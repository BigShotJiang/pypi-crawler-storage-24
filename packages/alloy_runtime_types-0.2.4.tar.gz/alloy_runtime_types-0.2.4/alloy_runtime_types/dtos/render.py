"""DTOs for render endpoints."""

from pydantic import BaseModel, Field


class RenderHtmlToImageRequest(BaseModel):
    """Request for HTML-to-image rendering endpoint."""

    html_text: str = Field(
        min_length=1,
        description="HTML text to render (can include tags like <strong>, <em>, etc.)",
    )
    bg_color: str = Field(
        default="#ffffff",
        pattern=r"^#[0-9a-fA-F]{6}$",
        description="Background color in hex format",
    )
    text_color: str = Field(
        default="#000000",
        pattern=r"^#[0-9a-fA-F]{6}$",
        description="Text color in hex format",
    )
    font_family: str = Field(
        default="Georgia, serif",
        min_length=1,
        description="CSS font-family value",
    )
    font_url: str | None = Field(
        default=None,
        description="URL to a web font stylesheet (e.g., Google Fonts URL)",
    )
    width: int = Field(
        default=1080,
        ge=100,
        le=4096,
        description="Image width in pixels",
    )
    height: int = Field(
        default=1080,
        ge=100,
        le=4096,
        description="Image height in pixels",
    )


class RenderHtmlToImageResponse(BaseModel):
    """Response containing the rendered image."""

    image_base64: str = Field(description="Base64-encoded PNG image")
    width: int = Field(description="Image width in pixels")
    height: int = Field(description="Image height in pixels")
    render_time_ms: int = Field(
        description="Time taken to render the image in milliseconds"
    )
