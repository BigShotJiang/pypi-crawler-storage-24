"""DTOs for pipeline endpoints."""

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, Field

from alloy_runtime_types.dtos.templates import TagResponse


def _empty_tag_responses() -> list[TagResponse]:
    return []


# ============================================================================
# Create Pipeline DTOs
# ============================================================================


class CreatePipelineRequest(BaseModel):
    """Request to create a new SDK pipeline definition.

    Pipelines are defined using Python code with @pipeline decorated functions:

        @pipeline
        async def my_pipeline(ctx: PipelineContext):
            result = await ctx.generate_text(step_id="research", agent=config.agent, ...)
            return result

    The code is stored in module_content and executed in Modal sandboxes.
    """

    name: str = Field(..., min_length=1, max_length=255, description="Pipeline name")
    description: str | None = Field(default=None, description="Pipeline description")

    module_content: str = Field(
        ...,
        description="Python source code containing @pipeline decorated function(s).",
    )
    pipeline_function_name: str | None = Field(
        default=None,
        description="Name of the @pipeline function to run. "
        "If None, uses the first/only @pipeline function in the module.",
    )

    is_public: bool = Field(
        default=False, description="Whether pipeline is publicly accessible"
    )


class CreatePipelineResponse(BaseModel):
    """Response after creating a pipeline."""

    id: UUID
    name: str
    description: str | None
    input_schema: dict[str, Any] | None = Field(
        default=None,
        description="JSON Schema for validating config at execution time. "
        "Extracted from @pipeline(Schema) if a Pydantic model is provided.",
    )
    is_public: bool
    created_at: datetime


# ============================================================================
# Execute Pipeline DTOs
# ============================================================================


class ExecutePipelineRequest(BaseModel):
    """Request to execute a pipeline.

    Pass runtime configuration via `config`. The pipeline accesses this
    as ctx.config with dot-notation.

    Example:
        POST /pipelines/{id}/execute
        {
            "config": {
                "synthesis": {
                    "agents": ["architect-grok", "architect-opus"],
                    "template": "synthesis-task"
                },
                "execution": {
                    "models": [{"provider_key": "openai", "provider_model_name": "gpt-4o"}],
                    "user_message": "Generate an avatar..."
                }
            },
            "timeout_seconds": 300
        }

    The pipeline code accesses this as:
        config = ctx.config
        for agent in config.synthesis.agents:
            ...
    """

    config: dict[str, Any] = Field(
        default_factory=dict,
        description="Runtime configuration for SDK pipelines. "
        "Accessible in pipeline code as ctx.config with dot-notation.",
    )

    timeout_seconds: int | None = Field(
        default=None,
        gt=0,
        description="Execution timeout in seconds. "
        "Uses server default (300 seconds) if not specified.",
    )

    env_vars: dict[str, str] | None = Field(
        default=None,
        description="Environment variables to inject into the pipeline execution. "
        "These override any env vars defined on the pipeline definition. "
        "Keys and values must be strings (like real environment variables).",
    )

    external_id: str | None = Field(
        default=None,
        description="Optional caller-provided identifier for idempotency and correlation. "
        "Must be unique per organization. Use to track processed items or prevent duplicates.",
    )

    metadata: dict[str, Any] | None = Field(
        default=None,
        description="User-defined metadata to attach to this execution. "
        "Stored as JSONB and queryable via list endpoint filters.",
    )

    tags: list[str] | None = Field(
        default=None,
        description="Tag paths to associate with this execution (e.g., ['pipeline.test', 'batch.weekly']). "
        "Tags are auto-created if they don't exist.",
    )


class ExecutePipelineResponse(BaseModel):
    """Response after executing a pipeline."""

    execution_id: UUID
    pipeline_id: UUID
    status: str
    external_id: str | None = None
    metadata: dict[str, Any] | None = None
    tags: list[TagResponse] | None = None
    result_data: dict[str, Any] | None = None
    total_duration_ms: int | None = None
    error_message: str | None = None


# ============================================================================
# Get Pipeline DTOs
# ============================================================================


class GetPipelineResponse(BaseModel):
    """Response for getting a pipeline definition."""

    id: UUID
    name: str
    description: str | None
    module_content: str | None = Field(
        default=None, description="Python source code (only returned to owner)"
    )
    pipeline_function_name: str | None = None
    input_schema: dict[str, Any] | None = Field(
        default=None,
        description="JSON Schema for validating config at execution time. "
        "Use this to build dynamic forms for pipeline inputs.",
    )
    is_public: bool
    created_at: datetime
    updated_at: datetime


# ============================================================================
# List Pipelines DTOs
# ============================================================================


class PipelineSummary(BaseModel):
    """Summary of a pipeline for list responses."""

    id: UUID
    name: str
    description: str | None
    is_public: bool
    created_at: datetime


class ListPipelinesResponse(BaseModel):
    """Response for listing pipelines."""

    pipelines: list[PipelineSummary]
    total: int


# ============================================================================
# Pipeline Execution DTOs (List, Get, Update)
# ============================================================================


class PipelineExecutionSummary(BaseModel):
    """Summary of a pipeline execution for list responses."""

    id: UUID
    pipeline_definition_id: UUID
    external_id: str | None = None
    status: str
    metadata: dict[str, Any] | None = None
    tags: list[TagResponse] = Field(default_factory=_empty_tag_responses)
    queued_at: datetime
    started_at: datetime | None = None
    completed_at: datetime | None = None
    total_duration_ms: int | None = None
    error_message: str | None = None


class ListPipelineExecutionsResponse(BaseModel):
    """Response for listing pipeline executions with pagination."""

    executions: list[PipelineExecutionSummary]
    total: int = Field(
        description="Total number of matching executions across all pages"
    )


class PipelineExecutionDetail(BaseModel):
    """Full details of a pipeline execution."""

    id: UUID
    pipeline_definition_id: UUID
    organization_id: UUID | None = None
    user_id: UUID
    external_id: str | None = None
    status: str
    metadata: dict[str, Any] | None = None
    tags: list[TagResponse] = Field(default_factory=_empty_tag_responses)
    input_parameters: dict[str, Any] | None = None
    result_data: dict[str, Any] | None = None
    error_message: str | None = None
    error_stack_trace: str | None = None
    execution_stdout: str | None = None
    execution_stderr: str | None = None
    queued_at: datetime
    started_at: datetime | None = None
    completed_at: datetime | None = None
    total_duration_ms: int | None = None


class GetPipelineExecutionResponse(BaseModel):
    """Response for getting a single pipeline execution."""

    execution: PipelineExecutionDetail


class UpdatePipelineExecutionRequest(BaseModel):
    """Request to update a pipeline execution's metadata or tags.

    All fields are optional - only provided fields are updated.
    Use metadata_merge to merge into existing metadata rather than replace.
    """

    metadata: dict[str, Any] | None = Field(
        default=None,
        description="Replace the execution's metadata with this value. "
        "Set to {} to clear metadata.",
    )

    metadata_merge: dict[str, Any] | None = Field(
        default=None,
        description="Merge these keys into existing metadata (existing | new). "
        "Mutually exclusive with 'metadata' field.",
    )

    tags: list[str] | None = Field(
        default=None,
        description="Replace all tags with these tag paths. "
        "Tags are auto-created if they don't exist. "
        "Set to [] to remove all tags.",
    )


class UpdatePipelineExecutionResponse(BaseModel):
    """Response after updating a pipeline execution."""

    execution: PipelineExecutionDetail


# ============================================================================
# Pipeline Environment Variables DTOs
# ============================================================================


class SetPipelineEnvVarsRequest(BaseModel):
    """Request to set environment variables on a pipeline."""

    env_vars: dict[str, str] = Field(
        ...,
        description="Environment variables to set on the pipeline. "
        "These are encrypted at rest and injected into pipeline executions. "
        "Pass an empty dict {} to clear all env vars.",
    )


class SetPipelineEnvVarsResponse(BaseModel):
    """Response after setting pipeline environment variables."""

    pipeline_id: UUID
    env_var_keys: list[str] = Field(
        ...,
        description="List of env var keys that were set (values are not returned for security).",
    )
    masked_values: dict[str, str] = Field(
        ...,
        description="Masked values showing only prefix for identification.",
    )


class ApprovalCheckpointResponse(BaseModel):
    id: UUID
    pipeline_execution_id: UUID
    approval_key: str
    status: str
    approved: bool | None = None
    decided_by_user_id: UUID | None = None
    decision_data: dict[str, Any] | None = None
    decided_at: str | None = None
    created_at: str


class DecideApprovalRequest(BaseModel):
    approved: bool
    decision_data: dict[str, Any] | None = None
