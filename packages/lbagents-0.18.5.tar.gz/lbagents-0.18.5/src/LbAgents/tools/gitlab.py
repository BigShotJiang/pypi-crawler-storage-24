###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""GitLab tools for merge request analysis and review posting.

These tools are created at runtime via ``make_gitlab_review_tools()``,
which accepts a GitLab token and MR IID, and returns pre-configured tool
instances scoped to that specific merge request. The model cannot specify
arbitrary MR IIDs — the IID is closed over in the factory.

The host application (LbAPI) provides the token and MR IID when building graphs.
"""

from __future__ import annotations

import json

import gitlab
from langchain_core.tools import tool

# CERN GitLab instance
GITLAB_URL = "https://gitlab.cern.ch"

# Analysis Productions repository — the main repo where production MRs live
AP_PROJECT_ID = 76059


def make_gitlab_review_tools(
    gitlab_token: str,
    mr_iid: int,
    gitlab_url: str = GITLAB_URL,
    project_id: int = AP_PROJECT_ID,
) -> list:
    """Create GitLab tools scoped to a specific merge request.

    All returned tools operate on the given ``mr_iid`` only — the model
    cannot access other merge requests.

    Args:
        gitlab_token: Private token or OAuth token for GitLab API.
        mr_iid: The merge request IID to scope all tools to.
        gitlab_url: GitLab instance URL.
        project_id: Default project ID (Analysis Productions repo).

    Returns:
        List of LangChain tool objects for MR operations.
    """
    gl = gitlab.Gitlab(gitlab_url, private_token=gitlab_token)
    project = gl.projects.get(project_id, lazy=True)

    @tool
    def get_mr_info() -> dict:
        """Get merge request metadata: title, description, author, source/target branches, head SHA, and web URL."""
        mr = project.mergerequests.get(mr_iid)
        return {
            "iid": mr.iid,
            "title": mr.title,
            "description": mr.description or "",
            "author": mr.author["username"],
            "source_branch": mr.source_branch,
            "target_branch": mr.target_branch,
            "head_sha": mr.sha,
            "web_url": mr.web_url,
            "state": mr.state,
            "labels": mr.labels,
        }

    @tool
    def get_mr_diff() -> list[dict]:
        """Get the file-level diff for the merge request.

        Returns a list of changed files with their diffs (old_path, new_path,
        diff content, new_file/deleted_file/renamed_file flags).
        """
        mr = project.mergerequests.get(mr_iid)
        changes = mr.changes()
        diffs = []
        for change in changes.get("changes", []):
            diffs.append(
                {
                    "old_path": change["old_path"],
                    "new_path": change["new_path"],
                    "diff": change["diff"],
                    "new_file": change["new_file"],
                    "deleted_file": change["deleted_file"],
                    "renamed_file": change["renamed_file"],
                }
            )
        return diffs

    @tool
    def get_mr_file_content(file_path: str) -> str:
        """Get the full content of a file from the merge request's source branch.

        Useful for reading the complete info.yaml or options file when the diff
        alone is not sufficient to understand the context.

        Args:
            file_path: Path to the file within the repository.
        """
        mr = project.mergerequests.get(mr_iid)
        f = project.files.get(file_path=file_path, ref=mr.source_branch)
        return f.decode().decode("utf-8")

    @tool
    def post_mr_review(
        body: str,
        inline_comments: list[dict] | None = None,
    ) -> dict:
        """Post a review comment on the merge request.

        Posts a top-level comment with the review body. Optionally adds inline
        comments on specific lines of the diff.

        Args:
            body: The main review body (markdown). Should include diagnosis
                  summary, root cause, and fix recommendations.
            inline_comments: Optional list of inline comments. Each dict has:
                - file_path (str): Path to the file
                - new_line (int): Line number in the new version
                - body (str): Comment text (markdown)
        """
        mr = project.mergerequests.get(mr_iid)

        # Post main review as a note
        note = mr.notes.create({"body": body})
        result = {"note_id": note.id, "web_url": f"{mr.web_url}#note_{note.id}"}

        # Post inline comments as diff discussions
        if isinstance(inline_comments, str):
            inline_comments = json.loads(inline_comments)
        if inline_comments:
            diff_refs = mr.changes().get("diff_refs", {})
            result["inline_comments"] = []
            for comment in inline_comments:
                discussion = mr.discussions.create(
                    {
                        "body": comment["body"],
                        "position": {
                            "base_sha": diff_refs.get("base_sha", ""),
                            "head_sha": diff_refs.get("head_sha", ""),
                            "start_sha": diff_refs.get("start_sha", ""),
                            "position_type": "text",
                            "new_path": comment["file_path"],
                            "new_line": comment["new_line"],
                        },
                    }
                )
                result["inline_comments"].append({"discussion_id": discussion.id})

        return result

    @tool
    def get_mr_commits() -> list[dict]:
        """List commits in this merge request, newest first.

        Useful for understanding the change history and narrowing down
        which commit may have introduced a CI failure.
        """
        mr = project.mergerequests.get(mr_iid)
        commits = mr.commits()
        return [
            {
                "sha": c.id[:12],
                "title": c.title,
                "author_name": c.author_name,
                "created_at": c.created_at,
            }
            for c in commits
        ]

    @tool
    def get_target_branch_file(file_path: str) -> str:
        """Get the content of a file from the merge request's target branch.

        Use this to compare against the source branch version and understand
        what the file looked like before the MR changes.

        Args:
            file_path: Path to the file within the repository.
        """
        mr = project.mergerequests.get(mr_iid)
        f = project.files.get(file_path=file_path, ref=mr.target_branch)
        return f.decode().decode("utf-8")

    @tool
    def get_commit_diff(commit_sha: str) -> list[dict]:
        """Get the diff for a specific commit in this merge request.

        Use after ``get_mr_commits`` to inspect what changed in a single
        push. Helps correlate a specific commit with a pipeline failure
        (e.g. "pipeline X failed on commit Y — what did Y change?").

        Args:
            commit_sha: The commit SHA (short or full) from get_mr_commits.
        """
        commit = project.commits.get(commit_sha)
        return [
            {
                "old_path": d["old_path"],
                "new_path": d["new_path"],
                "diff": d["diff"],
                "new_file": d["new_file"],
                "deleted_file": d["deleted_file"],
                "renamed_file": d["renamed_file"],
            }
            for d in commit.diff()
        ]

    return [
        get_mr_info,
        get_mr_diff,
        get_mr_file_content,
        post_mr_review,
        get_mr_commits,
        get_commit_diff,
        get_target_branch_file,
    ]
