###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""Graph factory functions and workflow registration.

Importing this module populates WORKFLOW_REGISTRY with all available workflows.
"""

from __future__ import annotations

from LbAgents.registry import (
    DeliveryTarget,
    TriggerType,
    WorkflowSpec,
    register_workflow,
)

from .ap_debug_ci_failure import build_ap_debug_ci_failure_graph
from .ap_debug_ci_failure_v2 import build_ap_debug_ci_failure_multiagent_graph
from .ap_debug_stuck_productions import build_ap_debug_stuck_productions_graph
from .mattermost_debug_user_request import build_mattermost_debug_user_request_graph
from .nightly_failure_summary import build_nightly_failure_summary_graph

register_workflow(
    WorkflowSpec(
        name="ap_debug_ci_failure",
        description="Diagnose CI pipeline failures and post review on GitLab MR",
        factory=build_ap_debug_ci_failure_graph,
        triggers=[TriggerType.INTERNAL],
        delivery=[DeliveryTarget.GITLAB_MR],
        requires_review=True,
        llms_required=["orchestrator"],
        timeout_seconds=600,
        tool_allowlist={
            # Pipeline investigation
            "get_pipeline_info",
            "get_pipeline_log",
            "get_pipeline_validation_report",
            "get_ci_run_info",
            "get_ci_run_log",
            "get_ci_job_info",
            "get_ci_job_logs",
            "grep_ci_job_log",
            "list_pipelines_for_mr",
            # Production context
            "get_production_summary",
            "get_production_repo_path",
            # Diagnostics
            "explain_ci_job_status",
            "get_debugging_guide",
            "list_application_versions",
            # GitLab MR tools (created at runtime, not from MCP)
            "get_mr_info",
            "get_mr_diff",
            "get_mr_file_content",
            "post_mr_review",
            "get_mr_commits",
            "get_commit_diff",
            "get_target_branch_file",
        },
    )
)

register_workflow(
    WorkflowSpec(
        name="ap_debug_ci_failure_multiagent",
        description="Multi-agent CI failure debugging with parallel job investigation",
        factory=build_ap_debug_ci_failure_multiagent_graph,
        triggers=[TriggerType.INTERNAL],
        delivery=[DeliveryTarget.GITLAB_MR],
        requires_review=True,
        llms_required=["orchestrator", "coder"],
        timeout_seconds=600,
        tool_allowlist={
            # Pipeline investigation
            "get_pipeline_info",
            "get_pipeline_log",
            "get_pipeline_validation_report",
            "get_ci_run_info",
            "get_ci_run_log",
            "get_ci_job_info",
            "get_ci_job_logs",
            "grep_ci_job_log",
            "list_pipelines_for_mr",
            # Production context
            "get_production_summary",
            "get_production_repo_path",
            # Diagnostics
            "explain_ci_job_status",
            "get_debugging_guide",
            "list_application_versions",
            # GitLab MR tools (created at runtime, not from MCP)
            "get_mr_info",
            "get_mr_diff",
            "get_mr_file_content",
            "post_mr_review",
            "get_mr_commits",
            "get_commit_diff",
            "get_target_branch_file",
            # Codebase knowledge graph (RAG)
            "query_code_graph",
            "get_code_snippet",
            "get_graph_schema",
            "run_cypher",
            "search_code_text",
        },
    )
)

register_workflow(
    WorkflowSpec(
        name="ap_debug_stuck_productions",
        description="Diagnose stuck productions (MaxReset, stalled files) and propose actions",
        factory=build_ap_debug_stuck_productions_graph,
        triggers=[TriggerType.INTERNAL],
        delivery=[DeliveryTarget.GITLAB_ISSUE],
        requires_review=True,
        llms_required=["orchestrator"],
        timeout_seconds=600,
        tool_allowlist={
            "get_sample_details",
            "get_sample_progress",
            "get_maxreset_files",
            "get_production_summary",
            "get_debugging_guide",
            "get_grid_job_log_url",
            "explain_sample_state",
            "get_production_repo_path",
            "add_known_failure",
        },
    )
)

register_workflow(
    WorkflowSpec(
        name="mattermost_debug_user_request",
        description="Handle user support questions from Mattermost and draft responses",
        factory=build_mattermost_debug_user_request_graph,
        triggers=[TriggerType.WEBHOOK_MATTERMOST],
        delivery=[DeliveryTarget.MATTERMOST],
        requires_review=True,
        llms_required=["orchestrator"],
        timeout_seconds=300,
        tool_allowlist=None,  # needs access to all tools depending on user question
    )
)

register_workflow(
    WorkflowSpec(
        name="nightly_failure_summary",
        description="Summarize test failures from nightly build results",
        factory=build_nightly_failure_summary_graph,
        triggers=[TriggerType.MANUAL],
        delivery=[],
        requires_review=False,
        llms_required=["orchestrator"],
        timeout_seconds=600,
        tool_allowlist={
            "get_nightly_status_summary",
            "list_nightly_platforms",
            "list_nightly_projects",
            "get_failed_tests",
            "get_test_output",
            "get_test_measurement",
        },
    )
)

__all__ = [
    "build_ap_debug_ci_failure_graph",
    "build_ap_debug_ci_failure_multiagent_graph",
    "build_ap_debug_stuck_productions_graph",
    "build_mattermost_debug_user_request_graph",
    "build_nightly_failure_summary_graph",
]
