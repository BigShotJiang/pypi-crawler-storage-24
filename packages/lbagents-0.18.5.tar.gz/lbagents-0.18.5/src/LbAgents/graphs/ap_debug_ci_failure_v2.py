###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""Multi-agent CI Failure Debug workflow.

Fans out parallel job investigator sub-agents, synthesizes findings into a
review draft, then runs a targeted code review with full context from
both investigations and the draft review.

Graph structure:
    triage (ReAct) → collect_job_info → cluster_jobs → fan_out
        → investigate_job (sub-agent per cluster, parallel)
    → [optional review_findings interrupt] → synthesize (draft review body)
    → review_code (code review sub-agent, gets findings + draft)
    → [human_review interrupt] → post_review → END
"""

from __future__ import annotations

import json
import logging
from collections import defaultdict
from typing import Literal

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage
from langchain_core.tools import tool
from langgraph.graph import END, StateGraph
from langgraph.prebuilt import ToolNode
from langgraph.types import Send
from openai import BadRequestError

from LbAgents.context import cap_tool_message_content, trim_messages_for_context
from LbAgents.prompts.templates import (
    CI_CODE_REVIEWER_PROMPT,
    CI_CODE_TRACE_PROMPT,
    CI_JOB_INVESTIGATOR_PROMPT,
    CI_SYNTHESIZER_PROMPT,
    CI_TRIAGE_PROMPT,
)
from LbAgents.schemas.state import (
    CodeReviewComment,
    CodeReviewState,
    CodeTraceState,
    JobCluster,
    JobFinding,
    JobInvestigationState,
    MultiAgentCIDebugState,
)

logger = logging.getLogger(__name__)

_DEFAULT_MAX_MESSAGE_TOKENS = 32_000
# Model context = 65536, minus 16384 completion tokens, minus ~3000 for tool
# schemas → ~46000 available.  The char-based token estimator undercounts by
# ~1.5x on structured content (JSON, logs), so use 30k to stay safe.
_INVESTIGATOR_MAX_TOKENS = 30_000
_MAX_CLUSTERS = 8
_MAX_INVESTIGATOR_ITERATIONS = 15

# Tool names by phase — used to partition the flat tool list
_TRIAGE_TOOLS = {
    "get_pipeline_info",
    "get_pipeline_validation_report",
    "get_ci_run_info",
    "get_ci_run_log",
    "list_pipelines_for_mr",
    # Scratchpad tools (for large tool outputs)
    "read_document",
    "search_document",
    "list_documents",
}
_INVESTIGATOR_TOOLS = {
    "get_ci_job_info",
    "get_ci_job_logs",
    "grep_ci_job_log",
    "list_application_versions",
    # Codebase knowledge graph
    "query_code_graph",
    "get_code_snippet",
    # Scratchpad tools (always available)
    "read_document",
    "search_document",
    "list_documents",
}
_SYNTHESIZER_TOOLS = {
    "get_mr_info",
    "get_ci_run_log",
    # Scratchpad tools (for large tool outputs)
    "read_document",
    "search_document",
    "list_documents",
}
_POST_REVIEW_TOOLS = {
    "post_mr_review",
}
_CODE_TRACE_TOOLS = {
    "query_code_graph",
    "get_code_snippet",
    "get_graph_schema",
    "run_cypher",
    "search_code_text",  # grep repos for log messages, error strings, etc.
}
_CODE_REVIEW_TOOLS = {
    "get_mr_info",
    "get_mr_diff",
    "get_mr_file_content",
    "get_target_branch_file",
    "get_mr_commits",
    "get_commit_diff",
    # Codebase knowledge graph
    "get_graph_schema",
    "run_cypher",
    "get_code_snippet",
    "query_code_graph",
    # Scratchpad tools
    "read_document",
    "search_document",
    "list_documents",
}

_CODE_TRACE_MAX_TOKENS = 16_000
_CODE_REVIEW_MAX_TOKENS = 32_000
_MAX_CODE_TRACE_ITERATIONS = 8
_MAX_CODE_REVIEW_ITERATIONS = 10


def _partition_tools(
    tools: list,
) -> tuple[list, list, list, list, list, list]:
    """Split the flat tool list into phase-specific sets."""
    triage, investigator, synthesizer = [], [], []
    code_trace, code_review, post_review = [], [], []
    for t in tools:
        name = t.name
        if name in _TRIAGE_TOOLS:
            triage.append(t)
        if name in _INVESTIGATOR_TOOLS:
            investigator.append(t)
        if name in _SYNTHESIZER_TOOLS:
            synthesizer.append(t)
        if name in _CODE_TRACE_TOOLS:
            code_trace.append(t)
        if name in _CODE_REVIEW_TOOLS:
            code_review.append(t)
        if name in _POST_REVIEW_TOOLS:
            post_review.append(t)
    return triage, investigator, synthesizer, code_trace, code_review, post_review


# ---------------------------------------------------------------------------
# report_finding — LangChain tool for sub-agent structured output
# ---------------------------------------------------------------------------


@tool
def report_finding(
    diagnosis: str,
    root_cause: str,
    severity: Literal["critical", "error", "warning"],
    evidence: str = "",
) -> str:
    """Submit your investigation finding. Call this ONCE when you have completed
    your investigation of the assigned job. This records your structured finding
    for the synthesis phase.

    Args:
        diagnosis: Structured summary of what went wrong (up to 1000 chars).
        root_cause: Single sentence explaining the root cause.
        severity: "critical" (job can never succeed), "error" (fixable issue),
            or "warning" (non-blocking concern).
        evidence: Key error messages, tracebacks, or log excerpts that support
            your diagnosis (up to 3000 chars). The synthesizer will use these
            verbatim in the review — include exact error text.
    """
    return "Finding recorded successfully."


# ---------------------------------------------------------------------------
# Job investigator sub-graph
# ---------------------------------------------------------------------------


def _build_investigator_subgraph(
    llm: BaseChatModel,
    investigator_tools: list,
    max_context_tokens: int,
) -> StateGraph:
    """Build the inner ReAct graph for investigating a single CI job.

    Returns an uncompiled StateGraph[JobInvestigationState].
    """
    all_tools = investigator_tools + [report_finding]
    llm_with_tools = llm.bind_tools(all_tools)

    def agent_node(state: JobInvestigationState):
        messages = CI_JOB_INVESTIGATOR_PROMPT.format_messages(
            messages=state["messages"],
            pipeline_id=state.get("pipeline_id", "?"),
            ci_run_name=state.get("ci_run_name", "?"),
            job_name=state.get("job_name", "?"),
        )
        messages = trim_messages_for_context(messages, max_tokens=max_context_tokens)
        try:
            response = llm_with_tools.invoke(messages)
        except BadRequestError as exc:
            logger.error("Investigator LLM request failed: %s", exc)
            return {
                "messages": [
                    AIMessage(
                        content="Investigator stopped: LLM request failed.",
                        name="job_investigator",
                    )
                ],
                "error": str(exc),
            }
        response.name = "job_investigator"
        return {"messages": [response]}

    tool_node = ToolNode(all_tools)

    async def capped_tools(state: JobInvestigationState):
        result = await tool_node.ainvoke(state)
        result["messages"] = cap_tool_message_content(result["messages"])
        return result

    def extract_finding(state: JobInvestigationState):
        """After report_finding is called, extract the args and write to job_findings."""
        # Walk backwards to find the report_finding tool call
        for msg in reversed(state["messages"]):
            if hasattr(msg, "tool_calls") and msg.tool_calls:
                for tc in msg.tool_calls:
                    if tc["name"] == "report_finding":
                        args = tc["args"]
                        finding = JobFinding(
                            job_name=state.get("job_name", "unknown"),
                            ci_run_name=state.get("ci_run_name", "unknown"),
                            affected_jobs=state.get("affected_jobs", []),
                            diagnosis=args.get("diagnosis", ""),
                            root_cause=args.get("root_cause", ""),
                            severity=args.get("severity", "error"),
                            evidence=args.get("evidence", ""),
                            code_context="",
                        )
                        return {"job_findings": [finding]}
        # Fallback: agent didn't call report_finding — create a finding from last message
        last = state["messages"][-1] if state["messages"] else None
        content = (
            last.content
            if last and hasattr(last, "content") and last.content
            else "No finding produced."
        )
        # Use the LLM's own explanation as root_cause if it's substantive
        root_cause = (
            content[:200]
            if content != "No finding produced."
            else "Unable to determine root cause — investigator did not produce a finding."
        )
        return {
            "job_findings": [
                JobFinding(
                    job_name=state.get("job_name", "unknown"),
                    ci_run_name=state.get("ci_run_name", "unknown"),
                    affected_jobs=state.get("affected_jobs", []),
                    diagnosis=content[:500],
                    root_cause=root_cause,
                    severity="error",
                    evidence="",
                    code_context="",
                )
            ]
        }

    def _has_read_logs(state: JobInvestigationState) -> bool:
        """Check if the investigator has called get_ci_job_logs at least once."""
        return any(
            isinstance(msg, ToolMessage)
            and getattr(msg, "name", None) == "get_ci_job_logs"
            for msg in state["messages"]
        )

    def should_continue(state: JobInvestigationState):
        if state.get("error"):
            return "extract_finding"
        last = state["messages"][-1]
        if not hasattr(last, "tool_calls") or not last.tool_calls:
            # Force log reading: if the LLM tries to finish without reading
            # any logs, inject a nudge and send it back to the agent node.
            if not _has_read_logs(state):
                logger.warning(
                    "Investigator tried to finish without reading logs — nudging"
                )
                nudge = HumanMessage(
                    content=(
                        "You MUST read the logs before concluding. Call "
                        "`get_ci_job_logs` with no filename to list available "
                        "logs, then read the application log."
                    )
                )
                state["messages"].append(nudge)
                return "agent"
            return "extract_finding"
        # Check if report_finding is among the tool calls
        for tc in last.tool_calls:
            if tc["name"] == "report_finding":
                # Block report_finding if no logs have been read
                if not _has_read_logs(state):
                    logger.warning(
                        "Investigator tried to report without reading logs — nudging"
                    )
                    # Remove the report_finding tool call and nudge
                    last.tool_calls = [
                        tc for tc in last.tool_calls if tc["name"] != "report_finding"
                    ]
                    nudge = HumanMessage(
                        content=(
                            "You called report_finding without reading any logs. "
                            "Call `get_ci_job_logs` first, then read the "
                            "application log before reporting."
                        )
                    )
                    state["messages"].append(nudge)
                    return "agent"
                return "tools"  # execute report_finding, then extract
        return "tools"

    def after_tools(state: JobInvestigationState):
        """Route after tool execution: if report_finding was just executed, extract."""
        for msg in reversed(state["messages"]):
            if (
                isinstance(msg, ToolMessage)
                and getattr(msg, "name", None) == "report_finding"
            ):
                return "extract_finding"
            # Only check the most recent tool messages
            if not isinstance(msg, ToolMessage):
                break
        return "agent"

    graph = StateGraph(JobInvestigationState)
    graph.add_node("agent", agent_node)
    graph.add_node("tools", capped_tools)
    graph.add_node("extract_finding", extract_finding)

    graph.set_entry_point("agent")
    graph.add_conditional_edges(
        "agent",
        should_continue,
        {"tools": "tools", "extract_finding": "extract_finding", "agent": "agent"},
    )
    graph.add_conditional_edges(
        "tools",
        after_tools,
        {"agent": "agent", "extract_finding": "extract_finding"},
    )
    graph.add_edge("extract_finding", END)

    return graph


# ---------------------------------------------------------------------------
# Code trace sub-graph (coder LLM + RAG tools)
# ---------------------------------------------------------------------------


@tool
def report_code_context(
    code_paths: str,
    relevant_symbols: str,
    suggested_fix_location: str = "",
) -> str:
    """Submit the code context you discovered. Call this ONCE when done tracing.

    Args:
        code_paths: Call chain description from user code to the error site.
            Include qualified names and file paths.
        relevant_symbols: Comma-separated qualified names involved in the error.
        suggested_fix_location: Where the fix should be applied (file + function).
    """
    return "Code context recorded."


def _build_code_trace_subgraph(
    llm: BaseChatModel,
    code_trace_tools: list,
    max_context_tokens: int,
) -> StateGraph:
    """Build the inner ReAct graph for tracing errors through the code graph.

    Uses the coder LLM with RAG tools (query_code_graph, get_code_snippet, etc.)
    to enrich investigation findings with cross-repo code context.

    Returns an uncompiled StateGraph[CodeTraceState].
    """
    all_tools = code_trace_tools + [report_code_context]
    llm_with_tools = llm.bind_tools(all_tools)

    def agent_node(state: CodeTraceState):
        finding = state.get("finding") or {}
        messages = CI_CODE_TRACE_PROMPT.format_messages(
            messages=state["messages"],
            job_name=finding.get("job_name", "?"),
            root_cause=finding.get("root_cause", "unknown"),
            diagnosis=finding.get("diagnosis", "unknown"),
            evidence=finding.get("evidence", "(no evidence)"),
        )
        messages = trim_messages_for_context(messages, max_tokens=max_context_tokens)
        try:
            response = llm_with_tools.invoke(messages)
        except BadRequestError as exc:
            logger.error("Code trace LLM request failed: %s", exc)
            return {
                "messages": [
                    AIMessage(
                        content="Code trace stopped: LLM request failed.",
                        name="code_tracer",
                    )
                ],
                "error": str(exc),
            }
        response.name = "code_tracer"
        return {"messages": [response]}

    tool_node = ToolNode(all_tools)

    async def capped_tools(state: CodeTraceState):
        result = await tool_node.ainvoke(state)
        result["messages"] = cap_tool_message_content(result["messages"])
        return result

    def extract_context(state: CodeTraceState):
        """Extract code_context from the report_code_context tool call."""
        for msg in reversed(state["messages"]):
            if hasattr(msg, "tool_calls") and msg.tool_calls:
                for tc in msg.tool_calls:
                    if tc["name"] == "report_code_context":
                        args = tc["args"]
                        parts = []
                        if args.get("code_paths"):
                            parts.append(f"Code paths: {args['code_paths']}")
                        if args.get("relevant_symbols"):
                            parts.append(f"Symbols: {args['relevant_symbols']}")
                        if args.get("suggested_fix_location"):
                            parts.append(
                                f"Fix location: {args['suggested_fix_location']}"
                            )
                        return {"code_context": "\n".join(parts)}
        # Fallback: use last message content if the LLM didn't call the tool
        last = state["messages"][-1] if state["messages"] else None
        content = (
            last.content if last and hasattr(last, "content") and last.content else ""
        )
        return {"code_context": content[:1000] if content else ""}

    def should_continue(state: CodeTraceState):
        if state.get("error"):
            return "extract_context"
        last = state["messages"][-1]
        if not hasattr(last, "tool_calls") or not last.tool_calls:
            return "extract_context"
        for tc in last.tool_calls:
            if tc["name"] == "report_code_context":
                return "tools"
        return "tools"

    def after_tools(state: CodeTraceState):
        for msg in reversed(state["messages"]):
            if (
                isinstance(msg, ToolMessage)
                and getattr(msg, "name", None) == "report_code_context"
            ):
                return "extract_context"
            if not isinstance(msg, ToolMessage):
                break
        return "agent"

    graph = StateGraph(CodeTraceState)
    graph.add_node("agent", agent_node)
    graph.add_node("tools", capped_tools)
    graph.add_node("extract_context", extract_context)

    graph.set_entry_point("agent")
    graph.add_conditional_edges(
        "agent",
        should_continue,
        {"tools": "tools", "extract_context": "extract_context"},
    )
    graph.add_conditional_edges(
        "tools",
        after_tools,
        {"agent": "agent", "extract_context": "extract_context"},
    )
    graph.add_edge("extract_context", END)

    return graph


# ---------------------------------------------------------------------------
# Code review sub-graph
# ---------------------------------------------------------------------------


@tool
def report_code_review(comments: list[CodeReviewComment]) -> str:
    """Submit your code review comments. Call this ONCE when you have finished
    reviewing all changed files.

    Args:
        comments: List of inline comments. Each must have:
            - file_path (str): Path to the file (use new_path from the diff)
            - new_line (int): Line number in the new version of the file
            - body (str): Markdown comment — use ```suggestion blocks to
              propose concrete fixes where possible
    """
    return "Code review comments recorded."


def _build_code_review_subgraph(
    llm: BaseChatModel,
    code_review_tools: list,
    max_context_tokens: int,
) -> StateGraph:
    """Build the inner ReAct graph for reviewing MR code changes.

    Returns an uncompiled StateGraph[CodeReviewState].
    """
    all_tools = code_review_tools + [report_code_review]
    llm_with_tools = llm.bind_tools(all_tools)

    def agent_node(state: CodeReviewState):
        messages = CI_CODE_REVIEWER_PROMPT.format_messages(
            messages=state["messages"],
        )
        messages = trim_messages_for_context(messages, max_tokens=max_context_tokens)
        try:
            response = llm_with_tools.invoke(messages)
        except BadRequestError as exc:
            logger.error("Code reviewer LLM request failed: %s", exc)
            return {
                "messages": [
                    AIMessage(
                        content="Code reviewer stopped: LLM request failed.",
                        name="code_reviewer",
                    )
                ],
                "error": str(exc),
            }
        response.name = "code_reviewer"
        return {"messages": [response]}

    tool_node = ToolNode(all_tools)

    async def capped_tools(state: CodeReviewState):
        result = await tool_node.ainvoke(state)
        result["messages"] = cap_tool_message_content(result["messages"])
        return result

    def extract_comments(state: CodeReviewState):
        """After report_code_review is called, extract comments to state."""
        for msg in reversed(state["messages"]):
            if hasattr(msg, "tool_calls") and msg.tool_calls:
                for tc in msg.tool_calls:
                    if tc["name"] == "report_code_review":
                        raw_comments = tc["args"].get("comments", [])
                        comments = []
                        for c in raw_comments:
                            if not isinstance(c, dict):
                                logger.warning(
                                    "Skipping malformed comment (expected "
                                    "dict, got %s): %r",
                                    type(c).__name__,
                                    c,
                                )
                                continue
                            if not c.get("file_path") or not c.get("body"):
                                continue
                            comments.append(
                                CodeReviewComment(
                                    file_path=c["file_path"],
                                    new_line=c.get("new_line", 0),
                                    body=c["body"],
                                )
                            )
                        return {"code_review_comments": comments}
        return {"code_review_comments": []}

    def should_continue(state: CodeReviewState):
        if state.get("error"):
            return "extract_comments"
        last = state["messages"][-1]
        if not hasattr(last, "tool_calls") or not last.tool_calls:
            return "extract_comments"
        for tc in last.tool_calls:
            if tc["name"] == "report_code_review":
                return "tools"  # execute report_code_review, then extract
        return "tools"

    def after_tools(state: CodeReviewState):
        for msg in reversed(state["messages"]):
            if (
                isinstance(msg, ToolMessage)
                and getattr(msg, "name", None) == "report_code_review"
            ):
                return "extract_comments"
            if not isinstance(msg, ToolMessage):
                break
        return "agent"

    graph = StateGraph(CodeReviewState)
    graph.add_node("agent", agent_node)
    graph.add_node("tools", capped_tools)
    graph.add_node("extract_comments", extract_comments)

    graph.set_entry_point("agent")
    graph.add_conditional_edges(
        "agent",
        should_continue,
        {"tools": "tools", "extract_comments": "extract_comments"},
    )
    graph.add_conditional_edges(
        "tools",
        after_tools,
        {"agent": "agent", "extract_comments": "extract_comments"},
    )
    graph.add_edge("extract_comments", END)

    return graph


# ---------------------------------------------------------------------------
# Main multiagent graph
# ---------------------------------------------------------------------------


def build_ap_debug_ci_failure_multiagent_graph(
    orchestrator_llm: BaseChatModel,
    tools: list,
    write_tool_names: list[str] | None = None,
    config: dict | None = None,
    max_context_tokens: int | None = None,
    coder_llm: BaseChatModel | None = None,
    **kwargs,
) -> StateGraph:
    """Build an uncompiled StateGraph for multi-agent CI failure diagnosis.

    Triage → cluster → parallel investigation → code trace → synthesis → review.

    Args:
        orchestrator_llm: LLM for triage, investigation, and synthesis.
        tools: All available tools (MCP + GitLab).
        write_tool_names: Tools requiring human approval (e.g. ["post_mr_review"]).
        config: Optional configuration dict.
        max_context_tokens: Token budget for messages. Defaults to 32000.
        coder_llm: Optional code-specialized LLM for code trace and review.
            Falls back to orchestrator_llm if not provided.

    Returns:
        Uncompiled StateGraph. Caller must call .compile(checkpointer=...).
    """
    write_names = set(write_tool_names or [])
    token_budget = max_context_tokens or _DEFAULT_MAX_MESSAGE_TOKENS

    (
        triage_tools,
        investigator_tools,
        synthesizer_tools,
        code_trace_tools,
        code_review_tools,
        post_review_tools,
    ) = _partition_tools(tools)

    # --- Triage phase (ReAct loop with triage tools only) ---

    triage_llm = orchestrator_llm.bind_tools(triage_tools)

    def triage_agent(state: MultiAgentCIDebugState):
        messages = CI_TRIAGE_PROMPT.format_messages(messages=state["messages"])
        messages = trim_messages_for_context(messages, max_tokens=token_budget)
        try:
            response = triage_llm.invoke(messages)
        except BadRequestError as exc:
            logger.error("Triage LLM request failed: %s", exc)
            return {
                "messages": [
                    AIMessage(
                        content="Triage stopped: LLM request failed.",
                        name="triage_agent",
                    )
                ],
                "error": str(exc),
            }
        response.name = "triage_agent"
        return {"messages": [response]}

    triage_tool_node = ToolNode(triage_tools)

    async def triage_tools_node(state: MultiAgentCIDebugState):
        result = await triage_tool_node.ainvoke(state)
        result["messages"] = cap_tool_message_content(result["messages"])
        return result

    def triage_should_continue(state: MultiAgentCIDebugState):
        if state.get("error"):
            return END
        last = state["messages"][-1]
        if not hasattr(last, "tool_calls") or not last.tool_calls:
            return "collect_job_info"
        return "triage_tools"

    # --- Deterministic nodes ---

    async def collect_job_info(state: MultiAgentCIDebugState):
        """Parse triage tool results to extract failing jobs, then fetch job info."""
        failing_jobs = []

        # Extract failing job names from get_ci_run_info tool results
        for msg in state["messages"]:
            if not isinstance(msg, ToolMessage):
                continue
            if getattr(msg, "name", None) != "get_ci_run_info":
                continue
            try:
                data = (
                    json.loads(msg.content)
                    if isinstance(msg.content, str)
                    else msg.content
                )
            except (json.JSONDecodeError, TypeError):
                continue
            ci_run_name = data.get("ci_run_name", state.get("ci_run_name", ""))
            for job in data.get("jobs", []):
                if job.get("status", "").upper() == "FAILED":
                    failing_jobs.append(
                        {
                            "ci_run_name": ci_run_name,
                            "job_name": job["name"],
                        }
                    )

        if not failing_jobs:
            logger.info("No failing jobs found in triage results")
            return {"failing_jobs": []}

        # Fetch failure_summary for each failing job via MCP tools
        get_ci_job_info_tool = None
        for t in tools:
            if t.name == "get_ci_job_info":
                get_ci_job_info_tool = t
                break

        if get_ci_job_info_tool:
            for job in failing_jobs:
                try:
                    result = await get_ci_job_info_tool.ainvoke(
                        {
                            "pipeline_id": state.get("pipeline_id"),
                            "ci_run_name": job["ci_run_name"],
                            "job_name": job["job_name"],
                        }
                    )
                    data = json.loads(result) if isinstance(result, str) else result
                    job["failure_summary"] = data.get("failure_summary", {})
                except Exception:
                    logger.warning(
                        "Failed to get job info for %s", job["job_name"], exc_info=True
                    )
                    job["failure_summary"] = {}

        return {"failing_jobs": failing_jobs}

    def cluster_jobs(state: MultiAgentCIDebugState):
        """Group failing jobs by failure signature and pick representatives."""
        failing_jobs = state.get("failing_jobs", [])
        if not failing_jobs:
            return {"job_clusters": []}

        # Build signature for each job
        clusters: dict[str, list[dict]] = defaultdict(list)
        for job in failing_jobs:
            summary = job.get("failure_summary", {})
            errors = sorted(summary.get("errors", []))
            fatal = summary.get("log_counts", {}).get("fatal", 0) > 0
            exec_zero = summary.get("exec_time_seconds", -1) == 0
            sig = json.dumps({"errors": errors, "fatal": fatal, "exec_zero": exec_zero})
            clusters[sig].append(job)

        # Sort clusters by size (largest first) and cap
        sorted_clusters = sorted(
            clusters.items(), key=lambda x: len(x[1]), reverse=True
        )
        sorted_clusters = sorted_clusters[:_MAX_CLUSTERS]

        job_clusters = []
        for sig, jobs in sorted_clusters:
            representative = jobs[0]
            job_clusters.append(
                JobCluster(
                    signature=sig,
                    representative_job=representative["job_name"],
                    ci_run_name=representative["ci_run_name"],
                    job_names=[j["job_name"] for j in jobs],
                    failure_summary=representative.get("failure_summary", {}),
                )
            )

        logger.info(
            "Clustered %d failing jobs into %d clusters",
            len(failing_jobs),
            len(job_clusters),
        )
        return {"job_clusters": job_clusters}

    def fan_out(state: MultiAgentCIDebugState):
        """Route: Send one investigate_job per cluster, or skip to synthesize."""
        clusters = state.get("job_clusters", [])
        if not clusters:
            return "synthesize"

        sends = []
        for cluster in clusters:
            # Build a briefing with what we already know from triage
            summary = cluster.get("failure_summary", {})
            briefing_parts = [
                f"Investigate the failed CI job '{cluster['representative_job']}' "
                f"in CI run '{cluster['ci_run_name']}' of pipeline "
                f"{state.get('pipeline_id', '?')}.",
                "",
                "Here is what triage already found:",
            ]
            if summary.get("known_failure_patterns"):
                patterns = summary["known_failure_patterns"]
                briefing_parts.append(
                    f"- LogAnalysis matched {len(patterns)} known failure pattern(s): "
                    + ", ".join(p.get("name", "?") for p in patterns)
                )
            if summary.get("errors"):
                briefing_parts.append(
                    f"- Detected errors: {', '.join(summary['errors'][:5])}"
                )
            # Only flag exec_time=0 if no step succeeded (otherwise it's
            # just a measurement artifact — the app ran but DIRAC reported 0).
            steps = summary.get("steps", [])
            any_step_success = any(s.get("success") for s in steps)
            if summary.get("exec_time_seconds", -1) == 0 and not any_step_success:
                briefing_parts.append(
                    "- exec_time is 0 and no step succeeded — the application "
                    "may never have started"
                )
            log_counts = summary.get("log_counts", {})
            if log_counts.get("fatal", 0) > 0:
                briefing_parts.append(
                    f"- Log counts: {log_counts.get('fatal', 0)} FATAL, "
                    f"{log_counts.get('error', 0)} ERROR"
                )
            elif log_counts.get("error", 0) > 0:
                briefing_parts.append(
                    f"- Log counts: {log_counts.get('error', 0)} ERROR"
                )
            # Flag when all steps succeeded but job is still FAILED
            if any_step_success and not summary.get("errors"):
                briefing_parts.append(
                    "- Application step(s) succeeded with 0 errors but job is "
                    "FAILED — likely evt_max partial processing or merge step "
                    "failure. Check DIRAC.log and the job spec for evt_max."
                )
            if len(briefing_parts) == 3:
                # No useful triage data
                briefing_parts.append("- No failure diagnostics available yet")
            briefing_parts.append(
                "\nYour tools: `get_ci_job_info`, `get_ci_job_logs`, "
                "`grep_ci_job_log`, `list_application_versions`, "
                "`report_finding`. "
                "Start by calling `get_ci_job_info`, then read the logs "
                "with `get_ci_job_logs`."
            )

            initial_message = HumanMessage(
                content="\n".join(briefing_parts),
                name="fan_out",
            )
            sends.append(
                Send(
                    "investigate_job",
                    {
                        "messages": [initial_message],
                        "pipeline_id": state.get("pipeline_id"),
                        "ci_run_name": cluster["ci_run_name"],
                        "job_name": cluster["representative_job"],
                        "affected_jobs": cluster["job_names"],
                        "job_findings": [],
                    },
                )
            )

        return sends

    # --- Synthesize phase (draft review body, no posting) ---

    def _build_findings_text(findings: list[JobFinding]) -> str:
        """Format job findings for prompts."""
        if not findings:
            return "No job-level findings were produced. Check the validation report."
        parts = []
        for i, f in enumerate(findings, 1):
            affected = ", ".join(f["affected_jobs"][:5])
            if len(f["affected_jobs"]) > 5:
                affected += f" (and {len(f['affected_jobs']) - 5} more)"
            evidence_block = ""
            if f.get("evidence"):
                evidence_block = f"- **Evidence**:\n```\n{f['evidence'][:3000]}\n```\n"
            code_context_block = ""
            if f.get("code_context"):
                code_context_block = (
                    f"- **Code context** (from knowledge graph):\n"
                    f"{f['code_context'][:2000]}\n"
                )
            parts.append(
                f"### Finding {i}: {f['job_name']}\n"
                f"- **Severity**: {f['severity']}\n"
                f"- **Root cause**: {f['root_cause']}\n"
                f"- **Affected jobs**: {affected}\n"
                f"- **Diagnosis**: {f['diagnosis']}\n"
                f"{evidence_block}"
                f"{code_context_block}"
            )
        return "\n".join(parts)

    synthesizer_llm = orchestrator_llm.bind_tools(synthesizer_tools)

    def synthesize_agent(state: MultiAgentCIDebugState):
        """Synthesize findings into a review body draft (no posting)."""
        findings = state.get("job_findings", [])
        logger.info(
            "Synthesizer received %d finding(s): %s",
            len(findings),
            [f.get("root_cause", "?")[:80] for f in findings] if findings else "none",
        )
        findings_text = _build_findings_text(findings)

        # Filter messages: only keep the synthesizer's own conversation.
        # Drop triage/investigator messages — their findings are already in
        # the system prompt via findings_text. Keeping triage ToolMessages
        # causes the model to latch onto triage patterns and ignore findings.
        synth_tool_call_ids = set()
        synth_messages = []
        for m in state["messages"]:
            if isinstance(m, HumanMessage) and not synth_messages:
                # Keep only the first human message (the task)
                synth_messages.append(m)
            elif hasattr(m, "name") and m.name == "synthesizer":
                # Keep synthesizer's own AI messages
                synth_messages.append(m)
                # Track tool_call IDs so we can keep their results
                if hasattr(m, "tool_calls") and m.tool_calls:
                    for tc in m.tool_calls:
                        synth_tool_call_ids.add(tc.get("id", ""))
            elif isinstance(m, ToolMessage) and m.tool_call_id in synth_tool_call_ids:
                # Keep only tool results for the synthesizer's own tool calls
                synth_messages.append(m)

        messages = CI_SYNTHESIZER_PROMPT.format_messages(
            messages=synth_messages,
            findings_text=findings_text,
            pipeline_id=state.get("pipeline_id", "?"),
            ci_run_name=state.get("ci_run_name", "?"),
            head_sha_short="(see get_mr_info)",
        )
        messages = trim_messages_for_context(messages, max_tokens=token_budget)
        try:
            response = synthesizer_llm.invoke(messages)
        except BadRequestError as exc:
            logger.error("Synthesizer LLM request failed: %s", exc)
            return {
                "messages": [
                    AIMessage(
                        content="Synthesizer stopped: LLM request failed.",
                        name="synthesizer",
                    )
                ],
                "error": str(exc),
            }
        response.name = "synthesizer"
        return {"messages": [response]}

    synthesizer_tool_node = ToolNode(synthesizer_tools)

    async def synthesize_tools_node(state: MultiAgentCIDebugState):
        result = await synthesizer_tool_node.ainvoke(state)
        result["messages"] = cap_tool_message_content(result["messages"])
        return result

    def synthesize_should_continue(state: MultiAgentCIDebugState):
        if state.get("error"):
            return "save_review_body"
        last = state["messages"][-1]
        if not hasattr(last, "tool_calls") or not last.tool_calls:
            return "save_review_body"
        return "synthesize_tools"

    def save_review_body(state: MultiAgentCIDebugState):
        """Extract review body text from the synthesizer's last message."""
        for msg in reversed(state["messages"]):
            if hasattr(msg, "name") and msg.name == "synthesizer":
                if hasattr(msg, "content") and msg.content:
                    return {"review_body": msg.content}
                break
        return {"review_body": None}

    # --- Code review phase (runs after synthesis, gets full context) ---

    def merge_code_review(state: MultiAgentCIDebugState):
        """Append code review summary to the review body so inline findings
        are visible in the main review text, not just as disconnected comments."""
        comments = state.get("code_review_comments", [])
        review_body = state.get("review_body", "")
        if not comments or not review_body:
            return {}

        lines = ["\n\n### Code Review Issues\n"]
        for c in comments:
            path = c.get("file_path", c["file_path"])
            line = c.get("new_line", c["new_line"])
            body = c.get("body", c["body"])
            # Strip suggestion blocks for the review body — they're in inline comments
            summary = body.split("```suggestion")[0].strip()
            lines.append(f"- **`{path}:{line}`** — {summary}")

        return {"review_body": review_body + "\n".join(lines)}

    # --- Post review phase (posts review body + inline comments) ---
    #
    # Split into two steps following the v1 pattern:
    # 1. prepare_post_review: builds an AIMessage with a pending post_mr_review
    #    tool call (but does NOT execute it)
    # 2. execute_post_review: ToolNode that executes the pending tool call
    #
    # When write_names is set, human_review sits between these two steps and
    # interrupts with the pending_tool_calls — matching the v1 interrupt pattern.

    post_review_tool_node = ToolNode(post_review_tools)

    def prepare_post_review(state: MultiAgentCIDebugState):
        """Build a pending post_mr_review tool call without executing it.

        Adds an AIMessage with the tool call to state. The next node
        (human_review or execute_post_review) decides what happens.
        """
        review_body = state.get("review_body", "")
        if not review_body:
            return {
                "messages": [
                    AIMessage(content="No review body to post.", name="post_review")
                ]
            }

        inline_comments = [dict(c) for c in state.get("code_review_comments", [])]

        tool_call = {
            "name": "post_mr_review",
            "args": {
                "body": review_body,
            },
            "id": "post_review_call",
            "type": "tool_call",
        }
        if inline_comments:
            tool_call["args"]["inline_comments"] = inline_comments

        ai_msg = AIMessage(content="", tool_calls=[tool_call], name="post_review")
        return {"messages": [ai_msg]}

    async def execute_post_review(state: MultiAgentCIDebugState):
        """Execute the pending post_mr_review tool call via ToolNode."""
        result = await post_review_tool_node.ainvoke(state)
        return result

    # --- Build the graph ---

    # Compile the investigator subgraph
    investigator_graph = _build_investigator_subgraph(
        orchestrator_llm,
        investigator_tools,
        max_context_tokens=_INVESTIGATOR_MAX_TOKENS,
    )
    investigator_compiled = investigator_graph.compile()

    # Compile the code trace subgraph (coder LLM + RAG tools)
    code_trace_compiled = None
    if code_trace_tools and coder_llm:
        code_trace_graph = _build_code_trace_subgraph(
            coder_llm,
            code_trace_tools,
            max_context_tokens=_CODE_TRACE_MAX_TOKENS,
        )
        code_trace_compiled = code_trace_graph.compile()

    async def _run_code_trace(finding: JobFinding) -> str:
        """Run the code trace sub-agent on a single finding."""
        if not code_trace_compiled:
            return ""
        # Only trace findings with substantive evidence
        if not finding.get("evidence") or finding.get("root_cause", "").startswith(
            "Unable to determine"
        ):
            return ""
        try:
            result = await code_trace_compiled.ainvoke(
                {
                    "messages": [
                        HumanMessage(
                            content="Trace the error through the codebase.",
                            name="dispatch",
                        )
                    ],
                    "finding": dict(finding),
                    "pipeline_id": finding.get("pipeline_id"),
                },
                config={"recursion_limit": 20},
            )
            return result.get("code_context", "")
        except Exception:
            logger.exception("Code trace failed for %s", finding.get("job_name"))
            return ""

    async def investigate_job_wrapper(state: JobInvestigationState) -> dict:
        """Run investigator subgraph, then enrich findings with code trace.

        The investigator calls its own tools (get_ci_job_info, get_ci_job_logs,
        etc.) — we don't prefetch anything because context trimming could
        discard it before the LLM sees it.

        After investigation, the coder LLM traces the error through the
        knowledge graph to add cross-repo code context to findings.
        """
        job_name = state.get("job_name", "")

        result = await investigator_compiled.ainvoke(
            dict(state), config={"recursion_limit": 40}
        )
        findings = result.get("job_findings", [])

        # Enrich findings with code context from RAG
        enriched = []
        for finding in findings:
            code_context = await _run_code_trace(finding)
            enriched_finding = dict(finding)
            enriched_finding["code_context"] = code_context
            enriched.append(JobFinding(**enriched_finding))

        # Emit a summary message so the investigation is visible
        if enriched:
            f = enriched[0]
            parts = [f"**Investigation: {job_name}** [{f['severity']}]"]
            parts.append(f["root_cause"])
            if f.get("diagnosis") and f["diagnosis"] != f["root_cause"]:
                parts.append(f["diagnosis"][:1000])
            if f.get("code_context"):
                parts.append(f"\n**Code trace**: {f['code_context'][:500]}")
            summary = "\n".join(parts)
        else:
            summary = f"**Investigation: {job_name}** — no findings produced."
        return {
            "job_findings": enriched,
            "messages": [AIMessage(content=summary, name="job_investigator")],
        }

    # Compile the code review subgraph (prefer coder LLM if available)
    code_review_graph = _build_code_review_subgraph(
        coder_llm or orchestrator_llm,
        code_review_tools,
        max_context_tokens=_CODE_REVIEW_MAX_TOKENS,
    )
    code_review_compiled = code_review_graph.compile()

    async def review_code_wrapper(state: CodeReviewState) -> dict:
        """Run code review subgraph, returning only code_review_comments to parent."""
        logger.info("Code review sub-agent starting for MR !%s", state.get("mr_iid"))
        result = await code_review_compiled.ainvoke(
            dict(state), config={"recursion_limit": 30}
        )
        comments = result.get("code_review_comments", [])
        logger.info(
            "Code review sub-agent finished: %d comment(s) produced", len(comments)
        )
        if comments:
            summary_parts = [f"**Code review**: {len(comments)} issue(s) found.\n"]
            for c in comments:
                summary_parts.append(
                    f"- `{c['file_path']}:{c['new_line']}` — {c['body']}"
                )
            summary = "\n".join(summary_parts)
        else:
            summary = "**Code review**: no issues found in the merge request diff."
        return {
            "code_review_comments": comments,
            "messages": [AIMessage(content=summary, name="code_reviewer")],
        }

    graph = StateGraph(MultiAgentCIDebugState)

    # Triage phase
    graph.add_node("triage_agent", triage_agent)
    graph.add_node("triage_tools", triage_tools_node)
    graph.add_node("collect_job_info", collect_job_info)
    graph.add_node("cluster_jobs", cluster_jobs)

    # Investigation phase (sub-agents via Send, wrapped to isolate messages)
    graph.add_node("investigate_job", investigate_job_wrapper)

    # Synthesis phase (drafts review body, no posting)
    graph.add_node("synthesize_agent", synthesize_agent)
    graph.add_node("synthesize_tools", synthesize_tools_node)
    graph.add_node("save_review_body", save_review_body)

    # Code review phase (runs after synthesis with full context)
    graph.add_node("review_code", review_code_wrapper)
    graph.add_node("merge_code_review", merge_code_review)

    # Post review phase (prepare pending tool call, then execute)
    graph.add_node("prepare_post_review", prepare_post_review)
    graph.add_node("execute_post_review", execute_post_review)

    # Optional findings review
    review_findings_enabled = (config or {}).get("review_findings", False)

    # Entry
    graph.set_entry_point("triage_agent")

    # Triage edges
    graph.add_conditional_edges(
        "triage_agent",
        triage_should_continue,
        {
            "triage_tools": "triage_tools",
            "collect_job_info": "collect_job_info",
            END: END,
        },
    )
    graph.add_edge("triage_tools", "triage_agent")
    graph.add_edge("collect_job_info", "cluster_jobs")

    # Fan-out edge (investigation only — code review runs later)
    if review_findings_enabled:
        from langgraph.types import interrupt

        def review_findings_node(state: MultiAgentCIDebugState):
            """Pause for human review of investigation findings before synthesis."""
            findings = state.get("job_findings", [])
            findings_payload = [dict(f) for f in findings]
            decision = interrupt({"findings": findings_payload})
            if not decision.get("approved", True):
                feedback = decision.get("feedback", "")
                if feedback:
                    return {
                        "messages": [
                            HumanMessage(
                                content=(
                                    "The reviewer provided feedback on the findings:\n\n"
                                    f"{feedback}"
                                )
                            )
                        ]
                    }
            return {}

        graph.add_node("review_findings", review_findings_node)
        graph.add_conditional_edges(
            "cluster_jobs",
            fan_out,
            {"synthesize": "synthesize_agent"},
        )
        graph.add_edge("investigate_job", "review_findings")
        graph.add_edge("review_findings", "synthesize_agent")
    else:
        graph.add_conditional_edges(
            "cluster_jobs",
            fan_out,
            {"synthesize": "synthesize_agent"},
        )
        graph.add_edge("investigate_job", "synthesize_agent")

    # Synthesis edges (ReAct loop for get_mr_info, then save body)
    graph.add_conditional_edges(
        "synthesize_agent",
        synthesize_should_continue,
        {
            "synthesize_tools": "synthesize_tools",
            "save_review_body": "save_review_body",
        },
    )
    graph.add_edge("synthesize_tools", "synthesize_agent")

    # After saving review body → code review (if MR) or skip to post

    def route_after_synthesis(state: MultiAgentCIDebugState):
        """Route: dispatch code review via Send if MR exists, else post or end."""
        if not state.get("mr_iid"):
            # No MR — nothing to post
            return END
        if code_review_tools:
            findings = state.get("job_findings", [])
            findings_text = _build_findings_text(findings)
            review_body = state.get("review_body", "")

            context = (
                "Review the merge request code changes. Use the investigation "
                "findings and the synthesizer's draft review below to target "
                "your review — look for the code that caused these failures.\n\n"
                "## Investigation findings\n\n"
                f"{findings_text}\n\n"
                "## Synthesizer draft review\n\n"
                f"{review_body or '(no review body produced)'}\n\n"
                "Read the diff, find the bugs, and submit your inline comments."
            )
            logger.info("Dispatching code review for MR !%s", state.get("mr_iid"))
            return Send(
                "review_code",
                {
                    "messages": [HumanMessage(content=context, name="dispatch")],
                    "mr_iid": state.get("mr_iid"),
                    "pipeline_id": state.get("pipeline_id"),
                    "code_review_comments": [],
                },
            )
        return "prepare_post_review"

    graph.add_conditional_edges(
        "save_review_body",
        route_after_synthesis,
        {
            "review_code": "review_code",
            "prepare_post_review": "prepare_post_review",
            END: END,
        },
    )

    # Human review interrupt before posting (v1 pattern: interrupt on pending tool call)
    if write_names:
        from langgraph.types import interrupt

        def human_review_node(state: MultiAgentCIDebugState):
            """Pause for human approval before write operations.

            Interrupts with the pending post_mr_review tool call from the
            last AIMessage — matching the v1 pattern where the interrupt
            payload contains the actual tool call that will be executed.

            On approval: returns empty so the pending tool call executes.
            On rejection with feedback: strips the tool call and injects
            feedback so the synthesizer can revise.
            On rejection without feedback: stops the graph.
            """
            last = state["messages"][-1]
            review_payload = {
                "pending_tool_calls": [
                    tc for tc in last.tool_calls if tc["name"] in write_names
                ],
                "summary": last.content if hasattr(last, "content") else "",
            }
            decision = interrupt(review_payload)

            if decision.get("approved", False):
                return {"review_approved": True}

            feedback = decision.get("feedback", "")
            if not feedback:
                return {
                    "review_approved": False,
                    "messages": [
                        AIMessage(
                            content="Human reviewer rejected the review. Stopping."
                        )
                    ],
                }

            # Strip the rejected tool call, feed feedback back to synthesizer
            logger.info("Review rejected with feedback, returning to synthesizer")
            revised_last = AIMessage(
                content=last.content if hasattr(last, "content") else "",
            )
            return {
                "review_approved": False,
                "messages": [
                    revised_last,
                    HumanMessage(
                        content=(
                            "The human reviewer rejected the review and provided "
                            f"this feedback:\n\n{feedback}\n\n"
                            "Please revise the review based on this feedback."
                        )
                    ),
                ],
            }

        def after_human_review(state: MultiAgentCIDebugState):
            if state.get("review_approved", False):
                return "execute_post_review"
            last = state["messages"][-1]
            if isinstance(last, HumanMessage):
                return "synthesize_agent"
            return END

        graph.add_node("human_review", human_review_node)
        graph.add_edge("review_code", "merge_code_review")
        graph.add_edge("merge_code_review", "prepare_post_review")
        graph.add_edge("prepare_post_review", "human_review")
        graph.add_conditional_edges(
            "human_review",
            after_human_review,
            {
                "execute_post_review": "execute_post_review",
                "synthesize_agent": "synthesize_agent",
                END: END,
            },
        )
    else:
        graph.add_edge("review_code", "merge_code_review")
        graph.add_edge("merge_code_review", "prepare_post_review")
        graph.add_edge("prepare_post_review", "execute_post_review")

    graph.add_edge("execute_post_review", END)

    return graph
