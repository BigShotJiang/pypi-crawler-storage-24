###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""Stuck Production workflow — diagnoses a single stuck production.

Dispatched per-production by a Celery task that identifies stuck samples.
Investigates MaxReset failures, classifies root cause, and proposes
actions (GitLab issues, known failure patterns) subject to human review.
"""

from __future__ import annotations

import logging

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage
from langgraph.graph import END, StateGraph
from langgraph.prebuilt import ToolNode
from langgraph.types import interrupt
from openai import BadRequestError

from LbAgents.context import cap_tool_message_content, trim_messages_for_context
from LbAgents.prompts.templates import STUCK_PRODUCTIONS_PROMPT
from LbAgents.schemas.state import StuckProductionState

logger = logging.getLogger(__name__)

_DEFAULT_MAX_MESSAGE_TOKENS = 34_000


def build_ap_debug_stuck_productions_graph(
    orchestrator_llm: BaseChatModel,
    tools: list,
    write_tool_names: list[str] | None = None,
    config: dict | None = None,
    max_context_tokens: int | None = None,
) -> StateGraph:
    """Build an uncompiled StateGraph for single stuck production diagnosis.

    One instance is dispatched per stuck production by a Celery scanning task.
    Includes a human review interrupt before any write operations (e.g.
    adding known failures, creating GitLab issues).

    Args:
        orchestrator_llm: Primary LLM for analysis and triage.
        tools: List of tool objects (e.g. from MCP server discovery).
        write_tool_names: Names of tools that require human approval.
        config: Optional configuration dict.

    Returns:
        Uncompiled StateGraph. Caller must call .compile(checkpointer=...).
    """
    write_names = set(write_tool_names or [])
    llm_with_tools = orchestrator_llm.bind_tools(tools)
    token_budget = max_context_tokens or _DEFAULT_MAX_MESSAGE_TOKENS

    def agent_node(state: StuckProductionState):
        """Invoke the LLM with the production context."""
        messages = STUCK_PRODUCTIONS_PROMPT.format_messages(messages=state["messages"])
        messages = trim_messages_for_context(messages, max_tokens=token_budget)
        try:
            response = llm_with_tools.invoke(messages)
        except BadRequestError as exc:
            logger.error("LLM request failed: %s", exc)
            return {
                "messages": [AIMessage(content="Agent stopped: LLM request failed.")],
                "error": str(exc),
            }
        return {"messages": [response]}

    def should_continue(state: StuckProductionState):
        """Route to tools, human_review, or END."""
        if state.get("error"):
            return END
        last = state["messages"][-1]
        if not hasattr(last, "tool_calls") or not last.tool_calls:
            return END
        if write_names:
            for tc in last.tool_calls:
                if tc["name"] in write_names:
                    return "human_review"
        return "tools"

    def human_review_node(state: StuckProductionState):
        """Pause graph for human approval before write operations.

        Write operations include adding known failure patterns and
        creating/updating GitLab issues in the appropriate project.
        """
        last = state["messages"][-1]
        review_payload = {
            "pending_tool_calls": [
                tc for tc in last.tool_calls if tc["name"] in write_names
            ],
            "summary": last.content if hasattr(last, "content") else "",
        }
        decision = interrupt(review_payload)
        if not decision.get("approved", False):
            return {
                "messages": [
                    AIMessage(
                        content="Human reviewer rejected the proposed action. Stopping."
                    )
                ]
            }
        return {}

    tool_node = ToolNode(tools)

    async def capped_tools(state: StuckProductionState):
        """Run tools and cap oversized ToolMessage content."""
        result = await tool_node.ainvoke(state)
        result["messages"] = cap_tool_message_content(result["messages"])
        return result

    graph = StateGraph(StuckProductionState)
    graph.add_node("agent", agent_node)
    graph.add_node("tools", capped_tools)
    graph.add_node("human_review", human_review_node)

    graph.set_entry_point("agent")
    graph.add_conditional_edges(
        "agent",
        should_continue,
        {"tools": "tools", "human_review": "human_review", END: END},
    )
    graph.add_edge("tools", "agent")
    graph.add_edge("human_review", "agent")

    return graph
