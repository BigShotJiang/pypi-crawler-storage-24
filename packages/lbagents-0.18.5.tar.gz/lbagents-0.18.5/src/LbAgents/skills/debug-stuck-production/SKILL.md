---
name: debug-stuck-production
description: Diagnose and triage stuck LHCb Analysis Productions
version: "1.0"
tags: [lhcb, production, debugging, maxreset, analysis-productions]
tools:
  - get_sample_details
  - get_sample_progress
  - get_maxreset_files
  - get_grid_job_log_url
  - get_debugging_guide
  - explain_sample_state
  - get_production_repo_path
  - add_known_failure
---

# Debug a Stuck Production

## Context

Analysis Productions process ~24k samples/year across hundreds of physics analyses. Productions get "stuck" when jobs repeatedly fail (MaxReset), stall in Assigned state, or never transition from "new" to "active". The most common cause is high memory usage and leaks.

## Debugging workflow

1. **Get sample state**: Call `get_sample_details` and `get_sample_progress` to check the sample's current state and transformation-level file statuses.
2. **Investigate failures**: Focus on transformations with MaxReset > 0 (jobs keep failing, retries exhausted).
   - Call `get_maxreset_files` to get failed file details with task/job IDs.
   - Use `get_debugging_guide("maxreset")` for the detailed debugging procedure.
3. **Classify the problem**:
   - **Known pattern**: Memory errors, CVMFS failures, grid infrastructure issues — these have standard fixes.
   - **New/unknown pattern**: Unfamiliar crash, new error type — needs human attention and may warrant adding a new known failure reason via `add_known_failure`.
4. **Recommend action**: Propose a fix or a GitLab issue to create in the appropriate project (analysis repo, LHCbDIRAC, or the application project depending on root cause). All write actions require human approval first.

## Problem categories (by frequency)

1. **High memory usage / leaks** — #1 cause. Look for MemoryError, OOM kills, or prmon showing RSS exceeding limits. Reproducible locally with `lb-ap make-reproducer`.
2. **Performance issues** — Jobs timing out. Check exec_time vs wall time.
3. **Crashes and exceptions** — Segfaults, unhandled Python exceptions, Gaudi FATAL errors.
4. **Grid-related issues** — CVMFS mount failures, worker node problems, staging errors. Usually transient (RecoverableFailure or WorkerNodeIssue).

## Output

Present your findings as:
1. **Sample**: {{wg}}/{{analysis}}/{{name}} v{{version}} — include link to the website.
2. **Problem**: What was found (e.g. "47 files in MaxReset, MemoryError")
3. **Root cause**: Diagnosis with evidence
4. **Classification**: Known/new, severity, affected scope
5. **Recommended action**: Proposed fix or GitLab issue to create (subject to human review)
