from .base import BaseProvider
import briefcase_ai as bf

class AnthropicProvider(BaseProvider):
    def generate(self, prompt: str, **kwargs) -> str:
        # Mock Anthropic call
        
        decision = bf.Decision("anthropic_completion")
        decision.add_input(bf.Input("prompt", prompt, "string"))
        
        params = bf.ModelParameters(self.model_name)
        params.with_provider("anthropic")
        decision.with_model_parameters(params)
        
        response_text = f"[Anthropic Mock] Response to: {prompt[:20]}..."
        
        output = bf.Output("completion", response_text, "string")
        decision.add_output(output)
        
        return response_text
