from .base import BaseProvider
import briefcase_ai as bf

class LocalProvider(BaseProvider):
    def generate(self, prompt: str, **kwargs) -> str:
        decision = bf.Decision("local_completion")
        decision.add_input(bf.Input("prompt", prompt, "string"))
        
        params = bf.ModelParameters(self.model_name)
        params.with_provider("local-llama-cpp")
        decision.with_model_parameters(params)
        
        response_text = f"[Local Mock] Response to: {prompt[:20]}..."
        
        output = bf.Output("completion", response_text, "string")
        decision.add_output(output)
        
        return response_text
