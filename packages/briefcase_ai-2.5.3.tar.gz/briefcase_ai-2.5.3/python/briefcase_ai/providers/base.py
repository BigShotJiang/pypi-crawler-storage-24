from abc import ABC, abstractmethod
from typing import Any, Dict

class BaseProvider(ABC):
    """
    Abstract base class for LLM providers.
    Ensures consistent metadata extraction and decision tracking.
    """
    def __init__(self, model_name: str, **kwargs):
        self.model_name = model_name
        self.config = kwargs

    @abstractmethod
    def generate(self, prompt: str, **kwargs) -> Any:
        """
        Execute generation and return result.
        Must handle Briefcase decision capture internally.
        """
        pass
