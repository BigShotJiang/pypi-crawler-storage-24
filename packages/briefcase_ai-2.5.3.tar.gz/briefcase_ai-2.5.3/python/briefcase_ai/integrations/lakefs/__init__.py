"""Compatibility bridge: briefcase_ai.integrations.lakefs → briefcase.integrations.lakefs"""

from briefcase.integrations.lakefs import (
    versioned,
    versioned_context,
    lakefs_versioned,
    lakefs_context,
)
from briefcase.correlation import briefcase_workflow

__all__ = [
    "versioned",
    "versioned_context",
    "lakefs_versioned",
    "lakefs_context",
    "briefcase_workflow",
]
