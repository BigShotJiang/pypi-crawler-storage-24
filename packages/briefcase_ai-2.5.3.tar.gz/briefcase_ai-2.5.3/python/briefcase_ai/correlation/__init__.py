"""Compatibility bridge for ``briefcase_ai.correlation``."""

from briefcase_ai._compat import _bridge_module

_bridge_module(
    __name__,
    "briefcase.correlation",
    submodules=("workflow", "propagation"),
)
