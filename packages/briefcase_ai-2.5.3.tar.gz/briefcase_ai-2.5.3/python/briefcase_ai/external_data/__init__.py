"""Compatibility bridge for ``briefcase_ai.external_data``."""

from briefcase_ai._compat import _bridge_module

_bridge_module(__name__, "briefcase.external_data", submodules=("tracker",))
