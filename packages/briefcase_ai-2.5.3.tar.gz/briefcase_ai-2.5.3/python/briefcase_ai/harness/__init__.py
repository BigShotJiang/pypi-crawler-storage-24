from typing import List, Any, Callable, Optional
from .env import Environment
from .experiment import Experiment

def distributed_eval(
    task_fn: Callable, 
    data: List[Any], 
    models: Optional[List[str]] = None, 
    name: str = "distributed-eval",
    **kwargs
):
    """
    High-level entry point for running distributed evaluations.
    """
    exp = Experiment(
        name=name, 
        models=models or ["default"], 
        iterations=kwargs.get("iterations", 1)
    )
    return exp.run(dataset=data, task_fn=task_fn)

__all__ = ["Environment", "Experiment", "distributed_eval"]
