from typing import Dict, Any, Optional

class JobGenerator:
    """
    Factory for generating Neo-Cloud infrastructure templates.
    """
    @staticmethod
    def generate_akash_sdl(image: str, cpu: float = 1.0, memory: str = "1Gi") -> str:
        return f"""
version: "2.0"
services:
  briefcase-worker:
    image: {image}
    expose:
      - port: 8080
        as: 80
        to:
          - global: true
    params:
      storage:
        data:
          mount: /app/data
profiles:
  compute:
    briefcase-worker:
      resources:
        cpu:
          units: {cpu}
        memory:
          size: {memory}
"""

    @staticmethod
    def generate_modal_stub(name: str) -> str:
        return f"""
import modal
import briefcase_ai as bf

app = modal.App("{name}")

@app.function(gpu="A10G")
def run_task(item):
    bf.init(mode="performance")
    # Task logic here
    pass
"""
