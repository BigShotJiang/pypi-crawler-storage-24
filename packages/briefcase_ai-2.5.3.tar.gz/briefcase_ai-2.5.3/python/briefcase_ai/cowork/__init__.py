"""Compatibility bridge for ``briefcase_ai.cowork``."""

from briefcase_ai._compat import _bridge_module

_bridge_module(
    __name__,
    "briefcase.cowork",
    submodules=("receiver", "redaction", "correlation", "dashboards", "alerts"),
)
