from .registry import load

__all__ = ["load"]
