"""Core pack — registers generic RBAC and ABAC envs."""

from __future__ import annotations

from briefcase.guardrails.framework import _default_registry


def register_core_pack() -> None:
    """Register core guardrail envs (RBAC, ABAC) as generic building blocks."""
    _specs = _default_registry._specs

    if "rbac-v1" not in _specs:
        _default_registry.register(
            id="rbac-v1",
            entry_point="briefcase.guardrails.envs.rbac:RBACGuardrailEnv",
            description="Role-based access control with glob resource matching",
            tags=["core", "rbac"],
            max_eval_time_ms=0.5,
        )

    if "abac-v1" not in _specs:
        _default_registry.register(
            id="abac-v1",
            entry_point="briefcase.guardrails.envs.abac:ABACGuardrailEnv",
            description="Attribute-based access control with rule evaluation",
            tags=["core", "abac"],
            max_eval_time_ms=1.0,
        )
