"""Healthcare pack — registers HIPAA PHI guardrail envs."""

from __future__ import annotations

from briefcase.guardrails.framework import _default_registry


def register_healthcare_pack() -> None:
    """Register all healthcare guardrail envs."""
    _specs = _default_registry._specs

    if "hipaa-phi-v1" not in _specs:
        _default_registry.register(
            id="hipaa-phi-v1",
            entry_point="briefcase.guardrails.envs.phi:PHIGuardrailEnv",
            kwargs={"confidence_threshold": 0.85},
            description="HIPAA PHI access control (RBAC + confidence + tags)",
            tags=["healthcare", "phi", "hipaa"],
            max_eval_time_ms=5.0,
        )
