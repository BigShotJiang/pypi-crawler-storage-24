"""
Framework integration callback handlers for automatic decision capture.

Provides drop-in callbacks for popular AI frameworks:
  - LangChain: BriefcaseLangChainHandler
  - LlamaIndex: BriefcaseLlamaIndexHandler
  - OpenAI Agents SDK: OpenAIAgentsTracer, openai_agents_hook
  - PageIndex: PageIndexTracer, PageIndexMCPObserver
  - CrewAI: CrewAIEventListener
  - AG2 (community AutoGen fork): AG2HookTracer, ag2_hook
  - AutoGen v0.4+: AutoGenEventHandler, autogen_hook
"""

from briefcase.integrations.frameworks.langchain_handler import (
    BriefcaseLangChainHandler,
)
from briefcase.integrations.frameworks.llamaindex_handler import (
    BriefcaseLlamaIndexHandler,
)
from briefcase.integrations.frameworks import openai_agents_handler as openai_agents_hook
from briefcase.integrations.frameworks.openai_agents_handler import (
    OpenAIAgentsTracer,
)
from briefcase.integrations.frameworks.pageindex_handler import (
    PageIndexTracer,
)
from briefcase.integrations.frameworks.pageindex_mcp import (
    PageIndexMCPObserver,
)
from briefcase.integrations.frameworks.crewai_handler import (
    CrewAIEventListener,
)
from briefcase.integrations.frameworks import ag2_handler as ag2_hook
from briefcase.integrations.frameworks.ag2_handler import (
    AG2HookTracer,
)
from briefcase.integrations.frameworks import autogen_handler as autogen_hook
from briefcase.integrations.frameworks.autogen_handler import (
    AutoGenEventHandler,
)

__all__ = [
    "BriefcaseLangChainHandler",
    "BriefcaseLlamaIndexHandler",
    "OpenAIAgentsTracer",
    "openai_agents_hook",
    "PageIndexTracer",
    "PageIndexMCPObserver",
    "CrewAIEventListener",
    "AG2HookTracer",
    "ag2_hook",
    "AutoGenEventHandler",
    "autogen_hook",
]
