"""
Briefcase events  typed event records emitted by the SDK.
"""

from briefcase.events.types import BriefcaseEvent
from briefcase.events.webhook import WebhookEmitter
from briefcase.events.kafka import KafkaPublisher
from briefcase.events.emitter import emit, emit_low_confidence, emit_drift_detected

__all__ = [
    "BriefcaseEvent",
    "WebhookEmitter",
    "KafkaPublisher",
    "emit",
    "emit_low_confidence",
    "emit_drift_detected",
]
