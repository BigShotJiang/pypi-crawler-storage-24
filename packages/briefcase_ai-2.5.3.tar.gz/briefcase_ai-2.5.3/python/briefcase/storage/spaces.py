"""
DOSpacesStorage  DigitalOcean Spaces storage backend.

Extends S3ObjectLockStorage with the Spaces-specific endpoint URL pattern.
"""

from __future__ import annotations

from typing import Optional

from briefcase.storage.s3 import S3ObjectLockStorage


class DOSpacesStorage(S3ObjectLockStorage):
    """Store decision records in a DigitalOcean Spaces bucket.

    Inherits all behaviour from S3ObjectLockStorage; overrides only the
    endpoint URL to point at the Spaces regional endpoint.

    Args:
        bucket: Space (bucket) name.
        region_name: DO region slug (e.g. "nyc3", "ams3", "sgp1").
        retention_days: Retention period in days.
        access_key: Spaces access key.
        secret_key: Spaces secret key.
    """

    def __init__(
        self,
        bucket: str,
        region_name: str = "nyc3",
        retention_days: int = 2555,
        access_key: Optional[str] = None,
        secret_key: Optional[str] = None,
    ) -> None:
        endpoint_url = f"https://{region_name}.digitaloceanspaces.com"
        super().__init__(
            bucket=bucket,
            region=region_name,
            retention_days=retention_days,
            access_key=access_key,
            secret_key=secret_key,
            endpoint_url=endpoint_url,
        )
        self._endpoint_url = endpoint_url

    @property
    def endpoint_url(self) -> str:
        return self._endpoint_url
