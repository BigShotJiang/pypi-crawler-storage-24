"""
Briefcase Python-layer storage backends for decision audit records.
"""

from briefcase.storage.base import PythonStorageBackend, StorageReceipt
from briefcase.storage.s3 import S3ObjectLockStorage
from briefcase.storage.spaces import DOSpacesStorage

__all__ = [
    "PythonStorageBackend",
    "StorageReceipt",
    "S3ObjectLockStorage",
    "DOSpacesStorage",
]
