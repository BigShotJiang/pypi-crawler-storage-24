"""
Cowork integration  receives and processes OpenTelemetry events
exported by the Cowork coding agent.
"""

from briefcase.cowork.receiver import CoworkEventReceiver
from briefcase.cowork.redaction import CoworkRedactionFilter
from briefcase.cowork.correlation import PromptCorrelationEngine
from briefcase.cowork.dashboards import CoworkDashboards
from briefcase.cowork.alerts import CoworkAlertManager

__all__ = [
    "CoworkEventReceiver",
    "CoworkRedactionFilter",
    "PromptCorrelationEngine",
    "CoworkDashboards",
    "CoworkAlertManager",
]
