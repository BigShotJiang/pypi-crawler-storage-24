from typing import Any, List, Optional


class BriefcaseConfig:
    """Central configuration for Briefcase SDK extensions."""

    _instance: Optional["BriefcaseConfig"] = None

    def __init__(self):
        self.exporter: Optional[Any] = None
        self.router: Optional[Any] = None
        self.webhook_url: Optional[str] = None
        self.webhook_secret: Optional[str] = None
        self.subscribed_events: Optional[List[str]] = None
        self.event_bus: Optional[Any] = None
        self.storage: Optional[Any] = None
        self._guardrail_packs_loaded: List[str] = []

    @classmethod
    def get(cls) -> "BriefcaseConfig":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        cls._instance = None

    @property
    def guardrail_registry(self) -> Any:
        """Expose the global guardrail registry from framework.py."""
        from briefcase.guardrails.framework import _default_registry
        return _default_registry


def setup(
    exporter=None,
    router=None,
    webhook_url=None,
    webhook_secret=None,
    events=None,
    event_bus=None,
    storage=None,
    guardrail_packs: Optional[List[str]] = None,
) -> BriefcaseConfig:
    """Configure Briefcase SDK extensions.

    Does not interfere with briefcase_ai.init() for the Rust runtime.

    Args:
        guardrail_packs: List of pack names to register. Values: "core",
            "healthcare". Default: ["core"].
    """
    config = BriefcaseConfig.get()
    if exporter is not None:
        config.exporter = exporter
    if router is not None:
        config.router = router
    if webhook_url is not None:
        config.webhook_url = webhook_url
    if webhook_secret is not None:
        config.webhook_secret = webhook_secret
    if events is not None:
        config.subscribed_events = events
    if event_bus is not None:
        config.event_bus = event_bus
    if storage is not None:
        config.storage = storage

    # Register guardrail packs
    packs_to_load = guardrail_packs if guardrail_packs is not None else ["core"]
    _PACK_REGISTRY = {
        "core": "briefcase.guardrails.packs.core:register_core_pack",
        "healthcare": "briefcase.guardrails.packs.healthcare:register_healthcare_pack",
    }
    for pack_name in packs_to_load:
        if pack_name in config._guardrail_packs_loaded:
            continue
        entry = _PACK_REGISTRY.get(pack_name)
        if entry is not None:
            module_path, func_name = entry.rsplit(":", 1)
            import importlib
            module = importlib.import_module(module_path)
            register_fn = getattr(module, func_name)
            register_fn()
            config._guardrail_packs_loaded.append(pack_name)

    return config
