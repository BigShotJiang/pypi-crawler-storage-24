from __future__ import annotations

"""briefcase.vector  pluggable vector-search layer for Briefcase AI.

Lazy-imports the ``zvec`` backend so the module loads cleanly even when the
optional ``zvec`` package is not installed.  Check :data:`ZVEC_AVAILABLE`
before instantiating :class:`ZvecIndex`.

Example::

    from briefcase.vector import ZvecIndex, ZVEC_AVAILABLE

    if ZVEC_AVAILABLE:
        idx = ZvecIndex(path="/tmp/idx", dimension=384)
        idx.index("snap-001", embedding)
        results = idx.search(query_vec, topk=5)
"""

try:
    import zvec as _zvec_probe  # noqa: F401

    del _zvec_probe
    ZVEC_AVAILABLE = True
except ImportError:
    ZVEC_AVAILABLE = False

from briefcase.vector.base import SearchResult, VectorIndex, VectorIndexError
from briefcase.vector.zvec_backend import ZvecIndex

__all__ = [
    "VectorIndex",
    "ZvecIndex",
    "SearchResult",
    "VectorIndexError",
    "ZVEC_AVAILABLE",
]
