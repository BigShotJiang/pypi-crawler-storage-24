from setuptools import setup, find_packages

setup(
    name="fluidAI",
    version="1.0.0",
    author="discord @ fluid.dll",
    description="Luxury UI/UX Web Designer AI",
    packages=find_packages(),
    install_requires=[
        "groq>=0.3.0",
    ],
    python_requires='>=3.7',
)
