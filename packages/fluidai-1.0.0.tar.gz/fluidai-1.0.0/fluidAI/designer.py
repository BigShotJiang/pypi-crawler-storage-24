import os
import webbrowser
import time
import re
from groq import Groq

client = Groq(api_key="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")
MODEL_ADI = "llama-3.3-70b-versatile"

SYSTEM_PROMPT = """
Sen dünyanın en iyi UI/UX tasarımcısısın. Sadece saf HTML/Tailwind kodu üretirsin.
KURALLAR:
1. MUTLAKA Tailwind CSS CDN kullan (<script src="https://cdn.tailwindcss.com"></script>).
2. Tasarımda 'Dark Mode' hakim olmalı. Arka plan: bg-[#050505]. 
3. SARI RENK KESİNLİKLE YASAK. Mor, Indigo ve Koyu Gri tonları kullan.
4. Kartlar 'glassmorphism' olmalı: bg-white/5 backdrop-blur-lg border border-white/10 rounded-2xl.
5. KESİNLİKLE KONUŞMA. Sadece <html> ile başlayan kodu ver.
"""

def dosyayi_kaydet_ve_ac(ham_kod):
    folder = "AI_Tasarimlarim"
    os.makedirs(folder, exist_ok=True)
    match = re.search(r'<!DOCTYPE html>.*</html>', ham_kod, re.DOTALL | re.IGNORECASE)
    kod = match.group(0) if match else ham_kod.replace("```html", "").replace("```", "").strip()
    path = os.path.join(folder, "index.html")
    with open(path, "w", encoding="utf-8") as f:
        f.write(kod)
    webbrowser.open('file://' + os.path.realpath(path))

def start():
    history = [{"role": "system", "content": SYSTEM_PROMPT}]
    print("\n--- fluidAI Tasarım Motoru Aktif ---")
    while True:
        istek = input("Sen: ")
        if istek.lower() == 'exit': break
        history.append({"role": "user", "content": istek})
        try:
            completion = client.chat.completions.create(messages=history, model=MODEL_ADI, temperature=0.2)
            ai_kod = completion.choices[0].message.content
            history.append({"role": "assistant", "content": ai_kod})
            dosyayi_kaydet_ve_ac(ai_kod)
        except Exception as e:
            print(f"Hata: {e}")
