// ═══════════════════════════════════════════════════════
//  CVC Dashboard — Chat Module
//  (Compiled from ts/chat.ts — edit TypeScript source)
// ═══════════════════════════════════════════════════════
"use strict";

/** @type {{ role: string; content: string }[]} */
let chatHistory = [];
/** @type {boolean} */
let isStreaming = false;

function initChat() {
  const input = document.getElementById('chat-input');
  const sendBtn = document.getElementById('chat-send');

  // Auto-resize textarea
  input.addEventListener('input', () => {
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 200) + 'px';
  });

  // Ctrl+Enter to send
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      sendChatMessage();
    }
  });

  sendBtn.addEventListener('click', sendChatMessage);

  // Suggestion buttons
  document.querySelectorAll('.suggestion-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const msg = btn.dataset.msg;
      if (msg) {
        input.value = msg;
        sendChatMessage();
      }
    });
  });

  // Load current model tag
  loadChatModelTag();
}

async function loadChatModelTag() {
  try {
    const m = await CvcApi.getCurrentModel();
    const tag = document.getElementById('chat-model');
    if (tag) tag.textContent = m.model || m.provider || '—';
  } catch { /* ignore */ }
}

async function sendChatMessage() {
  if (isStreaming) return;
  const input = document.getElementById('chat-input');
  const text = input.value.trim();
  if (!text) return;

  input.value = '';
  input.style.height = 'auto';

  // Remove welcome screen
  const welcome = document.querySelector('.chat-welcome');
  if (welcome) welcome.remove();

  // Add user message
  const userMsg = { role: 'user', content: text };
  chatHistory.push(userMsg);
  appendChatMessage(userMsg);

  // Stream assistant response
  isStreaming = true;
  const assistantMsg = { role: 'assistant', content: '' };
  chatHistory.push(assistantMsg);
  const msgEl = appendChatMessage(assistantMsg, true);
  const contentEl = msgEl.querySelector('.msg-content');

  try {
    const stream = CvcApi.chatStream({
      messages: chatHistory.slice(0, -1),
      stream: true,
    });

    for await (const chunk of stream) {
      assistantMsg.content += chunk;
      renderChatMarkdown(contentEl, assistantMsg.content);
      scrollChatToBottom();
    }
  } catch (err) {
    assistantMsg.content = `_Error: ${err.message}_`;
  }

  // Remove streaming cursor
  const cursor = contentEl.querySelector('.streaming-indicator');
  if (cursor) cursor.remove();
  renderChatMarkdown(contentEl, assistantMsg.content);
  isStreaming = false;
  scrollChatToBottom();
}

/**
 * @param {{ role: string; content: string }} msg
 * @param {boolean} [streaming=false]
 * @returns {HTMLElement}
 */
function appendChatMessage(msg, streaming = false) {
  const container = document.getElementById('chat-messages');
  const el = document.createElement('div');
  el.className = 'chat-message';

  const isUser = msg.role === 'user';
  el.innerHTML = `
    <div class="chat-avatar ${isUser ? 'user' : 'assistant'}">${isUser ? 'U' : 'C'}</div>
    <div class="chat-message-body">
      <div class="role">${isUser ? 'You' : 'CVC Agent'}</div>
      <div class="msg-content">${streaming ? '<span class="streaming-indicator"></span>' : ''}</div>
    </div>
  `;

  if (!streaming && msg.content) {
    const contentEl = el.querySelector('.msg-content');
    renderChatMarkdown(contentEl, msg.content);
  }

  container.appendChild(el);
  scrollChatToBottom();
  return el;
}

/**
 * @param {HTMLElement} el
 * @param {string} text
 */
function renderChatMarkdown(el, text) {
  try {
    if (typeof marked !== 'undefined') {
      el.innerHTML = marked.parse(text);
    } else {
      el.textContent = text;
    }
  } catch {
    el.textContent = text;
  }
}

function scrollChatToBottom() {
  const container = document.getElementById('chat-messages');
  container.scrollTop = container.scrollHeight;
}

function clearChat() {
  chatHistory = [];
  const container = document.getElementById('chat-messages');
  container.innerHTML = '';
}
