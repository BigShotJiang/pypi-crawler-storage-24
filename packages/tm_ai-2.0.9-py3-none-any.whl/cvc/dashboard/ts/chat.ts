// ═══════════════════════════════════════════════════════
//  CVC Dashboard — Chat Module
// ═══════════════════════════════════════════════════════
import type { ChatMessage } from './types';
import * as api from './api';

declare const marked: { parse(md: string): string };

let chatHistory: ChatMessage[] = [];
let isStreaming = false;

export function initChat(): void {
  const input = document.getElementById('chat-input') as HTMLTextAreaElement;
  const sendBtn = document.getElementById('chat-send') as HTMLButtonElement;

  // Auto-resize textarea
  input.addEventListener('input', () => {
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 200) + 'px';
  });

  // Ctrl+Enter / Cmd+Enter to send
  input.addEventListener('keydown', (e: KeyboardEvent) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      sendMessage();
    }
  });

  sendBtn.addEventListener('click', sendMessage);

  // Suggestion buttons
  document.querySelectorAll('.suggestion-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const msg = (btn as HTMLElement).dataset.msg;
      if (msg) {
        input.value = msg;
        sendMessage();
      }
    });
  });

  // Load current model
  loadChatModel();
}

async function loadChatModel(): Promise<void> {
  try {
    const m = await api.getCurrentModel();
    const tag = document.getElementById('chat-model');
    if (tag) tag.textContent = m.model || m.provider || '—';
  } catch { /* ignore */ }
}

async function sendMessage(): Promise<void> {
  if (isStreaming) return;
  const input = document.getElementById('chat-input') as HTMLTextAreaElement;
  const text = input.value.trim();
  if (!text) return;

  input.value = '';
  input.style.height = 'auto';

  // Remove welcome screen
  const welcome = document.querySelector('.chat-welcome');
  if (welcome) welcome.remove();

  // Add user message
  const userMsg: ChatMessage = { role: 'user', content: text };
  chatHistory.push(userMsg);
  appendMessage(userMsg);

  // Stream assistant response
  isStreaming = true;
  const assistantMsg: ChatMessage = { role: 'assistant', content: '' };
  chatHistory.push(assistantMsg);
  const msgEl = appendMessage(assistantMsg, true);
  const contentEl = msgEl.querySelector('.msg-content') as HTMLElement;

  try {
    const stream = api.chatStream({
      messages: chatHistory.slice(0, -1), // send everything except the empty assistant slot
      stream: true,
    });

    for await (const chunk of stream) {
      assistantMsg.content += chunk;
      renderMarkdown(contentEl, assistantMsg.content);
      scrollToBottom();
    }
  } catch (err) {
    assistantMsg.content = `_Error: ${(err as Error).message}_`;
  }

  // Remove streaming cursor
  const cursor = contentEl.querySelector('.streaming-indicator');
  if (cursor) cursor.remove();
  renderMarkdown(contentEl, assistantMsg.content);
  isStreaming = false;
  scrollToBottom();
}

function appendMessage(msg: ChatMessage, streaming: boolean = false): HTMLElement {
  const container = document.getElementById('chat-messages')!;
  const el = document.createElement('div');
  el.className = 'chat-message';

  const isUser = msg.role === 'user';
  el.innerHTML = `
    <div class="chat-avatar ${isUser ? 'user' : 'assistant'}">${isUser ? 'U' : 'C'}</div>
    <div class="chat-message-body">
      <div class="role">${isUser ? 'You' : 'CVC Agent'}</div>
      <div class="msg-content">${streaming ? '<span class="streaming-indicator"></span>' : ''}</div>
    </div>
  `;

  if (!streaming && msg.content) {
    const contentEl = el.querySelector('.msg-content') as HTMLElement;
    renderMarkdown(contentEl, msg.content);
  }

  container.appendChild(el);
  scrollToBottom();
  return el;
}

function renderMarkdown(el: HTMLElement, text: string): void {
  try {
    if (typeof marked !== 'undefined') {
      el.innerHTML = marked.parse(text);
    } else {
      el.textContent = text;
    }
  } catch {
    el.textContent = text;
  }
}

function scrollToBottom(): void {
  const container = document.getElementById('chat-messages')!;
  container.scrollTop = container.scrollHeight;
}

export function clearChat(): void {
  chatHistory = [];
  const container = document.getElementById('chat-messages')!;
  container.innerHTML = '';
}
