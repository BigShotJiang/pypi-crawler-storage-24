"""
cvc.gateway — The CVC Gateway (Management Dashboard Server).

A FastAPI application that runs on ``http://127.0.0.1:17888`` and provides:

1. A web-based dashboard UI (Open WebUI-style) for managing all CVC features.
2. A management REST API for service lifecycle control.
3. An agent chat endpoint (streaming) — full CVC Agent in the browser.
4. Operations API: commit, branch, merge, restore, recall, diff, timeline.
5. Memory & context browsing.
6. Model catalog and provider switching.
7. Hive Mind / SDK multi-agent management.
8. Real-time event streaming via WebSocket.

The gateway manages the Proxy (port 19333) as a child service and
exposes analytics pulled from the shared ``.cvc/`` database.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.responses import FileResponse, StreamingResponse
from starlette.websockets import WebSocket, WebSocketDisconnect

logger = logging.getLogger("cvc.gateway")

# ---------------------------------------------------------------------------
# Module-level singletons (initialised in lifespan)
# ---------------------------------------------------------------------------

_manager = None        # GatewayManager
_db = None             # ContextDatabase
_config = None         # CVCConfig
_engine = None         # CVCEngine (for operations)
_event_bus = None      # EventBus
_health_task = None    # Background health poller
_project_root = None   # Discovered project root

_GATEWAY_PORT: int = int(os.environ.get("CVC_GATEWAY_PORT", "17888"))
_PROXY_PORT: int = int(os.environ.get("CVC_PROXY_PORT", "19333"))
_HOST: str = os.environ.get("CVC_GATEWAY_HOST", "127.0.0.1")


def _get_event_bus():
    global _event_bus
    if _event_bus is None:
        from cvc.sdk.events import EventBus
        _event_bus = EventBus()
    return _event_bus


async def _health_poll_loop():
    while True:
        try:
            if _manager:
                _manager.refresh_health()
        except Exception:
            logger.debug("Health poll error", exc_info=True)
        await asyncio.sleep(10)


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _manager, _db, _config, _engine, _health_task, _project_root

    from cvc.core.models import CVCConfig, discover_cvc_root
    from cvc.core.database import ContextDatabase
    from cvc.operations.engine import CVCEngine
    from cvc.gateway_manager import GatewayManager

    _project_root = discover_cvc_root()
    if _project_root is None:
        _project_root = Path.cwd()
    cvc_root = _project_root / ".cvc"
    cvc_root.mkdir(parents=True, exist_ok=True)

    _config = CVCConfig.for_project(project_root=_project_root, mode="gateway")
    _config.ensure_dirs()
    _db = ContextDatabase(_config)
    _engine = CVCEngine(_config, _db)
    _manager = GatewayManager(cvc_root, host=_HOST)

    proxy_port = int(os.environ.get("CVC_PROXY_PORT", "19333"))
    _manager.start_proxy(proxy_port)

    _health_task = asyncio.create_task(_health_poll_loop())
    logger.info("CVC Gateway started — http://%s:%d", _HOST, _GATEWAY_PORT)

    yield

    if _health_task:
        _health_task.cancel()
    if _db:
        _db.close()
    logger.info("CVC Gateway shut down.")


# ---------------------------------------------------------------------------
# FastAPI App
# ---------------------------------------------------------------------------

try:
    from cvc import __version__ as _cvc_version
except ImportError:
    _cvc_version = "2.0.0"

app = FastAPI(
    title="CVC Gateway",
    version=_cvc_version,
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


def _ensure(what="gateway"):
    if not _manager or not _db or not _config:
        raise HTTPException(status_code=503, detail=f"{what} not initialised yet")


# ═══════════════════════════════════════════════════════════════════════
# 1. HEALTH
# ═══════════════════════════════════════════════════════════════════════

@app.get("/health")
async def health():
    return {"status": "ok", "service": "cvc-gateway", "version": _cvc_version}


# ═══════════════════════════════════════════════════════════════════════
# 2. SERVICE MANAGEMENT
# ═══════════════════════════════════════════════════════════════════════

@app.get("/api/gateway/services")
async def get_services():
    _ensure()
    services = _manager.service_status()
    enriched = {}
    for svc in services:
        name = svc["name"]
        enriched[name] = svc
        enriched[name]["uptime"] = _manager.get_service(name).uptime_display
    if _db:
        try:
            agents = _db.index.list_agents() if hasattr(_db.index, "list_agents") else []
            enriched.get("sdk", {})["registered_agents"] = len(agents)
        except Exception:
            pass
        try:
            total = _db.index.count_commits() if hasattr(_db.index, "count_commits") else 0
            enriched.get("sdk", {})["total_commits"] = total
        except Exception:
            pass
    return enriched


@app.post("/api/gateway/services/{service_name}/{action}")
async def service_action(service_name: str, action: str):
    _ensure()
    if service_name == "proxy":
        port = _manager.get_service("proxy").port or _PROXY_PORT
        actions = {
            "start": lambda: _manager.start_proxy(port),
            "stop": lambda: _manager.stop_proxy(),
            "restart": lambda: _manager.restart_proxy(port),
            "pause": lambda: _manager.pause_proxy(),
            "resume": lambda: _manager.resume_proxy(),
        }
    else:
        raise HTTPException(400, f"Service '{service_name}' does not support lifecycle actions")
    if action not in actions:
        raise HTTPException(400, f"Unknown action '{action}'. Use: start, stop, restart, pause, resume")
    result = actions[action]()
    _get_event_bus().emit("service.action", {"service": service_name, "action": action, "status": result.status})
    return result.to_dict()


# ═══════════════════════════════════════════════════════════════════════
# 3. ANALYTICS & COMMITS
# ═══════════════════════════════════════════════════════════════════════

@app.get("/api/gateway/analytics")
async def get_analytics():
    _ensure()
    analytics: dict[str, Any] = {
        "commits": {"total": 0, "by_type": {}, "by_branch": {}},
        "branches": [],
        "tokens": {"total": 0, "estimated_cost_usd": 0.0},
        "recent_activity": [],
    }
    try:
        idx = _db.index
        commits = idx.all_commits() if hasattr(idx, "all_commits") else []
        analytics["commits"]["total"] = len(commits)
        by_type: dict[str, int] = {}
        for c in commits:
            ct = _field(c, "commit_type", "unknown")
            by_type[ct] = by_type.get(ct, 0) + 1
        analytics["commits"]["by_type"] = by_type

        branches = idx.list_branches() if hasattr(idx, "list_branches") else []
        analytics["branches"] = [
            {
                "name": b.name if hasattr(b, "name") else b.get("name", ""),
                "head": (b.head_hash if hasattr(b, "head_hash") else b.get("head_hash", ""))[:12],
                "status": b.status if hasattr(b, "status") else b.get("status", "active"),
            }
            for b in branches
        ]

        if hasattr(idx, "query_audit_log"):
            audit = idx.query_audit_log(limit=500)
            total_tokens = sum(e.get("token_count", 0) for e in audit if isinstance(e, dict))
            analytics["tokens"]["total"] = total_tokens
            analytics["tokens"]["estimated_cost_usd"] = round(total_tokens * 3.0 / 1_000_000, 4)

        recent = commits[-20:] if len(commits) > 20 else commits
        analytics["recent_activity"] = [
            {
                "hash": _field(c, "commit_hash", "")[:12],
                "type": _field(c, "commit_type", ""),
                "message": _field(c, "message", "")[:80],
                "agent_id": _meta(c, "agent_id", ""),
            }
            for c in recent
        ]
    except Exception:
        logger.debug("Analytics query error", exc_info=True)
    return analytics


@app.get("/api/gateway/commits")
async def get_commits(limit: int = 50, offset: int = 0, branch: str | None = None, agent_id: str | None = None):
    _ensure()
    try:
        commits = _db.index.all_commits() if hasattr(_db.index, "all_commits") else []
        commits = list(reversed(commits))
        if branch:
            commits = [c for c in commits if _meta(c, "branch") == branch]
        if agent_id:
            commits = [c for c in commits if _meta(c, "agent_id") == agent_id]
        total = len(commits)
        page = commits[offset:offset + limit]
        return {
            "total": total, "offset": offset, "limit": limit,
            "commits": [
                {
                    "hash": _field(c, "commit_hash", "")[:12],
                    "type": _field(c, "commit_type", ""),
                    "message": _field(c, "message", ""),
                    "created_at": _field(c, "created_at", 0),
                    "agent_id": _meta(c, "agent_id", ""),
                    "branch": _meta(c, "branch", ""),
                }
                for c in page
            ],
        }
    except Exception:
        logger.debug("Commits query error", exc_info=True)
        return {"total": 0, "offset": offset, "limit": limit, "commits": []}


# ═══════════════════════════════════════════════════════════════════════
# 4. OPERATIONS — commit, branch, merge, restore, recall, diff
# ═══════════════════════════════════════════════════════════════════════

@app.post("/api/ops/commit")
async def ops_commit(request: Request):
    _ensure("engine")
    body = await request.json()
    from cvc.core.models import CommitRequest
    req = CommitRequest(
        message=body.get("message", "Dashboard commit"),
        content=body.get("content", ""),
        commit_type=body.get("type", "checkpoint"),
        tags=body.get("tags", []),
    )
    result = _engine.commit(req)
    _get_event_bus().emit("commit.created", {"hash": result.commit_hash[:12], "message": req.message})
    return {"commit_hash": result.commit_hash[:12], "message": req.message, "status": "ok"}


@app.post("/api/ops/branch")
async def ops_branch(request: Request):
    _ensure("engine")
    body = await request.json()
    from cvc.core.models import BranchRequest
    req = BranchRequest(name=body["name"])
    result = _engine.branch(req)
    return {"branch": result.name, "head": result.head_hash[:12] if result.head_hash else "", "status": "ok"}


@app.post("/api/ops/merge")
async def ops_merge(request: Request):
    _ensure("engine")
    body = await request.json()
    from cvc.core.models import MergeRequest
    req = MergeRequest(source_branch=body["source_branch"], strategy=body.get("strategy", "semantic"))
    result = _engine.merge(req)
    return {"merge_commit": result.commit_hash[:12] if hasattr(result, "commit_hash") else "", "status": "ok"}


@app.post("/api/ops/restore")
async def ops_restore(request: Request):
    _ensure("engine")
    body = await request.json()
    from cvc.core.models import RestoreRequest
    req = RestoreRequest(commit_hash=body["hash"])
    _engine.restore(req)
    return {"restored_to": body["hash"], "status": "ok"}


@app.get("/api/ops/status")
async def ops_status():
    _ensure("engine")
    try:
        branches = _db.index.list_branches() if hasattr(_db.index, "list_branches") else []
        active = _config.default_branch
        head = ""
        for b in branches:
            name = b.name if hasattr(b, "name") else b.get("name", "")
            if name == active:
                head = (b.head_hash if hasattr(b, "head_hash") else b.get("head_hash", ""))[:12]
                break
        return {"branch": active, "head": head, "branches": len(branches), "cvc_root": str(_config.cvc_root)}
    except Exception as exc:
        return {"error": str(exc)}


@app.get("/api/ops/recall")
async def ops_recall(query: str, limit: int = 10):
    _ensure()
    try:
        if hasattr(_db, "semantic") and _db.semantic:
            results = _db.semantic.search(query, n_results=limit)
            return {"results": results, "total": len(results)}
        return {"results": [], "total": 0, "message": "Semantic store not available"}
    except Exception as exc:
        return {"results": [], "total": 0, "error": str(exc)}


@app.get("/api/ops/diff")
async def ops_diff(hash1: str, hash2: str):
    _ensure()
    try:
        idx = _db.index
        c1 = idx.get_commit(hash1) if hasattr(idx, "get_commit") else None
        c2 = idx.get_commit(hash2) if hasattr(idx, "get_commit") else None
        if not c1 or not c2:
            raise HTTPException(404, "One or both commits not found")
        return {
            "commit_a": {"hash": hash1, "message": _field(c1, "message", ""), "type": _field(c1, "commit_type", "")},
            "commit_b": {"hash": hash2, "message": _field(c2, "message", ""), "type": _field(c2, "commit_type", "")},
        }
    except HTTPException:
        raise
    except Exception as exc:
        return {"error": str(exc)}


@app.get("/api/ops/timeline")
async def ops_timeline(limit: int = 100):
    _ensure()
    try:
        commits = _db.index.all_commits() if hasattr(_db.index, "all_commits") else []
        commits = list(reversed(commits))[:limit]
        return {
            "timeline": [
                {
                    "hash": _field(c, "commit_hash", "")[:12],
                    "type": _field(c, "commit_type", ""),
                    "message": _field(c, "message", ""),
                    "created_at": _field(c, "created_at", 0),
                    "agent_id": _meta(c, "agent_id", ""),
                    "branch": _meta(c, "branch", ""),
                }
                for c in commits
            ]
        }
    except Exception as exc:
        return {"timeline": [], "error": str(exc)}


@app.get("/api/ops/branches")
async def ops_branches():
    _ensure()
    try:
        branches = _db.index.list_branches() if hasattr(_db.index, "list_branches") else []
        return {
            "branches": [
                {
                    "name": b.name if hasattr(b, "name") else b.get("name", ""),
                    "head": (b.head_hash if hasattr(b, "head_hash") else b.get("head_hash", ""))[:12],
                    "status": b.status if hasattr(b, "status") else b.get("status", "active"),
                }
                for b in branches
            ]
        }
    except Exception as exc:
        return {"branches": [], "error": str(exc)}


# ═══════════════════════════════════════════════════════════════════════
# 5. MEMORY & CONTEXT
# ═══════════════════════════════════════════════════════════════════════

@app.get("/api/memory/context")
async def get_context(limit: int = 50):
    _ensure()
    try:
        idx = _db.index
        messages = idx.get_context(limit=limit) if hasattr(idx, "get_context") else []
        return {
            "messages": [
                {"role": _field(m, "role", ""), "content": _field(m, "content", "")[:500], "timestamp": _field(m, "timestamp", 0)}
                for m in messages
            ],
            "total": len(messages),
        }
    except Exception as exc:
        return {"messages": [], "total": 0, "error": str(exc)}


@app.get("/api/memory/blobs")
async def get_blobs(limit: int = 20):
    _ensure()
    try:
        blobs_dir = _config.cvc_root / "objects"
        if not blobs_dir.exists():
            return {"blobs": [], "total": 0}
        blob_files = sorted(blobs_dir.glob("*"), key=lambda p: p.stat().st_mtime, reverse=True)[:limit]
        return {
            "blobs": [{"hash": f.name, "size_bytes": f.stat().st_size, "modified": f.stat().st_mtime} for f in blob_files],
            "total": len(list(blobs_dir.glob("*"))),
        }
    except Exception as exc:
        return {"blobs": [], "total": 0, "error": str(exc)}


@app.get("/api/memory/stats")
async def get_memory_stats():
    _ensure()
    try:
        db_path = _config.cvc_root / "cvc.db"
        blobs_dir = _config.cvc_root / "objects"
        return {
            "database_size_bytes": db_path.stat().st_size if db_path.exists() else 0,
            "blob_count": len(list(blobs_dir.glob("*"))) if blobs_dir.exists() else 0,
            "blob_total_bytes": sum(f.stat().st_size for f in blobs_dir.glob("*")) if blobs_dir.exists() else 0,
            "cvc_root": str(_config.cvc_root),
        }
    except Exception as exc:
        return {"error": str(exc)}


# ═══════════════════════════════════════════════════════════════════════
# 6. MODEL CATALOG & PROVIDER
# ═══════════════════════════════════════════════════════════════════════

@app.get("/api/models/catalog")
async def get_model_catalog():
    try:
        from cvc.adapters import PROVIDER_DEFAULTS
        catalog = {}
        for provider, defaults in PROVIDER_DEFAULTS.items():
            catalog[provider] = {
                "name": provider,
                "default_model": defaults.get("default_model", ""),
                "env_key": defaults.get("env_key", ""),
                "base_url": defaults.get("base_url", ""),
                "models": defaults.get("models", []),
            }
        return {
            "providers": catalog,
            "current_provider": _config.provider if _config else "",
            "current_model": _config.model if _config else "",
        }
    except Exception as exc:
        return {"providers": {}, "error": str(exc)}


@app.get("/api/models/current")
async def get_current_model():
    _ensure()
    from cvc.core.models import GlobalConfig as GC
    gc = GC.load()
    return {
        "provider": _config.provider,
        "model": _config.model,
        "api_key_set": bool(_config.api_key),
        "api_keys_stored": {k: bool(v) for k, v in gc.api_keys.items()},
    }


@app.post("/api/models/switch")
async def switch_model(request: Request):
    _ensure()
    body = await request.json()
    new_provider = body.get("provider", _config.provider)
    new_model = body.get("model", _config.model)
    from cvc.core.models import GlobalConfig as GC
    gc = GC.load()
    gc.provider = new_provider
    gc.model = new_model
    gc.save()
    _config.provider = new_provider
    _config.model = new_model
    return {"provider": new_provider, "model": new_model, "status": "ok"}


# ═══════════════════════════════════════════════════════════════════════
# 7. HIVE MIND / SDK
# ═══════════════════════════════════════════════════════════════════════

@app.get("/api/gateway/config")
async def get_config():
    _ensure()
    return {
        "provider": _config.provider,
        "model": _config.model,
        "agent_id": _config.agent_id,
        "default_branch": _config.default_branch,
        "proxy_port": _PROXY_PORT,
        "gateway_port": _GATEWAY_PORT,
        "host": _HOST,
        "api_key_set": bool(_config.api_key),
        "cvc_root": str(_config.cvc_root),
    }


@app.get("/api/gateway/hivemind/agents")
async def get_hivemind_agents():
    _ensure()
    try:
        agents = _db.index.list_agents() if hasattr(_db.index, "list_agents") else []
        return {"agents": [a if isinstance(a, dict) else a.__dict__ for a in agents], "total": len(agents)}
    except Exception:
        return {"agents": [], "total": 0}


@app.post("/api/hivemind/register")
async def register_agent(request: Request):
    _ensure()
    body = await request.json()
    try:
        agent_id = body["agent_id"]
        _db.index.register_agent(
            agent_id=agent_id,
            name=body.get("name", agent_id),
            role=body.get("role", "worker"),
            rank=body.get("rank", "private"),
            squad=body.get("squad", "alpha"),
        )
        return {"agent_id": agent_id, "status": "registered"}
    except Exception as exc:
        raise HTTPException(400, str(exc))


@app.delete("/api/hivemind/agents/{agent_id}")
async def remove_agent(agent_id: str):
    _ensure()
    try:
        if hasattr(_db.index, "delete_agent") and _db.index.delete_agent(agent_id):
            return {"agent_id": agent_id, "status": "removed"}
        raise HTTPException(404, f"Agent '{agent_id}' not found")
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(400, str(exc))


# ═══════════════════════════════════════════════════════════════════════
# 8. SESSIONS
# ═══════════════════════════════════════════════════════════════════════

@app.get("/api/sessions")
async def get_sessions():
    import httpx
    try:
        r = httpx.get(f"http://{_HOST}:{_PROXY_PORT}/cvc/sessions", timeout=5.0)
        return r.json()
    except Exception:
        return {"sessions": [], "error": "Proxy not reachable"}


# ═══════════════════════════════════════════════════════════════════════
# 9. AGENT CHAT (Streaming)
# ═══════════════════════════════════════════════════════════════════════

@app.post("/api/chat")
async def agent_chat(request: Request):
    import httpx
    body = await request.json()
    messages = body.get("messages", [])
    model = body.get("model", _config.model if _config else "")
    stream = body.get("stream", True)
    chat_body = {"model": model, "messages": messages, "stream": stream}
    proxy_url = f"http://{_HOST}:{_PROXY_PORT}/v1/chat/completions"

    if not stream:
        try:
            async with httpx.AsyncClient(timeout=120.0) as client:
                r = await client.post(proxy_url, json=chat_body)
                return r.json()
        except Exception as exc:
            raise HTTPException(502, f"Proxy error: {exc}")

    async def stream_generator():
        try:
            async with httpx.AsyncClient(timeout=120.0) as client:
                async with client.stream("POST", proxy_url, json=chat_body) as resp:
                    async for line in resp.aiter_lines():
                        if line:
                            yield line + "\n"
        except Exception as exc:
            yield f"data: {json.dumps({'error': str(exc)})}\n\n"

    return StreamingResponse(
        stream_generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.get("/api/chat/models")
async def chat_models():
    import httpx
    try:
        r = httpx.get(f"http://{_HOST}:{_PROXY_PORT}/v1/models", timeout=5.0)
        return r.json()
    except Exception:
        return {"data": [{"id": _config.model, "object": "model", "owned_by": _config.provider}] if _config else []}


# ═══════════════════════════════════════════════════════════════════════
# 10. MCP SERVER INFO
# ═══════════════════════════════════════════════════════════════════════

@app.get("/api/mcp/tools")
async def mcp_tools():
    try:
        from cvc.mcp_server import TOOL_DEFINITIONS
        return {"tools": TOOL_DEFINITIONS, "total": len(TOOL_DEFINITIONS)}
    except ImportError:
        tools = [
            "cvc_status", "cvc_commit", "cvc_branch", "cvc_merge", "cvc_restore",
            "cvc_log", "cvc_capture_context", "cvc_set_workspace", "cvc_get_context",
            "cvc_recall", "cvc_export", "cvc_inject", "cvc_diff", "cvc_stats",
            "cvc_compact", "cvc_timeline", "cvc_audit",
            "cvc_sync_push", "cvc_sync_pull", "cvc_sync_status",
            "cvc_register_agent", "cvc_agent_commit", "cvc_agent_recall",
            "cvc_list_agents", "cvc_agent_context", "cvc_hive_status",
        ]
        return {"tools": [{"name": t} for t in tools], "total": len(tools)}
    except Exception:
        return {"tools": [], "total": 0}


@app.get("/api/mcp/status")
async def mcp_status():
    return {
        "transport": "stdio",
        "status": "available",
        "tools_count": 26,
        "note": "MCP server runs as a subprocess launched by IDEs, not as a persistent service",
    }


# ═══════════════════════════════════════════════════════════════════════
# 11. GIT / VCS BRIDGE
# ═══════════════════════════════════════════════════════════════════════

@app.get("/api/vcs/status")
async def vcs_status():
    _ensure()
    try:
        git_dir = _project_root / ".git" if _project_root else None
        hooks_installed = False
        if git_dir and git_dir.exists():
            post_commit = git_dir / "hooks" / "post-commit"
            hooks_installed = post_commit.exists() and "cvc" in post_commit.read_text(encoding="utf-8", errors="ignore").lower() if post_commit.exists() else False
        return {"git_repo": bool(git_dir and git_dir.exists()), "hooks_installed": hooks_installed, "project_root": str(_project_root) if _project_root else ""}
    except Exception as exc:
        return {"error": str(exc)}


# ═══════════════════════════════════════════════════════════════════════
# 12. AUDIT & STATS
# ═══════════════════════════════════════════════════════════════════════

@app.get("/api/audit")
async def get_audit(limit: int = 100):
    _ensure()
    try:
        if hasattr(_db.index, "query_audit_log"):
            entries = _db.index.query_audit_log(limit=limit)
            return {"entries": entries, "total": len(entries)}
        return {"entries": [], "total": 0}
    except Exception as exc:
        return {"entries": [], "error": str(exc)}


@app.get("/api/stats")
async def get_stats():
    _ensure()
    try:
        commits = _db.index.all_commits() if hasattr(_db.index, "all_commits") else []
        branches = _db.index.list_branches() if hasattr(_db.index, "list_branches") else []
        agents = _db.index.list_agents() if hasattr(_db.index, "list_agents") else []
        by_type: dict[str, int] = {}
        total_tokens = 0
        for c in commits:
            ct = _field(c, "commit_type", "unknown")
            by_type[ct] = by_type.get(ct, 0) + 1
            total_tokens += _meta_dict(c).get("token_count", 0)
        db_path = _config.cvc_root / "cvc.db"
        blobs_dir = _config.cvc_root / "objects"
        return {
            "total_commits": len(commits), "total_branches": len(branches), "total_agents": len(agents),
            "commits_by_type": by_type, "total_tokens": total_tokens,
            "estimated_cost_usd": round(total_tokens * 3.0 / 1_000_000, 4),
            "database_size_bytes": db_path.stat().st_size if db_path.exists() else 0,
            "blob_count": len(list(blobs_dir.glob("*"))) if blobs_dir.exists() else 0,
        }
    except Exception as exc:
        return {"error": str(exc)}


# ═══════════════════════════════════════════════════════════════════════
# 13. CONNECTIONS
# ═══════════════════════════════════════════════════════════════════════

@app.get("/api/connections")
async def get_connections():
    base = f"http://{_HOST}:{_PROXY_PORT}"
    return {
        "proxy_url": f"{base}/v1",
        "api_key": "cvc",
        "tools": [
            {"name": "VS Code", "type": "ide", "method": "BYOK settings.json", "icon": "vscode"},
            {"name": "Cursor", "type": "ide", "method": "BYOK settings.json", "icon": "cursor"},
            {"name": "Antigravity", "type": "ide", "method": "MCP config", "icon": "antigravity"},
            {"name": "Windsurf", "type": "ide", "method": "MCP config", "icon": "windsurf"},
            {"name": "Claude Code", "type": "cli", "method": "ANTHROPIC_BASE_URL env", "icon": "claude"},
            {"name": "Aider", "type": "cli", "method": "OPENAI_API_BASE env", "icon": "aider"},
            {"name": "Codex CLI", "type": "cli", "method": "OPENAI_BASE_URL env", "icon": "codex"},
            {"name": "Gemini CLI", "type": "cli", "method": "CVC MCP", "icon": "gemini"},
            {"name": "Continue.dev", "type": "extension", "method": "config.json", "icon": "continue"},
            {"name": "Cline", "type": "extension", "method": "MCP or API endpoint", "icon": "cline"},
            {"name": "Open WebUI", "type": "web", "method": "OpenAI API endpoint", "icon": "openwebui"},
        ],
    }


# ═══════════════════════════════════════════════════════════════════════
# WEBSOCKET — Real-Time Dashboard Events
# ═══════════════════════════════════════════════════════════════════════

@app.websocket("/ws/dashboard")
async def ws_dashboard(websocket: WebSocket):
    await websocket.accept()
    bus = _get_event_bus()
    sub_id = f"dashboard-{id(websocket)}"
    sub = bus.subscribe(sub_id, replay=True)
    try:
        if _manager:
            await websocket.send_json({
                "event": "services.snapshot",
                "data": {s.name: s.to_dict() for s in _manager.all_services().values()},
                "timestamp": time.time(),
            })
        while sub.active:
            try:
                envelope = await asyncio.wait_for(sub.get(), timeout=10.0)
                await websocket.send_json({"event": envelope.event, "data": envelope.data, "timestamp": envelope.timestamp})
            except asyncio.TimeoutError:
                if _manager:
                    _manager.refresh_health()
                    await websocket.send_json({
                        "event": "services.snapshot",
                        "data": {s.name: s.to_dict() for s in _manager.all_services().values()},
                        "timestamp": time.time(),
                    })
    except WebSocketDisconnect:
        pass
    except Exception:
        logger.debug("Dashboard WebSocket error", exc_info=True)
    finally:
        bus.unsubscribe(sub_id)


# ═══════════════════════════════════════════════════════════════════════
# STATIC FILES — Dashboard SPA
# ═══════════════════════════════════════════════════════════════════════

_DASHBOARD_DIR = Path(__file__).parent / "dashboard" / "static"

if _DASHBOARD_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(_DASHBOARD_DIR)), name="dashboard-static")


@app.get("/", include_in_schema=False)
async def serve_dashboard():
    index_path = _DASHBOARD_DIR / "index.html"
    if index_path.exists():
        return FileResponse(str(index_path), media_type="text/html")
    return JSONResponse({"message": "CVC Gateway running.", "api": "/api/gateway/services"}, status_code=200)


# ═══════════════════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════════════════

def _field(obj: Any, key: str, default: Any = "") -> Any:
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


def _meta_dict(obj: Any) -> dict:
    raw = _field(obj, "metadata_json", "")
    if not raw:
        return {}
    try:
        return json.loads(raw) if isinstance(raw, str) else raw
    except (json.JSONDecodeError, TypeError):
        return {}


def _meta(obj: Any, key: str, default: Any = "") -> Any:
    return _meta_dict(obj).get(key, default)
