import numpy as np
WORKING_DISTANCE = 1.5  # meters



def step(env, *, objectId=None, **kwargs):
    """
    Places the robot’s currently held object onto a specified target object
    if it is within working distance.

    The skill interprets the provided `objectId` as the receptacle or surface
    on which the held object should be placed. It looks up the target in the
    current observation metadata, computes the 3D distance between the robot
    and the target, and fails if the target is farther than `WORKING_DISTANCE`.
    If close enough, the skill issues a `PutObject` action to the controller.
    On success, the environment’s `held_object` and related cached state are
    cleared to reflect that the robot is no longer carrying anything.

    Args:
        env: The simulation environment containing controller access, the
            robot’s pose, and object metadata.
        action (dict): Skill invocation containing:
            objectId (str): ID of the target receptacle or surface on which
                to place the held object.

    Returns:
        tuple: `(success, message)` where `success` indicates whether the
        placement succeeded, and `message` provides a descriptive status.
    """
        
    print("\n=== PutObjectSkill ===")

    obs= env.get_observation()
    obj_meta = next( (o for o in obs.metadata["objects"] if o["objectId"] == objectId), None)
    
    obj_pos = obj_meta["position"]
    
    # Euclidean distance in 3D between agent and object
    object_robot_distance = np.sqrt(
        (obj_pos["x"] - env.agent_pos["x"]) ** 2 +
        (obj_pos["y"] - env.agent_pos["y"]) ** 2 +
        (obj_pos["z"] - env.agent_pos["z"]) ** 2
    )

    if object_robot_distance >= WORKING_DISTANCE:
        return False, f"Object is too far ({object_robot_distance:.2f} m). Move closer before putting object down."
    
    
    event = env.controller.step("PutObject", objectId=objectId)

    if event.metadata.get("lastActionSuccess", False):
        # Update the floor JSON entry's position/rotation to match where the
        # object was actually placed, so it reloads at the correct location
        # on the next floor switch.
        if env.held_object is not None:
            held_id = env.held_object.get("id", "")
            placed_meta = next(
                (o for o in event.metadata["objects"] if o["objectId"] == held_id),
                None,
            )
            if placed_meta is not None:
                for lst in (env.cur_json.get("objects", []), env.cur_json.get("small_objects", [])):
                    for entry in lst:
                        if entry.get("id") == held_id:
                            entry["position"] = placed_meta["position"]
                            entry["rotation"] = placed_meta["rotation"]
                            break

        env.held_object = None
        env.held_object_cur_state = None
        env.recepted_objs = None
        return True, "PutObject succeeded."
    else:
        return False, event.metadata.get("errorMessage", "PutObject failed (not in reach or not visible).")