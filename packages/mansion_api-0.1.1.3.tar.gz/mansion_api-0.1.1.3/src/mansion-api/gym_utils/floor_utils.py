# mansion_gym/gym_utils/floor_utils.py

from .controller_utils import setup_scene
from .utils import find_object_with_parent, ground_distance_2d
from copy import deepcopy

def remove_object_from_floor(floor_json, obj_id):
    """
    Remove an object from floor_json, searching recursively in:
      - floor_json["objects"]
      - small_objects
      - any object's children
    Returns True if removed, False if not found.
    """

    # -------- Remove from top-level objects --------
    new_objs = []
    removed = False
    for obj in floor_json["objects"]:
        if obj["id"] == obj_id:
            removed = True
            continue

        # recursively clean children
        if "children" in obj:
            if remove_object_from_obj_children(obj, obj_id):
                removed = True

        new_objs.append(obj)

    floor_json["objects"] = new_objs

    # -------- Remove from small_objects (if present) --------
    if "small_objects" in floor_json:
        floor_json["small_objects"] = [
            o for o in floor_json["small_objects"] if o["id"] != obj_id
        ]

    return removed


def remove_object_from_obj_children(parent_obj, obj_id):
    """
    Recursively remove obj_id from parent_obj["children"].
    Returns True if removed.
    """
    if "children" not in parent_obj:
        return False

    new_children = []
    removed = False
    for child in parent_obj["children"]:
        if child["id"] == obj_id:
            removed = True
            continue

        # recurse deep
        if "children" in child:
            if remove_object_from_obj_children(child, obj_id):
                removed = True

        new_children.append(child)

    parent_obj["children"] = new_children
    return removed




def update_floor(env, target_floor):
    if target_floor < 1 or target_floor > env.max_floor:
        return False, f"[MansionGym] Cannot move to floor {target_floor}, out of bounds."
    
    # Capture position before switching floors
    prev_pos = deepcopy(env.agent_pos)
    
    elevator_stair_list = [
        door for door in env.get_observation().metadata["objects"]
        if "stair" in door["objectId"].lower() or "elevator" in door["objectId"].lower()
    ]
    
    if not elevator_stair_list:
        return True, "[MansionGym] No elevator/staircase found, cannot change floors."
    
    distance_to_nearest = min(
        ground_distance_2d(env.agent_pos, door["position"])
        for door in elevator_stair_list
    ) 
    
    if distance_to_nearest > 2.0:
        return False, f"[MansionGym] Too far from elevator/staircase ({distance_to_nearest:.2f} m). Move closer before changing floors."
    
    # Determine connector type BEFORE switching floors
    nearest_door_pre = min(
        elevator_stair_list,
        key=lambda item: ground_distance_2d(prev_pos, item["position"]),
    )
    connector_type = "stair" if "stair" in nearest_door_pre["objectId"].lower() else "elevator"

    # Save held object info before dropping, then remove from source floor JSON.
    # We do NOT add it to the target floor JSON — instead we use SpawnAsset
    # after the new scene loads, which avoids all parent/room reference issues
    # that cause JSON-injected small objects to silently not spawn.
    held_asset_id = None
    held_new_id = None
    if env.held_object is not None:
        env.controller.step("DropHandObject", forceAction=True)
        object_info = deepcopy(env.held_object)

        env.record_object_states()

        # Remove the object from the previous floor JSON
        remove_object_from_floor(env.floor_jsons[env.current_floor - 1], object_info["id"])

        # If the held object had receptacle objects, remove them from source floor
        if env.recepted_objs:
            for recept_obj in env.recepted_objs:
                obj_id = recept_obj["objectId"]
                remove_object_from_floor(env.floor_jsons[env.current_floor - 1], obj_id)

        # Build a clean id for the spawned object on the target floor
        _oid = object_info["id"]
        _base_name = _oid.split("|")[0] if "|" in _oid else (_oid.split(" (")[0] if " (" in _oid else _oid)
        held_asset_id = object_info.get("assetId")
        held_new_id = f"{_base_name} (F{target_floor}_carried)"
        # Update held_object with the new id so downstream code stays consistent
        object_info["id"] = held_new_id
        env.held_object = object_info

    env.current_floor = target_floor

    setup_scene(env, change_floor=True)

    # Update the recorded object states after floor change
    update_recorded_object_states(env, env.saved_object_states[env.current_floor], recepted_related=False)

    # Re-spawn and re-pickup the held object using SpawnAsset so we don't depend
    # on the floor JSON having a valid parent/room for the small object.
    if held_asset_id is not None and held_new_id is not None:
        # Spawn underground (y-20) to avoid physics interference before pickup
        agent_init = env.floor_jsons[env.current_floor - 1]["metadata"]["agent"]["position"]
        spawn_event = env.controller.step(
            action="SpawnAsset",
            assetId=held_asset_id,
            generatedId=held_new_id,
            position={"x": agent_init["x"], "y": agent_init["y"] - 20, "z": agent_init["z"]},
            rotation={"x": 0, "y": 0, "z": 0},
            renderImage=False,
        )
        print(f"[MansionGym] SpawnAsset '{held_asset_id}' as '{held_new_id}' success={spawn_event.metadata.get('lastActionSuccess')} error='{spawn_event.metadata.get('errorMessage','')}'")

        # Register the dynamically spawned object in the floor JSON so that
        # find_object_with_parent can locate it if the object is dropped and
        # re-picked up on this floor (e.g. by ManipulateDoorSkill's auto-drop).
        _carried_entry = {
            "assetId": held_asset_id,
            "id": held_new_id,
            "kinematic": True,
            "position": {"x": agent_init["x"], "y": agent_init["y"] - 0.8, "z": agent_init["z"]},
            "rotation": {"x": 0, "y": 0, "z": 0},
            "material": None,
            "roomId": "",
        }
        env.cur_json["objects"].append(_carried_entry)
        if "small_objects" in env.cur_json:
            env.cur_json["small_objects"].append(_carried_entry)

        pickup_event = env.controller.step(
            action="PickupObject",
            objectId=held_new_id,
            forceAction=True,
        )
        print(f"[MansionGym] Re-pickup success={pickup_event.metadata.get('lastActionSuccess')} error='{pickup_event.metadata.get('errorMessage','')[:120]}'")
        if not pickup_event.metadata.get("lastActionSuccess"):
            env.held_object = None


    elevator_stair_list = [
        door for door in env.get_observation().metadata["objects"]
        if "stair" in door["objectId"].lower() or "elevator" in door["objectId"].lower()
    ]

    nearest_door = min(
        elevator_stair_list,
        key=lambda item: ground_distance_2d(prev_pos, item["position"]),
    )

    if connector_type == "elevator":
        # Use elevator landmark center (reference behavior)
        elevator_landmark_name = f"F{env.current_floor}_elevator"
        if elevator_landmark_name in env.landmarks:
            print(f"[MansionGym] Teleporting to elevator landmark center: {elevator_landmark_name}")
            position_x = env.landmarks[elevator_landmark_name]["x"]
            position_z = env.landmarks[elevator_landmark_name]["z"]
        else:
            position_x = prev_pos["x"]
            position_z = prev_pos["z"]

        # Face toward nearest door center
        door_center = nearest_door["axisAlignedBoundingBox"]["center"]
        dx = door_center["x"] - position_x
        dz = door_center["z"] - position_z
        if abs(dx) >= abs(dz):
            rotation_y = 90.0 if dx > 0 else 270.0
        else:
            rotation_y = 0.0 if dz > 0 else 180.0

    else:
        # Stair: spawn 0.5m outside the doorframe, in the corridor direction.
        # "Outside" = from stair room center through doorframe and beyond.
        connector_room = f"F{env.current_floor}_stair"
        objects_by_id = {o["objectId"]: o for o in env.get_observation().metadata["objects"]}

        spawn_door_obj = None
        for (rA, rB), door_ids in env.edge_doors.items():
            if connector_room not in (rA, rB):
                continue
            for did in door_ids:
                obj = objects_by_id.get(did)
                if obj is not None:
                    spawn_door_obj = obj
                    break
            if spawn_door_obj is not None:
                break

        if spawn_door_obj is not None:
            door_center = spawn_door_obj["axisAlignedBoundingBox"]["center"]
            frame_x, frame_z = door_center["x"], door_center["z"]

            # Direction: stair room center → doorframe (this is the "outward" direction)
            stair_center = env.landmarks.get(connector_room, {"x": frame_x, "z": frame_z})
            dx = frame_x - stair_center["x"]
            dz = frame_z - stair_center["z"]
            dist = (dx ** 2 + dz ** 2) ** 0.5
            if dist > 0:
                nx, nz = dx / dist, dz / dist
            else:
                nx, nz = 0.0, 0.0

            position_x = frame_x + 0.5 * nx
            position_z = frame_z + 0.5 * nz
            print(f"[MansionGym] stair transition: spawning 0.5m outside doorframe ({position_x:.2f}, {position_z:.2f})")
        else:
            # Fallback: stair landmark center
            stair_center = env.landmarks.get(connector_room, {"x": prev_pos["x"], "z": prev_pos["z"]})
            position_x = stair_center["x"]
            position_z = stair_center["z"]
            print(f"[MansionGym] stair transition: no doorframe found, using landmark ({position_x:.2f}, {position_z:.2f})")
            dx = nearest_door["axisAlignedBoundingBox"]["center"]["x"] - position_x
            dz = nearest_door["axisAlignedBoundingBox"]["center"]["z"] - position_z

        if abs(dx) >= abs(dz):
            rotation_y = 90.0 if dx > 0 else 270.0
        else:
            rotation_y = 0.0 if dz > 0 else 180.0

    env.controller.step(
        action="Teleport",
        position={
            "x": round(position_x, 2),
            "y": round(env.init_info["position"]["y"], 2),
            "z": round(position_z, 2),
        },
        rotation={"x": 0.0, "y": rotation_y, "z": 0.0},
        forceAction=True,
    )

    return True, f"[MansionGym] Moved to floor {env.current_floor}."


def update_recorded_object_states(env, saved_states, recepted_related= False):
        """
        Apply previously recorded object states to AI2-THOR scene.
        (Currently simplified — can be extended.)
        """

        # If nothing changed on this floor, skip
        if not saved_states:
            return

        if recepted_related:
            env.controller.step("DropHandObject", forceAction=True)
        else:
            # Set up object pos and rot
            env.controller.step(
                action='SetObjectPoses',
                objectPoses=[{"objectName": obj["name"], "rotation": obj['rotation'],
                            "position": obj['position']} for obj in saved_states],)
        
        for obj in saved_states:
            
            if not obj["moveable"] and not obj['pickupable']:
                continue
            
            if recepted_related:
                env.controller.step("PickupObject", objectId=obj["objectId"], forceAction=True)
                env.controller.step("PutObject", objectId=env.held_object["id"], forceAction=True)
            
            
            if obj['toggleable']:
                if obj["isToggled"]:
                    env.controller.step(action="ToggleObjectOn", objectId=obj["objectId"], forceAction=True)
                else:
                    env.controller.step(action="ToggleObjectOff", objectId=obj["objectId"], forceAction=True)
                    
            if obj['breakable'] and obj["isBroken"]:
                    env.controller.step(action="BreakObject", objectId=obj["objectId"], forceAction=True)
            
            if obj["canFillWithLiquid"]:
                if obj["isFilledWithLiquid"]:
                    env.controller.step(action="FillObjectWithLiquid", objectId=obj["objectId"], fillLiquid=obj["fillLiquid"], forceAction=True)
                else:
                    env.controller.step(action="EmptyLiquidFromObject", objectId=obj["objectId"], forceAction=True)
            
            if obj['dirtyable']:
                if obj["isDirty"]:
                    env.controller.step(action="DirtyObject", objectId=obj["objectId"], forceAction=True)
                else:
                    env.controller.step(action="CleanObject", objectId=obj["objectId"], forceAction=True)
            
            if obj['canBeUsedUp'] and obj["isUsedUp"]:
                    env.controller.step(action="UseUpObject", objectId=obj["objectId"], forceAction=True)
            
            if obj['cookable'] and obj["isCooked"]:
                    env.controller.step(action="CookObject", objectId=obj["objectId"], forceAction=True)
            
            if obj['sliceable'] and obj["isSliced"]:
                    env.controller.step(action="SliceObject", objectId=obj["objectId"], forceAction=True)
            
            
            if obj['openable']:
                if obj["isOpen"]:
                    env.controller.step(action="OpenObject", objectId=obj["objectId"], openness=obj["openness"], forceAction=True)
                else:
                    env.controller.step(action="CloseObject", objectId=obj["objectId"], forceAction=True)
        