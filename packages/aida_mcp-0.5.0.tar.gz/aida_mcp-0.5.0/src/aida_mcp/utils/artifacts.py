# Copyright (C) 2026 GoodData Corporation

"""Artifact/log output locations for AIDA (AI Developer Assistant).

The MCP tools should not write artifacts into the repository workspace by default.
Instead, they should use a user cache directory that works across Linux + macOS.
"""

from __future__ import annotations

import os
import platform
from pathlib import Path


def get_artifacts_root() -> Path:
    """Return the root directory for AIDA artifacts.

    Resolution order:
    1) AIDA_ARTIFACTS_DIR (absolute or user-relative path)
    2) XDG_CACHE_HOME/aida
    3) macOS: ~/Library/Caches/aida
    4) fallback: ~/.cache/aida
    """

    override = os.environ.get("AIDA_ARTIFACTS_DIR")
    if override:
        return Path(override).expanduser()

    xdg = os.environ.get("XDG_CACHE_HOME")
    if xdg:
        return Path(xdg).expanduser() / "aida"

    home = Path.home()
    if platform.system() == "Darwin":
        return home / "Library" / "Caches" / "aida"

    return home / ".cache" / "aida"
