# Copyright (C) 2026 GoodData Corporation

"""Compatibility facade for command runner utilities."""

from __future__ import annotations

from aida_mcp.utils.command_runner_execution import CommandResult, run_command, run_command_streaming
from aida_mcp.utils.command_runner_formatting import format_command_output
from aida_mcp.utils.command_runner_logs import (
    finalize_stream_log,
    open_streaming_log,
    write_command_log,
    write_stream_log_line,
)

__all__ = [
    "CommandResult",
    "finalize_stream_log",
    "format_command_output",
    "open_streaming_log",
    "run_command",
    "run_command_streaming",
    "write_command_log",
    "write_stream_log_line",
]
