# Copyright (C) 2026 GoodData Corporation

"""Path resolution utilities for workspace and project paths."""

from __future__ import annotations

from pathlib import Path


def resolve_path(path: str | Path, workspace_root: Path) -> Path:
    """
    Resolve a path relative to workspace root, or return absolute path as-is.

    This is a unified utility for resolving project paths. It handles:
    - Absolute paths: returns resolved absolute path
    - Relative paths: resolves relative to workspace_root

    Args:
        path: Path string or Path object (can be absolute or relative)
        workspace_root: Workspace root path (absolute)

    Returns:
        Resolved absolute Path

    Examples:
        resolve_path("services/example-service", workspace_root)
        resolve_path("/absolute/path", workspace_root)
    """
    candidate = Path(path)
    if candidate.is_absolute():
        return candidate.resolve()
    return (workspace_root / candidate).resolve()
