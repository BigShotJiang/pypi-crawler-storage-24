# Copyright (C) 2026 GoodData Corporation

"""Repo-local artifact discovery for the aida workflow.

In the final design, each repository owns its validation config + rules under:
- `.aida/validation_registry.yaml`
- `.aida/validation_policy.yaml`
- `.aida/change_domains.yaml`
- `.aida/git_policy.yaml`
- `.aida/rules/**/*.mdc`

The AIDA package (when moved to a separate repo) will use these helpers to locate
repo-provided artifacts deterministically.
"""

from __future__ import annotations

import os
from pathlib import Path

ENV_CONFIG_ROOT = "AIDA_CONFIG_ROOT"
DOT_AIDA = ".aida"


def get_repo_config_root(workspace_root: Path) -> Path:
    """Return the directory containing repo-local aida artifacts.

    Priority:
    1) `AIDA_CONFIG_ROOT` (absolute or relative-to-cwd)
    2) `<workspace_root>/.aida`
    """
    override = os.environ.get(ENV_CONFIG_ROOT)
    if isinstance(override, str) and override.strip():
        p = Path(override.strip()).expanduser()
        if not p.is_absolute():
            p = (Path.cwd() / p).resolve()
        return p
    return (workspace_root / DOT_AIDA).resolve()


def get_repo_rules_root(workspace_root: Path) -> Path:
    """Return the repo-local rules directory root (`.aida/rules`)."""
    return get_repo_config_root(workspace_root) / "rules"
