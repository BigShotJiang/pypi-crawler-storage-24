# Copyright (C) 2026 GoodData Corporation

"""Formatting helpers for command output summaries."""

from __future__ import annotations


def format_command_output(
    command: str,
    exit_code: int,
    stdout: str,
    stderr: str,
) -> str:
    result = [
        f"Command: {command}",
        f"Exit Code: {exit_code}",
        "",
    ]
    if exit_code == 0:
        result.append("✅ PASSED")
    else:
        result.append("❌ FAILED")
    if stdout.strip():
        result.extend(["", "=== Output ===", stdout.strip()])
    if stderr.strip():
        result.extend(["", "=== Errors ===", stderr.strip()])
    return "\n".join(result)
