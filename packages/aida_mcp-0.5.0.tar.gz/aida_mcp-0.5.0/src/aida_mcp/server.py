# Copyright (C) 2026 GoodData Corporation

"""Legacy stdio entrypoint.

The preferred entrypoint is `python -m aida_mcp.server` (package) which performs
explicit tool registration via `aida_mcp.server.registry.register_all`.
"""

from __future__ import annotations

from aida_mcp.server.app_instance import mcp
from aida_mcp.server.registry import register_all

register_all(mcp)

# ============================================================================
# SERVER STARTUP
# ============================================================================


# Start the server (stdio mode)
if __name__ == "__main__":
    # Note: Embeddings for rule retrieval are lazily initialized on first get_rules() call.
    # This allows the client to provide workspace_root and shows progress during initialization.
    mcp.run()
