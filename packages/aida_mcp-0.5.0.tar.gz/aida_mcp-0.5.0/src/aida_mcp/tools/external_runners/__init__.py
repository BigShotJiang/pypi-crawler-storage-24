# Copyright (C) 2026 GoodData Corporation

"""Self-external runner entrypoints.

These modules exist to *test* external execution mode while still in this repository.
They implement the external JSON runner contract (single JSON object on stdout).

When aida-mcp moves to a separate repository, equivalent runners can live in the
target repo (gdc-nas, gdc-ui, etc.) and be invoked via the validation registry.
"""
