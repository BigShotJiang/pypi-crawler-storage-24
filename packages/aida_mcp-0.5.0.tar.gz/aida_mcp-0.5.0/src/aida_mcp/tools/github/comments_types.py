# Copyright (C) 2026 GoodData Corporation

"""Types for GitHub PR review comment/thread operations."""

from __future__ import annotations

from typing import Literal, TypedDict


class ReplyResult(TypedDict):
    ok: bool
    repo: str
    pr_number: int
    in_reply_to: int
    reply_id: int
    reply_url: str


class ResolveResult(TypedDict):
    ok: bool
    repo: str
    pr_number: int
    thread_id: str
    resolved: bool


class ThreadComment(TypedDict):
    """A single comment within a review thread."""

    url: str
    author: str
    body: str
    created_at: str


class ReviewThread(TypedDict):
    """A review thread with full context (resolved or unresolved)."""

    thread_id: str
    is_resolved: bool
    path: str
    line: int | None
    diff_hunk: str
    comments: list[ThreadComment]
    comment_urls: list[str]  # Kept for backward compatibility


class ListThreadsResult(TypedDict):
    ok: bool
    repo: str
    pr_number: int
    threads: list[ReviewThread]


GithubCommentsAction = Literal["reply_to_review_comment", "resolve_review_thread", "list_review_threads"]
