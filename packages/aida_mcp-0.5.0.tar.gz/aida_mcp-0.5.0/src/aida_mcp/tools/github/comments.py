# Copyright (C) 2026 GoodData Corporation

"""PR review comment/thread management via GitHub API.

Supports:
- Replying in-thread to an inline PR review comment (NOT top-level PR conversation comments).
- Resolving the review thread ("Resolve conversation") containing a given review comment.
- Listing review threads for a PR.
"""

from __future__ import annotations

from aida_mcp.tools.github.comments_list import list_review_threads
from aida_mcp.tools.github.comments_reply import reply_to_review_comment
from aida_mcp.tools.github.comments_resolve import resolve_review_thread
from aida_mcp.tools.github.comments_types import (
    GithubCommentsAction,
    ListThreadsResult,
    ReplyResult,
    ResolveResult,
    ReviewThread,
    ThreadComment,
)
from aida_mcp.tools.github.comments_url import ensure_ai_reply_prefix, parse_review_comment_url

__all__ = [
    "GithubCommentsAction",
    "ListThreadsResult",
    "ReplyResult",
    "ResolveResult",
    "ReviewThread",
    "ThreadComment",
    "ensure_ai_reply_prefix",
    "parse_review_comment_url",
    "reply_to_review_comment",
    "resolve_review_thread",
    "list_review_threads",
]
