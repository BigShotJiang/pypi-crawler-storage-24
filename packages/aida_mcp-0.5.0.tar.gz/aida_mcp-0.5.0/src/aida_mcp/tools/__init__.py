# Copyright (C) 2026 GoodData Corporation

"""Validation tool implementations."""
