# Copyright (C) 2026 GoodData Corporation

"""Data model for validation command/processor registry."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from pathlib import Path


def _new_str_dict() -> dict[str, str]:
    return {}


@dataclass(frozen=True, slots=True)
class CommandSpec:
    argv: list[str]
    cwd: str | None = None
    env: dict[str, str] = field(default_factory=_new_str_dict)
    timeout_sec: int | None = None
    streaming: bool = True


@dataclass(frozen=True, slots=True)
class ProcessorSpec:
    kind: str
    builtin_id: str | None = None
    module: str | None = None
    argv: list[str] | None = None
    timeout_sec: int | None = None
    env: dict[str, str] = field(default_factory=_new_str_dict)


@dataclass(frozen=True, slots=True)
class ValidationRegistry:
    commands: Mapping[str, CommandSpec]
    processors: Mapping[str, ProcessorSpec]

    @classmethod
    def load(cls, config_path: Path | None = None) -> ValidationRegistry:
        from aida_mcp.tools.core.validation_registry_loader import load_validation_registry

        return load_validation_registry(config_path)
