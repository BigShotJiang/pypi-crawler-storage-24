# Copyright (C) 2026 GoodData Corporation

from __future__ import annotations

from collections.abc import Mapping, Sequence

type JsonScalar = str | int | float | bool | None
type JsonValue = JsonScalar | Sequence[JsonValue] | Mapping[str, JsonValue]
type JsonDict = dict[str, JsonValue]


def new_json_dict() -> JsonDict:
    return {}
