# Copyright (C) 2026 GoodData Corporation

"""Shared, strongly-typed validation result models.

This package owns the JSON-serializable result schema used by validate_* tools.
"""

from .builders import build_step_detail_from_command_result
from .models import ValidationResult, ValidationStepDetail
from .types import JsonDict, JsonScalar, JsonValue

__all__ = [
    "JsonScalar",
    "JsonValue",
    "JsonDict",
    "ValidationStepDetail",
    "ValidationResult",
    "build_step_detail_from_command_result",
]
