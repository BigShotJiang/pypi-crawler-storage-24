# Copyright (C) 2026 GoodData Corporation

"""Compatibility facade for validation registry models and loader."""

from __future__ import annotations

from pathlib import Path

from aida_mcp.tools.core.validation_registry_loader import (
    ENV_VALIDATION_REGISTRY_PATH,
    ENV_WORKSPACE_ROOT,
    default_registry_path,
    load_validation_registry,
)
from aida_mcp.tools.core.validation_registry_model import CommandSpec, ProcessorSpec, ValidationRegistry

_cached_registry: ValidationRegistry | None = None
_cached_registry_path: Path | None = None
_cached_registry_mtime: float | None = None


def get_validation_registry() -> ValidationRegistry:
    """Backward-compatible cache facade for callers/tests patching module globals."""

    global _cached_registry, _cached_registry_mtime, _cached_registry_path
    config_path = default_registry_path()
    try:
        mtime = config_path.stat().st_mtime if config_path.exists() else None
    except Exception:
        mtime = None
    if _cached_registry is None or _cached_registry_path != config_path or _cached_registry_mtime != mtime:
        _cached_registry = load_validation_registry(config_path=config_path)
        _cached_registry_path = config_path
        _cached_registry_mtime = mtime
    return _cached_registry


__all__ = [
    "CommandSpec",
    "ENV_VALIDATION_REGISTRY_PATH",
    "ENV_WORKSPACE_ROOT",
    "ProcessorSpec",
    "ValidationRegistry",
    "get_validation_registry",
]
