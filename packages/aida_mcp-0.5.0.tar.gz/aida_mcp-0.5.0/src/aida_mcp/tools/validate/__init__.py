# Copyright (C) 2026 GoodData Corporation

"""Unified validation engine (config-driven).

The MCP tool entrypoint lives in `aida_mcp.server.validation_tools.validate`.
This package will contain the routing/execution implementation.
"""
