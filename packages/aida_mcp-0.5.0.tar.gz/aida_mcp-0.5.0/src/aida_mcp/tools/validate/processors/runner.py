# Copyright (C) 2026 GoodData Corporation

"""Processor runner for unified validation.

Decouples command execution from output processing.

Processor contracts:
- builtin: runs in-process (Python function) and returns StepResult
"""

from __future__ import annotations

from aida_mcp.tools.core.validation_registry import ProcessorSpec
from aida_mcp.tools.validate.models import ExecutionResult, StepResult
from aida_mcp.tools.validate.processors.builtin import BUILTIN_PROCESSORS


async def run_processor(
    spec: ProcessorSpec,
    *,
    execution: ExecutionResult,
    processor_config: dict[str, object] | None = None,
) -> StepResult:
    cfg = processor_config or {}

    if spec.kind == "builtin":
        pid = spec.builtin_id or ""
        fn = BUILTIN_PROCESSORS.get(pid)
        if fn is None:
            return StepResult(
                success=False,
                text=f"Unknown builtin processor: {pid!r}",
                error_count=1,
                log_paths=[str(execution.log_path)] if execution.log_path is not None else [],
            )
        return fn(execution, cfg)

    return StepResult(
        success=False,
        text=f"Unsupported processor kind for unified validate: {spec.kind!r}",
        error_count=1,
        log_paths=[str(execution.log_path)] if execution.log_path is not None else [],
    )
