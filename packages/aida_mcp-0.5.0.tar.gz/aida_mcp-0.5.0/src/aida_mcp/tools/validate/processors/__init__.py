# Copyright (C) 2026 GoodData Corporation

"""Processor implementations for unified validation.

Processors normalize raw command outputs into a stable `StepResult` shape.
"""
