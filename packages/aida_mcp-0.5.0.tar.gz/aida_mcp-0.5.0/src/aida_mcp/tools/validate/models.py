# Copyright (C) 2026 GoodData Corporation

"""Models for unified validation execution + processing."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class ExecutionResult:
    argv: list[str]
    cwd: Path
    exit_code: int
    stdout: str
    stderr: str
    log_path: Path | None
    duration_sec: float | None = None

    def to_dict(self) -> dict[str, object]:
        return {
            "argv": self.argv,
            "cwd": str(self.cwd),
            "exit_code": self.exit_code,
            "stdout": self.stdout,
            "stderr": self.stderr,
            "log_path": str(self.log_path) if self.log_path is not None else None,
            "duration_sec": self.duration_sec,
        }


@dataclass(frozen=True, slots=True)
class StepResult:
    success: bool
    text: str
    error_count: int | None = None
    log_paths: list[str] | None = None
    meta: dict[str, object] | None = None
    did_autofix: bool | None = None
    modified_files: list[str] | None = None

    def to_dict(self) -> dict[str, object]:
        out: dict[str, object] = {"success": self.success, "text": self.text}
        if self.error_count is not None:
            out["error_count"] = self.error_count
        if self.log_paths is not None:
            out["log_paths"] = self.log_paths
        if self.meta is not None:
            out["meta"] = self.meta
        if self.did_autofix is not None:
            out["did_autofix"] = self.did_autofix
        if self.modified_files is not None:
            out["modified_files"] = self.modified_files
        return out


@dataclass(frozen=True, slots=True)
class ResolvedCommandSpec:
    command_id: str
    found: bool
    argv: list[str]
    cwd: Path
    env: dict[str, str]
    timeout_sec: int
    streaming: bool
    error: str | None = None

    def to_dict(self) -> dict[str, object]:
        return {
            "command_id": self.command_id,
            "found": self.found,
            "argv": self.argv,
            "cwd": str(self.cwd),
            "env": self.env,
            "timeout_sec": self.timeout_sec,
            "streaming": self.streaming,
            "error": self.error,
        }
