# Copyright (C) 2026 GoodData Corporation

"""Configuration constants for rule retrieval."""

# Default configuration
# RRF scores with k=5: BM25-only max ~0.17, hybrid max ~0.33
# Use 0.25 for production (filters marginally relevant rules)
# Tests without embeddings can pass lower threshold explicitly
DEFAULT_SCORE_THRESHOLD = 0.25
DEFAULT_TOP_K = 12  # Default for most queries
MIN_TOP_K = 5  # Minimum rules to return (if above threshold)
MAX_TOP_K = 20  # Maximum rules to return
SCORE_GAP_THRESHOLD = 0.30  # Stop if score drops by >30% from previous
HIGH_SCORE_THRESHOLD = 0.30  # Consider expansion if many rules above this
EXPANSION_TRIGGER_COUNT = 5  # Expand if this many rules above HIGH_SCORE_THRESHOLD
EXPANDED_TOP_K = 18  # Top-k when expansion is triggered

# Anti-spam: reduce false positives from generic word matching
PHRASE_MATCH_BOOST = 0.05  # Boost when query words appear together
MIN_EMBEDDING_SCORE = 0.15  # Minimum embedding score for multi-term queries (penalty threshold)
MIN_EMBEDDING_FOR_SINGLE_MATCH = 0.35  # Higher threshold for single-word matches (filter threshold)
MIN_EMBEDDING_FOR_GENERIC_PAIRS = 0.25  # Threshold for 2-word matches on generic words (changes, current, etc.)
EMBEDDING_PENALTY = 0.15  # Penalty if embedding score below minimum (applied to final score)
PHRASE_PROXIMITY = 5  # Words within this distance count as phrase match

# Best-effort fallback thresholds (for rules below main threshold)
FALLBACK_MIN_SCORE = 0.10  # Minimum RRF score for fallback rules
FALLBACK_MIN_EMBEDDING = 0.20  # Minimum embedding score for fallback rules (if embeddings available)
