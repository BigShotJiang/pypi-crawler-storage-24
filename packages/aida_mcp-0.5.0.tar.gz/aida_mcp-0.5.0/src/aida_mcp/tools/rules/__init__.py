# Copyright (C) 2026 GoodData Corporation

"""Rules retrieval module.

This module provides rule loading, scoring, and formatting for the get_rules tool.
The main entry point is in app/tools/rules_retrieval.py.
"""

from aida_mcp.tools.rules.formatting import RetrievalMetadata, format_rules_response
from aida_mcp.tools.rules.retriever import RulesRetriever
from aida_mcp.tools.rules.scoring import ScoredRule, tokenize_query
from aida_mcp.tools.rules.store import Rule, RuleStore, get_rule_store

__all__ = [
    # Store
    "Rule",
    "RuleStore",
    "get_rule_store",
    # Scoring
    "ScoredRule",
    "tokenize_query",
    # Formatting
    "RetrievalMetadata",
    "format_rules_response",
    # Retriever
    "RulesRetriever",
]
