# Copyright (C) 2026 GoodData Corporation

"""AIDA (AI Developer Assistant) - Developer action tools for GoodData monorepo."""
