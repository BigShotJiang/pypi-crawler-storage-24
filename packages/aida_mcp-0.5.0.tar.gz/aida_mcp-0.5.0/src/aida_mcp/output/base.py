# Copyright (C) 2026 GoodData Corporation

"""Backward-compatible exports for output formatting utilities.

Implementation is split into focused modules:
- `aida_mcp.output.command_summary`
- `aida_mcp.output.test_summary`
- `aida_mcp.output.error_grouping`
"""

from __future__ import annotations

from aida_mcp.output.command_summary import STDERR_PREVIEW_LINES, format_command_summary
from aida_mcp.output.test_summary import create_test_failure_summary, extract_failed_test_names, extract_test_summary

__all__ = [
    "STDERR_PREVIEW_LINES",
    "format_command_summary",
    "extract_test_summary",
    "extract_failed_test_names",
    "create_test_failure_summary",
]
