# Copyright (C) 2026 GoodData Corporation

"""Python tools output parsing utilities."""

from __future__ import annotations


def extract_ruff_summary(stdout: str, stderr: str) -> str | None:
    """Extract ruff linting summary."""
    combined = stdout + "\n" + stderr

    # Ruff shows issues like "Found 10 errors."
    for line in reversed(combined.split("\n")):
        if "found" in line.lower() and "error" in line.lower():
            return f"🔍 Ruff: {line.strip()}"

    # Check for "All checks passed"
    if not stdout.strip() or "would reformat" not in stdout.lower():
        return "🔍 Ruff: No issues found"

    return None


def extract_types_summary(stdout: str, stderr: str) -> str | None:
    """Extract a type-checking summary (e.g., Ty).

    Keep this intentionally tool-agnostic: we only look for common "Found N errors"
    style trailers to avoid baking in a single checker.
    """
    combined = stdout + "\n" + stderr

    for line in reversed(combined.split("\n")):
        ll = line.lower()
        if "found" in ll and "error" in ll:
            return f"📝 Types: {line.strip()}"
        if "error" in ll and "warning" in ll:
            return f"📝 Types: {line.strip()}"

    return None
