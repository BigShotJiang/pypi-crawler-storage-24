# Copyright (C) 2026 GoodData Corporation

"""Output parsing and formatting utilities."""

from aida_mcp.output.base import (
    STDERR_PREVIEW_LINES,
    create_test_failure_summary,
    extract_failed_test_names,
    extract_test_summary,
    format_command_summary,
)
from aida_mcp.output.gradle_parser import (
    extract_detekt_summary,
    extract_gradle_errors,
    extract_spotless_summary,
)
from aida_mcp.output.log_utils import extract_error_payload, extract_error_payload_from_lines, read_log_tail
from aida_mcp.output.python_parser import (
    extract_ruff_summary,
    extract_types_summary,
)
from aida_mcp.output.response_guard import shrink_tool_payload

__all__ = [
    # Base/shared
    "STDERR_PREVIEW_LINES",
    "format_command_summary",
    "extract_test_summary",
    "extract_failed_test_names",
    "create_test_failure_summary",
    # Gradle/Kotlin
    "extract_gradle_errors",
    "extract_detekt_summary",
    "extract_spotless_summary",
    # Python tools
    "extract_ruff_summary",
    "extract_types_summary",
    # Log helpers
    "extract_error_payload",
    "extract_error_payload_from_lines",
    "read_log_tail",
    "shrink_tool_payload",
]
