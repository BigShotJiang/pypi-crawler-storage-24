# Copyright (C) 2026 GoodData Corporation

"""Module entrypoint for `python -m aida_mcp.server`."""

from __future__ import annotations

from aida_mcp.server.app_instance import mcp
from aida_mcp.server.registry import register_all


def main() -> None:
    register_all(mcp)
    # `mcp` is a FastMCP instance; running it starts the stdio server.
    mcp.run()


if __name__ == "__main__":
    main()
