# Copyright (C) 2026 GoodData Corporation

"""Compatibility facade for MCP install helpers.

The implementation is split across focused modules to keep file sizes manageable while
preserving the original import surface from `aida_mcp.server.mcp_install`.
"""

from __future__ import annotations

from aida_mcp.server.mcp_install_common import (
    DEFAULT_HTTP_HOST,
    DEFAULT_HTTP_PATH,
    DEFAULT_HTTP_PORT,
    build_http_url,
    err,
    log,
    resolve_self_command_path,
    resolve_targets,
)
from aida_mcp.server.mcp_install_config import write_codex_toml_config, write_mcp_json_config
from aida_mcp.server.mcp_install_targets import (
    install_for_claude,
    install_for_claude_project,
    install_for_codex,
    install_for_codex_project,
    install_for_cursor,
    install_for_cursor_project,
    install_for_jetbrains,
    install_for_junie,
    resolve_claude_bin,
)

__all__ = [
    "DEFAULT_HTTP_HOST",
    "DEFAULT_HTTP_PATH",
    "DEFAULT_HTTP_PORT",
    "build_http_url",
    "err",
    "install_for_claude",
    "install_for_claude_project",
    "install_for_codex",
    "install_for_codex_project",
    "install_for_cursor",
    "install_for_cursor_project",
    "install_for_jetbrains",
    "install_for_junie",
    "log",
    "resolve_claude_bin",
    "resolve_self_command_path",
    "resolve_targets",
    "write_codex_toml_config",
    "write_mcp_json_config",
]
