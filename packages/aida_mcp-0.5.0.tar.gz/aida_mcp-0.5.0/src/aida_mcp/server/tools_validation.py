# Copyright (C) 2026 GoodData Corporation

"""Validation-related MCP tool registrations.

This module is intentionally tiny; tool implementations live in `aida_mcp.server.validation_tools.*`.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from aida_mcp.server.validation_tools import validate

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP


def register(mcp: FastMCP) -> None:
    """Register validation-related MCP tools."""
    validate.register(mcp)
