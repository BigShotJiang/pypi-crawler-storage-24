# Copyright (C) 2026 GoodData Corporation

"""Validation tool registrations for the MCP server."""
