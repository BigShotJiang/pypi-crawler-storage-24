# Copyright (C) 2026 GoodData Corporation

"""Shared FastMCP app instance for stdio mode.

Tool modules import `mcp` from here to register tools via decorators.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import TYPE_CHECKING, Any

from aida_mcp.server.bootstrap import configure_stdio_logging

configure_stdio_logging()

if TYPE_CHECKING:
    from mcp.server.fastmcp import (
        Context as MCPContext,
        FastMCP,
    )
else:
    try:
        from mcp.server.fastmcp import (
            Context as MCPContext,
            FastMCP,
        )
    except ImportError:
        # Provide helpful error message if dependencies are not installed
        aida_mcp_dir = Path(__file__).parent.parent.resolve()
        print(
            "\n" + "=" * 80 + "\n"
            "⚠️  AIDA dependencies not installed!\n\n"
            "If using 'uv run' (Cursor default), dependencies should install automatically.\n"
            "If this error persists, manually run:\n"
            f"  cd {aida_mcp_dir}\n"
            "  make dev\n\n"
            "This will create a virtual environment and install all required dependencies.\n"
            "After running 'make dev', restart Cursor to load the MCP server.\n"
            "=" * 80 + "\n",
            file=sys.stderr,
        )
        sys.exit(1)


if TYPE_CHECKING:
    # Type alias for Context with Any generics to satisfy pyright
    Context = MCPContext[Any, Any, Any]
else:
    # Runtime: keep Context as the real FastMCP Context class so the framework can inject it.
    Context = MCPContext

mcp = FastMCP(
    "aida",
    # stdio mode for local filesystem access (tools need access to codebase)
)
