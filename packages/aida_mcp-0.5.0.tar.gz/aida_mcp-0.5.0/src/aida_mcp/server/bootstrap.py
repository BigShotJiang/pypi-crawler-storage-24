# Copyright (C) 2026 GoodData Corporation

"""FastMCP import + logging bootstrap for the stdio MCP server."""

from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Any


def configure_stdio_logging() -> None:
    """Configure logging for MCP stdio mode.

    Cursor labels all stderr as "error", so we keep logs at WARNING+ by default.
    """
    logging.basicConfig(
        level=logging.WARNING,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )


def import_fastmcp() -> tuple[type[Any], type[Any]]:
    """Import FastMCP and Context; fail with a helpful message if missing."""
    try:
        from mcp.server.fastmcp import (
            Context as MCPContext,
            FastMCP,
        )

        return FastMCP, MCPContext
    except ImportError:
        aida_mcp_dir = Path(__file__).parent.parent.resolve()
        print(
            "\n" + "=" * 80 + "\n"
            "⚠️  AIDA dependencies not installed!\n\n"
            "If using 'uv run' (Cursor default), dependencies should install automatically.\n"
            "If this error persists, manually run:\n"
            f"  cd {aida_mcp_dir}\n"
            "  make dev\n\n"
            "This will create a virtual environment and install all required dependencies.\n"
            "After running 'make dev', restart Cursor to load the MCP server.\n"
            "=" * 80 + "\n",
            file=sys.stderr,
        )
        raise
