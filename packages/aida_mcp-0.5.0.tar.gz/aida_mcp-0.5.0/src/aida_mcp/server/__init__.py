# Copyright (C) 2026 GoodData Corporation

"""MCP server package for aida (stdio mode).

Tool registration is intentionally explicit (see `aida_mcp.server.registry.register_all`).
"""

from __future__ import annotations

from aida_mcp.server.app_instance import Context, mcp
from aida_mcp.server.registry import register_all

__all__ = ["Context", "mcp", "register_all"]
