# Copyright (C) 2026 GoodData Corporation

"""Compatibility facade for repo onboarding commands."""

from __future__ import annotations

from aida_mcp.server.repo_onboarding_impl import (
    InitResult,
    MigrateResult,
    UpdateRulesResult,
    doctor_repo,
    init_repo,
    migrate_repo,
    update_rules,
)

__all__ = [
    "InitResult",
    "MigrateResult",
    "UpdateRulesResult",
    "doctor_repo",
    "init_repo",
    "migrate_repo",
    "update_rules",
]
