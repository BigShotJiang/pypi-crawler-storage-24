# Copyright (C) 2026 GoodData Corporation

"""Packaged CLI entrypoint for AIDA (AI Developer Assistant)."""

from __future__ import annotations

import sys

from aida_mcp.server.cli_parser import build_arg_parser
from aida_mcp.server.cli_runtime import run_stdio_server


def main(argv: list[str] | None = None) -> None:
    """Console script entrypoint.

    Default behavior (no args): run the MCP stdio server.

    Subcommands are intended for local developer tasks (e.g. config installation) and may
    print to stdout/stderr freely.
    """

    _argv = list(sys.argv[1:] if argv is None else argv)
    if not _argv:
        run_stdio_server()
        return

    parser = build_arg_parser()
    parsed = parser.parse_args(_argv)
    handler = getattr(parsed, "_handler", None)
    if handler is None:
        parser.print_help(file=sys.stderr)
        raise SystemExit(2)
    handler(parsed)
