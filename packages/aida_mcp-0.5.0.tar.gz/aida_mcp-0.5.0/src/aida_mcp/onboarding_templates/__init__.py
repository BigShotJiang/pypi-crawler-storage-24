# Copyright (C) 2026 GoodData Corporation

"""Packaged onboarding templates for `aida-mcp init`.

Templates are shipped as package data and loaded via `importlib.resources`.
"""
