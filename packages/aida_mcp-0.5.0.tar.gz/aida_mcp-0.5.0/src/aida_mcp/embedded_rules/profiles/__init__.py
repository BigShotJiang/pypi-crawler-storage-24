# Copyright (C) 2026 GoodData Corporation

"""Optional embedded rule profiles."""
