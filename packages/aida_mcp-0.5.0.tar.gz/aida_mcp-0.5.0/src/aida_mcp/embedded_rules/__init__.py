# Copyright (C) 2026 GoodData Corporation

"""Embedded rules shipped with the aida-mcp package.

This package is intentionally designed to make `get_rules` portable across repos:
- `core/`: safe reusable defaults enabled by default
- `profiles/`: optional technology/workflow profiles enabled via `.aida/rules_selection.yaml`
"""
