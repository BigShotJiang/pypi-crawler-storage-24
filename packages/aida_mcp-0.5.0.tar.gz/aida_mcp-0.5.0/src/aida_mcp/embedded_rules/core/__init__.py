# Copyright (C) 2026 GoodData Corporation

"""Core embedded rules enabled by default."""
