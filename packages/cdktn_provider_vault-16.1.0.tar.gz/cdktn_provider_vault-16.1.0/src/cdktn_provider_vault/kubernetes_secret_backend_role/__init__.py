r'''
# `vault_kubernetes_secret_backend_role`

Refer to the Terraform Registry for docs: [`vault_kubernetes_secret_backend_role`](https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role).
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8


class KubernetesSecretBackendRole(
    _cdktn_78ede62e.TerraformResource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-vault.kubernetesSecretBackendRole.KubernetesSecretBackendRole",
):
    '''Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role vault_kubernetes_secret_backend_role}.'''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id_: builtins.str,
        *,
        backend: builtins.str,
        name: builtins.str,
        allowed_kubernetes_namespaces: typing.Optional[typing.Sequence[builtins.str]] = None,
        allowed_kubernetes_namespace_selector: typing.Optional[builtins.str] = None,
        extra_annotations: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        extra_labels: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        generated_role_rules: typing.Optional[builtins.str] = None,
        id: typing.Optional[builtins.str] = None,
        kubernetes_role_name: typing.Optional[builtins.str] = None,
        kubernetes_role_type: typing.Optional[builtins.str] = None,
        namespace: typing.Optional[builtins.str] = None,
        name_template: typing.Optional[builtins.str] = None,
        service_account_name: typing.Optional[builtins.str] = None,
        token_default_audiences: typing.Optional[typing.Sequence[builtins.str]] = None,
        token_default_ttl: typing.Optional[jsii.Number] = None,
        token_max_ttl: typing.Optional[jsii.Number] = None,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role vault_kubernetes_secret_backend_role} Resource.

        :param scope: The scope in which to define this construct.
        :param id_: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param backend: The mount path for the Kubernetes secrets engine. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#backend KubernetesSecretBackendRole#backend}
        :param name: The name of the role. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#name KubernetesSecretBackendRole#name}
        :param allowed_kubernetes_namespaces: The list of Kubernetes namespaces this role can generate credentials for. If set to '*' all namespaces are allowed. If set with``allowed_kubernetes_namespace_selector``, the conditions are ``OR``ed. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#allowed_kubernetes_namespaces KubernetesSecretBackendRole#allowed_kubernetes_namespaces}
        :param allowed_kubernetes_namespace_selector: A label selector for Kubernetes namespaces in which credentials can begenerated. Accepts either a JSON or YAML object. The value should be of typeLabelSelector. If set with ``allowed_kubernetes_namespace``, the conditions are ``OR``ed. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#allowed_kubernetes_namespace_selector KubernetesSecretBackendRole#allowed_kubernetes_namespace_selector}
        :param extra_annotations: Additional annotations to apply to all generated Kubernetes objects. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#extra_annotations KubernetesSecretBackendRole#extra_annotations}
        :param extra_labels: Additional labels to apply to all generated Kubernetes objects. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#extra_labels KubernetesSecretBackendRole#extra_labels}
        :param generated_role_rules: The Role or ClusterRole rules to use when generating a role. Accepts either JSON or YAML formatted rules. Mutually exclusive with 'service_account_name' and 'kubernetes_role_name'. If set, the entire chain of Kubernetes objects will be generated when credentials are requested. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#generated_role_rules KubernetesSecretBackendRole#generated_role_rules}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#id KubernetesSecretBackendRole#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param kubernetes_role_name: The pre-existing Role or ClusterRole to bind a generated service account to. Mutually exclusive with 'service_account_name' and 'generated_role_rules'. If set, Kubernetes token, service account, and role binding objects will be created when credentials are requested. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#kubernetes_role_name KubernetesSecretBackendRole#kubernetes_role_name}
        :param kubernetes_role_type: Specifies whether the Kubernetes role is a Role or ClusterRole. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#kubernetes_role_type KubernetesSecretBackendRole#kubernetes_role_type}
        :param namespace: Target namespace. (requires Enterprise). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#namespace KubernetesSecretBackendRole#namespace}
        :param name_template: The name template to use when generating service accounts, roles and role bindings. If unset, a default template is used. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#name_template KubernetesSecretBackendRole#name_template}
        :param service_account_name: The pre-existing service account to generate tokens for. Mutually exclusive with 'kubernetes_role_name' and 'generated_role_rules'. If set, only a Kubernetes token will be created when credentials are requested. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#service_account_name KubernetesSecretBackendRole#service_account_name}
        :param token_default_audiences: The default audiences for generated Kubernetes tokens. If not set, defaults to the Kubernetes cluster's default audiences. Requires Vault 1.15+. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#token_default_audiences KubernetesSecretBackendRole#token_default_audiences}
        :param token_default_ttl: The default TTL for generated Kubernetes tokens in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#token_default_ttl KubernetesSecretBackendRole#token_default_ttl}
        :param token_max_ttl: The maximum TTL for generated Kubernetes tokens in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#token_max_ttl KubernetesSecretBackendRole#token_max_ttl}
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9562d9518962bb4a1f15a987ffa8d69ffddca82ee3cf296cdedc03462a0f3854)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id_", value=id_, expected_type=type_hints["id_"])
        config = KubernetesSecretBackendRoleConfig(
            backend=backend,
            name=name,
            allowed_kubernetes_namespaces=allowed_kubernetes_namespaces,
            allowed_kubernetes_namespace_selector=allowed_kubernetes_namespace_selector,
            extra_annotations=extra_annotations,
            extra_labels=extra_labels,
            generated_role_rules=generated_role_rules,
            id=id,
            kubernetes_role_name=kubernetes_role_name,
            kubernetes_role_type=kubernetes_role_type,
            namespace=namespace,
            name_template=name_template,
            service_account_name=service_account_name,
            token_default_audiences=token_default_audiences,
            token_default_ttl=token_default_ttl,
            token_max_ttl=token_max_ttl,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id_, config])

    @jsii.member(jsii_name="generateConfigForImport")
    @builtins.classmethod
    def generate_config_for_import(
        cls,
        scope: "_constructs_77d1e7e8.Construct",
        import_to_id: builtins.str,
        import_from_id: builtins.str,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
    ) -> "_cdktn_78ede62e.ImportableResource":
        '''Generates CDKTN code for importing a KubernetesSecretBackendRole resource upon running "cdktn plan ".

        :param scope: The scope in which to define this construct.
        :param import_to_id: The construct id used in the generated config for the KubernetesSecretBackendRole to import.
        :param import_from_id: The id of the existing KubernetesSecretBackendRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#import import section} in the documentation of this resource for the id to use
        :param provider: ? Optional instance of the provider where the KubernetesSecretBackendRole to import is found.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c215aacf692f33811a7757d7b45cec916f842b09d36b694bd76576120db588ae)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument import_to_id", value=import_to_id, expected_type=type_hints["import_to_id"])
            check_type(argname="argument import_from_id", value=import_from_id, expected_type=type_hints["import_from_id"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
        return typing.cast("_cdktn_78ede62e.ImportableResource", jsii.sinvoke(cls, "generateConfigForImport", [scope, import_to_id, import_from_id, provider]))

    @jsii.member(jsii_name="resetAllowedKubernetesNamespaces")
    def reset_allowed_kubernetes_namespaces(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAllowedKubernetesNamespaces", []))

    @jsii.member(jsii_name="resetAllowedKubernetesNamespaceSelector")
    def reset_allowed_kubernetes_namespace_selector(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAllowedKubernetesNamespaceSelector", []))

    @jsii.member(jsii_name="resetExtraAnnotations")
    def reset_extra_annotations(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetExtraAnnotations", []))

    @jsii.member(jsii_name="resetExtraLabels")
    def reset_extra_labels(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetExtraLabels", []))

    @jsii.member(jsii_name="resetGeneratedRoleRules")
    def reset_generated_role_rules(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetGeneratedRoleRules", []))

    @jsii.member(jsii_name="resetId")
    def reset_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetId", []))

    @jsii.member(jsii_name="resetKubernetesRoleName")
    def reset_kubernetes_role_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetKubernetesRoleName", []))

    @jsii.member(jsii_name="resetKubernetesRoleType")
    def reset_kubernetes_role_type(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetKubernetesRoleType", []))

    @jsii.member(jsii_name="resetNamespace")
    def reset_namespace(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNamespace", []))

    @jsii.member(jsii_name="resetNameTemplate")
    def reset_name_template(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNameTemplate", []))

    @jsii.member(jsii_name="resetServiceAccountName")
    def reset_service_account_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetServiceAccountName", []))

    @jsii.member(jsii_name="resetTokenDefaultAudiences")
    def reset_token_default_audiences(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTokenDefaultAudiences", []))

    @jsii.member(jsii_name="resetTokenDefaultTtl")
    def reset_token_default_ttl(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTokenDefaultTtl", []))

    @jsii.member(jsii_name="resetTokenMaxTtl")
    def reset_token_max_ttl(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTokenMaxTtl", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.member(jsii_name="synthesizeHclAttributes")
    def _synthesize_hcl_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeHclAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="allowedKubernetesNamespaceSelectorInput")
    def allowed_kubernetes_namespace_selector_input(
        self,
    ) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "allowedKubernetesNamespaceSelectorInput"))

    @builtins.property
    @jsii.member(jsii_name="allowedKubernetesNamespacesInput")
    def allowed_kubernetes_namespaces_input(
        self,
    ) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "allowedKubernetesNamespacesInput"))

    @builtins.property
    @jsii.member(jsii_name="backendInput")
    def backend_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "backendInput"))

    @builtins.property
    @jsii.member(jsii_name="extraAnnotationsInput")
    def extra_annotations_input(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], jsii.get(self, "extraAnnotationsInput"))

    @builtins.property
    @jsii.member(jsii_name="extraLabelsInput")
    def extra_labels_input(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], jsii.get(self, "extraLabelsInput"))

    @builtins.property
    @jsii.member(jsii_name="generatedRoleRulesInput")
    def generated_role_rules_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "generatedRoleRulesInput"))

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="kubernetesRoleNameInput")
    def kubernetes_role_name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "kubernetesRoleNameInput"))

    @builtins.property
    @jsii.member(jsii_name="kubernetesRoleTypeInput")
    def kubernetes_role_type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "kubernetesRoleTypeInput"))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="namespaceInput")
    def namespace_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "namespaceInput"))

    @builtins.property
    @jsii.member(jsii_name="nameTemplateInput")
    def name_template_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameTemplateInput"))

    @builtins.property
    @jsii.member(jsii_name="serviceAccountNameInput")
    def service_account_name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "serviceAccountNameInput"))

    @builtins.property
    @jsii.member(jsii_name="tokenDefaultAudiencesInput")
    def token_default_audiences_input(
        self,
    ) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "tokenDefaultAudiencesInput"))

    @builtins.property
    @jsii.member(jsii_name="tokenDefaultTtlInput")
    def token_default_ttl_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "tokenDefaultTtlInput"))

    @builtins.property
    @jsii.member(jsii_name="tokenMaxTtlInput")
    def token_max_ttl_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "tokenMaxTtlInput"))

    @builtins.property
    @jsii.member(jsii_name="allowedKubernetesNamespaces")
    def allowed_kubernetes_namespaces(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "allowedKubernetesNamespaces"))

    @allowed_kubernetes_namespaces.setter
    def allowed_kubernetes_namespaces(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__993b5fe1099a24c2de3cffe80de405c8da044dbb280568cca11775eca285bc16)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "allowedKubernetesNamespaces", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="allowedKubernetesNamespaceSelector")
    def allowed_kubernetes_namespace_selector(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "allowedKubernetesNamespaceSelector"))

    @allowed_kubernetes_namespace_selector.setter
    def allowed_kubernetes_namespace_selector(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__47664a7cea72b3653f098e4424240e8d1dad4db626b9fa2118da48227e2b55f9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "allowedKubernetesNamespaceSelector", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="backend")
    def backend(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "backend"))

    @backend.setter
    def backend(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4c448c44c0d253ee948b7abcec470408a1884a9c055c7d88d268d90a57947350)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "backend", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="extraAnnotations")
    def extra_annotations(self) -> typing.Mapping[builtins.str, builtins.str]:
        return typing.cast(typing.Mapping[builtins.str, builtins.str], jsii.get(self, "extraAnnotations"))

    @extra_annotations.setter
    def extra_annotations(
        self,
        value: typing.Mapping[builtins.str, builtins.str],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f08004a933f39780091f9ac4e57de85fd5b11e2e839c83f9aec9c067643153ab)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "extraAnnotations", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="extraLabels")
    def extra_labels(self) -> typing.Mapping[builtins.str, builtins.str]:
        return typing.cast(typing.Mapping[builtins.str, builtins.str], jsii.get(self, "extraLabels"))

    @extra_labels.setter
    def extra_labels(self, value: typing.Mapping[builtins.str, builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__72d5e253f4bd69e07826ce7f5244c5831e5abe943a8642df2722aeed06fc3422)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "extraLabels", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="generatedRoleRules")
    def generated_role_rules(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "generatedRoleRules"))

    @generated_role_rules.setter
    def generated_role_rules(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__08c78afa82086e77897c2117d0f2f66fef9da25cdeb10c3e62c9d67f77458ca8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "generatedRoleRules", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @id.setter
    def id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eab2e374085a667b85d991f4700601936f00d6268d7a1d58ecfe76bd9f246a39)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="kubernetesRoleName")
    def kubernetes_role_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "kubernetesRoleName"))

    @kubernetes_role_name.setter
    def kubernetes_role_name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__308f8ee3d5bc9f98b53b541f805dfcb118261f3384a83199e27bbc837a441222)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "kubernetesRoleName", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="kubernetesRoleType")
    def kubernetes_role_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "kubernetesRoleType"))

    @kubernetes_role_type.setter
    def kubernetes_role_type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b92af2958e9c04cebd396b26117e1cc5215b8c9c8d2d3d7439938696068b5fef)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "kubernetesRoleType", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4cebec0e140df9e1933be0056c7c205ae3979f15027bb954bb2d275f85e0abb8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="namespace")
    def namespace(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "namespace"))

    @namespace.setter
    def namespace(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__83f7690a2803fa155f635bc02faa10152b12904b48e9d24189c5faa1a811f9a1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "namespace", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="nameTemplate")
    def name_template(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "nameTemplate"))

    @name_template.setter
    def name_template(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__95c105b44f54674f1152d3423b86e7fa6b1b661256ddc62bd9d798f83f9f9dc8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "nameTemplate", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="serviceAccountName")
    def service_account_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "serviceAccountName"))

    @service_account_name.setter
    def service_account_name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__186600f0af028b8251db6c9b153fbc0f6513c7d9b0a9b7bc6a68fe07855015b3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "serviceAccountName", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="tokenDefaultAudiences")
    def token_default_audiences(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "tokenDefaultAudiences"))

    @token_default_audiences.setter
    def token_default_audiences(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__998305c3baa0b5ed563486fbad3f33b5128f24d70668d1e00f5ebb9ba326f671)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "tokenDefaultAudiences", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="tokenDefaultTtl")
    def token_default_ttl(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "tokenDefaultTtl"))

    @token_default_ttl.setter
    def token_default_ttl(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__34b9b1900978c9683a1d85f039f996c7914045889e47bc6078c5259cd13ab1aa)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "tokenDefaultTtl", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="tokenMaxTtl")
    def token_max_ttl(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "tokenMaxTtl"))

    @token_max_ttl.setter
    def token_max_ttl(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__acc33cd3700987fb345485ddd74c38baa3cd43dbf9368409d1692506e5b82956)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "tokenMaxTtl", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-vault.kubernetesSecretBackendRole.KubernetesSecretBackendRoleConfig",
    jsii_struct_bases=[_cdktn_78ede62e.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "backend": "backend",
        "name": "name",
        "allowed_kubernetes_namespaces": "allowedKubernetesNamespaces",
        "allowed_kubernetes_namespace_selector": "allowedKubernetesNamespaceSelector",
        "extra_annotations": "extraAnnotations",
        "extra_labels": "extraLabels",
        "generated_role_rules": "generatedRoleRules",
        "id": "id",
        "kubernetes_role_name": "kubernetesRoleName",
        "kubernetes_role_type": "kubernetesRoleType",
        "namespace": "namespace",
        "name_template": "nameTemplate",
        "service_account_name": "serviceAccountName",
        "token_default_audiences": "tokenDefaultAudiences",
        "token_default_ttl": "tokenDefaultTtl",
        "token_max_ttl": "tokenMaxTtl",
    },
)
class KubernetesSecretBackendRoleConfig(_cdktn_78ede62e.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
        backend: builtins.str,
        name: builtins.str,
        allowed_kubernetes_namespaces: typing.Optional[typing.Sequence[builtins.str]] = None,
        allowed_kubernetes_namespace_selector: typing.Optional[builtins.str] = None,
        extra_annotations: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        extra_labels: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        generated_role_rules: typing.Optional[builtins.str] = None,
        id: typing.Optional[builtins.str] = None,
        kubernetes_role_name: typing.Optional[builtins.str] = None,
        kubernetes_role_type: typing.Optional[builtins.str] = None,
        namespace: typing.Optional[builtins.str] = None,
        name_template: typing.Optional[builtins.str] = None,
        service_account_name: typing.Optional[builtins.str] = None,
        token_default_audiences: typing.Optional[typing.Sequence[builtins.str]] = None,
        token_default_ttl: typing.Optional[jsii.Number] = None,
        token_max_ttl: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param backend: The mount path for the Kubernetes secrets engine. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#backend KubernetesSecretBackendRole#backend}
        :param name: The name of the role. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#name KubernetesSecretBackendRole#name}
        :param allowed_kubernetes_namespaces: The list of Kubernetes namespaces this role can generate credentials for. If set to '*' all namespaces are allowed. If set with``allowed_kubernetes_namespace_selector``, the conditions are ``OR``ed. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#allowed_kubernetes_namespaces KubernetesSecretBackendRole#allowed_kubernetes_namespaces}
        :param allowed_kubernetes_namespace_selector: A label selector for Kubernetes namespaces in which credentials can begenerated. Accepts either a JSON or YAML object. The value should be of typeLabelSelector. If set with ``allowed_kubernetes_namespace``, the conditions are ``OR``ed. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#allowed_kubernetes_namespace_selector KubernetesSecretBackendRole#allowed_kubernetes_namespace_selector}
        :param extra_annotations: Additional annotations to apply to all generated Kubernetes objects. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#extra_annotations KubernetesSecretBackendRole#extra_annotations}
        :param extra_labels: Additional labels to apply to all generated Kubernetes objects. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#extra_labels KubernetesSecretBackendRole#extra_labels}
        :param generated_role_rules: The Role or ClusterRole rules to use when generating a role. Accepts either JSON or YAML formatted rules. Mutually exclusive with 'service_account_name' and 'kubernetes_role_name'. If set, the entire chain of Kubernetes objects will be generated when credentials are requested. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#generated_role_rules KubernetesSecretBackendRole#generated_role_rules}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#id KubernetesSecretBackendRole#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param kubernetes_role_name: The pre-existing Role or ClusterRole to bind a generated service account to. Mutually exclusive with 'service_account_name' and 'generated_role_rules'. If set, Kubernetes token, service account, and role binding objects will be created when credentials are requested. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#kubernetes_role_name KubernetesSecretBackendRole#kubernetes_role_name}
        :param kubernetes_role_type: Specifies whether the Kubernetes role is a Role or ClusterRole. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#kubernetes_role_type KubernetesSecretBackendRole#kubernetes_role_type}
        :param namespace: Target namespace. (requires Enterprise). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#namespace KubernetesSecretBackendRole#namespace}
        :param name_template: The name template to use when generating service accounts, roles and role bindings. If unset, a default template is used. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#name_template KubernetesSecretBackendRole#name_template}
        :param service_account_name: The pre-existing service account to generate tokens for. Mutually exclusive with 'kubernetes_role_name' and 'generated_role_rules'. If set, only a Kubernetes token will be created when credentials are requested. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#service_account_name KubernetesSecretBackendRole#service_account_name}
        :param token_default_audiences: The default audiences for generated Kubernetes tokens. If not set, defaults to the Kubernetes cluster's default audiences. Requires Vault 1.15+. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#token_default_audiences KubernetesSecretBackendRole#token_default_audiences}
        :param token_default_ttl: The default TTL for generated Kubernetes tokens in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#token_default_ttl KubernetesSecretBackendRole#token_default_ttl}
        :param token_max_ttl: The maximum TTL for generated Kubernetes tokens in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#token_max_ttl KubernetesSecretBackendRole#token_max_ttl}
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e1939173189f32be71597b312ff2385e3a90ab0bdb4aa85177dd321bcc5d69ad)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument backend", value=backend, expected_type=type_hints["backend"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument allowed_kubernetes_namespaces", value=allowed_kubernetes_namespaces, expected_type=type_hints["allowed_kubernetes_namespaces"])
            check_type(argname="argument allowed_kubernetes_namespace_selector", value=allowed_kubernetes_namespace_selector, expected_type=type_hints["allowed_kubernetes_namespace_selector"])
            check_type(argname="argument extra_annotations", value=extra_annotations, expected_type=type_hints["extra_annotations"])
            check_type(argname="argument extra_labels", value=extra_labels, expected_type=type_hints["extra_labels"])
            check_type(argname="argument generated_role_rules", value=generated_role_rules, expected_type=type_hints["generated_role_rules"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument kubernetes_role_name", value=kubernetes_role_name, expected_type=type_hints["kubernetes_role_name"])
            check_type(argname="argument kubernetes_role_type", value=kubernetes_role_type, expected_type=type_hints["kubernetes_role_type"])
            check_type(argname="argument namespace", value=namespace, expected_type=type_hints["namespace"])
            check_type(argname="argument name_template", value=name_template, expected_type=type_hints["name_template"])
            check_type(argname="argument service_account_name", value=service_account_name, expected_type=type_hints["service_account_name"])
            check_type(argname="argument token_default_audiences", value=token_default_audiences, expected_type=type_hints["token_default_audiences"])
            check_type(argname="argument token_default_ttl", value=token_default_ttl, expected_type=type_hints["token_default_ttl"])
            check_type(argname="argument token_max_ttl", value=token_max_ttl, expected_type=type_hints["token_max_ttl"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "backend": backend,
            "name": name,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if allowed_kubernetes_namespaces is not None:
            self._values["allowed_kubernetes_namespaces"] = allowed_kubernetes_namespaces
        if allowed_kubernetes_namespace_selector is not None:
            self._values["allowed_kubernetes_namespace_selector"] = allowed_kubernetes_namespace_selector
        if extra_annotations is not None:
            self._values["extra_annotations"] = extra_annotations
        if extra_labels is not None:
            self._values["extra_labels"] = extra_labels
        if generated_role_rules is not None:
            self._values["generated_role_rules"] = generated_role_rules
        if id is not None:
            self._values["id"] = id
        if kubernetes_role_name is not None:
            self._values["kubernetes_role_name"] = kubernetes_role_name
        if kubernetes_role_type is not None:
            self._values["kubernetes_role_type"] = kubernetes_role_type
        if namespace is not None:
            self._values["namespace"] = namespace
        if name_template is not None:
            self._values["name_template"] = name_template
        if service_account_name is not None:
            self._values["service_account_name"] = service_account_name
        if token_default_audiences is not None:
            self._values["token_default_audiences"] = token_default_audiences
        if token_default_ttl is not None:
            self._values["token_default_ttl"] = token_default_ttl
        if token_max_ttl is not None:
            self._values["token_max_ttl"] = token_max_ttl

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]], result)

    @builtins.property
    def for_each(self) -> typing.Optional["_cdktn_78ede62e.ITerraformIterator"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional["_cdktn_78ede62e.ITerraformIterator"], result)

    @builtins.property
    def lifecycle(
        self,
    ) -> typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"], result)

    @builtins.property
    def provider(self) -> typing.Optional["_cdktn_78ede62e.TerraformProvider"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformProvider"], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]], result)

    @builtins.property
    def backend(self) -> builtins.str:
        '''The mount path for the Kubernetes secrets engine.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#backend KubernetesSecretBackendRole#backend}
        '''
        result = self._values.get("backend")
        assert result is not None, "Required property 'backend' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def name(self) -> builtins.str:
        '''The name of the role.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#name KubernetesSecretBackendRole#name}
        '''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def allowed_kubernetes_namespaces(
        self,
    ) -> typing.Optional[typing.List[builtins.str]]:
        '''The list of Kubernetes namespaces this role can generate credentials for.

        If set to '*' all namespaces are allowed. If set with``allowed_kubernetes_namespace_selector``, the conditions are ``OR``ed.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#allowed_kubernetes_namespaces KubernetesSecretBackendRole#allowed_kubernetes_namespaces}
        '''
        result = self._values.get("allowed_kubernetes_namespaces")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def allowed_kubernetes_namespace_selector(self) -> typing.Optional[builtins.str]:
        '''A label selector for Kubernetes namespaces in which credentials can begenerated.

        Accepts either a JSON or YAML object. The value should be of typeLabelSelector. If set with ``allowed_kubernetes_namespace``, the conditions are ``OR``ed.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#allowed_kubernetes_namespace_selector KubernetesSecretBackendRole#allowed_kubernetes_namespace_selector}
        '''
        result = self._values.get("allowed_kubernetes_namespace_selector")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def extra_annotations(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''Additional annotations to apply to all generated Kubernetes objects.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#extra_annotations KubernetesSecretBackendRole#extra_annotations}
        '''
        result = self._values.get("extra_annotations")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def extra_labels(
        self,
    ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''Additional labels to apply to all generated Kubernetes objects.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#extra_labels KubernetesSecretBackendRole#extra_labels}
        '''
        result = self._values.get("extra_labels")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def generated_role_rules(self) -> typing.Optional[builtins.str]:
        '''The Role or ClusterRole rules to use when generating a role.

        Accepts either JSON or YAML formatted rules. Mutually exclusive with 'service_account_name' and 'kubernetes_role_name'. If set, the entire chain of Kubernetes objects will be generated when credentials are requested.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#generated_role_rules KubernetesSecretBackendRole#generated_role_rules}
        '''
        result = self._values.get("generated_role_rules")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def id(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#id KubernetesSecretBackendRole#id}.

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def kubernetes_role_name(self) -> typing.Optional[builtins.str]:
        '''The pre-existing Role or ClusterRole to bind a generated service account to.

        Mutually exclusive with 'service_account_name' and 'generated_role_rules'. If set, Kubernetes token, service account, and role binding objects will be created when credentials are requested.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#kubernetes_role_name KubernetesSecretBackendRole#kubernetes_role_name}
        '''
        result = self._values.get("kubernetes_role_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def kubernetes_role_type(self) -> typing.Optional[builtins.str]:
        '''Specifies whether the Kubernetes role is a Role or ClusterRole.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#kubernetes_role_type KubernetesSecretBackendRole#kubernetes_role_type}
        '''
        result = self._values.get("kubernetes_role_type")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def namespace(self) -> typing.Optional[builtins.str]:
        '''Target namespace. (requires Enterprise).

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#namespace KubernetesSecretBackendRole#namespace}
        '''
        result = self._values.get("namespace")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def name_template(self) -> typing.Optional[builtins.str]:
        '''The name template to use when generating service accounts, roles and role bindings.

        If unset, a default template is used.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#name_template KubernetesSecretBackendRole#name_template}
        '''
        result = self._values.get("name_template")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def service_account_name(self) -> typing.Optional[builtins.str]:
        '''The pre-existing service account to generate tokens for.

        Mutually exclusive with 'kubernetes_role_name' and 'generated_role_rules'. If set, only a Kubernetes token will be created when credentials are requested.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#service_account_name KubernetesSecretBackendRole#service_account_name}
        '''
        result = self._values.get("service_account_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def token_default_audiences(self) -> typing.Optional[typing.List[builtins.str]]:
        '''The default audiences for generated Kubernetes tokens.

        If not set, defaults to the Kubernetes cluster's default audiences. Requires Vault 1.15+.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#token_default_audiences KubernetesSecretBackendRole#token_default_audiences}
        '''
        result = self._values.get("token_default_audiences")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def token_default_ttl(self) -> typing.Optional[jsii.Number]:
        '''The default TTL for generated Kubernetes tokens in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#token_default_ttl KubernetesSecretBackendRole#token_default_ttl}
        '''
        result = self._values.get("token_default_ttl")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def token_max_ttl(self) -> typing.Optional[jsii.Number]:
        '''The maximum TTL for generated Kubernetes tokens in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kubernetes_secret_backend_role#token_max_ttl KubernetesSecretBackendRole#token_max_ttl}
        '''
        result = self._values.get("token_max_ttl")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "KubernetesSecretBackendRoleConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "KubernetesSecretBackendRole",
    "KubernetesSecretBackendRoleConfig",
]

publication.publish()

def _typecheckingstub__9562d9518962bb4a1f15a987ffa8d69ffddca82ee3cf296cdedc03462a0f3854(
    scope: _constructs_77d1e7e8.Construct,
    id_: builtins.str,
    *,
    backend: builtins.str,
    name: builtins.str,
    allowed_kubernetes_namespaces: typing.Optional[typing.Sequence[builtins.str]] = None,
    allowed_kubernetes_namespace_selector: typing.Optional[builtins.str] = None,
    extra_annotations: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    extra_labels: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    generated_role_rules: typing.Optional[builtins.str] = None,
    id: typing.Optional[builtins.str] = None,
    kubernetes_role_name: typing.Optional[builtins.str] = None,
    kubernetes_role_type: typing.Optional[builtins.str] = None,
    namespace: typing.Optional[builtins.str] = None,
    name_template: typing.Optional[builtins.str] = None,
    service_account_name: typing.Optional[builtins.str] = None,
    token_default_audiences: typing.Optional[typing.Sequence[builtins.str]] = None,
    token_default_ttl: typing.Optional[jsii.Number] = None,
    token_max_ttl: typing.Optional[jsii.Number] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c215aacf692f33811a7757d7b45cec916f842b09d36b694bd76576120db588ae(
    scope: _constructs_77d1e7e8.Construct,
    import_to_id: builtins.str,
    import_from_id: builtins.str,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__993b5fe1099a24c2de3cffe80de405c8da044dbb280568cca11775eca285bc16(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__47664a7cea72b3653f098e4424240e8d1dad4db626b9fa2118da48227e2b55f9(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4c448c44c0d253ee948b7abcec470408a1884a9c055c7d88d268d90a57947350(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f08004a933f39780091f9ac4e57de85fd5b11e2e839c83f9aec9c067643153ab(
    value: typing.Mapping[builtins.str, builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__72d5e253f4bd69e07826ce7f5244c5831e5abe943a8642df2722aeed06fc3422(
    value: typing.Mapping[builtins.str, builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__08c78afa82086e77897c2117d0f2f66fef9da25cdeb10c3e62c9d67f77458ca8(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eab2e374085a667b85d991f4700601936f00d6268d7a1d58ecfe76bd9f246a39(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__308f8ee3d5bc9f98b53b541f805dfcb118261f3384a83199e27bbc837a441222(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b92af2958e9c04cebd396b26117e1cc5215b8c9c8d2d3d7439938696068b5fef(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4cebec0e140df9e1933be0056c7c205ae3979f15027bb954bb2d275f85e0abb8(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__83f7690a2803fa155f635bc02faa10152b12904b48e9d24189c5faa1a811f9a1(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__95c105b44f54674f1152d3423b86e7fa6b1b661256ddc62bd9d798f83f9f9dc8(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__186600f0af028b8251db6c9b153fbc0f6513c7d9b0a9b7bc6a68fe07855015b3(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__998305c3baa0b5ed563486fbad3f33b5128f24d70668d1e00f5ebb9ba326f671(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__34b9b1900978c9683a1d85f039f996c7914045889e47bc6078c5259cd13ab1aa(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__acc33cd3700987fb345485ddd74c38baa3cd43dbf9368409d1692506e5b82956(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e1939173189f32be71597b312ff2385e3a90ab0bdb4aa85177dd321bcc5d69ad(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    backend: builtins.str,
    name: builtins.str,
    allowed_kubernetes_namespaces: typing.Optional[typing.Sequence[builtins.str]] = None,
    allowed_kubernetes_namespace_selector: typing.Optional[builtins.str] = None,
    extra_annotations: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    extra_labels: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    generated_role_rules: typing.Optional[builtins.str] = None,
    id: typing.Optional[builtins.str] = None,
    kubernetes_role_name: typing.Optional[builtins.str] = None,
    kubernetes_role_type: typing.Optional[builtins.str] = None,
    namespace: typing.Optional[builtins.str] = None,
    name_template: typing.Optional[builtins.str] = None,
    service_account_name: typing.Optional[builtins.str] = None,
    token_default_audiences: typing.Optional[typing.Sequence[builtins.str]] = None,
    token_default_ttl: typing.Optional[jsii.Number] = None,
    token_max_ttl: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass
