r'''
# `vault_kmip_secret_role`

Refer to the Terraform Registry for docs: [`vault_kmip_secret_role`](https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role).
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8


class KmipSecretRole(
    _cdktn_78ede62e.TerraformResource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-vault.kmipSecretRole.KmipSecretRole",
):
    '''Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role vault_kmip_secret_role}.'''

    def __init__(
        self,
        scope_: "_constructs_77d1e7e8.Construct",
        id_: builtins.str,
        *,
        path: builtins.str,
        role: builtins.str,
        scope: builtins.str,
        ca: typing.Optional[builtins.str] = None,
        id: typing.Optional[builtins.str] = None,
        namespace: typing.Optional[builtins.str] = None,
        operation_activate: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_add_attribute: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_all: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_create: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_create_key_pair: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_decrypt: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_delete_attribute: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_destroy: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_discover_versions: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_encrypt: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_get: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_get_attribute_list: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_get_attributes: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_import: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_locate: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_mac: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_mac_verify: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_modify_attribute: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_none: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_query: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_register: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_rekey: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_rekey_key_pair: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_revoke: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_rng_retrieve: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_rng_seed: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_sign: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_signature_verify: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        tls_client_key_bits: typing.Optional[jsii.Number] = None,
        tls_client_key_type: typing.Optional[builtins.str] = None,
        tls_client_ttl: typing.Optional[jsii.Number] = None,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role vault_kmip_secret_role} Resource.

        :param scope_: The scope in which to define this construct.
        :param id_: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param path: Path where KMIP backend is mounted. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#path KmipSecretRole#path}
        :param role: Name of the role. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#role KmipSecretRole#role}
        :param scope: Name of the scope. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#scope KmipSecretRole#scope}
        :param ca: Name of the ca to use, if absent use legacy ca. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#ca KmipSecretRole#ca}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#id KmipSecretRole#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param namespace: Target namespace. (requires Enterprise). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#namespace KmipSecretRole#namespace}
        :param operation_activate: Grant permission to use the KMIP Activate operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_activate KmipSecretRole#operation_activate}
        :param operation_add_attribute: Grant permission to use the KMIP Add Attribute operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_add_attribute KmipSecretRole#operation_add_attribute}
        :param operation_all: Grant all permissions to this role. May not be specified with any other operation_* params. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_all KmipSecretRole#operation_all}
        :param operation_create: Grant permission to use the KMIP Create operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_create KmipSecretRole#operation_create}
        :param operation_create_key_pair: Grant permission to use the KMIP Create Key Pair operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_create_key_pair KmipSecretRole#operation_create_key_pair}
        :param operation_decrypt: Grant permission to use the KMIP Decrypt operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_decrypt KmipSecretRole#operation_decrypt}
        :param operation_delete_attribute: Grant permission to use the KMIP Delete Attribute operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_delete_attribute KmipSecretRole#operation_delete_attribute}
        :param operation_destroy: Grant permission to use the KMIP Destroy operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_destroy KmipSecretRole#operation_destroy}
        :param operation_discover_versions: Grant permission to use the KMIP Discover Version operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_discover_versions KmipSecretRole#operation_discover_versions}
        :param operation_encrypt: Grant permission to use the KMIP Encrypt operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_encrypt KmipSecretRole#operation_encrypt}
        :param operation_get: Grant permission to use the KMIP Get operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_get KmipSecretRole#operation_get}
        :param operation_get_attribute_list: Grant permission to use the KMIP Get Attribute List operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_get_attribute_list KmipSecretRole#operation_get_attribute_list}
        :param operation_get_attributes: Grant permission to use the KMIP Get Attributes operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_get_attributes KmipSecretRole#operation_get_attributes}
        :param operation_import: Grant permission to use the KMIP Import operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_import KmipSecretRole#operation_import}
        :param operation_locate: Grant permission to use the KMIP Locate operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_locate KmipSecretRole#operation_locate}
        :param operation_mac: Grant permission to use the KMIP MAC operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_mac KmipSecretRole#operation_mac}
        :param operation_mac_verify: Grant permission to use the KMIP MAC Verify operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_mac_verify KmipSecretRole#operation_mac_verify}
        :param operation_modify_attribute: Grant permission to use the KMIP Modify Attribute operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_modify_attribute KmipSecretRole#operation_modify_attribute}
        :param operation_none: Remove all permissions from this role. May not be specified with any other operation_* params. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_none KmipSecretRole#operation_none}
        :param operation_query: Grant permission to use the KMIP Query operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_query KmipSecretRole#operation_query}
        :param operation_register: Grant permission to use the KMIP Register operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_register KmipSecretRole#operation_register}
        :param operation_rekey: Grant permission to use the KMIP Rekey operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_rekey KmipSecretRole#operation_rekey}
        :param operation_rekey_key_pair: Grant permission to use the KMIP Rekey Key Pair operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_rekey_key_pair KmipSecretRole#operation_rekey_key_pair}
        :param operation_revoke: Grant permission to use the KMIP Revoke operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_revoke KmipSecretRole#operation_revoke}
        :param operation_rng_retrieve: Grant permission to use the KMIP RNG Retrieve operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_rng_retrieve KmipSecretRole#operation_rng_retrieve}
        :param operation_rng_seed: Grant permission to use the KMIP RNG Seed operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_rng_seed KmipSecretRole#operation_rng_seed}
        :param operation_sign: Grant permission to use the KMIP Sign operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_sign KmipSecretRole#operation_sign}
        :param operation_signature_verify: Grant permission to use the KMIP Signature Verify operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_signature_verify KmipSecretRole#operation_signature_verify}
        :param tls_client_key_bits: Client certificate key bits, valid values depend on key type. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#tls_client_key_bits KmipSecretRole#tls_client_key_bits}
        :param tls_client_key_type: Client certificate key type, rsa or ec. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#tls_client_key_type KmipSecretRole#tls_client_key_type}
        :param tls_client_ttl: Client certificate TTL in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#tls_client_ttl KmipSecretRole#tls_client_ttl}
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f13ed3ec02a0672e6f50dce16be296ea4ecbc4bb64730638cf3c60da67e3f641)
            check_type(argname="argument scope_", value=scope_, expected_type=type_hints["scope_"])
            check_type(argname="argument id_", value=id_, expected_type=type_hints["id_"])
        config = KmipSecretRoleConfig(
            path=path,
            role=role,
            scope=scope,
            ca=ca,
            id=id,
            namespace=namespace,
            operation_activate=operation_activate,
            operation_add_attribute=operation_add_attribute,
            operation_all=operation_all,
            operation_create=operation_create,
            operation_create_key_pair=operation_create_key_pair,
            operation_decrypt=operation_decrypt,
            operation_delete_attribute=operation_delete_attribute,
            operation_destroy=operation_destroy,
            operation_discover_versions=operation_discover_versions,
            operation_encrypt=operation_encrypt,
            operation_get=operation_get,
            operation_get_attribute_list=operation_get_attribute_list,
            operation_get_attributes=operation_get_attributes,
            operation_import=operation_import,
            operation_locate=operation_locate,
            operation_mac=operation_mac,
            operation_mac_verify=operation_mac_verify,
            operation_modify_attribute=operation_modify_attribute,
            operation_none=operation_none,
            operation_query=operation_query,
            operation_register=operation_register,
            operation_rekey=operation_rekey,
            operation_rekey_key_pair=operation_rekey_key_pair,
            operation_revoke=operation_revoke,
            operation_rng_retrieve=operation_rng_retrieve,
            operation_rng_seed=operation_rng_seed,
            operation_sign=operation_sign,
            operation_signature_verify=operation_signature_verify,
            tls_client_key_bits=tls_client_key_bits,
            tls_client_key_type=tls_client_key_type,
            tls_client_ttl=tls_client_ttl,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope_, id_, config])

    @jsii.member(jsii_name="generateConfigForImport")
    @builtins.classmethod
    def generate_config_for_import(
        cls,
        scope: "_constructs_77d1e7e8.Construct",
        import_to_id: builtins.str,
        import_from_id: builtins.str,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
    ) -> "_cdktn_78ede62e.ImportableResource":
        '''Generates CDKTN code for importing a KmipSecretRole resource upon running "cdktn plan ".

        :param scope: The scope in which to define this construct.
        :param import_to_id: The construct id used in the generated config for the KmipSecretRole to import.
        :param import_from_id: The id of the existing KmipSecretRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#import import section} in the documentation of this resource for the id to use
        :param provider: ? Optional instance of the provider where the KmipSecretRole to import is found.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c03a7f90e961d0a6a3548a7553397f4c950a9be1e8912039153f41b799448fa2)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument import_to_id", value=import_to_id, expected_type=type_hints["import_to_id"])
            check_type(argname="argument import_from_id", value=import_from_id, expected_type=type_hints["import_from_id"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
        return typing.cast("_cdktn_78ede62e.ImportableResource", jsii.sinvoke(cls, "generateConfigForImport", [scope, import_to_id, import_from_id, provider]))

    @jsii.member(jsii_name="resetCa")
    def reset_ca(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCa", []))

    @jsii.member(jsii_name="resetId")
    def reset_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetId", []))

    @jsii.member(jsii_name="resetNamespace")
    def reset_namespace(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNamespace", []))

    @jsii.member(jsii_name="resetOperationActivate")
    def reset_operation_activate(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperationActivate", []))

    @jsii.member(jsii_name="resetOperationAddAttribute")
    def reset_operation_add_attribute(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperationAddAttribute", []))

    @jsii.member(jsii_name="resetOperationAll")
    def reset_operation_all(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperationAll", []))

    @jsii.member(jsii_name="resetOperationCreate")
    def reset_operation_create(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperationCreate", []))

    @jsii.member(jsii_name="resetOperationCreateKeyPair")
    def reset_operation_create_key_pair(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperationCreateKeyPair", []))

    @jsii.member(jsii_name="resetOperationDecrypt")
    def reset_operation_decrypt(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperationDecrypt", []))

    @jsii.member(jsii_name="resetOperationDeleteAttribute")
    def reset_operation_delete_attribute(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperationDeleteAttribute", []))

    @jsii.member(jsii_name="resetOperationDestroy")
    def reset_operation_destroy(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperationDestroy", []))

    @jsii.member(jsii_name="resetOperationDiscoverVersions")
    def reset_operation_discover_versions(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperationDiscoverVersions", []))

    @jsii.member(jsii_name="resetOperationEncrypt")
    def reset_operation_encrypt(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperationEncrypt", []))

    @jsii.member(jsii_name="resetOperationGet")
    def reset_operation_get(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperationGet", []))

    @jsii.member(jsii_name="resetOperationGetAttributeList")
    def reset_operation_get_attribute_list(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperationGetAttributeList", []))

    @jsii.member(jsii_name="resetOperationGetAttributes")
    def reset_operation_get_attributes(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperationGetAttributes", []))

    @jsii.member(jsii_name="resetOperationImport")
    def reset_operation_import(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperationImport", []))

    @jsii.member(jsii_name="resetOperationLocate")
    def reset_operation_locate(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperationLocate", []))

    @jsii.member(jsii_name="resetOperationMac")
    def reset_operation_mac(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperationMac", []))

    @jsii.member(jsii_name="resetOperationMacVerify")
    def reset_operation_mac_verify(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperationMacVerify", []))

    @jsii.member(jsii_name="resetOperationModifyAttribute")
    def reset_operation_modify_attribute(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperationModifyAttribute", []))

    @jsii.member(jsii_name="resetOperationNone")
    def reset_operation_none(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperationNone", []))

    @jsii.member(jsii_name="resetOperationQuery")
    def reset_operation_query(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperationQuery", []))

    @jsii.member(jsii_name="resetOperationRegister")
    def reset_operation_register(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperationRegister", []))

    @jsii.member(jsii_name="resetOperationRekey")
    def reset_operation_rekey(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperationRekey", []))

    @jsii.member(jsii_name="resetOperationRekeyKeyPair")
    def reset_operation_rekey_key_pair(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperationRekeyKeyPair", []))

    @jsii.member(jsii_name="resetOperationRevoke")
    def reset_operation_revoke(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperationRevoke", []))

    @jsii.member(jsii_name="resetOperationRngRetrieve")
    def reset_operation_rng_retrieve(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperationRngRetrieve", []))

    @jsii.member(jsii_name="resetOperationRngSeed")
    def reset_operation_rng_seed(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperationRngSeed", []))

    @jsii.member(jsii_name="resetOperationSign")
    def reset_operation_sign(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperationSign", []))

    @jsii.member(jsii_name="resetOperationSignatureVerify")
    def reset_operation_signature_verify(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOperationSignatureVerify", []))

    @jsii.member(jsii_name="resetTlsClientKeyBits")
    def reset_tls_client_key_bits(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTlsClientKeyBits", []))

    @jsii.member(jsii_name="resetTlsClientKeyType")
    def reset_tls_client_key_type(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTlsClientKeyType", []))

    @jsii.member(jsii_name="resetTlsClientTtl")
    def reset_tls_client_ttl(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTlsClientTtl", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.member(jsii_name="synthesizeHclAttributes")
    def _synthesize_hcl_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeHclAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="caInput")
    def ca_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "caInput"))

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="namespaceInput")
    def namespace_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "namespaceInput"))

    @builtins.property
    @jsii.member(jsii_name="operationActivateInput")
    def operation_activate_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "operationActivateInput"))

    @builtins.property
    @jsii.member(jsii_name="operationAddAttributeInput")
    def operation_add_attribute_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "operationAddAttributeInput"))

    @builtins.property
    @jsii.member(jsii_name="operationAllInput")
    def operation_all_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "operationAllInput"))

    @builtins.property
    @jsii.member(jsii_name="operationCreateInput")
    def operation_create_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "operationCreateInput"))

    @builtins.property
    @jsii.member(jsii_name="operationCreateKeyPairInput")
    def operation_create_key_pair_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "operationCreateKeyPairInput"))

    @builtins.property
    @jsii.member(jsii_name="operationDecryptInput")
    def operation_decrypt_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "operationDecryptInput"))

    @builtins.property
    @jsii.member(jsii_name="operationDeleteAttributeInput")
    def operation_delete_attribute_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "operationDeleteAttributeInput"))

    @builtins.property
    @jsii.member(jsii_name="operationDestroyInput")
    def operation_destroy_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "operationDestroyInput"))

    @builtins.property
    @jsii.member(jsii_name="operationDiscoverVersionsInput")
    def operation_discover_versions_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "operationDiscoverVersionsInput"))

    @builtins.property
    @jsii.member(jsii_name="operationEncryptInput")
    def operation_encrypt_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "operationEncryptInput"))

    @builtins.property
    @jsii.member(jsii_name="operationGetAttributeListInput")
    def operation_get_attribute_list_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "operationGetAttributeListInput"))

    @builtins.property
    @jsii.member(jsii_name="operationGetAttributesInput")
    def operation_get_attributes_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "operationGetAttributesInput"))

    @builtins.property
    @jsii.member(jsii_name="operationGetInput")
    def operation_get_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "operationGetInput"))

    @builtins.property
    @jsii.member(jsii_name="operationImportInput")
    def operation_import_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "operationImportInput"))

    @builtins.property
    @jsii.member(jsii_name="operationLocateInput")
    def operation_locate_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "operationLocateInput"))

    @builtins.property
    @jsii.member(jsii_name="operationMacInput")
    def operation_mac_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "operationMacInput"))

    @builtins.property
    @jsii.member(jsii_name="operationMacVerifyInput")
    def operation_mac_verify_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "operationMacVerifyInput"))

    @builtins.property
    @jsii.member(jsii_name="operationModifyAttributeInput")
    def operation_modify_attribute_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "operationModifyAttributeInput"))

    @builtins.property
    @jsii.member(jsii_name="operationNoneInput")
    def operation_none_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "operationNoneInput"))

    @builtins.property
    @jsii.member(jsii_name="operationQueryInput")
    def operation_query_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "operationQueryInput"))

    @builtins.property
    @jsii.member(jsii_name="operationRegisterInput")
    def operation_register_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "operationRegisterInput"))

    @builtins.property
    @jsii.member(jsii_name="operationRekeyInput")
    def operation_rekey_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "operationRekeyInput"))

    @builtins.property
    @jsii.member(jsii_name="operationRekeyKeyPairInput")
    def operation_rekey_key_pair_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "operationRekeyKeyPairInput"))

    @builtins.property
    @jsii.member(jsii_name="operationRevokeInput")
    def operation_revoke_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "operationRevokeInput"))

    @builtins.property
    @jsii.member(jsii_name="operationRngRetrieveInput")
    def operation_rng_retrieve_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "operationRngRetrieveInput"))

    @builtins.property
    @jsii.member(jsii_name="operationRngSeedInput")
    def operation_rng_seed_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "operationRngSeedInput"))

    @builtins.property
    @jsii.member(jsii_name="operationSignatureVerifyInput")
    def operation_signature_verify_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "operationSignatureVerifyInput"))

    @builtins.property
    @jsii.member(jsii_name="operationSignInput")
    def operation_sign_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "operationSignInput"))

    @builtins.property
    @jsii.member(jsii_name="pathInput")
    def path_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "pathInput"))

    @builtins.property
    @jsii.member(jsii_name="roleInput")
    def role_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "roleInput"))

    @builtins.property
    @jsii.member(jsii_name="scopeInput")
    def scope_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "scopeInput"))

    @builtins.property
    @jsii.member(jsii_name="tlsClientKeyBitsInput")
    def tls_client_key_bits_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "tlsClientKeyBitsInput"))

    @builtins.property
    @jsii.member(jsii_name="tlsClientKeyTypeInput")
    def tls_client_key_type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "tlsClientKeyTypeInput"))

    @builtins.property
    @jsii.member(jsii_name="tlsClientTtlInput")
    def tls_client_ttl_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "tlsClientTtlInput"))

    @builtins.property
    @jsii.member(jsii_name="ca")
    def ca(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "ca"))

    @ca.setter
    def ca(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ab6805a7370b2d8d1dc2f567fe68a227b3430298fc9e42d34fb5703eab6f270d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "ca", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @id.setter
    def id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e63a20968faf6b2d3a65e08a41e55059560b25b8cad97275543bfbe2547a3bc3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="namespace")
    def namespace(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "namespace"))

    @namespace.setter
    def namespace(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4dd4b0e79bf419aafd9022e4a7ce72c53b4c17a5b992b1e739e41125f8a5935e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "namespace", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operationActivate")
    def operation_activate(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "operationActivate"))

    @operation_activate.setter
    def operation_activate(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__56415085bbda9e0349949b6d0b62517a313023cced4a2b3670975514247efe10)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operationActivate", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operationAddAttribute")
    def operation_add_attribute(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "operationAddAttribute"))

    @operation_add_attribute.setter
    def operation_add_attribute(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dfc78b409f8597eb8b63f2a50757458d326bf759cc3b1fd1622ff88af6b2efed)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operationAddAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operationAll")
    def operation_all(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "operationAll"))

    @operation_all.setter
    def operation_all(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e82cb30aab3fa6d1dbe940d470c185ce3805c8f01fa1467dc8a7218d23bf30b8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operationAll", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operationCreate")
    def operation_create(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "operationCreate"))

    @operation_create.setter
    def operation_create(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ee7339926b308baa570a8f87e288a57f8b6e8ad8482800a4c358e34ec0a14b9c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operationCreate", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operationCreateKeyPair")
    def operation_create_key_pair(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "operationCreateKeyPair"))

    @operation_create_key_pair.setter
    def operation_create_key_pair(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bf22f96b006658603a752d2e034dc1648eb2224bb2f0d90a3f7e4b62b0ddd1ce)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operationCreateKeyPair", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operationDecrypt")
    def operation_decrypt(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "operationDecrypt"))

    @operation_decrypt.setter
    def operation_decrypt(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6f29be6eb31a573b7e672e351ec58cb809c2651422efd6fb8f27d3c7b28ff885)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operationDecrypt", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operationDeleteAttribute")
    def operation_delete_attribute(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "operationDeleteAttribute"))

    @operation_delete_attribute.setter
    def operation_delete_attribute(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f7ffbc21a50eb4a889cc4178d7eb3d4e54b9e0907d428b00227eddf465620236)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operationDeleteAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operationDestroy")
    def operation_destroy(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "operationDestroy"))

    @operation_destroy.setter
    def operation_destroy(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f5597267c7232cf14ac204d739554c4b9dd9a5bb8e6a76168dfab94e2a54fa59)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operationDestroy", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operationDiscoverVersions")
    def operation_discover_versions(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "operationDiscoverVersions"))

    @operation_discover_versions.setter
    def operation_discover_versions(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0ddc6340a088e2a4baaf4fac428a9500856eaf3a8e7b9a22dab1e7c0414b3cf2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operationDiscoverVersions", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operationEncrypt")
    def operation_encrypt(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "operationEncrypt"))

    @operation_encrypt.setter
    def operation_encrypt(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7e84c292f3b03ad605a8cbbb44a4dd0be17d2e5e59e252f98ec7550179e8f4d2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operationEncrypt", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operationGet")
    def operation_get(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "operationGet"))

    @operation_get.setter
    def operation_get(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dcd085b9977449de0ec6b39107dd45ce1fb9aa8c419f47ef05580af333175ee7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operationGet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operationGetAttributeList")
    def operation_get_attribute_list(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "operationGetAttributeList"))

    @operation_get_attribute_list.setter
    def operation_get_attribute_list(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fd8a963217e16a8b36b0589b0988c009e06b09a5a7d71793d340f028a776384b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operationGetAttributeList", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operationGetAttributes")
    def operation_get_attributes(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "operationGetAttributes"))

    @operation_get_attributes.setter
    def operation_get_attributes(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8ca9a5ad84ac5d723ef32a584e95382defc7440dc3e53402a0b0d6072bf8f659)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operationGetAttributes", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operationImport")
    def operation_import(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "operationImport"))

    @operation_import.setter
    def operation_import(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__436264d7b342223e1d34bb2f076128a5a48c41729d13e791e16b52dbe406869b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operationImport", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operationLocate")
    def operation_locate(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "operationLocate"))

    @operation_locate.setter
    def operation_locate(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d72fce5ad029f544c0b8be5ded2e981f8238250f1e9fd2f6ca28f4b6beff83dd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operationLocate", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operationMac")
    def operation_mac(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "operationMac"))

    @operation_mac.setter
    def operation_mac(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6595e38bf4f20b932af734e6433f1549b5c80c70a3f6d718829febd7dc58752d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operationMac", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operationMacVerify")
    def operation_mac_verify(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "operationMacVerify"))

    @operation_mac_verify.setter
    def operation_mac_verify(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__28a0a5760aae2263a37d354699025c8580876513305e3369bb85cecb39fcca5c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operationMacVerify", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operationModifyAttribute")
    def operation_modify_attribute(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "operationModifyAttribute"))

    @operation_modify_attribute.setter
    def operation_modify_attribute(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2cf6446258497ee85d088ec3e7bf8a1edb50bba988f04c5937e9d3f7b19daaa2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operationModifyAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operationNone")
    def operation_none(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "operationNone"))

    @operation_none.setter
    def operation_none(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__69c8964236d10f6cac4e6897a85100cb1c4fec6b6a9848aac177739a2324d056)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operationNone", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operationQuery")
    def operation_query(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "operationQuery"))

    @operation_query.setter
    def operation_query(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__adbc3244bf7241f174c931c984df235c88266c654fb175c09b271d538f3bf113)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operationQuery", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operationRegister")
    def operation_register(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "operationRegister"))

    @operation_register.setter
    def operation_register(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fa71d985bf21969509c7f1be58380a21dcb0fc445b702b89fe25ab775ee4ea2a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operationRegister", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operationRekey")
    def operation_rekey(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "operationRekey"))

    @operation_rekey.setter
    def operation_rekey(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__efe9c97d3cca19fe85d1bc35edabeed00192a985b86ee7a1b542c89feb0ade07)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operationRekey", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operationRekeyKeyPair")
    def operation_rekey_key_pair(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "operationRekeyKeyPair"))

    @operation_rekey_key_pair.setter
    def operation_rekey_key_pair(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2a1276119af8c10a9ecbfa6f5701ebe22a1908e0d2e8da26c9e91a417c799f7f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operationRekeyKeyPair", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operationRevoke")
    def operation_revoke(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "operationRevoke"))

    @operation_revoke.setter
    def operation_revoke(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__721d5226db8f8364f4f6348d0aae4bd478574ed8868be481dd756746257bedc1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operationRevoke", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operationRngRetrieve")
    def operation_rng_retrieve(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "operationRngRetrieve"))

    @operation_rng_retrieve.setter
    def operation_rng_retrieve(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a7293df4cfcdd8263d66f44fb7fbd2b0544ca4733dcac1f3f0cc1c0c95c53c1c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operationRngRetrieve", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operationRngSeed")
    def operation_rng_seed(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "operationRngSeed"))

    @operation_rng_seed.setter
    def operation_rng_seed(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1077fe6c2bca90163f68c6ddefff3d365acbac85ff1693544f7b8519c0badfbd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operationRngSeed", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operationSign")
    def operation_sign(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "operationSign"))

    @operation_sign.setter
    def operation_sign(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4fc760ad23c9f051cad5454ef1378ab7a4a598fa1c2c6b1078dbde4a928e07d8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operationSign", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operationSignatureVerify")
    def operation_signature_verify(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "operationSignatureVerify"))

    @operation_signature_verify.setter
    def operation_signature_verify(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7a5c934a2347a72e0f05ea43a26750bb8aab858db4102da9833175ef72d148c5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operationSignatureVerify", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="path")
    def path(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "path"))

    @path.setter
    def path(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__80552c3d659f58a7256275de6d24089835df802003fe0ae75e4ee51ac2dfef00)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "path", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="role")
    def role(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "role"))

    @role.setter
    def role(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0bbe444e703f528a30a6e4ce804ebaf813d8beb5885d8e5f500d483465d39a94)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "role", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="scope")
    def scope(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "scope"))

    @scope.setter
    def scope(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6935014e0d07b36664c2058f52709533559dea6a32cf2bf985d38c594a4e8845)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "scope", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="tlsClientKeyBits")
    def tls_client_key_bits(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "tlsClientKeyBits"))

    @tls_client_key_bits.setter
    def tls_client_key_bits(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d0e0494ce9661b9c5ba67e2ed710e642f2b3ca8fa30f45102cfd0ed85a89dc11)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "tlsClientKeyBits", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="tlsClientKeyType")
    def tls_client_key_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "tlsClientKeyType"))

    @tls_client_key_type.setter
    def tls_client_key_type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d1dc2a2ade0966ce6e3c6c96a2862b6544fa4440bb8b70a29492eb141eef21c8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "tlsClientKeyType", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="tlsClientTtl")
    def tls_client_ttl(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "tlsClientTtl"))

    @tls_client_ttl.setter
    def tls_client_ttl(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__930446ba62be785582836da9a65cf8367521e5258b90783d503ad83f9b35454d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "tlsClientTtl", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-vault.kmipSecretRole.KmipSecretRoleConfig",
    jsii_struct_bases=[_cdktn_78ede62e.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "path": "path",
        "role": "role",
        "scope": "scope",
        "ca": "ca",
        "id": "id",
        "namespace": "namespace",
        "operation_activate": "operationActivate",
        "operation_add_attribute": "operationAddAttribute",
        "operation_all": "operationAll",
        "operation_create": "operationCreate",
        "operation_create_key_pair": "operationCreateKeyPair",
        "operation_decrypt": "operationDecrypt",
        "operation_delete_attribute": "operationDeleteAttribute",
        "operation_destroy": "operationDestroy",
        "operation_discover_versions": "operationDiscoverVersions",
        "operation_encrypt": "operationEncrypt",
        "operation_get": "operationGet",
        "operation_get_attribute_list": "operationGetAttributeList",
        "operation_get_attributes": "operationGetAttributes",
        "operation_import": "operationImport",
        "operation_locate": "operationLocate",
        "operation_mac": "operationMac",
        "operation_mac_verify": "operationMacVerify",
        "operation_modify_attribute": "operationModifyAttribute",
        "operation_none": "operationNone",
        "operation_query": "operationQuery",
        "operation_register": "operationRegister",
        "operation_rekey": "operationRekey",
        "operation_rekey_key_pair": "operationRekeyKeyPair",
        "operation_revoke": "operationRevoke",
        "operation_rng_retrieve": "operationRngRetrieve",
        "operation_rng_seed": "operationRngSeed",
        "operation_sign": "operationSign",
        "operation_signature_verify": "operationSignatureVerify",
        "tls_client_key_bits": "tlsClientKeyBits",
        "tls_client_key_type": "tlsClientKeyType",
        "tls_client_ttl": "tlsClientTtl",
    },
)
class KmipSecretRoleConfig(_cdktn_78ede62e.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
        path: builtins.str,
        role: builtins.str,
        scope: builtins.str,
        ca: typing.Optional[builtins.str] = None,
        id: typing.Optional[builtins.str] = None,
        namespace: typing.Optional[builtins.str] = None,
        operation_activate: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_add_attribute: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_all: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_create: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_create_key_pair: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_decrypt: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_delete_attribute: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_destroy: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_discover_versions: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_encrypt: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_get: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_get_attribute_list: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_get_attributes: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_import: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_locate: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_mac: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_mac_verify: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_modify_attribute: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_none: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_query: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_register: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_rekey: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_rekey_key_pair: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_revoke: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_rng_retrieve: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_rng_seed: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_sign: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        operation_signature_verify: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        tls_client_key_bits: typing.Optional[jsii.Number] = None,
        tls_client_key_type: typing.Optional[builtins.str] = None,
        tls_client_ttl: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param path: Path where KMIP backend is mounted. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#path KmipSecretRole#path}
        :param role: Name of the role. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#role KmipSecretRole#role}
        :param scope: Name of the scope. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#scope KmipSecretRole#scope}
        :param ca: Name of the ca to use, if absent use legacy ca. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#ca KmipSecretRole#ca}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#id KmipSecretRole#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param namespace: Target namespace. (requires Enterprise). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#namespace KmipSecretRole#namespace}
        :param operation_activate: Grant permission to use the KMIP Activate operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_activate KmipSecretRole#operation_activate}
        :param operation_add_attribute: Grant permission to use the KMIP Add Attribute operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_add_attribute KmipSecretRole#operation_add_attribute}
        :param operation_all: Grant all permissions to this role. May not be specified with any other operation_* params. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_all KmipSecretRole#operation_all}
        :param operation_create: Grant permission to use the KMIP Create operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_create KmipSecretRole#operation_create}
        :param operation_create_key_pair: Grant permission to use the KMIP Create Key Pair operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_create_key_pair KmipSecretRole#operation_create_key_pair}
        :param operation_decrypt: Grant permission to use the KMIP Decrypt operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_decrypt KmipSecretRole#operation_decrypt}
        :param operation_delete_attribute: Grant permission to use the KMIP Delete Attribute operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_delete_attribute KmipSecretRole#operation_delete_attribute}
        :param operation_destroy: Grant permission to use the KMIP Destroy operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_destroy KmipSecretRole#operation_destroy}
        :param operation_discover_versions: Grant permission to use the KMIP Discover Version operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_discover_versions KmipSecretRole#operation_discover_versions}
        :param operation_encrypt: Grant permission to use the KMIP Encrypt operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_encrypt KmipSecretRole#operation_encrypt}
        :param operation_get: Grant permission to use the KMIP Get operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_get KmipSecretRole#operation_get}
        :param operation_get_attribute_list: Grant permission to use the KMIP Get Attribute List operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_get_attribute_list KmipSecretRole#operation_get_attribute_list}
        :param operation_get_attributes: Grant permission to use the KMIP Get Attributes operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_get_attributes KmipSecretRole#operation_get_attributes}
        :param operation_import: Grant permission to use the KMIP Import operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_import KmipSecretRole#operation_import}
        :param operation_locate: Grant permission to use the KMIP Locate operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_locate KmipSecretRole#operation_locate}
        :param operation_mac: Grant permission to use the KMIP MAC operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_mac KmipSecretRole#operation_mac}
        :param operation_mac_verify: Grant permission to use the KMIP MAC Verify operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_mac_verify KmipSecretRole#operation_mac_verify}
        :param operation_modify_attribute: Grant permission to use the KMIP Modify Attribute operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_modify_attribute KmipSecretRole#operation_modify_attribute}
        :param operation_none: Remove all permissions from this role. May not be specified with any other operation_* params. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_none KmipSecretRole#operation_none}
        :param operation_query: Grant permission to use the KMIP Query operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_query KmipSecretRole#operation_query}
        :param operation_register: Grant permission to use the KMIP Register operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_register KmipSecretRole#operation_register}
        :param operation_rekey: Grant permission to use the KMIP Rekey operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_rekey KmipSecretRole#operation_rekey}
        :param operation_rekey_key_pair: Grant permission to use the KMIP Rekey Key Pair operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_rekey_key_pair KmipSecretRole#operation_rekey_key_pair}
        :param operation_revoke: Grant permission to use the KMIP Revoke operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_revoke KmipSecretRole#operation_revoke}
        :param operation_rng_retrieve: Grant permission to use the KMIP RNG Retrieve operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_rng_retrieve KmipSecretRole#operation_rng_retrieve}
        :param operation_rng_seed: Grant permission to use the KMIP RNG Seed operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_rng_seed KmipSecretRole#operation_rng_seed}
        :param operation_sign: Grant permission to use the KMIP Sign operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_sign KmipSecretRole#operation_sign}
        :param operation_signature_verify: Grant permission to use the KMIP Signature Verify operation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_signature_verify KmipSecretRole#operation_signature_verify}
        :param tls_client_key_bits: Client certificate key bits, valid values depend on key type. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#tls_client_key_bits KmipSecretRole#tls_client_key_bits}
        :param tls_client_key_type: Client certificate key type, rsa or ec. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#tls_client_key_type KmipSecretRole#tls_client_key_type}
        :param tls_client_ttl: Client certificate TTL in seconds. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#tls_client_ttl KmipSecretRole#tls_client_ttl}
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__17c124bec735b061a2614d9c2a2e3ce979c80eb1cbdd5b5a37c6b55f0959eb97)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument path", value=path, expected_type=type_hints["path"])
            check_type(argname="argument role", value=role, expected_type=type_hints["role"])
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument ca", value=ca, expected_type=type_hints["ca"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument namespace", value=namespace, expected_type=type_hints["namespace"])
            check_type(argname="argument operation_activate", value=operation_activate, expected_type=type_hints["operation_activate"])
            check_type(argname="argument operation_add_attribute", value=operation_add_attribute, expected_type=type_hints["operation_add_attribute"])
            check_type(argname="argument operation_all", value=operation_all, expected_type=type_hints["operation_all"])
            check_type(argname="argument operation_create", value=operation_create, expected_type=type_hints["operation_create"])
            check_type(argname="argument operation_create_key_pair", value=operation_create_key_pair, expected_type=type_hints["operation_create_key_pair"])
            check_type(argname="argument operation_decrypt", value=operation_decrypt, expected_type=type_hints["operation_decrypt"])
            check_type(argname="argument operation_delete_attribute", value=operation_delete_attribute, expected_type=type_hints["operation_delete_attribute"])
            check_type(argname="argument operation_destroy", value=operation_destroy, expected_type=type_hints["operation_destroy"])
            check_type(argname="argument operation_discover_versions", value=operation_discover_versions, expected_type=type_hints["operation_discover_versions"])
            check_type(argname="argument operation_encrypt", value=operation_encrypt, expected_type=type_hints["operation_encrypt"])
            check_type(argname="argument operation_get", value=operation_get, expected_type=type_hints["operation_get"])
            check_type(argname="argument operation_get_attribute_list", value=operation_get_attribute_list, expected_type=type_hints["operation_get_attribute_list"])
            check_type(argname="argument operation_get_attributes", value=operation_get_attributes, expected_type=type_hints["operation_get_attributes"])
            check_type(argname="argument operation_import", value=operation_import, expected_type=type_hints["operation_import"])
            check_type(argname="argument operation_locate", value=operation_locate, expected_type=type_hints["operation_locate"])
            check_type(argname="argument operation_mac", value=operation_mac, expected_type=type_hints["operation_mac"])
            check_type(argname="argument operation_mac_verify", value=operation_mac_verify, expected_type=type_hints["operation_mac_verify"])
            check_type(argname="argument operation_modify_attribute", value=operation_modify_attribute, expected_type=type_hints["operation_modify_attribute"])
            check_type(argname="argument operation_none", value=operation_none, expected_type=type_hints["operation_none"])
            check_type(argname="argument operation_query", value=operation_query, expected_type=type_hints["operation_query"])
            check_type(argname="argument operation_register", value=operation_register, expected_type=type_hints["operation_register"])
            check_type(argname="argument operation_rekey", value=operation_rekey, expected_type=type_hints["operation_rekey"])
            check_type(argname="argument operation_rekey_key_pair", value=operation_rekey_key_pair, expected_type=type_hints["operation_rekey_key_pair"])
            check_type(argname="argument operation_revoke", value=operation_revoke, expected_type=type_hints["operation_revoke"])
            check_type(argname="argument operation_rng_retrieve", value=operation_rng_retrieve, expected_type=type_hints["operation_rng_retrieve"])
            check_type(argname="argument operation_rng_seed", value=operation_rng_seed, expected_type=type_hints["operation_rng_seed"])
            check_type(argname="argument operation_sign", value=operation_sign, expected_type=type_hints["operation_sign"])
            check_type(argname="argument operation_signature_verify", value=operation_signature_verify, expected_type=type_hints["operation_signature_verify"])
            check_type(argname="argument tls_client_key_bits", value=tls_client_key_bits, expected_type=type_hints["tls_client_key_bits"])
            check_type(argname="argument tls_client_key_type", value=tls_client_key_type, expected_type=type_hints["tls_client_key_type"])
            check_type(argname="argument tls_client_ttl", value=tls_client_ttl, expected_type=type_hints["tls_client_ttl"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "path": path,
            "role": role,
            "scope": scope,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if ca is not None:
            self._values["ca"] = ca
        if id is not None:
            self._values["id"] = id
        if namespace is not None:
            self._values["namespace"] = namespace
        if operation_activate is not None:
            self._values["operation_activate"] = operation_activate
        if operation_add_attribute is not None:
            self._values["operation_add_attribute"] = operation_add_attribute
        if operation_all is not None:
            self._values["operation_all"] = operation_all
        if operation_create is not None:
            self._values["operation_create"] = operation_create
        if operation_create_key_pair is not None:
            self._values["operation_create_key_pair"] = operation_create_key_pair
        if operation_decrypt is not None:
            self._values["operation_decrypt"] = operation_decrypt
        if operation_delete_attribute is not None:
            self._values["operation_delete_attribute"] = operation_delete_attribute
        if operation_destroy is not None:
            self._values["operation_destroy"] = operation_destroy
        if operation_discover_versions is not None:
            self._values["operation_discover_versions"] = operation_discover_versions
        if operation_encrypt is not None:
            self._values["operation_encrypt"] = operation_encrypt
        if operation_get is not None:
            self._values["operation_get"] = operation_get
        if operation_get_attribute_list is not None:
            self._values["operation_get_attribute_list"] = operation_get_attribute_list
        if operation_get_attributes is not None:
            self._values["operation_get_attributes"] = operation_get_attributes
        if operation_import is not None:
            self._values["operation_import"] = operation_import
        if operation_locate is not None:
            self._values["operation_locate"] = operation_locate
        if operation_mac is not None:
            self._values["operation_mac"] = operation_mac
        if operation_mac_verify is not None:
            self._values["operation_mac_verify"] = operation_mac_verify
        if operation_modify_attribute is not None:
            self._values["operation_modify_attribute"] = operation_modify_attribute
        if operation_none is not None:
            self._values["operation_none"] = operation_none
        if operation_query is not None:
            self._values["operation_query"] = operation_query
        if operation_register is not None:
            self._values["operation_register"] = operation_register
        if operation_rekey is not None:
            self._values["operation_rekey"] = operation_rekey
        if operation_rekey_key_pair is not None:
            self._values["operation_rekey_key_pair"] = operation_rekey_key_pair
        if operation_revoke is not None:
            self._values["operation_revoke"] = operation_revoke
        if operation_rng_retrieve is not None:
            self._values["operation_rng_retrieve"] = operation_rng_retrieve
        if operation_rng_seed is not None:
            self._values["operation_rng_seed"] = operation_rng_seed
        if operation_sign is not None:
            self._values["operation_sign"] = operation_sign
        if operation_signature_verify is not None:
            self._values["operation_signature_verify"] = operation_signature_verify
        if tls_client_key_bits is not None:
            self._values["tls_client_key_bits"] = tls_client_key_bits
        if tls_client_key_type is not None:
            self._values["tls_client_key_type"] = tls_client_key_type
        if tls_client_ttl is not None:
            self._values["tls_client_ttl"] = tls_client_ttl

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]], result)

    @builtins.property
    def for_each(self) -> typing.Optional["_cdktn_78ede62e.ITerraformIterator"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional["_cdktn_78ede62e.ITerraformIterator"], result)

    @builtins.property
    def lifecycle(
        self,
    ) -> typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"], result)

    @builtins.property
    def provider(self) -> typing.Optional["_cdktn_78ede62e.TerraformProvider"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformProvider"], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]], result)

    @builtins.property
    def path(self) -> builtins.str:
        '''Path where KMIP backend is mounted.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#path KmipSecretRole#path}
        '''
        result = self._values.get("path")
        assert result is not None, "Required property 'path' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def role(self) -> builtins.str:
        '''Name of the role.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#role KmipSecretRole#role}
        '''
        result = self._values.get("role")
        assert result is not None, "Required property 'role' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def scope(self) -> builtins.str:
        '''Name of the scope.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#scope KmipSecretRole#scope}
        '''
        result = self._values.get("scope")
        assert result is not None, "Required property 'scope' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def ca(self) -> typing.Optional[builtins.str]:
        '''Name of the ca to use, if absent use legacy ca.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#ca KmipSecretRole#ca}
        '''
        result = self._values.get("ca")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def id(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#id KmipSecretRole#id}.

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def namespace(self) -> typing.Optional[builtins.str]:
        '''Target namespace. (requires Enterprise).

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#namespace KmipSecretRole#namespace}
        '''
        result = self._values.get("namespace")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def operation_activate(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Grant permission to use the KMIP Activate operation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_activate KmipSecretRole#operation_activate}
        '''
        result = self._values.get("operation_activate")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def operation_add_attribute(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Grant permission to use the KMIP Add Attribute operation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_add_attribute KmipSecretRole#operation_add_attribute}
        '''
        result = self._values.get("operation_add_attribute")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def operation_all(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Grant all permissions to this role. May not be specified with any other operation_* params.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_all KmipSecretRole#operation_all}
        '''
        result = self._values.get("operation_all")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def operation_create(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Grant permission to use the KMIP Create operation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_create KmipSecretRole#operation_create}
        '''
        result = self._values.get("operation_create")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def operation_create_key_pair(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Grant permission to use the KMIP Create Key Pair operation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_create_key_pair KmipSecretRole#operation_create_key_pair}
        '''
        result = self._values.get("operation_create_key_pair")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def operation_decrypt(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Grant permission to use the KMIP Decrypt operation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_decrypt KmipSecretRole#operation_decrypt}
        '''
        result = self._values.get("operation_decrypt")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def operation_delete_attribute(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Grant permission to use the KMIP Delete Attribute operation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_delete_attribute KmipSecretRole#operation_delete_attribute}
        '''
        result = self._values.get("operation_delete_attribute")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def operation_destroy(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Grant permission to use the KMIP Destroy operation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_destroy KmipSecretRole#operation_destroy}
        '''
        result = self._values.get("operation_destroy")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def operation_discover_versions(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Grant permission to use the KMIP Discover Version operation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_discover_versions KmipSecretRole#operation_discover_versions}
        '''
        result = self._values.get("operation_discover_versions")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def operation_encrypt(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Grant permission to use the KMIP Encrypt operation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_encrypt KmipSecretRole#operation_encrypt}
        '''
        result = self._values.get("operation_encrypt")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def operation_get(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Grant permission to use the KMIP Get operation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_get KmipSecretRole#operation_get}
        '''
        result = self._values.get("operation_get")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def operation_get_attribute_list(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Grant permission to use the KMIP Get Attribute List operation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_get_attribute_list KmipSecretRole#operation_get_attribute_list}
        '''
        result = self._values.get("operation_get_attribute_list")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def operation_get_attributes(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Grant permission to use the KMIP Get Attributes operation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_get_attributes KmipSecretRole#operation_get_attributes}
        '''
        result = self._values.get("operation_get_attributes")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def operation_import(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Grant permission to use the KMIP Import operation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_import KmipSecretRole#operation_import}
        '''
        result = self._values.get("operation_import")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def operation_locate(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Grant permission to use the KMIP Locate operation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_locate KmipSecretRole#operation_locate}
        '''
        result = self._values.get("operation_locate")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def operation_mac(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Grant permission to use the KMIP MAC operation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_mac KmipSecretRole#operation_mac}
        '''
        result = self._values.get("operation_mac")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def operation_mac_verify(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Grant permission to use the KMIP MAC Verify operation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_mac_verify KmipSecretRole#operation_mac_verify}
        '''
        result = self._values.get("operation_mac_verify")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def operation_modify_attribute(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Grant permission to use the KMIP Modify Attribute operation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_modify_attribute KmipSecretRole#operation_modify_attribute}
        '''
        result = self._values.get("operation_modify_attribute")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def operation_none(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Remove all permissions from this role. May not be specified with any other operation_* params.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_none KmipSecretRole#operation_none}
        '''
        result = self._values.get("operation_none")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def operation_query(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Grant permission to use the KMIP Query operation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_query KmipSecretRole#operation_query}
        '''
        result = self._values.get("operation_query")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def operation_register(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Grant permission to use the KMIP Register operation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_register KmipSecretRole#operation_register}
        '''
        result = self._values.get("operation_register")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def operation_rekey(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Grant permission to use the KMIP Rekey operation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_rekey KmipSecretRole#operation_rekey}
        '''
        result = self._values.get("operation_rekey")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def operation_rekey_key_pair(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Grant permission to use the KMIP Rekey Key Pair operation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_rekey_key_pair KmipSecretRole#operation_rekey_key_pair}
        '''
        result = self._values.get("operation_rekey_key_pair")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def operation_revoke(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Grant permission to use the KMIP Revoke operation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_revoke KmipSecretRole#operation_revoke}
        '''
        result = self._values.get("operation_revoke")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def operation_rng_retrieve(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Grant permission to use the KMIP RNG Retrieve operation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_rng_retrieve KmipSecretRole#operation_rng_retrieve}
        '''
        result = self._values.get("operation_rng_retrieve")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def operation_rng_seed(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Grant permission to use the KMIP RNG Seed operation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_rng_seed KmipSecretRole#operation_rng_seed}
        '''
        result = self._values.get("operation_rng_seed")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def operation_sign(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Grant permission to use the KMIP Sign operation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_sign KmipSecretRole#operation_sign}
        '''
        result = self._values.get("operation_sign")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def operation_signature_verify(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Grant permission to use the KMIP Signature Verify operation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#operation_signature_verify KmipSecretRole#operation_signature_verify}
        '''
        result = self._values.get("operation_signature_verify")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def tls_client_key_bits(self) -> typing.Optional[jsii.Number]:
        '''Client certificate key bits, valid values depend on key type.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#tls_client_key_bits KmipSecretRole#tls_client_key_bits}
        '''
        result = self._values.get("tls_client_key_bits")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def tls_client_key_type(self) -> typing.Optional[builtins.str]:
        '''Client certificate key type, rsa or ec.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#tls_client_key_type KmipSecretRole#tls_client_key_type}
        '''
        result = self._values.get("tls_client_key_type")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def tls_client_ttl(self) -> typing.Optional[jsii.Number]:
        '''Client certificate TTL in seconds.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/kmip_secret_role#tls_client_ttl KmipSecretRole#tls_client_ttl}
        '''
        result = self._values.get("tls_client_ttl")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "KmipSecretRoleConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "KmipSecretRole",
    "KmipSecretRoleConfig",
]

publication.publish()

def _typecheckingstub__f13ed3ec02a0672e6f50dce16be296ea4ecbc4bb64730638cf3c60da67e3f641(
    scope_: _constructs_77d1e7e8.Construct,
    id_: builtins.str,
    *,
    path: builtins.str,
    role: builtins.str,
    scope: builtins.str,
    ca: typing.Optional[builtins.str] = None,
    id: typing.Optional[builtins.str] = None,
    namespace: typing.Optional[builtins.str] = None,
    operation_activate: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_add_attribute: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_all: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_create: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_create_key_pair: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_decrypt: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_delete_attribute: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_destroy: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_discover_versions: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_encrypt: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_get: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_get_attribute_list: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_get_attributes: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_import: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_locate: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_mac: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_mac_verify: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_modify_attribute: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_none: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_query: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_register: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_rekey: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_rekey_key_pair: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_revoke: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_rng_retrieve: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_rng_seed: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_sign: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_signature_verify: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    tls_client_key_bits: typing.Optional[jsii.Number] = None,
    tls_client_key_type: typing.Optional[builtins.str] = None,
    tls_client_ttl: typing.Optional[jsii.Number] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c03a7f90e961d0a6a3548a7553397f4c950a9be1e8912039153f41b799448fa2(
    scope: _constructs_77d1e7e8.Construct,
    import_to_id: builtins.str,
    import_from_id: builtins.str,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ab6805a7370b2d8d1dc2f567fe68a227b3430298fc9e42d34fb5703eab6f270d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e63a20968faf6b2d3a65e08a41e55059560b25b8cad97275543bfbe2547a3bc3(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4dd4b0e79bf419aafd9022e4a7ce72c53b4c17a5b992b1e739e41125f8a5935e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__56415085bbda9e0349949b6d0b62517a313023cced4a2b3670975514247efe10(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dfc78b409f8597eb8b63f2a50757458d326bf759cc3b1fd1622ff88af6b2efed(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e82cb30aab3fa6d1dbe940d470c185ce3805c8f01fa1467dc8a7218d23bf30b8(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ee7339926b308baa570a8f87e288a57f8b6e8ad8482800a4c358e34ec0a14b9c(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bf22f96b006658603a752d2e034dc1648eb2224bb2f0d90a3f7e4b62b0ddd1ce(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6f29be6eb31a573b7e672e351ec58cb809c2651422efd6fb8f27d3c7b28ff885(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f7ffbc21a50eb4a889cc4178d7eb3d4e54b9e0907d428b00227eddf465620236(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f5597267c7232cf14ac204d739554c4b9dd9a5bb8e6a76168dfab94e2a54fa59(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0ddc6340a088e2a4baaf4fac428a9500856eaf3a8e7b9a22dab1e7c0414b3cf2(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7e84c292f3b03ad605a8cbbb44a4dd0be17d2e5e59e252f98ec7550179e8f4d2(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dcd085b9977449de0ec6b39107dd45ce1fb9aa8c419f47ef05580af333175ee7(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fd8a963217e16a8b36b0589b0988c009e06b09a5a7d71793d340f028a776384b(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8ca9a5ad84ac5d723ef32a584e95382defc7440dc3e53402a0b0d6072bf8f659(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__436264d7b342223e1d34bb2f076128a5a48c41729d13e791e16b52dbe406869b(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d72fce5ad029f544c0b8be5ded2e981f8238250f1e9fd2f6ca28f4b6beff83dd(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6595e38bf4f20b932af734e6433f1549b5c80c70a3f6d718829febd7dc58752d(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__28a0a5760aae2263a37d354699025c8580876513305e3369bb85cecb39fcca5c(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2cf6446258497ee85d088ec3e7bf8a1edb50bba988f04c5937e9d3f7b19daaa2(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__69c8964236d10f6cac4e6897a85100cb1c4fec6b6a9848aac177739a2324d056(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__adbc3244bf7241f174c931c984df235c88266c654fb175c09b271d538f3bf113(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fa71d985bf21969509c7f1be58380a21dcb0fc445b702b89fe25ab775ee4ea2a(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__efe9c97d3cca19fe85d1bc35edabeed00192a985b86ee7a1b542c89feb0ade07(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2a1276119af8c10a9ecbfa6f5701ebe22a1908e0d2e8da26c9e91a417c799f7f(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__721d5226db8f8364f4f6348d0aae4bd478574ed8868be481dd756746257bedc1(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a7293df4cfcdd8263d66f44fb7fbd2b0544ca4733dcac1f3f0cc1c0c95c53c1c(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1077fe6c2bca90163f68c6ddefff3d365acbac85ff1693544f7b8519c0badfbd(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4fc760ad23c9f051cad5454ef1378ab7a4a598fa1c2c6b1078dbde4a928e07d8(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7a5c934a2347a72e0f05ea43a26750bb8aab858db4102da9833175ef72d148c5(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__80552c3d659f58a7256275de6d24089835df802003fe0ae75e4ee51ac2dfef00(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0bbe444e703f528a30a6e4ce804ebaf813d8beb5885d8e5f500d483465d39a94(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6935014e0d07b36664c2058f52709533559dea6a32cf2bf985d38c594a4e8845(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d0e0494ce9661b9c5ba67e2ed710e642f2b3ca8fa30f45102cfd0ed85a89dc11(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d1dc2a2ade0966ce6e3c6c96a2862b6544fa4440bb8b70a29492eb141eef21c8(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__930446ba62be785582836da9a65cf8367521e5258b90783d503ad83f9b35454d(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__17c124bec735b061a2614d9c2a2e3ce979c80eb1cbdd5b5a37c6b55f0959eb97(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    path: builtins.str,
    role: builtins.str,
    scope: builtins.str,
    ca: typing.Optional[builtins.str] = None,
    id: typing.Optional[builtins.str] = None,
    namespace: typing.Optional[builtins.str] = None,
    operation_activate: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_add_attribute: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_all: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_create: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_create_key_pair: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_decrypt: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_delete_attribute: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_destroy: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_discover_versions: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_encrypt: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_get: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_get_attribute_list: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_get_attributes: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_import: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_locate: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_mac: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_mac_verify: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_modify_attribute: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_none: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_query: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_register: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_rekey: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_rekey_key_pair: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_revoke: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_rng_retrieve: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_rng_seed: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_sign: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    operation_signature_verify: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    tls_client_key_bits: typing.Optional[jsii.Number] = None,
    tls_client_key_type: typing.Optional[builtins.str] = None,
    tls_client_ttl: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass
