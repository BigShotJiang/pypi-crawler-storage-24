r'''
# `vault_transit_secret_backend_key`

Refer to the Terraform Registry for docs: [`vault_transit_secret_backend_key`](https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key).
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8


class TransitSecretBackendKey(
    _cdktn_78ede62e.TerraformResource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-vault.transitSecretBackendKey.TransitSecretBackendKey",
):
    '''Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key vault_transit_secret_backend_key}.'''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id_: builtins.str,
        *,
        backend: builtins.str,
        name: builtins.str,
        allow_plaintext_backup: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        auto_rotate_period: typing.Optional[jsii.Number] = None,
        context: typing.Optional[builtins.str] = None,
        convergent_encryption: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        deletion_allowed: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        derived: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        exportable: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        hybrid_key_type_ec: typing.Optional[builtins.str] = None,
        hybrid_key_type_pqc: typing.Optional[builtins.str] = None,
        id: typing.Optional[builtins.str] = None,
        key_size: typing.Optional[jsii.Number] = None,
        managed_key_id: typing.Optional[builtins.str] = None,
        managed_key_name: typing.Optional[builtins.str] = None,
        min_decryption_version: typing.Optional[jsii.Number] = None,
        min_encryption_version: typing.Optional[jsii.Number] = None,
        namespace: typing.Optional[builtins.str] = None,
        parameter_set: typing.Optional[builtins.str] = None,
        type: typing.Optional[builtins.str] = None,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key vault_transit_secret_backend_key} Resource.

        :param scope: The scope in which to define this construct.
        :param id_: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param backend: The Transit secret backend the resource belongs to. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#backend TransitSecretBackendKey#backend}
        :param name: Name of the encryption key to create. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#name TransitSecretBackendKey#name}
        :param allow_plaintext_backup: If set, enables taking backup of named key in the plaintext format. Once set, this cannot be disabled. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#allow_plaintext_backup TransitSecretBackendKey#allow_plaintext_backup}
        :param auto_rotate_period: Amount of seconds the key should live before being automatically rotated. A value of 0 disables automatic rotation for the key. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#auto_rotate_period TransitSecretBackendKey#auto_rotate_period}
        :param context: Base64 encoded context for key derivation. Required if derived is set to true. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#context TransitSecretBackendKey#context}
        :param convergent_encryption: Whether or not to support convergent encryption, where the same plaintext creates the same ciphertext. This requires derived to be set to true. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#convergent_encryption TransitSecretBackendKey#convergent_encryption}
        :param deletion_allowed: Specifies if the key is allowed to be deleted. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#deletion_allowed TransitSecretBackendKey#deletion_allowed}
        :param derived: Specifies if key derivation is to be used. If enabled, all encrypt/decrypt requests to this key must provide a context which is used for key derivation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#derived TransitSecretBackendKey#derived}
        :param exportable: Enables keys to be exportable. This allows for all the valid keys in the key ring to be exported. Once set, this cannot be disabled. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#exportable TransitSecretBackendKey#exportable}
        :param hybrid_key_type_ec: The elliptic curve algorithm to use for hybrid signatures. Supported key types are ``ecdsa-p256``, ``ecdsa-p384``, ``ecdsa-p521``, and ``ed25519``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#hybrid_key_type_ec TransitSecretBackendKey#hybrid_key_type_ec}
        :param hybrid_key_type_pqc: The post-quantum algorithm to use for hybrid signatures. Currently, ML-DSA is the only supported key type. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#hybrid_key_type_pqc TransitSecretBackendKey#hybrid_key_type_pqc}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#id TransitSecretBackendKey#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param key_size: The key size in bytes for algorithms that allow variable key sizes. Currently only applicable to HMAC; this value must be between 32 and 512. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#key_size TransitSecretBackendKey#key_size}
        :param managed_key_id: The UUID of the managed key to use when the key type is managed_key. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#managed_key_id TransitSecretBackendKey#managed_key_id}
        :param managed_key_name: The name of the managed key to use when the key type is managed_key. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#managed_key_name TransitSecretBackendKey#managed_key_name}
        :param min_decryption_version: Minimum key version to use for decryption. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#min_decryption_version TransitSecretBackendKey#min_decryption_version}
        :param min_encryption_version: Minimum key version to use for encryption. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#min_encryption_version TransitSecretBackendKey#min_encryption_version}
        :param namespace: Target namespace. (requires Enterprise). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#namespace TransitSecretBackendKey#namespace}
        :param parameter_set: The parameter set to use for ML-DSA. Required for ML-DSA and hybrid keys. Valid values for ML-DSA are ``44``, ``65``, and ``87``. Valid values for SLH-DSA are ``slh-dsa-sha2-128s``, ``slh-dsa-shake-128s``, ``slh-dsa-sha2-128f``, ``slh-dsa-shake-128``, ``slh-dsa-sha2-192s``, ``slh-dsa-shake-192s``, ``slh-dsa-sha2-192f``, ``slh-dsa-shake-192f``, ``slh-dsa-sha2-256s``, ``slh-dsa-shake-256s``, ``slh-dsa-sha2-256f``, and ``slh-dsa-shake-256f``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#parameter_set TransitSecretBackendKey#parameter_set}
        :param type: Specifies the type of key to create. The currently-supported types are: ``aes128-gcm96``, ``aes256-gcm96`` (default), ``chacha20-poly1305``, ``ed25519``, ``ecdsa-p256``, ``ecdsa-p384``, ``ecdsa-p521``, ``hmac``, ``rsa-2048``, ``rsa-3072``, ``rsa-4096``, ``managed_key``, ``aes128-cmac``, ``aes192-cmac``, ``aes256-cmac``, ``ml-dsa``, ``hybrid``, and ``slh-dsa``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#type TransitSecretBackendKey#type}
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f4f0adff6d27785295995ae7cdac13283189b54aa9a89686a9536eacff32d880)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id_", value=id_, expected_type=type_hints["id_"])
        config = TransitSecretBackendKeyConfig(
            backend=backend,
            name=name,
            allow_plaintext_backup=allow_plaintext_backup,
            auto_rotate_period=auto_rotate_period,
            context=context,
            convergent_encryption=convergent_encryption,
            deletion_allowed=deletion_allowed,
            derived=derived,
            exportable=exportable,
            hybrid_key_type_ec=hybrid_key_type_ec,
            hybrid_key_type_pqc=hybrid_key_type_pqc,
            id=id,
            key_size=key_size,
            managed_key_id=managed_key_id,
            managed_key_name=managed_key_name,
            min_decryption_version=min_decryption_version,
            min_encryption_version=min_encryption_version,
            namespace=namespace,
            parameter_set=parameter_set,
            type=type,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id_, config])

    @jsii.member(jsii_name="generateConfigForImport")
    @builtins.classmethod
    def generate_config_for_import(
        cls,
        scope: "_constructs_77d1e7e8.Construct",
        import_to_id: builtins.str,
        import_from_id: builtins.str,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
    ) -> "_cdktn_78ede62e.ImportableResource":
        '''Generates CDKTN code for importing a TransitSecretBackendKey resource upon running "cdktn plan ".

        :param scope: The scope in which to define this construct.
        :param import_to_id: The construct id used in the generated config for the TransitSecretBackendKey to import.
        :param import_from_id: The id of the existing TransitSecretBackendKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#import import section} in the documentation of this resource for the id to use
        :param provider: ? Optional instance of the provider where the TransitSecretBackendKey to import is found.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dce68980bcb31ae419a3f3874b6c5bb66f2a31309df2080780990e85e619674a)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument import_to_id", value=import_to_id, expected_type=type_hints["import_to_id"])
            check_type(argname="argument import_from_id", value=import_from_id, expected_type=type_hints["import_from_id"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
        return typing.cast("_cdktn_78ede62e.ImportableResource", jsii.sinvoke(cls, "generateConfigForImport", [scope, import_to_id, import_from_id, provider]))

    @jsii.member(jsii_name="resetAllowPlaintextBackup")
    def reset_allow_plaintext_backup(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAllowPlaintextBackup", []))

    @jsii.member(jsii_name="resetAutoRotatePeriod")
    def reset_auto_rotate_period(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAutoRotatePeriod", []))

    @jsii.member(jsii_name="resetContext")
    def reset_context(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetContext", []))

    @jsii.member(jsii_name="resetConvergentEncryption")
    def reset_convergent_encryption(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetConvergentEncryption", []))

    @jsii.member(jsii_name="resetDeletionAllowed")
    def reset_deletion_allowed(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDeletionAllowed", []))

    @jsii.member(jsii_name="resetDerived")
    def reset_derived(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDerived", []))

    @jsii.member(jsii_name="resetExportable")
    def reset_exportable(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetExportable", []))

    @jsii.member(jsii_name="resetHybridKeyTypeEc")
    def reset_hybrid_key_type_ec(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetHybridKeyTypeEc", []))

    @jsii.member(jsii_name="resetHybridKeyTypePqc")
    def reset_hybrid_key_type_pqc(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetHybridKeyTypePqc", []))

    @jsii.member(jsii_name="resetId")
    def reset_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetId", []))

    @jsii.member(jsii_name="resetKeySize")
    def reset_key_size(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetKeySize", []))

    @jsii.member(jsii_name="resetManagedKeyId")
    def reset_managed_key_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetManagedKeyId", []))

    @jsii.member(jsii_name="resetManagedKeyName")
    def reset_managed_key_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetManagedKeyName", []))

    @jsii.member(jsii_name="resetMinDecryptionVersion")
    def reset_min_decryption_version(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMinDecryptionVersion", []))

    @jsii.member(jsii_name="resetMinEncryptionVersion")
    def reset_min_encryption_version(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMinEncryptionVersion", []))

    @jsii.member(jsii_name="resetNamespace")
    def reset_namespace(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNamespace", []))

    @jsii.member(jsii_name="resetParameterSet")
    def reset_parameter_set(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetParameterSet", []))

    @jsii.member(jsii_name="resetType")
    def reset_type(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetType", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.member(jsii_name="synthesizeHclAttributes")
    def _synthesize_hcl_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeHclAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="keys")
    def keys(self) -> "_cdktn_78ede62e.StringMapList":
        return typing.cast("_cdktn_78ede62e.StringMapList", jsii.get(self, "keys"))

    @builtins.property
    @jsii.member(jsii_name="latestVersion")
    def latest_version(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "latestVersion"))

    @builtins.property
    @jsii.member(jsii_name="minAvailableVersion")
    def min_available_version(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "minAvailableVersion"))

    @builtins.property
    @jsii.member(jsii_name="supportsDecryption")
    def supports_decryption(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "supportsDecryption"))

    @builtins.property
    @jsii.member(jsii_name="supportsDerivation")
    def supports_derivation(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "supportsDerivation"))

    @builtins.property
    @jsii.member(jsii_name="supportsEncryption")
    def supports_encryption(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "supportsEncryption"))

    @builtins.property
    @jsii.member(jsii_name="supportsSigning")
    def supports_signing(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "supportsSigning"))

    @builtins.property
    @jsii.member(jsii_name="allowPlaintextBackupInput")
    def allow_plaintext_backup_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "allowPlaintextBackupInput"))

    @builtins.property
    @jsii.member(jsii_name="autoRotatePeriodInput")
    def auto_rotate_period_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "autoRotatePeriodInput"))

    @builtins.property
    @jsii.member(jsii_name="backendInput")
    def backend_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "backendInput"))

    @builtins.property
    @jsii.member(jsii_name="contextInput")
    def context_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "contextInput"))

    @builtins.property
    @jsii.member(jsii_name="convergentEncryptionInput")
    def convergent_encryption_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "convergentEncryptionInput"))

    @builtins.property
    @jsii.member(jsii_name="deletionAllowedInput")
    def deletion_allowed_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "deletionAllowedInput"))

    @builtins.property
    @jsii.member(jsii_name="derivedInput")
    def derived_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "derivedInput"))

    @builtins.property
    @jsii.member(jsii_name="exportableInput")
    def exportable_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "exportableInput"))

    @builtins.property
    @jsii.member(jsii_name="hybridKeyTypeEcInput")
    def hybrid_key_type_ec_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "hybridKeyTypeEcInput"))

    @builtins.property
    @jsii.member(jsii_name="hybridKeyTypePqcInput")
    def hybrid_key_type_pqc_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "hybridKeyTypePqcInput"))

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="keySizeInput")
    def key_size_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "keySizeInput"))

    @builtins.property
    @jsii.member(jsii_name="managedKeyIdInput")
    def managed_key_id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "managedKeyIdInput"))

    @builtins.property
    @jsii.member(jsii_name="managedKeyNameInput")
    def managed_key_name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "managedKeyNameInput"))

    @builtins.property
    @jsii.member(jsii_name="minDecryptionVersionInput")
    def min_decryption_version_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "minDecryptionVersionInput"))

    @builtins.property
    @jsii.member(jsii_name="minEncryptionVersionInput")
    def min_encryption_version_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "minEncryptionVersionInput"))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="namespaceInput")
    def namespace_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "namespaceInput"))

    @builtins.property
    @jsii.member(jsii_name="parameterSetInput")
    def parameter_set_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "parameterSetInput"))

    @builtins.property
    @jsii.member(jsii_name="typeInput")
    def type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "typeInput"))

    @builtins.property
    @jsii.member(jsii_name="allowPlaintextBackup")
    def allow_plaintext_backup(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "allowPlaintextBackup"))

    @allow_plaintext_backup.setter
    def allow_plaintext_backup(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b87219c23fb6a580521048eefd6ff04d7be40e3e412ce083ad72ca1a9a0d287f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "allowPlaintextBackup", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="autoRotatePeriod")
    def auto_rotate_period(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "autoRotatePeriod"))

    @auto_rotate_period.setter
    def auto_rotate_period(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9e3036f18a05347d5af21c54a0408165c417b28f1a6327d05a60a68a9979237c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "autoRotatePeriod", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="backend")
    def backend(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "backend"))

    @backend.setter
    def backend(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dc6908d9d67e19f87a4d326c6bf46ffc6e1eac6cd4f380c37a3e17be84e373fe)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "backend", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="context")
    def context(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "context"))

    @context.setter
    def context(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3699b17f857113479bfa92280a213a54b5fb1e6b853dcdebafee248f30b7ef81)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "context", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="convergentEncryption")
    def convergent_encryption(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "convergentEncryption"))

    @convergent_encryption.setter
    def convergent_encryption(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2e35095ce5f09dd76250f5fc043cf9642afa717581b55b9fc96343ebced020e1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "convergentEncryption", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="deletionAllowed")
    def deletion_allowed(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "deletionAllowed"))

    @deletion_allowed.setter
    def deletion_allowed(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2f44b8964c368f57af15eb2188e0923ab3a6c88d2739dde9f58a8b7023a7f047)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "deletionAllowed", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="derived")
    def derived(self) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "derived"))

    @derived.setter
    def derived(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a0655dbf81aad77686db0721b5d0c9b371ebb66d08bf49010cad4d81f4b05731)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "derived", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="exportable")
    def exportable(self) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "exportable"))

    @exportable.setter
    def exportable(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__50fa94fca8290e7f88d6430804003ee7c1342b9fd1e322c3bf33f074d2ec11cb)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "exportable", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="hybridKeyTypeEc")
    def hybrid_key_type_ec(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "hybridKeyTypeEc"))

    @hybrid_key_type_ec.setter
    def hybrid_key_type_ec(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0b475dd432be61a3e855f2789e337d84a62c2f1e610c75adc675cd4b904ac60b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "hybridKeyTypeEc", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="hybridKeyTypePqc")
    def hybrid_key_type_pqc(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "hybridKeyTypePqc"))

    @hybrid_key_type_pqc.setter
    def hybrid_key_type_pqc(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c42e35a210d2017c032c836ceb23e0f8c6e318f0386abfdb7daf7b4eda030b38)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "hybridKeyTypePqc", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @id.setter
    def id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3c46a323372c26e816371aef104cf26398b8c8f9d5e63e1a533694aa2c60ca20)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="keySize")
    def key_size(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "keySize"))

    @key_size.setter
    def key_size(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cf37651691a58b0e29f99c043444497925710aba57e4eb2bb491d290b798df49)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "keySize", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="managedKeyId")
    def managed_key_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "managedKeyId"))

    @managed_key_id.setter
    def managed_key_id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__603db1e7da4b21cbf84d6351779728d205f1588437a7d7609d622b0ad9c4ff41)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "managedKeyId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="managedKeyName")
    def managed_key_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "managedKeyName"))

    @managed_key_name.setter
    def managed_key_name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__50038d9bcbdf887118eb083624f70b80f9caa79b996d465b9cde0160161aed26)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "managedKeyName", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="minDecryptionVersion")
    def min_decryption_version(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "minDecryptionVersion"))

    @min_decryption_version.setter
    def min_decryption_version(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4f0f0047b5de78a18bfcc7ea6eeeba2cf4deeee7c64868a08d07b97a69e1f4c3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "minDecryptionVersion", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="minEncryptionVersion")
    def min_encryption_version(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "minEncryptionVersion"))

    @min_encryption_version.setter
    def min_encryption_version(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__40cec7c685b52ee3277f87d0a9e5099dadceae74fc06694e6ef380c505754b40)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "minEncryptionVersion", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fce4dbe15f2cbe14edc8a19e69cb9d0560b3f121071504cfdb8934dde212ed83)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="namespace")
    def namespace(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "namespace"))

    @namespace.setter
    def namespace(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__be8d57564a0c4d54e731c2b6ce6a0043d85c0112b927622431ce02d361c59036)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "namespace", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="parameterSet")
    def parameter_set(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "parameterSet"))

    @parameter_set.setter
    def parameter_set(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__63a3cc4f35955024bbc425a3e3fd1d6ce852fbec58b49d56bf7aff2f4fab77ef)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "parameterSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @type.setter
    def type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bb05093187a5c98e48c0761851b914869cb02ce889507a898c97228ef2008e95)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "type", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-vault.transitSecretBackendKey.TransitSecretBackendKeyConfig",
    jsii_struct_bases=[_cdktn_78ede62e.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "backend": "backend",
        "name": "name",
        "allow_plaintext_backup": "allowPlaintextBackup",
        "auto_rotate_period": "autoRotatePeriod",
        "context": "context",
        "convergent_encryption": "convergentEncryption",
        "deletion_allowed": "deletionAllowed",
        "derived": "derived",
        "exportable": "exportable",
        "hybrid_key_type_ec": "hybridKeyTypeEc",
        "hybrid_key_type_pqc": "hybridKeyTypePqc",
        "id": "id",
        "key_size": "keySize",
        "managed_key_id": "managedKeyId",
        "managed_key_name": "managedKeyName",
        "min_decryption_version": "minDecryptionVersion",
        "min_encryption_version": "minEncryptionVersion",
        "namespace": "namespace",
        "parameter_set": "parameterSet",
        "type": "type",
    },
)
class TransitSecretBackendKeyConfig(_cdktn_78ede62e.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
        backend: builtins.str,
        name: builtins.str,
        allow_plaintext_backup: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        auto_rotate_period: typing.Optional[jsii.Number] = None,
        context: typing.Optional[builtins.str] = None,
        convergent_encryption: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        deletion_allowed: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        derived: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        exportable: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        hybrid_key_type_ec: typing.Optional[builtins.str] = None,
        hybrid_key_type_pqc: typing.Optional[builtins.str] = None,
        id: typing.Optional[builtins.str] = None,
        key_size: typing.Optional[jsii.Number] = None,
        managed_key_id: typing.Optional[builtins.str] = None,
        managed_key_name: typing.Optional[builtins.str] = None,
        min_decryption_version: typing.Optional[jsii.Number] = None,
        min_encryption_version: typing.Optional[jsii.Number] = None,
        namespace: typing.Optional[builtins.str] = None,
        parameter_set: typing.Optional[builtins.str] = None,
        type: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param backend: The Transit secret backend the resource belongs to. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#backend TransitSecretBackendKey#backend}
        :param name: Name of the encryption key to create. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#name TransitSecretBackendKey#name}
        :param allow_plaintext_backup: If set, enables taking backup of named key in the plaintext format. Once set, this cannot be disabled. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#allow_plaintext_backup TransitSecretBackendKey#allow_plaintext_backup}
        :param auto_rotate_period: Amount of seconds the key should live before being automatically rotated. A value of 0 disables automatic rotation for the key. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#auto_rotate_period TransitSecretBackendKey#auto_rotate_period}
        :param context: Base64 encoded context for key derivation. Required if derived is set to true. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#context TransitSecretBackendKey#context}
        :param convergent_encryption: Whether or not to support convergent encryption, where the same plaintext creates the same ciphertext. This requires derived to be set to true. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#convergent_encryption TransitSecretBackendKey#convergent_encryption}
        :param deletion_allowed: Specifies if the key is allowed to be deleted. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#deletion_allowed TransitSecretBackendKey#deletion_allowed}
        :param derived: Specifies if key derivation is to be used. If enabled, all encrypt/decrypt requests to this key must provide a context which is used for key derivation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#derived TransitSecretBackendKey#derived}
        :param exportable: Enables keys to be exportable. This allows for all the valid keys in the key ring to be exported. Once set, this cannot be disabled. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#exportable TransitSecretBackendKey#exportable}
        :param hybrid_key_type_ec: The elliptic curve algorithm to use for hybrid signatures. Supported key types are ``ecdsa-p256``, ``ecdsa-p384``, ``ecdsa-p521``, and ``ed25519``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#hybrid_key_type_ec TransitSecretBackendKey#hybrid_key_type_ec}
        :param hybrid_key_type_pqc: The post-quantum algorithm to use for hybrid signatures. Currently, ML-DSA is the only supported key type. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#hybrid_key_type_pqc TransitSecretBackendKey#hybrid_key_type_pqc}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#id TransitSecretBackendKey#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param key_size: The key size in bytes for algorithms that allow variable key sizes. Currently only applicable to HMAC; this value must be between 32 and 512. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#key_size TransitSecretBackendKey#key_size}
        :param managed_key_id: The UUID of the managed key to use when the key type is managed_key. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#managed_key_id TransitSecretBackendKey#managed_key_id}
        :param managed_key_name: The name of the managed key to use when the key type is managed_key. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#managed_key_name TransitSecretBackendKey#managed_key_name}
        :param min_decryption_version: Minimum key version to use for decryption. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#min_decryption_version TransitSecretBackendKey#min_decryption_version}
        :param min_encryption_version: Minimum key version to use for encryption. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#min_encryption_version TransitSecretBackendKey#min_encryption_version}
        :param namespace: Target namespace. (requires Enterprise). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#namespace TransitSecretBackendKey#namespace}
        :param parameter_set: The parameter set to use for ML-DSA. Required for ML-DSA and hybrid keys. Valid values for ML-DSA are ``44``, ``65``, and ``87``. Valid values for SLH-DSA are ``slh-dsa-sha2-128s``, ``slh-dsa-shake-128s``, ``slh-dsa-sha2-128f``, ``slh-dsa-shake-128``, ``slh-dsa-sha2-192s``, ``slh-dsa-shake-192s``, ``slh-dsa-sha2-192f``, ``slh-dsa-shake-192f``, ``slh-dsa-sha2-256s``, ``slh-dsa-shake-256s``, ``slh-dsa-sha2-256f``, and ``slh-dsa-shake-256f``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#parameter_set TransitSecretBackendKey#parameter_set}
        :param type: Specifies the type of key to create. The currently-supported types are: ``aes128-gcm96``, ``aes256-gcm96`` (default), ``chacha20-poly1305``, ``ed25519``, ``ecdsa-p256``, ``ecdsa-p384``, ``ecdsa-p521``, ``hmac``, ``rsa-2048``, ``rsa-3072``, ``rsa-4096``, ``managed_key``, ``aes128-cmac``, ``aes192-cmac``, ``aes256-cmac``, ``ml-dsa``, ``hybrid``, and ``slh-dsa``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#type TransitSecretBackendKey#type}
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5690f0f12519e5291f7d5a0652db7aba2b00fd2cefd22e05373176357cec99ab)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument backend", value=backend, expected_type=type_hints["backend"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument allow_plaintext_backup", value=allow_plaintext_backup, expected_type=type_hints["allow_plaintext_backup"])
            check_type(argname="argument auto_rotate_period", value=auto_rotate_period, expected_type=type_hints["auto_rotate_period"])
            check_type(argname="argument context", value=context, expected_type=type_hints["context"])
            check_type(argname="argument convergent_encryption", value=convergent_encryption, expected_type=type_hints["convergent_encryption"])
            check_type(argname="argument deletion_allowed", value=deletion_allowed, expected_type=type_hints["deletion_allowed"])
            check_type(argname="argument derived", value=derived, expected_type=type_hints["derived"])
            check_type(argname="argument exportable", value=exportable, expected_type=type_hints["exportable"])
            check_type(argname="argument hybrid_key_type_ec", value=hybrid_key_type_ec, expected_type=type_hints["hybrid_key_type_ec"])
            check_type(argname="argument hybrid_key_type_pqc", value=hybrid_key_type_pqc, expected_type=type_hints["hybrid_key_type_pqc"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument key_size", value=key_size, expected_type=type_hints["key_size"])
            check_type(argname="argument managed_key_id", value=managed_key_id, expected_type=type_hints["managed_key_id"])
            check_type(argname="argument managed_key_name", value=managed_key_name, expected_type=type_hints["managed_key_name"])
            check_type(argname="argument min_decryption_version", value=min_decryption_version, expected_type=type_hints["min_decryption_version"])
            check_type(argname="argument min_encryption_version", value=min_encryption_version, expected_type=type_hints["min_encryption_version"])
            check_type(argname="argument namespace", value=namespace, expected_type=type_hints["namespace"])
            check_type(argname="argument parameter_set", value=parameter_set, expected_type=type_hints["parameter_set"])
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "backend": backend,
            "name": name,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if allow_plaintext_backup is not None:
            self._values["allow_plaintext_backup"] = allow_plaintext_backup
        if auto_rotate_period is not None:
            self._values["auto_rotate_period"] = auto_rotate_period
        if context is not None:
            self._values["context"] = context
        if convergent_encryption is not None:
            self._values["convergent_encryption"] = convergent_encryption
        if deletion_allowed is not None:
            self._values["deletion_allowed"] = deletion_allowed
        if derived is not None:
            self._values["derived"] = derived
        if exportable is not None:
            self._values["exportable"] = exportable
        if hybrid_key_type_ec is not None:
            self._values["hybrid_key_type_ec"] = hybrid_key_type_ec
        if hybrid_key_type_pqc is not None:
            self._values["hybrid_key_type_pqc"] = hybrid_key_type_pqc
        if id is not None:
            self._values["id"] = id
        if key_size is not None:
            self._values["key_size"] = key_size
        if managed_key_id is not None:
            self._values["managed_key_id"] = managed_key_id
        if managed_key_name is not None:
            self._values["managed_key_name"] = managed_key_name
        if min_decryption_version is not None:
            self._values["min_decryption_version"] = min_decryption_version
        if min_encryption_version is not None:
            self._values["min_encryption_version"] = min_encryption_version
        if namespace is not None:
            self._values["namespace"] = namespace
        if parameter_set is not None:
            self._values["parameter_set"] = parameter_set
        if type is not None:
            self._values["type"] = type

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]], result)

    @builtins.property
    def for_each(self) -> typing.Optional["_cdktn_78ede62e.ITerraformIterator"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional["_cdktn_78ede62e.ITerraformIterator"], result)

    @builtins.property
    def lifecycle(
        self,
    ) -> typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"], result)

    @builtins.property
    def provider(self) -> typing.Optional["_cdktn_78ede62e.TerraformProvider"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformProvider"], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]], result)

    @builtins.property
    def backend(self) -> builtins.str:
        '''The Transit secret backend the resource belongs to.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#backend TransitSecretBackendKey#backend}
        '''
        result = self._values.get("backend")
        assert result is not None, "Required property 'backend' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def name(self) -> builtins.str:
        '''Name of the encryption key to create.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#name TransitSecretBackendKey#name}
        '''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def allow_plaintext_backup(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''If set, enables taking backup of named key in the plaintext format. Once set, this cannot be disabled.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#allow_plaintext_backup TransitSecretBackendKey#allow_plaintext_backup}
        '''
        result = self._values.get("allow_plaintext_backup")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def auto_rotate_period(self) -> typing.Optional[jsii.Number]:
        '''Amount of seconds the key should live before being automatically rotated.

        A value of 0 disables automatic rotation for the key.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#auto_rotate_period TransitSecretBackendKey#auto_rotate_period}
        '''
        result = self._values.get("auto_rotate_period")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def context(self) -> typing.Optional[builtins.str]:
        '''Base64 encoded context for key derivation. Required if derived is set to true.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#context TransitSecretBackendKey#context}
        '''
        result = self._values.get("context")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def convergent_encryption(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Whether or not to support convergent encryption, where the same plaintext creates the same ciphertext.

        This requires derived to be set to true.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#convergent_encryption TransitSecretBackendKey#convergent_encryption}
        '''
        result = self._values.get("convergent_encryption")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def deletion_allowed(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Specifies if the key is allowed to be deleted.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#deletion_allowed TransitSecretBackendKey#deletion_allowed}
        '''
        result = self._values.get("deletion_allowed")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def derived(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Specifies if key derivation is to be used.

        If enabled, all encrypt/decrypt requests to this key must provide a context which is used for key derivation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#derived TransitSecretBackendKey#derived}
        '''
        result = self._values.get("derived")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def exportable(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Enables keys to be exportable.

        This allows for all the valid keys in the key ring to be exported. Once set, this cannot be disabled.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#exportable TransitSecretBackendKey#exportable}
        '''
        result = self._values.get("exportable")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def hybrid_key_type_ec(self) -> typing.Optional[builtins.str]:
        '''The elliptic curve algorithm to use for hybrid signatures. Supported key types are ``ecdsa-p256``, ``ecdsa-p384``, ``ecdsa-p521``, and ``ed25519``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#hybrid_key_type_ec TransitSecretBackendKey#hybrid_key_type_ec}
        '''
        result = self._values.get("hybrid_key_type_ec")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def hybrid_key_type_pqc(self) -> typing.Optional[builtins.str]:
        '''The post-quantum algorithm to use for hybrid signatures. Currently, ML-DSA is the only supported key type.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#hybrid_key_type_pqc TransitSecretBackendKey#hybrid_key_type_pqc}
        '''
        result = self._values.get("hybrid_key_type_pqc")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def id(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#id TransitSecretBackendKey#id}.

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def key_size(self) -> typing.Optional[jsii.Number]:
        '''The key size in bytes for algorithms that allow variable key sizes.

        Currently only applicable to HMAC; this value must be between 32 and 512.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#key_size TransitSecretBackendKey#key_size}
        '''
        result = self._values.get("key_size")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def managed_key_id(self) -> typing.Optional[builtins.str]:
        '''The UUID of the managed key to use when the key type is managed_key.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#managed_key_id TransitSecretBackendKey#managed_key_id}
        '''
        result = self._values.get("managed_key_id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def managed_key_name(self) -> typing.Optional[builtins.str]:
        '''The name of the managed key to use when the key type is managed_key.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#managed_key_name TransitSecretBackendKey#managed_key_name}
        '''
        result = self._values.get("managed_key_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def min_decryption_version(self) -> typing.Optional[jsii.Number]:
        '''Minimum key version to use for decryption.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#min_decryption_version TransitSecretBackendKey#min_decryption_version}
        '''
        result = self._values.get("min_decryption_version")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def min_encryption_version(self) -> typing.Optional[jsii.Number]:
        '''Minimum key version to use for encryption.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#min_encryption_version TransitSecretBackendKey#min_encryption_version}
        '''
        result = self._values.get("min_encryption_version")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def namespace(self) -> typing.Optional[builtins.str]:
        '''Target namespace. (requires Enterprise).

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#namespace TransitSecretBackendKey#namespace}
        '''
        result = self._values.get("namespace")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def parameter_set(self) -> typing.Optional[builtins.str]:
        '''The parameter set to use for ML-DSA.

        Required for ML-DSA and hybrid keys.  Valid values for ML-DSA are ``44``, ``65``, and ``87``. Valid values for SLH-DSA are ``slh-dsa-sha2-128s``, ``slh-dsa-shake-128s``, ``slh-dsa-sha2-128f``, ``slh-dsa-shake-128``, ``slh-dsa-sha2-192s``, ``slh-dsa-shake-192s``, ``slh-dsa-sha2-192f``, ``slh-dsa-shake-192f``, ``slh-dsa-sha2-256s``, ``slh-dsa-shake-256s``, ``slh-dsa-sha2-256f``, and ``slh-dsa-shake-256f``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#parameter_set TransitSecretBackendKey#parameter_set}
        '''
        result = self._values.get("parameter_set")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def type(self) -> typing.Optional[builtins.str]:
        '''Specifies the type of key to create.

        The currently-supported types are: ``aes128-gcm96``, ``aes256-gcm96`` (default), ``chacha20-poly1305``, ``ed25519``, ``ecdsa-p256``, ``ecdsa-p384``, ``ecdsa-p521``, ``hmac``, ``rsa-2048``, ``rsa-3072``, ``rsa-4096``, ``managed_key``, ``aes128-cmac``, ``aes192-cmac``, ``aes256-cmac``, ``ml-dsa``, ``hybrid``, and ``slh-dsa``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/transit_secret_backend_key#type TransitSecretBackendKey#type}
        '''
        result = self._values.get("type")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "TransitSecretBackendKeyConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "TransitSecretBackendKey",
    "TransitSecretBackendKeyConfig",
]

publication.publish()

def _typecheckingstub__f4f0adff6d27785295995ae7cdac13283189b54aa9a89686a9536eacff32d880(
    scope: _constructs_77d1e7e8.Construct,
    id_: builtins.str,
    *,
    backend: builtins.str,
    name: builtins.str,
    allow_plaintext_backup: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    auto_rotate_period: typing.Optional[jsii.Number] = None,
    context: typing.Optional[builtins.str] = None,
    convergent_encryption: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    deletion_allowed: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    derived: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    exportable: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    hybrid_key_type_ec: typing.Optional[builtins.str] = None,
    hybrid_key_type_pqc: typing.Optional[builtins.str] = None,
    id: typing.Optional[builtins.str] = None,
    key_size: typing.Optional[jsii.Number] = None,
    managed_key_id: typing.Optional[builtins.str] = None,
    managed_key_name: typing.Optional[builtins.str] = None,
    min_decryption_version: typing.Optional[jsii.Number] = None,
    min_encryption_version: typing.Optional[jsii.Number] = None,
    namespace: typing.Optional[builtins.str] = None,
    parameter_set: typing.Optional[builtins.str] = None,
    type: typing.Optional[builtins.str] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dce68980bcb31ae419a3f3874b6c5bb66f2a31309df2080780990e85e619674a(
    scope: _constructs_77d1e7e8.Construct,
    import_to_id: builtins.str,
    import_from_id: builtins.str,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b87219c23fb6a580521048eefd6ff04d7be40e3e412ce083ad72ca1a9a0d287f(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9e3036f18a05347d5af21c54a0408165c417b28f1a6327d05a60a68a9979237c(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dc6908d9d67e19f87a4d326c6bf46ffc6e1eac6cd4f380c37a3e17be84e373fe(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3699b17f857113479bfa92280a213a54b5fb1e6b853dcdebafee248f30b7ef81(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2e35095ce5f09dd76250f5fc043cf9642afa717581b55b9fc96343ebced020e1(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2f44b8964c368f57af15eb2188e0923ab3a6c88d2739dde9f58a8b7023a7f047(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a0655dbf81aad77686db0721b5d0c9b371ebb66d08bf49010cad4d81f4b05731(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__50fa94fca8290e7f88d6430804003ee7c1342b9fd1e322c3bf33f074d2ec11cb(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0b475dd432be61a3e855f2789e337d84a62c2f1e610c75adc675cd4b904ac60b(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c42e35a210d2017c032c836ceb23e0f8c6e318f0386abfdb7daf7b4eda030b38(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3c46a323372c26e816371aef104cf26398b8c8f9d5e63e1a533694aa2c60ca20(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cf37651691a58b0e29f99c043444497925710aba57e4eb2bb491d290b798df49(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__603db1e7da4b21cbf84d6351779728d205f1588437a7d7609d622b0ad9c4ff41(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__50038d9bcbdf887118eb083624f70b80f9caa79b996d465b9cde0160161aed26(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4f0f0047b5de78a18bfcc7ea6eeeba2cf4deeee7c64868a08d07b97a69e1f4c3(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__40cec7c685b52ee3277f87d0a9e5099dadceae74fc06694e6ef380c505754b40(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fce4dbe15f2cbe14edc8a19e69cb9d0560b3f121071504cfdb8934dde212ed83(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__be8d57564a0c4d54e731c2b6ce6a0043d85c0112b927622431ce02d361c59036(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__63a3cc4f35955024bbc425a3e3fd1d6ce852fbec58b49d56bf7aff2f4fab77ef(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bb05093187a5c98e48c0761851b914869cb02ce889507a898c97228ef2008e95(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5690f0f12519e5291f7d5a0652db7aba2b00fd2cefd22e05373176357cec99ab(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    backend: builtins.str,
    name: builtins.str,
    allow_plaintext_backup: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    auto_rotate_period: typing.Optional[jsii.Number] = None,
    context: typing.Optional[builtins.str] = None,
    convergent_encryption: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    deletion_allowed: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    derived: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    exportable: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    hybrid_key_type_ec: typing.Optional[builtins.str] = None,
    hybrid_key_type_pqc: typing.Optional[builtins.str] = None,
    id: typing.Optional[builtins.str] = None,
    key_size: typing.Optional[jsii.Number] = None,
    managed_key_id: typing.Optional[builtins.str] = None,
    managed_key_name: typing.Optional[builtins.str] = None,
    min_decryption_version: typing.Optional[jsii.Number] = None,
    min_encryption_version: typing.Optional[jsii.Number] = None,
    namespace: typing.Optional[builtins.str] = None,
    parameter_set: typing.Optional[builtins.str] = None,
    type: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass
