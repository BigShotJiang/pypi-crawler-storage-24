r'''
# `vault_cf_auth_backend_config`

Refer to the Terraform Registry for docs: [`vault_cf_auth_backend_config`](https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config).
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8


class CfAuthBackendConfig(
    _cdktn_78ede62e.TerraformResource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-vault.cfAuthBackendConfig.CfAuthBackendConfig",
):
    '''Represents a {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config vault_cf_auth_backend_config}.'''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        cf_api_addr: builtins.str,
        cf_password_wo: builtins.str,
        cf_username: builtins.str,
        identity_ca_certificates: typing.Sequence[builtins.str],
        mount: builtins.str,
        cf_api_trusted_certificates: typing.Optional[typing.Sequence[builtins.str]] = None,
        cf_timeout: typing.Optional[jsii.Number] = None,
        login_max_seconds_not_after: typing.Optional[jsii.Number] = None,
        login_max_seconds_not_before: typing.Optional[jsii.Number] = None,
        namespace: typing.Optional[builtins.str] = None,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config vault_cf_auth_backend_config} Resource.

        :param scope: The scope in which to define this construct.
        :param id: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param cf_api_addr: CF's full API address, used for verifying that a given ``CF_INSTANCE_CERT`` shows an application ID, space ID, and organization ID that presently exist. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#cf_api_addr CfAuthBackendConfig#cf_api_addr}
        :param cf_password_wo: The password for authenticating to the CF API. This is a write-only field and will not be read back from Vault. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#cf_password_wo CfAuthBackendConfig#cf_password_wo}
        :param cf_username: The username for authenticating to the CF API. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#cf_username CfAuthBackendConfig#cf_username}
        :param identity_ca_certificates: The root CA certificate(s) to be used for verifying that the ``CF_INSTANCE_CERT`` presented for logging in was issued by the proper authority. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#identity_ca_certificates CfAuthBackendConfig#identity_ca_certificates}
        :param mount: Mount path for the CF auth engine in Vault. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#mount CfAuthBackendConfig#mount}
        :param cf_api_trusted_certificates: The certificate(s) presented by the CF API. Configures Vault to trust these certificates when making API calls. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#cf_api_trusted_certificates CfAuthBackendConfig#cf_api_trusted_certificates}
        :param cf_timeout: The timeout for the CF API in seconds. Defaults to ``0`` (no timeout). Removing this field from config resets the value to ``0`` in Vault. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#cf_timeout CfAuthBackendConfig#cf_timeout}
        :param login_max_seconds_not_after: The maximum number of seconds in the future when a signature could have been created. Defaults to ``60``. This field is ``Computed``: if removed from config, Vault retains the previously set value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#login_max_seconds_not_after CfAuthBackendConfig#login_max_seconds_not_after}
        :param login_max_seconds_not_before: The maximum number of seconds in the past when a signature could have been created. Defaults to ``300``. This field is ``Computed``: if removed from config, Vault retains the previously set value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#login_max_seconds_not_before CfAuthBackendConfig#login_max_seconds_not_before}
        :param namespace: Target namespace. (requires Enterprise). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#namespace CfAuthBackendConfig#namespace}
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0f73c2d12a6a23aaf8268d61f646b127d703722f8d94da17a966abc489d7fd84)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        config = CfAuthBackendConfigConfig(
            cf_api_addr=cf_api_addr,
            cf_password_wo=cf_password_wo,
            cf_username=cf_username,
            identity_ca_certificates=identity_ca_certificates,
            mount=mount,
            cf_api_trusted_certificates=cf_api_trusted_certificates,
            cf_timeout=cf_timeout,
            login_max_seconds_not_after=login_max_seconds_not_after,
            login_max_seconds_not_before=login_max_seconds_not_before,
            namespace=namespace,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id, config])

    @jsii.member(jsii_name="generateConfigForImport")
    @builtins.classmethod
    def generate_config_for_import(
        cls,
        scope: "_constructs_77d1e7e8.Construct",
        import_to_id: builtins.str,
        import_from_id: builtins.str,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
    ) -> "_cdktn_78ede62e.ImportableResource":
        '''Generates CDKTN code for importing a CfAuthBackendConfig resource upon running "cdktn plan ".

        :param scope: The scope in which to define this construct.
        :param import_to_id: The construct id used in the generated config for the CfAuthBackendConfig to import.
        :param import_from_id: The id of the existing CfAuthBackendConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#import import section} in the documentation of this resource for the id to use
        :param provider: ? Optional instance of the provider where the CfAuthBackendConfig to import is found.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__835b09ac39a9e9b875bc4880d567911ba4559aa0ef0f445245827da9ba3d0025)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument import_to_id", value=import_to_id, expected_type=type_hints["import_to_id"])
            check_type(argname="argument import_from_id", value=import_from_id, expected_type=type_hints["import_from_id"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
        return typing.cast("_cdktn_78ede62e.ImportableResource", jsii.sinvoke(cls, "generateConfigForImport", [scope, import_to_id, import_from_id, provider]))

    @jsii.member(jsii_name="resetCfApiTrustedCertificates")
    def reset_cf_api_trusted_certificates(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCfApiTrustedCertificates", []))

    @jsii.member(jsii_name="resetCfTimeout")
    def reset_cf_timeout(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCfTimeout", []))

    @jsii.member(jsii_name="resetLoginMaxSecondsNotAfter")
    def reset_login_max_seconds_not_after(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetLoginMaxSecondsNotAfter", []))

    @jsii.member(jsii_name="resetLoginMaxSecondsNotBefore")
    def reset_login_max_seconds_not_before(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetLoginMaxSecondsNotBefore", []))

    @jsii.member(jsii_name="resetNamespace")
    def reset_namespace(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNamespace", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.member(jsii_name="synthesizeHclAttributes")
    def _synthesize_hcl_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeHclAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="cfApiAddrInput")
    def cf_api_addr_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "cfApiAddrInput"))

    @builtins.property
    @jsii.member(jsii_name="cfApiTrustedCertificatesInput")
    def cf_api_trusted_certificates_input(
        self,
    ) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "cfApiTrustedCertificatesInput"))

    @builtins.property
    @jsii.member(jsii_name="cfPasswordWoInput")
    def cf_password_wo_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "cfPasswordWoInput"))

    @builtins.property
    @jsii.member(jsii_name="cfTimeoutInput")
    def cf_timeout_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "cfTimeoutInput"))

    @builtins.property
    @jsii.member(jsii_name="cfUsernameInput")
    def cf_username_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "cfUsernameInput"))

    @builtins.property
    @jsii.member(jsii_name="identityCaCertificatesInput")
    def identity_ca_certificates_input(
        self,
    ) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "identityCaCertificatesInput"))

    @builtins.property
    @jsii.member(jsii_name="loginMaxSecondsNotAfterInput")
    def login_max_seconds_not_after_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "loginMaxSecondsNotAfterInput"))

    @builtins.property
    @jsii.member(jsii_name="loginMaxSecondsNotBeforeInput")
    def login_max_seconds_not_before_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "loginMaxSecondsNotBeforeInput"))

    @builtins.property
    @jsii.member(jsii_name="mountInput")
    def mount_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "mountInput"))

    @builtins.property
    @jsii.member(jsii_name="namespaceInput")
    def namespace_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "namespaceInput"))

    @builtins.property
    @jsii.member(jsii_name="cfApiAddr")
    def cf_api_addr(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "cfApiAddr"))

    @cf_api_addr.setter
    def cf_api_addr(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7d9f888759dc95c4e3339d28ca81900c727e2b78071fd335a560bdabe93cc948)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "cfApiAddr", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="cfApiTrustedCertificates")
    def cf_api_trusted_certificates(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "cfApiTrustedCertificates"))

    @cf_api_trusted_certificates.setter
    def cf_api_trusted_certificates(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__49d0e8e9e15440727faa86b42b4d03b28cee09caff265f751b2aa61941c51104)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "cfApiTrustedCertificates", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="cfPasswordWo")
    def cf_password_wo(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "cfPasswordWo"))

    @cf_password_wo.setter
    def cf_password_wo(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__aedd68d0503cacfcaf63dcd2a604f94501a54fe728db099b0fd5ea49a8c62fc5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "cfPasswordWo", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="cfTimeout")
    def cf_timeout(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "cfTimeout"))

    @cf_timeout.setter
    def cf_timeout(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d53ef8165f8611ef99906ced8a247c77fd582ef0ce03495a1fe53859997b5b40)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "cfTimeout", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="cfUsername")
    def cf_username(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "cfUsername"))

    @cf_username.setter
    def cf_username(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c608b33380da2d244536e259dce4f7ff8c861ef21b24b64a7cf04a3cb2c633ac)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "cfUsername", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="identityCaCertificates")
    def identity_ca_certificates(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "identityCaCertificates"))

    @identity_ca_certificates.setter
    def identity_ca_certificates(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1fde93bffd1fb5275ebe2e261b191556d8ef2051344ae48dc77f9b9f5c0e4458)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "identityCaCertificates", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="loginMaxSecondsNotAfter")
    def login_max_seconds_not_after(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "loginMaxSecondsNotAfter"))

    @login_max_seconds_not_after.setter
    def login_max_seconds_not_after(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__77d15ae5171975f850304669f424fddd2fadaa1a970bdae8a66c68b1da60bc8d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "loginMaxSecondsNotAfter", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="loginMaxSecondsNotBefore")
    def login_max_seconds_not_before(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "loginMaxSecondsNotBefore"))

    @login_max_seconds_not_before.setter
    def login_max_seconds_not_before(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__880a6aee0661ab94ad9f3f511b7fdb3624818d442275071c7722b7458866d9fc)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "loginMaxSecondsNotBefore", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="mount")
    def mount(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "mount"))

    @mount.setter
    def mount(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__30c1fd56679d64dd114300f556223da0e0ed2d05995e34efbf8b95274f0d0cc9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "mount", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="namespace")
    def namespace(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "namespace"))

    @namespace.setter
    def namespace(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__91fa108024e339aa058a2a58a44633fdd67be6a93208bf9e93b1a304188d21d0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "namespace", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-vault.cfAuthBackendConfig.CfAuthBackendConfigConfig",
    jsii_struct_bases=[_cdktn_78ede62e.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "cf_api_addr": "cfApiAddr",
        "cf_password_wo": "cfPasswordWo",
        "cf_username": "cfUsername",
        "identity_ca_certificates": "identityCaCertificates",
        "mount": "mount",
        "cf_api_trusted_certificates": "cfApiTrustedCertificates",
        "cf_timeout": "cfTimeout",
        "login_max_seconds_not_after": "loginMaxSecondsNotAfter",
        "login_max_seconds_not_before": "loginMaxSecondsNotBefore",
        "namespace": "namespace",
    },
)
class CfAuthBackendConfigConfig(_cdktn_78ede62e.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
        cf_api_addr: builtins.str,
        cf_password_wo: builtins.str,
        cf_username: builtins.str,
        identity_ca_certificates: typing.Sequence[builtins.str],
        mount: builtins.str,
        cf_api_trusted_certificates: typing.Optional[typing.Sequence[builtins.str]] = None,
        cf_timeout: typing.Optional[jsii.Number] = None,
        login_max_seconds_not_after: typing.Optional[jsii.Number] = None,
        login_max_seconds_not_before: typing.Optional[jsii.Number] = None,
        namespace: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param cf_api_addr: CF's full API address, used for verifying that a given ``CF_INSTANCE_CERT`` shows an application ID, space ID, and organization ID that presently exist. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#cf_api_addr CfAuthBackendConfig#cf_api_addr}
        :param cf_password_wo: The password for authenticating to the CF API. This is a write-only field and will not be read back from Vault. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#cf_password_wo CfAuthBackendConfig#cf_password_wo}
        :param cf_username: The username for authenticating to the CF API. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#cf_username CfAuthBackendConfig#cf_username}
        :param identity_ca_certificates: The root CA certificate(s) to be used for verifying that the ``CF_INSTANCE_CERT`` presented for logging in was issued by the proper authority. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#identity_ca_certificates CfAuthBackendConfig#identity_ca_certificates}
        :param mount: Mount path for the CF auth engine in Vault. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#mount CfAuthBackendConfig#mount}
        :param cf_api_trusted_certificates: The certificate(s) presented by the CF API. Configures Vault to trust these certificates when making API calls. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#cf_api_trusted_certificates CfAuthBackendConfig#cf_api_trusted_certificates}
        :param cf_timeout: The timeout for the CF API in seconds. Defaults to ``0`` (no timeout). Removing this field from config resets the value to ``0`` in Vault. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#cf_timeout CfAuthBackendConfig#cf_timeout}
        :param login_max_seconds_not_after: The maximum number of seconds in the future when a signature could have been created. Defaults to ``60``. This field is ``Computed``: if removed from config, Vault retains the previously set value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#login_max_seconds_not_after CfAuthBackendConfig#login_max_seconds_not_after}
        :param login_max_seconds_not_before: The maximum number of seconds in the past when a signature could have been created. Defaults to ``300``. This field is ``Computed``: if removed from config, Vault retains the previously set value. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#login_max_seconds_not_before CfAuthBackendConfig#login_max_seconds_not_before}
        :param namespace: Target namespace. (requires Enterprise). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#namespace CfAuthBackendConfig#namespace}
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ee1157ece897dac631359e89f9c23dbe17b151053a98db95080b1bd8c620d3f3)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument cf_api_addr", value=cf_api_addr, expected_type=type_hints["cf_api_addr"])
            check_type(argname="argument cf_password_wo", value=cf_password_wo, expected_type=type_hints["cf_password_wo"])
            check_type(argname="argument cf_username", value=cf_username, expected_type=type_hints["cf_username"])
            check_type(argname="argument identity_ca_certificates", value=identity_ca_certificates, expected_type=type_hints["identity_ca_certificates"])
            check_type(argname="argument mount", value=mount, expected_type=type_hints["mount"])
            check_type(argname="argument cf_api_trusted_certificates", value=cf_api_trusted_certificates, expected_type=type_hints["cf_api_trusted_certificates"])
            check_type(argname="argument cf_timeout", value=cf_timeout, expected_type=type_hints["cf_timeout"])
            check_type(argname="argument login_max_seconds_not_after", value=login_max_seconds_not_after, expected_type=type_hints["login_max_seconds_not_after"])
            check_type(argname="argument login_max_seconds_not_before", value=login_max_seconds_not_before, expected_type=type_hints["login_max_seconds_not_before"])
            check_type(argname="argument namespace", value=namespace, expected_type=type_hints["namespace"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "cf_api_addr": cf_api_addr,
            "cf_password_wo": cf_password_wo,
            "cf_username": cf_username,
            "identity_ca_certificates": identity_ca_certificates,
            "mount": mount,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if cf_api_trusted_certificates is not None:
            self._values["cf_api_trusted_certificates"] = cf_api_trusted_certificates
        if cf_timeout is not None:
            self._values["cf_timeout"] = cf_timeout
        if login_max_seconds_not_after is not None:
            self._values["login_max_seconds_not_after"] = login_max_seconds_not_after
        if login_max_seconds_not_before is not None:
            self._values["login_max_seconds_not_before"] = login_max_seconds_not_before
        if namespace is not None:
            self._values["namespace"] = namespace

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]], result)

    @builtins.property
    def for_each(self) -> typing.Optional["_cdktn_78ede62e.ITerraformIterator"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional["_cdktn_78ede62e.ITerraformIterator"], result)

    @builtins.property
    def lifecycle(
        self,
    ) -> typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"], result)

    @builtins.property
    def provider(self) -> typing.Optional["_cdktn_78ede62e.TerraformProvider"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformProvider"], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]], result)

    @builtins.property
    def cf_api_addr(self) -> builtins.str:
        '''CF's full API address, used for verifying that a given ``CF_INSTANCE_CERT`` shows an application ID, space ID, and organization ID that presently exist.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#cf_api_addr CfAuthBackendConfig#cf_api_addr}
        '''
        result = self._values.get("cf_api_addr")
        assert result is not None, "Required property 'cf_api_addr' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def cf_password_wo(self) -> builtins.str:
        '''The password for authenticating to the CF API.

        This is a write-only field and will not be read back from Vault.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#cf_password_wo CfAuthBackendConfig#cf_password_wo}
        '''
        result = self._values.get("cf_password_wo")
        assert result is not None, "Required property 'cf_password_wo' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def cf_username(self) -> builtins.str:
        '''The username for authenticating to the CF API.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#cf_username CfAuthBackendConfig#cf_username}
        '''
        result = self._values.get("cf_username")
        assert result is not None, "Required property 'cf_username' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def identity_ca_certificates(self) -> typing.List[builtins.str]:
        '''The root CA certificate(s) to be used for verifying that the ``CF_INSTANCE_CERT`` presented for logging in was issued by the proper authority.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#identity_ca_certificates CfAuthBackendConfig#identity_ca_certificates}
        '''
        result = self._values.get("identity_ca_certificates")
        assert result is not None, "Required property 'identity_ca_certificates' is missing"
        return typing.cast(typing.List[builtins.str], result)

    @builtins.property
    def mount(self) -> builtins.str:
        '''Mount path for the CF auth engine in Vault.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#mount CfAuthBackendConfig#mount}
        '''
        result = self._values.get("mount")
        assert result is not None, "Required property 'mount' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def cf_api_trusted_certificates(self) -> typing.Optional[typing.List[builtins.str]]:
        '''The certificate(s) presented by the CF API. Configures Vault to trust these certificates when making API calls.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#cf_api_trusted_certificates CfAuthBackendConfig#cf_api_trusted_certificates}
        '''
        result = self._values.get("cf_api_trusted_certificates")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def cf_timeout(self) -> typing.Optional[jsii.Number]:
        '''The timeout for the CF API in seconds.

        Defaults to ``0`` (no timeout). Removing this field from config resets the value to ``0`` in Vault.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#cf_timeout CfAuthBackendConfig#cf_timeout}
        '''
        result = self._values.get("cf_timeout")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def login_max_seconds_not_after(self) -> typing.Optional[jsii.Number]:
        '''The maximum number of seconds in the future when a signature could have been created.

        Defaults to ``60``. This field is ``Computed``: if removed from config, Vault retains the previously set value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#login_max_seconds_not_after CfAuthBackendConfig#login_max_seconds_not_after}
        '''
        result = self._values.get("login_max_seconds_not_after")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def login_max_seconds_not_before(self) -> typing.Optional[jsii.Number]:
        '''The maximum number of seconds in the past when a signature could have been created.

        Defaults to ``300``. This field is ``Computed``: if removed from config, Vault retains the previously set value.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#login_max_seconds_not_before CfAuthBackendConfig#login_max_seconds_not_before}
        '''
        result = self._values.get("login_max_seconds_not_before")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def namespace(self) -> typing.Optional[builtins.str]:
        '''Target namespace. (requires Enterprise).

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/vault/5.8.0/docs/resources/cf_auth_backend_config#namespace CfAuthBackendConfig#namespace}
        '''
        result = self._values.get("namespace")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfAuthBackendConfigConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "CfAuthBackendConfig",
    "CfAuthBackendConfigConfig",
]

publication.publish()

def _typecheckingstub__0f73c2d12a6a23aaf8268d61f646b127d703722f8d94da17a966abc489d7fd84(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    cf_api_addr: builtins.str,
    cf_password_wo: builtins.str,
    cf_username: builtins.str,
    identity_ca_certificates: typing.Sequence[builtins.str],
    mount: builtins.str,
    cf_api_trusted_certificates: typing.Optional[typing.Sequence[builtins.str]] = None,
    cf_timeout: typing.Optional[jsii.Number] = None,
    login_max_seconds_not_after: typing.Optional[jsii.Number] = None,
    login_max_seconds_not_before: typing.Optional[jsii.Number] = None,
    namespace: typing.Optional[builtins.str] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__835b09ac39a9e9b875bc4880d567911ba4559aa0ef0f445245827da9ba3d0025(
    scope: _constructs_77d1e7e8.Construct,
    import_to_id: builtins.str,
    import_from_id: builtins.str,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7d9f888759dc95c4e3339d28ca81900c727e2b78071fd335a560bdabe93cc948(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__49d0e8e9e15440727faa86b42b4d03b28cee09caff265f751b2aa61941c51104(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aedd68d0503cacfcaf63dcd2a604f94501a54fe728db099b0fd5ea49a8c62fc5(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d53ef8165f8611ef99906ced8a247c77fd582ef0ce03495a1fe53859997b5b40(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c608b33380da2d244536e259dce4f7ff8c861ef21b24b64a7cf04a3cb2c633ac(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1fde93bffd1fb5275ebe2e261b191556d8ef2051344ae48dc77f9b9f5c0e4458(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__77d15ae5171975f850304669f424fddd2fadaa1a970bdae8a66c68b1da60bc8d(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__880a6aee0661ab94ad9f3f511b7fdb3624818d442275071c7722b7458866d9fc(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__30c1fd56679d64dd114300f556223da0e0ed2d05995e34efbf8b95274f0d0cc9(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__91fa108024e339aa058a2a58a44633fdd67be6a93208bf9e93b1a304188d21d0(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ee1157ece897dac631359e89f9c23dbe17b151053a98db95080b1bd8c620d3f3(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    cf_api_addr: builtins.str,
    cf_password_wo: builtins.str,
    cf_username: builtins.str,
    identity_ca_certificates: typing.Sequence[builtins.str],
    mount: builtins.str,
    cf_api_trusted_certificates: typing.Optional[typing.Sequence[builtins.str]] = None,
    cf_timeout: typing.Optional[jsii.Number] = None,
    login_max_seconds_not_after: typing.Optional[jsii.Number] = None,
    login_max_seconds_not_before: typing.Optional[jsii.Number] = None,
    namespace: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass
