# FetchTranscript MCP Server

An [MCP](https://modelcontextprotocol.io) server that gives AI assistants (Claude Desktop, Cursor, etc.) access to YouTube transcripts, video metadata, channels, and search via the [FetchTranscript](https://fetchtranscript.com) API.

## Features

**8 Tools** — get transcripts, list languages, video metadata, chapters, comments, channel info, channel videos, search

**4 Documentation Resources** — API reference, quickstart guide, pricing, workflow examples

**3 Prompt Templates** — summarize video, compare videos, extract quotes

## Quick Start

### 1. Get an API Key

Sign up at [fetchtranscript.com](https://fetchtranscript.com) and create an API key from the dashboard.

### 2. Configure Claude Desktop

Add to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "fetchtranscript": {
      "command": "uvx",
      "args": ["fetchtranscript-mcp"],
      "env": {
        "FETCHTRANSCRIPT_API_KEY": "yt_your_key_here"
      }
    }
  }
}
```

### 3. Use it

Ask Claude:
- "Get the transcript of YouTube video dQw4w9WgXcQ"
- "Summarize this YouTube video: https://youtube.com/watch?v=..."
- "Search YouTube for 'machine learning explained' and summarize the top result"

## Configuration for Other Clients

### Cursor

Add to `.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "fetchtranscript": {
      "command": "uvx",
      "args": ["fetchtranscript-mcp"],
      "env": {
        "FETCHTRANSCRIPT_API_KEY": "yt_your_key_here"
      }
    }
  }
}
```

### Claude Code

```bash
claude mcp add fetchtranscript -- uvx fetchtranscript-mcp
```

Set `FETCHTRANSCRIPT_API_KEY` in your environment.

## Installation Alternatives

### pip

```bash
pip install fetchtranscript-mcp
FETCHTRANSCRIPT_API_KEY=yt_xxx fetchtranscript-mcp
```

### npx

```bash
FETCHTRANSCRIPT_API_KEY=yt_xxx npx @fetchtranscript/mcp-server
```

## Tools

| Tool | Description | Key defaults |
|------|-------------|--------------|
| `get_transcript` | Fetch video transcript | format=text |
| `list_languages` | Available transcript languages | — |
| `get_video_metadata` | Video title, views, likes, etc. | — |
| `get_chapters` | Video chapter list | — |
| `get_comments` | Top comments | limit=20 |
| `get_channel_info` | Channel metadata | — |
| `list_channel_videos` | Videos from a channel | limit=10 |
| `search_videos` | Search YouTube | limit=5 |

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `FETCHTRANSCRIPT_API_KEY` | Yes | Your API key (starts with `yt_`) |
| `FETCHTRANSCRIPT_BASE_URL` | No | Override API base URL (default: `https://api.fetchtranscript.com`) |

## Development

```bash
cd mcp
pip install -e ".[dev]"
pytest tests/
```

Test with MCP Inspector:

```bash
FETCHTRANSCRIPT_API_KEY=yt_xxx mcp dev src/fetchtranscript_mcp/server.py
```

## License

MIT
