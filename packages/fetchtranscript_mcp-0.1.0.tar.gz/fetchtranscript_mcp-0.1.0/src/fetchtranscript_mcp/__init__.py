"""FetchTranscript MCP Server — YouTube transcript tools for AI."""

__version__ = "0.1.0"
