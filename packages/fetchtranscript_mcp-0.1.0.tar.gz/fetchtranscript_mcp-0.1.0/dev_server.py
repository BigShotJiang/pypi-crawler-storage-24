"""Wrapper for `mcp dev` — re-exports the server with absolute imports."""

from fetchtranscript_mcp.server import mcp  # noqa: F401
