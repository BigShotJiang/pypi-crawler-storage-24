"""NRDP package."""
version = "0.1.0"