from __future__ import annotations

import sys
import time
from dataclasses import dataclass
from pathlib import Path
from threading import Lock
from typing import Any

from tqdm import tqdm
import typer


@dataclass
class PhaseStats:
    name: str
    total: int
    start_time: float
    end_time: float | None = None


class CommandReporter:
    def __init__(self, *, verbose: bool, log_path: Path) -> None:
        self.verbose = verbose
        self.log_path = log_path
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self._handle = self.log_path.open("a", encoding="utf-8")
        self._progress: Any | None = None
        self._lock = Lock()
        self._phase_stats: PhaseStats | None = None
        self._completed_phases: list[PhaseStats] = []

    def debug(self, message: str) -> None:
        self._write(f"DEBUG {message}", to_stdout=self.verbose)

    def info(self, message: str) -> None:
        self._write(message, to_stdout=True)

    def _format_duration(self, seconds: float) -> str:
        if seconds >= 60:
            minutes = int(seconds // 60)
            secs = int(seconds % 60)
            return f"{minutes}:{secs:02d}"
        return f"{seconds:.1f}s"

    def phase(self, name: str, *, total: int) -> None:
        self.finish_phase()
        self._write(f"PHASE {name} total={total}", to_stdout=False)
        self._phase_stats = PhaseStats(name=name, total=total, start_time=time.time())
        if self.verbose:
            return

        self._progress = tqdm(
            total=max(total, 0),
            desc=name,
            unit="samples",
            file=sys.stdout,
        )

    def advance(self, step: int = 1) -> None:
        with self._lock:
            if self._progress is not None:
                self._progress.update(step)

    def finish_phase(self) -> None:
        if self._phase_stats is not None:
            self._phase_stats.end_time = time.time()
            self._completed_phases.append(self._phase_stats)
            self._phase_stats = None
        if self._progress is None:
            return

        self._progress.close()
        self._progress = None

    def print_summary(self) -> None:
        if not self._completed_phases:
            return
        self._write("", to_stdout=True)
        self._write("Phase summary:", to_stdout=True)
        total_time = 0.0
        for stats in self._completed_phases:
            if stats.end_time is None:
                continue
            duration = stats.end_time - stats.start_time
            total_time += duration
            self._write(f"  {stats.name}: {self._format_duration(duration)}", to_stdout=True)
        self._write(f"Total time: {self._format_duration(total_time)}", to_stdout=True)

    def close(self) -> None:
        self.finish_phase()
        self._handle.close()

    def _write(self, message: str, *, to_stdout: bool) -> None:
        self._handle.write(f"{message}\n")
        self._handle.flush()
        if to_stdout:
            typer.echo(message)
