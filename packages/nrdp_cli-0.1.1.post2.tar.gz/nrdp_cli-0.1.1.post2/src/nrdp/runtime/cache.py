from __future__ import annotations

import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
from threading import Lock
from typing import Any

import numpy as np

from nrdp.domain.nrrd_io import load_nrrd


@dataclass(slots=True)
class PreloadedSample:
    patient_id: str
    data_path: Path
    label_path: Path
    data_shape: tuple[int, ...]
    data_header: dict[str, Any]
    label_header: dict[str, Any]
    data_array: np.ndarray
    label_array: np.ndarray


class CommandCache:
    def __init__(self) -> None:
        self._samples: dict[str, PreloadedSample] = {}
        self._lock = Lock()

    def get(self, patient_id: str) -> PreloadedSample | None:
        with self._lock:
            return self._samples.get(patient_id)

    def put(self, sample: PreloadedSample) -> None:
        with self._lock:
            self._samples[sample.patient_id] = sample

    def contains(self, patient_id: str) -> bool:
        with self._lock:
            return patient_id in self._samples


def _load_sample(patient_id: str, data_path: Path, label_path: Path) -> PreloadedSample:
    data_array, data_header = load_nrrd(data_path)
    label_array, label_header = load_nrrd(label_path)
    return PreloadedSample(
        patient_id=patient_id,
        data_path=data_path,
        label_path=label_path,
        data_shape=tuple(data_array.shape),
        data_header=data_header,
        label_header=label_header,
        data_array=data_array,
        label_array=label_array,
    )


def preload_sample_batch(
    *,
    cache: CommandCache,
    sample_pairs: list[tuple[str, Path, Path]],
    on_loaded: Any | None = None,
) -> None:
    pending = [
        (patient_id, data_path, label_path)
        for patient_id, data_path, label_path in sample_pairs
        if not cache.contains(patient_id)
    ]
    if not pending:
        return

    max_workers = min(8, os.cpu_count() or 4, len(pending))
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [
            executor.submit(_load_sample, patient_id, data_path, label_path)
            for patient_id, data_path, label_path in pending
        ]
        for future in as_completed(futures):
            sample = future.result()
            cache.put(sample)
            if on_loaded is not None:
                on_loaded(sample)
