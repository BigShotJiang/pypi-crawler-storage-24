from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import nrrd
import numpy as np


_STUB_FORMAT_KEY = "_nrdp_format"
_STUB_FORMAT_VALUE = "stub"
_WRITE_ONLY_HEADER_KEYS = {
    "type",
    "dimension",
    "endian",
    "encoding",
    "data file",
    "byte skip",
    "line skip",
}


def _looks_like_json_stub(path: Path) -> bool:
    with path.open("rb") as handle:
        prefix = handle.read(32)
    return prefix.lstrip().startswith(b"{")


def _build_stub_label_volume(shape: tuple[int, int, int], tumor_indices: list[int]) -> np.ndarray:
    label = np.zeros(shape, dtype=np.uint8)
    dims = list(shape)
    min_value = min(dims)
    if dims.count(min_value) != 1:
        return label

    axis = dims.index(min_value)
    for index in tumor_indices:
        if 0 <= index < shape[axis]:
            selection: list[slice | int] = [slice(None), slice(None), slice(None)]
            selection[axis] = index
            label[tuple(selection)] = 1

    return label


def _load_stub_document(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _load_stub_nrrd(path: Path) -> tuple[np.ndarray, dict[str, Any]]:
    document = _load_stub_document(path)
    shape = tuple(document["shape"])
    if "data" in document:
        data = np.array(document["data"]).reshape(shape)
    else:
        data = _build_stub_label_volume(shape, document.get("tumor_indices", []))

    header = dict(document.get("header", {"sizes": list(shape)}))
    header[_STUB_FORMAT_KEY] = _STUB_FORMAT_VALUE
    return data, header


def load_nrrd(path: Path) -> tuple[np.ndarray, dict[str, Any]]:
    if _looks_like_json_stub(path):
        return _load_stub_nrrd(path)

    data, header = nrrd.read(str(path))
    return np.asarray(data), dict(header)


def load_nrrd_shape(path: Path) -> tuple[int, ...]:
    if _looks_like_json_stub(path):
        document = _load_stub_document(path)
        return tuple(document["shape"])

    header = nrrd.read_header(str(path))
    return tuple(int(size) for size in header["sizes"])


def _prepare_header_for_write(header: dict[str, Any], data: np.ndarray) -> dict[str, Any]:
    prepared: dict[str, Any] = {}
    for key, value in header.items():
        if key.startswith("_nrdp_"):
            continue
        if key in _WRITE_ONLY_HEADER_KEYS:
            continue
        prepared[key] = value
    prepared["sizes"] = list(data.shape)
    return prepared


def save_nrrd(path: Path, data: np.ndarray, header: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if header.get(_STUB_FORMAT_KEY) == _STUB_FORMAT_VALUE:
        document = {
            "shape": list(data.shape),
            "data": data.tolist(),
            "header": _prepare_header_for_write(header, data),
        }
        path.write_text(json.dumps(document, indent=2), encoding="utf-8")
        return

    nrrd.write(str(path), data, header=_prepare_header_for_write(header, data))


def load_stub_nrrd(path: Path) -> tuple[np.ndarray, dict[str, Any]]:
    return load_nrrd(path)


def save_stub_nrrd(path: Path, data: np.ndarray, header: dict[str, Any]) -> None:
    save_nrrd(path, data, header)
