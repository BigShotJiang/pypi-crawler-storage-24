"""Domain logic for NRDP."""
