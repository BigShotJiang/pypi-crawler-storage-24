from __future__ import annotations

import math
from dataclasses import dataclass

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.transforms import Affine2D


@dataclass(slots=True)
class SliceRange:
    """切片范围：从最小肿瘤索引到最大肿瘤索引"""
    start: int
    end: int
    tumor_indices: list[int]


@dataclass(slots=True)
class VisualizationConfig:
    """可视化配置"""
    slice_spacing: float = 4.0
    angle: float = 30.0
    background_color: str = "black"
    tumor_color: str = "white"


def extract_slice_range(tumor_indices: list[int]) -> SliceRange | None:
    """从肿瘤索引列表中提取切片范围"""
    if not tumor_indices:
        return None
    return SliceRange(
        start=min(tumor_indices),
        end=max(tumor_indices),
        tumor_indices=tumor_indices,
    )


def prepare_slice_image(
    data_slice: np.ndarray,
    label_slice: np.ndarray,
) -> np.ndarray:
    """准备单层切片图像：透明背景 + 灰度脑组织 + 白色肿瘤"""
    data_min = float(data_slice.min())
    data_max = float(data_slice.max())
    if data_max > data_min:
        normalized = (data_slice - data_min) / (data_max - data_min) * 255.0
    else:
        normalized = np.zeros_like(data_slice, dtype=np.float32)

    grayscale = normalized.astype(np.uint8)
    result = np.zeros(data_slice.shape + (4,), dtype=np.uint8)

    visible_mask = grayscale > 0
    result[visible_mask, 0] = grayscale[visible_mask]
    result[visible_mask, 1] = grayscale[visible_mask]
    result[visible_mask, 2] = grayscale[visible_mask]
    result[visible_mask, 3] = 255

    tumor_mask = label_slice > 0
    result[tumor_mask] = np.array([255, 255, 255, 255], dtype=np.uint8)

    return result


def calculate_canvas_size(
    num_slices: int,
    slice_shape: tuple[int, int],
    slice_gap: int = 4,
    angle: float = 30.0,
    title_height: int = 100,
) -> tuple[int, int]:
    """根据切片数量自动计算画布大小"""
    base_height, base_width = slice_shape

    layer_count = max(num_slices - 1, 0)
    angle_rad = math.radians(angle)
    x_offset = math.ceil(layer_count * slice_gap * math.cos(angle_rad))
    y_offset = math.ceil(layer_count * slice_gap * math.sin(angle_rad))
    skew_width = math.ceil(base_height * math.tan(angle_rad))

    return (
        base_width + x_offset + skew_width,
        base_height + y_offset + title_height,
    )


def render_isometric_stack(
    slices: list[np.ndarray],
    config: VisualizationConfig,
) -> np.ndarray:
    """渲染等距视角堆叠图"""
    if not slices:
        return np.zeros((100, 0, 4), dtype=np.uint8)

    slice_shape = slices[0].shape[:2]
    canvas_width, canvas_height = calculate_canvas_size(
        len(slices),
        slice_shape,
        slice_gap=int(config.slice_spacing),
        angle=config.angle,
    )

    plt.switch_backend("agg")
    fig, ax = plt.subplots(
        figsize=(canvas_width / 100, canvas_height / 100),
        dpi=100,
        facecolor=config.background_color,
    )
    ax.set_xlim(0, canvas_width)
    ax.set_ylim(0, canvas_height)
    ax.set_aspect("equal")
    ax.axis("off")

    # 创建等距变换
    angle_rad = math.radians(config.angle)
    x_step = config.slice_spacing * math.cos(angle_rad)
    y_step = config.slice_spacing * math.sin(angle_rad)
    transform = Affine2D().skew_deg(config.angle, 0)

    # 从底部向上绘制切片
    for i, slice_img in enumerate(slices):
        x_offset = i * x_step
        y_offset = i * y_step
        extent = [x_offset, x_offset + slice_shape[1], y_offset, y_offset + slice_shape[0]]
        imshow_kwargs = {
            "extent": extent,
            "transform": transform + ax.transData,
            "origin": "lower",
            "interpolation": "nearest",
        }
        if slice_img.ndim == 2:
            imshow_kwargs["cmap"] = "gray"
            imshow_kwargs["vmin"] = 0
            imshow_kwargs["vmax"] = 255
        ax.imshow(slice_img, **imshow_kwargs)

    fig.subplots_adjust(left=0, right=1, bottom=0, top=1)

    # 转换为 numpy 数组
    fig.canvas.draw()
    result = np.frombuffer(fig.canvas.buffer_rgba(), dtype=np.uint8)
    result = result.reshape(fig.canvas.get_width_height()[::-1] + (4,))
    plt.close(fig)

    return result
