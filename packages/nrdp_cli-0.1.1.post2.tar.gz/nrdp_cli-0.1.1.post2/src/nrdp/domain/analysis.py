from dataclasses import dataclass

import numpy as np


@dataclass(slots=True)
class SampleAnalysis:
    sample_id: str
    axis: int | None
    tumor_indices: list[int]
    segments: list[list[int]]
    plan_status: dict | None | str


def analyze_sample(
    sample_id: str,
    data_shape: tuple[int, int, int],
    label: np.ndarray,
    times: int,
) -> SampleAnalysis:
    dims = list(data_shape)
    min_value = min(dims)
    if dims.count(min_value) != 1:
        return SampleAnalysis(sample_id, None, [], [], None)

    axis = dims.index(min_value)
    tumor_indices = [
        idx for idx in range(label.shape[axis]) if np.any(np.take(label, idx, axis=axis) > 0)
    ]
    if len(tumor_indices) < 2:
        return SampleAnalysis(sample_id, axis, tumor_indices, [], None)

    segments: list[list[int]] = []
    current = [tumor_indices[0]]
    for idx in tumor_indices[1:]:
        if idx == current[-1] + 1:
            current.append(idx)
        else:
            segments.append(current)
            current = [idx]
    segments.append(current)

    executable_segments = [segment for segment in segments if len(segment) >= 2]
    if not executable_segments:
        return SampleAnalysis(sample_id, axis, tumor_indices, segments, None)

    return SampleAnalysis(
        sample_id=sample_id,
        axis=axis,
        tumor_indices=tumor_indices,
        segments=segments,
        plan_status={
            "times": times,
            "segments": executable_segments,
        },
    )
