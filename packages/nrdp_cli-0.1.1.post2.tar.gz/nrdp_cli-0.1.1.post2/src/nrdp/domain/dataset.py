from dataclasses import dataclass, field
from pathlib import Path
import re


PATTERN = re.compile(r"^(U?MR[^.]+)\.(image|label)\.nrrd$")


@dataclass(slots=True)
class PairReport:
    pairs: list[tuple[str, Path, Path]] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


def collect_dataset_pairs(data_dir: Path, label_dir: Path) -> PairReport:
    report = PairReport()
    data_map = {
        match.group(1): path
        for path in data_dir.glob("*.nrrd")
        if (match := PATTERN.match(path.name))
    }
    label_map = {
        match.group(1): path
        for path in label_dir.glob("*.nrrd")
        if (match := PATTERN.match(path.name))
    }

    for patient_id in sorted(set(data_map) | set(label_map)):
        data_path = data_map.get(patient_id)
        label_path = label_map.get(patient_id)
        if data_path and label_path:
            report.pairs.append((patient_id, data_path, label_path))
        else:
            report.errors.append(patient_id)

    return report
