from __future__ import annotations

import numpy as np


def collect_contiguous_segments(indices: list[int]) -> list[list[int]]:
    if not indices:
        return []

    segments: list[list[int]] = []
    current = [indices[0]]
    for idx in indices[1:]:
        if idx == current[-1] + 1:
            current.append(idx)
        else:
            segments.append(current)
            current = [idx]
    segments.append(current)
    return segments


def expanded_tumor_slice_indices(axis_length: int, tumor_indices: list[int], times: int) -> list[int]:
    if len(tumor_indices) < 2 or times <= 1:
        return list(tumor_indices)

    left_indices = {
        left
        for segment in collect_contiguous_segments(tumor_indices)
        for left, _ in zip(segment, segment[1:])
    }
    tumor_set = set(tumor_indices)
    output_index = 0
    expanded: list[int] = []

    for input_index in range(axis_length):
        if input_index in tumor_set:
            if input_index in left_indices:
                for step in range(times):
                    expanded.append(output_index + step)
                output_index += times
            else:
                expanded.append(output_index)
                output_index += 1
        else:
            output_index += 1

    return expanded


def interpolate_binary_mask(mask_a: np.ndarray, mask_b: np.ndarray, alpha: float) -> np.ndarray:
    blended = (1.0 - alpha) * mask_a.astype(np.float32) + alpha * mask_b.astype(np.float32)
    return (blended >= 0.5).astype(np.uint8)
