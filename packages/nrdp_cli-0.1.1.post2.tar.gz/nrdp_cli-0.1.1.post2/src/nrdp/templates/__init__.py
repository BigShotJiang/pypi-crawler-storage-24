"""Template resources for NRDP."""
