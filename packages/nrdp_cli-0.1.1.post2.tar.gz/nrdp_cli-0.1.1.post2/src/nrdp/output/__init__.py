"""Output helpers for NRDP."""
