from __future__ import annotations

import csv
from pathlib import Path


def update_header_for_axis(header: dict, axis: int, new_size: int, times: int) -> dict:
    next_header = dict(header)
    sizes = list(next_header["sizes"])
    sizes[axis] = new_size
    next_header["sizes"] = sizes
    return next_header


def ensure_output_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def resolve_command_log_path(logs_dir: Path, command_name: str) -> Path:
    resolved_dir = logs_dir if not logs_dir.suffix else logs_dir.parent
    resolved_dir.mkdir(parents=True, exist_ok=True)
    return resolved_dir / f"{command_name}.log"


def write_summary_csv(path: Path, rows: list[dict[str, object]]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "patient_id",
        "status",
        "axis",
        "input_shape",
        "output_shape",
        "times",
        "inserted_slices",
    ]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    return path


def write_log(path: Path, message: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(message, encoding="utf-8")
    return path
