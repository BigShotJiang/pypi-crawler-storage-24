import json
from pathlib import Path
from typing import Any


def write_plan_document(plan_path: Path, document: dict[str, Any]) -> Path:
    plan_path.parent.mkdir(parents=True, exist_ok=True)
    plan_path.write_text(json.dumps(document, indent=2), encoding="utf-8")
    return plan_path
