from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

from nrdp.config.parser import load_config_document, load_dataset_config
from nrdp.domain.visualization import VisualizationConfig
from nrdp.domain.nrrd_io import load_nrrd
from nrdp.output.writers import ensure_output_dir, resolve_command_log_path
from nrdp.output.png_writer import generate_sample_png
from nrdp.runtime.cache import CommandCache
from nrdp.runtime.reporting import CommandReporter


AXIS_INDEX = {"X": 0, "Y": 1, "Z": 2}


def _sample_id(sample: dict[str, Any]) -> str:
    return Path(sample["data*"]).name.split(".")[0]


def execute_print(
    plan_path: Path,
    verbose: bool = False,
    *,
    workers: int = 4,
    cache: CommandCache | None = None,
    reporter: CommandReporter | None = None,
) -> dict[str, Any]:
    """执行 print 命令"""
    if not plan_path.exists():
        raise FileNotFoundError(f"Plan file not found: {plan_path}")

    document = load_config_document(plan_path)
    plan_root = document["nrdp"]
    config = load_dataset_config(Path(plan_root["json_path*"]))

    active_cache = cache or CommandCache()
    active_reporter = reporter or CommandReporter(
        verbose=verbose,
        log_path=resolve_command_log_path(config.logs_dir, "print"),
    )
    png_root = ensure_output_dir(config.png_output_dir)

    tumor_list = plan_root.get("tumor_list*", {})
    processable = [
        (patient_id, sample)
        for patient_id, sample in tumor_list.items()
        if isinstance(sample.get("nrdp_plan*"), dict)
    ]

    try:
        active_reporter.phase("Print", total=len(processable))

        results: list[dict[str, Any]] = []
        if processable:
            max_workers = min(workers, len(processable))
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = {
                    executor.submit(
                        _process_sample_png,
                        sample,
                        config=config,
                    ): patient_id
                    for patient_id, sample in processable
                }
                for future in as_completed(futures):
                    patient_id = futures[future]
                    try:
                        result = future.result()
                        results.append(result)
                        active_reporter.advance()
                        active_reporter.debug(f"generated PNG for {patient_id}")
                    except Exception as e:
                        results.append({
                            "patient_id": patient_id,
                            "status": "error",
                            "error": str(e),
                        })
                        active_reporter.advance()

        active_reporter.print_summary()
    finally:
        if reporter is None:
            active_reporter.close()

    return {
        "total": len(processable),
        "success": sum(1 for r in results if r.get("status") == "success"),
        "errors": sum(1 for r in results if r.get("status") == "error"),
    }


def _process_sample_png(
    sample: dict[str, Any],
    *,
    config: Any,
) -> dict[str, Any]:
    """处理单个样本的 PNG 生成"""
    patient_id = _sample_id(sample)
    axis_names = sample.get("axis*", [])
    if not axis_names:
        return {"patient_id": patient_id, "status": "skipped", "reason": "no axis"}

    axis = AXIS_INDEX.get(axis_names[0])
    if axis is None:
        return {"patient_id": patient_id, "status": "skipped", "reason": "invalid axis"}

    tumor_indices = sample.get("slides*", {}).get("tumor_slice_index", [])

    if not tumor_indices:
        return {"patient_id": patient_id, "status": "skipped", "reason": "no tumor"}

    plan_data = sample.get("nrdp_plan*")
    if not isinstance(plan_data, dict):
        return {"patient_id": patient_id, "status": "skipped", "reason": "no plan"}

    expanded_tumor_indices = plan_data.get("tumor_expanded_slice_index", [])
    if not expanded_tumor_indices:
        raise ValueError(f"Expanded tumor slice indices missing for {patient_id}")

    # 加载原始数据
    original_data, _ = load_nrrd(Path(sample["data*"]))
    original_label, _ = load_nrrd(Path(sample["label*"]))

    # 加载插值后数据
    output_data_path = config.output_dir / "data" / Path(sample["data*"]).name
    output_label_path = config.output_dir / "label" / Path(sample["label*"]).name

    if not output_data_path.exists():
        raise ValueError(f"Output data not found: {output_data_path}. Run 'nrdp start' first.")

    expanded_data, _ = load_nrrd(output_data_path)
    expanded_label, _ = load_nrrd(output_label_path)

    # 生成 PNG
    output_dir = config.png_output_dir / patient_id
    generate_sample_png(
        patient_id=patient_id,
        original_data=original_data,
        original_label=original_label,
        expanded_data=expanded_data,
        expanded_label=expanded_label,
        axis=axis,
        tumor_indices=tumor_indices,
        expanded_tumor_indices=expanded_tumor_indices,
        output_dir=output_dir,
        config=VisualizationConfig(),
    )

    return {"patient_id": patient_id, "status": "success"}
