from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

import numpy as np

from nrdp.config.parser import load_config_document, load_dataset_config
from nrdp.domain.interpolation import collect_contiguous_segments, interpolate_binary_mask
from nrdp.domain.nrrd_io import load_nrrd, save_nrrd
from nrdp.output.writers import (
    ensure_output_dir,
    resolve_command_log_path,
    update_header_for_axis,
    write_summary_csv,
)
from nrdp.runtime.cache import CommandCache, preload_sample_batch
from nrdp.runtime.reporting import CommandReporter


AXIS_INDEX = {"X": 0, "Y": 1, "Z": 2}


def _sample_id(sample: dict[str, Any]) -> str:
    return Path(sample["data*"]).name.split(".")[0]


def validate_start_plan(document: dict[str, Any]) -> None:
    tumor_list = document.get("nrdp", {}).get("tumor_list*", {})
    for sample in tumor_list.values():
        if sample.get("nrdp_plan*") == "error":
            raise ValueError("Plan contains error entries; run nrdp plan --fix --plan <plan>")


def _expand_volume(
    volume: np.ndarray,
    *,
    axis: int,
    segments: list[list[int]],
    times: int,
    binary: bool,
) -> np.ndarray:
    inserts_by_left: dict[int, list[np.ndarray]] = {}
    for segment in segments:
        for left, right in zip(segment, segment[1:]):
            left_slice = np.take(volume, left, axis=axis)
            right_slice = np.take(volume, right, axis=axis)
            generated: list[np.ndarray] = []
            for step in range(1, times):
                alpha = step / times
                if binary:
                    generated.append(interpolate_binary_mask(left_slice, right_slice, alpha))
                else:
                    blended = (1.0 - alpha) * left_slice.astype(np.float32) + alpha * right_slice.astype(
                        np.float32
                    )
                    generated.append(blended.astype(volume.dtype))
            inserts_by_left.setdefault(left, []).extend(generated)

    slices: list[np.ndarray] = []
    for index in range(volume.shape[axis]):
        slices.append(np.take(volume, index, axis=axis))
        slices.extend(inserts_by_left.get(index, []))
    return np.stack(slices, axis=axis)


def _validate_expanded_axis_size(
    *,
    patient_id: str,
    input_shape: tuple[int, ...],
    output_data_shape: tuple[int, ...],
    output_label_shape: tuple[int, ...],
    axis: int,
    segments: list[list[int]],
    times: int,
    planned_axis_size: int,
) -> None:
    min_axis = min(range(len(input_shape)), key=input_shape.__getitem__)
    if axis != min_axis:
        raise ValueError(f"{patient_id}: interpolation axis {axis} is not the minimum axis {min_axis}")

    expected_inserted_slices = sum((len(segment) - 1) * (times - 1) for segment in segments)
    expected_axis_size = input_shape[axis] + expected_inserted_slices
    if planned_axis_size != expected_axis_size:
        raise ValueError(
            f"{patient_id}: expanded axis {axis} size mismatch, expected {expected_axis_size}, got plan {planned_axis_size}"
        )
    if output_data_shape[axis] != expected_axis_size:
        raise ValueError(
            f"{patient_id}: expanded axis {axis} size mismatch, expected {expected_axis_size}, got {output_data_shape[axis]}"
        )
    if output_label_shape[axis] != expected_axis_size:
        raise ValueError(
            f"{patient_id}: expanded label axis {axis} size mismatch, expected {expected_axis_size}, got {output_label_shape[axis]}"
        )


def _process_sample(
    sample: dict[str, Any],
    *,
    cache: CommandCache | None,
    output_data_dir: Path,
    output_label_dir: Path,
) -> dict[str, object]:
    axis_names = sample.get("axis*", [])
    axis = AXIS_INDEX.get(axis_names[0]) if axis_names else None
    if axis is None or not isinstance(sample.get("nrdp_plan*"), dict):
        return {
            "patient_id": _sample_id(sample),
            "status": "skipped",
            "axis": axis,
            "input_shape": sample.get("size*"),
            "output_shape": sample.get("size*"),
            "times": None,
            "inserted_slices": 0,
        }

    tumor_indices = sample.get("slides*", {}).get("tumor_slice_index", [])
    segments = collect_contiguous_segments(tumor_indices)

    times = int(sample["nrdp_plan*"]["times"])
    patient_id = _sample_id(sample)
    cached = cache.get(_sample_id(sample)) if cache is not None else None
    if cached is not None:
        data = cached.data_array
        data_header = cached.data_header
        label = cached.label_array
        label_header = cached.label_header
    else:
        data, data_header = load_nrrd(Path(sample["data*"]))
        label, label_header = load_nrrd(Path(sample["label*"]))

    expanded_data = _expand_volume(data, axis=axis, segments=segments, times=times, binary=False)
    expanded_label = _expand_volume(label, axis=axis, segments=segments, times=times, binary=True)
    _validate_expanded_axis_size(
        patient_id=patient_id,
        input_shape=tuple(data.shape),
        output_data_shape=tuple(expanded_data.shape),
        output_label_shape=tuple(expanded_label.shape),
        axis=axis,
        segments=segments,
        times=times,
        planned_axis_size=int(sample["nrdp_plan*"]["nrdp_slides"]),
    )

    output_data_path = output_data_dir / Path(sample["data*"]).name
    output_label_path = output_label_dir / Path(sample["label*"]).name
    save_nrrd(
        output_data_path,
        expanded_data,
        update_header_for_axis(data_header, axis=axis, new_size=expanded_data.shape[axis], times=times),
    )
    save_nrrd(
        output_label_path,
        expanded_label,
        update_header_for_axis(label_header, axis=axis, new_size=expanded_label.shape[axis], times=times),
    )

    inserted_slices = expanded_data.shape[axis] - data.shape[axis]
    return {
        "patient_id": patient_id,
        "status": "processed",
        "axis": axis,
        "input_shape": list(data.shape),
        "output_shape": list(expanded_data.shape),
        "times": times,
        "inserted_slices": inserted_slices,
    }


def execute_start(
    plan_path: Path,
    verbose: bool = False,
    *,
    workers: int = 4,
    cache: CommandCache | None = None,
    reporter: CommandReporter | None = None,
) -> dict[str, Any]:
    document = load_config_document(plan_path)
    validate_start_plan(document)

    plan_root = document["nrdp"]
    config = load_dataset_config(Path(plan_root["json_path*"]))
    active_cache = cache or CommandCache()
    active_reporter = reporter or CommandReporter(
        verbose=verbose,
        log_path=resolve_command_log_path(config.logs_dir, "start"),
    )
    output_root = ensure_output_dir(config.output_dir)
    output_data_dir = ensure_output_dir(output_root / "data")
    output_label_dir = ensure_output_dir(output_root / "label")
    png_root = ensure_output_dir(config.png_output_dir)

    tumor_list = list(plan_root.get("tumor_list*", {}).values())
    processable_samples = [sample for sample in tumor_list if isinstance(sample.get("nrdp_plan*"), dict)]
    preload_pairs = [
        (_sample_id(sample), Path(sample["data*"]), Path(sample["label*"]))
        for sample in processable_samples
        if not active_cache.contains(_sample_id(sample))
    ]

    try:
        active_reporter.phase("Preload", total=len(preload_pairs))
        preload_sample_batch(
            cache=active_cache,
            sample_pairs=preload_pairs,
            on_loaded=(
                (lambda sample: (active_reporter.advance(), active_reporter.debug(f"loaded sample {sample.patient_id}")))
                if preload_pairs
                else None
            ),
        )
        active_reporter.finish_phase()

        rows_by_index: list[dict[str, object] | None] = [None] * len(tumor_list)
        processable_entries: list[tuple[int, dict[str, Any]]] = []
        active_reporter.phase("Expand", total=len(tumor_list))
        for index, sample in enumerate(tumor_list):
            if sample.get("nrdp_plan*") is None:
                rows_by_index[index] = {
                    "patient_id": _sample_id(sample),
                    "status": "skipped",
                    "axis": AXIS_INDEX.get(sample.get("axis*", [None])[0]) if sample.get("axis*") else None,
                    "input_shape": sample.get("size*"),
                    "output_shape": sample.get("size*"),
                    "times": None,
                    "inserted_slices": 0,
                }
                active_reporter.advance()
                active_reporter.debug(f"skipped sample {_sample_id(sample)}")
                continue

            processable_entries.append((index, sample))

        if processable_entries:
            max_workers = min(workers, len(processable_entries))
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                future_to_index = {
                    executor.submit(
                        _process_sample,
                        sample,
                        cache=active_cache,
                        output_data_dir=output_data_dir,
                        output_label_dir=output_label_dir,
                    ): index
                    for index, sample in processable_entries
                }
                for future in as_completed(future_to_index):
                    index = future_to_index[future]
                    row = future.result()
                    rows_by_index[index] = row
                    ensure_output_dir(png_root / str(row["patient_id"]))
                    active_reporter.advance()

            # 按顺序写日志
            for row in rows_by_index:
                if row is not None:
                    active_reporter.debug(f"expanded sample {row['patient_id']}")

        active_reporter.finish_phase()
        rows = [row for row in rows_by_index if row is not None]
        write_summary_csv(output_root / "nrdp.csv", rows)
        active_reporter.debug(f"processed {sum(row['status'] == 'processed' for row in rows)} samples")
        active_reporter.print_summary()
    finally:
        if reporter is None:
            active_reporter.close()
    return document
