from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

from nrdp.config.parser import load_config_document, load_dataset_config
from nrdp.domain.analysis import analyze_sample
from nrdp.domain.dataset import collect_dataset_pairs
from nrdp.domain.interpolation import expanded_tumor_slice_indices
from nrdp.output.writers import resolve_command_log_path
from nrdp.output.plan_writer import write_plan_document
from nrdp.runtime.cache import CommandCache, PreloadedSample, preload_sample_batch
from nrdp.runtime.reporting import CommandReporter


AXIS_NAMES = ["X", "Y", "Z"]


def _build_patient_plan_entry(
    *,
    patient_id: str,
    data_path: Path,
    label_path: Path,
    shape: tuple[int, int, int],
    analysis: Any,
) -> dict[str, Any]:
    axis_name = [AXIS_NAMES[analysis.axis]] if analysis.axis is not None else []
    tumor_indices = analysis.tumor_indices
    slides = {
        "count": shape[analysis.axis] if analysis.axis is not None else None,
        "tumor_slices": len(tumor_indices),
        "tumor_slice_index": tumor_indices,
    }

    if analysis.plan_status == "error":
        plan_value: dict[str, Any] | None | str = "error"
    elif analysis.plan_status is None:
        plan_value = None
    else:
        times = int(analysis.plan_status["times"])
        expanded_positions = expanded_tumor_slice_indices(shape[analysis.axis], tumor_indices, times)
        plan_value = {
            "times": times,
            "nrdp_slides": shape[analysis.axis] + (len(expanded_positions) - len(tumor_indices)),
            "tumor_expanded_slices": len(expanded_positions),
            "tumor_expanded_slice_index": expanded_positions,
        }

    return {
        "data*": str(data_path),
        "label*": str(label_path),
        "size*": list(shape),
        "axis*": axis_name,
        "slides*": slides,
        "nrdp_plan*": plan_value,
    }


def _analyze_preloaded_sample(
    *,
    patient_id: str,
    data_path: Path,
    label_path: Path,
    sample: PreloadedSample,
    times: int,
) -> tuple[str, dict[str, Any]]:
    analysis = analyze_sample(
        sample_id=patient_id,
        data_shape=sample.data_shape,
        label=sample.label_array,
        times=times,
    )
    return (
        patient_id,
        _build_patient_plan_entry(
            patient_id=patient_id,
            data_path=data_path,
            label_path=label_path,
            shape=sample.data_shape,
            analysis=analysis,
        ),
    )


def build_plan_document(
    config_path: Path,
    *,
    workers: int = 4,
    cache: CommandCache | None = None,
    reporter: CommandReporter | None = None,
) -> tuple[dict[str, Any], bool]:
    config = load_dataset_config(config_path)
    dataset_name = config.dataset_name
    data_dir = config.data_dir
    label_dir = config.label_dir
    nrdp_times = config.nrdp_times
    active_cache = cache or CommandCache()

    pair_report = collect_dataset_pairs(data_dir=data_dir, label_dir=label_dir)
    tumor_list: dict[str, Any] = {}

    for patient_id in pair_report.errors:
        tumor_list[patient_id] = {
            "data*": str(data_dir / f"{patient_id}.image.nrrd"),
            "label*": str(label_dir / f"{patient_id}.label.nrrd"),
            "size*": [],
            "axis*": [],
            "slides*": {
                "count": None,
                "tumor_slices": 0,
                "tumor_slice_index": [],
            },
            "nrdp_plan*": "error",
        }

    if reporter is not None:
        reporter.phase("Preload", total=len(pair_report.pairs))

    preload_sample_batch(
        cache=active_cache,
        sample_pairs=pair_report.pairs,
        on_loaded=(
            (lambda sample: (reporter.advance(), reporter.debug(f"loaded sample {sample.patient_id}")))
            if reporter is not None
            else None
        ),
    )

    if reporter is not None:
        reporter.finish_phase()
        reporter.phase("Analyze", total=len(pair_report.pairs))

    ordered_results: list[tuple[str, dict[str, Any]] | None] = [None] * len(pair_report.pairs)
    if pair_report.pairs:
        max_workers = min(workers, len(pair_report.pairs))
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_index = {}
            for index, (patient_id, data_path, label_path) in enumerate(pair_report.pairs):
                sample = active_cache.get(patient_id)
                if sample is None:
                    raise ValueError(f"Missing preloaded sample for {patient_id}")
                future = executor.submit(
                    _analyze_preloaded_sample,
                    patient_id=patient_id,
                    data_path=data_path,
                    label_path=label_path,
                    sample=sample,
                    times=nrdp_times,
                )
                future_to_index[future] = index

            for future in as_completed(future_to_index):
                index = future_to_index[future]
                patient_id, entry = future.result()
                ordered_results[index] = (patient_id, entry)
                if reporter is not None:
                    reporter.advance()

            # 按顺序写日志
            if reporter is not None:
                for result in ordered_results:
                    if result is not None:
                        patient_id, _ = result
                        reporter.debug(f"analyzed sample {patient_id}")

        for result in ordered_results:
            if result is None:
                raise ValueError("Analyze phase did not produce a complete result set")
            patient_id, entry = result
            tumor_list[patient_id] = entry

    if reporter is not None:
        reporter.finish_phase()

    plan_document = {
        "nrdp": {
            "name*": dataset_name,
            "json_path*": str(config_path),
            "data": str(data_dir),
            "label": str(label_dir),
            "tumor_list*": tumor_list,
        }
    }
    has_errors = any(sample["nrdp_plan*"] == "error" for sample in tumor_list.values())
    return plan_document, has_errors


def execute_plan(
    input_path: Path,
    verbose: bool = False,
    *,
    workers: int = 4,
    cache: CommandCache | None = None,
    reporter: CommandReporter | None = None,
) -> tuple[Path, bool]:
    config = load_dataset_config(input_path)
    plan_path = config.plan_output_path
    active_reporter = reporter or CommandReporter(
        verbose=verbose,
        log_path=resolve_command_log_path(config.logs_dir, "plan"),
    )
    try:
        plan_document, has_errors = build_plan_document(
            input_path,
            workers=workers,
            cache=cache,
            reporter=active_reporter,
        )
        write_plan_document(plan_path, plan_document)
        active_reporter.debug(f"wrote plan file to {plan_path}")
        active_reporter.print_summary()
    finally:
        if reporter is None:
            active_reporter.close()
    return plan_path, has_errors


def repair_plan_document(document: dict[str, Any]) -> dict[str, Any]:
    for sample in document.get("nrdp", {}).get("tumor_list*", {}).values():
        if sample.get("nrdp_plan*") == "error":
            sample["nrdp_plan*"] = None
    return document
