from __future__ import annotations

from pathlib import Path

import typer

from nrdp.commands.plan import execute_plan
from nrdp.commands.print import execute_print
from nrdp.commands.start import execute_start
from nrdp.runtime.cache import CommandCache


def run_pipeline(config_path: Path, verbose: bool, workers: int = 4) -> int:
    cache = CommandCache()
    plan_path, has_errors = execute_plan(
        input_path=config_path,
        verbose=verbose,
        workers=workers,
        cache=cache,
    )
    if has_errors:
        typer.echo(f"Inspect the exported plan: {plan_path}")
        typer.echo(f"Repair with: nrdp plan --fix --plan {plan_path}")
        raise typer.Exit(code=1)

    execute_start(
        plan_path=plan_path,
        verbose=verbose,
        workers=workers,
        cache=cache,
    )

    execute_print(
        plan_path=plan_path,
        verbose=verbose,
        workers=workers,
        cache=cache,
    )

    return 0
