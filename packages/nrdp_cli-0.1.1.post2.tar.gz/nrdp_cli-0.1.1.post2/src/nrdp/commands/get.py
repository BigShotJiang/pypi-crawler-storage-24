from importlib import resources
from pathlib import Path


def write_dataset_template(destination_dir: Path) -> Path:
    template = resources.files("nrdp.templates").joinpath("dataset.jsonl").read_text(encoding="utf-8")
    output_path = destination_dir / "dataset.jsonl"
    output_path.write_text(template, encoding="utf-8")
    return output_path


def write_plan_template(destination_dir: Path) -> Path:
    template = resources.files("nrdp.templates").joinpath("plan.jsonl").read_text(encoding="utf-8")
    output_path = destination_dir / "plan.jsonl"
    output_path.write_text(template, encoding="utf-8")
    return output_path
