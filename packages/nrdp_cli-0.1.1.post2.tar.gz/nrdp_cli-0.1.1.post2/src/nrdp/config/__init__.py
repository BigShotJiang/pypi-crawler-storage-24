"""Configuration helpers for NRDP."""
