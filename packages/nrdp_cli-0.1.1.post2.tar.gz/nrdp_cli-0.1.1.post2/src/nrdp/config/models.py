from dataclasses import dataclass
from pathlib import Path


@dataclass(slots=True)
class DatasetConfig:
    dataset_name: str
    data_dir: Path
    label_dir: Path
    output_dir: Path
    plan_output_path: Path
    logs_dir: Path
    png_output_dir: Path
    nrdp_times: int

    @property
    def logs_path(self) -> Path:
        return self.logs_dir
