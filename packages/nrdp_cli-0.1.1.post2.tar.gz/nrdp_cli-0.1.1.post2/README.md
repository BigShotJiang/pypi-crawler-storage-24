# NRDP
Nrrd Process

## 项目环境

- 使用conda虚拟环境"nrdp"的python作为编译器
- WSL2（Ubuntu24.04）
