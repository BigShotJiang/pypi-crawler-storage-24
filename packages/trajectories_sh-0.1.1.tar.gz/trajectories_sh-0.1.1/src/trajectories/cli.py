"""trajectories CLI entry point."""

from pathlib import Path

import click
from rich.console import Console

from trajectories.config import get_api_key, get_api_url, set_api_key, set_api_url

console = Console()


@click.group()
@click.version_option(package_name="trajectories-sh")
def main():
    """trajectories.sh — Upload and share Harbor trajectory jobs."""
    pass


@main.command()
@click.argument("job_dir", type=click.Path(exists=True, file_okay=False, path_type=Path))
@click.option("--slug", "-s", default=None, help="URL slug (default: directory name)")
@click.option("--name", "-n", default=None, help="Display name (default: slug)")
@click.option("--visibility", "-v", type=click.Choice(["public", "unlisted", "private"]), default="private")
@click.option("--api-url", default=None, help="API base URL (override config)")
@click.option("--api-key", default=None, help="API key (override config)")
@click.option("--concurrency", "-c", default=4, help="Parallel upload threads")
def push(job_dir, slug, name, visibility, api_url, api_key, concurrency):
    """Push a Harbor job directory to trajectories.sh."""
    from trajectories.push import push_job
    push_job(job_dir, slug=slug, name=name, visibility=visibility,
             api_url=api_url, api_key=api_key, concurrency=concurrency)


@main.command()
@click.option("--api-key", prompt="API key", help="Your trajectories.sh API key")
@click.option("--api-url", default=None, help="Custom API URL (default: trajectories.sh)")
def login(api_key, api_url):
    """Save your API key for future pushes."""
    set_api_key(api_key)
    if api_url:
        set_api_url(api_url)

    console.print(f"[green]API key saved to ~/.trajectories-sh/config.json[/green]")
    console.print(f"  Key: {api_key[:12]}...")
    console.print(f"  URL: {api_url or get_api_url()}")


@main.command()
def whoami():
    """Show current configuration."""
    key = get_api_key()
    url = get_api_url()

    if key:
        console.print(f"  API key: {key[:12]}...")
    else:
        console.print("  [dim]No API key configured[/dim]")
    console.print(f"  API URL: {url}")


@main.command()
def logout():
    """Remove saved API key."""
    from trajectories.config import CONFIG_FILE
    if CONFIG_FILE.exists():
        CONFIG_FILE.unlink()
        console.print("[green]Logged out. Config removed.[/green]")
    else:
        console.print("[dim]No config to remove.[/dim]")


if __name__ == "__main__":
    main()
