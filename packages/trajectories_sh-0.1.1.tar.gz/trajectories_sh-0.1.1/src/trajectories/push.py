"""Push a Harbor job directory to trajectories.sh."""

import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import httpx
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn

from trajectories.config import get_api_key, get_api_url

console = Console()

SKIP_PATTERNS = {"__pycache__", ".DS_Store", ".git"}
MAX_FILE_SIZE = 50 * 1024 * 1024


def collect_files(job_dir: Path) -> list[tuple[Path, str]]:
    """Collect all files in the job directory with relative paths."""
    files = []
    for root, dirs, filenames in os.walk(job_dir):
        dirs[:] = [d for d in dirs if d not in SKIP_PATTERNS]
        for name in filenames:
            if name in SKIP_PATTERNS:
                continue
            abs_path = Path(root) / name
            rel_path = abs_path.relative_to(job_dir)
            if abs_path.stat().st_size > MAX_FILE_SIZE:
                continue
            files.append((abs_path, str(rel_path)))
    return files


def push_job(
    job_dir: Path,
    slug: str | None = None,
    name: str | None = None,
    visibility: str = "private",
    api_url: str | None = None,
    api_key: str | None = None,
    concurrency: int = 8,
):
    """Push a Harbor job directory to trajectories.sh."""
    api_url = api_url or get_api_url()
    api_key = api_key or get_api_key()

    if not api_key:
        console.print("[red]No API key configured. Run: trajectories login[/red]")
        raise SystemExit(1)

    if not job_dir.exists() or not job_dir.is_dir():
        console.print(f"[red]Directory not found: {job_dir}[/red]")
        raise SystemExit(1)

    if not slug:
        slug = job_dir.name

    if not name:
        name = slug

    headers = {"Authorization": f"Bearer {api_key}"}
    client = httpx.Client(base_url=api_url, headers=headers, timeout=60.0)

    console.print(f"[bold]Pushing[/bold] {job_dir} → [cyan]{slug}[/cyan]")

    files = collect_files(job_dir)
    total_size = sum(f.stat().st_size for f, _ in files)
    console.print(f"  {len(files)} files, {total_size / 1024 / 1024:.1f} MB")

    resp = client.post("/api/cli/push/init", json={
        "slug": slug,
        "name": name,
        "visibility": visibility,
    })
    if resp.status_code != 200:
        console.print(f"[red]Init failed: {resp.text}[/red]")
        raise SystemExit(1)

    init_data = resp.json()
    job_id = init_data["job_id"]
    console.print(f"  Job ID: [dim]{job_id}[/dim]")

    uploaded = 0
    errors = 0

    def upload_one(abs_path: Path, rel_path: str) -> bool:
        import time
        for attempt in range(3):
            try:
                with open(abs_path, "rb") as f:
                    upload_resp = client.post(
                        f"/api/cli/push/{job_id}/file",
                        files={"file": (rel_path, f, "application/octet-stream")},
                        data={"path": rel_path},
                    )
                if upload_resp.status_code == 200:
                    return True
            except Exception:
                pass
            if attempt < 2:
                time.sleep(1.0 * (attempt + 1))
        return False

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("Uploading...", total=len(files))

        with ThreadPoolExecutor(max_workers=concurrency) as executor:
            futures = {executor.submit(upload_one, ap, rp): rp for ap, rp in files}
            for future in as_completed(futures):
                if future.result():
                    uploaded += 1
                else:
                    errors += 1
                progress.advance(task)

    console.print(f"  Uploaded: {uploaded}, Errors: {errors}")

    console.print("  Finalizing...")
    resp = client.post(f"/api/cli/push/{job_id}/finalize")
    if resp.status_code != 200:
        console.print(f"[red]Finalize failed: {resp.text}[/red]")
        raise SystemExit(1)

    result = resp.json()
    console.print()
    console.print(f"[green bold]Pushed successfully![/green bold]")
    console.print(f"  Trials: {result['n_trials']}")
    if result.get("mean_reward") is not None:
        console.print(f"  Pass rate: {result['mean_reward'] * 100:.0f}%")
    console.print(f"  Viewer: {api_url}{result['viewer_url']}")
