from setuptools import setup, find_packages

setup(
    name="things-pytools-dasheer",
    version="0.5",
    packages=find_packages(),
)