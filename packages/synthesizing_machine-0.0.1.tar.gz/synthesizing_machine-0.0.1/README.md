# Synthesizing Machine
A Machine that performs the synthesis of meaning.
```bash
  echo "Theodotos-Alexandreus: Are language models seeking the Truth, machine?" \
    | uvx synthesizing-machine \
        --provider-api-key=sk-ant-api... \
        --github-token=ghp_... 
```
Or:
```bash
  pip install synthesizing-machine
```
Then:
```Python
  # Python
  import synthesizing_machine
```
