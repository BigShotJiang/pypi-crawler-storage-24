"""
Setup script for PNG Offline Optimizer
使用 CMake 进行编译，支持跨平台编译
"""

import os
import sys
import platform
import subprocess
from pathlib import Path
from setuptools import setup, Extension
from setuptools.command.build_ext import build_ext
from distutils.util import get_platform


class CMakeExtension(Extension):
    """CMake 扩展"""
    def __init__(self, name, sourcedir=""):
        Extension.__init__(self, name, sources=[])
        self.sourcedir = os.path.abspath(sourcedir)


class CMakeBuild(build_ext):
    """使用 CMake 编译 C++ 扩展"""
    
    def build_extension(self, ext):
        if isinstance(ext, CMakeExtension):
            self.build_cmake_extension(ext)
        else:
            super().build_extension(ext)
    
    def build_cmake_extension(self, ext):
        extdir = os.path.abspath(os.path.dirname(self.get_ext_fullpath(ext.name)))
        
        # 必需的工具
        cmake_args = []
        cfg = "Debug" if self.debug else "Release"
        build_args = ["--config", cfg]
        
        # 平台特定配置
        if platform.system() == "Windows":
            cmake_args += [
                f"-DCMAKE_LIBRARY_OUTPUT_DIRECTORY={extdir}",
                f"-DCMAKE_RUNTIME_OUTPUT_DIRECTORY={extdir}",
            ]
            if sys.maxsize > 2**32:
                cmake_args += ["-A", "x64"]
            else:
                cmake_args += ["-A", "Win32"]
            build_args += ["--", "/M:4"]
        else:
            cmake_args += [f"-DCMAKE_LIBRARY_OUTPUT_DIRECTORY={extdir}"]
            cmake_args += [f"-DCMAKE_BUILD_TYPE={cfg}"]
            build_args += ["--", "-j4"]
        
        # 跨编译支持
        if platform.system() == "Darwin":
            # macOS 特定
            cmake_args += ["-DCMAKE_OSX_DEPLOYMENT_TARGET=10.13"]
        
        # Python 路径
        if not os.environ.get("CONDA_DEFAULT_ENV"):
            # 非 conda 环境
            pass
        
        # 构建临时目录
        if not os.path.exists(self.build_temp):
            os.makedirs(self.build_temp)
        
        # 运行 CMake 配置
        subprocess.check_call(
            ["cmake", ext.sourcedir] + cmake_args,
            cwd=self.build_temp
        )
        
        # 运行 CMake 编译
        subprocess.check_call(
            ["cmake", "--build", "."] + build_args,
            cwd=self.build_temp
        )
        
        print("CMake build completed successfully!")


def get_version():
    """读取版本号"""
    version_file = Path(__file__).parent / "version.txt"
    if version_file.exists():
        return version_file.read_text().strip()
    return "3.20"


setup(
    name="png-offline-optimizer",
    version=get_version(),
    author="Your Name",
    author_email="your.email@example.com",
    description="Intelligent offline PNG compression with OpenCV feature analysis",
    long_description=Path("README_PY.md").read_text(encoding="utf-8") 
                     if Path("README_PY.md").exists() else "",
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/png-offline-optimizer",
    project_urls={
        "Bug Tracker": "https://github.com/yourusername/png-offline-optimizer/issues",
        "Documentation": "https://github.com/yourusername/png-offline-optimizer#readme",
        "Source Code": "https://github.com/yourusername/png-offline-optimizer",
    },
    packages=["png_optimizer"],
    package_dir={"": "python"},
    ext_modules=[CMakeExtension("png_optimizer.native")],
    cmdclass={"build_ext": CMakeBuild},
    install_requires=[
        "numpy>=1.20.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0",
            "pytest-cov>=4.0",
            "black>=22.0",
            "flake8>=4.0",
        ],
    },
    python_requires=">=3.8",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Environment :: Console",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: MacOS",
        "Operating System :: POSIX :: Linux",
        "Operating System :: Microsoft :: Windows",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: C++",
    ],
    keywords="png compression optimization image processing opencv",
    zip_safe=False,
)
