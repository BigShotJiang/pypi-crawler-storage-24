"""
PNG Offline Optimizer - Intelligent PNG compression with feature analysis

支持：
- 自动图像分类（照片、截图、图标等）
- 动态压缩参数选择
- OpenCV 特征分析
- libimagequant 质量控制
- optipng 二次无损优化
- Python API + CLI
"""

import os
import sys
from pathlib import Path

__version__ = "3.20"
__author__ = "Your Name"
__email__ = "your.email@example.com"
__license__ = "MIT"

# 获取包目录
_PACKAGE_DIR = Path(__file__).parent

def load_native_module():
    """动态加载原生 C++ 模块"""
    try:
        # 尝试导入预编译的扩展
        from . import native as _native
        return _native
    except ImportError:
        try:
            # 备用：从本地编译的版本
            import importlib.util
            spec = importlib.util.find_spec("png_optimizer.native")
            if spec and spec.origin:
                native_module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(native_module)
                return native_module
        except Exception:
            pass
        raise ImportError("无法加载原生 C++ 模块，请确保已正确编译安装 png-optimizer")

try:
    _native = load_native_module()
    optimize = _native.optimize
    batch_optimize = _native.batch_optimize
    get_version = _native.get_version
except ImportError as e:
    # 后备方案：提供纯 Python 的存根
    def optimize(*args, **kwargs):
        raise ImportError(f"原生模块不可用: {e}")
    
    def batch_optimize(*args, **kwargs):
        raise ImportError(f"原生模块不可用: {e}")
    
    def get_version():
        return __version__

# 公开 API
__all__ = [
    "optimize",
    "batch_optimize",
    "get_version",
    "Config",
    "Optimizer",
    "ImageFeatures",
]


class ImageFeatures:
    """图像特征数据类"""
    
    def __init__(self, **kwargs):
        self.keypoint_count = kwargs.get('keypoint_count', 0)
        self.keypoint_density = kwargs.get('keypoint_density', 0.0)
        self.gradient_consistency = kwargs.get('gradient_consistency', 0.0)
        self.glcm_contrast = kwargs.get('glcm_contrast', 0.0)
        self.glcm_energy = kwargs.get('glcm_energy', 0.0)
        self.glcm_homogeneity = kwargs.get('glcm_homogeneity', 0.0)
        self.histogram_peaks = kwargs.get('histogram_peaks', 0)
        self.histogram_spread = kwargs.get('histogram_spread', 0.0)
        self.color_count = kwargs.get('color_count', 0)
        self.flat_ratio = kwargs.get('flat_ratio', 0.0)
        self.has_alpha = kwargs.get('has_alpha', False)
        self.opaque_ratio = kwargs.get('opaque_ratio', 0.0)
        self.semi_trans_ratio = kwargs.get('semi_trans_ratio', 0.0)
        self.alpha_std = kwargs.get('alpha_std', 0.0)
    
    def __repr__(self):
        return (
            f"ImageFeatures(keypoints={self.keypoint_count}, "
            f"colors={self.color_count}, alpha={self.has_alpha})"
        )


class Config:
    """全局配置类"""
    
    def __init__(self, config_file=None):
        """
        初始化配置
        
        Args:
            config_file: 配置文件路径 (YAML 或 JSON)
        """
        self.quality = 0  # 0 = 自动
        self.enable_optipng = True
        self.parallel_workers = 0  # 0 = 使用 CPU 核心数
        self.timeout_seconds = 300
        
        if config_file:
            self.load_from_file(config_file)
    
    def load_from_file(self, config_file):
        """从文件加载配置"""
        try:
            import yaml
            with open(config_file, 'r', encoding='utf-8') as f:
                config_dict = yaml.safe_load(f)
            self.update_from_dict(config_dict)
        except ImportError:
            # 尝试 JSON
            try:
                import json
                with open(config_file, 'r', encoding='utf-8') as f:
                    config_dict = json.load(f)
                self.update_from_dict(config_dict)
            except Exception as e:
                raise ValueError(f"无法加载配置文件: {e}")
    
    def update_from_dict(self, config_dict):
        """从字典更新配置"""
        if 'compression' in config_dict:
            comp = config_dict['compression']
            self.quality = comp.get('default_quality', 0)
            self.enable_optipng = comp.get('enable_optipng', True)
            self.parallel_workers = comp.get('parallel_workers', 0)
            self.timeout_seconds = comp.get('timeout_seconds', 300)


class Optimizer:
    """高级优化器类"""
    
    def __init__(self, config=None):
        """
        初始化优化器
        
        Args:
            config: Config 对象或配置文件路径
        """
        if isinstance(config, str):
            self.config = Config(config)
        elif isinstance(config, Config):
            self.config = config
        else:
            self.config = Config()
    
    def optimize_file(self, input_path, output_path=None, quality=None, use_optipng=None):
        """
        优化单个文件
        
        Args:
            input_path: 输入文件路径
            output_path: 输出文件路径 (默认: 同目录, 名称添加 _optimized)
            quality: 质量参数 (默认: 使用配置值)
            use_optipng: 是否使用 optipng (默认: 使用配置值)
        
        Returns:
            dict: 优化结果
        """
        if output_path is None:
            input_path = Path(input_path)
            output_path = input_path.parent / f"{input_path.stem}_optimized{input_path.suffix}"
        
        quality = quality or self.config.quality
        use_optipng = use_optipng if use_optipng is not None else self.config.enable_optipng
        
        return optimize(str(input_path), str(output_path), quality, use_optipng)
    
    def optimize_directory(self, input_dir, output_dir=None, recursive=True):
        """
        优化目录中的所有 PNG 文件
        
        Args:
            input_dir: 输入目录
            output_dir: 输出目录 (默认: 同位置，名称添加 _optimized)
            recursive: 是否递归处理子目录
        
        Returns:
            list: 优化结果列表
        """
        input_dir = Path(input_dir)
        if output_dir is None:
            output_dir = input_dir.parent / f"{input_dir.name}_optimized"
        else:
            output_dir = Path(output_dir)
        
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # 收集所有 PNG 文件
        pattern = "**/*.png" if recursive else "*.png"
        png_files = list(input_dir.glob(pattern))
        
        # 构造文件对
        file_pairs = []
        for input_file in png_files:
            rel_path = input_file.relative_to(input_dir)
            output_file = output_dir / rel_path
            output_file.parent.mkdir(parents=True, exist_ok=True)
            file_pairs.append((str(input_file), str(output_file)))
        
        # 批量处理
        return batch_optimize(file_pairs, self.config.quality, self.config.enable_optipng)


def main():
    """CLI 入口点"""
    import argparse
    
    parser = argparse.ArgumentParser(
        description="PNG Offline Optimizer - Intelligent compression with feature analysis"
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    
    subparsers = parser.add_subparsers(dest="command", help="commands")
    
    # optimize 子命令
    optimize_parser = subparsers.add_parser("optimize", help="Optimize PNG file(s)")
    optimize_parser.add_argument("input", help="Input file or directory")
    optimize_parser.add_argument("-o", "--output", help="Output file or directory")
    optimize_parser.add_argument("-q", "--quality", type=int, default=0, help="Quality (0=auto, 1-100=fixed)")
    optimize_parser.add_argument("--no-optipng", action="store_true", help="Disable optipng optimization")
    optimize_parser.add_argument("-r", "--recursive", action="store_true", help="Process directories recursively")
    optimize_parser.add_argument("-c", "--config", help="Configuration file (YAML/JSON)")
    
    args = parser.parse_args()
    
    if args.command == "optimize":
        config = Config(args.config) if args.config else Config()
        if args.quality != 0:
            config.quality = args.quality
        if args.no_optipng:
            config.enable_optipng = False
        
        optimizer = Optimizer(config)
        input_path = Path(args.input)
        
        if input_path.is_file():
            result = optimizer.optimize_file(str(input_path), args.output, args.quality, not args.no_optipng)
            print(f"✓ {result.get('status', 'completed')}: {result.get('message', '')}")
            print(f"  Input: {result.get('input_size', 0)} bytes → Output: {result.get('output_size', 0)} bytes")
            print(f"  Compression ratio: {result.get('compression_ratio', 1.0):.2%}")
        elif input_path.is_dir():
            results = optimizer.optimize_directory(str(input_path), args.output, args.recursive)
            success_count = sum(1 for r in results if r.get('success'))
            total_saved = sum(r.get('bytes_saved', 0) for r in results)
            print(f"✓ Processed {len(results)} files, {success_count} compressed")
            print(f"  Total bytes saved: {total_saved} bytes")
        else:
            print(f"✗ Input path not found: {input_path}")
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
