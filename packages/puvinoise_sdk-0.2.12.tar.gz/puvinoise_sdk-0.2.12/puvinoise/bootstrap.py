"""
OpenTelemetry bootstrap for the PUVINoise SDK (telemetry-only by default).

Sends OTLP traces to the platform; does not manage the host (no default disk queues,
no auto control polling). The Agent process handles .env, installs, deploy, restart,
and polls GET /api/agent/config with PUVINOISE_AGENTACCESSKEY.

Set PUVINOISE_SDK_TELEMETRY_ONLY=0 for legacy behavior (default span persist dir + optional automation).
"""

from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider, SpanLimits
from opentelemetry.sdk.trace.export import BatchSpanProcessor, ConsoleSpanExporter
from opentelemetry.sdk.resources import Resource
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
import atexit
import logging
import os

from puvinoise.reliable_export import ReliableSpanExporter
from puvinoise.runtime_metadata import collect_runtime_metadata, get_runtime_metadata
from puvinoise.sdk_mode import sdk_telemetry_only

logger = logging.getLogger(__name__)

_initialized = False
_provider = None
_reliable_exporter = None  # for flush_persisted at exit
_control_worker = None  # AgentControlWorker when control is enabled
_config_poller = None  # GET /api/agent/config poller when pull-based config is enabled

def _normalize_http_api_base(url: str) -> str:
    """Strip trailing slash and optional /api — control paths are /api/agent-control/... under origin."""
    u = (url or "").strip().rstrip("/")
    if u.lower().endswith("/api"):
        u = u[: -len("/api")].rstrip("/")
    return u


def _derive_control_api_base_url() -> str:
    """
    Base URL for GET /api/agent-control (no /v1/traces).
    Prefer explicit platform URLs; only derive from OTLP when it clearly targets the API, not an OTLP collector.

    PUVINOISE_API_URL is the same backend HTTP origin used in server/.env and TestAgent (often set when
    PUVINOISE_PLATFORM_URL is omitted).
    """
    for key in (
        "PUVINOISE_PLATFORM_URL",
        "PUVI_PLATFORM_URL",
        "PUVINOISE_API_URL",
        "PLATFORM_BASE_URL",
        "PUVINOISE_CONTROL_API_URL",
    ):
        v = os.environ.get(key, "").strip()
        if v:
            return _normalize_http_api_base(v)
    ep = os.environ.get("PUVINOISE_END_POINT_URL", "").strip()
    if not ep:
        return ""
    ep = ep.rstrip("/")
    if ep.endswith("/v1/traces"):
        base = ep[: -len("/v1/traces")].rstrip("/")
    else:
        base = ep
    if not base:
        return ""
    try:
        from urllib.parse import urlparse

        raw = base if "://" in base else f"http://{base}"
        u = urlparse(raw)
        if u.port in (4317, 4318, 4319):
            return ""
    except Exception:
        pass
    return _normalize_http_api_base(base)


def _control_auto_start_enabled() -> bool:
    """Agent / supervisor should poll control; SDK default is off (telemetry-only)."""
    v = os.environ.get("PUVINOISE_CONTROL_AUTO_START", "0").strip().lower()
    return v not in ("0", "false", "no")


def _resolve_span_persist_dir():
    """
    None = no span files on disk (default when PUVINOISE_SDK_TELEMETRY_ONLY is on).
    Explicit PUVINOISE_SPAN_PERSIST_DIR always enables persistence for that path.
    """
    explicit = (os.environ.get("PUVINOISE_SPAN_PERSIST_DIR") or "").strip()
    if explicit:
        return explicit
    if sdk_telemetry_only():
        return None
    return os.path.join(os.path.expanduser("~"), ".puvinoise", "span_queue")


def _agent_config_poll_enabled() -> bool:
    v = os.environ.get("PUVINOISE_AGENT_CONFIG_POLL", "0").strip().lower()
    return v in ("1", "true", "yes")


def _resolve_span_limits():
    """
    Raise OTEL attribute limits so custom tags like scenario metadata are not dropped.
    Defaults are intentionally conservative and can truncate/drop attributes under heavy tagging.
    """
    count_limit = int(
        os.getenv("PUVINOISE_SPAN_ATTRIBUTE_COUNT_LIMIT")
        or os.getenv("OTEL_SPAN_ATTRIBUTE_COUNT_LIMIT")
        or "512"
    )
    value_len_limit = int(
        os.getenv("PUVINOISE_SPAN_ATTRIBUTE_VALUE_LENGTH_LIMIT")
        or os.getenv("OTEL_SPAN_ATTRIBUTE_VALUE_LENGTH_LIMIT")
        or "2048"
    )
    return SpanLimits(
        max_span_attributes=max(128, count_limit),
        max_attribute_length=max(256, value_len_limit),
    )


def _create_otlp_exporter(
    endpoint: str,
    headers: dict | None,
    compression: bool,
    timeout: int = 30,
    sdk_version: str = "0.0.0",
):
    # Ensure headers is a dict and always advertise SDK version
    hdrs: dict = dict(headers or {})
    hdrs["X-Sdk-Version"] = str(sdk_version)
    kwargs = {"endpoint": endpoint, "timeout": timeout, "headers": hdrs}
    if compression:
        try:
            from opentelemetry.exporter.otlp.proto.http import Compression
            kwargs["compression"] = Compression.Gzip
        except ImportError:
            pass
    return OTLPSpanExporter(**kwargs)


def init(
    api_key: str = None,
    agent_name: str = None,
    agent_id: str = None,
    endpoint: str = None,
    tenant_id: str = None,
    console_export: bool = False,
    batch_config: dict = None,
    compression: bool = True,
    control_config: dict = None,
):
    """
    One-line init for minimal integration. Sets env from config and calls bootstrap.

    Example::
        puvinoise.init(api_key="PUVINOISE_AGENTACCESSKEY", agent_name="research-agent", agent_id="agt_xxx", endpoint="https://api.example.com/v1/traces")
        agent = puvinoise.wrapAgent(my_agent)

    agent_id: Optional stable agent identity (e.g. agt_xxx from registration). Can also be set via PUVI_AGENT_ID.
    control_config: Optional dict with agentId, controlApiUrl, pollingInterval (seconds).
        When set, starts the agent control worker in the background after telemetry init.
    """
    if api_key:
        os.environ["PUVINOISE_AGENTACCESSKEY"] = str(api_key).strip()
    if agent_name:
        os.environ["PUVI_AGENT_NAME"] = str(agent_name).strip()
    if agent_id:
        os.environ["PUVI_AGENT_ID"] = str(agent_id).strip()
    if endpoint:
        os.environ["PUVINOISE_END_POINT_URL"] = str(endpoint).rstrip("/")
    if tenant_id:
        tid = str(tenant_id).strip()
        os.environ["PUVINOISE_TENANTID"] = tid

    # Optional: auto-load platform config (bootstrap .env) before initializing tracing.
    # Uses agentDeployVersion for PUVI_DEPLOY_VERSION, never touches SDK version.
    config_url = (
        os.environ.get("PUVINOISE_PLATFORM_URL", "").strip()
        or os.environ.get("PUVI_PLATFORM_URL", "").strip()
        or os.environ.get("PUVINOISE_API_URL", "").strip()
    )
    if config_url and not os.environ.get("PUVINOISE_CONFIG_LOADED"):
        try:
            from puvinoise.config_loader import load_platform_config as _load

            _load(
                api_key=api_key or os.environ.get("PUVINOISE_AGENTACCESSKEY", ""),
                agent_id=agent_name or os.environ.get("PUVI_AGENT_NAME", ""),
                platform_url=config_url,
                fail_silently=True,
            )
            os.environ["PUVINOISE_CONFIG_LOADED"] = "1"
        except Exception as _e:
            logger.warning("Auto config load failed (non-fatal): %s", _e)

    return bootstrap(
        service_name=agent_name,
        otlp_endpoint=endpoint,
        console_export=console_export,
        batch_config=batch_config,
        compression=compression,
        control_config=control_config,
    )


def bootstrap(
    service_name: str = None,
    otlp_endpoint: str = None,
    console_export: bool = False,
    batch_config: dict = None,
    compression: bool = True,
    control_config: dict = None,
):
    """
    Initialize OpenTelemetry tracing for the agent, then optionally start the agent control worker.

    Tuned for high-frequency telemetry (e.g. every second per agent):
    batching every 1s, optional gzip compression, retry-capable export.

    Reads env: PUVI_AGENT_NAME, PUVI_AGENT_ID, CUST_LLM_PROVIDER, PUVINOISE_TENANTID,
    PUVINOISE_AGENTACCESSKEY, PUVINOISE_END_POINT_URL; optional deployment metadata:
    PUVI_DEPLOY_ENV, PUVI_DEPLOY_VERSION, PUVI_REGION, PUVI_SDK_LANGUAGE, PUVI_SDK_VERSION
    (SDK auto-detects language/version if unset for backward compatibility).

    control_config: Optional dict with agentId, controlApiUrl, pollingInterval (seconds).
        Starts control worker in background; failures do not crash the SDK.

    If control_config includes controlApiUrl, the control worker starts unless you rely on
    telemetry-only defaults. Env-based auto-start requires PUVINOISE_CONTROL_AUTO_START=1 and
    PUVINOISE_SDK_TELEMETRY_ONLY=0 (legacy in-process automation).
    """
    global _initialized, _provider

    env_agent_name = os.getenv("PUVI_AGENT_NAME", "").strip()
    name = (service_name or env_agent_name or "").strip()
    if not name:
        raise ValueError(
            "Agent name must be set via service_name argument or PUVI_AGENT_NAME environment variable"
        )

    if _initialized:
        logger.info("Tracer already initialized for service: %s", name)
        return trace.get_tracer(name)

    endpoint = (otlp_endpoint or os.getenv("PUVINOISE_END_POINT_URL") or "").strip()
    if not endpoint:
        raise ValueError(
            "OTLP endpoint must be set via otlp_endpoint or PUVINOISE_END_POINT_URL environment variable"
        )
    if not endpoint.endswith("/v1/traces"):
        endpoint = endpoint.rstrip("/") + "/v1/traces"

    access_key = (os.getenv("PUVINOISE_AGENTACCESSKEY") or os.getenv("PUVI_API_KEY") or "").strip()
    headers: dict = {}
    if access_key:
        headers["Authorization"] = f"Bearer {access_key}"

    otlp_headers = {
        "X-Api-Key": access_key,
        "X-Organization-Id": (
            os.environ.get("PUVINOISE_ORGANIZATION_ID")
            or os.environ.get("PUVINOISE_TENANTID", "")
        ),
        "X-Project-Id": os.environ.get("PUVINOISE_PROJECT_ID", ""),
        "X-Environment": (
            os.environ.get("PUVINOISE_ENVIRONMENT")
            or os.environ.get("PUVI_DEPLOY_ENV", "")
        ),
    }
    # Merge any Authorization header into OTLP headers as well
    if access_key:
        otlp_headers.setdefault("Authorization", f"Bearer {access_key}")

    import warnings
    if not otlp_headers["X-Organization-Id"]:
        warnings.warn(
            "PUVINoise: PUVINOISE_TENANTID not set — set this to your tenant ID for multi-tenant routing",
            RuntimeWarning,
        )

    try:
        from puvinoise.routing import get_version as _get_routed_version
        _v = _get_routed_version()
        if _v:
            headers["X-Agent-Version"] = _v
            _existing = os.environ.get("OTEL_EXPORTER_OTLP_HEADERS", "")
            if "x-agent-version" not in _existing.lower():
                os.environ["OTEL_EXPORTER_OTLP_HEADERS"] = (
                    (_existing + "," if _existing else "") + f"x-agent-version={_v}"
                )
    except Exception:
        pass

    llm_provider = (os.getenv("CUST_LLM_PROVIDER") or "").strip()
    # Real tenant ID from env (matches backend tenantId). Reject placeholder.
    tenant_id = (
        os.getenv("PUVINOISE_TENANTID")
        or ""
    ).strip()
    if tenant_id.lower() == "your-tenant-id":
        tenant_id = ""

    try:
        from puvinoise import __version__ as _sdk_version
        sdk_version = str(_sdk_version)
    except Exception:
        sdk_version = "0.0.0"
    puvi_agent_id = (os.getenv("PUVI_AGENT_ID") or "").strip()
    collect_runtime_metadata(agent_id=puvi_agent_id or None, agent_name=name)
    runtime_meta = get_runtime_metadata()
    resource_attrs = {
        "service.name": name,
        "service.version": sdk_version,
        "deployment.environment": runtime_meta.get("deploy_env") or os.getenv("DEPLOYMENT_ENV", "production"),
        "puvinoise.sdk.version": sdk_version,
        "puvinoise.telemetry.schema": "v2",
        "tenant.id": tenant_id,
        "agent.name": name,
        "puvinoise.sdk_language": runtime_meta.get("sdk_language", ""),
        "puvinoise.deploy_version": runtime_meta.get("deploy_version", ""),
        "puvinoise.runtime": runtime_meta.get("runtime", ""),
        "puvinoise.host": runtime_meta.get("host", ""),
        "puvinoise.region": runtime_meta.get("region", ""),
        "puvinoise.instance_id": runtime_meta.get("instance_id", ""),
    }
    if puvi_agent_id:
        resource_attrs["agent.id"] = puvi_agent_id
        resource_attrs["puvinoise.agent_id"] = puvi_agent_id
    if llm_provider:
        resource_attrs["puvinoise.llm_provider"] = llm_provider
        resource_attrs["llm.provider"] = llm_provider
    resource = Resource.create(resource_attrs)

    provider = TracerProvider(resource=resource, span_limits=_resolve_span_limits())
    trace.set_tracer_provider(provider)

    default_batch_config = {
        "schedule_delay_millis": 1000,
        "max_export_batch_size": 128,
        "export_timeout_millis": 30000,
        "max_queue_size": 4096,
    }

    if batch_config:
        default_batch_config.update(batch_config)

    try:
        otlp_exporter = _create_otlp_exporter(
            endpoint=endpoint,
          headers=otlp_headers,
            compression=compression,
            timeout=default_batch_config.get("export_timeout_millis", 30000) // 1000,
            sdk_version=sdk_version,
        )
        persist_dir = _resolve_span_persist_dir()
        reliable_exporter = ReliableSpanExporter(
            otlp_exporter,
            persist_dir=persist_dir,
        )
        global _reliable_exporter
        _reliable_exporter = reliable_exporter
        provider.add_span_processor(
            BatchSpanProcessor(reliable_exporter, **default_batch_config)
        )
        # Replay any spans persisted from previous runs (e.g. API was down)
        replayed = reliable_exporter.flush_persisted()
        if replayed:
            logger.info("Replayed %s persisted spans from previous run", replayed)
        logger.info("OTLP exporter configured (reliable): %s", endpoint)
    except Exception as e:
        logger.error("Failed to configure OTLP exporter: %s", e)
        console_export = True

    if console_export:
        console_exporter = ConsoleSpanExporter()
        provider.add_span_processor(
            BatchSpanProcessor(console_exporter, **default_batch_config)
        )
        logger.info("Console exporter configured for debugging")

    _initialized = True
    _provider = provider

    atexit.register(_atexit_flush)

    # Optional: reliable buffer for decision events (HTTP ingest with persistence)
    try:
        from puvinoise.telemetry_buffer import init_decision_buffer_from_env
        if init_decision_buffer_from_env() is not None:
            logger.info("Decision telemetry buffer enabled (ingest URL); events will be persisted if API is unavailable")
    except Exception as e:
        logger.debug("Decision buffer not configured: %s", e)

    logger.info("OpenTelemetry initialized for service: %s", name)

    control_agent_id = (control_config.get("agentId") if control_config else None) or puvi_agent_id
    if control_config and control_config.get("controlApiUrl") and control_agent_id:
        start_agent_control_worker(
            agent_id=control_agent_id,
            control_api_url=control_config["controlApiUrl"],
            polling_interval=control_config.get("pollingInterval"),
            api_key=control_config.get("apiKey"),
            lifecycle_hooks=control_config.get("lifecycleHooks"),
        )
    elif _control_auto_start_enabled() and not sdk_telemetry_only():
        # Legacy: env-based control poll (Agent should use GET /api/agent/config + control separately).
        auto_base = _derive_control_api_base_url()
        auto_agent = (
            (control_agent_id or "").strip()
            or (os.environ.get("PUVI_AGENT_NAME") or "").strip()
        )
        if auto_base and auto_agent:
            start_agent_control_worker(
                agent_id=auto_agent,
                control_api_url=auto_base,
                polling_interval=control_config.get("pollingInterval") if control_config else None,
                api_key=control_config.get("apiKey") if control_config else None,
                lifecycle_hooks=control_config.get("lifecycleHooks") if control_config else None,
            )

    if _agent_config_poll_enabled() and not sdk_telemetry_only():
        poll_base = _derive_control_api_base_url()
        poll_agent = (control_agent_id or "").strip() or (os.environ.get("PUVI_AGENT_NAME") or "").strip()
        if poll_base and poll_agent:
            start_agent_config_poller(
                agent_id=poll_agent,
                base_url=poll_base,
                api_key=(control_config.get("apiKey") if control_config else None)
                or os.environ.get("PUVINOISE_AGENTACCESSKEY")
                or os.environ.get("PUVI_API_KEY"),
                environment=os.environ.get("PUVI_DEPLOY_ENV", "").strip() or None,
            )

    return trace.get_tracer(name)


def get_control_worker():
    """Return the active agent control worker, or None if control is not enabled or failed to start."""
    return _control_worker


def get_agent_config_poller():
    """Return the GET /api/agent/config poller, or None if not started."""
    return _config_poller


def start_agent_config_poller(
    agent_id: str,
    base_url: str,
    *,
    api_key: str | None = None,
    environment: str | None = None,
    interval_seconds: float | None = None,
    on_change=None,
):
    """
    Poll GET /api/agent/config for desired version (pull-based). Set PUVINOISE_AGENT_CONFIG_POLL=1 to auto-start from bootstrap.
    """
    global _config_poller
    try:
        from puvinoise.agent_config_poller import AgentConfigPoller, default_on_desired_version_change

        base = _normalize_http_api_base(base_url or "")
        if not base or not (agent_id or "").strip():
            return
        interval = float(interval_seconds) if interval_seconds is not None else float(
            os.environ.get("PUVINOISE_AGENT_CONFIG_POLL_INTERVAL", "30") or 30
        )
        interval = max(5.0, interval)
        cb = on_change if on_change is not None else default_on_desired_version_change
        _config_poller = AgentConfigPoller(
            base_url=base,
            agent_id=agent_id.strip(),
            api_key=(api_key or os.environ.get("PUVINOISE_AGENTACCESSKEY") or os.environ.get("PUVI_API_KEY") or "").strip() or None,
            environment=environment,
            interval_seconds=interval,
            on_change=cb,
        )
        _config_poller.start()
        logger.info(
            "Agent config poller started (GET /api/agent/config) agent_id=%s interval=%.1fs",
            agent_id,
            interval,
        )
    except Exception as e:
        logger.warning("Agent config poller failed to start (SDK continues): %s", e)
        _config_poller = None


def start_agent_control_worker(
    agent_id: str,
    control_api_url: str,
    polling_interval: float = None,
    api_key: str = None,
    lifecycle_hooks: dict = None,
):
    """
    Start the agent control worker in a background thread.
    Failures (import, constructor, start) are logged and do not raise.
    """
    global _control_worker
    try:
        from puvinoise.agent_runtime import AgentControlWorker, DEFAULT_POLL_INTERVAL_SEC
        base_url = _normalize_http_api_base(control_api_url or "")
        if not base_url or not (agent_id or "").strip():
            return
        interval = float(polling_interval) if polling_interval is not None else DEFAULT_POLL_INTERVAL_SEC
        interval = max(0.5, interval)
        _control_worker = AgentControlWorker(
            agent_id=agent_id.strip(),
            base_url=base_url,
            poll_interval_seconds=interval,
            api_key=(api_key or os.environ.get("PUVINOISE_AGENTACCESSKEY") or os.environ.get("PUVI_API_KEY") or "").strip() or None,
            lifecycle_hooks=lifecycle_hooks,
        )
        _control_worker.start()
        logger.info(
            "Agent control worker started agent_id=%s control_api_url=%s polling_interval=%.1fs",
            agent_id,
            base_url,
            interval,
        )
    except Exception as e:
        logger.warning("Agent control worker failed to start (SDK continues): %s", e)
        _control_worker = None


def _atexit_flush():
    """Auto-flush on interpreter exit; replay persisted spans and decision buffer so telemetry is never lost."""
    try:
        if _provider is not None:
            _provider.force_flush(timeout_millis=5000)
        if _reliable_exporter is not None:
            _reliable_exporter.flush_persisted()
        try:
            from puvinoise.telemetry_buffer import get_decision_buffer
            buf = get_decision_buffer()
            if buf is not None:
                buf.flush(timeout_sec=5.0)
        except Exception:
            pass
    except Exception:
        pass


def shutdown():
    """
    Gracefully shutdown the tracer provider and stop the agent control worker.
    Call this when your application is terminating to ensure all spans are exported.
    Replays any persisted span batches before shutdown.
    """
    global _provider, _reliable_exporter, _control_worker, _config_poller
    if _config_poller is not None:
        try:
            _config_poller.stop()
            logger.debug("Agent config poller stopped")
        except Exception as e:
            logger.debug("Error stopping config poller: %s", e)
        _config_poller = None
    if _control_worker is not None:
        try:
            _control_worker.stop()
            logger.debug("Agent control worker stopped")
        except Exception as e:
            logger.debug("Error stopping control worker: %s", e)
        _control_worker = None
    provider = trace.get_tracer_provider()
    if isinstance(provider, TracerProvider):
        if _reliable_exporter is not None:
            _reliable_exporter.flush_persisted()
            _reliable_exporter.shutdown()
        provider.shutdown()
        logger.info("OpenTelemetry tracer provider shut down successfully")
    _provider = None
    _reliable_exporter = None


def force_flush(timeout_millis: int = 30000):
    """
    Force flush all pending spans.

    Args:
        timeout_millis: Maximum time to wait for flush in milliseconds
    """
    provider = trace.get_tracer_provider()
    if isinstance(provider, TracerProvider):
        success = provider.force_flush(timeout_millis)
        if success:
            logger.info("Successfully flushed all pending spans")
        else:
            logger.warning("Flush timed out or failed")
        return success
    return False


def is_initialized() -> bool:
    """Check if the tracer has been initialized."""
    return _initialized
