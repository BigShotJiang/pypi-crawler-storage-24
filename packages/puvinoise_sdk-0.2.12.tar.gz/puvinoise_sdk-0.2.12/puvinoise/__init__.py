"""
Puvinoise - Independent OpenTelemetry SDK for AI agents
Supports Anthropic Claude, OpenAI, Ollama, and other LLM providers.
"""

__version__ = "0.2.12"

from puvinoise.bootstrap import (
    bootstrap,
    init,
    shutdown,
    force_flush,
    is_initialized,
    start_agent_control_worker,
    get_control_worker,
    start_agent_config_poller,
    get_agent_config_poller,
)
from puvinoise.runtime_metadata import get_runtime_metadata, collect_runtime_metadata, ensure_runtime_metadata_env
from puvinoise.sdk_mode import sdk_telemetry_only
from puvinoise.tracer import run_with_trace, start_trace, record_context
from puvinoise.trace_context import TraceContext
from puvinoise.observe import observe_agent
from puvinoise.agent_lifecycle import (
    agent_start,
    agent_step,
    tool_call,
    tool_result,
    reasoning_complete,
    task_complete,
)
from puvinoise.agent_wrapper import wrapAgent
from puvinoise.client import PuviClient, ScenarioTraceHandle
from puvinoise.telemetry_buffer import (
    ReliableTelemetryBuffer,
    get_decision_buffer,
    set_decision_buffer,
    init_decision_buffer_from_env,
)
from puvinoise.routing import init_routing, get_version as get_routed_version
from puvinoise.config_loader import load_platform_config, get_loaded_config
from puvinoise.hooks import (
    # Anthropic
    instrument_anthropic_call,
    instrument_anthropic_stream,
    # OpenAI
    instrument_openai_call,
    instrument_openai_stream,
    # Generic / Ollama
    instrument_llm_call,
    # Agent internals
    instrument_memory_operation,
    instrument_tool_call,
    # Span utilities
    add_span_attribute,
    add_span_event,
)
from puvinoise.agent_runtime import (
    AgentControlWorker,
    ControlCommand,
    DEFAULT_POLL_INTERVAL_SEC,
    start as start_agent_runtime,
)
from puvinoise.decision_telemetry import (
    record_intent_classification,
    record_tool_candidates,
    record_reasoning_checkpoint,
    record_decision_confidence,
    record_tool_selection,
    record_tool_selection_reasoning,
    record_agent_state_transition,
    record_llm_reasoning_finished,
    record_plan_step,
    record_tool_decision_checkpoint,
    record_retry_checkpoint,
    record_fallback_checkpoint,
    record_retrieval_ranking,
    record_tool_execution_result,
    record_failure,
    set_trace_outcome,
    set_retry_attempt,
    record_outcome,
    record_task_completed,
    record_guardrail_triggered,
    flush_decision_events,
    get_dropped_event_count,
    get_telemetry_stats,
    recordIntentClassification,
    recordToolCandidates,
    recordReasoningCheckpoint,
    recordToolSelection,
    recordDecisionConfidence,
    recordAgentStateTransition,
    recordTaskCompleted,
)

__all__ = [
    "__version__",
    # Bootstrap & lifecycle
    "bootstrap",
    "init",
    "shutdown",
    "force_flush",
    "is_initialized",
    "start_agent_control_worker",
    "get_control_worker",
    "start_agent_config_poller",
    "get_agent_config_poller",
    "start_agent_runtime",
    "get_runtime_metadata",
    "collect_runtime_metadata",
    "ensure_runtime_metadata_env",
    "sdk_telemetry_only",

    # Core tracing
    "run_with_trace",
    "start_trace",
    "record_context",
    "TraceContext",
    "observe_agent",

    # Auto-instrumentation (lifecycle + wrapAgent)
    "agent_start",
    "agent_step",
    "tool_call",
    "tool_result",
    "reasoning_complete",
    "task_complete",
    "wrapAgent",
    "PuviClient",
    "ScenarioTraceHandle",

    # Reliable telemetry (buffer, retry, persistence)
    "ReliableTelemetryBuffer",
    "get_decision_buffer",
    "set_decision_buffer",
    "init_decision_buffer_from_env",

    # Anthropic hooks
    "instrument_anthropic_call",
    "instrument_anthropic_stream",

    # OpenAI hooks
    "instrument_openai_call",
    "instrument_openai_stream",

    # Generic / Ollama hooks
    "instrument_llm_call",

    # Agent internals
    "instrument_memory_operation",
    "instrument_tool_call",

    # Span utilities
    "add_span_attribute",
    "add_span_event",

    # Decision telemetry (agent decision-stage instrumentation)
    "record_intent_classification",
    "record_tool_candidates",
    "record_reasoning_checkpoint",
    "record_decision_confidence",
    "record_tool_selection",
    "record_tool_selection_reasoning",
    "record_agent_state_transition",
    "record_llm_reasoning_finished",
    "record_plan_step",
    "record_tool_decision_checkpoint",
    "record_retry_checkpoint",
    "record_fallback_checkpoint",
    "record_retrieval_ranking",
    "record_tool_execution_result",
    "record_failure",
    "set_trace_outcome",
    "set_retry_attempt",
    "record_outcome",
    "record_task_completed",
    "record_guardrail_triggered",
    "flush_decision_events",
    "get_dropped_event_count",
    "get_telemetry_stats",
    "recordIntentClassification",
    "recordToolCandidates",
    "recordReasoningCheckpoint",
    "recordToolSelection",
    "recordDecisionConfidence",
    "recordAgentStateTransition",
    "recordTaskCompleted",

    # Remote agent control (polling worker + handlers)
    "AgentControlWorker",
    "ControlCommand",
    "DEFAULT_POLL_INTERVAL_SEC",
    # Routing
    "init_routing",
    "get_routed_version",
    # Config loader
    "load_platform_config",
    "get_loaded_config",
]