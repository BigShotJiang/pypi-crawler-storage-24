"""
High-level PUVINoise client (SDK 0.2.12+).

Provides explicit initialization and scenario-level tracing with ``trace.log()`` for
input/output, latency, and cost — without replacing ``run_with_trace`` / OpenTelemetry hooks.
"""

from __future__ import annotations

import os
import time
from contextlib import contextmanager
from typing import Any, Dict, Iterator, Optional

from opentelemetry import trace
from opentelemetry.trace import Status, StatusCode

from puvinoise.bootstrap import init as _sdk_init, is_initialized
from puvinoise.trace_context import TraceContext
from puvinoise.tracer import start_trace
from puvinoise.schema import LLM_LATENCY_MS

_tracer = trace.get_tracer("agent.runtime")

# Optional decision telemetry (never break callers)
try:
    from puvinoise.decision_telemetry import record_failure
except Exception:  # pragma: no cover

    def record_failure(*args: Any, **kwargs: Any) -> None:
        return None


def _safe_str(value: Any, max_len: int = 8000) -> str:
    try:
        text = repr(value)
    except Exception:
        text = f"<unreprable:{type(value).__name__}>"
    return text[:max_len]


def _set_env_if(
    key: str,
    value: Optional[str],
    *,
    overwrite: bool = False,
) -> None:
    if value is None:
        return
    v = str(value).strip()
    if not v:
        return
    if overwrite or not (os.environ.get(key) or "").strip():
        os.environ[key] = v


class ScenarioTraceHandle:
    """
    Handle returned by ``PuviClient.trace()``: exposes ``context`` (TraceContext) and ``log()``.
    """

    __slots__ = ("_span", "_ctx", "_t0")

    def __init__(self, ctx: TraceContext, span: Any) -> None:
        self._ctx = ctx
        self._span = span
        self._t0 = time.perf_counter()

    @property
    def context(self) -> TraceContext:
        return self._ctx

    def log(
        self,
        input: Any = None,  # noqa: A002 — SDK public API name
        output: Any = None,
        latency_ms: Optional[float] = None,
        cost_usd: Optional[float] = None,
        tokens_prompt: Optional[int] = None,
        tokens_completion: Optional[int] = None,
        total_tokens: Optional[int] = None,
        **extra: Any,
    ) -> None:
        """Attach I/O, latency, cost, token usage, and optional extra attributes to the scenario span."""
        span = self._span
        if not span or not span.is_recording():
            return
        if input is not None:
            span.set_attribute("llm.input", _safe_str(input))
        if output is not None:
            span.set_attribute("llm.output", _safe_str(output))
        if latency_ms is not None:
            try:
                span.set_attribute(LLM_LATENCY_MS, float(latency_ms))
            except Exception:
                span.set_attribute(LLM_LATENCY_MS, str(latency_ms))
        if cost_usd is not None:
            try:
                span.set_attribute("llm.cost_usd", float(cost_usd))
            except Exception:
                span.set_attribute("llm.cost_usd", str(cost_usd))
        if tokens_prompt is not None:
            try:
                span.set_attribute("llm.input_tokens", int(tokens_prompt))
            except Exception:
                span.set_attribute("llm.input_tokens", str(tokens_prompt))
        if tokens_completion is not None:
            try:
                span.set_attribute("llm.output_tokens", int(tokens_completion))
            except Exception:
                span.set_attribute("llm.output_tokens", str(tokens_completion))
        if total_tokens is not None:
            try:
                span.set_attribute("llm.total_tokens", int(total_tokens))
            except Exception:
                span.set_attribute("llm.total_tokens", str(total_tokens))
        for k, v in extra.items():
            if v is None:
                continue
            key = f"scenario.{str(k)[:100]}"
            try:
                span.set_attribute(key, _safe_str(v))
            except Exception:
                pass

    def error(
        self,
        message: str = "",
        error_type: Optional[str] = None,
        **extra: Any,
    ) -> None:
        """Record error metadata on the scenario span (in addition to OTEL exception recording)."""
        span = self._span
        if not span or not span.is_recording():
            return
        if message:
            span.set_attribute("error.message", _safe_str(message)[:2000])
        if error_type:
            span.set_attribute("error.type", str(error_type)[:256])
        for k, v in extra.items():
            if v is None:
                continue
            try:
                span.set_attribute(f"error.{str(k)[:100]}", _safe_str(v)[:2000])
            except Exception:
                pass

    def elapsed_ms(self) -> float:
        return (time.perf_counter() - self._t0) * 1000.0


class PuviClient:
    """
    Explicit SDK client: maps constructor args to environment, then initializes telemetry.

    Typical usage::

        client = PuviClient(
            endpoint=os.getenv("PUVINOISE_END_POINT_URL"),
            tenant_id=os.getenv("PUVINOISE_TENANTID"),
            access_key=os.getenv("PUVINOISE_AGENTACCESSKEY"),
            agent_id=os.getenv("PUVI_AGENT_ID"),
            env=os.getenv("PUVI_DEPLOY_ENV"),
            version=os.getenv("PUVI_DEPLOY_VERSION"),
            sdk_version=os.getenv("PUVI_SDK_VERSION"),
            region=os.getenv("PUVI_REGION"),
        )

        with client.trace(name=\"my_scenario\", metadata={\"scenario_type\": \"e2e\"}) as tr:
            puvinoise.run_with_trace(lambda: run(), ctx=tr.context, session_id=tr.context.session_id)
            tr.log(input=\"...\", output=\"...\", latency_ms=120.0, cost_usd=0.001)
    """

    def __init__(
        self,
        endpoint: Optional[str] = None,
        tenant_id: Optional[str] = None,
        access_key: Optional[str] = None,
        agent_id: Optional[str] = None,
        env: Optional[str] = None,
        version: Optional[str] = None,
        sdk_version: Optional[str] = None,
        region: Optional[str] = None,
        *,
        auto_init: bool = True,
    ) -> None:
        self._apply_config(
            endpoint=endpoint,
            tenant_id=tenant_id,
            access_key=access_key,
            agent_id=agent_id,
            env=env,
            version=version,
            sdk_version=sdk_version,
            region=region,
        )
        if auto_init:
            self.connect()

    def _apply_config(
        self,
        *,
        endpoint: Optional[str],
        tenant_id: Optional[str],
        access_key: Optional[str],
        agent_id: Optional[str],
        env: Optional[str],
        version: Optional[str],
        sdk_version: Optional[str],
        region: Optional[str],
    ) -> None:
        _set_env_if("PUVINOISE_END_POINT_URL", endpoint or os.getenv("PUVINOISE_END_POINT_URL"))
        _set_env_if("PUVINOISE_TENANTID", tenant_id)
        _set_env_if("PUVINOISE_AGENTACCESSKEY", access_key)
        _set_env_if("PUVI_AGENT_ID", agent_id)
        _set_env_if("PUVI_DEPLOY_ENV", env)
        _set_env_if("PUVI_DEPLOY_VERSION", version)
        _set_env_if("PUVI_SDK_VERSION", sdk_version)
        _set_env_if("PUVI_REGION", region)

    def connect(self) -> None:
        """Initialize OpenTelemetry + optional buffers (idempotent)."""
        if is_initialized():
            return
        ep = (os.getenv("PUVINOISE_END_POINT_URL") or "").strip()
        key = (os.getenv("PUVINOISE_AGENTACCESSKEY") or os.getenv("PUVI_API_KEY") or "").strip()
        agent_name = (os.getenv("PUVI_AGENT_NAME") or "").strip()
        if not agent_name:
            raise ValueError(
                "PUVINoise: set PUVI_AGENT_NAME before PuviClient.connect() "
                "(required for tracer service name)"
            )
        _sdk_init(
            api_key=key or None,
            agent_name=agent_name,
            agent_id=(os.getenv("PUVI_AGENT_ID") or "").strip() or None,
            endpoint=ep or None,
            tenant_id=(os.getenv("PUVINOISE_TENANTID") or "").strip() or None,
        )

    @classmethod
    def from_env(cls, *, auto_init: bool = True) -> "PuviClient":
        """Build client using current environment only."""
        return cls(
            endpoint=os.getenv("PUVINOISE_END_POINT_URL"),
            tenant_id=os.getenv("PUVINOISE_TENANTID"),
            access_key=os.getenv("PUVINOISE_AGENTACCESSKEY"),
            agent_id=os.getenv("PUVI_AGENT_ID"),
            env=os.getenv("PUVI_DEPLOY_ENV"),
            version=os.getenv("PUVI_DEPLOY_VERSION"),
            sdk_version=os.getenv("PUVI_SDK_VERSION"),
            region=os.getenv("PUVI_REGION"),
            auto_init=auto_init,
        )

    @contextmanager
    def trace(
        self,
        name: str,
        metadata: Optional[Dict[str, Any]] = None,
        *,
        session_id: Optional[str] = None,
    ) -> Iterator[ScenarioTraceHandle]:
        """
        Open a scenario span and TraceContext. Nest ``run_with_trace(..., ctx=handle.context)`` inside.

        On exit, records exceptions on the span and emits ``record_failure`` for error capture.
        """
        meta = dict(metadata or {})
        sid = (
            session_id
            or meta.get("session_id")
            or meta.get("test_id")
            or os.getenv("PUVINOISE_SESSION_ID")
            or "default-session"
        )
        ctx = start_trace(session_id=str(sid))
        if not hasattr(ctx, "metadata") or ctx.metadata is None:
            ctx.metadata = {}
        elif not isinstance(ctx.metadata, dict):
            try:
                ctx.metadata = dict(ctx.metadata)
            except Exception:
                ctx.metadata = {}
        for k, v in meta.items():
            if v is not None:
                ctx.metadata[str(k)] = v
        if name and not ctx.metadata.get("scenario"):
            ctx.metadata["scenario"] = str(name)
        env_agent = (os.getenv("PUVI_AGENT_NAME") or "").strip()
        if env_agent and not ctx.metadata.get("agent_name"):
            ctx.metadata["agent_name"] = env_agent

        span_name = (name or "scenario").strip() or "scenario"

        with _tracer.start_as_current_span(span_name) as span:
            span.set_attribute("trace.id", str(getattr(ctx, "trace_id", ""))[:200])
            span.set_attribute("session.id", str(sid)[:200])
            span.set_attribute("scenario.name", str(name)[:200])
            if ctx.metadata:
                for mk, mv in ctx.metadata.items():
                    if mv is None:
                        continue
                    span.set_attribute(f"metadata.{mk}", _safe_str(mv)[:2000])
            handle = ScenarioTraceHandle(ctx, span)
            try:
                yield handle
                if span.is_recording():
                    span.set_status(Status(StatusCode.OK))
                    span.set_attribute("otel.status_code", "OK")
            except Exception as e:
                if span.is_recording():
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    span.set_attribute("otel.status_code", "ERROR")
                    span.record_exception(e)
                try:
                    record_failure(
                        category="unknown",
                        message=str(e)[:500],
                        error_type=type(e).__name__,
                    )
                except Exception:
                    pass
                raise


__all__ = ["PuviClient", "ScenarioTraceHandle"]
