"""
Poll GET /api/agent/config for desired state (version, config, instructions).

Production: run this in the Agent / supervisor process with PUVINOISE_AGENTACCESSKEY.
The default SDK does not start this poller (use Agent automation); enable only with
PUVINOISE_AGENT_CONFIG_POLL=1 and PUVINOISE_SDK_TELEMETRY_ONLY=0 for legacy in-process use.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Callable, Dict, Optional

logger = logging.getLogger(__name__)

DEFAULT_INTERVAL_SEC = 30.0


def _normalize_base(url: str) -> str:
    u = (url or "").strip().rstrip("/")
    if u.lower().endswith("/api"):
        u = u[: -len("/api")].rstrip("/")
    return u


class AgentConfigPoller:
    """
    Background poll of GET /api/agent/config with API key auth.
    Invokes on_change(desired_version, full_payload) when desired.agentVersion changes.
    """

    def __init__(
        self,
        base_url: str,
        agent_id: str,
        *,
        api_key: Optional[str] = None,
        environment: Optional[str] = None,
        interval_seconds: float = DEFAULT_INTERVAL_SEC,
        on_change: Optional[Callable[[Optional[str], Dict[str, Any]], None]] = None,
    ):
        self._base = _normalize_base(base_url)
        self._agent_id = (agent_id or "").strip()
        self._api_key = (api_key or os.environ.get("PUVINOISE_AGENTACCESSKEY") or os.environ.get("PUVI_API_KEY") or "").strip()
        self._environment = (environment or os.environ.get("PUVI_DEPLOY_ENV") or "").strip() or None
        self._interval = max(5.0, float(interval_seconds))
        self._on_change = on_change
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self._last_version: Optional[str] = None

    def _build_url(self) -> str:
        q = {"agentId": self._agent_id}
        if self._environment:
            q["environment"] = self._environment
        qs = urllib.parse.urlencode(q)
        return f"{self._base}/api/agent/config?{qs}"

    def _poll_once(self) -> None:
        if not self._base or not self._agent_id or not self._api_key:
            return
        url = self._build_url()
        req = urllib.request.Request(
            url,
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Accept": "application/json",
            },
            method="GET",
        )
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                raw = resp.read().decode("utf-8", errors="replace")
                data = json.loads(raw)
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace") if e.fp else ""
            logger.warning("agent config poll HTTP %s: %s", e.code, body[:200])
            return
        except Exception as e:
            logger.warning("agent config poll failed: %s", e)
            return

        desired = data.get("desired") or {}
        ver = desired.get("agentVersion")
        if isinstance(ver, str):
            ver = ver.strip() or None
        else:
            ver = None

        if ver != self._last_version:
            prev = self._last_version
            self._last_version = ver
            if self._on_change is not None and (ver is not None or prev is not None):
                try:
                    self._on_change(ver, data)
                except Exception as cb:
                    logger.warning("on_change callback failed: %s", cb)

    def _loop(self) -> None:
        while not self._stop.is_set():
            self._poll_once()
            self._stop.wait(self._interval)

    def start(self) -> None:
        if self._thread is not None:
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True, name="puvinoise-agent-config-poller")
        self._thread.start()
        logger.info("Agent config poller started url=%s interval=%.1fs", self._build_url(), self._interval)

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=self._interval + 2.0)
            self._thread = None


def default_on_desired_version_change(desired_version: Optional[str], payload: Dict[str, Any]) -> None:
    """Log instructions; host app should override for download + restart."""
    ins = payload.get("instructions") or {}
    logger.info(
        "Desired agent version is now %s — %s",
        desired_version,
        ins.get("onVersionChange") or ins.get("summary") or "apply locally",
    )


def runtime_deploy_on_config_change(
    desired_version: Optional[str],
    full_payload: Dict[str, Any],
    *,
    base_url: str,
    agent_id: str,
    api_key: Optional[str] = None,
) -> None:
    """
    Optional AgentConfigPoller on_change: run ControlRuntimeExecutor.deploy when desired version changes.
    Requires PUVINOISE_CONTROL_RUNTIME_EXEC=1 and workdir/scripts (see runtime_executor).
    """
    _ = full_payload
    from puvinoise.agent_runtime.runtime_executor import get_runtime_executor
    from puvinoise.agent_runtime.runtime_flags import runtime_exec_enabled

    v = (desired_version or "").strip()
    if not v or not runtime_exec_enabled():
        return
    key = (api_key or os.environ.get("PUVINOISE_AGENTACCESSKEY") or os.environ.get("PUVI_API_KEY") or "").strip()
    if not key:
        logger.warning("runtime_deploy_on_config_change: missing API key")
        return
    ex = get_runtime_executor(base_url, agent_id, key)
    ex.deploy(v, None)


def make_runtime_config_deploy_callback(
    base_url: str,
    agent_id: str,
    *,
    api_key: Optional[str] = None,
):
    """Build on_change(desired_version, payload) that applies deploy via runtime_executor."""

    def _cb(desired_version: Optional[str], payload: Dict[str, Any]) -> None:
        runtime_deploy_on_config_change(
            desired_version,
            payload,
            base_url=base_url,
            agent_id=agent_id,
            api_key=api_key,
        )

    return _cb

