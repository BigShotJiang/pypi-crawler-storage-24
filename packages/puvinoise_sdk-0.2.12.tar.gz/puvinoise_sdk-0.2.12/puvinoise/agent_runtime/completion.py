"""
POST completion for remote control commands (PATCH /api/agent-control/:agentId/complete).
"""

from __future__ import annotations

import json
import logging
import os
import urllib.error
import urllib.request
from typing import Optional

logger = logging.getLogger(__name__)


def post_control_command_completion(
    base_url: str,
    agent_id: str,
    api_key: str,
    command_id: str,
    status: str,
    error: Optional[str] = None,
) -> bool:
    """
    Notify the platform that a control command finished.
    status: "completed" | "failed"
    """
    base = (base_url or "").strip().rstrip("/")
    cid = (command_id or "").strip()
    aid = (agent_id or "").strip()
    key = (api_key or "").strip()
    if not base or not cid or not aid or not key:
        return False
    if status not in ("completed", "failed"):
        return False

    url = f"{base}/api/agent-control/{aid}/complete"
    body = json.dumps(
        {"commandId": cid, "status": status, **({"error": error[:4000]} if error else {})},
        separators=(",", ":"),
    ).encode("utf-8")

    req = urllib.request.Request(url, data=body, method="PATCH")
    req.add_header("Content-Type", "application/json")
    req.add_header("Accept", "application/json")
    req.add_header("Authorization", f"Bearer {key}")
    req.add_header("x-api-key", key)

    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            code = resp.getcode()
            resp.read()
        return 200 <= int(code) < 300
    except urllib.error.HTTPError as e:
        logger.warning("control completion HTTP %s: %s", e.code, e.reason)
        return False
    except Exception as e:
        logger.warning("control completion failed: %s", e)
        return False


def post_control_execution_event(
    base_url: str,
    agent_id: str,
    api_key: str,
    command_id: str,
    event: str,
    message: Optional[str] = None,
    *,
    progress_pct: Optional[float] = None,
    deployment_id: Optional[str] = None,
    error: Optional[str] = None,
) -> bool:
    """
    POST /api/agent-control/:agentId/events — deploy/restart progress for DeploymentEvent timeline.
    event: deploy_started | deploy_progress | deploy_completed | deploy_failed | restart_* 
    """
    base = (base_url or "").strip().rstrip("/")
    cid = (command_id or "").strip()
    aid = (agent_id or "").strip()
    key = (api_key or "").strip()
    ev = (event or "").strip()
    if not base or not cid or not aid or not key or not ev:
        return False

    body_obj: dict = {"commandId": cid, "event": ev}
    if message:
        body_obj["message"] = str(message)[:4000]
    if progress_pct is not None:
        body_obj["progressPct"] = float(progress_pct)
    if deployment_id:
        body_obj["deploymentId"] = str(deployment_id).strip()
    if error:
        body_obj["error"] = str(error)[:4000]

    body = json.dumps(body_obj, separators=(",", ":")).encode("utf-8")
    url = f"{base}/api/agent-control/{aid}/events"
    req = urllib.request.Request(url, data=body, method="POST")
    req.add_header("Content-Type", "application/json")
    req.add_header("Accept", "application/json")
    req.add_header("Authorization", f"Bearer {key}")
    req.add_header("x-api-key", key)

    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            code = resp.getcode()
            resp.read()
        return 200 <= int(code) < 300
    except urllib.error.HTTPError as e:
        logger.warning("control execution event HTTP %s: %s", e.code, e.reason)
        return False
    except Exception as e:
        logger.warning("control execution event failed: %s", e)
        return False


def post_control_execution_event_from_env(
    event: str,
    message: Optional[str] = None,
    *,
    progress_pct: Optional[float] = None,
    deployment_id: Optional[str] = None,
    error: Optional[str] = None,
) -> bool:
    """Uses platform URL, PUVI_AGENT_ID / agent name, PUVINOISE_CONTROL_COMMAND_ID, API key env."""
    base = (
        os.environ.get("PUVINOISE_PLATFORM_URL")
        or os.environ.get("PUVI_PLATFORM_URL")
        or os.environ.get("PUVINOISE_API_URL")
        or os.environ.get("PLATFORM_BASE_URL")
        or os.environ.get("PUVINOISE_CONTROL_API_URL")
        or ""
    ).strip()
    aid = (os.environ.get("PUVI_AGENT_ID") or os.environ.get("PUVI_AGENT_NAME") or "").strip()
    cid = (os.environ.get("PUVINOISE_CONTROL_COMMAND_ID") or "").strip()
    key = (
        os.environ.get("PUVINOISE_AGENTACCESSKEY", "").strip()
        or os.environ.get("PUVI_API_KEY", "").strip()
    )
    dep = (deployment_id or "").strip() or (os.environ.get("PUVI_DEPLOYMENT_ID") or "").strip() or None
    return post_control_execution_event(
        base,
        aid,
        key,
        cid,
        event,
        message,
        progress_pct=progress_pct,
        deployment_id=dep,
        error=error,
    )


def post_control_command_completion_from_env(status: str, error: Optional[str] = None) -> bool:
    """Uses PUVI_PLATFORM_URL / PLATFORM_BASE_URL, PUVI_AGENT_ID, PUVINOISE_CONTROL_COMMAND_ID, API key env."""
    base = (
        os.environ.get("PUVINOISE_PLATFORM_URL")
        or os.environ.get("PUVI_PLATFORM_URL")
        or os.environ.get("PUVINOISE_API_URL")
        or os.environ.get("PLATFORM_BASE_URL")
        or os.environ.get("PUVINOISE_CONTROL_API_URL")
        or ""
    ).strip()
    aid = (os.environ.get("PUVI_AGENT_ID") or os.environ.get("PUVI_AGENT_NAME") or "").strip()
    cid = (os.environ.get("PUVINOISE_CONTROL_COMMAND_ID") or "").strip()
    key = (
        os.environ.get("PUVINOISE_AGENTACCESSKEY", "").strip()
        or os.environ.get("PUVI_API_KEY", "").strip()
    )
    return post_control_command_completion(base, aid, key, cid, status, error)
