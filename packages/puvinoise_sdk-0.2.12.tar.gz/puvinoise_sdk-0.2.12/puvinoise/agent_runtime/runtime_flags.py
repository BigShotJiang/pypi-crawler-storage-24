"""Feature flags for host execution (opt-in; telemetry works without these)."""

from __future__ import annotations

import os


def _truthy(name: str, default: str = "0") -> bool:
    return os.environ.get(name, default).strip().lower() in ("1", "true", "yes", "on")


def runtime_exec_enabled() -> bool:
    """When True, deploy/rollback/pip/env/process scripts may run."""
    return _truthy("PUVINOISE_CONTROL_RUNTIME_EXEC", "0")


def require_runtime_exec() -> None:
    if not runtime_exec_enabled():
        raise RuntimeError(
            "PUVINOISE_CONTROL_RUNTIME_EXEC=1 is required for built-in deploy/rollback/pip/env actions"
        )


def restart_after_sdk_upgrade() -> bool:
    return _truthy("PUVINOISE_RESTART_AFTER_SDK_UPGRADE", "0")
