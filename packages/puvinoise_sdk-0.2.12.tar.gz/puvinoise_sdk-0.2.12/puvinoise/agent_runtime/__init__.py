"""
Agent runtime (execution plane): control polling, deploy/rollback, env, process hooks.

Telemetry and tracing live in the rest of `puvinoise`; importing this package is optional.
Use `puvinoise.agent_runtime.start()` to start the control poller without touching bootstrap.init().
"""

from __future__ import annotations

import logging
import os
from typing import Any, Optional

from puvinoise.agent_runtime.agent_control_worker import (
    AgentControlWorker,
    ControlCommand,
    ControlHandler,
    DEFAULT_POLL_INTERVAL_SEC,
    OnAgentRestartHook,
    OnAgentStopHook,
    OnDeployRequestedHook,
    OnRollbackRequestedHook,
)
from puvinoise.agent_runtime.completion import (
    post_control_command_completion,
    post_control_command_completion_from_env,
)
from puvinoise.agent_runtime.env_manager import fetch_agent_config
from puvinoise.agent_runtime.bootstrap_apply import BootstrapApplyResult, apply_bootstrap_from_config
from puvinoise.agent_runtime.runtime_executor import ControlRuntimeExecutor, get_runtime_executor
from puvinoise.agent_runtime.runtime_flags import runtime_exec_enabled

from . import deploy_handler
from . import env_manager
from . import process_manager
from . import rollback_handler

logger = logging.getLogger(__name__)

__all__ = [
    "start",
    "AgentControlWorker",
    "ControlCommand",
    "ControlHandler",
    "DEFAULT_POLL_INTERVAL_SEC",
    "OnAgentStopHook",
    "OnAgentRestartHook",
    "OnDeployRequestedHook",
    "OnRollbackRequestedHook",
    "post_control_command_completion",
    "post_control_command_completion_from_env",
    "ControlRuntimeExecutor",
    "get_runtime_executor",
    "runtime_exec_enabled",
    "BootstrapApplyResult",
    "apply_bootstrap_from_config",
    "fetch_agent_config",
    "deploy_handler",
    "rollback_handler",
    "env_manager",
    "process_manager",
]


def _normalize_http_api_base(url: str) -> str:
    u = (url or "").strip().rstrip("/")
    if u.lower().endswith("/api"):
        u = u[: -len("/api")].rstrip("/")
    return u


def start(
    agent_id: Optional[str] = None,
    control_api_url: Optional[str] = None,
    *,
    polling_interval: Optional[float] = None,
    api_key: Optional[str] = None,
    lifecycle_hooks: Optional[dict[str, Any]] = None,
) -> Optional[AgentControlWorker]:
    """
    Start execution plane: background poll of GET /api/agent-control/:agentId.

    When arguments are omitted, reads env: PUVI_AGENT_ID, PUVINOISE_API_URL (or PUVINOISE_PLATFORM_URL),
    PUVINOISE_AGENTACCESSKEY, PUVINOISE_CONTROL_POLL_INTERVAL (optional).

    Does not enable OTLP telemetry; call `puvinoise.init` / `bootstrap` separately for observe mode.
    Returns the worker instance or None if misconfigured.
    """
    aid = (agent_id or os.environ.get("PUVI_AGENT_ID") or os.environ.get("PUVINOISE_AGENT_ID") or "").strip()
    base = _normalize_http_api_base(
        control_api_url
        or os.environ.get("PUVINOISE_API_URL")
        or os.environ.get("PUVINOISE_PLATFORM_URL")
        or os.environ.get("PUVI_PLATFORM_URL")
        or ""
    )
    key = (
        (api_key or "").strip()
        or os.environ.get("PUVINOISE_AGENTACCESSKEY", "").strip()
        or os.environ.get("PUVI_API_KEY", "").strip()
        or None
    )
    if not aid or not base:
        logger.warning("agent_runtime.start: missing PUVI_AGENT_ID or PUVINOISE_API_URL")
        return None
    interval = float(polling_interval) if polling_interval is not None else DEFAULT_POLL_INTERVAL_SEC
    raw = os.environ.get("PUVINOISE_CONTROL_POLL_INTERVAL") or os.environ.get("PUVINOISE_AGENT_CONTROL_POLL_INTERVAL")
    if polling_interval is None and raw:
        try:
            interval = float(raw)
        except ValueError:
            pass
    interval = max(0.5, interval)
    worker = AgentControlWorker(
        agent_id=aid,
        base_url=base,
        poll_interval_seconds=interval,
        api_key=key,
        lifecycle_hooks=lifecycle_hooks,
    )
    worker.start()
    logger.info("agent_runtime.start: control worker running agent_id=%s url=%s", aid, base)
    return worker
