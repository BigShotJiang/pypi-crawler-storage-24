# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable, Optional
from datetime import date
from typing_extensions import Literal, Required, Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = ["ComplianceCreateParams", "Entity"]


class ComplianceCreateParams(TypedDict, total=False):
    company_id: Optional[str]

    directors_screening_enabled: bool
    """If directors should be screened."""

    entities: Iterable[Entity]

    ownership_screening_threshold: Optional[float]
    """The threshold for ultimate ownership to enable for screening."""

    ubo_screening_enabled: bool
    """If enabled, UBOs discovered for the company will be screened."""


class Entity(TypedDict, total=False):
    """### Compliance Entity Request

    Represents an entity (individual or organization) to be included in a compliance
    screening.
    """

    name: Required[str]

    aliases: SequenceNotStr[str]
    """Alternative names or aliases for the compliance entity."""

    country: Optional[str]

    date_of_birth: Annotated[Union[str, date, None], PropertyInfo(format="iso8601")]

    entity_type: Literal["individual", "company"]
    """
    - `individual` - Individual
    - `company` - Company
    """

    first_name: Optional[str]

    last_name: Optional[str]

    middle_name: Optional[str]
