"""Anonymous telemetry — opt-out."""
