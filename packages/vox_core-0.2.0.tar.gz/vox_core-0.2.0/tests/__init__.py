"""Vox test suite."""
