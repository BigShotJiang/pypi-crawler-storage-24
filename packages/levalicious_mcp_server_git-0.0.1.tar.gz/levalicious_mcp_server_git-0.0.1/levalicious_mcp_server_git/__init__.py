from .server import serve
from tap import Tap
from pathlib import Path

class GitRequestParser(Tap):
    repository: Path | None = None

def main():
    """MCP Git Server - Git functionality for MCP"""
    import asyncio
    
    args = GitRequestParser(underscores_to_dashes=True).parse_args()
    asyncio.run(serve(args.repository))


if __name__ == "__main__":
    main()
