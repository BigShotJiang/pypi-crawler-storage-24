import pytest
from pathlib import Path
import git
from levalicious_mcp_server_git.server import (
    git_checkout,
    git_branch,
    git_status,
    git_add,
    git_commit,
    git_show,
    git_init,
    git_log,
    configure_unicode,
)
import shutil

@pytest.fixture
def test_repository(tmp_path: Path):
    repo_path = tmp_path / "temp_test_repo"
    test_repo = git.Repo.init(repo_path)
    configure_unicode(test_repo)

    Path(repo_path / "test.txt").write_text("test")
    test_repo.index.add(["test.txt"])
    test_repo.index.commit("initial commit")

    yield test_repo

    shutil.rmtree(repo_path)

def test_git_checkout_existing_branch(test_repository):
    test_repository.git.branch("test-branch")
    result = git_checkout(test_repository, "test-branch")

    assert "Switched to branch 'test-branch'" in result
    assert test_repository.active_branch.name == "test-branch"

def test_git_checkout_nonexistent_branch(test_repository):

    with pytest.raises(git.GitCommandError):
        git_checkout(test_repository, "nonexistent-branch")

def test_git_branch_local(test_repository):
    test_repository.git.branch("new-branch-local")
    result = git_branch(test_repository, "local")
    assert "new-branch-local" in result

def test_git_branch_remote(test_repository):
    # GitPython does not easily support creating remote branches without a remote.
    # This test will check the behavior when 'remote' is specified without actual remotes.
    result = git_branch(test_repository, "remote")
    assert "" == result.strip()  # Should be empty if no remote branches

def test_git_branch_all(test_repository):
    test_repository.git.branch("new-branch-all")
    result = git_branch(test_repository, "all")
    assert "new-branch-all" in result

def test_git_branch_contains(test_repository):
    # Create a new branch and commit to it
    test_repository.git.checkout("-b", "feature-branch")
    Path(test_repository.working_dir / Path("feature.txt")).write_text("feature content")
    test_repository.index.add(["feature.txt"])
    commit = test_repository.index.commit("feature commit")
    test_repository.git.checkout("master")

    result = git_branch(test_repository, "local", contains=commit.hexsha)
    assert "feature-branch" in result
    assert "master" not in result

def test_git_branch_not_contains(test_repository):
    # Create a new branch and commit to it
    test_repository.git.checkout("-b", "another-feature-branch")
    Path(test_repository.working_dir / Path("another_feature.txt")).write_text("another feature content")
    test_repository.index.add(["another_feature.txt"])
    commit = test_repository.index.commit("another feature commit")
    test_repository.git.checkout("master")

    result = git_branch(test_repository, "local", not_contains=commit.hexsha)
    assert "another-feature-branch" not in result
    assert "master" in result


# --- Non-ASCII path tests ---

def test_git_status_unicode_filename(test_repository):
    """git status should show non-ASCII filenames without octal escaping."""
    unicode_file = Path(test_repository.working_dir) / "文件.txt"
    unicode_file.write_text("hello", encoding="utf-8")
    result = git_status(test_repository)
    assert "文件.txt" in result


def test_git_add_unicode_filename(test_repository):
    """git add should handle non-ASCII filenames."""
    unicode_file = Path(test_repository.working_dir) / "données.txt"
    unicode_file.write_text("bonjour", encoding="utf-8")
    result = git_add(test_repository, ["données.txt"])
    assert "staged" in result.lower()


def test_git_commit_unicode_message(test_repository):
    """git commit should handle non-ASCII commit messages."""
    Path(test_repository.working_dir, "new.txt").write_text("x")
    test_repository.index.add(["new.txt"])
    result = git_commit(test_repository, "提交消息: added new file")
    assert "committed" in result.lower()


def test_git_log_unicode(test_repository):
    """git log should show non-ASCII author names and messages."""
    Path(test_repository.working_dir, "ファイル.txt").write_text("data")
    test_repository.index.add(["ファイル.txt"])
    test_repository.index.commit("追加: new file")
    log = git_log(test_repository, max_count=1)
    assert len(log) > 0
    assert "追加" in log[0]


def test_git_show_unicode_diff(test_repository):
    """git show should handle diffs with non-ASCII content and filenames."""
    unicode_file = Path(test_repository.working_dir) / "日本語.txt"
    unicode_file.write_text("こんにちは", encoding="utf-8")
    test_repository.index.add(["日本語.txt"])
    commit = test_repository.index.commit("add japanese file")
    result = git_show(test_repository, commit.hexsha)
    assert "日本語.txt" in result
    assert "こんにちは" in result


def test_git_init_unicode_path(tmp_path):
    """git init should work with non-ASCII directory paths."""
    unicode_dir = str(tmp_path / "проект")
    result = git_init(unicode_dir)
    assert "Initialized" in result
    shutil.rmtree(unicode_dir)
