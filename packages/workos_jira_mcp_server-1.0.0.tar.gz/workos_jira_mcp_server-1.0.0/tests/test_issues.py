"""Tests for Jira MCP issue tools."""

import pytest
from unittest.mock import AsyncMock, patch
from fastmcp import FastMCP
from jira_mcp_server.tools.issues import register_issue_tools


@pytest.fixture
def app_with_tools(mock_config):
    app = FastMCP(name="test", version="0.1.0")
    register_issue_tools(app, mock_config)
    return app


class TestIssueTools:
    def test_tools_registered(self, app_with_tools):
        """Verify all issue tools are registered."""
        import asyncio
        tools = asyncio.run(app_with_tools.list_tools())
        tool_names = [t.name for t in tools]
        assert "jira_get_issue" in tool_names
        assert "jira_create_issue" in tool_names
        assert "jira_update_issue" in tool_names
        assert "jira_search_issues" in tool_names
        assert "jira_transition_issue" in tool_names
        assert "jira_add_comment" in tool_names
