"""Tests for Jira MCP server client."""

import pytest
from unittest.mock import AsyncMock, patch
from jira_mcp_server.client import (
    JiraClient, JiraAPIError, JiraAuthError, JiraNotFoundError, JiraRateLimitError
)
from jira_mcp_server.config import JiraConfig


@pytest.fixture
def client():
    return JiraClient(
        base_url="https://test.atlassian.net",
        email="test@co.com",
        api_token="test-token",
    )


class TestClientInit:
    def test_requires_credentials(self):
        with pytest.raises(JiraAuthError):
            JiraClient(base_url="", email="a@b.com", api_token="tok")

    def test_requires_email(self):
        with pytest.raises(JiraAuthError):
            JiraClient(base_url="https://x.atlassian.net", email="", api_token="tok")

    def test_requires_api_token(self):
        with pytest.raises(JiraAuthError):
            JiraClient(base_url="https://x.atlassian.net", email="a@b.com", api_token="")

    def test_creates_with_valid_credentials(self):
        c = JiraClient(base_url="https://x.atlassian.net", email="a@b.com", api_token="tok")
        assert c.base_url == "https://x.atlassian.net"

    def test_strips_trailing_slash(self):
        c = JiraClient(base_url="https://x.atlassian.net/", email="a@b.com", api_token="tok")
        assert c.base_url == "https://x.atlassian.net"


class TestGetIssue:
    @pytest.mark.asyncio
    async def test_get_issue_success(self, client, mock_jira_response):
        resp = mock_jira_response(data={
            "key": "PROJ-1",
            "id": "10001",
            "fields": {
                "summary": "Test issue",
                "status": {"name": "To Do"},
                "priority": {"name": "Medium"},
                "assignee": {"displayName": "John"},
                "reporter": {"displayName": "Jane"},
                "issuetype": {"name": "Task"},
                "project": {"key": "PROJ"},
                "created": "2025-01-01",
                "updated": "2025-01-02",
                "labels": ["backend"],
                "description": None,
            }
        })
        with patch.object(client._client, "get", return_value=resp):
            result = await client.get_issue("PROJ-1")
            assert result["key"] == "PROJ-1"
            assert result["summary"] == "Test issue"
            assert result["status"] == "To Do"
            assert result["assignee"] == "John"


class TestCreateIssue:
    @pytest.mark.asyncio
    async def test_create_issue_success(self, client, mock_jira_response):
        resp = mock_jira_response(data={"key": "PROJ-2", "id": "10002", "self": "https://x/rest/api/3/issue/10002"})
        with patch.object(client._client, "post", return_value=resp):
            result = await client.create_issue(project_key="PROJ", summary="New task")
            assert result["key"] == "PROJ-2"


class TestSearchIssues:
    @pytest.mark.asyncio
    async def test_search_success(self, client, mock_jira_response):
        resp = mock_jira_response(data={
            "total": 1,
            "issues": [{
                "key": "PROJ-1",
                "fields": {
                    "summary": "Found it",
                    "status": {"name": "Done"},
                    "priority": {"name": "High"},
                    "assignee": None,
                    "issuetype": {"name": "Bug"},
                    "project": {"key": "PROJ"},
                }
            }]
        })
        with patch.object(client._client, "post", return_value=resp):
            result = await client.search_issues(jql="project = PROJ")
            assert result["total"] == 1
            assert result["issues"][0]["key"] == "PROJ-1"
            assert result["issues"][0]["assignee"] == "Unassigned"


class TestListProjects:
    @pytest.mark.asyncio
    async def test_list_projects_success(self, client, mock_jira_response):
        resp = mock_jira_response(data=[
            {"key": "PROJ", "name": "My Project", "id": "100", "projectTypeKey": "software", "style": "next-gen"},
        ])
        # list_projects calls GET which returns a list, not a dict
        resp.json = lambda: [
            {"key": "PROJ", "name": "My Project", "id": "100", "projectTypeKey": "software", "style": "next-gen"},
        ]
        with patch.object(client._client, "get", return_value=resp):
            result = await client.list_projects()
            assert len(result) == 1
            assert result[0]["key"] == "PROJ"


class TestErrorHandling:
    @pytest.mark.asyncio
    async def test_auth_error(self, client):
        resp = AsyncMock()
        resp.status_code = 401
        resp.headers = {}
        resp.json = lambda: {"errorMessages": ["Unauthorized"]}
        with patch.object(client._client, "get", return_value=resp):
            with pytest.raises(JiraAuthError):
                await client.get_issue("PROJ-1")

    @pytest.mark.asyncio
    async def test_not_found_error(self, client):
        resp = AsyncMock()
        resp.status_code = 404
        resp.headers = {}
        resp.json = lambda: {"errorMessages": ["Issue not found"]}
        with patch.object(client._client, "get", return_value=resp):
            with pytest.raises(JiraNotFoundError):
                await client.get_issue("PROJ-999")

    @pytest.mark.asyncio
    async def test_rate_limit_retry(self, client):
        resp_429 = AsyncMock()
        resp_429.status_code = 429
        resp_429.headers = {"Retry-After": "1"}
        resp_429.json = lambda: {}

        resp_ok = AsyncMock()
        resp_ok.status_code = 200
        resp_ok.headers = {}
        resp_ok.json = lambda: {
            "key": "PROJ-1", "id": "1",
            "fields": {
                "summary": "Ok", "status": {"name": "Done"},
                "priority": {"name": "Low"}, "assignee": None,
                "reporter": None, "issuetype": {"name": "Task"},
                "project": {"key": "PROJ"}, "created": "", "updated": "",
                "labels": [], "description": None,
            }
        }
        with patch.object(client._client, "get", side_effect=[resp_429, resp_ok]):
            result = await client.get_issue("PROJ-1")
            assert result["key"] == "PROJ-1"


class TestConfigValidation:
    def test_valid_config(self, mock_config):
        errors = mock_config.validate()
        assert len(errors) == 0

    def test_missing_base_url(self):
        import os
        with patch.dict(os.environ, {}, clear=True):
            config = JiraConfig()
            errors = config.validate()
            assert any("JIRA_BASE_URL" in e for e in errors)

    def test_missing_email(self):
        import os
        with patch.dict(os.environ, {"JIRA_BASE_URL": "https://x.atlassian.net"}, clear=True):
            config = JiraConfig()
            errors = config.validate()
            assert any("JIRA_EMAIL" in e for e in errors)

    def test_missing_api_token(self):
        import os
        with patch.dict(os.environ, {
            "JIRA_BASE_URL": "https://x.atlassian.net",
            "JIRA_EMAIL": "a@b.com",
        }, clear=True):
            config = JiraConfig()
            errors = config.validate()
            assert any("JIRA_API_TOKEN" in e for e in errors)

    def test_invalid_url_prefix(self):
        import os
        with patch.dict(os.environ, {
            "JIRA_BASE_URL": "http://x.atlassian.net",
            "JIRA_EMAIL": "a@b.com",
            "JIRA_API_TOKEN": "tok",
        }, clear=True):
            config = JiraConfig()
            errors = config.validate()
            assert any("https://" in e for e in errors)
