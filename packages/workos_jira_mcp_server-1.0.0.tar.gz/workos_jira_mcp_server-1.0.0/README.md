# Jira MCP Server

<!-- mcp-name: io.github.workos/jira-mcp-server -->

A production-ready [Model Context Protocol (MCP)](https://modelcontextprotocol.io/) server for Jira project management. Connect any AI agent to Jira — create issues, search with JQL, manage workflows, track sprints, and more.

**This is an independent, generalized MCP server.** It is not tied to any specific project and can be connected to any AI agent that supports MCP (Claude Desktop, Cursor, WorkOS, or custom agents).

## Features

- 🎫 **Issues**: Create, read, update, search, and transition issues
- 🔍 **JQL Search**: Full Jira Query Language support
- 🔄 **Workflows**: Transition issues through statuses (To Do → In Progress → Done)
- 💬 **Comments**: Add comments to issues
- 📋 **Projects**: List accessible projects
- 🏃 **Sprints**: List sprints and get board details

## Installation

```bash
pip install workos-jira-mcp-server
```

Or install from source:
```bash
git clone https://github.com/workos/workos-jira-mcp-server
cd workos-jira-mcp-server
pip install -e .
```

## Quick Start

```bash
export JIRA_BASE_URL="https://your-org.atlassian.net"
export JIRA_EMAIL="you@company.com"
export JIRA_API_TOKEN="your-api-token"

# Run the server
jira-mcp-server

# Or run as a Python module
python -m jira_mcp_server
```

## Configuration

### Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `JIRA_BASE_URL` | ✅ Yes | Jira instance URL (e.g., `https://your-org.atlassian.net`) |
| `JIRA_EMAIL` | ✅ Yes | Email for Jira authentication |
| `JIRA_API_TOKEN` | ✅ Yes | API token ([generate here](https://id.atlassian.net/manage-profile/security/api-tokens)) |

### Getting a Jira API Token

1. Go to [Atlassian API Tokens](https://id.atlassian.net/manage-profile/security/api-tokens)
2. Click **Create API token**
3. Give it a label and click **Create**
4. Copy the token

## Connecting to AI Agents

### Claude Desktop

Add to `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "jira": {
      "command": "jira-mcp-server",
      "env": {
        "JIRA_BASE_URL": "https://your-org.atlassian.net",
        "JIRA_EMAIL": "you@company.com",
        "JIRA_API_TOKEN": "your-api-token"
      }
    }
  }
}
```

### Cursor

Add to `.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "jira": {
      "command": "jira-mcp-server",
      "env": {
        "JIRA_BASE_URL": "https://your-org.atlassian.net",
        "JIRA_EMAIL": "you@company.com",
        "JIRA_API_TOKEN": "your-api-token"
      }
    }
  }
}
```

### WorkOS / Custom Agents

Add to `.mcp.json`:

```json
{
  "mcpServers": {
    "jira": {
      "transport": "stdio",
      "command": "python",
      "args": ["-m", "jira_mcp_server"],
      "env": {
        "JIRA_BASE_URL": "${JIRA_BASE_URL}",
        "JIRA_EMAIL": "${JIRA_EMAIL}",
        "JIRA_API_TOKEN": "${JIRA_API_TOKEN}"
      }
    }
  }
}
```

## Available Tools (9)

| Tool | Description |
|------|-------------|
| `jira_get_issue` | Get a Jira issue by key |
| `jira_create_issue` | Create a new issue |
| `jira_update_issue` | Update fields on an existing issue |
| `jira_search_issues` | Search issues using JQL |
| `jira_transition_issue` | Transition an issue to a new status |
| `jira_add_comment` | Add a comment to an issue |
| `jira_list_projects` | List all accessible projects |
| `jira_list_sprints` | List sprints for a board |
| `jira_get_board` | Get board details |

## Development

```bash
git clone https://github.com/workos/workos-jira-mcp-server
cd workos-jira-mcp-server
pip install -e .

# Run tests
pytest

# Run the server locally
JIRA_BASE_URL=https://test.atlassian.net JIRA_EMAIL=test@co.com JIRA_API_TOKEN=test python -m jira_mcp_server
```

## Publishing

### To PyPI
```bash
pip install build twine
python -m build
twine upload dist/*
```

### To MCP Registry
```bash
mcp-publisher login github
mcp-publisher publish
```

## License

MIT — see [LICENSE](LICENSE) for details.
