"""
Jira MCP Server — Model Context Protocol server for Jira project management.

An independent, generalized MCP server that can connect to any AI agent
supporting the Model Context Protocol. Not tied to any specific project.

Quick start:
    pip install workos-jira-mcp-server
    JIRA_BASE_URL=https://org.atlassian.net JIRA_EMAIL=you@co.com JIRA_API_TOKEN=... jira-mcp-server

Or run as a module:
    python -m jira_mcp_server
"""

__version__ = "1.0.0"

from jira_mcp_server.server import create_server


def main():
    """Entry point for the jira-mcp-server CLI command."""
    server = create_server()
    server.run()


__all__ = ["main", "create_server", "__version__"]
