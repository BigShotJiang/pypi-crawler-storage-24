"""
Async Jira REST API Client.

Production-quality client with:
- Persistent connection pooling (httpx.AsyncClient)
- Dual auth: Basic (email + API token) or OAuth 2.0 client credentials
- Automatic retry with exponential backoff (429, 5xx)
- Rate limit handling (Retry-After header)
- OAuth token auto-refresh
- Structured error types
- Proper resource cleanup
"""

import asyncio
import base64
import logging
import sys
import time
from typing import Any, Optional

import httpx

logger = logging.getLogger("jira_mcp_server.client")

# Configure logging to stderr (required for stdio MCP transport)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    stream=sys.stderr,
)

ATLASSIAN_AUTH_URL = "https://auth.atlassian.com/oauth/token"
ATLASSIAN_RESOURCES_URL = "https://api.atlassian.com/oauth/token/accessible-resources"


# --- Error Types ---

class JiraAPIError(Exception):
    """Base error for Jira API failures."""

    def __init__(self, status_code: int = 0, message: str = ""):
        self.status_code = status_code
        self.message = message or f"Jira API error (HTTP {status_code})"
        super().__init__(self.message)


class JiraAuthError(JiraAPIError):
    """Authentication/authorization failure (401/403)."""
    pass


class JiraNotFoundError(JiraAPIError):
    """Resource not found (404)."""
    pass


class JiraRateLimitError(JiraAPIError):
    """Rate limit exceeded — caller should retry after delay."""

    def __init__(self, retry_after: int = 30):
        self.retry_after = retry_after
        super().__init__(429, f"Rate limited. Retry after {retry_after}s")


# --- OAuth Helper ---

async def _oauth_get_token(client_id: str, client_secret: str) -> tuple[str, int]:
    """Exchange client credentials for an access token.

    Returns (access_token, expires_in_seconds).
    """
    async with httpx.AsyncClient(timeout=15.0) as http:
        resp = await http.post(
            ATLASSIAN_AUTH_URL,
            json={
                "grant_type": "client_credentials",
                "client_id": client_id,
                "client_secret": client_secret,
            },
        )
        if resp.status_code != 200:
            raise JiraAuthError(
                resp.status_code,
                f"OAuth token exchange failed: {resp.text}",
            )
        data = resp.json()
        return data["access_token"], data.get("expires_in", 3600)


async def _oauth_get_cloud_id(access_token: str) -> tuple[str, str]:
    """Discover the first accessible Jira Cloud site.

    Returns (cloud_id, site_url).
    """
    async with httpx.AsyncClient(timeout=15.0) as http:
        resp = await http.get(
            ATLASSIAN_RESOURCES_URL,
            headers={"Authorization": f"Bearer {access_token}"},
        )
        if resp.status_code != 200:
            raise JiraAuthError(resp.status_code, "Failed to list accessible resources")
        sites = resp.json()
        if not sites:
            raise JiraAuthError(
                0,
                "No accessible Jira sites found for this service account. "
                "Grant the service account access in Atlassian Admin → Products.",
            )
        site = sites[0]
        return site["id"], site.get("url", f"https://{site.get('name', '')}.atlassian.net")


# --- Client ---

class JiraClient:
    """Async Jira REST API client with connection pooling and retry."""

    MAX_RETRIES = 3
    BACKOFF_BASE = 1.0  # seconds

    def __init__(self, base_url: str, email: str, api_token: str):
        """Create client with Basic auth (email + API token)."""
        if not base_url or not email or not api_token:
            raise JiraAuthError(0, "JIRA_BASE_URL, JIRA_EMAIL, and JIRA_API_TOKEN are all required")

        self.base_url = base_url.rstrip("/")
        self._auth_mode = "basic"
        credentials = base64.b64encode(f"{email}:{api_token}".encode()).decode()

        self._client = httpx.AsyncClient(
            base_url=f"{self.base_url}/rest",
            headers={
                "Authorization": f"Basic {credentials}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            timeout=30.0,
        )

        # OAuth fields (unused in basic mode)
        self._oauth_client_id = ""
        self._oauth_client_secret = ""
        self._oauth_token_expiry = 0.0

    @classmethod
    async def from_oauth(cls, client_id: str, client_secret: str) -> "JiraClient":
        """Create client with OAuth 2.0 client credentials (service account).

        Automatically discovers the Jira Cloud site and obtains an access token.
        """
        token, expires_in = await _oauth_get_token(client_id, client_secret)
        cloud_id, site_url = await _oauth_get_cloud_id(token)

        instance = cls.__new__(cls)
        instance.base_url = site_url.rstrip("/")
        instance._auth_mode = "oauth"
        instance._oauth_client_id = client_id
        instance._oauth_client_secret = client_secret
        instance._oauth_token_expiry = time.time() + expires_in - 60  # refresh 60s early

        instance._client = httpx.AsyncClient(
            base_url=f"https://api.atlassian.com/ex/jira/{cloud_id}/rest",
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            timeout=30.0,
        )

        logger.info("OAuth client connected to %s (cloud_id=%s)", site_url, cloud_id)
        return instance

    async def _refresh_oauth_if_needed(self):
        """Refresh the OAuth access token if it's close to expiring."""
        if self._auth_mode != "oauth":
            return
        if time.time() < self._oauth_token_expiry:
            return

        logger.info("Refreshing OAuth access token...")
        token, expires_in = await _oauth_get_token(
            self._oauth_client_id, self._oauth_client_secret,
        )
        self._oauth_token_expiry = time.time() + expires_in - 60
        self._client.headers["Authorization"] = f"Bearer {token}"
        logger.info("OAuth token refreshed (expires in %ds)", expires_in)

    async def close(self):
        """Close underlying HTTP client."""
        await self._client.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()

    async def _request(
        self,
        method: str,
        path: str,
        **kwargs,
    ) -> dict[str, Any] | list[Any] | None:
        """Make an authenticated request with retry logic."""
        await self._refresh_oauth_if_needed()
        for attempt in range(self.MAX_RETRIES):
            try:
                if method == "GET":
                    resp = await self._client.get(path, params=kwargs.get("params"))
                elif method == "POST":
                    resp = await self._client.post(path, json=kwargs.get("json"))
                elif method == "PUT":
                    resp = await self._client.put(path, json=kwargs.get("json"))
                elif method == "DELETE":
                    resp = await self._client.delete(path)
                else:
                    raise ValueError(f"Unsupported method: {method}")

                # Rate limit
                if resp.status_code == 429:
                    retry_after = int(resp.headers.get("Retry-After", 30))
                    if attempt < self.MAX_RETRIES - 1:
                        logger.warning(
                            "Rate limited, retrying after %ds (attempt %d/%d)",
                            retry_after, attempt + 1, self.MAX_RETRIES,
                        )
                        await asyncio.sleep(min(retry_after, 60))
                        continue
                    raise JiraRateLimitError(retry_after)

                # Server errors
                if resp.status_code >= 500:
                    if attempt < self.MAX_RETRIES - 1:
                        delay = self.BACKOFF_BASE * (2 ** attempt)
                        logger.warning(
                            "Server error %d, retrying in %.1fs (attempt %d/%d)",
                            resp.status_code, delay, attempt + 1, self.MAX_RETRIES,
                        )
                        await asyncio.sleep(delay)
                        continue

                # Auth errors
                if resp.status_code in (401, 403):
                    raise JiraAuthError(resp.status_code, "Authentication failed — check JIRA_EMAIL and JIRA_API_TOKEN")

                # Not found
                if resp.status_code == 404:
                    raise JiraNotFoundError(404, "Resource not found")

                # Other client errors
                if resp.status_code >= 400:
                    try:
                        body = resp.json()
                        messages = body.get("errorMessages", [])
                        errors = body.get("errors", {})
                        detail = "; ".join(messages) if messages else str(errors)
                    except Exception:
                        detail = resp.text
                    raise JiraAPIError(resp.status_code, detail)

                # No content (e.g., 204 on transitions)
                if resp.status_code == 204:
                    return None

                return resp.json()

            except httpx.RequestError as e:
                if attempt < self.MAX_RETRIES - 1:
                    delay = self.BACKOFF_BASE * (2 ** attempt)
                    logger.warning("Request error: %s, retrying in %.1fs", str(e), delay)
                    await asyncio.sleep(delay)
                    continue
                raise JiraAPIError(0, str(e))

        raise JiraAPIError(0, "Failed after maximum retries")

    # --- Issues ---

    async def get_issue(self, issue_key: str, fields: Optional[str] = None) -> dict:
        """Get a Jira issue by key (e.g., 'PROJ-123')."""
        params = {}
        if fields:
            params["fields"] = fields
        data = await self._request("GET", f"/api/3/issue/{issue_key}", params=params or None)
        issue = data
        f = issue.get("fields", {})
        return {
            "key": issue.get("key", issue_key),
            "id": issue.get("id", ""),
            "summary": f.get("summary", ""),
            "description": _extract_text(f.get("description")),
            "status": f.get("status", {}).get("name", ""),
            "priority": f.get("priority", {}).get("name", ""),
            "assignee": f.get("assignee", {}).get("displayName", "Unassigned") if f.get("assignee") else "Unassigned",
            "reporter": f.get("reporter", {}).get("displayName", "") if f.get("reporter") else "",
            "issue_type": f.get("issuetype", {}).get("name", ""),
            "project": f.get("project", {}).get("key", ""),
            "created": f.get("created", ""),
            "updated": f.get("updated", ""),
            "labels": f.get("labels", []),
        }

    async def create_issue(
        self,
        project_key: str,
        summary: str,
        issue_type: str = "Task",
        description: str = "",
        priority: str = "",
        assignee_id: str = "",
        labels: Optional[list[str]] = None,
    ) -> dict:
        """Create a new Jira issue."""
        fields: dict[str, Any] = {
            "project": {"key": project_key},
            "summary": summary,
            "issuetype": {"name": issue_type},
        }
        if description:
            fields["description"] = _make_adf(description)
        if priority:
            fields["priority"] = {"name": priority}
        if assignee_id:
            fields["assignee"] = {"accountId": assignee_id}
        if labels:
            fields["labels"] = labels

        data = await self._request("POST", "/api/3/issue", json={"fields": fields})
        return {
            "key": data.get("key", ""),
            "id": data.get("id", ""),
            "self": data.get("self", ""),
        }

    async def update_issue(
        self,
        issue_key: str,
        summary: Optional[str] = None,
        description: Optional[str] = None,
        priority: Optional[str] = None,
        assignee_id: Optional[str] = None,
        labels: Optional[list[str]] = None,
    ) -> dict:
        """Update fields on an existing Jira issue."""
        fields: dict[str, Any] = {}
        if summary is not None:
            fields["summary"] = summary
        if description is not None:
            fields["description"] = _make_adf(description)
        if priority is not None:
            fields["priority"] = {"name": priority}
        if assignee_id is not None:
            fields["assignee"] = {"accountId": assignee_id}
        if labels is not None:
            fields["labels"] = labels

        if not fields:
            return {"key": issue_key, "updated": False, "message": "No fields to update"}

        await self._request("PUT", f"/api/3/issue/{issue_key}", json={"fields": fields})
        return {"key": issue_key, "updated": True}

    async def search_issues(self, jql: str, max_results: int = 20, fields: Optional[str] = None) -> dict:
        """Search issues using JQL."""
        payload: dict[str, Any] = {
            "jql": jql,
            "maxResults": min(max_results, 100),
            "fields": (fields or "summary,status,assignee,priority,issuetype,project,created,updated").split(","),
        }
        data = await self._request("POST", "/api/3/search/jql", json=payload)
        issues = []
        for issue in data.get("issues", []):
            f = issue.get("fields", {})
            issues.append({
                "key": issue.get("key", ""),
                "summary": f.get("summary", ""),
                "status": f.get("status", {}).get("name", ""),
                "priority": f.get("priority", {}).get("name", "") if f.get("priority") else "",
                "assignee": f.get("assignee", {}).get("displayName", "Unassigned") if f.get("assignee") else "Unassigned",
                "issue_type": f.get("issuetype", {}).get("name", ""),
                "project": f.get("project", {}).get("key", ""),
            })
        return {
            "total": data.get("total", len(issues)),
            "count": len(issues),
            "issues": issues,
        }

    # --- Transitions ---

    async def get_transitions(self, issue_key: str) -> list[dict]:
        """Get available transitions for an issue."""
        data = await self._request("GET", f"/api/3/issue/{issue_key}/transitions")
        return [
            {"id": t["id"], "name": t["name"], "to_status": t.get("to", {}).get("name", "")}
            for t in data.get("transitions", [])
        ]

    async def transition_issue(self, issue_key: str, transition_id: str, comment: str = "") -> dict:
        """Transition an issue to a new status."""
        payload: dict[str, Any] = {"transition": {"id": transition_id}}
        if comment:
            payload["update"] = {
                "comment": [{"add": {"body": _make_adf(comment)}}]
            }
        await self._request("POST", f"/api/3/issue/{issue_key}/transitions", json=payload)
        return {"key": issue_key, "transitioned": True, "transition_id": transition_id}

    # --- Comments ---

    async def add_comment(self, issue_key: str, body: str) -> dict:
        """Add a comment to an issue."""
        data = await self._request(
            "POST",
            f"/api/3/issue/{issue_key}/comment",
            json={"body": _make_adf(body)},
        )
        return {
            "id": data.get("id", ""),
            "issue_key": issue_key,
            "author": data.get("author", {}).get("displayName", ""),
            "created": data.get("created", ""),
        }

    # --- Projects ---

    async def list_projects(self) -> list[dict]:
        """List all accessible projects."""
        data = await self._request("GET", "/api/3/project")
        return [
            {
                "key": p.get("key", ""),
                "name": p.get("name", ""),
                "id": p.get("id", ""),
                "project_type": p.get("projectTypeKey", ""),
                "style": p.get("style", ""),
            }
            for p in data
        ]

    # --- Boards & Sprints (Agile API) ---

    async def get_board(self, board_id: int) -> dict:
        """Get a Jira board by ID."""
        data = await self._request("GET", f"/agile/1.0/board/{board_id}")
        return {
            "id": data.get("id", board_id),
            "name": data.get("name", ""),
            "type": data.get("type", ""),
            "project_key": data.get("location", {}).get("projectKey", ""),
        }

    async def list_sprints(self, board_id: int, state: str = "active") -> list[dict]:
        """List sprints for a board."""
        data = await self._request(
            "GET",
            f"/agile/1.0/board/{board_id}/sprint",
            params={"state": state},
        )
        return [
            {
                "id": s.get("id", 0),
                "name": s.get("name", ""),
                "state": s.get("state", ""),
                "start_date": s.get("startDate", ""),
                "end_date": s.get("endDate", ""),
                "goal": s.get("goal", ""),
            }
            for s in data.get("values", [])
        ]


# --- Helpers ---

def _extract_text(description: Any) -> str:
    """Extract plain text from Atlassian Document Format (ADF)."""
    if description is None:
        return ""
    if isinstance(description, str):
        return description
    # ADF format: walk content nodes for text
    parts = []
    _walk_adf(description, parts)
    return " ".join(parts)


def _walk_adf(node: Any, parts: list[str]):
    """Recursively walk ADF nodes to extract text."""
    if isinstance(node, dict):
        if node.get("type") == "text":
            parts.append(node.get("text", ""))
        for child in node.get("content", []):
            _walk_adf(child, parts)
    elif isinstance(node, list):
        for item in node:
            _walk_adf(item, parts)


def _make_adf(text: str) -> dict:
    """Convert plain text to Atlassian Document Format (ADF)."""
    return {
        "type": "doc",
        "version": 1,
        "content": [
            {
                "type": "paragraph",
                "content": [{"type": "text", "text": text}],
            }
        ],
    }


# --- Client Factory ---

# Cache OAuth client to avoid re-discovering cloud ID on every tool call
_oauth_client_cache: Optional[JiraClient] = None


async def create_client(config) -> JiraClient:
    """Create a JiraClient from config, using the appropriate auth mode.

    For OAuth mode, the client is cached and reused across tool calls
    (token refresh is handled automatically).
    """
    global _oauth_client_cache

    if config.auth_mode == "oauth":
        if _oauth_client_cache is not None:
            return _oauth_client_cache
        client = await JiraClient.from_oauth(
            client_id=config.oauth_client_id,
            client_secret=config.oauth_client_secret,
        )
        _oauth_client_cache = client
        return client
    else:
        return JiraClient(
            base_url=config.base_url,
            email=config.email,
            api_token=config.api_token,
        )
