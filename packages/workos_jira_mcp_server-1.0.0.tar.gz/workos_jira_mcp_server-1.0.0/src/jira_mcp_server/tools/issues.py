"""Jira issue tools — get, create, update, search, transition, comment."""

from typing import Optional

from jira_mcp_server.client import JiraAPIError, create_client
from jira_mcp_server.config import JiraConfig


def register_issue_tools(app, config: JiraConfig):
    """Register issue tools with the FastMCP app."""

    @app.tool()
    async def jira_get_issue(issue_key: str) -> dict:
        """Get a Jira issue by key.

        Args:
            issue_key: The issue key (e.g., 'PROJ-123')
        """
        try:
            client = await create_client(config)
            result = await client.get_issue(issue_key=issue_key)
            return {"success": True, **result}
        except JiraAPIError as e:
            return {"success": False, "error": e.message}

    @app.tool()
    async def jira_create_issue(
        project_key: str,
        summary: str,
        issue_type: str = "Task",
        description: str = "",
        priority: str = "",
        assignee_id: str = "",
        labels: Optional[list[str]] = None,
    ) -> dict:
        """Create a new Jira issue.

        Args:
            project_key: Project key (e.g., 'PROJ')
            summary: Issue title/summary
            issue_type: Type of issue — 'Task', 'Bug', 'Story', 'Epic' (default: 'Task')
            description: Detailed description (plain text, converted to ADF)
            priority: Priority name — 'Highest', 'High', 'Medium', 'Low', 'Lowest'
            assignee_id: Atlassian account ID of the assignee
            labels: List of labels to apply
        """
        try:
            client = await create_client(config)
            result = await client.create_issue(
                project_key=project_key,
                summary=summary,
                issue_type=issue_type,
                description=description,
                priority=priority,
                assignee_id=assignee_id,
                labels=labels,
            )
            return {"success": True, **result}
        except JiraAPIError as e:
            return {"success": False, "error": e.message}

    @app.tool()
    async def jira_update_issue(
        issue_key: str,
        summary: Optional[str] = None,
        description: Optional[str] = None,
        priority: Optional[str] = None,
        assignee_id: Optional[str] = None,
        labels: Optional[list[str]] = None,
    ) -> dict:
        """Update fields on an existing Jira issue.

        Args:
            issue_key: The issue key (e.g., 'PROJ-123')
            summary: New summary/title
            description: New description (plain text)
            priority: New priority — 'Highest', 'High', 'Medium', 'Low', 'Lowest'
            assignee_id: New assignee (Atlassian account ID)
            labels: New labels (replaces existing)
        """
        try:
            client = await create_client(config)
            result = await client.update_issue(
                issue_key=issue_key,
                summary=summary,
                description=description,
                priority=priority,
                assignee_id=assignee_id,
                labels=labels,
            )
            return {"success": True, **result}
        except JiraAPIError as e:
            return {"success": False, "error": e.message}

    @app.tool()
    async def jira_search_issues(jql: str, max_results: int = 20) -> dict:
        """Search Jira issues using JQL (Jira Query Language).

        Args:
            jql: JQL query string (e.g., 'project = PROJ AND status = "In Progress"')
            max_results: Maximum number of results (1-100, default: 20)
        """
        max_results = min(max(max_results, 1), 100)
        try:
            client = await create_client(config)
            result = await client.search_issues(jql=jql, max_results=max_results)
            return {"success": True, **result}
        except JiraAPIError as e:
            return {"success": False, "error": e.message}

    @app.tool()
    async def jira_transition_issue(
        issue_key: str, transition_id: str, comment: str = ""
    ) -> dict:
        """Transition an issue to a new status (e.g., To Do → In Progress → Done).

        Use jira_get_issue first to see available transitions.

        Args:
            issue_key: The issue key (e.g., 'PROJ-123')
            transition_id: The transition ID (get from available transitions on the issue)
            comment: Optional comment to add with the transition
        """
        try:
            client = await create_client(config)
            result = await client.transition_issue(
                issue_key=issue_key, transition_id=transition_id, comment=comment
            )
            return {"success": True, **result}
        except JiraAPIError as e:
            return {"success": False, "error": e.message}

    @app.tool()
    async def jira_add_comment(issue_key: str, body: str) -> dict:
        """Add a comment to a Jira issue.

        Args:
            issue_key: The issue key (e.g., 'PROJ-123')
            body: Comment text (plain text, converted to ADF)
        """
        try:
            client = await create_client(config)
            result = await client.add_comment(issue_key=issue_key, body=body)
            return {"success": True, **result}
        except JiraAPIError as e:
            return {"success": False, "error": e.message}
