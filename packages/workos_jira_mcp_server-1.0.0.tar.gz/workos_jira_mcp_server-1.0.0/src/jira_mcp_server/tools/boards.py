"""Jira board & sprint tools — list sprints, get board."""

from jira_mcp_server.client import JiraAPIError, create_client
from jira_mcp_server.config import JiraConfig


def register_board_tools(app, config: JiraConfig):
    """Register board/sprint tools with the FastMCP app."""

    @app.tool()
    async def jira_list_sprints(board_id: int, state: str = "active") -> dict:
        """List sprints for a Jira board.

        Args:
            board_id: The board ID (numeric)
            state: Sprint state filter — 'active', 'closed', 'future' (default: 'active')
        """
        try:
            client = await create_client(config)
            sprints = await client.list_sprints(board_id=board_id, state=state)
            return {"success": True, "board_id": board_id, "count": len(sprints), "sprints": sprints}
        except JiraAPIError as e:
            return {"success": False, "error": e.message}

    @app.tool()
    async def jira_get_board(board_id: int) -> dict:
        """Get details of a Jira board.

        Args:
            board_id: The board ID (numeric)
        """
        try:
            client = await create_client(config)
            result = await client.get_board(board_id=board_id)
            return {"success": True, **result}
        except JiraAPIError as e:
            return {"success": False, "error": e.message}
