"""Jira project tools — list projects."""

from jira_mcp_server.client import JiraAPIError, create_client
from jira_mcp_server.config import JiraConfig


def register_project_tools(app, config: JiraConfig):
    """Register project tools with the FastMCP app."""

    @app.tool()
    async def jira_list_projects() -> dict:
        """List all accessible Jira projects."""
        try:
            client = await create_client(config)
            projects = await client.list_projects()
            return {"success": True, "count": len(projects), "projects": projects}
        except JiraAPIError as e:
            return {"success": False, "error": e.message}
