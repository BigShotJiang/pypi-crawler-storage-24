"""Jira MCP Server tools — organized by domain."""
