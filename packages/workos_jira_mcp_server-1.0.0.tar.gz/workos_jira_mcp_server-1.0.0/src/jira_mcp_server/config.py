"""
Environment variable validation for Jira MCP Server.

Supports two authentication modes:

  Mode 1 — API Token (simplest):
    JIRA_BASE_URL:   Jira instance URL (e.g., https://your-org.atlassian.net)
    JIRA_EMAIL:      Email address for authentication
    JIRA_API_TOKEN:  API token (https://id.atlassian.net/manage-profile/security/api-tokens)

  Mode 2 — OAuth 2.0 Client Credentials (service accounts):
    ATLASSIAN_CLIENT_ID:     OAuth 2.0 client ID
    ATLASSIAN_CLIENT_SECRET: OAuth 2.0 client secret

Optional:
    JIRA_LOG_LEVEL:  Logging level (default: INFO)
"""

import os
import sys
import logging

logger = logging.getLogger("jira_mcp_server.config")


class JiraConfig:
    """Validated Jira configuration from environment variables."""

    def __init__(self):
        self.base_url: str = ""
        self.email: str = ""
        self.api_token: str = ""
        self.oauth_client_id: str = ""
        self.oauth_client_secret: str = ""
        self.auth_mode: str = ""  # "api_token" or "oauth"
        self.log_level: str = "INFO"
        self._load()

    def _load(self):
        self.base_url = os.environ.get("JIRA_BASE_URL", "").rstrip("/")
        self.email = os.environ.get("JIRA_EMAIL", "")
        self.api_token = os.environ.get("JIRA_API_TOKEN", "")
        self.oauth_client_id = os.environ.get("ATLASSIAN_CLIENT_ID", "")
        self.oauth_client_secret = os.environ.get("ATLASSIAN_CLIENT_SECRET", "")
        self.log_level = os.environ.get("JIRA_LOG_LEVEL", "INFO")

        # Determine auth mode
        if self.oauth_client_id and self.oauth_client_secret:
            self.auth_mode = "oauth"
        elif self.api_token and self.email and self.base_url:
            self.auth_mode = "api_token"
        else:
            self.auth_mode = ""

    def validate(self) -> list[str]:
        """Validate configuration. Returns list of error messages (empty = valid)."""
        errors = []

        if self.auth_mode == "oauth":
            # OAuth mode — base_url is resolved from accessible-resources
            if not self.oauth_client_id:
                errors.append("ATLASSIAN_CLIENT_ID is required for OAuth mode")
            if not self.oauth_client_secret:
                errors.append("ATLASSIAN_CLIENT_SECRET is required for OAuth mode")
            logger.info("Using OAuth 2.0 client credentials authentication")

        elif self.auth_mode == "api_token":
            if not self.base_url:
                errors.append("JIRA_BASE_URL is required (e.g., https://your-org.atlassian.net)")
            elif not self.base_url.startswith("https://"):
                errors.append(
                    f"JIRA_BASE_URL should start with 'https://', got '{self.base_url[:20]}...'"
                )
            if not self.email:
                errors.append("JIRA_EMAIL is required (your Jira account email)")
            if not self.api_token:
                errors.append(
                    "JIRA_API_TOKEN is required (generate at https://id.atlassian.net/manage-profile/security/api-tokens)"
                )
            logger.info("Using API token authentication")

        else:
            errors.append(
                "No valid authentication configured. Provide either:\n"
                "  Option 1: JIRA_BASE_URL + JIRA_EMAIL + JIRA_API_TOKEN\n"
                "  Option 2: ATLASSIAN_CLIENT_ID + ATLASSIAN_CLIENT_SECRET"
            )

        return errors

    def validate_or_exit(self):
        """Validate configuration, exit with clear error if invalid."""
        errors = self.validate()
        if errors:
            print("Jira MCP Server configuration errors:", file=sys.stderr)
            for err in errors:
                print(f"  ✗ {err}", file=sys.stderr)
            print(
                "\nSet the required environment variables and try again.",
                file=sys.stderr,
            )
            sys.exit(1)
        logger.info("Jira configuration validated successfully")
