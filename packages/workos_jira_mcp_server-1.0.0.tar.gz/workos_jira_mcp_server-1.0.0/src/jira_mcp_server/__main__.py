"""Allow running as: python -m jira_mcp_server"""
from jira_mcp_server import main

main()
