"""
Jira MCP Server — FastMCP instance with all tools registered.

This is the core server module. Tools are organized by domain
in the tools/ subpackage and registered here.
"""

import logging
import sys

from fastmcp import FastMCP

from jira_mcp_server.config import JiraConfig
from jira_mcp_server.tools.issues import register_issue_tools
from jira_mcp_server.tools.projects import register_project_tools
from jira_mcp_server.tools.boards import register_board_tools

# Ensure logging goes to stderr (required for stdio MCP transport)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    stream=sys.stderr,
)

logger = logging.getLogger("jira_mcp_server")


def create_server() -> FastMCP:
    """Create and configure the Jira MCP server.

    Validates environment configuration on startup and registers
    all Jira tools with the FastMCP instance.
    """
    # Validate config on startup
    config = JiraConfig()
    config.validate_or_exit()

    app = FastMCP(
        name="jira-mcp-server",
        instructions=(
            "MCP server for Jira project management. "
            "Create issues, search with JQL, manage workflows, "
            "track sprints, and add comments."
        ),
        version="1.0.0",
    )

    # Register all tool groups
    register_issue_tools(app, config)
    register_project_tools(app, config)
    register_board_tools(app, config)

    logger.info("Jira MCP server configured with all tool groups")
    return app
