---
gsd_state_version: 1.0
milestone: v1.4
milestone_name: milestone
status: executing
stopped_at: Completed 06-04-PLAN.md
last_updated: "2026-03-23T03:50:20.907Z"
progress:
  total_phases: 6
  completed_phases: 5
  total_plans: 16
  completed_plans: 15
---

# Project State: v1.4 -- Zero-Gap Zero-Overlap Guarantee

**Initialized:** 2026-03-21
**Status:** Ready to execute

---

## Project Reference

See: .planning/PROJECT.md (updated 2026-03-21)

**Core value:** Zero Stathera gaps and overlaps across every restart, every midnight boundary, every deploy -- verified by continuous telemetry.
**Current focus:** Phase 06 — memory-efficiency-refactoring-p0-findings-from-issue-300-with-oracle-bit-exact-regression-tests

## Current Position

Phase: 06 (memory-efficiency-refactoring-p0-findings-from-issue-300-with-oracle-bit-exact-regression-tests) — EXECUTING
Plan: 2 of 4

## Performance Metrics

**Velocity:**

- Total plans completed: 0
- Average duration: -
- Total execution time: 0 hours

**By Phase:**

| Phase | Plans | Total | Avg/Plan |
| ----- | ----- | ----- | -------- |
| -     | -     | -     | -        |

**Recent Trend:**

- Last 5 plans: -
- Trend: -

_Updated after each plan completion_
| Phase 01 P01 | 3min | 1 tasks | 3 files |
| Phase 01 P02 | 7min | 2 tasks | 3 files |
| Phase 02 P01 | 2min | 2 tasks | 3 files |
| Phase 02 P02 | 2min | 2 tasks | 2 files |
| Phase 03 P01 | 5min | 2 tasks | 4 files |
| Phase 03 P02 | 6min | 2 tasks | 9 files |
| Phase 04 P01 | 7min | 2 tasks | 4 files |
| Phase 04 P02 | 4min | 2 tasks | 4 files |
| Phase 05 P01 | 4min | 2 tasks | 5 files |
| Phase 05 P02 | 6min | 3 tasks | 9 files |
| Phase 05 P03 | 6min | 2 tasks | 3 files |
| Phase 05 P04 | 8min | 3 tasks | 7 files |
| Phase 06 P01 | 73min | 2 tasks | 5 files |
| Phase 06 P03 | 3min | 1 tasks | 2 files |
| Phase 06 P02 | 15min | 2 tasks | 8 files |
| Phase 06 P04 | 4min | 2 tasks | 4 files |

## Accumulated Context

### Decisions

Decisions are logged in PROJECT.md Key Decisions table.
Recent decisions affecting current work:

- [v1.4 init]: committed_floors fix must land before preflight (preflight depends on correct dedup to verify junction)
- [v1.4 init]: Telemetry phase last -- validates the fixes from Phases 1 and 2 in production
- [v1.4 init]: 6-agent spike (2026-03-21) identified two root causes: Bug 1 (committed_floors), Bug 2 (midnight processor seam)
- [Phase 01]: last_completed_bar_tid NOT reset to None in reset_at_ouroboros -- persists across day boundaries for dedup floor continuity
- [Phase 01]: Orphan bars treated as completed bars for dedup purposes -- orphan emission updates last_completed_bar_tid
- [Phase 01]: committed_floors reads last_completed_bar_tid to avoid suppressing junction bars
- [Phase 02]: Preflight functions never raise -- return None/False on error, deferring to kintsugi
- [Phase 02]: Verification is log-only -- orphan mismatch does NOT prevent seed override (crossover TID authoritative)
- [Phase 03]: Removed intra-day/adjacent-day/backfill gap classification -- a gap is a gap (TELEM-01)
- [Phase 03]: Today-gap LOUD alert suppressed when kintsugi is healing to prevent noise during repairs
- [Phase 03]: yesterday_completion is health-gating; junction_telemetry is informational only
- [Phase 03]: Added scripts to pytest pythonpath for heartbeat module imports
- [Phase 04]: PongTimeout is recoverable (triggers reconnect), RateLimited and BanDetected are terminal (prevent retry storm)
- [Phase 04]: BanDetected handled specially in run_with_reconnect: sleep until expiry then resume, despite terminal classification
- [Phase 04]: Stream signals derived from engine metrics reconnection counter, not Rust channel piping
- [Phase 04]: 429/ban classified as FATAL (ws_errors_healthy=False), transient disconnects as NORMAL (True)
- [Phase 05]: All Parquet tick writes must route through write_ticks() for dedup + continuity validation
- [Phase 05]: PyAdaptiveRateLimiter.acquire() uses inline tokio runtime (no py.allow_threads) matching existing fetch pattern
- [Phase 05]: Rate limit check gates both \_fetch_aggtrades_rest and_fetch_aggtrades_by_id via single helper function
- [Phase 05]: REST fallback uses Rust bindings (full column names) not raw REST single-letter keys
- [Phase 05]: Kintsugi guard uses .meta sidecar presence not ClickHouse queries -- O(1) per day
- [Phase 05]: Batch rotation state persisted to JSON file on disk (survives systemd timer restarts)
- [Phase 05]: ratelimit_ok added to WARNING_KEYS (not CRITICAL) -- 429 risk is operational, not data integrity
- [Phase 05]: days_behind is informational only, does NOT gate seeder_ok
- [Phase 05]: Vision oracle uses weekly cadence with 0.1% mismatch threshold
- [Phase 06]: f64 comparison uses 1e-12 relative tolerance for JSON text round-trip ULP noise
- [Phase 06]: GoldenBar struct uses raw i64/i128 for FixedPoint fields, avoiding f64 conversion
- [Phase 06]: Python golden fixture captures Arrow output columns only (inter/intra-bar features not in Arrow schema)
- [Phase 06]: MEM-03 GIL release via py.detach() in both Arrow processing methods; PyO3 0.28 renamed allow_threads to detach
- [Phase 06]: FormingBar throttle uses trade timestamp for deterministic 1 Hz throttling with reset on bar completion
- [Phase 06]: discover_providers() check gates to_pandas() — cached after first call, zero overhead
- [Phase 06]: REST fallback converts list[dict] to Polars immediately then uses Arrow path — orphan bars handled via dict-to-DataFrame fallback
- [Phase 06]: diagonal_relaxed concat used for mixing Arrow-output and dict-constructed DataFrames

### Roadmap Evolution

- Phase 4 added: WS Resilience Enhancements — adopt unicorn-binance-websocket-api patterns (ping/pong, rate limits, error classification, IP ban handling, stream signals, buffer OOM prevention)
- Phase 6 added: Memory efficiency refactoring — P0 findings from Issue #300 with Oracle bit-exact regression tests

### Pending Todos

None yet.

### Blockers/Concerns

None.

### Quick Tasks Completed

| #          | Description                                                        | Date       | Commit  | Directory                                                                  |
| ---------- | ------------------------------------------------------------------ | ---------- | ------- | -------------------------------------------------------------------------- |
| 260320-xah | Fix pytest OOM: exclude benchmark and heavy tests from default run | 2026-03-21 | e3287cc | [260320-xah](./quick/260320-xah-fix-pytest-oom-exclude-benchmark-and-hea/) |
| 260321-n48 | Fix async DELETE race in \_delete_today_bars + diagnostics         | 2026-03-21 | 941aabc | [260321-n48](./quick/260321-n48-fix-async-delete-race-in-delete-today-ba/) |
| 260321-ql9 | Sprint 1 Guard Hardening P0 Fixes (4 data-loss prevention fixes)   | 2026-03-22 | ca76a6b | [260321-ql9](./quick/260321-ql9-sprint-1-guard-hardening-p0-fixes/)        |

## Session Continuity

Last session: 2026-03-23T03:50:20.905Z
Stopped at: Completed 06-04-PLAN.md
Resume file: None
