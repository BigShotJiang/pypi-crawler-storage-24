"""DOCX text extraction."""

from __future__ import annotations

from llm_lab.exceptions import ParseError

from .base import File


class Docx(File):
    """DOCX text parser using python-docx."""

    def read_file(self) -> str:
        """Extract text from a DOCX file.

        Returns:
            Concatenated text from paragraph runs.

        Raises:
            ParseError: if the DOCX cannot be opened or parsed.
        """
        from docx import Document

        try:
            doc = Document(self.path)
            return "\n".join(p.text for p in doc.paragraphs if p.text.strip())
        except Exception as exc:
            raise ParseError(f"Failed to parse DOCX: {self.path}") from exc
