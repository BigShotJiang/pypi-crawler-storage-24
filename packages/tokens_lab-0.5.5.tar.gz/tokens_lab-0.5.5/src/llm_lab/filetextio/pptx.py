"""PPTX text extraction."""

from __future__ import annotations

from llm_lab.exceptions import ParseError

from .base import File


def _extract_shape_text(shape) -> str:
    """Extract text content from a single PPTX shape."""
    if getattr(shape, "has_text_frame", False) and shape.text_frame:
        return "\n".join(p.text for p in shape.text_frame.paragraphs if p.text).strip()
    return (getattr(shape, "text", "") or "").strip()


class Pptx(File):
    """PPTX text parser using python-pptx."""

    def read_file(self) -> str:
        from pptx import Presentation

        try:
            prs = Presentation(self.path)
            parts: list[str] = []
            for idx, slide in enumerate(prs.slides, start=1):
                texts = [t for shape in slide.shapes if (t := _extract_shape_text(shape))]
                if texts:
                    parts.append(f"[SLIDE {idx}]\n" + "\n".join(texts))
            return "\n\n".join(parts)
        except Exception as exc:
            raise ParseError(f"Failed to parse PPTX: {self.path}") from exc
