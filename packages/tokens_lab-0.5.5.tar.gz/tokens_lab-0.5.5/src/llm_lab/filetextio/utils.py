"""Utility helpers for temporary file handling in async upload flows."""

from __future__ import annotations

from pathlib import Path
from typing import Any


async def create_temp_pdf_file(file: Any, temp_path: str, logger: Any) -> bool:
    """Write an uploaded PDF to a temporary path. Returns False if empty."""
    with open(temp_path, "wb") as f:
        content = await file.read()
        if not content:
            logger.warning(f"Empty file uploaded: {getattr(file, 'filename', '<unknown>')}")
            return False
        f.write(content)
    return True


def delete_file(temp_path: str) -> None:
    """Delete a file if it exists, ignoring errors."""
    Path(temp_path).unlink(missing_ok=True)
