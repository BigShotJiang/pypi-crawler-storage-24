"""File text I/O: parsers, format detection, and utilities."""

from __future__ import annotations

from .base import File, PathLike
from .docx import Docx
from .pdf import Pdf
from .pptx import Pptx
from .txt import Txt
from .registry import (
    detect_file_format,
    get_parser_for,
    get_supported_types,
    is_supported_file,
    load_text,
)
from .utils import create_temp_pdf_file, delete_file

__all__ = [
    "File",
    "PathLike",
    "Pdf",
    "Docx",
    "Pptx",
    "Txt",
    "detect_file_format",
    "get_parser_for",
    "get_supported_types",
    "is_supported_file",
    "load_text",
    "create_temp_pdf_file",
    "delete_file",
]
