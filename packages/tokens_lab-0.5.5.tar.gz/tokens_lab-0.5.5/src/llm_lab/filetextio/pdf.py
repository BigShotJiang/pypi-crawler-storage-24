"""PDF text extraction and page-to-image conversion."""

from __future__ import annotations

import os
from pathlib import Path

import fitz  # type: ignore[import-untyped]
import pdfplumber  # type: ignore[import-untyped]
import pypdfium2 as pdfium  # type: ignore[import-untyped]

from llm_lab.exceptions import ParseError

from .base import File
from .image import _pil_to_base64


class Pdf(File):
    """PDF text parser using pdfplumber."""

    def read_file(self) -> str:
        try:
            with pdfplumber.open(self.path) as pdf:
                return "\n".join(page.extract_text() or "" for page in pdf.pages)
        except Exception as exc:
            raise ParseError(f"Failed to parse PDF: {self.path}") from exc

    @staticmethod
    def render_page(doc, index: int):
        """Render a single PDF page to a PIL image."""
        try:
            page = doc.get_page(index)
        except AttributeError:
            page = doc[index]
        try:
            return page.render(scale=2.0).to_pil()
        finally:
            try:
                page.close()
            except Exception:
                pass

    @staticmethod
    def render_pages(pdf_path: str, max_pages: int | None = None) -> list:
        """Render PDF pages to PIL images using pypdfium2."""
        doc = pdfium.PdfDocument(pdf_path)
        try:
            limit = len(doc) if max_pages is None else min(len(doc), max_pages)
            return [Pdf.render_page(doc, i) for i in range(limit)]
        finally:
            try:
                doc.close()
            except Exception:
                pass

    @classmethod
    def pdf_to_base64_images(cls, pdf_path: str, max_pages: int | None = None) -> list[str]:
        """Convert PDF pages to base64-encoded JPEG images."""
        try:
            return [_pil_to_base64(img) for img in cls.render_pages(pdf_path, max_pages)]
        except Exception:
            return []

    @staticmethod
    def save_single_page(input_pdf: str, page_number: int, output_pdf: str) -> None:
        """Save a single page from a PDF to a new file (1-based page number)."""
        pdf_doc = fitz.open(input_pdf)
        total_pages = pdf_doc.page_count

        if page_number < 1 or page_number > total_pages:
            pdf_doc.close()
            raise ValueError(f"Page number must be between 1 and {total_pages}")

        new_pdf = fitz.open()
        new_pdf.insert_pdf(pdf_doc, from_page=page_number - 1, to_page=page_number - 1)
        new_pdf.save(output_pdf)

        new_pdf.close()
        pdf_doc.close()

    @staticmethod
    def save_multiple_pages(
        input_pdf: str,
        page_numbers: list[int],
        dest_paths: dict[int, str] | None = None,
        output_folder: str | None = None,
        cv_info: list[dict] | None = None,
    ) -> dict[int, str]:
        """Save multiple pages from a PDF to individual files (1-based page numbers)."""
        if not page_numbers:
            return {}

        pdf_doc = fitz.open(input_pdf)
        total_pages = pdf_doc.page_count

        for p in page_numbers:
            if p < 1 or p > total_pages:
                pdf_doc.close()
                raise ValueError(f"Page {p} out of range 1..{total_pages}")

        name_lookup: dict[int, str] = {}
        if cv_info:
            for item in cv_info:
                name_lookup[item['slide']] = File.sanitize_filename(item.get('name', 'Unknown'))

        sorted_page_nums = sorted(page_numbers)
        result_files: dict[int, str] = {}

        for original_num in sorted_page_nums:
            if dest_paths and original_num in dest_paths:
                output_file = dest_paths[original_num]
            elif output_folder:
                filename = (
                    f"{name_lookup[original_num]}.pdf"
                    if original_num in name_lookup
                    else f"page_{original_num}.pdf"
                )
                output_file = os.path.join(output_folder, filename)
            else:
                pdf_doc.close()
                raise ValueError("Either dest_paths or output_folder is required")

            os.makedirs(os.path.dirname(output_file), exist_ok=True)
            single = fitz.open()
            single.insert_pdf(pdf_doc, from_page=original_num - 1, to_page=original_num - 1)
            single.save(output_file)
            single.close()
            result_files[original_num] = output_file

        pdf_doc.close()
        return result_files

    @staticmethod
    def pdf_to_markdown(pdf_path: Path, md_path: Path) -> tuple[bool, str]:
        """Convert a PDF to a markdown file with page headers."""
        try:
            doc = fitz.open(pdf_path)
            lines = []

            for i, page in enumerate(doc, start=1):
                lines.append(f"\n## Page {i}\n")

                text = page.get_text()
                paragraphs = [p.strip() for p in text.split('\n') if p.strip()]

                for paragraph in paragraphs:
                    lines.append(f"{paragraph}\n\n")

            doc.close()
            md_path.write_text("".join(lines), encoding="utf-8")
            return True, ""
        except Exception as e:
            return False, str(e)
