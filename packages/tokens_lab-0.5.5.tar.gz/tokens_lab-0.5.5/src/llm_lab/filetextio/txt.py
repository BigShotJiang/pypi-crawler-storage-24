"""Plain text file reading."""

from __future__ import annotations

from pathlib import Path

from llm_lab.exceptions import ParseError

from .base import File


class Txt(File):
    """Plain text file reader."""

    def read_file(self) -> str:
        """Read plain text files safely with UTF-8 and ignore errors."""
        try:
            return Path(self.path).read_text(encoding="utf-8", errors="ignore")
        except Exception as exc:
            raise ParseError(f"Failed to read TXT: {self.path}") from exc
