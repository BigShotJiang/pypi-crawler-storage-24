"""Parser registry, file format detection, and convenience loaders."""

from __future__ import annotations

import mimetypes
from pathlib import Path

from llm_lab.exceptions import UnsupportedFileTypeError

from .base import File, PathLike
from .docx import Docx
from .pdf import Pdf
from .pptx import Pptx
from .txt import Txt

_PARSER_REGISTRY: dict[str, type[File]] = {
    ".pdf": Pdf,
    ".docx": Docx,
    ".pptx": Pptx,
    ".txt": Txt,
}

_SUPPORTED_EXTENSIONS = set(_PARSER_REGISTRY.keys())

_MIME_TO_EXT: dict[str, str] = {
    "application/pdf": ".pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation": ".pptx",
}


def detect_file_format(path: PathLike, prefer_mime: bool = True) -> str:
    """Detect file format via MIME type or suffix. Returns extension like ".pdf" or ""."""
    p = Path(path)
    ext = p.suffix.lower()

    if prefer_mime:
        mime, _ = mimetypes.guess_type(str(p))
        if mime in _MIME_TO_EXT:
            return _MIME_TO_EXT[mime]
        if mime and mime.startswith("text/"):
            return ".txt"

    return ext if ext in _SUPPORTED_EXTENSIONS else ""


def get_parser_for(path: PathLike) -> File:
    """Return a parser instance for the given file path."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"File not found: {p}")
    if p.is_dir():
        raise IsADirectoryError(f"Path is a directory, expected file: {p}")

    ext = detect_file_format(p)
    cls = _PARSER_REGISTRY.get(ext)
    if not cls:
        raise UnsupportedFileTypeError(f"Unsupported file type: {ext or 'unknown'}")
    return cls(str(p))


def load_text(path: PathLike) -> str:
    """Parse and return text for any supported file."""
    return get_parser_for(path).read_file()


def get_supported_types() -> list[str]:
    """Return the list of supported file extensions."""
    return sorted(_SUPPORTED_EXTENSIONS)


def is_supported_file(path: PathLike) -> bool:
    """Check whether the given file path is a supported format."""
    try:
        p = Path(path)
        if not p.exists() or p.is_dir():
            return False
        return detect_file_format(p) in _SUPPORTED_EXTENSIONS
    except Exception:
        return False
