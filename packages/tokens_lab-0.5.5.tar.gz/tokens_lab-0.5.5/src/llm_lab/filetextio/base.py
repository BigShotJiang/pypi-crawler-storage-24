"""Abstract base class for file parsers."""

from __future__ import annotations

import re
from abc import ABC, abstractmethod
from pathlib import Path

PathLike = str | Path


class File(ABC):
    """Base class for file parsers.

    Subclasses must implement read_file() to extract text.
    """

    def __init__(self, path: PathLike):
        self.path = str(path)

    @abstractmethod
    def read_file(self) -> str:
        """Extract text from file."""
        ...
    
    @staticmethod
    def sanitize_filename(name: str) -> str:
        sanitized = re.sub(r'[<>:"/\\|?*]', '_', name)
        sanitized = re.sub(r'[\s_]+', '_', sanitized)
        sanitized = sanitized.strip('_')
        if len(sanitized) > 50:
            sanitized = sanitized[:50].rstrip('_')
        if not sanitized:
            sanitized = "Unknown"
        return sanitized
