from reflex_pdf.apps.event_test_client import post_pdf_url_event


class DummyClient:
    def __init__(self):
        self.calls = []

    def connect(self, *args, **kwargs):
        self.calls.append(("connect", args, kwargs))

    def emit(self, *args, **kwargs):
        self.calls.append(("emit", args, kwargs))

    def disconnect(self):
        self.calls.append(("disconnect", (), {}))


def test_post_pdf_url_event_posts_reflex_event(monkeypatch):
    dummy = DummyClient()
    monkeypatch.setattr(
        "reflex_pdf.apps.event_test_client.socketio.SimpleClient", lambda: dummy
    )

    post_pdf_url_event("http://127.0.0.1:3000", "https://example.com/test.pdf", token="abc")

    connect_call = dummy.calls[0]
    emit_call = dummy.calls[1]
    disconnect_call = dummy.calls[2]

    assert connect_call[0] == "connect"
    assert connect_call[1][0] == "http://127.0.0.1:3000?token=abc"
    assert connect_call[2]["namespace"] == "/_event"
    assert connect_call[2]["socketio_path"] == "/_event/socket.io"

    assert emit_call[0] == "emit"
    assert emit_call[1][0] == "event"
    payload = emit_call[1][1]
    assert payload["token"] == "abc"
    assert payload["name"].endswith(".set_pdf_url")
    assert payload["payload"] == {"url": "https://example.com/test.pdf"}

    assert disconnect_call[0] == "disconnect"
