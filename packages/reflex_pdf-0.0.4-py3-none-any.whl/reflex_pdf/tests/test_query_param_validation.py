from urllib.parse import quote

from reflex_pdf.apps.viewer import QUERY_PARAM_WARNING, validate_pdf_query

RAW_PDF_URL = "https://example.com/file.pdf?token=abc&download=1"
RAW_QUERY = f"?pdf={RAW_PDF_URL}"


def test_validate_pdf_query_rejects_multiple_params_for_unencoded_url():
    pdf_url, warning = validate_pdf_query(RAW_QUERY)

    assert pdf_url == ""
    assert warning == QUERY_PARAM_WARNING


def test_validate_pdf_query_accepts_encoded_pdf_url_with_internal_query_params():
    encoded = f"?pdf={quote(RAW_PDF_URL, safe='')}"
    pdf_url, warning = validate_pdf_query(encoded)

    assert pdf_url == RAW_PDF_URL
    assert warning == ""
