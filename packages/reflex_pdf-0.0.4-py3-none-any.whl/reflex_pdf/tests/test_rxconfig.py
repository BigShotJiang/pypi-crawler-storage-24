from reflex_pdf.apps.rxconfig import config


def test_frontend_packages_include_tslib():
    assert "tslib" in config.frontend_packages
