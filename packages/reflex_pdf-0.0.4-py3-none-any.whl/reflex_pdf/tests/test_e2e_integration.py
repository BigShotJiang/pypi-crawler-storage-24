import queue
import socket
import threading
import time

import pytest

from reflex_pdf.apps.event_test_client import post_pdf_url_event

uvicorn = pytest.importorskip("uvicorn")


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


def _wait_for_port(port: int, timeout: float = 5.0) -> None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(0.2)
            if sock.connect_ex(("127.0.0.1", port)) == 0:
                return
        time.sleep(0.05)
    raise TimeoutError(f"Timed out waiting for port {port}")


def test_post_pdf_url_event_end_to_end():
    import socketio

    received: queue.Queue[dict] = queue.Queue()

    sio = socketio.AsyncServer(async_mode="asgi", cors_allowed_origins="*")

    @sio.on("event", namespace="/_event")
    async def handle_event(_sid, data):
        received.put(data)

    app = socketio.ASGIApp(sio, socketio_path="/_event/socket.io")
    port = _free_port()
    config = uvicorn.Config(app, host="127.0.0.1", port=port, log_level="error")
    server = uvicorn.Server(config)
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()

    try:
        _wait_for_port(port)
        pdf_url = "https://example.com/end-to-end.pdf"
        token = "e2e-token"

        post_pdf_url_event(f"http://127.0.0.1:{port}", pdf_url, token=token)

        payload = received.get(timeout=5)
        assert payload["token"] == token
        assert payload["payload"] == {"url": pdf_url}
        assert payload["name"].endswith(".set_pdf_url")
    finally:
        server.should_exit = True
        thread.join(timeout=5)
