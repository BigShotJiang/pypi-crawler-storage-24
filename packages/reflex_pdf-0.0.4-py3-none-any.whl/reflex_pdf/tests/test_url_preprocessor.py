from reflex_pdf.apps.url_preprocessor import (
    IdentityUrlPreprocessor,
    UrlPreprocessor,
    preprocess_pdf_url,
    set_url_preprocess_hook,
    set_url_preprocessor,
)
from reflex_pdf.apps.viewer import normalize_pdf_url


class PrefixPreprocessor(UrlPreprocessor):
    def preprocess(self, url: str) -> str:
        return f"prefix:{url}"


def teardown_function(_function):
    set_url_preprocess_hook(None)


def test_preprocess_pdf_url_uses_default_identity_behavior():
    assert preprocess_pdf_url("https://example.com/file.pdf") == "https://example.com/file.pdf"


def test_set_url_preprocessor_accepts_abc_implementations():
    set_url_preprocessor(PrefixPreprocessor())

    assert preprocess_pdf_url("https://example.com/file.pdf") == "prefix:https://example.com/file.pdf"


def test_set_url_preprocess_hook_transforms_url():
    set_url_preprocess_hook(lambda url: url.replace("http://", "https://"))

    assert preprocess_pdf_url("http://example.com/file.pdf") == "https://example.com/file.pdf"


def test_normalize_pdf_url_applies_strip_then_hook():
    set_url_preprocess_hook(lambda url: f"sanitized:{url}")

    assert normalize_pdf_url("  https://example.com/file.pdf  ") == "sanitized:https://example.com/file.pdf"


def test_reset_hook_restores_identity_behavior():
    set_url_preprocess_hook(lambda url: f"x:{url}")
    set_url_preprocess_hook(None)

    assert preprocess_pdf_url("https://example.com/file.pdf") == "https://example.com/file.pdf"
    assert isinstance(IdentityUrlPreprocessor(), UrlPreprocessor)
