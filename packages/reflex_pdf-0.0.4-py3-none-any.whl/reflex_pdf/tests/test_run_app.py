import os
from contextlib import contextmanager

import pytest

from reflex_pdf.apps import run_app


@pytest.fixture(params=[False, True], ids=["bun-default", "npm-enabled"])
def reflex_use_npm(monkeypatch, request):
    if request.param:
        monkeypatch.setenv("REFLEX_USE_NPM", "true")
    else:
        monkeypatch.delenv("REFLEX_USE_NPM", raising=False)
    return request.param


def test_main_uses_apps_directory_as_cwd(monkeypatch, tmp_path, reflex_use_npm):
    captured: dict[str, object] = {}

    monkeypatch.setattr(run_app, "runtime_base_dir", lambda: tmp_path)
    monkeypatch.setattr(
        run_app,
        "build_runtime_env",
        lambda _base: {"REFLEX_DIR": str(tmp_path / "reflex"), "PATH": ""},
    )
    monkeypatch.setattr(run_app, "ensure_bun", lambda _path: None)
    monkeypatch.setattr(run_app, "ensure_node", lambda _base, env, _min: env)
    def fake_reflex_cli(*args, **kwargs):
        captured["reflex_args"] = kwargs.get("args")

    monkeypatch.setattr(run_app, "reflex_cli", fake_reflex_cli)
    monkeypatch.setattr(run_app, "resolve_run_mode", lambda: "dev")
    monkeypatch.setattr(run_app, "resolve_transport", lambda: "polling")
    monkeypatch.setattr(run_app, "resolve_reflex_ports", lambda: (3000, 8000))

    @contextmanager
    def fake_scoped_process_context(env, cwd):
        captured["env"] = env
        captured["cwd"] = cwd
        yield

    monkeypatch.setattr(run_app, "scoped_process_context", fake_scoped_process_context)

    run_app.main()

    assert captured["cwd"] == run_app.app_dir()
    assert captured["env"]["REFLEX_TRANSPORT"] == "polling"
    assert captured["reflex_args"] == [
        "run",
        "--frontend-port",
        "3000",
        "--backend-port",
        "8000",
        "--backend-host",
        "0.0.0.0",
    ]
    assert (run_app.app_dir() / "rxconfig.py").exists()

def test_main_uses_single_port_in_prod_mode(monkeypatch, tmp_path, reflex_use_npm):
    captured: dict[str, object] = {}

    monkeypatch.setattr(run_app, "runtime_base_dir", lambda: tmp_path)
    monkeypatch.setattr(
        run_app,
        "build_runtime_env",
        lambda _base: {"REFLEX_DIR": str(tmp_path / "reflex"), "PATH": ""},
    )
    monkeypatch.setattr(run_app, "ensure_bun", lambda _path: None)
    monkeypatch.setattr(run_app, "ensure_node", lambda _base, env, _min: env)
    monkeypatch.setattr(run_app, "resolve_run_mode", lambda: "prod-single-port")
    monkeypatch.setattr(run_app, "resolve_transport", lambda: "polling")
    monkeypatch.setattr(run_app, "resolve_single_port", lambda: 3000)

    def fake_reflex_cli(*args, **kwargs):
        captured["reflex_args"] = kwargs.get("args")

    monkeypatch.setattr(run_app, "reflex_cli", fake_reflex_cli)

    @contextmanager
    def fake_scoped_process_context(env, cwd):
        captured["env"] = env
        captured["cwd"] = cwd
        yield

    monkeypatch.setattr(run_app, "scoped_process_context", fake_scoped_process_context)

    run_app.main()

    assert captured["cwd"] == run_app.app_dir()
    assert captured["reflex_args"] == [
        "run",
        "--env",
        "prod",
        "--single-port",
        "--frontend-port",
        "3000",
        "--backend-port",
        "3000",
        "--backend-host",
        "0.0.0.0",
    ]

def test_main_fails_when_frontend_and_backend_port_match(monkeypatch):
    monkeypatch.setenv("REFLEX_FRONTEND_PORT", "3000")
    monkeypatch.setenv("REFLEX_BACKEND_PORT", "3000")

    try:
        run_app.resolve_reflex_ports()
    except ValueError as exc:
        assert "must be different" in str(exc)
    else:
        raise AssertionError("Expected ValueError for matching frontend/backend ports")

def test_main_setup_only_skips_port_resolution(monkeypatch, tmp_path, reflex_use_npm):
    monkeypatch.setattr(run_app, "runtime_base_dir", lambda: tmp_path)
    monkeypatch.setattr(
        run_app,
        "build_runtime_env",
        lambda _base: {"REFLEX_DIR": str(tmp_path / "reflex"), "PATH": ""},
    )
    monkeypatch.setattr(run_app, "ensure_bun", lambda _path: None)
    monkeypatch.setattr(run_app, "ensure_node", lambda _base, env, _min: env)
    monkeypatch.setattr(run_app, "resolve_transport", lambda: "polling")
    monkeypatch.setattr(
        run_app,
        "resolve_reflex_ports",
        lambda: (_ for _ in ()).throw(AssertionError("should not resolve ports")),
    )
    monkeypatch.setattr(
        run_app,
        "reflex_cli",
        lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError("should not run app")),
    )

    run_app.main(setup_only=True)

def test_prebuild_compiles_app_artifacts(monkeypatch, tmp_path, reflex_use_npm):
    captured: dict[str, object] = {"reflex_calls": []}

    monkeypatch.setattr(run_app, "runtime_base_dir", lambda: tmp_path)
    monkeypatch.setattr(
        run_app,
        "build_runtime_env",
        lambda _base: {
            "REFLEX_DIR": str(tmp_path / "reflex"),
            "REFLEX_WEB_WORKDIR": str(tmp_path / "web"),
            "PATH": "",
        },
    )
    monkeypatch.setattr(run_app, "ensure_bun", lambda _path: None)
    monkeypatch.setattr(run_app, "ensure_node", lambda _base, env, _min: env)
    monkeypatch.setattr(run_app, "resolve_run_mode", lambda: "dev")
    monkeypatch.setattr(run_app, "resolve_transport", lambda: "polling")

    def fake_reflex_cli(*args, **kwargs):
        captured["reflex_calls"].append(kwargs.get("args"))

    monkeypatch.setattr(run_app, "reflex_cli", fake_reflex_cli)

    @contextmanager
    def fake_scoped_process_context(env, cwd):
        captured["env"] = env
        captured["cwd"] = cwd
        yield

    monkeypatch.setattr(run_app, "scoped_process_context", fake_scoped_process_context)

    run_app.prebuild()

    assert captured["cwd"] == run_app.app_dir()
    assert captured["env"]["REFLEX_TRANSPORT"] == "polling"
    assert captured["reflex_calls"] == [["init"], ["export", "--no-zip"]]


def test_prebuild_uses_prod_node_version_in_prod_single_port_mode(monkeypatch, tmp_path, reflex_use_npm):
    captured: dict[str, object] = {"bun_called": False}

    monkeypatch.setattr(run_app, "runtime_base_dir", lambda: tmp_path)
    monkeypatch.setattr(
        run_app,
        "build_runtime_env",
        lambda _base: {"REFLEX_DIR": str(tmp_path / "reflex"), "PATH": ""},
    )
    monkeypatch.setattr(run_app, "resolve_run_mode", lambda: "prod-single-port")
    monkeypatch.setattr(run_app, "resolve_transport", lambda: "polling")

    def fake_ensure_bun(_path):
        captured["bun_called"] = True

    monkeypatch.setattr(run_app, "ensure_bun", fake_ensure_bun)

    def fake_ensure_node(_base, env, minimum_version):
        captured["node_minimum_version"] = minimum_version
        return env

    monkeypatch.setattr(run_app, "ensure_node", fake_ensure_node)
    monkeypatch.setattr(run_app, "ensure_npm_runtime_dependencies", lambda _env: None)
    monkeypatch.setattr(run_app, "reflex_cli", lambda *args, **kwargs: None)

    @contextmanager
    def fake_scoped_process_context(env, cwd):
        captured["env"] = env
        captured["cwd"] = cwd
        yield

    monkeypatch.setattr(run_app, "scoped_process_context", fake_scoped_process_context)

    run_app.prebuild()

    assert captured["bun_called"] is (not reflex_use_npm)
    assert captured["node_minimum_version"] == run_app.MIN_NODE_VERSION_PROD_SINGLE_PORT
    assert captured["env"]["REFLEX_TRANSPORT"] == "polling"
    assert captured["cwd"] == run_app.app_dir()


def test_prebuild_skips_bun_when_reflex_use_npm_true(monkeypatch, tmp_path):
    called = {"bun": False}

    monkeypatch.setenv("REFLEX_USE_NPM", "true")
    monkeypatch.setattr(run_app, "runtime_base_dir", lambda: tmp_path)
    monkeypatch.setattr(
        run_app,
        "build_runtime_env",
        lambda _base: {"REFLEX_DIR": str(tmp_path / "reflex"), "PATH": ""},
    )

    def fake_ensure_bun(_path):
        called["bun"] = True

    monkeypatch.setattr(run_app, "ensure_bun", fake_ensure_bun)
    monkeypatch.setattr(run_app, "ensure_node", lambda _base, env, _min: env)
    monkeypatch.setattr(run_app, "resolve_run_mode", lambda: "dev")
    monkeypatch.setattr(run_app, "resolve_transport", lambda: "polling")
    monkeypatch.setattr(run_app, "reflex_cli", lambda *args, **kwargs: None)

    run_app.prebuild()

    assert called["bun"] is False

def test_should_use_bun_respects_reflex_use_npm(monkeypatch):
    monkeypatch.delenv("REFLEX_USE_NPM", raising=False)
    assert run_app.should_use_bun() is True

    monkeypatch.setenv("REFLEX_USE_NPM", "true")
    assert run_app.should_use_bun() is False

    monkeypatch.setenv("REFLEX_USE_NPM", "TRUE")
    assert run_app.should_use_bun() is False

def test_main_skips_bun_when_reflex_use_npm_true(monkeypatch, tmp_path):
    called = {"bun": False}

    monkeypatch.setenv("REFLEX_USE_NPM", "true")
    monkeypatch.setattr(run_app, "runtime_base_dir", lambda: tmp_path)
    monkeypatch.setattr(
        run_app,
        "build_runtime_env",
        lambda _base: {"REFLEX_DIR": str(tmp_path / "reflex"), "PATH": ""},
    )

    def fake_ensure_bun(_path):
        called["bun"] = True

    monkeypatch.setattr(run_app, "ensure_bun", fake_ensure_bun)
    monkeypatch.setattr(run_app, "ensure_node", lambda _base, env, _min: env)
    monkeypatch.setattr(run_app, "resolve_transport", lambda: "polling")

    run_app.main(setup_only=True)

    assert called["bun"] is False

def test_resolve_run_mode_defaults_to_prod_single_port_in_codespaces(monkeypatch):
    monkeypatch.delenv("REFLEX_RUN_MODE", raising=False)
    monkeypatch.setenv("CODESPACES", "true")

    assert run_app.resolve_run_mode() == "prod-single-port"

def test_resolve_run_mode_accepts_explicit_dev(monkeypatch):
    monkeypatch.setenv("REFLEX_RUN_MODE", "dev")
    monkeypatch.setenv("CODESPACES", "true")

    assert run_app.resolve_run_mode() == "dev"

def test_resolve_transport_defaults_to_polling_in_codespaces(monkeypatch):
    monkeypatch.delenv("REFLEX_TRANSPORT", raising=False)
    monkeypatch.setenv("CODESPACES", "true")

    assert run_app.resolve_transport() == "polling"

def test_resolve_transport_defaults_to_websocket_outside_codespaces(monkeypatch):
    monkeypatch.delenv("REFLEX_TRANSPORT", raising=False)
    monkeypatch.delenv("CODESPACES", raising=False)

    assert run_app.resolve_transport() == "websocket"



def test_build_runtime_env_sets_npm_optional_dependency_flags(tmp_path, monkeypatch):
    monkeypatch.delenv("NPM_CONFIG_INCLUDE", raising=False)
    monkeypatch.delenv("NPM_CONFIG_OPTIONAL", raising=False)

    env = run_app.build_runtime_env(tmp_path)

    assert "NPM_CONFIG_INCLUDE" not in env
    assert env["NPM_CONFIG_OPTIONAL"] == "true"


def test_build_runtime_env_drops_include_when_optional_missing(tmp_path, monkeypatch):
    monkeypatch.setenv("NPM_CONFIG_INCLUDE", "prod")

    env = run_app.build_runtime_env(tmp_path)

    assert "NPM_CONFIG_INCLUDE" not in env


def test_build_runtime_env_keeps_include_when_optional_present(tmp_path, monkeypatch):
    monkeypatch.setenv("NPM_CONFIG_INCLUDE", "optional")

    env = run_app.build_runtime_env(tmp_path)

    assert env["NPM_CONFIG_INCLUDE"] == "optional"


def test_build_runtime_env_removes_optional_from_omit(tmp_path, monkeypatch):
    monkeypatch.setenv("NPM_CONFIG_OMIT", "dev,optional")

    env = run_app.build_runtime_env(tmp_path)

    assert env["NPM_CONFIG_OMIT"] == "dev"


def test_build_runtime_env_clears_omit_if_only_optional(tmp_path, monkeypatch):
    monkeypatch.setenv("NPM_CONFIG_OMIT", "optional")

    env = run_app.build_runtime_env(tmp_path)

    assert "NPM_CONFIG_OMIT" not in env


def test_ensure_npm_runtime_dependencies_installs_tslib_when_missing(monkeypatch, tmp_path):
    web_dir = tmp_path / "web"
    web_dir.mkdir(parents=True, exist_ok=True)
    (web_dir / "package.json").write_text("{}")

    env = {"REFLEX_WEB_WORKDIR": str(web_dir), "PATH": ""}
    called: dict[str, object] = {}

    monkeypatch.setattr(run_app, "should_use_bun", lambda: False)

    def fake_run(cmd, env=None, cwd=None):
        called["cmd"] = cmd
        called["env"] = env
        called["cwd"] = cwd

    monkeypatch.setattr(run_app, "run", fake_run)

    run_app.ensure_npm_runtime_dependencies(env)

    assert called["cmd"] == [
        "npm",
        "install",
        "--legacy-peer-deps",
        "--include=optional",
        "tslib",
    ]
    assert called["env"] == env
    assert called["cwd"] == web_dir


def test_ensure_npm_runtime_dependencies_skips_when_tslib_exists(monkeypatch, tmp_path):
    web_dir = tmp_path / "web"
    (web_dir / "node_modules" / "tslib").mkdir(parents=True, exist_ok=True)
    (web_dir / "package.json").write_text("{}")

    env = {"REFLEX_WEB_WORKDIR": str(web_dir), "PATH": ""}

    monkeypatch.setattr(run_app, "should_use_bun", lambda: False)
    monkeypatch.setattr(
        run_app,
        "run",
        lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError("should not install")),
    )

    run_app.ensure_npm_runtime_dependencies(env)


def test_prebuild_reproduces_binding_error_without_optional_env_hardening(monkeypatch, tmp_path):
    monkeypatch.setenv("REFLEX_USE_NPM", "true")
    monkeypatch.setenv("NPM_CONFIG_OPTIONAL", "false")
    monkeypatch.setenv("NPM_CONFIG_OMIT", "optional")
    monkeypatch.setenv("NPM_CONFIG_INCLUDE", "prod")

    monkeypatch.setattr(run_app, "runtime_base_dir", lambda: tmp_path)

    def legacy_build_runtime_env(_base):
        return {
            "REFLEX_DIR": str(tmp_path / "reflex"),
            "REFLEX_WEB_WORKDIR": str(tmp_path / "web"),
            "REFLEX_STATES_WORKDIR": str(tmp_path / "states"),
            "PATH": "",
            "NPM_CONFIG_OPTIONAL": "false",
            "NPM_CONFIG_OMIT": "optional",
            "NPM_CONFIG_INCLUDE": "prod",
        }

    monkeypatch.setattr(run_app, "build_runtime_env", legacy_build_runtime_env)
    monkeypatch.setattr(run_app, "ensure_bun", lambda _path: None)
    monkeypatch.setattr(run_app, "ensure_node", lambda _base, env, _min: env)
    monkeypatch.setattr(run_app, "resolve_run_mode", lambda: "dev")
    monkeypatch.setattr(run_app, "resolve_transport", lambda: "polling")

    def fake_reflex_cli(*, args, standalone_mode):
        if args == ["export", "--no-zip"] and os.environ.get("NPM_CONFIG_OPTIONAL") != "true":
            raise RuntimeError("Cannot find module '@rolldown/binding-linux-x64-gnu'")

    monkeypatch.setattr(run_app, "reflex_cli", fake_reflex_cli)

    with pytest.raises(RuntimeError, match="@rolldown/binding-linux-x64-gnu"):
        run_app.prebuild()


def test_prebuild_reproduces_tslib_error_without_runtime_dependency_step(monkeypatch, tmp_path):
    monkeypatch.setenv("REFLEX_USE_NPM", "true")
    monkeypatch.setattr(run_app, "runtime_base_dir", lambda: tmp_path)
    monkeypatch.setattr(
        run_app,
        "build_runtime_env",
        lambda _base: {
            "REFLEX_DIR": str(tmp_path / "reflex"),
            "REFLEX_WEB_WORKDIR": str(tmp_path / "web"),
            "REFLEX_STATES_WORKDIR": str(tmp_path / "states"),
            "PATH": "",
        },
    )
    monkeypatch.setattr(run_app, "ensure_bun", lambda _path: None)
    monkeypatch.setattr(run_app, "ensure_node", lambda _base, env, _min: env)
    monkeypatch.setattr(run_app, "resolve_run_mode", lambda: "dev")
    monkeypatch.setattr(run_app, "resolve_transport", lambda: "polling")
    monkeypatch.setattr(run_app, "ensure_npm_runtime_dependencies", lambda _env: None)

    def fake_reflex_cli(*, args, standalone_mode):
        if args == ["export", "--no-zip"]:
            raise RuntimeError('Rolldown failed to resolve import "tslib"')

    monkeypatch.setattr(run_app, "reflex_cli", fake_reflex_cli)

    with pytest.raises(RuntimeError, match='resolve import "tslib"'):
        run_app.prebuild()
