import reflex as rx

config = rx.Config(
    app_name="viewer",
    app_module_import="viewer",
    show_built_with_reflex=False,
    frontend_packages=["tslib"],
)
