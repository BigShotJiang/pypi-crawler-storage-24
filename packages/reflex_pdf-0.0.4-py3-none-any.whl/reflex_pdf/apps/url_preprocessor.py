"""URL preprocessing primitives for PDF URLs."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Callable

UrlPreprocessHook = Callable[[str], str]


class UrlPreprocessor(ABC):
    """ABC contract for URL preprocessors."""

    @abstractmethod
    def preprocess(self, url: str) -> str:
        """Preprocess a PDF URL and return the transformed value."""


class IdentityUrlPreprocessor(UrlPreprocessor):
    """Default no-op URL preprocessor."""

    def preprocess(self, url: str) -> str:
        return url


class HookUrlPreprocessor(UrlPreprocessor):
    """Adapter that exposes a plain callable as a ``UrlPreprocessor``."""

    def __init__(self, hook: UrlPreprocessHook):
        self._hook = hook

    def preprocess(self, url: str) -> str:
        return self._hook(url)


_url_preprocessor: UrlPreprocessor = IdentityUrlPreprocessor()


def set_url_preprocessor(preprocessor: UrlPreprocessor) -> None:
    """Set the process-wide URL preprocessor implementation."""
    global _url_preprocessor
    _url_preprocessor = preprocessor


def set_url_preprocess_hook(hook: UrlPreprocessHook | None) -> None:
    """Register a simple preprocessing hook.

    Passing ``None`` resets preprocessing to the default no-op behavior.
    """
    if hook is None:
        set_url_preprocessor(IdentityUrlPreprocessor())
        return
    set_url_preprocessor(HookUrlPreprocessor(hook))


def preprocess_pdf_url(url: str) -> str:
    """Run configured preprocessing for a PDF URL."""
    return _url_preprocessor.preprocess(url)
