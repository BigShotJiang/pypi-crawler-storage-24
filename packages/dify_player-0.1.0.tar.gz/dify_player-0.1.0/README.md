# dify-player

最小構成の Dify workflow ランナーです。  
現在は strict plan JSON の実行、最小 Dify YAML の import、Python からの async ライブラリ利用をサポートしています。

## Setup

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
```

## Library Usage

### Quick Start

ライブラリとして使う場合は `WorkflowEngine` を利用します。  
`run_plan_data(...)` は strict plan JSON 相当の dict をそのまま受け取れます。

```python
from dify_player import WorkflowEngine
from dify_player.models import to_data

engine = WorkflowEngine()

result = await engine.run_plan_data(
    plan_data=plan_data,
    inputs=inputs,
)

if result.status == "succeeded":
    print(result.outputs)
else:
    print(result.error.code, result.error.message)

payload = to_data(result)
```

返り値は `RunResult` です。`result.outputs`、`result.error`、`result.nodes` に実行結果が入ります。  
HTTP レスポンスや JSON 化が必要な場合は `dify_player.models.to_data(...)` を使って dict に変換できます。

### FastAPI Example

FastAPI から呼ぶ場合は、アプリ lifespan で `httpx.AsyncClient` を 1 つ持ち、`WorkflowEngine` に注入するのが扱いやすいです。

```python
import httpx
from fastapi import FastAPI, HTTPException

from dify_player import WorkflowEngine
from dify_player.exceptions import PlanValidationError
from dify_player.models import to_data

app = FastAPI()
engine = WorkflowEngine()


@app.on_event("startup")
async def startup() -> None:
    app.state.http_client = httpx.AsyncClient()


@app.on_event("shutdown")
async def shutdown() -> None:
    await app.state.http_client.aclose()


@app.post("/workflow/run")
async def run_workflow(payload: dict) -> dict:
    try:
        result = await engine.run_plan_data(
            plan_data=payload["plan"],
            inputs=payload["inputs"],
            http_client=app.state.http_client,
        )
    except PlanValidationError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    return to_data(result)
```

### Public Interface

`WorkflowEngine` には次の async API があります。

- `await engine.run_plan_data(plan_data=..., inputs=..., run_id=None, logger=None, http_client=None)`
- `await engine.run_plan(plan=..., inputs=..., run_id=None, logger=None, http_client=None)`
- `await engine.run_compiled_plan(compiled_plan=..., inputs=..., run_id=None, logger=None, http_client=None)`

使い分けは次のとおりです。

- `run_plan_data`: Web API や JSON 入力から直接呼ぶ用途向け
- `run_plan`: すでに `Plan` オブジェクトを組み立てている内部利用向け
- `run_compiled_plan`: 同じ plan を何度も実行する用途向け

### Logger And HTTP Client

`logger` を渡さない場合、ライブラリ利用時はファイルログを書きません。  
必要なら `run_id`, `log(...)`, `close()` を持つ logger を渡せます。

`http_client` は任意です。

- 渡した場合: 呼び出し側が所有し、このライブラリでは close しません
- 渡さない場合: 実行ごとに内部で `httpx.AsyncClient` を生成して close します

### Validation Behavior

`run_plan_data(...)` は `plan_data` を `Plan` に変換する段階で `PlanValidationError` を送出することがあります。  
一方、実行フェーズの失敗は `RunResult(status="failed")` として返ります。

## CLI

### Run

手書きまたは import 済みの strict plan JSON を実行します。

`plan.nodes[].name` は任意です。指定するとエラー表示とイベントログに `name [id]` 形式で出るため、Dify のどのノードか追いやすくなります。

```bash
python -m dify_player run examples/hello/plan.json examples/hello/input.json
```

ログを明示したい場合は `--log` を使います。

```bash
python -m dify_player run examples/hello/plan.json examples/hello/input.json --log logs/run.jsonl
```

### Import

最小 Dify workflow YAML を strict plan JSON に変換します。

```bash
python -m dify_player import workflows/test_http_saas.yml output/plan.json
```

生成された `plan.json` は、そのまま `run` で実行できます。

## Test HTTP Server

HTTP ノードの確認用に、固定ポート `18080` のローカルサーバを起動できます。

```bash
python scripts/http_test_server.py
```

このサーバは `GET /json`, `GET /slow`, `GET /not-found`, `POST /echo` を返します。
