from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import Any

import httpx
from dify_player.event_logger import WorkflowLogger
from dify_player.exceptions import (
    AzureLLMBadStatusError,
    AzureLLMRequestFailedError,
    AzureLLMStructuredOutputError,
    HTTPBadStatusError,
    HTTPRequestFailedError,
    PlanValidationError,
    UnsupportedNodeError,
)
from dify_player.input_resolver import resolve_node_inputs
from dify_player.models import CompiledLoop, CompiledPlan, Edge, Node, NodeResult, RunResult, RunState, WorkflowError
from dify_player.nodes import run_node


class WorkflowRuntime:
    def __init__(self, logger: WorkflowLogger) -> None:
        self.logger = logger

    async def run(
        self,
        compiled_plan: CompiledPlan,
        inputs: dict[str, Any],
        *,
        started_at: str | None = None,
        started_monotonic: float | None = None,
        http_client: httpx.AsyncClient | None = None,
    ) -> RunResult:
        effective_started_at = started_at or _utc_now()
        effective_started_monotonic = started_monotonic if started_monotonic is not None else time.monotonic()
        state = RunState(run_id=self.logger.run_id, inputs=inputs)
        effective_http_client = http_client if http_client is not None else httpx.AsyncClient()
        owns_http_client = http_client is None
        try:
            for node_id in compiled_plan.execution_order:
                node = compiled_plan.node_by_id[node_id]
                if not self._should_run_node(node=node, state=state, compiled_plan=compiled_plan):
                    self._mark_node_skipped(node=node, state=state)
                    continue
                error = await self._run_node(
                    node=node,
                    state=state,
                    compiled_plan=compiled_plan,
                    http_client=effective_http_client,
                )
                if error is not None:
                    return self._build_run_result(
                        state=state,
                        status="failed",
                        outputs=None,
                        error=error,
                        started_at=effective_started_at,
                        started_monotonic=effective_started_monotonic,
                    )
        finally:
            if owns_http_client:
                await effective_http_client.aclose()

        if compiled_plan.end_node_id not in state.node_outputs:
            return self._build_run_result(
                state=state,
                status="failed",
                outputs=None,
                error=WorkflowError(
                    code="INTERNAL_ERROR",
                    message=f"end node {compiled_plan.end_node_id!r} was not reached",
                    phase="runtime",
                    node_id=compiled_plan.end_node_id,
                    node_name=compiled_plan.node_by_id[compiled_plan.end_node_id].name,
                    retryable=False,
                ),
                started_at=effective_started_at,
                started_monotonic=effective_started_monotonic,
            )

        return self._build_run_result(
            state=state,
            status="succeeded",
            outputs=state.node_outputs[compiled_plan.end_node_id],
            error=None,
            started_at=effective_started_at,
            started_monotonic=effective_started_monotonic,
        )

    async def _run_node(
        self,
        node: Node,
        state: RunState,
        compiled_plan: CompiledPlan,
        http_client: httpx.AsyncClient,
    ) -> WorkflowError | None:
        node_started_at = _utc_now()
        node_started_monotonic = time.monotonic()
        node_result = NodeResult(
            node_id=node.id,
            node_name=node.name,
            kind=node.kind,
            status="running",
            started_at=node_started_at,
        )
        state.node_results[node.id] = node_result
        try:
            resolved_inputs = resolve_node_inputs(
                node,
                workflow_inputs=state.inputs,
                node_outputs=state.node_outputs,
            )
            node_result.resolved_inputs = resolved_inputs
        except Exception as exc:
            error = self._normalize_input_resolution_error(exc=exc, node=node)
            node_result.status = "failed"
            node_result.error = error
            node_result.finished_at = _utc_now()
            node_result.duration_ms = max(0, int((time.monotonic() - node_started_monotonic) * 1000))
            self.logger.log(
                "node_failed",
                node_id=node.id,
                node_name=node.name,
                kind=node.kind,
                status="failed",
                error=error.message,
                error_code=error.code,
                phase=error.phase,
                retryable=error.retryable,
            )
            return error

        self.logger.log(
            "node_started",
            node_id=node.id,
            node_name=node.name,
            kind=node.kind,
            status="running",
            resolved_inputs=resolved_inputs,
        )

        try:
            if node.kind == "loop":
                compiled_loop = compiled_plan.compiled_loops_by_node.get(node.id)
                if compiled_loop is None:
                    raise ValueError(f"compiled loop is missing for node {node.label!r}")
                output = await self._run_loop_node(
                    node=node,
                    compiled_loop=compiled_loop,
                    state=state,
                    http_client=http_client,
                )
            else:
                output = await run_node(
                    node=node,
                    workflow_inputs=state.inputs,
                    node_outputs=state.node_outputs,
                    resolved_inputs=resolved_inputs,
                    http_client=http_client,
                )
        except Exception as exc:
            error = self._normalize_node_execution_error(exc=exc, node=node)
            node_result.status = "failed"
            node_result.error = error
            node_result.finished_at = _utc_now()
            node_result.duration_ms = max(0, int((time.monotonic() - node_started_monotonic) * 1000))
            self.logger.log(
                "node_failed",
                node_id=node.id,
                node_name=node.name,
                kind=node.kind,
                status="failed",
                error=error.message,
                error_code=error.code,
                phase=error.phase,
                retryable=error.retryable,
            )
            return error

        state.node_outputs[node.id] = output
        node_result.status = "succeeded"
        node_result.outputs = output
        node_result.finished_at = _utc_now()
        node_result.duration_ms = max(0, int((time.monotonic() - node_started_monotonic) * 1000))
        self.logger.log(
            "node_succeeded",
            node_id=node.id,
            node_name=node.name,
            kind=node.kind,
            status="succeeded",
            output=output,
        )
        return None

    async def _run_loop_node(
        self,
        *,
        node: Node,
        compiled_loop: CompiledLoop,
        state: RunState,
        http_client: httpx.AsyncClient,
    ) -> dict[str, Any]:
        loop_variables = dict(compiled_loop.initial_loop_variables)

        for iteration in range(1, compiled_loop.max_iterations + 1):
            self.logger.log(
                "loop_iteration_started",
                node_id=node.id,
                node_name=node.name,
                kind=node.kind,
                status="running",
                loop_id=node.id,
                iteration=iteration,
                loop_variables=dict(loop_variables),
            )

            iteration_outputs: dict[str, dict[str, Any]] = {}
            iteration_results: dict[str, NodeResult] = {}
            broke = False
            for body_node_id in compiled_loop.execution_order:
                body_node = compiled_loop.node_by_id[body_node_id]
                if not self._should_run_loop_body_node(
                    body_node=body_node,
                    compiled_loop=compiled_loop,
                    iteration_results=iteration_results,
                    iteration_outputs=iteration_outputs,
                ):
                    continue

                error = await self._run_loop_body_node(
                    loop_node=node,
                    body_node=body_node,
                    state=state,
                    loop_variables=loop_variables,
                    iteration_outputs=iteration_outputs,
                    iteration_results=iteration_results,
                    iteration=iteration,
                    http_client=http_client,
                )
                if error is not None:
                    self.logger.log(
                        "loop_iteration_finished",
                        node_id=node.id,
                        node_name=node.name,
                        kind=node.kind,
                        status="failed",
                        loop_id=node.id,
                        iteration=iteration,
                        outcome="failed",
                        loop_variables=dict(loop_variables),
                    )
                    raise _LoopRuntimeError(error)

                if body_node.id in compiled_loop.break_node_ids:
                    self.logger.log(
                        "loop_iteration_finished",
                        node_id=node.id,
                        node_name=node.name,
                        kind=node.kind,
                        status="succeeded",
                        loop_id=node.id,
                        iteration=iteration,
                        outcome="break",
                        loop_variables=dict(loop_variables),
                    )
                    broke = True
                    break

            if broke:
                return loop_variables

            outcome = "continue"
            status = "running"
            if iteration == compiled_loop.max_iterations:
                outcome = "failed"
                status = "failed"
            self.logger.log(
                "loop_iteration_finished",
                node_id=node.id,
                node_name=node.name,
                kind=node.kind,
                status=status,
                loop_id=node.id,
                iteration=iteration,
                outcome=outcome,
                loop_variables=dict(loop_variables),
            )
            if outcome == "failed":
                raise ValueError(
                    f"loop node {node.label!r} reached max_iterations={compiled_loop.max_iterations} without hitting a break node"
                )

        raise ValueError(f"loop node {node.label!r} exited unexpectedly")

    async def _run_loop_body_node(
        self,
        *,
        loop_node: Node,
        body_node: Node,
        state: RunState,
        loop_variables: dict[str, Any],
        iteration_outputs: dict[str, dict[str, Any]],
        iteration_results: dict[str, NodeResult],
        iteration: int,
        http_client: httpx.AsyncClient,
    ) -> WorkflowError | None:
        node_started_at = _utc_now()
        node_started_monotonic = time.monotonic()
        node_result = NodeResult(
            node_id=body_node.id,
            node_name=body_node.name,
            kind=body_node.kind,
            status="running",
            started_at=node_started_at,
        )
        iteration_results[body_node.id] = node_result
        merged_node_outputs = self._build_loop_body_node_outputs(
            loop_node=loop_node,
            outer_node_outputs=state.node_outputs,
            loop_variables=loop_variables,
            iteration_outputs=iteration_outputs,
        )

        try:
            resolved_inputs = resolve_node_inputs(
                body_node,
                workflow_inputs=state.inputs,
                node_outputs=merged_node_outputs,
            )
            node_result.resolved_inputs = resolved_inputs
        except Exception as exc:
            error = self._normalize_input_resolution_error(exc=exc, node=body_node)
            node_result.status = "failed"
            node_result.error = error
            node_result.finished_at = _utc_now()
            node_result.duration_ms = max(0, int((time.monotonic() - node_started_monotonic) * 1000))
            self.logger.log(
                "node_failed",
                node_id=body_node.id,
                node_name=body_node.name,
                kind=body_node.kind,
                status="failed",
                error=error.message,
                error_code=error.code,
                phase=error.phase,
                retryable=error.retryable,
                loop_id=loop_node.id,
                iteration=iteration,
            )
            return error

        self.logger.log(
            "node_started",
            node_id=body_node.id,
            node_name=body_node.name,
            kind=body_node.kind,
            status="running",
            resolved_inputs=resolved_inputs,
            loop_id=loop_node.id,
            iteration=iteration,
        )

        try:
            output = await run_node(
                node=body_node,
                workflow_inputs=state.inputs,
                node_outputs=merged_node_outputs,
                resolved_inputs=resolved_inputs,
                http_client=http_client,
            )
        except Exception as exc:
            error = self._normalize_node_execution_error(exc=exc, node=body_node)
            node_result.status = "failed"
            node_result.error = error
            node_result.finished_at = _utc_now()
            node_result.duration_ms = max(0, int((time.monotonic() - node_started_monotonic) * 1000))
            self.logger.log(
                "node_failed",
                node_id=body_node.id,
                node_name=body_node.name,
                kind=body_node.kind,
                status="failed",
                error=error.message,
                error_code=error.code,
                phase=error.phase,
                retryable=error.retryable,
                loop_id=loop_node.id,
                iteration=iteration,
            )
            return error

        iteration_outputs[body_node.id] = output
        if body_node.kind == "assigner":
            loop_variables.update(output)
        node_result.status = "succeeded"
        node_result.outputs = output
        node_result.finished_at = _utc_now()
        node_result.duration_ms = max(0, int((time.monotonic() - node_started_monotonic) * 1000))
        self.logger.log(
            "node_succeeded",
            node_id=body_node.id,
            node_name=body_node.name,
            kind=body_node.kind,
            status="succeeded",
            output=output,
            loop_id=loop_node.id,
            iteration=iteration,
        )
        return None

    def _build_loop_body_node_outputs(
        self,
        *,
        loop_node: Node,
        outer_node_outputs: dict[str, dict[str, Any]],
        loop_variables: dict[str, Any],
        iteration_outputs: dict[str, dict[str, Any]],
    ) -> dict[str, dict[str, Any]]:
        merged = dict(outer_node_outputs)
        merged[loop_node.id] = dict(loop_variables)
        merged.update(iteration_outputs)
        return merged

    def _should_run_loop_body_node(
        self,
        *,
        body_node: Node,
        compiled_loop: CompiledLoop,
        iteration_results: dict[str, NodeResult],
        iteration_outputs: dict[str, dict[str, Any]],
    ) -> bool:
        if body_node.id in compiled_loop.entry_node_ids:
            return True

        selected_incoming_count = 0
        for edge in compiled_loop.incoming_edges_by_node[body_node.id]:
            source_result = iteration_results.get(edge.from_node)
            if source_result is None or source_result.status != "succeeded":
                continue
            source_node = compiled_loop.node_by_id[edge.from_node]
            if not self._is_selected_edge_in_outputs(
                edge=edge,
                source_node=source_node,
                node_outputs=iteration_outputs,
            ):
                continue
            selected_incoming_count += 1
        return selected_incoming_count > 0

    def _should_run_node(self, *, node: Node, state: RunState, compiled_plan: CompiledPlan) -> bool:
        if node.kind == "start":
            return True

        selected_incoming_count = 0
        for edge in compiled_plan.incoming_edges_by_node[node.id]:
            source_result = state.node_results.get(edge.from_node)
            if source_result is None or source_result.status != "succeeded":
                continue
            source_node = compiled_plan.node_by_id[edge.from_node]
            if not self._is_selected_edge_in_outputs(
                edge=edge,
                source_node=source_node,
                node_outputs=state.node_outputs,
            ):
                continue
            selected_incoming_count += 1

        return selected_incoming_count > 0

    def _is_selected_edge_in_outputs(
        self,
        *,
        edge: Edge,
        source_node: Node,
        node_outputs: dict[str, dict[str, Any]],
    ) -> bool:
        if source_node.kind != "if_else":
            return True
        source_output = node_outputs.get(edge.from_node, {})
        return source_output.get("selected_handle") == edge.source_handle

    def _mark_node_skipped(self, *, node: Node, state: RunState) -> None:
        state.node_results[node.id] = NodeResult(
            node_id=node.id,
            node_name=node.name,
            kind=node.kind,
            status="skipped",
            started_at=_utc_now(),
            finished_at=_utc_now(),
            duration_ms=0,
        )

    def _normalize_input_resolution_error(self, *, exc: Exception, node: Node) -> WorkflowError:
        if isinstance(exc, (PlanValidationError, ValueError)):
            return WorkflowError(
                code="INPUT_RESOLUTION_FAILED",
                message=str(exc),
                phase="runtime",
                node_id=node.id,
                node_name=node.name,
                retryable=False,
            )
        return WorkflowError(
            code="INTERNAL_ERROR",
            message=str(exc),
            phase="runtime",
            node_id=node.id,
            node_name=node.name,
            retryable=False,
        )

    def _normalize_node_execution_error(self, *, exc: Exception, node: Node) -> WorkflowError:
        if isinstance(exc, HTTPRequestFailedError):
            return WorkflowError(
                code="HTTP_REQUEST_FAILED",
                message=str(exc),
                phase="runtime",
                node_id=node.id,
                node_name=node.name,
                retryable=True,
            )
        if isinstance(exc, HTTPBadStatusError):
            return WorkflowError(
                code="HTTP_BAD_STATUS",
                message=str(exc),
                phase="runtime",
                node_id=node.id,
                node_name=node.name,
                retryable=False,
                details={
                    "status_code": exc.status_code,
                    **({"response_body": exc.response_body} if exc.response_body is not None else {}),
                },
            )
        if isinstance(exc, AzureLLMRequestFailedError):
            return WorkflowError(
                code="LLM_REQUEST_FAILED",
                message=str(exc),
                phase="runtime",
                node_id=node.id,
                node_name=node.name,
                retryable=True,
            )
        if isinstance(exc, AzureLLMBadStatusError):
            return WorkflowError(
                code="LLM_BAD_STATUS",
                message=str(exc),
                phase="runtime",
                node_id=node.id,
                node_name=node.name,
                retryable=False,
                details={
                    "status_code": exc.status_code,
                    **({"response_body": exc.response_body} if exc.response_body is not None else {}),
                },
            )
        if isinstance(exc, AzureLLMStructuredOutputError):
            return WorkflowError(
                code="NODE_EXECUTION_FAILED",
                message=str(exc),
                phase="runtime",
                node_id=node.id,
                node_name=node.name,
                retryable=False,
                details={"attempts": exc.attempts},
            )
        if isinstance(exc, UnsupportedNodeError):
            return WorkflowError(
                code="UNSUPPORTED_NODE",
                message=str(exc),
                phase="runtime",
                node_id=node.id,
                node_name=node.name,
                retryable=False,
            )
        if isinstance(exc, _LoopRuntimeError):
            return exc.error
        if isinstance(exc, ValueError):
            return WorkflowError(
                code="NODE_EXECUTION_FAILED",
                message=str(exc),
                phase="runtime",
                node_id=node.id,
                node_name=node.name,
                retryable=False,
            )
        return WorkflowError(
            code="INTERNAL_ERROR",
            message=str(exc),
            phase="runtime",
            node_id=node.id,
            node_name=node.name,
            retryable=False,
        )

    def _build_run_result(
        self,
        *,
        state: RunState,
        status: str,
        outputs: dict[str, Any] | None,
        error: WorkflowError | None,
        started_at: str,
        started_monotonic: float,
    ) -> RunResult:
        return RunResult(
            run_id=state.run_id,
            status=status,
            outputs=outputs,
            error=error,
            nodes=state.node_results,
            started_at=started_at,
            finished_at=_utc_now(),
            duration_ms=max(0, int((time.monotonic() - started_monotonic) * 1000)),
        )


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


class _LoopRuntimeError(ValueError):
    def __init__(self, error: WorkflowError) -> None:
        super().__init__(error.message)
        self.error = error
