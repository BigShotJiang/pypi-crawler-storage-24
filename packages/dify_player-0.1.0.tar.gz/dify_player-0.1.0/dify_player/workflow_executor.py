from __future__ import annotations

import asyncio
import json
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

import httpx
from dify_player.event_logger import EventLogger, WorkflowLogger
from dify_player.exceptions import PlanValidationError
from dify_player.models import CompiledPlan, Plan, RunResult, WorkflowError
from dify_player.plan_loader import compile_plan, load_input_data, load_plan_definition
from dify_player.runtime import WorkflowRuntime


def build_default_log_path(run_id: str) -> Path:
    timestamp = datetime.now().astimezone().strftime("%Y%m%dT%H%M%S")
    return Path("logs") / f"{timestamp}_{run_id}.jsonl"


class WorkflowExecutor:
    async def run_compiled_plan(
        self,
        *,
        compiled_plan: CompiledPlan,
        inputs: dict[str, object],
        logger: WorkflowLogger,
        started_at: str | None = None,
        started_monotonic: float | None = None,
        http_client: httpx.AsyncClient | None = None,
    ) -> RunResult:
        runtime = WorkflowRuntime(logger=logger)
        return await runtime.run(
            compiled_plan=compiled_plan,
            inputs=inputs,
            started_at=started_at,
            started_monotonic=started_monotonic,
            http_client=http_client,
        )

    async def run_plan(
        self,
        *,
        plan: Plan,
        inputs: dict[str, object],
        logger: WorkflowLogger,
        started_at: str | None = None,
        started_monotonic: float | None = None,
        http_client: httpx.AsyncClient | None = None,
    ) -> RunResult:
        try:
            compiled_plan = compile_plan(plan)
        except PlanValidationError as exc:
            return self._build_failed_result(
                run_id=logger.run_id,
                code="PLAN_COMPILE_FAILED",
                message=str(exc),
                phase="compile",
                started_at=started_at,
                started_monotonic=started_monotonic,
            )
        return await self.run_compiled_plan(
            compiled_plan=compiled_plan,
            inputs=inputs,
            logger=logger,
            started_at=started_at,
            started_monotonic=started_monotonic,
            http_client=http_client,
        )

    async def run_plan_path(
        self,
        *,
        plan_path: Path,
        input_path: Path,
        log_path: Path | None = None,
        http_client: httpx.AsyncClient | None = None,
    ) -> RunResult:
        run_id = uuid.uuid4().hex
        resolved_log_path = log_path if log_path is not None else build_default_log_path(run_id)
        logger = EventLogger(log_path=resolved_log_path, run_id=run_id)
        started_at = _utc_now()
        started_monotonic = time.monotonic()

        logger.log(
            "run_started",
            status="running",
            plan_path=str(plan_path),
            input_path=str(input_path),
        )

        try:
            try:
                plan = await asyncio.to_thread(load_plan_definition, plan_path)
            except (FileNotFoundError, OSError, json.JSONDecodeError, PlanValidationError) as exc:
                result = self._build_failed_result(
                    run_id=run_id,
                    code="PLAN_LOAD_FAILED",
                    message=str(exc),
                    phase="load_plan",
                    started_at=started_at,
                    started_monotonic=started_monotonic,
                )
                _log_run_failed(logger=logger, result=result)
                return result

            try:
                input_data = await asyncio.to_thread(load_input_data, input_path)
            except (FileNotFoundError, OSError, json.JSONDecodeError, PlanValidationError) as exc:
                result = self._build_failed_result(
                    run_id=run_id,
                    code="INPUT_LOAD_FAILED",
                    message=str(exc),
                    phase="load_input",
                    started_at=started_at,
                    started_monotonic=started_monotonic,
                )
                _log_run_failed(logger=logger, result=result)
                return result

            result = await self.run_plan(
                plan=plan,
                inputs=input_data,
                logger=logger,
                started_at=started_at,
                started_monotonic=started_monotonic,
                http_client=http_client,
            )

            if result.status == "failed":
                _log_run_failed(logger=logger, result=result)
            else:
                logger.log("run_succeeded", status="succeeded", outputs=result.outputs)
            return result
        finally:
            logger.close()

    def _build_failed_result(
        self,
        *,
        run_id: str,
        code: str,
        message: str,
        phase: str,
        started_at: str | None,
        started_monotonic: float | None,
    ) -> RunResult:
        effective_started_at = started_at or _utc_now()
        effective_started_monotonic = started_monotonic if started_monotonic is not None else time.monotonic()
        finished_at = _utc_now()
        return RunResult(
            run_id=run_id,
            status="failed",
            outputs=None,
            error=WorkflowError(
                code=code,
                message=message,
                phase=phase,
                retryable=False,
            ),
            nodes={},
            started_at=effective_started_at,
            finished_at=finished_at,
            duration_ms=max(0, int((time.monotonic() - effective_started_monotonic) * 1000)),
        )


def _log_run_failed(*, logger: WorkflowLogger, result: RunResult) -> None:
    assert result.error is not None
    logger.log(
        "run_failed",
        status="failed",
        phase=result.error.phase,
        error=result.error.message,
        error_code=result.error.code,
        retryable=result.error.retryable,
        node_id=result.error.node_id,
        node_name=result.error.node_name,
    )


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
