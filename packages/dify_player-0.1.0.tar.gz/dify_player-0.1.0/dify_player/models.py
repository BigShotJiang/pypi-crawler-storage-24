from __future__ import annotations

from dataclasses import asdict, dataclass, field, is_dataclass
from typing import Any

ALLOWED_NODE_KINDS = {"start", "template", "http", "llm_azure_chat", "if_else", "variable_aggregator", "code", "loop", "end"}


def format_node_label(node_id: str, name: str | None = None) -> str:
    if name is None:
        return node_id
    return f"{name} [{node_id}]"


@dataclass(frozen=True)
class Node:
    id: str
    kind: str
    name: str | None = None
    inputs: dict[str, Any] = field(default_factory=dict)
    config: dict[str, Any] = field(default_factory=dict)

    @property
    def label(self) -> str:
        return format_node_label(self.id, self.name)


@dataclass(frozen=True)
class Edge:
    from_node: str
    to_node: str
    source_handle: str | None = None


@dataclass(frozen=True)
class Plan:
    nodes: list[Node]
    edges: list[Edge]
    outputs: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class CompiledPlan:
    plan: Plan
    node_by_id: dict[str, Node]
    incoming_by_node: dict[str, list[str]]
    outgoing_by_node: dict[str, list[str]]
    incoming_edges_by_node: dict[str, list[Edge]]
    outgoing_edges_by_node: dict[str, list[Edge]]
    execution_order: list[str]
    start_node_id: str
    end_node_id: str
    compiled_loops_by_node: dict[str, "CompiledLoop"] = field(default_factory=dict)


@dataclass(frozen=True)
class CompiledLoop:
    max_iterations: int
    initial_loop_variables: dict[str, Any]
    node_by_id: dict[str, Node]
    incoming_by_node: dict[str, list[str]]
    outgoing_by_node: dict[str, list[str]]
    incoming_edges_by_node: dict[str, list[Edge]]
    outgoing_edges_by_node: dict[str, list[Edge]]
    execution_order: list[str]
    entry_node_ids: list[str]
    break_node_ids: list[str]


@dataclass
class WorkflowError:
    code: str
    message: str
    phase: str
    node_id: str | None = None
    node_name: str | None = None
    retryable: bool = False
    details: dict[str, Any] = field(default_factory=dict)


@dataclass
class NodeResult:
    node_id: str
    node_name: str | None
    kind: str
    status: str
    resolved_inputs: dict[str, Any] | None = None
    outputs: dict[str, Any] | None = None
    error: WorkflowError | None = None
    started_at: str | None = None
    finished_at: str | None = None
    duration_ms: int | None = None


@dataclass
class RunResult:
    run_id: str
    status: str
    outputs: dict[str, Any] | None
    error: WorkflowError | None
    nodes: dict[str, NodeResult]
    started_at: str
    finished_at: str
    duration_ms: int


@dataclass
class RunState:
    run_id: str
    inputs: dict[str, Any]
    node_outputs: dict[str, dict[str, Any]] = field(default_factory=dict)
    node_results: dict[str, NodeResult] = field(default_factory=dict)


def to_data(value: Any) -> Any:
    if is_dataclass(value):
        return {key: to_data(item) for key, item in asdict(value).items()}
    if isinstance(value, dict):
        return {key: to_data(item) for key, item in value.items()}
    if isinstance(value, list):
        return [to_data(item) for item in value]
    return value
