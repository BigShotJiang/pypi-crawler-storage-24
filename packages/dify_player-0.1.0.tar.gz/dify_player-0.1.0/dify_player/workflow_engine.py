from __future__ import annotations

import uuid
from typing import Any

import httpx

from dify_player.event_logger import NullEventLogger, WorkflowLogger
from dify_player.models import CompiledPlan, Plan, RunResult
from dify_player.plan_loader import parse_plan
from dify_player.workflow_executor import WorkflowExecutor


class WorkflowEngine:
    def __init__(self) -> None:
        self._executor = WorkflowExecutor()

    async def run_compiled_plan(
        self,
        *,
        compiled_plan: CompiledPlan,
        inputs: dict[str, object],
        run_id: str | None = None,
        logger: WorkflowLogger | None = None,
        http_client: httpx.AsyncClient | None = None,
    ) -> RunResult:
        effective_logger, owns_logger = _resolve_logger(run_id=run_id, logger=logger)
        try:
            return await self._executor.run_compiled_plan(
                compiled_plan=compiled_plan,
                inputs=inputs,
                logger=effective_logger,
                http_client=http_client,
            )
        finally:
            if owns_logger:
                effective_logger.close()

    async def run_plan(
        self,
        *,
        plan: Plan,
        inputs: dict[str, object],
        run_id: str | None = None,
        logger: WorkflowLogger | None = None,
        http_client: httpx.AsyncClient | None = None,
    ) -> RunResult:
        effective_logger, owns_logger = _resolve_logger(run_id=run_id, logger=logger)
        try:
            return await self._executor.run_plan(
                plan=plan,
                inputs=inputs,
                logger=effective_logger,
                http_client=http_client,
            )
        finally:
            if owns_logger:
                effective_logger.close()

    async def run_plan_data(
        self,
        *,
        plan_data: dict[str, Any],
        inputs: dict[str, object],
        run_id: str | None = None,
        logger: WorkflowLogger | None = None,
        http_client: httpx.AsyncClient | None = None,
    ) -> RunResult:
        plan = parse_plan(plan_data)
        return await self.run_plan(
            plan=plan,
            inputs=inputs,
            run_id=run_id,
            logger=logger,
            http_client=http_client,
        )


def _resolve_logger(*, run_id: str | None, logger: WorkflowLogger | None) -> tuple[WorkflowLogger, bool]:
    if logger is not None:
        return logger, False
    return NullEventLogger(run_id=run_id or uuid.uuid4().hex), True
