class PlanValidationError(ValueError):
    """Raised when a hand-authored plan is invalid."""


class NodeExecutionError(RuntimeError):
    """Raised when a node fails during workflow execution."""


class UnsupportedNodeError(RuntimeError):
    """Raised when a node kind has no executor."""


class HTTPRequestFailedError(RuntimeError):
    """Raised when an HTTP request fails before receiving a response."""


class HTTPBadStatusError(RuntimeError):
    """Raised when an HTTP request returns a 4xx/5xx response."""

    def __init__(self, message: str, *, status_code: int, response_body: str | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body


class AzureLLMRequestFailedError(RuntimeError):
    """Raised when an Azure LLM request fails before receiving a response."""


class AzureLLMBadStatusError(RuntimeError):
    """Raised when an Azure LLM request returns a 4xx/5xx response."""

    def __init__(self, message: str, *, status_code: int, response_body: str | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body


class AzureLLMStructuredOutputError(RuntimeError):
    """Raised when structured output remains invalid after repair retries."""

    def __init__(self, message: str, *, attempts: list[dict[str, str]]) -> None:
        super().__init__(message)
        self.attempts = attempts
