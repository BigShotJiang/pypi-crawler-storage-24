from __future__ import annotations

import re
from typing import Any

from jinja2 import StrictUndefined, Undefined, UndefinedError
from jinja2.nativetypes import NativeEnvironment

_NATIVE_ENV = NativeEnvironment(undefined=StrictUndefined)
_SIMPLE_EXPRESSION_PATTERN = re.compile(r"^\s*\{\{\s*(.+?)\s*\}\}\s*$", re.DOTALL)


def get_native_environment() -> NativeEnvironment:
    return _NATIVE_ENV


def render_value(value: Any, context: dict[str, Any], *, location: str | None = None) -> Any:
    if isinstance(value, str):
        try:
            rendered = _render_string(value, context)
        except UndefinedError as exc:
            raise ValueError(_format_missing_value_error(location, str(exc))) from exc
        _raise_if_undefined(rendered, location)
        return rendered
    if isinstance(value, list):
        return [render_value(item, context, location=_child_location(location, index)) for index, item in enumerate(value)]
    if isinstance(value, dict):
        return {
            key: render_value(item, context, location=_child_location(location, key))
            for key, item in value.items()
        }
    return value


def _render_string(value: str, context: dict[str, Any]) -> Any:
    expression_match = _SIMPLE_EXPRESSION_PATTERN.fullmatch(value)
    if expression_match is not None:
        compiled = _NATIVE_ENV.compile_expression(expression_match.group(1), undefined_to_none=False)
        return compiled(**context)

    template = _NATIVE_ENV.from_string(value)
    return template.render(context)


def _raise_if_undefined(value: Any, location: str | None) -> None:
    if not isinstance(value, Undefined):
        return
    raise ValueError(_format_missing_value_error(location, _undefined_message(value)))


def _undefined_message(value: Undefined) -> str:
    try:
        return str(value)
    except UndefinedError as exc:
        return str(exc)


def _format_missing_value_error(location: str | None, detail: str) -> str:
    if location is None:
        return f"missing value: {detail}"
    return f"{location} references missing value: {detail}"


def _child_location(location: str | None, child: str | int) -> str | None:
    if location is None:
        return None
    if isinstance(child, int):
        return f"{location}[{child}]"
    if child.isidentifier():
        return f"{location}.{child}"
    return f"{location}[{child!r}]"
