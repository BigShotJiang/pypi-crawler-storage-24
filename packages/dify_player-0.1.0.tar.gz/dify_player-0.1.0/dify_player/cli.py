from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path

from dify_player.dify_workflow_importer import load_dify_workflow_definition, plan_to_data
from dify_player.exceptions import PlanValidationError
from dify_player.models import to_data
from dify_player.plan_loader import compile_plan
from dify_player.workflow_executor import WorkflowExecutor


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="dify_player")
    subparsers = parser.add_subparsers(dest="command", required=True)

    run_parser = subparsers.add_parser("run", help="Run a hand-authored workflow plan.")
    run_parser.add_argument("plan", help="Path to a plan JSON file.")
    run_parser.add_argument("input", help="Path to an input JSON file.")
    run_parser.add_argument(
        "--log",
        dest="log_path",
        help="Path to the JSONL log file. Defaults to logs/<timestamp>_<run_id>.jsonl.",
    )

    import_parser = subparsers.add_parser("import", help="Import a minimal Dify workflow YAML into a strict plan JSON.")
    import_parser.add_argument("workflow", help="Path to a Dify workflow YAML file.")
    import_parser.add_argument("plan", help="Path to write the imported strict plan JSON.")
    return parser


async def async_main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "import":
        try:
            plan = load_dify_workflow_definition(Path(args.workflow))
            compile_plan(plan)
        except (FileNotFoundError, OSError, PlanValidationError) as exc:
            print(str(exc), file=sys.stderr)
            return 1

        output_path = Path(args.plan)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with output_path.open("w", encoding="utf-8") as handle:
            json.dump(plan_to_data(plan), handle, ensure_ascii=False, indent=2)
            handle.write("\n")
        print(str(output_path))
        return 0

    if args.command != "run":
        parser.error(f"unsupported command: {args.command}")

    log_path = Path(args.log_path) if args.log_path else None
    result = await WorkflowExecutor().run_plan_path(
        plan_path=Path(args.plan),
        input_path=Path(args.input),
        log_path=log_path,
    )
    print(json.dumps(to_data(result), ensure_ascii=False))
    return 0 if result.status == "succeeded" else 1


def main(argv: list[str] | None = None) -> int:
    return asyncio.run(async_main(argv))


if __name__ == "__main__":
    raise SystemExit(main())
