"""Minimal workflow runner package."""

from dify_player.workflow_engine import WorkflowEngine

__all__ = ["__version__", "WorkflowEngine"]

__version__ = "0.1.0"
