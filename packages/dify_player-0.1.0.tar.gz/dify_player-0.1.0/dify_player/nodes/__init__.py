from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any

import httpx
from dify_player.exceptions import UnsupportedNodeError
from dify_player.models import Node

from dify_player.nodes.assigner import run as run_assigner
from dify_player.nodes.code import run as run_code
from dify_player.nodes.end import run as run_end
from dify_player.nodes.http import run as run_http
from dify_player.nodes.if_else import run as run_if_else
from dify_player.nodes.llm_azure_chat import run as run_llm_azure_chat
from dify_player.nodes.start import run as run_start
from dify_player.nodes.template import run as run_template
from dify_player.nodes.variable_aggregator import run as run_variable_aggregator

NodeExecutor = Callable[..., Awaitable[dict[str, Any]]]

_EXECUTORS: dict[str, NodeExecutor] = {
    "start": run_start,
    "template": run_template,
    "http": run_http,
    "llm_azure_chat": run_llm_azure_chat,
    "if_else": run_if_else,
    "variable_aggregator": run_variable_aggregator,
    "code": run_code,
    "assigner": run_assigner,
    "end": run_end,
}


async def run_node(
    node: Node,
    *,
    workflow_inputs: dict[str, Any],
    node_outputs: dict[str, dict[str, Any]],
    resolved_inputs: dict[str, Any],
    http_client: httpx.AsyncClient | None = None,
) -> dict[str, Any]:
    executor = _EXECUTORS.get(node.kind)
    if executor is None:
        raise UnsupportedNodeError(f"unsupported node kind {node.kind!r}")
    return await executor(
        node=node,
        workflow_inputs=workflow_inputs,
        node_outputs=node_outputs,
        resolved_inputs=resolved_inputs,
        http_client=http_client,
    )
