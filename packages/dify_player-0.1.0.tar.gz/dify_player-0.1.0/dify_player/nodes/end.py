from __future__ import annotations

from typing import Any

import httpx
from dify_player.exceptions import PlanValidationError
from dify_player.models import Node
from dify_player.value_renderer import render_value


async def run(
    *,
    node: Node,
    workflow_inputs: dict[str, Any],
    node_outputs: dict[str, dict[str, Any]],
    resolved_inputs: dict[str, Any],
    http_client: httpx.AsyncClient | None = None,
) -> dict[str, Any]:
    _ = workflow_inputs
    _ = node_outputs
    _ = http_client
    rendered = render_value(
        node.config["outputs"],
        {"inputs": resolved_inputs},
        location=f"end node {node.label!r} config.outputs",
    )
    if not isinstance(rendered, dict):
        raise PlanValidationError(f"end node {node.label!r} outputs must render to an object")
    return rendered
