from __future__ import annotations

from typing import Any

import httpx
from dify_player.models import Node


async def run(
    *,
    node: Node,
    workflow_inputs: dict[str, Any],
    node_outputs: dict[str, dict[str, Any]],
    resolved_inputs: dict[str, Any],
    http_client: httpx.AsyncClient | None = None,
) -> dict[str, Any]:
    _ = workflow_inputs
    _ = resolved_inputs
    _ = http_client

    for candidate in node.config["candidates"]:
        source_output = node_outputs.get(candidate["node_id"])
        if source_output is None:
            continue
        output_key = candidate["output_key"]
        if output_key not in source_output:
            continue
        value = source_output[output_key]
        if value is None:
            continue
        return {"output": value}

    raise ValueError(f"variable_aggregator node {node.label!r} could not find any available candidate outputs")
