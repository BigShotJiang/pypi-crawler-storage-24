from __future__ import annotations

from typing import Any

import httpx
from dify_player.models import Node


async def run(
    *,
    node: Node,
    workflow_inputs: dict[str, Any],
    node_outputs: dict[str, dict[str, Any]],
    resolved_inputs: dict[str, Any],
    http_client: httpx.AsyncClient | None = None,
) -> dict[str, Any]:
    _ = node
    _ = node_outputs
    _ = resolved_inputs
    _ = http_client
    return dict(workflow_inputs)
