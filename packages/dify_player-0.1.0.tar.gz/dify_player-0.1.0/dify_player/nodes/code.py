from __future__ import annotations

import inspect
from typing import Any

import httpx
from dify_player.models import Node


async def run(
    *,
    node: Node,
    workflow_inputs: dict[str, Any],
    node_outputs: dict[str, dict[str, Any]],
    resolved_inputs: dict[str, Any],
    http_client: httpx.AsyncClient | None = None,
) -> dict[str, Any]:
    _ = workflow_inputs
    _ = node_outputs
    _ = http_client

    if node.config["language"] != "python3":
        raise ValueError(f"code node {node.label!r} only supports python3")

    namespace = {"__builtins__": __builtins__}
    exec(node.config["source"], namespace)
    main = namespace.get("main")
    if not callable(main):
        raise ValueError(f"code node {node.label!r} must define callable main")

    result = main(**resolved_inputs)
    if inspect.isawaitable(result):
        result = await result
    if not isinstance(result, dict):
        raise ValueError(f"code node {node.label!r} main must return an object")

    outputs: dict[str, Any] = {}
    for output_name in node.config["outputs"]:
        if output_name not in result:
            raise ValueError(f"code node {node.label!r} main must return output {output_name!r}")
        outputs[output_name] = result[output_name]
    return outputs
