from __future__ import annotations

from typing import Any

import httpx
from dify_player.models import Node


async def run(
    *,
    node: Node,
    workflow_inputs: dict[str, Any],
    node_outputs: dict[str, dict[str, Any]],
    resolved_inputs: dict[str, Any],
    http_client: httpx.AsyncClient | None = None,
) -> dict[str, Any]:
    _ = workflow_inputs
    _ = node_outputs
    _ = http_client

    for case in node.config["cases"]:
        if _matches_case(case=case, resolved_inputs=resolved_inputs):
            return {
                "selected_handle": case["case_id"],
                "selected_case_id": case["case_id"],
            }

    return {
        "selected_handle": "false",
        "selected_case_id": None,
    }


def _matches_case(*, case: dict[str, Any], resolved_inputs: dict[str, Any]) -> bool:
    return all(_matches_condition(condition=condition, resolved_inputs=resolved_inputs) for condition in case["conditions"])


def _matches_condition(*, condition: dict[str, Any], resolved_inputs: dict[str, Any]) -> bool:
    left_value = resolved_inputs[condition["input_name"]]
    if condition["operator"] == "contains":
        return str(condition["value"]) in str(left_value)
    if condition["operator"] == "equals":
        return str(left_value) == str(condition["value"])
    raise ValueError(f"unsupported if_else operator {condition['operator']!r}")
