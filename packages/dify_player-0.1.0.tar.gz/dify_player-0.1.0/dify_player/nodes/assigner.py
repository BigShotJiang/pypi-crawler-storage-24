from __future__ import annotations

from typing import Any

import httpx
from dify_player.models import Node


async def run(
    *,
    node: Node,
    workflow_inputs: dict[str, Any],
    node_outputs: dict[str, dict[str, Any]],
    resolved_inputs: dict[str, Any],
    http_client: httpx.AsyncClient | None = None,
) -> dict[str, Any]:
    _ = workflow_inputs
    _ = node_outputs
    _ = http_client

    if node.kind != "assigner":
        raise ValueError(f"assigner helper only supports assigner nodes; got {node.kind!r}")

    raw_assignments = node.config.get("assignments")
    if not isinstance(raw_assignments, list):
        raise ValueError(f"assigner node {node.label!r} must define config.assignments as an array")

    updates: dict[str, Any] = {}
    for index, item in enumerate(raw_assignments):
        if not isinstance(item, dict):
            raise ValueError(f"assigner node {node.label!r} config.assignments[{index}] must be an object")
        input_name = item.get("input_name")
        target_name = item.get("target_name")
        if not isinstance(input_name, str) or not input_name:
            raise ValueError(f"assigner node {node.label!r} config.assignments[{index}].input_name must be a non-empty string")
        if not isinstance(target_name, str) or not target_name:
            raise ValueError(f"assigner node {node.label!r} config.assignments[{index}].target_name must be a non-empty string")
        if input_name not in resolved_inputs:
            raise ValueError(
                f"assigner node {node.label!r} config.assignments[{index}] references missing input {input_name!r}"
            )
        updates[target_name] = resolved_inputs[input_name]
    return updates
