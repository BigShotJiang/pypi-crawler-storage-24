from __future__ import annotations

import json
from typing import Any

import httpx

from dify_player.exceptions import HTTPBadStatusError, HTTPRequestFailedError
from dify_player.models import Node


async def run(
    *,
    node: Node,
    workflow_inputs: dict[str, Any],
    node_outputs: dict[str, dict[str, Any]],
    resolved_inputs: dict[str, Any],
    http_client: httpx.AsyncClient | None = None,
) -> dict[str, Any]:
    _ = workflow_inputs
    _ = node_outputs
    node_label = node.label
    method = node.config["method"]
    timeout_sec = node.config.get("timeout_sec", 30)
    url = resolved_inputs.get("url")
    if not isinstance(url, str) or not url:
        raise ValueError(f"http node {node_label!r} requires inputs.url as a non-empty string")

    headers = _normalize_headers(node=node, resolved_inputs=resolved_inputs)
    params = _normalize_params(node=node, resolved_inputs=resolved_inputs)
    body = resolved_inputs.get("body")

    request_kwargs: dict[str, Any] = {
        "headers": headers,
        "params": params,
        "timeout": timeout_sec,
    }

    if method == "GET":
        if "body" in resolved_inputs and body is not None:
            raise ValueError(f"http node {node_label!r} does not allow inputs.body for GET requests")
    elif method == "POST" and body is not None:
        if isinstance(body, (dict, list)):
            request_kwargs["json"] = body
        else:
            request_kwargs["data"] = str(body)

    if http_client is None:
        raise ValueError(f"http node {node_label!r} requires an async HTTP client")

    try:
        response = await http_client.request(method=method, url=url, **request_kwargs)
    except httpx.RequestError as exc:
        raise HTTPRequestFailedError(f"http node {node_label!r} request failed: {exc}") from exc
    body_text = response.text
    if response.status_code >= 400:
        raise HTTPBadStatusError(
            f"http node {node_label!r} received HTTP {response.status_code}",
            status_code=response.status_code,
            response_body=body_text,
        )

    headers_out = {key.lower(): value for key, value in response.headers.items()}
    json_body = None
    content_type = response.headers.get("Content-Type", "").lower()
    if "application/json" in content_type:
        try:
            json_body = response.json()
        except (ValueError, json.JSONDecodeError):
            json_body = None

    return {
        "status": response.status_code,
        "headers": headers_out,
        "body": body_text,
        "json": json_body,
    }


def _normalize_headers(*, node: Node, resolved_inputs: dict[str, Any]) -> dict[str, str]:
    headers = resolved_inputs.get("headers")
    if headers is None:
        return {}
    if not isinstance(headers, dict):
        raise ValueError(f"http node {node.label!r} inputs.headers must be an object")

    normalized: dict[str, str] = {}
    for key, value in headers.items():
        if not isinstance(key, str):
            raise ValueError(f"http node {node.label!r} inputs.headers keys must be strings")
        if not isinstance(value, str):
            raise ValueError(f"http node {node.label!r} inputs.headers values must be strings")
        normalized[key] = value
    return normalized


def _normalize_params(*, node: Node, resolved_inputs: dict[str, Any]) -> dict[str, str | int | float | bool]:
    params = resolved_inputs.get("params")
    if params is None:
        return {}
    if not isinstance(params, dict):
        raise ValueError(f"http node {node.label!r} inputs.params must be an object")

    normalized: dict[str, str | int | float | bool] = {}
    for key, value in params.items():
        if not isinstance(key, str):
            raise ValueError(f"http node {node.label!r} inputs.params keys must be strings")
        if isinstance(value, bool) or isinstance(value, (str, int, float)):
            normalized[key] = value
            continue
        raise ValueError(f"http node {node.label!r} inputs.params values must be strings, numbers, or booleans")
    return normalized
