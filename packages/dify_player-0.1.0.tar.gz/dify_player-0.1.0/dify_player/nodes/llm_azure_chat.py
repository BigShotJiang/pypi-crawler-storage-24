from __future__ import annotations

import json
import os
from typing import Any

import httpx

from dify_player.exceptions import AzureLLMBadStatusError, AzureLLMRequestFailedError, AzureLLMStructuredOutputError
from dify_player.models import Node
from dify_player.value_renderer import render_value

_STRUCTURED_OUTPUT_REPAIR_RETRIES = 1


async def run(
    *,
    node: Node,
    workflow_inputs: dict[str, Any],
    node_outputs: dict[str, dict[str, Any]],
    resolved_inputs: dict[str, Any],
    http_client: httpx.AsyncClient | None = None,
) -> dict[str, Any]:
    _ = resolved_inputs
    endpoint = _require_env("AZURE_OPENAI_ENDPOINT", node=node)
    api_key = _require_env("AZURE_OPENAI_API_KEY", node=node)
    api_version = _require_env("AZURE_OPENAI_API_VERSION", node=node)

    messages = render_value(
        node.config["messages"],
        {"inputs": workflow_inputs, "nodes": node_outputs},
        location=f"llm node {node.label!r} config.messages",
    )
    if node.config["response_format"] == "json_schema":
        return await _run_structured_output_with_repair(
            node=node,
            endpoint=endpoint,
            api_key=api_key,
            api_version=api_version,
            messages=messages,
            http_client=http_client,
        )

    raw_text = await _request_raw_text(
        node=node,
        endpoint=endpoint,
        api_key=api_key,
        api_version=api_version,
        messages=messages,
        http_client=http_client,
    )
    return {"text": raw_text}


def _require_env(name: str, *, node: Node) -> str:
    value = os.environ.get(name)
    if value:
        return value
    raise ValueError(f"llm node {node.label!r} requires environment variable {name}")


def _build_request_body(*, node: Node, messages: Any) -> dict[str, Any]:
    if not isinstance(messages, list):
        raise ValueError(f"llm node {node.label!r} config.messages must render to an array")

    request_messages: list[dict[str, str]] = []
    for index, message in enumerate(messages):
        if not isinstance(message, dict):
            raise ValueError(f"llm node {node.label!r} config.messages[{index}] must be an object")
        role = message.get("role")
        content = message.get("content")
        if not isinstance(role, str) or not role:
            raise ValueError(f"llm node {node.label!r} config.messages[{index}].role must be a non-empty string")
        if not isinstance(content, str):
            raise ValueError(f"llm node {node.label!r} config.messages[{index}].content must be a string")
        request_messages.append({"role": role, "content": content})

    body: dict[str, Any] = {"messages": request_messages}
    for key in ("temperature", "top_p", "max_tokens"):
        if key in node.config:
            body[key] = node.config[key]

    if node.config["response_format"] == "json_schema":
        body["response_format"] = {
            "type": "json_schema",
            "json_schema": {
                "name": "structured_output",
                "schema": node.config["json_schema"],
            },
        }

    return body


async def _request_raw_text(
    *,
    node: Node,
    endpoint: str,
    api_key: str,
    api_version: str,
    messages: list[dict[str, str]],
    http_client: httpx.AsyncClient | None,
) -> str:
    request_body = _build_request_body(node=node, messages=messages)
    url = f"{endpoint.rstrip('/')}/openai/deployments/{node.config['model']}/chat/completions"

    if http_client is None:
        raise ValueError(f"llm node {node.label!r} requires an async HTTP client")

    try:
        response = await http_client.post(
            url,
            params={"api-version": api_version},
            headers={"api-key": api_key, "Content-Type": "application/json"},
            json=request_body,
            timeout=node.config.get("timeout_sec", 60),
        )
    except httpx.RequestError as exc:
        raise AzureLLMRequestFailedError(f"llm node {node.label!r} request failed: {exc}") from exc

    if response.status_code >= 400:
        raise AzureLLMBadStatusError(
            _build_bad_status_message(node=node, status_code=response.status_code, response_body=response.text),
            status_code=response.status_code,
            response_body=response.text,
        )

    payload = _parse_response_json(node=node, body=response.text)
    return _extract_response_text(node=node, payload=payload)


async def _run_structured_output_with_repair(
    *,
    node: Node,
    endpoint: str,
    api_key: str,
    api_version: str,
    messages: list[dict[str, str]],
    http_client: httpx.AsyncClient | None,
) -> dict[str, Any]:
    current_messages = list(messages)
    attempts: list[dict[str, str]] = []

    for attempt_index in range(_STRUCTURED_OUTPUT_REPAIR_RETRIES + 1):
        raw_text = await _request_raw_text(
            node=node,
            endpoint=endpoint,
            api_key=api_key,
            api_version=api_version,
            messages=current_messages,
            http_client=http_client,
        )
        try:
            structured_output = _parse_structured_output(node=node, raw_text=raw_text)
            _validate_schema(node=node, schema=node.config["json_schema"], value=structured_output, path="$")
            return {"text": raw_text, "structured_output": structured_output}
        except ValueError as exc:
            attempts.append(
                {
                    "attempt": str(attempt_index + 1),
                    "error": str(exc),
                    "raw_text": raw_text,
                }
            )
            if attempt_index >= _STRUCTURED_OUTPUT_REPAIR_RETRIES:
                raise AzureLLMStructuredOutputError(
                    f"{str(exc)} after {attempt_index + 1} attempts",
                    attempts=attempts,
                ) from exc
            current_messages = current_messages + [_build_repair_message(validation_error=str(exc), previous_output=raw_text)]

    raise AssertionError("structured output repair loop must return or raise")


def _parse_response_json(*, node: Node, body: str) -> dict[str, Any]:
    try:
        payload = json.loads(body)
    except json.JSONDecodeError as exc:
        raise ValueError(f"llm node {node.label!r} returned invalid JSON response: {exc}") from exc
    if not isinstance(payload, dict):
        raise ValueError(f"llm node {node.label!r} returned invalid response payload")
    return payload


def _build_bad_status_message(*, node: Node, status_code: int, response_body: str) -> str:
    detail = _extract_error_detail(response_body)
    if detail is None:
        return f"llm node {node.label!r} received HTTP {status_code}"
    return f"llm node {node.label!r} received HTTP {status_code}: {detail}"


def _extract_error_detail(response_body: str) -> str | None:
    if not response_body.strip():
        return None
    try:
        payload = json.loads(response_body)
    except json.JSONDecodeError:
        return _truncate_text(response_body)
    if not isinstance(payload, dict):
        return _truncate_text(response_body)

    error = payload.get("error")
    if isinstance(error, dict):
        message = error.get("message")
        code = error.get("code")
        if isinstance(message, str) and isinstance(code, str) and code:
            return f"{code}: {message}"
        if isinstance(message, str):
            return message
        if isinstance(code, str) and code:
            return code
    message = payload.get("message")
    if isinstance(message, str):
        return message
    return _truncate_text(response_body)


def _truncate_text(value: str, *, limit: int = 400) -> str:
    normalized = " ".join(value.split())
    if len(normalized) <= limit:
        return normalized
    return normalized[:limit] + "..."


def _build_repair_message(*, validation_error: str, previous_output: str) -> dict[str, str]:
    return {
        "role": "user",
        "content": (
            "Your previous response did not satisfy the required JSON schema.\n"
            f"Validation error: {validation_error}\n"
            "Return only valid JSON that satisfies the schema exactly.\n"
            "Do not add markdown, commentary, or code fences.\n"
            f"Previous response:\n{previous_output}"
        ),
    }


def _extract_response_text(*, node: Node, payload: dict[str, Any]) -> str:
    choices = payload.get("choices")
    if not isinstance(choices, list) or not choices:
        raise ValueError(f"llm node {node.label!r} response must contain choices")
    first_choice = choices[0]
    if not isinstance(first_choice, dict):
        raise ValueError(f"llm node {node.label!r} response choice must be an object")
    message = first_choice.get("message")
    if not isinstance(message, dict):
        raise ValueError(f"llm node {node.label!r} response choice must contain message")
    content = message.get("content")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        text_parts: list[str] = []
        for item in content:
            if not isinstance(item, dict):
                continue
            text = item.get("text")
            if isinstance(text, str):
                text_parts.append(text)
        if text_parts:
            return "".join(text_parts)
    raise ValueError(f"llm node {node.label!r} response message.content must be text")


def _parse_structured_output(*, node: Node, raw_text: str) -> Any:
    try:
        return json.loads(raw_text)
    except json.JSONDecodeError as exc:
        raise ValueError(f"llm node {node.label!r} returned malformed structured output: {exc}") from exc


def _validate_schema(*, node: Node, schema: Any, value: Any, path: str) -> None:
    if not isinstance(schema, dict):
        raise ValueError(f"llm node {node.label!r} config.json_schema must be an object")

    expected_type = schema.get("type")
    if isinstance(expected_type, str):
        _validate_type(node=node, expected_type=expected_type, value=value, path=path)

    enum_values = schema.get("enum")
    if isinstance(enum_values, list) and value not in enum_values:
        raise ValueError(f"llm node {node.label!r} structured output at {path} must be one of {enum_values!r}")

    if expected_type == "object":
        properties = schema.get("properties", {})
        required = schema.get("required", [])
        additional_properties = schema.get("additionalProperties", True)
        if not isinstance(value, dict):
            return
        if isinstance(required, list):
            for key in required:
                if isinstance(key, str) and key not in value:
                    raise ValueError(f"llm node {node.label!r} structured output missing required field {path}.{key}")
        if additional_properties is False and isinstance(properties, dict):
            extra_keys = sorted(set(value) - set(properties))
            if extra_keys:
                raise ValueError(f"llm node {node.label!r} structured output at {path} has unexpected fields: {', '.join(extra_keys)}")
        if isinstance(properties, dict):
            for key, item_schema in properties.items():
                if key in value:
                    _validate_schema(node=node, schema=item_schema, value=value[key], path=f"{path}.{key}")
        return

    if expected_type == "array":
        item_schema = schema.get("items")
        if item_schema is not None and isinstance(value, list):
            for index, item in enumerate(value):
                _validate_schema(node=node, schema=item_schema, value=item, path=f"{path}[{index}]")
        return

    if expected_type in {"number", "integer"}:
        minimum = schema.get("minimum")
        maximum = schema.get("maximum")
        if minimum is not None and isinstance(value, (int, float)) and not isinstance(value, bool) and value < minimum:
            raise ValueError(f"llm node {node.label!r} structured output at {path} must be >= {minimum}")
        if maximum is not None and isinstance(value, (int, float)) and not isinstance(value, bool) and value > maximum:
            raise ValueError(f"llm node {node.label!r} structured output at {path} must be <= {maximum}")


def _validate_type(*, node: Node, expected_type: str, value: Any, path: str) -> None:
    if expected_type == "object" and not isinstance(value, dict):
        raise ValueError(f"llm node {node.label!r} structured output at {path} must be an object")
    if expected_type == "array" and not isinstance(value, list):
        raise ValueError(f"llm node {node.label!r} structured output at {path} must be an array")
    if expected_type == "string" and not isinstance(value, str):
        raise ValueError(f"llm node {node.label!r} structured output at {path} must be a string")
    if expected_type == "boolean" and not isinstance(value, bool):
        raise ValueError(f"llm node {node.label!r} structured output at {path} must be a boolean")
    if expected_type == "number" and (not isinstance(value, (int, float)) or isinstance(value, bool)):
        raise ValueError(f"llm node {node.label!r} structured output at {path} must be a number")
    if expected_type == "integer" and (not isinstance(value, int) or isinstance(value, bool)):
        raise ValueError(f"llm node {node.label!r} structured output at {path} must be an integer")
    if expected_type == "null" and value is not None:
        raise ValueError(f"llm node {node.label!r} structured output at {path} must be null")
