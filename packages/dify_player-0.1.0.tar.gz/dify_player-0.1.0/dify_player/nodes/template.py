from __future__ import annotations

from typing import Any

import httpx
from dify_player.models import Node
from dify_player.value_renderer import render_value


async def run(
    *,
    node: Node,
    workflow_inputs: dict[str, Any],
    node_outputs: dict[str, dict[str, Any]],
    resolved_inputs: dict[str, Any],
    http_client: httpx.AsyncClient | None = None,
) -> dict[str, Any]:
    _ = workflow_inputs
    _ = node_outputs
    _ = http_client
    template = node.config["template"]
    rendered = render_value(template, {"inputs": resolved_inputs}, location=f"template node {node.label!r} config.template")
    return {"text": str(rendered)}
