from __future__ import annotations

from typing import Any

from dify_player.exceptions import PlanValidationError
from dify_player.models import Node
from dify_player.value_renderer import render_value


def resolve_node_inputs(
    node: Node,
    *,
    workflow_inputs: dict[str, Any],
    node_outputs: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    if node.kind == "start":
        return {}

    resolved = render_value(
        node.inputs,
        {
            "inputs": workflow_inputs,
            "nodes": node_outputs,
        },
        location=f"node {node.label!r} inputs",
    )
    if not isinstance(resolved, dict):
        raise PlanValidationError(f"node {node.label!r} inputs must resolve to an object")
    return resolved
