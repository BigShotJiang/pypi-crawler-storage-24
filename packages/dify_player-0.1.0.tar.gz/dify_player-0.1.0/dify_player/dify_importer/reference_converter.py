from __future__ import annotations

import re
from typing import Any

from dify_player.exceptions import PlanValidationError

SIMPLE_REFERENCE_PATTERN = re.compile(r"^\s*\{\{#([^.#\s]+)\.([^#\s]+)#\}\}\s*$")
EMBEDDED_REFERENCE_PATTERN = re.compile(r"\{\{#([^.#\s]+)\.([^#\s]+)#\}\}")
UNSUPPORTED_TEMPLATE_PATTERN = re.compile(r"\{\{.*\}\}")
HTTP_OUTPUT_FIELDS = {"status", "headers", "body", "json"}


def convert_value(raw_value: Any, *, node_specs: dict[str, dict[str, Any]], context: str) -> Any:
    if isinstance(raw_value, dict):
        return {
            str(key): convert_value(value, node_specs=node_specs, context=context)
            for key, value in raw_value.items()
        }
    if isinstance(raw_value, list):
        return [convert_value(value, node_specs=node_specs, context=context) for value in raw_value]
    if isinstance(raw_value, str):
        return convert_string_reference(raw_value, node_specs=node_specs, context=context)
    return raw_value


def convert_value_selector(raw_value: Any, *, node_specs: dict[str, dict[str, Any]], context: str) -> str:
    if not isinstance(raw_value, list) or len(raw_value) < 2:
        raise PlanValidationError(f"{context} must be an array with at least [node_id, field]")
    selector_parts = [item for item in raw_value if isinstance(item, str) and item]
    if len(selector_parts) != len(raw_value):
        raise PlanValidationError(f"{context} must only contain non-empty string selector parts")
    source_node_id = selector_parts[0]
    field_name = ".".join(selector_parts[1:])
    return convert_reference_to_strict_expression(
        source_node_id=source_node_id,
        field_name=field_name,
        node_specs=node_specs,
        context=context,
    )


def convert_selector_to_output_ref(raw_value: Any, *, node_specs: dict[str, dict[str, Any]], context: str) -> dict[str, str]:
    if not isinstance(raw_value, list) or len(raw_value) != 2:
        raise PlanValidationError(f"{context} must be an array with exactly [node_id, output]")
    source_node_id, field_name = raw_value
    if not isinstance(source_node_id, str) or not source_node_id:
        raise PlanValidationError(f"{context}[0] must be a non-empty string node id")
    if not isinstance(field_name, str) or not field_name:
        raise PlanValidationError(f"{context}[1] must be a non-empty string output name")

    source_data = node_specs.get(source_node_id)
    if source_data is None:
        raise PlanValidationError(f"{context} references unknown Dify node {source_node_id!r}")

    source_type = source_data["type"]
    if source_type == "template-transform":
        if field_name != "output":
            raise PlanValidationError(f"{context} may only reference template-transform output")
        return {"node_id": source_node_id, "output_key": "text"}
    if source_type == "variable-aggregator":
        if field_name != "output":
            raise PlanValidationError(f"{context} may only reference variable-aggregator output")
        return {"node_id": source_node_id, "output_key": "output"}

    raise PlanValidationError(f"{context} only supports template-transform or variable-aggregator outputs")


def convert_string_reference(raw_value: str, *, node_specs: dict[str, dict[str, Any]], context: str) -> str:
    match = SIMPLE_REFERENCE_PATTERN.fullmatch(raw_value)
    if match is None:
        if UNSUPPORTED_TEMPLATE_PATTERN.search(raw_value):
            raise PlanValidationError(f"{context} only supports simple Dify references in Step 5")
        return raw_value

    source_node_id, field_name = match.groups()
    return convert_reference_to_strict_expression(
        source_node_id=source_node_id,
        field_name=field_name,
        node_specs=node_specs,
        context=context,
    )


def replace_embedded_dify_references(raw_value: str, *, node_specs: dict[str, dict[str, Any]], context: str) -> str:
    if "{{" not in raw_value:
        return raw_value

    def _replace(match: re.Match[str]) -> str:
        source_node_id, field_name = match.groups()
        return convert_reference_to_strict_expression(
            source_node_id=source_node_id,
            field_name=field_name,
            node_specs=node_specs,
            context=context,
        )

    replaced_value = EMBEDDED_REFERENCE_PATTERN.sub(_replace, raw_value)
    if "{{#" in replaced_value:
        raise PlanValidationError(f"{context} only supports embedded simple Dify references in Step 5")
    return replaced_value


def convert_reference_to_strict_expression(
    *, source_node_id: str, field_name: str, node_specs: dict[str, dict[str, Any]], context: str
) -> str:
    source_data = node_specs.get(source_node_id)
    if source_data is None:
        raise PlanValidationError(f"{context} references unknown Dify node {source_node_id!r}")

    source_type = source_data["type"]
    if source_type == "start":
        if "." in field_name:
            raise PlanValidationError(f"{context} references unsupported nested start value {field_name!r}")
        _ensure_known_start_variable(
            source_node_id=source_node_id,
            field_name=field_name,
            source_data=source_data,
            context=context,
        )
        return f"{{{{ inputs.{field_name} }}}}"
    if source_type == "http-request":
        return _convert_http_reference(
            source_node_id=source_node_id,
            field_name=field_name,
            context=context,
        )
    if source_type == "llm":
        return _convert_llm_reference(
            source_node_id=source_node_id,
            field_name=field_name,
            context=context,
        )
    if source_type == "template-transform":
        return _convert_template_transform_reference(
            source_node_id=source_node_id,
            field_name=field_name,
            context=context,
        )
    if source_type == "code":
        return _convert_code_reference(
            source_node_id=source_node_id,
            field_name=field_name,
            source_data=source_data,
            context=context,
        )
    if source_type == "loop":
        return _convert_loop_reference(
            source_node_id=source_node_id,
            field_name=field_name,
            source_data=source_data,
            context=context,
        )
    if source_type == "variable-aggregator":
        return _convert_variable_aggregator_reference(
            source_node_id=source_node_id,
            field_name=field_name,
            context=context,
        )

    raise PlanValidationError(f"{context} references unsupported Dify node type {source_type!r}")


def _ensure_known_start_variable(
    *, source_node_id: str, field_name: str, source_data: dict[str, Any], context: str
) -> None:
    variables = source_data.get("variables")
    if not isinstance(variables, list):
        raise PlanValidationError(f"Dify start node {source_node_id!r} must define variables as an array")
    allowed_names = {
        item.get("variable")
        for item in variables
        if isinstance(item, dict) and isinstance(item.get("variable"), str) and item.get("variable")
    }
    if field_name not in allowed_names:
        raise PlanValidationError(f"{context} references unknown start variable {field_name!r}")


def _convert_http_reference(*, source_node_id: str, field_name: str, context: str) -> str:
    root_field, *remaining = field_name.split(".")
    if root_field not in HTTP_OUTPUT_FIELDS:
        raise PlanValidationError(f"{context} may only reference http-request outputs: {', '.join(sorted(HTTP_OUTPUT_FIELDS))}")
    return _build_nodes_expression(source_node_id=source_node_id, root_field=root_field, remaining=remaining)


def _convert_llm_reference(*, source_node_id: str, field_name: str, context: str) -> str:
    root_field, *remaining = field_name.split(".")
    if root_field not in {"text", "structured_output"}:
        raise PlanValidationError(f"{context} may only reference llm outputs: structured_output, text")
    if root_field == "text" and remaining:
        raise PlanValidationError(f"{context} may not reference nested llm text output")
    if root_field == "structured_output" and not remaining:
        return f"{{{{ nodes['{source_node_id}'].structured_output }}}}"
    return _build_nodes_expression(source_node_id=source_node_id, root_field=root_field, remaining=remaining)


def _convert_template_transform_reference(*, source_node_id: str, field_name: str, context: str) -> str:
    if field_name != "output":
        raise PlanValidationError(f"{context} may only reference template-transform output")
    return f"{{{{ nodes['{source_node_id}'].text }}}}"


def _convert_variable_aggregator_reference(*, source_node_id: str, field_name: str, context: str) -> str:
    if field_name != "output":
        raise PlanValidationError(f"{context} may only reference variable-aggregator output")
    return f"{{{{ nodes['{source_node_id}'].output }}}}"


def _convert_code_reference(*, source_node_id: str, field_name: str, source_data: dict[str, Any], context: str) -> str:
    root_field, *remaining = field_name.split(".")
    raw_outputs = source_data.get("outputs")
    if not isinstance(raw_outputs, dict) or root_field not in raw_outputs:
        raise PlanValidationError(f"{context} references unknown code output {root_field!r}")
    return _build_nodes_expression(source_node_id=source_node_id, root_field=root_field, remaining=remaining)


def _convert_loop_reference(*, source_node_id: str, field_name: str, source_data: dict[str, Any], context: str) -> str:
    root_field, *remaining = field_name.split(".")
    raw_loop_variables = source_data.get("loop_variables")
    if not isinstance(raw_loop_variables, dict) or root_field not in raw_loop_variables:
        raise PlanValidationError(f"{context} references unknown loop output {root_field!r}")
    return _build_nodes_expression(source_node_id=source_node_id, root_field=root_field, remaining=remaining)


def _build_nodes_expression(*, source_node_id: str, root_field: str, remaining: list[str]) -> str:
    expression = f"nodes['{source_node_id}'].{root_field}"
    for item in remaining:
        if item.isidentifier():
            expression = f"{expression}.{item}"
        else:
            expression = f"{expression}[{item!r}]"
    return f"{{{{ {expression} }}}}"
