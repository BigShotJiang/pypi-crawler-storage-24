from __future__ import annotations

from copy import deepcopy
from typing import Any

from dify_player.exceptions import PlanValidationError


def normalize_dify_workflow(data: Any) -> Any:
    if not isinstance(data, dict):
        return data
    normalized = deepcopy(data)
    workflow = normalized.get("workflow")
    if not isinstance(workflow, dict):
        return normalized
    graph = workflow.get("graph")
    if not isinstance(graph, dict):
        return normalized

    raw_nodes = graph.get("nodes")
    raw_edges = graph.get("edges")
    if not isinstance(raw_nodes, list) or not isinstance(raw_edges, list):
        return normalized

    ignored_note_ids = _collect_ignored_note_ids(raw_nodes)
    loop_ids = {
        node["id"]
        for node in raw_nodes
        if isinstance(node, dict)
        and isinstance(node.get("id"), str)
        and isinstance(node.get("data"), dict)
        and node["data"].get("type") == "loop"
    }
    for raw_node in raw_nodes:
        if not isinstance(raw_node, dict):
            continue
        raw_id = raw_node.get("id")
        if raw_id in loop_ids and raw_node.get("parentId") is not None:
            raise PlanValidationError(f"Dify loop node {raw_id!r} may not be nested")
        if raw_node.get("parentId") in loop_ids:
            data_type = raw_node.get("data", {}).get("type")
            if data_type == "loop":
                raise PlanValidationError(f"Dify nested loop inside {raw_node.get('parentId')!r} is not supported")

    normalized_nodes: list[dict[str, Any]] = []
    top_level_ids: set[str] = set()
    for raw_node in raw_nodes:
        if not isinstance(raw_node, dict):
            continue
        raw_id = raw_node.get("id")
        if raw_id in ignored_note_ids:
            continue
        if raw_node.get("parentId") in loop_ids:
            continue
        data_dict = raw_node.get("data")
        if not isinstance(raw_id, str) or not isinstance(data_dict, dict):
            continue
        if data_dict.get("type") == "loop":
            normalized_nodes.append(_normalize_loop_node(loop_node=raw_node, raw_nodes=raw_nodes, raw_edges=raw_edges, ignored_note_ids=ignored_note_ids))
        else:
            normalized_nodes.append(raw_node)
        top_level_ids.add(raw_id)

    normalized_edges = [
        raw_edge
        for raw_edge in raw_edges
        if isinstance(raw_edge, dict)
        and raw_edge.get("source") in top_level_ids
        and raw_edge.get("target") in top_level_ids
        and raw_edge.get("source") not in ignored_note_ids
        and raw_edge.get("target") not in ignored_note_ids
    ]
    graph["nodes"] = normalized_nodes
    graph["edges"] = normalized_edges
    return normalized


def _collect_ignored_note_ids(raw_nodes: list[Any]) -> set[str]:
    ignored: set[str] = set()
    for raw_node in raw_nodes:
        if not isinstance(raw_node, dict):
            continue
        raw_id = raw_node.get("id")
        data_dict = raw_node.get("data")
        if not isinstance(raw_id, str) or not isinstance(data_dict, dict):
            continue
        node_type = data_dict.get("type")
        if node_type in ("", None):
            ignored.add(raw_id)
    return ignored


def _normalize_loop_node(
    *,
    loop_node: dict[str, Any],
    raw_nodes: list[Any],
    raw_edges: list[Any],
    ignored_note_ids: set[str],
) -> dict[str, Any]:
    loop_id = loop_node["id"]
    loop_data = loop_node["data"]
    if loop_data.get("break_conditions") not in (None, []):
        raise PlanValidationError(f"Dify loop node {loop_id!r} only supports empty break_conditions")
    if loop_data.get("error_handle_mode") != "terminated":
        raise PlanValidationError(f"Dify loop node {loop_id!r} only supports error_handle_mode=terminated")

    child_nodes = [
        raw_node
        for raw_node in raw_nodes
        if isinstance(raw_node, dict) and raw_node.get("parentId") == loop_id and raw_node.get("id") not in ignored_note_ids
    ]
    child_ids = {
        raw_node["id"]
        for raw_node in child_nodes
        if isinstance(raw_node.get("id"), str)
    }

    start_node_id = loop_data.get("start_node_id")
    if not isinstance(start_node_id, str) or start_node_id not in child_ids:
        raise PlanValidationError(f"Dify loop node {loop_id!r} must define a valid start_node_id")

    loop_end_ids = {
        raw_node["id"]
        for raw_node in child_nodes
        if isinstance(raw_node.get("data"), dict) and raw_node["data"].get("type") == "loop-end"
    }
    if not loop_end_ids:
        raise PlanValidationError(f"Dify loop node {loop_id!r} must define at least one loop-end child")

    body_nodes = []
    body_node_ids: set[str] = set()
    for raw_node in child_nodes:
        raw_id = raw_node.get("id")
        data_dict = raw_node.get("data")
        if not isinstance(raw_id, str) or not isinstance(data_dict, dict):
            continue
        if data_dict.get("type") in {"loop-start", "loop-end"}:
            continue
        body_nodes.append({"id": raw_id, "data": data_dict})
        body_node_ids.add(raw_id)

    entry_nodes: list[str] = []
    break_nodes: list[str] = []
    body_edges: list[dict[str, Any]] = []
    for raw_edge in raw_edges:
        if not isinstance(raw_edge, dict):
            continue
        source = raw_edge.get("source")
        target = raw_edge.get("target")
        if source == start_node_id and target in body_node_ids:
            entry_nodes.append(target)
            continue
        if source in body_node_ids and target in loop_end_ids:
            break_nodes.append(source)
            continue
        if source in body_node_ids and target in body_node_ids:
            body_edges.append(raw_edge)

    if not entry_nodes:
        raise PlanValidationError(f"Dify loop node {loop_id!r} must have at least one entry node")
    if not break_nodes:
        raise PlanValidationError(f"Dify loop node {loop_id!r} must have at least one break node")

    return {
        **loop_node,
        "data": {
            "type": "loop",
            **({"title": loop_data["title"]} if loop_data.get("title") else {}),
            "max_iterations": loop_data.get("loop_count"),
            "loop_variables": _normalize_loop_variables(loop_id=loop_id, raw_loop_variables=loop_data.get("loop_variables")),
            "body_nodes": body_nodes,
            "body_edges": body_edges,
            "entry_nodes": _dedupe_preserve_order(entry_nodes),
            "break_nodes": _dedupe_preserve_order(break_nodes),
        },
    }


def _normalize_loop_variables(*, loop_id: str, raw_loop_variables: Any) -> dict[str, Any]:
    if not isinstance(raw_loop_variables, list) or not raw_loop_variables:
        raise PlanValidationError(f"Dify loop node {loop_id!r} must define loop_variables as a non-empty array")
    result: dict[str, Any] = {}
    for index, raw_item in enumerate(raw_loop_variables):
        if not isinstance(raw_item, dict):
            raise PlanValidationError(f"Dify loop node {loop_id!r} loop_variables[{index}] must be an object")
        if raw_item.get("value_type") != "constant":
            raise PlanValidationError(f"Dify loop node {loop_id!r} only supports constant loop_variables")
        label = raw_item.get("label")
        if not isinstance(label, str) or not label:
            raise PlanValidationError(f"Dify loop node {loop_id!r} loop_variables[{index}].label must be a non-empty string")
        if label in result:
            raise PlanValidationError(f"Dify loop node {loop_id!r} has duplicate loop variable {label!r}")
        result[label] = _parse_constant_value(raw_item.get("value"))
    return result


def _parse_constant_value(raw_value: Any) -> Any:
    if not isinstance(raw_value, str):
        return raw_value
    stripped = raw_value.strip()
    if stripped == "":
        return ""
    if stripped == "null":
        return None
    if stripped == "true":
        return True
    if stripped == "false":
        return False
    if stripped[:1] in "[{\"'" or stripped.replace(".", "", 1).replace("-", "", 1).isdigit():
        try:
            import json

            return json.loads(stripped)
        except json.JSONDecodeError:
            return raw_value
    return raw_value


def _dedupe_preserve_order(values: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        result.append(value)
    return result
