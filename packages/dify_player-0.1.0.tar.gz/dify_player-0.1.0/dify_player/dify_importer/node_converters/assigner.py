from __future__ import annotations

from typing import Any

from dify_player.dify_importer.reference_converter import convert_value_selector
from dify_player.exceptions import PlanValidationError
from dify_player.models import Node


def convert_assigner_node(
    *,
    node_id: str,
    node_name: str | None,
    data: dict[str, Any],
    node_specs: dict[str, dict[str, Any]],
) -> Node:
    raw_items = data.get("items")
    if not isinstance(raw_items, list) or not raw_items:
        raise PlanValidationError(f"Dify assigner node {node_id!r} must define items as a non-empty array")

    inputs: dict[str, Any] = {}
    assignments: list[dict[str, str]] = []
    target_names: set[str] = set()
    for index, raw_item in enumerate(raw_items):
        if not isinstance(raw_item, dict):
            raise PlanValidationError(f"Dify assigner node {node_id!r} items[{index}] must be an object")
        if raw_item.get("input_type") != "variable":
            raise PlanValidationError(f"Dify assigner node {node_id!r} only supports items[{index}].input_type=variable")
        if raw_item.get("operation") != "over-write":
            raise PlanValidationError(f"Dify assigner node {node_id!r} only supports items[{index}].operation=over-write")

        output_name = raw_item.get("output_name")
        if not isinstance(output_name, str) or not output_name:
            raise PlanValidationError(f"Dify assigner node {node_id!r} items[{index}].output_name must be a non-empty string")

        loop_node_id, target_name = _parse_target_selector(
            raw_item.get("variable_selector"),
            node_id=node_id,
            item_index=index,
        )
        if output_name != target_name:
            raise PlanValidationError(
                f"Dify assigner node {node_id!r} items[{index}] output_name must match target loop variable {target_name!r}"
            )
        if output_name in target_names:
            raise PlanValidationError(
                f"Dify assigner node {node_id!r} may not assign the same target more than once: {output_name!r}"
            )
        target_names.add(output_name)

        input_name = f"input_{index}"
        inputs[input_name] = convert_value_selector(
            raw_item.get("value"),
            node_specs=node_specs,
            context=f"Dify assigner node {node_id!r} items[{index}].value",
        )
        assignments.append(
            {
                "input_name": input_name,
                "target_name": target_name,
                "target_scope": "loop_variable",
                "operation": "overwrite",
            }
        )
        _ = loop_node_id

    return Node(
        id=node_id,
        kind="assigner",
        name=node_name,
        inputs=inputs,
        config={"assignments": assignments},
    )


def _parse_target_selector(raw_value: Any, *, node_id: str, item_index: int) -> tuple[str, str]:
    context = f"Dify assigner node {node_id!r} items[{item_index}].variable_selector"
    if not isinstance(raw_value, list) or len(raw_value) != 2:
        raise PlanValidationError(f"{context} must be exactly [loop_node_id, loop_var_name]")
    loop_node_id, target_name = raw_value
    if not isinstance(loop_node_id, str) or not loop_node_id:
        raise PlanValidationError(f"{context}[0] must be a non-empty string loop node id")
    if not isinstance(target_name, str) or not target_name:
        raise PlanValidationError(f"{context}[1] must be a non-empty string loop variable name")
    return loop_node_id, target_name
