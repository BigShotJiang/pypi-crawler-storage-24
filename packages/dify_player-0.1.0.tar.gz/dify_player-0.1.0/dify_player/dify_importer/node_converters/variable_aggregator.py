from __future__ import annotations

from typing import Any

from dify_player.dify_importer.reference_converter import convert_selector_to_output_ref
from dify_player.exceptions import PlanValidationError
from dify_player.models import Node


def convert_variable_aggregator_node(
    *,
    node_id: str,
    node_name: str | None,
    data: dict[str, Any],
    node_specs: dict[str, dict[str, Any]],
) -> Node:
    output_type = data.get("output_type")
    if output_type != "string":
        raise PlanValidationError(f"Dify variable-aggregator node {node_id!r} only supports output_type=string")

    raw_variables = data.get("variables")
    if not isinstance(raw_variables, list) or not raw_variables:
        raise PlanValidationError(f"Dify variable-aggregator node {node_id!r} must define variables as a non-empty array")

    candidates: list[dict[str, str]] = []
    for index, item in enumerate(raw_variables):
        candidates.append(
            convert_selector_to_output_ref(
                item,
                node_specs=node_specs,
                context=f"Dify variable-aggregator node {node_id!r} variables[{index}]",
            )
        )

    return Node(
        id=node_id,
        kind="variable_aggregator",
        name=node_name,
        config={
            "output_type": "string",
            "candidates": candidates,
        },
    )
