from __future__ import annotations

import re
from typing import Any

from jinja2 import meta

from dify_player.dify_importer.reference_converter import convert_value_selector
from dify_player.exceptions import PlanValidationError
from dify_player.models import Node
from dify_player.value_renderer import get_native_environment

_SIMPLE_BARE_VARIABLE_PATTERN = re.compile(r"\{\{\s*([A-Za-z_][A-Za-z0-9_]*)\s*\}\}")


def convert_template_transform_node(
    *,
    node_id: str,
    node_name: str | None,
    data: dict[str, Any],
    node_specs: dict[str, dict[str, Any]],
) -> Node:
    template = data.get("template")
    if not isinstance(template, str):
        raise PlanValidationError(f"Dify template-transform node {node_id!r} must define template as a string")

    raw_variables = data.get("variables", [])
    if raw_variables is None:
        raw_variables = []
    if not isinstance(raw_variables, list):
        raise PlanValidationError(f"Dify template-transform node {node_id!r} variables must be an array")

    inputs: dict[str, Any] = {}
    declared_variables: set[str] = set()
    for index, item in enumerate(raw_variables):
        if not isinstance(item, dict):
            raise PlanValidationError(f"Dify template-transform node {node_id!r} variables[{index}] must be an object")
        variable = item.get("variable")
        if not isinstance(variable, str) or not variable:
            raise PlanValidationError(
                f"Dify template-transform node {node_id!r} variables[{index}].variable must be a non-empty string"
            )
        declared_variables.add(variable)
        inputs[variable] = convert_value_selector(
            item.get("value_selector"),
            node_specs=node_specs,
            context=f"Dify template-transform node {node_id!r} variables[{index}].value_selector",
        )

    converted_template = _convert_template_text(
        template=template,
        declared_variables=declared_variables,
        node_id=node_id,
    )
    return Node(id=node_id, kind="template", name=node_name, inputs=inputs, config={"template": converted_template})


def _convert_template_text(*, template: str, declared_variables: set[str], node_id: str) -> str:
    parsed = get_native_environment().parse(template)
    undeclared = meta.find_undeclared_variables(parsed)
    missing = sorted(name for name in undeclared if name not in declared_variables)
    if missing:
        raise PlanValidationError(
            f"Dify template-transform node {node_id!r} template references undeclared variables: {', '.join(missing)}"
        )

    converted = _SIMPLE_BARE_VARIABLE_PATTERN.sub(
        lambda match: _replace_bare_variable(match=match, declared_variables=declared_variables),
        template,
    )

    remaining_undeclared = meta.find_undeclared_variables(get_native_environment().parse(converted))
    if remaining_undeclared - {"inputs"}:
        names = ", ".join(sorted(remaining_undeclared - {"inputs"}))
        raise PlanValidationError(
            f"Dify template-transform node {node_id!r} template only supports simple bare variable references; found {names}"
        )
    return converted


def _replace_bare_variable(*, match: re.Match[str], declared_variables: set[str]) -> str:
    variable = match.group(1)
    if variable not in declared_variables:
        return match.group(0)
    return f"{{{{ inputs.{variable} }}}}"
