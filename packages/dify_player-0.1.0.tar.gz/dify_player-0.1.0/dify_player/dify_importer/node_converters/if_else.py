from __future__ import annotations

from typing import Any

from dify_player.dify_importer.reference_converter import convert_value_selector
from dify_player.exceptions import PlanValidationError
from dify_player.models import Node


def convert_if_else_node(
    *,
    node_id: str,
    node_name: str | None,
    data: dict[str, Any],
    node_specs: dict[str, dict[str, Any]],
) -> Node:
    raw_cases = data.get("cases")
    if not isinstance(raw_cases, list) or not raw_cases:
        raise PlanValidationError(f"Dify if-else node {node_id!r} must define cases as a non-empty array")

    inputs: dict[str, Any] = {}
    config_cases: list[dict[str, Any]] = []
    for case_index, raw_case in enumerate(raw_cases):
        if not isinstance(raw_case, dict):
            raise PlanValidationError(f"Dify if-else node {node_id!r} cases[{case_index}] must be an object")

        case_id = raw_case.get("case_id")
        logical_operator = raw_case.get("logical_operator")
        raw_conditions = raw_case.get("conditions")
        if not isinstance(case_id, str) or not case_id:
            raise PlanValidationError(f"Dify if-else node {node_id!r} cases[{case_index}].case_id must be a non-empty string")
        if logical_operator != "and":
            raise PlanValidationError(f"Dify if-else node {node_id!r} only supports logical_operator=and")
        if not isinstance(raw_conditions, list) or not raw_conditions:
            raise PlanValidationError(f"Dify if-else node {node_id!r} cases[{case_index}].conditions must be a non-empty array")

        conditions: list[dict[str, Any]] = []
        for condition_index, raw_condition in enumerate(raw_conditions):
            if not isinstance(raw_condition, dict):
                raise PlanValidationError(
                    f"Dify if-else node {node_id!r} cases[{case_index}].conditions[{condition_index}] must be an object"
                )
            comparison_operator = raw_condition.get("comparison_operator")
            operator = _convert_comparison_operator(comparison_operator, node_id=node_id)
            value = raw_condition.get("value")
            if not isinstance(value, str):
                raise PlanValidationError(
                    f"Dify if-else node {node_id!r} cases[{case_index}].conditions[{condition_index}].value must be a string"
                )
            input_name = f"case_{case_index}_condition_{condition_index}"
            inputs[input_name] = convert_value_selector(
                raw_condition.get("variable_selector"),
                node_specs=node_specs,
                context=(
                    f"Dify if-else node {node_id!r} "
                    f"cases[{case_index}].conditions[{condition_index}].variable_selector"
                ),
            )
            conditions.append(
                {
                    "operator": operator,
                    "input_name": input_name,
                    "value": value,
                }
            )

        config_cases.append(
            {
                "case_id": case_id,
                "logical_operator": "and",
                "conditions": conditions,
            }
        )

    return Node(
        id=node_id,
        kind="if_else",
        name=node_name,
        inputs=inputs,
        config={"cases": config_cases},
    )


def _convert_comparison_operator(raw_value: Any, *, node_id: str) -> str:
    if raw_value == "contains":
        return "contains"
    if raw_value == "=":
        return "equals"
    raise PlanValidationError(f"Dify if-else node {node_id!r} only supports comparison_operator=contains or '='")
