from __future__ import annotations

from typing import Any

from dify_player.dify_importer.http_body_converter import convert_http_body
from dify_player.dify_importer.reference_converter import convert_value
from dify_player.exceptions import PlanValidationError
from dify_player.models import Node


def convert_http_request_node(
    *,
    node_id: str,
    node_name: str | None,
    data: dict[str, Any],
    node_specs: dict[str, dict[str, Any]],
) -> Node:
    authorization = data.get("authorization")
    if not isinstance(authorization, dict) or authorization.get("type") != "no-auth":
        raise PlanValidationError(f"Dify http-request node {node_id!r} only supports authorization.type=no-auth")

    method = data.get("method")
    if not isinstance(method, str) or not method:
        raise PlanValidationError(f"Dify http-request node {node_id!r} must define method")

    inputs: dict[str, Any] = {
        "url": convert_value(data.get("url"), node_specs=node_specs, context=f"http-request node {node_id!r} url")
    }

    headers = _convert_optional_mapping(
        data.get("headers"),
        node_specs=node_specs,
        context=f"http-request node {node_id!r} headers",
    )
    if headers is not None:
        inputs["headers"] = headers

    params = _convert_optional_mapping(
        data.get("params"),
        node_specs=node_specs,
        context=f"http-request node {node_id!r} params",
    )
    if params is not None:
        inputs["params"] = params

    body = convert_http_body(data.get("body"), node_specs=node_specs, context=f"http-request node {node_id!r} body")
    if body is not None:
        inputs["body"] = body

    return Node(
        id=node_id,
        kind="http",
        name=node_name,
        inputs=inputs,
        config={"method": method.upper()},
    )


def _convert_optional_mapping(raw_value: Any, *, node_specs: dict[str, dict[str, Any]], context: str) -> dict[str, Any] | None:
    if raw_value in (None, ""):
        return None
    if not isinstance(raw_value, dict):
        raise PlanValidationError(f"{context} must be an object or empty")
    return convert_value(raw_value, node_specs=node_specs, context=context)
