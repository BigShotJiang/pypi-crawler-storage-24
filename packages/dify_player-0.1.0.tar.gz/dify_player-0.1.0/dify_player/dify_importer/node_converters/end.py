from __future__ import annotations

from typing import Any

from dify_player.dify_importer.reference_converter import convert_value_selector
from dify_player.exceptions import PlanValidationError
from dify_player.models import Node


def convert_end_node(
    *,
    node_id: str,
    node_name: str | None,
    data: dict[str, Any],
    node_specs: dict[str, dict[str, Any]],
) -> Node:
    outputs = data.get("outputs", [])
    if outputs in ([], None):
        return Node(id=node_id, kind="end", name=node_name, inputs={}, config={"outputs": {}})
    if not isinstance(outputs, list):
        raise PlanValidationError(f"Dify end node {node_id!r} outputs must be an array")

    inputs: dict[str, Any] = {}
    config_outputs: dict[str, str] = {}
    for index, item in enumerate(outputs):
        if not isinstance(item, dict):
            raise PlanValidationError(f"Dify end node {node_id!r} outputs[{index}] must be an object")
        variable = item.get("variable")
        if not isinstance(variable, str) or not variable:
            raise PlanValidationError(f"Dify end node {node_id!r} outputs[{index}].variable must be a non-empty string")
        inputs[variable] = convert_value_selector(
            item.get("value_selector"),
            node_specs=node_specs,
            context=f"Dify end node {node_id!r} outputs[{index}].value_selector",
        )
        config_outputs[variable] = _build_end_output_reference(variable)

    return Node(id=node_id, kind="end", name=node_name, inputs=inputs, config={"outputs": config_outputs})


def _build_end_output_reference(variable: str) -> str:
    if variable.isidentifier():
        return f"{{{{ inputs.{variable} }}}}"
    return f"{{{{ inputs[{variable!r}] }}}}"
