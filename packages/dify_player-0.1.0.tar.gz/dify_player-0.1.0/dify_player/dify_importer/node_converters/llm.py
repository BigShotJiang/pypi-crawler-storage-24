from __future__ import annotations

import json
from typing import Any

from dify_player.dify_importer.reference_converter import replace_embedded_dify_references
from dify_player.exceptions import PlanValidationError
from dify_player.models import Node

_AZURE_PROVIDER = "langgenius/azure_openai/azure_openai"


def convert_llm_node(
    *,
    node_id: str,
    node_name: str | None,
    data: dict[str, Any],
    node_specs: dict[str, dict[str, Any]],
) -> Node:
    _validate_default_only_fields(node_id=node_id, data=data)

    model = data.get("model")
    if not isinstance(model, dict):
        raise PlanValidationError(f"Dify llm node {node_id!r} must define model")
    provider = model.get("provider")
    if provider != _AZURE_PROVIDER:
        raise PlanValidationError(f"Dify llm node {node_id!r} only supports model.provider={_AZURE_PROVIDER}")
    if model.get("mode") != "chat":
        raise PlanValidationError(f"Dify llm node {node_id!r} only supports model.mode=chat")
    model_name = model.get("name")
    if not isinstance(model_name, str) or not model_name:
        raise PlanValidationError(f"Dify llm node {node_id!r} must define model.name")

    completion_params = model.get("completion_params", {})
    if completion_params is None:
        completion_params = {}
    if not isinstance(completion_params, dict):
        raise PlanValidationError(f"Dify llm node {node_id!r} model.completion_params must be an object")

    structured_output_enabled = data.get("structured_output_enabled", False)
    if not isinstance(structured_output_enabled, bool):
        raise PlanValidationError(f"Dify llm node {node_id!r} structured_output_enabled must be a boolean")

    config: dict[str, Any] = {
        "model": model_name,
        "messages": _convert_prompt_template(node_id=node_id, data=data, node_specs=node_specs),
        "response_format": "text",
    }
    _copy_optional_number(config=config, source=completion_params, key="temperature", node_id=node_id)
    _copy_optional_number(config=config, source=completion_params, key="top_p", node_id=node_id)
    _copy_optional_positive_int(config=config, source=completion_params, key="max_tokens", node_id=node_id)

    if structured_output_enabled:
        config["response_format"] = "json_schema"
        config["json_schema"] = _extract_json_schema(node_id=node_id, data=data, completion_params=completion_params)

    return Node(id=node_id, kind="llm_azure_chat", name=node_name, config=config)


def _convert_prompt_template(*, node_id: str, data: dict[str, Any], node_specs: dict[str, dict[str, Any]]) -> list[dict[str, str]]:
    raw_prompt_template = data.get("prompt_template")
    if not isinstance(raw_prompt_template, list) or not raw_prompt_template:
        raise PlanValidationError(f"Dify llm node {node_id!r} must define prompt_template as a non-empty array")

    messages: list[dict[str, str]] = []
    for index, item in enumerate(raw_prompt_template):
        if not isinstance(item, dict):
            raise PlanValidationError(f"Dify llm node {node_id!r} prompt_template[{index}] must be an object")
        role = item.get("role")
        text = item.get("text")
        if not isinstance(role, str) or not role:
            raise PlanValidationError(f"Dify llm node {node_id!r} prompt_template[{index}].role must be a string")
        if not isinstance(text, str):
            raise PlanValidationError(f"Dify llm node {node_id!r} prompt_template[{index}].text must be a string")
        messages.append(
            {
                "role": role,
                "content": replace_embedded_dify_references(
                    text,
                    node_specs=node_specs,
                    context=f"llm node {node_id!r} prompt_template[{index}].text",
                ),
            }
        )
    return messages


def _extract_json_schema(*, node_id: str, data: dict[str, Any], completion_params: dict[str, Any]) -> dict[str, Any]:
    structured_output = data.get("structured_output")
    if isinstance(structured_output, dict):
        schema = structured_output.get("schema")
        if isinstance(schema, dict):
            return schema

    raw_json_schema = completion_params.get("json_schema")
    if isinstance(raw_json_schema, str) and raw_json_schema.strip():
        try:
            parsed = json.loads(raw_json_schema)
        except json.JSONDecodeError as exc:
            raise PlanValidationError(f"Dify llm node {node_id!r} model.completion_params.json_schema must be valid JSON") from exc
        if not isinstance(parsed, dict):
            raise PlanValidationError(f"Dify llm node {node_id!r} model.completion_params.json_schema must be a JSON object")
        return parsed

    raise PlanValidationError(f"Dify llm node {node_id!r} must define structured_output.schema for structured output")


def _validate_default_only_fields(*, node_id: str, data: dict[str, Any]) -> None:
    context = data.get("context")
    if context is not None:
        if not isinstance(context, dict):
            raise PlanValidationError(f"Dify llm node {node_id!r} context must be an object when provided")
        if context.get("enabled") not in (None, False):
            raise PlanValidationError(f"Dify llm node {node_id!r} does not support context.enabled=true")
        variable_selector = context.get("variable_selector", [])
        if variable_selector not in ([], None):
            raise PlanValidationError(f"Dify llm node {node_id!r} does not support context.variable_selector")

    vision = data.get("vision")
    if vision is not None:
        if not isinstance(vision, dict):
            raise PlanValidationError(f"Dify llm node {node_id!r} vision must be an object when provided")
        if vision.get("enabled") not in (None, False):
            raise PlanValidationError(f"Dify llm node {node_id!r} does not support vision.enabled=true")


def _copy_optional_number(*, config: dict[str, Any], source: dict[str, Any], key: str, node_id: str) -> None:
    if key not in source:
        return
    value = source[key]
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise PlanValidationError(f"Dify llm node {node_id!r} model.completion_params.{key} must be a number")
    config[key] = value


def _copy_optional_positive_int(*, config: dict[str, Any], source: dict[str, Any], key: str, node_id: str) -> None:
    if key not in source:
        return
    value = source[key]
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise PlanValidationError(f"Dify llm node {node_id!r} model.completion_params.{key} must be a positive integer")
    config[key] = value
