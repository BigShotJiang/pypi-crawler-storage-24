from __future__ import annotations

from dify_player.models import Node


def convert_start_node(*, node_id: str, node_name: str | None) -> Node:
    return Node(id=node_id, kind="start", name=node_name)
