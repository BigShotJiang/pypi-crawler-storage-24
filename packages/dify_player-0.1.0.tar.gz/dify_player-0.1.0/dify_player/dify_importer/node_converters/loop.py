from __future__ import annotations

from typing import Any

from dify_player.dify_importer.node_converters.assigner import convert_assigner_node
from dify_player.dify_importer.node_converters.code import convert_code_node
from dify_player.dify_importer.node_converters.if_else import convert_if_else_node
from dify_player.dify_importer.node_converters.llm import convert_llm_node
from dify_player.dify_importer.node_converters.template_transform import convert_template_transform_node
from dify_player.exceptions import PlanValidationError
from dify_player.models import Node


def convert_loop_node(
    *,
    node_id: str,
    node_name: str | None,
    data: dict[str, Any],
    node_specs: dict[str, dict[str, Any]],
) -> Node:
    max_iterations = data.get("max_iterations")
    if isinstance(max_iterations, bool) or not isinstance(max_iterations, int) or max_iterations <= 0:
        raise PlanValidationError(f"Dify loop node {node_id!r} must define max_iterations as a positive integer")

    raw_loop_variables = data.get("loop_variables")
    if not isinstance(raw_loop_variables, dict):
        raise PlanValidationError(f"Dify loop node {node_id!r} must define loop_variables as an object")

    body_nodes = data.get("body_nodes")
    if not isinstance(body_nodes, list) or not body_nodes:
        raise PlanValidationError(f"Dify loop node {node_id!r} must define body_nodes as a non-empty array")
    body_edges = data.get("body_edges")
    if not isinstance(body_edges, list):
        raise PlanValidationError(f"Dify loop node {node_id!r} must define body_edges as an array")
    entry_nodes = data.get("entry_nodes")
    if not isinstance(entry_nodes, list) or not entry_nodes:
        raise PlanValidationError(f"Dify loop node {node_id!r} must define entry_nodes as a non-empty array")
    break_nodes = data.get("break_nodes")
    if not isinstance(break_nodes, list) or not break_nodes:
        raise PlanValidationError(f"Dify loop node {node_id!r} must define break_nodes as a non-empty array")

    combined_node_specs = dict(node_specs)
    body_node_specs: dict[str, dict[str, Any]] = {}
    for raw_node in body_nodes:
        if not isinstance(raw_node, dict):
            raise PlanValidationError(f"Dify loop node {node_id!r} body_nodes must only contain objects")
        child_id = raw_node.get("id")
        child_data = raw_node.get("data")
        if not isinstance(child_id, str) or not child_id:
            raise PlanValidationError(f"Dify loop node {node_id!r} body_nodes must define a non-empty string id")
        if not isinstance(child_data, dict):
            raise PlanValidationError(f"Dify loop node {node_id!r} body node {child_id!r} must define data")
        if child_id in combined_node_specs:
            raise PlanValidationError(f"Dify loop node {node_id!r} body node id {child_id!r} collides with outer graph")
        body_node_specs[child_id] = child_data
    combined_node_specs.update(body_node_specs)

    converted_body_nodes = [
        _serialize_node(
            _convert_body_node(
                node_id=str(raw_node["id"]),
                data=body_node_specs[str(raw_node["id"])],
                node_specs=combined_node_specs,
            )
        )
        for raw_node in body_nodes
    ]
    converted_body_edges = [_convert_body_edge(raw_edge, node_id=node_id) for raw_edge in body_edges]

    return Node(
        id=node_id,
        kind="loop",
        name=node_name,
        config={
            "max_iterations": max_iterations,
            "loop_variables": dict(raw_loop_variables),
            "body": {
                "nodes": converted_body_nodes,
                "edges": converted_body_edges,
                "entry_nodes": list(entry_nodes),
                "break_nodes": list(break_nodes),
            },
        },
    )


def _convert_body_node(*, node_id: str, data: dict[str, Any], node_specs: dict[str, dict[str, Any]]) -> Node:
    node_type = data.get("type")
    node_name = _extract_body_node_name(node_id=node_id, data=data)
    if node_type == "llm":
        return convert_llm_node(node_id=node_id, node_name=node_name, data=data, node_specs=node_specs)
    if node_type == "code":
        return convert_code_node(node_id=node_id, node_name=node_name, data=data, node_specs=node_specs)
    if node_type == "if-else":
        return convert_if_else_node(node_id=node_id, node_name=node_name, data=data, node_specs=node_specs)
    if node_type == "template-transform":
        return convert_template_transform_node(node_id=node_id, node_name=node_name, data=data, node_specs=node_specs)
    if node_type == "assigner":
        return convert_assigner_node(node_id=node_id, node_name=node_name, data=data, node_specs=node_specs)
    raise PlanValidationError(f"Dify loop body node {node_id!r} has unsupported type {node_type!r}")


def _extract_body_node_name(*, node_id: str, data: dict[str, Any]) -> str | None:
    raw_name = data.get("title")
    if raw_name is None:
        return None
    if not isinstance(raw_name, str) or not raw_name.strip():
        raise PlanValidationError(f"Dify loop body node {node_id!r} must define data.title as a non-empty string when provided")
    return raw_name.strip()


def _convert_body_edge(raw_edge: Any, *, node_id: str) -> dict[str, Any]:
    if not isinstance(raw_edge, dict):
        raise PlanValidationError(f"Dify loop node {node_id!r} body_edges must only contain objects")
    source = raw_edge.get("source")
    target = raw_edge.get("target")
    if not isinstance(source, str) or not isinstance(target, str):
        raise PlanValidationError(f"Dify loop node {node_id!r} body edge source and target must be strings")

    source_handle = raw_edge.get("sourceHandle")
    if isinstance(source_handle, bool):
        source_handle = "true" if source_handle else "false"
    if source_handle is not None and not isinstance(source_handle, str):
        raise PlanValidationError(f"Dify loop node {node_id!r} body edge sourceHandle must be a string when provided")

    edge_data = raw_edge.get("data")
    if not isinstance(edge_data, dict) or edge_data.get("sourceType") != "if-else":
        source_handle = None

    result = {"from": source, "to": target}
    if source_handle is not None:
        result["source_handle"] = source_handle
    return result


def _serialize_node(node: Node) -> dict[str, Any]:
    data: dict[str, Any] = {"id": node.id, "kind": node.kind}
    if node.name is not None:
        data["name"] = node.name
    if node.inputs or node.kind in {"template", "if_else"}:
        data["inputs"] = node.inputs
    if node.config:
        data["config"] = node.config
    return data
