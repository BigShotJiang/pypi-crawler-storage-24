from __future__ import annotations

from typing import Any

from dify_player.dify_importer.reference_converter import convert_value_selector
from dify_player.exceptions import PlanValidationError
from dify_player.models import Node


def convert_code_node(
    *,
    node_id: str,
    node_name: str | None,
    data: dict[str, Any],
    node_specs: dict[str, dict[str, Any]],
) -> Node:
    language = data.get("code_language")
    if language != "python3":
        raise PlanValidationError(f"Dify code node {node_id!r} only supports code_language=python3")

    source = data.get("code")
    if not isinstance(source, str):
        raise PlanValidationError(f"Dify code node {node_id!r} must define code as a string")

    raw_variables = data.get("variables", [])
    if raw_variables is None:
        raw_variables = []
    if not isinstance(raw_variables, list):
        raise PlanValidationError(f"Dify code node {node_id!r} variables must be an array")

    inputs: dict[str, Any] = {}
    for index, item in enumerate(raw_variables):
        if not isinstance(item, dict):
            raise PlanValidationError(f"Dify code node {node_id!r} variables[{index}] must be an object")
        variable = item.get("variable")
        if not isinstance(variable, str) or not variable:
            raise PlanValidationError(f"Dify code node {node_id!r} variables[{index}].variable must be a non-empty string")
        inputs[variable] = convert_value_selector(
            item.get("value_selector"),
            node_specs=node_specs,
            context=f"Dify code node {node_id!r} variables[{index}].value_selector",
        )

    raw_outputs = data.get("outputs")
    if not isinstance(raw_outputs, dict):
        raise PlanValidationError(f"Dify code node {node_id!r} must define outputs as an object")

    outputs: list[str] = []
    for output_name in raw_outputs:
        if not isinstance(output_name, str) or not output_name:
            raise PlanValidationError(f"Dify code node {node_id!r} outputs must use non-empty string keys")
        outputs.append(output_name)

    return Node(
        id=node_id,
        kind="code",
        name=node_name,
        inputs=inputs,
        config={
            "language": "python3",
            "source": source,
            "outputs": outputs,
        },
    )
