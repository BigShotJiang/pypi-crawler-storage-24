from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from dify_player.dify_importer.graph_parser import ParsedDifyGraph, parse_dify_graph
from dify_player.dify_importer.node_converters import (
    convert_code_node,
    convert_end_node,
    convert_http_request_node,
    convert_if_else_node,
    convert_llm_node,
    convert_loop_node,
    convert_start_node,
    convert_template_transform_node,
    convert_variable_aggregator_node,
)
from dify_player.dify_importer.workflow_normalizer import normalize_dify_workflow
from dify_player.exceptions import PlanValidationError
from dify_player.models import Edge, Plan


def load_dify_workflow_definition(path: Path) -> Plan:
    try:
        with path.open("r", encoding="utf-8") as handle:
            data = yaml.safe_load(handle)
    except yaml.YAMLError as exc:
        raise PlanValidationError(f"failed to parse Dify workflow YAML: {exc}") from exc
    return import_dify_workflow(data)


def import_dify_workflow(data: Any) -> Plan:
    parsed_graph = parse_dify_graph(normalize_dify_workflow(data))
    nodes = [_convert_node(node_id=node_id, data=node_data, parsed_graph=parsed_graph) for node_id, node_data in parsed_graph.node_specs.items()]
    edges = [_convert_edge(raw_edge) for raw_edge in parsed_graph.raw_edges]
    return Plan(nodes=nodes, edges=edges, outputs={})


def _convert_node(*, node_id: str, data: dict[str, Any], parsed_graph: ParsedDifyGraph):
    node_type = data["type"]
    node_name = _extract_node_name(node_id=node_id, data=data)
    if node_type == "start":
        return convert_start_node(node_id=node_id, node_name=node_name)
    if node_type == "http-request":
        return convert_http_request_node(node_id=node_id, node_name=node_name, data=data, node_specs=parsed_graph.node_specs)
    if node_type == "llm":
        return convert_llm_node(node_id=node_id, node_name=node_name, data=data, node_specs=parsed_graph.node_specs)
    if node_type == "template-transform":
        return convert_template_transform_node(
            node_id=node_id,
            node_name=node_name,
            data=data,
            node_specs=parsed_graph.node_specs,
        )
    if node_type == "variable-aggregator":
        return convert_variable_aggregator_node(
            node_id=node_id,
            node_name=node_name,
            data=data,
            node_specs=parsed_graph.node_specs,
        )
    if node_type == "code":
        return convert_code_node(node_id=node_id, node_name=node_name, data=data, node_specs=parsed_graph.node_specs)
    if node_type == "loop":
        return convert_loop_node(node_id=node_id, node_name=node_name, data=data, node_specs=parsed_graph.node_specs)
    if node_type == "if-else":
        return convert_if_else_node(node_id=node_id, node_name=node_name, data=data, node_specs=parsed_graph.node_specs)
    if node_type == "end":
        return convert_end_node(node_id=node_id, node_name=node_name, data=data, node_specs=parsed_graph.node_specs)
    raise PlanValidationError(f"Dify node {node_id!r} has unsupported type {node_type!r}")


def _convert_edge(raw_edge: dict[str, Any]) -> Edge:
    source_handle = raw_edge.get("sourceHandle")
    if isinstance(source_handle, bool):
        source_handle = "true" if source_handle else "false"
    if source_handle is not None and not isinstance(source_handle, str):
        raise PlanValidationError("Dify graph edge sourceHandle must be a string when provided")
    edge_data = raw_edge.get("data")
    if not isinstance(edge_data, dict):
        edge_data = {}
    if edge_data.get("sourceType") != "if-else":
        source_handle = None
    return Edge(from_node=raw_edge["source"], to_node=raw_edge["target"], source_handle=source_handle)


def _extract_node_name(*, node_id: str, data: dict[str, Any]) -> str | None:
    raw_name = data.get("title")
    if raw_name is None:
        return None
    if not isinstance(raw_name, str) or not raw_name.strip():
        raise PlanValidationError(f"Dify node {node_id!r} must define data.title as a non-empty string when provided")
    return raw_name.strip()
