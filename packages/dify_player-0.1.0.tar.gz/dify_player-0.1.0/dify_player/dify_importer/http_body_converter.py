from __future__ import annotations

import json
from typing import Any

from dify_player.exceptions import PlanValidationError
from dify_player.dify_importer.reference_converter import convert_value, replace_embedded_dify_references


def convert_http_body(raw_body: Any, *, node_specs: dict[str, dict[str, Any]], context: str) -> Any | None:
    if raw_body in (None, ""):
        return None
    if not isinstance(raw_body, dict):
        return convert_value(raw_body, node_specs=node_specs, context=context)

    body_type = raw_body.get("type")
    if body_type == "none":
        return None
    if body_type == "json":
        return _convert_json_http_body(raw_body, node_specs=node_specs, context=context)

    if "data" not in raw_body:
        raise PlanValidationError(f"{context} must define data when body.type is not none")
    return convert_value(raw_body["data"], node_specs=node_specs, context=context)


def _convert_json_http_body(raw_body: dict[str, Any], *, node_specs: dict[str, dict[str, Any]], context: str) -> dict[str, Any] | list[Any]:
    raw_data = raw_body.get("data")
    if not isinstance(raw_data, list) or len(raw_data) != 1:
        raise PlanValidationError(f"{context} only supports a single raw JSON entry in Step 5")

    entry = raw_data[0]
    if not isinstance(entry, dict):
        raise PlanValidationError(f"{context} must contain object entries")
    if entry.get("key") != "":
        raise PlanValidationError(f"{context} only supports an empty key for raw JSON entries in Step 5")
    if entry.get("type") != "text":
        raise PlanValidationError(f"{context} only supports text raw JSON entries in Step 5")

    raw_value = entry.get("value")
    if not isinstance(raw_value, str) or not raw_value:
        raise PlanValidationError(f"{context} raw JSON entry must define a non-empty string value")

    converted_json_text = replace_embedded_dify_references(
        raw_value,
        node_specs=node_specs,
        context=f"{context} raw JSON value",
    )
    try:
        converted_body = json.loads(converted_json_text)
    except json.JSONDecodeError as exc:
        raise PlanValidationError(f"{context} raw JSON value must be valid JSON after reference conversion") from exc

    if not isinstance(converted_body, (dict, list)):
        raise PlanValidationError(f"{context} raw JSON value must decode to an object or array")
    return converted_body
