from __future__ import annotations

from typing import Any

from dify_player.models import Node, Plan


def plan_to_data(plan: Plan) -> dict[str, Any]:
    return {
        "nodes": [_node_to_data(node) for node in plan.nodes],
        "edges": [
            {
                **{"from": edge.from_node, "to": edge.to_node},
                **({"source_handle": edge.source_handle} if edge.source_handle is not None else {}),
            }
            for edge in plan.edges
        ],
        "outputs": plan.outputs,
    }


def _node_to_data(node: Node) -> dict[str, Any]:
    data: dict[str, Any] = {
        "id": node.id,
        "kind": node.kind,
    }
    if node.name is not None:
        data["name"] = node.name
    if node.kind in {"template", "http", "if_else", "end"}:
        data["inputs"] = node.inputs
    elif node.inputs:
        data["inputs"] = node.inputs
    if node.config:
        data["config"] = node.config
    return data
