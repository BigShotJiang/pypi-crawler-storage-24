from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from dify_player.exceptions import PlanValidationError

SUPPORTED_DIFY_NODE_TYPES = {
    "start",
    "http-request",
    "llm",
    "template-transform",
    "if-else",
    "variable-aggregator",
    "code",
    "loop",
    "end",
}


@dataclass(frozen=True)
class ParsedDifyGraph:
    node_specs: dict[str, dict[str, Any]]
    raw_edges: list[dict[str, Any]]


def parse_dify_graph(data: Any) -> ParsedDifyGraph:
    if not isinstance(data, dict):
        raise PlanValidationError("Dify workflow YAML must be an object at the top level")
    if data.get("kind") != "app":
        raise PlanValidationError("Dify workflow YAML must define kind=app")

    app = data.get("app")
    if not isinstance(app, dict) or app.get("mode") != "workflow":
        raise PlanValidationError("Dify workflow YAML must define app.mode=workflow")

    workflow = data.get("workflow")
    if not isinstance(workflow, dict):
        raise PlanValidationError("Dify workflow YAML must define workflow")

    graph = workflow.get("graph")
    if not isinstance(graph, dict):
        raise PlanValidationError("Dify workflow YAML must define workflow.graph")

    raw_nodes = graph.get("nodes")
    raw_edges = graph.get("edges")
    if not isinstance(raw_nodes, list) or not raw_nodes:
        raise PlanValidationError("Dify workflow graph must define non-empty nodes")
    if not isinstance(raw_edges, list):
        raise PlanValidationError("Dify workflow graph must define edges as an array")

    return ParsedDifyGraph(
        node_specs=_build_node_specs(raw_nodes),
        raw_edges=[_parse_raw_edge(raw_edge) for raw_edge in raw_edges],
    )


def _build_node_specs(raw_nodes: list[Any]) -> dict[str, dict[str, Any]]:
    node_specs: dict[str, dict[str, Any]] = {}
    start_count = 0
    end_count = 0

    for raw_node in raw_nodes:
        if not isinstance(raw_node, dict):
            raise PlanValidationError("each Dify graph node must be an object")
        node_id = raw_node.get("id")
        data = raw_node.get("data")
        if not isinstance(node_id, str) or not node_id:
            raise PlanValidationError("each Dify graph node must define a non-empty string id")
        if not isinstance(data, dict):
            raise PlanValidationError(f"Dify node {node_id!r} must define data")

        node_type = data.get("type")
        if not isinstance(node_type, str) or not node_type:
            raise PlanValidationError(f"Dify node {node_id!r} must define data.type")
        if node_type not in SUPPORTED_DIFY_NODE_TYPES:
            raise PlanValidationError(f"Dify node {node_id!r} has unsupported type {node_type!r}")
        if node_id in node_specs:
            raise PlanValidationError(f"duplicate Dify node id {node_id!r}")

        if node_type == "start":
            start_count += 1
        if node_type == "end":
            end_count += 1

        node_specs[node_id] = data

    if start_count != 1:
        raise PlanValidationError("Dify workflow must contain exactly one start node")
    if end_count != 1:
        raise PlanValidationError("Dify workflow must contain exactly one end node")

    return node_specs


def _parse_raw_edge(raw_edge: Any) -> dict[str, Any]:
    if not isinstance(raw_edge, dict):
        raise PlanValidationError("each Dify graph edge must be an object")
    source = raw_edge.get("source")
    target = raw_edge.get("target")
    if not isinstance(source, str) or not isinstance(target, str):
        raise PlanValidationError("Dify graph edge source and target must be strings")
    return raw_edge
