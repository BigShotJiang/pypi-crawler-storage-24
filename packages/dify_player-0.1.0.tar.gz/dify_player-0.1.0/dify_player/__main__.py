from dify_player.cli import main


raise SystemExit(main())
