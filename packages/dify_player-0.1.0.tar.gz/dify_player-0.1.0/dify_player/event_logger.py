from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Protocol


class WorkflowLogger(Protocol):
    run_id: str

    def log(
        self,
        event: str,
        *,
        node_id: str | None = None,
        kind: str | None = None,
        status: str | None = None,
        error: str | None = None,
        **extra: Any,
    ) -> None: ...

    def close(self) -> None: ...


class EventLogger:
    def __init__(self, log_path: Path, run_id: str) -> None:
        self.log_path = log_path
        self.run_id = run_id
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self._handle = self.log_path.open("a", encoding="utf-8")

    def log(
        self,
        event: str,
        *,
        node_id: str | None = None,
        kind: str | None = None,
        status: str | None = None,
        error: str | None = None,
        **extra: Any,
    ) -> None:
        payload = {
            "ts": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "run_id": self.run_id,
            "event": event,
            "node_id": node_id,
            "kind": kind,
            "status": status,
            "error": error,
        }
        payload.update(extra)
        self._handle.write(json.dumps(payload, ensure_ascii=False) + "\n")
        self._handle.flush()

    def close(self) -> None:
        self._handle.close()


class NullEventLogger:
    def __init__(self, run_id: str) -> None:
        self.run_id = run_id

    def log(
        self,
        event: str,
        *,
        node_id: str | None = None,
        kind: str | None = None,
        status: str | None = None,
        error: str | None = None,
        **extra: Any,
    ) -> None:
        _ = event
        _ = node_id
        _ = kind
        _ = status
        _ = error
        _ = extra

    def close(self) -> None:
        return
