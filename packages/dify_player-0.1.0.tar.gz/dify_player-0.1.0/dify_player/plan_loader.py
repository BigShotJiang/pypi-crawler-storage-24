from __future__ import annotations

import json
from collections import deque
from pathlib import Path
from typing import Any

from jinja2 import meta

from dify_player.exceptions import PlanValidationError
from dify_player.models import ALLOWED_NODE_KINDS, CompiledLoop, CompiledPlan, Edge, Node, Plan, format_node_label
from dify_player.value_renderer import get_native_environment

LOOP_BODY_ALLOWED_NODE_KINDS = {"llm_azure_chat", "code", "if_else", "template", "assigner"}


def _load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def load_input_data(path: Path) -> dict[str, Any]:
    data = _load_json(path)
    if not isinstance(data, dict):
        raise PlanValidationError("input JSON must be an object at the top level")
    return data


def load_plan_definition(path: Path) -> Plan:
    data = _load_json(path)
    return parse_plan(data)


def load_plan(path: Path) -> CompiledPlan:
    plan = load_plan_definition(path)
    return compile_plan(plan)


# 生の JSON を Node / Edge / Plan に詰め替え、authoring 上の基本的な整合性を確認する。
def parse_plan(data: Any) -> Plan:
    if not isinstance(data, dict):
        raise PlanValidationError("plan JSON must be an object at the top level")

    raw_nodes = data.get("nodes")
    raw_edges = data.get("edges")
    raw_outputs = data.get("outputs", {})

    if not isinstance(raw_nodes, list) or not raw_nodes:
        raise PlanValidationError("plan.nodes must be a non-empty array")
    if not isinstance(raw_edges, list):
        raise PlanValidationError("plan.edges must be an array")
    if not isinstance(raw_outputs, dict):
        raise PlanValidationError("plan.outputs must be an object when provided")

    nodes: list[Node] = []
    for raw_node in raw_nodes:
        if not isinstance(raw_node, dict):
            raise PlanValidationError("each node must be an object")

        node_id = raw_node.get("id")
        kind = raw_node.get("kind")
        raw_name = raw_node.get("name")
        has_inputs = "inputs" in raw_node
        inputs = raw_node.get("inputs", {})
        config = raw_node.get("config", {})
        if not isinstance(node_id, str) or not node_id:
            raise PlanValidationError("node.id must be a non-empty string")
        name = _normalize_node_name(raw_name, node_id=node_id)
        node_label = format_node_label(node_id, name)
        if not isinstance(kind, str) or not kind:
            raise PlanValidationError(f"node.kind must be a non-empty string for node {node_id!r}")
        if kind not in ALLOWED_NODE_KINDS:
            raise PlanValidationError(f"unsupported node kind {kind!r} for node {node_id!r}")
        if kind in {"template", "http", "if_else", "end"} and not has_inputs:
            raise PlanValidationError(f"{kind} node {node_label!r} must define inputs as an object")
        if not isinstance(inputs, dict):
            raise PlanValidationError(f"node.inputs must be an object for node {node_label!r}")
        if not isinstance(config, dict):
            raise PlanValidationError(f"node.config must be an object for node {node_label!r}")
        normalized_config = dict(config)
        if kind == "template" and not isinstance(normalized_config.get("template"), str):
            raise PlanValidationError(f"template node {node_label!r} must define config.template as a string")
        if kind == "http":
            _validate_http_config(node_id=node_id, node_name=name, config=normalized_config)
        if kind == "if_else":
            _validate_if_else_config(node_id=node_id, node_name=name, config=normalized_config)
        if kind == "variable_aggregator":
            _validate_variable_aggregator_config(node_id=node_id, node_name=name, config=normalized_config)
        if kind == "code":
            _validate_code_config(node_id=node_id, node_name=name, config=normalized_config)
        if kind == "loop":
            _validate_loop_config(node_id=node_id, node_name=name, config=normalized_config)
        if kind == "llm_azure_chat":
            _validate_llm_azure_chat_config(node_id=node_id, node_name=name, config=normalized_config)
        if kind == "end" and not isinstance(normalized_config.get("outputs"), dict):
            raise PlanValidationError(f"end node {node_label!r} must define config.outputs as an object")
        node = Node(id=node_id, kind=kind, name=name, inputs=inputs, config=normalized_config)
        _validate_node_definition(node)
        nodes.append(node)

    edges: list[Edge] = []
    for raw_edge in raw_edges:
        if not isinstance(raw_edge, dict):
            raise PlanValidationError("each edge must be an object")
        from_node = raw_edge.get("from")
        to_node = raw_edge.get("to")
        source_handle = raw_edge.get("source_handle")
        if not isinstance(from_node, str) or not isinstance(to_node, str):
            raise PlanValidationError("edge.from and edge.to must be strings")
        if source_handle is not None and not isinstance(source_handle, str):
            raise PlanValidationError("edge.source_handle must be a string when provided")
        edges.append(Edge(from_node=from_node, to_node=to_node, source_handle=source_handle))

    return Plan(nodes=nodes, edges=edges, outputs=raw_outputs)


# Plan を実行用に前処理し、DAG 検証と依存関係解決済みの CompiledPlan に変換する。
def compile_plan(plan: Plan) -> CompiledPlan:
    node_by_id: dict[str, Node] = {}
    for node in plan.nodes:
        if node.id in node_by_id:
            raise PlanValidationError(f"duplicate node id {node.id!r}")
        node_by_id[node.id] = node

    start_nodes = [node.id for node in plan.nodes if node.kind == "start"]
    end_nodes = [node.id for node in plan.nodes if node.kind == "end"]
    if len(start_nodes) != 1:
        raise PlanValidationError("plan must contain exactly one start node")
    if len(end_nodes) != 1:
        raise PlanValidationError("plan must contain exactly one end node")

    incoming_by_node = {node_id: [] for node_id in node_by_id}
    outgoing_by_node = {node_id: [] for node_id in node_by_id}
    incoming_edges_by_node = {node_id: [] for node_id in node_by_id}
    outgoing_edges_by_node = {node_id: [] for node_id in node_by_id}
    for edge in plan.edges:
        if edge.from_node not in node_by_id:
            raise PlanValidationError(f"edge references unknown from node {edge.from_node!r}")
        if edge.to_node not in node_by_id:
            raise PlanValidationError(f"edge references unknown to node {edge.to_node!r}")
        source_node = node_by_id[edge.from_node]
        if source_node.kind == "if_else":
            if edge.source_handle is None:
                raise PlanValidationError(f"edge from if_else node {source_node.label!r} must define source_handle")
        elif edge.source_handle is not None:
            raise PlanValidationError(f"edge from node {source_node.label!r} must not define source_handle")
        outgoing_by_node[edge.from_node].append(edge.to_node)
        incoming_by_node[edge.to_node].append(edge.from_node)
        outgoing_edges_by_node[edge.from_node].append(edge)
        incoming_edges_by_node[edge.to_node].append(edge)

    start_node_id = start_nodes[0]
    end_node_id = end_nodes[0]
    if incoming_by_node[start_node_id]:
        raise PlanValidationError("start node must not have incoming edges")
    if outgoing_by_node[end_node_id]:
        raise PlanValidationError("end node must not have outgoing edges")

    reachable_from_start = _walk_graph(start_node_id, outgoing_by_node)
    if len(reachable_from_start) != len(node_by_id):
        unreachable = _format_node_list(set(node_by_id) - reachable_from_start, node_by_id=node_by_id)
        raise PlanValidationError(f"all nodes must be reachable from start; unreachable: {unreachable}")

    can_reach_end = _walk_graph(end_node_id, incoming_by_node)
    if len(can_reach_end) != len(node_by_id):
        dead_end = _format_node_list(set(node_by_id) - can_reach_end, node_by_id=node_by_id)
        raise PlanValidationError(f"all nodes must be able to reach end; disconnected: {dead_end}")

    execution_order = _topological_sort(node_by_id, incoming_by_node, outgoing_by_node)

    compiled_loops_by_node = {
        node.id: _compile_loop(node=node, outer_node_ids=set(node_by_id) - {node.id})
        for node in plan.nodes
        if node.kind == "loop"
    }

    return CompiledPlan(
        plan=plan,
        node_by_id=node_by_id,
        incoming_by_node=incoming_by_node,
        outgoing_by_node=outgoing_by_node,
        incoming_edges_by_node=incoming_edges_by_node,
        outgoing_edges_by_node=outgoing_edges_by_node,
        execution_order=execution_order,
        start_node_id=start_node_id,
        end_node_id=end_node_id,
        compiled_loops_by_node=compiled_loops_by_node,
    )


def _walk_graph(origin: str, adjacency: dict[str, list[str]]) -> set[str]:
    visited: set[str] = set()
    stack = [origin]
    while stack:
        node_id = stack.pop()
        if node_id in visited:
            continue
        visited.add(node_id)
        stack.extend(adjacency[node_id])
    return visited


def _walk_graph_many(origins: list[str], adjacency: dict[str, list[str]]) -> set[str]:
    visited: set[str] = set()
    stack = list(origins)
    while stack:
        node_id = stack.pop()
        if node_id in visited:
            continue
        visited.add(node_id)
        stack.extend(adjacency[node_id])
    return visited


def _topological_sort(
    node_by_id: dict[str, Node],
    incoming_by_node: dict[str, list[str]],
    outgoing_by_node: dict[str, list[str]],
) -> list[str]:
    indegree = {node_id: len(incoming) for node_id, incoming in incoming_by_node.items()}
    queue = deque(sorted(node_id for node_id, degree in indegree.items() if degree == 0))
    order: list[str] = []

    while queue:
        node_id = queue.popleft()
        order.append(node_id)
        for successor in sorted(outgoing_by_node[node_id]):
            indegree[successor] -= 1
            if indegree[successor] == 0:
                queue.append(successor)

    if len(order) != len(node_by_id):
        raise PlanValidationError("plan must be a DAG without cycles")
    return order


def _validate_node_definition(node: Node) -> None:
    if node.kind == "start":
        if node.inputs:
            raise PlanValidationError(f"start node {node.label!r} must not define inputs")
        return

    if node.kind == "template":
        _validate_allowed_roots(
            node.config["template"],
            allowed_roots={"inputs"},
            location=f"template node {node.label!r} config.template",
        )
    elif node.kind == "end":
        _validate_allowed_roots(
            node.config["outputs"],
            allowed_roots={"inputs"},
            location=f"end node {node.label!r} config.outputs",
        )
    elif node.kind == "if_else":
        _validate_if_else_inputs(node)
    elif node.kind == "variable_aggregator":
        if node.inputs:
            raise PlanValidationError(f"variable_aggregator node {node.label!r} must not define inputs")
    elif node.kind == "code":
        if not isinstance(node.config.get("source"), str):
            raise PlanValidationError(f"code node {node.label!r} must define config.source as a string")
    elif node.kind == "loop":
        if node.inputs:
            raise PlanValidationError(f"loop node {node.label!r} must not define inputs")
    elif node.kind == "llm_azure_chat":
        _validate_allowed_roots(
            node.config["messages"],
            allowed_roots={"inputs", "nodes"},
            location=f"llm node {node.label!r} config.messages",
        )

    if node.kind == "http" and "url" not in node.inputs:
        raise PlanValidationError(f"http node {node.label!r} must define inputs.url")

    _validate_allowed_roots(
        node.inputs,
        allowed_roots={"inputs", "nodes"},
        location=f"node {node.label!r} inputs",
    )


def _validate_allowed_roots(value: Any, *, allowed_roots: set[str], location: str) -> None:
    disallowed = sorted(_collect_roots(value) - allowed_roots)
    if disallowed:
        allowed_label = ", ".join(sorted(allowed_roots))
        rejected_label = ", ".join(disallowed)
        raise PlanValidationError(f"{location} may only reference {allowed_label}; found {rejected_label}")


def _collect_roots(value: Any) -> set[str]:
    if isinstance(value, str):
        parsed = get_native_environment().parse(value)
        return set(meta.find_undeclared_variables(parsed))
    if isinstance(value, list):
        roots: set[str] = set()
        for item in value:
            roots.update(_collect_roots(item))
        return roots
    if isinstance(value, dict):
        roots: set[str] = set()
        for item in value.values():
            roots.update(_collect_roots(item))
        return roots
    return set()


def _validate_http_config(*, node_id: str, node_name: str | None, config: dict[str, Any]) -> None:
    node_label = format_node_label(node_id, node_name)
    allowed_keys = {"method", "timeout_sec"}
    extra_keys = sorted(set(config) - allowed_keys)
    if extra_keys:
        raise PlanValidationError(
            f"http node {node_label!r} config may only define method and timeout_sec; found {', '.join(extra_keys)}"
        )

    method = config.get("method")
    if not isinstance(method, str) or not method:
        raise PlanValidationError(f"http node {node_label!r} must define config.method as GET or POST")

    normalized_method = method.upper()
    if normalized_method not in {"GET", "POST"}:
        raise PlanValidationError(f"http node {node_label!r} config.method must be GET or POST")
    config["method"] = normalized_method

    if "timeout_sec" in config:
        timeout_sec = config["timeout_sec"]
        if isinstance(timeout_sec, bool) or not isinstance(timeout_sec, int) or timeout_sec <= 0:
            raise PlanValidationError(f"http node {node_label!r} config.timeout_sec must be a positive integer")


def _validate_if_else_config(*, node_id: str, node_name: str | None, config: dict[str, Any]) -> None:
    node_label = format_node_label(node_id, node_name)
    if set(config) != {"cases"}:
        extra_keys = sorted(set(config) - {"cases"})
        if "cases" not in config:
            raise PlanValidationError(f"if_else node {node_label!r} must define config.cases")
        raise PlanValidationError(f"if_else node {node_label!r} config has unsupported keys: {', '.join(extra_keys)}")

    cases = config.get("cases")
    if not isinstance(cases, list) or not cases:
        raise PlanValidationError(f"if_else node {node_label!r} config.cases must be a non-empty array")
    for case_index, case in enumerate(cases):
        if not isinstance(case, dict):
            raise PlanValidationError(f"if_else node {node_label!r} config.cases[{case_index}] must be an object")
        case_id = case.get("case_id")
        if not isinstance(case_id, str) or not case_id:
            raise PlanValidationError(f"if_else node {node_label!r} config.cases[{case_index}].case_id must be a non-empty string")
        if case.get("logical_operator") != "and":
            raise PlanValidationError(f"if_else node {node_label!r} only supports logical_operator=and")
        conditions = case.get("conditions")
        if not isinstance(conditions, list) or not conditions:
            raise PlanValidationError(
                f"if_else node {node_label!r} config.cases[{case_index}].conditions must be a non-empty array"
            )
        for condition_index, condition in enumerate(conditions):
            if not isinstance(condition, dict):
                raise PlanValidationError(
                    f"if_else node {node_label!r} config.cases[{case_index}].conditions[{condition_index}] must be an object"
                )
            if condition.get("operator") not in {"contains", "equals"}:
                raise PlanValidationError(f"if_else node {node_label!r} only supports operator=contains or equals")
            input_name = condition.get("input_name")
            if not isinstance(input_name, str) or not input_name:
                raise PlanValidationError(
                    f"if_else node {node_label!r} config.cases[{case_index}].conditions[{condition_index}].input_name must be a non-empty string"
                )
            value = condition.get("value")
            if not isinstance(value, str):
                raise PlanValidationError(
                    f"if_else node {node_label!r} config.cases[{case_index}].conditions[{condition_index}].value must be a string"
                )


def _validate_if_else_inputs(node: Node) -> None:
    input_names = set(node.inputs)
    for case_index, case in enumerate(node.config["cases"]):
        for condition_index, condition in enumerate(case["conditions"]):
            if condition["input_name"] not in input_names:
                raise PlanValidationError(
                    f"if_else node {node.label!r} config.cases[{case_index}].conditions[{condition_index}] references unknown input_name {condition['input_name']!r}"
                )


def _validate_variable_aggregator_config(*, node_id: str, node_name: str | None, config: dict[str, Any]) -> None:
    node_label = format_node_label(node_id, node_name)
    allowed_keys = {"output_type", "candidates"}
    extra_keys = sorted(set(config) - allowed_keys)
    if extra_keys:
        raise PlanValidationError(
            f"variable_aggregator node {node_label!r} config has unsupported keys: {', '.join(extra_keys)}"
        )

    if config.get("output_type") != "string":
        raise PlanValidationError(f"variable_aggregator node {node_label!r} only supports config.output_type=string")

    candidates = config.get("candidates")
    if not isinstance(candidates, list) or not candidates:
        raise PlanValidationError(f"variable_aggregator node {node_label!r} config.candidates must be a non-empty array")
    for index, candidate in enumerate(candidates):
        if not isinstance(candidate, dict):
            raise PlanValidationError(
                f"variable_aggregator node {node_label!r} config.candidates[{index}] must be an object"
            )
        node_ref = candidate.get("node_id")
        output_key = candidate.get("output_key")
        if not isinstance(node_ref, str) or not node_ref:
            raise PlanValidationError(
                f"variable_aggregator node {node_label!r} config.candidates[{index}].node_id must be a non-empty string"
            )
        if not isinstance(output_key, str) or not output_key:
            raise PlanValidationError(
                f"variable_aggregator node {node_label!r} config.candidates[{index}].output_key must be a non-empty string"
            )


def _validate_code_config(*, node_id: str, node_name: str | None, config: dict[str, Any]) -> None:
    node_label = format_node_label(node_id, node_name)
    allowed_keys = {"language", "source", "outputs"}
    extra_keys = sorted(set(config) - allowed_keys)
    if extra_keys:
        raise PlanValidationError(f"code node {node_label!r} config has unsupported keys: {', '.join(extra_keys)}")

    if config.get("language") != "python3":
        raise PlanValidationError(f"code node {node_label!r} only supports config.language=python3")

    source = config.get("source")
    if not isinstance(source, str):
        raise PlanValidationError(f"code node {node_label!r} must define config.source as a string")

    outputs = config.get("outputs")
    if not isinstance(outputs, list):
        raise PlanValidationError(f"code node {node_label!r} must define config.outputs as an array")
    for index, item in enumerate(outputs):
        if not isinstance(item, str) or not item:
            raise PlanValidationError(f"code node {node_label!r} config.outputs[{index}] must be a non-empty string")


def _validate_loop_config(*, node_id: str, node_name: str | None, config: dict[str, Any]) -> None:
    node_label = format_node_label(node_id, node_name)
    allowed_keys = {"max_iterations", "loop_variables", "body"}
    extra_keys = sorted(set(config) - allowed_keys)
    if extra_keys:
        raise PlanValidationError(f"loop node {node_label!r} config has unsupported keys: {', '.join(extra_keys)}")

    max_iterations = config.get("max_iterations")
    if isinstance(max_iterations, bool) or not isinstance(max_iterations, int) or max_iterations <= 0:
        raise PlanValidationError(f"loop node {node_label!r} config.max_iterations must be a positive integer")

    loop_variables = config.get("loop_variables")
    if not isinstance(loop_variables, dict) or not loop_variables:
        raise PlanValidationError(f"loop node {node_label!r} config.loop_variables must be a non-empty object")
    for key in loop_variables:
        if not isinstance(key, str) or not key:
            raise PlanValidationError(f"loop node {node_label!r} config.loop_variables keys must be non-empty strings")

    body = config.get("body")
    if not isinstance(body, dict):
        raise PlanValidationError(f"loop node {node_label!r} must define config.body as an object")
    if set(body) != {"nodes", "edges", "entry_nodes", "break_nodes"}:
        raise PlanValidationError(
            f"loop node {node_label!r} config.body must define exactly nodes, edges, entry_nodes, break_nodes"
        )

    raw_body_nodes = body.get("nodes")
    raw_body_edges = body.get("edges")
    entry_nodes = body.get("entry_nodes")
    break_nodes = body.get("break_nodes")
    if not isinstance(raw_body_nodes, list) or not raw_body_nodes:
        raise PlanValidationError(f"loop node {node_label!r} config.body.nodes must be a non-empty array")
    if not isinstance(raw_body_edges, list):
        raise PlanValidationError(f"loop node {node_label!r} config.body.edges must be an array")
    if not isinstance(entry_nodes, list) or not entry_nodes:
        raise PlanValidationError(f"loop node {node_label!r} config.body.entry_nodes must be a non-empty array")
    if not isinstance(break_nodes, list) or not break_nodes:
        raise PlanValidationError(f"loop node {node_label!r} config.body.break_nodes must be a non-empty array")
    for index, item in enumerate(entry_nodes):
        if not isinstance(item, str) or not item:
            raise PlanValidationError(f"loop node {node_label!r} config.body.entry_nodes[{index}] must be a non-empty string")
    for index, item in enumerate(break_nodes):
        if not isinstance(item, str) or not item:
            raise PlanValidationError(f"loop node {node_label!r} config.body.break_nodes[{index}] must be a non-empty string")

    _parse_loop_body_nodes(raw_body_nodes, node_label=node_label)


def _compile_loop(*, node: Node, outer_node_ids: set[str]) -> CompiledLoop:
    node_label = node.label
    body = node.config["body"]
    body_nodes = _parse_loop_body_nodes(body["nodes"], node_label=node_label)

    body_node_by_id: dict[str, Node] = {}
    for body_node in body_nodes:
        if body_node.id in outer_node_ids:
            raise PlanValidationError(f"loop node {node_label!r} body node id {body_node.id!r} collides with outer graph")
        if body_node.id in body_node_by_id:
            raise PlanValidationError(f"loop node {node_label!r} has duplicate body node id {body_node.id!r}")
        body_node_by_id[body_node.id] = body_node

    incoming_by_node = {body_node_id: [] for body_node_id in body_node_by_id}
    outgoing_by_node = {body_node_id: [] for body_node_id in body_node_by_id}
    incoming_edges_by_node = {body_node_id: [] for body_node_id in body_node_by_id}
    outgoing_edges_by_node = {body_node_id: [] for body_node_id in body_node_by_id}
    for raw_edge in body["edges"]:
        edge = _parse_loop_body_edge(raw_edge, node_label=node_label, node_by_id=body_node_by_id)
        source_node = body_node_by_id[edge.from_node]
        if source_node.kind == "if_else":
            if edge.source_handle is None:
                raise PlanValidationError(f"loop node {node_label!r} body edge from if_else node {source_node.label!r} must define source_handle")
        elif edge.source_handle is not None:
            raise PlanValidationError(f"loop node {node_label!r} body edge from node {source_node.label!r} must not define source_handle")
        outgoing_by_node[edge.from_node].append(edge.to_node)
        incoming_by_node[edge.to_node].append(edge.from_node)
        outgoing_edges_by_node[edge.from_node].append(edge)
        incoming_edges_by_node[edge.to_node].append(edge)

    entry_node_ids = _validate_loop_body_boundary_nodes(
        raw_values=body["entry_nodes"],
        node_label=node_label,
        field_name="entry_nodes",
        node_by_id=body_node_by_id,
    )
    break_node_ids = _validate_loop_body_boundary_nodes(
        raw_values=body["break_nodes"],
        node_label=node_label,
        field_name="break_nodes",
        node_by_id=body_node_by_id,
    )

    reachable_from_entries = _walk_graph_many(entry_node_ids, outgoing_by_node)
    if len(reachable_from_entries) != len(body_node_by_id):
        unreachable = _format_node_list(set(body_node_by_id) - reachable_from_entries, node_by_id=body_node_by_id)
        raise PlanValidationError(f"loop node {node_label!r} body nodes must be reachable from entry_nodes; unreachable: {unreachable}")

    terminal_node_ids = [node_id for node_id, outgoing in outgoing_by_node.items() if not outgoing]
    targets = set(terminal_node_ids) | set(break_node_ids)
    reachable_to_exit = _walk_graph_many(list(targets), incoming_by_node)
    if len(reachable_to_exit) != len(body_node_by_id):
        disconnected = _format_node_list(set(body_node_by_id) - reachable_to_exit, node_by_id=body_node_by_id)
        raise PlanValidationError(f"loop node {node_label!r} body nodes must reach break_nodes or terminal nodes; disconnected: {disconnected}")

    execution_order = _topological_sort(body_node_by_id, incoming_by_node, outgoing_by_node)
    return CompiledLoop(
        max_iterations=node.config["max_iterations"],
        initial_loop_variables=dict(node.config["loop_variables"]),
        node_by_id=body_node_by_id,
        incoming_by_node=incoming_by_node,
        outgoing_by_node=outgoing_by_node,
        incoming_edges_by_node=incoming_edges_by_node,
        outgoing_edges_by_node=outgoing_edges_by_node,
        execution_order=execution_order,
        entry_node_ids=entry_node_ids,
        break_node_ids=break_node_ids,
    )


def _parse_loop_body_nodes(raw_body_nodes: list[Any], *, node_label: str) -> list[Node]:
    body_nodes: list[Node] = []
    for raw_node in raw_body_nodes:
        if not isinstance(raw_node, dict):
            raise PlanValidationError(f"loop node {node_label!r} config.body.nodes must only contain objects")
        node_id = raw_node.get("id")
        kind = raw_node.get("kind")
        raw_name = raw_node.get("name")
        has_inputs = "inputs" in raw_node
        inputs = raw_node.get("inputs", {})
        config = raw_node.get("config", {})
        if not isinstance(node_id, str) or not node_id:
            raise PlanValidationError(f"loop node {node_label!r} body node.id must be a non-empty string")
        name = _normalize_node_name(raw_name, node_id=node_id)
        body_node_label = format_node_label(node_id, name)
        if not isinstance(kind, str) or kind not in LOOP_BODY_ALLOWED_NODE_KINDS:
            raise PlanValidationError(f"loop node {node_label!r} has unsupported body node kind {kind!r} for node {node_id!r}")
        if kind in {"template", "if_else"} and not has_inputs:
            raise PlanValidationError(f"{kind} body node {body_node_label!r} must define inputs as an object")
        if not isinstance(inputs, dict):
            raise PlanValidationError(f"loop body node.inputs must be an object for node {body_node_label!r}")
        if not isinstance(config, dict):
            raise PlanValidationError(f"loop body node.config must be an object for node {body_node_label!r}")

        normalized_config = dict(config)
        if kind == "template" and not isinstance(normalized_config.get("template"), str):
            raise PlanValidationError(f"template body node {body_node_label!r} must define config.template as a string")
        if kind == "if_else":
            _validate_if_else_config(node_id=node_id, node_name=name, config=normalized_config)
        if kind == "code":
            _validate_code_config(node_id=node_id, node_name=name, config=normalized_config)
        if kind == "llm_azure_chat":
            _validate_llm_azure_chat_config(node_id=node_id, node_name=name, config=normalized_config)
        if kind == "assigner":
            _validate_assigner_config(node_id=node_id, node_name=name, config=normalized_config)
        node = Node(id=node_id, kind=kind, name=name, inputs=inputs, config=normalized_config)
        _validate_loop_body_node_definition(node)
        body_nodes.append(node)
    return body_nodes


def _parse_loop_body_edge(raw_edge: Any, *, node_label: str, node_by_id: dict[str, Node]) -> Edge:
    if not isinstance(raw_edge, dict):
        raise PlanValidationError(f"loop node {node_label!r} config.body.edges must only contain objects")
    from_node = raw_edge.get("from")
    to_node = raw_edge.get("to")
    source_handle = raw_edge.get("source_handle")
    if not isinstance(from_node, str) or not isinstance(to_node, str):
        raise PlanValidationError(f"loop node {node_label!r} body edge from/to must be strings")
    if from_node not in node_by_id or to_node not in node_by_id:
        raise PlanValidationError(f"loop node {node_label!r} body edge references unknown node")
    if source_handle is not None and not isinstance(source_handle, str):
        raise PlanValidationError(f"loop node {node_label!r} body edge source_handle must be a string when provided")
    return Edge(from_node=from_node, to_node=to_node, source_handle=source_handle)


def _validate_loop_body_boundary_nodes(
    *,
    raw_values: list[Any],
    node_label: str,
    field_name: str,
    node_by_id: dict[str, Node],
) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for index, item in enumerate(raw_values):
        if not isinstance(item, str) or not item:
            raise PlanValidationError(f"loop node {node_label!r} config.body.{field_name}[{index}] must be a non-empty string")
        if item not in node_by_id:
            raise PlanValidationError(f"loop node {node_label!r} config.body.{field_name}[{index}] references unknown body node {item!r}")
        if item in seen:
            continue
        seen.add(item)
        result.append(item)
    return result


def _validate_loop_body_node_definition(node: Node) -> None:
    if node.kind == "template":
        _validate_allowed_roots(
            node.config["template"],
            allowed_roots={"inputs"},
            location=f"loop body template node {node.label!r} config.template",
        )
    elif node.kind == "if_else":
        _validate_if_else_inputs(node)
    elif node.kind == "code":
        if not isinstance(node.config.get("source"), str):
            raise PlanValidationError(f"loop body code node {node.label!r} must define config.source as a string")
    elif node.kind == "llm_azure_chat":
        _validate_allowed_roots(
            node.config["messages"],
            allowed_roots={"inputs", "nodes"},
            location=f"loop body llm node {node.label!r} config.messages",
        )

    _validate_allowed_roots(
        node.inputs,
        allowed_roots={"inputs", "nodes"},
        location=f"loop body node {node.label!r} inputs",
    )


def _validate_assigner_config(*, node_id: str, node_name: str | None, config: dict[str, Any]) -> None:
    node_label = format_node_label(node_id, node_name)
    if set(config) != {"assignments"}:
        raise PlanValidationError(f"assigner node {node_label!r} config must define only assignments")
    assignments = config.get("assignments")
    if not isinstance(assignments, list) or not assignments:
        raise PlanValidationError(f"assigner node {node_label!r} config.assignments must be a non-empty array")
    for index, item in enumerate(assignments):
        if not isinstance(item, dict):
            raise PlanValidationError(f"assigner node {node_label!r} config.assignments[{index}] must be an object")
        input_name = item.get("input_name")
        target_name = item.get("target_name")
        if not isinstance(input_name, str) or not input_name:
            raise PlanValidationError(f"assigner node {node_label!r} config.assignments[{index}].input_name must be a non-empty string")
        if not isinstance(target_name, str) or not target_name:
            raise PlanValidationError(f"assigner node {node_label!r} config.assignments[{index}].target_name must be a non-empty string")
        if item.get("target_scope") != "loop_variable":
            raise PlanValidationError(f"assigner node {node_label!r} only supports target_scope=loop_variable")
        if item.get("operation") != "overwrite":
            raise PlanValidationError(f"assigner node {node_label!r} only supports operation=overwrite")


def _validate_llm_azure_chat_config(*, node_id: str, node_name: str | None, config: dict[str, Any]) -> None:
    node_label = format_node_label(node_id, node_name)
    allowed_keys = {
        "model",
        "messages",
        "response_format",
        "json_schema",
        "temperature",
        "top_p",
        "max_tokens",
        "timeout_sec",
    }
    extra_keys = sorted(set(config) - allowed_keys)
    if extra_keys:
        raise PlanValidationError(
            f"llm_azure_chat node {node_label!r} config has unsupported keys: {', '.join(extra_keys)}"
        )

    model = config.get("model")
    if not isinstance(model, str) or not model:
        raise PlanValidationError(f"llm_azure_chat node {node_label!r} must define config.model as a non-empty string")

    messages = config.get("messages")
    if not isinstance(messages, list) or not messages:
        raise PlanValidationError(f"llm_azure_chat node {node_label!r} must define config.messages as a non-empty array")
    for index, message in enumerate(messages):
        if not isinstance(message, dict):
            raise PlanValidationError(f"llm_azure_chat node {node_label!r} config.messages[{index}] must be an object")
        role = message.get("role")
        content = message.get("content")
        if not isinstance(role, str) or not role:
            raise PlanValidationError(
                f"llm_azure_chat node {node_label!r} config.messages[{index}].role must be a non-empty string"
            )
        if not isinstance(content, str):
            raise PlanValidationError(f"llm_azure_chat node {node_label!r} config.messages[{index}].content must be a string")

    response_format = config.get("response_format", "text")
    if not isinstance(response_format, str) or response_format not in {"text", "json_schema"}:
        raise PlanValidationError(f"llm_azure_chat node {node_label!r} config.response_format must be text or json_schema")
    config["response_format"] = response_format

    if response_format == "json_schema":
        json_schema = config.get("json_schema")
        if not isinstance(json_schema, dict):
            raise PlanValidationError(
                f"llm_azure_chat node {node_label!r} must define config.json_schema as an object"
            )
    elif "json_schema" in config and not isinstance(config["json_schema"], dict):
        raise PlanValidationError(f"llm_azure_chat node {node_label!r} config.json_schema must be an object")

    if "temperature" in config:
        temperature = config["temperature"]
        if isinstance(temperature, bool) or not isinstance(temperature, (int, float)):
            raise PlanValidationError(f"llm_azure_chat node {node_label!r} config.temperature must be a number")

    if "top_p" in config:
        top_p = config["top_p"]
        if isinstance(top_p, bool) or not isinstance(top_p, (int, float)):
            raise PlanValidationError(f"llm_azure_chat node {node_label!r} config.top_p must be a number")

    if "max_tokens" in config:
        max_tokens = config["max_tokens"]
        if isinstance(max_tokens, bool) or not isinstance(max_tokens, int) or max_tokens <= 0:
            raise PlanValidationError(f"llm_azure_chat node {node_label!r} config.max_tokens must be a positive integer")

    if "timeout_sec" in config:
        timeout_sec = config["timeout_sec"]
        if isinstance(timeout_sec, bool) or not isinstance(timeout_sec, int) or timeout_sec <= 0:
            raise PlanValidationError(f"llm_azure_chat node {node_label!r} config.timeout_sec must be a positive integer")


def _normalize_node_name(raw_name: Any, *, node_id: str) -> str | None:
    if raw_name is None:
        return None
    if not isinstance(raw_name, str) or not raw_name.strip():
        raise PlanValidationError(f"node.name must be a non-empty string for node {node_id!r}")
    return raw_name.strip()


def _format_node_list(node_ids: set[str], *, node_by_id: dict[str, Node]) -> str:
    return ", ".join(sorted(node_by_id[node_id].label for node_id in node_ids))
