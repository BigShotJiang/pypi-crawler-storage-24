from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _unused_local_url() -> str:
    return "http://127.0.0.1:65535/unreachable"


class CLITestCase(unittest.TestCase):
    def _env(self) -> dict[str, str]:
        env = os.environ.copy()
        existing = env.get("PYTHONPATH")
        env["PYTHONPATH"] = str(ROOT) if not existing else f"{ROOT}{os.pathsep}{existing}"
        return env

    def test_cli_success_with_default_log_path(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            result = subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "dify_player",
                    "run",
                    str(ROOT / "examples" / "hello" / "plan.json"),
                    str(ROOT / "examples" / "hello" / "input.json"),
                ],
                cwd=tmpdir,
                env=self._env(),
                capture_output=True,
                text=True,
                check=False,
            )

            self.assertEqual(result.returncode, 0, result.stderr)
            payload = json.loads(result.stdout)
            self.assertEqual(payload["status"], "succeeded")
            self.assertEqual(payload["outputs"], {"message": "Hello World"})
            self.assertIsNone(payload["error"])

            logs_dir = Path(tmpdir) / "logs"
            log_files = list(logs_dir.glob("*.jsonl"))
            self.assertEqual(len(log_files), 1)
            self.assertRegex(log_files[0].name, r"^\d{8}T\d{6}_[0-9a-f]{32}\.jsonl$")
            events = [json.loads(line) for line in log_files[0].read_text(encoding="utf-8").splitlines()]
            self.assertEqual(events[0]["event"], "run_started")
            self.assertEqual(events[0]["plan_path"], str(ROOT / "examples" / "hello" / "plan.json"))
            self.assertEqual(events[0]["input_path"], str(ROOT / "examples" / "hello" / "input.json"))
            self.assertEqual(events[-1]["event"], "run_succeeded")
            self.assertEqual(events[-1]["outputs"], {"message": "Hello World"})

    def test_cli_requires_arguments(self) -> None:
        result = subprocess.run(
            [sys.executable, "-m", "dify_player", "run"],
            cwd=ROOT,
            env=self._env(),
            capture_output=True,
            text=True,
            check=False,
        )

        self.assertNotEqual(result.returncode, 0)

    def test_cli_invalid_json_returns_non_zero(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            bad_input = Path(tmpdir) / "bad.json"
            log_path = Path(tmpdir) / "run.jsonl"
            bad_input.write_text("{not json", encoding="utf-8")

            result = subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "dify_player",
                    "run",
                    str(ROOT / "examples" / "hello" / "plan.json"),
                    str(bad_input),
                    "--log",
                    str(log_path),
                ],
                cwd=ROOT,
                env=self._env(),
                capture_output=True,
                text=True,
                check=False,
            )

            self.assertNotEqual(result.returncode, 0)
            payload = json.loads(result.stdout)
            self.assertEqual(payload["status"], "failed")
            self.assertEqual(payload["error"]["code"], "INPUT_LOAD_FAILED")
            self.assertIn("Expecting property name enclosed in double quotes", payload["error"]["message"])
            self.assertEqual(result.stderr, "")
            events = [json.loads(line) for line in log_path.read_text(encoding="utf-8").splitlines()]
            self.assertEqual(events[0]["event"], "run_started")
            self.assertEqual(events[-1]["event"], "run_failed")
            self.assertEqual(events[-1]["phase"], "load_input")
            self.assertEqual(events[-1]["error_code"], "INPUT_LOAD_FAILED")

    def test_cli_invalid_plan_logs_load_plan_failure(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            bad_plan = Path(tmpdir) / "bad-plan.json"
            log_path = Path(tmpdir) / "run.jsonl"
            bad_plan.write_text("{not json", encoding="utf-8")

            result = subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "dify_player",
                    "run",
                    str(bad_plan),
                    str(ROOT / "examples" / "hello" / "input.json"),
                    "--log",
                    str(log_path),
                ],
                cwd=ROOT,
                env=self._env(),
                capture_output=True,
                text=True,
                check=False,
            )

            self.assertNotEqual(result.returncode, 0)
            payload = json.loads(result.stdout)
            self.assertEqual(payload["status"], "failed")
            self.assertEqual(payload["error"]["code"], "PLAN_LOAD_FAILED")
            events = [json.loads(line) for line in log_path.read_text(encoding="utf-8").splitlines()]
            self.assertEqual(events[0]["event"], "run_started")
            self.assertEqual(events[-1]["event"], "run_failed")
            self.assertEqual(events[-1]["phase"], "load_plan")
            self.assertEqual(events[-1]["error_code"], "PLAN_LOAD_FAILED")

    def test_cli_compile_failure_logs_compile_phase(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            log_path = Path(tmpdir) / "run.jsonl"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "greet",
                                "kind": "template",
                                "inputs": {"name": "{{ inputs.name }}"},
                                "config": {"template": "Hello {{ inputs.name }}"},
                            },
                            {
                                "id": "again",
                                "kind": "template",
                                "inputs": {"name": "Again"},
                                "config": {"template": "{{ inputs.name }}"},
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {"message": "ok"},
                                "config": {"outputs": {"message": "{{ inputs.message }}"}},
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "greet"},
                            {"from": "greet", "to": "again"},
                            {"from": "again", "to": "greet"},
                            {"from": "greet", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )

            result = subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "dify_player",
                    "run",
                    str(plan_path),
                    str(ROOT / "examples" / "hello" / "input.json"),
                    "--log",
                    str(log_path),
                ],
                cwd=ROOT,
                env=self._env(),
                capture_output=True,
                text=True,
                check=False,
            )

            self.assertNotEqual(result.returncode, 0)
            payload = json.loads(result.stdout)
            self.assertEqual(payload["status"], "failed")
            self.assertEqual(payload["error"]["code"], "PLAN_COMPILE_FAILED")
            events = [json.loads(line) for line in log_path.read_text(encoding="utf-8").splitlines()]
            self.assertEqual(events[0]["event"], "run_started")
            self.assertEqual(events[-1]["event"], "run_failed")
            self.assertEqual(events[-1]["phase"], "compile")
            self.assertEqual(events[-1]["error_code"], "PLAN_COMPILE_FAILED")

    def test_cli_end_reference_failure_returns_non_zero(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            log_path = Path(tmpdir) / "run.jsonl"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "greet",
                                "kind": "template",
                                "inputs": {"name": "{{ inputs.name }}"},
                                "config": {"template": "Hello {{ inputs.name }}"},
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "name": "結果出力",
                                "inputs": {"message": "{{ nodes.missing.text }}"},
                                "config": {"outputs": {"message": "{{ inputs.message }}"}},
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "greet"},
                            {"from": "greet", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )

            result = subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "dify_player",
                    "run",
                    str(plan_path),
                    str(ROOT / "examples" / "hello" / "input.json"),
                    "--log",
                    str(log_path),
                ],
                cwd=ROOT,
                env=self._env(),
                capture_output=True,
                text=True,
                check=False,
            )

            self.assertNotEqual(result.returncode, 0)
            payload = json.loads(result.stdout)
            self.assertEqual(payload["status"], "failed")
            self.assertEqual(payload["error"]["code"], "INPUT_RESOLUTION_FAILED")
            self.assertEqual(payload["error"]["node_name"], "結果出力")
            self.assertEqual(result.stderr, "")

            events = [json.loads(line) for line in log_path.read_text(encoding="utf-8").splitlines()]
            self.assertEqual(events[-2]["event"], "node_failed")
            self.assertEqual(events[-2]["node_name"], "結果出力")
            self.assertEqual(events[-1]["event"], "run_failed")
            self.assertEqual(events[-1]["phase"], "runtime")
            self.assertEqual(events[-1]["error_code"], "INPUT_RESOLUTION_FAILED")

    def test_cli_http_network_failure_logs_runtime_phase(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            log_path = Path(tmpdir) / "run.jsonl"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "fetch",
                                "kind": "http",
                                "inputs": {"url": "{{ inputs.url }}"},
                                "config": {"method": "GET", "timeout_sec": 1},
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {"message": "unused"},
                                "config": {"outputs": {"message": "{{ inputs.message }}"}},
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "fetch"},
                            {"from": "fetch", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )
            input_path = Path(tmpdir) / "input.json"
            input_path.write_text(json.dumps({"url": _unused_local_url()}), encoding="utf-8")

            result = subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "dify_player",
                    "run",
                    str(plan_path),
                    str(input_path),
                    "--log",
                    str(log_path),
                ],
                cwd=ROOT,
                env=self._env(),
                capture_output=True,
                text=True,
                check=False,
            )

            self.assertNotEqual(result.returncode, 0)
            payload = json.loads(result.stdout)
            self.assertEqual(payload["status"], "failed")
            self.assertEqual(payload["error"]["code"], "HTTP_REQUEST_FAILED")
            events = [json.loads(line) for line in log_path.read_text(encoding="utf-8").splitlines()]
            self.assertEqual(events[-2]["event"], "node_failed")
            self.assertEqual(events[-1]["event"], "run_failed")
            self.assertEqual(events[-1]["phase"], "runtime")
            self.assertEqual(events[-1]["error_code"], "HTTP_REQUEST_FAILED")
            self.assertTrue(events[-1]["retryable"])

    def test_cli_import_writes_strict_plan_json(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            output_path = Path(tmpdir) / "generated" / "plan.json"

            result = subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "dify_player",
                    "import",
                    str(ROOT / "workflows" / "test_http_saas.yml"),
                    str(output_path),
                ],
                cwd=ROOT,
                env=self._env(),
                capture_output=True,
                text=True,
                check=False,
            )

            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout.strip(), str(output_path))
            self.assertTrue(output_path.exists())
            imported = json.loads(output_path.read_text(encoding="utf-8"))
            self.assertEqual(imported["nodes"][0], {"id": "1773064906498", "kind": "start", "name": "ユーザー入力"})
            self.assertEqual(imported["nodes"][1]["name"], "HTTP リクエスト")
            self.assertEqual(imported["nodes"][1]["config"], {"method": "GET"})
            self.assertEqual(imported["nodes"][2]["name"], "出力")
            self.assertEqual(imported["nodes"][2]["config"], {"outputs": {}})

    def test_cli_import_invalid_yaml_returns_non_zero(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            workflow_path = Path(tmpdir) / "workflow.yml"
            output_path = Path(tmpdir) / "plan.json"
            workflow_path.write_text("kind: app:\n", encoding="utf-8")

            result = subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "dify_player",
                    "import",
                    str(workflow_path),
                    str(output_path),
                ],
                cwd=ROOT,
                env=self._env(),
                capture_output=True,
                text=True,
                check=False,
            )

            self.assertNotEqual(result.returncode, 0)
            self.assertIn("failed to parse Dify workflow YAML", result.stderr)


if __name__ == "__main__":
    unittest.main()
