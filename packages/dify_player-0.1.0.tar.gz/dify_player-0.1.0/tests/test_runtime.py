from __future__ import annotations

import asyncio
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, Mock, patch

from dify_player.event_logger import EventLogger
from dify_player.exceptions import PlanValidationError
from dify_player.plan_loader import load_input_data, load_plan
from dify_player.runtime import WorkflowRuntime
from tests.workflow_http_server import HTTPServerContext

ROOT = Path(__file__).resolve().parents[1]


def _run_runtime(runtime: WorkflowRuntime, *, compiled_plan, inputs):
    return asyncio.run(runtime.run(compiled_plan=compiled_plan, inputs=inputs))


class RuntimeTestCase(unittest.TestCase):
    def test_code_node_executes_python_and_returns_declared_outputs(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "code",
                                "kind": "code",
                                "inputs": {
                                    "source_text": "{{ inputs.source_text }}",
                                    "translation_style": "{{ inputs.translation_style }}",
                                },
                                "config": {
                                    "language": "python3",
                                    "source": (
                                        "def main(source_text, translation_style):\n"
                                        "    return {\n"
                                        "        'summary': f'{translation_style}:{source_text.upper()}',\n"
                                        "        'length': len(source_text),\n"
                                        "    }\n"
                                    ),
                                    "outputs": ["summary", "length"],
                                },
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {
                                    "summary": "{{ nodes.code.summary }}",
                                    "length": "{{ nodes.code.length }}",
                                },
                                "config": {
                                    "outputs": {
                                        "summary": "{{ inputs.summary }}",
                                        "length": "{{ inputs.length }}",
                                    }
                                },
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "code"},
                            {"from": "code", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )

            compiled_plan = load_plan(plan_path)
            logger = EventLogger(log_path=Path(tmpdir) / "run.jsonl", run_id="code-node")
            runtime = WorkflowRuntime(logger=logger)
            try:
                result = _run_runtime(
                    runtime,
                    compiled_plan=compiled_plan,
                    inputs={"source_text": "hello", "translation_style": "Natural"},
                )
            finally:
                logger.close()

            self.assertEqual(result.status, "succeeded")
            self.assertEqual(result.outputs, {"summary": "Natural:HELLO", "length": 5})
            self.assertEqual(result.nodes["code"].outputs, {"summary": "Natural:HELLO", "length": 5})

    def test_code_node_fails_when_declared_output_is_missing(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "code",
                                "kind": "code",
                                "config": {
                                    "language": "python3",
                                    "source": "def main():\n    return {'summary': 'ok'}\n",
                                    "outputs": ["summary", "length"],
                                },
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {"summary": "unused"},
                                "config": {"outputs": {"summary": "{{ inputs.summary }}"}},
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "code"},
                            {"from": "code", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )

            compiled_plan = load_plan(plan_path)
            logger = EventLogger(log_path=Path(tmpdir) / "run.jsonl", run_id="code-node-missing-output")
            runtime = WorkflowRuntime(logger=logger)
            try:
                result = _run_runtime(runtime, compiled_plan=compiled_plan, inputs={})
            finally:
                logger.close()

            self.assertEqual(result.status, "failed")
            self.assertEqual(result.error.code, "NODE_EXECUTION_FAILED")
            self.assertIn("must return output 'length'", result.error.message)

    def test_code_node_awaits_async_main(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "code",
                                "kind": "code",
                                "inputs": {"name": "{{ inputs.name }}"},
                                "config": {
                                    "language": "python3",
                                    "source": (
                                        "import asyncio\n\n"
                                        "async def main(name):\n"
                                        "    await asyncio.sleep(0)\n"
                                        "    return {'message': f'Hello {name}'}\n"
                                    ),
                                    "outputs": ["message"],
                                },
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {"message": "{{ nodes.code.message }}"},
                                "config": {"outputs": {"message": "{{ inputs.message }}"}},
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "code"},
                            {"from": "code", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )

            compiled_plan = load_plan(plan_path)
            logger = EventLogger(log_path=Path(tmpdir) / "run.jsonl", run_id="code-node-async-main")
            runtime = WorkflowRuntime(logger=logger)
            try:
                result = _run_runtime(runtime, compiled_plan=compiled_plan, inputs={"name": "World"})
            finally:
                logger.close()

            self.assertEqual(result.status, "succeeded")
            self.assertEqual(result.outputs, {"message": "Hello World"})

    def test_llm_azure_chat_returns_text_and_renders_messages(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "classify",
                                "kind": "llm_azure_chat",
                                "config": {
                                    "model": "gpt-4o",
                                    "messages": [
                                        {"role": "system", "content": "Be concise"},
                                        {"role": "user", "content": "Classify {{ inputs.source_text }}"},
                                    ],
                                    "response_format": "text",
                                    "temperature": 0,
                                    "top_p": 1,
                                    "max_tokens": 256,
                                },
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {
                                    "text": "{{ nodes.classify.text }}",
                                },
                                "config": {"outputs": {"text": "{{ inputs.text }}"}},
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "classify"},
                            {"from": "classify", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )
            compiled_plan = load_plan(plan_path)
            response = Mock(status_code=200)
            response.text = json.dumps({"choices": [{"message": {"content": "SNS"}}]})

            logger = EventLogger(log_path=Path(tmpdir) / "run.jsonl", run_id="llm-text")
            runtime = WorkflowRuntime(logger=logger)
            try:
                with patch.dict(
                    os.environ,
                    {
                        "AZURE_OPENAI_ENDPOINT": "https://example.openai.azure.com",
                        "AZURE_OPENAI_API_KEY": "secret",
                        "AZURE_OPENAI_API_VERSION": "2024-10-21",
                    },
                    clear=False,
                ):
                    with patch(
                        "dify_player.nodes.llm_azure_chat.httpx.AsyncClient.post",
                        new_callable=AsyncMock,
                        return_value=response,
                    ) as mock_post:
                        result = _run_runtime(runtime, compiled_plan=compiled_plan, inputs={"source_text": "hello"})
            finally:
                logger.close()

            self.assertEqual(result.status, "succeeded")
            self.assertEqual(result.outputs, {"text": "SNS"})
            mock_post.assert_called_once()
            self.assertEqual(
                mock_post.call_args.kwargs["json"]["messages"],
                [
                    {"role": "system", "content": "Be concise"},
                    {"role": "user", "content": "Classify hello"},
                ],
            )
            self.assertEqual(mock_post.call_args.kwargs["params"], {"api-version": "2024-10-21"})

    def test_llm_azure_chat_returns_structured_output(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "detect",
                                "kind": "llm_azure_chat",
                                "config": {
                                    "model": "gpt-4o",
                                    "messages": [
                                        {"role": "user", "content": "Detect {{ inputs.source_text }}"},
                                    ],
                                    "response_format": "json_schema",
                                    "json_schema": {
                                        "type": "object",
                                        "properties": {"language": {"type": "string"}},
                                        "required": ["language"],
                                        "additionalProperties": False,
                                    },
                                },
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {
                                    "raw": "{{ nodes.detect.text }}",
                                    "language": "{{ nodes.detect.structured_output.language }}",
                                },
                                "config": {
                                    "outputs": {
                                        "raw": "{{ inputs.raw }}",
                                        "language": "{{ inputs.language }}",
                                    }
                                },
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "detect"},
                            {"from": "detect", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )
            compiled_plan = load_plan(plan_path)
            raw_text = '{"language":"Japanese"}'
            response = Mock(status_code=200)
            response.text = json.dumps({"choices": [{"message": {"content": raw_text}}]})

            logger = EventLogger(log_path=Path(tmpdir) / "run.jsonl", run_id="llm-structured")
            runtime = WorkflowRuntime(logger=logger)
            try:
                with patch.dict(
                    os.environ,
                    {
                        "AZURE_OPENAI_ENDPOINT": "https://example.openai.azure.com",
                        "AZURE_OPENAI_API_KEY": "secret",
                        "AZURE_OPENAI_API_VERSION": "2024-10-21",
                    },
                    clear=False,
                ):
                    with patch(
                        "dify_player.nodes.llm_azure_chat.httpx.AsyncClient.post",
                        new_callable=AsyncMock,
                        return_value=response,
                    ):
                        result = _run_runtime(runtime, compiled_plan=compiled_plan, inputs={"source_text": "hello"})
            finally:
                logger.close()

            self.assertEqual(result.status, "succeeded")
            self.assertEqual(result.outputs, {"raw": raw_text, "language": "Japanese"})
            self.assertEqual(
                result.nodes["detect"].outputs,
                {"text": raw_text, "structured_output": {"language": "Japanese"}},
            )

    def test_llm_azure_chat_fails_on_malformed_structured_output(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "detect",
                                "kind": "llm_azure_chat",
                                "config": {
                                    "model": "gpt-4o",
                                    "messages": [{"role": "user", "content": "Detect"}],
                                    "response_format": "json_schema",
                                    "json_schema": {
                                        "type": "object",
                                        "properties": {"language": {"type": "string"}},
                                        "required": ["language"],
                                    },
                                },
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {"message": "unused"},
                                "config": {"outputs": {"message": "{{ inputs.message }}"}},
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "detect"},
                            {"from": "detect", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )
            compiled_plan = load_plan(plan_path)
            response = Mock(status_code=200)
            response.text = json.dumps({"choices": [{"message": {"content": "{bad"}}]})

            logger = EventLogger(log_path=Path(tmpdir) / "run.jsonl", run_id="llm-bad-json")
            runtime = WorkflowRuntime(logger=logger)
            try:
                with patch.dict(
                    os.environ,
                    {
                        "AZURE_OPENAI_ENDPOINT": "https://example.openai.azure.com",
                        "AZURE_OPENAI_API_KEY": "secret",
                        "AZURE_OPENAI_API_VERSION": "2024-10-21",
                    },
                    clear=False,
                ):
                    with patch(
                        "dify_player.nodes.llm_azure_chat.httpx.AsyncClient.post",
                        new_callable=AsyncMock,
                        return_value=response,
                    ):
                        result = _run_runtime(runtime, compiled_plan=compiled_plan, inputs={})
            finally:
                logger.close()

            self.assertEqual(result.status, "failed")
            self.assertEqual(result.error.code, "NODE_EXECUTION_FAILED")
            self.assertIn("malformed structured output", result.error.message)
            self.assertEqual(len(result.error.details["attempts"]), 2)

    def test_llm_azure_chat_fails_on_schema_mismatch(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "detect",
                                "kind": "llm_azure_chat",
                                "config": {
                                    "model": "gpt-4o",
                                    "messages": [{"role": "user", "content": "Detect"}],
                                    "response_format": "json_schema",
                                    "json_schema": {
                                        "type": "object",
                                        "properties": {"language": {"type": "string"}},
                                        "required": ["language"],
                                        "additionalProperties": False,
                                    },
                                },
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {"message": "unused"},
                                "config": {"outputs": {"message": "{{ inputs.message }}"}},
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "detect"},
                            {"from": "detect", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )
            compiled_plan = load_plan(plan_path)
            response = Mock(status_code=200)
            response.text = json.dumps({"choices": [{"message": {"content": '{"language":false}'}}]})

            logger = EventLogger(log_path=Path(tmpdir) / "run.jsonl", run_id="llm-schema")
            runtime = WorkflowRuntime(logger=logger)
            try:
                with patch.dict(
                    os.environ,
                    {
                        "AZURE_OPENAI_ENDPOINT": "https://example.openai.azure.com",
                        "AZURE_OPENAI_API_KEY": "secret",
                        "AZURE_OPENAI_API_VERSION": "2024-10-21",
                    },
                    clear=False,
                ):
                    with patch(
                        "dify_player.nodes.llm_azure_chat.httpx.AsyncClient.post",
                        new_callable=AsyncMock,
                        return_value=response,
                    ):
                        result = _run_runtime(runtime, compiled_plan=compiled_plan, inputs={})
            finally:
                logger.close()

            self.assertEqual(result.status, "failed")
            self.assertEqual(result.error.code, "NODE_EXECUTION_FAILED")
            self.assertIn("must be a string", result.error.message)
            self.assertEqual(len(result.error.details["attempts"]), 2)

    def test_llm_azure_chat_repairs_structured_output_once(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "detect",
                                "kind": "llm_azure_chat",
                                "config": {
                                    "model": "gpt-4o",
                                    "messages": [{"role": "user", "content": "Detect"}],
                                    "response_format": "json_schema",
                                    "json_schema": {
                                        "type": "object",
                                        "properties": {"language": {"type": "string"}},
                                        "required": ["language"],
                                        "additionalProperties": False,
                                    },
                                },
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {"language": "{{ nodes.detect.structured_output.language }}"},
                                "config": {"outputs": {"language": "{{ inputs.language }}"}},
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "detect"},
                            {"from": "detect", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )
            compiled_plan = load_plan(plan_path)
            first_response = Mock(status_code=200)
            first_response.text = json.dumps({"choices": [{"message": {"content": "{}"}}]})
            second_response = Mock(status_code=200)
            second_response.text = json.dumps({"choices": [{"message": {"content": '{"language":"Japanese"}'}}]})

            logger = EventLogger(log_path=Path(tmpdir) / "run.jsonl", run_id="llm-repair")
            runtime = WorkflowRuntime(logger=logger)
            try:
                with patch.dict(
                    os.environ,
                    {
                        "AZURE_OPENAI_ENDPOINT": "https://example.openai.azure.com",
                        "AZURE_OPENAI_API_KEY": "secret",
                        "AZURE_OPENAI_API_VERSION": "2024-10-21",
                    },
                    clear=False,
                ):
                    with patch(
                        "dify_player.nodes.llm_azure_chat.httpx.AsyncClient.post",
                        new_callable=AsyncMock,
                        side_effect=[first_response, second_response],
                    ) as mock_post:
                        result = _run_runtime(runtime, compiled_plan=compiled_plan, inputs={})
            finally:
                logger.close()

            self.assertEqual(result.status, "succeeded")
            self.assertEqual(result.outputs, {"language": "Japanese"})
            self.assertEqual(mock_post.call_count, 2)
            retry_messages = mock_post.call_args_list[1].kwargs["json"]["messages"]
            self.assertIn("Validation error:", retry_messages[-1]["content"])
            self.assertIn("Previous response:", retry_messages[-1]["content"])

    def test_llm_azure_chat_includes_http_error_details(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "detect",
                                "kind": "llm_azure_chat",
                                "name": "Document Classifier",
                                "config": {
                                    "model": "gpt-4o",
                                    "messages": [{"role": "user", "content": "Detect"}],
                                    "response_format": "text",
                                },
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {"message": "unused"},
                                "config": {"outputs": {"message": "{{ inputs.message }}"}},
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "detect"},
                            {"from": "detect", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )
            compiled_plan = load_plan(plan_path)
            response = Mock(status_code=400)
            response.text = json.dumps(
                {
                    "error": {
                        "code": "context_length_exceeded",
                        "message": "The input is too long for this model.",
                    }
                }
            )

            logger = EventLogger(log_path=Path(tmpdir) / "run.jsonl", run_id="llm-bad-status")
            runtime = WorkflowRuntime(logger=logger)
            try:
                with patch.dict(
                    os.environ,
                    {
                        "AZURE_OPENAI_ENDPOINT": "https://example.openai.azure.com",
                        "AZURE_OPENAI_API_KEY": "secret",
                        "AZURE_OPENAI_API_VERSION": "2024-10-21",
                    },
                    clear=False,
                ):
                    with patch(
                        "dify_player.nodes.llm_azure_chat.httpx.AsyncClient.post",
                        new_callable=AsyncMock,
                        return_value=response,
                    ):
                        result = _run_runtime(runtime, compiled_plan=compiled_plan, inputs={})
            finally:
                logger.close()

            self.assertEqual(result.status, "failed")
            self.assertEqual(result.error.code, "LLM_BAD_STATUS")
            self.assertIn("context_length_exceeded", result.error.message)
            self.assertIn("The input is too long", result.error.message)
            self.assertEqual(result.error.details["status_code"], 400)
            self.assertIn("context_length_exceeded", result.error.details["response_body"])

    def test_llm_azure_chat_requires_json_schema_for_json_schema_format(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "detect",
                                "kind": "llm_azure_chat",
                                "config": {
                                    "model": "gpt-4o",
                                    "messages": [{"role": "user", "content": "Detect"}],
                                    "response_format": "json_schema",
                                },
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {"message": "unused"},
                                "config": {"outputs": {"message": "{{ inputs.message }}"}},
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "detect"},
                            {"from": "detect", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )

            with self.assertRaisesRegex(PlanValidationError, "config.json_schema"):
                load_plan(plan_path)

    def test_successful_run_returns_outputs_and_logs_events(self) -> None:
        compiled_plan = load_plan(ROOT / "examples" / "hello" / "plan.json")
        inputs = load_input_data(ROOT / "examples" / "hello" / "input.json")

        with tempfile.TemporaryDirectory() as tmpdir:
            log_path = Path(tmpdir) / "run.jsonl"
            logger = EventLogger(log_path=log_path, run_id="run-1")
            runtime = WorkflowRuntime(logger=logger)
            try:
                result = _run_runtime(runtime, compiled_plan=compiled_plan, inputs=inputs)
            finally:
                logger.close()

            self.assertEqual(result.status, "succeeded")
            self.assertEqual(result.outputs, {"message": "Hello World"})
            self.assertIsNone(result.error)
            self.assertEqual(result.nodes["greet"].resolved_inputs, {"name": "World"})
            self.assertEqual(result.nodes["end"].resolved_inputs, {"message": "Hello World"})
            events = [json.loads(line) for line in log_path.read_text(encoding="utf-8").splitlines()]
            self.assertEqual(
                [event["event"] for event in events],
                [
                    "node_started",
                    "node_succeeded",
                    "node_started",
                    "node_succeeded",
                    "node_started",
                    "node_succeeded",
                ],
            )
            self.assertEqual(events[2]["resolved_inputs"], {"name": "World"})
            self.assertEqual(events[4]["resolved_inputs"], {"message": "Hello World"})
            self.assertIsNone(events[0]["node_name"])

    def test_unknown_node_kind_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {"id": "bad", "kind": "llm"},
                            {"id": "end", "kind": "end", "inputs": {"message": "ok"}, "config": {"outputs": {}}},
                        ],
                        "edges": [
                            {"from": "start", "to": "bad"},
                            {"from": "bad", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )

            with self.assertRaisesRegex(PlanValidationError, "unsupported node kind"):
                load_plan(plan_path)

    def test_if_else_selects_true_branch_and_skips_false_branch(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "branch",
                                "kind": "if_else",
                                "inputs": {"style": "{{ inputs.translation_style }}"},
                                "config": {
                                    "cases": [
                                        {
                                            "case_id": "literal",
                                            "logical_operator": "and",
                                            "conditions": [
                                                {
                                                    "operator": "contains",
                                                    "input_name": "style",
                                                    "value": "Literal",
                                                }
                                            ],
                                        }
                                    ]
                                },
                            },
                            {
                                "id": "literal",
                                "kind": "template",
                                "inputs": {"name": "literal"},
                                "config": {"template": "{{ inputs.name }}"},
                            },
                            {
                                "id": "other",
                                "kind": "template",
                                "inputs": {"name": "other"},
                                "config": {"template": "{{ inputs.name }}"},
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {"message": "done"},
                                "config": {"outputs": {"message": "{{ inputs.message }}"}},
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "branch"},
                            {"from": "branch", "to": "literal", "source_handle": "literal"},
                            {"from": "branch", "to": "other", "source_handle": "false"},
                            {"from": "literal", "to": "end"},
                            {"from": "other", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )
            compiled_plan = load_plan(plan_path)

            logger = EventLogger(log_path=Path(tmpdir) / "run.jsonl", run_id="if-else-true")
            runtime = WorkflowRuntime(logger=logger)
            try:
                result = _run_runtime(runtime, compiled_plan=compiled_plan, inputs={"translation_style": "Literal"})
            finally:
                logger.close()

            self.assertEqual(result.status, "succeeded")
            self.assertEqual(result.outputs, {"message": "done"})
            self.assertEqual(result.nodes["branch"].outputs["selected_handle"], "literal")
            self.assertEqual(result.nodes["literal"].outputs, {"text": "literal"})
            self.assertEqual(result.nodes["other"].status, "skipped")

    def test_if_else_selects_false_branch(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "branch",
                                "kind": "if_else",
                                "inputs": {"style": "{{ inputs.translation_style }}"},
                                "config": {
                                    "cases": [
                                        {
                                            "case_id": "literal",
                                            "logical_operator": "and",
                                            "conditions": [
                                                {
                                                    "operator": "contains",
                                                    "input_name": "style",
                                                    "value": "Literal",
                                                }
                                            ],
                                        }
                                    ]
                                },
                            },
                            {
                                "id": "literal",
                                "kind": "template",
                                "inputs": {"name": "literal"},
                                "config": {"template": "{{ inputs.name }}"},
                            },
                            {
                                "id": "other",
                                "kind": "template",
                                "inputs": {"name": "other"},
                                "config": {"template": "{{ inputs.name }}"},
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {"message": "done"},
                                "config": {"outputs": {"message": "{{ inputs.message }}"}},
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "branch"},
                            {"from": "branch", "to": "literal", "source_handle": "literal"},
                            {"from": "branch", "to": "other", "source_handle": "false"},
                            {"from": "literal", "to": "end"},
                            {"from": "other", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )
            compiled_plan = load_plan(plan_path)

            logger = EventLogger(log_path=Path(tmpdir) / "run.jsonl", run_id="if-else-false")
            runtime = WorkflowRuntime(logger=logger)
            try:
                result = _run_runtime(runtime, compiled_plan=compiled_plan, inputs={"translation_style": "Natural"})
            finally:
                logger.close()

            self.assertEqual(result.status, "succeeded")
            self.assertEqual(result.outputs, {"message": "done"})
            self.assertEqual(result.nodes["branch"].outputs["selected_handle"], "false")
            self.assertEqual(result.nodes["other"].outputs, {"text": "other"})
            self.assertEqual(result.nodes["literal"].status, "skipped")

    def test_if_else_equals_matches_number_like_string(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "branch",
                                "kind": "if_else",
                                "inputs": {"seg_match": "{{ inputs.seg_match }}"},
                                "config": {
                                    "cases": [
                                        {
                                            "case_id": "matched",
                                            "logical_operator": "and",
                                            "conditions": [
                                                {
                                                    "operator": "equals",
                                                    "input_name": "seg_match",
                                                    "value": "1",
                                                }
                                            ],
                                        }
                                    ]
                                },
                            },
                            {
                                "id": "matched",
                                "kind": "template",
                                "inputs": {"name": "matched"},
                                "config": {"template": "{{ inputs.name }}"},
                            },
                            {
                                "id": "other",
                                "kind": "template",
                                "inputs": {"name": "other"},
                                "config": {"template": "{{ inputs.name }}"},
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {"message": "done"},
                                "config": {"outputs": {"message": "{{ inputs.message }}"}},
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "branch"},
                            {"from": "branch", "to": "matched", "source_handle": "matched"},
                            {"from": "branch", "to": "other", "source_handle": "false"},
                            {"from": "matched", "to": "end"},
                            {"from": "other", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )
            compiled_plan = load_plan(plan_path)

            logger = EventLogger(log_path=Path(tmpdir) / "run.jsonl", run_id="if-else-equals")
            runtime = WorkflowRuntime(logger=logger)
            try:
                result = _run_runtime(runtime, compiled_plan=compiled_plan, inputs={"seg_match": 1})
            finally:
                logger.close()

            self.assertEqual(result.status, "succeeded")
            self.assertEqual(result.nodes["branch"].outputs["selected_handle"], "matched")
            self.assertEqual(result.nodes["matched"].outputs, {"text": "matched"})
            self.assertEqual(result.nodes["other"].status, "skipped")

    def test_variable_aggregator_picks_first_available_candidate(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "branch",
                                "kind": "if_else",
                                "inputs": {"style": "{{ inputs.translation_style }}"},
                                "config": {
                                    "cases": [
                                        {
                                            "case_id": "literal",
                                            "logical_operator": "and",
                                            "conditions": [
                                                {
                                                    "operator": "contains",
                                                    "input_name": "style",
                                                    "value": "Literal",
                                                }
                                            ],
                                        }
                                    ]
                                },
                            },
                            {
                                "id": "literal",
                                "kind": "template",
                                "inputs": {"name": "literal"},
                                "config": {"template": "{{ inputs.name }}"},
                            },
                            {
                                "id": "other",
                                "kind": "template",
                                "inputs": {"name": "other"},
                                "config": {"template": "{{ inputs.name }}"},
                            },
                            {
                                "id": "aggregate",
                                "kind": "variable_aggregator",
                                "config": {
                                    "output_type": "string",
                                    "candidates": [
                                        {"node_id": "literal", "output_key": "text"},
                                        {"node_id": "other", "output_key": "text"},
                                    ],
                                },
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {"message": "{{ nodes.aggregate.output }}"},
                                "config": {"outputs": {"message": "{{ inputs.message }}"}},
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "branch"},
                            {"from": "branch", "to": "literal", "source_handle": "literal"},
                            {"from": "branch", "to": "other", "source_handle": "false"},
                            {"from": "literal", "to": "aggregate"},
                            {"from": "other", "to": "aggregate"},
                            {"from": "aggregate", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )
            compiled_plan = load_plan(plan_path)

            logger = EventLogger(log_path=Path(tmpdir) / "run.jsonl", run_id="variable-aggregator")
            runtime = WorkflowRuntime(logger=logger)
            try:
                result = _run_runtime(runtime, compiled_plan=compiled_plan, inputs={"translation_style": "Natural"})
            finally:
                logger.close()

            self.assertEqual(result.status, "succeeded")
            self.assertEqual(result.outputs, {"message": "other"})
            self.assertEqual(result.nodes["aggregate"].outputs, {"output": "other"})

    def test_isolated_node_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "greet",
                                "kind": "template",
                                "inputs": {"name": "{{ inputs.name }}"},
                                "config": {"template": "Hello {{ inputs.name }}"},
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {"message": "ok"},
                                "config": {"outputs": {"message": "{{ inputs.message }}"}},
                            },
                            {
                                "id": "unused",
                                "kind": "template",
                                "inputs": {"name": "Nope"},
                                "config": {"template": "Hello {{ inputs.name }}"},
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "greet"},
                            {"from": "greet", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )

            with self.assertRaisesRegex(PlanValidationError, "reachable from start"):
                load_plan(plan_path)

    def test_cycle_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "greet",
                                "kind": "template",
                                "inputs": {"name": "Hello"},
                                "config": {"template": "{{ inputs.name }}"},
                            },
                            {
                                "id": "again",
                                "kind": "template",
                                "inputs": {"name": "Again"},
                                "config": {"template": "{{ inputs.name }}"},
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {"message": "ok"},
                                "config": {"outputs": {"message": "{{ inputs.message }}"}},
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "greet"},
                            {"from": "greet", "to": "again"},
                            {"from": "again", "to": "greet"},
                            {"from": "greet", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )

            with self.assertRaisesRegex(PlanValidationError, "DAG without cycles"):
                load_plan(plan_path)

    def test_missing_edge_reference_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {"id": "end", "kind": "end", "inputs": {"message": "ok"}, "config": {"outputs": {}}},
                        ],
                        "edges": [
                            {"from": "start", "to": "missing"},
                        ],
                    }
                ),
                encoding="utf-8",
            )

            with self.assertRaisesRegex(PlanValidationError, "unknown to node"):
                load_plan(plan_path)

    def test_template_inputs_reference_failure_logs_node_failed_and_run_failed(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "greet",
                                "kind": "template",
                                "inputs": {"name": "{{ inputs.missing }}"},
                                "config": {"template": "Hello {{ inputs.name }}"},
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {"message": "unused"},
                                "config": {"outputs": {"message": "{{ inputs.message }}"}},
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "greet"},
                            {"from": "greet", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )
            compiled_plan = load_plan(plan_path)

            logger = EventLogger(log_path=Path(tmpdir) / "run.jsonl", run_id="run-2")
            runtime = WorkflowRuntime(logger=logger)
            try:
                result = _run_runtime(runtime, compiled_plan=compiled_plan, inputs={"name": "World"})
            finally:
                logger.close()

            self.assertEqual(result.status, "failed")
            self.assertEqual(result.error.code, "INPUT_RESOLUTION_FAILED")
            self.assertIn("inputs.name references missing value", result.error.message)
            events = [
                json.loads(line) for line in (Path(tmpdir) / "run.jsonl").read_text(encoding="utf-8").splitlines()
            ]
            self.assertEqual(events[-1]["event"], "node_failed")
            self.assertIn("inputs.name references missing value", events[-1]["error"])

    def test_template_requires_inputs(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {"id": "greet", "kind": "template", "config": {"template": "Hello {{ inputs.name }}"}},
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {"message": "ok"},
                                "config": {"outputs": {"message": "{{ inputs.message }}"}},
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "greet"},
                            {"from": "greet", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )

            with self.assertRaisesRegex(PlanValidationError, "must define inputs"):
                load_plan(plan_path)

    def test_node_inputs_must_be_object(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "greet",
                                "kind": "template",
                                "inputs": "not-an-object",
                                "config": {"template": "Hello {{ inputs.name }}"},
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {"message": "ok"},
                                "config": {"outputs": {"message": "{{ inputs.message }}"}},
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "greet"},
                            {"from": "greet", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )

            with self.assertRaisesRegex(PlanValidationError, "node.inputs must be an object"):
                load_plan(plan_path)

    def test_node_name_must_be_non_empty_string_when_provided(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "greet",
                                "kind": "template",
                                "name": "   ",
                                "inputs": {"name": "{{ inputs.name }}"},
                                "config": {"template": "Hello {{ inputs.name }}"},
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {"message": "ok"},
                                "config": {"outputs": {"message": "{{ inputs.message }}"}},
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "greet"},
                            {"from": "greet", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )

            with self.assertRaisesRegex(PlanValidationError, "node.name must be a non-empty string"):
                load_plan(plan_path)

    def test_template_config_rejects_global_nodes_reference(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "greet",
                                "kind": "template",
                                "inputs": {"name": "{{ inputs.name }}"},
                                "config": {"template": "Hello {{ nodes.start.name }}"},
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {"message": "unused"},
                                "config": {"outputs": {"message": "{{ inputs.message }}"}},
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "greet"},
                            {"from": "greet", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )

            with self.assertRaisesRegex(PlanValidationError, "may only reference inputs"):
                load_plan(plan_path)

    def test_http_get_returns_response_shape(self) -> None:
        with HTTPServerContext() as (base_url, requests_log):
            with tempfile.TemporaryDirectory() as tmpdir:
                plan_path = Path(tmpdir) / "plan.json"
                input_path = Path(tmpdir) / "input.json"
                plan_path.write_text(
                    json.dumps(
                        {
                            "nodes": [
                                {"id": "start", "kind": "start"},
                                {
                                    "id": "fetch",
                                    "kind": "http",
                                    "inputs": {
                                        "url": "{{ inputs.url }}",
                                        "headers": {"Authorization": "{{ inputs.auth_header }}"},
                                        "params": {"q": "{{ inputs.query }}"},
                                    },
                                    "config": {"method": "get", "timeout_sec": 30},
                                },
                                {
                                    "id": "end",
                                    "kind": "end",
                                    "inputs": {
                                        "status": "{{ nodes.fetch.status }}",
                                        "headers": "{{ nodes.fetch.headers }}",
                                        "payload": "{{ nodes.fetch.json }}"
                                    },
                                    "config": {
                                        "outputs": {
                                            "status": "{{ inputs.status }}",
                                            "query": "{{ inputs.payload.query }}",
                                            "ok": "{{ inputs.payload.ok }}",
                                            "content_type": "{{ inputs.headers['content-type'] }}"
                                        }
                                    },
                                },
                            ],
                            "edges": [
                                {"from": "start", "to": "fetch"},
                                {"from": "fetch", "to": "end"},
                            ],
                        }
                    ),
                    encoding="utf-8",
                )
                input_path.write_text(
                    json.dumps(
                        {
                            "url": f"{base_url}/json",
                            "auth_header": "Bearer token",
                            "query": "hello",
                        }
                    ),
                    encoding="utf-8",
                )

                compiled_plan = load_plan(plan_path)
                inputs = load_input_data(input_path)

                logger = EventLogger(log_path=Path(tmpdir) / "run.jsonl", run_id="http-get")
                runtime = WorkflowRuntime(logger=logger)
                try:
                    result = _run_runtime(runtime, compiled_plan=compiled_plan, inputs=inputs)
                finally:
                    logger.close()

                self.assertEqual(
                    result.outputs,
                    {
                        "status": 200,
                        "query": "hello",
                        "ok": True,
                        "content_type": "application/json",
                    },
                )
                self.assertEqual(requests_log[0]["method"], "GET")
                self.assertEqual(requests_log[0]["query"], {"q": ["hello"]})
                self.assertEqual(requests_log[0]["headers"]["Authorization"], "Bearer token")

    def test_http_post_sends_json_body(self) -> None:
        with HTTPServerContext() as (base_url, requests_log):
            with tempfile.TemporaryDirectory() as tmpdir:
                plan_path = Path(tmpdir) / "plan.json"
                input_path = Path(tmpdir) / "input.json"
                plan_path.write_text(
                    json.dumps(
                        {
                            "nodes": [
                                {"id": "start", "kind": "start"},
                                {
                                    "id": "fetch",
                                    "kind": "http",
                                    "inputs": {
                                        "url": "{{ inputs.url }}",
                                        "body": "{{ inputs.payload }}"
                                    },
                                    "config": {"method": "POST"},
                                },
                                {
                                    "id": "end",
                                    "kind": "end",
                                    "inputs": {
                                        "received": "{{ nodes.fetch.json.received }}"
                                    },
                                    "config": {
                                        "outputs": {
                                            "received": "{{ inputs.received }}"
                                        }
                                    },
                                },
                            ],
                            "edges": [
                                {"from": "start", "to": "fetch"},
                                {"from": "fetch", "to": "end"},
                            ],
                        }
                    ),
                    encoding="utf-8",
                )
                input_path.write_text(
                    json.dumps(
                        {
                            "url": f"{base_url}/echo",
                            "payload": {"name": "World"},
                        }
                    ),
                    encoding="utf-8",
                )

                compiled_plan = load_plan(plan_path)
                inputs = load_input_data(input_path)

                logger = EventLogger(log_path=Path(tmpdir) / "run.jsonl", run_id="http-post")
                runtime = WorkflowRuntime(logger=logger)
                try:
                    result = _run_runtime(runtime, compiled_plan=compiled_plan, inputs=inputs)
                finally:
                    logger.close()

                self.assertEqual(result.status, "succeeded")
                self.assertEqual(result.outputs, {"received": {"name": "World"}})
                self.assertEqual(requests_log[0]["method"], "POST")
                self.assertEqual(json.loads(str(requests_log[0]["body"])), {"name": "World"})

    def test_http_get_rejects_body(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "fetch",
                                "kind": "http",
                                "inputs": {
                                    "url": "{{ inputs.url }}",
                                    "body": "{{ inputs.payload }}"
                                },
                                "config": {"method": "GET"},
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {"message": "unused"},
                                "config": {"outputs": {"message": "{{ inputs.message }}"}},
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "fetch"},
                            {"from": "fetch", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )
            compiled_plan = load_plan(plan_path)

            logger = EventLogger(log_path=Path(tmpdir) / "run.jsonl", run_id="http-get-body")
            runtime = WorkflowRuntime(logger=logger)
            try:
                result = _run_runtime(
                    runtime,
                    compiled_plan=compiled_plan,
                    inputs={"url": "http://example.invalid", "payload": "x"},
                )
            finally:
                logger.close()

            self.assertEqual(result.status, "failed")
            self.assertEqual(result.error.code, "NODE_EXECUTION_FAILED")

    def test_http_method_validation_rejects_invalid_method(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "fetch",
                                "kind": "http",
                                "inputs": {"url": "{{ inputs.url }}"},
                                "config": {"method": "DELETE"},
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {"message": "unused"},
                                "config": {"outputs": {"message": "{{ inputs.message }}"}},
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "fetch"},
                            {"from": "fetch", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )

            with self.assertRaisesRegex(PlanValidationError, "config.method must be GET or POST"):
                load_plan(plan_path)

    def test_http_timeout_validation_rejects_non_positive_integer(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "fetch",
                                "kind": "http",
                                "inputs": {"url": "{{ inputs.url }}"},
                                "config": {"method": "GET", "timeout_sec": 0},
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {"message": "unused"},
                                "config": {"outputs": {"message": "{{ inputs.message }}"}},
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "fetch"},
                            {"from": "fetch", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )

            with self.assertRaisesRegex(PlanValidationError, "config.timeout_sec must be a positive integer"):
                load_plan(plan_path)

    def test_http_404_logs_node_failed(self) -> None:
        with HTTPServerContext() as (base_url, _requests_log):
            with tempfile.TemporaryDirectory() as tmpdir:
                plan_path = Path(tmpdir) / "plan.json"
                plan_path.write_text(
                    json.dumps(
                        {
                            "nodes": [
                                {"id": "start", "kind": "start"},
                                {
                                    "id": "fetch",
                                    "kind": "http",
                                    "name": "HTTP リクエスト",
                                    "inputs": {"url": "{{ inputs.url }}"},
                                    "config": {"method": "GET"},
                                },
                                {
                                    "id": "end",
                                    "kind": "end",
                                    "inputs": {"message": "unused"},
                                    "config": {"outputs": {"message": "{{ inputs.message }}"}},
                                },
                            ],
                            "edges": [
                                {"from": "start", "to": "fetch"},
                                {"from": "fetch", "to": "end"},
                            ],
                        }
                    ),
                    encoding="utf-8",
                )
                compiled_plan = load_plan(plan_path)
                logger = EventLogger(log_path=Path(tmpdir) / "run.jsonl", run_id="http-404")
                runtime = WorkflowRuntime(logger=logger)
                try:
                    result = _run_runtime(runtime, compiled_plan=compiled_plan, inputs={"url": f"{base_url}/not-found"})
                finally:
                    logger.close()

                self.assertEqual(result.status, "failed")
                self.assertEqual(result.error.code, "HTTP_BAD_STATUS")
                self.assertEqual(result.error.node_name, "HTTP リクエスト")
                events = [json.loads(line) for line in (Path(tmpdir) / "run.jsonl").read_text(encoding="utf-8").splitlines()]
                self.assertEqual(events[-1]["event"], "node_failed")
                self.assertEqual(events[-1]["node_id"], "fetch")
                self.assertEqual(events[-1]["node_name"], "HTTP リクエスト")

    def test_http_missing_url_reports_input_reference_error(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "fetch",
                                "kind": "http",
                                "name": "HTTP リクエスト",
                                "inputs": {"url": "{{ inputs.url }}"},
                                "config": {"method": "GET"},
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {"message": "unused"},
                                "config": {"outputs": {"message": "{{ inputs.message }}"}},
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "fetch"},
                            {"from": "fetch", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )
            compiled_plan = load_plan(plan_path)
            logger = EventLogger(log_path=Path(tmpdir) / "run.jsonl", run_id="missing-url")
            runtime = WorkflowRuntime(logger=logger)
            try:
                result = _run_runtime(runtime, compiled_plan=compiled_plan, inputs={})
            finally:
                logger.close()

            self.assertEqual(result.status, "failed")
            self.assertEqual(result.error.code, "INPUT_RESOLUTION_FAILED")
            self.assertIn("inputs.url references missing value", result.error.message)
            events = [json.loads(line) for line in (Path(tmpdir) / "run.jsonl").read_text(encoding="utf-8").splitlines()]
            self.assertEqual(events[-1]["event"], "node_failed")
            self.assertIn("inputs.url references missing value", events[-1]["error"])
            self.assertNotIn("not JSON serializable", events[-1]["error"])

    def test_loop_node_breaks_on_second_iteration_and_exposes_final_outputs(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            log_path = Path(tmpdir) / "run.jsonl"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "loop",
                                "kind": "loop",
                                "config": {
                                    "max_iterations": 3,
                                    "loop_variables": {"count": 0, "message": "init"},
                                    "body": {
                                        "nodes": [
                                            {
                                                "id": "inc",
                                                "kind": "code",
                                                "inputs": {"count": "{{ nodes['loop'].count }}"},
                                                "config": {
                                                    "language": "python3",
                                                    "source": (
                                                        "def main(count):\n"
                                                        "    next_count = count + 1\n"
                                                        "    return {\n"
                                                        "        'count': next_count,\n"
                                                        "        'message': f'iter-{next_count}',\n"
                                                        "        'is_done': next_count == 2,\n"
                                                        "    }\n"
                                                    ),
                                                    "outputs": ["count", "message", "is_done"],
                                                },
                                            },
                                            {
                                                "id": "assign",
                                                "kind": "assigner",
                                                "inputs": {
                                                    "count": "{{ nodes['inc'].count }}",
                                                    "message": "{{ nodes['inc'].message }}",
                                                },
                                                "config": {
                                                    "assignments": [
                                                        {
                                                            "input_name": "count",
                                                            "target_name": "count",
                                                            "target_scope": "loop_variable",
                                                            "operation": "overwrite",
                                                        },
                                                        {
                                                            "input_name": "message",
                                                            "target_name": "message",
                                                            "target_scope": "loop_variable",
                                                            "operation": "overwrite",
                                                        },
                                                    ]
                                                },
                                            },
                                            {
                                                "id": "branch",
                                                "kind": "if_else",
                                                "inputs": {"done": "{{ nodes['inc'].is_done }}"},
                                                "config": {
                                                    "cases": [
                                                        {
                                                            "case_id": "done",
                                                            "logical_operator": "and",
                                                            "conditions": [
                                                                {
                                                                    "operator": "equals",
                                                                    "input_name": "done",
                                                                    "value": "True",
                                                                }
                                                            ],
                                                        }
                                                    ]
                                                },
                                            },
                                            {
                                                "id": "done",
                                                "kind": "template",
                                                "inputs": {},
                                                "config": {"template": "done"},
                                            },
                                            {
                                                "id": "continue",
                                                "kind": "template",
                                                "inputs": {},
                                                "config": {"template": "continue"},
                                            },
                                        ],
                                        "edges": [
                                            {"from": "inc", "to": "assign"},
                                            {"from": "assign", "to": "branch"},
                                            {"from": "branch", "to": "done", "source_handle": "done"},
                                            {"from": "branch", "to": "continue", "source_handle": "false"},
                                        ],
                                        "entry_nodes": ["inc"],
                                        "break_nodes": ["done"],
                                    },
                                },
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {
                                    "count": "{{ nodes['loop'].count }}",
                                    "message": "{{ nodes['loop'].message }}",
                                },
                                "config": {
                                    "outputs": {
                                        "count": "{{ inputs.count }}",
                                        "message": "{{ inputs.message }}",
                                    }
                                },
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "loop"},
                            {"from": "loop", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )
            compiled_plan = load_plan(plan_path)
            logger = EventLogger(log_path=log_path, run_id="loop-break")
            runtime = WorkflowRuntime(logger=logger)
            try:
                result = _run_runtime(runtime, compiled_plan=compiled_plan, inputs={})
            finally:
                logger.close()

            self.assertEqual(result.status, "succeeded")
            self.assertEqual(result.outputs, {"count": 2, "message": "iter-2"})
            self.assertEqual(set(result.nodes), {"start", "loop", "end"})
            self.assertEqual(result.nodes["loop"].outputs, {"count": 2, "message": "iter-2"})

            events = [json.loads(line) for line in log_path.read_text(encoding="utf-8").splitlines()]
            iteration_events = [event for event in events if event["event"] == "loop_iteration_finished"]
            self.assertEqual([event["outcome"] for event in iteration_events], ["continue", "break"])

            body_success_events = [
                event
                for event in events
                if event["event"] == "node_succeeded" and event["node_id"] in {"inc", "assign", "branch", "done", "continue"}
            ]
            self.assertTrue(body_success_events)
            self.assertTrue(all(event["loop_id"] == "loop" for event in body_success_events))
            self.assertTrue(all(isinstance(event["iteration"], int) for event in body_success_events))

    def test_loop_node_fails_after_max_iterations_without_break(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            log_path = Path(tmpdir) / "run.jsonl"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "loop",
                                "kind": "loop",
                                "config": {
                                    "max_iterations": 2,
                                    "loop_variables": {"count": 0},
                                    "body": {
                                        "nodes": [
                                            {
                                                "id": "inc",
                                                "kind": "code",
                                                "inputs": {"count": "{{ nodes['loop'].count }}"},
                                                "config": {
                                                    "language": "python3",
                                                    "source": (
                                                        "def main(count):\n"
                                                        "    return {'count': count + 1, 'is_done': False}\n"
                                                    ),
                                                    "outputs": ["count", "is_done"],
                                                },
                                            },
                                            {
                                                "id": "assign",
                                                "kind": "assigner",
                                                "inputs": {"count": "{{ nodes['inc'].count }}"},
                                                "config": {
                                                    "assignments": [
                                                        {
                                                            "input_name": "count",
                                                            "target_name": "count",
                                                            "target_scope": "loop_variable",
                                                            "operation": "overwrite",
                                                        }
                                                    ]
                                                },
                                            },
                                            {
                                                "id": "branch",
                                                "kind": "if_else",
                                                "inputs": {"done": "{{ nodes['inc'].is_done }}"},
                                                "config": {
                                                    "cases": [
                                                        {
                                                            "case_id": "done",
                                                            "logical_operator": "and",
                                                            "conditions": [
                                                                {
                                                                    "operator": "equals",
                                                                    "input_name": "done",
                                                                    "value": "True",
                                                                }
                                                            ],
                                                        }
                                                    ]
                                                },
                                            },
                                            {
                                                "id": "done",
                                                "kind": "template",
                                                "inputs": {},
                                                "config": {"template": "done"},
                                            },
                                            {
                                                "id": "continue",
                                                "kind": "template",
                                                "inputs": {},
                                                "config": {"template": "continue"},
                                            },
                                        ],
                                        "edges": [
                                            {"from": "inc", "to": "assign"},
                                            {"from": "assign", "to": "branch"},
                                            {"from": "branch", "to": "done", "source_handle": "done"},
                                            {"from": "branch", "to": "continue", "source_handle": "false"},
                                        ],
                                        "entry_nodes": ["inc"],
                                        "break_nodes": ["done"],
                                    },
                                },
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {"count": "{{ nodes['loop'].count }}"},
                                "config": {"outputs": {"count": "{{ inputs.count }}"}},
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "loop"},
                            {"from": "loop", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )
            compiled_plan = load_plan(plan_path)
            logger = EventLogger(log_path=log_path, run_id="loop-fail")
            runtime = WorkflowRuntime(logger=logger)
            try:
                result = _run_runtime(runtime, compiled_plan=compiled_plan, inputs={})
            finally:
                logger.close()

            self.assertEqual(result.status, "failed")
            self.assertEqual(result.error.code, "NODE_EXECUTION_FAILED")
            self.assertIn("max_iterations=2", result.error.message)

            events = [json.loads(line) for line in log_path.read_text(encoding="utf-8").splitlines()]
            iteration_events = [event for event in events if event["event"] == "loop_iteration_finished"]
            self.assertEqual([event["outcome"] for event in iteration_events], ["continue", "failed"])

    def test_loop_body_failure_propagates_to_workflow_failure(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            log_path = Path(tmpdir) / "run.jsonl"
            plan_path.write_text(
                json.dumps(
                    {
                        "nodes": [
                            {"id": "start", "kind": "start"},
                            {
                                "id": "loop",
                                "kind": "loop",
                                "config": {
                                    "max_iterations": 1,
                                    "loop_variables": {"count": 0},
                                    "body": {
                                        "nodes": [
                                            {
                                                "id": "boom",
                                                "kind": "code",
                                                "config": {
                                                    "language": "python3",
                                                    "source": "def main():\n    raise ValueError('boom')\n",
                                                    "outputs": ["count"],
                                                },
                                            },
                                            {
                                                "id": "done",
                                                "kind": "template",
                                                "inputs": {},
                                                "config": {"template": "done"},
                                            },
                                        ],
                                        "edges": [{"from": "boom", "to": "done"}],
                                        "entry_nodes": ["boom"],
                                        "break_nodes": ["done"],
                                    },
                                },
                            },
                            {
                                "id": "end",
                                "kind": "end",
                                "inputs": {"message": "unused"},
                                "config": {"outputs": {"message": "{{ inputs.message }}"}},
                            },
                        ],
                        "edges": [
                            {"from": "start", "to": "loop"},
                            {"from": "loop", "to": "end"},
                        ],
                    }
                ),
                encoding="utf-8",
            )
            compiled_plan = load_plan(plan_path)
            logger = EventLogger(log_path=log_path, run_id="loop-body-failure")
            runtime = WorkflowRuntime(logger=logger)
            try:
                result = _run_runtime(runtime, compiled_plan=compiled_plan, inputs={})
            finally:
                logger.close()

            self.assertEqual(result.status, "failed")
            self.assertEqual(result.error.node_id, "boom")
            self.assertEqual(result.error.code, "NODE_EXECUTION_FAILED")

            events = [json.loads(line) for line in log_path.read_text(encoding="utf-8").splitlines()]
            failed_body_events = [event for event in events if event["event"] == "node_failed" and event["node_id"] == "boom"]
            self.assertEqual(len(failed_body_events), 1)
            self.assertEqual(failed_body_events[0]["loop_id"], "loop")
            self.assertEqual(failed_body_events[0]["iteration"], 1)


if __name__ == "__main__":
    unittest.main()
