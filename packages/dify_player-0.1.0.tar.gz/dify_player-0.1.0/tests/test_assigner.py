from __future__ import annotations

import asyncio
import unittest

from dify_player.dify_importer.node_converters.assigner import convert_assigner_node
from dify_player.exceptions import PlanValidationError
from dify_player.models import Node
from dify_player.nodes.assigner import run as run_assigner


def _run_assigner(**kwargs):
    return asyncio.run(run_assigner(**kwargs))


class AssignerNodeConverterTestCase(unittest.TestCase):
    def test_convert_assigner_node_normalizes_single_item(self) -> None:
        node = convert_assigner_node(
            node_id="assign",
            node_name="Assign",
            data={
                "items": [
                    {
                        "input_type": "variable",
                        "operation": "over-write",
                        "output_name": "checked_segments_final",
                        "value": ["llm", "structured_output", "segments"],
                        "variable_selector": ["loop", "checked_segments_final"],
                    }
                ]
            },
            node_specs={
                "loop": {"type": "loop"},
                "llm": {"type": "llm"},
            },
        )

        self.assertEqual(node.kind, "assigner")
        self.assertEqual(node.inputs, {"input_0": "{{ nodes['llm'].structured_output.segments }}"})
        self.assertEqual(
            node.config,
            {
                "assignments": [
                    {
                        "input_name": "input_0",
                        "target_name": "checked_segments_final",
                        "target_scope": "loop_variable",
                        "operation": "overwrite",
                    }
                ]
            },
        )

    def test_convert_assigner_node_normalizes_multiple_items(self) -> None:
        node = convert_assigner_node(
            node_id="assign",
            node_name=None,
            data={
                "items": [
                    {
                        "input_type": "variable",
                        "operation": "over-write",
                        "output_name": "checked_segments_final",
                        "value": ["llm", "structured_output", "segments"],
                        "variable_selector": ["loop", "checked_segments_final"],
                    },
                    {
                        "input_type": "variable",
                        "operation": "over-write",
                        "output_name": "segment_count",
                        "value": ["code", "seg_count"],
                        "variable_selector": ["loop", "segment_count"],
                    },
                ]
            },
            node_specs={
                "loop": {"type": "loop"},
                "llm": {"type": "llm"},
                "code": {"type": "code", "outputs": {"seg_count": {"type": "string"}}},
            },
        )

        self.assertEqual(
            node.inputs,
            {
                "input_0": "{{ nodes['llm'].structured_output.segments }}",
                "input_1": "{{ nodes['code'].seg_count }}",
            },
        )
        self.assertEqual(
            node.config["assignments"],
            [
                {
                    "input_name": "input_0",
                    "target_name": "checked_segments_final",
                    "target_scope": "loop_variable",
                    "operation": "overwrite",
                },
                {
                    "input_name": "input_1",
                    "target_name": "segment_count",
                    "target_scope": "loop_variable",
                    "operation": "overwrite",
                },
            ],
        )

    def test_convert_assigner_node_rejects_unsupported_operation(self) -> None:
        with self.assertRaisesRegex(PlanValidationError, "operation=over-write"):
            convert_assigner_node(
                node_id="assign",
                node_name=None,
                data={
                    "items": [
                        {
                            "input_type": "variable",
                            "operation": "append",
                            "output_name": "checked_segments_final",
                            "value": ["code", "seg_count"],
                            "variable_selector": ["loop", "checked_segments_final"],
                        }
                    ]
                },
                node_specs={"loop": {"type": "loop"}, "code": {"type": "code", "outputs": {"seg_count": {"type": "string"}}}},
            )

    def test_convert_assigner_node_rejects_unsupported_input_type(self) -> None:
        with self.assertRaisesRegex(PlanValidationError, "input_type=variable"):
            convert_assigner_node(
                node_id="assign",
                node_name=None,
                data={
                    "items": [
                        {
                            "input_type": "constant",
                            "operation": "over-write",
                            "output_name": "checked_segments_final",
                            "value": ["code", "seg_count"],
                            "variable_selector": ["loop", "checked_segments_final"],
                        }
                    ]
                },
                node_specs={"loop": {"type": "loop"}, "code": {"type": "code", "outputs": {"seg_count": {"type": "string"}}}},
            )

    def test_convert_assigner_node_rejects_non_loop_variable_selector_shape(self) -> None:
        with self.assertRaisesRegex(PlanValidationError, "exactly \\[loop_node_id, loop_var_name\\]"):
            convert_assigner_node(
                node_id="assign",
                node_name=None,
                data={
                    "items": [
                        {
                            "input_type": "variable",
                            "operation": "over-write",
                            "output_name": "checked_segments_final",
                            "value": ["code", "seg_count"],
                            "variable_selector": ["loop", "checked_segments_final", "nested"],
                        }
                    ]
                },
                node_specs={"loop": {"type": "loop"}, "code": {"type": "code", "outputs": {"seg_count": {"type": "string"}}}},
            )

    def test_convert_assigner_node_rejects_output_name_mismatch(self) -> None:
        with self.assertRaisesRegex(PlanValidationError, "must match target loop variable"):
            convert_assigner_node(
                node_id="assign",
                node_name=None,
                data={
                    "items": [
                        {
                            "input_type": "variable",
                            "operation": "over-write",
                            "output_name": "checked_segments_final",
                            "value": ["code", "seg_count"],
                            "variable_selector": ["loop", "different_name"],
                        }
                    ]
                },
                node_specs={"loop": {"type": "loop"}, "code": {"type": "code", "outputs": {"seg_count": {"type": "string"}}}},
            )

    def test_convert_assigner_node_rejects_duplicate_target(self) -> None:
        with self.assertRaisesRegex(PlanValidationError, "same target more than once"):
            convert_assigner_node(
                node_id="assign",
                node_name=None,
                data={
                    "items": [
                        {
                            "input_type": "variable",
                            "operation": "over-write",
                            "output_name": "checked_segments_final",
                            "value": ["code", "seg_count"],
                            "variable_selector": ["loop", "checked_segments_final"],
                        },
                        {
                            "input_type": "variable",
                            "operation": "over-write",
                            "output_name": "checked_segments_final",
                            "value": ["llm", "structured_output", "segments"],
                            "variable_selector": ["loop", "checked_segments_final"],
                        },
                    ]
                },
                node_specs={
                    "loop": {"type": "loop"},
                    "code": {"type": "code", "outputs": {"seg_count": {"type": "string"}}},
                    "llm": {"type": "llm"},
                },
            )


class AssignerNodeExecutorTestCase(unittest.TestCase):
    def test_run_assigner_returns_updates_for_single_assignment(self) -> None:
        node = Node(
            id="assign",
            kind="assigner",
            config={
                "assignments": [
                    {
                        "input_name": "input_0",
                        "target_name": "checked_segments_final",
                        "target_scope": "loop_variable",
                        "operation": "overwrite",
                    }
                ]
            },
        )

        result = _run_assigner(
            node=node,
            workflow_inputs={},
            node_outputs={},
            resolved_inputs={"input_0": [{"index": 0, "content": "hello"}]},
        )

        self.assertEqual(result, {"checked_segments_final": [{"index": 0, "content": "hello"}]})

    def test_run_assigner_returns_updates_for_multiple_assignments(self) -> None:
        node = Node(
            id="assign",
            kind="assigner",
            config={
                "assignments": [
                    {
                        "input_name": "input_0",
                        "target_name": "checked_segments_final",
                        "target_scope": "loop_variable",
                        "operation": "overwrite",
                    },
                    {
                        "input_name": "input_1",
                        "target_name": "segment_count",
                        "target_scope": "loop_variable",
                        "operation": "overwrite",
                    },
                ]
            },
        )

        result = _run_assigner(
            node=node,
            workflow_inputs={},
            node_outputs={},
            resolved_inputs={"input_0": [{"index": 0, "content": "hello"}], "input_1": "1"},
        )

        self.assertEqual(
            result,
            {
                "checked_segments_final": [{"index": 0, "content": "hello"}],
                "segment_count": "1",
            },
        )

    def test_run_assigner_fails_fast_when_declared_input_is_missing(self) -> None:
        node = Node(
            id="assign",
            kind="assigner",
            name="Assign",
            config={
                "assignments": [
                    {
                        "input_name": "input_0",
                        "target_name": "checked_segments_final",
                        "target_scope": "loop_variable",
                        "operation": "overwrite",
                    }
                ]
            },
        )

        with self.assertRaisesRegex(ValueError, "missing input 'input_0'"):
            _run_assigner(
                node=node,
                workflow_inputs={},
                node_outputs={},
                resolved_inputs={},
            )
