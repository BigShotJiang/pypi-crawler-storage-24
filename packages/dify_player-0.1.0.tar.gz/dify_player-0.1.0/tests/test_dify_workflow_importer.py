from __future__ import annotations

import asyncio
import json
import tempfile
import unittest
from pathlib import Path

from dify_player.dify_workflow_importer import load_dify_workflow_definition, plan_to_data
from dify_player.event_logger import EventLogger
from dify_player.exceptions import PlanValidationError
from dify_player.plan_loader import compile_plan
from dify_player.runtime import WorkflowRuntime
from tests.workflow_http_server import HTTPServerContext

ROOT = Path(__file__).resolve().parents[1]


def _run_runtime(runtime: WorkflowRuntime, *, compiled_plan, inputs):
    return asyncio.run(runtime.run(compiled_plan=compiled_plan, inputs=inputs))


class DifyWorkflowImporterTestCase(unittest.TestCase):
    def test_imports_code_node_and_references_its_outputs(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            workflow_path = Path(tmpdir) / "workflow.yml"
            workflow_path.write_text(
                """
kind: app
app:
  mode: workflow
workflow:
  graph:
    nodes:
      - id: start
        data:
          type: start
          variables:
            - variable: source_text
      - id: code
        data:
          type: code
          title: Formatter
          code_language: python3
          code: |
            def main(source_text):
                return {"summary": source_text.upper()}
          variables:
            - variable: source_text
              value_selector: [start, source_text]
          outputs:
            summary:
              type: string
      - id: end
        data:
          type: end
          outputs:
            - variable: message
              value_selector: [code, summary]
    edges:
      - source: start
        target: code
        sourceHandle: source
        data:
          sourceType: start
      - source: code
        target: end
        sourceHandle: source
        data:
          sourceType: code
""",
                encoding="utf-8",
            )

            plan = load_dify_workflow_definition(workflow_path)

            self.assertEqual(
                [node.kind for node in plan.nodes],
                ["start", "code", "end"],
            )
            self.assertEqual(plan.nodes[1].inputs, {"source_text": "{{ inputs.source_text }}"})
            self.assertEqual(
                plan.nodes[1].config,
                {
                    "language": "python3",
                    "source": "def main(source_text):\n    return {\"summary\": source_text.upper()}\n",
                    "outputs": ["summary"],
                },
            )
            self.assertEqual(plan.nodes[2].inputs, {"message": "{{ nodes['code'].summary }}"})

    def test_imports_variable_aggregator_node(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            workflow_path = Path(tmpdir) / "workflow.yml"
            workflow_path.write_text(
                """
kind: app
app:
  mode: workflow
workflow:
  graph:
    nodes:
      - id: start
        data:
          type: start
          variables:
            - variable: translation_style
      - id: branch
        data:
          type: if-else
          cases:
            - case_id: literal
              id: literal
              logical_operator: and
              conditions:
                - comparison_operator: contains
                  value: Literal
                  variable_selector: [start, translation_style]
      - id: literal
        data:
          type: template-transform
          template: "literal"
          variables: []
      - id: other
        data:
          type: template-transform
          template: "other"
          variables: []
      - id: aggregate
        data:
          type: variable-aggregator
          output_type: string
          variables:
            - [literal, output]
            - [other, output]
      - id: end
        data:
          type: end
          outputs:
            - variable: message
              value_selector: [aggregate, output]
    edges:
      - source: start
        target: branch
        sourceHandle: source
        data:
          sourceType: start
      - source: branch
        target: literal
        sourceHandle: literal
        data:
          sourceType: if-else
      - source: branch
        target: other
        sourceHandle: false
        data:
          sourceType: if-else
      - source: literal
        target: aggregate
        sourceHandle: source
        data:
          sourceType: template-transform
      - source: other
        target: aggregate
        sourceHandle: source
        data:
          sourceType: template-transform
      - source: aggregate
        target: end
        sourceHandle: source
        data:
          sourceType: variable-aggregator
""",
                encoding="utf-8",
            )

            plan = load_dify_workflow_definition(workflow_path)

            self.assertEqual(
                [node.kind for node in plan.nodes],
                ["start", "if_else", "template", "template", "variable_aggregator", "end"],
            )
            self.assertEqual(
                plan.nodes[4].config,
                {
                    "output_type": "string",
                    "candidates": [
                        {"node_id": "literal", "output_key": "text"},
                        {"node_id": "other", "output_key": "text"},
                    ],
                },
            )
            self.assertEqual(plan.nodes[5].inputs, {"message": "{{ nodes['aggregate'].output }}"})

    def test_imported_variable_aggregator_workflow_runs(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            workflow_path = Path(tmpdir) / "workflow.yml"
            workflow_path.write_text(
                """
kind: app
app:
  mode: workflow
workflow:
  graph:
    nodes:
      - id: start
        data:
          type: start
          variables:
            - variable: translation_style
      - id: branch
        data:
          type: if-else
          cases:
            - case_id: literal
              id: literal
              logical_operator: and
              conditions:
                - comparison_operator: contains
                  value: Literal
                  variable_selector: [start, translation_style]
      - id: literal
        data:
          type: template-transform
          template: "literal"
          variables: []
      - id: other
        data:
          type: template-transform
          template: "other"
          variables: []
      - id: aggregate
        data:
          type: variable-aggregator
          output_type: string
          variables:
            - [literal, output]
            - [other, output]
      - id: end
        data:
          type: end
          outputs:
            - variable: message
              value_selector: [aggregate, output]
    edges:
      - source: start
        target: branch
        sourceHandle: source
        data:
          sourceType: start
      - source: branch
        target: literal
        sourceHandle: literal
        data:
          sourceType: if-else
      - source: branch
        target: other
        sourceHandle: false
        data:
          sourceType: if-else
      - source: literal
        target: aggregate
        sourceHandle: source
        data:
          sourceType: template-transform
      - source: other
        target: aggregate
        sourceHandle: source
        data:
          sourceType: template-transform
      - source: aggregate
        target: end
        sourceHandle: source
        data:
          sourceType: variable-aggregator
""",
                encoding="utf-8",
            )

            plan = load_dify_workflow_definition(workflow_path)
            compiled_plan = compile_plan(plan)
            logger = EventLogger(log_path=Path(tmpdir) / "run.jsonl", run_id="imported-variable-aggregator")
            runtime = WorkflowRuntime(logger=logger)
            try:
                result = _run_runtime(runtime, compiled_plan=compiled_plan, inputs={"translation_style": "Natural"})
            finally:
                logger.close()

            self.assertEqual(result.status, "succeeded")
            self.assertEqual(result.outputs, {"message": "other"})
            self.assertEqual(result.nodes["aggregate"].outputs, {"output": "other"})

    def test_imports_if_else_node_and_branch_edges(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            workflow_path = Path(tmpdir) / "workflow.yml"
            workflow_path.write_text(
                """
kind: app
app:
  mode: workflow
workflow:
  graph:
    nodes:
      - id: start
        data:
          type: start
          title: Start
          variables:
            - variable: translation_style
      - id: branch
        data:
          type: if-else
          title: Branch
          cases:
            - case_id: literal
              id: literal
              logical_operator: and
              conditions:
                - comparison_operator: contains
                  value: Literal
                  variable_selector: [start, translation_style]
      - id: literal
        data:
          type: template-transform
          title: Literal
          template: "literal"
          variables: []
      - id: other
        data:
          type: template-transform
          title: Other
          template: "other"
          variables: []
      - id: end
        data:
          type: end
          outputs: []
    edges:
      - source: start
        target: branch
        sourceHandle: source
        data:
          sourceType: start
      - source: branch
        target: literal
        sourceHandle: literal
        data:
          sourceType: if-else
      - source: branch
        target: other
        sourceHandle: false
        data:
          sourceType: if-else
      - source: literal
        target: end
        sourceHandle: source
        data:
          sourceType: template-transform
      - source: other
        target: end
        sourceHandle: source
        data:
          sourceType: template-transform
""",
                encoding="utf-8",
            )

            plan = load_dify_workflow_definition(workflow_path)

            self.assertEqual([node.kind for node in plan.nodes], ["start", "if_else", "template", "template", "end"])
            self.assertEqual(plan.nodes[1].inputs, {"case_0_condition_0": "{{ inputs.translation_style }}"})
            self.assertEqual(
                plan.nodes[1].config,
                {
                    "cases": [
                        {
                            "case_id": "literal",
                            "logical_operator": "and",
                            "conditions": [
                                {
                                    "operator": "contains",
                                    "input_name": "case_0_condition_0",
                                    "value": "Literal",
                                }
                            ],
                        }
                    ]
                },
            )
            self.assertEqual(
                plan_to_data(plan)["edges"],
                [
                    {"from": "start", "to": "branch"},
                    {"from": "branch", "to": "literal", "source_handle": "literal"},
                    {"from": "branch", "to": "other", "source_handle": "false"},
                    {"from": "literal", "to": "end"},
                    {"from": "other", "to": "end"},
                ],
            )

    def test_imports_if_else_equals_condition(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            workflow_path = Path(tmpdir) / "workflow.yml"
            workflow_path.write_text(
                """
kind: app
app:
  mode: workflow
workflow:
  graph:
    nodes:
      - id: start
        data:
          type: start
          variables:
            - variable: seg_match
      - id: branch
        data:
          type: if-else
          cases:
            - case_id: matched
              id: matched
              logical_operator: and
              conditions:
                - comparison_operator: '='
                  value: '1'
                  variable_selector: [start, seg_match]
      - id: matched
        data:
          type: template-transform
          template: "matched"
          variables: []
      - id: other
        data:
          type: template-transform
          template: "other"
          variables: []
      - id: end
        data:
          type: end
          outputs: []
    edges:
      - source: start
        target: branch
        sourceHandle: source
        data:
          sourceType: start
      - source: branch
        target: matched
        sourceHandle: matched
        data:
          sourceType: if-else
      - source: branch
        target: other
        sourceHandle: false
        data:
          sourceType: if-else
      - source: matched
        target: end
        sourceHandle: source
        data:
          sourceType: template-transform
      - source: other
        target: end
        sourceHandle: source
        data:
          sourceType: template-transform
""",
                encoding="utf-8",
            )

            plan = load_dify_workflow_definition(workflow_path)

            self.assertEqual(
                plan.nodes[1].config,
                {
                    "cases": [
                        {
                            "case_id": "matched",
                            "logical_operator": "and",
                            "conditions": [
                                {
                                    "operator": "equals",
                                    "input_name": "case_0_condition_0",
                                    "value": "1",
                                }
                            ],
                        }
                    ]
                },
            )

    def test_imported_if_else_workflow_runs(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            workflow_path = Path(tmpdir) / "workflow.yml"
            workflow_path.write_text(
                """
kind: app
app:
  mode: workflow
workflow:
  graph:
    nodes:
      - id: start
        data:
          type: start
          variables:
            - variable: translation_style
      - id: branch
        data:
          type: if-else
          cases:
            - case_id: literal
              id: literal
              logical_operator: and
              conditions:
                - comparison_operator: contains
                  value: Literal
                  variable_selector: [start, translation_style]
      - id: literal
        data:
          type: template-transform
          template: "literal"
          variables: []
      - id: other
        data:
          type: template-transform
          template: "other"
          variables: []
      - id: end
        data:
          type: end
          outputs: []
    edges:
      - source: start
        target: branch
        sourceHandle: source
        data:
          sourceType: start
      - source: branch
        target: literal
        sourceHandle: literal
        data:
          sourceType: if-else
      - source: branch
        target: other
        sourceHandle: false
        data:
          sourceType: if-else
      - source: other
        target: end
        sourceHandle: source
        data:
          sourceType: template-transform
      - source: literal
        target: end
        sourceHandle: source
        data:
          sourceType: template-transform
""",
                encoding="utf-8",
            )

            plan = load_dify_workflow_definition(workflow_path)
            compiled_plan = compile_plan(plan)
            logger = EventLogger(log_path=Path(tmpdir) / "run.jsonl", run_id="imported-if-else")
            runtime = WorkflowRuntime(logger=logger)
            try:
                result = _run_runtime(runtime, compiled_plan=compiled_plan, inputs={"translation_style": "Natural"})
            finally:
                logger.close()

            self.assertEqual(result.status, "succeeded")
            self.assertEqual(result.outputs, {})
            self.assertEqual(result.nodes["other"].outputs, {"text": "other"})
            self.assertEqual(result.nodes["literal"].status, "skipped")

    def test_imports_template_transform_node(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            workflow_path = Path(tmpdir) / "workflow.yml"
            workflow_path.write_text(
                """
kind: app
app:
  mode: workflow
workflow:
  graph:
    nodes:
      - id: start
        data:
          type: start
          title: Start
          variables:
            - variable: target_language
            - variable: source_text
      - id: prompt
        data:
          type: template-transform
          title: Prompt
          template: "Translate into {{ target_language }}: {{ source_text }}"
          variables:
            - variable: target_language
              value_selector: [start, target_language]
            - variable: source_text
              value_selector: [start, source_text]
      - id: end
        data:
          type: end
          outputs:
            - variable: prompt
              value_selector: [prompt, output]
    edges:
      - source: start
        target: prompt
      - source: prompt
        target: end
""",
                encoding="utf-8",
            )

            plan = load_dify_workflow_definition(workflow_path)

            self.assertEqual([node.kind for node in plan.nodes], ["start", "template", "end"])
            self.assertEqual(
                plan.nodes[1].inputs,
                {
                    "target_language": "{{ inputs.target_language }}",
                    "source_text": "{{ inputs.source_text }}",
                },
            )
            self.assertEqual(
                plan.nodes[1].config,
                {
                    "template": "Translate into {{ inputs.target_language }}: {{ inputs.source_text }}",
                },
            )
            self.assertEqual(
                plan.nodes[2].inputs,
                {
                    "prompt": "{{ nodes['prompt'].text }}",
                },
            )

    def test_imported_template_transform_workflow_runs(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            workflow_path = Path(tmpdir) / "workflow.yml"
            workflow_path.write_text(
                """
kind: app
app:
  mode: workflow
workflow:
  graph:
    nodes:
      - id: start
        data:
          type: start
          title: Start
          variables:
            - variable: target_language
            - variable: source_text
      - id: prompt
        data:
          type: template-transform
          title: Prompt
          template: "Translate into {{ target_language }}: {{ source_text }}"
          variables:
            - variable: target_language
              value_selector: [start, target_language]
            - variable: source_text
              value_selector: [start, source_text]
      - id: end
        data:
          type: end
          outputs:
            - variable: prompt
              value_selector: [prompt, output]
    edges:
      - source: start
        target: prompt
      - source: prompt
        target: end
""",
                encoding="utf-8",
            )

            plan = load_dify_workflow_definition(workflow_path)
            compiled_plan = compile_plan(plan)
            logger = EventLogger(log_path=Path(tmpdir) / "run.jsonl", run_id="template-transform")
            runtime = WorkflowRuntime(logger=logger)
            try:
                result = _run_runtime(
                    runtime,
                    compiled_plan=compiled_plan,
                    inputs={"target_language": "Japanese", "source_text": "Hello"},
                )
            finally:
                logger.close()

            self.assertEqual(result.status, "succeeded")
            self.assertEqual(result.outputs, {"prompt": "Translate into Japanese: Hello"})

    def test_imports_llm_node_with_embedded_references(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            workflow_path = Path(tmpdir) / "workflow.yml"
            workflow_path.write_text(
                """
kind: app
app:
  mode: workflow
workflow:
  graph:
    nodes:
      - id: start
        data:
          type: start
          title: Start
          variables:
            - variable: source_text
      - id: llm1
        data:
          type: llm
          title: Detect
          context:
            enabled: false
            variable_selector: []
          vision:
            enabled: false
          model:
            provider: langgenius/azure_openai/azure_openai
            mode: chat
            name: gpt-4o
            completion_params:
              temperature: 0
          prompt_template:
            - role: user
              text: "Detect {{#start.source_text#}}"
          structured_output_enabled: true
          structured_output:
            schema:
              type: object
              properties:
                language:
                  type: string
              required: [language]
              additionalProperties: false
      - id: llm2
        data:
          type: llm
          title: Explain
          context:
            enabled: false
            variable_selector: []
          vision:
            enabled: false
          model:
            provider: langgenius/azure_openai/azure_openai
            mode: chat
            name: gpt-4o
            completion_params: {}
          prompt_template:
            - role: user
              text: "Language is {{#llm1.structured_output.language#}}"
      - id: end
        data:
          type: end
          outputs: []
    edges:
      - source: start
        target: llm1
      - source: llm1
        target: llm2
      - source: llm2
        target: end
""",
                encoding="utf-8",
            )

            plan = load_dify_workflow_definition(workflow_path)

            self.assertEqual([node.kind for node in plan.nodes], ["start", "llm_azure_chat", "llm_azure_chat", "end"])
            self.assertEqual(
                plan.nodes[1].config,
                {
                    "model": "gpt-4o",
                    "messages": [{"role": "user", "content": "Detect {{ inputs.source_text }}"}],
                    "response_format": "json_schema",
                    "json_schema": {
                        "type": "object",
                        "properties": {"language": {"type": "string"}},
                        "required": ["language"],
                        "additionalProperties": False,
                    },
                    "temperature": 0,
                },
            )
            self.assertEqual(
                plan.nodes[2].config["messages"],
                [{"role": "user", "content": "Language is {{ nodes['llm1'].structured_output.language }}"}],
            )

    def test_imports_test_http_saas_workflow(self) -> None:
        plan = load_dify_workflow_definition(ROOT / "workflows" / "test_http_saas.yml")

        self.assertEqual([node.kind for node in plan.nodes], ["start", "http", "end"])
        self.assertEqual([node.name for node in plan.nodes], ["ユーザー入力", "HTTP リクエスト", "出力"])
        self.assertEqual(plan.nodes[1].id, "1773065547624")
        self.assertEqual(plan.nodes[1].inputs, {"url": "{{ inputs.url }}"})
        self.assertEqual(plan.nodes[1].config, {"method": "GET"})
        self.assertEqual(plan.nodes[2].inputs, {})
        self.assertEqual(plan.nodes[2].config, {"outputs": {}})
        self.assertEqual(
            plan_to_data(plan),
            {
                "nodes": [
                    {"id": "1773064906498", "kind": "start", "name": "ユーザー入力"},
                    {
                        "id": "1773065547624",
                        "kind": "http",
                        "name": "HTTP リクエスト",
                        "inputs": {"url": "{{ inputs.url }}"},
                        "config": {"method": "GET"},
                    },
                    {
                        "id": "1773065560222",
                        "kind": "end",
                        "name": "出力",
                        "inputs": {},
                        "config": {"outputs": {}},
                    },
                ],
                "edges": [
                    {"from": "1773064906498", "to": "1773065547624"},
                    {"from": "1773065547624", "to": "1773065560222"},
                ],
                "outputs": {},
            },
        )

    def test_imports_end_outputs_from_llm_selector(self) -> None:
        plan = load_dify_workflow_definition(ROOT / "workflows" / "test_llm_simple.yml")

        self.assertEqual([node.kind for node in plan.nodes], ["start", "llm_azure_chat", "end"])
        self.assertEqual([node.name for node in plan.nodes], ["開始", "LLM", "終了"])
        self.assertEqual(
            plan.nodes[2].inputs,
            {
                "result": "{{ nodes['1773223899775'].text }}",
            },
        )
        self.assertEqual(
            plan.nodes[2].config,
            {
                "outputs": {
                    "result": "{{ inputs.result }}",
                }
            },
        )

    def test_imported_workflow_runs_and_returns_empty_outputs(self) -> None:
        plan = load_dify_workflow_definition(ROOT / "workflows" / "test_http_saas.yml")
        compiled_plan = compile_plan(plan)

        with HTTPServerContext() as (base_url, _requests_log):
            with tempfile.TemporaryDirectory() as tmpdir:
                logger = EventLogger(log_path=Path(tmpdir) / "run.jsonl", run_id="imported-http")
                runtime = WorkflowRuntime(logger=logger)
                try:
                    result = _run_runtime(
                        runtime,
                        compiled_plan=compiled_plan,
                        inputs={
                            "url": f"{base_url}/json",
                            "text": "unused",
                        },
                    )
                finally:
                    logger.close()

                self.assertEqual(result.status, "succeeded")
                self.assertEqual(result.outputs, {})

    def test_imports_post_workflow_with_json_body(self) -> None:
        plan = load_dify_workflow_definition(ROOT / "workflows" / "test_http_post_saas.yml")

        self.assertEqual([node.kind for node in plan.nodes], ["start", "http", "end"])
        self.assertEqual([node.name for node in plan.nodes], ["ユーザー入力", "HTTP リクエスト", "出力"])
        self.assertEqual(
            plan.nodes[1].inputs,
            {
                "url": "{{ inputs.url }}",
                "body": {"text": "{{ inputs.text }}"},
            },
        )
        self.assertEqual(plan.nodes[1].config, {"method": "POST"})

    def test_imported_post_workflow_sends_json_body(self) -> None:
        plan = load_dify_workflow_definition(ROOT / "workflows" / "test_http_post_saas.yml")
        compiled_plan = compile_plan(plan)

        with HTTPServerContext() as (base_url, requests_log):
            with tempfile.TemporaryDirectory() as tmpdir:
                logger = EventLogger(log_path=Path(tmpdir) / "run.jsonl", run_id="imported-http-post")
                runtime = WorkflowRuntime(logger=logger)
                try:
                    result = _run_runtime(
                        runtime,
                        compiled_plan=compiled_plan,
                        inputs={
                            "url": f"{base_url}/echo",
                            "text": "hello",
                        },
                    )
                finally:
                    logger.close()

                self.assertEqual(result.status, "succeeded")
                self.assertEqual(result.outputs, {})
                self.assertEqual(requests_log[0]["method"], "POST")
                self.assertEqual(json.loads(str(requests_log[0]["body"])), {"text": "hello"})

    def test_import_rejects_non_no_auth_http_request(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            workflow_path = Path(tmpdir) / "workflow.yml"
            workflow_path.write_text(
                """
kind: app
app:
  mode: workflow
workflow:
  graph:
    nodes:
      - id: start
        data:
          type: start
          variables:
            - variable: url
      - id: fetch
        data:
          type: http-request
          method: get
          url: "{{#start.url#}}"
          headers: ""
          params: ""
          body:
            type: none
            data: []
          authorization:
            type: api-key
      - id: end
        data:
          type: end
          outputs: []
    edges:
      - source: start
        target: fetch
      - source: fetch
        target: end
""",
                encoding="utf-8",
            )

            with self.assertRaisesRegex(PlanValidationError, "authorization.type=no-auth"):
                load_dify_workflow_definition(workflow_path)

    def test_import_rejects_invalid_end_output_selector(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            workflow_path = Path(tmpdir) / "workflow.yml"
            workflow_path.write_text(
                """
kind: app
app:
  mode: workflow
workflow:
  graph:
    nodes:
      - id: start
        data:
          type: start
          variables:
            - variable: url
      - id: fetch
        data:
          type: http-request
          method: get
          url: "{{#start.url#}}"
          headers: ""
          params: ""
          body:
            type: none
            data: []
          authorization:
            type: no-auth
      - id: end
        data:
          type: end
          outputs:
            - variable: result
              value_selector: []
    edges:
      - source: start
        target: fetch
      - source: fetch
        target: end
""",
                encoding="utf-8",
            )

            with self.assertRaisesRegex(PlanValidationError, "value_selector"):
                load_dify_workflow_definition(workflow_path)

    def test_import_rejects_template_transform_with_undeclared_variable(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            workflow_path = Path(tmpdir) / "workflow.yml"
            workflow_path.write_text(
                """
kind: app
app:
  mode: workflow
workflow:
  graph:
    nodes:
      - id: start
        data:
          type: start
          variables:
            - variable: source_text
      - id: prompt
        data:
          type: template-transform
          template: "Translate into {{ target_language }}"
          variables: []
      - id: end
        data:
          type: end
          outputs: []
    edges:
      - source: start
        target: prompt
      - source: prompt
        target: end
""",
                encoding="utf-8",
            )

            with self.assertRaisesRegex(PlanValidationError, "undeclared variables"):
                load_dify_workflow_definition(workflow_path)

    def test_import_rejects_non_default_llm_context(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            workflow_path = Path(tmpdir) / "workflow.yml"
            workflow_path.write_text(
                """
kind: app
app:
  mode: workflow
workflow:
  graph:
    nodes:
      - id: start
        data:
          type: start
          variables:
            - variable: source_text
      - id: llm
        data:
          type: llm
          context:
            enabled: true
            variable_selector: [foo]
          vision:
            enabled: false
          model:
            provider: langgenius/azure_openai/azure_openai
            mode: chat
            name: gpt-4o
            completion_params: {}
          prompt_template:
            - role: user
              text: "{{#start.source_text#}}"
      - id: end
        data:
          type: end
          outputs: []
    edges:
      - source: start
        target: llm
      - source: llm
        target: end
""",
                encoding="utf-8",
            )

            with self.assertRaisesRegex(PlanValidationError, "context.enabled=true"):
                load_dify_workflow_definition(workflow_path)

    def test_import_rejects_non_azure_llm_provider(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            workflow_path = Path(tmpdir) / "workflow.yml"
            workflow_path.write_text(
                """
kind: app
app:
  mode: workflow
workflow:
  graph:
    nodes:
      - id: start
        data:
          type: start
          variables:
            - variable: source_text
      - id: llm
        data:
          type: llm
          context:
            enabled: false
            variable_selector: []
          vision:
            enabled: false
          model:
            provider: other/provider
            mode: chat
            name: gpt-4o
            completion_params: {}
          prompt_template:
            - role: user
              text: "{{#start.source_text#}}"
      - id: end
        data:
          type: end
          outputs: []
    edges:
      - source: start
        target: llm
      - source: llm
        target: end
""",
                encoding="utf-8",
            )

            with self.assertRaisesRegex(PlanValidationError, "model.provider"):
                load_dify_workflow_definition(workflow_path)

    def test_imports_loop_as_single_top_level_node_and_ignores_notes(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            workflow_path = Path(tmpdir) / "workflow.yml"
            workflow_path.write_text(
                """
kind: app
app:
  mode: workflow
workflow:
  graph:
    nodes:
      - id: start
        data:
          type: start
      - id: note
        data:
          type: ""
      - id: loop
        data:
          type: loop
          title: Retry Loop
          loop_count: 3
          break_conditions: []
          error_handle_mode: terminated
          start_node_id: loop_start
          loop_variables:
            - label: count
              value_type: constant
              value: "0"
            - label: message
              value_type: constant
              value: init
      - id: loop_start
        parentId: loop
        data:
          type: loop-start
      - id: inc
        parentId: loop
        data:
          type: code
          title: Increment
          code_language: python3
          code: |
            def main(count):
                next_count = count + 1
                return {"count": next_count, "message": f"iter-{next_count}", "is_done": next_count == 2}
          variables:
            - variable: count
              value_selector: [loop, count]
          outputs:
            count:
              type: number
            message:
              type: string
            is_done:
              type: boolean
      - id: assign
        parentId: loop
        data:
          type: assigner
          title: Assign
          items:
            - input_type: variable
              operation: over-write
              output_name: count
              value: [inc, count]
              variable_selector: [loop, count]
            - input_type: variable
              operation: over-write
              output_name: message
              value: [inc, message]
              variable_selector: [loop, message]
      - id: branch
        parentId: loop
        data:
          type: if-else
          title: Done?
          cases:
            - case_id: done
              logical_operator: and
              conditions:
                - comparison_operator: "="
                  value: "True"
                  variable_selector: [inc, is_done]
      - id: done
        parentId: loop
        data:
          type: template-transform
          title: Done
          template: done
          variables: []
      - id: continue
        parentId: loop
        data:
          type: template-transform
          title: Continue
          template: continue
          variables: []
      - id: loop_end
        parentId: loop
        data:
          type: loop-end
      - id: end
        data:
          type: end
          outputs:
            - variable: count
              value_selector: [loop, count]
            - variable: message
              value_selector: [loop, message]
    edges:
      - source: start
        target: loop
        sourceHandle: source
        data:
          sourceType: start
      - source: loop
        target: end
        sourceHandle: source
        data:
          sourceType: loop
      - source: loop_start
        target: inc
      - source: inc
        target: assign
        data:
          sourceType: code
      - source: assign
        target: branch
        data:
          sourceType: assigner
      - source: branch
        target: done
        sourceHandle: done
        data:
          sourceType: if-else
      - source: branch
        target: continue
        sourceHandle: false
        data:
          sourceType: if-else
      - source: done
        target: loop_end
""",
                encoding="utf-8",
            )

            plan = load_dify_workflow_definition(workflow_path)

            self.assertEqual([node.id for node in plan.nodes], ["start", "loop", "end"])
            self.assertEqual(plan.nodes[1].kind, "loop")
            self.assertEqual(plan.nodes[1].config["max_iterations"], 3)
            self.assertEqual(plan.nodes[1].config["loop_variables"], {"count": 0, "message": "init"})
            self.assertEqual(plan.nodes[1].config["body"]["entry_nodes"], ["inc"])
            self.assertEqual(plan.nodes[1].config["body"]["break_nodes"], ["done"])
            self.assertEqual(plan.nodes[2].inputs, {"count": "{{ nodes['loop'].count }}", "message": "{{ nodes['loop'].message }}"})

    def test_imported_loop_workflow_runs(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            workflow_path = Path(tmpdir) / "workflow.yml"
            workflow_path.write_text(
                """
kind: app
app:
  mode: workflow
workflow:
  graph:
    nodes:
      - id: start
        data:
          type: start
      - id: loop
        data:
          type: loop
          loop_count: 3
          break_conditions: []
          error_handle_mode: terminated
          start_node_id: loop_start
          loop_variables:
            - label: count
              value_type: constant
              value: "0"
            - label: message
              value_type: constant
              value: init
      - id: loop_start
        parentId: loop
        data:
          type: loop-start
      - id: inc
        parentId: loop
        data:
          type: code
          code_language: python3
          code: |
            def main(count):
                next_count = count + 1
                return {"count": next_count, "message": f"iter-{next_count}", "is_done": next_count == 2}
          variables:
            - variable: count
              value_selector: [loop, count]
          outputs:
            count:
              type: number
            message:
              type: string
            is_done:
              type: boolean
      - id: assign
        parentId: loop
        data:
          type: assigner
          items:
            - input_type: variable
              operation: over-write
              output_name: count
              value: [inc, count]
              variable_selector: [loop, count]
            - input_type: variable
              operation: over-write
              output_name: message
              value: [inc, message]
              variable_selector: [loop, message]
      - id: branch
        parentId: loop
        data:
          type: if-else
          cases:
            - case_id: done
              logical_operator: and
              conditions:
                - comparison_operator: "="
                  value: "True"
                  variable_selector: [inc, is_done]
      - id: done
        parentId: loop
        data:
          type: template-transform
          template: done
          variables: []
      - id: continue
        parentId: loop
        data:
          type: template-transform
          template: continue
          variables: []
      - id: loop_end
        parentId: loop
        data:
          type: loop-end
      - id: end
        data:
          type: end
          outputs:
            - variable: count
              value_selector: [loop, count]
            - variable: message
              value_selector: [loop, message]
    edges:
      - source: start
        target: loop
        data:
          sourceType: start
      - source: loop
        target: end
        data:
          sourceType: loop
      - source: loop_start
        target: inc
      - source: inc
        target: assign
        data:
          sourceType: code
      - source: assign
        target: branch
        data:
          sourceType: assigner
      - source: branch
        target: done
        sourceHandle: done
        data:
          sourceType: if-else
      - source: branch
        target: continue
        sourceHandle: false
        data:
          sourceType: if-else
      - source: done
        target: loop_end
""",
                encoding="utf-8",
            )

            plan = load_dify_workflow_definition(workflow_path)
            compiled_plan = compile_plan(plan)
            logger = EventLogger(log_path=Path(tmpdir) / "run.jsonl", run_id="imported-loop")
            runtime = WorkflowRuntime(logger=logger)
            try:
                result = _run_runtime(runtime, compiled_plan=compiled_plan, inputs={})
            finally:
                logger.close()

            self.assertEqual(result.status, "succeeded")
            self.assertEqual(result.outputs, {"count": 2, "message": "iter-2"})
            self.assertEqual(set(result.nodes), {"start", "loop", "end"})

    def test_nested_loop_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            workflow_path = Path(tmpdir) / "workflow.yml"
            workflow_path.write_text(
                """
kind: app
app:
  mode: workflow
workflow:
  graph:
    nodes:
      - id: start
        data:
          type: start
      - id: outer
        data:
          type: loop
          loop_count: 1
          break_conditions: []
          error_handle_mode: terminated
          start_node_id: outer_start
          loop_variables:
            - label: count
              value_type: constant
              value: "0"
      - id: outer_start
        parentId: outer
        data:
          type: loop-start
      - id: inner
        parentId: outer
        data:
          type: loop
      - id: end
        data:
          type: end
    edges: []
""",
                encoding="utf-8",
            )

            with self.assertRaisesRegex(PlanValidationError, "nested|may not be nested"):
                load_dify_workflow_definition(workflow_path)


if __name__ == "__main__":
    unittest.main()
