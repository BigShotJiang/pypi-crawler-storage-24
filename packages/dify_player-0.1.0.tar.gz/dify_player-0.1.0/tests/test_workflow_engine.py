from __future__ import annotations

import json
import unittest
from pathlib import Path

import httpx

from dify_player import WorkflowEngine
from dify_player.models import to_data
from tests.workflow_http_server import HTTPServerContext

ROOT = Path(__file__).resolve().parents[1]


class WorkflowEngineTestCase(unittest.IsolatedAsyncioTestCase):
    async def test_run_plan_data_succeeds_without_file_logger(self) -> None:
        engine = WorkflowEngine()
        plan_data = json.loads((ROOT / "examples" / "hello" / "plan.json").read_text(encoding="utf-8"))

        result = await engine.run_plan_data(
            plan_data=plan_data,
            inputs={"name": "World"},
        )

        self.assertEqual(result.status, "succeeded")
        self.assertEqual(result.outputs, {"message": "Hello World"})
        self.assertEqual(to_data(result)["outputs"], {"message": "Hello World"})

    async def test_run_plan_data_uses_caller_managed_http_client(self) -> None:
        engine = WorkflowEngine()
        plan_data = json.loads((ROOT / "examples" / "http_get" / "plan.json").read_text(encoding="utf-8"))

        async with httpx.AsyncClient() as http_client:
            with HTTPServerContext() as (base_url, requests_log):
                result = await engine.run_plan_data(
                    plan_data=plan_data,
                    inputs={"url": f"{base_url}/echo", "query": "hello"},
                    http_client=http_client,
                )

                self.assertEqual(result.status, "succeeded")
                self.assertFalse(http_client.is_closed)
                self.assertEqual(requests_log[0]["method"], "POST")
                self.assertEqual(requests_log[0]["query"], {"q": ["hello"]})
