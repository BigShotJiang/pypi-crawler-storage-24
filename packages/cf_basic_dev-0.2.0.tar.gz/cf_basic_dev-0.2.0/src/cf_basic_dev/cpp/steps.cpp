﻿#include <algorithm>
#include <cstdint>
#include <cstring>
#include <string>
#include <thread>
#include <vector>

#ifdef CF_HAS_OPENMP
  #include <omp.h>
#endif

#include "cf_step_abi.h"
#include "cf_step_utils.h"
#include "cf_plugin_table.h"
#include "cf_basic_dev_signature_hashes.h"

namespace {

static CfStatusCode call_inline_source(
  CfCallContext* ctx,
  const CfValueHandle* params,
  size_t n_params,
  const CfValueHandle*,
  size_t,
  CfValueHandle* outputs,
  size_t n_outputs) {
  using S = cf_sig::InlineSource;
  if (n_params < S::kParamCount || n_outputs < S::kOutputCount) return CF_STATUS_INVALID;
  if (cf_handle_is_empty(&params[S::P_payload])) return CF_STATUS_INVALID;

  std::string payload = cf_handle_to_string(&params[S::P_payload]);
  const std::string prefix = "inline://";
  if (payload.rfind(prefix, 0) == 0) {
    payload = payload.substr(prefix.size());
  }

  std::vector<double> values = cf_parse_inline_values(payload);
  if (values.empty()) return CF_STATUS_INVALID;

  return cf_out_vector_f64(ctx, &outputs[S::O_data], values.data(), values.size());
}

static CfStatusCode call_opcua_ph_source(
  CfCallContext* ctx,
  const CfValueHandle* params,
  size_t n_params,
  const CfValueHandle*,
  size_t,
  CfValueHandle* outputs,
  size_t n_outputs) {
  using S = cf_sig::OpcuaPhSource;
  if (n_params < S::kParamCount || n_outputs < S::kOutputCount) return CF_STATUS_INVALID;
  if (cf_handle_is_empty(&params[S::P_endpoint])) return CF_STATUS_INVALID;

  if (cf_out_f64(ctx, &outputs[S::O_ph], 7.0) != CF_STATUS_OK) return CF_STATUS_ERROR;
  if (cf_out_f64(ctx, &outputs[S::O_temperature], 25.0) != CF_STATUS_OK) return CF_STATUS_ERROR;
  return cf_out_string(ctx, &outputs[S::O_timestamp], "1970-01-01T00:00:00Z");
}

static CfStatusCode call_omp_reduction(
  CfCallContext* ctx,
  const CfValueHandle* params,
  size_t n_params,
  const CfValueHandle*,
  size_t,
  CfValueHandle* outputs,
  size_t n_outputs) {
  int64_t terms = 0;
  (void)n_params;
  (void)n_outputs;
  using S = cf_sig::OmpReductionStep;
  (void)cf_read_i64(&params[S::P_terms], terms);

  double sum = 0.0;
#ifdef CF_HAS_OPENMP
  #pragma omp parallel for reduction(+:sum)
  for (int64_t i = 1; i <= terms; ++i) {
    sum += 1.0 / static_cast<double>(i);
  }
#else
  for (int64_t i = 1; i <= terms; ++i) {
    sum += 1.0 / static_cast<double>(i);
  }
#endif

  if (cf_out_f64(ctx, &outputs[S::O_data], sum) != CF_STATUS_OK) return CF_STATUS_ERROR;
  return CF_STATUS_OK;
}

static CfStatusCode call_budget_aware(
  CfCallContext* ctx,
  const CfValueHandle*,
  size_t,
  const CfValueHandle*,
  size_t,
  CfValueHandle* outputs,
  size_t n_outputs) {
  (void)n_outputs;
  using S = cf_sig::BudgetAwareStep;

  const CfRuntimeHintsV1* hints = cf_runtime_hints_v1(ctx);
  uint32_t observed_budget = 1;
  int observed_deterministic = 0;
  if (hints) {
    observed_budget = hints->thread_budget > 0 ? hints->thread_budget : 1;
    observed_deterministic = (hints->flags & CF_RUNTIME_HINT_DETERMINISTIC) != 0;
  }

  const int64_t work_items = 100000;
  uint32_t threads = observed_budget > 0 ? observed_budget : 1;
  if (work_items > 0) {
    threads = std::min<uint32_t>(threads, static_cast<uint32_t>(work_items));
  }
  threads = std::max<uint32_t>(1, threads);

  uint64_t checksum = 0;
#ifdef CF_HAS_OPENMP
  #pragma omp parallel for num_threads(static_cast<int>(threads)) reduction(+:checksum)
  for (int64_t i = 0; i < work_items; ++i) {
    checksum += static_cast<uint64_t>(i) * 2654435761u;
  }
#else
  std::vector<uint64_t> partial(threads, 0);
  std::vector<std::thread> workers;
  workers.reserve(threads > 1 ? threads - 1 : 0);

  auto worker = [&](uint32_t tid) {
    const int64_t begin = (work_items * static_cast<int64_t>(tid)) / static_cast<int64_t>(threads);
    const int64_t end = (work_items * static_cast<int64_t>(tid + 1)) / static_cast<int64_t>(threads);
    uint64_t local = 0;
    for (int64_t i = begin; i < end; ++i) {
      local += static_cast<uint64_t>(i) * 2654435761u;
    }
    partial[tid] = local;
  };

  for (uint32_t t = 1; t < threads; ++t) {
    workers.emplace_back(worker, t);
  }
  worker(0);
  for (auto& t : workers) {
    t.join();
  }
  for (uint32_t t = 0; t < threads; ++t) {
    checksum += partial[t];
  }
#endif
  (void)checksum;

  if (cf_out_i64(ctx, &outputs[S::O_observed_thread_budget], static_cast<int64_t>(observed_budget)) != CF_STATUS_OK) {
    return CF_STATUS_ERROR;
  }
  if (cf_out_bool(ctx, &outputs[S::O_observed_deterministic], observed_deterministic) != CF_STATUS_OK) {
    return CF_STATUS_ERROR;
  }
  return CF_STATUS_OK;
}

#define CF_BASIC_DEV_STEPS(X) \
  X(cf_generated::kInlineSourceIri, cf_generated::kInlineSourceSigHash, call_inline_source, nullptr) \
  X(cf_generated::kOpcuaPhSourceIri, cf_generated::kOpcuaPhSourceSigHash, call_opcua_ph_source, nullptr) \
  X(cf_generated::kOmpReductionStepIri, cf_generated::kOmpReductionStepSigHash, call_omp_reduction, nullptr) \
  X(cf_generated::kBudgetAwareStepIri, cf_generated::kBudgetAwareStepSigHash, call_budget_aware, nullptr)

}  // namespace

CF_DEFINE_STEP_TABLE(CF_BASIC_DEV_STEPS)

