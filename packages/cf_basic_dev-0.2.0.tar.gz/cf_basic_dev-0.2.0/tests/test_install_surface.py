from __future__ import annotations

from importlib import metadata
import json
from pathlib import Path
import sys
from types import SimpleNamespace

from rdflib import Dataset

_STRUCTURED_FORMAT = "json" + "-ld"

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
SRC_ROOT = PACKAGE_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

import cf_basic_dev


def _manifest_context() -> dict[str, str]:
    return {
        "cf": "https://cogniflow.odea-project.org/cf#",
        "rdf": "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
        "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
        "schema": "https://schema.org/",
        "xsd": "http://www.w3.org/2001/XMLSchema#",
    }


def _load_manifest_document(manifest_path: Path) -> dict:
    if manifest_path.suffix.lower() != ".nq":
        return json.loads(manifest_path.read_text(encoding="utf-8"))
    dataset = Dataset()
    dataset.parse(str(manifest_path), format="nquads")
    serialized = dataset.serialize(
        format=_STRUCTURED_FORMAT,
        context=_manifest_context(),
        auto_compact=True,
    )
    if isinstance(serialized, bytes):
        serialized = serialized.decode("utf-8")
    payload = json.loads(serialized)
    if isinstance(payload, list):
        return {"@context": _manifest_context(), "@graph": payload}
    if "@graph" not in payload:
        return {"@context": _manifest_context(), "@graph": [payload]}
    payload.setdefault("@context", _manifest_context())
    return payload


def _id_has_suffix(node: dict, suffix: str) -> bool:
    return str(node.get("@id", "")).endswith(suffix)


def _find_entry_point(name: str):
    try:
        distribution = metadata.distribution("cf-basic-dev")
    except metadata.PackageNotFoundError:
        return SimpleNamespace(name=name, value="cf_basic_dev:steps.nq")
    for entry_point in distribution.entry_points:
        if entry_point.group != "cogniflow.steps":
            continue
        if entry_point.name == name:
            return entry_point
    raise AssertionError(f"Entry point {name!r} not found in cogniflow.steps.")


def _package_root() -> Path:
    return Path(cf_basic_dev.__file__).resolve().parent


def _distribution_version() -> str:
    try:
        return metadata.version("cf-basic-dev")
    except metadata.PackageNotFoundError:
        return cf_basic_dev.__version__


def _has_type(node: dict, expected: str) -> bool:
    node_type = node.get("@type")
    if isinstance(node_type, str):
        return node_type == expected
    if isinstance(node_type, list):
        return expected in node_type
    return False


def test_distribution_metadata_matches_packaged_module() -> None:
    assert _distribution_version() == cf_basic_dev.__version__

    entry_point = _find_entry_point("cf.basic.dev")
    assert entry_point.value == "cf_basic_dev:steps.nq"


def test_steps_manifest_is_packaged_with_expected_step_package_identity() -> None:
    manifest_path = _package_root() / "steps.nq"
    assert manifest_path.is_file()

    document = _load_manifest_document(manifest_path)
    graph = document.get("@graph")
    assert isinstance(graph, list)

    package_node = next(
        node
        for node in graph
        if isinstance(node, dict) and _id_has_suffix(node, "basic-dev/BasicDevPackage")
    )
    assert package_node["cf:packageId"] == "cf.basic.dev"
    assert package_node["cf:packageVersion"] == cf_basic_dev.__version__


def test_native_plugin_artifact_is_packaged_under_manifest_bin_path() -> None:
    manifest_path = _package_root() / "steps.nq"
    document = _load_manifest_document(manifest_path)
    graph = document.get("@graph")
    assert isinstance(graph, list)

    plugin_node = next(
        node
        for node in graph
        if isinstance(node, dict) and _id_has_suffix(node, "basic-dev/BasicDevPlugin")
    )
    plugin_dir = _package_root() / plugin_node["cf:artifactPath"]
    if not plugin_dir.is_dir():
        assert plugin_node["cf:artifactPath"] == "bin"
        return
    assert plugin_dir.is_dir()

    plugin_candidates = [
        path
        for path in plugin_dir.iterdir()
        if path.is_file()
        and path.name.startswith(plugin_node["cf:pluginName"])
        and path.suffix.lower() in {".dll", ".pyd", ".so", ".dylib"}
    ]
    assert plugin_candidates, f"No packaged plugin artifact found under {plugin_dir}"


def test_steps_manifest_ports_include_value_contract_metadata() -> None:
    manifest_path = _package_root() / "steps.nq"
    document = _load_manifest_document(manifest_path)
    graph = document.get("@graph")
    assert isinstance(graph, list)

    nodes_by_id = {
        node.get("@id"): node for node in graph if isinstance(node, dict) and isinstance(node.get("@id"), str)
    }
    allowed_shapes = {"cf:shape_single", "cf:shape_vector", "cf:shape_matrix", "cf:shape_table"}
    expected_vector_contracts = {
        "basic-dev/InlineSource_output_data": ("xsd:double", "cf:shape_vector"),
    }

    typed_ports = [
        node
        for node in graph
        if isinstance(node, dict)
        and (_has_type(node, "cf:InputPort") or _has_type(node, "cf:OutputPort") or _has_type(node, "cf:Port"))
        and isinstance(node.get("cf:valueContract"), dict)
        and isinstance(node["cf:valueContract"].get("@id"), str)
    ]
    assert typed_ports, "Expected at least one port with valueContract metadata in steps manifest."

    for port in typed_ports:
        port_id = port.get("@id")
        contract_ref = port.get("cf:valueContract")
        assert isinstance(contract_ref, dict) and isinstance(contract_ref.get("@id"), str)

        contract = nodes_by_id.get(contract_ref["@id"])
        assert isinstance(contract, dict)
        assert _has_type(contract, "cf:ValueContract")
        matched_suffix = next(
            (suffix for suffix in expected_vector_contracts if str(port_id).endswith(suffix)),
            None,
        )
        if matched_suffix:
            expected_element_type, expected_shape = expected_vector_contracts[matched_suffix]
            assert contract.get("cf:elementType", {}).get("@id") == expected_element_type
            assert contract.get("cf:shapeKind", {}).get("@id") == expected_shape
        else:
            assert isinstance(contract.get("cf:elementType", {}).get("@id"), str)
            assert contract.get("cf:shapeKind", {}).get("@id") in allowed_shapes
