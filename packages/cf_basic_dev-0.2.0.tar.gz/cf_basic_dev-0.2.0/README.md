# cf-basic-dev

Cogniflow StepPackage for development-only, test, demo, and benchmark steps.

## Steps

| Step | Category | Description |
|------|----------|-------------|
| `cfbd:InlineSource` | source | Emit inline payloads for quick test pipelines |
| `cfbd:OpcuaPhSource` | source | Read virtual pH/temperature demo values from an OPC-UA endpoint |
| `cfbd:OmpReductionStep` | analytical | Synthetic CPU benchmark step for OpenMP/internal parallelism |
| `cfbd:BudgetAwareStep` | analytical | Reference step that reports runtime thread budget hints |

## Notes

- These steps are intended for development, testing, demo, and benchmarking workflows.
- Production pipelines should prefer stable steps from `cf-basic-io` and `cf-basic-signal`.

Published distribution name:

```bash
pip install cf-basic-dev
```

## Native build prerequisites

`cf_basic_dev` is built with `scikit-build-core` and CMake and requires the published SDK package at build time:

- CPython 3.13
- CMake on `PATH`
- a Windows C++ toolchain compatible with that CMake installation
- access to `cf-pipeline-sdk` from the package index

The package-local CMake currently generates the signature header through `python -m cogniflow_pipeline_sdk.siggen` and copies the built plugin artifact into the installed package's `bin/` directory.

## Publishing

`cf_basic_dev` is published with the dedicated Windows workflow:

- Workflow: `.github/workflows/cf_basic_dev_windows_publish.yml`
- Package directory: `sandcastle/cf_basic_steps/cf_basic_dev`
- PyPI tag: `cf-basic-dev-v<version>`
- TestPyPI tag: `cf-basic-dev-v<version>-test`

Local preflight:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/mimic_windows_python_publish_workflow.ps1 `
  -WorkflowFile .github/workflows/cf_basic_dev_windows_publish.yml `
  -PackageDir sandcastle/cf_basic_steps/cf_basic_dev `
  -PythonExe py `
  -PythonVersion 3.13
```

Queue a dry-run dispatch:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/queue_windows_python_publish_workflow.ps1 `
  -WorkflowFile .github/workflows/cf_basic_dev_windows_publish.yml `
  -PackageDir sandcastle/cf_basic_steps/cf_basic_dev `
  -PublishTarget testpypi `
  -Ref main `
  -RequireLocalPass `
  -DryRun
```

Watch queued runs:

```powershell
gh run list --workflow cf_basic_dev_windows_publish.yml --limit 10
gh run watch --exit-status
```
