"""Guide content shared between CLI and MCP server.

Each topic is a Markdown string. The GUIDE_TOPICS dict maps topic names
to their content, and GUIDE_ALL lists them in presentation order.
"""

from __future__ import annotations

GUIDE_STARTUP = """\
# Agent Startup

**Authority:** `plan.yaml` is the SINGLE source of truth.
Conflict? Update plan or escalate. Do not guess.

## Tools Priority
**Always prefer MCP tools** (`vectl_status`, `vectl_claim`, `vectl_complete`, etc.) when available.
CLI fallback priority: `uv run vectl` > `vectl` > `uvx vectl`.

## Workflow
1. `vectl_status` / `vectl status`    — Overview & progress
2. `vectl_guide` / `vectl next`       — Find available work
3. `vectl_claim` / `vectl claim <id>` — Lock a step (one at a time)
4. **Execute**                         — Follow description + refs exactly
5. `vectl_complete` / `vectl complete <id> --evidence "..."` — Submit results
6. Loop

## Claim-time Guidance
`vectl claim` may emit a bounded Guidance block delimited by:
- `--- VECTL:GUIDANCE:BEGIN ---`
- `--- VECTL:GUIDANCE:END ---`

Use the included evidence template as the skeleton for completion evidence.
For automation/CI, disable guidance with: `vectl claim --no-guidance`.

## Evidence (Strict)
Required: Files changed, Verification (cmd + result), Gaps (skipped).
> Ex: "Fixed auth.py. Ran pytest (PASS). No integration tests."

## Agent Instructions (AGENTS.md / CLAUDE.md)
`vectl init` injects a vectl section into AGENTS.md or CLAUDE.md.
To update an existing project to the latest template:
```
vectl agents-md          # auto-detect target file
vectl agents-md --target claude   # force CLAUDE.md
```
"""

GUIDE_STUCK = """\
# Unblocking Strategy

## Rejected? (High Priority)
1. `vectl next`             — Rejected items float to top
2. `vectl show <id>`        — Read **rejection_reason**
3. `vectl claim <id>`       — Re-claim & Fix
4. `vectl complete`         — Submit with new evidence

## Blocked? (Deps Missing)
1. `vectl show <id>`        — Identify missing deps
2. `vectl search <term>`    — Find the blocker
3. **Pivot**                — Work on parallel steps

> **Lock status is automatic.** Completing upstream steps unlocks
> downstream phases on the next write — no manual intervention needed.

## Lock Status Wrong? (After Manual YAML Edit)
If you (or a tool) edited `plan.yaml` directly and lock status looks wrong:
```
vectl recalc-lock           # fix immediately
vectl recalc-lock --dry-run # preview changes first
```
Under normal agent workflow this is never needed — lock status recalculates
on every `claim`, `complete`, or `mutate`.

## Claim Consistency Issues? (Ghost Claims / Split-Brain)
When claim state diverges from plan state:

```
vectl repair claims --dry-run     # diagnose (read-only)
vectl repair claims               # repair all
vectl repair claims --step <id>   # repair specific step
vectl repair claims --dry-run --json  # machine-readable
```

See `vectl guide recovery` for full runbook.
"""

GUIDE_REVIEW = """\
# Review & Validation

## Situational Awareness
1. `vectl review`           — Deep scan (L1:Valid → L4:Specs)
2. `vectl review --all`     — Full history (audit trail)

## Gatekeeping
1. `vectl validate`         — Check structural integrity
2. `vectl gate-check <ph>`  — Check phase completion
3. `vectl validate --check-refs` — Audit file references

> Always review before starting a complex phase.
"""

GUIDE_PLANNING = """\
# Architect Protocol

## 1. Orient
`vectl status` → `vectl review` (Context load)

## 2. Mutate
- `vectl add-phase --name "..."`
- `vectl add-step --phase <p> --name "..." --after <dep> --evidence-template "..."`
- `vectl edit-step <id> --desc "..." --verify "..." --refs "..."`
- `vectl edit-plan --project-guidance-file <path>`
- `vectl move-step <step> --target-phase <phase>` — Move step between phases
- `vectl skip-phase <phase> -r superseded` — Clean up empty/merged phases

## 3. Intelligent Guidance (The "Why")
Your goal is to make the *next* agent (the Worker) succeed without guessing.
Ambiguity = Hallucination.

### A. Evidence Templates (`--evidence-template`)
**Prevent lazy completions.** Don't let workers say "Done". Force them to prove it.
- **Bad**: (No template) → Worker says "Fixed the bug."
- **Good**: Template requires specific command output.
  ```text
  ## Verification
  - Command: `pytest tests/test_auth.py`
  - Output: <paste output here>
  - [ ] Confirmed 0 failures
  ```

### B. Context Pinning (`--refs`)
**Stop searching, start working.** If you know which files need editing, tell the worker.
- Use `--refs "src/auth.py,tests/test_auth.py"`
- Result: Worker receives these file paths immediately upon claiming.
- Benefit: Reduces token usage (no `find_file` loops) and prevents focus drift.

## 4. Restructuring Phases
When reorganizing phases for better dependency granularity:

1. **Move steps** to target phase: `vectl move-step <step> --target-phase <target>`
2. **Skip the now-empty phase**: `vectl skip-phase <empty> -r superseded`
3. **For locked phases**: Empty ones skip freely; non-empty need `--force`

> Why? Lock protects work. Zero steps = zero work = nothing to protect.

## 5. Verify
- `vectl validate` (Mandatory before commit)
- `vectl search <term>` (Check for dupes)
"""


GUIDE_MIGRATION = """\
# Migration: Existing Plan → plan.yaml

If your project already has an implementation plan (markdown file, spreadsheet,
issue tracker), use this workflow to migrate it into plan.yaml.

## Prerequisites

Run `vectl init --project <name>` first. This creates an empty plan.yaml and
configures AGENTS.md (or CLAUDE.md for Claude Code projects).

## Rules

1. **Preserve language.** Use the same language as the original plan.
   If the source is in Chinese, plan.yaml content stays in Chinese.

2. **Respect structure.** Map the original plan's hierarchy into phases/steps
   as directly as possible. Do not reorganize, merge, or split unless the
   user requests it.

3. **Copy, don't rephrase.** Use the original titles and descriptions verbatim.
   Do not summarize, reword, or "improve" the text during migration.

4. **Surface issues, don't silently fix.** If you detect dependency errors,
   missing references, or structural inconsistencies, ask the user whether
   to auto-fix. Only apply fixes after explicit confirmation.

## Step ID Uniqueness (Important)

**Step IDs must be GLOBALLY UNIQUE across ALL phases.**

- Before vectl, step IDs only needed to be unique within a phase.
- Now, the same step ID cannot appear in multiple phases.
- Use qualified IDs like `phase-name.step-id` to ensure uniqueness.

Example (correct):
```yaml
phases:
  - id: auth
    steps:
      - id: auth.login      # unique
  - id: api
    steps:
      - id: api.login       # different from auth.login
```

Example (incorrect - will be rejected):
```yaml
phases:
  - id: auth
    steps:
      - id: login
  - id: api
    steps:
      - id: login           # ERROR: duplicate with auth.login
```

## Legacy Duplicate Step ID Repair

If you have an existing plan with duplicate step IDs (created before this
requirement), use the migration tool to repair:

```bash
# Preview the changes (dry-run)
vectl migrate-step-id --dry-run

# Apply the migration
vectl migrate-step-id --yes
```

The migration tool will:
1. Detect all duplicate step IDs across phases
2. Rename non-canonical occurrences to `{phase_id}.{old_step_id}`
3. Rewrite depends_on references to preserve DAG structure
4. Emit a mapping of old IDs → new IDs for automation updates

**Important:** Read-only commands (status, show, validate) NEVER mutate plan
files. Only `migrate-step-id --yes` will modify step IDs in phase B.

### Ambiguous Target Handling (Phase B)

When a targeted command (claim, complete, etc.) hits an ambiguous duplicate,
the command fails with structured repair guidance and does not mutate state:

```bash
$ vectl claim login
Error: Ambiguous step ID 'login' appears in: auth, api
Recommendation: run 'vectl migrate-step-id --dry-run' then 'vectl migrate-step-id --yes'
```

### Post-Migration Automation Updates

After migration, update any scripts or automation that reference old step IDs:

```bash
# Get the mapping
vectl migrate-step-id --dry-run --json

# Update your scripts to use new IDs
# Old: vectl claim login
# New: vectl claim auth.login
```

## Workflow

1. **Read** the existing plan in full. Identify phases and steps.

2. **Build** plan.yaml incrementally.

   **CLI Users** (terminal):
   - `vectl add-phase --phase-id <id> --name "<name>"`
   - `vectl add-step --phase-id <id> --step-id <id> --name "<name>"`
   - `vectl add-step ... --description "<desc>" --depends-on "dep1,dep2"`

   **MCP Agents** (Claude/Cursor):
   - Use `vectl_mutate` tool with `action="add-phase"` or `action="add-step"`.
   - Arguments map 1:1 (e.g., `--depends-on` → `depends_on=["dep1", "dep2"]`).

3. **Verify** with `vectl render` — compare against the original plan.
   - Every phase accounted for?
   - Every step accounted for?
   - Dependencies correct?
   - Step IDs globally unique?

4. **Drop** content that belongs in AGENTS.md / CLAUDE.md, not plan.yaml
   (testing strategy, coding standards, architectural decisions).
   plan.yaml tracks *what to do*. AGENTS.md / CLAUDE.md tracks *how to do it*.

5. **Archive** the old plan (e.g., move to `docs/_archive/`).
   plan.yaml is now the single source of truth.

## What Goes Where

- **Phase headings** in source doc → `vectl add-phase` (or `vectl_mutate action=add-phase`)
- **Step items** under each phase → `vectl add-step` (or `vectl_mutate action=add-step`)
- **Dependencies** between steps → `--depends-on` (or `depends_on=[...]`)
- **Context/descriptions** → `--description` / `--context`

| Content                        | plan.yaml | AGENTS.md / CLAUDE.md / docs/ |
|--------------------------------|-----------|-------------------------------|
| Phases, steps, dependencies    | ✅        | —                              |
| Step descriptions & verification | ✅      | —                              |
| Status tracking                | ✅        | —                              |
| Coding standards & rules       | —         | ✅                             |
| Testing strategy & tiers       | —         | ✅                             |
| Architecture decisions         | —         | ✅ docs/                       |

## Tips

- **Tip:** vectl searches parent directories for `plan.yaml` automatically.
- Use `vectl review` after building to check for orphan deps or missing verifications.
- Mark already-completed steps: `vectl complete <step-id> --evidence "pre-migration: done"`.
- One phase at a time. Verify as you go — don't build the entire plan in one pass.
- **Important:** Always use globally unique step IDs. When in doubt, prefix with phase ID.
"""


GUIDE_RECOVERY = """\
# Claim Recovery Runbook

Ghost claims and split-brain claim state can block work. This guide covers
symptom recognition and the recovery workflow.

## Symptom Recognition

| Symptom | Likely Cause |
|---------|-------------|
| Claim rejected, `show` says unclaimed | Ghost claim in `claims.json` (stale/orphaned) |
| Claim rejected, `show` shows different owner | Split-brain: claims.json vs plan.yaml disagree |
| `status` shows claimed, but no agent working | Stale claim (agent crashed/left) |

**Example error**:
```
$ vectl claim auth.user-model
Error: Step 'auth.user-model' is already claimed on branch 'main'

$ vectl show auth.user-model
status: pending
claimed_by: null
```

## Recovery Commands

```bash
# 1. Preview changes (safe, read-only)
vectl repair claims --dry-run

# 2. Machine-readable output (CI/scripting)
vectl repair claims --dry-run --json

# 3. Repair all claims on current branch
vectl repair claims

# 4. Repair specific step only (scoped)
vectl repair claims --step auth.user-model
```

## Flags

| Flag | Purpose |
|------|---------|
| `--dry-run` | Preview without writing. **Always run first.** |
| `--step <id>` | Scope repair to single step. Other claims untouched. |
| `--json` | JSON output for automation. |

## Policy: Plan Precedence

`vectl repair claims` follows **plan precedence**:
- `plan.yaml` is source of truth for claim-visible state
- Claims entries for current branch are repaired to match plan step status/owner
- Out-of-scope entries (other branches, unrelated steps) preserved

## When Repo is Healthy (No-Op)

If consistent, `--dry-run` returns:
```json
{"changed": false, "actions": []}
```

No repair needed — claims.json already matches plan.yaml.

## Full Recovery Sequence

```bash
# Step 1: Diagnose
vectl repair claims --dry-run --json

# Step 2: If changes needed, review them
# Look for "ghost_claim_or_non_claimed_step" or "stale_claim_entry"

# Step 3: Apply repair
vectl repair claims

# Step 4: Verify
vectl status
vectl show <step-id>
vectl repair claims --dry-run  # should show no changes
```

## MCP Equivalent

```python
vectl_repair_claims(dry_run=True)           # diagnose
vectl_repair_claims(dry_run=False)          # repair
vectl_repair_claims(step_id="auth.user")   # scoped
```
"""


GUIDE_ALL: list[str] = [
    GUIDE_STARTUP,
    GUIDE_STUCK,
    GUIDE_RECOVERY,
    GUIDE_REVIEW,
    GUIDE_PLANNING,
    GUIDE_MIGRATION,
]

GUIDE_TOPICS: dict[str, str] = {
    "startup": GUIDE_STARTUP,
    "stuck": GUIDE_STUCK,
    "recovery": GUIDE_RECOVERY,
    "review": GUIDE_REVIEW,
    "planning": GUIDE_PLANNING,
    "migration": GUIDE_MIGRATION,
}

VALID_TOPICS = list(GUIDE_TOPICS.keys())
