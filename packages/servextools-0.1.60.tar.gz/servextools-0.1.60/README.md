# ServexTools
[![PyPI version](https://badge.fury.io/py/servextools.svg)](https://pypi.org/project/servextools/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

Framework avanzado para desarrollo de sistemas empresariales Python/Flask con MongoDB

---

## Descripción General
ServexTools es un framework completo para acelerar el desarrollo de aplicaciones empresariales en Python, especialmente orientado a sistemas basados en Flask y MongoDB. Proporciona un conjunto de herramientas optimizadas para manejo de datos, generación de interfaces, seguridad, comunicación en tiempo real y más.

### Características principales
- **Integración avanzada con MongoDB**: CRUD optimizado, replicación automática, manejo de transacciones y sesiones distribuidas
- **Generación de tablas HTML de alto rendimiento**: Procesamiento vectorizado con Polars y NumPy para grandes volúmenes de datos
- **WebSockets optimizados**: Comunicación bidireccional en tiempo real con configuración para alta disponibilidad
- **Sistema de sesiones distribuidas**: Almacenamiento eficiente de datos de sesión en MongoDB
- **Seguridad integrada**: Limitación de peticiones, encriptación JWT, protección contra ataques
- **Utilidades de fecha/hora**: Conversión, formateo y cálculos con soporte para zonas horarias
- **Logs avanzados**: Sistema de logs con rotación, categorización y notificaciones en tiempo real
- **Operaciones con archivos**: Manipulación segura, compresión y procesamiento eficiente

---

## Estructura del Proyecto

```
ServexTools/
├── Tools.py           # Utilidades generales y funciones de ayuda (989 líneas)
├── Table.py           # Generación de tablas HTML de alto rendimiento (1494 líneas)
├── ReplicaDb.py       # Sistema de replicación MongoDB en tiempo real (560 líneas)
├── conexion.py        # Abstracción para conexiones a bases de datos (432 líneas)
├── Necesario.py       # Manejo de sesiones distribuidas y paginación (241 líneas)
├── socket_manager.py  # Gestión optimizada de WebSockets (72 líneas)
├── EscribirLog.py     # Sistema de logs avanzado (163 líneas)
├── Limiter.py         # Control de tasa de peticiones y seguridad (138 líneas)
├── TablePV.py         # Tablas especializadas para punto de venta (632 líneas)
├── GetTime.py         # Utilidades avanzadas de tiempo y fecha (62 líneas)
├── Enumerable.py      # Enumeraciones y constantes del sistema (7 líneas)
└── __init__.py        # Inicialización del paquete
```

---

## Instalación

```bash
pip install servextools
```

## Uso Rápido

### Conexión y operaciones con MongoDB
```python
from ServexTools import conexion

# Conexión básica
coleccion, cliente = conexion.Get('usuarios')

# Inserción con manejo automático de historial
from ServexTools import Tools
datos = {"nombre": "Juan", "edad": 30}
conexion.ProcesarDatos('usuarios', datos, 'idusuario', PonerHistorial=True)

# Replicación automática entre instancias
from ServexTools.ReplicaDb import ReplicaCluster
cluster = ReplicaCluster(
    'mongodb://user:pass@servidor-principal:27017/db?authSource=admin',
    'mongodb://user:pass@servidor-replica:27017/db?authSource=admin'
)
coleccion = cluster['midb']['usuarios']
coleccion.insert_one({"nombre": "Ana", "edad": 25})  # Se replica automáticamente
```

### Generación de tablas HTML de alto rendimiento
```python
from ServexTools import Table

# Datos de ejemplo (funciona eficientemente con miles o millones de registros)
datos = [
    {"Nombre": "Juan", "Edad": 30, "Salario": 2500.50},
    {"Nombre": "Ana", "Edad": 25, "Salario": 3200.75}
]

# Configuración de columnas
columnas = ("Nombre", "Edad", "Salario")
datos_columnas = ("Nombre", "Edad", "Salario")
class_columnas = ("text-left", "text-center", "text-right")
formato_columnas = ("", "", "moneda")
totalizar_columnas = (False, False, True)

# Generar tabla HTML con paginación y formateo automático
html = Table.CrearTabla(
    datos,
    NombreColumnas=columnas,
    DatosColumnas=datos_columnas,
    ClassColumnas=class_columnas,
    FormatoColumnas=formato_columnas,
    TotalizarColumnas=totalizar_columnas,
    paginacion=True,
    LongitudPaginacion=100
)
```

### WebSockets optimizados
```python
from flask import Flask
from ServexTools.socket_manager import init_socketio, init

# Inicializar gevent al principio de la aplicación
init()

app = Flask(__name__)
# Configuración optimizada para producción con Redis
socketio = init_socketio(app, isProduccion=True, Proyecto="MiAplicacion")

@socketio.on('connect')
def handle_connect():
    print('Cliente conectado')

@socketio.on('mensaje')
def handle_mensaje(data):
    socketio.emit('respuesta', {'status': 'recibido'})

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5000)
```

### Control de tasa de peticiones
```python
from flask import Flask
from ServexTools.Limiter import rate_limit

app = Flask(__name__)

@app.route('/api/datos')
@rate_limit(max_requests=15, window_seconds=60)
def obtener_datos():
    # Esta ruta está protegida contra abusos
    return {'datos': 'información importante'}
```

### Sesiones distribuidas
```python
from flask import Flask
from ServexTools.Necesario import Session

app = Flask(__name__)
app.secret_key = 'clave-secreta'

@app.route('/guardar')
def guardar_datos():
    # Almacena grandes volúmenes de datos en MongoDB
    Session['datos_usuario'] = {'historial': [...], 'preferencias': {...}}
    return 'Datos guardados'

@app.route('/recuperar')
def recuperar_datos():
    # Recupera datos de forma eficiente
    datos = Session['datos_usuario']
    return datos
```

---

## Componentes Principales

### Tools.py
Colección extensa de utilidades para operaciones comunes en aplicaciones empresariales:

- **Manipulación de fechas**: Conversión, formateo, cálculos y zonas horarias
  ```python
  from ServexTools import Tools
  
  # Conversión y formateo
  fecha = Tools.StrToDate("25/12/2023")
  fecha_formateada = Tools.DateFormat(fecha)
  
  # Cálculos con fechas
  fecha_futura = Tools.DateTimeAdd_D_H_M_S(fecha, AddDias=5, AddHoras=2)
  ```

- **Operaciones con archivos**
  ```python
  # Lectura/escritura segura
  contenido = Tools.ReadFile("config.json")
  Tools.WriteFile("log.txt", "Nueva entrada de log")
  
  # Operaciones con directorios
  if not Tools.ExisteDirectorio("datos"):
      Tools.CrearDirectorio("datos")
  ```

- **Formateo de datos**
  ```python
  # Conversión de tipos
  numero = Tools.StrToInt("123")
  decimal = Tools.StrToFloat("123.45")
  
  # Formateo de moneda
  valor_formateado = Tools.FormatoMoneda(1234.56)  # "$1,234.56"
  ```

- **Seguridad**
  ```python
  # Encriptación/desencriptación JWT
  token = Tools.Encriptar({"usuario": 123}, "clave-secreta")
  datos = Tools.DesEncriptar(token, "clave-secreta")
  ```

- **Manejo de respuestas API**
  ```python
  from ServexTools.Enumerable import TipoMensaje
  
  # Respuesta estándar
  respuesta = Tools.Mensaje(
      iddatos=usuario_id,
      estatus="Exito",
      mensaje="Operación completada",
      tipomensaje=TipoMensaje.MSJ
  )
  ```

### Table.py
Sistema avanzado para generación de tablas HTML con procesamiento vectorizado:

- **Características avanzadas**:
  - Procesamiento paralelo con Polars y NumPy para millones de registros
  - Paginación cliente/servidor automática
  - Formateo condicional de celdas
  - Cálculo de totales y subtotales
  - Marcado condicional de filas
  - Subfilas y datos anidados
  - Exportación a diferentes formatos

- **Optimizaciones**:
  - Caché LRU para operaciones repetitivas
  - Procesamiento por lotes para grandes volúmenes
  - Generación eficiente con StringIO
  - Notificaciones de progreso en tiempo real

### ReplicaDb.py
Sistema de replicación MongoDB en tiempo real:

- **Replicación transparente**: Las operaciones se replican automáticamente a un servidor secundario
- **Cola de operaciones**: Sistema de cola para garantizar la consistencia
- **Manejo de errores**: Reintentos automáticos y registro de errores
- **API compatible**: Implementa la misma API que PyMongo para facilitar la integración

### conexion.py
Abstracción para conexiones a bases de datos:

- **Conexión MongoDB**: Configuración automática con parámetros óptimos
- **Historial de cambios**: Registro automático de modificaciones en documentos
- **Transacciones**: Soporte para operaciones atómicas
- **Integridad de datos**: Validación automática antes de operaciones

### socket_manager.py
Gestión optimizada de WebSockets:

- **Configuración para producción**: Optimizaciones para entornos de alta disponibilidad
- **Integración con Redis**: Comunicación entre múltiples instancias
- **Canales seguros**: Generación automática de canales únicos
- **Configuración de timeouts**: Ajustes para mantener conexiones estables

### Limiter.py
Control avanzado de tasa de peticiones:

- **Protección contra abusos**: Limitación de peticiones por IP o usuario
- **Bloqueo progresivo**: Mayor tiempo de bloqueo para intentos repetidos
- **Detección de ataques**: Identificación de patrones sospechosos
- **Integración con Redis**: Almacenamiento distribuido de contadores

### Necesario.py
Sistema de sesiones distribuidas:

- **Almacenamiento en MongoDB**: Soporte para grandes volúmenes de datos en sesión
- **Fragmentación automática**: División de datos grandes en fragmentos
- **Paginación servidor**: Sistema optimizado para tablas con millones de registros
- **Índices automáticos**: Creación de índices para consultas eficientes

---

## Dependencias Principales
- **flask**: Framework web
- **pymongo**: Cliente MongoDB
- **polars-lts-cpu**: Procesamiento de datos vectorizado
- **numpy**: Operaciones numéricas vectorizadas
- **flask-socketio**: Comunicación en tiempo real
- **gevent**: Servidor WSGI asíncrono
- **redis**: Almacenamiento en memoria distribuido
- **PyJWT**: Tokens web JSON
- **pytz**: Soporte para zonas horarias
- **httpx**: Cliente HTTP asíncrono

---

## Licencia
MIT - Ver archivo [LICENSE](LICENSE)

---

## Contribución
Las contribuciones son bienvenidas. Por favor, asegúrate de seguir las convenciones de código existentes y añadir pruebas para nuevas funcionalidades.


---

## Referencia Exacta de API (Generada Automáticamente)

A continuación se detalla una exploración exhaustiva de todas las clases y funciones principales expuestas por el framework:

### Módulo `Enumerable.py`

#### Clase: `TipoMensaje`
Sin documentación.

#### Clase: `Metodo`
Sin documentación.

#### Clase: `async_mode`
Sin documentación.

### Módulo `EscribirLog.py`

#### Clase: `TipoLog`
Sin documentación.

#### Función: `_get_log_directory()`
*Obtiene y crea el directorio de logs si no existe*

#### Función: `_get_logger(name, filename)`
*Crea o retorna un logger configurado con RotatingFileHandler*

#### Función: `EscribirLog(texto, tipo)`
*Escribe log de errores o éxitos.*

#### Función: `EscribirConsola(texto)`
*Escribe log de consola. Append-only.*

#### Función: `EscribirProcesos(texto)`
*Escribe log de procesos. Append-only.*

#### Función: `EscribirUpdate(texto)`
*Escribe log de updates y emite por socket. Append-only.*

#### Función: `LimpiarLogsAntiguos(dias)`
*Limpia archivos de log más antiguos que X días.*

#### Función: `GetDirectorio()`
*Función legacy - mantener por compatibilidad*

### Módulo `GetTime.py`

#### Función: `CalDias(fechaInicial, FechaActual, tiempoGratis)`
*Sin documentación rápida.*

#### Función: `CalDiasExactos(fechaInicial)`
*Sin documentación rápida.*

#### Función: `CalHoras(fechaInicial, FechaActual, tiempoGratis, redondear)`
*Sin documentación rápida.*

#### Función: `CalMinutos(fechaInicial, FechaActual, tiempoGratis)`
*Sin documentación rápida.*

#### Función: `CalSegundos(fechaInicial)`
*Sin documentación rápida.*

#### Función: `CalHolaYMinutos(fechaInicial, fechaFinal)`
*Sin documentación rápida.*

#### Función: `CalMinutosTransc(fechaInicial)`
*Sin documentación rápida.*

### Módulo `Limiter.py`

#### Función: `get_real_ip()`
*Obtener la IP real del cliente cuando nginx actúa como proxy*

#### Función: `limitar_peticiones(key, max_requests, window_seconds, redisconexion)`
*Implementación manual de rate limiting usando Redis con detección de ataques*

#### Función: `rate_limit(max_requests, window_seconds, key_func)`
*Decorador para limitar peticiones a una ruta*

### Módulo `MTRequest.py`

#### Función: `_extraer_ip_valida(ip_string)`
*Extrae una IP válida de una cadena que puede contener puerto o múltiples IPs*

#### Función: `GetMetaData(datosusuario)`
*Sin documentación rápida.*

#### Función: `_ParsearUserAgent(user_agent)`
*Parsear User-Agent para extraer información del navegador y sistema operativo*

### Módulo `Necesario.py`

#### Clase: `SessionMeta`
Sin documentación.
- Método: `__getitem__(cls, key, sessionidusuario)`
- Método: `__setitem__(cls, key, value, sessionidusuario)`

#### Clase: `Session`
Sin documentación.
- Método: `__init__(self, sessionidusuario)`
- Método: `__setitem__(self, key)`
- Método: `__getitem__(self, key)`

#### Función: `_formatear_find_paginacion(dt)`
*Sin documentación rápida.*

#### Función: `_convertir_lista_a_tupla_recursivo(lista)`
*Sin documentación rápida.*

#### Función: `find_paginacion(RUTA_TABLA, idusuario, page)`
*Sin documentación rápida.*

#### Función: `ensure_pagination_indexes()`
*Ensure that the required indexes exist in the pagination collection.*

#### Función: `insert_paginacion(RUTA_TABLA, datos, ps_idusuario, longitud_paginacion, parametros_tabla, totales)`
*Sin documentación rápida.*

#### Función: `delete_paginacion(RUTA_TABLA, ps_idusuario)`
*Sin documentación rápida.*

#### Función: `delete_paginacionRT(RUTA_TABLA)`
*Sin documentación rápida.*

#### Función: `BloquearProceso(lock_id, expiracion, process_id)`
*Intentar adquirir el bloqueo de manera atómica*

#### Función: `ActualizarLock(lock_id, process_id)`
*Sin documentación rápida.*

#### Función: `BorrarLock()`
*Sin documentación rápida.*

#### Función: `BloqueoLiderActivo()`
*Sin documentación rápida.*

#### Función: `BorrarLockNoLider()`
*Sin documentación rápida.*

#### Función: `ObtenerInfoBloqueo(lock_id)`
*Sin documentación rápida.*

#### Función: `LiberarBloqueoProceso(lock_id, process_id)`
*Sin documentación rápida.*

#### Función: `AdquirirBloqueoProceso(lock_id, expiracion, tiempo_espera)`
*Sin documentación rápida.*

#### Función: `VerificarBloqueoProceso(lock_id, process_id)`
*Sin documentación rápida.*

#### Función: `InsertaProceso(idproceso)`
*Sin documentación rápida.*

#### Función: `SProcesos()`
*Sin documentación rápida.*

#### Función: `BorrarProceso(idproceso)`
*Sin documentación rápida.*

#### Función: `convertir_documento(doc)`
*Sin documentación rápida.*

### Módulo `ReplicaDb.py`

#### Clase: `ReplicaCollection`
Sin documentación.
- Método: `__init__(self, conexion_local, conexion_replica, db_local, db_replica, col_local, col_replica)`
- Método: `__getattr__(self, name)`
- Método: `_process_replica(self, func, args, kwargs)`
  - *Procesa las operaciones de replicación en cola*
- Método: `_queue_replica_operation(self, func)`
  - *Encola una operación de replicación*
- Método: `_convert_args(self, accion, args, kwargs)`
  - *Convierte los argumentos al tipo correcto según la operación*
- Método: `procesar_cola(self, _id)`
  - *Procesar las operaciones de cola*
- Método: `sincronizar_datos(self)`
  - *Procesa los errores almacenados en la colección errores_replica*
- Método: `find(self)`
- Método: `find_one(self)`
- Método: `aggregate(self)`
- Método: `list_indexes(self)`
  - *Lista los índices de la colección local*
- Método: `drop(self)`
  - *Elimina la colección local*
- Método: `insert_one(self, document, bypass_document_validation, session, comment)`
- Método: `insert_many(self, documents, ordered, bypass_document_validation, session, comment)`
- Método: `update_one(self, filter, update, upsert, bypass_document_validation, collation, array_filters, hint, session, let, comment)`
- Método: `update_many(self, filter, update, upsert, array_filters, bypass_document_validation, collation, hint, session, let, comment)`
- Método: `delete_one(self, filter, collation, hint, session, let, comment)`
- Método: `delete_many(self, filter, collation, hint, session, let, comment)`
- Método: `create_index(self, keys)`
  - *Crea un índice en la colección local y lo replica en la colección remota*
- Método: `create_indexes(self, indexes)`
  - *Crea múltiples índices en la colección local y los replica en la colección remota*

#### Clase: `ReplicaDB`
Sin documentación.
- Método: `__init__(self, conexion_local, conexion_replica, db_local, db_replica)`
- Método: `__getattr__(self, name)`
- Método: `list_collection_names(self)`
  - *Retorna los nombres de las colecciones en la base de datos local*
- Método: `__getitem__(self, name)`

#### Clase: `ReplicaCluster`
Sin documentación.
- Método: `__init__(self, conexion_local, conexion_replica, local_kwargs, replica_kwargs)`
  - *Args:*
- Método: `__getattr__(self, name)`
- Método: `start_session(self)`
  - *Inicia una sesión en la conexión local y crea una sesión paralela para la réplica*
- Método: `__getitem__(self, name)`

### Módulo `Table.py`

#### Función: `CrearTabla(Datos, NombreColumnas, DatosColumnas, ClassColumnas, FormatoColumnas, TotalizarColumnas, ColumnasJson, SubColumnasDatos, SubFilas, FilasPlus, MarcarRows, Titulo, nombreClase, idtable, MostrarLosTH, MostralConteo, TablaNumero, IncluirScript, RealizarReplace, paginacion, paginacion_server, LongitudPaginacion, claseprincipal, progressBar, sessionidusuario, reporte, conteo, iddivtable, ps_paginando, ps_conteo, ps_offset, ps_func, ps_current_active_page)`
*Generador de tablas HTML con múltiples opciones avanzadas.*

#### Función: `CrearFila(nombreClase, NumeralTabla, style, RespuestaValidacion)`
*Genera el HTML para la apertura de una fila de tabla con clases y estilos específicos.*

#### Función: `MarcarFilas(MarcarRows, SubColumnasDatos, DatosColumnas, row)`
*Aplica marcado condicional a filas de tabla basado en valores de datos.*

#### Función: `CondicionParaTotalizar(ColumnaTotales, SubColumnasDatos, DatosColumnas, row)`
*Determina si una fila debe incluirse en los cálculos de totales basado en una condición.*

#### Función: `ValidarLongitudDatos(NombreColumnas, DatosColumnas, ClassColumnas, FormatoColumnas, TotalizarColumnas, SubColumnasDatos)`
*Sin documentación rápida.*

#### Función: `ProcesarSubDatos(SubColumnasDatos, countCol, col, row)`
*Sin documentación rápida.*

#### Función: `SubDatosMarcar(SubColumnasDatos, DatosColumnas, col, row)`
*Obtiene datos anidados para marcar filas condicionalmente.*

#### Función: `process_nested_data(tup, row)`
*Procesa datos anidados de forma optimizada utilizando Polars.*

#### Función: `recursive_access(row, tup)`
*Proporciona acceso recursivo a datos anidados con manejo de errores.*

#### Función: `ProcesarSubFilas(SubFilas, row, FilasPlus)`
*Procesa las subfilas de una tabla y genera el HTML correspondiente.*

#### Función: `HtmlSubfilas(Datos, DatosColumnas, FormatoColumnas, FilasPlus)`
*Genera el HTML para las filas de una subtabla basado en los datos proporcionados.*

#### Función: `_procesar_dict_filas(row, DatosColumnas, FormatoColumnas, FilasPlus)`
*Genera el HTML para una fila de tabla a partir de un diccionario de datos.*

#### Función: `ProcesarFilasPlus(FilasPlus, row)`
*Procesa filas adicionales anidadas y genera el HTML correspondiente.*

#### Función: `obtener_datos_anidados(PCampo, clave)`
*Obtiene datos anidados de diccionarios o listas de forma segura.*

#### Función: `HtmlfilasPlus(Datos, DatosColumnas, FormatoColumnas)`
*Genera el HTML para filas adicionales en tablas anidadas.*

#### Función: `aplicar_formato_lote(datos, formato)`
*Aplica formato a un lote de datos utilizando operaciones vectorizadas para optimizar rendimiento.*

#### Función: `Formatos(FormatoColumnas, countCol, columna)`
*Aplica formato a un valor de columna con optimizaciones de rendimiento.*

#### Función: `_format_cached(value, format_type)`
*Versión con caché de las funciones de formato para mejorar rendimiento.*

#### Función: `CrearTablaReport(Datos, NombreColumnas, DatosColumnas, ClassColumnas, FormatoColumnas, TotalizarColumnas, ColumnasJson, SubColumnasDatos, SubFilas, FilasPlus, MarcarRows, conteo, progressBar, sessionidusuario)`
*Sin documentación rápida.*

#### Función: `TableVacia(NombreColumnas, ColumnasJson, ClassColumnas, Titulo, idtable)`
*Sin documentación rápida.*

#### Función: `PaginacionServer_ps(RUTA_TABLA)`
*Sin documentación rápida.*

### Módulo `TablePV.py`

#### Función: `CrearFila(nombreClase, NumeralTabla, style, RespuestaValidacion)`
*Sin documentación rápida.*

#### Función: `MarcarFilas(MarcarRows, SubColumnasDatos, DatosColumnas, row)`
*Sin documentación rápida.*

#### Función: `CondicionParaTotalizar(ColumnaTotales, SubColumnasDatos, DatosColumnas, row)`
*Sin documentación rápida.*

#### Función: `ValidarLongitudDatos(NombreColumnas, DatosColumnas, ClassColumnas, FormatoColumnas, TotalizarColumnas, SubColumnasDatos)`
*Sin documentación rápida.*

#### Función: `ProcesarSubDatos(SubColumnasDatos, countCol, col, row)`
*Sin documentación rápida.*

#### Función: `SubDatosMarcar(SubColumnasDatos, DatosColumnas, col, row)`
*Sin documentación rápida.*

#### Función: `ProcesarSubFilas(SubFilas, row, FilasPlus)`
*Sin documentación rápida.*

#### Función: `HtmlSubfilas(Datos, DatosColumnas, FormatoColumnas, FilasPlus)`
*Sin documentación rápida.*

#### Función: `ProcesarFilasPlus(FilasPlus, row)`
*Sin documentación rápida.*

#### Función: `HtmlfilasPlus(Datos, DatosColumnas, FormatoColumnas)`
*Sin documentación rápida.*

#### Función: `Formatos(FormatoColumnas, countCol, columna)`
*Sin documentación rápida.*

#### Función: `CrearTablaReport(Datos, NombreColumnas, DatosColumnas, ClassColumnas, FormatoColumnas, TotalizarColumnas, CondicionTotalizar, SubColumnasDatos, SubFilas, FilasPlus, MarcarRows, conteo, Cabezera)`
*Sin documentación rápida.*

#### Función: `CrearTablaReportHtmlCustom(cabeceras, filas)`
*Sin documentación rápida.*

### Módulo `Tools.py`

#### Función: `OptenerRutaApp()`
*Sin documentación rápida.*

#### Función: `AgregarActualizarCampo(coleccion, nombrecampo, defaultval, conexion)`
*Sin documentación rápida.*

#### Función: `AgregarActualizarCampoEnArray(coleccion, nombrecampo, valor, campoArray, conexion)`
*Sin documentación rápida.*

#### Función: `RegistrarAreas(nombre, archivo, visiblepara, conexion)`
*Sin documentación rápida.*

#### Función: `EliminarArea(nombre, conexion)`
*Sin documentación rápida.*

#### Función: `CambiarNombreCampo(coleccion, nombrecampo, newnombre, esArray, campoArray, conexion)`
*Sin documentación rápida.*

#### Función: `CambiarNombreColeccion(coleccion, newnombre, conexion)`
*Sin documentación rápida.*

#### Función: `EliminarIndexColeccion(coleccion, nombreIndex, conexion)`
*Sin documentación rápida.*

#### Función: `EliminarColeccion(coleccion, conexion)`
*Sin documentación rápida.*

#### Función: `CrearIndexColeccion(coleccion, nombreCampo, nombreIndex, unico, conexion)`
*Sin documentación rápida.*

#### Función: `FormatearValor(valor)`
*Sin documentación rápida.*

#### Función: `ProcesarDetalle(detalle, completar, calcular)`
*Sin documentación rápida.*

#### Función: `FormatearDatos(args, ComposNoFormatear)`
*Sin documentación rápida.*

#### Función: `OptenerFechaArchivo(rutaArchivo)`
*Sin documentación rápida.*

#### Función: `convert_size(size_bytes)`
*Sin documentación rápida.*

#### Función: `DateToNombre(dato)`
*PARA CONVERTIR DE STRING A FECHA FORMATO DEVUELTO(dia/mes/año)*

#### Función: `ObtenerNombreMesPorNumero(mes)`
*Sin documentación rápida.*

#### Función: `StrToDate(dato, AddDias, AddHoras, AddMinutos, AddSegundo)`
*PARA CONVERTIR DE STRING A FECHA FORMATO DEVUELTO(dia/mes/año)*

#### Función: `StrDateDomToAmerican(dato, hora, FechaDivisor)`
*PARA CONVERTIR STRING DE FECHA CON FORMATO (dia/mes/año) A (año-mes-dia)*

#### Función: `StrToDateAmerican(dato, AddDias, AddHoras, AddMinutos, AddSegundo)`
*PARA CONVERTIR DE STRING A FECHA FORMATO DEVUELTO(año-mes-dia)*

#### Función: `StrToDateTime(dato, AddDias, AddHoras, AddMinutos, AddSegundo)`
*Sin documentación rápida.*

#### Función: `StrToDateTimeAmerican(dato, AddDias, AddHoras, AddMinutos, AddSegundo)`
*Sin documentación rápida.*

#### Función: `DateFormat(dato, AddDias, AddHoras, AddMinutos, AddSegundo)`
*Sin documentación rápida.*

#### Función: `DateFormatAmerican(dato, AddDias, AddHoras, AddMinutos, AddSegundo)`
*Sin documentación rápida.*

#### Función: `DateTimeFormat(dato, AddDias, AddHoras, AddMinutos, AddSegundo, incluirSegundos)`
*Sin documentación rápida.*

#### Función: `DateTimeFormatAmerican(dato, AddDias, AddHoras, AddMinutos, AddSegundo)`
*Sin documentación rápida.*

#### Función: `DateTimeAdd_D_H_M_S(dato, AddDias, AddHoras, AddMinutos, AddSegundo)`
*Sin documentación rápida.*

#### Función: `OptenerHora(dato, incluirSegundos, Formato24h)`
*Sin documentación rápida.*

#### Función: `OptenerFecha(dato, incluirSegundos, Formato24h)`
*Sin documentación rápida.*

#### Función: `FormatoMoneda(dato)`
*Sin documentación rápida.*

#### Función: `StrToInt(dato)`
*Sin documentación rápida.*

#### Función: `StrToByte(dato)`
*Sin documentación rápida.*

#### Función: `TiempoEspera(tiempo, IsGevent)`
*## Permite esperar un tiempo (float o int) y verifica periódicamente si existe el archivo .kill para salir inmediatamente.*

#### Función: `IterarDatos(dato)`
*Sin documentación rápida.*

#### Función: `IterarDatosToList(dato, campoValid, DatoValid, Simbolo)`
*Sin documentación rápida.*

#### Función: `OptenerDatos(request, remplazar)`
*Sin documentación rápida.*

#### Función: `escapar_regex(expresion)`
*Valida si una cadena tiene caracteres especiales de regex y los escapa.*

#### Función: `FormarOptionDdl(valor, nombre)`
*Sin documentación rápida.*

#### Función: `NoActualizar()`
*Sin documentación rápida.*

#### Función: `EjecutarComando(comando, clavesudo, opciones)`
*Sin documentación rápida.*

#### Función: `_coleccion_a_texto(nombre)`
*Convierte el nombre técnico de una colección MongoDB a texto legible en español.*

#### Función: `MensajeErrorMongo(e)`
*Parsea cualquier excepción de MongoDB E11000 (duplicate key) y genera*

#### Función: `Mensaje(iddatos, estatus, mensaje, JsonUpdate, tipomensaje, AutoCerrarAlerta)`
*PARA MOSTRAR UN MENSAJE DE MODIFICACION ES OBLIGATORIO EL ID DEL DOCUMENTO.*

#### Función: `MensajeV2(iddatos, estatus, mensaje, tipomensaje, AutoCerrarAlerta, e)`
*Sin documentación rápida.*

#### Función: `MensajeGeneral(estatus, mensaje)`
*PARA MOSTRAR UN MENSAJE DE MODIFICACION ES OBLIGATORIO EL ID DEL DOCUMENTO.*

#### Función: `GetHostName(request)`
*Sin documentación rápida.*

#### Función: `StrToFloat(dato)`
*Sin documentación rápida.*

#### Función: `Base64ToImagen(base64Str)`
*Sin documentación rápida.*

#### Función: `CopiarArchivo(RutaOrigen, RutaDestino, borrar)`
*Sin documentación rápida.*

#### Función: `ReadFile(nombre, encoding)`
*Sin documentación rápida.*

#### Función: `ReadFileToList(nombre)`
*Sin documentación rápida.*

#### Función: `WriteFile(nombre, datos)`
*Sin documentación rápida.*

#### Función: `CreateFile(nombre, datos, reemplace)`
*Sin documentación rápida.*

#### Función: `DeleteFile(nombre)`
*Sin documentación rápida.*

#### Función: `DeleteListFile(nombre, tiempoEspera, IsGevent)`
*Sin documentación rápida.*

#### Función: `ExistFile(nombre)`
*Sin documentación rápida.*

#### Función: `ExisteDirectorio(Ruta)`
*Sin documentación rápida.*

#### Función: `CrearDirectorio(Ruta)`
*VALIDA SI NO EXITE EL DIRECTORIO PARA CREARLO.*

#### Función: `BorrarDirectorio(Ruta)`
*Sin documentación rápida.*

#### Función: `BorrarDirectorioVacio(Ruta)`
*Sin documentación rápida.*

#### Función: `FechaHora(AddDias, AddHoras, AddMinutos, AddSegundo)`
*Sin documentación rápida.*

#### Función: `Fecha(AddDias, AddHoras, AddMinutos, AddSegundo)`
*Sin documentación rápida.*

#### Función: `Hora(AddMinutos, AddSegundo)`
*Sin documentación rápida.*

#### Función: `Encriptar(datos, clave)`
*Sin documentación rápida.*

#### Función: `DesEncriptar(datos, clave)`
*Sin documentación rápida.*

#### Función: `BorrarArchivo(nombre, tiempoEspera, IsGevent)`
*Sin documentación rápida.*

#### Función: `BorrarArchivoHoraCreado(nombre, NumeroHoras, IsGevent)`
*ESTE METODO SOLO SE DEBE USAR CON UN HILO*

#### Función: `IterarDatosSQliteToList(dato)`
*Sin documentación rápida.*

#### Función: `Progressbar(data, ncols, color)`
*Sin documentación rápida.*

#### Función: `OptenerDatoApi(url, ruta, parametro, TiempoEspera, metodo, headers)`
*Sin documentación rápida.*

#### Función: `DesComprimir(RutaZip, RutaDescomprimir, eliminar)`
*Sin documentación rápida.*

#### Función: `EscribirLog(texto, tipo)`
*Sin documentación rápida.*

#### Función: `CalDias(fechaInicial, FechaActual, tiempoGratis)`
*Sin documentación rápida.*

#### Función: `ProcesoEsActivo(pid)`
*Verifica si un proceso está activo y no es zombie.*

### Módulo `conexion.py`

#### Función: `Get(Coleccion, agregarzona)`
*Sin documentación rápida.*

#### Función: `GetDB(agregarzona)`
*Sin documentación rápida.*

#### Función: `poner_historial(idcoleccion, accion, datos, coleccion, idusuario, mongoDbSession)`
*Sin documentación rápida.*

#### Función: `ProcesarDatos(Coleccion, args, idcolecion, session, ColecionString, ReturnId, PonerHistorial)`
*Sin documentación rápida.*

#### Función: `ProcesarDatosPRG(Coleccion, args, idcolecion, session, PonerHistorial)`
*Sin documentación rápida.*

#### Función: `GetTestConexionMongo()`
*Sin documentación rápida.*

#### Función: `CallProced(NameProc, prm, dicionario)`
*Sin documentación rápida.*

#### Función: `TypeConnection()`
*Sin documentación rápida.*

#### Función: `GetSQLite()`
*Sin documentación rápida.*

#### Función: `ExecuteSQLite(query, args)`
*Sin documentación rápida.*

#### Función: `create_database()`
*Sin documentación rápida.*

### Módulo `socket_manager.py`

#### Función: `init()`
*Sin documentación rápida.*

#### Función: `get_socketio()`
*Sin documentación rápida.*

#### Función: `init_socketio(app, isProduccion, Proyecto, async_mode)`
*Inicializa el socketio.*
