# [13.5.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.4.0...v13.5.0) (2026-03-09)


### Features

* add ClickHouse password auth support ([#201](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/201)) ([8a70953](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8a70953ddff20f8b2e52bef5493f3d283debbd42))
* add OPENDEVIATIONBAR_TELEGRAM_LOG_LEVEL env var ([#243](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/243)) ([9595fa4](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9595fa433b6c7663a284fca3bea2f48c98e7aa22))
* **monit:** detailed Telegram health reports with UUID and LOUD failure alerts ([87e20e0](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/87e20e0e9e16de4b127a3675c88deede6bfd4509))

# [13.4.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.3.0...v13.4.0) (2026-03-09)


### Bug Fixes

* **clickhouse:** crash-safe replace with overlapping DELETE predicate ([9b343b4](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9b343b493c808623953eb46fb6f4340e98194c20))
* **kintsugi:** cap day-recompute to one day per pass in day-mode Ouroboros ([be30451](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/be304519217e81e39e61c9a4cf86826f6b0c639f))
* **vision:** cache ALL failures in Redis negative cache, not just 404s ([51d2d84](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/51d2d847c4db37a938103d9b6e8f9e1e7b6d2a67))


### Features

* **heartbeat:** deterministic hotfix detection via mtime comparison ([31984ae](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/31984aedb606e41eb0c6d40291541449ce17bce9))
* **kintsugi:** Vision-first data source priority for day-recompute ([d4eaae0](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/d4eaae01e42788030ae7cb27e09bf0767872e973))

# [13.3.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.2.0...v13.3.0) (2026-03-09)


### Features

* **issue-256:** add write-time registry gate to ClickHouse layer ([969af12](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/969af12f4c367981eecbd140f834e12faa6d4445))
* **monitoring:** add delta tracking to heartbeat for repair progress visibility ([3457e89](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/3457e89ebc33f98efb98f125fc8fea7a202a85c0))
