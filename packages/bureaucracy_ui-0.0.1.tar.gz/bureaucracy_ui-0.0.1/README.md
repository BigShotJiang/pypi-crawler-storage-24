# Bureaucracy

**The backend decides. The frontend renders. No questions asked.**

🚧 Under active development. First usable release coming soon.

- Website: [bureaucracy.cc](https://bureaucracy.cc)
- Docs: [lib.bureaucracy.cc](https://lib.bureaucracy.cc)
