"""Bureaucracy — backend-driven UI protocol for data interfaces."""
__version__ = "0.0.1"
