# Herd Python Client

This is the official Python client for the Herd daemon. It provides both synchronous and asynchronous interfaces for acquiring and managing worker sessions.

## Installation

```bash
pip install herd-client
```

## Quick Start (Async)

```python
import asyncio
import httpx
from herd import AsyncClient

async def main():
    client = AsyncClient("unix:///tmp/herd.sock")
    
    async with client.acquire(worker_type="python-inference") as session:
        print(f"Acquired worker: {session.id}")
        
        async with httpx.AsyncClient() as http:
            resp = await http.post(
                f"{session.proxy_url}/generate",
                headers={"X-Session-ID": session.id},
                json={"prompt": "Hello world"}
            )
            print(resp.json())

if __name__ == "__main__":
    asyncio.run(main())
```

## Quick Start (Sync)

```python
import requests
from herd import Client

client = Client("unix:///tmp/herd.sock")

with client.acquire(worker_type="python-inference") as session:
    print(f"Acquired worker: {session.id}")
    
    resp = requests.post(
        f"{session.proxy_url}/generate",
        headers={"X-Session-ID": session.id},
        json={"prompt": "Hello world"}
    )
    print(resp.json())
```
