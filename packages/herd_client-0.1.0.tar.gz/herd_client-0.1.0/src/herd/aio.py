import grpc
import asyncio
from contextlib import asynccontextmanager

# Import generated stubs
from .proto import herd_pb2
from .proto import herd_pb2_grpc

class AsyncClient:
    def __init__(self, address="unix:///tmp/herd.sock"):
        self.address = address
        
    @asynccontextmanager
    async def acquire(self, worker_type="", timeout=30):
        """
        Async context manager to acquire a worker session.
        Background asyncio task maintains the heartbeat.
        """
        session = AsyncSession(self.address, worker_type, timeout)
        try:
            await session.connect()
            yield session
        finally:
            await session.close()

class AsyncSession:
    def __init__(self, address, worker_type, timeout):
        self.address = address
        self.worker_type = worker_type
        self.timeout = timeout
        
        self.channel = None
        self.stub = None
        self.id = None
        self.proxy_url = None
        
        # Async stream control
        self._request_queue = asyncio.Queue()
        self._heartbeat_task = None
        self._call = None
    
    async def _request_generator(self):
        """Yields requests from the async queue."""
        while True:
            req = await self._request_queue.get()
            if req is None: # Sentinel
                break
            yield req

    async def _heartbeat_loop(self):
        """Async task that sends PING every 5s."""
        try:
            while True:
                await asyncio.sleep(5)
                ping = herd_pb2.AcquireRequest(
                    type=herd_pb2.REQUEST_TYPE_PING,
                    session_id=self.id
                )
                await self._request_queue.put(ping)
        except asyncio.CancelledError:
            pass

    async def connect(self):
        """Establishes gRPC connection and handshake."""
        # Use simple insecure channel - grpc.aio handles the loop execution
        self.channel = grpc.aio.insecure_channel(self.address)
        self.stub = herd_pb2_grpc.HerdServiceStub(self.channel)
        
        # 1. Start the stream
        # In grpc.aio, we simply call the method. It returns a StreamStreamCall.
        # But we need to pass an iterator.
        self._call = self.stub.Acquire(self._request_generator())
        
        # 2. Send ACQUIRE
        req = herd_pb2.AcquireRequest(
            type=herd_pb2.REQUEST_TYPE_ACQUIRE,
            worker_type=self.worker_type,
            timeout_seconds=self.timeout
        )
        await self._request_queue.put(req)
        
        # 3. Wait for handshake response
        try:
            # The call object is an async iterator of responses
            resp = await self._call.read()
            if not resp.session_id:
                raise RuntimeError("Failed to acquire session: No ID returned")
            
            self.id = resp.session_id
            self.proxy_url = resp.proxy_address
            if not self.proxy_url.startswith("http"):
                self.proxy_url = "http://" + self.proxy_url
                
        except grpc.aio.AioRpcError as e:
            await self.channel.close()
            raise RuntimeError(f"Herd daemon error: {e.details()}") from e
            
        # 4. Start heartbeat
        self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())

    async def close(self):
        """Clean teardown."""
        # Cancel heartbeat
        if self._heartbeat_task:
            self._heartbeat_task.cancel()
            try:
                await self._heartbeat_task
            except asyncio.CancelledError:
                pass
        
        # Send EOF to stream
        await self._request_queue.put(None)
        
        # Wait for stream to finish closing if needed, or just close channel
        if self.channel:
            await self.channel.close()
