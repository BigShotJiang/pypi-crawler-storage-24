# This file will be automatically overwritten by protoc.
# It is just a placeholder to ensure the module exists.
