import grpc
import time
import threading
import queue
from contextlib import contextmanager

# Import generated stubs
from .proto import herd_pb2
from .proto import herd_pb2_grpc

class Client:
    def __init__(self, address="unix:///tmp/herd.sock"):
        self.address = address
        
    @contextmanager
    def acquire(self, worker_type="", timeout=30):
        """
        Synchronous context manager to acquire a worker session.
        Background thread maintains the heartbeat.
        """
        session = Session(self.address, worker_type, timeout)
        try:
            session.connect()
            yield session
        finally:
            session.close()

class Session:
    def __init__(self, address, worker_type, timeout):
        self.address = address
        self.worker_type = worker_type
        self.timeout = timeout
        
        self.channel = None
        self.stub = None
        self.id = None
        self.proxy_url = None
        
        # Stream control
        self._request_queue = queue.Queue()
        self._response_iterator = None
        self._stop_event = threading.Event()
        self._heartbeat_thread = None

    def _request_generator(self):
        """Yields requests from the queue to the gRPC stream."""
        while not self._stop_event.is_set():
            try:
                # Timeout allows us to check stop_event periodically
                req = self._request_queue.get(timeout=1.0)
                if req is None: # Sentinel
                    break
                yield req
            except queue.Empty:
                continue

    def _heartbeat_loop(self):
        """Background thread that sends PING every 5s."""
        while not self._stop_event.is_set():
            time.sleep(5)
            if self._stop_event.is_set():
                break
            
            try:
                ping = herd_pb2.AcquireRequest(
                    type=herd_pb2.REQUEST_TYPE_PING,
                    session_id=self.id
                )
                self._request_queue.put(ping)
            except Exception:
                # If we can't enqueue, the session is likely dead
                break

    def connect(self):
        """Establishes gRPC connection and handshake."""
        self.channel = grpc.insecure_channel(self.address)
        self.stub = herd_pb2_grpc.HerdServiceStub(self.channel)
        
        # 1. Start the stream
        self._response_iterator = self.stub.Acquire(self._request_generator())
        
        # 2. Send ACQUIRE
        req = herd_pb2.AcquireRequest(
            type=herd_pb2.REQUEST_TYPE_ACQUIRE,
            worker_type=self.worker_type,
            timeout_seconds=self.timeout
        )
        self._request_queue.put(req)
        
        # 3. Wait for handshake response
        # We assume the first message is the handshake
        try:
            resp = next(self._response_iterator)
            if not resp.session_id:
                raise RuntimeError("Failed to acquire session: No ID returned")
            
            self.id = resp.session_id
            self.proxy_url = resp.proxy_address
            if not self.proxy_url.startswith("http"):
                self.proxy_url = "http://" + self.proxy_url
                
        except grpc.RpcError as e:
            raise RuntimeError(f"Herd daemon error: {e.details()}") from e
            
        # 4. Start heartbeat
        self._heartbeat_thread = threading.Thread(target=self._heartbeat_loop, daemon=True)
        self._heartbeat_thread.start()

    def close(self):
        """Clean teardown."""
        self._stop_event.set()
        
        # Send EOF to stream generator
        self._request_queue.put(None)
        
        if self._heartbeat_thread:
            self._heartbeat_thread.join(timeout=2.0)
            
        if self.channel:
            self.channel.close()
