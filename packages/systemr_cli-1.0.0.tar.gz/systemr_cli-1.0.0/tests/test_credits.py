"""Tests for neo.credits — session credit tracking with Decimal."""

import time
from decimal import Decimal

from neo.credits import SessionCredits, LOW_BALANCE_THRESHOLD


class TestSessionCredits:
    """Verify credit accumulation uses Decimal throughout."""

    def test_initial_state(self) -> None:
        sc = SessionCredits()
        assert sc.total_credits == Decimal("0")
        assert sc.tools_called == 0
        assert sc.trades_placed == 0
        assert sc.messages_sent == 0
        assert sc.last_balance is None
        assert not sc.is_low_balance

    def test_add_response_decimal(self) -> None:
        """Credits must accumulate as Decimal."""
        sc = SessionCredits()
        sc.add_response(credits_used=Decimal("2.5"), balance=Decimal("100"), tools=3)
        assert sc.total_credits == Decimal("2.5")
        assert isinstance(sc.total_credits, Decimal)
        assert sc.last_balance == Decimal("100")
        assert isinstance(sc.last_balance, Decimal)
        assert sc.tools_called == 3
        assert sc.messages_sent == 1

    def test_add_response_float_converts(self) -> None:
        """Float inputs should be converted to Decimal."""
        sc = SessionCredits()
        sc.add_response(credits_used=2.5, balance=100.0)
        assert isinstance(sc.total_credits, Decimal)
        assert isinstance(sc.last_balance, Decimal)

    def test_accumulates_without_drift(self) -> None:
        """Decimal accumulation should not have float drift."""
        sc = SessionCredits()
        # 0.1 + 0.1 + 0.1 in float = 0.30000000000000004
        # In Decimal it should be exactly 0.3
        for _ in range(3):
            sc.add_response(credits_used=Decimal("0.1"))
        assert sc.total_credits == Decimal("0.3")

    def test_accumulates_with_trades(self) -> None:
        sc = SessionCredits()
        sc.add_response(credits_used=Decimal("1"), tools=2)
        sc.add_response(credits_used=Decimal("3"), tools=5, trade=True)
        sc.add_response(credits_used=Decimal("0.5"), tools=1)
        assert sc.total_credits == Decimal("4.5")
        assert sc.tools_called == 8
        assert sc.trades_placed == 1
        assert sc.messages_sent == 3

    def test_low_balance(self) -> None:
        sc = SessionCredits()
        sc.add_response(balance=Decimal("100"))
        assert not sc.is_low_balance

        sc.add_response(balance=Decimal("30"))
        assert sc.is_low_balance

    def test_low_balance_threshold_is_decimal(self) -> None:
        assert isinstance(LOW_BALANCE_THRESHOLD, Decimal)
        assert LOW_BALANCE_THRESHOLD == Decimal("50")

    def test_summary(self) -> None:
        sc = SessionCredits()
        sc.add_response(
            credits_used=Decimal("5"), balance=Decimal("95"), tools=10, trade=True,
        )
        s = sc.summary()
        assert s["credits_used"] == 5.0
        assert s["tools_called"] == 10
        assert s["trades_placed"] == 1
        assert s["balance"] == 95.0

    def test_duration(self) -> None:
        sc = SessionCredits()
        sc.start_time = time.time() - 120  # 2 minutes ago
        assert sc.duration_minutes == 2

    def test_none_credits_dont_accumulate(self) -> None:
        sc = SessionCredits()
        sc.add_response(credits_used=None, balance=None)
        assert sc.total_credits == Decimal("0")
        assert sc.last_balance is None
        assert sc.messages_sent == 1  # message count still increments
