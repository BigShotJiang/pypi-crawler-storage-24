"""Tests for neo.display.chat_renderer — all rendering through Rich."""

from decimal import Decimal
from io import StringIO

from rich.console import Console

import neo.display.chat_renderer as renderer_mod


def _capture_console() -> Console:
    """Create a console that captures output for testing."""
    return Console(file=StringIO(), force_terminal=True)


class TestRenderers:
    """Verify all renderers produce output without error."""

    def test_render_user_message(self, monkeypatch: object) -> None:
        c = _capture_console()
        monkeypatch.setattr(renderer_mod, "console", c)  # type: ignore[attr-defined]
        renderer_mod.render_user_message("buy TSLA 2% risk")
        output = c.file.getvalue()  # type: ignore[union-attr]
        assert "you >" in output
        assert "buy TSLA" in output

    def test_render_assistant_message(self, monkeypatch: object) -> None:
        c = _capture_console()
        monkeypatch.setattr(renderer_mod, "console", c)  # type: ignore[attr-defined]
        renderer_mod.render_assistant_message("**TSLA** is at $198.50")
        output = c.file.getvalue()  # type: ignore[union-attr]
        assert "SYSTEM R" in output
        assert "TSLA" in output

    def test_render_assistant_empty_skipped(self, monkeypatch: object) -> None:
        c = _capture_console()
        monkeypatch.setattr(renderer_mod, "console", c)  # type: ignore[attr-defined]
        renderer_mod.render_assistant_message("   ")
        output = c.file.getvalue()  # type: ignore[union-attr]
        assert output == ""

    def test_render_thinking(self, monkeypatch: object) -> None:
        c = _capture_console()
        monkeypatch.setattr(renderer_mod, "console", c)  # type: ignore[attr-defined]
        renderer_mod.render_thinking("analyzing risk...")
        output = c.file.getvalue()  # type: ignore[union-attr]
        assert "analyzing risk" in output

    def test_render_action_running(self, monkeypatch: object) -> None:
        c = _capture_console()
        monkeypatch.setattr(renderer_mod, "console", c)  # type: ignore[attr-defined]
        renderer_mod.render_action("get_quote", status="running")
        output = c.file.getvalue()  # type: ignore[union-attr]
        assert "get_quote" in output

    def test_render_action_complete(self, monkeypatch: object) -> None:
        c = _capture_console()
        monkeypatch.setattr(renderer_mod, "console", c)  # type: ignore[attr-defined]
        renderer_mod.render_action("get_quote", status="complete", result="198.50")
        output = c.file.getvalue()  # type: ignore[union-attr]
        assert "get_quote" in output
        assert "198.50" in output

    def test_render_action_error(self, monkeypatch: object) -> None:
        c = _capture_console()
        monkeypatch.setattr(renderer_mod, "console", c)  # type: ignore[attr-defined]
        renderer_mod.render_action("place_order", status="error", result="timeout")
        output = c.file.getvalue()  # type: ignore[union-attr]
        assert "place_order" in output

    def test_render_action_pending(self, monkeypatch: object) -> None:
        c = _capture_console()
        monkeypatch.setattr(renderer_mod, "console", c)  # type: ignore[attr-defined]
        renderer_mod.render_action("place_order", status="pending", result="awaiting")
        output = c.file.getvalue()  # type: ignore[union-attr]
        assert "place_order" in output

    def test_render_error(self, monkeypatch: object) -> None:
        c = _capture_console()
        monkeypatch.setattr(renderer_mod, "console", c)  # type: ignore[attr-defined]
        renderer_mod.render_error("connection lost")
        output = c.file.getvalue()  # type: ignore[union-attr]
        assert "connection lost" in output

    def test_render_credits_with_values(self, monkeypatch: object) -> None:
        c = _capture_console()
        monkeypatch.setattr(renderer_mod, "console", c)  # type: ignore[attr-defined]
        renderer_mod.render_credits(credits_used=Decimal("2.5"), balance=Decimal("97.5"))
        output = c.file.getvalue()  # type: ignore[union-attr]
        assert "2.5" in output
        assert "97.5" in output

    def test_render_credits_low_balance(self, monkeypatch: object) -> None:
        c = _capture_console()
        monkeypatch.setattr(renderer_mod, "console", c)  # type: ignore[attr-defined]
        renderer_mod.render_credits(balance=Decimal("10.0"))
        output = c.file.getvalue()  # type: ignore[union-attr]
        assert "10.0" in output

    def test_render_credits_none(self, monkeypatch: object) -> None:
        c = _capture_console()
        monkeypatch.setattr(renderer_mod, "console", c)  # type: ignore[attr-defined]
        renderer_mod.render_credits()
        output = c.file.getvalue()  # type: ignore[union-attr]
        assert output == ""

    def test_no_sys_import(self) -> None:
        """Verify chat_renderer does not import sys module."""
        import inspect
        source = inspect.getsource(renderer_mod)
        assert "import sys\n" not in source
