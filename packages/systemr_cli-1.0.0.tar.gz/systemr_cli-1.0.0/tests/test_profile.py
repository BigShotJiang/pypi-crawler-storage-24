"""Tests for neo.profile — trader profile, rules, and memory management."""

from datetime import date, timedelta

from neo.profile import (
    append_daily_log,
    load_daily_context,
    load_standing_orders,
    save_profile,
    save_rules,
    save_standing_order,
    search_memory,
    init_memory,
    save_memory,
    load_profile,
    load_rules,
    load_memory_index,
    profile_exists,
    init_all,
    auto_save_trade_lesson,
    auto_save_rule_violation,
    auto_save_explicit,
)


class TestProfile:
    """Profile read/write operations."""

    def test_save_and_load(self, tmp_path: object, monkeypatch: object) -> None:
        monkeypatch.setattr("neo.profile.PROFILE_FILE", tmp_path / "PROFILE.md")  # type: ignore[arg-type]
        monkeypatch.setattr("neo.profile.ensure_systemr_home", lambda: None)

        save_profile(
            name="Ashim",
            style="Momentum swing",
            timeframe="2-5 days",
            experience="Advanced",
            risk_pct="2",
            daily_loss_pct="5",
            max_positions=5,
            broker="Alpaca",
        )

        content = load_profile()
        assert "Ashim" in content
        assert "Momentum swing" in content
        assert "2%" in content
        assert "Alpaca" in content

    def test_profile_exists_false(self, tmp_path: object, monkeypatch: object) -> None:
        monkeypatch.setattr("neo.profile.PROFILE_FILE", tmp_path / "PROFILE.md")  # type: ignore[arg-type]
        assert not profile_exists()

    def test_profile_exists_true(self, tmp_path: object, monkeypatch: object) -> None:
        f = tmp_path / "PROFILE.md"  # type: ignore[operator]
        f.write_text("test")
        monkeypatch.setattr("neo.profile.PROFILE_FILE", f)
        assert profile_exists()

    def test_load_profile_empty(self, tmp_path: object, monkeypatch: object) -> None:
        monkeypatch.setattr("neo.profile.PROFILE_FILE", tmp_path / "nonexistent.md")  # type: ignore[arg-type]
        assert load_profile() == ""

    def test_risk_values_are_strings(self, tmp_path: object, monkeypatch: object) -> None:
        """Risk values stored as strings to avoid float contamination."""
        monkeypatch.setattr("neo.profile.PROFILE_FILE", tmp_path / "PROFILE.md")  # type: ignore[arg-type]
        monkeypatch.setattr("neo.profile.ensure_systemr_home", lambda: None)

        save_profile(
            name="Test", style="test", timeframe="1d",
            experience="beginner", risk_pct="2.5",
            daily_loss_pct="5.0", max_positions=3, broker="Alpaca",
        )
        content = load_profile()
        # Stored as "2.5%" not "2.500000000000000111..." (float repr)
        assert "2.5%" in content
        assert "5.0%" in content


class TestRules:
    """Rules read/write operations."""

    def test_save_and_load(self, tmp_path: object, monkeypatch: object) -> None:
        monkeypatch.setattr("neo.profile.RULES_FILE", tmp_path / "RULES.md")  # type: ignore[arg-type]
        monkeypatch.setattr("neo.profile.ensure_systemr_home", lambda: None)

        save_rules(
            hard_rules=["Max 2% risk per trade", "Always set stop loss"],
            soft_rules=["Prefer R:R above 1:2"],
        )

        content = load_rules()
        assert "Max 2% risk per trade" in content
        assert "Always set stop loss" in content
        assert "Prefer R:R above 1:2" in content

    def test_empty_rules(self, tmp_path: object, monkeypatch: object) -> None:
        monkeypatch.setattr("neo.profile.RULES_FILE", tmp_path / "RULES.md")  # type: ignore[arg-type]
        monkeypatch.setattr("neo.profile.ensure_systemr_home", lambda: None)

        save_rules(hard_rules=[], soft_rules=[])
        content = load_rules()
        assert "(none set)" in content

    def test_load_rules_empty(self, tmp_path: object, monkeypatch: object) -> None:
        monkeypatch.setattr("neo.profile.RULES_FILE", tmp_path / "nonexistent.md")  # type: ignore[arg-type]
        assert load_rules() == ""


class TestMemory:
    """Memory index and file operations."""

    def test_init_memory(self, tmp_path: object, monkeypatch: object) -> None:
        memory_dir = tmp_path / "memory"  # type: ignore[operator]
        memory_dir.mkdir()
        monkeypatch.setattr("neo.profile.MEMORY_DIR", memory_dir)
        monkeypatch.setattr("neo.profile.MEMORY_INDEX", memory_dir / "MEMORY.md")
        monkeypatch.setattr("neo.profile.ensure_systemr_home", lambda: None)

        init_memory()
        assert (memory_dir / "MEMORY.md").exists()
        assert "Trading Memory" in (memory_dir / "MEMORY.md").read_text()

    def test_save_memory(self, tmp_path: object, monkeypatch: object) -> None:
        memory_dir = tmp_path / "memory"  # type: ignore[operator]
        memory_dir.mkdir()
        index = memory_dir / "MEMORY.md"
        index.write_text("# Trading Memory\n")
        monkeypatch.setattr("neo.profile.MEMORY_DIR", memory_dir)
        monkeypatch.setattr("neo.profile.MEMORY_INDEX", index)
        monkeypatch.setattr("neo.profile.ensure_systemr_home", lambda: None)

        save_memory("tsla_notes.md", "TSLA support at $192", "TSLA patterns")

        assert (memory_dir / "tsla_notes.md").exists()
        assert "TSLA support at $192" in (memory_dir / "tsla_notes.md").read_text()
        assert "tsla_notes.md" in index.read_text()

    def test_save_memory_no_duplicate_index(self, tmp_path: object, monkeypatch: object) -> None:
        memory_dir = tmp_path / "memory"  # type: ignore[operator]
        memory_dir.mkdir()
        index = memory_dir / "MEMORY.md"
        index.write_text("# Trading Memory\n- [TSLA](tsla_notes.md)\n")
        monkeypatch.setattr("neo.profile.MEMORY_DIR", memory_dir)
        monkeypatch.setattr("neo.profile.MEMORY_INDEX", index)
        monkeypatch.setattr("neo.profile.ensure_systemr_home", lambda: None)

        save_memory("tsla_notes.md", "updated", "TSLA patterns")

        # Index should NOT have duplicate entry
        text = index.read_text()
        assert text.count("tsla_notes.md") == 1

    def test_load_memory_index(self, tmp_path: object, monkeypatch: object) -> None:
        memory_dir = tmp_path / "memory"  # type: ignore[operator]
        memory_dir.mkdir()
        index = memory_dir / "MEMORY.md"
        index.write_text("# Memory\n- [Note](note.md)\n")
        monkeypatch.setattr("neo.profile.MEMORY_INDEX", index)

        content = load_memory_index()
        assert "Note" in content

    def test_load_memory_index_missing(self, tmp_path: object, monkeypatch: object) -> None:
        monkeypatch.setattr("neo.profile.MEMORY_INDEX", tmp_path / "nope.md")  # type: ignore[arg-type]
        assert load_memory_index() == ""


class TestAutoSave:
    """Auto-memory triggers."""

    def test_trade_lesson_saves_on_loss(self, tmp_path: object, monkeypatch: object) -> None:
        memory_dir = tmp_path / "memory"  # type: ignore[operator]
        memory_dir.mkdir()
        index = memory_dir / "MEMORY.md"
        index.write_text("# Trading Memory\n")
        monkeypatch.setattr("neo.profile.MEMORY_DIR", memory_dir)
        monkeypatch.setattr("neo.profile.MEMORY_INDEX", index)
        monkeypatch.setattr("neo.profile.ensure_systemr_home", lambda: None)

        result = auto_save_trade_lesson(
            symbol="TSLA", r_multiple="-2.30",
            direction="long", entry="198.50", exit_price="183.55",
        )
        assert result is not None
        assert result.exists()
        content = result.read_text()
        assert "TSLA" in content
        assert "-2.30" in content

    def test_trade_lesson_skips_small_loss(self, tmp_path: object, monkeypatch: object) -> None:
        monkeypatch.setattr("neo.profile.MEMORY_DIR", tmp_path / "memory")  # type: ignore[arg-type]

        result = auto_save_trade_lesson(
            symbol="AAPL", r_multiple="-0.50",
            direction="long", entry="180", exit_price="177",
        )
        assert result is None

    def test_trade_lesson_skips_win(self, tmp_path: object, monkeypatch: object) -> None:
        result = auto_save_trade_lesson(
            symbol="AAPL", r_multiple="1.50",
            direction="long", entry="180", exit_price="190",
        )
        assert result is None

    def test_rule_violation_creates(self, tmp_path: object, monkeypatch: object) -> None:
        memory_dir = tmp_path / "memory"  # type: ignore[operator]
        memory_dir.mkdir()
        index = memory_dir / "MEMORY.md"
        index.write_text("# Trading Memory\n")
        monkeypatch.setattr("neo.profile.MEMORY_DIR", memory_dir)
        monkeypatch.setattr("neo.profile.MEMORY_INDEX", index)
        monkeypatch.setattr("neo.profile.ensure_systemr_home", lambda: None)

        result = auto_save_rule_violation("Max 2% risk", "TSLA 500 shares")
        assert result.exists()
        assert "TSLA 500 shares" in result.read_text()

    def test_rule_violation_appends(self, tmp_path: object, monkeypatch: object) -> None:
        memory_dir = tmp_path / "memory"  # type: ignore[operator]
        memory_dir.mkdir()
        from datetime import date
        filename = f"blocked_{date.today().isoformat()}.md"
        existing = memory_dir / filename
        existing.write_text("# Blocked\n- First violation\n")
        monkeypatch.setattr("neo.profile.MEMORY_DIR", memory_dir)
        monkeypatch.setattr("neo.profile.ensure_systemr_home", lambda: None)

        auto_save_rule_violation("Daily limit", "3rd trade attempt")
        content = existing.read_text()
        assert "First violation" in content
        assert "3rd trade attempt" in content

    def test_explicit_save(self, tmp_path: object, monkeypatch: object) -> None:
        memory_dir = tmp_path / "memory"  # type: ignore[operator]
        memory_dir.mkdir()
        index = memory_dir / "MEMORY.md"
        index.write_text("# Trading Memory\n")
        monkeypatch.setattr("neo.profile.MEMORY_DIR", memory_dir)
        monkeypatch.setattr("neo.profile.MEMORY_INDEX", index)
        monkeypatch.setattr("neo.profile.ensure_systemr_home", lambda: None)

        result = auto_save_explicit("TSLA support at $192")
        assert result.exists()
        assert "TSLA support at $192" in result.read_text()


class TestStandingOrders:
    """Standing orders in RULES.md."""

    def test_save_standing_order(self, tmp_path: object, monkeypatch: object) -> None:
        rules_file = tmp_path / "RULES.md"  # type: ignore[operator]
        rules_file.write_text("# Trading Rules\n\n## Hard Rules\n- Max 2% risk\n")
        monkeypatch.setattr("neo.profile.RULES_FILE", rules_file)
        monkeypatch.setattr("neo.profile.ensure_systemr_home", lambda: None)

        save_standing_order(
            name="Morning Scan",
            scope="Scan watchlist for setups",
            trigger="Daily at 7:00 AM EST",
            approval="Do NOT execute trades — report only",
            escalation="Alert if no setups found for 3 days",
            action="Run morning briefing with watchlist scan",
        )

        content = rules_file.read_text()
        assert "## Standing Orders" in content
        assert "Morning Scan" in content
        assert "Do NOT execute trades" in content

    def test_load_standing_orders(self, tmp_path: object, monkeypatch: object) -> None:
        rules_file = tmp_path / "RULES.md"  # type: ignore[operator]
        rules_file.write_text(
            "# Trading Rules\n\n## Hard Rules\n- Max 2% risk\n\n"
            "## Standing Orders\n### Morning Scan\n- **Scope**: Scan watchlist\n"
        )
        monkeypatch.setattr("neo.profile.RULES_FILE", rules_file)

        orders = load_standing_orders()
        assert "Standing Orders" in orders
        assert "Morning Scan" in orders

    def test_load_standing_orders_empty(self, tmp_path: object, monkeypatch: object) -> None:
        rules_file = tmp_path / "RULES.md"  # type: ignore[operator]
        rules_file.write_text("# Trading Rules\n## Hard Rules\n- Max 2% risk\n")
        monkeypatch.setattr("neo.profile.RULES_FILE", rules_file)

        assert load_standing_orders() == ""

    def test_load_standing_orders_no_rules(self, tmp_path: object, monkeypatch: object) -> None:
        monkeypatch.setattr("neo.profile.RULES_FILE", tmp_path / "nope.md")  # type: ignore[arg-type]
        assert load_standing_orders() == ""


class TestDailyLog:
    """Daily trading log (YYYY-MM-DD.md) operations."""

    def test_append_creates_file(self, tmp_path: object, monkeypatch: object) -> None:
        memory_dir = tmp_path / "memory"  # type: ignore[operator]
        memory_dir.mkdir()
        monkeypatch.setattr("neo.profile.MEMORY_DIR", memory_dir)
        monkeypatch.setattr("neo.profile.ensure_systemr_home", lambda: None)

        result = append_daily_log("Bought TSLA at $198.50", category="trade")
        assert result.exists()
        content = result.read_text()
        assert "Trading Log" in content
        assert "[trade]" in content
        assert "Bought TSLA at $198.50" in content

    def test_append_adds_to_existing(self, tmp_path: object, monkeypatch: object) -> None:
        memory_dir = tmp_path / "memory"  # type: ignore[operator]
        memory_dir.mkdir()
        monkeypatch.setattr("neo.profile.MEMORY_DIR", memory_dir)
        monkeypatch.setattr("neo.profile.ensure_systemr_home", lambda: None)

        append_daily_log("First entry", category="note")
        append_daily_log("Second entry", category="trade")

        today = date.today().isoformat()
        filepath = memory_dir / f"{today}.md"
        content = filepath.read_text()
        assert "First entry" in content
        assert "Second entry" in content
        assert content.count("Trading Log") == 1  # Header only once

    def test_load_daily_context_today_only(self, tmp_path: object, monkeypatch: object) -> None:
        memory_dir = tmp_path / "memory"  # type: ignore[operator]
        memory_dir.mkdir()
        monkeypatch.setattr("neo.profile.MEMORY_DIR", memory_dir)
        monkeypatch.setattr("neo.profile.ensure_systemr_home", lambda: None)

        today = date.today().isoformat()
        (memory_dir / f"{today}.md").write_text("# Trading Log\n- Today's entry\n")

        context = load_daily_context()
        assert "Today's entry" in context

    def test_load_daily_context_yesterday_and_today(self, tmp_path: object, monkeypatch: object) -> None:
        memory_dir = tmp_path / "memory"  # type: ignore[operator]
        memory_dir.mkdir()
        monkeypatch.setattr("neo.profile.MEMORY_DIR", memory_dir)

        today = date.today()
        yesterday = today - timedelta(days=1)
        (memory_dir / f"{yesterday.isoformat()}.md").write_text("# Yesterday\n- Old trade\n")
        (memory_dir / f"{today.isoformat()}.md").write_text("# Today\n- New trade\n")

        context = load_daily_context()
        assert "Old trade" in context
        assert "New trade" in context

    def test_load_daily_context_empty(self, tmp_path: object, monkeypatch: object) -> None:
        memory_dir = tmp_path / "memory"  # type: ignore[operator]
        memory_dir.mkdir()
        monkeypatch.setattr("neo.profile.MEMORY_DIR", memory_dir)

        assert load_daily_context() == ""


class TestMemorySearch:
    """Memory search across files."""

    def test_search_finds_match(self, tmp_path: object, monkeypatch: object) -> None:
        memory_dir = tmp_path / "memory"  # type: ignore[operator]
        memory_dir.mkdir()
        monkeypatch.setattr("neo.profile.MEMORY_DIR", memory_dir)

        (memory_dir / "notes.md").write_text("TSLA support at $192\nAAPL resistance at $200\n")
        results = search_memory("TSLA")
        assert len(results) == 1
        assert results[0]["content"] == "TSLA support at $192"

    def test_search_case_insensitive(self, tmp_path: object, monkeypatch: object) -> None:
        memory_dir = tmp_path / "memory"  # type: ignore[operator]
        memory_dir.mkdir()
        monkeypatch.setattr("neo.profile.MEMORY_DIR", memory_dir)

        (memory_dir / "notes.md").write_text("tsla support at $192\n")
        results = search_memory("TSLA")
        assert len(results) == 1

    def test_search_max_results(self, tmp_path: object, monkeypatch: object) -> None:
        memory_dir = tmp_path / "memory"  # type: ignore[operator]
        memory_dir.mkdir()
        monkeypatch.setattr("neo.profile.MEMORY_DIR", memory_dir)

        lines = "\n".join(f"TSLA line {i}" for i in range(20))
        (memory_dir / "notes.md").write_text(lines)
        results = search_memory("TSLA", max_results=5)
        assert len(results) == 5

    def test_search_no_results(self, tmp_path: object, monkeypatch: object) -> None:
        memory_dir = tmp_path / "memory"  # type: ignore[operator]
        memory_dir.mkdir()
        monkeypatch.setattr("neo.profile.MEMORY_DIR", memory_dir)

        (memory_dir / "notes.md").write_text("AAPL only here\n")
        results = search_memory("NVDA")
        assert len(results) == 0

    def test_search_empty_dir(self, tmp_path: object, monkeypatch: object) -> None:
        memory_dir = tmp_path / "memory"  # type: ignore[operator]
        memory_dir.mkdir()
        monkeypatch.setattr("neo.profile.MEMORY_DIR", memory_dir)
        assert search_memory("anything") == []

    def test_search_nonexistent_dir(self, tmp_path: object, monkeypatch: object) -> None:
        monkeypatch.setattr("neo.profile.MEMORY_DIR", tmp_path / "nope")  # type: ignore[arg-type]
        assert search_memory("anything") == []


class TestInitAll:
    """Full directory initialization."""

    def test_init_all(self, tmp_path: object, monkeypatch: object) -> None:
        home = tmp_path / ".systemr"  # type: ignore[operator]
        memory_dir = home / "memory"
        sessions_dir = home / "sessions"
        monkeypatch.setattr("neo.profile.MEMORY_DIR", memory_dir)
        monkeypatch.setattr("neo.profile.MEMORY_INDEX", memory_dir / "MEMORY.md")
        monkeypatch.setattr("neo.config.SYSTEMR_HOME", home)
        monkeypatch.setattr("neo.config.MEMORY_DIR", memory_dir)
        monkeypatch.setattr("neo.config.SESSIONS_DIR", sessions_dir)

        init_all()
        assert memory_dir.exists()
        assert (memory_dir / "MEMORY.md").exists()
