"""Tests for neo.confirmation — trade confirmation and permission levels."""


from neo.confirmation import (
    PERMISSION_PROFILES,
    PermissionLevel,
    get_active_profile,
    get_permission_level,
    set_active_profile,
    ACTION_PERMISSIONS,
)


class TestPermissionLevels:
    """Verify action-to-permission mapping."""

    def test_read_only_actions_are_auto(self) -> None:
        auto_actions = [
            "get_quote", "get_account_balance", "calculate_position_size",
            "check_trade_risk", "evaluate_performance", "get_pricing",
            "get_positions", "get_portfolio", "get_order_status",
        ]
        for action in auto_actions:
            assert get_permission_level(action) == PermissionLevel.AUTO, (
                f"{action} should be AUTO"
            )

    def test_trade_actions_require_confirm(self) -> None:
        confirm_actions = [
            "place_order", "cancel_order", "modify_order",
            "close_position", "set_stop_loss", "modify_stop",
            "set_take_profit", "connect_broker", "disconnect_broker",
        ]
        for action in confirm_actions:
            assert get_permission_level(action) == PermissionLevel.CONFIRM, (
                f"{action} should be CONFIRM"
            )

    def test_destructive_actions_require_double_confirm(self) -> None:
        double_actions = [
            "kill_switch", "close_all_positions",
            "enable_margin", "withdraw_funds",
        ]
        for action in double_actions:
            assert get_permission_level(action) == PermissionLevel.DOUBLE_CONFIRM, (
                f"{action} should be DOUBLE_CONFIRM"
            )

    def test_unknown_action_defaults_to_confirm(self) -> None:
        """SAFETY: Unknown actions must default to CONFIRM, not AUTO."""
        assert get_permission_level("unknown_action") == PermissionLevel.CONFIRM
        assert get_permission_level("brand_new_tool") == PermissionLevel.CONFIRM
        assert get_permission_level("") == PermissionLevel.CONFIRM

    def test_all_permissions_are_valid_enum(self) -> None:
        for action, level in ACTION_PERMISSIONS.items():
            assert isinstance(level, PermissionLevel), (
                f"{action} has invalid permission type: {type(level)}"
            )

    def test_no_auto_for_money_touching_actions(self) -> None:
        """Execution actions (order, close, withdraw) must never be AUTO."""
        # These keywords indicate actions that move money — never AUTO
        execution_keywords = ["place_order", "cancel_order", "modify_order",
                              "close_position", "close_all", "kill_switch",
                              "withdraw", "enable_margin"]
        for action, level in ACTION_PERMISSIONS.items():
            if any(kw in action for kw in execution_keywords):
                assert level != PermissionLevel.AUTO, (
                    f"SAFETY VIOLATION: {action} is AUTO but executes trades"
                )


class TestPermissionProfiles:
    """Permission profile switching."""

    def test_default_is_standard(self) -> None:
        set_active_profile("standard")  # reset
        assert get_active_profile() == "standard"

    def test_paper_elevates_trades_to_double_confirm(self) -> None:
        set_active_profile("paper")
        assert get_permission_level("place_order") == PermissionLevel.DOUBLE_CONFIRM
        assert get_permission_level("cancel_order") == PermissionLevel.DOUBLE_CONFIRM
        set_active_profile("standard")  # cleanup

    def test_experienced_relaxes_stop_adjustments(self) -> None:
        set_active_profile("experienced")
        assert get_permission_level("set_stop_loss") == PermissionLevel.AUTO
        assert get_permission_level("modify_stop") == PermissionLevel.AUTO
        assert get_permission_level("set_take_profit") == PermissionLevel.AUTO
        set_active_profile("standard")  # cleanup

    def test_experienced_still_confirms_orders(self) -> None:
        set_active_profile("experienced")
        # Orders should still need confirmation even in experienced mode
        assert get_permission_level("place_order") == PermissionLevel.CONFIRM
        set_active_profile("standard")  # cleanup

    def test_unknown_profile_rejected(self) -> None:
        assert set_active_profile("yolo") is False
        # Profile should not have changed
        assert get_active_profile() != "yolo"

    def test_all_profiles_exist(self) -> None:
        for name in ("paper", "standard", "experienced"):
            assert name in PERMISSION_PROFILES

    def test_profile_overrides_dont_weaken_destructive(self) -> None:
        """No profile should make kill_switch anything less than DOUBLE_CONFIRM."""
        for profile_name, overrides in PERMISSION_PROFILES.items():
            level = overrides.get("kill_switch", ACTION_PERMISSIONS.get("kill_switch"))
            assert level == PermissionLevel.DOUBLE_CONFIRM or level is None, (
                f"Profile {profile_name} weakens kill_switch to {level}"
            )


class TestConfirmTradeSignature:
    """Verify confirm_trade accepts Decimal types (not float)."""

    def test_accepts_decimal_params(self) -> None:
        """confirm_trade should accept Decimal for all financial fields."""
        import inspect
        from neo.confirmation import confirm_trade
        sig = inspect.signature(confirm_trade)

        # These params should accept Price/RiskAmount/Percentage (all Decimal)
        decimal_params = ["entry", "stop", "risk_amount", "risk_pct"]
        for param_name in decimal_params:
            # Verify the param exists in the signature
            assert param_name in sig.parameters, f"Missing param: {param_name}"

    def test_shares_is_quantity(self) -> None:
        """shares parameter should be typed as Quantity (int)."""
        import inspect
        from neo.confirmation import confirm_trade
        sig = inspect.signature(confirm_trade)
        assert "shares" in sig.parameters
