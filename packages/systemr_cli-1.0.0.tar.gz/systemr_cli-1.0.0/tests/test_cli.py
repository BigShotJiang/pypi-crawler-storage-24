"""Tests for CLI entry point."""

from click.testing import CliRunner

from neo.cli import cli


def test_version():
    runner = CliRunner()
    result = runner.invoke(cli, ["--version"])
    assert result.exit_code == 0
    assert "systemr" in result.output
    assert "1.0.0" in result.output


def test_help():
    runner = CliRunner()
    result = runner.invoke(cli, ["--help"])
    assert result.exit_code == 0
    assert "System R" in result.output


def test_journal_help():
    runner = CliRunner()
    result = runner.invoke(cli, ["journal", "--help"])
    assert result.exit_code == 0
    assert "journal" in result.output.lower()


def test_journal_add_and_list(tmp_path, monkeypatch):
    monkeypatch.setattr("neo.store.DB_FILE", tmp_path / "test.db")
    monkeypatch.setattr("neo.store.ensure_neo_home", lambda: None)

    runner = CliRunner()
    result = runner.invoke(cli, [
        "journal", "add",
        "--symbol", "AAPL",
        "--entry", "182.50",
        "--stop", "178",
        "--direction", "long",
        "--qty", "100",
    ])
    assert result.exit_code == 0
    assert "AAPL" in result.output

    result = runner.invoke(cli, ["journal", "list"])
    assert result.exit_code == 0
    assert "AAPL" in result.output
