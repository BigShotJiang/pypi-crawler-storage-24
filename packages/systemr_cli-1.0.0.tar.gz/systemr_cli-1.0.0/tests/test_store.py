"""Tests for neo.store (SQLite journal)."""

from neo.store import LocalStore


def test_add_and_list_trade(tmp_path, monkeypatch):
    monkeypatch.setattr("neo.store.DB_FILE", tmp_path / "test.db")
    monkeypatch.setattr("neo.store.ensure_neo_home", lambda: None)

    store = LocalStore()
    tid = store.add_trade("AAPL", "long", 182.50, 178.0, 100, notes="Test trade")
    assert tid == 1

    trades = store.list_trades()
    assert len(trades) == 1
    assert trades[0]["symbol"] == "AAPL"
    assert trades[0]["direction"] == "long"
    assert trades[0]["entry_price"] == 182.50


def test_get_trade(tmp_path, monkeypatch):
    monkeypatch.setattr("neo.store.DB_FILE", tmp_path / "test.db")
    monkeypatch.setattr("neo.store.ensure_neo_home", lambda: None)

    store = LocalStore()
    tid = store.add_trade("TSLA", "short", 250.0, 260.0, 50)
    t = store.get_trade(tid)
    assert t is not None
    assert t["symbol"] == "TSLA"
    assert t["direction"] == "short"


def test_update_trade(tmp_path, monkeypatch):
    monkeypatch.setattr("neo.store.DB_FILE", tmp_path / "test.db")
    monkeypatch.setattr("neo.store.ensure_neo_home", lambda: None)

    store = LocalStore()
    tid = store.add_trade("MSFT", "long", 400.0, 395.0, 25)
    store.update_trade(tid, exit_price=410.0, r_multiple=2.0)

    t = store.get_trade(tid)
    assert t["exit_price"] == 410.0
    assert t["r_multiple"] == 2.0


def test_delete_trade(tmp_path, monkeypatch):
    monkeypatch.setattr("neo.store.DB_FILE", tmp_path / "test.db")
    monkeypatch.setattr("neo.store.ensure_neo_home", lambda: None)

    store = LocalStore()
    tid = store.add_trade("NVDA", "long", 800.0, 780.0, 10)
    assert store.delete_trade(tid)
    assert store.get_trade(tid) is None


def test_export_trades(tmp_path, monkeypatch):
    monkeypatch.setattr("neo.store.DB_FILE", tmp_path / "test.db")
    monkeypatch.setattr("neo.store.ensure_neo_home", lambda: None)

    store = LocalStore()
    store.add_trade("AAPL", "long", 180.0, 175.0, 100)
    store.add_trade("GOOG", "short", 150.0, 155.0, 50)

    exports = store.export_trades()
    assert len(exports) == 2


def test_chat_session(tmp_path, monkeypatch):
    monkeypatch.setattr("neo.store.DB_FILE", tmp_path / "test.db")
    monkeypatch.setattr("neo.store.ensure_neo_home", lambda: None)

    store = LocalStore()
    sid = store.create_chat_session("Test session")
    store.add_chat_message(sid, "user", "Hello NEO")
    store.add_chat_message(sid, "assistant", "Hello! How can I help?")

    history = store.get_chat_history(sid)
    assert len(history) == 2
    assert history[0]["role"] == "user"
    assert history[1]["role"] == "assistant"


def test_list_sessions(tmp_path, monkeypatch):
    monkeypatch.setattr("neo.store.DB_FILE", tmp_path / "test.db")
    monkeypatch.setattr("neo.store.ensure_neo_home", lambda: None)

    store = LocalStore()
    sid1 = store.create_chat_session("Session 1")
    store.add_chat_message(sid1, "user", "hello")
    store.add_chat_message(sid1, "assistant", "hi")
    sid2 = store.create_chat_session("Session 2")
    store.add_chat_message(sid2, "user", "test")

    sessions = store.list_sessions()
    assert len(sessions) == 2
    # Most recent first
    assert sessions[0]["id"] == sid2
    assert sessions[0]["message_count"] == 1
    assert sessions[1]["id"] == sid1
    assert sessions[1]["message_count"] == 2


def test_export_session(tmp_path, monkeypatch):
    monkeypatch.setattr("neo.store.DB_FILE", tmp_path / "test.db")
    monkeypatch.setattr("neo.store.ensure_neo_home", lambda: None)

    store = LocalStore()
    sid = store.create_chat_session("Export test")
    store.add_chat_message(sid, "user", "hello")
    store.add_chat_message(sid, "assistant", "hi there")

    export = store.export_session(sid)
    assert "session" in export
    assert "messages" in export
    assert len(export["messages"]) == 2
    assert export["session"]["title"] == "Export test"


def test_export_nonexistent_session(tmp_path, monkeypatch):
    monkeypatch.setattr("neo.store.DB_FILE", tmp_path / "test.db")
    monkeypatch.setattr("neo.store.ensure_neo_home", lambda: None)

    store = LocalStore()
    export = store.export_session(999)
    assert export == {}


def test_list_sessions_empty(tmp_path, monkeypatch):
    monkeypatch.setattr("neo.store.DB_FILE", tmp_path / "test.db")
    monkeypatch.setattr("neo.store.ensure_neo_home", lambda: None)

    store = LocalStore()
    assert store.list_sessions() == []
