"""Authentication manager — login, logout, token storage."""

from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass

import httpx

from neo.config import AUTH_FILE, ensure_neo_home, get_api_url


@dataclass
class AuthToken:
    access_token: str
    refresh_token: str | None
    email: str
    expires_at: float  # Unix timestamp

    def is_expired(self) -> bool:
        return time.time() >= self.expires_at

    def to_dict(self) -> dict:
        return {
            "access_token": self.access_token,
            "refresh_token": self.refresh_token,
            "email": self.email,
            "expires_at": self.expires_at,
        }

    @classmethod
    def from_dict(cls, data: dict) -> AuthToken:
        return cls(
            access_token=data["access_token"],
            refresh_token=data.get("refresh_token"),
            email=data["email"],
            expires_at=data.get("expires_at", 0),
        )


class AuthManager:
    """Handles login, logout, and token persistence."""

    def __init__(self) -> None:
        self._token: AuthToken | None = None

    def load(self) -> AuthToken | None:
        """Load stored token from disk."""
        if self._token is not None:
            return self._token
        if not AUTH_FILE.exists():
            return None
        try:
            data = json.loads(AUTH_FILE.read_text())
            self._token = AuthToken.from_dict(data)
            return self._token
        except (json.JSONDecodeError, KeyError):
            return None

    def save(self, token: AuthToken) -> None:
        """Persist token to disk with secure permissions."""
        ensure_neo_home()
        AUTH_FILE.write_text(json.dumps(token.to_dict(), indent=2))
        os.chmod(AUTH_FILE, 0o600)
        self._token = token

    def clear(self) -> None:
        """Remove stored credentials and attempt server-side revocation.

        Calls the logout endpoint to invalidate the token server-side.
        The local file is always deleted regardless of revocation success.
        """
        token = self.load()
        if token and token.access_token:
            self._try_revoke(token)
        if AUTH_FILE.exists():
            AUTH_FILE.unlink()
        self._token = None

    def _try_revoke(self, token: AuthToken) -> None:
        """Attempt to revoke the token server-side.

        Best-effort — silent on failure. The local clear always happens.

        Args:
            token: The token to revoke.
        """
        api_url = get_api_url()
        try:
            httpx.post(
                f"{api_url}/api/auth/logout",
                headers={"Authorization": f"Bearer {token.access_token}"},
                timeout=5.0,
            )
        except Exception:
            pass

    def get_token(self) -> AuthToken | None:
        """Get current token, returning None if expired."""
        token = self.load()
        if token is None:
            return None
        if token.is_expired():
            refreshed = self._try_refresh(token)
            if refreshed:
                self.save(refreshed)
                return refreshed
            self.clear()
            return None
        return token

    async def register(self, email: str, password: str, name: str = "") -> AuthToken:
        """Register a new account and auto-login.

        Args:
            email: User's email address.
            password: Chosen password.
            name: Optional display name.

        Returns:
            AuthToken for the new account.

        Raises:
            httpx.HTTPStatusError: If registration fails (e.g., email taken).
        """
        api_url = get_api_url()
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{api_url}/api/auth/register",
                json={"email": email, "password": password, "name": name},
                timeout=30.0,
            )
            resp.raise_for_status()
            data = resp.json()

        token = AuthToken(
            access_token=data.get("access_token") or data.get("session_token", ""),
            refresh_token=data.get("refresh_token"),
            email=email,
            expires_at=time.time() + data.get("expires_in", 86400),
        )
        self.save(token)
        return token

    async def login(self, email: str, password: str) -> AuthToken:
        """Authenticate against System R API and store the token."""
        api_url = get_api_url()
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{api_url}/api/auth/login",
                json={"email": email, "password": password},
                timeout=30.0,
            )
            resp.raise_for_status()
            data = resp.json()

        token = AuthToken(
            access_token=data.get("access_token") or data.get("session_token", ""),
            refresh_token=data.get("refresh_token"),
            email=email,
            expires_at=time.time() + data.get("expires_in", 86400),
        )
        self.save(token)
        return token

    def _try_refresh(self, token: AuthToken) -> AuthToken | None:
        """Synchronously attempt to refresh an expired token."""
        if not token.refresh_token:
            return None
        api_url = get_api_url()
        try:
            resp = httpx.post(
                f"{api_url}/api/auth/refresh",
                json={"refresh_token": token.refresh_token},
                timeout=15.0,
            )
            resp.raise_for_status()
            data = resp.json()
            return AuthToken(
                access_token=data["access_token"],
                refresh_token=data.get("refresh_token", token.refresh_token),
                email=token.email,
                expires_at=time.time() + data.get("expires_in", 3600),
            )
        except httpx.HTTPError:
            return None

    @property
    def is_authenticated(self) -> bool:
        return self.get_token() is not None
