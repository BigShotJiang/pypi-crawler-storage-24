"""Trade confirmation flow — mandatory safety layer.

Permission levels (from DESIGN.md §9):
  AUTO           — read-only, calculations: no confirmation needed
  CONFIRM        — place/cancel/modify order: show details, wait for y/n
  DOUBLE_CONFIRM — kill switch: show warning, require typing KILL

SAFETY: Unknown actions default to CONFIRM, not AUTO. Any new tool
added to the backend requires explicit approval until classified.

All financial values in confirmation functions use Decimal.
"""

from __future__ import annotations

from decimal import Decimal
from enum import Enum
from typing import Any

import click
import structlog

from neo.display.theme import (
    GREEN,
    RED,
    GRAY,
    console,
)
from neo.types import Price, RiskAmount, Percentage, Quantity

logger = structlog.get_logger(module="confirmation")


class PermissionLevel(Enum):
    """Permission level for tool actions."""

    AUTO = "auto"
    CONFIRM = "confirm"
    DOUBLE_CONFIRM = "double_confirm"


# Actions mapped to permission levels.
# SAFETY: default is CONFIRM for unknown actions (see get_permission_level).
ACTION_PERMISSIONS: dict[str, PermissionLevel] = {
    # Auto — no confirmation needed (read-only and calculations)
    "get_quote": PermissionLevel.AUTO,
    "get_account_balance": PermissionLevel.AUTO,
    "calculate_position_size": PermissionLevel.AUTO,
    "check_trade_risk": PermissionLevel.AUTO,
    "evaluate_performance": PermissionLevel.AUTO,
    "get_pricing": PermissionLevel.AUTO,
    "get_positions": PermissionLevel.AUTO,
    "get_portfolio": PermissionLevel.AUTO,
    "get_order_status": PermissionLevel.AUTO,
    "search_memory": PermissionLevel.AUTO,
    "get_trading_biases": PermissionLevel.AUTO,
    "record_trade_outcome": PermissionLevel.AUTO,
    "store_memory": PermissionLevel.AUTO,
    # Confirm — show details, wait for y/n (actions touching money)
    "place_order": PermissionLevel.CONFIRM,
    "cancel_order": PermissionLevel.CONFIRM,
    "modify_order": PermissionLevel.CONFIRM,
    "close_position": PermissionLevel.CONFIRM,
    "set_stop_loss": PermissionLevel.CONFIRM,
    "modify_stop": PermissionLevel.CONFIRM,
    "set_take_profit": PermissionLevel.CONFIRM,
    "connect_broker": PermissionLevel.CONFIRM,
    "disconnect_broker": PermissionLevel.CONFIRM,
    # Double confirm — type to confirm (destructive/irreversible)
    "kill_switch": PermissionLevel.DOUBLE_CONFIRM,
    "close_all_positions": PermissionLevel.DOUBLE_CONFIRM,
    "enable_margin": PermissionLevel.DOUBLE_CONFIRM,
    "withdraw_funds": PermissionLevel.DOUBLE_CONFIRM,
}


# ── Permission profiles ────────────────────────────────────────────
# Named profiles configure safety tiers for different user levels.
# Inspired by OpenClaw's tool profiles (messaging/minimal/automation).

# Profile overrides: maps action names to elevated/demoted permission levels.
# Actions not in overrides use the default ACTION_PERMISSIONS mapping.
PERMISSION_PROFILES: dict[str, dict[str, PermissionLevel]] = {
    "paper": {
        # Maximum safety — ALL trade actions require DOUBLE_CONFIRM
        "place_order": PermissionLevel.DOUBLE_CONFIRM,
        "cancel_order": PermissionLevel.DOUBLE_CONFIRM,
        "modify_order": PermissionLevel.DOUBLE_CONFIRM,
        "close_position": PermissionLevel.DOUBLE_CONFIRM,
        "set_stop_loss": PermissionLevel.DOUBLE_CONFIRM,
        "modify_stop": PermissionLevel.DOUBLE_CONFIRM,
        "set_take_profit": PermissionLevel.DOUBLE_CONFIRM,
        "connect_broker": PermissionLevel.DOUBLE_CONFIRM,
    },
    "standard": {},  # Empty — uses ACTION_PERMISSIONS as-is
    "experienced": {
        # Relaxed — stop/target adjustments auto-approved
        "set_stop_loss": PermissionLevel.AUTO,
        "modify_stop": PermissionLevel.AUTO,
        "set_take_profit": PermissionLevel.AUTO,
    },
}

# Active profile — set via /permissions command or config.json
_active_profile: str = "standard"


def get_active_profile() -> str:
    """Return the name of the active permission profile.

    Returns:
        Profile name string.
    """
    return _active_profile


def set_active_profile(profile: str) -> bool:
    """Set the active permission profile and persist to config.json.

    Args:
        profile: Profile name (paper, standard, experienced).

    Returns:
        True if profile was set, False if unknown.
    """
    global _active_profile
    if profile not in PERMISSION_PROFILES:
        return False
    _active_profile = profile
    _save_profile_to_config(profile)
    logger.info("permission_profile_changed", profile=profile)
    return True


def load_profile_from_config() -> None:
    """Load the permission profile from config.json on startup.

    Reads the 'permission_profile' key from ~/.systemr/config.json.
    Falls back to 'standard' if not set or invalid.
    """
    global _active_profile
    import json
    from neo.config import CONFIG_FILE

    if not CONFIG_FILE.exists():
        return

    try:
        config = json.loads(CONFIG_FILE.read_text())
        profile = config.get("permission_profile", "standard")
        if profile in PERMISSION_PROFILES:
            _active_profile = profile
            logger.info("permission_profile_loaded", profile=profile)
    except (json.JSONDecodeError, TypeError):
        pass


def _save_profile_to_config(profile: str) -> None:
    """Persist the active permission profile to config.json.

    Args:
        profile: Profile name to save.
    """
    import json
    from neo.config import CONFIG_FILE, ensure_systemr_home

    ensure_systemr_home()
    config: dict = {}
    if CONFIG_FILE.exists():
        try:
            config = json.loads(CONFIG_FILE.read_text())
        except (json.JSONDecodeError, TypeError):
            config = {}

    config["permission_profile"] = profile
    CONFIG_FILE.write_text(json.dumps(config, indent=2))


def get_permission_level(action: str) -> PermissionLevel:
    """Get the permission level for a given action under active profile.

    Resolution order:
    1. Active profile overrides (if action is in profile)
    2. Default ACTION_PERMISSIONS mapping
    3. CONFIRM (safety default for unknown actions)

    Args:
        action: Tool/action name from the backend.

    Returns:
        The permission level for this action.
    """
    # Check active profile overrides first
    profile_overrides = PERMISSION_PROFILES.get(_active_profile, {})
    if action in profile_overrides:
        return profile_overrides[action]
    return ACTION_PERMISSIONS.get(action, PermissionLevel.CONFIRM)


def confirm_trade(
    symbol: str,
    direction: str,
    entry: Price,
    stop: Price,
    shares: Quantity,
    risk_amount: RiskAmount,
    risk_pct: Percentage,
    target: Price | None = None,
    rr_ratio: Decimal | None = None,
    position_value: Price | None = None,
) -> bool:
    """Show trade card and ask for confirmation.

    All financial values are Decimal. Returns True if the user approves.

    Args:
        symbol: Ticker symbol.
        direction: "long" or "short".
        entry: Entry price.
        stop: Stop loss price.
        shares: Number of shares.
        risk_amount: Total risk in dollars.
        risk_pct: Risk as percentage of account.
        target: Optional target price.
        rr_ratio: Optional reward-to-risk ratio.
        position_value: Optional total position value.

    Returns:
        True if user typed 'y', False otherwise.
    """
    from neo.display.formatters import fmt_price, fmt_qty, fmt_risk, fmt_pct

    dir_color = GREEN if direction.lower() == "long" else RED
    console.print()
    console.print(f"  ┌─ [{GREEN}]TRADE — {symbol.upper()}[/] {'─' * 30}┐")
    console.print(f"  │  Direction   [{dir_color}]{direction.upper()}[/]")
    console.print(f"  │  Entry       {fmt_price(entry)}")
    console.print(f"  │  Stop        {fmt_price(stop)}")
    if target is not None:
        console.print(f"  │  Target      {fmt_price(target)}")
    console.print(f"  │  Shares      {fmt_qty(shares)}")
    console.print(f"  │  Risk        {fmt_risk(risk_amount)} ({fmt_pct(risk_pct)})")
    if rr_ratio is not None:
        console.print(f"  │  R:R         1 : {float(rr_ratio):.1f}")
    if position_value is not None:
        console.print(f"  │  Position    {fmt_price(position_value)}")
    console.print(f"  └{'─' * 45}┘")
    console.print()

    try:
        response = click.prompt(
            click.style("  Place this trade? [y/n]", fg="white"),
            type=click.Choice(["y", "n"], case_sensitive=False),
            show_choices=False,
        )
        approved = response.lower() == "y"
        logger.info(
            "trade_confirmation",
            symbol=symbol, direction=direction, approved=approved,
            risk=str(risk_amount), shares=shares,
        )
        return approved
    except (click.Abort, EOFError):
        logger.info("trade_confirmation", symbol=symbol, approved=False, reason="aborted")
        return False


def confirm_kill_switch(
    positions: list[dict[str, Any]] | None = None,
) -> bool:
    """Double confirmation for kill switch — requires typing KILL.

    This is the most dangerous action. It closes ALL open positions.

    Args:
        positions: Optional list of position dicts to display.

    Returns:
        True only if user types exactly "KILL".
    """
    console.print()
    console.print(f"  [{RED}]{'━' * 48}[/]")
    console.print(f"  [{RED}]KILL SWITCH — This will close ALL open positions.[/]")
    console.print(f"  [{RED}]{'━' * 48}[/]")

    if positions:
        console.print()
        for p in positions:
            symbol = p.get("symbol", "?")
            qty = p.get("quantity", 0)
            pnl = p.get("pnl", 0)
            pnl_color = GREEN if float(pnl) >= 0 else RED
            console.print(
                f"  [{GRAY}]{symbol}  {qty} shares  "
                f"[{pnl_color}]{'+' if float(pnl) >= 0 else ''}{float(pnl):.2f}[/][/]"
            )

    console.print()

    try:
        response = click.prompt(
            click.style("  Type KILL to confirm", fg="red", bold=True),
            default="",
            show_default=False,
        )
        approved = response.strip() == "KILL"
        logger.info("kill_switch_confirmation", approved=approved)
        return approved
    except (click.Abort, EOFError):
        logger.info("kill_switch_confirmation", approved=False, reason="aborted")
        return False
