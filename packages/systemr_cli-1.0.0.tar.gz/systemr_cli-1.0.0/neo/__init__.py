"""System R CLI — trading operating system in your terminal."""

__version__ = "1.0.0"
