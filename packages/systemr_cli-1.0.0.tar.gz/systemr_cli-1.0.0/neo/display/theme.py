"""System R CLI display theme — dark, precise, institutional.

Provides the canonical brand palette (from DESIGN.md §4.2),
Rich theme, console instance, and print helpers.
"""

from rich.console import Console
from rich.theme import Theme

# ── System R brand palette ──────────────────────────────────────────
# Canonical colors from systemr.ai. Do not modify without updating
# DESIGN.md §4.2.

WHITE = "#F5F5F5"          # Primary text — values, data, emphasis
GRAY = "#A1A1AA"           # Secondary text — labels, descriptions
DIM = "#52525B"            # Tertiary text — timestamps, hints
MUTED = "#3F3F46"          # Borders, separators, disabled
GREEN = "#3ECF8E"          # Brand accent — success, active, emphasis
GREEN_DIM = "#34B87A"      # Secondary accent — hover, borders
RED = "#EF4444"            # Errors, losses, short positions
AMBER = "#F59E0B"          # Warnings, caution states
BLUE = "#3B82F6"           # Info, neutral indicators
BG = "#09090B"             # Terminal background

# Legacy aliases (additive-only — old names from Matrix theme still work)
DARK_BG = BG

# ── Rich theme ──────────────────────────────────────────────────────

SYSTEM_R_THEME = Theme({
    # Core palette
    "sr.white": f"bold {WHITE}",
    "sr.gray": GRAY,
    "sr.dim": DIM,
    "sr.muted": MUTED,
    "sr.accent": f"bold {GREEN}",
    "sr.accent.dim": GREEN_DIM,
    "sr.value": f"bold {WHITE}",
    "sr.label": GRAY,

    # Semantic
    "sr.success": f"bold {GREEN}",
    "sr.error": f"bold {RED}",
    "sr.warn": f"bold {AMBER}",
    "sr.info": f"bold {BLUE}",

    # Trading-specific
    "sr.long": f"bold {GREEN}",
    "sr.short": f"bold {RED}",
    "sr.profit": f"bold {GREEN}",
    "sr.loss": f"bold {RED}",

    # Legacy aliases (additive-only)
    "neo.green": f"bold {GREEN}",
    "neo.dim": DIM,
    "neo.label": GREEN_DIM,
    "neo.value": f"bold {WHITE}",
    "neo.error": f"bold {RED}",
    "neo.warn": f"bold {AMBER}",
    "neo.header": f"bold {GREEN}",
    "neo.muted": f"dim {GREEN_DIM}",
})

console = Console(theme=SYSTEM_R_THEME)

# ── Indicators ──────────────────────────────────────────────────────

ICON_THINKING = "◐"
ICON_SUCCESS = "✓"
ICON_ERROR = "✗"
ICON_WARN = "!"
ICON_INFO = "●"
ICON_CONNECTED = "●"
ICON_DISCONNECTED = "○"

# ── Legacy banner (kept for backward compat) ────────────────────────

NEO_BANNER = rf"""[{GREEN}]
 ███╗   ██╗███████╗ ██████╗
 ████╗  ██║██╔════╝██╔═══██╗
 ██╔██╗ ██║█████╗  ██║   ██║
 ██║╚██╗██║██╔══╝  ██║   ██║
 ██║ ╚████║███████╗╚██████╔╝
 ╚═╝  ╚═══╝╚══════╝ ╚═════╝[/]
[{GREEN_DIM}] System R AI — Trading Operator[/]
"""


# ── Print helpers ───────────────────────────────────────────────────

def print_banner() -> None:
    """Print the System R home screen header.

    SYSTEM R AI in brand green bold, version, tagline.
    """
    from neo import __version__
    console.print()
    console.print(f"  [{GREEN}][bold]SYSTEM R AI[/bold][/]  [{DIM}]V{__version__}[/]", highlight=False)
    console.print()
    console.print(f"  [{GRAY}]Trading operating system for agents[/]")
    console.print()


def neo_banner() -> str:
    """Return legacy banner string.

    Returns:
        Rich-formatted banner string.
    """
    return f"[{GREEN}]SYSTEM R[/] [{GREEN_DIM}]Trading OS[/]"


def print_error(msg: str) -> None:
    """Print an error message.

    Args:
        msg: Error message text.
    """
    console.print(f"  [{RED}]{ICON_ERROR}[/] [{GRAY}]{msg}[/]")


def print_success(msg: str) -> None:
    """Print a success message.

    Args:
        msg: Success message text.
    """
    console.print(f"  [{GREEN}]{ICON_SUCCESS}[/] [{WHITE}]{msg}[/]")


def print_warn(msg: str) -> None:
    """Print a warning message.

    Args:
        msg: Warning message text.
    """
    console.print(f"  [{AMBER}]{ICON_WARN}[/] [{GRAY}]{msg}[/]")


def print_info(msg: str) -> None:
    """Print an info message.

    Args:
        msg: Info message text.
    """
    console.print(f"  [{BLUE}]{ICON_INFO}[/] [{GRAY}]{msg}[/]")


def print_separator() -> None:
    """Print a separator line.

    Uses 48 thin dashes in MUTED color.
    """
    console.print(f"  [{MUTED}]{'─' * 48}[/]")
