"""Formatting utilities for trading data.

All formatters accept both Decimal and float for backward compatibility.
New code should pass Decimal values (from neo.types).
"""

from __future__ import annotations

from decimal import Decimal
from typing import Union

# Accept both Decimal and float — Decimal preferred, float for backward compat
Numeric = Union[Decimal, float, int]


def fmt_price(value: Numeric, decimals: int = 2) -> str:
    """Format a price with $ prefix.

    Args:
        value: Price as Decimal, float, or int.
        decimals: Number of decimal places (default 2).

    Returns:
        Formatted string like "$1,234.56".
    """
    return f"${float(value):,.{decimals}f}"


def fmt_qty(value: int | float) -> str:
    """Format a quantity (shares/contracts).

    Args:
        value: Quantity as int or float. Floats that are whole numbers
               are displayed without decimals.

    Returns:
        Formatted string like "1,200".
    """
    if isinstance(value, float) and value == int(value):
        value = int(value)
    return f"{value:,}"


def fmt_pct(value: Numeric, decimals: int = 1, signed: bool = False) -> str:
    """Format as percentage.

    Args:
        value: Percentage as Decimal, float, or int.
        decimals: Number of decimal places (default 1).
        signed: If True, prefix with +/- sign (DESIGN.md §4.3).

    Returns:
        Formatted string like "1.5%" or "+2.34%".
    """
    v = float(value)
    if signed:
        sign = "+" if v > 0 else ""
        return f"{sign}{v:.{decimals}f}%"
    return f"{v:.{decimals}f}%"


def fmt_r(value: Numeric) -> str:
    """Format an R-multiple.

    Args:
        value: R-multiple as Decimal, float, or int.

    Returns:
        Formatted string like "+1.50R" or "-1.00R".
    """
    v = float(value)
    sign = "+" if v > 0 else ""
    return f"{sign}{v:.2f}R"


def fmt_risk(value: Numeric) -> str:
    """Format a risk amount with $ prefix.

    Args:
        value: Risk amount as Decimal, float, or int.

    Returns:
        Formatted string like "$1,046.80".
    """
    return f"${float(value):,.2f}"


def fmt_pnl(value: Numeric) -> str:
    """Format P&L with sign and Rich color markup.

    Args:
        value: P&L amount as Decimal, float, or int.

    Returns:
        Rich-formatted string with green for profit, red for loss.
    """
    v = float(value)
    sign = "+" if v >= 0 else ""
    color = "#3ECF8E" if v >= 0 else "#EF4444"
    return f"[{color}]{sign}${v:,.2f}[/]"


def direction_style(direction: str) -> str:
    """Return Rich style string for trade direction.

    Args:
        direction: "long" or "short".

    Returns:
        Rich style string with brand colors.
    """
    return "bold #3ECF8E" if direction.lower() == "long" else "bold #EF4444"
