"""Chat message renderer — System R streaming conversation display.

All rendering goes through Rich console. No raw sys.stdout writes.
Text deltas are collected by the chat loop and rendered once as a
formatted panel when the done event arrives — no double rendering.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Union

from rich.markdown import Markdown
from rich.panel import Panel

from neo.display.theme import (
    GREEN,
    GREEN_DIM,
    DIM,
    MUTED,
    GRAY,
    RED,
    AMBER,
    console,
)

# Indicators — defined in theme.py, imported for consistency
ICON_THINKING = "◐"
ICON_SUCCESS = "✓"
ICON_ERROR = "✗"

# Low balance threshold — must match credits.SessionCredits if used
_LOW_BALANCE_THRESHOLD: Decimal = Decimal("50")


def render_user_message(text: str) -> None:
    """Render a user message with the you > prompt.

    Args:
        text: The user's input text.
    """
    console.print(f"\n  [{GREEN_DIM}]you >[/] {text}")


def render_assistant_message(text: str) -> None:
    """Render a complete System R response as a Rich markdown panel.

    Args:
        text: The full response text (may contain markdown).
    """
    if not text.strip():
        return
    md = Markdown(text)
    console.print(
        Panel(
            md,
            title=f"[bold {GREEN}]SYSTEM R[/]",
            border_style=MUTED,
            padding=(1, 2),
        )
    )


def render_thinking(text: str = "thinking...") -> None:
    """Show a thinking step from the LLM reasoning process.

    Args:
        text: Description of what the LLM is thinking about.
    """
    console.print(f"  [{DIM}]{ICON_THINKING} {text}[/]")


def render_action(
    tool_name: str,
    status: str = "running",
    result: str = "",
) -> None:
    """Show a tool call being executed with status indicator.

    Args:
        tool_name: Name of the tool being called.
        status: One of "running", "complete", "error", "pending".
        result: Optional result summary (truncated in display).
    """
    if status == "complete":
        suffix = f"  [{GRAY}]{result}[/]" if result else ""
        console.print(f"  [{GREEN}]{ICON_SUCCESS}[/] [{GRAY}]{tool_name}[/]{suffix}")
    elif status == "error":
        suffix = f"  [{RED}]{result}[/]" if result else ""
        console.print(f"  [{RED}]{ICON_ERROR}[/] [{GRAY}]{tool_name}[/]{suffix}")
    elif status == "pending":
        suffix = f"  [{AMBER}]{result}[/]" if result else ""
        console.print(f"  [{AMBER}]![/] [{GRAY}]{tool_name}[/]{suffix}")
    else:
        console.print(f"  [{GREEN_DIM}]{ICON_THINKING}[/] [{GRAY}]{tool_name}...[/]")


def render_error(message: str) -> None:
    """Show an error from the stream or chat loop.

    Args:
        message: The error message text.
    """
    console.print(f"\n  [{RED}]{ICON_ERROR}[/] [{GRAY}]{message}[/]")


def render_credits(
    credits_used: Union[Decimal, float, None] = None,
    balance: Union[Decimal, float, None] = None,
) -> None:
    """Show credit usage after a response.

    Args:
        credits_used: Credits consumed by this response.
        balance: Remaining credit balance.
    """
    parts: list[str] = []
    if credits_used is not None:
        parts.append(f"{float(credits_used):.1f} credits")
    if balance is not None:
        bal = Decimal(str(balance)) if not isinstance(balance, Decimal) else balance
        if bal < _LOW_BALANCE_THRESHOLD:
            parts.append(f"[{AMBER}]balance: {float(balance):.1f}[/]")
        else:
            parts.append(f"balance: {float(balance):.1f}")
    if parts:
        console.print(f"  [{DIM}]{' · '.join(parts)}[/]")
