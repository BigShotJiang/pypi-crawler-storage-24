"""System R CLI configuration — paths, settings, defaults."""

from __future__ import annotations

import os
from pathlib import Path

# Base directory for all System R local data
SYSTEMR_HOME = Path(os.environ.get("SYSTEMR_HOME", Path.home() / ".systemr"))

# File paths
AUTH_FILE = SYSTEMR_HOME / "auth.json"
DB_FILE = SYSTEMR_HOME / "journal.db"
CONFIG_FILE = SYSTEMR_HOME / "config.json"
PROFILE_FILE = SYSTEMR_HOME / "PROFILE.md"
RULES_FILE = SYSTEMR_HOME / "RULES.md"
MEMORY_DIR = SYSTEMR_HOME / "memory"
MEMORY_INDEX = MEMORY_DIR / "MEMORY.md"
SESSIONS_DIR = SYSTEMR_HOME / "sessions"

# API base URLs
DEFAULT_API_URL = "https://agents.systemr.ai"
STAGING_API_URL = "https://app-staging.systemr.ai"

# Backward compat aliases (additive-only rule — old names still work)
NEO_HOME = SYSTEMR_HOME


def get_api_url() -> str:
    """Return the API base URL, respecting SYSTEMR_API_URL env override.

    Validates HTTPS for non-localhost URLs to prevent credential leaks
    over plaintext connections.

    Returns:
        The API base URL string.

    Raises:
        ValueError: If the URL uses HTTP for a non-localhost host.
    """
    # Check new name first, fall back to old name for backward compat
    url = os.environ.get(
        "SYSTEMR_API_URL",
        os.environ.get("NEO_API_URL", DEFAULT_API_URL),
    )
    if (
        not url.startswith("https://")
        and "localhost" not in url
        and "127.0.0.1" not in url
    ):
        raise ValueError(
            f"SYSTEMR_API_URL must use HTTPS (got: {url}). "
            "Only localhost URLs are allowed over HTTP."
        )
    return url


def ensure_systemr_home() -> None:
    """Create ~/.systemr/ with secure permissions if it doesn't exist.

    Creates the base directory plus memory/ and sessions/ subdirectories.
    All directories use mode 0o700 (owner read/write/execute only).
    """
    SYSTEMR_HOME.mkdir(mode=0o700, parents=True, exist_ok=True)
    MEMORY_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)
    SESSIONS_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)


# Backward compat alias
ensure_neo_home = ensure_systemr_home
