"""Local SQLite store for trade journal and analysis cache.

Financial values are stored as TEXT in SQLite (not REAL) to preserve
exact Decimal precision. The boundary conversion happens here — callers
always get Decimal values back from trade queries.
"""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any, Generator, Union

from neo.config import DB_FILE, ensure_neo_home
from neo.types import to_decimal

# Accept both Decimal and float at the boundary (backward compat)
Numeric = Union[Decimal, float, int]

SCHEMA = """
CREATE TABLE IF NOT EXISTS trades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT NOT NULL,
    direction TEXT NOT NULL CHECK(direction IN ('long', 'short')),
    entry_price TEXT NOT NULL,
    stop_price TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    entry_date TEXT NOT NULL,
    exit_price TEXT,
    exit_date TEXT,
    r_multiple TEXT,
    notes TEXT,
    tags TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS chat_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS chat_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL REFERENCES chat_sessions(id),
    role TEXT NOT NULL CHECK(role IN ('user', 'assistant')),
    content TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_trades_symbol ON trades(symbol);
CREATE INDEX IF NOT EXISTS idx_trades_entry_date ON trades(entry_date);
CREATE INDEX IF NOT EXISTS idx_chat_messages_session ON chat_messages(session_id);
"""


# Financial fields that are stored as TEXT and returned as Decimal
_DECIMAL_FIELDS = {"entry_price", "stop_price", "exit_price", "r_multiple"}


def _decimalize_trade(row: dict[str, Any]) -> dict[str, Any]:
    """Convert TEXT financial fields back to Decimal on read.

    Args:
        row: A trade dict from SQLite.

    Returns:
        The same dict with financial fields as Decimal.
    """
    for field in _DECIMAL_FIELDS:
        val = row.get(field)
        if val is not None:
            row[field] = Decimal(str(val))
    return row


class LocalStore:
    """SQLite-backed local data store.

    Financial values (prices, R-multiples) are stored as TEXT to preserve
    exact Decimal precision. They are converted to Decimal on read.
    """

    def __init__(self) -> None:
        ensure_neo_home()
        self._db_path = str(DB_FILE)
        self._init_db()

    def _init_db(self) -> None:
        """Initialize database schema."""
        with self._conn() as conn:
            conn.executescript(SCHEMA)

    @contextmanager
    def _conn(self) -> Generator[sqlite3.Connection, None, None]:
        """Get a database connection with WAL mode and foreign keys."""
        conn = sqlite3.connect(self._db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()

    def _now(self) -> str:
        """Return current UTC timestamp in ISO format."""
        return datetime.now(timezone.utc).isoformat()

    # --- Trades ---

    def add_trade(
        self,
        symbol: str,
        direction: str,
        entry_price: Numeric,
        stop_price: Numeric,
        quantity: int,
        entry_date: str | None = None,
        notes: str | None = None,
        tags: str | None = None,
    ) -> int:
        """Add a trade to the journal.

        Args:
            symbol: Ticker symbol (auto-uppercased).
            direction: "long" or "short".
            entry_price: Entry price (Decimal or float).
            stop_price: Stop loss price (Decimal or float).
            quantity: Number of shares/contracts.
            entry_date: Date string YYYY-MM-DD (default: today).
            notes: Optional trade notes.
            tags: Optional comma-separated tags.

        Returns:
            The trade ID.
        """
        now = self._now()
        if entry_date is None:
            entry_date = now[:10]
        # Convert to string for TEXT storage (preserves Decimal precision)
        entry_str = str(to_decimal(entry_price))
        stop_str = str(to_decimal(stop_price))
        with self._conn() as conn:
            cursor = conn.execute(
                """INSERT INTO trades
                   (symbol, direction, entry_price, stop_price, quantity,
                    entry_date, notes, tags, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (symbol.upper(), direction, entry_str, stop_str,
                 quantity, entry_date, notes, tags, now, now),
            )
            return cursor.lastrowid  # type: ignore[return-value]

    def list_trades(
        self, limit: int = 50, symbol: str | None = None
    ) -> list[dict[str, Any]]:
        """List trades from the journal.

        Args:
            limit: Maximum number of trades to return.
            symbol: Optional filter by ticker symbol.

        Returns:
            List of trade dicts with Decimal financial values.
        """
        with self._conn() as conn:
            if symbol:
                rows = conn.execute(
                    "SELECT * FROM trades WHERE symbol = ? "
                    "ORDER BY entry_date DESC LIMIT ?",
                    (symbol.upper(), limit),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM trades ORDER BY entry_date DESC LIMIT ?",
                    (limit,),
                ).fetchall()
        return [_decimalize_trade(dict(r)) for r in rows]

    def get_trade(self, trade_id: int) -> dict[str, Any] | None:
        """Get a single trade by ID.

        Args:
            trade_id: The trade ID.

        Returns:
            Trade dict with Decimal financial values, or None.
        """
        with self._conn() as conn:
            row = conn.execute(
                "SELECT * FROM trades WHERE id = ?", (trade_id,)
            ).fetchone()
        if row is None:
            return None
        return _decimalize_trade(dict(row))

    def update_trade(self, trade_id: int, **fields: Any) -> bool:
        """Update fields on a trade.

        Financial fields (exit_price, r_multiple, entry_price, stop_price)
        are converted to string for TEXT storage.

        Args:
            trade_id: The trade ID.
            **fields: Fields to update (must be in the allowed set).

        Returns:
            True if the trade was updated, False if not found or no changes.
        """
        allowed = {
            "exit_price", "exit_date", "r_multiple", "notes",
            "tags", "quantity", "entry_price", "stop_price",
        }
        updates = {k: v for k, v in fields.items() if k in allowed and v is not None}
        if not updates:
            return False
        # Convert financial fields to string for TEXT storage
        for field in _DECIMAL_FIELDS:
            if field in updates:
                updates[field] = str(to_decimal(updates[field]))
        updates["updated_at"] = self._now()
        set_clause = ", ".join(f"{k} = ?" for k in updates)
        values = list(updates.values()) + [trade_id]
        with self._conn() as conn:
            cursor = conn.execute(
                f"UPDATE trades SET {set_clause} WHERE id = ?", values
            )
            return cursor.rowcount > 0

    def delete_trade(self, trade_id: int) -> bool:
        """Delete a trade from the journal.

        Args:
            trade_id: The trade ID.

        Returns:
            True if the trade was deleted, False if not found.
        """
        with self._conn() as conn:
            cursor = conn.execute(
                "DELETE FROM trades WHERE id = ?", (trade_id,)
            )
            return cursor.rowcount > 0

    def export_trades(self) -> list[dict[str, Any]]:
        """Export all trades.

        Returns:
            List of all trade dicts with Decimal financial values.
        """
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM trades ORDER BY entry_date DESC"
            ).fetchall()
        return [_decimalize_trade(dict(r)) for r in rows]

    # --- Chat Sessions ---

    def create_chat_session(self, title: str | None = None) -> int:
        """Create a new chat session.

        Args:
            title: Optional session title.

        Returns:
            The session ID.
        """
        now = self._now()
        with self._conn() as conn:
            cursor = conn.execute(
                "INSERT INTO chat_sessions (title, created_at, updated_at) "
                "VALUES (?, ?, ?)",
                (title, now, now),
            )
            return cursor.lastrowid  # type: ignore[return-value]

    def add_chat_message(
        self, session_id: int, role: str, content: str
    ) -> int:
        """Add a message to a chat session.

        Args:
            session_id: The session ID.
            role: "user" or "assistant".
            content: Message content.

        Returns:
            The message ID.
        """
        now = self._now()
        with self._conn() as conn:
            cursor = conn.execute(
                "INSERT INTO chat_messages "
                "(session_id, role, content, created_at) "
                "VALUES (?, ?, ?, ?)",
                (session_id, role, content, now),
            )
            conn.execute(
                "UPDATE chat_sessions SET updated_at = ? WHERE id = ?",
                (now, session_id),
            )
            return cursor.lastrowid  # type: ignore[return-value]

    def get_chat_history(
        self, session_id: int
    ) -> list[dict[str, Any]]:
        """Get all messages in a chat session.

        Args:
            session_id: The session ID.

        Returns:
            List of message dicts ordered by creation time.
        """
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM chat_messages WHERE session_id = ? "
                "ORDER BY created_at",
                (session_id,),
            ).fetchall()
        return [dict(r) for r in rows]

    def list_sessions(self, limit: int = 20) -> list[dict[str, Any]]:
        """List recent chat sessions with message counts.

        Args:
            limit: Maximum sessions to return.

        Returns:
            List of session dicts with id, title, created_at, message_count.
        """
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT s.id, s.title, s.created_at, s.updated_at, "
                "COUNT(m.id) as message_count "
                "FROM chat_sessions s "
                "LEFT JOIN chat_messages m ON s.id = m.session_id "
                "GROUP BY s.id "
                "ORDER BY s.updated_at DESC "
                "LIMIT ?",
                (limit,),
            ).fetchall()
        return [dict(r) for r in rows]

    def prune_sessions(self, days: int = 30) -> int:
        """Delete sessions older than the specified number of days.

        Args:
            days: Sessions older than this many days are deleted.

        Returns:
            Number of sessions deleted.
        """
        from datetime import timedelta
        cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
        with self._conn() as conn:
            # Get IDs to delete
            rows = conn.execute(
                "SELECT id FROM chat_sessions WHERE updated_at < ?",
                (cutoff,),
            ).fetchall()
            ids = [r["id"] for r in rows]
            if ids:
                placeholders = ",".join("?" * len(ids))
                conn.execute(
                    f"DELETE FROM chat_messages WHERE session_id IN ({placeholders})",
                    ids,
                )
                conn.execute(
                    f"DELETE FROM chat_sessions WHERE id IN ({placeholders})",
                    ids,
                )
        return len(ids)

    def export_session(self, session_id: int) -> dict[str, Any]:
        """Export a session and its messages as a JSON-serializable dict.

        Args:
            session_id: The session ID.

        Returns:
            Dict with session metadata and messages.
        """
        with self._conn() as conn:
            session = conn.execute(
                "SELECT * FROM chat_sessions WHERE id = ?",
                (session_id,),
            ).fetchone()
            if not session:
                return {}
            messages = conn.execute(
                "SELECT role, content, created_at FROM chat_messages "
                "WHERE session_id = ? ORDER BY created_at",
                (session_id,),
            ).fetchall()
        return {
            "session": dict(session),
            "messages": [dict(m) for m in messages],
        }
