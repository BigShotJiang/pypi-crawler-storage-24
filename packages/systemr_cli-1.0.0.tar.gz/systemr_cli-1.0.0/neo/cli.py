"""System R CLI — main entry point.

Shows the home screen when invoked without subcommands.
Initializes the local directory structure on first run.
Checks for updates on launch (non-blocking).
"""

from __future__ import annotations

import click

from neo import __version__
from neo.commands.auth_commands import balance, link_wallet, login, logout, pay, register, verify, whoami
from neo.commands.chat_commands import chat
from neo.commands.cron_commands import cron
from neo.commands.doctor_command import doctor
from neo.commands.eval_commands import eval
from neo.commands.journal_commands import journal
from neo.commands.plan_commands import plan
from neo.commands.risk_commands import risk
from neo.commands.scan_commands import scan
from neo.commands.size_commands import size
from neo.display.theme import (
    WHITE,
    GRAY,
    DIM,
    MUTED,
    GREEN,
    RED,
    ICON_CONNECTED,
    ICON_DISCONNECTED,
    console,
    print_banner,
    print_separator,
)


@click.group(invoke_without_command=True)
@click.version_option(version=__version__, prog_name="systemr")
@click.pass_context
def cli(ctx: click.Context) -> None:
    """System R — trading operating system in your terminal."""
    # Configure logging (suppress INFO from terminal, only WARN+ to stderr)
    from neo.logging import configure_logging
    configure_logging(debug=False)

    # Initialize local directory on first run
    from neo.profile import init_all
    init_all()

    # Load saved permission profile
    from neo.confirmation import load_profile_from_config
    load_profile_from_config()

    if ctx.invoked_subcommand is None:
        _show_home()


def _show_home() -> None:
    """Home screen — clean, three-state status display."""
    from neo.auth import AuthManager
    from neo.profile import profile_exists

    print_banner()

    auth = AuthManager()
    token = auth.get_token()

    if not token:
        # State 1: Not logged in
        console.print(
            f"  [{RED}]{ICON_DISCONNECTED}[/] [{RED}]not connected[/]   "
            f"[{MUTED}]run[/] [{DIM}]systemr login[/]"
        )
    else:
        # State 2 or 3: Logged in
        console.print(
            f"  [{GREEN}]{ICON_CONNECTED}[/] [{GREEN}]connected[/] [{GRAY}]as {token.email}[/]"
        )
        if not profile_exists():
            # State 2: No profile yet
            console.print(
                f"  [{GRAY}]{ICON_DISCONNECTED}[/] [{GRAY}]no profile yet[/]   "
                f"[{MUTED}]run[/] [{DIM}]systemr setup[/]"
            )

    console.print()


# ── Command registration ────────────────────────────────────────────

# Auth & Billing
cli.add_command(register)
cli.add_command(login)
cli.add_command(verify)
cli.add_command(pay)
cli.add_command(balance)
cli.add_command(link_wallet)
cli.add_command(logout)
cli.add_command(whoami)

# Trading commands
cli.add_command(size)
cli.add_command(risk)
cli.add_command(eval)
cli.add_command(scan)
cli.add_command(plan)

# Local
cli.add_command(journal)

# Interactive
cli.add_command(chat)

# Automation
cli.add_command(cron)

# Diagnostics
cli.add_command(doctor)


# Setup
@click.command()
def setup() -> None:
    """Run the profile setup wizard."""
    from neo.display.theme import print_success, print_info
    from neo.profile import (
        profile_exists, save_profile, save_rules, save_standing_order, init_all,
    )

    init_all()
    print_banner()

    if profile_exists():
        print_info("Profile already exists. Answers will overwrite it.")

    console.print(f"  [{WHITE}]Welcome. Let's set up your profile.[/]")
    console.print()

    style = click.prompt(click.style("  Trading style", fg="white"))
    timeframe = click.prompt(click.style("  Timeframe", fg="white"))
    risk_pct = click.prompt(click.style("  Max risk per trade (%)", fg="white"))
    daily_loss = click.prompt(click.style("  Max daily loss (%)", fg="white"))
    max_pos = click.prompt(click.style("  Max open positions", fg="white"), type=int)
    broker = click.prompt(click.style("  Primary broker", fg="white"))
    name = click.prompt(click.style("  Your name", fg="white"))

    console.print()
    console.print(f"  [{GRAY}]Any hard rules? (comma-separated, or Enter to skip)[/]")
    rules_input = click.prompt(
        click.style("  Rules", fg="white"), default="", show_default=False,
    )
    hard_rules = [r.strip() for r in rules_input.split(",") if r.strip()]

    experience = click.prompt(
        click.style("  Experience level", fg="white"),
        type=click.Choice(["beginner", "intermediate", "advanced"]),
    )

    console.print()
    print_separator()
    console.print()

    save_profile(
        name=name, style=style, timeframe=timeframe,
        experience=experience, risk_pct=risk_pct,
        daily_loss_pct=daily_loss, max_positions=max_pos, broker=broker,
    )
    print_success("Profile saved to ~/.systemr/PROFILE.md")

    if hard_rules:
        save_rules(hard_rules=hard_rules, soft_rules=[])
        print_success("Rules saved to ~/.systemr/RULES.md")

    # Standing orders (optional)
    console.print()
    console.print(f"  [{GRAY}]Standing orders give your agent authority to act within boundaries.[/]")
    console.print(f"  [{DIM}]Example: 'Every morning, scan watchlist for setups. Report only, no trades.'[/]")
    add_orders = click.confirm(
        click.style("  Add a standing order?", fg="white"), default=False,
    )
    if add_orders:
        order_name = click.prompt(click.style("  Order name", fg="white"))
        order_action = click.prompt(click.style("  What should it do?", fg="white"))
        order_trigger = click.prompt(
            click.style("  When? (e.g., 'Daily at 7AM', 'On trade close')", fg="white"),
        )
        save_standing_order(
            name=order_name,
            scope=order_action,
            trigger=order_trigger,
            approval="Report only — do NOT execute trades without confirmation",
            escalation="Alert if unable to complete",
            action=order_action,
        )
        print_success(f"Standing order '{order_name}' saved to RULES.md")

    console.print()
    console.print(
        f"  [{WHITE}]You're ready. Run `systemr chat` to start.[/]"
    )
    console.print()


cli.add_command(setup)
