"""Model failover chain — automatic fallback on stream failure.

When the primary model fails (timeout, 429, 5xx), tries the next model
in the configured fallback chain. Tracks cooldowns per model to avoid
retrying a model that just failed.

Inspired by OpenClaw's two-stage failover with cooldown tracking and
session pinning. Simplified for System R: no auth rotation, just model
fallback with cooldown.

No bare print() — logging via structlog.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path

import structlog

from neo.config import CONFIG_FILE, ensure_systemr_home

logger = structlog.get_logger(module="model_failover")

# Default cooldown: 60 seconds after a failure
DEFAULT_COOLDOWN_SECONDS: float = 60.0

# Maximum cooldown: 15 minutes
MAX_COOLDOWN_SECONDS: float = 900.0

# Default fallback chain
DEFAULT_FALLBACKS: list[str] = [
    "anthropic.claude-sonnet-4-6",
    "anthropic.claude-haiku-4-5-20251001",
]


@dataclass
class ModelCooldown:
    """Tracks failure state for a single model.

    Attributes:
        model: Model identifier.
        failed_at: Unix timestamp of last failure.
        cooldown_until: Unix timestamp when cooldown expires.
        error_count: Consecutive failure count.
    """

    model: str
    failed_at: float = 0.0
    cooldown_until: float = 0.0
    error_count: int = 0

    @property
    def is_cooled_down(self) -> bool:
        """True if the model is available (cooldown expired)."""
        return time.time() >= self.cooldown_until

    def record_failure(self) -> None:
        """Record a failure and extend cooldown with exponential backoff."""
        self.error_count += 1
        self.failed_at = time.time()
        # Exponential backoff: 60s, 120s, 240s, ... capped at 15min
        backoff = min(
            DEFAULT_COOLDOWN_SECONDS * (2 ** (self.error_count - 1)),
            MAX_COOLDOWN_SECONDS,
        )
        self.cooldown_until = self.failed_at + backoff
        logger.info(
            "model_cooldown_set",
            model=self.model,
            error_count=self.error_count,
            cooldown_seconds=backoff,
        )

    def record_success(self) -> None:
        """Reset cooldown state after a successful call."""
        if self.error_count > 0:
            logger.info(
                "model_cooldown_reset",
                model=self.model,
                was_error_count=self.error_count,
            )
        self.error_count = 0
        self.cooldown_until = 0.0


@dataclass
class FailoverChain:
    """Manages model selection with automatic failover.

    Attributes:
        primary: Primary model to use.
        fallbacks: Ordered list of fallback models.
        cooldowns: Per-model cooldown state.
        pinned_model: Model pinned for current session (sticks until failure).
    """

    primary: str = ""
    fallbacks: list[str] = field(default_factory=list)
    cooldowns: dict[str, ModelCooldown] = field(default_factory=dict)
    pinned_model: str | None = None

    def get_model(self) -> str:
        """Return the best available model (pinned > primary > fallbacks).

        Returns:
            Model identifier string.
        """
        # If pinned and not in cooldown, use it
        if self.pinned_model:
            cd = self.cooldowns.get(self.pinned_model)
            if cd is None or cd.is_cooled_down:
                return self.pinned_model

        # Try primary
        cd = self.cooldowns.get(self.primary)
        if cd is None or cd.is_cooled_down:
            return self.primary

        # Try fallbacks in order
        for model in self.fallbacks:
            cd = self.cooldowns.get(model)
            if cd is None or cd.is_cooled_down:
                logger.info("model_failover", from_model=self.primary, to_model=model)
                return model

        # All models in cooldown — use primary anyway (best effort)
        logger.warning("all_models_in_cooldown", primary=self.primary)
        return self.primary

    def on_success(self, model: str) -> None:
        """Record successful call — pin model for session, reset cooldown.

        Args:
            model: The model that succeeded.
        """
        self.pinned_model = model
        if model in self.cooldowns:
            self.cooldowns[model].record_success()

    def on_failure(self, model: str) -> None:
        """Record failed call — set cooldown, unpin if pinned.

        Args:
            model: The model that failed.
        """
        if model not in self.cooldowns:
            self.cooldowns[model] = ModelCooldown(model=model)
        self.cooldowns[model].record_failure()

        # Unpin so next call tries a different model
        if self.pinned_model == model:
            self.pinned_model = None


def load_failover_chain() -> FailoverChain:
    """Load failover configuration from ~/.systemr/config.json.

    Config format:
    {
        "model": {
            "primary": "anthropic.claude-sonnet-4-6",
            "fallbacks": ["anthropic.claude-haiku-4-5-20251001"]
        }
    }

    Returns:
        Configured FailoverChain instance.
    """
    chain = FailoverChain()

    if CONFIG_FILE.exists():
        try:
            config = json.loads(CONFIG_FILE.read_text())
            model_config = config.get("model", {})
            chain.primary = model_config.get("primary", "")
            chain.fallbacks = model_config.get("fallbacks", DEFAULT_FALLBACKS)
        except (json.JSONDecodeError, TypeError):
            logger.warning("config_parse_error", path=str(CONFIG_FILE))

    if not chain.primary:
        chain.primary = DEFAULT_FALLBACKS[0] if DEFAULT_FALLBACKS else ""
        chain.fallbacks = DEFAULT_FALLBACKS[1:] if len(DEFAULT_FALLBACKS) > 1 else []

    logger.info(
        "failover_chain_loaded",
        primary=chain.primary,
        fallbacks=chain.fallbacks,
    )
    return chain
