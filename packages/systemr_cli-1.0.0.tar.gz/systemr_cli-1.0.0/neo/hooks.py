"""Hooks system — pre/post event automation.

Mirrors Claude Code's hook architecture with trading-specific events.
Hooks are shell commands configured in ~/.systemr/config.json.

Event types:
  PreTrade     — before any order is placed (confirmation approved)
  PostTrade    — after an order is confirmed executed
  PreSession   — when a chat session starts
  PostSession  — when a chat session ends
  RuleViolation — when a trading rule is violated
  KillSwitch   — when kill switch is activated
  LowBalance   — when credits drop below threshold
  Error        — when an error occurs

Config format in config.json:
{
  "hooks": {
    "PreTrade": [{"command": "echo 'Trade incoming'"}],
    "PostTrade": [{"command": "say 'Trade executed'"}]
  }
}
"""

from __future__ import annotations

import json
import os
import subprocess
from enum import Enum
from typing import Any

import structlog

from neo.config import CONFIG_FILE

logger = structlog.get_logger(module="hooks")


class HookEvent(Enum):
    """Hook event types matching Claude Code's architecture.

    Extended with OpenClaw-inspired events:
    - BEFORE_TOOL_CALL: inspect tool name + args before execution, can block
    - COMPACT_BEFORE: auto-flush memories before context compaction
    """

    PRE_TRADE = "PreTrade"
    POST_TRADE = "PostTrade"
    PRE_SESSION = "PreSession"
    POST_SESSION = "PostSession"
    RULE_VIOLATION = "RuleViolation"
    KILL_SWITCH = "KillSwitch"
    LOW_BALANCE = "LowBalance"
    ERROR = "Error"
    # New: OpenClaw-inspired events
    BEFORE_TOOL_CALL = "BeforeToolCall"
    COMPACT_BEFORE = "CompactBefore"


# Maximum time a hook can run before being killed
_HOOK_TIMEOUT_SECONDS = 10


def fire_hook(
    event: HookEvent,
    context: dict[str, Any] | None = None,
) -> list[str]:
    """Fire all hooks registered for the given event.

    Hooks are non-blocking — they run with a timeout and failures
    are logged but never propagate to the caller.

    Args:
        event: The hook event type to fire.
        context: Optional dict passed as SYSTEMR_HOOK_CONTEXT env var.

    Returns:
        List of hook stdout outputs (empty strings filtered out).
    """
    hooks = _load_hooks(event)
    if not hooks:
        return []

    outputs: list[str] = []
    for hook in hooks:
        command = hook.get("command", "")
        if not command:
            continue
        try:
            env = dict(os.environ)
            if context:
                env["SYSTEMR_HOOK_CONTEXT"] = json.dumps(context)

            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=_HOOK_TIMEOUT_SECONDS,
                env=env,
            )
            if result.stdout.strip():
                outputs.append(result.stdout.strip())
            logger.debug(
                "hook_fired", hook_event=event.value,
                command=command[:50], exit_code=result.returncode,
            )
        except subprocess.TimeoutExpired:
            logger.warning("hook_timeout", hook_event=event.value, command=command[:50])
        except Exception as exc:
            logger.warning("hook_error", hook_event=event.value, error=str(exc))

    return outputs


def _load_hooks(event: HookEvent) -> list[dict[str, str]]:
    """Load hooks for a specific event from config.json.

    Args:
        event: The hook event type.

    Returns:
        List of hook dicts with "command" key. Empty if no config.
    """
    if not CONFIG_FILE.exists():
        return []
    try:
        config = json.loads(CONFIG_FILE.read_text())
        hooks = config.get("hooks", {})
        return hooks.get(event.value, [])
    except (json.JSONDecodeError, KeyError):
        return []


def register_hook(event: HookEvent, command: str) -> None:
    """Register a new hook for an event in config.json.

    Args:
        event: The hook event type.
        command: Shell command to execute.
    """
    config: dict[str, Any] = {}
    if CONFIG_FILE.exists():
        try:
            config = json.loads(CONFIG_FILE.read_text())
        except json.JSONDecodeError:
            config = {}

    hooks = config.setdefault("hooks", {})
    event_hooks: list[dict[str, str]] = hooks.setdefault(event.value, [])
    event_hooks.append({"command": command})

    CONFIG_FILE.write_text(json.dumps(config, indent=2))
    logger.info("hook_registered", hook_event=event.value, command=command[:50])


def list_hooks() -> dict[str, list[dict[str, str]]]:
    """List all registered hooks.

    Returns:
        Dict mapping event names to lists of hook dicts.
    """
    if not CONFIG_FILE.exists():
        return {}
    try:
        config = json.loads(CONFIG_FILE.read_text())
        return config.get("hooks", {})
    except (json.JSONDecodeError, KeyError):
        return {}
