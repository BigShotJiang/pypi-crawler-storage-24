"""Allow running as `python -m neo`."""

from neo.cli import cli

cli()
