"""Financial types for System R CLI.

Rule: Decimal for money, int for counts, str for IDs.

All financial values in System R use decimal.Decimal to prevent
floating-point rounding errors that can lose real money. These
types are the foundation — every module that handles prices,
risk amounts, or percentages imports from here.

Usage:
    from neo.types import Price, RiskAmount, Quantity, Percentage, to_decimal

    entry = Price("198.50")
    risk = RiskAmount("1046.80")
    shares = Quantity(160)
    risk_pct = Percentage("1.97")
"""

from __future__ import annotations

from decimal import Decimal, ROUND_HALF_UP
from typing import Union

# Type aliases for clarity and type checking.
# All are Decimal — the alias communicates intent.
Price = Decimal
RiskAmount = Decimal
Percentage = Decimal

# Quantity is int — shares, contracts, units. Never fractional.
Quantity = int

# Rounding contexts
PRICE_PLACES = Decimal("0.01")       # $198.50
RISK_PLACES = Decimal("0.01")        # $1046.80
PCT_PLACES = Decimal("0.01")         # 1.97%
R_MULTIPLE_PLACES = Decimal("0.01")  # +2.30R


def to_decimal(value: Union[str, int, float, Decimal]) -> Decimal:
    """Convert any numeric value to Decimal safely.

    Handles str, int, float, and Decimal inputs.
    Float is converted via string to avoid float representation errors.

    Args:
        value: The numeric value to convert.

    Returns:
        A Decimal representation of the value.

    Raises:
        InvalidOperation: If the value cannot be converted.
    """
    if isinstance(value, Decimal):
        return value
    if isinstance(value, float):
        # Convert float via string to avoid repr issues
        # e.g., float 0.1 -> "0.1" -> Decimal("0.1")
        return Decimal(str(value))
    return Decimal(value)


def round_price(value: Decimal) -> Decimal:
    """Round a price to 2 decimal places (standard for equities).

    Args:
        value: The price to round.

    Returns:
        Price rounded to nearest cent.
    """
    return value.quantize(PRICE_PLACES, rounding=ROUND_HALF_UP)


def round_risk(value: Decimal) -> Decimal:
    """Round a risk amount to 2 decimal places.

    Args:
        value: The risk amount to round.

    Returns:
        Risk amount rounded to nearest cent.
    """
    return value.quantize(RISK_PLACES, rounding=ROUND_HALF_UP)


def round_pct(value: Decimal) -> Decimal:
    """Round a percentage to 2 decimal places.

    Args:
        value: The percentage to round.

    Returns:
        Percentage rounded to 2 decimals (e.g., 1.97).
    """
    return value.quantize(PCT_PLACES, rounding=ROUND_HALF_UP)


def round_r(value: Decimal) -> Decimal:
    """Round an R-multiple to 2 decimal places.

    Args:
        value: The R-multiple to round.

    Returns:
        R-multiple rounded to 2 decimals (e.g., 2.30).
    """
    return value.quantize(R_MULTIPLE_PLACES, rounding=ROUND_HALF_UP)
