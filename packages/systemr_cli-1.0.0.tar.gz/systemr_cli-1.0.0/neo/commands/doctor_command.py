"""Doctor command — health check and diagnostic tool.

Checks: API connectivity, auth validity, profile completeness,
rules loaded, local DB integrity, credit balance, Python version.
Exit codes: 0=healthy, 1=errors, 2=warnings.

Inspired by OpenClaw's `openclaw doctor` + `openclaw status --deep`.
No bare print() — all output via Rich console. Logging via structlog.
"""

from __future__ import annotations

import sqlite3
import sys

import click
import structlog

from neo.auth import AuthManager
from neo.config import (
    DB_FILE,
    PROFILE_FILE,
    RULES_FILE,
    MEMORY_DIR,
    SYSTEMR_HOME,
    get_api_url,
)
from neo.display.theme import (
    AMBER,
    DIM,
    GREEN,
    GRAY,
    RED,
    WHITE,
    ICON_ERROR,
    ICON_SUCCESS,
    ICON_WARN,
    console,
    print_banner,
    print_separator,
)

logger = structlog.get_logger(module="doctor")


@click.command()
def doctor() -> None:
    """Run health checks on System R CLI."""
    print_banner()
    print_separator()
    console.print(f"  [{GRAY}]Running diagnostics...[/]\n")

    checks: list[tuple[str, str, str]] = []  # (name, status, detail)

    # 1. Python version
    v = sys.version_info
    if v >= (3, 11):
        checks.append(("Python version", "ok", f"{v.major}.{v.minor}.{v.micro}"))
    else:
        checks.append(("Python version", "error", f"{v.major}.{v.minor} (need >=3.11)"))

    # 2. SYSTEMR_HOME exists
    if SYSTEMR_HOME.exists():
        checks.append(("~/.systemr/ directory", "ok", str(SYSTEMR_HOME)))
    else:
        checks.append(("~/.systemr/ directory", "warn", "not created yet — run `systemr setup`"))

    # 3. API connectivity
    api_url = get_api_url()
    try:
        import httpx
        resp = httpx.get(f"{api_url}/health", timeout=5.0)
        if resp.status_code == 200:
            checks.append(("API connectivity", "ok", api_url))
        else:
            checks.append(("API connectivity", "error", f"{api_url} returned {resp.status_code}"))
    except Exception as exc:
        checks.append(("API connectivity", "error", f"{api_url} — {exc}"))

    # 4. Auth token
    auth = AuthManager()
    token = auth.get_token()
    if token is not None:
        checks.append(("Authentication", "ok", f"logged in as {token.email}"))
    else:
        checks.append(("Authentication", "error", "not authenticated — run `systemr login`"))

    # 5. Profile
    if PROFILE_FILE.exists():
        content = PROFILE_FILE.read_text()
        has_name = "Name:" in content and "(none)" not in content
        has_risk = "Max risk per trade:" in content
        if has_name and has_risk:
            checks.append(("Trader profile", "ok", "PROFILE.md complete"))
        else:
            checks.append(("Trader profile", "warn", "PROFILE.md incomplete — run `systemr setup`"))
    else:
        checks.append(("Trader profile", "warn", "no PROFILE.md — run `systemr setup`"))

    # 6. Rules
    if RULES_FILE.exists():
        content = RULES_FILE.read_text()
        if "(none set)" not in content:
            checks.append(("Trading rules", "ok", "RULES.md has rules defined"))
        else:
            checks.append(("Trading rules", "warn", "RULES.md has no rules — add via `systemr setup`"))
    else:
        checks.append(("Trading rules", "warn", "no RULES.md — run `systemr setup`"))

    # 7. Local DB integrity
    if DB_FILE.exists():
        try:
            conn = sqlite3.connect(str(DB_FILE))
            result = conn.execute("PRAGMA integrity_check").fetchone()
            conn.close()
            if result and result[0] == "ok":
                checks.append(("Journal database", "ok", "integrity check passed"))
            else:
                checks.append(("Journal database", "error", f"integrity check: {result}"))
        except Exception as exc:
            checks.append(("Journal database", "error", f"cannot open: {exc}"))
    else:
        checks.append(("Journal database", "warn", "no journal.db — will be created on first use"))

    # 8. Memory directory
    if MEMORY_DIR.exists():
        file_count = len(list(MEMORY_DIR.glob("*.md")))
        checks.append(("Memory files", "ok", f"{file_count} files in ~/.systemr/memory/"))
    else:
        checks.append(("Memory files", "warn", "memory directory not created yet"))

    # 9. Credit balance (only if authenticated)
    if token is not None:
        try:
            import httpx
            resp = httpx.get(
                f"{api_url}/v1/billing/balance",
                headers={"Authorization": f"Bearer {token.access_token}"},
                timeout=5.0,
            )
            if resp.status_code == 200:
                data = resp.json()
                balance = data.get("balance", data.get("credits", "unknown"))
                checks.append(("Credit balance", "ok", f"{balance} credits"))
            else:
                checks.append(("Credit balance", "warn", f"could not fetch (HTTP {resp.status_code})"))
        except Exception:
            checks.append(("Credit balance", "warn", "could not fetch balance"))

    # Display results
    errors = 0
    warnings = 0
    for name, status, detail in checks:
        if status == "ok":
            icon = f"[{GREEN}]{ICON_SUCCESS}[/]"
        elif status == "warn":
            icon = f"[{AMBER}]{ICON_WARN}[/]"
            warnings += 1
        else:
            icon = f"[{RED}]{ICON_ERROR}[/]"
            errors += 1
        console.print(f"  {icon} [{WHITE}]{name:<20}[/] [{DIM}]{detail}[/]")

    console.print()
    if errors > 0:
        console.print(f"  [{RED}]{errors} error(s)[/] [{DIM}]found. Fix before using System R.[/]")
    elif warnings > 0:
        console.print(f"  [{AMBER}]{warnings} warning(s)[/] [{DIM}]— System R will work but some features may be limited.[/]")
    else:
        console.print(f"  [{GREEN}]All checks passed.[/] [{DIM}]System R is ready.[/]")
    console.print()

    logger.info("doctor_complete", errors=errors, warnings=warnings)

    if errors > 0:
        raise SystemExit(1)
    if warnings > 0:
        raise SystemExit(2)
