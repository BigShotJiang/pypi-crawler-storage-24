"""Cron commands — manage scheduled tasks from the CLI.

Usage:
  systemr cron list           — show all scheduled jobs
  systemr cron add            — create a new job
  systemr cron remove <id>    — delete a job
  systemr cron run <id>       — force-run a job now
  systemr cron runs <id>      — show run history

No bare print() — all output via Rich console. Logging via structlog.
"""

from __future__ import annotations

import click
import structlog

from neo.cron import (
    CronJob,
    Schedule,
    ScheduleKind,
    add_job,
    get_job,
    get_runs,
    load_jobs,
    remove_job,
)
from neo.display.theme import (
    AMBER,
    DIM,
    GRAY,
    GREEN,
    RED,
    WHITE,
    ICON_ERROR,
    ICON_SUCCESS,
    console,
    print_error,
    print_success,
)

logger = structlog.get_logger(module="cron_commands")


@click.group()
def cron() -> None:
    """Manage scheduled tasks."""
    pass


@cron.command("list")
def cron_list() -> None:
    """List all scheduled jobs."""
    jobs = load_jobs()
    if not jobs:
        console.print(f"  [{DIM}]No scheduled tasks.[/]")
        console.print(f"  [{DIM}]Create one: systemr cron add --name 'Morning scan' --message 'Run morning briefing'[/]")
        return

    console.print()
    console.print(f"  [{GRAY}]Scheduled tasks ({len(jobs)})[/]")
    console.print()
    for j in jobs:
        status_icon = f"[{GREEN}]{ICON_SUCCESS}[/]" if j.enabled else f"[{DIM}]○[/]"
        kind = j.schedule.kind.value
        detail = ""
        if j.schedule.kind == ScheduleKind.AT and j.schedule.at:
            detail = j.schedule.at[:19]
        elif j.schedule.kind == ScheduleKind.EVERY and j.schedule.every_seconds:
            mins = j.schedule.every_seconds / 60
            detail = f"every {mins:.0f}m"
        elif j.schedule.kind == ScheduleKind.CRON and j.schedule.expr:
            detail = j.schedule.expr
            if j.schedule.tz:
                detail += f" ({j.schedule.tz})"

        console.print(
            f"  {status_icon} [{WHITE}]{j.name:<24}[/] "
            f"[{DIM}]{detail:<30}[/] "
            f"[{DIM}]runs: {j.run_count}[/]  "
            f"[{DIM}]{j.id}[/]"
        )
    console.print()


@cron.command()
@click.option("--name", required=True, help="Job name")
@click.option("--message", required=True, help="Prompt to send when job fires")
@click.option("--cron-expr", "expr", default=None, help="Cron expression (e.g., '0 7 * * 1-5')")
@click.option("--every", "every_seconds", type=float, default=None, help="Interval in seconds")
@click.option("--at", "at_time", default=None, help="ISO 8601 timestamp for one-shot")
@click.option("--tz", default=None, help="IANA timezone (e.g., 'America/New_York')")
@click.option("--model", default=None, help="Model override for this job")
def add(
    name: str,
    message: str,
    expr: str | None,
    every_seconds: float | None,
    at_time: str | None,
    tz: str | None,
    model: str | None,
) -> None:
    """Create a new scheduled job."""
    if expr:
        schedule = Schedule(kind=ScheduleKind.CRON, expr=expr, tz=tz)
        desc = f"cron: {expr}"
    elif every_seconds:
        schedule = Schedule(kind=ScheduleKind.EVERY, every_seconds=every_seconds)
        desc = f"every {every_seconds / 60:.0f}m"
    elif at_time:
        schedule = Schedule(kind=ScheduleKind.AT, at=at_time)
        desc = f"at: {at_time[:19]}"
    else:
        # Default: every 1 hour
        schedule = Schedule(kind=ScheduleKind.EVERY, every_seconds=3600)
        desc = "every 60m (default)"

    delete_after = schedule.kind == ScheduleKind.AT
    job = add_job(name, message, schedule, model=model, delete_after_run=delete_after)
    print_success(f"Created: {job.name} — {desc} ({job.id})")


@cron.command()
@click.argument("job_id")
def remove(job_id: str) -> None:
    """Remove a scheduled job by ID."""
    if remove_job(job_id):
        print_success(f"Removed: {job_id}")
    else:
        print_error(f"Job not found: {job_id}")


@cron.command()
@click.argument("job_id")
def run(job_id: str) -> None:
    """Force-run a job now (sends its message to the backend)."""
    job = get_job(job_id)
    if not job:
        print_error(f"Job not found: {job_id}")
        return
    console.print(f"  [{GRAY}]Running:[/] [{WHITE}]{job.name}[/]")
    console.print(f"  [{DIM}]Message: {job.message[:80]}[/]")
    console.print(f"  [{AMBER}]Note: Manual run queued. Use `systemr chat` to see results.[/]")
    logger.info("cron_manual_run", job_id=job_id, name=job.name)


@cron.command()
@click.argument("job_id")
@click.option("--limit", default=20, help="Max records to show")
def runs(job_id: str, limit: int) -> None:
    """Show run history for a job."""
    job = get_job(job_id)
    if not job:
        print_error(f"Job not found: {job_id}")
        return

    records = get_runs(job_id, limit=limit)
    if not records:
        console.print(f"  [{DIM}]No runs recorded for {job.name}[/]")
        return

    console.print()
    console.print(f"  [{GRAY}]Run history: {job.name} (last {len(records)})[/]")
    console.print()
    for r in records:
        status = r.get("status", "unknown")
        if status == "ok":
            icon = f"[{GREEN}]{ICON_SUCCESS}[/]"
        else:
            icon = f"[{RED}]{ICON_ERROR}[/]"
        run_at = r.get("run_at", "")[:19]
        duration = r.get("duration_seconds", 0)
        msg = r.get("message", "")
        console.print(
            f"  {icon} [{WHITE}]{run_at}[/]  "
            f"[{DIM}]{duration:.1f}s[/]  "
            f"[{DIM}]{msg[:60]}[/]" if msg else f"  {icon} [{WHITE}]{run_at}[/]  [{DIM}]{duration:.1f}s[/]"
        )
    console.print()
