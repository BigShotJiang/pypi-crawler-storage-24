"""Trade evaluation command — neo eval."""

from __future__ import annotations

import asyncio

import click

from neo.auth import AuthManager
from neo.client import AuthRequired, NeoClient
from neo.display.formatters import fmt_r
from neo.display.tables import kv_table
from neo.display.theme import console, print_error, GREEN, GREEN_DIM


@click.command()
@click.argument("r_multiples", nargs=-1, type=float, required=True)
@click.option("--tier", type=click.Choice(["basic", "full", "pro"]), default="basic", help="Evaluation tier")
def eval(r_multiples: tuple[float, ...], tier: str) -> None:
    """Evaluate a series of R-multiples.

    Example: neo eval 1.5 -1.0 2.3 0.8 -1.0
    """
    auth = AuthManager()
    client = NeoClient(auth)

    payload = {
        "r_multiples": list(r_multiples),
    }

    try:
        with console.status(f"[{GREEN_DIM}]Processing...[/]"):
            result = asyncio.run(client.post(f"/v1/eval/{tier}", json=payload))
    except AuthRequired:
        print_error("Not authenticated. Run `neo login` first.")
        raise SystemExit(1)
    except Exception as e:
        print_error(f"Evaluation failed: {e}")
        raise SystemExit(1)

    # Display results
    total_r = sum(r_multiples)
    win_count = sum(1 for r in r_multiples if r > 0)
    loss_count = sum(1 for r in r_multiples if r <= 0)
    win_rate = win_count / len(r_multiples) * 100 if r_multiples else 0

    display_data = {
        "Trades": str(len(r_multiples)),
        "Wins": str(win_count),
        "Losses": str(loss_count),
        "Win Rate": f"{win_rate:.1f}%",
        "Total R": fmt_r(total_r),
        "Avg R": fmt_r(total_r / len(r_multiples)) if r_multiples else "0.00R",
    }

    # Add API-provided metrics
    if "expectancy" in result:
        display_data["Expectancy"] = fmt_r(result["expectancy"])
    if "g_score" in result:
        score = result["g_score"]
        style = f"bold {GREEN}" if score >= 50 else "bold red"
        display_data["G-Score"] = f"[{style}]{score:.1f}[/]"
    if "edge_ratio" in result:
        display_data["Edge Ratio"] = f"{result['edge_ratio']:.2f}"

    kv_table("TRADE EVALUATION", display_data)

    # R-multiple sequence
    r_display = " ".join(
        f"[bold green]{fmt_r(r)}[/]" if r > 0 else f"[bold red]{fmt_r(r)}[/]"
        for r in r_multiples
    )
    console.print(f"\n  Sequence: {r_display}")
