"""Auth commands — register, login, verify, pay, logout, whoami.

Complete onboarding from the terminal:
  systemr register  → create account (email + password)
  systemr verify    → confirm email with 6-digit code
  systemr pay       → open Stripe checkout in browser for credits
  systemr login     → authenticate existing account
  systemr logout    → clear credentials
  systemr whoami    → show current user + balance

Payment MUST happen in a browser (credit card / crypto wallet).
The CLI generates the Stripe checkout URL and opens it automatically.

No bare print() — all output via Rich console. Logging via structlog.
"""

from __future__ import annotations

import asyncio
import webbrowser

import click
import httpx
import structlog

from neo.auth import AuthManager
from neo.config import get_api_url
from neo.display.theme import (
    AMBER,
    DIM,
    GRAY,
    GREEN,
    GREEN_DIM,
    MUTED,
    RED,
    WHITE,
    console,
    print_error,
    print_info,
    print_success,
    print_warn,
)

logger = structlog.get_logger(module="auth_commands")

APP_URL = "https://app.systemr.ai"


@click.command()
@click.option("--email", prompt="Email", help="Your System R email")
@click.option("--password", prompt=True, hide_input=True, help="Your password")
def login(email: str, password: str) -> None:
    """Authenticate with System R."""
    auth = AuthManager()
    try:
        with console.status(f"[{GREEN_DIM}]Connecting...[/]"):
            token = asyncio.run(auth.login(email, password))
        print_success(f"Connected as [{GREEN}]{token.email}[/]")
    except Exception as e:
        print_error(f"Login failed: {e}")
        console.print(f"  [{DIM}]No account? Run `systemr register` to create one.[/]")
        console.print(f"  [{DIM}]Or sign up at {APP_URL}[/]")
        raise SystemExit(1)


@click.command()
@click.option("--email", prompt="Email", help="Your email address")
@click.option("--password", prompt=True, hide_input=True, confirmation_prompt=True, help="Choose a password")
@click.option("--name", prompt="Name", default="", help="Your name (optional)")
def register(email: str, password: str, name: str) -> None:
    """Create a new System R account from the terminal.

    After registration, you'll need to:
    1. Verify your email (systemr verify)
    2. Add credits (systemr pay)
    3. Set up your profile (systemr setup)
    """
    auth = AuthManager()
    console.print()
    try:
        with console.status(f"[{GREEN_DIM}]Creating account...[/]"):
            token = asyncio.run(auth.register(email, password, name))
        print_success(f"Account created! Connected as [{GREEN}]{token.email}[/]")
        console.print()
        console.print(f"  [{WHITE}]Next steps:[/]")
        console.print(f"    [{GREEN}]1.[/] [{GRAY}]systemr verify    — confirm your email (check inbox for 6-digit code)[/]")
        console.print(f"    [{GREEN}]2.[/] [{GRAY}]systemr pay       — add compute credits (opens browser)[/]")
        console.print(f"    [{GREEN}]3.[/] [{GRAY}]systemr setup     — create your trading profile[/]")
        console.print(f"    [{GREEN}]4.[/] [{GRAY}]systemr chat      — start trading[/]")
        console.print()
    except Exception as e:
        error_msg = str(e)
        if "409" in error_msg or "exist" in error_msg.lower() or "already" in error_msg.lower():
            print_error("Email already registered. Run `systemr login` instead.")
        else:
            print_error(f"Registration failed: {e}")
            console.print(f"  [{DIM}]Try signing up at {APP_URL}[/]")
        raise SystemExit(1)


@click.command()
@click.option("--code", prompt="Verification code", help="6-digit code from your email")
def verify(code: str) -> None:
    """Verify your email with the 6-digit code sent to your inbox."""
    auth = AuthManager()
    token = auth.get_token()
    if token is None:
        print_error("Not connected. Run `systemr login` first.")
        raise SystemExit(1)

    api_url = get_api_url()
    try:
        resp = httpx.post(
            f"{api_url}/api/auth/verify-email/confirm",
            json={"code": code},
            headers={"Authorization": f"Bearer {token.access_token}"},
            timeout=15.0,
        )
        if resp.status_code in (200, 204):
            print_success("Email verified!")
            console.print(f"  [{DIM}]Next: run `systemr pay` to add credits.[/]")
        else:
            data = resp.json() if resp.headers.get("content-type", "").startswith("application/json") else {}
            print_error(f"Verification failed: {data.get('detail', resp.status_code)}")
    except Exception as e:
        print_error(f"Verification failed: {e}")


@click.command()
def pay() -> None:
    """Add compute credits — card (Stripe) or crypto (send to wallet).

    Two payment paths:
      1. Card/stablecoin via Stripe — opens browser
      2. Crypto (SOL, OSR, USDC, USDT, PYUSD) — send to treasury wallet,
         auto-credited via Helius webhook (~30s after confirmation)

    Link your wallet first with `systemr link-wallet` for auto-credit.
    """
    auth = AuthManager()
    token = auth.get_token()
    if token is None:
        print_error("Not connected. Run `systemr login` first.")
        raise SystemExit(1)

    api_url = get_api_url()
    console.print()
    console.print(f"  [{WHITE}]Add Compute Credits[/]")
    console.print(f"  [{DIM}]Credits power every tool call. Pricing: $0.002–$2.00 per call.[/]")
    console.print()
    console.print(f"    [{WHITE}]1.[/] [{GRAY}]Card / stablecoin (Stripe) — opens browser[/]")
    console.print(f"    [{WHITE}]2.[/] [{GRAY}]Crypto (SOL, OSR, USDC, USDT, PYUSD) — send to wallet[/]")
    console.print()

    choice = click.prompt(
        click.style("  Select", fg="white"),
        type=click.Choice(["1", "2"]),
        show_choices=False,
    )

    if choice == "1":
        # Stripe path — open billing page in browser
        billing_url = f"{APP_URL}/billing"
        print_success("Opening billing page...")
        console.print(f"  [{DIM}]If browser doesn't open:[/] [{GREEN_DIM}]{billing_url}[/]")
        webbrowser.open(billing_url)
        console.print()
        console.print(f"  [{DIM}]After payment, run `systemr balance` to verify.[/]")
        console.print()

    elif choice == "2":
        # Crypto path — show treasury wallet + accepted tokens
        # Try to fetch treasury info from backend
        treasury_wallet = "9Nc6u9ft3uAr6DSaqHijFjQS53hZPDRL2LoVYvH4vK5H"
        try:
            resp = httpx.get(f"{api_url}/v1/crypto/treasury", timeout=5.0)
            if resp.status_code == 200:
                data = resp.json()
                treasury_wallet = data.get("wallet", treasury_wallet)
        except Exception:
            pass

        console.print()
        console.print(f"  [{WHITE}]Send crypto to our Solana treasury wallet:[/]")
        console.print()
        console.print(f"    [{GREEN}]{treasury_wallet}[/]")
        console.print(f"    [{DIM}]Network: Solana Mainnet[/]")
        console.print()
        console.print(f"  [{WHITE}]Accepted tokens:[/]")
        console.print(f"    [{WHITE}]USDC[/]   [{DIM}]1:1 credit[/]")
        console.print(f"    [{WHITE}]USDT[/]   [{DIM}]1:1 credit[/]")
        console.print(f"    [{WHITE}]PYUSD[/]  [{DIM}]1:1 credit[/]")
        console.print(f"    [{WHITE}]SOL[/]    [{DIM}]live market price[/]")
        console.print(f"    [{WHITE}]OSR[/]    [{DIM}]$0.005/token ($0.004 presale)[/]")
        console.print()
        console.print(f"  [{GREEN}]Credits appear automatically after confirmation (~30s).[/]")
        console.print()
        console.print(f"  [{AMBER}]Important:[/] [{GRAY}]Link your wallet first so we know who to credit:[/]")
        console.print(f"    [{WHITE}]systemr link-wallet <your-solana-pubkey>[/]")
        console.print()
        console.print(f"  [{DIM}]Check balance anytime: systemr balance[/]")
        console.print()


@click.command("link-wallet")
@click.argument("wallet_address")
def link_wallet(wallet_address: str) -> None:
    """Link your Solana wallet for automatic crypto credit.

    After linking, any SOL/OSR/USDC/USDT/PYUSD sent from this wallet
    to the System R treasury will be automatically credited to your account
    via Helius webhook (~30s after confirmation).
    """
    auth = AuthManager()
    token = auth.get_token()
    if token is None:
        print_error("Not connected. Run `systemr login` first.")
        raise SystemExit(1)

    # Basic validation — Solana pubkeys are 32-44 base58 chars
    if len(wallet_address) < 32 or len(wallet_address) > 44:
        print_error("Invalid Solana wallet address. Must be 32-44 characters (base58).")
        raise SystemExit(1)

    api_url = get_api_url()
    try:
        with console.status(f"[{GREEN_DIM}]Linking wallet...[/]"):
            resp = httpx.post(
                f"{api_url}/v1/agents/link-wallet",
                json={"wallet_address": wallet_address},
                headers={"Authorization": f"Bearer {token.access_token}"},
                timeout=15.0,
            )
            resp.raise_for_status()

        print_success(f"Wallet linked: [{GREEN}]{wallet_address[:8]}...{wallet_address[-4:]}[/]")
        console.print()
        console.print(f"  [{DIM}]Now send crypto to the treasury wallet and credits[/]")
        console.print(f"  [{DIM}]will appear automatically. Run `systemr pay` to see the address.[/]")
        console.print()
    except Exception as e:
        print_error(f"Failed to link wallet: {e}")
        console.print(f"  [{DIM}]You can also link at {APP_URL}/settings[/]")


@click.command()
def balance() -> None:
    """Check your compute credit balance."""
    auth = AuthManager()
    token = auth.get_token()
    if token is None:
        print_error("Not connected. Run `systemr login` first.")
        raise SystemExit(1)

    api_url = get_api_url()
    try:
        resp = httpx.get(
            f"{api_url}/api/portal/balance",
            headers={"Authorization": f"Bearer {token.access_token}"},
            timeout=10.0,
        )
        resp.raise_for_status()
        data = resp.json()
        bal = data.get("balance", "0.00")
        console.print(f"  [{GREEN}]●[/] [{WHITE}]${bal}[/] [{GRAY}]credits[/]")
        if float(bal) < 1.0:
            print_warn(f"Low balance. Run `systemr pay` to add credits.")
    except Exception as e:
        print_error(f"Could not fetch balance: {e}")


@click.command()
def logout() -> None:
    """Clear stored credentials."""
    auth = AuthManager()
    auth.clear()
    print_success("Disconnected")


@click.command()
def whoami() -> None:
    """Show current authenticated user and balance."""
    auth = AuthManager()
    token = auth.get_token()
    if token is None:
        print_error("Not connected. Run `systemr login` or `systemr register`.")
        raise SystemExit(1)
    console.print(f"  [{GREEN}]●[/] [{GREEN}]{token.email}[/]")

    # Also show balance
    api_url = get_api_url()
    try:
        resp = httpx.get(
            f"{api_url}/api/portal/balance",
            headers={"Authorization": f"Bearer {token.access_token}"},
            timeout=5.0,
        )
        if resp.status_code == 200:
            data = resp.json()
            bal = data.get("balance", "?")
            console.print(f"  [{DIM}]${bal} credits[/]")
    except Exception:
        pass
