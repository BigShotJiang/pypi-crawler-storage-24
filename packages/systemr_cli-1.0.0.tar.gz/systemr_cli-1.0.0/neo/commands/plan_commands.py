"""Plan command — neo plan (trade plan generation)."""

from __future__ import annotations

import asyncio

import click

from neo.auth import AuthManager
from neo.client import AuthRequired, NeoClient
from neo.display.formatters import fmt_price, fmt_pct, fmt_risk, fmt_qty
from neo.display.tables import kv_table
from neo.display.theme import console, print_error, GREEN


@click.command()
@click.option("--ticker", required=True, help="Ticker symbol")
@click.option("--equity", required=True, type=float, help="Account equity ($)")
@click.option("--risk-pct", type=float, default=1.0, help="Risk per trade (%, default 1.0)")
@click.option("--direction", type=click.Choice(["long", "short"]), default=None, help="Force direction (auto-detect if omitted)")
def plan(ticker: str, equity: float, risk_pct: float, direction: str | None) -> None:
    """Generate a complete trade plan for a ticker."""
    auth = AuthManager()
    client = NeoClient(auth)

    payload: dict = {
        "ticker": ticker.upper(),
        "equity": equity,
        "risk_percent": risk_pct,
    }
    if direction:
        payload["direction"] = direction

    try:
        with console.status(f"[neo.green]Building plan for {ticker.upper()}...[/]"):
            result = asyncio.run(client.post("/api/plans", json=payload))
    except AuthRequired:
        print_error("Not authenticated. Run `neo login` first.")
        raise SystemExit(1)
    except Exception as e:
        print_error(f"Plan generation failed: {e}")
        raise SystemExit(1)

    # Display the plan
    data: dict[str, str] = {"Ticker": ticker.upper()}

    dir_val = result.get("direction", direction or "—")
    dir_style = f"bold {GREEN}" if dir_val == "long" else "bold red"
    data["Direction"] = f"[{dir_style}]{dir_val.upper()}[/]"

    if "entry" in result:
        data["Entry"] = fmt_price(result["entry"])
    if "stop" in result:
        data["Stop"] = fmt_price(result["stop"])
    if "target" in result:
        data["Target"] = fmt_price(result["target"])
    if "risk_per_share" in result:
        data["Risk/Share"] = fmt_price(result["risk_per_share"])
    if "risk_amount" in result:
        data["Risk Amount"] = fmt_risk(result["risk_amount"])
    if "shares" in result:
        data["Shares"] = fmt_qty(result["shares"])
    if "position_value" in result:
        data["Position Value"] = fmt_price(result["position_value"])
    if "reward_risk" in result:
        data["Reward:Risk"] = f"{result['reward_risk']:.2f}"
    if "confidence" in result:
        data["Confidence"] = fmt_pct(result["confidence"])

    kv_table(f"TRADE PLAN — {ticker.upper()}", data)

    # Show rationale if provided
    if "rationale" in result:
        console.print(f"\n[bold]Rationale:[/] {result['rationale']}")
    if "notes" in result:
        for note in result["notes"]:
            console.print(f"  [neo.dim]•[/] {note}")
