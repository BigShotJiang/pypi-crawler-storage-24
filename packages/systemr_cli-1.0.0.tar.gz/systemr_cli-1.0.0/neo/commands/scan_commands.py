"""Scan command — neo scan SYMBOL."""

from __future__ import annotations

import asyncio

import click

from neo.auth import AuthManager
from neo.client import AuthRequired, NeoClient
from neo.display.formatters import fmt_price, fmt_pct
from neo.display.tables import kv_table
from neo.display.theme import console, print_error


@click.command()
@click.argument("symbol")
@click.option("--scanner", default="default", help="Scanner ID to use")
def scan(symbol: str, scanner: str) -> None:
    """Scan a symbol for trading signals."""
    auth = AuthManager()
    client = NeoClient(auth)

    try:
        with console.status(f"[neo.green]Scanning {symbol.upper()}...[/]"):
            result = asyncio.run(
                client.post(
                    f"/api/scanners/{scanner}/scan",
                    json={"symbol": symbol.upper()},
                )
            )
    except AuthRequired:
        print_error("Not authenticated. Run `neo login` first.")
        raise SystemExit(1)
    except Exception as e:
        print_error(f"Scan failed: {e}")
        raise SystemExit(1)

    # Build display from response
    data: dict[str, str] = {"Symbol": symbol.upper()}

    if "price" in result:
        data["Price"] = fmt_price(result["price"])
    if "change_pct" in result:
        pct = result["change_pct"]
        style = "bold green" if pct >= 0 else "bold red"
        data["Change"] = f"[{style}]{fmt_pct(pct)}[/]"
    if "trend" in result:
        data["Trend"] = result["trend"]
    if "signals" in result:
        for sig in result["signals"]:
            name = sig.get("name", "Signal")
            value = sig.get("value", sig.get("direction", "—"))
            data[name] = str(value)
    if "support" in result:
        data["Support"] = fmt_price(result["support"])
    if "resistance" in result:
        data["Resistance"] = fmt_price(result["resistance"])
    if "score" in result:
        data["Score"] = str(result["score"])

    kv_table(f"SCAN — {symbol.upper()}", data)
