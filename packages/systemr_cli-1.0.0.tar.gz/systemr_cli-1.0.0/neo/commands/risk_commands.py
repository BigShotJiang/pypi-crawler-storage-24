"""Risk check command — neo risk."""

from __future__ import annotations

import asyncio

import click

from neo.auth import AuthManager
from neo.client import AuthRequired, NeoClient
from neo.display.formatters import fmt_price, fmt_pct, fmt_risk
from neo.display.tables import kv_table
from neo.display.theme import console, print_error, GREEN, GREEN_DIM


@click.command()
@click.option("--symbol", required=True, help="Ticker symbol")
@click.option("--entry", required=True, type=float, help="Entry price")
@click.option("--stop", required=True, type=float, help="Stop loss price")
@click.option("--qty", required=True, type=int, help="Number of shares")
@click.option("--equity", required=True, type=float, help="Account equity ($)")
def risk(symbol: str, entry: float, stop: float, qty: int, equity: float) -> None:
    """Check risk metrics for a trade."""
    auth = AuthManager()
    client = NeoClient(auth)

    payload = {
        "symbol": symbol.upper(),
        "entry_price": entry,
        "stop_price": stop,
        "quantity": qty,
        "equity": equity,
    }

    try:
        with console.status(f"[{GREEN_DIM}]Analyzing risk...[/]"):
            result = asyncio.run(client.post("/v1/risk/check", json=payload))
    except AuthRequired:
        print_error("Not authenticated. Run `neo login` first.")
        raise SystemExit(1)
    except Exception as e:
        print_error(f"Risk check failed: {e}")
        raise SystemExit(1)

    risk_per_share = abs(entry - stop)
    total_risk = risk_per_share * qty
    risk_pct = (total_risk / equity * 100) if equity else 0
    position_value = entry * qty

    status = result.get("status", "PASS" if risk_pct <= 2.0 else "FAIL")
    status_style = f"bold {GREEN}" if status == "PASS" else "bold red"

    kv_table(f"RISK CHECK — {symbol.upper()}", {
        "Status": f"[{status_style}]{status}[/]",
        "Entry": fmt_price(entry),
        "Stop": fmt_price(stop),
        "Quantity": str(qty),
        "Risk/Share": fmt_price(risk_per_share),
        "Total Risk": fmt_risk(total_risk),
        "Risk % of Equity": fmt_pct(risk_pct),
        "Position Value": fmt_price(position_value),
        "Position % of Equity": fmt_pct(position_value / equity * 100 if equity else 0),
    })

    # Show any warnings from the API
    warnings = result.get("warnings", [])
    for w in warnings:
        console.print(f"  [neo.warn]![/] {w}")
