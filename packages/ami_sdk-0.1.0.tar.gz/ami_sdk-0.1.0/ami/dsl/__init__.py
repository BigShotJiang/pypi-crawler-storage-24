"""
DSL (Domain Specific Language) module for EMU trigger validation.

This module provides local validation of trigger expressions before
sending them to the AMI API, enabling faster feedback during development.
"""

from .validator import (
    validate_trigger,
    validate_emu,
    DSLSyntaxError,
    DSLValidationError,
)
from .parser import (
    tokenize,
    Token,
    TokenType,
)

__all__ = [
    # Validation
    "validate_trigger",
    "validate_emu",
    "DSLSyntaxError",
    "DSLValidationError",
    # Parsing
    "tokenize",
    "Token",
    "TokenType",
]
