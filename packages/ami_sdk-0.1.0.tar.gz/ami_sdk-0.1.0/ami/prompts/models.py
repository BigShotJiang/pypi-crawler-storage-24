"""
Prompt Registry models for the AMI SDK.

Request and response dataclasses for interacting with the Prompt Registry API.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


# =============================================================================
# Request Models
# =============================================================================


@dataclass
class PromptCreate:
    """
    Request model for creating a new prompt.

    Attributes:
        slug: URL-safe identifier (2-64 chars, lowercase alphanumeric + hyphens)
        name: Human-readable display name
        content: Prompt template content with {{variable}} placeholders
        folder_path: Optional folder path (e.g., "onboarding/tier-1")
        description: Optional description (max 1024 chars)
        category: Optional category (e.g., "system", "user", "assistant")
        model: Optional target LLM model
        max_tokens: Optional token budget
        max_length: Optional character limit
        tags: Optional list of tags for categorization

    Example:
        ```python
        prompt = PromptCreate(
            slug="welcome-email",
            name="Welcome Email",
            content="Hello {{user_name}}, welcome to {{company}}!",
            category="system",
            tags=["email", "onboarding"],
        )
        ```
    """

    slug: str
    name: str
    content: str
    folder_path: Optional[str] = None
    description: Optional[str] = None
    category: Optional[str] = None
    model: Optional[str] = None
    max_tokens: Optional[int] = None
    max_length: Optional[int] = None
    temperature: Optional[float] = None
    tags: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dict, excluding None values."""
        result = {
            "slug": self.slug,
            "name": self.name,
            "content": self.content,
        }
        if self.folder_path is not None:
            result["folder_path"] = self.folder_path
        if self.description is not None:
            result["description"] = self.description
        if self.category is not None:
            result["category"] = self.category
        if self.model is not None:
            result["model"] = self.model
        if self.max_tokens is not None:
            result["max_tokens"] = self.max_tokens
        if self.max_length is not None:
            result["max_length"] = self.max_length
        if self.temperature is not None:
            result["temperature"] = self.temperature
        if self.tags:
            result["tags"] = self.tags
        return result


@dataclass
class PromptUpdate:
    """
    Request model for updating a prompt.

    All fields are optional - only specified fields are updated.
    A new version is created automatically.

    Attributes:
        name: New display name
        content: New prompt template content
        description: New description
        category: New category
        model: New target model
        max_tokens: New token budget
        max_length: New character limit
        tags: New tags list (replaces existing)
        change_reason: Optional reason for the change (audit trail)

    Example:
        ```python
        update = PromptUpdate(
            content="Updated template: Hello {{user_name}}!",
            change_reason="Simplified greeting",
        )
        ```
    """

    name: Optional[str] = None
    content: Optional[str] = None
    description: Optional[str] = None
    category: Optional[str] = None
    model: Optional[str] = None
    max_tokens: Optional[int] = None
    max_length: Optional[int] = None
    tags: Optional[List[str]] = None
    change_reason: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dict, excluding None values."""
        result: Dict[str, Any] = {}
        if self.name is not None:
            result["name"] = self.name
        if self.content is not None:
            result["content"] = self.content
        if self.description is not None:
            result["description"] = self.description
        if self.category is not None:
            result["category"] = self.category
        if self.model is not None:
            result["model"] = self.model
        if self.max_tokens is not None:
            result["max_tokens"] = self.max_tokens
        if self.max_length is not None:
            result["max_length"] = self.max_length
        if self.tags is not None:
            result["tags"] = self.tags
        if self.change_reason is not None:
            result["change_reason"] = self.change_reason
        return result


@dataclass
class PromptMove:
    """
    Request model for moving a prompt to a different folder.

    Attributes:
        folder_path: Target folder path, or None to move to root

    Example:
        ```python
        move = PromptMove(folder_path="archive/2024")
        client.move_prompt("old-prompt", move, workspace="dev", project="prompts")
        ```
    """

    folder_path: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dict."""
        return {"folder_path": self.folder_path}


@dataclass
class FolderCreate:
    """
    Request model for creating a prompt folder.

    Attributes:
        name: Display name for the folder
        path: Full path including parent folders (e.g., "support/tier-1")

    Example:
        ```python
        folder = FolderCreate(name="tier-1", path="support/tier-1")
        client.create_prompt_folder(folder, workspace="dev", project="prompts")
        ```
    """

    name: str
    path: str

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dict."""
        return {"name": self.name, "path": self.path}
