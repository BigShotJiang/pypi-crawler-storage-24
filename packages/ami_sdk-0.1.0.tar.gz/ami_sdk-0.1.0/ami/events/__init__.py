"""Event ingestion utilities."""
