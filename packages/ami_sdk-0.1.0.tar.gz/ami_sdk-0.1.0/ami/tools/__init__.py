"""
AMI Tool Registry - Unified tool registration and execution framework.

This module provides:
- ToolRegistry: Central registry for tool definitions with auto-discovery
- ActionExecutor: Lifecycle-aware execution of EMU actions
- ClaudeBridge: Claude Agent SDK integration

Code is the single source of truth for tools. Define tools in code,
register them with the platform, and the UI displays them (read-only).

Basic Example:
    ```python
    from ami.tools import ToolRegistry, ActionExecutor, ShadowMode

    # Create registry and register tools
    registry = ToolRegistry()

    @registry.tool("send_email", "Send email", {"to": str, "subject": str})
    async def send_email(args: dict) -> dict:
        return {"sent": True}

    # Create executor with lifecycle support
    executor = ActionExecutor(registry)
    executor.configure_shadow(ShadowMode.EXECUTE_AND_COMPARE)

    # Execute decisions
    results = await executor.execute_decisions(decisions)
    ```

Auto-Discovery Example:
    ```python
    from ami.tools import ToolRegistry

    # Auto-discover all @tool handlers in your project
    registry = ToolRegistry().discover(package="my_app.tools")

    # Or auto-detect from current directory
    registry = ToolRegistry().discover()
    ```

CLI Usage:
    ```bash
    # List discovered tools
    ami tool-list

    # Register tools with the platform
    ami tool-register -w production -j my-agent

    # Export schema locally
    ami tool-export -o .ami/tools_schema.json
    ```
"""

# Models
from ami.tools.models import (
    ActionHandlers,
    AckResult,
    CanaryConfig,
    Decision,
    ExecutionMetricsSample,
    ExecutionResult,
    ExecutorConfig,
    ExecutorSchema,
    InvokeAndExecuteResult,
    LifecycleMetrics,
    LifecycleState,
    MissingToolBehavior,
    RetryPolicy,
    ShadowComparisonResult,
    ShadowConfig,
    ShadowMode,
    ToolDefinition,
    make_sticky_decider,
)

# Registry
from ami.tools.registry import ToolRegistry

# Executor
from ami.tools.executor import ActionExecutor, MetricsCollector

# Claude Integration
from ami.tools.claude import ClaudeBridge, create_mcp_tool_handler


# Signature Validation
from ami.tools.signature_validation import (
    HandlerSignatureValidator,
    SignatureValidationError,
    SignatureValidationResult,
    validate_handler_signature,
)

# Configuration
from ami.tools.config import (
    AMIToolConfig,
    ToolConfigError,
    load_config,
    find_project_root,
)

# Idempotency Key Resolution
from ami.tools.idempotency import (
    IdempotencyKeyError,
    resolve_idempotency_key,
    generate_default_idempotency_key,
    validate_idempotency_template,
)

# Rate Limiting
from ami.tools.rate_limiter import (
    RateLimiter,
    RateLimiterBackend,
    InMemoryRateLimiter,
    RateLimitSpec,
    RateLimitResult,
    RateLimitError,
    RateLimitExceeded,
    parse_rate_limit,
    validate_rate_limit,
)


# Circuit Breaker
from ami.tools.circuit_breaker import (
    CircuitBreaker,
    CircuitBreakerConfig,
    CircuitBreakerRegistry,
    CircuitOpenError,
    CircuitState,
    CircuitStats,
)

# Schema Validation
from ami.tools.schema_validation import (
    SchemaValidationError,
    validate_args,
)

__all__ = [
    # Models
    "ToolDefinition",
    "ActionHandlers",
    "Decision",
    "ExecutionResult",
    "AckResult",
    "InvokeAndExecuteResult",
    "ExecutorConfig",
    "ShadowConfig",
    "CanaryConfig",
    "ExecutorSchema",
    # Lifecycle Metrics (FR3.9)
    "LifecycleMetrics",
    "ExecutionMetricsSample",
    "ShadowComparisonResult",
    # Sticky Sessions (FR3.7)
    "make_sticky_decider",
    # Enums
    "ShadowMode",
    "LifecycleState",
    "MissingToolBehavior",
    "RetryPolicy",
    # Registry
    "ToolRegistry",
    # Executor
    "ActionExecutor",
    "MetricsCollector",
    # Claude Integration
    "ClaudeBridge",
    "create_mcp_tool_handler",
    # Signature Validation
    "HandlerSignatureValidator",
    "SignatureValidationError",
    "SignatureValidationResult",
    "validate_handler_signature",
    # Configuration
    "AMIToolConfig",
    "ToolConfigError",
    "load_config",
    "find_project_root",
    # Idempotency
    "IdempotencyKeyError",
    "resolve_idempotency_key",
    "generate_default_idempotency_key",
    "validate_idempotency_template",
    # Rate Limiting
    "RateLimiter",
    "RateLimiterBackend",
    "InMemoryRateLimiter",
    "RateLimitSpec",
    "RateLimitResult",
    "RateLimitError",
    "RateLimitExceeded",
    "parse_rate_limit",
    "validate_rate_limit",
    # Circuit Breaker
    "CircuitBreaker",
    "CircuitBreakerConfig",
    "CircuitBreakerRegistry",
    "CircuitOpenError",
    "CircuitState",
    "CircuitStats",
    # Schema Validation
    "SchemaValidationError",
    "validate_args",
]
