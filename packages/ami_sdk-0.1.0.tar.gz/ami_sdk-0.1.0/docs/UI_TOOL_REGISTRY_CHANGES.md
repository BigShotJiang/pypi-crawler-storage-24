# UI Tool Registry Changes Required

## Context

The SDK has been refactored to make **code the single source of truth** for tools. This eliminates the complexity of two-way sync between code and UI.

**Previous flow (complex):**
```
Code ←→ UI (both can add tools) ←→ Drift detection needed
```

**New flow (simple):**
```
Code (@tool) → ami tool-register → UI displays (read-only)
```

## SDK Changes (Already Done)

- Removed `ami tool-verify` command
- Removed schema drift detection (`schema_drift.py`)
- Removed verification logic (`verification.py`)
- SDK now only pushes schemas to platform via `ami tool-register`

## UI Changes Required

### 1. Remove "Add Tool" Functionality

Remove the ability to manually create tools in the Tool Registry UI.

**Before:** Users can click "Add Tool" and define tools in the UI
**After:** Tool list is populated only from SDK uploads

### 2. Make Tool Registry Read-Only

The Tool Registry page should display tools from the uploaded schema without edit capabilities.

| Field | Editable? |
|-------|-----------|
| Tool name | No (from schema) |
| Description | No (from schema) |
| Input schema | No (from schema) |
| Capabilities | No (from schema) |
| Constraints | No (from schema) |

### 3. Keep Accepting Schema Uploads

The existing API endpoint should continue working:

```
POST /v1/workspaces/{workspace_id}/projects/{project_id}/executor-schema
```

**Request body:**
```json
{
  "name": "project-tools",
  "version": "1.0.0",
  "schema": {
    "version": "1.0.0",
    "server_name": "my-agent",
    "generated_at": "2024-01-15T10:30:00Z",
    "tools": {
      "send_email": {
        "name": "send_email",
        "description": "Send an email",
        "input_schema": {
          "type": "object",
          "properties": {
            "to": {"type": "string"},
            "subject": {"type": "string"}
          },
          "required": ["to", "subject"]
        },
        "has_handler": true,
        "capabilities": ["communication"],
        "constraints": []
      }
    },
    "action_handlers": {
      "tool_call": true,
      "route": false,
      "decision_prompt": false
    }
  }
}
```

### 4. UI Display Requirements

Show the following for each tool:

- **Name**: Tool identifier
- **Description**: Human-readable description
- **Input Schema**: JSON schema (collapsible/expandable)
- **Has Handler**: Badge showing if SDK has a handler registered
- **Capabilities**: Tags/chips
- **Constraints**: List of constraints

### 5. Optional: Show Upload History

Consider showing when the schema was last uploaded:

```
Last updated: 2024-01-15 10:30 UTC
Uploaded by: ami tool-register (SDK v1.2.0)
Tools count: 12
```

## Developer Workflow (After Changes)

1. Developer defines tools in code:
   ```python
   @registry.tool("send_email", "Send email", {"to": str})
   async def send_email(args: dict) -> dict:
       return {"sent": True}
   ```

2. Developer runs:
   ```bash
   ami tool-register -w production -j my-agent
   ```

3. UI automatically shows the new tools (read-only)

## Migration Notes

- Existing manually-created tools in UI should be migrated to code
- Consider a one-time export feature to help users migrate UI tools to code
- After migration, disable manual tool creation

## Questions for UI Team

1. Should we show a diff when a new schema is uploaded?
2. Should there be approval workflow for schema updates?
3. How to handle tool deletion (tool exists in UI but not in new schema)?
