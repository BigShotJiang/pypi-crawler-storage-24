from __future__ import annotations

from typing import Optional


class GkCaptchaError(Exception):
    def __init__(self, code: str, message: str, cause: Optional[Exception] = None):
        super().__init__(message)
        self.code = code
        self.cause = cause

    def __str__(self) -> str:
        if self.cause:
            return f"gkcaptcha: {self.code}: {super().__str__()}: {self.cause}"
        return f"gkcaptcha: {self.code}: {super().__str__()}"
