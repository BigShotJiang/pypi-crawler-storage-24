from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class VerifyTokenResponse:
    success: bool
    score: Optional[float] = None
    timestamp: Optional[int] = None
    error: Optional[str] = None
    reason_code: Optional[str] = None
    fail_open: bool = False

    @classmethod
    def from_dict(cls, data: dict) -> "VerifyTokenResponse":
        return cls(
            success=bool(data.get("success", False)),
            score=float(data["score"]) if "score" in data else None,
            timestamp=int(data["timestamp"]) if "timestamp" in data else None,
            error=data.get("error"),
            reason_code=data.get("reasonCode"),  # camelCase -> snake_case
        )


@dataclass(frozen=True)
class VerifyOptions:
    client_ip: Optional[str] = None
    user_agent: Optional[str] = None
