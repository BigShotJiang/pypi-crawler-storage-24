import asyncio
import os
import time
from typing import Optional

import httpx

from .errors import GkCaptchaError
from .types import VerifyOptions, VerifyTokenResponse


class GkCaptchaClient:
    def __init__(
        self,
        secret_key: Optional[str] = None,
        site_key: Optional[str] = None,
        api_url: Optional[str] = None,
        timeout: float = 5.0,
        max_retries: int = 1,
        retry_delay: float = 1.0,
        fail_closed: bool = False,
    ):
        self._secret_key = secret_key or os.environ.get("GKCAPTCHA_SECRET_KEY", "")
        self._site_key = site_key or os.environ.get("GKCAPTCHA_SITE_KEY", "")
        self._api_url = (
            api_url
            or os.environ.get("GKCAPTCHA_API_URL", "https://gkcaptcha.gatekeeper.sa")
        )
        self._timeout = timeout
        self._max_retries = max_retries
        self._retry_delay = retry_delay
        self._fail_closed = fail_closed

        if not self._secret_key:
            raise GkCaptchaError("INVALID_CONFIG", "secret_key is required")
        if not self._site_key:
            raise GkCaptchaError("INVALID_CONFIG", "site_key is required")

    def _build_body(self, token: str, options: Optional[VerifyOptions]) -> dict:
        body: dict = {
            "siteKey": self._site_key,
            "secret": self._secret_key,
            "token": token,
        }
        if options and options.client_ip:
            body["clientIP"] = options.client_ip
        if options and options.user_agent:
            body["userAgent"] = options.user_agent
        return body

    def verify_token(
        self,
        token: str,
        options: Optional[VerifyOptions] = None,
    ) -> VerifyTokenResponse:
        url = f"{self._api_url}/api/v1/token/verify"
        body = self._build_body(token, options)
        last_error: Optional[Exception] = None

        for attempt in range(self._max_retries + 1):
            try:
                with httpx.Client(timeout=self._timeout) as client:
                    resp = client.post(url, json=body)
                    return VerifyTokenResponse.from_dict(resp.json())
            except httpx.TimeoutException as e:
                raise GkCaptchaError("TIMEOUT", "Request timed out", cause=e) from e
            except httpx.TransportError as e:
                last_error = e
                if attempt < self._max_retries:
                    time.sleep(self._retry_delay)

        if self._fail_closed:
            raise GkCaptchaError(
                "NETWORK_ERROR",
                "Network error after retries",
                cause=last_error,
            ) from last_error
        return VerifyTokenResponse(success=True, fail_open=True)

    async def verify_token_async(
        self,
        token: str,
        options: Optional[VerifyOptions] = None,
    ) -> VerifyTokenResponse:
        url = f"{self._api_url}/api/v1/token/verify"
        body = self._build_body(token, options)
        last_error: Optional[Exception] = None

        for attempt in range(self._max_retries + 1):
            try:
                async with httpx.AsyncClient(timeout=self._timeout) as client:
                    resp = await client.post(url, json=body)
                    return VerifyTokenResponse.from_dict(resp.json())
            except httpx.TimeoutException as e:
                raise GkCaptchaError("TIMEOUT", "Request timed out", cause=e) from e
            except httpx.TransportError as e:
                last_error = e
                if attempt < self._max_retries:
                    await asyncio.sleep(self._retry_delay)

        if self._fail_closed:
            raise GkCaptchaError(
                "NETWORK_ERROR",
                "Network error after retries",
                cause=last_error,
            ) from last_error
        return VerifyTokenResponse(success=True, fail_open=True)
