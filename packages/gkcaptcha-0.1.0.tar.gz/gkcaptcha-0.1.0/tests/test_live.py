"""Live smoke test for the gkCAPTCHA Python SDK.

Run with: GKCAPTCHA_LIVE_TEST=1 GKCAPTCHA_SECRET_KEY=<key> pytest -v tests/test_live.py

Verifies that the production API is reachable, returns a parseable response,
and correctly rejects a dummy token (success=false, not fail-open).
"""

import os

import pytest

from gkcaptcha import GkCaptchaClient


pytestmark = pytest.mark.skipif(
    not os.environ.get("GKCAPTCHA_LIVE_TEST"),
    reason="set GKCAPTCHA_LIVE_TEST=1 to run live tests",
)


@pytest.fixture
def live_client():
    secret_key = os.environ.get("GKCAPTCHA_SECRET_KEY", "")
    site_key = os.environ.get("GKCAPTCHA_SITE_KEY", "")
    if not secret_key or not site_key:
        pytest.fail("GKCAPTCHA_SECRET_KEY and GKCAPTCHA_SITE_KEY must be set for live tests")

    return GkCaptchaClient(
        secret_key=secret_key,
        site_key=site_key,
        fail_closed=True,  # We want to see real errors, not fail-open
        max_retries=2,
        timeout=10.0,
    )


def test_live_api_reachable(live_client):
    """Production API is reachable and returns a well-formed rejection for dummy token."""
    result = live_client.verify_token("smoke-test-dummy-token")

    # Dummy token must be rejected
    assert result.success is False, "expected success=False for dummy token"
    assert result.fail_open is False, "expected actual API response, not fail-open fallback"


@pytest.mark.asyncio
async def test_live_api_reachable_async(live_client):
    """Async variant: production API is reachable and returns well-formed rejection."""
    result = await live_client.verify_token_async("smoke-test-dummy-token")

    assert result.success is False, "expected success=False for dummy token"
    assert result.fail_open is False, "expected actual API response, not fail-open fallback"
