import os

import httpx
import pytest
import respx

from gkcaptcha import GkCaptchaClient, GkCaptchaError, VerifyTokenResponse
from gkcaptcha.types import VerifyOptions

API_URL = "https://gkcaptcha.gatekeeper.sa"
VERIFY_URL = f"{API_URL}/api/v1/token/verify"


def make_client(fail_closed: bool = False, **kwargs) -> GkCaptchaClient:
    return GkCaptchaClient(
        secret_key="sk_test_secret123",
        site_key="pk_live_site123",
        api_url=API_URL,
        retry_delay=0,  # No sleep in tests
        fail_closed=fail_closed,
        **kwargs,
    )


# Test 1: verify_token returns success
@respx.mock
def test_verify_token_success():
    respx.post(VERIFY_URL).mock(
        return_value=httpx.Response(200, json={"success": True, "score": 0.15})
    )
    client = make_client()
    result = client.verify_token("test-token")
    assert result.success is True
    assert result.score == 0.15


# Test 2: verify_token returns failure with reason_code
@respx.mock
def test_verify_token_failure():
    respx.post(VERIFY_URL).mock(
        return_value=httpx.Response(
            200,
            json={"success": False, "error": "token expired", "reasonCode": "token_expired"},
        )
    )
    client = make_client()
    result = client.verify_token("expired-token")
    assert result.success is False
    assert result.reason_code == "token_expired"


# Test 3: fail-open default on timeout — timeout ALWAYS raises
@respx.mock
def test_timeout_always_raises():
    respx.post(VERIFY_URL).mock(side_effect=httpx.TimeoutException("timed out"))
    client = make_client(fail_closed=False)  # fail_closed=False (default)
    with pytest.raises(GkCaptchaError) as exc_info:
        client.verify_token("test-token")
    assert exc_info.value.code == "TIMEOUT"


# Test 4: fail-open default on network error — returns success=True, fail_open=True
@respx.mock
def test_network_error_fail_open():
    respx.post(VERIFY_URL).mock(side_effect=httpx.ConnectError("connection refused"))
    client = make_client(fail_closed=False, max_retries=0)
    result = client.verify_token("test-token")
    assert result.success is True
    assert result.fail_open is True


# Test 5: fail_closed=True on network error — raises GkCaptchaError
@respx.mock
def test_network_error_fail_closed():
    respx.post(VERIFY_URL).mock(side_effect=httpx.ConnectError("connection refused"))
    client = make_client(fail_closed=True, max_retries=0)
    with pytest.raises(GkCaptchaError) as exc_info:
        client.verify_token("test-token")
    assert exc_info.value.code == "NETWORK_ERROR"


# Test 6: Retries on transport error (1 retry = 2 total calls)
@respx.mock
def test_retries_on_transport_error():
    route = respx.post(VERIFY_URL)
    route.side_effect = [
        httpx.ConnectError("first attempt fails"),
        httpx.Response(200, json={"success": True, "score": 0.05}),
    ]
    client = make_client(max_retries=1)
    result = client.verify_token("test-token")
    assert result.success is True
    assert route.call_count == 2


# Test 7: Reads env vars for configuration
def test_reads_env_vars(monkeypatch):
    monkeypatch.setenv("GKCAPTCHA_SECRET_KEY", "sk_env_secret")
    monkeypatch.setenv("GKCAPTCHA_SITE_KEY", "pk_env_site")
    monkeypatch.setenv("GKCAPTCHA_API_URL", "https://custom.api.sa")
    client = GkCaptchaClient()
    assert client._secret_key == "sk_env_secret"
    assert client._site_key == "pk_env_site"
    assert client._api_url == "https://custom.api.sa"


# Test 8: Raises on missing secret_key
def test_raises_on_missing_secret_key(monkeypatch):
    monkeypatch.delenv("GKCAPTCHA_SECRET_KEY", raising=False)
    with pytest.raises(GkCaptchaError) as exc_info:
        GkCaptchaClient(site_key="pk_live_site123")
    assert exc_info.value.code == "INVALID_CONFIG"


# Test 9: verify_token_async returns success
@pytest.mark.asyncio
@respx.mock
async def test_verify_token_async_success():
    respx.post(VERIFY_URL).mock(
        return_value=httpx.Response(200, json={"success": True, "score": 0.08})
    )
    client = make_client()
    result = await client.verify_token_async("test-token")
    assert result.success is True
    assert result.score == 0.08


# Test 10: Passes client_ip and user_agent in request body
@respx.mock
def test_passes_client_ip_and_user_agent():
    route = respx.post(VERIFY_URL).mock(
        return_value=httpx.Response(200, json={"success": True})
    )
    client = make_client()
    options = VerifyOptions(client_ip="192.168.1.1", user_agent="Mozilla/5.0")
    client.verify_token("test-token", options=options)

    request_body = route.calls.last.request.content
    import json
    body = json.loads(request_body)
    assert body["clientIP"] == "192.168.1.1"
    assert body["userAgent"] == "Mozilla/5.0"


# Test 11: camelCase to snake_case mapping (reasonCode -> reason_code)
@respx.mock
def test_camel_case_to_snake_case_mapping():
    respx.post(VERIFY_URL).mock(
        return_value=httpx.Response(
            200,
            json={
                "success": False,
                "reasonCode": "bot_detected",
                "score": 0.95,
                "timestamp": 1700000000,
            },
        )
    )
    client = make_client()
    result = client.verify_token("test-token")
    assert result.reason_code == "bot_detected"
    assert result.score == 0.95
    assert result.timestamp == 1700000000
