"""
Custom exceptions for the state machine framework.

These exceptions provide clear error messages and help with debugging
state machine issues.
"""


class StateMachineError(Exception):
    """Base exception for all state machine errors."""
    pass


class StateValidityError(StateMachineError):
    """
    Raised when a pre-transition hook or validator fails.

    Both pre-transition hooks and validators raise this exception on failure,
    which causes the transition to be rolled back.
    """
    pass


class ObjectNotFound(StateMachineError):
    """
    Raised when a required object (model instance) is not found.
    
    This typically occurs when trying to fetch model instances
    during a transition.
    """
    pass


class TransitionError(StateMachineError):
    """
    Raised when a state transition is not permitted.

    This occurs when:
    - The start state is a terminal state (no outgoing transitions allowed)
    - The target state is not in the start state's allowed_transitions list
    """
    pass


class ContextValidationError(StateMachineError):
    """
    Raised when workflow context validation fails.
    
    This occurs when required context fields are missing or invalid.
    """
    pass


