"""
State class and metaclass definitions.

States represent points in a workflow with associated validation and hooks.
"""

from abc import ABC, ABCMeta
from typing import Optional


class StateMeta(ABCMeta):
    """
    Metaclass for State classes.
    
    Automatically sets default values for state flags when a State
    subclass is created.
    """
    
    def __new__(cls, name, bases, dct):
        dct.setdefault('is_start_state', False)
        dct.setdefault('is_terminal_state', False)
        dct.setdefault('allowed_transitions', [])
        # Each subclass gets its own model_states dict — never inherited/shared.
        if 'model_states' not in dct:
            dct['model_states'] = {}
        return super().__new__(cls, name, bases, dct)


class State(ABC, metaclass=StateMeta):
    """
    Base class for defining states in a state machine.

    Subclass this to define a state. Use class-level attributes to configure
    the state, and decorator-based methods for inline validators/hooks.

    Example:
        class PaymentPending(State):
            _state_machine = PaymentStateMachine
            is_start_state = True
            allowed_transitions = [PaymentProcessing]
            model_states = {Payment: 'pending', Order: 'awaiting_payment'}

            @validator(order=1)
            def check_amount(self, data, context):
                if data['Payment'].get('amount', 0) <= 0:
                    raise ValueError("Amount must be positive")
                return {'amount_valid': True}

            @hook(order=1)
            def send_notification(self, instances, context):
                notify(instances['Payment'])
                return {'notification_sent': True}

    Attributes:
        _state_machine: The StateMachine subclass this state belongs to.
            Must be set before external decorators or transition graph
            validation can be used.
        is_start_state (bool): Whether this is the initial state. The owning
            StateMachine will record it as _start_state automatically.
        is_terminal_state (bool): Whether this is a final state. Transitioning
            out of a terminal state raises TransitionError.
        allowed_transitions (list): State classes this state may transition to.
            An empty list means unrestricted.
        model_states (dict): Maps model class → state field value for that
            model when entering this state.
        _inline_pre_transition_hooks (list): Populated automatically from
            @pre_transition-decorated methods defined in this class.
        _inline_validators (list): Populated automatically from
            @validator-decorated methods defined in this class.
        _inline_hooks (list): Populated automatically from @hook-decorated
            methods defined in this class.
        _inline_transition: Custom @transition method if defined, else None.
    """
    
    # Inline hooks/validators populated by __init_subclass__.
    # get_*() merges these with the machine registry on every call.
    _inline_pre_transition_hooks: list = []
    _inline_validators: list = []
    _inline_hooks: list = []
    _inline_transition = None
    _state_machine = None  # Set by the developer to associate this state with a StateMachine

    # Explicit list of State classes this state may transition to.
    # Empty means unrestricted. Set by StateMeta if not defined by the subclass.
    allowed_transitions: list = []

    # Maps model class → target state value for that model at this state.
    # Each subclass gets its own dict (guaranteed by StateMeta).
    # Example:
    #   model_states = {Payment: 'pending', Order: 'awaiting_payment'}
    model_states: dict = {}
    
    @classmethod
    def name(cls) -> str:
        """Return the state's name. Used as the key within its machine's registry."""
        return cls.__name__

    @classmethod
    def get_model_state(cls, model_cls: type) -> Optional[str]:
        """
        Return the target state value for the given model class at this state.

        Returns None if this state does not define a value for that model,
        which means the framework will leave that model's state field unchanged.

        Example:
            class PaymentPending(State):
                model_states = {Payment: 'pending', Order: 'awaiting_payment'}

            PaymentPending.get_model_state(Payment)  # → 'pending'
            PaymentPending.get_model_state(Order)    # → 'awaiting_payment'
            PaymentPending.get_model_state(User)     # → None
        """
        return cls.model_states.get(model_cls)

    @classmethod
    def _registry(cls):
        """
        Return the HookRegistry for this state's owning StateMachine.

        Raises RuntimeError if _state_machine is not set, so the error surfaces
        clearly at the point of use rather than silently doing nothing.
        """
        machine = cls._state_machine
        if machine is None:
            raise RuntimeError(
                f"State '{cls.__name__}' has no '_state_machine' set. "
                f"Assign the owning StateMachine before using this state:\n\n"
                f"    class {cls.__name__}(State):\n"
                f"        _state_machine = YourStateMachine\n"
            )
        return machine._registry
    
    def __init_subclass__(cls, **kwargs):
        """
        Called when a State subclass is created.
        
        Automatically discovers and organizes validators, hooks, and
        custom transitions defined in the state class or registered externally.
        """
        super().__init_subclass__(**kwargs)
        
        # Helper function to safely get attributes, filtering out special ABC attributes
        def get_class_attributes():
            """Get all class attributes, filtering out special/descriptor attributes."""
            attrs = []
            for name in dir(cls):
                # Skip special attributes that might cause issues with ABCMeta
                if name.startswith('__') and name.endswith('__'):
                    continue
                try:
                    attr = getattr(cls, name)
                    # Only include callable attributes (methods/functions)
                    if callable(attr):
                        attrs.append((name, attr))
                except (AttributeError, TypeError):
                    # Skip attributes that can't be accessed
                    continue
            return attrs
        
        # Collect inline pre-transition hooks (defined in the class)
        inline_pre_transition_hooks = sorted(
            [attr for name, attr in get_class_attributes()
             if hasattr(attr, '_is_pre_transition_hook')],
            key=lambda func: func._order
        )

        cls._inline_pre_transition_hooks = inline_pre_transition_hooks

        # Collect inline validators (defined in the class)
        cls._inline_validators = sorted(
            [attr for name, attr in get_class_attributes()
             if hasattr(attr, '_is_validator')],
            key=lambda func: func._order
        )

        # Collect inline post-transition hooks
        cls._inline_hooks = sorted(
            [attr for name, attr in get_class_attributes()
             if hasattr(attr, '_is_hook')],
            key=lambda func: func._order
        )

        # Inline transition takes precedence over any external registration
        cls._inline_transition = next(
            (attr for _, attr in get_class_attributes() if hasattr(attr, '_is_transition')),
            None
        )

        # Auto-register as start state on the owning machine if applicable.
        if cls._state_machine is not None and cls.is_start_state:
            cls._state_machine._start_state = cls

    @classmethod
    def get_pre_transition_hooks(cls) -> list:
        """Return inline hooks merged with any externally registered hooks, in order."""
        if cls._state_machine is None:
            return cls._inline_pre_transition_hooks
        external = cls._registry().get_pre_transition_hooks(cls)
        return sorted(
            cls._inline_pre_transition_hooks + external,
            key=lambda f: f._order,
        )

    @classmethod
    def get_validators(cls) -> list:
        """Return inline validators merged with any externally registered validators, in order."""
        if cls._state_machine is None:
            return cls._inline_validators
        external = cls._registry().get_validators(cls)
        return sorted(
            cls._inline_validators + external,
            key=lambda f: f._order,
        )

    @classmethod
    def get_hooks(cls) -> list:
        """Return inline hooks merged with any externally registered post-transition hooks, in order."""
        if cls._state_machine is None:
            return cls._inline_hooks
        external = cls._registry().get_hooks(cls)
        return sorted(
            cls._inline_hooks + external,
            key=lambda f: f._order,
        )

    @classmethod
    def get_transition(cls):
        """Return the transition function. Inline takes precedence over external."""
        if cls._inline_transition is not None:
            return cls._inline_transition
        if cls._state_machine is None:
            return None
        return cls._registry().get_transition(cls)
    


