"""
StateMachine base class for defining state machines.

This module contains the core state machine logic including transition
execution, validation, and hook processing.
"""

from abc import ABC, ABCMeta
from logging import getLogger
from typing import Any

from state_machine_framework.core.exceptions import (
    StateValidityError,
    ObjectNotFound,
    TransitionError
)
from state_machine_framework.decorators.hooks import HookRegistry
from state_machine_framework.orm.base import ORMAdapter

logger = getLogger(__name__)


class StateMachineMeta(ABCMeta):
    """
    Metaclass for StateMachine classes.
    
    Provides model registration functionality for tracking which models
    are managed by the state machine.
    """
    
    def __init__(cls, name, bases, dct):
        super().__init__(name, bases, dct)
        if 'registered_models' not in cls.__dict__:
            cls.registered_models = {}
        if '_registry' not in cls.__dict__:
            cls._registry = HookRegistry()
        if '_start_state' not in cls.__dict__:
            cls._start_state = None
    
    def register(cls, model: type, state_field: str, identifier_field: str):
        """
        Register a model with the state machine.
        
        Args:
            model: The model class to register
            state_field: Name of the field that stores the state
            identifier_field: Name of the field used to identify instances
        """
        cls.registered_models[model] = {
            'state_field': state_field,
            'identifier_field': identifier_field,
        }


class StateMachine(ABC, metaclass=StateMachineMeta):
    """
    Base class for state machines.
    
    Subclass this to create a state machine for your domain. Register models
    using the register() class method and define states as nested classes.
    
    Example:
        class PaymentStateMachine(StateMachine):
            pass
        
        PaymentStateMachine.register(
            Payment,
            state_field='status',
            identifier_field='payment_id'
        )
        
        class PaymentPending(State):
            model_states = {Payment: 'pending'}
    """
    
    def __init__(self, data: dict, context: dict | None = None, initial: bool = False,
                 orm_adapter: ORMAdapter = None):
        """
        Initialize the state machine.
        
        Args:
            data: Dictionary containing model data or identifiers
            context: Optional context dictionary for validators and hooks
            initial: Boolean flag indicating if this is initial state creation
            orm_adapter: ORM adapter instance (must implement ORMAdapter interface)
        
        Raises:
            TypeError: If orm_adapter is not provided or not an instance of ORMAdapter
        """
        self.data = data
        self.initial = initial
        self.context = context or {}
        
        if orm_adapter is None:
            raise TypeError(
                "orm_adapter is required. You must provide an ORM adapter instance "
                "that implements the ORMAdapter interface."
            )
        
        if not isinstance(orm_adapter, ORMAdapter):
            raise TypeError(
                f"orm_adapter must be an instance of ORMAdapter, got {type(orm_adapter)}"
            )
        
        self.orm_adapter = orm_adapter
        # Add ORM adapter to context so hooks and validators can access it
        self.context['_orm_adapter'] = orm_adapter
    
    def perform_transition(self, start_state=None, target_state=None):
        """
        Perform a state transition, wrapped in a transaction.

        Calls orm_adapter.begin() before executing, orm_adapter.commit() on
        success, and orm_adapter.rollback() on any failure. All three are
        no-ops by default — override them in your adapter for atomicity.

        Args:
            start_state: The current state (None for initial creation).
            target_state: The state to transition to.

        Returns:
            Tuple of (instances, responses) where responses has keys
            'pre_transition_responses', 'validator_responses', 'hook_responses'.

        Raises:
            StateValidityError: If validation or a pre-transition hook fails.
            TransitionError: If the transition is not permitted.
        """
        self.orm_adapter.begin()
        try:
            if self.initial:
                result = self._init_state(target_state or start_state)
            else:
                result = self._execute_transition(start_state, target_state)
            self.orm_adapter.commit()
            return result
        except Exception:
            self.orm_adapter.rollback()
            raise
    
    def _init_state(self, state) -> tuple[dict, dict]:
        """
        Initialize models in their initial state.

        Returns:
            Tuple of (instances, responses) where responses has keys
            'pre_transition_responses', 'validator_responses', 'hook_responses'.
        """
        instances: dict = {}

        pre_transition_responses = self._run_pre_transition_hooks(state)
        validator_responses = self._run_validators(state)

        for model_name, model_data in self.data.items():
            model_cls = self._get_model_class(model_name)
            identifier_field = self.registered_models[model_cls]['identifier_field']
            identifier_value = model_data.get(identifier_field)

            if identifier_value:
                try:
                    instance = self.orm_adapter.get(
                        model_cls, **{identifier_field: identifier_value}
                    )
                    state_field = self.registered_models[model_cls]['state_field']
                    state_value = state.get_model_state(model_cls)
                    if state_value:
                        self.orm_adapter.update(
                            model_cls,
                            {identifier_field: identifier_value},
                            **{state_field: state_value},
                        )
                        instance = self.orm_adapter.get(
                            model_cls, **{identifier_field: identifier_value}
                        )
                    instances[model_name] = instance
                    continue
                except ObjectNotFound:
                    pass

            state_field = self.registered_models[model_cls]['state_field']
            if state_field not in model_data:
                state_value = state.get_model_state(model_cls)
                if state_value:
                    model_data[state_field] = state_value

            custom_create = getattr(state, f'create_{model_name.lower()}', None)
            instances[model_name] = (
                custom_create(state, data=model_data)
                if custom_create
                else self.orm_adapter.create(model_cls, **model_data)
            )

        hook_responses = self._run_hooks(state, instances)

        return instances, {
            'pre_transition_responses': pre_transition_responses,
            'validator_responses': validator_responses,
            'hook_responses': hook_responses,
        }
    
    def _execute_transition(self, start_state, target_state):
        """
        Execute a state transition from start_state to target_state.
        
        Args:
            start_state: The current state
            target_state: The target state
        
        Returns:
            Tuple of (instances, responses)
        
        Raises:
            StateValidityError: If validation fails
            TransitionError: If transition is invalid
        """
        # Enforce transition graph. Terminal states have no outgoing transitions.
        if getattr(start_state, 'is_terminal_state', False):
            raise TransitionError(
                f"Cannot transition out of terminal state '{start_state.__name__}'."
            )

        allowed = getattr(start_state, 'allowed_transitions', [])
        if allowed and target_state not in allowed:
            allowed_names = ', '.join(s.__name__ for s in allowed)
            raise TransitionError(
                f"Transition from '{start_state.__name__}' to '{target_state.__name__}' "
                f"is not allowed. Allowed transitions: [{allowed_names}]."
            )
        
        # Pre-transition hooks run first — they may enrich self.data before instance fetching.
        pre_transition_responses = self._run_pre_transition_hooks(target_state)

        instances = self._fetch_instances(target_state)

        validator_responses = self._run_validators(target_state)

        transition_fn = target_state.get_transition()
        if transition_fn:
            transition_fn(target_state, instances, self.context)
        else:
            self._update_states(instances, target_state)

        hook_responses = self._run_hooks(target_state, instances)

        return instances, {
            'pre_transition_responses': pre_transition_responses,
            'validator_responses': validator_responses,
            'hook_responses': hook_responses,
        }
    
    def _fetch_instances(self, target_state) -> dict:
        """
        Fetch or create model instances needed for the transition.

        Called after pre-transition hooks so that any data they wrote is available.
        """
        instances: dict = {}

        for model_name, model_data in self.data.items():
            model_cls = self._get_model_class(model_name)

            custom_get = getattr(target_state, f'get_{model_name.lower()}', None)
            if custom_get:
                instances[model_name] = custom_get(target_state, data=model_data)
                continue

            identifier_field = self.registered_models[model_cls]['identifier_field']
            identifier_value = model_data.get(identifier_field)

            if identifier_value:
                try:
                    instances[model_name] = self.orm_adapter.get(
                        model_cls, **{identifier_field: identifier_value}
                    )
                except ObjectNotFound:
                    # Identifier supplied but not found — only create if extra data was provided.
                    actual_data = {k: v for k, v in model_data.items() if v is not None}
                    has_extra = len(actual_data) > 1 or (
                        len(actual_data) == 1 and identifier_field not in actual_data
                    )
                    if not has_extra:
                        raise
                    actual_data = self._inject_model_state(actual_data, model_cls, target_state)
                    instances[model_name] = self._create_instance(
                        target_state, model_name, model_cls, actual_data
                    )
            else:
                # No identifier — create if any data was provided.
                actual_data = {k: v for k, v in model_data.items() if v is not None}
                if actual_data:
                    actual_data = self._inject_model_state(actual_data, model_cls, target_state)
                    instances[model_name] = self._create_instance(
                        target_state, model_name, model_cls, actual_data
                    )
                else:
                    instances[model_name] = None

        return instances
    
    def _run_pre_transition_hooks(self, state) -> dict[str, Any]:
        """
        Run pre-transition hooks. Hooks receive (data, context) and may mutate
        both to enrich data before validation and instance fetching.

        Raises StateValidityError on any failure — a failed pre-transition hook
        is considered a hard stop, same as a failed validator.
        """
        responses: dict[str, Any] = {}
        for func in state.get_pre_transition_hooks():
            try:
                responses[func.__name__] = func(state, data=self.data, context=self.context)
            except Exception as e:
                raise StateValidityError(
                    f"Pre-transition hook '{func.__name__}' failed: {e}"
                ) from e
        return responses

    def _run_validators(self, state) -> dict[str, Any]:
        """
        Run validators. Validators receive (data, context) and should only raise
        exceptions — they must not modify data or context.

        Raises StateValidityError on any failure.
        """
        responses: dict[str, Any] = {}
        for func in state.get_validators():
            try:
                responses[func.__name__] = func(state, data=self.data, context=self.context)
            except Exception as e:
                raise StateValidityError(
                    f"Validator '{func.__name__}' failed: {e}"
                ) from e
        return responses

    def _run_hooks(self, state, instances: dict) -> dict[str, Any]:
        """
        Run post-transition hooks. Hooks receive (instances, context).
        Use context for any cross-phase data sharing.

        Hook failures are logged but do not abort — post-transition side effects
        (emails, notifications) should not roll back a completed transition.
        """
        responses: dict[str, Any] = {}
        for func in state.get_hooks():
            try:
                responses[func.__name__] = func(
                    state, instances=instances, context=self.context
                )
            except Exception as e:
                logger.error("Hook '%s' failed: %s", func.__name__, e, exc_info=True)
        return responses
    
    def _inject_model_state(self, data: dict, model_cls: type, state) -> dict:
        """Inject the state field value into data if not already present."""
        state_field = self.registered_models[model_cls]['state_field']
        if state_field not in data:
            state_value = state.get_model_state(model_cls)
            if state_value:
                data[state_field] = state_value
        return data

    def _create_instance(self, state, model_name: str, model_cls: type, data: dict) -> Any:
        """Create a model instance via custom method or ORM adapter."""
        custom_create = getattr(state, f'create_{model_name.lower()}', None)
        return (
            custom_create(state, data=data)
            if custom_create
            else self.orm_adapter.create(model_cls, **data)
        )

    def _update_states(self, instances: dict, target_state) -> None:
        """Update state fields of model instances after a transition."""
        for model_name, instance in instances.items():
            if not instance:
                continue
            model_cls = self._get_model_class(model_name)
            state_field = self.registered_models[model_cls]['state_field']
            new_state_value = target_state.get_model_state(model_cls)

            if new_state_value:
                custom_update = getattr(target_state, f'update_{model_name.lower()}', None)
                if custom_update:
                    custom_update(target_state, instance, self.context)
                else:
                    identifier_field = self.registered_models[model_cls]['identifier_field']
                    self.orm_adapter.update(
                        model_cls,
                        {identifier_field: getattr(instance, identifier_field)},
                        **{state_field: new_state_value},
                    )
    
    def _get_model_class(self, model_name):
        """
        Get model class by name.
        
        Args:
            model_name: Name of the model
        
        Returns:
            Model class
        
        Raises:
            ObjectNotFound: If model is not registered
        """
        for model_cls in self.registered_models.keys():
            if model_cls.__name__.lower() == model_name.lower():
                return model_cls
        
        raise ObjectNotFound(
            f"Model {model_name} is not registered in {self.__class__.__name__}"
        )


