"""
WorkflowContext for managing state machine workflows with validation.

This module provides the WorkflowContext class which manages workflow execution
with type-safe, validated context.
"""

from logging import getLogger
from typing import Dict, Type, Any, Optional, List, Callable
from dataclasses import dataclass

from state_machine_framework.core.exceptions import ContextValidationError

logger = getLogger(__name__)
from state_machine_framework.orm.base import ORMAdapter
from state_machine_framework.workflow.requirements import (
    ContextRequirement,
    ModelRequirement,
    DictRequirement
)


@dataclass
class StateTransitionResult:
    """
    Result of a state transition.
    
    Attributes:
        state_name: Name of the state transitioned to
        instances: Dictionary of model instances after transition
        validator_responses: Responses from validators
        hook_responses: Responses from hooks
        success: Whether the transition succeeded
        error: Error message if transition failed
    """
    state_name: str
    instances: Dict[str, Any]
    validator_responses: Dict[str, Any]
    hook_responses: Dict[str, Any]
    success: bool = True
    error: Optional[str] = None


class WorkflowContext:
    """
    Base class for defining workflow contexts with type-safe requirements.
    
    Subclass this to define a workflow with specific requirements. The context
    ensures all required fields are present and valid before allowing workflow
    execution.
    
    Example:
        class PaymentWorkflowContext(WorkflowContext):
            def define_requirements(self):
                self.require_value('user_id', str)
                self.require_model('payment', Payment, created_in_state=PaymentPending)
                self.require_dict('payment_data', PaymentDataSchema)
        
        # Usage
        with PaymentWorkflowContext(
            PaymentStateMachine,
            user_id='USER123',
            payment_data={'amount': 100.00, 'currency': 'USD'}
        ) as workflow:
            workflow.transition_to(PaymentPending)
            workflow.transition_to(PaymentProcessing)
            workflow.transition_to(PaymentCompleted)
    """
    
    def __init__(self, state_machine_cls, log: bool = False, debug: bool = False, **initial_context):
        """
        Initialize workflow context.
        
        Args:
            state_machine_cls: The StateMachine subclass to drive.
            log: If True, store transition history in transition_history (default: False).
            debug: Same effect as log — enables transition history logging (default: False).
            **initial_context: Initial context key-value pairs. Must include
                '_orm_adapter' set to an ORMAdapter instance.
        """
        self.state_machine_cls = state_machine_cls
        self.requirements: Dict[str, ContextRequirement] = {}
        self.context: Dict[str, Any] = {}
        self.transition_history: List[StateTransitionResult] = []
        self.current_state: Optional[Type] = None
        self._in_context_manager = False
        self._initial_context = initial_context
        self._log_enabled = log or debug  # Enable logging if either flag is True
        
        # Define requirements (implemented by subclass)
        self.define_requirements()
        
        # Store initial context
        self.context.update(initial_context)
    
    def define_requirements(self):
        """
        Override this method to define context requirements.
        
        Raises:
            NotImplementedError: If not implemented by subclass
        """
        raise NotImplementedError(
            "Subclasses must implement define_requirements()"
        )
    
    def require_model(self, name: str, model_cls: Type, required: bool = True,
                     validator: Optional[Callable] = None,
                     created_in_state: Optional[Type] = None):
        """
        Require an ORM model instance in context.
        
        Args:
            name: Field name in context
            model_cls: The model class
            required: Whether this field is required
            validator: Optional custom validator function
            created_in_state: State where this model is created (if any)
        """
        self.requirements[name] = ModelRequirement(
            name, model_cls, required, validator, created_in_state
        )
    
    def require_dict(self, name: str, schema: Type, required: bool = True):
        """
        Require a dictionary validated by Pydantic schema.
        
        Args:
            name: Field name in context
            schema: Pydantic BaseModel schema
            required: Whether this field is required
        """
        self.requirements[name] = DictRequirement(name, schema, required)
    
    def require_value(self, name: str, type_: Type, required: bool = True,
                     validator: Optional[Callable] = None, default: Any = None):
        """
        Require a simple value in context.
        
        Args:
            name: Field name in context
            type_: Expected type
            required: Whether this field is required
            validator: Optional custom validator function
            default: Default value if not provided
        """
        self.requirements[name] = ContextRequirement(
            name, type_, required, validator, default
        )
    
    def validate_initial_context(self):
        """
        Validate that initial context meets requirements.
        
        Raises:
            ContextValidationError: If validation fails
        """
        errors = []
        
        for name, requirement in self.requirements.items():
            # Skip models created in states
            if isinstance(requirement, ModelRequirement) and requirement.created_in_state:
                continue
            
            value = self.context.get(name)
            
            # Set default if available
            if value is None and hasattr(requirement, 'default') and requirement.default is not None:
                self.context[name] = requirement.default
                value = requirement.default
            
            try:
                requirement.validate(value)
            except (ValueError, TypeError) as e:
                errors.append(f"  • {str(e)}")
        
        if errors:
            error_msg = "Workflow context validation failed:\n" + "\n".join(errors)
            raise ContextValidationError(error_msg)
    
    def validate_state_context(self, state: Type):
        """
        Validate context for a specific state.
        
        Args:
            state: The state to validate context for
        
        Raises:
            ContextValidationError: If validation fails
        """
        errors = []
        
        for name, requirement in self.requirements.items():
            if isinstance(requirement, ModelRequirement):
                if requirement.created_in_state == state:
                    # Model created in this state, skip validation
                    continue
                
                # Model should exist by now
                value = self.context.get(name)
                try:
                    requirement.validate(value)
                except (ValueError, TypeError) as e:
                    errors.append(f"  • {str(e)}")
            else:
                # Non-model requirements always validate
                value = self.context.get(name)
                try:
                    requirement.validate(value)
                except (ValueError, TypeError) as e:
                    errors.append(f"  • {str(e)}")
        
        if errors:
            error_msg = (
                f"Context validation failed for state {state.__name__}:\n" +
                "\n".join(errors)
            )
            raise ContextValidationError(error_msg)
    
    def update(self, **kwargs):
        """
        Update context with new values.
        
        Args:
            **kwargs: Key-value pairs to add to context
        
        Raises:
            RuntimeError: If called outside of 'with' block
        """
        if not self._in_context_manager:
            raise RuntimeError("Cannot update context outside of 'with' block")
        
        self.context.update(kwargs)
    
    def get(self, name: str, default: Any = None) -> Any:
        """
        Get value from context.
        
        Args:
            name: Field name
            default: Default value if not found
        
        Returns:
            The context value or default
        """
        return self.context.get(name, default)
    
    def __enter__(self):
        """Enter the workflow context manager."""
        self._in_context_manager = True
        
        # Validate initial context
        self.validate_initial_context()
        
        start_state = self._find_start_state()
        if start_state:
            logger.debug("Workflow start state is '%s'", start_state.__name__)
        
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit the workflow context manager."""
        self._in_context_manager = False
        
        if exc_type is not None:
            logger.error("Workflow exited with error: %s", exc_val)
            return False

        logger.debug("Workflow completed successfully")
        return True
    
    def _find_start_state(self) -> Optional[Type]:
        """Return the start state registered on the state machine, if any."""
        return getattr(self.state_machine_cls, '_start_state', None)
    
    def transition_to(self, target_state: Type, **additional_data) -> StateTransitionResult:
        """
        Perform a state transition.
        
        Args:
            target_state: State to transition to
            **additional_data: Additional data for this transition
        
        Returns:
            StateTransitionResult with transition details
        
        Raises:
            RuntimeError: If called outside of 'with' block
            ContextValidationError: If context validation fails
        """
        if not self._in_context_manager:
            raise RuntimeError("Transitions can only occur within 'with' block")
        
        logger.debug("Transitioning to '%s'", target_state.__name__)
        
        # Validate context for this state
        self.validate_state_context(target_state)
        
        # Prepare data
        data = self._prepare_transition_data(target_state, additional_data)
        
        # Get ORM adapter from context (required)
        orm_adapter = self.context.get('_orm_adapter')
        if orm_adapter is None:
            raise RuntimeError(
                "ORM adapter is required. Provide '_orm_adapter' in the workflow context. "
                "You must implement an ORMAdapter subclass for your ORM."
            )
        
        # Create state machine instance
        # Only mark as initial if this is the very first transition (current_state is None)
        sm = self.state_machine_cls(
            data=data,
            context=self.context,
            initial=(self.current_state is None),
            orm_adapter=orm_adapter
        )
        
        try:
            # Perform transition
            instances, responses = sm.perform_transition(
                start_state=self.current_state,
                target_state=target_state
            )
            
            # Update context with instances
            self._update_context_from_instances(instances)
            
            result = StateTransitionResult(
                state_name=target_state.__name__,
                instances=instances,
                validator_responses=responses.get('validator_responses', {}),
                hook_responses=responses.get('hook_responses', {}),
                success=True,
            )
            
            # Only store history if logging is enabled
            if self._log_enabled:
                self.transition_history.append(result)
            self.current_state = target_state
            
            return result
            
        except Exception as e:
            logger.error("Transition to '%s' failed: %s", target_state.__name__, e)
            
            result = StateTransitionResult(
                state_name=target_state.__name__,
                instances={},
                validator_responses={},
                hook_responses={},
                success=False,
                error=str(e)
            )
            
            # Only store history if logging is enabled
            if self._log_enabled:
                self.transition_history.append(result)
            raise
    
    def _prepare_transition_data(self, target_state: Type, additional_data: Dict) -> Dict:
        """Prepare data dictionary for state machine."""
        data = {}
        
        # Add model instances from context
        for name, requirement in self.requirements.items():
            if isinstance(requirement, ModelRequirement):
                instance = self.context.get(name)
                
                # Skip if model created in this state
                if requirement.created_in_state == target_state:
                    if name in additional_data:
                        model_name = requirement.model_cls.__name__
                        data[model_name] = additional_data[name]
                    continue
                
                # Add identifier for existing instances
                if instance:
                    model_cls = requirement.model_cls
                    model_name = model_cls.__name__
                    
                    if hasattr(self.state_machine_cls, 'registered_models'):
                        identifier_field = self.state_machine_cls.registered_models.get(
                            model_cls, {}
                        ).get('identifier_field', 'id')
                        
                        data[model_name] = {
                            identifier_field: getattr(instance, identifier_field)
                        }
        
        # Merge additional data
        data.update(additional_data)
        
        return data
    
    def _update_context_from_instances(self, instances: Dict[str, Any]):
        """Update context with instances from transition result."""
        for model_name, instance in instances.items():
            if instance is None:
                continue

            matched = False
            for req_name, requirement in self.requirements.items():
                if isinstance(requirement, ModelRequirement):
                    if requirement.model_cls.__name__ == model_name:
                        self.context[req_name] = instance
                        logger.debug("Updated context: %s = %r", req_name, instance)
                        matched = True
                        break

            if not matched:
                logger.debug("No matching requirement found for model '%s'", model_name)
    
    def get_history_summary(self) -> str:
        """Get a summary of transition history."""
        lines = ["\n" + "="*60]
        lines.append("  WORKFLOW TRANSITION HISTORY")
        lines.append("="*60)
        
        if not self._log_enabled:
            lines.append("\n  (Logging is disabled. Enable with log=True or debug=True)")
        elif not self.transition_history:
            lines.append("\n  (No transitions recorded)")
        else:
            for i, result in enumerate(self.transition_history, 1):
                status = "✅" if result.success else "❌"
                lines.append(f"\n{i}. {status} {result.state_name}")
                
                if result.success:
                    lines.append(f"   Models: {', '.join(result.instances.keys())}")
                    if result.validator_responses:
                        lines.append(f"   Validators: {len(result.validator_responses)} passed")
                    if result.hook_responses:
                        lines.append(f"   Hooks: {len(result.hook_responses)} executed")
                else:
                    lines.append(f"   Error: {result.error}")
        
        lines.append("\n" + "="*60)
        return "\n".join(lines)

