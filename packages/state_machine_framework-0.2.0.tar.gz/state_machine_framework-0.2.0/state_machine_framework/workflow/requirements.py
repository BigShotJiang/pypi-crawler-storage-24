"""
Context requirement classes for workflow validation.

These classes define requirements for workflow context fields and provide
validation logic.
"""

from typing import Any, Callable
from pydantic import BaseModel


class ContextRequirement:
    """
    Base class for context requirements.
    
    Defines a requirement for a field in the workflow context.
    """
    
    def __init__(self, name: str, type_: type, required: bool = True,
                 validator_func: Callable | None = None, default: Any = None):
        """
        Initialize a context requirement.
        
        Args:
            name: Name of the required field
            type_: Expected type of the field
            required: Whether the field is required
            validator_func: Optional custom validator function
            default: Default value if not provided
        """
        self.name = name
        self.type = type_
        self.required = required
        self.validator_func = validator_func
        self.default = default
    
    def validate(self, value: Any) -> bool:
        """
        Validate that a value meets the requirement.
        
        Args:
            value: The value to validate
        
        Returns:
            True if validation passes
        
        Raises:
            ValueError: If validation fails
            TypeError: If type is incorrect
        """
        if value is None:
            if self.required:
                raise ValueError(f"Required field '{self.name}' is missing")
            return True
        
        # Type checking
        if not isinstance(value, self.type):
            raise TypeError(
                f"Field '{self.name}' must be of type {self.type.__name__}, "
                f"got {type(value).__name__}"
            )
        
        # Custom validation
        if self.validator_func and not self.validator_func(value):
            raise ValueError(f"Validation failed for field '{self.name}'")
        
        return True


class ModelRequirement(ContextRequirement):
    """
    Requirement for ORM model instances.
    
    Separate handling for models that may be created during workflow execution.
    """
    
    def __init__(self, name: str, model_cls: type, required: bool = True,
                 validator_func: Callable | None = None,
                 created_in_state: type | None = None):
        """
        Initialize a model requirement.
        
        Args:
            name: Name of the required model field
            model_cls: The model class
            required: Whether the field is required
            validator_func: Optional custom validator
            created_in_state: State where this model is created (if any)
        """
        super().__init__(name, model_cls, required, validator_func)
        self.model_cls = model_cls
        self.created_in_state = created_in_state
    
    def validate(self, value: Any) -> bool:
        """
        Validate model instance.
        
        Args:
            value: The value to validate
        
        Returns:
            True if validation passes
        
        Raises:
            ValueError: If validation fails
            TypeError: If type is incorrect
        """
        if value is None:
            if self.required and not self.created_in_state:
                raise ValueError(f"Required model '{self.name}' is missing")
            return True
        
        if not isinstance(value, self.model_cls):
            raise TypeError(
                f"Field '{self.name}' must be instance of {self.model_cls.__name__}, "
                f"got {type(value).__name__}"
            )
        
        # Custom validation
        if self.validator_func and not self.validator_func(value):
            raise ValueError(f"Validation failed for model '{self.name}'")
        
        return True


class DictRequirement(ContextRequirement):
    """
    Requirement for dictionary fields with Pydantic schema validation.
    """
    
    def __init__(self, name: str, schema: type[BaseModel], required: bool = True):
        """
        Initialize a dict requirement.
        
        Args:
            name: Name of the required dict field
            schema: Pydantic schema for validation
            required: Whether the field is required
        """
        super().__init__(name, dict, required)
        self.schema = schema
    
    def validate(self, value: Any) -> bool:
        """
        Validate dictionary against Pydantic schema.
        
        Args:
            value: The value to validate
        
        Returns:
            True if validation passes
        
        Raises:
            ValueError: If validation fails
            TypeError: If type is incorrect
        """
        if value is None:
            if self.required:
                raise ValueError(f"Required dict '{self.name}' is missing")
            return True
        
        if not isinstance(value, dict):
            raise TypeError(
                f"Field '{self.name}' must be a dict, got {type(value).__name__}"
            )
        
        try:
            # Pydantic v2
            try:
                self.schema.model_validate(value)
            except AttributeError:
                # Pydantic v1 fallback
                self.schema(**value)
        except Exception as e:
            raise ValueError(
                f"Schema validation failed for '{self.name}': {e}"
            )
        
        return True
