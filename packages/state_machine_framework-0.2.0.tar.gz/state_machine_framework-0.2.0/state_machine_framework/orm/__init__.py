"""
ORM adapter base class.

Developers must implement their own ORM adapter by subclassing ORMAdapter.
"""

from state_machine_framework.orm.base import ORMAdapter

__all__ = [
    'ORMAdapter',
]


