"""
Abstract ORM adapter for database operations.

Implement ORMAdapter to integrate the state machine framework with any ORM.
The interface is intentionally minimal — just the CRUD operations the framework
needs. Session management, transactions, and connection pooling are the
responsibility of the implementing adapter.

Example (SQLAlchemy)::

    class SQLAlchemyAdapter(ORMAdapter):
        def __init__(self, session):
            self.session = session

        def create(self, model_cls, **data):
            instance = model_cls(**data)
            self.session.add(instance)
            self.session.flush()
            return instance

        def get(self, model_cls, **filters):
            instance = self.session.query(model_cls).filter_by(**filters).one_or_none()
            if instance is None:
                raise ObjectNotFound(f"{model_cls.__name__} not found: {filters}")
            return instance

        def filter(self, model_cls, **filters):
            return self.session.query(model_cls).filter_by(**filters).all()

        def update(self, model_cls, filters, **updates):
            count = self.session.query(model_cls).filter_by(**filters).update(updates)
            return count

        def delete(self, model_cls, **filters):
            count = self.session.query(model_cls).filter_by(**filters).delete()
            return count

        def begin(self):
            self.session.begin()

        def commit(self):
            self.session.commit()

        def rollback(self):
            self.session.rollback()
"""

from abc import ABC, abstractmethod
from typing import Any


class ORMAdapter(ABC):
    """
    Abstract base class for ORM adapters.

    Subclass this and implement all five methods to connect the framework
    to your ORM. One adapter instance is passed to the StateMachine on each
    transition, so it can carry a live session or connection.

    Note on update(): unlike the other methods which use **kwargs for their
    lookup criteria, update() takes a positional `filters` dict. This is
    intentional — it cleanly separates "which rows to find" from "what to
    change", avoiding ambiguity when field names overlap.
    """

    @abstractmethod
    def create(self, model_cls: type, **data) -> Any:
        """
        Create and persist a new model instance.

        Args:
            model_cls: The model class to instantiate.
            **data: Field values for the new instance.

        Returns:
            The created instance.

        Raises:
            Exception: If creation fails.
        """
        ...

    @abstractmethod
    def get(self, model_cls: type, **filters) -> Any:
        """
        Retrieve exactly one model instance matching the filters.

        Args:
            model_cls: The model class to query.
            **filters: Field equality filters (e.g. id=123).

        Returns:
            The matching instance.

        Raises:
            ObjectNotFound: If no matching instance exists.
            Exception: If more than one instance matches.
        """
        ...

    @abstractmethod
    def filter(self, model_cls: type, **filters) -> list[Any]:
        """
        Retrieve all model instances matching the filters.

        Args:
            model_cls: The model class to query.
            **filters: Field equality filters.

        Returns:
            List of matching instances (empty list if none found).
        """
        ...

    @abstractmethod
    def update(self, model_cls: type, filters: dict, **updates) -> int:
        """
        Update fields on all instances matching filters.

        The `filters` argument is a positional dict (not **kwargs) to keep
        lookup criteria and update values unambiguous.

        Args:
            model_cls: The model class to update.
            filters: Dict of field equality conditions to identify rows.
            **updates: Field values to apply to matching rows.

        Returns:
            Number of instances updated.
        """
        ...

    @abstractmethod
    def delete(self, model_cls: type, **filters) -> int:
        """
        Delete all instances matching the filters.

        Args:
            model_cls: The model class.
            **filters: Field equality filters.

        Returns:
            Number of instances deleted.
        """
        ...

    # ------------------------------------------------------------------ #
    # Transaction management — optional, no-op by default.                #
    # Override these to get atomic transitions. If left as no-ops, there  #
    # are no transaction guarantees and a mid-transition failure can leave #
    # the database in a partially-updated state.                          #
    # ------------------------------------------------------------------ #

    def begin(self) -> None:
        """
        Begin a transaction before a state transition.

        Override to start a DB transaction (e.g. session.begin()).
        Default is a no-op — override if you need atomicity.
        """

    def commit(self) -> None:
        """
        Commit the transaction after a successful state transition.

        Override to commit (e.g. session.commit()).
        Default is a no-op.
        """

    def rollback(self) -> None:
        """
        Roll back the transaction after a failed state transition.

        Override to roll back (e.g. session.rollback()).
        Default is a no-op.
        """




