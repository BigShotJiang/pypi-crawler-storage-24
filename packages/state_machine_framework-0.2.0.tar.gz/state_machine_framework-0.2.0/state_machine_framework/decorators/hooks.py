"""
Decorators for validators, hooks, and transitions.

These decorators can be used inline (within State classes) or externally
(in separate modules) for clean code organization.

External registration requires that the State class has its _state_machine
attribute set before the decorator is applied, so the framework can route
the hook to the correct per-machine registry.
"""

from typing import Callable
import inspect


class HookRegistry:
    """
    Per-state-machine registry for validators, hooks, and transitions.

    One instance of this class is created per StateMachine subclass and stored
    as StateMachine._registry. This ensures complete isolation between different
    state machines in the same process, making testing straightforward.

    You do not instantiate this class directly — it is created automatically
    by StateMachineMeta when a StateMachine subclass is defined.
    """

    def __init__(self) -> None:
        self._pre_transition_hooks: dict[str, list[tuple[int, Callable]]] = {}
        self._validators: dict[str, list[tuple[int, Callable]]] = {}
        self._hooks: dict[str, list[tuple[int, Callable]]] = {}
        self._transitions: dict[str, Callable] = {}

    def _key(self, state_cls: type) -> str:
        return state_cls.__name__

    def _insert_ordered(
        self,
        store: dict[str, list[tuple[int, Callable]]],
        state_cls: type,
        order: int,
        func: Callable,
    ) -> None:
        key = self._key(state_cls)
        store.setdefault(key, [])
        store[key].append((order, func))
        store[key].sort(key=lambda x: x[0])

    def register_pre_transition_hook(self, state_cls: type, order: int, func: Callable) -> None:
        self._insert_ordered(self._pre_transition_hooks, state_cls, order, func)

    def register_validator(self, state_cls: type, order: int, func: Callable) -> None:
        self._insert_ordered(self._validators, state_cls, order, func)

    def register_hook(self, state_cls: type, order: int, func: Callable) -> None:
        self._insert_ordered(self._hooks, state_cls, order, func)

    def register_transition(self, state_cls: type, func: Callable) -> None:
        self._transitions[self._key(state_cls)] = func

    def get_pre_transition_hooks(self, state_cls: type) -> list[Callable]:
        return [f for _, f in self._pre_transition_hooks.get(self._key(state_cls), [])]

    def get_validators(self, state_cls: type) -> list[Callable]:
        return [f for _, f in self._validators.get(self._key(state_cls), [])]

    def get_hooks(self, state_cls: type) -> list[Callable]:
        return [f for _, f in self._hooks.get(self._key(state_cls), [])]

    def get_transition(self, state_cls: type) -> Callable | None:
        return self._transitions.get(self._key(state_cls))

    def clear(self) -> None:
        """Remove all registered hooks, validators, and transitions. Useful for testing."""
        self._pre_transition_hooks.clear()
        self._validators.clear()
        self._hooks.clear()
        self._transitions.clear()


def _get_registry(state_cls: type) -> HookRegistry:
    """
    Resolve the HookRegistry for a state class.

    Requires that state_cls._state_machine is set to its owning StateMachine
    subclass. Raises RuntimeError if the association is missing.
    """
    machine = getattr(state_cls, '_state_machine', None)
    if machine is None:
        raise RuntimeError(
            f"Cannot register an external hook on '{state_cls.__name__}' because "
            f"'_state_machine' is not set. Assign the owning StateMachine subclass "
            f"before applying external decorators:\n\n"
            f"    class {state_cls.__name__}(State):\n"
            f"        _state_machine = YourStateMachine\n"
        )
    registry = getattr(machine, '_registry', None)
    if registry is None:
        raise RuntimeError(
            f"StateMachine '{machine.__name__}' has no '_registry'. "
            f"Ensure it subclasses StateMachine correctly."
        )
    return registry


def _make_decorator(flag: str, register_fn_name: str, needs_order: bool = True):
    """
    Factory that generates the pre_transition / validator / hook / transition
    decorators, all of which share the same dual-use calling convention:

        @decorator              — inline, no arguments
        @decorator(order=N)     — inline, with order
        @decorator(StateClass, order=N)  — external registration
    """
    def outer(state_class=None, order: int = 0):
        def decorator(func: Callable) -> Callable:
            setattr(func, flag, True)
            if needs_order:
                func._order = order
            if state_class is not None:
                registry = _get_registry(state_class)
                if needs_order:
                    getattr(registry, register_fn_name)(state_class, order, func)
                else:
                    getattr(registry, register_fn_name)(state_class, func)
            return func

        # Called as @decorator (bare, no parentheses) — state_class is actually the function
        if state_class is not None and not inspect.isclass(state_class) and callable(state_class):
            return decorator(state_class)

        return decorator

    return outer


pre_transition = _make_decorator('_is_pre_transition_hook', 'register_pre_transition_hook')
pre_transition.__doc__ = """
Decorator to mark a function as a pre-transition hook.

Pre-transition hooks run BEFORE validators and can modify data/context.
Use these for operations like generating IDs or enriching data.

Usage:
    # Inline (inside State class):
    class MyState(State):
        @pre_transition(order=1)
        def generate_id(self, data, context):
            data['order']['id'] = f"ORD-{uuid.uuid4()}"
            return {'id_generated': True}

    # External (separate file, _state_machine must be set first):
    @pre_transition(MyState, order=1)
    def generate_id(state, data, context):
        data['order']['id'] = f"ORD-{uuid.uuid4()}"
        return {'id_generated': True}
"""

validator = _make_decorator('_is_validator', 'register_validator')
validator.__doc__ = """
Decorator to mark a function as a validator.

Validators run AFTER pre-transition hooks. They should ONLY validate —
never modify data or context. Raise an exception to fail the transition.

Usage:
    # Inline:
    class MyState(State):
        @validator(order=1)
        def check_amount(self, data, context):
            if data['order'].get('amount', 0) <= 0:
                raise ValueError("Amount must be positive")

    # External:
    @validator(MyState, order=1)
    def check_amount(state, data, context):
        if data['order'].get('amount', 0) <= 0:
            raise ValueError("Amount must be positive")
"""

hook = _make_decorator('_is_hook', 'register_hook')
hook.__doc__ = """
Decorator to mark a function as a post-transition hook.

Hooks run after the transition completes. Use them for side effects:
sending notifications, logging, updating external systems, etc.

Hook failures are logged but do NOT abort the transition — the state
update has already been committed at this point.

Usage:
    # Inline:
    class MyState(State):
        @hook(order=1)
        def send_email(self, instances, context):
            send_notification(instances['User'].email)
            return {'email_sent': True}

    # External:
    @hook(MyState, order=1)
    def send_email(state, instances, context):
        send_notification(instances['User'].email)
        return {'email_sent': True}
"""

transition = _make_decorator('_is_transition', 'register_transition', needs_order=False)
transition.__doc__ = """
Decorator to mark a function as a custom transition handler.

Custom transitions override the default state-update logic, giving
full control over how model state fields are updated.

Usage:
    # Inline:
    class MyState(State):
        @transition
        def custom_logic(self, instances, context):
            for instance in instances.values():
                instance.status = 'custom'
                instance.save()

    # External:
    @transition(MyState)
    def custom_logic(state, instances, context):
        pass
"""
