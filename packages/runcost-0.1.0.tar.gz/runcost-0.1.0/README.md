# RunCost

Run a 1,000-agent simulation for $2 instead of $200.

https://cost.run
