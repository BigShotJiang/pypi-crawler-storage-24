"""Define Microsoft providers."""
