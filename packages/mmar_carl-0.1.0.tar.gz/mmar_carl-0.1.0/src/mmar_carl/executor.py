"""
DAG execution engine for CARL reasoning chains.

Handles parallel execution of reasoning steps based on their dependencies.
Supports multiple step types through pluggable executors.
"""

import asyncio
import copy
import time
from dataclasses import dataclass
from typing import Any

from .logging_utils import (
    log_batch_start,
    log_chain_complete,
    log_chain_start,
    log_step_complete,
    log_step_start,
)
from .models import PromptTemplate, ReasoningContext, ReasoningResult, StepDescription, StepExecutionResult
from .step_executors import get_executor
from .tracing import create_chain_trace
from mmar_utils import gather_with_limit


class ExecutionCancelledError(Exception):
    """Raised when chain execution is cancelled by user."""

    pass


@dataclass
class ExecutionNode:
    """
    Represents a node in the execution DAG.
    """

    step: StepDescription
    dependencies: list["ExecutionNode"]
    dependents: list["ExecutionNode"]
    executed: bool = False
    executing: bool = False
    result: StepExecutionResult | None = None

    def __post_init__(self):
        if self.dependencies is None:
            self.dependencies = []
        if self.dependents is None:
            self.dependents = []

    def can_execute(self) -> bool:
        """Check if this node can be executed (all dependencies completed)."""
        return all(dep.executed for dep in self.dependencies)

    def is_ready(self) -> bool:
        """Check if this node is ready for execution (not executing or executed)."""
        return not self.executing and not self.executed and self.can_execute()


class DAGExecutor:
    """
    Executes reasoning chains as a Directed Acyclic Graph (DAG).

    Automatically parallelizes execution where dependencies allow.

    Note on parallel execution:
        - Each parallel step gets an isolated copy of memory (deep copy)
        - Tool registry is shared via shallow copy - tools MUST be stateless
        - Memory writes in parallel steps ARE merged back after batch completion
          but are NOT visible to other parallel steps in the same batch

    Note on conditional steps:
        - CONDITIONAL steps return next_step in result_data but DAG execution
          currently proceeds in topological order
        - For branching behavior, use separate chains or design dependencies accordingly
        - This is a known limitation that may be addressed in future versions

    Note on cancellation:
        - Call context.cancel() to request cancellation
        - Execution will stop after the current batch completes
        - Partial results are returned with success=False

    Performance Notes:
        For chains with large memory payloads, deep copying for parallel
        execution can be expensive. Consider:

        1. Using smaller, focused memory namespaces
        2. Reducing max_workers if memory is huge (default is 1)
        3. Using external state storage (Redis, etc.) for very large state
        4. Setting max_workers=1 for memory-heavy chains to avoid deep copies

    Token Usage Tracking:
        Token usage is tracked per step and aggregated in ReasoningResult.
        Note: Token counts are only available when the LLM client provides them
        (e.g., OpenAI API responses include usage data).
    """

    def __init__(
        self,
        max_workers: int = 1,
        prompt_template: PromptTemplate | None = None,
        enable_progress: bool = False,
        timeout: float | None = None,
    ):
        """
        Initialize the DAG executor.

        Args:
            max_workers: Maximum number of parallel executions
            prompt_template: Template for generating prompts
            enable_progress: Whether to enable progress tracking
            timeout: Maximum total execution time in seconds (None = no limit)
        """
        self.max_workers = max_workers
        self.prompt_template = prompt_template or PromptTemplate()
        self.enable_progress = enable_progress
        self.timeout = timeout
        self._execution_stats = {
            "total_steps": 0,
            "executed_steps": 0,
            "failed_steps": 0,
            "parallel_batches": 0,
            "total_time": 0.0,
        }

    def build_execution_graph(self, steps: list[StepDescription]) -> list[ExecutionNode]:
        """
        Build an execution graph from step descriptions.

        Args:
            steps: list of step descriptions

        Returns:
            list of execution nodes forming the DAG
        """
        if not steps:
            return []

        # Create nodes
        step_map: dict[int, ExecutionNode] = {}
        for step in steps:
            node = ExecutionNode(step=step, dependencies=[], dependents=[])
            step_map[step.number] = node

        # Build dependencies
        for step in steps:
            node = step_map[step.number]
            for dep_number in step.dependencies:
                if dep_number in step_map:
                    dependency_node = step_map[dep_number]
                    node.dependencies.append(dependency_node)
                    dependency_node.dependents.append(node)
                else:
                    raise ValueError(
                        f"Step {step.number} ('{step.title}') depends on non-existent step {dep_number}. "
                        f"Available steps: {sorted(step_map.keys())}. "
                        "Check your dependencies configuration."
                    )

        # Validate no cycles
        self._validate_no_cycles(step_map)

        return list(step_map.values())

    def _validate_no_cycles(self, nodes: dict[int, ExecutionNode]) -> None:
        """
        Validate that the execution graph has no cycles.

        Args:
            nodes: Dictionary of execution nodes

        Raises:
            ValueError: If cycles are detected
        """
        visited = set()
        rec_stack = set()

        def has_cycle(node_num: int) -> bool:
            visited.add(node_num)
            rec_stack.add(node_num)

            node = nodes[node_num]
            for dep in node.dependencies:
                if dep.step.number not in visited:
                    if has_cycle(dep.step.number):
                        return True
                elif dep.step.number in rec_stack:
                    return True

            rec_stack.remove(node_num)
            return False

        for node_num in nodes:
            if node_num not in visited:
                if has_cycle(node_num):
                    raise ValueError(f"Cycle detected in execution graph involving step {node_num}")

    async def execute_step(self, node: ExecutionNode, context: ReasoningContext) -> StepExecutionResult:
        """
        Execute a single step using the appropriate executor based on step type.

        Args:
            node: Execution node to execute
            context: Reasoning context

        Returns:
            Step execution result
        """
        step = node.step
        start_time = time.time()

        # Log step start
        log_step_start(step.number, step.title, str(step.step_type))

        # Get per-step timeout (step override > chain default > None)
        step_timeout = getattr(step, "timeout", None) or self.timeout

        # Call step_start callback if registered
        if context.on_step_start:
            try:
                context.on_step_start(step.number, step.title)
            except Exception:
                # Don't fail execution if callback fails
                pass

        # Create a LangFuse span for this step if tracing is active
        trace = context.metadata.get("__langfuse_trace")
        span = None
        if trace is not None:
            span_input: dict[str, Any] = {
                "step_type": str(step.step_type),
                "number": step.number,
                "title": step.title,
                "dependencies": getattr(step, "dependencies", []),
            }

            # Add step-type-specific details to span input
            step_config = getattr(step, "step_config", None)
            if step_config is not None:
                from .models import StepType as ST

                if step.step_type == ST.TOOL:
                    span_input["tool_name"] = getattr(step_config, "tool_name", None)
                    span_input["input_mapping"] = getattr(step_config, "input_mapping", {})
                elif step.step_type == ST.MEMORY:
                    span_input["operation"] = str(getattr(step_config, "operation", ""))
                    span_input["memory_key"] = getattr(step_config, "memory_key", "")
                    span_input["namespace"] = getattr(step_config, "namespace", "default")
                elif step.step_type == ST.TRANSFORM:
                    span_input["transform_type"] = getattr(step_config, "transform_type", "")
                    span_input["input_key"] = getattr(step_config, "input_key", "")
                elif step.step_type == ST.MCP:
                    span_input["tool_name"] = getattr(step_config, "tool_name", None)
                    server = getattr(step_config, "server", None)
                    if server:
                        span_input["server_name"] = getattr(server, "server_name", "")
                elif step.step_type == ST.CONDITIONAL:
                    span_input["condition_key"] = getattr(step_config, "condition_context_key", "")

            span = trace.start_span(
                name=f"step_{step.number}: {step.title}",
                input=span_input,
            )
            context.metadata["__langfuse_span"] = span

        # Get the appropriate executor for this step type
        executor = get_executor(step.step_type)

        # Execute the step with optional per-step timeout
        try:
            if step_timeout is not None:
                result = await asyncio.wait_for(
                    executor.execute(step, context, self.prompt_template), timeout=step_timeout
                )
            else:
                result = await executor.execute(step, context, self.prompt_template)
        except asyncio.TimeoutError:
            result = StepExecutionResult(
                step_number=step.number,
                step_title=step.title,
                step_type=step.step_type,
                result="",
                success=False,
                error_message=f"Step timed out after {step_timeout}s",
            )

        # End the span with step outcome
        if span is not None:
            end_output: dict[str, Any] = {"success": result.success}
            if result.result:
                end_output["result"] = result.result[:1000]
            if result.result_data is not None:
                try:
                    import json as _json

                    serialized = _json.dumps(result.result_data, default=str)
                    end_output["result_data"] = _json.loads(serialized)
                except (TypeError, ValueError):
                    end_output["result_data"] = str(result.result_data)[:1000]
            if result.error_message:
                end_output["error"] = result.error_message
            if result.execution_time:
                end_output["execution_time"] = result.execution_time
            span.update(output=end_output)
            span.end()
            context.metadata.pop("__langfuse_span", None)

        # Call step_complete callback if registered
        if context.on_step_complete:
            try:
                context.on_step_complete(result)
            except Exception:
                # Don't fail execution if callback fails
                pass

        # Log step completion
        log_step_complete(step.number, result.success, time.time() - start_time)

        return result

    async def execute_batch(
        self, ready_nodes: list[ExecutionNode], context: ReasoningContext
    ) -> list[StepExecutionResult]:
        """
        Execute a batch of ready nodes in parallel.

        Args:
            ready_nodes: list of nodes ready for execution
            context: Reasoning context

        Returns:
            list of step execution results
        """
        if not ready_nodes:
            return []

        # Create independent contexts for parallel execution
        context_snapshots = []
        try:
            for _ in ready_nodes:
                snapshot = ReasoningContext(
                    outer_context=context.outer_context,
                    api=context.api,
                    endpoint_key=context.endpoint_key,
                    retry_max=context.retry_max,
                    history=context.history.copy(),
                    metadata=context.metadata.copy(),
                    language=context.language,
                    system_prompt=context.system_prompt,
                    memory=copy.deepcopy(context.memory),  # Deep copy memory for isolation
                    max_history_entries=context.max_history_entries,
                    # Preserve callbacks
                    on_step_start=context.on_step_start,
                    on_step_complete=context.on_step_complete,
                    on_progress=context.on_progress,
                    on_llm_chunk=context.on_llm_chunk,
                )
                # Copy tool registry (shallow copy is fine for callables)
                snapshot._tool_registry = context._tool_registry.copy()
                # Preserve cancellation state
                snapshot._cancelled = context._cancelled
                context_snapshots.append(snapshot)

            # Execute in parallel
            tasks = [self.execute_step(node, ctx) for node, ctx in zip(ready_nodes, context_snapshots)]

            if self.max_workers == 1:
                results = [(await task) for task in tasks]
            else:
                results = await gather_with_limit(*tasks, return_exceptions=True, max_workers=self.max_workers)

            # Process results and handle exceptions
            processed_results = []
            import traceback as _traceback
            for i, result in enumerate(results):
                if isinstance(result, Exception):
                    error_tb = _traceback.format_exception(type(result), result, result.__traceback__)
                    processed_results.append(
                        StepExecutionResult(
                            step_number=ready_nodes[i].step.number,
                            step_title=ready_nodes[i].step.title,
                            step_type=ready_nodes[i].step.step_type,
                            result="",
                            success=False,
                            error_message=str(result),
                            error_traceback="".join(error_tb),
                        )
                    )
                else:
                    processed_results.append(result)

            # Merge memory changes back from successful parallel steps
            # Memory writes in parallel steps are now visible to subsequent batches
            for i, result in enumerate(processed_results):
                if result.success and context_snapshots[i].memory:
                    for namespace, data in context_snapshots[i].memory.items():
                        if namespace not in context.memory:
                            context.memory[namespace] = {}
                        # Merge the namespace data
                        context.memory[namespace].update(data)

            return processed_results
        finally:
            # Close all snapshot contexts to prevent event loop issues
            # (Each snapshot creates its own LLM clients via model_post_init)
            # This ensures cleanup even if an exception occurs during execution
            for snapshot in context_snapshots:
                try:
                    await snapshot.close()
                except Exception:
                    pass  # Don't fail if cleanup fails

    async def execute(self, steps: list[StepDescription], context: ReasoningContext) -> ReasoningResult:
        """
        Execute a complete reasoning chain.

        Args:
            steps: list of step descriptions
            context: Initial reasoning context

        Returns:
            Complete reasoning result

        Raises:
            TimeoutError: If execution exceeds the configured timeout
            ExecutionCancelledError: If cancellation is requested via context.cancel()
        """
        start_time = time.time()
        self._execution_stats["total_steps"] = len(steps)

        # Reset cancellation state for new execution
        context.reset_cancellation()

        # Create a LangFuse trace for this chain execution (no-op when disabled)
        chain_meta = context.metadata.get("chain_metadata", {})
        chain_name = chain_meta.get("trace_name") or chain_meta.get("name", "*Unnamed CARL Chain*")
        session_id = chain_meta.get("session_id")

        # Log chain start
        log_chain_start(chain_name, len(steps), self.max_workers)
        trace = create_chain_trace(
            chain_name=chain_name,
            context_preview=context.outer_context,
            total_steps=len(steps),
            language=str(context.language),
            session_id=session_id,
        )
        context.metadata["__langfuse_trace"] = trace

        # Build execution graph
        nodes = self.build_execution_graph(steps)
        if not nodes:
            trace.update(output={"success": True, "executed_steps": 0})
            trace.end()
            result = ReasoningResult(
                success=True, history=[], step_results=[], total_execution_time=time.time() - start_time
            )
            if context.on_chain_complete:
                try:
                    context.on_chain_complete(result)
                except Exception:
                    pass
            return result

        # Execute DAG
        executed_nodes: set[int] = set()
        all_results: list[StepExecutionResult] = []
        current_history = context.history.copy()
        batch_count = 0
        cancelled = False

        while len(executed_nodes) < len(nodes):
            # Check for cancellation
            if context.is_cancelled():
                cancelled = True
                break

            # Check for timeout
            if self.timeout is not None and (time.time() - start_time) > self.timeout:
                raise TimeoutError(
                    f"Chain execution timed out after {self.timeout}s. "
                    f"Completed {len(executed_nodes)}/{len(nodes)} steps."
                )

            # Find ready nodes
            ready_nodes = [node for node in nodes if node.step.number not in executed_nodes and node.can_execute()]

            if not ready_nodes:
                # This should not happen in a valid DAG
                remaining = [n.step.number for n in nodes if n.step.number not in executed_nodes]
                raise ValueError(
                    f"Deadlock detected: unable to execute steps {remaining}. "
                    f"Check for missing dependencies or circular references."
                )

            batch_count += 1
            log_batch_start(batch_count, len(ready_nodes))
            if self.enable_progress:
                print(f"Executing batch {batch_count} with {len(ready_nodes)} steps")

            # Call on_progress callback if registered
            if context.on_progress:
                try:
                    context.on_progress(len(executed_nodes), len(nodes))
                except Exception:
                    pass

            # Execute batch
            batch_results = await self.execute_batch(ready_nodes, context)
            all_results.extend(batch_results)

            # Update history from successful results
            # Sort by step number to maintain deterministic order
            batch_results.sort(key=lambda r: r.step_number)
            seen_steps = set()

            for result in batch_results:
                if result.success and result.step_number not in seen_steps:
                    # Add the latest history entry from this step
                    if result.updated_history:
                        new_entry = result.updated_history[-1]
                        # FIX: Use add_to_history() to enforce max_history_entries limit
                        context.add_to_history(new_entry)
                        seen_steps.add(result.step_number)

            # Sync current_history with context (may have been trimmed by max_history_entries)
            current_history = context.history.copy()

            # Mark nodes as executed
            for node in ready_nodes:
                node.executed = True
                executed_nodes.add(node.step.number)

            # Store step results into metadata for downstream references ($steps.<step_number>...)
            context.metadata.setdefault("step_results", {})
            for result in batch_results:
                if result.success:
                    context.metadata["step_results"][str(result.step_number)] = {
                        "step_number": result.step_number,
                        "title": result.step_title,
                        "step_type": str(result.step_type),
                        "result": result.result,
                        "result_data": result.result_data,
                    }
                    context.metadata[f"step_{result.step_number}"] = (
                        result.result_data if result.result_data is not None else result.result
                    )

        # Calculate final stats
        total_time = time.time() - start_time
        successful_steps = [r for r in all_results if r.success]
        failed_steps = [r for r in all_results if not r.success]

        self._execution_stats.update(
            {
                "executed_steps": len(successful_steps),
                "failed_steps": len(failed_steps),
                "parallel_batches": batch_count,
                "total_time": total_time,
            }
        )

        # Determine success (false if cancelled)
        chain_success = len(failed_steps) == 0 and not cancelled

        # Aggregate token usage from all steps
        total_tokens = {"prompt": 0, "completion": 0, "total": 0}
        for step_result in all_results:
            if step_result.token_usage:
                total_tokens["prompt"] += step_result.token_usage.get("prompt", 0)
                total_tokens["completion"] += step_result.token_usage.get("completion", 0)
        total_tokens["total"] = total_tokens["prompt"] + total_tokens["completion"]

        # Build final output for trace
        trace_output: dict[str, Any] = {
            "success": chain_success,
            "executed_steps": len(successful_steps),
            "failed_steps": len(failed_steps),
            "cancelled": cancelled,
            "total_execution_time": total_time,
            "token_usage": total_tokens,
        }
        # Include the final step result in trace output
        if successful_steps:
            last_successful = max(successful_steps, key=lambda r: r.step_number)
            if last_successful.result:
                trace_output["final_output"] = last_successful.result[:2000]

        # Update trace with final chain outcome
        trace.update(
            output=trace_output,
        )

        # End the trace to complete it in Langfuse
        trace.end()

        result = ReasoningResult(
            success=chain_success,
            history=current_history,
            step_results=all_results,
            total_execution_time=total_time,
            token_usage=total_tokens,
            metadata={
                "execution_stats": self._execution_stats.copy(),
                "parallel_batches": batch_count,
                "cancelled": cancelled,
            },
        )

        # Call chain_complete callback if registered
        if context.on_chain_complete:
            try:
                context.on_chain_complete(result)
            except Exception:
                pass

        # Log chain completion
        log_chain_complete(chain_success, total_time, len(successful_steps), len(steps))

        # Raise cancellation error after cleanup
        if cancelled:
            raise ExecutionCancelledError(
                f"Chain execution cancelled after completing {len(executed_nodes)}/{len(nodes)} steps. "
                "Partial results are available in the returned ReasoningResult."
            )

        return result

    def get_execution_stats(self) -> dict[str, Any]:
        """Get execution statistics from the last run."""
        return self._execution_stats.copy()
