"""
Abstract base classes for CARL reasoning system.
"""

from abc import ABC, abstractmethod
from typing import List


class LLMClientBase(ABC):
    """Abstract base class for LLM clients."""

    @abstractmethod
    async def get_response(self, prompt: str) -> str:
        """
        Get a response from the LLM.

        Args:
            prompt: The prompt to send to the LLM

        Returns:
            The LLM response as a string
        """
        pass

    @abstractmethod
    async def get_response_with_retries(self, prompt: str, retries: int = 3) -> str:
        """
        Get a response from the LLM with retry logic.

        Args:
            prompt: The prompt to send to the LLM
            retries: Maximum number of retry attempts

        Returns:
            The LLM response as a string
        """
        pass


class SearchStrategy(ABC):
    """Abstract base class for search strategies."""

    @abstractmethod
    def extract_context(self, outer_context: str, queries: List[str], **kwargs) -> str:
        """
        Extract relevant context from outer_context using queries.

        Args:
            outer_context: The full context data to search through
            queries: List of queries to find relevant context
            **kwargs: Additional strategy-specific parameters

        Returns:
            String containing relevant context found for each query
        """
        pass
