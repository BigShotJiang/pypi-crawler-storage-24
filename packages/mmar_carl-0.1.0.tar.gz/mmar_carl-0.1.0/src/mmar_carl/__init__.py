"""
MMAR CARL (Collaborative Agent Reasoning Library)

A library for building chain-of-thought reasoning systems with DAG-based parallel execution.
Supports multiple step types: LLM, Tool, MCP, Memory, Transform, and Conditional.

Module Structure:
- mmar_carl.models: Package containing all data models (re-exports all for convenience)
  - mmar_carl.models.enums: StepType, MemoryOperation, Language
  - mmar_carl.models.base: LLMClientBase, SearchStrategy
  - mmar_carl.models.search: SubstringSearchStrategy, VectorSearchStrategy, ContextSearchConfig
  - mmar_carl.models.config: ToolParameter, ToolStepConfig, MCPStepConfig, MemoryStepConfig, etc.
  - mmar_carl.models.steps: StepDescriptionBase, LLMStepDescription, ToolStepDescription, etc.
  - mmar_carl.models.context: ReasoningContext
  - mmar_carl.models.results: StepExecutionResult, ReasoningResult
  - mmar_carl.models.prompts: PromptTemplate

Step Description Classes (New API):
- StepDescriptionBase: Abstract base class for all steps
- LLMStepDescription: LLM reasoning steps
- ToolStepDescription: External tool/function execution
- MCPStepDescription: MCP protocol calls
- MemoryStepDescription: Memory operations
- TransformStepDescription: Data transformations
- ConditionalStepDescription: Conditional branching
- AnyStepDescription: Union type of all step types
- create_step(): Factory function for creating typed steps

Legacy API (Backward Compatible):
- StepDescription: Unified class supporting all step types
"""

from .chain import ChainBuilder, ReasoningChain, ReflectionOptions, create_chain_from_config
from .executor import DAGExecutor, ExecutionCancelledError
from .tracing import flush as langfuse_flush, is_langfuse_enabled
from .llm import (
    OpenAIClientConfig,
    OpenAICompatibleClient,
    create_llm_client,
    create_openai_client,
)
from .models import (
    # Enums
    Language,
    MemoryOperation,
    StepType,
    # Abstract base classes
    LLMClientBase,
    SearchStrategy,
    # Search & Context
    ContextQuery,
    ContextSearchConfig,
    SubstringSearchStrategy,
    VectorSearchStrategy,
    # Step Configurations
    ConditionalBranch,
    ConditionalStepConfig,
    LLMStepConfig,
    MCPServerConfig,
    MCPStepConfig,
    MemoryStepConfig,
    StepConfig,
    ToolParameter,
    ToolStepConfig,
    TransformStepConfig,
    StructuredOutputStepConfig,
    # Step Description Classes (New API)
    AnyStepDescription,
    ConditionalStepDescription,
    LLMStepDescription,
    MCPStepDescription,
    MemoryStepDescription,
    StepDescriptionBase,
    ToolStepDescription,
    TransformStepDescription,
    StructuredOutputStepDescription,
    create_step,
    # Legacy Step Description (Backward Compatible)
    StepDescription,
    # Execution Context & Results
    PromptTemplate,
    ReasoningContext,
    ReasoningResult,
    StepExecutionResult,
)
from .step_executors import (
    ConditionalStepExecutor,
    LLMStepExecutor,
    MCPStepExecutor,
    MemoryStepExecutor,
    StepExecutorBase,
    ToolStepExecutor,
    TransformStepExecutor,
    StructuredOutputStepExecutor,
    get_executor,
    register_executor,
)
from .logging_utils import (
    get_logger,
    set_log_level,
    log_chain_start,
    log_chain_complete,
    log_step_start,
    log_step_complete,
    log_batch_start,
    log_error,
    log_warning,
    log_debug,
    log_info,
)

__version__ = "0.1.0"
__all__ = [
    # Core Chain Classes
    "ReasoningChain",
    "ChainBuilder",
    "DAGExecutor",
    "create_chain_from_config",
    # Reflection
    "ReflectionOptions",
    # Exceptions
    "ExecutionCancelledError",
    # Enums
    "Language",
    "MemoryOperation",
    "StepType",
    # Abstract Base Classes
    "LLMClientBase",
    "SearchStrategy",
    # Search & Context
    "ContextQuery",
    "ContextSearchConfig",
    "SubstringSearchStrategy",
    "VectorSearchStrategy",
    # Step Configurations
    "ConditionalBranch",
    "ConditionalStepConfig",
    "LLMStepConfig",
    "MCPServerConfig",
    "MCPStepConfig",
    "MemoryStepConfig",
    "StepConfig",
    "ToolParameter",
    "ToolStepConfig",
    "TransformStepConfig",
    "StructuredOutputStepConfig",
    # Step Description Classes (New API)
    "AnyStepDescription",
    "ConditionalStepDescription",
    "LLMStepDescription",
    "MCPStepDescription",
    "MemoryStepDescription",
    "StepDescriptionBase",
    "ToolStepDescription",
    "TransformStepDescription",
    "StructuredOutputStepDescription",
    "create_step",
    # Legacy Step Description (Backward Compatible)
    "StepDescription",
    # Execution Context & Results
    "PromptTemplate",
    "ReasoningContext",
    "ReasoningResult",
    "StepExecutionResult",
    # Tracing
    "langfuse_flush",
    "is_langfuse_enabled",
    # LLM
    "create_llm_client",
    "create_openai_client",
    "OpenAIClientConfig",
    "OpenAICompatibleClient",
    # Step Executors
    "ConditionalStepExecutor",
    "LLMStepExecutor",
    "MCPStepExecutor",
    "MemoryStepExecutor",
    "StepExecutorBase",
    "ToolStepExecutor",
    "TransformStepExecutor",
    "StructuredOutputStepExecutor",
    "get_executor",
    "register_executor",
    # Logging
    "get_logger",
    "set_log_level",
    "log_chain_start",
    "log_chain_complete",
    "log_step_start",
    "log_step_complete",
    "log_batch_start",
    "log_error",
    "log_warning",
    "log_debug",
    "log_info",
]
