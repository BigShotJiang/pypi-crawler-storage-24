from setuptools import setup
from setuptools import find_packages
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent

readme_path = ROOT_DIR / "Readme.md"
if readme_path.exists():
    with readme_path.open("r", encoding="utf-8") as fh:
        long_description = fh.read()
else:
    long_description = "Source code for APIs for STEAM tools."

with (ROOT_DIR / "requirements.txt").open("r", encoding="utf-8") as f:
    required = f.read().splitlines()

docs_require = [
    "Markdown==3.8",
    "markdown-include==0.8.1",
    "MarkupSafe==2.1.5",
    "mkdocs==1.6.1",
    "mkdocs-autorefs==1.4.1",
    "mkdocs-git-revision-date-localized-plugin==1.4.5",
    "mkdocs-include-markdown-plugin==7.1.5",
    "mkdocs-material==9.6.14",
    "mkdocs-material-extensions==1.3.1",
    "mkdocstrings==0.29.0",
    "mkdocstrings-python==1.16.10",
    "Pygments==2.17.2",
    "pymdown-extensions==10.7.1",
]

tests_require = [
    "coverage==7.4.3",
    "coverage-badge==1.1.0",
    "griffe==1.7.3",
    "pytest==8.1.1",
    "pytest-cov==4.1.0",
]

build_require = ["setuptools==69.2.0",
                 "twine==6.1.0"]

all_requirements = required + docs_require + tests_require + build_require

setup(
    name="steam_sdk",
    version="2026.3.2",
    author="STEAM Team",
    author_email="steam-team@cern.ch",
    description="Source code for APIs for STEAM tools.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://gitlab.cern.ch/steam/steam_sdk",
    keywords={"STEAM", "API", "SDK", "CERN"},
    install_requires=required,
    extras_require={
        "all": all_requirements,
        "docs": docs_require,
        "test": tests_require,
        "build": build_require,
    },
    python_requires=">=3.11",
    include_package_data=True,
    package_data={'': ['call_ledet_htcondor.sh', 'call_mainfiqus_htcondor.sh']},
    packages=find_packages(),
    classifiers=["Programming Language :: Python :: 3.11"],
)
