"""The mock_event_generator package.

This package downloads and caches existing G-Events from GraceDB and translates them
in time in order to produce new events, but with the same characteristics as the old
ones.
"""

import logging

from .creators import GEventCreator, SEventCreator
from .fetchers import GEventFetcher, SEventFetcher

__all__ = [
    'GEventCreator',
    'SEventCreator',
    'GEventFetcher',
    'SEventFetcher',
]

logging.basicConfig(
    format='%(asctime)s %(levelname)-8s %(message)s',
    level=logging.INFO,
    datefmt='%Y-%m-%d %H:%M:%S',
)

# ----- Disable scitoken INFO logs ------
logging.getLogger('scitokens').setLevel(logging.ERROR)
