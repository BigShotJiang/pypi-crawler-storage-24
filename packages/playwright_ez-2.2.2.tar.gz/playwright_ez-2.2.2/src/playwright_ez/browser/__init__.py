"""
浏览器模块

提供简化浏览器操作的核心类。
"""
from .tab import Tab
from .core import BrowserCore
from .mixins import (
    TabManagerMixin,
    NavigationMixin,
    ElementsMixin,
    WindowMixin,
    BatchMixin,
    PropertiesMixin,
)


class EasyBrowser(
    PropertiesMixin,
    BatchMixin,
    WindowMixin,
    ElementsMixin,
    NavigationMixin,
    TabManagerMixin,
    BrowserCore,
):
    """
    简化的浏览器操作类

    特性:
    - 多标签页支持
    - 自动元素高亮
    - 智能等待
    - 操作日志
    """

    pass


__all__ = [
    "EasyBrowser",
    "Tab",
    "BrowserCore",
    "TabManagerMixin",
    "NavigationMixin",
    "ElementsMixin",
    "WindowMixin",
    "BatchMixin",
    "PropertiesMixin",
]
