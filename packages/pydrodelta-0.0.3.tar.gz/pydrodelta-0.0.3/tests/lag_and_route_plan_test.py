from pydrodelta.plan import Plan
from unittest import TestCase
import yaml
import os
from pydrodelta.config import config
from pandas import DataFrame
from pathlib import Path

data_dir = Path(__file__).parent / "data"

class Test_LagAndRouteProcedure(TestCase):

    def test_run(self):
        plan = Plan.load(data_dir / "plans/lar_dummy.yml")
        self.assertEqual(plan.procedures[0].function.pars_list[0], 3)
        self.assertTrue(plan.procedures[0].function.pars_list[1], 0.5)
        self.assertTrue(plan.procedures[0].function.pars_list[2], 2)
        plan.topology.batchProcessInput()
        plan.execute(upload=False)
        self.assertGreaterEqual(len(plan.procedures[0].output[0]),31)
        self.assertEqual(type(plan.procedures[0].procedure_function_results.data),DataFrame)
        self.assertTrue("output" in plan.procedures[0].procedure_function_results.data)
        self.assertEqual(len(plan.procedures[0].procedure_function_results.data["output"].dropna()), 31)

    def test_run_no_output(self):
        plan = Plan.load(data_dir / "plans/lar_dummy_no_output.yml")
        plan.execute(upload=False)
        self.assertGreaterEqual(len(plan.procedures[0].output[0]),31)
        self.assertEqual(type(plan.procedures[0].procedure_function_results.data),DataFrame)
        self.assertTrue("output" in plan.procedures[0].procedure_function_results.data)
        self.assertEqual(len(plan.procedures[0].procedure_function_results.data["output"].dropna()), 31)



