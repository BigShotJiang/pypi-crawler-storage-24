from pydrodelta.plan import Plan
plan = Plan.load("/home/jbianchi/git_repos/pydrodelta/data_/plans/paraguay-transitos-cal.yml")
plan.topology.batchProcessInput()
procedure = plan.procedures[2]
procedure.calibration.run()
result = procedure.run()
procedure.outputToNodes()

result = procedure.calibration.result
result["scores"][0]

K = 1.96
[ (K * h["rse"],K * h["rse_val"]) for h in procedure.calibration.result["scores"]]