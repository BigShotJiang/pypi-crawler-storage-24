from pydrodelta.plan import Plan
plan = Plan.load("data_/plans/uruguay_medio.yml")
plan.execute(upload=True)