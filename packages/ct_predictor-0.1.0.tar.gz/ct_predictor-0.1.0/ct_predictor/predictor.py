# Copyright (c) 2026 Melissa Berteau-Rainville, Emanuele Orgiu, Ingo Salzmann
# This work is licensed under CC BY-NC-ND 4.0. 
# To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-nd/4.0/
import onnxruntime as rt
import os
import csv
import numpy as np


class MLPredictor:

    DEFAULT_MODELS = [
        "ML_32_32_32_32.onnx"
    ]
    
    def __init__(self, output_path="results.csv", model_dir=None, model_files=None):
        self.output_path = output_path
        
        if model_dir is None:
            model_dir = os.path.join(os.path.dirname(__file__), 'model')
        self.model_dir = model_dir
        
        if model_files is None:
            model_files = self.DEFAULT_MODELS
        self.model_files = model_files
        
        self.sessions = []
        self.input_name = None
        self.output_name = None
        
        self._load_models()
    
    def _load_models(self):
        print(f"Loading {len(self.model_files)} ONNX model...")
        
        for model_file in self.model_files:
            model_path = os.path.join(self.model_dir, model_file)
            
            if not os.path.exists(model_path):
                print(f"Warning: Model file not found: {model_path}")
                continue
            
            sess = rt.InferenceSession(model_path)
            self.sessions.append(sess)
            
            if self.input_name is None:
                self.input_name = sess.get_inputs()[0].name
                self.output_name = sess.get_outputs()[0].name
        
        if not self.sessions:
            raise RuntimeError("No ONNX models were successfully loaded!")
        
        print("Successfully loaded 1 model.")
    
    def _load_csv_data(self, file_path):
        data = []
        with open(file_path, 'r', newline='', encoding='utf-8-sig') as csvfile:
            reader = csv.reader(csvfile)
            for row in reader:
                data.append([float(x) for x in row])
        return np.array(data, dtype=np.float32)
    
    def predict(self, input_data):

        if isinstance(input_data, str) and input_data.endswith(".csv"):
            input_array = self._load_csv_data(input_data)
        elif isinstance(input_data, np.ndarray):
            input_array = input_data.astype(np.float32)
        else:
            input_array = np.array(input_data, dtype=np.float32)
        
        if input_array.ndim == 1:
            input_array = input_array.reshape(1, -1)
        
        print(f"Running inference on {input_array.shape[0]} samples...")
        
        # SINGLE MODEL ONLY
        sess = self.sessions[0]
        predictions = []
        
        for i in range(input_array.shape[0]):
            single_sample = input_array[i:i+1, :]
            result = sess.run([self.output_name], {self.input_name: single_sample})
            predictions.append(result[0])
        
        predictions = np.vstack(predictions)
        
        self._save_predictions(predictions)
        return predictions
    
    def _save_predictions(self, predictions):
        with open(self.output_path, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['Prediction1', 'Prediction2'])
            writer.writerows(predictions)
        print(f"Predictions written to {self.output_path}")
