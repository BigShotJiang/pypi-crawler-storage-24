# Copyright (c) 2026 Melissa Berteau-Rainville, Emanuele Orgiu, Ingo Salzmann
# This work is licensed under CC BY-NC-ND 4.0. 
# To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-nd/4.0/
from .predictor import MLPredictor