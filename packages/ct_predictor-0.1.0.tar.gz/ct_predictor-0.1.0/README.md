# Copyright (c) 2026 Melissa Berteau-Rainville, Emanuele Orgiu, Ingo Salzmann
# This work is licensed under CC BY-NC-ND 4.0. 
# To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-nd/4.0/

## Citation

If you use **ct_predictor** in your research, please cite the following paper:

> Berteau-Rainville, M., et al. (2026). "Title of the Paper." *Journal Name*, Volume(Issue), pages. DOI: [10.1038/s41524-026-XXXX-X](https://doi.org/10.1038/s41524-026-XXXX-X)

```bibtex
@article{BerteauRainville2026,
  title={Title of the Paper},
  author={Berteau-Rainville, Melissa and Co-author, A. and Co-author, B.},
  journal={Journal Name},
  year={2026},
  doi={10.1038/s41524-026-XXXX-X},
  url={[https://github.com/yourusername/ct_predictor](https://github.com/yourusername/ct_predictor)}
}

## Support and Contact

If you have questions regarding the **software implementation**, bug reports, or feature requests, please:
* **Open an Issue:** Use the [GitHub Issue Tracker](https://github.com/yourusername/ct_predictor/issues).
* **GitHub Profile:** Reach out via the email listed on the maintainer's GitHub profile.

For inquiries regarding the **underlying research, methodology, or theoretical framework**, please direct your queries to the **corresponding author** of the associated paper:
* **Paper:** [Title of your Published Paper]
* **DOI:** [10.1038/s41524-026-XXXX-X](https://doi.org/10.1038/s41524-026-XXXX-X)

# ct_predictor

Predict charge transfer properties from CSV input using a neural network stored in ONNX format.

## Installation

```
pip install ct_predictor
```

## Usage

```python
from ct_predictor.predictor import MLPredictor

p = MLPredictor(output_path="results.csv")
p.predict("inputs.csv")
```