import os
from ct_predictor.predictor import MLPredictor

TEST_DIR = os.path.dirname(os.path.abspath(__file__))

input_path = os.path.join(TEST_DIR, "inputs.csv")
output_path = os.path.join(TEST_DIR, "results.csv")
reference_path = os.path.join(TEST_DIR, "results_reference.csv")

predictor = MLPredictor(output_path=output_path)

print(f"Running prediction on: {input_path}")
predictor.predict(input_path)

exit()