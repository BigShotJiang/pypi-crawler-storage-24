"""API client for Veris backend."""

from typing import Any, Optional

import httpx

from veris_cli.config import Config


class APIError(Exception):
    """Raised when the backend returns an error response with details."""

    def __init__(self, status_code: int, detail: str, url: str):
        self.status_code = status_code
        self.detail = detail
        self.url = url
        super().__init__(f"[{status_code}] {detail} ({url})")


def _raise_for_status(response: httpx.Response) -> None:
    """Like response.raise_for_status() but includes the response body."""
    if response.is_success:
        return
    try:
        body = response.json()
        detail = body.get("detail", response.text)
    except Exception:
        detail = response.text or response.reason_phrase
    raise APIError(response.status_code, detail, str(response.url))


class VerisAPI:
    """Simple HTTP client for Veris backend API."""

    def __init__(self, profile: str | None = None):
        config = Config(profile=profile)
        self.api_key = config.get_api_key()
        self.base_url = config.get_backend_url()
        self.organization_id = config.get_organization_id()

        if not self.api_key:
            profile_name = config.profile
            raise ValueError(
                f"No API key found for profile '{profile_name}'. "
                f"Run 'veris login --profile {profile_name}' first."
            )

    def _headers(self) -> dict:
        """Get request headers with auth."""
        return {"Authorization": f"Bearer {self.api_key}"}

    # Environments
    def create_environment(self, name: str, description: Optional[str] = None) -> dict[str, Any]:
        """Create a new environment (one-time setup)."""
        payload: dict[str, Any] = {"name": name, "description": description}
        if self.organization_id:
            payload["organization_id"] = self.organization_id
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.post("/v1/environments", json=payload)
            _raise_for_status(response)
            return response.json()

    def create_environment_tag(self, environment_id: str, tag: str = "latest") -> dict[str, Any]:
        """Create a new tag for an environment and get push credentials."""
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.post(
                f"/v1/environments/{environment_id}/tags",
                json={"tag": tag},
            )
            _raise_for_status(response)
            return response.json()

    def list_environments(
        self, status: Optional[str] = None, limit: int = 20, offset: int = 0
    ) -> dict[str, Any]:
        """List environments."""
        params = {"limit": limit, "offset": offset}
        if status:
            params["status"] = status
        if self.organization_id:
            params["organization_id"] = self.organization_id
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.get("/v1/environments", params=params)
            _raise_for_status(response)
            return response.json()

    # Builds (Cloud Build)
    def create_build(self, environment_id: str, tag: str = "latest") -> dict[str, Any]:
        """Create a build and get a signed upload URL."""
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.post(
                f"/v1/environments/{environment_id}/builds",
                json={"tag": tag},
            )
            _raise_for_status(response)
            return response.json()

    def notify_build_uploaded(self, environment_id: str, build_id: str) -> dict[str, Any]:
        """Notify that the build context tarball has been uploaded."""
        with httpx.Client(base_url=self.base_url, headers=self._headers(), timeout=30) as client:
            response = client.post(
                f"/v1/environments/{environment_id}/builds/{build_id}/uploaded",
            )
            _raise_for_status(response)
            return response.json()

    def get_build_status(self, environment_id: str, build_id: str) -> dict[str, Any]:
        """Poll build status."""
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.get(
                f"/v1/environments/{environment_id}/builds/{build_id}",
            )
            _raise_for_status(response)
            return response.json()

    def delete_environment(self, env_id: str) -> None:
        """Delete an environment."""
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.delete(f"/v1/environments/{env_id}")
            _raise_for_status(response)

    # Scenario Sets
    def list_scenario_sets(
        self, environment_id: Optional[str] = None, limit: int = 100, skip: int = 0
    ) -> list[dict[str, Any]]:
        """List scenario sets."""
        params = {"limit": limit, "skip": skip}
        if environment_id:
            params["environment_id"] = environment_id
        if self.organization_id:
            params["organization_id"] = self.organization_id
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.get("/v1/scenario-sets", params=params)
            _raise_for_status(response)
            return response.json()

    def get_scenario_set(self, set_id: str) -> dict[str, Any]:
        """Get scenario set details."""
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.get(f"/v1/scenario-sets/{set_id}")
            _raise_for_status(response)
            return response.json()

    # Runs
    def create_run(
        self,
        scenario_set_id: str,
        environment_id: str,
        parallel_jobs: int = 10,
        config: Optional[dict] = None,
    ) -> dict[str, Any]:
        """Create a new run."""
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.post(
                "/v1/runs",
                json={
                    "scenario_set_id": scenario_set_id,
                    "environment_id": environment_id,
                    "parallel_jobs": parallel_jobs,
                    "config": config or {},
                },
            )
            _raise_for_status(response)
            return response.json()

    def list_runs(
        self,
        status: Optional[str] = None,
        environment_id: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> dict[str, Any]:
        """List runs."""
        params = {"limit": limit, "offset": offset}
        if status:
            params["status"] = status
        if environment_id:
            params["environment_id"] = environment_id
        if self.organization_id:
            params["organization_id"] = self.organization_id
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.get("/v1/runs", params=params)
            _raise_for_status(response)
            return response.json()

    def get_run(self, run_id: str) -> dict[str, Any]:
        """Get run details."""
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.get(f"/v1/runs/{run_id}")
            _raise_for_status(response)
            return response.json()

    def cancel_run(self, run_id: str) -> None:
        """Cancel a run."""
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.delete(f"/v1/runs/{run_id}")
            _raise_for_status(response)

    def get_run_events(self, run_id: str, limit: int = 100, offset: int = 0) -> dict[str, Any]:
        """Get run events/logs."""
        params = {"limit": limit, "offset": offset}
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.get(f"/v1/runs/{run_id}/events", params=params)
            _raise_for_status(response)
            return response.json()

    def list_run_simulations(self, run_id: str) -> dict[str, Any]:
        """List simulations for a run."""
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.get(f"/v1/runs/{run_id}/simulations")
            _raise_for_status(response)
            return response.json()

    def get_simulation_result(self, run_id: str, sim_id: str) -> dict[str, Any]:
        """Get simulation result summary."""
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.get(f"/v1/runs/{run_id}/simulations/{sim_id}/result")
            _raise_for_status(response)
            return response.json()

    # Scenario Generation
    def generate_scenario_set(
        self,
        environment_id: str,
        num_scenarios: int = 5,
        image_tag: Optional[str] = None,
    ) -> dict[str, Any]:
        """Trigger async scenario + grader generation via K8s job."""
        payload: dict[str, Any] = {
            "environment_id": environment_id,
            "num_scenarios": num_scenarios,
        }
        if image_tag:
            payload["image_tag"] = image_tag
        with httpx.Client(base_url=self.base_url, headers=self._headers(), timeout=30) as client:
            response = client.post("/v1/scenario-sets/generate", json=payload)
            _raise_for_status(response)
            return response.json()

    # Graders
    def list_graders(
        self,
        environment_id: str,
        scenario_set_id: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> dict[str, Any]:
        """List graders for an environment."""
        params: dict[str, Any] = {
            "environment_id": environment_id,
            "limit": limit,
            "offset": offset,
        }
        if scenario_set_id:
            params["scenario_set_id"] = scenario_set_id
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.get("/v1/graders", params=params)
            _raise_for_status(response)
            return response.json()

    # Evaluations
    def trigger_evaluation(self, run_id: str, grader_id: str) -> dict[str, Any]:
        """Trigger grading on a completed run."""
        with httpx.Client(base_url=self.base_url, headers=self._headers(), timeout=30) as client:
            response = client.post(
                f"/v1/runs/{run_id}/evaluate",
                params={"grader_id": grader_id},
            )
            _raise_for_status(response)
            return response.json()

    def list_evaluation_runs(self, run_id: str, limit: int = 20, offset: int = 0) -> dict[str, Any]:
        """List evaluation runs for a given run."""
        params = {"limit": limit, "offset": offset}
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.get(f"/v1/runs/{run_id}/evaluation-runs", params=params)
            _raise_for_status(response)
            return response.json()

    def get_evaluation_run(self, run_id: str, eval_run_id: str) -> dict[str, Any]:
        """Get evaluation run details including per-simulation results."""
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.get(f"/v1/runs/{run_id}/evaluation-runs/{eval_run_id}")
            _raise_for_status(response)
            return response.json()

    # Environment Variables
    def list_environment_variables(self, environment_id: str) -> dict[str, Any]:
        """List environment variables for an environment."""
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.get(f"/v1/environments/{environment_id}/variables")
            _raise_for_status(response)
            return response.json()

    def upsert_environment_variables(
        self, environment_id: str, variables: list[dict[str, Any]]
    ) -> dict[str, Any]:
        """Create or update environment variables."""
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.post(
                f"/v1/environments/{environment_id}/variables",
                json={"variables": variables},
            )
            _raise_for_status(response)
            return response.json()

    def delete_environment_variable(self, environment_id: str, key: str) -> None:
        """Delete an environment variable by key."""
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.delete(f"/v1/environments/{environment_id}/variables/{key}")
            _raise_for_status(response)

    # Reports
    def generate_report(
        self, environment_id: str, evaluation_run_id: Optional[str] = None
    ) -> dict[str, Any]:
        """Trigger report generation for an evaluation run."""
        params: dict[str, Any] = {"environment_id": environment_id}
        if evaluation_run_id:
            params["evaluation_run_id"] = evaluation_run_id
        with httpx.Client(base_url=self.base_url, headers=self._headers(), timeout=30) as client:
            response = client.post("/v1/reports", params=params)
            _raise_for_status(response)
            return response.json()

    def list_reports(self, environment_id: str, limit: int = 20, offset: int = 0) -> dict[str, Any]:
        """List reports for an environment."""
        params: dict[str, Any] = {
            "environment_id": environment_id,
            "limit": limit,
            "offset": offset,
        }
        with httpx.Client(base_url=self.base_url, headers=self._headers()) as client:
            response = client.get("/v1/reports", params=params)
            _raise_for_status(response)
            return response.json()

    def get_report(self, report_id: str) -> dict[str, Any]:
        """Get report details including html_content."""
        with httpx.Client(base_url=self.base_url, headers=self._headers(), timeout=60) as client:
            response = client.get(f"/v1/reports/{report_id}")
            _raise_for_status(response)
            return response.json()
