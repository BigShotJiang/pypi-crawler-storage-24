#!/usr/bin/env bash
set -e

# Docker build script for Veris CLI
# Usage: docker_build.sh <dockerfile_path> <image_uri> <registry> <username> <password> [no_cache] [gvisor_base]

DOCKERFILE_PATH="$1"
IMAGE_URI="$2"
REGISTRY="$3"
USERNAME="$4"
PASSWORD="$5"
NO_CACHE="${6:-0}"  # Optional, defaults to 0 (use cache)
GVISOR_BASE="$7"    # Optional, overrides GVISOR_BASE build arg

if [ -z "$DOCKERFILE_PATH" ] || [ -z "$IMAGE_URI" ] || [ -z "$REGISTRY" ] || [ -z "$USERNAME" ] || [ -z "$PASSWORD" ]; then
    echo "Usage: $0 <dockerfile_path> <image_uri> <registry> <username> <password> [no_cache]"
    exit 1
fi

if [ ! -f "$DOCKERFILE_PATH" ]; then
    echo "Error: Dockerfile not found at $DOCKERFILE_PATH"
    exit 1
fi

# Use a temporary Docker config directory to avoid conflicts with
# system credential helpers (e.g., gcloud credHelper for gcr.io)
TEMP_DOCKER_CONFIG=$(mktemp -d)
export DOCKER_CONFIG="$TEMP_DOCKER_CONFIG"
trap "rm -rf $TEMP_DOCKER_CONFIG" EXIT

# Preserve credential helpers and CLI plugins from the default config.
# We only copy credHelpers (not the full config) to avoid importing
# Docker Desktop context references that break in the temp directory.
# Exclude the target registry from credHelpers so docker login token is used
# instead of a potentially-stale gcloud credential helper.
DEFAULT_DOCKER_CONFIG="${HOME}/.docker"
if [ -f "$DEFAULT_DOCKER_CONFIG/config.json" ]; then
    if command -v jq &> /dev/null; then
        jq --arg reg "$REGISTRY" '{"credHelpers": ((.credHelpers // {}) | del(.[$reg]))}' "$DEFAULT_DOCKER_CONFIG/config.json" > "$TEMP_DOCKER_CONFIG/config.json"
    fi
fi
if [ -d "$DEFAULT_DOCKER_CONFIG/cli-plugins" ]; then
    ln -s "$DEFAULT_DOCKER_CONFIG/cli-plugins" "$TEMP_DOCKER_CONFIG/cli-plugins"
fi

# Login to registry first so we can pull the base image
echo "Authenticating with Docker registry..."
echo "  Registry: $REGISTRY"
echo ""
echo "$PASSWORD" | docker login -u "$USERNAME" --password-stdin "$REGISTRY"

echo ""
echo "Building Docker image..."
echo "  Dockerfile: $DOCKERFILE_PATH"
echo "  Image URI: $IMAGE_URI"
echo ""

# Build for linux/amd64 (GKE target platform)
# Use DOCKER_BUILDKIT=1 with docker build instead of docker buildx build.
# buildx with the default builder on macOS Docker Desktop tries to resolve
# FROM images via registry metadata, failing for local-only base images
# (e.g. veris-gvisor:latest built by build-local.sh).
BUILD_ARGS="--platform linux/amd64 -f $DOCKERFILE_PATH -t $IMAGE_URI"
if [ -n "$GVISOR_BASE" ]; then
    BUILD_ARGS="$BUILD_ARGS --build-arg GVISOR_BASE=$GVISOR_BASE"
fi
if [ "$NO_CACHE" = "1" ]; then
    BUILD_ARGS="$BUILD_ARGS --no-cache"
fi
DOCKER_BUILDKIT=1 docker build $BUILD_ARGS .

echo ""
echo "✓ Image built successfully: $IMAGE_URI"
