# ---------------------------------------------------------------------
# Copyright (c) 2025 Qualcomm Technologies, Inc. and/or its subsidiaries.
# SPDX-License-Identifier: BSD-3-Clause
# ---------------------------------------------------------------------

from __future__ import annotations

import numpy as np
import torch
from PIL import Image

from qai_hub_models.datasets.common import BaseDataset, DatasetMetadata, DatasetSplit
from qai_hub_models.utils.asset_loaders import CachedWebDatasetAsset
from qai_hub_models.utils.image_processing import app_to_net_image_inputs

CAMO_FOLDER_NAME = "camo"
CAMO_VERSION = 1

# originally from the https://github.com/thograce/BGNet.git
CAMO_ASSET = CachedWebDatasetAsset.from_asset_store(
    CAMO_FOLDER_NAME,
    CAMO_VERSION,
    "TestDataset.zip",
)


class CamouflageDataset(BaseDataset):
    def __init__(
        self,
        dataset_names: list[str] | None = None,
        split: DatasetSplit = DatasetSplit.VAL,
        input_height: int = 416,
        input_width: int = 416,
    ) -> None:
        if dataset_names is None:
            dataset_names = ["CAMO", "CHAMELEON", "COD10K", "NC4K"]
        self.dataset_names = dataset_names
        self.input_height = input_height
        self.input_width = input_width
        BaseDataset.__init__(
            self, CAMO_ASSET.path(extracted=True) / "TestDataset", split
        )

    def __getitem__(self, index: int) -> tuple[torch.Tensor, torch.Tensor]:
        """
        Parameters
        ----------
        index
            Dataset element index

        Returns
        -------
        image : torch.Tensor
            Input image of shape [3, height, width]. RGB, range [0-1]
        gt : torch.Tensor
            Ground truth masks with shape [1, height, width]. uint8, range [0, 255]
        """
        orig_image = Image.open(self.images[index]).convert("RGB")
        orig_gt = Image.open(self.categories[index]).convert("L")

        image = orig_image.resize((self.input_width, self.input_height))
        gt_image = orig_gt.resize((self.input_width, self.input_height))

        _, img_tensor = app_to_net_image_inputs(image)
        img_tensor = img_tensor.squeeze(0)
        gt_array = torch.from_numpy(np.asarray(gt_image)).unsqueeze(0)
        return img_tensor, gt_array

    def __len__(self) -> int:
        return len(self.images)

    def _validate_data(self) -> bool:
        base_path = self.dataset_path
        self.im_ids = []
        self.images = []
        self.categories = []

        # Check if dataset path exists
        if not base_path.exists():
            return False

        # Iterate through datasets and collect image-annotation pairs
        for dataset_name in self.dataset_names:
            dataset_path = base_path / dataset_name
            img_dir = dataset_path / "Imgs"
            cat_dir = dataset_path / "GT"

            # Skip if directories don't exist
            if not img_dir.exists() or not cat_dir.exists():
                continue

            # Collect valid image-annotation pairs
            for image_path in sorted(img_dir.glob("*.jpg")):
                im_id = image_path.stem
                annot_path = cat_dir / f"{im_id}.png"
                if annot_path.exists():
                    self.im_ids.append(im_id)
                    self.images.append(image_path)
                    self.categories.append(annot_path)

        # Verify collected data
        return not (not self.images or len(self.images) != len(self.categories))

    def _download_data(self) -> None:
        CAMO_ASSET.fetch(extract=True)

    @staticmethod
    def default_samples_per_job() -> int:
        return 250

    @staticmethod
    def get_dataset_metadata() -> DatasetMetadata:
        return DatasetMetadata(
            link="https://github.com/thograce/BGNet.git",
            split_description="test split",
        )
