# ---------------------------------------------------------------------
# Copyright (c) 2025 Qualcomm Technologies, Inc. and/or its subsidiaries.
# SPDX-License-Identifier: BSD-3-Clause
# ---------------------------------------------------------------------


from __future__ import annotations

import torch
from py_sod_metrics import MAE, Emeasure, Smeasure, WeightedFmeasure

from qai_hub_models.evaluators.base_evaluators import BaseEvaluator, MetricMetadata
from qai_hub_models.models.bgnet.app import postprocess_masks


class CamouflageEvaluator(BaseEvaluator):
    """Evaluator for comparing segmentation output against ground truth"""

    def __init__(
        self, metrics: tuple[str, ...] = ("mae", "smeasure", "wfmeasure", "emeasure")
    ) -> None:
        self.metrics = metrics
        self.reset()

    def reset(self) -> None:
        self.sm = Smeasure()
        self.wfm = WeightedFmeasure()
        self.em = Emeasure()
        self.mae = MAE()
        self.results: dict = {m: [] for m in self.metrics}

    def add_batch(self, output: torch.Tensor, gt: torch.Tensor) -> None:
        """
        Process a batch of segmentation predictions and ground truth masks.

        Parameters
        ----------
        output
            model predicted masks with shape
            [batch_size, 1, height, width]
            float32, range (0 - 1)
        gt
            Ground truth masks with shape
            [batch_size, 1, height, width]
            uint8, range (0, 255)
        """
        # Resize predicted masks to the same size as the ground truth masks, convert prediction to uint8 [0, 255]
        pred_masks_np = postprocess_masks(output, gt.shape[-2:]).numpy()

        # Remove channel dimension from prediction and ground truth.
        pred_masks_np = pred_masks_np.squeeze(1)
        gt_masks_np = gt.numpy().squeeze(1)

        for b_out, b_gt in zip(pred_masks_np, gt_masks_np, strict=False):
            self.sm.step(pred=b_out, gt=b_gt, normalize=True)
            self.wfm.step(pred=b_out, gt=b_gt, normalize=True)
            self.em.step(pred=b_out, gt=b_gt, normalize=True)
            self.mae.step(pred=b_out, gt=b_gt, normalize=True)

    def smeasure(self) -> float:
        """Returns the S-measure (structural similarity) score
        Higher values indicate better segmentation quality.
        """
        return float(self.sm.get_results()["sm"])

    def wfmeasure(self) -> float:
        """Returns the weighted F-measure score
        Higher values indicate better boundary accuracy.
        """
        return float(self.wfm.get_results()["wfm"])

    def mae_acc(self) -> float:
        """Returns the Mean Absolute Error
        Lower values indicate better pixel-wise accuracy.
        """
        return float(self.mae.get_results()["mae"])

    def emasure(self) -> float:
        """Returns the mean E-measure (enhanced alignment measure) score
        Higher values indicate better region and boundary alignment.
        """
        return float(self.em.get_results()["em"]["curve"].mean())

    def get_accuracy_score(self) -> float:
        return self.smeasure()

    def get_metric_metadata(self) -> MetricMetadata:
        return MetricMetadata(
            name="Structural Similarity",
            unit="SSIM",
            description="A measure of the perceived quality difference between two images.",
            range=(0.0, 1.0),
            float_vs_device_threshold=0.1,
        )

    def formatted_accuracy(self) -> str:
        parts = [
            f"MAE: {self.mae_acc():.4f}",
            f"Smeasure: {self.smeasure():.4f}",
            f"wFmeasure: {self.wfmeasure():.4f}",
            f"Emeasure: {self.emasure():.4f}",
        ]
        return ", ".join(parts)
