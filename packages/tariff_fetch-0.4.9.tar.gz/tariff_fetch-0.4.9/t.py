from datetime import date, datetime, time
from typing import get_args

from dotenv import load_dotenv
from tariff_fetch.arcadia.api import ArcadiaSignalAPI
from tariff_fetch.arcadia.schema.common import RateChargeClass
from tariff_fetch.urdb.arcadia.energyschedule import get_raw_bands_at_datetime
from tariff_fetch.urdb.arcadia.library import Library
from tariff_fetch.urdb.arcadia.scenario import Scenario


def main():
    _ = load_dotenv()
    master_tariff_id = 80824
    scenario = Scenario(master_tariff_id, 2025, apply_percentages=True, charge_classes=set(get_args(RateChargeClass)))
    api = ArcadiaSignalAPI()
    library = Library(api)
    result = get_raw_bands_at_datetime(scenario, library, datetime.combine(date(2025, 1, 15), time(minute=30)))
    print(result)

    pass


if __name__ == "__main__":
    main()
