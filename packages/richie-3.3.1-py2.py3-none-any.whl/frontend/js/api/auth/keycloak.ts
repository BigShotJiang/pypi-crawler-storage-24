import Keycloak from 'keycloak-js';
import { AuthenticationBackend } from 'types/commonDataProps';
import { APIAuthentication } from 'types/api';
import { KeycloakApiProfile } from 'types/keycloak';
import { location } from 'utils/indirection/window';
import { handle } from 'utils/errors/handle';
import { RICHIE_USER_TOKEN } from 'settings';

const API = (APIConf: AuthenticationBackend): { user: APIAuthentication } => {
  const keycloak = new Keycloak({
    url: APIConf.endpoint,
    realm: APIConf.keycloak_realm!,
    clientId: APIConf.keycloak_client_id!,
  });
  const initPromise = keycloak.init({
    checkLoginIframe: false,
    flow: 'standard',
    onLoad: 'check-sso',
    pkceMethod: 'S256',
  });

  keycloak.onTokenExpired = () => {
    keycloak.updateToken(30).catch(() => {
      sessionStorage.removeItem(RICHIE_USER_TOKEN);
    });
  };

  keycloak.onAuthRefreshSuccess = () => {
    if (keycloak.idToken) {
      sessionStorage.setItem(RICHIE_USER_TOKEN, keycloak.idToken);
    }
  };

  const getRedirectUri = () => {
    return `${location.origin}${location.pathname}`;
  };

  return {
    user: {
      accessToken: () => sessionStorage.getItem(RICHIE_USER_TOKEN),
      me: async () => {
        let isAuthenticated: boolean;
        try {
          isAuthenticated = await initPromise;
        } catch (error) {
          handle(error);
          return null;
        }
        if (!isAuthenticated) return null;

        try {
          await keycloak.updateToken(30);
        } catch (error) {
          handle(error);
          return null;
        }

        return keycloak
          .loadUserProfile()
          .then((userProfile) => {
            sessionStorage.setItem(RICHIE_USER_TOKEN, keycloak.idToken!);
            const fullName = [userProfile.firstName, userProfile.lastName]
              .filter(Boolean)
              .join(' ');
            return {
              username: fullName,
              full_name: fullName,
              email: userProfile.email,
              access_token: keycloak.idToken,
            };
          })
          .catch((error) => {
            handle(error);
            return null;
          });
      },

      login: async () => {
        await keycloak.login({ redirectUri: getRedirectUri() });
      },

      register: async () => {
        await keycloak.login({ redirectUri: getRedirectUri(), action: 'REGISTER' });
      },

      logout: async () => {
        sessionStorage.removeItem(RICHIE_USER_TOKEN);
        await keycloak.logout({ redirectUri: getRedirectUri() });
      },

      account: {
        get: (): KeycloakApiProfile => {
          return {
            username: keycloak.idTokenParsed?.preferred_username,
            firstName: keycloak.idTokenParsed?.firstName,
            lastName: keycloak.idTokenParsed?.lastName,
            email: keycloak.idTokenParsed?.email,
          };
        },
        updateUrl: () => keycloak.createAccountUrl(),
      },
    },
  };
};

export default API;
