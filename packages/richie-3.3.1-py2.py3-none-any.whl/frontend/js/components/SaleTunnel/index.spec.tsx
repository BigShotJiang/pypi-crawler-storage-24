import { act, cleanup, screen, waitFor } from '@testing-library/react';
import fetchMock from 'fetch-mock';
import queryString from 'query-string';
import userEvent from '@testing-library/user-event';
import { within } from '@testing-library/dom';
import { createIntl } from 'react-intl';
import { useState } from 'react';
import { OrderState, Product, ProductType, NOT_CANCELED_ORDER_STATES } from 'types/Joanie';
import {
  RichieContextFactory as mockRichieContextFactory,
  CourseStateFactory,
  UserFactory,
  PacedCourseFactory,
} from 'utils/test/factories/richie';
import {
  AddressFactory,
  CertificateOrderFactory,
  CertificateProductFactory,
  OfferingFactory,
  CourseRunFactory,
  CredentialOrderFactory,
  CredentialProductFactory,
  CreditCardFactory,
  EnrollmentFactory,
  PaymentPlanFactory,
} from 'utils/test/factories/joanie';
import { Priority } from 'types';
import { render } from 'utils/test/render';
import { SaleTunnel, SaleTunnelProps } from 'components/SaleTunnel/index';
import { setupJoanieSession } from 'utils/test/wrappers/JoanieAppWrapper';
import { HttpError, HttpStatusCode } from 'utils/errors/HttpError';
import { getAddressLabel } from 'components/SaleTunnel/AddressSelector';
import { User } from 'types/User';
import { OpenEdxApiProfile } from 'types/openEdx';
import { OpenEdxApiProfileFactory } from 'utils/test/factories/openEdx';
import { createTestQueryClient } from 'utils/test/createTestQueryClient';
import { StringHelper } from 'utils/StringHelper';
import { DEFAULT_DATE_FORMAT } from 'hooks/useDateFormat';
import { AuthenticationApi } from 'api/authentication';
import { APIAuthentication } from 'types/api';
import { Deferred } from 'utils/test/deferred';

jest.mock('utils/context', () => ({
  __esModule: true,
  default: mockRichieContextFactory({
    authentication: { backend: 'fonzie', endpoint: 'https://auth.test' },
    joanie_backend: { endpoint: 'https://joanie.endpoint' },
    site_urls: {
      terms_and_conditions: '/en/about/terms-and-conditions/',
    },
  }).one(),
}));

jest.mock('utils/indirection/window', () => ({
  matchMedia: () => ({
    matches: true,
    addListener: jest.fn(),
    removeListener: jest.fn(),
  }),
}));

jest.mock('./SaleTunnelSavePaymentMethod', () => ({
  __esModule: true,
  default: () => <div data-testid="sale-tunnel-save-payment-method-step" />,
}));
jest.mock('components/ContractFrame/LearnerContractFrame', () => ({
  __esModule: true,
  default: () => <div data-testid="sale-tunnel-sign-step" />,
}));

describe.each([
  {
    productType: ProductType.CREDENTIAL,
    ProductFactory: CredentialProductFactory,
    OrderFactory: CredentialOrderFactory,
  },
  {
    productType: ProductType.CERTIFICATE,
    ProductFactory: CertificateProductFactory,
    OrderFactory: CertificateOrderFactory,
  },
])('SaleTunnel for $productType product', ({ productType, ProductFactory, OrderFactory }) => {
  let nbApiCalls: number;

  const course = PacedCourseFactory().one();
  const enrollment =
    productType === ProductType.CERTIFICATE
      ? EnrollmentFactory({ course_run: { course } }).one()
      : undefined;

  let richieUser: User;
  let openApiEdxProfile: OpenEdxApiProfile;

  const formatPrice = (price: number, currency: string) =>
    new Intl.NumberFormat('en', {
      currency,
      style: 'currency',
    }).format(price);

  const Wrapper = (props: Omit<SaleTunnelProps, 'isOpen' | 'onClose'>) => {
    const [open, setOpen] = useState(true);
    return (
      <SaleTunnel
        {...props}
        enrollment={props.enrollment ?? enrollment}
        course={productType === ProductType.CREDENTIAL ? course : undefined}
        isOpen={open}
        onClose={() => setOpen(false)}
      />
    );
  };

  beforeEach(() => {
    jest.useFakeTimers();
    jest.clearAllTimers();
    jest.resetAllMocks();

    fetchMock.restore();
    sessionStorage.clear();

    nbApiCalls = 3;

    richieUser = UserFactory().one();
    openApiEdxProfile = OpenEdxApiProfileFactory({
      username: richieUser.username,
      email: richieUser.email,
      name: richieUser.full_name,
    }).one();

    const { 'pref-lang': prefLang, ...openEdxAccount } = openApiEdxProfile;

    fetchMock.get(`https://auth.test/api/user/v1/accounts/${richieUser.username}`, openEdxAccount);
    fetchMock.get(`https://auth.test/api/user/v1/preferences/${richieUser.username}`, {
      'pref-lang': prefLang,
    });
  });

  setupJoanieSession();

  afterEach(() => {
    act(() => {
      jest.runOnlyPendingTimers();
    });
    jest.useRealTimers();
    cleanup();
  });

  const getFetchOrderQueryParams = (product: Product) => {
    return product.type === ProductType.CREDENTIAL
      ? {
          course_code: course.code,
          product_id: product.id,
          state: NOT_CANCELED_ORDER_STATES,
        }
      : {
          enrollment_id: enrollment?.id,
          product_id: product.id,
          state: NOT_CANCELED_ORDER_STATES,
        };
  };

  it('should create an order when the user clicks on subscribe button', async () => {
    const product = ProductFactory().one();
    const billingAddress = AddressFactory({
      is_main: true,
    }).one();
    const order = OrderFactory({ state: OrderState.TO_SAVE_PAYMENT_METHOD }).one();
    const paymentPlan = PaymentPlanFactory().one();
    fetchMock
      .get(
        `https://joanie.endpoint/api/v1.0/orders/?${queryString.stringify(getFetchOrderQueryParams(product))}`,
        [],
      )
      .get(
        `https://joanie.endpoint/api/v1.0/courses/${course.code}/products/${product.id}/payment-plan/`,
        paymentPlan,
      )
      .post('https://joanie.endpoint/api/v1.0/orders/', order)
      .get(`https://joanie.endpoint/api/v1.0/orders/${order.id}/`, order)
      .get('https://joanie.endpoint/api/v1.0/addresses/', [billingAddress], {
        overwriteRoutes: true,
      });

    render(<Wrapper product={product} isWithdrawable={true} paymentPlan={paymentPlan} />, {
      queryOptions: { client: createTestQueryClient({ user: richieUser }) },
    });
    nbApiCalls += 1; // useProductOrder call.
    nbApiCalls += 1; // get user account call.
    nbApiCalls += 1; // get user preferences call.
    nbApiCalls += 1; // product payment-schedule call
    await waitFor(() => expect(fetchMock.calls()).toHaveLength(nbApiCalls));

    const user = userEvent.setup({ delay: null });

    const $button = screen.getByRole<HTMLButtonElement>('button', {
      name: `Subscribe`,
    });

    // - wait for address to be loaded.
    await screen.findByText(getAddressLabel(billingAddress));

    // - Subscribe button should not be disabled.
    expect($button.disabled).toBe(false);

    // - Order should not have been created yet
    expect(
      fetchMock
        .calls()
        .filter(
          ([url, metadata]) =>
            url === 'https://joanie.endpoint/api/v1.0/orders/' && metadata?.method === 'POST',
        ),
    ).toHaveLength(0);

    // - User clicks on pay button
    await user.click($button);

    fetchMock.get(
      `https://joanie.endpoint/api/v1.0/orders/?${queryString.stringify(getFetchOrderQueryParams(product))}`,
      [order],
      { overwriteRoutes: true },
    );

    // - Route to create order should have been called
    nbApiCalls += 1; // order create
    nbApiCalls += 1; // useProductOrder call (invalidate from create)

    await waitFor(() => expect(fetchMock.calls()).toHaveLength(nbApiCalls));
    expect(fetchMock.lastUrl()).toBe(
      `https://joanie.endpoint/api/v1.0/orders/?${queryString.stringify(getFetchOrderQueryParams(product))}`,
    );

    // - Order should have been created once
    expect(
      fetchMock
        .calls()
        .filter(
          ([url, metadata]) =>
            url === 'https://joanie.endpoint/api/v1.0/orders/' && metadata?.method === 'POST',
        ),
    ).toHaveLength(1);

    // - Spinner should be displayed
    screen.getByText('Order creation in progress');

    // - Save payment step should be displayed
    await screen.findByTestId('sale-tunnel-save-payment-method-step');
  });

  it('should render an error message when order creation fails', async () => {
    const product = ProductFactory().one();
    const billingAddress = AddressFactory({
      is_main: true,
    }).one();
    const deferred = new Deferred();
    const paymentPlan = PaymentPlanFactory().one();
    fetchMock
      .get(
        `https://joanie.endpoint/api/v1.0/orders/?${queryString.stringify(getFetchOrderQueryParams(product))}`,
        [],
      )
      .get(
        `https://joanie.endpoint/api/v1.0/courses/${course.code}/products/${product.id}/payment-plan/`,
        paymentPlan,
      )
      .post('https://joanie.endpoint/api/v1.0/orders/', deferred.promise)
      .get('https://joanie.endpoint/api/v1.0/addresses/', [billingAddress], {
        overwriteRoutes: true,
      });

    render(<Wrapper product={product} isWithdrawable={true} paymentPlan={paymentPlan} />, {
      queryOptions: { client: createTestQueryClient({ user: richieUser }) },
    });
    nbApiCalls += 1; // useProductOrder get order with filters
    nbApiCalls += 1; // get user account call.
    nbApiCalls += 1; // get user preferences call.
    nbApiCalls += 1; // get paymentPlan call.
    await waitFor(() => expect(fetchMock.calls()).toHaveLength(nbApiCalls));

    const user = userEvent.setup({ delay: null });

    const $button = screen.getByRole('button', {
      name: `Subscribe`,
    }) as HTMLButtonElement;

    // - wait for address to be loaded.
    await screen.findByText(getAddressLabel(billingAddress));

    // - As all information are provided, subscribe button should not be disabled.
    expect($button.disabled).toBe(false);

    // - User clicks on subscribe button
    await user.click($button);

    // - Route to create order should have been called
    nbApiCalls += 1; // order post create (no query invalidation)

    await waitFor(() => expect(fetchMock.calls()).toHaveLength(nbApiCalls));

    // - Spinner should be displayed and subscribe button should be disabled
    screen.getByText('Order creation in progress');
    expect($button.disabled).toBe(true);

    // - Simulate the order creation has failed
    await act(async () => {
      deferred.reject(
        new HttpError(HttpStatusCode.BAD_REQUEST, 'An error occurred during order creation.'),
      );
    });

    // - An error message should be displayed
    const $error = screen.getByText('An error occurred during order creation. Please retry later.');
    expect(document.activeElement).toBe($error);

    // - Payment button should have been restore to its idle state
    expect($button.disabled).toBe(false);
    screen.getByRole('button', {
      name: 'Subscribe',
    });
  });

  it('should verify the purchase type selector visibility based on product type', async () => {
    const product = ProductFactory().one();
    const paymentPlan = PaymentPlanFactory().one();
    const user = userEvent.setup({ delay: null });

    fetchMock
      .get(
        `https://joanie.endpoint/api/v1.0/orders/?${queryString.stringify(getFetchOrderQueryParams(product))}`,
        [],
      )
      .get(
        `https://joanie.endpoint/api/v1.0/courses/${course.code}/products/${product.id}/payment-plan/`,
        paymentPlan,
      )
      .get('https://joanie.endpoint/api/v1.0/offerings/get-organizations/', []);

    render(<Wrapper paymentPlan={paymentPlan} product={product} isWithdrawable={true} />, {
      queryOptions: { client: createTestQueryClient({ user: richieUser }) },
    });

    await screen.findByText(
      formatPrice(paymentPlan.price, product.price_currency).replace(/(\u202F|\u00a0)/g, ' '),
    );

    if (productType === ProductType.CERTIFICATE) {
      expect(screen.queryByRole('combobox', { name: 'Purchase type' })).not.toBeInTheDocument();
      expect(screen.getByText('This information will be used for billing')).toBeInTheDocument();
    } else {
      const purchaseType = screen.getByRole('combobox', { name: 'Purchase type' });
      expect(purchaseType).toBeInTheDocument();

      expect(screen.getByText('This information will be used for billing')).toBeInTheDocument();
      expect(screen.queryByRole('textbox', { name: 'Company name' })).not.toBeInTheDocument();

      await user.click(purchaseType);
      await user.click(
        screen.getByRole('option', { name: 'I am purchasing on behalf of an organization' }),
      );

      expect(screen.getByRole('textbox', { name: 'Company name' })).toBeInTheDocument();
    }
  });

  it('should start at the save payment method step if order is in state to_save_payment_method', async () => {
    const product = ProductFactory().one();
    const billingAddress = AddressFactory({
      is_main: true,
    }).one();
    const creditCard = CreditCardFactory().one();
    const order = OrderFactory({ state: OrderState.TO_SAVE_PAYMENT_METHOD }).one();
    const paymentPlan = PaymentPlanFactory().one();
    fetchMock
      .get(
        `https://joanie.endpoint/api/v1.0/orders/?${queryString.stringify(getFetchOrderQueryParams(product))}`,
        [order],
      )
      .get(
        `https://joanie.endpoint/api/v1.0/courses/${course.code}/products/${product.id}/payment-plan/`,
        paymentPlan,
      )
      .get('https://joanie.endpoint/api/v1.0/credit-cards/', [creditCard], {
        overwriteRoutes: true,
      })
      .get('https://joanie.endpoint/api/v1.0/addresses/', [billingAddress], {
        overwriteRoutes: true,
      });

    render(<Wrapper product={product} isWithdrawable={true} paymentPlan={paymentPlan} />, {
      queryOptions: { client: createTestQueryClient({ user: richieUser }) },
    });

    nbApiCalls += 3;
    await waitFor(() => expect(fetchMock.calls()).toHaveLength(nbApiCalls));

    await screen.findByTestId('sale-tunnel-save-payment-method-step');
  });

  it.each([OrderState.TO_SIGN, OrderState.SIGNING])(
    'should start at the sign step if order is in state %s',
    async (state) => {
      const product = ProductFactory().one();
      const billingAddress = AddressFactory({
        is_main: true,
      }).one();
      const creditCard = CreditCardFactory().one();
      const order = OrderFactory({ state }).one();
      const paymentPlan = PaymentPlanFactory().one();
      fetchMock
        .get(
          `https://joanie.endpoint/api/v1.0/orders/?${queryString.stringify(getFetchOrderQueryParams(product))}`,
          [order],
        )
        .get(
          `https://joanie.endpoint/api/v1.0/courses/${course.code}/products/${product.id}/payment-plan/`,
          paymentPlan,
        )
        .get('https://joanie.endpoint/api/v1.0/credit-cards/', [creditCard], {
          overwriteRoutes: true,
        })
        .get('https://joanie.endpoint/api/v1.0/addresses/', [billingAddress], {
          overwriteRoutes: true,
        });

      render(<Wrapper product={product} isWithdrawable={true} paymentPlan={paymentPlan} />, {
        queryOptions: { client: createTestQueryClient({ user: richieUser }) },
      });

      nbApiCalls += 3;
      await waitFor(() => expect(fetchMock.calls()).toHaveLength(nbApiCalls));

      await screen.findByTestId('sale-tunnel-sign-step');
    },
  );

  it('should show the product payment schedule', async () => {
    const intl = createIntl({ locale: 'en' });
    const product = ProductFactory().one();
    const paymentPlan = PaymentPlanFactory().one();
    const schedule = paymentPlan.payment_schedule;
    fetchMock
      .get(
        `https://joanie.endpoint/api/v1.0/orders/?${queryString.stringify(getFetchOrderQueryParams(product))}`,
        [],
      )
      .get(
        `https://joanie.endpoint/api/v1.0/courses/${course.code}/products/${product.id}/payment-plan/`,
        paymentPlan,
      );

    render(<Wrapper paymentPlan={paymentPlan} product={product} isWithdrawable={true} />, {
      queryOptions: { client: createTestQueryClient({ user: richieUser }) },
    });

    if (product.type === ProductType.CREDENTIAL) {
      await screen.findByRole('heading', {
        level: 4,
        name: 'Payment schedule',
      });

      const scheduleTable = screen.getByRole('table');
      const scheduleTableRows = within(scheduleTable).getAllByRole('row');
      expect(scheduleTableRows).toHaveLength(schedule.length);

      scheduleTableRows.forEach((row, index) => {
        const installment = schedule[index];
        // A first column should show the installment index
        within(row).getByRole('cell', {
          name: (index + 1).toString(),
        });
        // A 2nd column should show the installment amount
        within(row).getByRole('cell', {
          name: formatPrice(installment.amount, installment.currency),
        });
        // A 3rd column should show the installment withdraw date
        within(row).getByRole('cell', {
          name: `Withdrawn on ${intl.formatDate(installment.due_date, {
            ...DEFAULT_DATE_FORMAT,
          })}`,
        });
        // A 4th column should show the installment state
        within(row).getByRole('cell', {
          name: StringHelper.capitalizeFirst(installment.state.replace('_', ' '))!,
        });
      });
    } else {
      expect(
        screen.queryByRole('heading', { level: 4, name: 'Payment schedule' }),
      ).not.toBeInTheDocument();
      expect(
        screen.queryByText('No payment required. This order is fully covered.'),
      ).not.toBeInTheDocument();
      expect(screen.queryByRole('table')).toBeNull();
    }

    const $totalAmount = screen.getByTestId('sale-tunnel__total__amount');
    expect($totalAmount).toHaveTextContent(
      'Total' +
        formatPrice(paymentPlan.price, product.price_currency).replace(/(\u202F|\u00a0)/g, ' '),
    );
  });

  // Fixes the issue : https://github.com/openfun/richie/issues/2645
  it('should show the certificate product total with discounted price', async () => {
    const product = ProductFactory({
      price: 600,
      target_courses: [course],
    }).one();
    const enrollmentDiscounted = EnrollmentFactory({
      course_run: CourseRunFactory({
        state: CourseStateFactory({ priority: Priority.ONGOING_OPEN }).one(),
        course,
      }).one(),
      offerings: [
        OfferingFactory({
          product,
          rules: {
            discounted_price: 540,
            discount_rate: 0.1,
          },
        }).one(),
      ],
    }).one();
    const paymentPlan = PaymentPlanFactory({ discounted_price: 80 }).one();
    if (product.type === ProductType.CERTIFICATE) {
      enrollmentDiscounted.offerings[0].product = product;
      fetchMock
        .get(
          `https://joanie.endpoint/api/v1.0/orders/?enrollment_id=${enrollmentDiscounted.id}&product_id=${product.id}&state=pending&state=pending_payment&state=no_payment&state=failed_payment&state=completed&state=draft&state=assigned&state=to_sign&state=signing&state=to_save_payment_method`,
          {
            results: [],
            next: null,
            previous: null,
            count: 0,
          },
        )
        .get(
          `https://joanie.endpoint/api/v1.0/courses/${course.code}/products/${product.id}/payment-plan/`,
          paymentPlan,
        );
      render(
        <Wrapper
          product={product}
          enrollment={enrollmentDiscounted}
          isWithdrawable={true}
          paymentPlan={paymentPlan}
        />,
        { queryOptions: { client: createTestQueryClient({ user: richieUser }) } },
      );

      const $totalAmount = screen.getByTestId('sale-tunnel__total__amount');
      expect($totalAmount).toHaveTextContent(
        'Total' +
          formatPrice(paymentPlan.price!, product.price_currency).replace(/(\u202F|\u00a0)/g, ' ') +
          formatPrice(paymentPlan.discounted_price!, product.price_currency).replace(
            /(\u202F|\u00a0)/g,
            ' ',
          ),
      );
    }
  });

  it('should show the product payment schedule with discounted price', async () => {
    const intl = createIntl({ locale: 'en' });
    const paymentPlan = PaymentPlanFactory({ discounted_price: 80 }).one();
    const schedule = paymentPlan.payment_schedule;

    const offering = OfferingFactory({
      product: ProductFactory({
        price: 840,
        price_currency: 'EUR',
      }).one(),
      rules: {
        discounted_price: 800,
        discount_rate: 0.3,
      },
    }).one();
    const { product } = offering;

    fetchMock
      .get(
        `https://joanie.endpoint/api/v1.0/orders/?${queryString.stringify(getFetchOrderQueryParams(product))}`,
        [],
      )
      .get(
        `https://joanie.endpoint/api/v1.0/courses/${course.code}/products/${product.id}/payment-plan/`,
        paymentPlan,
      );

    render(
      <Wrapper
        paymentPlan={paymentPlan}
        product={product}
        offering={offering}
        isWithdrawable={true}
      />,
      {
        queryOptions: { client: createTestQueryClient({ user: richieUser }) },
      },
    );

    if (product.type === ProductType.CREDENTIAL) {
      await screen.findByRole('heading', { level: 4, name: 'Payment schedule' });

      const scheduleTable = screen.getByRole('table');
      const scheduleTableRows = within(scheduleTable).getAllByRole('row');
      expect(scheduleTableRows).toHaveLength(schedule.length);

      scheduleTableRows.forEach((row, index) => {
        const installment = schedule[index];
        // A first column should show the installment index
        within(row).getByRole('cell', {
          name: (index + 1).toString(),
        });
        // A 2nd column should show the installment amount
        within(row).getByRole('cell', {
          name: formatPrice(installment.amount, installment.currency),
        });
        // A 3rd column should show the installment withdraw date
        within(row).getByRole('cell', {
          name: `Withdrawn on ${intl.formatDate(installment.due_date, {
            ...DEFAULT_DATE_FORMAT,
          })}`,
        });
        // A 4th column should show the installment state
        within(row).getByRole('cell', {
          name: StringHelper.capitalizeFirst(installment.state.replace('_', ' '))!,
        });
      });
    } else {
      expect(
        screen.queryByRole('heading', { level: 4, name: 'Payment schedule' }),
      ).not.toBeInTheDocument();
      expect(
        screen.queryByText('No payment required. This order is fully covered.'),
      ).not.toBeInTheDocument();
      expect(screen.queryByRole('table')).toBeNull();
    }

    const $totalAmount = screen.getByTestId('sale-tunnel__total__amount');
    expect($totalAmount).toHaveTextContent(
      'Total' +
        formatPrice(paymentPlan.price!, product.price_currency).replace(/(\u202F|\u00a0)/g, ' ') +
        formatPrice(paymentPlan.discounted_price!, product.price_currency).replace(
          /(\u202F|\u00a0)/g,
          ' ',
        ),
    );
  });

  it('should show a walkthrough to explain the subscription process', async () => {
    const product = ProductFactory().one();
    const paymentPlan = PaymentPlanFactory().one();
    fetchMock
      .get(
        `https://joanie.endpoint/api/v1.0/orders/?${queryString.stringify(getFetchOrderQueryParams(product))}`,
        [],
      )
      .get(
        `https://joanie.endpoint/api/v1.0/courses/${course.code}/products/${product.id}/payment-plan/`,
        paymentPlan,
      );

    render(<Wrapper paymentPlan={paymentPlan} product={product} isWithdrawable={true} />, {
      queryOptions: { client: createTestQueryClient({ user: richieUser }) },
    });

    screen.getByTestId('walkthrough-banner');
  });

  it('should show a checkbox to waive withdrawal right if the product is not withdrawable', async () => {
    const product = ProductFactory().one();
    const paymentPlan = PaymentPlanFactory().one();
    fetchMock
      .get(
        `https://joanie.endpoint/api/v1.0/orders/?${queryString.stringify(getFetchOrderQueryParams(product))}`,
        [],
      )
      .get(
        `https://joanie.endpoint/api/v1.0/courses/${course.code}/products/${product.id}/payment-plan/`,
        paymentPlan,
      );

    render(<Wrapper paymentPlan={paymentPlan} product={product} isWithdrawable={false} />, {
      queryOptions: { client: createTestQueryClient({ user: richieUser }) },
    });

    screen.getByTestId('withdraw-right-checkbox');
  });

  it('should not show a checkbox to waive withdrawal right if the product is withdrawable', async () => {
    const product = ProductFactory().one();
    const paymentPlan = PaymentPlanFactory().one();
    fetchMock
      .get(
        `https://joanie.endpoint/api/v1.0/orders/?${queryString.stringify(getFetchOrderQueryParams(product))}`,
        [],
      )
      .get(
        `https://joanie.endpoint/api/v1.0/courses/${course.code}/products/${product.id}/payment-plan/`,
        paymentPlan,
      );

    render(<Wrapper paymentPlan={paymentPlan} product={product} isWithdrawable={true} />, {
      queryOptions: { client: createTestQueryClient({ user: richieUser }) },
    });

    expect(screen.queryByTestId('withdraw-right-checkbox')).toBeNull();
  });

  it('should show a specific checkbox to waive withdrawal right according to the product type', async () => {
    const product = ProductFactory().one();
    const paymentPlan = PaymentPlanFactory().one();
    fetchMock
      .get(
        `https://joanie.endpoint/api/v1.0/orders/?${queryString.stringify(getFetchOrderQueryParams(product))}`,
        [],
      )
      .get(
        `https://joanie.endpoint/api/v1.0/courses/${course.code}/products/${product.id}/payment-plan/`,
        paymentPlan,
      );

    render(<Wrapper paymentPlan={paymentPlan} product={product} isWithdrawable={false} />, {
      queryOptions: { client: createTestQueryClient({ user: richieUser }) },
    });

    screen.getByTestId('withdraw-right-checkbox');

    const expectedMessages =
      productType === ProductType.CERTIFICATE
        ? [
            'If you access the exam, you acknowledge waiving your 14-day withdrawal right, as provided for in Article L221-18 of the French Consumer Code.',
            'I acknowledge that I have been informed of my legal right of withdrawal, which allows me to cancel my registration within 14 days from the date of payment.',
            'I understand that if I access the exam during this period, I expressly waive my right of withdrawal.',
          ]
        : [
            'The training program you wish to enroll in begins before the end of the 14-day withdrawal period mentioned in Article L221-18 of the French Consumer Code. You must check the box below to proceed with your registration.',
            'I acknowledge that I have expressly requested to begin the training before the expiration date of the withdrawal period.',
            'I expressly waive my right of withdrawal in order to begin the training before the expiration of the withdrawal period.',
          ];

    expectedMessages.forEach((message) => {
      screen.getByText(message);
    });
  });

  it('should show appropriate error messages for invalid vouchers', async () => {
    const user = userEvent.setup({ delay: null });
    const paymentPlan = PaymentPlanFactory().one();
    const paymentPlanVoucher = PaymentPlanFactory({
      discounted_price: 70,
      discount: '-30%',
    }).one();
    const product = ProductFactory().one();
    fetchMock
      .get(
        `https://joanie.endpoint/api/v1.0/orders/?${queryString.stringify(getFetchOrderQueryParams(product))}`,
        [],
      )
      .get(
        `https://joanie.endpoint/api/v1.0/courses/${course.code}/products/${product.id}/payment-plan/`,
        paymentPlan,
      )
      .get(
        `https://joanie.endpoint/api/v1.0/courses/${course.code}/products/${product.id}/payment-plan/?voucher_code=DISCOUNT30`,
        {
          status: 404,
          body: {
            detail: 'No Voucher matches the given query.',
          },
        },
      )
      .get(
        `https://joanie.endpoint/api/v1.0/courses/${course.code}/products/${product.id}/payment-plan/?voucher_code=DISCOUNT29`,
        {
          status: 429,
          body: {
            detail: 'Too many attempts. Please try again later.',
          },
        },
      )
      .get(
        `https://joanie.endpoint/api/v1.0/courses/${course.code}/products/${product.id}/payment-plan/?voucher_code=DISCOUNT10`,
        paymentPlanVoucher,
      );
    render(<Wrapper paymentPlan={paymentPlan} product={product} isWithdrawable={true} />, {
      queryOptions: { client: createTestQueryClient({ user: richieUser }) },
    });
    expect(screen.getByLabelText('Voucher code'));
    await user.type(screen.getByLabelText('Voucher code'), 'DISCOUNT30');
    await user.click(screen.getByRole('button', { name: 'Validate' }));
    expect(await screen.findByText('The submitted voucher code is not valid.')).toBeInTheDocument();
    await user.type(screen.getByLabelText('Voucher code'), 'DISCOUNT29');
    await user.click(screen.getByRole('button', { name: 'Validate' }));
    expect(
      await screen.findByText('Too many attempts. Please try again later.'),
    ).toBeInTheDocument();
    await user.type(screen.getByLabelText('Voucher code'), 'DISCOUNT10');
    await user.click(screen.getByRole('button', { name: 'Validate' }));
    expect(await screen.findByText('Discount applied')).toBeInTheDocument();
  });

  it('should hide billing informations for a voucher from a batch order', async () => {
    const user = userEvent.setup({ delay: null });
    const paymentPlan = PaymentPlanFactory().one();
    const paymentPlanVoucher = PaymentPlanFactory({
      discounted_price: 0.0,
      discount: '-100%',
      from_batch_order: true,
    }).one();
    const product = ProductFactory().one();
    fetchMock
      .get(
        `https://joanie.endpoint/api/v1.0/orders/?${queryString.stringify(getFetchOrderQueryParams(product))}`,
        [],
      )
      .get(
        `https://joanie.endpoint/api/v1.0/courses/${course.code}/products/${product.id}/payment-plan/`,
        paymentPlan,
      )
      .get(
        `https://joanie.endpoint/api/v1.0/courses/${course.code}/products/${product.id}/payment-plan/?voucher_code=DISCOUNT100`,
        paymentPlanVoucher,
      );
    render(<Wrapper paymentPlan={paymentPlan} product={product} isWithdrawable={true} />, {
      queryOptions: { client: createTestQueryClient({ user: richieUser }) },
    });
    expect(
      await screen.queryByText('This information will be used for billing'),
    ).toBeInTheDocument();

    await user.type(screen.getByLabelText('Voucher code'), 'DISCOUNT100');
    await user.click(screen.getByRole('button', { name: 'Validate' }));

    expect(await screen.findByText('Discount applied')).toBeInTheDocument();
    await waitFor(async () =>
      expect(
        await screen.queryByText('This information will be used for billing'),
      ).not.toBeInTheDocument(),
    );
    expect(await screen.queryByTestId('withdraw-right-checkbox')).not.toBeInTheDocument();

    expect(
      screen.getByText(
        'No billing information required. This order is covered by your organization.',
      ),
    ).toBeInTheDocument();
    expect(
      screen.queryByRole('heading', { level: 4, name: 'Payment schedule' }),
    ).not.toBeInTheDocument();
    expect(
      screen.queryByText('No payment required. This order is fully covered.'),
    ).not.toBeInTheDocument();
  });

  it('should hide voucher code input when one is already used', async () => {
    const user = userEvent.setup({ delay: null });
    const paymentPlan = PaymentPlanFactory().one();
    const paymentPlanVoucher = PaymentPlanFactory({
      discounted_price: 70,
      discount: '-30%',
    }).one();
    const product = ProductFactory().one();
    fetchMock
      .get(
        `https://joanie.endpoint/api/v1.0/orders/?${queryString.stringify(getFetchOrderQueryParams(product))}`,
        [],
      )
      .get(
        `https://joanie.endpoint/api/v1.0/courses/${course.code}/products/${product.id}/payment-plan/`,
        paymentPlan,
      )
      .get(
        `https://joanie.endpoint/api/v1.0/courses/${course.code}/products/${product.id}/payment-plan/?voucher_code=DISCOUNT30`,
        paymentPlanVoucher,
      );
    render(<Wrapper paymentPlan={paymentPlan} product={product} isWithdrawable={true} />, {
      queryOptions: { client: createTestQueryClient({ user: richieUser }) },
    });

    // Initially, voucher input should be visible
    expect(screen.getByLabelText('Voucher code')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Validate' })).toBeInTheDocument();
    expect(
      screen.getByText('If you have a voucher code, please enter it in the field below.'),
    ).toBeInTheDocument();

    // Apply a voucher code
    await user.type(screen.getByLabelText('Voucher code'), 'DISCOUNT30');
    await user.click(screen.getByRole('button', { name: 'Validate' }));

    // Wait for voucher to be applied
    expect(await screen.findByText('Discount applied')).toBeInTheDocument();

    // Voucher input should be hidden
    expect(screen.queryByLabelText('Voucher code')).not.toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Validate' })).not.toBeInTheDocument();
    expect(
      screen.queryByText('If you have a voucher code, please enter it in the field below.'),
    ).not.toBeInTheDocument();

    // Voucher tag should be visible with the applied code
    expect(screen.getByText('DISCOUNT30')).toBeInTheDocument();

    // Remove the voucher
    await user.click(screen.getByTitle('Delete this voucher'));

    // Voucher input should be visible again
    expect(screen.getByLabelText('Voucher code')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Validate' })).toBeInTheDocument();
    expect(
      screen.getByText('If you have a voucher code, please enter it in the field below.'),
    ).toBeInTheDocument();

    // Voucher tag should be hidden
    expect(screen.queryByText('DISCOUNT30')).not.toBeInTheDocument();
  });
});

describe('SaleTunnel with Keycloak backend', () => {
  const mockAccountUpdateUrl = 'https://keycloak.test/auth/realms/richie-realm/account';
  const course = PacedCourseFactory().one();
  let richieUser: User;
  let originalBackend: string;
  let originalAccount: APIAuthentication['account'];

  const Wrapper = (props: Omit<SaleTunnelProps, 'isOpen' | 'onClose'>) => {
    const [open, setOpen] = useState(true);
    return <SaleTunnel {...props} course={course} isOpen={open} onClose={() => setOpen(false)} />;
  };

  beforeEach(() => {
    jest.useFakeTimers();
    jest.clearAllTimers();
    jest.resetAllMocks();

    fetchMock.restore();
    sessionStorage.clear();

    richieUser = UserFactory({
      username: 'John Doe',
      full_name: 'John Doe',
      email: 'johndoe@example.com',
    }).one();

    // Mock OpenEdx profile endpoints that may still be triggered by the fonzie-based
    // AuthenticationApi (resolved at module load). These should not be called by
    // the keycloak code paths we are testing.
    fetchMock.get(`begin:https://auth.test/api/user/v1/accounts/`, {});
    fetchMock.get(`begin:https://auth.test/api/user/v1/preferences/`, {});

    // Temporarily switch context to keycloak backend
    const context = require('utils/context').default;
    originalBackend = context.authentication.backend;
    context.authentication.backend = 'keycloak';

    // Add keycloak account methods to AuthenticationApi
    originalAccount = AuthenticationApi!.account;
    AuthenticationApi!.account = {
      get: () => ({
        username: 'johndoe',
        firstName: 'John',
        lastName: 'Doe',
        email: 'johndoe@example.com',
      }),
      updateUrl: () => mockAccountUpdateUrl,
    };
  });

  // Must be called after beforeEach so fetchMock.restore() doesn't clear joanie mocks
  setupJoanieSession();

  afterEach(() => {
    // Restore original backend and account
    const context = require('utils/context').default;
    context.authentication.backend = originalBackend;
    AuthenticationApi!.account = originalAccount;

    act(() => {
      jest.runOnlyPendingTimers();
    });
    jest.useRealTimers();
    cleanup();
  });

  it('should render keycloak account name, email, and update link instead of OpenEdx profile', async () => {
    const product = CredentialProductFactory().one();
    const paymentPlan = PaymentPlanFactory().one();

    fetchMock
      .get(
        `https://joanie.endpoint/api/v1.0/orders/?${queryString.stringify({
          course_code: course.code,
          product_id: product.id,
          state: NOT_CANCELED_ORDER_STATES,
        })}`,
        [],
      )
      .get(
        `https://joanie.endpoint/api/v1.0/courses/${course.code}/products/${product.id}/payment-plan/`,
        paymentPlan,
      );

    render(<Wrapper product={product} isWithdrawable={true} paymentPlan={paymentPlan} />, {
      queryOptions: { client: createTestQueryClient({ user: richieUser }) },
    });

    // Should display the "Account name" heading
    await screen.findByRole('heading', { level: 4, name: 'Account name' });

    // Should display the username from the session
    screen.getByText(richieUser.username);

    // Should display the username info
    screen.getByText('This name will be used in legal documents.');

    // Should display the email from the session
    screen.getByText(richieUser.email!);

    // Should display the email info
    screen.getByText('This email will be used to send you confirmation mails.');

    // Should display the keycloak account update link (only the link part)
    const updateLink = screen.getByRole('link', {
      name: 'please update your account',
    });
    expect(updateLink).toHaveAttribute('href', mockAccountUpdateUrl);

    // Should NOT render the OpenEdx full name form
    expect(screen.queryByLabelText('First name and last name')).not.toBeInTheDocument();

    // No OpenEdx profile API calls should have been made
    expect(fetchMock.calls().filter(([url]) => url.includes('/api/user/v1/'))).toHaveLength(0);
  });

  it('should render keycloak account info when using fonzie-keycloak backend', async () => {
    // Switch to fonzie-keycloak backend
    const ctx = require('utils/context').default;
    ctx.authentication.backend = 'fonzie-keycloak';

    const product = CredentialProductFactory().one();
    const paymentPlan = PaymentPlanFactory().one();

    fetchMock
      .get(
        `https://joanie.endpoint/api/v1.0/orders/?${queryString.stringify({
          course_code: course.code,
          product_id: product.id,
          state: NOT_CANCELED_ORDER_STATES,
        })}`,
        [],
      )
      .get(
        `https://joanie.endpoint/api/v1.0/courses/${course.code}/products/${product.id}/payment-plan/`,
        paymentPlan,
      );

    render(<Wrapper product={product} isWithdrawable={true} paymentPlan={paymentPlan} />, {
      queryOptions: { client: createTestQueryClient({ user: richieUser }) },
    });

    // Should display the "Account name" heading (keycloak flow)
    await screen.findByRole('heading', { level: 4, name: 'Account name' });

    // Should display the username from the session
    screen.getByText(richieUser.username);

    // Should display the email from the session
    screen.getByText(richieUser.email!);

    // Should display the keycloak account update link
    const updateLink = screen.getByRole('link', {
      name: 'please update your account',
    });
    expect(updateLink).toHaveAttribute('href', mockAccountUpdateUrl);

    // Should NOT render the OpenEdx full name form
    expect(screen.queryByLabelText('First name and last name')).not.toBeInTheDocument();

    // No OpenEdx profile API calls should have been made
    expect(fetchMock.calls().filter(([url]) => url.includes('/api/user/v1/'))).toHaveLength(0);
  });
});
