"""
CodeSecure CLI - Cross-Platform Security Scanner.

Cross-platform CLI for Windows, Mac, and Linux.
PRD Section 5.1: IDE Integration - "Direct Python"
"""

import asyncio
import logging
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional

import click

from codesecure import __version__

# Removed direct ScannerEngine imports to enforce Layered Isolation
from codesecure.common.logging import get_logger
from codesecure.common.models import ScanMode, JobStatus
from codesecure.common.cloud_provider import CloudProvider, PROVIDER_CAPABILITIES, ProviderAvailability, SUPPORTED_PROVIDERS
from codesecure.common.config import is_terms_accepted, accept_terms
from codesecure.reports.generator import get_report_generator, ReportMetadata
from codesecure_cli.feedback import feedback
from codesecure.telemetry.client import TelemetryClient

# MCP Imports
import json
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

# Rich Imports
from rich.console import Console
from rich.progress import (
    Progress,
    SpinnerColumn,
    TextColumn,
    BarColumn,
    TaskProgressColumn,
    TimeElapsedColumn
)
from rich.live import Live
from rich.panel import Panel
from rich.prompt import Confirm

console = Console()

# Logger initialization
logger = get_logger(__name__)


def print_banner():
    """Print CodeSecure banner."""
    banner_content = "[bold deep_sky_blue1]🔒 CodeSecure Scanner[/bold deep_sky_blue1]\n[dim white]Enterprise-Grade Security Analysis Platform[/dim white]"
    
    panel = Panel(
        banner_content,
        subtitle="[bold gold1]BETA RELEASE[/bold gold1]",
        subtitle_align="right",
        border_style="bright_cyan",
        padding=(1, 4),
        expand=False
    )
    console.print(panel)


def print_success(message: str):
    """Print success message."""
    console.print(f"[bold spring_green3]✔[/bold spring_green3] [white]{message}[/white]")


def print_error(message: str):
    """Print error message."""
    console.print(f"[bold red]✖[/bold red] [orange_red1]{message}[/orange_red1]")


def print_info(message: str):
    """Print info message."""
    console.print(f"[bold sky_blue1]➜[/bold sky_blue1] [grey85]{message}[/grey85]")


def print_warning(message: str):
    """Print warning message."""
    console.print(f"[bold gold1]⚠ {message}[/bold gold1]")


def show_beta_terms():
    """Show Beta terms and ask for acceptance."""
    console.print("\n[bold white]Welcome to the CodeSecure CLI Beta![/bold white]")
    console.print("─" * 50)
    console.print("[bold yellow][!] This is pre-release software. Use at your own risk.[/bold yellow]")
    console.print("[bold green][✓] Privacy First: This tool collects ZERO telemetry or usage data.[/bold green]")
    console.print("\nBy continuing, you agree to our Beta Terms: [blue underline]https://codesecure.dev/beta-terms[/blue underline]")
    console.print()
    
    if Confirm.ask("Do you accept these terms?", default=False, console=console):
        accept_terms()
        print_success("Terms accepted. Welcome aboard!")
        return True
    else:
        print_error("You must accept the terms to use CodeSecure CLI.")
        return False


@click.group()
@click.version_option(version=__version__, prog_name="codesecure")
@click.pass_context
def cli(ctx):
    """
    CodeSecure - Enterprise Security Analysis CLI (Beta).
    
    Cross-platform security scanner for Windows, Mac, and Linux.
    This product is currently in Beta and undergoing active development.
    """
    # Skip terms check for help or version commands if possible
    # In Click, help/version usually short-circuit before the group callback
    # but we can check if a subcommand is about to be invoked.
    if not is_terms_accepted():
        # Only prompt if a subcommand is being invoked and it's not 'init'
        if ctx.invoked_subcommand and ctx.invoked_subcommand != 'init':
            if not show_beta_terms():
                ctx.exit(0)


@cli.command()
def init():
    """Initialize CodeSecure and accept Beta terms."""
    print_banner()
    if is_terms_accepted():
        print_info("CodeSecure is already initialized and terms are accepted.")
    else:
        if show_beta_terms():
            print_success("Initialization complete.")
        else:
            sys.exit(1)


@cli.command()
def login():
    """
    Login to AI providers and CodeSecure services.
    
    This command helps you authenticate with the AI providers used for enrichment.
    """
    print_banner()
    console.print("\n[bold sky_blue1]Authentication Guidance[/bold sky_blue1]")
    console.print("─" * 30)
    
    # Detect platform for correct env var hint
    if sys.platform == "win32":
        e_cmd = ""
        e_pfx = "$env:"
        e_sfx = "=\"value\""
    else:
        e_cmd = "export "
        e_pfx = ""
        e_sfx = "=\"value\""

    console.print("\n[bold bright_cyan]Google Gemini (SDK - API Key)[/bold bright_cyan]")
    console.print("  1. Get an API key from [bold white]https://aistudio.google.com/app/apikey[/bold white]")
    console.print(f"  2. Set Env: [bold white]{e_cmd}{e_pfx}GOOGLE_API_KEY{e_sfx}[/bold white]")
    console.print(f"  3. (Optional) Set Env: [bold white]{e_cmd}{e_pfx}GOOGLE_GEMINI_MODEL{e_sfx}[/bold white]")
    console.print("  4. Install SDK: [bold white]pip install \"codesecure[google]\"[/bold white]")

    console.print("\n[bold bright_cyan]Anthropic (Claude 3.5 Sonnet)[/bold bright_cyan]")
    console.print("  1. Get an API key from [bold white]https://console.anthropic.com/[/bold white]")
    console.print(f"  2. Set Env: [bold white]{e_cmd}{e_pfx}CODESECURE_ANTHROPIC_API_KEY{e_sfx}[/bold white]")
    console.print(f"  3. (Optional) Set Env: [bold white]{e_cmd}{e_pfx}CODESECURE_ANTHROPIC_MODEL{e_sfx}[/bold white]")
    console.print("  4. Install SDK: [bold white]pip install \"codesecure[anthropicai]\"[/bold white]")

    console.print("\n[bold bright_cyan]OpenAI (GPT-4o / GPT-4o-mini)[/bold bright_cyan]")
    console.print("  1. Get an API key from [bold white]https://platform.openai.com/api-keys[/bold white]")
    console.print(f"  2. Set Env: [bold white]{e_cmd}{e_pfx}CODESECURE_OPENAI_API_KEY{e_sfx}[/bold white]")
    console.print(f"  3. (Optional) Set Env: [bold white]{e_cmd}{e_pfx}CODESECURE_OPENAI_MODEL{e_sfx}[/bold white]")
    console.print("  4. Install SDK: [bold white]pip install \"codesecure[openai]\"[/bold white]")
    



@cli.command(name="mcp-server", hidden=True)
def mcp_server_command():
    """Internal command to start the MCP server."""
    # Import here to avoid circular dependencies
    from codesecure_mcp.scanner.server import main as server_main
    server_main()


@cli.command()
@click.argument("path", type=click.Path(exists=True, path_type=Path))
@click.option(
    "--format", "-f",
    type=click.Choice(["html", "json", "sarif", "markdown", "all"]),
    multiple=True,
    default=["all"],
    help="Output report format (default: all)"
)
@click.option(
    "--output", "-o",
    type=click.Path(path_type=Path),
    default=None,
    help="Output directory for reports (default: 'codesecure_scan_reports' in the scanned directory)"
)
@click.option(
    "--scanners", "-s",
    multiple=True,
    help="Specific scanners to run (default: all available)"
)
@click.option(
    "--mode", "-m",
    type=click.Choice(["local", "container"]),
    default="local",
    help="Execution mode (default: local)"
)
@click.option(
    "--timeout", "-t",
    type=int,
    default=480,
    help="Timeout per scanner in seconds (default: 480)"
)
@click.option(
    "--ai-provider",
    type=click.Choice(["google", "openai", "anthropic", "none"], case_sensitive=False),
    default=None,
    help="AI provider override for explicit false positive filtering (e.g., 'openai')"
)
@click.option(
    "--ai-api-key",
    type=str,
    default=None,
    envvar='CODESECURE_AI_API_KEY',
    help="API Key for the chosen AI provider (also via CODESECURE_AI_API_KEY)"
)
@click.option(
    "--fail-on", "-F",
    type=str,
    default=None,
    help="Comma-separated list of severities to fail the pipeline (e.g., 'critical,high')"
)
@click.option(
    "--ai-min-severity",
    type=click.Choice(["critical", "high", "medium", "low", "info"]),
    default="medium",
    help="Minimum severity threshold for AI enrichment (default: medium)"
)
def scan(
    path: Path,
    format: tuple,
    output: Optional[Path],
    scanners: tuple,
    mode: str,
    timeout: int,
    ai_provider: Optional[str] = None,
    ai_api_key: Optional[str] = None,
    fail_on: Optional[str] = None,
    ai_min_severity: str = "medium",
):
    """
    Run security scan on target path.
    
    PATH: Directory or file to scan.
    
    Example:
        codesecure scan ./my-project --format html
    """
    print_banner()
    
    start_time = datetime.now()
    console.print(f"\n[bold white]🚀 Scan Initiated:[/bold white] [bright_cyan]{start_time.strftime('%Y-%m-%d %H:%M:%S')}[/bright_cyan]")
    console.print("─" * 50)
    
    # Silence noise from report generator
    logging.getLogger("codesecure.reports.generator").setLevel(logging.WARNING)

    # Silence noise from MCP/Starlette/HTTPX
    logging.getLogger("mcp").setLevel(logging.WARNING)
    logging.getLogger("fastmcp").setLevel(logging.WARNING)
    logging.getLogger("starlette").setLevel(logging.WARNING)
    logging.getLogger("uvicorn").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.getLogger("httpx").setLevel(logging.WARNING)

    # Set base output directory
    if output:
        base_output_dir = output
    else:
        # Default to 'codesecure_scan_reports' relative to the path being scanned
        base_path = path if path.is_dir() else path.parent
        base_output_dir = base_path / "codesecure_scan_reports"
        
    base_output_dir.mkdir(parents=True, exist_ok=True)
    
    # Parse mode
    scan_mode = ScanMode.LOCAL if mode == "local" else ScanMode.CONTAINER
    
    # Parse scanners
    scanner_list = list(scanners) if scanners else None
    
    # Interactive provider selection if not provided
    if ai_provider is None:
        console.print("\n[bold cyan]🤖 AI Enrichment Options[/bold cyan]")
        console.print("CodeSecure can use AI to provide deeper security insights, remediation guidance, and false positive reduction.")
        
        if Confirm.ask("Would you like to enable AI-powered analysis?", default=False, console=console):
            console.print("\n[bold white]Available AI Providers & Pre-requisites:[/bold white]")
            
            # Helper for platform-specific env var syntax
            if sys.platform == "win32":
                env_hint = "[dim](PowerShell: [white]$env:KEY=\"val\"[/white] | CMD: [white]set KEY=val[/white])[/dim]"
            else:
                env_hint = "[dim](Bash/Zsh: [white]export KEY=\"val\"[/white])[/dim]"

            console.print("  [bold blue][1] Google Gemini (SDK)[/bold blue]")
            console.print("      • Pre-req: API Key from [white]aistudio.google.com[/white]")
            console.print(f"      • Config: Set [bold cyan]GOOGLE_API_KEY[/bold cyan] {env_hint}")

            console.print("  [bold blue][2] Anthropic (Claude 3.5)[/bold blue]")
            console.print("      • Pre-req: API Key from [white]console.anthropic.com[/white]")
            console.print(f"      • Config: Set [bold cyan]CODESECURE_ANTHROPIC_API_KEY[/bold cyan] {env_hint}")

            console.print("  [bold blue][3] OpenAI (GPT-4o)[/bold blue]")
            console.print("      • Pre-req: API Key from [white]platform.openai.com[/white]")
            console.print(f"      • Config: Set [bold cyan]CODESECURE_OPENAI_API_KEY[/bold cyan] {env_hint}")

            choice = click.prompt("\nSelect a provider (or 0 to cancel)", type=click.Choice(["0", "1", "2", "3"]), default="1")

            if choice == "0":
                print_info("AI enrichment declined. Proceeding with None.")
                cloud_provider = CloudProvider.NONE
            else:
                mapping = {
                    "1": CloudProvider.GOOGLE,
                    "2": CloudProvider.ANTHROPIC,
                    "3": CloudProvider.OPENAI,
                }
                cloud_provider = mapping[choice]
                display_name = "GOOGLE GEMINI" if cloud_provider.value == "google" else cloud_provider.value.upper()
                console.print(f"\n[bold green]Selected: {display_name}[/bold green]")
        else:
            print_info("Proceeding with AI features disabled (None).")
            cloud_provider = CloudProvider.NONE
    else:
        cloud_provider = CloudProvider(ai_provider)
    
    # Validate provider availability if not None
    if cloud_provider != CloudProvider.NONE:
        status = asyncio.run(ProviderAvailability.check_provider(cloud_provider, check_quota=True))
        if not status["available"]:
            console.print(f"\n[bold yellow]⚠ AI Provider '{cloud_provider.value}' not ready: {status['error']}[/bold yellow]")
            if Confirm.ask("Would you like to proceed with the scan without AI enrichment?", default=False, console=console):
                print_info("Proceeding with AI capabilities disabled.")
                cloud_provider = CloudProvider.NONE
                ai_provider = None
            else:
                print_error("Scan aborted. Please configure the AI provider and try again.")
                sys.exit(0)
    
    # Parse formats
    formats_to_gen = list(format)
    if "all" in formats_to_gen:
        formats_to_gen = ["html", "json", "sarif", "markdown"]

    # Set scan output directory
    scan_output_dir = base_output_dir / f"scan_{start_time.strftime('%Y%m%d_%H%M%S')}"
    scan_output_dir.mkdir(parents=True, exist_ok=True)

    # Provider capabilities for UI
    caps = PROVIDER_CAPABILITIES.get(cloud_provider)
    
    display_map = {
        "google": "GOOGLE GEMINI",
        "openai": "OPENAI",
        "anthropic": "ANTHROPIC",
        "none": "None"
    }
    
    if ai_provider:
        effective_ai_display = display_map.get(ai_provider.lower(), ai_provider.upper())
    else:
        effective_ai_display = display_map.get(cloud_provider.value.lower(), "None") if cloud_provider != CloudProvider.NONE else "None"

    # Show configuration
    conf_content = (
        f"[bold sky_blue1]Target:[/bold sky_blue1]   [blue]{path.resolve()}[/blue]\n"
        f"[bold sky_blue1]Mode:[/bold sky_blue1]     [white]{mode.capitalize()}[/white]\n"
        f"[bold sky_blue1]Output:[/bold sky_blue1]   [white]{', '.join([f.upper() for f in formats_to_gen])}[/white]\n"
        f"[bold sky_blue1]Provider:[/bold sky_blue1] [bright_cyan]{effective_ai_display}[/bright_cyan]\n"
        f"[bold sky_blue1]AI Threshold:[/bold sky_blue1] [yellow]{ai_min_severity.upper()}+[/yellow]\n"
        f"[dim]AI Review: {'✅' if caps.code_review_enabled or ai_provider else '❌'}  |  FP Detection: {'✅' if caps.false_positive_detection or ai_provider else '❌'}[/dim]"
    )
    
    console.print(Panel(conf_content, title="[bold white]Scan Configuration[/bold white]", border_style="bright_cyan", expand=False))
    console.print()

    # Run scan
    try:
        result = asyncio.run(_run_scan(
            path, 
            scanner_list, 
            scan_mode, 
            timeout, 
            cloud_provider,
            ai_provider_override=ai_provider,
            api_key_override=ai_api_key,
            ai_min_severity=ai_min_severity
        ))
    except Exception as e:
        print_error(f"Scan failed: {e}")
        sys.exit(1)
    
    # Evaluate Quality Gate
    gate_failed = False
    if fail_on:
        thresholds = [s.strip().lower() for s in fail_on.split(",")]
        for sev in thresholds:
            if result.findings_by_severity.get(sev, 0) > 0:
                gate_failed = True
                break
    
    end_time = datetime.now()
    duration = end_time - start_time
    
    console.print("─" * 50)
    console.print("\n[bold white]📊 Scan Summary[/bold white]")
    console.print("─" * 50)
    
    # Show summary
    if result.success:
        files_suffix = f" across {result.scanned_files} files" if result.scanned_files > 0 else ""
        if result.total_findings > 0:
            print_success(f"Scan completed: {result.total_findings} findings identified{files_suffix}")
        else:
            print_success(f"Scan completed: No security issues found{files_suffix} 🎉")
            
        if result.errors:
            print_warning(f"Note: {len(result.errors)} tool errors occurred during execution")
        
        # Show severity breakdown
        severity_counts = result.findings_by_severity
        if result.total_findings > 0:
            console.print("\n[dim]Findings Breakdown:[/dim]")
            for sev in ["critical", "high", "medium", "low"]:
                count = severity_counts.get(sev, 0)
                if count > 0:
                    color = {"critical": "bold red", "high": "orange_red1", "medium": "gold1", "low": "deep_sky_blue1"}[sev]
                    console.print(f"  [bold {color}]• {sev.upper():<8}:[/bold {color}] [white]{count}[/white]")
        
        # Show errors for partial success
        if result.total_false_positives > 0:
            console.print(f"\n[dim]AI suppressed {result.total_false_positives} false positive(s)[/dim]")

        if result.errors:
            console.print("\n[bold gold1]⚠️  Scanner Diagnostics[/bold gold1]")
            for error in result.errors:
                print_error(f"  {error}")
                
    else:
        print_error(f"Scan failed with {len(result.errors)} errors")
        for error in result.errors:
            print_error(f"  {error}")
    
    # Evidence Location
    console.print(f"\n[bold white]📂 Evidence Location[/bold white]")
    console.print(f"   [dim cyan]{scan_output_dir}[/dim cyan]")

    # Generate reports
    console.print(f"\n[bold white]📝 Security Reports Generated[/bold white]")
    report_files = []
    for fmt in formats_to_gen:
        try:
            report_path = _generate_report(result, fmt, scan_output_dir, path)
            report_files.append((fmt.upper(), report_path.name))
        except Exception as e:
            print_error(f"  • {fmt.upper():<8} : Failed ({e})")
            
    for fmt_name, filename in report_files:
        console.print(f"  • [bold sky_blue1]{fmt_name:<10}:[/bold sky_blue1] [white]{filename}[/white]")
            
    console.print("─" * 50)
    console.print(f"[bold white]🏁 Scan Finished:[/bold white] [bright_cyan]{end_time.strftime('%Y-%m-%d %H:%M:%S')}[/bright_cyan]")
    
    # Calculate minutes and seconds
    mins, secs = divmod(int(duration.total_seconds()), 60)
    duration_str = f"{mins}m {secs}s" if mins > 0 else f"{secs}s"
    console.print(f"[bold spring_green3]⏱️  Total Duration:[/bold spring_green3] [white]{duration_str}[/white]\n")
    
    console.print("[dim italic cyan]💡 Have feedback? Run 'codesecure feedback' to help us improve![/dim italic cyan]\n")

    # Exit code based on Quality Gate
    if gate_failed:
        print_error(f"Quality Gate Failed: Found findings matching --fail-on thresholds ({fail_on})")
        sys.exit(1)


async def _run_scan(
    path: Path,
    scanners: Optional[List[str]],
    mode: ScanMode,
    timeout: int,
    cloud_provider: CloudProvider,
    ai_provider_override: Optional[str] = None,
    api_key_override: Optional[str] = None,
    ai_min_severity: str = "medium"
):
    """Run the scan asynchronously via Direct Python Core API."""
    from codesecure.scanners.engine import get_scanner_engine
    from codesecure.jobs.manager import get_job_manager
    from codesecure.ai_providers.manager import get_ai_manager
    from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn, TimeElapsedColumn
    
    # Initialize the overriding AI Manager before the engine starts
    get_ai_manager(
        cloud_provider=cloud_provider, 
        ai_provider_override=ai_provider_override, 
        api_key_override=api_key_override,
        min_severity=ai_min_severity
    )
    
    engine = get_scanner_engine()
    job_manager = get_job_manager()
    
    print_info("Initializing Hexagonal Core...")
    
    job_id_box = {"id": None}
    
    async def scan_task():
        for _ in range(50):
            if job_id_box["id"]:
                break
            await asyncio.sleep(0.01)
            
        job_id = job_id_box["id"]
        
        async def progress_cb(pct, msg):
            if job_id:
                await job_manager.update_job(job_id, pct, status=JobStatus.RUNNING)
        
        return await engine.run_scan_with_progress(
            path, job_id, scanners, mode, timeout=timeout, 
            progress_callback=progress_cb, cloud_provider=cloud_provider
        )
        
    scan_job_id = await job_manager.create_job("scan", scan_task())
    job_id_box["id"] = scan_job_id
    
    click.echo(click.style("➜ ", fg="cyan") + "Scan Engine Started")
    
    with Progress(
        SpinnerColumn(spinner_name="dots", style="cyan"),
        TextColumn("[bold blue]{task.description}"),
        BarColumn(bar_width=40, style="blue", complete_style="green"),
        TaskProgressColumn(),
        "•",
        TimeElapsedColumn(),
        console=console
    ) as progress_bar:
        scan_task_bar = progress_bar.add_task("Initializing...", total=100)
        
        while True:
            status_data = await job_manager.get_status(scan_job_id)
            if not status_data:
                await asyncio.sleep(0.5)
                continue
                
            progress_val = status_data.get("progress", 0)
            state = status_data.get("state", "pending").lower()
            
            if progress_val < 5:
                desc = f"Initializing scan engine..."
            elif progress_val < 15:
                desc = f"Starting security tools..."
            elif progress_val < 75:
                desc = f"Running scanners..."
            elif progress_val < 80:
                desc = f"Merging findings..."
            elif progress_val < 90:
                desc = f"Enriching with AI analysis..."
            else:
                desc = f"Finalizing results..."
            
            progress_bar.update(scan_task_bar, completed=progress_val, description=desc)
            
            if state == "completed":
                progress_bar.update(scan_task_bar, completed=100, description="[bold green]Scan completed successfully[/bold green]")
                break
            elif state in ["failed", "cancelled", "timeout"]:
                error = status_data.get("error", "Unknown error")
                progress_bar.update(scan_task_bar, description=f"[bold red]Scan {state}[/bold red]")
                raise Exception(f"Scan failed: {error}")
            
            await asyncio.sleep(0.5)
            
    result = await job_manager.get_result(scan_job_id)
    if not result:
        raise Exception("Scan completed but no result was found.")
    return result


def _get_available_scanners(mode: ScanMode) -> List[str]:
    """Get available scanners directly from the core engine."""
    from codesecure.scanners.engine import get_scanner_engine
    engine = get_scanner_engine()
    return engine.get_available_scanners(mode)


def _generate_report(result, format: str, output_dir: Path, scan_target: Path) -> Path:
    """Generate report and return path."""
    generator = get_report_generator()
    
    metadata = ReportMetadata(
        title="CodeSecure Security Scan Report",
        scan_target=str(scan_target.resolve()),
        scan_duration=result.duration_seconds,
        job_id=result.job_id,
    )
    
    return generator.generate(result, format, output_dir, metadata)


@cli.command()
@click.argument("path", type=click.Path(exists=True, path_type=Path))
@click.option(
    "--format", "-f",
    type=click.Choice(["html", "json", "sarif", "markdown", "all"]),
    multiple=True,
    default=["all"],
    help="Output report format (default: all)"
)
@click.option(
    "--output", "-o",
    type=click.Path(path_type=Path),
    default=None,
    help="Output directory for reports (default: 'codesecure_reports' in the scanned directory)"
)
def report(path: Path, format: tuple, output: Optional[Path]):
    """
    Generate report from previous scan results.
    
    PATH: Path to a previously generated CodeSecure JSON report file.
    
    Example:
        codesecure report ./codesecure_scan_reports/scan_1/report.json --format html
    """
    print_banner()
    
    start_time = datetime.now()
    console.print(f"\n[bold white]📝 Report Generation Initiated:[/bold white] [bright_cyan]{start_time.strftime('%Y-%m-%d %H:%M:%S')}[/bright_cyan]")
    console.print("─" * 50)
    
    if path.is_dir() or not path.name.endswith(".json"):
        print_error("PATH must be a .json file generated by a previous CodeSecure scan.")
        sys.exit(1)
        
    formats_to_gen = list(format)
    if "all" in formats_to_gen:
        formats_to_gen = ["html", "json", "sarif", "markdown"]
        
    if output:
        base_output_dir = output
    else:
        base_output_dir = path.parent
        
    base_output_dir.mkdir(parents=True, exist_ok=True)
    
    # Show configuration
    conf_content = (
        f"[bold sky_blue1]Input JSON:[/bold sky_blue1] [blue]{path.resolve()}[/blue]\n"
        f"[bold sky_blue1]Output Dir:[/bold sky_blue1] [blue]{base_output_dir.resolve()}[/blue]\n"
        f"[bold sky_blue1]Formats:[/bold sky_blue1]    [white]{', '.join([f.upper() for f in formats_to_gen])}[/white]\n"
    )
    console.print(Panel(conf_content, title="[bold white]Report Configuration[/bold white]", border_style="bright_cyan", expand=False))
    console.print()
    
    try:
        from codesecure.common.models import ScanResult
        
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
            
        print_info(f"Loaded JSON payload from '{path.name}'...")
        
        # Validating the JSON string data against the Pydantic ScanResult model
        result = ScanResult.model_validate(data)
        print_success(f"Successfully unpacked {result.total_findings} findings.")
        
    except Exception as e:
        print_error(f"Failed to load or parse JSON scan result: {e}")
        sys.exit(1)
        
    console.print(f"\n[bold white]📝 Generated Reports[/bold white]")
    report_files = []
    
    # Re-use the _generate_report logic passing the re-created result obj
    for fmt in formats_to_gen:
        try:
            report_path = _generate_report(result, fmt, base_output_dir, path)
            report_files.append((fmt.upper(), report_path.name))
        except Exception as e:
            print_error(f"  • {fmt.upper():<8} : Failed ({e})")
            
    for fmt_name, filename in report_files:
        console.print(f"  • [bold sky_blue1]{fmt_name:<10}:[/bold sky_blue1] [white]{filename}[/white]")
            
    console.print("─" * 50)
    console.print(f"[bold white]🏁 Finished:[/bold white] [bright_cyan]{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}[/bright_cyan]\n")


@cli.command("threat-model", hidden=True)
@click.argument("path", type=click.Path(exists=True, path_type=Path))
@click.option(
    "--provider", "-p",
    type=click.Choice(["google", "aws", "azure"]),
    default="google",
    help="AI provider for analysis"
)
@click.option(
    "--output", "-o",
    type=click.Path(path_type=Path),
    default=None,
    help="Output directory"
)
def threat_model(path: Path, provider: str, output: Optional[Path]):
    """
    Generate STRIDE threat model.
    
    PATH: Repository or architecture document path.
    """
    print_info("Threat model generation using ThreatModel module")
    print_warning("Threat model CLI integration pending TM-001 implementation")


@cli.command(hidden=True)
@click.argument("path", type=click.Path(exists=True, path_type=Path))
@click.option(
    "--type", "-t",
    type=click.Choice(["terraform", "cdk", "cloudformation"]),
    default="terraform",
    help="IaC type"
)
def validate(path: Path, type: str):
    """
    Detect infrastructure drift.
    
    PATH: IaC project path.
    """
    print_info("Drift detection using SecurityValidate module")
    print_warning("Validate CLI integration pending SV-001 implementation")


@cli.command(hidden=True)
@click.argument("path", type=click.Path(exists=True, path_type=Path))
def matrix(path: Path):
    """
    Generate DSR Security Matrix via core framework.
    
    PATH: Project path.
    """
    print_info("Security Matrix generation using NeoLifter module")
    print_warning("Matrix CLI integration pending SM-001 implementation")


@cli.command()
def list_scanners():
    """List available security scanners from Core."""
    print_banner()
    
    try:
        local_scanners = _get_available_scanners(ScanMode.LOCAL)
        all_scanners = _get_available_scanners(ScanMode.CONTAINER)
    except Exception as e:
        print_error(f"Failed to list scanners: {e}")
        return

    click.echo(click.style("\n📋 Available Scanners:\n", bold=True))
    
    click.echo(click.style("Local + Container Mode:", fg="cyan", bold=True))
    for name in local_scanners:
        click.echo(f"  • {name}")
    
    click.echo(click.style("\nContainer Mode Only:", fg="yellow", bold=True))
    container_only = set(all_scanners) - set(local_scanners)
    for name in container_only:
        click.echo(f"  • {name}")
    
    # Platform specific notes
    if sys.platform == "win32":
        click.echo()
        print_warning("Note for Windows users:")
        click.echo("  • 'semgrep' is not supported natively on Windows.")
        click.echo("  • Use WSL or Docker mode for full coverage.")


def main_entry():
    """Main entry point."""
    # Register external commands
    cli.add_command(feedback)
    
    try:
        cli()
    except Exception as e:
        # Let Click handle its own exceptions (Abort, UsageError, etc.)
        if isinstance(e, click.ClickException) or isinstance(e, SystemExit):
            raise
            
        # Handle unexpected exceptions
        console.print(f"\n[bold red]An unexpected error occurred: {e}[/bold red]")
        
        # Ask for permission to send error report
        if Confirm.ask("Would you like to send an automated error report to help us fix this?", default=True, console=console):
            client = TelemetryClient()
            with console.status("[bold green]Sending error report...", spinner="dots"):
                tb = traceback.format_exc()
                success = client.send_error_report(str(e), tb)
            
            if success:
                console.print("[green]Error report sent. Thank you![/green]")
            else:
                console.print("[yellow]Failed to send error report, but thank you for trying![/yellow]")
        
        # Exit with error code
        sys.exit(1)


if __name__ == "__main__":
    main_entry()
