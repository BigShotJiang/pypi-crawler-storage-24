"""
Individual Correlation Primitives

Single-signal correlation measures: autocorrelation, PACF.
"""

import numpy as np
from typing import Optional

import pmtvs_correlation._rust as _rust


def autocorrelation(signal: np.ndarray, lag: int = 1) -> float:
    """
    Compute autocorrelation at specified lag.

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    lag : int
        Time lag

    Returns
    -------
    float
        Autocorrelation at lag
    """
    signal = np.ascontiguousarray(np.asarray(signal, dtype=np.float64).flatten())
    return _rust.autocorrelation(signal, lag)


def partial_autocorrelation(signal: np.ndarray, max_lag: int = 10) -> np.ndarray:
    """
    Compute partial autocorrelation function (PACF).

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    max_lag : int
        Maximum lag

    Returns
    -------
    np.ndarray
        PACF values for lags 0 to max_lag
    """
    signal = np.ascontiguousarray(np.asarray(signal, dtype=np.float64).flatten())
    return np.asarray(_rust.partial_autocorrelation(signal, max_lag))


def autocorrelation_function(signal: np.ndarray, max_lag: Optional[int] = None) -> np.ndarray:
    """
    Compute full autocorrelation function.

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    max_lag : int, optional
        Maximum lag (default: len(signal) // 2)

    Returns
    -------
    np.ndarray
        ACF values for lags 0 to max_lag
    """
    signal = np.ascontiguousarray(np.asarray(signal, dtype=np.float64).flatten())
    signal = signal[~np.isnan(signal)]
    ml = max_lag if max_lag is not None else -1
    return np.asarray(_rust.autocorrelation_function(signal, ml))


def acf_decay_time(signal: np.ndarray, threshold: float = 1.0 / np.e) -> float:
    """
    Compute ACF decay time (lag where ACF drops below threshold).

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    threshold : float
        Threshold value (default: 1/e)

    Returns
    -------
    float
        Decay time (in samples)
    """
    signal = np.ascontiguousarray(np.asarray(signal, dtype=np.float64).flatten())
    signal = signal[~np.isnan(signal)]
    return float(_rust.acf_decay_time(signal, threshold))
