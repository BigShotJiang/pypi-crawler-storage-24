"""
pmtvs-correlation — Correlation primitives for signal analysis.

numpy in, number out.
"""

__version__ = "0.5.1"
BACKEND = "rust"

try:
    import pmtvs_correlation._rust  # noqa: F401 — validates Rust extension is loadable
except ImportError as e:
    raise ImportError(
        f"\n\nRust extension not found: {e}\n"
        f"The pmtvs framework requires compiled Rust extensions.\n"
        f"Install with: cd packages/pmtvs-correlation && maturin develop --release\n"
        f"Or rebuild the Docker image.\n"
    ) from e

# --- Public API ---
from pmtvs_correlation.individual import (
    autocorrelation,
    partial_autocorrelation,
    autocorrelation_function,
    acf_decay_time,
)

from pmtvs_correlation.pairwise import (
    correlation,
    covariance,
    cross_correlation,
    lag_at_max_xcorr,
    partial_correlation,
    coherence,
    cross_spectral_density,
    phase_spectrum,
    wavelet_coherence,
    spearman_correlation,
    kendall_tau,
)

__all__ = [
    "__version__",
    "BACKEND",
    # Individual
    "autocorrelation",
    "partial_autocorrelation",
    "autocorrelation_function",
    "acf_decay_time",
    # Pairwise
    "correlation",
    "covariance",
    "cross_correlation",
    "lag_at_max_xcorr",
    "partial_correlation",
    "coherence",
    "cross_spectral_density",
    "phase_spectrum",
    "wavelet_coherence",
    "spearman_correlation",
    "kendall_tau",
]
