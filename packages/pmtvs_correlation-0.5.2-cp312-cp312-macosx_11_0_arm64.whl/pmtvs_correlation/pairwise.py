"""
Pairwise Correlation Primitives

Two-signal correlation measures: correlation, covariance, cross-correlation, coherence.
"""

import numpy as np
from typing import Optional, Tuple

import pmtvs_correlation._rust as _rust


def correlation(x: np.ndarray, y: np.ndarray) -> float:
    """
    Compute Pearson correlation coefficient.

    Parameters
    ----------
    x : np.ndarray
        First signal
    y : np.ndarray
        Second signal

    Returns
    -------
    float
        Correlation coefficient in [-1, 1]
    """
    x = np.ascontiguousarray(np.asarray(x, dtype=np.float64).flatten())
    y = np.ascontiguousarray(np.asarray(y, dtype=np.float64).flatten())
    return _rust.correlation(x, y)


def covariance(x: np.ndarray, y: np.ndarray) -> float:
    """
    Compute covariance between two signals.

    Parameters
    ----------
    x : np.ndarray
        First signal
    y : np.ndarray
        Second signal

    Returns
    -------
    float
        Covariance
    """
    x = np.ascontiguousarray(np.asarray(x, dtype=np.float64).flatten())
    y = np.ascontiguousarray(np.asarray(y, dtype=np.float64).flatten())
    return _rust.covariance(x, y)


def cross_correlation(
    x: np.ndarray,
    y: np.ndarray,
    max_lag: Optional[int] = None,
    normalize: bool = True
) -> np.ndarray:
    """
    Compute cross-correlation between two signals.

    Parameters
    ----------
    x : np.ndarray
        First signal
    y : np.ndarray
        Second signal
    max_lag : int, optional
        Maximum lag (default: len(x) - 1)
    normalize : bool
        If True, normalize to [-1, 1]

    Returns
    -------
    np.ndarray
        Cross-correlation values for lags [-max_lag, max_lag]
    """
    x = np.ascontiguousarray(np.asarray(x, dtype=np.float64).flatten())
    y = np.ascontiguousarray(np.asarray(y, dtype=np.float64).flatten())
    ml = max_lag if max_lag is not None else -1
    return np.asarray(_rust.cross_correlation(x, y, ml, normalize))


def lag_at_max_xcorr(x: np.ndarray, y: np.ndarray, max_lag: Optional[int] = None) -> int:
    """
    Find lag at maximum cross-correlation.

    Parameters
    ----------
    x : np.ndarray
        First signal
    y : np.ndarray
        Second signal
    max_lag : int, optional
        Maximum lag to search

    Returns
    -------
    int
        Lag at maximum cross-correlation
    """
    x = np.ascontiguousarray(np.asarray(x, dtype=np.float64).flatten())
    y = np.ascontiguousarray(np.asarray(y, dtype=np.float64).flatten())
    ml = max_lag if max_lag is not None else -1
    return int(_rust.lag_at_max_xcorr(x, y, ml))


def partial_correlation(x: np.ndarray, y: np.ndarray, z: np.ndarray) -> float:
    """
    Compute partial correlation between x and y, controlling for z.

    Parameters
    ----------
    x : np.ndarray
        First signal
    y : np.ndarray
        Second signal
    z : np.ndarray
        Control signal

    Returns
    -------
    float
        Partial correlation coefficient
    """
    x = np.ascontiguousarray(np.asarray(x, dtype=np.float64).flatten())
    y = np.ascontiguousarray(np.asarray(y, dtype=np.float64).flatten())
    z = np.ascontiguousarray(np.asarray(z, dtype=np.float64).flatten())
    return float(_rust.partial_correlation(x, y, z))


def coherence(
    x: np.ndarray,
    y: np.ndarray,
    nperseg: int = 256
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Compute magnitude-squared coherence.

    Parameters
    ----------
    x : np.ndarray
        First signal
    y : np.ndarray
        Second signal
    nperseg : int
        Segment length for FFT

    Returns
    -------
    tuple
        (frequencies, coherence values)
    """
    x = np.ascontiguousarray(np.asarray(x, dtype=np.float64).flatten())
    y = np.ascontiguousarray(np.asarray(y, dtype=np.float64).flatten())
    freqs, coh = _rust.coherence(x, y, nperseg)
    return np.asarray(freqs), np.asarray(coh)


def cross_spectral_density(
    x: np.ndarray,
    y: np.ndarray,
    nperseg: int = 256
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Compute cross-spectral density.

    Parameters
    ----------
    x : np.ndarray
        First signal
    y : np.ndarray
        Second signal
    nperseg : int
        Segment length for FFT

    Returns
    -------
    tuple
        (frequencies, cross-spectral density)
    """
    x = np.ascontiguousarray(np.asarray(x, dtype=np.float64).flatten())
    y = np.ascontiguousarray(np.asarray(y, dtype=np.float64).flatten())
    freqs, csd_re, csd_im = _rust.cross_spectral_density(x, y, nperseg)
    csd = np.asarray(csd_re) + 1j * np.asarray(csd_im)
    return np.asarray(freqs), csd


def phase_spectrum(
    x: np.ndarray,
    y: np.ndarray,
    nperseg: int = 256
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Compute phase spectrum between two signals.

    Parameters
    ----------
    x : np.ndarray
        First signal
    y : np.ndarray
        Second signal
    nperseg : int
        Segment length for FFT

    Returns
    -------
    tuple
        (frequencies, phase angles in radians)
    """
    freqs, csd = cross_spectral_density(x, y, nperseg)

    if len(freqs) == 1 and np.isnan(freqs[0]):
        return np.array([np.nan]), np.array([np.nan])

    phase = np.angle(csd)
    return freqs, phase


def spearman_correlation(x: np.ndarray, y: np.ndarray) -> float:
    """
    Compute Spearman rank correlation coefficient.

    Parameters
    ----------
    x : np.ndarray
        First signal
    y : np.ndarray
        Second signal

    Returns
    -------
    float
        Spearman correlation in [-1, 1]
    """
    x = np.ascontiguousarray(np.asarray(x, dtype=np.float64).flatten())
    y = np.ascontiguousarray(np.asarray(y, dtype=np.float64).flatten())
    return float(_rust.spearman_correlation(x, y))


def kendall_tau(x: np.ndarray, y: np.ndarray) -> float:
    """
    Compute Kendall's tau rank correlation (tau-a).

    Parameters
    ----------
    x : np.ndarray
        First signal
    y : np.ndarray
        Second signal

    Returns
    -------
    float
        Kendall's tau in [-1, 1]
    """
    x = np.ascontiguousarray(np.asarray(x, dtype=np.float64).flatten())
    y = np.ascontiguousarray(np.asarray(y, dtype=np.float64).flatten())
    return float(_rust.kendall_tau(x, y))


def wavelet_coherence(
    x: np.ndarray,
    y: np.ndarray,
    scales: Optional[np.ndarray] = None,
    wavelet: str = 'morlet'
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Compute wavelet coherence (simplified implementation).

    Parameters
    ----------
    x : np.ndarray
        First signal
    y : np.ndarray
        Second signal
    scales : np.ndarray, optional
        Scales for wavelet transform (default: log-spaced)
    wavelet : str
        Wavelet type (currently only 'morlet' supported)

    Returns
    -------
    tuple
        (scales, coherence values averaged over time)
    """
    x = np.ascontiguousarray(np.asarray(x, dtype=np.float64).flatten())
    y = np.ascontiguousarray(np.asarray(y, dtype=np.float64).flatten())

    if scales is not None:
        # Use provided scales with per-scale windowed correlation
        if len(x) != len(y) or len(x) < 10:
            return np.array([np.nan]), np.array([np.nan])

        n = len(x)
        coherences = []
        for scale in scales:
            if scale >= n:
                coherences.append(np.nan)
                continue
            n_windows = n // scale
            if n_windows < 2:
                coherences.append(np.nan)
                continue
            corrs = []
            for w in range(n_windows):
                start = w * scale
                end = start + scale
                r = float(_rust.correlation(x[start:end], y[start:end]))
                if np.isfinite(r):
                    corrs.append(r ** 2)
            coherences.append(np.mean(corrs) if corrs else np.nan)
        return scales, np.array(coherences)

    s, c = _rust.wavelet_coherence(x, y, 20)
    return np.asarray(s), np.asarray(c)
