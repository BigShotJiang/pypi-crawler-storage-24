# Curly

A TUI swiss army knife for JSON, built with [Textual](https://github.com/Textualize/textual).

```
 ██████╗██╗   ██╗██████╗ ██╗  ██╗   ██╗
██╔════╝██║   ██║██╔══██╗██║  ╚██╗ ██╔╝
██║     ██║   ██║██████╔╝██║   ╚████╔╝
██║     ██║   ██║██╔══██╗██║    ╚██╔╝
╚██████╗╚██████╔╝██║  ██║███████╗██║
 ╚═════╝ ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝
```

## Features

- **Format** (F2) — Pretty-print pasted JSON with proper indentation
- **Preview** (F3) — Browse JSON structure as a collapsible tree
- **Search** (F4) — Find any key or value with live highlighting
- **Diff** (F5) — Compare two JSON documents side-by-side with added/removed/changed markers

## Quick Start

```bash
pipx install curly-json
curly
```

Paste JSON into the editor and use the function keys to explore it.

### Diff two files directly

```bash
curly a.json b.json
```

## Keybindings

| Key | Action |
|---|---|
| `F2` | Format / pretty-print |
| `F3` | Tree preview |
| `F4` | Search keys & values |
| `F5` | Diff mode |
| `Ctrl+C` | Copy output to clipboard |
| `Ctrl+Q` | Quit |

## Requirements

- Python 3.10+
- [Textual](https://github.com/Textualize/textual)
