# fastpluggy-debug-tools

Debug Tools plugin for FastPluggy — runtime introspection and diagnostics.

## Install

```bash
pip install -e .
```

Optional extras for memory profiling:

```bash
pip install -e ".[all]"
```

## Usage

Register the plugin in your FastPluggy configuration. Once loaded it provides diagnostic pages for inspecting the running application: loaded plugins, configuration, routes, and memory usage.
