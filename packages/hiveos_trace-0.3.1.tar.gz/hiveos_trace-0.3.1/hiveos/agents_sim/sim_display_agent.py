import uuid
from hiveos.agent_interface import AgentInterface
import time

class SimDisplayAgent(AgentInterface):
    def __init__(self, agent_id=None, capability="display"):
        self.agent_id = agent_id or f"sim-display-{str(uuid.uuid4())[:8]}"
        self.name = f"SimDisplay-{str(uuid.uuid4())[:4]}"
        #self.zone = None
        #self.status = "idle"
        self.capabilities = [capability]
        #self._available = True
        self.current_chunk = None
        #self.chunk_obj = None
        #self.chunk_progress = 0
        #self.required_ticks = 0

        self.latest_output = ""

    def get_status(self):
        return self.status

    def report_capabilities(self):
        return self.capabilities
     
    def execute_chunk(self, chunk, payload=None):
        super().execute_chunk(chunk, payload)
        
        if isinstance(payload, dict):
            intent = payload.get("intent")
            params = payload.get("parameters", {})
            if intent == "render_text" and "text" in params:
                self.latest_output = params["text"]
            else:
                self.latest_output = f"{intent}: {params}"
        else:
            self.latest_output = str(payload)

    
    def report_completion(self, chunk):  
        super().report_completion(chunk)

    def health_check(self):
        return True

    def enter_cooldown(self, reason=""):
        self.status = 'cooldown'
        self.publish("cooldown_reason", reason)

    def is_available(self):
        return self._available and self.status == 'idle'

    def get_summary(self) -> dict:
        return super().get_summary() | { 
            "latest_output": self.latest_output,
        }