import uuid
import random
from hiveos.agent_interface import AgentInterface
#from hiveos.runtime.agent_runtime import register

class RandomValueAgent(AgentInterface):
    def __init__(self, agent_id=None, capability="random-output"):
        self.agent_id = agent_id or f"random-value-{str(uuid.uuid4())[:8]}"
        self.name = f"RandomValue-{str(uuid.uuid4())[:4]}"
        self.zone = None
        self.status = "idle"
        self.capabilities = [capability]
        self._available = True
        self.current_chunk = None
        self.chunk_obj = None
        self.chunk_progress = 0
        self.required_ticks = 0

        self.default_output_key = "random_value"

        # register(self)

    def get_status(self):
        return self.status

    def report_capabilities(self):
        return self.capabilities

    def execute_chunk(self, chunk, payload=None):
        super().execute_chunk(chunk, payload)

        if isinstance(payload, dict):
            intent = payload.get("intent")
            params = payload.get("parameters", {})

            if intent == "publish_random":
                min_val = int(params.get("min", 0))
                max_val = int(params.get("max", 100))
                output_key = params.get("output_key", self.default_output_key)

                value = random.randint(min_val, max_val)

                if self.zone and self.message_bus:
                    self.message_bus.publish(output_key, value)
                    print(f"[{self.agent_id}] Published {output_key}: {value}")
                else:
                    print(f"[{self.agent_id}] Skipped publish (no zone or bus)")
            else:
                print(f"[{self.agent_id}] Unsupported intent: {intent}")
        else:
            print(f"[{self.agent_id}] Invalid payload: {payload}")



    def report_completion(self, chunk):
        super().report_completion(chunk)

    def health_check(self):
        return True

    def enter_cooldown(self, reason=""):
        self.status = 'cooldown'

    def is_available(self):
        return self._available and self.status == 'idle'

    def get_summary(self):
        return super().get_summary() | {
            "type": "RandomValueAgent",
        }