# hiveos/runtime/runtime_agent.py

class RuntimeAgent:
    def __init__(self, agent_id, obj, session_id):
        self.agent_id = agent_id
        self.obj = obj  # Holds the actual agent wrapper (SimDisplay, Terminal, etc)
        self.session_id = session_id

    def get_summary(self):
        return self.obj.get_summary()
        
    def to_dict(self):
        data = self.obj.get_summary().copy()
        data["agent_id"] = self.agent_id
        data["type"] = type(self.obj).__name__
        data["session_id"] = self.session_id
        return data


def register(agent_obj, core):
    from hiveos.models.agent import Agent as AgentModel

    # Create agent in DB
    AgentModel.create(
        agent_id=agent_obj.agent_id,
        capabilities=agent_obj.capabilities,
        zone=agent_obj.zone,
        session_id=core.session_id
    )

    # Register in local runtime
    wrapped = RuntimeAgent(agent_obj.agent_id, agent_obj, core.session_id)
    core._runtime_agents[agent_obj.agent_id] = wrapped