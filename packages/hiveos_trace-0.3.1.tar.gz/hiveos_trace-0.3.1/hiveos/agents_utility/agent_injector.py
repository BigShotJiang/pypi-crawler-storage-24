import uuid
from hiveos.agent_interface import AgentInterface

class AgentInjector(AgentInterface):
    def __init__(self, agent_id=None, capability="agent_injector"):
        self.agent_id = agent_id or f"agent-injector-{str(uuid.uuid4())[:8]}"
        self.name = f"AgentInjector-{str(uuid.uuid4())[:4]}"
        self.zone = None
        self.status = "idle"
        self.capabilities = [capability]
        self._available = True
        self.current_chunk = None
        self.chunk_obj = None
        self.chunk_progress = 0
        self.required_ticks = 0

    def get_status(self):
        return self.status

    def report_capabilities(self):
        return self.capabilities

    def execute_chunk(self, chunk, payload=None):
        super().execute_chunk(chunk, payload)

        if not isinstance(payload, dict):
            self.enter_cooldown("Invalid payload format")
            return

        intent = payload.get("intent")
        params = payload.get("parameters", {})

        if intent != "inject_wrapper":
            self.enter_cooldown(f"Unsupported intent: {intent}")
            return

        # Check for wrapper_spec or wrapper_py
        if not any(key in params for key in ["wrapper_spec", "wrapper_py", "wrapper_ref"]):
            self.enter_cooldown("Missing 'wrapper_spec', 'wrapper_py', or 'wrapper_ref'")
            return

        topic = f"zone/{self.zone}/agent_injection"
        self.message_bus.publish(topic, params)
        print(f"[{self.agent_id}] Published agent injection request to {topic}")

    def report_completion(self, chunk):
        super().report_completion(chunk)

    def health_check(self):
        return True

    def enter_cooldown(self, reason=""):
        self.status = 'cooldown'
        print(f"[{self.agent_id}] Cooldown: {reason}")

    def is_available(self):
        return self._available and self.status == 'idle'
