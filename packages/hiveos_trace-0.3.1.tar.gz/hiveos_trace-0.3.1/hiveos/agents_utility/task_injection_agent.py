import uuid
import yaml
from hiveos.agent_interface import AgentInterface

class TaskInjectionAgent(AgentInterface):
    def __init__(self, agent_id=None, capability="task_injector"):
        self.agent_id = agent_id or f"injector-{str(uuid.uuid4())[:8]}"
        self.name = f"TaskInjector-{str(uuid.uuid4())[:4]}"
        self.zone = None
        self.status = "idle"
        self.capabilities = [capability]
        self._available = True
        self.current_chunk = None
        self.chunk_obj = None
        self.chunk_progress = 0
        self.required_ticks = 0

    def get_status(self):
        return self.status

    def report_capabilities(self):
        return self.capabilities

    def execute_chunk(self, chunk, payload=None):
        super().execute_chunk(chunk, payload)

        if not isinstance(payload, dict):
            self.enter_cooldown("Invalid payload format")
            return
        
        intent = payload.get("intent")
        params = payload.get("parameters", {})

        if intent != "inject":
            self.enter_cooldown(f"Unsupported intent: {intent}")
            return

        task_reference = params.get("task_name")
        if not task_reference:
            self.enter_cooldown("Missing 'task_name' in parameters")
            return

        topic = f"zone/{self.zone}/task_injection"
        print(f"[{self.agent_id}] Injecting task with reference: {task_reference} ({type(task_reference)})")
        self.message_bus.publish(topic, task_reference)
        print(f"[{self.agent_id}] Published task injection request to {topic}")


    def report_completion(self, chunk):
        super().report_completion(chunk)

    def health_check(self):
        return True  # Stateless agent

    def enter_cooldown(self, reason=""):
        self.status = 'cooldown'
        print(f"[{self.agent_id}] Cooldown: {reason}")

    def is_available(self):
        return self._available and self.status == 'idle'
