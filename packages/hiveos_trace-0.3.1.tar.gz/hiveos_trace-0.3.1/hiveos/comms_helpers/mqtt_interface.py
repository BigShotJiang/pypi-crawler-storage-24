import paho.mqtt.client as mqtt

class MQTTInterface:
    def __init__(self, broker="localhost", port=1883, topic="hiveos/agent"):
        self.topic = topic
        self.client = mqtt.Client()
        self.client.connect(broker, port, keepalive=60)

    def send_payload(self, payload: str):
        self.client.publish(self.topic, payload)

    def is_connected(self):
        return self.client.is_connected()

    def close(self):
        self.client.disconnect()
