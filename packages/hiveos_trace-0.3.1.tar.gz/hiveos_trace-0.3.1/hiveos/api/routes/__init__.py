from hiveos.api.routes.agents import agents_bp
from hiveos.api.routes.control import control_bp
from hiveos.api.routes.intent import intent_bp
from hiveos.api.routes.proposals import proposals_bp
from hiveos.api.routes.runtime import runtime_bp
from hiveos.api.routes.sessions import sessions_bp
from hiveos.api.routes.tasks import tasks_bp
from hiveos.api.routes.terminal import terminal_bp
from hiveos.api.routes.traces import traces_bp


def register_blueprints(app):
    app.register_blueprint(runtime_bp)
    app.register_blueprint(agents_bp)
    app.register_blueprint(tasks_bp)
    app.register_blueprint(proposals_bp)
    app.register_blueprint(traces_bp)
    app.register_blueprint(control_bp)
    app.register_blueprint(sessions_bp)
    app.register_blueprint(terminal_bp)
    app.register_blueprint(intent_bp)
