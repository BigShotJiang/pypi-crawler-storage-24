# hiveos/utils.py

import time
from functools import wraps

# Simple timing decorator (for later use in profiling)
def timeit(label=""):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            start = time.perf_counter()
            result = func(*args, **kwargs)
            end = time.perf_counter()
            elapsed = (end - start) * 1000
            print(f"⏱ {label or func.__name__} took {elapsed:.2f} ms.")
            return result
        return wrapper
    return decorator

# Capability match helper
def has_capability(agent_caps, required):
    try:
        return required in eval(agent_caps)
    except Exception:
        return False

# Scoring placeholder
def basic_score(agent, chunk):
    # Score by battery for now, more later
    return agent['battery']

# Future: Retry threshold logic
def max_retries(chunk_id):
    # Could later pull from chunk metadata
    return 3
