def get_positive_int(prompt):
    try:
        value = int(input(prompt).strip())
        if value < 1:
            print("⚠️ Please enter a positive number.")
            return None
        return value
    except ValueError:
        print("⚠️ Invalid input. Please enter a number.")
        return None

def get_non_empty_string(prompt):
    value = input(prompt).strip()
    if not value:
        print("⚠️ Input cannot be empty.")
        return None
    return value

def get_capability(prompt, default="generic"):
    value = input(prompt).strip()
    return value if value else default
