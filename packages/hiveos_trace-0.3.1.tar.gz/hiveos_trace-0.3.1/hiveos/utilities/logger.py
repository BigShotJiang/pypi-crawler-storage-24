from hiveos.db import get_db
from datetime import datetime

def log_event(agent_id, chunk_id, event, zone):
    with get_db() as conn:
        conn.execute("""
            INSERT INTO task_logs (timestamp, agent_id, chunk_id, event, zone)
            VALUES (?, ?, ?, ?, ?)
        """, (datetime.utcnow().isoformat(), agent_id, chunk_id, event, zone))
