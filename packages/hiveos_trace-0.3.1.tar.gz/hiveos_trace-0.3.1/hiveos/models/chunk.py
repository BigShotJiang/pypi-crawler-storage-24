# hiveos/chunk.py
from hiveos.db import get_db

class Chunk:
    @staticmethod
    def create(chunk_id, task_id, required_capability='generic', zone_id=None, payload=None, depends_on=None, ttl=1, timing="ticks", conditional=None, session_id=None):
        with get_db() as conn:
            conn.execute(
                "INSERT INTO task_chunks (chunk_id, task_id, status, assigned_agent, required_capability, zone_id, retry_count, payload, depends_on, ttl, timing, conditional, session_id) "
                "VALUES (?, ?, 'pending', NULL, ?, ?, 0, ?, ?, ?, ?, ?, ?)",
                (chunk_id, task_id, required_capability, zone_id, payload, depends_on, ttl, timing, conditional, session_id)
            )

    @staticmethod
    def get_by_id(chunk_id):
        with get_db() as conn:
            row = conn.execute(
                "SELECT * FROM task_chunks WHERE chunk_id = ?",
                (chunk_id,)
            ).fetchone()
            if row:
                return row
            return None
