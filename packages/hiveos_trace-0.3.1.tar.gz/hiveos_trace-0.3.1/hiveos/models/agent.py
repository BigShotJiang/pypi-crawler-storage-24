# hiveos/agent.py
from hiveos.db import get_db

class Agent:
    @staticmethod
    def create(agent_id, capabilities, zone=None, session_id=None):
        with get_db() as conn:
            conn.execute("""
                INSERT OR REPLACE INTO agents (agent_id, status, battery, zone, capabilities, zone_residency_until, session_id)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                agent_id,
                "idle",
                100,  # default battery
                zone,
                str(capabilities),
                None,
                session_id
            ))

    @staticmethod
    def get_static_by_id(agent_id):
        with get_db() as conn:
            return conn.execute(
                "SELECT * FROM agents WHERE agent_id = ?",
                (agent_id,)
            ).fetchone()
