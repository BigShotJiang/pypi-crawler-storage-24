# hiveos/task.py
from hiveos.db import get_db

class Task:
    def __init__(self, task_id, name, execution_mode="sequential", has_conditionals=False, session_id=None):
        self.task_id = task_id
        self.name = name
        self.execution_mode = execution_mode
        self.has_conditionals = has_conditionals
        self.session_id = session_id

    @staticmethod
    def create(name, execution_mode, has_conditionals=False, session_id=None):
        with get_db() as conn:
            cursor = conn.execute(
                "INSERT INTO tasks (name, status, execution_mode, has_conditionals, session_id) VALUES (?, 'pending', ?, ?, ?)",
                (name, execution_mode, int(has_conditionals), session_id)
            )
            task_id = cursor.lastrowid
            print(f"[Task] Created task with ID: {task_id} | Mode: {execution_mode} | Has conditionals: {has_conditionals}")
            return task_id

    @staticmethod
    def get_by_id(task_id):
        with get_db() as conn:
            row = conn.execute(
                "SELECT task_id, name, execution_mode, IFNULL(has_conditionals, 0), session_id FROM tasks WHERE task_id = ?", 
                (task_id,)
            ).fetchone()
            if row:
                return Task(*row)
            return None