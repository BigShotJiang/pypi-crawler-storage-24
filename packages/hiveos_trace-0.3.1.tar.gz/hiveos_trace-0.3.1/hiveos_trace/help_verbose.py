"""Verbose help rendering for Hive trace CLI.

Phase-2 extraction slice: moved from `hiveos.observe` to reduce monolith size
without behavior changes.
"""


def _command_path_from_argv(raw_argv):
    tokens = [str(item) for item in (raw_argv or []) if str(item or "").strip()]
    non_flags = [token for token in tokens if not token.startswith("-")]
    if not non_flags:
        return tuple()
    first = non_flags[0]
    if first == "trace":
        if len(non_flags) >= 2:
            second = non_flags[1]
            if second == "flow" and len(non_flags) >= 3:
                return ("trace", "flow", non_flags[2])
            if second == "insight" and len(non_flags) >= 3:
                return ("trace", "insight", non_flags[2])
            if second == "ops" and len(non_flags) >= 3:
                return ("trace", "ops", non_flags[2])
            return ("trace", second)
        return ("trace",)
    return (first,)


def print_verbose_help(raw_argv):
    path = _command_path_from_argv(raw_argv)
    text_map = {
        tuple(): """Hive CLI (verbose)
Purpose:
  Local-first trace harness for wrapping commands, inspecting execution, and replaying behavior.
Core flow:
  1) hive trace run -- <command>
  2) hive trace ls
  3) hive trace summary <run_id>
  4) hive trace diagnose <run_id>
  5) hive trace replay <run_id> [--from-step-id | --from-checkpoint-id]
Tip:
  Use '--help' on any subcommand for complete flag details.
""",
        ("trace",): """hive trace (verbose)
Purpose:
  Command group for primitives, insight macros, and ops lifecycle controls.
Categories:
  primitives: run/ls/show/tail/summary/diff/diagnose/replay/flow/artifacts
  insight:    insight explain|drift|health
  ops:        ops archive|unarchive|prune|reconcile|export|import
Common commands:
  hive trace run -- <command>
  hive trace ls --limit 20
  hive trace show <run_id>
  hive trace replay-plan <run_id> --from-step-id <id>
  hive trace ops reconcile --stale-after 10m
""",
        ("trace", "run"): """hive trace run (verbose)
Purpose:
  Execute a command with trace capture while preserving original exit behavior.
Examples:
  hive trace run -- python agent.py
  hive trace run --name smoke --timeout-sec 60 --open -- python -m unittest -q
Notes:
  - '--' separates hive flags from wrapped command argv.
  - '--proxy' enables OpenAI-compatible proxy capture.
""",
        ("trace", "replay"): """hive trace replay (verbose)
Purpose:
  Re-run a prior captured command with optional anchor constraints.
Examples:
  hive trace replay observe-run:abc123
  hive trace replay observe-run:abc123 --from-step-id step_7
  hive trace replay observe-run:abc123 --from-checkpoint-id ckpt_2 --no-open
Notes:
  - '--from-step-id' and '--from-checkpoint-id' are mutually exclusive.
  - Replay lineage fields are persisted on the new run.
""",
        ("trace", "replay-plan"): """hive trace replay-plan (verbose)
Purpose:
  Preview replay intent and anchor validation without executing by default.
Examples:
  hive trace replay-plan observe-run:abc123
  hive trace replay-plan observe-run:abc123 --from-step-id step_7
  hive trace replay-plan observe-run:abc123 --recommended --json
  hive trace replay-plan observe-run:abc123 --recommended --explain
  hive trace replay-plan observe-run:abc123 --from-step-id step_7 --emit-artifact --json
  hive trace replay-plan observe-run:abc123 --from-checkpoint-id ckpt_2 --apply
Notes:
  - '--apply' executes replay using the validated plan.
  - '--apply' and '--json' are mutually exclusive.
  - '--recommended' auto-selects highest-ranked admissible anchor when explicit anchor flags are omitted.
  - '--explain' prints selected/rejected candidate rationale in text mode.
  - '--emit-artifact' writes replay-plan payload to JSON for downstream tooling.
  - Use anchors command first when IDs are unknown: hive trace anchors <run_id>
""",
        ("trace", "anchors"): """hive trace anchors (verbose)
Purpose:
  Discover available step/checkpoint anchor IDs for a run.
Examples:
  hive trace anchors observe-run:abc123
  hive trace anchors observe-run:abc123 --json
""",
        ("trace", "artifacts"): """hive trace artifacts (verbose)
Purpose:
  Inspect persisted trace artifacts (starting with replay-plan manifests).
Examples:
  hive trace artifacts ls --type replay_plan --json
  hive trace artifacts show replay-plan:abc123
  hive trace artifacts show .\\path\\to\\artifact.json --json
  hive trace artifacts replay replay-plan:abc123 --no-open
""",
        ("trace", "diff"): """hive trace diff (verbose)
Purpose:
  Compare two runs and surface divergence in config, event stream, and output tails.
Examples:
  hive trace diff observe-run:a observe-run:b
  hive trace diff observe-run:a observe-run:b --json
""",
        ("trace", "diagnose"): """hive trace diagnose (verbose)
Purpose:
  Classify run outcomes and print actionable next-step recommendations.
Examples:
  hive trace diagnose observe-run:abc123
  hive trace diagnose observe-run:abc123 --json
""",
        ("trace", "flow"): """hive trace flow (verbose)
Purpose:
  Inspect flow-level lineage assembled from step identifiers.
Examples:
  hive trace flow ls
  hive trace flow show <flow_id>
  hive trace flow diff <flow_a> <flow_b>
""",
        ("trace", "insight"): """hive trace insight (verbose)
Purpose:
  Macro layer that composes primitives into concise answers with provenance.
Examples:
  hive trace insight explain <run_id>
  hive trace insight drift <run_a> <run_b>
  hive trace insight health --window 24h
Notes:
  - Insight macros do not replace primitives.
  - Use '--emit-primitive' to print equivalent primitive commands.
""",
        ("trace", "ops"): """hive trace ops (verbose)
Purpose:
  Lifecycle and admin controls for trace hygiene and portability.
Examples:
  hive trace ops archive <run_id>
  hive trace ops prune --older-than 30d
  hive trace ops reconcile --stale-after 5m
""",
    }
    message = text_map.get(path)
    if message is None and len(path) >= 2 and path[:2] == ("trace", "flow"):
        message = text_map[("trace", "flow")]
    if message is None and len(path) >= 2 and path[:2] == ("trace", "insight"):
        message = text_map[("trace", "insight")]
    if message is None and len(path) >= 2 and path[:2] == ("trace", "ops"):
        message = text_map[("trace", "ops")]
    if message is None:
        message = "Verbose help is not defined for this command path yet. Use '--help' for full option details."
    print(message.rstrip())
    return 0

