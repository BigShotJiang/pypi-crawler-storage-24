import unittest

from hiveos.intelligence.model_routing import build_model_routing_recommendation


class ModelRoutingTests(unittest.TestCase):
    def test_recommendation_prefers_better_quality_and_latency(self):
        events = [
            {
                "event_type": "terminal_output",
                "outcome": "success",
                "payload": {"derived": True, "module": "localize", "quality_status": "ok"},
                "timing": {"latency_ms": 120},
                "model": {"provider": "ollama", "name": "fast-good"},
            },
            {
                "event_type": "terminal_output",
                "outcome": "success",
                "payload": {"derived": True, "module": "localize", "quality_status": "ok"},
                "timing": {"latency_ms": 130},
                "model": {"provider": "ollama", "name": "fast-good"},
            },
            {
                "event_type": "terminal_output",
                "outcome": "failed",
                "payload": {"derived": True, "module": "localize", "quality_status": "fallback_noop"},
                "timing": {"latency_ms": 220},
                "model": {"provider": "ollama", "name": "slow-bad"},
            },
            {
                "event_type": "terminal_output",
                "outcome": "success",
                "payload": {"derived": True, "module": "localize", "quality_status": "fallback_noop"},
                "timing": {"latency_ms": 240},
                "model": {"provider": "ollama", "name": "slow-bad"},
            },
        ]
        artifact = build_model_routing_recommendation(
            events=events,
            route_classes=["localize"],
            min_samples=2,
        )
        self.assertEqual(["localize"], artifact.get("routes_evaluated"))
        recommendation = (artifact.get("recommendations") or [])[0]
        self.assertEqual("localize", recommendation.get("route_class"))
        winner = recommendation.get("winner") or {}
        self.assertEqual("ollama", winner.get("provider"))
        self.assertEqual("fast-good", winner.get("name"))
        self.assertEqual(2, len(recommendation.get("candidates") or []))


if __name__ == "__main__":
    unittest.main()
