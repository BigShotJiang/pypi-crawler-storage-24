import unittest

from hiveos.security.authorization import authorize_action


class AuthorizationPolicyTests(unittest.TestCase):
    def test_unregistered_action_denied(self):
        decision = authorize_action("unknown.action", ["runtime.write"], enforce=True)
        self.assertFalse(decision.allowed)
        self.assertEqual("policy_action_unregistered", decision.reason)

    def test_enforcement_disabled_allows_without_caps(self):
        decision = authorize_action("runtime.inject_yaml", [], enforce=False)
        self.assertTrue(decision.allowed)
        self.assertEqual("capability_enforcement_disabled", decision.reason)

    def test_enforcement_enabled_denies_without_caps(self):
        decision = authorize_action("runtime.inject_yaml", [], enforce=True)
        self.assertFalse(decision.allowed)
        self.assertEqual("capability_denied", decision.reason)

    def test_exact_capability_match(self):
        decision = authorize_action("runtime.inject_yaml", ["runtime.write"], enforce=True)
        self.assertTrue(decision.allowed)

    def test_wildcard_capability_match(self):
        decision = authorize_action("control.pause_core", ["runtime.*"], enforce=True)
        self.assertTrue(decision.allowed)

    def test_admin_capability_match(self):
        decision = authorize_action("proposals.inject", ["admin"], enforce=True)
        self.assertTrue(decision.allowed)

    def test_terminal_exec_capability_match(self):
        decision = authorize_action("terminal.exec", ["terminal.exec"], enforce=True)
        self.assertTrue(decision.allowed)

    def test_intent_preview_capability_match(self):
        decision = authorize_action("intent.preview", ["intelligence.write"], enforce=True)
        self.assertTrue(decision.allowed)

    def test_proposal_archive_capability_match(self):
        decision = authorize_action("proposals.archive", ["intelligence.write"], enforce=True)
        self.assertTrue(decision.allowed)


if __name__ == "__main__":
    unittest.main()
