# hyperliquid-cli

Agent-first CLI for Hyperliquid perpetual futures trading. Thin Python wrapper over [hyperliquid-python-sdk](https://github.com/hyperliquid-x/hyperliquid-python-sdk).

## Install

```bash
uv tool install hyperliquid-cli
```

## Usage

```bash
# Read commands (no auth needed)
hl prices BTC ETH
hl book BTC --depth 10
hl assets TSLA
hl funding BTC --history
hl candles BTC 1h --limit 50

# Account commands (needs HL_PRIVATE_KEY or --address)
hl status
hl balance
hl positions
hl orders
hl fills

# Write commands (needs HL_PRIVATE_KEY)
hl order BTC buy 0.1 --market
hl order BTC buy 0.1 95000 --tp 100000 --sl 90000
hl cancel 77738308
hl cancel-all BTC
hl leverage BTC 10
```

## Auth

Set `HL_PRIVATE_KEY` env var with your Hyperliquid API wallet key (can trade but cannot withdraw).

Read-only commands work without auth using `--address`.

## Design

- JSON-only output (stdout), debug/warnings to stderr
- Rich exit codes (0=success, 1=input, 2=auth, 3=API, 4=asset, 5=rejected)
- Structured errors with recovery hints
- Field projection via `--fields`
- HIP-3 asset auto-resolution (e.g. `TSLA` → `xyz:TSLA`)
- Trade logging to `data/trades.jsonl`

## License

MIT
