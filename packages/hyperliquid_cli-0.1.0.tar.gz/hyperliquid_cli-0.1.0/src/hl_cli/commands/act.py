"""Act commands — order, cancel, cancel-all, leverage."""

import json
import sys
import time
from pathlib import Path
from typing import Annotated, Optional

import typer

from hl_cli.client import get_address, get_exchange
from hl_cli.main import app
from hl_cli.output import die, format_timestamp, output
from hl_cli.resolver import get_resolver

SIDE_MAP = {"buy": True, "long": True, "sell": False, "short": False}


def _parse_order_response(resp, asset: str, side_str: str, size: str):
    """Parse SDK order response into CLI output format."""
    if resp.get("status") == "err":
        die("order_rejected", resp.get("response", str(resp)), exit_code=5)

    data = resp.get("response", {}).get("data", {})
    statuses = data.get("statuses", [])
    if not statuses:
        die("order_rejected", "No status in response", exit_code=5)

    st = statuses[0]
    if "error" in st:
        die("order_rejected", st["error"], exit_code=5)

    if "filled" in st:
        filled = st["filled"]
        return {
            "status": "filled",
            "oid": filled.get("oid", 0),
            "asset": asset,
            "side": side_str,
            "size": filled.get("totalSz", size),
            "avg_price": filled.get("avgPx", ""),
        }
    elif "resting" in st:
        resting = st["resting"]
        return {
            "status": "resting",
            "oid": resting.get("oid", 0),
            "asset": asset,
            "side": side_str,
            "size": size,
        }
    else:
        return {"status": "unknown", "raw": st}


def _log_trade(result: dict, order_type: str, price: str = ""):
    """Append trade record to data/trades.jsonl."""
    trades_dir = Path("data")
    trades_dir.mkdir(exist_ok=True)
    record = {
        "timestamp": format_timestamp(int(time.time() * 1000)),
        "asset": result.get("asset", ""),
        "side": result.get("side", ""),
        "size": result.get("size", ""),
        "price": result.get("avg_price", price),
        "type": order_type,
        "oid": result.get("oid", 0),
        "status": result.get("status", ""),
    }
    with open(trades_dir / "trades.jsonl", "a") as f:
        f.write(json.dumps(record, separators=(",", ":")) + "\n")


@app.command()
def order(
    ctx: typer.Context,
    asset: Annotated[str, typer.Argument(help="Asset name")],
    side: Annotated[str, typer.Argument(help="buy/long or sell/short")],
    size: Annotated[str, typer.Argument(help="Amount in base asset")],
    price: Annotated[Optional[str], typer.Argument(help="Limit price")] = None,
    market: Annotated[bool, typer.Option("--market", help="Market order (IOC)")] = False,
    tif: Annotated[Optional[str], typer.Option("--tif", help="gtc|ioc|alo")] = None,
    reduce_only: Annotated[bool, typer.Option("--reduce-only", help="Reduce only")] = False,
    tp: Annotated[Optional[str], typer.Option("--tp", help="Take profit trigger price")] = None,
    sl: Annotated[Optional[str], typer.Option("--sl", help="Stop loss trigger price")] = None,
    cloid: Annotated[Optional[str], typer.Option("--cloid", help="Client order ID (hex)")] = None,
):
    """Place an order."""
    opts = ctx.obj

    side_lower = side.lower()
    if side_lower not in SIDE_MAP:
        die("input_error", f"Invalid side: {side}", hint="Use buy/long or sell/short")

    is_buy = SIDE_MAP[side_lower]
    sz = float(size)

    exchange = get_exchange(opts["testnet"])
    resolver = get_resolver(exchange.info)
    resolved = resolver.resolve(asset)

    from hyperliquid.utils.types import Cloid as SdkCloid
    sdk_cloid = SdkCloid.from_str(cloid) if cloid else None

    if market or price is None:
        # Market order
        resp = exchange.market_open(resolved, is_buy, sz, cloid=sdk_cloid)
        result = _parse_order_response(resp, resolved, side_lower, size)
        _log_trade(result, "market")
        output(result, opts["fields"])
        return

    # Limit order
    px = float(price)
    tif_val = (tif or "gtc").capitalize()
    if tif_val == "Gtc":
        tif_val = "Gtc"
    elif tif_val == "Ioc":
        tif_val = "Ioc"
    elif tif_val == "Alo":
        tif_val = "Alo"
    order_type = {"limit": {"tif": tif_val}}

    if tp or sl:
        # Parent + TP/SL as grouped order
        order_requests = [
            {
                "coin": resolved,
                "is_buy": is_buy,
                "sz": sz,
                "limit_px": px,
                "order_type": order_type,
                "reduce_only": reduce_only,
                "cloid": sdk_cloid,
            }
        ]
        if tp:
            tp_type = {"trigger": {"triggerPx": float(tp), "isMarket": True, "tpsl": "tp"}}
            order_requests.append({
                "coin": resolved,
                "is_buy": not is_buy,
                "sz": sz,
                "limit_px": float(tp),
                "order_type": tp_type,
                "reduce_only": True,
            })
        if sl:
            sl_type = {"trigger": {"triggerPx": float(sl), "isMarket": True, "tpsl": "sl"}}
            order_requests.append({
                "coin": resolved,
                "is_buy": not is_buy,
                "sz": sz,
                "limit_px": float(sl),
                "order_type": sl_type,
                "reduce_only": True,
            })

        resp = exchange.bulk_orders(
            [exchange._order_request_to_wire(r) for r in order_requests]
            if hasattr(exchange, "_order_request_to_wire")
            else order_requests,
            grouping="normalTpsl",
        )
        result = _parse_order_response(resp, resolved, side_lower, size)
        _log_trade(result, "limit", price)
        output(result, opts["fields"])
    else:
        resp = exchange.order(resolved, is_buy, sz, px, order_type, reduce_only, cloid=sdk_cloid)
        result = _parse_order_response(resp, resolved, side_lower, size)
        _log_trade(result, "limit", price)
        output(result, opts["fields"])


@app.command()
def cancel(
    ctx: typer.Context,
    first: Annotated[str, typer.Argument(help="OID or asset name")],
    second: Annotated[Optional[str], typer.Argument(help="OID (if first is asset)")] = None,
    cloid: Annotated[Optional[str], typer.Option("--cloid", help="Cancel by client order ID")] = None,
    asset_opt: Annotated[Optional[str], typer.Option("--asset", help="Asset for cloid cancel")] = None,
):
    """Cancel a specific order."""
    opts = ctx.obj
    exchange = get_exchange(opts["testnet"])

    if cloid:
        # Cancel by client order ID
        if not asset_opt:
            die("input_error", "Must specify --asset with --cloid", hint="hl cancel --cloid 0x... --asset BTC")
        resolver = get_resolver(exchange.info)
        resolved = resolver.resolve(asset_opt)
        from hyperliquid.utils.types import Cloid as SdkCloid
        resp = exchange.cancel_by_cloid(resolved, SdkCloid.from_str(cloid))
        output({"status": "cancelled", "asset": resolved, "cloid": cloid}, opts["fields"])
        return

    if second is not None:
        # hl cancel BTC 77738308
        resolver = get_resolver(exchange.info)
        resolved = resolver.resolve(first)
        oid = int(second)
        exchange.cancel(resolved, oid)
        output({"status": "cancelled", "oid": oid, "asset": resolved}, opts["fields"])
    else:
        # hl cancel 77738308 — auto-lookup asset from open orders
        oid = int(first)
        addr = get_address()
        open_orders = exchange.info.open_orders(addr)
        coin = None
        for o in open_orders:
            if o["oid"] == oid:
                coin = o["coin"]
                break
        if not coin:
            die("input_error", f"Order {oid} not found in open orders", hint="Pass asset explicitly: hl cancel BTC {oid}")
        exchange.cancel(coin, oid)
        output({"status": "cancelled", "oid": oid, "asset": coin}, opts["fields"])


@app.command(name="cancel-all")
def cancel_all(
    ctx: typer.Context,
    asset: Annotated[Optional[str], typer.Argument(help="Cancel only this asset's orders")] = None,
):
    """Cancel all open orders."""
    opts = ctx.obj
    exchange = get_exchange(opts["testnet"])
    addr = get_address()

    open_orders = exchange.info.open_orders(addr)

    if asset:
        resolver = get_resolver(exchange.info)
        resolved = resolver.resolve(asset)
        open_orders = [o for o in open_orders if o["coin"] == resolved]

    if not open_orders:
        output({"cancelled": 0, "assets": []}, opts["fields"])
        return

    cancel_requests = [{"coin": o["coin"], "oid": o["oid"]} for o in open_orders]
    exchange.bulk_cancel(cancel_requests)

    assets_cancelled = sorted(set(o["coin"] for o in open_orders))
    output({"cancelled": len(open_orders), "assets": assets_cancelled}, opts["fields"])


@app.command()
def leverage(
    ctx: typer.Context,
    asset: Annotated[str, typer.Argument(help="Asset name")],
    lev: Annotated[int, typer.Argument(help="Leverage (integer)")],
    cross: Annotated[bool, typer.Option("--cross", help="Cross margin")] = False,
    isolated: Annotated[bool, typer.Option("--isolated", help="Isolated margin")] = False,
):
    """Set leverage for an asset."""
    opts = ctx.obj

    if cross and isolated:
        die("input_error", "Cannot specify both --cross and --isolated")

    exchange = get_exchange(opts["testnet"])
    resolver = get_resolver(exchange.info)
    resolved = resolver.resolve(asset)

    is_cross = not isolated  # default is cross
    if is_cross and ":" in resolved:
        print("Warning: HIP-3 assets support isolated margin only. Using isolated.", file=sys.stderr)
        is_cross = False

    exchange.update_leverage(lev, resolved, is_cross)

    output({
        "asset": resolved,
        "leverage": lev,
        "margin_mode": "cross" if is_cross else "isolated",
    }, opts["fields"])
