"""SDK client factory — creates Info and Exchange instances."""

import os

import eth_account
from hyperliquid.exchange import Exchange
from hyperliquid.info import Info
from hyperliquid.utils.constants import MAINNET_API_URL

from hl_cli.output import die

TESTNET_API_URL = "https://api.hyperliquid-testnet.xyz"


def _base_url(testnet: bool) -> str:
    return TESTNET_API_URL if testnet else MAINNET_API_URL


def _get_key():
    key = os.environ.get("HL_PRIVATE_KEY")
    if not key:
        die(
            "auth_error",
            "HL_PRIVATE_KEY environment variable not set",
            hint="Set HL_PRIVATE_KEY to your API wallet private key",
            exit_code=2,
        )
    return key


def get_address(explicit: str = None) -> str:
    """Get wallet address from explicit arg or HL_PRIVATE_KEY."""
    if explicit:
        return explicit
    key = os.environ.get("HL_PRIVATE_KEY")
    if key:
        return eth_account.Account.from_key(key).address
    die(
        "auth_error",
        "No address available",
        hint="Set HL_PRIVATE_KEY or use --address",
        exit_code=2,
    )


def get_info(testnet: bool = False) -> Info:
    """Create Info client (default perps only, dexes loaded lazily by resolver)."""
    return Info(_base_url(testnet), skip_ws=True)


def get_exchange(testnet: bool = False) -> Exchange:
    """Create Exchange client (requires HL_PRIVATE_KEY)."""
    key = _get_key()
    account = eth_account.Account.from_key(key)
    return Exchange(account, _base_url(testnet), account_address=account.address)


def get_all_mids(info: Info) -> dict:
    """Get all mid prices including HIP-3 deployer assets."""
    mids = info.all_mids()
    try:
        dex_list = info.post("/info", {"type": "perpDexs"})
        for dex_info in dex_list[1:]:
            dex_mids = info.post("/info", {"type": "allMids", "dex": dex_info["name"]})
            mids.update(dex_mids)
    except Exception:
        pass
    return mids
