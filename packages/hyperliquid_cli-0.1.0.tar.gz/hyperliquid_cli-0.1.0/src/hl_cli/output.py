"""Output formatting, errors, and time utilities."""

import json
import sys
from datetime import datetime, timezone


def output(data, fields=None):
    """Write data to stdout as compact JSON."""
    if fields:
        data = _project(data, fields)
    sys.stdout.write(json.dumps(data, separators=(",", ":")) + "\n")


def die(error_code: str, message: str, hint: str = None, exit_code: int = 1):
    """Write structured error to stdout and exit."""
    err = {"error": error_code, "message": message}
    if hint:
        err["hint"] = hint
    sys.stdout.write(json.dumps(err, separators=(",", ":")) + "\n")
    raise SystemExit(exit_code)


def debug(message: str, verbose: bool = False):
    """Write debug info to stderr."""
    if verbose:
        sys.stderr.write(f"[debug] {message}\n")


def _project(data, fields_str: str):
    """Filter data to only include specified fields."""
    fields = {f.strip() for f in fields_str.split(",")}
    if isinstance(data, list):
        return [
            {k: v for k, v in item.items() if k in fields}
            for item in data
            if isinstance(item, dict)
        ]
    elif isinstance(data, dict):
        return {k: v for k, v in data.items() if k in fields}
    return data


def parse_time(s: str) -> int:
    """Parse time string to unix milliseconds."""
    dt = datetime.fromisoformat(s)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return int(dt.timestamp() * 1000)


def format_timestamp(ms) -> str:
    """Format unix milliseconds to ISO 8601."""
    if isinstance(ms, (int, float)) and ms > 0:
        dt = datetime.fromtimestamp(ms / 1000, tz=timezone.utc)
        return dt.strftime("%Y-%m-%dT%H:%M:%SZ")
    return str(ms)


INTERVAL_MS = {
    "1m": 60_000,
    "3m": 180_000,
    "5m": 300_000,
    "15m": 900_000,
    "30m": 1_800_000,
    "1h": 3_600_000,
    "2h": 7_200_000,
    "4h": 14_400_000,
    "8h": 28_800_000,
    "12h": 43_200_000,
    "1d": 86_400_000,
    "3d": 259_200_000,
    "1w": 604_800_000,
    "1M": 2_592_000_000,
}


def interval_to_ms(interval: str) -> int:
    """Convert candle interval string to milliseconds."""
    ms = INTERVAL_MS.get(interval)
    if ms is None:
        valid = ", ".join(INTERVAL_MS.keys())
        die("input_error", f"Invalid interval: {interval}", hint=f"Valid intervals: {valid}")
    return ms
