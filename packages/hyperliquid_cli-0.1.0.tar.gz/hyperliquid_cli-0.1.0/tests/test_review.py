"""Tests for review commands — fills, trades."""

import json
import os

import pytest

from hl_cli.main import app


def parse(result):
    return json.loads(result.output)


class TestFills:
    def test_basic(self, runner, patched, snapshot):
        result = runner.invoke(app, ["fills"])
        assert result.exit_code == 0
        assert parse(result) == snapshot

    def test_filter_asset(self, runner, patched):
        result = runner.invoke(app, ["fills", "BTC"])
        assert result.exit_code == 0
        data = parse(result)
        assert len(data) == 1
        assert data[0]["asset"] == "BTC"

    def test_limit(self, runner, patched):
        result = runner.invoke(app, ["fills", "--limit", "1"])
        assert result.exit_code == 0
        data = parse(result)
        assert len(data) == 1


class TestTrades:
    @pytest.fixture(autouse=True)
    def _use_tmp_dir(self, tmp_path):
        original = os.getcwd()
        os.chdir(tmp_path)
        yield
        os.chdir(original)

    def test_empty(self, runner, patched):
        result = runner.invoke(app, ["trades"])
        assert result.exit_code == 0
        assert parse(result) == []

    def test_with_data(self, runner, patched, tmp_path, snapshot):
        trades_dir = tmp_path / "data"
        trades_dir.mkdir()
        (trades_dir / "trades.jsonl").write_text(
            '{"timestamp":"2026-03-11T10:30:00Z","asset":"BTC","side":"buy","size":"0.1","price":"69666.0","type":"market","oid":200001,"status":"filled"}\n'
            '{"timestamp":"2026-03-11T10:31:00Z","asset":"ETH","side":"sell","size":"1.0","price":"3300.0","type":"limit","oid":200002,"status":"resting"}\n'
        )
        result = runner.invoke(app, ["trades"])
        assert result.exit_code == 0
        assert parse(result) == snapshot

    def test_filter_asset(self, runner, patched, tmp_path):
        trades_dir = tmp_path / "data"
        trades_dir.mkdir()
        (trades_dir / "trades.jsonl").write_text(
            '{"timestamp":"2026-03-11T10:30:00Z","asset":"BTC","side":"buy","size":"0.1","price":"69666.0","type":"market","oid":200001,"status":"filled"}\n'
            '{"timestamp":"2026-03-11T10:31:00Z","asset":"ETH","side":"sell","size":"1.0","price":"3300.0","type":"limit","oid":200002,"status":"resting"}\n'
        )
        result = runner.invoke(app, ["trades", "--asset", "BTC"])
        assert result.exit_code == 0
        data = parse(result)
        assert len(data) == 1
        assert data[0]["asset"] == "BTC"
