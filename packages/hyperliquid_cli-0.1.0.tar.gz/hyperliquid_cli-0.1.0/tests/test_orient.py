"""Tests for orient commands — status, balance, positions, orders."""

import json

from hl_cli.main import app


def parse(result):
    return json.loads(result.output)


class TestStatus:
    def test_basic(self, runner, patched, snapshot):
        result = runner.invoke(app, ["status"])
        assert result.exit_code == 0
        assert parse(result) == snapshot

    def test_fields(self, runner, patched):
        result = runner.invoke(app, ["--fields", "account_value,withdrawable", "status"])
        assert result.exit_code == 0
        data = parse(result)
        assert set(data.keys()) == {"account_value", "withdrawable"}


class TestBalance:
    def test_basic(self, runner, patched, snapshot):
        result = runner.invoke(app, ["balance"])
        assert result.exit_code == 0
        assert parse(result) == snapshot


class TestPositions:
    def test_all(self, runner, patched, snapshot):
        result = runner.invoke(app, ["positions"])
        assert result.exit_code == 0
        assert parse(result) == snapshot

    def test_filter_asset(self, runner, patched):
        result = runner.invoke(app, ["positions", "BTC"])
        assert result.exit_code == 0
        data = parse(result)
        assert len(data) == 1
        assert data[0]["asset"] == "BTC"

    def test_empty(self, runner, patched):
        patched["info"].user_state.return_value = {
            "crossMarginSummary": {"accountValue": "100.00"},
            "withdrawable": "100.00",
            "assetPositions": [],
        }
        result = runner.invoke(app, ["positions"])
        assert result.exit_code == 0
        assert parse(result) == []


class TestOrders:
    def test_all(self, runner, patched, snapshot):
        result = runner.invoke(app, ["orders"])
        assert result.exit_code == 0
        assert parse(result) == snapshot

    def test_filter_asset(self, runner, patched):
        result = runner.invoke(app, ["orders", "BTC"])
        assert result.exit_code == 0
        data = parse(result)
        assert len(data) == 1
        assert data[0]["asset"] == "BTC"

    def test_trigger_order_tif_none(self, runner, patched):
        """Regression: trigger orders (TP/SL) return tif=None from API."""
        patched["info"].frontend_open_orders.return_value = [
            {
                "coin": "BTC",
                "oid": 100003,
                "side": "A",
                "limitPx": "80000.0",
                "sz": "0.001",
                "orderType": "Take Profit Market",
                "tif": None,
                "reduceOnly": True,
                "timestamp": 1773000000000,
            }
        ]
        result = runner.invoke(app, ["orders"])
        assert result.exit_code == 0
        data = parse(result)
        assert data[0]["tif"] is None
        assert data[0]["type"] == "take profit market"
