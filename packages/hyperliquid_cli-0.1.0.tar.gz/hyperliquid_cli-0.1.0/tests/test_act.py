"""Tests for act commands — order, cancel, cancel-all, leverage."""

import json
import os

import pytest

from hl_cli.main import app


def parse(result):
    return json.loads(result.output)


@pytest.fixture(autouse=True)
def _use_tmp_dir(tmp_path):
    """Run act tests in a temp dir so trade log doesn't pollute the project."""
    original = os.getcwd()
    os.chdir(tmp_path)
    yield
    os.chdir(original)


class TestOrder:
    def test_market_buy(self, runner, patched, snapshot):
        result = runner.invoke(app, ["order", "BTC", "buy", "0.1", "--market"])
        assert result.exit_code == 0
        assert parse(result) == snapshot

    def test_limit_buy(self, runner, patched, snapshot):
        result = runner.invoke(app, ["order", "BTC", "buy", "0.1", "65000"])
        assert result.exit_code == 0
        assert parse(result) == snapshot

    def test_side_aliases(self, runner, patched):
        for side in ["buy", "long", "sell", "short"]:
            result = runner.invoke(app, ["order", "BTC", side, "0.1", "--market"])
            assert result.exit_code == 0, f"Failed for side={side}"

    def test_invalid_side(self, runner, patched):
        result = runner.invoke(app, ["order", "BTC", "yolo", "0.1", "65000"])
        assert result.exit_code == 1
        assert parse(result)["error"] == "input_error"

    def test_trade_log_written(self, runner, patched, tmp_path):
        runner.invoke(app, ["order", "BTC", "buy", "0.1", "--market"])
        trades_file = tmp_path / "data" / "trades.jsonl"
        assert trades_file.exists()
        record = json.loads(trades_file.read_text().strip())
        assert record["asset"] == "BTC"
        assert record["type"] == "market"

    def test_unknown_asset(self, runner, patched):
        result = runner.invoke(app, ["order", "FAKECOIN", "buy", "0.1", "--market"])
        assert result.exit_code == 4
        assert parse(result)["error"] == "unknown_asset"


class TestCancel:
    def test_by_oid_auto_lookup(self, runner, patched, snapshot):
        result = runner.invoke(app, ["cancel", "100001"])
        assert result.exit_code == 0
        assert parse(result) == snapshot

    def test_by_oid_with_asset(self, runner, patched, snapshot):
        result = runner.invoke(app, ["cancel", "BTC", "100001"])
        assert result.exit_code == 0
        assert parse(result) == snapshot

    def test_oid_not_found(self, runner, patched):
        result = runner.invoke(app, ["cancel", "999999"])
        assert result.exit_code == 1
        assert parse(result)["error"] == "input_error"


class TestCancelAll:
    def test_all(self, runner, patched, snapshot):
        result = runner.invoke(app, ["cancel-all"])
        assert result.exit_code == 0
        assert parse(result) == snapshot

    def test_filtered(self, runner, patched):
        result = runner.invoke(app, ["cancel-all", "BTC"])
        assert result.exit_code == 0
        data = parse(result)
        assert data["cancelled"] == 1
        assert data["assets"] == ["BTC"]

    def test_empty(self, runner, patched):
        patched["exchange"].info.open_orders.return_value = []
        result = runner.invoke(app, ["cancel-all"])
        assert result.exit_code == 0
        data = parse(result)
        assert data["cancelled"] == 0


class TestLeverage:
    def test_cross_default(self, runner, patched, snapshot):
        result = runner.invoke(app, ["leverage", "BTC", "10"])
        assert result.exit_code == 0
        assert parse(result) == snapshot

    def test_isolated(self, runner, patched, snapshot):
        result = runner.invoke(app, ["leverage", "BTC", "10", "--isolated"])
        assert result.exit_code == 0
        assert parse(result) == snapshot

    def test_both_flags_error(self, runner, patched):
        result = runner.invoke(app, ["leverage", "BTC", "10", "--cross", "--isolated"])
        assert result.exit_code == 1
        assert parse(result)["error"] == "input_error"
