"""Tests for research commands — assets, prices, book, funding, candles."""

import json

from hl_cli.main import app


def parse(result):
    return json.loads(result.output)


class TestAssets:
    def test_all(self, runner, patched, snapshot):
        result = runner.invoke(app, ["assets"])
        assert result.exit_code == 0
        assert parse(result) == snapshot

    def test_search(self, runner, patched):
        result = runner.invoke(app, ["assets", "BTC"])
        assert result.exit_code == 0
        data = parse(result)
        assert len(data) == 1
        assert data[0]["asset"] == "BTC"

    def test_sort_name(self, runner, patched):
        result = runner.invoke(app, ["assets", "--sort", "name"])
        assert result.exit_code == 0
        data = parse(result)
        names = [a["asset"] for a in data]
        assert names == sorted(names)


class TestPrices:
    def test_all_mids(self, runner, patched, snapshot):
        result = runner.invoke(app, ["prices"])
        assert result.exit_code == 0
        assert parse(result) == snapshot

    def test_specific(self, runner, patched, snapshot):
        result = runner.invoke(app, ["prices", "BTC"])
        assert result.exit_code == 0
        assert parse(result) == snapshot

    def test_multiple(self, runner, patched):
        result = runner.invoke(app, ["prices", "BTC", "ETH"])
        assert result.exit_code == 0
        data = parse(result)
        assert len(data) == 2
        assert {d["asset"] for d in data} == {"BTC", "ETH"}

    def test_unknown_asset(self, runner, patched):
        result = runner.invoke(app, ["prices", "FAKECOIN"])
        assert result.exit_code == 4
        data = parse(result)
        assert data["error"] == "unknown_asset"


class TestBook:
    def test_basic(self, runner, patched, snapshot):
        result = runner.invoke(app, ["book", "BTC"])
        assert result.exit_code == 0
        assert parse(result) == snapshot

    def test_depth(self, runner, patched):
        result = runner.invoke(app, ["book", "BTC", "--depth", "2"])
        assert result.exit_code == 0
        data = parse(result)
        assert len(data["bids"]) == 2
        assert len(data["asks"]) == 2


class TestFunding:
    def test_current_all(self, runner, patched, snapshot):
        result = runner.invoke(app, ["funding"])
        assert result.exit_code == 0
        assert parse(result) == snapshot

    def test_current_specific(self, runner, patched):
        result = runner.invoke(app, ["funding", "BTC"])
        assert result.exit_code == 0
        data = parse(result)
        assert len(data) == 1
        assert data[0]["asset"] == "BTC"

    def test_history(self, runner, patched, snapshot):
        result = runner.invoke(app, ["funding", "BTC", "--history", "--limit", "3"])
        assert result.exit_code == 0
        assert parse(result) == snapshot

    def test_history_requires_asset(self, runner, patched):
        result = runner.invoke(app, ["funding", "--history"])
        assert result.exit_code == 1
        data = parse(result)
        assert data["error"] == "input_error"


class TestCandles:
    def test_basic(self, runner, patched, snapshot):
        result = runner.invoke(app, ["candles", "BTC", "1h", "--limit", "2"])
        assert result.exit_code == 0
        assert parse(result) == snapshot

    def test_invalid_interval(self, runner, patched):
        result = runner.invoke(app, ["candles", "BTC", "2d"])
        assert result.exit_code == 1
        data = parse(result)
        assert data["error"] == "input_error"
