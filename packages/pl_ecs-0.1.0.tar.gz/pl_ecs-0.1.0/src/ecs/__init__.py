from .entity import Entity
from .component import Component, component_dataclass
from .system import System
from .world import World

__version__ = "0.0.1"
__author__ = "Peach"

__all__ = ["Entity", "Component", "System", "World", "component_dataclass"]


# Declare an instance to auto-register
singleton = Component()
