# world.py
from __future__ import annotations
from typing import Dict, Iterable, Set
import logging
from copy import deepcopy

from .entity import Entity
from .component import Component
from .system import System

logger = logging.getLogger(__name__)


class World:
    """
    Central registry that stores:
      • component tables (one dict per component type)
      • a set of active systems
    It also provides the query helpers used by systems.
    """

    def __init__(self) -> None:
        self._entities: Set[Entity] = set()
        self._components: Dict[str, Dict[Entity, Component]] = {}
        self._systems: list[System] = []

        # Monotomic world clock, elapsed time since creation
        self._time: float = 0.0

    @property
    def time(self):
        return self._time

    # ------------------------------------------------------------------
    # Entity management
    # ------------------------------------------------------------------
    def create_entity(self) -> Entity:
        # Create new instance of an entity
        entity = Entity()
        # Keep a reference
        self._entities.add(entity)

        return entity

    def delete_entity(self, entity: Entity) -> None:
        # Remove all components associated with the entity
        for comp_dict in self._components.values():
            comp_dict.pop(entity, None)

        # Remove the entity
        self._entities.discard(entity)

    # ------------------------------------------------------------------
    # Component management
    # ------------------------------------------------------------------
    def add_component(self, entity: Entity, component: Component) -> None:
        # Normalize component name
        ct = component.__class__.__name__.lower()

        # Get Components
        comps = self._components.setdefault(ct, {})

        # Check if overwriting
        if entity in comps:
            logger.warning(f"Overwriting {ct} for {entity}")

        # Add the component
        comps[entity] = component

    def get_component(self, entity: Entity, ct: str) -> Component | None:
        # Normalize component type
        ct = ct.lower()

        # Get component
        comp = self._components.get(ct, {}).get(entity)

        if comp is None:
            logger.debug(f"Component {ct} not found for {entity}")
            return None

        return deepcopy(comp)

    def remove_component(self, entity: Entity, ct: str) -> None:
        # Normalize component type name
        ct = ct.lower()

        table = self._components.get(ct, {})
        if table:
            # Remove component for entity
            table.pop(entity, None)
            # Check if table is empty
            if not table:
                # Clean up empty table
                del self._components[ct]

    # ------------------------------------------------------------------
    # Query helper – entities that have *all* of the supplied component types
    # ------------------------------------------------------------------
    def entities_with(self, *cts: str) -> Iterable[tuple]:
        # Check if no component types
        if not cts:
            # Return empty set
            return iter([])

        sets = []
        for ct in cts:
            ent_set = set(self._components.get(ct.lower(), {}))
            # Check for empty set
            if not ent_set:
                # No match, short circuit
                return iter([])
            # Append set to list of sets
            sets.append(ent_set)

        # Intersect the entity sets for each component type
        matched_ents = set.intersection(*sets)

        # Get all requested components
        retVal = []
        for ent in matched_ents:
            comps = (ent,)
            comps += tuple(self.get_component(ent, ct) for ct in cts)
            retVal.append(comps)

        return iter(retVal)

    # ------------------------------------------------------------------
    # System registration
    # ------------------------------------------------------------------
    def add_system(self, system: System) -> None:
        self._systems.append(system)

    def remove_system(self, system: System) -> None:
        try:
            self._systems.remove(system)
        except ValueError:
            logger.warning(f"System, {system}, not registered")

    # ------------------------------------------------------------------
    # Main loop – called once per tick
    # ------------------------------------------------------------------
    def update(self, dt: float) -> None:
        """
        Execute every registered system in order of registration.
        """
        # Update world time
        self._time += dt

        # TODO: Add performance metrics
        for sys in list(self._systems):
            logger.debug(f"SYSTEM: {sys.__class__.__name__}")
            try:
                sys.update(dt, self)
            except Exception as e:
                logger.error(f"Failed to run: {sys.__class__.__name__}")
                logger.debug(e)
