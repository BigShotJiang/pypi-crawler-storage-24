import logging
import importlib

logger = logging.getLogger(__name__)


class System:
    """
    Abstract base class for all systems.
    Serves as a self registering factory, all implementations must exist in
    the ./systems folder so it can be lazy loaded otherwise it will need to be manually imported before being used
    """

    _registry = {}

    def __init_subclass__(cls, name: str = None, *args, **kwargs):
        super().__init_subclass__(*args, **kwargs)

        # If no name provided, use the module name
        if name is None:
            name = cls.__module__.split(".")[-1]

        # Normalize the instance name to use lowercase of the class name
        name = name.lower()

        # Check if already registered
        if name in System._registry:
            raise ValueError(f"Already registered: {name}")

        # Register an instantiation of the implementation
        System._registry[name] = cls

        if logger.isEnabledFor(logging.DEBUG):
            logger.debug(f"Registered: {name} - {cls}")

    def __new__(cls, name: str = None, config: dict = None):
        """Factory that returns an *instance* of the requested system.

        Parameters
        ----------
        name: str | None
            Identifier of the concrete system (case‑insensitive). If omitted,
            the name of the calling subclass/module is used.
        config: dict | None
            Optional configuration dictionary forwarded to the concrete system's
            ``__init__``.
        """

        # If no name provided, use the class name
        if name is None:
            name = cls.__module__.split(".")[-1]

        # Normalize name to be lowercased
        name = name.lower()

        # Check if implementation is already registered
        if name in System._registry:
            impl_class = System._registry[name]
            return super().__new__(impl_class)

        try:
            # Lazy load implementation
            importlib.import_module(f"systems.{name}")
        except Exception as e:
            logger.error(f"Failed to import systems: {name}")
            logger.debug(e)
            raise ModuleNotFoundError(f"<systems.{name}>")

        # Check if lazy load worked
        if name not in System._registry:
            logger.debug(cls._registry)
            raise ValueError(f"Unknown implementation: {name}")

        impl_class = System._registry[name]
        return super().__new__(impl_class)

    def __init__(self, name: str = None, config: dict = None):
        # Check if already initialized
        if hasattr(self, "_init") and self._init:
            return
        self._init = True

    def update(self, dt: float, world: "World") -> None:
        """
        ``dt`` is the elapsed time (seconds) since the previous tick.
        ``world`` gives read/write access to components.
        """
        raise NotImplementedError
