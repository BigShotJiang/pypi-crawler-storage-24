# entity.py
from __future__ import annotations


class Entity:
    """
    A thin wrapper around an integer ID.
    The ID is immutable (``Final``) so that entities can be used as dict keys
    without accidental mutation.
    """

    __slots__ = ("_id",)

    _counter: int = 0  # class‑wide counter for generating fresh IDs

    def __init__(self) -> None:
        self._id: int = Entity._counter
        Entity._counter += 1

    @property
    def id(self) -> int:
        """Return the underlying integer identifier."""
        return self._id

    # Equality / hashing based on the underlying integer – useful for dicts & sets
    def __eq__(self, other: object) -> bool:
        return isinstance(other, Entity) and self._id == other._id

    def __hash__(self) -> int:
        return hash(self._id)

    def __repr__(self) -> str:
        return f"<Entity {self._id}>"
