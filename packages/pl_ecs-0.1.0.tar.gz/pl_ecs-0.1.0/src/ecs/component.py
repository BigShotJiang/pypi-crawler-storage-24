# component_registry.py
from __future__ import annotations

import sys
import logging
import importlib
import pkgutil
import threading
import uuid
from pathlib import Path
from dataclasses import dataclass, fields, MISSING
from typing import Any, Dict, Tuple, Type

logger = logging.getLogger(__name__)


# ----------------------------------------------------------------------
# Tiny runtime validator (keeps the dataclass approach simple)
# ----------------------------------------------------------------------
def _validate_dataclass(instance: Any) -> None:
    for f in fields(instance):
        value = getattr(instance, f.name)
        if f.default is MISSING and f.default_factory is MISSING:
            expected = f.type
            if expected is Any:
                continue
            if not isinstance(value, expected):
                raise TypeError(
                    f"{type(instance).__name__}.{f.name}: expected {expected}, got {type(value)}"
                )


# ----------------------------------------------------------------------
# Decorator that turns a plain class into a dataclass **and** registers it
# ----------------------------------------------------------------------
class Component:
    """
    Singleton‑style holder for all component classes.
    You can retrieve a component class by name:
        >>> Price = Component.get('Price')
    or create an instance directly:
        >>> price = Component.create('Price', symbol='BTC', bid=1.0, ask=1.1, timestamp=0)
    """

    # Create registry of Components
    _by_name: Dict[str, Type[Any]] = {}
    _lock = threading.Lock()

    def __new__(cls, *args, **kwargs):
        # Enforce Singleton
        if not hasattr(cls, "_instance"):
            # Thread safe lock
            with cls._lock:
                # Double check that instance hasn't been created while waiting for lock
                if not hasattr(cls, "_instance"):
                    # Create the single instance
                    cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self, component_pkg: str = "components"):
        # Only init once
        if hasattr(self, "_init") and self._init:
            return
        self._init = True

        # Get the package containing all components
        try:
            pkg = importlib.import_module(component_pkg)
        except ModuleNotFoundError as exc:
            raise ModuleNotFoundError(
                f"Component package '{component_pkg}' not found. "
                "Make sure it is on the PYTHONPATH."
            ) from exc

        # Auto import any modules defined in a /components directory
        pkg_path = Path(pkg.__file__).parent
        for finder, module_name, is_pkg in pkgutil.iter_modules([str(pkg_path)]):
            full_name = f"components.{module_name}"
            _ = importlib.import_module(full_name)

        # Look for markers to register component
        for module in list(sys.modules.values()):
            mod_pkg = getattr(module, "__package__", "")
            if mod_pkg and not mod_pkg.startswith(component_pkg):
                continue
            for attr_name in dir(module):
                obj = getattr(module, attr_name)
                if getattr(obj, "_is_ecs_component", False):
                    Component.register(obj.__name__, obj)

    @classmethod
    def register(cls, name: str, comp_cls: Type[Any]) -> None:
        with cls._lock:
            if name in cls._by_name:
                # If the signatures differ we raise – helps catch accidental re‑definitions
                existing = cls._by_name[name]
                if existing.__slots__ != comp_cls.__slots__:
                    raise ValueError(
                        f"Component name clash: '{name}' already registered with a different schema"
                    )
                # otherwise silently ignore – the class is already there
                return
            cls._by_name[name] = comp_cls
            if logger.isEnabledFor(logging.DEBUG):
                logger.debug("Component registered: %s", name)

    @classmethod
    def get(cls, name: str) -> Type[Any]:
        """Return the concrete component class (raises KeyError if unknown)."""
        try:
            return cls._by_name[name]
        except KeyError as exc:
            raise KeyError(f"Component '{name}' is not registered") from exc

    @classmethod
    def create(cls, name: str, **kwargs: Any) -> Any:
        """Convenience shortcut – instantiate a registered component."""
        comp_cls = cls.get(name)
        return comp_cls(**kwargs)


def component_dataclass(cls: Type[Any]) -> Type[Any]:
    """
    Decorator that:
      * turns ``cls`` into a ``dataclass(slots=True)``;
      * injects a ``__post_init__`` that runs our runtime validator;
      * registers the resulting class in ``Component`` under ``cls.__name__``.
    """
    # Turn it into a dataclass with slots (memory‑efficient)
    cls = dataclass(eq=True, frozen=False, slots=True)(cls)  # type: ignore

    # Preserve any user‑defined __post_init__
    orig_post = getattr(cls, "__post_init__", lambda self: None)

    def __post_init__(self):
        orig_post(self)  # keep user logic
        _validate_dataclass(self)

    cls.__post_init__ = __post_init__  # type: ignore

    # Set secret flag to indicate this class needs to be registered
    setattr(cls, "_is_ecs_component", True)

    return cls
