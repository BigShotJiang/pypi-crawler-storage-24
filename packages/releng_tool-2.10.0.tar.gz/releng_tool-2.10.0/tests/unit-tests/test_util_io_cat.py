# SPDX-License-Identifier: BSD-2-Clause
# Copyright releng-tool

from pathlib import Path
from releng_tool.util.io_cat import cat
from releng_tool.util.log import is_api_log_mode
from releng_tool.util.log import is_debug
from tests import prepare_workdir
from tests import redirect_stdout
from tests import RelengToolTestCase
import os
import unittest


class TestUtilIoCat(RelengToolTestCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        # tests will not function in a api logging mode
        if is_api_log_mode():
            raise unittest.skipTest('ignoring checks while in api logging mode')

        # tests will not function in a debugging mode
        if is_debug():
            raise unittest.SkipTest('ignoring checks while in debug mode')

    def test_utilio_cat_expanded_encoded(self):
        with redirect_stdout() as stream:
            with prepare_workdir() as test_dir:
                test_file1 = Path(test_dir) / 'test-a'
                with test_file1.open('w') as f:
                    f.write('a')

                test_file2 = Path(test_dir) / 'test-b'
                with test_file2.open('w') as f:
                    f.write('b')

                os.environ['R'] = 'a'
                os.environ['S'] = 'b'

                test_file_encoded1 = os.fsencode(f'{test_dir}/test-$R')
                test_file_encoded2 = os.fsencode(f'{test_dir}/test-$S')
                output = cat(test_file_encoded1, test_file_encoded2)

        self.assertTrue(output)
        self.assertEqual(stream.getvalue(), 'ab')

    def test_utilio_cat_expanded_path(self):
        with redirect_stdout() as stream:
            with prepare_workdir() as test_dir:
                test_dir = Path(test_dir)
                test_file1 = test_dir / 'test-a'
                with test_file1.open('w') as f:
                    f.write('a')

                test_file2 = test_dir / 'test-b'
                with test_file2.open('w') as f:
                    f.write('b')

                os.environ['R'] = 'a'
                os.environ['S'] = 'b'
                output = cat(test_dir / 'test-$R', test_dir / 'test-$S')

        self.assertTrue(output)
        self.assertEqual(stream.getvalue(), 'ab')

    def test_utilio_cat_expanded_str(self):
        with redirect_stdout() as stream:
            with prepare_workdir() as test_dir:
                test_file1 = Path(test_dir) / 'test-a'
                with test_file1.open('w') as f:
                    f.write('a')

                test_file2 = Path(test_dir) / 'test-b'
                with test_file2.open('w') as f:
                    f.write('b')

                os.environ['R'] = 'a'
                os.environ['S'] = 'b'
                output = cat(f'{test_dir}/test-$R', f'{test_dir}/test-$S')

        self.assertTrue(output)
        self.assertEqual(stream.getvalue(), 'ab')

    def test_utilio_cat_invalid_file(self):
        with redirect_stdout() as stream:
            with prepare_workdir() as test_dir:
                output = cat(test_dir)

        self.assertFalse(output)
        self.assertEqual(stream.getvalue(), '')

    def test_utilio_cat_missing_file(self):
        with redirect_stdout() as stream:
            with prepare_workdir() as test_dir:
                missing_file = Path(test_dir) / 'missing-file'

                output = cat(missing_file)

        self.assertFalse(output)
        self.assertEqual(stream.getvalue(), '')

    def test_utilio_cat_valid_contents_multiple(self):
        with redirect_stdout() as stream:
            with prepare_workdir() as test_dir:
                test_file1 = Path(test_dir) / 'test1'
                with test_file1.open('w') as f:
                    f.write('1')

                test_file2 = Path(test_dir) / 'test2'
                with test_file2.open('w') as f:
                    f.write('2')

                test_file3 = Path(test_dir) / 'test3'
                with test_file3.open('w') as f:
                    f.write('3')

                output = cat(test_file1, test_file2, test_file3)

        self.assertTrue(output)
        self.assertEqual(stream.getvalue(), '123')

    def test_utilio_cat_valid_contents_single_encoded(self):
        with redirect_stdout() as stream:
            with prepare_workdir() as test_dir:
                test_file = Path(test_dir) / 'test'

                with test_file.open('w') as f:
                    f.write('this is a test')

                test_file_encoded = os.fsencode(test_file)
                output = cat(test_file_encoded)

        self.assertTrue(output)
        self.assertEqual(stream.getvalue(), 'this is a test')

    def test_utilio_cat_valid_contents_single_path(self):
        with redirect_stdout() as stream:
            with prepare_workdir() as test_dir:
                test_file = Path(test_dir) / 'test'

                with test_file.open('w') as f:
                    f.write('this is a test')

                output = cat(test_file)

        self.assertTrue(output)
        self.assertEqual(stream.getvalue(), 'this is a test')

    def test_utilio_cat_valid_contents_single_str(self):
        with redirect_stdout() as stream:
            with prepare_workdir() as test_dir:
                test_file = Path(test_dir) / 'test'

                with test_file.open('w') as f:
                    f.write('this is a test')

                test_file_str = str(test_file)
                output = cat(test_file_str)

        self.assertTrue(output)
        self.assertEqual(stream.getvalue(), 'this is a test')

    def test_utilio_cat_valid_empty(self):
        with redirect_stdout() as stream:
            with prepare_workdir() as test_dir:
                test_file = Path(test_dir) / 'test'

                with test_file.open('w'):
                    pass  # empty

                output = cat(test_file)

        self.assertTrue(output)
        self.assertEqual(stream.getvalue(), '')
