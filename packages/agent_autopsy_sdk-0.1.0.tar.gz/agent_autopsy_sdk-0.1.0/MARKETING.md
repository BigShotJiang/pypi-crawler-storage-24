# agent-autopsy Marketing Plan

## Awesome Lists

### awesome-langchain

**PR Title:** Add agent-autopsy -- debug tool for LangChain agent traces

**Category:** Tools / Debugging

**Entry:**
```markdown
- [agent-autopsy](https://github.com/VladislavRoss/agent-autopsy-sdk) - Debug tool that captures and visualizes LangChain agent execution traces with timeline, tool calls, and decision reasoning.
```

**Checklist before PR:**
- [ ] Package on PyPI
- [ ] README with usage examples
- [ ] At least 30 GitHub stars (soft requirement)
- [ ] Working demo/screenshot

### awesome-python

**PR Title:** Add agent-autopsy to Debugging Tools

**Category:** Debugging Tools

**Entry:**
```markdown
- [agent-autopsy](https://github.com/VladislavRoss/agent-autopsy-sdk) - Execution trace debugger for AI agents (LangChain, CrewAI, OpenAI Agents SDK).
```

---

## Reddit Strategy

### r/LangChain

**Post Title:** "I built a free debugging tool for LangChain agents -- agent-autopsy"

**Body:**
- Problem: debugging multi-step agents is painful (print statements, manual logging)
- Solution: drop-in callback handler that captures the full execution trace
- Show: timeline visualization, tool call details, decision reasoning
- Free, MIT licensed, pip install agent-autopsy
- Upgrade path: for tamperproof traces, there's aegis-ledger-sdk (link in footer)

**Rules:** No hard sell. Genuine value first. Mention Aegis only in context of upgrade.

### r/MachineLearning

**Post Title:** "[P] agent-autopsy: Execution trace debugger for AI agents"

**Body:** Focus on the debugging problem. Technical audience. Link to GitHub.

---

## Discord Communities

| Community | Channel | Approach |
|-----------|---------|----------|
| LangChain Discord | #showcase | Share with demo |
| CrewAI Discord | #showcase | Integration example |
| AI Engineer Discord | #tools | Technical deep-dive |

**Rule:** Always provide genuine value. Never spam. Answer questions. Be helpful.

---

## Growth Funnel

```
agent-autopsy (free, OSS)
    |
    | Footer: "For tamperproof traces: aegis-ledger.com"
    | upgrade_code: "from aegis.langchain import AegisCallbackHandler"
    |
    v
aegis-ledger-sdk (freemium)
    |
    | 10k free events/month
    | Pro: CHF 39/mo (500k events)
    | Business: CHF 149/mo (5M events)
    |
    v
Enterprise (custom)
```

## PyPI Publication

**Package name:** `agent-autopsy`

**Steps:**
1. Ensure all 40 tests pass
2. Update version in pyproject.toml
3. `hatch build && hatch publish`
4. Verify: `pip install agent-autopsy`

## Success Metrics (First 30 Days)

| Metric | Target |
|--------|--------|
| PyPI installs | 200+ |
| GitHub stars | 25+ |
| Reddit post upvotes | 20+ |
| awesome-langchain PR merged | Yes |
| Users clicking upgrade link | 10+ |
