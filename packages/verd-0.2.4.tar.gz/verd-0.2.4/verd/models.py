"""Model tiers and role assignments for debate.

Each model has a role that shapes its prompt and the judge's weighting.
Users can customize models and roles for their provider.
"""

ROLES = {
    # Role name → (description for prompt, weight hint for judge)
    "analyst": (
        "You are the primary analyst. Give a thorough, balanced initial assessment. "
        "Cover the main arguments for and against. Be specific and evidence-based.",
        "general assessment",
    ),
    "devils_advocate": (
        "You are the devil's advocate. Your job is to find what others miss — "
        "edge cases, hidden assumptions, failure modes, and contrarian perspectives. "
        "If everyone agrees, find the strongest counterargument. "
        "If there's an obvious answer, question why it might be wrong.",
        "contrarian analysis and edge cases",
    ),
    "logic_checker": (
        "You are the logic checker. Focus on reasoning quality — "
        "are the arguments logically sound? Are there fallacies, circular reasoning, "
        "or unsupported leaps? Verify that conclusions follow from premises. "
        "If code is involved, trace execution paths and check for off-by-one, "
        "race conditions, and boundary errors.",
        "logical reasoning and formal analysis",
    ),
    "fact_checker": (
        "You are the fact checker with web search capabilities. "
        "Verify claims against real-world sources. Check if APIs, libraries, "
        "or approaches mentioned actually exist and work as described. "
        "Ground the discussion in documented facts, not assumptions.",
        "web-grounded factual verification",
    ),
    "pragmatist": (
        "You are the pragmatist. Focus on real-world practicality — "
        "will this actually work in production? What are the operational costs, "
        "maintenance burden, team skill requirements, and deployment complexity? "
        "Theory is nice but what matters is shipping.",
        "practical and operational assessment",
    ),
}

MODELS = {
    "verdl": {
        "debaters": [
            {"model": "gpt-5-mini", "role": "analyst"},
            {"model": "gemini-2.5-flash", "role": "devils_advocate"},
        ],
        "judge": "claude-sonnet-4-6",
        "rounds": 1,
    },
    "verd": {
        "debaters": [
            {"model": "claude-sonnet-4-6", "role": "analyst"},
            {"model": "gpt-4.1", "role": "devils_advocate"},
            {"model": "gemini-2.5-flash", "role": "logic_checker"},
            {"model": "gpt-5-mini", "role": "pragmatist"},
        ],
        "judge": "o3",
        "rounds": 2,
    },
    "verdh": {
        "debaters": [
            {"model": "claude-opus-4-6", "role": "analyst"},
            {"model": "deepseek-r1", "role": "devils_advocate"},
            {"model": "gemini-3.1-pro-preview", "role": "logic_checker"},
            {"model": "sonar-pro", "role": "fact_checker"},
            {"model": "gpt-5.4", "role": "pragmatist"},
        ],
        "judge": "o3",
        "rounds": 3,
    },
}

MODEL_PARAMS = {
    "sonar-pro": {
        "web_search_options": {"search_context_size": "high"},
    },
}

# Context window sizes in tokens — used to cap content for smaller models
MODEL_CONTEXT_WINDOWS = {
    "gpt-5-mini":               1_000_000,
    "gpt-5.4":                  1_000_000,
    "gpt-4.1":                  1_000_000,
    "o3":                       200_000,
    "o4-mini":                  200_000,
    "claude-opus-4-6":          1_000_000,
    "claude-sonnet-4-6":        200_000,
    "gemini-2.5-flash":         1_000_000,
    "gemini-3.1-pro-preview":   1_000_000,
    "deepseek-r1":              128_000,
    "sonar-pro":                128_000,
}

# Judge reasoning effort per tier — higher = more thorough but slower
JUDGE_PARAMS = {
    "verdl": {"reasoning_effort": "medium"},
    "verd": {"reasoning_effort": "medium"},
    "verdh": {"reasoning_effort": "high"},
}
