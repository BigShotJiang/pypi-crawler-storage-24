from .wc_object import WcObj

class WcContent(WcObj):
    domain = 'PTC' #There may not be an exposed domain/endpoint to retrieve this object directly
    endpoint = 'ContentItem' #There may not be an exposed domain/endpoint to retrieve this object directly
    def __init__(self, session, obj_id=None, json=None):
        super().__init__(session, obj_id, json)
	
    @staticmethod
    def upload_file(wc_session, domain, endpoint, obj_id, filename, file_bytes, primary_content=False):
        stage1_action = f'PTC.{domain}.UploadStage1Action'
        stage1_body = {'NoOfFiles': 1}
        response = wc_session.call_api(
            request_type='post',
            domain=domain,
            endpoint=endpoint,
            arguments=obj_id,
            action=stage1_action,
            body=stage1_body
        )
        stage2_url = response.json()['value'][0]['ReplicaUrl']
        stream_id = response.json()['value'][0]['StreamIds'][0]
        wc_file_name = response.json()['value'][0]['FileNames'][0]
        
        stage2_addl_headers = {'Content-Type': 'multipart/form-data; boundary=---------------------------boundary'}
        stage2_body_part1 = f'''-----------------------------boundary
Content-Disposition: form-data; name="Master_URL"

{wc_session.base_url}/WindchillGW
-----------------------------boundary
Content-Disposition: form-data; name="CacheDescriptor_array"

{stream_id}:{wc_file_name}:{stream_id}
-----------------------------boundary
Content-Disposition: form-data; name="{wc_file_name}"; filename="{filename}"

'''#file_bytes will go here
        stage2_body_part2 = '''
-----------------------------boundary
'''
        #Note: String above ^^^ is very finicky - even spaces will break it. Also, note that there are 2 more dashes in header than in ---...boundary in body. 
        stage2_body = stage2_body_part1.encode() + file_bytes + stage2_body_part2.encode()
        response = wc_session.call_api(
            request_type='post',
            raw_url = stage2_url,
            data=stage2_body, #TODO: See if we can pass this in a json object. then we can remove the data input from the call_api signature. 
            addl_headers=stage2_addl_headers
        )
        file_size = response.json()['contentInfos'][0]['fileSize']
        encoded_info = response.json()['contentInfos'][0]['encodedInfo']
        
        stage3_action = f'PTC.{domain}.UploadStage3Action'
        stage3_body = {
            "ContentInfo" : [
                {	
                    "StreamId" : stream_id,
                    "EncodedInfo" : encoded_info,
                    "FileName" : filename,
                    "PrimaryContent" : primary_content,
                    "MimeType" : "null",
                    "FileSize" : file_size
                }
            ]
        }
        response = wc_session.call_api(
            request_type='post',
            domain=domain,
            endpoint=endpoint,
            arguments=obj_id,
            action=stage3_action,
            body=stage3_body
        )
        return response
        
    def download_file(self):
        file_url = self.attrs['Content']['URL']
        response = self.session.call_api(
            request_type='get',
            raw_url=file_url
        )
        return response.content
    
class WcRep(WcObj):
    domain = 'PTC' #There may not be an exposed domain/endpoint to retrieve this object directly
    endpoint = 'Representation' #There may not be an exposed domain/endpoint to retrieve this object directly
    def __init__(self, session, obj_id=None, json=None):
        super().__init__(session, obj_id, json)