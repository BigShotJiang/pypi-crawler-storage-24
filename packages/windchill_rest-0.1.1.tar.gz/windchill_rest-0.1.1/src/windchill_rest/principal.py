from .wc_object import WcObj

class WcPrincipal(WcObj):
    def __init__(self, session, obj_id=None, json=None):
        super().__init__(session, obj_id, json)

class WcGroup(WcPrincipal):
    domain = 'PrincipalMgmt'
    endpoint = 'Groups'
    def __init__(self, session, obj_id=None, json=None):
        super().__init__(session, obj_id, json)
    
    def get_users(self, select_str=''):
        users = self.get_related('Users', WcUser, select_str)
        return users
        
class WcUser(WcPrincipal):
    domain = 'PrincipalMgmt'
    endpoint = 'Users'
    def __init__(self, session, obj_id=None, json=None):
        super().__init__(session, obj_id, json)