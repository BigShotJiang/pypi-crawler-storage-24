
from .wc_object import WcObj
from .workable import WcWorkable

class WcChange(WcObj):
    def __init__(self, session, obj_id=None, json=None):
        super().__init__(session, obj_id, json)

    def get_aff_objs(self):
        navigation = 'AffectedObjects'
        objs = self.get_related(navigation, WcWorkable)
        return objs


class WcPr(WcChange):
    domain = 'ChangeMgmt'
    endpoint = 'ProblemReports'
    def __init__(self, session, obj_id=None, json=None):
        super().__init__(session, obj_id, json)

class WcCr(WcChange):
    domain = 'ChangeMgmt'
    endpoint = 'ChangeRequests'
    def __init__(self, session, obj_id=None, json=None):
        super().__init__(session, obj_id, json)

class WcCn(WcChange):
    domain = 'ChangeMgmt'
    endpoint = 'ChangeNotices'
    def __init__(self, session, obj_id=None, json=None):
        super().__init__(session, obj_id, json)
    
    def get_res_objs(self):
        navigation = 'ResultingObjects'
        objs = self.get_related(navigation, WcWorkable)
        return objs
