'''piss off pylint'''
from ast import literal_eval
import time
import re
import requests
from bs4 import BeautifulSoup
from selenium import webdriver 
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium import common

class Vulcan:
    def __init__(self, username, password, city, school, cookie=None):
        options = Options()
        options.add_argument("--window-size=1920,1080")
        options.add_argument("--disable-gpu")
        options.add_argument("--no-sandbox")
        options.add_argument('--headless')
        
        self.driver = webdriver.Chrome(options=options)

        self.session = requests.session()

        self.username = username
        self.password = password
        self.city = city
        self.school = school
        self.cookie = cookie

        if self.cookie is not True:
            self.driver.get(f'https://logowanie.edu.{self.city}.pl/LoginPage.aspx')
            time.sleep(1)
            self.driver.set_window_size(1920, 1080)

            # Defining fields and buttons at the start
            username_input = self.driver.find_element(By.ID, 'Username')
            username_input.send_keys(self.username)

            password_input = self.driver.find_element(By.ID, 'Password')
            password_input.send_keys(self.password)

            login_btn = self.driver.find_element(By.CSS_SELECTOR, 'button.submit-button.box-line')
            login_btn.click()

            # Simulating a regular user, so appropriate cookies will create
            self.driver.get(f'https://uonetplus.edu.{self.city}.pl/{self.city}/Start.mvc')
            self.driver.get(f'https://uonetplus-uczen.edu.{self.city}.pl/{self.city}/{self.school}/App')
            
            soup = BeautifulSoup(self.driver.page_source, 'html.parser')
            buttons = soup.select('button')
            for button in buttons:
                if button.get('id').startswith('ext-element-') and button.get('data-componentid').startswith('ext-tab') and button.text != '':
                    try:
                        self.driver.find_element(By.ID, button.get('id')).click()
                    except common.exceptions.ElementNotInteractableException:
                        continue
            
            time.sleep(0.5)

            # Getting and setting the cookies
            self.cookies = self.driver.get_cookies()
            self.driver.quit()
        elif self.cookie is True:
            self.cookies = literal_eval(open('.vulcan.cookie', 'r',encoding='utf-8').read())
        else:
            raise AttributeError(
                'Use True in the cookie variable while defining Vulcan() if you\'d like to read from a file (When export_cookies() is ran)',
                'Otherwise leave it empty. Please don\'t crash out',
                '- Your fellow maintainer :D'
            )

        for cookie in self.cookies:
            self.session.cookies.set(
                cookie['name'],
                cookie['value'],
                domain=cookie.get('domain', '').lstrip('.'),
                path=cookie.get('path', '/')
            )

    def export_cookies(self):
        with open('./.vulcan.cookie','w', encoding='utf-8') as file:
            file.write(str(self.cookies))
        return 'OK'

    def get_classes(self, date):
        classes = []
        response = self.session.post(f'https://uonetplus-uczen.edu.{self.city}.pl/{self.city}/{self.school}/PlanZajec.mvc/Get', data={"data": f"{date}T00:00"}, timeout=5).json()

        for rows in response['data']['Rows']:
            for cols in rows:
                description = cols['Description'].strip()
                soup = BeautifulSoup(description, 'html.parser')
                formatted = soup.text
                hours = re.findall('\\d+ \\d+:\\d+ \\d+:\\d+', formatted)
                cleaned_text = formatted
                for h in hours:
                    cleaned_text = cleaned_text.replace(h, '')
                for items in formatted.split('\n'):
                    classes.append(items)

        monday = [classes[1], classes[7], classes[13], classes[19], classes[25], classes[31], classes[37], classes[43], classes[49], classes[55], classes[61], classes[67]]
        tuesday = [classes[2], classes[8], classes[14], classes[20], classes[26], classes[32], classes[38], classes[44], classes[50], classes[56], classes[62], classes[68]]
        wednesday = [classes[3], classes[9], classes[15], classes[21], classes[27], classes[33], classes[39], classes[45], classes[51], classes[57], classes[63], classes[69]]
        thursday = [classes[4], classes[10], classes[16], classes[22], classes[28], classes[34], classes[40], classes[46], classes[52], classes[58], classes[64], classes[70]]
        friday = [classes[5], classes[11], classes[17], classes[23], classes[29], classes[35], classes[41], classes[47], classes[53], classes[59], classes[65], classes[71]]
        hours = ['7.05 - 7.50','8.00 - 8.45', '8.55 - 9.40','9.50 - 10.35', '10.45 - 11.30', '11.50 - 12.35', '12.55 - 13.40', '13.50 - 14.35', '14.45 - 15.30', '15.40 - 16.25', '16.35 - 17.20', '17.30 - 18.15']

        return {
            "Monday": monday,
            "Tuesday": tuesday,
            "Wednesday": wednesday,
            "Thursday": thursday,
            "Friday": friday,
        }
    def get_grades(self, okres):
        if okres == 1:
            okres = 65155
        elif okres == 2:
            okres = 65156
        
        response = self.session.post(f'https://uonetplus-uczen.edu.{self.city}.pl/{self.city}/{self.school}/Oceny.mvc/Get', data={"okres":okres}).json()
        return response['data']['Oceny'] # For the love of god don't parse this.
    def get_attendance(self, date):
        response = self.session.post(f'https://uonetplus-uczen.edu.{self.city}.pl/{self.city}/{self.school}/Frekwencja.mvc/Get',data={"idTypWpisuFrekwencji":-1,"data":f"{date}T00:00"}).json()
        return response['data']

    def get_behavior(self):
        response = self.session.post(f'https://uonetplus-uczen.edu.{self.city}.pl/{self.city}/{self.school}/UwagiIOsiagniecia.mvc/Get', data={}).json()
        return response['data']
    def get_pupil_bg(self, okres):
        if okres == 1:
            okres = 65155
        elif okres == 2:
            okres = 65156
        response = self.session.post(f'https://uonetplus-uczen.edu.{self.city}.pl/{self.city}/{self.school}/StatystykiOcenyCzastkowe.mvc/Get', data={"idOkres":okres}).json()
        return response['data']
    def get_announcements(self):
        headers = {
            "X-Requested-With": "XMLHttpRequest"
        }
        response = self.session.post(f'https://uonetplus-uczen.edu.{self.city}.pl/{self.city}/{self.school}/Ogloszenia.mvc/Get', headers=headers).json()
        return response['data']
    def get_meetings(self):
        response = self.session.post(f'https://uonetplus-uczen.edu.{self.city}.pl/{self.city}/{self.school}/Zebrania.mvc/Get').json()
        return response['data']
    def get_exams(self, date, schoolyear):
        response = self.session.post(f'https://uonetplus-uczen.edu.{self.city}.pl/{self.city}/{self.school}/Sprawdziany.mvc/Get', data={'data': f'{date}T00:00:00', 'rokSzkolny': schoolyear}).json()
        return response['data']
    def get_homework(self, date, schoolyear):
        headers = {
            "X-Requested-With": "XMLHttpRequest"
        }
        response = self.session.post(f'https://uonetplus-uczen.edu.{self.city}.pl/{self.city}/{self.school}/Homework.mvc/Get', data={'data': f'{date}T00:00:00', 'rokSzkolny': schoolyear, 'statusFilter': -1}, headers=headers).json()
        return response
    def get_school_and_teachers(self):
        response = self.session.post(f'https://uonetplus-uczen.edu.{self.city}.pl/{self.city}/{self.school}/SzkolaINauczyciele.mvc/Get', data={}).json()
        return response['data']
