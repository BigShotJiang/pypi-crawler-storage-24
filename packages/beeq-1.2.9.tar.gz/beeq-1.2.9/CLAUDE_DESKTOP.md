# BeeQ — Claude Desktop Integration

Add BeeQ as an MCP server to Claude Desktop.

## macOS

```bash
# Edit Claude Desktop config
nano ~/Library/Application\ Support/Claude/claude_desktop_config.json
```

## Windows

```
%APPDATA%\Claude\claude_desktop_config.json
```

## Config to add

```json
{
  "mcpServers": {
    "beeq": {
      "command": "beeq",
      "args": ["mcp-server"]
    }
  }
}
```

## What you get

Once connected, Claude Desktop has access to:

| Tool | What it does |
|------|-------------|
| `execute_mission` | Give a mission to your BeeQ hive |
| `remember` | Store in sovereign memory (local SQLite, never cloud) |
| `recall` | Search memory with BM25 + synonyms |
| `verify_pia` | Verify a Prior Intent Proof |
| `hive_status` | Current hive state, workers, audit chain |
| `run_code` | Execute Python/bash in isolated sandbox |
| `write_document` | Generate Markdown, HTML, or PDF |
| `search_web` | DDG search, no API key needed |

## Verify it works

In Claude Desktop, try:
> "Use BeeQ to execute a mission: what is the capital of Morocco?"

You should see Claude use the `execute_mission` tool and return a result
with a `verify_url` you can check at `https://beeq.run/verify/<hash>`.
