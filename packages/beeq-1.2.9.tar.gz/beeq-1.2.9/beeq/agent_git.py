"""
Git pour Agents — Feature 6 de BeeQ.

beeq commit "mission terminée"   → snapshot signé AAP de l'état du hive
beeq branch "nouvelle-stratégie" → fork du hive (nouvelle ligne de missions)
beeq rollback mission-47         → retour à un état précédent
beeq log                         → historique complet des missions

Pourquoi c'est révolutionnaire:
- Un hive a une histoire. Comme un dépôt Git a une histoire.
- Tu peux "brancher" pour tester une stratégie sans affecter la principale.
- Tu peux revenir en arrière si une mission a mal tourné.
- Yasmin peut "cloner" le hive de Mehdi et continuer son travail.
- Les PIAs sont liées aux commits — chaque snapshot a sa preuve d'intention.

Structure:
  ~/.beeq/history/
    commits/
      <commit_hash>.json   — snapshot complet du hive à cet instant
    branches/
      main                 → pointe vers le dernier commit de main
      <branch>/            → branche alternative
    HEAD                   → branche ou commit actif

Un commit contient:
  - hash du commit (SHA-256 du contenu)
  - message
  - timestamp
  - parent commit hash
  - session state snapshot (mémoire, workers actifs, dernière mission)
  - PIA IDs des missions de cette session
  - signature AAP du Queen

Z = dI/d(log s) · exp(iθ)
  Chaque commit maximise I (information préservée)
  L'historique est invariant d'échelle (fonctionne pour 1 commit ou 10000)
  θ = 0 parce que l'état déclaré = l'état réel
"""

import hashlib
import json
import shutil
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


HISTORY_ROOT = Path.home() / ".beeq" / "history"
COMMITS_DIR  = HISTORY_ROOT / "commits"
BRANCHES_DIR = HISTORY_ROOT / "branches"
HEAD_FILE    = HISTORY_ROOT / "HEAD"


@dataclass
class Commit:
    """A snapshot of the hive state at a point in time."""
    hash:       str           # SHA-256 — canonical ID
    message:    str           # Human description of the milestone
    timestamp:  str           # ISO-8601 UTC
    timestamp_unix: float
    parent:     Optional[str] # Previous commit hash (None for first)
    branch:     str           # Branch this commit belongs to

    # Hive state snapshot
    session_state:  dict = field(default_factory=dict)   # All session key/values
    memory_export:  dict = field(default_factory=dict)   # Memory items (condensed)
    active_workers: list = field(default_factory=list)   # Worker names active
    missions_count: int  = 0                             # Total missions this session
    pia_ids:        list = field(default_factory=list)   # PIAs from this session

    # Integrity
    signature:  str = ""  # sha256 of content

    def to_dict(self) -> dict:
        return asdict(self)

    def summary(self) -> str:
        ago = _time_ago(self.timestamp_unix)
        parent_str = f" ← {self.parent[:8]}" if self.parent else " (root)"
        return (
            f"  {self.hash[:8]}  [{self.branch}]{parent_str}  "
            f"{ago}  {self.message}"
        )


class AgentGit:
    """
    Git-like version control for BeeQ hives.

    Every operation is append-only — nothing is ever deleted.
    Rollback creates a new commit that restores a previous state.
    This preserves the full audit history (LEX §4).
    """

    def __init__(self, hive=None):
        self.hive = hive
        COMMITS_DIR.mkdir(parents=True, exist_ok=True)
        BRANCHES_DIR.mkdir(parents=True, exist_ok=True)
        self._ensure_main()

    # ── PUBLIC API ────────────────────────────────────────────────

    def commit(self, message: str) -> Commit:
        """
        Snapshot the current hive state with a message.

        Like `git commit -m "message"` but for an AI hive.
        Records: memory, session state, active workers, recent PIAs.
        Signs the snapshot with SHA-256.
        """
        now = datetime.now(timezone.utc)
        parent = self._head_hash()
        branch = self._current_branch()

        # Collect state
        session_state = {}
        memory_items  = []
        workers       = []
        missions      = 0
        pia_ids       = []

        if self.hive:
            # Session state
            if hasattr(self.hive, 'memory') and self.hive.memory:
                session_state = self.hive.memory.session_all()
                # Export memory (summary only — not full content)
                mem_summary = self.hive.memory.summary()
                memory_items = [{"summary": mem_summary}]
            # Workers
            if hasattr(self.hive, 'governance'):
                workers = list(self.hive.governance.workers.keys())
                missions = len(list(self.hive.governance.audit_entries))
            # Recent PIAs
            from beeq.intention import IntentionEngine
            engine = IntentionEngine()
            recent_pias = engine.list_recent(20)
            pia_ids = [p.pia_id for p in recent_pias]

        # Build commit content
        content = {
            "message":      message,
            "timestamp":    now.isoformat(),
            "parent":       parent,
            "branch":       branch,
            "session_state": session_state,
            "active_workers": workers,
            "missions_count": missions,
            "pia_ids":      pia_ids,
        }
        content_json = json.dumps(content, sort_keys=True, ensure_ascii=False)
        commit_hash  = hashlib.sha256(content_json.encode()).hexdigest()
        signature    = f"sha256:{hashlib.sha256((commit_hash + now.isoformat()).encode()).hexdigest()}"

        c = Commit(
            hash=commit_hash,
            message=message,
            timestamp=now.isoformat(),
            timestamp_unix=now.timestamp(),
            parent=parent,
            branch=branch,
            session_state=session_state,
            memory_export={"items": memory_items},
            active_workers=workers,
            missions_count=missions,
            pia_ids=pia_ids,
            signature=signature,
        )

        # Store
        self._store_commit(c)
        self._update_branch(branch, commit_hash)
        return c

    def branch(self, name: str, from_commit: str = None) -> str:
        """
        Create a new branch from current HEAD (or a specific commit).

        Like `git checkout -b name` — creates a parallel line of development.
        The new branch is checked out immediately.
        """
        # Validate name
        name = name.replace(" ", "-").lower()
        branch_file = BRANCHES_DIR / name

        if branch_file.exists():
            raise ValueError(f"Branch '{name}' already exists")

        # Point to specified commit or current HEAD
        start = from_commit or self._head_hash() or ""
        branch_file.write_text(start)

        # Switch to new branch
        HEAD_FILE.write_text(f"ref: {name}")

        return name

    def checkout(self, target: str) -> str:
        """
        Switch to a branch or commit.

        Does NOT modify the working state (hive memory etc.) — that's rollback.
        Just changes what HEAD points to.
        """
        # Is it a branch?
        branch_file = BRANCHES_DIR / target
        if branch_file.exists():
            HEAD_FILE.write_text(f"ref: {target}")
            return f"Switched to branch '{target}'"

        # Is it a commit hash (full or short)?
        commit = self._find_commit(target)
        if commit:
            HEAD_FILE.write_text(f"detached: {commit.hash}")
            return f"HEAD detached at {commit.hash[:8]}"

        raise ValueError(f"Unknown branch or commit: {target}")

    def rollback(self, target: str) -> Commit:
        """
        Create a new commit that restores a previous state.

        Like `git revert` — does NOT delete history.
        Creates a NEW commit with the old state (LEX §4 — memory of acts).
        Returns the new commit.
        """
        commit = self._find_commit(target)
        if not commit:
            raise ValueError(f"Commit not found: {target}")

        # Restore session state in hive
        if self.hive and hasattr(self.hive, 'memory') and self.hive.memory:
            for k, v in commit.session_state.items():
                self.hive.memory.session_set(k, v)

        # Create a new commit recording the rollback
        return self.commit(
            f"rollback: restore state from {commit.hash[:8]} — '{commit.message}'"
        )

    def log(self, branch: str = None, n: int = 20) -> list[Commit]:
        """Return commit history for a branch (newest first)."""
        b = branch or self._current_branch()
        tip = self._branch_head(b)
        if not tip:
            return []

        commits = []
        current = tip
        while current and len(commits) < n:
            c = self._load_commit(current)
            if not c:
                break
            commits.append(c)
            current = c.parent

        return commits

    def branches(self) -> dict:
        """List all branches and their HEAD commits."""
        result = {}
        for f in BRANCHES_DIR.iterdir():
            if f.is_file():
                tip = f.read_text().strip()
                result[f.name] = tip[:8] if tip else "(empty)"
        return result

    def status(self) -> dict:
        """Current HEAD state."""
        return {
            "branch":      self._current_branch(),
            "head":        self._head_hash(),
            "head_short":  (self._head_hash() or "")[:8] or "(no commits)",
            "branches":    list(self.branches().keys()),
            "uncommitted": self._has_changes(),
        }

    # ── INTERNAL ──────────────────────────────────────────────────

    def _ensure_main(self):
        """Create main branch if it doesn't exist."""
        main_file = BRANCHES_DIR / "main"
        if not main_file.exists():
            main_file.write_text("")
        if not HEAD_FILE.exists():
            HEAD_FILE.write_text("ref: main")

    def _current_branch(self) -> str:
        if not HEAD_FILE.exists():
            return "main"
        head = HEAD_FILE.read_text().strip()
        if head.startswith("ref: "):
            return head[5:]
        return "main"

    def _head_hash(self) -> Optional[str]:
        branch = self._current_branch()
        return self._branch_head(branch)

    def _branch_head(self, branch: str) -> Optional[str]:
        f = BRANCHES_DIR / branch
        if not f.exists():
            return None
        tip = f.read_text().strip()
        return tip if tip else None

    def _update_branch(self, branch: str, commit_hash: str):
        (BRANCHES_DIR / branch).write_text(commit_hash)

    def _store_commit(self, c: Commit):
        path = COMMITS_DIR / f"{c.hash}.json"
        path.write_text(json.dumps(c.to_dict(), indent=2, ensure_ascii=False))

    def _load_commit(self, hash_or_short: str) -> Optional[Commit]:
        # Try exact match
        path = COMMITS_DIR / f"{hash_or_short}.json"
        if path.exists():
            return Commit(**json.loads(path.read_text()))
        # Try short hash
        for f in COMMITS_DIR.glob(f"{hash_or_short}*.json"):
            return Commit(**json.loads(f.read_text()))
        return None

    def _find_commit(self, ref: str) -> Optional[Commit]:
        """Find commit by hash, short hash, or branch name."""
        # Check if it's a branch
        branch_file = BRANCHES_DIR / ref
        if branch_file.exists():
            tip = branch_file.read_text().strip()
            if tip:
                return self._load_commit(tip)
        # Try as hash
        return self._load_commit(ref)

    def _has_changes(self) -> bool:
        """Check if there are unsaved changes (simplified)."""
        if not self.hive:
            return False
        # If missions were run since last commit
        if hasattr(self.hive, 'governance'):
            audit_count = len(list(self.hive.governance.audit_entries))
            head = self._head_hash()
            if head:
                c = self._load_commit(head)
                if c and c.missions_count != audit_count:
                    return True
        return False


def _time_ago(ts: float) -> str:
    """Human-readable time ago."""
    delta = datetime.now(timezone.utc).timestamp() - ts
    if delta < 60:
        return f"{int(delta)}s ago"
    if delta < 3600:
        return f"{int(delta/60)}m ago"
    if delta < 86400:
        return f"{int(delta/3600)}h ago"
    return f"{int(delta/86400)}d ago"
