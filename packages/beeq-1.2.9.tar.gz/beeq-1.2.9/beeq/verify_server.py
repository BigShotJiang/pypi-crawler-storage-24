"""
beeq.run/verify/<hash> — Endpoint de vérification publique.

N'importe qui dans le monde peut vérifier une PIA.
Pas de compte. Pas de clé API. Juste le hash.

C'est le Bitcoin de la confiance pour les actions IA.
"""

import json
import sys
import os
from pathlib import Path
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse

# PIA store — même chemin que IntentionEngine
PIA_STORE = Path.home() / ".beeq" / "intentions"


class VerifyHandler(BaseHTTPRequestHandler):

    def log_message(self, format, *args):
        pass  # Silencieux

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path

        # Health check
        if path == "/health":
            self._json({"status": "ok", "pia_count": len(list(PIA_STORE.glob("*.json")))})
            return

        # GET /verify/<hash>
        if path.startswith("/verify/"):
            pia_id = path[len("/verify/"):].strip("/")
            self._handle_verify(pia_id)
            return

        # GET /verify (liste les 10 dernières)
        if path == "/verify":
            self._handle_list()
            return

        self._json({"error": "Not found"}, status=404)

    def _handle_verify(self, pia_id: str):
        # Valider format
        if not pia_id or len(pia_id) != 64 or not all(c in "0123456789abcdef" for c in pia_id):
            self._json({"valid": False, "error": "Invalid PIA ID format"}, status=400)
            return

        # Charger depuis le store
        path = PIA_STORE / f"{pia_id}.json"
        if not path.exists():
            self._json({
                "valid": False,
                "error": "PIA not found",
                "pia_id": pia_id,
                "message": "This PIA ID does not exist in this hive's store."
            }, status=404)
            return

        try:
            data = json.loads(path.read_text())
        except Exception as e:
            self._json({"valid": False, "error": f"Corrupted PIA: {e}"}, status=500)
            return

        # Vérification cryptographique
        import hashlib

        errors = []

        # 1. Mission hash
        computed_mission = hashlib.sha256(data["mission"].encode()).hexdigest()
        if computed_mission != data["mission_hash"]:
            errors.append("mission_hash_mismatch")

        # 2. Plan hash
        plan_json = json.dumps(data["plan"], sort_keys=True, ensure_ascii=False)
        computed_plan = hashlib.sha256(plan_json.encode()).hexdigest()
        if computed_plan != data["plan_hash"]:
            errors.append("plan_hash_mismatch")

        # 3. Signature
        if data["signature"].startswith("sha256:"):
            sig_content = f"{data['mission_hash']}{data['plan_hash']}{data['timestamp_intent']}{data['node_id']}"
            expected = f"sha256:{hashlib.sha256(sig_content.encode()).hexdigest()}"
            if expected != data["signature"]:
                errors.append("signature_mismatch")

        # 4. PIA ID
        pia_content = f"{data['mission_hash']}{data['plan_hash']}{data['timestamp_intent']}{data['node_id']}{data['signature']}"
        computed_id = hashlib.sha256(pia_content.encode()).hexdigest()
        if computed_id != pia_id:
            errors.append("pia_id_mismatch")

        # 5. Temporal order
        temporal_valid = True
        if data.get("timestamp_action"):
            from datetime import datetime, timezone
            t_intent = datetime.fromisoformat(data["timestamp_intent"]).timestamp()
            t_action = datetime.fromisoformat(data["timestamp_action"]).timestamp()
            if t_intent >= t_action:
                errors.append("temporal_violation")
                temporal_valid = False

        valid = len(errors) == 0

        result = {
            "valid": valid,
            "pia_id": pia_id,
            "errors": errors,
            "temporal_valid": temporal_valid,
            "plan_followed": data.get("plan_followed", True),
            "divergences": data.get("divergences", []),
            "mission": data["mission"],
            "mission_hash": data["mission_hash"],
            "node_id": data["node_id"],
            "timestamp_intent": data["timestamp_intent"],
            "timestamp_action": data.get("timestamp_action"),
            "timestamp_done": data.get("timestamp_done"),
            "actions_count": data.get("actions_count", 0),
            "subtasks_planned": len(data.get("plan", {}).get("subtasks", [])),
            "verify_url": data.get("verify_url", f"https://beeq.run/verify/{pia_id}"),
            "signature": data["signature"],
            "beeq_version": "1.2.0",
            "summary": (
                f"✅ VALID — This BeeQ hive declared its intention at "
                f"{data['timestamp_intent']} — BEFORE any action was taken. "
                f"The plan was {'followed exactly' if data.get('plan_followed', True) else 'adapted (see divergences)'}. "
                f"This proof is cryptographically verified."
            ) if valid else (
                f"❌ INVALID — Verification failed: {', '.join(errors)}"
            ),
        }

        # HTML response if browser
        accept = self.headers.get("Accept", "")
        if "text/html" in accept:
            self._html_verify(result)
        else:
            self._json(result)

    def _handle_list(self):
        """List 10 most recent PIAs (public metadata only)."""
        files = sorted(
            PIA_STORE.glob("*.json"),
            key=lambda f: f.stat().st_mtime,
            reverse=True
        )[:10]
        pias = []
        for f in files:
            try:
                d = json.loads(f.read_text())
                pias.append({
                    "pia_id": d["pia_id"],
                    "mission_preview": d["mission"][:60] + "..." if len(d["mission"]) > 60 else d["mission"],
                    "timestamp_intent": d["timestamp_intent"],
                    "valid": True,
                    "verify_url": d.get("verify_url", f"https://beeq.run/verify/{d['pia_id']}")
                })
            except Exception:
                pass
        self._json({"count": len(pias), "pias": pias})

    def _json(self, data: dict, status: int = 200):
        body = json.dumps(data, indent=2, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", len(body))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _html_verify(self, r: dict):
        valid = r["valid"]
        color = "#22c55e" if valid else "#ef4444"
        icon = "✅" if valid else "❌"
        body = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BeeQ Verify — {r['pia_id'][:16]}...</title>
  <style>
    * {{ box-sizing: border-box; margin: 0; padding: 0; }}
    body {{ font-family: 'Courier New', monospace; background: #0a0a0a; color: #e5e5e5; padding: 2rem; }}
    .container {{ max-width: 800px; margin: 0 auto; }}
    .header {{ border: 2px solid {color}; padding: 1.5rem; border-radius: 8px; margin-bottom: 2rem; }}
    .status {{ font-size: 2rem; color: {color}; margin-bottom: 0.5rem; }}
    .hash {{ font-size: 0.75rem; color: #666; word-break: break-all; }}
    .section {{ margin: 1.5rem 0; }}
    .label {{ color: #888; font-size: 0.8rem; text-transform: uppercase; margin-bottom: 0.3rem; }}
    .value {{ color: #e5e5e5; font-size: 0.9rem; }}
    .timeline {{ display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 1rem; margin: 1rem 0; }}
    .time-box {{ background: #111; border: 1px solid #333; padding: 1rem; border-radius: 6px; }}
    .time-label {{ color: #888; font-size: 0.75rem; margin-bottom: 0.3rem; }}
    .time-value {{ color: #e5e5e5; font-size: 0.8rem; }}
    .mission {{ background: #111; border-left: 3px solid {color}; padding: 1rem; border-radius: 4px; }}
    .summary {{ color: {color}; margin-top: 1rem; font-size: 0.95rem; line-height: 1.6; }}
    .footer {{ margin-top: 3rem; color: #444; font-size: 0.75rem; text-align: center; }}
    .footer a {{ color: #666; text-decoration: none; }}
  </style>
</head>
<body>
<div class="container">
  <div class="header">
    <div class="status">{icon} {"VALID PROOF" if valid else "INVALID"}</div>
    <div class="hash">PIA: {r['pia_id']}</div>
  </div>

  <div class="section">
    <div class="label">Mission</div>
    <div class="mission">{r['mission']}</div>
  </div>

  <div class="section">
    <div class="label">Timeline</div>
    <div class="timeline">
      <div class="time-box">
        <div class="time-label">🧠 Intent declared</div>
        <div class="time-value">{r.get('timestamp_intent','—')[:23]}</div>
      </div>
      <div class="time-box">
        <div class="time-label">⚡ First action</div>
        <div class="time-value">{r.get('timestamp_action','—')[:23] if r.get('timestamp_action') else '—'}</div>
      </div>
      <div class="time-box">
        <div class="time-label">✓ Completed</div>
        <div class="time-value">{r.get('timestamp_done','—')[:23] if r.get('timestamp_done') else '—'}</div>
      </div>
    </div>
    <div style="color: {'#22c55e' if r['temporal_valid'] else '#ef4444'}; font-size: 0.85rem; margin-top: 0.5rem;">
      {'✓ Intent preceded action — temporal order verified' if r['temporal_valid'] else '✗ Temporal violation detected'}
    </div>
  </div>

  <div class="section">
    <div class="label">Verification Details</div>
    <div style="font-size: 0.85rem; line-height: 2;">
      Actions executed: {r['actions_count']}<br>
      Subtasks planned: {r['subtasks_planned']}<br>
      Plan followed: {'yes' if r['plan_followed'] else 'adapted — see divergences'}<br>
      Node: {r['node_id']}<br>
      Signature: {r['signature'][:48]}...
    </div>
  </div>

  <div class="summary">{r['summary']}</div>

  <div class="footer">
    <a href="https://beeq.run">beeq.run</a> · Prior Intent Proof v1 ·
    BeeQ {r['beeq_version']} · Powered by AAP
  </div>
</div>
</body>
</html>"""
        body = body.encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", len(body))
        self.end_headers()
        self.wfile.write(body)


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 7936
    PIA_STORE.mkdir(parents=True, exist_ok=True)
    server = HTTPServer(("0.0.0.0", port), VerifyHandler)
    print(f"BeeQ Verify server — port {port}")
    print(f"PIA store: {PIA_STORE} ({len(list(PIA_STORE.glob('*.json')))} PIAs)")
    server.serve_forever()
