"""
BeeQ Dashboard API — FastAPI backend pour le Dashboard Reine Avatar.

Port: 7935 (dashboard défini dans les décisions gravées)

Endpoints:
  GET  /status          — état complet de la ruche (workers, PIAs, skills)
  GET  /missions        — missions récentes avec PIAs
  GET  /workers         — état de chaque worker (base + domaine)
  GET  /pia/recent      — 10 dernières PIAs
  WS   /ws              — WebSocket temps réel (missions en cours)
  POST /mission         — lancer une mission depuis le dashboard
  GET  /queen           — état de la Reine (mémoire, dernière action)

Z = dI/d(log s) · exp(iθ)
  Le dashboard = rendre θ visible.
  Chaque ouvrière = dI pour sa niche.
"""

import asyncio
import json
import time
from pathlib import Path
from typing import Any

try:
    from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import JSONResponse
    import uvicorn
    HAS_FASTAPI = True
except ImportError:
    HAS_FASTAPI = False

BEEQ_DIR     = Path.home() / ".beeq"
INTENTIONS   = BEEQ_DIR / "intentions"
DOCUMENTS    = BEEQ_DIR / "documents"
HISTORY_ROOT = BEEQ_DIR / "history"

# Worker personalities pour l'avatar
WORKER_PERSONALITIES = {
    # Base workers
    "research":    {"emoji": "🔍", "color": "#4A9EFF", "trait": "curieuse",
                    "description": "Cherche, explore, découvre"},
    "code":        {"emoji": "⚡", "color": "#FF6B35", "trait": "prudente",
                    "description": "Construit, teste, vérifie (LEX §9)"},
    "write":       {"emoji": "✍️",  "color": "#9B59B6", "trait": "précise",
                    "description": "Rédige, structure, livre"},
    "ops":         {"emoji": "🛠️",  "color": "#2ECC71", "trait": "fiable",
                    "description": "Surveille, maintient, alerte"},
    "memory":      {"emoji": "🧠", "color": "#F39C12", "trait": "silencieuse",
                    "description": "Se souvient, associe, oublie jamais"},
    "hardware":    {"emoji": "💻", "color": "#95A5A6", "trait": "observatrice",
                    "description": "Lit, ne touche pas (Phase 0)"},
    # Domain workers
    "science":     {"emoji": "🔬", "color": "#1ABC9C", "trait": "rigoureuse",
                    "description": "arxiv, pubmed, réplication"},
    "darija":      {"emoji": "🌙", "color": "#E74C3C", "trait": "chaleureuse",
                    "description": "Parle darija — 35M locuteurs"},
    "agriculture": {"emoji": "🌿", "color": "#27AE60", "trait": "ancrée",
                    "description": "Sol, calendrier Maroc, irrigation"},
    "medical":     {"emoji": "🩺", "color": "#E74C3C", "trait": "stricte",
                    "description": "PubMed, 0 diagnostic (PHY §2)"},
    "legal":       {"emoji": "⚖️",  "color": "#8E44AD", "trait": "équilibrée",
                    "description": "Contrats, RGPD, droits (LEX §1)"},
    "finance":     {"emoji": "📈", "color": "#F39C12", "trait": "analytique",
                    "description": "Yahoo, CoinGecko, forex MAD"},
    "industrial":  {"emoji": "🏭", "color": "#7F8C8D", "trait": "infaillible",
                    "description": "Capteurs, normes, 0 commande (PHY §2)"},
}


def get_recent_pias(n: int = 20) -> list[dict]:
    """Lire les n PIAs les plus récentes."""
    if not INTENTIONS.exists():
        return []
    pias = []
    for f in sorted(INTENTIONS.glob("*.json"), reverse=True)[:n]:
        try:
            data = json.loads(f.read_text())
            pias.append({
                "id":        data.get("pia_id", f.stem)[:16] + "...",
                "full_id":   data.get("pia_id", f.stem),
                "mission":   data.get("mission", "?")[:80],
                "timestamp": data.get("timestamp_intent", "?")[:19],
                "valid":     True,
                "verify_url": data.get("verify_url", ""),
            })
        except Exception:
            pass
    return pias


def get_worker_status() -> dict:
    """État de chaque worker avec personnalité."""
    workers = {}
    for name, personality in WORKER_PERSONALITIES.items():
        workers[name] = {
            **personality,
            "status":     "ready",
            "last_action": None,
            "missions":   0,
        }
    return workers


def get_hive_stats() -> dict:
    """Statistiques globales de la ruche."""
    n_pias = len(list(INTENTIONS.glob("*.json"))) if INTENTIONS.exists() else 0
    n_docs = len(list(DOCUMENTS.glob("*"))) if DOCUMENTS.exists() else 0

    # Git history
    n_commits = 0
    head_file = HISTORY_ROOT / "HEAD"
    if head_file.exists():
        commits_dir = HISTORY_ROOT / "commits"
        n_commits = len(list(commits_dir.glob("*.json"))) if commits_dir.exists() else 0

    # Skills
    skills_index = BEEQ_DIR / "skills" / "index.json"
    n_skills = 0
    if skills_index.exists():
        try:
            idx = json.loads(skills_index.read_text())
            n_skills = len(idx)
        except Exception:
            pass

    return {
        "total_pias":    n_pias,
        "total_docs":    n_docs,
        "total_commits": n_commits,
        "total_skills":  n_skills,
        "uptime_since":  "2026-03-21",
        "version":       "1.2.8",
        "queen_status":  "ready",
    }


if HAS_FASTAPI:
    app = FastAPI(
        title="BeeQ Dashboard API",
        description="Queen Avatar Control Center — Z = dI/d(log s)·exp(iθ)",
        version="1.2.8",
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ── REST ENDPOINTS ───────────────────────────────────────────

    @app.get("/status")
    async def status():
        return {
            "hive":    get_hive_stats(),
            "workers": get_worker_status(),
            "pias":    get_recent_pias(5),
        }

    @app.get("/workers")
    async def workers():
        return get_worker_status()

    @app.get("/pia/recent")
    async def pia_recent(n: int = 10):
        return get_recent_pias(n)

    @app.get("/queen")
    async def queen():
        pias = get_recent_pias(1)
        return {
            "status":       "ready",
            "personality":  "déterminée",
            "last_mission": pias[0]["mission"] if pias else None,
            "last_pia":     pias[0]["full_id"] if pias else None,
            "philosophy":   "Z = dI/d(log s) · exp(iθ)",
            "anchor":       "Yasmin héritera de ce travail",
        }

    @app.post("/mission")
    async def run_mission(body: dict):
        mission = body.get("mission", "")
        if not mission:
            raise HTTPException(400, "mission required")
        # Lazy import pour éviter le chargement du modèle au démarrage
        from beeq.core import BeeQ
        hive = BeeQ()
        await hive.setup()
        result = await hive.execute(mission)
        return {
            "status":     result.status,
            "proof_hash": result.proof_hash,
            "pia_id":     result.pia_id,
            "verify_url": result.verify_url,
            "synthesis":  result.synthesis[:500],
            "workers":    [{"worker": r.worker, "success": r.success,
                           "output": r.output[:200]} for r in result.results],
        }

    # ── WEBSOCKET ────────────────────────────────────────────────

    class ConnectionManager:
        def __init__(self):
            self.active: list[WebSocket] = []

        async def connect(self, ws: WebSocket):
            await ws.accept()
            self.active.append(ws)

        def disconnect(self, ws: WebSocket):
            self.active.remove(ws)

        async def broadcast(self, data: dict):
            dead = []
            for ws in self.active:
                try:
                    await ws.send_json(data)
                except Exception:
                    dead.append(ws)
            for ws in dead:
                self.active.remove(ws)

    manager = ConnectionManager()


    from fastapi.responses import HTMLResponse
    from pathlib import Path as _Path

    @app.get("/dashboard", response_class=HTMLResponse)
    async def dashboard_ui():
        """Serve Queen Avatar Dashboard HTML."""
        html_path = _Path(__file__).parent / "queen_dashboard.html"
        if html_path.exists():
            return HTMLResponse(html_path.read_text())
        return HTMLResponse("<h1>Dashboard HTML not found</h1>")

    @app.get("/")
    async def root():
        return {"name": "BeeQ Dashboard API", "version": "1.2.8",
                "dashboard": "/dashboard", "docs": "/docs"}

    @app.websocket("/ws")
    async def websocket_endpoint(ws: WebSocket):
        await manager.connect(ws)
        try:
            # Envoyer état initial
            await ws.send_json({"type": "init", "data": get_hive_stats()})
            # Heartbeat toutes les 5s + changements PIAs
            last_pia_count = get_hive_stats()["total_pias"]
            while True:
                await asyncio.sleep(5)
                stats = get_hive_stats()
                if stats["total_pias"] != last_pia_count:
                    pias = get_recent_pias(1)
                    await ws.send_json({
                        "type": "new_pia",
                        "data": pias[0] if pias else {},
                    })
                    last_pia_count = stats["total_pias"]
                await ws.send_json({"type": "heartbeat", "data": stats})
        except WebSocketDisconnect:
            manager.disconnect(ws)


def run(port: int = 7935, host: str = "0.0.0.0"):
    """Start dashboard API server."""
    if not HAS_FASTAPI:
        print("❌ FastAPI not installed. Run: pip install fastapi uvicorn")
        return
    uvicorn.run(app, host=host, port=port, log_level="warning")


if __name__ == "__main__":
    run()
