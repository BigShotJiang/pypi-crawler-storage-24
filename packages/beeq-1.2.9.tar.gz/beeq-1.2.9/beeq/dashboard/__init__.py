"""BeeQ Dashboard — Queen Avatar Control Center."""
