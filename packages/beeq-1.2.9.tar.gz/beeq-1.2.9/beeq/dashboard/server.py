"""
BeeQ Dashboard — localhost:7935

Real-time hive supervision.
Every action visible. Audit chain live. Revoke in 1 click.
The WOW line: "47 actions · 47 signatures · Chain: INTACT"
"""

import json
import asyncio
import hashlib
from pathlib import Path
from datetime import datetime

HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>BeeQ — Your Hive</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap');

  :root{
    --bg:#07050A;--bg2:#0E0B14;--bg3:#16121E;
    --gold:#F0A020;--gold2:#FFB84D;--gold3:#FFD580;
    --text:#EAE0CC;--text2:#B8AA95;--text3:#7A6F62;
    --green:#2EA043;--red:#F85149;--border:rgba(240,160,32,0.13);
    --mono:'JetBrains Mono',monospace;--sans:'Plus Jakarta Sans',sans-serif;
  }
  *{margin:0;padding:0;box-sizing:border-box}
  body{background:var(--bg);color:var(--text);font-family:var(--sans);min-height:100vh;overflow-x:hidden}

  /* ── HEADER ── */
  .header{
    padding:16px 28px;border-bottom:1px solid var(--border);
    display:flex;align-items:center;gap:16px;
    background:rgba(7,5,10,0.8);backdrop-filter:blur(12px);
    position:sticky;top:0;z-index:100;
  }
  .logo{font-size:20px;font-weight:800;color:var(--gold);letter-spacing:-0.5px}
  .logo span{color:var(--text);font-weight:400}
  .header-right{margin-left:auto;display:flex;align-items:center;gap:12px}
  .dot{width:8px;height:8px;border-radius:50%;background:var(--green);box-shadow:0 0 8px var(--green);animation:pulse 2s infinite}
  @keyframes pulse{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.4;transform:scale(.7)}}
  .status-text{font-family:var(--mono);font-size:11px;color:var(--text3)}

  /* ── WOW LINE ── */
  .wow-bar{
    background:linear-gradient(90deg,rgba(240,160,32,0.08),rgba(240,160,32,0.04));
    border-bottom:1px solid var(--border);
    padding:14px 28px;
    display:flex;align-items:center;gap:20px;flex-wrap:wrap;
  }
  .wow-stat{display:flex;flex-direction:column;gap:2px}
  .wow-n{font-size:28px;font-weight:800;color:var(--gold);letter-spacing:-1.5px;line-height:1}
  .wow-l{font-family:var(--mono);font-size:10px;color:var(--text3);letter-spacing:0.5px}
  .wow-sep{width:1px;height:36px;background:var(--border)}
  .chain-badge{
    margin-left:auto;display:flex;align-items:center;gap:8px;
    font-family:var(--mono);font-size:12px;
    background:rgba(46,160,67,0.1);border:1px solid rgba(46,160,67,0.3);
    padding:6px 14px;border-radius:8px;color:var(--green);
    cursor:pointer;text-decoration:none;transition:all 0.2s;
  }
  .chain-badge:hover{background:rgba(46,160,67,0.18);border-color:rgba(46,160,67,0.5);text-decoration:none;color:var(--green)}
  .chain-badge.error{background:rgba(248,81,73,0.1);border-color:rgba(248,81,73,0.3);color:var(--red)}

  /* ── GRID ── */
  .grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;padding:20px 28px}

  /* ── PANELS ── */
  .panel{background:var(--bg2);border:1px solid var(--border);border-radius:14px;overflow:hidden}
  .panel-header{
    padding:14px 18px;border-bottom:1px solid var(--border);
    display:flex;align-items:center;justify-content:space-between;
  }
  .panel-title{font-size:13px;font-weight:700;color:var(--text);letter-spacing:0.2px}
  .panel-tag{font-family:var(--mono);font-size:10px;color:var(--text3)}
  .panel-body{padding:16px 18px}

  /* ── MISSION INPUT ── */
  .mission-panel{grid-column:1/-1}
  .mission-form{display:flex;gap:10px}
  .mission-input{
    flex:1;background:var(--bg3);border:1px solid var(--border);
    border-radius:10px;padding:12px 16px;
    font-family:var(--sans);font-size:14px;color:var(--text);
    outline:none;transition:border-color 0.2s;
  }
  .mission-input:focus{border-color:rgba(240,160,32,0.4)}
  .mission-input::placeholder{color:var(--text3)}
  .btn-send{
    background:var(--gold);color:#0A0604;border:none;border-radius:10px;
    padding:12px 20px;font-family:var(--sans);font-size:14px;font-weight:700;
    cursor:pointer;transition:all 0.2s;white-space:nowrap;
  }
  .btn-send:hover{background:var(--gold2);transform:translateY(-1px)}
  .btn-send:disabled{opacity:0.5;cursor:not-allowed;transform:none}

  /* ── WORKERS ── */
  .workers-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}
  .worker-card{
    background:var(--bg3);border:1px solid var(--border);border-radius:10px;
    padding:12px;display:flex;flex-direction:column;gap:6px;transition:all 0.2s;
  }
  .worker-card.active{border-color:var(--gold);background:rgba(240,160,32,0.06)}
  .worker-card.revoked{border-color:var(--red);opacity:0.5}
  .worker-header{display:flex;align-items:center;justify-content:space-between}
  .worker-name{font-size:13px;font-weight:700;color:var(--text)}
  .worker-status{font-family:var(--mono);font-size:10px;padding:2px 7px;border-radius:99px}
  .worker-status.ok{background:rgba(46,160,67,0.15);color:var(--green)}
  .worker-status.busy{background:rgba(240,160,32,0.15);color:var(--gold)}
  .worker-status.revoked{background:rgba(248,81,73,0.15);color:var(--red)}
  .worker-scope{font-family:var(--mono);font-size:10px;color:var(--text3);line-height:1.5}
  .worker-id{font-family:var(--mono);font-size:9px;color:var(--text3)}
  .revoke-btn{
    background:transparent;border:1px solid rgba(248,81,73,0.3);border-radius:6px;
    color:var(--red);font-size:10px;padding:3px 8px;cursor:pointer;
    font-family:var(--mono);transition:all 0.2s;margin-top:2px;
  }
  .revoke-btn:hover{background:rgba(248,81,73,0.1);border-color:var(--red)}

  /* ── AUDIT FEED ── */
  .audit-feed{display:flex;flex-direction:column;gap:8px;max-height:340px;overflow-y:auto}
  .audit-feed::-webkit-scrollbar{width:4px}
  .audit-feed::-webkit-scrollbar-track{background:transparent}
  .audit-feed::-webkit-scrollbar-thumb{background:var(--border);border-radius:4px}

  .audit-entry{
    background:var(--bg3);border:1px solid var(--border);border-radius:8px;
    padding:10px 12px;display:flex;flex-direction:column;gap:4px;
  }
  .audit-entry.success{border-left:3px solid var(--green)}
  .audit-entry.failure{border-left:3px solid var(--red)}
  .audit-entry.blocked{border-left:3px solid orange}
  .audit-top{display:flex;align-items:center;justify-content:space-between}
  .audit-worker{font-size:12px;font-weight:700;color:var(--text)}
  .audit-action{font-family:var(--mono);font-size:11px;color:var(--gold)}
  .audit-time{font-family:var(--mono);font-size:10px;color:var(--text3)}
  .audit-hash{font-family:var(--mono);font-size:10px;color:var(--text3);word-break:break-all}
  .audit-verify{font-family:var(--mono);font-size:10px;color:var(--gold);text-decoration:none}
  .audit-verify:hover{text-decoration:underline}

  /* ── MISSION OUTPUT ── */
  .mission-output{
    background:var(--bg3);border:1px solid var(--border);border-radius:10px;
    padding:14px;font-family:var(--mono);font-size:12px;line-height:1.7;
    color:var(--text2);min-height:80px;max-height:300px;overflow-y:auto;
    white-space:pre-wrap;word-break:break-word;
  }
  .mission-output.empty{color:var(--text3);font-style:italic}

  /* ── INTENTION ── */
  .intention-box{
    background:rgba(240,160,32,0.04);border:1px solid var(--border);
    border-radius:8px;padding:12px;
    font-family:var(--mono);font-size:11px;line-height:1.7;color:var(--text2);
    min-height:60px;max-height:200px;overflow-y:auto;
  }
  .intention-box.empty{color:var(--text3);font-style:italic}
  .intention-label{font-size:11px;font-weight:700;color:var(--gold);margin-bottom:6px}

  .empty-state{color:var(--text3);font-family:var(--mono);font-size:12px;padding:16px 0;text-align:center}

  @media(max-width:800px){
    .grid{grid-template-columns:1fr}
    .workers-grid{grid-template-columns:repeat(2,1fr)}
    .wow-bar{gap:12px}
  }
</style>
</head>
<body>

<div class="header">
  <div class="logo">Bee<span>Q</span> &nbsp;🐝</div>
  <div style="font-family:var(--mono);font-size:11px;color:var(--text3)">Your Hive · localhost:7935</div>
  <div class="header-right">
    <div class="dot"></div>
    <div class="status-text" id="hive-status">Hive ready</div>
  </div>
</div>

<!-- WOW BAR -->
<div class="wow-bar">
  <div class="wow-stat">
    <div class="wow-n" id="wow-actions">0</div>
    <div class="wow-l">Actions</div>
  </div>
  <div class="wow-sep"></div>
  <div class="wow-stat">
    <div class="wow-n" id="wow-sigs">0</div>
    <div class="wow-l">Signatures</div>
  </div>
  <div class="wow-sep"></div>
  <div class="wow-stat">
    <div class="wow-n" id="wow-workers">0</div>
    <div class="wow-l">Workers</div>
  </div>
  <div class="wow-sep"></div>
  <div class="wow-stat">
    <div class="wow-n" id="wow-missions">0</div>
    <div class="wow-l">Missions</div>
  </div>
  <a href="#" id="chain-badge" class="chain-badge" target="_blank">
    ✅ Chain: INTACT
  </a>
</div>

<div class="grid">

  <!-- MISSION INPUT -->
  <div class="panel mission-panel">
    <div class="panel-header">
      <div class="panel-title">Mission</div>
      <div class="panel-tag">Give the Queen a mission in natural language</div>
    </div>
    <div class="panel-body" style="display:flex;flex-direction:column;gap:12px">
      <div class="mission-form">
        <input class="mission-input" id="mission-input"
               placeholder="Research the latest AI papers and write a summary..."
               onkeydown="if(event.key==='Enter')sendMission()">
        <button class="btn-send" id="send-btn" onclick="sendMission()">
          Deploy Queen →
        </button>
      </div>

      <!-- Preuve d'Intention Antérieure -->
      <div>
        <div class="intention-label">⚡ Preuve d'Intention Antérieure</div>
        <div class="intention-box empty" id="intention-box">
          The Queen's signed reasoning will appear here BEFORE she acts.
        </div>
      </div>

      <!-- Output -->
      <div class="mission-output empty" id="mission-output">
        Results will appear here...
      </div>
    </div>
  </div>

  <!-- WORKERS -->
  <div class="panel">
    <div class="panel-header">
      <div class="panel-title">Workers</div>
      <div class="panel-tag" id="workers-count">6 registered</div>
    </div>
    <div class="panel-body">
      <div class="workers-grid" id="workers-grid">
        <div class="empty-state">Loading workers...</div>
      </div>
    </div>
  </div>

  <!-- AUDIT CHAIN FEED -->
  <div class="panel">
    <div class="panel-header">
      <div class="panel-title">Audit Chain</div>
      <div class="panel-tag">Every action · Every signature · Forever</div>
    </div>
    <div class="panel-body">
      <div class="audit-feed" id="audit-feed">
        <div class="empty-state">No actions yet. Give a mission to the Queen.</div>
      </div>
    </div>
  </div>

</div>

<script>
const API = '';  // same origin
let missionCount = 0;
let state = { actions:0, sigs:0, workers:0, missions:0, chain_intact:true, chain_hash:'', workers_list:[] };

// ── INIT ──────────────────────────────────────────────────────
async function init() {
  await refresh();
  setInterval(refresh, 3000);
}

async function refresh() {
  try {
    const r = await fetch('/api/status');
    if (!r.ok) return;
    const d = await r.json();
    state = d;
    updateWowBar();
    updateWorkers();
    updateAuditFeed();
  } catch(e) { /* server not yet ready */ }
}

// ── WOW BAR ──────────────────────────────────────────────────
function updateWowBar() {
  document.getElementById('wow-actions').textContent = state.actions;
  document.getElementById('wow-sigs').textContent    = state.actions; // each action = 1 sig
  document.getElementById('wow-workers').textContent = state.workers_count || state.workers_list.length;
  document.getElementById('wow-missions').textContent = state.missions;

  const badge = document.getElementById('chain-badge');
  if (state.chain_intact) {
    badge.className = 'chain-badge';
    badge.textContent = '✅ Chain: INTACT';
    const h = (state.chain_hash||'').slice(0,12);
    if (h) {
      badge.textContent = `✅ Chain: INTACT · ${h}...`;
      badge.href = `https://beeq.run/verify/${state.chain_hash}`;
    }
  } else {
    badge.className = 'chain-badge error';
    badge.textContent = '⚠️ Chain: ERROR';
  }
}

// ── WORKERS ──────────────────────────────────────────────────
function updateWorkers() {
  const grid = document.getElementById('workers-grid');
  const ws   = state.workers_list || [];
  if (!ws.length) return;
  document.getElementById('workers-count').textContent = ws.length + ' registered';
  grid.innerHTML = ws.map(w => `
    <div class="worker-card ${w.revoked?'revoked':''}" id="wc-${w.name}">
      <div class="worker-header">
        <div class="worker-name">${ICONS[w.name]||'🤖'} ${w.name}</div>
        <div class="worker-status ${w.revoked?'revoked':'ok'}">${w.revoked?'revoked':'active'}</div>
      </div>
      <div class="worker-scope">${(w.scope||[]).join('<br>')}</div>
      <div class="worker-id">${(w.id||'').slice(0,32)}...</div>
      ${!w.revoked?`<button class="revoke-btn" onclick="revokeWorker('${w.name}')">Revoke</button>`:''}
    </div>
  `).join('');
}

const ICONS = {research:'🔍',code:'💻',write:'✍️',ops:'⚙️',memory:'🧠',hardware:'🤖'};

async function revokeWorker(name) {
  if (!confirm(`Revoke worker "${name}"? This cannot be undone.`)) return;
  await fetch('/api/revoke', {method:'POST', headers:{'Content-Type':'application/json'},
                              body: JSON.stringify({worker: name})});
  await refresh();
}

// ── AUDIT FEED ────────────────────────────────────────────────
function updateAuditFeed() {
  const feed = document.getElementById('audit-feed');
  const entries = state.audit_entries || [];
  if (!entries.length) return;

  feed.innerHTML = entries.slice().reverse().map(e => `
    <div class="audit-entry ${e.result||'success'}">
      <div class="audit-top">
        <span class="audit-worker">${ICONS[e.worker]||'🤖'} ${e.worker||''}</span>
        <span class="audit-action">${e.action||''}</span>
        <span class="audit-time">${fmtTime(e.timestamp)}</span>
      </div>
      ${e.hash?`<div class="audit-hash">
        # ${e.hash.slice(0,32)}...
        <a href="https://beeq.run/verify/${e.hash}" class="audit-verify" target="_blank">verify →</a>
      </div>`:''}
    </div>
  `).join('');
}

function fmtTime(ts) {
  if (!ts) return '';
  try { return new Date(ts).toLocaleTimeString(); } catch(e) { return ts; }
}

// ── MISSION ──────────────────────────────────────────────────
async function sendMission() {
  const input = document.getElementById('mission-input');
  const text  = input.value.trim();
  if (!text) return;

  const btn = document.getElementById('send-btn');
  btn.disabled = true;
  btn.textContent = 'Queen thinking...';

  document.getElementById('hive-status').textContent = 'Queen orchestrating...';
  document.getElementById('mission-output').textContent = '⏳ Queen is decomposing the mission...';
  document.getElementById('mission-output').className = 'mission-output';
  document.getElementById('intention-box').textContent = '⏳ Signing intention...';
  document.getElementById('intention-box').className   = 'intention-box';

  try {
    const r = await fetch('/api/mission', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({mission: text}),
    });
    const d = await r.json();

    // Intention
    if (d.intention) {
      document.getElementById('intention-box').textContent = d.intention;
    }

    // Output
    const outputs = (d.results||[]).map(r => `[${r.worker}]\n${r.output}`).join('\n\n───\n\n');
    document.getElementById('mission-output').textContent = outputs || d.error || 'No output.';

    missionCount++;
    input.value = '';
    document.getElementById('hive-status').textContent = `Mission ${missionCount} complete`;
  } catch(e) {
    document.getElementById('mission-output').textContent = 'Error: ' + e.message;
  } finally {
    btn.disabled = false;
    btn.textContent = 'Deploy Queen →';
    await refresh();
  }
}

init();
</script>
</body>
</html>
"""


class DashboardServer:
    """BeeQ Dashboard — FastAPI server on port 7935."""

    def __init__(self, hive=None):
        self.hive = hive

    def get_status(self) -> dict:
        """Current hive status for the WOW bar."""
        if not self.hive:
            return self._empty_status()

        audit = self.hive.audit()
        gov   = self.hive.governance

        # Collect audit entries with hashes
        entries = []
        for e in list(gov.audit_entries)[-50:]:  # last 50
            h = hashlib.sha256(
                f"{e.agent_id}{e.action}{e.timestamp}".encode()
            ).hexdigest()
            entries.append({
                "worker":    e.agent_id.split("/")[-1].split("@")[0] if e.agent_id else "",
                "action":    e.action,
                "result":    e.result,
                "timestamp": e.timestamp.isoformat() if hasattr(e.timestamp, "isoformat") else str(e.timestamp),
                "hash":      h,
            })

        # Workers list
        workers_list = []
        for name, w in gov.workers.items():
            workers_list.append({
                "name":    name,
                "scope":   list(w.identity.scope),
                "id":      w.identity.id,
                "revoked": w.identity.revoked or not w.authorization.is_valid(),
            })

        chain_hash = hashlib.sha256(
            json.dumps(entries).encode()
        ).hexdigest() if entries else ""

        return {
            "actions":       audit["actions"],
            "chain_intact":  audit["valid"],
            "chain_hash":    chain_hash,
            "workers_count": len(audit["workers"]),
            "workers_list":  workers_list,
            "audit_entries": entries,
            "missions":      getattr(self.hive, "_mission_count", 0),
        }

    def _empty_status(self) -> dict:
        return {"actions":0,"chain_intact":True,"chain_hash":"",
                "workers_count":0,"workers_list":[],"audit_entries":[],"missions":0}


def create_app(hive=None):
    """Create FastAPI app for the BeeQ dashboard."""
    try:
        from fastapi import FastAPI
        from fastapi.responses import HTMLResponse, JSONResponse
        from fastapi.middleware.cors import CORSMiddleware
        import uvicorn
    except ImportError:
        raise ImportError("pip install fastapi uvicorn")

    app = FastAPI(title="BeeQ Dashboard", version="1.0.0")
    app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
    server = DashboardServer(hive)

    @app.get("/", response_class=HTMLResponse)
    async def root():
        return HTMLResponse(HTML)

    @app.get("/api/status")
    async def status():
        return JSONResponse(server.get_status())

    @app.post("/api/mission")
    async def mission(req: dict):
        if not hive:
            return JSONResponse({"error": "Hive not initialized"}, status_code=503)
        text = req.get("mission", "")
        if not text:
            return JSONResponse({"error": "Empty mission"}, status_code=400)

        # Sign intention BEFORE acting (Preuve d'Intention Antérieure)
        intention_text = await _sign_intention(hive, text)

        m = await hive.execute(text)
        if not hasattr(hive, "_mission_count"):
            hive._mission_count = 0
        hive._mission_count += 1

        results = [
            {"worker": r.worker, "output": r.output, "success": r.success}
            for r in m.results
        ]
        return JSONResponse({
            "status":    m.status,
            "intention": intention_text,
            "results":   results,
        })

    @app.post("/api/revoke")
    async def revoke(req: dict):
        if not hive:
            return JSONResponse({"error": "Hive not initialized"}, status_code=503)
        worker = req.get("worker", "")
        hive.governance.revoke_worker(worker)
        return JSONResponse({"revoked": worker})


    @app.get("/verify/{pia_id}")
    @app.get("/api/pia/{pia_id}")
    async def verify_pia(pia_id: str):
        """
        Verify a Prior Intent Proof — Feature 1 of BeeQ.
        Public endpoint. No auth required.
        This is what beeq.run/verify/<hash> returns.
        """
        from beeq.intention import IntentionEngine
        from fastapi.responses import HTMLResponse
        engine = IntentionEngine()
        result = engine.verify(pia_id)
        # Check Accept header for HTML vs JSON
        return JSONResponse(result)

    @app.get("/api/verify/{hash_id}")
    async def verify_action(hash_id: str):
        """Verify a specific action hash from the audit chain."""
        if not hive:
            return JSONResponse({"found": False, "error": "Hive not initialized"})
        
        gov = hive.governance
        for e in gov.audit_entries:
            import hashlib
            ts = e.timestamp.isoformat() if hasattr(e.timestamp, "isoformat") else str(e.timestamp)
            agent = e.agent_id or ""
            h = hashlib.sha256(f"{agent}{e.action}{ts}".encode()).hexdigest()
            if h.startswith(hash_id) or h == hash_id:
                worker_name = agent.split("/")[-1].split("@")[0] if agent else ""
                return JSONResponse({
                    "found":     True,
                    "hash":      h,
                    "worker":    worker_name,
                    "action":    e.action,
                    "result":    e.result,
                    "timestamp": ts,
                    "hive":      "local",
                    "chain_valid": hive.audit()["valid"],
                })
        return JSONResponse({"found": False, "hash": hash_id})

    return app, uvicorn


async def _sign_intention(hive, mission: str) -> str:
    """
    Preuve d'Intention Antérieure.
    Ask the Queen to state her reasoning plan BEFORE acting.
    This is signed and timestamped — proof she reasoned correctly first.
    """
    ts = datetime.utcnow().isoformat() + "Z"
    try:
        response = await hive.providers.complete(
            messages=[{"role": "user", "content": mission}],
            system=(
                "You are the Queen of a BeeQ hive. Before acting on this mission, "
                "state your intention plan in 2-4 sentences: what you understand, "
                "which workers you will use, and what the human will receive. "
                "Be concise and precise. This statement will be signed and timestamped "
                "as proof of your reasoning before you act."
            ),
            max_tokens=256,
        )
        intention = response.content
    except Exception:
        intention = f"[Intention signing — {ts}]\nMission: {mission}"

    sig = hashlib.sha256(f"{intention}{ts}".encode()).hexdigest()[:16]
    return f"[Signed {ts} · #{sig}]\n\n{intention}"


def run(hive=None, port: int = 7935):
    """Start the dashboard server."""
    app, uvicorn = create_app(hive)
    uvicorn.run(app, host="0.0.0.0", port=port, log_level="error")
