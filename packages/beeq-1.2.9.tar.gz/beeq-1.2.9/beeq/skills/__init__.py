"""BeeQ Skills — installable, signed, verified extensions."""
from .manager import SkillManager, Skill
