"""
BeeQ Skills — L'App Store de la civilisation artificielle.

Un Skill est une compétence installable dans BeeQ :
  - Instructions spécialisées pour la Queen
  - Workers additionnels pour un domaine
  - Outils MCP spécifiques
  - Signé AAP par l'auteur
  - Vérifiable par quiconque

Format .skill.md:
  ---
  name: labo-z
  author: ElmadaniS
  version: 1.0.0
  description: Compétences recherche LABO_Z pour BeeQ
  scope: [read:files, exec:code, search:web]
  signature: sha256:<hash>
  ---

  ## Instructions Queen
  Tu as accès aux outils de recherche LABO_Z...

  ## Workers additionnels
  ...

  ## MCP Tools
  ...

Installation:
  beeq hub install mehdi/labo-z
  beeq hub install ./my-skill.skill.md
  beeq hub install https://hub.beeq.run/skills/farmer

Vérification:
  beeq hub verify mehdi/labo-z
  beeq hub list

Z = dI/d(log s) · exp(iθ)
  Un skill = dI maximal pour un domaine spécifique
  θ = 0 parce que la signature prouve l'authenticité
"""

import hashlib
import json
import re
import urllib.request
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

SKILLS_DIR  = Path.home() / ".beeq" / "skills"
SKILLS_INDEX = SKILLS_DIR / "index.json"

# Hub officiel BeeQ (futur)
HUB_BASE = "https://hub.beeq.run/skills"


@dataclass
class SkillMetadata:
    name:        str
    author:      str
    version:     str
    description: str
    scope:       list[str]     = field(default_factory=list)
    signature:   str           = ""
    installed_at: str          = ""
    source:      str           = ""   # URL or path of origin
    verified:    bool          = False


@dataclass
class Skill:
    metadata:     SkillMetadata
    instructions: str   = ""   # Queen system prompt additions
    raw:          str   = ""   # Full .skill.md content

    @property
    def name(self) -> str:
        return self.metadata.name

    def system_prompt_addition(self) -> str:
        """Return the text to inject into the Queen's system prompt."""
        if not self.instructions:
            return ""
        return (
            f"\n\n## Skill: {self.metadata.name} v{self.metadata.version}\n"
            f"{self.instructions}"
        )

    def verify(self) -> bool:
        """Verify the skill's signature."""
        if not self.metadata.signature:
            return False
        if self.metadata.signature.startswith("sha256:"):
            # Compute hash of (name + author + version + instructions)
            content = f"{self.metadata.name}{self.metadata.author}{self.metadata.version}{self.instructions}"
            expected = f"sha256:{hashlib.sha256(content.encode()).hexdigest()}"
            return expected == self.metadata.signature
        return False


class SkillManager:
    """
    Manages BeeQ Skills — install, verify, list, remove.

    Skills are stored in ~/.beeq/skills/<name>/
      skill.md         — the skill file
      metadata.json    — parsed metadata
    """

    def __init__(self):
        SKILLS_DIR.mkdir(parents=True, exist_ok=True)

    def install(self, source: str) -> Skill:
        """
        Install a skill from:
          - local path: ./my-skill.skill.md
          - hub shorthand: mehdi/labo-z
          - full URL: https://...
        """
        content = self._fetch(source)
        skill   = self._parse(content)
        skill.metadata.installed_at = datetime.now(timezone.utc).isoformat()
        skill.metadata.source = source

        # Store
        skill_dir = SKILLS_DIR / skill.metadata.name
        skill_dir.mkdir(parents=True, exist_ok=True)
        (skill_dir / "skill.md").write_text(content, encoding="utf-8")
        (skill_dir / "metadata.json").write_text(
            json.dumps(asdict(skill.metadata), indent=2), encoding="utf-8"
        )

        # Update index
        self._update_index(skill.metadata)

        return skill

    def install_from_content(self, content: str, source: str = "inline") -> Skill:
        """Install a skill directly from its content string."""
        skill = self._parse(content)
        skill.metadata.installed_at = datetime.now(timezone.utc).isoformat()
        skill.metadata.source = source
        skill_dir = SKILLS_DIR / skill.metadata.name
        skill_dir.mkdir(parents=True, exist_ok=True)
        (skill_dir / "skill.md").write_text(content, encoding="utf-8")
        (skill_dir / "metadata.json").write_text(
            json.dumps(asdict(skill.metadata), indent=2), encoding="utf-8"
        )
        self._update_index(skill.metadata)
        return skill

    def verify(self, name: str) -> dict:
        """Verify a skill's signature."""
        skill = self.get(name)
        if not skill:
            return {"valid": False, "error": "Skill not found"}
        verified = skill.verify()
        skill.metadata.verified = verified
        return {
            "valid": verified,
            "name": skill.metadata.name,
            "author": skill.metadata.author,
            "version": skill.metadata.version,
            "signature": skill.metadata.signature,
            "message": (
                f"✅ Skill '{name}' by {skill.metadata.author} — signature valid."
                if verified else
                f"⚠️  Skill '{name}' — no valid signature (unsigned or tampered)."
            )
        }

    def get(self, name: str) -> Optional[Skill]:
        """Load an installed skill by name."""
        skill_dir = SKILLS_DIR / name
        skill_file = skill_dir / "skill.md"
        if not skill_file.exists():
            return None
        content = skill_file.read_text(encoding="utf-8")
        return self._parse(content)

    def list_installed(self) -> list[SkillMetadata]:
        """List all installed skills."""
        skills = []
        for d in SKILLS_DIR.iterdir():
            if d.is_dir() and (d / "metadata.json").exists():
                try:
                    data = json.loads((d / "metadata.json").read_text())
                    skills.append(SkillMetadata(**data))
                except Exception:
                    pass
        return sorted(skills, key=lambda s: s.name)

    def remove(self, name: str) -> bool:
        """Remove an installed skill."""
        import shutil
        skill_dir = SKILLS_DIR / name
        if not skill_dir.exists():
            return False
        shutil.rmtree(skill_dir)
        self._remove_from_index(name)
        return True

    def get_all_instructions(self) -> str:
        """Get combined system prompt additions from all installed skills."""
        parts = []
        for meta in self.list_installed():
            skill = self.get(meta.name)
            if skill:
                addition = skill.system_prompt_addition()
                if addition:
                    parts.append(addition)
        return "\n".join(parts)

    def sign(self, name: str, author: str, version: str, instructions: str) -> str:
        """Generate a skill signature (for skill authors)."""
        content = f"{name}{author}{version}{instructions}"
        return f"sha256:{hashlib.sha256(content.encode()).hexdigest()}"

    # ── INTERNAL ──────────────────────────────────────────────────

    def _fetch(self, source: str) -> str:
        """Fetch skill content from various sources."""
        # Local file
        if source.startswith("./") or source.startswith("/") or source.endswith(".md"):
            return Path(source).expanduser().read_text(encoding="utf-8")

        # Hub shorthand: author/name
        if re.match(r"^[\w-]+/[\w-]+$", source):
            # Future: fetch from hub.beeq.run
            # For now: check if local file exists with that name
            local = SKILLS_DIR / source.split("/")[1] / "skill.md"
            if local.exists():
                return local.read_text(encoding="utf-8")
            raise FileNotFoundError(
                f"Skill '{source}' not found locally and hub not yet available. "
                f"Install manually: beeq hub install ./your-skill.skill.md"
            )

        # Full URL
        if source.startswith("http"):
            with urllib.request.urlopen(source, timeout=10) as r:
                return r.read().decode("utf-8")

        raise ValueError(f"Unknown skill source format: {source}")

    def _parse(self, content: str) -> Skill:
        """Parse a .skill.md file into a Skill object."""
        # Extract YAML front matter between --- delimiters
        meta: dict = {}
        instructions = content

        front_matter_match = re.match(
            r"^---\n(.*?)\n---\n?(.*)", content, re.DOTALL
        )
        if front_matter_match:
            yaml_block   = front_matter_match.group(1)
            instructions = front_matter_match.group(2).strip()

            # Simple YAML parser (no deps)
            for line in yaml_block.split("\n"):
                if ":" in line:
                    key, _, val = line.partition(":")
                    key = key.strip()
                    val = val.strip()
                    # Handle list values: [a, b, c]
                    if val.startswith("[") and val.endswith("]"):
                        val = [v.strip().strip('"\'') for v in val[1:-1].split(",") if v.strip()]
                    meta[key] = val

        # Extract ## Instructions section
        instr_match = re.search(r"## Instructions?(.*?)(?=##|$)", instructions, re.DOTALL)
        queen_instructions = instr_match.group(1).strip() if instr_match else instructions

        sm = SkillMetadata(
            name        = str(meta.get("name", "unnamed")),
            author      = str(meta.get("author", "unknown")),
            version     = str(meta.get("version", "0.1.0")),
            description = str(meta.get("description", "")),
            scope       = meta.get("scope", []) if isinstance(meta.get("scope"), list) else [],
            signature   = str(meta.get("signature", "")),
        )

        return Skill(metadata=sm, instructions=queen_instructions, raw=content)

    def _update_index(self, meta: SkillMetadata):
        index = self._load_index()
        index[meta.name] = {
            "name": meta.name,
            "author": meta.author,
            "version": meta.version,
            "description": meta.description,
            "installed_at": meta.installed_at,
        }
        SKILLS_INDEX.write_text(json.dumps(index, indent=2), encoding="utf-8")

    def _remove_from_index(self, name: str):
        index = self._load_index()
        index.pop(name, None)
        SKILLS_INDEX.write_text(json.dumps(index, indent=2), encoding="utf-8")

    def _load_index(self) -> dict:
        if SKILLS_INDEX.exists():
            try:
                return json.loads(SKILLS_INDEX.read_text())
            except Exception:
                pass
        return {}
