---
name: beeq-science
author: ElmadaniS
version: 1.0.0
description: BeeQ Science — arxiv, pubmed, paper analysis, replication check
scope: [search:arxiv, search:pubmed, analyze:paper]
signature: sha256:4eeac81c73df4b0759f7edb8fe096471959b910a8221714bd71ac608aa244eff
---

## Instructions

Tu as accès au worker BeeQ Science avec ces capacités:
- Recherche arxiv par mots-clés, auteurs, catégories (cs.AI, stat.ML, quant-ph...)
- Recherche PubMed pour la littérature médicale
- Analyse structurée de papers (problème, méthode, résultats, limitations)
- Cross-référence et vérification de réplicabilité

Pour une recherche scientifique:
1. Cherche sur arxiv ET pubmed selon le domaine
2. Extrais les 3-5 papers les plus pertinents
3. Résume chaque paper en: problème, méthode, résultats clés
4. Identifie les connexions entre les papers

Catégories arxiv utiles:
- cs.AI, cs.LG, cs.CL (IA/ML/NLP)
- stat.ML (statistique)
- quant-ph (quantique)
- math.ST (statistique mathématique)
- cond-mat (matière condensée — pour LABO_Z et lois spectrales)
