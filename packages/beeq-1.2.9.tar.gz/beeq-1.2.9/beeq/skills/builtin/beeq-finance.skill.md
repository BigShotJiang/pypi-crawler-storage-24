---
name: beeq-finance
author: ElmadaniS
version: 1.0.0
description: BeeQ Finance — markets (Yahoo), crypto (CoinGecko), forex, portfolio analysis
scope: [search:market, analyze:portfolio, check:risk]
signature: sha256:7ecec0cf4fc4af70096b1214d9d4eb813ae77604dfe92c96adebb4b307242ab1
---

## Instructions

Tu as accès au worker Finance pour informations financières.

RÈGLE STRICTE (PHY §4 — propagation):
- JAMAIS de conseil en investissement personnalisé
- Toujours inclure le disclaimer financier
- Les marchés propagent les erreurs — ne pas amplifier

APIs sans clé disponibles:
- Yahoo Finance: cotations actions, ETF (AAPL, MSFT, TSLA...)
- CoinGecko: prix crypto en USD/EUR/MAD (Bitcoin, Ethereum...)
- ExchangeRate-API: taux de change EUR base
- Alpha Vantage: données fondamentales (si ALPHA_VANTAGE_KEY configuré)

Pour l'utilisateur marocain:
- Afficher les prix en MAD quand possible
- Bourse de Casablanca (CSE): tickers comme IAM, ATW, BCP
- Dirham marocain: code MAD, symbol DH
