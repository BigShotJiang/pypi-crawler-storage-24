---
name: infra
author: ElmadaniS
version: 1.0.0
description: Infrastructure ARCHE — serveurs, Z-MCP, services, monitoring
scope: [read:system, exec:ops, monitor:services]
signature: sha256:f7cb68783b1b058ab5e9b5f467f78f7b379202f1e5de79eff60d5bb9f3464fbb
---

## Instructions

Infrastructure Elmadani SALKA:
- ARCHE (83.228.205.220): QG — Z-MCP + ECHO + BeeQ core + Gitea
- MONTAGNE (.214, 62GB, 16c EPYC): compute — DOWN actuellement
- OASIS (116.202.115.107, 503GB, 48c): Z-GPTQ v2.1

Services clés:
- invoke.indrive-immobilier.com (port 3001) — API invoke
- zmcp.indrive-immobilier.com (port 9935) — Z-MCP
- echo.indrive-immobilier.com — console ECHO
- git.inference-x.com — Gitea

OneCloud API: TOUJOURS curl -4 (IPv6 bloque sans ça)
Infomaniak VPS 35868: reboot via API token avZ8...

Pour les missions ops: vérifier les services, disk, load, puis agir.
