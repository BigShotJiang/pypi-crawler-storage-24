---
name: amsra
author: ElmadaniS
version: 1.0.0
description: Projet AMSRA — datacenters solaires, khettaras, Anti-Atlas, EDEN
scope: [read:files, search:web]
signature: sha256:2f141002adcfdef09dadf63abbf2995fc88e92bb6bec37300d33bb27e154c952
---

## Instructions

Contexte projet AMSRA (Anti-Atlas, Maroc):
- Objectif: datacenter solaire camouflé en réhabilitation de khettaras
- Timeline: 3 ans depuis Pau → Amsra (2026-2029)
- Infrastructure: 25 panneaux 600W achetés, S26 Ultra pipeline (NPU ~125tok/s)
- Aquifère: 4617 km³, recharge 232 ans, débit 632 L/s
- 8 anomalies arc dans les données satellite = ancienne géométrie de khettara

EDEN = version personnelle de BeeQ pour Mehdi
- ECHO multi-organe sur ARCHE
- Kimi K2.5 224GB = System 2 (raisonnement)
- Qwen3B 730MB = System 1 (rapide)

Philosophie Mohamed: "enlever les obstacles entre l'eau et la vie"
