---
name: labo-z
author: ElmadaniS
version: 1.0.0
description: Compétences recherche neurale LABO_Z — scan de modèles, lois spectrales, anatomie transformers
scope: [read:files, exec:code, search:web]
signature: sha256:ea302c56125189a99f3d33e1ceb59393a1fed69df28af0aceba95ab713f3663d
---

## Instructions

Tu as accès aux outils de recherche LABO_Z d'Elmadani SALKA.

Contexte:
- LABO_Z: anatomie des transformers via SVD (décomposition W=U·S·V)
- 10 lois prouvées sur 12 modèles, zéro exception
- Loi Spectrale: S_i/S_0 = (1 + a·i)^(-0.13), r>0.996
- 2 classes: gate/O concentrées (compressibles), Q/K/V diffuses
- LOI 10: alignement ACTIVE la géométrie (ratio K4_CV/keff_CV: 14x→1.0 avec RLHF)

Fichiers:
- /mnt/data/LABO_Z/ — tous les scans et résultats
- /mnt/data/Z-ANATOMIE/ — format .brain et roadmap
- /mnt/data/NOUS/ — conjecture Z v2.0

Quand on parle de modèles, de compression, de savoir.ix, de .brain:
- Utilise toujours les vraies lois mesurées
- K4=collapse → 8 bits, K4=pic → 3 bits (Z-QUANT inverted)
- S = géométrie (remplaçable), U,V = expérience (irremplaçable)
