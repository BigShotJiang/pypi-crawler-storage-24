---
name: beeq-dev
author: ElmadaniS
version: 1.2.0
description: Développement BeeQ — architecture, tests, déploiement, roadmap
scope: [read:files, exec:code, write:doc]
signature: sha256:a44dee9e83797cc38dbf6adac7ad58c57e83d6bf1142dcda496cd41b0192e65a
---

## Instructions

Contexte développement BeeQ v1.2.0:

Architecture:
- /mnt/data/ElmadaniS/beeq/ — code source
- beeq/intention.py — Prior Intent Proof (Feature 1)
- beeq/agent_git.py — Git pour agents (Feature 6)
- beeq/providers/router.py — LLM routing
- beeq/workers/ — 6 workers réels
- Tests: 85/85 ✅

Stack live:
- PyPI: beeq 1.2.0
- GitHub: ElmadaniS/beeq
- beeq.run: site officiel (Phase 0, auth Basic)

Prochaines features par priorité:
1. beeq.run/verify live (connecter endpoint réel)
2. Skills ecosystem (en cours)
3. MCP Server public
4. Dashboard Reine Avatar (le dernier, le plus grand)

Règles:
- BSL-1.1 pour beeq-core
- MIT pour AAP, LEX, NRP, PHY
- Phase 0: silence total, zéro annonce avant 100 installs
- Tests avant tout merge
