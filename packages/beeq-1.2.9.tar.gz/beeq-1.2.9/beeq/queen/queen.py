"""
Queen — BeeQ orchestration engine.

REAL DAG execution:
  1. Queen plans: N subtasks with dependencies → directed acyclic graph
  2. Topological sort → execution waves (parallel where possible)
  3. Each wave runs concurrently (asyncio.gather)
  4. Results feed downstream tasks via context
  5. Consolidation: Queen synthesizes all outputs

The Queen does not execute. She decomposes, delegates, consolidates.
The LLM is the brain. Any LLM can play the Queen.

Z = dI/d(log s) · exp(iθ)
  I = information gain per subtask
  s = scale (number of workers engaged)
  θ = coherence (dependency graph alignment)
"""

import json
import asyncio
import hashlib
from dataclasses import dataclass, field
from datetime import datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..providers.manager import ProviderManager
    from ..governance.hive import HiveGovernance
    from ..workers.base import BaseWorker, WorkerResult


QUEEN_SYSTEM = """You are the Queen of a BeeQ hive.

Your role: receive a mission, decompose it into concrete subtasks,
delegate each to the right worker, execute in correct order, consolidate.

Workers available:
{workers}

Respond ONLY with valid JSON (no markdown, no explanation):
{{
  "understanding": "concise restatement of what the human wants",
  "subtasks": [
    {{
      "id": "t1",
      "worker": "research",
      "action": "search:web",
      "instruction": "exact instruction for the worker",
      "depends_on": [],
      "parallel_ok": true
    }},
    {{
      "id": "t2",
      "worker": "write",
      "action": "write:doc",
      "instruction": "write a summary using the research from t1",
      "depends_on": ["t1"],
      "parallel_ok": false
    }}
  ],
  "expected_result": "what the human will receive"
}}

Rules (LEX):
- §1  Each subtask has one responsible worker
- §2  Worker scope cannot be exceeded (check scope list)
- §6  Workers act freely within their authorized scope
- §8  Minimum subtasks to achieve the goal (no bloat)
- §9  Prefer reversible actions (read before write)
- Mark depends_on correctly — circular deps are forbidden
- parallel_ok: true if this task can run alongside others at same level
"""

CONSOLIDATION_SYSTEM = """You are the Queen of a BeeQ hive.
You have executed a mission through your workers.
Synthesize their results into a clear, direct response for the human.
Be concise. Include key facts. Cite which worker produced what.
Do not repeat the raw outputs verbatim — synthesize them."""


@dataclass
class SubtaskResult:
    task_id:   str
    worker:    str
    action:    str
    success:   bool
    output:    str
    error:     str | None = None
    duration:  float = 0.0


@dataclass
class Mission:
    instruction:  str
    context:      dict             = field(default_factory=dict)
    plan:         dict | None      = None
    results:      list             = field(default_factory=list)  # list[WorkerResult]
    subtask_map:  dict             = field(default_factory=dict)  # id -> SubtaskResult
    synthesis:    str              = ""
    status:       str              = "pending"
    intention:    object           = None    # PriorIntentProof — created BEFORE actions
    started_at:   str              = field(default_factory=lambda: datetime.utcnow().isoformat())
    finished_at:  str              = ""
    proof_hash:   str              = ""
    pia_id:       str              = ""      # Prior Intent Proof ID
    verify_url:   str              = ""      # https://beeq.run/verify/<pia_id>


class Queen:
    """
    BeeQ orchestration engine — real DAG, real parallelism.

    execute() flow:
      plan()     → LLM produces N-subtask DAG
      _topo()    → topological sort into execution waves
      _wave()    → asyncio.gather for each wave
      _consolidate() → LLM synthesizes all results
    """

    def __init__(
        self,
        providers:  "ProviderManager",
        governance: "HiveGovernance",
        workers:    dict[str, "BaseWorker"] | None = None,
    ):
        self.providers  = providers
        self.governance = governance
        self.workers    = workers or {}

    def add_worker(self, worker: "BaseWorker") -> None:
        worker.register()
        self.workers[worker.name] = worker

    # ── PUBLIC ───────────────────────────────────────────────────────────

    async def execute(self, mission: str, context: dict | None = None) -> Mission:
        """Full mission cycle: plan → DAG execute → consolidate."""
        m = Mission(instruction=mission, context=context or {})
        m.status = "running"

        # Build worker manifest for the Queen prompt
        worker_desc = self._worker_manifest()

        # Step 1 — Plan (Queen LLM decomposes mission into subtask DAG)
        plan = await self._plan(mission, worker_desc)
        if not plan or not plan.get("subtasks"):
            # Fallback: single research task
            plan = self._fallback_plan(mission)

        m.plan = plan

        # ── PRIOR INTENT PROOF ────────────────────────────────────────
        # Feature 1: Queen signs intention BEFORE any action.
        # timestamp_intent always precedes timestamp_action — provable.
        from beeq.intention import IntentionEngine as _IE
        _engine = _IE()
        pia = _engine.create_prior_intent(mission=mission, plan=plan)
        m.intention  = pia
        m.pia_id     = pia.pia_id
        m.verify_url = pia.verify_url
        # ─────────────────────────────────────────────────────────────

        # Step 2 — Topological waves
        waves = self._topological_waves(plan["subtasks"])

        # Step 3 — Execute wave by wave (parallel within each wave)
        completed: dict[str, SubtaskResult] = {}
        _first_wave = True
        for wave_idx, wave in enumerate(waves):
            if _first_wave:
                _engine.record_action_start(pia)
                _first_wave = False
            wave_results = await self._execute_wave(wave, mission, completed)
            for sr in wave_results:
                completed[sr.task_id] = sr
                # Convert to WorkerResult for compatibility
                from ..workers.base import WorkerResult
                m.results.append(WorkerResult(
                    worker=sr.worker,
                    action=sr.action,
                    success=sr.success,
                    output=sr.output,
                    error=sr.error,
                ))
                m.subtask_map[sr.task_id] = sr

        # Step 4 — Synthesize
        if len(m.results) > 1:
            m.synthesis = await self._consolidate(mission, completed)
        elif m.results:
            m.synthesis = m.results[0].output

        # Step 5 — Proof hash
        m.finished_at = datetime.utcnow().isoformat()
        m.proof_hash = hashlib.sha256(
            f"{mission}{m.started_at}{m.finished_at}{len(m.results)}".encode()
        ).hexdigest()

        # ── COMPLETE PIA ─────────────────────────────────────────────
        _divs = [{"type":"failed","subtask":tid,"error":str(sr.error)[:100]}
                 for tid, sr in completed.items() if not sr.success]
        _engine.record_completion(pia=pia, actions_count=len(m.results),
                                  proof_hash=m.proof_hash, divergences=_divs)
        # ─────────────────────────────────────────────────────────────

        m.status = "done"
        return m

    # ── PLANNING ──────────────────────────────────────────────────────────

    async def _plan(self, mission: str, worker_desc: str) -> dict | None:
        """Queen LLM decomposes mission → subtask DAG."""
        system = QUEEN_SYSTEM.format(workers=worker_desc)
        # Inject active skills into Queen system prompt
        try:
            from beeq.skills import SkillManager
            _skill_additions = SkillManager().get_all_instructions()
            if _skill_additions:
                system = system + "\n\n## Active Skills\n" + _skill_additions
        except Exception:
            pass
        try:
            resp = await self.providers.complete(
                messages=[{"role": "user", "content": mission}],
                system=system,
                max_tokens=2048,
            )
            content = resp.content.strip()
            # Strip markdown fences if present
            if content.startswith("```"):
                content = content.split("```")[1]
                if content.startswith("json"):
                    content = content[4:]
            # Extract JSON
            start = content.find("{")
            end   = content.rfind("}") + 1
            if start >= 0 and end > start:
                plan = json.loads(content[start:end])
                # Validate subtasks
                if "subtasks" in plan and isinstance(plan["subtasks"], list):
                    return plan
        except Exception:
            pass
        return None

    def _fallback_plan(self, mission: str) -> dict:
        """Single-worker fallback if Queen fails to plan."""
        return {
            "understanding": mission,
            "subtasks": [{
                "id": "t1",
                "worker": "research",
                "action": "search:web",
                "instruction": mission,
                "depends_on": [],
                "parallel_ok": True,
            }],
            "expected_result": "Direct research answer",
        }

    # ── DAG EXECUTION ─────────────────────────────────────────────────────

    def _topological_waves(self, subtasks: list[dict]) -> list[list[dict]]:
        """
        Topological sort → execution waves.
        Tasks with no pending deps can run in parallel (same wave).

        Returns list of waves, each wave is list of subtasks.
        """
        # Build dependency graph
        id_to_task = {t["id"]: t for t in subtasks}
        in_degree   = {t["id"]: 0 for t in subtasks}
        dependents  = {t["id"]: [] for t in subtasks}  # who depends on me

        for task in subtasks:
            for dep in task.get("depends_on", []):
                if dep in in_degree:
                    in_degree[task["id"]] += 1
                    dependents[dep].append(task["id"])

        waves = []
        remaining = set(id_to_task.keys())

        while remaining:
            # Current wave = tasks with in_degree 0
            wave_ids = {tid for tid in remaining if in_degree[tid] == 0}
            if not wave_ids:
                # Cycle or unresolvable — add remaining as last wave
                wave_ids = remaining.copy()

            wave = [id_to_task[tid] for tid in wave_ids]
            waves.append(wave)
            remaining -= wave_ids

            # Reduce in_degree for dependents
            for tid in wave_ids:
                for dep_id in dependents.get(tid, []):
                    if dep_id in in_degree:
                        in_degree[dep_id] = max(0, in_degree[dep_id] - 1)

        return waves

    async def _execute_wave(
        self,
        wave: list[dict],
        mission: str,
        completed: dict[str, "SubtaskResult"],
    ) -> list[SubtaskResult]:
        """Execute all tasks in a wave concurrently."""
        coros = [self._execute_subtask(task, mission, completed) for task in wave]
        return await asyncio.gather(*coros)

    async def _execute_subtask(
        self,
        subtask: dict,
        mission: str,
        completed: dict[str, "SubtaskResult"],
    ) -> SubtaskResult:
        """Execute a single subtask, injecting upstream results."""
        t0 = asyncio.get_event_loop().time()
        worker_name = subtask.get("worker", "research")
        worker      = self.workers.get(worker_name)

        if not worker:
            # Try fallback to research
            worker = self.workers.get("research")
            if not worker:
                return SubtaskResult(
                    task_id=subtask["id"], worker=worker_name,
                    action=subtask.get("action",""),
                    success=False, output="",
                    error=f"Worker not found: {worker_name}",
                )

        # Build enriched context with upstream outputs
        upstream = {
            dep_id: completed[dep_id].output
            for dep_id in subtask.get("depends_on", [])
            if dep_id in completed
        }

        instruction = subtask.get("instruction", mission)
        if upstream:
            upstream_text = "\n\n".join(
                f"[Result from {dep_id}]:\n{out}"
                for dep_id, out in upstream.items()
            )
            instruction = f"{instruction}\n\nPrevious results:\n{upstream_text}"

        try:
            result = await worker.execute(
                task=instruction,
                context={
                    "subtask":  subtask,
                    "mission":  mission,
                    "upstream": upstream,
                },
            )
            duration = asyncio.get_event_loop().time() - t0
            return SubtaskResult(
                task_id=subtask["id"],
                worker=worker.name,
                action=subtask.get("action", ""),
                success=result.success,
                output=result.output,
                error=result.error,
                duration=duration,
            )
        except Exception as e:
            return SubtaskResult(
                task_id=subtask["id"], worker=worker_name,
                action=subtask.get("action",""),
                success=False, output="", error=str(e),
            )

    # ── CONSOLIDATION ─────────────────────────────────────────────────────

    async def _consolidate(
        self,
        mission: str,
        completed: dict[str, "SubtaskResult"],
    ) -> str:
        """Queen synthesizes all worker outputs into a final response."""
        parts = []
        for task_id, sr in completed.items():
            if sr.success and sr.output:
                parts.append(f"[{sr.worker} / {task_id}]:\n{sr.output[:1000]}")

        if not parts:
            return "Mission completed. No output from workers."

        synthesis_prompt = (
            f"Mission: {mission}\n\n"
            f"Worker outputs:\n\n" +
            "\n\n---\n\n".join(parts)
        )

        try:
            resp = await self.providers.complete(
                messages=[{"role": "user", "content": synthesis_prompt}],
                system=CONSOLIDATION_SYSTEM,
                max_tokens=1024,
            )
            return resp.content
        except Exception:
            return "\n\n".join(f"{k}: {v.output[:500]}" for k, v in completed.items())

    # ── HELPERS ───────────────────────────────────────────────────────────

    def _worker_manifest(self) -> str:
        lines = []
        for name, w in self.workers.items():
            scope = ", ".join(w.default_scope)
            lines.append(f"- {name}: {w.description}\n  scope: [{scope}]")
        return "\n".join(lines)
