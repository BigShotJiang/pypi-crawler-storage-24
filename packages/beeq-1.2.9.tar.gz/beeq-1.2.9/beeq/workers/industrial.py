"""
BeeQ Industrial — Worker spécialisé industrie et automatisation.

Scope: monitor:equipment · analyze:process · check:safety · search:standards

Ce worker est le plus critique de BeeQ en termes de sécurité.
PHY §2 (irréversibilité) et PHY §6 (seuil) s'appliquent avec la
plus haute priorité — une erreur industrielle peut tuer.

RÈGLE ABSOLUE:
  BeeQ Industrial ne commande JAMAIS d'équipement autonomement.
  Niveau 4 (AUTONOMOUS) = BLOQUÉ par LEX §3 + PHY §2.
  Toute action physique requiert validation humaine explicite.

Capacités:
  - Analyse données capteurs (temperature, pression, vibration)
  - Détection anomalies et alertes préventives
  - Recherche normes (IEC 62443, ISO 13849, ATEX)
  - Aide au diagnostic de pannes machines
  - Calculs ingénierie (résistance, thermique, hydraulique)
  - Documentation process et maintenance

Protocoles industriels (lecture seule via NRP):
  Modbus RTU/TCP · OPC-UA · MQTT · CANbus · Profibus
"""

import math
from .base import BaseWorker, WorkerResult

INDUSTRIAL_SAFETY_DISCLAIMER = (
    "\n\n🏭 **Sécurité industrielle**: BeeQ Industrial fournit des informations "
    "d'aide à la décision uniquement. Toute intervention sur équipement doit "
    "être validée par un ingénieur qualifié. PHY §2: certaines erreurs "
    "industrielles sont irréversibles."
)

# Valeurs seuils communes (PHY §6)
THRESHOLDS = {
    "temperature_motor_max_c": 85,
    "vibration_rms_alarm_mm_s": 7.1,    # ISO 10816 classe II
    "vibration_rms_danger_mm_s": 18.0,
    "pressure_relief_factor": 1.1,       # 110% pression nominale = alarme
    "bearing_temp_delta_alarm_c": 20,    # écart température palier
}

# Normes industrielles référencées
STANDARDS = {
    "IEC 62443":  "Cybersécurité systèmes automatisés",
    "ISO 13849":  "Sécurité machines — parties système de commande",
    "ATEX":       "Équipements zones explosibles",
    "ISO 10816":  "Vibrations mécaniques — machines",
    "IEC 61511":  "Systèmes instrumentés de sécurité (SIS)",
    "EN 60079":   "Atmosphères explosives",
    "ISO 55000":  "Gestion des actifs",
    "IEC 61850":  "Réseaux électriques intelligents",
}


class IndustrialWorker(BaseWorker):
    name          = "industrial"
    description   = "Industrial automation: sensor analysis, anomaly detection, safety standards"
    default_scope = ["monitor:equipment", "analyze:process", "check:safety"]

    async def execute(self, task: str, context: dict | None = None) -> WorkerResult:
        ctx    = context or {}
        action = ctx.get("action", "auto")
        task_l = task.lower()

        # PHY §2 check: bloquer toute tentative d'action physique autonome
        PHYSICAL_ACTIONS = ["commande", "activer", "éteindre", "démarrer", "arrêter",
                           "ouvrir vanne", "fermer vanne", "command", "activate",
                           "start motor", "stop motor", "open valve", "close valve"]
        if any(a in task_l for a in PHYSICAL_ACTIONS) and not ctx.get("supervised"):
            return WorkerResult(
                self.name, "check:safety", False,
                "⛔ BeeQ Industrial REFUSE cette action.\n\n"
                "PHY §2 (irréversibilité) + LEX §3 (monde physique):\n"
                "BeeQ ne peut pas commander d'équipement de façon autonome.\n"
                "Toute action physique requiert la présence et validation d'un "
                "opérateur qualifié.\n\n"
                "BeeQ peut vous aider à:\n"
                "  - Analyser les données avant l'action\n"
                "  - Préparer la procédure d'intervention\n"
                "  - Vérifier les consignes de sécurité\n"
                "  - Documenter l'intervention",
                error="PHY§2: physical action blocked — human supervision required"
            )

        try:
            if action == "sensor" or any(w in task_l for w in
               ["capteur", "sensor", "température", "pression", "vibration", "débit"]):
                return await self._analyze_sensors(task, ctx)
            if action == "anomaly" or any(w in task_l for w in
               ["anomalie", "anomaly", "alarme", "alert", "défaut", "fault"]):
                return await self._detect_anomaly(task, ctx)
            if action == "standard" or any(w in task_l for w in
               ["norme", "standard", "iec", "iso", "atex", "certification"]):
                return await self._search_standards(task, ctx)
            if action == "calculate" or any(w in task_l for w in
               ["calcul", "calculate", "dimensionner", "résistance", "thermique"]):
                return await self._engineering_calc(task, ctx)
            if action == "maintenance" or any(w in task_l for w in
               ["maintenance", "panne", "diagnostic", "failure", "mtbf"]):
                return await self._maintenance_advice(task, ctx)
            return await self._industrial_info(task, ctx)
        except Exception as e:
            self._record("monitor:equipment", False, task.encode(), str(e).encode())
            return WorkerResult(self.name, "monitor:equipment", False, "", error=str(e))

    # ── SENSOR ANALYSIS ──────────────────────────────────────────

    async def _analyze_sensors(self, task: str, ctx: dict) -> WorkerResult:
        """Analyze sensor data and check against safety thresholds."""
        sensors = ctx.get("sensors", {})
        equipment = ctx.get("equipment", "machine")
        lines = [f"🏭 Analyse capteurs — {equipment}\n"]
        alerts = []

        # Check temperature
        if "temperature" in sensors:
            temp = float(sensors["temperature"])
            limit = ctx.get("temp_limit", THRESHOLDS["temperature_motor_max_c"])
            pct = (temp / limit) * 100
            status = "🔴 ALARME" if pct > 100 else "🟡 ATTENTION" if pct > 85 else "🟢 NORMAL"
            lines.append(f"  Température: {temp}°C / {limit}°C → {status} ({pct:.0f}%)")
            if pct > 85:
                alerts.append(f"Température {temp}°C approche seuil {limit}°C")

        # Check pressure
        if "pressure" in sensors:
            press = float(sensors["pressure"])
            nominal = ctx.get("nominal_pressure", press)
            ratio = press / nominal if nominal else 1
            status = "🔴 ALARME" if ratio > 1.1 else "🟡 ATTENTION" if ratio > 1.05 else "🟢 NORMAL"
            lines.append(f"  Pression: {press} bar / {nominal} bar → {status} ({ratio:.2f}x)")
            if ratio > 1.05:
                alerts.append(f"Pression {press} bar dépasse nominal {nominal} bar")

        # Check vibration
        if "vibration" in sensors:
            vib = float(sensors["vibration"])
            alarm = THRESHOLDS["vibration_rms_alarm_mm_s"]
            danger = THRESHOLDS["vibration_rms_danger_mm_s"]
            if vib > danger:
                status = "🔴 DANGER — Arrêt immédiat recommandé (PHY §6)"
                alerts.append(f"DANGER VIBRATION: {vib} mm/s > {danger} mm/s")
            elif vib > alarm:
                status = "🟡 ALARME (ISO 10816 classe II)"
                alerts.append(f"Vibration anormale: {vib} mm/s > {alarm} mm/s")
            else:
                status = "🟢 NORMAL"
            lines.append(f"  Vibration: {vib} mm/s → {status}")

        # No sensors provided — use LLM
        if not sensors:
            return await self._industrial_info(task, ctx)

        if alerts:
            lines.append(f"\n⚠️  {len(alerts)} alerte(s) détectée(s):")
            for a in alerts:
                lines.append(f"  → {a}")
            lines.append("\nAction recommandée: planifier inspection")
        else:
            lines.append("\n✅ Tous les paramètres dans les plages nominales")

        lines.append(INDUSTRIAL_SAFETY_DISCLAIMER)
        output = "\n".join(lines)
        artifact = self._record("monitor:equipment", True, task.encode(), output.encode())
        return WorkerResult(
            self.name, "monitor:equipment", True, output,
            artifacts=[artifact],
            metadata={"alerts": len(alerts), "sensors": sensors},
        )

    # ── ANOMALY DETECTION ────────────────────────────────────────

    async def _detect_anomaly(self, task: str, ctx: dict) -> WorkerResult:
        """Detect anomalies in process data using LLM."""
        data = ctx.get("data", task)
        process = ctx.get("process", "process industriel")

        resp = await self.providers.complete(
            messages=[{"role": "user", "content": str(data)}],
            system=(
                f"Tu es ingénieur process expert en maintenance prédictive {process}. "
                "Analyse les données et identifie:\n"
                "1. ANOMALIES: déviation par rapport au comportement normal\n"
                "2. CAUSES PROBABLES: liste des causes par probabilité\n"
                "3. RISQUES: gravité et urgence selon PHY §6 (seuils critiques)\n"
                "4. ACTIONS: inspection, mesures immédiates, planification\n"
                "Cite les codes d'alarme et normes applicables."
            ),
            max_tokens=600,
        )
        output = resp.content + INDUSTRIAL_SAFETY_DISCLAIMER
        artifact = self._record("analyze:process", True, task.encode(), output.encode())
        return WorkerResult(self.name, "analyze:process", True, output, artifacts=[artifact])

    # ── STANDARDS SEARCH ─────────────────────────────────────────

    async def _search_standards(self, task: str, ctx: dict) -> WorkerResult:
        """Reference industrial standards."""
        lines = ["📋 Normes industrielles applicables\n"]
        task_u = task.upper()

        # Direct matches
        found = []
        for std, desc in STANDARDS.items():
            if std.replace(" ", "") in task_u.replace(" ", "") or \
               any(w in task.lower() for w in desc.lower().split()[:3]):
                lines.append(f"  {std}: {desc}")
                found.append(std)

        if found:
            lines.append("")

        # LLM for detailed info
        resp = await self.providers.complete(
            messages=[{"role": "user", "content": task}],
            system=(
                "Tu es expert normalisation industrielle (IEC, ISO, EN, ATEX). "
                "Explique les exigences de la norme demandée:\n"
                "1. SCOPE: domaine d'application\n"
                "2. EXIGENCES CLÉS: 3-5 points essentiels\n"
                "3. CERTIFICATION: processus et organismes\n"
                "4. LIEN BeeQ: comment BeeQ respecte cette norme (audit trail, "
                "   Prior Intent Proof, Physical World Rule)"
            ),
            max_tokens=600,
        )
        lines.append(resp.content)
        lines.append(INDUSTRIAL_SAFETY_DISCLAIMER)
        output = "\n".join(lines)
        artifact = self._record("check:safety", True, task.encode(), output.encode())
        return WorkerResult(self.name, "check:safety", True, output, artifacts=[artifact])

    # ── ENGINEERING CALCULATIONS ─────────────────────────────────

    async def _engineering_calc(self, task: str, ctx: dict) -> WorkerResult:
        """Basic engineering calculations — mechanical, thermal, hydraulic."""
        calc_type = ctx.get("type", "")

        # Calcul thermique simple si données disponibles
        if "thermique" in task.lower() or calc_type == "thermal":
            power_kw  = ctx.get("power_kw")
            efficiency = ctx.get("efficiency", 0.92)
            if power_kw:
                losses_kw = float(power_kw) * (1 - float(efficiency))
                lines = [
                    f"🔧 Calcul thermique:",
                    f"  Puissance nominale: {power_kw} kW",
                    f"  Rendement: {float(efficiency)*100:.0f}%",
                    f"  Pertes thermiques: {losses_kw:.2f} kW",
                    f"  → Refroidissement minimum requis: {losses_kw:.2f} kW",
                ]
                output = "\n".join(lines) + INDUSTRIAL_SAFETY_DISCLAIMER
                return WorkerResult(self.name, "analyze:process", True, output)

        # Calcul via LLM pour les cas généraux
        resp = await self.providers.complete(
            messages=[{"role": "user", "content": task}],
            system=(
                "Tu es ingénieur calcul (mécanique, thermique, hydraulique, électrique). "
                "Effectue le calcul demandé avec:\n"
                "1. FORMULE utilisée (avec référence)\n"
                "2. CALCUL détaillé étape par étape\n"
                "3. RÉSULTAT avec unités\n"
                "4. MARGE DE SÉCURITÉ recommandée\n"
                "PHY §6: inclure les facteurs de sécurité réglementaires."
            ),
            max_tokens=600,
        )
        output = resp.content + INDUSTRIAL_SAFETY_DISCLAIMER
        artifact = self._record("analyze:process", True, task.encode(), output.encode())
        return WorkerResult(self.name, "analyze:process", True, output, artifacts=[artifact])

    # ── MAINTENANCE ──────────────────────────────────────────────

    async def _maintenance_advice(self, task: str, ctx: dict) -> WorkerResult:
        """Maintenance diagnosis and MTBF analysis."""
        equipment = ctx.get("equipment", "")
        symptoms  = ctx.get("symptoms", task)

        resp = await self.providers.complete(
            messages=[{"role": "user", "content":
                f"Équipement: {equipment}\nSymptômes: {symptoms}"}],
            system=(
                "Tu es expert maintenance industrielle (RCM, TPM, CMMS). "
                "Diagnostic de panne:\n"
                "1. CAUSE PROBABLE: mécanisme de défaillance\n"
                "2. VÉRIFICATIONS: séquence de diagnostic (du plus simple au plus complexe)\n"
                "3. PIÈCES: composants susceptibles d'être défaillants\n"
                "4. URGENCE: criticité selon MTBF et impact production\n"
                "PHY §1 (entropie): tout équipement se dégrade sans maintenance."
            ),
            max_tokens=600,
        )
        output = resp.content + INDUSTRIAL_SAFETY_DISCLAIMER
        artifact = self._record("monitor:equipment", True, task.encode(), output.encode())
        return WorkerResult(self.name, "monitor:equipment", True, output, artifacts=[artifact])

    async def _industrial_info(self, task: str, ctx: dict) -> WorkerResult:
        """General industrial information."""
        resp = await self.providers.complete(
            messages=[{"role": "user", "content": task}],
            system=(
                "Tu es ingénieur industriel expert automatisation et sécurité. "
                "Réponds avec précision technique. "
                "JAMAIS de commandes directes sur équipements. "
                "Cite les normes applicables. "
                "PHY §2: certaines erreurs industrielles sont irréversibles."
            ),
            max_tokens=600,
        )
        output = resp.content + INDUSTRIAL_SAFETY_DISCLAIMER
        artifact = self._record("monitor:equipment", True, task.encode(), output.encode())
        return WorkerResult(self.name, "monitor:equipment", True, output, artifacts=[artifact])
