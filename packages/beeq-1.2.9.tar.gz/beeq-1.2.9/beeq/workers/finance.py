"""
BeeQ Finance — Worker spécialisé finance et marchés.

Scope: search:market · analyze:portfolio · check:risk · explain:finance

RÈGLE STRICTE (PHY §4 — propagation):
  BeeQ Finance fournit des informations financières générales.
  BeeQ Finance ne fournit PAS de conseil en investissement.
  Les marchés propagent les erreurs — PHY §4 s'applique.
  Tout résultat inclut: "Consultez un conseiller financier agréé."

Capacités:
  - Prix et cotations temps réel (Yahoo Finance API — gratuit)
  - Analyse fondamentale: P/E, ROE, dette, croissance
  - Gestion de portefeuille: diversification, corrélation, risque
  - Cryptomonnaies: prix, capitalisation, dominance
  - Taux de change: EUR/MAD, USD/MAD, etc.
  - Éducation financière: expliquer ratios, concepts, mécanismes
"""

import json
import urllib.request
import urllib.parse
from .base import BaseWorker, WorkerResult

FINANCE_DISCLAIMER = (
    "\n\n💰 **Important**: Cette information est fournie à titre éducatif uniquement. "
    "BeeQ Finance ne fournit pas de conseil en investissement. "
    "Consultez un conseiller financier agréé avant toute décision."
)


class FinanceWorker(BaseWorker):
    name          = "finance"
    description   = "Financial information: markets, portfolio, crypto, forex, education"
    default_scope = ["search:market", "analyze:portfolio", "check:risk"]

    async def execute(self, task: str, context: dict | None = None) -> WorkerResult:
        ctx    = context or {}
        action = ctx.get("action", "auto")
        task_l = task.lower()
        try:
            if action == "quote" or any(w in task_l for w in ["prix", "cours", "price", "cotation", "ticker"]):
                return await self._get_quote(task, ctx)
            if action == "crypto" or any(w in task_l for w in ["bitcoin", "crypto", "btc", "eth", "bnb"]):
                return await self._crypto_info(task, ctx)
            if action == "forex" or any(w in task_l for w in ["taux", "mad", "eur", "usd", "change", "forex"]):
                return await self._forex_rates(task, ctx)
            if action == "analyze" or any(w in task_l for w in ["analyse", "portefeuille", "portfolio", "risque"]):
                return await self._analyze_portfolio(task, ctx)
            if action == "explain" or any(w in task_l for w in ["explique", "c'est quoi", "what is", "définition"]):
                return await self._explain_concept(task, ctx)
            return await self._finance_info(task, ctx)
        except Exception as e:
            self._record("search:market", False, task.encode(), str(e).encode())
            return WorkerResult(self.name, "search:market", False, "", error=str(e))

    # ── QUOTES ───────────────────────────────────────────────────

    async def _get_quote(self, task: str, ctx: dict) -> WorkerResult:
        """Get stock/ETF quote from Yahoo Finance."""
        ticker = ctx.get("ticker", "").upper()
        if not ticker:
            # Extract ticker from task
            import re
            m = re.search(r'\b([A-Z]{1,5})\b', task.upper())
            ticker = m.group(1) if m else ""

        if not ticker:
            return WorkerResult(
                self.name, "search:market", True,
                f"Specify a ticker (e.g. AAPL, MSFT, BTC-USD){FINANCE_DISCLAIMER}"
            )

        try:
            url = (f"https://query1.finance.yahoo.com/v8/finance/chart/{ticker}"
                   f"?interval=1d&range=5d")
            req = urllib.request.Request(
                url, headers={"User-Agent": "Mozilla/5.0", "Accept": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=10) as r:
                data = json.loads(r.read())

            result = data.get("chart", {}).get("result", [{}])[0]
            meta   = result.get("meta", {})
            price  = meta.get("regularMarketPrice", "N/A")
            prev   = meta.get("chartPreviousClose", price)
            curr   = meta.get("currency", "USD")
            name   = meta.get("longName", ticker)
            change = ((price - prev) / prev * 100) if prev and price != "N/A" else 0
            arrow  = "📈" if change >= 0 else "📉"

            output = (
                f"{arrow} **{ticker}** — {name}\n"
                f"Prix: {price} {curr}\n"
                f"Variation: {change:+.2f}% vs veille\n"
                f"Marché: {meta.get('exchangeName', '?')}"
            )
        except Exception as e:
            output = f"Prix non disponible pour {ticker}: {e}"

        output += FINANCE_DISCLAIMER
        artifact = self._record("search:market", True, task.encode(), output.encode())
        return WorkerResult(self.name, "search:market", True, output,
                           artifacts=[artifact],
                           metadata={"ticker": ticker})

    # ── CRYPTO ───────────────────────────────────────────────────

    async def _crypto_info(self, task: str, ctx: dict) -> WorkerResult:
        """Get crypto price from CoinGecko API (free, no key)."""
        # Map common names to CoinGecko IDs
        CRYPTO_MAP = {
            "bitcoin": "bitcoin", "btc": "bitcoin",
            "ethereum": "ethereum", "eth": "ethereum",
            "bnb": "binancecoin", "solana": "solana", "sol": "solana",
            "xrp": "ripple", "cardano": "cardano", "ada": "cardano",
            "dogecoin": "dogecoin", "doge": "dogecoin",
        }
        task_l = task.lower()
        coin_id = next((v for k, v in CRYPTO_MAP.items() if k in task_l), "bitcoin")
        coin_name = ctx.get("coin", coin_id)

        try:
            url = (f"https://api.coingecko.com/api/v3/simple/price"
                   f"?ids={coin_id}&vs_currencies=usd,eur,mad"
                   f"&include_24hr_change=true&include_market_cap=true")
            req = urllib.request.Request(
                url, headers={"User-Agent": "BeeQ/1.2.5"}
            )
            with urllib.request.urlopen(req, timeout=10) as r:
                data = json.loads(r.read())

            info = data.get(coin_id, {})
            usd  = info.get("usd", "N/A")
            eur  = info.get("eur", "N/A")
            mad  = info.get("mad", "N/A")
            chg  = info.get("usd_24h_change", 0)
            mcap = info.get("usd_market_cap", 0)
            arrow = "📈" if chg >= 0 else "📉"

            def _fmt(v):
                try: return f"{float(v):,.2f}"
                except: return str(v)

            output = (
                f"{arrow} **{coin_id.upper()}**\n"
                f"USD: ${_fmt(usd)}  |  EUR: €{_fmt(eur)}  |  MAD: {_fmt(mad)} DH\n"
                f"24h: {float(chg):+.2f}%\n"
                f"Market cap: ${float(mcap)/1e9:.1f}B"
            ) if usd not in ('N/A', None) else f"{coin_id}: prix non disponible"
        except Exception as e:
            output = f"Crypto data unavailable: {e}"

        output += FINANCE_DISCLAIMER
        artifact = self._record("search:market", True, task.encode(), output.encode())
        return WorkerResult(self.name, "search:market", True, output,
                           artifacts=[artifact],
                           metadata={"coin": coin_id})

    # ── FOREX ────────────────────────────────────────────────────

    async def _forex_rates(self, task: str, ctx: dict) -> WorkerResult:
        """Get exchange rates — focus on MAD (Moroccan Dirham)."""
        try:
            # Fixer API (free tier: EUR base)
            url = "https://api.exchangerate-api.com/v4/latest/EUR"
            req = urllib.request.Request(url, headers={"User-Agent": "BeeQ/1.2.5"})
            with urllib.request.urlopen(req, timeout=10) as r:
                data = json.loads(r.read())

            rates = data.get("rates", {})
            mad   = rates.get("MAD", "N/A")
            usd   = rates.get("USD", "N/A")
            gbp   = rates.get("GBP", "N/A")
            chf   = rates.get("CHF", "N/A")

            output = (
                f"💱 **Taux de change** (base EUR)\n"
                f"1 EUR = {mad:.4f} MAD\n"
                f"1 EUR = {usd:.4f} USD\n"
                f"1 EUR = {gbp:.4f} GBP\n"
                f"1 EUR = {chf:.4f} CHF\n"
                f"Source: exchangerate-api.com"
            )
        except Exception as e:
            output = f"Taux de change non disponibles: {e}"

        output += FINANCE_DISCLAIMER
        artifact = self._record("search:market", True, task.encode(), output.encode())
        return WorkerResult(self.name, "search:market", True, output, artifacts=[artifact])

    # ── PORTFOLIO ANALYSIS ───────────────────────────────────────

    async def _analyze_portfolio(self, task: str, ctx: dict) -> WorkerResult:
        """Portfolio analysis — diversification, risk, allocation."""
        portfolio = ctx.get("portfolio", [])
        portfolio_str = str(portfolio) if portfolio else task

        resp = await self.providers.complete(
            messages=[{"role": "user", "content": portfolio_str}],
            system=(
                "Tu es analyste financier. Analyse ce portefeuille:\n"
                "1. DIVERSIFICATION: classes d'actifs, géographies, secteurs\n"
                "2. RISQUE: concentration, corrélations, volatilité\n"
                "3. ÉQUILIBRE: répartition actions/obligations/cash\n"
                "4. SUGGESTIONS: amélioration sans conseil personnalisé\n"
                "PHY §4: un portefeuille concentré propage les chocs — diversifier."
            ),
            max_tokens=600,
        )
        output = resp.content + FINANCE_DISCLAIMER
        artifact = self._record("analyze:portfolio", True, task.encode(), output.encode())
        return WorkerResult(self.name, "analyze:portfolio", True, output, artifacts=[artifact])

    # ── EXPLAIN ──────────────────────────────────────────────────

    async def _explain_concept(self, task: str, ctx: dict) -> WorkerResult:
        """Explain financial concepts."""
        resp = await self.providers.complete(
            messages=[{"role": "user", "content": task}],
            system=(
                "Tu expliques les concepts financiers en langage simple et accessible. "
                "Format: Définition → Exemple concret → Risques → À retenir. "
                "Adapte au niveau débutant sauf indication contraire."
            ),
            max_tokens=500,
        )
        output = resp.content + FINANCE_DISCLAIMER
        artifact = self._record("search:market", True, task.encode(), output.encode())
        return WorkerResult(self.name, "search:market", True, output, artifacts=[artifact])

    async def _finance_info(self, task: str, ctx: dict) -> WorkerResult:
        """General financial information."""
        resp = await self.providers.complete(
            messages=[{"role": "user", "content": task}],
            system=(
                "Tu fournis des informations financières générales et éducatives. "
                "Cite des données factuelles. JAMAIS de recommandation d'investissement. "
                "PHY §4: les décisions financières se propagent — chaque action a des conséquences."
            ),
            max_tokens=500,
        )
        output = resp.content + FINANCE_DISCLAIMER
        artifact = self._record("search:market", True, task.encode(), output.encode())
        return WorkerResult(self.name, "search:market", True, output, artifacts=[artifact])
