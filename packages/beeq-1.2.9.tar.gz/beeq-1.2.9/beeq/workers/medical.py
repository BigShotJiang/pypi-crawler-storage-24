"""
BeeQ Medical — Worker spécialisé santé et médecine.

Scope: search:pubmed · analyze:symptoms · check:interactions · summarize:research

RÈGLE ABSOLUE (PHY §2 — irréversibilité):
  BeeQ Medical ne pose JAMAIS de diagnostic.
  BeeQ Medical ne prescrit JAMAIS de traitement.
  Tout résultat est accompagné de: "Consultez un médecin."

Ce que BeeQ Medical FAIT:
  - Recherche littérature médicale (PubMed, guidelines WHO)
  - Résumé structuré d'articles pour professionnels de santé
  - Vérification interactions médicamenteuses (base de données)
  - Préparer un briefing médecin (historique + symptômes + questions)
  - Terminologie médicale en plusieurs langues (darija, français, anglais)
"""

from .base import BaseWorker, WorkerResult

# Disclaimer obligatoire sur TOUTES les réponses
MEDICAL_DISCLAIMER = (
    "\n\n⚠️ **Important**: BeeQ Medical fournit des informations générales, "
    "pas un diagnostic médical. Consultez toujours un médecin qualifié."
)


class MedicalWorker(BaseWorker):
    name          = "medical"
    description   = "Medical information: PubMed research, symptom briefs, drug interactions"
    default_scope = ["search:pubmed", "analyze:symptoms", "check:interactions"]

    async def execute(self, task: str, context: dict | None = None) -> WorkerResult:
        ctx    = context or {}
        action = ctx.get("action", "auto")
        task_l = task.lower()
        try:
            if action == "research" or "pubmed" in task_l or "étude" in task_l:
                return await self._medical_research(task, ctx)
            if action == "interaction" or "interaction" in task_l or "médicament" in task_l:
                return await self._check_interactions(task, ctx)
            if action == "brief" or "briefing" in task_l or "médecin" in task_l:
                return await self._prepare_brief(task, ctx)
            if action == "terminology" or "terme" in task_l or "signifie" in task_l:
                return await self._explain_terminology(task, ctx)
            # Default: information générale avec disclaimer
            return await self._general_medical_info(task, ctx)
        except Exception as e:
            self._record("search:pubmed", False, task.encode(), str(e).encode())
            return WorkerResult(self.name, "search:pubmed", False, "", error=str(e))

    async def _medical_research(self, task: str, ctx: dict) -> WorkerResult:
        """Search and summarize medical literature."""
        import urllib.request, urllib.parse, json

        query   = ctx.get("query", task)
        max_res = ctx.get("max_results", 5)
        clean_q = query.replace("pubmed", "").replace("étude", "").strip()

        # PubMed search
        try:
            search_url = (
                f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
                f"?db=pubmed&term={urllib.parse.quote(clean_q)}"
                f"&retmax={max_res}&retmode=json&sort=relevance"
            )
            req = urllib.request.Request(search_url, headers={"User-Agent": "BeeQ/1.2.4"})
            with urllib.request.urlopen(req, timeout=15) as r:
                data = json.loads(r.read())

            ids = data.get("esearchresult", {}).get("idlist", [])
            if not ids:
                return WorkerResult(
                    self.name, "search:pubmed", True,
                    f"No PubMed results for: {query}{MEDICAL_DISCLAIMER}",
                    metadata={"count": 0}
                )

            # Fetch summaries
            fetch_url = (
                f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi"
                f"?db=pubmed&id={','.join(ids)}&retmode=json"
            )
            req2 = urllib.request.Request(fetch_url, headers={"User-Agent": "BeeQ/1.2.4"})
            with urllib.request.urlopen(req2, timeout=15) as r:
                summaries = json.loads(r.read())

            result_data = summaries.get("result", {})
            lines = [f"📚 PubMed Research: {clean_q}\n"]
            papers = []
            for pmid in ids:
                article = result_data.get(pmid, {})
                title   = article.get("title", "?")
                authors = ", ".join(a.get("name","") for a in article.get("authors",[])[:3])
                pub_date = article.get("pubdate", "")
                source   = article.get("source", "")
                url = f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/"
                lines.append(f"[PMID:{pmid}] {title}")
                lines.append(f"  {authors} | {source} | {pub_date}")
                lines.append(f"  → {url}\n")
                papers.append({"pmid": pmid, "title": title, "url": url})

            lines.append(MEDICAL_DISCLAIMER)
            output = "\n".join(lines)

        except Exception as e:
            output = f"PubMed search failed: {e}{MEDICAL_DISCLAIMER}"
            papers = []

        artifact = self._record("search:pubmed", True, task.encode(), output.encode())
        return WorkerResult(
            self.name, "search:pubmed", True, output,
            artifacts=[artifact],
            metadata={"count": len(papers), "papers": papers},
        )

    async def _check_interactions(self, task: str, ctx: dict) -> WorkerResult:
        """Check drug interactions — informational only."""
        medicaments = ctx.get("medicaments", [])
        drugs_str = ", ".join(medicaments) if medicaments else task

        resp = await self.providers.complete(
            messages=[{"role": "user", "content":
                f"Interactions entre: {drugs_str}\n\nQuestion: {task}"}],
            system=(
                "Tu es pharmacologue. Donne des informations sur les interactions "
                "médicamenteuses connues. TOUJOURS rappeler de consulter un pharmacien. "
                "Format: mécanisme d'interaction → risque → conduite à tenir."
            ),
            max_tokens=512,
        )
        output = resp.content + MEDICAL_DISCLAIMER
        artifact = self._record("check:interactions", True, task.encode(), output.encode())
        return WorkerResult(self.name, "check:interactions", True, output,
                           artifacts=[artifact])

    async def _prepare_brief(self, task: str, ctx: dict) -> WorkerResult:
        """Prepare a structured patient brief for doctor consultation."""
        symptomes  = ctx.get("symptomes", [])
        historique = ctx.get("historique", "")
        questions  = ctx.get("questions", [])

        content = f"Prépare un briefing médecin pour:\n"
        if symptomes:
            content += f"Symptômes: {', '.join(symptomes)}\n"
        if historique:
            content += f"Historique: {historique}\n"
        if questions:
            content += f"Questions: {'; '.join(questions)}\n"
        content += f"\nContexte: {task}"

        resp = await self.providers.complete(
            messages=[{"role": "user", "content": content}],
            system=(
                "Tu aides le patient à préparer sa consultation médicale. "
                "Structure: 1.Motif principal 2.Symptômes chronologiques "
                "3.Facteurs aggravants/soulageants 4.Questions pour le médecin. "
                "Rappelle que ce document ne remplace pas l'examen médical."
            ),
            max_tokens=600,
        )
        output = resp.content + MEDICAL_DISCLAIMER
        artifact = self._record("analyze:symptoms", True, task.encode(), output.encode())
        return WorkerResult(self.name, "analyze:symptoms", True, output,
                           artifacts=[artifact])

    async def _explain_terminology(self, task: str, ctx: dict) -> WorkerResult:
        """Explain medical terminology in plain language."""
        langue = ctx.get("langue", "français")
        resp = await self.providers.complete(
            messages=[{"role": "user", "content": task}],
            system=(
                f"Tu expliques la terminologie médicale en {langue} simple. "
                "Définition claire + étymologie si utile + exemple clinique simple. "
                "Disponible aussi en darija (الدارجة) si demandé."
            ),
            max_tokens=400,
        )
        output = resp.content + MEDICAL_DISCLAIMER
        artifact = self._record("search:pubmed", True, task.encode(), output.encode())
        return WorkerResult(self.name, "search:pubmed", True, output, artifacts=[artifact])

    async def _general_medical_info(self, task: str, ctx: dict) -> WorkerResult:
        """General medical information with strict disclaimer."""
        resp = await self.providers.complete(
            messages=[{"role": "user", "content": task}],
            system=(
                "Tu fournis des informations médicales générales basées sur les guidelines WHO. "
                "JAMAIS de diagnostic. JAMAIS de prescription. "
                "Toujours orienter vers un professionnel de santé pour les cas individuels. "
                "PHY §2: une erreur médicale peut être irréversible."
            ),
            max_tokens=512,
        )
        output = resp.content + MEDICAL_DISCLAIMER
        artifact = self._record("search:pubmed", True, task.encode(), output.encode())
        return WorkerResult(self.name, "search:pubmed", True, output, artifacts=[artifact])
