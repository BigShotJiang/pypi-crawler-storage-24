"""BeeQ Domain Workers — specialized workers for specific industries."""
from ..science     import ScienceWorker
from ..darija      import DarijaWorker
from ..agriculture import AgricultureWorker
from ..medical     import MedicalWorker
from ..legal       import LegalWorker
from ..finance     import FinanceWorker
from ..industrial  import IndustrialWorker

DOMAIN_WORKERS = {
    "science":    ScienceWorker,
    "darija":     DarijaWorker,
    "agriculture":AgricultureWorker,
    "medical":    MedicalWorker,
    "legal":      LegalWorker,
    "finance":    FinanceWorker,
    "industrial": IndustrialWorker,
}
__all__ = ["ScienceWorker","DarijaWorker","AgricultureWorker","MedicalWorker",
           "LegalWorker","FinanceWorker","IndustrialWorker","DOMAIN_WORKERS"]
