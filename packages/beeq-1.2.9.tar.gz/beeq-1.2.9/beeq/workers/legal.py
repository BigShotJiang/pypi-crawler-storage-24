"""
BeeQ Legal — Worker spécialisé droit et juridique.

Scope: search:law · analyze:contract · check:compliance · explain:rights

RÈGLE STRICTE (LEX §1 — responsabilité):
  BeeQ Legal fournit des informations juridiques générales.
  BeeQ Legal ne fournit PAS de conseil juridique personnalisé.
  Tout résultat est accompagné de: "Consultez un avocat."

Capacités:
  - Recherche jurisprudence et textes de loi (Maroc, France, EU)
  - Analyse de clauses contractuelles (risques, anomalies)
  - Vérification conformité RGPD / loi 09-08 Maroc
  - Explication droits des utilisateurs en langage clair
  - Rédaction de templates contractuels standards

Droit marocain supporté:
  - Code des obligations et contrats (DOC)
  - Loi 09-08 (protection données personnelles)
  - Code du travail marocain
  - Droit commercial, droit de la propriété intellectuelle
"""

from .base import BaseWorker, WorkerResult

LEGAL_DISCLAIMER = (
    "\n\n⚖️ **Important**: Cette information est générale et ne constitue pas "
    "un conseil juridique. Pour votre situation spécifique, consultez un avocat."
)

# RGPD / Loi 09-08 checklist
RGPD_CHECKLIST = [
    ("Consentement", "Le consentement est-il explicite et librement donné?"),
    ("Finalité", "La finalité du traitement est-elle clairement définie?"),
    ("Minimisation", "Seules les données nécessaires sont-elles collectées?"),
    ("Durée", "La durée de conservation est-elle définie?"),
    ("Droits", "Les droits RGPD (accès, rectification, suppression) sont-ils garantis?"),
    ("Sécurité", "Des mesures de sécurité techniques sont-elles en place?"),
    ("Transfert", "Les transferts hors UE/Maroc sont-ils encadrés?"),
    ("DPO", "Un délégué à la protection des données est-il désigné si requis?"),
]


class LegalWorker(BaseWorker):
    name          = "legal"
    description   = "Legal information: contracts, compliance, rights, GDPR/09-08"
    default_scope = ["search:law", "analyze:contract", "check:compliance"]

    async def execute(self, task: str, context: dict | None = None) -> WorkerResult:
        ctx    = context or {}
        action = ctx.get("action", "auto")
        task_l = task.lower()
        try:
            if action == "contract" or any(w in task_l for w in
               ["contrat", "clause", "contract", "accord", "convention"]):
                return await self._analyze_contract(task, ctx)
            if action == "rgpd" or any(w in task_l for w in
               ["rgpd", "gdpr", "données personnelles", "09-08", "privacy"]):
                return await self._check_rgpd(task, ctx)
            if action == "rights" or any(w in task_l for w in
               ["droit", "right", "protection", "recours"]):
                return await self._explain_rights(task, ctx)
            if action == "template" or any(w in task_l for w in
               ["template", "modèle", "rédige", "draft"]):
                return await self._draft_template(task, ctx)
            return await self._legal_info(task, ctx)
        except Exception as e:
            self._record("search:law", False, task.encode(), str(e).encode())
            return WorkerResult(self.name, "search:law", False, "", error=str(e))

    async def _analyze_contract(self, task: str, ctx: dict) -> WorkerResult:
        """Analyze contract clauses — identify risks."""
        contrat = ctx.get("contrat", task)
        juridiction = ctx.get("juridiction", "France/Maroc")

        resp = await self.providers.complete(
            messages=[{"role": "user", "content": contrat}],
            system=(
                f"Tu es juriste expert droit {juridiction}. "
                "Analyse les clauses contractuelles et identifie:\n"
                "1. CLAUSES ABUSIVES: déséquilibre significatif\n"
                "2. RISQUES JURIDIQUES: ambiguïtés, responsabilités mal définies\n"
                "3. ÉLÉMENTS MANQUANTS: clauses obligatoires absentes\n"
                "4. RECOMMANDATIONS: modifications suggérées\n"
                "Sois précis et cite les articles de loi applicables."
            ),
            max_tokens=800,
        )
        output = resp.content + LEGAL_DISCLAIMER
        artifact = self._record("analyze:contract", True, task.encode(), output.encode())
        return WorkerResult(self.name, "analyze:contract", True, output,
                           artifacts=[artifact],
                           metadata={"juridiction": juridiction})

    async def _check_rgpd(self, task: str, ctx: dict) -> WorkerResult:
        """RGPD / Loi 09-08 compliance check."""
        lines = ["📋 Checklist Conformité RGPD / Loi 09-08 Maroc\n"]
        context_text = ctx.get("contexte", task)

        for category, question in RGPD_CHECKLIST:
            lines.append(f"□ **{category}**: {question}")
        lines.append("")

        # LLM analysis of the specific context
        resp = await self.providers.complete(
            messages=[{"role": "user", "content":
                f"Analyse RGPD/09-08 pour: {context_text}"}],
            system=(
                "Tu es expert RGPD et loi marocaine 09-08 protection données. "
                "Identifie les points de non-conformité et les actions correctives. "
                "Format: Point → Statut (✅/⚠️/❌) → Action requise."
            ),
            max_tokens=600,
        )
        lines.append(resp.content)
        lines.append(LEGAL_DISCLAIMER)
        output = "\n".join(lines)
        artifact = self._record("check:compliance", True, task.encode(), output.encode())
        return WorkerResult(self.name, "check:compliance", True, output,
                           artifacts=[artifact])

    async def _explain_rights(self, task: str, ctx: dict) -> WorkerResult:
        """Explain legal rights in plain language."""
        langue = ctx.get("langue", "français")
        domaine = ctx.get("domaine", "général")

        resp = await self.providers.complete(
            messages=[{"role": "user", "content": task}],
            system=(
                f"Tu expliques les droits juridiques en {langue} simple et accessible. "
                f"Domaine: {domaine}. "
                "Format: Droit → Ce que ça signifie → Comment l'exercer → Délais. "
                "Cite les textes de loi applicables (articles)."
            ),
            max_tokens=600,
        )
        output = resp.content + LEGAL_DISCLAIMER
        artifact = self._record("search:law", True, task.encode(), output.encode())
        return WorkerResult(self.name, "search:law", True, output, artifacts=[artifact])

    async def _draft_template(self, task: str, ctx: dict) -> WorkerResult:
        """Draft a legal template document."""
        doc_type    = ctx.get("type", "contrat")
        juridiction = ctx.get("juridiction", "France")
        parties     = ctx.get("parties", "")

        resp = await self.providers.complete(
            messages=[{"role": "user", "content":
                f"Rédige un {doc_type} pour: {task}\n"
                f"Juridiction: {juridiction}\n"
                f"Parties: {parties}"}],
            system=(
                f"Tu es juriste expert droit {juridiction}. "
                f"Rédige un template de {doc_type} standard. "
                "Utilise [PARTIE A], [PARTIE B], [DATE], [MONTANT] pour les champs à compléter. "
                "Inclus toutes les clauses obligatoires selon la loi applicable."
            ),
            max_tokens=1200,
        )
        output = resp.content + LEGAL_DISCLAIMER
        artifact = self._record("analyze:contract", True, task.encode(), output.encode())
        return WorkerResult(self.name, "analyze:contract", True, output,
                           artifacts=[artifact],
                           metadata={"type": doc_type, "juridiction": juridiction})

    async def _legal_info(self, task: str, ctx: dict) -> WorkerResult:
        """General legal information."""
        resp = await self.providers.complete(
            messages=[{"role": "user", "content": task}],
            system=(
                "Tu fournis des informations juridiques générales. "
                "Cite les textes de loi applicables. "
                "JAMAIS de conseil juridique personnalisé. "
                "Oriente toujours vers un avocat pour les situations individuelles. "
                "LEX §1: chaque acte juridique a un responsable identifiable."
            ),
            max_tokens=600,
        )
        output = resp.content + LEGAL_DISCLAIMER
        artifact = self._record("search:law", True, task.encode(), output.encode())
        return WorkerResult(self.name, "search:law", True, output, artifacts=[artifact])
