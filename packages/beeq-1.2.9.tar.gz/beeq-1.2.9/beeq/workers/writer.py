"""
Worker-Write — Document generation and communication.

Scope: write:doc · write:email · write:report · write:pdf

Real actions:
  - Generate Markdown documents (always works, no deps)
  - Generate PDF via reportlab or weasyprint (if available)
  - Generate HTML reports
  - Send email via SMTP (configured in ~/.beeq/config.json)
  - Future: MCP Gmail integration

LEX §9: before overwriting any existing file, backup first.
Z: maximize information density per token — no padding, no filler.
"""

import os
import re
import json
import smtplib
import subprocess
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from pathlib import Path

from .base import BaseWorker, WorkerResult

DOCS_DIR = Path.home() / ".beeq" / "documents"


class WriterWorker(BaseWorker):
    name          = "write"
    description   = "Write documents (Markdown, PDF, HTML), send emails, generate reports"
    default_scope = ["write:doc", "write:email", "write:report"]

    # ── EXECUTE ───────────────────────────────────────────────────

    async def execute(self, task: str, context: dict | None = None) -> WorkerResult:
        ctx    = context or {}
        action = ctx.get("action", "auto")
        DOCS_DIR.mkdir(parents=True, exist_ok=True)

        try:
            if action == "email":
                return await self._send_email(ctx)
            if action == "pdf":
                return await self._write_pdf(task, ctx)
            if action == "html":
                return await self._write_html(task, ctx)
            if action == "markdown" or action == "md":
                return await self._write_markdown(task, ctx)
            if action == "report":
                return await self._write_report(task, ctx)

            # Auto-detect from task
            task_lower = task.lower()
            if any(w in task_lower for w in ["email", "mail", "envoie", "send"]):
                return await self._send_email(ctx)
            if "pdf" in task_lower:
                return await self._write_pdf(task, ctx)
            if "html" in task_lower or "page" in task_lower:
                return await self._write_html(task, ctx)
            if "rapport" in task_lower or "report" in task_lower:
                return await self._write_report(task, ctx)

            # Default: LLM generates content, save as Markdown
            return await self._write_markdown(task, ctx)

        except Exception as e:
            self._record("write:doc", False, task.encode(), str(e).encode())
            return WorkerResult(self.name, "write:doc", False, "", error=str(e))

    # ── MARKDOWN ─────────────────────────────────────────────────

    async def _write_markdown(self, task: str, ctx: dict) -> WorkerResult:
        """Generate Markdown content — always works, zero dependencies."""
        content = ctx.get("content", "")

        if not content:
            # Generate with LLM
            resp = await self.providers.complete(
                messages=[{"role": "user", "content": task}],
                system=(
                    "You are a professional writer. Generate well-structured Markdown content. "
                    "Use headers, lists, and emphasis appropriately. "
                    "Be concise and information-dense. No filler."
                ),
                max_tokens=4096,
            )
            content = resp.content

        # Save to file
        filename = ctx.get("filename") or self._title_to_filename(task, ".md")
        path = DOCS_DIR / filename

        # LEX §9: backup before overwrite
        if path.exists():
            bak = path.with_suffix(f".{datetime.now().strftime('%Y%m%d_%H%M%S')}.bak")
            path.rename(bak)

        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")

        artifact = self._record("write:doc", True,
                               task.encode(), f"saved:{path}".encode())
        return WorkerResult(
            self.name, "write:doc", True,
            f"Document saved: {path}\n\n{content[:500]}{'...' if len(content) > 500 else ''}",
            artifacts=[artifact],
            metadata={"path": str(path), "chars": len(content), "format": "markdown"},
        )

    # ── PDF ──────────────────────────────────────────────────────

    async def _write_pdf(self, task: str, ctx: dict) -> WorkerResult:
        """Generate PDF — tries reportlab, falls back to HTML→PDF, then Markdown."""
        content = ctx.get("content", "")
        title   = ctx.get("title", task[:60])
        filename = ctx.get("filename") or self._title_to_filename(task, ".pdf")
        path    = DOCS_DIR / filename

        # Generate content if not provided
        if not content:
            resp = await self.providers.complete(
                messages=[{"role": "user", "content": task}],
                system=(
                    "Generate professional document content for a PDF report. "
                    "Use clear sections with ## headers. Be structured and concise."
                ),
                max_tokens=4096,
            )
            content = resp.content

        # Try reportlab (best quality)
        pdf_path = await self._pdf_via_reportlab(content, title, path)

        # Try weasyprint (HTML→PDF)
        if not pdf_path:
            pdf_path = await self._pdf_via_weasyprint(content, title, path)

        # Fallback: save as Markdown with .pdf name (honest degradation)
        if not pdf_path:
            md_path = path.with_suffix(".md")
            md_path.write_text(f"# {title}\n\n{content}", encoding="utf-8")
            note = "⚠️ PDF libraries not available — saved as Markdown instead."
            artifact = self._record("write:doc", True,
                                   task.encode(), str(md_path).encode())
            return WorkerResult(
                self.name, "write:doc", True,
                f"{note}\nSaved: {md_path}",
                artifacts=[artifact],
                metadata={"path": str(md_path), "format": "markdown_fallback"},
            )

        artifact = self._record("write:doc", True,
                               task.encode(), str(pdf_path).encode())
        return WorkerResult(
            self.name, "write:doc", True,
            f"PDF saved: {pdf_path} ({pdf_path.stat().st_size // 1024}KB)",
            artifacts=[artifact],
            metadata={"path": str(pdf_path), "format": "pdf"},
        )

    async def _pdf_via_reportlab(self, content: str, title: str, path: Path):
        """Generate PDF with reportlab."""
        try:
            from reportlab.lib.pagesizes import A4
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
            from reportlab.lib.units import cm
            from reportlab.lib import colors
            from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, HRFlowable
            from reportlab.lib.enums import TA_LEFT, TA_CENTER

            doc = SimpleDocTemplate(
                str(path),
                pagesize=A4,
                leftMargin=2.5*cm, rightMargin=2.5*cm,
                topMargin=2.5*cm, bottomMargin=2.5*cm,
            )
            styles = getSampleStyleSheet()

            # Custom styles
            title_style = ParagraphStyle(
                'BeeQTitle',
                parent=styles['Title'],
                fontSize=20, textColor=colors.HexColor('#F0A020'),
                spaceAfter=20,
            )
            h1_style = ParagraphStyle(
                'BeeQH1', parent=styles['Heading1'],
                fontSize=14, textColor=colors.HexColor('#1a1a2e'),
                spaceBefore=15, spaceAfter=8,
            )
            body_style = ParagraphStyle(
                'BeeQBody', parent=styles['Normal'],
                fontSize=10, leading=16, spaceAfter=8,
            )

            story = []
            story.append(Paragraph(title, title_style))
            story.append(Paragraph(
                f"Generated by BeeQ · {datetime.now().strftime('%Y-%m-%d %H:%M')}",
                styles['Normal']
            ))
            story.append(HRFlowable(width="100%", thickness=1,
                                    color=colors.HexColor('#F0A020')))
            story.append(Spacer(1, 0.5*cm))

            # Parse markdown-ish content
            for line in content.split('\n'):
                line = line.strip()
                if not line:
                    story.append(Spacer(1, 0.3*cm))
                elif line.startswith('## '):
                    story.append(Paragraph(line[3:], h1_style))
                elif line.startswith('# '):
                    story.append(Paragraph(line[2:], h1_style))
                elif line.startswith('- ') or line.startswith('* '):
                    story.append(Paragraph(f"• {line[2:]}", body_style))
                else:
                    # Escape HTML entities
                    safe = line.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
                    story.append(Paragraph(safe, body_style))

            # Footer
            story.append(Spacer(1, 1*cm))
            story.append(HRFlowable(width="100%", thickness=0.5,
                                    color=colors.HexColor('#cccccc')))
            story.append(Paragraph(
                "Generated by BeeQ — beeq.run",
                ParagraphStyle('footer', parent=styles['Normal'],
                               fontSize=8, textColor=colors.HexColor('#888888'),
                               alignment=TA_CENTER)
            ))

            doc.build(story)
            return path

        except ImportError:
            return None
        except Exception:
            return None

    async def _pdf_via_weasyprint(self, content: str, title: str, path: Path):
        """Generate PDF via weasyprint (HTML→PDF)."""
        try:
            import weasyprint
            html_content = self._md_to_html(content, title)
            weasyprint.HTML(string=html_content).write_pdf(str(path))
            return path
        except ImportError:
            return None
        except Exception:
            return None

    # ── HTML REPORT ───────────────────────────────────────────────

    async def _write_html(self, task: str, ctx: dict) -> WorkerResult:
        """Generate HTML report with BeeQ styling."""
        content = ctx.get("content", "")
        title   = ctx.get("title", task[:60])
        filename = ctx.get("filename") or self._title_to_filename(task, ".html")
        path    = DOCS_DIR / filename

        if not content:
            resp = await self.providers.complete(
                messages=[{"role": "user", "content": task}],
                system=(
                    "Generate structured content for an HTML report. "
                    "Use ## for sections. Be comprehensive and well-organized."
                ),
                max_tokens=4096,
            )
            content = resp.content

        html = self._md_to_html(content, title)
        if path.exists():
            path.rename(path.with_suffix(f".{datetime.now().strftime('%H%M%S')}.bak"))
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(html, encoding="utf-8")

        artifact = self._record("write:doc", True,
                               task.encode(), str(path).encode())
        return WorkerResult(
            self.name, "write:doc", True,
            f"HTML report saved: {path}",
            artifacts=[artifact],
            metadata={"path": str(path), "format": "html"},
        )

    # ── REPORT (auto-format) ──────────────────────────────────────

    async def _write_report(self, task: str, ctx: dict) -> WorkerResult:
        """Generate a report — auto-selects best format."""
        # Try PDF first, fallback to Markdown
        try:
            return await self._write_pdf(task, ctx)
        except Exception:
            return await self._write_markdown(task, ctx)

    # ── EMAIL ─────────────────────────────────────────────────────

    async def _send_email(self, ctx: dict) -> WorkerResult:
        """
        Send an email via SMTP.

        Config in ~/.beeq/config.json:
          "email": {
            "smtp_host": "smtp.gmail.com",
            "smtp_port": 587,
            "smtp_user": "you@gmail.com",
            "smtp_pass": "app_password",
            "from": "BeeQ <you@gmail.com>"
          }
        """
        cfg_path = Path.home() / ".beeq" / "config.json"
        if not cfg_path.exists():
            return WorkerResult(self.name, "write:email", False, "",
                               error="No email config. Add 'email' section to ~/.beeq/config.json")

        try:
            cfg = json.loads(cfg_path.read_text()).get("email", {})
        except Exception as e:
            return WorkerResult(self.name, "write:email", False, "",
                               error=f"Config error: {e}")

        if not cfg.get("smtp_host"):
            return WorkerResult(self.name, "write:email", False, "",
                               error="No SMTP config found in ~/.beeq/config.json")

        to      = ctx.get("to", "")
        subject = ctx.get("subject", "BeeQ")
        body    = ctx.get("body", ctx.get("content", ""))
        attach  = ctx.get("attachment", "")  # path to file to attach

        if not to:
            return WorkerResult(self.name, "write:email", False, "",
                               error="No 'to' address in context")

        # Build message
        msg = MIMEMultipart()
        msg["From"]    = cfg.get("from", cfg["smtp_user"])
        msg["To"]      = to
        msg["Subject"] = subject
        msg.attach(MIMEText(body, "plain" if not "<html>" in body else "html"))

        # Attachment
        if attach and Path(attach).exists():
            with open(attach, "rb") as f:
                part = MIMEBase("application", "octet-stream")
                part.set_payload(f.read())
            encoders.encode_base64(part)
            part.add_header("Content-Disposition",
                           f"attachment; filename={Path(attach).name}")
            msg.attach(part)

        # Send
        try:
            with smtplib.SMTP(cfg["smtp_host"], int(cfg.get("smtp_port", 587))) as server:
                server.starttls()
                server.login(cfg["smtp_user"], cfg["smtp_pass"])
                server.sendmail(cfg["smtp_user"], to, msg.as_string())

            artifact = self._record("write:email", True,
                                   to.encode(), subject.encode())
            return WorkerResult(
                self.name, "write:email", True,
                f"Email sent to {to}: '{subject}'",
                artifacts=[artifact],
            )
        except Exception as e:
            return WorkerResult(self.name, "write:email", False, "",
                               error=f"SMTP error: {e}")

    # ── HELPERS ───────────────────────────────────────────────────

    def _md_to_html(self, content: str, title: str) -> str:
        """Convert Markdown-ish content to HTML with BeeQ styling."""
        lines = content.split('\n')
        html_lines = []
        for line in lines:
            line = line.strip()
            if not line:
                html_lines.append("<br>")
            elif line.startswith('## '):
                html_lines.append(f"<h2>{line[3:]}</h2>")
            elif line.startswith('# '):
                html_lines.append(f"<h1>{line[2:]}</h1>")
            elif line.startswith('- ') or line.startswith('* '):
                html_lines.append(f"<li>{line[2:]}</li>")
            else:
                safe = (line.replace('&','&amp;').replace('<','&lt;')
                           .replace('>','&gt;'))
                # Bold **text**
                safe = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', safe)
                # Italic *text*
                safe = re.sub(r'\*(.+?)\*', r'<em>\1</em>', safe)
                html_lines.append(f"<p>{safe}</p>")

        body = "\n".join(html_lines)
        return f"""<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{title}</title>
  <style>
    body{{font-family:'Helvetica Neue',Arial,sans-serif;max-width:800px;margin:0 auto;
          padding:2rem;color:#1a1a1a;line-height:1.7}}
    h1{{color:#F0A020;border-bottom:2px solid #F0A020;padding-bottom:.5rem}}
    h2{{color:#333;margin-top:2rem}}
    li{{margin:.3rem 0}}
    .footer{{margin-top:3rem;padding-top:1rem;border-top:1px solid #eee;
             color:#888;font-size:.8rem;text-align:center}}
  </style>
</head>
<body>
  <h1>{title}</h1>
  <p style="color:#888;font-size:.85rem">
    Generated by BeeQ · {datetime.now().strftime('%Y-%m-%d %H:%M')}
  </p>
  <hr>
  {body}
  <div class="footer">Generated by BeeQ — beeq.run</div>
</body>
</html>"""

    def _title_to_filename(self, task: str, ext: str) -> str:
        """Convert task description to safe filename."""
        ts = datetime.now().strftime('%Y%m%d_%H%M%S')
        # Take first 5 words, slugify
        words = re.sub(r'[^a-zA-Z0-9\s]', '', task).split()[:5]
        slug = '_'.join(w.lower() for w in words if w) or "document"
        return f"{ts}_{slug}{ext}"
