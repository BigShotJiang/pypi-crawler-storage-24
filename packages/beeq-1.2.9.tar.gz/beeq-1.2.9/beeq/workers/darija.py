"""
BeeQ Darija — Worker spécialisé langue darija (arabe marocain).

Le fellah de Tiznit parle darija. BeeQ lui répond en darija.

Capacités:
  - Comprendre des missions formulées en darija
  - Répondre en darija avec le même registre que l'utilisateur
  - Traduction darija ↔ français ↔ anglais ↔ tamazight
  - Reformulation technique en darija courant
  - Support billingue (darija + français ou arabe standard)

Pourquoi c'est important:
  ~35 millions de locuteurs darija au Maroc
  Langue principale de communication quotidienne
  Pas de LLM mainstream optimisé pour le darija
  BeeQ peut être le premier agent vraiment accessible au Maroc

Z = dI/d(log s) · exp(iθ)
  La langue = le canal de transmission de l'information
  Si le canal est incorrect → θ ≠ 0 → Z chute
  Darija natif → θ → 0 → Z maximal pour l'utilisateur marocain
"""

from .base import BaseWorker, WorkerResult

# Darija vocabulaire de base pour la Queen
DARIJA_SYSTEM = """أنت مساعد ذكي يتكلم الدارجة المغربية.
الدارجة هي اللغة العامية المغربية.
جاوب دايما بالدارجة إلا إذا خصك تترجم.
استخدم الخط العربي لكتابة الدارجة.

نماذج من الدارجة:
- "واش كاين شي مشكل؟" = "Est-ce qu'il y a un problème?"
- "خويا/أختي" = "mon frère/ma sœur" (termes d'adresse amicaux)
- "مزيان/مزيانة" = "bien/bonne"
- "بزاف" = "beaucoup"
- "باغي/باغية" = "je veux"
- "فين" = "où"
- "علاش" = "pourquoi"
- "كيفاش" = "comment"
- "شحال" = "combien"

Pour les termes techniques (AI, ordinateur, etc.), garde le terme français/anglais
et explique en darija: "AI (ذكاء اصطناعي) = الطوموبيل ديال الكمبيوتر"
"""


class DarijaWorker(BaseWorker):
    name          = "darija"
    description   = "Darija language specialist — understand and respond in Moroccan Arabic"
    default_scope = ["translate:darija", "respond:darija", "analyze:text"]

    async def execute(self, task: str, context: dict | None = None) -> WorkerResult:
        ctx    = context or {}
        action = ctx.get("action", "auto")

        try:
            if action == "translate":
                return await self._translate(task, ctx)
            if action == "respond":
                return await self._respond_darija(task, ctx)
            if action == "detect":
                return await self._detect_language(task, ctx)

            # Auto: détecter si c'est du darija, puis agir
            lang = await self._detect_language_fast(task)
            if lang in ("darija", "arabic"):
                return await self._respond_darija(task, ctx)
            else:
                return await self._translate_to_darija(task, ctx)

        except Exception as e:
            self._record("translate:darija", False, task.encode(), str(e).encode())
            return WorkerResult(self.name, "translate:darija", False, "", error=str(e))

    # ── RESPOND IN DARIJA ─────────────────────────────────────────

    async def _respond_darija(self, task: str, ctx: dict) -> WorkerResult:
        """Respond to a query in darija."""
        tone = ctx.get("tone", "friendly")
        domain = ctx.get("domain", "general")

        system = DARIJA_SYSTEM
        if domain == "agriculture":
            system += "\nأنت خبير ف الفلاحة والزراعة المغربية."
        elif domain == "health":
            system += "\nأنت خبير ف الصحة. دايما قل للمريض يشوف الطبيب."
        elif domain == "technology":
            system += "\nأنت خبير ف التكنولوجيا والكمبيوتر."

        resp = await self.providers.complete(
            messages=[{"role": "user", "content": task}],
            system=system,
            max_tokens=512,
        )

        artifact = self._record("respond:darija", True, task.encode(), resp.content.encode())
        return WorkerResult(
            self.name, "respond:darija", True, resp.content,
            artifacts=[artifact],
            metadata={"language": "darija", "domain": domain},
        )

    # ── TRANSLATE ────────────────────────────────────────────────

    async def _translate(self, task: str, ctx: dict) -> WorkerResult:
        """Translate between darija and other languages."""
        target = ctx.get("target", "français")
        source = ctx.get("source", "auto")

        prompt = f"""Translate this text to {target}.
If the source is darija (Moroccan Arabic), translate naturally preserving the tone.
If the source is {target}, translate to darija.

Text: {task}

Provide:
1. Translation in {target}
2. Brief cultural note if relevant (optional)"""

        resp = await self.providers.complete(
            messages=[{"role": "user", "content": prompt}],
            max_tokens=512,
        )

        artifact = self._record("translate:darija", True,
                               task.encode(), resp.content.encode())
        return WorkerResult(
            self.name, "translate:darija", True, resp.content,
            artifacts=[artifact],
            metadata={"source": source, "target": target},
        )

    async def _translate_to_darija(self, task: str, ctx: dict) -> WorkerResult:
        """Translate French/English text to darija."""
        return await self._translate(task, {**ctx, "target": "darija marocaine (الدارجة المغربية)"})

    # ── DETECT ───────────────────────────────────────────────────

    async def _detect_language(self, task: str, ctx: dict) -> WorkerResult:
        """Detect if text is darija, MSA, French, etc."""
        lang = await self._detect_language_fast(task)
        return WorkerResult(self.name, "analyze:text", True,
                           f"Detected language: {lang}",
                           metadata={"language": lang})

    async def _detect_language_fast(self, text: str) -> str:
        """Fast heuristic language detection."""
        import unicodedata
        # Count Arabic chars
        arabic = sum(1 for c in text if '\u0600' <= c <= '\u06FF')
        latin  = sum(1 for c in text if c.isalpha() and c.isascii())

        if arabic > latin * 0.5:
            # Arabic script — could be darija or MSA
            # Darija markers
            darija_markers = ["واش", "كيفاش", "بزاف", "مزيان", "خويا",
                             "باغي", "فين", "علاش", "شحال", "ديال",
                             "كاين", "راه", "غادي", "بغيت", "ماشي"]
            if any(m in text for m in darija_markers):
                return "darija"
            return "arabic"

        # Detect French vs English by common words
        fr_words = ["le", "la", "les", "de", "du", "et", "est", "je", "tu", "nous", "vous"]
        en_words = ["the", "is", "are", "and", "of", "to", "in", "it", "this", "that"]
        words = text.lower().split()
        fr_count = sum(1 for w in words if w in fr_words)
        en_count = sum(1 for w in words if w in en_words)

        if fr_count > en_count:
            return "french"
        if en_count > fr_count:
            return "english"
        return "unknown"
