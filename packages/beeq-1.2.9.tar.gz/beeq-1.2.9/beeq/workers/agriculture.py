"""
BeeQ Agriculture — Worker spécialisé agriculture et agronomie.

Scope: analyze:soil · search:crop · monitor:weather · plan:irrigation

Capacités:
  - Analyse sol: pH, humidité, nutriments → recommandations
  - Météo agricole: prévisions + indices (ETP, GDD, stress hydrique)
  - Calendrier cultural: semis, récolte, traitements selon région/culture
  - Maladies et ravageurs: identification + traitement
  - Marché agricole: prix, tendances

Régions supportées: Maroc (Souss, Gharb, Tadla, Haouz, Saiss...)
PHY §1 (entropie): chaque saison sans maintenance dégrade le sol
PHY §6 (seuil): stress hydrique > 80% = perte de rendement irréversible
"""

from .base import BaseWorker, WorkerResult


# Calendrier cultural Maroc (simplifié)
MAROC_CALENDAR = {
    "tomate":      {"semis": [1,2], "plantation": [3,4,9,10], "recolte": [6,7,12,1]},
    "orge":        {"semis": [11,12], "recolte": [5,6]},
    "ble":         {"semis": [11,12], "recolte": [6,7]},
    "agrumes":     {"recolte": [11,12,1,2,3,4]},
    "olivier":     {"recolte": [10,11,12]},
    "arganier":    {"recolte": [7,8]},
    "luzerne":     {"semis": [9,10,3,4], "coupe": [3,4,5,6,7,8,9,10]},
    "pomme_terre": {"plantation": [2,3,9,10], "recolte": [5,6,12,1]},
}

# Valeurs pH optimales par culture
PH_OPTIMAL = {
    "tomate": (6.0, 7.0), "orge": (6.0, 7.5), "ble": (6.0, 7.5),
    "luzerne": (6.5, 7.5), "pomme_terre": (5.5, 6.5),
    "agrumes": (5.5, 6.5), "olivier": (6.0, 8.0),
}


class AgricultureWorker(BaseWorker):
    name          = "agriculture"
    description   = "Agricultural specialist: soil analysis, crop calendar, weather, market"
    default_scope = ["analyze:soil", "search:crop", "monitor:weather", "plan:irrigation"]

    async def execute(self, task: str, context: dict | None = None) -> WorkerResult:
        ctx    = context or {}
        action = ctx.get("action", "auto")
        task_l = task.lower()
        try:
            if action == "soil" or any(w in task_l for w in ["sol", "ph", "soil", "nutriment"]):
                return await self._analyze_soil(task, ctx)
            if action == "calendar" or any(w in task_l for w in ["semis", "plantation", "récolte", "calendrier"]):
                return await self._crop_calendar(task, ctx)
            if action == "weather" or any(w in task_l for w in ["météo", "pluie", "température", "weather"]):
                return await self._weather_advice(task, ctx)
            if action == "disease" or any(w in task_l for w in ["maladie", "ravageur", "parasite", "disease"]):
                return await self._disease_diagnosis(task, ctx)
            if action == "irrigation" or any(w in task_l for w in ["irrigation", "eau", "arrosage"]):
                return await self._irrigation_plan(task, ctx)
            # Default: LLM avec contexte agronomique
            return await self._agro_advice(task, ctx)
        except Exception as e:
            self._record("analyze:soil", False, task.encode(), str(e).encode())
            return WorkerResult(self.name, "analyze:soil", False, "", error=str(e))

    async def _analyze_soil(self, task: str, ctx: dict) -> WorkerResult:
        """Analyze soil parameters and give recommendations."""
        ph      = ctx.get("ph")
        culture = ctx.get("culture", "").lower()
        humidite = ctx.get("humidite")
        region  = ctx.get("region", "Maroc")

        system = """Tu es un agronome expert en agriculture marocaine.
Analyse les données sol et donne des recommandations précises et pratiques.
Format: problème identifié → action recommandée → produit/dose si applicable.
Toujours inclure les risques PHY (irréversibilité, seuils critiques)."""

        content = f"Analyse sol pour {region}:\n"
        if ph:
            content += f"- pH mesuré: {ph}\n"
            if culture and culture in PH_OPTIMAL:
                lo, hi = PH_OPTIMAL[culture]
                if float(ph) < lo:
                    content += f"  → pH trop acide pour {culture} (optimal {lo}-{hi}): chaulage recommandé\n"
                elif float(ph) > hi:
                    content += f"  → pH trop alcalin pour {culture} (optimal {lo}-{hi}): soufre ou matière organique\n"
                else:
                    content += f"  → pH optimal pour {culture} ✓\n"
        if humidite:
            content += f"- Humidité sol: {humidite}%\n"
            if float(humidite) < 30:
                content += "  → ALERTE SÉCHERESSE: stress hydrique critique (PHY §6)\n"
            elif float(humidite) > 80:
                content += "  → Excès eau: risque pourriture racinaire\n"
        content += f"\nQuestion: {task}"

        resp = await self.providers.complete(
            messages=[{"role": "user", "content": content}],
            system=system,
            max_tokens=512,
        )
        artifact = self._record("analyze:soil", True, task.encode(), resp.content.encode())
        return WorkerResult(
            self.name, "analyze:soil", True, resp.content,
            artifacts=[artifact],
            metadata={"ph": ph, "humidite": humidite, "culture": culture},
        )

    async def _crop_calendar(self, task: str, ctx: dict) -> WorkerResult:
        """Crop calendar for Morocco."""
        culture = ctx.get("culture", "").lower()
        region  = ctx.get("region", "Maroc")
        mois    = ctx.get("mois")  # 1-12

        lines = [f"📅 Calendrier cultural — {region}\n"]

        if culture and culture in MAROC_CALENDAR:
            cal = MAROC_CALENDAR[culture]
            lines.append(f"Culture: {culture.upper()}")
            for op, mois_list in cal.items():
                mois_noms = ["Jan","Fév","Mar","Avr","Mai","Jun",
                            "Jul","Aoû","Sep","Oct","Nov","Déc"]
                noms = [mois_noms[m-1] for m in mois_list]
                lines.append(f"  {op}: {', '.join(noms)}")
        elif mois:
            lines.append(f"Mois {mois} — Cultures en cours:")
            for cult, cal in MAROC_CALENDAR.items():
                for op, mois_list in cal.items():
                    if int(mois) in mois_list:
                        lines.append(f"  → {cult}: {op}")
        else:
            # LLM pour une requête libre
            resp = await self.providers.complete(
                messages=[{"role": "user", "content": f"Calendrier agricole Maroc: {task}"}],
                system="Tu es agronome expert Maroc. Réponds de façon pratique et concise.",
                max_tokens=400,
            )
            lines.append(resp.content)

        output = "\n".join(lines)
        artifact = self._record("search:crop", True, task.encode(), output.encode())
        return WorkerResult(
            self.name, "search:crop", True, output,
            artifacts=[artifact],
            metadata={"culture": culture, "region": region},
        )

    async def _weather_advice(self, task: str, ctx: dict) -> WorkerResult:
        """Weather-based agricultural advice."""
        resp = await self.providers.complete(
            messages=[{"role": "user", "content": task}],
            system=(
                "Tu es agronome et météorologue agricole expert Maroc. "
                "Donne des conseils pratiques basés sur les conditions météo. "
                "Inclus: irrigation, traitements, protections gel/chaleur."
            ),
            max_tokens=400,
        )
        artifact = self._record("monitor:weather", True, task.encode(), resp.content.encode())
        return WorkerResult(self.name, "monitor:weather", True, resp.content, artifacts=[artifact])

    async def _disease_diagnosis(self, task: str, ctx: dict) -> WorkerResult:
        """Identify and treat crop diseases."""
        symptomes = ctx.get("symptomes", task)
        culture   = ctx.get("culture", "")
        resp = await self.providers.complete(
            messages=[{"role": "user", "content": f"Culture: {culture}\nSymptômes: {symptomes}"}],
            system=(
                "Tu es phytopathologiste expert agriculture marocaine. "
                "Identifie la maladie/ravageur et propose le traitement (biologique préféré). "
                "Format: 1.Diagnostic 2.Cause 3.Traitement 4.Prévention"
            ),
            max_tokens=512,
        )
        artifact = self._record("analyze:soil", True, task.encode(), resp.content.encode())
        return WorkerResult(self.name, "analyze:soil", True, resp.content, artifacts=[artifact])

    async def _irrigation_plan(self, task: str, ctx: dict) -> WorkerResult:
        """Generate irrigation plan."""
        culture  = ctx.get("culture", "")
        surface  = ctx.get("surface_ha", 1)
        methode  = ctx.get("methode", "goutte-à-goutte")
        resp = await self.providers.complete(
            messages=[{"role": "user", "content":
                f"Plan irrigation: {culture}, {surface} ha, {methode}\n{task}"}],
            system=(
                "Tu es expert irrigation et économie d'eau Maroc. "
                "Calcule les besoins hydriques et propose un calendrier d'irrigation. "
                "Inclus: dose/apport, fréquence, stades critiques. "
                "PHY §1: entropie = gaspillage d'eau = déséquilibre sol."
            ),
            max_tokens=512,
        )
        artifact = self._record("plan:irrigation", True, task.encode(), resp.content.encode())
        return WorkerResult(self.name, "plan:irrigation", True, resp.content, artifacts=[artifact])

    async def _agro_advice(self, task: str, ctx: dict) -> WorkerResult:
        """General agronomic advice."""
        resp = await self.providers.complete(
            messages=[{"role": "user", "content": task}],
            system=(
                "Tu es agronome expert agriculture durable Maroc. "
                "Réponds de façon pratique, locale et précise. "
                "Cite toujours les risques climatiques et les seuils critiques (PHY)."
            ),
            max_tokens=512,
        )
        artifact = self._record("search:crop", True, task.encode(), resp.content.encode())
        return WorkerResult(self.name, "search:crop", True, resp.content, artifacts=[artifact])
