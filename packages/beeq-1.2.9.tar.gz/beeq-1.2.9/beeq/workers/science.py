"""
BeeQ Science — Worker spécialisé recherche scientifique.

Scope: search:arxiv · search:pubmed · analyze:paper

Z = dI/d(log s) · exp(iθ)
  Science = domaine où dI est maximal par nature
"""

import json
import urllib.request
import urllib.parse
from .base import BaseWorker, WorkerResult


class ScienceWorker(BaseWorker):
    name          = "science"
    description   = "Scientific research: arxiv, pubmed, paper analysis, replication"
    default_scope = ["search:arxiv", "search:pubmed", "analyze:paper"]

    async def execute(self, task: str, context: dict | None = None) -> WorkerResult:
        ctx    = context or {}
        action = ctx.get("action", "auto")
        task_l = task.lower()
        try:
            if action == "arxiv" or "arxiv" in task_l:
                return await self._search_arxiv(task, ctx)
            if action == "pubmed" or "pubmed" in task_l or "medical" in task_l:
                return await self._search_pubmed(task, ctx)
            if action in ("analyze", "summarize") or any(w in task_l for w in ["analys", "summar"]):
                return await self._analyze_paper(task, ctx)
            return await self._search_arxiv(task, ctx)
        except Exception as e:
            self._record("search:arxiv", False, task.encode(), str(e).encode())
            return WorkerResult(self.name, "search:arxiv", False, "", error=str(e))

    # ── ARXIV ────────────────────────────────────────────────────

    async def _search_arxiv(self, query: str, ctx: dict) -> WorkerResult:
        """Search arxiv API — no key required."""
        max_results = ctx.get("max_results", 5)
        category    = ctx.get("category", "")
        clean_q = query.replace("arxiv", "").replace("papers", "").strip()
        if category:
            q = f"cat:{category}+AND+ti:{urllib.parse.quote(clean_q)}"
        else:
            q = f"all:{urllib.parse.quote(clean_q)}"
        url = (f"https://export.arxiv.org/api/query"
               f"?search_query={q}&max_results={max_results}"
               f"&sortBy=relevance&sortOrder=descending")
        req = urllib.request.Request(url, headers={"User-Agent": "BeeQ/1.2.3"})
        with urllib.request.urlopen(req, timeout=15) as resp:
            xml = resp.read().decode()
        papers = self._parse_arxiv(xml)
        if not papers:
            return WorkerResult(self.name, "search:arxiv", True,
                               f"No papers found for: {query}")
        lines = [f"Found {len(papers)} papers on arxiv:\n"]
        for i, p in enumerate(papers, 1):
            lines.append(f"[{i}] {p['title']}")
            lines.append(f"     Authors: {p['authors']}")
            lines.append(f"     Date: {p['published'][:10]}")
            lines.append(f"     URL: {p['url']}")
            lines.append(f"     Abstract: {p['abstract'][:200]}...")
            lines.append("")
        output = "\n".join(lines)
        artifact = self._record("search:arxiv", True, query.encode(), output.encode())
        return WorkerResult(
            self.name, "search:arxiv", True, output,
            artifacts=[artifact],
            metadata={"count": len(papers), "query": query, "papers": papers},
        )

    def _parse_arxiv(self, xml: str) -> list[dict]:
        """Parse arxiv Atom XML — no deps, no closures."""
        import re as _re
        papers = []

        def _tag(text, tag):
            m = _re.search(rf'<{tag}[^>]*>(.*?)</{tag}>', text, _re.DOTALL)
            return m.group(1).strip() if m else ""

        entries = _re.findall(r'<entry>(.*?)</entry>', xml, _re.DOTALL)
        for entry in entries:
            authors_raw = _re.findall(r'<n>(.*?)</n>', entry)
            authors_str = ", ".join(a.strip() for a in authors_raw[:3])
            if len(authors_raw) > 3:
                authors_str += f" et al. ({len(authors_raw)} total)"
            raw_id   = _tag(entry, "id")
            arxiv_id = raw_id.split("/abs/")[-1] if "/abs/" in raw_id else raw_id
            papers.append({
                "title":     _tag(entry, "title").replace("\n", " ").strip(),
                "authors":   authors_str,
                "abstract":  _tag(entry, "summary").replace("\n", " ").strip(),
                "published": _tag(entry, "published"),
                "url":       f"https://arxiv.org/abs/{arxiv_id}",
                "id":        arxiv_id,
            })
        return papers

    # ── PUBMED ───────────────────────────────────────────────────

    async def _search_pubmed(self, query: str, ctx: dict) -> WorkerResult:
        """Search PubMed (NCBI) — no key required."""
        max_results = ctx.get("max_results", 5)
        clean_q = query.replace("pubmed", "").replace("medical", "").strip()
        search_url = (
            f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
            f"?db=pubmed&term={urllib.parse.quote(clean_q)}"
            f"&retmax={max_results}&retmode=json"
        )
        req = urllib.request.Request(search_url, headers={"User-Agent": "BeeQ/1.2.3"})
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = json.loads(resp.read())
        except Exception as e:
            return WorkerResult(self.name, "search:pubmed", True,
                               f"PubMed unavailable: {e}", metadata={"count": 0, "papers": []})

        ids = data.get("esearchresult", {}).get("idlist", [])
        if not ids:
            return WorkerResult(self.name, "search:pubmed", True,
                               f"No PubMed results for: {query}",
                               metadata={"count": 0, "papers": []})
        fetch_url = (
            f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi"
            f"?db=pubmed&id={','.join(ids)}&retmode=json"
        )
        req2 = urllib.request.Request(fetch_url, headers={"User-Agent": "BeeQ/1.2.3"})
        with urllib.request.urlopen(req2, timeout=15) as resp:
            summaries = json.loads(resp.read())

        result_data = summaries.get("result", {})
        lines = [f"Found {len(ids)} PubMed articles:\n"]
        papers = []
        for pmid in ids:
            article = result_data.get(pmid, {})
            title   = article.get("title", "?")
            authors = ", ".join(a.get("name", "") for a in article.get("authors", [])[:3])
            pub_date = article.get("pubdate", "")
            url = f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/"
            lines.append(f"[PMID:{pmid}] {title}")
            lines.append(f"  Authors: {authors}  |  {pub_date}  |  {url}")
            lines.append("")
            papers.append({"pmid": pmid, "title": title, "url": url})

        output = "\n".join(lines)
        artifact = self._record("search:pubmed", True, query.encode(), output.encode())
        return WorkerResult(self.name, "search:pubmed", True, output,
                           artifacts=[artifact],
                           metadata={"count": len(ids), "papers": papers})

    # ── ANALYZE ──────────────────────────────────────────────────

    async def _analyze_paper(self, task: str, ctx: dict) -> WorkerResult:
        """Analyze a paper via LLM — structured extraction."""
        abstract = ctx.get("abstract", "")
        content  = ctx.get("content", "")
        url      = ctx.get("url", "")

        if url and not content:
            try:
                req = urllib.request.Request(url, headers={"User-Agent": "BeeQ/1.2.3"})
                with urllib.request.urlopen(req, timeout=10) as r:
                    content = r.read().decode()[:5000]
            except Exception:
                pass

        prompt = (
            f"Analyze this scientific paper:\n{task}\n"
            f"{f'Abstract: {abstract}' if abstract else ''}\n"
            f"{f'Content: {content[:2000]}' if content else ''}\n\n"
            "Extract:\n1. PROBLEM\n2. METHOD\n3. RESULTS\n4. LIMITATIONS\n5. Z-RELEVANCE"
        )
        resp = await self.providers.complete(
            messages=[{"role": "user", "content": prompt}],
            max_tokens=1024,
        )
        artifact = self._record("analyze:paper", True, task.encode(), resp.content.encode())
        return WorkerResult(self.name, "analyze:paper", True, resp.content,
                           artifacts=[artifact])
