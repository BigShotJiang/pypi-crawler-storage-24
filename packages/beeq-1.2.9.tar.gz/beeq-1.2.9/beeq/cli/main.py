"""
BeeQ CLI — beeq <command>

Commands:
  start     Start the hive (Queen + workers + dashboard)
  stop      Stop the hive
  mission   Give a mission
  status    Hive status + audit chain
  log       Show audit chain
  verify    Verify an action hash
  workers   List workers
  revoke    Revoke a worker
  connect   Configure LLM provider
  memory    Manage sovereign memory
  version   Show version
"""

import asyncio
import click
from rich.console import Console
from rich.table   import Table
from rich         import box

console = Console()


def header():
    console.print()
    console.print("  [bold yellow]BeeQ[/bold yellow] [dim]— The First AI Hive[/dim]")
    console.print("  [dim]Every action signed. You remain sovereign.[/dim]")
    console.print()


@click.group()
def cli():
    """BeeQ — The First AI Hive."""
    pass


@cli.command()
@click.option("--port", default=7935, help="Dashboard port")
@click.option("--provider", default=None, help="LLM provider (claude/openai/ollama)")
def start(port, provider):
    """Start the BeeQ hive + dashboard."""
    header()
    console.print(f"  [dim]Starting hive...[/dim]")

    async def _run():
        from beeq.core import BeeQ
        hive = BeeQ()
        await hive.setup(provider=provider)

        workers = list(hive.governance.workers.keys())
        console.print(f"  [green]✓[/green] Queen ready")
        console.print(f"  [green]✓[/green] {len(workers)} workers: {', '.join(workers)}")
        console.print()
        console.print(f"  Dashboard: [bold yellow]http://localhost:{port}[/bold yellow]")
        console.print(f"  Verify:    [bold]https://beeq.run/verify/<hash>[/bold]")
        console.print()
        console.print("  [dim]Press Ctrl+C to stop.[/dim]")
        console.print()

        from beeq.dashboard.server import create_app
        app, uvicorn = create_app(hive)
        config = uvicorn.Config(app, host="0.0.0.0", port=port, log_level="error")
        server = uvicorn.Server(config)
        await server.serve()

    asyncio.run(_run())


@cli.command()
@click.argument("text", nargs=-1)
@click.option("--provider", default=None)
def mission(text, provider):
    """Give a mission to the hive."""
    if not text:
        console.print("[red]Error:[/red] Please provide a mission.")
        return

    mission_text = " ".join(text)
    header()
    console.print(f"  [bold]Mission:[/bold] {mission_text}")
    console.print()

    async def _run():
        from beeq.core import BeeQ
        hive = BeeQ()
        await hive.setup(provider=provider)

        with console.status("[yellow]Queen orchestrating...[/yellow]"):
            # Sign intention first
            from beeq.dashboard.server import _sign_intention
            intention = await _sign_intention(hive, mission_text)

        console.print("  [bold yellow]⚡ Intention Signed (BEFORE acting):[/bold yellow]")
        console.print(f"  [dim]{intention[:200]}...[/dim]" if len(intention) > 200 else f"  [dim]{intention}[/dim]")
        console.print()

        with console.status("[yellow]Workers executing...[/yellow]"):
            m = await hive.execute(mission_text)

        for r in m.results:
            icon = "✅" if r.success else "❌"
            console.print(f"  {icon} [{r.worker}]")
            console.print(f"  [dim]{r.output[:500]}[/dim]")
            console.print()

        audit = hive.audit()
        chain = "INTACT" if audit["valid"] else "ERROR"
        color = "green" if audit["valid"] else "red"
        console.print(f"  [{color}]Chain: {chain}[/{color}] · {audit['actions']} action(s) signed")
        console.print()

    asyncio.run(_run())


@cli.command()
@click.option("--provider", default=None)
def status(provider):
    """Show hive status + audit chain."""
    async def _run():
        from beeq.core import BeeQ
        hive = BeeQ()
        await hive.setup(provider=provider)
        audit = hive.audit()
        header()

        t = Table(box=box.SIMPLE, show_header=False, padding=(0,1))
        t.add_column("K", style="dim", width=12)
        t.add_column("V")
        t.add_row("Workers", str(len(audit["workers"])))
        t.add_row("Actions", str(audit["actions"]))
        t.add_row("Chain", "[green]INTACT[/green]" if audit["valid"] else "[red]ERROR[/red]")
        console.print(t)

    asyncio.run(_run())


@cli.command()
@click.argument("hash_id")
@click.option("--provider", default=None)
def verify(hash_id, provider):
    """Verify an action hash from the audit chain."""
    async def _run():
        from beeq.core import BeeQ
        import hashlib
        hive = BeeQ()
        await hive.setup(provider=provider)

        for e in hive.governance.audit_entries:
            ts = e.timestamp.isoformat() if hasattr(e.timestamp, "isoformat") else str(e.timestamp)
            h = hashlib.sha256(f"{e.agent_id}{e.action}{ts}".encode()).hexdigest()
            if h.startswith(hash_id) or h == hash_id:
                worker = (e.agent_id or "").split("/")[-1].split("@")[0]
                console.print(f"\n  [green]✅ Valid[/green]")
                console.print(f"  Worker:    {worker}")
                console.print(f"  Action:    {e.action}")
                console.print(f"  Result:    {e.result}")
                console.print(f"  Timestamp: {ts}")
                console.print(f"  Hash:      {h}")
                return

        console.print(f"\n  [yellow]Hash not found in current session.[/yellow]")
        console.print(f"  [dim]Start the same hive instance to verify historical actions.[/dim]")

    asyncio.run(_run())


@cli.command()
@click.option("--last", default=20, help="Number of entries")
@click.option("--provider", default=None)
def log(last, provider):
    """Show audit chain."""
    async def _run():
        import hashlib
        from beeq.core import BeeQ
        hive = BeeQ()
        await hive.setup(provider=provider)

        entries = list(hive.governance.audit_entries)[-last:]
        if not entries:
            console.print("  [dim]No actions yet.[/dim]")
            return

        t = Table(box=box.SIMPLE, padding=(0,1))
        t.add_column("Worker", style="yellow", width=10)
        t.add_column("Action", style="cyan", width=16)
        t.add_column("Result", width=8)
        t.add_column("Hash", style="dim", width=18)

        for e in reversed(entries):
            ts = e.timestamp.isoformat() if hasattr(e.timestamp, "isoformat") else str(e.timestamp)
            h  = hashlib.sha256(f"{e.agent_id}{e.action}{ts}".encode()).hexdigest()[:16]
            worker = (e.agent_id or "").split("/")[-1].split("@")[0]
            color  = "green" if e.result == "success" else "red"
            t.add_row(worker, e.action, f"[{color}]{e.result}[/{color}]", h + "...")
        console.print(t)

    asyncio.run(_run())


@cli.command()
@click.option("--provider", default=None)
def workers(provider):
    """List active workers + their scopes."""
    async def _run():
        from beeq.core import BeeQ
        hive = BeeQ()
        await hive.setup(provider=provider)
        header()
        for name, w in hive.governance.workers.items():
            status = "[red]REVOKED[/red]" if not w.authorization.is_valid() else "[green]active[/green]"
            scope  = ", ".join(w.identity.scope)
            console.print(f"  {name:12} {status}  [dim]{scope}[/dim]")
        console.print()

    asyncio.run(_run())


@cli.command()
@click.argument("worker_name")
@click.option("--provider", default=None)
def revoke(worker_name, provider):
    """Revoke a worker (LEX §5)."""
    async def _run():
        from beeq.core import BeeQ
        hive = BeeQ()
        await hive.setup(provider=provider)
        hive.governance.revoke_worker(worker_name)
        console.print(f"  [red]✗[/red] Worker '{worker_name}' revoked. LEX §5 applied.")

    asyncio.run(_run())


@cli.command()
@click.argument("text", nargs=-1)
@click.option("--provider", default=None)
def memory(text, provider):
    """Manage sovereign memory. Usage: beeq memory [search query]"""
    async def _run():
        from beeq.core import BeeQ
        hive = BeeQ()
        await hive.setup(provider=provider)

        if text:
            query   = " ".join(text)
            results = await hive.recall(query)
            if results:
                for r in results:
                    console.print(f"  [{r['id'][:8]}] [dim]{r['content'][:100]}[/dim]")
            else:
                console.print("  [dim]Nothing found.[/dim]")
        else:
            if hive.memory:
                console.print(f"  [dim]{hive.memory.summary()}[/dim]")

    asyncio.run(_run())


@cli.command()
@click.argument("provider_name")
@click.option("--key", default=None, help="API key")
@click.option("--model", default=None, help="Model name")
def connect(provider_name, key, model):
    """Configure LLM provider."""
    import json
    from pathlib import Path

    cfg_path = Path.home() / ".beeq" / "config.json"
    cfg_path.parent.mkdir(parents=True, exist_ok=True)
    cfg = json.loads(cfg_path.read_text()) if cfg_path.exists() else {}

    cfg["default_provider"] = provider_name
    if "providers" not in cfg:
        cfg["providers"] = {}
    if provider_name not in cfg["providers"]:
        cfg["providers"][provider_name] = {}
    if key:
        cfg["providers"][provider_name]["api_key"] = key
    if model:
        cfg["providers"][provider_name]["model"] = model

    cfg_path.write_text(json.dumps(cfg, indent=2))
    console.print(f"  [green]✓[/green] Provider '{provider_name}' configured.")


@cli.command()
def version():
    """Show BeeQ version."""
    from beeq import __version__
    console.print(f"\n  [bold yellow]BeeQ[/bold yellow] v{__version__}")
    console.print(f"  [dim]https://beeq.run[/dim]\n")



@cli.command()
@click.option("--telegram", is_flag=True, help="Send to Telegram")
@click.option("--install-cron", is_flag=True, help="Install daily cron at 7:00 AM")
def brief(telegram, install_cron):
    """Generate and display the morning brief (system state + suggestions)."""
    if install_cron:
        from beeq.brief import install_cron as _install
        _install()
        return
    async def _run():
        from beeq.brief import run_brief
        await run_brief(send_telegram=telegram)
    asyncio.run(_run())



@cli.command()
@click.option("--no-claude", is_flag=True, help="Skip Claude API tests (local only)")
@click.option("--output", default=None, help="Save JSON results to file")
def benchmark(no_claude, output):
    """Run full BeeQ benchmark suite — 56 tests, all components + Claude."""
    import os
    from pathlib import Path
    if no_claude:
        os.environ.pop("ANTHROPIC_API_KEY", None)
    elif not os.environ.get("ANTHROPIC_API_KEY"):
        cfg_path = Path.home() / ".beeq" / "config.json"
        if cfg_path.exists():
            import json as _json
            try:
                cfg = _json.loads(cfg_path.read_text())
                key = cfg.get("providers", {}).get("claude", {}).get("api_key", "")
                if key:
                    os.environ["ANTHROPIC_API_KEY"] = key
            except Exception:
                pass
    async def _run():
        from beeq.benchmark import main as bench_main
        results = await bench_main()
        if output:
            import json as _json
            Path(output).write_text(_json.dumps(results, indent=2))
            click.echo(f"\nResults saved: {output}")
    asyncio.run(_run())



@cli.command()
@click.argument("message")
def commit(message):
    """Snapshot hive state with a message. Like git commit."""
    from beeq.agent_git import AgentGit
    git = AgentGit()
    c = git.commit(message)
    click.echo(f"[{c.branch}] {c.hash[:8]} {c.message}")
    click.echo(f"  Workers : {', '.join(c.active_workers) or 'none'}")
    click.echo(f"  PIAs    : {len(c.pia_ids)}")
    click.echo(f"  Verify  : {c.hash[:8]} (beeq log to see history)")


@cli.command()
@click.argument("name")
@click.option("--from", "from_commit", default=None, help="Start from specific commit")
def branch(name, from_commit):
    """Create and switch to a new branch. Like git checkout -b."""
    from beeq.agent_git import AgentGit
    git = AgentGit()
    b = git.branch(name, from_commit=from_commit)
    click.echo(f"Switched to new branch '{b}'")


@cli.command()
@click.argument("target")
def checkout(target):
    """Switch to a branch or commit."""
    from beeq.agent_git import AgentGit
    git = AgentGit()
    msg = git.checkout(target)
    click.echo(msg)


@cli.command()
@click.argument("target")
def rollback(target):
    """Restore hive state from a previous commit (creates new commit)."""
    from beeq.agent_git import AgentGit
    git = AgentGit()
    c = git.rollback(target)
    click.echo(f"Rolled back to {target}")
    click.echo(f"New commit: [{c.branch}] {c.hash[:8]} {c.message}")


@cli.command("log")
@click.option("--branch", "-b", default=None, help="Branch to show")
@click.option("-n", default=10, help="Number of commits")
def git_log(branch, n):
    """Show commit history."""
    from beeq.agent_git import AgentGit
    git = AgentGit()
    st = git.status()
    click.echo(f"On branch {st['branch']} — HEAD: {st['head_short']}")
    if st['uncommitted']:
        click.echo("  (uncommitted changes)")
    click.echo()
    commits = git.log(branch=branch, n=n)
    if not commits:
        click.echo('  No commits yet. Use: beeq commit "first snapshot"')
        return
    for c in commits:
        click.echo(c.summary())


@cli.command("branches")
def git_branches():
    """List all branches."""
    from beeq.agent_git import AgentGit
    git = AgentGit()
    st = git.status()
    for name, tip in git.branches().items():
        marker = "* " if name == st['branch'] else "  "
        click.echo(f"{marker}{name:20} {tip}")



@cli.command("hub")
@click.argument("action", type=click.Choice(["install", "list", "verify", "remove", "sign"]))
@click.argument("target", default="")
def hub(action, target):
    """BeeQ Hub — install, verify and manage skills.

    \b
    beeq hub list                    — list installed skills
    beeq hub install ./my.skill.md   — install from local file
    beeq hub install mehdi/labo-z    — install from hub (future)
    beeq hub verify labo-z           — verify skill signature
    beeq hub remove labo-z           — remove skill
    beeq hub sign ./my.skill.md      — generate signature for your skill
    """
    from beeq.skills.manager import SkillManager
    mgr = SkillManager()

    if action == "list":
        skills = mgr.list_installed()
        if not skills:
            click.echo("No skills installed. Try: beeq hub install ./my.skill.md")
            return
        click.echo(f"Installed skills ({len(skills)}):")
        for s in skills:
            verified = "✅" if s.signature else "⚠️ "
            click.echo(f"  {verified} {s.name:20} v{s.version:6} by {s.author}")
            if s.description:
                click.echo(f"     {s.description[:60]}")

    elif action == "install":
        if not target:
            click.echo("Usage: beeq hub install <path or author/name>", err=True)
            return
        try:
            skill = mgr.install(target)
            r = mgr.verify(skill.metadata.name)
            status = "✅ verified" if r["valid"] else "⚠️  unsigned"
            click.echo(f"Installed: {skill.name} v{skill.metadata.version} [{status}]")
            click.echo(f"  {skill.metadata.description}")
        except Exception as e:
            click.echo(f"Error: {e}", err=True)

    elif action == "verify":
        if not target:
            click.echo("Usage: beeq hub verify <skill-name>", err=True)
            return
        r = mgr.verify(target)
        click.echo(r["message"])

    elif action == "remove":
        if not target:
            click.echo("Usage: beeq hub remove <skill-name>", err=True)
            return
        if mgr.remove(target):
            click.echo(f"Removed: {target}")
        else:
            click.echo(f"Skill not found: {target}", err=True)

    elif action == "sign":
        if not target:
            click.echo("Usage: beeq hub sign ./my.skill.md", err=True)
            return
        from pathlib import Path
        content = Path(target).read_text()
        skill = mgr._parse(content)
        sig = mgr.sign(
            skill.metadata.name,
            skill.metadata.author,
            skill.metadata.version,
            skill.instructions
        )
        click.echo(f"Signature for {skill.metadata.name}:")
        click.echo(f"  {sig}")
        click.echo()
        click.echo("Add this to your skill's front matter:")
        click.echo(f"  signature: {sig}")



@cli.command("mcp-server")
def mcp_server_cmd():
    """Start BeeQ as an MCP server (stdio transport).

    Connect from Claude Desktop by adding to claude_desktop_config.json:

    \b
    {
      "mcpServers": {
        "beeq": {
          "command": "beeq",
          "args": ["mcp-server"]
        }
      }
    }
    """
    from beeq.mcp.server import run
    run()



@cli.command("mcp")
@click.argument("action", type=click.Choice(["connect","list","status","disconnect","call"]))
@click.argument("target", default="")
@click.option("--token", default=None, help="API token for service")
@click.option("--tool", default=None, help="Tool name (for call action)")
@click.option("--args", default="{}", help="JSON arguments (for call action)")
def mcp_cmd(action, target, token, tool, args):
    """Manage MCP connections to external services.

    \b
    beeq mcp list                    — list available MCP services
    beeq mcp status                  — connection status
    beeq mcp connect github          — connect to GitHub (needs GITHUB_PERSONAL_ACCESS_TOKEN)
    beeq mcp connect filesystem      — connect to local filesystem (no token)
    beeq mcp connect memory          — connect to MCP memory graph (no token)
    beeq mcp call filesystem read_file --args '{"path":"/tmp/test.txt"}'
    beeq mcp disconnect github       — disconnect service
    """
    from beeq.mcp.client import MCPClient
    import json as _json

    async def _run():
        client = MCPClient()

        if action == "list":
            servers = client.available_servers()
            click.echo(f"Available MCP services ({len(servers)}):")
            for name, info in servers.items():
                configured = "✅" if info["configured"] else "⚙️ "
                connected  = " [connected]" if info["connected"] else ""
                click.echo(f"  {configured} {name:14} {info['description'][:45]}{connected}")
                if not info["configured"] and info["env_key"]:
                    click.echo(f"     Requires: {info['env_key']}")
            return

        if action == "status":
            servers = client.available_servers()
            connected = [(n,i) for n,i in servers.items() if i["connected"]]
            click.echo(f"Connected services: {len(connected)}/{len(servers)}")
            for name, info in servers.items():
                icon = "🟢" if info["connected"] else ("🟡" if info["configured"] else "⚫")
                click.echo(f"  {icon} {name}")
            return

        if action == "connect":
            if not target:
                click.echo("Usage: beeq mcp connect <service>", err=True); return
            try:
                click.echo(f"Connecting to {target}...", nl=False)
                if token:
                    conn = await client.connect(target, token=token)
                else:
                    conn = await client.connect(target)
                click.echo(f" ✅ {len(conn.tools)} tools available")
                for t in conn.tools[:8]:
                    click.echo(f"  • {t['name']}")
                if len(conn.tools) > 8:
                    click.echo(f"  ... and {len(conn.tools)-8} more")
            except Exception as e:
                click.echo(f" ❌ {e}", err=True)
            finally:
                await client.disconnect_all()
            return

        if action == "call":
            if not target or not tool:
                click.echo("Usage: beeq mcp call <service> --tool <tool> --args '{}'", err=True)
                return
            try:
                arguments = _json.loads(args)
                conn = await client.connect(target)
                result = await client.call(target, tool, arguments)
                if result.get("success"):
                    click.echo(result.get("output", "")[:500])
                else:
                    click.echo(f"Error: {result.get('error','?')}", err=True)
            except Exception as e:
                click.echo(f"Error: {e}", err=True)
            finally:
                await client.disconnect_all()
            return

        if action == "disconnect":
            click.echo(f"Session connections are not persistent — nothing to disconnect.")
            return

    asyncio.run(_run())



@cli.command("verify")
@click.argument("pia_id")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON")
def verify_cmd(pia_id, as_json):
    """Verify a Prior Intent Proof.

    \b
    beeq verify <hash>         — verify locally stored PIA
    beeq verify <hash> --json  — raw JSON output

    Also available at: https://beeq.run/verify/<hash>
    """
    from beeq.intention import IntentionEngine

    engine = IntentionEngine()
    result = engine.verify(pia_id)

    if as_json:
        import json as _json
        click.echo(_json.dumps(result, indent=2))
        return

    if result["valid"]:
        click.echo(f"✅ VALID Prior Intent Proof")
    else:
        click.echo(f"❌ INVALID: {', '.join(result.get('errors', [result.get('error','?')]))}")

    if result.get("mission"):
        click.echo(f"   Mission : {result['mission'][:70]}")
    if result.get("timestamp_intent"):
        click.echo(f"   Intent  : {result['timestamp_intent'][:19]} UTC")
    if result.get("timestamp_action"):
        click.echo(f"   Action  : {result['timestamp_action'][:19]} UTC")
    if result.get("temporal_valid") is not None:
        icon = "✓" if result["temporal_valid"] else "✗"
        click.echo(f"   Temporal: {icon} intent preceded action")
    if result.get("actions_count") is not None:
        click.echo(f"   Actions : {result['actions_count']}")
    click.echo(f"   URL     : {result.get('verify_url', '')}")



@cli.command("dashboard")
@click.option("--port", default=7935, show_default=True, help="Dashboard port")
@click.option("--open", "open_browser", is_flag=True, help="Open browser automatically")
def dashboard_cmd(port, open_browser):
    """Launch the Queen Avatar Dashboard.

    \b
    beeq dashboard           — start on port 7935
    beeq dashboard --open    — start + open browser
    beeq dashboard --port 8080

    Access: http://localhost:7935
    """
    import webbrowser, threading, time as _time

    try:
        import fastapi, uvicorn
    except ImportError:
        click.echo("❌ Dashboard requires: pip install fastapi uvicorn")
        return

    from beeq.dashboard.api import app

    click.echo(f"\n  👑 BeeQ Dashboard — Reine Avatar")
    click.echo(f"  🌐 http://localhost:{port}")
    click.echo(f"  ⚡ API http://localhost:{port}/status")
    click.echo(f"  Ctrl+C to stop\n")

    if open_browser:
        def _open():
            _time.sleep(1.2)
            webbrowser.open(f"http://localhost:{port}/dashboard")
        threading.Thread(target=_open, daemon=True).start()

    uvicorn.run(app, host="0.0.0.0", port=port, log_level="warning")


if __name__ == "__main__":
    cli()
