"""
BeeQ MCP Server — expose BeeQ comme serveur MCP.

N'importe quel client MCP peut se brancher:
  - Claude Desktop
  - Cursor
  - Zed
  - Tout éditeur/LLM compatible MCP

Outils exposés:
  1. execute_mission   — donner une mission à la ruche
  2. remember          — stocker un souvenir
  3. recall            — retrouver un souvenir
  4. verify_pia        — vérifier une Preuve d'Intention Antérieure
  5. hive_status       — état de la ruche (workers, audit chain)
  6. run_code          — exécuter du code Python dans le sandbox
  7. write_document    — générer un document (Markdown, HTML, PDF)
  8. search_web        — recherche web via DDG

Protocol: MCP (Model Context Protocol) over stdio
Spec: https://spec.modelcontextprotocol.io/

Z = dI/d(log s) · exp(iθ)
  BeeQ MCP = la prise universelle
  Chaque outil = un worker BeeQ avec son scope AAP
  Chaque action = un enregistrement dans l'audit chain
"""

import asyncio
import json
import sys
import os
from pathlib import Path

# ── MCP PROTOCOL TYPES ───────────────────────────────────────────

def mcp_response(id, result):
    return json.dumps({"jsonrpc": "2.0", "id": id, "result": result})

def mcp_error(id, code, message):
    return json.dumps({"jsonrpc": "2.0", "id": id, "error": {"code": code, "message": message}})

def mcp_notification(method, params):
    return json.dumps({"jsonrpc": "2.0", "method": method, "params": params})


# ── TOOLS MANIFEST ───────────────────────────────────────────────

TOOLS = [
    {
        "name": "execute_mission",
        "description": (
            "Give a mission to the BeeQ hive. The Queen will decompose it into subtasks, "
            "delegate to specialized workers, and return a consolidated result. "
            "Every action is cryptographically signed (AAP). "
            "A Prior Intent Proof is generated BEFORE any action."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "mission": {
                    "type": "string",
                    "description": "The mission to execute (natural language)"
                }
            },
            "required": ["mission"]
        }
    },
    {
        "name": "remember",
        "description": "Store information in BeeQ's sovereign memory (local SQLite, never cloud).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "content": {"type": "string", "description": "The information to remember"},
                "tags": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Optional tags for easier retrieval"
                }
            },
            "required": ["content"]
        }
    },
    {
        "name": "recall",
        "description": "Search BeeQ's sovereign memory using BM25 + semantic search.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query"},
                "top_k": {"type": "integer", "description": "Number of results (default: 5)"}
            },
            "required": ["query"]
        }
    },
    {
        "name": "verify_pia",
        "description": (
            "Verify a Prior Intent Proof — cryptographic proof that BeeQ declared "
            "its intention BEFORE acting. Enter a PIA hash from beeq.run/verify/<hash>."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "pia_id": {"type": "string", "description": "64-character SHA-256 PIA hash"}
            },
            "required": ["pia_id"]
        }
    },
    {
        "name": "hive_status",
        "description": "Get the current status of the BeeQ hive (workers, audit chain, skills, last missions).",
        "inputSchema": {"type": "object", "properties": {}}
    },
    {
        "name": "run_code",
        "description": "Execute Python or bash code in BeeQ's isolated sandbox (subprocess, timeout 10s).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "code": {"type": "string", "description": "Python or bash code to execute"},
                "language": {
                    "type": "string",
                    "enum": ["python", "bash"],
                    "description": "Language (default: python)"
                }
            },
            "required": ["code"]
        }
    },
    {
        "name": "write_document",
        "description": "Generate a document (Markdown, HTML, or PDF) with BeeQ's Write worker.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "task": {"type": "string", "description": "What to write"},
                "format": {
                    "type": "string",
                    "enum": ["markdown", "html", "pdf"],
                    "description": "Output format (default: markdown)"
                },
                "content": {
                    "type": "string",
                    "description": "Optional: provide content directly instead of generating it"
                }
            },
            "required": ["task"]
        }
    },
    {
        "name": "search_web",
        "description": "Search the web via DuckDuckGo (no API key required) and optionally scrape top results.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query"},
                "scrape": {
                    "type": "boolean",
                    "description": "Also scrape top result pages for full content (default: false)"
                }
            },
            "required": ["query"]
        }
    },
]


# ── MCP SERVER ────────────────────────────────────────────────────

class BeeQMCPServer:
    """BeeQ as an MCP server — stdio transport."""

    def __init__(self):
        self.hive = None
        self._initialized = False

    async def _ensure_hive(self):
        """Lazy init of the hive."""
        if self.hive is None:
            from beeq.core import BeeQ
            self.hive = BeeQ()
            await self.hive.setup()
            self._initialized = True

    async def handle(self, request: dict) -> str:
        method = request.get("method", "")
        id_    = request.get("id")
        params = request.get("params", {})

        try:
            if method == "initialize":
                return mcp_response(id_, {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {
                        "tools": {"listChanged": False},
                        "resources": {}
                    },
                    "serverInfo": {
                        "name": "beeq",
                        "version": "1.2.2",
                        "description": "BeeQ — The First AI Hive with sovereign memory and audit chain"
                    }
                })

            elif method == "notifications/initialized":
                return ""  # No response needed

            elif method == "tools/list":
                return mcp_response(id_, {"tools": TOOLS})

            elif method == "tools/call":
                return await self._call_tool(id_, params)

            elif method == "ping":
                return mcp_response(id_, {})

            else:
                return mcp_error(id_, -32601, f"Method not found: {method}")

        except Exception as e:
            return mcp_error(id_, -32603, str(e))

    async def _call_tool(self, id_, params: dict) -> str:
        name  = params.get("name", "")
        args  = params.get("arguments", {})

        await self._ensure_hive()

        try:
            if name == "execute_mission":
                m = await self.hive.execute(args["mission"])
                text = m.synthesis or (m.results[0].output if m.results else "No output")
                result = {
                    "status": m.status,
                    "output": text,
                    "workers_used": len(m.results),
                    "pia_id": m.pia_id,
                    "verify_url": m.verify_url,
                }

            elif name == "remember":
                tags = args.get("tags", [])
                mid  = await self.hive.remember(args["content"], tags=tags)
                result = {"stored": True, "id": mid}

            elif name == "recall":
                results = await self.hive.recall(args["query"], top_k=args.get("top_k", 5))
                result  = {"results": results}

            elif name == "verify_pia":
                from beeq.intention import IntentionEngine
                r = IntentionEngine().verify(args["pia_id"])
                result = r

            elif name == "hive_status":
                audit  = self.hive.audit()
                skills = self.hive.skills.list_installed() if self.hive.skills else []
                result = {
                    "workers": list(self.hive.governance.workers.keys()),
                    "audit_valid": audit.get("valid"),
                    "audit_actions": audit.get("actions", 0),
                    "skills_installed": [s.name for s in skills],
                    "beeq_version": "1.2.1",
                    "memory_summary": (
                        self.hive.memory.summary() if self.hive.memory else "no memory"
                    ),
                }

            elif name == "run_code":
                from beeq.workers.code import CodeWorker
                from beeq.governance.hive import HiveGovernance
                from beeq.providers.manager import ProviderManager
                cw = CodeWorker(self.hive.governance, self.hive.providers)
                cw.register()
                r  = await cw._exec_direct(args["code"])
                result = {
                    "success": r.success,
                    "output": r.output,
                    "error":  r.error,
                }

            elif name == "write_document":
                from beeq.workers.writer import WriterWorker
                ww  = WriterWorker(self.hive.governance, self.hive.providers)
                ww.register()
                fmt = args.get("format", "markdown")
                ctx = {"action": fmt}
                if args.get("content"):
                    ctx["content"] = args["content"]
                r   = await ww.execute(args["task"], context=ctx)
                result = {
                    "success": r.success,
                    "output":  r.output[:500],
                    "format":  r.metadata.get("format"),
                    "path":    r.metadata.get("path"),
                }

            elif name == "search_web":
                from beeq.workers.research import ResearchWorker
                rw = ResearchWorker(self.hive.governance, self.hive.providers)
                rw.register()
                if args.get("scrape"):
                    text = await rw._web_search_with_content(args["query"])
                else:
                    text = await rw._search_web(args["query"])
                result = {"results": text}

            else:
                return mcp_error(id_, -32602, f"Unknown tool: {name}")

            return mcp_response(id_, {
                "content": [{"type": "text", "text": json.dumps(result, indent=2, ensure_ascii=False)}]
            })

        except Exception as e:
            return mcp_error(id_, -32603, f"Tool error [{name}]: {e}")

    async def run_stdio(self):
        """Run MCP server on stdio (standard MCP transport)."""
        reader = asyncio.StreamReader()
        proto  = asyncio.StreamReaderProtocol(reader)
        loop   = asyncio.get_event_loop()

        await loop.connect_read_pipe(lambda: proto, sys.stdin)
        w_transport, w_proto = await loop.connect_write_pipe(
            asyncio.BaseProtocol, sys.stdout
        )
        writer = asyncio.StreamWriter(w_transport, w_proto, reader, loop)

        while True:
            try:
                line = await reader.readline()
                if not line:
                    break
                line = line.decode().strip()
                if not line:
                    continue

                request = json.loads(line)
                response = await self.handle(request)
                if response:
                    writer.write((response + "\n").encode())
                    await writer.drain()

            except json.JSONDecodeError:
                continue
            except Exception as e:
                sys.stderr.write(f"MCP error: {e}\n")


def run():
    """Entry point: beeq mcp-server"""
    server = BeeQMCPServer()
    asyncio.run(server.run_stdio())


if __name__ == "__main__":
    run()
