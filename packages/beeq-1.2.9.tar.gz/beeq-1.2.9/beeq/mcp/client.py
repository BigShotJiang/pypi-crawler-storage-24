"""
BeeQ MCP Client — connecte BeeQ aux services MCP externes.

BeeQ est simultanément :
  - Serveur MCP (beeq mcp-server) — Claude Desktop se branche
  - Client MCP (ce module) — BeeQ se branche sur Gmail, GitHub, Notion...

Protocole: MCP over stdio ou SSE (Server-Sent Events)
Chaque connexion génère un AAP token avec scope limité (LEX §8).

Services supportés (via MCP):
  gmail     — lire/envoyer emails
  github    — lire/créer issues, PRs, commits
  notion    — lire/écrire pages et bases de données
  slack     — lire/envoyer messages
  filesystem — lire/écrire fichiers locaux
  custom    — n'importe quel serveur MCP URL

Usage:
  hive.mcp.connect("github", "npx @modelcontextprotocol/server-github")
  hive.mcp.connect("gmail",  "npx @modelcontextprotocol/server-gmail")
  tools = await hive.mcp.list_tools("github")
  result = await hive.mcp.call("github", "create_issue", {...})
"""

import asyncio
import json
import os
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class MCPConnection:
    """Active connection to an MCP server."""
    name:     str
    command:  str           # e.g. "npx @modelcontextprotocol/server-github"
    env:      dict          # Environment vars (tokens, keys)
    tools:    list = field(default_factory=list)  # Available tools
    process:  Optional[object] = None             # asyncio subprocess
    _reader:  Optional[object] = None
    _writer:  Optional[object] = None
    _seq:     int = 0


class MCPClient:
    """
    BeeQ MCP Client — manages connections to external MCP servers.

    Each connected service exposes tools that BeeQ workers can call.
    The Queen routes tasks to these tools via the normal worker interface.
    """

    # NVM node path for MCP servers
    _NVM_NODE = "/root/.nvm/versions/node/v20.20.1/bin"

    def __init__(self):
        self.connections: dict[str, MCPConnection] = {}
        # Prepend nvm node to PATH for all subprocess calls
        _node_path = self._NVM_NODE
        if os.path.exists(_node_path):
            os.environ["PATH"] = f"{_node_path}:{os.environ.get('PATH','')}"
        self._known_servers = {
            "github": {
                "command": "npx -y @modelcontextprotocol/server-github",
                "env_key": "GITHUB_PERSONAL_ACCESS_TOKEN",
                "description": "GitHub — repos, issues, PRs, commits",
            },
            "filesystem": {
                "command": "npx -y @modelcontextprotocol/server-filesystem /tmp",
                "env_key": None,
                "description": "Local filesystem — read/write files",
            },
            "memory": {
                "command": "npx -y @modelcontextprotocol/server-memory",
                "env_key": None,
                "description": "In-memory knowledge graph",
            },
            "everything": {
                "command": "npx -y @modelcontextprotocol/server-everything",
                "env_key": None,
                "description": "Test server — all MCP features",
            },
            "notion": {
                "command": "npx -y @notionhq/notion-mcp-server",
                "env_key": "NOTION_API_KEY",
                "description": "Notion — pages, databases",
            },
            "slack": {
                "command": "npx -y @modelcontextprotocol/server-slack",
                "env_key": "SLACK_BOT_TOKEN",
                "description": "Slack — messages, channels",
            },
        }

    def available_servers(self) -> dict:
        """List known MCP servers and their connection status."""
        result = {}
        for name, info in self._known_servers.items():
            connected = name in self.connections
            configured = (
                not info["env_key"] or
                bool(os.environ.get(info["env_key"])) or
                bool(self._load_token(name))
            )
            result[name] = {
                "description": info["description"],
                "connected": connected,
                "configured": configured,
                "env_key": info["env_key"],
            }
        return result

    async def connect(
        self,
        name: str,
        command: str = None,
        env: dict = None,
        token: str = None,
    ) -> MCPConnection:
        """
        Connect to an MCP server.

        Args:
            name:    Service name ("github", "gmail", etc.) or custom name
            command: MCP server command (auto-detected for known services)
            env:     Environment variables for the server process
            token:   API token (stored in ~/.beeq/mcp_tokens/<name>)
        """
        if name in self.connections:
            return self.connections[name]

        # Auto-detect command for known services
        if command is None:
            if name not in self._known_servers:
                raise ValueError(
                    f"Unknown service '{name}'. Provide command= or use: "
                    f"{list(self._known_servers.keys())}"
                )
            command = self._known_servers[name]["command"]

        # Build environment
        proc_env = {**os.environ}
        if env:
            proc_env.update(env)

        # Load stored token
        if token:
            self._save_token(name, token)
            env_key = self._known_servers.get(name, {}).get("env_key")
            if env_key:
                proc_env[env_key] = token
        else:
            stored = self._load_token(name)
            if stored:
                env_key = self._known_servers.get(name, {}).get("env_key")
                if env_key:
                    proc_env[env_key] = stored

        conn = MCPConnection(name=name, command=command, env=proc_env)

        # Start the MCP server process
        try:
            proc = await asyncio.create_subprocess_shell(
                command,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.DEVNULL,
                env=proc_env,
            )
            conn.process = proc
            conn._reader = proc.stdout
            conn._writer = proc.stdin

            # Step 1: Send initialize
            await self._send(conn, "initialize", {
                "protocolVersion": "2024-11-05",
                "clientInfo": {"name": "beeq", "version": "1.2.2"},
                "capabilities": {"tools": {}},
            })

            # Step 2: Send initialized notification (required by MCP spec)
            notif = '{"jsonrpc":"2.0","method":"notifications/initialized","params":{}}\n'
            conn._writer.write(notif.encode())
            await conn._writer.drain()

            # Small delay for server to be ready
            import asyncio as _asyncio
            await _asyncio.sleep(0.5)

            # Step 3: List tools
            tools_response = await self._send(conn, "tools/list", {})
            if tools_response and "tools" in tools_response.get("result", {}):
                conn.tools = tools_response["result"]["tools"]

            self.connections[name] = conn
            return conn

        except Exception as e:
            if conn.process:
                conn.process.terminate()
            raise ConnectionError(f"Failed to connect to {name}: {e}")

    async def call(self, service: str, tool: str, arguments: dict = None) -> dict:
        """
        Call a tool on a connected MCP service.

        Args:
            service:   Service name (must be connected)
            tool:      Tool name
            arguments: Tool arguments

        Returns:
            Tool result dict
        """
        if service not in self.connections:
            raise RuntimeError(
                f"Service '{service}' not connected. "
                f"Call: await hive.mcp.connect('{service}')"
            )

        conn = self.connections[service]
        response = await self._send(conn, "tools/call", {
            "name": tool,
            "arguments": arguments or {},
        })

        if response and "result" in response:
            content = response["result"].get("content", [])
            if content:
                text = " ".join(
                    c.get("text", "") for c in content if c.get("type") == "text"
                )
                return {"success": True, "output": text, "raw": response["result"]}

        if response and "error" in response:
            return {"success": False, "error": response["error"].get("message", "Unknown error")}

        return {"success": False, "error": "No response"}

    async def list_tools(self, service: str) -> list:
        """List available tools for a connected service."""
        if service not in self.connections:
            raise RuntimeError(f"Service '{service}' not connected")
        return self.connections[service].tools

    async def disconnect(self, service: str):
        """Disconnect from an MCP service."""
        conn = self.connections.pop(service, None)
        if conn and conn.process:
            try:
                conn.process.terminate()
                await asyncio.wait_for(conn.process.wait(), timeout=2)
            except Exception:
                pass

    async def disconnect_all(self):
        """Disconnect from all services."""
        for name in list(self.connections.keys()):
            await self.disconnect(name)

    # ── INTERNAL ──────────────────────────────────────────────────

    async def _send(self, conn: MCPConnection, method: str, params: dict) -> Optional[dict]:
        """Send MCP JSON-RPC request and wait for response."""
        if not conn._writer or not conn._reader:
            return None

        conn._seq += 1
        req = json.dumps({
            "jsonrpc": "2.0",
            "id": conn._seq,
            "method": method,
            "params": params,
        }) + "\n"

        try:
            conn._writer.write(req.encode())
            await conn._writer.drain()

            # Read response (with timeout)
            line = await asyncio.wait_for(conn._reader.readline(), timeout=10.0)
            if line:
                return json.loads(line.decode())
        except asyncio.TimeoutError:
            return None
        except Exception:
            return None

    def _token_path(self, name: str) -> Path:
        path = Path.home() / ".beeq" / "mcp_tokens"
        path.mkdir(parents=True, exist_ok=True)
        return path / f"{name}.token"

    def _save_token(self, name: str, token: str):
        self._token_path(name).write_text(token)
        self._token_path(name).chmod(0o600)

    def _load_token(self, name: str) -> Optional[str]:
        path = self._token_path(name)
        return path.read_text().strip() if path.exists() else None


# ── BEEQ INTEGRATION ─────────────────────────────────────────────

class MCPWorkerBridge:
    """
    Bridge between BeeQ workers and MCP services.

    Allows workers to call MCP tools transparently:
      await bridge.github_create_issue(title="...", body="...")
      await bridge.gmail_send(to="...", subject="...", body="...")
    """

    def __init__(self, mcp_client: MCPClient):
        self.client = mcp_client

    async def github_create_issue(
        self, repo: str, title: str, body: str = "", labels: list = None
    ) -> dict:
        """Create a GitHub issue."""
        return await self.client.call("github", "create_issue", {
            "owner": repo.split("/")[0],
            "repo": repo.split("/")[1],
            "title": title,
            "body": body,
            **({"labels": labels} if labels else {}),
        })

    async def github_search_code(self, query: str) -> dict:
        """Search GitHub code."""
        return await self.client.call("github", "search_code", {"query": query})

    async def gmail_send(self, to: str, subject: str, body: str) -> dict:
        """Send an email via Gmail MCP."""
        return await self.client.call("gmail", "send_email", {
            "to": to, "subject": subject, "body": body,
        })

    async def notion_create_page(
        self, database_id: str, title: str, content: str
    ) -> dict:
        """Create a Notion page."""
        return await self.client.call("notion", "create_page", {
            "database_id": database_id,
            "title": title,
            "content": content,
        })

    async def fetch_url(self, url: str) -> dict:
        """Fetch a URL via MCP fetch service."""
        await self._ensure_connected("fetch")
        return await self.client.call("fetch", "fetch", {"url": url})

    async def _ensure_connected(self, service: str):
        if service not in self.client.connections:
            await self.client.connect(service)
