"""
BeeQ Verify API — endpoint public beeq.run/verify/<hash>

FastAPI minimal, port 7937.
Sert les PIAs stockées dans ~/.beeq/intentions/
Retourne JSON ou HTML selon Accept header.

Expose via CF tunnel ou nginx proxy depuis eden-935.
"""

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware

PIA_STORE = Path.home() / ".beeq" / "intentions"

app = FastAPI(
    title="BeeQ Verify API",
    description="Prior Intent Proof verification — beeq.run/verify/<hash>",
    version="1.2.2",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET"],
    allow_headers=["*"],
)


@app.get("/health")
def health():
    return {
        "status": "ok",
        "pia_count": len(list(PIA_STORE.glob("*.json"))),
        "beeq_version": "1.2.2",
    }


@app.get("/verify/{pia_id}")
@app.get("/api/pia/{pia_id}")
async def verify_pia(pia_id: str, request: Request):
    """Verify a Prior Intent Proof. Returns JSON or HTML."""
    result = _verify(pia_id)
    accept = request.headers.get("accept", "")
    if "text/html" in accept and "application/json" not in accept:
        return HTMLResponse(_render_html(result))
    return JSONResponse(result)


@app.get("/verify")
@app.get("/api/pia")
def list_pias(n: int = 10):
    """List n most recent PIAs (public metadata)."""
    files = sorted(
        PIA_STORE.glob("*.json"),
        key=lambda f: f.stat().st_mtime,
        reverse=True,
    )[:n]
    pias = []
    for f in files:
        try:
            d = json.loads(f.read_text())
            pias.append({
                "pia_id": d["pia_id"],
                "mission": d["mission"][:80],
                "timestamp_intent": d["timestamp_intent"],
                "verify_url": d.get("verify_url", f"https://beeq.run/verify/{d['pia_id']}"),
            })
        except Exception:
            pass
    return {"count": len(pias), "pias": pias}


# ── CORE VERIFY LOGIC ─────────────────────────────────────────────

def _verify(pia_id: str) -> dict:
    """Full cryptographic verification of a PIA."""
    # Validate format
    if not pia_id or len(pia_id) != 64:
        return {"valid": False, "error": "Invalid PIA ID (must be 64 hex chars)", "pia_id": pia_id}
    if not all(c in "0123456789abcdef" for c in pia_id.lower()):
        return {"valid": False, "error": "Invalid PIA ID format", "pia_id": pia_id}

    path = PIA_STORE / f"{pia_id}.json"
    if not path.exists():
        return {
            "valid": False,
            "error": "PIA not found",
            "pia_id": pia_id,
            "message": (
                "This PIA was not found in this hive. "
                "PIAs are stored on the hive that generated them."
            ),
        }

    try:
        data = json.loads(path.read_text())
    except Exception as e:
        return {"valid": False, "error": f"Corrupted PIA: {e}", "pia_id": pia_id}

    errors = []

    # 1. Mission hash
    h_mission = hashlib.sha256(data["mission"].encode()).hexdigest()
    if h_mission != data["mission_hash"]:
        errors.append("mission_hash_mismatch")

    # 2. Plan hash
    plan_json = json.dumps(data["plan"], sort_keys=True, ensure_ascii=False)
    h_plan = hashlib.sha256(plan_json.encode()).hexdigest()
    if h_plan != data["plan_hash"]:
        errors.append("plan_hash_mismatch")

    # 3. Signature
    if data.get("signature", "").startswith("sha256:"):
        sig_content = (f"{data['mission_hash']}{data['plan_hash']}"
                       f"{data['timestamp_intent']}{data['node_id']}")
        expected = f"sha256:{hashlib.sha256(sig_content.encode()).hexdigest()}"
        if expected != data["signature"]:
            errors.append("signature_mismatch")

    # 4. PIA ID
    pia_content = (f"{data['mission_hash']}{data['plan_hash']}"
                   f"{data['timestamp_intent']}{data['node_id']}{data['signature']}")
    computed_id = hashlib.sha256(pia_content.encode()).hexdigest()
    if computed_id != pia_id:
        errors.append("pia_id_mismatch")

    # 5. Temporal order (intent BEFORE action)
    temporal_valid = True
    if data.get("timestamp_action"):
        t_intent = datetime.fromisoformat(data["timestamp_intent"]).timestamp()
        t_action = datetime.fromisoformat(data["timestamp_action"]).timestamp()
        if t_intent >= t_action:
            errors.append("temporal_violation")
            temporal_valid = False

    valid = len(errors) == 0
    return {
        "valid": valid,
        "pia_id": pia_id,
        "errors": errors,
        "temporal_valid": temporal_valid,
        "plan_followed": data.get("plan_followed", True),
        "divergences": data.get("divergences", []),
        "mission": data["mission"],
        "mission_hash": data["mission_hash"],
        "node_id": data["node_id"],
        "timestamp_intent": data["timestamp_intent"],
        "timestamp_action": data.get("timestamp_action"),
        "timestamp_done": data.get("timestamp_done"),
        "actions_count": data.get("actions_count", 0),
        "subtasks_planned": len(data.get("plan", {}).get("subtasks", [])),
        "signature": data.get("signature", ""),
        "verify_url": data.get("verify_url", f"https://beeq.run/verify/{pia_id}"),
        "beeq_version": "1.2.2",
        "summary": (
            f"✅ VALID — BeeQ declared its intention at "
            f"{data['timestamp_intent'][:19]} UTC, "
            f"BEFORE taking any action. "
            f"Plan {'followed exactly' if data.get('plan_followed', True) else 'adapted'}. "
            f"Cryptographically verified."
        ) if valid else (
            f"❌ INVALID — {', '.join(errors)}"
        ),
    }


# ── HTML RENDERER ─────────────────────────────────────────────────

def _render_html(r: dict) -> str:
    valid   = r.get("valid", False)
    color   = "#22c55e" if valid else "#ef4444"
    icon    = "✅" if valid else "❌"
    label   = "VALID PRIOR INTENT PROOF" if valid else (r.get("error", "INVALID"))

    def t(v): return str(v)[:19] if v else "—"
    def esc(s): return str(s).replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")

    timeline = ""
    if r.get("timestamp_intent"):
        timeline = f"""
    <div class="timeline">
      <div class="tbox"><div class="tl">🧠 Intent</div><div class="tv">{t(r.get('timestamp_intent'))}</div></div>
      <div class="tbox"><div class="tl">⚡ Action</div><div class="tv">{t(r.get('timestamp_action'))}</div></div>
      <div class="tbox"><div class="tl">✓ Done</div><div class="tv">{t(r.get('timestamp_done'))}</div></div>
    </div>
    <div class="temporal {'ok' if r.get('temporal_valid', True) else 'fail'}">
      {'✓ Intent preceded action — temporal order verified' if r.get('temporal_valid', True)
       else '✗ Temporal violation detected'}
    </div>"""

    meta = ""
    if r.get("actions_count") is not None:
        meta = f"""
    <div class="field"><span class="lbl">Node</span> {esc(r.get('node_id','—'))}</div>
    <div class="field"><span class="lbl">Actions</span> {r.get('actions_count',0)}</div>
    <div class="field"><span class="lbl">Subtasks planned</span> {r.get('subtasks_planned',0)}</div>
    <div class="field"><span class="lbl">Plan</span> {'followed exactly' if r.get('plan_followed',True) else 'adapted'}</div>"""

    errors_html = ""
    if r.get("errors"):
        errors_html = f'<div class="errors">Errors: {esc(", ".join(r["errors"]))}</div>'

    sig = r.get("signature", "")
    sig_display = f"{sig[:48]}..." if len(sig) > 48 else sig

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>BeeQ Verify — {r.get('pia_id','')[:16]}...</title>
  <style>
    *{{box-sizing:border-box;margin:0;padding:0}}
    body{{font-family:'Courier New',monospace;background:#07050A;color:#EAE0CC;
         min-height:100vh;padding:2rem 1rem;}}
    .wrap{{max-width:760px;margin:0 auto}}
    .logo{{color:#F0A020;font-size:1.3rem;font-weight:700;margin-bottom:1.5rem}}
    .logo span{{color:#EAE0CC}}
    .card{{border:2px solid {color};border-radius:8px;padding:1.5rem;margin-bottom:1.5rem}}
    .status{{font-size:1.8rem;color:{color};margin-bottom:.5rem}}
    .hash{{font-size:.7rem;color:#555;word-break:break-all;margin-bottom:1rem}}
    .mission{{background:#111;border-left:3px solid {color};
              padding:.75rem 1rem;border-radius:4px;margin:1rem 0;font-size:.9rem}}
    .timeline{{display:grid;grid-template-columns:1fr 1fr 1fr;gap:.75rem;margin:1rem 0}}
    .tbox{{background:#0a0a0a;border:1px solid #222;padding:.75rem;border-radius:6px}}
    .tl{{color:#888;font-size:.7rem;margin-bottom:.25rem}}
    .tv{{color:#EAE0CC;font-size:.75rem}}
    .temporal{{font-size:.8rem;margin:.5rem 0}}
    .temporal.ok{{color:#22c55e}}.temporal.fail{{color:#ef4444}}
    .field{{font-size:.82rem;margin:.4rem 0;color:#B8AA95}}
    .lbl{{color:#666;font-size:.7rem;text-transform:uppercase;
          letter-spacing:.06em;display:inline-block;width:140px}}
    .summary{{margin-top:1.2rem;padding:1rem;background:#0a0a0a;
              border-radius:6px;font-size:.85rem;line-height:1.7;
              color:{color}}}
    .errors{{color:#ef4444;font-size:.82rem;margin-top:.5rem}}
    .sig{{font-size:.65rem;color:#444;word-break:break-all;margin-top:.75rem}}
    .footer{{margin-top:2rem;text-align:center;color:#333;font-size:.75rem}}
    .footer a{{color:#555;text-decoration:none}}
    @media(max-width:500px){{.timeline{{grid-template-columns:1fr}}}}
  </style>
</head>
<body>
<div class="wrap">
  <div class="logo">bee<span>Q</span></div>
  <div class="card">
    <div class="status">{icon} {esc(label)}</div>
    <div class="hash">PIA: {esc(r.get('pia_id','—'))}</div>
    {'<div class="mission">' + esc(r.get('mission','')) + '</div>' if r.get('mission') else ''}
    {timeline}
    {meta}
    {errors_html}
    {'<div class="sig">Signature: ' + esc(sig_display) + '</div>' if sig else ''}
    <div class="summary">{esc(r.get('summary',''))}</div>
  </div>
  <div class="footer">
    <a href="https://beeq.run">beeq.run</a> · Prior Intent Proof v1 ·
    BeeQ {r.get('beeq_version','1.2.2')} · Powered by AAP
  </div>
</div>
</body>
</html>"""


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=7937, log_level="warning")
