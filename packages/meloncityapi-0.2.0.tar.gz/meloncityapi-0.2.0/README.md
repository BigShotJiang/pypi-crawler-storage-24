# MelonCityAPI

CLI tool + library für Pycord Discord Bots.

## Installation
```
pip install meloncityapi
```

## Commands

```
meloncityapi new "MeinBot"               Neues Bot-Projekt erstellen
meloncityapi --addcog Music              Neues Cog hinzufügen
meloncityapi --rename MeinBot NeuerName  Projekt umbenennen
meloncityapi --info                      Projekt-Infos anzeigen
meloncityapi --stats bot.py             Datei-Stats anzeigen
meloncityapi --deletecomments bot.py    Alle Kommentare entfernen
meloncityapi --format bot.py            Code formatieren
meloncityapi --clean bot.py             Kommentare entfernen + formatieren
```
