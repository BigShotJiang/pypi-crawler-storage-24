import sys
import os
from .generator import create_project, add_cog, rename_project, get_project_info
from .cleaner import remove_comments_from_file, format_file, clean_file, get_stats
from .exceptions import InvalidProjectNameError


def main():
    args = sys.argv[1:]

    if not args:
        print("MelonCityAPI CLI v0.2.0")
        print("")
        print("  meloncityapi new <name>                  Create new bot project")
        print("  meloncityapi --addcog <name>             Add a new cog")
        print("  meloncityapi --rename <old> <new>        Rename a project")
        print("  meloncityapi --info                      Show project info")
        print("  meloncityapi --stats <file>              Show file stats")
        print("  meloncityapi --deletecomments <file>     Remove all comments")
        print("  meloncityapi --format <file>             Format file")
        print("  meloncityapi --clean <file>              Remove comments + format")
        return

    command = args[0]

    if command == "new":
        if len(args) < 2:
            print("Usage: meloncityapi new <name>")
            sys.exit(1)
        name = args[1].strip('"').strip("'")
        try:
            path = create_project(name)
            print(f"✅ Project '{name}' created at: {path}")
            print(f"")
            print(f"   {name}/")
            print(f"   ├── main.py")
            print(f"   ├── requirements.txt")
            print(f"   ├── .env")
            print(f"   └── cogs/")
            print(f"       └── example.py")
        except InvalidProjectNameError as e:
            print(f"❌ {e}")
            sys.exit(1)

    elif command == "--addcog":
        if len(args) < 2:
            print("Usage: meloncityapi --addcog <name>")
            sys.exit(1)
        name = args[1].strip('"').strip("'")
        try:
            filepath = add_cog(name)
            print(f"✅ Cog '{name}' created at: {filepath}")
        except InvalidProjectNameError as e:
            print(f"❌ {e}")
            sys.exit(1)

    elif command == "--rename":
        if len(args) < 3:
            print("Usage: meloncityapi --rename <old> <new>")
            sys.exit(1)
        old = args[1].strip('"').strip("'")
        new = args[2].strip('"').strip("'")
        try:
            path = rename_project(old, new)
            print(f"✅ Renamed '{old}' → '{new}'")
            print(f"   New path: {path}")
        except InvalidProjectNameError as e:
            print(f"❌ {e}")
            sys.exit(1)

    elif command == "--info":
        info = get_project_info()
        print(f"📁 Path      : {info['path']}")
        print(f"📄 main.py   : {'✅' if info['has_main'] else '❌'}")
        print(f"📂 cogs/     : {'✅' if info['has_cogs'] else '❌'}")
        if info["cogs"]:
            print(f"🧩 Cogs      : {', '.join(info['cogs'])}")
        if info["dependencies"]:
            print(f"📦 Deps      : {', '.join(info['dependencies'])}")

    elif command == "--stats":
        if len(args) < 2:
            print("Usage: meloncityapi --stats <file>")
            sys.exit(1)
        filepath = args[1]
        if not os.path.exists(filepath):
            print(f"❌ File not found: {filepath}")
            sys.exit(1)
        s = get_stats(filepath)
        print(f"📊 Stats for: {filepath}")
        print(f"   Total lines   : {s['total_lines']}")
        print(f"   Code lines    : {s['code_lines']}")
        print(f"   Comment lines : {s['comment_lines']}")
        print(f"   Empty lines   : {s['empty_lines']}")

    elif command == "--deletecomments":
        if len(args) < 2:
            print("Usage: meloncityapi --deletecomments <file>")
            sys.exit(1)
        filepath = args[1]
        if not os.path.exists(filepath):
            print(f"❌ File not found: {filepath}")
            sys.exit(1)
        result = remove_comments_from_file(filepath)
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(result)
        print(f"✅ Comments removed from: {filepath}")

    elif command == "--format":
        if len(args) < 2:
            print("Usage: meloncityapi --format <file>")
            sys.exit(1)
        filepath = args[1]
        if not os.path.exists(filepath):
            print(f"❌ File not found: {filepath}")
            sys.exit(1)
        result = format_file(filepath)
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(result)
        print(f"✅ Formatted: {filepath}")

    elif command == "--clean":
        if len(args) < 2:
            print("Usage: meloncityapi --clean <file>")
            sys.exit(1)
        filepath = args[1]
        if not os.path.exists(filepath):
            print(f"❌ File not found: {filepath}")
            sys.exit(1)
        result = clean_file(filepath)
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(result)
        print(f"✅ Cleaned: {filepath}")

    else:
        print(f"❌ Unknown command: {command}")
        print("Run 'meloncityapi' to see all commands.")
        sys.exit(1)


if __name__ == "__main__":
    main()
