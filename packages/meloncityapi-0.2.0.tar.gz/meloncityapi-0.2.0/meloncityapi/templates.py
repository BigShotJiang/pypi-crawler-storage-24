MAIN_PY = '''import discord
from discord.ext import commands
import os

bot = commands.Bot(command_prefix="!", intents=discord.Intents.all())

@bot.event
async def on_ready():
    print(f"Logged in as {bot.user}")
    for filename in os.listdir("./cogs"):
        if filename.endswith(".py"):
            await bot.load_extension(f"cogs.{filename[:-3]}")

bot.run("YOUR_TOKEN_HERE")
'''

COG_TEMPLATE = '''import discord
from discord.ext import commands


class {name}(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def {name_lower}(self, ctx):
        await ctx.send("{name} command!")


def setup(bot):
    bot.add_cog({name}(bot))
'''

REQUIREMENTS_TXT = '''py-cord>=2.4.0
python-dotenv
'''
