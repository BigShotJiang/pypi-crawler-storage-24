import re
import tokenize
import io


def remove_comments_from_file(filepath: str) -> str:
    with open(filepath, "r", encoding="utf-8") as f:
        source = f.read()

    tokens = []
    try:
        for tok in tokenize.generate_tokens(io.StringIO(source).readline):
            if tok.type != tokenize.COMMENT:
                tokens.append(tok)
        result = tokenize.untokenize(tokens)
    except tokenize.TokenError:
        result = re.sub(r"#.*", "", source)

    lines = [line for line in result.splitlines() if line.strip() != ""]
    return "\n".join(lines) + "\n"


def format_file(filepath: str) -> str:
    with open(filepath, "r", encoding="utf-8") as f:
        source = f.read()

    lines = source.splitlines()
    result = []
    prev_was_empty = False

    for line in lines:
        stripped = line.strip()

        if stripped.startswith(("def ", "async def ", "class ")):
            if result and not prev_was_empty:
                result.append("")
            result.append(line)
            prev_was_empty = False

        elif stripped == "":
            if not prev_was_empty:
                result.append("")
            prev_was_empty = True

        else:
            result.append(line)
            prev_was_empty = False

    while result and result[-1].strip() == "":
        result.pop()

    return "\n".join(result) + "\n"


def clean_file(filepath: str) -> str:
    no_comments = remove_comments_from_file(filepath)

    with open(filepath, "w", encoding="utf-8") as f:
        f.write(no_comments)

    return format_file(filepath)


def get_stats(filepath: str) -> dict:
    with open(filepath, "r", encoding="utf-8") as f:
        lines = f.readlines()

    total = len(lines)
    empty = sum(1 for l in lines if l.strip() == "")
    comments = sum(1 for l in lines if l.strip().startswith("#"))
    code = total - empty - comments

    return {
        "total_lines": total,
        "code_lines": code,
        "comment_lines": comments,
        "empty_lines": empty,
    }
