class MelonCityAPIError(Exception):
    pass

class InvalidProjectNameError(MelonCityAPIError):
    pass
