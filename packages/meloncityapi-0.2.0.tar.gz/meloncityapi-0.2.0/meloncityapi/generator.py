import os
import re
from .templates import MAIN_PY, COG_TEMPLATE, REQUIREMENTS_TXT
from .exceptions import InvalidProjectNameError


def create_project(name: str, path: str = None) -> str:
    if not re.match(r"^[a-zA-Z0-9_\-]+$", name):
        raise InvalidProjectNameError(f"Invalid project name: {name!r}")

    base = path or os.getcwd()
    project_path = os.path.join(base, name)

    if os.path.exists(project_path):
        raise InvalidProjectNameError(f"Folder '{name}' already exists!")

    os.makedirs(project_path)
    os.makedirs(os.path.join(project_path, "cogs"))

    with open(os.path.join(project_path, "main.py"), "w", encoding="utf-8") as f:
        f.write(MAIN_PY)

    with open(os.path.join(project_path, "cogs", "example.py"), "w", encoding="utf-8") as f:
        f.write(COG_TEMPLATE.format(name="Example", name_lower="example"))

    with open(os.path.join(project_path, "requirements.txt"), "w", encoding="utf-8") as f:
        f.write(REQUIREMENTS_TXT)

    with open(os.path.join(project_path, ".env"), "w", encoding="utf-8") as f:
        f.write("TOKEN=your_bot_token_here\n")

    return project_path


def add_cog(cog_name: str, cogs_path: str = None) -> str:
    if not re.match(r"^[a-zA-Z0-9_]+$", cog_name):
        raise InvalidProjectNameError(f"Invalid cog name: {cog_name!r}")

    path = cogs_path or os.path.join(os.getcwd(), "cogs")

    if not os.path.exists(path):
        raise InvalidProjectNameError(f"cogs/ folder not found at: {path}")

    filepath = os.path.join(path, f"{cog_name.lower()}.py")

    if os.path.exists(filepath):
        raise InvalidProjectNameError(f"Cog '{cog_name}' already exists!")

    from .templates import COG_TEMPLATE
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(COG_TEMPLATE.format(name=cog_name.capitalize(), name_lower=cog_name.lower()))

    return filepath


def rename_project(old_name: str, new_name: str, path: str = None) -> str:
    if not re.match(r"^[a-zA-Z0-9_\-]+$", new_name):
        raise InvalidProjectNameError(f"Invalid project name: {new_name!r}")

    base = path or os.getcwd()
    old_path = os.path.join(base, old_name)
    new_path = os.path.join(base, new_name)

    if not os.path.exists(old_path):
        raise InvalidProjectNameError(f"Project '{old_name}' not found!")

    if os.path.exists(new_path):
        raise InvalidProjectNameError(f"'{new_name}' already exists!")

    os.rename(old_path, new_path)
    return new_path


def get_project_info(path: str = None) -> dict:
    base = path or os.getcwd()
    main_py = os.path.join(base, "main.py")
    cogs_dir = os.path.join(base, "cogs")
    requirements = os.path.join(base, "requirements.txt")

    info = {
        "path": base,
        "has_main": os.path.exists(main_py),
        "has_cogs": os.path.exists(cogs_dir),
        "cogs": [],
        "dependencies": [],
    }

    if os.path.exists(cogs_dir):
        info["cogs"] = [f[:-3] for f in os.listdir(cogs_dir) if f.endswith(".py")]

    if os.path.exists(requirements):
        with open(requirements, "r") as f:
            info["dependencies"] = [l.strip() for l in f if l.strip()]

    return info
