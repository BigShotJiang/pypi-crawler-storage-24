from enum import StrEnum
from typing import TypeVar
from nexo.types.string import ListOfStrs


class IdentifierType(StrEnum):
    ID = "id"
    UUID = "uuid"
    CHECKUP_ID = "checkup_id"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]

    @property
    def column(self) -> str:
        return self.value


class Lang(StrEnum):
    ID = "id"
    EN = "en"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptLang = Lang | None
OptLangT = TypeVar("OptLangT", bound=OptLang)
ListOfLangs = list[Lang]
OptListOfLangs = ListOfLangs | None
OptListOfLangsT = TypeVar("OptListOfLangsT", bound=OptListOfLangs)
