from .spark_schema import spark_field_descriptions


def test_spark_field_descriptions_empty_parameters():
    assert spark_field_descriptions({}) == {}


def test_spark_field_descriptions_reads_split_schema():
    parameters = {
        "spark.sql.sources.schema.part.1": (
            '"nullable":true,"metadata":{"comment":"status comment"}}'
            ']},"nullable":true,"metadata":{"comment":"activity comment"}}]}'
        ),
        "spark.sql.sources.schema.part.0": (
            '{"type":"struct","fields":[{"name":"activity","type":{"type":"struct",'
            '"fields":[{"name":"status","type":"string",'
        ),
    }

    assert spark_field_descriptions(parameters) == {
        "activity": "activity comment",
        "activity.status": "status comment",
    }


def test_spark_field_descriptions_flattens_array_of_struct():
    parameters = {
        "spark.sql.sources.schema.part.0": (
            '{"type":"struct","fields":['
            '{"name":"items","type":{"type":"array","elementType":{'
            '"type":"struct","fields":['
            '{"name":"price","type":"long","nullable":true,'
            '"metadata":{"comment":"price comment"}}'
            ']},"containsNull":true},"nullable":true,'
            '"metadata":{"comment":"items comment"}}]}'
        )
    }

    assert spark_field_descriptions(parameters) == {
        "items": "items comment",
        "items.price": "price comment",
    }


def test_spark_field_descriptions_stops_at_map():
    parameters = {
        "spark.sql.sources.schema.part.0": (
            '{"type":"struct","fields":['
            '{"name":"labels","type":{"type":"map","keyType":"string",'
            '"valueType":"string","valueContainsNull":true},'
            '"nullable":true,"metadata":{"comment":"labels comment"}}]}'
        )
    }

    assert spark_field_descriptions(parameters) == {
        "labels": "labels comment",
    }
