import logging
from argparse import ArgumentParser

from castor_extractor.warehouse import glue_athena  # type: ignore

logging.basicConfig(level=logging.INFO, format="%(levelname)s - %(message)s")


def main():
    parser = ArgumentParser()

    parser.add_argument("--access-key-id", help="AWS access key id")
    parser.add_argument("--access-key-secret", help="AWS access key secret")
    parser.add_argument("--aws-region", help="AWS region")
    parser.add_argument("--aws-account-id", help="AWS account id")

    parser.add_argument("-o", "--output", help="Directory to write to")

    args = parser.parse_args()

    glue_athena.extract_all(
        access_key_id=args.access_key_id,
        access_key_secret=args.access_key_secret,
        aws_region=args.aws_region,
        aws_account_id=args.aws_account_id,
        output_directory=args.output,
    )
