class ConfluenceEndpointFactory:
    """
    Confluence rest api v2 endpoint factory.
    https://developer.atlassian.com/cloud/confluence/rest/v2/intro/#about
    """

    API_V1 = "wiki/rest/api/"
    API_V2 = "wiki/api/v2/"
    CONTENT_SEARCH = "content/search"
    DATABASE = "databases"
    FOLDERS = "folders"
    PAGES = "pages"
    SPACES = "spaces"
    USERS = "users-bulk"

    @classmethod
    def database(cls, database_id: str) -> str:
        """
        Endpoint to fetch a database by id.
        More: https://developer.atlassian.com/cloud/confluence/rest/v2/api-group-database/#api-databases-id-get
        """
        return f"{cls.API_V2}{cls.DATABASE}/{database_id}"

    @classmethod
    def folder(cls, folder_id: str) -> str:
        """
        Endpoint to fetch a folder by id.
        More: https://developer.atlassian.com/cloud/confluence/rest/v2/api-group-folder/#api-folders-id-get
        """
        return f"{cls.API_V2}{cls.FOLDERS}/{folder_id}"

    @classmethod
    def pages(cls, space_id: str) -> str:
        """
        Endpoint to fetch all pages in the given space.
        More: https://developer.atlassian.com/cloud/confluence/rest/v2/api-group-page/#api-spaces-id-pages-get
        """
        return f"{cls.API_V2}{cls.SPACES}/{space_id}/{cls.PAGES}?body-format=atlas_doc_format"

    @classmethod
    def spaces(cls) -> str:
        """
        Endpoint to fetch all spaces.
        https://developer.atlassian.com/cloud/confluence/rest/v2/api-group-space/#api-spaces-get
        """
        return f"{cls.API_V2}{cls.SPACES}"

    @classmethod
    def users(cls) -> str:
        """
        Endpoint to fetch all user.
        More: https://developer.atlassian.com/cloud/confluence/rest/v2/api-group-user/#api-users-bulk-post
        """
        return f"{cls.API_V2}{cls.USERS}"

    @classmethod
    def content_search(cls) -> str:
        """
        Endpoint to search content with CQL.
        https://developer.atlassian.com/cloud/confluence/rest/v1/api-group-content/
        """
        return f"{cls.API_V1}{cls.CONTENT_SEARCH}"
