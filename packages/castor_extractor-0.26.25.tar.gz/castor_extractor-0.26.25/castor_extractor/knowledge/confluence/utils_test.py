from .utils import pages_to_folder_ids


def test_pages_to_folder_ids():
    """Test the pages_to_folder_ids function."""
    pages = [
        {"id": "9", "parentId": None, "parentType": None},
        {"id": "8", "parentId": "2", "parentType": "folder"},
        {"id": "7", "parentId": "9", "parentType": "page"},
        {"id": "6", "parentId": "4", "parentType": "folder"},
        {"id": "5", "parentId": "4", "parentType": "folder"},
    ]
    expected = {"2", "4"}
    result = pages_to_folder_ids(pages)
    assert result == expected
