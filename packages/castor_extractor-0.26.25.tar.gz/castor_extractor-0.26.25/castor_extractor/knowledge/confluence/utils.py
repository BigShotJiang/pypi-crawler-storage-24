def pages_to_folder_ids(pages: list[dict]) -> set[str]:
    """Returns all unique folder parents."""
    return {
        page["parentId"] for page in pages if page["parentType"] == "folder"
    }
