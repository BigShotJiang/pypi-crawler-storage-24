# Contributing to Pts.py

Thank you for your interest in Pts.py! We appreciate you taking the time to explore this project.

## Current Status

Pts.py is in its early stages and the API is still evolving.

We are not accepting pull requests at this time, as the core design is actively being shaped and we want to ensure a coherent foundation before opening up to code contributions.

## How You Can Help

The most valuable contributions right now are your feedback and experiences. [Open an issue](https://github.com/williamngan/ptspy/issues):

- **Bug reports** — If something doesn't work as expected, please provide steps to reproduce it.
- **Questions** — If the documentation is unclear or you're unsure how to achieve something, let us know. Your questions help us improve the docs.
- **Feature requests** — Tell us what problems you're trying to solve and what capabilities you need. Understanding real use cases helps us prioritize and design better APIs.
- **Use cases** — Share what you're building or exploring with Pts.py. Seeing how people use the library is incredibly helpful.

When filing a bug report, please include:

- Your Python version and OS
- The version of Pts.py you're using
- A minimal code example that demonstrates the issue or request

## Looking Ahead

As the project matures, we plan to open up to pull requests. Stay tuned!
