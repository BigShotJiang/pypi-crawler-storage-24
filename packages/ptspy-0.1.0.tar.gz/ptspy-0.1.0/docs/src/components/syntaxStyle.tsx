export default {
  hljs: {
    display: "block",
    color: "#f0f5f9",
    background: "#0a0a0a",
  },
  "hljs-comment": {
    color: "#9966ff",
  },
  "hljs-keyword": {
    color: "#76c490",
  },
  "hljs-selector-tag": {
    color: "#88aece",
  },
  "hljs-meta-keyword": {
    color: "#88aece",
  },
  "hljs-doctag": {
    color: "#88aece",
  },
  "hljs-section": {
    color: "#88aece",
  },
  "hljs-selector-class": {
    color: "#88aece",
  },
  "hljs-meta": {
    color: "#88aece",
  },
  "hljs-selector-pseudo": {
    color: "#88aece",
  },
  "hljs-attr": {
    color: "#88aece",
  },
  "hljs-attribute": {
    color: "#c59bc1",
  },
  "hljs-name": {
    color: "#ffc930",
  },
  "hljs-type": {
    color: "#ffc930",
  },
  "hljs-number": {
    color: "#999fac",
  },
  "hljs-selector-id": {
    color: "#f08d49",
  },
  "hljs-quote": {
    color: "#f08d49",
  },
  "hljs-template-tag": {
    color: "#f08d49",
  },
  "hljs-built_in": {
    color: "#f08d49",
  },
  "hljs-title": {
    color: "#ffc930",
  },
  "hljs-literal": {
    color: "#f08d49",
  },
  "hljs-string": {
    color: "#e9a079",
  },
  "hljs-regexp": {
    color: "#b5bd68",
  },
  "hljs-symbol": {
    color: "#b5bd68",
  },
  "hljs-variable": {
    color: "#b5bd68",
  },
  "hljs-template-variable": {
    color: "#b5bd68",
  },
  "hljs-link": {
    color: "#b5bd68",
  },
  "hljs-selector-attr": {
    color: "#b5bd68",
  },
  "hljs-meta-string": {
    color: "#b5bd68",
  },
  "hljs-bullet": {
    color: "#cccccc",
  },
  "hljs-code": {
    color: "#cccccc",
  },
  "hljs-deletion": {
    color: "#de7176",
  },
  "hljs-addition": {
    color: "#76c490",
  },
  "hljs-emphasis": {
    fontStyle: "italic",
  },
  "hljs-strong": {
    fontWeight: "bold",
  },
};
