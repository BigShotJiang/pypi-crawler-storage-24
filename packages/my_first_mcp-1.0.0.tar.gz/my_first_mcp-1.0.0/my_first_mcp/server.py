from mcp.server.fastmcp import FastMCP
from my_first_mcp.tools.datetime_tool import get_current_datetime
from my_first_mcp.tools.date_diff import calculate_date_diff
from my_first_mcp.tools.server_info import get_server_info

mcp = FastMCP("my-first-mcp")


@mcp.tool()
def get_current_datetime_tool(timezone: str = "UTC") -> dict:
    """Retorna a data e hora atual no formato ISO 8601"""
    return get_current_datetime(timezone)


@mcp.tool()
def get_server_info_tool() -> dict:
    """Retorna informações sobre o servidor MCP"""
    return get_server_info()


@mcp.tool()
def calculate_date_diff_tool(date1: str, date2: str) -> dict:
    """Calcula a diferença entre duas datas"""
    return calculate_date_diff(date1, date2)


def main():
    mcp.run()


if __name__ == "__main__":
    main()
