import json
from datetime import datetime
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


def get_current_datetime(timezone: str = "UTC") -> dict:
    try:
        tz = ZoneInfo(timezone)
    except (ZoneInfoNotFoundError, KeyError):
        return {
            "content": [{"type": "text", "text": f'Timezone inválido: "{timezone}". Forneça um identificador IANA válido (ex: "UTC", "America/Sao_Paulo").'}],
            "isError": True,
        }

    now = datetime.now(tz)
    result = {
        "datetime": now.strftime("%Y-%m-%dT%H:%M:%S"),
        "timezone": timezone,
    }
    return {"content": [{"type": "text", "text": json.dumps(result)}]}
