import json
from datetime import datetime, timezone
from importlib.metadata import version, PackageNotFoundError

_started_at = datetime.now(timezone.utc).isoformat()

try:
    _version = version("my-first-mcp")
except PackageNotFoundError:
    _version = "unknown"


def get_server_info() -> dict:
    info = {
        "name": "my-first-mcp",
        "version": _version,
        "description": "Servidor MCP educacional com tools de data/hora",
        "status": "running",
        "startedAt": _started_at,
        "tools": ["get_current_datetime", "get_server_info", "calculate_date_diff"],
    }
    return {"content": [{"type": "text", "text": json.dumps(info, indent=2)}]}
