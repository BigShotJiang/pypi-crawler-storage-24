import json
import re
from datetime import datetime, timezone

DATE_PATTERN = re.compile(
    r"^\d{4}-\d{2}-\d{2}(T\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:\d{2})?)?$"
)


def _parse(date_str: str) -> datetime | None:
    if not DATE_PATTERN.match(date_str):
        return None
    for fmt in ("%Y-%m-%dT%H:%M:%S.%f%z", "%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M", "%Y-%m-%d"):
        try:
            dt = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
            return dt
        except ValueError:
            pass
    return None


def calculate_date_diff(date1: str, date2: str) -> dict:
    d1 = _parse(date1)
    if d1 is None:
        return {"content": [{"type": "text", "text": f'Erro: "date1" é inválida ("{date1}"). Use o formato ISO 8601 (YYYY-MM-DDTHH:MM:SS) ou data simples (YYYY-MM-DD).'}], "isError": True}

    d2 = _parse(date2)
    if d2 is None:
        return {"content": [{"type": "text", "text": f'Erro: "date2" é inválida ("{date2}"). Use o formato ISO 8601 (YYYY-MM-DDTHH:MM:SS) ou data simples (YYYY-MM-DD).'}], "isError": True}

    # Normalize to UTC-aware for comparison
    if d1.tzinfo is None:
        d1 = d1.replace(tzinfo=timezone.utc)
    if d2.tzinfo is None:
        d2 = d2.replace(tzinfo=timezone.utc)

    total_minutes = int(abs((d2 - d1).total_seconds()) // 60)
    days = total_minutes // (60 * 24)
    remaining = total_minutes % (60 * 24)
    hours = remaining // 60
    minutes = remaining % 60

    result = {"days": days, "hours": hours, "minutes": minutes, "totalMinutes": total_minutes}
    return {"content": [{"type": "text", "text": json.dumps(result)}]}
