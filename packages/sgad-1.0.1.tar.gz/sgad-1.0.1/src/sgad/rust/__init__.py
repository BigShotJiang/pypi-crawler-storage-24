"""Rust-accelerated SGAD APIs."""
