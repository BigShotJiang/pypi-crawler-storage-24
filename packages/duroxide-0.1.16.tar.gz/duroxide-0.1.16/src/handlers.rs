use parking_lot::Mutex;
use pyo3::prelude::*;
use std::collections::HashMap;
use std::time::Duration;

use duroxide::{ActivityContext, OrchestrationContext};

use crate::types::{GeneratorStepResult, RetryPolicyConfig, ScheduledTask};

// ─── Shared Context Storage ─────────────────────────────────────

// Global map for activity contexts, keyed by a unique token per invocation.
static ACTIVITY_CTXS: std::sync::LazyLock<Mutex<HashMap<String, ActivityContext>>> =
    std::sync::LazyLock::new(|| Mutex::new(HashMap::new()));

static ACTIVITY_TOKEN_COUNTER: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);

fn new_activity_token() -> String {
    let id = ACTIVITY_TOKEN_COUNTER.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
    format!("act-{id}")
}

struct ActivityCtxGuard {
    token: String,
}

impl Drop for ActivityCtxGuard {
    fn drop(&mut self) {
        ACTIVITY_CTXS.lock().remove(&self.token);
    }
}

/// Called from Python to get the routing tag from the stored ActivityContext.
pub fn activity_tag(token: &str) -> Option<String> {
    let map = ACTIVITY_CTXS.lock();
    map.get(token).and_then(|ctx| ctx.tag().map(String::from))
}

/// Called from Python to check if an activity has been cancelled.
pub fn activity_is_cancelled(token: &str) -> bool {
    let map = ACTIVITY_CTXS.lock();
    map.get(token).is_some_and(|ctx| ctx.is_cancelled())
}

/// Called from Python to get a Client from the stored ActivityContext.
pub fn activity_get_client(token: &str) -> Option<crate::client::PyClient> {
    let map = ACTIVITY_CTXS.lock();
    map.get(token).map(|ctx| {
        let client = ctx.get_client();
        crate::client::PyClient::from_client(client)
    })
}

/// Called from Python to trace through the Rust ActivityContext.
pub fn activity_trace(token: &str, level: &str, message: &str) {
    let map = ACTIVITY_CTXS.lock();
    if let Some(ctx) = map.get(token) {
        match level {
            "warn" => ctx.trace_warn(message),
            "error" => ctx.trace_error(message),
            "debug" => ctx.trace_debug(message),
            _ => ctx.trace_info(message),
        }
    }
}

// Global map for orchestration contexts (keyed by instance_id).
static ORCHESTRATION_CTXS: std::sync::LazyLock<Mutex<HashMap<String, OrchestrationContext>>> =
    std::sync::LazyLock::new(|| Mutex::new(HashMap::new()));

struct OrchestrationInvokeGuard {
    instance_id: String,
    gen_id: Option<u64>,
    dispose_fn: Py<PyAny>,
}

impl OrchestrationInvokeGuard {
    fn new(instance_id: String, dispose_fn: Py<PyAny>) -> Self {
        Self {
            instance_id,
            gen_id: None,
            dispose_fn,
        }
    }

    fn set_gen_id(&mut self, gen_id: u64) {
        self.gen_id = Some(gen_id);
    }
}

impl Drop for OrchestrationInvokeGuard {
    fn drop(&mut self) {
        ORCHESTRATION_CTXS.lock().remove(&self.instance_id);

        let Some(gen_id) = self.gen_id.take() else {
            return;
        };

        // Call dispose synchronously via GIL
        if let Err(e) = Python::with_gil(|py| -> PyResult<()> {
            self.dispose_fn.call1(py, (gen_id.to_string(),))?;
            Ok(())
        }) {
            eprintln!("Warning: dispose_fn failed: {e}");
        }
    }
}

/// Called from Python to trace through the Rust OrchestrationContext.
pub fn orchestration_trace(instance_id: &str, level: &str, message: &str) {
    let map = ORCHESTRATION_CTXS.lock();
    if let Some(ctx) = map.get(instance_id) {
        ctx.trace(level, message);
    }
}

/// Called from Python to set custom status on the OrchestrationContext.
pub fn orchestration_set_custom_status(instance_id: &str, status: &str) {
    let map = ORCHESTRATION_CTXS.lock();
    if let Some(ctx) = map.get(instance_id) {
        ctx.set_custom_status(status);
    }
}

/// Called from Python to reset (clear) custom status on the OrchestrationContext.
pub fn orchestration_reset_custom_status(instance_id: &str) {
    let map = ORCHESTRATION_CTXS.lock();
    if let Some(ctx) = map.get(instance_id) {
        ctx.reset_custom_status();
    }
}

/// Called from Python to read the current custom status from the OrchestrationContext.
pub fn orchestration_get_custom_status(instance_id: &str) -> Option<String> {
    let map = ORCHESTRATION_CTXS.lock();
    map.get(instance_id).and_then(|ctx| ctx.get_custom_status())
}

/// Called from Python to set a KV value on the OrchestrationContext.
pub fn orchestration_set_kv_value(instance_id: &str, key: &str, value: &str) {
    let map = ORCHESTRATION_CTXS.lock();
    if let Some(ctx) = map.get(instance_id) {
        ctx.set_kv_value(key, value);
    }
}

/// Called from Python to read a KV value from the OrchestrationContext.
pub fn orchestration_get_kv_value(instance_id: &str, key: &str) -> Option<String> {
    let map = ORCHESTRATION_CTXS.lock();
    map.get(instance_id).and_then(|ctx| ctx.get_kv_value(key))
}

/// Called from Python to read all KV values from the OrchestrationContext.
pub fn orchestration_get_kv_all_values(instance_id: &str) -> HashMap<String, String> {
    let map = ORCHESTRATION_CTXS.lock();
    map.get(instance_id)
        .map(|ctx| ctx.get_kv_all_values())
        .unwrap_or_default()
}

/// Called from Python to read all KV keys from the OrchestrationContext.
pub fn orchestration_get_kv_all_keys(instance_id: &str) -> Vec<String> {
    let map = ORCHESTRATION_CTXS.lock();
    map.get(instance_id)
        .map(|ctx| ctx.get_kv_all_keys())
        .unwrap_or_default()
}

/// Called from Python to read the KV length from the OrchestrationContext.
pub fn orchestration_get_kv_length(instance_id: &str) -> usize {
    let map = ORCHESTRATION_CTXS.lock();
    map.get(instance_id)
        .map(|ctx| ctx.get_kv_length())
        .unwrap_or_default()
}

/// Called from Python to clear a single KV value on the OrchestrationContext.
pub fn orchestration_clear_kv_value(instance_id: &str, key: &str) {
    let map = ORCHESTRATION_CTXS.lock();
    if let Some(ctx) = map.get(instance_id) {
        ctx.clear_kv_value(key);
    }
}

/// Called from Python to clear all KV values on the OrchestrationContext.
pub fn orchestration_clear_all_kv_values(instance_id: &str) {
    let map = ORCHESTRATION_CTXS.lock();
    if let Some(ctx) = map.get(instance_id) {
        ctx.clear_all_kv_values();
    }
}

/// Called from Python to prune KV values older than the provided cutoff.
pub fn orchestration_prune_kv_values(instance_id: &str, cutoff_ms: u64) -> usize {
    let map = ORCHESTRATION_CTXS.lock();
    map.get(instance_id)
        .map(|ctx| ctx.prune_kv_values_updated_before(cutoff_ms))
        .unwrap_or_default()
}

// ─── Activity Bridge ─────────────────────────────────────────────

/// Wraps a Python callable as a Rust ActivityHandler.
pub struct PyActivityHandler {
    name: String,
    callback: Py<PyAny>,
}

impl PyActivityHandler {
    pub fn new(name: String, callback: Py<PyAny>) -> Self {
        Self { name, callback }
    }

    pub async fn invoke(&self, ctx: ActivityContext, input: String) -> Result<String, String> {
        // Store ctx in global map with a unique token so Python trace calls can find it
        let token = new_activity_token();
        ACTIVITY_CTXS.lock().insert(token.clone(), ctx.clone());
        let _guard = ActivityCtxGuard {
            token: token.clone(),
        };

        // Build a context info object as JSON for the Python side
        let ctx_info = serde_json::json!({
            "instanceId": ctx.instance_id(),
            "executionId": ctx.execution_id(),
            "orchestrationName": ctx.orchestration_name(),
            "orchestrationVersion": ctx.orchestration_version(),
            "activityName": ctx.activity_name(),
            "workerId": ctx.worker_id(),
            "sessionId": ctx.session_id(),
            "tag": ctx.tag(),
            "_traceToken": token,
        });

        // Send "ctxJson\ninput" to Python
        let payload = format!("{}\n{}", ctx_info, input);

        // Call the Python callable synchronously via GIL (activity functions are regular def)
        let result: String = tokio::task::block_in_place(|| {
            Python::with_gil(|py| {
                let result = self
                    .callback
                    .call1(py, (payload,))
                    .map_err(|e| format!("Activity '{}' call failed: {}", self.name, e))?;
                result
                    .extract::<String>(py)
                    .map_err(|e| format!("Activity '{}' invalid result: {}", self.name, e))
            })
        })?;

        Ok(result)
    }
}

// ─── Orchestration Bridge ────────────────────────────────────────

/// Wraps Python generator-driver functions as a Rust OrchestrationHandler.
///
/// Architecture:
/// - Python side: user writes generator functions that yield ScheduledTask descriptors
/// - The generator yields ScheduledTask descriptors as JSON
/// - Rust handler loop: get next task from Python → execute with real DurableFuture → feed result back
pub struct PyOrchestrationHandler {
    /// Called to create the generator and drive the first step.
    create_fn: Py<PyAny>,
    /// Called to drive the generator one step with a result.
    next_fn: Py<PyAny>,
    /// Called to dispose of a generator.
    dispose_fn: Py<PyAny>,
}

impl PyOrchestrationHandler {
    pub fn new(create_fn: Py<PyAny>, next_fn: Py<PyAny>, dispose_fn: Py<PyAny>) -> Self {
        Self {
            create_fn,
            next_fn,
            dispose_fn,
        }
    }

    /// Call the Python create function synchronously using block_in_place + GIL.
    fn call_create_blocking(&self, payload: String) -> Result<GeneratorStepResult, String> {
        tokio::task::block_in_place(|| {
            Python::with_gil(|py| {
                let result = self
                    .create_fn
                    .call1(py, (payload,))
                    .map_err(|e| format!("Generator create failed: {e}"))?;
                let json_str: String = result
                    .extract(py)
                    .map_err(|e| format!("Invalid result: {e}"))?;
                serde_json::from_str(&json_str)
                    .map_err(|e| format!("Invalid generator step result: {e}"))
            })
        })
    }

    fn call_next_blocking(
        &self,
        gen_id: u64,
        result: &str,
        is_error: bool,
    ) -> Result<GeneratorStepResult, String> {
        let payload = serde_json::json!({
            "generatorId": gen_id,
            "result": result,
            "isError": is_error,
        })
        .to_string();

        tokio::task::block_in_place(|| {
            Python::with_gil(|py| {
                let result = self
                    .next_fn
                    .call1(py, (payload,))
                    .map_err(|e| format!("Generator next failed: {e}"))?;
                let json_str: String = result
                    .extract(py)
                    .map_err(|e| format!("Invalid result: {e}"))?;
                serde_json::from_str(&json_str)
                    .map_err(|e| format!("Invalid generator step result: {e}"))
            })
        })
    }

    /// Execute a ScheduledTask using the real OrchestrationContext.
    async fn execute_task(&self, ctx: &OrchestrationContext, task: ScheduledTask) -> TaskResult {
        match task {
            ScheduledTask::Activity { name, input, tag } => {
                let future = ctx.schedule_activity(&name, input);
                match if let Some(t) = tag {
                    future.with_tag(t).await
                } else {
                    future.await
                } {
                    Ok(val) => TaskResult::Ok(val),
                    Err(err) => TaskResult::Err(err),
                }
            }
            ScheduledTask::ActivityWithSession {
                name,
                input,
                session_id,
                tag,
            } => {
                let future = ctx.schedule_activity_on_session(&name, input, session_id);
                match if let Some(t) = tag {
                    future.with_tag(t).await
                } else {
                    future.await
                } {
                    Ok(val) => TaskResult::Ok(val),
                    Err(err) => TaskResult::Err(err),
                }
            }
            ScheduledTask::ActivityWithRetry {
                name,
                input,
                retry,
                tag,
            } => {
                if let Some(t) = tag {
                    // Retry with tag: manually retry using schedule_activity + with_tag
                    let policy = convert_retry_policy(&retry);
                    match retry_with_tag(ctx, &name, &input, &t, &policy).await {
                        Ok(val) => TaskResult::Ok(val),
                        Err(err) => TaskResult::Err(err),
                    }
                } else {
                    let policy = convert_retry_policy(&retry);
                    match ctx.schedule_activity_with_retry(&name, input, policy).await {
                        Ok(val) => TaskResult::Ok(val),
                        Err(err) => TaskResult::Err(err),
                    }
                }
            }
            ScheduledTask::Timer { delay_ms } => {
                ctx.schedule_timer(Duration::from_millis(delay_ms)).await;
                TaskResult::Ok("null".to_string())
            }
            ScheduledTask::WaitEvent { name } => {
                let data = ctx.schedule_wait(&name).await;
                TaskResult::Ok(data)
            }
            ScheduledTask::SubOrchestration { name, input } => {
                match ctx.schedule_sub_orchestration(&name, input).await {
                    Ok(val) => TaskResult::Ok(val),
                    Err(err) => TaskResult::Err(err),
                }
            }
            ScheduledTask::SubOrchestrationWithId {
                name,
                instance_id,
                input,
            } => match ctx
                .schedule_sub_orchestration_with_id(&name, instance_id, input)
                .await
            {
                Ok(val) => TaskResult::Ok(val),
                Err(err) => TaskResult::Err(err),
            },
            ScheduledTask::Orchestration {
                name,
                instance_id,
                input,
            } => {
                ctx.schedule_orchestration(&name, &instance_id, input);
                TaskResult::Ok("null".to_string())
            }
            ScheduledTask::OrchestrationVersioned {
                name,
                version,
                instance_id,
                input,
            } => {
                ctx.schedule_orchestration_versioned(&name, version, &instance_id, input);
                TaskResult::Ok("null".to_string())
            }
            ScheduledTask::SubOrchestrationVersioned {
                name,
                version,
                input,
            } => match ctx
                .schedule_sub_orchestration_versioned(&name, version, input)
                .await
            {
                Ok(val) => TaskResult::Ok(val),
                Err(err) => TaskResult::Err(err),
            },
            ScheduledTask::SubOrchestrationVersionedWithId {
                name,
                version,
                instance_id,
                input,
            } => match ctx
                .schedule_sub_orchestration_versioned_with_id(&name, version, instance_id, input)
                .await
            {
                Ok(val) => TaskResult::Ok(val),
                Err(err) => TaskResult::Err(err),
            },
            ScheduledTask::NewGuid => match ctx.new_guid().await {
                Ok(g) => TaskResult::Ok(format!("\"{}\"", g)),
                Err(e) => TaskResult::Err(e),
            },
            ScheduledTask::UtcNow => match ctx.utc_now().await {
                Ok(t) => {
                    let ms = t
                        .duration_since(std::time::UNIX_EPOCH)
                        .unwrap_or_default()
                        .as_millis();
                    TaskResult::Ok(ms.to_string())
                }
                Err(e) => TaskResult::Err(e),
            },
            ScheduledTask::ContinueAsNew { input } => match ctx.continue_as_new(input).await {
                Ok(_) => TaskResult::Ok("null".to_string()),
                Err(e) => TaskResult::Err(e),
            },
            ScheduledTask::ContinueAsNewVersioned { input, version } => {
                let result = if let Some(ver) = version {
                    ctx.continue_as_new_versioned(ver, input).await
                } else {
                    ctx.continue_as_new(input).await
                };
                match result {
                    Ok(_) => TaskResult::Ok("null".to_string()),
                    Err(e) => TaskResult::Err(e),
                }
            }
            ScheduledTask::DequeueEvent { queue_name } => {
                let data = ctx.dequeue_event(&queue_name).await;
                TaskResult::Ok(data)
            }
            ScheduledTask::ActivityWithRetryOnSession {
                name,
                input,
                retry,
                session_id,
                tag,
            } => {
                if let Some(t) = tag {
                    let policy = convert_retry_policy(&retry);
                    match retry_on_session_with_tag(ctx, &name, &input, &session_id, &t, &policy)
                        .await
                    {
                        Ok(val) => TaskResult::Ok(val),
                        Err(err) => TaskResult::Err(err),
                    }
                } else {
                    let policy = convert_retry_policy(&retry);
                    match ctx
                        .schedule_activity_with_retry_on_session(&name, input, policy, &session_id)
                        .await
                    {
                        Ok(val) => TaskResult::Ok(val),
                        Err(err) => TaskResult::Err(err),
                    }
                }
            }
            ScheduledTask::Join { tasks } => {
                for t in &tasks {
                    match t {
                        ScheduledTask::Join { .. } | ScheduledTask::Select { .. } => {
                            return TaskResult::Err(
                                "nested join/select inside join is not supported".to_string(),
                            );
                        }
                        _ => {}
                    }
                }

                let futures: Vec<
                    std::pin::Pin<Box<dyn std::future::Future<Output = String> + Send + '_>>,
                > = tasks
                    .into_iter()
                    .map(|t| make_join_future(ctx, t))
                    .collect();

                let results = ctx.join(futures).await;
                let json_results: Vec<serde_json::Value> = results
                    .into_iter()
                    .map(|v| {
                        serde_json::from_str::<serde_json::Value>(&v)
                            .unwrap_or(serde_json::Value::String(v))
                    })
                    .collect();
                TaskResult::Ok(serde_json::to_string(&json_results).unwrap())
            }
            ScheduledTask::Select { tasks } => {
                if tasks.len() != 2 {
                    return TaskResult::Err(
                        "select currently supports exactly 2 tasks".to_string(),
                    );
                }
                for t in &tasks {
                    match t {
                        ScheduledTask::Join { .. } | ScheduledTask::Select { .. } => {
                            return TaskResult::Err(
                                "nested join/select inside select is not supported".to_string(),
                            );
                        }
                        _ => {}
                    }
                }
                let mut iter = tasks.into_iter();
                let t1 = iter.next().unwrap();
                let t2 = iter.next().unwrap();

                let f1 = make_select_future(ctx, t1);
                let f2 = make_select_future(ctx, t2);

                match ctx.select2(f1, f2).await {
                    duroxide::Either2::First(val) => {
                        // Parse val as JSON so it's embedded as a structured value,
                        // not double-serialized as a JSON string.
                        let parsed = serde_json::from_str::<serde_json::Value>(&val)
                            .unwrap_or(serde_json::Value::String(val));
                        TaskResult::Ok(
                            serde_json::json!({ "index": 0, "value": parsed }).to_string(),
                        )
                    }
                    duroxide::Either2::Second(val) => {
                        let parsed = serde_json::from_str::<serde_json::Value>(&val)
                            .unwrap_or(serde_json::Value::String(val));
                        TaskResult::Ok(
                            serde_json::json!({ "index": 1, "value": parsed }).to_string(),
                        )
                    }
                }
            }
        }
    }
}

enum TaskResult {
    Ok(String),
    Err(String),
}

/// Convert a ScheduledTask into a type-erased future returning a raw string for use in select.
fn make_select_future(
    ctx: &OrchestrationContext,
    task: ScheduledTask,
) -> std::pin::Pin<Box<dyn std::future::Future<Output = String> + Send + '_>> {
    match task {
        ScheduledTask::Activity { name, input, tag } => Box::pin(async move {
            let future = ctx.schedule_activity(&name, input);
            match if let Some(t) = tag {
                future.with_tag(t).await
            } else {
                future.await
            } {
                Ok(v) => v,
                Err(e) => e,
            }
        }),
        ScheduledTask::ActivityWithSession {
            name,
            input,
            session_id,
            tag,
        } => Box::pin(async move {
            let future = ctx.schedule_activity_on_session(&name, input, session_id);
            match if let Some(t) = tag {
                future.with_tag(t).await
            } else {
                future.await
            } {
                Ok(v) => v,
                Err(e) => e,
            }
        }),
        ScheduledTask::ActivityWithRetry {
            name,
            input,
            retry,
            tag,
        } => Box::pin(async move {
            if let Some(t) = tag {
                let policy = convert_retry_policy(&retry);
                match retry_with_tag(ctx, &name, &input, &t, &policy).await {
                    Ok(v) => v,
                    Err(e) => e,
                }
            } else {
                let policy = convert_retry_policy(&retry);
                match ctx.schedule_activity_with_retry(&name, input, policy).await {
                    Ok(v) => v,
                    Err(e) => e,
                }
            }
        }),
        ScheduledTask::Timer { delay_ms } => Box::pin(async move {
            ctx.schedule_timer(Duration::from_millis(delay_ms)).await;
            "null".to_string()
        }),
        ScheduledTask::WaitEvent { name } => {
            Box::pin(async move { ctx.schedule_wait(&name).await })
        }
        ScheduledTask::SubOrchestration { name, input } => Box::pin(async move {
            match ctx.schedule_sub_orchestration(&name, input).await {
                Ok(v) => v,
                Err(e) => e,
            }
        }),
        ScheduledTask::SubOrchestrationWithId {
            name,
            instance_id,
            input,
        } => Box::pin(async move {
            match ctx
                .schedule_sub_orchestration_with_id(&name, instance_id, input)
                .await
            {
                Ok(v) => v,
                Err(e) => e,
            }
        }),
        ScheduledTask::SubOrchestrationVersioned {
            name,
            version,
            input,
        } => Box::pin(async move {
            match ctx
                .schedule_sub_orchestration_versioned(&name, version, input)
                .await
            {
                Ok(v) => v,
                Err(e) => e,
            }
        }),
        ScheduledTask::SubOrchestrationVersionedWithId {
            name,
            version,
            instance_id,
            input,
        } => Box::pin(async move {
            match ctx
                .schedule_sub_orchestration_versioned_with_id(&name, version, instance_id, input)
                .await
            {
                Ok(v) => v,
                Err(e) => e,
            }
        }),
        ScheduledTask::DequeueEvent { queue_name } => {
            Box::pin(async move { ctx.dequeue_event(&queue_name).await })
        }
        ScheduledTask::ActivityWithRetryOnSession {
            name,
            input,
            retry,
            session_id,
            tag,
        } => Box::pin(async move {
            if let Some(t) = tag {
                let policy = convert_retry_policy(&retry);
                match retry_on_session_with_tag(ctx, &name, &input, &session_id, &t, &policy).await
                {
                    Ok(v) => v,
                    Err(e) => e,
                }
            } else {
                let policy = convert_retry_policy(&retry);
                match ctx
                    .schedule_activity_with_retry_on_session(&name, input, policy, &session_id)
                    .await
                {
                    Ok(v) => v,
                    Err(e) => e,
                }
            }
        }),
        _ => Box::pin(async { "unsupported task in select".to_string() }),
    }
}

/// Wrap a raw string value as `{"ok": <parsed>}` or `{"err": <parsed>}` JSON.
/// Parses the string as JSON first to avoid double-serialization.
fn wrap_ok(val: String) -> String {
    let parsed =
        serde_json::from_str::<serde_json::Value>(&val).unwrap_or(serde_json::Value::String(val));
    serde_json::json!({ "ok": parsed }).to_string()
}

fn wrap_err(val: String) -> String {
    let parsed =
        serde_json::from_str::<serde_json::Value>(&val).unwrap_or(serde_json::Value::String(val));
    serde_json::json!({ "err": parsed }).to_string()
}

/// Convert a ScheduledTask into a type-erased future returning `{ok:v}/{err:e}` JSON for use in join.
fn make_join_future(
    ctx: &OrchestrationContext,
    task: ScheduledTask,
) -> std::pin::Pin<Box<dyn std::future::Future<Output = String> + Send + '_>> {
    match task {
        ScheduledTask::Activity { name, input, tag } => Box::pin(async move {
            let future = ctx.schedule_activity(&name, input);
            match if let Some(t) = tag {
                future.with_tag(t).await
            } else {
                future.await
            } {
                Ok(v) => wrap_ok(v),
                Err(e) => wrap_err(e),
            }
        }),
        ScheduledTask::ActivityWithSession {
            name,
            input,
            session_id,
            tag,
        } => Box::pin(async move {
            let future = ctx.schedule_activity_on_session(&name, input, session_id);
            match if let Some(t) = tag {
                future.with_tag(t).await
            } else {
                future.await
            } {
                Ok(v) => wrap_ok(v),
                Err(e) => wrap_err(e),
            }
        }),
        ScheduledTask::ActivityWithRetry {
            name,
            input,
            retry,
            tag,
        } => Box::pin(async move {
            if let Some(t) = tag {
                let policy = convert_retry_policy(&retry);
                match retry_with_tag(ctx, &name, &input, &t, &policy).await {
                    Ok(v) => wrap_ok(v),
                    Err(e) => wrap_err(e),
                }
            } else {
                let policy = convert_retry_policy(&retry);
                match ctx.schedule_activity_with_retry(&name, input, policy).await {
                    Ok(v) => wrap_ok(v),
                    Err(e) => wrap_err(e),
                }
            }
        }),
        ScheduledTask::Timer { delay_ms } => Box::pin(async move {
            ctx.schedule_timer(Duration::from_millis(delay_ms)).await;
            serde_json::json!({ "ok": null }).to_string()
        }),
        ScheduledTask::WaitEvent { name } => Box::pin(async move {
            let data = ctx.schedule_wait(&name).await;
            wrap_ok(data)
        }),
        ScheduledTask::SubOrchestration { name, input } => Box::pin(async move {
            match ctx.schedule_sub_orchestration(&name, input).await {
                Ok(v) => wrap_ok(v),
                Err(e) => wrap_err(e),
            }
        }),
        ScheduledTask::SubOrchestrationWithId {
            name,
            instance_id,
            input,
        } => Box::pin(async move {
            match ctx
                .schedule_sub_orchestration_with_id(&name, instance_id, input)
                .await
            {
                Ok(v) => wrap_ok(v),
                Err(e) => wrap_err(e),
            }
        }),
        ScheduledTask::SubOrchestrationVersioned {
            name,
            version,
            input,
        } => Box::pin(async move {
            match ctx
                .schedule_sub_orchestration_versioned(&name, version, input)
                .await
            {
                Ok(v) => wrap_ok(v),
                Err(e) => wrap_err(e),
            }
        }),
        ScheduledTask::SubOrchestrationVersionedWithId {
            name,
            version,
            instance_id,
            input,
        } => Box::pin(async move {
            match ctx
                .schedule_sub_orchestration_versioned_with_id(&name, version, instance_id, input)
                .await
            {
                Ok(v) => wrap_ok(v),
                Err(e) => wrap_err(e),
            }
        }),
        ScheduledTask::DequeueEvent { queue_name } => Box::pin(async move {
            let data = ctx.dequeue_event(&queue_name).await;
            wrap_ok(data)
        }),
        ScheduledTask::ActivityWithRetryOnSession {
            name,
            input,
            retry,
            session_id,
            tag,
        } => Box::pin(async move {
            if let Some(t) = tag {
                let policy = convert_retry_policy(&retry);
                match retry_on_session_with_tag(ctx, &name, &input, &session_id, &t, &policy).await
                {
                    Ok(v) => wrap_ok(v),
                    Err(e) => wrap_err(e),
                }
            } else {
                let policy = convert_retry_policy(&retry);
                match ctx
                    .schedule_activity_with_retry_on_session(&name, input, policy, &session_id)
                    .await
                {
                    Ok(v) => wrap_ok(v),
                    Err(e) => wrap_err(e),
                }
            }
        }),
        _ => {
            Box::pin(async { serde_json::json!({ "err": "unsupported task in join" }).to_string() })
        }
    }
}

#[async_trait::async_trait]
impl duroxide::runtime::OrchestrationHandler for PyOrchestrationHandler {
    async fn invoke(&self, ctx: OrchestrationContext, input: String) -> Result<String, String> {
        let instance_id = ctx.instance_id().to_string();

        // Store ctx in global map so Python trace calls can delegate to it
        ORCHESTRATION_CTXS
            .lock()
            .insert(instance_id.clone(), ctx.clone());
        let mut guard = OrchestrationInvokeGuard::new(
            instance_id.clone(),
            Python::with_gil(|py| self.dispose_fn.clone_ref(py)),
        );

        let ctx_info = serde_json::json!({
            "instanceId": ctx.instance_id(),
            "executionId": ctx.execution_id(),
            "orchestrationName": ctx.orchestration_name(),
            "orchestrationVersion": ctx.orchestration_version(),
        });

        let payload = serde_json::json!({
            "ctxInfo": ctx_info,
            "input": input,
        })
        .to_string();

        // Step 1: Create generator and get first step (blocking call to Python)
        let first_step = self.call_create_blocking(payload)?;

        let (gen_id, mut current_step) = match first_step {
            GeneratorStepResult::Completed { output } => return Ok(output),
            GeneratorStepResult::Error { message } => return Err(message),
            GeneratorStepResult::Yielded { generator_id, task } => {
                guard.set_gen_id(generator_id);
                (generator_id, task)
            }
        };

        // Step 2: Execute task → feed result back → repeat
        loop {
            let result = self.execute_task(&ctx, current_step).await;

            let (result_str, is_error) = match result {
                TaskResult::Ok(val) => (val, false),
                TaskResult::Err(err) => (err, true),
            };

            let next_step = self.call_next_blocking(gen_id, &result_str, is_error)?;

            match next_step {
                GeneratorStepResult::Completed { output } => return Ok(output),
                GeneratorStepResult::Error { message } => return Err(message),
                GeneratorStepResult::Yielded { task, .. } => {
                    current_step = task;
                }
            }
        }
    }
}

/// Retry an activity with a tag, mirroring the duroxide core retry logic.
/// Core's `schedule_activity_with_retry` is `async fn` and can't chain `.with_tag()`,
/// so we implement the retry loop here using `schedule_activity().with_tag()`.
async fn retry_with_tag(
    ctx: &OrchestrationContext,
    name: &str,
    input: &str,
    tag: &str,
    policy: &duroxide::RetryPolicy,
) -> Result<String, String> {
    let mut last_error = String::new();
    for attempt in 1..=policy.max_attempts {
        let activity_result = if let Some(timeout) = policy.timeout {
            let deadline = async {
                ctx.schedule_timer(timeout).await;
                Err::<String, String>("timeout: activity timed out".to_string())
            };
            let activity = ctx.schedule_activity(name, input).with_tag(tag);
            match ctx.select2(activity, deadline).await {
                duroxide::Either2::First(result) => result,
                duroxide::Either2::Second(Err(e)) => return Err(e),
                duroxide::Either2::Second(Ok(_)) => unreachable!(),
            }
        } else {
            ctx.schedule_activity(name, input).with_tag(tag).await
        };
        match activity_result {
            Ok(result) => return Ok(result),
            Err(e) => {
                last_error = e;
                if attempt < policy.max_attempts {
                    let delay = policy.delay_for_attempt(attempt);
                    if !delay.is_zero() {
                        ctx.schedule_timer(delay).await;
                    }
                }
            }
        }
    }
    Err(last_error)
}

/// Retry an activity with session affinity and a tag.
async fn retry_on_session_with_tag(
    ctx: &OrchestrationContext,
    name: &str,
    input: &str,
    session_id: &str,
    tag: &str,
    policy: &duroxide::RetryPolicy,
) -> Result<String, String> {
    let mut last_error = String::new();
    for attempt in 1..=policy.max_attempts {
        let activity_result = if let Some(timeout) = policy.timeout {
            let deadline = async {
                ctx.schedule_timer(timeout).await;
                Err::<String, String>("timeout: activity timed out".to_string())
            };
            let activity = ctx
                .schedule_activity_on_session(name, input, session_id)
                .with_tag(tag);
            match ctx.select2(activity, deadline).await {
                duroxide::Either2::First(result) => result,
                duroxide::Either2::Second(Err(e)) => return Err(e),
                duroxide::Either2::Second(Ok(_)) => unreachable!(),
            }
        } else {
            ctx.schedule_activity_on_session(name, input, session_id)
                .with_tag(tag)
                .await
        };
        match activity_result {
            Ok(result) => return Ok(result),
            Err(e) => {
                last_error = e;
                if attempt < policy.max_attempts {
                    let delay = policy.delay_for_attempt(attempt);
                    if !delay.is_zero() {
                        ctx.schedule_timer(delay).await;
                    }
                }
            }
        }
    }
    Err(last_error)
}

fn convert_retry_policy(config: &RetryPolicyConfig) -> duroxide::RetryPolicy {
    let mut policy = duroxide::RetryPolicy::new(config.max_attempts);
    if let Some(ms) = config.timeout_ms {
        policy = policy.with_timeout(Duration::from_millis(ms));
    }
    if let Some(ms) = config.total_timeout_ms {
        policy = policy.with_total_timeout(Duration::from_millis(ms));
    }
    if let Some(ref backoff) = config.backoff {
        let strategy = match backoff.as_str() {
            "exponential" => duroxide::BackoffStrategy::Exponential {
                base: Duration::from_millis(100),
                multiplier: 2.0,
                max: Duration::from_secs(30),
            },
            "fixed" => duroxide::BackoffStrategy::Fixed {
                delay: Duration::from_secs(1),
            },
            _ => duroxide::BackoffStrategy::Linear {
                base: Duration::from_millis(100),
                max: Duration::from_secs(30),
            },
        };
        policy = policy.with_backoff(strategy);
    }
    policy
}
