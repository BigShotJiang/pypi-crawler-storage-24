from __future__ import annotations

import sys
import threading
from typing import Callable, List

from pulselog.queue import LogQueue
from pulselog.record import LogRecord

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
WORKER_INTERVAL = 0.01          # FIX #5: reduced from 0.05s → 0.01s (10ms)
                                 # At 38.5k/sec multi-thread, 50ms filled the queue.
                                 # 10ms drains 5× more frequently, preventing drops.
WORKER_SHUTDOWN_TIMEOUT = 5.0   # raised from 2.0s — gives larger queues time to flush
_ADAPTIVE_THRESHOLD = 0.5       # fraction of queue capacity that triggers faster drains


class BackgroundWorker(threading.Thread):
    """Daemon thread that drains the LogQueue and dispatches batches to handlers.

    The worker sleeps on a ``threading.Event`` so it wakes immediately when new
    records arrive, rather than polling every N milliseconds.  It also wakes
    periodically (every ``interval`` seconds) to flush any records that arrived
    between drain cycles.

    Adaptive draining: when the queue is more than 50% full the worker
    halves its sleep interval so it catches up faster under burst load.

    Handler contract:
        Each handler is called as ``handler(batch: List[LogRecord])``.
        If a handler raises an exception the error is written to stderr and the
        worker continues — a bad handler must never crash the pipeline.
    """

    def __init__(
        self,
        queue: LogQueue,
        handlers: List[Callable[[List[LogRecord]], None]],
        interval: float = WORKER_INTERVAL,
    ) -> None:
        super().__init__(daemon=True, name="pulselog-worker")
        self._queue = queue
        self._handlers: List[Callable[[List[LogRecord]], None]] = [
            h for h in handlers if h is not None
        ]
        self._base_interval = max(interval, 0.005)  # floor raised to 5ms for safety
        self._interval = self._base_interval
        self._stop_event = threading.Event()

    # ------------------------------------------------------------------
    # Thread entry-point
    # ------------------------------------------------------------------

    def run(self) -> None:
        """Main loop: wait → drain → dispatch.  Runs until shutdown() is called."""
        while not self._stop_event.is_set():
            # Block until a record arrives OR timeout expires.
            self._queue._event.wait(timeout=self._interval)

            batch = self._queue.drain()
            if batch:
                self._dispatch(batch)
                # FIX #5 adaptive: if queue is still filling up, drain faster
                self._adapt_interval()

        # Final drain after stop signal — flush whatever remains.
        batch = self._queue.drain()
        if batch:
            self._dispatch(batch)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def shutdown(self, timeout: float = WORKER_SHUTDOWN_TIMEOUT) -> None:
        """Signal the worker to stop and wait for it to finish.

        Args:
            timeout: Maximum seconds to wait for thread termination.
        """
        self._stop_event.set()
        self._queue._event.set()  # wake immediately so the loop can exit
        self.join(timeout=timeout)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _adapt_interval(self) -> None:
        """Halve the sleep interval when queue is under pressure, restore when calm."""
        queue_len = len(self._queue)
        capacity = self._queue._deque.maxlen or 1
        fill_ratio = queue_len / capacity

        if fill_ratio >= _ADAPTIVE_THRESHOLD:
            # Queue is >50% full — drain twice as fast
            self._interval = max(self._base_interval / 2, 0.005)
        else:
            # Queue is healthy — restore normal interval
            self._interval = self._base_interval

    def _dispatch(self, batch: List[LogRecord]) -> None:
        """Call each handler with the batch; swallow and log any exceptions."""
        for handler in self._handlers:
            try:
                handler(batch)
            except Exception as exc:  # handler must not crash the worker
                sys.stderr.write(
                    f"[pulselog] Handler {handler!r} raised an exception: {exc}\n"
                )