from __future__ import annotations

import itertools
import time
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

from pulselog.levels import Level

# ---------------------------------------------------------------------------
# Global sequence counter — atomic on CPython due to the GIL.
# Provides a monotonic ordering tie-breaker when timestamps collide.
# ---------------------------------------------------------------------------
_seq_counter = itertools.count(1)


@dataclass
class LogRecord:
    """Immutable snapshot of a single log event.

    Attributes:
        level:     Severity level.
        msg:       Log message string.
        timestamp: Unix timestamp (seconds) when the record was created.
        extra:     Arbitrary key/value metadata supplied by the caller.
        tag:       Active tag label at the time of logging, or None.
        seq:       Monotonic sequence number — unique per process lifetime.
                   Guarantees ordering when two records share a timestamp.
    """

    # NOTE: __slots__ is intentionally omitted.
    # @dataclass(slots=True) requires Python 3.10+. Since pulselog supports
    # 3.8+, a manual __slots__ definition conflicts with field(default_factory=...)
    # and raises ValueError at import time on 3.8/3.9. Skip it.

    level: Level
    msg: str
    timestamp: float = field(default_factory=time.time)
    extra: Dict[str, Any] = field(default_factory=dict)
    tag: Optional[str] = None
    seq: int = field(default_factory=lambda: next(_seq_counter))  # FIX #14

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to a JSON-serializable dict.

        Returns:
            Dict with string keys and JSON-safe values.
        """
        return {
            "level": self.level.name,
            "msg": self.msg,
            "timestamp": self.timestamp,
            "extra": self.extra,
            "tag": self.tag,
            "seq": self.seq,
        }