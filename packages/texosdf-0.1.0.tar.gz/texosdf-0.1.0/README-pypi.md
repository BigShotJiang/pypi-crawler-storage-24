# texosdf

`texosdf` is a lightweight Python package for generating 3D meshes from signed
distance functions (SDFs).

It is a modernized fork of [fogleman/sdf](https://github.com/fogleman/sdf),
published as `texosdf` with proper packaging, curated exports, typed modules,
and clearer optional dependency handling.

![texosdf example](https://raw.githubusercontent.com/torayeff/texosdf/main/docs/images/example.png)

## Installation

Install the core package:

```bash
pip install texosdf
```

Optional extras:

```bash
pip install texosdf[plot]
pip install texosdf[mesh]
pip install texosdf[all]
```

Notes:

- `plot` installs `matplotlib` for `show_slice()`
- `mesh` installs `meshio` for mesh loading and non-STL export
- `Mesh.sdf()` also requires OpenVDB and `pyopenvdb`
- `pyopenvdb` is intentionally not included in package requirements because it
  is platform-specific and only needed for the advanced mesh-to-SDF workflow

## Quickstart

```python
from texosdf import *

shape = sphere(1) & box(1.5)

cutout = cylinder(0.5)
shape -= cutout.orient(X) | cutout.orient(Y) | cutout.orient(Z)

shape.save("out.stl")
```

## Why `import *`?

While `import *` is usually not ideal in general Python code, CAD and geometry
scripting has broadly moved in that direction because it makes modeling scripts
shorter and easier to read. `texosdf` keeps that convenience on purpose.

If you use Ruff in scripts written that way, add:

```python
# ruff: noqa: F403, F405
from texosdf import *
```

## Features

- 2D and 3D analytic SDF primitives
- boolean operators such as union, difference, and intersection
- transforms and deformations such as translate, rotate, twist, bend, and shell
- 2D-to-3D operations such as extrude, revolve, and profile blending
- text and image-based masks
- optional plotting and mesh loading/export helpers
- custom SDF authoring with decorators such as `@sdf2`, `@sdf3`, `@op2`, and
  `@op3`

## Full Documentation

- GitHub repository: [torayeff/texosdf](https://github.com/torayeff/texosdf)
- Full documentation and examples: [README on GitHub](https://github.com/torayeff/texosdf#readme)
- Example scripts: [examples folder](https://github.com/torayeff/texosdf/tree/main/examples)
