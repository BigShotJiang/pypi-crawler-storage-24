"""Mesh helpers and mesh-to-SDF conversion utilities."""

from __future__ import annotations

import numpy as np
from scipy import interpolate

try:
    import meshio
except ImportError as exc:  # pragma: no cover - exercised via failure path tests.
    meshio = None
    _MESHIO_IMPORT_ERROR = exc
else:  # pragma: no cover - trivial branch.
    _MESHIO_IMPORT_ERROR = None

# OpenVDB is intentionally optional because it is commonly installed outside of
# pip and is only needed for the advanced mesh-to-SDF conversion path.
try:
    import pyopenvdb as vdb
except ImportError as exc:  # pragma: no cover - exercised via failure path tests.
    vdb = None
    _OPENVDB_IMPORT_ERROR = exc
else:  # pragma: no cover - trivial branch.
    _OPENVDB_IMPORT_ERROR = None

from ._types import AnyArrayLike, Bounds3D, PathLikeStr, ScalarOrVector3
from .d3 import box, sdf3


def _require_meshio():
    if meshio is None:
        raise ImportError(
            "meshio is required for mesh file loading. Install texosdf with the "
            "'mesh' extra, for example: pip install texosdf[mesh]"
        ) from _MESHIO_IMPORT_ERROR
    return meshio


def _require_openvdb() -> None:
    if vdb is None:
        raise ImportError(
            "pyopenvdb is required for Mesh.sdf(). Install OpenVDB and its Python bindings first."
        ) from _OPENVDB_IMPORT_ERROR


class Mesh:
    """Triangle mesh wrapper used for mesh loading and transformation.

    Args:
        points: Vertex coordinates with shape ``(N, 3)``.
        triangles: Triangle indices with shape ``(M, 3)``.
    """

    @classmethod
    def from_file(cls, path: PathLikeStr) -> "Mesh":
        """Load a triangle mesh from disk."""
        meshio_module = _require_meshio()
        mesh = meshio_module.read(path)
        triangle_block = next(
            (cell.data for cell in mesh.cells if cell.type == "triangle"), None
        )
        if triangle_block is None:
            raise ValueError("Mesh file does not contain triangle cells.")
        points = np.asarray(mesh.points[:, :3], dtype=float)
        triangles = np.asarray(triangle_block, dtype=int)
        return cls(points, triangles)

    def __init__(self, points: AnyArrayLike, triangles: AnyArrayLike) -> None:
        self.points = np.asarray(points, dtype=float)
        self.triangles = np.asarray(triangles, dtype=int)

    @property
    def size(self) -> tuple[float, float, float]:
        """Return the size of the mesh bounding box."""
        a = self.points.min(axis=0)
        b = self.points.max(axis=0)
        return tuple((b - a).tolist())

    @property
    def bounding_box(self) -> Bounds3D:
        """Return the mesh bounding box."""
        a = tuple(self.points.min(axis=0).tolist())
        b = tuple(self.points.max(axis=0).tolist())
        return a, b

    def transformed(self, matrix: AnyArrayLike) -> "Mesh":
        """Return a transformed copy of the mesh."""
        points = np.hstack([self.points, np.ones((self.points.shape[0], 1))])
        transformed_points = points @ np.asarray(matrix, dtype=float).T
        return Mesh(transformed_points[:, :3], self.triangles)

    def scaled(self, scale: ScalarOrVector3) -> "Mesh":
        """Return a scaled copy of the mesh."""
        try:
            sx, sy, sz = scale
        except TypeError:
            sx = sy = sz = float(scale)
        matrix = [[sx, 0, 0, 0], [0, sy, 0, 0], [0, 0, sz, 0], [0, 0, 0, 1]]
        return self.transformed(matrix)

    def translated(self, offset: AnyArrayLike) -> "Mesh":
        """Return a translated copy of the mesh."""
        dx, dy, dz = np.asarray(offset, dtype=float)
        matrix = [[1, 0, 0, dx], [0, 1, 0, dy], [0, 0, 1, dz], [0, 0, 0, 1]]
        return self.transformed(matrix)

    def positioned(self, position: AnyArrayLike, anchor: AnyArrayLike) -> "Mesh":
        """Return a copy of the mesh positioned by an anchor point."""
        lower, upper = map(np.asarray, self.bounding_box)
        anchor_array = np.asarray(anchor, dtype=float)
        target = np.asarray(position, dtype=float)
        pivot = lower + (upper - lower) * anchor_array
        return self.translated(target - pivot)

    def centered(self) -> "Mesh":
        """Return a copy of the mesh centered around the origin."""
        return self.positioned((0, 0, 0), (0.5, 0.5, 0.5))

    @sdf3
    def sdf(self, voxel_size: float, half_width: float | None = None):
        """Convert the mesh into a sampled SDF backed by OpenVDB."""
        _require_openvdb()
        lower, upper = self.bounding_box
        estimator = box(a=lower, b=upper)
        transform = vdb.createLinearTransform(voxelSize=voxel_size)

        half_width_voxels = 3
        if half_width is not None:
            half_width_voxels = max(
                half_width_voxels, int(np.ceil(half_width / voxel_size))
            )

        grid = vdb.FloatGrid.createLevelSetFromPolygons(
            self.points,
            triangles=self.triangles,
            transform=transform,
            halfWidth=half_width_voxels,
        )

        voxel_min, voxel_max = grid.evalActiveVoxelBoundingBox()
        ijk0 = np.array(voxel_min, dtype=int)
        ijk1 = np.array(voxel_max, dtype=int)
        size = ijk1 - ijk0 + 1

        world_min = grid.transform.indexToWorld(ijk0)
        world_max = grid.transform.indexToWorld(ijk1)
        x_values = np.linspace(world_min[0], world_max[0], size[0])
        y_values = np.linspace(world_min[1], world_max[1], size[1])
        z_values = np.linspace(world_min[2], world_max[2], size[2])

        array = np.zeros(size, dtype=np.float32)
        grid.copyToArray(array, ijk=ijk0)
        interpolator = interpolate.RegularGridInterpolator(
            (x_values, y_values, z_values),
            array,
            bounds_error=False,
            fill_value=grid.background,
        )

        def f(p):
            estimated = estimator(p)
            sampled = interpolator(p).reshape((-1, 1))
            return np.where(estimated > grid.background, estimated, sampled)

        f.array = array
        f.xyz = (x_values, y_values, z_values)
        f.grid = grid
        f.interpolator = interpolator
        f.estimator = estimator
        return f


__all__ = ["Mesh"]
