"""Sampling and mesh generation helpers for 3D SDFs."""

from __future__ import annotations

import itertools
import multiprocessing
import time
from functools import partial
from multiprocessing.pool import ThreadPool

import numpy as np
from skimage import measure

try:
    import matplotlib.pyplot as plt
except ImportError as exc:  # pragma: no cover - exercised via failure path tests.
    plt = None
    _MATPLOTLIB_IMPORT_ERROR = exc
else:  # pragma: no cover - trivial branch.
    _MATPLOTLIB_IMPORT_ERROR = None

try:
    import meshio
except ImportError as exc:  # pragma: no cover - exercised via failure path tests.
    meshio = None
    _MESHIO_IMPORT_ERROR = exc
else:  # pragma: no cover - trivial branch.
    _MESHIO_IMPORT_ERROR = None

from . import progress, stl
from ._types import (
    Bounds3D,
    FloatArray,
    PathLikeStr,
    Points3D,
    ScalarOrVector3,
    SDFCallable,
)

WORKERS = multiprocessing.cpu_count()
SAMPLES = 2**22
BATCH_SIZE = 32


def _require_matplotlib() -> None:
    if plt is None:
        raise ImportError(
            "matplotlib is required for show_slice(). Install texosdf with the "
            "'plot' extra, for example: pip install texosdf[plot]"
        ) from _MATPLOTLIB_IMPORT_ERROR


def _require_meshio():
    if meshio is None:
        raise ImportError(
            "meshio is required for non-STL mesh export. Install texosdf with the "
            "'mesh' extra, for example: pip install texosdf[mesh]"
        ) from _MESHIO_IMPORT_ERROR
    return meshio


def _marching_cubes(volume: FloatArray, level: float = 0) -> Points3D:
    verts, faces, _, _ = measure.marching_cubes(volume, level)
    return verts[faces].reshape((-1, 3))


def _cartesian_product(*arrays: FloatArray) -> FloatArray:
    array_count = len(arrays)
    dtype = np.result_type(*arrays)
    result = np.empty([len(array) for array in arrays] + [array_count], dtype=dtype)
    for index, array in enumerate(np.ix_(*arrays)):
        result[..., index] = array
    return result.reshape(-1, array_count)


def _skip(sdf: SDFCallable, job: tuple[FloatArray, FloatArray, FloatArray]) -> bool:
    x_values, y_values, z_values = job
    x0, x1 = x_values[0], x_values[-1]
    y0, y1 = y_values[0], y_values[-1]
    z0, z1 = z_values[0], z_values[-1]
    x = (x0 + x1) / 2
    y = (y0 + y1) / 2
    z = (z0 + z1) / 2
    radius = abs(sdf(np.array([(x, y, z)], dtype=float)).reshape(-1)[0])
    diagonal = np.linalg.norm(np.array((x - x0, y - y0, z - z0), dtype=float))
    if radius <= diagonal:
        return False
    corners = np.array(
        list(itertools.product((x0, x1), (y0, y1), (z0, z1))), dtype=float
    )
    values = sdf(corners).reshape(-1)
    same_sign = np.all(values > 0) if values[0] > 0 else np.all(values < 0)
    return bool(same_sign)


def _worker(
    sdf: SDFCallable, job: tuple[FloatArray, FloatArray, FloatArray], sparse: bool
) -> Points3D | None:
    x_values, y_values, z_values = job
    if sparse and _skip(sdf, job):
        return None
    sample_points = _cartesian_product(x_values, y_values, z_values)
    shape = (len(x_values), len(y_values), len(z_values))
    volume = sdf(sample_points).reshape(shape)
    try:
        points = _marching_cubes(volume)
    except Exception:
        return np.empty((0, 3), dtype=float)
    scale = np.array(
        [
            x_values[1] - x_values[0],
            y_values[1] - y_values[0],
            z_values[1] - z_values[0],
        ],
        dtype=float,
    )
    offset = np.array([x_values[0], y_values[0], z_values[0]], dtype=float)
    return points * scale + offset


def _estimate_bounds(sdf: SDFCallable) -> Bounds3D:
    sample_count = 16
    x0 = y0 = z0 = -1e9
    x1 = y1 = z1 = 1e9
    previous_threshold = None
    for _ in range(32):
        x_values = np.linspace(x0, x1, sample_count)
        y_values = np.linspace(y0, y1, sample_count)
        z_values = np.linspace(z0, z1, sample_count)
        delta = np.array(
            [
                x_values[1] - x_values[0],
                y_values[1] - y_values[0],
                z_values[1] - z_values[0],
            ]
        )
        threshold = np.linalg.norm(delta) / 2
        if threshold == previous_threshold:
            break
        previous_threshold = threshold
        sample_points = _cartesian_product(x_values, y_values, z_values)
        volume = sdf(sample_points).reshape(
            (len(x_values), len(y_values), len(z_values))
        )
        close_to_surface = np.argwhere(np.abs(volume) <= threshold)
        if close_to_surface.size == 0:
            raise ValueError(
                "Could not estimate SDF bounds automatically. Pass explicit bounds to generate() or save()."
            )
        x1, y1, z1 = (x0, y0, z0) + close_to_surface.max(axis=0) * delta + delta / 2
        x0, y0, z0 = (x0, y0, z0) + close_to_surface.min(axis=0) * delta - delta / 2
    return ((float(x0), float(y0), float(z0)), (float(x1), float(y1), float(z1)))


def generate(
    sdf: SDFCallable,
    step: ScalarOrVector3 | None = None,
    bounds: Bounds3D | None = None,
    samples: int | None = SAMPLES,
    workers: int = WORKERS,
    batch_size: int = BATCH_SIZE,
    verbose: bool = True,
    sparse: bool = True,
) -> Points3D:
    """Generate triangle vertices from a 3D signed distance function.

    Args:
        sdf: Signed distance function to sample.
        step: Sampling step size as a scalar or per-axis tuple.
        bounds: Explicit sampling bounds. When omitted, bounds are estimated.
        samples: Approximate sample budget used to derive ``step`` when it is omitted.
        workers: Number of worker threads used for batch sampling.
        batch_size: Number of samples per batch edge.
        verbose: Whether to print progress and timing information.
        sparse: Whether to skip batches that are confidently far from the surface.

    Returns:
        Triangle vertices with shape ``(N, 3)`` where every three rows form a single triangle.
    """
    start = time.time()

    if bounds is None:
        bounds = _estimate_bounds(sdf)
    (x0, y0, z0), (x1, y1, z1) = bounds

    if step is None:
        if samples is None:
            raise ValueError("Either step or samples must be provided.")
        volume = (x1 - x0) * (y1 - y0) * (z1 - z0)
        step = (volume / samples) ** (1 / 3)

    try:
        dx, dy, dz = step
    except TypeError:
        dx = dy = dz = float(step)

    if verbose:
        print(f"min {x0:g}, {y0:g}, {z0:g}")
        print(f"max {x1:g}, {y1:g}, {z1:g}")
        print(f"step {dx:g}, {dy:g}, {dz:g}")

    x_values = np.arange(x0, x1, dx)
    y_values = np.arange(y0, y1, dy)
    z_values = np.arange(z0, z1, dz)

    x_batches = [
        x_values[index : index + batch_size + 1]
        for index in range(0, len(x_values), batch_size)
    ]
    y_batches = [
        y_values[index : index + batch_size + 1]
        for index in range(0, len(y_values), batch_size)
    ]
    z_batches = [
        z_values[index : index + batch_size + 1]
        for index in range(0, len(z_values), batch_size)
    ]

    batches = list(itertools.product(x_batches, y_batches, z_batches))
    batch_count = len(batches)
    sample_count = sum(len(xs) * len(ys) * len(zs) for xs, ys, zs in batches)

    if verbose:
        print(f"{sample_count} samples in {batch_count} batches with {workers} workers")

    chunks: list[Points3D] = []
    skipped = empty = nonempty = 0
    bar = progress.Bar(batch_count, enabled=verbose)
    pool = ThreadPool(workers)
    worker = partial(_worker, sdf, sparse=sparse)
    for result in pool.imap(worker, batches):
        bar.increment(1)
        if result is None:
            skipped += 1
        elif len(result) == 0:
            empty += 1
        else:
            nonempty += 1
            chunks.append(result)
    pool.close()
    pool.join()
    bar.done()

    points = np.vstack(chunks) if chunks else np.empty((0, 3), dtype=float)

    if verbose:
        print(f"{skipped} skipped, {empty} empty, {nonempty} nonempty")
        triangle_count = len(points) // 3
        seconds = time.time() - start
        print(f"{triangle_count} triangles in {seconds:g} seconds")

    return points


def save(path: PathLikeStr, *args, **kwargs) -> None:
    """Generate a mesh and save it to disk.

    Args:
        path: Output mesh path.
        *args: Positional arguments forwarded to :func:`generate`.
        **kwargs: Keyword arguments forwarded to :func:`generate`.
    """
    points = generate(*args, **kwargs)
    if str(path).lower().endswith(".stl"):
        stl.write_binary_stl(path, points)
    else:
        mesh = _mesh(points)
        mesh.write(path)


def _mesh(points: Points3D):
    meshio_module = _require_meshio()
    unique_points, cells = np.unique(points, axis=0, return_inverse=True)
    triangle_cells = [("triangle", cells.reshape((-1, 3)))]
    return meshio_module.Mesh(unique_points, triangle_cells)


def sample_slice(
    sdf: SDFCallable,
    w: int = 1024,
    h: int = 1024,
    x: float | None = None,
    y: float | None = None,
    z: float | None = None,
    bounds: Bounds3D | None = None,
) -> tuple[FloatArray, tuple[float, float, float, float], str]:
    """Sample a 2D slice from a 3D signed distance function.

    Args:
        sdf: Signed distance function to sample.
        w: Width in samples.
        h: Height in samples.
        x: Optional fixed x coordinate for the slice plane.
        y: Optional fixed y coordinate for the slice plane.
        z: Optional fixed z coordinate for the slice plane.
        bounds: Explicit sampling bounds.

    Returns:
        A tuple containing the sampled slice values, the matplotlib extent, and the axis labels.
    """
    if bounds is None:
        bounds = _estimate_bounds(sdf)
    (x0, y0, z0), (x1, y1, z1) = bounds

    if x is not None:
        x_values = np.array([x], dtype=float)
        y_values = np.linspace(y0, y1, w)
        z_values = np.linspace(z0, z1, h)
        extent = (
            float(z_values[0]),
            float(z_values[-1]),
            float(y_values[0]),
            float(y_values[-1]),
        )
        axes = "ZY"
    elif y is not None:
        y_values = np.array([y], dtype=float)
        x_values = np.linspace(x0, x1, w)
        z_values = np.linspace(z0, z1, h)
        extent = (
            float(z_values[0]),
            float(z_values[-1]),
            float(x_values[0]),
            float(x_values[-1]),
        )
        axes = "ZX"
    elif z is not None:
        z_values = np.array([z], dtype=float)
        x_values = np.linspace(x0, x1, w)
        y_values = np.linspace(y0, y1, h)
        extent = (
            float(y_values[0]),
            float(y_values[-1]),
            float(x_values[0]),
            float(x_values[-1]),
        )
        axes = "YX"
    else:
        raise ValueError("x, y, or z position must be specified")

    sample_points = _cartesian_product(x_values, y_values, z_values)
    return sdf(sample_points).reshape((w, h)), extent, axes


def show_slice(*args, **kwargs) -> None:
    """Display a sampled slice using matplotlib.

    Args:
        *args: Positional arguments forwarded to :func:`sample_slice`.
        **kwargs: Keyword arguments forwarded to :func:`sample_slice`. The optional ``abs`` flag displays absolute distance values.
    """
    _require_matplotlib()
    show_abs = kwargs.pop("abs", False)
    array, extent, axes = sample_slice(*args, **kwargs)
    if show_abs:
        array = np.abs(array)
    image = plt.imshow(array, extent=extent, origin="lower")
    plt.xlabel(axes[0])
    plt.ylabel(axes[1])
    plt.colorbar(image)
    plt.show()


__all__ = [
    "BATCH_SIZE",
    "SAMPLES",
    "WORKERS",
    "generate",
    "sample_slice",
    "save",
    "show_slice",
]
