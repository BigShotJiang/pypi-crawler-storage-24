"""3D signed distance primitives and operations."""

from __future__ import annotations

import functools
from typing import Any, Callable

import numpy as np

from . import core, d2, ease, ops
from ._types import (
    AnyArrayLike,
    DistanceArray,
    EaseFunction,
    FloatArray,
    ScalarOrVector3,
    SDFCallable,
)

ORIGIN = np.array((0.0, 0.0, 0.0))
X = np.array((1.0, 0.0, 0.0))
Y = np.array((0.0, 1.0, 0.0))
Z = np.array((0.0, 0.0, 1.0))
UP = Z

_ops: dict[str, Callable[..., object]] = {}
_min = np.minimum
_max = np.maximum


class SDF3:
    """Callable wrapper around a vectorized 3D signed distance function.

    Args:
        f: Callable that accepts points with shape ``(N, 3)`` and returns signed distances.
    """

    def __init__(self, f: SDFCallable) -> None:
        self.f = f
        self._k: float | None = None

    def __call__(self, p: FloatArray) -> DistanceArray:
        """Evaluate the SDF on a batch of 3D points.

        Args:
            p: Points with shape ``(N, 3)``.

        Returns:
            Distances with shape ``(N, 1)``.
        """
        return self.f(np.asarray(p, dtype=float)).reshape((-1, 1))

    def __getattr__(self, name: str):
        if name in _ops:
            return functools.partial(_ops[name], self)
        try:
            return getattr(self.f, name)
        except AttributeError as exc:
            raise AttributeError(name) from exc

    def __or__(self, other: "SDF3") -> "SDF3":
        return union(self, other)

    def __and__(self, other: "SDF3") -> "SDF3":
        return intersection(self, other)

    def __sub__(self, other: "SDF3") -> "SDF3":
        return difference(self, other)

    def k(self, k: float | None = None) -> "SDF3":
        """Store a smoothing value for subsequent boolean combinations.

        Args:
            k: Smoothing factor used by boolean operations.

        Returns:
            The same SDF instance for fluent chaining.
        """
        self._k = k
        return self

    def generate(self, *args, **kwargs):
        """Generate triangle vertices for this SDF."""
        return core.generate(self, *args, **kwargs)

    def save(self, path, *args, **kwargs) -> None:
        """Generate a mesh and save it to disk."""
        core.save(path, self, *args, **kwargs)

    def show_slice(self, *args, **kwargs) -> None:
        """Display a sampled slice of this SDF."""
        core.show_slice(self, *args, **kwargs)


def sdf3(f: Callable[..., SDFCallable]) -> Callable[..., SDF3]:
    """Wrap an SDF factory and return :class:`SDF3` objects."""

    @functools.wraps(f)
    def wrapper(*args: Any, **kwargs: Any) -> SDF3:
        return SDF3(f(*args, **kwargs))

    return wrapper


def op3(f: Callable[..., SDFCallable]) -> Callable[..., SDF3]:
    """Register a 3D operation for free-function and method-style use."""

    @functools.wraps(f)
    def wrapper(*args: Any, **kwargs: Any) -> SDF3:
        return SDF3(f(*args, **kwargs))

    _ops[f.__name__] = wrapper
    return wrapper


def op32(f: Callable[..., SDFCallable]) -> Callable[..., "d2.SDF2"]:
    """Register a 3D-to-2D operation for method-style use."""

    @functools.wraps(f)
    def wrapper(*args: Any, **kwargs: Any) -> "d2.SDF2":
        return d2.SDF2(f(*args, **kwargs))

    _ops[f.__name__] = wrapper
    return wrapper


def _length(a: FloatArray) -> FloatArray:
    return np.linalg.norm(a, axis=1)


def _normalize(a: AnyArrayLike) -> FloatArray:
    vector = np.asarray(a, dtype=float)
    return vector / np.linalg.norm(vector)


def _dot(a: FloatArray, b: AnyArrayLike) -> FloatArray:
    return np.sum(a * b, axis=1)


def _vec(*arrays: AnyArrayLike) -> FloatArray:
    return np.stack(arrays, axis=-1)


def _perpendicular(v: FloatArray) -> FloatArray:
    if v[1] == 0 and v[2] == 0:
        if v[0] == 0:
            raise ValueError("zero vector")
        return np.cross(v, [0, 1, 0])
    return np.cross(v, [1, 0, 0])


@sdf3
def sphere(radius: float = 1, center: AnyArrayLike = ORIGIN) -> SDFCallable:
    """Create a sphere SDF."""
    center_array = np.asarray(center, dtype=float)

    def f(p: FloatArray) -> FloatArray:
        return _length(p - center_array) - radius

    return f


@sdf3
def plane(normal: AnyArrayLike = UP, point: AnyArrayLike = ORIGIN) -> SDFCallable:
    """Create an infinite plane half-space SDF."""
    normal_array = _normalize(normal)
    point_array = np.asarray(point, dtype=float)

    def f(p: FloatArray) -> FloatArray:
        return np.dot(point_array - p, normal_array)

    return f


@sdf3
def slab(
    x0: float | None = None,
    y0: float | None = None,
    z0: float | None = None,
    x1: float | None = None,
    y1: float | None = None,
    z1: float | None = None,
    k: float | None = None,
) -> SDFCallable:
    """Create an axis-aligned 3D slab."""
    functions: list[SDF3] = []
    if x0 is not None:
        functions.append(plane(X, (x0, 0, 0)))
    if x1 is not None:
        functions.append(plane(-X, (x1, 0, 0)))
    if y0 is not None:
        functions.append(plane(Y, (0, y0, 0)))
    if y1 is not None:
        functions.append(plane(-Y, (0, y1, 0)))
    if z0 is not None:
        functions.append(plane(Z, (0, 0, z0)))
    if z1 is not None:
        functions.append(plane(-Z, (0, 0, z1)))
    return intersection(*functions, k=k).f


@sdf3
def box(
    size: ScalarOrVector3 = 1,
    center: AnyArrayLike = ORIGIN,
    a: AnyArrayLike | None = None,
    b: AnyArrayLike | None = None,
) -> SDFCallable:
    """Create a box SDF."""
    if a is not None and b is not None:
        a_array = np.asarray(a, dtype=float)
        b_array = np.asarray(b, dtype=float)
        size = tuple((b_array - a_array).tolist())
        center = a_array + (b_array - a_array) / 2
        return box(size=size, center=center).f
    size_array = np.asarray(size, dtype=float)
    center_array = np.asarray(center, dtype=float)

    def f(p: FloatArray) -> FloatArray:
        q = np.abs(p - center_array) - size_array / 2
        return _length(_max(q, 0)) + _min(np.amax(q, axis=1), 0)

    return f


@sdf3
def rounded_box(size: AnyArrayLike, radius: float) -> SDFCallable:
    """Create a rounded box SDF."""
    size_array = np.asarray(size, dtype=float)

    def f(p: FloatArray) -> FloatArray:
        q = np.abs(p) - size_array / 2 + radius
        return _length(_max(q, 0)) + _min(np.amax(q, axis=1), 0) - radius

    return f


@sdf3
def wireframe_box(size: AnyArrayLike, thickness: float) -> SDFCallable:
    """Create a wireframe box SDF."""
    size_array = np.asarray(size, dtype=float)

    def g(a: FloatArray, b: FloatArray, c: FloatArray) -> FloatArray:
        return _length(_max(_vec(a, b, c), 0)) + _min(_max(a, _max(b, c)), 0)

    def f(p: FloatArray) -> FloatArray:
        q = np.abs(p) - size_array / 2 - thickness / 2
        frame = np.abs(q + thickness / 2) - thickness / 2
        px, py, pz = q[:, 0], q[:, 1], q[:, 2]
        qx, qy, qz = frame[:, 0], frame[:, 1], frame[:, 2]
        return _min(_min(g(px, qy, qz), g(qx, py, qz)), g(qx, qy, pz))

    return f


@sdf3
def torus(r1: float, r2: float) -> SDFCallable:
    """Create a torus SDF."""

    def f(p: FloatArray) -> FloatArray:
        xy = p[:, [0, 1]]
        major = _length(xy) - r1
        return _length(_vec(major, p[:, 2])) - r2

    return f


@sdf3
def capsule(a: AnyArrayLike, b: AnyArrayLike, radius: float) -> SDFCallable:
    """Create a capsule SDF."""
    start = np.asarray(a, dtype=float)
    end = np.asarray(b, dtype=float)

    def f(p: FloatArray) -> FloatArray:
        pa = p - start
        ba = end - start
        h = np.clip(np.dot(pa, ba) / np.dot(ba, ba), 0, 1).reshape((-1, 1))
        return _length(pa - np.multiply(ba, h)) - radius

    return f


@sdf3
def cylinder(radius: float) -> SDFCallable:
    """Create an infinite cylinder aligned with the z axis."""

    def f(p: FloatArray) -> FloatArray:
        return _length(p[:, [0, 1]]) - radius

    return f


@sdf3
def capped_cylinder(a: AnyArrayLike, b: AnyArrayLike, radius: float) -> SDFCallable:
    """Create a finite cylinder between two points."""
    start = np.asarray(a, dtype=float)
    end = np.asarray(b, dtype=float)

    def f(p: FloatArray) -> FloatArray:
        axis = end - start
        pa = p - start
        axis_length_sq = np.dot(axis, axis)
        projected = np.dot(pa, axis).reshape((-1, 1))
        x = _length(pa * axis_length_sq - axis * projected) - radius * axis_length_sq
        y = np.abs(projected - axis_length_sq * 0.5) - axis_length_sq * 0.5
        x = x.reshape((-1, 1))
        y = y.reshape((-1, 1))
        x2 = x * x
        y2 = y * y * axis_length_sq
        distance = np.where(
            _max(x, y) < 0,
            -_min(x2, y2),
            np.where(x > 0, x2, 0) + np.where(y > 0, y2, 0),
        )
        return np.sign(distance) * np.sqrt(np.abs(distance)) / axis_length_sq

    return f


@sdf3
def rounded_cylinder(ra: float, rb: float, height: float) -> SDFCallable:
    """Create a rounded finite cylinder."""

    def f(p: FloatArray) -> FloatArray:
        distance = _vec(
            _length(p[:, [0, 1]]) - ra + rb, np.abs(p[:, 2]) - height / 2 + rb
        )
        return (
            _min(_max(distance[:, 0], distance[:, 1]), 0)
            + _length(_max(distance, 0))
            - rb
        )

    return f


@sdf3
def capped_cone(a: AnyArrayLike, b: AnyArrayLike, ra: float, rb: float) -> SDFCallable:
    """Create a cone frustum between two points."""
    start = np.asarray(a, dtype=float)
    end = np.asarray(b, dtype=float)

    def f(p: FloatArray) -> FloatArray:
        radius_delta = rb - ra
        axis_length_sq = np.dot(end - start, end - start)
        pa_norm_sq = _dot(p - start, p - start)
        projected = np.dot(p - start, end - start) / axis_length_sq
        x = np.sqrt(pa_norm_sq - projected * projected * axis_length_sq)
        cax = _max(0, x - np.where(projected < 0.5, ra, rb))
        cay = np.abs(projected - 0.5) - 0.5
        k = radius_delta * radius_delta + axis_length_sq
        factor = np.clip(
            (radius_delta * (x - ra) + projected * axis_length_sq) / k, 0, 1
        )
        cbx = x - ra - factor * radius_delta
        cby = projected - factor
        sign = np.where(np.logical_and(cbx < 0, cay < 0), -1, 1)
        return sign * np.sqrt(
            _min(
                cax * cax + cay * cay * axis_length_sq,
                cbx * cbx + cby * cby * axis_length_sq,
            )
        )

    return f


@sdf3
def rounded_cone(r1: float, r2: float, height: float) -> SDFCallable:
    """Create a rounded cone aligned with the z axis."""

    def f(p: FloatArray) -> FloatArray:
        q = _vec(_length(p[:, [0, 1]]), p[:, 2])
        b = (r1 - r2) / height
        a = np.sqrt(1 - b * b)
        k = np.dot(q, _vec(-b, a))
        c1 = _length(q) - r1
        c2 = _length(q - _vec(0, height)) - r2
        c3 = np.dot(q, _vec(a, b)) - r1
        return np.where(k < 0, c1, np.where(k > a * height, c2, c3))

    return f


@sdf3
def ellipsoid(size: AnyArrayLike) -> SDFCallable:
    """Create an ellipsoid SDF."""
    size_array = np.asarray(size, dtype=float)

    def f(p: FloatArray) -> FloatArray:
        k0 = _length(p / size_array)
        k1 = _length(p / (size_array * size_array))
        return k0 * (k0 - 1) / k1

    return f


@sdf3
def pyramid(height: float) -> SDFCallable:
    """Create a square pyramid SDF."""

    def f(p: FloatArray) -> FloatArray:
        a = np.abs(p[:, [0, 1]]) - 0.5
        swap = a[:, 1] > a[:, 0]
        a[swap] = a[:, [1, 0]][swap]
        px = a[:, 0]
        py = p[:, 2]
        pz = a[:, 1]
        m2 = height * height + 0.25
        qx = pz
        qy = height * py - 0.5 * px
        qz = height * px + 0.5 * py
        s = _max(-qx, 0)
        t = np.clip((qy - 0.5 * pz) / (m2 + 0.25), 0, 1)
        da = m2 * (qx + s) ** 2 + qy * qy
        db = m2 * (qx + 0.5 * t) ** 2 + (qy - m2 * t) ** 2
        distance_sq = np.where(_min(qy, -qx * m2 - qy * 0.5) > 0, 0, _min(da, db))
        return np.sqrt((distance_sq + qz * qz) / m2) * np.sign(_max(qz, -py))

    return f


@sdf3
def tetrahedron(radius: float) -> SDFCallable:
    """Create a tetrahedron SDF."""

    def f(p: FloatArray) -> FloatArray:
        x_values = p[:, 0]
        y_values = p[:, 1]
        z_values = p[:, 2]
        return (
            _max(
                np.abs(x_values + y_values) - z_values,
                np.abs(x_values - y_values) + z_values,
            )
            - radius
        ) / np.sqrt(3)

    return f


@sdf3
def octahedron(radius: float) -> SDFCallable:
    """Create an octahedron SDF."""

    def f(p: FloatArray) -> FloatArray:
        return (np.sum(np.abs(p), axis=1) - radius) * np.tan(np.radians(30))

    return f


@sdf3
def dodecahedron(radius: float) -> SDFCallable:
    """Create a dodecahedron SDF."""
    x_value, y_value, z_value = _normalize(((1 + np.sqrt(5)) / 2, 1, 0))

    def f(p: FloatArray) -> FloatArray:
        q = np.abs(p / radius)
        a = np.dot(q, (x_value, y_value, z_value))
        b = np.dot(q, (z_value, x_value, y_value))
        c = np.dot(q, (y_value, z_value, x_value))
        return (_max(_max(a, b), c) - x_value) * radius

    return f


@sdf3
def icosahedron(radius: float) -> SDFCallable:
    """Create an icosahedron SDF."""
    adjusted_radius = radius * 0.8506507174597755
    x_value, y_value, z_value = _normalize(((np.sqrt(5) + 3) / 2, 1, 0))
    w = np.sqrt(3) / 3

    def f(p: FloatArray) -> FloatArray:
        q = np.abs(p / adjusted_radius)
        a = np.dot(q, (x_value, y_value, z_value))
        b = np.dot(q, (z_value, x_value, y_value))
        c = np.dot(q, (y_value, z_value, x_value))
        d = np.dot(q, (w, w, w)) - x_value
        return _max(_max(_max(a, b), c) - x_value, d) * adjusted_radius

    return f


@op3
def translate(other: SDF3, offset: AnyArrayLike) -> SDFCallable:
    """Translate a 3D SDF."""
    offset_array = np.asarray(offset, dtype=float)

    def f(p: FloatArray) -> FloatArray:
        return other(p - offset_array)

    return f


@op3
def scale(other: SDF3, factor: ScalarOrVector3) -> SDFCallable:
    """Scale a 3D SDF."""
    try:
        x_scale, y_scale, z_scale = factor
    except TypeError:
        x_scale = y_scale = z_scale = float(factor)
    scale_array = np.array((x_scale, y_scale, z_scale), dtype=float)
    scale_min = min(x_scale, y_scale, z_scale)

    def f(p: FloatArray) -> FloatArray:
        return other(p / scale_array) * scale_min

    return f


@op3
def rotate(other: SDF3, angle: float, vector: AnyArrayLike = Z) -> SDFCallable:
    """Rotate a 3D SDF around an arbitrary axis."""
    x_value, y_value, z_value = _normalize(vector)
    sine = np.sin(angle)
    cosine = np.cos(angle)
    one_minus_cosine = 1 - cosine
    matrix = np.array(
        [
            [
                one_minus_cosine * x_value * x_value + cosine,
                one_minus_cosine * x_value * y_value + z_value * sine,
                one_minus_cosine * z_value * x_value - y_value * sine,
            ],
            [
                one_minus_cosine * x_value * y_value - z_value * sine,
                one_minus_cosine * y_value * y_value + cosine,
                one_minus_cosine * y_value * z_value + x_value * sine,
            ],
            [
                one_minus_cosine * z_value * x_value + y_value * sine,
                one_minus_cosine * y_value * z_value - x_value * sine,
                one_minus_cosine * z_value * z_value + cosine,
            ],
        ],
        dtype=float,
    ).T

    def f(p: FloatArray) -> FloatArray:
        return other(np.dot(p, matrix))

    return f


@op3
def rotate_to(other: SDF3, a: AnyArrayLike, b: AnyArrayLike) -> SDFCallable:
    """Rotate a 3D SDF so one direction aligns with another."""
    start = _normalize(np.asarray(a, dtype=float))
    end = _normalize(np.asarray(b, dtype=float))
    dot = np.dot(end, start)
    if dot == 1:
        return other.f
    if dot == -1:
        return rotate(other, np.pi, _perpendicular(start)).f
    angle = np.arccos(dot)
    axis = _normalize(np.cross(end, start))
    return rotate(other, angle, axis).f


@op3
def orient(other: SDF3, axis: AnyArrayLike) -> SDFCallable:
    """Rotate a 3D SDF so ``+Z`` points along ``axis``."""
    return rotate_to(other, UP, axis).f


@op3
def circular_array(other: SDF3, count: int, offset: float = 0) -> SDFCallable:
    """Repeat a 3D SDF around the z axis."""
    shifted = other.translate(X * offset)
    angle_step = 2 * np.pi / count

    def f(p: FloatArray) -> FloatArray:
        x_values = p[:, 0]
        y_values = p[:, 1]
        z_values = p[:, 2]
        distance = np.hypot(x_values, y_values)
        angle = np.arctan2(y_values, x_values) % angle_step
        d1 = shifted(
            _vec(
                np.cos(angle - angle_step) * distance,
                np.sin(angle - angle_step) * distance,
                z_values,
            )
        )
        d2 = shifted(_vec(np.cos(angle) * distance, np.sin(angle) * distance, z_values))
        return _min(d1, d2)

    return f


@op3
def elongate(other: SDF3, size: AnyArrayLike) -> SDFCallable:
    """Elongate a 3D SDF along each axis."""
    size_array = np.asarray(size, dtype=float)

    def f(p: FloatArray) -> FloatArray:
        q = np.abs(p) - size_array
        x_values = q[:, 0].reshape((-1, 1))
        y_values = q[:, 1].reshape((-1, 1))
        z_values = q[:, 2].reshape((-1, 1))
        w = _min(_max(x_values, _max(y_values, z_values)), 0)
        return other(_max(q, 0)) + w

    return f


@op3
def twist(other: SDF3, k: float) -> SDFCallable:
    """Twist a 3D SDF around the z axis."""

    def f(p: FloatArray) -> FloatArray:
        x_values = p[:, 0]
        y_values = p[:, 1]
        z_values = p[:, 2]
        cosine = np.cos(k * z_values)
        sine = np.sin(k * z_values)
        x2 = cosine * x_values - sine * y_values
        y2 = sine * x_values + cosine * y_values
        return other(_vec(x2, y2, z_values))

    return f


@op3
def bend(other: SDF3, k: float) -> SDFCallable:
    """Bend a 3D SDF around the x axis."""

    def f(p: FloatArray) -> FloatArray:
        x_values = p[:, 0]
        y_values = p[:, 1]
        z_values = p[:, 2]
        cosine = np.cos(k * x_values)
        sine = np.sin(k * x_values)
        x2 = cosine * x_values - sine * y_values
        y2 = sine * x_values + cosine * y_values
        return other(_vec(x2, y2, z_values))

    return f


@op3
def bend_linear(
    other: SDF3,
    p0: AnyArrayLike,
    p1: AnyArrayLike,
    v: AnyArrayLike,
    e: EaseFunction = ease.linear,
) -> SDFCallable:
    """Apply a linear bend between two points."""
    start = np.asarray(p0, dtype=float)
    end = np.asarray(p1, dtype=float)
    offset = -np.asarray(v, dtype=float)
    segment = end - start

    def f(p: FloatArray) -> FloatArray:
        t = np.clip(np.dot(p - start, segment) / np.dot(segment, segment), 0, 1)
        eased = e(t).reshape((-1, 1))
        return other(p + eased * offset)

    return f


@op3
def bend_radial(
    other: SDF3, r0: float, r1: float, dz: float, e: EaseFunction = ease.linear
) -> SDFCallable:
    """Apply a radial bend between two radii."""

    def f(p: FloatArray) -> FloatArray:
        x_values = p[:, 0]
        y_values = p[:, 1]
        z_values = p[:, 2]
        radius = np.hypot(x_values, y_values)
        t = np.clip((radius - r0) / (r1 - r0), 0, 1)
        return other(_vec(x_values, y_values, z_values - dz * e(t)))

    return f


@op3
def transition_linear(
    f0: SDF3,
    f1: SDF3,
    p0: AnyArrayLike = -Z,
    p1: AnyArrayLike = Z,
    e: EaseFunction = ease.linear,
) -> SDFCallable:
    """Blend between two SDFs along a linear segment."""
    start = np.asarray(p0, dtype=float)
    end = np.asarray(p1, dtype=float)
    segment = end - start

    def f(p: FloatArray) -> FloatArray:
        d1 = f0(p)
        d2 = f1(p)
        t = np.clip(np.dot(p - start, segment) / np.dot(segment, segment), 0, 1)
        eased = e(t).reshape((-1, 1))
        return eased * d2 + (1 - eased) * d1

    return f


@op3
def transition_radial(
    f0: SDF3, f1: SDF3, r0: float = 0, r1: float = 1, e: EaseFunction = ease.linear
) -> SDFCallable:
    """Blend between two SDFs across a radial interval."""

    def f(p: FloatArray) -> FloatArray:
        d1 = f0(p)
        d2 = f1(p)
        radius = np.hypot(p[:, 0], p[:, 1])
        t = np.clip((radius - r0) / (r1 - r0), 0, 1)
        eased = e(t).reshape((-1, 1))
        return eased * d2 + (1 - eased) * d1

    return f


@op3
def wrap_around(
    other: SDF3,
    x0: float,
    x1: float,
    r: float | None = None,
    e: EaseFunction = ease.linear,
) -> SDFCallable:
    """Wrap a 3D SDF around a cylinder."""
    start = X * x0
    end = X * x1
    down = -Y
    radius = np.linalg.norm(end - start) / (2 * np.pi) if r is None else r

    def f(p: FloatArray) -> FloatArray:
        x_values = p[:, 0]
        y_values = p[:, 1]
        z_values = p[:, 2]
        delta = np.hypot(x_values, y_values) - radius
        delta = delta.reshape((-1, 1))
        angle = np.arctan2(y_values, x_values)
        t = (angle + np.pi) / (2 * np.pi)
        eased = e(t).reshape((-1, 1))
        q = start + (end - start) * eased + down * delta
        q[:, 2] = z_values
        return other(q)

    return f


@op32
def slice(other: SDF3) -> SDFCallable:
    """Sample a thin z=0 slice from a 3D SDF."""
    slab_sdf = slab(z0=-1e-9, z1=1e-9)
    positive = other & slab_sdf
    negative = other.negate() & slab_sdf

    def f(p: FloatArray) -> FloatArray:
        points = _vec(p[:, 0], p[:, 1], np.zeros(len(p)))
        positive_distance = positive(points).reshape(-1)
        negative_distance = -negative(points).reshape(-1)
        mask = positive_distance <= 0
        positive_distance[mask] = negative_distance[mask]
        return positive_distance

    return f


union = op3(ops.union)
difference = op3(ops.difference)
intersection = op3(ops.intersection)
blend = op3(ops.blend)
negate = op3(ops.negate)
dilate = op3(ops.dilate)
erode = op3(ops.erode)
shell = op3(ops.shell)
repeat = op3(ops.repeat)

__all__ = [
    "ORIGIN",
    "SDF3",
    "UP",
    "X",
    "Y",
    "Z",
    "bend",
    "bend_linear",
    "bend_radial",
    "blend",
    "box",
    "capsule",
    "capped_cone",
    "capped_cylinder",
    "circular_array",
    "cylinder",
    "difference",
    "dilate",
    "dodecahedron",
    "ellipsoid",
    "erode",
    "icosahedron",
    "intersection",
    "negate",
    "octahedron",
    "op3",
    "op32",
    "orient",
    "plane",
    "pyramid",
    "repeat",
    "rotate",
    "rotate_to",
    "rounded_box",
    "rounded_cone",
    "rounded_cylinder",
    "scale",
    "sdf3",
    "shell",
    "slab",
    "slice",
    "sphere",
    "tetrahedron",
    "torus",
    "transition_linear",
    "transition_radial",
    "translate",
    "twist",
    "union",
    "wireframe_box",
    "wrap_around",
]
