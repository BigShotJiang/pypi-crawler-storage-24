"""Dimension-agnostic signed distance operations."""

from __future__ import annotations

import itertools

import numpy as np

from ._types import AnyArrayLike, FloatArray, SDFCallable

_min = np.minimum
_max = np.maximum


def union(a: SDFCallable, *bs: SDFCallable, k: float | None = None) -> SDFCallable:
    """Create the union of one or more signed distance functions.

    Args:
        a: Base SDF.
        *bs: Additional SDFs to union with ``a``.
        k: Optional smoothing factor.

    Returns:
        A vectorized SDF callable.
    """

    def f(p: FloatArray) -> FloatArray:
        distance = a(p)
        for other in bs:
            other_distance = other(p)
            smoothing = k or getattr(other, "_k", None)
            if smoothing is None:
                distance = _min(distance, other_distance)
            else:
                h = np.clip(0.5 + 0.5 * (other_distance - distance) / smoothing, 0, 1)
                mix = other_distance + (distance - other_distance) * h
                distance = mix - smoothing * h * (1 - h)
        return distance

    return f


def difference(a: SDFCallable, *bs: SDFCallable, k: float | None = None) -> SDFCallable:
    """Subtract one or more signed distance functions from another.

    Args:
        a: Base SDF.
        *bs: SDFs to subtract from ``a``.
        k: Optional smoothing factor.

    Returns:
        A vectorized SDF callable.
    """

    def f(p: FloatArray) -> FloatArray:
        distance = a(p)
        for other in bs:
            other_distance = other(p)
            smoothing = k or getattr(other, "_k", None)
            if smoothing is None:
                distance = _max(distance, -other_distance)
            else:
                h = np.clip(0.5 - 0.5 * (other_distance + distance) / smoothing, 0, 1)
                mix = distance + (-other_distance - distance) * h
                distance = mix + smoothing * h * (1 - h)
        return distance

    return f


def intersection(
    a: SDFCallable, *bs: SDFCallable, k: float | None = None
) -> SDFCallable:
    """Create the intersection of one or more signed distance functions.

    Args:
        a: Base SDF.
        *bs: Additional SDFs to intersect with ``a``.
        k: Optional smoothing factor.

    Returns:
        A vectorized SDF callable.
    """

    def f(p: FloatArray) -> FloatArray:
        distance = a(p)
        for other in bs:
            other_distance = other(p)
            smoothing = k or getattr(other, "_k", None)
            if smoothing is None:
                distance = _max(distance, other_distance)
            else:
                h = np.clip(0.5 - 0.5 * (other_distance - distance) / smoothing, 0, 1)
                mix = other_distance + (distance - other_distance) * h
                distance = mix + smoothing * h * (1 - h)
        return distance

    return f


def blend(a: SDFCallable, *bs: SDFCallable, k: float = 0.5) -> SDFCallable:
    """Blend multiple signed distance functions linearly.

    Args:
        a: Base SDF.
        *bs: Additional SDFs to blend with ``a``.
        k: Blend factor used for each pairwise mix.

    Returns:
        A vectorized SDF callable.
    """

    def f(p: FloatArray) -> FloatArray:
        distance = a(p)
        for other in bs:
            other_distance = other(p)
            mix = k or getattr(other, "_k", None)
            distance = mix * other_distance + (1 - mix) * distance
        return distance

    return f


def negate(other: SDFCallable) -> SDFCallable:
    """Invert the sign of a signed distance function.

    Args:
        other: SDF to negate.

    Returns:
        A negated SDF callable.
    """

    def f(p: FloatArray) -> FloatArray:
        return -other(p)

    return f


def dilate(other: SDFCallable, radius: float) -> SDFCallable:
    """Expand an SDF outward by a fixed radius.

    Args:
        other: SDF to dilate.
        radius: Dilation radius.

    Returns:
        A dilated SDF callable.
    """

    def f(p: FloatArray) -> FloatArray:
        return other(p) - radius

    return f


def erode(other: SDFCallable, radius: float) -> SDFCallable:
    """Shrink an SDF inward by a fixed radius.

    Args:
        other: SDF to erode.
        radius: Erosion radius.

    Returns:
        An eroded SDF callable.
    """

    def f(p: FloatArray) -> FloatArray:
        return other(p) + radius

    return f


def shell(other: SDFCallable, thickness: float) -> SDFCallable:
    """Convert an SDF into a thin shell.

    Args:
        other: SDF to shell.
        thickness: Shell thickness.

    Returns:
        A shell SDF callable.
    """

    def f(p: FloatArray) -> FloatArray:
        return np.abs(other(p)) - thickness / 2.0

    return f


def repeat(
    other: SDFCallable,
    spacing: AnyArrayLike,
    count: AnyArrayLike | None = None,
    padding: int | AnyArrayLike = 0,
) -> SDFCallable:
    """Repeat an SDF across a lattice.

    Args:
        other: SDF to repeat.
        spacing: Distance between repeated cells per axis.
        count: Optional per-axis repeat count on either side of the origin.
        padding: Number of neighboring cells to sample when computing the
            repeated field.

    Returns:
        A repeated SDF callable.
    """
    count_array = np.asarray(count, dtype=float) if count is not None else None
    spacing_array = np.asarray(spacing, dtype=float)

    def neighbors(
        dim: int, padding_value: int | AnyArrayLike, spacing_value: FloatArray
    ) -> list[tuple[int, ...]]:
        try:
            padding_values = [int(padding_value[i]) for i in range(dim)]
        except Exception:
            padding_values = [int(padding_value)] * dim
        try:
            spacing_values = [spacing_value[i] for i in range(dim)]
        except Exception:
            spacing_values = [spacing_value] * dim
        for index, step in enumerate(spacing_values):
            if step == 0:
                padding_values[index] = 0
        axes = [list(range(-value, value + 1)) for value in padding_values]
        return list(itertools.product(*axes))

    def f(p: FloatArray) -> FloatArray:
        q = np.divide(p, spacing_array, out=np.zeros_like(p), where=spacing_array != 0)
        if count_array is None:
            index = np.round(q)
        else:
            index = np.clip(np.round(q), -count_array, count_array)

        indexes = [
            index + offset for offset in neighbors(p.shape[-1], padding, spacing_array)
        ]
        distances = [other(p - spacing_array * item) for item in indexes]
        distance = distances[0]
        for other_distance in distances[1:]:
            distance = _min(distance, other_distance)
        return distance

    return f


__all__ = [
    "blend",
    "difference",
    "dilate",
    "erode",
    "intersection",
    "negate",
    "repeat",
    "shell",
    "union",
]
