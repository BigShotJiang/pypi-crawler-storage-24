"""Console progress bar helpers used during mesh generation."""

from __future__ import annotations

import sys
import time


def pretty_time(seconds: float) -> str:
    """Format a duration as ``H:MM:SS``.

    Args:
        seconds: Duration in seconds.

    Returns:
        A human-readable duration string.
    """
    total_seconds = int(round(seconds))
    s = total_seconds % 60
    m = (total_seconds // 60) % 60
    h = total_seconds // 3600
    return f"{h}:{m:02d}:{s:02d}"


class Bar:
    """Render a simple progress bar to standard output.

    Args:
        max_value: Upper bound of the progress range.
        min_value: Lower bound of the progress range.
        enabled: Whether to emit progress updates.
    """

    def __init__(
        self, max_value: int = 100, min_value: int = 0, enabled: bool = True
    ) -> None:
        self.min_value = min_value
        self.max_value = max_value
        self.value = min_value
        self.start_time = time.time()
        self.enabled = enabled

    @property
    def percent_complete(self) -> float:
        """Return the completion percentage."""
        total = self.max_value - self.min_value
        if total == 0:
            return 100.0
        progress = (self.value - self.min_value) / total
        return progress * 100.0

    @property
    def elapsed_time(self) -> float:
        """Return the elapsed time in seconds."""
        return time.time() - self.start_time

    @property
    def eta(self) -> float:
        """Estimate the remaining time in seconds."""
        fraction = self.percent_complete / 100.0
        if fraction == 0:
            return 0.0
        return (1.0 - fraction) * self.elapsed_time / fraction

    def increment(self, delta: int) -> None:
        """Advance the bar by ``delta`` units.

        Args:
            delta: Increment to apply.
        """
        self.update(self.value + delta)

    def update(self, value: int) -> None:
        """Set the current bar value.

        Args:
            value: New progress value.
        """
        self.value = value
        if self.enabled:
            sys.stdout.write(f"  {self.render()}    \r")
            sys.stdout.flush()

    def done(self) -> None:
        """Mark the bar as complete and stop rendering."""
        self.update(self.max_value)
        self.stop()

    def stop(self) -> None:
        """Stop rendering and finish the current line."""
        if self.enabled:
            sys.stdout.write("\n")
            sys.stdout.flush()

    def render(self) -> str:
        """Return the current bar state as text."""
        items = [
            self.render_percent_complete(),
            self.render_value(),
            self.render_bar(),
            self.render_elapsed_time(),
            self.render_eta(),
        ]
        return " ".join(items)

    def render_percent_complete(self) -> str:
        """Return the completion percentage segment."""
        return f"{self.percent_complete:3.0f}%"

    def render_value(self) -> str:
        """Return the current value segment."""
        if self.min_value == 0:
            return f"({self.value:g} of {self.max_value:g})"
        return f"({self.value:g})"

    def render_bar(self, size: int = 30) -> str:
        """Return the bar segment.

        Args:
            size: Number of character cells in the bar.

        Returns:
            A text progress bar.
        """
        filled = int(round(self.percent_complete / 100.0 * size))
        empty = size - filled
        return "[" + "#" * filled + "-" * empty + "]"

    def render_elapsed_time(self) -> str:
        """Return the elapsed time segment."""
        return pretty_time(self.elapsed_time)

    def render_eta(self) -> str:
        """Return the ETA segment."""
        return pretty_time(self.eta)


__all__ = ["Bar", "pretty_time"]
