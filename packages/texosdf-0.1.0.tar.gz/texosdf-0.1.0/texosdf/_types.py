"""Shared type aliases for texosdf."""

from __future__ import annotations

from os import PathLike
from typing import Callable, TypeAlias

import numpy as np
from numpy.typing import ArrayLike, NDArray

FloatArray: TypeAlias = NDArray[np.float64]
Points2D: TypeAlias = FloatArray
Points3D: TypeAlias = FloatArray
DistanceArray: TypeAlias = FloatArray
Vector2: TypeAlias = tuple[float, float]
Vector3: TypeAlias = tuple[float, float, float]
Bounds2D: TypeAlias = tuple[Vector2, Vector2]
Bounds3D: TypeAlias = tuple[Vector3, Vector3]
ScalarOrVector2: TypeAlias = float | Vector2
ScalarOrVector3: TypeAlias = float | Vector3
PathLikeStr: TypeAlias = str | PathLike[str]
EaseFunction: TypeAlias = Callable[[FloatArray], FloatArray]
SDFCallable: TypeAlias = Callable[[FloatArray], FloatArray]
AnyArrayLike: TypeAlias = ArrayLike

__all__ = [
    "AnyArrayLike",
    "Bounds2D",
    "Bounds3D",
    "DistanceArray",
    "EaseFunction",
    "FloatArray",
    "PathLikeStr",
    "Points2D",
    "Points3D",
    "SDFCallable",
    "ScalarOrVector2",
    "ScalarOrVector3",
    "Vector2",
    "Vector3",
]
