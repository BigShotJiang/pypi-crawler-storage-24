"""Small math utilities re-exported by the public API."""

from __future__ import annotations

import math

pi = math.pi
"""The mathematical constant pi."""

degrees = math.degrees
"""Convert radians to degrees."""

radians = math.radians
"""Convert degrees to radians."""

__all__ = ["degrees", "pi", "radians"]
