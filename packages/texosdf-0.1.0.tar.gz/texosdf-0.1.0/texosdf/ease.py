"""Vectorized easing helpers used by transition operations."""

from __future__ import annotations

import numpy as np

from ._types import FloatArray


def linear(t: FloatArray) -> FloatArray:
    """Apply linear easing.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    return t


def in_quad(t: FloatArray) -> FloatArray:
    """Apply quadratic ease-in easing.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    return t * t


def out_quad(t: FloatArray) -> FloatArray:
    """Apply quadratic ease-out easing.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    return -t * (t - 2)


def in_out_quad(t: FloatArray) -> FloatArray:
    """Apply quadratic ease-in-out easing.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    u = 2 * t - 1
    a = 2 * t * t
    b = -0.5 * (u * (u - 2) - 1)
    return np.where(t < 0.5, a, b)


def in_cubic(t: FloatArray) -> FloatArray:
    """Apply cubic ease-in easing.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    return t * t * t


def out_cubic(t: FloatArray) -> FloatArray:
    """Apply cubic ease-out easing.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    u = t - 1
    return u * u * u + 1


def in_out_cubic(t: FloatArray) -> FloatArray:
    """Apply cubic ease-in-out easing.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    u = t * 2
    v = u - 2
    a = 0.5 * u * u * u
    b = 0.5 * (v * v * v + 2)
    return np.where(u < 1, a, b)


def in_quart(t: FloatArray) -> FloatArray:
    """Apply quartic ease-in easing.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    return t * t * t * t


def out_quart(t: FloatArray) -> FloatArray:
    """Apply quartic ease-out easing.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    u = t - 1
    return -(u * u * u * u - 1)


def in_out_quart(t: FloatArray) -> FloatArray:
    """Apply quartic ease-in-out easing.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    u = t * 2
    v = u - 2
    a = 0.5 * u * u * u * u
    b = -0.5 * (v * v * v * v - 2)
    return np.where(u < 1, a, b)


def in_quint(t: FloatArray) -> FloatArray:
    """Apply quintic ease-in easing.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    return t * t * t * t * t


def out_quint(t: FloatArray) -> FloatArray:
    """Apply quintic ease-out easing.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    u = t - 1
    return u * u * u * u * u + 1


def in_out_quint(t: FloatArray) -> FloatArray:
    """Apply quintic ease-in-out easing.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    u = t * 2
    v = u - 2
    a = 0.5 * u * u * u * u * u
    b = 0.5 * (v * v * v * v * v + 2)
    return np.where(u < 1, a, b)


def in_sine(t: FloatArray) -> FloatArray:
    """Apply sinusoidal ease-in easing.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    return -np.cos(t * np.pi / 2) + 1


def out_sine(t: FloatArray) -> FloatArray:
    """Apply sinusoidal ease-out easing.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    return np.sin(t * np.pi / 2)


def in_out_sine(t: FloatArray) -> FloatArray:
    """Apply sinusoidal ease-in-out easing.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    return -0.5 * (np.cos(np.pi * t) - 1)


def in_expo(t: FloatArray) -> FloatArray:
    """Apply exponential ease-in easing.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    a = np.zeros(len(t))
    b = 2 ** (10 * (t - 1))
    return np.where(t == 0, a, b)


def out_expo(t: FloatArray) -> FloatArray:
    """Apply exponential ease-out easing.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    a = np.zeros(len(t)) + 1
    b = 1 - 2 ** (-10 * t)
    return np.where(t == 1, a, b)


def in_out_expo(t: FloatArray) -> FloatArray:
    """Apply exponential ease-in-out easing.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    zero = np.zeros(len(t))
    one = zero + 1
    a = 0.5 * 2 ** (20 * t - 10)
    b = 1 - 0.5 * 2 ** (-20 * t + 10)
    return np.where(t == 0, zero, np.where(t == 1, one, np.where(t < 0.5, a, b)))


def in_circ(t: FloatArray) -> FloatArray:
    """Apply circular ease-in easing.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    return -(np.sqrt(1 - t * t) - 1)


def out_circ(t: FloatArray) -> FloatArray:
    """Apply circular ease-out easing.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    u = t - 1
    return np.sqrt(1 - u * u)


def in_out_circ(t: FloatArray) -> FloatArray:
    """Apply circular ease-in-out easing.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    u = t * 2
    v = u - 2
    a = -0.5 * (np.sqrt(1 - u * u) - 1)
    b = 0.5 * (np.sqrt(1 - v * v) + 1)
    return np.where(u < 1, a, b)


def in_elastic(t: FloatArray, k: float = 0.5) -> FloatArray:
    """Apply elastic ease-in easing.

    Args:
        t: Values in the ``[0, 1]`` interval.
        k: Elastic period.

    Returns:
        The eased values.
    """
    u = t - 1
    return -(2 ** (10 * u) * np.sin((u - k / 4) * (2 * np.pi) / k))


def out_elastic(t: FloatArray, k: float = 0.5) -> FloatArray:
    """Apply elastic ease-out easing.

    Args:
        t: Values in the ``[0, 1]`` interval.
        k: Elastic period.

    Returns:
        The eased values.
    """
    return 2 ** (-10 * t) * np.sin((t - k / 4) * (2 * np.pi / k)) + 1


def in_out_elastic(t: FloatArray, k: float = 0.5) -> FloatArray:
    """Apply elastic ease-in-out easing.

    Args:
        t: Values in the ``[0, 1]`` interval.
        k: Elastic period.

    Returns:
        The eased values.
    """
    u = t * 2
    v = u - 1
    a = -0.5 * (2 ** (10 * v) * np.sin((v - k / 4) * 2 * np.pi / k))
    b = 2 ** (-10 * v) * np.sin((v - k / 4) * 2 * np.pi / k) * 0.5 + 1
    return np.where(u < 1, a, b)


def in_back(t: FloatArray) -> FloatArray:
    """Apply back ease-in easing.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    k = 1.70158
    return t * t * ((k + 1) * t - k)


def out_back(t: FloatArray) -> FloatArray:
    """Apply back ease-out easing.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    k = 1.70158
    u = t - 1
    return u * u * ((k + 1) * u + k) + 1


def in_out_back(t: FloatArray) -> FloatArray:
    """Apply back ease-in-out easing.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    k = 1.70158 * 1.525
    u = t * 2
    v = u - 2
    a = 0.5 * (u * u * ((k + 1) * u - k))
    b = 0.5 * (v * v * ((k + 1) * v + k) + 2)
    return np.where(u < 1, a, b)


def in_bounce(t: FloatArray) -> FloatArray:
    """Apply bounce ease-in easing.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    return 1 - out_bounce(1 - t)


def out_bounce(t: FloatArray) -> FloatArray:
    """Apply bounce ease-out easing.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    a = (121 * t * t) / 16
    b = (363 / 40 * t * t) - (99 / 10 * t) + 17 / 5
    c = (4356 / 361 * t * t) - (35442 / 1805 * t) + 16061 / 1805
    d = (54 / 5 * t * t) - (513 / 25 * t) + 268 / 25
    return np.where(t < 4 / 11, a, np.where(t < 8 / 11, b, np.where(t < 9 / 10, c, d)))


def in_out_bounce(t: FloatArray) -> FloatArray:
    """Apply bounce ease-in-out easing.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    a = in_bounce(2 * t) * 0.5
    b = out_bounce(2 * t - 1) * 0.5 + 0.5
    return np.where(t < 0.5, a, b)


def in_square(t: FloatArray) -> FloatArray:
    """Apply a step-like ease-in curve.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    a = np.zeros(len(t))
    b = a + 1
    return np.where(t < 1, a, b)


def out_square(t: FloatArray) -> FloatArray:
    """Apply a step-like ease-out curve.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    a = np.zeros(len(t))
    b = a + 1
    return np.where(t > 0, b, a)


def in_out_square(t: FloatArray) -> FloatArray:
    """Apply a step-like ease-in-out curve.

    Args:
        t: Values in the ``[0, 1]`` interval.

    Returns:
        The eased values.
    """
    a = np.zeros(len(t))
    b = a + 1
    return np.where(t < 0.5, a, b)


__all__ = [
    "in_back",
    "in_bounce",
    "in_circ",
    "in_cubic",
    "in_elastic",
    "in_expo",
    "in_out_back",
    "in_out_bounce",
    "in_out_circ",
    "in_out_cubic",
    "in_out_elastic",
    "in_out_expo",
    "in_out_quad",
    "in_out_quart",
    "in_out_quint",
    "in_out_sine",
    "in_out_square",
    "in_quad",
    "in_quart",
    "in_quint",
    "in_sine",
    "in_square",
    "linear",
    "out_back",
    "out_bounce",
    "out_circ",
    "out_cubic",
    "out_elastic",
    "out_expo",
    "out_quad",
    "out_quart",
    "out_quint",
    "out_sine",
    "out_square",
]
