"""Helpers for writing binary STL files."""

from __future__ import annotations

import struct

import numpy as np

from ._types import PathLikeStr, Points3D


def write_binary_stl(path: PathLikeStr, points: Points3D) -> None:
    """Write triangle vertices to a binary STL file.

    Args:
        path: Output STL path.
        points: Triangle vertices with shape ``(N, 3)`` where every three rows form a triangle.
    """
    triangle_count = len(points) // 3
    triangle_points = np.asarray(points, dtype=np.float32).reshape((-1, 3, 3))
    normals = np.cross(
        triangle_points[:, 1] - triangle_points[:, 0],
        triangle_points[:, 2] - triangle_points[:, 0],
    )
    lengths = np.linalg.norm(normals, axis=1, keepdims=True)
    np.divide(normals, lengths, out=normals, where=lengths != 0)

    dtype = np.dtype(
        [
            ("normal", ("<f4", 3)),
            ("points", ("<f4", (3, 3))),
            ("attr", "<u2"),
        ]
    )
    data = np.zeros(triangle_count, dtype=dtype)
    data["points"] = triangle_points
    data["normal"] = normals

    with open(path, "wb") as file_pointer:
        file_pointer.write(b"\x00" * 80)
        file_pointer.write(struct.pack("<I", triangle_count))
        file_pointer.write(data.tobytes())


__all__ = ["write_binary_stl"]
