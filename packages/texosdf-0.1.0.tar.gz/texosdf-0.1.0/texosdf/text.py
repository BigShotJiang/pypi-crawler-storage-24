"""Text and image helpers that produce 2D SDFs."""

from __future__ import annotations

from os import PathLike

import numpy as np
import scipy.ndimage as nd
from PIL import Image, ImageDraw, ImageFont

from . import d2
from ._types import AnyArrayLike, FloatArray, PathLikeStr, SDFCallable

PIXELS = 2**22


def _load_image(thing: PathLikeStr | AnyArrayLike) -> Image.Image:
    if isinstance(thing, (str, PathLike)):
        return Image.open(thing)
    if isinstance(thing, (np.ndarray, np.generic)):
        return Image.fromarray(thing)
    return Image.fromarray(np.asarray(thing))


def measure_text(
    name: PathLikeStr,
    text: str,
    width: float | None = None,
    height: float | None = None,
) -> tuple[float, float]:
    """Measure the world-space size of rendered text."""
    font = ImageFont.truetype(str(name), 96)
    x0, y0, x1, y1 = font.getbbox(text)
    aspect = (x1 - x0) / (y1 - y0)
    if width is None and height is None:
        height = 1
    if width is None:
        width = height * aspect
    if height is None:
        height = width / aspect
    return float(width), float(height)


def measure_image(
    thing: PathLikeStr | AnyArrayLike,
    width: float | None = None,
    height: float | None = None,
) -> tuple[float, float]:
    """Measure the world-space size of an image mask."""
    image = _load_image(thing)
    pixel_width, pixel_height = image.size
    aspect = pixel_width / pixel_height
    if width is None and height is None:
        height = 1
    if width is None:
        width = height * aspect
    if height is None:
        height = width / aspect
    return float(width), float(height)


@d2.sdf2
def text(
    font_name: PathLikeStr,
    text: str,
    width: float | None = None,
    height: float | None = None,
    pixels: int = PIXELS,
    points: int = 512,
) -> SDFCallable:
    """Render text into a 2D signed distance field."""
    font = ImageFont.truetype(str(font_name), points)
    padding = 0.2
    x0, y0, x1, y1 = font.getbbox(text)
    pad_x = int((x1 - x0) * padding)
    pad_y = int((y1 - y0) * padding)
    texture_width = x1 - x0 + 1 + pad_x * 2
    texture_height = y1 - y0 + 1 + pad_y * 2

    image = Image.new("L", (texture_width, texture_height))
    draw = ImageDraw.Draw(image)
    draw.text((pad_x - x0, pad_y - y0), text, font=font, fill=255)
    return _sdf(width, height, pixels, pad_x, pad_y, image)


@d2.sdf2
def image(
    thing: PathLikeStr | AnyArrayLike,
    width: float | None = None,
    height: float | None = None,
    pixels: int = PIXELS,
) -> SDFCallable:
    """Convert an image mask into a 2D signed distance field."""
    return _sdf(width, height, pixels, 0, 0, _load_image(thing).convert("L"))


def _sdf(
    width: float | None,
    height: float | None,
    pixels: int,
    pad_x: int,
    pad_y: int,
    image: Image.Image,
) -> SDFCallable:
    texture_width, texture_height = image.size
    factor = (pixels / (texture_width * texture_height)) ** 0.5
    if factor < 1:
        texture_width = int(round(texture_width * factor))
        texture_height = int(round(texture_height * factor))
        pad_x = int(round(pad_x * factor))
        pad_y = int(round(pad_y * factor))
        image = image.resize((texture_width, texture_height))

    bitmap = np.array(image.convert("1"))
    inside = -nd.distance_transform_edt(bitmap)
    outside = nd.distance_transform_edt(~bitmap)
    texture = np.zeros(bitmap.shape)
    texture[bitmap] = inside[bitmap]
    texture[~bitmap] = outside[~bitmap]

    pixel_width = texture_width - pad_x * 2
    pixel_height = texture_height - pad_y * 2
    aspect = pixel_width / pixel_height
    if width is None and height is None:
        height = 1
    if width is None:
        width = height * aspect
    if height is None:
        height = width / aspect
    x0 = -width / 2
    y0 = -height / 2
    x1 = width / 2
    y1 = height / 2

    texture *= width / texture_width
    rectangle = d2.rectangle((width / 2, height / 2))

    def f(p: FloatArray) -> FloatArray:
        x_values = p[:, 0]
        y_values = p[:, 1]
        u = (x_values - x0) / (x1 - x0)
        v = 1 - (y_values - y0) / (y1 - y0)
        i = u * pixel_width + pad_x
        j = v * pixel_height + pad_y
        distance = _bilinear_interpolate(texture, i, j)
        fallback = rectangle(p).reshape(-1)
        outside_bounds = (
            (i < 0) | (i >= texture_width - 1) | (j < 0) | (j >= texture_height - 1)
        )
        distance[outside_bounds] = fallback[outside_bounds]
        return distance

    return f


def _bilinear_interpolate(a: FloatArray, x: FloatArray, y: FloatArray) -> FloatArray:
    x0 = np.floor(x).astype(int)
    x1 = x0 + 1
    y0 = np.floor(y).astype(int)
    y1 = y0 + 1

    x0 = np.clip(x0, 0, a.shape[1] - 1)
    x1 = np.clip(x1, 0, a.shape[1] - 1)
    y0 = np.clip(y0, 0, a.shape[0] - 1)
    y1 = np.clip(y1, 0, a.shape[0] - 1)

    pa = a[y0, x0]
    pb = a[y1, x0]
    pc = a[y0, x1]
    pd = a[y1, x1]

    wa = (x1 - x) * (y1 - y)
    wb = (x1 - x) * (y - y0)
    wc = (x - x0) * (y1 - y)
    wd = (x - x0) * (y - y0)
    return wa * pa + wb * pb + wc * pc + wd * pd


__all__ = ["PIXELS", "image", "measure_image", "measure_text", "text"]
