"""2D signed distance primitives and operations."""

from __future__ import annotations

import functools
from typing import Any, Callable

import numpy as np

from . import d3, ease, ops
from ._types import (
    AnyArrayLike,
    DistanceArray,
    EaseFunction,
    FloatArray,
    ScalarOrVector2,
    SDFCallable,
)

ORIGIN = np.array((0.0, 0.0))
X = np.array((1.0, 0.0))
Y = np.array((0.0, 1.0))
UP = Y

_ops: dict[str, Callable[..., object]] = {}
_min = np.minimum
_max = np.maximum


class SDF2:
    """Callable wrapper around a vectorized 2D signed distance function.

    Args:
        f: Callable that accepts points with shape ``(N, 2)`` and returns signed distances.
    """

    def __init__(self, f: SDFCallable) -> None:
        self.f = f
        self._k: float | None = None

    def __call__(self, p: FloatArray) -> DistanceArray:
        """Evaluate the SDF on a batch of 2D points.

        Args:
            p: Points with shape ``(N, 2)``.

        Returns:
            Distances with shape ``(N, 1)``.
        """
        return self.f(np.asarray(p, dtype=float)).reshape((-1, 1))

    def __getattr__(self, name: str):
        if name in _ops:
            return functools.partial(_ops[name], self)
        raise AttributeError(name)

    def __or__(self, other: "SDF2") -> "SDF2":
        return union(self, other)

    def __and__(self, other: "SDF2") -> "SDF2":
        return intersection(self, other)

    def __sub__(self, other: "SDF2") -> "SDF2":
        return difference(self, other)

    def k(self, k: float | None = None) -> "SDF2":
        """Store a smoothing value for subsequent boolean combinations.

        Args:
            k: Smoothing factor used by boolean operations.

        Returns:
            The same SDF instance for fluent chaining.
        """
        self._k = k
        return self


def sdf2(f: Callable[..., SDFCallable]) -> Callable[..., SDF2]:
    """Wrap an SDF factory and return :class:`SDF2` objects.

    Args:
        f: Factory returning a vectorized SDF callable.

    Returns:
        A wrapped factory that returns :class:`SDF2` instances.
    """

    @functools.wraps(f)
    def wrapper(*args: Any, **kwargs: Any) -> SDF2:
        return SDF2(f(*args, **kwargs))

    return wrapper


def op2(f: Callable[..., SDFCallable]) -> Callable[..., SDF2]:
    """Register a 2D operation for free-function and method-style use.

    Args:
        f: Operation returning a vectorized 2D SDF callable.

    Returns:
        A wrapped operation that returns :class:`SDF2` instances.
    """

    @functools.wraps(f)
    def wrapper(*args: Any, **kwargs: Any) -> SDF2:
        return SDF2(f(*args, **kwargs))

    _ops[f.__name__] = wrapper
    return wrapper


def op23(f: Callable[..., SDFCallable]) -> Callable[..., "d3.SDF3"]:
    """Register a 2D-to-3D operation for method-style use.

    Args:
        f: Operation returning a vectorized 3D SDF callable.

    Returns:
        A wrapped operation that returns :class:`texosdf.d3.SDF3` instances.
    """

    @functools.wraps(f)
    def wrapper(*args: Any, **kwargs: Any) -> "d3.SDF3":
        return d3.SDF3(f(*args, **kwargs))

    _ops[f.__name__] = wrapper
    return wrapper


def _length(a: FloatArray) -> FloatArray:
    return np.linalg.norm(a, axis=1)


def _normalize(a: AnyArrayLike) -> FloatArray:
    vector = np.asarray(a, dtype=float)
    return vector / np.linalg.norm(vector)


def _dot(a: FloatArray, b: AnyArrayLike) -> FloatArray:
    return np.sum(a * b, axis=1)


def _vec(*arrays: AnyArrayLike) -> FloatArray:
    return np.stack(arrays, axis=-1)


@sdf2
def circle(radius: float = 1, center: AnyArrayLike = ORIGIN) -> SDFCallable:
    """Create a circle SDF.

    Args:
        radius: Circle radius.
        center: Circle center.

    Returns:
        A 2D signed distance function.
    """
    center_array = np.asarray(center, dtype=float)

    def f(p: FloatArray) -> FloatArray:
        return _length(p - center_array) - radius

    return f


@sdf2
def line(normal: AnyArrayLike = UP, point: AnyArrayLike = ORIGIN) -> SDFCallable:
    """Create an infinite line half-space SDF.

    Args:
        normal: Outward line normal.
        point: Point on the line.

    Returns:
        A 2D signed distance function.
    """
    normal_array = _normalize(normal)
    point_array = np.asarray(point, dtype=float)

    def f(p: FloatArray) -> FloatArray:
        return np.dot(point_array - p, normal_array)

    return f


@sdf2
def slab(
    x0: float | None = None,
    y0: float | None = None,
    x1: float | None = None,
    y1: float | None = None,
    k: float | None = None,
) -> SDFCallable:
    """Create an axis-aligned 2D slab.

    Args:
        x0: Lower x bound.
        y0: Lower y bound.
        x1: Upper x bound.
        y1: Upper y bound.
        k: Optional smoothing factor for combining the half-spaces.

    Returns:
        A 2D signed distance function.
    """
    functions: list[SDF2] = []
    if x0 is not None:
        functions.append(line(X, (x0, 0)))
    if x1 is not None:
        functions.append(line(-X, (x1, 0)))
    if y0 is not None:
        functions.append(line(Y, (0, y0)))
    if y1 is not None:
        functions.append(line(-Y, (0, y1)))
    return intersection(*functions, k=k).f


@sdf2
def rectangle(
    size: ScalarOrVector2 = 1,
    center: AnyArrayLike = ORIGIN,
    a: AnyArrayLike | None = None,
    b: AnyArrayLike | None = None,
) -> SDFCallable:
    """Create a rectangle SDF.

    Args:
        size: Rectangle size as a scalar or ``(width, height)``.
        center: Rectangle center.
        a: Optional lower-left corner.
        b: Optional upper-right corner.

    Returns:
        A 2D signed distance function.
    """
    if a is not None and b is not None:
        a_array = np.asarray(a, dtype=float)
        b_array = np.asarray(b, dtype=float)
        size = tuple((b_array - a_array).tolist())
        center = a_array + (b_array - a_array) / 2
        return rectangle(size=size, center=center).f
    size_array = np.asarray(size, dtype=float)
    center_array = np.asarray(center, dtype=float)

    def f(p: FloatArray) -> FloatArray:
        q = np.abs(p - center_array) - size_array / 2
        return _length(_max(q, 0)) + _min(np.amax(q, axis=1), 0)

    return f


@sdf2
def rounded_rectangle(
    size: AnyArrayLike,
    radius: float | tuple[float, float, float, float],
    center: AnyArrayLike = ORIGIN,
) -> SDFCallable:
    """Create a rectangle with rounded corners.

    Args:
        size: Rectangle size as ``(width, height)``.
        radius: Corner radius or per-corner radii.
        center: Rectangle center.

    Returns:
        A 2D signed distance function.
    """
    size_array = np.asarray(size, dtype=float)
    center_array = np.asarray(center, dtype=float)
    try:
        r0, r1, r2, r3 = radius
    except TypeError:
        r0 = r1 = r2 = r3 = float(radius)

    def f(p: FloatArray) -> FloatArray:
        shifted = p - center_array
        x = shifted[:, 0]
        y = shifted[:, 1]
        radii = np.zeros(len(p)).reshape((-1, 1))
        radii[np.logical_and(x > 0, y > 0)] = r0
        radii[np.logical_and(x > 0, y <= 0)] = r1
        radii[np.logical_and(x <= 0, y <= 0)] = r2
        radii[np.logical_and(x <= 0, y > 0)] = r3
        q = np.abs(shifted) - size_array / 2 + radii
        return (
            _min(_max(q[:, 0], q[:, 1]), 0).reshape((-1, 1))
            + _length(_max(q, 0)).reshape((-1, 1))
            - radii
        )

    return f


@sdf2
def equilateral_triangle() -> SDFCallable:
    """Create a unit equilateral triangle SDF.

    Returns:
        A 2D signed distance function.
    """

    def f(p: FloatArray) -> FloatArray:
        k = 3**0.5
        q = _vec(np.abs(p[:, 0]) - 1, p[:, 1] + 1 / k)
        use_fold = q[:, 0] + k * q[:, 1] > 0
        folded = _vec(q[:, 0] - k * q[:, 1], -k * q[:, 0] - q[:, 1]) / 2
        q = np.where(use_fold.reshape((-1, 1)), folded, q)
        q = _vec(q[:, 0] - np.clip(q[:, 0], -2, 0), q[:, 1])
        return -_length(q) * np.sign(q[:, 1])

    return f


@sdf2
def hexagon(radius: float) -> SDFCallable:
    """Create a regular hexagon SDF.

    Args:
        radius: Circumradius of the hexagon.

    Returns:
        A 2D signed distance function.
    """
    scaled_radius = radius * 3**0.5 / 2

    def f(p: FloatArray) -> FloatArray:
        k = np.array((3**0.5 / -2, 0.5, np.tan(np.pi / 6)))
        q = np.abs(p)
        q -= 2 * k[:2] * _min(_dot(k[:2], q), 0).reshape((-1, 1))
        q -= _vec(
            np.clip(q[:, 0], -k[2] * scaled_radius, k[2] * scaled_radius),
            np.zeros(len(p)) + scaled_radius,
        )
        return _length(q) * np.sign(q[:, 1])

    return f


@sdf2
def rounded_x(width: float, radius: float) -> SDFCallable:
    """Create a rounded X-shaped 2D SDF.

    Args:
        width: Arm width.
        radius: End radius.

    Returns:
        A 2D signed distance function.
    """

    def f(p: FloatArray) -> FloatArray:
        q = np.abs(p)
        half = (_min(q[:, 0] + q[:, 1], width) * 0.5).reshape((-1, 1))
        return _length(q - half) - radius

    return f


@sdf2
def polygon(points: list[AnyArrayLike]) -> SDFCallable:
    """Create an SDF from a closed polygon.

    Args:
        points: Polygon vertices in winding order.

    Returns:
        A 2D signed distance function.
    """
    vertices = [np.asarray(point, dtype=float) for point in points]

    def f(p: FloatArray) -> FloatArray:
        vertex_count = len(vertices)
        distance = _dot(p - vertices[0], p - vertices[0])
        sign = np.ones(len(p))
        for index in range(vertex_count):
            prev_index = (index + vertex_count - 1) % vertex_count
            current = vertices[index]
            previous = vertices[prev_index]
            edge = previous - current
            offset = p - current
            projected = offset - edge * np.clip(
                np.dot(offset, edge) / np.dot(edge, edge), 0, 1
            ).reshape((-1, 1))
            distance = _min(distance, _dot(projected, projected))
            c1 = p[:, 1] >= current[1]
            c2 = p[:, 1] < previous[1]
            c3 = edge[0] * offset[:, 1] > edge[1] * offset[:, 0]
            mask = _vec(c1, c2, c3)
            sign = np.where(np.all(mask, axis=1) | np.all(~mask, axis=1), -sign, sign)
        return sign * np.sqrt(distance)

    return f


@sdf2
def vesica(radius: float, distance: float) -> SDFCallable:
    """Create a vesica piscis SDF.

    Args:
        radius: Radius of the circles.
        distance: Distance from the origin to each circle center along x.

    Returns:
        A 2D signed distance function.
    """

    def f(p: FloatArray) -> FloatArray:
        q = np.abs(p)
        height = np.sqrt(radius * radius - distance * distance)
        return np.where(
            ((q[:, 1] - height) * distance > q[:, 0] * height),
            _length(q - np.array([0, height], dtype=float)),
            _length(q - np.array([-distance, 0], dtype=float)) - radius,
        )

    return f


@op2
def translate(other: SDF2, offset: AnyArrayLike) -> SDFCallable:
    """Translate a 2D SDF.

    Args:
        other: SDF to translate.
        offset: Translation vector.

    Returns:
        A translated 2D signed distance function.
    """
    offset_array = np.asarray(offset, dtype=float)

    def f(p: FloatArray) -> FloatArray:
        return other(p - offset_array)

    return f


@op2
def scale(other: SDF2, factor: ScalarOrVector2) -> SDFCallable:
    """Scale a 2D SDF.

    Args:
        other: SDF to scale.
        factor: Uniform scale or ``(sx, sy)``.

    Returns:
        A scaled 2D signed distance function.
    """
    try:
        x_scale, y_scale = factor
    except TypeError:
        x_scale = y_scale = float(factor)
    scale_array = np.array((x_scale, y_scale), dtype=float)
    scale_min = min(x_scale, y_scale)

    def f(p: FloatArray) -> FloatArray:
        return other(p / scale_array) * scale_min

    return f


@op2
def rotate(other: SDF2, angle: float) -> SDFCallable:
    """Rotate a 2D SDF around the origin.

    Args:
        other: SDF to rotate.
        angle: Rotation angle in radians.

    Returns:
        A rotated 2D signed distance function.
    """
    sine = np.sin(angle)
    cosine = np.cos(angle)
    matrix = np.array([[cosine, -sine], [sine, cosine]], dtype=float).T

    def f(p: FloatArray) -> FloatArray:
        return other(np.dot(p, matrix))

    return f


@op2
def circular_array(other: SDF2, count: int) -> SDFCallable:
    """Repeat a 2D SDF around the origin.

    Args:
        other: SDF to repeat.
        count: Number of repeated instances.

    Returns:
        A 2D signed distance function.
    """
    angles = [index / count * 2 * np.pi for index in range(count)]
    return union(*[other.rotate(angle) for angle in angles]).f


@op2
def elongate(other: SDF2, size: AnyArrayLike) -> SDFCallable:
    """Elongate a 2D SDF along each axis.

    Args:
        other: SDF to elongate.
        size: Elongation amount per axis.

    Returns:
        A 2D signed distance function.
    """
    size_array = np.asarray(size, dtype=float)

    def f(p: FloatArray) -> FloatArray:
        q = np.abs(p) - size_array
        x_values = q[:, 0].reshape((-1, 1))
        y_values = q[:, 1].reshape((-1, 1))
        w = _min(_max(x_values, y_values), 0)
        return other(_max(q, 0)) + w

    return f


@op23
def extrude(other: SDF2, height: float) -> SDFCallable:
    """Extrude a 2D SDF into 3D.

    Args:
        other: 2D SDF to extrude.
        height: Extrusion height.

    Returns:
        A 3D signed distance function.
    """

    def f(p: FloatArray) -> FloatArray:
        distance = other(p[:, [0, 1]])
        w = _vec(distance.reshape(-1), np.abs(p[:, 2]) - height / 2)
        return _min(_max(w[:, 0], w[:, 1]), 0) + _length(_max(w, 0))

    return f


@op23
def extrude_to(
    a: SDF2, b: SDF2, height: float, e: EaseFunction = ease.linear
) -> SDFCallable:
    """Blend two 2D SDFs across an extrusion.

    Args:
        a: Start profile.
        b: End profile.
        height: Extrusion height.
        e: Easing function controlling the blend.

    Returns:
        A 3D signed distance function.
    """

    def f(p: FloatArray) -> FloatArray:
        d1 = a(p[:, [0, 1]])
        d2 = b(p[:, [0, 1]])
        t = e(np.clip(p[:, 2] / height, -0.5, 0.5) + 0.5)
        distance = d1 + (d2 - d1) * t.reshape((-1, 1))
        w = _vec(distance.reshape(-1), np.abs(p[:, 2]) - height / 2)
        return _min(_max(w[:, 0], w[:, 1]), 0) + _length(_max(w, 0))

    return f


@op23
def revolve(other: SDF2, offset: float = 0) -> SDFCallable:
    """Revolve a 2D profile around the z axis.

    Args:
        other: 2D profile to revolve.
        offset: Radial offset before revolving.

    Returns:
        A 3D signed distance function.
    """

    def f(p: FloatArray) -> FloatArray:
        xy = p[:, [0, 1]]
        q = _vec(_length(xy) - offset, p[:, 2])
        return other(q)

    return f


union = op2(ops.union)
difference = op2(ops.difference)
intersection = op2(ops.intersection)
blend = op2(ops.blend)
negate = op2(ops.negate)
dilate = op2(ops.dilate)
erode = op2(ops.erode)
shell = op2(ops.shell)
repeat = op2(ops.repeat)

__all__ = [
    "ORIGIN",
    "SDF2",
    "UP",
    "X",
    "Y",
    "blend",
    "circle",
    "circular_array",
    "difference",
    "dilate",
    "elongate",
    "equilateral_triangle",
    "erode",
    "extrude",
    "extrude_to",
    "hexagon",
    "intersection",
    "line",
    "negate",
    "op2",
    "op23",
    "polygon",
    "rectangle",
    "repeat",
    "revolve",
    "rotate",
    "rounded_rectangle",
    "rounded_x",
    "scale",
    "sdf2",
    "shell",
    "slab",
    "translate",
    "union",
    "vesica",
]
