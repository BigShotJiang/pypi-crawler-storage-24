import tempfile
import unittest
from pathlib import Path
from unittest import mock

import numpy as np

import texosdf
from texosdf import core, mesh as mesh_module


class TexosdfSmokeTests(unittest.TestCase):
    def test_public_import_surface(self):
        self.assertEqual(texosdf.__version__, '0.1.0')
        self.assertTrue(callable(texosdf.sphere))
        self.assertTrue(hasattr(texosdf, 'd2'))
        self.assertTrue(hasattr(texosdf, 'd3'))

    def test_circle_returns_column_vector(self):
        points = np.array([[0.0, 0.0], [1.0, 0.0]], dtype=float)
        distances = texosdf.circle(1.0)(points)
        self.assertEqual(distances.shape, (2, 1))
        self.assertLess(distances[0, 0], 0)
        self.assertAlmostEqual(distances[1, 0], 0.0)

    def test_generate_and_save_stl(self):
        solid = texosdf.sphere(1.0).translate((0.25, 0.0, 0.0))
        bounds = ((-1.5, -1.5, -1.5), (1.5, 1.5, 1.5))
        points = solid.generate(bounds=bounds, step=0.5, workers=1, verbose=False)
        self.assertEqual(points.shape[1], 3)
        self.assertGreater(len(points), 0)

        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / 'out.stl'
            solid.save(path, bounds=bounds, step=0.75, workers=1, verbose=False)
            self.assertTrue(path.exists())
            self.assertGreater(path.stat().st_size, 84)

    def test_show_slice_missing_matplotlib_message(self):
        with mock.patch.object(core, 'plt', None), mock.patch.object(core, '_MATPLOTLIB_IMPORT_ERROR', ImportError('missing matplotlib')):
            with self.assertRaisesRegex(ImportError, 'matplotlib is required'):
                texosdf.show_slice(texosdf.sphere(1.0), z=0.0, bounds=((-1, -1, -1), (1, 1, 1)), w=8, h=8)

    def test_mesh_from_file_missing_meshio_message(self):
        with mock.patch.object(mesh_module, 'meshio', None), mock.patch.object(mesh_module, '_MESHIO_IMPORT_ERROR', ImportError('missing meshio')):
            with self.assertRaisesRegex(ImportError, 'meshio is required'):
                mesh_module.Mesh.from_file('demo.stl')

    def test_mesh_sdf_missing_openvdb_message(self):
        mesh = mesh_module.Mesh(
            np.array([[0.0, 0.0, 0.0], [1.0, 0.0, 0.0], [0.0, 1.0, 0.0]], dtype=float),
            np.array([[0, 1, 2]], dtype=int),
        )
        with mock.patch.object(mesh_module, 'vdb', None), mock.patch.object(mesh_module, '_OPENVDB_IMPORT_ERROR', ImportError('missing pyopenvdb')):
            with self.assertRaisesRegex(ImportError, 'pyopenvdb is required'):
                mesh.sdf(voxel_size=0.1)


if __name__ == '__main__':
    unittest.main()
