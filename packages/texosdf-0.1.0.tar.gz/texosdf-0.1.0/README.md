# texosdf

`texosdf` is a lightweight Python package for generating 3D meshes from signed
distance functions (SDFs).

This is the main package guide, with the richer original-style examples, images, and
function-oriented reference kept directly in the top-level README.

It is a modernized fork of [fogleman/sdf](https://github.com/fogleman/sdf),
published as `texosdf` with typed modules, curated exports, and clearer package
structure.

## Example

<img width=350 align="right" src="docs/images/example.png">

Here is the canonical constructive solid geometry example. It shows the core
`texosdf` workflow: compose analytic shapes, transform them, apply booleans,
and export a mesh.

```python
from texosdf import *

shape = sphere(1) & box(1.5)

cutout = cylinder(0.5)
shape -= cutout.orient(X) | cutout.orient(Y) | cutout.orient(Z)

shape.save("out.stl")
```

You can 3D print that result or open it in any STL viewer.

## More Examples

| [gearlike.py](examples/gearlike.py) | [knurling.py](examples/knurling.py) | [blobby.py](examples/blobby.py) | [weave.py](examples/weave.py) |
| --- | --- | --- | --- |
| ![gearlike](docs/images/gearlike.png) | ![knurling](docs/images/knurling.png) | ![blobby](docs/images/blobby.png) | ![weave](docs/images/weave.png) |
| ![gearlike](docs/images/gearlike.jpg) | ![knurling](docs/images/knurling.jpg) | ![blobby](docs/images/blobby.jpg) | ![weave](docs/images/weave.jpg) |

## Installation

Install the core package:

```bash
pip install texosdf
```

Optional extras:

```bash
pip install texosdf[plot]
pip install texosdf[mesh]
pip install texosdf[all]
```

If you are working in a Conda environment:

```bash
conda activate texosdf
python -m pip install -e .
```

Notes:

- `plot` installs `matplotlib` for `show_slice()`.
- `mesh` installs `meshio` for mesh loading and non-STL export.
- `Mesh.sdf()` also requires OpenVDB and `pyopenvdb`.
- `pyopenvdb` is intentionally not part of normal package requirements because
  it is platform-specific and only needed for the advanced mesh-to-SDF
  workflow.

## Import Style

The package supports the original convenience style:

```python
from texosdf import *
```

While `import *` is usually not considered best practice in general Python code,
CAD and geometry scripting has broadly moved toward that style because it makes
interactive modeling code much shorter and more readable. `texosdf` keeps that
convenience on purpose.

If you use that style in scripts checked with Ruff, add:

```python
# ruff: noqa: F403, F405
from texosdf import *
```

You can also use explicit imports:

```python
from texosdf import box, sphere
from texosdf import d2, d3, ease
```

## The SDF Model

Primitive constructors such as `circle()`, `rectangle()`, `sphere()`, and
`box()` return `SDF2` or `SDF3` objects.

Those wrappers let you:

- call the distance function on point batches
- chain operations like `.translate()`, `.rotate()`, `.twist()`, and `.shell()`
- use boolean operators like `|`, `&`, and `-`
- generate and save meshes with `.generate()` and `.save()`

For most users, it is easiest to think of them as composable shape objects.

## Resolution, Bounds, And Export

### Bounds

The bounding box is estimated automatically for most shapes. If you know the
sampling region, you can pass bounds explicitly:

```python
from texosdf import *

shape = sphere()
shape.save("out.stl", bounds=((-1, -1, -1), (1, 1, 1)))
```

### Resolution

There are two common ways to control resolution.

Use an explicit step:

```python
from texosdf import *

shape = sphere()
shape.save("out.stl", step=0.01)
shape.save("out.stl", step=(0.01, 0.02, 0.03))
```

Or use a sampling budget:

```python
from texosdf import *

shape = sphere()
shape.save("out.stl", samples=2**22)
```

### Without Saving

You can generate triangle vertices directly:

```python
from texosdf import *

points = sphere().generate(step=0.05)
print(points.shape)
```

And if needed, save the result manually:

```python
from texosdf import *

points = sphere().generate(step=0.05)
write_binary_stl("out.stl", points)
```

### Visualizing The SDF

<img width=350 align="right" src="docs/images/show_slice.png">

You can inspect a 2D slice before exporting a full mesh:

```python
from texosdf import *

shape = sphere(1) & box(1.5)
shape.show_slice(z=0)
shape.show_slice(z=0, abs=True)
```

This requires:

```bash
pip install texosdf[plot]
```

## Function Reference

## 3D Primitives

### sphere

<img width=128 align="right" src="docs/images/sphere.png">

`sphere(radius=1, center=ORIGIN)`

```python
from texosdf import *

shape = sphere()
shape = sphere(2)
shape = sphere(1, (1, 2, 3))
```

### box

<img width=128 align="right" src="docs/images/box2.png">

`box(size=1, center=ORIGIN, a=None, b=None)`

```python
from texosdf import *

shape = box(1)
shape = box((1, 2, 3))
shape = box(a=(-1, -1, -1), b=(3, 4, 5))
```

### rounded_box

<img width=128 align="right" src="docs/images/rounded_box.png">

`rounded_box(size, radius)`

```python
from texosdf import *

shape = rounded_box((1, 2, 3), 0.25)
```

### wireframe_box

<img width=128 align="right" src="docs/images/wireframe_box.png">

`wireframe_box(size, thickness)`

```python
from texosdf import *

shape = wireframe_box((1, 2, 3), 0.05)
```

### torus

<img width=128 align="right" src="docs/images/torus.png">

`torus(r1, r2)`

```python
from texosdf import *

shape = torus(1, 0.25)
```

### capsule

<img width=128 align="right" src="docs/images/capsule.png">

`capsule(a, b, radius)`

```python
from texosdf import *

shape = capsule(-Z, Z, 0.5)
```

### capped_cylinder

<img width=128 align="right" src="docs/images/capped_cylinder.png">

`capped_cylinder(a, b, radius)`

```python
from texosdf import *

shape = capped_cylinder(-Z, Z, 0.5)
```

### rounded_cylinder

<img width=128 align="right" src="docs/images/rounded_cylinder.png">

`rounded_cylinder(ra, rb, h)`

```python
from texosdf import *

shape = rounded_cylinder(0.5, 0.1, 2)
```

### capped_cone

<img width=128 align="right" src="docs/images/capped_cone.png">

`capped_cone(a, b, ra, rb)`

```python
from texosdf import *

shape = capped_cone(-Z, Z, 1, 0.5)
```

### rounded_cone

<img width=128 align="right" src="docs/images/rounded_cone.png">

`rounded_cone(r1, r2, h)`

```python
from texosdf import *

shape = rounded_cone(0.75, 0.25, 2)
```

### ellipsoid

<img width=128 align="right" src="docs/images/ellipsoid.png">

`ellipsoid(size)`

```python
from texosdf import *

shape = ellipsoid((1, 2, 3))
```

### pyramid

<img width=128 align="right" src="docs/images/pyramid.png">

`pyramid(h)`

```python
from texosdf import *

shape = pyramid(1)
```

## Platonic Solids

### tetrahedron

<img width=128 align="right" src="docs/images/tetrahedron.png">

```python
from texosdf import *

shape = tetrahedron(1)
```

### octahedron

<img width=128 align="right" src="docs/images/octahedron.png">

```python
from texosdf import *

shape = octahedron(1)
```

### dodecahedron

<img width=128 align="right" src="docs/images/dodecahedron.png">

```python
from texosdf import *

shape = dodecahedron(1)
```

### icosahedron

<img width=128 align="right" src="docs/images/icosahedron.png">

```python
from texosdf import *

shape = icosahedron(1)
```

## Infinite 3D Primitives

These are most useful when combined with other shapes.

### plane

<img width=128 align="right" src="docs/images/plane.png">

`plane(normal=UP, point=ORIGIN)`

```python
from texosdf import *

shape = sphere() & plane()
```

### slab

<img width=128 align="right" src="docs/images/slab.png">

`slab(x0=None, y0=None, z0=None, x1=None, y1=None, z1=None, k=None)`

```python
from texosdf import *

shape = sphere() & slab(z0=-0.5, z1=0.5, x0=0)
```

### cylinder

<img width=128 align="right" src="docs/images/cylinder.png">

`cylinder(radius)`

```python
from texosdf import *

shape = sphere() - cylinder(0.5)
```

## Text And Images

### text

<img width=350 src="docs/images/text-large.png">

`text(font_name, text, width=None, height=None, pixels=PIXELS, points=512)`

```python
from texosdf import *

font = "Arial"
label = "Hello, world!"
w, h = measure_text(font, label)

shape = rounded_box((w + 1, h + 1, 0.2), 0.1)
shape -= text(font, label).extrude(1)
```

### image

<img width=256 src="docs/images/butterfly.png">

`image(path_or_array, width=None, height=None, pixels=PIXELS)`

```python
from texosdf import *

path = "examples/butterfly.png"
w, h = measure_image(path)

shape = rounded_box((w * 1.1, h * 1.1, 0.1), 0.05)
shape |= image(path).extrude(1) & slab(z0=0, z1=0.075)
```

`image()` also accepts array-like image data, not just file paths.

## Positioning

### translate

<img width=128 align="right" src="docs/images/translate.png">

```python
from texosdf import *

shape = sphere().translate((0, 0, 2))
```

### scale

<img width=128 align="right" src="docs/images/scale.png">

```python
from texosdf import *

shape = sphere().scale(2)
shape = sphere().scale((1, 2, 3))
```

### rotate

<img width=128 align="right" src="docs/images/rotate.png">

```python
from texosdf import *

shape = capped_cylinder(-Z, Z, 0.5).rotate(pi / 4, X)
```

### orient

<img width=128 align="right" src="docs/images/orient.png">

```python
from texosdf import *

cylinder_shape = capped_cylinder(-Z, Z, 0.25)
shape = cylinder_shape.orient(X) | cylinder_shape.orient(Y) | cylinder_shape.orient(Z)
```

## Boolean Operations

Let:

```python
from texosdf import *

a = box((3, 3, 0.5))
b = sphere()
```

### union

<img width=128 align="right" src="docs/images/union.png">

```python
shape = a | b
shape = union(a, b)
```

### difference

<img width=128 align="right" src="docs/images/difference.png">

```python
shape = a - b
shape = difference(a, b)
```

### intersection

<img width=128 align="right" src="docs/images/intersection.png">

```python
shape = a & b
shape = intersection(a, b)
```

### smooth union

<img width=128 align="right" src="docs/images/smooth_union.png">

```python
shape = a | b.k(0.25)
shape = union(a, b, k=0.25)
```

### smooth difference

<img width=128 align="right" src="docs/images/smooth_difference.png">

```python
shape = a - b.k(0.25)
shape = difference(a, b, k=0.25)
```

### smooth intersection

<img width=128 align="right" src="docs/images/smooth_intersection.png">

```python
shape = a & b.k(0.25)
shape = intersection(a, b, k=0.25)
```

## Repetition

### repeat

<img width=128 align="right" src="docs/images/repeat.png">

```python
from texosdf import *

shape = sphere().repeat(3, (1, 1, 0))
```

### circular_array

<img width=128 align="right" src="docs/images/circular_array.png">

```python
from texosdf import *

shape = capped_cylinder(-Z, Z, 0.5).circular_array(8, 4)
```

## Miscellaneous Operations

### blend

<img width=128 align="right" src="docs/images/blend.png">

```python
from texosdf import *

shape = sphere().blend(box())
```

### dilate

<img width=128 align="right" src="docs/images/dilate.png">

```python
from texosdf import *

shape = sphere().dilate(0.1)
```

### erode

<img width=128 align="right" src="docs/images/erode.png">

```python
from texosdf import *

shape = sphere().erode(0.1)
```

### shell

<img width=128 align="right" src="docs/images/shell.png">

```python
from texosdf import *

shape = sphere().shell(0.05) & plane(-Z)
```

### elongate

<img width=128 align="right" src="docs/images/elongate.png">

```python
from texosdf import *

shape = wireframe_box((1, 1, 1), 0.08).elongate((0.25, 0.5, 0.75))
```

### twist

<img width=128 align="right" src="docs/images/twist.png">

```python
from texosdf import *

shape = box().twist(pi / 2)
```

### bend

<img width=128 align="right" src="docs/images/bend.png">

```python
from texosdf import *

shape = box().bend(1)
```

### bend_linear

<img width=128 align="right" src="docs/images/bend_linear.png">

```python
from texosdf import *

shape = capsule(-Z * 2, Z * 2, 0.25).bend_linear(-Z, Z, X, ease.in_out_quad)
```

### bend_radial

<img width=128 align="right" src="docs/images/bend_radial.png">

```python
from texosdf import *

shape = box((5, 5, 0.25)).bend_radial(1, 2, -1, ease.in_out_quad)
```

### transition_linear

<img width=128 align="right" src="docs/images/transition_linear.png">

```python
from texosdf import *

shape = box().transition_linear(sphere(), e=ease.in_out_quad)
```

### transition_radial

<img width=128 align="right" src="docs/images/transition_radial.png">

```python
from texosdf import *

shape = box().transition_radial(sphere(), e=ease.in_out_quad)
```

### wrap_around

<img width=128 align="right" src="docs/images/wrap_around.png">

```python
from texosdf import *

font = "Arial"
label = " wrap_around " * 3
w, h = measure_text(font, label)
shape = text(font, label).extrude(0.1).orient(Y).wrap_around(-w / 2, w / 2)
```

## 2D To 3D Operations

### extrude

<img width=128 align="right" src="docs/images/extrude.png">

```python
from texosdf import *

shape = hexagon(1).extrude(1)
```

### extrude_to

<img width=128 align="right" src="docs/images/extrude_to.png">

```python
from texosdf import *

shape = rectangle(2).extrude_to(circle(1), 2, ease.in_out_quad)
```

### revolve

<img width=128 align="right" src="docs/images/revolve.png">

```python
from texosdf import *

shape = hexagon(1).revolve(3)
```

## 3D To 2D Operations

### slice

<img width=128 align="right" src="docs/images/slice.png">

```python
from texosdf import *

shape = sphere().translate((0, 0, 0.55)).slice().extrude(0.1)
```

## 2D Primitives

The package also includes these 2D primitives:

- `circle()`
- `line()`
- `rectangle()`
- `rounded_rectangle()`
- `equilateral_triangle()`
- `hexagon()`
- `rounded_x()`
- `polygon()`
- `vesica()`

## Mesh Workflows

The mesh workflow is advanced and optional. It exists for the case where you
already have a triangle mesh and want to bring it into the SDF world so you can
apply shelling, booleans, deformation, or clipping.

```python
from texosdf import *

mesh = Mesh.from_file("input.stl")
shape = mesh.sdf(voxel_size=0.25, half_width=1)
shape = shape.shell(0.5)
shape &= slab(y0=0)
shape.save("out.stl", step=0.25)
```

Notes:

- `Mesh.from_file()` requires `meshio`
- `Mesh.sdf()` requires OpenVDB and `pyopenvdb`
- `pyopenvdb` is intentionally not included in normal package requirements
- mesh-to-SDF conversion is slower and more advanced than working directly with
  analytic SDF primitives

## Writing Your Own SDFs

One of the strongest features of the package is that you can write your own
SDFs when the built-in primitives are not enough.

### Custom 3D primitive

```python
from texosdf import *
import numpy as np

@sdf3
def sphere_like(radius=1, center=ORIGIN):
    center = np.array(center, dtype=float)

    def f(p):
        return np.linalg.norm(p - center, axis=1) - radius

    return f
```

### Custom 3D operation

```python
from texosdf import *

@op3
def translate_z(other, offset):
    def f(p):
        q = p.copy()
        q[:, 2] -= offset
        return other(q)

    return f
```

Conventions for custom SDFs:

- input points are shaped like `(N, 2)` or `(N, 3)`
- the callable returns one distance per input point
- use `@sdf2` or `@sdf3` for primitives
- use `@op2`, `@op3`, `@op23`, or `@op32` for operations on existing SDFs

## Package Layout

Useful namespaces:

- `texosdf.d2` for 2D primitives and operations
- `texosdf.d3` for 3D primitives and operations
- `texosdf.ease` for easing functions

The top-level package re-exports the main public API for convenience.

## Example Scripts

Repository examples:

- [`examples/example.py`](examples/example.py)
- [`examples/text.py`](examples/text.py)
- [`examples/image.py`](examples/image.py)
- [`examples/mesh.py`](examples/mesh.py)
- [`examples/pawn.py`](examples/pawn.py)
- [`examples/weave.py`](examples/weave.py)
- [`examples/gearlike.py`](examples/gearlike.py)
- [`examples/knurling.py`](examples/knurling.py)
- [`examples/blobby.py`](examples/blobby.py)
- [`examples/customizable_box.py`](examples/customizable_box.py)

## Practical Tips

- Start with a coarse `step` while designing models.
- Increase resolution only for final export.
- Prefer explicit `bounds` when automatic bound estimation is unstable.
- Use `show_slice()` early when debugging complex shapes.
- Install optional dependencies only when a workflow actually needs them.

## Original References

The project remains conceptually grounded in the original documentation and
examples from [fogleman/sdf](https://github.com/fogleman/sdf).
