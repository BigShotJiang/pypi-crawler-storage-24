"""CDS-adjusted proxy risk-free helpers."""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal

from .adjusted_cds import adjusted_cds_breakdown


def _to_decimal(value: object) -> Decimal:
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


@dataclass(frozen=True, slots=True)
class RiskFreeProxyBreakdown:
    bond_yield: Decimal
    quoted_cds_spread: Decimal
    adjusted_cds_spread: Decimal
    liquidity_adjustment: Decimal
    funding_adjustment: Decimal
    proxy_risk_free_rate: Decimal


def proxy_risk_free_breakdown(
    *,
    bond_yield: object,
    cds_spread: object,
    delivery_option_adjustment: object = Decimal(0),
    fx_adjustment: object = Decimal(0),
    other_cds_adjustment: object = Decimal(0),
    liquidity_adjustment: object = Decimal(0),
    funding_adjustment: object = Decimal(0),
) -> RiskFreeProxyBreakdown:
    """Infer a CDS-adjusted proxy risk-free rate from a risky bond yield.

    Sign convention:
    - positive CDS adjustments increase quoted CDS above pure default risk
    - positive liquidity or funding adjustments increase the risky bond yield
      above the desired proxy risk-free rate
    """

    bond_yield_value = _to_decimal(bond_yield)
    liquidity = _to_decimal(liquidity_adjustment)
    funding = _to_decimal(funding_adjustment)
    breakdown = adjusted_cds_breakdown(
        quoted_spread=cds_spread,
        delivery_option_adjustment=delivery_option_adjustment,
        fx_adjustment=fx_adjustment,
        other_adjustment=other_cds_adjustment,
    )
    return RiskFreeProxyBreakdown(
        bond_yield=bond_yield_value,
        quoted_cds_spread=breakdown.quoted_spread,
        adjusted_cds_spread=breakdown.adjusted_spread,
        liquidity_adjustment=liquidity,
        funding_adjustment=funding,
        proxy_risk_free_rate=bond_yield_value - breakdown.adjusted_spread - liquidity - funding,
    )


def cds_adjusted_risk_free_rate(
    *,
    bond_yield: object,
    cds_spread: object,
    delivery_option_adjustment: object = Decimal(0),
    fx_adjustment: object = Decimal(0),
    other_cds_adjustment: object = Decimal(0),
    liquidity_adjustment: object = Decimal(0),
    funding_adjustment: object = Decimal(0),
) -> Decimal:
    return proxy_risk_free_breakdown(
        bond_yield=bond_yield,
        cds_spread=cds_spread,
        delivery_option_adjustment=delivery_option_adjustment,
        fx_adjustment=fx_adjustment,
        other_cds_adjustment=other_cds_adjustment,
        liquidity_adjustment=liquidity_adjustment,
        funding_adjustment=funding_adjustment,
    ).proxy_risk_free_rate


__all__ = [
    "RiskFreeProxyBreakdown",
    "cds_adjusted_risk_free_rate",
    "proxy_risk_free_breakdown",
]
