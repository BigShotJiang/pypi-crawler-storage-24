"""Adjusted CDS spread helpers."""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal


def _to_decimal(value: object) -> Decimal:
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


@dataclass(frozen=True, slots=True)
class AdjustedCdsBreakdown:
    quoted_spread: Decimal
    delivery_option_adjustment: Decimal
    fx_adjustment: Decimal
    other_adjustment: Decimal
    adjusted_spread: Decimal


def adjusted_cds_breakdown(
    *,
    quoted_spread: object,
    delivery_option_adjustment: object = Decimal(0),
    fx_adjustment: object = Decimal(0),
    other_adjustment: object = Decimal(0),
) -> AdjustedCdsBreakdown:
    """Strip non-default-risk components out of a quoted CDS spread.

    Sign convention:
    - positive adjustments increase the quoted CDS spread relative to the
      pure default-risk component
    - `adjusted_spread = quoted - delivery_option - fx - other`
    """

    quoted = _to_decimal(quoted_spread)
    delivery = _to_decimal(delivery_option_adjustment)
    fx = _to_decimal(fx_adjustment)
    other = _to_decimal(other_adjustment)
    return AdjustedCdsBreakdown(
        quoted_spread=quoted,
        delivery_option_adjustment=delivery,
        fx_adjustment=fx,
        other_adjustment=other,
        adjusted_spread=quoted - delivery - fx - other,
    )


def adjusted_cds_spread(
    *,
    quoted_spread: object,
    delivery_option_adjustment: object = Decimal(0),
    fx_adjustment: object = Decimal(0),
    other_adjustment: object = Decimal(0),
) -> Decimal:
    return adjusted_cds_breakdown(
        quoted_spread=quoted_spread,
        delivery_option_adjustment=delivery_option_adjustment,
        fx_adjustment=fx_adjustment,
        other_adjustment=other_adjustment,
    ).adjusted_spread


__all__ = [
    "AdjustedCdsBreakdown",
    "adjusted_cds_breakdown",
    "adjusted_cds_spread",
]
