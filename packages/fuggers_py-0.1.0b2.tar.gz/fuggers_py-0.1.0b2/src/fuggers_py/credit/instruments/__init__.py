"""Credit instruments."""

from __future__ import annotations

from .cds import Cds, CdsPremiumPeriod, CreditDefaultSwap, ProtectionSide

__all__ = [
    "Cds",
    "CdsPremiumPeriod",
    "CreditDefaultSwap",
    "ProtectionSide",
]
