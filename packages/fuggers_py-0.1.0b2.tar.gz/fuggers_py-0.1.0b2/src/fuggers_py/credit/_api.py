"""Convenience re-exports for `fuggers_py.credit`."""

from __future__ import annotations

from fuggers_py.data import CdsQuote, CdsQuoteOutput, CdsReferenceData, RvSignalOutput
from .analytics import (
    AdjustedCdsBreakdown,
    BondCdsBasisBreakdown,
    RiskFreeProxyBreakdown,
    adjusted_cds_breakdown,
    adjusted_cds_spread,
    bond_cds_basis,
    bond_cds_basis_breakdown,
    cds_adjusted_risk_free_rate,
    proxy_risk_free_breakdown,
)
from .curves import CdsBootstrapPoint, CdsBootstrapResult, bootstrap_credit_curve
from .instruments import Cds, CreditDefaultSwap, ProtectionSide
from .pricing import CdsPricer, CdsPricingResult

__all__ = [
    "AdjustedCdsBreakdown",
    "BondCdsBasisBreakdown",
    "Cds",
    "CdsBootstrapPoint",
    "CdsBootstrapResult",
    "CdsPricer",
    "CdsPricingResult",
    "CdsQuote",
    "CdsQuoteOutput",
    "CdsReferenceData",
    "CreditDefaultSwap",
    "ProtectionSide",
    "RiskFreeProxyBreakdown",
    "RvSignalOutput",
    "adjusted_cds_breakdown",
    "adjusted_cds_spread",
    "bond_cds_basis",
    "bond_cds_basis_breakdown",
    "bootstrap_credit_curve",
    "cds_adjusted_risk_free_rate",
    "proxy_risk_free_breakdown",
]
