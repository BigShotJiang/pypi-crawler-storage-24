"""Analytics-layer option re-exports."""

from __future__ import annotations

from fuggers_py.bonds.options import BinomialTree, HullWhiteModel, ModelError, ShortRateModel
from fuggers_py.rates.options.pricing import HullWhiteOptionPricer, HullWhiteRateOptionModel, OptionGreeks

HullWhite = HullWhiteModel

from .greeks import add_option_greeks, aggregate_option_greeks, extract_option_greeks, scale_option_greeks
from .rv import OptionRvSignal, implied_minus_realized_volatility, option_rv_signal, vega_notional

__all__ = [
    "BinomialTree",
    "HullWhite",
    "HullWhiteModel",
    "HullWhiteOptionPricer",
    "HullWhiteRateOptionModel",
    "ModelError",
    "OptionGreeks",
    "OptionRvSignal",
    "ShortRateModel",
    "add_option_greeks",
    "aggregate_option_greeks",
    "extract_option_greeks",
    "implied_minus_realized_volatility",
    "option_rv_signal",
    "scale_option_greeks",
    "vega_notional",
]
