"""Secured-versus-unsecured overnight basis helpers."""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Protocol


def _to_decimal(value: object) -> Decimal:
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


class SecuredUnsecuredBasisModel(Protocol):
    def basis(
        self,
        *,
        loss_given_default: object,
        default_probability: object,
        discount_factor: object,
    ) -> Decimal:
        ...


@dataclass(frozen=True, slots=True)
class GQDSecuredUnsecuredBasisModel:
    """Basis approximation `g * q * d`.

    Sign convention:
    - positive values mean unsecured overnight fixes above secured overnight
    - `g` is loss-given-default, `q` is default probability, `d` is discount factor
    """

    def basis(
        self,
        *,
        loss_given_default: object,
        default_probability: object,
        discount_factor: object,
    ) -> Decimal:
        lgd = _to_decimal(loss_given_default)
        default_prob = _to_decimal(default_probability)
        discount = _to_decimal(discount_factor)
        if lgd < Decimal(0) or lgd > Decimal(1):
            raise ValueError("loss_given_default must lie in [0, 1].")
        if default_prob < Decimal(0) or default_prob > Decimal(1):
            raise ValueError("default_probability must lie in [0, 1].")
        if discount < Decimal(0):
            raise ValueError("discount_factor must be non-negative.")
        return lgd * default_prob * discount


def secured_unsecured_overnight_basis(
    *,
    loss_given_default: object,
    default_probability: object,
    discount_factor: object,
    model: SecuredUnsecuredBasisModel | None = None,
) -> Decimal:
    resolved_model = model or GQDSecuredUnsecuredBasisModel()
    return resolved_model.basis(
        loss_given_default=loss_given_default,
        default_probability=default_probability,
        discount_factor=discount_factor,
    )


__all__ = [
    "GQDSecuredUnsecuredBasisModel",
    "SecuredUnsecuredBasisModel",
    "secured_unsecured_overnight_basis",
]
