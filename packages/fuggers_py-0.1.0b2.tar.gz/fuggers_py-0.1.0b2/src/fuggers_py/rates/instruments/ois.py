"""Tradable overnight indexed swaps."""

from __future__ import annotations

from dataclasses import dataclass

from .fixed_float_swap import FixedFloatSwap


@dataclass(frozen=True, slots=True)
class Ois(FixedFloatSwap):
    def __post_init__(self) -> None:
        FixedFloatSwap.__post_init__(self)


OvernightIndexedSwap = Ois


__all__ = ["Ois", "OvernightIndexedSwap"]
