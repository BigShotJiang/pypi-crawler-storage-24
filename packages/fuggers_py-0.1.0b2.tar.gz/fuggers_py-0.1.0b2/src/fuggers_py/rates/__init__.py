"""Rates-domain public API."""

from __future__ import annotations

from . import _api as _api


def __getattr__(name: str) -> object:
    return getattr(_api, name)

__all__ = list(_api.__all__)
