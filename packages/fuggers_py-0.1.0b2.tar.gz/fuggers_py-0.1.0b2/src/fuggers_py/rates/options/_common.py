"""Shared option-domain helpers for rates options."""

from __future__ import annotations

from decimal import Decimal
from enum import Enum


def _to_decimal(value: object) -> Decimal:
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


class OptionType(str, Enum):
    CALL = "CALL"
    PUT = "PUT"

    @classmethod
    def parse(cls, value: "OptionType" | str) -> "OptionType":
        if isinstance(value, cls):
            return value
        normalized = value.strip().upper()
        aliases = {
            "CALL": cls.CALL,
            "C": cls.CALL,
            "PUT": cls.PUT,
            "P": cls.PUT,
        }
        try:
            return aliases[normalized]
        except KeyError as exc:
            raise ValueError(f"Unsupported option type: {value!r}.") from exc

    def sign(self) -> Decimal:
        return Decimal(1) if self is OptionType.CALL else Decimal(-1)


__all__ = ["OptionType"]
