"""Cap/floor product definitions."""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from enum import Enum

from fuggers_py.core.types import Date
from fuggers_py.data.ids import InstrumentId
from fuggers_py.rates.instruments import FloatingLegSpec

from ._common import OptionType, _to_decimal


class CapFloorType(str, Enum):
    CAP = "CAP"
    FLOOR = "FLOOR"

    @classmethod
    def parse(cls, value: "CapFloorType" | str) -> "CapFloorType":
        if isinstance(value, cls):
            return value
        normalized = value.strip().upper()
        aliases = {
            "CAP": cls.CAP,
            "CAPLET_STRIP": cls.CAP,
            "FLOOR": cls.FLOOR,
            "FLOORLET_STRIP": cls.FLOOR,
        }
        try:
            return aliases[normalized]
        except KeyError as exc:
            raise ValueError(f"Unsupported cap/floor type: {value!r}.") from exc

    def option_type(self) -> OptionType:
        return OptionType.CALL if self is CapFloorType.CAP else OptionType.PUT


@dataclass(frozen=True, slots=True)
class CapFloor:
    effective_date: Date
    maturity_date: Date
    floating_leg: FloatingLegSpec
    strike: Decimal
    cap_floor_type: CapFloorType | str = CapFloorType.CAP
    instrument_id: InstrumentId | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "strike", _to_decimal(self.strike))
        object.__setattr__(self, "cap_floor_type", CapFloorType.parse(self.cap_floor_type))
        if self.instrument_id is not None:
            object.__setattr__(self, "instrument_id", InstrumentId.parse(self.instrument_id))
        if self.strike < Decimal(0):
            raise ValueError("CapFloor strike must be non-negative.")
        if self.maturity_date <= self.effective_date:
            raise ValueError("CapFloor requires maturity_date after effective_date.")

    def currency(self):
        return self.floating_leg.currency

    def option_type(self) -> OptionType:
        return self.cap_floor_type.option_type()

    def optionlet_periods(self):
        return self.floating_leg.accrual_periods(self.effective_date, self.maturity_date)


__all__ = ["CapFloor", "CapFloorType"]
