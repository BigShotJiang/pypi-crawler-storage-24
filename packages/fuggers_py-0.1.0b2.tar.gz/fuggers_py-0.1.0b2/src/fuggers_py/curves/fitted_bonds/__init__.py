"""Cross-sectional fitted bond curves and fair-value helpers."""

from __future__ import annotations

from .fair_value import (
    BondFairValueRequest,
    BondFairValueResult,
    clean_price_from_curve,
    dirty_price_from_curve,
    fair_value_from_curve,
    fair_value_from_fit,
)
from .model import (
    CubicSplineDiscountFactorCurve,
    CubicSplineDiscountFactorCurveModel,
    ExponentialSplineCurveModel,
    ExponentialSplineDiscountCurve,
    FittedBondCurveFamily,
    FittedBondCurveModel,
    FittedBondDiagnostics,
    FittedBondFitResult,
    FittedBondObservation,
    FittedBondObjective,
    FittedBondPointResult,
    RegressionCoefficient,
)
from .notional_benchmarks import BenchmarkComponent, NotionalBenchmark, build_notional_benchmark
from .optimization import FittedBondCurveFitter, FittedBondFitConfig
from .regression import (
    RegressionDesignMatrix,
    RegressionExposure,
    build_design_matrix,
    evaluate_regression_adjustment,
    merge_regression_exposures,
    metadata_regression_exposures,
)

__all__ = [
    "BenchmarkComponent",
    "BondFairValueRequest",
    "BondFairValueResult",
    "CubicSplineDiscountFactorCurve",
    "CubicSplineDiscountFactorCurveModel",
    "ExponentialSplineCurveModel",
    "ExponentialSplineDiscountCurve",
    "FittedBondCurveFamily",
    "FittedBondCurveFitter",
    "FittedBondCurveModel",
    "FittedBondDiagnostics",
    "FittedBondFitConfig",
    "FittedBondFitResult",
    "FittedBondObservation",
    "FittedBondObjective",
    "FittedBondPointResult",
    "NotionalBenchmark",
    "RegressionCoefficient",
    "RegressionDesignMatrix",
    "RegressionExposure",
    "build_design_matrix",
    "build_notional_benchmark",
    "clean_price_from_curve",
    "dirty_price_from_curve",
    "evaluate_regression_adjustment",
    "fair_value_from_curve",
    "fair_value_from_fit",
    "merge_regression_exposures",
    "metadata_regression_exposures",
]
