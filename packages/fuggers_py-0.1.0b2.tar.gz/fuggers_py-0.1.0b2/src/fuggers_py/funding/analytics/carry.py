"""Carry helpers for repo trades."""

from __future__ import annotations

from decimal import Decimal

from fuggers_py.funding.instruments import RepoTrade


def _to_decimal(value: object) -> Decimal:
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


def repo_financing_cost(trade: RepoTrade) -> Decimal:
    return trade.interest_amount()


def repo_net_carry(
    trade: RepoTrade,
    *,
    collateral_income: object = Decimal(0),
    haircut_financing_cost: object = Decimal(0),
) -> Decimal:
    return _to_decimal(collateral_income) - trade.interest_amount() - _to_decimal(haircut_financing_cost)


def repo_carry_return(
    trade: RepoTrade,
    *,
    collateral_income: object = Decimal(0),
    haircut_financing_cost: object = Decimal(0),
) -> Decimal:
    cash_lent = trade.cash_lent()
    if cash_lent == Decimal(0):
        raise ValueError("repo_carry_return requires non-zero cash lent.")
    return repo_net_carry(
        trade,
        collateral_income=collateral_income,
        haircut_financing_cost=haircut_financing_cost,
    ) / cash_lent


__all__ = [
    "repo_carry_return",
    "repo_financing_cost",
    "repo_net_carry",
]
