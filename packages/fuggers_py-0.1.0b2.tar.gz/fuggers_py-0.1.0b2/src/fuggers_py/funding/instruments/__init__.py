"""Funding instruments."""

from __future__ import annotations

from .repo import RepoTrade

__all__ = ["RepoTrade"]
