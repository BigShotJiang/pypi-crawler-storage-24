"""Convenience re-exports for `fuggers_py.funding`."""

from __future__ import annotations

from fuggers_py.data import HaircutQuote, RepoQuote, RepoReferenceData
from .analytics import (
    all_in_financing_cost,
    financed_cash,
    futures_invoice_amount,
    haircut_amount,
    haircut_drag,
    haircut_financing_cost,
    implied_repo_rate,
    implied_repo_rate_from_trade,
    is_special,
    repo_carry_return,
    repo_financing_cost,
    repo_net_carry,
    specialness_spread,
    specialness_value,
)
from .curves import RepoCurve
from .instruments import RepoTrade

__all__ = [
    "all_in_financing_cost",
    "financed_cash",
    "futures_invoice_amount",
    "HaircutQuote",
    "haircut_amount",
    "haircut_drag",
    "haircut_financing_cost",
    "implied_repo_rate",
    "implied_repo_rate_from_trade",
    "is_special",
    "RepoCurve",
    "RepoQuote",
    "RepoReferenceData",
    "RepoTrade",
    "repo_carry_return",
    "repo_financing_cost",
    "repo_net_carry",
    "specialness_spread",
    "specialness_value",
]
