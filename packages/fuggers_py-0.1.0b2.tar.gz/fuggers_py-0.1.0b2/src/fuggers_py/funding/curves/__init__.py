"""Funding curves."""

from __future__ import annotations

from .repo_curve import RepoCurve

__all__ = ["RepoCurve"]
