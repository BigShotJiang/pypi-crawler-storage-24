# Credit Docs

`fuggers_py.credit` now provides a small CDS-focused credit stack on top of the
shared data layer and the generic `fuggers_py.curves.CreditCurve` wrapper.

## Current Scope

- `credit.instruments`
  - `CreditDefaultSwap` / `Cds`
  - `ProtectionSide`
- `credit.pricing`
  - `CdsPricer`
  - premium leg, protection leg, accrued-on-default approximation, par spread,
    fair upfront, risky PV01, and CS01
- `credit.curves`
  - `bootstrap_credit_curve`
  - `CdsBootstrapResult` and fitted survival / hazard diagnostics
- `credit.analytics`
  - `adjusted_cds_breakdown` / `adjusted_cds_spread`
  - `bond_cds_basis_breakdown` / `bond_cds_basis`
  - `proxy_risk_free_breakdown` / `cds_adjusted_risk_free_rate`
- shared data records re-exported at the root
  - `CdsQuote`
  - `CdsQuoteOutput`
  - `CdsReferenceData`
  - `RvSignalOutput`

## Notes

- The CDS bootstrap returns a standard `CreditCurve` built from bootstrapped
  survival probabilities. The generic curve wrapper remains owned by
  `fuggers_py.curves`.
- Sign conventions are explicit in code:
  - fair CDS upfront is quoted as the fraction of notional paid by the
    protection buyer
  - bond/CDS basis is positive when the bond spread is wider than adjusted CDS
  - positive delivery-option and FX adjustments are stripped out of quoted
    sovereign CDS when building adjusted spreads
- The sovereign-adjustment helpers are parameterized. Defaults exist, but no
  fixed percentages are embedded in the core logic.
