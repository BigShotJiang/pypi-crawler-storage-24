# Data Docs

`fuggers_py.data` contains research-facing identifiers, records, and provider shapes.
Sprint 0 also uses it as the shared record layer for upcoming `rates`, `funding`, and `credit` roots.

## Modules

- `data.ids`: instrument, curve, node, and portfolio identifiers
- `data.market_data`: quotes, curve inputs, fixings, in-memory providers, and additive repo/swap/futures/FX forward/CDS/haircut quotes
- `data.reference_data`: bond reference records, additive swap/repo/futures/CDS reference records, deliverable-bond placeholders, and reference providers
- `data.pricing_specs`: pricing directives, configuration records, and expanded analytics-curve bundles
- `data.output`: typed pricing and analytics output records, including additive swap/future/CDS/RV outputs
- `data.errors`: data-layer exceptions

## Example

```python
from decimal import Decimal

from fuggers_py.bonds.types import ASWType
from fuggers_py.core import Date
from fuggers_py.data import CurveInputs, CurvePoint, PricingSpec, RepoQuote, SwapQuote

curve_inputs = CurveInputs.from_points(
    "usd.discount",
    Date.from_ymd(2026, 1, 15),
    [CurvePoint(Decimal("1.0"), Decimal("0.0350")), CurvePoint(Decimal("5.0"), Decimal("0.0385"))],
)
spec = PricingSpec(include_asset_swap=True, asset_swap_type=ASWType.PROCEEDS)
repo_quote = RepoQuote(instrument_id="repo-usd-1w", rate=Decimal("0.0410"))
swap_quote = SwapQuote(instrument_id="usd-swap-5y", rate=Decimal("0.0380"))
```

## Guidance

- Use `data` for typed records and providers.
- `PricingSpec` uses lower-layer shared enums such as `fuggers_py.bonds.types.ASWType` rather than importing analytics modules.
- `AnalyticsCurves` now carries optional repo, collateral, FX-forward, multicurve, projection-curve, and vol-surface handles without changing existing discount/forward workflows.
- `BondReferenceData` now carries optional local-RV metadata such as `amount_outstanding`, `issue_date`, `benchmark_flag`, `futures_deliverable_flags`, and `liquidity_score` for fitted-curve and benchmark workflows.
- `BondFutureReferenceData` now also carries optional delivery-window and standard-coupon metadata, and `BondFutureContractReference` aliases that widened contract record for the rates-futures domain.
- `DeliverableBondReference` is the placeholder reference record for deliverable bonds in the government bond futures basket.
- The `rates`, `funding`, and `credit` roots stay thin over these shared records where appropriate; provider responsibilities still remain conservative.
- Prefer explicit exception names such as `TraitTimeoutError`, `TraitIOError`, and `PermissionDeniedError`.
- Keep storage and transport concerns in `fuggers_py.io`.
