# Funding Docs

`fuggers_py.funding` is the domain-first funding and repo layer.

## Current Scope

- `RepoTrade` as the core repo instrument
- `RepoCurve` as a lightweight funding-curve wrapper
- carry, implied-repo, specialness, and haircut-financing helpers
- `RepoQuote`, `HaircutQuote`, and `RepoReferenceData` shared data records

## Notes

- The layer stays domain-first: funding analytics depend on funding instruments and curves rather than on a bond-futures product class.
- `FundingPricingRouter` lives in `fuggers_py.engine` so the domain package does not depend upward on engine code.
