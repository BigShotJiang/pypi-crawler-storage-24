# Changelog

## 0.1.0b2

Second beta cut focused on the expanded relative-value and cross-asset fixed-income stack, plus release engineering cleanup ahead of publication.

### Added

- expanded relative-value analytics across local RV, global RV, workflow hooks, and richer desk-style comparisons
- `funding`: repo trades, repo curves, implied repo, specialness, haircuts, and a dedicated funding pricing router
- `rates`: tradable IRS, OIS, FRAs, basis swaps, asset swaps, cross-currency basis swaps, and rates risk helpers
- government bond futures tooling covering contracts, deliverable baskets, conversion factors, CTD selection, invoice, basis, delivery-option models, and OABPV
- fitted-bond curve fitting, fair-value outputs, benchmark generation, bond switches, butterflies, and constant-maturity analytics
- `credit`: first-class CDS products, bootstrap, pricing, adjusted CDS helpers, bond/CDS basis, and proxy risk-free analytics
- options support for swaptions, cap/floors, futures options, Greeks, options RV, overlays, and optional advanced curve-model integrations

### Changed

- release engineering now tracks the current top-level package surface in the source-coverage policy
- supported local release builds are documented explicitly around `python -m build` and `pip wheel` from a normal git checkout
- packaging regression coverage now checks that build outputs, installed wheel metadata, installed sdist metadata, and `fuggers_py.__version__` stay aligned on supported local build paths

## 0.1.0

Initial release-focused cut of the Python analytics port.

### Added

- `core`: dates, prices, yields, spreads, calendars, day counts, and abstract curve/pricing/risk traits
- `math`: solvers, interpolation, extrapolation, optimization, and linear algebra helpers
- `curves`: discrete/wrapped curves, builders, calibration helpers, bumping, and multi-curve support
- `bonds`: fixed-rate, zero-coupon, callable/putable, floating-rate, sinking-fund, index/fixing, and option-model workflows
- `analytics`: yield, risk, spread, OAS, discount-margin, asset-swap, and YAS calculations
- `portfolio`: holdings, ETF helpers, aggregation, stress, benchmark, credit, and key-rate tooling
- `data`: typed ids, market/reference data, pricing specs, outputs, and in-memory research providers
- `io`: file-backed providers, JSON codecs, SQLite-backed embedded storage, and storage/transport interfaces
- `engine`: sync pricing router, batch pricing, curve builder, calculation graph, schedulers, market-data listener, builder, and reactive orchestration
- deterministic examples, golden validations, benchmark harness, and release smoke coverage

### Scope

- This package targets Python analytics and research orchestration workflows.
- Deterministic local adapters and notebook-friendly APIs are first-class.
- Server runtimes, WASM, FFI bindings, MCP surfaces, and distributed service infrastructure remain out of scope for this release.

### Changed

- historical compatibility namespaces such as `fuggers_py.prelude`, `fuggers_py.traits`, and `fuggers_py.ext` are removed from the current public surface
- removed the redundant top-level `fuggers_py.spreads` namespace
- `fuggers_py.analytics.spreads` is the canonical spread namespace
