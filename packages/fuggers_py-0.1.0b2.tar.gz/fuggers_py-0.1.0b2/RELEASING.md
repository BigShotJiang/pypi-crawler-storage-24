# Releasing

`fuggers-py` uses `setuptools_scm`, so supported release builds must be run from a normal git checkout (or tag checkout) with `.git` metadata present.

Do not cut release artifacts from an exported/copied source tree that no longer has SCM metadata attached. In that case `setuptools_scm` falls back to the configured development version, which is fine for scratch snapshots but not a publishing path.

## Private beta from a local wheel

```bash
python -m build
python -m pip wheel . --no-deps -w /tmp/fuggers-pip-wheel-check
python -m venv /tmp/fuggers-beta-venv
/tmp/fuggers-beta-venv/bin/pip install --upgrade pip
/tmp/fuggers-beta-venv/bin/pip install dist/fuggers_py-*.whl
/tmp/fuggers-beta-venv/bin/python -c "import fuggers_py; print(fuggers_py.__version__)"
```

Both `python -m build` and `python -m pip wheel . --no-deps -w <dir>` are supported from a normal git checkout and should produce the same version metadata. Share the wheel in `dist/` for private testers, or install it directly the same way on their machines.

## One-time PyPI Trusted Publisher setup

1. Make the GitHub repository public.
2. In the PyPI project settings for `fuggers-py`, add a GitHub Trusted Publisher with:
   - owner: `stanislawkubik`
   - repository: `fuggers-py`
   - workflow file: `release.yml`
3. Leave the GitHub environment field empty. The workflow does not use one.

## First public release

1. Ensure `main` is ready and CI is green.
2. Push the release tag:

```bash
git tag v0.1.0
git push origin v0.1.0
```

3. GitHub Actions runs `release.yml`, builds the distributions, smoke-tests them, and publishes to PyPI.

`setuptools_scm` maps the Git tag `v0.1.0` to the package version `0.1.0`.

## Subsequent releases

1. Update `CHANGELOG.md` as needed.
2. Push the next tag, for example:

```bash
git tag v0.1.1
git push origin v0.1.1
```

No packaging-file edits should be required for later releases.
