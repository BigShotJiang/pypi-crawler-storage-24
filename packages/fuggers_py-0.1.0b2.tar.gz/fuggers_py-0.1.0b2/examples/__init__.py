"""Structured research notebooks and shared example helpers."""
