"""Shared helpers for the structured examples catalog."""

from .datasets import build_foundation_bond, foundation_calendar_scenarios, foundation_coupon_period_context
from .formatting import as_bps, as_percent, date_label, to_float
from .plotting import apply_research_style, percent_axis
from .tables import display_table

__all__ = [
    "apply_research_style",
    "as_bps",
    "as_percent",
    "build_foundation_bond",
    "date_label",
    "display_table",
    "foundation_calendar_scenarios",
    "foundation_coupon_period_context",
    "percent_axis",
    "to_float",
]
