"""Formatting helpers for notebook tables and charts."""

from __future__ import annotations

from decimal import Decimal

from fuggers_py.core import Date


def to_float(value: object) -> float:
    """Convert Decimal-like values used in the library into a plotting-friendly float."""

    if isinstance(value, float):
        return value
    if isinstance(value, int):
        return float(value)
    if isinstance(value, Decimal):
        return float(value)
    return float(value)


def date_label(date: Date) -> str:
    """Return an ISO-like label for a core Date."""

    return str(date)


def as_percent(value: object) -> float:
    """Convert a decimal rate into percentage points."""

    return 100.0 * to_float(value)


def as_bps(value: object) -> float:
    """Convert a decimal rate into basis points."""

    return 10000.0 * to_float(value)
