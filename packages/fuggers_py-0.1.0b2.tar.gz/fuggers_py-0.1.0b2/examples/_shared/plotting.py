"""Minimal chart styling for research notebooks."""

from __future__ import annotations

import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter


def apply_research_style() -> None:
    """Apply a clean, deterministic plotting style."""

    plt.rcParams.update(
        {
            "axes.grid": True,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.facecolor": "#fbfbf8",
            "figure.facecolor": "white",
            "grid.alpha": 0.25,
            "grid.linestyle": "--",
            "axes.titlesize": 12,
            "axes.labelsize": 10,
            "legend.frameon": False,
            "font.size": 10,
            "figure.figsize": (10, 5),
        }
    )


def percent_axis(axis: plt.Axes, digits: int = 2) -> None:
    """Format the y-axis in percentage points."""

    axis.yaxis.set_major_formatter(FuncFormatter(lambda value, _: f"{value:.{digits}f}%"))
