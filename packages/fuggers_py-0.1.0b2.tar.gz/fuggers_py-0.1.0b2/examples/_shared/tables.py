"""Tabular display helpers for notebooks."""

from __future__ import annotations

from collections.abc import Iterable

import pandas as pd

from .formatting import as_bps, as_percent, date_label, to_float


def display_table(
    frame: pd.DataFrame,
    *,
    date_columns: Iterable[str] = (),
    percent_columns: Iterable[str] = (),
    bps_columns: Iterable[str] = (),
    float_columns: Iterable[str] = (),
    digits: int = 3,
) -> pd.DataFrame:
    """Return a notebook-friendly copy of a table with formatted values."""

    display = frame.copy()

    for column in date_columns:
        display[column] = display[column].map(date_label)

    for column in percent_columns:
        display[column] = display[column].map(
            lambda value: "" if value is None else f"{as_percent(value):.{digits}f}%"
        )

    for column in bps_columns:
        display[column] = display[column].map(
            lambda value: "" if value is None else f"{as_bps(value):.{digits}f}"
        )

    for column in float_columns:
        display[column] = display[column].map(
            lambda value: "" if value is None else round(to_float(value), digits)
        )

    return display
