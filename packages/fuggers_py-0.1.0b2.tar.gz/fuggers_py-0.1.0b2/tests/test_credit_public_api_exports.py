from __future__ import annotations

from fuggers_py.credit import (
    CdsPricer,
    CdsQuote,
    CdsQuoteOutput,
    CdsReferenceData,
    CreditDefaultSwap,
    RvSignalOutput,
    adjusted_cds_spread,
    bond_cds_basis,
    bootstrap_credit_curve,
    cds_adjusted_risk_free_rate,
)
from fuggers_py.credit.analytics import adjusted_cds_spread as analytics_adjusted_cds_spread
from fuggers_py.credit.analytics import bond_cds_basis as analytics_bond_cds_basis
from fuggers_py.credit.analytics import cds_adjusted_risk_free_rate as analytics_cds_adjusted_risk_free_rate
from fuggers_py.credit.curves import bootstrap_credit_curve as curves_bootstrap_credit_curve
from fuggers_py.credit.instruments import CreditDefaultSwap as instruments_credit_default_swap
from fuggers_py.credit.pricing import CdsPricer as pricing_cds_pricer
from fuggers_py.data import CdsQuote as data_cds_quote
from fuggers_py.data import CdsQuoteOutput as data_cds_quote_output
from fuggers_py.data import CdsReferenceData as data_cds_reference_data
from fuggers_py.data import RvSignalOutput as data_rv_signal_output


def test_credit_root_exports_scaffold_records() -> None:
    assert CdsQuote is data_cds_quote
    assert CdsQuoteOutput is data_cds_quote_output
    assert CdsReferenceData is data_cds_reference_data
    assert RvSignalOutput is data_rv_signal_output
    assert CreditDefaultSwap is instruments_credit_default_swap
    assert CdsPricer is pricing_cds_pricer
    assert bootstrap_credit_curve is curves_bootstrap_credit_curve
    assert adjusted_cds_spread is analytics_adjusted_cds_spread
    assert bond_cds_basis is analytics_bond_cds_basis
    assert cds_adjusted_risk_free_rate is analytics_cds_adjusted_risk_free_rate
