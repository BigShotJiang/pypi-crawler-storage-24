from __future__ import annotations

from importlib import metadata

import fuggers_py
import fuggers_py.analytics
import fuggers_py.bonds
import fuggers_py.core
import fuggers_py.credit
import fuggers_py.curves
import fuggers_py.data
import fuggers_py.engine
import fuggers_py.funding
import fuggers_py.io
import fuggers_py.math
import fuggers_py.portfolio
import fuggers_py.rates


def main() -> None:
    version = fuggers_py.__version__
    assert version
    assert any(char.isdigit() for char in version)
    assert metadata.version("fuggers-py") == version
    print(version)


if __name__ == "__main__":
    main()
