# -*- coding: utf-8 -*-
"""DeconWork 会话持久化（按会话 ID 保存与恢复）。"""

from __future__ import annotations

import json
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage


def _now_ts() -> int:
    """当前时间戳（秒）。"""
    return int(time.time())


def generate_session_id() -> str:
    """生成新的会话 ID。"""
    return f"s_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"


def _conversations_dir(runtime_dir: Path) -> Path:
    """会话目录。"""
    out = runtime_dir / "conversations"
    out.mkdir(parents=True, exist_ok=True)
    return out


def _index_path(runtime_dir: Path) -> Path:
    """索引文件路径。"""
    return _conversations_dir(runtime_dir) / "index.json"


def _session_path(runtime_dir: Path, session_id: str) -> Path:
    """单会话文件路径。"""
    sid = str(session_id or "").strip()
    return _conversations_dir(runtime_dir) / f"{sid}.json"


def _safe_content(value: Any) -> str:
    """将消息 content 规整为可持久化文本。"""
    if isinstance(value, str):
        return value
    try:
        return json.dumps(value, ensure_ascii=False)
    except Exception:
        return str(value)


def _serialize_messages(messages: List[Any]) -> List[Dict[str, Any]]:
    """序列化消息列表。"""
    serialized: List[Dict[str, Any]] = []
    for msg in messages or []:
        msg_type = str(getattr(msg, "type", "") or "").strip().lower()
        if not msg_type:
            if isinstance(msg, HumanMessage):
                msg_type = "human"
            elif isinstance(msg, AIMessage):
                msg_type = "ai"
            elif isinstance(msg, SystemMessage):
                msg_type = "system"
            else:
                msg_type = "unknown"

        serialized.append(
            {
                "type": msg_type,
                "content": _safe_content(getattr(msg, "content", "")),
            }
        )
    return serialized


def _deserialize_messages(items: List[Dict[str, Any]]) -> List[Any]:
    """反序列化消息列表。"""
    out: List[Any] = []
    for item in items or []:
        msg_type = str((item or {}).get("type", "") or "").strip().lower()
        content = str((item or {}).get("content", "") or "")
        if msg_type == "human":
            out.append(HumanMessage(content=content))
        elif msg_type == "ai":
            out.append(AIMessage(content=content))
        elif msg_type == "system":
            out.append(SystemMessage(content=content))
        else:
            # 对未知类型降级为 HumanMessage，避免恢复失败
            out.append(HumanMessage(content=content))
    return out


def _read_json(path: Path) -> Dict[str, Any]:
    """读取 JSON 文件。"""
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_json(path: Path, payload: Dict[str, Any]) -> None:
    """写入 JSON 文件。"""
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def _upsert_index(
    runtime_dir: Path,
    *,
    session_id: str,
    message_count: int,
    updated_at: int,
) -> None:
    """写入/更新会话索引。"""
    path = _index_path(runtime_dir)
    payload = _read_json(path)
    sessions = payload.get("sessions", [])
    if not isinstance(sessions, list):
        sessions = []

    found = False
    for item in sessions:
        if str(item.get("session_id", "")).strip() == session_id:
            item["message_count"] = int(message_count)
            item["updated_at"] = int(updated_at)
            found = True
            break

    if not found:
        sessions.append(
            {
                "session_id": session_id,
                "created_at": int(updated_at),
                "updated_at": int(updated_at),
                "message_count": int(message_count),
            }
        )

    sessions = sorted(
        sessions,
        key=lambda x: int(x.get("updated_at", 0) or 0),
        reverse=True,
    )[:500]
    payload["sessions"] = sessions
    _write_json(path, payload)


def save_session_from_agent(agent: Any, runtime_dir: Path, session_id: str) -> Dict[str, Any]:
    """从 agent 当前线程状态保存会话。"""
    sid = str(session_id or "").strip()
    if not sid:
        return {}

    state_values = agent.get_context(sid) or {}
    messages = list(state_values.get("messages", []) or [])
    serialized = _serialize_messages(messages)
    now = _now_ts()

    payload = {
        "session_id": sid,
        "updated_at": now,
        "message_count": len(serialized),
        "messages": serialized,
    }
    _write_json(_session_path(runtime_dir, sid), payload)
    _upsert_index(
        runtime_dir,
        session_id=sid,
        message_count=len(serialized),
        updated_at=now,
    )
    return {
        "session_id": sid,
        "message_count": len(serialized),
        "updated_at": now,
    }


def list_sessions(runtime_dir: Path, limit: int = 20) -> List[Dict[str, Any]]:
    """列出最近会话。"""
    payload = _read_json(_index_path(runtime_dir))
    sessions = payload.get("sessions", [])
    if not isinstance(sessions, list):
        return []
    sessions = sorted(
        sessions,
        key=lambda x: int(x.get("updated_at", 0) or 0),
        reverse=True,
    )
    return sessions[: max(1, int(limit))]


def restore_session_to_agent(agent: Any, runtime_dir: Path, session_id: str) -> Dict[str, Any]:
    """将会话内容恢复到当前进程 agent 中。"""
    sid = str(session_id or "").strip()
    if not sid:
        return {"ok": False, "error": "session_id 不能为空"}

    payload = _read_json(_session_path(runtime_dir, sid))
    if not payload:
        return {"ok": False, "error": f"未找到会话: {sid}"}

    raw_messages = payload.get("messages", [])
    if not isinstance(raw_messages, list):
        return {"ok": False, "error": f"会话格式损坏: {sid}"}

    messages = _deserialize_messages(raw_messages)
    if not messages:
        return {"ok": False, "error": f"会话为空: {sid}"}

    # 恢复 messages 到指定 thread_id
    agent.app.update_state(
        {"configurable": {"thread_id": sid}},
        {"messages": messages},
    )
    return {
        "ok": True,
        "session_id": sid,
        "message_count": len(messages),
    }
