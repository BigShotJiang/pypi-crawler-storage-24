# -*- coding: utf-8 -*-
"""DeconWork 运行时共享状态定义。"""

from __future__ import annotations

import threading
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class RuntimeState:
    """运行时共享状态。"""

    heartbeat_enabled: bool = True
    heartbeat_interval_seconds: int = 300
    heartbeat_lock_policy: str = "skip_if_busy"  # skip_if_busy | wait
    stop_event: threading.Event = field(default_factory=threading.Event)
    execution_lock: threading.Lock = field(default_factory=threading.Lock)
    print_lock: threading.Lock = field(default_factory=threading.Lock)
    user_thread_id: str = field(default_factory=lambda: f"user_{uuid.uuid4().hex[:8]}")
    heartbeat_thread_id: str = "heartbeat_main"
    round_count: int = 0
    total_tokens: int = 0
    rules_path: Path = Path()
    memory_path: Path = Path()
    heartbeat_path: Path = Path()


def safe_print(state: RuntimeState, *args: Any, **kwargs: Any) -> None:
    """带锁打印，降低多线程输出交错。"""
    with state.print_lock:
        print(*args, **kwargs, flush=True)
