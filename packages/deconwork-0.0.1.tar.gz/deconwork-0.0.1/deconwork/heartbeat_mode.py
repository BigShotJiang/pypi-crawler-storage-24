# -*- coding: utf-8 -*-
"""DeconWork 心跳模式逻辑。"""

from __future__ import annotations

import time
from pathlib import Path
from typing import Any, Callable, Dict

from .runtime_state import RuntimeState


def _read_heartbeat_text(state: RuntimeState, safe_print: Callable[..., None]) -> str:
    """读取心跳文件内容。"""
    path = Path(state.heartbeat_path)
    if not path.exists():
        safe_print(state, f"[HB] 心跳文件不存在: {path}")
        return ""
    try:
        return path.read_text(encoding="utf-8").strip()
    except Exception as exc:
        safe_print(state, f"[HB] 读取心跳文件失败: {exc}")
        return ""


def build_heartbeat_task(heartbeat_text: str) -> str:
    """构造心跳任务文本。"""
    now = time.strftime("%Y-%m-%d %H:%M:%S")
    return (
        f"[Heartbeat Trigger @ {now}]\n"
        "请根据以下心跳指令自动执行必要任务。若内容为空或不明确，请给出最小澄清建议。\n\n"
        "<heartbeat>\n"
        f"{heartbeat_text}\n"
        "</heartbeat>"
    )


def trigger_heartbeat_once(
    agent: Any,
    state: RuntimeState,
    run_react_task: Callable[..., Dict[str, Any]],
    safe_print: Callable[..., None],
) -> None:
    """执行一次心跳触发。"""
    heartbeat_text = _read_heartbeat_text(state, safe_print)
    if not heartbeat_text:
        return

    task = build_heartbeat_task(heartbeat_text)
    safe_print(state, f"[HB] 触发心跳任务: {state.heartbeat_path}")
    run_react_task(
        agent=agent,
        state=state,
        source="heartbeat",
        task=task,
        thread_id=state.heartbeat_thread_id,
        heartbeat_text=heartbeat_text,
    )


def heartbeat_loop(
    agent: Any,
    state: RuntimeState,
    trigger_once: Callable[[], None],
) -> None:
    """心跳线程循环。"""
    next_tick = time.time() + max(1, state.heartbeat_interval_seconds)
    while not state.stop_event.is_set():
        if state.stop_event.wait(0.5):
            break
        if not state.heartbeat_enabled:
            continue
        now = time.time()
        if now < next_tick:
            continue
        trigger_once()
        next_tick = now + max(1, state.heartbeat_interval_seconds)
