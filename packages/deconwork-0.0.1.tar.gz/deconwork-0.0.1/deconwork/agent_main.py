﻿# -*- coding: utf-8 -*-
"""DeconWork Agent 主逻辑。

本模块负责三件事：
1. 构建 Agent 与模型；
2. 运行主进程终端对话循环（支持 /new、/sessions、/resume）；
3. 运行独立 heartbeat 进程。
"""

from __future__ import annotations

import os
import stat
from pathlib import Path
from typing import Any, Dict

from klynx import create_agent, setup_model
from klynx.agent.tools.web_search import is_tavily_configured

from .config_manager import resolve_api_key_for_model, runtime_dir as config_runtime_dir
from .context_compressor import build_runtime_context_append
from .conversation_store import (
    generate_session_id,
    list_sessions,
    restore_session_to_agent,
    save_session_from_agent,
)
from .heartbeat_mode import heartbeat_loop, trigger_heartbeat_once
from .runtime_state import RuntimeState, safe_print

DEFAULT_MAX_ITERATIONS = 200
TRUTHY_VALUES = {"1", "true", "yes", "on", "y"}
FALSY_VALUES = {"0", "false", "no", "off", "n"}


def _read_text_file(path: Path, state: RuntimeState, label: str) -> str:
    """读取 UTF-8 文本；读取失败时返回空字符串。"""
    if not path.exists():
        return ""
    try:
        return path.read_text(encoding="utf-8").strip()
    except Exception as exc:
        safe_print(state, f"[SYS] 读取 {label} 失败: {exc}")
        return ""


def _build_system_prompt_append(
    state: RuntimeState,
    source: str,
    heartbeat_text: str = "",
) -> str:
    """构建运行时附加上下文（带预算压缩）。"""
    rules_text = _read_text_file(state.rules_path, state, "rules.md")
    memory_text = _read_text_file(state.memory_path, state, "memory.md")

    budget_raw = (os.getenv("DECONWORK_APPEND_MAX_TOKENS", "2400") or "2400").strip()
    try:
        budget = max(900, int(budget_raw))
    except Exception:
        budget = 2400

    runtime_append = build_runtime_context_append(
        source=source,
        rules_text=rules_text,
        memory_text=memory_text,
        heartbeat_text=heartbeat_text,
        total_budget_tokens=budget,
    )
    runtime_file_notes = _build_runtime_file_notes(state)
    if runtime_file_notes:
        runtime_append = f"{runtime_file_notes}\n\n{runtime_append}".strip()

    # 软约束：需求不明确时先澄清，不做多轮盲目试错。
    if source == "user":
        clarify_guide = (
            "<deconwork_clarify_policy>\n"
            "- 当用户目标不明确、信息不足或输入像命令缩写时，先用 1~2 句提问澄清。\n"
            "- 澄清前不要连续尝试多条命令或大范围搜索。\n"
            "- 若输入形如 `/xxx` 且含义不明，先确认是 CLI 命令还是任务请求。\n"
            "</deconwork_clarify_policy>"
        )
        return f"{clarify_guide}\n\n{runtime_append}".strip()

    return runtime_append


def _build_runtime_file_notes(state: RuntimeState) -> str:
    """构建运行时关键文件能力说明，显式告知路径、用途与可写性。"""
    write_permissions = _resolve_file_write_permissions()
    records = [
        {
            "name": "rules.md",
            "path": str(state.rules_path),
            "purpose": "规定 Agent 行为约束与执行边界。",
            "write_allowed": bool(write_permissions.get("rules", True)),
            "env_key": "DECONWORK_ALLOW_WRITE_RULES_FILE",
        },
        {
            "name": "memory.md",
            "path": str(state.memory_path),
            "purpose": "记录长期记忆、用户偏好与持续性事实。",
            "write_allowed": bool(write_permissions.get("memory", True)),
            "env_key": "DECONWORK_ALLOW_WRITE_MEMORY_FILE",
        },
        {
            "name": "heartbeat.md",
            "path": str(state.heartbeat_path),
            "purpose": "心跳进程每次触发时读取，作为自动化任务输入。",
            "write_allowed": bool(write_permissions.get("heartbeat", True)),
            "env_key": "DECONWORK_ALLOW_WRITE_HEARTBEAT_FILE",
        },
    ]

    lines = [
        "<deconwork_runtime_files>",
        f"- heartbeat_enabled: {str(bool(state.heartbeat_enabled)).lower()}",
        f"- heartbeat_interval_seconds: {int(state.heartbeat_interval_seconds)}",
        f"- heartbeat_lock_policy: {state.heartbeat_lock_policy}",
        "- 关键文件能力如下（路径与权限以本块为准）：",
    ]

    for item in records:
        writable = str(bool(item["write_allowed"])).lower()
        if bool(item["write_allowed"]):
            action_rule = "允许修改；可通过 read_file + apply_patch 或 write_to_file 更新。"
        else:
            action_rule = "禁止修改（只读）；如需变更需先征求用户。"
        lines.append(
            f"- {item['name']}: path={item['path']} | purpose={item['purpose']} | "
            f"write_allowed={writable} ({item['env_key']}) | {action_rule}"
        )

    lines.extend(
        [
            "- 修改关键文件时：必须先读取现状，再执行最小改动，并以 tool_result 确认成功。",
            "- 不得声称已修改，除非工具结果明确成功。",
            "</deconwork_runtime_files>",
        ]
    )
    return "\n".join(lines).strip()


def _resolve_max_iterations() -> int:
    """解析单轮任务最大迭代次数，默认 200。"""
    raw = (os.getenv("DECONWORK_MAX_ITERATIONS", str(DEFAULT_MAX_ITERATIONS)) or "").strip()
    try:
        value = int(raw)
    except Exception:
        value = DEFAULT_MAX_ITERATIONS
    return max(1, value)


def _resolve_permission_mode() -> str:
    """解析权限模式，仅允许 workspace/global。"""
    raw = (os.getenv("DECONWORK_PERMISSION_MODE", "global") or "").strip().lower()
    if raw in {"workspace", "sandbox"}:
        return "workspace"
    if raw in {"global", "full"}:
        return "global"
    return "global"


def _resolve_allow_shell_commands() -> bool:
    """解析是否允许 execute_command。"""
    raw = (os.getenv("DECONWORK_ALLOW_SHELL_COMMANDS", "true") or "").strip().lower()
    if raw in TRUTHY_VALUES:
        return True
    if raw in FALSY_VALUES:
        return False
    return True


def _resolve_bool_env(env_key: str, default: bool = True) -> bool:
    """解析布尔环境变量。"""
    default_text = "true" if default else "false"
    raw = (os.getenv(env_key, default_text) or "").strip().lower()
    if raw in TRUTHY_VALUES:
        return True
    if raw in FALSY_VALUES:
        return False
    return default


def _resolve_agent_working_dir(install_dir: Path) -> Path:
    """解析 Agent 工作目录（默认安装目录，可通过环境变量覆盖）。"""
    raw = (os.getenv("DECONWORK_WORKING_DIR", "") or "").strip()
    if raw:
        candidate = Path(raw).expanduser()
        if not candidate.is_absolute():
            candidate = (install_dir / candidate).resolve()
        else:
            candidate = candidate.resolve()
    else:
        candidate = install_dir.resolve()

    if candidate.exists() and (not candidate.is_dir()):
        raise ValueError(f"DECONWORK_WORKING_DIR 不是目录: {candidate}")

    candidate.mkdir(parents=True, exist_ok=True)
    return candidate


def _resolve_file_write_permissions() -> Dict[str, bool]:
    """解析 rules/memory/heartbeat 三个文件的写入权限。"""
    return {
        "rules": _resolve_bool_env("DECONWORK_ALLOW_WRITE_RULES_FILE", default=True),
        "memory": _resolve_bool_env("DECONWORK_ALLOW_WRITE_MEMORY_FILE", default=True),
        "heartbeat": _resolve_bool_env("DECONWORK_ALLOW_WRITE_HEARTBEAT_FILE", default=True),
    }


def _resolve_web_search_available() -> bool:
    """判断当前环境是否可启用 Tavily 联网搜索。"""
    try:
        return bool(is_tavily_configured())
    except Exception:
        return False


def _try_enable_web_search(agent: Any) -> bool:
    """在检测到 Tavily Key 时自动加载 web_search 工具。"""
    if not _resolve_web_search_available():
        return False
    try:
        agent.add_tools("web_search")
        return True
    except Exception as exc:
        # 失败时不阻断主流程，仅给出可见告警，避免“看似有 key 但工具不可用”。
        print(f"[SYS] 检测到 TAVILY_API_KEY，但加载 web_search 失败: {exc}")
        return False


def _build_write_guard_targets(state: RuntimeState) -> Dict[str, Path]:
    """返回需要受保护的关键文件路径。"""
    return {
        "rules": state.rules_path,
        "memory": state.memory_path,
        "heartbeat": state.heartbeat_path,
    }


def _apply_file_write_guard(state: RuntimeState) -> list[Dict[str, Any]]:
    """对禁止写入的关键文件加只读保护，并记录快照用于回滚。"""
    permissions = _resolve_file_write_permissions()
    targets = _build_write_guard_targets(state)
    snapshots: list[Dict[str, Any]] = []

    for key, path in targets.items():
        allow_write = bool(permissions.get(key, True))
        if allow_write:
            continue

        resolved = Path(path).resolve()
        existed = resolved.exists()
        original_mode = int(resolved.stat().st_mode) if existed else 0
        original_text = ""
        if existed:
            try:
                original_text = resolved.read_text(encoding="utf-8")
            except Exception:
                original_text = ""

        if existed:
            # 临时去掉写位，优先阻止写入动作发生。
            try:
                readonly_mode = original_mode & ~stat.S_IWUSR & ~stat.S_IWGRP & ~stat.S_IWOTH
                resolved.chmod(readonly_mode)
            except Exception:
                pass

        snapshots.append(
            {
                "key": key,
                "path": resolved,
                "existed": existed,
                "original_mode": original_mode,
                "original_text": original_text,
            }
        )
    return snapshots


def _restore_file_write_guard(state: RuntimeState, snapshots: list[Dict[str, Any]]) -> None:
    """恢复关键文件权限，并在发生越权写入时回滚文件内容。"""
    for snapshot in snapshots:
        key = str(snapshot.get("key", "") or "")
        path = Path(snapshot.get("path"))
        existed = bool(snapshot.get("existed", False))
        original_mode = int(snapshot.get("original_mode", 0) or 0)
        original_text = str(snapshot.get("original_text", "") or "")

        # 先恢复权限，便于后续可能的内容回滚。
        if path.exists() and original_mode:
            try:
                path.chmod(original_mode)
            except Exception:
                pass

        changed = False
        try:
            if existed:
                if not path.exists():
                    path.parent.mkdir(parents=True, exist_ok=True)
                    path.write_text(original_text, encoding="utf-8")
                    changed = True
                else:
                    current_text = path.read_text(encoding="utf-8")
                    if current_text != original_text:
                        path.write_text(original_text, encoding="utf-8")
                        changed = True
            else:
                if path.exists() and path.is_file():
                    path.unlink()
                    changed = True
        except Exception as exc:
            safe_print(state, f"[Permission] 恢复受保护文件失败: {path} ({exc})")
            continue

        if changed:
            safe_print(state, f"[Permission] 已回滚受保护文件写入: {key} -> {path}")


def _build_agent(working_dir: str) -> Any:
    """按当前环境配置创建 Klynx Agent。"""
    provider = (os.getenv("DECONWORK_MODEL_PROVIDER") or "moonshot").strip()
    model_name = (os.getenv("DECONWORK_MODEL_NAME") or "kimi-k2.5").strip()
    api_base = (os.getenv("DECONWORK_API_BASE") or "https://api.moonshot.cn/v1").strip()
    permission_mode = _resolve_permission_mode()
    allow_shell_commands = _resolve_allow_shell_commands()

    api_key, env_keys, _ = resolve_api_key_for_model(model_name, provider_hint=provider)
    if not api_key:
        expected = " / ".join(env_keys) if env_keys else "对应模型的 API_KEY"
        raise ValueError(f"缺少 API Key，请先配置：{expected}")

    model = setup_model(provider, model_name, api_key, api_base=api_base)
    max_iterations = _resolve_max_iterations()
    agent = create_agent(
        working_dir=working_dir,
        model=model,
        max_iterations=max_iterations,
        memory_dir=working_dir,
        load_project_docs=False,
        permission_mode=permission_mode,
        allow_shell_commands=allow_shell_commands,
    )

    # 如果存在 MCP 配置，则自动挂载。
    mcp_config = Path(working_dir) / ".klynx" / "mcp_servers.json"
    if mcp_config.exists():
        agent.add_mcp(str(mcp_config))

    web_search_enabled = _try_enable_web_search(agent)
    setattr(agent, "_deconwork_web_search_enabled", bool(web_search_enabled))

    return agent


def run_react_task(
    agent: Any,
    state: RuntimeState,
    source: str,
    task: str,
    thread_id: str,
    heartbeat_text: str = "",
) -> Dict[str, Any]:
    """统一 ReAct 调用入口。

    用户任务与 heartbeat 任务共用同一执行函数。
    heartbeat 在 `skip_if_busy` 策略下会尝试非阻塞加锁，忙时直接跳过。
    """
    if source == "heartbeat" and state.heartbeat_lock_policy == "skip_if_busy":
        if not state.execution_lock.acquire(blocking=False):
            safe_print(state, "[HB] 当前有任务执行，跳过本次心跳。")
            return {}
    else:
        state.execution_lock.acquire()

    guard_snapshots: list[Dict[str, Any]] = []
    try:
        guard_snapshots = _apply_file_write_guard(state)
        append_text = _build_system_prompt_append(state, source, heartbeat_text)
        return agent.run_terminal_agent_stream(
            task=task,
            thread_id=thread_id,
            system_prompt_append=append_text,
        )
    finally:
        _restore_file_write_guard(state, guard_snapshots)
        state.execution_lock.release()


def _get_agent_permission(agent: Any) -> tuple[str, bool]:
    """读取 Agent 当前权限信息。"""
    getter = getattr(agent, "get_permission", None)
    if callable(getter):
        info = getter() or {}
        mode = str(info.get("mode", "") or _resolve_permission_mode())
        allow_shell = bool(info.get("allow_shell_commands", _resolve_allow_shell_commands()))
        return mode, allow_shell
    return _resolve_permission_mode(), _resolve_allow_shell_commands()


def _print_status(agent: Any, state: RuntimeState) -> None:
    """打印主进程状态摘要。"""
    context = agent.get_context(state.user_thread_id) or {}
    msg_count = len(context.get("messages", []) or [])
    mode, allow_shell = _get_agent_permission(agent)
    write_permissions = _resolve_file_write_permissions()
    web_search_enabled = bool(getattr(agent, "_deconwork_web_search_enabled", False))
    tavily_ready = _resolve_web_search_available()
    working_dir = str(getattr(agent, "working_dir", "") or "")

    safe_print(state, "\n[SYS] 当前状态:")
    safe_print(state, f"  - 当前会话: {state.user_thread_id}")
    safe_print(state, f"  - 工作目录: {working_dir}")
    safe_print(state, f"  - 权限模式: {mode}")
    safe_print(state, f"  - 允许命令执行: {allow_shell}")
    safe_print(
        state,
        "  - 关键文件可写: "
        f"rules={write_permissions['rules']}, "
        f"memory={write_permissions['memory']}, "
        f"heartbeat={write_permissions['heartbeat']}",
    )
    safe_print(state, f"  - Tavily Key 已配置: {tavily_ready}")
    safe_print(state, f"  - 联网搜索工具(web_search): {web_search_enabled}")
    safe_print(state, "  - 心跳进程: 使用 `DeconWork heartbeat` 独立运行")
    safe_print(state, f"  - 心跳配置: enabled={state.heartbeat_enabled}")
    safe_print(state, f"  - 心跳间隔: {state.heartbeat_interval_seconds}s")
    safe_print(state, f"  - 锁策略: {state.heartbeat_lock_policy}")
    safe_print(state, f"  - 统计: rounds={state.round_count}, tokens={state.total_tokens}")
    safe_print(state, f"  - 上下文消息数: {msg_count}\n")


def _print_sessions(state: RuntimeState, runtime_root: Path, limit: int = 20) -> None:
    """打印最近会话列表。"""
    sessions = list_sessions(runtime_root, limit=limit)
    if not sessions:
        safe_print(state, "[SYS] 暂无已保存会话。")
        return

    safe_print(state, "[SYS] 最近会话：")
    for item in sessions:
        sid = str(item.get("session_id", "") or "")
        msg_count = int(item.get("message_count", 0) or 0)
        updated_at = int(item.get("updated_at", 0) or 0)
        safe_print(state, f"  - {sid} | messages={msg_count} | updated_at={updated_at}")


def conversation_loop(agent: Any, state: RuntimeState, runtime_root: Path) -> None:
    """终端对话循环（主进程）。"""
    safe_print(
        state,
        "\n[SYS] 命令: /new | /resume <session_id> | /sessions | /status | /clear | /quit",
    )
    safe_print(state, f"[SYS] 当前会话: {state.user_thread_id}")

    while not state.stop_event.is_set():
        try:
            user_input = input(f"[USER][{state.round_count + 1}] > ").strip()
        except (EOFError, KeyboardInterrupt):
            state.stop_event.set()
            break

        if not user_input:
            continue

        lowered = user_input.lower()
        if lowered in {"/quit", "/exit", "q"}:
            state.stop_event.set()
            safe_print(state, "[SYS] 收到退出指令。")
            break

        if lowered in {"/new", "/clear"}:
            state.user_thread_id = generate_session_id()
            safe_print(state, f"[SYS] 已创建新会话: {state.user_thread_id}")
            continue

        if lowered == "/sessions":
            _print_sessions(state, runtime_root)
            continue

        if lowered.startswith("/resume"):
            parts = user_input.split(maxsplit=1)
            if len(parts) == 1:
                _print_sessions(state, runtime_root)
                safe_print(state, "[SYS] 用法: /resume <session_id>")
                continue

            target_session = parts[1].strip()
            result = restore_session_to_agent(agent, runtime_root, target_session)
            if bool(result.get("ok", False)):
                state.user_thread_id = target_session
                safe_print(
                    state,
                    f"[SYS] 会话已恢复: {target_session} "
                    f"(messages={result.get('message_count', 0)})",
                )
            else:
                safe_print(state, f"[SYS] 恢复失败: {result.get('error', 'unknown error')}")
            continue

        if lowered == "/status":
            _print_status(agent, state)
            continue

        # 默认按用户任务执行，并在每轮后持久化会话。
        result = run_react_task(
            agent=agent,
            state=state,
            source="user",
            task=user_input,
            thread_id=state.user_thread_id,
        )
        state.round_count += 1
        state.total_tokens += int(result.get("total_tokens", 0) or 0)
        save_session_from_agent(agent, runtime_root, state.user_thread_id)


def _build_runtime_state() -> RuntimeState:
    """从环境变量构建运行时状态对象。"""
    enabled = (os.getenv("DECONWORK_HEARTBEAT_ENABLED", "true") or "").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }
    interval_raw = (os.getenv("DECONWORK_HEARTBEAT_INTERVAL", "300") or "300").strip()
    lock_policy = (os.getenv("DECONWORK_HEARTBEAT_LOCK_POLICY", "skip_if_busy") or "").strip().lower()
    if lock_policy not in {"skip_if_busy", "wait"}:
        lock_policy = "skip_if_busy"

    try:
        interval_seconds = max(1, int(interval_raw))
    except Exception:
        interval_seconds = 300

    return RuntimeState(
        heartbeat_enabled=enabled,
        heartbeat_interval_seconds=interval_seconds,
        heartbeat_lock_policy=lock_policy,
        rules_path=Path(os.environ["DECONWORK_RULES_FILE"]).resolve(),
        memory_path=Path(os.environ["DECONWORK_MEMORY_FILE"]).resolve(),
        heartbeat_path=Path(os.environ["DECONWORK_HEARTBEAT_FILE"]).resolve(),
    )


def run_agent_main(install_dir: Path) -> int:
    """运行主进程（终端对话）。"""
    state = _build_runtime_state()
    runtime_root = config_runtime_dir(install_dir)
    runtime_root.mkdir(parents=True, exist_ok=True)
    state.user_thread_id = generate_session_id()
    write_permissions = _resolve_file_write_permissions()
    tavily_ready = _resolve_web_search_available()
    try:
        agent_working_dir = _resolve_agent_working_dir(install_dir)
    except Exception as exc:
        print(f"[SYS] 工作目录配置无效: {exc}")
        return 2

    print("=" * 60)
    print("DeconWork Agent（主进程：终端对话 + ReAct）")
    print(f"安装目录: {install_dir}")
    print(f"工作目录: {agent_working_dir}")
    print(f"规则文件: {state.rules_path}")
    print(f"记忆文件: {state.memory_path}")
    print(f"心跳文件: {state.heartbeat_path}")
    print(f"单轮最大循环: {_resolve_max_iterations()}")
    print(f"权限模式: {_resolve_permission_mode()}")
    print(f"允许命令执行: {_resolve_allow_shell_commands()}")
    print(f"Tavily Key 已配置: {tavily_ready}")
    print(
        "关键文件可写: "
        f"rules={write_permissions['rules']}, "
        f"memory={write_permissions['memory']}, "
        f"heartbeat={write_permissions['heartbeat']}"
    )
    print("心跳模式: 请另开终端执行 `DeconWork heartbeat`")
    print("=" * 60)

    try:
        agent = _build_agent(str(agent_working_dir))
    except Exception as exc:
        print(f"[SYS] Agent 初始化失败: {exc}")
        return 2

    # 在主线程运行对话循环，确保 Ctrl+C 能直接中断当前交互/任务流。
    try:
        conversation_loop(agent, state, runtime_root)
    except KeyboardInterrupt:
        state.stop_event.set()
        cancel_event = getattr(agent, "_cancel_event", None)
        if cancel_event is not None:
            try:
                cancel_event.set()
            except Exception:
                pass
        print("\n[SYS] 收到 Ctrl+C，中断当前运行。")
    finally:
        state.stop_event.set()

    print("\n[SYS] 程序已退出。")
    print(f"[SYS] 统计: rounds={state.round_count}, total_tokens={state.total_tokens}")
    return 0


def run_heartbeat_main(install_dir: Path, once: bool = False) -> int:
    """运行独立 heartbeat 进程。"""
    state = _build_runtime_state()
    state.heartbeat_enabled = True
    write_permissions = _resolve_file_write_permissions()
    tavily_ready = _resolve_web_search_available()
    try:
        agent_working_dir = _resolve_agent_working_dir(install_dir)
    except Exception as exc:
        print(f"[SYS] 工作目录配置无效: {exc}")
        return 2

    print("=" * 60)
    print("DeconWork Heartbeat（独立进程）")
    print(f"安装目录: {install_dir}")
    print(f"工作目录: {agent_working_dir}")
    print(f"心跳文件: {state.heartbeat_path}")
    print(f"心跳间隔: {state.heartbeat_interval_seconds}s")
    print(f"单轮最大循环: {_resolve_max_iterations()}")
    print(f"权限模式: {_resolve_permission_mode()}")
    print(f"允许命令执行: {_resolve_allow_shell_commands()}")
    print(f"Tavily Key 已配置: {tavily_ready}")
    print(
        "关键文件可写: "
        f"rules={write_permissions['rules']}, "
        f"memory={write_permissions['memory']}, "
        f"heartbeat={write_permissions['heartbeat']}"
    )
    print("=" * 60)

    try:
        agent = _build_agent(str(agent_working_dir))
    except Exception as exc:
        print(f"[SYS] Heartbeat Agent 初始化失败: {exc}")
        return 2

    if once:
        trigger_heartbeat_once(agent, state, run_react_task, safe_print)
        return 0

    try:
        heartbeat_loop(
            agent,
            state,
            lambda: trigger_heartbeat_once(agent, state, run_react_task, safe_print),
        )
    except KeyboardInterrupt:
        state.stop_event.set()
        print("\n[SYS] Heartbeat 收到退出信号。")
    return 0
