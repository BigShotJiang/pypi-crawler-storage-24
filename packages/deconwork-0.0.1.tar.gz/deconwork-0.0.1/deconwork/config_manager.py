﻿# -*- coding: utf-8 -*-
"""DeconWork 配置管理与模型配置向导。"""

from __future__ import annotations

import argparse
import getpass
import os
from pathlib import Path
from typing import Dict, List, Tuple

from dotenv import load_dotenv


ENV_FILE_NAME = "deconwork.env"
RUNTIME_DIR_NAME = "deconwork_runtime"
WORKING_DIR_ENV_KEY = "DECONWORK_WORKING_DIR"
PATH_ENV_DEFAULT_FILE = {
    "DECONWORK_RULES_FILE": "rules.md",
    "DECONWORK_MEMORY_FILE": "memory.md",
    "DECONWORK_HEARTBEAT_FILE": "heartbeat.md",
}
WRITE_GUARD_ENV_KEYS = {
    "DECONWORK_ALLOW_WRITE_RULES_FILE": "true",
    "DECONWORK_ALLOW_WRITE_MEMORY_FILE": "true",
    "DECONWORK_ALLOW_WRITE_HEARTBEAT_FILE": "true",
}
PERMISSION_MODES = {"workspace", "global"}
TRUTHY_VALUES = {"1", "true", "yes", "on", "y"}
FALSY_VALUES = {"0", "false", "no", "off", "n"}
SENSITIVE_KEY_HINTS = ("KEY", "TOKEN", "SECRET", "PASSWORD")
_MODEL_REGISTRY_CACHE: Dict[str, Dict[str, object]] | None = None

PROVIDER_API_KEY_ENV = {
    "openai": "OPENAI_API_KEY",
    "deepseek": "DEEPSEEK_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",
    "gemini": "GEMINI_API_KEY",
    "dashscope": "DASHSCOPE_API_KEY",
    "minimax": "MINIMAX_API_KEY",
    "zhipuai": "GLM_API_KEY",
}


def model_registry() -> Dict[str, Dict[str, object]]:
    """懒加载 klynx 模型注册表，避免非模型命令触发 LiteLLM 初始化。"""
    global _MODEL_REGISTRY_CACHE
    if _MODEL_REGISTRY_CACHE is None:
        from klynx.model.registry import MODEL_REGISTRY as REGISTRY  # 延迟导入

        _MODEL_REGISTRY_CACHE = dict(REGISTRY)
    return _MODEL_REGISTRY_CACHE


def install_dir() -> Path:
    """返回 DeconWork 安装目录（当前模块所在目录）。"""
    return Path(__file__).resolve().parent


def env_file_path(target_dir: Path) -> Path:
    """返回安装目录下 env 配置文件路径。"""
    return target_dir / ENV_FILE_NAME


def runtime_dir(target_dir: Path) -> Path:
    """返回安装目录下 runtime 目录路径。"""
    return target_dir / RUNTIME_DIR_NAME


def read_env_file(path: Path) -> Dict[str, str]:
    """读取简单 KEY=VALUE env 文件。"""
    data: Dict[str, str] = {}
    if not path.exists():
        return data
    for line in path.read_text(encoding="utf-8").splitlines():
        text = line.strip()
        if not text or text.startswith("#") or "=" not in text:
            continue
        key, value = text.split("=", 1)
        data[key.strip()] = value.strip().strip("'").strip('"')
    return data


def write_env_file(path: Path, data: Dict[str, str]) -> None:
    """写回 env 文件。"""
    lines = [
        "# DeconWork 配置文件（由 CLI 维护）",
        "# 受管路径会自动规范化：rules/memory/heartbeat 固定到安装目录，working_dir 可自定义",
    ]
    for key in sorted(data.keys()):
        lines.append(f"{key}={data[key]}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def normalize_managed_path(env_key: str, raw_value: str, target_dir: Path) -> str:
    """规范路径变量到安装目录。"""
    out_dir = runtime_dir(target_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    default_filename = PATH_ENV_DEFAULT_FILE[env_key]
    filename = Path(raw_value).name if raw_value else default_filename
    if not filename:
        filename = default_filename
    return str((out_dir / filename).resolve())


def normalize_working_dir(raw_value: str, target_dir: Path) -> str:
    """规范工作目录路径（支持绝对路径和相对安装目录路径）。"""
    text = str(raw_value or "").strip()
    if not text:
        return str(target_dir.resolve())

    candidate = Path(text).expanduser()
    if not candidate.is_absolute():
        candidate = (target_dir / candidate).resolve()
    else:
        candidate = candidate.resolve()
    return str(candidate)


def default_env_map(target_dir: Path) -> Dict[str, str]:
    """生成默认配置。"""
    defaults = {
        WORKING_DIR_ENV_KEY: normalize_working_dir("", target_dir),
        "DECONWORK_HEARTBEAT_ENABLED": "true",
        "DECONWORK_HEARTBEAT_INTERVAL": "300",
        "DECONWORK_HEARTBEAT_LOCK_POLICY": "skip_if_busy",
        "DECONWORK_MAX_ITERATIONS": "200",
        "DECONWORK_PERMISSION_MODE": "global",
        "DECONWORK_ALLOW_SHELL_COMMANDS": "true",
        "DECONWORK_MODEL_PROVIDER": "moonshot",
        "DECONWORK_MODEL_NAME": "kimi-k2.5",
        "DECONWORK_API_BASE": "https://api.moonshot.cn/v1",
        "LITELLM_LOCAL_MODEL_COST_MAP": "true",
        "LITELLM_LOCAL_ANTHROPIC_BETA_HEADERS": "true",
        "KLYNX_STREAM_SHOW_REASONING": "false",
        "KLYNX_STREAM_FLUSH_INTERVAL_S": "0.05",
        "KLYNX_STREAM_FLUSH_CHARS": "64",
    }
    defaults.update(WRITE_GUARD_ENV_KEYS)
    for key in PATH_ENV_DEFAULT_FILE:
        defaults[key] = normalize_managed_path(key, "", target_dir)
    return defaults


def extract_provider_from_route(route: str) -> str:
    """从 liteLLM 路由字符串提取 provider。"""
    text = str(route or "").strip()
    if "/" in text:
        return text.split("/", 1)[0].strip().lower()
    return text.lower()


def get_model_env_keys(model_alias: str, provider: str = "") -> List[str]:
    """获取模型对应的 API key 环境变量候选列表。"""
    config = model_registry().get(model_alias, {})
    env_keys = config.get("env_key")
    if isinstance(env_keys, list):
        keys = [str(item).strip() for item in env_keys if str(item or "").strip()]
    elif env_keys:
        keys = [str(env_keys).strip()]
    else:
        keys = []

    if keys:
        return keys
    provider_env = PROVIDER_API_KEY_ENV.get(str(provider or "").strip().lower(), "")
    return [provider_env] if provider_env else []


def list_model_aliases() -> List[str]:
    """返回可选模型别名列表。"""
    return sorted(model_registry().keys())


def normalize_permission_mode(raw_mode: str) -> str:
    """规范权限模式，仅允许 workspace/global。"""
    mode = str(raw_mode or "").strip().lower()
    if mode in {"workspace", "sandbox"}:
        return "workspace"
    if mode in {"global", "full"}:
        return "global"
    return "global"


def normalize_bool_env_value(raw_value: str, default: bool = True) -> str:
    """将布尔值规范为 true/false 字符串。"""
    text = str(raw_value or "").strip().lower()
    if text in TRUTHY_VALUES:
        return "true"
    if text in FALSY_VALUES:
        return "false"
    return "true" if default else "false"


def merge_and_normalize_env(target_dir: Path, file_data: Dict[str, str]) -> Dict[str, str]:
    """合并默认值并做路径规范化。"""
    merged = default_env_map(target_dir)
    merged.update(file_data)
    merged[WORKING_DIR_ENV_KEY] = normalize_working_dir(
        merged.get(WORKING_DIR_ENV_KEY, ""),
        target_dir,
    )
    for key in PATH_ENV_DEFAULT_FILE:
        merged[key] = normalize_managed_path(key, merged.get(key, ""), target_dir)

    lock_policy = (merged.get("DECONWORK_HEARTBEAT_LOCK_POLICY", "") or "").strip().lower()
    if lock_policy not in {"skip_if_busy", "wait"}:
        merged["DECONWORK_HEARTBEAT_LOCK_POLICY"] = "skip_if_busy"

    merged["DECONWORK_PERMISSION_MODE"] = normalize_permission_mode(
        merged.get("DECONWORK_PERMISSION_MODE", "global")
    )
    merged["DECONWORK_ALLOW_SHELL_COMMANDS"] = normalize_bool_env_value(
        merged.get("DECONWORK_ALLOW_SHELL_COMMANDS", "true"),
        default=True,
    )
    for key, default_value in WRITE_GUARD_ENV_KEYS.items():
        merged[key] = normalize_bool_env_value(merged.get(key, default_value), default=True)
    return merged


def env_file_needs_backfill(file_data: Dict[str, str], merged: Dict[str, str]) -> bool:
    """判断配置文件是否缺失/不一致，需要回写补齐。"""
    if len(file_data) != len(merged):
        return True
    for key, value in merged.items():
        if str(file_data.get(key, "")) != str(value):
            return True
    return False


def ensure_runtime_files(env_map: Dict[str, str]) -> None:
    """确保 rules/memory/heartbeat 文件存在。"""
    working_dir = Path(str(env_map.get(WORKING_DIR_ENV_KEY, "") or "").strip() or ".")
    rules_path = Path(env_map["DECONWORK_RULES_FILE"])
    memory_path = Path(env_map["DECONWORK_MEMORY_FILE"])
    heartbeat_path = Path(env_map["DECONWORK_HEARTBEAT_FILE"])

    working_dir.mkdir(parents=True, exist_ok=True)
    rules_path.parent.mkdir(parents=True, exist_ok=True)
    if not rules_path.exists():
        rules_path.write_text(
            "# DeconWork Rules\n\n## Mission\n- 在用户授权范围内执行任务。\n",
            encoding="utf-8",
        )
    if not memory_path.exists():
        memory_path.write_text(
            "# DeconWork Memory\n\n## User Preferences\n- \n",
            encoding="utf-8",
        )
    if not heartbeat_path.exists():
        heartbeat_path.write_text(
            "# Heartbeat Task\n\n- 每次心跳时检查待办并执行可自动化任务。\n",
            encoding="utf-8",
        )


def load_install_env(target_dir: Path) -> Dict[str, str]:
    """加载并标准化安装目录配置。"""
    env_file = env_file_path(target_dir)

    if env_file.exists():
        # 存在配置文件时优先加载；仅在检测到缺失键/无效值时回写一次补齐。
        file_data = read_env_file(env_file)
        merged = merge_and_normalize_env(target_dir, file_data)
        if env_file_needs_backfill(file_data, merged):
            write_env_file(env_file, merged)
    else:
        # 仅首次运行（配置文件不存在）时写入默认配置。
        merged = merge_and_normalize_env(target_dir, {})
        write_env_file(env_file, merged)

    for key, value in merged.items():
        os.environ[key] = value

    # 允许用户在安装目录 .env 中放置 API key。
    load_dotenv(dotenv_path=target_dir / ".env", override=False)
    return merged


def resolve_api_key_for_model(model_name: str, provider_hint: str = "") -> tuple[str, List[str], str]:
    """根据模型别名解析 API key。"""
    model_config = model_registry().get(model_name, {})
    route_model = str(model_config.get("model", "") or "")
    route_provider = extract_provider_from_route(route_model) or str(provider_hint).lower()
    env_keys = get_model_env_keys(model_name, route_provider)

    for key in env_keys:
        value = (os.getenv(key) or "").strip()
        if value:
            return value, env_keys, route_provider

    for key in ("KIMI_API_KEY", "MOONSHOT_API_KEY"):
        value = (os.getenv(key) or "").strip()
        if value:
            return value, env_keys, route_provider

    return "", env_keys, route_provider


def is_model_ready(env_map: Dict[str, str]) -> Tuple[bool, str]:
    """判断当前配置是否可直接启动模型。"""
    model_name = str(env_map.get("DECONWORK_MODEL_NAME", "") or "").strip()
    provider = str(env_map.get("DECONWORK_MODEL_PROVIDER", "") or "").strip()
    if not model_name:
        return False, "未配置 DECONWORK_MODEL_NAME。"
    if model_name not in model_registry():
        return False, f"模型别名无效: {model_name}"

    api_key, env_keys, _ = resolve_api_key_for_model(model_name, provider_hint=provider)
    if api_key:
        return True, ""

    expected = " / ".join(env_keys) if env_keys else "对应模型 API key"
    return False, f"模型 {model_name} 缺少 API key（{expected}）。"


def _mask_if_sensitive(key: str, value: str, raw: bool) -> str:
    """按需掩码敏感值。"""
    if raw:
        return value
    upper_key = key.upper()
    if any(hint in upper_key for hint in SENSITIVE_KEY_HINTS):
        if not value:
            return ""
        return value[:6] + "..."
    return value


def _print_model_options() -> None:
    """打印可选模型列表。"""
    registry = model_registry()
    aliases = list_model_aliases()
    if not aliases:
        print("未发现可选模型。")
        return

    print("可选模型：")
    print("-" * 100)
    print("序号 | 别名 | 描述 | API Key 变量")
    print("-" * 100)
    for idx, alias in enumerate(aliases, start=1):
        cfg = registry.get(alias, {})
        desc = str(cfg.get("description", "") or "")
        route = str(cfg.get("model", "") or "")
        provider = extract_provider_from_route(route)
        env_keys = get_model_env_keys(alias, provider)
        env_text = " / ".join(env_keys) if env_keys else "-"
        print(f"{idx:>2} | {alias:<20} | {desc:<24} | {env_text}")
    print("-" * 100)


def _prompt_yes_no(question: str, default_yes: bool = True) -> bool:
    """读取 y/n 输入。"""
    suffix = "[Y/n]" if default_yes else "[y/N]"
    raw = input(f"{question} {suffix} > ").strip().lower()
    if not raw:
        return default_yes
    return raw in {"y", "yes"}


def _select_model_alias_interactive() -> str:
    """交互式选择模型别名。"""
    registry = model_registry()
    aliases = list_model_aliases()
    _print_model_options()
    while True:
        raw = input("请输入模型序号或模型别名 > ").strip()
        if not raw:
            continue
        if raw.isdigit():
            idx = int(raw)
            if 1 <= idx <= len(aliases):
                return aliases[idx - 1]
        if raw in registry:
            return raw
        print("输入无效，请重新输入。")


def _select_api_key_env_interactive(env_keys: List[str]) -> str:
    """在多个 API key 变量中交互选择一个。"""
    if not env_keys:
        return ""
    if len(env_keys) == 1:
        return env_keys[0]

    print("该模型支持多个 API key 变量，请选择写入目标：")
    for idx, key in enumerate(env_keys, start=1):
        print(f"{idx}. {key}")
    while True:
        raw = input("请输入序号（默认 1）> ").strip()
        if not raw:
            return env_keys[0]
        if raw.isdigit():
            idx = int(raw)
            if 1 <= idx <= len(env_keys):
                return env_keys[idx - 1]
        print("输入无效，请重新输入。")


def config_model(
    *,
    list_only: bool = False,
    select: str = "",
    api_key: str = "",
    api_key_env: str = "",
    no_prompt_key: bool = False,
) -> int:
    """模型配置向导。"""
    if list_only:
        _print_model_options()
        return 0

    target_dir = install_dir()
    env_file = env_file_path(target_dir)
    file_data = read_env_file(env_file)
    merged = merge_and_normalize_env(target_dir, file_data)

    alias = str(select or "").strip()
    if not alias:
        alias = _select_model_alias_interactive()
    registry = model_registry()
    if alias not in registry:
        print(f"未知模型别名: {alias}")
        return 2

    cfg = registry[alias]
    route = str(cfg.get("model", "") or "")
    provider = extract_provider_from_route(route) or str(
        merged.get("DECONWORK_MODEL_PROVIDER", "moonshot")
    )

    merged["DECONWORK_MODEL_PROVIDER"] = provider
    merged["DECONWORK_MODEL_NAME"] = alias

    default_kwargs = cfg.get("default_kwargs", {}) or {}
    api_base = str(default_kwargs.get("api_base", "") or "").strip()
    if api_base:
        merged["DECONWORK_API_BASE"] = api_base

    env_keys = get_model_env_keys(alias, provider)
    existing_key = any((merged.get(key) or os.getenv(key) or "").strip() for key in env_keys)
    target_key = str(api_key_env or "").strip()
    if not target_key and env_keys:
        target_key = env_keys[0]

    input_api_key = str(api_key or "").strip()
    if input_api_key:
        if not target_key:
            target_key = input("请输入 API key 变量名（例如 OPENAI_API_KEY）> ").strip()
        if not target_key:
            print("未提供 API key 变量名，无法保存。")
            return 2
        merged[target_key] = input_api_key
        existing_key = True
    elif (not existing_key) and (not no_prompt_key):
        if env_keys:
            need_input = _prompt_yes_no(
                f"当前模型未检测到 API key（{ ' / '.join(env_keys) }），现在输入吗？",
                default_yes=True,
            )
            if need_input:
                if len(env_keys) > 1 and (not api_key_env):
                    target_key = _select_api_key_env_interactive(env_keys)
                secret = getpass.getpass(f"请输入 {target_key} > ").strip()
                if secret:
                    merged[target_key] = secret
                    existing_key = True
        else:
            need_input = _prompt_yes_no("当前模型未提供默认 API key 变量，手动输入吗？", default_yes=False)
            if need_input:
                target_key = input("请输入 API key 变量名 > ").strip()
                if target_key:
                    secret = getpass.getpass(f"请输入 {target_key} > ").strip()
                    if secret:
                        merged[target_key] = secret
                        existing_key = True

    merged = merge_and_normalize_env(target_dir, merged)
    write_env_file(env_file, merged)
    ensure_runtime_files(merged)

    print("模型配置已更新：")
    print(f"  - DECONWORK_MODEL_PROVIDER={merged.get('DECONWORK_MODEL_PROVIDER', '')}")
    print(f"  - DECONWORK_MODEL_NAME={merged.get('DECONWORK_MODEL_NAME', '')}")
    print(f"  - DECONWORK_API_BASE={merged.get('DECONWORK_API_BASE', '')}")
    if env_keys:
        print(f"  - API key 变量候选: {' / '.join(env_keys)}")
    if not existing_key:
        print("  - 警告: 当前仍未检测到 API key，运行时会初始化失败。")
    return 0


def config_show() -> int:
    """显示当前配置。"""
    target_dir = install_dir()
    env_file = env_file_path(target_dir)
    env_map = load_install_env(target_dir)

    print(f"安装目录: {target_dir}")
    print(f"配置文件: {env_file}")
    print("-" * 60)
    for key in sorted(env_map.keys()):
        value = env_map[key]
        value = _mask_if_sensitive(key, value, raw=False)
        print(f"{key}={value}")
    return 0


def config_init() -> int:
    """初始化配置文件和 runtime 文件。"""
    target_dir = install_dir()
    env_map = load_install_env(target_dir)
    ensure_runtime_files(env_map)
    print(f"已初始化: {env_file_path(target_dir)}")
    print(f"runtime目录: {runtime_dir(target_dir)}")
    return 0


def config_set(key: str, value: str) -> int:
    """设置配置项。"""
    target_dir = install_dir()
    env_file = env_file_path(target_dir)
    file_data = read_env_file(env_file)
    merged = merge_and_normalize_env(target_dir, file_data)

    key = (key or "").strip()
    value = (value or "").strip()
    if not key:
        print("key 不能为空。")
        return 2

    if key == WORKING_DIR_ENV_KEY:
        merged[key] = normalize_working_dir(value, target_dir)
    elif key in PATH_ENV_DEFAULT_FILE:
        merged[key] = normalize_managed_path(key, value, target_dir)
    else:
        merged[key] = value

    merged = merge_and_normalize_env(target_dir, merged)
    write_env_file(env_file, merged)
    ensure_runtime_files(merged)
    print(f"已写入: {key}={merged.get(key, '')}")
    return 0


def config_env_path() -> int:
    """显示 deconwork.env 路径。"""
    target_dir = install_dir()
    env_map = load_install_env(target_dir)
    ensure_runtime_files(env_map)
    print(env_file_path(target_dir))
    return 0


def config_env_show(raw: bool = False) -> int:
    """显示 deconwork.env 当前内容。"""
    target_dir = install_dir()
    env_map = load_install_env(target_dir)
    ensure_runtime_files(env_map)
    env_file = env_file_path(target_dir)
    file_data = read_env_file(env_file)

    print(f"配置文件: {env_file}")
    print("-" * 60)
    for key in sorted(file_data.keys()):
        value = _mask_if_sensitive(key, str(file_data[key]), raw=raw)
        print(f"{key}={value}")
    return 0


def config_env_set(key: str, value: str) -> int:
    """修改 deconwork.env 单个键值。"""
    return config_set(key, value)


def config_env_unset(key: str) -> int:
    """删除 deconwork.env 中单个键。"""
    target_dir = install_dir()
    env_file = env_file_path(target_dir)
    file_data = read_env_file(env_file)
    merged = merge_and_normalize_env(target_dir, file_data)

    key = (key or "").strip()
    if not key:
        print("key 不能为空。")
        return 2

    if key not in merged:
        print(f"未找到键: {key}")
        return 2

    # 删除后会重新 merge 默认值；默认项会自动回填，自定义项会被真正移除。
    merged.pop(key, None)
    merged = merge_and_normalize_env(target_dir, merged)
    write_env_file(env_file, merged)
    ensure_runtime_files(merged)
    print(f"已删除: {key}")
    return 0


def config_permission(
    mode: str = "",
    sandbox: str = "",
    allow_shell: str = "",
    write_rules: str = "",
    write_memory: str = "",
    write_heartbeat: str = "",
) -> int:
    """配置权限模式与沙箱开关。"""
    target_dir = install_dir()
    env_file = env_file_path(target_dir)
    file_data = read_env_file(env_file)
    merged = merge_and_normalize_env(target_dir, file_data)

    changed = False
    mode = str(mode or "").strip().lower()
    sandbox = str(sandbox or "").strip().lower()
    allow_shell = str(allow_shell or "").strip().lower()
    write_rules = str(write_rules or "").strip().lower()
    write_memory = str(write_memory or "").strip().lower()
    write_heartbeat = str(write_heartbeat or "").strip().lower()

    if sandbox:
        mode = "workspace" if sandbox == "on" else "global"

    if mode:
        merged["DECONWORK_PERMISSION_MODE"] = normalize_permission_mode(mode)
        changed = True

    if allow_shell:
        merged["DECONWORK_ALLOW_SHELL_COMMANDS"] = normalize_bool_env_value(allow_shell, default=True)
        changed = True
    if write_rules:
        merged["DECONWORK_ALLOW_WRITE_RULES_FILE"] = normalize_bool_env_value(write_rules, default=True)
        changed = True
    if write_memory:
        merged["DECONWORK_ALLOW_WRITE_MEMORY_FILE"] = normalize_bool_env_value(write_memory, default=True)
        changed = True
    if write_heartbeat:
        merged["DECONWORK_ALLOW_WRITE_HEARTBEAT_FILE"] = normalize_bool_env_value(write_heartbeat, default=True)
        changed = True

    if changed:
        merged = merge_and_normalize_env(target_dir, merged)
        write_env_file(env_file, merged)
        ensure_runtime_files(merged)
        print("权限配置已更新。")
    else:
        merged = merge_and_normalize_env(target_dir, merged)
        if env_file_needs_backfill(file_data, merged):
            write_env_file(env_file, merged)
            ensure_runtime_files(merged)
            print("当前权限配置（已自动补齐缺失项到配置文件）：")
        else:
            print("当前权限配置：")

    print(f"配置文件: {env_file}")
    print(f"  - DECONWORK_PERMISSION_MODE={merged.get('DECONWORK_PERMISSION_MODE', 'global')}")
    print(f"  - DECONWORK_ALLOW_SHELL_COMMANDS={merged.get('DECONWORK_ALLOW_SHELL_COMMANDS', 'true')}")
    print(
        "  - 文件写入权限: "
        f"rules={merged.get('DECONWORK_ALLOW_WRITE_RULES_FILE', 'true')}, "
        f"memory={merged.get('DECONWORK_ALLOW_WRITE_MEMORY_FILE', 'true')}, "
        f"heartbeat={merged.get('DECONWORK_ALLOW_WRITE_HEARTBEAT_FILE', 'true')}"
    )
    print("说明：workspace=工作目录沙箱，global=全局权限；sandbox on/off 等价切换 workspace/global。")
    return 0


def add_config_subcommands(config_parser: argparse.ArgumentParser) -> None:
    """向 `config` 子命令挂载下级命令。"""
    config_subparsers = config_parser.add_subparsers(dest="config_command")
    config_subparsers.add_parser("show", help="显示当前配置")
    config_subparsers.add_parser("init", help="初始化配置文件和 runtime 文件")

    set_parser = config_subparsers.add_parser("set", help="设置单个配置项")
    set_parser.add_argument("key", help="环境变量名")
    set_parser.add_argument("value", help="环境变量值")

    model_parser = config_subparsers.add_parser("model", help="模型配置向导")
    model_parser.add_argument("--list", action="store_true", help="仅显示可选模型")
    model_parser.add_argument("--select", default="", help="指定模型别名（如 kimi-k2.5）")
    model_parser.add_argument("--api-key", default="", help="可选：直接写入 API key")
    model_parser.add_argument("--api-key-env", default="", help="可选：指定 API key 环境变量名")
    model_parser.add_argument(
        "--no-prompt-key",
        action="store_true",
        help="选择模型后不进入 API key 交互输入",
    )

    permission_parser = config_subparsers.add_parser("permission", help="配置权限模式与沙箱")
    permission_parser.add_argument(
        "--mode",
        choices=["workspace", "global"],
        default="",
        help="权限模式：workspace(沙箱) / global(全局)",
    )
    permission_parser.add_argument(
        "--sandbox",
        choices=["on", "off"],
        default="",
        help="沙箱开关：on=workspace, off=global",
    )
    permission_parser.add_argument(
        "--allow-shell",
        choices=["true", "false"],
        default="",
        help="是否允许 execute_command 工具",
    )
    permission_parser.add_argument(
        "--write-rules",
        choices=["true", "false"],
        default="",
        help="是否允许写入 rules 文件",
    )
    permission_parser.add_argument(
        "--write-memory",
        choices=["true", "false"],
        default="",
        help="是否允许写入 memory 文件",
    )
    permission_parser.add_argument(
        "--write-heartbeat",
        choices=["true", "false"],
        default="",
        help="是否允许写入 heartbeat 文件",
    )

    env_parser = config_subparsers.add_parser("env", help="查看/修改 deconwork.env")
    env_subparsers = env_parser.add_subparsers(dest="env_command")

    env_subparsers.add_parser("path", help="显示 deconwork.env 路径")

    env_show_parser = env_subparsers.add_parser("show", help="显示 deconwork.env 内容")
    env_show_parser.add_argument(
        "--raw",
        action="store_true",
        help="显示完整值（默认会对敏感项做掩码）",
    )

    env_set_parser = env_subparsers.add_parser("set", help="设置 deconwork.env 项")
    env_set_parser.add_argument("key", help="环境变量名")
    env_set_parser.add_argument("value", help="环境变量值")

    env_unset_parser = env_subparsers.add_parser("unset", help="删除 deconwork.env 项")
    env_unset_parser.add_argument("key", help="环境变量名")


def handle_config_command(args: argparse.Namespace) -> int:
    """分发 config 子命令。"""
    if args.config_command in (None, "show"):
        return config_show()
    if args.config_command == "init":
        return config_init()
    if args.config_command == "set":
        return config_set(args.key, args.value)
    if args.config_command == "model":
        return config_model(
            list_only=bool(args.list),
            select=args.select,
            api_key=args.api_key,
            api_key_env=args.api_key_env,
            no_prompt_key=bool(args.no_prompt_key),
        )
    if args.config_command == "permission":
        return config_permission(
            mode=args.mode,
            sandbox=args.sandbox,
            allow_shell=args.allow_shell,
            write_rules=args.write_rules,
            write_memory=args.write_memory,
            write_heartbeat=args.write_heartbeat,
        )
    if args.config_command == "env":
        if args.env_command in (None, "show"):
            return config_env_show(raw=bool(getattr(args, "raw", False)))
        if args.env_command == "path":
            return config_env_path()
        if args.env_command == "set":
            return config_env_set(args.key, args.value)
        if args.env_command == "unset":
            return config_env_unset(args.key)
        return 2
    return 2

