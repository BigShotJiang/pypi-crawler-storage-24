# -*- coding: utf-8 -*-
"""DeconWork 上下文压缩工具。

目标：
1. 替代简单字符截断，改为按 Markdown 分节压缩。
2. 以 token 预算为约束，优先保留高价值段落。
3. 对单个超长段落采用“头尾保留”策略，降低信息丢失。
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Dict, List, Tuple

from klynx.agent.context_manager import TokenCounter


@dataclass
class Section:
    """Markdown 分节单元。"""

    title: str
    body: str
    index: int

    @property
    def text(self) -> str:
        if self.title:
            return f"{self.title}\n{self.body}".strip()
        return self.body.strip()


def _estimate_tokens(text: str) -> int:
    """估算 token 数。"""
    return max(0, int(TokenCounter.estimate_tokens(text or "")))


def _split_markdown_sections(text: str) -> List[Section]:
    """按 Markdown 标题分节。"""
    raw = str(text or "").strip()
    if not raw:
        return []

    lines = raw.splitlines()
    sections: List[Section] = []
    current_title = ""
    current_body: List[str] = []
    index = 0

    heading_pattern = re.compile(r"^\s{0,3}#{1,6}\s+.+$")

    def _flush() -> None:
        nonlocal index, current_title, current_body
        body_text = "\n".join(current_body).strip()
        if current_title or body_text:
            sections.append(
                Section(
                    title=current_title.strip(),
                    body=body_text,
                    index=index,
                )
            )
            index += 1
        current_title = ""
        current_body = []

    for line in lines:
        if heading_pattern.match(line):
            _flush()
            current_title = line.strip()
            continue
        current_body.append(line)
    _flush()
    return sections


def _head_tail_excerpt(text: str, target_tokens: int) -> str:
    """对超长文本做头尾保留。"""
    content = str(text or "").strip()
    if not content:
        return ""
    if _estimate_tokens(content) <= target_tokens:
        return content

    lines = content.splitlines()
    if len(lines) <= 8:
        # 短文本但 token 估算过大时，做字符截断兜底
        max_chars = max(64, int(target_tokens * 3.2))
        return content[:max_chars].rstrip() + "\n...(已压缩)"

    head_lines = max(2, min(16, int(len(lines) * 0.35)))
    tail_lines = max(2, min(16, int(len(lines) * 0.20)))
    head = "\n".join(lines[:head_lines]).strip()
    tail = "\n".join(lines[-tail_lines:]).strip()
    merged = f"{head}\n...\n{tail}".strip()

    # 二次兜底：若仍超预算，继续字符级收缩
    if _estimate_tokens(merged) > target_tokens:
        max_chars = max(64, int(target_tokens * 3.0))
        merged = merged[:max_chars].rstrip() + "\n...(已压缩)"
    return merged


def _score_section(section: Section, priority_terms: List[str]) -> int:
    """对分节打分，用于预算内优先保留。"""
    title = section.title.lower()
    body_head = "\n".join(section.body.splitlines()[:20]).lower()
    score = 0

    # 标题命中优先级最高
    for term in priority_terms:
        if term in title:
            score += 8
        if term in body_head:
            score += 2

    # 前置段落默认有轻微优势
    score += max(0, 3 - min(section.index, 3))
    return score


def compress_markdown(
    *,
    text: str,
    max_tokens: int,
    priority_terms: List[str],
) -> str:
    """按 token 预算压缩 Markdown 文本。"""
    raw = str(text or "").strip()
    if not raw:
        return ""
    if max_tokens <= 0:
        return ""

    total_tokens = _estimate_tokens(raw)
    if total_tokens <= max_tokens:
        return raw

    sections = _split_markdown_sections(raw)
    if not sections:
        return _head_tail_excerpt(raw, max_tokens)

    # 先按分数排序，再逐段装入预算
    ranked = sorted(
        sections,
        key=lambda s: (_score_section(s, priority_terms), -s.index),
        reverse=True,
    )

    selected: List[Tuple[int, str]] = []
    used = 0
    dropped = 0

    for section in ranked:
        section_text = section.text
        section_tokens = _estimate_tokens(section_text)

        if used + section_tokens <= max_tokens:
            selected.append((section.index, section_text))
            used += section_tokens
            continue

        # 若预算不足但还未选任何段，至少保留一个压缩段
        if not selected:
            excerpt_budget = max(64, max_tokens - used - 8)
            compact = _head_tail_excerpt(section_text, excerpt_budget)
            compact_tokens = _estimate_tokens(compact)
            if compact and compact_tokens <= max_tokens:
                selected.append((section.index, compact))
                used += compact_tokens
            else:
                selected.append((section.index, _head_tail_excerpt(section_text, max_tokens)))
                used = max_tokens
            dropped += 1
            continue

        dropped += 1

    # 按原顺序还原
    selected.sort(key=lambda x: x[0])
    merged = "\n\n".join(text for _, text in selected).strip()
    if dropped > 0:
        merged = f"{merged}\n\n...(已省略 {dropped} 个段落)"
    return merged


def build_runtime_context_append(
    *,
    source: str,
    rules_text: str,
    memory_text: str,
    heartbeat_text: str = "",
    total_budget_tokens: int = 2400,
) -> str:
    """构建运行时上下文附加块（带预算压缩）。"""
    has_heartbeat = bool(str(heartbeat_text or "").strip())
    budget = max(900, int(total_budget_tokens))

    # 预算分配：rules 与 memory 主导，heartbeat 次之
    if has_heartbeat:
        rules_budget = int(budget * 0.38)
        memory_budget = int(budget * 0.38)
        heartbeat_budget = max(120, budget - rules_budget - memory_budget)
    else:
        rules_budget = int(budget * 0.5)
        memory_budget = budget - rules_budget
        heartbeat_budget = 0

    rules_compact = compress_markdown(
        text=rules_text,
        max_tokens=rules_budget,
        priority_terms=["mission", "rule", "rules", "policy", "约束", "规范", "安全", "禁止"],
    )
    memory_compact = compress_markdown(
        text=memory_text,
        max_tokens=memory_budget,
        priority_terms=[
            "ongoing",
            "task",
            "todo",
            "decision",
            "constraint",
            "偏好",
            "进行中",
            "约束",
            "决定",
        ],
    )
    heartbeat_compact = ""
    if has_heartbeat:
        heartbeat_compact = compress_markdown(
            text=heartbeat_text,
            max_tokens=heartbeat_budget,
            priority_terms=["todo", "task", "action", "步骤", "目标", "优先级"],
        )

    parts = [
        "## DeconWork Runtime Context",
        f"- source: {source}",
        f"- context_budget_tokens: {budget}",
        "- 使用 ReAct 主循环执行任务。",
    ]
    if rules_compact:
        parts.extend(["### rules.md", rules_compact])
    if memory_compact:
        parts.extend(["### memory.md", memory_compact])
    if heartbeat_compact:
        parts.extend(["### heartbeat.md", heartbeat_compact])

    return "\n\n".join(parts).strip()
