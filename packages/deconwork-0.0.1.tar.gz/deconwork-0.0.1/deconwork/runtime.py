﻿# -*- coding: utf-8 -*-
"""DeconWork CLI 入口与命令分发。"""

from __future__ import annotations

import argparse
from typing import Dict, Optional

from .config_manager import (
    add_config_subcommands,
    config_model,
    ensure_runtime_files,
    handle_config_command,
    install_dir,
    is_model_ready,
    load_install_env,
)


def _build_parser() -> argparse.ArgumentParser:
    """构建命令行解析器。"""
    parser = argparse.ArgumentParser(
        prog="DeconWork",
        description="DeconWork 独立桌面 Agent（主进程对话 + 独立心跳进程）。",
    )
    subparsers = parser.add_subparsers(dest="command")

    subparsers.add_parser("run", help="启动主进程对话（默认行为）")

    heartbeat_parser = subparsers.add_parser("heartbeat", help="启动独立心跳进程")
    heartbeat_parser.add_argument(
        "--once",
        action="store_true",
        help="只触发一次心跳任务后退出",
    )

    config_parser = subparsers.add_parser("config", help="管理安装目录配置")
    add_config_subcommands(config_parser)
    return parser


def _bootstrap_env(target_dir) -> Dict[str, str]:
    """确保 deconwork.env 与运行时文件已初始化。"""
    env_map = load_install_env(target_dir)
    ensure_runtime_files(env_map)
    return env_map


def _ensure_model_ready_for_run(target_dir, env_map: Dict[str, str]) -> Optional[Dict[str, str]]:
    """主进程启动前校验模型配置；未配置则自动进入配置向导。"""
    ready, reason = is_model_ready(env_map)
    if ready:
        return env_map

    print("[SYS] 检测到当前模型未完成配置，先进入模型配置向导。")
    if reason:
        print(f"[SYS] {reason}")

    # 首次运行默认带入当前模型别名（如有），减少重复输入。
    selected = str(env_map.get("DECONWORK_MODEL_NAME", "") or "").strip()
    result = config_model(select=selected)
    if result != 0:
        print("[SYS] 模型配置未完成，已退出。")
        return None

    refreshed = _bootstrap_env(target_dir)
    ready, reason = is_model_ready(refreshed)
    if ready:
        return refreshed

    print("[SYS] 模型配置仍不完整，无法启动。")
    if reason:
        print(f"[SYS] {reason}")
    return None


def main(argv: list[str] | None = None) -> int:
    """CLI 主入口。"""
    parser = _build_parser()
    args = parser.parse_args(argv)

    target_dir = install_dir()
    env_map = _bootstrap_env(target_dir)

    if args.command in (None, "run"):
        ready_env = _ensure_model_ready_for_run(target_dir, env_map)
        if ready_env is None:
            return 2
        from .agent_main import run_agent_main

        return run_agent_main(target_dir)

    if args.command == "heartbeat":
        ready, reason = is_model_ready(env_map)
        if not ready:
            print("[SYS] Heartbeat 启动前需要完成模型配置。")
            if reason:
                print(f"[SYS] {reason}")
            print("[SYS] 请先执行 `DeconWork config model`。")
            return 2
        from .agent_main import run_heartbeat_main

        return run_heartbeat_main(target_dir, once=bool(args.once))

    if args.command == "config":
        return handle_config_command(args)

    parser.error("未知命令。")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
