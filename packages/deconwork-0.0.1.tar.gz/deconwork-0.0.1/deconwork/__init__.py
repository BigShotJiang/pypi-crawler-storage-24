"""DeconWork 独立程序包入口。"""

from __future__ import annotations


def main(argv=None):
    """延迟导入 CLI 入口，避免 `python -m deconwork.runtime` 的重复导入警告。"""
    from .runtime import main as runtime_main

    return runtime_main(argv)


__all__ = ["main"]
