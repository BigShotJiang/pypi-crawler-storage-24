Pymunk
======

.. image::  https://raw.githubusercontent.com/viblo/pymunk/master/docs/src/_static/pymunk_logo_animation.gif

Pymunk is an easy-to-use pythonic 2D physics library that can be used whenever 
you need 2D rigid body physics from Python. Perfect when you need 2D physics 
in your game, demo or simulation! It is built on top of Munk2D, a fork of the 
very capable 2D physics library `Chipmunk2D <http://chipmunk-physics.net>`_.

The first version was released in 2007 and Pymunk is still actively developed 
and maintained today, more than 15 years of active development!

Pymunk has been used with success in many projects, big and small. For example: 
3 Pyweek game competition winners, dozens of published scientific 
papers and even in a self-driving car simulation! See the Showcases section on 
the Pymunk webpage for some examples.

2007 - 2025, Victor Blomqvist - vb@viblo.se, MIT License

This release is based on the latest Pymunk release (7.2.0), 
using Munk2D 2.0.1 rev ade7ed72849e60289eefb7a41e79ae6322fefaf3.


Installation
------------

In the normal case Pymunk can be installed from PyPI with pip::

    > pip install pymunk

It has one direct dependency, CFFI.

Pymunk can also be installed with conda, from the conda-forge channel::

    > conda install -c conda-forge pymunk

For more detailed installation instructions, please see the complete Pymunk 
documentation.

Example
-------

Quick code example::
    
    import pymunk               # Import pymunk..

    space = pymunk.Space()      # Create a Space which contain the simulation
    space.gravity = 0,-981      # Set its gravity

    body = pymunk.Body()        # Create a Body
    body.position = 50,100      # Set the position of the body

    poly = pymunk.Poly.create_box(body) # Create a box shape and attach to body
    poly.mass = 10              # Set the mass on the shape
    space.add(body, poly)       # Add both body and shape to the simulation

    print_options = pymunk.SpaceDebugDrawOptions() # For easy printing 

    for _ in range(100):        # Run simulation 100 steps in total
        space.step(0.02)        # Step the simulation one step forward
        space.debug_draw(print_options) # Print the state of the simulation

This will print (to console) the state of the simulation. For more visual, 
detailed and advanced examples, take a look at the included demos.  
They are included in the Pymunk install, in the pymunk.examples subpackage. 
They can be run directly. To list the examples::

    > python -m pymunk.examples -l

And to run one of them::

    > python -m pymunk.examples.index_video


Contact & Support
-----------------
.. _contact-support:

**Homepage**
    http://www.pymunk.org/

**Stackoverflow**
    You can ask questions/browse old ones at Stackoverflow, just look for 
    the Pymunk tag. http://stackoverflow.com/questions/tagged/pymunk

**E-Mail**
    You can email me directly at vb@viblo.se

**Issue Tracker**
    Please use the issue tracker at Github to report any issues you find. This 
    is also the place for feature requests:
    https://github.com/viblo/pymunk/issues
    
Regardless of the method you use I will try to answer your questions as soon 
as I see them. (And if you ask on Stackoverflow other people might help as 
well!)


Documentation
-------------

The full documentation including API reference, showcase of usages and 
screenshots of examples is available on the Pymunk homepage, 
http://www.pymunk.org


The Pymunk Vision
-----------------

    "*Make 2D physics easy to include in your game*"

It is (or is striving to be):

* **Easy to use** - It should be easy to use, no complicated code should be 
  needed to add physics to your game or program.
* **"Pythonic"** - It should not be visible that a c-library (Chipmunk) is in 
  the bottom, it should feel like a Python library (no strange naming, OO, 
  no memory handling and more)
* **Simple to build & install** - You shouldn't need to have a zillion of 
  libraries installed to make it install, or do a lot of command line tricks.
* **Multi-platform** - Should work on both Windows, \*nix and OSX.
* **Non-intrusive** - It should not put restrictions on how you structure 
  your program and not force you to use a special game loop, it should be 
  possible to use with other libraries like Pygame and Pyglet. 

  
Dependencies / Requirements
---------------------------

Basically Pymunk have been made to be as easy to install and distribute as 
possible, usually `pip install` will take care of everything for you.

- Python (Runs on CPython 3.9 and later and Pypy3)
- Chipmunk (Prebuilt and included when using binary wheels)
- CFFI (will be installed automatically by Pip)
- Setuptools (should be included with Pip)

* GCC and friends (optional, you need it to compile Pymunk from source. On 
  windows Visual Studio is required to compile)
* Pygame or Pygame-CE (optional, you need it to run the Pygame based demos)
* Pyglet (optional, you need it to run the Pyglet based demos)
* Matplotlib & Jupyter Notebook (optional, you need it to run the Matplotlib 
  based demos)
* Numpy (optional, you need to it run a few demos)
* Sphinx & aafigure & sphinx_autodoc_typehints (optional, you need it to build 
  documentation)


Older Pythons
-------------

- Support for Python 2 (and Python 3.0 - 3.5) was dropped with Pymunk 6.0.
- Support for Python 3.6 was dropped with Pymunk 6.5.2.
- Support for Python 3.7 was dropped with Pymunk 6.9.0.
- Support for Python 3.8 was dropped with Pymunk 7.0.0.

If you use any of these legacy versions of Python, please use an older 
Pymunk version. It might work on newer Pymunks as well, but it's not tested, 
and no wheels are built.

