"""
Enhanced data models for comprehensive action execution tracking.

These models provide detailed information for debugging and error reporting,
capturing the full lifecycle of action execution from validation through result analysis.
"""

from datetime import datetime, timezone
from typing import Any
from uuid import UUID, uuid4

from pydantic import BaseModel, Field

from haindy.core.types import CoordinateReference, TestState, TestStep


class ValidationResult(BaseModel):
    """Result of action validation phase."""

    valid: bool = Field(..., description="Whether the action is valid to execute")
    confidence: float = Field(
        ..., ge=0.0, le=1.0, description="Validation confidence score"
    )
    reasoning: str = Field(
        ..., description="Detailed explanation of validation decision"
    )
    concerns: list[str] = Field(
        default_factory=list, description="List of validation concerns"
    )
    suggestions: list[str] = Field(
        default_factory=list, description="Alternative approaches if validation failed"
    )
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class CoordinateResult(BaseModel):
    """Result of coordinate determination phase."""

    target_reference: str = Field(
        ...,
        description="Provider-neutral target reference identifier",
    )
    pixel_coordinates: tuple[int, int] = Field(
        ...,
        description="Pixel coordinates (x, y)",
    )
    relative_x: float = Field(
        ...,
        ge=0.0,
        le=1.0,
        description="Normalized X coordinate within selected target bounds",
    )
    relative_y: float = Field(
        ...,
        ge=0.0,
        le=1.0,
        description="Normalized Y coordinate within selected target bounds",
    )
    confidence: float = Field(
        ..., ge=0.0, le=1.0, description="Coordinate confidence score"
    )
    reasoning: str = Field("", description="Explanation of coordinate selection")
    adjusted: bool = Field(
        False, description="Whether post-selection adjustment was applied"
    )
    adjustment_details: dict[str, Any] | None = Field(
        None, description="Details about any coordinate adjustment process"
    )


class ExecutionResult(BaseModel):
    """Result of action execution phase."""

    success: bool = Field(..., description="Whether the action executed successfully")
    execution_time_ms: float = Field(
        ..., description="Execution duration in milliseconds"
    )
    error_message: str | None = None
    error_traceback: str | None = None
    environment_logs: list[str] = Field(
        default_factory=list, description="Environment logs"
    )
    network_activity: list[dict[str, Any]] = Field(
        default_factory=list, description="Network requests during execution"
    )


class AIAnalysis(BaseModel):
    """AI analysis of action results."""

    success: bool = Field(..., description="AI assessment of action success")
    confidence: float = Field(
        ..., ge=0.0, le=1.0, description="Analysis confidence score"
    )
    actual_outcome: str = Field(
        ..., description="Description of what actually happened"
    )
    matches_expected: bool = Field(
        ..., description="Whether outcome matches expectations"
    )
    ui_changes: list[str] = Field(
        default_factory=list, description="List of observed UI changes"
    )
    recommendations: list[str] = Field(
        default_factory=list, description="AI recommendations for next steps"
    )
    anomalies: list[str] = Field(
        default_factory=list, description="Unexpected behaviors or UI states detected"
    )


class EnvironmentState(BaseModel):
    """Environment state at a point in time."""

    url: str = Field(..., description="Current page URL")
    title: str = Field(..., description="Page title")
    viewport_size: tuple[int, int] = Field(
        ..., description="Viewport dimensions (width, height)"
    )
    screenshot: bytes | None = None
    screenshot_path: str | None = None
    dom_ready_state: str | None = None
    active_element: str | None = None
    frame_kind: str = "keyframe"
    frame_id: str | None = None
    parent_keyframe_id: str | None = None
    patch_bounds: tuple[int, int, int, int] | None = None
    target_bounds: tuple[int, int, int, int] | None = None
    diff_bounds: tuple[int, int, int, int] | None = None


class ComputerToolTurn(BaseModel):
    """Record of a single Computer Use tool action and its execution details."""

    call_id: str = Field(..., description="OpenAI computer_call identifier")
    action_type: str = Field(..., description="Type of action requested by the model")
    parameters: dict[str, Any] = Field(
        default_factory=dict,
        description="Raw action payload supplied by the model",
    )
    status: str = "pending"
    error_message: str | None = None
    screenshot_path: str | None = None
    response_id: str | None = None
    pending_safety_checks: list[dict[str, Any]] = Field(
        default_factory=list,
        description="Safety checks returned alongside this action",
    )
    acknowledged: bool = False
    timestamp: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        description="Timestamp when the action was processed",
    )
    latency_ms: float | None = None
    metadata: dict[str, Any] = Field(
        default_factory=dict, description="Additional metadata for observability"
    )


class SafetyEvent(BaseModel):
    """Represents a safety check event encountered during Computer Use execution."""

    call_id: str = Field(..., description="Call ID associated with the safety event")
    code: str = Field(..., description="Safety check code")
    message: str = Field(..., description="Safety check message")
    acknowledged: bool = Field(
        False, description="Whether the event was acknowledged by the system"
    )
    response_id: str | None = Field(
        None, description="Response ID where the safety event originated"
    )
    timestamp: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        description="Timestamp when the safety event was recorded",
    )


class EnhancedActionResult(BaseModel):
    """
    Comprehensive result of action execution with full debugging information.

    This model captures the complete lifecycle of an action from validation
    through execution and analysis, providing rich context for debugging
    and error reporting.
    """

    # Identifiers
    action_id: UUID = Field(default_factory=uuid4)
    test_step_id: UUID = Field(..., description="ID of the test step being executed")

    # Timestamps
    timestamp_start: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc)
    )
    timestamp_end: datetime | None = None

    # Original request
    test_step: TestStep = Field(..., description="Original test step")
    test_context: dict[str, Any] = Field(..., description="Test execution context")

    # Validation phase
    validation: ValidationResult = Field(..., description="Validation phase results")

    # Coordinate determination
    coordinates: CoordinateResult | None = None

    # Environment states
    environment_state_before: EnvironmentState | None = None
    environment_state_after: EnvironmentState | None = None

    # Execution
    execution: ExecutionResult | None = None

    # AI Analysis
    ai_analysis: AIAnalysis | None = None
    computer_actions: list[ComputerToolTurn] = Field(
        default_factory=list,
        description="Sequence of Computer Use tool actions executed",
    )
    safety_events: list[SafetyEvent] = Field(
        default_factory=list,
        description="Safety check events encountered during execution",
    )
    final_model_output: str | None = None
    response_ids: list[str] = Field(
        default_factory=list,
        description="OpenAI response IDs involved in this action loop",
    )
    terminal_failure_code: str | None = None
    terminal_failure_reason: str | None = None
    cache_label: str | None = None
    cache_action: str | None = None
    cache_hit: bool = False
    cache_coordinates: tuple[int, int] | None = None
    cache_resolution: tuple[int, int] | None = None
    driver_actions: list[dict[str, Any]] = Field(
        default_factory=list,
        description="Recorded driver actions for execution replay",
    )

    # Overall status
    overall_success: bool = False
    failure_phase: str | None = None

    def dict_for_compatibility(self) -> dict[str, Any]:
        """
        Convert to dictionary format compatible with existing code.

        This method provides backward compatibility while we transition
        to the new model structure.
        """
        return {
            "action_type": "click",  # Default since we don't have action_type in new structure
            "timestamp": self.timestamp_start.isoformat(),
            "validation_passed": self.validation.valid,
            "validation_reasoning": self.validation.reasoning,
            "validation_confidence": self.validation.confidence,
            "target_reference": (
                self.coordinates.target_reference if self.coordinates else ""
            ),
            "pixel_coordinates": (
                self.coordinates.pixel_coordinates if self.coordinates else (0, 0)
            ),
            "relative_x": self.coordinates.relative_x if self.coordinates else 0.5,
            "relative_y": self.coordinates.relative_y if self.coordinates else 0.5,
            "coordinate_confidence": (
                self.coordinates.confidence if self.coordinates else 0.0
            ),
            "coordinate_reasoning": (
                self.coordinates.reasoning if self.coordinates else ""
            ),
            "execution_success": self.execution.success if self.execution else False,
            "execution_time_ms": (
                self.execution.execution_time_ms if self.execution else 0.0
            ),
            "execution_error": self.execution.error_message if self.execution else None,
            "url_before": (
                self.environment_state_before.url
                if self.environment_state_before
                else ""
            ),
            "url_after": (
                self.environment_state_after.url if self.environment_state_after else ""
            ),
            "page_title_before": (
                self.environment_state_before.title
                if self.environment_state_before
                else ""
            ),
            "page_title_after": (
                self.environment_state_after.title
                if self.environment_state_after
                else ""
            ),
            "screenshot_before": (
                self.environment_state_before.screenshot
                if self.environment_state_before
                else None
            ),
            "screenshot_after": (
                self.environment_state_after.screenshot
                if self.environment_state_after
                else None
            ),
            "test_context": self.test_context,
            "ai_analysis": self.ai_analysis.model_dump() if self.ai_analysis else {},
            "computer_actions": [
                action.model_dump() for action in self.computer_actions
            ],
            "safety_events": [event.model_dump() for event in self.safety_events],
            "final_model_output": self.final_model_output,
            "response_ids": self.response_ids,
            "terminal_failure_code": self.terminal_failure_code,
            "terminal_failure_reason": self.terminal_failure_reason,
        }


class ActionPattern(BaseModel):
    """
    Reusable pattern for successful actions.

    Used for caching and optimizing repeated actions.
    """

    pattern_id: UUID = Field(default_factory=uuid4)
    action_type: str = Field(..., description="Type of action")
    target_description: str = Field(..., description="Description of target element")
    coordinates: CoordinateResult = Field(..., description="Successful coordinates")
    automation_command: str | None = Field(
        None, description="Recorded Automation command for direct replay"
    )
    confidence: float = Field(..., ge=0.0, le=1.0, description="Pattern confidence")
    success_count: int = Field(0, description="Number of successful uses")
    failure_count: int = Field(0, description="Number of failed attempts")
    last_used: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    screenshot_hash: str | None = Field(
        None, description="Hash of screenshot for visual similarity matching"
    )


class BugReport(BaseModel):
    """
    Comprehensive bug report for failed test steps.

    Captures all relevant information for debugging test failures,
    including screenshots, AI reasoning, and execution details.
    """

    bug_id: UUID = Field(default_factory=uuid4, description="Unique bug identifier")
    test_step: TestStep = Field(..., description="The test step that failed")
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    # Failure details
    failure_type: str = Field(
        ..., description="Type of failure: validation|execution|evaluation"
    )
    error_message: str = Field(..., description="Primary error message")
    detailed_error: str | None = Field(
        None, description="Detailed error with stack trace"
    )

    # Execution context
    test_plan_name: str = Field(..., description="Name of the test plan")
    step_number: int = Field(..., description="Step number in the test plan")
    execution_mode: str = Field("visual", description="How the step was executed")

    # Visual evidence
    screenshot_before: bytes | None = Field(
        None, description="Screenshot before action"
    )
    screenshot_after: bytes | None = Field(None, description="Screenshot after action")
    # AI analysis
    validation_result: ValidationResult | None = Field(
        None, description="Validation phase results"
    )
    coordinate_result: CoordinateResult | None = Field(
        None, description="Coordinate determination results"
    )
    execution_result: ExecutionResult | None = Field(
        None, description="Execution phase results"
    )
    ai_analysis: AIAnalysis | None = Field(None, description="AI evaluation of results")

    # Action details
    attempted_action: str = Field(..., description="What action was attempted")
    expected_outcome: str = Field(..., description="What was expected to happen")
    actual_outcome: str = Field(..., description="What actually happened")

    # Coordinate interaction
    target_reference: str | None = Field(
        None,
        description="Provider-neutral target reference that was selected",
    )
    coordinates_used: CoordinateReference | None = Field(
        None,
        description="Exact coordinates used for the action",
    )

    # Environment state
    url_before: str | None = Field(None, description="URL before action")
    url_after: str | None = Field(None, description="URL after action")
    page_title_before: str | None = Field(None, description="Page title before action")
    page_title_after: str | None = Field(None, description="Page title after action")

    # Debugging aids
    confidence_scores: dict[str, float] = Field(
        default_factory=dict, description="Confidence scores at each phase"
    )
    ui_anomalies: list[str] = Field(
        default_factory=list, description="Detected UI anomalies or unexpected states"
    )
    suggested_fixes: list[str] = Field(
        default_factory=list, description="AI-suggested fixes or workarounds"
    )

    # Categorization
    severity: str = Field(
        "medium", description="Bug severity: low|medium|high|critical"
    )
    is_blocking: bool = Field(
        False, description="Whether this blocks test continuation"
    )
    is_flaky: bool = Field(
        False, description="Whether this appears to be a flaky failure"
    )

    def to_summary(self) -> str:
        """Generate a concise summary of the bug report."""
        severity_upper = self.severity.upper()
        blocking_text = " [BLOCKING]" if self.is_blocking else ""

        summary = f"BUG [{severity_upper}]{blocking_text}"

        if self.step_number:
            summary += f" Step {self.step_number}: {self.test_step.description}\n"
        else:
            summary += f" {self.test_step.description}\n"

        summary += f"  Error: {self.error_message}\n"

        if self.expected_outcome and self.actual_outcome:
            summary += f"  Expected: {self.expected_outcome}\n"
            summary += f"  Actual: {self.actual_outcome}\n"

        if self.ai_analysis:
            summary += f"  Confidence: {self.ai_analysis.confidence * 100:.0f}%\n"
        elif self.confidence_scores.get("overall"):
            summary += (
                f"  Confidence: {self.confidence_scores.get('overall', 0.0):.0%}\n"
            )

        return summary


class EnhancedTestState(TestState):
    """Extended test state with enhanced tracking capabilities."""

    execution_history: list[EnhancedActionResult] = Field(
        default_factory=list, description="Detailed history of all action executions"
    )
    bug_reports: list[BugReport] = Field(
        default_factory=list, description="Collection of bug reports for failed steps"
    )
    performance_metrics: dict[str, Any] = Field(
        default_factory=dict, description="Performance metrics for the test execution"
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict, description="Additional metadata for test execution"
    )
