"""
Data models for execution journaling and scripted automation.
"""

from datetime import datetime, timezone
from enum import Enum
from typing import Any
from uuid import UUID, uuid4

from pydantic import BaseModel, ConfigDict, Field, field_serializer

# Import ActionType from core
from haindy.core.types import ActionType


class ExecutionMode(str, Enum):
    """Mode of test execution."""

    VISUAL = "visual"  # AI-driven visual interaction
    SCRIPTED = "scripted"  # Direct WebDriver commands
    HYBRID = "hybrid"  # Mix of both modes


class PatternType(str, Enum):
    """Types of action patterns."""

    CLICK = "click"
    TYPE = "type"
    NAVIGATE = "navigate"
    SCROLL = "scroll"
    WAIT = "wait"
    SCREENSHOT = "screenshot"


class JournalActionResult(BaseModel):
    """Action result for journaling system."""

    success: bool
    action: ActionType | None = None
    confidence: float = Field(0.0, ge=0.0, le=1.0)
    coordinates: tuple[int, int] | None = None
    coordinate_metadata: dict[str, Any] | None = None
    automation_command: str | None = None
    selectors: dict[str, str] | None = None
    input_text: str | None = None
    element_text: str | None = None
    actual_outcome: str | None = None
    error_message: str | None = None


class JournalEntry(BaseModel):
    """A single test execution journal entry."""

    entry_id: UUID = Field(default_factory=uuid4)
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    test_scenario: str
    step_reference: str
    action_taken: str

    # Coordinate metadata for visual mode
    coordinate_metadata: dict[str, Any] | None = Field(
        default=None,
        description="Coordinate metadata used for visual interaction",
    )

    # Scripted command for replay mode
    scripted_command: str | None = Field(
        default=None, description="Automation command for direct execution"
    )

    # Selectors discovered during execution
    selectors: dict[str, str] | None = Field(
        default=None, description="CSS/XPath selectors found for the element"
    )

    # Execution details
    execution_mode: ExecutionMode = ExecutionMode.VISUAL
    execution_time_ms: int = 0
    agent_confidence: float = 0.0

    # Results
    expected_result: str
    actual_result: str
    success: bool = True
    error_message: str | None = None

    # Evidence
    screenshot_before: str | None = None
    screenshot_after: str | None = None

    # Pattern matching data
    pattern_id: UUID | None = Field(
        default=None, description="ID of matched pattern if reused"
    )

    model_config = ConfigDict()

    @field_serializer("timestamp")
    def serialize_timestamp(self, timestamp: datetime) -> str:
        return timestamp.isoformat()

    @field_serializer("entry_id", "pattern_id")
    def serialize_uuid(self, value: UUID | None) -> str | None:
        return str(value) if value else None


class ActionRecord(BaseModel):
    """Recorded action for pattern matching and reuse."""

    record_id: UUID = Field(default_factory=uuid4)
    pattern_type: PatternType

    # Visual pattern data
    visual_signature: dict[str, Any] = Field(
        default_factory=dict, description="Visual characteristics for pattern matching"
    )

    # Scripted replay data
    automation_command: str
    selectors: dict[str, str] = Field(default_factory=dict)
    fallback_commands: list[str] = Field(
        default_factory=list, description="Alternative commands if primary fails"
    )

    # Context and metadata
    url_pattern: str | None = None
    element_type: str | None = None
    element_text: str | None = None

    # Performance data
    success_count: int = 0
    failure_count: int = 0
    avg_execution_time_ms: float = 0.0
    last_used: datetime | None = None

    model_config = ConfigDict()

    @field_serializer("last_used")
    def serialize_last_used(self, last_used: datetime | None) -> str | None:
        return last_used.isoformat() if last_used else None

    @field_serializer("record_id")
    def serialize_record_id(self, record_id: UUID) -> str:
        return str(record_id)


class PatternMatch(BaseModel):
    """Result of pattern matching attempt."""

    pattern_id: UUID
    confidence: float = Field(ge=0.0, le=1.0)
    match_type: str  # exact, similar, partial
    adjustments: dict[str, Any] = Field(
        default_factory=dict, description="Required adjustments to apply pattern"
    )


class ScriptedCommand(BaseModel):
    """A scripted command ready for execution."""

    command_type: str  # click, type, navigate, etc.
    command: str  # The actual Automation command
    selectors: list[str] = Field(
        default_factory=list, description="Ordered list of selectors to try"
    )
    parameters: dict[str, Any] = Field(default_factory=dict)
    timeout_ms: int = 30000
    retry_count: int = 3

    # Fallback to visual mode criteria
    fallback_threshold: float = Field(
        default=0.8, description="Confidence threshold to trigger visual fallback"
    )
    allow_visual_fallback: bool = True


class ExecutionJournal(BaseModel):
    """Complete execution journal for a test run."""

    journal_id: UUID = Field(default_factory=uuid4)
    test_plan_id: UUID
    test_name: str

    # Execution timeline
    start_time: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    end_time: datetime | None = None

    # Entries
    entries: list[JournalEntry] = Field(default_factory=list)

    # Patterns discovered
    discovered_patterns: list[ActionRecord] = Field(default_factory=list)
    reused_patterns: list[UUID] = Field(default_factory=list)

    # Statistics
    total_steps: int = 0
    successful_steps: int = 0
    failed_steps: int = 0
    visual_interactions: int = 0
    scripted_interactions: int = 0

    # Performance metrics
    total_execution_time_ms: int = 0
    avg_step_time_ms: float = 0.0

    model_config = ConfigDict()

    @field_serializer("start_time", "end_time")
    def serialize_datetime(self, dt: datetime | None) -> str | None:
        return dt.isoformat() if dt else None

    @field_serializer("journal_id", "test_plan_id")
    def serialize_uuid(self, value: UUID) -> str:
        return str(value)

    @field_serializer("reused_patterns")
    def serialize_uuid_list(self, patterns: list[UUID]) -> list[str]:
        return [str(uuid) for uuid in patterns]

    def add_entry(self, entry: JournalEntry) -> None:
        """Add an entry to the journal."""
        self.entries.append(entry)
        self.total_steps += 1

        if entry.success:
            self.successful_steps += 1
        else:
            self.failed_steps += 1

        if entry.execution_mode == ExecutionMode.VISUAL:
            self.visual_interactions += 1
        elif entry.execution_mode == ExecutionMode.SCRIPTED:
            self.scripted_interactions += 1

        self.total_execution_time_ms += entry.execution_time_ms
        if self.total_steps > 0:
            self.avg_step_time_ms = self.total_execution_time_ms / self.total_steps

    def finalize(self) -> None:
        """Finalize the journal at test completion."""
        self.end_time = datetime.now(timezone.utc)

    def get_summary(self) -> dict[str, Any]:
        """Get a summary of the journal."""
        duration = None
        if self.end_time and self.start_time:
            duration = (self.end_time - self.start_time).total_seconds()

        return {
            "test_name": self.test_name,
            "total_steps": self.total_steps,
            "success_rate": (
                self.successful_steps / self.total_steps if self.total_steps > 0 else 0
            ),
            "execution_modes": {
                "visual": self.visual_interactions,
                "scripted": self.scripted_interactions,
            },
            "patterns": {
                "discovered": len(self.discovered_patterns),
                "reused": len(self.reused_patterns),
            },
            "performance": {
                "total_time_seconds": duration,
                "avg_step_time_ms": self.avg_step_time_ms,
            },
        }
