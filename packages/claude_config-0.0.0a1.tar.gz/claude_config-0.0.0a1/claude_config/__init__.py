"""Tool for statically configuring Claude Code"""

__version__ = "0.0.0a1"
