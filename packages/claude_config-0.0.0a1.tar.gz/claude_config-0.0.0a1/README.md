# claude-config

Tool for statically configuring Claude Code
