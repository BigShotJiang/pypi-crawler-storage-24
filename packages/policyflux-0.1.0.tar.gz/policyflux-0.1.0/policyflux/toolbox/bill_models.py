from __future__ import annotations

from ..core.abstract_bill import Bill
from ..core.id_generator import get_id_generator
from ..core.pf_typing import PolicyPosition


class SequentialBill(Bill):
    def __init__(
        self,
        id: int | None = None,
        position: PolicyPosition | list[float] | None = None,
    ) -> None:
        if id is None:
            id = get_id_generator().generate_bill_id()
        super().__init__(id)
        if isinstance(position, list):
            self.position: PolicyPosition | None = PolicyPosition.from_list(position)
        else:
            self.position = position

        self.n_passed: int = 0
        self.n_failed: int = 0

        self.is_government_bill: bool = False
        self.is_confidence_vote: bool = False

    def record_pass(self) -> None:
        self.n_passed += 1

    def record_fail(self) -> None:
        self.n_failed += 1

    def make_report(self) -> str:
        """Generate a report about the bill."""
        report = f"Bill {self.id}\n"
        report += f"Position: {self.position}\n"
        report += f"Passed: {self.n_passed}, Failed: {self.n_failed}\n"
        return report
