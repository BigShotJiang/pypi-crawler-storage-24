#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-03-23
################################################################

try:
    import berxel_py_wrapper as _berxel_py_wrapper  # noqa: F401
except ImportError:
    _berxel_py_wrapper = None

if _berxel_py_wrapper is not None:
    from .cam import HexCamBerxel, HexCamBerxelParams

    __all__ = [
        "HexCamBerxel",
        "HexCamBerxelParams",
    ]
else:
    __all__ = []
