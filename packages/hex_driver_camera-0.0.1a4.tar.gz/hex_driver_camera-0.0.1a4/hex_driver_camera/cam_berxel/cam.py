#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-03-23
################################################################

import multiprocessing as mp
import time
from dataclasses import dataclass
from typing import Any, Optional

import numpy as np
from berxel_py_wrapper import *
from hex_util_runtime import ns_now, HexShmRingBuffer

from ..base import HexCamBase, HexCamBaseParams


@dataclass
class HexCamBerxelParams(HexCamBaseParams):
    serial_number: Optional[str] = None
    exposure: int = 10000
    gain: int = 100
    sens_ts: bool = True


class HexCamBerxel(HexCamBase):

    def __init__(
            self,
            params: HexCamBerxelParams = HexCamBerxelParams(),
    ) -> None:
        super().__init__()
        self.__params = params
        self.__context: Any = None
        self.__device: Any = None

        self.__intri_shared = mp.Array("d", 4)
        self.__color_ring: Optional[HexShmRingBuffer] = None
        self.__depth_ring: Optional[HexShmRingBuffer] = None
        self.init_vars()

    def get_intri(self) -> np.ndarray:
        return np.array(self.__intri_shared[:], dtype=np.float64)

    def get_color_img(self, latest: bool = False) -> Optional[dict[str, Any]]:
        if self.__color_ring is None:
            return None
        return self.__color_ring.read(latest=latest)

    def get_depth_img(self, latest: bool = False) -> Optional[dict[str, Any]]:
        if self.__depth_ring is None:
            return None
        return self.__depth_ring.read(latest=latest)

    def init_vars(self) -> None:
        self.__h = self.__params.height
        self.__w = self.__params.width
        self.__fps = self.__params.frame_rate
        self.__serial_number = self.__params.serial_number
        self.__exposure = self.__params.exposure
        self.__gain = self.__params.gain
        self.__sens_ts = self.__params.sens_ts

        color_frame_dt = np.dtype([
            ("ts_ns", np.int64),
            ("data", np.uint8, (self.__h, self.__w, 3)),
        ])
        depth_frame_dt = np.dtype([
            ("ts_ns", np.int64),
            ("data", np.uint16, (self.__h, self.__w)),
        ])
        self.__color_ring = HexShmRingBuffer(
            capacity=self.__params.cam_buffer_size,
            dtype=color_frame_dt,
        )
        self.__depth_ring = HexShmRingBuffer(
            capacity=self.__params.cam_buffer_size,
            dtype=depth_frame_dt,
        )

    def init_camera(self) -> None:
        """Open device, start streams, fill intrinsics. Runs in the worker process."""
        if not self.__open_device():
            raise RuntimeError("failed to open Berxel device")
        if not self.__start_stream():
            raise RuntimeError("failed to start Berxel streams")
        self._init_event.set()

    def deinit_camera(self) -> None:
        main = mp.current_process().name == "MainProcess"
        if main and self.is_working():
            self.stop()
        self.__stop_stream()
        self.__close_device()
        if self.__color_ring is not None:
            self.__color_ring.close()
            self.__color_ring = None
        if self.__depth_ring is not None:
            self.__depth_ring.close()
            self.__depth_ring = None

    def work_loop(self) -> None:
        clean_cnt = 0
        while clean_cnt < 5:
            hawk_rgb_frame = self.__device.readColorFrame(40)
            hawk_depth_frame = self.__device.readDepthFrame(40)
            if hawk_rgb_frame is not None:
                self.__device.releaseFrame(hawk_rgb_frame)
            if hawk_depth_frame is not None:
                self.__device.releaseFrame(hawk_depth_frame)
            clean_cnt += 1
            time.sleep(0.01)

        bias_ns = np.int64(0)
        for _ in range(30):
            f = self.__device.readColorFrame(40)
            if f is None:
                time.sleep(0.001)
                continue
            sensor_ns = np.int64(int(f.getTimeStamp() * 1_000))
            bias_ns = np.int64(ns_now()) - sensor_ns
            self.__device.releaseFrame(f)
            break

        while not self.stop_event.is_set():
            hawk_color_frame = self.__device.readColorFrame(40)
            hawk_depth_frame = self.__device.readDepthFrame(40)
            cur_ns = ns_now()

            if hawk_color_frame is not None:
                ts_ns, img = self.__unpack_frame(
                    hawk_color_frame,
                    False,
                    bias_ns,
                    cur_ns,
                )
                self.__color_ring.write({"ts_ns": ts_ns, "data": img})
                self.__device.releaseFrame(hawk_color_frame)

            if hawk_depth_frame is not None:
                ts_ns, depth = self.__unpack_frame(
                    hawk_depth_frame,
                    True,
                    bias_ns,
                    cur_ns,
                )
                self.__depth_ring.write({"ts_ns": ts_ns, "data": depth})
                self.__device.releaseFrame(hawk_depth_frame)

    def __unpack_frame(
        self,
        hawk_frame: BerxelHawkFrame,
        depth: bool,
        bias_ns: np.int64,
        cur_ns: int,
    ) -> tuple[int, np.ndarray]:
        berxel_ts_ns = int(bias_ns) + int(hawk_frame.getTimeStamp() * 1_000)
        if self.__sens_ts:
            ts_ns = berxel_ts_ns
            if cur_ns < ts_ns:
                ts_ns = cur_ns
        else:
            ts_ns = cur_ns

        width = hawk_frame.getWidth()
        height = hawk_frame.getHeight()

        if depth:
            frame_buffer = hawk_frame.getDataAsUint16()
            frame = np.ndarray(
                shape=(height, width),
                dtype=np.uint16,
                buffer=frame_buffer,
            )
            pixel_type = hawk_frame.getPixelType()
            if pixel_type == BerxelHawkPixelType.forward_dict[
                    'BERXEL_HAWK_PIXEL_TYPE_DEP_16BIT_12I_4D']:
                frame = frame // 16
            elif pixel_type == BerxelHawkPixelType.forward_dict[
                    'BERXEL_HAWK_PIXEL_TYPE_DEP_16BIT_13I_3D']:
                frame = frame // 8
            else:
                raise ValueError(f"pixel_type: {pixel_type} not supported")
        else:
            frame_buffer = hawk_frame.getDataAsUint8()
            frame = np.ndarray(
                shape=(height, width, 3),
                dtype=np.uint8,
                buffer=frame_buffer,
            )
            frame = frame[:, :, ::-1]

        return ts_ns, frame

    def __open_device(self) -> bool:
        self.__context = BerxelHawkContext()
        if self.__context is None:
            print("init failed")
            return False
        self.__context.initCamera()

        device_list = self.__context.getDeviceList()
        if len(device_list) < 1:
            print("can not find device")
            return False
        if self.__serial_number is not None:

            def same_serial(tar_serial, device_serial):

                def norm_serial(x):
                    if x is None:
                        return None
                    if isinstance(x, (bytes, bytearray)):
                        x = x.decode('utf-8', 'ignore')
                    x = x.replace('\x00', '').strip()
                    return x.upper()

                return norm_serial(tar_serial) == norm_serial(device_serial)

            device_idx = -1
            for idx, device in enumerate(device_list):
                if same_serial(self.__serial_number, device.serialNumber):
                    print(
                        f"find device with serial number: {self.__serial_number}"
                    )
                    device_idx = idx
                    break
            if device_idx == -1:
                print(
                    f"can not find device with serial number: {self.__serial_number}"
                )
                print("available device serial numbers:")
                for device in device_list:
                    print(f"{device.serialNumber}")
                return False
            self.__device = self.__context.openDevice(device_list[device_idx])
            self.__serial_number = str(self.__serial_number)
        else:
            print("No serial number, use first device")
            self.__device = self.__context.openDevice(device_list[0])
            sn = device_list[0].serialNumber
            if isinstance(sn, (bytes, bytearray)):
                sn = sn.decode('utf-8', 'ignore')
            self.__serial_number = str(sn).replace('\x00', '').strip()

        if self.__device is None:
            print("open device failed")
            return False

        return True

    def __start_stream(self) -> bool:
        if self.__serial_number.startswith('P008'):
            self.__device.setSonixAEStatus(False)
            self.__device.setSonixExposureTime(int(self.__exposure // 100))
        else:
            self.__device.setColorExposureGain(self.__exposure, self.__gain)
        self.__device.setDepthElectricCurrent(700)
        self.__device.setDepthAE(False)
        self.__device.setDepthExposure(43)
        self.__device.setDepthGain(1)
        self.__device.setRegistrationEnable(True)
        self.__device.setFrameSync(True)
        while self.__device.setSystemClock() != 0:
            print("set system clock failed")
            time.sleep(0.1)

        intrinsic_params = self.__device.getDeviceIntriscParams()
        self.__intri_shared[0] = intrinsic_params.colorIntrinsicParams.fx / 2
        self.__intri_shared[1] = intrinsic_params.colorIntrinsicParams.fy / 2
        self.__intri_shared[2] = intrinsic_params.colorIntrinsicParams.cx / 2
        self.__intri_shared[3] = intrinsic_params.colorIntrinsicParams.cy / 2

        color_frame_mode = self.__device.getCurrentFrameMode(
            BerxelHawkStreamType.forward_dict['BERXEL_HAWK_COLOR_STREAM'])
        depth_frame_mode = self.__device.getCurrentFrameMode(
            BerxelHawkStreamType.forward_dict['BERXEL_HAWK_DEPTH_STREAM'])
        color_frame_mode.framerate = int(self.__fps)
        depth_frame_mode.framerate = int(self.__fps)
        self.__device.setFrameMode(
            BerxelHawkStreamType.forward_dict['BERXEL_HAWK_COLOR_STREAM'],
            color_frame_mode)
        self.__device.setFrameMode(
            BerxelHawkStreamType.forward_dict['BERXEL_HAWK_DEPTH_STREAM'],
            depth_frame_mode)
        ret = self.__device.startStreams(
            BerxelHawkStreamType.forward_dict['BERXEL_HAWK_DEPTH_STREAM']
            | BerxelHawkStreamType.forward_dict['BERXEL_HAWK_COLOR_STREAM'])
        if ret == 0:
            print("start stream succeed")
            return True
        print("start stream failed")
        return False

    def __stop_stream(self) -> bool:
        if self.__device is None:
            return False
        ret = self.__device.stopStream(
            BerxelHawkStreamType.forward_dict['BERXEL_HAWK_DEPTH_STREAM']
            | BerxelHawkStreamType.forward_dict['BERXEL_HAWK_COLOR_STREAM'])
        return ret == 0

    def __close_device(self) -> None:
        if self.__context is None:
            return
        if self.__device is None:
            return

        ret = self.__context.closeDevice(self.__device)
        if ret == 0:
            print("close device succeed")
        else:
            print("close device Failed")
        self.__context.destroyCamera()
