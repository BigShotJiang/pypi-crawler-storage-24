#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-03-23
################################################################

import multiprocessing as mp
from dataclasses import dataclass
from typing import Optional, Any

import numpy as np
from hex_util_runtime import HexRate, ns_now, HexShmRingBuffer

from ..base import HexCamBase, HexCamBaseParams


@dataclass
class HexCamDummyParams(HexCamBaseParams):
    pass


class HexCamDummy(HexCamBase):

    def __init__(
            self,
            params: HexCamDummyParams = HexCamDummyParams(),
    ) -> None:
        super().__init__()
        self.__params = params

        self.__color_ring: Optional[HexShmRingBuffer] = None
        self.init_vars()

    def get_color_img(self, latest: bool = False) -> Optional[dict[str, Any]]:
        if self.__color_ring is None:
            return None
        return self.__color_ring.read(latest=latest)

    def init_vars(self):
        self.__h = self.__params.height
        self.__w = self.__params.width
        self.__fps = self.__params.frame_rate

        color_frame_dt = np.dtype([
            ("ts_ns", np.int64),
            ("data", np.uint8, (self.__h, self.__w, 3)),
        ])
        self.__color_ring = HexShmRingBuffer(
            capacity=self.__params.cam_buffer_size,
            dtype=color_frame_dt,
        )

    def init_camera(self) -> None:
        self._init_event.set()

    def deinit_camera(self) -> None:
        main = mp.current_process().name == "MainProcess"
        if main and self.is_working():
            self.stop()
        if self.__color_ring is not None:
            self.__color_ring.close()
            self.__color_ring = None

    def work_loop(self) -> None:
        rate = HexRate(self.__fps)
        while not self.stop_event.is_set():
            rate.sleep()
            color_img = np.random.randint(
                0,
                255,
                (self.__h, self.__w, 3),
                dtype=np.uint8,
            )
            ts = ns_now()
            self.__color_ring.write({"ts_ns": ts, "data": color_img})
