#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-03-23
################################################################

import platform
import cv2
import numpy as np
import multiprocessing as mp
from dataclasses import dataclass
from typing import Optional, Any

from hex_util_runtime import HexRate, ns_now, HexShmRingBuffer

from ..base import HexCamBase, HexCamBaseParams


@dataclass
class HexCamUsbParams(HexCamBaseParams):
    cam_path: str = "/dev/video0"
    exposure: int = 100
    temperature: int = 4000
    sens_ts: bool = True


class HexCamUsb(HexCamBase):

    def __init__(
            self,
            params: HexCamUsbParams = HexCamUsbParams(),
    ) -> None:
        super().__init__()
        self.__params = params
        self._cap: Optional[cv2.VideoCapture] = None

        self.__color_ring: Optional[HexShmRingBuffer] = None
        self.init_vars()

    def get_color_img(self, latest: bool = False) -> Optional[dict[str, Any]]:
        if self.__color_ring is None:
            return None
        return self.__color_ring.read(latest=latest)

    def init_vars(self):
        self.__h = self.__params.height
        self.__w = self.__params.width
        self.__fps = self.__params.frame_rate
        self.__cam_path = self.__params.cam_path
        self.__exposure = self.__params.exposure
        self.__temperature = self.__params.temperature

        color_frame_dt = np.dtype([
            ("ts_ns", np.int64),
            ("data", np.uint8, (self.__h, self.__w, 3)),
        ])
        self.__color_ring = HexShmRingBuffer(
            capacity=self.__params.cam_buffer_size,
            dtype=color_frame_dt,
        )

    def init_camera(self) -> None:
        # open camera
        if platform.system() == "Linux":
            self._cap = cv2.VideoCapture(self.__cam_path, cv2.CAP_V4L2)
        else:
            self._cap = cv2.VideoCapture(self.__cam_path)
        if not self._cap.isOpened():
            raise RuntimeError(f"Failed to open camera: {self.__cam_path}")

        # set camera parameters
        self._cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
        self._cap.set(cv2.CAP_PROP_FRAME_WIDTH, float(self.__w))
        self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, float(self.__h))
        self._cap.set(cv2.CAP_PROP_FPS, float(self.__fps))
        ae_open = 1.0 if platform.system() == "Windows" else 3.0
        ae_close = 0.0 if platform.system() == "Windows" else 1.0
        ae_value = 10000 * (2**self.__exposure) if platform.system(
        ) == "Windows" else float(self.__exposure)
        self._cap.set(cv2.CAP_PROP_AUTO_EXPOSURE, ae_open)
        if self.__exposure != 0:
            self._cap.set(cv2.CAP_PROP_AUTO_EXPOSURE, ae_close)
            self._cap.set(cv2.CAP_PROP_EXPOSURE, ae_value)
        self._cap.set(cv2.CAP_PROP_AUTO_WB, 1)
        if self.__temperature != 0:
            self._cap.set(cv2.CAP_PROP_AUTO_WB, 0)
            self._cap.set(cv2.CAP_PROP_WB_TEMPERATURE,
                          float(self.__temperature))

        # print camera info
        print(
            f"Camera info: {self._cap.get(cv2.CAP_PROP_FRAME_WIDTH)}x{self._cap.get(cv2.CAP_PROP_FRAME_HEIGHT)}@{self._cap.get(cv2.CAP_PROP_FPS)}"
        )

        self._init_event.set()

    def deinit_camera(self) -> None:
        main = mp.current_process().name == "MainProcess"
        if main and self.is_working():
            self.stop()
        if self._cap is not None:
            self._cap.release()
            self._cap = None
        if self.__color_ring is not None:
            self.__color_ring.close()
            self.__color_ring = None

    def work_loop(self) -> None:
        rate = HexRate(self.__fps)
        while not self.stop_event.is_set():
            rate.sleep()
            ret, frame = self._cap.read()
            if not ret or frame is None:
                continue
            ts = ns_now()
            self.__color_ring.write({"ts_ns": ts, "data": frame})
