#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-03-23
################################################################

from .cam_dummy import HexCamDummy, HexCamDummyParams
from .cam_usb import HexCamUsb, HexCamUsbParams

__all__ = [
    # dummy camera
    "HexCamDummy",
    "HexCamDummyParams",

    # usb camera
    "HexCamUsb",
    "HexCamUsbParams",
]

try:
    import pyrealsense2 as _pyrealsense2  # noqa: F401
except ImportError:
    _pyrealsense2 = None

if _pyrealsense2 is not None:
    from .cam_realsense import HexCamRealsense, HexCamRealsenseParams

    __all__ += [
        # realsense camera (requires pyrealsense2)
        "HexCamRealsense",
        "HexCamRealsenseParams",
    ]

try:
    import berxel_py_wrapper as _berxel_py_wrapper  # noqa: F401
except ImportError:
    _berxel_py_wrapper = None

if _berxel_py_wrapper is not None:
    from .cam_berxel import HexCamBerxel, HexCamBerxelParams

    __all__ += [
        "HexCamBerxel",
        "HexCamBerxelParams",
    ]
