#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-03-23
################################################################

import numpy as np
import pyrealsense2 as rs
import multiprocessing as mp
from dataclasses import dataclass
from typing import Any, Optional
from hex_util_runtime import ns_now, HexShmRingBuffer

from ..base import HexCamBase, HexCamBaseParams


@dataclass
class HexCamRealsenseParams(HexCamBaseParams):
    serial_number: str = "243422073194"
    sens_ts: bool = True


class HexCamRealsense(HexCamBase):

    def __init__(
            self,
            params: HexCamRealsenseParams = HexCamRealsenseParams(),
    ) -> None:
        super().__init__()
        self.__params = params
        self.__pipeline: Any = None
        self.__align: Any = None

        self.__intri_shared = mp.Array("d", 4)
        self.__color_ring: Optional[HexShmRingBuffer] = None
        self.__depth_ring: Optional[HexShmRingBuffer] = None
        self.init_vars()

    def get_intri(self) -> np.ndarray:
        return np.array(self.__intri_shared[:], dtype=np.float64)

    def get_color_img(self, latest: bool = False) -> Optional[dict[str, Any]]:
        if self.__color_ring is None:
            return None
        return self.__color_ring.read(latest=latest)

    def get_depth_img(self, latest: bool = False) -> Optional[dict[str, Any]]:
        if self.__depth_ring is None:
            return None
        return self.__depth_ring.read(latest=latest)

    def init_vars(self) -> None:
        self.__h = self.__params.height
        self.__w = self.__params.width
        self.__fps = self.__params.frame_rate
        self.__serial_number = self.__params.serial_number
        self.__sens_ts = self.__params.sens_ts

        color_frame_dt = np.dtype([
            ("ts_ns", np.int64),
            ("data", np.uint8, (self.__h, self.__w, 3)),
        ])
        depth_frame_dt = np.dtype([
            ("ts_ns", np.int64),
            ("data", np.uint16, (self.__h, self.__w)),
        ])
        self.__color_ring = HexShmRingBuffer(
            capacity=self.__params.cam_buffer_size,
            dtype=color_frame_dt,
        )
        self.__depth_ring = HexShmRingBuffer(
            capacity=self.__params.cam_buffer_size,
            dtype=depth_frame_dt,
        )

    def init_camera(self) -> None:
        """Enumerate device, start color+depth streams, fill intrinsics. Must run in the worker process."""
        ctx = rs.context()
        serial_numbers = []
        for dev in ctx.query_devices():
            serial = dev.get_info(rs.camera_info.serial_number)
            name = dev.get_info(rs.camera_info.name)
            print(f"  - Device: {name}, Serial: {serial}")
            serial_numbers.append(serial)
        if self.__serial_number not in serial_numbers:
            raise RuntimeError(
                f"cannot find device with serial number: {self.__serial_number}"
            )

        self.__pipeline = rs.pipeline()
        config = rs.config()
        config.enable_device(self.__serial_number)
        config.enable_stream(
            rs.stream.color,
            self.__w,
            self.__h,
            rs.format.bgr8,
            int(self.__fps),
        )
        config.enable_stream(
            rs.stream.depth,
            self.__w,
            self.__h,
            rs.format.z16,
            int(self.__fps),
        )
        profile = self.__pipeline.start(config)
        color_profile = profile.get_stream(rs.stream.color)
        color_intrinsics = color_profile.as_video_stream_profile(
        ).get_intrinsics()
        self.__intri_shared[0] = float(color_intrinsics.fx)
        self.__intri_shared[1] = float(color_intrinsics.fy)
        self.__intri_shared[2] = float(color_intrinsics.ppx)
        self.__intri_shared[3] = float(color_intrinsics.ppy)
        self.__align = rs.align(rs.stream.color)
        self.__depth_scale = profile.get_device().first_depth_sensor().get_depth_scale() * 1000.0
        self._init_event.set()

    def deinit_camera(self) -> None:
        main = mp.current_process().name == "MainProcess"
        if main and self.is_working():
            self.stop()
        if self.__pipeline is not None:
            try:
                self.__pipeline.stop()
            except RuntimeError:
                pass
            self.__pipeline = None
        self.__align = None
        if self.__color_ring is not None:
            self.__color_ring.close()
            self.__color_ring = None
        if self.__depth_ring is not None:
            self.__depth_ring.close()
            self.__depth_ring = None

    def work_loop(self) -> None:
        aligned_frames = self.__align.process(
            self.__pipeline.wait_for_frames())
        bias_ns = np.int64(ns_now()) - np.int64(
            aligned_frames.get_frame_metadata(
                rs.frame_metadata_value.sensor_timestamp) * 1_000)

        while not self.stop_event.is_set():
            aligned_frames = self.__align.process(
                self.__pipeline.wait_for_frames())
            cur_ns = ns_now()
            if self.__sens_ts:
                sen_ts = bias_ns + np.int64(
                    aligned_frames.get_frame_metadata(
                        rs.frame_metadata_value.sensor_timestamp) * 1_000)
                if cur_ns < sen_ts:
                    sen_ts = cur_ns
                ts_ns = sen_ts
            else:
                ts_ns = cur_ns

            color_frame = aligned_frames.get_color_frame()
            if color_frame is not None:
                color = np.asanyarray(color_frame.get_data())
                self.__color_ring.write({"ts_ns": ts_ns, "data": color})

            depth_frame = aligned_frames.get_depth_frame()
            if depth_frame is not None:
                depth = np.asanyarray(depth_frame.get_data(), dtype=np.float32) * self.__depth_scale
                self.__depth_ring.write({"ts_ns": ts_ns, "data": depth.astype(np.uint16)})
