from pathlib import Path
from setuptools import setup

setup(
    name="dsviper",
    version="1.2.0.post2",
    description="Digital Substrate Viper Runtime",
    long_description=Path("README.md").read_text(encoding="utf-8"),
    long_description_content_type="text/markdown",
    author="Digital Substrate",
    maintainer="Digital Substrate",
    url="https://devkit.digitalsubstrate.io",
    project_urls={
        "Documentation": "https://devkit.digitalsubstrate.io",
    },
    license="Proprietary",
    python_requires=">=3.10.0",
    classifiers=[
        "License :: Other/Proprietary License",
        "Development Status :: 5 - Production/Stable",
        "Programming Language :: C++",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Programming Language :: Python :: 3.14",
        "Intended Audience :: Developers",
        "Topic :: Software Development",
        "Operating System :: MacOS :: MacOS X",
        "Operating System :: POSIX :: Linux",
        "Operating System :: Microsoft :: Windows",
    ],
)
