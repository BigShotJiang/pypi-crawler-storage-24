# Roadmap

Browser Hybrid development timeline.

## v0.1.0 — Core ✅

**Goal**: Working browser automation with accessibility tree

- [x] Tab management (HTTP API)
- [x] Navigation
- [x] Accessibility tree parsing
- [x] Click/type by ref
- [x] Click by text
- [x] Form filling
- [x] Screenshot capture
- [x] JavaScript execution
- [x] CLI interface
- [x] Type hints
- [x] Unit tests
- [x] Documentation

## v0.2.0 — Polish ✅

**Goal**: Production-ready package

- [x] Better error handling
  - [x] Custom exception hierarchy (ConnectionError, TabError, TimeoutError, CDPError)
  - [x] Timeout handling (per-operation)
  - [x] WebSocket reconnection
- [x] Wait conditions
  - [x] `wait_for(selector=...)`
  - [x] `wait_for(text=...)`
  - [x] `wait_for(url=...)`
  - [x] `wait_until(condition=...)`
- [x] Cookies
  - [x] `get_cookies()`
  - [x] `set_cookies()`
  - [x] `delete_cookies()`
- [x] Network interception
  - [x] `on_request()`
  - [x] `on_response()`
  - [x] `on_request_failed()`
- [x] Keyboard input
  - [x] `press_key()` - Key press with modifiers (Ctrl+C, etc.)
  - [x] `type_slowly()` - Character-by-character typing
- [x] Mouse actions
  - [x] `hover()` - Hover over element
  - [x] Double-click (`click(ref, double=True)`)
  - [x] Right-click (`click(ref, button="right")`)
- [x] CI/CD (GitHub Actions)
  - [x] ruff linting
  - [x] mypy type checking
  - [x] pytest across Python 3.10-3.12

## v0.2.6 — Critical Fixes ✅

**Released**: 2026-03-24

- [x] JavaScript binding fix (`Runtime.callFunctionOn` uses `this`, not argument)
- [x] CDP field name fix (`backendDOMNodeId` not `backendNodeId`)
- [x] Runtime.evaluate result parsing fix
- [x] `focus()` method for form fields
- [x] `clear()` method for input fields
- [x] CLI `--tab-id` option
- [x] Comprehensive test coverage

## v0.3.0 — Distribution

**Goal**: Polished package with docs

- [x] PyPI upload
- [x] GitHub release automation
- [x] Documentation site (MkDocs) — https://sidonsoft.github.io/browser-hybrid/
- [x] Example scripts
- [x] Comparison benchmarks
- [x] Improved form detection
  - [x] Label/for associations
  - [x] Placeholder matching
  - [x] ARIA labels

## v0.4.0 — Advanced

**Goal**: Enterprise features

- [x] PDF generation
- [x] Multi-tab coordination
- [x] Recording/Playback
- [x] Screenshot comparison

---

## Priority Matrix

| Feature | Priority | Status |
|---------|----------|--------|
| ~~Core automation~~ | ~~P0~~ | ✅ Done |
| ~~Error handling & reconnection~~ | ~~P0~~ | ✅ Done |
| ~~PyPI publish~~ | ~~P1~~ | ✅ Done |
| ~~Critical JS/CDP fixes~~ | ~~P1~~ | ✅ Done |
| ~~Documentation site~~ | ~~P2~~ | ✅ Done |
| ~~Improved form detection~~ | ~~P2~~ | ✅ Done |
| ~~Example scripts~~ | ~~P2~~ | ✅ Done |
| ~~Comparison benchmarks~~ | ~~P2~~ | ✅ Done |
| ~~PDF generation~~ | ~~P3~~ | ✅ Done |
| ~~Multi-tab coordination~~ | ~~P3~~ | ✅ Done |
| ~~Recording/Playback~~ | ~~P3~~ | ✅ Done |
| ~~Screenshot comparison~~ | ~~P3~~ | ✅ Done |

## Effort Legend

- **Low**: < 100 lines, no new dependencies
- **Medium**: < 500 lines, minor complexity
- **High**: > 500 lines, complex CDP handling