"""Tests for tab lifecycle and stale reference bug fix."""

from unittest.mock import patch

from browser_hybrid import Browser


class TestTabLifecycle:
    @patch("browser_hybrid.browser.Browser._http_get")
    @patch("browser_hybrid.browser.Browser._http_put")
    def test_close_tab_updates_current(self, mock_http_put, mock_http_get):
        """Closing current tab should switch _current_tab to another."""
        # Setup two tabs
        tab1_data = {
            "id": "tab1",
            "url": "https://a.com",
            "type": "page",
            "webSocketDebuggerUrl": "ws://tab1",
        }
        tab2_data = {
            "id": "tab2",
            "url": "https://b.com",
            "type": "page",
            "webSocketDebuggerUrl": "ws://tab2",
        }

        mock_http_put.side_effect = [tab1_data, tab2_data, None]
        # list_tabs will return tab1 after tab2 is closed
        mock_http_get.return_value = [tab1_data]

        browser = Browser()
        browser.new_tab("https://a.com")
        browser.new_tab("https://b.com")

        assert browser._current_tab.id == "tab2"

        browser.close_tab("tab2")

        # Should have switched to tab1
        assert browser._current_tab is not None
        assert browser._current_tab.id == "tab1"

    @patch("browser_hybrid.browser.Browser._http_get")
    @patch("browser_hybrid.browser.Browser._http_put")
    def test_close_last_tab_clears_current(self, mock_http_put, mock_http_get):
        """Closing the only tab should set _current_tab to None."""
        tab1_data = {
            "id": "tab1",
            "url": "https://example.com",
            "type": "page",
            "webSocketDebuggerUrl": "ws://tab1",
        }

        mock_http_put.side_effect = [tab1_data, None]
        mock_http_get.return_value = []  # No tabs left

        browser = Browser()
        browser.new_tab("https://example.com")
        assert browser._current_tab.id == "tab1"

        browser.close_tab()
        assert browser._current_tab is None

    @patch("browser_hybrid.browser.Browser._http_get")
    @patch("browser_hybrid.browser.Browser._http_put")
    def test_close_non_current_tab(self, mock_http_put, mock_http_get):
        """Closing non-current tab shouldn't change _current_tab."""
        tab1_data = {
            "id": "tab1",
            "url": "https://a.com",
            "type": "page",
            "webSocketDebuggerUrl": "ws://tab1",
        }
        tab2_data = {
            "id": "tab2",
            "url": "https://b.com",
            "type": "page",
            "webSocketDebuggerUrl": "ws://tab2",
        }

        mock_http_put.side_effect = [tab1_data, tab2_data, None]
        # list_tabs would still find tab2 as current

        browser = Browser()
        browser.new_tab("https://a.com")
        browser.new_tab("https://b.com")

        assert browser._current_tab.id == "tab2"

        browser.close_tab("tab1")

        # Current should still be tab2
        assert browser._current_tab.id == "tab2"
