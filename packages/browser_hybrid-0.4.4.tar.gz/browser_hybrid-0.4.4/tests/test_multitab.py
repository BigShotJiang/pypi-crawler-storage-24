"""Tests for multi-tab coordination."""

from __future__ import annotations

from unittest.mock import patch

from browser_hybrid import Browser, Tab


class TestMultiTab:
    @patch("browser_hybrid.browser.Browser._http_get")
    @patch("browser_hybrid.browser.Browser._http_put")
    def test_temp_tab_closes_on_exit(self, mock_http_put, mock_http_get):
        """Test that temp_tab closes tab on exit by default."""
        mock_http_get.return_value = []
        mock_http_put.return_value = {
            "id": "tab123",
            "url": "about:blank",
            "type": "page",
            "webSocketDebuggerUrl": "ws://tab123",
        }

        browser = Browser()
        with browser.temp_tab("https://example.com") as tab:
            assert tab.id == "tab123"

        # Verify close_tab results in an HTTP PUT to /json/close/tab123
        close_calls = [c for c in mock_http_put.call_args_list if "/json/close/tab123" in str(c)]
        assert len(close_calls) == 1

    @patch("browser_hybrid.browser.Browser._http_get")
    @patch("browser_hybrid.browser.Browser._http_put")
    def test_temp_tab_keeps_when_close_on_exit_false(self, mock_http_put, mock_http_get):
        """Test that temp_tab keeps tab when close_on_exit=False."""
        mock_http_get.return_value = []
        mock_http_put.return_value = {
            "id": "tab456",
            "url": "about:blank",
            "type": "page",
            "webSocketDebuggerUrl": "ws://tab456",
        }

        browser = Browser()
        with browser.temp_tab("https://example.com", close_on_exit=False) as tab:
            assert tab.id == "tab456"

        # Verify close_tab was NOT called
        close_calls = [c for c in mock_http_put.call_args_list if "/json/close/tab456" in str(c)]
        assert len(close_calls) == 0

    @patch("browser_hybrid.browser.Browser._http_put")
    def test_switch_to_tab_returns_previous(self, mock_http_put):
        """Test switch_to_tab returns previous tab and updates state."""
        tab1_attrs = {"id": "1", "url": "url1", "title": "t1", "type": "page"}
        tab1 = Tab(**tab1_attrs, web_socket_debugger_url="ws1")
        tab2_attrs = {"id": "2", "url": "url2", "title": "t2", "type": "page"}
        tab2 = Tab(**tab2_attrs, web_socket_debugger_url="ws2")

        browser = Browser()
        browser.current_tab = tab1

        prev = browser.switch_to_tab(tab2)

        assert prev.id == "1"
        assert browser.current_tab.id == "2"
        # Verify activate was called for tab 2
        activate_calls = [c for c in mock_http_put.call_args_list if "/json/activate/2" in str(c)]
        assert len(activate_calls) == 1

    @patch("browser_hybrid.browser.Browser._http_get")
    @patch("browser_hybrid.browser.Browser._http_put")
    def test_switch_to_tab_by_id(self, mock_http_put, mock_http_get):
        """Test switch_to_tab works with a string ID."""
        t1 = {
            "id": "1",
            "url": "url1",
            "title": "t1",
            "type": "page",
            "web_socket_debugger_url": "ws1",
        }
        tab1 = Tab(**t1)

        mock_http_get.return_value = [
            {
                "id": "1",
                "url": "url1",
                "title": "t1",
                "type": "page",
                "webSocketDebuggerUrl": "ws1",
            },
            {
                "id": "2",
                "url": "url2",
                "title": "t2",
                "type": "page",
                "webSocketDebuggerUrl": "ws2",
            },
        ]

        browser = Browser()
        browser.current_tab = tab1

        prev = browser.switch_to_tab("2")

        assert prev.id == "1"
        assert browser.current_tab.id == "2"
        assert browser.current_tab.url == "url2"
