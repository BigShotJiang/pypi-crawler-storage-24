# mcpzoo-rewrite

> 改写提示词 — 生成文本风格改写的提示词

## Installation

```bash
uvx mcpzoo-rewrite
```

## uvx JSON

```json
{
  "mcpServers": {
    "rewrite": {
      "args": ["mcpzoo-rewrite"],
      "command": "uvx"
    }
  }
}
```
