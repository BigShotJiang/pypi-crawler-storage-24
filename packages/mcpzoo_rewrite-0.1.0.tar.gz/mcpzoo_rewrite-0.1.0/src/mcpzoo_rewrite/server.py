from mcp.server.fastmcp import FastMCP

mcp = FastMCP("rewrite")

@mcp.tool()
def gen_rewrite(text: str, style: str, target_audience: str = "") -> str:
    """生成文本增强或风格改写的提示词。"""
    prompt = f"请按照以下要求改写这段文本：\n\n"
    prompt += f"【目标风格】：{style}\n"
    if target_audience:
        prompt += f"【目标受众】：{target_audience}\n"
        
    prompt += "\n改写要求：\n"
    prompt += "1. 保持原意不变，不要随意增减核心信息。\n"
    prompt += "2. 调整词汇和句式，使其完全符合要求的目标风格。\n"
    prompt += "3. 只输出改写后的文本，不要输出额外的解释性废话。\n\n"
    prompt += f"【待改写的原文本】：\n{text}"
    
    return prompt

def main():
    mcp.run()

if __name__ == "__main__":
    main()
