from setuptools import setup, find_packages

setup(
    name="christoffersen_lib",
    version="0.1.9",
    author="Ton Nom",
    description="Christoffersen Independence Test for VaR backtesting",
    long_description=open("README.md",encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "numpy",
        "scipy"
    ],
    python_requires='>=3.7',
)