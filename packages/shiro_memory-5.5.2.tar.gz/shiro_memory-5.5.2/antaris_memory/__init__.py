"""
Shiro Memory — File-based persistent memory for AI agents.
Forked from antaris-memory, upgraded to v5.0.1 feature parity.

Intentionally stripped (Shiro's spec):
- No sharding (MCP, Supabase collection removed)
- No MCP server
- No Supabase collection

v5.0.1 features added:
- LLM enrichment hooks
- Graph intelligence (entity extraction + knowledge graph)
- Tiered storage (hot/warm/cold)
- Co-occurrence / PPMI semantic expansion
- 11-layer search pipeline
- Input gating P0-P3 priority classification
- SemanticExpander (word_expansion.json)
- Metadata junk filtering + credential detection
- agent_name scoping (REQUIRED — prevents memory bleed)
- Re-enrichment, web/structured ingestion, graph queries

Usage:
    from antaris_memory import MemorySystem

    mem = MemorySystem(workspace="./store", agent_name="shiro")
    mem.load()
    mem.ingest("Key decision", source="meeting", category="strategic")
    results = mem.search("decision")
    mem.save()
"""

__version__ = "5.5.2"

# MCP server stripped from shiro-memory per Shiro's spec
MCP_AVAILABLE = False

from typing import TypedDict, List, Optional


class EnrichmentResult(TypedDict, total=False):
    """Return type for LLM enrichment callables passed to MemorySystem."""
    tags: List[str]
    summary: str
    keywords: List[str]
    search_queries: List[str]


# Core
from antaris_memory.core_v4 import MemorySystemV4 as MemorySystem
from antaris_memory.core_v4 import SemanticExpander
from antaris_memory.entry import MemoryEntry
from antaris_memory.decay import DecayEngine
from antaris_memory.sentiment import SentimentTagger
from antaris_memory.temporal import TemporalEngine
from antaris_memory.confidence import ConfidenceEngine
from antaris_memory.compression import CompressionEngine
from antaris_memory.forgetting import ForgettingEngine
from antaris_memory.consolidation import ConsolidationEngine
from antaris_memory.gating import InputGate
from antaris_memory.synthesis import KnowledgeSynthesizer

# Multi-agent
from antaris_memory.shared import SharedMemoryPool, AgentPermission

# Storage
from antaris_memory.migration import MigrationManager, Migration
from antaris_memory.indexing import IndexManager, SearchIndex, TagIndex, DateIndex

# Concurrency
from antaris_memory.locking import FileLock, LockTimeout
from antaris_memory.versioning import VersionTracker, ConflictError

# Search
from antaris_memory.search import SearchEngine, SearchResult

# Context Packets (v1.1)
from antaris_memory.context_packet import ContextPacket, ContextPacketBuilder

# Recovery (v3.3.1)
from antaris_memory.recovery import RecoveryConfig, RecoveryManager

# Memory Types + Namespace Isolation
from antaris_memory.memory_types import MEMORY_TYPE_CONFIGS, get_type_config
from antaris_memory.namespace import NamespacedMemory, NamespaceManager

# Semantic utilities
from antaris_memory.utils import cosine_similarity

# v3.2 — Instrumentation
from antaris_memory.instrumentation import (
    SearchContext,
    extract_memory_references,
    anonymize_query,
    build_usage_signal,
)

# v4.x — Co-occurrence / PPMI
from antaris_memory.cooccurrence import CooccurrenceIndex
from antaris_memory.ppmi_bootstrap import PPMIBootstrap

# v4.x — Graph Intelligence
from antaris_memory.graph import MemoryGraph
from antaris_memory.entity_extractor import EntityExtractor
from antaris_memory.category_tagger import CategoryTagger
from antaris_memory.clustering import MemoryClusterer as ClusterEngine

# v4.7 — Tiered Storage
from antaris_memory.tiers import TierManager

# v4.x — Quality / Search Improvements
from antaris_memory.quality_router import QualityRouter
from antaris_memory.query_expansion import QueryExpander

# Backward compatibility - import legacy core if needed
try:
    from antaris_memory.core import MemorySystem as LegacyMemorySystem
except ImportError:
    LegacyMemorySystem = None

__all__ = [
    "MemorySystem",
    "MemoryEntry",
    "EnrichmentResult",
    "SemanticExpander",

    # Core engines
    "DecayEngine",
    "SentimentTagger",
    "TemporalEngine",
    "ConfidenceEngine",
    "CompressionEngine",
    "ForgettingEngine",
    "ConsolidationEngine",
    "InputGate",
    "KnowledgeSynthesizer",

    # Multi-agent (v0.3)
    "SharedMemoryPool",
    "AgentPermission",

    # Production features (v0.4)
    "MigrationManager",
    "Migration",
    "IndexManager",
    "SearchIndex",
    "TagIndex",
    "DateIndex",

    # Concurrency (v0.5)
    "FileLock",
    "LockTimeout",
    "VersionTracker",
    "ConflictError",

    # Search (v1.0)
    "SearchEngine",
    "SearchResult",

    # Context Packets (v1.1)
    "ContextPacket",
    "ContextPacketBuilder",

    # Sprint 2 — Memory Types
    "MEMORY_TYPE_CONFIGS",
    "get_type_config",

    # Sprint 8 — Namespace Isolation
    "NamespacedMemory",
    "NamespaceManager",

    # Sprint 3 — Hybrid Semantic Search
    "cosine_similarity",

    # v3.2 — Instrumentation
    "SearchContext",
    "extract_memory_references",
    "anonymize_query",
    "build_usage_signal",

    # Recovery
    "RecoveryConfig",
    "RecoveryManager",

    # v4.x — Co-occurrence / PPMI
    "CooccurrenceIndex",
    "PPMIBootstrap",

    # v4.x — Graph Intelligence
    "MemoryGraph",
    "EntityExtractor",
    "CategoryTagger",
    "ClusterEngine",

    # v4.7 — Tiered Storage
    "TierManager",

    # v4.x — Quality / Search
    "QualityRouter",
    "QueryExpander",
]
