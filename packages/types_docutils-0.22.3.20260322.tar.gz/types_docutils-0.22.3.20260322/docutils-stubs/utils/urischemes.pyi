schemes: dict[str, str]
