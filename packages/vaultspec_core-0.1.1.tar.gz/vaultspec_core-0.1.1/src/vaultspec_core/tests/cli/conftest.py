"""Shared fixtures for the CLI test suite.

Provides the session-scoped ``runner``, the ``test_project`` workspace
fixture backed by the real ``test-project/`` corpus, and autouse isolation
that saves/restores the workspace context between tests.  Color output is
disabled globally via ``NO_COLOR=1``.
"""

from __future__ import annotations

import os
import shutil
from pathlib import Path

import pytest
import typer.rich_utils
from typer.testing import CliRunner

import vaultspec_core.core.types as _t
from vaultspec_core.cli import app
from vaultspec_core.config.workspace import resolve_workspace
from vaultspec_core.core.types import init_paths

# Disable Rich/Typer color output in tests.
os.environ["NO_COLOR"] = "1"
typer.rich_utils.COLOR_SYSTEM = None

# Path to the real test-project/ corpus at the repository root.
_REPO_ROOT = Path(__file__).resolve().parents[4]
_TEST_PROJECT_SRC = _REPO_ROOT / "test-project"


def setup_rules_dir(root):
    """Setup rules source directory in the given root."""
    (root / ".vaultspec" / "rules" / "rules").mkdir(parents=True, exist_ok=True)


@pytest.fixture(scope="session")
def runner():
    return CliRunner(env={"NO_COLOR": "1"})


@pytest.fixture
def test_project(tmp_path):
    """Copy the real test-project/ corpus and install vaultspec.

    Each test gets a fresh copy of the full test-project/ tree including
    .vault/ documentation.  ``install_run`` is called to scaffold
    ``.vaultspec/`` and provider destinations so that all commands work.
    The original test-project/ is never modified.  Cleanup is automatic
    via pytest's ``tmp_path``.

    The workspace context is initialised via ``init_paths`` so that unit
    tests calling internal functions (``collect_rules``, ``rules_sync``,
    etc.) have the paths they rely on.
    """
    dest = tmp_path / "project"
    shutil.copytree(
        _TEST_PROJECT_SRC,
        dest,
        ignore_dangling_symlinks=True,
        ignore=shutil.ignore_patterns("*.log"),
    )

    # Install vaultspec framework so .vaultspec/ exists
    # install_run bootstraps its own context, no need to call init_paths first
    from vaultspec_core.core.commands import install_run

    install_run(path=dest, provider="all", upgrade=False, dry_run=False, force=False)

    # Re-init after install to pick up the full workspace layout
    layout = resolve_workspace(target_override=dest)
    init_paths(layout)

    return dest


def run_vaultspec(runner, *args, target=None):
    """Invoke the CLI with optional --target."""
    args_list = list(args)
    if target and "--target" not in args_list and "-t" not in args_list:
        args_list = [*args_list, "--target", str(target)]
    return runner.invoke(app, args_list)


def run_vault(runner, *args, target=None):
    """Invoke the CLI with ``vault`` prefix and optional --target."""
    args_list = list(args)
    if target and "--target" not in args_list and "-t" not in args_list:
        args_list = [*args_list, "--target", str(target)]
    if "vault" not in args_list:
        args_list.insert(0, "vault")
    return runner.invoke(app, args_list)


def run_spec(runner, *args, target=None):
    """Invoke the CLI with optional --target (spec commands)."""
    args_list = list(args)
    if target and "--target" not in args_list and "-t" not in args_list:
        args_list = [*args_list, "--target", str(target)]
    return runner.invoke(app, args_list)


@pytest.fixture(autouse=True)
def _isolate_state():
    """Save and restore workspace context and console between tests.

    This prevents state leakage when one test's CLI invocation sets the
    workspace context and the next test inherits stale values pointing
    at the wrong tmp_path.
    """
    from vaultspec_core.cli._target import reset as reset_target
    from vaultspec_core.console import reset_console
    from vaultspec_core.core.types import _workspace_ctx

    # Snapshot current context via token so we can restore to the exact
    # prior state - including "unset" when no context existed.
    try:
        current = _workspace_ctx.get()
        token = _workspace_ctx.set(current)  # identity set to obtain token
    except LookupError:
        # No context set - set a throwaway value to get a resettable token
        # whose reset() will restore the "no value" state.
        _sentinel = Path(".")
        token = _workspace_ctx.set(
            _t.WorkspaceContext(
                root_dir=_sentinel,
                target_dir=_sentinel,
                rules_src_dir=_sentinel,
                skills_src_dir=_sentinel,
                agents_src_dir=_sentinel,
                system_src_dir=_sentinel,
                templates_dir=_sentinel,
                hooks_dir=_sentinel,
            )
        )

    reset_console()
    reset_target()

    yield

    # Restore original context (including "unset" if that was the prior state).
    _workspace_ctx.reset(token)
    reset_console()
    reset_target()
