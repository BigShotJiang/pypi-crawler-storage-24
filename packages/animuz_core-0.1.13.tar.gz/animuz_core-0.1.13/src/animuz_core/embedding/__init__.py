"""Embedding module - Multiple embedding client implementations."""

from .embedding_client import HTTPEmbeddingClient, EmbeddingClient
from .modal_embedding_client import ModalEmbeddingClient
from .s3_embedding_client import S3EmbeddingClient

__all__ = [
    "HTTPEmbeddingClient",
    "EmbeddingClient",
    "ModalEmbeddingClient",
    "S3EmbeddingClient",
]
