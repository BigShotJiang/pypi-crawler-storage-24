"""
A placeholder for code that needs to be implemented. Raises a NotImplementedError with a descriptive message about the call site.
- todo(what: str) can be inserted anywhere in the code where functionality is yet to be implemented, without basedpyright screaming warnings.
- todof(msg: str) is a decorator that can be used to mark entire functions as TODOs. When the decorated function is called, it raises a NotImplementedError with a descriptive message about the call site.
- todoc(msg: str) is a class decorator that can be used to mark entire classes as TODOs. When any method of the decorated class is called, it raises a NotImplementedError with a descriptive message about the call site.
"""

__version__ = "0.1.6"

from .yatodo import todo, todof, todoc

__all__ = ["todo", "todof", "todoc"]
