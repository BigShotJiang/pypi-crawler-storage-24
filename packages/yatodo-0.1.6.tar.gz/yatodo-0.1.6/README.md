# YATODO

<center><a href="https://ja.wikipedia.org/wiki/%E3%83%88%E3%83%89">
  <figure>
    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/85/Adult_male_Northern_Fur_Seal.jpg/250px-Adult_male_Northern_Fur_Seal.jpg" alt="や!トド!" width="200"/>
    <figcaption>や!トド!</figcaption>
  </figure>
</a>
</center>

YATODO (Yet Another TODO) is a placeholder function for code that needs to be implemented. It raises a NotImplementedError with a descriptive message about the call site. It can be inserted anywhere in the code where functionality is yet to be implemented, without basedpyright screaming warnings. You can use it as a placeholder for function bodies, expressions that are not yet decided, or even insert into the middle of an not fully implemented class.

Provides three functions: `todo(what: str)`, `todof(msg: str)`, and `todoc(msg: str)`. `todo(what: str)` can be inserted anywhere in the code where functionality is yet to be implemented, without basedpyright screaming warnings. `todof(msg: str)` is a decorator that can be used to mark entire functions as TODOs. When the decorated function is called, it raises a NotImplementedError with a descriptive message about the call site. `todoc(msg: str)` is a class decorator that can be used to mark entire classes as TODOs. When any method of the decorated class is called, it raises a NotImplementedError with a descriptive message about the call site.

# Usage

```python
from yatodo import todo, todof, todoc

# Example 1: Using todo as a placeholder for a function body
def my_function():
    todo("Implement the logic for my_function")

# Example 2: Using todo as a placeholder in an expression
def calculate_area(radius: float) -> float:
    return 3.14 * todo() * todo()

# Example 3: Using todof to mark an entire function as a TODO
@todof("This function is not implemented yet")
def unimplemented_function():
    pass

# Example 4: Using todoc to mark an entire class as a TODO
@todoc("This class is not implemented yet")
class UnimplementedClass:
    def method_one(self):
        pass
    def method_two(self):
        pass

    @todof("This method is not implemented yet")
    def already_decorated_method(self):
        pass

    @staticmethod
    @todof("This static method is not implemented yet")
    def already_decorated_static_method():
        pass

    @classmethod
    @todof("This class method is not implemented yet")
    def already_decorated_class_method(cls):
        pass
```
