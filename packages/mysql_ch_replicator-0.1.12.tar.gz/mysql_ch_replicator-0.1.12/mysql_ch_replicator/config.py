import os
import yaml
import fnmatch
import zoneinfo

from dataclasses import dataclass


def stype(obj):
    return type(obj).__name__


@dataclass
class MysqlSettings:
    host: str = 'localhost'
    port: int = 3306
    user: str = 'root'
    password: str = ''
    charset: str = 'utf8mb4'  # Default to utf8mb4 for full Unicode support

    def validate(self):
        if not isinstance(self.host, str):
            raise ValueError(f'mysql host should be string and not {stype(self.host)}')

        if not isinstance(self.port, int):
            raise ValueError(f'mysql port should be int and not {stype(self.port)}')

        if not isinstance(self.user, str):
            raise ValueError(f'mysql user should be string and not {stype(self.user)}')

        if not isinstance(self.password, str):
            raise ValueError(f'mysql password should be string and not {stype(self.password)}')
        
        if not isinstance(self.charset, str):
            raise ValueError(f'mysql charset should be string and not {stype(self.charset)}')


@dataclass
class Index:
    databases: str | list = '*'
    tables: str | list = '*'
    index: str = ''


@dataclass
class PartitionBy:
    databases: str | list = '*'
    tables: str | list = '*'
    partition_by: str = ''


@dataclass
class PostInitialReplicationCommands:
    databases: str | list = '*'
    commands: list = None


@dataclass
class ClickhouseSettings:
    host: str = 'localhost'
    port: int = 3306
    user: str = 'root'
    password: str = ''
    cluster: str = ''
    connection_timeout: int = 30
    send_receive_timeout: int = 120
    erase_batch_size: int = 100000  # Number of records to delete per batch

    def validate(self):
        if not isinstance(self.host, str):
            raise ValueError(f'clickhouse host should be string and not {stype(self.host)}')

        if not isinstance(self.port, int):
            raise ValueError(f'clickhouse port should be int and not {stype(self.port)}')

        if not isinstance(self.user, str):
            raise ValueError(f'clickhouse user should be string and not {stype(self.user)}')

        if not isinstance(self.password, str):
            raise ValueError(f'clickhouse password should be string and not {stype(self.password)}')

        if not isinstance(self.cluster, str):
            raise ValueError(f'clickhouse cluster should be string and not {stype(self.cluster)}')

        if not isinstance(self.connection_timeout, int):
            raise ValueError(f'clickhouse connection_timeout should be int and not {stype(self.connection_timeout)}')

        if not isinstance(self.send_receive_timeout, int):
            raise ValueError(f'clickhouse send_receive_timeout should be int and not {stype(self.send_receive_timeout)}')

        if self.connection_timeout <= 0:
            raise ValueError(f'connection timeout should be at least 1 second')

        if self.send_receive_timeout <= 0:
            raise ValueError(f'send_receive_timeout timeout should be at least 1 second')

        if not isinstance(self.erase_batch_size, int):
            raise ValueError(f'erase_batch_size should be int and not {stype(self.erase_batch_size)}')
        if self.erase_batch_size <= 0:
            raise ValueError('erase_batch_size should be positive')


@dataclass
class BinlogReplicatorSettings:
    data_dir: str = 'binlog'
    records_per_file: int = 100000
    binlog_retention_period: int = 43200  # 12 hours in seconds

    def validate(self):
        if not isinstance(self.data_dir, str):
            raise ValueError(f'binlog_replicator data_dir should be string and not {stype(self.data_dir)}')

        if not isinstance(self.records_per_file, int):
            raise ValueError(f'binlog_replicator records_per_file should be int and not {stype(self.data_dir)}')

        if self.records_per_file <= 0:
            raise ValueError('binlog_replicator records_per_file should be positive')

        if not isinstance(self.binlog_retention_period, int):
            raise ValueError(f'binlog_replicator binlog_retention_period should be int and not {stype(self.binlog_retention_period)}')

        if self.binlog_retention_period <= 0:
            raise ValueError('binlog_replicator binlog_retention_period should be positive')


class Settings:
    DEFAULT_LOG_LEVEL = 'info'
    DEFAULT_OPTIMIZE_INTERVAL = 86400
    DEFAULT_CHECK_DB_UPDATED_INTERVAL = 120
    DEFAULT_AUTO_RESTART_INTERVAL = 3600
    DEFAULT_INITIAL_REPLICATION_BATCH_SIZE = 50000

    def __init__(self):
        self.mysql = MysqlSettings()
        self.clickhouse = ClickhouseSettings()
        self.binlog_replicator = BinlogReplicatorSettings()
        self.databases = ''
        self.tables = '*'
        self.exclude_databases = ''
        self.exclude_tables = ''
        self.settings_file = ''
        self.log_level = 'info'
        self.debug_log_level = False
        self.optimize_interval = 0
        self.enable_optimize_final = None
        self.check_db_updated_interval = 0
        self.indexes: list[Index] = []
        self.partition_bys: list[PartitionBy] = []
        self.post_initial_replication_commands: list[PostInitialReplicationCommands] = []
        self.auto_restart_interval = 0
        self.http_host = ''
        self.http_port = 0
        self.types_mapping = {}
        self.target_databases = {}
        self.target_tables = {}
        self.initial_replication_threads = 0
        self.ignore_deletes = False
        self.cluster_mode = None
        self.mysql_timezone = 'UTC'
        self.initial_replication_batch_size = 50000
        self.skip_initial_replication = False

    def load(self, settings_file):
        data = open(settings_file, 'r').read()
        data = yaml.safe_load(data)

        self.settings_file = settings_file
        self.mysql = MysqlSettings(**data.pop('mysql', {}))
        self.clickhouse = ClickhouseSettings(**data.pop('clickhouse', {}))
        
        self._apply_env_overrides()
        
        self.databases = data.pop('databases')
        self.tables = data.pop('tables', '*')
        self.exclude_databases = data.pop('exclude_databases', '')
        self.exclude_tables = data.pop('exclude_tables', '')
        self.log_level = data.pop('log_level', Settings.DEFAULT_LOG_LEVEL)
        self.optimize_interval = data.pop('optimize_interval', Settings.DEFAULT_OPTIMIZE_INTERVAL)
        # https://clickhouse.com/docs/optimize/avoidoptimizefinal
        self.enable_optimize_final = data.pop('enable_optimize_final', True)
        self.check_db_updated_interval = data.pop(
            'check_db_updated_interval', Settings.DEFAULT_CHECK_DB_UPDATED_INTERVAL,
        )
        self.auto_restart_interval = data.pop(
            'auto_restart_interval', Settings.DEFAULT_AUTO_RESTART_INTERVAL,
        )
        self.types_mapping = data.pop('types_mapping', {})
        self.http_host = data.pop('http_host', '')
        self.http_port = data.pop('http_port', 0)
        self.target_databases = data.pop('target_databases', {})
        self.target_tables = data.pop('target_tables', {})
        self.initial_replication_threads = data.pop('initial_replication_threads', 0)
        self.ignore_deletes = data.pop('ignore_deletes', False)
        self.cluster_mode = True if self.clickhouse.cluster else False
        self.mysql_timezone = data.pop('mysql_timezone', 'UTC')
        self.initial_replication_batch_size = data.pop('initial_replication_batch_size', Settings.DEFAULT_INITIAL_REPLICATION_BATCH_SIZE)
        self.skip_initial_replication = data.pop('skip_initial_replication', False)

        indexes = data.pop('indexes', [])
        for index in indexes:
            self.indexes.append(
                Index(**index)
            )
        
        partition_bys = data.pop('partition_bys', [])
        for partition_by in partition_bys:
            self.partition_bys.append(
                PartitionBy(**partition_by)
            )
        
        post_initial_replication_commands = data.pop('post_initial_replication_commands', [])
        for cmd_config in post_initial_replication_commands:
            self.post_initial_replication_commands.append(
                PostInitialReplicationCommands(**cmd_config)
            )
        
        assert isinstance(self.databases, str) or isinstance(self.databases, list)
        assert isinstance(self.tables, str) or isinstance(self.tables, list)
        self.binlog_replicator = BinlogReplicatorSettings(**data.pop('binlog_replicator'))
        if data:
            raise Exception(f'Unsupported config options: {list(data.keys())}')
        self.validate()

    def _apply_env_overrides(self):
        if os.getenv('MYSQL_HOST'):
            self.mysql.host = os.getenv('MYSQL_HOST')
        if os.getenv('MYSQL_PORT'):
            self.mysql.port = int(os.getenv('MYSQL_PORT'))
        if os.getenv('MYSQL_USER'):
            self.mysql.user = os.getenv('MYSQL_USER')
        if os.getenv('MYSQL_PASSWORD'):
            self.mysql.password = os.getenv('MYSQL_PASSWORD')
        if os.getenv('MYSQL_CHARSET'):
            self.mysql.charset = os.getenv('MYSQL_CHARSET')
        
        if os.getenv('CLICKHOUSE_HOST'):
            self.clickhouse.host = os.getenv('CLICKHOUSE_HOST')
        if os.getenv('CLICKHOUSE_PORT'):
            self.clickhouse.port = int(os.getenv('CLICKHOUSE_PORT'))
        if os.getenv('CLICKHOUSE_USER'):
            self.clickhouse.user = os.getenv('CLICKHOUSE_USER')
        if os.getenv('CLICKHOUSE_PASSWORD'):
            self.clickhouse.password = os.getenv('CLICKHOUSE_PASSWORD')

    @classmethod
    def is_pattern_matches(cls, substr, pattern):
        if not pattern or pattern == '*':
            return True
        if isinstance(pattern, str):
            return fnmatch.fnmatch(substr, pattern)
        if isinstance(pattern, list):
            for allowed_pattern in pattern:
                if fnmatch.fnmatch(substr, allowed_pattern):
                    return True
            return False
        raise ValueError()

    def is_database_matches(self, db_name):
        if self.exclude_databases and self.is_pattern_matches(db_name, self.exclude_databases):
            return False
        return self.is_pattern_matches(db_name, self.databases)

    def is_table_matches(self, table_name):
        if self.exclude_tables and self.is_pattern_matches(table_name, self.exclude_tables):
            return False
        return self.is_pattern_matches(table_name, self.tables)

    def validate_log_level(self):
        if self.log_level not in ['critical', 'error', 'warning', 'info', 'debug']:
            raise ValueError(f'wrong log level {self.log_level}')
        if self.log_level == 'debug':
            self.debug_log_level = True

    def validate_mysql_timezone(self):
        if not isinstance(self.mysql_timezone, str):
            raise ValueError(f'mysql_timezone should be string and not {stype(self.mysql_timezone)}')
        
        # Validate timezone by attempting to import and check if it's valid
        try:
            zoneinfo.ZoneInfo(self.mysql_timezone)
        except zoneinfo.ZoneInfoNotFoundError:
            raise ValueError(f'invalid timezone: {self.mysql_timezone}. Use IANA timezone names like "UTC", "Europe/London", "America/New_York", etc.')

    def get_indexes(self, db_name, table_name):
        results = []
        for index in self.indexes:
            if not self.is_pattern_matches(db_name, index.databases):
                continue
            if not self.is_pattern_matches(table_name, index.tables):
                continue
            results.append(index.index)
        return results

    def get_partition_bys(self, db_name, table_name):
        results = []
        for partition_by in self.partition_bys:
            if not self.is_pattern_matches(db_name, partition_by.databases):
                continue
            if not self.is_pattern_matches(table_name, partition_by.tables):
                continue
            results.append(partition_by.partition_by)
        return results

    def get_post_initial_replication_commands(self, db_name):
        results = []
        for cmd_config in self.post_initial_replication_commands:
            if not self.is_pattern_matches(db_name, cmd_config.databases):
                continue
            if cmd_config.commands:
                results.extend(cmd_config.commands)
        return results

    def is_multiple_mysql_dbs_to_single_ch_db(self, mysql_database: str, target_database: str) -> bool:
        """
        Check if multiple MySQL databases are being replicated to the same ClickHouse database.
        
        Args:
            mysql_database: The MySQL database being replicated
            target_database: The ClickHouse target database
            
        Returns:
            True if multiple MySQL databases map to the same ClickHouse database
        """
        if not self.target_databases:
            return False
        
        same_target_count = 0
        for mysql_db, ch_db in self.target_databases.items():
            if ch_db == target_database:
                same_target_count += 1
                if same_target_count > 1:
                    return True
        
        return False

    def get_target_table_name(self, source_database: str, source_table: str) -> str:
        key = f'{source_database}.{source_table}'
        return self.target_tables.get(key, source_table)

    def validate(self):
        self.mysql.validate()
        self.clickhouse.validate()
        self.binlog_replicator.validate()
        self.validate_log_level()
        if not isinstance(self.target_databases, dict):
            raise ValueError(f'wrong target databases {self.target_databases}')
        if not isinstance(self.target_tables, dict):
            raise ValueError(f'wrong target tables {self.target_tables}')
        if not isinstance(self.initial_replication_threads, int):
            raise ValueError(f'initial_replication_threads should be an integer, not {type(self.initial_replication_threads)}')
        if self.initial_replication_threads < 0:
            raise ValueError(f'initial_replication_threads should be non-negative')
        self.validate_mysql_timezone()
