from decimal import Decimal
from pybinbot import KucoinRest, KucoinKlineIntervals, OrderType, OrderStatus, DealType
from uuid import uuid4
from time import sleep, time
from typing import List
from pybinbot.models.order import OrderBase
from kucoin_universal_sdk.generate.futures.order import (
    AddOrderReqBuilder,
    GetOrderByOrderIdReqBuilder,
    GetTradeHistoryReqBuilder,
    GetTradeHistoryResp,
    GetTradeHistoryReq,
)
from kucoin_universal_sdk.generate.futures.order.model_add_order_req import AddOrderReq
from kucoin_universal_sdk.generate.futures.order.model_get_order_by_order_id_resp import (
    GetOrderByOrderIdResp,
)
from kucoin_universal_sdk.generate.account.transfer.model_flex_transfer_req import (
    FlexTransferReq,
    FlexTransferReqBuilder,
)
from kucoin_universal_sdk.generate.futures.market import (
    GetKlinesReqBuilder,
    GetSymbolReqBuilder,
    GetPartOrderBookReqBuilder,
)
from kucoin_universal_sdk.generate.account.transfer.model_flex_transfer_resp import (
    FlexTransferResp,
)
from kucoin_universal_sdk.generate.futures.positions.model_modify_margin_leverage_req import (
    ModifyMarginLeverageReqBuilder,
)
from kucoin_universal_sdk.generate.futures.positions.model_modify_margin_leverage_resp import (
    ModifyMarginLeverageResp,
)
from kucoin_universal_sdk.generate.futures.positions.model_get_position_details_req import (
    GetPositionDetailsReqBuilder,
)
from kucoin_universal_sdk.generate.futures.positions.model_get_position_details_resp import (
    GetPositionDetailsResp,
)
from kucoin_universal_sdk.generate.futures.positions import (
    SwitchMarginModeReq,
    SwitchMarginModeReqBuilder,
    SwitchMarginModeResp,
)
from kucoin_universal_sdk.generate.futures.order import (
    CancelAllOrdersV3ReqBuilder,
)
from kucoin_universal_sdk.model.common import RestError
from kucoin_universal_sdk.generate.account.account import (
    GetFuturesAccountReqBuilder,
    GetFuturesAccountResp,
)
from kucoin_universal_sdk.generate.futures.positions.model_get_isolated_margin_risk_limit_resp import (
    GetIsolatedMarginRiskLimitData,
)
from kucoin_universal_sdk.generate.futures.order.model_get_stop_order_list_resp import (
    GetStopOrderListItems,
)
from kucoin_universal_sdk.generate.futures.order import GetStopOrderListReqBuilder
from kucoin_universal_sdk.generate.futures.order.model_batch_cancel_orders_req import (
    BatchCancelOrdersReqBuilder,
)
from kucoin_universal_sdk.generate.futures.order.model_batch_cancel_orders_resp import (
    BatchCancelOrdersResp,
)


class KucoinFutures(KucoinRest):
    """
    Basic Kucoin Futures order endpoints using KucoinApi as base.

    To be replaced in the future with KucoinApi class inheriting from
    Futures API KucoinApi(KucoinFutures) in pybinbot
    """

    def __init__(self, key: str, secret: str, passphrase: str):
        self.DEFAULT_LEVERAGE = 3
        self.DEFAULT_MULTIPLIER = 1
        super().__init__(
            key=key,
            secret=secret,
            passphrase=passphrase,
        )
        self.setup_futures_api()

    def get_symbol_info(self, symbol: str):
        req = GetSymbolReqBuilder().set_symbol(symbol).build()
        return self.futures_market_api.get_symbol(req)

    def _tick_size(self, symbol: str) -> float:
        """
        Cached in production
        """
        info = self.get_symbol_info(symbol)
        if info.tick_size is None:
            raise ValueError(f"tick_size not available for symbol {symbol}")
        return float(info.tick_size)

    def matching_engine(
        self, symbol: str, size: float, side: AddOrderReq.SideEnum
    ) -> float:
        """
        Cross spread by 1 tick max
        """
        req = (
            GetPartOrderBookReqBuilder()
            .set_size(str(int(size)))
            .set_symbol(symbol)
            .build()
        )
        book = self.futures_market_api.get_full_order_book(req)

        tick = Decimal(str(self._tick_size(symbol)))

        if side == AddOrderReq.SideEnum.BUY:
            best_ask = Decimal(book.asks[0][0])
            price = best_ask + tick
        else:
            best_bid = Decimal(book.bids[0][0])
            price = best_bid - tick

        return float(price)

    def buy(
        self,
        symbol: str,
        qty: float,
        reduce_only: bool = False,
    ) -> OrderBase:
        """
        Place an order and get the order
        leverage is set separately via set_futures_leverage
        """
        price = self.matching_engine(symbol, size=qty, side=AddOrderReq.SideEnum.BUY)

        order_resp = self.place_futures_order(
            symbol=symbol,
            side=AddOrderReq.SideEnum.BUY,
            size=int(qty),
            price=price,
            leverage=int(self.DEFAULT_LEVERAGE),
            order_type=OrderType.limit,
            reduce_only=reduce_only,
        )
        return order_resp

    def sell(
        self,
        symbol: str,
        qty: float,
        leverage: int = 1,
        reduce_only: bool = False,
    ) -> OrderBase:
        price = self.matching_engine(symbol, size=qty, side=AddOrderReq.SideEnum.SELL)
        order_resp = self.place_futures_order(
            symbol=symbol,
            side=AddOrderReq.SideEnum.SELL,
            size=qty,
            leverage=leverage,
            price=price,
            order_type=OrderType.limit,
            reduce_only=reduce_only,
        )

        if not order_resp or not order_resp.order_id:
            order_resp = self.place_futures_order(
                symbol=symbol,
                side=AddOrderReq.SideEnum.SELL,
                size=qty,
                leverage=leverage,
                price=price,
                order_type=OrderType.market,
                reduce_only=reduce_only,
            )

        try:
            order_details = self.retrieve_order(str(order_resp.order_id))
            status = OrderStatus.map_from_kucoin_status(order_details.status.value)
            filled_size = float(order_details.filled_size)
            price_used = float(order_details.avg_deal_price)
            timestamp = order_details.created_at
        except RestError as e:
            if float(e.response.code) == 100001:
                # filler response to wait for completion
                order_details = GetOrderByOrderIdResp(
                    order_id=order_resp.order_id,
                    symbol=symbol,
                    side=AddOrderReq.SideEnum.SELL.value,
                    type=AddOrderReq.TypeEnum.LIMIT.value,
                    price=str(price),
                    size=str(qty),
                    filled_size=str(qty),
                    time_in_force=AddOrderReq.TimeInForceEnum.GOOD_TILL_CANCELED.value,
                )
                status = OrderStatus.NEW
                filled_size = qty
                price_used = price
                timestamp = int(time() * 1000)
            else:
                raise e

        return OrderBase(
            order_id=order_resp.order_id,
            order_type=order_details.type.value,
            pair=symbol,
            timestamp=timestamp,
            order_side=order_details.side.value,
            qty=filled_size,
            price=price_used,
            status=status,
            time_in_force=order_details.time_in_force,
            deal_type=DealType.base_order,
        )

    def get_all_stop_loss_orders(self, symbol: str) -> list[GetStopOrderListItems]:
        """
        Get all open stop loss orders for a symbol.
        """
        req = GetStopOrderListReqBuilder().set_symbol(symbol).build()
        book = self.futures_order_api.get_stop_order_list(req)

        return book.items

    def cancel_all_futures_orders(self, symbol: str) -> List[str]:
        """Cancel all open futures orders, optionally filtered by symbol.

        Uses the futures Cancel All Orders V3 endpoint, which supports
        an optional symbol filter. This cancels standard (non-stop)
        futures orders in bulk, rather than one order_id at a time.
        """
        request = CancelAllOrdersV3ReqBuilder().set_symbol(symbol).build()
        # We intentionally ignore the detailed response; any errors will
        # be raised via the transport layer.
        response = self.futures_order_api.cancel_all_orders_v3(request)
        return response.cancelled_order_ids

    def retrieve_order(self, order_id: str) -> GetOrderByOrderIdResp:
        """
        Get order status/details by order_id.
        """
        builder = GetOrderByOrderIdReqBuilder().set_order_id(order_id)
        request = builder.build()
        resp = self.futures_order_api.get_order_by_order_id(request)
        return resp

    def transfer_main_to_futures(
        self, currency: str, amount: float
    ) -> FlexTransferResp:
        """
        Transfer funds from main account to futures account.
        """
        client_oid = str(uuid4())
        req = (
            FlexTransferReqBuilder()
            .set_client_oid(client_oid)
            .set_currency(currency)
            .set_amount(str(amount))
            .set_type(FlexTransferReq.TypeEnum.INTERNAL)
            .set_from_account_type(FlexTransferReq.FromAccountTypeEnum.MAIN)
            .set_to_account_type(FlexTransferReq.ToAccountTypeEnum.CONTRACT)
            .build()
        )
        return self.transfer_api.flex_transfer(req)

    def transfer_trade_to_futures(
        self, currency: str, amount: float
    ) -> FlexTransferResp:
        """
        Transfer funds from trade (spot) account to futures account.
        """
        client_oid = str(uuid4())
        req = (
            FlexTransferReqBuilder()
            .set_client_oid(client_oid)
            .set_currency(currency)
            .set_amount(str(amount))
            .set_type(FlexTransferReq.TypeEnum.INTERNAL)
            .set_from_account_type(FlexTransferReq.FromAccountTypeEnum.TRADE)
            .set_to_account_type(FlexTransferReq.ToAccountTypeEnum.CONTRACT)
            .build()
        )
        return self.transfer_api.flex_transfer(req)

    def get_ui_klines(
        self,
        symbol: str,
        interval: str,
        limit: int = 500,
        start_time=None,
        end_time=None,
    ) -> list[list]:
        """
        Get raw klines/candlestick data from KuCoin Futures.

        Returns Binance-compatible format:
        [open_time_ms, open, high, low, close, volume, close_time_ms]
        """

        # --- Interval ---
        interval_enum = KucoinKlineIntervals(interval)
        granularity = interval_enum.to_minutes()  # e.g., 15
        interval_ms = granularity * 60 * 1000

        builder = GetKlinesReqBuilder().set_symbol(symbol).set_granularity(granularity)

        if start_time:
            builder.set_from_(int(start_time))

        if end_time:
            builder.set_to(int(end_time))

        request = builder.build()
        response = self.futures_market_api.get_klines(request)

        # --- Parse response ---
        klines = []
        for kline in response.data:
            open_time_ms = int(kline[0])
            open_price = float(kline[1])
            high_price = float(kline[2])
            low_price = float(kline[3])
            close_price = float(kline[4])
            volume = float(kline[5])

            close_time_ms = open_time_ms + interval_ms - 1

            klines.append(
                [
                    open_time_ms,
                    open_price,
                    high_price,
                    low_price,
                    close_price,
                    volume,
                    close_time_ms,
                ]
            )

        # Safety: ensure sorted
        klines.sort(key=lambda x: x[0])

        return klines[-limit:]

    def set_futures_leverage(
        self, symbol: str, leverage: int
    ) -> ModifyMarginLeverageResp:
        """Set cross-margin leverage for a futures symbol.

        This uses the Kucoin futures positions API `modify_margin_leverage` endpoint.
        """
        req = (
            ModifyMarginLeverageReqBuilder()
            .set_symbol(symbol)
            .set_leverage(str(leverage))
            .build()
        )
        return self.futures_positions_api.modify_margin_leverage(req)

    def set_futures_margin_mode(
        self, symbol: str, margin_mode: SwitchMarginModeReq.MarginModeEnum
    ) -> SwitchMarginModeResp:
        """Set margin mode (ISOLATED or CROSS) for a futures symbol.

        This uses the dedicated futures positions margin-mode endpoint.
        """
        req = (
            SwitchMarginModeReqBuilder()
            .set_symbol(symbol)
            .set_margin_mode(margin_mode)
            .build()
        )
        return self.futures_positions_api.switch_margin_mode(req)

    def get_futures_position(self, symbol: str) -> GetPositionDetailsResp:
        """
        Get current futures position details for a symbol.
        """
        req = GetPositionDetailsReqBuilder().set_symbol(symbol).build()
        return self.futures_positions_api.get_position_details(req)

    def place_futures_order(
        self,
        symbol: str,
        side: AddOrderReq.SideEnum,
        size: float,
        leverage: int = 2,
        order_type: OrderType = OrderType.limit,
        margin_mode: str | None = "ISOLATED",
        reduce_only: bool = False,
        close_order: bool = False,
        price: float | None = None,
        stop: AddOrderReq.StopEnum | None = None,
        stop_price: float | None = None,
        stop_price_type: AddOrderReq.StopPriceTypeEnum | None = None,
    ) -> OrderBase:
        """Place a Kucoin futures order using the official SDK.

        Args:
            symbol: Futures contract symbol, e.g. "BTCUSDTM" or "BTC-USDT" depending on market.
            side: "buy" or "sell" (case-insensitive).
            size: Contract size (lot size) as float.
            price: Limit price as float; required for limit orders.
            leverage: Leverage multiplier.
            order_type: Internal OrderType (limit/market).
            margin_mode: Optional margin mode, "ISOLATED" or "CROSS".
            reduce_only: Optional reduce-only flag.
            close_order: Optional close-position flag.
            stop: Optional stop direction (DOWN/UP). If provided, stop_price and
                stop_price_type must also be set.
            stop_price: Optional stop trigger price. Required when stop is set.
            stop_price_type: Optional stop price type (TP/MP/IP). Required when
                stop is set.
            client_oid: Optional client order id; if omitted a UUID is generated.
        """

        client_oid = str(uuid4())

        # Ensure the symbol-level margin mode is set before placing the order.
        if margin_mode is not None:
            # Map the string ("ISOLATED"/"CROSS") to the futures margin-mode enum
            mm_enum = SwitchMarginModeReq.MarginModeEnum[margin_mode]
            self.set_futures_margin_mode(symbol, mm_enum)

        if order_type == OrderType.limit:
            type_enum = AddOrderReq.TypeEnum.LIMIT
        else:
            type_enum = AddOrderReq.TypeEnum.MARKET

        builder = (
            AddOrderReqBuilder()
            .set_client_oid(client_oid)
            .set_symbol(symbol)
            .set_side(side)
            .set_type(type_enum)
        )

        if leverage is not None:
            builder = builder.set_leverage(str(leverage))

        if price is not None:
            builder = builder.set_price(str(price))

        builder = builder.set_size(int(size))

        if reduce_only is not None:
            builder = builder.set_reduce_only(reduce_only)

        if close_order is not None:
            builder = builder.set_close_order(close_order)

        # Optional stop-loss / take-profit trigger parameters
        if stop is not None:
            if stop_price is None or stop_price_type is None:
                raise ValueError(
                    "stop_price and stop_price_type must be provided when stop is set"
                )
            builder = builder.set_stop(stop)
            builder = builder.set_stop_price(str(stop_price))
            builder = builder.set_stop_price_type(stop_price_type)

        req = builder.build()
        order_resp = self.futures_order_api.add_order(req)

        if not order_resp or not order_resp.order_id:
            order_resp = self.place_futures_order(
                symbol=symbol,
                side=AddOrderReq.SideEnum.BUY,
                size=int(size),
                price=price,
                leverage=int(self.DEFAULT_LEVERAGE),
                order_type=OrderType.market,
                reduce_only=reduce_only,
            )

        # Small delay to allow order to be processed and show up in order details endpoint;
        sleep(5)
        try:
            # Fetch order details as source of truth for status/fills
            order_details = self.retrieve_order(order_resp.order_id)
            # status it he only enum field to help with db consistency
            status = OrderStatus.map_from_kucoin_status(order_details.status.value)
            filled_size = float(order_details.filled_size)
            price_used = float(order_details.avg_deal_price)
            timestamp = order_details.created_at

        except RestError as e:
            if float(e.response.code) == 100001:
                price = order_details.price
                order_details = GetOrderByOrderIdResp(
                    order_id=str(order_resp.order_id),
                    symbol=symbol,
                    side=AddOrderReq.SideEnum.SELL.value,
                    type=AddOrderReq.TypeEnum.LIMIT.value,
                    price=str(price),
                    size=str(size),
                    filled_size=str(size),
                    time_in_force=AddOrderReq.TimeInForceEnum.GOOD_TILL_CANCELED.value,
                )
                status = OrderStatus.NEW
                filled_size = size
                price_used = price
                timestamp = int(time() * 1000)
            else:
                raise e

        return OrderBase(
            order_type=order_details.type.value,
            time_in_force=order_details.time_in_force,
            timestamp=timestamp,
            order_id=order_resp.order_id,
            order_side=order_details.side.value,
            pair=symbol,
            qty=filled_size,
            price=price_used,
            status=status,
            deal_type=DealType.base_order,
        )

    def get_futures_balance(self, fiat) -> GetFuturesAccountResp:
        """
        Get futures account balances.
        """
        req = GetFuturesAccountReqBuilder().set_currency(fiat).build()
        return self.futures_account_api.get_futures_account(req)

    def get_max_allowed_leverage(self, symbol: str, position_notional: float) -> int:
        """
        Returns the maximum leverage allowed for the given symbol
        based on intended position size.
        """

        # 1️⃣ Fetch risk limit tiers
        tiers = self.futures_positions_api.get_isolated_margin_risk_limit(symbol)

        # 2️⃣ Sort tiers by min risk limit ascending
        tiers_sorted: list[GetIsolatedMarginRiskLimitData] = sorted(
            tiers.data, key=lambda t: t.min_risk_limit or 0
        )

        # 3️⃣ Find the tier that matches the position size
        for tier in tiers_sorted:
            max_risk = Decimal(str(tier.max_risk_limit or 0))
            min_risk = Decimal(str(tier.min_risk_limit or 0))
            if min_risk <= position_notional <= max_risk:
                # Use initial_margin to compute max allowed leverage
                if tier.initial_margin:
                    max_leverage = int(Decimal("1") / Decimal(str(tier.initial_margin)))
                    return max_leverage
        # Fallback to last tier
        last_tier = tiers_sorted[-1]
        return int(Decimal("1") / Decimal(str(last_tier.initial_margin)))

    def batch_cancel_stop_loss_orders(self, so_ids: list[str]) -> BatchCancelOrdersResp:
        """
        Cancel multiple stop loss orders by their IDs.
        """
        req = BatchCancelOrdersReqBuilder().set_order_ids_list(so_ids).build()
        return self.futures_order_api.batch_cancel_orders(req)

    def get_fills(
        self,
        order_id: str | None = None,
        symbol: str | None = None,
        side: GetTradeHistoryReq.SideEnum | None = None,
        order_type: GetTradeHistoryReq.TypeEnum | None = None,
        trade_types: str | None = None,
        start_at: int | None = None,
        end_at: int | None = None,
        current_page: int | None = None,
        page_size: int | None = None,
    ) -> GetTradeHistoryResp:
        """Fetch trade fills via GET /api/v1/fills."""

        builder = GetTradeHistoryReqBuilder()

        if order_id is not None:
            builder = builder.set_order_id(order_id)
        if symbol is not None:
            builder = builder.set_symbol(symbol)
        if side is not None:
            builder = builder.set_side(side)
        if order_type is not None:
            builder = builder.set_type(order_type)
        if trade_types is not None:
            builder = builder.set_trade_types(trade_types)
        if start_at is not None:
            builder = builder.set_start_at(start_at)
        if end_at is not None:
            builder = builder.set_end_at(end_at)
        if current_page is not None:
            builder = builder.set_current_page(current_page)
        if page_size is not None:
            builder = builder.set_page_size(page_size)

        req = builder.build()
        return self.futures_order_api.get_trade_history(req)

    def get_open_interest(self, symbol: str) -> str:
        """
        Get the current open interest (in lots) for a futures symbol.

        KuCoin does not expose a dedicated /api/v1/contracts/openInterest
        endpoint.  Open interest is returned as part of the contract details
        from GET /api/v1/contracts/{symbol}, so this method wraps
        ``get_symbol_info`` and extracts the ``open_interest`` field.

        Args:
            symbol: Futures contract symbol, e.g. "XBTUSDTM".

        Returns:
            Open interest as a string representing lots.

        Raises:
            ValueError: If open interest data is not available for the symbol.
        """
        info = self.get_symbol_info(symbol)
        if info.open_interest is None:
            raise ValueError(f"open_interest not available for symbol {symbol}")
        return info.open_interest
