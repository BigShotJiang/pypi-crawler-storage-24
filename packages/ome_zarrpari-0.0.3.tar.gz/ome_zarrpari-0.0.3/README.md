# ome-zarrpari

[![License BSD-3](https://img.shields.io/pypi/l/ome-zarrpari.svg?color=green)](https://github.com/ome-zarr-models/ome-zarrpari/raw/main/LICENSE)
[![PyPI](https://img.shields.io/pypi/v/ome-zarrpari.svg?color=green)](https://pypi.org/project/ome-zarrpari)
[![Python Version](https://img.shields.io/pypi/pyversions/ome-zarrpari.svg?color=green)](https://python.org)
[![tests](https://github.com/ome-zarr-models/ome-zarrpari/workflows/tests/badge.svg)](https://github.com/ome-zarr-models/ome-zarrpari/actions)
[![codecov](https://codecov.io/gh/ome-zarr-models/ome-zarrpari/branch/main/graph/badge.svg)](https://codecov.io/gh/ome-zarr-models/ome-zarrpari)
[![napari hub](https://img.shields.io/endpoint?url=https://api.napari-hub.org/shields/ome-zarrpari)](https://napari-hub.org/plugins/ome-zarrpari)
[![npe2](https://img.shields.io/badge/plugin-npe2-blue?link=https://napari.org/stable/plugins/index.html)](https://napari.org/stable/plugins/index.html)
[![Copier](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/copier-org/copier/master/img/badge/badge-grayscale-inverted-border-purple.json)](https://github.com/copier-org/copier)

A plugin to load and use OME-Zarr data

----------------------------------

This [napari] plugin was generated with [copier] using the [napari-plugin-template] (None).

<!--
Don't miss the full getting started guide to set up your new package:
https://github.com/napari/napari-plugin-template#getting-started

and review the napari docs for plugin developers:
https://napari.org/stable/plugins/index.html
-->

## Installation

You can install `ome-zarrpari` via [pip]:

```
pip install ome-zarrpari
```

If napari is not already installed, you can install `ome-zarrpari` with napari and Qt via:

```
pip install "ome-zarrpari[all]"
```


To install latest development version :

```
pip install git+https://github.com/ome-zarr-models/ome-zarrpari.git
```



## Contributing

Contributions are very welcome. Tests can be run with [tox], please ensure
the coverage at least stays the same before you submit a pull request.

## License

Distributed under the terms of the [BSD-3] license,
"ome-zarrpari" is free and open source software

## Issues

If you encounter any problems, please [file an issue] along with a detailed description.

## Roadmap

1. A widget with a textbox and "load" button to load a single remote OME-Zarr image

[napari]: https://github.com/napari/napari
[copier]: https://copier.readthedocs.io/en/stable/
[@napari]: https://github.com/napari
[MIT]: http://opensource.org/licenses/MIT
[BSD-3]: http://opensource.org/licenses/BSD-3-Clause
[GNU GPL v3.0]: http://www.gnu.org/licenses/gpl-3.0.txt
[GNU LGPL v3.0]: http://www.gnu.org/licenses/lgpl-3.0.txt
[Apache Software License 2.0]: http://www.apache.org/licenses/LICENSE-2.0
[Mozilla Public License 2.0]: https://www.mozilla.org/media/MPL/2.0/index.txt
[napari-plugin-template]: https://github.com/napari/napari-plugin-template

[file an issue]: https://github.com/ome-zarr-models/ome-zarrpari/issues

[napari]: https://github.com/napari/napari
[tox]: https://tox.readthedocs.io/en/latest/
[pip]: https://pypi.org/project/pip/
[PyPI]: https://pypi.org/
