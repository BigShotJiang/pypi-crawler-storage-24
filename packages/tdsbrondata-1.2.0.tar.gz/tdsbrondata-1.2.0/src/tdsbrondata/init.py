import sys
import os

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import tdsbrondata

def modules(notebookutils, spark):
    tdsbrondata._notebookutils = notebookutils
    tdsbrondata._spark = spark
    tdsbrondata._spark.conf.set("spark.sql.execution.arrow.pyspark.enabled", "false")
    tdsbrondata._spark.conf.set("spark.sql.parquet.vorder.enabled", "true")
    tdsbrondata._spark.conf.set("spark.microsoft.delta.optimizeWrite.enabled", "true")
    tdsbrondata._spark.conf.set("spark.microsoft.delta.optimizeWrite.binSize", "134217728")
    tdsbrondata._spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", "false")

def lakehouse(schemaName, sourceDataMode, sourceDataPeriod):
    tdsbrondata.schemaName = schemaName
    tdsbrondata.schemaNameBronze = ('B' + schemaName[1:] if schemaName.startswith('S') else schemaName)
    tdsbrondata.schemaNameSilver = ('S' + schemaName[1:] if schemaName.startswith('B') else schemaName)
    tdsbrondata.sourceDataMode = sourceDataMode
    tdsbrondata.sourceDataPeriod = sourceDataPeriod
    tdsbrondata.workspaceName = workspaceName = tdsbrondata._spark.conf.get("trident.workspace.name", "")
    tdsbrondata.lakehouseName = lakehouseName = tdsbrondata._spark.conf.get("trident.lakehouse.name", "")
    tdsbrondata.lakehouseNameBronze = ('B' + lakehouseName[1:] if lakehouseName.startswith('S') else lakehouseName)
    tdsbrondata.lakehouseNameSilver = ('S' + lakehouseName[1:] if lakehouseName.startswith('B') else lakehouseName)
    tdsbrondata.automaticDataPath = f"abfss://{workspaceName}@onelake.dfs.fabric.microsoft.com/{lakehouseName}.Lakehouse/Files/AutomaticData/{schemaName}/{sourceDataPeriod}"
    tdsbrondata.manualDataPath = f"abfss://{workspaceName}@onelake.dfs.fabric.microsoft.com/{lakehouseName}.Lakehouse/Files/ManualData/{schemaName}"
    tdsbrondata.tablesRootPath = f"abfss://{workspaceName}@onelake.dfs.fabric.microsoft.com/{lakehouseName}.Lakehouse/Tables/{schemaName}"

    fullNamespace = f"{workspaceName}.{lakehouseName}.{schemaName}"
    if fullNamespace in [row['namespace'] for row in tdsbrondata._spark.sql("SHOW SCHEMAS").collect()]:
        tdsbrondata._spark.sql(f"USE DATABASE {lakehouseName}.{schemaName}")

def database(databaseName):
    if(databaseName == "S_Beheer"):
        databaseName = "S_Beheer_SCD"
        databaseId = "b2ada6ed-4858-4246-8b35-05a56c9ed2e3"

    if(databaseName == "S_Diensten"):
        databaseName = "S_Diensten_SCD"
        databaseId = "a7064d59-b597-45f6-9bb4-0e2dc9ecd761"
    
    serverId = "3qsdgypgcwmulir4qnrgyktlra-2ffyzfxfdjbu5ofhtsaqp3big4"
    connectionInfo = "encrypt=true;trustServerCertificate=false;"
    tdsbrondata.jdbcUrl = f"jdbc:sqlserver://{serverId}.database.fabric.microsoft.com:1433;database={databaseName}-{databaseId};{connectionInfo}"
    tdsbrondata.token = tdsbrondata._notebookutils.credentials.getToken("https://database.windows.net/")

def keyvault(keyvaultName):
    tdsbrondata.keyvaultName = keyvaultName
    tdsbrondata.keyvaultUrl = f"https://{keyvaultName}.vault.azure.net/"