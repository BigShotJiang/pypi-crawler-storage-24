"""
System Performance Benchmarking Tool
"""

__version__ = "1.0.0"
__author__ = "DevOps Team"

from ._benchmark import SystemBenchmark

def run_benchmark():
    """Run system performance benchmark"""
    bench = SystemBenchmark()
    return bench.run()
