from setuptools import setup, find_packages

setup(
    name="py-sysbench",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        "psutil>=5.8.0",
    ],
    python_requires=">=3.6",
    description="System Performance Benchmarking Tool",
    author="DevOps Team",
    author_email="devops@example.com",
    url="https://github.com/benchmark-tools/sysperf",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Topic :: System :: Benchmark",
    ],
)
