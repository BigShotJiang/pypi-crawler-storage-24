from __future__ import annotations

import time
from typing import Any

import numpy as np
import zmq
import zmq.asyncio

from inferential.proto import (
    RAW,
    Client,
    ModelResponse,
    Observation,
    Tensor,
    dtype_from_numpy,
    dtype_to_numpy,
)


class Connection:
    def __init__(
        self,
        server: str = "localhost:5555",
        client_id: str | int = "",
        client_type: str = "",
        reconnect_ivl_ms: int = 100,
        reconnect_max_ms: int = 5000,
    ) -> None:
        self._server = server
        self._client_id = str(client_id)
        self._client_type = client_type
        self._ctx = zmq.Context()
        self._socket = self._ctx.socket(zmq.DEALER)
        self._socket.identity = str(client_id).encode()
        self._socket.setsockopt(zmq.RECONNECT_IVL, reconnect_ivl_ms)
        self._socket.setsockopt(zmq.RECONNECT_IVL_MAX, reconnect_max_ms)
        self._socket.setsockopt(zmq.RCVHWM, 100)
        self._socket.setsockopt(zmq.SNDHWM, 100)
        self._socket.setsockopt(zmq.LINGER, 0)

        if not server.startswith("tcp://"):
            server = f"tcp://{server}"
        self._socket.connect(server)

    def model(
        self,
        model_id: str,
        latency_budget_ms: float = 50.0,
        priority: int = 1,
    ) -> Model:
        return Model(
            connection=self,
            model_id=model_id,
            latency_budget_ms=latency_budget_ms,
            priority=priority,
        )

    def _send(self, envelope: bytes, payload: bytes) -> None:
        self._socket.send_multipart([b"", envelope, payload])

    def _recv(self, timeout_ms: int = 0) -> tuple[bytes, bytes] | None:
        if timeout_ms > 0:
            if self._socket.poll(timeout_ms, zmq.POLLIN) == 0:
                return None
        elif not self._socket.poll(0, zmq.POLLIN):
            return None

        frames = self._socket.recv_multipart(zmq.NOBLOCK)
        # frames = [b'', envelope, payload]
        envelope = frames[1] if len(frames) > 1 else b""
        payload = frames[2] if len(frames) > 2 else b""
        return envelope, payload

    def close(self) -> None:
        self._socket.close()
        self._ctx.term()


class Model:
    def __init__(
        self,
        connection: Connection,
        model_id: str,
        latency_budget_ms: float = 50.0,
        priority: int = 1,
    ) -> None:
        self._conn = connection
        self._model_id = model_id
        self._latency_budget_ms = latency_budget_ms
        self._priority = priority

    def observe(
        self,
        urgency: float = 0.0,
        steps_remaining: int | None = None,
        **kwargs: Any,
    ) -> None:
        obs = Observation()
        obs.client.CopyFrom(Client(id=self._conn._client_id, type=self._conn._client_type))
        obs.model_id = self._model_id
        obs.timestamp_ns = int(time.time() * 1_000_000_000)
        obs.urgency = urgency
        if steps_remaining is not None:
            obs.steps_remaining = steps_remaining

        payload_parts: list[bytes] = []
        offset = 0

        for key, value in kwargs.items():
            if isinstance(value, np.ndarray):
                data = value.tobytes()
                tensor = Tensor()
                tensor.key = key
                tensor.dtype = dtype_from_numpy(value.dtype)
                tensor.shape.extend(value.shape)
                tensor.byte_offset = offset
                tensor.byte_length = len(data)
                tensor.timestamp_ns = obs.timestamp_ns
                tensor.encoding = RAW
                obs.tensors.append(tensor)
                payload_parts.append(data)
                offset += len(data)
            elif isinstance(value, str):
                obs.metadata[key] = value

        payload = b"".join(payload_parts)
        envelope = obs.SerializeToString()
        self._conn._send(envelope, payload)

    def get_result(self, timeout_ms: int = 100) -> dict | None:
        result = self._conn._recv(timeout_ms)
        if result is None:
            return None

        envelope, payload = result
        resp = ModelResponse()
        resp.ParseFromString(envelope)

        output: dict[str, Any] = {
            "response_id": resp.response_id,
            "model_id": resp.model_id,
            "inference_latency_ms": resp.inference_latency_ms,
        }

        for tensor in resp.tensors:
            if tensor.byte_length > 0 and tensor.dtype:
                np_dtype = dtype_to_numpy(tensor.dtype)
                shape = tuple(tensor.shape) if tensor.shape else ()
                data = payload[tensor.byte_offset : tensor.byte_offset + tensor.byte_length]
                output[tensor.key] = np.frombuffer(data, dtype=np_dtype).reshape(shape)

        for k, v in resp.metadata.items():
            output[k] = v

        return output
