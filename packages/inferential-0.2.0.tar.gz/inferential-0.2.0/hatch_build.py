"""Hatchling build hook to generate protobuf code at build time."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

from hatchling.builders.hooks.plugin.interface import BuildHookInterface


class ProtobufBuildHook(BuildHookInterface):
    PLUGIN_NAME = "protobuf"

    def initialize(self, version: str, build_data: dict) -> None:
        proto_dir = Path(self.root) / "inferential" / "proto"
        proto_file = proto_dir / "inferential.proto"

        if not proto_file.exists():
            return

        subprocess.check_call(
            [
                sys.executable,
                "-m",
                "grpc_tools.protoc",
                f"--proto_path={proto_dir}",
                f"--python_out={proto_dir}",
                f"--pyi_out={proto_dir}",
                str(proto_file),
            ]
        )
