#!/usr/bin/env bash
set -euo pipefail

PROTO_DIR="$(cd "$(dirname "$0")/.." && pwd)/inferential/proto"

python -m grpc_tools.protoc \
    --proto_path="$PROTO_DIR" \
    --python_out="$PROTO_DIR" \
    --pyi_out="$PROTO_DIR" \
    "$PROTO_DIR/inferential.proto"

echo "Generated inferential_pb2.py"
