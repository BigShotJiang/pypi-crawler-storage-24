# Examples

The `examples/` directory contains ready-to-run demos. This guide walks through each one.

## Server Demo

**File**: `examples/server_demo.py`

A Ray Serve deployment with an Inferential server that logs metrics.

```bash
ray start --head
python examples/server_demo.py
```

### What It Does

1. Deploys a `MockPolicy` model as a Ray Serve app named `policy-v2`
2. Starts an Inferential server on `tcp://*:5555` with the deadline-aware scheduler
3. Registers a metric callback that prints latency, staleness, wait times, and errors

### The Model

The `MockPolicy.infer()` method receives a dict of numpy arrays and returns a dict. The dispatcher handles deserialization (protobuf bytes to numpy) and serialization (any array-like back to bytes).

```python
@serve.deployment
class MockPolicy:
    def infer(self, obs: dict) -> dict:
        dim = 7
        for v in obs.values():
            if isinstance(v, np.ndarray) and v.ndim == 1:
                dim = v.shape[0]
                break
        return {"actions": np.random.randn(dim).astype(np.float32)}
```

Replace this with your real model. The return value can be any array-like (numpy, PyTorch, JAX, TensorFlow) — the dispatcher converts via `np.asarray()`.

### Metric Callback

The `@server.on_metric` decorator registers a callback that fires on every metric recording:

```python
@server.on_metric
def log_metrics(name: str, value: float, labels: dict) -> None:
    client = labels.get("client", "")
    prefix = f"  [{client}]" if client else " "
    if name in ("inference_latency_ms", "observation_staleness_ms",
                 "scheduling_wait_ms", "e2e_latency_ms"):
        print(f"{prefix} {name}: {value:.1f}ms")
    elif name in ("queue_full_drops", "dispatch_errors", "dispatch_retries",
                   "requests_expired", "client_disconnected", "observation_errors"):
        print(f"{prefix} {name}: {value:.0f}")
```

This logs timing metrics with millisecond precision and error/warning metrics as counts. Metrics like `queue_depth` and `batch_size` are intentionally skipped to reduce noise.

## Client Demo

**File**: `examples/client_demo.py`

A simulated client (or multiple clients) sending observations at a configurable rate.

### Single Client

```bash
python examples/client_demo.py
```

Default: 1 client at 20Hz for 100 steps.

### Multiple Clients

```bash
python examples/client_demo.py --clients 4
```

Spawns 4 threads, each running an independent client (`sim-01` through `sim-04`).

### CLI Flags

| Flag | Default | Description |
|------|---------|-------------|
| `--server` | `tcp://localhost:5555` | Server address |
| `--clients` | `1` | Number of parallel clients |
| `--hz` | `20.0` | Request frequency per client |
| `--steps` | `100` | Number of observations per client |

### What Each Client Does

1. Connects to the server with a unique ID (`sim-01`, `sim-02`, etc.)
2. Sends a random 7-dimensional state vector at the specified rate
3. Reads the response and prints actions + latency every 20 steps
4. Reports total responses received at the end

```
[sim-01] starting — 20.0Hz, 100 steps
[sim-01] step 0: actions=[0.69 0.08 0.65]... latency=12.2ms
[sim-01] step 20: actions=[0.88 -1.59 0.60]... latency=2.0ms
[sim-01] step 40: actions=[-0.31 0.55 1.22]... latency=1.5ms
[sim-01] step 60: actions=[0.91 -0.18 0.03]... latency=1.3ms
[sim-01] step 80: actions=[0.42 -1.07 0.83]... latency=1.1ms
[sim-01] done — received 100/100 responses
```

## Running Both Together

Terminal 1 — start the server:

```bash
ray start --head
python examples/server_demo.py
```

Wait for `Application 'policy-v2' is ready`.

Terminal 2 — run clients:

```bash
# 4 clients at 10Hz, 50 steps each
python examples/client_demo.py --clients 4 --hz 10 --steps 50
```

Server output shows per-client metrics:

```
  [sim-01] inference_latency_ms: 12.2ms
  [sim-02] inference_latency_ms: 1.1ms
  [sim-01] scheduling_wait_ms: 0.3ms
  [sim-02] scheduling_wait_ms: 0.1ms
  [sim-03] e2e_latency_ms: 2.1ms
  ...
```

Client output shows responses:

```
[sim-01] starting — 10.0Hz, 50 steps
[sim-02] starting — 10.0Hz, 50 steps
[sim-03] starting — 10.0Hz, 50 steps
[sim-04] starting — 10.0Hz, 50 steps
[sim-01] step 0: actions=[0.69 0.08 0.65]... latency=12.2ms
[sim-02] step 0: actions=[0.73 0.20 -0.96]... latency=1.2ms
...
[sim-01] done — received 50/50 responses
[sim-02] done — received 50/50 responses
[sim-03] done — received 50/50 responses
[sim-04] done — received 50/50 responses
```

## Extending the Examples

### Swap Scheduler

```python
server.use_scheduler("round_robin")
server.use_scheduler("batch_optimized")
server.use_scheduler("priority_tiered")
```

### Custom Scoring

```python
from inferential import register_policy, InferenceRequest

@register_policy("latency_first")
def score(req: InferenceRequest) -> float:
    return 1.0 / max(req.latency_budget_ms, 1.0)

server.use_scheduler("deadline_aware", policy="latency_first")
```

### Real Model

Replace `MockPolicy` with your model. The `infer()` method receives numpy arrays and can return any array-like:

```python
@serve.deployment(num_replicas=2, ray_actor_options={"num_gpus": 1})
class MyModel:
    def __init__(self):
        self.model = load_model("weights.pt")

    def infer(self, obs: dict) -> dict:
        # obs["state"] is np.ndarray — convert to your framework as needed
        return {"actions": self.model.predict(obs["state"])}
```

### Queue Tuning

```python
server = Server(
    bind="tcp://*:5555",
    models=["policy-v2"],
    config=InferentialConfig(
        scheduling={
            "strategy": "deadline_aware",
            "request_ttl_ms": 2000,
            "overflow_policy": "drop_oldest",
            "max_retries": 2,
        }
    ),
)
```
