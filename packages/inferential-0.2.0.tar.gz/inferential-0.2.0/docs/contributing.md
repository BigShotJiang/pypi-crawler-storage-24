# Contributing

## Setup

```bash
# Clone and install dev dependencies
git clone https://github.com/inferential-sh/inferential.git
cd inferential
pip install -e ".[dev]"

# Generate protobuf code
make proto

# Install pre-commit hooks
pre-commit install
```

## Pre-commit Hooks

The following run automatically on every commit:

| Hook | What it does |
|------|-------------|
| **Ruff lint** | Catches errors, unused imports, style violations (`--fix` applied automatically) |
| **Ruff format** | Enforces consistent code formatting |
| **Mypy** | Static type checking with `--ignore-missing-imports` |
| **Trailing whitespace** | Removes trailing whitespace from all files |
| **End-of-file fixer** | Ensures files end with a single newline |
| **check-yaml** | Validates YAML syntax |
| **check-toml** | Validates TOML syntax |

If a hook fails, it will either auto-fix the file (ruff lint/format, whitespace) or print the error (mypy). Stage the fixes and commit again.

## Commit Messages

We follow [Conventional Commits](https://www.conventionalcommits.org/).

### Format

```
<type>(<scope>): <subject>

[optional body]

[optional footer]
```

### Types

| Type | When to use |
|------|-------------|
| `feat` | New feature or capability |
| `fix` | Bug fix |
| `refactor` | Code change that neither fixes a bug nor adds a feature |
| `perf` | Performance improvement |
| `docs` | Documentation only |
| `test` | Adding or updating tests |
| `ci` | CI/CD pipeline changes (workflows, pre-commit) |
| `build` | Build system or dependency changes (pyproject.toml, Makefile) |
| `chore` | Maintenance tasks that don't fit above |

### Scopes

Use the module or area being changed:

| Scope | Area |
|-------|------|
| `scheduler` | Scheduler strategies, base class, policies |
| `dispatch` | Dispatcher, health tracking |
| `transport` | ZMQ transport layer |
| `proto` | Protobuf schema, codegen, dtype/encoding mappings |
| `client` | Client SDK (Connection, ModelHandle) |
| `server` | Server orchestration loop |
| `metrics` | Metrics pipeline, ring buffer |
| `tracking` | Cadence tracker, response tracker |
| `examples` | Example scripts |
| `deps` | Dependency changes |

Scope is optional but encouraged for non-trivial changes.

### Subject line rules

- Imperative mood: "add feature" not "added feature" or "adds feature"
- Lowercase first letter
- No period at the end
- Max 72 characters

### Examples

```
feat(scheduler): add batch-optimized scheduling strategy

fix(dispatch): handle non-numpy model responses with np.asarray

refactor(proto): use DType/Encoding types instead of raw int

docs: add architecture and quickstart guides

test(scheduler): add TTL expiry edge case tests

ci: bump actions/checkout to v6 for Node.js 24

build(deps): add mypy and pre-commit to dev dependencies

perf(transport): reduce ZMQ send copies with zero-copy frames
```

### Breaking changes

Add `!` after the type/scope and explain in the footer:

```
feat(proto)!: rename Observation.metadata to Observation.labels

BREAKING CHANGE: Observation.metadata field renamed to labels.
Existing serialized messages are incompatible.
```

### Multi-line body

Use the body for context when the subject isn't enough:

```
fix(scheduler): expire stale requests before batch assembly

Requests were only checked for TTL expiry during tick(), but
long-running dispatches could leave expired requests in the
queue until the next tick. Now next_batch() also filters expired
requests before returning.
```

## Branching

| Branch | Purpose |
|--------|---------|
| `main` | Stable, release-ready code |
| `feat/<name>` | New features |
| `fix/<name>` | Bug fixes |
| `refactor/<name>` | Refactoring |
| `docs/<name>` | Documentation |

Always branch from `main`. Keep branches short-lived.

## Pull Requests

1. One logical change per PR
2. PR title follows the same conventional commit format
3. Ensure CI passes (lint + tests on Python 3.11 and 3.12)
4. Squash merge into `main`

## Releases

Releases are triggered by pushing a version tag:

```bash
# Bump version in pyproject.toml, then:
git tag v0.2.0
git push origin v0.2.0
```

This triggers the publish workflow which runs tests, builds the package, and publishes to PyPI.

### Version format

We use [Semantic Versioning](https://semver.org/):

- **MAJOR** (`1.0.0` → `2.0.0`): Breaking changes to public API
- **MINOR** (`0.1.0` → `0.2.0`): New features, backward-compatible
- **PATCH** (`0.1.0` → `0.1.1`): Bug fixes, backward-compatible

## Code Style

- **Python 3.11+** — use `X | Y` union syntax, not `Union[X, Y]`
- **Line length**: 100 characters (configured in `pyproject.toml`)
- **Imports**: sorted by ruff (isort-compatible) — constants first, then classes
- **Type hints**: required on all function signatures (`disallow_untyped_defs = true`)
- **Protobuf enums**: use `DType`/`Encoding` types, not raw `int`
- **Generated files**: `inferential_pb2.py` and `inferential_pb2.pyi` are excluded from linting/formatting

## Running Checks Manually

```bash
# All at once
make lint

# Individual
uv run ruff check inferential/              # lint
uv run ruff format inferential/ tests/      # format
uv run mypy inferential/ --ignore-missing-imports  # type check
uv run pytest tests/                        # tests
```
