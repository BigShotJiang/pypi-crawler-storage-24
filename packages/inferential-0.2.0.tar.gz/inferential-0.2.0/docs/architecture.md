# Architecture

## System Overview

Inferential sits between your clients and your ML models. Clients send observations over ZMQ, the server schedules and dispatches inference to Ray Serve, and streams results back.

```
                        Inferential Server
                  ┌──────────────────────────────┐
                  │                              │
  Client A ──ZMQ──┤  Assembler ──► Scheduler     │
  Client B ──ZMQ──┤                  │           │
  Client C ──ZMQ──┤              next_batch()    │
                  │                  │           │
                  │              Dispatcher ─────┼──► Ray Serve
                  │                  │           │    (model replicas)
                  │              responses       │
                  │                  │           │
  Client A ◄─ZMQ─┤  Transport ◄────┘           │
  Client B ◄─ZMQ─┤                              │
  Client C ◄─ZMQ─┤  Metrics   Cadence   Health  │
                  └──────────────────────────────┘
```

### Data Flow

1. **Client** serializes numpy arrays + metadata into a protobuf envelope and binary payload, sends over ZMQ
2. **Transport** (ROUTER socket) receives the multipart message, tags it with identity and `received_at`
3. **Assembler** parses the protobuf envelope, validates tensor slots against the payload, extracts client/model info
4. **Server** updates cadence tracking, client registry, and metrics, then builds an `InferenceRequest`
5. **Scheduler** queues the request and scores/orders it according to its strategy
6. **Dispatcher** pulls the next batch, deserializes tensors back to numpy dicts, calls `model.infer()` via Ray Serve handles
7. **Response** is serialized back to protobuf + binary and sent to the client over ZMQ

## Wire Protocol

Messages use protobuf serialization over ZMQ multipart frames:

```
[identity | "" | envelope (protobuf bytes) | payload (binary tensors)]
```

The envelope contains metadata (client info, model ID, tensor descriptors with dtype/shape/offset), while the payload is a single concatenated binary buffer holding all tensor data. This two-part design keeps metadata parseable without touching the tensor bytes.

### Observation (client -> server)

```protobuf
message Observation {
    Client client = 1;           // id + type
    uint64 timestamp_ns = 2;
    float urgency = 3;           // 0.0 (low) to 1.0 (critical)
    repeated Tensor tensors = 4; // descriptors with byte_offset into payload
    string model_id = 5;
    optional uint32 steps_remaining = 6;
    map<string, string> metadata = 7;
}
```

### ModelResponse (server -> client)

```protobuf
message ModelResponse {
    Client client = 1;
    string response_id = 2;
    uint64 timestamp_ns = 3;
    repeated Tensor tensors = 4;
    float inference_latency_ms = 5;
    string model_id = 6;
    map<string, string> metadata = 7;
}
```

### Supported Types

| Tensor DType | NumPy | Notes |
|---|---|---|
| `FLOAT16` | `float16` | |
| `FLOAT32` | `float32` | |
| `FLOAT64` | `float64` | |
| `BFLOAT16` | `float16` | Mapped to float16 (numpy has no native bfloat16) |
| `UINT8` | `uint8` | |
| `INT32` | `int32` | |
| `INT64` | `int64` | |
| `BOOL` | `bool` | |

Supported encodings: `RAW`, `JPEG`, `PNG`.

## Tensor Handling

The system is **framework-agnostic**. Tensors travel as numpy arrays over the wire.

**Client side**: `model.observe()` accepts numpy arrays. They are serialized via `ndarray.tobytes()` with dtype/shape metadata in the protobuf envelope.

**Server side (input)**: The dispatcher deserializes binary back to numpy dicts using `np.frombuffer()` (zero-copy). The `infer()` method receives a `dict[str, np.ndarray]`.

**Server side (output)**: The dispatcher accepts any array-like return from `infer()` — numpy, PyTorch, JAX, TensorFlow — and converts via `np.asarray()`. If the model returns a raw numpy array, no copy occurs.

## Observation API

`model.observe()` accepts keyword arguments:

- **`np.ndarray`** values are serialized as tensors with full dtype/shape metadata
- **`str`** values are passed as metadata key-value pairs
- **`urgency`** (float, 0.0-1.0) — hints how time-critical this request is
- **`steps_remaining`** (int, optional) — remaining steps in the current trajectory

```python
model.observe(
    urgency=0.5,
    steps_remaining=120,
    state_vector=np.zeros(7, dtype=np.float32),
    image=np.zeros((3, 224, 224), dtype=np.uint8),
    prompt="describe the scene",  # goes to metadata
)
```

## Schedulers

Four built-in strategies. Each implements the `Scheduler` ABC and can be used standalone or via the server.

| Strategy | Data Structure | Description |
|----------|---------------|-------------|
| `deadline_aware` | heapq | Weighted scoring: cadence, urgency, priority, age (default) |
| `batch_optimized` | dict of deques | Groups requests per model, flushes on size or time threshold |
| `priority_tiered` | list of deques | Strict priority tiers (0=highest), FIFO within each tier |
| `round_robin` | OrderedDict of deques | Fair rotation across clients |

### Standalone Usage

```python
from inferential.scheduler.base import create_scheduler
from inferential.config.schema import SchedulingConfig

scheduler = create_scheduler(SchedulingConfig(strategy="batch_optimized"))
scheduler.submit(request)
batch = scheduler.next_batch()
```

### Via Server

```python
server.use_scheduler("deadline_aware", cadence_weight=50.0, urgency_weight=30.0)
```

### Custom Scoring Policy

Override how the deadline-aware scheduler scores requests:

```python
from inferential import register_policy, InferenceRequest

@register_policy("safety_first")
def score(req: InferenceRequest) -> float:
    if req.urgency > 0.9:
        return 1000.0
    return req.priority * 10.0

server.use_scheduler("deadline_aware", policy="safety_first")
```

### Custom Scheduler

Implement the `Scheduler` interface:

```python
from inferential.scheduler.base import Scheduler, register_scheduler

@register_scheduler("my_scheduler")
class MyScheduler(Scheduler):
    def __init__(self, config):
        self._queue = []

    def submit(self, request):
        self._queue.append(request)

    def next_batch(self):
        batch, self._queue = self._queue[:8], self._queue[8:]
        return batch

    def tick(self):
        return 0  # number of expired requests

    def status(self):
        return {"queue_len": len(self._queue)}

    def queue_len(self):
        return len(self._queue)

server.use_scheduler("my_scheduler")
```

## Queue Management

The scheduler queue supports TTL, overflow policies, and dispatch retry:

| Parameter | Default | Description |
|-----------|---------|-------------|
| `request_ttl_ms` | 5000 | Drop queued requests older than this (avoids wasting GPU on stale data) |
| `overflow_policy` | `"drop_oldest"` | What to do when the queue is full: `"drop_oldest"` evicts the stalest request, `"reject_newest"` drops the incoming one |
| `max_retries` | 0 | Re-queue failed dispatches up to N times before dropping |

TTL is enforced in `tick()` which runs at 10Hz. Each scheduler purges expired requests from its data structure and returns the count.

Overflow policy is enforced in `submit()`. When the queue is at capacity:
- **`drop_oldest`**: finds and removes the oldest/lowest-priority request, then inserts the new one
- **`reject_newest`**: raises `QueueFullError`, dropping the incoming request

Dispatch retry uses `resubmit()` which bypasses overflow checks. The request's `retry_count` is incremented and it re-enters the queue.

## Metrics

In-memory ring-buffer metrics with label filtering and percentile stats.

```python
# Register a callback
@server.on_metric
def log(name, value, labels):
    print(f"{name}: {value}")

# Query stats
stats = server.metrics.get_stats("inference_latency_ms", window_seconds=60)
print(f"p95: {stats.p95:.1f}ms")

# Latest value
depth = server.metrics.get_latest("queue_depth")

# Full snapshot
snapshot = server.metrics.snapshot()
```

### Tracked Metrics

| Metric | Labels | Description |
|--------|--------|-------------|
| `inference_latency_ms` | `client` | Time spent in Ray Serve model |
| `scheduling_wait_ms` | `client` | Time request sat in queue before dispatch |
| `e2e_latency_ms` | `client` | Total server-side time (queue wait + inference) |
| `observation_staleness_ms` | `client` | Age of observation on arrival |
| `payload_size_bytes` | `client` | Size of binary tensor payload |
| `queue_depth` | — | Scheduler queue length at dispatch time |
| `batch_size` | — | Number of requests per dispatch batch |
| `active_clients` | — | Currently connected client count |
| `queue_full_drops` | `client` | Requests dropped due to full queue |
| `dispatch_errors` | `client`, `error` | Failed dispatches (after retries exhausted) |
| `dispatch_retries` | `client` | Dispatch retry attempts |
| `requests_expired` | — | Requests dropped by TTL |
| `observation_errors` | — | Malformed observations |
| `client_disconnected` | `client` | Client disconnect events |

## Configuration

```python
from inferential.config import InferentialConfig

config = InferentialConfig(
    transport={"bind": "tcp://*:5555", "recv_hwm": 2000},
    scheduling={
        "strategy": "deadline_aware",
        "max_queue_size": 500,
        "request_ttl_ms": 3000,
        "overflow_policy": "drop_oldest",
        "max_retries": 1,
    },
    clients={
        "defaults": {"latency_budget_ms": 50.0, "priority": 1},
        "known": [
            {"id": "agent-01", "model": "policy-v2", "latency_budget_ms": 30.0, "priority": 2},
        ],
        "accept_unknown": True,
    },
    response_tracking={"cadence_alpha": 0.3, "disconnect_timeout_s": 10.0},
    metrics={"ring_buffer_size": 10000},
)

server = Server(config=config)
```
