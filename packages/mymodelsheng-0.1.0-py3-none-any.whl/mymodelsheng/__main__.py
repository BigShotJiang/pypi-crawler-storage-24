# 以模块运行的入口文件
from mymodelsheng import main

main()
