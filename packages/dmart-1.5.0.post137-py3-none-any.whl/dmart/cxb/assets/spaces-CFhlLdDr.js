import{w as s}from"./svelte-CUJGDAhG.js";const o=s(null);export{o as s};
