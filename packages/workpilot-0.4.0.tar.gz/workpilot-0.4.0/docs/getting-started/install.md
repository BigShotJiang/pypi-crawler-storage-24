# Install WorkPilot

## Requirements

- Python 3.11 or later
- A supported LLM provider (GitHub Copilot recommended)

## Install

### From PyPI

```bash
pip install workpilot
```

To include all optional features (browser automation, gateway server, scheduler):

```bash
pip install "workpilot[all]"
```

### From source

```bash
git clone https://github.com/your-org/workpilot.git
cd workpilot
pip install -e ".[all]"
```

## Initialize a project

Run the interactive setup wizard to create a local config file:

```bash
workpilot init
```

The wizard will:

1. Sign in with GitHub to enable Copilot access (recommended)
2. Ask for a default model (press Enter to use `auto`)
3. Ask for a security profile (`standard` is the default)
4. Optionally enable the HTTP gateway server

This creates `workpilot.local.yaml` in your current directory. This file is gitignored and holds your personal settings and API keys. The main `workpilot.yaml` (if present) holds team settings and should be committed.

You can run `workpilot init` again at any time to change settings.

## Verify the installation

```bash
workpilot doctor
```

This checks your Python version, configuration, provider keys, and optional dependencies, and reports any issues.

```bash
workpilot version
```

Prints the installed version.

## Optional dependencies

Some features require additional packages:

| Feature | Install command |
|---------|----------------|
| HTTP gateway / browser chat | `pip install fastapi uvicorn` |
| Scheduled jobs | `pip install apscheduler` |
| Browser automation | `pip install playwright && playwright install msedge` |
| All of the above | `pip install "workpilot[all]"` |

## Next step

[Start your first chat](first-chat.md)
