# Your First Chat

This guide walks you through having your first conversation with WorkPilot.

## Start the interactive REPL

```bash
workpilot chat
```

You will see a prompt:

```
you>
```

Type anything and press Enter. WorkPilot will respond.

```
you> What files are in this directory?
```

The agent will list the files using its built-in file tools.

## Try a few things

```
you> Summarise what this project does
you> Find all Python files that import requests
you> What does the function process_order do in orders.py?
you> Write a unit test for the calculate_total function
```

WorkPilot reads files, runs git commands, and searches the codebase to answer your questions. It can also make changes if you ask it to.

## Slash commands

Inside the REPL, these commands are available:

| Command | What it does |
|---------|-------------|
| `/help` | Show available slash commands |
| `/new` | Clear the current session and start fresh |
| `/status` | Show agent name, model, session ID, and message count |
| `/memory` | Show the contents of MEMORY.md (persistent facts) |
| `/tools` | List available tools |
| `/skills` | List loaded skills |
| `/history` | Show the last 10 messages |
| `/history 20` | Show the last 20 messages |
| `/stop` | Interrupt hint (use Ctrl+C to actually interrupt) |
| `/exit` | Exit hint (use Ctrl+C to exit) |

## Exit

Press `Ctrl+C` to exit the REPL.

## Run a one-shot command

If you want to run a single prompt without the interactive REPL:

```bash
workpilot run "List all TODO comments in the codebase"
```

This runs the agent once, prints the response, and exits. Useful for scripting or quick checks.

## Check the status

```bash
workpilot status
```

Shows which agents, channels, and features are active, and what security profile is in use.

## Next steps

- [Terminal channel](../channels/terminal.md) — all terminal commands and options
- [Browser channel](../channels/browser.md) — use WorkPilot from a web browser
- [Teams channel](../channels/teams.md) — chat with WorkPilot in Microsoft Teams
