# WorkPilot v0.3.0 — User Documentation

WorkPilot is an enterprise AI assistant that runs on your own machine. It can write and review code, automate tasks, search the web, interact with Git and Azure DevOps, and chat with you through a terminal, a browser, or Microsoft Teams — all while keeping your data local.

## Documentation

### Getting Started

| Guide | Description |
|-------|-------------|
| [Install](getting-started/install.md) | Install WorkPilot and set up your provider |
| [First Chat](getting-started/first-chat.md) | Run your first conversation |

### Channels

| Guide | Description |
|-------|-------------|
| [Terminal](channels/terminal.md) | Interactive REPL and one-shot commands |
| [Browser](channels/browser.md) | Web chat UI and REST API |
| [Teams](channels/teams.md) | Chat with WorkPilot in Microsoft Teams |

### Features

| Guide | Description |
|-------|-------------|
| [Copilot Tasks](features/copilot-tasks.md) | Delegate coding tasks to GitHub Copilot |
| [Scheduling](features/scheduling.md) | Run agent tasks on a schedule |
| [Sessions](features/sessions.md) | Manage conversation history |
| [Skills](features/skills.md) | Extend the agent with custom skill files |

### Admin

| Guide | Description |
|-------|-------------|
| [Portal](admin/portal.md) | Web admin portal for monitoring and control |
| [Security](admin/security.md) | Security profiles, RBAC, and audit logging |

### Reference

| Guide | Description |
|-------|-------------|
| [Commands](reference/commands.md) | Full CLI command reference |
| [Configuration](reference/configuration.md) | Complete workpilot.yaml reference |

### [Troubleshooting](troubleshooting.md)

---

## Quick Start

```bash
pip install workpilot
workpilot init
workpilot chat
```

See [Install](getting-started/install.md) for full setup instructions.
