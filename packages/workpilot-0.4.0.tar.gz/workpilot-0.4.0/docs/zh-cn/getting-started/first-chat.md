# 第一次对话

本指南将带您完成与 WorkPilot 的第一次对话。

## 启动交互式 REPL

```bash
workpilot chat
```

您将看到如下提示符：

```
you>
```

输入任何内容并按 Enter 键，WorkPilot 将会响应。

```
you> What files are in this directory?
```

代理将使用内置的文件工具列出当前目录中的文件。

## 试试这些提问

```
you> Summarise what this project does
you> Find all Python files that import requests
you> What does the function process_order do in orders.py?
you> Write a unit test for the calculate_total function
```

WorkPilot 会读取文件、运行 git 命令并搜索代码库来回答您的问题。如果您提出要求，它也可以对代码进行修改。

## 斜杠命令

在 REPL 中，以下命令可用：

| 命令 | 功能说明 |
|---------|-------------|
| `/help` | 显示所有可用的斜杠命令 |
| `/new` | 清除当前会话并重新开始 |
| `/status` | 显示代理名称、模型、会话 ID 和消息数量 |
| `/memory` | 显示 MEMORY.md 的内容（持久化记忆） |
| `/tools` | 列出可用工具 |
| `/skills` | 列出已加载的技能 |
| `/history` | 显示最近 10 条消息 |
| `/history 20` | 显示最近 20 条消息 |
| `/stop` | 中断提示（实际中断请使用 Ctrl+C） |
| `/exit` | 退出提示（实际退出请使用 Ctrl+C） |

## 退出

按 `Ctrl+C` 退出 REPL。

## 单次命令模式

如果您想在不启动交互式 REPL 的情况下执行单个提示：

```bash
workpilot run "List all TODO comments in the codebase"
```

此命令会让代理执行一次，打印响应后退出。适合用于脚本化操作或快速查询。

## 查看状态

```bash
workpilot status
```

显示当前激活的代理、渠道和功能，以及正在使用的安全配置文件。

## 后续步骤

- [终端渠道](../channels/terminal.md) — 所有终端命令与选项
- [浏览器渠道](../channels/browser.md) — 通过网页浏览器使用 WorkPilot
- [Teams 渠道](../channels/teams.md) — 在 Microsoft Teams 中使用 WorkPilot
