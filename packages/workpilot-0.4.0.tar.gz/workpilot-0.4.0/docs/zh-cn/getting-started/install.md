# 安装 WorkPilot

## 系统要求

- Python 3.11 或更高版本
- 受支持的 LLM 提供商（推荐使用 GitHub Copilot）

## 安装

### 从 PyPI 安装

```bash
pip install workpilot
```

如需包含所有可选功能（浏览器自动化、网关服务器、任务调度器）：

```bash
pip install "workpilot[all]"
```

### 从源码安装

```bash
git clone https://github.com/your-org/workpilot.git
cd workpilot
pip install -e ".[all]"
```

## 初始化项目

运行交互式配置向导，在当前目录创建本地配置文件：

```bash
workpilot init
```

向导将：

1. 通过 GitHub 登录以启用 Copilot 访问（推荐）
2. 询问默认模型（直接回车使用 `auto`）
3. 询问安全配置文件（默认为 `standard`）
4. 可选择是否启用 HTTP 网关服务器

此命令将在当前目录创建 `workpilot.local.yaml`。该文件已加入 .gitignore，用于保存您的个人设置和 API 密钥。主配置文件 `workpilot.yaml`（如存在）保存团队共用设置，应提交到代码仓库。

您可以随时重新运行 `workpilot init` 来修改配置。

## 验证安装

```bash
workpilot doctor
```

此命令将检查您的 Python 版本、配置文件、提供商密钥和可选依赖项，并报告任何问题。

```bash
workpilot version
```

打印已安装的版本号。

## 可选依赖项

某些功能需要额外安装软件包：

| 功能 | 安装命令 |
|---------|----------------|
| HTTP 网关 / 浏览器聊天 | `pip install fastapi uvicorn` |
| 计划任务 | `pip install apscheduler` |
| 浏览器自动化 | `pip install playwright && playwright install msedge` |
| 以上全部 | `pip install "workpilot[all]"` |

## 下一步

[开始您的第一次对话](first-chat.md)
