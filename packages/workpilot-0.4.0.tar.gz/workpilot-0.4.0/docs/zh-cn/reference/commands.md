# 命令参考

WorkPilot CLI 所有命令的完整参考。

## 顶级命令

### workpilot chat

启动交互式代理 REPL 会话。

```bash
workpilot chat [--config PATH] [--profile PROFILE]
```

如果 `workpilot serve` 已在运行，`chat` 会通过 `~/.workpilot/gateway.pid` 中的 PID 文件检测到正在运行的网关，并通过 WebSocket 连接，而不是启动新的代理实例。

| 选项 | 短选项 | 说明 |
|--------|-------|-------------|
| `--config PATH` | `-c` | 配置文件或目录（默认：当前目录） |
| `--profile PROFILE` | `-p` | 安全配置文件覆盖 |

**REPL 中可用的斜杠命令：**

| 命令 | 说明 |
|---------|-------------|
| `/help` | 显示可用命令 |
| `/new` | 清除会话，重新开始 |
| `/status` | 显示代理名称、模型、会话 ID、消息数量 |
| `/memory` | 显示 MEMORY.md 内容 |
| `/tools` | 列出可用工具 |
| `/skills` | 列出已加载的技能 |
| `/history [N]` | 显示最近 N 条消息（默认 10） |
| `/model` | 显示当前模型 |
| `/stop` | 中断提示 |
| `/exit` | 退出提示 |

---

### workpilot run

以单次提示运行代理。

```bash
workpilot run "PROMPT" [OPTIONS]
```

| 选项 | 短选项 | 说明 |
|--------|-------|-------------|
| `--config PATH` | `-c` | 配置文件或目录 |
| `--profile PROFILE` | `-p` | 安全配置文件 |
| `--session ID` | `-s` | 恢复之前的会话 |
| `--model MODEL` | `-m` | 为本次运行覆盖模型 |
| `--output FILE` | `-o` | 将响应写入文件 |

**示例：**

```bash
workpilot run "Summarise the last git commit"
workpilot run "Review orders.py" --model github/gpt-4o
workpilot run "Continue the refactor" --session abc-123
workpilot run "Generate changelog" --output changelog.md
```

---

### workpilot serve

启动 HTTP 网关服务器。

```bash
workpilot serve [--config PATH] [--profile PROFILE] [--host HOST] [--port PORT]
```

强制单实例：如果网关已在运行，显示现有 PID 和端口后退出。

| 选项 | 说明 |
|--------|-------------|
| `--host HOST` | 绑定主机（默认：localhost） |
| `--port PORT` | 绑定端口（默认：3003） |

---

### workpilot cloud

连接到 WorkPilot 云网关（Teams、Web Chat）。

```bash
workpilot cloud [--config PATH] [--url URL] [--login METHOD]
```

如果 `workpilot serve` 正在运行且云渠道已连接，显示状态后退出。

| 选项 | 说明 |
|--------|-------------|
| `--url URL` | 覆盖云网关 WSS URL |
| `--scope SCOPE` | 覆盖 Entra ID 范围 |
| `--login METHOD` | 登录方式：`auto`（默认）、`browser`、`device` |

---

### workpilot init

创建或更新本地配置文件（`workpilot.local.yaml`）。

```bash
workpilot init [--dir PATH] [--name NAME]
```

可安全多次运行，现有值将作为默认值显示。

| 选项 | 说明 |
|--------|-------------|
| `--dir PATH` | 目标目录（默认：当前目录） |
| `--name NAME` | 在配置中设置项目名称 |

---

### workpilot status

显示运行时配置状态。

```bash
workpilot status [--config PATH] [--profile PROFILE]
```

显示代理、渠道、安全设置和功能状态。

---

### workpilot doctor

运行健康诊断。

```bash
workpilot doctor [--config PATH] [--profile PROFILE]
```

检查：Python 版本、配置有效性、LLM 提供商密钥、可选软件包、工具配置、凭据提供商。

---

### workpilot logs

显示最近的日志输出。

```bash
workpilot logs [--lines N] [--config PATH]
```

| 选项 | 短选项 | 说明 |
|--------|-------|-------------|
| `--lines N` | `-n` | 显示的行数（默认：50） |

需要在 `workpilot.yaml` 中设置 `logging.file`。未设置日志文件时，日志输出到 stderr。

---

### workpilot version

打印 WorkPilot 版本号。

```bash
workpilot version
```

---

## 子命令

### workpilot agents

```bash
workpilot agents list [--config PATH]
workpilot agents add NAME [--config PATH]
```

`agents list` — 显示所有已配置的代理，包括模型、温度、迭代限制和工具列表。

`agents add NAME` — 以交互方式添加新代理。提示输入模型、指令、温度和最大迭代次数，然后保存到 `workpilot.yaml`。

---

### workpilot tools

```bash
workpilot tools list [--config PATH]
workpilot tools info NAME [--config PATH]
```

`tools list` — 列出所有内置工具（含风险级别）及已配置的 MCP 服务器。

`tools info NAME` — 显示指定工具的详细信息。

---

### workpilot mcp

```bash
workpilot mcp list [--config PATH]
workpilot mcp add NAME COMMAND [--config PATH]
workpilot mcp remove NAME [--config PATH]
```

`mcp list` — 显示所有已配置的 MCP 服务器，包含传输类型和命令/URL。

`mcp add NAME COMMAND` — 添加 MCP 服务器（stdio 传输方式）。`COMMAND` 是完整命令字符串，例如 `"npx -y @my-org/mcp-server"`。

`mcp remove NAME` — 从配置中移除 MCP 服务器。

---

### workpilot sessions

```bash
workpilot sessions list
workpilot sessions show SESSION_ID [--lines N]
workpilot sessions delete SESSION_ID [--yes]
workpilot sessions export SESSION_ID [--format md|json] [--output FILE]
```

`sessions list` — 显示所有已保存的会话，包含大小、消息数量和最后修改时间。

`sessions show` — 显示会话中的消息。`--lines N` 控制显示最近消息的数量（默认：20）。

`sessions delete` — 删除会话文件。除非传入 `--yes`，否则会提示确认。

`sessions export` — 将会话导出为 Markdown（`--format md`，默认）或 JSON（`--format json`）。默认输出到 `<session-id>.<format>`；使用 `--output` 指定路径。

---

### workpilot memory

```bash
workpilot memory show [--config PATH]
workpilot memory search QUERY [--config PATH]
workpilot memory clear [--config PATH]
workpilot memory stats [--config PATH]
```

`memory show` — 显示 MEMORY.md 的当前内容。

`memory search QUERY` — 在会话历史中搜索查询字符串。

`memory clear` — 清除 MEMORY.md 中的记忆内容，不会删除会话历史。

`memory stats` — 显示记忆统计信息（MEMORY.md 大小、会话数量等）。

---

### workpilot secrets

```bash
workpilot secrets set KEY [--from-env VAR]
workpilot secrets remove KEY
workpilot secrets test
```

`secrets set KEY` — 保存一个密钥（交互式输入值）。使用 `--from-env VAR` 可从环境变量复制。

`secrets remove KEY` — 从本地凭据存储中移除一个密钥。

`secrets test` — 通过发起最小化 API 调用来测试已配置的密钥是否有效。

---

### workpilot skills

```bash
workpilot skills list [--config PATH]
workpilot skills show NAME [--config PATH]
```

`skills list` — 列出所有已加载的技能，包含模式（always / available）、触发条件和描述。

`skills show` — 按名称显示技能文件的完整内容。

---

### workpilot cron

```bash
workpilot cron list [--config PATH]
workpilot cron add [--config PATH]
workpilot cron remove NAME [--config PATH]
workpilot cron enable NAME [--config PATH]
workpilot cron disable NAME [--config PATH]
workpilot cron status [--config PATH]
workpilot cron history [JOB_ID] [--config PATH]
```

`cron list` — 显示所有已配置的计划任务。

`cron add` — 以交互方式添加新任务。提示输入名称、计划、代理和提示词。

`cron remove NAME` — 从配置中移除 cron 任务。

`cron enable NAME` — 启用已禁用的 cron 任务。

`cron disable NAME` — 禁用 cron 任务而不删除它。

`cron status` — 显示调度器健康状态和任务数量。

`cron history [JOB_ID]` — 显示执行历史，可选择按任务 ID 过滤。

---

### workpilot security

```bash
workpilot security status [--config PATH]
workpilot security audit [--config PATH]
workpilot security credentials [--config PATH]
workpilot security roles [--config PATH]
workpilot security allowlist list|add|remove [OPTIONS]
workpilot security estop
workpilot security reset
```

`security status` — 显示当前安全配置文件和 E-stop 状态。

`security audit` — 显示审计配置和最近 10 条审计事件。

`security credentials` — 显示哪些凭据环境变量已设置（不显示实际值）。

`security roles` — 显示 RBAC 角色、其权限以及当前配置文件的自主权默认设置。

`security estop` — 触发紧急停止——立即停止所有代理活动。

`security reset` — 重置 E-stop，恢复正常运行。

`security allowlist list` — 列出已预批准的工具模式。

`security allowlist add` — 添加白名单条目。

| 选项 | 短选项 | 说明 |
|--------|-------|-------------|
| `--tool NAME` | `-t` | 工具名称（必填） |
| `--pattern REGEX` | `-p` | 参数正则表达式模式（可选，省略则匹配所有） |
| `--note TEXT` | `-n` | 可读注释 |

`security allowlist remove` — 按索引删除条目。

| 选项 | 短选项 | 说明 |
|--------|-------|-------------|
| `--index N` | `-i` | 来自 `allowlist list` 的索引（必填） |

---

## 全局选项

大多数命令接受以下选项：

| 选项 | 短选项 | 说明 |
|--------|-------|-------------|
| `--config PATH` | `-c` | 配置文件或目录（默认：`.`） |
| `--profile PROFILE` | `-p` | 覆盖安全配置文件 |

---

## 环境变量

| 变量 | 说明 |
|----------|-------------|
| `GITHUB_TOKEN` | 用于 Copilot 访问的 GitHub 令牌 |
| `OPENAI_API_KEY` | OpenAI API 密钥 |
| `AZURE_OPENAI_API_KEY` | Azure OpenAI API 密钥 |
| `ADO_PAT` | Azure DevOps 个人访问令牌 |
