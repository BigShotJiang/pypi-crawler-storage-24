# 配置参考

WorkPilot 使用 YAML 文件进行配置，共使用两个文件：

| 文件 | 用途 | 是否提交到 git？ |
|------|---------|----------------|
| `workpilot.yaml` | 团队/项目配置 | 是 |
| `workpilot.local.yaml` | 个人配置、API 密钥 | 否（已加入 .gitignore） |

`workpilot.local.yaml` 中的值会深度合并覆盖 `workpilot.yaml` 中的值。请将密钥和机器特定的配置放入 `workpilot.local.yaml`。

运行 `workpilot init` 以交互方式创建 `workpilot.local.yaml`。

---

## 顶级字段

```yaml
name: "My Project"          # 在状态和日志中显示的名称
entrypoint: default         # 作为默认代理使用的代理（默认："default"）
```

---

## providers

LLM 提供商凭据和模型配置。

```yaml
providers:
  github_copilot:
    token: "${GITHUB_TOKEN}"         # 用于 Copilot 访问的 GitHub 令牌

  openai:
    api_key: "${OPENAI_API_KEY}"
    api_base: ""                     # 可选：自定义 base URL

  azure_openai:
    api_key: "${AZURE_OPENAI_API_KEY}"
    endpoint: "https://your-resource.openai.azure.com"
    deployment: "gpt-4o"
    api_version: "2024-10-21"

  ai_foundry:
    endpoint: "https://your-resource.api.azureml.ms"
    api_key: "${AI_FOUNDRY_KEY}"
    deployment: "gpt-4o"

  aliases:
    default: "auto"         # auto = 自动选择最佳可用模型
    fast: "auto"
    reasoning: "auto"
    coding: "auto"

  fallback:
    enabled: true
    chain:
      - "github/gpt-4o"
      - "azure_ai/gpt-4o"
      - "openai/gpt-4o"
    max_retries: 2
```

**模型名称格式**：`provider/model-name`，例如 `github/gpt-4o`、`openai/gpt-4o-mini`、`azure_ai/gpt-4o`。使用 `auto` 让 WorkPilot 根据可用凭据自动选择。

---

## agents

配置默认代理及任何额外的自定义代理。

```yaml
agents:
  default:
    name: "WorkPilot Assistant"
    model: "auto"
    instructions: ""             # 系统提示词补充内容
    temperature: 0.3
    max_tokens: 8192
    max_iterations: 40
    timeout: 1200                # 每轮对话的超时时间（秒）
    memory_window: 50            # 在活跃上下文中保留的消息数量
    memory_writable: true        # 允许代理更新 MEMORY.md
    context_limit: 128000        # 用于压缩阈值的 token 预算
    workspace: "."               # 文件操作的工作目录
    tools:
      - shell
      - read_file
      - write_file
      - edit_file
      - list_dir
      - search_files
      - git
      - http_request
      - web_search
      - web_fetch
      - browser
      - spawn
      - message
    skills: []                   # 要加载的技能名称（空列表 = 全部）

  # 自定义代理示例
  my-reviewer:
    model: "auto"
    instructions: "You are a code reviewer. Be thorough and constructive."
    temperature: 0.1
    max_iterations: 20
    tools:
      - read_file
      - list_dir
      - git
    permissions:
      allow_shell: false
      allow_file_write: false
```

### 代理权限

```yaml
agents:
  my-agent:
    permissions:
      allow_shell: true
      allow_file_write: true
      allow_file_read: true
      allow_network: true
      allow_browser: false
      allow_spawn: false
      allowed_tools:
        - "*"              # "*" = 所有工具
      denied_tools: []
```

---

## security

```yaml
security:
  profile: standard              # open | standard | controlled | restricted
  credential_provider: env       # env | dotenv | azure-keyvault
  azure_keyvault_url: ""         # 使用 azure-keyvault 时必填

  audit:
    enabled: true
    log_file: ""                 # 空 = 输出到 stderr；设置路径则写入文件
    redact_secrets: true

  estop:
    enabled: true
    trigger_on_leak: true        # 检测到凭据时自动停止
    notify_channels: []

  default_role: user
  require_auth: false

  roles:
    admin:
      name: admin
      allowed_tools:
        - "*"
      denied_tools: []
      allowed_channels:
        - "*"
      max_iterations: 40

  approval:
    timeout_seconds: 900         # 升级前等待时间（15 分钟）
    auto_approve_timeout: 180    # 低风险自动审批等待时间（3 分钟）
    escalation_channels:
      - teams
    default_channel: cli

  allowlist:
    enabled: true
    path: ""                     # 默认：~/.workpilot/allowlist.json
```

---

## tools

```yaml
tools:
  shell:
    timeout: 120                 # 每个 Shell 命令的超时时间（秒）
    max_output_chars: 50000
    deny_patterns:               # 正则表达式模式——匹配的命令将被拦截
      - "rm\\s+-rf\\s+/"
      - ":\\(\\)\\s*\\{\\s*:\\|:&\\s*\\}\\s*;"
      - "shutdown"
      - "reboot"
      - "mkfs"
    allow_patterns: []           # 绕过 deny_patterns 的模式

  filesystem:
    restrict_to_workspace: true  # 拦截工作区目录之外的访问
    max_file_size_bytes: 10485760  # 10 MB
    deny_paths:
      - "/etc/shadow"
      - "/etc/passwd"
      - "~/.ssh"
      - "~/.gnupg"
      - "~/.aws/credentials"

  browser:
    enabled: false
    browser: msedge              # msedge | chromium | firefox
    headless: true
    timeout: 30000               # 毫秒
    allowed_domains: []          # 空 = 全部（SSRF 规则仍然适用）

  copilot:
    enabled: true
    default_model: "claude-sonnet-4.6"
    task_timeout: 0              # 0 = 上限为 1 小时
    max_concurrent: 5
    model_policy:
      code: "claude-sonnet-4.6"
      review: "claude-sonnet-4.6"
      test: "claude-haiku-4.5"
      refactor: "claude-sonnet-4.6"

  mcp_servers:
    my-server:
      command: "npx"
      args: ["-y", "@my-org/mcp-server"]
      env:
        MY_KEY: "${MY_KEY}"

    my-http-server:
      url: "http://localhost:8080"
```

---

## gateway

```yaml
gateway:
  enabled: false
  host: localhost
  port: 3003
  api_key: "${WORKPILOT_API_KEY}"   # 可选；启用 Bearer 令牌认证
  cors_origins: []                   # 空 = 仅同源
  rate_limit_per_minute: 60
  request_timeout: 300               # 每个请求的超时时间（秒）
  entra_tenant_id: ""                # 用于 Entra ID 网关认证
  entra_client_id: ""
```

---

## channels

```yaml
channels:
  cli:
    enabled: true
    prompt: "you> "

  cloud:
    enabled: true
    url: "wss://workpilot-gw-dev.azurewebsites.net/connect"
    tenant_id: "72f988bf-86f1-41af-91ab-2d7cd011db47"
    client_id: "c5bdcb9d-14dc-4b8a-9530-643d9db6df25"
    scope: "c5bdcb9d-14dc-4b8a-9530-643d9db6df25/.default"
    login_method: auto             # auto | browser | device
    auto_reconnect: true
    reconnect_max: 60

  teams:
    enabled: false
    app_id: "${TEAMS_APP_ID}"
    app_password: "${TEAMS_APP_PASSWORD}"
    tenant_id: "${TEAMS_TENANT_ID}"

  outlook:
    enabled: false
    client_id: "${OUTLOOK_CLIENT_ID}"
    client_secret: "${OUTLOOK_CLIENT_SECRET}"
    tenant_id: "${OUTLOOK_TENANT_ID}"
    user_email: "me@example.com"

  github:
    enabled: false
    token: "${GITHUB_TOKEN}"
    webhook_secret: "${GITHUB_WEBHOOK_SECRET}"

  ado:
    enabled: false
    organization: "my-org"
    project: "my-project"
    pat: "${ADO_PAT}"
```

---

## cron

```yaml
cron:
  enabled: false
  timezone: "UTC"
  max_concurrent_jobs: 3

  jobs:
    daily-standup:
      schedule: "0 9 * * 1-5"        # cron 表达式
      agent: default
      prompt: "Summarise overnight activity"
      session_mode: isolated           # isolated | persistent
      notify_channels: []
      enabled: true
      timeout: 300                     # 秒；0 或省略 = 无限制
```

计划格式：

| 格式 | 示例 | 含义 |
|--------|---------|---------|
| Cron 表达式 | `"0 9 * * 1-5"` | 工作日上午 9 点 |
| 间隔（秒） | `3600` | 每小时 |
| 定时（绝对时间） | `"at:2026-04-01T09:00:00"` | 在此时间执行一次 |
| 定时（相对时间） | `"at:+3600"` | 1 小时后执行一次 |

---

## logging

```yaml
logging:
  level: INFO                  # TRACE | DEBUG | INFO | WARNING | ERROR | CRITICAL
  format: pretty               # pretty | json
  file: ""                     # 日志文件路径；空 = 输出到 stderr
```

---

## 环境变量替换

`workpilot.yaml` 或 `workpilot.local.yaml` 中的任何值都可以使用 `${VAR_NAME}` 语法引用环境变量：

```yaml
providers:
  github_copilot:
    token: "${GITHUB_TOKEN}"
```

如果该变量未设置，值将被视为空。
