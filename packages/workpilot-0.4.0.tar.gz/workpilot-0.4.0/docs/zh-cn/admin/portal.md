# 管理门户

WorkPilot 管理门户是一个 Web 界面，用于监控代理活动、查看审计日志、管理已连接的代理以及触发紧急停止。

## 访问方式

管理门户托管在：

```
https://workpilot-gw-dev.azurewebsites.net/portal
```

请使用具有 WorkPilot 云网关管理员权限的 Entra ID 账号登录。

## 门户内容

### 已连接的代理

当前连接到云网关的 WorkPilot 实例列表。每个代理显示：

- 连接状态（已连接 / 已断开）
- 用户身份（UPN）
- 连接时间
- 消息数量

### 本地网关仪表盘

当 `workpilot serve` 运行时，状态仪表盘可在以下地址访问：

```
http://localhost:3003/
```

此仪表盘每 5 秒自动刷新，显示：

- 运行时状态
- 各渠道及其连接状态
- 代理配置摘要
- 最近活动

### 健康检查

```
http://localhost:3003/health
```

返回简单的 JSON 响应，指示网关是否正在运行。适用于监控和负载均衡器健康检查。

```
http://localhost:3003/api/health
```

返回涵盖所有子系统的详细健康信息。

## 紧急停止（E-stop）

紧急停止会立即停止所有代理循环，并使网关对新请求返回 503。当代理执行了意外操作且需要立即中止时使用此功能。

### 通过 CLI

```bash
workpilot security status    # 查看 E-stop 状态
workpilot security estop     # 立即触发
```

### 通过管理门户

点击页面上的**紧急停止**按钮，无需命令行。

### E-stop 后恢复

检查情况并确认可以恢复后：

```bash
workpilot security reset
```

或在管理门户中点击**重置**按钮。

### 自动 E-stop

当 WorkPilot 检测到工具输出或出站消息中可能存在凭据泄露时，会自动触发 E-stop。这是防止敏感信息离开您系统的安全机制。

自动 E-stop 触发后：

1. 查看 `workpilot logs` 和审计日志，了解发生了什么
2. 如果是误报，运行 `workpilot security reset` 或在管理门户点击重置
3. 如有需要，考虑调整密钥信息脱敏模式

## 审计日志

WorkPilot 将每次工具调用、消息和安全事件记录到只追加的审计文件中。查看最近的事件：

```bash
workpilot security audit
```

输出显示：

- 审计是否已启用/禁用
- 密钥信息脱敏是否已激活
- 日志文件位置
- 最近 10 条审计事件

配置审计日志文件位置：

```yaml
security:
  audit:
    enabled: true
    log_file: "/var/log/workpilot/audit.jsonl"
    redact_secrets: true
```

## 凭据状态

查看已配置的凭据（不会显示实际值）：

```bash
workpilot security credentials
```

显示所有已知凭据环境变量的状态（已设置 / 未设置）。

## RBAC 角色

```bash
workpilot security roles
```

显示已配置的角色、其允许和拒绝的工具、允许的渠道以及迭代限制。同时显示当前安全配置文件的自主权默认设置。

## 工具审批白名单

当某个工具需要人工审批时（基于安全配置文件），您可以预先批准特定模式，使其不再每次都弹出提示：

```bash
# 显示当前白名单
workpilot security allowlist list

# 预先批准所有 git 读取操作
workpilot security allowlist add --tool git --pattern "status|log|diff|show"

# 预先批准运行测试
workpilot security allowlist add --tool shell --pattern "pytest.*" --note "Test runner"

# 按索引删除条目
workpilot security allowlist remove --index 0
```

白名单存储在 `~/.workpilot/allowlist.json`。

## 运行时状态

```bash
workpilot status
```

显示：

- WorkPilot 版本
- 使用的安全配置文件
- 已配置的代理（名称、模型、工具）
- 渠道状态（已启用 / 已禁用）
- 功能状态（网关、cron、浏览器）
- MCP 服务器数量和名称
