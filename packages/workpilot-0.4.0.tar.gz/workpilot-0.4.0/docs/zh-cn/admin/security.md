# 安全配置

WorkPilot 专为在企业环境中安全运行而设计。本页介绍安全控制机制、如何配置它们，以及它们所防护的威胁。

## 安全配置文件

安全配置文件控制代理的自主权限级别。在 `workpilot.yaml` 中设置，或在 `workpilot init` 时配置。

| 配置文件 | 说明 | 适用场景 |
|---------|-------------|----------|
| `open` | 完全自主——代理无需征求审批即可执行操作 | 可信的个人机器、高级用户 |
| `standard` | 中等风险操作需要审批 | 大多数用户（默认） |
| `controlled` | 所有工具调用都通过安全分类器审核 | 共享环境、敏感代码库 |
| `restricted` | 所有操作均需人工审批；子代理已禁用 | 高安全性或合规环境 |

设置配置文件：

```yaml
security:
  profile: standard
```

或针对单次运行覆盖：

```bash
workpilot run "Fix the bug" --profile controlled
```

## 安全分类器

安全分类器是一个快速的内部代理，在工具调用执行前对其进行审查。它将调用分类为：

- **approve** — 调用看起来安全，继续执行
- **reject** — 调用看起来危险，予以拦截
- **escalate** — 不确定，需要人工审查

在当前版本中，升级决策被视为拒绝（未来版本计划支持人工路由）。分类结果缓存 5 分钟以避免重复检查。

敏感参数值在发送给分类器之前会进行脱敏处理。

## 工具审批级别

每个工具根据当前安全配置文件被分配一个自主权级别：

| 级别 | 行为 |
|-------|-----------|
| `autonomous` | 工具静默执行（仅记录审计日志） |
| `notify` | 工具执行，结果被记录并显示 |
| `approval` | 工具执行前需人工审批 |
| `forbidden` | 完全不允许使用该工具 |

## 命令沙箱

WorkPilot 会拦截与危险模式匹配的 Shell 命令。默认拦截：

- `rm -rf /` 及类似的破坏性删除操作
- Fork 炸弹
- 磁盘格式化命令（`mkfs`、`dd if=/dev/...`）
- `shutdown` 和 `reboot`
- 管道式 Shell 执行（`curl ... | sh`、`wget ... | bash`）
- 对根目录的递归所有权更改
- `chmod 777`

查看当前活跃的拒绝模式：

```bash
workpilot security audit
```

在 `workpilot.yaml` 中添加自定义模式：

```yaml
tools:
  shell:
    deny_patterns:
      - "my-dangerous-command"
      - "rm.*important-dir"
```

## 文件系统沙箱

默认情况下，代理只能读写已配置工作区目录内的文件。无论使用何种安全配置文件，对敏感系统路径的访问都会被拒绝。

被拒绝的路径包括 `/etc/shadow`、`/etc/passwd`、`~/.ssh`、`~/.gnupg` 和 `~/.aws/credentials`。

配置方式：

```yaml
tools:
  filesystem:
    restrict_to_workspace: true          # 默认：true
    max_file_size_bytes: 10485760        # 默认：10 MB
    deny_paths:
      - "/etc/shadow"
      - "~/.ssh"
```

## 密钥信息脱敏

WorkPilot 会自动从以下内容中脱敏密钥信息：

- 显示给您之前的工具输出
- 发送到任何渠道之前的出站消息
- 审计日志条目

检测的模式包括：JWT 令牌、AWS 访问密钥、GitHub PAT、OpenAI 密钥、Slack 令牌，以及看起来像凭据的高熵字符串。

禁用脱敏（不推荐）：

```yaml
security:
  audit:
    redact_secrets: false
```

## 泄露检测与自动 E-stop

如果在工具输出或出站消息中检测到疑似凭据，WorkPilot 会自动触发紧急停止。所有代理循环停止，网关对新请求返回 503，直到您重置为止。

E-stop 后重置：

```bash
workpilot security reset
```

禁用泄露检测时的自动 E-stop：

```yaml
security:
  estop:
    trigger_on_leak: false
```

## RBAC（基于角色的访问控制）

您可以定义角色来限制不同用户可以执行的操作。每个角色指定：

- 允许或拒绝使用哪些工具
- 允许使用哪些渠道
- 最大迭代次数

示例：

```yaml
security:
  default_role: user
  roles:
    admin:
      name: admin
      allowed_tools:
        - "*"
      denied_tools: []
      allowed_channels:
        - "*"
      max_iterations: 40

    user:
      name: user
      allowed_tools:
        - read_file
        - list_dir
        - git
        - http_request
      denied_tools:
        - shell
        - write_file
      allowed_channels:
        - teams
        - cli
      max_iterations: 20
```

查看已配置的角色：

```bash
workpilot security roles
```

## 用户级工具审批白名单

用户可以预先批准特定工具模式，避免重复的审批提示。白名单条目按用户存储在 `~/.workpilot/allowlist.json`。

```bash
workpilot security allowlist list
workpilot security allowlist add --tool git --pattern "log|status|diff"
workpilot security allowlist remove --index 0
```

## 凭据提供商

凭据可从不同来源加载：

| 提供商 | 配置方式 |
|----------|--------------|
| `env` | 环境变量（默认） |
| `dotenv` | 工作区中的 `.env` 文件 |
| `azure-keyvault` | Azure Key Vault |

使用 Azure Key Vault：

```yaml
security:
  credential_provider: azure-keyvault
  azure_keyvault_url: "https://your-vault.vault.azure.net"
```

检查已设置的凭据：

```bash
workpilot security credentials
```

## 审计日志

所有工具调用、消息和安全事件都记录在只追加的审计日志中。配置方式：

```yaml
security:
  audit:
    enabled: true
    log_file: "/var/log/workpilot/audit.jsonl"
    redact_secrets: true
```

查看最近的审计事件：

```bash
workpilot security audit
```

## SSRF 防护

WorkPilot 会拦截针对内部网络地址（169.254.x.x、10.x.x.x、172.16-31.x.x、192.168.x.x、localhost 等）的 HTTP 请求，以防止服务端请求伪造攻击。此机制适用于所有 HTTP 工具。

## MCP 工具隔离

从 MCP（Model Context Protocol）服务器加载的工具默认不受信任。在 `restricted` 配置文件下，MCP 工具在容器中隔离运行。如有需要，您可以在 `workpilot.yaml` 中为特定 MCP 服务器授予信任。

## 代理级权限

每个代理可以拥有独立于全局配置文件的权限集：

```yaml
agents:
  my-reviewer:
    permissions:
      allow_shell: false
      allow_file_write: false
      allow_file_read: true
      allow_network: true
      allow_browser: false
      allow_spawn: false
```

即使全局配置文件允许更多操作，此配置也会将 `my-reviewer` 代理限制为只读操作。
