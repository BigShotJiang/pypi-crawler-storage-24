# WorkPilot v0.3.0 — 用户文档

WorkPilot 是一款在您本地机器上运行的企业级 AI 助手。它能够编写和审查代码、自动化任务、搜索网络、与 Git 和 Azure DevOps 交互，并通过终端、浏览器或 Microsoft Teams 与您对话——同时确保您的数据始终保留在本地。

## 文档目录

### 快速入门

| 指南 | 说明 |
|-------|-------------|
| [安装](getting-started/install.md) | 安装 WorkPilot 并配置 LLM 提供商 |
| [第一次对话](getting-started/first-chat.md) | 开始您的第一次对话 |

### 接入渠道

| 指南 | 说明 |
|-------|-------------|
| [终端](channels/terminal.md) | 交互式 REPL 与单次命令 |
| [浏览器](channels/browser.md) | 网页聊天界面与 REST API |
| [Teams](channels/teams.md) | 在 Microsoft Teams 中使用 WorkPilot |

### 功能特性

| 指南 | 说明 |
|-------|-------------|
| [Copilot 任务](features/copilot-tasks.md) | 将编码任务委托给 GitHub Copilot |
| [计划任务](features/scheduling.md) | 按计划自动执行代理任务 |
| [会话管理](features/sessions.md) | 管理对话历史记录 |
| [技能扩展](features/skills.md) | 通过自定义技能文件扩展代理能力 |

### 管理

| 指南 | 说明 |
|-------|-------------|
| [管理门户](admin/portal.md) | 用于监控和控制的 Web 管理门户 |
| [安全配置](admin/security.md) | 安全配置文件、RBAC 和审计日志 |

### 参考

| 指南 | 说明 |
|-------|-------------|
| [命令参考](reference/commands.md) | 完整的 CLI 命令参考 |
| [配置参考](reference/configuration.md) | workpilot.yaml 完整配置参考 |

### [故障排除](troubleshooting.md)

---

## 快速开始

```bash
pip install workpilot
workpilot init
workpilot chat
```

完整安装说明请参阅[安装指南](getting-started/install.md)。
