# 浏览器渠道

WorkPilot 内置 HTTP 网关，让您可以通过网页浏览器与之对话，也可通过 REST 与其他工具集成，还支持为第三方客户端提供 OpenAI 兼容端点。

## 启动网关

```bash
workpilot serve
```

网关默认在 `http://localhost:3003` 上启动。打开浏览器并访问：

```
http://localhost:3003/chat.html
```

您将看到一个聊天界面，可在其中输入消息并接收响应。

## 单实例限制

WorkPilot 同一时间只允许运行一个网关实例。如果在网关已运行时再次执行 `workpilot serve`，它将显示现有的 PID 和端口后退出。

PID 文件存储在 `~/.workpilot/gateway.pid`。如果程序崩溃后需要强制重启，请先删除此文件。

## 网关选项

```bash
# 绑定到所有网络接口（可被局域网内其他设备访问）
# 安全提示：开放非本地监听前请先配置 gateway.api_key
workpilot serve --host 0.0.0.0

# 使用不同的端口
workpilot serve --port 8080

# 绑定到指定接口和端口
workpilot serve --host 192.168.1.10 --port 4000
```

## API 端点

| 端点 | 方法 | 说明 |
|----------|--------|-------------|
| `/` | GET | 状态仪表盘（每 5 秒自动刷新） |
| `/chat.html` | GET | 网页聊天界面 |
| `/health` | GET | 基础健康检查 |
| `/api/health` | GET | 详细健康检查（涵盖所有子系统） |
| `/api/status` | GET | 运行时状态（由仪表盘轮询） |
| `/api/chat` | POST | 发送提示，接收完整响应 |
| `/api/chat/stream` | POST | 发送提示，接收 SSE 流式响应 |
| `/api/ws` | WebSocket | 双向聊天 |
| `/api/sessions` | GET | 列出会话 |
| `/api/tools` | GET | 列出可用工具 |
| `/api/estop` | POST | 触发紧急停止 |
| `/api/reset` | POST | 重置紧急停止 |
| `/v1/chat/completions` | POST | OpenAI 兼容的聊天补全接口 |
| `/webhooks/{channel}` | POST | 接收 Webhook 事件（GitHub、ADO、Teams、Outlook） |

## REST API

### 发送提示

```bash
curl -X POST http://localhost:3003/api/chat \
  -H "Content-Type: application/json" \
  -d '{"prompt": "List all Python files in the project"}'
```

响应：

```json
{
  "response": "Here are the Python files...",
  "session_id": "abc-123"
}
```

### 流式响应

```bash
curl -X POST http://localhost:3003/api/chat/stream \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Summarise the README"}'
```

响应以服务器发送事件（SSE）形式发送，每个事件包含一段文本内容。

### 恢复会话

```bash
curl -X POST http://localhost:3003/api/chat \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Continue", "session_id": "abc-123"}'
```

### 列出会话

```bash
curl http://localhost:3003/api/sessions
```

### 列出工具

```bash
curl http://localhost:3003/api/tools
```

## WebSocket 聊天

`/api/ws` 端点提供双向聊天功能。发送 JSON：

```json
{"prompt": "Your message here"}
```

接收 JSON：

```json
{"response": "The agent response"}
```

当 `workpilot chat` 在网关运行时执行，它将使用此端点连接到现有的代理实例。

## OpenAI 兼容端点

`/v1/chat/completions` 端点接受标准 OpenAI 聊天格式，因此您可以在支持 OpenAI 的工具中将 WorkPilot 作为替代方案直接使用：

```bash
curl -X POST http://localhost:3003/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "workpilot",
    "messages": [
      {"role": "user", "content": "Hello"}
    ]
  }'
```

## 身份验证

默认情况下，网关只能从 `localhost` 访问。如需添加 API 密钥验证，在 `workpilot.yaml` 中设置 `gateway.api_key`：

```yaml
gateway:
  enabled: true
  api_key: "${WORKPILOT_API_KEY}"
```

设置 API 密钥后，所有请求必须在 Authorization 头中以 Bearer 令牌方式提供密钥：

```bash
curl -X POST http://localhost:3003/api/chat \
  -H "Authorization: Bearer your-api-key" \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Hello"}'
```

## CORS 跨域配置

默认情况下，只允许同源请求。如需允许其他来源的请求：

```yaml
gateway:
  cors_origins:
    - "https://your-app.example.com"
    - "http://localhost:3000"
```

## 速率限制

默认速率限制为每分钟 60 次请求。如需修改：

```yaml
gateway:
  rate_limit_per_minute: 120
```

## 网关配置

在 `workpilot.yaml` 中配置：

```yaml
gateway:
  enabled: true
  host: localhost
  port: 3003
  api_key: "${WORKPILOT_API_KEY}"   # 可选
  cors_origins: []                   # 空列表 = 仅同源
  rate_limit_per_minute: 60
  request_timeout: 300               # 每个请求的超时时间（秒）
```

或运行 `workpilot init` 并在向导提示时启用网关。
