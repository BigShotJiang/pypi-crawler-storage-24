# 终端渠道

终端是使用 WorkPilot 的主要方式，始终可用，无需额外配置。

## 交互式 REPL

```bash
workpilot chat
```

启动一个交互式会话，在终端中输入消息并接收响应。

如果 `workpilot serve` 已在运行，`workpilot chat` 会自动通过 `~/.workpilot/gateway.pid` 中的 PID 文件检测到这一情况，并通过 WebSocket 连接到正在运行的网关，而不是启动新的代理实例。此时响应以完整消息形式到达，而非流式输出。

### 斜杠命令

在 `you>` 提示符处可以输入以下命令：

| 命令 | 说明 |
|---------|-------------|
| `/help` | 列出所有斜杠命令 |
| `/new` | 清除会话并重新开始 |
| `/status` | 显示代理名称、模型、会话 ID 和消息数量 |
| `/memory` | 显示 MEMORY.md 的内容 |
| `/tools` | 列出可用工具 |
| `/skills` | 列出已加载的技能 |
| `/history` | 显示最近 10 条消息 |
| `/history N` | 显示最近 N 条消息 |
| `/stop` | 中断提示（请使用 Ctrl+C） |
| `/model` | 显示当前模型（会话中途不支持切换） |
| `/exit` | 退出提示（请使用 Ctrl+C） |

### 退出

按 `Ctrl+C` 退出。

## 单次命令模式

```bash
workpilot run "Your prompt here"
```

以给定的提示运行代理一次，打印响应后退出。适合在脚本、CI 流水线或快速查询中使用。

### 选项

| 选项 | 说明 |
|--------|-------------|
| `--model MODEL` | 为本次运行覆盖指定模型 |
| `--output FILE` | 将响应写入文件而非打印到终端 |
| `--session ID` | 通过 ID 恢复之前的会话 |
| `--profile PROFILE` | 使用指定的安全配置文件 |

### 示例

```bash
# 运行提示并打印到标准输出
workpilot run "Summarise the changes in the last git commit"

# 将响应写入文件
workpilot run "Generate a changelog for this week" --output changelog.md

# 恢复之前的会话
workpilot run "Continue where we left off" --session abc123

# 使用指定模型
workpilot run "Review this code" --model github/gpt-4o
```

## 网关服务器

```bash
workpilot serve
```

在端口 3003（默认）上启动 HTTP 网关服务器。这将启用：

- 浏览器聊天界面：`http://localhost:3003/chat.html`
- REST API：`http://localhost:3003/api/chat`
- WebSocket 聊天：`ws://localhost:3003/api/ws`
- OpenAI 兼容端点：`http://localhost:3003/v1/chat/completions`

WorkPilot 强制执行单实例规则。如果在网关已运行时再次执行 `workpilot serve`，它将显示现有的 PID 和端口后退出。

### 选项

| 选项 | 说明 |
|--------|-------------|
| `--host HOST` | 绑定到指定主机（默认：localhost） |
| `--port PORT` | 绑定到指定端口（默认：3003） |

详细的网关端点说明请参阅[浏览器渠道](browser.md)。

## 云网关

```bash
workpilot cloud
```

连接到 WorkPilot 云网关，该网关将来自 Microsoft Teams 和 Web Chat 的消息中继到您的本地代理。由于连接是从本地发出的出站连接，无需配置入站防火墙规则。

如果 `workpilot serve` 正在运行且云渠道已连接，`workpilot cloud` 将显示现有的连接状态后退出，不会建立新连接。

### 登录方式

| 方式 | 说明 |
|--------|-------------|
| `auto` | 尝试浏览器 PKCE 弹窗；失败时回退到设备码（默认） |
| `browser` | 打开浏览器窗口进行交互式登录 |
| `device` | 设备码流程——访问 URL 并输入代码；无需浏览器即可完成 |

```bash
# 使用设备码（适合无图形界面的服务器）
workpilot cloud --login device
```

完整的配置说明请参阅 [Teams 渠道](teams.md)。

## 状态与诊断

```bash
# 显示当前活动配置
workpilot status

# 运行诊断（Python 版本、配置有效性、提供商密钥、依赖包）
workpilot doctor

# 显示最近的日志输出
workpilot logs

# 显示更多行的日志
workpilot logs --lines 100

# 打印版本号
workpilot version
```

## 会话管理

```bash
# 列出所有会话
workpilot sessions list

# 显示会话中的消息
workpilot sessions show <session-id>

# 显示最近 5 条消息
workpilot sessions show <session-id> --lines 5

# 删除会话
workpilot sessions delete <session-id>

# 将会话导出为 Markdown
workpilot sessions export <session-id>

# 导出为 JSON
workpilot sessions export <session-id> --format json

# 导出到指定文件
workpilot sessions export <session-id> --output my-session.md
```

会话以 JSONL 格式存储在 `~/.workpilot/sessions/` 目录中。

## 代理管理

```bash
# 列出已配置的代理
workpilot agents list

# 以交互方式添加新代理
workpilot agents add my-reviewer
```

## 工具管理

```bash
# 列出内置工具和 MCP 服务器
workpilot tools list
```

## MCP 服务器管理

MCP（Model Context Protocol）服务器可为 WorkPilot 扩展额外的工具能力。

```bash
# 列出已配置的 MCP 服务器
workpilot mcp list

# 添加 MCP 服务器（stdio 传输方式）
workpilot mcp add my-server "npx -y @my-org/my-mcp-server"

# 移除 MCP 服务器
workpilot mcp remove my-server
```

## 技能管理

```bash
# 列出已加载的技能
workpilot skills list
```

## 计划任务（cron）

```bash
# 列出已配置的 cron 任务
workpilot cron list

# 以交互方式添加 cron 任务
workpilot cron add
```

详细说明请参阅[计划任务](../features/scheduling.md)。

## 安全命令

```bash
# 显示审计配置和最近的事件
workpilot security audit

# 显示凭据状态（不会显示实际值）
workpilot security credentials

# 显示 RBAC 角色
workpilot security roles

# 管理工具调用审批白名单
workpilot security allowlist list
workpilot security allowlist add --tool shell --pattern "git .*"
workpilot security allowlist remove --index 0
```
