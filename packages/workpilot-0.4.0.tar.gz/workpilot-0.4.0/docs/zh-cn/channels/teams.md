# Teams 渠道

WorkPilot 通过 WorkPilot 云网关连接到 Microsoft Teams。您的代理在本地运行；云网关通过出站 WebSocket 在 Teams 与您的机器之间中继消息。无需配置入站防火墙规则。

## 工作原理

```
Teams 用户 -> 云网关（Azure）-> WorkPilot（您的机器）
WorkPilot  -> 云网关（Azure）-> Teams 用户
```

云网关已预先配置好。您只需使用 Entra ID 账号完成一次身份验证，WorkPilot 便会与网关保持持久连接。

## 前置条件

- WorkPilot v0.3.0 或更高版本，已安装并配置完成（`workpilot doctor` 检查通过）
- 可访问 WorkPilot Teams 应用的 Microsoft 365 账号
- 您的 IT 团队或管理员须已在您的租户中安装 WorkPilot Teams 应用

## 连接到云网关

```bash
workpilot cloud
```

此命令将：

1. 打开浏览器（或为无图形界面环境显示设备码）
2. 提示您使用 Microsoft 账号登录
3. 建立与云网关的连接
4. 保持运行——在使用 Teams 期间请保持此终端窗口打开

您将看到如下输出：

```
Gateway : wss://workpilot-gw-dev.azurewebsites.net/connect
Tenant  : 72f988bf-86f1-41af-91ab-2d7cd011db47
Login   : browser -> device code fallback
```

登录后，您的代理便可从 Teams 中访问。

## 登录方式

使用 `--login` 参数控制登录方式：

| 方式 | 命令 | 使用场景 |
|--------|---------|-------------|
| 自动（默认） | `workpilot cloud` | 常规使用——尝试浏览器，失败时回退到设备码 |
| 浏览器 | `workpilot cloud --login browser` | 需要强制弹出浏览器窗口时 |
| 设备码 | `workpilot cloud --login device` | 无图形界面的服务器、WSL、无浏览器的 SSH 会话 |

### 设备码示例

```bash
workpilot cloud --login device
```

输出：

```
To sign in, use a web browser to open https://microsoft.com/devicelogin
and enter the code ABCD-1234 to authenticate.
```

在任意设备上打开该 URL，输入代码，使用您的工作账号登录即可。

## 在 Teams 中使用 WorkPilot

连接成功后，在 Teams 中找到 WorkPilot 应用。您可以直接与它发起聊天，或在频道中 @提及它（具体取决于管理员对应用的配置方式）。

您在 Teams 中发送的消息将被路由到您的本地代理，响应通常在几秒内出现在 Teams 中。

## 保持连接

`workpilot cloud` 进程必须保持运行，Teams 消息才能到达您的代理。对于长时间使用的场景，建议：

- 在 screen 或 tmux 会话中运行
- 改用 `workpilot serve`（见下文），它会自动管理云连接

## 与 serve 配合使用

如果您在配置中启用了云渠道并运行 `workpilot serve`，网关将自动处理 Teams 连接：

```yaml
# workpilot.yaml
channels:
  cloud:
    enabled: true
```

然后只需运行：

```bash
workpilot serve
```

检查云渠道是否已连接：

```bash
workpilot cloud
```

如果 `workpilot serve` 正在运行且已连接，此命令将显示当前状态后退出，不会建立新连接。

## 令牌缓存

首次登录后，WorkPilot 会缓存您的身份验证令牌，后续启动时无需再次提示登录即可静默连接。

令牌缓存存储在：

```
~/.workpilot/token_cache_<client-id-prefix>.json
```

如需强制重新登录，删除此文件即可：

```bash
# Windows（PowerShell）
Remove-Item "$env:USERPROFILE\.workpilot\token_cache_*.json"

# Linux/macOS
rm ~/.workpilot/token_cache_*.json
```

## 管理门户

如需监控已连接的代理、查看活跃用户并管理云网关，请访问：

```
https://workpilot-gw-dev.azurewebsites.net/portal
```

您需要使用具有管理员权限的 Entra ID 账号登录。详情请参阅[管理门户](../admin/portal.md)。

## 配置参考

云网关已预先配置好开箱即用的默认值，只有在自建私有网关时才需要修改这些设置。

```yaml
channels:
  cloud:
    enabled: true
    url: "wss://workpilot-gw-dev.azurewebsites.net/connect"
    tenant_id: "72f988bf-86f1-41af-91ab-2d7cd011db47"
    client_id: "c5bdcb9d-14dc-4b8a-9530-643d9db6df25"
    scope: "c5bdcb9d-14dc-4b8a-9530-643d9db6df25/.default"
    login_method: "auto"          # auto | browser | device
    auto_reconnect: true
    reconnect_max: 60             # 最大重连次数
```

## 故障排除

**"Disconnected from Cloud Gateway"** — 您的令牌可能已过期，或网络连接中断。重新运行 `workpilot cloud` 即可重连。

**"Could not query running gateway"** — `workpilot serve` 正在运行但未响应。请查看 `workpilot logs` 中的错误信息。

**Teams 消息未到达** — 请确认 `workpilot cloud` 或启用了云渠道的 `workpilot serve` 正在运行。查看管理门户确认您的代理是否显示为已连接。

**使用 AADSTS9002326 错误登录失败** — 您的 Microsoft 365 租户条件访问策略可能阻止了设备码流程。请改用 `--login browser`。

更多故障排除帮助，请参阅[故障排除](../troubleshooting.md)。
