# 计划任务

WorkPilot 可以按计划自动执行代理任务。您可以将其用于每日报告、周期性代码审查、定时健康检查，或任何无需手动触发即可定期执行的任务。

## 前置条件

调度器需要 APScheduler：

```bash
pip install apscheduler
```

或安装所有可选依赖：

```bash
pip install "workpilot[all]"
```

## 启用调度器

在 `workpilot.yaml` 中：

```yaml
cron:
  enabled: true
```

或运行 `workpilot init` 并在向导提示时启用 cron。

## 调度类型

| 类型 | 格式 | 示例 |
|------|--------|---------|
| Cron 表达式 | 标准 5 字段 cron | `"0 9 * * 1-5"` |
| 间隔 | 秒数（整数） | `3600` |
| 定时（单次） | `"at"` 或 `"at:<时间>"` | `"at:2026-03-07T10:00:00"` |

### Cron 表达式示例

| 表达式 | 含义 |
|------------|---------|
| `"0 9 * * 1-5"` | 周一至周五 上午 9:00 |
| `"0 */4 * * *"` | 每 4 小时 |
| `"30 17 * * 5"` | 每周五 下午 5:30 |
| `"0 0 1 * *"` | 每月 1 日 午夜 |

### 间隔示例

| 值 | 含义 |
|-------|---------|
| `3600` | 每小时 |
| `300` | 每 5 分钟 |
| `86400` | 每天一次 |

## 在 workpilot.yaml 中配置任务

```yaml
cron:
  enabled: true
  jobs:
    daily-standup:
      schedule: "0 9 * * 1-5"        # 工作日上午 9 点
      agent: default
      prompt: "Summarise the git commits from the last 24 hours and any open issues"
      session_mode: isolated          # isolated = 每次运行使用全新的上下文
      notify_channels: []             # 可选：将结果发送到 Teams、邮件等渠道
      enabled: true

    hourly-health:
      schedule: 3600                  # 每小时（秒）
      agent: default
      prompt: "Run a quick health check: are tests passing, any pending PRs?"
      session_mode: isolated
      enabled: true

    weekly-review:
      schedule: "0 17 * * 5"          # 每周五下午 5 点
      agent: default
      prompt: "Generate a weekly summary of work completed and areas needing attention"
      session_mode: isolated
      enabled: true
```

## 会话模式

| 模式 | 说明 |
|------|-------------|
| `isolated` | 每次运行从全新的上下文开始（默认，推荐） |
| `persistent` | 每次运行在上一个会话基础上继续——代理记住过去的运行记录 |

对于需要跨运行跟踪状态的任务（例如跟踪长期迁移进度），请使用 `persistent` 模式。

## 列出任务

```bash
workpilot cron list
```

显示所有已配置任务的计划、代理和启用状态。

## 以交互方式添加任务

```bash
workpilot cron add
```

向导将提示输入：
- 任务名称
- Cron 计划（例如 `0 9 * * 1-5`）
- 代理名称（默认：`default`）
- 提示词

任务保存到 `workpilot.yaml`。

## 任务在 serve 运行时才会执行

计划任务只有在 `workpilot serve` 运行时才会执行。启动网关以激活调度功能：

```bash
workpilot serve
```

## 通知渠道

您可以自动将任务结果发送到指定渠道：

```yaml
cron:
  jobs:
    daily-report:
      schedule: "0 9 * * 1-5"
      agent: default
      prompt: "Generate the daily status report"
      notify_channels:
        - teams
        - email
```

此功能需要相应渠道已配置并启用。

## 超时设置

为每个任务设置超时时间（秒）：

```yaml
cron:
  jobs:
    quick-check:
      schedule: 3600
      agent: default
      prompt: "Quick health check"
      timeout: 60         # 60 秒内未完成则失败
```

## 单次定时任务（at）

安排任务在指定时间运行一次：

```yaml
cron:
  jobs:
    release-prep:
      schedule: "at:2026-04-01T09:00:00"   # 在此时间运行一次
      agent: default
      prompt: "Prepare the release notes for v1.0"
```

或相对于当前时间：

```yaml
    quick-one-off:
      schedule: "at:+3600"    # 60 分钟后运行一次
```

## 全局 cron 设置

```yaml
cron:
  enabled: true
  timezone: "UTC"             # cron 表达式使用的时区
  max_concurrent_jobs: 3      # 同时运行的最大任务数
```
