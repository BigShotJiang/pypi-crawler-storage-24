# 会话管理

WorkPilot 将每次对话保存为一个会话。会话功能让您可以恢复过去的对话、查看代理执行的操作、导出对话历史，并管理存储空间。

## 会话的工作原理

每次对话都有一个会话 ID。启动 `workpilot chat` 时，会自动创建一个新会话。对话过程中，每条消息都会追加到以下位置的 JSONL 文件中：

```
~/.workpilot/sessions/<session-id>.jsonl
```

文件中的每一行都是一个 JSON 对象，代表一条消息（用户消息、助手消息或工具调用）。会话是只追加的——除非您明确删除某个会话，否则 WorkPilot 不会修改或删除消息。

## 恢复会话

要继续之前的对话，将会话 ID 传递给 `workpilot run`：

```bash
workpilot run "Continue with the refactoring we discussed" --session <session-id>
```

## 列出会话

```bash
workpilot sessions list
```

输出显示会话 ID、文件大小、消息数量和最后修改时间。

## 查看会话内容

```bash
workpilot sessions show <session-id>
```

默认显示最近 20 条消息。如需显示更多或更少：

```bash
workpilot sessions show <session-id> --lines 50
workpilot sessions show <session-id> --lines 5
```

## 导出会话

导出为 Markdown（默认）：

```bash
workpilot sessions export <session-id>
```

在当前目录创建 `<session-id>.md` 文件。

导出为 JSON：

```bash
workpilot sessions export <session-id> --format json
```

写入指定文件：

```bash
workpilot sessions export <session-id> --output my-conversation.md
workpilot sessions export <session-id> --format json --output data.json
```

## 删除会话

```bash
workpilot sessions delete <session-id>
```

删除前会提示确认。如需跳过确认：

```bash
workpilot sessions delete <session-id> --yes
```

## 在 REPL 中开始新会话

在 `workpilot chat` 中，使用 `/new` 斜杠命令：

```
you> /new
Session cleared. Starting fresh.
```

这将开始一个新会话，而不会丢失之前的会话记录。

## 在 REPL 中查看会话历史

回顾当前会话中的对话内容：

```
you> /history
you> /history 20
```

## 跨会话记忆

MEMORY.md 与会话历史是分开的。它保存跨会话持久存在的事实信息（例如您的名字、项目偏好和重要上下文）。代理在每次对话开始时都会读取 MEMORY.md。

在 REPL 中查看 MEMORY.md：

```
you> /memory
```

从命令行查看：

```bash
workpilot memory show
```

## 在 Web API 中使用会话

使用 REST API 时，可以管理会话：

```bash
# 列出会话
curl http://localhost:3003/api/sessions

# 发送提示并获取会话 ID
curl -X POST http://localhost:3003/api/chat \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Hello"}'

# 恢复该会话
curl -X POST http://localhost:3003/api/chat \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Continue", "session_id": "the-id-from-before"}'
```

## 存储位置

会话存储在 `~/.workpilot/sessions/` 目录下。每个会话是一个单独的 `.jsonl` 文件。系统不会自动清理——请手动删除旧会话，或使用 `workpilot sessions delete` 释放磁盘空间。
