# Copilot 任务

WorkPilot 可以通过 `gh_copilot` 工具族将编码任务委托给 GitHub Copilot。这让代理能够在后台执行代码编写、审查、测试和重构任务，而您可以继续其他工作。

## 前置条件

- GitHub Copilot 订阅
- 已配置 GitHub 令牌（在 `workpilot init` 时设置，或通过 `GITHUB_TOKEN` 环境变量设置）

## 工作原理

当您要求 WorkPilot 实现某个功能、编写测试或审查代码时，它可以选择使用 `gh_copilot` 工具将该工作委托给 GitHub Copilot。Copilot 执行任务后将结果返回给 WorkPilot，再由 WorkPilot 呈现给您。

任务可以在后台运行（您获得一个任务 ID，稍后查看结果），也可以在等待模式下运行（WorkPilot 阻塞直到任务完成）。

## 工具说明

### gh_copilot

向 GitHub Copilot 提交任务。

| 参数 | 类型 | 说明 |
|-----------|------|-------------|
| `task` | string | 任务描述 |
| `task_type` | string | `code`、`review`、`test` 或 `refactor` |
| `files` | list | 与任务相关的文件（可选） |
| `mode` | string | `background`（默认）或 `wait` |
| `model` | string | 使用的模型（可选，默认使用按任务类型的策略） |
| `resume_task_id` | string | 恢复之前的任务（可选） |

### gh_copilot_status

查看正在运行或已完成任务的状态。

| 参数 | 类型 | 说明 |
|-----------|------|-------------|
| `task_id` | string | 要查看的任务 ID（可选——省略时列出所有任务） |

### gh_copilot_models

列出可用的 GitHub Copilot 模型及其上下文限制。

无需参数。

## 任务类型

| 类型 | Copilot 执行的操作 |
|------|--------------------|
| `code` | 实现任务，编写简洁的代码，在适用时运行测试 |
| `review` | 审查代码中的错误、安全问题、性能和风格违规 |
| `test` | 使用现有测试框架和约定编写测试 |
| `refactor` | 在不改变行为的前提下重构代码，提升可读性并减少重复 |

## 各任务类型的默认模型

| 任务类型 | 默认模型 |
|-----------|--------------|
| code | claude-sonnet-4.6 |
| review | claude-sonnet-4.6 |
| test | claude-haiku-4.5 |
| refactor | claude-sonnet-4.6 |

## 使用示例

用自然语言要求 WorkPilot 委托任务：

```
you> Implement the missing validate_email function in utils.py
you> Review the changes in my last commit
you> Write unit tests for the ShoppingCart class
you> Refactor the database connection module to remove duplication
```

WorkPilot 会根据任务内容自行决定是否使用 `gh_copilot`。

## 后台模式与等待模式

**后台模式**（默认）：WorkPilot 提交任务后立即返回，附带一个任务 ID。Copilot 在后台工作。您可以随时查看进度：

```
you> What is the status of my Copilot tasks?
```

**等待模式**：WorkPilot 等待任务完成后再响应。当您需要立即获得结果时使用此模式。

## 并发任务

默认情况下，最多可同时运行 5 个 Copilot 任务。如果提交的任务超过此数量，它们将排队等待空闲槽位。

在 `workpilot.yaml` 中修改限制：

```yaml
tools:
  copilot:
    max_concurrent: 10
```

## 配置

在 `workpilot.yaml` 中配置：

```yaml
tools:
  copilot:
    enabled: true
    default_model: "claude-sonnet-4.6"
    task_timeout: 0          # 秒；0 = 上限为 1 小时
    max_concurrent: 5
    model_policy:
      code: "claude-sonnet-4.6"
      review: "claude-sonnet-4.6"
      test: "claude-haiku-4.5"
      refactor: "claude-sonnet-4.6"
```

禁用 Copilot 任务委托：

```yaml
tools:
  copilot:
    enabled: false
```
