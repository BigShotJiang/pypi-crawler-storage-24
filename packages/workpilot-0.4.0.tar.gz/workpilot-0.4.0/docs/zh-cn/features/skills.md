# 技能扩展

技能是为代理提供特定任务专业知识的提示词覆盖层。技能是带有 YAML 前置元数据头的 Markdown 文件。当代理处理与某个技能触发条件匹配的任务时，它会读取该技能的指令并遵循执行。

## 内置技能

WorkPilot 随附三个内置技能：

| 技能 | 说明 |
|-------|-------------|
| `github` | GitHub 工作流规范——PR 创建、分支命名、提交信息 |
| `ado` | Azure DevOps 规范——工作项、流水线、拉取请求 |
| `azure-ops` | Azure 运营——资源管理、部署模式 |

这些技能开箱即用，无需任何配置。

## 列出技能

```bash
workpilot skills list
```

显示技能名称、模式（always 或 available）、触发条件和简短描述。

在 REPL 中查看：

```
you> /skills
```

## 技能模式

| 模式 | 行为 |
|------|-----------|
| `always` | 技能始终包含在代理的上下文中 |
| `available` | 仅当用户消息中出现相关触发关键词时才加载技能 |

`available` 模式更为常见，因为它能让上下文聚焦于当前相关的内容。

## 技能触发条件

触发条件是关键词或短语。当用户消息包含其中之一时，该技能会自动加载。

例如，`github` 技能可能有 `pull request`、`PR`、`branch`、`commit`、`merge` 等触发词。如果您提问"Can you help me write a PR description?"，`github` 技能便会被加载。

## 创建自定义技能

在项目的 `.workpilot/skills/` 目录中创建带有 YAML 前置元数据的 Markdown 文件：

```
your-project/
  .workpilot/
    skills/
      my-skill.md
```

### 技能文件格式

```markdown
---
name: python-style
description: Python code style conventions for this project
mode: available
triggers:
  - python
  - function
  - class
  - style
  - convention
---

# Python Style Guide

This project follows these conventions:

- Use type hints on all public functions
- Maximum line length is 100 characters
- Use `loguru` for logging, not `logging`
- All functions must have docstrings
- Use `pathlib.Path` instead of `os.path`
- Prefer `async/await` over threading

## Naming

- Classes: `PascalCase`
- Functions and variables: `snake_case`
- Constants: `UPPER_SNAKE_CASE`
- Private members: prefix with underscore `_`

## Error handling

Always raise specific exceptions, not `Exception`. Document exceptions in docstrings.
```

## 技能上下文预算

技能会消耗代理上下文窗口的一部分空间。为保持上下文高效利用，WorkPilot 将技能摘要限制在可用上下文的约 2%。过长的技能会被压缩摘要而非完整包含。

对于每个字都至关重要的技能，使用 `mode: always` 以确保完整内容被包含。

## 工作区技能发现

WorkPilot 会自动从以下位置发现技能：

1. 内置技能（随 WorkPilot 一起发布）
2. 项目工作区中的 `.workpilot/skills/`

无需任何配置——只需创建文件并重启代理即可。

## 为特定代理分配技能

在 `workpilot.yaml` 中，您可以将技能限制为特定代理使用：

```yaml
agents:
  default:
    skills:
      - github
      - python-style
```

如果未列出任何技能，则所有已发现的技能均可使用。

## 在 REPL 中使用技能

您无需手动调用技能。代理会根据触发条件自动加载它们。您可以随时查看当前已加载的技能：

```
you> /skills
```

## SKILL.md（项目级）

您也可以在工作区根目录创建一个 `SKILL.md` 文件。它将作为整个项目的单一技能加载，适合用于记录代理应始终遵循的项目特定规范。

```markdown
# Project Conventions

This project uses FastAPI for the web layer and SQLAlchemy for the database.
Always use async functions. Use Alembic for migrations.
```

将此文件放在项目根目录（与 `workpilot.yaml` 同级）。
