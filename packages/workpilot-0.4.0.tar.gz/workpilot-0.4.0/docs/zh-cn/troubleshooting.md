# 故障排除

## 第一步

运行内置诊断工具：

```bash
workpilot doctor
```

此命令检查 Python 版本、配置有效性、提供商密钥、可选软件包和工具可用性，并报告发现的所有错误。在进一步排查之前，请先修复报告的错误。

查看最近的日志输出：

```bash
workpilot logs
workpilot logs --lines 200
```

---

## 安装问题

### "Command not found: workpilot"

软件包未安装到 PATH 中的路径。

尝试：

```bash
python -m workpilot --help
```

如果此命令有效，请将 Python scripts 目录添加到 PATH，或改用 `python -m workpilot`。

如果您在虚拟环境中安装，请先激活它：

```bash
source .venv/bin/activate        # Linux/macOS
.venv\Scripts\activate           # Windows
```

### Python 版本错误

WorkPilot 需要 Python 3.11 或更高版本：

```bash
python --version
```

如果版本过旧，请从 https://python.org 安装 Python 3.11+ 并创建新的虚拟环境。

### 缺少可选依赖

```
Error: FastAPI and uvicorn are required for the gateway.
Install with: pip install fastapi uvicorn
```

安装指定的软件包，或安装所有可选依赖：

```bash
pip install "workpilot[all]"
```

---

## 配置问题

### "Config error: ..."

运行 `workpilot doctor` 查看详细的验证错误信息。

检查您的 `workpilot.yaml` 和 `workpilot.local.yaml` 是否存在 YAML 语法错误。常见问题：

- 缩进错误（YAML 使用空格，不使用制表符）
- 包含特殊字符（如 `:`、`{`、`}`）的值缺少引号
- `${VAR}` 环境变量引用与实际变量名不匹配

### "No workpilot.yaml found"

您在没有配置文件的情况下运行了 `workpilot chat`。解决方法：

- 运行 `workpilot init` 创建配置文件，或
- 传入配置路径：`workpilot chat --config /path/to/config`

---

## 提供商和模型问题

### "No LLM API key found"

WorkPilot 找不到任何支持的提供商凭据。运行配置向导：

```bash
workpilot init
```

向导将引导您完成 GitHub 登录（用于 Copilot），或在 `workpilot.local.yaml` 中配置其他提供商。

### 代理响应非常慢或超时

- 检查您的网络连接
- 模型提供商可能正在承受高负载
- 尝试更快的模型：`workpilot run "hello" --model github/gpt-4o-mini`
- 检查提供商账户的速率限制

### "Circuit breaker open"

提供商连续失败次数过多，WorkPilot 已停止重试。请等待几分钟后再试。查看 `workpilot logs` 了解底层错误原因。

---

## 聊天和 REPL 问题

### 代理陷入循环或重复执行

WorkPilot 内置了循环检测机制。如果检测到重复工具调用的模式，它会注入警告提示。如果循环持续，它会自动停止。

如果此情况频繁发生：

- 提问时更加具体明确
- 使用 `/new` 开始新会话
- 查看 `workpilot logs` 了解代理正在尝试做什么

### 响应被截断

上下文窗口可能已满。WorkPilot 会在使用率达到 80%、85% 和 95% 时自动压缩上下文。如果您正在处理非常大的代码库：

- 使用 `/new` 开始新会话以清空上下文
- 对不需要会话历史的单次任务使用 `workpilot run`

### "/new 不起作用"

请确保您是在 `you>` 提示符处输入 `/new`，而不是在消息中间输入。

---

## 网关问题

### 启动时提示 "Gateway already running"

之前的 `workpilot serve` 进程没有清理其 PID 文件。解决步骤：

1. 查看错误消息中显示的 PID，检查该进程是否仍在运行
2. 如果进程已退出，删除 PID 文件：

```bash
# Linux/macOS
rm ~/.workpilot/gateway.pid

# Windows（PowerShell）
Remove-Item "$env:USERPROFILE\.workpilot\gateway.pid"
```

3. 重新运行 `workpilot serve`

### 网关返回 503

紧急停止已被触发。重置方法：

```bash
workpilot security reset
```

或在管理门户 `https://workpilot-gw-dev.azurewebsites.net/portal` 中点击**重置**按钮。

### 无法从其他机器连接到网关

默认情况下，网关只绑定到 `localhost`。如需允许外部连接：

```bash
workpilot serve --host 0.0.0.0
```

> **安全提示：** 绑定到 `0.0.0.0` 会将网关 API（包括 shell 和文件系统工具）暴露给所有能访问该机器 3003 端口的用户。请在此之前在配置中设置 `gateway.api_key`，并通过防火墙限制访问来源。

确保您的防火墙允许 3003 端口的流量通过。

---

## Teams 和云网关问题

### "Disconnected from Cloud Gateway"

您的令牌已过期或网络连接中断。重新运行 `workpilot cloud` 即可。

如果经常断开连接，删除令牌缓存以强制重新登录：

```bash
# Linux/macOS
rm ~/.workpilot/token_cache_*.json

# Windows（PowerShell）
Remove-Item "$env:USERPROFILE\.workpilot\token_cache_*.json"
```

### 登录时出现 AADSTS9002326 错误

您的 Microsoft 365 租户要求将重定向 URI 注册为**移动和桌面应用程序**（而非 SPA）类型的 Azure 应用注册。

请联系 IT 管理员：

1. 打开 Azure 门户，找到 WorkPilot 应用注册
2. 进入"身份验证"
3. 从 SPA 平台部分删除 `http://localhost`
4. 在"移动和桌面应用程序"下添加 `http://localhost`

### 出现 "Cloud Gateway already connected" 提示

`workpilot serve` 正在运行并已维护云连接，无需任何操作。Teams 消息正在被中继到您的代理。

### Teams 消息未到达

1. 确认 `workpilot cloud` 或设置了 `channels.cloud.enabled: true` 的 `workpilot serve` 正在运行
2. 检查管理门户，确认您的代理是否显示为已连接
3. 运行 `workpilot logs` 查找连接错误
4. 尝试重连：按 Ctrl+C，然后重新运行 `workpilot cloud`

---

## 安全和 E-stop 问题

### 自动 E-stop 被触发

WorkPilot 在工具输出中检测到可能的凭据并自动停止。诊断步骤：

```bash
workpilot logs --lines 100
workpilot security audit
```

查看触发检测的原因。如果是误报，重置：

```bash
workpilot security reset
```

### 工具调用提示 "Permission denied"

当前安全配置文件或 RBAC 角色不允许此工具调用。解决方案：

- 使用限制较少的配置文件：`workpilot run "..." --profile open`
- 在 `workpilot.yaml` 的允许工具列表中添加该工具
- 预先批准该模式：`workpilot security allowlist add --tool shell --pattern "..."`

### "Command blocked by deny pattern"

Shell 命令匹配了沙箱拒绝模式。如果该命令是安全的，在 `workpilot.yaml` 中添加允许模式：

```yaml
tools:
  shell:
    allow_patterns:
      - "my-safe-command.*"
```

---

## Copilot 任务问题

### Copilot 任务很快超时

默认任务超时上限为 1 小时。如果任务提前超时，增加限制：

```yaml
tools:
  copilot:
    task_timeout: 1800    # 30 分钟
```

---

## 启用调试日志

如需获取更详细的日志，在 `workpilot.local.yaml` 中添加：

```yaml
logging:
  level: DEBUG
  file: "/tmp/workpilot-debug.log"
```

然后重新运行 `workpilot chat` 或 `workpilot serve` 并查看日志文件。

---

## 获取更多帮助

1. 运行 `workpilot doctor` 并分享输出结果
2. 运行 `workpilot logs --lines 200` 查找错误消息
3. 使用 `workpilot status` 检查安全配置文件
4. 使用 `workpilot security audit` 验证您的配置
