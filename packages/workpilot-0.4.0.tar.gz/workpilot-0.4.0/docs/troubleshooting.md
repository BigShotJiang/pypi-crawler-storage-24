# Troubleshooting

## First steps

Run the built-in diagnostics:

```bash
workpilot doctor
```

This checks Python version, configuration validity, provider keys, optional packages, and tool availability. Fix any errors it reports before investigating further.

Check recent log output:

```bash
workpilot logs
workpilot logs --lines 200
```

---

## Installation problems

### "Command not found: workpilot"

The package was not installed into a location on your PATH.

Try:

```bash
python -m workpilot --help
```

If this works, add the Python scripts directory to your PATH, or use `python -m workpilot` instead of `workpilot`.

If you installed in a virtual environment, activate it first:

```bash
source .venv/bin/activate        # Linux/macOS
.venv\Scripts\activate           # Windows
```

### Python version error

WorkPilot requires Python 3.11 or later:

```bash
python --version
```

If you have an older version, install Python 3.11+ from https://python.org and create a new virtual environment.

### Missing optional dependency

```
Error: FastAPI and uvicorn are required for the gateway.
Install with: pip install fastapi uvicorn
```

Install the specific package, or install all optional dependencies:

```bash
pip install "workpilot[all]"
```

---

## Configuration problems

### "Config error: ..."

Run `workpilot doctor` to see the exact validation error.

Check your `workpilot.yaml` and `workpilot.local.yaml` for YAML syntax errors. Common issues:

- Indentation errors (YAML uses spaces, not tabs)
- Missing quotes around values containing special characters like `:`, `{`, `}`
- Environment variable reference `${VAR}` not matching the actual variable name

### "No workpilot.yaml found"

You ran `workpilot chat` without a config file. Either:

- Run `workpilot init` to create one, or
- Pass the config path: `workpilot chat --config /path/to/config`

---

## Provider and model problems

### "No LLM API key found"

WorkPilot cannot find credentials for any supported provider. Run the setup wizard:

```bash
workpilot init
```

This guides you through GitHub sign-in (for Copilot) or lets you configure other providers in `workpilot.local.yaml`.

### Agent responds very slowly or times out

- Check your internet connection
- The model provider may be experiencing high load
- Try a faster model: `workpilot run "hello" --model github/gpt-4o-mini`
- Check rate limits on your provider account

### "Circuit breaker open"

The provider failed too many times in a row and WorkPilot stopped trying. Wait a few minutes and try again. Check `workpilot logs` for the underlying error.

---

## Chat and REPL problems

### Agent loops or repeats itself

WorkPilot has loop detection built in. If it detects a pattern of repeating tool calls, it injects a warning. If the loop persists, it stops automatically.

If this happens frequently:

- Be more specific in your requests
- Use `/new` to start a fresh session
- Check `workpilot logs` for what the agent was trying to do

### Responses are truncated

The context window may be full. WorkPilot compacts the context automatically at 80%, 85%, and 95% usage. If you are working on a very large codebase:

- Start a new session with `/new` to clear the context
- Use `workpilot run` for one-shot tasks that do not need session history

### "/new does not work"

Make sure you are typing `/new` at the `you>` prompt, not in the middle of a message.

---

## Gateway problems

### "Gateway already running" on startup

A previous `workpilot serve` process did not clean up its PID file. To resolve:

1. Check if the process is still running by looking at the PID shown in the error message
2. If the process is gone, delete the PID file:

```bash
# Linux/macOS
rm ~/.workpilot/gateway.pid

# Windows (PowerShell)
Remove-Item "$env:USERPROFILE\.workpilot\gateway.pid"
```

3. Run `workpilot serve` again

### Gateway returns 503

The emergency stop has been triggered. Reset it:

```bash
workpilot security reset
```

Or click the **Reset** button in the admin portal at `https://workpilot-gw-dev.azurewebsites.net/portal`.

### Cannot connect to the gateway from another machine

By default, the gateway only binds to `localhost`. To allow external connections:

```bash
workpilot serve --host 0.0.0.0
```

> **Security warning:** Binding to `0.0.0.0` exposes the gateway API (including shell and filesystem tools) to anyone who can reach this machine on port 3003. Always set `gateway.api_key` in your config before doing this, and restrict access via firewall to trusted machines only.

---

## Teams and Cloud Gateway problems

### "Disconnected from Cloud Gateway"

Your token expired or the network connection dropped. Run `workpilot cloud` again.

If you consistently get disconnected, delete the token cache to force a fresh sign-in:

```bash
# Linux/macOS
rm ~/.workpilot/token_cache_*.json

# Windows (PowerShell)
Remove-Item "$env:USERPROFILE\.workpilot\token_cache_*.json"
```

### AADSTS9002326 error during sign-in

Your Microsoft 365 tenant requires the redirect URI to be registered as a **Mobile and desktop application** (not SPA) in the Azure app registration.

Ask your IT admin to:

1. Open the Azure portal and find the WorkPilot app registration
2. Go to Authentication
3. Remove `http://localhost` from the SPA platform section
4. Add `http://localhost` under Mobile and desktop applications

### "Cloud Gateway already connected" message

`workpilot serve` is running and already maintaining the cloud connection. No action is needed. Teams messages are being relayed to your agent.

### Teams messages not arriving

1. Confirm `workpilot cloud` or `workpilot serve` with `channels.cloud.enabled: true` is running
2. Check the admin portal to see if your agent shows as connected
3. Run `workpilot logs` to look for connection errors
4. Try reconnecting: press Ctrl+C, then run `workpilot cloud` again

---

## Security and E-stop problems

### Automatic E-stop triggered

WorkPilot detected a possible credential in tool output and stopped automatically. To diagnose:

```bash
workpilot logs --lines 100
workpilot security audit
```

Review what triggered the detection. If it was a false positive, reset:

```bash
workpilot security reset
```

### "Permission denied" on a tool call

The active security profile or RBAC role does not permit this tool call. Options:

- Use a less restrictive profile: `workpilot run "..." --profile open`
- Add the tool to the allowed tools list in `workpilot.yaml`
- Pre-approve the pattern: `workpilot security allowlist add --tool shell --pattern "..."`

### "Command blocked by deny pattern"

The shell command matched one of the sandbox deny patterns. If the command is safe, add an allow pattern in `workpilot.yaml`:

```yaml
tools:
  shell:
    allow_patterns:
      - "my-safe-command.*"
```

---

## Copilot task problems

### Copilot task times out quickly

The default task timeout is capped at 1 hour. If tasks time out earlier, increase the limit:

```yaml
tools:
  copilot:
    task_timeout: 1800    # 30 minutes
```

---

## Enabling debug logging

To get more detailed logs, add this to `workpilot.local.yaml`:

```yaml
logging:
  level: DEBUG
  file: "/tmp/workpilot-debug.log"
```

Then run `workpilot chat` or `workpilot serve` again and check the log file.

---

## Getting more help

1. Run `workpilot doctor` and share the output
2. Run `workpilot logs --lines 200` and look for error messages
3. Check the security profile with `workpilot status`
4. Verify your configuration with `workpilot security audit`
