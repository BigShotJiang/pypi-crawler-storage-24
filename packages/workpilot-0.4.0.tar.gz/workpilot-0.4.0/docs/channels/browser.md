# Browser Channel

WorkPilot includes a built-in HTTP gateway that lets you chat from a web browser, integrate with other tools via REST, and expose an OpenAI-compatible endpoint for third-party clients.

## Start the gateway

```bash
workpilot serve
```

The gateway starts on `http://localhost:3003` by default. Open a browser and navigate to:

```
http://localhost:3003/chat.html
```

You will see a chat interface where you can type messages and receive responses.

## Single-instance enforcement

WorkPilot allows only one gateway instance at a time. If you run `workpilot serve` when a gateway is already running, it displays the existing PID and port and exits.

The PID file is stored at `~/.workpilot/gateway.pid`. If you need to force a restart after a crash, delete this file first.

## Gateway options

```bash
# Bind to all interfaces (accessible on your network)
# WARNING: set gateway.api_key before exposing beyond localhost
workpilot serve --host 0.0.0.0

# Use a different port
workpilot serve --port 8080

# Bind to a specific interface and port
workpilot serve --host 192.168.1.10 --port 4000
```

## API endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | Status dashboard (auto-refreshes every 5 seconds) |
| `/chat.html` | GET | Web chat interface |
| `/health` | GET | Basic health check |
| `/api/health` | GET | Detailed health check (all subsystems) |
| `/api/status` | GET | Runtime status (polled by the dashboard) |
| `/api/chat` | POST | Send a prompt, receive a complete response |
| `/api/chat/stream` | POST | Send a prompt, receive a streaming SSE response |
| `/api/ws` | WebSocket | Bidirectional chat |
| `/api/sessions` | GET | List sessions |
| `/api/tools` | GET | List available tools |
| `/api/estop` | POST | Trigger emergency stop |
| `/api/reset` | POST | Reset emergency stop |
| `/v1/chat/completions` | POST | OpenAI-compatible chat completions |
| `/webhooks/{channel}` | POST | Receive webhook events (GitHub, ADO, Teams, Outlook) |

## REST API

### Send a prompt

```bash
curl -X POST http://localhost:3003/api/chat \
  -H "Content-Type: application/json" \
  -d '{"prompt": "List all Python files in the project"}'
```

Response:

```json
{
  "response": "Here are the Python files...",
  "session_id": "abc-123"
}
```

### Streaming response

```bash
curl -X POST http://localhost:3003/api/chat/stream \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Summarise the README"}'
```

The response is sent as Server-Sent Events (SSE). Each event contains a chunk of text.

### Resume a session

```bash
curl -X POST http://localhost:3003/api/chat \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Continue", "session_id": "abc-123"}'
```

### List sessions

```bash
curl http://localhost:3003/api/sessions
```

### List tools

```bash
curl http://localhost:3003/api/tools
```

## WebSocket chat

The WebSocket endpoint at `/api/ws` provides bidirectional chat. Send JSON:

```json
{"prompt": "Your message here"}
```

Receive JSON:

```json
{"response": "The agent response"}
```

When `workpilot chat` is run while the gateway is running, it uses this endpoint to connect to the existing agent.

## OpenAI-compatible endpoint

The `/v1/chat/completions` endpoint accepts the standard OpenAI chat format, so you can use WorkPilot as a drop-in replacement in tools that support OpenAI:

```bash
curl -X POST http://localhost:3003/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "workpilot",
    "messages": [
      {"role": "user", "content": "Hello"}
    ]
  }'
```

## Authentication

By default, the gateway is accessible only from `localhost`. To add API key authentication, set `gateway.api_key` in `workpilot.yaml`:

```yaml
gateway:
  enabled: true
  api_key: "${WORKPILOT_API_KEY}"
```

When an API key is set, all requests must include it as a Bearer token:

```bash
curl -X POST http://localhost:3003/api/chat \
  -H "Authorization: Bearer your-api-key" \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Hello"}'
```

## CORS

By default, only same-origin requests are allowed. To allow requests from other origins:

```yaml
gateway:
  cors_origins:
    - "https://your-app.example.com"
    - "http://localhost:3000"
```

## Rate limiting

The default rate limit is 60 requests per minute. To change it:

```yaml
gateway:
  rate_limit_per_minute: 120
```

## Configuring the gateway

In `workpilot.yaml`:

```yaml
gateway:
  enabled: true
  host: localhost
  port: 3003
  api_key: "${WORKPILOT_API_KEY}"   # optional
  cors_origins: []                   # empty = same-origin only
  rate_limit_per_minute: 60
  request_timeout: 300               # seconds per request
```

Or run `workpilot init` and enable the gateway when prompted.
