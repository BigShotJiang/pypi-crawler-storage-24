# Terminal Channel

The terminal is the primary way to use WorkPilot. It is always available and requires no additional configuration.

## Interactive REPL

```bash
workpilot chat
```

Starts an interactive session. Type messages and receive responses in the terminal.

If `workpilot serve` is already running, `workpilot chat` detects this automatically via the PID file at `~/.workpilot/gateway.pid` and connects to the running gateway over WebSocket instead of starting a new agent. Responses arrive as complete messages rather than streaming output.

### Slash commands

These commands can be typed at the `you>` prompt:

| Command | Description |
|---------|-------------|
| `/help` | List all slash commands |
| `/new` | Clear session and start fresh |
| `/status` | Show agent name, model, session ID, and message count |
| `/memory` | Show the contents of MEMORY.md |
| `/tools` | List available tools |
| `/skills` | List loaded skills |
| `/history` | Show last 10 messages |
| `/history N` | Show last N messages |
| `/stop` | Interrupt hint (use Ctrl+C) |
| `/model` | Show current model (mid-session switching not supported) |
| `/exit` | Exit hint (use Ctrl+C) |

### Exit

Press `Ctrl+C` to exit.

## One-shot command

```bash
workpilot run "Your prompt here"
```

Runs the agent once with the given prompt, prints the response, and exits. Suitable for scripts, CI pipelines, or quick lookups.

### Options

| Option | Description |
|--------|-------------|
| `--model MODEL` | Override the model for this run |
| `--output FILE` | Write the response to a file instead of printing it |
| `--session ID` | Resume a previous session by ID |
| `--profile PROFILE` | Use a specific security profile |

### Examples

```bash
# Run a prompt and print to stdout
workpilot run "Summarise the changes in the last git commit"

# Write the response to a file
workpilot run "Generate a changelog for this week" --output changelog.md

# Resume a previous session
workpilot run "Continue where we left off" --session abc123

# Use a specific model
workpilot run "Review this code" --model github/gpt-4o
```

## Gateway server

```bash
workpilot serve
```

Starts the HTTP gateway server on port 3003 (default). This enables:

- Browser-based chat at `http://localhost:3003/chat.html`
- REST API at `http://localhost:3003/api/chat`
- WebSocket chat at `ws://localhost:3003/api/ws`
- OpenAI-compatible endpoint at `http://localhost:3003/v1/chat/completions`

WorkPilot enforces a single-instance rule. If you run `workpilot serve` when a gateway is already running, it shows the existing PID and port and exits.

### Options

| Option | Description |
|--------|-------------|
| `--host HOST` | Bind to a specific host (default: localhost) |
| `--port PORT` | Bind to a specific port (default: 3003) |

See [Browser Channel](browser.md) for more detail on the gateway endpoints.

## Cloud Gateway

```bash
workpilot cloud
```

Connects to the WorkPilot Cloud Gateway, which relays messages from Microsoft Teams and Web Chat to your local agent. No inbound firewall rules are required because the connection is outbound.

If `workpilot serve` is running and the cloud channel is already connected, `workpilot cloud` shows the existing connection status and exits without starting another connection.

### Login methods

| Method | Description |
|--------|-------------|
| `auto` | Try browser PKCE popup; fall back to device code (default) |
| `browser` | Open a browser window for interactive sign-in |
| `device` | Device code flow — visit a URL and enter a code; works without a browser |

```bash
# Use device code (headless servers)
workpilot cloud --login device
```

See [Teams Channel](teams.md) for full setup instructions.

## Status and diagnostics

```bash
# Show active configuration
workpilot status

# Run diagnostics (Python version, config validity, provider keys, packages)
workpilot doctor

# Show recent log output
workpilot logs

# Show recent log output (more lines)
workpilot logs --lines 100

# Print version
workpilot version
```

## Session management

```bash
# List all sessions
workpilot sessions list

# Show messages in a session
workpilot sessions show <session-id>

# Show last 5 messages
workpilot sessions show <session-id> --lines 5

# Delete a session
workpilot sessions delete <session-id>

# Export a session to markdown
workpilot sessions export <session-id>

# Export to JSON
workpilot sessions export <session-id> --format json

# Export to a specific file
workpilot sessions export <session-id> --output my-session.md
```

Sessions are stored as JSONL files in `~/.workpilot/sessions/`.

## Agent management

```bash
# List configured agents
workpilot agents list

# Add a new agent interactively
workpilot agents add my-reviewer
```

## Tool management

```bash
# List built-in tools and MCP servers
workpilot tools list
```

## MCP server management

MCP (Model Context Protocol) servers extend WorkPilot with additional tools.

```bash
# List configured MCP servers
workpilot mcp list

# Add an MCP server (stdio transport)
workpilot mcp add my-server "npx -y @my-org/my-mcp-server"

# Remove an MCP server
workpilot mcp remove my-server
```

## Skills management

```bash
# List loaded skills
workpilot skills list
```

## Scheduled jobs (cron)

```bash
# List configured cron jobs
workpilot cron list

# Add a cron job interactively
workpilot cron add
```

See [Scheduling](../features/scheduling.md) for full details.

## Security commands

```bash
# Show audit configuration and recent events
workpilot security audit

# Show credential status (never reveals actual values)
workpilot security credentials

# Show RBAC roles
workpilot security roles

# Manage the tool approval allowlist
workpilot security allowlist list
workpilot security allowlist add --tool shell --pattern "git .*"
workpilot security allowlist remove --index 0
```
