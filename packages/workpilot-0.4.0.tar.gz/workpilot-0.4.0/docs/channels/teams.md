# Teams Channel

WorkPilot connects to Microsoft Teams through the WorkPilot Cloud Gateway. Your agent runs locally; the Cloud Gateway relays messages between Teams and your machine over an outbound WebSocket. No inbound firewall rules are required.

## How it works

```
Teams user -> Cloud Gateway (Azure) -> WorkPilot (your machine)
WorkPilot  -> Cloud Gateway (Azure) -> Teams user
```

The Cloud Gateway is pre-configured. You authenticate once with your Entra ID account, and WorkPilot maintains a persistent connection to the gateway.

## Prerequisites

- WorkPilot v0.3.0 or later, installed and configured (`workpilot doctor` passes)
- A Microsoft 365 account with access to the WorkPilot Teams app
- Your IT team or admin must have installed the WorkPilot Teams app in your tenant

## Connect to the Cloud Gateway

```bash
workpilot cloud
```

This will:

1. Open your browser (or show a device code for headless environments)
2. Ask you to sign in with your Microsoft account
3. Establish a connection to the Cloud Gateway
4. Keep running — keep this terminal open while you use Teams

You should see output like:

```
Gateway : wss://workpilot-gw-dev.azurewebsites.net/connect
Tenant  : 72f988bf-86f1-41af-91ab-2d7cd011db47
Login   : browser -> device code fallback
```

After signing in, your agent is reachable from Teams.

## Login methods

Use `--login` to control how you sign in:

| Method | Command | When to use |
|--------|---------|-------------|
| Auto (default) | `workpilot cloud` | Normal use — tries browser, falls back to device code |
| Browser | `workpilot cloud --login browser` | When you want to force the browser popup |
| Device code | `workpilot cloud --login device` | Headless servers, WSL, SSH sessions without a browser |

### Device code example

```bash
workpilot cloud --login device
```

Output:

```
To sign in, use a web browser to open https://microsoft.com/devicelogin
and enter the code ABCD-1234 to authenticate.
```

Open the URL on any device, enter the code, and sign in with your work account.

## Using WorkPilot in Teams

Once connected, find the WorkPilot app in Teams. You can chat with it directly or @mention it in a channel (depending on how your admin has configured the app).

Messages you send in Teams are routed to your local agent. Responses appear in Teams, usually within a few seconds.

## Keep the connection alive

The `workpilot cloud` process must stay running for Teams messages to reach your agent. For long-running use, consider:

- Running it in a screen or tmux session
- Using `workpilot serve` instead (see below), which manages the cloud connection automatically

## Using serve with cloud

If you run `workpilot serve` with the cloud channel enabled in your config, the gateway handles the Teams connection automatically:

```yaml
# workpilot.yaml
channels:
  cloud:
    enabled: true
```

Then just run:

```bash
workpilot serve
```

To check if the cloud channel is connected:

```bash
workpilot cloud
```

If `workpilot serve` is running and already connected, this command shows the current status and exits without starting another connection.

## Token cache

After your first sign-in, WorkPilot caches your authentication token so subsequent startups connect silently without prompting you again.

The token cache is stored at:

```
~/.workpilot/token_cache_<client-id-prefix>.json
```

To force a fresh sign-in, delete this file:

```bash
# On Windows (PowerShell)
Remove-Item "$env:USERPROFILE\.workpilot\token_cache_*.json"

# On Linux/macOS
rm ~/.workpilot/token_cache_*.json
```

## Admin portal

To monitor connected agents, see which users are active, and manage the Cloud Gateway, visit:

```
https://workpilot-gw-dev.azurewebsites.net/portal
```

You must sign in with an Entra ID account that has admin access. See [Admin Portal](../admin/portal.md) for details.

## Configuration reference

The Cloud Gateway is pre-configured with defaults that work out of the box. You only need to change these if you are self-hosting a private gateway.

```yaml
channels:
  cloud:
    enabled: true
    url: "wss://workpilot-gw-dev.azurewebsites.net/connect"
    tenant_id: "72f988bf-86f1-41af-91ab-2d7cd011db47"
    client_id: "c5bdcb9d-14dc-4b8a-9530-643d9db6df25"
    scope: "c5bdcb9d-14dc-4b8a-9530-643d9db6df25/.default"
    login_method: "auto"          # auto | browser | device
    auto_reconnect: true
    reconnect_max: 60             # max reconnect attempts
```

## Troubleshooting

**"Disconnected from Cloud Gateway"** — Your token may have expired or the network connection dropped. Run `workpilot cloud` again to reconnect.

**"Could not query running gateway"** — `workpilot serve` is running but not responding. Check `workpilot logs` for errors.

**Teams messages not arriving** — Check that `workpilot cloud` or `workpilot serve` with cloud enabled is running. Check the admin portal to confirm your agent shows as connected.

**Sign-in fails with AADSTS9002326** — Your Microsoft 365 tenant's Conditional Access policy may block device code. Use `--login browser` instead.

For more troubleshooting help, see [Troubleshooting](../troubleshooting.md).
