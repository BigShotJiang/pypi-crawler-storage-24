# Command Reference

Complete reference for all WorkPilot CLI commands.

## Top-level commands

### workpilot chat

Start an interactive agent REPL session.

```bash
workpilot chat [--config PATH] [--profile PROFILE]
```

If `workpilot serve` is already running, `chat` detects the running gateway via the PID file at `~/.workpilot/gateway.pid` and connects over WebSocket instead of starting a new agent instance.

| Option | Short | Description |
|--------|-------|-------------|
| `--config PATH` | `-c` | Config file or directory (default: current directory) |
| `--profile PROFILE` | `-p` | Security profile override |

**Slash commands available inside the REPL:**

| Command | Description |
|---------|-------------|
| `/help` | Show available commands |
| `/new` | Clear session, start fresh |
| `/status` | Show agent name, model, session ID, message count |
| `/memory` | Show MEMORY.md contents |
| `/tools` | List available tools |
| `/skills` | List loaded skills |
| `/history [N]` | Show last N messages (default 10) |
| `/model` | Show current model |
| `/stop` | Interrupt hint |
| `/exit` | Exit hint |

---

### workpilot run

Run the agent with a one-shot prompt.

```bash
workpilot run "PROMPT" [OPTIONS]
```

| Option | Short | Description |
|--------|-------|-------------|
| `--config PATH` | `-c` | Config file or directory |
| `--profile PROFILE` | `-p` | Security profile |
| `--session ID` | `-s` | Resume a previous session |
| `--model MODEL` | `-m` | Override model for this run |
| `--output FILE` | `-o` | Write response to file |

**Examples:**

```bash
workpilot run "Summarise the last git commit"
workpilot run "Review orders.py" --model github/gpt-4o
workpilot run "Continue the refactor" --session abc-123
workpilot run "Generate changelog" --output changelog.md
```

---

### workpilot serve

Start the HTTP gateway server.

```bash
workpilot serve [--config PATH] [--profile PROFILE] [--host HOST] [--port PORT]
```

Enforces single-instance: if a gateway is already running, shows the existing PID and port and exits.

| Option | Description |
|--------|-------------|
| `--host HOST` | Bind host (default: localhost) |
| `--port PORT` | Bind port (default: 3003) |

---

### workpilot cloud

Connect to the WorkPilot Cloud Gateway (Teams, Web Chat).

```bash
workpilot cloud [--config PATH] [--url URL] [--login METHOD]
```

If `workpilot serve` is running and the cloud channel is already connected, shows the status and exits.

| Option | Description |
|--------|-------------|
| `--url URL` | Override Cloud Gateway WSS URL |
| `--scope SCOPE` | Override Entra ID scope |
| `--login METHOD` | Login method: `auto` (default), `browser`, `device` |

---

### workpilot init

Create or update the local config file (`workpilot.local.yaml`).

```bash
workpilot init [--dir PATH] [--name NAME]
```

Safe to run multiple times. Existing values are shown as defaults.

| Option | Description |
|--------|-------------|
| `--dir PATH` | Target directory (default: current directory) |
| `--name NAME` | Set the project name in the config |

---

### workpilot status

Show runtime configuration status.

```bash
workpilot status [--config PATH] [--profile PROFILE]
```

Displays agents, channels, security settings, and feature status.

---

### workpilot doctor

Run health diagnostics.

```bash
workpilot doctor [--config PATH] [--profile PROFILE]
```

Checks: Python version, config validity, LLM provider keys, optional packages, tool configuration, credential provider.

---

### workpilot logs

Show recent log output.

```bash
workpilot logs [--lines N] [--config PATH]
```

| Option | Short | Description |
|--------|-------|-------------|
| `--lines N` | `-n` | Number of lines to show (default: 50) |

Requires `logging.file` to be set in `workpilot.yaml`. Without a log file, logs go to stderr.

---

### workpilot version

Print the WorkPilot version.

```bash
workpilot version
```

---

## Sub-commands

### workpilot agents

```bash
workpilot agents list [--config PATH]
workpilot agents add NAME [--config PATH]
```

`agents list` — Show all configured agents with model, temperature, iteration limit, and tools.

`agents add NAME` — Add a new agent interactively. Prompts for model, instructions, temperature, and max iterations, then saves to `workpilot.yaml`.

---

### workpilot tools

```bash
workpilot tools list [--config PATH]
workpilot tools info NAME [--config PATH]
```

`tools list` — List all built-in tools (with risk level) and any configured MCP servers.

`tools info NAME` — Show detailed information for a specific tool.

---

### workpilot mcp

```bash
workpilot mcp list [--config PATH]
workpilot mcp add NAME COMMAND [--config PATH]
workpilot mcp remove NAME [--config PATH]
```

`mcp list` — Show all configured MCP servers with transport type and command/URL.

`mcp add NAME COMMAND` — Add an MCP server (stdio transport). `COMMAND` is the full command string, e.g. `"npx -y @my-org/mcp-server"`.

`mcp remove NAME` — Remove an MCP server from the configuration.

---

### workpilot sessions

```bash
workpilot sessions list
workpilot sessions show SESSION_ID [--lines N]
workpilot sessions delete SESSION_ID [--yes]
workpilot sessions export SESSION_ID [--format md|json] [--output FILE]
```

`sessions list` — Show all saved sessions with size, message count, and last modified time.

`sessions show` — Show messages in a session. `--lines N` controls how many recent messages to display (default: 20).

`sessions delete` — Delete a session file. Prompts for confirmation unless `--yes` is passed.

`sessions export` — Export a session to markdown (`--format md`, default) or JSON (`--format json`). Output goes to `<session-id>.<format>` by default; use `--output` to specify a path.

---

### workpilot memory

```bash
workpilot memory show [--config PATH]
workpilot memory search QUERY [--config PATH]
workpilot memory clear [--config PATH]
workpilot memory stats [--config PATH]
```

`memory show` — Show the current contents of MEMORY.md.

`memory search QUERY` — Search session history for a query string.

`memory clear` — Clear MEMORY.md facts. Does not delete session history.

`memory stats` — Show memory statistics (MEMORY.md size, session count, etc.).

---

### workpilot secrets

```bash
workpilot secrets set KEY [--from-env VAR]
workpilot secrets remove KEY
workpilot secrets test
```

`secrets set KEY` — Store a secret (prompts for value interactively). Use `--from-env VAR` to copy from an environment variable instead.

`secrets remove KEY` — Remove a secret from the local credential store.

`secrets test` — Test configured secrets by making minimal API calls to verify they work.

---

### workpilot skills

```bash
workpilot skills list [--config PATH]
workpilot skills show NAME [--config PATH]
```

`skills list` — Lists all loaded skills with their mode (always / available), triggers, and description.

`skills show` — Print the full content of a skill file by name.

---

### workpilot cron

```bash
workpilot cron list [--config PATH]
workpilot cron add [--config PATH]
workpilot cron remove NAME [--config PATH]
workpilot cron enable NAME [--config PATH]
workpilot cron disable NAME [--config PATH]
workpilot cron status [--config PATH]
workpilot cron history [JOB_ID] [--config PATH]
```

`cron list` — Show all configured scheduled jobs.

`cron add` — Add a new job interactively. Prompts for name, schedule, agent, and prompt.

`cron remove NAME` — Remove a cron job from the configuration.

`cron enable NAME` — Enable a disabled cron job.

`cron disable NAME` — Disable a cron job without removing it.

`cron status` — Show scheduler health and job counts.

`cron history [JOB_ID]` — Show execution history. Optionally filter by job ID.

---

### workpilot security

```bash
workpilot security status [--config PATH]
workpilot security audit [--config PATH]
workpilot security credentials [--config PATH]
workpilot security roles [--config PATH]
workpilot security allowlist list|add|remove [OPTIONS]
workpilot security estop
workpilot security reset
```

`security status` — Show the active security profile and current E-stop state.

`security audit` — Show audit configuration and the last 10 audit events.

`security credentials` — Show which credential environment variables are set (never shows actual values).

`security roles` — Show RBAC roles, their permissions, and the autonomy defaults for the active profile.

`security estop` — Trigger emergency stop — halts all agent activity immediately.

`security reset` — Reset E-stop and resume normal operation.

`security allowlist list` — List pre-approved tool patterns.

`security allowlist add` — Add an allowlist entry.

| Option | Short | Description |
|--------|-------|-------------|
| `--tool NAME` | `-t` | Tool name (required) |
| `--pattern REGEX` | `-p` | Argument regex pattern (optional, matches all if omitted) |
| `--note TEXT` | `-n` | Human-readable note |

`security allowlist remove` — Remove an entry by index.

| Option | Short | Description |
|--------|-------|-------------|
| `--index N` | `-i` | Index from `allowlist list` (required) |

---

## Global options

Most commands accept these options:

| Option | Short | Description |
|--------|-------|-------------|
| `--config PATH` | `-c` | Config file or directory (default: `.`) |
| `--profile PROFILE` | `-p` | Override security profile |

---

## Environment variables

| Variable | Description |
|----------|-------------|
| `GITHUB_TOKEN` | GitHub token for Copilot access |
| `OPENAI_API_KEY` | OpenAI API key |
| `AZURE_OPENAI_API_KEY` | Azure OpenAI API key |
| `ADO_PAT` | Azure DevOps personal access token |
