# Configuration Reference

WorkPilot is configured with YAML files. Two files are used:

| File | Purpose | Commit to git? |
|------|---------|----------------|
| `workpilot.yaml` | Team/project settings | Yes |
| `workpilot.local.yaml` | Personal settings, API keys | No (gitignored) |

Values in `workpilot.local.yaml` are deep-merged on top of `workpilot.yaml`. Use `workpilot.local.yaml` for secrets and machine-specific settings.

Run `workpilot init` to create `workpilot.local.yaml` interactively.

---

## Top-level fields

```yaml
name: "My Project"          # Display name shown in status and logs
entrypoint: default         # Agent to use as the default (default: "default")
```

---

## providers

LLM provider credentials and model configuration.

```yaml
providers:
  github_copilot:
    token: "${GITHUB_TOKEN}"         # GitHub token for Copilot access

  openai:
    api_key: "${OPENAI_API_KEY}"
    api_base: ""                     # Optional: custom base URL

  azure_openai:
    api_key: "${AZURE_OPENAI_API_KEY}"
    endpoint: "https://your-resource.openai.azure.com"
    deployment: "gpt-4o"
    api_version: "2024-10-21"

  ai_foundry:
    endpoint: "https://your-resource.api.azureml.ms"
    api_key: "${AI_FOUNDRY_KEY}"
    deployment: "gpt-4o"

  aliases:
    default: "auto"         # auto = pick best available
    fast: "auto"
    reasoning: "auto"
    coding: "auto"

  fallback:
    enabled: true
    chain:
      - "github/gpt-4o"
      - "azure_ai/gpt-4o"
      - "openai/gpt-4o"
    max_retries: 2
```

**Model name format**: `provider/model-name`, for example `github/gpt-4o`, `openai/gpt-4o-mini`, `azure_ai/gpt-4o`. Use `auto` to let WorkPilot choose based on available credentials.

---

## agents

Configure the default agent and any additional custom agents.

```yaml
agents:
  default:
    name: "WorkPilot Assistant"
    model: "auto"
    instructions: ""             # System prompt additions
    temperature: 0.3
    max_tokens: 8192
    max_iterations: 40
    timeout: 1200                # seconds per conversation turn
    memory_window: 50            # messages to keep in active context
    memory_writable: true        # allow agent to update MEMORY.md
    context_limit: 128000        # token budget for compaction thresholds
    workspace: "."               # working directory for file operations
    tools:
      - shell
      - read_file
      - write_file
      - edit_file
      - list_dir
      - search_files
      - git
      - http_request
      - web_search
      - web_fetch
      - browser
      - spawn
      - message
    skills: []                   # skill names to load (empty = all)

  # Custom agent example
  my-reviewer:
    model: "auto"
    instructions: "You are a code reviewer. Be thorough and constructive."
    temperature: 0.1
    max_iterations: 20
    tools:
      - read_file
      - list_dir
      - git
    permissions:
      allow_shell: false
      allow_file_write: false
```

### Agent permissions

```yaml
agents:
  my-agent:
    permissions:
      allow_shell: true
      allow_file_write: true
      allow_file_read: true
      allow_network: true
      allow_browser: false
      allow_spawn: false
      allowed_tools:
        - "*"              # "*" = all tools
      denied_tools: []
```

---

## security

```yaml
security:
  profile: standard              # open | standard | controlled | restricted
  credential_provider: env       # env | dotenv | azure-keyvault
  azure_keyvault_url: ""         # required if using azure-keyvault

  audit:
    enabled: true
    log_file: ""                 # empty = stderr; set to a path for file logging
    redact_secrets: true

  estop:
    enabled: true
    trigger_on_leak: true        # auto-stop on credential detection
    notify_channels: []

  default_role: user
  require_auth: false

  roles:
    admin:
      name: admin
      allowed_tools:
        - "*"
      denied_tools: []
      allowed_channels:
        - "*"
      max_iterations: 40

  approval:
    timeout_seconds: 900         # 15 minutes before escalation
    auto_approve_timeout: 180    # 3 minutes for low-risk auto-approve
    escalation_channels:
      - teams
    default_channel: cli

  allowlist:
    enabled: true
    path: ""                     # default: ~/.workpilot/allowlist.json
```

---

## tools

```yaml
tools:
  shell:
    timeout: 120                 # seconds per shell command
    max_output_chars: 50000
    deny_patterns:               # regex patterns — matching commands are blocked
      - "rm\\s+-rf\\s+/"
      - ":\\(\\)\\s*\\{\\s*:\\|:&\\s*\\}\\s*;"
      - "shutdown"
      - "reboot"
      - "mkfs"
    allow_patterns: []           # patterns that bypass deny_patterns

  filesystem:
    restrict_to_workspace: true  # block access outside workspace directory
    max_file_size_bytes: 10485760  # 10 MB
    deny_paths:
      - "/etc/shadow"
      - "/etc/passwd"
      - "~/.ssh"
      - "~/.gnupg"
      - "~/.aws/credentials"

  browser:
    enabled: false
    browser: msedge              # msedge | chromium | firefox
    headless: true
    timeout: 30000               # milliseconds
    allowed_domains: []          # empty = all (SSRF rules still apply)

  copilot:
    enabled: true
    default_model: "claude-sonnet-4.6"
    task_timeout: 0              # 0 = 1-hour cap
    max_concurrent: 5
    model_policy:
      code: "claude-sonnet-4.6"
      review: "claude-sonnet-4.6"
      test: "claude-haiku-4.5"
      refactor: "claude-sonnet-4.6"

  mcp_servers:
    my-server:
      command: "npx"
      args: ["-y", "@my-org/mcp-server"]
      env:
        MY_KEY: "${MY_KEY}"

    my-http-server:
      url: "http://localhost:8080"
```

---

## gateway

```yaml
gateway:
  enabled: false
  host: localhost
  port: 3003
  api_key: "${WORKPILOT_API_KEY}"   # optional; enables bearer token auth
  cors_origins: []                   # empty = same-origin only
  rate_limit_per_minute: 60
  request_timeout: 300               # per-request timeout in seconds
  entra_tenant_id: ""                # for Entra ID gateway auth
  entra_client_id: ""
```

---

## channels

```yaml
channels:
  cli:
    enabled: true
    prompt: "you> "

  cloud:
    enabled: true
    url: "wss://workpilot-gw-dev.azurewebsites.net/connect"
    tenant_id: "72f988bf-86f1-41af-91ab-2d7cd011db47"
    client_id: "c5bdcb9d-14dc-4b8a-9530-643d9db6df25"
    scope: "c5bdcb9d-14dc-4b8a-9530-643d9db6df25/.default"
    login_method: auto             # auto | browser | device
    auto_reconnect: true
    reconnect_max: 60

  teams:
    enabled: false
    app_id: "${TEAMS_APP_ID}"
    app_password: "${TEAMS_APP_PASSWORD}"
    tenant_id: "${TEAMS_TENANT_ID}"

  outlook:
    enabled: false
    client_id: "${OUTLOOK_CLIENT_ID}"
    client_secret: "${OUTLOOK_CLIENT_SECRET}"
    tenant_id: "${OUTLOOK_TENANT_ID}"
    user_email: "me@example.com"

  github:
    enabled: false
    token: "${GITHUB_TOKEN}"
    webhook_secret: "${GITHUB_WEBHOOK_SECRET}"

  ado:
    enabled: false
    organization: "my-org"
    project: "my-project"
    pat: "${ADO_PAT}"
```

---

## cron

```yaml
cron:
  enabled: false
  timezone: "UTC"
  max_concurrent_jobs: 3

  jobs:
    daily-standup:
      schedule: "0 9 * * 1-5"        # cron expression
      agent: default
      prompt: "Summarise overnight activity"
      session_mode: isolated           # isolated | persistent
      notify_channels: []
      enabled: true
      timeout: 300                     # seconds; 0 or omit = no limit
```

Schedule formats:

| Format | Example | Meaning |
|--------|---------|---------|
| Cron expression | `"0 9 * * 1-5"` | 9am weekdays |
| Interval (seconds) | `3600` | Every hour |
| One-time (absolute) | `"at:2026-04-01T09:00:00"` | Once at this time |
| One-time (relative) | `"at:+3600"` | Once in 1 hour |

---

## logging

```yaml
logging:
  level: INFO                  # TRACE | DEBUG | INFO | WARNING | ERROR | CRITICAL
  format: pretty               # pretty | json
  file: ""                     # path to log file; empty = stderr
```

---

## Environment variable substitution

Any value in `workpilot.yaml` or `workpilot.local.yaml` can reference an environment variable using `${VAR_NAME}` syntax:

```yaml
providers:
  github_copilot:
    token: "${GITHUB_TOKEN}"
```

If the variable is not set, the value is treated as empty.
