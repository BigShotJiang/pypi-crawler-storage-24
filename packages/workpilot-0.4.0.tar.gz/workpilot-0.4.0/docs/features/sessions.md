# Sessions

WorkPilot stores every conversation as a session. Sessions let you resume past conversations, review what the agent did, export conversation history, and manage storage.

## How sessions work

Every conversation has a session ID. When you start `workpilot chat`, a new session is created automatically. As you chat, each message is appended to a JSONL file at:

```
~/.workpilot/sessions/<session-id>.jsonl
```

Each line in the file is a JSON object representing one message (user, assistant, or tool call). Sessions are append-only — WorkPilot never modifies or deletes messages except when you explicitly delete a session.

## Resume a session

To continue a previous conversation, pass the session ID to `workpilot run`:

```bash
workpilot run "Continue with the refactoring we discussed" --session <session-id>
```

## List sessions

```bash
workpilot sessions list
```

Output shows session ID, file size, message count, and last modified time.

## View session contents

```bash
workpilot sessions show <session-id>
```

Shows the last 20 messages by default. To show more or fewer:

```bash
workpilot sessions show <session-id> --lines 50
workpilot sessions show <session-id> --lines 5
```

## Export a session

Export to markdown (default):

```bash
workpilot sessions export <session-id>
```

Creates `<session-id>.md` in the current directory.

Export to JSON:

```bash
workpilot sessions export <session-id> --format json
```

Write to a specific file:

```bash
workpilot sessions export <session-id> --output my-conversation.md
workpilot sessions export <session-id> --format json --output data.json
```

## Delete a session

```bash
workpilot sessions delete <session-id>
```

Prompts for confirmation before deleting. To skip the confirmation:

```bash
workpilot sessions delete <session-id> --yes
```

## Start a fresh session in the REPL

Inside `workpilot chat`, use the `/new` slash command:

```
you> /new
Session cleared. Starting fresh.
```

This starts a new session without losing the previous one.

## Session history inside the REPL

To review what was discussed in the current session:

```
you> /history
you> /history 20
```

## Memory across sessions

MEMORY.md is separate from session history. It holds persistent facts that survive across sessions (for example, your name, project preferences, and important context). The agent reads MEMORY.md at the start of every conversation.

To view MEMORY.md inside the REPL:

```
you> /memory
```

To view it from the command line:

```bash
workpilot memory show
```

## Sessions in the web API

When using the REST API, you can manage sessions:

```bash
# List sessions
curl http://localhost:3003/api/sessions

# Send a prompt and get back the session ID
curl -X POST http://localhost:3003/api/chat \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Hello"}'

# Resume that session
curl -X POST http://localhost:3003/api/chat \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Continue", "session_id": "the-id-from-before"}'
```

## Storage location

Sessions are stored at `~/.workpilot/sessions/`. Each session is a single `.jsonl` file. There is no automatic cleanup — delete old sessions manually or use `workpilot sessions delete` to free disk space.
