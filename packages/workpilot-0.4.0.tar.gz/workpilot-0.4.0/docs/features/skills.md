# Skills

Skills are prompt overlays that give the agent specialist knowledge for specific tasks. A skill is a Markdown file with a YAML frontmatter header. When the agent works on a task that matches a skill's triggers, it reads the skill's instructions and follows them.

## Bundled skills

WorkPilot ships with three bundled skills:

| Skill | Description |
|-------|-------------|
| `github` | GitHub workflow conventions — PR creation, branch naming, commit messages |
| `ado` | Azure DevOps conventions — work items, pipelines, pull requests |
| `azure-ops` | Azure operations — resource management, deployment patterns |

These are available automatically. No configuration is needed.

## List skills

```bash
workpilot skills list
```

Shows skill name, mode (always or available), triggers, and a short description.

Inside the REPL:

```
you> /skills
```

## Skill modes

| Mode | Behaviour |
|------|-----------|
| `always` | The skill is always included in the agent's context |
| `available` | The skill is included only when a relevant trigger keyword appears in the user's message |

`available` mode is more common because it keeps the context focused on what is relevant.

## Skill triggers

Triggers are keywords or phrases. When the user's message contains one of them, the skill is automatically loaded.

For example, a `github` skill might have triggers like `pull request`, `PR`, `branch`, `commit`, `merge`. If you ask "Can you help me write a PR description?", the `github` skill is loaded.

## Create a custom skill

Create a Markdown file with YAML frontmatter in your project's `.workpilot/skills/` directory:

```
your-project/
  .workpilot/
    skills/
      my-skill.md
```

### Skill file format

```markdown
---
name: python-style
description: Python code style conventions for this project
mode: available
triggers:
  - python
  - function
  - class
  - style
  - convention
---

# Python Style Guide

This project follows these conventions:

- Use type hints on all public functions
- Maximum line length is 100 characters
- Use `loguru` for logging, not `logging`
- All functions must have docstrings
- Use `pathlib.Path` instead of `os.path`
- Prefer `async/await` over threading

## Naming

- Classes: `PascalCase`
- Functions and variables: `snake_case`
- Constants: `UPPER_SNAKE_CASE`
- Private members: prefix with underscore `_`

## Error handling

Always raise specific exceptions, not `Exception`. Document exceptions in docstrings.
```

## Skill context budget

Skills consume a share of the agent's context window. To keep context efficient, WorkPilot limits skill summaries to approximately 2% of the available context. Long skills are summarised rather than fully included.

For skills where every word matters, use `mode: always` to ensure the full content is included.

## Workspace skill discovery

WorkPilot automatically finds skills in:

1. The bundled skills (shipped with WorkPilot)
2. `.workpilot/skills/` in your project workspace

No configuration is needed — just create the files and restart the agent.

## Assign skills to specific agents

In `workpilot.yaml`, you can restrict skills to specific agents:

```yaml
agents:
  default:
    skills:
      - github
      - python-style
```

If no skills are listed, all discovered skills are available.

## Use a skill from the REPL

You do not need to invoke skills manually. The agent loads them automatically based on triggers. You can check which skills are loaded at any point:

```
you> /skills
```

## SKILL.md (project-wide)

You can also create a single `SKILL.md` file in the root of your workspace. This is loaded as a single skill for the entire project. It is useful for documenting project-specific conventions that the agent should always follow.

```markdown
# Project Conventions

This project uses FastAPI for the web layer and SQLAlchemy for the database.
Always use async functions. Use Alembic for migrations.
```

Put this file at the root of your project directory (the same level as `workpilot.yaml`).
