# Scheduling

WorkPilot can run agent tasks automatically on a schedule. Use this for daily reports, recurring code reviews, periodic health checks, or any task that should run without manual prompting.

## Requirements

The scheduler requires APScheduler:

```bash
pip install apscheduler
```

Or install with all optional dependencies:

```bash
pip install "workpilot[all]"
```

## Enable the scheduler

In `workpilot.yaml`:

```yaml
cron:
  enabled: true
```

Or run `workpilot init` and enable cron when prompted.

## Schedule types

| Type | Format | Example |
|------|--------|---------|
| Cron expression | Standard 5-field cron | `"0 9 * * 1-5"` |
| Interval | Seconds as a number | `3600` |
| At (one-time) | `"at"` or `"at:<time>"` | `"at:2026-03-07T10:00:00"` |

### Cron expression examples

| Expression | Meaning |
|------------|---------|
| `"0 9 * * 1-5"` | 9:00 AM Monday to Friday |
| `"0 */4 * * *"` | Every 4 hours |
| `"30 17 * * 5"` | 5:30 PM every Friday |
| `"0 0 1 * *"` | Midnight on the first of every month |

### Interval examples

| Value | Meaning |
|-------|---------|
| `3600` | Every hour |
| `300` | Every 5 minutes |
| `86400` | Once per day |

## Configure jobs in workpilot.yaml

```yaml
cron:
  enabled: true
  jobs:
    daily-standup:
      schedule: "0 9 * * 1-5"        # 9am weekdays
      agent: default
      prompt: "Summarise the git commits from the last 24 hours and any open issues"
      session_mode: isolated          # isolated = fresh context each run
      notify_channels: []             # optional: send result to Teams, email, etc.
      enabled: true

    hourly-health:
      schedule: 3600                  # every hour (seconds)
      agent: default
      prompt: "Run a quick health check: are tests passing, any pending PRs?"
      session_mode: isolated
      enabled: true

    weekly-review:
      schedule: "0 17 * * 5"          # 5pm Friday
      agent: default
      prompt: "Generate a weekly summary of work completed and areas needing attention"
      session_mode: isolated
      enabled: true
```

## Session modes

| Mode | Description |
|------|-------------|
| `isolated` | Each run starts with a fresh context (default, recommended) |
| `persistent` | Each run continues the previous session — the agent remembers past runs |

Use `persistent` for jobs that need to track state across runs (for example, tracking a long-running migration).

## List jobs

```bash
workpilot cron list
```

Shows all configured jobs with their schedule, agent, and enabled status.

## Add a job interactively

```bash
workpilot cron add
```

The wizard prompts for:
- Job name
- Cron schedule (e.g. `0 9 * * 1-5`)
- Agent name (default: `default`)
- Prompt

The job is saved to `workpilot.yaml`.

## The jobs run when serve is running

Scheduled jobs only execute when `workpilot serve` is running. Start the gateway to activate scheduling:

```bash
workpilot serve
```

## Notify channels

You can send job results to a channel automatically:

```yaml
cron:
  jobs:
    daily-report:
      schedule: "0 9 * * 1-5"
      agent: default
      prompt: "Generate the daily status report"
      notify_channels:
        - teams
        - email
```

This requires the relevant channels to be configured and enabled.

## Timeout

Set a per-job timeout in seconds:

```yaml
cron:
  jobs:
    quick-check:
      schedule: 3600
      agent: default
      prompt: "Quick health check"
      timeout: 60         # fail if not done within 60 seconds
```

## One-time scheduled tasks (at)

Schedule a task to run once at a specific time:

```yaml
cron:
  jobs:
    release-prep:
      schedule: "at:2026-04-01T09:00:00"   # run once at this time
      agent: default
      prompt: "Prepare the release notes for v1.0"
```

Or relative to now:

```yaml
    quick-one-off:
      schedule: "at:+3600"    # run once in 60 minutes
```

## Global cron settings

```yaml
cron:
  enabled: true
  timezone: "UTC"             # timezone for cron expressions
  max_concurrent_jobs: 3      # max jobs running at the same time
```
