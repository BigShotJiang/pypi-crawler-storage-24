# Copilot Tasks

WorkPilot can delegate coding tasks to GitHub Copilot using the `gh_copilot` tool family. This lets the agent run code, review, test, and refactor tasks in the background while you continue working.

## Requirements

- A GitHub Copilot subscription
- GitHub token configured (set during `workpilot init` or via `GITHUB_TOKEN` environment variable)

## How it works

When you ask WorkPilot to implement a feature, write tests, or review code, it can optionally delegate that work to GitHub Copilot using the `gh_copilot` tool. Copilot runs the task and reports the result back to WorkPilot, which then presents it to you.

Tasks can run in the background (you get a task ID and check back later) or in wait mode (WorkPilot blocks until the task is done).

## Tools

### gh_copilot

Submits a task to GitHub Copilot.

| Parameter | Type | Description |
|-----------|------|-------------|
| `task` | string | Description of what to do |
| `task_type` | string | `code`, `review`, `test`, or `refactor` |
| `files` | list | Files relevant to the task (optional) |
| `mode` | string | `background` (default) or `wait` |
| `model` | string | Model to use (optional, defaults to per-type policy) |
| `resume_task_id` | string | Resume a previous task (optional) |

### gh_copilot_status

Check the status of a running or completed task.

| Parameter | Type | Description |
|-----------|------|-------------|
| `task_id` | string | Task ID to check (optional — lists all tasks if omitted) |

### gh_copilot_models

Lists available GitHub Copilot models and their context limits.

No parameters required.

## Task types

| Type | What Copilot does |
|------|--------------------|
| `code` | Implements the task, writes clean minimal code, runs tests if applicable |
| `review` | Reviews code for bugs, security issues, performance, and style violations |
| `test` | Writes tests using the existing test framework and conventions |
| `refactor` | Refactors code without changing behaviour; improves readability and reduces duplication |

## Default models per task type

| Task type | Default model |
|-----------|--------------|
| code | claude-sonnet-4.6 |
| review | claude-sonnet-4.6 |
| test | claude-haiku-4.5 |
| refactor | claude-sonnet-4.6 |

## Examples

Ask WorkPilot to delegate a task in natural language:

```
you> Implement the missing validate_email function in utils.py
you> Review the changes in my last commit
you> Write unit tests for the ShoppingCart class
you> Refactor the database connection module to remove duplication
```

WorkPilot will decide whether to use `gh_copilot` based on the task.

## Background vs wait mode

**Background mode** (default): WorkPilot submits the task and returns immediately with a task ID. Copilot works in the background. You can check progress:

```
you> What is the status of my Copilot tasks?
```

**Wait mode**: WorkPilot waits until the task is complete before responding. Useful when you need the result right away.

## Concurrent tasks

Up to 5 Copilot tasks can run concurrently by default. If you submit more, they queue until a slot is available.

To change the limit in `workpilot.yaml`:

```yaml
tools:
  copilot:
    max_concurrent: 10
```

## Configuration

In `workpilot.yaml`:

```yaml
tools:
  copilot:
    enabled: true
    default_model: "claude-sonnet-4.6"
    task_timeout: 0          # seconds; 0 = 1-hour cap
    max_concurrent: 5
    model_policy:
      code: "claude-sonnet-4.6"
      review: "claude-sonnet-4.6"
      test: "claude-haiku-4.5"
      refactor: "claude-sonnet-4.6"
```

To disable Copilot task delegation:

```yaml
tools:
  copilot:
    enabled: false
```
