# Admin Portal

The WorkPilot admin portal is a web interface for monitoring agent activity, reviewing audit logs, managing connected agents, and triggering emergency stops.

## Access

The admin portal is hosted at:

```
https://workpilot-gw-dev.azurewebsites.net/portal
```

Sign in with an Entra ID account that has admin access to the WorkPilot Cloud Gateway.

## What the portal shows

### Connected agents

A list of WorkPilot instances currently connected to the Cloud Gateway. For each agent you can see:

- Connection status (connected / disconnected)
- User identity (UPN)
- Connection time
- Message count

### Local gateway dashboard

When `workpilot serve` is running, the status dashboard is available at:

```
http://localhost:3003/
```

This dashboard refreshes automatically every 5 seconds and shows:

- Runtime status
- Active channels and their connection state
- Agent configuration summary
- Recent activity

### Health check

```
http://localhost:3003/health
```

Returns a simple JSON response indicating whether the gateway is running. Use this for monitoring and load balancer health checks.

```
http://localhost:3003/api/health
```

Returns detailed health information across all subsystems.

## Emergency stop (E-stop)

The emergency stop immediately halts all agent loops and makes the gateway return 503 for new requests. Use it if the agent is doing something unexpected and you need to stop it instantly.

### From the CLI

```bash
workpilot security status    # check E-stop state
workpilot security estop     # trigger immediately
```

### From the admin portal

Click the **Emergency Stop** button — no command line needed.

### Reset after E-stop

Once you have reviewed the situation and are ready to resume:

```bash
workpilot security reset
```

Or click the **Reset** button in the admin portal.

### Automatic E-stop

WorkPilot triggers E-stop automatically when it detects a potential credential leak in tool output or outbound messages. This is a safety mechanism to prevent sensitive information from leaving your system.

After an automatic E-stop:

1. Review `workpilot logs` and the audit log to understand what happened
2. If the alert was a false positive, run `workpilot security reset` or click Reset in the admin portal
3. Consider adjusting the secret redaction patterns if needed

## Audit log

WorkPilot logs every tool call, message, and security event to an append-only audit file. To view recent events:

```bash
workpilot security audit
```

The output shows:

- Audit enabled / disabled
- Whether secret redaction is active
- Log file location
- Last 10 audit events

To configure the audit log file location:

```yaml
security:
  audit:
    enabled: true
    log_file: "/var/log/workpilot/audit.jsonl"
    redact_secrets: true
```

## Credential status

To check which credentials are configured (without revealing the actual values):

```bash
workpilot security credentials
```

Shows the status of all known credential environment variables (set / not set).

## RBAC roles

```bash
workpilot security roles
```

Shows the configured roles, their allowed and denied tools, permitted channels, and iteration limits. Also shows the autonomy defaults for the active security profile.

## Tool approval allowlist

When a tool requires human approval (based on the security profile), you can pre-approve specific patterns so they do not prompt every time:

```bash
# Show the current allowlist
workpilot security allowlist list

# Pre-approve all git read operations
workpilot security allowlist add --tool git --pattern "status|log|diff|show"

# Pre-approve running tests
workpilot security allowlist add --tool shell --pattern "pytest.*" --note "Test runner"

# Remove an entry by index
workpilot security allowlist remove --index 0
```

The allowlist is stored at `~/.workpilot/allowlist.json`.

## Runtime status

```bash
workpilot status
```

Shows:

- WorkPilot version
- Security profile in use
- Configured agents (name, model, tools)
- Channel status (enabled / disabled)
- Feature status (gateway, cron, browser)
- MCP server count and names
