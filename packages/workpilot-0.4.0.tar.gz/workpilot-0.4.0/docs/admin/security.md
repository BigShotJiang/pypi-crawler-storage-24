# Security

WorkPilot is designed to be safe to run in enterprise environments. This page describes the security controls, how to configure them, and what they protect against.

## Security profiles

The security profile controls how much autonomy the agent has. Set it in `workpilot.yaml` or during `workpilot init`.

| Profile | Description | Best for |
|---------|-------------|----------|
| `open` | Full autonomy — agent acts without prompting for approval | Trusted personal machines, power users |
| `standard` | Medium risk operations require approval | Most users (default) |
| `controlled` | All tool calls go through the Security Classifier | Shared environments, sensitive codebases |
| `restricted` | Human approval required for all actions; sub-agents disabled | High-security or compliance environments |

To set the profile:

```yaml
security:
  profile: standard
```

Or override for a single run:

```bash
workpilot run "Fix the bug" --profile controlled
```

## Security Classifier

The Security Classifier is a fast internal agent that reviews tool calls before they are executed. It classifies calls as:

- **approve** — the call looks safe, proceed
- **reject** — the call looks dangerous, block it
- **escalate** — uncertain, requires human review

In the current release, escalations are treated as rejections (human routing is planned for a future version). Results are cached for 5 minutes to avoid redundant checks.

Sensitive argument values are redacted before being sent to the classifier.

## Tool approval levels

Each tool is assigned an autonomy level based on the active security profile:

| Level | Behaviour |
|-------|-----------|
| `autonomous` | Tool executes silently (audit log only) |
| `notify` | Tool executes, result is logged and shown |
| `approval` | Human must approve before tool executes |
| `forbidden` | Tool is not allowed at all |

## Command sandbox

WorkPilot blocks shell commands that match dangerous patterns. The defaults block:

- `rm -rf /` and similar destructive deletions
- Fork bombs
- Disk formatting commands (`mkfs`, `dd if=/dev/...`)
- `shutdown` and `reboot`
- Piped shell execution (`curl ... | sh`, `wget ... | bash`)
- Recursive ownership changes to root
- `chmod 777`

To view the active deny patterns:

```bash
workpilot security audit
```

To add custom patterns in `workpilot.yaml`:

```yaml
tools:
  shell:
    deny_patterns:
      - "my-dangerous-command"
      - "rm.*important-dir"
```

## File system sandbox

By default, the agent can only read and write files within the configured workspace directory. Access to sensitive system paths is denied regardless of profile.

Denied paths include `/etc/shadow`, `/etc/passwd`, `~/.ssh`, `~/.gnupg`, and `~/.aws/credentials`.

To configure:

```yaml
tools:
  filesystem:
    restrict_to_workspace: true          # default: true
    max_file_size_bytes: 10485760        # default: 10 MB
    deny_paths:
      - "/etc/shadow"
      - "~/.ssh"
```

## Secret redaction

WorkPilot automatically redacts secrets from:

- Tool output before it is shown to you
- Outbound messages before they are sent to any channel
- Audit log entries

Patterns detected include: JWT tokens, AWS access keys, GitHub PATs, OpenAI keys, Slack tokens, and high-entropy strings that look like credentials.

To disable redaction (not recommended):

```yaml
security:
  audit:
    redact_secrets: false
```

## Leak detection and automatic E-stop

If a suspected credential appears in tool output or an outbound message, WorkPilot triggers an emergency stop automatically. All agent loops halt and the gateway returns 503 until you reset it.

To reset after an E-stop:

```bash
workpilot security reset
```

To disable automatic E-stop on leak detection:

```yaml
security:
  estop:
    trigger_on_leak: false
```

## RBAC (Role-Based Access Control)

You can define roles that restrict what different users can do. Each role specifies:

- Which tools are allowed or denied
- Which channels are permitted
- Maximum iteration count

Example:

```yaml
security:
  default_role: user
  roles:
    admin:
      name: admin
      allowed_tools:
        - "*"
      denied_tools: []
      allowed_channels:
        - "*"
      max_iterations: 40

    user:
      name: user
      allowed_tools:
        - read_file
        - list_dir
        - git
        - http_request
      denied_tools:
        - shell
        - write_file
      allowed_channels:
        - teams
        - cli
      max_iterations: 20
```

To view configured roles:

```bash
workpilot security roles
```

## Per-user tool approval allowlist

Users can pre-approve specific tool patterns to avoid repeated approval prompts. Allowlist entries are stored per-user in `~/.workpilot/allowlist.json`.

```bash
workpilot security allowlist list
workpilot security allowlist add --tool git --pattern "log|status|diff"
workpilot security allowlist remove --index 0
```

## Credential providers

Credentials can be loaded from different sources:

| Provider | Configuration |
|----------|--------------|
| `env` | Environment variables (default) |
| `dotenv` | `.env` file in the workspace |
| `azure-keyvault` | Azure Key Vault |

To use Azure Key Vault:

```yaml
security:
  credential_provider: azure-keyvault
  azure_keyvault_url: "https://your-vault.vault.azure.net"
```

To check which credentials are set:

```bash
workpilot security credentials
```

## Audit log

All tool calls, messages, and security events are recorded in an append-only audit log. To configure:

```yaml
security:
  audit:
    enabled: true
    log_file: "/var/log/workpilot/audit.jsonl"
    redact_secrets: true
```

To view recent audit events:

```bash
workpilot security audit
```

## SSRF protection

WorkPilot blocks HTTP requests that target internal network addresses (169.254.x.x, 10.x.x.x, 172.16-31.x.x, 192.168.x.x, localhost, etc.) to prevent server-side request forgery attacks. This applies to all HTTP tools.

## MCP tool isolation

Tools loaded from MCP (Model Context Protocol) servers are untrusted by default. In `restricted` profile, MCP tools are isolated in a container. You can grant trust to specific MCP servers in `workpilot.yaml` if needed.

## Per-agent permissions

Each agent can have its own permission set, independent of the global profile:

```yaml
agents:
  my-reviewer:
    permissions:
      allow_shell: false
      allow_file_write: false
      allow_file_read: true
      allow_network: true
      allow_browser: false
      allow_spawn: false
```

This restricts the `my-reviewer` agent to read-only operations even if the global profile would allow more.
