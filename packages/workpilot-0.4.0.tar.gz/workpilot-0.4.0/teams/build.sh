#!/usr/bin/env bash
# Build the WorkPilot Teams app package (WorkPilot-teams-app.zip)
# Run from the teams/ directory:  ./build.sh
set -e
cd "$(dirname "$0")"

# Validate
if [[ ! -f manifest.json ]]; then echo "ERROR: manifest.json not found" && exit 1; fi
if [[ ! -f color.png || ! -f outline.png ]]; then echo "ERROR: color.png/outline.png not found" && exit 1; fi

# Package
OUT="WorkPilot-teams-app.zip"
rm -f "$OUT"
zip "$OUT" manifest.json color.png outline.png
echo "Created $OUT  ($(du -sh "$OUT" | cut -f1))"
echo ""
echo "Install in Teams:"
echo "  Teams → Apps → Manage your apps → Upload a custom app → $OUT"
