"""
Dev environment smoke tests against deployed Azure App Service.
Usage: python tests/e2e_dev_smoke.py
"""
import asyncio
import json
import sys

import httpx
import websockets

BASE    = "https://workpilot-gw-dev.azurewebsites.net"
BASE_WS = "wss://workpilot-gw-dev.azurewebsites.net"
TOKEN   = "dev-bypass"
H       = {"Authorization": f"Bearer {TOKEN}"}

passed = failed = 0

def ok(label):
    global passed
    passed += 1
    print(f"  PASS  {label}")

def fail(label, r=""):
    global failed
    failed += 1
    print(f"  FAIL  {label}" + (f": {r}" if r else ""))

async def recv(ws, timeout=15):
    async with asyncio.timeout(timeout):
        return json.loads(await ws.recv())

async def drain_connect(ws):
    """Read connected frame + optional buffered_start/messages/buffered_end sequence."""
    frame = await recv(ws)
    assert frame["type"] == "connected", f"expected connected, got {frame}"
    if frame.get("buffered_count", 0) > 0:
        while True:
            f = await recv(ws)
            if f["type"] == "buffered_end":
                break
    return frame

async def main():
    print("=" * 60)
    print("Dev E2E Smoke Tests")
    print(BASE)
    print("=" * 60)

    async with httpx.AsyncClient(timeout=15) as c:

        # 1. Health
        r = await c.get(f"{BASE}/health")
        if r.status_code == 200 and r.json().get("status") == "ok":
            ok("/health 200 ok")
        else:
            fail("/health", f"{r.status_code} {r.text[:80]}")

        # 2. Health ready
        r = await c.get(f"{BASE}/health/ready")
        if r.status_code == 200 and r.json().get("status") == "ready":
            ok("/health/ready 200 ready")
        else:
            fail("/health/ready", f"{r.status_code} {r.text[:80]}")

        # 3. Auth boundary
        r = await c.get(f"{BASE}/connect")
        if r.status_code == 401:
            ok("/connect no-auth -> 401")
        else:
            fail("/connect no-auth", f"got {r.status_code}")

        r = await c.get(f"{BASE}/webchat")
        if r.status_code == 401:
            ok("/webchat no-auth -> 401")
        else:
            fail("/webchat no-auth", f"got {r.status_code}")

    # 4. /connect WebSocket with bypass token
    try:
        async with websockets.connect(f"{BASE_WS}/connect", additional_headers=H) as ws:
            frame = await recv(ws)
            if frame.get("type") == "connected":
                ok(f"/connect WS connected buffered_count={frame.get('buffered_count',0)}")
            else:
                fail("/connect WS", f"unexpected frame: {frame}")

            # 5. reply_context_expired for stale channel_id
            fake_cid = "cid_00000000-0000-0000-0000-000000000000"
            await ws.send(json.dumps({"type": "response", "channel_id": fake_cid,
                                      "content": "test", "format": "markdown"}))
            # Drain frames until we get the error (may arrive after a ping frame)
            err = None
            try:
                for _ in range(5):
                    frame = await recv(ws, timeout=15)
                    if frame.get("type") == "error":
                        err = frame
                        break
                    # ping or other control frame — skip and keep waiting
            except Exception as recv_err:
                fail("reply_context_expired", f"recv exception: {type(recv_err).__name__}: {recv_err}")
                err = "exception"
            if err == "exception":
                pass  # already failed above
            elif err and err.get("code") == "reply_context_expired":
                ok("reply_context_expired error for stale channel_id")
            else:
                fail("reply_context_expired", f"got: {err}")

            # 6. Pong accepted
            await ws.send(json.dumps({"type": "pong"}))
            ok("pong sent without error")

    except Exception as e:
        fail("/connect WebSocket", f"{type(e).__name__}: {e}")

    # 7. /webchat WebSocket with bypass token
    try:
        async with websockets.connect(f"{BASE_WS}/webchat", additional_headers=H) as ws:
            frame = await recv(ws)
            if frame.get("type") == "connected" and frame.get("thread_id", "").startswith("wc_"):
                ok(f"/webchat WS connected thread_id={frame['thread_id']}")
            else:
                fail("/webchat WS", f"unexpected frame: {frame}")

            # 8. WebChat message -> offline notification (no WorkPilot client connected)
            await ws.send(json.dumps({"type": "message", "content": "hello from browser"}))
            notif = await recv(ws, timeout=6)
            if notif.get("type") == "error" and notif.get("code") == "agent_offline":
                ok("agent_offline notification when no client connected")
            else:
                fail("agent_offline", f"got: {notif}")

    except Exception as e:
        fail("/webchat WebSocket", str(e))

    # 9. Full relay: client connects, WebChat message delivered to client
    try:
        async with websockets.connect(f"{BASE_WS}/connect", additional_headers=H) as client_ws:
            await drain_connect(client_ws)  # drain connected + any buffered messages

            async with websockets.connect(f"{BASE_WS}/webchat", additional_headers=H) as browser_ws:
                await recv(browser_ws)  # drain connected frame

                await browser_ws.send(json.dumps({"type": "message", "content": "relay test"}))
                msg = await recv(client_ws, timeout=8)
                if msg.get("type") == "message" and "relay test" in msg.get("content", ""):
                    ok("full relay: WebChat message delivered to /connect client")
                else:
                    fail("full relay", f"got: {msg}")

                # 10. Client sends response back -> browser receives it
                cid = msg.get("channel_id", "")
                await client_ws.send(json.dumps({
                    "type": "response", "channel_id": cid,
                    "content": "AI reply", "format": "markdown"
                }))
                resp = await recv(browser_ws, timeout=8)
                if resp.get("type") == "response" and resp.get("content") == "AI reply":
                    ok("full relay: response routed back to browser")
                else:
                    fail("full relay response", f"got: {resp}")

    except Exception as e:
        fail("full relay loop", str(e))

    # 11. Teams endpoint (no auth)
    async with httpx.AsyncClient(timeout=10) as c:
        r = await c.post(f"{BASE}/bot/teams",
            content=b'{"type":"message"}',
            headers={"Content-Type": "application/json"})
        if r.status_code in (400, 401, 202):
            ok(f"/bot/teams no-auth -> {r.status_code}")
        else:
            fail("/bot/teams", f"got {r.status_code}")

    print()
    print(f"Results: {passed} passed, {failed} failed")
    sys.exit(1 if failed > 0 else 0)

asyncio.run(main())
