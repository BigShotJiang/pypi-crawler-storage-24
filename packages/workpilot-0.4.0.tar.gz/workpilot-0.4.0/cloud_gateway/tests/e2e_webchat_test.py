"""
Phase 7 e2e test: /webchat browser WebSocket ↔ /connect client relay.

Full round-trip:
  Browser (/webchat) -> server -> client (/connect) -> server -> browser

Run: python tests/e2e_webchat_test.py
"""
import asyncio
import json

import httpx
import websockets

BASE_WS   = "ws://localhost:5136"
TOKEN     = "dev-bypass"
HEADERS   = {"Authorization": f"Bearer {TOKEN}"}
BYPASS_OID = "00000000-0000-0000-0000-000000000001"

passed = failed = 0

def ok(label):
    global passed
    passed += 1
    print(f"  PASS  {label}")

def fail(label, reason=""):
    global failed
    failed += 1
    print(f"  FAIL  {label}" + (f": {reason}" if reason else ""))

def ws(path):
    return websockets.connect(f"{BASE_WS}{path}", additional_headers=HEADERS)

async def recv(socket, timeout=4):
    async with asyncio.timeout(timeout):
        return json.loads(await socket.recv())

async def drain_startup(socket):
    """Receive connected + optional buffered sequence, return first non-setup frame."""
    frame = await recv(socket)
    assert frame["type"] == "connected", f"expected connected, got {frame}"
    while True:
        try:
            f = await recv(socket, timeout=1)
            if f["type"] not in ("buffered_start", "message", "buffered_end"):
                return f
        except TimeoutError:
            return None


# ── Test 1: /webchat endpoint reachable + connected frame ────────────────────

async def test_webchat_basic():
    print("\n[1] /webchat basic connection")

    async with ws("/webchat") as browser:
        frame = await recv(browser)
        if frame.get("type") == "connected" and "thread_id" in frame:
            ok(f"1a connected frame with thread_id={frame['thread_id'][:20]}...")
        else:
            fail("1a connected frame", str(frame))
            return

        tid = frame["thread_id"]
        if tid.startswith("wc_") and len(tid) == 39:  # "wc_" + 36-char OID
            ok("1b thread_id format correct (wc_{full-oid})")
        else:
            fail("1b thread_id format", tid)

        if frame.get("buffered_count") == 0:
            ok("1c buffered_count=0 on fresh connect")
        else:
            fail("1c buffered_count", str(frame))


# ── Test 2: browser sends message -> WorkPilot client receives it ─────────────

async def test_webchat_to_client():
    print("\n[2] /webchat -> /connect message delivery")

    async with ws("/connect") as client, ws("/webchat") as browser:
        # drain startup for both
        client_startup = await recv(client)  # connected
        browser_startup = await recv(browser)  # connected
        ok(f"2a both sockets connected (client buffered={client_startup['buffered_count']}, "
           f"browser thread_id={browser_startup['thread_id'][:15]}...)")

        # browser sends a message
        await browser.send(json.dumps({"type": "message", "content": "Hello from browser"}))
        ok("2b browser sent message")

        # client should receive it as a message frame
        frame = await recv(client, timeout=5)
        if (frame.get("type") == "message"
                and frame.get("content") == "Hello from browser"
                and frame.get("metadata", {}).get("source") == "cloud_webchat"):
            ok("2c client received message (source=cloud_webchat)")
            ok(f"2d session_key={frame.get('session_key', '')[:40]}...")
            ok(f"2e channel_id format: {frame.get('channel_id', '')[:8]}...")
        else:
            fail("2c client did not receive message", str(frame))
            return

        channel_id = frame["channel_id"]

        # client sends response back
        await client.send(json.dumps({
            "type":       "response",
            "channel_id": channel_id,
            "content":    "Response from agent",
            "format":     "markdown",
        }))
        ok("2f client sent response")

        # browser should receive the response
        resp = await recv(browser, timeout=5)
        if resp.get("type") == "response" and resp.get("content") == "Response from agent":
            ok("2g browser received response from client")
        else:
            fail("2g browser response", str(resp))


# ── Test 3: streaming chunks browser <- client ────────────────────────────────

async def test_webchat_streaming():
    print("\n[3] /webchat streaming chunks (client -> browser)")

    async with ws("/connect") as client, ws("/webchat") as browser:
        await recv(client)   # connected
        await recv(browser)  # connected

        # browser sends message
        await browser.send(json.dumps({"type": "message", "content": "stream test"}))
        msg = await recv(client, timeout=5)  # client receives
        channel_id = msg["channel_id"]

        # client sends 3 chunks
        for _i, (content, done) in enumerate([("Hello ", False), ("world", False), ("", True)]):
            await client.send(json.dumps({
                "type":       "chunk",
                "channel_id": channel_id,
                "content":    content,
                "chunk_type": "token",
                "done":       done,
            }))

        chunks = []
        for _ in range(3):
            c = await recv(browser, timeout=5)
            chunks.append(c)

        if all(c.get("type") == "chunk" for c in chunks):
            ok(f"3a browser received {len(chunks)} chunk frames")
        else:
            fail("3a chunk frames", str(chunks))
            return

        contents = [c.get("content") for c in chunks]
        if contents == ["Hello ", "world", ""]:
            ok("3b chunk content correct")
        else:
            fail("3b chunk content", str(contents))

        done_flags = [c.get("done") for c in chunks]
        if done_flags == [False, False, True]:
            ok("3c done flags correct (False, False, True)")
        else:
            fail("3c done flags", str(done_flags))


# ── Test 4: no client connected -> agent_offline error to browser ─────────────

async def test_webchat_offline():
    print("\n[4] /webchat with no client connected -> offline message")

    async with ws("/webchat") as browser:
        await recv(browser)  # connected

        # no /connect client running
        await browser.send(json.dumps({"type": "message", "content": "anyone there?"}))

        # The message goes to offline buffer. Browser may get no immediate error
        # (client is offline, message buffered — browser is notified via delivery
        # but current IMessageDelivery doesn't send error to browser when client is offline).
        # Verify: no crash, server still healthy
        r = httpx.get("http://localhost:5136/health")
        if r.status_code == 200:
            ok("4a server healthy after offline send")
        else:
            fail("4a server health", str(r.status_code))


# ── Test 5: OID isolation webchat ────────────────────────────────────────────

async def test_webchat_oid_isolation():
    print("\n[5] /webchat OID isolation")

    await asyncio.sleep(0.5)
    async with ws("/connect") as client, ws("/webchat") as b1, ws("/webchat") as b2:
        await drain_startup(client)   # drain buffered from prior tests
        t1 = (await recv(b1))["thread_id"]
        t2 = (await recv(b2))["thread_id"]

        # Both browsers for the same OID get the same thread_id
        if t1 == t2:
            ok(f"5a both browsers get same thread_id: {t1[:20]}...")
        else:
            fail("5a thread_id mismatch", f"{t1} vs {t2}")

        # b1 sends a message
        await b1.send(json.dumps({"type": "message", "content": "from-b1"}))
        msg = await recv(client, timeout=5)
        cid = msg.get("channel_id", "")
        if not cid:
            fail("5b no channel_id in msg", str(msg))
            return

        # client responds
        await client.send(json.dumps({
            "type":       "response",
            "channel_id": cid,
            "content":    "reply to b1",
            "format":     "markdown",
        }))

        # response should go to b1 only (the one that sent the request)
        resp = await recv(b1, timeout=5)
        if resp.get("content") == "reply to b1":
            ok("5b response routed back to correct browser (b1)")
        else:
            fail("5b response routing", str(resp))

        # b2 should receive nothing within 1s
        try:
            unexpected = await recv(b2, timeout=1)
            fail("5c b2 should not receive", str(unexpected))
        except TimeoutError:
            ok("5c b2 did not receive unrelated response")


# ── Main ──────────────────────────────────────────────────────────────────────

async def main():
    print("=" * 60)
    print("Cloud Gateway Phase 7 — WebChat Channel E2E")
    print("=" * 60)

    await test_webchat_basic()
    await test_webchat_to_client()
    await test_webchat_streaming()
    await test_webchat_offline()
    await test_webchat_oid_isolation()

    print("\n" + "=" * 60)
    print(f"Results: {passed} passed, {failed} failed")
    print("ALL WEBCHAT TESTS PASSED" if failed == 0 else "SOME TESTS FAILED")
    print("=" * 60)

asyncio.run(main())
