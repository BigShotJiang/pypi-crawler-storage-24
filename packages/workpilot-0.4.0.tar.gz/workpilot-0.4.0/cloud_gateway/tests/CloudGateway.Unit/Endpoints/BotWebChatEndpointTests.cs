using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace CloudGateway.Unit.Endpoints;

/// <summary>
/// Unit / integration tests for BotWebChatEndpoint using WebApplicationFactory.
/// The factory runs in Development (bypass auth), so requests with the dev bypass token
/// are treated as authenticated under the "WebChatBrowserUser" policy.
/// </summary>
[Collection("Integration")]          // sequential — avoids Serilog global-state conflicts
public sealed class BotWebChatEndpointTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly WebApplicationFactory<Program> _factory;

    public BotWebChatEndpointTests(WebApplicationFactory<Program> factory)
    {
        _factory = factory;
    }

    // ── helpers ──────────────────────────────────────────────────────────────

    /// <summary>
    /// Stub HttpMessageHandler that returns a fixed status code and optional JSON body
    /// without making a real network call. Keeps tests fast and CI-reliable.
    /// </summary>
    private sealed class FakeDirectLineHandler(
        HttpStatusCode status,
        string? jsonBody = null) : HttpMessageHandler
    {
        protected override Task<HttpResponseMessage> SendAsync(
            HttpRequestMessage _, CancellationToken __)
        {
            var resp = new HttpResponseMessage(status);
            if (jsonBody is not null)
                resp.Content = new StringContent(jsonBody, Encoding.UTF8, "application/json");
            return Task.FromResult(resp);
        }
    }

    /// <summary>
    /// Factory customised with in-memory DirectLine config overrides and a fake
    /// DirectLine HttpClient handler to prevent real outbound calls.
    /// </summary>
    private WebApplicationFactory<Program> WithDirectLine(
        bool enabled,
        string secret = "",
        HttpStatusCode directLineApiStatus = HttpStatusCode.Unauthorized,
        string? directLineApiBody = null)
        => _factory.WithWebHostBuilder(b =>
        {
            b.ConfigureAppConfiguration((_, cfg) =>
                cfg.AddInMemoryCollection(new Dictionary<string, string?>
                {
                    ["DirectLine:Enabled"] = enabled ? "true" : "false",
                    ["DirectLine:Secret"]  = secret,
                }));

            b.ConfigureServices(services =>
                services.AddHttpClient("DirectLine")
                        .ConfigurePrimaryHttpMessageHandler(
                            () => new FakeDirectLineHandler(directLineApiStatus, directLineApiBody)));
        });

    /// <summary>HttpClient with dev-bypass Bearer token (authenticates as WebChatBrowserUser).</summary>
    private static HttpClient BypassClient(WebApplicationFactory<Program> factory)
    {
        var client = factory.CreateClient();
        client.DefaultRequestHeaders.Authorization =
            new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", "dev-bypass");
        return client;
    }

    // ── /webchat/directline/token ─────────────────────────────────────────────

    [Fact]
    public async Task GetToken_WhenDisabled_Returns404()
    {
        // Endpoint not registered when disabled — returns 404 (no stub).
        using var factory = WithDirectLine(enabled: false);
        using var client  = BypassClient(factory);

        var resp = await client.PostAsync("/webchat/directline/token", null);

        Assert.Equal(HttpStatusCode.NotFound, resp.StatusCode);
    }

    [Fact]
    public async Task GetToken_WhenEnabledButSecretEmpty_Returns503()
    {
        using var factory = WithDirectLine(enabled: true, secret: "");
        using var client  = BypassClient(factory);

        var resp = await client.PostAsync("/webchat/directline/token", null);

        Assert.Equal(HttpStatusCode.ServiceUnavailable, resp.StatusCode);
    }

    [Fact]
    public async Task GetToken_WhenDirectLineApiReturnsError_Returns503()
    {
        // Fake handler returns 401 — deterministic, no real network call.
        using var factory = WithDirectLine(
            enabled: true,
            secret: "test-secret",
            directLineApiStatus: HttpStatusCode.Unauthorized);
        using var client = BypassClient(factory);

        var resp = await client.PostAsync("/webchat/directline/token", null);

        Assert.Equal(HttpStatusCode.ServiceUnavailable, resp.StatusCode);
        using var body = JsonDocument.Parse(await resp.Content.ReadAsStringAsync());
        Assert.Equal("directline_unavailable", body.RootElement.GetProperty("error").GetString());
    }

    [Fact]
    public async Task GetToken_WhenDirectLineApiSucceeds_Returns200WithToken()
    {
        // Fake handler returns a valid DirectLine token response.
        const string fakeResponse = """
            {"token":"dl-fake-token","conversationId":"conv-test-123","expires_in":3600}
            """;
        using var factory = WithDirectLine(
            enabled: true,
            secret: "test-secret",
            directLineApiStatus: HttpStatusCode.OK,
            directLineApiBody: fakeResponse);
        using var client = BypassClient(factory);

        var resp = await client.PostAsync("/webchat/directline/token", null);

        Assert.Equal(HttpStatusCode.OK, resp.StatusCode);
        using var body = JsonDocument.Parse(await resp.Content.ReadAsStringAsync());
        Assert.Equal("dl-fake-token",     body.RootElement.GetProperty("token").GetString());
        Assert.Equal("conv-test-123",     body.RootElement.GetProperty("conversationId").GetString());
        Assert.Equal(3600,                body.RootElement.GetProperty("expiresIn").GetInt32());
    }

    [Fact]
    public async Task GetToken_WhenDirectLineApiSucceeds_RequestContainsDlUserId()
    {
        // Verify the outgoing DirectLine request has user.id = "dl_{oid}".
        // The bypass auth sets oid = 00000000-0000-0000-0000-000000000001.
        // Read body inside the handler before the HttpRequestMessage is disposed.
        string? capturedBody = null;
        var captureHandler = new CapturingHandler(HttpStatusCode.OK,
            """{"token":"t","conversationId":"c","expires_in":1800}""",
            async req => capturedBody = req.Content is not null
                ? await req.Content.ReadAsStringAsync()
                : string.Empty);

        using var factory = _factory.WithWebHostBuilder(b =>
        {
            b.ConfigureAppConfiguration((_, cfg) =>
                cfg.AddInMemoryCollection(new Dictionary<string, string?>
                {
                    ["DirectLine:Enabled"] = "true",
                    ["DirectLine:Secret"]  = "secret",
                }));
            b.ConfigureServices(s =>
                s.AddHttpClient("DirectLine")
                 .ConfigurePrimaryHttpMessageHandler(() => captureHandler));
        });
        using var client = BypassClient(factory);

        await client.PostAsync("/webchat/directline/token", null);

        Assert.NotNull(capturedBody);
        Assert.Contains("dl_00000000-0000-0000-0000-000000000001", capturedBody);
    }

    [Fact]
    public async Task GetToken_WithoutAuth_Returns401()
    {
        using var factory = WithDirectLine(enabled: true, secret: "some-secret");
        using var client  = factory.CreateClient(); // no bypass token

        var resp = await client.PostAsync("/webchat/directline/token", null);

        Assert.True(
            resp.StatusCode is HttpStatusCode.Unauthorized or HttpStatusCode.Redirect,
            $"Expected 401 or 302, got {(int)resp.StatusCode}");
    }

    // ── /webchat/ui ──────────────────────────────────────────────────────────

    [Fact]
    public async Task GetUi_WhenDisabled_Returns404()
    {
        using var factory = WithDirectLine(enabled: false);
        using var client  = BypassClient(factory);

        var resp = await client.GetAsync("/webchat/ui");

        Assert.Equal(HttpStatusCode.NotFound, resp.StatusCode);
    }

    [Fact]
    public async Task GetUi_WhenEnabled_ReturnsHtml()
    {
        using var factory = WithDirectLine(enabled: true, secret: "any-secret");
        using var client  = BypassClient(factory);

        var resp = await client.GetAsync("/webchat/ui");

        Assert.Equal(HttpStatusCode.OK, resp.StatusCode);
        Assert.Equal("text/html", resp.Content.Headers.ContentType?.MediaType);
        var html = await resp.Content.ReadAsStringAsync();
        Assert.Contains("webchat.js", html);
        Assert.Contains("/webchat/directline/token", html);
    }

    [Fact]
    public async Task GetUi_WithoutAuth_Returns200()
    {
        // /webchat/ui is AllowAnonymous — MSAL.js handles auth client-side.
        using var factory = WithDirectLine(enabled: true, secret: "any-secret");
        using var client  = factory.CreateClient();

        var resp = await client.GetAsync("/webchat/ui");

        Assert.Equal(HttpStatusCode.OK, resp.StatusCode);
        Assert.Equal("text/html", resp.Content.Headers.ContentType?.MediaType);
    }
}

// ── File-scoped helper ────────────────────────────────────────────────────────

/// <summary>HttpMessageHandler that captures the outgoing request for assertion.</summary>
file sealed class CapturingHandler(
    HttpStatusCode status,
    string jsonBody,
    Func<HttpRequestMessage, Task> capture) : HttpMessageHandler
{
    protected override async Task<HttpResponseMessage> SendAsync(
        HttpRequestMessage req, CancellationToken _)
    {
        await capture(req);
        return new HttpResponseMessage(status)
        {
            Content = new StringContent(jsonBody, Encoding.UTF8, "application/json"),
        };
    }
}
