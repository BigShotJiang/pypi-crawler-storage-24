using CloudGateway.Config;
using CloudGateway.Models;
using CloudGateway.Services;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;

namespace CloudGateway.Unit.Services;

public sealed class InMemoryOfflineBufferTests
{
    private static InMemoryOfflineBuffer MakeBuffer(int ttlMinutes = 60, int maxMessages = 10)
    {
        var opts = Options.Create(new RelayOptions
        {
            OfflineBufferTtlMinutes  = ttlMinutes,
            OfflineBufferMaxMessages = maxMessages,
        });
        return new InMemoryOfflineBuffer(opts, NullLogger<InMemoryOfflineBuffer>.Instance);
    }

    private static MessageFrame Msg(string content = "hello") => new()
    {
        ChannelId  = WireFrames.NewChannelId(),
        SenderId   = "oid-1",
        SenderName = "Test User",
        Content    = content,
        ThreadId   = "thread-1",
        SessionKey = "cloud_teams:oid-1:thread-1",
        Timestamp  = DateTimeOffset.UtcNow.ToString("O"),
        Metadata   = new MessageMetadata { Source = "cloud_teams" },
    };

    [Fact]
    public void Drain_Empty_ReturnsEmpty()
    {
        var buffer = MakeBuffer();
        Assert.Empty(buffer.Drain("unknown-oid"));
    }

    [Fact]
    public void Enqueue_ThenDrain_ReturnsInOrder()
    {
        var buffer = MakeBuffer();
        buffer.Enqueue("oid-1", Msg("a"));
        buffer.Enqueue("oid-1", Msg("b"));
        buffer.Enqueue("oid-1", Msg("c"));

        var drained = buffer.Drain("oid-1");

        Assert.Equal(3, drained.Count);
        Assert.Equal("a", drained[0].Content);
        Assert.Equal("b", drained[1].Content);
        Assert.Equal("c", drained[2].Content);
    }

    [Fact]
    public void Drain_ClearsBuffer()
    {
        var buffer = MakeBuffer();
        buffer.Enqueue("oid-1", Msg());

        buffer.Drain("oid-1");

        Assert.Empty(buffer.Drain("oid-1"));
    }

    [Fact]
    public void CapExceeded_DropsOldest()
    {
        var buffer = MakeBuffer(maxMessages: 2);
        buffer.Enqueue("oid-1", Msg("first"));
        buffer.Enqueue("oid-1", Msg("second"));
        buffer.Enqueue("oid-1", Msg("third"));

        var drained = buffer.Drain("oid-1");

        Assert.Equal(2, drained.Count);
        Assert.Equal("second", drained[0].Content);
        Assert.Equal("third",  drained[1].Content);
    }

    [Fact]
    public void ExpiredMessages_NotReturned()
    {
        var buffer = MakeBuffer(ttlMinutes: 0);  // TTL = 0 → expires immediately
        buffer.Enqueue("oid-1", Msg());

        var drained = buffer.Drain("oid-1");

        Assert.Empty(drained);
    }

    [Fact]
    public void MultipleOids_Isolated()
    {
        var buffer = MakeBuffer();
        buffer.Enqueue("oid-A", Msg("for-A"));
        buffer.Enqueue("oid-B", Msg("for-B"));

        var drainedA = buffer.Drain("oid-A");
        var drainedB = buffer.Drain("oid-B");

        Assert.Single(drainedA);
        Assert.Equal("for-A", drainedA[0].Content);
        Assert.Single(drainedB);
        Assert.Equal("for-B", drainedB[0].Content);
    }
}
