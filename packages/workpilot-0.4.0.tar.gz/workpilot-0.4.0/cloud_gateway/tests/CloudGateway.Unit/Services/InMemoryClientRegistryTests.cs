using System.Net.WebSockets;
using CloudGateway.Services;

namespace CloudGateway.Unit.Services;

public sealed class InMemoryClientRegistryTests
{
    private static ClientConnection MakeClient(string oid, string upn = "user@test.com")
        => new() { Oid = oid, Upn = upn, Socket = new ClientWebSocket() };

    [Fact]
    public void Register_MakesUserOnline()
    {
        var registry = new InMemoryClientRegistry();
        registry.Register(MakeClient("oid-1"));

        Assert.True(registry.IsOnline("oid-1"));
    }

    [Fact]
    public void Unregister_LastClient_MakesUserOffline()
    {
        var registry = new InMemoryClientRegistry();
        var client   = MakeClient("oid-1");
        registry.Register(client);

        registry.Unregister(client);

        Assert.False(registry.IsOnline("oid-1"));
    }

    [Fact]
    public void GetActive_ReturnsNull_WhenNoClients()
    {
        var registry = new InMemoryClientRegistry();

        Assert.Null(registry.GetActive("unknown-oid"));
    }

    [Fact]
    public void GetActive_ReturnsMostRecentlyActive()
    {
        var registry = new InMemoryClientRegistry();
        var c1 = MakeClient("oid-1");
        var c2 = MakeClient("oid-1");
        registry.Register(c1);
        registry.Register(c2);

        c2.LastActivity = DateTimeOffset.UtcNow.AddSeconds(10);

        Assert.Equal(c2, registry.GetActive("oid-1"));
    }

    [Fact]
    public void GetAll_ReturnsAllClientsForOid()
    {
        var registry = new InMemoryClientRegistry();
        registry.Register(MakeClient("oid-2"));
        registry.Register(MakeClient("oid-2"));
        registry.Register(MakeClient("oid-2"));

        Assert.Equal(3, registry.GetAll("oid-2").Count);
    }

    [Fact]
    public void Unregister_OneOf_Two_StillOnline()
    {
        var registry = new InMemoryClientRegistry();
        var c1 = MakeClient("oid-3");
        var c2 = MakeClient("oid-3");
        registry.Register(c1);
        registry.Register(c2);

        registry.Unregister(c1);

        Assert.True(registry.IsOnline("oid-3"));
        Assert.Single(registry.GetAll("oid-3"));
    }
}
