using System.Text.Json;
using CloudGateway.Models;

namespace CloudGateway.Unit.Models;

public sealed class WireFrameSerializationTests
{
    // ── MessageFrame ─────────────────────────────────────────────────────────

    [Fact]
    public void MessageFrame_RoundTrip_AllFieldsPreserved()
    {
        var original = new MessageFrame
        {
            ChannelId  = WireFrames.NewChannelId(),
            SenderId   = "a7f3d9b2-4c1d-8f7a-b2e4-c1d8f7ab2e4c",
            SenderName = "John Smith",
            Content    = "Hello <at>WorkPilot</at> fix the bug",
            ThreadId   = "19:abc123@thread.v2",
            SessionKey = "cloud_teams:a7f3d9b2-4c1d-8f7a-b2e4-c1d8f7ab2e4c:19:abc123@thread.v2",
            Timestamp  = "2026-03-02T12:00:00Z",
            Metadata   = new MessageMetadata { Source = "cloud_teams", TenantId = "72f988bf-86f1-41af-91ab-2d7cd011db47" },
        };

        var json   = WireFrames.Serialize(original);
        var result = WireFrames.Deserialize<MessageFrame>(json);

        Assert.NotNull(result);
        Assert.Equal(FrameType.Message, result.Type);
        Assert.Equal(original.ChannelId,  result.ChannelId);
        Assert.Equal(original.SenderId,   result.SenderId);
        Assert.Equal(original.SenderName, result.SenderName);
        Assert.Equal(original.Content,    result.Content);
        Assert.Equal(original.ThreadId,   result.ThreadId);
        Assert.Equal(original.SessionKey, result.SessionKey);
        Assert.Equal(original.Timestamp,  result.Timestamp);
        Assert.Equal("cloud_teams",       result.Metadata.Source);
        Assert.Equal("72f988bf-86f1-41af-91ab-2d7cd011db47", result.Metadata.TenantId);
    }

    [Fact]
    public void MessageFrame_UsesSnakeCaseKeys()
    {
        var frame = new MessageFrame
        {
            ChannelId  = "cid_test",
            SenderId   = "oid-1",
            SenderName = "Test",
            Content    = "hi",
            ThreadId   = "thread-1",
            SessionKey = "cloud_teams:oid-1:thread-1",
            Timestamp  = "2026-01-01T00:00:00Z",
            Metadata   = new MessageMetadata { Source = "cloud_teams" },
        };

        var json = WireFrames.Serialize(frame);

        // snake_case keys must be present
        Assert.Contains("\"channel_id\"", json);
        Assert.Contains("\"sender_id\"", json);
        Assert.Contains("\"sender_name\"", json);
        Assert.Contains("\"session_key\"", json);
        // null TenantId must be omitted (WhenWritingNull)
        Assert.DoesNotContain("\"tenant_id\"", json);
    }

    // ── ResponseFrame ────────────────────────────────────────────────────────

    [Fact]
    public void ResponseFrame_RoundTrip()
    {
        var channelId = WireFrames.NewChannelId();
        var original  = new ResponseFrame
        {
            ChannelId = channelId,
            Content   = "Fixed the bug.",
            ThreadId  = "19:abc@thread.v2",
            Format    = "markdown",
        };

        var json   = WireFrames.Serialize(original);
        var result = WireFrames.Deserialize<ResponseFrame>(json);

        Assert.NotNull(result);
        Assert.Equal(FrameType.Response, result.Type);
        Assert.Equal(channelId,          result.ChannelId);
        Assert.Equal("Fixed the bug.",   result.Content);
        Assert.Equal("markdown",         result.Format);
    }

    // ── ChunkFrame ───────────────────────────────────────────────────────────

    [Fact]
    public void ChunkFrame_DoneFalse_RoundTrip()
    {
        var frame = new ChunkFrame
        {
            ChannelId      = "cid_f47ac10b-58cc-4372-a567-0e02b2c3d479",
            Content        = "Fixed",
            ChunkTypeValue = ChunkType.Token,
            Done           = false,
        };

        var json   = WireFrames.Serialize(frame);
        var result = WireFrames.Deserialize<ChunkFrame>(json);

        Assert.NotNull(result);
        Assert.Equal(FrameType.Chunk,  result.Type);
        Assert.Equal("Fixed",          result.Content);
        Assert.Equal(ChunkType.Token,  result.ChunkTypeValue);
        Assert.False(result.Done);
    }

    [Fact]
    public void ChunkFrame_DoneTrue_EmptyContent()
    {
        var frame = new ChunkFrame
        {
            ChannelId      = "cid_f47ac10b-58cc-4372-a567-0e02b2c3d479",
            Content        = string.Empty,
            ChunkTypeValue = ChunkType.Token,
            Done           = true,
        };

        var json   = WireFrames.Serialize(frame);
        var result = WireFrames.Deserialize<ChunkFrame>(json);

        Assert.NotNull(result);
        Assert.True(result.Done);
        Assert.Equal(string.Empty, result.Content);
    }

    // ── ErrorFrame ───────────────────────────────────────────────────────────

    [Fact]
    public void ErrorFrame_WithChannelId_RoundTrip()
    {
        var frame = new ErrorFrame
        {
            Code      = ErrorCode.ReplyContextExpired,
            ChannelId = "cid_f47ac10b-58cc-4372-a567-0e02b2c3d479",
            Message   = "The reply window has expired.",
        };

        var json   = WireFrames.Serialize(frame);
        var result = WireFrames.Deserialize<ErrorFrame>(json);

        Assert.NotNull(result);
        Assert.Equal(FrameType.Error,                 result.Type);
        Assert.Equal(ErrorCode.ReplyContextExpired,   result.Code);
        Assert.Equal("cid_f47ac10b-58cc-4372-a567-0e02b2c3d479", result.ChannelId);
    }

    [Fact]
    public void ErrorFrame_WithoutChannelId_FieldOmitted()
    {
        var frame = new ErrorFrame
        {
            Code    = ErrorCode.AuthExpired,
            Message = "Token has expired.",
        };

        var json   = WireFrames.Serialize(frame);
        var result = WireFrames.Deserialize<ErrorFrame>(json);

        Assert.NotNull(result);
        Assert.Equal(ErrorCode.AuthExpired, result.Code);
        Assert.Null(result.ChannelId);
        Assert.DoesNotContain("\"channel_id\"", json);
    }

    // ── channel_id format ────────────────────────────────────────────────────

    [Fact]
    public void ChannelId_HasCidPrefix_AndFullUuid()
    {
        var id = WireFrames.NewChannelId();

        Assert.StartsWith("cid_", id);

        // remainder must be a parseable GUID
        var guidPart = id["cid_".Length..];
        Assert.True(Guid.TryParse(guidPart, out _), $"Expected full UUID after cid_ prefix, got: {guidPart}");
    }

    // ── session_key format ───────────────────────────────────────────────────

    [Fact]
    public void SessionKey_Teams_Format()
    {
        const string oid            = "a7f3d9b2-4c1d-8f7a-b2e4-c1d8f7ab2e4c";
        const string conversationId = "19:abc123@thread.v2";

        var key = WireFrames.TeamsSessionKey(oid, conversationId);

        Assert.Equal($"cloud_teams:{oid}:{conversationId}", key);
        Assert.StartsWith("cloud_teams:", key);
    }

    [Fact]
    public void SessionKey_WebChat_Format()
    {
        const string upn = "john@contoso.com";
        const string oid = "a7f3d9b2-4c1d-8f7a-b2e4-c1d8f7ab2e4c";

        var key = WireFrames.WebChatSessionKey(upn, oid);

        Assert.Equal($"cloud_webchat:{upn}:wc_{oid}", key);
        Assert.StartsWith("cloud_webchat:", key);
    }

    [Fact]
    public void ThreadId_WebChat_IsFullOidWithPrefix()
    {
        const string oid = "a7f3d9b2-4c1d-8f7a-b2e4-c1d8f7ab2e4c";

        var threadId = WireFrames.WebChatThreadId(oid);

        Assert.Equal($"wc_{oid}", threadId);
        // Full OID with dashes is preserved
        Assert.Contains("-", threadId);
        Assert.Equal(39, threadId.Length); // "wc_" (3) + GUID (36)
    }
}
