using System.Security.Claims;
using CloudGateway.Config;
using CloudGateway.Middleware;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;

namespace CloudGateway.Unit.Middleware;

public sealed class RateLimitMiddlewareTests
{
    private static RateLimitMiddleware MakeMiddleware(
        RequestDelegate next,
        int requestsPerMinute = 3)
    {
        var opts = Options.Create(new RateLimitOptions { HttpRequestsPerMinute = requestsPerMinute });
        return new RateLimitMiddleware(next, opts);
    }

    private static HttpContext MakeContext(
        string path = "/api/test",
        string? oid = "oid-test-user")
    {
        var context = new DefaultHttpContext();
        context.Request.Path = path;

        if (oid is not null)
        {
            context.User = new ClaimsPrincipal(
                new ClaimsIdentity([new Claim("oid", oid)], "test"));
        }

        // Provide a writable response body for 429 JSON serialization
        context.Response.Body = new MemoryStream();
        return context;
    }

    [Fact]
    public async Task BelowLimit_AllRequestsAllowed()
    {
        var callCount  = 0;
        RequestDelegate next = _ => { callCount++; return Task.CompletedTask; };
        var middleware = MakeMiddleware(next, requestsPerMinute: 5);

        for (var i = 0; i < 5; i++)
            await middleware.InvokeAsync(MakeContext());

        Assert.Equal(5, callCount);
    }

    [Fact]
    public async Task AtLimit_NextRequestBlocked()
    {
        var callCount  = 0;
        RequestDelegate next = _ => { callCount++; return Task.CompletedTask; };
        var middleware = MakeMiddleware(next, requestsPerMinute: 3);

        // consume all 3 tokens
        for (var i = 0; i < 3; i++)
            await middleware.InvokeAsync(MakeContext());

        // 4th request must be blocked
        var ctx = MakeContext();
        await middleware.InvokeAsync(ctx);

        Assert.Equal(3, callCount);
        Assert.Equal(StatusCodes.Status429TooManyRequests, ctx.Response.StatusCode);
        Assert.Equal("60", ctx.Response.Headers["Retry-After"].ToString());
    }

    [Fact]
    public async Task DifferentOids_Independent()
    {
        var callCount  = 0;
        RequestDelegate next = _ => { callCount++; return Task.CompletedTask; };
        var middleware = MakeMiddleware(next, requestsPerMinute: 1);

        // exhaust oid-A
        await middleware.InvokeAsync(MakeContext(oid: "oid-A"));

        // oid-B should still be allowed
        var ctxB = MakeContext(oid: "oid-B");
        await middleware.InvokeAsync(ctxB);

        Assert.Equal(2, callCount);
        Assert.Equal(StatusCodes.Status200OK, ctxB.Response.StatusCode);
    }

    [Fact]
    public async Task HealthPath_Bypassed()
    {
        var called     = false;
        RequestDelegate next = _ => { called = true; return Task.CompletedTask; };
        var middleware = MakeMiddleware(next, requestsPerMinute: 0); // limit = 0 → always block

        await middleware.InvokeAsync(MakeContext(path: "/health"));

        Assert.True(called);
    }

    [Fact]
    public async Task HealthReadyPath_Bypassed()
    {
        var called     = false;
        RequestDelegate next = _ => { called = true; return Task.CompletedTask; };
        var middleware = MakeMiddleware(next, requestsPerMinute: 0);

        await middleware.InvokeAsync(MakeContext(path: "/health/ready"));

        Assert.True(called);
    }

    [Fact]
    public async Task Unauthenticated_NotRateLimited()
    {
        var called     = false;
        RequestDelegate next = _ => { called = true; return Task.CompletedTask; };
        var middleware = MakeMiddleware(next, requestsPerMinute: 0); // limit = 0 → would block auth'd users

        // no OID → no rate limiting
        await middleware.InvokeAsync(MakeContext(oid: null));

        Assert.True(called);
    }
}
