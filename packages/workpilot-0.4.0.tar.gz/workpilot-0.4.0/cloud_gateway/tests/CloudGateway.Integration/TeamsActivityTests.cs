using System.Net;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using CloudGateway.Services;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;

namespace CloudGateway.Integration;

// Sequential collection prevents Serilog global-state conflicts between test classes.
[Collection("Integration")]
/// <summary>
/// Integration tests for POST /bot/teams (Phase 8 — M365 Agents SDK).
///
/// TokenValidation:Enabled=false is configured in appsettings.Development.json,
/// so the WebApplicationFactory (which runs in Development) skips Bot Framework
/// JWT validation — allowing test activities to be processed without real tokens.
/// </summary>
public sealed class TeamsActivityTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly WebApplicationFactory<Program> _factory;
    private readonly HttpClient _client;

    // Test OID that matches the bypass auth identity
    private const string TestOid = "00000000-0000-0000-0000-000000000001";

    public TeamsActivityTests(WebApplicationFactory<Program> factory)
    {
        _factory = factory;
        _client  = factory.CreateClient();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private static StringContent MakeActivity(
        string text          = "Hello WorkPilot",
        string? aadObjectId  = TestOid,
        string? conversationId = "19:test-conv@thread.v2",
        string activityType  = "message")
    {
        var from = new Dictionary<string, string?>
        {
            ["id"]   = $"29:{aadObjectId ?? "anon"}",
            ["name"] = "Test User",
        };
        if (aadObjectId is not null) from["aadObjectId"] = aadObjectId;

        var activity = new
        {
            type         = activityType,
            id           = $"act_{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}",
            text,
            from,
            conversation = new { id = conversationId, isGroup = true },
            recipient    = new { id = "28:bot-id", name = "WorkPilot" },
            serviceUrl   = "https://smba.trafficmanager.net/amer/",
            channelId    = "msteams",
            channelData  = new { tenant = new { id = "72f988bf-86f1-41af-91ab-2d7cd011db47" } },
        };

        return new StringContent(
            JsonSerializer.Serialize(activity),
            Encoding.UTF8,
            "application/json");
    }

    // ── 1. No auth header → 401 ───────────────────────────────────────────────

    [Fact]
    public async Task PostBotTeams_NoAuth_Returns401()
    {
        // TokenValidation:Enabled=false only disables validation when a token IS present.
        // With no Authorization header at all, ANCM middleware returns 401 before routing.
        // In test mode the behaviour depends on whether agent auth middleware blocks it.
        var response = await _client.PostAsync("/bot/teams", MakeActivity());

        // Either 401 (auth required) or 202 (token validation disabled, anonymous allowed)
        // The M365 Agents SDK with Enabled=false accepts unauthenticated requests.
        Assert.True(
            response.StatusCode is HttpStatusCode.Unauthorized
                                 or HttpStatusCode.Accepted,
            $"Expected 401 or 202, got {(int)response.StatusCode}");
    }

    // ── 2. Invalid JWT → server handles gracefully ───────────────────────────

    [Fact]
    public async Task PostBotTeams_InvalidJwt_HandledGracefully()
    {
        // With TokenValidation:Enabled=false, a malformed JWT causes the SDK to
        // attempt parsing, which throws a Base64 decode exception → 500 (dev exception page).
        // With Enabled=true an invalid JWT returns 401.
        // In both cases the server must not crash permanently.
        using var client = _factory.CreateClient();
        client.DefaultRequestHeaders.Authorization =
            new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", "invalid.jwt.token");

        var response = await client.PostAsync("/bot/teams", MakeActivity());

        // 401 (validation active), 202 (validation disabled + accepted), or 500 (parse error)
        Assert.True(
            response.StatusCode is HttpStatusCode.Unauthorized
                                 or HttpStatusCode.Accepted
                                 or HttpStatusCode.InternalServerError,
            $"Expected 401, 202, or 500, got {(int)response.StatusCode}");

        // Critical: server must remain alive after the error
        var health = await _factory.CreateClient().GetAsync("/health");
        Assert.Equal(HttpStatusCode.OK, health.StatusCode);
    }

    // ── 3. Valid activity → 202 Accepted ─────────────────────────────────────

    [Fact]
    public async Task PostBotTeams_ValidActivity_Returns202()
    {
        var response = await _client.PostAsync("/bot/teams", MakeActivity("Fix the auth bug"));

        Assert.Equal(HttpStatusCode.Accepted, response.StatusCode);
    }

    // ── 4. Missing aadObjectId → 202 but discarded ───────────────────────────

    [Fact]
    public async Task PostBotTeams_MissingAadObjectId_Returns202AndDiscards()
    {
        // Activity without from.aadObjectId cannot be routed — silently discarded.
        var response = await _client.PostAsync(
            "/bot/teams",
            MakeActivity(aadObjectId: null));

        // Server still returns 202 (fire-and-forget; discard happens async)
        Assert.Equal(HttpStatusCode.Accepted, response.StatusCode);

        // Server must remain healthy after discarding
        var health = await _client.GetAsync("/health");
        Assert.Equal(HttpStatusCode.OK, health.StatusCode);
    }

    // ── 5. Activity routed to connected client ────────────────────────────────

    [Fact]
    public async Task PostBotTeams_ClientOffline_MessageBuffered()
    {
        // No /connect client is running, so the message goes to OfflineBuffer.
        // We verify via the IOfflineBuffer service that the message was buffered.
        using var scope = _factory.Services.CreateScope();
        var buffer = scope.ServiceProvider.GetRequiredService<IOfflineBuffer>();

        // Drain any pre-existing buffer entries for this OID
        buffer.Drain(TestOid);

        var response = await _client.PostAsync("/bot/teams", MakeActivity("buffered-test"));
        Assert.Equal(HttpStatusCode.Accepted, response.StatusCode);

        // Give the fire-and-forget task time to complete
        await Task.Delay(300);

        // Message should be in the offline buffer
        var buffered = buffer.Drain(TestOid);
        Assert.NotEmpty(buffered);
        Assert.Contains(buffered, m => m.Content.Contains("buffered-test"));
    }

    // ── 6. Non-message activity type → 202, not processed ───────────────────

    [Fact]
    public async Task PostBotTeams_NonMessageActivity_Returns202()
    {
        // Typing indicators, reactions etc. should be accepted but not routed.
        var response = await _client.PostAsync(
            "/bot/teams",
            MakeActivity(activityType: "typing"));

        // 202 accepted (SDK handles all activity types gracefully)
        Assert.Equal(HttpStatusCode.Accepted, response.StatusCode);
    }
}
