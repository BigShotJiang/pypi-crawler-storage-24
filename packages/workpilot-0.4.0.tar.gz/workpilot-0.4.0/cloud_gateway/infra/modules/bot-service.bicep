// Azure Bot Service + Teams Channel + Web Chat Channel
// App type: UserAssignedMSI — no client secret.
// The UAMI is used as the bot's identity for both inbound JWT validation
// and outbound Bot Connector calls.

param botName    string
param location   string = 'global'   // Bot Service is always global
param tags       object = {}

@description('Display name shown to Teams users')
param displayName string

@description('UAMI client ID — used as msaAppId')
param uamiClientId string

@description('UAMI resource ID — linked to the bot registration')
param uamiResourceId string

@description('Entra tenant ID')
param tenantId string

@description('Full HTTPS URL to the bot messaging endpoint: https://{host}/bot/teams')
param endpoint string

resource botService 'Microsoft.BotService/botServices@2022-09-15' = {
  name:     botName
  location: location
  tags:     tags
  sku:      { name: 'F0' }
  kind:     'azurebot'
  properties: {
    displayName:           displayName
    msaAppType:            'UserAssignedMSI'
    msaAppId:              uamiClientId
    msaAppMSIResourceId:   uamiResourceId
    msaAppTenantId:        tenantId
    endpoint:              endpoint
    isStreamingSupported:  false
  }
}

resource teamsChannel 'Microsoft.BotService/botServices/channels@2022-09-15' = {
  parent:   botService
  name:     'MsTeamsChannel'
  location: location
  properties: {
    channelName: 'MsTeamsChannel'
    properties: {
      enableCalling: false
      isEnabled:     true
    }
  }
}

// ── Web Chat Channel ─────────────────────────────────────────────────────────
// Enables the DirectLine v3.0 endpoint used by /webchat/directline/token.
// The Default Site secret is obtained from the Azure Portal after provisioning.
resource webChatChannel 'Microsoft.BotService/botServices/channels@2022-09-15' = {
  parent:   botService
  name:     'WebChatChannel'
  location: location
  properties: {
    channelName: 'WebChatChannel'
    properties: {
      sites: [
        {
          siteName:    'Default Site'
          isEnabled:   true
          isV1Enabled: false
          isV3Enabled: true
        }
      ]
    }
  }
}

output botServiceId       string = botService.id
output botServiceName     string = botService.name
output webChatChannelName string = webChatChannel.name
