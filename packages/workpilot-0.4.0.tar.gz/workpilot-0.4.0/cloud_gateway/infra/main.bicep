// Cloud Gateway — Azure Infrastructure
// Deploys: UAMI, App Service, App Insights, Key Vault, Azure Bot Service
//
// Pre-requisite: run infra/scripts/setup-entra.sh (creates Entra App Registrations
// and sets ENTRA_GATEWAY_CLIENT_ID in the azd environment).
//
// Usage:
//   azd up                              (preprovision hook → provision → deploy)
//   azd provision                       (infra only)
//   az deployment group create \
//     -g <rg> --template-file main.bicep \
//     --parameters parameters/prod.bicepparam

@description('Base name for all resources (e.g. "workpilot-gw-prod")')
param baseName string = 'workpilot-gw'

param location string = resourceGroup().location

@description('App Service Plan SKU')
@allowed(['D1', 'B1', 'B2', 'B3', 'P1v3', 'P2v3', 'P3v3'])
param appServiceSku string = 'B2'

@description('Entra ID tenant ID')
param tenantId string = '72f988bf-86f1-41af-91ab-2d7cd011db47'

@description('Entra App Registration client ID for /connect JWT validation. Set via ENTRA_GATEWAY_CLIENT_ID env var.')
param entraClientId string

@description('Application Insights connection string (empty = use auto-provisioned instance)')
param appInsightsConnectionString string = ''

@description('DirectLine channel secret for /webchat/directline/token. Empty = feature disabled. Store in Key Vault for production.')
@secure()
param directLineSecret string = ''

@description('Trusted origin for DirectLine tokens. Defaults to the provisioned App Service hostname when empty.')
param directLineTrustedOrigin string = ''

@description('Environment tag')
@allowed(['dev', 'staging', 'prod'])
param environment string = 'prod'

var tags = {
  application: 'workpilot-cloud-gateway'
  environment: environment
}

// ── User-Assigned Managed Identity ──────────────────────────────────────────
module uami 'modules/uami.bicep' = {
  name: 'uami'
  params: {
    name:     '${baseName}-identity'
    location: location
    tags:     tags
  }
}

// ── Application Insights (optional) ─────────────────────────────────────────
module appInsights 'modules/app-insights.bicep' = {
  name: 'appInsights'
  params: {
    name:     '${baseName}-insights'
    location: location
    tags:     tags
  }
}

// ── App Service ──────────────────────────────────────────────────────────────
module appService 'modules/app-service.bicep' = {
  name: 'appService'
  params: {
    appName:                    baseName
    sku:                        appServiceSku
    location:                   location
    tags:                       tags
    uamiClientId:               uami.outputs.clientId
    uamiResourceId:             uami.outputs.id
    tenantId:                   tenantId
    entraClientId:              entraClientId
    appInsightsConnectionString: appInsightsConnectionString == ''
      ? appInsights.outputs.connectionString
      : appInsightsConnectionString
    directLineSecret:           directLineSecret
    // Default TrustedOrigin to the App Service hostname derived from baseName.
    // The hostname follows <baseName>.azurewebsites.net by Azure convention.
    directLineTrustedOrigin:    directLineTrustedOrigin != ''
      ? directLineTrustedOrigin
      : 'https://${baseName}.azurewebsites.net'
  }
}

// ── Key Vault (no secrets in v1; structure for future use) ───────────────────
module keyVault 'modules/key-vault.bicep' = {
  name: 'keyVault'
  params: {
    name:                   '${baseName}-kv'
    location:               location
    tags:                   tags
    appServicePrincipalId:  appService.outputs.principalId
  }
}

// ── Azure Bot Service + Teams Channel ────────────────────────────────────────
// Depends on App Service hostname (known after appService module completes).
module botService 'modules/bot-service.bicep' = {
  name: 'botService'
  params: {
    botName:         '${baseName}-bot'
    displayName:     'WorkPilot (${environment})'
    uamiClientId:    uami.outputs.clientId
    uamiResourceId:  uami.outputs.id
    tenantId:        tenantId
    endpoint:        'https://${appService.outputs.defaultHostName}/bot/teams'
    tags:            tags
  }
}

// ── Outputs ──────────────────────────────────────────────────────────────────
output gatewayUrl          string = 'https://${appService.outputs.defaultHostName}'
output appServiceName      string = appService.outputs.name
output uamiClientId        string = uami.outputs.clientId
output uamiPrincipalId     string = uami.outputs.principalId
output appInsightsConnStr  string = appInsights.outputs.connectionString
output keyVaultUri         string = keyVault.outputs.vaultUri
output botServiceName      string = botService.outputs.botServiceName
