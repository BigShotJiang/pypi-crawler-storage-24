using '../main.bicep'

param baseName       = 'workpilot-gw-dev'
param appServiceSku  = 'D1'
param tenantId       = '72f988bf-86f1-41af-91ab-2d7cd011db47'
param environment    = 'dev'

// Injected by infra/scripts/setup-entra.sh → azd env set ENTRA_GATEWAY_CLIENT_ID
param entraClientId  = readEnvironmentVariable('ENTRA_GATEWAY_CLIENT_ID', '')

// appInsightsConnectionString: leave empty to auto-use the provisioned AI instance

// DirectLine secret: set DIRECTLINE_SECRET in your azd environment to enable Web Chat.
// Get the secret from Azure Portal → Bot Service → Channels → Web Chat → Default Site.
param directLineSecret = readEnvironmentVariable('DIRECTLINE_SECRET', '')
