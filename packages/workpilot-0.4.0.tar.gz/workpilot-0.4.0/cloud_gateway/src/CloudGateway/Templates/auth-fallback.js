document.getElementById('btn').onclick = () => { window.location.href = '/auth/login'; };
document.getElementById('btn').disabled = false;
document.getElementById('status').textContent = '';
