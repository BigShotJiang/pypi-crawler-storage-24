<#
.SYNOPSIS
    WorkPilot one-click installer for Windows.

.DESCRIPTION
    Automatically installs Python 3.11+ if needed (via winget or python.org),
    ensures pip, installs WorkPilot from PyPI, and adds the CLI to your PATH.

    Run from PowerShell:
        irm https://workpilot-gw-dev.azurewebsites.net/install.ps1 | iex

    Or download and run locally:
        .\install.ps1

.NOTES
    - Compatible with PowerShell 5.1+ and Windows 10/11.
    - Does not require administrator privileges.
    - Idempotent: safe to re-run to upgrade an existing installation.
#>

$ErrorActionPreference = "Continue"
$MinMajor  = 3
$MinMinor  = 11
$PyVersion = "3.13"
$PyArch    = if ($env:PROCESSOR_ARCHITECTURE -eq "ARM64") { "arm64" } else { "amd64" }
$PyUrl     = "https://www.python.org/ftp/python/$PyVersion.0/python-$PyVersion.0-$PyArch.exe"
$Package   = if ($env:WORKPILOT_PACKAGE) { $env:WORKPILOT_PACKAGE } else { "workpilot" }

function Write-Step { param([string]$m) Write-Host "" ; Write-Host ">> $m" -ForegroundColor Cyan }
function Write-Ok   { param([string]$m) Write-Host "   OK: $m" -ForegroundColor Green }
function Write-Warn { param([string]$m) Write-Host "   WARNING: $m" -ForegroundColor Yellow }
function Write-Fail { param([string]$m) Write-Host "   FAILED: $m" -ForegroundColor Red }

function Get-EnvPath {
    $m = [System.Environment]::GetEnvironmentVariable("Path", "Machine")
    $u = [System.Environment]::GetEnvironmentVariable("Path", "User")
    if (-not $m) { $m = "" }
    if (-not $u) { $u = "" }
    return (@($m, $u) | Where-Object { $_ }) -join ";"
}

function Refresh-Path {
    $env:Path = Get-EnvPath
}

function Add-ToUserPath {
    param([string]$Dir)
    if (-not $Dir -or -not (Test-Path $Dir)) { return }
    $current = [System.Environment]::GetEnvironmentVariable("Path", "User")
    if (-not $current) { $current = "" }
    $parts = $current -split ";"
    if ($parts -contains $Dir) { return }
    $newPath = ($parts + $Dir | Where-Object { $_ }) -join ";"
    [System.Environment]::SetEnvironmentVariable("Path", $newPath, "User")
    if ($env:Path -notlike "*$Dir*") { $env:Path = "$env:Path;$Dir" }
    Write-Ok "Added to PATH: $Dir"
}

function Test-IsStoreStub {
    param([string]$Cmd)
    try {
        $out = & $Cmd --version 2>&1
        return ($LASTEXITCODE -eq 9009 -or [string]$out -notmatch "Python")
    } catch { return $true }
}

function Find-Python {
    $candidates = @("python3", "python", "py")
    foreach ($c in $candidates) {
        if (-not (Get-Command $c -ErrorAction SilentlyContinue)) { continue }
        if (Test-IsStoreStub $c) { continue }
        try {
            $ver = & $c --version 2>&1
            if ([string]$ver -match "Python (\d+)\.(\d+)") {
                $maj = [int]$Matches[1]
                $min = [int]$Matches[2]
                if ($maj -gt $MinMajor -or ($maj -eq $MinMajor -and $min -ge $MinMinor)) {
                    return @{ Cmd = $c; Prefix = @() }
                }
            }
        } catch {}
    }
    # py launcher with version flag
    if (Get-Command py -ErrorAction SilentlyContinue) {
        $flag = "-$($MinMajor).$($MinMinor)"
        try {
            $ver = & py $flag --version 2>&1
            if ($LASTEXITCODE -eq 0 -and [string]$ver -match "Python") {
                return @{ Cmd = "py"; Prefix = @($flag) }
            }
        } catch {}
    }
    return $null
}

# --- Step 1: Locate or install Python ---
Write-Step "Checking for Python $($MinMajor).$($MinMinor)+ ..."

$pyInfo = Find-Python

if (-not $pyInfo) {
    Write-Warn "Python $($MinMajor).$($MinMinor)+ not found. Attempting automatic install..."

    # 1a. Try winget (Windows 10 1709+ / Windows 11)
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        Write-Step "Installing Python $PyVersion via winget ..."
        winget install --id "Python.Python.$PyVersion" `
            --accept-source-agreements `
            --accept-package-agreements `
            --scope user `
            --silent 2>&1 | ForEach-Object { Write-Host "   $_" -ForegroundColor DarkGray }
        Refresh-Path
        $pyInfo = Find-Python
        if ($pyInfo) { Write-Ok "Python installed via winget." }
    }

    # 1b. Fallback: download installer from python.org
    if (-not $pyInfo) {
        Write-Step "Downloading Python $PyVersion from python.org ..."
        $installer = Join-Path $env:TEMP "python-installer.exe"
        try {
            [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
            Invoke-WebRequest -Uri $PyUrl -OutFile $installer -UseBasicParsing -ErrorAction Stop
            Write-Step "Running Python installer silently (user scope, no admin needed) ..."
            $startArgs = @{
                FilePath     = $installer
                ArgumentList = "/quiet", "InstallAllUsers=0", "PrependPath=1", "Include_launcher=1"
                Wait         = $true
                PassThru     = $true
            }
            $null = Start-Process @startArgs
            Remove-Item $installer -ErrorAction SilentlyContinue
            Refresh-Path
            $pyInfo = Find-Python
            if ($pyInfo) { Write-Ok "Python installed from python.org." }
        } catch {
            Write-Warn "Direct download failed: $($_.Exception.Message)"
        }
    }

    if (-not $pyInfo) {
        Write-Fail "Could not automatically install Python."
        Write-Host ""
        Write-Host "  Please install Python $($MinMajor).$($MinMinor)+ manually:" -ForegroundColor Yellow
        Write-Host "    https://www.python.org/downloads/" -ForegroundColor Yellow
        Write-Host "  Check 'Add Python to PATH' during installation, then re-run this script." -ForegroundColor Yellow
        Write-Host ""
        exit 1
    }
}

$pyCmd    = $pyInfo.Cmd
$pyPrefix = $pyInfo.Prefix
$verOut   = & $pyCmd @pyPrefix --version 2>&1
Write-Ok "Found $verOut"

# --- Step 2: Ensure pip ---
Write-Step "Ensuring pip is available ..."

$pipCheck = & $pyCmd @pyPrefix -m pip --version 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Warn "pip not found. Bootstrapping via ensurepip ..."
    & $pyCmd @pyPrefix -m ensurepip --upgrade 2>&1 | Out-Null

    $pipCheck = & $pyCmd @pyPrefix -m pip --version 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Warn "ensurepip failed. Downloading get-pip.py ..."
        $getPip = Join-Path $env:TEMP "get-pip.py"
        Invoke-WebRequest -Uri "https://bootstrap.pypa.io/get-pip.py" -OutFile $getPip -UseBasicParsing
        & $pyCmd @pyPrefix $getPip 2>&1 | Out-Null
        Remove-Item $getPip -ErrorAction SilentlyContinue
    }
}

& $pyCmd @pyPrefix -m pip install --upgrade pip --quiet 2>&1 | Out-Null
Write-Ok "$( & $pyCmd @pyPrefix -m pip --version 2>&1 )"

# --- Step 3: Install WorkPilot ---
Write-Step "Installing / upgrading $Package ..."

$out = & $pyCmd @pyPrefix -m pip install --upgrade $Package 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Warn "Standard install failed. Retrying with --user ..."
    $out = & $pyCmd @pyPrefix -m pip install --upgrade --user $Package 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Fail "pip install failed:"
        Write-Host ($out | Out-String) -ForegroundColor Red
        Write-Host "  If behind a corporate proxy, set HTTPS_PROXY and retry." -ForegroundColor Yellow
        exit 1
    }
}
Write-Ok "$Package installed."

# --- Step 4: Ensure workpilot is on PATH ---
Write-Step "Verifying workpilot CLI ..."

Refresh-Path

if (-not (Get-Command workpilot -ErrorAction SilentlyContinue)) {
    # Auto-add Scripts directories to User PATH
    $scriptsDir  = & $pyCmd @pyPrefix -c "import sysconfig; print(sysconfig.get_path('scripts'))" 2>&1
    $userScripts = & $pyCmd @pyPrefix -c "import sysconfig; print(sysconfig.get_path('scripts', 'nt_user'))" 2>&1

    foreach ($d in @($scriptsDir, $userScripts) | Select-Object -Unique) {
        if ($d) { Add-ToUserPath $d }
    }
    Refresh-Path
}

if (Get-Command workpilot -ErrorAction SilentlyContinue) {
    Write-Ok "$( & workpilot version 2>&1 )"
} else {
    Write-Warn "workpilot not found on PATH yet."
    $sd = & $pyCmd @pyPrefix -c "import sysconfig; print(sysconfig.get_path('scripts'))" 2>&1
    Write-Host ""
    Write-Host "  Restart your terminal to pick up PATH changes, then run:" -ForegroundColor Yellow
    Write-Host "    workpilot version" -ForegroundColor Yellow
    if ($sd) { Write-Host "  (Scripts dir: $sd)" -ForegroundColor DarkGray }
    Write-Host ""
}

# --- Done ---
Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host "  WorkPilot installed successfully!" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host ""
Write-Host "  Next steps:" -ForegroundColor Cyan
Write-Host "    workpilot init    # guided project setup" -ForegroundColor White
Write-Host "    workpilot chat    # start chatting" -ForegroundColor White
Write-Host ""
