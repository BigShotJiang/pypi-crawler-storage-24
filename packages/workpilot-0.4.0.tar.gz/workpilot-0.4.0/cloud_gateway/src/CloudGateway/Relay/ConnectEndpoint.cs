using System.Buffers;
using System.Net.WebSockets;
using System.Security.Claims;
using System.Text;
using System.Text.Json;
using CloudGateway.Config;
using CloudGateway.Helpers;
using CloudGateway.Models;
using CloudGateway.Services;
using Microsoft.Extensions.Options;

namespace CloudGateway.Relay;

public static class ConnectEndpoint
{
    public static IEndpointRouteBuilder MapConnectEndpoint(this IEndpointRouteBuilder app)
    {
        app.MapGet("/connect", HandleAsync)
           .RequireAuthorization("WorkPilotClient");

        return app;
    }

    private static async Task HandleAsync(
        HttpContext ctx,
        IClientRegistry registry,
        IOfflineBuffer buffer,
        IReplyContextStore replyStore,
        IOutboundRouter router,
        IAdminRelay adminRelay,
        IOptions<RelayOptions> relayOpts,
        IOptions<RateLimitOptions> rateLimitOpts,
        ILogger<Program> logger)
    {
        if (!ctx.WebSockets.IsWebSocketRequest)
        {
            ctx.Response.StatusCode = StatusCodes.Status400BadRequest;
            return;
        }

        var oid = ctx.User.GetOid();
        var upn = ctx.User.GetUpn(oid ?? "unknown");

        if (string.IsNullOrEmpty(oid))
        {
            ctx.Response.StatusCode = StatusCodes.Status401Unauthorized;
            return;
        }

        // Enforce per-user WebSocket connection cap before accepting the upgrade.
        var maxConns = rateLimitOpts.Value.MaxWebSocketConnectionsPerUser;
        if (registry.GetAll(oid).Count >= maxConns)
        {
            ctx.Response.StatusCode = StatusCodes.Status429TooManyRequests;
            ctx.Response.Headers["Retry-After"] = "60";
            logger.LogWarning(
                "WebSocket cap ({Max}) reached for {Oid} — rejecting /connect", maxConns, oid);
            return;
        }

        var opts = relayOpts.Value;
        using var ws = await ctx.WebSockets.AcceptWebSocketAsync();

        var connection = new ClientConnection { Oid = oid, Upn = upn, Socket = ws };
        registry.Register(connection);
        logger.LogInformation("Client connected: {Upn} ({Oid})", upn, oid);

        try
        {
            // ── Drain offline buffer ─────────────────────────────────────────
            var pending = buffer.Drain(oid);
            await SendJsonAsync(ws, new ConnectedFrame { BufferedCount = pending.Count },
                ctx.RequestAborted);

            if (pending.Count > 0)
            {
                await SendJsonAsync(ws, new BufferedStartFrame { Count = pending.Count },
                    ctx.RequestAborted);
                foreach (var msg in pending)
                    await SendJsonAsync(ws, msg, ctx.RequestAborted);
                await SendJsonAsync(ws, new BufferedEndFrame(), ctx.RequestAborted);
            }

            // ── Heartbeat task ───────────────────────────────────────────────
            using var heartbeatCts = CancellationTokenSource.CreateLinkedTokenSource(
                ctx.RequestAborted);
            var heartbeatTask = RunHeartbeatAsync(ws, connection, opts, heartbeatCts.Token, logger);

            // ── Receive loop ─────────────────────────────────────────────────
            await ReceiveLoopAsync(ws, oid, connection, replyStore, router, adminRelay,
                opts, heartbeatCts, ctx.RequestAborted, logger);

            await heartbeatTask;
        }
        finally
        {
            registry.Unregister(connection);
            logger.LogInformation("Client disconnected: {Upn} ({Oid})", upn, oid);
        }
    }

    // ── Receive loop ─────────────────────────────────────────────────────────

    private static async Task ReceiveLoopAsync(
        WebSocket ws,
        string senderOid,
        ClientConnection connection,
        IReplyContextStore replyStore,
        IOutboundRouter router,
        IAdminRelay adminRelay,
        RelayOptions opts,
        CancellationTokenSource heartbeatCts,
        CancellationToken requestAborted,
        ILogger logger)
    {
        var recvBuffer = ArrayPool<byte>.Shared.Rent(opts.ChunkBufferMaxBytes);
        try
        {
            while (ws.State == WebSocketState.Open && !requestAborted.IsCancellationRequested)
            {
                WebSocketReceiveResult result;
                using var ms = new MemoryStream();

                // Accumulate fragmented message
                do
                {
                    try
                    {
                        result = await ws.ReceiveAsync(
                            new ArraySegment<byte>(recvBuffer), requestAborted);
                    }
                    catch (OperationCanceledException)
                    {
                        return;
                    }
                    catch (WebSocketException)
                    {
                        return;
                    }

                    if (result.MessageType == WebSocketMessageType.Close)
                    {
                        await CloseGracefullyAsync(ws, logger);
                        return;
                    }

                    ms.Write(recvBuffer, 0, result.Count);
                }
                while (!result.EndOfMessage);

                connection.LastActivity = DateTimeOffset.UtcNow;

                await DispatchFrameAsync(
                    ms.ToArray(), senderOid, connection, replyStore, router, adminRelay,
                    requestAborted, logger);
            }
        }
        finally
        {
            ArrayPool<byte>.Shared.Return(recvBuffer);
            heartbeatCts.Cancel();
        }
    }

    private static async Task DispatchFrameAsync(
        byte[] bytes,
        string senderOid,
        ClientConnection connection,
        IReplyContextStore replyStore,
        IOutboundRouter router,
        IAdminRelay adminRelay,
        CancellationToken ct,
        ILogger logger)
    {
        try
        {
            // Peek type field, then deserialise fully — all in one try block
            // so any JsonException from missing required properties is caught.
            using var doc = JsonDocument.Parse(bytes);
            if (!doc.RootElement.TryGetProperty("type", out var typeProp)) return;

            switch (typeProp.GetString())
            {
                case FrameType.Pong:
                    connection.LastActivity = DateTimeOffset.UtcNow;
                    logger.LogDebug("Pong received from {Oid}", senderOid);
                    break;

                case FrameType.Response:
                    var resp = WireFrames.Deserialize<ResponseFrame>(bytes);
                    if (resp is null) break;
                    await RouteOutboundAsync(
                        resp.ChannelId, senderOid, connection,
                        replyStore, router,
                        async (ctx, token) => await router.RouteResponseAsync(resp, ctx, token),
                        deleteContext: true,   // response is always final
                        ct, logger);
                    break;

                // Approval card — send to channel but keep reply context alive so the
                // tool result can be delivered after the user approves/denies.
                case "notification":
                    var notif = WireFrames.Deserialize<ResponseFrame>(bytes);
                    if (notif is null) break;
                    await RouteOutboundAsync(
                        notif.ChannelId, senderOid, connection,
                        replyStore, router,
                        async (ctx, token) => await router.RouteResponseAsync(notif, ctx, token),
                        deleteContext: false,   // keep context for the final tool-result reply
                        ct, logger);
                    break;

                case FrameType.Chunk:
                    var chunk = WireFrames.Deserialize<ChunkFrame>(bytes);
                    if (chunk is null) break;
                    await RouteOutboundAsync(
                        chunk.ChannelId, senderOid, connection,
                        replyStore, router,
                        async (ctx, token) => await router.RouteChunkAsync(chunk, ctx, token),
                        deleteContext: chunk.Done,   // keep context until streaming completes
                        ct, logger);
                    break;

                case FrameType.AdminResponse:
                    var adminResp = WireFrames.Deserialize<AdminResponseFrame>(bytes);
                    if (adminResp is not null)
                        adminRelay.Complete(adminResp.RequestId, adminResp.Status, adminResp.Body);
                    break;

                case FrameType.Typing:
                    var typing = WireFrames.Deserialize<TypingFrame>(bytes);
                    if (typing is null) break;
                    await RouteOutboundAsync(
                        typing.ChannelId, senderOid, connection,
                        replyStore, router,
                        async (ctx, token) => await router.RouteTypingAsync(typing, ctx, token),
                        deleteContext: false,   // typing does not consume the reply context
                        ct, logger);
                    break;

                default:
                    logger.LogDebug("Unknown frame type from {Oid}: {Type}",
                        senderOid, typeProp.GetString());
                    break;
            }
        }
        catch (JsonException ex)
        {
            logger.LogWarning(ex, "Malformed or invalid frame from {Oid} — ignored", senderOid);
        }
    }

    private static async Task RouteOutboundAsync(
        string channelId,
        string senderOid,
        ClientConnection connection,
        IReplyContextStore replyStore,
        IOutboundRouter router,
        Func<ReplyContext, CancellationToken, Task> deliver,
        bool deleteContext,
        CancellationToken ct,
        ILogger logger)
    {
        var context = replyStore.Get(channelId, senderOid);
        if (context is null)
        {
            // Check for OID mismatch vs plain expiry (don't reveal owner to caller)
            var unchecked_ = replyStore.GetUnchecked(channelId);
            if (unchecked_ is not null)
            {
                logger.LogWarning(
                    "SECURITY: OID mismatch on channel_id={ChannelId} " +
                    "sender={SenderOid} owner={OwnerOid}",
                    channelId, senderOid, unchecked_.OwnerOid);
            }

            // Notify the client that the reply window has expired (design §5.1).
            // Use Task.Run to detach the send from the receive-loop execution context —
            // IIS inprocess WebSocket module requires sends to come from a thread pool
            // thread rather than from within the receive-dispatch callback chain.
            logger.LogDebug("reply_context_expired channel_id={ChannelId}", channelId);
            _ = Task.Run(() => connection.SendJsonAsync(
                new ErrorFrame
                {
                    Code      = ErrorCode.ReplyContextExpired,
                    ChannelId = channelId,
                    Message   = "The reply window for this message has expired. The response was not delivered.",
                }, ct), ct);
            return;
        }

        await deliver(context, ct);

        // Delete the context after the final delivery so it cannot be reused.
        // For streaming (chunk done=false) the caller passes deleteContext=false
        // to preserve the context for subsequent chunk/response frames.
        if (deleteContext)
            replyStore.Delete(channelId);
    }

    // ── Heartbeat ────────────────────────────────────────────────────────────

    private static async Task RunHeartbeatAsync(
        WebSocket ws,
        ClientConnection connection,
        RelayOptions opts,
        CancellationToken ct,
        ILogger logger)
    {
        while (!ct.IsCancellationRequested && ws.State == WebSocketState.Open)
        {
            try
            {
                await Task.Delay(opts.HeartbeatInterval, ct);
            }
            catch (OperationCanceledException) { return; }

            if (ws.State != WebSocketState.Open) return;

            var sentAt = DateTimeOffset.UtcNow;
            try
            {
                // Use the connection's serialised send so this cannot race with
                // MessageDelivery or error-frame Task.Run sends on the same socket.
                await connection.SendJsonAsync(new PingFrame(), ct);
            }
            catch { return; }

            logger.LogDebug("Ping sent to {Oid}", connection.Oid);

            // Wait for pong (check lastActivity updated within HeartbeatTimeout)
            await Task.Delay(opts.HeartbeatTimeout, ct).ContinueWith(_ => { },
                CancellationToken.None);

            if (connection.LastActivity < sentAt)
            {
                logger.LogWarning(
                    "No pong received within {Timeout}s from {Oid} — closing stale connection",
                    opts.HeartbeatTimeoutSeconds, connection.Oid);
                await CloseGracefullyAsync(ws, logger);
                return;
            }
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    internal static async Task SendJsonAsync<T>(
        WebSocket ws, T payload, CancellationToken ct)
    {
        if (ws.State != WebSocketState.Open) return;
        var bytes = Encoding.UTF8.GetBytes(WireFrames.Serialize(payload));
        await ws.SendAsync(new ArraySegment<byte>(bytes),
            WebSocketMessageType.Text, endOfMessage: true, ct);
    }

    private static async Task CloseGracefullyAsync(WebSocket ws, ILogger logger)
    {
        try
        {
            if (ws.State == WebSocketState.Open)
                await ws.CloseAsync(WebSocketCloseStatus.NormalClosure,
                    "Closing", CancellationToken.None);
        }
        catch (Exception ex)
        {
            logger.LogDebug(ex, "Error during graceful WebSocket close");
        }
    }
}
