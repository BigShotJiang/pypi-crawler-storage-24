namespace CloudGateway.Config;

/// <summary>
/// Configuration for the admin dashboard portal.
/// Bind from appsettings.json section "Admin".
/// </summary>
public sealed class AdminOptions
{
    public const string Section = "Admin";

    /// <summary>
    /// Entra OIDs allowed to access the admin dashboard.
    /// Empty list = all authenticated users with a valid OID can access.
    /// </summary>
    public List<string> AllowedOids { get; set; } = [];

    /// <summary>Enable or disable the admin dashboard endpoints.</summary>
    public bool Enabled { get; set; } = true;
}
