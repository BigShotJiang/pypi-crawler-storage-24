namespace CloudGateway.Config;

public sealed class RateLimitOptions
{
    public const string Section = "RateLimit";

    /// <summary>Maximum HTTP requests per minute per authenticated user (keyed on OID).</summary>
    public int HttpRequestsPerMinute { get; set; } = 60;

    /// <summary>Maximum simultaneous WebSocket connections per user OID.</summary>
    public int MaxWebSocketConnectionsPerUser { get; set; } = 5;
}
