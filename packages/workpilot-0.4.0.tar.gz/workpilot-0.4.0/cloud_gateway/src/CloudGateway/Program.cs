using CloudGateway.Auth;
using CloudGateway.Config;
using CloudGateway.Helpers;
using Microsoft.AspNetCore.DataProtection;
using CloudGateway.Endpoints;
using CloudGateway.Middleware;
using CloudGateway.Relay;
using CloudGateway.Services;
using CloudGateway.Teams;
using Microsoft.Agents.Builder;
using Microsoft.Agents.Hosting.AspNetCore;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.Identity.Web;
using Serilog;
using Serilog.Events;

// ── Bootstrap logger (before host build) ────────────────────────────────────
Log.Logger = new LoggerConfiguration()
    .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
    .WriteTo.Console()
    .CreateBootstrapLogger();

try
{
    var builder = WebApplication.CreateBuilder(args);

    // ── Data Protection key persistence ──────────────────────────────────────
    // Default in-memory keys are lost on every App Service restart, breaking
    // the OIDC correlation cookie (Correlation failed → 500 on /auth/callback).
    // Persist Data Protection keys so OIDC state/correlation cookies survive
    // app restarts and deployments.
    // Priority: explicit app-setting > HOME env > ContentRootPath (ephemeral fallback).
    var keysDir =
        Environment.GetEnvironmentVariable("DataProtectionKeysPath")
        ?? (Environment.GetEnvironmentVariable("WEBSITE_SITE_NAME") is not null
            ? Path.Combine(Environment.GetEnvironmentVariable("HOME") ?? @"D:\home", "dataprotection-keys")
            : Path.Combine(builder.Environment.ContentRootPath, "dataprotection-keys"));
    Directory.CreateDirectory(keysDir);
    builder.Services.AddDataProtection()
        .PersistKeysToFileSystem(new System.IO.DirectoryInfo(keysDir))
        .SetApplicationName("workpilot-cloud-gateway");

    // ── Serilog ──────────────────────────────────────────────────────────────
    builder.Host.UseSerilog((ctx, services, cfg) =>
    {
        cfg.ReadFrom.Configuration(ctx.Configuration)
           .ReadFrom.Services(services)
           .Enrich.FromLogContext()
           .WriteTo.Console();

        // Use GetService (nullable) — AddApplicationInsightsTelemetry may have thrown
        // and been caught below, leaving TelemetryClient unregistered.
        var aiCs = ctx.Configuration["ApplicationInsights:ConnectionString"];
        if (!string.IsNullOrWhiteSpace(aiCs))
        {
            var telemetryClient = services.GetService<Microsoft.ApplicationInsights.TelemetryClient>();
            if (telemetryClient is not null)
                cfg.WriteTo.ApplicationInsights(telemetryClient, TelemetryConverter.Traces);
        }
    });

    // ── Application Insights (optional) ─────────────────────────────────────
    // Note: AddApplicationInsightsTelemetry can cause crashes in some IIS hosting
    // contexts. Wrap in try-catch and disable gracefully if initialization fails.
    var aiCs2 = builder.Configuration["ApplicationInsights:ConnectionString"];
    if (!string.IsNullOrWhiteSpace(aiCs2))
    {
        try { builder.Services.AddApplicationInsightsTelemetry(o => o.ConnectionString = aiCs2); }
        catch (Exception ex) { Log.Warning(ex, "Application Insights SDK initialization failed — telemetry disabled"); }
    }

    // ── Configuration ────────────────────────────────────────────────────────
    builder.Services.Configure<RelayOptions>(
        builder.Configuration.GetSection(RelayOptions.Section));
    builder.Services.Configure<RateLimitOptions>(
        builder.Configuration.GetSection(RateLimitOptions.Section));
    builder.Services.Configure<TeamsOptions>(
        builder.Configuration.GetSection(TeamsOptions.Section));
    builder.Services.Configure<DirectLineOptions>(
        builder.Configuration.GetSection(DirectLineOptions.Section));
    builder.Services.Configure<AdminOptions>(
        builder.Configuration.GetSection(AdminOptions.Section));

    // ── Core services (Phase 3) ──────────────────────────────────────────────
    builder.Services.AddSingleton<IClientRegistry,    InMemoryClientRegistry>();
    builder.Services.AddSingleton<IOfflineBuffer,     InMemoryOfflineBuffer>();
    builder.Services.AddSingleton<IReplyContextStore, InMemoryReplyContextStore>();
    builder.Services.AddHostedService(
        p => (InMemoryReplyContextStore)p.GetRequiredService<IReplyContextStore>());
    builder.Services.AddSingleton<StreamingChunkBuffer>();

    // ── Phase 7 services ─────────────────────────────────────────────────────
    builder.Services.AddSingleton<IWebChatRegistry, InMemoryWebChatRegistry>();

    // OutboundRouter: WebChat routes real; Teams stub until Phase 8
    builder.Services.AddSingleton<IOutboundRouter, OutboundRouter>();

    // ── Message delivery (online: direct WS; offline: buffer) ────────────────
    builder.Services.AddSingleton<IMessageDelivery, MessageDelivery>();

    // ── Admin relay (routes admin queries to Python client via WSS) ─────────
    builder.Services.AddSingleton<IAdminRelay, AdminRelay>();

    // ── Authentication ───────────────────────────────────────────────────────
    var bypassSection = builder.Configuration.GetSection(BypassAuthOptions.Section);
    var bypassEnabled = builder.Environment.IsDevelopment()
                        && bypassSection.GetValue<bool>("Enabled");
    // No predictable fallback — require explicit config when bypass is active
    // so the token cannot be guessed from a well-known default string.
    var bypassToken = bypassSection.GetValue<string>("Token");
    if (bypassEnabled && string.IsNullOrWhiteSpace(bypassToken))
        throw new InvalidOperationException(
            "Auth:Bypass:Token must be set explicitly in appsettings.Development.json " +
            "when Auth:Bypass:Enabled is true.");
    bypassToken ??= string.Empty;

    if (bypassEnabled)
    {
        // Development: SmartAuth policy scheme routes bypass token → BypassAuthHandler,
        // everything else → JwtBearer. Works for both /connect and /webchat.
        builder.Services
            .AddAuthentication(o =>
            {
                o.DefaultAuthenticateScheme = "SmartAuth";
                o.DefaultChallengeScheme    = "SmartAuth";
                o.DefaultSignInScheme       = CookieAuthenticationDefaults.AuthenticationScheme;
            })
            .AddPolicyScheme("SmartAuth", "SmartAuth", o =>
            {
                o.ForwardDefaultSelector = ctx =>
                {
                    var auth = ctx.Request.Headers.Authorization.FirstOrDefault();
                    if (auth is not null
                        && auth.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase)
                        && string.Equals(auth["Bearer ".Length..].Trim(), bypassToken,
                                         StringComparison.Ordinal))
                        return BypassAuthOptions.Scheme;
                    return JwtBearerDefaults.AuthenticationScheme;
                };
            })
            .AddScheme<BypassAuthOptions, BypassAuthHandler>(
                BypassAuthOptions.Scheme,
                opts => bypassSection.Bind(opts))
            .AddMicrosoftIdentityWebApi(builder.Configuration);
    }
    else
    {
        // Production: SmartProd policy scheme routes:
        //   Authorization: Bearer <token>  → JwtBearer  (/connect WorkPilot client)
        //   everything else                → Cookie     (/webchat browser)
        // OIDC challenge (code flow + PKCE, no client secret) sets the cookie on /auth/callback.
        var tenantId  = builder.Configuration["AzureAd:TenantId"];
        var clientId  = builder.Configuration["AzureAd:ClientId"];

        builder.Services
            .AddAuthentication(o =>
            {
                o.DefaultScheme          = "SmartProd";
                o.DefaultChallengeScheme = OpenIdConnectDefaults.AuthenticationScheme;
                // OIDC needs a concrete sign-in scheme to write the session cookie
                // after the callback. Without this, it tries to use "SmartProd" (a
                // policy routing scheme) as the sign-in target → 500 on /auth/callback.
                o.DefaultSignInScheme    = CookieAuthenticationDefaults.AuthenticationScheme;
            })
            // ── Route Bearer → JwtBearer, else → Cookie ──────────────────────
            .AddPolicyScheme("SmartProd", "SmartProd", o =>
            {
                o.ForwardDefaultSelector = ctx =>
                {
                    var auth = ctx.Request.Headers.Authorization.FirstOrDefault();
                    return (auth?.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase) == true)
                        ? JwtBearerDefaults.AuthenticationScheme
                        : CookieAuthenticationDefaults.AuthenticationScheme;
                };
            })
            // ── Cookie: HttpOnly, Secure, SameSite=Strict ─────────────────────
            .AddCookie(CookieAuthenticationDefaults.AuthenticationScheme, o =>
            {
                o.Cookie.Name       = "workpilot.webchat";
                o.Cookie.HttpOnly   = true;
                o.Cookie.SecurePolicy = Microsoft.AspNetCore.Http.CookieSecurePolicy.Always;
                o.Cookie.SameSite   = Microsoft.AspNetCore.Http.SameSiteMode.Lax;
                o.LoginPath         = "/";          // browser navigates here → OIDC challenge
                o.ExpireTimeSpan    = TimeSpan.FromHours(8);
                o.SlidingExpiration = true;
                // WebSocket upgrades cannot follow HTTP redirects — return 401/403 directly.
                // OnRedirectToLogin: non-WebSocket requests keep the default redirect so the
                // browser navigates to the login page normally.
                // OnRedirectToAccessDenied: always returns 403. Without a configured
                // AccessDeniedPath, ctx.RedirectUri resolves to the current URL and redirecting
                // would cause an infinite loop (/portal → 403 → redirect /portal → …).
                o.Events = new CookieAuthenticationEvents
                {
                    OnRedirectToLogin = ctx =>
                    {
                        if (IsWebSocketUpgrade(ctx.HttpContext))
                            ctx.Response.StatusCode = StatusCodes.Status401Unauthorized;
                        else
                            ctx.Response.Redirect(ctx.RedirectUri);
                        return Task.CompletedTask;
                    },
                    OnRedirectToAccessDenied = ctx =>
                    {
                        // Always return 403 directly. Without a configured AccessDeniedPath,
                        // ctx.RedirectUri resolves to the current URL, which causes an infinite
                        // redirect loop (/portal → forbidden → redirect /portal → forbidden → …).
                        ctx.Response.StatusCode = StatusCodes.Status403Forbidden;
                        return Task.CompletedTask;
                    },
                };
            })
            // ── OIDC: server-side auth code flow with PKCE (no client secret) ──
            .AddOpenIdConnect(OpenIdConnectDefaults.AuthenticationScheme, o =>
            {
                o.Authority    = $"https://login.microsoftonline.com/{tenantId}/v2.0";
                o.ClientId     = clientId;
                o.ResponseType = "code";
                o.ResponseMode = "query";       // GET redirect (code in query string)
                o.UsePkce      = true;          // PKCE replaces client secret for public client
                o.SaveTokens   = false;         // identity only — no downstream API calls needed
                o.CallbackPath = "/auth/callback";

                o.Scope.Clear();
                o.Scope.Add("openid");
                o.Scope.Add("profile");

                // Map oid and upn claims from the id_token to ClaimsPrincipal.
                // These are used by IClientRegistry routing and session key derivation.
                o.ClaimActions.MapJsonKey("oid",                "oid");
                o.ClaimActions.MapJsonKey("preferred_username", "preferred_username");
                o.ClaimActions.MapJsonKey("upn",                "upn");

                o.SignInScheme = CookieAuthenticationDefaults.AuthenticationScheme;

                o.Events = new Microsoft.AspNetCore.Authentication.OpenIdConnect.OpenIdConnectEvents
                {
                    // WebSocket upgrade requests cannot follow HTTP redirects.
                    // Return 401 so the client-side SPA can handle the redirect.
                    OnRedirectToIdentityProvider = ctx =>
                    {
                        if (IsWebSocketUpgrade(ctx.HttpContext))
                        {
                            ctx.Response.StatusCode = StatusCodes.Status401Unauthorized;
                            ctx.HandleResponse();
                        }
                        return Task.CompletedTask;
                    },
                    // Redirect to home page on OIDC failure with error detail in query.
                    // A raw 500 body gets replaced by the Azure App Service IIS error page
                    // ("resource removed"), hiding the real error from the user.
                    OnRemoteFailure = ctx =>
                    {
                        // Build error chain (outer → inner) for diagnosis on home page banner.
                        var parts = new System.Collections.Generic.List<string>();
                        var cur   = ctx.Failure;
                        while (cur is not null) { parts.Add(cur.Message); cur = cur.InnerException; }
                        var msg = string.Join(" → ", parts.Count > 0 ? parts : ["auth_error"]);
                        ctx.Response.Redirect($"/?auth_error={Uri.EscapeDataString(msg)}");
                        ctx.HandleResponse();
                        return Task.CompletedTask;
                    },
                };
            })
            // ── JwtBearer for /connect (WorkPilot Python client) ─────────────
            .AddMicrosoftIdentityWebApi(
                builder.Configuration,
                jwtBearerScheme: JwtBearerDefaults.AuthenticationScheme);

        // NOTE: NoCorrOidcHandler (which skipped correlation validation) has been removed.
        // The Web Chat integration now uses MSAL.js popup auth, so the server-side OIDC
        // callback is no longer invoked for Web Chat users. Standard OpenIdConnect
        // correlation validation is required to prevent auth-response injection attacks
        // (an attacker can supply a valid PKCE pair but the correlation cookie ties the
        // response to the specific browser session that initiated the challenge).
    }

    // ── MsalBrowser JwtBearer scheme ─────────────────────────────────────────
    // Validates MSAL.js id-tokens sent by the browser Web Chat page.
    // id-tokens have aud = clientId (GUID, no api:// prefix) and no scp/roles
    // claim. Kept separate from the WorkPilot-client JwtBearer scheme so that
    // the existing /connect auth is not affected.
    var browserClientId = builder.Configuration["AzureAd:ClientId"] ?? string.Empty;
    var browserTenantId = builder.Configuration["AzureAd:TenantId"] ?? string.Empty;
    if (!string.IsNullOrEmpty(browserClientId) && !string.IsNullOrEmpty(browserTenantId))
    {
        builder.Services
            .AddAuthentication()
            .AddJwtBearer("MsalBrowser", opts =>
            {
                opts.Authority         = $"https://login.microsoftonline.com/{browserTenantId}/v2.0";
                opts.Audience          = browserClientId; // GUID — id-tokens have aud = clientId
                opts.MapInboundClaims  = false;
            });
    }

    static bool HasOid(System.Security.Claims.ClaimsPrincipal user) =>
        user.HasClaim(c => c.Type == "oid" || c.Type == CloudGateway.Helpers.ClaimHelper.OidClaimUri);

    // Shared OID requirement reused by both /connect and /webchat policies.
    Action<Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder> requireOid = p =>
        p.RequireAuthenticatedUser().RequireAssertion(ctx => HasOid(ctx.User));

    builder.Services.AddAuthorization(o =>
    {
        // /connect — WorkPilot Python client (JwtBearer in production, bypass in dev)
        o.AddPolicy("WorkPilotClient", requireOid);

        // /webchat — browser Web Chat (Cookie+OIDC in production, bypass in dev)
        o.AddPolicy("WebChatUser", requireOid);

        // /webchat/directline/token — MSAL.js browser clients sending id-tokens.
        // MsalBrowser scheme is only registered when AzureAd:ClientId is non-empty.
        // Only include it in the policy when actually registered to avoid
        // InvalidOperationException at runtime when clientId is missing.
        o.AddPolicy("WebChatBrowserUser", policy =>
        {
            var schemes = new List<string>();
            if (bypassEnabled)             schemes.Add(BypassAuthOptions.Scheme);
            if (!string.IsNullOrEmpty(browserClientId)) schemes.Add("MsalBrowser");
            policy.RequireAuthenticatedUser()
                  .AddAuthenticationSchemes(schemes.ToArray())
                  .RequireClaim("oid");
        });

        // /bot/teams: M365 Agents SDK handles Bot Framework JWT internally via
        // AddAgentAspNetAuthentication. This policy just requires authentication
        // to have been attempted; the adapter enforces Bot Framework token rules.
        o.AddPolicy("AgentAuth", policy => policy.RequireAssertion(_ => true));

        // /admin — admin dashboard (Cookie+OIDC in production, bypass in dev).
        // If Admin:AllowedOids is non-empty, only those OIDs can access.
        var adminAllowedOids = builder.Configuration
            .GetSection("Admin:AllowedOids").Get<string[]>() ?? [];
        o.AddPolicy("AdminUser", policy =>
            policy.RequireAuthenticatedUser()
                  .RequireAssertion(ctx =>
                  {
                      if (!HasOid(ctx.User)) return false;
                      if (adminAllowedOids.Length == 0) return true;
                      var oid = ctx.User.GetOid();
                      return oid is not null && Array.Exists(
                          adminAllowedOids,
                          a => string.Equals(a, oid, StringComparison.OrdinalIgnoreCase));
                  }));
    });

    // ── TeamsReplyService — always registered (OutboundRouter depends on it) ────
    // OutboundRouter is registered unconditionally above; it injects TeamsReplyService.
    // The service itself is a no-op in dev mode (skips HTTP calls). Even when
    // Teams:Enabled=false, registering it costs nothing — the /bot/teams endpoint
    // and the M365 Agents SDK are the only conditional parts below.
    builder.Services.AddHttpClient("BotConnector");
    builder.Services.AddSingleton<TeamsReplyService>();
    builder.Services.AddHttpClient("DirectLine", c =>
        c.BaseAddress = new Uri("https://directline.botframework.com/"));

    // ── Phase 8: M365 Agents SDK (conditional on Teams:Enabled) ─────────────
    var teamsEnabled = builder.Configuration.GetValue("Teams:Enabled", false);
    if (teamsEnabled)
    {
        // IStorage is required by AgentApplicationOptions TurnStateFactory.
        builder.Services.AddSingleton<Microsoft.Agents.Storage.IStorage>(
            new Microsoft.Agents.Storage.MemoryStorage());

        // Register AgentApplicationOptions manually to disable @mention stripping.
        // Design decision: server passes content verbatim; Python client strips the mention.
        builder.Services.AddSingleton(sp =>
            new Microsoft.Agents.Builder.App.AgentApplicationOptions(
                sp.GetRequiredService<Microsoft.Agents.Storage.IStorage>())
            {
                RemoveRecipientMention = false,  // pass <at>WorkPilot</at> verbatim
                NormalizeMentions      = false,
            });

        // IAgentHttpAdapter (CloudAdapter) handles Bot Framework JWT validation internally.
        // TokenValidation:Enabled=false in appsettings.Development.json bypasses it locally.
        builder.AddAgent<WorkPilotAgent>();
    }

    // ── Build ────────────────────────────────────────────────────────────────
    var app = builder.Build();

    // ── Middleware pipeline ──────────────────────────────────────────────────
    var relayOpts = builder.Configuration
        .GetSection(RelayOptions.Section)
        .Get<RelayOptions>() ?? new RelayOptions();
    app.UseWebSockets(new WebSocketOptions
    {
        KeepAliveInterval = relayOpts.HeartbeatInterval,
    });
    app.UseMiddleware<CorrelationIdMiddleware>();
    app.UseMiddleware<RequestLoggingMiddleware>();
    app.UseAuthentication();
    app.UseAuthorization();
    app.UseMiddleware<RateLimitMiddleware>();

    // ── Endpoints ────────────────────────────────────────────────────────────
    app.MapHealthEndpoints();
    app.MapAuthEndpoints(app.Environment.IsProduction(), browserClientId, browserTenantId);
    app.MapConnectEndpoint();               // Phase 6: GET /connect
    app.MapWebChatEndpoint();               // Phase 7: GET /webchat
    app.MapDebugEndpoints(app.Environment); // Dev-only
    app.MapAdminEndpoints();               // Portal dashboard (/portal)
    // Require all three values to be present: DirectLine:Enabled=true AND
    // AzureAd:ClientId/TenantId non-empty. Without clientId/tenantId the
    // MsalBrowser scheme is not registered and /webchat/ui renders a broken page.
    var dlEnabled  = builder.Configuration.GetValue("DirectLine:Enabled", false);
    var dlClientId = builder.Configuration["AzureAd:ClientId"]  ?? string.Empty;
    var dlTenantId = builder.Configuration["AzureAd:TenantId"]  ?? string.Empty;
    app.MapBotWebChatEndpoint(             // DirectLine Web Chat token + UI (MSAL.js)
        enabled:  dlEnabled && !string.IsNullOrWhiteSpace(dlClientId) && !string.IsNullOrWhiteSpace(dlTenantId),
        clientId: dlClientId,
        tenantId: dlTenantId);

    // Phase 8: POST /bot/teams — registered only when Teams:Enabled=true
    if (teamsEnabled)
    {
        app.MapPost("/bot/teams", async (
            HttpRequest  request,
            HttpResponse response,
            IAgentHttpAdapter adapter,
            IAgent        agent,
            CancellationToken ct) =>
        {
            await adapter.ProcessAsync(request, response, agent, ct);
        }).RequireAuthorization("AgentAuth");
    }

    app.Run();
}
catch (Exception ex)
{
    Log.Fatal(ex, "Host terminated unexpectedly");
}
finally
{
    Log.CloseAndFlush();
}

// Returns true for WebSocket upgrade requests (both Kestrel and IIS/ARR paths).
static bool IsWebSocketUpgrade(HttpContext ctx) =>
    ctx.WebSockets.IsWebSocketRequest ||
    string.Equals(ctx.Request.Headers.Upgrade.ToString(), "websocket",
        StringComparison.OrdinalIgnoreCase);

public partial class Program { }
