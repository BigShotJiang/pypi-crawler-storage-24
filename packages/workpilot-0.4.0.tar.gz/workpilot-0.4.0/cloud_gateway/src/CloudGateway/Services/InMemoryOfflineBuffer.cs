using System.Collections.Concurrent;
using CloudGateway.Config;
using CloudGateway.Models;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace CloudGateway.Services;

/// <summary>
/// In-memory offline buffer with configurable TTL and per-user message cap.
/// Messages are lost on server restart (by design — stateless service).
/// Future: replace with Redis-backed implementation for durability.
/// </summary>
public sealed class InMemoryOfflineBuffer : IOfflineBuffer
{
    private readonly record struct Entry(MessageFrame Frame, DateTimeOffset ExpiresAt);

    private readonly ConcurrentDictionary<string, Queue<Entry>> _store = new();
    private readonly TimeSpan _ttl;
    private readonly int _maxMessages;
    private readonly ILogger<InMemoryOfflineBuffer> _logger;

    public InMemoryOfflineBuffer(
        IOptions<RelayOptions> options,
        ILogger<InMemoryOfflineBuffer> logger)
    {
        _ttl         = options.Value.OfflineBufferTtl;
        _maxMessages = options.Value.OfflineBufferMaxMessages;
        _logger      = logger;
    }

    public void Enqueue(string oid, MessageFrame message)
    {
        var queue = _store.GetOrAdd(oid, _ => new Queue<Entry>());

        lock (queue)
        {
            while (queue.Count >= _maxMessages)
                queue.Dequeue();   // drop oldest

            queue.Enqueue(new Entry(message, DateTimeOffset.UtcNow + _ttl));
        }

        _logger.LogDebug("Buffered message for offline user {Oid} (queue={Count})",
            oid, queue.Count);
    }

    public IReadOnlyList<MessageFrame> Drain(string oid)
    {
        if (!_store.TryRemove(oid, out var queue))
            return [];

        var now    = DateTimeOffset.UtcNow;
        var result = new List<MessageFrame>();

        lock (queue)
        {
            while (queue.TryDequeue(out var entry))
            {
                if (entry.ExpiresAt > now)
                    result.Add(entry.Frame);
            }
        }

        _logger.LogInformation("Drained {Count} buffered message(s) for user {Oid}",
            result.Count, oid);
        return result;
    }
}
