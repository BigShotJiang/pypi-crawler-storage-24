using CloudGateway.Models;

namespace CloudGateway.Services;

/// <summary>
/// Relays admin queries through the /connect WSS to the Python client.
/// SendAsync sends an admin_request and awaits the correlated admin_response.
/// Complete is called by ConnectEndpoint when an admin_response frame arrives.
/// </summary>
public interface IAdminRelay
{
    /// <summary>
    /// Send an admin request to the user's Python client and await the response.
    /// Returns (status, body) from the client, or (503, ...) if offline, (504, ...) on timeout.
    /// </summary>
    Task<(int Status, string Body)> SendAsync(
        string oid, string endpoint, string method = "GET",
        string? body = null, CancellationToken ct = default);

    /// <summary>Complete a pending admin request (called when admin_response arrives).</summary>
    void Complete(string requestId, int status, string body);
}
