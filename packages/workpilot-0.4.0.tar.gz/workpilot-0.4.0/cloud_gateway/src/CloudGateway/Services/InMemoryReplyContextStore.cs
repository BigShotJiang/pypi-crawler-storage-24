using System.Collections.Concurrent;
using CloudGateway.Config;
using CloudGateway.Models;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace CloudGateway.Services;

/// <summary>
/// In-memory reply context store with TTL eviction.
/// Validates owner_oid to prevent cross-user reply injection.
/// Background timer evicts expired entries.
/// </summary>
public sealed class InMemoryReplyContextStore : IReplyContextStore, IHostedService, IDisposable
{
    private readonly ConcurrentDictionary<string, ReplyContext> _store = new();
    private readonly TimeSpan _evictionInterval;
    private readonly ILogger<InMemoryReplyContextStore> _logger;
    private Timer? _evictionTimer;

    public InMemoryReplyContextStore(
        IOptions<RelayOptions> options,
        ILogger<InMemoryReplyContextStore> logger)
    {
        _evictionInterval = options.Value.ReplyContextEvictionInterval;
        _logger           = logger;
    }

    public void Store(ReplyContext context) =>
        _store[context.ChannelId] = context;

    public ReplyContext? Get(string channelId, string ownerOid)
    {
        if (!_store.TryGetValue(channelId, out var ctx)) return null;

        if (ctx.ExpiresAt <= DateTimeOffset.UtcNow)
        {
            _store.TryRemove(channelId, out _);
            return null;
        }

        if (!string.Equals(ctx.OwnerOid, ownerOid, StringComparison.Ordinal))
        {
            // Security: caller must log the WARNING — this method stays silent
            return null;
        }

        return ctx;
    }

    public ReplyContext? GetUnchecked(string channelId)
    {
        _store.TryGetValue(channelId, out var ctx);
        return ctx;
    }

    public void Delete(string channelId) =>
        _store.TryRemove(channelId, out _);

    // ── Background eviction ──────────────────────────────────────────────────

    public Task StartAsync(CancellationToken cancellationToken)
    {
        _evictionTimer = new Timer(
            _ => Evict(),
            null,
            _evictionInterval,
            _evictionInterval);
        return Task.CompletedTask;
    }

    public Task StopAsync(CancellationToken cancellationToken)
    {
        _evictionTimer?.Change(Timeout.Infinite, 0);
        return Task.CompletedTask;
    }

    private void Evict()
    {
        var now     = DateTimeOffset.UtcNow;
        var removed = 0;

        foreach (var (key, ctx) in _store)
        {
            if (ctx.ExpiresAt <= now && _store.TryRemove(key, out _))
                removed++;
        }

        if (removed > 0)
            _logger.LogDebug("Evicted {Count} expired ReplyContext entries", removed);
    }

    public void Dispose() => _evictionTimer?.Dispose();
}
