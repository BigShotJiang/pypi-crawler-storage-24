using System.Net.WebSockets;
using System.Text;
using CloudGateway.Models;
using CloudGateway.Teams;
using Microsoft.Extensions.Logging;

namespace CloudGateway.Services;

/// <summary>
/// Routes client response/chunk frames back to the originating source channel.
/// - WebChat: sends directly to the browser WebSocket via IWebChatRegistry.
/// - Teams:   sends via Bot Connector REST API (TeamsReplyService).
///            Chunks are buffered in StreamingChunkBuffer; sent as one reply on done=true.
/// </summary>
public sealed class OutboundRouter(
    IWebChatRegistry webChatRegistry,
    StreamingChunkBuffer chunkBuffer,
    TeamsReplyService teamsReply,
    ILogger<OutboundRouter> logger) : IOutboundRouter
{
    public async Task RouteResponseAsync(
        ResponseFrame frame,
        ReplyContext context,
        CancellationToken ct = default)
    {
        switch (context.Source)
        {
            case ReplySource.WebChat:
                await SendToWebChatAsync(context.WebChatConnectionId, frame, ct);
                break;

            case ReplySource.Teams:
                // Flush any accumulated streaming chunks + append the final response content.
                var buffered = chunkBuffer.Flush(frame.ChannelId);
                var content  = string.IsNullOrEmpty(buffered)
                    ? frame.Content
                    : buffered + frame.Content;

                await teamsReply.SendReplyAsync(content, context, ct);
                break;
        }
    }

    public async Task RouteChunkAsync(
        ChunkFrame frame,
        ReplyContext context,
        CancellationToken ct = default)
    {
        switch (context.Source)
        {
            case ReplySource.WebChat:
                // Forward chunks to browser in real-time.
                await SendToWebChatAsync(context.WebChatConnectionId, frame, ct);
                break;

            case ReplySource.Teams:
                // Teams has no streaming API — accumulate chunks until done=true.
                if (!frame.Done)
                {
                    chunkBuffer.Append(frame.ChannelId, frame.Content);
                }
                else
                {
                    // Combine any previously buffered chunks with the final chunk's content.
                    // frame.Content on the done=true frame must NOT be discarded.
                    var accumulated = chunkBuffer.Flush(frame.ChannelId);
                    var toSend = string.IsNullOrEmpty(accumulated)
                        ? frame.Content
                        : accumulated + frame.Content;
                    if (!string.IsNullOrEmpty(toSend))
                        await teamsReply.SendReplyAsync(toSend, context, ct);
                }
                break;
        }
    }

    public async Task RouteTypingAsync(
        TypingFrame frame,
        ReplyContext context,
        CancellationToken ct = default)
    {
        switch (context.Source)
        {
            case ReplySource.WebChat:
                await SendToWebChatAsync(context.WebChatConnectionId, frame, ct);
                break;

            case ReplySource.Teams:
                await teamsReply.SendTypingAsync(context, ct);
                break;
        }
    }

    private async Task SendToWebChatAsync<T>(
        string? connectionId,
        T payload,
        CancellationToken ct)
    {
        if (string.IsNullOrEmpty(connectionId))
        {
            logger.LogWarning("WebChat route: no webchat_connection_id in ReplyContext");
            return;
        }

        var conn = webChatRegistry.Get(connectionId);
        if (conn is null)
        {
            logger.LogDebug(
                "WebChat connection {ConnectionId} no longer active — response dropped",
                connectionId);
            return;
        }

        try
        {
            var bytes = Encoding.UTF8.GetBytes(WireFrames.Serialize(payload));
            await conn.Socket.SendAsync(
                new ArraySegment<byte>(bytes),
                WebSocketMessageType.Text,
                endOfMessage: true,
                ct);
        }
        catch (WebSocketException ex)
        {
            logger.LogDebug(ex, "WebChat send failed for {ConnectionId}", connectionId);
            webChatRegistry.Unregister(connectionId);
        }
    }
}
