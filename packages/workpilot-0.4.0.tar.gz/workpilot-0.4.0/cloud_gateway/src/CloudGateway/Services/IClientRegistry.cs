using System.Net.WebSockets;
using System.Text;
using CloudGateway.Models;

namespace CloudGateway.Services;

/// <summary>Tracks a single active WorkPilot client WebSocket connection.</summary>
public sealed class ClientConnection
{
    public required string Oid          { get; init; }
    public required string Upn          { get; init; }
    public required WebSocket Socket    { get; init; }
    public DateTimeOffset ConnectedAt   { get; init; } = DateTimeOffset.UtcNow;
    public DateTimeOffset LastActivity  { get; set; }  = DateTimeOffset.UtcNow;

    // ASP.NET Core WebSocket does NOT support concurrent SendAsync calls.
    // All sends must be serialised through this lock regardless of which
    // code path originates the write (heartbeat, delivery, error frames, etc.).
    private readonly SemaphoreSlim _sendLock = new(1, 1);

    /// <summary>
    /// Thread-safe JSON send. Serialises concurrent callers so only one
    /// SendAsync is in-flight at a time on this WebSocket.
    /// Returns <c>false</c> when the socket is not open so callers can
    /// distinguish a silent skip from a successful send and buffer/unregister
    /// as appropriate.
    /// </summary>
    public async Task<bool> SendJsonAsync<T>(T payload, CancellationToken ct = default)
    {
        if (Socket.State != WebSocketState.Open) return false;

        await _sendLock.WaitAsync(ct);
        try
        {
            if (Socket.State != WebSocketState.Open) return false;
            var bytes = Encoding.UTF8.GetBytes(WireFrames.Serialize(payload));
            await Socket.SendAsync(
                new ArraySegment<byte>(bytes),
                WebSocketMessageType.Text,
                endOfMessage: true,
                ct);
            return true;
        }
        finally
        {
            _sendLock.Release();
        }
    }
}

/// <summary>
/// Maps Entra OID → active WebSocket connections.
/// Supports multiple simultaneous clients per user (home + work machine).
/// Routing delivers to the most recently active connection.
/// </summary>
public interface IClientRegistry
{
    void Register(ClientConnection connection);
    void Unregister(ClientConnection connection);

    /// <summary>Most recently active connection for the user, or null if offline.</summary>
    ClientConnection? GetActive(string oid);

    IReadOnlyList<ClientConnection> GetAll(string oid);
    bool IsOnline(string oid);
}
