using System.Collections.Concurrent;
using CloudGateway.Models;

namespace CloudGateway.Services;

/// <summary>
/// Relays admin data queries to the user's connected Python client via /connect WSS.
/// Tracks pending requests with TaskCompletionSource for async request/response correlation.
/// </summary>
public sealed class AdminRelay(
    IClientRegistry clientRegistry,
    ILogger<AdminRelay> logger) : IAdminRelay
{
    private static readonly TimeSpan Timeout = TimeSpan.FromSeconds(30);

    private readonly ConcurrentDictionary<string, TaskCompletionSource<(int, string)>>
        _pending = new();

    public async Task<(int Status, string Body)> SendAsync(
        string oid, string endpoint, string method = "GET",
        string? body = null, CancellationToken ct = default)
    {
        var conn = clientRegistry.GetActive(oid);
        if (conn is null)
            return (503, """{"error":"agent_offline","message":"WorkPilot client is not connected."}""");

        var requestId = $"adm_{Guid.NewGuid():N}";
        var tcs = new TaskCompletionSource<(int, string)>(
            TaskCreationOptions.RunContinuationsAsynchronously);
        _pending[requestId] = tcs;

        try
        {
            var frame = new AdminRequestFrame
            {
                RequestId = requestId,
                Endpoint  = endpoint,
                Method    = method,
                Body      = body,
            };

            var sent = await conn.SendJsonAsync(frame, ct);
            if (!sent)
                return (503, """{"error":"send_failed","message":"WebSocket send failed."}""");

            using var cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
            cts.CancelAfter(Timeout);

            return await tcs.Task.WaitAsync(cts.Token);
        }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested)
        {
            // Internal timeout — Python client didn't respond in time
            logger.LogWarning(
                "Admin relay timeout endpoint={Endpoint} oid={Oid}", endpoint, oid);
            return (504, """{"error":"timeout","message":"Python client did not respond in time."}""");
        }
        catch (OperationCanceledException)
        {
            // Caller cancelled (e.g., HTTP request aborted) — propagate
            throw;
        }
        finally
        {
            _pending.TryRemove(requestId, out _);
        }
    }

    public void Complete(string requestId, int status, string body)
    {
        if (_pending.TryRemove(requestId, out var tcs))
        {
            tcs.TrySetResult((status, body));
        }
        else
        {
            logger.LogDebug("No pending admin request for {RequestId}", requestId);
        }
    }
}
