using CloudGateway.Models;

namespace CloudGateway.Services;

/// <summary>
/// Delivers a MessageFrame to a user's WorkPilot client.
/// If online: sends directly over the active WebSocket.
/// If offline: enqueues to the OfflineBuffer for delivery on reconnect.
/// Used by both the Teams bot handler (Phase 8) and the debug endpoint.
/// </summary>
public interface IMessageDelivery
{
    Task DeliverAsync(string oid, MessageFrame frame, CancellationToken ct = default);
}
