using System.Net;
using System.Reflection;
using System.Security.Claims;
using System.Text.Json;
using CloudGateway.Helpers;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;

namespace CloudGateway.Endpoints;

public static class AuthEndpoints
{
    public static IEndpointRouteBuilder MapAuthEndpoints(
        this IEndpointRouteBuilder app,
        bool isProduction,
        string clientId,
        string tenantId)
    {
        // Pre-process templates once at startup — only the UPN placeholder
        // in the chat page needs per-request substitution.
        var loginHtml    = BuildLoginHtml(clientId, tenantId, isProduction);
        var chatTemplate = LoadTemplate("chat.html");  // contains {{UPN}}
        var homeHtml     = LoadTemplate("home.html");

        // ── Home page (public landing page) ──────────────────────────────────
        app.MapGet("/", () => Results.Content(homeHtml, "text/html; charset=utf-8"))
           .AllowAnonymous();

        // ── Chat page handler (GET /chat) ─────────────────────────────────────
        // Authenticated   → chat page  (connects to /webchat WebSocket)
        // Unauthenticated → login page (MSAL.js popup if clientId configured,
        //                               otherwise server-side redirect button)
        IResult ChatHandler(HttpContext ctx)
        {
            if (ctx.User.Identity?.IsAuthenticated == true)
            {
                var upn     = ctx.User.GetUpn();
                var safeUpn = WebUtility.HtmlEncode(upn);
                var html    = chatTemplate.Replace("{{UPN}}", safeUpn);
                return Results.Content(html, "text/html; charset=utf-8");
            }

            return Results.Content(loginHtml, "text/html; charset=utf-8");
        }

        app.MapGet("/chat", ChatHandler).AllowAnonymous();

        // ── Bootstrap install scripts (public, no auth required) ─────────────
        var installPs1 = LoadScript("install.ps1");
        var installSh  = LoadScript("install.sh");

        app.MapGet("/install.ps1", () =>
            Results.Content(installPs1, "text/plain; charset=utf-8"))
           .AllowAnonymous();

        app.MapGet("/install.sh", () =>
            Results.Content(installSh, "text/plain; charset=utf-8"))
           .AllowAnonymous();

        // ── Privacy policy & Terms of Use (required for Teams app store) ─────
        app.MapGet("/privacy", () => Results.Redirect("https://github.com/gim-home/WorkPilot#security"))
           .AllowAnonymous();
        app.MapGet("/terms", () => Results.Redirect("https://github.com/gim-home/WorkPilot"))
           .AllowAnonymous();

        // ── Blank popup-redirect page (MSAL.js popup redirectUri) ────────────
        app.MapGet("/auth/redirect", () =>
            Results.Content("<!DOCTYPE html><html><head><title></title></head><body></body></html>",
                "text/html"))
           .AllowAnonymous();

        // ── Token exchange: MSAL.js id-token → session cookie ────────────────
        if (!string.IsNullOrEmpty(clientId))
        {
            app.MapPost("/auth/token", async (HttpContext ctx) =>
            {
                var result = await ctx.AuthenticateAsync("MsalBrowser");
                if (!result.Succeeded)
                    return Results.Unauthorized();

                var oid = result.Principal?.GetOid();
                var upn = result.Principal?.GetUpn();

                if (string.IsNullOrEmpty(oid))
                    return Results.Unauthorized();

                var claims = new List<Claim> { new("oid", oid) };
                if (!string.IsNullOrEmpty(upn))
                    claims.Add(new Claim("preferred_username", upn));

                var identity  = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                var principal = new ClaimsPrincipal(identity);
                await ctx.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);

                return Results.Ok(new { oid, upn });
            }).AllowAnonymous();
        }

        // ── Fallback server-side login ────────────────────────────────────────
        // /auth/login?returnUrl=/portal  (default → /chat)
        app.MapGet("/auth/login", async (HttpContext ctx, string? returnUrl) =>
        {
            var redirect = string.IsNullOrEmpty(returnUrl) ? "/chat" : returnUrl;
            await ctx.ChallengeAsync(
                OpenIdConnectDefaults.AuthenticationScheme,
                new AuthenticationProperties { RedirectUri = redirect });
            return Results.Empty;
        }).AllowAnonymous();

        // ── OIDC callback (handles both GET fallback and form_post POST) ─────
        app.MapGet("/auth/callback",  (HttpContext ctx) => Results.Redirect("/chat")).AllowAnonymous();
        app.MapPost("/auth/callback", (HttpContext ctx) => Results.Redirect("/chat")).AllowAnonymous();

        // ── Sign-out ──────────────────────────────────────────────────────────
        app.MapPost("/auth/signout", async (HttpContext ctx) =>
        {
            await ctx.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            // OIDC SignOutAsync sets the redirect response internally; return Empty
            // so Minimal API does not emit a conflicting 200 body alongside it.
            await ctx.SignOutAsync(
                OpenIdConnectDefaults.AuthenticationScheme,
                new AuthenticationProperties { RedirectUri = "/" });
            return Results.Empty;
        }).AllowAnonymous();

        // ── Auth status ───────────────────────────────────────────────────────
        app.MapGet("/auth/me", (HttpContext ctx) =>
        {
            if (ctx.User.Identity?.IsAuthenticated != true)
                return Results.Unauthorized();

            var oid = ctx.User.GetOid();
            var upn = ctx.User.GetUpn();

            return Results.Ok(new { oid, upn });
        }).AllowAnonymous();

        return app;
    }

    // ── Template loading ──────────────────────────────────────────────────────

    /// <summary>Load an HTML template from the embedded Templates/ resources.</summary>
    private static string LoadTemplate(string fileName)
    {
        var resourceName = $"CloudGateway.Templates.{fileName}";
        using var stream = Assembly.GetExecutingAssembly()
                               .GetManifestResourceStream(resourceName)
                           ?? throw new InvalidOperationException(
                               $"Embedded resource '{resourceName}' not found.");
        using var reader = new StreamReader(stream);
        return reader.ReadToEnd();
    }

    private static string LoadScript(string fileName)
    {
        var resourceName = $"CloudGateway.Scripts.{fileName}";
        using var stream = Assembly.GetExecutingAssembly()
                               .GetManifestResourceStream(resourceName)
                           ?? throw new InvalidOperationException(
                               $"Embedded resource '{resourceName}' not found.");
        using var reader = new StreamReader(stream);
        return reader.ReadToEnd();
    }

    // ── Login page ────────────────────────────────────────────────────────────

    private static string BuildLoginHtml(string clientId, string tenantId, bool isProduction)
    {
        var template = LoadTemplate("login.html");

        var devNote = isProduction ? ""
            : "<div class=\"dev-note\">\u26a0 Development mode: authenticate /webchat via bypass Bearer token.</div>";

        var msalScriptTag = string.IsNullOrEmpty(clientId) ? ""
            : "<script src=\"https://alcdn.msauth.net/browser/2.35.0/js/msal-browser.min.js\" " +
              "integrity=\"sha384-PARf28kmic36Ve+O3DnUerRXFtOQ7ZDqRDGpLcbljly5/N39T2OV3kt3QsWOKeAX\" " +
              "crossorigin=\"anonymous\"></script>";

        string authScript;
        if (string.IsNullOrEmpty(clientId))
        {
            authScript = LoadTemplate("auth-fallback.js");
        }
        else
        {
            // Embed config as JSON strings to prevent injection.
            var safeClientId = JsonSerializer.Serialize(clientId);
            var safeTenantId = JsonSerializer.Serialize(tenantId);
            authScript = LoadTemplate("auth-msal.js")
                .Replace("{{CLIENT_ID_JSON}}", safeClientId)
                .Replace("{{TENANT_ID_JSON}}", safeTenantId);
        }

        return template
            .Replace("{{DEV_NOTE}}", devNote)
            .Replace("{{MSAL_SCRIPT_TAG}}", msalScriptTag)
            .Replace("{{AUTH_SCRIPT}}", authScript);
    }
}
