using System.Net;
using System.Reflection;
using System.Text.Json;
using CloudGateway.Helpers;
using CloudGateway.Services;

namespace CloudGateway.Endpoints;

/// <summary>
/// Admin dashboard: serves the SPA and relays API requests to the Python client.
/// All data flows through the /connect WSS relay — Cloud Gateway stores nothing.
/// </summary>
public static class AdminEndpoints
{
    public static IEndpointRouteBuilder MapAdminEndpoints(this IEndpointRouteBuilder app)
    {
        var adminHtml = LoadTemplate("portal.html");

        // ── SPA entry point ─────────────────────────────────────────────────
        app.MapGet("/portal", (HttpContext ctx) => ServeAdmin(ctx, adminHtml))
           .RequireAuthorization("AdminUser");
        app.MapGet("/portal/{**catchAll}", (HttpContext ctx) => ServeAdmin(ctx, adminHtml))
           .RequireAuthorization("AdminUser")
           .Add(ep => ((RouteEndpointBuilder)ep).Order = int.MaxValue); // lowest priority

        // ── Relay API ───────────────────────────────────────────────────────
        var api = app.MapGroup("/portal/api")
                     .RequireAuthorization("AdminUser");

        api.MapGet("/status",  (HttpContext ctx, IAdminRelay relay)
            => RelayGetAsync(ctx, relay, "/api/status"));
        api.MapGet("/health",  (HttpContext ctx, IAdminRelay relay)
            => RelayGetAsync(ctx, relay, "/api/health"));
        api.MapGet("/sessions",  (HttpContext ctx, IAdminRelay relay)
            => RelayGetAsync(ctx, relay, "/api/sessions"));
        api.MapGet("/sessions/{id}",  (string id, HttpContext ctx, IAdminRelay relay)
            => RelayGetAsync(ctx, relay, $"/api/sessions/{Uri.EscapeDataString(id)}"));
        api.MapGet("/tools",  (HttpContext ctx, IAdminRelay relay)
            => RelayGetAsync(ctx, relay, "/api/tools"));
        api.MapGet("/memory",  (HttpContext ctx, IAdminRelay relay)
            => RelayGetAsync(ctx, relay, "/api/memory"));
        api.MapGet("/audit",  (HttpContext ctx, IAdminRelay relay)
            => RelayGetAsync(ctx, relay, "/api/audit"));
        api.MapGet("/cost",  (HttpContext ctx, IAdminRelay relay)
            => RelayGetAsync(ctx, relay, "/api/cost"));
        api.MapGet("/config",  (HttpContext ctx, IAdminRelay relay)
            => RelayGetAsync(ctx, relay, "/api/config"));
        api.MapGet("/approvals",  (HttpContext ctx, IAdminRelay relay)
            => RelayGetAsync(ctx, relay, "/api/approvals"));

        api.MapPost("/estop",  (HttpContext ctx, IAdminRelay relay)
            => RelayPostAsync(ctx, relay, "/api/estop"));
        api.MapPost("/reset",  (HttpContext ctx, IAdminRelay relay)
            => RelayPostAsync(ctx, relay, "/api/reset"));
        api.MapPost("/approvals/{id}/resolve",  (string id, HttpContext ctx, IAdminRelay relay)
            => RelayPostAsync(ctx, relay, $"/api/approvals/{Uri.EscapeDataString(id)}/resolve"));

        return app;
    }

    private static IResult ServeAdmin(HttpContext ctx, string html)
    {
        var upn = ctx.User.GetUpn();
        var oid = ctx.User.GetOid() ?? "";
        // Use JSON-safe encoding for values injected into <script> context.
        // JsonSerializer.Serialize produces a quoted JSON string that is safe
        // inside JS (escapes ', ", </script>, \, etc.).  We strip the outer
        // quotes because the template already has them: upn: '{{UPN}}'.
        var safeUpn = JsonSerializer.Serialize(upn).Trim('"');
        var safeOid = JsonSerializer.Serialize(oid).Trim('"');
        var rendered = html
            .Replace("{{UPN}}", safeUpn)
            .Replace("{{OID}}", safeOid);
        return Results.Content(rendered, "text/html; charset=utf-8");
    }

    private static async Task<IResult> RelayGetAsync(
        HttpContext ctx, IAdminRelay relay, string endpoint)
    {
        var oid = ctx.User.GetOid();
        if (string.IsNullOrEmpty(oid)) return Results.Unauthorized();

        var (status, body) = await relay.SendAsync(oid, endpoint, ct: ctx.RequestAborted);
        return Results.Content(body, "application/json; charset=utf-8", statusCode: status);
    }

    private static async Task<IResult> RelayPostAsync(
        HttpContext ctx, IAdminRelay relay, string endpoint)
    {
        var oid = ctx.User.GetOid();
        if (string.IsNullOrEmpty(oid)) return Results.Unauthorized();

        using var reader = new StreamReader(ctx.Request.Body);
        var reqBody = await reader.ReadToEndAsync(ctx.RequestAborted);

        var (status, body) = await relay.SendAsync(
            oid, endpoint, "POST", reqBody, ctx.RequestAborted);
        return Results.Content(body, "application/json; charset=utf-8", statusCode: status);
    }

    private static string LoadTemplate(string fileName)
    {
        var resourceName = $"CloudGateway.Templates.{fileName}";
        using var stream = Assembly.GetExecutingAssembly()
                               .GetManifestResourceStream(resourceName)
                           ?? throw new InvalidOperationException(
                               $"Embedded resource '{resourceName}' not found.");
        using var reader = new StreamReader(stream);
        return reader.ReadToEnd();
    }
}
