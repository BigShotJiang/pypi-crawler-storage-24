namespace CloudGateway.Endpoints;

public static class HealthEndpoints
{
    private static readonly string Version =
        typeof(HealthEndpoints).Assembly.GetName().Version?.ToString(3) ?? "0.0.0";

    public static IEndpointRouteBuilder MapHealthEndpoints(this IEndpointRouteBuilder app)
    {
        // Liveness — always 200 while the process is alive. Never 503.
        app.MapGet("/health", () => Results.Ok(new { status = "ok", version = Version }))
           .AllowAnonymous()
           .WithName("Liveness");

        // Readiness — 200 once fully initialised; 503 only during startup.
        // Relay is stateless with no downstream dependencies to ping,
        // so this is effectively the same as liveness after startup.
        app.MapGet("/health/ready", () => Results.Ok(new
        {
            status    = "ready",
            version   = Version,
            timestamp = DateTimeOffset.UtcNow,
        })).AllowAnonymous()
           .WithName("Readiness");

        return app;
    }
}
