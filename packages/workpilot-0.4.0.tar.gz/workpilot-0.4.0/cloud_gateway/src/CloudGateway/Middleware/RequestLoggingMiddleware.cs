using System.Diagnostics;
using System.Security.Claims;

namespace CloudGateway.Middleware;

/// <summary>
/// Logs every HTTP request with method, path, status, duration, user OID, and correlation ID.
/// Message content is never logged (privacy — gateway is a stateless relay).
/// </summary>
public sealed class RequestLoggingMiddleware(
    RequestDelegate next,
    ILogger<RequestLoggingMiddleware> logger)
{
    public async Task InvokeAsync(HttpContext context)
    {
        var sw            = Stopwatch.StartNew();
        var correlationId = context.Items[CorrelationIdMiddleware.ItemsKey] as string ?? "-";

        await next(context);

        sw.Stop();

        var oid = context.User.FindFirstValue("oid") ?? "anon";

        logger.LogInformation(
            "{Method} {Path} -> {Status} ({Duration}ms) [oid={Oid}] [cid={CorrelationId}]",
            context.Request.Method,
            context.Request.Path.Value,
            context.Response.StatusCode,
            sw.ElapsedMilliseconds,
            oid,
            correlationId);
    }
}
