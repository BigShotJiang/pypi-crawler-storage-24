namespace CloudGateway.Middleware;

/// <summary>
/// Reads X-Correlation-ID from inbound requests; generates a new GUID if absent.
/// Echoes the value in the response header and stores it in HttpContext.Items
/// for downstream use (e.g. structured logging).
/// </summary>
public sealed class CorrelationIdMiddleware(RequestDelegate next)
{
    public const string Header   = "X-Correlation-ID";
    public const string ItemsKey = "CorrelationId";

    public async Task InvokeAsync(HttpContext context)
    {
        var correlationId = context.Request.Headers[Header].FirstOrDefault()
                            ?? Guid.NewGuid().ToString();

        context.Items[ItemsKey] = correlationId;
        context.Response.Headers[Header] = correlationId;

        await next(context);
    }
}
