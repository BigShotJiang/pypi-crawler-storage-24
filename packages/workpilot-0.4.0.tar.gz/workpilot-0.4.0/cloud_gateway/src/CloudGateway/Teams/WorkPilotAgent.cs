using System.Text.Json;
using CloudGateway.Config;
using CloudGateway.Models;
using CloudGateway.Services;
using Microsoft.Agents.Builder;
using Microsoft.Agents.Builder.App;
using Microsoft.Agents.Builder.State;
using Microsoft.Agents.Core.Models;
using Microsoft.Extensions.Options;

namespace CloudGateway.Teams;

/// <summary>
/// M365 Agents SDK agent that handles inbound Teams message activities.
/// Routes each message to the sender's connected WorkPilot client via IMessageDelivery.
/// Processing is fire-and-forget so the HTTP 202 response is returned immediately.
/// </summary>
public sealed class WorkPilotAgent : AgentApplication
{
    private readonly IMessageDelivery _delivery;
    private readonly IReplyContextStore _replyStore;
    private readonly IClientRegistry _registry;
    private readonly TeamsReplyService _teamsReply;
    private readonly RelayOptions _opts;
    private readonly ILogger<WorkPilotAgent> _logger;

    public WorkPilotAgent(
        AgentApplicationOptions options,
        IMessageDelivery delivery,
        IReplyContextStore replyStore,
        IClientRegistry registry,
        TeamsReplyService teamsReply,
        IOptions<RelayOptions> relayOpts,
        ILogger<WorkPilotAgent> logger)
        : base(options)
    {
        _delivery   = delivery;
        _replyStore = replyStore;
        _registry   = registry;
        _teamsReply = teamsReply;
        _opts       = relayOpts.Value;
        _logger     = logger;

        // Register handlers for messages and installation events.
        // Note: Action.Submit is used (not Action.Execute/UAM) for mobile Teams compatibility.
        OnActivity(ActivityTypes.Message,            HandleMessageAsync);
        OnActivity(ActivityTypes.ConversationUpdate, HandleInstallAsync);
    }

    private async Task HandleMessageAsync(
        ITurnContext ctx,
        ITurnState state,
        CancellationToken ct)
    {
        var activity = ctx.Activity;

        // Guard: routing requires Entra OID — guests/legacy accounts may not have it.
        var oid = activity.From?.AadObjectId;

        // DirectLine (Web Chat) activities set from.id = "dl_{oid}" but leave
        // aadObjectId null. Strip the "dl_" prefix to recover the Entra OID.
        // Validate with Guid.TryParse to reject malformed values (e.g. "dl_" alone).
        if (string.IsNullOrEmpty(oid) &&
            activity.From?.Id?.StartsWith("dl_", StringComparison.OrdinalIgnoreCase) == true)
        {
            var candidate = activity.From.Id[3..];
            if (Guid.TryParse(candidate, out _))
                oid = candidate;
        }

        if (string.IsNullOrEmpty(oid))
        {
            _logger.LogDebug(
                "Activity discarded: from.aadObjectId missing and from.id not in dl_{{oid}} format (from.id={FromId})",
                activity.From?.Id);
            return;
        }

        var channelId  = WireFrames.NewChannelId();
        var sessionKey = WireFrames.TeamsSessionKey(oid, activity.Conversation.Id);
        var tenantId   = ExtractTenantId(activity);

        // Store reply context so the client's outbound response can be routed back.
        _replyStore.Store(new ReplyContext
        {
            ChannelId      = channelId,
            OwnerOid       = oid,
            Source         = ReplySource.Teams,
            CreatedAt      = DateTimeOffset.UtcNow,
            ExpiresAt      = DateTimeOffset.UtcNow + _opts.ReplyContextTtl,
            ServiceUrl     = activity.ServiceUrl,
            ConversationId = activity.Conversation.Id,
            ActivityId     = activity.Id,
            FromId         = activity.From?.Id,
            TenantId       = tenantId,
        });

        // Extract Adaptive Card Action.Submit data (approval button clicks).
        // activity.Value is a JsonElement when a card action is submitted.
        string? approvalAction    = null;
        string? approvalRequestId = null;
        if (activity.Value is System.Text.Json.JsonElement valueEl &&
            valueEl.ValueKind == System.Text.Json.JsonValueKind.Object)
        {
            valueEl.TryGetProperty("approval_action",     out var aa);
            valueEl.TryGetProperty("approval_request_id", out var ar);
            approvalAction    = aa.ValueKind == System.Text.Json.JsonValueKind.Undefined ? null : aa.GetString();
            approvalRequestId = ar.ValueKind == System.Text.Json.JsonValueKind.Undefined ? null : ar.GetString();
        }

        // For card submits, use the action as the message content so _try_route_approval
        // can also match it as a text command if metadata routing is unavailable.
        var content = approvalAction is not null
            ? $"/{approvalAction} {approvalRequestId}"   // e.g. "/approve <id>"
            : activity.Text ?? string.Empty;

        var frame = new MessageFrame
        {
            ChannelId  = channelId,
            SenderId   = oid,
            SenderName = activity.From?.Name ?? oid,
            Content    = content,
            ThreadId   = activity.Conversation.Id,
            SessionKey = sessionKey,
            Timestamp  = DateTimeOffset.UtcNow.ToString("O"),
            Metadata   = new MessageMetadata
            {
                Source            = "cloud_teams",
                TenantId          = tenantId,
                ApprovalAction    = approvalAction,
                ApprovalRequestId = approvalRequestId,
            },
        };

        var online = _registry.IsOnline(oid);

        // If the user's WorkPilot client is not connected, send an immediate offline
        // notification so they know what to do — their message is still buffered.
        // Only for Teams activities: DirectLine/Web Chat handles offline via its own WebSocket error frame.
        if (!online)
        {
            var offlineCtx = _replyStore.GetUnchecked(channelId);
            if (offlineCtx?.Source == ReplySource.Teams)
            {
                var msg = BuildOfflineMessage(_opts.HomeUrl);
                _ = Task.Run(
                    async () =>
                    {
                        try
                        {
                            await _teamsReply.SendReplyAsync(msg, offlineCtx, CancellationToken.None);
                        }
                        catch (Exception ex)
                        {
                            _logger.LogError(
                                ex,
                                "Failed to send offline Teams notification channel_id={ChannelId} oid={Oid}",
                                channelId, oid);
                        }
                    },
                    CancellationToken.None);
            }
        }

        // Update the approval card in-place to show resolved state (no extra HTTP call needed
        // — ctx.UpdateActivityAsync runs within the current turn context).
        if (approvalAction is not null)
        {
            var label = approvalAction switch
            {
                "approve" => "✓ Approved",
                "deny"    => "✗ Denied",
                "always"  => "♾ Always allowed",
                _         => "Done",
            };
            var updatedCard = new Microsoft.Agents.Core.Models.Activity
            {
                Type = ActivityTypes.Message,
                Id   = activity.ReplyToId ?? activity.Id,
                Attachments = new System.Collections.Generic.List<Microsoft.Agents.Core.Models.Attachment>
                {
                    new()
                    {
                        ContentType = "application/vnd.microsoft.card.adaptive",
                        Content     = System.Text.Json.JsonSerializer.Deserialize<object>(
                            System.Text.Json.JsonSerializer.Serialize(new
                            {
                                schema  = "http://adaptivecards.io/schemas/adaptive-card.json",
                                type    = "AdaptiveCard",
                                version = "1.4",
                                body    = new object[]
                                {
                                    new { type = "TextBlock", text = "Tool Approval", weight = "Bolder", size = "Medium", isSubtle = true },
                                    new { type = "TextBlock", text = label, size = "Large",
                                          color = approvalAction == "deny" ? "Attention" : "Good" },
                                },
                            })),
                    }
                },
            };
            _ = Task.Run(
                async () =>
                {
                    try { await ctx.UpdateActivityAsync(updatedCard, CancellationToken.None); }
                    catch { /* best-effort — card update is cosmetic */ }
                },
                CancellationToken.None);
        }

        // Fire-and-forget: deliver to client without blocking the HTTP 202 response.
        _ = Task.Run(
            async () => await _delivery.DeliverAsync(oid, frame, CancellationToken.None),
            CancellationToken.None);

        _logger.LogInformation(
            "Teams activity queued channel_id={ChannelId} oid={Oid} online={Online}",
            channelId, oid, online);

        await Task.CompletedTask;
    }

    private async Task HandleInstallAsync(
        ITurnContext ctx,
        ITurnState state,
        CancellationToken ct)
    {
        // Send a welcome message when the bot is added to a conversation.
        var activity    = ctx.Activity;
        var membersAdded = activity.MembersAdded;
        if (membersAdded is null) return;

        var botId = activity.Recipient?.Id;
        var isBotAdded = membersAdded.Any(m => m.Id == botId);
        if (!isBotAdded) return;

        // Resolve the installing user's OID to check if their agent is already online.
        var userOid = activity.From?.AadObjectId;
        if (string.IsNullOrEmpty(userOid) &&
            activity.From?.Id?.StartsWith("dl_", StringComparison.OrdinalIgnoreCase) == true)
        {
            var candidate = activity.From.Id[3..];
            if (Guid.TryParse(candidate, out _)) userOid = candidate;
        }

        var isOnline = !string.IsNullOrEmpty(userOid) && _registry.IsOnline(userOid);
        var welcome  = isOnline
            ? BuildWelcomeOnlineMessage(_opts.HomeUrl)
            : BuildWelcomeOfflineMessage(_opts.HomeUrl);

        // Store a reply context so we can send back via Bot Connector.
        var channelId = WireFrames.NewChannelId();
        var tenantId  = ExtractTenantId(activity);
        _replyStore.Store(new ReplyContext
        {
            ChannelId      = channelId,
            OwnerOid       = userOid ?? "unknown",
            Source         = ReplySource.Teams,
            CreatedAt      = DateTimeOffset.UtcNow,
            ExpiresAt      = DateTimeOffset.UtcNow + _opts.ReplyContextTtl,
            ServiceUrl     = activity.ServiceUrl,
            ConversationId = activity.Conversation.Id,
            ActivityId     = activity.Id,
            TenantId       = tenantId,
        });

        var ctx2 = _replyStore.GetUnchecked(channelId);
        if (ctx2 is not null)
        {
            // Use a linked token so the send respects both turn cancellation and a
            // graceful-shutdown timeout, without blocking the 202 response.
            using var cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
            cts.CancelAfter(TimeSpan.FromSeconds(10));
            var linkedCt = cts.Token;
            _ = Task.Run(
                async () =>
                {
                    try { await _teamsReply.SendReplyAsync(welcome, ctx2, linkedCt); }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Failed to send Teams welcome message channel_id={ChannelId}", channelId);
                    }
                },
                CancellationToken.None);
        }
    }

    private static string BuildWelcomeOnlineMessage(string homeUrl)
    {
        var website = string.IsNullOrWhiteSpace(homeUrl) ? string.Empty
            : $" · 🌐 [Website]({homeUrl.TrimEnd('/')})";

        return $"""
            ✅ **WorkPilot is connected and ready!**

            Your local agent is online — just send a message to get started.

            **Commands:** `help` · `status`

            📂 [GitHub](https://github.com/gim-home/WorkPilot){website}
            """;
    }

    private static string BuildWelcomeOfflineMessage(string homeUrl)
    {
        var website = string.IsNullOrWhiteSpace(homeUrl) ? string.Empty
            : $"\n\n🌐 [Official Website]({homeUrl.TrimEnd('/')})";

        return $"""
            👋 **Welcome to WorkPilot!**

            WorkPilot is an autonomous AI assistant that codes, communicates, and ships across your entire Microsoft 365 environment — running entirely on your own machine.

            **Getting started**

            ```
            git clone https://github.com/gim-home/WorkPilot.git
            cd WorkPilot
            pip install -e ".[all]"
            workpilot init
            workpilot cloud
            ```

            Once `workpilot cloud` is running, your messages here will reach your local agent instantly.

            **Commands:** `help` · `status`{website}

            📂 [GitHub](https://github.com/gim-home/WorkPilot)
            """;
    }

    private static string BuildOfflineMessage(string homeUrl)
    {
        var links = "[GitHub](https://github.com/gim-home/WorkPilot)";
        if (!string.IsNullOrWhiteSpace(homeUrl))
            links = $"[Official Website]({homeUrl.TrimEnd('/')}) | " + links;

        return $"""
            ⚠️ **WorkPilot is not connected**

            Your local WorkPilot agent is currently offline. Install and run it to start chatting.

            **Quick start**

            ```
            git clone https://github.com/gim-home/WorkPilot.git
            cd WorkPilot
            pip install -e ".[all]"
            workpilot init
            workpilot cloud
            ```

            {links}

            *Your message has been queued and will be delivered once your agent comes online.*
            """;
    }

    private static string? ExtractTenantId(IActivity activity)
    {
        try
        {
            if (activity.ChannelData is JsonElement cd &&
                cd.TryGetProperty("tenant", out var tenant) &&
                tenant.TryGetProperty("id", out var tenantId))
                return tenantId.GetString();
        }
        catch { /* ignore */ }

        return null;
    }
}
