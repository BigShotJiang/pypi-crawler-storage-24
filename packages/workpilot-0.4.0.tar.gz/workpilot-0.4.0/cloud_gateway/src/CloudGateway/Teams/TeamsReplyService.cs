using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using Azure.Core;
using Azure.Identity;
using CloudGateway.Models;
using Microsoft.Extensions.Logging;

namespace CloudGateway.Teams;

/// <summary>
/// Sends replies to Teams conversations via the Bot Framework Connector REST API.
/// Authenticates using User-Assigned Managed Identity (no client secret).
///
/// In Development (IsDevelopment == true): skips the actual HTTP call and logs at DEBUG.
/// UAMI is only available on Azure App Service — not on a local developer machine.
/// </summary>
public sealed class TeamsReplyService
{
    private static readonly string[] _scopes = ["https://api.botframework.com/.default"];

    private readonly IHttpClientFactory _httpFactory;
    private readonly TokenCredential _credential;
    private readonly ILogger<TeamsReplyService> _logger;
    private readonly bool _devMode;

    public TeamsReplyService(
        IHttpClientFactory httpFactory,
        IConfiguration configuration,
        IWebHostEnvironment env,
        ILogger<TeamsReplyService> logger)
    {
        _httpFactory = httpFactory;
        _logger      = logger;
        _devMode     = env.IsDevelopment();

        // UAMI in production; DefaultAzureCredential falls back to developer credentials locally.
        var uamiClientId = configuration["MicrosoftAppId"];
        _credential = string.IsNullOrWhiteSpace(uamiClientId)
            ? new DefaultAzureCredential()
            : new ManagedIdentityCredential(
                ManagedIdentityId.FromUserAssignedClientId(uamiClientId));
    }

    /// <summary>
    /// Send a text reply to the originating Teams conversation.
    /// Called proactively — outside of an active ITurnContext.
    /// </summary>
    public async Task SendReplyAsync(
        string content,
        ReplyContext context,
        CancellationToken ct = default)
    {
        // In local development UAMI is unavailable (no Azure IMDS endpoint).
        // Skip the actual Bot Connector call to keep e2e tests clean.
        if (_devMode)
        {
            _logger.LogDebug(
                "[DEV] Teams reply skipped (UAMI unavailable locally) " +
                "channel_id={ChannelId} content_len={Len}",
                context.ChannelId, content.Length);
            return;
        }

        if (string.IsNullOrEmpty(context.ServiceUrl) ||
            string.IsNullOrEmpty(context.ConversationId))
        {
            _logger.LogWarning(
                "Teams reply skipped: missing ServiceUrl or ConversationId for channel_id={ChannelId}",
                context.ChannelId);
            return;
        }

        try
        {
            var tokenResult = await _credential.GetTokenAsync(
                new TokenRequestContext(_scopes), ct);

            var client = _httpFactory.CreateClient("BotConnector");
            client.DefaultRequestHeaders.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue(
                    "Bearer", tokenResult.Token);

            var serviceUrl = context.ServiceUrl.TrimEnd('/');
            var url        = $"{serviceUrl}/v3/conversations/{Uri.EscapeDataString(context.ConversationId)}/activities";

            if (!string.IsNullOrEmpty(context.ActivityId))
                url += $"/{Uri.EscapeDataString(context.ActivityId)}";

            // If content is a Bot Framework activity JSON (e.g. Adaptive Card from Python
            // TeamsApprovalFormatter), send it as-is; otherwise wrap as plain text.
            object reply;
            if (TryParseActivity(content, out var parsedActivity))
            {
                // Inject replyToId so Teams threads the reply correctly.
                if (!string.IsNullOrEmpty(context.ActivityId) && parsedActivity is not null)
                    parsedActivity["replyToId"] = context.ActivityId;
                reply = parsedActivity!;
            }
            else
            {
                reply = new BotReplyActivity
                {
                    Type      = "message",
                    Text      = content,
                    ReplyToId = context.ActivityId,
                };
            }

            var response = await client.PostAsJsonAsync(url, reply, ct);

            if (!response.IsSuccessStatusCode)
            {
                var body = await response.Content.ReadAsStringAsync(ct);
                _logger.LogWarning(
                    "Teams reply failed: {Status} {Body} channel_id={ChannelId}",
                    response.StatusCode, body, context.ChannelId);
            }
            else
            {
                _logger.LogDebug(
                    "Teams reply sent channel_id={ChannelId}", context.ChannelId);
            }
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            _logger.LogError(ex,
                "Teams reply error channel_id={ChannelId}", context.ChannelId);
        }
    }

    /// <summary>
    /// Update the original Adaptive Card in-place to show the resolved state.
    /// Uses a PUT to the activity URL (Teams card update pattern).
    /// </summary>
    public async Task SendCardUpdateAsync(
        string resolvedLabel,
        ReplyContext context,
        CancellationToken ct = default)
    {
        if (_devMode) { _logger.LogDebug("[DEV] Card update skipped channel_id={ChannelId}", context.ChannelId); return; }
        if (string.IsNullOrEmpty(context.ServiceUrl) || string.IsNullOrEmpty(context.ConversationId) || string.IsNullOrEmpty(context.ActivityId)) return;

        try
        {
            var tokenResult = await _credential.GetTokenAsync(new TokenRequestContext(_scopes), ct);
            var client = _httpFactory.CreateClient("BotConnector");
            client.DefaultRequestHeaders.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", tokenResult.Token);

            // PUT to update the existing activity (card) in-place
            var url = $"{context.ServiceUrl.TrimEnd('/')}/v3/conversations/{Uri.EscapeDataString(context.ConversationId)}/activities/{Uri.EscapeDataString(context.ActivityId)}";

            // Resolved card: no buttons, just a status TextBlock
            var updatedCard = new
            {
                type        = "message",
                id          = context.ActivityId,
                replyToId   = context.ActivityId,
                attachments = new[]
                {
                    new
                    {
                        contentType = "application/vnd.microsoft.card.adaptive",
                        content     = new
                        {
                            schema  = "http://adaptivecards.io/schemas/adaptive-card.json",
                            type    = "AdaptiveCard",
                            version = "1.4",
                            body    = new object[]
                            {
                                new { type = "TextBlock", text = $"Approval — {resolvedLabel}", weight = "Bolder", size = "Medium" },
                                new { type = "TextBlock", text = resolvedLabel, color = resolvedLabel.Contains("Denied") ? "Attention" : "Good", size = "Large" },
                            }
                        }
                    }
                }
            };

            var response = await client.PutAsJsonAsync(url, updatedCard, ct);
            _logger.LogDebug("Card update {Status} channel_id={ChannelId}", response.StatusCode, context.ChannelId);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            _logger.LogDebug(ex, "Card update failed channel_id={ChannelId}", context.ChannelId);
        }
    }

    /// <summary>
    /// Send a typing indicator to the originating Teams conversation.
    /// Teams displays "WorkPilot is typing..." while the agent processes.
    /// </summary>
    public async Task SendTypingAsync(
        ReplyContext context,
        CancellationToken ct = default)
    {
        if (_devMode)
        {
            _logger.LogDebug(
                "[DEV] Teams typing skipped (UAMI unavailable locally) " +
                "channel_id={ChannelId}", context.ChannelId);
            return;
        }

        if (string.IsNullOrEmpty(context.ServiceUrl) ||
            string.IsNullOrEmpty(context.ConversationId))
        {
            _logger.LogWarning(
                "Teams typing skipped: missing ServiceUrl or ConversationId for channel_id={ChannelId}",
                context.ChannelId);
            return;
        }

        try
        {
            var tokenResult = await _credential.GetTokenAsync(
                new TokenRequestContext(_scopes), ct);

            var client = _httpFactory.CreateClient("BotConnector");
            client.DefaultRequestHeaders.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue(
                    "Bearer", tokenResult.Token);

            var serviceUrl = context.ServiceUrl.TrimEnd('/');
            var url        = $"{serviceUrl}/v3/conversations/{Uri.EscapeDataString(context.ConversationId)}/activities";

            var activity = new BotTypingActivity();
            var response = await client.PostAsJsonAsync(url, activity, ct);

            if (!response.IsSuccessStatusCode)
            {
                var body = await response.Content.ReadAsStringAsync(ct);
                _logger.LogDebug(
                    "Teams typing failed: {Status} {Body} channel_id={ChannelId}",
                    response.StatusCode, body, context.ChannelId);
            }
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            _logger.LogDebug(ex,
                "Teams typing error channel_id={ChannelId}", context.ChannelId);
        }
    }

    /// <summary>
    /// Try to parse <paramref name="content"/> as a Bot Framework activity JSON object.
    /// Handles two cases:
    /// - <c>"type":"message"</c> with <c>"attachments"</c> (TeamsApprovalFormatter output) → send as-is
    /// - <c>"type":"approval_request"</c> (CloudApprovalFormatter output) → convert to Adaptive Card
    /// Returns <c>true</c> and sets <paramref name="activity"/> when structured.
    /// </summary>
    private static bool TryParseActivity(
        string content,
        out System.Collections.Generic.Dictionary<string, object?>? activity)
    {
        activity = null;
        if (string.IsNullOrWhiteSpace(content) || content[0] != '{')
            return false;
        try
        {
            var doc  = JsonDocument.Parse(content);
            var root = doc.RootElement;
            if (root.ValueKind != JsonValueKind.Object)
                return false;

            if (!root.TryGetProperty("type", out var typeEl))
                return false;

            var msgType = typeEl.GetString();

            // Case 1: already a Bot Framework activity with attachments
            if (msgType == "message" &&
                root.TryGetProperty("attachments", out var attEl) &&
                attEl.ValueKind == JsonValueKind.Array)
            {
                activity = JsonSerializer.Deserialize
                    <System.Collections.Generic.Dictionary<string, object?>>(content);
                return activity is not null;
            }

            // Case 2: CloudApprovalFormatter → build Adaptive Card on-the-fly
            if (msgType == "approval_request")
            {
                var requestId = root.TryGetProperty("request_id", out var rid) ? rid.GetString() : "";
                var toolName  = root.TryGetProperty("tool_name",  out var tn)  ? tn.GetString()  : "tool";
                var risk      = root.TryGetProperty("risk",       out var rk)  ? rk.GetString()  : "medium";
                var reason    = root.TryGetProperty("reason",     out var rs)  ? rs.GetString()  : "";

                var card = new
                {
                    type             = "message",
                    attachments      = new[]
                    {
                        new
                        {
                            contentType = "application/vnd.microsoft.card.adaptive",
                            content     = new
                            {
                                schema  = "http://adaptivecards.io/schemas/adaptive-card.json",
                                type    = "AdaptiveCard",
                                version = "1.4",
                                body    = new object[]
                                {
                                    new { type = "TextBlock", text = "Tool Approval Required", weight = "Bolder", size = "Medium" },
                                    new { type = "FactSet", facts = new[]
                                    {
                                        new { title = "Tool",   value = toolName },
                                        new { title = "Risk",   value = risk     },
                                        new { title = "Reason", value = reason   },
                                        new { title = "ID",     value = requestId?[..Math.Min(12, requestId?.Length ?? 0)] + "…" },
                                    }},
                                    new { type = "TextBlock", text = "Or reply **yes** / **no** / **always** if buttons are unavailable.", isSubtle = true, size = "Small", wrap = true },
                                },
                                // Action.Submit — works reliably on desktop AND mobile.
                                // Action.Execute (UAM) has known mobile compatibility issues
                                // (GitHub microsoft/AdaptiveCards#9315, msteams-docs#13924).
                                // Card is updated via ctx.UpdateActivityAsync() in HandleMessageAsync.
                                actions = new object[]
                                {
                                    new { type = "Action.Submit", title = "Approve",      data = new { approval_action = "approve", approval_request_id = requestId } },
                                    new { type = "Action.Submit", title = "Deny",          data = new { approval_action = "deny",    approval_request_id = requestId } },
                                    new { type = "Action.Submit", title = "Always Allow",  data = new { approval_action = "always",  approval_request_id = requestId } },
                                },
                            }
                        }
                    }
                };

                var json     = JsonSerializer.Serialize(card);
                activity     = JsonSerializer.Deserialize
                    <System.Collections.Generic.Dictionary<string, object?>>(json);
                return activity is not null;
            }

            return false;
        }
        catch
        {
            return false;
        }
    }

    // Minimal Bot Connector activity payload for replies
    private sealed record BotReplyActivity
    {
        [JsonPropertyName("type")]      public string Type      { get; init; } = "message";
        [JsonPropertyName("text")]      public string Text      { get; init; } = string.Empty;
        [JsonPropertyName("replyToId")] public string? ReplyToId { get; init; }
    }

    private sealed record BotTypingActivity
    {
        [JsonPropertyName("type")] public string Type { get; init; } = "typing";
    }
}
