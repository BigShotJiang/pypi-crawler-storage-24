using System.Text.Json;
using System.Text.Json.Serialization;

namespace CloudGateway.Models;

// ── Shared JSON options ──────────────────────────────────────────────────────

public static class WireJson
{
    public static readonly JsonSerializerOptions Options = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower,
        PropertyNameCaseInsensitive = true,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
    };
}

// ── Frame type constants ─────────────────────────────────────────────────────

public static class FrameType
{
    public const string Message        = "message";
    public const string Response       = "response";
    public const string Chunk          = "chunk";
    public const string Connected      = "connected";
    public const string BufferedStart  = "buffered_start";
    public const string BufferedEnd    = "buffered_end";
    public const string Ping           = "ping";
    public const string Pong           = "pong";
    public const string Error          = "error";
    public const string Typing         = "typing";
    public const string AdminRequest   = "admin_request";
    public const string AdminResponse  = "admin_response";
}

// ── Error codes ──────────────────────────────────────────────────────────────

public static class ErrorCode
{
    public const string ReplyContextExpired = "reply_context_expired";
    public const string ResponseTimeout     = "response_timeout";
    public const string RateLimited         = "rate_limited";
    public const string AuthExpired         = "auth_expired";
    public const string AgentOffline        = "agent_offline";
    public const string ServerError         = "server_error";
}

// ── Chunk types ──────────────────────────────────────────────────────────────

public static class ChunkType
{
    public const string Token        = "token";
    public const string ToolProgress = "tool_progress";
    public const string Status       = "status";
}

// ── Wire frame records ───────────────────────────────────────────────────────

/// <summary>
/// Server → Client (/connect): relay an inbound message to the Agent Loop.
/// session_key format: "cloud_teams:{oid}:{conversation_id}" or
///                     "cloud_webchat:{upn}:wc_{full-oid}"
/// channel_id format:  "cid_{Guid.NewGuid()}"
/// </summary>
public sealed record MessageFrame
{
    public string Type       { get; init; } = FrameType.Message;
    public string Channel    { get; init; } = "cloud";
    public required string ChannelId   { get; init; }
    public required string SenderId    { get; init; }
    public required string SenderName  { get; init; }
    public required string Content     { get; init; }
    public required string ThreadId    { get; init; }
    public required string SessionKey  { get; init; }
    public required string Timestamp   { get; init; }
    public required MessageMetadata Metadata { get; init; }
}

public sealed record MessageMetadata
{
    public required string Source   { get; init; }  // "cloud_teams" | "cloud_webchat"
    public string? TenantId { get; init; }

    // Adaptive Card Action.Submit payload — populated when a card button is clicked
    [JsonPropertyName("approval_action")]
    public string? ApprovalAction    { get; init; }  // "approve" | "deny" | "always"

    [JsonPropertyName("approval_request_id")]
    public string? ApprovalRequestId { get; init; }
}

/// <summary>Client → Server (/connect): relay response back to source channel.</summary>
public sealed record ResponseFrame
{
    public string Type      { get; init; } = FrameType.Response;
    public required string ChannelId  { get; init; }
    public required string Content    { get; init; }
    public string? ThreadId  { get; init; }
    public string Format    { get; init; } = "markdown";
}

/// <summary>Client → Server (/connect): relay a streaming chunk back to source.</summary>
public sealed record ChunkFrame
{
    public string Type       { get; init; } = FrameType.Chunk;
    public required string ChannelId  { get; init; }
    public required string Content    { get; init; }

    /// <summary>Wire field name is "chunk_type" per the protocol spec.</summary>
    [JsonPropertyName("chunk_type")]
    public required string ChunkTypeValue { get; init; }

    public required bool   Done       { get; init; }
}

/// <summary>Server → Client (/connect): connection acknowledged.</summary>
public sealed record ConnectedFrame
{
    public string Type          { get; init; } = FrameType.Connected;
    public required int BufferedCount { get; init; }
}

/// <summary>Server → Browser (/webchat): connection acknowledged with deterministic thread_id.</summary>
public sealed record ConnectedBrowserFrame
{
    public string Type          { get; init; } = FrameType.Connected;
    public required string ThreadId      { get; init; }
    public required int    BufferedCount { get; init; }
}

/// <summary>Server → Client: start of buffered message delivery sequence.</summary>
public sealed record BufferedStartFrame
{
    public string Type  { get; init; } = FrameType.BufferedStart;
    public required int Count { get; init; }
}

/// <summary>Server → Client: end of buffered message delivery sequence.</summary>
public sealed record BufferedEndFrame
{
    public string Type { get; init; } = FrameType.BufferedEnd;
}

/// <summary>Server → Client: heartbeat ping. Client must reply with pong within 10 s.</summary>
public sealed record PingFrame
{
    public string Type { get; init; } = FrameType.Ping;
}

/// <summary>Client → Server: heartbeat pong reply.</summary>
public sealed record PongFrame
{
    public string Type { get; init; } = FrameType.Pong;
}

/// <summary>Client → Server (/connect): relay typing indicator to source channel.</summary>
public sealed record TypingFrame
{
    public string Type       { get; init; } = FrameType.Typing;
    public required string ChannelId  { get; init; }
}

/// <summary>Server → Client (/connect): admin data query relayed to Python client.</summary>
public sealed record AdminRequestFrame
{
    public string Type       { get; init; } = FrameType.AdminRequest;
    public required string RequestId  { get; init; }
    public required string Endpoint   { get; init; }
    public string Method              { get; init; } = "GET";
    public string? Body               { get; init; }
}

/// <summary>Client → Server (/connect): admin data response from Python client.</summary>
public sealed record AdminResponseFrame
{
    public string Type       { get; init; } = FrameType.AdminResponse;
    public required string RequestId  { get; init; }
    public required int    Status     { get; init; }
    public required string Body       { get; init; }
}

/// <summary>Server → Client or Server → Browser: error notification.</summary>
public sealed record ErrorFrame
{
    public string Type      { get; init; } = FrameType.Error;
    public required string Code     { get; init; }
    public string? ChannelId { get; init; }
    public required string Message  { get; init; }
}

// ── Factory helpers ──────────────────────────────────────────────────────────

public static class WireFrames
{
    /// <summary>Generate a new opaque channel routing key: cid_{uuid}.</summary>
    public static string NewChannelId() => $"cid_{Guid.NewGuid()}";

    /// <summary>
    /// Compute the deterministic Web Chat thread_id for a user:
    /// "wc_{full-oid-with-dashes}"
    /// </summary>
    public static string WebChatThreadId(string oid) => $"wc_{oid}";

    /// <summary>Compute the Teams session key.</summary>
    public static string TeamsSessionKey(string oid, string conversationId)
        => $"cloud_teams:{oid}:{conversationId}";

    /// <summary>Compute the Web Chat session key.</summary>
    public static string WebChatSessionKey(string upn, string oid)
        => $"cloud_webchat:{upn}:wc_{oid}";

    public static string Serialize<T>(T frame)
        => JsonSerializer.Serialize(frame, WireJson.Options);

    public static T? Deserialize<T>(string json)
        => JsonSerializer.Deserialize<T>(json, WireJson.Options);

    public static T? Deserialize<T>(ReadOnlySpan<byte> bytes)
        => JsonSerializer.Deserialize<T>(bytes, WireJson.Options);
}
