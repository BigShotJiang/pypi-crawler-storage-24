"""
Config loader — YAML with environment variable substitution,
profile support, and config inheritance via `extends`.
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any

import yaml

from workpilot.config.schema import AppConfig

_ENV_PATTERN = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")
_SEARCH_NAMES = ("workpilot.yaml", "workpilot.yml", "config.yaml", "config.yml")


def _substitute_env(value: str, env: dict[str, str]) -> str:
    """Replace ${VAR} placeholders with environment values."""

    def _replace(m: re.Match[str]) -> str:
        return env.get(m.group(1), "")

    return _ENV_PATTERN.sub(_replace, value)


def _deep_substitute(obj: Any, env: dict[str, str]) -> Any:
    if isinstance(obj, str):
        return _substitute_env(obj, env)
    if isinstance(obj, dict):
        return {k: _deep_substitute(v, env) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_deep_substitute(v, env) for v in obj]
    return obj


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    """Recursively merge override into base."""
    result = {**base}
    for key, value in override.items():
        if isinstance(value, dict) and key in result and isinstance(result[key], dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def _load_yaml(path: Path) -> dict[str, Any]:
    text = path.read_text(encoding="utf-8")
    return yaml.safe_load(text) or {}


def _resolve_config_file(config_path: Path) -> Path | None:
    """Find the config file at the given path or in directory."""
    if config_path.is_file():
        return config_path
    if config_path.is_dir():
        for name in _SEARCH_NAMES:
            candidate = config_path / name
            if candidate.is_file():
                return candidate
    return None


def _load_dotenv(directory: Path, env: dict[str, str]) -> None:
    """Read a .env file into *env* (existing keys take priority).

    Values are loaded into the substitution dict only — ``os.environ`` is
    never modified.  A future version will support encrypted .env files.
    """
    dotenv = directory / ".env"
    if not dotenv.is_file():
        return
    for line in dotenv.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip().strip("\"'")
        env.setdefault(key, value)


def _resolve_local_override(config_file: Path) -> Path | None:
    """Derive the .local.yaml sibling for a config file and return it if it exists.

    workpilot.yaml  -> workpilot.local.yaml
    config.yml      -> config.local.yml
    """
    stem = config_file.stem  # e.g. "workpilot"
    suffix = config_file.suffix  # e.g. ".yaml"
    local_name = f"{stem}.local{suffix}"
    local_path = config_file.parent / local_name
    return local_path if local_path.is_file() else None


def load_config(
    config_path: str | Path | None = None,
    profile: str | None = None,
) -> AppConfig:
    """
    Load and validate WorkPilot configuration.

    1. Resolve config file path
    2. Process `extends` (config inheritance)
    3. Apply `profiles` (environment overrides)
    4. Substitute environment variables
    5. Validate with Pydantic
    """
    path = Path(config_path) if config_path else Path(".")
    resolved = _resolve_config_file(path)

    if resolved is None:
        # No config file — use defaults
        return AppConfig()

    raw = _load_yaml(resolved)
    config_dir = resolved.parent

    # Process extends
    extends = raw.pop("extends", None)
    if isinstance(extends, list):
        for parent_path in extends:
            parent_file = _resolve_config_file(config_dir / parent_path)
            if parent_file:
                parent_raw = _load_yaml(parent_file)
                raw = _deep_merge(parent_raw, raw)

    # Merge local override (e.g. workpilot.local.yaml next to workpilot.yaml)
    local_file = _resolve_local_override(resolved)
    if local_file is not None:
        local_raw = _load_yaml(local_file)
        raw = _deep_merge(raw, local_raw)

    # Apply profile
    profiles = raw.pop("profiles", None)
    if profile and isinstance(profiles, dict) and profile in profiles:
        raw = _deep_merge(raw, profiles[profile])

    # Environment variable substitution
    # Sources (lowest → highest priority): .env file, os.environ, config env section.
    # Nothing is written to os.environ — the env dict is local only.
    # TODO: support encrypted .env files (AES / age / SOPS)
    env: dict[str, str] = {}
    _load_dotenv(config_dir, env)
    env.update(os.environ)
    # Also extract env defaults from config
    config_env = raw.get("env", {})
    if isinstance(config_env, dict):
        for key, val in config_env.items():
            if isinstance(val, str):
                env.setdefault(key, val)
            elif isinstance(val, dict) and "default" in val:
                env.setdefault(key, val["default"])
    raw = _deep_substitute(raw, env)

    # Remove env section (not part of AppConfig)
    raw.pop("env", None)

    return AppConfig.model_validate(raw)
