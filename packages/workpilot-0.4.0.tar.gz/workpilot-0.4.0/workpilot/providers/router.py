"""
Provider router — resolves "auto" model selection and maps provider
credentials to OpenAI SDK kwargs.

Secrets are read from config (primary) or environment (fallback) and
passed as arguments to SDK clients — never written to ``os.environ``.
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from workpilot.providers.openai_provider import OpenAIProvider

from loguru import logger
from pydantic import SecretStr

from workpilot.config.schema import ProvidersConfig

_FALLBACK_MODEL = "openai/gpt-4o"


# ── helpers ──────────────────────────────────────────────────────────────────


def _secret(value: SecretStr | None) -> str | None:
    """Unwrap a SecretStr, returning *None* for empty / missing values."""
    if value is None:
        return None
    plain = value.get_secret_value()
    return plain if plain else None


def _secret_or_env(value: SecretStr | None, *env_names: str) -> str | None:
    """Return the config value if set, otherwise fall back to env vars.

    This lets users export keys directly in their shell without adding
    them to the YAML config.  We only *read* ``os.environ`` — we never
    write to it.
    """
    result = _secret(value)
    if result:
        return result
    for name in env_names:
        result = os.environ.get(name)
        if result:
            return result
    return None


# ── auto-resolution ──────────────────────────────────────────────────────────

# Each entry: (check_fn, model_or_fn, label)
# - check_fn(p)    → truthy when provider is configured
# - model_or_fn    → concrete model string, OR callable(p) → str for dynamic selection
# check_fn / model_or_fn both receive ProvidersConfig.


def _openai_configured(p: ProvidersConfig) -> bool:
    """True when an OpenAI-compatible API key is available (config or env)."""
    return bool(
        _secret_or_env(
            p.openai.api_key,
            "OPENAI_API_KEY",
            "AZURE_API_KEY",
            "AZURE_OPENAI_API_KEY",
            "AZURE_AI_FOUNDRY_API_KEY",
        )
    )


def _resolve_endpoint(p: ProvidersConfig) -> str:
    """Return the configured endpoint, checking config then all known env vars."""
    return (
        p.openai.endpoint
        or os.environ.get("OPENAI_ENDPOINT", "")
        or os.environ.get("AZURE_OPENAI_ENDPOINT", "")
        or os.environ.get("AZURE_AI_FOUNDRY_ENDPOINT", "")
    )


def _openai_model(p: ProvidersConfig) -> str:
    """Return the appropriate model prefix based on the configured endpoint.

    no endpoint          → openai/gpt-4o   (OpenAI direct)
    *.openai.azure.com   → azure/gpt-4o    (Azure OpenAI Service)
    anything else        → azure_ai/gpt-4o (Azure AI Foundry / custom)
    """
    endpoint = _resolve_endpoint(p)
    if not endpoint:
        return "openai/gpt-4o"
    if ".openai.azure.com" in endpoint:
        return "azure/gpt-4o"
    return "azure_ai/gpt-4o"


# Known aliases that get special resolution
_ALIASES = frozenset({"auto", "fast", "reasoning", "coding"})


def _openai_fast_model(p: ProvidersConfig) -> str:
    """Fast variant of the configured OpenAI-compatible endpoint."""
    endpoint = _resolve_endpoint(p)
    if not endpoint:
        return "openai/gpt-4o-mini"
    if ".openai.azure.com" in endpoint:
        return "azure/gpt-4o-mini"
    return "azure_ai/gpt-4o-mini"


def _openai_reasoning_model(p: ProvidersConfig) -> str:
    """Reasoning variant of the configured OpenAI-compatible endpoint."""
    endpoint = _resolve_endpoint(p)
    if not endpoint:
        return "openai/o1"
    if ".openai.azure.com" in endpoint:
        return "azure/o1"
    return "azure_ai/o1"


def _github_configured(p: ProvidersConfig) -> bool:
    return bool(_secret_or_env(p.github_copilot.token, "GITHUB_TOKEN"))


def _resolve_routing_candidate(
    entry: str,
    providers: ProvidersConfig,
    *,
    require_credentials_for_concrete: bool = True,
) -> str | None:
    """Resolve a configured candidate entry into a concrete model ID."""
    value = entry.strip()
    if not value:
        return None

    lowered = value.lower()
    if lowered == "openai:auto":
        return _openai_model(providers) if _openai_configured(providers) else None
    if lowered == "openai:fast":
        return _openai_fast_model(providers) if _openai_configured(providers) else None
    if lowered == "openai:reasoning":
        return _openai_reasoning_model(providers) if _openai_configured(providers) else None

    if value.startswith("github/"):
        if require_credentials_for_concrete:
            return value if _github_configured(providers) else None
        return value
    if value.startswith(("openai/", "azure/", "azure_ai/")):
        if require_credentials_for_concrete:
            return value if _openai_configured(providers) else None
        return value

    return value


def resolve_model_chain(model: str, providers: ProvidersConfig | None = None) -> list[str]:
    """Resolve a model/alias into ordered concrete candidates.

    The first entry is the preferred model. Remaining entries are ordered
    failover candidates for runtime fallback.
    """
    if model not in _ALIASES:
        return [model]

    if providers is None:
        logger.warning(
            "No provider config found for '{}' resolution; no fallback candidates available",
            model,
        )
        return []

    candidates: list[str] = []

    def _append_unique(value: str) -> None:
        if value and value not in candidates:
            candidates.append(value)

    def _expand(entries: list[str]) -> None:
        for entry in entries:
            resolved = _resolve_routing_candidate(entry, providers)
            if resolved:
                _append_unique(resolved)

    # Check user-configured alias mapping first.
    alias_map = {
        "auto": providers.aliases.default,
        "fast": providers.aliases.fast,
        "reasoning": providers.aliases.reasoning,
        "coding": providers.aliases.coding,
    }
    configured: Any = alias_map.get(model, "auto")
    has_alias_override = False

    def _expand_alias_item(item: str) -> None:
        # "auto" inside a list means: expand this alias' default routing candidates.
        if item == "auto":
            if model == "fast":
                _expand(providers.routing.fast_candidates)
            elif model == "reasoning":
                _expand(providers.routing.reasoning_candidates)
            else:
                _expand(providers.routing.default_candidates)
            return

        if item in _ALIASES:
            if item == model:
                return
            for entry in resolve_model_chain(item, providers):
                _append_unique(entry)
            return

        resolved = _resolve_routing_candidate(
            item,
            providers,
            require_credentials_for_concrete=False,
        )
        if resolved:
            _append_unique(resolved)

    if isinstance(configured, list):
        has_alias_override = True
        logger.info("Alias '{}' resolved via configured candidate list", model)
        for item in configured:
            if isinstance(item, str):
                _expand_alias_item(item)
    elif configured != "auto":
        has_alias_override = True
        logger.info("Alias '{}' resolved to '{}' via config", model, configured)
        if configured in _ALIASES:
            if configured != model:
                for entry in resolve_model_chain(configured, providers):
                    _append_unique(entry)
        else:
            resolved = _resolve_routing_candidate(
                str(configured),
                providers,
                require_credentials_for_concrete=False,
            )
            if resolved:
                _append_unique(resolved)

    # Alias-specific auto-resolution candidates
    if not has_alias_override:
        if model == "fast":
            _expand(providers.routing.fast_candidates)
        elif model == "reasoning":
            _expand(providers.routing.reasoning_candidates)
        elif model in ("coding", "auto"):
            _expand(providers.routing.default_candidates)

    # For auto/coding we already expanded default candidates above.
    # Keep fast/reasoning chains scoped to their tier, then add only
    # the ultimate fallback model below.

    # Only add OpenAI fallback when an OpenAI-compatible key is configured.
    # Derive the fallback from the configured endpoint so Azure/Foundry users
    # get the right client type (azure/* or azure_ai/*) rather than openai/*.
    if _openai_configured(providers):
        _append_unique(_openai_model(providers))
    elif not candidates:
        logger.warning(
            "No provider credentials found for '{}' resolution and OpenAI key is not configured",
            model,
        )

    return candidates


def resolve_model(model: str, providers: ProvidersConfig | None = None) -> str:
    """Resolve model aliases to the preferred concrete model ID."""
    chain = resolve_model_chain(model, providers)
    if not chain:
        raise ValueError(f"No configured provider credentials available to resolve alias '{model}'")
    return chain[0]


# ── credential resolution ────────────────────────────────────────────────────


def resolve_credentials(model: str, providers: ProvidersConfig) -> dict[str, Any]:
    """Return litellm kwargs (``api_key``, ``api_base``, …) for *model*.

    Config values take priority; environment variables are a read-only
    fallback.  Nothing is written to ``os.environ``.
    """
    kwargs: dict[str, Any] = {}

    if model.startswith("github/"):
        # The device-flow OAuth token has Copilot access, not GitHub Models
        # access.  Exchange it for a Copilot session token and route through
        # the Copilot API (OpenAI-compatible).
        github_token = _secret_or_env(providers.github_copilot.token, "GITHUB_TOKEN")
        if github_token:
            from workpilot.security.github_auth import (
                _COPILOT_HEADERS,
                get_copilot_api_base,
                get_copilot_token,
            )

            kwargs["api_key"] = get_copilot_token(github_token)
            kwargs["api_base"] = get_copilot_api_base()
            kwargs["extra_headers"] = _COPILOT_HEADERS

    elif model.startswith(("openai/", "azure/", "azure_ai/")):
        key = _secret_or_env(
            providers.openai.api_key,
            "OPENAI_API_KEY",
            "AZURE_API_KEY",
            "AZURE_OPENAI_API_KEY",
            "AZURE_AI_FOUNDRY_API_KEY",
        )
        if key:
            kwargs["api_key"] = key
        endpoint = _resolve_endpoint(providers)
        if endpoint:
            kwargs["api_base"] = endpoint
        if providers.openai.api_version and model.startswith(("azure/", "azure_ai/")):
            kwargs["api_version"] = providers.openai.api_version

    return kwargs


# ── factory ──────────────────────────────────────────────────────────────────


def get_provider(providers: ProvidersConfig | None = None) -> OpenAIProvider:
    """Create and return a configured OpenAI-compatible provider."""
    from workpilot.providers.openai_provider import OpenAIProvider

    return OpenAIProvider(providers=providers)
