"""
OpenAI-compatible unified provider.

Supports GitHub Copilot and OpenAI-compatible endpoints (OpenAI/Azure OpenAI)
without depending on LiteLLM.
"""

from __future__ import annotations

import json
import time
from collections.abc import AsyncIterator
from typing import Any

from loguru import logger

from workpilot.config.schema import ProvidersConfig
from workpilot.providers.base import LLMChunk, LLMProvider, LLMResponse, ToolCallRequest
from workpilot.providers.router import resolve_credentials, resolve_model_chain

# Models that should use Responses API by default.
_RESPONSES_API_MODELS = frozenset({"gpt-5.4"})


def _sanitize_messages(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Sanitize messages for OpenAI-compatible APIs."""
    out = []
    for msg in messages:
        msg = dict(msg)

        if "content" not in msg or msg["content"] is None:
            msg["content"] = ""

        if "tool_calls" in msg and msg["tool_calls"]:
            fixed_calls = []
            for tc in msg["tool_calls"]:
                tc = dict(tc)
                if "function" in tc:
                    fn = dict(tc["function"])
                    if isinstance(fn.get("arguments"), dict):
                        fn["arguments"] = json.dumps(fn["arguments"])
                    tc["function"] = fn
                fixed_calls.append(tc)
            msg["tool_calls"] = fixed_calls

        out.append(msg)
    return out


def _api_model_name(resolved_model: str) -> str:
    for prefix in ("github/", "openai/", "azure/", "azure_ai/"):
        if resolved_model.startswith(prefix):
            return resolved_model.removeprefix(prefix)
    return resolved_model


def _responses_input(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Convert chat-style messages to Responses API input items.

    Tool messages become function_call_output items (preserving call_id) so
    that multi-turn agentic workflows work correctly with the Responses API.
    """
    items: list[dict[str, Any]] = []
    for msg in _sanitize_messages(messages):
        role = msg.get("role", "user")
        content = msg.get("content", "")

        if not isinstance(content, str):
            content = json.dumps(content, ensure_ascii=False)

        if role == "tool":
            # Responses API expects function_call_output items, not user messages.
            items.append(
                {
                    "type": "function_call_output",
                    "call_id": msg.get("tool_call_id", ""),
                    "output": content,
                }
            )
            continue

        if role not in {"system", "user", "assistant"}:
            role = "user"

        if role == "assistant" and msg.get("tool_calls"):
            # Emit a proper function_call item for each tool call so that
            # subsequent function_call_output items can be matched by call_id.
            # This fixes "No tool call found for function call output" errors
            # when session history contains tool calls from a different model.
            for tc in msg["tool_calls"]:
                fn = tc.get("function", {})
                args = fn.get("arguments", "{}")
                items.append(
                    {
                        "type": "function_call",
                        "call_id": tc.get("id", ""),
                        "name": fn.get("name", ""),
                        "arguments": args if isinstance(args, str) else json.dumps(args),
                    }
                )
            # Tool-calling turns rarely have text content; drop any orphan
            # text to avoid emitting a non-standard assistant item after the
            # function_call items (which would not conform to the Responses API).
            continue

        items.append({"role": role, "content": content})

    return items


def _responses_tools(tools: list[dict[str, Any]] | None) -> list[dict[str, Any]] | None:
    if not tools:
        return None

    converted: list[dict[str, Any]] = []
    for tool in tools:
        if tool.get("type") != "function":
            continue
        fn = tool.get("function", {})
        converted.append(
            {
                "type": "function",
                "name": fn.get("name", ""),
                "description": fn.get("description", ""),
                "parameters": fn.get("parameters", {"type": "object", "properties": {}}),
            }
        )
    return converted


def _should_prefer_responses_api(resolved_model: str) -> bool:
    return _api_model_name(resolved_model) in _RESPONSES_API_MODELS


def _is_chat_unsupported_error(exc: Exception) -> bool:
    body = getattr(exc, "body", None)
    if isinstance(body, dict):
        error = body.get("error", {})
        code = str(error.get("code", "")).lower()
        message = str(error.get("message", "")).lower()
        if code == "unsupported_api_for_model":
            return True
        if "/chat/completions" in message:
            return True

    text = str(exc).lower()
    return "unsupported_api_for_model" in text or "/chat/completions endpoint" in text


class OpenAIProvider(LLMProvider):
    """Provider implementation based on the official OpenAI SDK."""

    def __init__(self, providers: ProvidersConfig | None = None) -> None:
        self._providers = providers or ProvidersConfig()
        # Cache clients by (api_key, api_base, api_version) to avoid constructing
        # a new HTTP connection pool on every request in the fallback loop.
        self._client_cache: dict[tuple[str, str | None, str | None, Any], Any] = {}

    def _build_kwargs(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
    ) -> tuple[str, dict[str, Any], dict[str, Any]]:
        """Build request/client kwargs. Returns (resolved_model, req_kwargs, creds)."""
        resolved_model = model
        creds = resolve_credentials(resolved_model, self._providers)

        req_kwargs: dict[str, Any] = {
            "model": _api_model_name(resolved_model),
            "messages": _sanitize_messages(messages),
        }
        if temperature is not None:
            req_kwargs["temperature"] = temperature
        if max_tokens is not None:
            req_kwargs["max_tokens"] = max_tokens
        if tools:
            req_kwargs["tools"] = tools

        return resolved_model, req_kwargs, creds

    def _build_client(self, resolved_model: str, creds: dict[str, Any]):
        from openai import AsyncAzureOpenAI, AsyncOpenAI

        api_key = creds.get("api_key")
        if not api_key:
            raise ValueError(f"Missing API key for model '{resolved_model}'")

        api_base: str | None = creds.get("api_base")
        api_version: str | None = creds.get("api_version")
        extra_headers = creds.get("extra_headers")
        headers_key = (
            tuple(sorted(extra_headers.items()))
            if isinstance(extra_headers, dict)
            else extra_headers
        )
        cache_key = (api_key, api_base, api_version, headers_key)

        if cache_key in self._client_cache:
            return self._client_cache[cache_key]

        client: AsyncAzureOpenAI | AsyncOpenAI
        if resolved_model.startswith(("azure/", "azure_ai/")):
            if not api_base:
                raise ValueError("Azure OpenAI / Azure AI Foundry requires endpoint (api_base)")
            client = AsyncAzureOpenAI(
                api_key=api_key,
                azure_endpoint=api_base,
                api_version=api_version or "2024-10-21",
                default_headers=extra_headers,
            )
        else:
            client = AsyncOpenAI(
                api_key=api_key,
                base_url=api_base,
                default_headers=extra_headers,
            )

        self._client_cache[cache_key] = client
        return client

    @staticmethod
    def _parse_chat_tool_calls(message: Any) -> list[ToolCallRequest]:
        tool_calls: list[ToolCallRequest] = []
        if not getattr(message, "tool_calls", None):
            return tool_calls

        for tc in message.tool_calls:
            args = tc.function.arguments
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except json.JSONDecodeError:
                    args = {"raw": args}
            tool_calls.append(
                ToolCallRequest(
                    id=tc.id,
                    name=tc.function.name,
                    arguments=args,
                )
            )
        return tool_calls

    @staticmethod
    def _parse_responses_result(response: Any) -> tuple[str, list[ToolCallRequest], int, int]:
        content = getattr(response, "output_text", "") or ""
        tool_calls: list[ToolCallRequest] = []

        for item in getattr(response, "output", []) or []:
            item_type = getattr(item, "type", None)
            if item_type == "function_call":
                raw_args = getattr(item, "arguments", "{}") or "{}"
                if isinstance(raw_args, str):
                    try:
                        args = json.loads(raw_args)
                    except json.JSONDecodeError:
                        args = {"raw": raw_args}
                else:
                    args = raw_args
                tool_calls.append(
                    ToolCallRequest(
                        id=str(
                            getattr(item, "call_id", None)
                            or getattr(item, "id", None)
                            or "function_call"
                        ),
                        name=getattr(item, "name", ""),
                        arguments=args,
                    )
                )
            elif item_type == "message" and not content:
                texts: list[str] = []
                for part in getattr(item, "content", []) or []:
                    part_type = getattr(part, "type", None)
                    if part_type in ("output_text", "text"):
                        text = getattr(part, "text", "")
                        if text:
                            texts.append(text)
                if texts:
                    content = "".join(texts)

        usage = getattr(response, "usage", None)
        prompt_tokens = 0
        completion_tokens = 0
        if usage is not None:
            prompt_tokens = int(
                getattr(usage, "input_tokens", 0) or getattr(usage, "prompt_tokens", 0) or 0
            )
            completion_tokens = int(
                getattr(usage, "output_tokens", 0) or getattr(usage, "completion_tokens", 0) or 0
            )

        return content, tool_calls, prompt_tokens, completion_tokens

    async def _complete_via_responses(
        self,
        *,
        client: Any,
        resolved_model: str,
        req_kwargs: dict[str, Any],
    ) -> LLMResponse:
        resp_kwargs: dict[str, Any] = {
            "model": req_kwargs["model"],
            "input": _responses_input(req_kwargs["messages"]),
        }
        if "temperature" in req_kwargs:
            resp_kwargs["temperature"] = req_kwargs["temperature"]
        if "max_tokens" in req_kwargs:
            resp_kwargs["max_output_tokens"] = req_kwargs["max_tokens"]

        converted_tools = _responses_tools(req_kwargs.get("tools"))
        if converted_tools:
            resp_kwargs["tools"] = converted_tools

        start = time.monotonic()
        response = await client.responses.create(**resp_kwargs)
        elapsed_ms = (time.monotonic() - start) * 1000

        content, tool_calls, prompt_tokens, completion_tokens = self._parse_responses_result(
            response
        )

        return LLMResponse(
            content=content,
            tool_calls=tool_calls,
            finish_reason="tool_calls" if tool_calls else "stop",
            model=getattr(response, "model", None) or resolved_model,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            duration_ms=elapsed_ms,
        )

    async def complete(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
    ) -> LLMResponse:
        candidate_models = resolve_model_chain(model, self._providers)
        if not candidate_models:
            raise ValueError(
                f"No model candidates resolved for alias '{model}'. Configure GITHUB_TOKEN or OPENAI_API_KEY."
            )

        result: LLMResponse | None = None
        resolved_model = model
        last_error: Exception | None = None

        for idx, candidate in enumerate(candidate_models):
            resolved_model, req_kwargs, creds = self._build_kwargs(
                model=candidate,
                messages=messages,
                tools=tools,
                temperature=temperature,
                max_tokens=max_tokens,
            )
            try:
                client = self._build_client(resolved_model, creds)

                if _should_prefer_responses_api(resolved_model):
                    result = await self._complete_via_responses(
                        client=client,
                        resolved_model=resolved_model,
                        req_kwargs=req_kwargs,
                    )
                else:
                    try:
                        start = time.monotonic()
                        response = await client.chat.completions.create(**req_kwargs)
                        elapsed_ms = (time.monotonic() - start) * 1000
                        choice = response.choices[0]
                        msg = choice.message
                        usage = response.usage
                        result = LLMResponse(
                            content=msg.content or "",
                            tool_calls=self._parse_chat_tool_calls(msg),
                            finish_reason=choice.finish_reason or "stop",
                            model=resolved_model,
                            prompt_tokens=usage.prompt_tokens if usage else 0,
                            completion_tokens=usage.completion_tokens if usage else 0,
                            duration_ms=elapsed_ms,
                        )
                    except Exception as exc:
                        if _is_chat_unsupported_error(exc):
                            logger.warning(
                                "Model '{}' does not support /chat/completions; switching to Responses API",
                                resolved_model,
                            )
                            result = await self._complete_via_responses(
                                client=client,
                                resolved_model=resolved_model,
                                req_kwargs=req_kwargs,
                            )
                        else:
                            raise

                if idx > 0:
                    logger.warning(
                        "LLM fallback succeeded: '{}' -> '{}'",
                        candidate_models[0],
                        resolved_model,
                    )
                break
            except Exception as exc:
                last_error = exc
                logger.error("LLM error ({}): {}", resolved_model, exc)
                if idx < len(candidate_models) - 1:
                    logger.warning(
                        "Retrying LLM with fallback model '{}' after '{}' failed",
                        candidate_models[idx + 1],
                        resolved_model,
                    )

        if result is None:
            if last_error is not None:
                raise last_error
            raise RuntimeError("LLM completion failed without an exception")

        logger.debug(
            "LLM {}: {}+{} tokens, {:.0f}ms, {} tool calls",
            resolved_model,
            result.prompt_tokens,
            result.completion_tokens,
            result.duration_ms,
            len(result.tool_calls),
        )

        return result

    async def stream(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
    ) -> AsyncIterator[LLMChunk]:
        candidate_models = resolve_model_chain(model, self._providers)
        if not candidate_models:
            raise ValueError(
                f"No model candidates resolved for alias '{model}'. Configure GITHUB_TOKEN or OPENAI_API_KEY."
            )

        last_error: Exception | None = None

        for idx, candidate in enumerate(candidate_models):
            resolved_model, req_kwargs, creds = self._build_kwargs(
                model=candidate,
                messages=messages,
                tools=tools,
                temperature=temperature,
                max_tokens=max_tokens,
            )

            try:
                client = self._build_client(resolved_model, creds)

                if _should_prefer_responses_api(resolved_model):
                    result = await self._complete_via_responses(
                        client=client,
                        resolved_model=resolved_model,
                        req_kwargs=req_kwargs,
                    )
                    if result.content:
                        yield LLMChunk(
                            content=result.content, finish_reason="stop", model=result.model
                        )
                    return

                try:
                    response = await client.chat.completions.create(**req_kwargs, stream=True)
                except Exception as exc:
                    if _is_chat_unsupported_error(exc):
                        logger.warning(
                            "Model '{}' does not support /chat/completions; switching to Responses API",
                            resolved_model,
                        )
                        result = await self._complete_via_responses(
                            client=client,
                            resolved_model=resolved_model,
                            req_kwargs=req_kwargs,
                        )
                        if result.content:
                            yield LLMChunk(
                                content=result.content,
                                finish_reason="stop",
                                model=result.model,
                            )
                        return
                    raise

                emitted_any = False
                try:
                    async for chunk in response:
                        if not chunk.choices:
                            continue
                        emitted_any = True
                        choice = chunk.choices[0]
                        delta = choice.delta
                        yield LLMChunk(
                            content=delta.content or "",
                            finish_reason=choice.finish_reason,
                            model=resolved_model,
                        )
                    if idx > 0:
                        logger.warning(
                            "LLM stream fallback succeeded: '{}' -> '{}'",
                            candidate_models[0],
                            resolved_model,
                        )
                    return
                except Exception as exc:
                    last_error = exc
                    logger.error("LLM stream iteration error ({}): {}", resolved_model, exc)
                    if emitted_any or idx >= len(candidate_models) - 1:
                        raise
                    logger.warning(
                        "Retrying stream with fallback model '{}' after early stream failure in '{}'",
                        candidate_models[idx + 1],
                        resolved_model,
                    )
            except Exception as exc:
                last_error = exc
                logger.error("LLM stream error ({}): {}", resolved_model, exc)
                if idx < len(candidate_models) - 1:
                    logger.warning(
                        "Retrying stream with fallback model '{}' after '{}' failed",
                        candidate_models[idx + 1],
                        resolved_model,
                    )
                    continue
                raise

        if last_error is not None:
            raise last_error
        raise RuntimeError("LLM stream failed without an exception")
