"""
Two-layer memory system with SQLite hybrid search.

Layer 1 — File-based (original):
  - MEMORY.md: Long-term facts (preferences, decisions, extracted context)
  - HISTORY.md: Append-only searchable log of key interactions

Layer 2 — SQLite + optional vector search (new):
  - knowledge.db: FTS5 full-text indexed knowledge base (BM25 ranking)
  - embeddings.npz: Optional numpy-based vector embeddings for semantic search

Memory consolidation compresses old conversation turns into these stores
when the conversation exceeds the configured window.

Inspired by HKUDS/nanobot's memory model, extended for enterprise use.
"""

from __future__ import annotations

import asyncio
import re
import sqlite3
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from loguru import logger

# ── File-based Memory Store (original API preserved) ─────────────────────────


class MemoryStore:
    """Persistent two-layer memory for the agent.

    Maintains backward-compatible MEMORY.md + HISTORY.md file-based memory.

    The ``consolidation_lock`` is shared across all instances for the same
    workspace to prevent concurrent MEMORY.md writes from sub-agents.
    Optionally scoped to a named agent via ``agent_name``, which stores files
    under ``memory/agents/<name>/`` instead of the workspace root.  Shared
    memory lives under ``memory/shared/``.

    Parameters
    ----------
    workspace:
        Root workspace directory.
    agent_name:
        If provided, memory files are placed in a per-agent subdirectory.
        Shared memory files are also accessible under ``memory/shared/``.
    """

    # Per-workspace consolidation locks shared across all MemoryStore instances
    _consolidation_locks: dict[str, asyncio.Lock] = {}

    def __init__(self, workspace: Path, *, agent_name: str | None = None) -> None:
        self._workspace = workspace
        self._agent_name = agent_name
        # Get or create a shared lock for this workspace
        ws_key = str(workspace.resolve())
        if ws_key not in MemoryStore._consolidation_locks:
            MemoryStore._consolidation_locks[ws_key] = asyncio.Lock()
        self.consolidation_lock = MemoryStore._consolidation_locks[ws_key]

        if agent_name:
            base = workspace / "memory" / "agents" / agent_name
        else:
            base = workspace

        base.mkdir(parents=True, exist_ok=True)
        self._base = base
        self._memory_path = base / "MEMORY.md"
        self._history_path = base / "HISTORY.md"

        # Shared memory directory (always available)
        self._shared_dir = workspace / "memory" / "shared"
        self._shared_dir.mkdir(parents=True, exist_ok=True)

    @property
    def workspace(self) -> Path:
        """Return the workspace root."""
        return self._workspace

    @property
    def base_dir(self) -> Path:
        """Return the base directory for this memory store."""
        return self._base

    @property
    def shared_dir(self) -> Path:
        """Return the shared memory directory."""
        return self._shared_dir

    # ── MEMORY.md ────────────────────────────────────────────────────────

    def read_memory(self) -> str:
        """Read long-term memory facts from MEMORY.md."""
        if self._memory_path.is_file():
            return self._memory_path.read_text(encoding="utf-8")
        return ""

    def write_memory(self, content: str) -> None:
        """Overwrite long-term memory with consolidated facts."""
        self._memory_path.write_text(content, encoding="utf-8")

    # ── HISTORY.md ───────────────────────────────────────────────────────

    def append_history(self, entry: str) -> None:
        """Append an entry to the searchable history log."""
        ts = datetime.now(UTC).strftime("%Y-%m-%d %H:%M")
        with self._history_path.open("a", encoding="utf-8") as f:
            f.write(f"\n## {ts}\n\n{entry}\n")

    def read_history(self, last_n_lines: int = 200) -> str:
        """Read the tail of the history log."""
        if not self._history_path.is_file():
            return ""
        lines = self._history_path.read_text(encoding="utf-8").splitlines()
        return "\n".join(lines[-last_n_lines:])

    # ── Shared memory helpers ────────────────────────────────────────────

    def read_shared(self, filename: str = "MEMORY.md") -> str:
        """Read a file from the shared memory directory."""
        path = self._shared_dir / filename
        if path.is_file():
            return path.read_text(encoding="utf-8")
        return ""

    def write_shared(self, content: str, filename: str = "MEMORY.md") -> None:
        """Write a file to the shared memory directory."""
        path = self._shared_dir / filename
        path.write_text(content, encoding="utf-8")

    # ── Consolidation ────────────────────────────────────────────────────

    def build_consolidation_prompt(self, messages: list[dict[str, Any]]) -> str:
        """Build a prompt asking the LLM to consolidate old messages
        into memory and history entries.
        """
        existing_memory = self.read_memory()

        # Build conversation with timestamps and tool context
        conv_lines: list[str] = []
        for m in messages:
            role = m.get("role", "?").upper()
            content = m.get("content", "")[:500]
            # Extract tool names from tool_calls if present
            tool_calls = m.get("tool_calls", [])
            tools_str = ""
            if tool_calls:
                names = [tc.get("function", {}).get("name", "?") for tc in tool_calls]
                tools_str = f" [tools: {', '.join(names)}]"
            timestamp = m.get("timestamp", "")
            ts_prefix = f"[{timestamp}] " if timestamp else ""
            conv_lines.append(f"{ts_prefix}{role}{tools_str}: {content}")
        conversation = "\n".join(conv_lines)

        return (
            "You are a memory consolidation agent.\n"
            "Review the conversation and update persistent memory.\n\n"
            f"## Existing Memory\n\n{existing_memory or '(empty)'}\n\n"
            f"## Conversation\n\n{conversation}\n\n"
            "## Instructions\n\n"
            "Output two sections:\n"
            "1. **MEMORY**: Updated long-term facts. Start with [YYYY-MM-DD HH:MM]. "
            "Include detail useful for grep search. Max 2000 chars.\n"
            "2. **HISTORY**: Brief summary (1-3 sentences) for the history log.\n\n"
            "Format:\n"
            "```memory\n<memory content>\n```\n\n"
            "```history\n<history entry>\n```"
        )

    def apply_consolidation(self, llm_response: str) -> None:
        """Parse and apply the consolidation response."""
        memory_match = re.search(r"```memory\n(.*?)```", llm_response, re.DOTALL)
        history_match = re.search(r"```history\n(.*?)```", llm_response, re.DOTALL)

        if memory_match:
            self.write_memory(memory_match.group(1).strip())
        if history_match:
            self.append_history(history_match.group(1).strip())


# ── SQLite FTS5 Knowledge Store ──────────────────────────────────────────────


class KnowledgeStore:
    """SQLite-backed knowledge base with FTS5 full-text search.

    Stores structured knowledge entries (facts, preferences, decisions,
    code snippets, etc.) and exposes BM25-ranked full-text search.

    The database is created at ``<base_dir>/knowledge.db``.

    Parameters
    ----------
    base_dir:
        Directory where ``knowledge.db`` will be created.
    """

    _DDL = [
        """
        CREATE TABLE IF NOT EXISTS knowledge (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            content    TEXT    NOT NULL,
            category   TEXT    NOT NULL DEFAULT 'fact',
            source     TEXT    NOT NULL DEFAULT 'agent',
            created_at TEXT    NOT NULL,
            updated_at TEXT    NOT NULL
        )
        """,
        # Standalone FTS5 table — synced manually in CRUD methods to
        # avoid trigger compatibility issues across SQLite versions.
        """
        CREATE VIRTUAL TABLE IF NOT EXISTS knowledge_fts
        USING fts5(content, tokenize='porter unicode61')
        """,
    ]

    def __init__(self, base_dir: Path) -> None:
        self._db_path = base_dir / "knowledge.db"
        base_dir.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self._db_path))
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._init_schema()

    def _init_schema(self) -> None:
        """Create tables and triggers if they do not exist."""
        for stmt in self._DDL:
            self._conn.execute(stmt)
        self._conn.commit()

    # ── CRUD ─────────────────────────────────────────────────────────────

    def add(
        self,
        content: str,
        category: str = "fact",
        source: str = "agent",
    ) -> int:
        """Insert a knowledge entry and return its row id.

        Parameters
        ----------
        content:
            The textual knowledge to store.
        category:
            Categorisation label (e.g. ``"fact"``, ``"preference"``,
            ``"decision"``, ``"code"``, ``"error"``).
        source:
            Origin of the knowledge (e.g. ``"agent"``, ``"user"``,
            ``"consolidation"``).

        Returns
        -------
        int
            The auto-generated id of the new row.
        """
        now = datetime.now(UTC).isoformat()
        cur = self._conn.execute(
            """
            INSERT INTO knowledge (content, category, source, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?)
            """,
            (content, category, source, now, now),
        )
        row_id = cur.lastrowid
        assert row_id is not None
        # Sync FTS index
        self._conn.execute(
            "INSERT INTO knowledge_fts(rowid, content) VALUES (?, ?)",
            (row_id, content),
        )
        self._conn.commit()
        logger.debug(f"KnowledgeStore: added id={row_id} category={category}")
        return row_id

    def search(self, query: str, top_k: int = 10) -> list[dict[str, Any]]:
        """Full-text search using FTS5 BM25 ranking.

        Parameters
        ----------
        query:
            The search query (supports FTS5 query syntax such as ``AND``,
            ``OR``, ``NEAR``, prefix ``*``, etc.).
        top_k:
            Maximum number of results to return.

        Returns
        -------
        list[dict]
            List of matching knowledge entries, each containing ``id``,
            ``content``, ``category``, ``source``, ``created_at``,
            ``updated_at``, and ``rank`` (BM25 score — lower is better).
        """
        # Sanitise the query for FTS5: wrap bare terms in double-quotes so
        # that special characters (colons, hyphens, etc.) do not trip the
        # parser.  This is a pragmatic approach — callers who want raw FTS5
        # syntax can prefix the query with ``fts5:``.
        if not query.startswith("fts5:"):
            # Simple tokenisation: split on whitespace and wrap each term.
            terms = query.split()
            safe_query = " ".join(f'"{t}"' for t in terms if t)
        else:
            safe_query = query.removeprefix("fts5:")

        if not safe_query.strip():
            return []

        try:
            rows = self._conn.execute(
                """
                SELECT k.id, k.content, k.category, k.source,
                       k.created_at, k.updated_at,
                       knowledge_fts.rank AS rank
                FROM knowledge_fts
                JOIN knowledge k ON k.id = knowledge_fts.rowid
                WHERE knowledge_fts MATCH ?
                ORDER BY knowledge_fts.rank
                LIMIT ?
                """,
                (safe_query, top_k),
            ).fetchall()
        except sqlite3.OperationalError as exc:
            logger.warning(f"KnowledgeStore FTS5 query failed: {exc}")
            return []

        return [dict(r) for r in rows]

    def update(self, id: int, content: str) -> None:
        """Update the content of an existing knowledge entry.

        Parameters
        ----------
        id:
            Row id of the entry to update.
        content:
            New textual content.
        """
        now = datetime.now(UTC).isoformat()
        # Remove old FTS entry, then update main table, then re-insert FTS
        self._conn.execute("DELETE FROM knowledge_fts WHERE rowid = ?", (id,))
        self._conn.execute(
            "UPDATE knowledge SET content = ?, updated_at = ? WHERE id = ?",
            (content, now, id),
        )
        self._conn.execute(
            "INSERT INTO knowledge_fts(rowid, content) VALUES (?, ?)",
            (id, content),
        )
        self._conn.commit()

    def delete(self, id: int) -> None:
        """Delete a knowledge entry by id.

        Parameters
        ----------
        id:
            Row id of the entry to remove.
        """
        # Remove FTS entry first, then the main row
        self._conn.execute("DELETE FROM knowledge_fts WHERE rowid = ?", (id,))
        self._conn.execute("DELETE FROM knowledge WHERE id = ?", (id,))
        self._conn.commit()

    def count(self) -> int:
        """Return the total number of knowledge entries."""
        row = self._conn.execute("SELECT COUNT(*) FROM knowledge").fetchone()
        return row[0] if row else 0

    def get(self, id: int) -> dict[str, Any] | None:
        """Retrieve a single knowledge entry by id."""
        row = self._conn.execute("SELECT * FROM knowledge WHERE id = ?", (id,)).fetchone()
        return dict(row) if row else None

    def close(self) -> None:
        """Close the underlying database connection."""
        self._conn.close()


# ── Optional Vector Index (numpy-based) ──────────────────────────────────────


class VectorIndex:
    """In-memory cosine-similarity vector index backed by numpy.

    Embeddings are stored as a contiguous numpy array and persisted to
    ``embeddings.npz`` on every mutation.  Numpy is imported lazily so
    that the rest of the memory module works without it installed.

    Parameters
    ----------
    base_dir:
        Directory where ``embeddings.npz`` will be saved.
    dimension:
        Embedding vector dimensionality (default 384, typical for
        all-MiniLM-L6-v2 and similar small models).
    """

    def __init__(self, base_dir: Path, *, dimension: int = 384) -> None:
        self._path = base_dir / "embeddings.npz"
        self._dimension = dimension
        self._np = self._import_numpy()

        # id → embedding mapping backed by numpy arrays
        self._ids: list[int] = []
        self._vectors: Any = None  # numpy ndarray | None

        if self._np is not None:
            self._load()

    @property
    def available(self) -> bool:
        """Return ``True`` if numpy is installed and the index is usable."""
        return self._np is not None

    @property
    def size(self) -> int:
        """Return the number of stored embeddings."""
        return len(self._ids)

    # ── Public API ───────────────────────────────────────────────────────

    def add(self, id: int, embedding: list[float]) -> None:
        """Add or replace an embedding for the given id.

        Parameters
        ----------
        id:
            Knowledge entry id.
        embedding:
            Dense vector of length ``self._dimension``.
        """
        np = self._require_numpy()
        vec = np.asarray(embedding, dtype=np.float32)
        if vec.shape != (self._dimension,):
            raise ValueError(f"Expected embedding of dimension {self._dimension}, got {vec.shape}")

        # Replace if already present
        if id in self._ids:
            idx = self._ids.index(id)
            self._vectors[idx] = vec
        else:
            self._ids.append(id)
            if self._vectors is None or len(self._vectors) == 0:
                self._vectors = vec.reshape(1, -1)
            else:
                self._vectors = np.vstack([self._vectors, vec.reshape(1, -1)])

        self._save()

    def search(
        self,
        query_embedding: list[float],
        top_k: int = 10,
    ) -> list[tuple[int, float]]:
        """Find the most similar embeddings by cosine similarity.

        Parameters
        ----------
        query_embedding:
            Query vector of length ``self._dimension``.
        top_k:
            Maximum number of results.

        Returns
        -------
        list[tuple[int, float]]
            ``(id, similarity)`` pairs sorted by descending similarity.
        """
        np = self._require_numpy()
        if self._vectors is None or len(self._ids) == 0:
            return []

        query = np.asarray(query_embedding, dtype=np.float32)
        if query.shape != (self._dimension,):
            raise ValueError(f"Expected query of dimension {self._dimension}, got {query.shape}")

        # Cosine similarity: (A . q) / (||A|| * ||q||)
        norms = np.linalg.norm(self._vectors, axis=1)
        query_norm = np.linalg.norm(query)
        if query_norm == 0:
            return []

        # Avoid division by zero for any zero-norm stored vectors
        safe_norms = np.where(norms == 0, 1.0, norms)
        similarities = (self._vectors @ query) / (safe_norms * query_norm)

        k = min(top_k, len(self._ids))
        # argpartition is O(n) for top-k, but for clarity we use argsort
        top_indices = np.argsort(-similarities)[:k]

        return [
            (self._ids[int(idx)], float(similarities[idx]))
            for idx in top_indices
            if similarities[idx] > 0
        ]

    def remove(self, id: int) -> None:
        """Remove the embedding for the given id.

        Parameters
        ----------
        id:
            Knowledge entry id whose embedding should be deleted.
        """
        np = self._require_numpy()
        if id not in self._ids:
            return
        idx = self._ids.index(id)
        self._ids.pop(idx)
        if self._vectors is not None and len(self._vectors) > 0:
            self._vectors = np.delete(self._vectors, idx, axis=0)
        self._save()

    # ── Persistence ──────────────────────────────────────────────────────

    def _load(self) -> None:
        """Load embeddings from disk if the file exists."""
        np = self._np
        if np is None or not self._path.is_file():
            return
        try:
            data = np.load(str(self._path), allow_pickle=False)
            self._ids = data["ids"].tolist()
            self._vectors = data["vectors"]
            logger.debug(f"VectorIndex: loaded {len(self._ids)} embeddings from {self._path}")
        except Exception as exc:
            logger.warning(f"VectorIndex: failed to load {self._path}: {exc}")
            self._ids = []
            self._vectors = None

    def _save(self) -> None:
        """Persist embeddings to disk."""
        np = self._require_numpy()
        ids_arr = np.asarray(self._ids, dtype=np.int64)
        vectors = (
            self._vectors
            if self._vectors is not None
            else np.empty((0, self._dimension), dtype=np.float32)
        )
        np.savez(str(self._path), ids=ids_arr, vectors=vectors)

    # ── Numpy helpers ────────────────────────────────────────────────────

    @staticmethod
    def _import_numpy() -> Any:
        """Try to import numpy; return the module or ``None``."""
        try:
            import numpy as np  # type: ignore[import-untyped]

            return np
        except ImportError:
            logger.debug("numpy not installed — VectorIndex disabled")
            return None

    def _require_numpy(self) -> Any:
        """Return numpy or raise if unavailable."""
        if self._np is None:
            raise RuntimeError(
                "numpy is required for VectorIndex but is not installed. "
                "Install it with: pip install numpy"
            )
        return self._np


# ── Hybrid Memory (FTS5 + Vector + File-based) ──────────────────────────────


class HybridMemory:
    """Unified memory layer combining file-based, FTS5, and vector search.

    Wraps :class:`MemoryStore`, :class:`KnowledgeStore`, and optionally
    :class:`VectorIndex` into a single facade with hybrid search.

    Parameters
    ----------
    workspace:
        Root workspace directory.
    agent_name:
        Optional agent name for per-agent memory scoping.
    vector_dimension:
        Embedding dimension for the optional vector index (default 384).
    """

    def __init__(
        self,
        workspace: Path,
        *,
        agent_name: str | None = None,
        vector_dimension: int = 384,
    ) -> None:
        self._workspace = workspace

        # File-based memory (backward compatible)
        self.memory_store = MemoryStore(workspace, agent_name=agent_name)

        # SQLite FTS5 knowledge base
        base_dir = self.memory_store.base_dir
        self.knowledge = KnowledgeStore(base_dir)

        # Optional vector index
        self.vectors = VectorIndex(base_dir, dimension=vector_dimension)

        logger.debug(
            f"HybridMemory initialised: workspace={workspace} "
            f"agent={agent_name or 'default'} "
            f"vector={'enabled' if self.vectors.available else 'disabled'}"
        )

    # ── Hybrid search ────────────────────────────────────────────────────

    def search(
        self,
        query: str,
        top_k: int = 10,
        *,
        fts_weight: float = 0.7,
        query_embedding: list[float] | None = None,
    ) -> list[dict[str, Any]]:
        """Run hybrid FTS5 + vector search with weighted score fusion.

        Executes a BM25-ranked FTS5 search and, if a ``query_embedding``
        is provided and the vector index is available, also runs a cosine
        similarity search.  Results are fused using weighted scoring:

            ``score = fts_weight * fts_score_norm + (1 - fts_weight) * vec_score``

        Parameters
        ----------
        query:
            Text search query (passed to FTS5).
        top_k:
            Maximum number of results to return.
        fts_weight:
            Weight for the FTS5 score in ``[0, 1]``.  The vector score
            weight is ``1 - fts_weight``.
        query_embedding:
            Optional dense vector for semantic search.  If ``None`` or
            the vector index is unavailable, only FTS5 results are used.

        Returns
        -------
        list[dict]
            Merged, deduplicated list of knowledge entries.  Each dict
            includes a ``score`` key with the fused relevance score
            (higher is better).
        """
        # 1. FTS5 search
        fts_results = self.knowledge.search(query, top_k=top_k * 2)

        # Normalise FTS5 BM25 scores: BM25 rank is negative (lower = better
        # match in sqlite), so we negate and normalise to [0, 1].
        fts_scores: dict[int, float] = {}
        if fts_results:
            raw_ranks = [abs(r["rank"]) for r in fts_results]
            max_rank = max(raw_ranks) if raw_ranks else 1.0
            max_rank = max_rank if max_rank > 0 else 1.0
            for r in fts_results:
                # Higher normalised score = better match
                fts_scores[r["id"]] = abs(r["rank"]) / max_rank

        # 2. Vector search (optional)
        vec_scores: dict[int, float] = {}
        if query_embedding is not None and self.vectors.available and self.vectors.size > 0:
            vec_results = self.vectors.search(query_embedding, top_k=top_k * 2)
            for entry_id, similarity in vec_results:
                vec_scores[entry_id] = similarity

        # 3. Fuse scores
        all_ids = set(fts_scores.keys()) | set(vec_scores.keys())
        fused: list[tuple[int, float]] = []

        for entry_id in all_ids:
            fs = fts_scores.get(entry_id, 0.0)
            vs = vec_scores.get(entry_id, 0.0)
            combined = fts_weight * fs + (1 - fts_weight) * vs
            fused.append((entry_id, combined))

        # Sort descending by score and take top_k
        fused.sort(key=lambda x: x[1], reverse=True)
        top_ids = fused[:top_k]

        # 4. Build result dicts
        results: list[dict[str, Any]] = []
        for entry_id, score in top_ids:
            entry = self.knowledge.get(entry_id)
            if entry is not None:
                entry["score"] = score
                results.append(entry)

        return results

    # ── Knowledge management ─────────────────────────────────────────────

    def add_knowledge(
        self,
        content: str,
        category: str = "fact",
        *,
        source: str = "agent",
        embedding: list[float] | None = None,
    ) -> int:
        """Add a knowledge entry with optional vector embedding.

        Parameters
        ----------
        content:
            Textual knowledge to store.
        category:
            Categorisation label.
        source:
            Origin of the knowledge.
        embedding:
            Optional dense vector for semantic search.

        Returns
        -------
        int
            The id of the newly created knowledge entry.
        """
        entry_id = self.knowledge.add(content, category=category, source=source)

        if embedding is not None and self.vectors.available:
            self.vectors.add(entry_id, embedding)

        return entry_id

    def remove_knowledge(self, id: int) -> None:
        """Remove a knowledge entry and its vector embedding."""
        self.knowledge.delete(id)
        if self.vectors.available:
            self.vectors.remove(id)

    # ── Auto-extraction ──────────────────────────────────────────────────

    async def auto_extract(
        self,
        messages: list[dict[str, Any]],
        provider: Any = None,
        *,
        memory_window: int = 50,
    ) -> None:
        """Extract knowledge from conversation when it exceeds the window.

        When the number of messages exceeds ``memory_window``, this method
        asks the LLM provider (if available) to extract facts, preferences,
        and decisions from the conversation, then stores them in both
        MEMORY.md and the knowledge database.

        Parameters
        ----------
        messages:
            Full conversation message list.
        provider:
            An LLM provider instance with an async ``complete`` method.
            If ``None``, only file-based consolidation is performed.
        memory_window:
            Threshold number of messages before auto-extraction triggers.
        """
        if len(messages) < memory_window:
            return

        logger.info(
            f"HybridMemory: auto-extracting from {len(messages)} messages (window={memory_window})"
        )

        # File-based consolidation (always available)
        consolidation_prompt = self.memory_store.build_consolidation_prompt(messages)

        if provider is None:
            logger.debug("HybridMemory: no provider — skipping LLM extraction")
            return

        try:
            # Ask the LLM to extract structured knowledge
            extraction_prompt = self._build_extraction_prompt(messages)
            response = await provider.complete(
                model=getattr(provider, "_default_model", "auto"),
                messages=[{"role": "user", "content": extraction_prompt}],
                temperature=0.1,
                max_tokens=2048,
            )

            extracted = self._parse_extraction(response.content)
            for item in extracted:
                self.knowledge.add(
                    content=item["content"],
                    category=item.get("category", "fact"),
                    source="auto_extract",
                )
            logger.info(f"HybridMemory: extracted {len(extracted)} knowledge entries")

            # Also run file-based consolidation
            consolidation_response = await provider.complete(
                model=getattr(provider, "_default_model", "auto"),
                messages=[{"role": "user", "content": consolidation_prompt}],
                temperature=0.1,
                max_tokens=2048,
            )
            self.memory_store.apply_consolidation(consolidation_response.content)

        except Exception as exc:
            logger.error(f"HybridMemory auto-extraction failed: {exc}")

    # ── Convenience proxies ──────────────────────────────────────────────

    def read_memory(self) -> str:
        """Proxy to :meth:`MemoryStore.read_memory`."""
        return self.memory_store.read_memory()

    def write_memory(self, content: str) -> None:
        """Proxy to :meth:`MemoryStore.write_memory`."""
        self.memory_store.write_memory(content)

    def append_history(self, entry: str) -> None:
        """Proxy to :meth:`MemoryStore.append_history`."""
        self.memory_store.append_history(entry)

    def read_history(self, last_n_lines: int = 200) -> str:
        """Proxy to :meth:`MemoryStore.read_history`."""
        return self.memory_store.read_history(last_n_lines)

    def build_consolidation_prompt(self, messages: list[dict[str, Any]]) -> str:
        """Proxy to :meth:`MemoryStore.build_consolidation_prompt`."""
        return self.memory_store.build_consolidation_prompt(messages)

    def apply_consolidation(self, llm_response: str) -> None:
        """Proxy to :meth:`MemoryStore.apply_consolidation`."""
        self.memory_store.apply_consolidation(llm_response)

    def close(self) -> None:
        """Release resources held by the knowledge store."""
        self.knowledge.close()

    # ── Private helpers ──────────────────────────────────────────────────

    @staticmethod
    def _build_extraction_prompt(messages: list[dict[str, Any]]) -> str:
        """Build a prompt that asks the LLM to extract structured knowledge."""
        conversation = "\n".join(
            f"[{m.get('role', '?')}] {m.get('content', '')[:500]}" for m in messages
        )

        return (
            "You are a knowledge extraction assistant. Analyse the following "
            "conversation and extract discrete knowledge entries.\n\n"
            f"## Conversation\n\n{conversation}\n\n"
            "## Instructions\n\n"
            "Extract facts, user preferences, key decisions, and important "
            "context as individual entries. Output a JSON array of objects, "
            "each with:\n"
            '- "content": the knowledge text\n'
            '- "category": one of "fact", "preference", "decision", '
            '"code", "error", "context"\n\n'
            "Output ONLY the JSON array, no extra text.\n\n"
            "Example:\n"
            "```json\n"
            '[\n  {"content": "User prefers dark mode", "category": "preference"},\n'
            '  {"content": "Project uses Python 3.11+", "category": "fact"}\n]\n'
            "```"
        )

    @staticmethod
    def _parse_extraction(llm_response: str) -> list[dict[str, str]]:
        """Parse the LLM's JSON extraction response."""
        import json

        # Try to find a JSON array in the response
        # First try: look for a fenced code block
        match = re.search(r"```(?:json)?\s*\n(\[.*?\])\s*\n?```", llm_response, re.DOTALL)
        text = match.group(1) if match else llm_response.strip()

        # If no code block, try to find a bare JSON array
        if not match:
            arr_match = re.search(r"\[.*\]", text, re.DOTALL)
            if arr_match:
                text = arr_match.group(0)

        try:
            data = json.loads(text)
            if isinstance(data, list):
                # Validate structure
                return [
                    {
                        "content": str(item.get("content", "")),
                        "category": str(item.get("category", "fact")),
                    }
                    for item in data
                    if isinstance(item, dict) and item.get("content")
                ]
        except (json.JSONDecodeError, TypeError) as exc:
            logger.warning(f"Failed to parse extraction response: {exc}")

        return []
