"""
Cross-channel messaging tool — send messages to any configured channel
via the async message bus.

The tool publishes an OutboundMessage to the MessageBus, which routes it
to the appropriate channel handler (CLI, Teams, Outlook, GitHub, ADO).
"""

from __future__ import annotations

from typing import Any

from loguru import logger

from workpilot.agent.tools.base import Tool, ToolMetadata
from workpilot.bus.events import OutboundMessage
from workpilot.bus.queue import MessageBus


class MessageTool(Tool):
    """Send messages to channels through the message bus."""

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(risk_level="low", approval="never", timeout=30)

    def __init__(self, bus: MessageBus) -> None:
        self._bus = bus

    # ── Tool ABC ────────────────────────────────────────────────────────

    @property
    def name(self) -> str:
        return "message"

    @property
    def description(self) -> str:
        return (
            "Send a message to a communication channel. "
            "Supported channels: cli, teams, outlook, github, ado. "
            "Optionally specify a recipient and/or thread to reply in."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "channel": {
                    "type": "string",
                    "enum": ["cli", "teams", "outlook", "github", "ado"],
                    "description": "Target channel to send the message to.",
                },
                "content": {
                    "type": "string",
                    "description": "The message content to send.",
                },
                "recipient": {
                    "type": "string",
                    "description": (
                        "Recipient identifier (email, username, etc.). "
                        "Optional — if omitted the channel decides the default target."
                    ),
                },
                "thread_id": {
                    "type": "string",
                    "description": (
                        "Thread or conversation ID to reply within. "
                        "Optional — if omitted a new conversation is started."
                    ),
                },
            },
            "required": ["channel", "content"],
        }

    async def execute(self, **kwargs: Any) -> str:
        channel: str = kwargs["channel"]
        content: str = kwargs["content"]
        recipient: str | None = kwargs.get("recipient")
        thread_id: str | None = kwargs.get("thread_id")

        if not content.strip():
            return "Error: message content cannot be empty."

        msg = OutboundMessage(
            channel=channel,
            channel_id=recipient or channel,
            content=content,
            thread_id=thread_id,
        )

        try:
            await self._bus.publish_outbound(msg)
            logger.debug(
                f"Message published to '{channel}'"
                + (f" thread={thread_id}" if thread_id else "")
                + (f" recipient={recipient}" if recipient else "")
            )
            summary = (
                f"Message sent to {channel}"
                + (f" (recipient: {recipient})" if recipient else "")
                + (f" (thread: {thread_id})" if thread_id else "")
            )
            return summary
        except Exception as exc:
            logger.error(f"Failed to publish message to '{channel}': {exc}")
            return f"Error sending message to {channel}: {exc}"
