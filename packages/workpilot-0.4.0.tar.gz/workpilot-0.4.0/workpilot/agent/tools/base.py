"""
Tool base class — ABC with JSON Schema validation (inspired by HKUDS/nanobot).

Each tool defines:
- name, description, parameters (JSON Schema)
- metadata (risk, approval, isolation, timeout)
- validate(args) → list of errors
- execute(**kwargs) → str
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any

# Type alias for progress callbacks — tools call this to emit incremental updates.
ProgressCallback = Callable[[str], Awaitable[None]]


@dataclass
class ToolMetadata:
    """Static properties for tool risk classification and approval."""

    risk_level: str = "low"  # low | medium | high | critical
    isolation: str = "process"  # process | container
    category: str = "builtin"  # builtin | mcp | subagent | custom
    approval: str = "auto"  # never | auto | always
    timeout: int = 600  # Config default (seconds)
    streaming: bool = False


class Tool(ABC):
    """Abstract tool that can be called by the agent."""

    _progress: ProgressCallback | None = None

    def set_progress_callback(self, cb: ProgressCallback | None) -> None:
        """Inject an async progress callback. Called by the registry before execution."""
        self._progress = cb

    @property
    @abstractmethod
    def name(self) -> str:
        """Unique tool name."""

    @property
    @abstractmethod
    def description(self) -> str:
        """Human-readable description shown to the LLM."""

    @property
    @abstractmethod
    def parameters(self) -> dict[str, Any]:
        """JSON Schema for the tool's input parameters."""

    @property
    def metadata(self) -> ToolMetadata:
        """Tool metadata for risk classification and approval. Override in subclass."""
        return ToolMetadata()

    def validate(self, args: dict[str, Any]) -> list[str]:
        """Validate args. Return list of error strings (empty = valid)."""
        return []

    @abstractmethod
    async def execute(self, **kwargs: Any) -> str:
        """Execute the tool and return a text result."""

    def to_openai_schema(self) -> dict[str, Any]:
        """Convert to OpenAI function-calling tool format."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }
