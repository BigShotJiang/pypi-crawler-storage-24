"""
MCP Connect tool — unified MCP server interaction with progressive loading.

All MCP interactions go through this single tool:
    mcp_connect()                                              → list servers
    mcp_connect(server="icm")                                  → connect (auto-describe if ≤5 tools)
    mcp_connect(server="icm", action="describe")               → full capabilities + tool signatures
    mcp_connect(server="icm", action="describe", filter="incident") → filtered tools
    mcp_connect(server="icm", action="resources", uri="...")   → read a resource
    mcp_connect(server="icm", action="prompts", prompt="...", arguments={...}) → get prompt
    mcp_connect(server="icm", action="disconnect")             → disconnect
    mcp_connect(server="icm", action="status")                 → server status
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from workpilot.agent.tools.base import Tool, ToolMetadata

if TYPE_CHECKING:
    from workpilot.mcp.manager import MCPManager


class MCPConnectTool(Tool):
    """Unified MCP server interaction with progressive loading."""

    def __init__(self, manager: MCPManager) -> None:
        self._manager = manager

    @property
    def name(self) -> str:
        return "mcp_connect"

    @property
    def description(self) -> str:
        return (
            "Manage MCP server connections and access server capabilities. "
            "Actions: connect (default) — connect a server; "
            "describe — list tools/resources/prompts with full signatures; "
            "resources — read a resource by URI; "
            "prompts — get a rendered prompt; "
            "disconnect — disconnect; status — show status. "
            "Call without arguments to list available servers."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "server": {
                    "type": "string",
                    "description": "MCP server name (e.g. 'icm', 'kusto'). Omit to list servers.",
                },
                "action": {
                    "type": "string",
                    "enum": ["connect", "describe", "disconnect", "status", "resources", "prompts"],
                    "description": "Action to perform. Default: connect.",
                },
                "filter": {
                    "type": "string",
                    "description": "Keyword filter for describe — only show matching tools.",
                },
                "uri": {
                    "type": "string",
                    "description": "Resource URI to read (for action=resources).",
                },
                "prompt": {
                    "type": "string",
                    "description": "Prompt name to render (for action=prompts).",
                },
                "arguments": {
                    "type": "object",
                    "description": "Arguments for prompt rendering.",
                    "additionalProperties": {"type": "string"},
                },
            },
            "required": [],
        }

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(
            risk_level="low",
            approval="never",
            category="builtin",
        )

    async def execute(self, **kwargs: Any) -> str:
        server = kwargs.get("server", "").strip()
        action = kwargs.get("action", "").strip()

        # No server → list available
        if not server:
            return self._format_server_list()

        # Default action
        if not action:
            action = "connect"

        match action:
            case "connect":
                return await self._manager.connect_server(server)
            case "describe":
                filter_kw = kwargs.get("filter", "").strip() or None
                return await self._manager.describe_server(server, keyword=filter_kw)
            case "resources":
                uri = kwargs.get("uri", "").strip()
                if not uri:
                    # No URI → describe will show resources list
                    return await self._manager.describe_server(server)
                return await self._manager.read_resource(server, uri)
            case "prompts":
                prompt = kwargs.get("prompt", "").strip()
                if not prompt:
                    # No prompt name → describe will show prompts list
                    return await self._manager.describe_server(server)
                arguments = kwargs.get("arguments") or {}
                return await self._manager.get_prompt(server, prompt, arguments)
            case "disconnect":
                await self._manager.disconnect_server(server)
                return f"Disconnected from MCP server '{server}'."
            case "status":
                return self._format_status(server)
            case _:
                return (
                    f"Unknown action '{action}'. "
                    "Use: connect, describe, disconnect, status, resources, prompts."
                )

    def _format_server_list(self) -> str:
        servers = self._manager.list_servers()
        if not servers:
            return "No MCP servers configured."

        lines: list[str] = []
        for s in servers:
            if not s.enabled:
                continue  # hide disabled servers from LLM
            desc = s.description or s.state.value
            tools = f" ({s.tool_count} tools)" if s.tool_count > 0 else ""
            lines.append(f"  {s.name} — {desc}{tools}")

        return (
            f"MCP servers ({len(lines)}):\n"
            + "\n".join(lines)
            + "\n\nCall mcp_connect(server='<name>') to connect."
        )

    def _format_status(self, server: str) -> str:
        info = self._manager.get_server_status(server)
        if info is None:
            return f"Unknown server '{server}'."
        parts = [
            f"Server: {info.name}",
            f"State: {info.state.value}",
            f"Agency: {'yes' if info.is_agency else 'no'}",
            f"Tools registered: {info.tool_count}",
        ]
        if info.protocol_version:
            parts.append(f"Protocol: {info.protocol_version}")
        if info.error:
            parts.append(f"Error: {info.error}")
        return "\n".join(parts)
