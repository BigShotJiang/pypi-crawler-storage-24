"""
Sub-agent spawning tool — create and manage child agent executions.

The tool delegates actual agent creation to a runtime-provided callback
(``spawn_fn``), keeping the tool itself decoupled from runtime internals.
Supports three execution modes:

- **serial**: await a single sub-agent and return its result.
- **parallel**: run multiple agents concurrently (prompt is a JSON array)
  and return all results.
- **background**: start a sub-agent in the background and return a task ID
  for later retrieval.
"""

from __future__ import annotations

import asyncio
import json
import uuid
from collections.abc import Awaitable, Callable
from typing import Any

from loguru import logger

from workpilot.agent.tools.base import Tool, ToolMetadata

# Type alias for the runtime-provided spawn callback.
# Signature: async spawn_fn(agent_name: str, prompt: str) -> str
SpawnFn = Callable[[str, str], Awaitable[str]]


class SpawnTool(Tool):
    """Spawn sub-agents in serial, parallel, or background mode."""

    def __init__(self, spawn_fn: SpawnFn) -> None:
        self._spawn_fn = spawn_fn
        # Track background tasks so callers can retrieve results later.
        self._background_tasks: dict[str, asyncio.Task[str]] = {}

    # ── Tool ABC ────────────────────────────────────────────────────────

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(risk_level="medium", approval="auto", timeout=600)

    @property
    def name(self) -> str:
        return "spawn"

    @property
    def description(self) -> str:
        return (
            "Spawn a sub-agent to handle a task. "
            "Modes: 'serial' (wait for result), 'parallel' (run multiple "
            "agents concurrently — prompt is a JSON array of "
            "{agent, prompt} objects), or "
            "'background' (start and return a task ID)."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "agent": {
                    "type": "string",
                    "description": (
                        "Agent name to spawn (must be defined in config). "
                        "Ignored when mode is 'parallel' — use prompt array instead."
                    ),
                },
                "prompt": {
                    "type": "string",
                    "description": (
                        "Prompt to send to the sub-agent. "
                        "For 'parallel' mode, provide a JSON array of objects "
                        'with "agent" and "prompt" keys.'
                    ),
                },
                "mode": {
                    "type": "string",
                    "enum": ["serial", "parallel", "background"],
                    "description": "Execution mode (default: serial).",
                },
            },
            "required": ["agent", "prompt"],
        }

    async def execute(self, **kwargs: Any) -> str:
        agent: str = kwargs["agent"]
        prompt: str = kwargs["prompt"]
        mode: str = kwargs.get("mode", "serial")

        if mode == "serial":
            return await self._serial(agent, prompt)
        elif mode == "parallel":
            return await self._parallel(prompt)
        elif mode == "background":
            return await self._background(agent, prompt)
        else:
            return f"Error: unknown spawn mode '{mode}'. Use serial, parallel, or background."

    # ── Mode implementations ────────────────────────────────────────────

    async def _serial(self, agent: str, prompt: str) -> str:
        """Await a single sub-agent and return its result."""
        logger.info(f"Spawning agent '{agent}' in serial mode")
        try:
            result = await self._spawn_fn(agent, prompt)
            return result
        except Exception as exc:
            logger.error(f"Serial spawn of '{agent}' failed: {exc}")
            return f"Error: sub-agent '{agent}' failed: {exc}"

    async def _parallel(self, prompt: str) -> str:
        """Run multiple agents concurrently and return all results."""
        try:
            items = json.loads(prompt)
        except json.JSONDecodeError as exc:
            return (
                f"Error: parallel mode requires prompt to be a JSON array "
                f'of {{"agent": ..., "prompt": ...}} objects. Parse error: {exc}'
            )

        if not isinstance(items, list) or not items:
            return "Error: parallel mode requires a non-empty JSON array."

        # Validate each item has agent + prompt.
        for i, item in enumerate(items):
            if not isinstance(item, dict):
                return f"Error: item at index {i} is not an object."
            if "agent" not in item or "prompt" not in item:
                return f"Error: item at index {i} must have 'agent' and 'prompt' keys."

        logger.info(f"Spawning {len(items)} agents in parallel mode")

        async def _run(item: dict[str, str]) -> str:
            try:
                return await self._spawn_fn(item["agent"], item["prompt"])
            except Exception as exc:
                return f"Error ({item['agent']}): {exc}"

        results = await asyncio.gather(*[_run(item) for item in items])

        # Format results with agent names.
        parts: list[str] = []
        for item, result in zip(items, results):
            parts.append(f"[{item['agent']}]\n{result}")

        return "\n\n---\n\n".join(parts)

    async def _background(self, agent: str, prompt: str) -> str:
        """Start a sub-agent in the background and return a task ID."""
        task_id = uuid.uuid4().hex[:12]
        logger.info(f"Spawning agent '{agent}' in background mode (task_id={task_id})")

        async def _run() -> str:
            try:
                return await self._spawn_fn(agent, prompt)
            except Exception as exc:
                error_msg = f"Background agent '{agent}' failed: {exc}"
                logger.error(error_msg)
                return error_msg

        task = asyncio.create_task(_run(), name=f"spawn-{task_id}")
        self._background_tasks[task_id] = task

        return (
            f"Background task started: {task_id}\n"
            f"Agent: {agent}\n"
            f"Use the task ID to check status later."
        )

    # ── Background task management ──────────────────────────────────────

    def get_background_result(self, task_id: str) -> str | None:
        """
        Retrieve the result of a background task, or None if still running.

        This is a synchronous helper the runtime can expose via another
        mechanism (e.g., a ``task_status`` tool or direct API).
        """
        task = self._background_tasks.get(task_id)
        if task is None:
            return None
        if not task.done():
            return None
        return task.result()

    @property
    def pending_tasks(self) -> list[str]:
        """Return IDs of background tasks that are still running."""
        return [tid for tid, task in self._background_tasks.items() if not task.done()]
