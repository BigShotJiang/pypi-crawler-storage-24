"""
Tool registry — central registry for tool discovery and execution.
"""

from __future__ import annotations

import asyncio
import time
from typing import Any

from loguru import logger

from workpilot.agent.tools.base import Tool
from workpilot.bus.events import StreamingChunk
from workpilot.bus.queue import MessageBus
from workpilot.security.audit import AuditLogger
from workpilot.security.leak import redact_credentials

_ERROR_HINT = "\n\n[Analyze the error above and try a different approach.]"

PROTECTED_TOOLS = frozenset(
    {
        "shell",
        "read_file",
        "write_file",
        "edit_file",
        "list_dir",
        "search_files",
        "git",
        "http_request",
        "web_search",
        "web_fetch",
        "browser",
        "spawn",
        "message",
        "cron",
        "gh_copilot",
        "gh_copilot_status",
        "gh_copilot_models",
    }
)


class ToolRegistry:
    """Central tool registry with execution tracking and audit logging."""

    def __init__(self, audit: AuditLogger | None = None) -> None:
        self._tools: dict[str, Tool] = {}
        self._audit = audit or AuditLogger()

    def register(self, tool: Tool) -> None:
        if tool.name in PROTECTED_TOOLS and tool.name in self._tools:
            raise ValueError(f"Cannot override protected built-in tool '{tool.name}'")
        self._tools[tool.name] = tool
        logger.debug(f"Tool registered: {tool.name}")

    def unregister(self, name: str) -> None:
        self._tools.pop(name, None)

    def unregister_prefix(self, prefix: str) -> list[str]:
        """Remove all tools whose names start with *prefix*. Returns removed names."""
        to_remove = [name for name in self._tools if name.startswith(prefix)]
        for name in to_remove:
            del self._tools[name]
        if to_remove:
            logger.debug(f"Unregistered {len(to_remove)} tools with prefix '{prefix}'")
        return to_remove

    def get(self, name: str) -> Tool | None:
        return self._tools.get(name)

    def list_tools(self) -> list[Tool]:
        return list(self._tools.values())

    def get_schemas(self, names: list[str] | None = None) -> list[dict[str, Any]]:
        """Get OpenAI-format tool schemas, optionally filtered by name."""
        tools: list[Tool] = list(self._tools.values())
        if names:
            name_set = set(names)
            tools = [t for t in tools if t.name in name_set]
        return [t.to_openai_schema() for t in tools]

    def scoped_copy(
        self, tool_names: list[str], *, audit: AuditLogger | None = None
    ) -> ToolRegistry:
        """Create a new registry containing only the named tools.

        Used for sub-agent spawning — the child gets a restricted toolset.
        """
        scoped = ToolRegistry(audit=audit or self._audit)
        name_set = set(tool_names)
        for name, tool in self._tools.items():
            if name in name_set:
                scoped._tools[name] = tool
        return scoped

    async def execute(
        self,
        name: str,
        args: dict[str, Any],
        *,
        actor: str = "agent",
        session_id: str | None = None,
        bus: MessageBus | None = None,
        channel: str | None = None,
        channel_id: str | None = None,
        thread_id: str | None = None,
    ) -> str:
        """Execute a tool by name with audit logging and optional progress streaming."""
        tool = self._tools.get(name)
        if tool is None:
            return f"Error: unknown tool '{name}'{_ERROR_HINT}"

        # Pass channel context as kwargs so tools can use it without mutable state.
        # (CopilotDelegateTool reads these for notification routing.)
        if channel and channel_id:
            args.setdefault("_channel", channel)
            args.setdefault("_channel_id", channel_id)
            if thread_id:
                args.setdefault("_thread_id", thread_id)

        # Wire progress callback for streaming-capable tools
        prev_callback = tool._progress
        if tool.metadata.streaming and bus and channel and channel_id:

            async def _progress(text: str) -> None:
                # Redact secrets before streaming to user
                sanitized = redact_credentials(text)
                await bus.dispatch_outbound(
                    StreamingChunk(
                        channel=channel,
                        channel_id=channel_id,
                        content=sanitized,
                        chunk_type="tool_progress",
                    )
                )

            tool.set_progress_callback(_progress)

        start = time.monotonic()
        tool_timeout = getattr(tool.metadata, "timeout", 600)
        try:
            result = await asyncio.wait_for(tool.execute(**args), timeout=tool_timeout) or ""
            elapsed = (time.monotonic() - start) * 1000
            self._audit.log_tool(
                tool=name,
                actor=actor,
                args=args,
                result=result,
                session_id=session_id,
                duration_ms=elapsed,
            )
            return result
        except Exception as exc:
            elapsed = (time.monotonic() - start) * 1000
            error_msg = f"Error executing {name}: {exc}{_ERROR_HINT}"
            logger.error(f"Error executing {name}: {exc}")
            self._audit.log_tool(
                tool=name,
                actor=actor,
                args=args,
                result=str(exc),
                is_error=True,
                session_id=session_id,
                duration_ms=elapsed,
            )
            return error_msg
        finally:
            # Restore previous callback (avoid clearing another in-flight callback)
            tool.set_progress_callback(prev_callback)
