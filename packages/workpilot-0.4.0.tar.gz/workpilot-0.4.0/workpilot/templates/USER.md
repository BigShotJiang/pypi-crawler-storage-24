# User Preferences

<!-- WorkPilot learns your preferences over time. You can also edit this file directly. -->

## Communication

- [ ] Concise responses (default)
- [ ] Detailed explanations
- [ ] Code comments in responses

## Coding Style

- Language: <!-- e.g., Python, TypeScript -->
- Framework: <!-- e.g., FastAPI, React -->
- Formatting: <!-- e.g., ruff, prettier -->
- Testing: <!-- e.g., pytest, jest -->

## Workflow

- [ ] Auto-commit after changes
- [ ] Run tests before committing
- [ ] Create PR descriptions automatically

## Notes

<!-- Add any personal preferences, project conventions, or recurring instructions here. -->
