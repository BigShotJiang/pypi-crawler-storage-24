# Periodic Tasks

<!-- Define recurring tasks that WorkPilot should execute on a schedule. -->
<!-- Each task needs a cron expression and a prompt describing the action. -->

<!--
## Example: Daily Summary
- Schedule: 0 9 * * 1-5  (weekdays at 9 AM)
- Prompt: Summarize yesterday's git commits and open PRs for this repository.
- Channel: cli

## Example: Health Check
- Schedule: */30 * * * *  (every 30 minutes)
- Prompt: Check if the dev server is running and report any errors from the last 30 minutes.
- Channel: cli
-->
