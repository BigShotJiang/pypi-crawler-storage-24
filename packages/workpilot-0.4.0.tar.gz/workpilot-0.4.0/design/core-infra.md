# WorkPilot — Core & Infrastructure Specification

> **Status**: Draft v6
> **Date**: 2026-02-28
> **Based on**: OpenClaw, nanobot, NanoClaw, IronClaw, ZeroClaw

One document. Protocols, core mechanisms, architecture. Simple and safe.

---

## 1. Design Principles

| Principle | Description |
|-----------|-------------|
| **Protocol-first** | Every subsystem boundary is an abstract protocol. Implementations registered at runtime. Swappable, testable. |
| **Safe by default** | Sandbox, leak detection, E-stop, audit — all on. Extended capabilities opt-in. |
| **Tools execute, Skills instruct** | Built-in tools, MCP tools, and sub-agent calls share the Tool protocol. Skills are prompt overlays (SKILL.md) — the LLM reads instructions and uses tools autonomously. |
| **Hooks at boundaries** | Pre/post interception at tool execution and message flow. Fixed safety checkpoints, not a plugin system. |
| **Ecosystem compatible** | Skill format (SKILL.md), identity files (CLAUDE.md), MCP protocol — interoperable with OpenClaw/nanobot ecosystem. Memory (MEMORY.md) follows nanobot convention. |

---

## 2. Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Transport Layer                            │
│                                                              │
│   Channel ──── Channel ──── Channel ──── Gateway             │
│   Protocol     Protocol     Protocol     (REST/SSE/WS)       │
│                                                              │
└──────────────────────────┬──────────────────────────────────┘
                           │
┌──────────────────────────▼──────────────────────────────────┐
│                    Message Bus                                │
│   Async queues (in/out) + typed event pub/sub                │
└──────────────────────────┬──────────────────────────────────┘
                           │
┌──────────────────────────▼──────────────────────────────────┐
│                    Processing Layer                           │
│                                                              │
│   Agent Loop                                                 │
│     Research → Context → LLM ↔ Tool Loop → Response          │
│     Can spawn Sub-Agents (scoped context, same loop)         │
│                                                              │
│   ┌──────────────────────────┐  ┌────────────────────┐      │
│   │     Tool Registry        │  │   Skills (SKILL.md) │      │
│   │  Built-in │ MCP │ Spawn  │  │   Prompt overlays   │      │
│   │                          │  │   loaded into LLM   │      │
│   │  Hook pipeline:          │  │   context. LLM      │      │
│   │  pre_tool → execute →    │  │   reads and uses    │      │
│   │  post_tool               │  │   tools to execute. │      │
│   └──────────────────────────┘  └────────────────────┘      │
└─────────────────────────────────────────────────────────────┘
                           │
┌──────────────────────────▼──────────────────────────────────┐
│                    Foundation Layer                           │
│                                                              │
│  Provider │ Memory │ Session │ Security │ Observer │ Config   │
│  Protocol │ Protocol│ Protocol│ Services │ Protocol │ (root)  │
│           │        │         │ E-Stop   │          │          │
└─────────────────────────────────────────────────────────────┘
```

---

## 3. Message Bus

> **Full spec**: [core/message-bus.md](core/message-bus.md) — queues, event bus, message types, routing, backpressure

Three components: **Inbound Queue** (channel → agent), **Outbound Queue** (agent → channel), **Event Bus** (typed pub/sub for cross-subsystem coordination).

| Component | Type | Capacity | Pattern |
|-----------|------|----------|---------|
| Inbound | asyncio.Queue[InboundMessage] | 100 (bounded) | nanobot dual-queue |
| Outbound | asyncio.Queue[OutboundMessage \| StreamingChunk] | 100 (bounded) | nanobot dual-queue |
| Event Bus | async pub/sub | fire-and-forget | IronClaw StatusUpdate-inspired |

Messages processed sequentially (one at a time, processing lock). Events are fire-and-forget (handlers run as separate tasks). 15+ typed event types for security alerts, tool execution, cost, health, memory, sessions.

---

## 4. Protocols

### 4.1 Subsystem Lifecycle

| Method | Description |
|--------|-------------|
| `start()` | Async init |
| `stop()` | Graceful shutdown |
| `health() → HealthStatus` | healthy / degraded / unhealthy |

Runtime registers subsystems with dependencies. Start in order, stop in reverse.

### 4.2 Channel

| Method | Description |
|--------|-------------|
| `start()` | Begin listening |
| `stop()` | Stop, drain in-flight |
| `send(OutboundMessage)` | Deliver to external surface |
| `supports_streaming → bool` | Whether channel supports token-by-token delivery |
| `health()` | Connection status |

Channels normalize input into `InboundMessage` and publish to Bus. Each operates independently.

### 4.3 Gateway

The Gateway is a special channel that serves HTTP:

- **REST API** — send prompts, list sessions, manage config
- **SSE / WebSocket** — real-time streaming delivery
- **Webhook ingestion** — receive events from external systems
- **Auth middleware** — token validation (Entra ID / API key)
- **Rate limiting** — per-client request throttling
- **E-stop** — returns 503 when halted

### 4.4 Tool

> **Full spec**: [core/tool.md](core/tool.md) — protocol, approval mechanism, registry, security boundary

| Method | Description |
|--------|-------------|
| `name → str` | Unique identifier |
| `description → str` | For LLM prompt inclusion |
| `parameters → dict` | JSON Schema for inputs |
| `validate(args) → list[str]` | Validate args against schema (nanobot pattern) |
| `execute(args) → ToolResult` | Run, return `{success, output, error}` (ZeroClaw pattern) |
| `metadata → ToolMetadata` | risk_level, isolation, category, approval, timeout, streaming |

**Approval**: Two-layer — tool declares `never / auto / always`, `auto` tools go through Security Agent (fast LLM) for arg-level classification. See [core/tool.md](core/tool.md) Section 3.

**Pipeline**: `pre_hook → validate → approval → security boundary → execute (with timeout + cancel) → post_hook → ToolResult`

**Registry**: register/unregister/replace at runtime. Anti-shadowing for built-in tools (IronClaw pattern).

### 4.5 Provider

| Method | Description |
|--------|-------------|
| `complete(model, messages, tools?, ...) → LLMResponse` | Batch mode |
| `stream(model, messages, tools?, ...) → AsyncIterator[LLMChunk]` | Streaming mode |

**LLMResponse**: content, tool_calls, usage (prompt/completion tokens), model, provider.
**LLMChunk**: delta_content, delta_tool_calls, usage, done.

Wrapped by **ReliableProvider**:

| Mechanism | Description |
|-----------|-------------|
| **Circuit breaker** | Per-provider: Closed → Open (after N failures) → Half-Open (after timeout). Falls to next in fallback chain. |
| **Cost tracker** | Records tokens + estimated USD per request. Emits warning events when cost is high. |
| **Auto-compress** | On ContextLengthExceeded: summarize older messages, keep recent N, retry once. |

### 4.6 Memory

Two-tier: **Facts** (always in LLM context) + **History** (searchable archive).

#### Facts Store (MEMORY.md — nanobot convention)

| Method | Description |
|--------|-------------|
| `read() → str` | All facts as string |
| `write(content)` | Replace atomically |
| `consolidate(new_facts)` | Merge, dedup, prune stale |

Optimized Markdown file. LLM organizes sections dynamically. Bounded size (default 8KB), atomic writes. Same convention as nanobot MEMORY.md.

#### History Store

| Method | Description |
|--------|-------------|
| `store(content, metadata) → id` | Persist record |
| `search(query, limit) → list[Entry]` | Relevance-ranked search |
| `get(id) → Entry` | Retrieve |
| `delete(id)` | Remove |

Default: SQLite with FTS5 (BM25). Optional: hybrid search (FTS5 + vector embeddings).

### 4.7 Session

| Method | Description |
|--------|-------------|
| `get_messages(session_id)` | Retrieve history |
| `add_message(session_id, message)` | Append |
| `trim(session_id, keep)` | Remove oldest |
| `clear(session_id)` | Delete |
| `fork(session_id) → new_id` | Branch for sub-agents |

Default: JSONL append-only.

### 4.8 Skill (SKILL.md — prompt overlay, not executable code)

> **Full spec**: [core/skill.md](core/skill.md) — format, discovery, security, lifecycle

A Skill is a **prompt text document** (SKILL.md) that teaches the LLM how to perform a specific task using existing tools. Skills are NOT executable code — the LLM reads the instructions and decides which tools to call. This is the proven pattern across all 5 reference projects.

**How skills work:**
1. Skills loaded into LLM context via progressive disclosure (summary always present, full content on demand)
2. LLM reads instructions and autonomously uses tools to execute
3. No "Skill Engine" running steps — the LLM IS the engine

**Format**: SKILL.md with YAML frontmatter (OpenClaw convention, used by 4/5 projects).

**Bundled skills** are read-only. **Workspace skills** are user-editable.

### 4.9 Observer

| Method | Description |
|--------|-------------|
| `counter(name, value, labels)` | Increment |
| `gauge(name, value, labels)` | Set |
| `histogram(name, value, labels)` | Record |

Backends: Log (default), Prometheus (opt-in), OTLP (opt-in).

### 4.10 Scheduler

> **Full spec**: [core/scheduler.md](core/scheduler.md) — triggers, job definition, execution model, heartbeat, HEARTBEAT.md, CronTool

| Method | Description |
|--------|-------------|
| `start()` | Load jobs (config + dynamic), register heartbeat, start APScheduler |
| `stop()` | Graceful shutdown, wait for running jobs |
| `add_job(job)` | Register a job |
| `remove_job(job_id)` | Remove |
| `enable(job_id)` / `disable(job_id)` | Toggle without removing |
| `run_now(job_id)` | Force immediate execution |
| `list_jobs()` | All jobs with status, next_run time |
| `health()` | Scheduler state, active jobs, failure counts |

9 methods — matches [core/scheduler.md](core/scheduler.md) Section 2.

Triggers: **cron expression**, **interval** (seconds), **event** (Bus EventType match). Jobs executed via `AgentLoop.run_once()` — tool hooks (pre/post_tool_use) and security apply. Results delivered to notify_channels by the SchedulerService.

**Session modes**: `isolated` (fresh per run) or `persistent` (context across runs). Results delivered to `notify_channels` (empty = log only).

**Heartbeat**: Built-in interval job (default: every 30 min). Reads HEARTBEAT.md (nanobot pattern — LLM decides whether to act).

**CronTool**: Built-in tool letting the agent manage its own scheduled jobs at runtime (nanobot pattern).

---

## 5. Agent Loop

> **Full spec**: [core/agent.md](core/agent.md) — loop structure, context assembly, iteration management, research phase, compaction, loop detection, streaming, error recovery

```
Message → hook → Research → Context Assembly → LLM ↔ Tool Loop → hook → Session persist
```

| Aspect | Design | Source |
|--------|--------|--------|
| Loop core | While loop, ≤ max_iterations (default 40) | nanobot (~40 lines) |
| Research phase | Pre-loop workspace/memory search, read-only | ZeroClaw (only project with this) |
| Context order | system → facts → skills → research → history → user | Cache-friendly (OpenClaw insight) |
| Iteration limit | Graceful: nudge → force-text → hard stop | IronClaw 3-stage |
| Auto-compaction | 3-tier at 80/85/95% of context limit | IronClaw |
| Loop detection | 3 detectors (repeat, poll, ping-pong) | OpenClaw + ZeroClaw |
| Streaming | Provider.stream() → channel, tool progress | All projects |
| Error recovery | Skip error history, auto-compact on overflow, loop detect | nanobot + IronClaw + ZeroClaw |
| Parallel tools | IronClaw 3-phase: preflight → parallel execute → postflight | IronClaw |

---

## 6. Hooks

Four hook points — the minimum set for safety and observability:

| Hook | When | Can do |
|------|------|--------|
| `on_message_received` | Inbound message arrives | Inspect, filter, reject (prompt injection scan) |
| `pre_tool_use` | Before tool execution | Reject, modify args, prompt for approval |
| `post_tool_use` | After tool execution | Modify result, trigger alerts |
| `on_message_sent` | Before outbound delivery | Inspect, redact (outbound leak scan) |

**Hook handler contract**: `handler(context) → Allow | Reject | Skip`. Handlers execute in priority order. First Reject wins.

**Built-in handlers** (always registered):

| Hook | Handler | What it does |
|------|---------|-------------|
| `on_message_received` | Injection scanner | Detect prompt injection patterns |
| `pre_tool_use` | E-stop gate | Reject if halted |
| `pre_tool_use` | Policy gate | RBAC permission check |
| `pre_tool_use` | Approval gate | Two-layer: tool declaration + Security Agent (see [core/tool.md](core/tool.md) Section 3) |
| `post_tool_use` | Leak scanner | Detect credentials in output |
| `post_tool_use` | Redactor | Replace secrets with [REDACTED] |
| `post_tool_use` | Auditor | Log to audit trail |
| `on_message_sent` | Outbound leak scan | Scan response for credentials |

---

## 7. Sub-Agents

A sub-agent is a scoped Agent Loop instance, invoked as a tool call.

```
Parent LLM → calls "spawn" tool → SpawnTool creates child AgentLoop:
  - Scoped instructions (task-specific)
  - Forked session (fresh context — no parent history, linked for tracking)
  - Scoped tool set (subset of parent's, never more)
  - Scoped permissions (never more permissive than parent)
  - Own iteration budget
  ↓
Child runs independently → returns result to parent as tool output
```

**Rules:**
- Permissions can only be restricted, never escalated
- Max spawn depth configurable (default 2 — sub-agents can spawn one level of sub-sub-agents)
- Shared E-stop — if triggered, all agents halt
- Parallel fan-out: parent can spawn multiple sub-agents in one LLM turn

---

## 8. MCP Bridge

```
MCP Server (external) ↔ stdio/HTTP ↔ MCP Client (WorkPilot)
  ↓
Each MCP tool wrapped as Tool protocol adapter (prefixed name, e.g., "server.tool")
  ↓
Registered in Tool Registry — same hooks, same security boundary
```

MCP tools are **untrusted by default**: leak scan, policy check, configurable timeout (default 30s), isolation escalatable by security profile.

**Hot-reload**: MCP servers can connect/disconnect at runtime.

**WorkPilot as MCP Server**: Exposes configured tool subset via MCP protocol (stdio or HTTP). Inbound requests pass through the same hook pipeline.

---

## 9. Security

### 9.1 Isolation (2 levels)

| Level | How | Default for |
|-------|-----|-------------|
| `process` | In-process with sandbox guards (command deny-patterns, path restriction, env filtering, output limit) | Built-in tools |
| `container` | Ephemeral Docker container. Mounted workspace subset (read-only default). Non-root. CPU/memory limits. | Opt-in for untrusted tools |

Security profile escalation (never relaxation):

| Profile | Built-in | MCP | Sub-agent |
|---------|---------|-----|-----------|
| `open` | process | process | process |
| `standard` | process | process | process |
| `controlled` | process | process | process |
| `restricted` | process | container | process |

### 9.2 Credential Injection

Credentials flow inward (host → tool boundary), never outward:

| Level | How |
|-------|-----|
| `process` | Sandbox strips all secrets from env except explicitly allowed for this tool |
| `container` | Credentials passed as Docker secrets. Host env never mounted. Ephemeral — destroyed on exit |

Leak Detector scans all tool output for accidentally included credentials.

### 9.3 Security Services

| Service | What |
|---------|------|
| **Sandbox** | Command deny-patterns + path restriction + SSRF protection (block localhost/private IP in HTTP tool) |
| **Audit Logger** | Append-only log + auto secret redaction |
| **Policy Engine** | RBAC + autonomy levels + security profiles |
| **Approval Gate** | Human-in-the-loop for high-risk ops |
| **Leak Detector** | Credential pattern scan (JWT, AWS, GitHub PAT, OpenAI, Slack, high-entropy) |
| **Sanitizer** | Prompt injection + log injection defense |
| **Credential Store** | Abstraction over env / .env / vault |

### 9.4 E-Stop

Global halt. Triggers: manual (CLI/API) or automatic (leak detection, configurable).

Behavior: `halted` flag set → all agent loops exit → tool registry rejects → gateway 503 → audit logs → notification → stays halted until explicit reset by authorized actor.

### 9.5 Security Profiles

| Profile | Sandbox | Approval | Leak Detection | E-Stop | Sub-Agents |
|---------|---------|----------|---------------|--------|------------|
| `open` | Standard | Minimal | On | Manual only | Allowed |
| `standard` | Standard | Medium-risk ops | On | Auto on leak | Allowed |
| `controlled` | Standard | All ops (Security Agent) | On | Auto on leak | Allowed |
| `restricted` | Strict | All ops (human required) | On | Auto on leak | Disabled |

---

## 10. Memory Management

### 10.1 Facts (MEMORY.md)

```
Conversation flows → consolidation trigger → LLM extracts facts →
merge + dedup + prune stale → enforce size cap → atomic write
```

LLM organizes sections dynamically (no prescribed headings).
Bounded (8KB default). Never compressed. Always in LLM context.

### 10.2 History (SQLite)

Stores: messages, tool calls, security events, consolidation records.
Search: FTS5 + BM25 (default). Optional hybrid with vector embeddings.
GC: configurable TTL (default 90 days).

### 10.3 Context Window

1. Proactive: when messages exceed threshold, summarize oldest, keep recent N
2. Reactive: on ContextLengthExceeded, compress aggressively, retry once
3. Facts never compressed — bounded by design

---

## 11. Ecosystem Compatibility

| Aspect | Convention source | WorkPilot | Compatibility |
|--------|------------------|-----------|---------------|
| Memory (MEMORY.md) | nanobot | MEMORY.md (Markdown) | Direct |
| Identity (CLAUDE.md) | OpenClaw / nanobot | CLAUDE.md | Direct |
| Skill (SKILL.md) | OpenClaw / NanoClaw | SKILL.md + YAML frontmatter | Direct |
| MCP protocol | Standard (all 5 projects) | Native MCP client + server | Standard |
| Channel model | OpenClaw (allowlist + pairing) | Allowlist + RBAC | Superset |
| Session | nanobot (JSONL) | JSONL per-session | Direct |
| Tool model | All 5 (JSON Schema) | JSON Schema + hooks | Superset |
| Hooks | NanoClaw (PreToolUseHook) | pre/post_tool_use + message hooks | Similar |

**What this means:**
- nanobot/OpenClaw SKILL.md files can be loaded by WorkPilot's Skill Loader
- MEMORY.md content is portable (nanobot convention)
- MCP servers configured for any project work with WorkPilot unchanged
- WorkPilot adds enterprise features (RBAC, audit, security profiles, E-stop) on top

---

## 12. Configuration

| Section | Key fields |
|---------|-----------|
| `providers` | Per-provider credentials (SecretStr), aliases, fallback chain |
| `agents` | Per-agent: model, instructions, tools, skills, permissions, max_iterations (default 40) |
| `memory` | facts_backend, history_backend, search_mode, embedding config |
| `reliability` | circuit_breaker, cost_tracking, auto_compress |
| `security` | profile (open/standard/controlled/restricted), audit, roles, approval |
| `estop` | enabled, trigger_on_leak, notify_channels |
| `isolation` | default_level, per_tool overrides, container_image |
| `hooks` | Additional handler registrations |
| `mcp_servers` | Per-server: command/url, timeout, risk_level |
| `skills` | directory |
| `channels` | Per-channel: enabled, auth config |
| `gateway` | host, port, auth, rate_limit |
| `cron` | Per-job: schedule, agent, prompt |
| `observability` | metrics_backend, trace_backend |
| `logging` | level, format, file |

Resolution: defaults → `workpilot.yaml` → `workpilot.local.yaml` → `WORKPILOT_*` env.

**Hot-reload**: Provider credentials and MCP server connections support hot-reload without restart.

---

## 13. Implementation Priority

| Phase | Component | Why |
|-------|-----------|-----|
| **1** | Config + Subsystem lifecycle | Foundation |
| **2** | E-stop + Leak detector | Safety before anything runs |
| **3** | Hooks engine (4 hooks + built-in handlers) | Safety expressed as hooks |
| **4** | Tool protocol + Registry + Sandbox | Core execution |
| **5** | Provider + ReliableProvider (streaming) | LLM with circuit breaker |
| **6** | Memory (Facts + History) | Searchable knowledge |
| **7** | Session + context compression | Conversation management |
| **8** | Message Bus + event pub/sub | Subsystem coordination |
| **9** | Agent Loop + CLI channel | Main engine + basic transport for testing |
| **10** | Sub-agent spawning | Delegation |
| **11** | MCP bridge | External tools |
| **12** | Skill loader (SKILL.md discovery + context injection) | Prompt overlays |
| **13** | Scheduler + heartbeat | Automation |
| **14** | Gateway | HTTP surface |
| **15** | Observer + metrics | Monitoring |
| **16** | Additional channels | External transports |
