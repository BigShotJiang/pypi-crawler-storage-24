# Cloud Gateway — Teams App Package

**Date**: 2026-03-04
**Status**: Implemented (`teams/`)

---

## 1. Purpose

The Teams app package (`WorkPilot-teams-app.zip`) is the installable artifact
that adds WorkPilot as a bot in Microsoft Teams and Outlook.
Users upload it once. No Azure portal access is needed by end users.

Current capability:

| Capability | Surface | Description |
|---|---|---|
| **Personal bot** | Teams 1:1 chat · Outlook | Conversational bot messages |

Planned:

| Capability | Surface | Notes |
|---|---|---|
| **Personal tab (dashboard)** | Teams sidebar · Outlook sidebar | Future — not yet implemented |

---

## 2. Package Contents

```
WorkPilot-teams-app.zip
├── manifest.json       — Teams app manifest (v1.17)
├── color.png           — 192×192 brand icon (rendered from logo.svg)
└── outline.png         — 32×32 transparent outline icon (from logo-outline.svg)
```

Source files in `teams/`:
- `logo.svg` / `logo-outline.svg` — canonical SVG design sources (edit these; export PNGs manually)
- `build.ps1` / `build.sh` — one-command package builder

---

## 3. Manifest Fields

### Identity

| Field | Value | Notes |
|---|---|---|
| `id` | `cfcdde49-617a-4fbd-bf0f-7c3bab131982` | Fixed Teams app GUID — never changes |
| `version` | `0.1.5` | Must match `workpilot.__version__`; bump on every release |
| `manifestVersion` | `1.17` | Latest stable Teams schema |
| `defaultInstallScope` | `personal` | Pre-selects personal scope in the install dialog |
| `accentColor` | `#464775` | WorkPilot brand purple |

### AAD / SSO

```json
"webApplicationInfo": {
  "id":       "98647cd1-f31c-46e7-ad1a-b65f742a54bf",
  "resource": "api://botid-98647cd1-f31c-46e7-ad1a-b65f742a54bf"
}
```

Links the app to the Azure AD app registration so Teams and Outlook can
establish SSO context. The `resource` URI follows the Bot Framework convention
`api://botid-{botId}`.

### Bot

```json
"bots": [{
  "botId":  "98647cd1-f31c-46e7-ad1a-b65f742a54bf",
  "scopes": ["personal"]
}]
```

`scopes: ["personal"]` — 1:1 chat with the bot only.
The `botId` must match `MicrosoftAppId` in `appsettings.json`.

> **Dev environment**: `appsettings.json` uses placeholder
> `"MicrosoftAppId": "__set_in_app_settings__"` — set this to the actual bot
> App Registration ID in Azure App Service Application Settings.
> The dev manifest uses `98647cd1-...` which serves as both the MSAL client app
> and the bot identity in the dev environment.

> **`Teams:Enabled`** must be `true` in appsettings for the `/bot/teams` endpoint
> to be registered (defaults to `false`).

### Bot commands

| Command | Description |
|---|---|
| `help` | Show what WorkPilot can do |
| `status` | Check if your WorkPilot agent is online |

### Valid Domains

```json
"validDomains": ["workpilot-gw-dev.azurewebsites.net"]
```

Update to the production hostname when deploying to production.

### botId vs Teams app id

| ID | What | Lifetime |
|---|---|---|
| `manifest.id` | Teams app identity in the catalogue | Fixed forever |
| `bots[].botId` + `webApplicationInfo.id` | Azure AD app registration | Per-environment |

---

## 4. Icons

| File | Size | Source | Content |
|---|---|---|---|
| `color.png` | 192×192 | `logo.svg` | Dark square bg (`#0D1117`), neon W-shape strokes, diamond spark |
| `outline.png` | 32×32 | `logo-outline.svg` | Transparent bg, simplified neon-stroke outline |

Edit the SVG files in Inkscape/Figma to change the design, then export the PNGs at the required sizes and commit them.

---

## 5. Building the Package

```powershell
# Windows
cd teams\
.\build.ps1
```

```bash
# macOS / Linux
cd teams/
chmod +x build.sh && ./build.sh
```

Both scripts:
1. Validate `manifest.json`, `color.png`, and `outline.png` exist
2. Zip into `WorkPilot-teams-app.zip`

---

## 6. Installation

### Sideload (developer / small team)

1. Teams → Apps → **Manage your apps** → Upload a custom app
2. Select `WorkPilot-teams-app.zip` → Add

### Enterprise (IT admin)

1. Teams Admin Center → Teams apps → Manage apps → **Upload**
2. Configure availability policy (specific users / all)
3. Users find WorkPilot in the org catalogue — no sideload needed

---

## 7. Environment-Specific Fields

The committed manifest targets **dev**. For each environment, update:

| Field | Dev | Production |
|---|---|---|
| `bots[].botId` + `webApplicationInfo.id` | `c5bdcb9d-...` | `<MicrosoftAppId>` from appsettings |
| `webApplicationInfo.resource` | `api://botid-c5bdcb9d-...` | `api://botid-<MicrosoftAppId>` |
| `developer.*Url` | dev URLs | prod URLs |
| `validDomains` | `workpilot-gw-dev.azurewebsites.net` | `<prod-host>` |

---

## 8. Version Bumping

When `workpilot.__version__` increments:
1. Update `manifest.json` → `version`
2. Rebuild: `.\build.ps1` or `./build.sh`
3. Commit `manifest.json` + zip

Teams requires `version` to increase for updates to propagate to existing installs.

---

## 9. Future: Personal Tab (Dashboard)

A personal tab will be added once the cloud portal / dashboard is implemented.
It will surface as a sidebar entry in Teams and Outlook.

Planned manifest addition:
```json
"staticTabs": [{
  "entityId":   "workpilot-dashboard",
  "name":       "WorkPilot",
  "contentUrl": "https://<host>/dashboard",
  "websiteUrl": "https://<host>/dashboard",
  "scopes":     ["personal"]
}]
```
