# Cloud Gateway — Azure Bot Web Chat Integration

**Date**: 2026-03-03
**Status**: Approved
**Related**: [server.md](server.md)

---

## 1. Purpose

Add a standard Web Chat UI to Cloud Gateway so browser users can chat with their WorkPilot
agent without writing custom client-side JavaScript. The integration uses Microsoft's
maintained [`botframework-webchat`](https://github.com/microsoft/BotFramework-WebChat) React
component and Azure Bot Service's DirectLine channel.

---

## 2. Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         Browser                                  │
│  GET /webchat/ui (anonymous)                                     │
│      │ MSAL.js loginPopup → AAD popup window → id-token         │
│      ▼                                                           │
│  POST /webchat/directline/token                                  │
│      │ Authorization: Bearer <AAD id-token>                      │
│      │ MsalBrowser JwtBearer validates id-token (aud=clientId)  │
│      │ receives { token, conversationId }                        │
│      │                                                           │
│      │ DirectLine v3.0 (HTTPS + WSS)                            │
│      ▼                                                           │
│  Azure Bot Service (DirectLine channel)                          │
└─────────────────────────────────────────────────────────────────┘
         │
         │  Bot Framework Activity (POST /bot/teams)
         ▼
   Cloud Gateway /bot/teams
         │
         ▼
   WorkPilotAgent.HandleTeamsMessageAsync
         │  IMessageDelivery
         ▼
   WorkPilot Python client (/connect WSS)
         │  ResponseFrame
         ▼
   Cloud Gateway OutboundRouter
         │  TeamsReplyService → Bot Connector REST API
         ▼
   Azure Bot Service → DirectLine → Browser
```

**Key insight:** The existing `/bot/teams` endpoint, `WorkPilotAgent`, and `TeamsReplyService`
are reused without modification. Cloud Gateway only adds:
- `POST /webchat/directline/token` — server-side token exchange
- `GET /webchat/ui` — static HTML page with botframework-webchat

---

## 3. Token Generation Flow

```
Browser                 Cloud Gateway             DirectLine API
   │                         │                         │
   │  MSAL.js loginPopup()   │                         │
   │◄──── AAD popup ─────────│(AAD handles login)      │
   │      → AAD id-token     │                         │
   │                         │                         │
   │  POST /webchat           │                         │
   │  /directline/token      │                         │
   │  Authorization:         │                         │
   │  Bearer <AAD id-token> ─►│                         │
   │                         │ MsalBrowser JwtBearer   │
   │                         │ validates id-token,     │
   │                         │ extracts oid + upn      │
   │                         │── POST tokens/generate ─►│
   │                         │   Bearer {Secret}        │
   │                         │   user.id = "dl_{oid}"   │
   │                         │◄── { token, convId } ───│
   │◄── { token, convId } ───│                         │
   │                         │                         │
   │── WebChat.createDirectLine({ token }) ──────────────►│
   │◄──────────── DirectLine WSS established ────────────│
```

The DirectLine `Secret` (a Web Chat channel key from Azure Bot Service) is **never sent to
the browser**. Only the short-lived scoped `token` (~30 min TTL) is returned.

---

## 4. Static UI Page

`GET /webchat/ui` is **anonymous** (`AllowAnonymous`) — MSAL.js handles authentication
entirely client-side via a popup window. The page returns HTML that:

1. Calls `POST /webchat/directline/token` on load
2. Passes the token to `WebChat.renderWebChat()` from the botframework-webchat CDN bundle
3. Shows a loading spinner while the token is fetched
4. Shows an error message if the token endpoint returns 503 (DirectLine not configured)

The page is intentionally minimal — just enough to host the Web Chat widget. Production
operators can style it or embed it in a larger SPA.

---

## 5. Security Model

| Concern | Mitigation |
|---------|------------|
| DirectLine Secret exposure | Secret stored only in App Setting / Key Vault; never returned to browser |
| Token scope | Token bound to user: `"id": "dl_{oid}"` — prevents user impersonation |
| Cross-origin | `trustedOrigins` set from `DirectLine:TrustedOrigin` config (not from request Host) |
| Auth — `/webchat/ui` | `AllowAnonymous` — MSAL.js popup handles auth entirely client-side |
| Auth — `/webchat/directline/token` | `WebChatBrowserUser` policy — validates MSAL.js id-token via `MsalBrowser` JwtBearer scheme (`aud = clientId GUID`) |
| Dev safety | `DirectLine:Enabled=false` by default; endpoints are not registered when disabled |
| Secret storage | Use Azure Key Vault reference for `DirectLine__Secret` in production App Settings |

**Key Vault reference pattern** (production):
```
DirectLine__Secret = @Microsoft.KeyVault(VaultUri=https://{kv}.vault.azure.net;SecretName=directline-secret)
```

---

## 6. Configuration Reference

### `appsettings.json`
```json
"DirectLine": {
  "Enabled": false,
  "Secret": ""
}
```

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `DirectLine:Enabled` | bool | `false` | Enable `/webchat/directline/token` and `/webchat/ui` endpoints |
| `DirectLine:Secret` | string | `""` | Web Chat channel DirectLine secret from Azure Bot Service |

**Auto-enable**: The `app-service.bicep` module sets `DirectLine__Enabled=true` automatically
when `directLineSecret` parameter is non-empty.

### Obtaining the DirectLine Secret

1. Azure Portal → Bot Service resource → Channels → Web Chat
2. Copy the **Secret key** from the Default Site
3. Store in Azure Key Vault: `az keyvault secret set --vault-name {kv} --name directline-secret --value {secret}`
4. Add Key Vault reference to App Service App Settings

---

## 7. Bicep Changes

### `infra/modules/bot-service.bicep`
Added `WebChatChannel` resource (alongside existing `MsTeamsChannel`):
```bicep
resource webChatChannel 'Microsoft.BotService/botServices/channels@2022-09-15' = {
  parent: botService
  name: 'WebChatChannel'
  properties: {
    channelName: 'WebChatChannel'
    properties: { isEnabled: true, sites: [{ siteName: 'Default Site', isEnabled: true }] }
  }
}
```

### `infra/modules/app-service.bicep`
Added `@secure() param directLineSecret string = ''` and two app settings:
- `DirectLine__Enabled` — set to `'true'` when secret is non-empty
- `DirectLine__Secret` — the secret value (empty by default)

### `infra/main.bicep`
Added `@secure() param directLineSecret string = ''`, passed to `appService` module.

### `infra/parameters/{dev,prod}.bicepparam`
```bicep
param directLineSecret = readEnvironmentVariable('DIRECTLINE_SECRET', '')
```
Set `DIRECTLINE_SECRET` in the azd environment or CI pipeline before provisioning.

---

## 8. Endpoints

### `POST /webchat/directline/token`

**Auth**: `WebChatBrowserUser` policy — validates the AAD id-token issued by MSAL.js
(`MsalBrowser` JwtBearer scheme, `aud = AzureAd:ClientId` GUID). In development the bypass
Bearer token (`dev-bypass`) is also accepted so unit tests can reach the handler.

**Request**: empty body

**Response 200 — success**:
```json
{
  "token": "eyJ...",
  "conversationId": "abc123def456",
  "expiresIn": 1800
}
```

**Response 503 — not configured**:
```json
{
  "error": "directline_unavailable",
  "message": "Web Chat is not configured. Contact your administrator."
}
```

### `GET /webchat/ui`

**Auth**: `AllowAnonymous` — MSAL.js popup handles authentication entirely client-side.
No server-side session cookie or OIDC redirect is involved.

**Response**: `text/html` page with embedded MSAL.js + botframework-webchat.
Endpoint is not registered (→ 404) when `DirectLine:Enabled=false` or `AzureAd:ClientId`/`TenantId` are empty.

### `GET /webchat/auth`

**Auth**: `AllowAnonymous`

**Response**: Blank HTML page (no scripts). Used as the MSAL popup `redirectUri` so the
popup window closes cleanly after AAD redirects back without re-running MSAL init code.

---

## 9. Limitations

| Limitation | Detail |
|-----------|--------|
| **No streaming** | Teams channel has no streaming API. Chunks are buffered by `StreamingChunkBuffer` until `done=true`, then sent as one reply. Browser sees the complete response at once, not token by token. |
| **~1 s latency** | DirectLine adds one extra hop vs the custom `/webchat` WSS endpoint. Not noticeable for most conversations. |
| **No typing indicator (Web Chat only)** | DirectLine Web Chat does not display typing indicators from the `typing` frame. Teams typing indicators are supported. |
| **Session key** | Activities arrive via `/bot/teams` and are handled by `WorkPilotAgent`, which assigns `cloud_teams:{oid}:{conversationId}` (Teams format). DirectLine `from.id = "dl_{oid}"` is mapped to the Entra OID; Web Chat and Teams conversations therefore share the same session-key namespace and conversation history. |
| **Rate limits** | Governed by Azure Bot Service / DirectLine limits, not Cloud Gateway's `RateLimitMiddleware`. |
| **Offline buffer** | `IOfflineBuffer` is not used for this channel; Azure Bot Service handles message delivery. |
