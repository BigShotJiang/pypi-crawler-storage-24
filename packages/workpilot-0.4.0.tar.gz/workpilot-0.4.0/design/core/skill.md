# Skill Protocol

> **Type**: Core Infrastructure
> **Date**: 2026-02-28
> **Parent**: [core-infra.md](../core-infra.md) Section 4.8

---

## Reference (from actual source code)

| Dimension | nanobot | OpenClaw | NanoClaw | IronClaw | ZeroClaw |
|-----------|---------|---------|----------|----------|----------|
| **What is a skill** | Prompt text | Prompt text + resources | Code transformation | **Trust-gated prompt** | Prompt OR WASM code |
| **Format** | **SKILL.md + YAML frontmatter** | **SKILL.md + YAML frontmatter** | manifest.yaml + source | **SKILL.md + YAML frontmatter** | SKILL.md or SKILL.toml |
| **Skill vs Tool** | Prompt teaches tool usage | Prompt teaches tool usage | Package modifies app | Prompt with trust-gated tools | Prompt OR new tool def |
| **Who runs steps** | **LLM decides** | **LLM decides** | Hybrid (engine + LLM) | **LLM decides** (trust-constrained) | LLM (prompt) or runtime (WASM) |
| **Discovery** | Summary in system prompt, load on demand | 3-tier progressive disclosure | User slash command | **Deterministic keyword/regex scoring** | Injected into system prompt |
| **Stateful** | No | No | Yes (install state) | No | No |
| **Security** | requires.bins/env | requires.bins/env | Manifest validation | **Trust attenuation + anti-gaming** | Security audit |
| **Count** | ~8 built-in | **60+ built-in** | ~13 | Workspace + installed | Workspace + open-skills |
| **Marketplace** | ClawHub skill | ClawHub | N/A | Registry + install/remove | ZeroMarket |

**Key consensus (4/5 projects):**
- A skill is a **SKILL.md prompt text**, not executable code
- The **LLM reads and executes** — no "Skill Engine" orchestrates steps
- SKILL.md with **YAML frontmatter** is the de facto format
- Skills are **stateless** — no pause/resume

---

## 1. What is a Skill

A Skill is a **prompt overlay document** that teaches the LLM how to perform a specific domain task using existing tools. The skill contains natural-language instructions, not executable code.

**Skill ≠ Tool:**

| | Tool | Skill |
|---|------|-------|
| What | Code that executes an operation | Text that teaches the LLM |
| Interface | `execute(args) → ToolResult` | Markdown text injected into LLM context |
| Runs | Tool Registry executes | LLM reads and autonomously uses tools |
| State | Stateless (single call) | Stateless (prompt injection) |
| Params | JSON Schema validated | Natural language task description |
| Example | `shell`, `read_file`, `git` | "GitHub PR Workflow", "Code Review" |

---

## 2. SKILL.md Format

OpenClaw convention, used by nanobot, IronClaw, ZeroClaw. WorkPilot follows the same format.

```markdown
---
name: github-pr
description: Create a pull request with code changes, tests, and description
metadata:
  workpilot:
    activation:
      keywords: ["pr", "pull request", "create pr", "submit pr"]
      patterns: ["(?i)\\b(create|open|submit)\\b.*\\b(pr|pull request)\\b"]
    requires:
      bins: ["gh"]
      env: ["GITHUB_TOKEN"]
    always: false
---

# GitHub PR Workflow

When the user asks to create a PR, follow these steps:

## 1. Create Branch
- Create a new branch from current HEAD: `git checkout -b feature/<short-name>`
- Branch name should be descriptive

## 2. Make Changes
- Implement the requested changes using available tools
- Follow the project's coding conventions

## 3. Run Tests
- Run the project's test suite
- Fix any failures before proceeding

## 4. Commit
- Stage changes: `git add <specific-files>`
- Commit with conventional commit message

## 5. Create PR
- Push branch: `git push -u origin <branch>`
- Create PR using `gh pr create`
- Include: title, description, linked issues
```

### Frontmatter Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `name` | string | yes | Unique skill identifier |
| `description` | string | yes | One-line description (used in summary for LLM) |
| `metadata.workpilot.activation.keywords` | list[string] | no | Keywords that trigger this skill |
| `metadata.workpilot.activation.patterns` | list[string] | no | Regex patterns for activation |
| `metadata.workpilot.requires.bins` | list[string] | no | Required CLI tools (e.g., `gh`, `npm`) |
| `metadata.workpilot.requires.env` | list[string] | no | Required environment variables |
| `metadata.workpilot.always` | bool | no | Always include in context (default false) |

The `metadata` namespace uses `workpilot` (like OpenClaw uses `openclaw`, nanobot uses `nanobot`). This allows skills to carry metadata for multiple platforms.

---

## 3. Skill Discovery

How the LLM knows what skills are available — **progressive disclosure** (nanobot + OpenClaw pattern):

```
System prompt includes skill summary:
  "Available skills:
   - github-pr: Create a pull request with code changes, tests, and description
   - code-review: Review code for bugs, security issues, and style
   - office-comms: Draft and send emails, schedule meetings
   (Use read_file to load full skill instructions when needed)"
  ↓
User asks: "create a PR for this fix"
  ↓
LLM recognizes relevance → calls read_file("skills/github-pr/SKILL.md")
  ↓
Full skill instructions now in context
  ↓
LLM follows instructions, calls tools autonomously
```

### Activation Matching (IronClaw pattern)

When a message arrives, skills are scored for relevance:

| Signal | Points | Cap |
|--------|--------|-----|
| Keyword exact match | 10 | 30 |
| Keyword substring | 5 | 30 |
| Regex pattern match | 20 | 40 |

Top-scoring skill(s) are mentioned prominently in the system prompt. The LLM decides whether to load and follow the skill — activation is a **hint, not a mandate**.

Skills marked `always: true` are always included in context (no scoring needed).

### Token Budget

Total skill content in context is bounded (default 4000 tokens). If multiple skills match, the highest-scoring ones get priority within the budget. This prevents context window bloat.

---

## 4. Skill Execution

**The LLM IS the engine.** There is no "Skill Engine" that orchestrates steps.

```
Skill instructions loaded into context
  ↓
LLM reads step-by-step instructions
  ↓
LLM autonomously decides which tools to call:
  - shell("git checkout -b feature/fix-auth")
  - edit_file("src/auth.py", old="...", new="...")
  - shell("pytest tests/test_auth.py")
  - shell("git add src/auth.py tests/test_auth.py")
  - shell("git commit -m 'fix: auth token refresh'")
  - shell("git push -u origin feature/fix-auth")
  - shell("gh pr create --title '...' --body '...'")
  ↓
Each tool call goes through normal Tool Registry pipeline
  (validate → approval → security boundary → execute → hooks)
  ↓
LLM completes the workflow, returns final response to user
```

**No special execution path.** Skill-driven tool calls are identical to regular tool calls — same hooks, same security, same audit. The only difference is that the LLM has domain-specific instructions in its context.

---

## 5. Skill Sources

| Source | Location | Editable | Trust |
|--------|----------|----------|-------|
| **Bundled** | `workpilot/skills/bundled/` (shipped with WorkPilot) | Read-only | High |
| **Workspace** | `<workspace>/skills/` or `<workspace>/.workpilot/skills/` | User-editable | High (user-placed) |
| **Installed** | Via marketplace or `workpilot skills install` | User-editable | Medium (external source) |

### Trust Model (IronClaw pattern)

When skills from different trust levels are active simultaneously:

| Scenario | Tool access |
|----------|------------|
| Only bundled/workspace skills | Full tool access |
| Any installed (external) skill active | Security Agent validates all tool calls (treat as `approval: auto`) |

This prevents a malicious installed skill from instructing the LLM to exfiltrate data using tools that would otherwise auto-approve.

---

## 6. Skill Lifecycle

| Command | Description |
|---------|-------------|
| `workpilot skills list` | List all skills (bundled + workspace + installed) |
| `workpilot skills show <name>` | Show skill content |
| `workpilot skills new <name>` | Scaffold new workspace skill (ZeroClaw pattern) |

### Scaffolding (`workpilot skills new`)

```
$ workpilot skills new deploy-staging
Created: skills/deploy-staging/SKILL.md

Edit the skill file to add instructions:
  skills/deploy-staging/SKILL.md
```

Creates a SKILL.md template with frontmatter and empty body.

### No Self-Evolution

The previous spec described "Skill Self-Iteration" where an LLM would automatically modify skill definitions. No reference project implements this. Skills are **manually authored and refined** by users. Execution outcomes are recorded in History Store for the user's reference, but skills don't auto-modify.

---

## 7. Comparison: WorkPilot vs Reference Projects

| Aspect | nanobot | OpenClaw | IronClaw | WorkPilot |
|--------|---------|---------|----------|-----------|
| Format | SKILL.md + frontmatter | SKILL.md + frontmatter | SKILL.md + frontmatter | **SKILL.md + frontmatter** (same) |
| Discovery | Summary in prompt | 3-tier progressive | Keyword/regex scoring | **Progressive + scoring** (combined) |
| Security | requires gating | requires gating | **Trust attenuation** | **Trust model** (IronClaw-inspired) |
| Execution | LLM decides | LLM decides | LLM decides (trust-constrained) | **LLM decides** |
| Marketplace | ClawHub | ClawHub (60+) | Registry | **Future** |
| Stateful | No | No | No | **No** |

WorkPilot combines:
- **nanobot/OpenClaw format** (SKILL.md + YAML frontmatter) for ecosystem compatibility
- **IronClaw activation** (keyword/regex scoring) for intelligent discovery
- **IronClaw trust model** (installed skills get reduced tool access) for security
- **Progressive disclosure** (summary → full load) for context efficiency
