# Message Bus

> **Type**: Core Infrastructure
> **Date**: 2026-03-01
> **Parent**: [core-infra.md](../core-infra.md) Section 3

---

## Reference (from actual source code)

| Dimension | nanobot | OpenClaw | NanoClaw | ZeroClaw | IronClaw |
|-----------|---------|---------|----------|----------|----------|
| **Bus type** | **Dual asyncio.Queue** | WebSocket RPC + broadcast | File IPC + GroupQueue | **tokio mpsc (fan-in)** | **Merged streams + mpsc + broadcast** |
| **Message types** | 2 dataclasses | JSON frames (req/res/event) | JSON files (~8 types) | 2 structs | 3 structs + **StatusUpdate enum (10 variants)** |
| **Typed events** | None (metadata dict) | Scoped event strings | IPC `type` field | None | **StatusUpdate enum** |
| **Backpressure** | **None** (unbounded) | Slow-consumer disconnect | Container count limit | **mpsc(100)** + semaphore | **mpsc(64)** + stream backpressure |
| **Concurrency** | asyncio + global lock | Node.js + SessionActorQueue | Node.js + 1 container/group | tokio + semaphore pool | tokio + sequential main |
| **Decoupling** | **Excellent** (bus mediator) | Moderate (direct dispatch) | Very strong (file IPC) | Good inbound, direct outbound | **Excellent** (stream abstraction) |
| **Hot-add channels** | No | Via WS reconnect | No | No | **Yes** (`hot_add()`) |
| **Queue capacity** | Unbounded | N/A (WS buffer) | N/A (filesystem) | 100 | 64 |

---

## 1. Design

WorkPilot follows the **nanobot dual-queue pattern** (simplest, most decoupled) with improvements from IronClaw (bounded queue, typed events).

```
Channels ──publish──→ [Inbound Queue] ──consume──→ Agent Loop
                                                        │
Agent Loop ──publish──→ [Outbound Queue] ──consume──→ Channel Manager ──route──→ Channels
                                                        │
Any subsystem ──emit──→ [Event Bus] ──subscribe──→ Subscribers (hooks, observer, etc.)
```

Three components:
1. **Inbound Queue** — channel → agent (messages from users)
2. **Outbound Queue** — agent → channel (responses to users)
3. **Event Bus** — any subsystem → subscribers (typed events for cross-cutting concerns)

---

## 2. Inbound Queue

```python
inbound: asyncio.Queue[InboundMessage]  # bounded, default capacity 100
```

| Method | Description |
|--------|-------------|
| `publish_inbound(msg)` | Channel pushes a user message (async, awaits if queue full) |
| `consume_inbound() → InboundMessage` | Agent loop pulls next message (blocks until available) |

**Capacity**: 100 messages (ZeroClaw convention). When full, `publish_inbound()` awaits — applying backpressure to the channel. This prevents memory blowup from a flood of messages.

**Single consumer**: The Agent Loop is the sole consumer of the inbound queue. Messages processed sequentially with a processing lock (nanobot pattern — one message at a time).

---

## 3. Outbound Queue

```python
outbound: asyncio.Queue[OutboundMessage | StreamingChunk]  # bounded, default capacity 100
```

| Method | Description |
|--------|-------------|
| `publish_outbound(msg)` | Agent loop pushes response or streaming chunk |
| `consume_outbound() → OutboundMessage \| StreamingChunk` | Channel Manager pulls and routes to correct channel |

**Routing**: Channel Manager matches `msg.channel` to the registered channel and calls `channel.send(msg)`. If channel not found, message is logged and dropped.

**Streaming**: `StreamingChunk` messages flow through the same outbound queue. Streaming-capable channels render them incrementally. Non-streaming channels ignore chunks and wait for the final `OutboundMessage`.

---

## 4. Event Bus

Typed events for cross-subsystem coordination. **Fire-and-forget** — publishers never block on subscribers.

```python
event_bus: EventBus  # async pub/sub
```

| Method | Description |
|--------|-------------|
| `emit(event_type, payload)` | Publish event (fire-and-forget) |
| `on(event_type, handler)` | Subscribe to event type |
| `off(event_type, handler)` | Unsubscribe |

### Event Types

| Category | Event | Payload | Publisher |
|----------|-------|---------|-----------|
| `message.received` | InboundMessage arrived | msg | Bus |
| `message.sent` | OutboundMessage delivered | msg | Bus |
| `tool.executed` | Tool call completed | tool_name, args, result, duration | Tool Registry |
| `tool.failed` | Tool call failed | tool_name, args, error | Tool Registry |
| `tool.approved` | User approved a tool call | tool_name, args, actor | Approval Gate |
| `tool.denied` | User denied a tool call | tool_name, args, actor | Approval Gate |
| `security.alert` | Security event detected | type, severity, details | Security Services |
| `security.estop` | E-stop triggered/reset | action (trigger/reset), reason, actor | E-Stop |
| `security.leak` | Credential leak detected | pattern_type, location | Leak Detector |
| `cost.warning` | Cost threshold approaching | current_cost, budget | Cost Tracker |
| `health.degraded` | Subsystem health changed | subsystem, old_status, new_status | Heartbeat |
| `health.recovered` | Subsystem recovered | subsystem | Heartbeat |
| `agent.iteration` | Agent loop iteration completed | iteration_num, tool_calls_count | Agent Loop |
| `memory.consolidated` | MEMORY.md updated | facts_added, facts_removed | Memory |
| `session.created` | New session started | session_id, channel | Session Manager |

### Subscriber Behavior

- Handlers run as **separate asyncio tasks** (one slow handler doesn't block others)
- If a handler throws, the exception is logged but doesn't affect other subscribers
- Events are logged at DEBUG level for troubleshooting
- No ordering guarantee across different subscribers for the same event

---

## 5. Message Types

### InboundMessage

```
InboundMessage:
  channel: str              # "cli", "web", "cloud"
  channel_id: str           # routing identifier — for Cloud: opaque cid_* key from Cloud Gateway,
                            # echoed into OutboundMessage.channel_id by the Agent Loop
  sender_id: str            # user identifier
  content: str              # message text
  thread_id: str | None     # for threaded conversations
  session_key: str           # computed: "{channel}:{sender_id}:{thread_id}"
                             # Exception — Cloud channel uses {source} prefix instead of {channel}:
                             #   cloud_teams:   "cloud_teams:{from.aadObjectId}:{conversation.id}"
                             #   cloud_webchat: "cloud_webchat:{upn}:wc_{full-oid}"
                             # CloudChannel sets session_key directly from the wire frame value;
                             # it does NOT call SessionManager.get_or_create_id() (which is for
                             # other channels and does not include thread_id).
                             # See design/core/channel.md §4 for full routing table.
  attachments: list | None  # files, images
  timestamp: datetime
  metadata: dict            # source-specific data
    source: str | None      # original source for Cloud ("cloud_teams", "cloud_webchat")
    tenant_id: str | None   # Cloud channel only: Entra tenant ID
    injection: bool          # true if injected during active processing
    interrupt: bool          # true if /stop or /cancel
```

### OutboundMessage

```
OutboundMessage:
  channel: str              # target channel
  channel_id: str           # routing key (usually = sender's channel)
  content: str              # response text
  thread_id: str | None     # reply in thread
  attachments: list | None  # files to attach
```

### StreamingChunk

```
StreamingChunk:
  channel: str
  channel_id: str
  content: str              # text fragment
  chunk_type: str           # "token" | "tool_progress" | "status"
  done: bool                # true on final chunk
```

---

## 6. Message Injection

While the Agent Loop is processing, new messages can arrive:

| Scenario | Behavior |
|----------|----------|
| Normal message | Queued in inbound queue, processed after current turn completes |
| `/stop` or `/cancel` | Marked as `interrupt=true`. Agent Loop checks for interrupt between tool calls and cancels current execution. |
| Cloud Gateway follow-up | Same as normal message — queued |

The Agent Loop checks for interrupt signals between iterations (nanobot: `asyncio.Task` cancellation).

---

## 7. Processing Lock

Only one message is processed at a time (nanobot pattern):

```python
async def _process_loop(self):
    while self._running:
        msg = await self.bus.consume_inbound()
        async with self._processing_lock:  # one at a time
            await self._handle_message(msg)
```

Messages from different channels or the same channel all serialize through this lock. This prevents concurrent writes to session state, memory, or workspace files.

**Why not parallel?** The agent modifies workspace files, writes to memory, and manages session state. Parallel message processing would require complex locking on all shared state. Sequential processing is simpler and matches 4/5 reference projects (only IronClaw does concurrent message handling, but serialized per-session).

---

## 8. Channel Manager (Outbound Router)

```python
class ChannelManager:
    channels: dict[str, Channel]  # name → channel instance

    async def dispatch_outbound(self):
        while True:
            msg = await self.bus.consume_outbound()
            channel = self.channels.get(msg.channel)
            if channel:
                await channel.send(msg)
            else:
                logger.warning(f"No channel '{msg.channel}' for outbound message")
```

**Streaming dispatch**: For `StreamingChunk` messages, the Channel Manager checks `channel.supports_streaming`. If true, forward the chunk. If false, buffer chunks and deliver only the final `OutboundMessage`.

---

## 9. Comparison: WorkPilot vs Reference Projects

| Aspect | nanobot | WorkPilot |
|--------|---------|-----------|
| Inbound | Unbounded asyncio.Queue | **Bounded** (100, backpressure) |
| Outbound | Unbounded asyncio.Queue | **Bounded** (100) |
| Events | None | **Typed event bus** (15+ event types) |
| Streaming | Progress via metadata hack | **StreamingChunk** message type |
| Processing | Global asyncio.Lock | Same (sequential) |
| Backpressure | None | **Queue capacity** + await on full |
| Message types | 2 (InboundMessage, OutboundMessage) | 3 (+ StreamingChunk) + typed events |
| Injection | Not explicit | **Explicit** (injection/interrupt flags) |
