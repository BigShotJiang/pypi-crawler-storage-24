# Agent Loop

> **Type**: Core Infrastructure
> **Date**: 2026-03-01
> **Parent**: [core-infra.md](../core-infra.md) Section 5

---

## Reference (from actual source code)

| Dimension | nanobot | OpenClaw | NanoClaw | ZeroClaw | IronClaw |
|-----------|---------|---------|----------|----------|----------|
| **Loop core** | ~40 lines, while loop | ~1557 lines (attempt.ts) | ~30 lines (SDK query) | ~900 lines, for loop + dual parsing | ~300 lines, 3-phase execution |
| **Max iterations** | **40** (soft: friendly msg) | 160 outer retries / SDK inner | SDK-controlled | **20** (hard: bail!) | Configurable (nudge → force-text → error) |
| **Context order** | System + History + Runtime + User | System + History + User (SDK) | claude_code preset + CLAUDE.md | System + Memory recall + User | System + Skills (XML trust) + Messages |
| **History mgmt** | JSONL, 100-msg window, 500-char tool truncation | SDK + 5-stage sanitization | SDK (invisible) | Hard trim + LLM compaction | **3-tier compaction at 80/85/95%** |
| **Memory** | MEMORY.md + HISTORY.md, async LLM consolidation | SDK sessions + compaction | Workspace filesystem | **Semantic recall** (top-5 vector) | Workspace identity files |
| **Research phase** | None | None | None | **Yes** (sentinel-based) | None |
| **Streaming** | Progress callbacks | Full event subscription | SDK (invisible) | 80-char delta chunks | Status updates |
| **Error recovery** | Skip error history | Auth rotation, overflow compact, thinking fallback | SDK | Missing tool retry (EN+CJK), 3-level loop detect | Auto-compact on overflow, nudge before limit |
| **Parallel tools** | Sequential | SDK | SDK | **Yes** (heuristic-based) | **Yes** (preflight→parallel→postflight) |
| **Loop detection** | None | **4 detectors** (repeat, poll, ping-pong, circuit) | None | **3 detectors** + 3-level verdict | None |
| **Cost guard** | None | None | None | None | **Yes** (daily budget, pre-call check) |
| **Safety heartbeat** | None | None | None | **Yes** (periodic security re-injection) | None |
| **Prompt caching** | None | **Cache-TTL tracking** | SDK | None | None |

---

## 1. Loop Structure

nanobot's ~40-line while loop is the foundation. WorkPilot adds proven enhancements from ZeroClaw and IronClaw.

```
Message In
  ↓
● on_message_received hook (prompt injection scan)
  ↓
Research Phase (ZeroClaw pattern — only project with this)
  - Workspace grep + memory search + facts read
  - Read-only, time-budgeted
  - Sentinel-based termination ("[RESEARCH COMPLETE]")
  ↓
Context Assembly
  - System prompt (agent instructions + identity)
  - Facts (MEMORY.md — always included)
  - Research results (if research ran)
  - Skill summaries (activated skills)
  - Conversation history (from session)
  - User message
  ↓
LLM ↔ Tool Loop (≤ max_iterations)
  │
  ├─ Provider.stream() → yield chunks to channel
  │
  ├─ For each tool call (parallel when independent):
  │    ● pre_tool_use hook (E-stop, policy, approval)
  │    Security Boundary → Tool.execute()
  │    ● post_tool_use hook (leak scan, redact, audit)
  │
  ├─ Loop detection check (prevent infinite loops)
  │
  ├─ Context window check → auto-compact if needed
  │
  └─ Repeat until text response or budget spent
  ↓
● on_message_sent hook (outbound leak scan)
  ↓
Session persist + memory consolidation check
```

---

## 2. Context Assembly

Order matters for prompt caching — put stable content first, dynamic content last.

```
[0] System prompt (agent instructions + identity)     ← stable, cache-friendly
[1] MEMORY.md facts                                    ← semi-stable
[2] Skill instructions (if any activated)              ← semi-stable
[3] Research context (if research phase ran)            ← per-request
[4..N-1] Conversation history (from session)           ← growing
[N] User message                                       ← per-request
```

**Why this order:**
- System prompt + facts are identical across requests → maximizes LLM prompt cache hits (OpenClaw insight)
- History grows in the middle
- User message is always last (LLM expectation)

---

## 3. Iteration Management

### Max Iterations

| Setting | Default | Source |
|---------|---------|--------|
| `max_iterations` | 40 | nanobot convention |

### Graceful Termination (IronClaw pattern)

Instead of a hard cutoff, use a three-stage approach:

| Stage | When | Behavior |
|-------|------|----------|
| **Nudge** | iteration == max - 2 | Inject system message: "You are approaching the iteration limit. Please wrap up your current task." |
| **Force text** | iteration == max - 1 | Send LLM request WITHOUT tools (force text-only response) |
| **Hard stop** | iteration == max | Return: "Iteration limit reached. Here's what was accomplished so far: ..." |

This is more graceful than nanobot (soft message, session continues) or ZeroClaw (hard bail!). The LLM gets a chance to summarize what it's done.

---

## 4. History Management

### Session Storage

JSONL append-only per session (nanobot convention). Each message appended immediately for crash safety.

### Context Window Monitoring

Track estimated token usage per LLM call (IronClaw: word-based estimation × 1.3 multiplier).

### Auto-Compaction (IronClaw 3-tier pattern)

| Threshold | Action |
|-----------|--------|
| **80%** of context limit | Compact older messages: summarize with fast model, keep recent N |
| **85%** | Aggressive compact: smaller summary, keep fewer recent messages |
| **95%** | Truncate: remove oldest messages entirely (no LLM summary) |

Original messages stored in History Store before compaction (nothing lost).

**Facts (MEMORY.md) are never compacted** — bounded by design (8KB cap).

### Tool Result Truncation in History

When saving to session, tool results longer than 500 chars are truncated with `"... (truncated)"` (nanobot convention). The full result was already processed by the LLM in the current turn — no need to store the full text for future turns.

---

## 5. Research Phase (ZeroClaw pattern)

**ZeroClaw is the only project with a dedicated research phase.** Before the main LLM-tool loop, proactively gather information:

```
User message arrives
  ↓
Research phase begins (read-only tools only):
  1. Search workspace files (grep/glob for keywords from user message)
  2. Search History Store (related past conversations)
  3. Read MEMORY.md facts (always loaded anyway)
  ↓
Sentinel detection: if LLM outputs "[RESEARCH COMPLETE]", research ends
  ↓
Research results injected into context for main loop
```

**Constraints:**
- Read-only: only search/read tools, no write/shell/network
- Time-budgeted: configurable timeout, returns whatever gathered
- Token-bounded: max research context tokens (prevent context bloat)

**When to skip research:**
- Short messages (< 20 chars)
- Slash commands (`/stop`, `/new`, etc.)
- Follow-up in existing conversation (context already present)

---

## 6. Parallel Tool Execution

When the LLM requests multiple tool calls in one turn, they can run in parallel.

### IronClaw Three-Phase Model (most sophisticated)

```
LLM returns N tool calls
  ↓
Phase 1: Preflight (sequential)
  - pre_tool_use hooks for ALL N tools
  - Any rejection cancels that tool only
  ↓
Phase 2: Execute (parallel)
  - All approved tools run concurrently (asyncio.gather)
  ↓
Phase 3: Postflight (sequential)
  - post_tool_use hooks for ALL N results
  - Leak scan, redact, audit
  ↓
All results appended to messages
```

**Safety heuristic** (ZeroClaw): some tool combinations should NOT run in parallel:
- Two shell commands that may conflict (both writing to same file)
- A write followed by a read of the same file

WorkPilot uses the **IronClaw three-phase model**: preflight hooks sequential, execution parallel (`asyncio.gather`), postflight hooks sequential. Read-only tools (read_file, list_dir, search_files) are always safe to parallelize. Write operations that target the same file are serialized automatically.

---

## 7. Loop Detection

Prevents the LLM from getting stuck in repetitive patterns.

### Three Detectors (OpenClaw has 4, ZeroClaw has 3)

| Detector | What it catches | Action |
|----------|----------------|--------|
| **Repeat** | Same tool + same args called 3+ times in a row | Inject: "You are repeating the same action. Try a different approach." |
| **Poll** | Tool called, result checked, same tool called again (polling pattern) | Inject: "You appear to be polling. The result is unlikely to change." |
| **Ping-pong** | Two tools alternating back and forth | Inject: "You are alternating between two actions. Step back and reconsider." |

Detection runs after each tool result. If detected, a system message is injected before the next LLM call. If the pattern persists after injection, the loop terminates.

---

## 8. Streaming

### LLM Response Streaming

When the agent loop produces a text-only response (no tool calls), it uses streaming:

```
Provider.stream(messages) → AsyncIterator[LLMChunk]
  ↓
For each chunk:
  Text delta → dispatch StreamingChunk to Bus handlers (no queue) → channel displays
  ↓
try/finally ensures done=True marker is always sent
  ↓
After streaming: on_message_sent hook runs on full accumulated content
  ↓
OutboundMessage skipped (channels already received via streaming chunks)
```

Streaming is used when `tools_for_call is None` (forced text at max-1 iteration) and channel info is available. Tool-calling iterations use `complete()` (non-streaming).

`MessageBus.dispatch_outbound()` sends chunks directly to handlers without enqueuing to the bounded outbound queue, preventing backpressure from high-frequency token delivery.

### Tool Progress (v2)

> Not yet implemented. Future: tools with `metadata.streaming = true` emit progress chunks (e.g., `⠋ Running shell: npm test... (15s)`).

---

## 9. Error Recovery

| Error | Recovery | Source |
|-------|----------|--------|
| **Tool execution fails** | Error returned as ToolResult(success=false). LLM sees error and tries different approach. | nanobot (all projects) |
| **ContextLengthExceeded** | Auto-compact: summarize history, retry once | IronClaw |
| **Provider timeout/5xx** | Circuit breaker → fallback to next provider | IronClaw (core-infra Section 4.5) |
| **Tool call missing in response** | Retry with explicit instruction: "Please use a tool to proceed." | ZeroClaw (EN + CJK detection) |
| **Loop detected** | Inject warning → if persists, terminate | OpenClaw + ZeroClaw |
| **E-stop triggered** | Immediate exit | ZeroClaw (core-infra Section 9.4) |

### Error History (nanobot pattern)

When saving error turns to session, nanobot skips persisting the error messages to prevent future sessions from hitting the same 400-error loop. WorkPilot follows this: tool errors are shown to the LLM in the current turn but NOT saved to session history.

---

## 10. Memory Integration

### When MEMORY.md is Read

- **Every turn**: facts.read() is called during context assembly (always in context)

### When MEMORY.md is Consolidated

```
After each turn completes:
  ↓
Check: message count in session > consolidation_threshold (default 50)?
  ├─ No → skip
  └─ Yes → async LLM consolidation:
       1. Extract key facts from recent messages
       2. Merge with existing MEMORY.md
       3. Deduplicate, prune stale
       4. Enforce size cap (8KB)
       5. Atomic write
```

Consolidation runs **async** (nanobot pattern) — doesn't block the response to the user.

### When History Store is Written

After every turn: messages, tool calls, and events are stored in History Store for search/recall.

---

## 11. Defaults

| Setting | Default | Source |
|---------|---------|--------|
| `max_iterations` | 40 | nanobot |
| `tool_timeout` | 600s (config default, LLM can pass shorter) | core/tool.md |
| `research_enabled` | true | ZeroClaw |
| `loop_detection` | true | OpenClaw + ZeroClaw |
| `auto_compact` | true at 80/85/95% thresholds | IronClaw |
| `consolidation_threshold` | 50 messages | nanobot |
| `tool_result_session_truncation` | 500 chars | nanobot |
| `parallel_tools` | true (IronClaw 3-phase) | IronClaw |

---

## 12. What WorkPilot Adds vs nanobot

nanobot's ~40-line loop is the ancestor. WorkPilot's additions:

| Addition | Source | Why |
|----------|--------|-----|
| Research phase | ZeroClaw (only project with this) | Reduces hallucination |
| Graceful iteration nudging | IronClaw (nudge → force-text → hard stop) | Better UX than hard cutoff |
| Loop detection (3 detectors) | OpenClaw + ZeroClaw | Prevents infinite loops |
| Auto-compaction (3-tier) | IronClaw (80/85/95%) | Handles long conversations |
| Streaming | All projects | Real-time feedback |
| Hook pipeline | OpenClaw + IronClaw | Safety (E-stop, leak scan, audit) |
| Error history skip | nanobot | Prevents 400-error loops |
| Tool result truncation in session | nanobot (500 chars) | Keeps session lean |
