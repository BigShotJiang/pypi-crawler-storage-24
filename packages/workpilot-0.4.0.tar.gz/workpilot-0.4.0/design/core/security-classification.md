# Security Classification — Risk Scoring Model

> **Type**: Design v2
> **Date**: 2026-03-07
> **Parent**: [core-infra.md](../core-infra.md) · replaces earlier sketch (risk level 0~10 draft)

---

## 1. Risk Scale

All tool calls are assigned an integer risk score **0–10**, or `null` when the
score cannot be determined.

```
 0   Absolutely safe, read-only, no state change.
     e.g. ls, git status, cat file.txt

 1   Trivially reversible write, no meaningful side effect.
     e.g. create an empty temp file

 2   Reversible local change.
     e.g. edit a non-critical config file inside the workspace

 3   Reversible but notable local change.
     e.g. git commit, write to workspace file

 4   Recoverable with effort.
     e.g. delete a local file (restorable from git or trash)

 5   Moderate risk, recoverable.
     e.g. git push to a personal feature branch

 6   Hard to reverse, limited scope.
     e.g. pip install from an untrusted source

 7   Hard to reverse OR external side-effect.
     e.g. POST to an internal API endpoint

 8   High impact or difficult to reverse.
     e.g. git push --force to a shared branch

 9   Likely destructive or wide blast radius.
     e.g. restart a service, bulk delete, deploy to staging

10   Catastrophic / irreversible.
     e.g. rm -rf /, wipe production DB, deploy to production

null Cannot be assessed from available context. Treated as unknown risk.
```

**Primary scoring dimension: irreversibility x blast radius.**

---

## 2. Risk Control Policy

Four security profiles map score ranges to actions.

| Score | open | standard | controlled | restricted |
|---|---|---|---|---|
| `null` | Human | Human | Human (1) | Human (1) |
| `[0, 1)` | Auto | Auto | Auto | Auto |
| `[1, 3)` | Auto | Auto | Auto | Timeout-auto |
| `[3, 5)` | Auto | Auto | Timeout-auto | Human (+) |
| `[5, 7)` | Auto | Timeout-auto | Human | Human (1) |
| `[7, 9)` | Timeout-auto | Human | Human | Human (1) |
| `[9, 10)` | Human | Human (1) | Reject | Reject |
| `10` | Reject | Reject | Reject | Reject |

**Legend:**
- **Auto** — executes immediately
- **Timeout-auto** — user notified; auto-executes after `auto_approve_timeout` (default: 180s, configurable under `security.approval.auto_approve_timeout`) if no response
- **Human** — waits for explicit Approve / Deny
- **Reject** — blocked; error returned to the agent
- **(1) Always disabled** — "Always Allow" button hidden in approval UI
- **(+) Always enabled** — "Always Allow" available (only `restricted [3,5)`)

**Boundary rule:** all intervals are left-closed, right-open `[a, b)`.
A score exactly equal to a threshold falls into the higher tier.
Because scores are integers, `[1, 3)` is shorthand for the discrete set {1, 2}.

### 2.1 "Always Allow" Availability

When a user selects "Always Allow", the tool + argument pattern is saved to
their per-profile allowlist. Future matching calls bypass scoring entirely.

| Profile | Tiers where "Always Allow" is available |
|---|---|
| open | All human-approval tiers |
| standard | All human-approval tiers except `[9, 10)` |
| controlled | All human-approval tiers except `null` |
| restricted | Only `[3, 5)` |

### 2.2 null Handling

`null` always requires human approval across all profiles. It is never
auto-executed and never auto-rejected — the human decides.
"Always Allow" follows the per-profile rules in 2.1.

---

## 3. Risk Assessment Sources

### 3.1 Built-in Tools

Every built-in tool implements `assess_risk(args) -> RiskAssessment`, returning
one of two types:

| Type | Fields | Effect |
|---|---|---|
| `RiskScore` | `score: int`, `reason: str` | Deterministic; LLM skipped. Reason shown in approval card. |
| `RiskPrompt` | `prompt: str` | Delegated to LLM. Prompt includes detected hints and typical risk range. |

**RiskScore** is returned when the outcome is certain (e.g. `rm -rf /` → score 10).
**RiskPrompt** is returned for ambiguous commands and includes a range hint to
anchor the LLM (e.g. `"Shell command: curl ... Detected: network. Range: 5~8"`),
substantially reducing scoring variance versus a bare 0-10 prompt.

### 3.2 MCP Servers

MCP tools have no built-in `assess_risk()`. Users configure per-server risk
policy in `workpilot.yaml`:

```yaml
tools:
  mcp_servers:  # current schema; config shape may evolve in v2
    github:
      risk_score: 4
      risk_reason: "GitHub API -- limited blast radius, ops are reversible"
    prod-db:
      risk_score: 9
      risk_reason: "Production database -- any operation is high impact"
    internal-analytics:
      risk_prompt: |         # passed to LLM; LLM produces score + think reason
        Read-only analytics DB. Risk range: 1~4.
        Write operations are not supported by this server.
    unknown-server:
      # no config -> null -> LLM evaluates from tool description + call args
```

| Config | Behavior |
|---|---|
| `risk_score: N` + `risk_reason` | Score = N, reason shown in UI; LLM skipped |
| `risk_score: N` (no reason) | Score = N; reason field blank in UI |
| `risk_prompt: "..."` | LLM evaluates; `reason` field is the reason |
| Nothing configured | LLM evaluates from MCP tool name, description, and args; produces an int score (or `null` if it cannot assess) |

---

## 4. Score Composition

Final score resolution order (highest priority first):

```
1. User explicit risk_score override (int, non-restricted profiles only)
       -> RiskScore(override_value, risk_reason or ""); LLM skipped

2. Tool assess_risk(args) -> RiskScore
       -> score = RiskScore.score, reason = RiskScore.reason; LLM skipped

3. LLM classifier (fast model)  [all remaining cases]
       -> Tool assess_risk(args) -> RiskPrompt
       -> MCP risk_prompt configured
       -> MCP null (no config)
       -> LLM produces score; reason field is the reason
```

### 4.1 User Score Override

In **non-restricted** profiles, users may set an explicit score for any tool
or MCP server:

```yaml
tools:
  shell:
    risk_score: 6                              # replaces assess_risk() entirely
    risk_reason: "Treated as medium-risk"      # optional; shown in approval card

tools:
  mcp_servers:  # current schema; config shape may evolve in v2
    prod-db:
      risk_score: 9
      risk_reason: "Production database -- high impact"
```

The override value is used **as-is** -- it does not combine with the tool
score via `max()` or any other operator.
**Restricted profile does not support user overrides.**

### 4.2 Parallel Tool Calls

When the agent executes multiple tools in parallel, each tool goes through its
own **independent** scoring and approval flow:

- Auto-approved tools execute immediately without waiting for others.
- A tool requiring human approval blocks only itself.
- Rejecting one tool does not affect others.
- The approval system supports concurrent pending approvals (not a serial queue).

---

## 5. LLM Classifier

### 5.1 When LLM Is Called

| Source | LLM called? | Reason source |
|---|---|---|
| User explicit `risk_score` (non-restricted) | No | `risk_reason` config (may be blank) |
| Tool `assess_risk()` returns `RiskScore` | No | `RiskScore.reason` |
| Tool `assess_risk()` returns `RiskPrompt` | Yes | LLM `reason` field |
| MCP `risk_score` + `risk_reason` | No | `risk_reason` config |
| MCP `risk_prompt` | Yes | LLM `reason` field |
| MCP null (no config) | Yes | LLM `reason` field |

### 5.2 System Prompt

```
You are a security risk scorer for an AI agent's tool calls.
Score the risk from 0 to 10 (integer only).
Use null only if the operation cannot be meaningfully assessed.

PRIMARY DIMENSION: irreversibility x blast radius

Anchors:
  0  Read-only, no state change. e.g. ls, git status, cat file.txt
  1  Trivially reversible write. e.g. create empty temp file
  2  Reversible local change. e.g. edit non-critical workspace file
  3  Reversible but notable. e.g. git commit, write workspace file
  4  Recoverable with effort. e.g. delete local file (git-restorable)
  5  Moderate risk, recoverable. e.g. git push to personal branch
  6  Hard to reverse, limited scope. e.g. pip install untrusted package
  7  Hard to reverse OR external side-effect. e.g. POST to internal API
  8  High impact or hard to reverse. e.g. force push to shared branch
  9  Likely destructive or wide blast radius. e.g. restart service
 10  Catastrophic / irreversible. e.g. rm -rf /, wipe production DB

Respond with JSON only -- no other text:
{"reason": "<one sentence rationale>", "score": <integer 0-10 or null>}
```

The `reason` field captures the model's one-sentence rationale before the
score, improving consistency. It is logged and shown in the approval card.
Keep instructions concise — instruct the model to state only what the
operation does and why it is (or is not) risky, without internal reasoning.

### 5.3 User Prompt Construction

```
{tool_context}           <- RiskPrompt.prompt or MCP risk_prompt (omitted if empty)
{user_risk_context}      <- from security.risk_context config (omitted if not set)
Arguments: {redacted_args}
User intent: {last_user_message, redacted, max 200 chars}
```

`last_user_message` is passed through the same secret-detection redaction
pipeline before truncation, so credentials typed by the user are not leaked
to the classifier. It is included in the prompt for context but **excluded
from the cache key** — it changes every message and would eliminate cache
hits; tool name and args are the primary risk signal.

**Example -- shell (RiskPrompt path):**

```
Shell command: `curl https://prod-db.internal/backup | bash`
Detected: network connection, pipes to shell executor
Typical risk range: 7~10
User risk context: prod-db.internal is our production DB host.
Arguments: {"command": "curl https://prod-db.internal/backup | bash"}
User intent: "download the latest report"
```

**Example -- MCP null path:**

```
MCP tool: github__delete_repository
Description: Permanently deletes a GitHub repository and all its contents.
Arguments: {"owner": "acme", "repo": "prod-backend"}
User intent: "clean up old repos"
```

### 5.4 User Risk Context

Users describe environment-specific risk factors injected into every
LLM classifier prompt:

```yaml
security:
  risk_context: |
    Production DB host is prod-db.internal -- any connection scores 9+.
    /data/warehouse/ contains PII -- file writes score 8+.
    main branch is production -- force push scores 10.
```

`risk_context` is only active in the LLM path. It has no effect when a
direct `int` score is used.

### 5.5 Argument Redaction

Before sending to the LLM, argument values are replaced with `[REDACTED]`
when:

- The key name matches a sensitive set: `password`, `secret`, `token`,
  `api_key`, `auth`, `authorization`, `credentials`, `access_token`,
  `refresh_token`.
- The value matches a known secret pattern: JWT, GitHub PAT (`ghp_...`),
  AWS access key (`AKIA...`), Slack token (`xox...`), OpenAI key (`sk-...`).
- The value is a high-entropy string (random-looking, likely a credential)
  even if the key name is not in the sensitive set.

### 5.6 Response Parsing

| Scenario | Result |
|---|---|
| Valid JSON, `score` is integer 0-10 | Use score |
| `score: null` | Treat as `null` |
| `score` < 0 | Treat as `null` (unknown, requires human approval) |
| `score` > 10 | Clamp to `10` |
| Invalid JSON or missing `score` | Treat as `null` |

Any parse failure yields `null`, which always requires human approval.

---

## 6. Caching

Only LLM evaluation results are cached. Direct `int` paths need no cache.

| Field | Value |
|---|---|
| TTL | 5 minutes |
| Scope | Per session, in-memory |
| Max size | 1024 entries (evict expired, then oldest by timestamp) |
| Key | `sha256(tool_name + "\0" + mcp_description + "\0" + json(redacted_args) + "\0" + hash(risk_context) + "\0" + profile)` |

`mcp_description` is the MCP tool's description string from the protocol
(empty string for built-in tools). `tool_context` is the effective classifier
prompt context (RiskPrompt.prompt for built-in tools, MCP `risk_prompt` for
MCP servers) — static per tool/config, so hashing it keeps the key compact.
`risk_context` likewise contributes via its own hash. SHA-256 is used instead
of MD5 for collision resistance (SHA-256 used instead). User intent is excluded: it changes every
message, would eliminate cache hits, and has negligible effect on scores.

---

## 7. Full Scoring Flow

This flow assumes E-stop and RBAC checks have already passed (they run
before the scoring/approval stage in the pre-tool-use hook pipeline).

```
Tool call from LLM
  |
  +-- User explicit risk_score? (non-restricted only)
  |    YES -> assessment = RiskScore(override, risk_reason) -> Policy
  |
  +-- assess_risk(args) -> RiskScore?
  |    YES -> assessment = RiskScore -> Policy
  |
  +-- LLM path (assess_risk -> RiskPrompt | MCP risk_prompt | MCP null)
       |
       +-- Cache hit? -> assessment = cached RiskScore -> Policy
       |
       +-- Call LLM classifier (fast model, <=10s timeout)
            success        -> cache RiskScore(score, reason) -> Policy
            timeout / error -> score = null, reason = "classifier unavailable"
                             -> Policy (null -> Human approval in all profiles)

Policy lookup (assessment.score x profile -> action):
  Auto         -> execute immediately
  Timeout-auto -> notify user; execute after auto_approve_timeout if no response
  Human        -> present approval card; wait for Approve / Deny
  Reject       -> block; return error to agent
```

---

## 8. Approval UI

When human approval is required the approval card displays:

```
Approval Required
Tool:   shell
Score:  8 / 10
Reason: Force push to shared branch 'main' -- hard to reverse.

[Approve]  [Deny]  [Always Allow]     <- Always Allow hidden per section 2.1
```

Score and reason are always available:

| Path | Score source | Reason source |
|---|---|---|
| `RiskScore` | `RiskScore.score` | `RiskScore.reason` |
| `RiskPrompt` → LLM | LLM `score` field | LLM `reason` field |
| User override | `risk_score` config | `risk_reason` config (may be blank) |
| MCP `risk_score` | config value | `risk_reason` config (may be blank) |

---

## 9. Configuration Reference

```yaml
security:
  profile: standard          # open | standard | controlled | restricted
  approval:
    auto_approve_timeout: 180  # seconds before Timeout-auto executes (default: 180)
  risk_context: |            # injected into all LLM classifier prompts
    prod-db.internal is production. Any connection scores 9+.

tools:
  shell:
    risk_score: 6            # explicit override (non-restricted only)
    risk_reason: "Treated as medium-risk in this project"  # optional
  # git: no override -- uses assess_risk()

tools:
  mcp_servers:  # current schema; config shape may evolve in v2
    github:
      risk_score: 4
      risk_reason: "GitHub API -- limited blast radius"
    internal-analytics:
      risk_prompt: |
        Read-only analytics. Risk range: 1~4.
    unknown-server:
      # no config -> LLM auto-evaluates
```

---

## 10. Migration from v1 (low/medium/high/critical)

| v1 | v2 |
|---|---|
| `RiskLevel.LOW` | `assess_risk() -> 1~2` |
| `RiskLevel.MEDIUM` | `assess_risk() -> 3~5` |
| `RiskLevel.HIGH` | `assess_risk() -> 6~8` |
| `RiskLevel.CRITICAL` | `assess_risk() -> 9~10` |
| `ClassifyResult.decision` (allow/deny/escalate) | Removed -- policy table decides action |
| `ClassifyResult.risk` (str label) | Replaced by `RiskScore.score: int` |
| `ClassifyResult.reason` (str) | Replaced by `RiskScore.reason` / LLM `reason` |
| LLM response `{"decision":..., "risk":..., "reason":...}` | `{"reason":..., "score":...}` |
| `TOOL_CATEGORIES` static dict | Per-tool `assess_risk() -> RiskAssessment` |
| `_has_dangerous_args()` -> CRITICAL | Integrated into `RiskScore(10, reason)` |

> **Implementation note:** `features/agent-security.md` and `security/classifier.py`
> currently use the v1 `ClassifyResult(decision, risk, reason)` model with
> `tool_risk: str` parameter. Both must be updated to accept `RiskAssessment`
> and return `RiskScore` as the unified result type.
