# Approval UX — Multi-Channel Approval Design

> Implements [Issue #85](https://github.com/gim-home/WorkPilot/issues/85)

## Overview

When a tool call is escalated for human approval the agent blocks execution
and surfaces an approval prompt in the user's active channel.  The user
approves, denies, or adds the tool to the allowlist ("always allow") and the
agent resumes or rejects accordingly.

## Architecture

```
SecurityClassifier (fast LLM)
    │
    │ decision = "escalate"
    ▼
ApprovalHook.__call__()          ← workpilot/hooks/handlers.py
    │
    ├─ ApprovalManager.request_approval()   create PENDING record
    │
    ├─ channel == "cli"?
    │       yes → _cli_prompt()             inline y/n/always prompt
    │       no  → _send_approval_prompt()   format + send to channel
    │               │
    │               ├─ CLI   → CLIApprovalFormatter   (plain text)
    │               ├─ Teams → TeamsApprovalFormatter  (Adaptive Card)
    │               └─ other → CloudApprovalFormatter  (JSON)
    │
    └─ ApprovalManager.wait_for_resolution()
            │
            ▼  (blocks asyncio event)
        Human responds via:
          • CLI    inline prompt (y/n/always)
          • Web UI Approve/Deny buttons  → POST /api/approvals/{id}/resolve
          • Teams  Adaptive Card submit  → relayed by cloud channel
          • Slash  /approve|/deny|/always <id>  (all channels)
```

## Approval Request Model (`ApprovalRequest`)

| Field | Type | Description |
|-------|------|-------------|
| `id` | `str` | UUID4 hex — stable, unguessable |
| `tool_name` | `str` | Tool requiring approval |
| `args` | `dict` | Proposed arguments |
| `agent_name` | `str` | Requesting agent |
| `channel` | `str` | Channel where user is active |
| `channel_id` | `str` | Channel-specific conversation id |
| `risk` | `str` | low / medium / high / critical |
| `reason` | `str` | Classifier explanation |
| `status` | `enum` | PENDING → APPROVED / DENIED / TIMEOUT |
| `created_at` | `datetime` | UTC creation timestamp |
| `resolved_at` | `datetime?` | UTC resolution timestamp |
| `resolver` | `str?` | Identity of resolver or "auto-approve-timeout" |

## State Machine

```
PENDING ──approve/deny──► APPROVED / DENIED
        ──timeout (high/critical)──► TIMEOUT (→ denied)
        ──timeout (low/medium)────► APPROVED (auto-approve)
```

- **Idempotent**: double-click or duplicate responses on the same `id` raise
  `ValueError` and are ignored.
- **In-memory**: cleared on agent restart (acceptable for v1).

## Channel Behaviour

### CLI
Inline `input()` prompt blocks the REPL turn:

```
⚠  Approval Required  [id: a1b2c3d4]
   Tool:    shell
   Risk:    high
   Action:  rm -rf /tmp/build
   Reason:  destructive shell command

   Approve? [y]es / [n]o / [a]lways  ›
```

- `y` / `yes` → approve
- `n` / `no` (or Enter) → deny
- `a` / `always` → approve + add to allowlist
- Ctrl+C / EOF → deny
- Auto-approve countdown shown for low/medium risk

### Web UI (local gateway `/chat`)

When the agent sends a message with `"type": "approval_request"` in the
WebSocket frame the chat UI renders an approval card with inline buttons:

```
┌──────────────────────────────────────────────┐
│ ⚠  Approval Required                          │
│ Tool:   http_request                           │
│ Risk:   medium                                 │
│ Action: POST https://api.example.com/transfer  │
│ Reason: outbound HTTP to external host         │
│ Expires in: 60s                                │
│                                                │
│  [✓ Approve]  [✗ Deny]  [♾ Always Allow]      │
└──────────────────────────────────────────────┘
```

Clicking a button POSTs to `/api/approvals/{id}/resolve` and disables
all three buttons.

### Cloud Web Chat (Teams / browser via Cloud Gateway)

Same JSON frame as local Web UI.  The gateway relays the button click as an
`approval_response` frame to the Python agent.

### Teams (Adaptive Card)

An Adaptive Card with three `Action.Submit` buttons is sent via the Bot
Framework relay.  The card's `data` payload carries
`approval_action` + `approval_request_id`, which the Python agent's
`_try_route_approval` handler reads from `msg.metadata`.

### Slash commands (all channels)

```
/approve <id>   approve
/deny    <id>   deny
/always  <id>   approve + add to allowlist
```

Work in every channel; useful as fallback when buttons are not rendered.

## Security

- Approval IDs are 32-char UUID4 hex strings (128 bits entropy) — not
  guessable.
- Resolver identity (`msg.sender_id` or `"cli-user"`) is logged in the
  audit trail.
- All decisions emit `TOOL_APPROVED` / `TOOL_DENIED` bus events and are
  written to the audit log.
- The allowlist (`/always`) is scoped per tool name; future versions may
  scope by args pattern.

## Key Files

| File | Role |
|------|------|
| `workpilot/security/approval.py` | State machine, `ApprovalManager` |
| `workpilot/security/approval_format.py` | Per-channel formatters |
| `workpilot/hooks/handlers.py` | `ApprovalHook` — wires classifier → manager → channel |
| `workpilot/agent/loop.py` | `_try_route_approval()` — slash command + metadata routing |
| `workpilot/gateway/static/chat.html` | Web UI approval card + buttons |
| `workpilot/gateway/api_handlers.py` | `handle_approval_resolve()` REST endpoint |
| `workpilot/gateway/server.py` | `/api/approvals` + `/api/approvals/{id}/resolve` |
| `cloud_gateway/.../Relay/WebChatEndpoint.cs` | Relay approval responses from web chat |
