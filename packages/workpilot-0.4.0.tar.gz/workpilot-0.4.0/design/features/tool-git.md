# Git Tool

> **Date**: 2026-02-28
> **Tool name**: `git`
> **Risk level**: medium (write ops), high (push)
> **Isolation**: process

---

## Reference (from actual source code)

| Feature | nanobot | OpenClaw | NanoClaw | ZeroClaw | IronClaw |
|---------|---------|---------|----------|----------|----------|
| **Git tool type** | Shell (generic) | Shell (exec approval) | Claude Code Bash | **Dedicated `git_operations.rs`** | Shell (generic) |
| **Force-push block** | None | Prompt-level | Prompt-level | **Omitted from operations** | **`NEVER_AUTO_APPROVE`** |
| **Reset --hard block** | None | None | Prompt-level | **Medium-risk gate** | **`NEVER_AUTO_APPROVE`** |
| **git clean -f block** | None | None | None | **Omitted** | **`NEVER_AUTO_APPROVE`** |
| **--no-verify block** | None | None | None | **Argument sanitizer** | None |
| **-c config injection** | None | None | None | **Argument sanitizer** | None |
| **Command injection** | None | None | None | **`$()`, backtick, pipe, `;`** | **base64, hex, DNS exfil** |
| **Autonomy levels** | None | Exec modes | None (bypass) | **ReadOnly/Supervised/Full** | Approval levels |
| **Structured output** | None | None | None | **JSON-parsed** | None |
| **Rate limiting** | None | None | None | **Per-hour** | **20/min, 200/hour** |

**Key insights:**
- **ZeroClaw** is the gold standard: dedicated tool, deliberately excludes dangerous ops, blocks `--no-verify` and `-c`, structured JSON output
- **IronClaw** has the best shell-level git safety: `NEVER_AUTO_APPROVE` for force-push, reset --hard, clean -f
- **nanobot** has zero git safety — any git command runs freely through shell
- WorkPilot should combine ZeroClaw's structured tool + IronClaw's never-auto-approve pattern

---

## 1. Why a Dedicated Git Tool

Git via shell has two problems:
1. **Bypass risk**: Shell deny patterns can't reliably catch all dangerous git operations (e.g., `git push -f` vs `git push --force` vs `GIT_FORCE=1 git push`)
2. **No structure**: Shell returns raw text; LLM must parse `git status` output to understand state

ZeroClaw solves both with a dedicated tool that:
- Exposes only safe operations as an **allowlist** (not a denylist)
- Returns **structured data** (JSON-parsed status, diff, log)
- Sanitizes arguments at the parameter level (blocks injection)

WorkPilot follows this approach.

---

## 2. Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `operation` | string | yes | — | Git operation (from allowed list) |
| `args` | string | no | — | Additional arguments (sanitized) |
| `working_dir` | string | no | workspace root | Repository path |

---

## 3. Allowed Operations

### Read Operations (low risk, always allowed)

| Operation | Example | Output |
|-----------|---------|--------|
| `status` | `git status` | Structured: modified files, staged, untracked |
| `diff` | `git diff`, `git diff HEAD~1` | Unified diff text |
| `log` | `git log -10` | Structured: commits with hash, author, message, date |
| `show` | `git show HEAD` | Commit details + diff |
| `branch` | `git branch`, `git branch -r` | List of branches with current marker |
| `remote` | `git remote -v` | List of remotes |
| `stash list` | `git stash list` | List of stashed changes |

### Write Operations (medium risk, subject to Security Agent + approval gate)

| Operation | Example | Risk | Notes |
|-----------|---------|------|-------|
| `add` | `git add src/main.py` | medium | Prefer specific files over `-A` |
| `commit` | `git commit -m "message"` | medium | See commit workflow below |
| `checkout` | `git checkout feature-branch` | medium | Switch branch only |
| `stash` | `git stash`, `git stash pop` | medium | Save/restore work |
| `merge` | `git merge feature-branch` | medium | Non-destructive merge |
| `pull` | `git pull` | medium | Fetch + merge |
| `fetch` | `git fetch` | low | Download only, no local changes |
| `tag` | `git tag v1.0` | low | Create tag |

### Push (high risk, default requires approval)

| Operation | Risk | Default | Configurable |
|-----------|------|---------|-------------|
| `push` | high | Requires approval | `auto_push: true` to auto-approve |
| `push --force-with-lease` | high | Requires approval | `auto_push: true` to auto-approve |

Users who want autonomous push can set `auto_push: true` in config. This is common for solo developers who trust the agent to push to feature branches.

### Dangerous Operations (require explicit user approval every time, never auto-approve)

| Operation | Risk | Why |
|-----------|------|-----|
| `push --force` / `push -f` | critical | Can destroy remote history |
| `reset --hard` | critical | Destroys uncommitted work |
| `clean -f` / `clean -fd` | critical | Permanently deletes untracked files |
| `checkout .` / `checkout -- .` | critical | Discards all local changes |
| `branch -D` | high | Force-deletes branch without merge check |

These are **not blocked** — they are allowed with explicit per-invocation user approval. `auto_push` does not bypass these; the user must confirm each time.

Approval prompt includes a safe alternative suggestion:
```
⚠ Dangerous git operation needs approval:
  Command: git push --force origin main
  Risk: Can destroy remote history
  Safer alternative: git push --force-with-lease

  [Approve] [Deny]
```

### Unsupported Operations

| Operation | Why |
|-----------|-----|
| `rebase -i` | Requires interactive terminal input — not supported in agent context |

---

## 4. Argument Sanitization (ZeroClaw pattern)

Before executing any git operation, arguments are sanitized to prevent injection:

**Blocked argument patterns:**

| Pattern | Why |
|---------|-----|
| `--exec=*` | Arbitrary command execution |
| `--upload-pack=*` | Remote code execution via pack protocol |
| `--receive-pack=*` | Remote code execution via pack protocol |
| `--pager=*` | Arbitrary command via pager |
| `--editor=*` | Arbitrary command via editor |
| `--no-verify` | Skip pre-commit hooks (bypasses safety checks) |
| `-c key=value` | Git config injection (can override security settings) |
| `$(...)` | Command substitution |
| `` ` `` | Backtick command substitution |
| `\|` | Pipe to another command |
| `;` | Command chaining |
| `>` / `>>` | Output redirection |

If any blocked pattern is detected:
```
Blocked: potentially dangerous git argument "--exec=/bin/sh"
```

---

## 5. Security Integration

Git operations go through the same three-layer security model as shell (see tool-shell.md), with git-specific rules:

### Layer 1: Rule Engine

| Classification | Operations |
|---------------|------------|
| **ALLOW** | status, diff, log, show, branch (list), remote, stash list, fetch |
| **DANGEROUS** | push --force, reset --hard, clean -f, checkout ., branch -D → always require per-invocation approval |
| **UNCERTAIN** | add, commit, checkout (branch), merge, pull, push, stash, tag |

### Layer 2: Security Agent

For UNCERTAIN operations, the Security Agent receives:
- The git operation + arguments
- Current repo state (branch, dirty/clean, remote tracking)
- Security profile

The Security Agent classifies as ALLOW / DENY / SUSPICIOUS / LOW_RISK.

### Layer 3: Approval Gate

| Operation | Default | With `auto_push: true` |
|-----------|---------|----------------------|
| `push` | Requires approval | Auto-approve |
| `commit`, `merge`, `pull` | Security Agent decides; LOW_RISK auto-approves after 3 min | Same |
| `add`, `checkout`, `stash` | Security Agent decides; usually ALLOW | Same |

---

## 6. Commit Workflow

When the agent creates a commit:

1. **Stage specific files** (not `git add -A` — avoids accidentally staging secrets or large binaries)
2. **Generate commit message** following conventional commits format
3. **Never skip hooks** — `--no-verify` is blocked at the argument sanitizer level
4. **Author identity** uses the user's git config (`user.name`, `user.email`) — not overridden

---

## 7. Structured Output

Unlike shell-based git (raw text), the git tool returns structured data for key operations:

### status

```json
{
  "branch": "feature-auth",
  "tracking": "origin/feature-auth",
  "ahead": 2,
  "behind": 0,
  "staged": ["src/auth.py"],
  "modified": ["src/config.py"],
  "untracked": ["tests/test_auth.py"],
  "clean": false
}
```

### log

```json
{
  "commits": [
    {
      "hash": "abc1234",
      "short_hash": "abc1234",
      "author": "Wei <wei@contoso.com>",
      "date": "2026-02-28T10:30:00+08:00",
      "message": "feat: add auth module"
    }
  ]
}
```

### diff

Returns raw unified diff text (not structured — diffs are best consumed as text by LLMs).

---

## 8. Config

```yaml
tools:
  git:
    allow_push: true                # false to block ALL pushes
    auto_push: false                # true to auto-approve push (no confirmation needed)
    allow_force_with_lease: true    # allow --force-with-lease
    blocked_operations:             # extend default block list
      - 'reflog delete'
    blocked_args:                   # extend default blocked arguments
      - '--no-gpg-sign'
    security_agent:
      enabled: true                 # use Security Agent for uncertain operations
      model: auto
```
