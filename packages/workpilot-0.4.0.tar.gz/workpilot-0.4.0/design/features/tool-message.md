# Message Tool

> **Date**: 2026-03-01
> **Tool name**: `message`
> **Risk level**: low
> **Isolation**: process
> **Approval**: never

---

## Reference (from actual source code)

| | nanobot | OpenClaw | NanoClaw | ZeroClaw | IronClaw |
|---|---|---|---|---|---|
| **Has message tool** | **Yes** (`MessageTool`) | Per-channel actions | IPC file-based | Agent IPC (`AgentsSendTool`) | **Yes** (`MessageTool` + approval) |
| **Cross-channel** | Any channel, unrestricted | Via `to` parameter | Restricted (auth check) | Agent-to-agent only | Any channel, approval-gated |
| **Approval** | None | None | Auth check | Policy-based | **Cross-channel requires approval** |
| **Media support** | **Yes** (file paths) | Yes | No | No | Yes (path-sandboxed) |
| **Rate limit** | None | None | None | None | 10/sec, 100/day |

**nanobot pattern adopted**: simple, direct, configurable. No approval (low risk — agent is sending messages the user would see anyway).

---

## 1. Purpose

The `message` tool lets the agent **proactively send messages to any connected channel**. Unlike the normal response flow (reply to current channel), this tool allows cross-channel communication.

**Use cases:**
- Agent processing a CLI task → notify Teams: "deployment complete"
- Agent running a scheduled job → send summary to user via Cloud channel
- Agent completing a long tool execution → send intermediate status update

**Not for:**
- Replying to the current channel (that's the normal OutboundMessage flow)
- Sending external emails/Teams messages via API (that's Graph tools — TODO)

---

## 2. Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `content` | string | yes | — | Message text to send |
| `channel` | string | no | current channel | Target channel name ("cli", "web", "cloud") |
| `thread_id` | string | no | — | Thread/conversation ID for threaded replies |
| `media` | list[string] | no | — | File paths to attach (images, documents) |

When `channel` is omitted, the message goes to the **current channel** (same as a normal response, but allows the agent to send mid-task updates without waiting for the full response).

---

## 3. How It Works

```
Agent decides to send a notification
  ↓
LLM calls: message(content="Build complete ✓", channel="cloud")
  ↓
pre_tool_use hook (E-stop check, policy check — approval: never)
  ↓
MessageTool.execute():
  1. Resolve target channel (param or default to current)
  2. Check target channel is in allowed list (configurable)
  3. Construct OutboundMessage
  4. Publish to Bus outbound queue
  ↓
post_tool_use hook (leak scan on content, audit log)
  ↓
ToolResult(success=true, output="Message sent to cloud")
  ↓
Channel Manager picks up OutboundMessage → routes to target channel
```

---

## 4. Context Management

Like nanobot, the message tool tracks the **current message context** — the channel and sender that triggered the current agent turn. This is set at the start of each turn by the Agent Loop.

| Property | Set by | Used for |
|----------|--------|----------|
| `default_channel` | Agent Loop (from InboundMessage.channel) | Default target when `channel` param omitted |
| `default_chat_id` | Agent Loop (from InboundMessage.sender_id) | Default recipient |
| `default_thread_id` | Agent Loop (from InboundMessage.thread_id) | Default thread for replies |

This means if the agent just calls `message(content="status update")` without specifying a channel, it sends to the same channel/thread that triggered the current conversation — essentially a mid-turn status update.

---

## 5. Configuration

```yaml
tools:
  message:
    enabled: true                    # can disable entirely
    allowed_channels: ["*"]          # which channels can be targeted ("*" = all, or explicit list)
    allow_media: true                # allow file attachments
```

### Channel Allowlist

Controls which channels the agent can target:

| Config | Behavior |
|--------|----------|
| `["*"]` (default) | Send to any connected channel |
| `["cli", "cloud"]` | Only CLI and Cloud channels |
| `["cloud"]` | Only Cloud (e.g., agent can notify Teams but not respond in CLI) |
| `[]` | Disabled — tool is registered but always returns error |

### Sub-Agent Exclusion

The `message` tool is **always excluded from sub-agents** (nanobot pattern). Sub-agents return results to their parent agent, which decides what to communicate to the user.

---

## 6. Safety

| Concern | Mitigation |
|---------|-----------|
| **Leak in content** | post_tool_use hook scans for credentials |
| **Spam** | Agent loop iteration limit (40) naturally bounds message count per turn |
| **Wrong channel** | Allowed channels configurable; default `["*"]` is permissive but audited |
| **Media exfiltration** | Media paths go through filesystem path validation (workspace restriction) |
| **Sub-agent abuse** | Excluded from sub-agents entirely |

**Approval: `never`** — the agent is sending messages on behalf of the user to the user's own channels. This is inherently low risk. If the user wants stricter control, they can restrict `allowed_channels` or change approval to `auto` in config override.

---

## 7. Output

```
# Success
ToolResult(success=true, output="Message sent to cloud")

# Success with media
ToolResult(success=true, output="Message sent to cloud with 2 attachments")

# Channel not connected
ToolResult(success=false, error="Channel 'cloud' is not connected")

# Channel not allowed
ToolResult(success=false, error="Channel 'cloud' is not in allowed_channels list")

# Empty content
ToolResult(success=false, error="Message content cannot be empty")
```
