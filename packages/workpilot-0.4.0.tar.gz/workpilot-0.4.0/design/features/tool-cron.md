# Cron Tool (Agent Self-Scheduling)

> **Date**: 2026-03-04
> **Tool name**: `cron`
> **Risk level**: low
> **Approval**: auto
> **Parent**: [core/scheduler.md](../core/scheduler.md) Section 7

---

## Reference

| Feature | nanobot | OpenClaw | Agent Zero |
|---------|---------|---------|------------|
| **Agent manages jobs** | CronTool (list/add/remove) | CLI/API only | Scheduler Tool (CRUD + wait) |
| **Dynamic persistence** | `jobs.json` | `jobs.json` | `tasks.json` |
| **Schedule types** | cron, interval, at | cron, interval, at | cron, interval, datetime |

WorkPilot follows nanobot's CronTool pattern — the agent can schedule its own future work at runtime.

---

## 1. Design

The CronTool is a built-in tool that lets the LLM manage scheduled jobs. It wraps the SchedulerService protocol (add/remove/enable/disable/list) as tool calls.

**When registered**: only when `cron.enabled=true` in config. The Runtime dynamically registers CronTool and adds `"cron"` to the default agent's tool list.

**Why a tool (not a skill)**: Skills are prompt overlays — they guide behavior but don't provide new capabilities. CronTool provides actual CRUD operations on the scheduler that the LLM cannot do through other tools.

---

## 2. Parameters

```json
{
  "type": "object",
  "properties": {
    "action": {
      "type": "string",
      "enum": ["list", "add", "remove", "enable", "disable", "describe"],
      "description": "Action to perform"
    },
    "job_id": {
      "type": "string",
      "description": "Job ID (required for remove/enable/disable/describe)"
    },
    "schedule": {
      "type": "string",
      "description": "Schedule type: 'at:+SECONDS' for delayed one-shot, 'at:ISO_DATETIME' for absolute time, 'at' for immediate, integer for interval, cron expression, or event type"
    },
    "prompt": {
      "type": "string",
      "description": "Job prompt (required for add)"
    },
    "notify_channels": {
      "type": "array",
      "items": { "type": "string" },
      "description": "Channels for result delivery. Default: ['*'] (broadcast to all active channels)"
    }
  },
  "required": ["action"]
}
```

---

## 3. Actions

### list

Returns all scheduled jobs with status, trigger type, schedule, and next run time.

```
Input:  cron(action="list")
Output: Scheduled jobs:
          daily-report: cron (0 9 * * 1-5) agent=default [enabled] next=2026-03-05T09:00:00+00:00
          monitor-ci: interval (3600) agent=explorer [enabled] next=2026-03-04T13:00:00+00:00
          __heartbeat__: interval (1800) agent=default [enabled] next=N/A
```

### add

Creates a new dynamic job. Persists to `.workpilot/cron/jobs.json`. When `notify_channels` is omitted, defaults to `["*"]` (broadcast to all active channels).

```
Input:  cron(action="add", schedule="at:+300", prompt="Remind me to check the build")
Output: Job 'agent-a1b2c3d4' added (schedule=at:+300).

Input:  cron(action="add", schedule="at:2026-03-04T15:00:00", prompt="Join standup meeting")
Output: Job 'agent-b2c3d4e5' added (schedule=at:2026-03-04T15:00:00).
```

Schedule auto-detection:
- `"at"`, `"at:+SECONDS"`, or `"at:ISO_DATETIME"` → one-shot trigger (nanobot `at_iso` pattern)
- Integer → interval (seconds)
- String with `.` matching EventType → event trigger
- Other string → cron expression

### remove

Removes a job by ID. Dynamic jobs also removed from `jobs.json`.

```
Input:  cron(action="remove", job_id="monitor-ci")
Output: Job 'monitor-ci' removed.
```

### enable

Re-enables a disabled job. Resets failure counter to 0.

```
Input:  cron(action="enable", job_id="monitor-ci")
Output: Job 'monitor-ci' enabled.
```

### disable

Pauses a job without removing it. Can be re-enabled later.

```
Input:  cron(action="disable", job_id="monitor-ci")
Output: Job 'monitor-ci' disabled.
```

### describe

Returns detailed information about a single job: schedule, agent, status, next run, and failure count.

```
Input:  cron(action="describe", job_id="monitor-ci")
Output: Job: monitor-ci
        Schedule: interval (3600)
        Agent: explorer
        Status: enabled
        Next run: 2026-03-04T13:00:00+00:00
        Failures: 0
```

---

## 4. Use Cases

| Pattern | Example |
|---------|---------|
| User asks for a reminder | "Remind me in 5 minutes" → `cron(add, "at:+300", "Remind: ...", notify_channels=["*"])` |
| User asks for a timed reminder | "Remind me at 3pm" → `cron(add, "at:2026-03-04T15:00:00", "Join meeting", notify_channels=["*"])` |
| User asks to schedule | "Check CI every hour" → `cron(add, 3600, "Check CI pipeline")` |
| User asks to cancel | "Stop the CI check" → `cron(remove, "monitor-ci")` |
| User asks what's scheduled | "What jobs are running?" → `cron(list)` |
| User asks about a job | "What does that job do?" → `cron(describe, "monitor-ci")` |
| Agent self-schedules | During a task, agent decides it needs follow-up → `cron(add, ...)` |
| User pauses a job | "Pause the daily report" → `cron(disable, "daily-report")` |
| React to events | "Alert me on leaks" → `cron(add, "security.leak", "Review audit log")` |

---

## 5. Security

| Aspect | Design |
|--------|--------|
| **Approval** | `auto` — Security Agent classifies in standard+ profiles |
| **Risk** | `low` — manages scheduling metadata, does not execute actions |
| **Protected** | Yes — in `PROTECTED_TOOLS` (cannot be shadowed by MCP) |
| **Sub-agents** | Not available — excluded from sub-agent tool sets (like spawn/message) |
| **E-stop** | Jobs created via CronTool are subject to E-stop when they execute |

---

## 6. Persistence

Dynamic jobs created via CronTool persist to `{workspace}/.workpilot/cron/jobs.json`. They survive restarts and are loaded alongside config jobs. Config jobs with the same ID take precedence.

---

## 7. Relationship to CLI

Both CronTool and CLI `workpilot cron` commands operate on the same SchedulerService. Jobs added via CronTool appear in `workpilot cron list` and vice versa.

| CronTool action | CLI equivalent |
|----------------|----------------|
| `list` | `workpilot cron list` |
| `add` | `workpilot cron add` |
| `remove` | `workpilot cron remove <id>` |
| `enable` | `workpilot cron enable <id>` |
| `disable` | `workpilot cron disable <id>` |
| `describe` | _not yet available in CLI_ |
