# Default Agent — Primary Orchestrator

> **Date**: 2026-03-02
> **Type**: Built-in Agent
> **Parent**: [builtin-agents.md](../builtin-agents.md) Section 3.1
> **Depends on**: [core/agent.md](../core/agent.md), [core/tool.md](../core/tool.md), [core/skill.md](../core/skill.md), [tool-spawn.md](tool-spawn.md)

---

## Reference (from actual source code)

| Dimension | Claude Code | nanobot | ZeroClaw | IronClaw | NanoClaw |
|-----------|-------------|---------|----------|----------|----------|
| **System prompt** | Dynamic assembly, 110+ conditional components (~15K tokens) | Static: system + IDENTITY.md + INSTRUCTIONS.md | Static: system_prompt config field + identity files | Static: system + AGENTS.md + skills (XML trust) | Claude Agent SDK preset + CLAUDE.md |
| **Context order** | System → CLAUDE.md → Memory → Skills → MCP → History → Reminders → User | System → History (100-msg) → Runtime → User | System → Memory recall (top-5 vector) → User | System → Skills (XML) → Messages | SDK (invisible) |
| **Tools** | 18 built-in + MCP dynamic | 7 built-in | Configurable per-agent allowlist | Container-scoped | SDK tools + MCP |
| **Delegation** | Task tool (5 subagent types) | SpawnTool → asyncio.Task | `delegate` (sync) + `subagent_spawn` (async) | `create_job` → Docker | Agent Swarms |
| **Max iterations** | No hard limit; token budget tracking | **40** (soft message) | **20** (hard bail) | Configurable (nudge → force → stop) | SDK-controlled |
| **Compaction** | wU2 at ~92%, 6.8x ratio, <3% semantic loss | None | `compact_context: true` | `compaction.rs` at token pressure | SDK (invisible) |
| **Loop detection** | Stop hooks, TodoWrite drift prevention | None | 3 detectors + 3-level verdict | Stuck job detection + self-repair | None |
| **Memory** | CLAUDE.md + MEMORY.md (auto, first 200 lines) | MEMORY.md + HISTORY.md | Semantic recall (SQLite + vector) | Workspace identity files (pgvector + RRF) | Per-group CLAUDE.md |
| **Streaming** | React+Ink, buffered chunks | Progress callbacks | 80-char delta chunks | Status updates | SDK (invisible) |
| **System reminders** | ~40 mid-conversation `<system-reminder>` tags | None | Safety heartbeat (periodic re-injection) | None | None |
| **Skills injection** | Dual-channel: metadata (visible) + hidden prompt. 2% context budget. | Always-loaded in prompt | Catalog + selector + gating + attenuation | XML trust model + SKILL.md | `/command` patterns |
| **Cost tracking** | Status line: model, context %, cost $ | None | None | 3 estimators: cost, time, value | None |
| **Permissions** | 5 modes (default/acceptEdits/plan/dontAsk/bypass) | None | OTP gating, E-stop state machine | Policy rules (Block/Warn/Review/Sanitize) | Container-level |
| **Hooks** | 17 events, 4 types (command/http/prompt/agent) | None | Safety heartbeat | None | None |
| **Planning tool** | TodoWrite (structured JSON task list) + EnterPlanMode | None | None | None | None |
| **Error recovery** | Error → LLM self-corrects; auth rotation; compaction | Skip error history in session | Missing tool retry (EN+CJK); 3-level loop detect | Stuck job detection → self-repair → escalation | Container exit code |

**Key findings:**
- **Claude Code**: Most mature. Dynamic prompt assembly, 17 hooks, 5 permission modes, TodoWrite for planning, system reminders for drift prevention, wU2 compaction at ~92%.
- **nanobot**: Simplest. ~40-line loop is the ancestor. Key insight: error history NOT persisted (prevents 400-error loops). 500-char tool result truncation.
- **ZeroClaw**: Research phase unique. Proactive fact-gathering before LLM response. Most configurable per-agent settings. E-stop state machine.
- **IronClaw**: Best enterprise safety. Router classifies intents. Job state machine. 3 cost estimators. Skills with trust/attenuation/gating.
- **NanoClaw**: Container isolation per group. Per-group CLAUDE.md as memory.

---

## 1. Design

The default agent is WorkPilot's **primary orchestrator** — the only agent that directly interacts with users, writes to long-term memory, and spawns sub-agents. It combines nanobot's simple loop with enhancements from Claude Code (dynamic prompt, system reminders, planning tools), ZeroClaw (research phase, loop detection), and IronClaw (graceful termination, cost tracking).

### Why One Primary Agent

All 5 reference projects + Claude Code, Cursor, Codex, Devin, and Copilot use a single primary agent as the entry point. The primary agent is the orchestrator; specialization happens via delegation to sub-agents. This is the universal consensus.

---

## 2. System Prompt Architecture

### 2.1 Modular Assembly (Claude Code Pattern)

WorkPilot's system prompt is assembled from **modular components** rather than a monolithic string. Each component is a template that may be conditionally included.

```
System Prompt Assembly:
  [0] Base identity (always)                    ← ~200 tokens, stable
  [1] Behavioral guidelines (always)            ← ~500 tokens, stable
  [2] Tool usage policies (always)              ← ~800 tokens, stable
  [3] Channel-specific rules (conditional)      ← ~200 tokens, per-channel
  [4] Security profile rules (conditional)      ← ~200 tokens, per-profile
  [5] Delegation guidance (conditional)         ← ~300 tokens, when agents available
  [6] Active skill summaries (conditional)      ← variable, 2% budget cap
  [7] Project type hints (conditional)          ← ~100 tokens, auto-detected
```

### 2.2 Base Identity (~200 tokens)

Always present. Defines who the agent is.

```
You are WorkPilot, an enterprise AI coding and office assistant.

You help users with software engineering tasks (coding, debugging, refactoring,
testing) and office productivity (email drafting, meeting scheduling, status reports).

You operate in a workspace directory and have access to tools for file operations,
shell commands, git, web search, and sub-agent delegation.
```

### 2.3 Behavioral Guidelines (~500 tokens)

Always present. Core behavior rules adapted from Claude Code's patterns.

```
Guidelines:
- Read code before modifying it. Understand existing patterns first.
- Prefer editing existing files over creating new ones.
- Keep changes minimal and focused — don't refactor unrelated code.
- Run tests after making changes when test infrastructure exists.
- Never introduce security vulnerabilities (OWASP Top 10).
- Include file_path:line_number when referencing code.
- Don't give time estimates for tasks.
- Don't add unnecessary comments, docstrings, or type annotations to code you didn't change.
- When blocked, try alternative approaches before asking the user.
- Keep responses concise. Use detail only when the task demands it.
```

### 2.4 Tool Usage Policies (~800 tokens)

Always present. Prescribes when to use which tool.

```
Tool usage:
- Use read_file to read files, not shell commands (cat, head, tail).
- Use edit_file for surgical edits, not shell commands (sed, awk).
- Use search_files to find content, not shell commands (grep, rg).
- Use list_dir for directory listing, not shell commands (ls, find).
- Reserve shell for commands that require execution (build, test, install).
- Use git tool for git operations, not shell.
- For broad codebase exploration, spawn an explorer sub-agent rather than
  running many search commands yourself.
- For complex tasks, consider spawning a sub-agent if one is available
  (check the Available Sub-Agents table).
- Batch independent tool calls together for parallel execution.
```

### 2.5 Conditional Components

Loaded based on runtime context:

| Component | Condition | Content |
|-----------|-----------|---------|
| **Channel rules** | Channel != CLI | Formatting rules for Teams/Outlook/Web (message length limits, thread etiquette) |
| **Security profile** | Profile != open | Security-specific restrictions ("All destructive operations require confirmation") |
| **Delegation guidance** | Sub-agents available | Table of available sub-agents with descriptions (see [builtin-agents.md](../builtin-agents.md) Section 2.2) |
| **Skill summaries** | Skills loaded | Short descriptions of available skills for on-demand activation |
| **Project type** | Auto-detected | Language/framework hints ("This is a Python project using pytest and FastAPI") |
| **Graph availability** | Graph configured | "You can read/send emails and manage calendar via Graph tools" |

### 2.6 System Reminders (Claude Code Pattern)

Mid-conversation reinforcement messages injected as `[system]` role messages at strategic points to prevent instruction drift during long sessions.

**When injected:**
- After every 10 tool calls: reinforce key behavioral guidelines
- After file modifications by external processes: "File X was modified externally. Re-read before editing."
- After context compaction: reinforce critical instructions
- After sub-agent results arrive: remind about synthesis responsibilities
- On security-relevant events: reinforce safety rules

**Format:**

```
[System reminder] You are approaching 80% context usage. Consider:
- Wrapping up the current task
- Spawning a sub-agent for remaining work
- Using /compact to free context space
```

**Implementation:** System reminders are inserted as system-role messages interleaved with the conversation history, NOT appended to the system prompt. This follows Claude Code's `<system-reminder>` pattern.

---

## 3. Context Assembly

### 3.1 Full Context Window Layout

Stable content first (maximizes prompt cache hits), dynamic content last.

```
[0] System prompt (base + guidelines + policies + conditional)  ← stable, cache-friendly
[1] Identity files:
    - SOUL.md (agent personality, if configured)                ← semi-stable
    - USER.md (learned user preferences, if exists)             ← semi-stable
    - AGENTS.md (multi-agent coordination rules, if exists)     ← semi-stable
[2] MEMORY.md facts (shared long-term memory)                   ← semi-stable
[3] Agent-specific MEMORY.md (memory/agents/default/)           ← semi-stable
[4] Skill summaries (2% of context budget)                      ← semi-stable
[5] Research context (if research phase ran)                     ← per-request
[6] Sub-agent discovery table                                    ← stable
[7] Conversation history (from session)                          ← growing
[8] System reminders (injected inline)                           ← periodic
[9] Pending sub-agent results (if any arrived)                   ← per-request
[10] User message                                                ← per-request
```

### 3.2 Identity File Loading (Claude Code Pattern)

Identity files are loaded in a hierarchy. Files closer to the workspace override earlier ones.

| File | Location | Purpose | Priority |
|------|----------|---------|----------|
| `SOUL.md` | `.workpilot/SOUL.md` or config path | Agent personality and identity | 1 (highest) |
| `USER.md` | `.workpilot/USER.md` or config path | Learned user preferences | 2 |
| `AGENTS.md` | `.workpilot/AGENTS.md` or config path | Multi-agent coordination rules | 3 |
| `workpilot.yaml` instructions | `agents.default.instructions` | Inline system prompt override | 4 (lowest) |

If `SOUL.md` exists, its contents are prepended to the system prompt. If `instructions` is also set in config, both are included (SOUL.md first).

### 3.3 MEMORY.md Loading

Following Claude Code's auto-memory pattern with nanobot's MEMORY.md:

- **Load**: First 200 lines of MEMORY.md loaded at session start (always in context)
- **Topic files**: Additional topic files (e.g., `debugging.md`, `patterns.md`) loaded on-demand
- **Survives compaction**: MEMORY.md is re-read from disk after compaction (Claude Code pattern)
- **Write access**: Only the default agent can write to MEMORY.md
- **Size cap**: 8KB maximum enforced (nanobot convention)

### 3.4 Skill Description Budget

Following Claude Code's progressive disclosure:

| Budget | Calculation | Purpose |
|--------|-------------|---------|
| **2% of context window** | ~4,000 tokens for 200K context | Skill summaries always in context |
| **Fallback** | 16,000 characters | When context window size unknown |

Only skill descriptions are loaded at start. Full skill content loads on-demand when the skill is activated (by user command or LLM decision). This prevents 20 skills × 2K tokens = 40K tokens of eager loading.

### 3.5 Prompt Caching Optimization

Content is ordered to maximize cache hits across requests (OpenClaw insight):

```
Cache-friendly (identical across requests):
  - System prompt blocks [0]
  - Identity files [1]
  - MEMORY.md [2-3]
  - Skill summaries [4]
  - Agent discovery table [6]

Cache-unfriendly (changes every request):
  - Research context [5]
  - Conversation history [7]
  - System reminders [8]
  - Sub-agent results [9]
  - User message [10]
```

---

## 4. Agent Loop

### 4.1 Core Loop (nanobot ~40-line ancestor + enhancements)

```
Message In
  ↓
Phase 0: on_message_received hook (prompt injection scan)
  ↓
Phase 1: Research Phase (ZeroClaw pattern)
  - Read-only tools: search_files, list_dir, read_file
  - Time-budgeted (15s), token-bounded (4K tokens)
  - Sentinel: LLM outputs "[RESEARCH COMPLETE]" to end
  ↓
Phase 2: Context Assembly
  - System prompt + identity files + MEMORY.md + skills + research + history + user message
  ↓
Phase 3: LLM ↔ Tool Loop (≤ max_iterations)
  │
  ├─ Context window check → auto-compact if > 80% (IronClaw 3-tier)
  │
  ├─ Provider.stream() → yield chunks to channel
  │
  ├─ If text-only response (no tool calls) → loop ends
  │
  ├─ Tool execution (IronClaw 3-phase, parallel when independent):
  │    Phase 1: pre_tool_use hooks for all N calls (sequential)
  │    Phase 2: Tool.validate() → Tool.execute() (parallel via asyncio.gather)
  │    Phase 3: post_tool_use hooks for all N results (sequential)
  │
  ├─ Loop detection check (repeat, poll, ping-pong)
  │    → inject warning if detected; terminate if persists
  │
  ├─ Graceful termination (IronClaw):
  │    iteration == max-2 → nudge: "Please wrap up"
  │    iteration == max-1 → force text (no tools)
  │    iteration == max   → hard stop with summary
  │
  └─ System reminder injection (every 10 tool calls)
  ↓
Phase 4: Post-processing
  - on_message_sent hook (outbound leak scan)
  - Session persist (JSONL append)
  - Memory consolidation check (async, non-blocking)
```

### 4.2 Research Phase (ZeroClaw — Only Project With This)

Before the main LLM-tool loop, proactively gather information using read-only tools:

```
User message arrives
  ↓
Skip research if:
  - Message is short (< 20 chars)
  - Message is a command (/stop, /new, etc.)
  - Follow-up in existing conversation (context already rich)
  ↓
Research phase (read-only tools: search_files, list_dir, read_file):
  1. Extract keywords from user message
  2. Search workspace files for keyword matches
  3. Search MEMORY.md / HISTORY.md for related context
  4. LLM processes search results
  ↓
Sentinel: if LLM outputs "[RESEARCH COMPLETE]", research ends
  ↓
Time budget: max 15 seconds (configurable)
Token budget: max 4,000 tokens of research context
  ↓
Research results injected at position [5] in context assembly
```

**Why this matters:** ZeroClaw found that proactive fact-gathering before the main loop reduces hallucination. The LLM has relevant context before making its first decision.

### 4.3 Tool Execution Pipeline

```
LLM returns tool_call(name, args)
  ↓
● pre_tool_use hook pipeline:
  1. E-stop gate — check if E-stop is active
  2. Policy gate — check security profile allows this tool
  3. Approval gate — auto/always/never per tool declaration
  4. Security Agent — fast LLM assessment (if controlled profile)
  ↓
Tool.validate(args) — JSON Schema validation
  ↓
Security boundary — process isolation (or container in restricted profile)
  ↓
Tool.execute(args) with asyncio.wait_for(timeout)
  ↓
● post_tool_use hook pipeline:
  1. Leak scan — credential pattern detection in output
  2. Redaction — mask detected secrets
  3. Audit log — structured event record
  ↓
ToolResult(success, output) → appended to messages
```

### 4.4 Graceful Termination (IronClaw Pattern)

Three-stage approach instead of a hard cutoff:

| Stage | When | Behavior |
|-------|------|----------|
| **Nudge** | iteration == max - 2 | System message: "Approaching iteration limit. Please wrap up your current task and summarize what you've accomplished." |
| **Force text** | iteration == max - 1 | LLM call WITHOUT tools (force text-only response) |
| **Hard stop** | iteration == max | Return: "Iteration limit reached. Here's what was accomplished..." |

### 4.5 Loop Detection (ZeroClaw + OpenClaw)

Three detectors run after each tool result:

| Detector | Pattern | Action |
|----------|---------|--------|
| **Repeat** | Same tool + same args called 3+ times consecutively | Inject: "You are repeating the same action. The result is unlikely to change. Try a different approach." |
| **Poll** | Tool called → result checked → same tool called (polling) | Inject: "You appear to be polling. The result is unlikely to change." |
| **Ping-pong** | Two tools alternating back and forth >4 times | Inject: "You are alternating between two actions without progress. Step back and reconsider your approach." |

If the pattern persists after one injection, terminate the loop.

### 4.6 Context Compaction (IronClaw 3-Tier)

| Threshold | Action | Details |
|-----------|--------|---------|
| **80%** | Compact | Summarize older messages with fast model. Keep recent 10. Original messages stored in History Store. |
| **85%** | Aggressive compact | Smaller summary. Keep recent 5. |
| **95%** | Truncate | Remove oldest messages entirely (no LLM summary). Keep recent 3. |

MEMORY.md and identity files are never compacted — they are re-read from disk after compaction (Claude Code pattern).

---

## 5. Delegation Logic

### 5.1 When to Delegate (LLM-Driven)

The default agent decides delegation based on the instructions in its system prompt. No programmatic routing — the LLM reads agent descriptions and chooses. This is the universal pattern across Claude Code, Cursor, Codex, and Copilot.

**Delegation guidance in system prompt:**

```
Delegation guidelines:
- Use 'explorer' for broad codebase search across many files.
  Explorer is fast and cheap — use it liberally for finding code.
- For other tasks, handle them directly unless:
  - The task would consume too much of your context window
  - The task needs many iterations (implement → test → fix cycles)
  - You want to parallelize independent subtasks
  - A user-configured sub-agent exists that's suited for the task
- Check the Available Sub-Agents table for any additional agents the user has enabled.

When NOT to delegate:
- Simple questions that need a quick answer
- Single file reads or small edits
- Tasks where you already have sufficient context
- When the user is having a conversation (not requesting a task)
```

### 5.2 Effort Scaling (Anthropic Research System Pattern)

The default agent scales delegation effort based on task complexity:

| Complexity | Strategy | Token Cost |
|------------|----------|-----------|
| **Simple** | Handle directly, no delegation | 2-5K |
| **Medium** | Spawn 1-2 agents sequentially | 10-30K |
| **Complex** | Spawn 3-5 agents in parallel | 50-100K |
| **Very complex** | Multi-wave: research → plan → implement → test → review | 100-200K |

### 5.3 What the Parent Passes to Sub-Agents

The parent constructs a delegation prompt with:

```
spawn(
  agent="coder",
  prompt="<task description>",
  context="<relevant context from parent's conversation>"
)
```

**Good delegation prompts include:**
- Clear task description with acceptance criteria
- Specific file paths when known
- Relevant context from the parent's conversation (NOT the full history)
- Expected output format
- Constraints or things to avoid

**Sub-agents receive:**
- Their own system prompt (from agent config)
- The delegation prompt + context as the user message
- Shared MEMORY.md (read-only)
- Shared workspace (read/write)
- Their own tool subset
- Fresh conversation history (no parent history — universal consensus)

### 5.4 Sub-Agent Result Handling

Results are injected as system messages into the parent's context:

```
[Sub-agent 'researcher' completed (task_id: abc123, iterations: 12/20, duration: 45s)]

## Summary
Found 3 approaches to rate limiting in FastAPI...

## Key Findings
- slowapi: Most popular, wraps limits library...
- Custom middleware: More control, 50 lines...

## Sources
- https://example.com/rate-limiting-guide
```

If the parent has already produced a response before the sub-agent completes, the result is queued and delivered at the start of the next user turn.

---

## 6. Memory Management

### 6.1 Two-Layer Memory (nanobot + Claude Code)

| Layer | File | Writer | Content | Loaded |
|-------|------|--------|---------|--------|
| **Facts** | `MEMORY.md` | Default agent only | Key project facts, architecture decisions, conventions | Always (first 200 lines) |
| **History** | History Store (SQLite) | All agents (tagged by agent ID) | Searchable log of past conversations and tool calls | On-demand (research phase) |

### 6.2 MEMORY.md Auto-Consolidation

```
After each turn completes:
  ↓
Check: messages in session > consolidation_threshold (default 50)?
  ├─ No → skip
  └─ Yes → async LLM consolidation:
       1. Extract key facts from recent messages
       2. Merge with existing MEMORY.md
       3. Deduplicate, prune stale entries
       4. Enforce size cap (8KB)
       5. Atomic write
       Runs async — does NOT block user response
```

### 6.3 Topic Files (Claude Code Auto-Memory Pattern)

MEMORY.md can link to topic files for detailed notes:

```
memory/
  MEMORY.md              # Main facts (first 200 lines auto-loaded)
  debugging.md           # Debugging patterns and solutions
  api-conventions.md     # API design decisions
  shared/
    MEMORY.md            # Shared across all agents
  agents/
    default/
      MEMORY.md          # Default agent's private notes
```

Topic files are loaded on-demand during the research phase or when the LLM requests them.

### 6.4 Session Persistence (nanobot JSONL)

Each message appended immediately as JSONL for crash safety. Tool results longer than 500 chars are truncated with `"... (truncated)"` in session (nanobot convention). Error messages are shown to the LLM in the current turn but NOT saved to session history (prevents 400-error loops — nanobot insight).

---

## 7. Streaming

### 7.1 LLM Response Streaming

```
Provider.stream(messages, tools) → AsyncIterator[LLMChunk]
  ↓
For each chunk:
  ├─ Text delta → publish StreamingChunk to Bus → channel renders
  └─ Tool call delta → buffer until complete → display tool name + spinner
  ↓
When tool starts executing:
  → Display: ⠋ Running shell: npm test... (elapsed time)
  ↓
When tool completes:
  → Display: ✓ shell completed (2.3s)
  ↓
When done → final OutboundMessage published to Bus
```

### 7.2 Sub-Agent Progress

When a sub-agent is running, the parent shows progress:

```
⠋ Sub-agent 'coder' working... (15s, iteration 8/25)
```

Progress updates come from the sub-agent's asyncio.Task via Bus events.

---

## 8. Error Recovery

| Error | Recovery | Source |
|-------|----------|--------|
| **Tool execution fails** | Error returned as ToolResult(success=false). LLM sees error and tries different approach. Error NOT saved to session. | nanobot |
| **ContextLengthExceeded** | Auto-compact: summarize history, retry once. If still fails, truncate. | IronClaw |
| **Provider timeout/5xx** | Circuit breaker → fallback to next provider in chain. | IronClaw |
| **Tool call missing in response** | Retry with: "Please use a tool to proceed, or provide a text response." | ZeroClaw |
| **Loop detected** | Inject warning → if persists, terminate loop. | OpenClaw + ZeroClaw |
| **E-stop triggered** | Immediate exit. All sub-agents cancelled. | ZeroClaw |
| **Sub-agent fails** | Error result injected into parent context. Parent decides next step. | All projects |
| **Spawn depth exceeded** | "Cannot delegate further — handle this task directly." | ZeroClaw |
| **Concurrency exceeded** | Queued: "Sub-agent queued (5/5 slots in use). Will start when a slot opens." | OpenClaw |

---

## 9. Permissions & Safety

### 9.1 Permission Modes

Permission modes control the **user-facing approval behavior** for tool calls. They operate on top of the security profile and autonomy levels defined in [core-infra.md](../core-infra.md) Section 9. A security profile sets the baseline policy; the permission mode determines how approval prompts surface to the user.

| Mode | Behavior | Autonomy Level Mapping | Use Case |
|------|----------|----------------------|----------|
| **default** | Prompt user for first use of each tool category | APPROVAL for unknown, AUTONOMOUS after first approval | Normal development |
| **auto** | Auto-approve read operations and file edits; prompt for shell and network | AUTONOMOUS for read/write, APPROVAL for shell/network | Fast prototyping |
| **plan** | Read-only; agent analyzes but cannot modify files or run commands | FORBIDDEN for write/shell, AUTONOMOUS for read | Safe exploration |
| **restricted** | All tool calls require explicit user approval | APPROVAL for all tools | Security-sensitive work |

### 9.2 Security Profile Impact

Security profiles are defined in [core-infra.md](../core-infra.md) Section 9.5.

| Profile | Default Agent Behavior |
|---------|----------------------|
| **open** | Full autonomy. All tools available. Approval minimal. E-stop manual only. |
| **standard** | Shell commands logged. File writes audited. Destructive git ops require confirmation. Auto E-stop on leak. |
| **controlled** | All tool calls assessed by Security Agent (fast LLM). Approval workflow for destructive ops. Auto E-stop on leak. |
| **restricted** | Sub-agents disabled. All tool calls require explicit human approval. MCP tools run in containers. Auto E-stop on leak. |

### 9.3 Audit Trail

Every tool call by the default agent is logged:

```json
{
  "event": "tool_call",
  "agent": "default",
  "tool": "shell",
  "args_hash": "sha256:abc123...",
  "result": "success",
  "duration_ms": 2300,
  "session_id": "abc123",
  "timestamp": "2026-03-02T10:30:00Z"
}
```

---

## 10. Configuration

### 10.1 Full Default Agent Config

```yaml
agents:
  default:
    name: "WorkPilot Assistant"
    description: "General-purpose assistant. Handles direct user interaction, orchestrates sub-agents."
    model: auto
    temperature: 0.3
    max_tokens: 8192
    max_iterations: 40
    timeout: 1200
    memory_window: 50
    memory_writable: true

    tools:
      - shell
      - read_file
      - write_file
      - edit_file
      - list_dir
      - search_files
      - git
      - http_request
      - web_search
      - web_fetch
      - browser
      - spawn
      - message

    # Permissions
    permissions:
      allow_shell: true
      allow_file_write: true
      allow_file_read: true
      allow_network: true
      allow_browser: true
      allow_spawn: true

    # Delegation
    max_spawn_depth: 2
    max_concurrent_children: 5

    # Research phase
    research_enabled: true
    research_timeout: 15          # seconds
    research_max_tokens: 4000

    # Context management
    compact_threshold: 0.80       # trigger compaction at 80%
    compact_aggressive: 0.85
    compact_truncate: 0.95

    # Loop detection
    loop_detection: true
    loop_repeat_threshold: 3      # same tool+args N times
    loop_pingpong_threshold: 4    # alternating tools N times

    # System reminders
    reminder_interval: 10         # inject reminder every N tool calls

    # Consolidation
    consolidation_threshold: 50   # messages before memory consolidation

    # Identity files
    soul_file: null               # optional: path to SOUL.md
    user_file: null               # optional: path to USER.md
    agents_file: null             # optional: path to AGENTS.md

    metadata:
      category: orchestrator
      builtin: true
```

### 10.2 Config Overrides

Users override any field:

```yaml
# workpilot.yaml
agents:
  default:
    model: "anthropic/claude-sonnet-4-6-20250514"  # specific model
    max_iterations: 60                              # more iterations
    research_enabled: false                         # disable research phase
    temperature: 0.5                                # more creative
```

### 10.3 Differences from Sub-Agents

| Aspect | Default Agent | Sub-Agents |
|--------|--------------|------------|
| User interaction | Direct (receives user messages) | Indirect (receives delegation prompts) |
| MEMORY.md write | **Yes** (only agent with write access) | No (read-only) |
| `spawn` tool | **Yes** | No (by default) |
| `message` tool | **Yes** | No (results return to parent) |
| Max iterations | 40 | 10-25 (per agent type) |
| System reminders | Yes (every 10 tool calls) | No |
| Research phase | Yes | No |
| Conversation history | Full session | Fresh (no parent history) |
| Context compaction | Yes (3-tier) | Yes (independent) |
| Loop detection | Yes | Yes (independent) |
| Hooks | Full pipeline (4 hooks) | Subset (pre_tool_use, post_tool_use) |

---

## 11. What WorkPilot Adds vs Reference Projects

| Addition | Source | Why |
|----------|--------|-----|
| Modular prompt assembly | Claude Code (110+ components) | Conditional sections for channel/profile/project type |
| System reminders | Claude Code (~40 `<system-reminder>` tags) | Prevents instruction drift in long sessions |
| Research phase | ZeroClaw (only project with this) | Reduces hallucination by fact-gathering first |
| Graceful termination | IronClaw (nudge → force → stop) | Better UX than hard cutoff |
| Loop detection (3 detectors) | OpenClaw + ZeroClaw | Prevents infinite loops |
| Auto-compaction (3-tier) | IronClaw (80/85/95%) | Handles long conversations |
| Progressive skill disclosure | Claude Code (2% budget) | Token-efficient skill loading |
| MEMORY.md survives compaction | Claude Code (re-read from disk) | Critical context not lost |
| Error history skip | nanobot | Prevents 400-error loops |
| Tool result truncation | nanobot (500 chars) | Keeps session lean |
| Delegation guidance in prompt | Claude Code (Task tool instructions) | LLM knows when to delegate |
| Two-layer memory | nanobot (MEMORY.md) + Claude Code (auto-memory) | Facts + searchable history |
| Topic memory files | Claude Code (separate .md files) | Scalable memory organization |
| Sub-agent result as system message | nanobot (Bus pattern) | Natural context injection |
| Enterprise permissions | Claude Code (5 modes) + IronClaw (policy rules) | Graduated autonomy for enterprise |
