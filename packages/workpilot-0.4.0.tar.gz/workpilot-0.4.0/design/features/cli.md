# CLI

> **Status**: v0.3
> **Date**: 2026-03-06
> **Framework**: Typer
> **Architecture**: CLI-as-Channel (nanobot pattern)

---

## 1. Entry Points

```
workpilot chat                    # Interactive REPL — attaches to running serve if available
workpilot run "fix the bug"       # One-shot prompt
workpilot serve                   # Start HTTP gateway (single-instance; second call shows PID/port)
workpilot cloud                   # Connect to Cloud Gateway — no-op if serve already handles it
workpilot init [--name NAME]      # Create or update workpilot.local.yaml (safe to re-run)
workpilot status                  # Show config and runtime state
workpilot doctor                  # Diagnose issues
workpilot logs                    # Show recent log output
workpilot version                 # Show version info
```

---

## 2. Command Reference

### 2.1 Core Commands

| Command | Options | Description |
|---------|---------|-------------|
| `chat` | `--config`, `--profile` | Interactive REPL. If `serve` is running, connects via WebSocket instead of starting a new Runtime. |
| `run` | `--session ID`, `--model MODEL`, `--output FILE`, `--config`, `--profile` | One-shot execution |
| `serve` | `--host`, `--port`, `--config`, `--profile` | Start HTTP gateway. Single-instance: second call shows PID/port and exits. PID at `~/.workpilot/gateway.pid`. |
| `cloud` | `--url URL`, `--login METHOD`, `--config`, `--profile` | Connect to Cloud Gateway. If `serve` is running and cloud is connected, shows status and exits. |
| `init` | `--dir DIR`, `--name NAME` | Create or update `workpilot.local.yaml`. Safe to run multiple times — existing values shown as defaults. |
| `status` | `--config`, `--profile` | Show config, agents, tools, channels, cron state |
| `doctor` | `--config`, `--profile` | Diagnose provider credentials, packages, tools, security |
| `logs` | `--lines N` | Show recent log output |
| `version` | — | Show version string |

### 2.2 Management Sub-Commands

```
workpilot sessions
  list                            # List sessions (recent first)
  show <id> [--lines N]           # View session messages
  delete <id> [--yes]             # Delete session
  export <id> [--format md|json] [--output FILE]  # Export session

workpilot memory
  show                            # Print MEMORY.md content
  search <query>                  # Search session history
  clear [--yes]                   # Clear MEMORY.md (with confirmation)
  stats                           # Show memory and session size stats

workpilot tools
  list                            # List registered tools with metadata
  info <name>                     # Show tool details (schema, risk, approval)

workpilot mcp
  list                            # List configured MCP servers
  add                             # Add MCP server interactively
  remove <name> [--yes]           # Remove MCP server

workpilot skills
  list                            # List available skills (bundled + workspace)
  show <name>                     # Show skill definition

workpilot cron
  list                            # List configured jobs
  add                             # Add cron job interactively
  remove <id> [--yes]             # Remove job
  enable <id>                     # Enable a disabled job
  disable <id>                    # Disable a job without removing it
  status                          # Scheduler health and job counts
  history [<id>] [--lines N]      # Show execution history (reads ~/.workpilot/cron/runs/)

workpilot security
  status                          # Show security profile and E-stop state
  estop [--reason TEXT] [--yes]   # Trigger emergency stop
  reset [--yes]                   # Reset E-stop
  audit                           # Show audit config and recent events
  credentials                     # Show credential provider status
  roles                           # Show configured RBAC roles
  allowlist                       # Manage per-user tool approval allowlist

workpilot secrets
  set <name> [--from-env VAR]     # Set a secret in the local credential store
  remove <name> [--yes]           # Remove a secret
  test                            # Test configured secrets (GitHub token, OpenAI key)

workpilot agents
  list                            # List configured agents
  add                             # Add agent interactively
```

---

## 3. Interactive REPL (`workpilot chat`)

### 3.1 Behavior

`workpilot chat` auto-detects whether `workpilot serve` is running:

- **serve running** → connects via WebSocket (`/api/ws`) to the existing gateway; no new Runtime started; responses arrive as complete messages (not streaming)
- **serve not running** → starts a local Runtime inline

### 3.2 REPL Slash Commands

Handled by `AgentLoop._handle_slash` before reaching the LLM:

| Command | Description |
|---------|-------------|
| `/help` | Show available slash commands |
| `/new` | Clear session, start fresh |
| `/status` | Show agent name, model, session ID, message count |
| `/memory` | Show MEMORY.md content |
| `/tools` | List available tools |
| `/skills` | List loaded skills |
| `/history [N]` | Show last N messages (default 10) |
| `/model <name>` | Show current model (switching not yet supported mid-session) |
| `/stop` | Hint to use Ctrl+C |
| `/exit` | Hint to use Ctrl+C |

Unknown slash commands are passed through to the LLM.

### 3.3 WS Mode Limitations (when serve is running)

- Responses are delivered as complete messages, not token-by-token
- Slash commands handled locally before sending to gateway
- No spinner or tool-call progress display

---

## 4. One-Shot Mode (`workpilot run`)

```bash
workpilot run "what files are in src/"
workpilot run "fix the bug" --model gpt-5.2
workpilot run "summarise" --output report.md
workpilot run "continue" --session abc123
```

---

## 5. Setup Wizard (`workpilot init`)

Creates or updates `workpilot.local.yaml` (gitignored, never committed).
Safe to re-run — existing values shown as defaults.

```
$ workpilot init
$ workpilot init --name my-project   # also sets top-level 'name' in config
```

**Steps:**
1. GitHub sign-in (configures Copilot token) — skipped if already set, offers re-auth
2. Default model (default: auto)
3. Security profile (default: standard)
4. Enable HTTP gateway? (default: no)

Writes `workpilot.local.yaml` with deep-merge over existing values.

---

## 6. Single-Instance Gateway (`workpilot serve`)

PID file: `~/.workpilot/gateway.pid` (JSON: `{"pid": N, "port": N}`)

- On start: check PID file → if process alive, print info and exit
- On exit (normal or Ctrl+C): `finally` block removes PID file
- Stale PID (process dead): cleaned up automatically on next start

---

## 7. Cloud Gateway (`workpilot cloud`)

```
workpilot cloud                   # Login (if needed) + connect + run agent loop
```

- Login method: `--login auto|browser|device` (default: auto)
- Token cached in `~/.workpilot/token_cache_<client_id[:8]>.json` via MSAL
- If `serve` is running:
  - cloud already connected → show status and exit
  - cloud not connected → warn user to configure and restart serve
- If `serve` not running: start cloud channel inline

---

## 8. Secrets Management (`workpilot secrets`)

Manages the **local OS keychain** (`keyring` library).

| Command | Description |
|---------|-------------|
| `set <name>` | Prompt for value (never as CLI arg) |
| `set <name> --from-env VAR` | Copy from environment variable |
| `remove <name>` | Delete from keychain |
| `test` | Verify GitHub token and OpenAI key with real API calls |

---

## 9. CLI Architecture

```
workpilot CLI (Typer)
  |
  +-- serve/cloud/chat  →  Runtime + channels (heavy path)
  |
  +-- management cmds   →  direct subsystem API (no Runtime, no Bus)
       sessions, memory, tools, cron, security, secrets, skills, agents
```

`workpilot chat` when serve is running:
```
workpilot chat  →  WebSocket client (/api/ws)  →  running Gateway  →  AgentLoop
```

---

## 10. Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | Error (config error, auth failure, etc.) |

---

## 11. Environment Variables

| Variable | Description |
|----------|-------------|
| `GITHUB_TOKEN` | GitHub Copilot / channel auth |
| `OPENAI_API_KEY` | OpenAI provider key |
| `AZURE_OPENAI_API_KEY` | Azure OpenAI key |
| `AZURE_OPENAI_ENDPOINT` | Azure OpenAI endpoint |
