# Copilot Tools

> **Date**: 2026-03-05
> **Tool names**: `gh_copilot`, `gh_copilot_status`, `gh_copilot_models`
> **Risk level**: medium / low / low
> **Dependency**: `github-copilot-sdk` (pip) + `gh copilot` CLI

---

## Overview

Three tools that delegate coding/review tasks to GitHub Copilot CLI and expose
Copilot session management to the WorkPilot agent.

All three are **optional**: if `github-copilot-sdk` is not installed, registration
is silently skipped (`ImportError` caught in `Runtime._register_tools()`).

| Tool | Purpose | Approval | Risk |
|------|---------|----------|------|
| `gh_copilot` | Submit a task to Copilot (background or wait) | `auto` | medium |
| `gh_copilot_status` | Query task status / list all tasks | `never` | low |
| `gh_copilot_models` | List available models with billing info | `never` | low |

---

## 1. Motivation

### `gh_copilot` vs `spawn` vs `shell`

| | `spawn` | `shell("gh copilot ...")` | `gh_copilot` |
|---|---|---|---|
| **Executor** | WorkPilot AgentLoop | gh copilot CLI | gh copilot CLI (SDK, JSON-RPC) |
| **Tools available** | WorkPilot's 14 built-ins | Copilot's own tools | Copilot's own tools |
| **Session history** | Fresh per call | Stateless | Persistent, resumable |
| **Background + notify** | asyncio.Task only | No built-in notify | Task registry + channel notification |
| **Model selection** | WorkPilot provider config | CLI flag | Per-call parameter |
| **Cost** | WorkPilot provider billing | Copilot subscription | Copilot subscription |
| **Auth** | WorkPilot provider key | `gh auth` | `gh auth` or configured token |

Use `spawn` for WorkPilot-native orchestration.
Use `gh_copilot` when the task needs Copilot's own tools (`view`, `glob`,
`shell`, `task`, `edit_file` …), may run for minutes, or must survive a restart.

---

## 2. Architecture

```
WorkPilot Runtime
  ├─ ToolRegistry
  │    ├─ gh_copilot   (CopilotDelegateTool)
  │    ├─ gh_copilot_status     (CopilotStatusTool)
  │    └─ gh_copilot_models     (CopilotModelsTool)
  │
  └─ CopilotDelegateService  (singleton, lazy-start)
       ├─ CopilotClient  (github-copilot-sdk, JSON-RPC over stdio)
       │    └─ gh copilot --headless  (1 process per Runtime, auto_restart=True)
       ├─ TaskRegistry   {task_id -> CopilotTask(status, result, notify_channel, ...)}
       └─ On complete -> MessageBus.publish_outbound -> original channel
```

**Session ID convention**:
`session_id = "wp-" + task_id` — deterministic, namespaces WorkPilot sessions in
`client.list_sessions()`, and enables resume by task_id without extra bookkeeping.

**Runtime wiring** — `runtime.py`:
```python
try:
    from workpilot.agent.tools.copilot import (
        CopilotDelegateService, CopilotDelegateTool, CopilotStatusTool, CopilotModelsTool,
    )
    gh_token = config.providers.github_copilot.token
    github_token = gh_token.get_secret_value() if gh_token else None
    self._copilot_service = CopilotDelegateService(self.workspace, self.bus, github_token=github_token)
    self.tool_registry.register(CopilotDelegateTool(self._copilot_service, self.bus))
    self.tool_registry.register(CopilotStatusTool(self._copilot_service))
    self.tool_registry.register(CopilotModelsTool(self._copilot_service))
except ImportError:
    self._copilot_service = None

# shutdown():
if self._copilot_service:
    await self._copilot_service.stop()
```

---

## 3. Authentication

`providers.github_copilot.token` (SecretStr) controls which auth path the CLI uses:

| Config | SDK behaviour | CLI auth |
|--------|--------------|---------|
| `token: null` (not onboarded) | `use_logged_in_user=True` | Reads `gh auth` keyring automatically |
| `token: "ghp_xxx"` (onboarded) | `use_logged_in_user=False` | Uses `COPILOT_SDK_AUTH_TOKEN` env var |

The raw token is never logged. *(Auth status check on first connect is planned.)*

---

## 4. Tool: `gh_copilot`

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `task` | string | yes | — | Full task description. Include file names, function names, expected behaviour. |
| `task_type` | enum | no | `code` | `code` \| `review` \| `test` \| `refactor` |
| `files` | string[] | no | `[]` | Workspace-relative paths for Copilot to focus on |
| `mode` | enum | no | `background` | `background`: returns immediately, notifies on done. `wait`: blocks until done. |
| `model` | string | no | `claude-sonnet-4.6` | See §7 for available models. |
| `resume_task_id` | string | no | — | *(planned)* Resume a prior task — session history restored. |

### Task type prompts

| task_type | Instruction sent to Copilot |
|-----------|----------------------------|
| `code` | "Implement the following task. Write clean, minimal code. Only change what is necessary. Run tests when applicable." |
| `review` | "Review the following code or task. Identify bugs, security issues, performance problems, and style violations. Be concise and actionable." |
| `test` | "Write tests for the following task. Use the existing test framework and conventions in the codebase." |
| `refactor` | "Refactor the following code. Keep behaviour identical. Improve readability, reduce duplication, and simplify where possible." |

Prompt sent to Copilot:
```
[REVIEW TASK]
{instruction}

Task:
{task}

Focus on these files/paths:
  - workpilot/auth/session.py
```

### Return values

**`mode=background`:**
```
Task submitted (id=abc123def456)
Type: review | Model: claude-sonnet-4.6
You will be notified on 'teams' when it completes.
Check status: gh_copilot_status(task_id="abc123def456")
```

**`mode=wait`:** returns Copilot's full response text synchronously.

---

## 5. Tool: `gh_copilot_status`

**Parameter**: `task_id` (string, optional — omit to list all tasks)

**List output:**
```
ID             TYPE       STATUS
------------------------------------
abc123def456   review     running
789xyz012abc   code       done
def456ghi789   refactor   failed
```

**Single task output** — fields: Task ID, Type, Status, and one of:
- `Result: (in progress...)` when running
- `Result:\n{first 500 chars}` when done
- `Error: {message}` when failed

---

## 6. Tool: `gh_copilot_models`

No parameters. Calls `client.list_models()` and returns a table:

```
MODEL                              CTX   PROMPT  BILLING
----------------------------------------------------------
claude-sonnet-4.6                 200K     128K  x1.0
claude-haiku-4.5                  144K     128K  x0.33
gpt-5-mini                        264K     128K  x0.0
...
```

Use this before calling `gh_copilot` to pick a model appropriate for the task.

---

## 7. Models & Billing

Available models (verified via `list_models()` on live subscription):

| Model | Context | Prompt limit | Billing |
|-------|---------|-------------|---------|
| `gpt-5-mini` | 264K | 128K | **0.0x** (free) |
| `gpt-4.1` | 128K | 64K | **0.0x** (free) |
| `claude-haiku-4.5` | 144K | 128K | **0.33x** |
| `gpt-5.1-codex-mini` | 400K | 128K | **0.33x** |
| `claude-sonnet-4.6` | 200K | 128K | **1.0x** (default) |
| `gpt-5.1-codex` | 400K | 128K | **1.0x** |
| `claude-opus-4.6` | 200K | 168K | **3.0x** |
| `claude-opus-4.6-1m` | 1M | 936K | **6.0x** |

Billing uses Copilot subscription **premium requests quota** — not WorkPilot's
LiteLLM provider. WorkPilot's `COST_WARNING` event does not track Copilot usage.

---

## 8. Execution Flow

```
Agent: gh_copilot(task="...", mode="background")
  |
  v
ToolRegistry injects channel context -> CopilotDelegateTool.execute()
  |
  v
CopilotDelegateService.submit()
  |  creates CopilotTask(task_id, PENDING, notify_channel=...)
  |
  +---> asyncio.create_task(_run_task)   [background; agent loop continues]
  `---> returns "Task submitted (id=...)"

[background]
_run_task():
  status = RUNNING
  session = client.create_session(model=..., hooks=...)   # session_id planned
  reply = await session.send_and_wait(prompt, timeout=None)
  session.destroy()   # CLI keeps history on disk
  status = DONE | FAILED
  MessageBus.publish_outbound(channel=notify_channel, ...)
```

**Wait mode**: same flow but `await _run_task()` directly — no `asyncio.create_task`.
*(Known bug: wait mode currently sends a notification too — should be skipped.)*

### Notification format

**Success:**
```
**Copilot task complete** (id=`abc123`, type=`review`)

{result — truncated at 4000 chars}
```

**Failure:**
```
**Copilot task failed** (id=`abc123`, type=`review`)
Error: {message}
```

---

## 9. Session Persistence

`session.destroy()` closes the Python handle but leaves history on disk at
`~/.copilot/session-state/`. A WorkPilot restart does not lose session history —
`resume_session(id)` still works after `client.stop()` + `client.start()`.

| Operation | History |
|-----------|---------|
| `session.destroy()` | Kept on disk |
| `client.stop()` / Runtime shutdown | Kept on disk |
| `client.delete_session(id)` | Permanently removed |

Resume flow *(planned)*:
```
resume_session("wp-{task_id}", ...) -> full conversation history restored
  -> send_and_wait(new_prompt) -> destroy -> notify
```

---

## 10. Hook Integration

| SDK hook | WorkPilot action |
|----------|-----------------|
| `on_pre_tool_use` | Log tool name; enforce `block_copilot_tools` deny-list |
| `on_post_tool_use` | Log tool name |
| `on_permission_request` | `PermissionHandler.approve_all` (gated by `on_pre_tool_use` deny-list) |

> **Security note**: `approve_all` means any Copilot tool not in the deny-list runs without
> per-command approval. For production deployments, configure `block_copilot_tools` to restrict
> dangerous tools: `tools.copilot.hooks.block_copilot_tools: ["shell", "edit_file"]`

---

## 11. Error Handling

| Scenario | Behaviour |
|----------|-----------|
| SDK not installed | Silent skip; tools unavailable |
| CLI not found | Task → `FAILED`; notification sent |
| Not authenticated | Task → `FAILED`; notification sent |
| Session not found on resume | Tool returns error; no task created |
| CLI crash | `auto_restart=True` restarts CLI; in-flight tasks → `FAILED` |
| Runtime shutdown with tasks running | Tasks cancelled; `FAILED` notification sent |

---

## 12. Config

```yaml
providers:
  github_copilot:
    token: null              # null -> gh auth keyring; "ghp_xxx" -> explicit token

tools:
  copilot:
    enabled: true
    cli_path: "copilot"
    default_model: "claude-sonnet-4.6"
    task_timeout: 600        # seconds; 0 = no timeout; enforced per Copilot task
    max_concurrent: 5        # parallel background tasks (Semaphore-based)
    notification_max_chars: 4000
    model_policy:            # per-task_type model override; falls back to default_model
      review:   "claude-sonnet-4.6"
      test:     "claude-haiku-4.5"
      code:     "claude-sonnet-4.6"
      refactor: "claude-sonnet-4.6"
    retry:
      enabled: false         # retry via resume_session on configured failures
      max_attempts: 2
      retry_on: [timeout]
    hooks:
      block_copilot_tools: []
```

---

## 13. Usage Examples

### Background review with Teams notification

```
User (Teams): Review the auth module before I merge.

Agent: gh_copilot(
    task="Review workpilot/auth/ for bugs and security issues. Max 5 bullets.",
    task_type="review", files=["workpilot/auth/"], mode="background"
)
<- "Task submitted (id=abc123). You'll be notified here when done."

[Teams, ~5 min later]
**Copilot task complete** (id=`abc123`, type=`review`)
1. Bug: token expiry not checked in refresh_token() (auth/session.py:142)
...
```

### Quick task in wait mode

```
Agent: gh_copilot(
    task="Add a docstring to validate_token in workpilot/auth/token.py.",
    task_type="code", files=["workpilot/auth/token.py"],
    mode="wait", model="claude-haiku-4.5"
)
<- [result returned synchronously]
```

### Check models, then pick one

```
Agent: gh_copilot_models()
<- MODEL        CTX   BILLING
   claude-haiku 144K  x0.33
   ...

Agent: gh_copilot(task="...", model="claude-haiku-4.5", ...)
```

---

## 14. Known Limitations

| Limitation | Detail |
|------------|--------|
| Alpha SDK | `github-copilot-sdk` v0.1.30, Technical Preview — breaking changes expected |
| Session history TTL | `~/.copilot/session-state/` grows without limit; no built-in cleanup |
| No streaming to channel | Notification is single message on completion; delta events not forwarded |
| No Copilot cost tracking | Premium request usage not visible to WorkPilot's cost events |
