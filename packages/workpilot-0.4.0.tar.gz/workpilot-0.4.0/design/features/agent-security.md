# Security Agent — Tool Approval Classifier

> **Date**: 2026-03-02
> **Type**: Built-in Agent (internal)
> **Parent**: [builtin-agents.md](../builtin-agents.md) Section 3.3
> **Depends on**: [core/tool.md](../core/tool.md) Section 3 (Approval Mechanism), [core-infra.md](../core-infra.md) Section 6 (Hooks)

---

## Reference

| Dimension | Claude Code | IronClaw | ZeroClaw | OpenClaw | nanobot |
|-----------|-------------|----------|----------|----------|---------|
| **Approval model** | 5 permission modes + hook system | SafetyLayer (Block/Warn/Review/Sanitize) | E-stop state machine + OTP gating | Per-agent tool allow/deny | None |
| **LLM classifier** | Prompt hooks (Haiku) | None (rule-based only) | None | None | None |
| **Rule engine** | PreToolUse hook matchers | `safety/validator.rs` + `safety/sanitizer.rs` | `no_progress_threshold` thresholds | Tool deny/allow lists | None |
| **Human approval** | Permission prompts (deny>ask>allow) | Policy rules (Block/Warn/Review) | OTP gating for sensitive ops | None | None |
| **Timeout fallback** | Not documented | Not documented | Not documented | Not documented | N/A |
| **Installed skill escalation** | Plugin trust model | Skills gating + attenuation | None | None | N/A |

**Key finding:** Claude Code is the only reference with an LLM-based approval classifier (via prompt hooks). IronClaw uses rule-based safety layers. Others rely on static tool allow/deny lists. WorkPilot's Security Agent follows Claude Code's LLM classifier pattern with IronClaw's layered safety approach.

---

## 1. Design

The Security Agent is a **fast, stateless LLM classifier** that evaluates tool calls for risk and policy compliance. It is the second layer in WorkPilot's two-layer approval mechanism:

```
Tool call from LLM
  ↓
Layer 1: Tool Declaration (static, <1ms)
  ├─ never   → allow immediately, skip Security Agent
  ├─ always  → always prompt user, skip Security Agent
  └─ auto    → delegate to Layer 2
  ↓
Layer 2: Security Agent (LLM, 1-3s)
  ├─ approve → execute
  ├─ deny    → reject, error to LLM
  └─ escalate → prompt user
```

### Why an LLM Classifier

Rule engines (regex patterns, allow/deny lists) handle known-safe and known-dangerous commands. But many tool calls fall into an **uncertain** middle ground:

- `shell: "curl https://internal-api.company.com/deploy"` — is this a read or a destructive deploy?
- `shell: "python scripts/cleanup.py --dry-run"` — safe dry-run, or destructive script?
- `git: "push origin feature/auth-refactor"` — normal push, or overwriting shared branch?

A fast LLM can reason about intent, context, and risk in ways that static rules cannot.

### Why Not Just Ask the User

Prompting the user for every uncertain tool call causes **approval fatigue** — users start auto-approving without reading. The Security Agent filters most calls to approve/deny, surfacing only genuinely ambiguous operations for human review.

---

## 2. Agent Configuration

```yaml
security:
  name: "Security Agent"
  description: "Internal: evaluates tool calls for risk and policy compliance."
  model: fast
  temperature: 0.0
  max_tokens: 1024
  max_iterations: 1
  timeout: 10
  tools: []
  permissions:
    allow_shell: false
    allow_file_write: false
    allow_file_read: false
    allow_network: false
    allow_browser: false
    allow_spawn: false
  memory_writable: false
  metadata:
    category: system
    builtin: true
    internal: true
```

| Field | Value | Rationale |
|-------|-------|-----------|
| `model: fast` | Cheapest/fastest model (Haiku, GPT-4o-mini) | Called per tool approval — must be cheap |
| `temperature: 0.0` | Deterministic | Same input should always give same classification |
| `max_iterations: 1` | Single pass | No multi-turn reasoning needed |
| `timeout: 10` | 10 seconds total | Agent-level hard cap. Per-tool configs may set shorter thresholds (e.g., shell: 3s). |
| `tools: []` | Zero tools | Pure classification, no side effects |
| `internal: true` | Hidden from user | Not shown in agent discovery table |

---

## 3. Input

The Security Agent receives a single-turn prompt with structured context about the tool call being evaluated.

### 3.1 Input Template

```
Evaluate this tool call for risk and policy compliance.

Tool: {tool_name}
Arguments: {redacted_args}
Working directory: {working_dir}
Security profile: {profile}
User intent: {user_message_summary}
{tool_specific_context}

Respond with JSON:
{
  "decision": "approve" | "deny" | "escalate",
  "risk": "low" | "medium" | "high" | "critical",
  "reason": "brief explanation"
}

Rules:
- approve: operation clearly matches intent, low risk
- deny: operation is dangerous, out of scope, or accesses sensitive resources
- escalate: uncertain — ask the user for confirmation
- When in doubt, escalate rather than approve
```

### 3.2 Context Fields

| Field | Source | Always present |
|-------|--------|---------------|
| `tool_name` | Tool call | Yes |
| `redacted_args` | Tool call arguments with secrets stripped (see below) | Yes |
| `working_dir` | Agent's current workspace | Yes |
| `profile` | Active security profile (open/standard/controlled/restricted) | Yes |
| `user_message_summary` | Last user message (truncated to 200 chars) | Yes |
| `tool_specific_context` | Extra context per tool type (see Section 3.3) | Tool-dependent |

### Argument Redaction

Before sending arguments to the Security Agent, sensitive fields are stripped or replaced with `[REDACTED]`. The Security Agent needs to classify **what operation is being performed**, not the secret values used.

| Tool | Fields redacted | What the Security Agent sees |
|------|----------------|------------------------------|
| `http_request` | `headers.Authorization`, `headers.X-API-Key`, `body` (if contains key patterns) | Method, URL, has_body=yes/no |
| `shell` | None (commands are the classification target) | Full command string |
| `git` | None (operations are the classification target) | Full operation + args |
| `web_fetch` | `headers.*` | URL only |
| `spawn` | None | Agent name + prompt summary |

Redaction uses the same Leak Detector patterns (JWT, AWS keys, GitHub PATs, etc.) already defined in [core-infra.md](../core-infra.md) Section 9.3.

### 3.3 Tool-Specific Context

#### Shell Commands

```
Command classification context:
- Deny patterns matched: none
- Allow patterns matched: none
- Command category: uncertain
```

The Security Agent only sees shell commands that passed Layer 1 deny/allow pattern matching but were classified as **uncertain**.

#### Git Operations

```
Git context:
- Operation: push
- Branch: feature/auth-refactor
- Remote: origin
- Repo status: clean (no uncommitted changes)
- Tracking: origin/feature/auth-refactor (up to date)
```

#### File Operations

```
File context:
- Path: /etc/nginx/nginx.conf
- Outside workspace: yes
- Path in deny list: no
```

#### HTTP Requests

```
HTTP context:
- Method: POST
- URL: https://api.production.company.com/deploy
- Has body: yes (content redacted)
- Headers: Authorization: [REDACTED], Content-Type: application/json
- Target: external (not localhost)
```

### 3.4 What the Security Agent Does NOT See

| Context | Available | Why |
|---------|-----------|-----|
| MEMORY.md | No | Irrelevant to security classification |
| Conversation history | No | Only current tool call matters |
| File contents | No | Cannot read files (no tools) |
| Previous tool results | No | Stateless per invocation |
| Agent's reasoning | No | Sees raw command, not the agent's explanation |

The Security Agent sees the **raw tool call**, not the agent's justification for making it. This prevents a compromised agent from social-engineering the classifier.

---

## 4. Output

### 4.1 Response Format

```json
{
  "decision": "approve" | "deny" | "escalate",
  "risk": "low" | "medium" | "high" | "critical",
  "reason": "brief explanation (1 sentence)"
}
```

### 4.2 Decision Mapping

| Decision | Effect | User sees |
|----------|--------|-----------|
| `approve` | Tool executes immediately | Nothing (transparent) |
| `deny` | Tool blocked, error returned to LLM | Nothing (LLM retries differently) |
| `escalate` | Rejected (treated as deny for safety). v0.2: prompt user for approval | "Escalated for review: {reason}" |

### 4.3 Risk Level Usage

The `risk` field is used for:
- **Audit logging** — recorded with every tool call
- **Approval presentation** — shown to user when escalated
- **Metrics** — track risk distribution over time

It does NOT affect the decision — `approve` with `risk: high` still executes immediately. The `decision` field is authoritative.

### 4.4 Malformed Response Handling

| Scenario | Fallback |
|----------|----------|
| Not valid JSON | Treat as `escalate` |
| Missing `decision` field | Treat as `escalate` |
| Unknown decision value | Treat as `escalate` |
| Empty response | Treat as `escalate` |

Conservative: any failure mode escalates to human review.

---

## 5. Hook Pipeline Integration

### 5.1 Position in Pipeline

The Security Agent is invoked from the **Approval Gate** handler in the `pre_tool_use` hook:

```
Tool call from LLM
  ↓
pre_tool_use hook pipeline (sequential, first Reject wins):
  │
  ├─ [1] E-stop gate
  │    Check if E-stop is active → reject all if halted
  │
  ├─ [2] Policy gate
  │    RBAC permission check → reject if user/role lacks permission
  │
  └─ [3] Approval gate
       │
       ├─ Check tool.metadata.approval:
       │    never  → Allow (skip Security Agent)
       │    always → Prompt user (skip Security Agent)
       │    auto   → Continue to Security Agent
       │
       ├─ Check security profile override:
       │    open → Skip Security Agent, auto-allow
       │    standard → Security Agent for medium+ risk only
       │    controlled → Security Agent active (all auto tools)
       │    restricted → Escalate 'never' tools to 'auto', Security Agent active (all)
       │
       ├─ [Security Agent invocation]
       │    Build input prompt → call fast LLM → parse JSON response
       │    Timeout: 3 seconds → treat as escalate
       │
       └─ Route decision:
            approve  → Allow
            deny     → Reject (error to LLM)
            escalate → Prompt user via active channel
  ↓
Tool.validate(args)
  ↓
Security boundary (process/container)
  ↓
Tool.execute()
  ↓
post_tool_use hook pipeline
```

### 5.2 User Approval Presentation

When the Security Agent escalates (or tool declares `always`):

| Channel | Presentation |
|---------|-------------|
| **CLI** | `⚠ Tool needs approval:` with `[Approve] [Deny] [Always allow]` |
| **Teams** | Adaptive Card with Approve/Deny buttons |
| **Gateway API** | HTTP 202 with `approval_id`; client polls or receives callback |

```
⚠ Shell command needs approval:
  Command: docker run --rm -v /:/host alpine cat /host/etc/shadow
  Risk: HIGH (Security Agent: possible data exfiltration via volume mount)

  [y] Approve  [n] Deny  [a] Always allow this pattern
```

"Always allow this pattern" saves a command pattern to the user's allowlist (config). Future matching commands bypass Security Agent.

### 5.3 Approval Timeout Behavior

| Classification | Timeout Behavior |
|---------------|-----------------|
| `escalate` (SUSPICIOUS) | Wait indefinitely for user approval |
| LOW_RISK (from Layer 1 rules) | Auto-approve after 3 minutes if no response |
| `always` (tool declaration) | Wait indefinitely |

---

## 6. Security Profile Interaction

The security profile determines **when** the Security Agent is invoked:

| Profile | `never` tools | `auto` tools | `always` tools |
|---------|--------------|-------------|---------------|
| **open** | Pass through | **Skip Security Agent**, auto-allow | Still always ask |
| **standard** | Pass through | **Security Agent for medium+ risk only** | Always ask |
| **controlled** | Pass through | **Security Agent active (all)** | Always ask |
| **restricted** | **Escalate to `auto`** | **Security Agent active (all)** | Always ask |

**Key behaviors:**
- `open`: Security Agent is never invoked — maximum autonomy
- `standard`: Security Agent classifies only medium-risk and above `auto` tools (shell, git write, http). Low-risk `auto` tools auto-allow.
- `controlled`: Security Agent classifies all `auto` tools
- `restricted`: Even `never` tools are escalated to `auto` — Security Agent evaluates everything except explicit `always` tools

### Installed Skill Escalation

When an **installed (external) skill** is active, the Security Agent gains additional responsibility:

```
Bundled/workspace skills only → normal approval rules
Any installed skill active    → ALL tool calls treated as approval: auto
                                (Security Agent evaluates everything)
```

This prevents a malicious installed skill from instructing the LLM to exfiltrate data through tools that would normally be auto-approved.

---

## 7. Per-Tool Classification Details

### 7.1 Shell Commands

Three-layer cascade (detailed in [tool-shell.md](tool-shell.md) Section 2):

```
Layer 1: Rule Engine (regex, <1ms)
  ├─ DENY patterns (rm -rf /, fork bomb, etc.) → blocked
  ├─ ALLOW patterns (ls, git status, python --version) → execute
  └─ UNCERTAIN → pass to Layer 2

Layer 2: Security Agent (LLM, 1-3s)
  ├─ approve → execute
  ├─ deny → blocked
  └─ escalate → pass to Layer 3

Layer 3: User Approval (human, async)
  ├─ Approve → execute
  ├─ Deny → blocked
  └─ Always allow → save pattern to allowlist
```

### 7.2 Git Operations

Two-layer cascade (detailed in [tool-git.md](tool-git.md) Section 5):

```
Layer 1: Operation classification (static)
  ├─ ALLOW: status, diff, log, show, branch (list), remote, fetch
  ├─ DANGEROUS: push --force, reset --hard, clean -f → always prompt user
  └─ UNCERTAIN: add, commit, push, merge, pull → pass to Layer 2

Layer 2: Security Agent
  Input: operation, args, branch, repo status, profile
  Output: approve / deny / escalate
```

### 7.3 Other Tools

| Tool | approval | Security Agent invoked? |
|------|----------|----------------------|
| `read_file` | never | No |
| `list_dir` | never | No |
| `search_files` | never | No |
| `write_file` | never | No (sandbox enforces path) |
| `edit_file` | never | No (sandbox enforces path) |
| `http_request` | auto | Yes (URL + method inspection) |
| `web_search` | never | No |
| `web_fetch` | auto | Yes (URL inspection) |
| `browser` | always (first use) / auto | Yes for auto invocations |
| `spawn` | auto | Yes (validates agent name + depth) |
| `message` | never | No |

---

## 8. Performance Requirements

The Security Agent is on the **critical path** of every `auto` tool call. Performance is essential.

| Metric | Target | Rationale |
|--------|--------|-----------|
| **Latency (p50)** | < 1s | Most classifications should be fast |
| **Latency (p99)** | < 3s | Per-tool timeout (e.g., shell: 3s). Agent hard cap: 10s. |
| **Cost per call** | < $0.001 | Fast model, ~500 input + ~100 output tokens |
| **Accuracy** | Conservative | False-escalate >> false-approve |

### 8.1 Token Budget

| Component | Tokens |
|-----------|--------|
| System prompt (instructions) | ~200 |
| Input template + context | ~200-400 |
| Response | ~50-100 |
| **Total per call** | **~450-700** |

At fast model pricing (~$0.25/M input, $1.25/M output), each Security Agent call costs approximately **$0.0002**.

### 8.2 Caching

Identical tool calls (same tool + same args + same profile) can be cached:

| Cache | TTL | Scope |
|-------|-----|-------|
| **In-memory** | 5 minutes | Per session |

Cache key: `hash(tool_name + args_json + profile)`. If the same `npm test` command is called 10 times in a session, only the first invocation hits the Security Agent.

---

## 9. Audit Trail

Every Security Agent invocation is logged:

```json
{
  "event": "security_agent_evaluation",
  "tool": "shell",
  "args_hash": "sha256:abc123...",
  "decision": "approve",
  "risk": "low",
  "reason": "Standard test command, read-only output",
  "latency_ms": 850,
  "model": "haiku",
  "profile": "standard",
  "cached": false,
  "session_id": "sess_xyz",
  "timestamp": "2026-03-02T10:30:00Z"
}
```

When escalated to user:

```json
{
  "event": "approval_request",
  "tool": "shell",
  "args_hash": "sha256:def456...",
  "security_agent_decision": "escalate",
  "security_agent_reason": "Unusual network command with volume mount",
  "user_decision": "deny",
  "user_action_time_ms": 5200,
  "session_id": "sess_xyz",
  "timestamp": "2026-03-02T10:30:05Z"
}
```

---

## 10. Configuration

### 10.1 Agent Override

Users can override the Security Agent's model or disable it:

```yaml
agents:
  security:
    model: "anthropic/claude-haiku-4-5-20251001"  # specific model
    timeout: 5                                      # shorter timeout
```

### 10.2 Per-Tool Override

Individual tools can configure Security Agent behavior:

```yaml
tools:
  shell:
    security_agent:
      enabled: true              # enable Layer 2 classification
      timeout: 3                 # seconds for classification call
    approval:
      auto_approve_timeout: 180  # seconds for LOW_RISK auto-approve
  git:
    security_agent:
      enabled: true
```

### 10.3 Disabling Security Agent

```yaml
# Option 1: Use open profile (skips Security Agent for auto tools)
security:
  profile: open

# Option 2: Disable Security Agent entirely
agents:
  security:
    enabled: false
```

---

## 11. Implementation Priority

The Security Agent depends on the approval mechanism:

| Phase | What | Depends On |
|-------|------|-----------|
| **1** | Security Agent config in schema | Config loader |
| **2** | LLM invocation (single-turn, fast model) | Provider + model aliases |
| **3** | pre_tool_use hook → Approval Gate → Security Agent call | Hook engine + tool registry |
| **4** | Response parsing + decision routing | Phase 3 |
| **5** | User approval presentation (CLI) | CLI channel |
| **6** | In-memory cache (5-min TTL) | Phase 3 |
| **7** | Audit logging | Audit logger |
| **8** | Per-tool Security Agent config | Phase 3 |
| **9** | Installed skill escalation | Skill loader |
