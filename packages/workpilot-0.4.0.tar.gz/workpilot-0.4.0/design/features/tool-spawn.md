# Spawn Tool (Sub-Agent Delegation)

> **Date**: 2026-02-28
> **Tool name**: `spawn`
> **Risk level**: medium
> **Isolation**: process

---

## Reference (from actual source code)

| Feature | nanobot | OpenClaw | NanoClaw | ZeroClaw | IronClaw |
|---------|---------|---------|----------|----------|----------|
| **Mechanism** | `SpawnTool` → asyncio.Task | `sessions_spawn` → Gateway RPC | Claude Code Agent Teams → Docker | **2 tools**: `delegate` (sync) + `subagent_spawn` (async) | `create_job` → Docker container |
| **Context** | Fresh (task only) | Fresh + system prompt | Fresh + workspace CLAUDE.md | Fresh + optional context + system prompt | Fresh (task only) |
| **Parent history** | **No access** | **No access** | **No access** | **No access** | **No access** |
| **Model config** | Same as parent | **Configurable per-spawn** | Inherited from SDK | **Fully configurable per-agent** (provider, model, temp) | Container mode (worker/claude_code) |
| **Tool scoping** | Reduced (no spawn/message) | Same agent, different session | Full SDK tools + MCP | **Explicit allowlist per agent**, no delegate/spawn | Container-isolated |
| **Max depth** | 1 (hard — no spawn given) | **Configurable** (default 1) | N/A (SDK internal) | **Configurable per-agent** (default 3) | 1 |
| **Concurrency** | Unlimited (no cap) | **5/agent, 8 global** | **5 containers** | **10 concurrent** (background) | 1 (sync) or unlimited (async) |
| **Iteration budget** | **15** (own, independent) | Timeout-based | SDK internal | **Per-agent** (default 10) | 10-min timeout |
| **Result return** | Bus InboundMessage | Auto-announce to session | Stdout markers + IPC | ToolResult via registry | broadcast → mpsc inject |
| **Error handling** | Log + announce | Cleanup hooks + session delete | Container exit code | Timeout + abort + dead letter | Poll timeout + container cleanup |

**Key findings from source code:**
- **All 5 projects** give sub-agents fresh context (no parent history) — this is consensus
- **nanobot**: simplest — asyncio.Task, 15 iterations, no concurrency cap, result via Bus
- **OpenClaw**: most operational — configurable model/depth/concurrency, auto-announce, spawn modes (run/session)
- **ZeroClaw**: most configurable — per-agent model/provider/system_prompt/tools/max_depth, dual sync+async, coordination bus with typed messages
- **IronClaw**: container-based jobs with credential grants

---

## 1. Design

WorkPilot uses a **single `spawn` tool** (nanobot simplicity) with **per-agent configuration** (ZeroClaw flexibility).

### Why One Tool (Not Two)

ZeroClaw has `delegate` (sync) + `subagent_spawn` (async). OpenClaw has `sessions_spawn` with `mode: "run" | "session"`. WorkPilot keeps it simple with one tool that is always **async** — the parent continues its loop and receives the result as a tool output when the sub-agent completes.

### Why Async by Default

- Sub-agent may take many iterations — blocking the parent wastes time
- Parent can spawn multiple sub-agents in parallel (fan-out)
- Result arrives as a tool call response — the LLM processes it naturally

---

## 2. Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `agent` | string | yes | — | Agent name from config registry |
| `prompt` | string | yes | — | Task to delegate |
| `context` | string | no | — | Optional context to pass (not parent's full history — ZeroClaw pattern) |
| `max_iterations` | int | no | agent config default (20) | Override iteration budget. LLM can pass shorter for simple tasks. |
| `timeout` | int | no | 600 | Max total seconds for sub-agent execution. LLM can pass shorter per call. |

---

## 3. How It Works

```
Parent Agent Loop (iteration N)
  ↓
LLM returns tool_call: spawn(agent="researcher", prompt="find examples of...")
  ↓
pre_tool_use hook pipeline (E-stop, policy, approval)
  ↓
SpawnTool.execute():
  1. Look up agent config by name
  2. Validate spawn depth (current depth < max_depth?)
  3. Create child with:
     - Fresh message history: [system_prompt, user_message_with_prompt+context]
     - Agent's own model/provider (can differ from parent — ZeroClaw pattern)
     - Agent's own tool subset (explicit allowlist, never includes spawn — nanobot pattern)
     - Agent's own iteration budget
  4. Launch as asyncio.Task (background — nanobot pattern)
  5. Return immediately: "Spawned agent 'researcher' (task_id: abc123). Result will be delivered when complete."
  ↓
Parent continues its loop (can spawn more agents or do other work)
  ↓
Sub-agent completes → result injected into parent's context as a system message:
  "[Sub-agent 'researcher' completed] {result summary}"
  ↓
Parent's next LLM call sees the sub-agent result
```

---

## 4. What Sub-Agents Get

### Context (consensus: fresh, not parent's history)

All 5 reference projects agree: sub-agents get **fresh context**, not the parent's conversation history.

| Component | Source | Description |
|-----------|--------|-------------|
| System prompt | Agent config (`agents.{name}.instructions`) | Agent-specific role and instructions |
| User message | `prompt` + `context` parameters | The delegated task |
| History | Empty | No parent history |
| Facts (MEMORY.md) | Shared (read-only) | Same MEMORY.md as parent — long-term project knowledge |
| Workspace | Shared | Same filesystem — can read/write same files |

### Model & Provider

Each agent can have its **own model and provider** (ZeroClaw pattern — the most configurable):

```yaml
agents:
  default:
    model: auto
    instructions: "You are a general-purpose assistant."
    max_iterations: 40
  researcher:
    model: auto
    instructions: "You research topics thoroughly. Search the web, read files, summarize findings."
    tools: [web_search, web_fetch, read_file, list_dir, search_files]
    max_iterations: 20
  coder:
    model: auto
    instructions: "You write and edit code. Run tests after changes."
    tools: [shell, read_file, write_file, edit_file, list_dir, git, search_files]
    max_iterations: 20
  reviewer:
    model: auto
    instructions: "You review code for bugs, security issues, and style."
    tools: [read_file, list_dir, search_files, git]
    max_iterations: 20
```

### Tools

Sub-agents get an **explicit tool subset** defined in their config. Tools NOT in the list are unavailable. Two tools are **always excluded** regardless of config (nanobot + ZeroClaw pattern):

- `spawn` — prevents recursive delegation
- `message` — sub-agents cannot directly message users

---

## 5. Scoping Rules

| Aspect | Rule | Source |
|--------|------|--------|
| **Permissions** | Cannot exceed parent's permissions. Agent config intersected with parent's active policy. | All projects |
| **Tools** | Explicit allowlist from agent config. `spawn` and `message` always excluded. | nanobot + ZeroClaw |
| **Iteration budget** | From agent config `max_iterations` (default 20). Independent from parent. | nanobot (15), ZeroClaw (configurable per-agent) |
| **Memory (facts)** | Reads same MEMORY.md. Does NOT write to MEMORY.md (read-only for sub-agents). | nanobot (shared workspace) |
| **Memory (history)** | Writes to own History Store entries, tagged with agent ID. | WorkPilot design |
| **Workspace** | Shared filesystem. Can read/write files in workspace. | All projects |
| **E-stop** | Shared. If triggered, parent + all sub-agents halt. | Core infra |
| **Session** | Independent. No access to parent's conversation history. | All 5 projects (consensus) |

---

## 6. Spawn Depth

| Setting | Default | Source |
|---------|---------|--------|
| `max_spawn_depth` | 2 | ZeroClaw (configurable, default 3), OpenClaw (default 1) |

Default: sub-agents **can spawn one level of sub-sub-agents** (depth 2). This allows patterns like: parent → researcher → web_fetcher.

```
Depth 0: Parent agent
Depth 1: Sub-agent (spawned by parent)
Depth 2: Sub-sub-agent (spawned by sub-agent) — allowed by default
Depth 3: Not allowed by default (max_spawn_depth=2)
```

When max depth exceeded: `"Spawn depth limit reached (depth 2, max 2). Cannot delegate further."`

---

## 7. Concurrency

| Setting | Default | Source |
|---------|---------|--------|
| Max concurrent sub-agents per parent | 5 | OpenClaw (5/agent), NanoClaw (5 containers) |

The LLM can request multiple spawn calls in one turn (parallel fan-out):

```
LLM response:
  tool_calls:
    - spawn(agent="researcher", prompt="research topic A")
    - spawn(agent="researcher", prompt="research topic B")
    - spawn(agent="coder", prompt="implement feature X")
```

All three run concurrently. Excess spawns beyond the limit are queued.

---

## 8. Result Delivery

When a sub-agent completes, the result is delivered to the parent as a **system message injected into the parent's context** (nanobot Bus pattern):

```
[Sub-agent 'researcher' completed (task_id: abc123)]
Found 3 relevant examples:
1. FastAPI authentication middleware in project X...
2. Flask-Login session handling in project Y...
3. Django REST Framework token auth in project Z...
```

The parent's next LLM call sees this message and can use the results.

If the parent has already completed its turn before the sub-agent finishes, the result is queued and delivered at the start of the next turn.

---

## 9. Error Handling

| Scenario | Behavior |
|----------|----------|
| Unknown agent name | Error: `Agent "xyz" not found in config` |
| Max depth exceeded | Error: `Spawn depth limit reached` |
| Max concurrency exceeded | Queued: `Sub-agent queued (5/5 slots in use). Will start when a slot opens.` |
| Sub-agent iterations exhausted | Return partial result + warning: `Agent 'coder' reached iteration limit (30/30)` |
| Sub-agent tool failure | Sub-agent handles internally. If unrecoverable, returns error message to parent. |
| Sub-agent E-stop | Parent also halts (shared E-stop) |
| Parent session ends | All sub-agents cancelled (cleanup) |

---

## 10. Config

```yaml
agents:
  default:
    model: auto
    instructions: "You are a general-purpose assistant."
    max_iterations: 40
    max_spawn_depth: 2
    max_concurrent_children: 5
  researcher:
    model: auto
    instructions: "You research topics. Search web, read files, summarize."
    tools: [web_search, web_fetch, read_file, list_dir, search_files]
    max_iterations: 20
  coder:
    model: auto
    instructions: "You write and edit code. Run tests after changes."
    tools: [shell, read_file, write_file, edit_file, list_dir, git, search_files]
    max_iterations: 20
  reviewer:
    model: auto
    instructions: "You review code for bugs, security issues, style."
    tools: [read_file, list_dir, search_files, git]
    max_iterations: 20
```
