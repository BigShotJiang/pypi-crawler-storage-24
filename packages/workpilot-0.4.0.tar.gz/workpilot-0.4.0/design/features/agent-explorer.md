# Explorer Agent — Fast Read-Only Search

> **Date**: 2026-03-02
> **Type**: Built-in Agent
> **Parent**: [builtin-agents.md](../builtin-agents.md) Section 3.2
> **Depends on**: [core/agent.md](../core/agent.md), [features/tool-spawn.md](tool-spawn.md)

---

## Reference

Based on Claude Code's Explore subagent — their most-used subagent type.

| Aspect | Claude Code Explore | WorkPilot Explorer |
|--------|--------------------|--------------------|
| **Model** | Haiku (fastest/cheapest) | `fast` alias |
| **Tools** | Glob, Grep, Read, Bash (read-only) | read_file, list_dir, search_files |
| **Read-only** | Yes (heavily enforced in prompt) | Yes (no write tools) |
| **Sub-spawning** | Disallowed | Disallowed |
| **Prompt** | 516 tokens — "file search specialist" | Similar, simplified |
| **Thoroughness** | quick / medium / very thorough (in prompt text) | Caller specifies in prompt |
| **Parallel tools** | Required ("spawn multiple parallel tool calls") | Encouraged |
| **Output** | Text message with absolute paths + line numbers | Same |

---

## 1. Design

The explorer is a **fast, cheap, read-only** agent for codebase search. It exists for one reason: the default agent uses the full model (auto) for everything, including search. Explorer uses the `fast` model at ~10x lower cost for the same search work.

```
Default agent                        Explorer agent
┌─────────────────────┐              ┌─────────────────────┐
│ model: auto ($$$)   │  spawn ──▶   │ model: fast ($)     │
│ all 13 tools        │              │ 3 read-only tools   │
│ 40 iterations       │              │ 15 iterations       │
│                     │  ◀── result  │ 120s timeout        │
└─────────────────────┘              └─────────────────────┘
```

### When to use explorer vs search directly

| Scenario | Do it yourself | Spawn explorer |
|----------|---------------|----------------|
| Find one specific file/function | Yes | No |
| Broad search across many files | No | Yes |
| Understand project structure | No | Yes |
| Find all usages of a pattern | No | Yes |
| Quick grep with known path | Yes | No |

Rule of thumb: if you'd need **3+ search/read tool calls**, spawn explorer.

---

## 2. Configuration

```yaml
explorer:
  name: "Explorer"
  description: "Fast codebase search and file discovery. Read-only."
  model: fast
  temperature: 0.1
  max_tokens: 4096
  max_iterations: 15
  timeout: 120
  tools: [read_file, list_dir, search_files]
  permissions:
    allow_shell: false
    allow_file_write: false
    allow_file_read: true
    allow_network: false
    allow_browser: false
    allow_spawn: false
  memory_writable: false
  metadata:
    category: development
    builtin: true
```

| Setting | Value | Why |
|---------|-------|-----|
| `model: fast` | Haiku / GPT-4o-mini | Search is high-volume, low-complexity |
| `temperature: 0.1` | Near-deterministic | Search doesn't need creativity |
| `max_iterations: 15` | Low budget | If it hasn't found it in 15 rounds, it won't |
| `timeout: 120` | 2 minutes | Quick or not at all |
| `tools: 3` | read_file, list_dir, search_files | Read-only — cannot modify anything |

---

## 3. System Prompt

```
You are a codebase explorer. Your job is to quickly find files, functions,
classes, and patterns in the codebase.

This is a READ-ONLY task. You cannot create, modify, or delete files.

Guidelines:
- Use search_files to grep for content patterns
- Use list_dir to understand directory structure
- Use read_file to examine specific files
- Make parallel tool calls wherever possible for speed
- Adapt your search thoroughness based on the request
- Return file paths with line numbers
- Do NOT suggest code changes — just report what you find
```

~100 tokens. Minimal by design — the prompt should not consume significant context.

---

## 4. Invocation

The default agent spawns explorer via the `spawn` tool:

```
spawn(
  agent="explorer",
  prompt="Find all error handling patterns in workpilot/gateway/. List file paths and line numbers."
)
```

The caller can specify thoroughness in the prompt text:

| Thoroughness | Prompt example |
|-------------|---------------|
| **Quick** | "Find the main entry point for the CLI" |
| **Medium** | "Find all files that import the Config class" |
| **Thorough** | "Map the complete authentication flow — find all related files, middleware, route handlers, and tests" |

This follows Claude Code's approach: thoroughness is a natural language instruction, not a formal parameter.

---

## 5. Output

Explorer returns a text message to the parent. No structured format enforced — the LLM naturally produces clear search results.

Typical output:

```
Found 5 error handling patterns in workpilot/gateway/:

1. workpilot/gateway/routes.py:45 — bare except clause, swallows all errors
2. workpilot/gateway/routes.py:112 — catches HTTPException, re-raises correctly
3. workpilot/gateway/auth.py:78 — catches ValueError, logs but doesn't re-raise
4. workpilot/gateway/auth.py:156 — try/except around MSAL token validation
5. workpilot/gateway/app.py:23 — global exception handler, returns 500

All patterns use loguru for logging. No custom exception classes defined.
```

The parent agent receives this as a tool result and decides what to do with it.

---

## 6. Restrictions

| Restriction | Enforcement |
|-------------|-------------|
| No file writes | `allow_file_write: false` + write tools not in tool list |
| No shell | `allow_shell: false` + shell not in tool list |
| No network | `allow_network: false` + no network tools |
| No spawning | `allow_spawn: false` + spawn not in tool list |
| No memory writes | `memory_writable: false` |
| Read-only prompt | System prompt says "READ-ONLY task" |

Enforcement is **two-layered**: tool access restrictions (hard) + prompt instructions (soft). Even if the LLM tries to use write tools, they're not available.

---

## 7. Cost

| Metric | Explorer | Default agent (same search) |
|--------|----------|----------------------------|
| Model | fast (~$0.25/M in, $1.25/M out) | auto (~$3/M in, $15/M out) |
| Typical search tokens | 5K-15K | 5K-15K |
| Cost per search task | ~$0.005 | ~$0.05 |
| **Savings** | **~10x cheaper** | baseline |

For a session with 10 search tasks, explorer saves ~$0.45 vs doing all searches in the default agent.
