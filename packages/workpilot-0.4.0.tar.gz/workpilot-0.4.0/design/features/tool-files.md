# File Tools

> **Date**: 2026-02-28
> **Tools**: `read_file`, `write_file`, `edit_file`, `list_dir`, `search_files`
> **Risk level**: read/list/search=low, write/edit=medium
> **Isolation**: process

---

## Reference (from actual source code)

| Feature | nanobot | OpenClaw | NanoClaw | ZeroClaw | IronClaw |
|---------|---------|---------|----------|----------|----------|
| **Tool count** | 4 | 3 (wrapped) | N/A (mount-level) | **5** (read/write/edit/glob/search) | 4 |
| **Edit mechanism** | old/new, unique, **fuzzy match on fail** | old/new (pi-coding-agent) | N/A | old/new, strict unique, reject empty | old/new + `replace_all` option |
| **Path validation** | `resolve()` + `relative_to()` | **O_NOFOLLOW + lstat + stat identity** | `realpathSync` + blocked patterns | `canonicalize` + null byte + URL-encoded | `canonicalize` + ancestor walk |
| **Read size** | No limit | **50KB-512KB adaptive to context** | N/A | 10MB | 1MB |
| **Write size** | No limit | No limit | N/A | No explicit | 5MB |
| **Binary handling** | Crashes (UTF-8 only) | Image MIME sniffing | N/A | **Lossy UTF-8 + PDF extract** | Crashes |
| **Line-range read** | No | Yes | N/A | Yes (offset/limit) | Yes (offset/limit) |
| **Search/grep** | No | No | N/A | **ripgrep + glob** (2 tools) | No |
| **Rate limiting** | No | No | N/A | 20/hour window | 20/min, 200/hour |
| **Blocked paths** | None (workspace) | Sandbox root | **17 patterns** | **14 dirs + 4 dotfiles** | None (sandbox) |
| **Null byte block** | No | No | No | **Yes** | **Yes** |
| **URL-encoded traversal** | No | No | No | **Yes** (`..%2f`) | **Yes** (`%2e,%2f,%5c`) |

---

## 1. Tool Inventory

5 file tools (matching ZeroClaw — the most complete):

| Tool | Risk | Description |
|------|------|-------------|
| `read_file` | low | Read file content with optional line range |
| `write_file` | medium | Create or overwrite file |
| `edit_file` | medium | Replace specific text in file |
| `list_dir` | low | List directory contents |
| `search_files` | low | Search file content (grep) and file names (glob) |

---

## 2. Path Security

### 2.1 Validation Pipeline

Every file operation passes through a multi-step path validation (synthesized from all 5 projects):

```
Input path
  ↓
1. Null byte check → reject if contains \0 (ZeroClaw, IronClaw)
  ↓
2. URL-encoded traversal check → reject ..%2f, %2f.., %2e, %5c (ZeroClaw, IronClaw)
  ↓
3. Expand ~ to home directory
  ↓
4. Resolve to absolute: workspace_root / relative_path
  ↓
5. Canonicalize (resolve symlinks) → real path
  ↓
6. Check symlink: if original path ≠ canonical path, verify
   canonical stays within allowed boundaries (OpenClaw pattern)
  ↓
7. Blocked paths check → reject if canonical path starts with any forbidden path
  ↓
8. Workspace boundary check → reject if canonical path is outside workspace
   (when restrict_to_workspace = true)
  ↓
ALLOWED
```

### 2.2 Blocked Paths

Default deny list (merged from NanoClaw 17 patterns + ZeroClaw 18 paths):

```
# Sensitive credentials & keys
~/.ssh
~/.gnupg
~/.gpg
~/.aws
~/.azure
~/.gcloud
~/.kube
~/.docker
~/.netrc
~/.npmrc
~/.pypirc

# Explicit secret files
**/id_rsa
**/id_ed25519
**/private_key
**/.secret
**/credentials
**/.env

# System directories (when not workspace-restricted)
/etc/shadow
/etc/passwd
```

### 2.3 Symlink Protection

- **Canonicalize before check**: `Path.resolve()` follows all symlinks, then boundary check on the real path (all projects)
- **Detect write-through-symlink**: Before writing, check if target is a symlink via `os.lstat()` — refuse if yes (ZeroClaw pattern)
- **No hardlink protection** (only OpenClaw does this — overkill for Python)

---

## 3. read_file

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `path` | string | yes | — | File path (relative to workspace) |
| `offset` | int | no | 1 | Start from line N (1-based) |
| `limit` | int | no | — | Read at most N lines |

### Read Size Management

Adaptive sizing based on remaining context window (inspired by OpenClaw's approach):

```
effective_limit = min(config.max_read_bytes, estimated_remaining_tokens * 4)
```

| Setting | Default | Description |
|---------|---------|-------------|
| `max_read_bytes` | 10MB | Hard cap on file read (ZeroClaw convention) |
| Context-adaptive | Yes | Actual returned content bounded by remaining context tokens |

When file exceeds effective_limit:
- If `offset`/`limit` specified: read only the requested range
- If no range: use LLM extraction (same as shell tool — fast model extracts key content)
- Fallback: head 4KB + tail 60KB hard truncation

### Binary File Handling

```
Read file bytes
  ↓
Try decode as UTF-8
  ├─ Success → return text content
  └─ Fail → check file type:
      ├─ PDF → extract text via pdf library (ZeroClaw pattern)
      ├─ Image → return "[Binary image file: {path}, {size} bytes]"
      └─ Other → return lossy UTF-8 (replace invalid bytes) with warning
```

### Output Format

```
File: src/main.py (234 lines, 5.2KB)
  1 │ import os
  2 │ import sys
  3 │ ...
```

Line numbers always included (helps LLM reference specific lines for edit_file).

---

## 4. write_file

### Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `path` | string | yes | File path |
| `content` | string | yes | Full file content |

### Behavior

- Creates parent directories if needed
- **Atomic write**: write to temp file in same directory, then `os.rename()` — prevents corruption on crash
- **Symlink check**: refuse if target path is a symlink (ZeroClaw pattern)
- **Size check**: reject if content > `max_file_size_bytes` (default 10MB)
- Returns: `Written {bytes} bytes to {path}`

### Safety

| Guard | Detail |
|-------|--------|
| Size limit | 10MB default (configurable) |
| Atomic write | temp + rename |
| Symlink block | refuse write through symlink |
| Path validation | full pipeline (Section 2.1) |
| Encoding | UTF-8 only |

---

## 5. edit_file

### Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `path` | string | yes | File path |
| `old_string` | string | yes | Text to find (must be unique in file) |
| `new_string` | string | yes | Replacement text |
| `replace_all` | bool | no (default false) | Replace all occurrences (IronClaw option) |

### Behavior

```
1. Read file content
2. Reject if old_string is empty (ZeroClaw: prevent accidental full-file prepend)
3. Count occurrences of old_string
   ├─ 0 matches → fuzzy match (nanobot pattern, see below)
   ├─ 1 match → replace, write file
   └─ N matches:
       ├─ replace_all=true → replace all N, write file
       └─ replace_all=false → error: "old_string appears {N} times, provide more context or use replace_all=true"
4. Return diff snippet showing the change
```

### Fuzzy Match on Failure (nanobot pattern)

When `old_string` is not found, instead of a bare error, show the closest match using `difflib.SequenceMatcher`:

```
Error: old_string not found in src/main.py
Best match (87% similar) at line 42:
--- old_string (provided)
+++ src/main.py (actual, line 42)
@@ -1,3 +1,3 @@
-def process_data(input):
+def process_data(input_data):
     result = transform(input)
     return result
```

This helps the LLM self-correct by seeing what the actual file content looks like.

### Output

Returns a unified diff snippet of the change:

```
Applied edit to src/main.py:
@@ -42,3 +42,3 @@
-def process_data(input):
+def process_data(input_data):
     result = transform(input)
```

---

## 6. list_dir

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `path` | string | no | workspace root | Directory path |
| `recursive` | bool | no | false | Recurse into subdirs |
| `pattern` | string | no | — | Glob filter (e.g., `*.py`) |

### Behavior

- Caps at **500 entries** (IronClaw convention — prevent context overload)
- **Skip noise directories**: `node_modules`, `.git`, `__pycache__`, `.venv`, `target`, `dist`, `build` (IronClaw skips these by default)
- Returns file names with sizes and type indicator (file/dir)
- Respects path validation pipeline

### Output

```
src/ (12 files, 3 dirs)
  main.py          4.2KB
  config.py        1.8KB
  utils/           (dir)
  tests/           (dir)
  ...
[showing 15 of 247 entries, use pattern to filter]
```

---

## 7. search_files

Combined glob + grep tool (ZeroClaw has these as 2 separate tools — we combine for simplicity).

### Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `pattern` | string | yes | Search pattern |
| `mode` | string | no (default "content") | `"content"` (grep) or `"name"` (glob) |
| `path` | string | no | Search directory (default: workspace root) |
| `file_pattern` | string | no | Filter files by glob (e.g., `*.py`) |
| `max_results` | int | no (default 50) | Max results to return (clamped 1–500) |

### Content Search (grep mode)

- Regex search across files in workspace
- Returns matching lines with file path, line number, and context (1 line before/after)
- Max 50 results by default (clamped 1–500)
- Skip binary files (UnicodeDecodeError)
- Skip files > 5MB (prevent OOM)
- Sandbox validation on each discovered path (symlink escape protection)

### Name Search (glob mode)

- Glob pattern matching on file names
- Max 50 results (clamped 1–500)
- Returns matching file paths relative to search root
- Sandbox validation on each result path

### Output (content mode)

```
Found 3 matches for "process_data":

src/main.py:42
  41 │ # Data processing
  42 │ def process_data(input):
  43 │     result = transform(input)

src/utils/helpers.py:15
  14 │ from main import process_data
  15 │ result = process_data(raw)
  16 │ print(result)

tests/test_main.py:8
   7 │ def test_process():
   8 │     assert process_data("hello") == "HELLO"
   9 │     assert process_data("") == ""
```

---

## 8. Config

```yaml
tools:
  filesystem:
    restrict_to_workspace: true
    max_file_size_bytes: 10485760    # 10MB write limit
    max_read_bytes: 10485760         # 10MB read limit (further bounded by context)
    deny_paths:                      # extend default blocked paths
      - '/custom/secret/path'
    skip_dirs:                       # directories to skip in list/search
      - node_modules
      - .git
      - __pycache__
      - .venv
      - target
    output_extraction:
      enabled: true                  # use LLM to extract key content when file is large
      model: auto                    # fast model
```
