# Claude Code Tools

> **Date**: 2026-03-06
> **Tool names**: `claude_code`, `claude_code_status`
> **Risk level**: medium / low
> **Dependency**: `claude-agent-sdk` (pip install claude-agent-sdk)

---

## Overview

Two tools that delegate coding/review tasks to **Claude Code** via the
**Agent SDK** (`claude_agent_sdk.query()`) and expose task management to the
WorkPilot agent.

Both are **optional**: if `claude-agent-sdk` is not installed or the `claude`
CLI binary is not on PATH, registration is silently skipped.

| Tool | Purpose | Approval | Risk |
|------|---------|----------|------|
| `claude_code` | Submit a task to Claude Code (background or wait) | `auto` | medium |
| `claude_code_status` | Query task status / list all tasks | `never` | low |

---

## 1. Motivation

### `gh_copilot` vs `claude_code` vs `spawn`

| | `spawn` | `gh_copilot` | `claude_code` |
|---|---|---|---|
| **Executor** | WorkPilot AgentLoop | gh copilot CLI (SDK) | Claude Code CLI |
| **Tools available** | WorkPilot's 14 built-ins | Copilot's own tools | Claude Code's tools (Bash, Edit, Read, Grep, Glob, Agent, etc.) |
| **Session history** | Fresh per call | Persistent, resumable | Persistent (session ID), resumable |
| **Background + notify** | asyncio.Task only | Task registry + channel notification | Task registry + channel notification |
| **Parallel tasks** | asyncio fan-out | Semaphore-limited | Semaphore-limited (concurrent SDK `query()` calls) |
| **Agent Teams** | No | No | Yes — can spawn subagents and teams |
| **Model** | WorkPilot provider config | Copilot subscription models | `sonnet`, `opus`, `haiku` (Claude subscription) |
| **Plugins** | No | No | Yes — code-review, playwright, custom skills/agents |
| **Cost** | WorkPilot provider billing | Copilot premium requests | Claude subscription (Max/Pro) or API key |
| **Auth** | WorkPilot provider key | `gh auth` | Claude Code auth (subscription or `setup-token`) |
| **Git worktree isolation** | No | No | Yes — `--add-dir`, subagent `isolation: worktree` |

Use `spawn` for WorkPilot-native orchestration.
Use `gh_copilot` when the task needs Copilot's tools and subscription billing.
Use `claude_code` when you need Claude Code's full toolset, plugins, subagents,
agent teams, and SDK-based programmatic usage.

---

## 2. Architecture

```
WorkPilot Runtime
  ├─ ToolRegistry
  │    ├─ claude_code        (ClaudeCodeTool)
  │    └─ claude_code_status (ClaudeCodeStatusTool)
  │
  └─ ClaudeCodeService  (singleton, lazy-start)
       ├─ SDK validation (import claude_agent_sdk on first use)
       ├─ TaskRegistry   {task_id -> ClaudeTask(status, result, notify_channel, ...)}
       ├─ Semaphore pool  asyncio.Semaphore(max_concurrent) → concurrent query() calls
       └─ On complete -> MessageBus.publish_outbound -> original channel
```

**Session ID convention**:
`session_id = "wp-cc-" + task_id` — deterministic, enables resume via `resume` option.

**Execution model**: Each task calls `claude_agent_sdk.query()` with
`ClaudeAgentOptions`. Background tasks run as `asyncio.create_task()`. Wait mode
awaits directly.

---

## 3. Tool: `claude_code`

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `task` | string | yes | — | Full task description. Include file names, function names, expected behaviour. |
| `task_type` | enum | no | `code` | `code` \| `review` \| `test` \| `refactor` \| `research` |
| `files` | string[] | no | `[]` | Workspace-relative paths for Claude to focus on |
| `mode` | enum | no | `background` | `background`: returns immediately, notifies on done. `wait`: blocks until done. |
| `model` | string | no | `sonnet` | `sonnet`, `opus`, `haiku`, or full model name |
| `allowed_tools` | string[] | no | `[]` | Restrict which tools Claude Code can use (e.g. `["Read", "Grep", "Glob"]`) |
| `max_turns` | int | no | 0 | Max agentic turns (0 = unlimited) |
| `resume_session_id` | string | no | — | Resume a prior session by session ID |
| `dangerously_skip_permissions` | bool | no | false | Bypass all permission checks (sandboxed environments only) |

### Task type prompts

| task_type | System prompt appended |
|-----------|----------------------|
| `code` | "Implement the following task. Write clean, minimal code. Only change what is necessary. Run tests when applicable." |
| `review` | "You have Agency plugins available..." (when use_plugins=true) or generic review prompt (when use_plugins=false). Both include inline-comment instructions. |
| `test` | "Write tests for the following task. Use the existing test framework and conventions in the codebase." |
| `refactor` | "Refactor the following code. Keep behaviour identical. Improve readability, reduce duplication, and simplify where possible." |
| `research` | "Research the following topic using the codebase and available tools. Provide a thorough analysis with specific code references." |

### SDK invocation

```python
from claude_agent_sdk import ClaudeAgentOptions, query

options = ClaudeAgentOptions(
    model="sonnet",
    cwd="/path/to/workspace",
    system_prompt="...",
    allowed_tools=["Read", "Edit", "Bash"],
    max_turns=50,
    resume="wp-cc-abc123",       # optional — resume prior session
    permission_mode="bypassPermissions",  # optional — sandboxed envs
    setting_sources=["user", "project", "local"],
)
messages = query(prompt="Implement feature X in src/foo.py", options=options)
```

### Return values

**`mode=background`:**
```
Task submitted (id=abc123def456)
Type: review | Model: sonnet
You will be notified on 'teams' when it completes.
Check status: claude_code_status(task_id="abc123def456")
```

**`mode=wait`:** returns Claude Code's full response text synchronously.

---

## 4. Tool: `claude_code_status`

**Parameter**: `task_id` (string, optional — omit to list all tasks)

**List output:**
```
ID             TYPE       STATUS     MODEL
--------------------------------------------
abc123def456   review     running    sonnet
789xyz012abc   code       done       opus
def456ghi789   refactor   failed     haiku
```

---

## 5. Execution Flow

```
Agent: claude_code(task="...", mode="background")
  |
  v
ToolRegistry injects channel context -> ClaudeCodeTool.execute()
  |
  v
ClaudeCodeService.submit()
  |  creates ClaudeTask(task_id, PENDING, notify_channel=...)
  |
  +---> asyncio.create_task(_run_task)   [background; agent loop continues]
  `---> returns "Task submitted (id=...)"

[background]
_run_task():
  status = RUNNING
  _execute_sdk():
    options = ClaudeAgentOptions(
        model=model, cwd=workspace,
        system_prompt=system_prompt,
        permission_mode="bypassPermissions" if skip_perms else None,
        setting_sources=["user", "project", "local"],
        resume=session_id,
    )
    messages = query(prompt=user_prompt, options=options)
    extract text from AssistantMessage/ResultMessage
  status = DONE | FAILED
  MessageBus.publish_outbound(channel=notify_channel, ...)
```

---

## 6. Config

```yaml
tools:
  claude_code:
    enabled: true
    cli_path: null              # null -> use SDK default; set to override
    default_model: "sonnet"
    task_timeout: 1800          # seconds; 0 = use 1h cap
    max_concurrent: 3           # parallel background tasks
    notification_max_chars: 4000
    model_policy:
      review:   "sonnet"
      test:     "sonnet"
      code:     "sonnet"
      refactor: "sonnet"
      research: "sonnet"
    dangerously_skip_permissions: false  # global override
    use_plugins: true           # include Agency plugin instructions in review prompt
    setting_sources: ["user", "project", "local"]  # SDK setting sources
```

---

## 7. Session Persistence

Claude Code sessions persist at `~/.claude/projects/`. Tasks can be resumed
with `--resume <session-id>` or `--continue`.

---

## 8. Error Handling

| Scenario | Behaviour |
|----------|-----------|
| SDK not installed | Silent skip; tools unavailable |
| CLI not on PATH | Silent skip; tools unavailable |
| Not authenticated | Task → `FAILED`; notification sent |
| SDK error / exception | Task → `FAILED`; error captured; notification sent |
| Task timeout | Task → `FAILED`; partial result preserved if available; notification includes both error and partial output |
| Runtime shutdown with tasks running | Tasks cancelled; specific error preserved (`"Cancelled: runtime shutting down"`); `FAILED` notification sent |

---

## 9. Usage Examples

### Background code review with Teams notification

```
User (Teams): Review the auth module before I merge.

Agent: claude_code(
    task="Review workpilot/security/ for bugs and security issues. Max 5 bullets.",
    task_type="review", files=["workpilot/security/"], mode="background"
)
← "Task submitted (id=abc123). You'll be notified here when done."

[Teams, ~3 min later]
**Claude Code task complete** (id=`abc123`, type=`review`)
1. Bug: token expiry not checked in refresh_token()
...
```

### Quick task in wait mode

```
Agent: claude_code(
    task="Add a docstring to validate_token in workpilot/auth/token.py.",
    task_type="code", files=["workpilot/auth/token.py"],
    mode="wait", model="haiku"
)
← [result returned synchronously]
```

### Research task

```
Agent: claude_code(
    task="How does the message bus handle backpressure? Trace the flow.",
    task_type="research", allowed_tools=["Read", "Grep", "Glob"],
    mode="wait", model="sonnet"
)
← [detailed analysis with code references]
```
