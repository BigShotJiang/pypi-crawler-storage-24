# MCP Auth — OAuth 2.1 Protocol Support

> **Status**: Draft v1
> **Date**: 2026-03-06
> **Parent**: [mcp-bridge.md](mcp-bridge.md)
> **Spec**: [MCP Authorization (draft)](https://modelcontextprotocol.io/specification/draft/basic/authorization)

---

## 1. Background

### 1.1 Current Implementation

WorkPilot 当前 auth 支持（`workpilot/mcp/auth.py`）：

| Type | Implementation | MCP 合规？ |
|------|---------------|-----------|
| `none` | No headers | ✅ |
| `bearer` | Static token from config/env → `Authorization: Bearer <token>` | ✅（token 来源不限） |
| `oauth` | Client credentials grant → Azure AD common endpoint → Bearer token | ❌ 不符合 MCP spec |
| Agency (stdio) | Agency CLI 内部处理 EntraID auth | N/A（stdio 不在 MCP auth spec 范围内） |

### 1.2 MCP Authorization Spec 要求

MCP draft spec 定义了 HTTP transport 的完整 OAuth 2.1 授权流程：

```
Client → Server: request without token
Server → Client: 401 + WWW-Authenticate (resource_metadata URL)
Client → Server: GET /.well-known/oauth-protected-resource
Server → Client: Protected Resource Metadata (auth server location)
Client → Auth Server: GET /.well-known/oauth-authorization-server
Auth Server → Client: Auth Server Metadata (endpoints, scopes, PKCE)
Client → Auth Server: Authorization Code + PKCE flow
Auth Server → Client: Access Token (+ Refresh Token)
Client → Server: request + Bearer token
```

### 1.3 Gap Analysis

| MCP Spec 要求 | 当前状态 | 优先级 |
|--------------|---------|--------|
| `Authorization: Bearer <token>` header | ✅ 已实现 | — |
| 处理 401 → 触发 auth flow | ❌ 缺失 | P1 |
| Protected Resource Metadata discovery (RFC 9728) | ❌ 缺失 | P1 |
| Auth Server Metadata discovery (RFC 8414 / OIDC) | ❌ 缺失 | P1 |
| Authorization Code + PKCE | ❌ 缺失 | P1 |
| Dynamic Client Registration (RFC 7591) | ❌ 缺失 | P2 |
| Client ID Metadata Documents | ❌ 缺失 | P3 |
| Resource Indicators (RFC 8707) | ❌ 缺失 | P2 |
| Token refresh | ❌ 缺失 | P1 |
| Scope challenge / step-up auth (403) | ❌ 缺失 | P2 |
| Secure token storage | ❌ 缺失 | P1 |

---

## 2. Design

### 2.1 Auth Flow Overview

```
MCPManager.connect_server(name)
  │
  ├── stdio transport → skip (auth handled by subprocess)
  │
  ├── HTTP + auth.type == "bearer" → static token → done (current behavior)
  │
  └── HTTP + auth.type == "oauth" or server returns 401
        │
        ├── 1. Try connect without auth
        │     └── Server returns 401 + WWW-Authenticate
        │
        ├── 2. Discover Protected Resource Metadata
        │     └── GET /.well-known/oauth-protected-resource
        │     └── Extract authorization_servers + scopes
        │
        ├── 3. Discover Auth Server Metadata
        │     └── GET /.well-known/oauth-authorization-server
        │     └── Extract: authorization_endpoint, token_endpoint,
        │         code_challenge_methods_supported, registration_endpoint
        │
        ├── 4. Client Registration (if needed)
        │     └── Pre-registered client_id (from config)
        │     └── OR Dynamic Client Registration (RFC 7591)
        │     └── OR Client ID Metadata Document
        │
        ├── 5. Authorization Code + PKCE
        │     └── Generate code_verifier + code_challenge (S256)
        │     └── Open browser → authorization_endpoint
        │     └── User authenticates + consents
        │     └── Receive auth code via localhost callback
        │     └── Exchange code for access_token + refresh_token
        │
        ├── 6. Store tokens securely
        │     └── ~/.workpilot/mcp_tokens/<server_name>.json
        │
        └── 7. Retry original request with Bearer token
```

### 2.2 401 Retry in MCPManager

当前 `connect_server` 直接连接。需要增加 401 处理：

```
connect_server(name):
  1. Resolve existing token from cache → if valid, use it
  2. Connect with token (or without if no cache)
  3. If 401:
     a. Parse WWW-Authenticate header
     b. Run OAuth discovery + authorization flow
     c. Store token
     d. Retry connect with new token
  4. If 403 (insufficient_scope):
     a. Parse required scopes from WWW-Authenticate
     b. Re-authorize with expanded scopes
     c. Retry
```

**Note**: 401 retry 只对 HTTP transport 生效。Stdio transport 不涉及 HTTP 状态码。

### 2.3 Token Storage

```
~/.workpilot/mcp_tokens/
  └── <server_name>.json
        {
          "access_token": "eyJ...",
          "refresh_token": "dGhp...",
          "token_type": "Bearer",
          "expires_at": 1709712000,
          "scope": "files:read files:write",
          "resource": "https://mcp.example.com"
        }
```

- 每个 MCP server 独立 token 文件
- `expires_at` 用于判断是否需要 refresh
- Token refresh 在 connect 前自动执行（如果 `expires_at` < now + 60s）
- 文件权限：owner read/write only (0600)

### 2.4 PKCE Flow

```
1. Generate:
   code_verifier = random(43-128 chars, [A-Za-z0-9-._~])
   code_challenge = BASE64URL(SHA256(code_verifier))

2. Authorization request:
   GET {authorization_endpoint}?
     response_type=code&
     client_id={client_id}&
     redirect_uri=http://127.0.0.1:{port}/callback&
     code_challenge={code_challenge}&
     code_challenge_method=S256&
     scope={scopes}&
     resource={mcp_server_url}&
     state={random}

3. User authenticates in browser

4. Callback receives auth code:
   http://127.0.0.1:{port}/callback?code={code}&state={state}

5. Token exchange:
   POST {token_endpoint}
     grant_type=authorization_code&
     code={code}&
     code_verifier={code_verifier}&
     client_id={client_id}&
     redirect_uri=http://127.0.0.1:{port}/callback&
     resource={mcp_server_url}
```

### 2.5 Localhost Callback Server

Authorization Code flow 需要临时 HTTP server 接收回调：

- 启动时选择随机可用端口（或用 `--callback-port` 固定）
- 监听 `http://127.0.0.1:{port}/callback`
- 接收 auth code 后立即关闭
- 超时 120 秒（用户未在浏览器完成授权）

### 2.6 Metadata Discovery

**Protected Resource Metadata (RFC 9728)**:

```
GET https://mcp.example.com/.well-known/oauth-protected-resource
→ {
    "resource": "https://mcp.example.com",
    "authorization_servers": ["https://auth.example.com"],
    "scopes_supported": ["files:read", "files:write"]
  }
```

**Auth Server Metadata (RFC 8414)**:

```
GET https://auth.example.com/.well-known/oauth-authorization-server
→ {
    "issuer": "https://auth.example.com",
    "authorization_endpoint": "https://auth.example.com/authorize",
    "token_endpoint": "https://auth.example.com/token",
    "registration_endpoint": "https://auth.example.com/register",
    "code_challenge_methods_supported": ["S256"],
    "scopes_supported": ["files:read", "files:write"]
  }
```

如果 Auth Server Metadata 没有 `code_challenge_methods_supported`，**拒绝继续**（MCP spec 要求）。

---

## 3. Configuration

### 3.1 MCPServerConfig Auth 扩展

```yaml
mcp_servers:
  # 场景 1: 无 auth（或 stdio）
  icm:
    command: "agency"
    args: ["mcp", "icm"]

  # 场景 2: 静态 Bearer token
  internal-api:
    url: "https://mcp.corp.com/api"
    auth:
      type: bearer
      token_env: "CORP_TOKEN"

  # 场景 3: MCP OAuth 2.1（自动发现）
  github:
    url: "https://api.githubcopilot.com/mcp/"
    auth:
      type: oauth

  # 场景 4: OAuth with pre-registered client
  sentry:
    url: "https://mcp.sentry.dev/mcp"
    auth:
      type: oauth
      client_id: "my-app-client-id"
      callback_port: 8080

  # 场景 5: OAuth with client secret (confidential client)
  private-api:
    url: "https://mcp.private.com/api"
    auth:
      type: oauth
      client_id: "app-id"
      client_secret: "${MCP_CLIENT_SECRET}"
```

### 3.2 MCPAuthConfig Schema 变更

当前：

```python
class MCPAuthConfig(BaseModel):
    type: Literal["none", "bearer", "oauth"] = "none"
    token: SecretStr | None = None
    token_env: str | None = None
    client_id: str | None = None
    client_secret: SecretStr | None = None
    scopes: list[str] = Field(default_factory=list)
```

新增字段：

| Field | Type | Description |
|-------|------|-------------|
| `callback_port` | `int?` | 固定 OAuth callback 端口（默认随机） |
| `auth_server_url` | `str?` | 直接指定 auth server（跳过 discovery） |

### 3.3 CLI 支持

```bash
# OAuth server（自动 discovery）
workpilot mcp add --transport http github https://api.githubcopilot.com/mcp/

# OAuth with pre-registered client
workpilot mcp add --transport http sentry https://mcp.sentry.dev/mcp \
  --auth oauth --client-id my-app-id --callback-port 8080

# 触发 OAuth login
workpilot mcp test sentry
# → Opens browser for OAuth authorization
# → Stores token in ~/.workpilot/mcp_tokens/sentry.json
```

---

## 4. Implementation Plan

### Phase 1 — Core OAuth Flow

| # | Task | What |
|---|------|------|
| 4.1 | Token cache | `~/.workpilot/mcp_tokens/` 读写，过期判断，自动 refresh |
| 4.2 | 401 handling | MCPManager 或 HttpTransport 层面拦截 401，触发 auth flow |
| 4.3 | Resource Metadata discovery | `GET /.well-known/oauth-protected-resource` → 解析 `authorization_servers` |
| 4.4 | Auth Server Metadata discovery | `GET /.well-known/oauth-authorization-server` 和 OIDC discovery 回退 |
| 4.5 | PKCE 生成 | `code_verifier` + `S256` challenge 生成 |
| 4.6 | Localhost callback server | 临时 HTTP server 接收 auth code |
| 4.7 | Token exchange | Authorization code → access_token + refresh_token |
| 4.8 | Browser launch | 打开系统浏览器进行用户授权 |

### Phase 2 — Advanced

| # | Task | What |
|---|------|------|
| 4.9 | Token refresh | 自动 refresh（access_token 过期前） |
| 4.10 | Scope step-up | 处理 403 insufficient_scope → 扩展 scope 重新授权 |
| 4.11 | Dynamic Client Registration | RFC 7591 — 无 pre-registered client_id 时自动注册 |
| 4.12 | Resource Indicators | RFC 8707 — `resource` 参数在 auth + token request 中 |

### Phase 3 — Nice-to-have

| # | Task | What |
|---|------|------|
| 4.13 | Client ID Metadata Documents | HTTPS URL 作为 client_id |
| 4.14 | Token revocation | 用户可以 `workpilot mcp logout <name>` 清除 token |
| 4.15 | Keychain integration | macOS Keychain / Windows Credential Manager 安全存储 |

---

## 5. Security Considerations

| Concern | Mitigation |
|---------|-----------|
| Token theft | 文件权限 0600；考虑 Phase 3 keychain |
| PKCE | 强制 S256（MCP spec 要求） |
| Redirect URI | 仅 `127.0.0.1`（不用 `localhost` 避免 DNS rebinding） |
| Token audience | 验证 token 是发给目标 MCP server 的 |
| HTTPS only | Auth server endpoints 必须 HTTPS |
| State parameter | 随机 state 防 CSRF |
| Token scope | 只请求必需 scope |

---

## 6. Relationship to Existing Auth

| Auth Type | 场景 | OAuth 2.1 相关？ |
|-----------|------|-----------------|
| `none` | 本地/可信 server | 不相关 |
| `bearer` | 静态 API key | 不相关（token 来源不限） |
| `oauth` (当前 client_credentials) | 服务间认证 | 保留，但改名为 `oauth_client_credentials` |
| `oauth` (新 authorization_code) | 用户授权的第三方 MCP server | **本 spec 的核心** |
| Agency stdio | Microsoft 内部 | 不相关（stdio 不走 HTTP auth） |

### 迁移

- 当前 `auth.type == "oauth"` 重命名为 `oauth_client_credentials`（服务间）
- 新增 `auth.type == "oauth"` 默认为 authorization_code + PKCE（MCP spec 合规）
- 向后兼容：如果配置了 `client_secret` 但没有 `callback_port`，推断为 client_credentials
