# HTTP & Web Tools

> **Date**: 2026-02-28
> **Tools**: `http_request`, `web_search`, `web_fetch`
> **Risk level**: medium
> **Isolation**: process

---

## Reference (from actual source code)

| Feature | nanobot | OpenClaw | NanoClaw | ZeroClaw | IronClaw |
|---------|---------|---------|----------|----------|----------|
| **HTTP tool** | httpx | Guarded fetch | N/A (delegated) | reqwest | reqwest (HTTPS only) |
| **Search providers** | Brave | **Brave/Perplexity/Grok/Gemini/Kimi** (5) | N/A | **DDG/Brave/Firecrawl/Tavily/Perplexity/Exa/Jina** (7) | None |
| **SSRF: Private IP** | **None** | **Comprehensive** (DNS pinning) | N/A | **Comprehensive** (resolve+check) | **Yes** (resolve+check) |
| **SSRF: DNS rebinding** | None | **Yes** (custom DNS agent) | N/A | **Yes** | **Yes** |
| **SSRF: Cloud metadata** | None | **Yes** (metadata.google.internal) | N/A | Yes (IP range) | **Yes** (169.254.169.254 explicit) |
| **SSRF: IPv6 bypass** | None | **Yes** (mapped/NAT64/6to4/Teredo/ISATAP) | N/A | Yes (basic) | Yes (basic) |
| **Redirect handling** | Auto-follow 5 | **Manual + re-validate** | N/A | **Disabled** | **Disabled + blocked** |
| **Outbound leak detection** | None | None | None | None | **Yes** (16 patterns, Aho-Corasick) |
| **Rate limiting** | None | None | None | Yes (per-hour) | Yes (30/min, 500/hr) |
| **Max response** | 50K chars | 2MB bytes / 50K chars | N/A | 500K configurable | 5MB (streamed) |
| **Timeout** | Search:10s, Fetch:30s | 30s | N/A | 30s | 30s |
| **HTML extraction** | readability + regex | **@mozilla/readability + Cloudflare MD** | N/A | html2md / Firecrawl | readabilityrs + html_to_markdown |
| **Response cache** | None | **Yes** (15min TTL, 100 entries) | N/A | None | None |
| **Content marking** | None | **Yes** (wrapExternalContent) | N/A | None | None |

---

## 1. Three Separate Tools

| Tool | Purpose | When used |
|------|---------|-----------|
| `http_request` | Raw HTTP client | API calls, webhook triggers |
| `web_search` | Search the web | Research phase, user queries |
| `web_fetch` | Fetch URL → readable content | Read documentation, web pages |

---

## 2. http_request

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `method` | string | yes | — | GET, POST, PUT, PATCH, DELETE, HEAD |
| `url` | string | yes | — | Request URL (http or https) |
| `headers` | dict | no | {} | Request headers |
| `body` | string | no | — | Request body |
| `timeout` | int | no | 30 | Timeout in seconds |

### SSRF Protection

Multi-layer validation (synthesized from OpenClaw + ZeroClaw + IronClaw):

```
URL received
  ↓
1. Scheme check: http/https only
  ↓
2. Reject URL with userinfo (user:pass@host)
  ↓
3. Hostname blocklist:
   - localhost, *.localhost
   - *.local, *.internal
   - metadata.google.internal
  ↓
4. Literal IP check: reject if IP is private/loopback/link-local/multicast/reserved:
   - 127.0.0.0/8 (loopback)
   - 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16 (private)
   - 169.254.0.0/16 (link-local, includes cloud metadata 169.254.169.254)
   - 100.64.0.0/10 (carrier-grade NAT)
   - 0.0.0.0, 255.255.255.255
   - 224.0.0.0/4 (multicast)
   - 240.0.0.0/4 (reserved)
  ↓
5. IPv6 bypass prevention:
   - ::1 (loopback)
   - ::ffff:127.0.0.1 (IPv4-mapped)
   - fc00::/7 (unique local)
   - fe80::/10 (link-local)
  ↓
6. DNS resolution: resolve hostname → check ALL resolved IPs against step 4-5
   (prevents DNS rebinding: hostname resolves to private IP)
  ↓
7. Outbound leak scan (see below)
  ↓
ALLOWED
```

### Outbound Leak Detection (IronClaw pattern)

Before sending, scan URL + headers + body for credential patterns:

| Pattern | Type | Action |
|---------|------|--------|
| `sk-proj-...`, `sk-ant-api...` | AI API keys | Block request |
| `AKIA...` (20 chars) | AWS Access Key | Block request |
| `ghp_`, `gho_`, `ghu_`, `ghs_`, `ghr_` | GitHub tokens | Block request |
| `sk_live_`, `sk_test_` | Stripe keys | Block request |
| `xox[baprs]-` | Slack tokens | Block request |
| `AIza...` | Google API keys | Block request |
| PEM / SSH private keys | Private keys | Block request |
| `Bearer ...` in non-Authorization header | Misplaced token | Warn |
| High-entropy strings (64+ hex chars) | Potential secrets | Warn |

On block: `Blocked: outbound request contains credential pattern (GitHub PAT detected in URL query parameter). Request not sent.`

### Redirect Handling

**Disabled by default** (ZeroClaw + IronClaw pattern). Redirects (3xx) are returned as-is to the agent, not followed automatically.

Why: auto-following redirects is a classic SSRF bypass vector. A public URL can redirect to `http://169.254.169.254/`.

If the agent needs to follow a redirect, it makes a second explicit `http_request` call to the redirect target — which goes through the full SSRF validation again.

### Response Size

| Setting | Default | Description |
|---------|---------|-------------|
| `max_response_bytes` | 1 MB | Hard cap on response body |
| Enforcement | Streaming | Read body chunk by chunk, abort if over limit |

### Output

```
Status: 200 OK
Headers: { content-type: application/json, ... }
Body: [response body, truncated if >1MB]
Duration: 0.8s
```

---

## 3. web_search

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `query` | string | yes | — | Search query |
| `count` | int | no | 5 | Number of results (1-10) |

### Search Provider

DuckDuckGo HTML search (no API key required). Rate-limited to 1 request/second.

| Provider | API | Key env var | Notes |
|----------|-----|-------------|-------|
| **DuckDuckGo** | HTML scrape | None (free) | Always available, no API key needed |

> **Future**: Brave Search API (`BRAVE_API_KEY`) and Perplexity Sonar (`PERPLEXITY_API_KEY`) can be added as optional providers with auto-detection priority.

### Output

```
Search results for "python async patterns":

1. Async IO in Python: A Complete Walkthrough
   https://realpython.com/async-io-python/
   A comprehensive guide to asyncio, covering coroutines, tasks, and event loops...

2. Python Concurrency with asyncio
   https://docs.python.org/3/library/asyncio.html
   Official documentation for the asyncio library...

[5 results]
```

### Safety

- Search queries pass through the same outbound leak scan
- No SSRF risk (search goes to known API endpoints only)

---

## 4. web_fetch

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `url` | string | yes | — | URL to fetch |
| `selector` | string | no | — | CSS selector to extract specific content |
| `max_chars` | int | no | 20000 | Max characters in output (clamped 100–100,000) |

### How It Works

```
URL received
  ↓
SSRF validation (same as http_request)
  ↓
Fetch page (timeout 30s, max 10MB raw)
  ↓
Content-type check:
  ├─ application/json → pretty-print JSON
  ├─ text/markdown → use as-is (Cloudflare "Markdown for Agents" protocol)
  ├─ text/html → extract readable content (see below)
  └─ text/* → use as-is
  ↓
If selector specified → extract matching elements only
  ↓
Truncate to max_chars
  ↓
Return as markdown text
```

### HTML Extraction Pipeline

```
Raw HTML
  ↓
1. Readability extraction (mozilla/readability equivalent)
   → removes nav, ads, sidebars, scripts, styles
   → extracts main article content
  ↓
2. HTML-to-Markdown conversion
   → headings, links, lists, tables, code blocks preserved
   → images converted to [alt text](url)
  ↓
3. Cleanup
   → collapse excessive whitespace
   → remove empty lines
   → truncate to max_chars
```

### Safety

- Full SSRF validation (same as http_request)
- Outbound leak scan on URL
- Response size cap: 2 MB raw, then truncated to `max_chars` after extraction
- Fetched content is **marked as untrusted** in the context (OpenClaw `wrapExternalContent` pattern) — the LLM is told this content comes from an external source and should not be treated as instructions

### Response Cache

In-memory cache for repeated fetches:

| Setting | Default |
|---------|---------|
| TTL | 15 minutes |
| Max entries | 100 |
| Cache key | URL (normalized) |

Avoids redundant fetches when the agent re-reads the same URL within a session.

### Output

```
Fetched: https://docs.python.org/3/library/asyncio.html
Content-Type: text/html → extracted as markdown
Length: 12,340 chars

# asyncio — Asynchronous I/O

asyncio is a library to write concurrent code using the async/await syntax...

## Coroutines and Tasks

A coroutine is declared with `async def`:
...
```

---

## 5. Config

```yaml
tools:
  http:
    timeout: 30
    max_response_bytes: 1048576     # 1MB
    block_private_ips: true         # SSRF protection (default on)
    redirects: false                # don't follow redirects (default)
    leak_detection: true            # scan outbound for credentials
  web_search:
    provider: auto                  # auto | brave | duckduckgo | perplexity
    brave_api_key: ${BRAVE_API_KEY}
  web_fetch:
    max_chars: 50000                # max extracted content
    max_raw_bytes: 10485760         # 10MB raw response cap
    cache_ttl_seconds: 900          # 15 min
    cache_max_entries: 100
    mark_as_untrusted: true         # wrap content with untrusted marker
```
