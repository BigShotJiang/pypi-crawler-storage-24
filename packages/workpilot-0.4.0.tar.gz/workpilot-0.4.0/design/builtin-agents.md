# WorkPilot — Built-in Agents Specification

> **Layer**: 2 of 3 (Core & Infrastructure → **Built-in Features** → Extended Abilities)
> **Status**: Draft v2
> **Date**: 2026-03-02
> **Depends on**: [core-infra.md](core-infra.md) Section 5 (Agent Loop), [core/agent.md](core/agent.md), [features/tool-spawn.md](features/tool-spawn.md)

WorkPilot ships with **3 built-in agents** (default + explorer + security) and **5 bundled templates** that users can enable. Users can also define fully custom agents. This follows the reference project consensus: provide infrastructure for multi-agent operation, ship minimal opinionated defaults, let users configure specialization.

---

## 1. Philosophy

### 1.1 Agents vs Skills vs Tools

| Layer | What it is | Who controls execution | Scope |
|-------|-----------|----------------------|-------|
| **Tool** | Single capability (shell, read_file, git) | Agent loop dispatches tool calls | One action |
| **Skill** | Prompt instructions (SKILL.md) | LLM reads and decides tool sequence | Multi-step recipe |
| **Agent** | Independent execution loop | Own context, model, tools, budget | Full delegation |

**When to use which:**
- **Tool**: The default agent needs one capability (read a file, run a command)
- **Skill**: The default agent needs guidance on a multi-step workflow (create a PR, review code)
- **Agent**: The task requires a separate context window, a different model, or a restricted toolset

### 1.2 Design Principles

1. **Start with one agent** — Most tasks should be handled by `default`. The LLM is smart enough to adapt its behavior based on the task prompt alone — it doesn't need a pre-defined role to do code review or write tests.

2. **Specialization through restriction** — A sub-agent is the default agent minus things it doesn't need. The primary axes are **tool restriction** (read-only vs read-write) and **model selection** (fast/cheap vs capable).

3. **Skills over agents for role behavior** — If you want "reviewer" behavior, load a review SKILL.md into the default agent's context. If you want a separate context window with a cheaper model and read-only tools, use an agent. Don't conflate prompt instructions (skill) with execution isolation (agent).

4. **Fresh context, shared workspace** — Sub-agents get clean message history but see the same files and MEMORY.md as the parent. (Consensus across all 5 reference projects.)

5. **Agents are configuration, not code** — An agent is an `AgentConfig` entry (tools + model + budget). No special classes or plugins needed.

### 1.3 Reference Project Consensus

All 5 reference projects agree: **no pre-defined specialized agents**.

| Project | Agent Model | What they ship |
|---------|------------|---------------|
| **nanobot** | Single default + background clones | SpawnTool clones same config, task prompt only |
| **OpenClaw** | Multi-instance general-purpose | User-created named instances, tool allow/deny |
| **NanoClaw** | One-per-group container isolation | Same agent, different CLAUDE.md per group |
| **IronClaw** | Dynamic contextual adaptation | Skills gating/attenuation scopes behavior at runtime |
| **ZeroClaw** | Explicit named agent configs | Empty `[agents.*]` by default, user-defined |

Claude Code ships with built-in subagent **modes** (Explore, Plan, General-purpose) but these are just tool restriction + model selection presets, not role definitions. WorkPilot follows this pattern.

---

## 2. Agent Definition Format

Every agent (built-in or custom) is an `AgentConfig` entry in `workpilot.yaml`:

```yaml
agents:
  <name>:
    name: "Human-readable display name"
    description: "Shown to parent LLM for delegation decisions"
    model: "auto"                       # auto | fast | reasoning | coding | specific ID
    temperature: 0.3
    max_tokens: 8192
    instructions: |                     # System prompt (optional — use SKILL.md for role behavior)
      You are a ...
    tools:                              # Explicit allowlist (deny-by-default)
      - read_file
      - list_dir
      - search_files
    max_iterations: 20
    timeout: 600
    permissions:
      allow_shell: false
      allow_file_write: false
      allow_file_read: true
      allow_network: false
      allow_browser: false
      allow_spawn: false
    memory_window: 50
    memory_writable: false
    skills: []                          # Skills always loaded in context
    metadata:
      category: "development"
      builtin: true
```

### 2.1 Key Fields

| Field | Purpose | Default |
|-------|---------|---------|
| `description` | Shown to parent LLM so it knows when to delegate | Required for non-default agents |
| `model` | `"auto"` = best available. `"fast"` = cheapest. | `"auto"` |
| `tools` | Explicit tool allowlist. Empty = no tools. | All tools (default only) |
| `max_iterations` | Iteration budget | `AgentConfig` schema default is 40; built-ins may set lower (explorer=15, security=1) |
| `memory_writable` | Can this agent write to MEMORY.md? | `false` (only default = `true`) |

### 2.2 Agent Discovery by Parent LLM

During context assembly, available sub-agents are summarized for the default agent:

```
## Available Sub-Agents

You can delegate tasks using the `spawn` tool. Pass a clear task description — the sub-agent
gets its own context and works independently.

| Agent | Description | Model | Tools | Budget |
|-------|------------|-------|-------|--------|
| explorer | Fast codebase search (read-only) | fast | read_file, list_dir, search_files | 15 iter |
```

Only non-internal agents with `builtin: true` or user-defined agents appear in this table.

---

## 3. Built-in Agents (3)

WorkPilot ships with 3 agents that are always available:

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│    default       │     │    explorer      │     │    security      │
│  (orchestrator)  │────▶│  (fast, r/o)     │     │  (internal)      │
│                  │     └─────────────────┘     └─────────────────┘
│  All tools       │                              Tool approval
│  40 iterations   │                              Fast model, 0 tools
│  Memory write    │                              1 iteration
└─────────────────┘
```

---

### 3.1 `default` — Primary Orchestrator

Detailed spec: [features/agent-default.md](features/agent-default.md)

The primary agent that handles direct user interaction. Has all tools and can spawn sub-agents.

```yaml
default:
  name: "WorkPilot Assistant"
  description: "General-purpose assistant. Handles direct user interaction, orchestrates sub-agents."
  model: auto
  temperature: 0.3
  max_tokens: 8192
  max_iterations: 40
  timeout: 1200
  tools: [shell, read_file, write_file, edit_file, list_dir, search_files,
      git, http_request, web_search, web_fetch, browser, spawn, message,
      gh_copilot, gh_copilot_status, gh_copilot_models]
  # + cron tool (added dynamically when cron.enabled=true in config)
  permissions:
    allow_shell: true
    allow_file_read: true
    allow_file_write: true
    allow_network: true
    allow_browser: true
    allow_spawn: true
  memory_writable: true
  max_spawn_depth: 2
  max_concurrent_children: 5
  metadata:
    category: orchestrator
    builtin: true
```

**Key traits:**
- Only agent with `spawn` and `message` tools
- Only agent that can write to MEMORY.md
- Highest iteration budget (40)
- Delegation is LLM-driven: the default agent reads sub-agent descriptions and decides when to delegate based on task complexity

---

### 3.2 `explorer` — Fast Read-Only Search

Detailed spec: [features/agent-explorer.md](features/agent-explorer.md)

Inspired by Claude Code's Explore subagent (Haiku model, read-only tools). The single most valuable built-in sub-agent — validated by Claude Code's production usage.

```yaml
explorer:
  name: "Explorer"
  description: "Fast codebase search and file discovery. Read-only. Use for finding files, understanding code structure, locating definitions."
  model: fast
  temperature: 0.1
  max_tokens: 4096
  max_iterations: 15
  timeout: 120
  instructions: |
    You are a codebase explorer. Quickly find files, functions, classes, and patterns.
    Return structured results: file paths with line numbers.
    Do NOT suggest code changes — just report what you find.
  tools: [read_file, list_dir, search_files]
  permissions:
    allow_shell: false
    allow_file_write: false
    allow_file_read: true
    allow_network: false
    allow_browser: false
    allow_spawn: false
  memory_writable: false
  metadata:
    category: development
    builtin: true
```

**Why built-in:**
- Uses `fast` model — **10x cheaper** than default agent for the same search work
- Read-only (3 tools) — zero risk of unintended modifications
- Short budget (15 iter, 120s) — exploration should be quick
- Claude Code proves this pattern: Explore is their most-used subagent type
- The default agent should delegate all broad codebase searches to explorer

---

### 3.3 `security` — Tool Approval Assessment

Detailed spec: [features/agent-security.md](features/agent-security.md)

Internal agent used by the two-layer approval mechanism ([core/tool.md](core/tool.md) Section 3). Not spawned via `spawn` tool — invoked directly by the Approval Gate handler in the `pre_tool_use` hook as a single-turn LLM call.

```yaml
security:
  name: "Security Agent"
  description: "Internal: evaluates tool calls for risk and policy compliance."
  model: fast
  temperature: 0.0
  max_tokens: 1024
  max_iterations: 1
  timeout: 10
  instructions: |
    You evaluate whether a proposed tool call should be approved.
    Respond with JSON: {"decision": "approve"|"deny"|"escalate", "risk": "low"|"medium"|"high"|"critical", "reason": "..."}
    When in doubt, ESCALATE rather than APPROVE.
  tools: []
  permissions:
    allow_shell: false
    allow_file_write: false
    allow_file_read: false
    allow_network: false
    allow_browser: false
    allow_spawn: false
  memory_writable: false
  metadata:
    category: system
    builtin: true
    internal: true
```

**Why built-in:**
- Required by the approval mechanism (controlled/restricted security profiles)
- Must be fast (0 tools, 1 iteration, 10s timeout) — called per tool approval
- Not user-facing — `internal: true` hides from agent discovery table

---

## 4. Bundled Templates (5)

These are **example agent configurations** shipped in `workpilot/agents/templates/`. Not enabled by default — users copy them into `workpilot.yaml` or enable with `workpilot agents enable <name>`.

The rationale: these roles are better served by **Skills** (prompt overlays) in most cases. An agent is only warranted when you need context isolation or a different model. Users who want a "reviewer agent" can enable the template; users who just want review behavior load the `review` skill.

### 4.1 Templates

| Template | Model | Tools | Iterations | When to use agent instead of skill |
|----------|-------|-------|-----------|-----------------------------------|
| `coder` | auto | shell, read_file, write_file, edit_file, list_dir, search_files, git | 25 | Multi-file implementation that would pollute parent context |
| `reviewer` | auto | read_file, list_dir, search_files, git | 15 | Parallel multi-perspective review (spawn 2-3 reviewers) |
| `tester` | auto | shell, read_file, write_file, edit_file, list_dir, search_files, git | 25 | Test generation that needs many iterate-and-fix cycles |
| `researcher` | auto | web_search, web_fetch, http_request, read_file, list_dir, search_files | 20 | Deep web research that would consume too much parent context |
| `communicator` | auto | read_file, search_files | 10 | Bilingual drafting with office skill loaded |

### 4.2 Template Files

```
workpilot/agents/templates/
  coder.yaml
  reviewer.yaml
  tester.yaml
  researcher.yaml
  communicator.yaml
```

Each template is a complete `AgentConfig` YAML snippet with instructions, tools, permissions, and rationale comments.

### 4.3 Enabling a Template

```bash
# Copy template to config
workpilot agents enable coder

# This adds to workpilot.yaml:
# agents:
#   coder:
#     model: auto
#     tools: [shell, read_file, write_file, edit_file, list_dir, search_files, git]
#     max_iterations: 25
#     ...
```

### 4.4 Custom Agents

Users define agents directly in config — no template needed:

```yaml
agents:
  dba:
    name: "Database Agent"
    description: "Schema design, query optimization, migrations."
    tools: [shell, read_file, write_file, edit_file, list_dir, search_files]
    max_iterations: 20
```

---

## 5. Delegation Patterns

### 5.1 When to Delegate

The default agent decides delegation based on its system prompt instructions. No programmatic routing — the LLM reads agent descriptions and chooses. This is the universal pattern.

```
Delegation guidelines (in default agent's system prompt):
- Use 'explorer' for broad codebase search — it's fast and cheap.
- For other tasks, handle them directly unless:
  - The task would consume too much of your context window
  - The task needs many iterations (implement → test → fix cycles)
  - You want to parallelize independent subtasks
  - A user-configured sub-agent exists that's suited for the task
```

### 5.2 Effort Scaling

| Complexity | Strategy | Example |
|------------|----------|---------|
| **Simple** | Default handles directly | "What does this function do?" |
| **Medium** | Spawn explorer for search, then default acts | "Find and fix the auth bug" |
| **Complex** | Spawn multiple agents in parallel | "Review security module" → 2 explorers (structure + tests) |
| **Very complex** | Multi-wave (if user enables templates) | explorer → coder → tester → reviewer |

### 5.3 Delegation Prompt

```
spawn(
  agent="explorer",
  prompt="Find all error handling patterns in workpilot/gateway/. List file paths and line numbers.",
  context="We're looking for inconsistent error handling to fix."
)
```

### 5.4 Result Handling

Sub-agent results are injected as system messages into the parent's context:

```
[Sub-agent 'explorer' completed (task_id: abc123, iterations: 8/15, duration: 12s)]

Found 5 error handling patterns in workpilot/gateway/:
1. workpilot/gateway/routes.py:45 — bare except
2. workpilot/gateway/auth.py:112 — swallowed exception
...
```

---

## 6. Security & Permissions

### 6.1 Permission Inheritance

```
Effective permissions = agent_config.permissions ∩ parent.active_permissions ∩ security_profile
```

Sub-agents can NEVER have MORE permissions than their parent.

### 6.2 Tool Exclusion Rules

By default, two tools are excluded from sub-agents:

| Tool | Why | Exception |
|------|-----|-----------|
| `spawn` | Prevents recursive delegation | Depth-1 sub-agents can access `spawn` when `max_spawn_depth >= 2` (default) |
| `message` | Sub-agents cannot directly message users | None — always excluded |

### 6.3 Security Profile Impact

| Profile | Agent Restrictions |
|---------|-------------------|
| **open** | No restrictions beyond agent config |
| **standard** | Shell commands logged, file writes audited |
| **controlled** | All tool calls require Security Agent approval |
| **restricted** | Sub-agents disabled entirely; only default agent runs |

---

## 7. Model Selection

### 7.1 Model Aliases

| Alias | Resolution | Use Case |
|-------|-----------|----------|
| `auto` | Best available model | Default for most agents |
| `fast` | Cheapest fast model (Haiku, GPT-4o-mini) | Explorer, Security |
| `reasoning` | Extended thinking model (Opus, o1) | Complex planning |
| `coding` | Code-optimized model (Sonnet, GPT-4o) | Implementation |

### 7.2 Cost Implications

| Agent | Model | Typical Tokens | Relative Cost |
|-------|-------|---------------|--------------|
| security | fast | 500-1K | $ |
| explorer | fast | 5K-15K | $ |
| default | auto | 30K-100K+ | $$$$ |

Using `explorer` for codebase search instead of the default agent saves ~10x per search task.

---

## 8. Implementation Priority

Phases below start after [core-infra.md](core-infra.md) Phase 10 (Sub-agent spawning).

| Phase | What | Depends On |
|-------|------|-----------|
| **1** | Agent definition format in config schema | Config loader |
| **2** | `default` agent (full loop) | Agent loop (core-infra Phase 9) |
| **3** | `explorer` agent (fast model + read-only) | Spawn tool (core-infra Phase 10) + model aliases |
| **4** | `security` agent | Approval mechanism (core-infra Phase 3-4) |
| **5** | Agent discovery injection in context | Context builder |
| **6** | Bundled templates (coder, reviewer, tester, researcher, communicator) | Phase 1-5 |
| **7** | `workpilot agents enable/disable` CLI | Phase 6 |
| **8** | Custom agent authoring docs | Phase 1-7 |
