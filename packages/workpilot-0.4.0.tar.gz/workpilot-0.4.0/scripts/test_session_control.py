"""
Copilot SDK session control & resume test.

Tests:
  1. create_session with explicit session_id
  2. multi-turn conversation (context retained)
  3. destroy -> resume_session (history survives destroy)
  4. list_sessions + get_messages
  5. resume across CopilotClient restart (client stop/start)
  6. session_id persistence in CopilotDelegateService task registry
"""

import asyncio
import sys
import uuid
from pathlib import Path

from copilot import CopilotClient, PermissionHandler, SessionListFilter

WORKSPACE = Path(__file__).parent.parent
PASS = "[PASS]"
FAIL = "[FAIL]"


def section(title: str) -> None:
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}")


def make_client() -> CopilotClient:
    return CopilotClient({"cwd": str(WORKSPACE)})


# ── Test 1: Explicit session_id ───────────────────────────────────────────────

async def test_explicit_session_id() -> bool:
    section("TEST 1: create_session with explicit session_id")
    client = make_client()
    await client.start()
    custom_id = "wp-test-" + uuid.uuid4().hex[:8]
    try:
        session = await client.create_session({
            "model": "claude-sonnet-4.6",
            "on_permission_request": PermissionHandler.approve_all,
            "session_id": custom_id,
        })
        ok = session.session_id == custom_id
        print(f"  Requested ID: {custom_id}")
        print(f"  Actual ID:    {session.session_id}")
        print(f"  {PASS if ok else FAIL} session_id matches requested value")
        await session.destroy()
        await client.stop()
        return ok
    except Exception as e:
        print(f"  {FAIL} Exception: {e}")
        await client.stop()
        return False


# ── Test 2: Multi-turn conversation ──────────────────────────────────────────

async def test_multi_turn() -> bool:
    section("TEST 2: Multi-turn conversation (context retention)")
    client = make_client()
    await client.start()
    try:
        session = await client.create_session({
            "model": "claude-sonnet-4.6",
            "on_permission_request": PermissionHandler.approve_all,
        })
        sid = session.session_id
        print(f"  Session ID: {sid}")

        # Turn 1: establish context
        r1 = await asyncio.wait_for(
            session.send_and_wait({"prompt": "My project codename is XRAY-7. Please say: NOTED"}),
            timeout=30,
        )
        t1 = r1.data.content if r1 else ""
        print(f"  Turn 1: {t1!r}")

        # Turn 2: recall
        r2 = await asyncio.wait_for(
            session.send_and_wait({"prompt": "What codename did I just tell you?"}),
            timeout=30,
        )
        t2 = r2.data.content if r2 else ""
        print(f"  Turn 2: {t2!r}")

        ok = "XRAY-7" in t2
        print(f"  {PASS if ok else FAIL} Context retained across turns (XRAY-7 recalled)")

        await session.destroy()
        await client.stop()
        return ok
    except Exception as e:
        print(f"  {FAIL} Exception: {e}")
        await client.stop()
        return False


# ── Test 3: destroy -> resume_session ─────────────────────────────────────────

async def test_resume_after_destroy() -> bool:
    section("TEST 3: destroy -> resume_session (history survives)")
    client = make_client()
    await client.start()
    try:
        # Create and use a session
        session = await client.create_session({
            "model": "claude-sonnet-4.6",
            "on_permission_request": PermissionHandler.approve_all,
        })
        sid = session.session_id
        print(f"  Session ID: {sid}")

        r1 = await asyncio.wait_for(
            session.send_and_wait({"prompt": "My project uses colour COBALT for branding. Please say: NOTED"}),
            timeout=30,
        )
        print(f"  Before destroy: {r1.data.content if r1 else ''!r}")

        # Destroy (closes handle, but CLI keeps history)
        await session.destroy()
        print(f"  Session destroyed.")

        # Resume with same session_id
        resumed = await client.resume_session(sid, {
            "model": "claude-sonnet-4.6",
            "on_permission_request": PermissionHandler.approve_all,
        })
        print(f"  Resumed session ID: {resumed.session_id}")

        r2 = await asyncio.wait_for(
            resumed.send_and_wait({"prompt": "What is my favourite colour?"}),
            timeout=30,
        )
        answer = r2.data.content if r2 else ""
        print(f"  After resume: {answer!r}")

        ok = "COBALT" in answer.upper()
        print(f"  {PASS if ok else FAIL} History survived destroy+resume (COBALT recalled)")

        await resumed.destroy()
        await client.stop()
        return ok
    except Exception as e:
        print(f"  {FAIL} Exception: {e}")
        await client.stop()
        return False


# ── Test 4: list_sessions + get_messages ─────────────────────────────────────

async def test_list_and_messages() -> bool:
    section("TEST 4: list_sessions + get_messages")
    client = make_client()
    await client.start()
    try:
        session = await client.create_session({
            "model": "claude-sonnet-4.6",
            "on_permission_request": PermissionHandler.approve_all,
        })
        sid = session.session_id

        await asyncio.wait_for(
            session.send_and_wait({"prompt": "Say: HISTORY_TEST"}),
            timeout=30,
        )

        # list_sessions filtered by cwd
        all_sessions = await client.list_sessions(
            SessionListFilter(cwd=str(WORKSPACE))
        )
        our_session = next((s for s in all_sessions if s.sessionId == sid), None)
        ok_list = our_session is not None
        print(f"  Total sessions listed: {len(all_sessions)}")
        print(f"  Our session found: {ok_list}")
        if our_session:
            print(f"  Summary: {our_session.summary!r}")
            print(f"  Modified: {our_session.modifiedTime}")

        # get_messages
        msgs = await session.get_messages()
        has_msg = any(
            "HISTORY_TEST" in str(getattr(getattr(e, "data", None), "content", ""))
            for e in msgs
        )
        print(f"  Messages in history: {len(msgs)}")
        print(f"  HISTORY_TEST found in messages: {has_msg}")
        ok = ok_list and has_msg
        print(f"  {PASS if ok else FAIL} list_sessions and get_messages work correctly")

        await session.destroy()
        await client.stop()
        return ok
    except Exception as e:
        print(f"  {FAIL} Exception: {e}")
        await client.stop()
        return False


# ── Test 5: Resume across full client restart ─────────────────────────────────

async def test_resume_across_client_restart() -> bool:
    section("TEST 5: Resume across CopilotClient restart")
    saved_session_id: str = ""

    # --- Phase A: create + set context + stop client ---
    client_a = make_client()
    await client_a.start()
    try:
        session_a = await client_a.create_session({
            "model": "claude-sonnet-4.6",
            "on_permission_request": PermissionHandler.approve_all,
        })
        saved_session_id = session_a.session_id
        print(f"  Phase A — Session ID: {saved_session_id}")

        await asyncio.wait_for(
            session_a.send_and_wait({"prompt": "The build version is PHOENIX-99. Please say: CONFIRMED"}),
            timeout=30,
        )
        # destroy session handle, then stop entire client
        await session_a.destroy()
        await client_a.stop()
        print(f"  Phase A — client stopped. Session ID saved: {saved_session_id}")
    except Exception as e:
        print(f"  {FAIL} Phase A exception: {e}")
        await client_a.stop()
        return False

    # --- Phase B: fresh client, resume session by saved ID ---
    client_b = make_client()
    await client_b.start()
    try:
        session_b = await client_b.resume_session(saved_session_id, {
            "model": "claude-sonnet-4.6",
            "on_permission_request": PermissionHandler.approve_all,
        })
        print(f"  Phase B — Resumed session: {session_b.session_id}")

        r = await asyncio.wait_for(
            session_b.send_and_wait({"prompt": "What code did I give you earlier?"}),
            timeout=30,
        )
        answer = r.data.content if r else ""
        print(f"  Phase B — Answer: {answer!r}")

        ok = "PHOENIX-99" in answer
        print(f"  {PASS if ok else FAIL} History persisted across full client restart (PHOENIX-99 recalled)")

        await session_b.destroy()
        await client_b.stop()
        return ok
    except Exception as e:
        print(f"  {FAIL} Phase B exception: {e}")
        await client_b.stop()
        return False


# ── Test 6: delete_session ────────────────────────────────────────────────────

async def test_delete_session() -> bool:
    section("TEST 6: delete_session (permanent removal)")
    client = make_client()
    await client.start()
    try:
        session = await client.create_session({
            "model": "claude-sonnet-4.6",
            "on_permission_request": PermissionHandler.approve_all,
        })
        sid = session.session_id
        print(f"  Session ID: {sid}")

        await asyncio.wait_for(
            session.send_and_wait({"prompt": "Say: DELETE_ME"}),
            timeout=30,
        )
        await session.destroy()

        # delete permanently
        await client.delete_session(sid)
        print(f"  Deleted session {sid}")

        # Attempt to resume — should fail
        try:
            bad = await client.resume_session(sid, {
                "on_permission_request": PermissionHandler.approve_all,
            })
            # If resume succeeded, the session wasn't really deleted
            await bad.destroy()
            ok = False
            print(f"  {FAIL} Resume succeeded after delete (unexpected)")
        except Exception as resume_exc:
            ok = True
            print(f"  Resume correctly failed: {type(resume_exc).__name__}: {resume_exc}")
            print(f"  {PASS} delete_session prevents future resume")

        await client.stop()
        return ok
    except Exception as e:
        print(f"  {FAIL} Exception: {e}")
        await client.stop()
        return False


# ── Main ──────────────────────────────────────────────────────────────────────

async def main() -> None:
    print("\nCopilot SDK — Session Control & Resume Test")
    print(f"Workspace: {WORKSPACE}")

    results: dict[str, bool] = {}
    results["explicit_session_id"] = await test_explicit_session_id()
    results["multi_turn"] = await test_multi_turn()
    results["resume_after_destroy"] = await test_resume_after_destroy()
    results["list_and_messages"] = await test_list_and_messages()
    results["resume_across_restart"] = await test_resume_across_client_restart()
    results["delete_session"] = await test_delete_session()

    section("SUMMARY")
    all_pass = True
    for name, ok in results.items():
        status = PASS if ok else FAIL
        print(f"  {status}  {name}")
        if not ok:
            all_pass = False

    print(f"\n  {'ALL TESTS PASSED' if all_pass else 'SOME TESTS FAILED'}")
    sys.exit(0 if all_pass else 1)


if __name__ == "__main__":
    asyncio.run(main())
