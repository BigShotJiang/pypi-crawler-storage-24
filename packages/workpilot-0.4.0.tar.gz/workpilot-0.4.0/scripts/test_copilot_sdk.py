"""
Copilot SDK integration feasibility test for WorkPilot.

Tests:
  1. Basic session + send_and_wait
  2. Custom tool injection (WorkPilot tool bridge pattern)
  3. Hook pipeline (pre_tool_use allow/deny)
  4. Streaming delta events
  5. Background concurrent sessions
  6. Real multi-step codebase task
"""

# NOTE: do NOT use `from __future__ import annotations` —
# define_tool uses get_type_hints() which breaks with lazy annotations
# when Pydantic models are referenced by string.

import asyncio
import subprocess
import sys
import time
from pathlib import Path

from copilot import CopilotClient, PermissionHandler, define_tool
from pydantic import BaseModel, Field

WORKSPACE = Path(__file__).parent.parent
PASS = "[PASS]"
FAIL = "[FAIL]"


# ── Module-level Pydantic models (required by define_tool / get_type_hints) ─

class ShellParams(BaseModel):
    command: str = Field(description="Shell command to run")


# ── Helpers ──────────────────────────────────────────────────────────────────

def section(title: str) -> None:
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}")


def make_client() -> CopilotClient:
    # CopilotClientOptions is a TypedDict — pass as dict
    return CopilotClient({"cwd": str(WORKSPACE)})


# ── Test 1: Basic session + send_and_wait ────────────────────────────────────

async def test_basic_session() -> bool:
    section("TEST 1: Basic session + send_and_wait")
    try:
        client = make_client()
        await client.start()
        session = await client.create_session({
            "model": "claude-sonnet-4.6",
            "on_permission_request": PermissionHandler.approve_all,
        })
        reply = await asyncio.wait_for(
            session.send_and_wait({"prompt": "Reply with exactly the word: PONG"}),
            timeout=30,
        )
        content = reply.data.content if reply else ""
        ok = "PONG" in content
        print(f"  Response: {content!r}")
        print(f"  {PASS if ok else FAIL} send_and_wait round-trip")
        await session.destroy()
        await client.stop()
        return ok
    except Exception as e:
        print(f"  {FAIL} Exception: {e}")
        return False


# ── Test 2: Custom tool injection (WorkPilot bridge pattern) ─────────────────

tool_call_log: list[str] = []


@define_tool(description="Execute a shell command and return stdout")
async def workpilot_shell(params: ShellParams) -> str:
    tool_call_log.append(params.command)
    try:
        result = subprocess.run(
            params.command, shell=True, capture_output=True, text=True,
            cwd=str(WORKSPACE), timeout=10,
        )
        return result.stdout.strip() or result.stderr.strip() or "(no output)"
    except Exception as e:
        return f"Error: {e}"


async def test_custom_tool() -> bool:
    section("TEST 2: Custom tool injection (WorkPilot bridge pattern)")
    tool_call_log.clear()
    try:
        client = make_client()
        await client.start()
        session = await client.create_session({
            "model": "claude-sonnet-4.6",
            "on_permission_request": PermissionHandler.approve_all,
            "tools": [workpilot_shell],
        })
        reply = await asyncio.wait_for(
            session.send_and_wait({
                "prompt": (
                    "Use the workpilot_shell tool to run: "
                    "python -c \"print('tool_bridge_ok')\"\n"
                    "Then reply with just the output you got."
                )
            }),
            timeout=30,
        )
        content = reply.data.content if reply else ""
        ok = "tool_bridge_ok" in content and len(tool_call_log) >= 1
        print(f"  Tool was called with: {tool_call_log}")
        print(f"  Response: {content!r}")
        print(f"  {PASS if ok else FAIL} Custom tool injected and invoked")
        await session.destroy()
        await client.stop()
        return ok
    except Exception as e:
        print(f"  {FAIL} Exception: {e}")
        return False


# ── Test 3: Hook pipeline (pre_tool_use allow/deny) ──────────────────────────

async def test_hooks() -> bool:
    section("TEST 3: Hook pipeline (on_pre_tool_use intercept)")
    intercepted: list[str] = []

    async def pre_hook(input: dict, invocation: dict) -> dict:
        name = input.get("toolName", "")
        intercepted.append(name)
        return {"permissionDecision": "allow"}

    try:
        client = make_client()
        await client.start()
        session = await client.create_session({
            "model": "claude-sonnet-4.6",
            "on_permission_request": PermissionHandler.approve_all,
            "hooks": {"on_pre_tool_use": pre_hook},
        })
        reply = await asyncio.wait_for(
            session.send_and_wait({
                "prompt": "List the files in the current directory using a file tool."
            }),
            timeout=30,
        )
        content = reply.data.content if reply else ""
        ok = len(intercepted) > 0
        print(f"  Intercepted tools: {intercepted}")
        print(f"  Response snippet: {content[:120]!r}")
        print(f"  {PASS if ok else FAIL} Hook intercepted {len(intercepted)} tool call(s)")
        await session.destroy()
        await client.stop()
        return ok
    except Exception as e:
        print(f"  {FAIL} Exception: {e}")
        return False


# ── Test 4: Streaming delta events ───────────────────────────────────────────

async def test_streaming() -> bool:
    section("TEST 4: Streaming delta events")
    try:
        client = make_client()
        await client.start()
        session = await client.create_session({
            "model": "claude-sonnet-4.6",
            "on_permission_request": PermissionHandler.approve_all,
            "streaming": True,
        })
        done = asyncio.Event()
        deltas: list[str] = []

        def on_event(event: object) -> None:
            t = event.type.value  # type: ignore[attr-defined]
            if t == "assistant.message_delta":
                chunk = event.data.delta_content or ""  # type: ignore[attr-defined]
                deltas.append(chunk)
                print(chunk, end="", flush=True)
            elif t == "session.idle":
                done.set()

        session.on(on_event)
        print("  Streaming output: ", end="")
        await session.send({"prompt": "Count from 1 to 3, one per line."})
        await asyncio.wait_for(done.wait(), timeout=30)
        print()

        # >=1 chunk is correct: short responses may arrive as a single delta
        ok = len(deltas) >= 1
        full = "".join(deltas)
        print(f"  Chunks received: {len(deltas)} | Full: {full.strip()!r}")
        print(f"  {PASS if ok else FAIL} Streaming produced {len(deltas)} delta chunk(s)")
        await session.destroy()
        await client.stop()
        return ok
    except Exception as e:
        print(f"  {FAIL} Exception: {e}")
        return False


# ── Test 5: Background concurrent sessions ────────────────────────────────────

async def test_background_concurrent() -> bool:
    section("TEST 5: Background concurrent sessions")
    try:
        client = make_client()
        await client.start()

        async def run_task(prompt: str) -> str:
            session = await client.create_session({
                "model": "claude-sonnet-4.6",
                "on_permission_request": PermissionHandler.approve_all,
            })
            reply = await asyncio.wait_for(
                session.send_and_wait({"prompt": prompt}),
                timeout=30,
            )
            await session.destroy()
            return reply.data.content if reply else ""

        start = time.monotonic()
        results = await asyncio.gather(
            run_task("Reply with just: ALPHA"),
            run_task("Reply with just: BETA"),
            run_task("Reply with just: GAMMA"),
        )
        elapsed = time.monotonic() - start

        ok = (
            any("ALPHA" in r for r in results)
            and any("BETA" in r for r in results)
            and any("GAMMA" in r for r in results)
        )
        print(f"  Results: {[r.strip() for r in results]}")
        print(f"  Elapsed: {elapsed:.1f}s (3 concurrent sessions)")
        print(f"  {PASS if ok else FAIL} All 3 concurrent sessions returned correct results")
        await client.stop()
        return ok
    except Exception as e:
        print(f"  {FAIL} Exception: {e}")
        return False


# ── Test 6: Real multi-step codebase task ─────────────────────────────────────

async def test_real_task() -> bool:
    section("TEST 6: Real multi-step codebase task")
    tool_names: list[str] = []

    async def pre_hook(input: dict, invocation: dict) -> dict:
        tool_names.append(input.get("toolName", ""))
        return {"permissionDecision": "allow"}

    try:
        client = make_client()
        await client.start()
        session = await client.create_session({
            "model": "claude-sonnet-4.6",
            "on_permission_request": PermissionHandler.approve_all,
            "hooks": {"on_pre_tool_use": pre_hook},
        })
        reply = await asyncio.wait_for(
            session.send_and_wait({
                "prompt": (
                    "In the workpilot/ directory, count how many Python (.py) files exist "
                    "and report the exact number. Use file tools to explore."
                )
            }),
            timeout=60,
        )
        content = reply.data.content if reply else ""
        ok = len(tool_names) > 0 and any(c.isdigit() for c in content)
        print(f"  Tools used ({len(tool_names)}): {tool_names}")
        print(f"  Response: {content.strip()!r}")
        print(f"  {PASS if ok else FAIL} Multi-step task: {len(tool_names)} tool call(s), numeric answer returned")
        await session.destroy()
        await client.stop()
        return ok
    except Exception as e:
        print(f"  {FAIL} Exception: {e}")
        return False


# ── Main ──────────────────────────────────────────────────────────────────────

async def main() -> None:
    print("\nCopilot SDK -- WorkPilot Integration Feasibility Test")
    print(f"Workspace: {WORKSPACE}")

    results: dict[str, bool] = {}
    results["basic_session"] = await test_basic_session()
    results["custom_tool"] = await test_custom_tool()
    results["hooks"] = await test_hooks()
    results["streaming"] = await test_streaming()
    results["background_concurrent"] = await test_background_concurrent()
    results["real_task"] = await test_real_task()

    section("SUMMARY")
    all_pass = True
    for name, ok in results.items():
        status = PASS if ok else FAIL
        print(f"  {status}  {name}")
        if not ok:
            all_pass = False

    print(f"\n  {'ALL TESTS PASSED' if all_pass else 'SOME TESTS FAILED'}")
    sys.exit(0 if all_pass else 1)


if __name__ == "__main__":
    asyncio.run(main())
