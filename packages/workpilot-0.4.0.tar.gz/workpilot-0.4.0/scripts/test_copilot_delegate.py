"""
End-to-end test for CopilotDelegateTool + CopilotStatusTool.

Tests:
  1. Direct service — background task + status poll
  2. Direct service — wait mode (blocks until done)
  3. Tool layer — CopilotDelegateTool.execute() with mocked bus
  4. Tool layer — CopilotStatusTool.execute()
  5. Real task — code review on a WorkPilot source file
  6. Notification — OutboundMessage reaches the bus
"""

import asyncio
import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

# Add WorkPilot to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from workpilot.agent.tools.copilot import (
    CopilotDelegateService,
    CopilotDelegateTool,
    CopilotStatusTool,
    TaskStatus,
)
from workpilot.config.schema import CopilotToolConfig

WORKSPACE = Path(__file__).parent.parent
PASS = "[PASS]"
FAIL = "[FAIL]"
DEFAULT_CONFIG = CopilotToolConfig()


def section(title: str) -> None:
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}")


def make_mock_bus() -> MagicMock:
    bus = MagicMock()
    bus.publish_outbound = AsyncMock()
    return bus


# ── Test 1: Background task submission + status poll ─────────────────────────

async def test_background_submit() -> bool:
    section("TEST 1: Background task submission + status poll")
    bus = make_mock_bus()
    svc = CopilotDelegateService(WORKSPACE, bus, config=DEFAULT_CONFIG)
    try:
        result = await svc.submit(
            task_desc="Reply with exactly: BACKGROUND_OK",
            task_type="code",
            files=[],
            model="claude-sonnet-4.6",
            mode="background",
            notify_channel="cli",
            notify_channel_id="cli",
            notify_thread_id=None,
        )
        ok_submit = "task_id" in result.lower() or "submitted" in result.lower()
        print(f"  Submit result: {result!r}")
        print(f"  {PASS if ok_submit else FAIL} Background submit returned task_id")

        # Extract task_id from result
        task_id = None
        for line in result.splitlines():
            if "id=" in line:
                task_id = line.split("id=")[1].split(")")[0].strip()
                break

        if not task_id:
            tasks = svc.list_tasks()
            task_id = tasks[0].task_id if tasks else None

        if not task_id:
            print(f"  {FAIL} Could not extract task_id")
            return False

        # Wait for background task to finish (max 30s)
        for _ in range(30):
            ct = svc.get_task(task_id)
            if ct and ct.status in (TaskStatus.DONE, TaskStatus.FAILED):
                break
            await asyncio.sleep(1)

        ct = svc.get_task(task_id)
        ok_done = ct is not None and ct.status == TaskStatus.DONE
        ok_notify = bus.publish_outbound.called
        print(f"  Task status: {ct.status.value if ct else 'not found'}")
        print(f"  Result snippet: {(ct.result[:80] if ct else '')!r}")
        print(f"  Notification sent: {ok_notify}")
        print(f"  {PASS if ok_done else FAIL} Task reached DONE state")
        print(f"  {PASS if ok_notify else FAIL} OutboundMessage published to bus")

        await svc.stop()
        return ok_submit and ok_done and ok_notify
    except Exception as e:
        print(f"  {FAIL} Exception: {e}")
        await svc.stop()
        return False


# ── Test 2: Wait mode ─────────────────────────────────────────────────────────

async def test_wait_mode() -> bool:
    section("TEST 2: Wait mode (blocking)")
    bus = make_mock_bus()
    svc = CopilotDelegateService(WORKSPACE, bus, config=DEFAULT_CONFIG)
    try:
        result = await asyncio.wait_for(
            svc.submit(
                task_desc="Reply with exactly: WAIT_OK",
                task_type="code",
                files=[],
                model="claude-sonnet-4.6",
                mode="wait",
                notify_channel="cli",
                notify_channel_id="cli",
                notify_thread_id=None,
            ),
            timeout=60,
        )
        ok = "WAIT_OK" in result
        print(f"  Result: {result!r}")
        print(f"  {PASS if ok else FAIL} Wait mode returned result synchronously")
        await svc.stop()
        return ok
    except Exception as e:
        print(f"  {FAIL} Exception: {e}")
        await svc.stop()
        return False


# ── Test 3: Tool layer — gh_copilot ─────────────────────────────────────

async def test_tool_delegate() -> bool:
    section("TEST 3: Tool layer — CopilotDelegateTool")
    bus = make_mock_bus()
    svc = CopilotDelegateService(WORKSPACE, bus, config=DEFAULT_CONFIG)
    tool = CopilotDelegateTool(svc)
    tool.set_channel_context("cli", "cli")

    try:
        result = await tool.execute(
            task="Count to three and reply with: ONE TWO THREE",
            task_type="code",
            mode="background",
            model="claude-sonnet-4.6",
        )
        ok = "task_id" in result.lower() or "submitted" in result.lower()
        print(f"  Tool result: {result!r}")
        print(f"  {PASS if ok else FAIL} CopilotDelegateTool.execute() returned task reference")

        # Wait for background
        tasks = svc.list_tasks()
        if tasks:
            task_id = tasks[0].task_id
            for _ in range(30):
                ct = svc.get_task(task_id)
                if ct and ct.status in (TaskStatus.DONE, TaskStatus.FAILED):
                    break
                await asyncio.sleep(1)
            ct = svc.get_task(task_id)
            print(f"  Final status: {ct.status.value if ct else 'unknown'}")

        await svc.stop()
        return ok
    except Exception as e:
        print(f"  {FAIL} Exception: {e}")
        await svc.stop()
        return False


# ── Test 4: Tool layer — gh_copilot_status ──────────────────────────────────────

async def test_tool_status() -> bool:
    section("TEST 4: Tool layer — CopilotStatusTool")
    bus = make_mock_bus()
    svc = CopilotDelegateService(WORKSPACE, bus, config=DEFAULT_CONFIG)
    delegate = CopilotDelegateTool(svc)
    delegate.set_channel_context("cli", "cli")
    status_tool = CopilotStatusTool(svc)

    try:
        # Submit a background task
        await delegate.execute(
            task="Reply: STATUS_TEST_OK",
            task_type="code",
            mode="background",
        )

        # List tasks (no task_id)
        list_result = await status_tool.execute()
        ok_list = "pending" in list_result or "running" in list_result or "done" in list_result
        print(f"  List result:\n{list_result}")
        print(f"  {PASS if ok_list else FAIL} List tasks shows status")

        # Query specific task
        tasks = svc.list_tasks()
        if tasks:
            task_id = tasks[0].task_id
            detail = await status_tool.execute(task_id=task_id)
            ok_detail = task_id in detail
            print(f"  Detail result:\n{detail}")
            print(f"  {PASS if ok_detail else FAIL} Single task query shows correct task_id")
        else:
            ok_detail = False
            print(f"  {FAIL} No tasks in registry")

        # Wait for completion
        if tasks:
            for _ in range(30):
                ct = svc.get_task(tasks[0].task_id)
                if ct and ct.status in (TaskStatus.DONE, TaskStatus.FAILED):
                    break
                await asyncio.sleep(1)

        await svc.stop()
        return ok_list and ok_detail
    except Exception as e:
        print(f"  {FAIL} Exception: {e}")
        await svc.stop()
        return False


# ── Test 5: Real code-review task ─────────────────────────────────────────────

async def test_real_review() -> bool:
    section("TEST 5: Real code-review task on WorkPilot source file")
    bus = make_mock_bus()
    svc = CopilotDelegateService(WORKSPACE, bus, config=DEFAULT_CONFIG)
    try:
        # Use background mode to avoid blocking; wait up to 120s for completion
        await svc.submit(
            task_desc=(
                "Review the file workpilot/agent/tools/shell.py for any bugs, "
                "security issues, or improvements. Be concise — max 5 bullet points."
            ),
            task_type="review",
            files=["workpilot/agent/tools/shell.py"],
            model="claude-sonnet-4.6",
            mode="background",
            notify_channel="cli",
            notify_channel_id="cli",
            notify_thread_id=None,
        )

        tasks = svc.list_tasks()
        task_id = tasks[0].task_id if tasks else None

        for _ in range(120):
            ct = svc.get_task(task_id) if task_id else None
            if ct and ct.status in (TaskStatus.DONE, TaskStatus.FAILED):
                break
            await asyncio.sleep(1)

        ct = svc.get_task(task_id) if task_id else None
        result = ct.result if ct and ct.status == TaskStatus.DONE else (ct.error if ct else "")
        ok = (
            ct is not None
            and ct.status == TaskStatus.DONE
            and len(result) > 50
            and any(
                kw in result.lower()
                for kw in ["shell", "command", "timeout", "sandbox", "security", "error", "risk"]
            )
        )
        safe_result = result.encode("ascii", errors="replace").decode("ascii")
        print(f"  Status: {ct.status.value if ct else 'unknown'}")
        print(f"  Review result ({len(result)} chars):\n{safe_result[:600]}")
        print(f"  {PASS if ok else FAIL} Real review task produced substantive output")
        await svc.stop()
        return ok
    except Exception as e:
        print(f"  {FAIL} Exception: {e}")
        await svc.stop()
        return False


# ── Test 6: Notification routing ─────────────────────────────────────────────

async def test_notification_routing() -> bool:
    section("TEST 6: Notification routed to correct channel")
    bus = make_mock_bus()
    svc = CopilotDelegateService(WORKSPACE, bus, config=DEFAULT_CONFIG)
    try:
        await svc.submit(
            task_desc="Do not use any tools. Reply with exactly the text: NOTIFY_TEST",
            task_type="code",
            files=[],
            model="claude-sonnet-4.6",
            mode="background",
            notify_channel="teams",      # non-CLI channel
            notify_channel_id="user-123",
            notify_thread_id="thread-abc",
        )

        # Wait for task to complete BEFORE stopping service
        for _ in range(120):
            tasks = svc.list_tasks()
            if tasks and tasks[0].status in (TaskStatus.DONE, TaskStatus.FAILED):
                break
            await asyncio.sleep(1)

        # Verify notification was sent to the right channel
        ok = False
        if bus.publish_outbound.called:
            call_args = bus.publish_outbound.call_args_list[-1]
            msg = call_args[0][0]  # first positional arg
            ok = (
                msg.channel == "teams"
                and msg.channel_id == "user-123"
                and msg.thread_id == "thread-abc"
                and "task_id" in (msg.metadata or {})
            )
            print(f"  Notification channel:    {msg.channel}")
            print(f"  Notification channel_id: {msg.channel_id}")
            print(f"  Notification thread_id:  {msg.thread_id}")
            print(f"  Notification metadata:   {msg.metadata}")
        else:
            print(f"  {FAIL} No notification published")

        print(f"  {PASS if ok else FAIL} Notification routed to correct channel/thread")
        await svc.stop()
        return ok
    except Exception as e:
        print(f"  {FAIL} Exception: {e}")
        await svc.stop()
        return False


# ── Main ──────────────────────────────────────────────────────────────────────

async def main() -> None:
    print("\nCopilotDelegate — End-to-End Integration Test")
    print(f"Workspace: {WORKSPACE}")

    results: dict[str, bool] = {}
    results["background_submit"] = await test_background_submit()
    results["wait_mode"] = await test_wait_mode()
    results["tool_delegate"] = await test_tool_delegate()
    results["tool_status"] = await test_tool_status()
    results["real_review"] = await test_real_review()
    results["notification_routing"] = await test_notification_routing()

    section("SUMMARY")
    all_pass = True
    for name, ok in results.items():
        status = PASS if ok else FAIL
        print(f"  {status}  {name}")
        if not ok:
            all_pass = False

    print(f"\n  {'ALL TESTS PASSED' if all_pass else 'SOME TESTS FAILED'}")
    sys.exit(0 if all_pass else 1)


if __name__ == "__main__":
    asyncio.run(main())
