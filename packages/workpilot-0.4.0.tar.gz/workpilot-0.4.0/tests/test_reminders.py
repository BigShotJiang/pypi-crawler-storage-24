"""Tests for system reminders injection during the agent loop.

Covers:
- ReminderTracker periodic injection logic
- Post-compaction memory re-read + task reminder
- Post-spawn parent-task reminder
- Integration with the agent loop (tool-call counting, compaction, spawn)
"""

from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock

import pytest

from workpilot.agent.loop import AgentLoop
from workpilot.agent.reminders import (
    ReminderTracker,
    build_periodic_reminder,
    build_post_compaction_reminder,
    build_post_spawn_reminder,
)
from workpilot.bus.queue import MessageBus
from workpilot.config.schema import AgentConfig, AuditConfig
from workpilot.providers.base import LLMResponse, ToolCallRequest
from workpilot.security.audit import AuditLogger
from workpilot.session.manager import SessionManager

# ── Helper builders ──────────────────────────────────────────────────────────


def _make_provider(responses: list[LLMResponse]) -> AsyncMock:
    """Create a mock LLM provider that returns pre-defined responses."""
    provider = AsyncMock()
    provider.complete = AsyncMock(side_effect=responses)
    return provider


def _make_tool_registry():
    """Minimal tool registry with mock 'shell' and 'spawn' tools."""
    from workpilot.agent.tools.base import Tool
    from workpilot.agent.tools.registry import ToolRegistry

    class MockShellTool(Tool):
        @property
        def name(self) -> str:
            return "shell"

        @property
        def description(self) -> str:
            return "Run a shell command"

        @property
        def parameters(self) -> dict:
            return {
                "type": "object",
                "properties": {"command": {"type": "string"}},
                "required": ["command"],
            }

        async def execute(self, **kwargs: Any) -> str:
            return f"executed: {kwargs.get('command', '')}"

    class MockSpawnTool(Tool):
        @property
        def name(self) -> str:
            return "spawn"

        @property
        def description(self) -> str:
            return "Spawn a sub-agent"

        @property
        def parameters(self) -> dict:
            return {
                "type": "object",
                "properties": {
                    "agent": {"type": "string"},
                    "prompt": {"type": "string"},
                },
                "required": ["agent", "prompt"],
            }

        async def execute(self, **kwargs: Any) -> str:
            return f"Sub-agent '{kwargs.get('agent', '')}' result: done"

    registry = ToolRegistry()
    registry.register(MockShellTool())
    registry.register(MockSpawnTool())
    return registry


def _make_loop(
    provider: AsyncMock,
    tmp_path: Path,
    *,
    reminder_interval: int = 10,
    max_iterations: int = 20,
) -> AgentLoop:
    return AgentLoop(
        config=AgentConfig(
            max_iterations=max_iterations,
            reminder_interval=reminder_interval,
        ),
        provider=provider,
        tool_registry=_make_tool_registry(),
        bus=MessageBus(),
        session_manager=SessionManager(tmp_path),
        audit=AuditLogger(AuditConfig(enabled=False)),
        workspace=tmp_path,
    )


# ── Unit tests: reminder builders ────────────────────────────────────────────


class TestBuildPeriodicReminder:
    def test_contains_agent_name(self):
        msg = build_periodic_reminder("TestBot", "Fix the login bug")
        assert msg["role"] == "system"
        assert "TestBot" in msg["content"]

    def test_contains_task(self):
        msg = build_periodic_reminder("Bot", "Implement feature X")
        assert "Implement feature X" in msg["content"]

    def test_truncates_long_task(self):
        long_task = "x" * 300
        msg = build_periodic_reminder("Bot", long_task)
        assert "..." in msg["content"]
        # Should contain at most 200 chars of the task + "..."
        assert "x" * 200 in msg["content"]
        assert "x" * 201 not in msg["content"]

    def test_system_reminder_marker(self):
        msg = build_periodic_reminder("Bot", "task")
        assert "[System Reminder]" in msg["content"]


class TestBuildPostCompactionReminder:
    def test_includes_memory_when_file_exists(self, tmp_path: Path):
        (tmp_path / "MEMORY.md").write_text("Important fact: X=42", encoding="utf-8")
        msgs = build_post_compaction_reminder("Bot", tmp_path, "Fix bug")
        # Should have memory reload + task reminder
        assert len(msgs) >= 2
        memory_msg = msgs[0]
        assert "[Post-Compaction Memory Reload]" in memory_msg["content"]
        assert "X=42" in memory_msg["content"]

    def test_no_memory_msg_when_no_file(self, tmp_path: Path):
        msgs = build_post_compaction_reminder("Bot", tmp_path, "Fix bug")
        # Only the task reminder (no memory file)
        assert len(msgs) == 1
        assert "[Post-Compaction Reminder]" in msgs[0]["content"]

    def test_includes_shared_memory(self, tmp_path: Path):
        shared_dir = tmp_path / "memory" / "shared"
        shared_dir.mkdir(parents=True)
        (shared_dir / "MEMORY.md").write_text("Shared fact: Y=99", encoding="utf-8")
        msgs = build_post_compaction_reminder("Bot", tmp_path, "task")
        contents = " ".join(m["content"] for m in msgs)
        assert "Y=99" in contents

    def test_task_in_reminder(self, tmp_path: Path):
        msgs = build_post_compaction_reminder("Bot", tmp_path, "Deploy to prod")
        last = msgs[-1]
        assert "Deploy to prod" in last["content"]
        assert "Bot" in last["content"]


class TestBuildPostSpawnReminder:
    def test_contains_child_name(self):
        msg = build_post_spawn_reminder("Parent", "Fix bug", "coder")
        assert msg["role"] == "system"
        assert "coder" in msg["content"]

    def test_contains_parent_task(self):
        msg = build_post_spawn_reminder("Parent", "Implement auth", "researcher")
        assert "Implement auth" in msg["content"]

    def test_sub_agent_complete_marker(self):
        msg = build_post_spawn_reminder("Parent", "task", "explorer")
        assert "[Sub-Agent Complete]" in msg["content"]


# ── Unit tests: ReminderTracker ──────────────────────────────────────────────


class TestReminderTracker:
    def test_should_inject_at_interval(self, tmp_path: Path):
        tracker = ReminderTracker(
            interval=5, agent_name="Bot", user_task="task", workspace=tmp_path
        )
        tracker.record_tool_calls(4)
        assert not tracker.should_inject()
        tracker.record_tool_calls(1)
        assert tracker.should_inject()

    def test_should_not_inject_when_disabled(self, tmp_path: Path):
        tracker = ReminderTracker(
            interval=0, agent_name="Bot", user_task="task", workspace=tmp_path
        )
        tracker.record_tool_calls(100)
        assert not tracker.should_inject()

    def test_resets_after_build(self, tmp_path: Path):
        tracker = ReminderTracker(
            interval=3, agent_name="Bot", user_task="task", workspace=tmp_path
        )
        tracker.record_tool_calls(3)
        assert tracker.should_inject()
        tracker.build_reminder()
        assert not tracker.should_inject()
        tracker.record_tool_calls(3)
        assert tracker.should_inject()

    def test_tool_call_count_accumulates(self, tmp_path: Path):
        tracker = ReminderTracker(
            interval=10, agent_name="Bot", user_task="task", workspace=tmp_path
        )
        tracker.record_tool_calls(3)
        tracker.record_tool_calls(4)
        tracker.record_tool_calls(3)
        assert tracker.tool_call_count == 10
        assert tracker.should_inject()

    def test_build_reminder_returns_system_msg(self, tmp_path: Path):
        tracker = ReminderTracker(
            interval=1, agent_name="Bot", user_task="do stuff", workspace=tmp_path
        )
        tracker.record_tool_calls(1)
        msg = tracker.build_reminder()
        assert msg["role"] == "system"
        assert "Bot" in msg["content"]
        assert "do stuff" in msg["content"]

    def test_build_post_compaction_reminders(self, tmp_path: Path):
        (tmp_path / "MEMORY.md").write_text("fact: 42", encoding="utf-8")
        tracker = ReminderTracker(
            interval=10, agent_name="Bot", user_task="task", workspace=tmp_path
        )
        msgs = tracker.build_post_compaction_reminders()
        assert len(msgs) >= 2
        assert any("42" in m["content"] for m in msgs)

    def test_build_post_spawn_reminder(self, tmp_path: Path):
        tracker = ReminderTracker(
            interval=10, agent_name="Bot", user_task="task", workspace=tmp_path
        )
        msg = tracker.build_post_spawn_reminder("explorer")
        assert "explorer" in msg["content"]


# ── Integration tests: agent loop ────────────────────────────────────────────


class TestReminderInAgentLoop:
    @pytest.mark.asyncio
    async def test_periodic_reminder_injected(self, tmp_path: Path):
        """After reminder_interval tool calls, a system reminder is injected."""
        # Build a chain: 3 iterations of tool calls (1 each), then text response
        tc1 = ToolCallRequest(id="tc1", name="shell", arguments={"command": "ls"})
        tc2 = ToolCallRequest(id="tc2", name="shell", arguments={"command": "pwd"})
        tc3 = ToolCallRequest(id="tc3", name="shell", arguments={"command": "date"})
        provider = _make_provider(
            [
                LLMResponse(content=None, tool_calls=[tc1]),
                LLMResponse(content=None, tool_calls=[tc2]),
                LLMResponse(content=None, tool_calls=[tc3]),
                LLMResponse(content="done", tool_calls=[]),
            ]
        )
        loop = _make_loop(provider, tmp_path, reminder_interval=3)

        result = await loop.run_once("list stuff")
        assert "done" in result

        # Verify the provider was called 4 times (3 tool + 1 final)
        assert provider.complete.call_count == 4

        # Check that the 4th call (after 3 tool calls) had a system reminder
        # in its messages list
        fourth_call_messages = provider.complete.call_args_list[3].kwargs.get(
            "messages", provider.complete.call_args_list[3][1].get("messages", [])
        )
        system_msgs = [
            m
            for m in fourth_call_messages
            if m.get("role") == "system" and "[System Reminder]" in m.get("content", "")
        ]
        assert len(system_msgs) == 1, "Expected exactly one periodic system reminder"

    @pytest.mark.asyncio
    async def test_no_reminder_when_disabled(self, tmp_path: Path):
        """With reminder_interval=0, no periodic reminders are injected."""
        tc1 = ToolCallRequest(id="tc1", name="shell", arguments={"command": "ls"})
        provider = _make_provider(
            [
                LLMResponse(content=None, tool_calls=[tc1]),
                LLMResponse(content="done", tool_calls=[]),
            ]
        )
        loop = _make_loop(provider, tmp_path, reminder_interval=0)

        await loop.run_once("list files")

        # Check no system reminder was injected
        second_call_messages = provider.complete.call_args_list[1].kwargs.get(
            "messages", provider.complete.call_args_list[1][1].get("messages", [])
        )
        system_reminders = [
            m
            for m in second_call_messages
            if m.get("role") == "system" and "[System Reminder]" in m.get("content", "")
        ]
        assert len(system_reminders) == 0

    @pytest.mark.asyncio
    async def test_spawn_injects_post_spawn_reminder(self, tmp_path: Path):
        """After a 'spawn' tool call, a post-spawn reminder is injected."""
        tc = ToolCallRequest(
            id="tc1",
            name="spawn",
            arguments={"agent": "coder", "prompt": "write tests"},
        )
        provider = _make_provider(
            [
                LLMResponse(content=None, tool_calls=[tc]),
                LLMResponse(content="integrated results", tool_calls=[]),
            ]
        )
        loop = _make_loop(provider, tmp_path, reminder_interval=0)

        result = await loop.run_once("implement feature")
        assert "integrated results" in result

        # The second LLM call should include a post-spawn reminder
        second_call_messages = provider.complete.call_args_list[1].kwargs.get(
            "messages", provider.complete.call_args_list[1][1].get("messages", [])
        )
        spawn_reminders = [
            m
            for m in second_call_messages
            if m.get("role") == "system" and "[Sub-Agent Complete]" in m.get("content", "")
        ]
        assert len(spawn_reminders) == 1
        assert "coder" in spawn_reminders[0]["content"]

    @pytest.mark.asyncio
    async def test_reminder_interval_config_default(self):
        """AgentConfig.reminder_interval defaults to 10."""
        config = AgentConfig()
        assert config.reminder_interval == 10

    @pytest.mark.asyncio
    async def test_reminder_interval_config_custom(self):
        """AgentConfig.reminder_interval can be set to a custom value."""
        config = AgentConfig(reminder_interval=5)
        assert config.reminder_interval == 5

    @pytest.mark.asyncio
    async def test_post_compaction_injects_memory_reminder(self, tmp_path: Path):
        """After compaction, MEMORY.md is re-read and a reminder is injected."""
        (tmp_path / "MEMORY.md").write_text(
            "Critical fact: API key rotation every 90 days",
            encoding="utf-8",
        )

        # Create enough tool calls + large results to trigger compaction
        # We use a very small context_limit to force compaction
        tc = ToolCallRequest(id="tc1", name="shell", arguments={"command": "ls"})
        provider = _make_provider(
            [
                LLMResponse(content=None, tool_calls=[tc]),
                LLMResponse(content="final answer", tool_calls=[]),
            ]
        )

        loop = AgentLoop(
            config=AgentConfig(
                max_iterations=10,
                reminder_interval=0,
                context_limit=50,  # Very small to force compaction
            ),
            provider=provider,
            tool_registry=_make_tool_registry(),
            bus=MessageBus(),
            session_manager=SessionManager(tmp_path),
            audit=AuditLogger(AuditConfig(enabled=False)),
            workspace=tmp_path,
        )

        result = await loop.run_once("do something")

        # The test verifies that the code path executes without error.
        # With context_limit=50, compaction will occur and memory will be re-read.
        assert "final answer" in result

    def test_build_post_compaction_reminder_structure(self, tmp_path: Path):
        """Directly verify build_post_compaction_reminder returns correct
        memory reload and task reminder messages when MEMORY.md exists."""
        memory_content = "Critical fact: API key rotation every 90 days"
        (tmp_path / "MEMORY.md").write_text(memory_content, encoding="utf-8")

        msgs = build_post_compaction_reminder("TestBot", tmp_path, "Fix the auth bug")

        # Should have exactly 2 messages: memory reload + task reminder
        assert len(msgs) == 2

        # First message: memory reload with the MEMORY.md content
        memory_msg = msgs[0]
        assert memory_msg["role"] == "system"
        assert "[Post-Compaction Memory Reload]" in memory_msg["content"]
        assert memory_content in memory_msg["content"]

        # Second message: task focus reminder
        task_msg = msgs[1]
        assert task_msg["role"] == "system"
        assert "[Post-Compaction Reminder]" in task_msg["content"]
        assert "TestBot" in task_msg["content"]
        assert "Fix the auth bug" in task_msg["content"]

    def test_build_post_compaction_reminder_with_shared_memory(self, tmp_path: Path):
        """Verify shared + agent MEMORY.md both appear in compaction reminders."""
        (tmp_path / "MEMORY.md").write_text("Agent fact: X=1", encoding="utf-8")
        shared_dir = tmp_path / "memory" / "shared"
        shared_dir.mkdir(parents=True)
        (shared_dir / "MEMORY.md").write_text("Shared fact: Y=2", encoding="utf-8")

        msgs = build_post_compaction_reminder("Bot", tmp_path, "task")

        # Should have 3 messages: shared memory + agent memory + task reminder
        assert len(msgs) == 3
        assert "[Post-Compaction Shared Memory Reload]" in msgs[0]["content"]
        assert "Y=2" in msgs[0]["content"]
        assert "[Post-Compaction Memory Reload]" in msgs[1]["content"]
        assert "X=1" in msgs[1]["content"]
        assert "[Post-Compaction Reminder]" in msgs[2]["content"]

    def test_build_post_compaction_reminder_no_memory_file(self, tmp_path: Path):
        """Without MEMORY.md, only the task reminder is returned."""
        msgs = build_post_compaction_reminder("Bot", tmp_path, "Deploy app")

        assert len(msgs) == 1
        assert "[Post-Compaction Reminder]" in msgs[0]["content"]
        assert "Deploy app" in msgs[0]["content"]
