"""Tests for OpenAI provider runtime fallback behavior."""

from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import patch

import pytest
from pydantic import SecretStr

from workpilot.config.schema import GitHubCopilotConfig, ProviderConfig, ProvidersConfig
from workpilot.providers.openai_provider import OpenAIProvider


class _FakeStream:
    def __init__(self, chunks):
        self._chunks = chunks

    def __aiter__(self):
        return self

    async def __anext__(self):
        if not self._chunks:
            raise StopAsyncIteration
        return self._chunks.pop(0)


class _FailingStream:
    def __aiter__(self):
        return self

    async def __anext__(self):
        raise RuntimeError("stream failed before first chunk")


@pytest.mark.asyncio
async def test_complete_falls_back_to_next_model_on_error():
    providers = ProvidersConfig(openai=ProviderConfig(api_key=SecretStr("sk-test")))
    provider = OpenAIProvider(providers)
    calls: list[str] = []

    class _FakeCompletions:
        async def create(self, **kwargs):
            model = kwargs["model"]
            calls.append(model)
            if model == "o1":
                raise RuntimeError("primary model failed")
            return SimpleNamespace(
                choices=[
                    SimpleNamespace(
                        message=SimpleNamespace(content="fallback ok", tool_calls=[]),
                        finish_reason="stop",
                    )
                ],
                usage=SimpleNamespace(prompt_tokens=3, completion_tokens=2),
                model=f"openai/{model}",
            )

    fake_client = SimpleNamespace(chat=SimpleNamespace(completions=_FakeCompletions()))

    with patch.object(OpenAIProvider, "_build_client", return_value=fake_client):
        response = await provider.complete(
            model="reasoning",
            messages=[{"role": "user", "content": "hello"}],
        )

    assert response.content == "fallback ok"
    assert response.model == "openai/gpt-4o"
    assert calls == ["o1", "gpt-4o"]


@pytest.mark.asyncio
async def test_stream_falls_back_when_stream_creation_fails():
    providers = ProvidersConfig(openai=ProviderConfig(api_key=SecretStr("sk-test")))
    provider = OpenAIProvider(providers)
    calls: list[str] = []

    class _FakeCompletions:
        async def create(self, **kwargs):
            model = kwargs["model"]
            calls.append(model)
            if model == "o1":
                raise RuntimeError("stream primary failed")
            chunk = SimpleNamespace(
                choices=[
                    SimpleNamespace(
                        delta=SimpleNamespace(content="hi"),
                        finish_reason="stop",
                    )
                ],
                model=f"openai/{model}",
            )
            return _FakeStream([chunk])

    fake_client = SimpleNamespace(chat=SimpleNamespace(completions=_FakeCompletions()))

    with patch.object(OpenAIProvider, "_build_client", return_value=fake_client):
        chunks = []
        async for chunk in provider.stream(
            model="reasoning",
            messages=[{"role": "user", "content": "hello"}],
        ):
            chunks.append(chunk)

    assert [c.content for c in chunks] == ["hi"]
    assert chunks[0].model == "openai/gpt-4o"
    assert calls == ["o1", "gpt-4o"]


@pytest.mark.asyncio
async def test_auto_switches_gpt54_to_responses_api():
    providers = ProvidersConfig(
        github_copilot=GitHubCopilotConfig(token=SecretStr("")),
        openai=ProviderConfig(api_key=SecretStr("sk-test")),
    )
    provider = OpenAIProvider(providers)
    calls: list[tuple[str, str]] = []

    class _FakeChatCompletions:
        async def create(self, **kwargs):
            calls.append(("chat", kwargs["model"]))
            raise RuntimeError(
                'Error code: 400 - {"error": {"message": "model "gpt-5.4" is not accessible via the /chat/completions endpoint", "code": "unsupported_api_for_model"}}'
            )

    class _FakeResponses:
        async def create(self, **kwargs):
            calls.append(("responses", kwargs["model"]))
            return SimpleNamespace(
                model="github/gpt-5.4",
                output_text="ok via responses",
                output=[],
                usage=SimpleNamespace(input_tokens=2, output_tokens=3),
            )

    fake_client = SimpleNamespace(
        chat=SimpleNamespace(completions=_FakeChatCompletions()),
        responses=_FakeResponses(),
    )

    with (
        patch(
            "workpilot.providers.openai_provider.resolve_credentials",
            return_value={"api_key": "test"},
        ),
        patch.object(OpenAIProvider, "_build_client", return_value=fake_client),
    ):
        response = await provider.complete(
            model="github/gpt-5.4",
            messages=[{"role": "user", "content": "hello"}],
        )

    assert response.content == "ok via responses"
    assert response.model == "github/gpt-5.4"
    assert calls == [("responses", "gpt-5.4")]


@pytest.mark.asyncio
async def test_responses_api_parses_function_calls_and_message_text():
    providers = ProvidersConfig(
        github_copilot=GitHubCopilotConfig(token=SecretStr("")),
        openai=ProviderConfig(api_key=SecretStr("sk-test")),
    )
    provider = OpenAIProvider(providers)

    function_call = SimpleNamespace(
        type="function_call",
        call_id="call_1",
        name="lookup_user",
        arguments='{"uid": "42"}',
    )
    message_part = SimpleNamespace(type="output_text", text="assistant text")
    message_item = SimpleNamespace(type="message", content=[message_part])

    class _FakeResponses:
        async def create(self, **kwargs):
            return SimpleNamespace(
                model="github/gpt-5.4",
                output_text="",
                output=[function_call, message_item],
                usage=SimpleNamespace(input_tokens=9, output_tokens=4),
            )

    fake_client = SimpleNamespace(
        chat=SimpleNamespace(completions=SimpleNamespace(create=None)),
        responses=_FakeResponses(),
    )

    with (
        patch(
            "workpilot.providers.openai_provider.resolve_credentials",
            return_value={"api_key": "test"},
        ),
        patch.object(OpenAIProvider, "_build_client", return_value=fake_client),
    ):
        response = await provider.complete(
            model="github/gpt-5.4",
            messages=[{"role": "user", "content": "hello"}],
        )

    assert response.content == "assistant text"
    assert response.model == "github/gpt-5.4"
    assert response.prompt_tokens == 9
    assert response.completion_tokens == 4
    assert len(response.tool_calls) == 1
    assert response.tool_calls[0].name == "lookup_user"
    assert response.tool_calls[0].arguments == {"uid": "42"}


@pytest.mark.asyncio
async def test_stream_falls_back_when_first_stream_breaks_before_output():
    providers = ProvidersConfig(openai=ProviderConfig(api_key=SecretStr("sk-test")))
    provider = OpenAIProvider(providers)

    class _FirstCompletions:
        async def create(self, **kwargs):
            return _FailingStream()

    class _SecondCompletions:
        async def create(self, **kwargs):
            chunk = SimpleNamespace(
                choices=[
                    SimpleNamespace(
                        delta=SimpleNamespace(content="fallback stream ok"),
                        finish_reason="stop",
                    )
                ],
                model="openai/gpt-4o",
            )
            return _FakeStream([chunk])

    first_client = SimpleNamespace(chat=SimpleNamespace(completions=_FirstCompletions()))
    second_client = SimpleNamespace(chat=SimpleNamespace(completions=_SecondCompletions()))

    def _client_for_model(resolved_model: str, creds: dict[str, str]):
        del creds
        if resolved_model == "openai/o1":
            return first_client
        return second_client

    with (
        patch(
            "workpilot.providers.openai_provider.resolve_credentials",
            return_value={"api_key": "test"},
        ),
        patch(
            "workpilot.providers.openai_provider.resolve_model_chain",
            return_value=["openai/o1", "openai/gpt-4o"],
        ),
        patch.object(OpenAIProvider, "_build_client", side_effect=_client_for_model),
    ):
        chunks = []
        async for chunk in provider.stream(
            model="reasoning",
            messages=[{"role": "user", "content": "hello"}],
        ):
            chunks.append(chunk)

    assert len(chunks) == 1
    assert chunks[0].content == "fallback stream ok"
    assert chunks[0].model == "openai/gpt-4o"
