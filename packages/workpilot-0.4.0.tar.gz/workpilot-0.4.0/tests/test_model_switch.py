"""Tests for /model slash command — mid-session model switching.

Covers:
- /model with no arg returns current model
- /model <alias> switches when credentials are configured
- /model <alias> rejects with helpful message when no credentials
- /model <concrete-id> always succeeds (validated at call time)
- Switched model is used by subsequent LLM calls
"""

from __future__ import annotations

import os
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from pydantic import SecretStr

from workpilot.agent.loop import AgentLoop
from workpilot.agent.tools.registry import ToolRegistry
from workpilot.bus.queue import MessageBus
from workpilot.config.schema import (
    AgentConfig,
    GitHubCopilotConfig,
    ProvidersConfig,
)
from workpilot.providers.base import LLMProvider
from workpilot.security.audit import AuditLogger
from workpilot.session.manager import SessionManager

# ── Fixtures ──────────────────────────────────────────────────────────────────


def _make_loop(model: str = "auto", providers: ProvidersConfig | None = None) -> AgentLoop:
    config = AgentConfig(name="test", model=model)
    provider = MagicMock(spec=LLMProvider)
    provider._providers = providers or ProvidersConfig()
    registry = MagicMock(spec=ToolRegistry)
    registry.list_tools.return_value = []
    bus = MagicMock(spec=MessageBus)
    sessions = MagicMock(spec=SessionManager)
    sessions.get_messages.return_value = []
    audit = MagicMock(spec=AuditLogger)
    return AgentLoop(
        config=config,
        provider=provider,
        tool_registry=registry,
        bus=bus,
        session_manager=sessions,
        audit=audit,
        workspace=Path("/tmp"),
    )


def _providers_with_github() -> ProvidersConfig:
    p = ProvidersConfig()
    p.github_copilot = GitHubCopilotConfig(token=SecretStr("ghp_test"))
    return p


# ── Tests ─────────────────────────────────────────────────────────────────────


class TestModelCommand:
    @pytest.mark.asyncio
    async def test_no_arg_returns_current_model(self):
        loop = _make_loop(model="auto")
        result = await loop._handle_slash("/model", "sess1", MagicMock())
        assert result == "Current model: `auto`"

    @patch.dict(os.environ, {}, clear=True)
    @pytest.mark.asyncio
    async def test_switch_alias_with_credentials(self):
        loop = _make_loop(model="auto", providers=_providers_with_github())
        result = await loop._handle_slash("/model fast", "sess1", MagicMock())
        assert "fast" in result
        assert loop._config.model == "fast"

    @patch.dict(os.environ, {}, clear=True)
    @pytest.mark.asyncio
    async def test_switch_shows_resolved_model(self):
        loop = _make_loop(model="auto", providers=_providers_with_github())
        result = await loop._handle_slash("/model fast", "sess1", MagicMock())
        # Resolved model (e.g. github/gpt-5-mini) should appear in suffix
        assert "resolves to" in result

    @patch.dict(os.environ, {}, clear=True)
    @pytest.mark.asyncio
    async def test_switch_alias_no_credentials_returns_error(self):
        loop = _make_loop(model="auto")  # no credentials
        result = await loop._handle_slash("/model fast", "sess1", MagicMock())
        assert result is not None
        assert "Cannot switch" in result
        assert loop._config.model == "auto"  # unchanged

    @patch.dict(os.environ, {}, clear=True)
    @pytest.mark.asyncio
    async def test_switch_concrete_id_always_succeeds(self):
        # resolve_model_chain returns [model] for non-alias IDs regardless of
        # credentials (aliases like "fast" return [] when no creds configured).
        loop = _make_loop(model="auto")  # no credentials
        result = await loop._handle_slash("/model github/gpt-5.4", "sess1", MagicMock())
        assert loop._config.model == "github/gpt-5.4"
        assert "switched" in result.lower()

    @pytest.mark.asyncio
    async def test_switch_persists_across_new_session(self):
        loop = _make_loop(model="auto", providers=_providers_with_github())
        await loop._handle_slash("/model fast", "sess1", MagicMock())
        assert loop._config.model == "fast"

        # /new clears session history but model remains
        await loop._handle_slash("/new", "sess1", MagicMock())
        assert loop._config.model == "fast"

    @pytest.mark.asyncio
    async def test_status_shows_switched_model(self):
        loop = _make_loop(model="auto", providers=_providers_with_github())
        await loop._handle_slash("/model fast", "sess1", MagicMock())
        result = await loop._handle_slash("/status", "sess1", MagicMock())
        assert "fast" in result

    @pytest.mark.asyncio
    async def test_switched_model_passed_to_provider(self):
        """Verify the new model name is actually used in subsequent LLM calls."""
        from unittest.mock import AsyncMock

        from workpilot.providers.base import LLMResponse

        loop = _make_loop(model="auto", providers=_providers_with_github())
        loop._provider.complete = AsyncMock(
            return_value=LLMResponse(
                content="ok",
                tool_calls=[],
                finish_reason="stop",
                model="github/gpt-5-mini",
                prompt_tokens=1,
                completion_tokens=1,
            )
        )

        await loop._handle_slash("/model fast", "sess1", MagicMock())
        assert loop._config.model == "fast"

        # Trigger an LLM call and verify the provider is called with the new model
        await loop.run_once("hello", session_id="sess1")

        assert loop._provider.complete.called
        called_model = loop._provider.complete.call_args[1].get("model")
        assert called_model == "fast"


class TestResponsesInput:
    """Unit tests for _responses_input cross-model tool call conversion."""

    def test_tool_message_becomes_function_call_output(self):
        from workpilot.providers.openai_provider import _responses_input

        messages = [
            {"role": "tool", "tool_call_id": "toolu_vrtx_abc", "content": "file contents"},
        ]
        result = _responses_input(messages)
        assert len(result) == 1
        assert result[0]["type"] == "function_call_output"
        assert result[0]["call_id"] == "toolu_vrtx_abc"
        assert result[0]["output"] == "file contents"

    def test_assistant_tool_calls_become_function_call_items(self):
        from workpilot.providers.openai_provider import _responses_input

        messages = [
            {
                "role": "assistant",
                "content": "",
                "tool_calls": [
                    {
                        "id": "toolu_vrtx_abc",
                        "function": {"name": "read_file", "arguments": '{"path": "foo.py"}'},
                    }
                ],
            },
        ]
        result = _responses_input(messages)
        assert len(result) == 1
        assert result[0]["type"] == "function_call"
        assert result[0]["call_id"] == "toolu_vrtx_abc"
        assert result[0]["name"] == "read_file"

    def test_function_call_output_paired_with_function_call(self):
        """Cross-model scenario: Anthropic call_id paired with OpenAI Responses API."""
        from workpilot.providers.openai_provider import _responses_input

        messages = [
            {
                "role": "assistant",
                "content": "",
                "tool_calls": [
                    {"id": "toolu_vrtx_01TPW", "function": {"name": "shell", "arguments": "{}"}}
                ],
            },
            {"role": "tool", "tool_call_id": "toolu_vrtx_01TPW", "content": "output"},
        ]
        result = _responses_input(messages)
        assert result[0]["type"] == "function_call"
        assert result[0]["call_id"] == "toolu_vrtx_01TPW"
        assert result[1]["type"] == "function_call_output"
        assert result[1]["call_id"] == "toolu_vrtx_01TPW"

    def test_assistant_with_tool_calls_drops_orphan_text(self):
        """Tool-call turns with text content: text is dropped to avoid non-standard shape."""
        from workpilot.providers.openai_provider import _responses_input

        messages = [
            {
                "role": "assistant",
                "content": "I will read the file",
                "tool_calls": [
                    {"id": "call_abc", "function": {"name": "read_file", "arguments": "{}"}}
                ],
            },
        ]
        result = _responses_input(messages)
        # Only function_call items, no orphan assistant text item
        assert all(item.get("type") == "function_call" for item in result)
