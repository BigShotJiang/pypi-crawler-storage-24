"""Tests for MCP transport abstractions (StdioTransport, HttpTransport)."""

from workpilot.mcp.transport import HttpTransport, StdioTransport

# ── Transport abstractions ───────────────────────────────────────────────────


class TestStdioTransport:
    def test_initialization(self):
        transport = StdioTransport("node", args=["server.js"])
        assert transport._command == "node"
        assert transport._args == ["server.js"]

    def test_default_args(self):
        transport = StdioTransport("python")
        assert transport._args == []

    def test_is_running_false_initially(self):
        transport = StdioTransport("echo")
        assert transport.is_running is False


class TestHttpTransport:
    def test_initialization(self):
        transport = HttpTransport("https://mcp.example.com/api")
        assert transport._url == "https://mcp.example.com/api"

    def test_url_trailing_slash_stripped(self):
        transport = HttpTransport("https://mcp.example.com/api/")
        assert transport._url == "https://mcp.example.com/api"

    def test_headers_stored(self):
        transport = HttpTransport(
            "https://mcp.example.com/api",
            headers={"Authorization": "Bearer token123"},
        )
        assert transport._headers["Authorization"] == "Bearer token123"

    def test_default_headers_empty(self):
        transport = HttpTransport("https://mcp.example.com/api")
        assert transport._headers == {}

    def test_parse_sse_event_valid(self):
        block = 'data: {"jsonrpc": "2.0", "id": 1, "result": {}}'
        result = HttpTransport._parse_sse_event(block)
        assert result is not None
        assert result["jsonrpc"] == "2.0"

    def test_parse_sse_event_multiline(self):
        block = 'data: {"jsonrpc": "2.0",\ndata:  "id": 1,\ndata:  "result": {}}'
        # Multi-line data merging: lines are joined
        result = HttpTransport._parse_sse_event(block)
        assert result is not None

    def test_parse_sse_event_no_data(self):
        block = "event: ping"
        result = HttpTransport._parse_sse_event(block)
        assert result is None

    def test_parse_sse_event_invalid_json(self):
        block = "data: not-valid-json"
        result = HttpTransport._parse_sse_event(block)
        assert result is None
