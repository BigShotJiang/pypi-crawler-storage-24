"""
Gateway tool tests — exercise ALL 9 built-in tools via the HTTP API.

Each test sends a directive prompt through /v1/chat/completions that
forces the agent to use a specific tool, then verifies the response
contains evidence the tool ran correctly.

Tools tested:
  1. shell        — execute shell command
  2. read_file    — read file contents
  3. write_file   — create / write file
  4. edit_file    — replace string in file
  5. list_dir     — list directory contents
  6. git          — run git command
  7. http_request — make HTTP request
  8. message      — send message to bus
  9. spawn        — spawn sub-agent

Requires: gateway running on localhost:3003 with API key.
"""

from __future__ import annotations

import time

import httpx
import pytest

# ── Config ───────────────────────────────────────────────────────────────────

BASE = "http://localhost:3003"
API_KEY: str | None = None
TIMEOUT = 90  # LLM calls can take a while

# Load API key from local config or env (never hard-coded)
try:
    import os
    from pathlib import Path

    import yaml

    _local = Path(__file__).resolve().parents[1] / "workpilot.local.yaml"
    if _local.exists():
        _raw = yaml.safe_load(_local.read_text())
        API_KEY = (_raw.get("gateway") or {}).get("api_key")
    if not API_KEY:
        API_KEY = os.environ.get("WORKPILOT_GATEWAY_API_KEY", "")
except Exception:
    pass


def _gateway_reachable() -> bool:
    try:
        return httpx.get(f"{BASE}/health", timeout=3).status_code == 200
    except Exception:
        return False


pytestmark = pytest.mark.skipif(
    not _gateway_reachable(),
    reason=f"Gateway not running at {BASE}",
)


# ── Helper ───────────────────────────────────────────────────────────────────


def chat(prompt: str) -> str:
    """Send a prompt through the OpenAI-compatible endpoint and return the response text."""
    r = httpx.post(
        f"{BASE}/v1/chat/completions",
        headers={"X-API-Key": API_KEY, "Content-Type": "application/json"},
        json={
            "messages": [{"role": "user", "content": prompt}],
            "model": "auto",
        },
        timeout=TIMEOUT,
    )
    assert r.status_code == 200, f"API returned {r.status_code}: {r.text}"
    body = r.json()
    content = body["choices"][0]["message"]["content"]
    return content


# ═══════════════════════════════════════════════════════════════════════════════
# 1. shell — execute a command
# ═══════════════════════════════════════════════════════════════════════════════


class TestShellTool:
    def test_echo(self) -> None:
        """Agent uses shell tool to run echo."""
        resp = chat(
            "Use the shell tool to run this exact command: echo WORKPILOT_SHELL_TEST_1749\n"
            "Then reply with ONLY the output of the command, nothing else."
        )
        assert "WORKPILOT_SHELL_TEST_1749" in resp

    def test_python_version(self) -> None:
        """Agent uses shell tool to check Python version."""
        resp = chat(
            "Use the shell tool to run: python --version\nReply with the exact version string."
        )
        assert "Python" in resp or "python" in resp


# ═══════════════════════════════════════════════════════════════════════════════
# 2. read_file — read file contents
# ═══════════════════════════════════════════════════════════════════════════════


class TestReadFileTool:
    def test_read_existing_file(self) -> None:
        """Agent reads a known file."""
        resp = chat(
            "Use the read_file tool to read the file 'pyproject.toml'.\n"
            "Tell me: what is the project name defined in it? Reply with just the name."
        )
        assert "workpilot" in resp.lower()

    def test_read_nonexistent_file(self) -> None:
        """Agent handles missing file gracefully."""
        resp = chat(
            "Use the read_file tool to read 'this_file_does_not_exist_xyz.txt'.\n"
            "What happened? Reply briefly."
        )
        assert "not found" in resp.lower() or "error" in resp.lower() or "exist" in resp.lower()


# ═══════════════════════════════════════════════════════════════════════════════
# 3. write_file — create a file
# ═══════════════════════════════════════════════════════════════════════════════


class TestWriteFileTool:
    def test_write_and_verify(self) -> None:
        """Agent creates a file, then confirms it exists."""
        tag = f"test_{int(time.time())}"
        resp = chat(
            f"Do these two steps:\n"
            f"1. Use write_file to create '.workpilot/test/{tag}.txt' "
            f"with content 'GATEWAY_WRITE_TEST_{tag}'\n"
            f"2. Use read_file to read it back and show the content.\n"
            f"Reply with the file content you read."
        )
        assert tag in resp


# ═══════════════════════════════════════════════════════════════════════════════
# 4. edit_file — replace string in file
# ═══════════════════════════════════════════════════════════════════════════════


class TestEditFileTool:
    def test_edit_string_replacement(self) -> None:
        """Agent writes a file, edits it, and reads back."""
        tag = f"edit_{int(time.time())}"
        resp = chat(
            f"Do these three steps:\n"
            f"1. Use write_file to create '.workpilot/test/{tag}.txt' "
            f"with content 'color is red'\n"
            f"2. Use edit_file to replace 'red' with 'blue' in that file\n"
            f"3. Use read_file to read the file back\n"
            f"Reply with the final content of the file."
        )
        assert "blue" in resp.lower()


# ═══════════════════════════════════════════════════════════════════════════════
# 5. list_dir — directory listing
# ═══════════════════════════════════════════════════════════════════════════════


class TestListDirTool:
    def test_list_workspace(self) -> None:
        """Agent lists files in workspace root."""
        resp = chat(
            "Use the list_dir tool to list the files in the current directory (path '.').\n"
            "Reply with just the file and folder names you see."
        )
        # Should see standard project files
        assert "workpilot" in resp.lower() or "pyproject" in resp.lower() or "tests" in resp.lower()


# ═══════════════════════════════════════════════════════════════════════════════
# 6. git — version control
# ═══════════════════════════════════════════════════════════════════════════════


class TestGitTool:
    def test_git_status(self) -> None:
        """Agent runs git status."""
        resp = chat(
            "Use the git tool with args 'status' to check the git status.\n"
            "Reply with what branch we are on."
        )
        assert "main" in resp.lower() or "branch" in resp.lower()

    def test_git_log(self) -> None:
        """Agent runs git log."""
        resp = chat(
            "Use the git tool with args 'log --oneline -3'.\n"
            "Reply with the 3 most recent commit messages."
        )
        # Should contain some commit info
        assert len(resp) > 20  # Non-trivial response


# ═══════════════════════════════════════════════════════════════════════════════
# 7. http_request — make HTTP request
# ═══════════════════════════════════════════════════════════════════════════════


class TestHttpRequestTool:
    def test_get_request(self) -> None:
        """Agent makes an HTTP GET request."""
        resp = chat(
            "Use the http_request tool to make a GET request to https://httpbin.org/get\n"
            "Reply with the HTTP status code you received."
        )
        assert "200" in resp

    def test_post_request(self) -> None:
        """Agent makes an HTTP POST request."""
        resp = chat(
            "Use the http_request tool to POST to https://httpbin.org/post "
            'with body \'{"test":"workpilot"}\' and Content-Type: application/json header.\n'
            "Reply with whether the request succeeded (status 200)."
        )
        assert "200" in resp or "success" in resp.lower()


# ═══════════════════════════════════════════════════════════════════════════════
# 8. message — cross-channel messaging
# ═══════════════════════════════════════════════════════════════════════════════


class TestMessageTool:
    def test_send_cli_message(self) -> None:
        """Agent sends a message via the message bus."""
        resp = chat(
            "Use the message tool to send a message to the 'cli' channel "
            "with content 'GATEWAY_MSG_TEST_OK'.\n"
            "Reply confirming whether the message was sent successfully."
        )
        assert "sent" in resp.lower() or "success" in resp.lower() or "cli" in resp.lower()


# ═══════════════════════════════════════════════════════════════════════════════
# 9. spawn — sub-agent delegation
# ═══════════════════════════════════════════════════════════════════════════════


class TestSpawnTool:
    def test_spawn_explorer(self) -> None:
        """Agent spawns the built-in explorer sub-agent."""
        resp = chat(
            "Use the spawn tool to spawn the 'explorer' agent in 'serial' mode "
            "with the prompt 'List the files in the workspace root directory'.\n"
            "Reply with what the explorer found."
        )
        # Should get directory listing from the explorer
        assert len(resp) > 20  # Non-trivial response


# ═══════════════════════════════════════════════════════════════════════════════
# Combined: multi-tool workflow
# ═══════════════════════════════════════════════════════════════════════════════


class TestMultiToolWorkflow:
    def test_write_read_edit_read(self) -> None:
        """Agent chains write → read → edit → read across 4 tool calls."""
        tag = f"multi_{int(time.time())}"
        resp = chat(
            f"Complete this 4-step workflow:\n"
            f"1. write_file: create '.workpilot/test/{tag}.txt' with 'alpha beta gamma'\n"
            f"2. read_file: read it back to confirm\n"
            f"3. edit_file: replace 'beta' with 'BETA' in the file\n"
            f"4. read_file: read again and show the final content\n"
            f"Reply with the final file content after all 4 steps."
        )
        assert "BETA" in resp

    def test_shell_and_git(self) -> None:
        """Agent chains shell + git in one conversation."""
        resp = chat(
            "Do two things:\n"
            "1. Use the shell tool to run 'echo MULTI_TOOL_CHECK'\n"
            "2. Use the git tool with args 'log --oneline -1'\n"
            "Reply with both results."
        )
        assert "MULTI_TOOL_CHECK" in resp or "commit" in resp.lower()
