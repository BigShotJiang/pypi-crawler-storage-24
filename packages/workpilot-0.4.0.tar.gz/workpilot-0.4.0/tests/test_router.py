"""Tests for model alias resolution in provider router."""

import os
from unittest.mock import patch

import pytest
from pydantic import SecretStr

from workpilot.config.schema import (
    GitHubCopilotConfig,
    ModelAlias,
    ModelRouting,
    ProviderConfig,
    ProvidersConfig,
)
from workpilot.providers.router import resolve_model, resolve_model_chain


def _providers(**kwargs) -> ProvidersConfig:
    """Create a ProvidersConfig with specified keys set."""
    p = ProvidersConfig()
    if "openai" in kwargs:
        p.openai = ProviderConfig(api_key=SecretStr(kwargs["openai"]))
    if "github" in kwargs:
        p.github_copilot = GitHubCopilotConfig(token=SecretStr(kwargs["github"]))
    if "aliases" in kwargs:
        p.aliases = kwargs["aliases"]
    if "routing" in kwargs:
        p.routing = kwargs["routing"]
    return p


class TestResolveModelConcreteIds:
    def test_concrete_model_returned_as_is(self):
        assert resolve_model("openai/gpt-4o") == "openai/gpt-4o"

    def test_concrete_model_ignores_providers(self):
        p = _providers(openai="sk-test")
        assert resolve_model("openai/gpt-4o", p) == "openai/gpt-4o"


class TestAutoAlias:
    @patch.dict(os.environ, {}, clear=True)
    def test_auto_resolves_to_first_available(self):
        p = _providers(openai="sk-test")
        result = resolve_model("auto", p)
        assert result.startswith("openai/")

    @patch.dict(os.environ, {}, clear=True)
    def test_auto_prefers_github_over_openai(self):
        p = _providers(github="ghp_test", openai="sk-test")
        result = resolve_model("auto", p)
        assert result.startswith("github/")

    @patch.dict(os.environ, {}, clear=True)
    def test_auto_fallback_when_no_credentials(self):
        p = ProvidersConfig()
        with pytest.raises(ValueError):
            resolve_model("auto", p)

    @patch.dict(os.environ, {}, clear=True)
    def test_auto_no_providers_arg(self):
        with pytest.raises(ValueError):
            resolve_model("auto", None)


class TestFastAlias:
    @patch.dict(os.environ, {}, clear=True)
    def test_fast_prefers_mini_models(self):
        p = _providers(openai="sk-test")
        result = resolve_model("fast", p)
        assert "mini" in result.lower()

    @patch.dict(os.environ, {}, clear=True)
    def test_fast_github_prefers_mini(self):
        p = _providers(github="ghp_test")
        result = resolve_model("fast", p)
        assert "mini" in result

    @patch.dict(os.environ, {}, clear=True)
    def test_fast_falls_back_to_default(self):
        p = ProvidersConfig()
        with pytest.raises(ValueError):
            resolve_model("fast", p)


class TestReasoningAlias:
    @patch.dict(os.environ, {}, clear=True)
    def test_reasoning_openai_prefers_o1(self):
        p = _providers(openai="sk-test")
        result = resolve_model("reasoning", p)
        assert "o1" in result

    @patch.dict(os.environ, {}, clear=True)
    def test_reasoning_fallback(self):
        p = ProvidersConfig()
        with pytest.raises(ValueError):
            resolve_model("reasoning", p)


class TestCodingAlias:
    @patch.dict(os.environ, {}, clear=True)
    def test_coding_uses_auto_candidates(self):
        p = _providers(openai="sk-test")
        result = resolve_model("coding", p)
        # coding uses same candidates as auto
        assert result.startswith("openai/")


class TestUserConfiguredAliases:
    @patch.dict(os.environ, {}, clear=True)
    def test_alias_override_in_config(self):
        aliases = ModelAlias(fast="openai/gpt-4o-mini")
        p = _providers(openai="sk-test", aliases=aliases)
        result = resolve_model("fast", p)
        assert result == "openai/gpt-4o-mini"

    @patch.dict(os.environ, {}, clear=True)
    def test_alias_auto_falls_through(self):
        aliases = ModelAlias(fast="auto")  # default
        p = _providers(openai="sk-test", aliases=aliases)
        result = resolve_model("fast", p)
        # "auto" in alias → falls through to fast-specific auto-resolution
        assert "mini" in result.lower()

    @patch.dict(os.environ, {}, clear=True)
    def test_all_aliases_configurable(self):
        aliases = ModelAlias(
            default="openai/gpt-4o",
            fast="openai/gpt-4o-mini",
            reasoning="openai/o1",
            coding="openai/gpt-4o",
        )
        p = _providers(aliases=aliases)
        assert resolve_model("auto", p) == "openai/gpt-4o"
        assert resolve_model("fast", p) == "openai/gpt-4o-mini"
        assert resolve_model("reasoning", p) == "openai/o1"
        assert resolve_model("coding", p) == "openai/gpt-4o"

    @patch.dict(os.environ, {}, clear=True)
    def test_alias_list_supports_ordered_fallback(self):
        aliases = ModelAlias(fast=["github/gpt-5-mini", "github/claude-haiku-4.5", "openai:fast"])
        p = _providers(github="ghp_test", openai="sk-test", aliases=aliases)

        chain = resolve_model_chain("fast", p)
        assert chain[:3] == [
            "github/gpt-5-mini",
            "github/claude-haiku-4.5",
            "openai/gpt-4o-mini",
        ]

    @patch.dict(os.environ, {}, clear=True)
    def test_alias_list_can_embed_auto(self):
        aliases = ModelAlias(default=["github/gpt-5.2", "auto"])
        p = _providers(github="ghp_test", openai="sk-test", aliases=aliases)

        chain = resolve_model_chain("auto", p)
        assert chain[0] == "github/gpt-5.2"
        assert "github/gpt-5.4" in chain


class TestResolveModelChain:
    @patch.dict(os.environ, {}, clear=True)
    def test_chain_contains_ordered_failover_candidates(self):
        p = _providers(github="ghp_test", openai="sk-test")
        chain = resolve_model_chain("auto", p)

        assert chain[0] == "github/gpt-5.4"
        assert "github/gpt-5.2" in chain
        assert any(m.startswith("openai/") or m.startswith("azure/") for m in chain)
        assert chain[-1] == "openai/gpt-4o"

    @patch.dict(os.environ, {}, clear=True)
    def test_chain_supports_alias_to_alias_mapping(self):
        aliases = ModelAlias(default="fast")
        p = _providers(github="ghp_test", openai="sk-test", aliases=aliases)

        chain = resolve_model_chain("auto", p)
        assert chain[0] in {"github/gpt-5-mini", "openai/gpt-4o-mini", "azure/gpt-4o-mini"}
        assert "openai/gpt-4o" in chain

    @patch.dict(os.environ, {}, clear=True)
    def test_no_openai_fallback_when_openai_key_missing(self):
        p = _providers(github="ghp_test")
        chain = resolve_model_chain("fast", p)
        assert "openai/gpt-4o" not in chain

    @patch.dict(os.environ, {}, clear=True)
    def test_fast_chain_stays_fast_tier_before_ultimate_fallback(self):
        p = _providers(github="ghp_test", openai="sk-test")
        chain = resolve_model_chain("fast", p)

        assert chain[:3] == [
            "github/gpt-5-mini",
            "github/claude-haiku-4.5",
            "openai/gpt-4o-mini",
        ]
        assert "github/gpt-5.4" not in chain
        assert "github/gpt-5.2" not in chain
        assert chain[-1] == "openai/gpt-4o"


class TestConfiguredRoutingCandidates:
    @patch.dict(os.environ, {}, clear=True)
    def test_default_chain_can_be_configured(self):
        routing = ModelRouting(default_candidates=["github/gpt-5.2", "github/gpt-5.4"])
        p = _providers(github="ghp_test", openai="sk-test", routing=routing)

        chain = resolve_model_chain("auto", p)
        assert chain[0] == "github/gpt-5.2"
        assert chain[1] == "github/gpt-5.4"

    @patch.dict(os.environ, {}, clear=True)
    def test_fast_chain_can_be_configured(self):
        routing = ModelRouting(fast_candidates=["openai:fast", "github/gpt-5-mini"])
        p = _providers(github="ghp_test", openai="sk-test", routing=routing)

        chain = resolve_model_chain("fast", p)
        assert chain[0] == "openai/gpt-4o-mini"
        assert "github/gpt-5-mini" in chain
