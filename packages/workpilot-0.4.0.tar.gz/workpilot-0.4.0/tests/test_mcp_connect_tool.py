"""Tests for the unified MCPConnectTool with progressive loading."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, PropertyMock, patch

import pytest

from workpilot.agent.tools.mcp_connect import MCPConnectTool
from workpilot.agent.tools.registry import ToolRegistry
from workpilot.config.schema import MCPServerConfig
from workpilot.mcp.manager import MCPManager


def _cfg(**kwargs: Any) -> MCPServerConfig:
    return MCPServerConfig(command="agency", args=["mcp", "icm"], **kwargs)


def _descriptors(*names: str) -> list[dict[str, Any]]:
    return [
        {
            "name": n,
            "description": f"Tool {n}",
            "inputSchema": {
                "type": "object",
                "properties": {"id": {"type": "string"}},
                "required": ["id"],
            },
        }
        for n in names
    ]


async def _agency_ok() -> tuple[bool, str]:
    return True, "ok"


_PATCH_AGENCY = patch("workpilot.mcp.manager.pre_connect_agency_check", side_effect=_agency_ok)


def _patch_client(descriptors: list[dict[str, Any]] | None = None):
    mock_cls = patch("workpilot.mcp.manager.MCPClient")

    def _setup(mc):
        inst = AsyncMock()
        type(inst).is_connected = PropertyMock(return_value=True)
        type(inst).name = PropertyMock(return_value="test")
        inst.list_tools = AsyncMock(return_value=descriptors or [])
        inst.call_tool = AsyncMock(return_value="result")
        inst.list_resources = AsyncMock(return_value=[])
        inst.list_prompts = AsyncMock(return_value=[])
        inst.read_resource = AsyncMock(return_value="resource content")
        inst.get_prompt = AsyncMock(return_value="rendered prompt")
        # capabilities property
        type(inst).capabilities = PropertyMock(
            return_value=type(
                "C",
                (),
                {
                    "tools": True,
                    "resources": False,
                    "prompts": False,
                    "streaming": False,
                    "logging": False,
                    "list_changed": False,
                },
            )()
        )
        mc.return_value = inst
        return inst

    return mock_cls, _setup


class TestMetadata:
    def test_name(self) -> None:
        tool = MCPConnectTool(manager=MCPManager({}, ToolRegistry()))
        assert tool.name == "mcp_connect"

    def test_approval_never(self) -> None:
        tool = MCPConnectTool(manager=MCPManager({}, ToolRegistry()))
        assert tool.metadata.approval == "never"

    def test_parameters_include_all_fields(self) -> None:
        tool = MCPConnectTool(manager=MCPManager({}, ToolRegistry()))
        props = tool.parameters["properties"]
        assert set(props.keys()) == {"server", "action", "filter", "uri", "prompt", "arguments"}
        assert set(props["action"]["enum"]) == {
            "connect",
            "describe",
            "disconnect",
            "status",
            "resources",
            "prompts",
        }


class TestListServers:
    @pytest.mark.asyncio
    async def test_no_args_lists_servers(self) -> None:
        configs = {"icm": _cfg(), "kusto": MCPServerConfig(command="agency", args=["mcp", "kusto"])}
        tool = MCPConnectTool(manager=MCPManager(configs, ToolRegistry()))

        result = await tool.execute()

        assert "MCP servers (2)" in result
        assert "icm" in result
        assert "kusto" in result

    @pytest.mark.asyncio
    async def test_no_servers_configured(self) -> None:
        tool = MCPConnectTool(manager=MCPManager({}, ToolRegistry()))
        result = await tool.execute()
        assert "No MCP servers configured" in result


class TestConnect:
    @pytest.mark.asyncio
    async def test_connect_small_server_auto_describes(self) -> None:
        """≤5 tools → connect returns full tool signatures (auto-describe)."""
        configs = {"icm": _cfg()}
        registry = ToolRegistry()
        tool = MCPConnectTool(manager=MCPManager(configs, registry))

        mock_cls, setup = _patch_client(_descriptors("get_incident", "list_incidents"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            result = await tool.execute(server="icm")

        # Should auto-describe (≤5 tools)
        assert "MCP_icm-get_incident" in result
        assert "MCP_icm-list_incidents" in result
        # Tools should be registered
        assert registry.get("MCP_icm-get_incident") is not None

    @pytest.mark.asyncio
    async def test_connect_large_server_returns_summary(self) -> None:
        """
        >5 tools → connect returns summary, not full signatures.
        """
        configs = {"icm": _cfg()}
        tool = MCPConnectTool(manager=MCPManager(configs, ToolRegistry()))

        many_tools = _descriptors(*[f"tool_{i}" for i in range(10)])
        mock_cls, setup = _patch_client(many_tools)
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            result = await tool.execute(server="icm")

        # Summary, not full signatures
        assert "Tools: 10" in result
        assert "describe" in result

    @pytest.mark.asyncio
    async def test_connect_is_default_action(self) -> None:
        configs = {"icm": _cfg()}
        tool = MCPConnectTool(manager=MCPManager(configs, ToolRegistry()))

        mock_cls, setup = _patch_client(_descriptors("t"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            result = await tool.execute(server="icm")

        # Should succeed (no action = connect)
        assert "icm" in result


class TestDescribe:
    @pytest.mark.asyncio
    async def test_describe_auto_connects(self) -> None:
        """describe on unconnected server auto-connects first."""
        configs = {"icm": _cfg()}
        registry = ToolRegistry()
        tool = MCPConnectTool(manager=MCPManager(configs, registry))

        mock_cls, setup = _patch_client(_descriptors("get_incident"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            result = await tool.execute(server="icm", action="describe")

        assert "MCP_icm-get_incident" in result
        assert registry.get("MCP_icm-get_incident") is not None

    @pytest.mark.asyncio
    async def test_describe_with_filter(self) -> None:
        configs = {"icm": _cfg()}
        tool = MCPConnectTool(manager=MCPManager(configs, ToolRegistry()))

        mock_cls, setup = _patch_client(
            _descriptors("get_incident", "list_incidents", "create_user")
        )
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            result = await tool.execute(server="icm", action="describe", filter="incident")

        assert "MCP_icm-get_incident" in result
        assert "MCP_icm-list_incidents" in result
        assert "MCP_icm-create_user" not in result

    @pytest.mark.asyncio
    async def test_describe_unknown_server(self) -> None:
        tool = MCPConnectTool(manager=MCPManager({}, ToolRegistry()))
        result = await tool.execute(server="nonexistent", action="describe")
        assert "Unknown" in result


class TestResources:
    @pytest.mark.asyncio
    async def test_read_resource(self) -> None:
        configs = {"icm": _cfg()}
        mgr = MCPManager(configs, ToolRegistry())
        tool = MCPConnectTool(manager=mgr)

        mock_cls, setup = _patch_client(_descriptors("t"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            await tool.execute(server="icm")  # connect
            result = await tool.execute(server="icm", action="resources", uri="icm://schema")

        assert "resource content" in result

    @pytest.mark.asyncio
    async def test_resources_no_uri_shows_describe(self) -> None:
        """resources without uri → falls back to describe (lists resources)."""
        configs = {"icm": _cfg()}
        tool = MCPConnectTool(manager=MCPManager(configs, ToolRegistry()))

        mock_cls, setup = _patch_client(_descriptors("t"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            result = await tool.execute(server="icm", action="resources")

        # Should show describe output (which includes resources section)
        assert "MCP server 'icm'" in result


class TestPrompts:
    @pytest.mark.asyncio
    async def test_get_prompt(self) -> None:
        configs = {"icm": _cfg()}
        mgr = MCPManager(configs, ToolRegistry())
        tool = MCPConnectTool(manager=mgr)

        mock_cls, setup = _patch_client(_descriptors("t"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            await tool.execute(server="icm")  # connect
            result = await tool.execute(
                server="icm",
                action="prompts",
                prompt="triage",
                arguments={"severity": "2"},
            )

        assert "rendered prompt" in result

    @pytest.mark.asyncio
    async def test_prompts_no_name_shows_describe(self) -> None:
        configs = {"icm": _cfg()}
        tool = MCPConnectTool(manager=MCPManager(configs, ToolRegistry()))

        mock_cls, setup = _patch_client(_descriptors("t"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            result = await tool.execute(server="icm", action="prompts")

        assert "MCP server 'icm'" in result


class TestOther:
    @pytest.mark.asyncio
    async def test_disconnect_action(self) -> None:
        configs = {"icm": _cfg()}
        registry = ToolRegistry()
        mgr = MCPManager(configs, registry)
        tool = MCPConnectTool(manager=mgr)

        mock_cls, setup = _patch_client(_descriptors("get_incident"))
        with mock_cls as mc, _PATCH_AGENCY:
            setup(mc)
            await tool.execute(server="icm", action="describe")  # connect + register

        assert registry.get("MCP_icm-get_incident") is not None
        result = await tool.execute(server="icm", action="disconnect")

        assert "Disconnected" in result
        assert registry.get("MCP_icm-get_incident") is None

    @pytest.mark.asyncio
    async def test_status_action(self) -> None:
        configs = {"icm": _cfg()}
        tool = MCPConnectTool(manager=MCPManager(configs, ToolRegistry()))
        result = await tool.execute(server="icm", action="status")
        assert "icm" in result
        assert "idle" in result

    @pytest.mark.asyncio
    async def test_unknown_action(self) -> None:
        configs = {"icm": _cfg()}
        tool = MCPConnectTool(manager=MCPManager(configs, ToolRegistry()))
        result = await tool.execute(server="icm", action="invalid")
        assert "Unknown action" in result
