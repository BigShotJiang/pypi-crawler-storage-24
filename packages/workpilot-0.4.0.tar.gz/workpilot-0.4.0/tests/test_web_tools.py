"""Tests for WebSearchTool and WebFetchTool."""

from __future__ import annotations

import time
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from workpilot.agent.tools.web import (
    WebFetchTool,
    WebSearchTool,
    _FetchCache,
    _validate_url,
)

# ── SSRF validation tests ────────────────────────────────────────────────────


class TestValidateUrl:
    @pytest.mark.asyncio
    async def test_rejects_non_http_scheme(self):
        with pytest.raises(ValueError, match="not allowed"):
            await _validate_url("ftp://example.com")

    @pytest.mark.asyncio
    async def test_rejects_userinfo(self):
        with pytest.raises(ValueError, match="user:password"):
            await _validate_url("http://user:pass@example.com")

    @pytest.mark.asyncio
    async def test_rejects_localhost(self):
        with pytest.raises(ValueError, match="SSRF"):
            await _validate_url("http://localhost/admin")

    @pytest.mark.asyncio
    async def test_rejects_metadata_internal(self):
        with pytest.raises(ValueError, match="SSRF"):
            await _validate_url("http://metadata.google.internal/v1/")

    @pytest.mark.asyncio
    async def test_rejects_private_ip(self):
        with pytest.raises(ValueError, match="SSRF"):
            await _validate_url("http://192.168.1.1/")

    @pytest.mark.asyncio
    async def test_rejects_loopback_ip(self):
        with pytest.raises(ValueError, match="SSRF"):
            await _validate_url("http://127.0.0.1/secret")

    @pytest.mark.asyncio
    async def test_rejects_link_local(self):
        with pytest.raises(ValueError, match="SSRF"):
            await _validate_url("http://169.254.169.254/latest/meta-data/")

    @pytest.mark.asyncio
    async def test_rejects_internal_suffix(self):
        with pytest.raises(ValueError, match="SSRF"):
            await _validate_url("http://evil.internal/api")

    @pytest.mark.asyncio
    async def test_accepts_public_url(self):
        # Should not raise for a public hostname
        # (DNS resolution may fail in CI, but the hostname/IP checks pass)
        try:
            await _validate_url("https://example.com")
        except ValueError:
            pytest.fail("Public URL should not be blocked")


# ── WebSearchTool tests ──────────────────────────────────────────────────────

_SAMPLE_DDG_HTML = """
<div class="result results_links results_links_deep web-result">
  <div class="result__body">
    <h2 class="result__title">
      <a class="result__a" href="https://example.com/page1">Example Page One</a>
    </h2>
    <a class="result__snippet" href="https://example.com/page1">This is the first snippet</a>
  </div>
</div>
<div class="result results_links results_links_deep web-result">
  <div class="result__body">
    <h2 class="result__title">
      <a class="result__a" href="https://example.com/page2">Example Page Two</a>
    </h2>
    <a class="result__snippet" href="https://example.com/page2">This is the second snippet</a>
  </div>
</div>
"""


class TestWebSearchTool:
    def setup_method(self):
        # Reset rate limiter between tests
        WebSearchTool._last_request_time = 0.0

    def test_properties(self):
        tool = WebSearchTool()
        assert tool.name == "web_search"
        assert tool.metadata.risk_level == "medium"
        assert tool.metadata.approval == "auto"
        assert tool.metadata.timeout == 30
        assert "query" in tool.parameters["required"]

    @pytest.mark.asyncio
    async def test_empty_query(self):
        tool = WebSearchTool()
        result = await tool.execute(query="   ")
        assert "Error" in result

    @pytest.mark.asyncio
    async def test_search_success_regex(self):
        """Test search with regex parser (no bs4)."""
        tool = WebSearchTool()

        mock_response = MagicMock()
        mock_response.text = _SAMPLE_DDG_HTML
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.get = AsyncMock(return_value=mock_response)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with (
            patch("workpilot.agent.tools.web.httpx.AsyncClient", return_value=mock_client),
            patch.dict("sys.modules", {"bs4": None}),
        ):
            result = await tool.execute(query="test query", count=2)

        assert "Example Page One" in result
        assert "example.com/page1" in result
        assert "first snippet" in result

    @pytest.mark.asyncio
    async def test_search_success_bs4(self):
        """Test search with BeautifulSoup parser."""
        tool = WebSearchTool()

        mock_response = MagicMock()
        mock_response.text = _SAMPLE_DDG_HTML
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.get = AsyncMock(return_value=mock_response)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("workpilot.agent.tools.web.httpx.AsyncClient", return_value=mock_client):
            # Import bs4 to check if available; if not, skip
            try:
                import bs4  # noqa: F401

                result = await tool.execute(query="test query", count=2)
                assert "Example Page One" in result
                assert "example.com/page1" in result
            except ImportError:
                pytest.skip("beautifulsoup4 not installed")

    @pytest.mark.asyncio
    async def test_search_no_results(self):
        tool = WebSearchTool()

        mock_response = MagicMock()
        mock_response.text = "<html><body>No results</body></html>"
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.get = AsyncMock(return_value=mock_response)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("workpilot.agent.tools.web.httpx.AsyncClient", return_value=mock_client):
            result = await tool.execute(query="xyznonexistent")

        assert "No results" in result

    @pytest.mark.asyncio
    async def test_search_timeout(self):
        tool = WebSearchTool()

        mock_client = AsyncMock()
        mock_client.get = AsyncMock(side_effect=httpx.TimeoutException("timeout"))
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("workpilot.agent.tools.web.httpx.AsyncClient", return_value=mock_client):
            result = await tool.execute(query="test")

        assert "timed out" in result

    @pytest.mark.asyncio
    async def test_search_count_clamped(self):
        """Count should be clamped to max 10."""
        tool = WebSearchTool()

        mock_response = MagicMock()
        mock_response.text = _SAMPLE_DDG_HTML
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.get = AsyncMock(return_value=mock_response)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("workpilot.agent.tools.web.httpx.AsyncClient", return_value=mock_client):
            result = await tool.execute(query="test", count=100)

        # Should still work — just clamped to 10 internally
        assert "test" in result.lower() or "Example" in result

    def test_openai_schema(self):
        tool = WebSearchTool()
        schema = tool.to_openai_schema()
        assert schema["type"] == "function"
        assert schema["function"]["name"] == "web_search"
        assert "query" in schema["function"]["parameters"]["properties"]


# ── WebFetchTool tests ───────────────────────────────────────────────────────


class TestWebFetchTool:
    def test_properties(self):
        tool = WebFetchTool()
        assert tool.name == "web_fetch"
        assert tool.metadata.risk_level == "medium"
        assert tool.metadata.approval == "auto"
        assert tool.metadata.timeout == 60
        assert "url" in tool.parameters["required"]

    @pytest.mark.asyncio
    async def test_rejects_non_http(self):
        tool = WebFetchTool()
        result = await tool.execute(url="ftp://example.com/file")
        assert "Error" in result

    @pytest.mark.asyncio
    async def test_rejects_ssrf(self):
        tool = WebFetchTool()
        result = await tool.execute(url="http://169.254.169.254/latest/meta-data/")
        assert "Error" in result
        assert "SSRF" in result

    @pytest.mark.asyncio
    async def test_fetch_html_content(self):
        tool = WebFetchTool()

        sample_html = """
        <html>
        <head><title>Test Page</title></head>
        <body>
            <nav>Navigation</nav>
            <main><h1>Hello World</h1><p>This is a test paragraph.</p></main>
            <footer>Footer</footer>
        </body>
        </html>
        """

        mock_response = MagicMock()
        mock_response.text = sample_html
        mock_response.content = sample_html.encode()
        mock_response.is_redirect = False
        mock_response.status_code = 200
        mock_response.headers = {"content-type": "text/html; charset=utf-8"}
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.get = AsyncMock(return_value=mock_response)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("workpilot.agent.tools.web.httpx.AsyncClient", return_value=mock_client):
            result = await tool.execute(url="https://example.com")

        assert "[UNTRUSTED_CONTENT]" in result
        assert "[/UNTRUSTED_CONTENT]" in result
        assert "Hello World" in result

    @pytest.mark.asyncio
    async def test_fetch_json_content(self):
        tool = WebFetchTool()

        mock_response = MagicMock()
        mock_response.text = '{"key": "value"}'
        mock_response.content = b'{"key": "value"}'
        mock_response.is_redirect = False
        mock_response.json.return_value = {"key": "value"}
        mock_response.status_code = 200
        mock_response.headers = {"content-type": "application/json"}
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.get = AsyncMock(return_value=mock_response)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("workpilot.agent.tools.web.httpx.AsyncClient", return_value=mock_client):
            result = await tool.execute(url="https://api.example.com/data")

        assert "[UNTRUSTED_CONTENT]" in result
        assert '"key"' in result
        assert '"value"' in result

    @pytest.mark.asyncio
    async def test_fetch_plain_text(self):
        tool = WebFetchTool()

        mock_response = MagicMock()
        mock_response.text = "Plain text content here"
        mock_response.content = b"Plain text content here"
        mock_response.is_redirect = False
        mock_response.status_code = 200
        mock_response.headers = {"content-type": "text/plain"}
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.get = AsyncMock(return_value=mock_response)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("workpilot.agent.tools.web.httpx.AsyncClient", return_value=mock_client):
            result = await tool.execute(url="https://example.com/file.txt")

        assert "Plain text content here" in result

    @pytest.mark.asyncio
    async def test_fetch_timeout(self):
        tool = WebFetchTool()

        mock_client = AsyncMock()
        mock_client.get = AsyncMock(side_effect=httpx.TimeoutException("timeout"))
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("workpilot.agent.tools.web.httpx.AsyncClient", return_value=mock_client):
            result = await tool.execute(url="https://slow.example.com")

        assert "timed out" in result

    @pytest.mark.asyncio
    async def test_fetch_truncation(self):
        tool = WebFetchTool()

        long_text = "x" * 30_000
        mock_response = MagicMock()
        mock_response.text = long_text
        mock_response.content = long_text.encode()
        mock_response.is_redirect = False
        mock_response.status_code = 200
        mock_response.headers = {"content-type": "text/plain"}
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.get = AsyncMock(return_value=mock_response)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("workpilot.agent.tools.web.httpx.AsyncClient", return_value=mock_client):
            result = await tool.execute(url="https://example.com/big", max_chars=100)

        assert "truncated" in result

    def test_openai_schema(self):
        tool = WebFetchTool()
        schema = tool.to_openai_schema()
        assert schema["type"] == "function"
        assert schema["function"]["name"] == "web_fetch"
        assert "url" in schema["function"]["parameters"]["properties"]
        assert "selector" in schema["function"]["parameters"]["properties"]


# ── FetchCache tests ─────────────────────────────────────────────────────────


class TestFetchCache:
    @pytest.mark.asyncio
    async def test_put_and_get(self):
        cache = _FetchCache(ttl=60.0, max_entries=10)
        await cache.put("key1", "value1")
        assert await cache.get("key1") == "value1"

    @pytest.mark.asyncio
    async def test_get_missing(self):
        cache = _FetchCache()
        assert await cache.get("nonexistent") is None

    @pytest.mark.asyncio
    async def test_ttl_expiry(self):
        cache = _FetchCache(ttl=0.01)  # 10ms TTL
        await cache.put("key1", "value1")
        time.sleep(0.02)
        assert await cache.get("key1") is None

    @pytest.mark.asyncio
    async def test_max_entries_eviction(self):
        cache = _FetchCache(ttl=60.0, max_entries=2)
        await cache.put("k1", "v1")
        await cache.put("k2", "v2")
        await cache.put("k3", "v3")
        # k1 should have been evicted (oldest)
        assert await cache.get("k1") is None
        assert await cache.get("k2") == "v2"
        assert await cache.get("k3") == "v3"

    @pytest.mark.asyncio
    async def test_clear(self):
        cache = _FetchCache()
        await cache.put("k1", "v1")
        await cache.clear()
        assert await cache.get("k1") is None
