"""
Gateway API integration tests — test every endpoint against a RUNNING gateway.

Start the gateway first:  python -m workpilot serve --port 3003

Tests exercise:
 1. Public endpoints (no API key)
 2. Auth rejection (missing/bad API key → 401)
 3. Auth success (X-API-Key, Bearer, query param)
 4. /api/tools — tool discovery
 5. /api/sessions — session management
 6. /api/health — detailed health
 7. /api/estop + /api/reset — emergency stop lifecycle
 8. /v1/chat/completions — OpenAI-compatible (real LLM call)
 9. /api/chat — prompt via bus (real LLM call)
10. /webhooks/{channel} — webhook receiver
11. /api/ws — WebSocket chat (real LLM call)
"""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

import httpx
import pytest

# ── Config ───────────────────────────────────────────────────────────────────

BASE = "http://localhost:3003"
API_KEY: str | None = None

# Load API key from local config or env (never hard-coded)
try:
    import yaml

    _local = Path(__file__).resolve().parents[1] / "workpilot.local.yaml"
    if _local.exists():
        _raw = yaml.safe_load(_local.read_text())
        API_KEY = (_raw.get("gateway") or {}).get("api_key")
except Exception:
    pass
if not API_KEY:
    import os

    API_KEY = os.environ.get("WORKPILOT_GATEWAY_API_KEY", "")


def auth_headers() -> dict[str, str]:
    return {"X-API-Key": API_KEY}


# ── Skip if gateway not running ──────────────────────────────────────────────


def _gateway_reachable() -> bool:
    try:
        r = httpx.get(f"{BASE}/health", timeout=3)
        return r.status_code == 200
    except Exception:
        return False


pytestmark = pytest.mark.skipif(
    not _gateway_reachable(),
    reason=f"Gateway not running at {BASE}. Start with: python -m workpilot serve",
)


# ═══════════════════════════════════════════════════════════════════════════════
# 1. Public endpoints (no API key needed)
# ═══════════════════════════════════════════════════════════════════════════════


class TestPublicEndpoints:
    def test_health(self) -> None:
        r = httpx.get(f"{BASE}/health", timeout=5)
        assert r.status_code == 200
        body = r.json()
        assert body["status"] == "ok"
        assert "version" in body

    def test_api_health(self) -> None:
        r = httpx.get(f"{BASE}/api/health", timeout=5)
        assert r.status_code == 200
        body = r.json()
        assert body["status"] == "ok"
        assert "estop" in body
        assert "bus" in body

    def test_auth_config(self) -> None:
        r = httpx.get(f"{BASE}/api/auth/config", timeout=5)
        assert r.status_code == 200
        body = r.json()
        assert "api_key_enabled" in body
        assert body["api_key_enabled"] is True

    def test_web_ui(self) -> None:
        r = httpx.get(f"{BASE}/", timeout=5)
        # 200 if chat.html exists, 404 with fallback HTML otherwise
        assert r.status_code in (200, 404)

    def test_docs(self) -> None:
        # /docs is behind auth (not in public paths)
        r = httpx.get(f"{BASE}/docs", headers=auth_headers(), timeout=5)
        assert r.status_code == 200
        assert "swagger" in r.text.lower() or "openapi" in r.text.lower()


# ═══════════════════════════════════════════════════════════════════════════════
# 2. Auth rejection
# ═══════════════════════════════════════════════════════════════════════════════


class TestAuthRejection:
    def test_no_key_401(self) -> None:
        r = httpx.get(f"{BASE}/api/tools", timeout=5)
        assert r.status_code == 401
        body = r.json()
        assert "Unauthorized" in body.get("error", "")

    def test_bad_key_401(self) -> None:
        r = httpx.get(
            f"{BASE}/api/tools",
            headers={"X-API-Key": "wrong-key"},
            timeout=5,
        )
        assert r.status_code == 401

    def test_bad_bearer_401(self) -> None:
        r = httpx.get(
            f"{BASE}/api/tools",
            headers={"Authorization": "Bearer invalid-token"},
            timeout=5,
        )
        assert r.status_code == 401


# ═══════════════════════════════════════════════════════════════════════════════
# 3. Auth success (multiple methods)
# ═══════════════════════════════════════════════════════════════════════════════


class TestAuthSuccess:
    def test_x_api_key_header(self) -> None:
        r = httpx.get(f"{BASE}/api/tools", headers={"X-API-Key": API_KEY}, timeout=5)
        assert r.status_code == 200

    def test_bearer_token(self) -> None:
        r = httpx.get(
            f"{BASE}/api/tools",
            headers={"Authorization": f"Bearer {API_KEY}"},
            timeout=5,
        )
        assert r.status_code == 200

    def test_query_param_key(self) -> None:
        r = httpx.get(f"{BASE}/api/tools?key={API_KEY}", timeout=5)
        assert r.status_code == 200


# ═══════════════════════════════════════════════════════════════════════════════
# 4. /api/tools — tool discovery
# ═══════════════════════════════════════════════════════════════════════════════


class TestToolsEndpoint:
    def test_list_tools(self) -> None:
        r = httpx.get(f"{BASE}/api/tools", headers=auth_headers(), timeout=5)
        assert r.status_code == 200
        tools = r.json()
        assert isinstance(tools, list)
        assert len(tools) >= 9

        names = {t["name"] for t in tools}
        assert "shell" in names
        assert "read_file" in names
        assert "write_file" in names
        assert "edit_file" in names
        assert "list_dir" in names
        assert "git" in names
        assert "http_request" in names
        assert "message" in names
        assert "spawn" in names

    def test_tool_metadata_shape(self) -> None:
        r = httpx.get(f"{BASE}/api/tools", headers=auth_headers(), timeout=5)
        tools = r.json()
        for t in tools:
            assert "name" in t
            assert "description" in t
            assert "risk_level" in t
            assert "approval" in t
            assert t["risk_level"] in ("low", "medium", "high", "critical")
            assert t["approval"] in ("never", "auto", "always")


# ═══════════════════════════════════════════════════════════════════════════════
# 5. /api/sessions — session management
# ═══════════════════════════════════════════════════════════════════════════════


class TestSessionsEndpoint:
    def test_list_sessions(self) -> None:
        r = httpx.get(f"{BASE}/api/sessions", headers=auth_headers(), timeout=5)
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_get_nonexistent_session(self) -> None:
        r = httpx.get(
            f"{BASE}/api/sessions/nonexistent-session-id",
            headers=auth_headers(),
            timeout=5,
        )
        assert r.status_code == 404

    def test_delete_session(self) -> None:
        r = httpx.delete(
            f"{BASE}/api/sessions/test-delete-session",
            headers=auth_headers(),
            timeout=5,
        )
        assert r.status_code == 200
        body = r.json()
        assert body["status"] == "deleted"


# ═══════════════════════════════════════════════════════════════════════════════
# 6. /api/health — detailed health
# ═══════════════════════════════════════════════════════════════════════════════


class TestDetailedHealth:
    def test_health_detail(self) -> None:
        r = httpx.get(f"{BASE}/api/health", timeout=5)
        assert r.status_code == 200
        body = r.json()
        assert body["status"] == "ok"
        assert "version" in body
        assert "estop" in body
        assert body["estop"]["halted"] is False
        assert "bus" in body
        assert "inbound_qsize" in body["bus"]
        assert "outbound_qsize" in body["bus"]


# ═══════════════════════════════════════════════════════════════════════════════
# 7. /api/estop + /api/reset — emergency stop lifecycle
# ═══════════════════════════════════════════════════════════════════════════════


class TestEStopLifecycle:
    def test_estop_trigger_and_reset(self) -> None:
        # Trigger E-stop
        r = httpx.post(
            f"{BASE}/api/estop",
            headers=auth_headers(),
            json={"reason": "API test"},
            timeout=5,
        )
        assert r.status_code == 200
        body = r.json()
        assert body["halted"] is True
        assert "API test" in body.get("reason", "")

        # Verify /api/health reflects halted state
        r2 = httpx.get(f"{BASE}/api/health", timeout=5)
        assert r2.json()["status"] == "halted"

        # Verify /api/tools is blocked with 503
        r3 = httpx.get(f"{BASE}/api/tools", headers=auth_headers(), timeout=5)
        assert r3.status_code == 503
        assert "E-stop" in r3.json().get("message", "")

        # Reset E-stop
        r4 = httpx.post(
            f"{BASE}/api/reset",
            headers=auth_headers(),
            json={"actor": "test-suite"},
            timeout=5,
        )
        assert r4.status_code == 200
        assert r4.json()["halted"] is False

        # Verify /api/tools works again
        r5 = httpx.get(f"{BASE}/api/tools", headers=auth_headers(), timeout=5)
        assert r5.status_code == 200

        # Verify health is ok
        r6 = httpx.get(f"{BASE}/api/health", timeout=5)
        assert r6.json()["status"] == "ok"


# ═══════════════════════════════════════════════════════════════════════════════
# 8. /webhooks/{channel} — webhook receiver
# ═══════════════════════════════════════════════════════════════════════════════


class TestWebhooks:
    def test_github_webhook(self) -> None:
        r = httpx.post(
            f"{BASE}/webhooks/github",
            headers=auth_headers(),
            json={"event": "push", "payload": {"ref": "refs/heads/main"}},
            timeout=30,
        )
        assert r.status_code == 200
        body = r.json()
        assert body["status"] == "accepted"
        assert body["channel"] == "github"

    def test_ado_webhook(self) -> None:
        r = httpx.post(
            f"{BASE}/webhooks/ado",
            headers=auth_headers(),
            json={"event": "workitem.updated", "payload": {"id": 42}},
            timeout=5,
        )
        assert r.status_code == 200
        assert r.json()["channel"] == "ado"

    def test_unknown_channel_404(self) -> None:
        r = httpx.post(
            f"{BASE}/webhooks/slack",
            headers=auth_headers(),
            json={"event": "message"},
            timeout=5,
        )
        assert r.status_code == 404


# ═══════════════════════════════════════════════════════════════════════════════
# 9. /v1/chat/completions — OpenAI-compatible (REAL LLM call)
# ═══════════════════════════════════════════════════════════════════════════════


class TestOpenAICompat:
    def test_chat_completion(self) -> None:
        """Real LLM call via OpenAI-compatible endpoint."""
        r = httpx.post(
            f"{BASE}/v1/chat/completions",
            headers={**auth_headers(), "Content-Type": "application/json"},
            json={
                "messages": [
                    {"role": "user", "content": "What is 2+2? Reply ONLY with the number."},
                ],
                "model": "auto",
            },
            timeout=60,
        )
        assert r.status_code == 200
        body = r.json()
        assert body["object"] == "chat.completion"
        assert len(body["choices"]) == 1
        content = body["choices"][0]["message"]["content"]
        assert content  # non-empty response
        assert "4" in content

    def test_missing_user_message_400(self) -> None:
        r = httpx.post(
            f"{BASE}/v1/chat/completions",
            headers={**auth_headers(), "Content-Type": "application/json"},
            json={"messages": [{"role": "system", "content": "You are helpful"}]},
            timeout=10,
        )
        assert r.status_code == 400

    def test_stream_not_supported(self) -> None:
        r = httpx.post(
            f"{BASE}/v1/chat/completions",
            headers={**auth_headers(), "Content-Type": "application/json"},
            json={
                "messages": [{"role": "user", "content": "hi"}],
                "stream": True,
            },
            timeout=10,
        )
        assert r.status_code == 400
        assert "stream" in r.json().get("message", "").lower()


# ═══════════════════════════════════════════════════════════════════════════════
# 10. /api/chat — prompt via bus (REAL LLM call)
# ═══════════════════════════════════════════════════════════════════════════════


class TestApiChat:
    def test_chat_prompt(self) -> None:
        """Real LLM call via /api/chat endpoint."""
        r = httpx.post(
            f"{BASE}/api/chat",
            headers={**auth_headers(), "Content-Type": "application/json"},
            json={"prompt": "What is the capital of France? Reply with just the city name."},
            timeout=90,
        )
        assert r.status_code == 200
        body = r.json()
        assert "response" in body
        assert "session_id" in body
        assert "Paris" in body["response"]


# ═══════════════════════════════════════════════════════════════════════════════
# 11. /api/ws — WebSocket chat (REAL LLM call)
# ═══════════════════════════════════════════════════════════════════════════════


class TestWebSocket:
    @pytest.mark.asyncio
    async def test_websocket_chat(self) -> None:
        """Real LLM call via WebSocket."""
        import websockets

        uri = f"ws://localhost:3003/api/ws?key={API_KEY}"
        async with websockets.connect(uri) as ws:
            await ws.send(
                json.dumps(
                    {
                        "prompt": "What is 3+3? Reply ONLY with the number.",
                        "sender_id": "test-ws",
                    }
                )
            )
            raw = await asyncio.wait_for(ws.recv(), timeout=60)
            msg = json.loads(raw)
            assert "response" in msg
            assert "6" in msg["response"]

    @pytest.mark.asyncio
    async def test_websocket_push_notification(self) -> None:
        """Schedule a reminder via WebSocket and verify push notification arrives.

        Flow: send prompt → agent calls cron tool → agent responds →
              ~10s later scheduler fires → push notification arrives on same WS.
        """
        import websockets

        uri = f"ws://localhost:3003/api/ws?key={API_KEY}"
        async with websockets.connect(uri) as ws:
            # Ask the agent to create a 10-second reminder
            await ws.send(
                json.dumps(
                    {
                        "prompt": (
                            "Use the cron tool to schedule a reminder in 10 seconds. "
                            "Use schedule='at:+10' and prompt='PUSH_TEST_PING'. "
                            "Use notify_channels=['*']. Do not explain, just call the tool."
                        ),
                        "sender_id": "test-push",
                    }
                )
            )

            # First message: the agent's response (may be empty — LLM sometimes
            # returns just whitespace after a tool call acknowledgment)
            raw = await asyncio.wait_for(ws.recv(), timeout=60)
            response = json.loads(raw)
            assert "response" in response, f"Expected response frame, got: {response}"

            # Wait for push notification from the scheduler (~10s later).
            # Keep connection open and collect messages until we see a push.
            push_received = False
            for _ in range(5):  # up to 5 recv attempts over ~20s
                try:
                    raw2 = await asyncio.wait_for(ws.recv(), timeout=20)
                    msg = json.loads(raw2)
                    if msg.get("type") == "push":
                        push_received = True
                        assert "PUSH_TEST_PING" in msg.get("content", "") or "Cron:" in msg.get(
                            "content", ""
                        ), f"Push content unexpected: {msg}"
                        break
                except TimeoutError:
                    break

            assert push_received, "No push notification received within timeout"


# ═══════════════════════════════════════════════════════════════════════════════
# Run directly
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    # Quick smoke test when run directly
    print(f"Testing gateway at {BASE} ...")
    print(f"API key: {API_KEY[:8]}...{API_KEY[-4:]}")

    if not _gateway_reachable():
        print(f"ERROR: Gateway not running at {BASE}")
        print("Start it with:  python -m workpilot serve --port 3003")
        sys.exit(1)

    # Run with pytest
    sys.exit(pytest.main([__file__, "-v", "--tb=short"]))
