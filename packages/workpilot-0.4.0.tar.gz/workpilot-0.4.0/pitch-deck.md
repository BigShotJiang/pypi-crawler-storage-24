# WorkPilot

## Not a copilot. An autopilot for your work.

**An autonomous AI assistant that codes, communicates, and ships across your entire Microsoft stack — proactively and securely.**

不是副驾驶，是自动驾驶。

> *3-minute pitch · M365 FHL 2026*

---

<!-- Slide 1: Title — 10 seconds -->
## Slide 1: WorkPilot

```
 __        __         _    ____  _ _       _
 \ \      / /__  _ __| | _|  _ \(_) | ___ | |_
  \ \ /\ / / _ \| '__| |/ / |_) | | |/ _ \| __|
   \ V  V / (_) | |  |   <|  __/| | | (_) | |_
    \_/\_/ \___/|_|  |_|\_\_|   |_|_|\___/ \__|
```

### Not a copilot. An autopilot for your work.

An autonomous AI assistant that codes, communicates, and ships across your entire Microsoft stack — proactively and securely.

> 安全的AI工作助理，自主处理任务，可以在手机或者其它电脑上与你主动交互.

---

<!-- Slide 2: The Problem — 30 seconds -->
## Slide 2: The Problem

### Today's AI tools are **reactive** — they wait for you to ask.

- **GitHub Copilot** helps you write code — but you trigger every suggestion **manually**, its memory resets every session, and it only knows what's in your current workspace. No cross-repo knowledge. No self-learning.
- **M365 Copilot** helps in Office... but it doesn't touch your dev workflow.
- These tools live in silos. Nobody connects the loop.

### More

> **Engineers spend 50%+ of their time on coordination, not creation.**
>
> 工程师超过50%的时间花在协调而非创造上。

Push code. Create PR. Post on Teams. Update ADO. Send email. Check CI. Fix build. Repeat.

Every day. Every engineer. Every team.

**Speaker notes:** *The coordination tax is real — and no current tool solves the full loop.*

---

<!-- Slide 3: WorkPilot — Autonomous, Not Just Assistive — 45 seconds -->
## Slide 3: WorkPilot — Autonomous, Not Just Assistive

### The key differentiator: **WorkPilot acts on its own.**

| Capability | What it means |
|---|---|
| **Proactive** | Wakes up on schedule, monitors ADO work items, checks build status, reminds about deadlines — *without being asked* |
| **End-to-end** | Doesn't just suggest code — it implements, tests, commits, creates PRs, posts Teams notifications, sends status emails |
| **Always-on** | Gateway mode runs 24/7 — listens on Teams, Outlook, GitHub, ADO webhooks |
| **Progressive autonomy** | 4 safety levels — from "suggest only" to "fully autonomous" — *you* control how far it goes |

### Example: A real workflow, zero human intervention

```
ADO work item assigned
    → WorkPilot wakes up
    → analyzes requirement
    → writes code
    → runs tests
    → creates PR
    → posts review request on Teams
    → monitors CI
    → auto-fixes if build fails
    → notifies you when done ✅
```

> 从任务分配到代码交付，全程自主完成。
> *From task assignment to code delivery — fully autonomous.*

**Speaker notes:** *This is the "aha" moment. Walk through the flow step by step. Emphasize: "At no point did a human type a command. WorkPilot saw the work item and drove it to completion." This is autopilot.*

---

<!-- Slide 4: How You Interact — 20 seconds -->
## Slide 4: How You Interact

### Phone + Teams Bot + Devbox — that's all you need

```
  ┌─────────────┐   Teams / BotFW   ┌──────────────────┐   ┌──────────────────────┐
  │   📱 You    │ ◄───────────────► │  🤖 Teams Bot    │   │   ☁ Cloud Triggers   │
  │  Phone /    │     ↑ 状态更新       │                  │   │  GitHub · ADO        │
  │  Laptop     │     ↑ 审批请求       └────────┬─────────┘   │  other · Webhooks  │
  │  anywhere   │     ↓ 指令                   │              └──────────┬───────────┘
  └─────────────┘                              └──────────────┬─webhook─┘
                                                              │
                        ┌─────────────── Devbox ─────────────▼──────────────────────────┐
                        │  ┌──────────────────────────────────┐  ┌──────────────────┐   │
                        │  │        ⚡ WorkPilot                │  │  🖥 Local Runtime  │   │
                        │  │        Agent Engine               │  │  CLI · Shell      │   │
                        │  │   10 Tools · Skills · Memory      │  │  bash · pwsh      │   │
                        │  └──────────────────────────────────┘  └──────────────────┘   │
                        └──────────────────────────────┬─────────────────────────────────┘
                                                       │
          ┌──────────┬──────────────┬──────────────────┴──────────────┬──────────────┐
          │          │              │                                 │              │
        HTTP      git push       LLM API                         Browser       Ext. MCP
          │          │              │                                 │              │
     ┌────▼─────┐ ┌──▼──────────┐ ┌─▼─────────────┐        ┌────────▼────┐ ┌────▼─────────┐
     │Azure·    │ │ADO · GitHub │ │  LLM (Cloud)  │        │  Web Pages  │ │External MCP │
     │Graph     │ │ (git push)  │ │               │        │(user login) │ │  Servers    │
     └──────────┘ └─────────────┘ └───────────────┘        └─────────────┘ └─────────────┘
```

> 你只需要一部手机。WorkPilot在Devbox上帮你完成剩下的一切。
> *You just need your phone. WorkPilot does the rest from your Devbox.*

**Speaker notes:** *展示实际交互模式。Teams Bot是双向通道：主动推送状态、请求审批、接收指令。WorkPilot通过HTTP连ADO和WebSearch，通过API调LLM，通过Agent/MCP连接浏览器、Git、Shell等工具。关键信息：你只需要一部手机。*

---

<!-- Slide 5: How It Works — Architecture — 30 seconds -->
## Slide 5: How It Works

### Architecture at a glance

```
┌─────────────────────────────────────────────────────┐
│                    CHANNELS                          │
│  CLI · Teams Bot · Outlook · GitHub · ADO · HTTP API │
└──────────────────────┬──────────────────────────────┘
                       │
┌──────────────────────▼──────────────────────────────┐
│                   GATEWAY                            │
│     FastAPI · Webhooks · OpenAI-compatible API        │
└──────────────────────┬──────────────────────────────┘
                       │
┌──────────────────────▼──────────────────────────────┐
│                 AGENT ENGINE                          │
│  LLM Loop · 10 Tools · Sub-agents · Skills · Memory  │
└──────────┬───────────────────────────┬──────────────┘
           │                           │
┌──────────▼──────────┐   ┌────────────▼──────────────┐
│   SECURITY LAYER    │   │    PROACTIVE LAYER         │
│ Sandbox · RBAC      │   │  Cron · Heartbeat          │
│ Audit · Approval    │   │  Scheduled tasks           │
└─────────────────────┘   └───────────────────────────┘
```

### Progressive Autonomy — 安全分级，渐进自主

| Level | Mode | Examples |
|---|---|---|
| **0 — Forbidden** | Always blocked | `rm -rf /` |
| **1 — Approval** | Human approves first | send emails, deploy |
| **2 — Notify** | Acts, then tells you | Push, PR creation |
| **3 — Autonomous** | Full autopilot | Reads, searches, analysis, code gen |

One-line config — enterprise-safe by default:

```yaml
security:
  profile: team    # That's it. Safe defaults out of the box.
```

**Speaker notes:** *Don't linger on architecture — the audience cares about what it does, not how. Hit two points: (1) it connects everything via channels, (2) the safety model means you're always in control. "You choose how autonomous it gets."*

---

<!-- Slide 6: Security — 25 seconds -->
## Slide 6: Enterprise Security

### Safety isn't a feature — it's the architecture.

```
┌─────────────────────────┐  ┌──────────────────────────┐  ┌───────────────────────────┐
│   🔐 权限控制              │  │   🔍 实时扫描               │  │   📋 定时审计               │
│   Access Control        │  │   Fast Scanning          │  │   Log Auditing            │
├─────────────────────────┤  ├──────────────────────────┤  ├───────────────────────────┤
│ 5 autonomy levels:      │  │ Every inbound message    │  │ Structured JSONL for:     │
│  0 = always blocked     │  │ scanned for:             │  │  · every tool call        │
│  1 = human approval     │  │  · Prompt injection      │  │  · every message in/out   │
│  1.5 = request, timeout │  │  · Secret leakage        │  │  · every security event   │
│      → auto-approve     │  │  · Log injection         │  │                           │
│  2 = notify then act    │  │                          │  │ Scheduled review:         │
│  3 = full autopilot     │  │ Auto-redaction:          │  │  · cron-triggered summary │
│                         │  │  JWT · API keys          │  │  · SIEM-ready output      │
│ RBAC PolicyEngine       │  │  GitHub PAT · OpenAI key │  │  · approval workflow      │
│ Per-channel allowlists  │  │  10 deny patterns        │  │  · tamper-evident log     │
│ Entra ID (MSAL) auth    │  │  Path restriction        │  │                           │
│ Command sandbox         │  │                          │  │                           │
└─────────────────────────┘  └──────────────────────────┘  └───────────────────────────┘
```

> 每一个操作都有迹可查，每一个风险都在第一时间拦截。
> *Every action is traceable. Every threat is intercepted at entry.*

**Speaker notes:** *三句话搞定这一页：(1) 权限是分级的，你决定AI走多远。(2) 每条消息进来都过一遍安全扫描——prompt注入、secret泄露、命令注入全拦。(3) 每次工具调用都有日志，定时汇总，可接SIEM。企业安全合规开箱即用。*

---

<!-- Slide 7: Memory & Skills — 25 seconds -->
## Slide 7: Memory & Skills

### WorkPilot gets smarter with every task.

```
┌─────────────────────────────────────────┐   ┌────────────────────────────────────────┐
│         🧠 两层记忆 · Dual-Layer Memory   │   │    ⚡ Skill 自动生成与优化                  │
│                                         │   │    Skill Auto-generation & Refinement  │
├─────────────────────────────────────────┤   ├────────────────────────────────────────┤
│                                         │   │                                        │
│  MEMORY.md ──── long-term facts         │   │  Task executes successfully            │
│  (project context, decisions, prefs)    │   │       ↓                                │
│                                         │   │  Pattern auto-extracted                │
│  HISTORY.md ─── searchable log          │   │       ↓                                │
│  (every task, outcome, command)         │   │  Skill saved as Markdown frontmatter   │
│                                         │   │       ↓                                │
│  📊 Auto-optimization (on overflow):    │   │  Reused & refined on next run          │
│    HISTORY.md ──► LLM analysis         │   │       ↓                                │
│      ├──► key facts → MEMORY.md        │   │  Skills compose into workflows (DAG)   │
│      └──► compress old entries         │   │                                        │
│                                         │   │  Bundled: GitHub · ADO · PR review     │
│  SQLite FTS5 · vector search            │   │  Office tasks · email · calendar       │
│  Persists across sessions & reboots     │   │                                        │
└─────────────────────────────────────────┘   └────────────────────────────────────────┘
```

> 不只是工具，是越用越懂你的工作伙伴。
> *Not just a tool — a partner that learns your workflow.*

**Speaker notes:** *记忆分两层：MEMORY.md存事实（项目背景、偏好、架构决策），HISTORY.md存历史（所有任务、结果、命令）。SQLite全文搜索+向量检索，跨session不丢失。Skills更厉害——任务成功后自动提取模式、生成Skill文件，下次直接复用，并根据结果持续优化。你用得越多，它越懂你。*

---

<!-- Slide 8: What We Built — 30 seconds -->
## Slide 8: What We Built

### Concrete numbers, working code

| Metric | Value |
|---|---|
| Python source files | **76** |
| Passing tests | **305** |
| Modules | **12** |
| Built-in tools | **10** |
| Lines of code | **~13,800** |

### Capabilities — shipping today

- **10 tools**: shell, file read/write/edit/list, git, HTTP, browser (Edge/Playwright), Graph API, cross-channel messaging, sub-agent spawning
- **Microsoft Graph**: read & send email, Teams messages — via Entra ID (MSAL)
- **MCP protocol**: connect any external tool server (stdio + HTTP/SSE)
- **LiteLLM routing**: 100+ LLM models — Azure OpenAI, Anthropic, OpenAI, local models
- **Skills system**: pluggable workflows — GitHub, ADO, code review, office tasks
- **Gateway mode**: OpenAI-compatible REST API — drop-in replacement for any client

> 76个源文件，305个测试，全部通过。这不是Demo，是可部署的产品。
> *76 source files, 305 tests, all passing. This isn't a demo — it's a deployable product.*

**Speaker notes:** *Rapid fire — let the numbers speak. Emphasize: "This is not a prototype. 305 tests passing. It works." Mention Graph integration — that's the Microsoft-native hook for this audience.*

---

<!-- Slide 7: Differentiation — 20 seconds -->
## Slide 7: Why WorkPilot?

### Head-to-head comparison

| Capability | GitHub Copilot | M365 Copilot | **WorkPilot** |
|---|:---:|:---:|:---:|
| Writes code | ✅ | ❌ | ✅ |
| Acts proactively — no manual trigger | ❌ | ❌ | ✅ |
| Memory persists across sessions | ❌ | ❌ | ✅ |
| Cross-repo / cross-project knowledge | ❌ | ❌ | ✅ |
| Self-learning from history | ❌ | ❌ | ✅ |
| Enterprise security built-in | Partial | ✅ | ✅ |
| Sends emails & Teams messages | ❌ | ❌ | ✅ |
| Monitors systems & acts on events | ❌ | ❌ | ✅ |
| **Connects dev + office in one agent** | ❌ | ❌ | **✅** |

> bridge **development** and **office productivity** in a single autonomous agent.
>
> 将开发和办公生产力融合在一个自主Agent中的工具。

**Speaker notes:** *Let the table do the talking. Point at the right column: "Every checkmark in one tool. That's WorkPilot." The key insight: no existing tool connects dev workflow with office workflow autonomously.*

---

<!-- Slide 8: Call to Action — 15 seconds -->
## Slide 8: Deploy Today

### Vision: Personal tool → Team deployment → Enterprise platform

**Roadmap:**
- **v0.1** (doing): Agent loop, 10 tools, Graph integration, security profiles, gateway
- **v0.2**: Full PR automation, email assistant, ADO work item lifecycle
- **v0.3**: Calendar management, SharePoint, monitoring dashboard

### Get started in 3 commands

```bash
pip install workpilot
workpilot init        # Interactive setup — connects your Azure, GitHub, ADO
workpilot chat          # Start your autonomous assistant
```

> 一个YAML文件，一条命令，部署到你的团队。
> *One YAML file. One command. Deploy to your team.*

### Not a copilot. An autopilot.

**Speaker notes:** *End strong. "Three commands. That's it. WorkPilot is ready." Leave with the tagline — "Not a copilot. An autopilot for your work." Thank the audience, open for questions.*

---

*Total estimated time: ~3 minutes (10s + 30s + 45s + 20s + 30s + 30s + 20s + 15s = 3:20)*
