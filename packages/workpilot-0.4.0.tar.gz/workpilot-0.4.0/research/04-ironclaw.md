# IronClaw (nearai/ironclaw) Research Report

> Last updated: 2026-02-27
> Repository: https://github.com/nearai/ironclaw
> Stars: ~3,700 | License: MIT OR Apache-2.0 | Language: Rust
> Website: https://www.ironclaw.com

---

## 1. Project Overview

IronClaw is a **privacy-and-security-first personal AI assistant** built in Rust, reimplementing OpenClaw's functionality. Developed by NEAR AI. Core motto: "Your AI assistant should work for you, not the other way around."

- Created: 2026-02-03
- Latest version: v0.12.0 (2026-02-26)
- Primary contributor: ilblackdragon (130 commits)
- Community: Telegram @ironclawAI, Reddit r/ironclawAI
- Iteration speed: v0.7.0 to v0.12.0 in one week

### Core Differentiators

- All data stored locally, encrypted, never leaves device
- Open source, auditable, no hidden telemetry
- Self-extending — can dynamically build new WASM tools
- Defense in depth — multi-layer security against prompt injection and data exfiltration

## 2. Technology Stack

| Layer | Technology |
|-------|-----------|
| Core language | Rust (Edition 2024, MSRV 1.92), ~91% of code |
| Async runtime | Tokio (full features) + futures |
| HTTP framework | Axum (Web Gateway) + Reqwest (HTTP client) |
| Database | PostgreSQL 15+ (pgvector for vector search), optional libSQL/Turso embedded |
| Serialization | Serde + serde_json + TOML |
| Sandbox | WebAssembly (wasmtime), capability-based permissions |
| CLI | Clap |
| Logging/Tracing | tracing + tracing-subscriber |
| Encryption | AES-256-GCM (keychain storage) |
| LLM interface | OpenAI-compatible API (NEAR AI, OpenRouter, Together AI, Fireworks, Ollama, vLLM, LiteLLM) |
| Web UI | JavaScript + CSS (embedded in Web Gateway) |
| Containerization | Docker + docker-compose (pgvector/pgvector:pg16) |
| Distribution | Homebrew, Windows MSI, Shell/PowerShell scripts, npm, Cargo |
| DB migrations | Refinery |
| TUI | Ratatui |
| WASM interfaces | WIT (WebAssembly Interface Types) |

## 3. Architecture

### Hub-and-Spoke Model

```
Channels (REPL / HTTP / WASM Channels / Web Gateway)
        |
   Agent Loop (intent routing)
    /          \
Scheduler     Routines Engine
(parallel)    (cron/event/webhook)
    |              |
    +------+-------+
           |
    Tool Registry
    (Built-in / MCP / WASM)
```

### Core Modules

| Module | Path | Responsibility |
|--------|------|---------------|
| Agent Loop | `src/agent/agent_loop.rs` | Main message processing, LLM -> tool calls -> LLM cycle |
| Router | `src/agent/router.rs` | User intent classification (command/query/task) |
| Scheduler | `src/agent/scheduler.rs` | Parallel task execution and priority management |
| Worker | `src/agent/worker.rs` | LLM inference + tool call execution |
| Orchestrator | `src/orchestrator/` | Docker container lifecycle, LLM proxy, per-job auth |
| Web Gateway | `src/channels/web/` | Browser UI (chat/memory/tasks/logs/extensions/routines), SSE + WebSocket streaming |
| Routines Engine | `src/agent/routine_engine.rs` | Cron + reactive (event/webhook) background tasks |
| Workspace | `src/workspace/` | Persistent memory, hybrid search (full-text + vector RRF) |
| Safety | `src/safety/` | Prompt injection defense + content sanitization |
| Sandbox | `src/sandbox/` | Docker container isolated execution |
| WASM Runtime | `src/tools/wasm/` | WASM sandbox runtime, capability-based permissions |
| Secrets | `src/secrets/` | AES-256-GCM encryption, system keychain integration |
| LLM | `src/llm/` | Multi-provider support, smart routing, circuit breaker, cost tracking |
| Skills | `src/skills/` | Composable multi-step skill system |

### Database Schema

9 migration files covering: initial tables, WASM security API, tool failure records, sandbox columns, Claude Code integration, routines system, event renaming, settings system, flexible embedding dimensions.

## 4. Core Features

### 4.1 WASM Sandbox (Key Innovation)

- Untrusted tools run in isolated WebAssembly containers
- **Capability-based permission model** (explicit opt-in for HTTP/secrets/tool calls)
- **Endpoint allowlists** (HTTP requests only to approved hosts/paths)
- **Credentials injected at host boundary** — never exposed to WASM code
- **Leak detection**: Scans requests/responses for secret exfiltration attempts
- **Rate limiting** + resource limits (memory, CPU, execution time)

### 4.2 Multi-Channel Support

Implemented channels:
- **REPL/TUI** — Ratatui terminal interface
- **HTTP Webhook** — Axum + secret verification
- **Web Gateway** — Browser UI, SSE + WebSocket real-time streaming
- **Telegram** — WASM channel (MTProto), DM pairing
- **Signal** — signal-cli HTTP daemon, user/group allowlists
- **Slack** — WASM tool
- **Discord** — WASM channel (latest addition)

Planned (P1-P3): WhatsApp, iMessage, Feishu/Lark, LINE, Matrix, MS Teams, Twitch, Voice Call, Nostr, etc.

### 4.3 Self-Extension

- **Dynamic tool building**: Describe requirements to build WASM tools on the fly
- **MCP protocol**: Connect to Model Context Protocol servers
- **Plugin architecture**: Hot-load WASM tools and channels without restart
- **WASM tool ecosystem**: GitHub, Gmail, Google Calendar/Docs/Drive/Sheets/Slides, Okta, Slack, Telegram

### 4.4 Persistent Memory

- **Hybrid search**: Full-text + vector search with Reciprocal Rank Fusion (RRF)
- **Workspace filesystem**: Flexible path-based storage (notes/logs/context)
- **Identity file**: Cross-session consistent personality and preferences
- **Memory cleaning**: Auto-cleanup integrated with heartbeat cycle

### 4.5 LLM Smart Routing

- Providers: NEAR AI, OpenRouter (300+ models), Together AI, Fireworks AI, Ollama (local), vLLM, LiteLLM
- **Smart routing** (`smart_routing.rs`): Cost-optimized model selection
- **Circuit breaker** (`circuit_breaker.rs`): Auto-failover on provider failure
- **Cost tracking** (`costs.rs`): Token usage and cost monitoring
- **Response cache** (`response_cache.rs`): LLM response caching
- **Auto-compression**: Automatic compression and retry on ContextLengthExceeded

### 4.6 Routines & Scheduling

- Cron scheduling, event triggers, webhook handling
- Heartbeat system: Proactive background execution, monitoring and maintenance
- Parallel tasks: Concurrent request handling with isolated contexts
- Self-healing: Auto-detect and recover stuck operations

### 4.7 Skills System

`src/skills/` includes: catalog, registry, parser, selector, gating, attenuation
- Composable multi-step workflow definitions
- Skill discovery and registration mechanisms

## 5. Latest Release — v0.12.0

- New Signal channel (native signal-cli HTTP) with tool approval workflow
- Web UI improvements: WASM channel setup flow, inline tool activity cards (auto-collapse), logs latest-first
- Added OpenRouter preset to settings wizard
- Fixed MCP registry URL, session thread parsing, Telegram/Slack name conflicts

### v0.10.0 Highlights

- TEE (Trusted Execution Environment) attestation shield
- Embedded registry catalog + WASM package install pipeline
- Docker sandbox Orchestrator/Worker mode
- Startup speed from ~15s to ~2s
- Smart routing provider (cost-optimized model selection)
- Token usage and cost tracking
- Hot-activate WASM channels

### Release Artifacts (Cross-Platform)

- macOS (aarch64 + x86_64)
- Linux (aarch64 + x86_64)
- Windows (x86_64, MSI installer)
- WASM channel/tool packages (Discord, Telegram, Slack, WhatsApp, GitHub, Gmail, Google suite, Okta)
- npm package

## 6. Relevance to WorkPilot

### 6.1 Highly Applicable Reference Points

| Area | IronClaw Approach | WorkPilot Current | Recommendation |
|------|-------------------|-------------------|----------------|
| Sandbox isolation | WASM sandbox + Docker dual-layer, capability-based | Command guards + path restriction | Consider WASM sandbox for fine-grained tool isolation |
| Credential security | Host-boundary injection + leak detection + AES-256-GCM | SecretStr + env vars + Azure Key Vault | **Adopt leak detection** (scan outbound requests for secret exfiltration) |
| Tool ecosystem | WASM hot-load + dynamic build + embedded registry | ToolRegistry + static registration | WASM plugin architecture significantly improves extensibility |
| Memory system | PostgreSQL + pgvector hybrid search (full-text + vector RRF) | MEMORY.md + HISTORY.md file-based | Vector search + RRF fusion significantly improves recall quality |
| LLM routing | Smart routing + circuit breaker + cost tracking + response cache | LiteLLM unified routing | **Circuit breaker** and **cost tracking** very practical for enterprise |
| Channel architecture | WASM channels hot-loadable, no restart needed | Static channel implementations | Hot-loading improves operational flexibility |
| Self-healing | Auto-detect stuck operations + recovery | None | Enterprise reliability essential |

### 6.2 WorkPilot's Differentiating Advantages

- **Microsoft ecosystem deep integration**: Graph API (mail/calendar/directory), Entra ID auth, Teams/Outlook channels — IronClaw has MS Teams as P3 (low priority)
- **Python ecosystem**: More mature for enterprise rapid development and data science integration
- **Security profiles**: solo/team/strict graduated security modes better fit enterprise multi-tenant needs
- **DAG workflow engine**: Declarative workflows more flexible for complex business processes

### 6.3 Specific Recommendations

1. **Leak detection**: Reference `leak_detector.rs` — scan tool HTTP outbound for sensitive data leakage
2. **Circuit breaker**: Add circuit breaker for LLM providers (`circuit_breaker.rs`) for multi-provider reliability
3. **Cost tracking**: Add token usage and cost tracking — critical for enterprise cost management
4. **Auto-compression**: Reference ContextLengthExceeded auto-compress mechanism
5. **Hybrid memory search**: pgvector + full-text + RRF as mature solution if upgrading persistence layer
6. **Heartbeat self-healing**: Add stuck operation detection and auto-recovery
7. **Tool approval workflow**: IronClaw's configurable human-in-the-loop approval aligns with WorkPilot's approval workflow concept — reference channel-level implementation
