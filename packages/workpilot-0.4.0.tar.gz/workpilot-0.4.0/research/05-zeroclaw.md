# ZeroClaw (zeroclaw-labs/zeroclaw) Research Report

> Last updated: 2026-02-27
> Repository: https://github.com/zeroclaw-labs/zeroclaw
> Stars: ~20,200 | License: MIT OR Apache-2.0 | Language: Rust
> Website: https://zeroclawlabs.ai

---

## 1. Project Overview

ZeroClaw is an **autonomous AI assistant infrastructure runtime OS** built by Harvard, MIT, and Sundai.Club community members. Core motto: "Zero overhead. Zero compromise. 100% Rust. 100% Agnostic."

- Created: 2026-02-13 (only 2 weeks old)
- Latest version: v0.1.7 (2026-02-24)
- Primary contributors: chumyin (699 commits), theonlyhennygod (280 commits), willsarg (123 commits)
- 20,000+ stars in 2 weeks — extremely rapid adoption

### Extreme Resource Efficiency

| Metric | ZeroClaw | OpenClaw/Claude Code |
|--------|----------|---------------------|
| Memory | <5MB RAM | >1GB |
| Cold start | <10ms | Seconds |
| Binary size | ~8.8MB | Hundreds of MB |
| Minimum hardware | $10 ARM/RISC-V | Desktop-class |

## 2. Technology Stack

### Language Distribution

| Language | Lines | Purpose |
|----------|-------|---------|
| Rust | 6,925,276 | Core runtime |
| Python | 399,051 | Companion package (zeroclaw-tools) |
| TypeScript | 247,388 | Web dashboard |
| Shell | 127,525 | Scripts/bootstrap |
| Kotlin | 29,406 | Android client |
| C++ | 4,188 | - |
| Slint | 1,848 | Embedded UI |

### Key Dependencies

| Category | Technology |
|----------|-----------|
| Async runtime | Tokio (multi-thread) |
| HTTP client | reqwest (rustls-tls, no OpenSSL) |
| HTTP server/Gateway | Axum |
| CLI | Clap 4.5 |
| Serialization | serde + serde_json + TOML |
| Database | rusqlite (bundled SQLite), optional PostgreSQL |
| Encryption | chacha20poly1305 (AEAD), ring (HMAC-SHA256) |
| WebSocket | tokio-tungstenite |
| WASM runtime | wasmtime (optional, plugin sandbox) |
| Observability | tracing + Prometheus + OpenTelemetry (optional) |
| Embedded web frontend | rust-embed + Vite/TypeScript |
| Hardware | tokio-serial, nusb, rppal (RPi GPIO) |
| Rust minimum version | 1.87 |
| Build optimization | opt-level=z, fat LTO, codegen-units=1, strip, panic=abort |

## 3. Architecture

### Trait-Driven Fully Pluggable Design

All subsystems are traits — implementations swappable via configuration with zero code changes.

```
CLI / Channels (Telegram, Discord, Slack, WhatsApp, Matrix, Nostr, IRC, Email, etc.)
    |
    v
Gateway (Axum — webhooks, REST API, WebSocket, pairing auth)
    |
    v
Agent Loop (LLM <-> Tool execution loop with research phase)
    |
    +-- Provider (OpenAI, Anthropic, Gemini, OpenRouter, Ollama, llama.cpp, vLLM, Bedrock, etc.)
    +-- ToolRegistry (shell, file, git, browser, MCP, WASM skills, hardware, composio, etc.)
    +-- Memory (SQLite hybrid search, PostgreSQL, Markdown, Lucid, Qdrant, none)
    +-- SecurityPolicy (pairing, sandbox, allowlists, rate limits, Landlock/Bubblewrap)
    +-- Identity (OpenClaw markdown / AIEOS JSON)
    +-- Observer (Noop, Log, Prometheus, OpenTelemetry)
    +-- RuntimeAdapter (Native, Docker)
    +-- Tunnel (Cloudflare, Tailscale, ngrok, Custom)
    +-- SkillForge (TOML manifest + SKILL.md + WASM plugins)
    +-- Cron/Heartbeat (APScheduler-style scheduled tasks)
```

### 9 Trait Extension Points

| Subsystem | Trait | Built-in Implementations |
|-----------|-------|------------------------|
| AI Models | `Provider` | OpenAI, Anthropic, Gemini, OpenRouter, Ollama, llama.cpp, vLLM, Bedrock, Copilot, GLM, Telnyx, etc. |
| Channels | `Channel` | CLI, Telegram, Discord, Slack, WhatsApp (Web+Business), Matrix, Signal, iMessage, IRC, Lark, DingTalk, QQ, Nostr, Email, Mattermost, Webhook, MQTT, Nextcloud Talk — **20+** |
| Memory | `Memory` | SQLite (vector+FTS5 hybrid), PostgreSQL, Markdown, Lucid, Qdrant, none |
| Tools | `Tool` | shell, file_read/write/edit, git, browser, http_request, screenshot, MCP, WASM skills, hardware, composio, web_search, pdf_read, delegate — **50+** |
| Observability | `Observer` | Noop, Log, Multi, Prometheus, OpenTelemetry |
| Runtime | `RuntimeAdapter` | Native, Docker (sandbox) |
| Security | `SecurityPolicy` | pairing, sandbox, allowlists, Landlock, Bubblewrap, Firejail |
| Identity | `IdentityConfig` | OpenClaw (markdown), AIEOS v1.1 (JSON) |
| Tunneling | `Tunnel` | None, Cloudflare, Tailscale, ngrok, Custom |

### Memory System (Full-Stack Search Engine, Zero External Dependencies)

- **Vector database**: SQLite BLOB storage + cosine similarity search
- **Keyword search**: FTS5 + BM25 scoring
- **Hybrid merge**: Custom weighted merge function
- **Embeddings**: OpenAI / custom URL / noop
- **Chunking**: Line-based Markdown chunking with heading preservation
- **Caching**: SQLite embedding_cache + LRU eviction
- **Snapshot/Hydrate**: Memory backup and restoration

## 4. Core Features

### 4.1 Extreme Resource Efficiency

- Single binary ~8.8MB, <5MB RAM, <10ms cold start
- Deployable on $10 ARM/RISC-V hardware (Raspberry Pi, ARM SBCs)
- Release profile: opt-level=z, fat LTO, strip, panic=abort

### 4.2 Full Channel Integration (20+)

- **Messaging**: Telegram, Discord, Slack, WhatsApp (Web+Business), Matrix, Signal, iMessage, IRC, Lark/Feishu, DingTalk, QQ, Nostr, Mattermost, Linq, MQTT, Nextcloud Talk
- **Enterprise**: Email (SMTP/IMAP), Webhook
- **Interactive**: CLI mode

### 4.3 Full Model Adaptation

All major LLMs: OpenAI, Anthropic, Gemini, OpenRouter, Ollama, llama.cpp, vLLM, AWS Bedrock, Copilot, GLM/Zhipu, Telnyx, Osaurus. Custom OpenAI-compatible / Anthropic-compatible endpoints. Subscription auth: OpenAI Codex OAuth, Claude Code setup-token. Reliability wrapper (`reliable.rs`) for retry and degradation.

### 4.4 Multi-Layer Security

- Gateway binds 127.0.0.1, refuses public exposure
- 6-digit one-time pairing code authentication
- **Filesystem sandbox**: workspace_only, 14 system directories + 4 sensitive dotfiles blocklist
- **Command sandbox**: deny-pattern guards
- **Channel allowlist**: deny-by-default
- **Kernel-level sandboxing**: Landlock / Bubblewrap / Firejail (Linux)
- **Docker sandbox runtime**
- **Encrypted key storage**: ChaCha20-Poly1305
- **Prompt injection detection** + **leak detection**
- **OTP security verification**
- **E-stop** (emergency stop) mechanism

### 4.5 Research Phase (Hallucination Reduction)

Before generating responses, the Agent proactively collects information through tools:
- Built-in `web_search_tool`, `web_fetch`, `content_search` research tools
- Significantly reduces hallucination by grounding responses in real data

### 4.6 WASM Skills System

- Install from ZeroMarket / ClawHub
- WASI stdio protocol plugin runtime
- Built-in security audit: blocks symlinks, script files, unsafe Markdown links
- Skill scaffolding: `zeroclaw skill new <name>`

### 4.7 Hardware/Embedded Support

- **Firmware**: Arduino, ESP32, STM32 Nucleo, UNO Q-Bridge
- **Peripherals**: USB discovery, serial communication, RPi GPIO
- **Hardware tools**: board_info, memory_map, memory_read
- probe-rs support for STM32 memory reading

### 4.8 Multi-Agent Coordination

- Sub-agent spawn/manage/register
- Inter-agent IPC (`agents_ipc.rs`)
- Task delegation (`delegate.rs`)
- SOP workflows (Standard Operating Procedures)

### 4.9 Observability

- Noop / Log / Prometheus / OpenTelemetry observers
- Multi-observer composition
- Structured tracing throughout

### 4.10 Python Companion Package (zeroclaw-tools)

- LangGraph-based tool calling
- Provides consistency for models with unstable native tool calling (e.g., GLM-5)

### 4.11 Android Client (New)

- Kotlin + UniFFI bridge
- Phase 2 in development

## 5. Latest Updates

### v0.1.7 (2026-02-24)

Recent notable changes:
- `feat(android)`: Phase 2 — UniFFI bridge and settings UI
- `feat(security)`: Default OTP enabled, prompt injection defense and leak detection
- `feat(channel)`: Separated Lark and Feishu providers
- `fix(lark)`: Accept object-shaped websocket message content
- `fix(config)`: Resolve Windows compilation blockers
- `fix(memory)`: Restore tokio-postgres-rustls dependency
- `feat(providers)`: Added Novita AI as OpenAI-compatible provider
- `feat`: Added WATI WhatsApp Business API channel
- `feat(release)`: Android target support (armv7 + aarch64)

### Version History

- v0.1.7 (2026-02-24)
- v0.1.6 (2026-02-22)
- v0.1.5 (2026-02-22)
- v0.1.4 (2026-02-21)
- v0.1.2 (2026-02-21)

Project created just 2 weeks ago, already 20,000+ stars.

## 6. Relevance to WorkPilot

### 6.1 Architecture Patterns (High Value)

| ZeroClaw Pattern | WorkPilot Mapping | Recommendation |
|-----------------|-------------------|----------------|
| Trait-driven pluggable architecture | ABC abstract base classes | ZeroClaw's trait architecture is more thorough — every subsystem is a trait; WorkPilot can learn its factory/registry pattern for more elegant Provider/Channel/Tool switching |
| **Research Phase** (research before answer) | None | **High value**: Add research phase to AgentLoop — proactively gather info before generating response to significantly reduce hallucination |
| WASM skills system | SkillsEngine | ZeroClaw's WASM sandbox skills are more secure and extensible; consider WASM plugin support |
| Multi-agent coordination (subagent/delegate) | None | Valuable multi-agent task decomposition and delegation patterns |

### 6.2 Security System (High Value)

| ZeroClaw Feature | WorkPilot Mapping | Recommendation |
|-----------------|-------------------|----------------|
| Gateway pairing code | Entra ID auth | 6-digit OTP more suitable for self-deployment scenarios |
| Landlock/Bubblewrap sandbox | Command guards + path restriction | Kernel-level sandboxing (Landlock) provides higher security |
| Prompt injection + leak detection | Log injection defense | Reference `prompt_guard.rs` and `leak_detector.rs` |
| **E-stop emergency stop** | None | **High value**: Emergency stop mechanism critical for enterprise systems |
| Security audit (skill install) | None | Static security audit during third-party skill/plugin installation |

### 6.3 Memory System (High Value)

ZeroClaw's memory system is fully self-built with zero external dependencies. WorkPilot's MemoryStore (MEMORY.md + HISTORY.md) is relatively simple. Applicable patterns:

- SQLite vector storage + cosine similarity search
- FTS5 + BM25 keyword search
- Hybrid weighted merge strategy
- Embedding cache + LRU eviction
- Snapshot/hydrate (backup/restore)

### 6.4 Channel Integration (Medium Value)

ZeroClaw supports 20+ channels (far exceeding WorkPilot's Teams/Outlook/GitHub/ADO), but WorkPilot's Microsoft ecosystem focus is its differentiating advantage. Applicable patterns:

- Channel trait + allowlist deny-by-default
- WhatsApp Web mode (no Business API needed)
- Nostr/Matrix E2EE secure communication channels

### 6.5 WorkPilot's Differentiating Advantages

| Dimension | ZeroClaw Advantage | WorkPilot Advantage |
|-----------|-------------------|---------------------|
| Language | Rust (extreme performance/safety) | Python (development velocity/ecosystem) |
| Resource efficiency | <5MB RAM | Depends on Python runtime |
| Microsoft ecosystem | No Graph API | **Deep integration** (Teams, Outlook, Calendar, Directory via Graph + MSAL) |
| LLM routing | Custom provider system | LiteLLM (100+ models out of the box) |
| Enterprise identity | No Entra ID | **Entra ID (MSAL) authentication** |
| Office productivity | Pure coding assistant | **Dual capability** (development + office) |
| Deployment barrier | Requires Rust compilation | `pip install` |
| Hardware/embedded | Yes (Arduino, ESP32, STM32) | None |

### Key Recommendations for WorkPilot

1. **Research Phase** — Implement pre-response information gathering to reduce hallucination
2. **Hybrid vector + keyword memory search** — SQLite FTS5 + vector with weighted merge
3. **E-stop emergency stop** — Essential safety mechanism for enterprise deployment
4. **Trait-driven pluggable architecture** — More thorough abstraction for all subsystems
5. **Prompt injection / leak detection** — Multi-layer defense system
6. **Observability stack** — Prometheus + OpenTelemetry integration for enterprise monitoring
