# WorkPilot Reference Project Research

> Last updated: 2026-02-27

## Reports

| # | Project | Stars | Language | Report |
|---|---------|-------|----------|--------|
| 1 | [OpenClaw](https://github.com/openclaw/openclaw) | ~235K | TypeScript | [01-openclaw.md](01-openclaw.md) |
| 2 | [nanobot](https://github.com/HKUDS/nanobot) | ~26K | Python | [02-nanobot.md](02-nanobot.md) |
| 3 | [NanoClaw](https://github.com/qwibitai/nanoclaw) | ~16K | TypeScript | [03-nanoclaw.md](03-nanoclaw.md) |
| 4 | [IronClaw](https://github.com/nearai/ironclaw) | ~3.7K | Rust | [04-ironclaw.md](04-ironclaw.md) |
| 5 | [ZeroClaw](https://github.com/zeroclaw-labs/zeroclaw) | ~20K | Rust | [05-zeroclaw.md](05-zeroclaw.md) |

## Cross-Project Comparison

| Dimension | OpenClaw | nanobot | NanoClaw | IronClaw | ZeroClaw | **WorkPilot** |
|-----------|----------|---------|----------|----------|----------|--------------|
| Language | TypeScript | **Python** | TypeScript | Rust | Rust | **Python** |
| Target | Personal assistant | Lightweight coding | Container-isolated | Privacy-first | Embedded AI OS | **Enterprise** |
| MS Ecosystem | Teams channel | None | None | None (P3) | None | **Deep Graph+MSAL** |
| Memory | SQLite-vec | MEMORY.md | Claude sessions | pgvector+RRF | SQLite hybrid | MEMORY.md |
| Sandbox | App-layer | App-layer | **Docker container** | **WASM+Docker** | **Kernel+WASM** | App-layer |
| Auth | Pairing code | Allowlist | Container isolation | Encrypted+pairing | OTP+pairing | **Entra ID** |
| Channels | 15+ | 12 | 5+ | 7+ | 20+ | 4 (enterprise) |
| Office Automation | None | None | None | None | None | **Mail+Calendar+Dir** |

## Top Recommendations for WorkPilot

### Priority 1 — High Impact, Directly Applicable

1. **Memory System Upgrade** — Migrate from file-based (MEMORY.md) to hybrid vector + keyword search
   - Reference: OpenClaw (SQLite-vec), ZeroClaw (SQLite FTS5+vector), IronClaw (pgvector+RRF)

2. **Research Phase** — Agent proactively gathers information before generating response
   - Reference: ZeroClaw's research phase with web_search, web_fetch, content_search tools
   - Impact: Significantly reduces hallucination

3. **Circuit Breaker + Cost Tracking** — LLM provider reliability and cost management
   - Reference: IronClaw (`circuit_breaker.rs`, `costs.rs`, `smart_routing.rs`)

4. **Leak Detection** — Scan tool HTTP outbound for sensitive data exfiltration
   - Reference: IronClaw (`leak_detector.rs`), ZeroClaw (prompt_guard + leak_detector)

### Priority 2 — Medium-Term Enhancement

5. **Container/WASM Sandbox** — Add OS-level isolation on top of existing app-layer sandbox
   - Reference: NanoClaw (Docker per-group), IronClaw (WASM capability-based), ZeroClaw (Landlock/Bubblewrap)

6. **E-stop Emergency Stop** — Critical safety mechanism for enterprise deployment
   - Reference: ZeroClaw

7. **Agent Swarms** — Multi-agent coordination for complex tasks
   - Reference: NanoClaw (first to implement), ZeroClaw (subagent/delegate/IPC)

8. **Skills Ecosystem** — Installable/removable skill marketplace
   - Reference: OpenClaw (ClawHub, 60+), ZeroClaw (ZeroMarket, WASM)

### Priority 3 — Long-Term Direction

9. **Trait-Driven Pluggable Architecture** — More thorough subsystem abstraction
   - Reference: ZeroClaw (9 traits, all swappable via config)

10. **Observability Stack** — Prometheus + OpenTelemetry for enterprise monitoring
    - Reference: ZeroClaw (Observer trait with multiple backends)

## WorkPilot's Unique Competitive Advantages

These differentiate WorkPilot from ALL reference projects:

- **Microsoft Graph deep integration** (mail, calendar, directory) — no competitor has this
- **Entra ID (MSAL) enterprise authentication** — all others use pairing codes or allowlists
- **Dual development + office productivity** — all others are pure coding assistants
- **Security Profiles** (solo/team/strict) — graduated enterprise permission control
- **DAG workflow engine** — declarative multi-step business workflows
- **Azure Key Vault integration** — enterprise credential management
- **Structured audit logging with auto-redaction** — enterprise compliance
