"""
VendorKernel
============
Commands for managing installed vendor modules.

Commands:
    vendor:list              Show all installed axon vendor providers
    vendor:publish <name>    Show config stubs and registration instructions
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

_PROJECT_ROOT = Path(os.environ.get("AXON_PROJECT_ROOT", Path.cwd()))


def _ok(msg: str)   -> None: print(f"  ✅ {msg}")
def _warn(msg: str) -> None: print(f"  ⚠️  {msg}")
def _err(msg: str)  -> None: print(f"  ❌ {msg}")
def _info(msg: str) -> None: print(f"  ℹ️  {msg}")
def _step(msg: str) -> None: print(f"\n  › {msg}")
def _dim(msg: str)  -> None: print(f"  {msg}")


class VendorKernel:

    # ── vendor:list ───────────────────────────────────────────────────────

    @staticmethod
    def list_vendors() -> None:
        """Show all installed axon vendor providers and their config keys."""
        from axon.core.module.vendor_loader import _discover_installed
        from axon.core.module.vendor_loader import _load_providers_file

        installed = _discover_installed()
        active_refs = _load_providers_file()
        active_names = {r.name for r in active_refs}

        print()
        print("  ╔══════════════════════════════════════════════════════╗")
        print("  ║          Installed Axon Vendor Providers             ║")
        print("  ╚══════════════════════════════════════════════════════╝")

        if not installed:
            print()
            _info("No vendor providers installed.")
            _info("Install one with: pip install python-axon-<name>")
            print()
            return

        for name, cls in sorted(installed.items()):
            status = "✅ active" if name in active_names else "⬜ not registered"
            print()
            print(f"  ┌─ {name}  [{status}]")
            print(f"  │  package : {cls.module_package}")

            if cls.config_keys:
                print(f"  │  required config:")
                for key, desc in cls.config_keys.items():
                    print(f"  │    {key}")
                    print(f"  │      → {desc}")

            if cls.optional_keys:
                print(f"  │  optional config:")
                for key, desc in cls.optional_keys.items():
                    print(f"  │    {key}  (optional)")
                    print(f"  │      → {desc}")

            if name not in active_names:
                print(f"  │")
                print(f"  │  To register: run ./manage vendor:publish {name}")

            print(f"  └──────────────────────────────────────────────────")

        print()

    # ── vendor:publish ────────────────────────────────────────────────────

    @staticmethod
    def publish(name: str) -> None:
        """
        Show a vendor's config stubs and registration instructions.
        No files are modified — copy the output manually into your project.
        """
        from axon.core.module.vendor_loader import _discover_installed

        installed = _discover_installed()
        provider_cls = installed.get(name)

        if provider_cls is None:
            _err(f"Vendor '{name}' is not installed.")
            _info(f"Install it with: pip install python-axon-{name}")
            sys.exit(1)

        _step(f"Publishing vendor '{name}'…")
        print()

        # ── .env stubs ────────────────────────────────────────────────
        print("  ┌─ Add to your .env file " + "─" * 28)

        header = f"\n# ---- {name} (python-axon-{name}) " + "-" * max(2, 40 - len(name))
        print(f"  │  {header}")

        for key, desc in provider_cls.config_keys.items():
            print(f"  │  # {desc}")
            print(f"  │  {key}=")

        for key, desc in provider_cls.optional_keys.items():
            print(f"  │  # {desc}")
            print(f"  │  # {key}=")

        print("  └" + "─" * 52)
        print()

        # ── providers.py instructions ─────────────────────────────────
        print("  ┌─ Add to app/providers/providers.py " + "─" * 16)
        print(f"  │  VendorProvider.use(\"{name}\")")
        print("  └" + "─" * 52)
        print()

        # ── Summary ───────────────────────────────────────────────────
        print(f"  ╔══════════════════════════════════════════════════════╗")
        print(f"  ║  vendor:publish '{name}' complete                    ║")
        print(f"  ╠══════════════════════════════════════════════════════╣")
        print(f"  ║  Next steps:                                         ║")
        print(f"  ║  1. Copy the .env stubs above into your .env file    ║")
        print(f"  ║  2. Copy the providers.py line above into your file  ║")
        print(f"  ║  3. ./manage runserver                               ║")
        print(f"  ╚══════════════════════════════════════════════════════╝")
        print()