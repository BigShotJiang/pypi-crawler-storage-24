"""LightClaw Channel — bridges CoPaw (Python) with LightClaw IM platform.

This is a CoPaw ``BaseChannel`` subclass that replaces the OpenClaw TypeScript
plugin (``lightclawbot``) with a native Python implementation.

Communication:
  - Inbound:  Socket.IO ``message:private`` → AgentRequest → CoPaw runner
  - Outbound: SSE events → rendered text/media → Socket.IO / REST to LightClaw
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from ..base import BaseChannel, OnReplySent, ProcessHandler
from ..schema import ChannelType
from .config import parse_channel_config
from .file_storage import FileStorage
from .gateway import LightClawGateway
from .inbound import build_native_payload, process_attachments
from .outbound import OutboundSender
from .types import GatewayContext, LightClawAccountConfig, PrivateMessageData

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


class LightClawChannel(BaseChannel):
    """CoPaw channel plugin for the LightClaw IM platform.

    Lifecycle:
      1. ``from_config()`` / ``from_env()``  → create instance
      2. ``start()``                         → connect Socket.IO gateway
      3. inbound messages enqueued via ``_enqueue``
      4. ``consume_one()``                   → process + stream reply
      5. ``send()``                          → deliver text to user
      6. ``stop()``                          → disconnect gracefully
    """

    # Registry key — CoPaw discovers the channel by this attribute.
    channel: ChannelType = "lightclawbot"
    display_name = "LightClawBot"

    def __init__(
        self,
        process: ProcessHandler,
        on_reply_sent: OnReplySent = None,
        show_tool_details: bool = True,
        *,
        config: LightClawAccountConfig | None = None,
        raw_config: dict[str, Any] | None = None,
    ):
        super().__init__(process, on_reply_sent, show_tool_details)
        self._config = config or LightClawAccountConfig()
        self._raw_config = raw_config or {}

        # Will be set in start()
        self._gateway: LightClawGateway | None = None
        self._outbound: OutboundSender | None = None
        self._file_storage: FileStorage | None = None

        # Multi-account support
        self._extra_gateways: list[LightClawGateway] = []

    # ----- factory methods (required by BaseChannel) -----

    @classmethod
    def from_config(
        cls,
        process: ProcessHandler,
        config: Any,
        on_reply_sent: OnReplySent = None,
        show_tool_details: bool = True,
    ) -> LightClawChannel:
        """Create from the ``channels.lightclawbot`` section of lightclaw.json.

        ``config`` is either:
        - A Pydantic model with ``.model_dump()``
        - A plain dict
        """
        if hasattr(config, "model_dump"):
            raw = config.model_dump(by_alias=True)
        elif isinstance(config, dict):
            raw = config
        else:
            raw = {}

        primary, _ = parse_channel_config(raw)
        return cls(
            process,
            on_reply_sent=on_reply_sent,
            show_tool_details=show_tool_details,
            config=primary,
            raw_config=raw,
        )

    @classmethod
    def from_env(
        cls,
        process: ProcessHandler,
        on_reply_sent: OnReplySent = None,
    ) -> LightClawChannel:
        """Create from environment variables (``LIGHTCLAW_API_KEY``, etc.)."""
        import os

        cfg = LightClawAccountConfig(
            api_key=os.environ.get("LIGHTCLAW_API_KEY", ""),
            api_base_url=os.environ.get("LIGHTCLAW_API_BASE_URL", ""),
            enabled=True,
        )
        return cls(process, on_reply_sent=on_reply_sent, config=cfg)

    # ----- lifecycle -----

    async def start(self) -> None:
        """Connect to LightClaw server via Socket.IO."""
        if not self._config.api_key:
            logger.warning("LightClaw channel: apiKey not configured — channel disabled")
            return

        # File storage
        self._file_storage = FileStorage(
            self._config.api_key,
            self._config.api_base_url,
        )

        # Primary gateway
        self._gateway = LightClawGateway(
            account_id="primary",
            config=self._config,
            on_message=self._on_inbound_message,
        )
        self._outbound = OutboundSender(self._gateway)

        try:
            await self._gateway.start()
            logger.info("LightClaw channel started (bot=%s)", self._gateway.bot_id)
        except Exception:
            logger.exception("LightClaw channel failed to start")
            return

        # Extra accounts
        _, extras = parse_channel_config(self._raw_config)
        for acct_name, acct_cfg in extras:
            if not acct_cfg.enabled or not acct_cfg.api_key:
                continue
            gw = LightClawGateway(
                account_id=acct_name,
                config=acct_cfg,
                on_message=self._on_inbound_message,
            )
            try:
                await gw.start()
                self._extra_gateways.append(gw)
                logger.info("LightClaw extra account started: %s", acct_name)
            except Exception:
                logger.exception("Failed to start extra account: %s", acct_name)

    async def stop(self) -> None:
        """Disconnect all gateways and clean up."""
        for gw in self._extra_gateways:
            try:
                await gw.stop()
            except Exception:
                logger.exception("Error stopping extra gateway")
        self._extra_gateways.clear()

        if self._gateway:
            try:
                await self._gateway.stop()
            except Exception:
                logger.exception("Error stopping primary gateway")
            self._gateway = None

        if self._file_storage:
            await self._file_storage.close()
            self._file_storage = None

        self._outbound = None
        logger.info("LightClaw channel stopped")

    # ----- inbound: LightClaw → CoPaw -----

    async def _on_inbound_message(
        self,
        msg: PrivateMessageData,
        ctx: GatewayContext,
    ) -> None:
        """Handle an incoming Socket.IO message from a LightClaw user."""
        # Process file attachments
        content_parts: list[dict[str, Any]] = []
        if msg.files and self._file_storage:
            content_parts = await process_attachments(msg.files, self._file_storage)

        payload = build_native_payload(msg, ctx, content_parts)

        # Enqueue into CoPaw's ChannelManager queue
        if self._enqueue:
            self._enqueue(payload)
        else:
            logger.warning("LightClaw: _enqueue not set — message dropped")

    def build_turn_request_from_native(self, native: Any) -> Any:
        """Convert native payload dict → TurnRequest.

        Required by BaseChannel. Called by ``_payload_to_request``.
        Uses the base class helper ``build_turn_request_from_user_content``
        to produce a proper TurnRequest with TurnInput.
        """
        from ...schemas import (
            AudioContent,
            ContentType,
            FileContent,
            ImageContent,
            TextContent,
            VideoContent,
        )

        payload = native if isinstance(native, dict) else {}
        sender_id = payload.get("sender_id", "unknown")
        content_parts = payload.get("content_parts", [])
        meta = payload.get("meta", {})

        # 将原始 dict 格式的 content_parts 转换为 Pydantic Content 对象，
        # 这样基类的 _content_has_text / _content_has_media 才能正确识别。
        content: list[Any] = []
        for part in content_parts:
            if isinstance(part, dict):
                ptype = part.get("type", "")
                if ptype == ContentType.TEXT:
                    content.append(TextContent(text=part.get("text", "")))
                elif ptype == ContentType.IMAGE:
                    content.append(ImageContent(image_url=part.get("image_url", "")))
                elif ptype == ContentType.VIDEO:
                    content.append(VideoContent(video_url=part.get("video_url", "")))
                elif ptype == ContentType.AUDIO:
                    content.append(AudioContent(
                        data=part.get("data"),
                        format=part.get("format"),
                    ))
                elif ptype == ContentType.FILE:
                    content.append(FileContent(
                        file_url=part.get("file_url"),
                        filename=part.get("filename"),
                    ))
                else:
                    # 未知类型，按文本处理
                    text = part.get("text", "")
                    if text:
                        content.append(TextContent(text=text))
            else:
                # 已经是 Pydantic 对象，直接使用
                content.append(part)

        session_id = self.resolve_session_id(sender_id, meta)

        return self.build_turn_request_from_user_content(
            channel_id=self.channel,
            sender_id=sender_id,
            session_id=session_id,
            content_parts=content,
            channel_meta=meta,
        )

    def resolve_session_id(
        self,
        sender_id: str,
        channel_meta: dict[str, Any] | None = None,
    ) -> str:
        """Session ID = ``lightclaw:{sender_id}`` for backward compatibility."""
        return f"lightclaw:{sender_id}"

    # ----- outbound: CoPaw → LightClaw -----

    async def send(
        self,
        to_handle: str,
        text: str,
        meta: dict[str, Any] | None = None,
    ) -> None:
        """Send a text reply back to the LightClaw user.

        ``to_handle`` is the user's client ID (``from_id`` in the original msg).
        """
        if not self._outbound:
            logger.warning("LightClaw: outbound sender not available")
            return

        meta = meta or {}
        reply_to = meta.get("reply_to_msg_id") or meta.get("msg_id")

        await self._outbound.send_text(
            to_id=to_handle,
            text=text,
            reply_to=reply_to,
        )

    async def send_media(
        self,
        to_handle: str,
        part: Any,
        meta: dict[str, Any] | None = None,
    ) -> None:
        """Send a media attachment to the LightClaw user."""
        if not self._outbound:
            return

        url = ""
        filename = ""
        mime_type = ""

        if hasattr(part, "image_url"):
            url = part.image_url
            mime_type = "image/png"
        elif hasattr(part, "video_url"):
            url = part.video_url
            mime_type = "video/mp4"
        elif hasattr(part, "file_url"):
            url = part.file_url
            filename = getattr(part, "filename", "") or "file"
        elif hasattr(part, "data") and isinstance(part.data, str):
            url = part.data

        if url:
            await self._outbound.send_media(
                to_id=to_handle,
                url=url,
                filename=filename,
                mime_type=mime_type,
            )

    async def send_content_parts(
        self,
        to_handle: str,
        parts: list[Any],
        meta: dict[str, Any] | None = None,
    ) -> None:
        """Send rendered content parts — text merged, media sent separately."""
        text_chunks: list[str] = []
        media_parts: list[Any] = []

        for part in parts:
            if hasattr(part, "text"):
                text_chunks.append(part.text)
            elif hasattr(part, "refusal"):
                text_chunks.append(part.refusal)
            else:
                media_parts.append(part)

        # Send text as one message
        if text_chunks:
            body = "\n".join(text_chunks)
            await self.send(to_handle, body, meta)

        # Send each media part
        for mp in media_parts:
            await self.send_media(to_handle, mp, meta)

    # ----- Hooks for typing indicator support -----
    # 不再覆写 consume_one()，而是通过基类钩子注入 typing indicator。
    # 基类 _consume_one_request → _run_process_loop 会正确处理 TurnEvent 流，
    # 并调用 send_message_content → send_content_parts → send() 推送消息。

    async def _before_consume_process(self, request: Any) -> None:
        """在 _run_process_loop 之前发送 typing_start 到用户。"""
        to_handle = self.get_to_handle_from_request(request)
        if self._outbound:
            await self._outbound.send_typing(to_handle, start=True)

    async def _run_process_loop(
        self,
        request: Any,
        to_handle: str,
        send_meta: dict[str, Any],
    ) -> None:
        """覆写基类 _run_process_loop，在完成后发送 typing_stop。"""
        try:
            await super()._run_process_loop(request, to_handle, send_meta)
        finally:
            # Typing stop
            if self._outbound:
                await self._outbound.send_typing(to_handle, start=False)

    # ----- connection status -----

    def get_connection_status(self) -> dict[str, Any]:
        """Return gateway connection status."""
        primary_ok = self._gateway.connected if self._gateway else False
        extras = {
            gw._account_id: gw.connected for gw in self._extra_gateways
        }
        return {
            "channel": self.channel,
            "connected": primary_ok,
            "bot_id": self._gateway.bot_id if self._gateway else "",
            "extra_accounts": extras,
        }

    # ----- credentials verification -----

    @classmethod
    async def verify_credentials_with_params(
        cls,
        credentials: dict,
    ) -> dict[str, Any]:
        """Verify LightClaw credentials from a request body dict."""
        import aiohttp

        from .config import DEFAULT_API_BASE, ENDPOINT_USER_CURRENT, build_auth_headers

        raw_api_keys = credentials.get("apiKeys") or []
        api_keys = [key for key in raw_api_keys if isinstance(key, str) and key.strip()]
        api_key = (
            credentials.get("apiKey")
            or (api_keys[0] if api_keys else "")
        )
        base = (credentials.get("apiBaseUrl") or DEFAULT_API_BASE).rstrip("/")

        if not api_key:
            return {
                "valid": False,
                "status": "disconnected",
                "reason": "Missing apiKey/apiKeys[0]",
            }

        url = f"{base}{ENDPOINT_USER_CURRENT}"
        headers = build_auth_headers(api_key)

        try:
            async with aiohttp.ClientSession(headers=headers) as sess, sess.get(url) as resp:
                if resp.status != 200:
                    return {
                        "valid": False,
                        "status": "disconnected",
                        "reason": f"HTTP {resp.status}: Authentication failed",
                    }
                body = await resp.json()
                extra_raw = (
                    (body.get("data") or {})
                    .get("client", {})
                    .get("extra", "")
                )
                import json as _json
                if isinstance(extra_raw, str) and extra_raw:
                    try:
                        extra_obj = _json.loads(extra_raw)
                    except (ValueError, TypeError):
                        extra_obj = {}
                elif isinstance(extra_raw, dict):
                    extra_obj = extra_raw
                else:
                    extra_obj = {}
                bot_id = extra_obj.get("botId", "")
                return {
                    "valid": True,
                    "status": "connected",
                    "bot_id": bot_id,
                    "message": f"Connected as bot: {bot_id}",
                }
        except Exception as exc:
            return {
                "valid": False,
                "status": "disconnected",
                "reason": str(exc),
            }

    # ----- configurator for CLI -----

    @classmethod
    def get_configurator(cls) -> Callable | None:
        """Return an interactive configurator for ``lightclaw channels config``."""

        def configure_lightclaw(current: dict[str, Any]) -> dict[str, Any]:
            """Interactive CLI config for LightClaw channel."""
            print("\n--- LightClaw Channel Configuration ---")
            current_api_keys = current.get("apiKeys") or []
            current_first_key = current_api_keys[0] if current_api_keys else current.get("apiKey", "")
            api_key = input(
                f"  API Key [{current_first_key[:8]}...]: "
            ).strip()
            if not api_key:
                api_key = current_first_key

            api_base_url = input(
                f"  API Base URL [{current.get('apiBaseUrl', '')}]: "
            ).strip()
            if not api_base_url:
                api_base_url = current.get("apiBaseUrl", "")

            enabled_str = input(
                f"  Enabled [{current.get('enabled', True)}] (true/false): "
            ).strip()
            enabled = (
                enabled_str.lower() in ("true", "1", "yes", "")
                if enabled_str
                else current.get("enabled", True)
            )

            return {
                "apiKey": api_key,
                "apiKeys": [api_key] if api_key else [],
                "apiBaseUrl": api_base_url,
                "enabled": enabled,
            }

        return configure_lightclaw
