"""
Public SDK for run management (create, list, get, cancel, delete, logs, csv, videos, download).

Use these for programmatic run inspection, cancellation, and video downloads.
For end-to-end pipeline execution (create run + generate + upload), use worldjen.run().
"""

from pathlib import Path
from typing import Any, Dict, List, Optional

from worldjen._api import (
    cancel_run,
    create_run,
    delete_run,
    get_run,
    get_run_csv,
    get_run_logs,
    get_run_videos,
    list_runs as _list_runs,
)

try:
    import requests
except ImportError:  # pragma: no cover — defensive; requests is a dependency
    requests = None


__all__ = [
    "create",
    "get",
    "list_runs",
    "cancel",
    "delete",
    "get_logs",
    "get_csv",
    "get_videos",
    "download_videos",
]


def create(
    name: str,
    dimensions: List[str],
    run_instructions: Optional[Dict[str, Any]] = None,
    model_id: Optional[str] = None,
) -> str:
    """Create a run. Returns the run ID."""
    return create_run(
        name=name,
        dimensions=dimensions,
        run_instructions=run_instructions,
        model_id=model_id,
    )


def get(run_id: str) -> Dict[str, Any]:
    """Fetch run metadata and result data."""
    return get_run(run_id)


def cancel(run_id: str) -> None:
    """Cancel a run."""
    cancel_run(run_id)


def delete(run_id: str) -> None:
    """Delete a run."""
    delete_run(run_id)


def get_logs(run_id: str) -> Dict[str, Any]:
    """Fetch run logs."""
    return get_run_logs(run_id)


def get_csv(run_id: str) -> bytes:
    """Fetch run CSV as bytes."""
    return get_run_csv(run_id)


def list_runs(
    status: Optional[str] = None,
    page: int = 1,
    limit: int = 50,
) -> Dict[str, Any]:
    """List runs with optional status filter and pagination."""
    return _list_runs(status=status, page=page, limit=limit)


def get_videos(run_id: str) -> List[Dict[str, Any]]:
    """List video metadata (id, prompt, url) for a run."""
    return get_run_videos(run_id)


def download_videos(
    run_id: str,
    output_dir: str | Path = ".",
) -> Path:
    """
    Download all videos for a run to output_dir.
    Returns the output directory path.
    """
    if requests is None:
        raise ImportError("requests is required for download_videos")
    videos = get_run_videos(run_id)
    out_dir = Path(output_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    for i, v in enumerate(videos):
        url = v.get("url")
        if not url:
            continue
        vid = v.get("id") or v.get("_id") or str(i)
        ext = ".mp4" if "mp4" in (v.get("contentType") or "mp4") else ".webm"
        path = out_dir / f"{vid}{ext}"
        r = requests.get(url, timeout=300)
        r.raise_for_status()
        path.write_bytes(r.content)
    return out_dir
