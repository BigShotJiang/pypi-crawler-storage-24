"""Shared CLI helpers for API config (api_key, api_url from args and env)."""
import argparse
import os
import sys

from worldjen._config import _config as _state, config as config_fn


def apply_api_config(args: argparse.Namespace, *, require_api_key: bool = True) -> None:
    """Apply API key and URL from args and env to global config. Optionally require api_key."""
    if getattr(args, "api_key", None):
        config_fn(api_key=args.api_key)
    if getattr(args, "api_url", None):
        config_fn(api_url=args.api_url)
    elif os.environ.get("WORLDJEN_API_URL"):
        config_fn(api_url=os.environ.get("WORLDJEN_API_URL"))
    if not _state.api_key:
        config_fn(api_key=os.environ.get("WORLDJEN_API_KEY"))
    if require_api_key and not _state.api_key:
        print("Error: WORLDJEN_API_KEY or --api-key required", file=sys.stderr)
        sys.exit(1)
