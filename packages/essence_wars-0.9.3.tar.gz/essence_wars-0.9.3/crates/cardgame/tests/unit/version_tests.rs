//! Tests migrated from inline #[cfg(test)] module in src/version.rs

use cardgame::version::{version_string, VersionInfo, VERSION};

#[test]
fn test_version_available() {
    assert!(!VERSION.is_empty());
    assert_eq!(VERSION, "0.9.2");
}

#[test]
fn test_version_string() {
    let vs = version_string();
    assert!(vs.contains("cardgame"));
    assert!(vs.contains("0.9.2"));
}

#[test]
fn test_version_info_serializable() {
    let info = VersionInfo::current();
    let json = serde_json::to_string(&info).unwrap();
    assert!(json.contains("0.9.2"));
}
