"""mlx-mfa: Metal Flash Attention for MLX.

High-performance FlashAttention on Apple Silicon, based on the Metal Flash
Attention kernels from philipturner/metal-flash-attention (ported to C++ by
liuliu/ccv for production use in Draw Things).

Quick start::

    from mlx_mfa import flash_attention

    # Drop-in replacement for mx.fast.scaled_dot_product_attention
    out = flash_attention(q, k, v, scale=None, causal=False)

Supported configurations:
    - head_dim: 64, 128, 256, 512
    - dtype: float16, bfloat16, float32
    - Shapes: [batch, heads, seq_len, head_dim] (BHND)
    - Causal and non-causal attention
    - Full autograd support via SDPA VJP fallback (default)
    - STEEL V2 production routing for dense causal D=64/128
    - D=256 narrow benchmark-backed dense causal promotion (M1/M2 f16)
    - D=512 dense remains SDPA-default in auto mode
    - SageAttention as a specialized decode backend
    - Softcap, ALiBi, window, sparse, varlen, and packed QKV/KV layouts

When the C++ extension is unavailable (e.g., during CI without a Metal GPU),
all functions fall back to ``mx.fast.scaled_dot_product_attention``.
"""

__version__ = "2.21.0"


def _check_abi() -> None:
    """Warn if the compiled extension was built against a different MLX major.minor."""
    try:
        import importlib
        _ext = importlib.import_module("mlx_mfa._ext")
        build_ver = _ext._mlx_build_version()
        if build_ver == "unknown":
            return
        import mlx.core
        runtime_ver = mlx.core.__version__
        # Compare major.minor only — patch releases are ABI-compatible.
        bv = tuple(int(x) for x in build_ver.split(".")[:2])
        rv = tuple(int(x) for x in runtime_ver.split(".")[:2])
        if bv != rv:
            import warnings
            warnings.warn(
                f"mlx-mfa was compiled against MLX {build_ver} but the installed "
                f"MLX is {runtime_ver}.  Rebuild the extension to avoid crashes:\n"
                "  pip install --no-build-isolation -e .",
                RuntimeWarning,
                stacklevel=2,
            )
    except Exception:
        pass


_check_abi()

from mlx_mfa.attention import (
    flash_attention,
    flash_attention_rope,
    flash_attention_rope_unified,
    flash_attention_sparse,
    flash_attention_gna,
    flash_attention_topk,
    flash_attention_varlen,
    flash_attention_kvcache,
    flash_attention_kvcache_rope_append,
    flash_attention_paged,
    flash_attention_paged_varlen,
    flash_attention_qkv_packed,
    flash_attention_kv_packed,
    flash_attention_varlen_qkv_packed,
    flash_attention_varlen_kv_packed,
    KVCacheProtocol,
    DenseKVCache,
    PagedKVCache,
    make_causal_block_mask,
    make_sliding_window_mask,
    make_rope_3d_tables,
    is_mfa_available,
    get_device_info,
    get_supported_configs,
    warmup_kernels,
    DispatchPolicy,
    # Track JD: LLM inference helpers
    flash_attention_speculative_verify,
    flash_attention_speculative_verify_paged,
    make_shared_prefix_cache,
    flash_attention_splitfuse,
    # Track KC: SageAttention
    sage_attention,
    # Track LA: SageAttention KV-cache decode
    sage_attention_kvcache,
    # CP6: pre-quantized SageAttention + QuantizedKVCache
    sage_attention_prequantized,
    QuantizedKVCache,
)

from mlx_mfa.quantize import (
    quantize_per_block,
    dequantize,
    smooth_k,
    sage_output_correction,
    sage_block_sizes,
)

# Track LC/Phase 2: InferenceContext + PagedInferenceContext + SageInferenceContext
from mlx_mfa.inference import (
    InferenceContext,
    PagedInferenceContext,
    SageInferenceContext,
    create_inference_context,
)
from mlx_mfa.runtime import (
    DecodeRuntime,
    create_decode_runtime,
)
from mlx_mfa.kv_cache import (
    KVCacheCapabilities,
    KVCacheOperationUnsupported,
    KVCacheAdapter,
    DenseKVCacheAdapter,
    PagedKVCacheAdapter,
    QuantizedKVCacheAdapter,
    HybridKVCache,
    HybridKVCacheAdapter,
    adapt_kv_cache,
    resolve_context_cache,
    resolve_context_cache_adapter,
)
from mlx_mfa.external_cache import (
    ExternalKVCacheCapabilities,
    ExternalKVCacheAdapter,
    LocalHostKVStoreAdapter,
)

from mlx_mfa.turboquant import (
    turboquant_compress,
    turboquant_decompress,
    TurboQuantKVCache,
)

from mlx_mfa.dispatch_policy import calibrate_dispatch, _load_calibrated_kernel_config, _invalidate_cached_env
from mlx_mfa.compile_metallib import compile_metallib

# Apply any calibrated kernel config (BK selection etc.) before first kernel dispatch.
_load_calibrated_kernel_config()

# Re-export C++ invalidation for benchmarks/advanced users.
def _invalidate_env_config():
    """Re-read all cached MFA_* env vars in the C++ singleton.

    Call after os.environ mutations of cached vars (MFA_V2_FORCE_BK, etc.).
    Dispatch gates (MFA_ENABLE_V3, etc.) are live-read and don't need this.
    """
    try:
        from mlx_mfa._ext import _invalidate_env_config as _inv
        _inv()
    except (ImportError, AttributeError):
        pass

from mlx_mfa.masks import (
    make_spatial_2d_mask,
    make_spatial_3d_mask,
    make_topk_spatial_mask,
    make_segment_mask,
    make_causal_segment_mask,
    make_adaptive_window_mask,
    make_lcsa_mask,
    make_axial_spatial_mask,
    make_axial_temporal_mask,
    make_dilated_temporal_mask,
    make_sink_window_mask,
    make_reference_frame_mask,
    make_cross_stream_mask,
    make_gna_mask,
    make_diagonal_mask,
    make_strided_mask,
    make_temporal_group_mask,
    make_temporal_distance_bias,
    temporal_distance_bias_to_mask,
)

__all__ = [
    # Core attention
    "flash_attention",
    "flash_attention_rope",
    "flash_attention_rope_unified",
    "flash_attention_sparse",
    "flash_attention_gna",
    "flash_attention_topk",
    "flash_attention_varlen",
    "flash_attention_kvcache",
    "flash_attention_kvcache_rope_append",
    "flash_attention_paged",
    "flash_attention_paged_varlen",
    "flash_attention_qkv_packed",
    "flash_attention_kv_packed",
    "flash_attention_varlen_qkv_packed",
    "flash_attention_varlen_kv_packed",
    "KVCacheProtocol",
    "DenseKVCache",
    "PagedKVCache",
    # Mask construction
    "make_causal_block_mask",
    "make_sliding_window_mask",
    "make_spatial_2d_mask",
    "make_spatial_3d_mask",
    "make_topk_spatial_mask",
    "make_segment_mask",
    "make_causal_segment_mask",
    "make_adaptive_window_mask",
    "make_lcsa_mask",
    "make_axial_spatial_mask",
    "make_axial_temporal_mask",
    "make_dilated_temporal_mask",
    "make_sink_window_mask",
    "make_reference_frame_mask",
    "make_cross_stream_mask",
    "make_gna_mask",
    "make_diagonal_mask",
    "make_strided_mask",
    "make_temporal_group_mask",
    "make_temporal_distance_bias",
    "temporal_distance_bias_to_mask",
    # RoPE helpers
    "make_rope_3d_tables",
    # Utilities
    "is_mfa_available",
    "get_device_info",
    "get_supported_configs",
    "warmup_kernels",
    "compile_metallib",
    "DispatchPolicy",
    "calibrate_dispatch",
    # LLM inference helpers (Track JD)
    "flash_attention_speculative_verify",
    "flash_attention_speculative_verify_paged",
    "make_shared_prefix_cache",
    "flash_attention_splitfuse",
    # SageAttention (Track KC / LA / CP6)
    "sage_attention",
    "sage_attention_kvcache",
    "sage_attention_prequantized",
    "QuantizedKVCache",
    # Quantization utilities (Track KA/KC)
    "quantize_per_block",
    "dequantize",
    "smooth_k",
    "sage_output_correction",
    "sage_block_sizes",
    # InferenceContext lifecycle (Track LC / Phase 2 / LA)
    "InferenceContext",
    "PagedInferenceContext",
    "SageInferenceContext",
    "create_inference_context",
    "DecodeRuntime",
    "create_decode_runtime",
    # Cache abstraction helpers
    "KVCacheCapabilities",
    "KVCacheOperationUnsupported",
    "KVCacheAdapter",
    "DenseKVCacheAdapter",
    "PagedKVCacheAdapter",
    "QuantizedKVCacheAdapter",
    "HybridKVCache",
    "HybridKVCacheAdapter",
    "adapt_kv_cache",
    "resolve_context_cache",
    "resolve_context_cache_adapter",
    "ExternalKVCacheCapabilities",
    "ExternalKVCacheAdapter",
    "LocalHostKVStoreAdapter",
    # TurboQuant KV cache compression (Phase 1)
    "turboquant_compress",
    "turboquant_decompress",
    "TurboQuantKVCache",
    "__version__",
]
