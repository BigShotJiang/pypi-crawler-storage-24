/// mfa_steel_fwd_v5.hpp  –  STEEL V5 forward kernel: D-blocked attention.
///
/// V5 key design: D is tiled into BD_tile=32 chunks.  Q+O stay in registers for
/// the entire K-loop (Q loaded from device once per Q-block; no Q_smem).
/// A single KV_smem buffer is reused for K^T and V chunks.
///
/// V5 TGP vs V2 (D=128, M1/M2, post-autoresearch BK=32):
///   V2 (BK=32): Q_smem(8704) + KV_smem(10240) = 18,944 B → 1 TG/CU
///   V5 (BK=32, BD=64): KV_smem only = 4,096 B             → 8 TG/CU
///
/// V5 K-tile count = same as V2 (BK matched post-autoresearch).
/// V5 advantage is 8× occupancy from eliminating Q_smem.
///
/// Q loading without TGP:
///   Each simdgroup owns BQ/WM = 8 unique Q rows — no cross-simdgroup sharing
///   needed, so Q is read directly from device memory into registers per SIMD.
///   This eliminates the Q_smem that V2 needed (8,704 bytes).
///
/// Block configs (post-autoresearch, per-D):
///   D=64  M1/M2: BQ=32, BK=32, BD_tile=32, WM=4 → TGP=2,048 B, 16 TG/CU
///   D=128 M1/M2: BQ=32, BK=32, BD_tile=64, WM=4 → TGP=4,096 B,  8 TG/CU
///   (was:  BQ=32, BK=128, BD_tile=32, WM=4      → TGP=10,240 B,  3 TG/CU)

#pragma once

#include "shader_cache.hpp"
#include "mfa_env.hpp"
#include <string>

namespace mlx_mfa {

struct SteelV5BlockConfig {
  int BQ;       // Query block size (sequence dim)
  int BK;       // Key block size (sequence dim)
  int BD_tile;  // D-blocking tile size (head dim chunk)
  int WM;       // SIMD groups per threadgroup
};

/// Check if V5 is eligible for a given head_dim.
inline bool v5_eligible(int head_dim) {
  // D=512 is intentionally excluded here; D=512 stays in the dedicated
  // D-split family and is currently SDPA-default in auto-dispatch policy.
  return (head_dim == 64 || head_dim == 128);
}

/// Block config for V5.
/// autoresearch Axis 2 (M1 Max, 2026-03-21): per-D configs
///   D=64:  BK=32 BD_tile=32 → TGP=2,048B → 16 TGs/CU  V5/SDPA=0.695 (1.44x)
///   D=128: BK=32 BD_tile=64 → TGP=4,096B →  8 TGs/CU  V5/SDPA=0.556 (1.80x)
///   D=64 prefers smaller BD_tile (fewer D-chunks, fewer barriers).
///   D=128 prefers larger BD_tile (amortizes barrier cost at higher D).
inline SteelV5BlockConfig select_steel_v5_block_config(int head_dim,
                                                       bool is_m3_plus) {
  (void)is_m3_plus;
  const auto& env = MFAEnvConfig::get();
  auto or_default = [](int override_val, int def) { return override_val > 0 ? override_val : def; };
  const int bq = or_default(env.v5_force_bq, 32);
  const int wm = or_default(env.v5_force_wm,  4);
  if (head_dim == 64) {
    const int bk      = or_default(env.v5_force_bk,      32);
    const int bd_tile = or_default(env.v5_force_bd_tile,  32);
    return {.BQ = bq, .BK = bk, .BD_tile = bd_tile, .WM = wm};
  }
  // D=128 (default)
  const int bk      = or_default(env.v5_force_bk,      32);
  const int bd_tile = or_default(env.v5_force_bd_tile,  64);
  return {.BQ = bq, .BK = bk, .BD_tile = bd_tile, .WM = wm};
}

/// Generate the Metal shader source for the STEEL V5 forward kernel.
/// Kernel function name: "mlx_mfa_v5_attention".
///
/// Supported: f16/bf16, D=64/128, causal/non-causal, GQA.
/// Supports: dense, causal, sliding window, softcap, ALiBi, GQA.
/// RoPE excluded (Q in registers, pairs D/2-apart across D-chunk boundaries).
std::string generate_steel_v5_source(const ShaderCache::KernelKey& key);

}  // namespace mlx_mfa
