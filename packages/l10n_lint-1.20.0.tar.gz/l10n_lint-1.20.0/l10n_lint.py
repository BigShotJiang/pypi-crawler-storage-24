#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-3.0-or-later
# l10n-lint - Linter for localization files
# Copyright (C) 2026 Daniel Nylander <daniel@danielnylander.se>
"""
l10n-lint - Linter for localization files (.po, .ts)

Checks for:
- Missing translations (empty msgstr)
- Fuzzy entries
- Placeholder mismatches (%s, %d, {0}, {1}, etc.)
- String length issues
- Duplicate entries
- Invalid syntax
"""

import argparse
import gettext
import json
import locale
import os
import re
import sys
import tempfile
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Generator, Optional
from urllib.parse import urlparse

__version__ = "1.19.0"

# Translation setup
DOMAIN = "l10n-lint"

# Look for locale in multiple places
_possible_locale_dirs = [
    Path(__file__).parent / "locale",  # Development / pip install -e
    Path("/usr/share/l10n-lint/locale"),  # System install (Debian)
    Path("/usr/share/locale"),  # Standard system locale (RPM/Fedora)
]
LOCALE_DIR = None
for _dir in _possible_locale_dirs:
    # Check it's a real locale dir (has LC_MESSAGES subdir or .pot file)
    if _dir.is_dir() and (list(_dir.glob("*/LC_MESSAGES")) or list(_dir.glob("*.pot"))):
        LOCALE_DIR = _dir
        break

# Initialize gettext - detect language
# Priority: LANGUAGE > LC_ALL > LC_MESSAGES > LANG > locale.getlocale()
_system_lang = (
    os.environ.get("LANGUAGE", "").split(":")[0] or
    os.environ.get("LC_ALL", "") or
    os.environ.get("LC_MESSAGES", "") or
    os.environ.get("LANG", "") or
    locale.getlocale()[0] or
    "en"
)
_lang_code = _system_lang.split("_")[0].split(".")[0] if _system_lang else "en"

try:
    if LOCALE_DIR:
        translation = gettext.translation(DOMAIN, LOCALE_DIR, languages=[_lang_code], fallback=True)
    else:
        translation = gettext.NullTranslations()
    _ = translation.gettext
except Exception:
    def _(s): return s


class Severity(Enum):
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


@dataclass
class LintIssue:
    file: str
    line: int
    severity: Severity
    rule: str
    message: str
    context: str = ""
    
    def to_dict(self):
        return {
            "file": self.file,
            "line": self.line,
            "severity": self.severity.value,
            "rule": self.rule,
            "message": self.message,
            "context": self.context,
        }


@dataclass
class LintResult:
    issues: list = field(default_factory=list)
    files_checked: int = 0
    entries_checked: int = 0
    disabled_rules: set = field(default_factory=set)
    
    @property
    def error_count(self):
        return sum(1 for i in self.issues if i.severity == Severity.ERROR)
    
    @property
    def warning_count(self):
        return sum(1 for i in self.issues if i.severity == Severity.WARNING)
    
    @property
    def info_count(self):
        return sum(1 for i in self.issues if i.severity == Severity.INFO)
    
    def issues_by_rule(self) -> dict:
        """Group issues by rule name."""
        by_rule = {}
        for issue in self.issues:
            by_rule[issue.rule] = by_rule.get(issue.rule, 0) + 1
        return dict(sorted(by_rule.items(), key=lambda x: -x[1]))
    
    def add(self, issue: LintIssue):
        if issue.rule in self.disabled_rules:
            return
        self.issues.append(issue)


class POParser:
    """Parse .po (gettext) files."""
    
    def __init__(self, content: str, filename: str = "<unknown>"):
        self.content = content
        self.filename = filename
        self.entries = []
        self._parse()
    
    def _parse(self):
        """Parse PO file into entries."""
        lines = self.content.split('\n')
        current_entry = {}
        current_key = None
        entry_start_line = 1
        
        for i, line in enumerate(lines, 1):
            line_stripped = line.strip()
            
            # Empty line = end of entry
            if not line_stripped:
                if current_entry:
                    current_entry['_line'] = entry_start_line
                    self.entries.append(current_entry)
                    current_entry = {}
                    current_key = None
                continue
            
            # Comment lines
            if line_stripped.startswith('#'):
                if not current_entry:
                    entry_start_line = i
                if line_stripped.startswith('#,'):
                    # Flags (fuzzy, etc.)
                    flags = line_stripped[2:].strip().split(',')
                    current_entry['_flags'] = [f.strip() for f in flags]
                elif line_stripped.startswith('#:'):
                    # Source reference
                    current_entry['_source'] = line_stripped[2:].strip()
                continue
            
            # msgctxt, msgid, msgstr (check longer keys first to avoid prefix matching issues)
            for key in ['msgctxt', 'msgid_plural', 'msgid', 'msgstr']:
                if line_stripped.startswith(key):
                    if not current_entry:
                        entry_start_line = i
                    # Handle msgstr[N] for plurals
                    match = re.match(rf'{key}(\[\d+\])?\s+"(.*)"', line_stripped)
                    if match:
                        suffix = match.group(1) or ''
                        value = match.group(2)
                        full_key = key + suffix
                        current_entry[full_key] = self._unescape(value)
                        current_key = full_key
                    break
            else:
                # Continuation line (starts with ")
                if line_stripped.startswith('"') and current_key:
                    match = re.match(r'"(.*)"', line_stripped)
                    if match:
                        current_entry[current_key] += self._unescape(match.group(1))
        
        # Don't forget last entry
        if current_entry:
            current_entry['_line'] = entry_start_line
            self.entries.append(current_entry)
    
    def _unescape(self, s: str) -> str:
        """Unescape PO string."""
        return s.replace('\\n', '\n').replace('\\t', '\t').replace('\\"', '"').replace('\\\\', '\\')


class TSParser:
    """Parse Qt .ts (XML) files."""
    
    def __init__(self, content: str, filename: str = "<unknown>"):
        self.content = content
        self.filename = filename
        self.entries = []
        self._parse()
    
    def _parse(self):
        """Parse TS file into entries."""
        import xml.etree.ElementTree as ET
        
        try:
            root = ET.fromstring(self.content)
        except ET.ParseError:
            return
        
        for context in root.findall('.//context'):
            context_name = context.findtext('name', '')
            
            for message in context.findall('message'):
                entry = {
                    '_context': context_name,
                    '_line': 1,  # XML doesn't give us line numbers easily
                }
                
                source = message.find('source')
                if source is not None:
                    entry['source'] = source.text or ''
                
                translation = message.find('translation')
                if translation is not None:
                    entry['translation'] = translation.text or ''
                    entry['_type'] = translation.get('type', '')  # unfinished, vanished, etc.
                
                self.entries.append(entry)


class L10nLinter:
    """Main linter class."""
    
    # Regex patterns for placeholder detection
    PRINTF_PATTERN = re.compile(r'%[-+0 #]*\d*\.?\d*[hlL]?[diouxXeEfFgGaAcspn%]')
    PYTHON_FORMAT = re.compile(r'\{(\d+|[a-zA-Z_][a-zA-Z0-9_]*)?(?:![rsa])?(?::[^}]*)?\}')
    PYTHON_NAMED = re.compile(r'%\([a-zA-Z_][a-zA-Z0-9_]*\)[sdfgiou]')  # %(name)s %(hotkey)s
    QT_PATTERN = re.compile(r'%\d+')
    
    # HTML tag pattern
    HTML_TAG_PATTERN = re.compile(r'<[^>]+>')
    
    # Keyboard accelerator patterns (&File, _File) - include unicode letters
    ACCELERATOR_PATTERN = re.compile(r'[&_](\w)', re.UNICODE)
    
    # Escaped characters
    ESCAPE_PATTERN = re.compile(r'\\[nrt\\"]')
    
    # Common English words (for untranslated detection)
    COMMON_ENGLISH = {
        # Articles and prepositions
        'the', 'a', 'an', 'and', 'or', 'of', 'to', 'in', 'on', 'at', 'by', 'for',
        'with', 'from', 'into', 'over', 'after', 'before', 'between', 'under',
        # Pronouns
        'you', 'your', 'they', 'their', 'there', 'here', 'this', 'that', 'these', 'those',
        'it', 'its', 'we', 'our', 'he', 'she', 'him', 'her', 'them',
        # Verbs (common)
        'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had',
        'do', 'does', 'did', 'will', 'would', 'could', 'should', 'can', 'may', 'might',
        # Question words
        'when', 'where', 'what', 'which', 'who', 'how', 'why',
        # Adjectives/Adverbs
        'all', 'each', 'every', 'both', 'few', 'more', 'most', 'other', 'some',
        'such', 'than', 'too', 'very', 'just', 'also', 'only', 'not', 'no', 'yes',
        # Common UI words (often left untranslated by mistake)
        'click', 'button', 'file', 'open', 'save', 'close', 'new', 'edit', 'view',
        'help', 'window', 'menu', 'options', 'settings', 'please', 'continue',
        'cancel', 'ok', 'error', 'warning', 'select', 'selected', 'delete',
        'remove', 'add', 'create', 'update', 'enable', 'disable', 'loading',
        'failed', 'success', 'download', 'upload', 'search', 'find', 'copy', 'paste',
        'undo', 'redo', 'print', 'exit', 'quit', 'about', 'preferences',
    }
    
    # Swedish special characters that shouldn't be accelerators
    NORDIC_CHARS = set('åäöÅÄÖæøÆØ')
    
    # Option value pattern (--option=VALUE or --option VALUE)
    OPTION_VALUE_PATTERN = re.compile(r'--?\w+[=\s]([A-Z][A-Z0-9_]+)')
    
    # Number patterns for localization checks
    NUMBER_WITH_COMMAS = re.compile(r'\b\d{1,3}(,\d{3})+\b')  # e.g. 1,000 or 1,000,000
    
    # Currency patterns
    CURRENCY_PATTERN = re.compile(r'[\$€£¥]\s?\d|USD|EUR|GBP|JPY')
    # Pattern to strip printf positional args (%1$s, %2$d etc.) before currency check
    PRINTF_POSITIONAL = re.compile(r'%\d+\$[a-zA-Z]')
    
    # Date format patterns (common English formats)
    DATE_PATTERNS = [
        re.compile(r'\b(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},?\s+\d{4}\b'),
        re.compile(r'\b\d{1,2}/\d{1,2}/\d{2,4}\b'),  # MM/DD/YYYY
        re.compile(r'\b\d{4}-\d{2}-\d{2}\b'),  # ISO format (usually OK)
    ]
    
    # Python brace format
    PYTHON_BRACE_FORMAT = re.compile(r'\{(\w*(?:\.\w+)*(?:\[[\w"\']+\])*)?(?:![rsa])?(?::[^}]*)?\}')
    
    # Newline pattern (literal \n in raw text before unescape)
    NEWLINE_LITERAL = re.compile(r'\\n')
    
    def __init__(self, config: Optional[dict] = None, disabled_rules: Optional[set] = None):
        self.config = config or {}
        self.disabled_rules = disabled_rules or set()
        self.max_length = self.config.get('max_length', 500)
        self.length_ratio = self.config.get('length_ratio', 3.0)  # Translation shouldn't be 3x longer
    
    def lint_file(self, filepath: str, content: Optional[str] = None) -> LintResult:
        """Lint a single file."""
        result = LintResult(disabled_rules=self.disabled_rules)
        result.files_checked = 1
        
        if content is None:
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()
            except Exception as e:
                result.add(LintIssue(
                    file=filepath,
                    line=0,
                    severity=Severity.ERROR,
                    rule="file-read-error",
                    message=_("Could not read file: {error}").format(error=e)
                ))
                return result
        
        # Determine file type
        ext = Path(filepath).suffix.lower()
        
        if ext == '.po':
            self._lint_po(filepath, content, result)
        elif ext == '.ts':
            self._lint_ts(filepath, content, result)
        else:
            result.add(LintIssue(
                file=filepath,
                line=0,
                severity=Severity.WARNING,
                rule="unknown-format",
                message=_("Unknown file format: {ext}").format(ext=ext)
            ))
        
        return result
    
    def _lint_po(self, filepath: str, content: str, result: LintResult):
        """Lint a .po file."""
        parser = POParser(content, filepath)
        self.po_parser = parser  # Store for access in check methods
        seen_msgids = {}
        entries_count = 0
        # Initialize consistency map for this file
        self.consistency_map = {}
        # Detect language for locale-specific checks
        self._current_lang = self._detect_language_from_po(filepath, parser)
        
        for entry in parser.entries:
            line = entry.get('_line', 0)
            msgid = entry.get('msgid', '')
            msgid_plural = entry.get('msgid_plural', '')
            msgstr = entry.get('msgstr', '')
            flags = entry.get('_flags', [])
            
            # Skip header entry
            if not msgid:
                continue
            
            entries_count += 1
            
            # Check: Missing translation (handle plural forms)
            if msgid_plural:
                # Plural form: check msgstr[0], msgstr[1], etc.
                has_translation = False
                for key in entry:
                    if key.startswith('msgstr[') and entry[key]:
                        has_translation = True
                        break
                if not has_translation:
                    result.add(LintIssue(
                        file=filepath,
                        line=line,
                        severity=Severity.ERROR,
                        rule="missing-translation",
                        message=_("Missing translation (empty msgstr)"),
                        context=msgid[:50]
                    ))
                # Use msgstr[0] for further checks
                msgstr = entry.get('msgstr[0]', '')
                
                # Check: Same plurals
                self._check_same_plurals(filepath, line, msgid, msgid_plural, entry, result)
            elif not msgstr:
                result.add(LintIssue(
                    file=filepath,
                    line=line,
                    severity=Severity.ERROR,
                    rule="missing-translation",
                    message=_("Missing translation (empty msgstr)"),
                    context=msgid[:50]
                ))
            
            # Check: Fuzzy
            if 'fuzzy' in flags:
                result.add(LintIssue(
                    file=filepath,
                    line=line,
                    severity=Severity.WARNING,
                    rule="fuzzy",
                    message=_("Fuzzy translation needs review"),
                    context=msgid[:50]
                ))
            
            # Check: Placeholder mismatch
            if msgstr:
                self._check_placeholders(filepath, line, msgid, msgstr, result)
            
            # Check: Length
            if msgstr:
                self._check_length(filepath, line, msgid, msgstr, result)
            
            # Check: Punctuation
            if msgstr:
                self._check_punctuation(filepath, line, msgid, msgstr, result)
            
            # Check: Capitalization
            if msgstr:
                self._check_capitalization(filepath, line, msgid, msgstr, result)
            
            # Check: Whitespace issues
            if msgstr:
                self._check_whitespace(filepath, line, msgid, msgstr, result)
            
            # Check: Quote consistency
            if msgstr:
                self._check_quotes(filepath, line, msgid, msgstr, result)
            
            # Check: HTML tags
            if msgstr:
                self._check_html_tags(filepath, line, msgid, msgstr, result)
            
            # Check: Escaped characters
            if msgstr:
                self._check_escapes(filepath, line, msgid, msgstr, result)
            
            # Check: Keyboard accelerators
            if msgstr:
                self._check_accelerators(filepath, line, msgid, msgstr, result)
            
            # Check: Numeric values
            if msgstr:
                self._check_numerics(filepath, line, msgid, msgstr, result)
            
            # Check: Untranslated English words
            if msgstr:
                self._check_untranslated(filepath, line, msgid, msgstr, result)
            
            # Check: Repeated words
            if msgstr:
                self._check_repeated_words(filepath, line, msgid, msgstr, result)
            
            # Check: Cross-newline duplicate words
            if msgstr:
                self._check_cross_newline_duplicates(filepath, line, msgid, msgstr, result)
            
            # Check: Source equals translation
            if msgstr:
                self._check_source_equals_translation(filepath, line, msgid, msgstr, result)
            
            # Check: Option value consistency
            if msgstr:
                self._check_option_values(filepath, line, msgid, msgstr, result)
            
            # Check: Swedish terminology consistency
            if msgstr:
                self._check_terminology(filepath, line, msgid, msgstr, result)
            
            # Check: Domain-specific terminology
            if msgstr:
                self._check_domain_terminology(filepath, line, msgid, msgstr, result)
            
            # Check: False friends
            if msgstr:
                self._check_false_friends(filepath, line, msgid, msgstr, result)
            
            # Check: Internal consistency
            if msgstr:
                self._check_consistency(filepath, line, msgid, msgstr, result)
            
            # Check: Typos (via aspell)
            if msgstr:
                self._check_typos(filepath, line, msgid, msgstr, result)
            
            # Check: Decimal separator (. → , in Swedish)
            if msgstr:
                self._check_decimal_separator(filepath, line, msgid, msgstr, result)
            
            # Check: Zero-width characters
            if msgstr:
                self._check_zero_width_space(filepath, line, msgid, msgstr, result)
            
            # Check: End stop mismatch
            if msgstr:
                self._check_end_stop_mismatch(filepath, line, msgid, msgstr, result)
            
            # Check: Ellipsis style
            if msgstr:
                self._check_ellipsis(filepath, line, msgid, msgstr, result)
            
            # Check: XML tags mismatch
            if msgstr:
                self._check_xml_tags_mismatch(filepath, line, msgid, msgstr, result)
            
            # Check: Duplicate words (enhanced)
            if msgstr:
                self._check_duplicate_words(filepath, line, msgid, msgstr, result)
            
            # Check: Punctuation mismatch (enhanced)
            if msgstr:
                self._check_punctuation_mismatch(filepath, line, msgid, msgstr, result)
            
            # Check: URL preservation
            if msgstr:
                self._check_url_preservation(filepath, line, msgid, msgstr, result)
            
            # Check: Escaped newline count
            if msgstr:
                self._check_escaped_newline_count(filepath, line, msgid, msgstr, result)
            
            # Check: Max length ratio
            if msgstr:
                self._check_max_length_ratio(filepath, line, msgid, msgstr, result)
            
            # Check: Duplicates (use msgctxt+msgid as key to avoid false positives)
            msgctxt = entry.get('msgctxt', '')
            dup_key = (msgctxt, msgid)
            if dup_key in seen_msgids:
                result.add(LintIssue(
                    file=filepath,
                    line=line,
                    severity=Severity.WARNING,
                    rule="duplicate",
                    message=_("Duplicate msgid (first seen at line {line})").format(line=seen_msgids[dup_key]),
                    context=msgid[:50]
                ))
            else:
                seen_msgids[dup_key] = line
        
        # Check plural forms in header and entries
        self._check_plural_forms(filepath, parser, result)
        
        result.entries_checked += entries_count
    
    def _lint_ts(self, filepath: str, content: str, result: LintResult):
        """Lint a .ts file."""
        parser = TSParser(content, filepath)
        entries_count = 0
        
        for entry in parser.entries:
            entries_count += 1
            line = entry.get('_line', 0)
            source = entry.get('source', '')
            translation = entry.get('translation', '')
            trans_type = entry.get('_type', '')
            
            # Check: Unfinished
            if trans_type == 'unfinished' or not translation:
                result.add(LintIssue(
                    file=filepath,
                    line=line,
                    severity=Severity.ERROR,
                    rule="missing-translation",
                    message=_("Unfinished/missing translation"),
                    context=source[:50]
                ))
            
            # Check: Vanished
            if trans_type == 'vanished':
                result.add(LintIssue(
                    file=filepath,
                    line=line,
                    severity=Severity.INFO,
                    rule="vanished",
                    message=_("Vanished translation (source removed)"),
                    context=source[:50]
                ))
            
            # Check: Placeholders
            if translation:
                self._check_placeholders(filepath, line, source, translation, result)
            
            # Check: Length
            if translation:
                self._check_length(filepath, line, source, translation, result)
        
        result.entries_checked += entries_count
    
    def _check_placeholders(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check for placeholder mismatches."""
        # Find all placeholders in source and translation
        for name, pattern in [
            ('printf', self.PRINTF_PATTERN),
            ('python-format', self.PYTHON_FORMAT),
            ('python-named', self.PYTHON_NAMED),
            ('qt-format', self.QT_PATTERN),
        ]:
            source_matches = sorted(pattern.findall(source))
            trans_matches = sorted(pattern.findall(translation))
            
            if source_matches != trans_matches and source_matches:
                result.add(LintIssue(
                    file=filepath,
                    line=line,
                    severity=Severity.ERROR,
                    rule="placeholder-mismatch",
                    message=_("Placeholder mismatch ({name}): source has {source}, translation has {trans}").format(
                        name=name, source=source_matches, trans=trans_matches
                    ),
                    context=source[:50]
                ))
    
    # Msgids where length checks are meaningless (translators put their own info)
    LENGTH_SKIP_MSGIDS = frozenset([
        'translator-credits', 'translator_credits',
        'translation-credits', 'translation_credits',
    ])

    def _check_length(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check for length issues."""
        # Skip meta-strings where translators write their own content
        if source.strip() in self.LENGTH_SKIP_MSGIDS:
            return
        
        # Only warn about too-long if translation is significantly longer than source
        if len(translation) > self.max_length and len(translation) > len(source) * 1.5:
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.WARNING,
                rule="too-long",
                message=_("Translation is very long ({length} chars, max {max})").format(
                    length=len(translation), max=self.max_length
                ),
                context=source[:50]
            ))
        
        if source and len(translation) > len(source) * self.length_ratio:
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.INFO,
                rule="length-ratio",
                message=_("Translation is {ratio:.1f}x longer than source").format(
                    ratio=len(translation)/len(source)
                ),
                context=source[:50]
            ))
        
        # Check for suspiciously short translation
        if source and len(source) > 10 and len(translation) < len(source) * 0.2:
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.WARNING,
                rule="suspicious-length",
                message=_("Translation is suspiciously short ({ratio:.1f}x of source)").format(
                    ratio=len(translation)/len(source)
                ),
                context=source[:50]
            ))
    
    def _check_punctuation(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check for punctuation mismatches."""
        if not source or not translation:
            return
        
        # Treat '...' and '…' (U+2026) as equivalent
        source_stripped = source.rstrip()
        trans_stripped = translation.rstrip()
        if (source_stripped.endswith('...') and trans_stripped.endswith('\u2026')) or \
           (source_stripped.endswith('\u2026') and trans_stripped.endswith('...')):
            return
        
        # Check ending punctuation
        end_punct = '.!?:;'
        source_end = source_stripped[-1] if source_stripped else ''
        trans_end = trans_stripped[-1] if trans_stripped else ''
        
        if source_end in end_punct and trans_end not in end_punct:
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.WARNING,
                rule="inconsistent-punctuation",
                message=_("Missing ending punctuation (source ends with '{char}')").format(char=source_end),
                context=source[:50]
            ))
        elif source_end not in end_punct and trans_end in end_punct:
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.INFO,
                rule="inconsistent-punctuation",
                message=_("Extra ending punctuation (source has none)"),
                context=source[:50]
            ))
    
    def _check_capitalization(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check for capitalization mismatches."""
        if not source or not translation:
            return
        
        # Get first letter of each
        source_first = next((c for c in source if c.isalpha()), None)
        trans_first = next((c for c in translation if c.isalpha()), None)
        
        if source_first and trans_first:
            if source_first.isupper() and trans_first.islower():
                result.add(LintIssue(
                    file=filepath,
                    line=line,
                    severity=Severity.WARNING,
                    rule="inconsistent-capitalization",
                    message=_("Source starts with uppercase, translation with lowercase"),
                    context=source[:50]
                ))
    
    def _check_whitespace(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check for whitespace issues."""
        # Trailing whitespace (only spaces/tabs, not newlines)
        # Don't flag if source also has trailing whitespace
        if translation != translation.rstrip(' \t') and source == source.rstrip(' \t'):
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.WARNING,
                rule="trailing-whitespace",
                message=_("Translation has trailing whitespace"),
                context=source[:50]
            ))
        
        # Missing trailing space: source ends with space but translation doesn't
        if source.endswith(' ') and not translation.endswith(' ') and translation:
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.WARNING,
                rule="missing-trailing-space",
                message=_("Source ends with space but translation does not"),
                context=translation[-50:]
            ))
        
        # Missing leading space: source starts with space but translation doesn't
        if source.startswith(' ') and not translation.startswith(' ') and translation:
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.WARNING,
                rule="missing-leading-space",
                message=_("Source starts with space but translation does not"),
                context=translation[:50]
            ))
        
        # Double spaces — only between words (not leading indentation)
        # Skip when source also has double spaces (intentional formatting)
        has_double = False
        if '  ' not in source:
            for tline in translation.split('\n'):
                stripped = tline.lstrip()
                if '  ' in stripped:
                    if re.search(r'\w  +\w', stripped):
                        has_double = True
                        break
        if has_double:
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.INFO,
                rule="double-spaces",
                message=_("Translation contains double spaces between words"),
                context=source[:50]
            ))
    
    def _check_quotes(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check for quote consistency."""
        # Skip strings containing HTML attributes (href="...", src="...", etc.)
        # where straight quotes inside tags are expected alongside typographic quotes in text
        if re.search(r'<[^>]+="[^"]*"', translation):
            return
        
        # Detect mixed quote styles
        straight_quotes = translation.count('"') + translation.count("'")
        curly_quotes = translation.count('\u201c') + translation.count('\u201d') + translation.count('\u2018') + translation.count('\u2019')
        german_quotes = translation.count('\u201e')  # Only „ (U+201E), don't re-count chars in curly_quotes
        
        quote_styles = sum(1 for c in [straight_quotes, curly_quotes, german_quotes] if c > 0)
        if quote_styles > 1:
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.INFO,
                rule="mixed-quotes",
                message=_("Translation has mixed quote styles"),
                context=source[:50]
            ))
    
    # Real HTML tags only (exclude man page B<>, I<>, shell redirects, math comparisons)
    _REAL_HTML_TAG = re.compile(
        r'</?(?:a|b|i|u|p|br|hr|em|tt|li|ul|ol|dl|dt|dd|td|th|tr|div|span|pre|code|strong|'
        r'table|thead|tbody|img|font|center|blockquote|h[1-6]|sup|sub|small|big|'
        r'input|select|option|form|label|textarea|button)(?:\s[^>]*)?>',
        re.IGNORECASE
    )

    def _check_html_tags(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check for HTML tag mismatches.
        
        Only flags when both source and translation contain HTML-like tags,
        to avoid false positives where <option> in source is descriptive
        text translated to <flagga> in Swedish (not actual HTML).
        """
        source_tags = sorted(self._REAL_HTML_TAG.findall(source))
        trans_tags = sorted(self._REAL_HTML_TAG.findall(translation))
        
        # Skip if translation has no HTML tags at all — source tags are likely
        # descriptive terms (e.g., <option> → <flagga>) not actual markup
        if source_tags != trans_tags and source_tags and trans_tags:
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.ERROR,
                rule="html-tag-mismatch",
                message=_("HTML tags mismatch: source has {source}, translation has {trans}").format(
                    source=source_tags, trans=trans_tags
                ),
                context=source[:50]
            ))
    
    def _check_escapes(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check for escaped character mismatches (newlines, tabs, etc.)."""
        # Count actual escape characters (after unescape has been applied)
        escape_chars = {'\n': '\\n', '\t': '\\t', '\r': '\\r'}
        
        source_counts = {char: source.count(char) for char in escape_chars}
        trans_counts = {char: translation.count(char) for char in escape_chars}
        
        # Find mismatches
        mismatches = []
        for char, name in escape_chars.items():
            src_count = source_counts[char]
            trans_count = trans_counts[char]
            if src_count != trans_count and src_count > 0:
                mismatches.append(f"{name}: {src_count}→{trans_count}")
        
        if mismatches:
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.ERROR,
                rule="escaped-chars-mismatch",
                message=_("Escape character count mismatch: {details}").format(
                    details=", ".join(mismatches)
                ),
                context=source[:50].replace('\n', '\\n')
            ))
    
    @staticmethod
    def _strip_html_entities(text: str) -> str:
        """Remove HTML entities like &amp; &lt; &gt; &quot; to avoid false accelerator matches."""
        return re.sub(r'&[a-zA-Z]+;', '', text)

    def _check_accelerators(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check keyboard accelerator consistency."""
        # Strip HTML entities before checking — &amp; is not an accelerator
        source_clean = self._strip_html_entities(source)
        trans_clean = self._strip_html_entities(translation)
        source_accels = self.ACCELERATOR_PATTERN.findall(source_clean)
        trans_accels = self.ACCELERATOR_PATTERN.findall(trans_clean)
        
        # Check if accelerator exists in source but not translation
        if source_accels and not trans_accels:
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.WARNING,
                rule="keyboard-shortcut-missing",
                message=_("Keyboard accelerator missing in translation"),
                context=source[:50]
            ))
        
        # Check for Nordic chars as accelerators
        for accel in trans_accels:
            if accel in self.NORDIC_CHARS:
                result.add(LintIssue(
                    file=filepath,
                    line=line,
                    severity=Severity.ERROR,
                    rule="nordic-accelerator",
                    message=_("Nordic character '{char}' used as keyboard accelerator").format(char=accel),
                    context=source[:50]
                ))
    
    def _check_numerics(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check that numbers in source appear in translation."""
        # Find all numbers in source
        source_nums = set(re.findall(r'\b\d+(?:\.\d+)?\b', source))
        trans_nums = set(re.findall(r'\b\d+(?:\.\d+)?\b', translation))
        
        # Numbers in source but not in translation
        missing = source_nums - trans_nums
        if missing and len(source_nums) <= 3:  # Only inform for few numbers
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.INFO,
                rule="numeric-mismatch",
                message=_("Numbers {nums} from source missing in translation").format(nums=missing),
                context=source[:50]
            ))
    
    def _check_untranslated(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check for common English words left in translation."""
        # Only check if source looks English
        if not any(w in source.lower() for w in ['the', 'and', 'is', 'are']):
            return
        
        trans_words = set(re.findall(r'\b[a-zA-Z]+\b', translation.lower()))
        found_english = trans_words & self.COMMON_ENGLISH
        
        # Remove words that also appear in source (might be intentional)
        source_words = set(re.findall(r'\b[a-zA-Z]+\b', source.lower()))
        suspicious = found_english - source_words
        
        # Also check if translation contains source words
        if len(suspicious) >= 3:  # Only warn if multiple common words
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.WARNING,
                rule="untranslated-words",
                message=_("Translation may contain untranslated English: {words}").format(
                    words=list(suspicious)[:5]
                ),
                context=source[:50]
            ))
    
    def _check_repeated_words(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check for repeated words."""
        words = re.findall(r'\b(\w+)\s+\1\b', translation, re.IGNORECASE)
        if words:
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.WARNING,
                rule="repeated-words",
                message=_("Repeated word: '{word}'").format(word=words[0]),
                context=source[:50]
            ))
    
    def _check_cross_newline_duplicates(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check for words duplicated across newline boundaries (e.g. 'word\\nword')."""
        lines = translation.split('\n')
        for i in range(len(lines) - 1):
            end_words = lines[i].rstrip().split()
            start_words = lines[i + 1].lstrip().split()
            if not end_words or not start_words:
                continue
            end_word = end_words[-1].strip('.,;:!?"\'()[]{}')
            start_word = start_words[0].strip('.,;:!?"\'()[]{}')
            # Skip short words (prepositions etc.), markdown headers, list markers, digits
            if (len(end_word) < 3 or len(start_word) < 3
                    or end_word.startswith('#') or end_word.startswith('-')
                    or end_word.startswith('*') or end_word.startswith('>')
                    or end_word.isdigit()):
                continue
            if end_word.lower() == start_word.lower():
                result.add(LintIssue(
                    file=filepath,
                    line=line,
                    severity=Severity.WARNING,
                    rule="cross-newline-duplicate",
                    message=_("Word '{word}' duplicated across line break").format(word=end_word),
                    context=source[:50]
                ))
                break  # One report per entry is enough
    
    # Patterns for false positive detection in source-equals-translation
    _CAMELCASE_RE = re.compile(r'^[A-Z][a-z]+(?:[A-Z][a-z]+)+$')
    _ALLCAPS_RE = re.compile(r'^[A-Z][A-Z0-9_\-./: ]{0,60}$')
    _IDENTIFIER_RE = re.compile(r'^[A-Za-z_][A-Za-z0-9_.\-]+$')
    _FORMAT_ONLY_RE = re.compile(r'^[%\-\d.#+ *]*[sdifcpxXeEgGulLhq]+$')
    _PATH_RE = re.compile(r'^[/~]|^[a-z]+://')
    # Enhanced false positive detection patterns
    _EMAIL_RE = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
    _URL_RE = re.compile(r'^https?://[^\s]+$')
    _FILEPATH_RE = re.compile(r'^[/\\]|^[a-zA-Z]:[/\\]|^\./|^\.\./|^~/')
    _FORMAT_SPECIFIER_RE = re.compile(r'^%[sd%]$|^%\d*\.\d*[sd]$|^%\d+\$[sd]$')
    _PROGRAMMING_KEYWORD_RE = re.compile(r'^(null|true|false|void|int|str|string|bool|boolean|float|double|long|short|char|byte|const|static|public|private|protected|if|else|for|while|switch|case|break|continue|return|import|from|class|def|function|var|let|const)$', re.IGNORECASE)
    _BRAND_WORDS = {
        'canon', 'epson', 'hp', 'nikon', 'sony', 'samsung', 'fuji', 'fujifilm',
        'kodak', 'olympus', 'pentax', 'panasonic', 'leica', 'ricoh', 'sigma',
    }
    _COMMON_ENGLISH_SRC_EQ = {
        'the', 'is', 'are', 'was', 'were', 'been', 'have', 'has', 'had',
        'this', 'that', 'will', 'would', 'could', 'should', 'for', 'with',
        'from', 'into', 'your', 'you', 'can', 'not', 'and', 'but', 'which',
        'when', 'where', 'what', 'how', 'why', 'also', 'only', 'must', 'may',
    }

    def _is_likely_false_positive_src_eq(self, source: str) -> bool:
        """Check if source-equals-translation is likely a false positive."""
        s = source.strip()
        if len(s) <= 3:
            return True
        if not any(c.isalpha() for c in s):
            return True
        if self._FORMAT_ONLY_RE.match(s):
            return True
        if self._PATH_RE.match(s):
            return True
        if self._CAMELCASE_RE.match(s):
            return True
        if self._ALLCAPS_RE.match(s) and len(s) <= 30:
            return True
        if self._IDENTIFIER_RE.match(s) and ' ' not in s:
            return True
        # Enhanced false positive detection (from task requirements)
        if self._EMAIL_RE.match(s):
            return True
        if self._URL_RE.match(s):
            return True
        if self._FILEPATH_RE.match(s):
            return True
        if self._FORMAT_SPECIFIER_RE.match(s):
            return True
        if self._PROGRAMMING_KEYWORD_RE.match(s):
            return True
        words = s.split()
        if words and words[0].startswith('-'):
            return True
        if len(words) == 1:
            if s[0].isupper():
                return True
            if s.islower() and len(s) <= 15 and s.lower() not in self._COMMON_ENGLISH_SRC_EQ:
                return True
        if len(words) == 2 and all(w[0].isupper() for w in words if w):
            return True
        if any(w.lower() in self._BRAND_WORDS for w in words):
            return True
        special_chars = sum(1 for c in s if c in '=|<>[]{}()@#$')
        if special_chars >= 2:
            return True
        placeholders = self.PRINTF_PATTERN.findall(s)
        alpha_len = sum(1 for c in s if c.isalpha())
        if placeholders and alpha_len < 10:
            return True
        if re.match(r'^[\d.,x\u00d7X\s]+(?:DPI|dpi|mm|cm|in|pt|px|lpi)\b', s):
            return True
        if re.match(r'^[\d.,xX\u00d7\s\-]+(?:\s+(?:in|mm|cm))?\s*(?:label|sheet)?$', s.strip()):
            return True
        paper_keywords = {'iso', 'jis', 'ansi', 'letter', 'legal', 'tabloid', 'executive', 'super', 'folio'}
        if len(words) <= 4 and any(w.lower() in paper_keywords for w in words):
            return True
        if re.search(r'version\s+[\d.]+', s, re.IGNORECASE):
            return True
        if alpha_len < len(s) * 0.3 and len(s) > 3:
            return True
        if '@' in s or '${' in s:
            return True
        if re.match(r'^(?:Extra|Channel|Slot|Tray|Bin|Mode|Type|Level)\s+\d+$', s):
            return True
        return False

    def _check_source_equals_translation(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check if translation is identical to source."""
        if len(source) < 5 or not any(c.isalpha() for c in source):
            return
        if source == translation:
            if self._is_likely_false_positive_src_eq(source):
                return
            words = set(w.lower() for w in re.findall(r'[a-zA-Z]+', source))
            has_english = bool(words & self._COMMON_ENGLISH_SRC_EQ)
            severity = Severity.WARNING if len(source) > 30 and has_english else Severity.INFO
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=severity,
                rule="source-equals-translation",
                message=_("Translation is identical to source (possibly untranslated)"),
                context=source[:80]
            ))
    
    def _check_option_values(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check for inconsistent option value placeholders."""
        # Find option values like --option=VALUE or --option VALUE
        source_values = set(self.OPTION_VALUE_PATTERN.findall(source))
        
        if not source_values:
            return
        
        # Check if these values appear in translation
        for value in source_values:
            # Value should either be kept as-is or translated consistently
            # Check if the value is missing entirely (not even translated)
            value_lower = value.lower()
            trans_lower = translation.lower()
            
            # Look for the value in translation (case-insensitive)
            if value not in translation and value_lower not in trans_lower:
                # Check if there's a similar uppercase word that might be the translation
                trans_upper_words = re.findall(r'\b[A-ZÅÄÖ][A-ZÅÄÖ0-9_]+\b', translation)
                if not trans_upper_words:
                    result.add(LintIssue(
                        file=filepath,
                        line=line,
                        severity=Severity.WARNING,
                        rule="option-value-missing",
                        message=_("Option value '{value}' from source not found in translation").format(value=value),
                        context=source[:50]
                    ))


    def _check_number_localization(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check that numbers use localized formatting (e.g. 1,000 → 1 000 in Swedish)."""
        # Find comma-separated numbers in translation that look like English formatting
        english_nums = self.NUMBER_WITH_COMMAS.findall(translation)
        if english_nums:
            # Check if source also has them (might be intentional)
            source_nums = self.NUMBER_WITH_COMMAS.findall(source)
            if english_nums and source_nums:
                result.add(LintIssue(
                    file=filepath,
                    line=line,
                    severity=Severity.INFO,
                    rule="number-localization",
                    message=_("Number formatting may not be localized (e.g. 1,000 should be 1 000 in some locales)"),
                    context=source[:50]
                ))

    def _check_decimal_separator(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check that decimal points in numbers are localized to commas in Swedish.
        
        English: 1.5, 3.14, 0.001
        Swedish: 1,5  3,14  0,001
        
        Skip: version numbers (2.0.1), IP addresses, filenames, format strings,
              numbers identical in source and translation (likely intentional).
        """
        target_lang = getattr(self, '_current_lang', 'sv')
        if not target_lang.startswith('sv'):
            return
        
        # Find decimal numbers in translation: digit(s).digit(s)
        # Must be preceded by space/start and followed by space/end/punctuation
        decimal_pattern = re.compile(r'(?:^|(?<=[\s(=:,]))(\d+\.\d+)(?=[\s).,;:!?\n]|$)')
        
        trans_decimals = decimal_pattern.findall(translation)
        if not trans_decimals:
            return
        
        # Get decimals from source too
        source_decimals = set(decimal_pattern.findall(source))
        
        for num in trans_decimals:
            # Skip if same number exists in source (likely intentional: version, constant)
            if num in source_decimals:
                continue
            
            # Skip time formats: HH.MM where both parts are exactly 2 digits
            # (00.00, 12.30, 23.59 — Swedish uses . for time)
            parts = num.split('.')
            if len(parts) == 2 and len(parts[0]) == 2 and len(parts[1]) == 2:
                try:
                    h, m = int(parts[0]), int(parts[1])
                    if 0 <= h <= 23 and 0 <= m <= 59:
                        continue
                except ValueError:
                    pass
            
            # Skip version-like numbers (more than one dot: 2.0.1, 3.14.1)
            # Check if this number is part of a longer dotted sequence
            ver_pattern = re.compile(re.escape(num) + r'\.\d')
            if ver_pattern.search(translation):
                continue
            
            # Skip if preceded by a dot (part of version: x.1.5)
            idx = translation.find(num)
            if idx > 0 and translation[idx-1] == '.':
                continue
            
            # Skip format strings (%.2f, %3.1f)
            if idx > 0 and translation[idx-1] == '%':
                continue
            
            # Skip IP-like patterns (four dot-separated groups)
            ip_pattern = re.compile(r'\d+\.\d+\.\d+\.\d+')
            if ip_pattern.search(translation):
                # Check if our number is part of it
                for m in ip_pattern.finditer(translation):
                    if m.start() <= idx < m.end():
                        break
                else:
                    # Not part of IP, flag it
                    result.add(LintIssue(
                        file=filepath,
                        line=line,
                        severity=Severity.WARNING,
                        rule="decimal-separator",
                        message=_("Decimal point «{num}» should use comma in Swedish (e.g. {fix})").format(
                            num=num, fix=num.replace('.', ',')),
                        context=source[:60],
                    ))
                continue
            
            # Skip filenames (word.ext pattern)
            if idx > 0:
                before = translation[:idx]
                if re.search(r'[a-zA-Z]$', before):
                    continue  # looks like filename.ext
            
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.WARNING,
                rule="decimal-separator",
                message=_("Decimal point «{num}» should use comma in Swedish (e.g. {fix})").format(
                    num=num, fix=num.replace('.', ',')),
                context=source[:60],
            ))

    def _check_currency_localization(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check currency format localization."""
        # Strip printf positional args (%1$s) before checking — $ there is not currency
        clean_source = self.PRINTF_POSITIONAL.sub('', source)
        clean_trans = self.PRINTF_POSITIONAL.sub('', translation)
        source_currencies = self.CURRENCY_PATTERN.findall(clean_source)
        if source_currencies:
            trans_currencies = self.CURRENCY_PATTERN.findall(clean_trans)
            # If source has currency symbols and translation has identical ones, might not be localized
            if source_currencies and source_currencies == trans_currencies:
                result.add(LintIssue(
                    file=filepath,
                    line=line,
                    severity=Severity.INFO,
                    rule="currency-localization",
                    message=_("Currency format may need localization"),
                    context=source[:50]
                ))

    def _check_date_format(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check date format localization."""
        for pattern in self.DATE_PATTERNS[:2]:  # Skip ISO format
            source_dates = pattern.findall(source)
            if source_dates:
                trans_dates = pattern.findall(translation)
                if trans_dates:
                    result.add(LintIssue(
                        file=filepath,
                        line=line,
                        severity=Severity.WARNING,
                        rule="date-format",
                        message=_("Date format may not be localized"),
                        context=source[:50]
                    ))
                    break

    def _check_newline_mismatch(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check that the number of newlines matches between source and translation."""
        source_newlines = source.count('\n')
        trans_newlines = translation.count('\n')
        if source_newlines != trans_newlines:
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.WARNING,
                rule="newline-mismatch",
                message=_("Newline count mismatch: source has {src}, translation has {trans}").format(
                    src=source_newlines, trans=trans_newlines
                ),
                context=source[:50]
            ))

    def _check_python_format(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check Python {}-format strings specifically."""
        source_braces = sorted(self.PYTHON_BRACE_FORMAT.findall(source))
        trans_braces = sorted(self.PYTHON_BRACE_FORMAT.findall(translation))
        
        if source_braces and source_braces != trans_braces:
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.ERROR,
                rule="python-format",
                message=_("Python format string mismatch: source has {src}, translation has {trans}").format(
                    src=source_braces, trans=trans_braces
                ),
                context=source[:50]
            ))

    def _detect_language_from_po(self, filepath: str, po_parser: 'POParser') -> str:
        """Detect target language from PO file header or filename."""
        # Check for Language header in PO file
        for entry in po_parser.entries[:5]:  # Check first few entries for header
            if 'msgid' in entry and entry['msgid'] == '':
                msgstr = entry.get('msgstr', '')
                # Look for Language: sv or similar
                if 'Language:' in msgstr:
                    lang_match = re.search(r'Language:\s*([a-z]{2,3})', msgstr)
                    if lang_match:
                        return lang_match.group(1)
        
        # Fall back to filename detection
        filename = Path(filepath).name.lower()
        if '.sv.' in filename or filename.endswith('.sv.po'):
            return 'sv'
        # Add more languages as needed
        return ''

    def _detect_domain_from_content(self, source_text: str) -> str:
        """Detect domain from source text content."""
        source_lower = source_text.lower()
        
        # Music domain keywords
        music_keywords = {'staff', 'note', 'chord', 'tempo', 'clef', 'measure', 'bar', 'scale', 'key'}
        if any(keyword in source_lower for keyword in music_keywords):
            return 'music'
        
        # Web platform domain keywords
        web_keywords = {'tracker', 'repository', 'commit', 'merge', 'branch', 'pull request', 'issue'}
        if any(keyword in source_lower for keyword in web_keywords):
            return 'web'
        
        # Mail domain keywords
        mail_keywords = {'envelope', 'relay', 'bounce', 'smtp', 'pop3', 'imap', 'mailbox'}
        if any(keyword in source_lower for keyword in mail_keywords):
            return 'mail'
        
        return ''

    def _check_terminology(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check for common Swedish terminology mistakes."""
        if not hasattr(self, 'po_parser'):
            return
        
        lang = self._detect_language_from_po(filepath, self.po_parser)
        if lang != 'sv':
            return
        
        # Swedish terminology rules
        terminology_rules = {
            'redaktör': ('redigerare', 'editor in software context'),
            'otydlig': ('luddig', 'fuzzy translation term'),
            'öppen källa': ('öppen källkod', 'open source'),
            'repostera': ('skicka om', 'repost is not a Swedish word'),
            'reposta': ('skicka om', 'repost is not a Swedish word'),
        }
        
        # Check mixed usage of omfång/omfattning for "range/scope"
        if 'omfång' in translation.lower() and 'omfattning' not in translation.lower():
            pass  # OK, using one consistently
        # Flag "repostera/reposta" variants
        for anglicism in ['forwarda', 'patcha', 'committa', 'pusha', 'mergea', 'fetcha', 'brancha', 'deploya']:
            if anglicism in translation.lower():
                result.add(LintIssue(
                    file=filepath,
                    line=line,
                    severity=Severity.WARNING,
                    rule="terminology",
                    message=_("Swedish: '{word}' is an anglicism, use Swedish equivalent").format(word=anglicism),
                    context=translation[:80]
                ))
        
        # Check Swedish menu terms: "Fil" as menu name must be "Arkiv"
        if source.strip() == 'File' and translation.strip() == 'Fil':
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.ERROR,
                rule="terminology",
                message=_("Swedish menu: 'File' menu must be 'Arkiv', not 'Fil'"),
                context=translation[:80]
            ))
        
        # Other menu term checks
        menu_terms = {
            'Edit': ('Redigera', 'Redigera'),
            'View': ('Visa', 'Visa'),
            'Tools': ('Verktyg', 'Verktyg'),
            'Help': ('Hjälp', 'Hjälp'),
            'Settings': ('Inställningar', 'Inställningar'),
            'Preferences': ('Inställningar', 'Inställningar'),
        }
        src_stripped = source.strip()
        tr_stripped = translation.strip()
        if src_stripped in menu_terms:
            expected, _desc = menu_terms[src_stripped]
            if tr_stripped and tr_stripped != expected and len(tr_stripped) < 30:
                result.add(LintIssue(
                    file=filepath,
                    line=line,
                    severity=Severity.WARNING,
                    rule="terminology",
                    message=_("Swedish menu: '{src}' should be '{expected}', got '{got}'").format(
                        src=src_stripped, expected=expected, got=tr_stripped),
                    context=translation[:80]
                ))

        # Check "linje" when source says "line" in CLI context
        source_lower = source.lower()
        if 'line' in source_lower and 'linje' in translation.lower():
            # In CLI/programming context, "line" should be "rad" not "linje"
            if any(kw in source_lower for kw in ['line number', 'line ', 'lines', 'command line', 'on line']):
                result.add(LintIssue(
                    file=filepath,
                    line=line,
                    severity=Severity.WARNING,
                    rule="terminology",
                    message=_("Swedish terminology: prefer 'rad' over 'linje' in CLI/programming context"),
                    context=translation[:80]
                ))
        
        # Check y/n → j/n
        
        if re.search(r'\by/n\b|\by/N\b|\bY/n\b|\bY/N\b', translation):
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.WARNING,
                rule="terminology",
                message=_("Swedish: 'y/n' should be 'j/n' (ja/nej)"),
                context=translation[:80]
            ))
        
        translation_lower = translation.lower()
        for wrong_term, (correct_term, context_note) in terminology_rules.items():
            if wrong_term in translation_lower:
                result.add(LintIssue(
                    file=filepath,
                    line=line,
                    severity=Severity.WARNING,
                    rule="terminology",
                    message=_("Swedish terminology: prefer '{correct}' over '{wrong}' ({context})").format(
                        correct=correct_term, wrong=wrong_term, context=context_note
                    ),
                    context=translation[:80]
                ))

    def _check_domain_terminology(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check for domain-specific terminology mistakes."""
        if not hasattr(self, 'po_parser'):
            return
        
        lang = self._detect_language_from_po(filepath, self.po_parser)
        if lang != 'sv':
            return
        
        domain = self._detect_domain_from_content(source)
        if not domain:
            return
        
        translation_lower = translation.lower()
        
        if domain == 'music':
            music_rules = {
                'personal': ('notsystem/notrad', 'staff (music)'),
                'belopp': ('värde', 'amount (music)'),
                'stoppning': ('utfyllnad', 'padding'),
                'rörelse': ('sats', 'movement (music)'),
                'röst': ('stämma', 'voice (music part)'),
                'slips': ('bindebåge', 'tie (music)'),
            }
            
            for wrong_term, (correct_term, context_note) in music_rules.items():
                if wrong_term in translation_lower:
                    result.add(LintIssue(
                        file=filepath,
                        line=line,
                        severity=Severity.WARNING,
                        rule="domain-terminology",
                        message=_("Music domain terminology: prefer '{correct}' over '{wrong}' ({context})").format(
                            correct=correct_term, wrong=wrong_term, context=context_note
                        ),
                        context=translation[:80]
                    ))
        
        elif domain == 'web':
            web_rules = {
                'spårare': ('ärendehanterare', 'tracker (issue)'),
            }
            
            for wrong_term, (correct_term, context_note) in web_rules.items():
                if wrong_term in translation_lower:
                    result.add(LintIssue(
                        file=filepath,
                        line=line,
                        severity=Severity.WARNING,
                        rule="domain-terminology",
                        message=_("Web platform terminology: prefer '{correct}' over '{wrong}' ({context})").format(
                            correct=correct_term, wrong=wrong_term, context=context_note
                        ),
                        context=translation[:80]
                    ))

    def _check_false_friends(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check for Swedish-English false friends."""
        if not hasattr(self, 'po_parser'):
            return
        
        lang = self._detect_language_from_po(filepath, self.po_parser)
        if lang != 'sv':
            return
        
        false_friends = {
            'actual': ('aktuell', 'faktisk/verklig'),
            'eventually': ('eventuellt', 'slutligen/till slut'),
            'patron': ('patron', 'kund/beskyddare'),
            'billion': ('biljon', 'miljard'),
            'chef': ('chef', 'kock'),  # Only in cooking context
        }
        
        source_lower = source.lower()
        translation_lower = translation.lower()
        
        for english_word, (wrong_swedish, correct_swedish) in false_friends.items():
            if english_word in source_lower and wrong_swedish in translation_lower:
                # Special handling for chef - only flag in cooking context
                if english_word == 'chef' and not any(cook_word in source_lower for cook_word in ['cook', 'kitchen', 'recipe', 'food']):
                    continue
                
                result.add(LintIssue(
                    file=filepath,
                    line=line,
                    severity=Severity.WARNING,
                    rule="false-friends",
                    message=_("False friend: '{english}' should be '{correct}', not '{wrong}'").format(
                        english=english_word, correct=correct_swedish, wrong=wrong_swedish
                    ),
                    context=f"{source[:40]} → {translation[:40]}"
                ))

    def _check_consistency(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check internal consistency within the file."""
        if not hasattr(self, 'consistency_map'):
            self.consistency_map = {}
        
        # Skip very short or technical strings
        if len(source) < 10 or not any(c.isalpha() for c in source):
            return
        
        # Use source as key, excluding msgctxt for now (could be enhanced)
        source_key = source.strip()
        
        if source_key in self.consistency_map:
            existing_translation = self.consistency_map[source_key]
            if existing_translation != translation and translation:
                result.add(LintIssue(
                    file=filepath,
                    line=line,
                    severity=Severity.INFO,
                    rule="consistency",
                    message=_("Inconsistent translation: same source has different translations"),
                    context=f"'{source[:40]}' → '{existing_translation[:30]}' vs '{translation[:30]}'"
                ))
        else:
            if translation:  # Only store non-empty translations
                self.consistency_map[source_key] = translation


    # Pattern-based typo detection (no external dictionary needed)
    # Doubled consonants that are likely typos (Swedish allows some doubles like ll, nn, ss, tt, etc.)
    _TYPO_DOUBLED_RE = re.compile(
        r'([bcdfghjkmpqvwxz])\1{2,}'  # Triple+ consonants are always wrong
        r'|([^lnrstdgk])(\2)'  # Doubled consonants that are rare in Swedish (except l,n,r,s,t,d,g,k)
        , re.IGNORECASE
    )
    # Common Swedish misspelling patterns (curated, low false positive)
    _COMMON_TYPOS = {
        # Doubled characters
        'ogiltligt': 'ogiltigt', 'borttagninngsnivå': 'borttagningsnivå',
        'innget': 'inget', 'inngen': 'ingen', 'meedd': 'med',
        'fölljande': 'följande', 'tilllåta': 'tillåta', 'tilllåt': 'tillåt',
        'annvändare': 'användare', 'annvänds': 'används', 'annvända': 'använda',
        'innstallera': 'installera', 'elller': 'eller',
        'upppil': 'uppil', 'upppilen': 'uppilen',
        # Transpositions / missing chars
        'defintions': 'definitions', 'definiton': 'definition',
        'destintation': 'destination', 'altenativ': 'alternativ',
        'kataolg': 'katalog', 'felakitg': 'felaktig', 'felaktgt': 'felaktigt',
        'tillåttet': 'tillåtet', 'filnamm': 'filnamn',
        'varabel': 'variabel', 'specifercera': 'specificera',
        'konfiguartion': 'konfiguration', 'proccess': 'process',
        'argumnet': 'argument', 'arguement': 'argument',
        'övversätt': 'översätt', 'reedan': 'redan',
        'inställnig': 'inställning', 'inställnignar': 'inställningar',
        'standdard': 'standard', 'verision': 'version',
        'kommmando': 'kommando', 'katalogg': 'katalog',
        'aktvieras': 'aktiveras', 'aktvierad': 'aktiverad',
        'uppkoplling': 'uppkoppling',
        'rättighetter': 'rättigheter', 'utskift': 'utskrift',
    }

    def _check_typos(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check for typos in translation using pattern-based detection."""
        # Skip very short strings
        if len(translation) < 8 or not any(c.isalpha() for c in translation):
            return
        
        # Clean the translation
        clean = re.sub(r'%[sd\d$.#+ -]*[sdifcpxXeEgGulLhqn]', ' ', translation)
        clean = re.sub(r'<[^>]+>', ' ', clean)
        clean = re.sub(r'\\[nt"\\]', ' ', clean)
        clean = re.sub(r'\{[^}]+\}', ' ', clean)
        clean = re.sub(r'&\w+;', ' ', clean)
        
        typos_found = []
        
        # Check for known common typos
        words = re.findall(r'\b(\w+)\b', clean)
        for w in words:
            wl = w.lower()
            if wl in self._COMMON_TYPOS:
                typos_found.append(f"{w} → {self._COMMON_TYPOS[wl]}")
        
        # Check for highly suspicious patterns only (minimize false positives)
        # Quadruple+ letters are always wrong (but skip date patterns and exclamations)
        for m in re.finditer(r'\b([a-zåäö]*([a-zåäö])\2\2\2[a-zåäö]*)\b', clean):
            word = m.group(1)
            # Skip date/time format patterns (åååå=year, mmmm=month, dddd=day, etc.)
            if re.match(r'^[åmdhs]+$', word, re.IGNORECASE):
                continue
            # Skip intentional exclamations in game/dialog text (neeeej, jooooo)
            if re.match(r'^[a-zåäö]{1,3}([a-zåäö])\1{3,}[a-zåäö]?$', word):
                continue
            # Skip format placeholders (uxxxx, etc.)
            if re.match(r'^[ux]+$', word):
                continue
            typos_found.append(word)
        
        # Specific doubled-error patterns (NOT valid compound boundaries)
        # "nng" at non-boundary (e.g., "borttagninngsnivå" but NOT "inngång")
        for m in re.finditer(r'\b([a-zåäö]*nng[a-zåäö]*)\b', clean):
            word = m.group(1)
            # Skip known valid: inngång → no, that's also wrong. "nng" is almost always a typo in Swedish
            if len(word) > 5:
                typos_found.append(word)
        
        if typos_found:
            # Deduplicate and report first 3
            unique = list(dict.fromkeys(typos_found))[:3]
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.WARNING,
                rule="typo",
                message=_("Possible typo(s): {words}").format(words=', '.join(unique)),
                context=source[:50]
            ))

    def _check_plural_forms(self, filepath: str, parser: 'POParser', result: LintResult):
        """Check plural forms in header and entries."""
        # Known correct plural forms per language
        KNOWN_PLURALS = {
            'sv': {'nplurals': 2, 'formula': '(n != 1)', 'desc': 'Swedish'},
            'da': {'nplurals': 2, 'formula': '(n != 1)', 'desc': 'Danish'},
            'de': {'nplurals': 2, 'formula': '(n != 1)', 'desc': 'German'},
            'en': {'nplurals': 2, 'formula': '(n != 1)', 'desc': 'English'},
            'es': {'nplurals': 2, 'formula': '(n != 1)', 'desc': 'Spanish'},
            'fi': {'nplurals': 2, 'formula': '(n != 1)', 'desc': 'Finnish'},
            'fr': {'nplurals': 2, 'formula': '(n > 1)', 'desc': 'French'},
            'it': {'nplurals': 2, 'formula': '(n != 1)', 'desc': 'Italian'},
            'nb': {'nplurals': 2, 'formula': '(n != 1)', 'desc': 'Norwegian Bokmål'},
            'nb_NO': {'nplurals': 2, 'formula': '(n != 1)', 'desc': 'Norwegian Bokmål'},
            'nl': {'nplurals': 2, 'formula': '(n != 1)', 'desc': 'Dutch'},
            'pt_BR': {'nplurals': 2, 'formula': '(n > 1)', 'desc': 'Brazilian Portuguese'},
            'pt': {'nplurals': 2, 'formula': '(n != 1)', 'desc': 'Portuguese'},
            'pl': {'nplurals': 3, 'formula': '(n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2)', 'desc': 'Polish'},
            'ru': {'nplurals': 3, 'formula': '(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2)', 'desc': 'Russian'},
            'ja': {'nplurals': 1, 'formula': '0', 'desc': 'Japanese'},
            'ko': {'nplurals': 1, 'formula': '0', 'desc': 'Korean'},
            'zh_CN': {'nplurals': 1, 'formula': '0', 'desc': 'Chinese Simplified'},
            'zh_TW': {'nplurals': 1, 'formula': '0', 'desc': 'Chinese Traditional'},
            'ar': {'nplurals': 6, 'formula': '(n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 ? 4 : 5)', 'desc': 'Arabic'},
            'cs': {'nplurals': 3, 'formula': '(n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2', 'desc': 'Czech'},
            'hu': {'nplurals': 2, 'formula': '(n != 1)', 'desc': 'Hungarian'},
            'ro': {'nplurals': 3, 'formula': '(n==1 ? 0 : (n==0 || (n%100>0 && n%100<20)) ? 1 : 2)', 'desc': 'Romanian'},
            'tr': {'nplurals': 2, 'formula': '(n > 1)', 'desc': 'Turkish'},
        }

        # Step 1: Parse header for Plural-Forms
        header_nplurals = None
        header_plural_formula = None
        header_lang = None
        
        for entry in parser.entries[:5]:
            if 'msgid' in entry and entry['msgid'] == '':
                msgstr = entry.get('msgstr', '')
                # Extract Plural-Forms header
                plural_match = re.search(
                    r'Plural-Forms:\s*nplurals\s*=\s*(\d+)\s*;\s*plural\s*=\s*([^;\\]+)',
                    msgstr
                )
                if plural_match:
                    header_nplurals = int(plural_match.group(1))
                    header_plural_formula = plural_match.group(2).strip().rstrip(';').strip()
                
                # Extract Language header
                lang_match = re.search(r'Language:\s*([a-zA-Z_]+)', msgstr)
                if lang_match:
                    header_lang = lang_match.group(1)
                break
        
        # Detect language from filename if not in header
        if not header_lang:
            filename = Path(filepath).name.lower()
            lang_match = re.search(r'\.([a-z]{2}(?:_[A-Z]{2})?)\.po$', filepath)
            if lang_match:
                header_lang = lang_match.group(1)
        
        # Step 2: Validate header Plural-Forms
        if header_lang and header_lang in KNOWN_PLURALS:
            expected = KNOWN_PLURALS[header_lang]
            
            if header_nplurals is None:
                result.add(LintIssue(
                    file=filepath,
                    line=1,
                    severity=Severity.ERROR,
                    rule="plural-header-missing",
                    message=_("Missing Plural-Forms header for {lang} (expected nplurals={n})").format(
                        lang=expected['desc'], n=expected['nplurals']
                    ),
                    context="Plural-Forms header"
                ))
            elif header_nplurals != expected['nplurals']:
                result.add(LintIssue(
                    file=filepath,
                    line=1,
                    severity=Severity.ERROR,
                    rule="plural-header-wrong",
                    message=_("Wrong nplurals={got} for {lang} (expected nplurals={expected})").format(
                        got=header_nplurals, lang=expected['desc'],
                        expected=expected['nplurals']
                    ),
                    context=f"Plural-Forms: nplurals={header_nplurals}"
                ))
            
            # Check formula for common languages
            if header_plural_formula and header_nplurals == expected['nplurals']:
                # Normalize whitespace for comparison
                norm_got = re.sub(r'\s+', '', header_plural_formula)
                norm_exp = re.sub(r'\s+', '', expected['formula'])
                # For simple 2-form languages, check the common patterns
                if expected['nplurals'] == 2:
                    valid_formulas = {
                        '(n!=1)', 'n!=1', '(n>1)', 'n>1',
                        '(n!=1);', 'n!=1;', '(n>1);', 'n>1;'
                    }
                    if header_lang in ('fr', 'pt_BR', 'tr'):
                        valid_formulas = {'(n>1)', 'n>1', '(n>1);', 'n>1;'}
                    else:
                        valid_formulas = {'(n!=1)', 'n!=1', '(n!=1);', 'n!=1;'}
                    
                    if norm_got.rstrip(';') not in {f.rstrip(';') for f in valid_formulas}:
                        result.add(LintIssue(
                            file=filepath,
                            line=1,
                            severity=Severity.WARNING,
                            rule="plural-formula-suspicious",
                            message=_("Suspicious plural formula for {lang}: got '{got}', expected '{exp}'").format(
                                lang=expected['desc'],
                                got=header_plural_formula,
                                exp=expected['formula']
                            ),
                            context="Plural-Forms"
                        ))
        
        # Step 3: Check individual plural entries
        expected_nplurals = header_nplurals or (
            KNOWN_PLURALS.get(header_lang, {}).get('nplurals') if header_lang else None
        )
        
        for entry in parser.entries:
            msgid = entry.get('msgid', '')
            msgid_plural = entry.get('msgid_plural', '')
            line = entry.get('_line', 0)
            flags = entry.get('_flags', [])
            
            if not msgid or not msgid_plural:
                continue
            
            if 'fuzzy' in flags:
                continue
            
            # Count msgstr[N] entries
            plural_forms = {}
            for key in entry:
                m = re.match(r'msgstr\[(\d+)\]', key)
                if m:
                    idx = int(m.group(1))
                    plural_forms[idx] = entry[key]
            
            if not plural_forms:
                continue
            
            # Check: correct number of plural forms
            if expected_nplurals:
                max_idx = max(plural_forms.keys()) + 1
                
                if max_idx < expected_nplurals:
                    result.add(LintIssue(
                        file=filepath,
                        line=line,
                        severity=Severity.ERROR,
                        rule="plural-forms-missing",
                        message=_("Missing plural forms: got {got}, expected {exp} (nplurals={n})").format(
                            got=max_idx, exp=expected_nplurals, n=expected_nplurals
                        ),
                        context=msgid[:50]
                    ))
                elif max_idx > expected_nplurals:
                    result.add(LintIssue(
                        file=filepath,
                        line=line,
                        severity=Severity.WARNING,
                        rule="plural-forms-extra",
                        message=_("Extra plural forms: got {got}, expected {exp} (nplurals={n})").format(
                            got=max_idx, exp=expected_nplurals, n=expected_nplurals
                        ),
                        context=msgid[:50]
                    ))
            
            # Check: empty plural forms (all should be filled)
            for idx in range(expected_nplurals or max(plural_forms.keys()) + 1):
                if idx in plural_forms and not plural_forms[idx]:
                    result.add(LintIssue(
                        file=filepath,
                        line=line,
                        severity=Severity.ERROR,
                        rule="plural-form-empty",
                        message=_("Empty msgstr[{idx}] in plural entry").format(idx=idx),
                        context=msgid[:50]
                    ))
            
            # Check: placeholders consistent across all plural forms
            if plural_forms:
                source_placeholders = set(re.findall(r'%[sd%]|%\d*\$?[sd]|\{[^}]+\}|%\([^)]+\)[sdf]', msgid))
                for idx, translation in plural_forms.items():
                    if translation:
                        trans_placeholders = set(re.findall(r'%[sd%]|%\d*\$?[sd]|\{[^}]+\}|%\([^)]+\)[sdf]', translation))
                        if source_placeholders and trans_placeholders != source_placeholders:
                            result.add(LintIssue(
                                file=filepath,
                                line=line,
                                severity=Severity.ERROR,
                                rule="plural-placeholder-mismatch",
                                message=_("Placeholder mismatch in msgstr[{idx}]: source has {src}, translation has {trans}").format(
                                    idx=idx, src=source_placeholders, trans=trans_placeholders
                                ),
                                context=msgid[:50]
                            ))

    def _check_zero_width_space(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check for zero-width Unicode characters in translations."""
        zero_width_chars = {
            '\u200B': 'Zero-width space',
            '\u200C': 'Zero-width non-joiner',
            '\u200D': 'Zero-width joiner',
            '\u200E': 'Left-to-right mark',
            '\u200F': 'Right-to-left mark',
            '\uFEFF': 'Byte order mark',
        }
        
        # Find zero-width characters in source and translation
        source_chars = {char: name for char, name in zero_width_chars.items() if char in source}
        trans_chars = {char: name for char, name in zero_width_chars.items() if char in translation}
        
        # If source doesn't have them but translation does -> warning
        extra_chars = {char: name for char, name in trans_chars.items() if char not in source_chars}
        if extra_chars:
            char_names = ', '.join(extra_chars.values())
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.WARNING,
                rule="zero-width-space",
                message=_("Translation contains zero-width characters not in source: {chars}").format(chars=char_names),
                context=translation[:50]
            ))

    def _check_end_stop_mismatch(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check that source and translation match end punctuation."""
        if not source or not translation:
            return
        
        # Ignore very short strings
        if len(source.strip()) <= 4:
            return
        
        source_clean = source.strip()
        trans_clean = translation.strip()
        
        # Skip if source contains common abbreviations  
        abbrev_patterns = [r'\b(Mr|Mrs|Ms|Dr|Prof|etc|vs|e\.g|i\.e)\.']
        for pattern in abbrev_patterns:
            if re.search(pattern, source_clean, re.IGNORECASE):
                return
        
        source_ends_dot = source_clean.endswith('.')
        trans_ends_dot = trans_clean.endswith('.')
        
        # Allow "..." → "…" mapping
        source_ends_ellipsis = source_clean.endswith('...')
        trans_ends_ellipsis = trans_clean.endswith('…') or trans_clean.endswith('...')
        
        if source_ends_ellipsis and trans_ends_ellipsis:
            return  # Both have ellipsis - OK
        
        if source_ends_dot and not trans_ends_dot:
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.WARNING,
                rule="end-stop-mismatch",
                message=_("Source ends with period but translation does not"),
                context=source[:50]
            ))
        elif trans_ends_dot and not source_ends_dot and not source_ends_ellipsis:
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.WARNING,
                rule="end-stop-mismatch",
                message=_("Translation ends with period but source does not"),
                context=source[:50]
            ))

    def _check_ellipsis(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check for proper ellipsis usage (... should be …)."""
        if '...' in translation:
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.INFO,
                rule="ellipsis",
                message=_("Use typographic ellipsis (…) instead of three dots (...)"),
                context=translation[:50]
            ))

    def _check_xml_tags_mismatch(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check that XML/HTML tags match between source and translation."""
        # Extract all tags from both strings
        tag_pattern = r'<(/?)([a-zA-Z][a-zA-Z0-9]*)\b[^>]*>'
        source_tags = re.findall(tag_pattern, source)
        trans_tags = re.findall(tag_pattern, translation)
        
        # Convert to sorted lists of (closing_slash, tag_name) pairs - keep case for comparison
        source_tag_list = sorted([(slash, tag) for slash, tag in source_tags])
        trans_tag_list = sorted([(slash, tag) for slash, tag in trans_tags])
        
        if source_tag_list != trans_tag_list:
            source_tag_names = [f"<{slash}{tag}>" for slash, tag in source_tag_list]
            trans_tag_names = [f"<{slash}{tag}>" for slash, tag in trans_tag_list]
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.WARNING,
                rule="xml-tags-mismatch",
                message=_("XML/HTML tags mismatch: source has {src}, translation has {trans}").format(
                    src=source_tag_names, trans=trans_tag_names
                ),
                context=source[:50]
            ))

    def _check_duplicate_words(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Enhanced check for duplicate words, with Swedish exceptions."""
        words = translation.lower().split()
        
        # Check for triple words (always wrong)
        for i in range(len(words) - 2):
            if words[i] == words[i + 1] == words[i + 2] and words[i].isalpha():
                result.add(LintIssue(
                    file=filepath,
                    line=line,
                    severity=Severity.WARNING,
                    rule="duplicate-words",
                    message=_("Triple duplicate word: '{word}'").format(word=words[i]),
                    context=translation[:50]
                ))
        
        # Check for double words with Swedish exceptions
        swedish_ok_doubles = {'i i', 'på på', 'till till', 'om om'}
        for i in range(len(words) - 1):
            if words[i] == words[i + 1] and words[i].isalpha():
                double_phrase = f"{words[i]} {words[i + 1]}"
                if double_phrase not in swedish_ok_doubles:
                    result.add(LintIssue(
                        file=filepath,
                        line=line,
                        severity=Severity.WARNING,
                        rule="duplicate-words",
                        message=_("Duplicate word: '{word}'").format(word=words[i]),
                        context=translation[:50]
                    ))

    def _check_same_plurals(self, filepath: str, line: int, msgid: str, msgid_plural: str, entry: dict, result: LintResult):
        """Check that plural forms are different (not identical)."""
        if not msgid_plural:
            return
        
        # Get all msgstr[n] values
        msgstr_values = []
        for key in sorted(entry.keys()):
            if key.startswith('msgstr[') and entry[key]:
                msgstr_values.append(entry[key])
        
        if len(msgstr_values) < 2:
            return
        
        # Check if all plural forms are identical
        if len(set(msgstr_values)) == 1:
            # Exception: if source plural/singular are also identical
            if msgid != msgid_plural:
                result.add(LintIssue(
                    file=filepath,
                    line=line,
                    severity=Severity.WARNING,
                    rule="same-plurals",
                    message=_("All plural forms are identical, but source forms differ"),
                    context=msgid[:50]
                ))

    def _check_punctuation_mismatch(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Enhanced check for punctuation matching."""
        end_punctuation = {':', ';', '!', '?'}
        
        source_clean = source.strip()
        trans_clean = translation.strip()
        
        if not source_clean or not trans_clean:
            return
        
        source_end = source_clean[-1] if source_clean else ''
        trans_end = trans_clean[-1] if trans_clean else ''
        
        # Check each type of punctuation (both end and throughout text)
        for punct in end_punctuation:
            source_has_end = source_end == punct
            trans_has_end = trans_end == punct
            source_has_any = punct in source_clean
            trans_has_any = punct in trans_clean
            
            # Check end punctuation first
            if source_has_end and not trans_has_end:
                result.add(LintIssue(
                    file=filepath,
                    line=line,
                    severity=Severity.WARNING,
                    rule="punctuation-mismatch",
                    message=_("Source ends with '{punct}' but translation does not").format(punct=punct),
                    context=source[:50]
                ))
            elif trans_has_end and not source_has_end:
                # Less strict for translation having extra punctuation
                result.add(LintIssue(
                    file=filepath,
                    line=line,
                    severity=Severity.INFO,
                    rule="punctuation-mismatch",
                    message=_("Translation ends with '{punct}' but source does not").format(punct=punct),
                    context=source[:50]
                ))
            # Check general presence for punctuation like semicolon
            elif punct in [';', ':'] and source_has_any and not trans_has_any:
                result.add(LintIssue(
                    file=filepath,
                    line=line,
                    severity=Severity.WARNING,
                    rule="punctuation-mismatch",
                    message=_("Source contains '{punct}' but translation does not").format(punct=punct),
                    context=source[:50]
                ))

    def _check_url_preservation(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check that URLs in source are preserved in translation."""
        url_pattern = r'https?://[^\s<>"\']+'
        source_urls = set(re.findall(url_pattern, source))
        trans_urls = set(re.findall(url_pattern, translation))
        
        missing_urls = source_urls - trans_urls
        if missing_urls:
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.WARNING,
                rule="url-preservation",
                message=_("URLs missing in translation: {urls}").format(urls=list(missing_urls)),
                context=source[:50]
            ))

    def _check_escaped_newline_count(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check that the number of \\n in source and translation match."""
        source_count = source.count('\\n')
        trans_count = translation.count('\\n')
        
        if source_count != trans_count:
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.WARNING,
                rule="escaped-newline-count",
                message=_("Escaped newline count mismatch: source has {src}, translation has {trans}").format(
                    src=source_count, trans=trans_count
                ),
                context=source[:50]
            ))

    def _check_max_length_ratio(self, filepath: str, line: int, source: str, translation: str, result: LintResult):
        """Check that translation is not more than 3x source length."""
        if len(source.strip()) < 10:
            return  # Skip short strings
        
        if len(translation) > len(source) * 3:
            ratio = len(translation) / len(source)
            result.add(LintIssue(
                file=filepath,
                line=line,
                severity=Severity.WARNING,
                rule="max-length-ratio",
                message=_("Translation is {ratio:.1f}x longer than source (max 3x recommended)").format(ratio=ratio),
                context=source[:50]
            ))


def find_l10n_files(path: str, recursive: bool = True) -> Generator[str, None, None]:
    """Find all .po and .ts files in path."""
    path = Path(path)
    
    if path.is_file():
        if path.suffix.lower() in ('.po', '.ts'):
            yield str(path)
        return
    
    pattern = '**/*' if recursive else '*'
    for ext in ('.po', '.ts'):
        for f in path.glob(f'{pattern}{ext}'):
            yield str(f)


def fetch_github_files(repo_url: str, path_filter: str = "") -> Generator[tuple[str, str], None, None]:
    """
    Fetch l10n files from a GitHub repository.
    
    Args:
        repo_url: GitHub URL (https://github.com/owner/repo) or owner/repo
        path_filter: Optional path filter within repo
    
    Yields:
        (filepath, content) tuples
    """
    import urllib.request
    
    # Parse repo URL
    if repo_url.startswith('https://github.com/'):
        parts = repo_url.replace('https://github.com/', '').strip('/').split('/')
    elif '/' in repo_url and not repo_url.startswith('http'):
        parts = repo_url.split('/')
    else:
        raise ValueError(f"Invalid GitHub URL: {repo_url}")
    
    if len(parts) < 2:
        raise ValueError(f"Invalid GitHub URL: {repo_url}")
    
    owner, repo = parts[0], parts[1]
    
    # Use GitHub API to get repository tree
    api_url = f"https://api.github.com/repos/{owner}/{repo}/git/trees/main?recursive=1"
    
    try:
        # Try main branch
        req = urllib.request.Request(api_url, headers={'User-Agent': 'l10n-lint'})
        response = urllib.request.urlopen(req, timeout=30)
        data = json.loads(response.read().decode())
    except:
        # Try master branch
        api_url = api_url.replace('/main?', '/master?')
        req = urllib.request.Request(api_url, headers={'User-Agent': 'l10n-lint'})
        response = urllib.request.urlopen(req, timeout=30)
        data = json.loads(response.read().decode())
    
    # Find .po and .ts files
    for item in data.get('tree', []):
        filepath = item['path']
        
        if path_filter and not filepath.startswith(path_filter):
            continue
        
        if not (filepath.endswith('.po') or filepath.endswith('.ts')):
            continue
        
        # Fetch file content
        raw_url = f"https://raw.githubusercontent.com/{owner}/{repo}/main/{filepath}"
        try:
            req = urllib.request.Request(raw_url, headers={'User-Agent': 'l10n-lint'})
            content_response = urllib.request.urlopen(req, timeout=30)
            content = content_response.read().decode('utf-8')
            yield (filepath, content)
        except Exception as e:
            print(_("Warning: Could not fetch {path}: {error}").format(path=filepath, error=e), file=sys.stderr)


def fetch_url_file(url: str) -> tuple[str, str]:
    """
    Fetch a single l10n file from a URL.
    
    Args:
        url: HTTP(S) URL to a .po or .ts file
    
    Returns:
        (filename, content) tuple
    """
    import urllib.request
    
    # Validate URL
    parsed = urlparse(url)
    if parsed.scheme not in ('http', 'https'):
        raise ValueError(_("Invalid URL scheme: {scheme}").format(scheme=parsed.scheme))
    
    # Get filename from URL
    filename = Path(parsed.path).name or "remote.po"
    
    # Validate file extension
    ext = Path(filename).suffix.lower()
    if ext not in ('.po', '.ts'):
        raise ValueError(_("URL must point to a .po or .ts file, got: {ext}").format(ext=ext))
    
    # Fetch content
    req = urllib.request.Request(url, headers={
        'User-Agent': f'l10n-lint/{__version__}',
        'Accept': 'text/plain, application/octet-stream, */*',
    })
    
    response = urllib.request.urlopen(req, timeout=30)
    content = response.read().decode('utf-8')
    
    return (filename, content)


def is_url(path: str) -> bool:
    """Check if a path is an HTTP(S) URL."""
    return path.startswith('http://') or path.startswith('https://')


def generate_html_report(result: LintResult, title: str = "l10n-lint Report") -> str:
    """Generate a detailed HTML report."""
    # Count issues by rule
    rule_counts = {}
    for issue in result.issues:
        rule_counts[issue.rule] = rule_counts.get(issue.rule, 0) + 1
    
    # Count issues by file
    file_counts = {}
    for issue in result.issues:
        file_counts[issue.file] = file_counts.get(issue.file, 0) + 1
    
    # Count by severity
    errors = result.error_count
    warnings = result.warning_count
    info = sum(1 for i in result.issues if i.severity == Severity.INFO)
    
    html = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>
        :root {{
            --bg: #1a1a2e;
            --card: #16213e;
            --text: #eee;
            --error: #e74c3c;
            --warning: #f39c12;
            --info: #3498db;
            --success: #2ecc71;
        }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: var(--bg);
            color: var(--text);
            margin: 0;
            padding: 20px;
            line-height: 1.6;
        }}
        .container {{ max-width: 1200px; margin: 0 auto; }}
        h1 {{ color: var(--text); border-bottom: 2px solid var(--info); padding-bottom: 10px; }}
        h2 {{ color: var(--info); margin-top: 30px; }}
        .summary {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }}
        .stat {{
            background: var(--card);
            padding: 20px;
            border-radius: 10px;
            text-align: center;
        }}
        .stat-value {{ font-size: 2em; font-weight: bold; }}
        .stat-label {{ opacity: 0.8; font-size: 0.9em; }}
        .stat.error .stat-value {{ color: var(--error); }}
        .stat.warning .stat-value {{ color: var(--warning); }}
        .stat.info .stat-value {{ color: var(--info); }}
        .stat.success .stat-value {{ color: var(--success); }}
        table {{
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
            background: var(--card);
            border-radius: 10px;
            overflow: hidden;
        }}
        th, td {{ padding: 12px 15px; text-align: left; }}
        th {{ background: rgba(52, 152, 219, 0.2); }}
        tr:nth-child(even) {{ background: rgba(255,255,255,0.05); }}
        .severity-error {{ color: var(--error); }}
        .severity-warning {{ color: var(--warning); }}
        .severity-info {{ color: var(--info); }}
        .issue-context {{
            font-family: monospace;
            background: rgba(0,0,0,0.3);
            padding: 2px 6px;
            border-radius: 3px;
            font-size: 0.9em;
        }}
        .chart {{ margin: 20px 0; }}
        .bar {{
            height: 25px;
            margin: 5px 0;
            border-radius: 5px;
            display: flex;
            align-items: center;
            padding: 0 10px;
            font-size: 0.9em;
        }}
        .bar-error {{ background: var(--error); }}
        .bar-warning {{ background: var(--warning); }}
        .bar-info {{ background: var(--info); }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 {title}</h1>
        <p>Generated: {time.strftime("%Y-%m-%d %H:%M")}</p>
        
        <div class="summary">
            <div class="stat success">
                <div class="stat-value">{result.files_checked}</div>
                <div class="stat-label">Files checked</div>
            </div>
            <div class="stat error">
                <div class="stat-value">{errors}</div>
                <div class="stat-label">Errors</div>
            </div>
            <div class="stat warning">
                <div class="stat-value">{warnings}</div>
                <div class="stat-label">Warnings</div>
            </div>
            <div class="stat info">
                <div class="stat-value">{info}</div>
                <div class="stat-label">Info</div>
            </div>
        </div>
'''
    
    # Issues by rule
    if rule_counts:
        html += '''
        <h2>📊 Issues by Rule</h2>
        <table>
            <tr><th>Rule</th><th>Count</th><th>%</th></tr>
'''
        total = len(result.issues)
        for rule, count in sorted(rule_counts.items(), key=lambda x: -x[1]):
            pct = (count / total * 100) if total > 0 else 0
            html += f'            <tr><td>{rule}</td><td>{count}</td><td>{pct:.1f}%</td></tr>\n'
        html += '        </table>\n'
    
    # Issues by file
    if file_counts:
        html += '''
        <h2>📁 Issues by File</h2>
        <table>
            <tr><th>File</th><th>Issues</th></tr>
'''
        for filepath, count in sorted(file_counts.items(), key=lambda x: -x[1])[:20]:
            html += f'            <tr><td>{filepath}</td><td>{count}</td></tr>\n'
        html += '        </table>\n'
    
    # All issues
    if result.issues:
        html += '''
        <h2>📋 All Issues</h2>
        <table>
            <tr><th>File</th><th>Line</th><th>Severity</th><th>Rule</th><th>Message</th></tr>
'''
        for issue in sorted(result.issues, key=lambda x: (x.file, x.line)):
            sev_class = f"severity-{issue.severity.value}"
            sev_icon = "❌" if issue.severity == Severity.ERROR else "⚠️" if issue.severity == Severity.WARNING else "ℹ️"
            ctx = f'<br><span class="issue-context">{issue.context}...</span>' if issue.context else ''
            html += f'''            <tr>
                <td>{issue.file}</td>
                <td>{issue.line}</td>
                <td class="{sev_class}">{sev_icon} {issue.severity.value}</td>
                <td>{issue.rule}</td>
                <td>{issue.message}{ctx}</td>
            </tr>
'''
        html += '        </table>\n'
    else:
        html += '<p style="color: var(--success); font-size: 1.2em;">✅ No issues found!</p>\n'
    
    html += '''
    </div>
</body>
</html>'''
    
    return html


def format_output(result: LintResult, format_type: str = "text") -> str:
    """Format lint results."""
    if format_type == "json":
        return json.dumps({
            "files_checked": result.files_checked,
            "errors": result.error_count,
            "warnings": result.warning_count,
            "issues": [i.to_dict() for i in result.issues]
        }, indent=2)
    
    elif format_type == "html":
        return generate_html_report(result)
    
    elif format_type == "github":
        # GitHub Actions annotation format
        lines = []
        for issue in result.issues:
            level = "error" if issue.severity == Severity.ERROR else "warning"
            lines.append(f"::{level} file={issue.file},line={issue.line}::[{issue.rule}] {issue.message}")
        return '\n'.join(lines)
    
    elif format_type == "gnu":
        # GNU style — Emacs compilation-mode compatible
        # Format: file:line: severity: [rule] message
        lines = []
        for issue in sorted(result.issues, key=lambda x: (x.file, x.line)):
            severity = "error" if issue.severity == Severity.ERROR else "warning" if issue.severity == Severity.WARNING else "info"
            lines.append(f"{issue.file}:{issue.line}: {severity}: [{issue.rule}] {issue.message}")
        if lines:
            lines.append("")
            lines.append(f"{result.files_checked} file(s), {result.error_count} error(s), {result.warning_count} warning(s)")
        else:
            lines.append(f"{result.files_checked} file(s) checked, no issues found.")
        return '\n'.join(lines)
    
    else:  # text
        if not result.issues:
            return _("✅ {count} file(s) checked, no issues found.").format(count=result.files_checked)
        
        lines = []
        current_file = None
        
        for issue in sorted(result.issues, key=lambda x: (x.file, x.line)):
            if issue.file != current_file:
                current_file = issue.file
                lines.append(f"\n📁 {current_file}")
            
            icon = "❌" if issue.severity == Severity.ERROR else "⚠️" if issue.severity == Severity.WARNING else "ℹ️"
            lines.append(_("  {icon} Line {line}: [{rule}] {message}").format(
                icon=icon, line=issue.line, rule=issue.rule, message=issue.message
            ))
            if issue.context:
                lines.append(_("     Context: \"{context}...\"").format(context=issue.context))
        
        lines.append(_("\n📊 Summary: {files} file(s), {errors} error(s), {warnings} warning(s)").format(
            files=result.files_checked, errors=result.error_count, warnings=result.warning_count
        ))
        return '\n'.join(lines)


class TranslatedHelpFormatter(argparse.RawDescriptionHelpFormatter):
    """Custom formatter that translates argparse default strings."""
    
    def start_section(self, heading):
        # Translate section headings
        translations = {
            'positional arguments': _('positional arguments'),
            'options': _('options'),
            'optional arguments': _('options'),
        }
        heading = translations.get(heading, heading)
        super().start_section(heading)


def main():
    parser = argparse.ArgumentParser(
        description=_('l10n-lint - Linter for localization files (.po, .ts)'),
        formatter_class=TranslatedHelpFormatter,
        add_help=False,
        epilog=_("Examples:") + """
  l10n-lint ./translations/           # Lint local directory
  l10n-lint file.po                   # Lint single file
  l10n-lint https://example.com/sv.po # Lint file from URL
  l10n-lint --github owner/repo       # Lint GitHub repository
  l10n-lint -f html -o report.html .  # Generate HTML report
  l10n-lint -f json -o results.json . # Generate JSON report
        """
    )
    
    parser.add_argument('paths', nargs='*', help=_('Files or directories to lint'))
    parser.add_argument('--github', '-g', metavar='REPO', help=_('GitHub repository (owner/repo or URL)'))
    parser.add_argument('--path', '-p', metavar='PATH', default='', help=_('Path filter for GitHub repos'))
    parser.add_argument('--format', '-f', choices=['text', 'json', 'html', 'github', 'gnu'], default='text', help=_('Output format (gnu = Emacs-compatible file:line:col format)'))
    parser.add_argument('--output', '-o', metavar='FILE', help=_('Save report to file'))
    parser.add_argument('--max-length', type=int, default=500, help=_('Max translation length (default: 500)'))
    parser.add_argument('--no-recursive', action='store_true', help=_("Don't search subdirectories"))
    parser.add_argument('--strict', action='store_true', help=_('Treat warnings as errors'))
    parser.add_argument('--quiet', '-q', action='store_true', help=_('Show only summary'))
    parser.add_argument('--check', action='store_true', help=_('Exit code only, no output (for CI)'))
    parser.add_argument('--skip-fuzzy', action='store_true', help=_('Ignore fuzzy warnings'))
    parser.add_argument('--disable', metavar='RULES', help=_('Comma-separated list of rule names to disable (e.g. trailing-whitespace,keyboard-shortcut-missing)'))
    parser.add_argument('--checks', metavar='RULES', help=_('Comma-separated list of specific checks to run (e.g. terminology,false-friends,consistency)'))
    parser.add_argument('--skip-checks', metavar='RULES', help=_('Comma-separated list of specific checks to skip (e.g. terminology,domain-terminology)'))
    parser.add_argument('--terminology', action='store_true', default=True, help=_('Enable terminology checks (default: enabled)'))
    parser.add_argument('--no-terminology', action='store_false', dest='terminology', help=_('Disable terminology checks'))
    parser.add_argument('--glossary', metavar='FILE', help=_('Load custom glossary file (TSV format: wrong\tcorrect\tcontext)'))
    parser.add_argument('--verbose', '-V', action='store_true', help=_('Show detailed progress'))
    parser.add_argument('--gtk', '-G', action='store_true', help=_('Launch GTK graphical interface'))
    parser.add_argument('-h', '--help', action='help', help=_('Show this help message and exit'))
    parser.add_argument('-v', '--version', action='version', version=f'%(prog)s {__version__}',
                        help=_('Show version number and exit'))
    
    args = parser.parse_args()
    
    # Launch GTK interface if requested
    if args.gtk:
        try:
            # Try to import and run GTK interface
            gtk_script = Path(__file__).parent / "l10n_lint_gtk.py"
            if gtk_script.exists():
                import subprocess
                cmd = [sys.executable, str(gtk_script)]
                if args.paths:
                    cmd.extend(args.paths)
                sys.exit(subprocess.call(cmd))
            else:
                # Try system-installed version
                import shutil
                gtk_cmd = shutil.which("l10n-lint-gtk")
                if gtk_cmd:
                    import subprocess
                    cmd = [gtk_cmd]
                    if args.paths:
                        cmd.extend(args.paths)
                    sys.exit(subprocess.call(cmd))
                else:
                    print(_("Error: GTK interface not found. Install l10n-lint-gtk or run from source directory."), file=sys.stderr)
                    sys.exit(1)
        except Exception as e:
            print(_("Error launching GTK interface: {error}").format(error=e), file=sys.stderr)
            sys.exit(1)
    
    if not args.paths and not args.github:
        parser.print_help()
        sys.exit(1)
    
    verbose = args.verbose
    start_time = time.time()
    
    def vprint(msg):
        """Print if verbose mode is enabled."""
        if verbose:
            print(msg, file=sys.stderr)
    
    def vprint_elapsed():
        """Print elapsed time."""
        elapsed = time.time() - start_time
        vprint(_("⏱️  Elapsed time: {elapsed:.2f}s").format(elapsed=elapsed))
    
    vprint(_("🔧 l10n-lint {version} starting...").format(version=__version__))
    vprint(_("   Max length: {max}").format(max=args.max_length))
    vprint(_("   Length ratio: {ratio}x").format(ratio=3.0))
    vprint(_("   Strict mode: {strict}").format(strict=args.strict))
    vprint(_("   Output format: {fmt}").format(fmt=args.format))
    vprint(_("   Recursive: {rec}").format(rec=not args.no_recursive))
    if LOCALE_DIR:
        vprint(_("   Locale dir: {dir}").format(dir=LOCALE_DIR))
        vprint(_("   Language: {lang}").format(lang=_lang_code))
    else:
        vprint(_("   Locale: not found (using English)"))
    vprint("")
    
    disabled = set()
    if hasattr(args, 'disable') and args.disable:
        disabled = {r.strip() for r in args.disable.split(',')}
    
    # Handle new CLI arguments for terminology checks
    terminology_disabled = set()
    
    # If --no-terminology, disable all terminology checks
    if hasattr(args, 'terminology') and not args.terminology:
        terminology_disabled.update(['terminology', 'domain-terminology', 'false-friends', 'consistency'])
    
    # Handle --skip-checks
    if hasattr(args, 'skip_checks') and args.skip_checks:
        terminology_disabled.update(r.strip() for r in args.skip_checks.split(','))
    
    # Handle --checks (only run specific checks)
    if hasattr(args, 'checks') and args.checks:
        all_terminology_checks = {'terminology', 'domain-terminology', 'false-friends', 'consistency'}
        specified_checks = {r.strip() for r in args.checks.split(',')}
        # Disable checks that were not specified
        terminology_disabled.update(all_terminology_checks - specified_checks)
    
    # Merge with existing disabled rules
    disabled.update(terminology_disabled)
    
    # TODO: Handle --glossary if needed in future versions
    
    linter = L10nLinter(config={
        'max_length': args.max_length,
    }, disabled_rules=disabled)
    
    result = LintResult(disabled_rules=disabled)
    
    # Lint GitHub repo
    if args.github:
        vprint(_("🌐 GitHub mode"))
        print(_("🔍 Fetching from GitHub: {repo}").format(repo=args.github), file=sys.stderr)
        if args.path:
            vprint(_("   Path filter: {path}").format(path=args.path))
        try:
            fetch_start = time.time()
            vprint(_("   Connecting to GitHub API..."))
            files_found = 0
            for filepath, content in fetch_github_files(args.github, args.path):
                files_found += 1
                file_start = time.time()
                vprint(_("  [{n}] {path}").format(n=files_found, path=filepath))
                vprint(_("       Size: {size} bytes").format(size=len(content)))
                file_result = linter.lint_file(filepath, content)
                file_elapsed = time.time() - file_start
                result.files_checked += file_result.files_checked
                result.entries_checked += file_result.entries_checked
                result.issues.extend(file_result.issues)
                vprint(_("       Entries: {count}").format(count=file_result.entries_checked))
                vprint(_("       Parsed in {elapsed:.3f}s").format(elapsed=file_elapsed))
                if file_result.issues:
                    vprint(_("       ⚠️  Found {count} issue(s)").format(count=len(file_result.issues)))
                else:
                    vprint(_("       ✓ No issues"))
            fetch_elapsed = time.time() - fetch_start
            vprint(_("   Fetched {count} file(s) in {elapsed:.2f}s").format(
                count=files_found, elapsed=fetch_elapsed))
        except Exception as e:
            print(_("❌ GitHub error: {error}").format(error=e), file=sys.stderr)
            sys.exit(1)
    
    # Lint local files and URLs
    if args.paths:
        # Separate URLs from local paths
        url_paths = [p for p in args.paths if is_url(p)]
        local_paths = [p for p in args.paths if not is_url(p)]
        
        # Process URLs
        if url_paths:
            vprint(_("🌐 URL mode"))
            url_files = 0
            for url in url_paths:
                url_files += 1
                file_start = time.time()
                vprint(_("  [{n}] {url}").format(n=url_files, url=url))
                try:
                    filename, content = fetch_url_file(url)
                    fetch_elapsed = time.time() - file_start
                    vprint(_("       Fetched: {name} ({size} bytes) in {elapsed:.3f}s").format(
                        name=filename, size=len(content), elapsed=fetch_elapsed))
                    
                    lint_start = time.time()
                    file_result = linter.lint_file(filename, content)
                    lint_elapsed = time.time() - lint_start
                    result.files_checked += file_result.files_checked
                    result.entries_checked += file_result.entries_checked
                    result.issues.extend(file_result.issues)
                    vprint(_("       Entries: {count}").format(count=file_result.entries_checked))
                    vprint(_("       Parsed in {elapsed:.3f}s").format(elapsed=lint_elapsed))
                    if file_result.issues:
                        vprint(_("       ⚠️  Found {count} issue(s)").format(count=len(file_result.issues)))
                    else:
                        vprint(_("       ✓ No issues"))
                except Exception as e:
                    print(_("❌ URL error for {url}: {error}").format(url=url, error=e), file=sys.stderr)
                    result.add(LintIssue(
                        file=url,
                        line=0,
                        severity=Severity.ERROR,
                        rule="url-fetch-error",
                        message=_("Could not fetch URL: {error}").format(error=e)
                    ))
                    result.files_checked += 1
            
            vprint(_("   Total URL files: {count}").format(count=url_files))
        
        # Process local paths
        if local_paths:
            vprint(_("📁 Local mode"))
            local_files = 0
            for path in local_paths:
                vprint(_("📂 Scanning: {path}").format(path=path))
                scan_start = time.time()
                path_files = list(find_l10n_files(path, recursive=not args.no_recursive))
                scan_elapsed = time.time() - scan_start
                vprint(_("   Found {count} file(s) in {elapsed:.3f}s").format(
                    count=len(path_files), elapsed=scan_elapsed))
                
                for filepath in path_files:
                    local_files += 1
                    file_start = time.time()
                    file_size = Path(filepath).stat().st_size
                    vprint(_("  [{n}] {path}").format(n=local_files, path=filepath))
                    vprint(_("       Size: {size} bytes").format(size=file_size))
                    file_result = linter.lint_file(filepath)
                    file_elapsed = time.time() - file_start
                    result.files_checked += file_result.files_checked
                    result.entries_checked += file_result.entries_checked
                    result.issues.extend(file_result.issues)
                    vprint(_("       Entries: {count}").format(count=file_result.entries_checked))
                    vprint(_("       Parsed in {elapsed:.3f}s").format(elapsed=file_elapsed))
                    if file_result.issues:
                        vprint(_("       ⚠️  Found {count} issue(s)").format(count=len(file_result.issues)))
                    else:
                        vprint(_("       ✓ No issues"))
            
            vprint(_("   Total local files: {count}").format(count=local_files))
    
    # Filter out fuzzy if requested
    if args.skip_fuzzy:
        result.issues = [i for i in result.issues if i.rule != 'fuzzy']
    
    # Verbose summary
    elapsed = time.time() - start_time
    vprint("")
    vprint(_("📊 Summary:"))
    vprint(_("   Files checked: {count}").format(count=result.files_checked))
    vprint(_("   Entries checked: {count}").format(count=result.entries_checked))
    vprint(_("   Errors: {count}").format(count=result.error_count))
    vprint(_("   Warnings: {count}").format(count=result.warning_count))
    vprint(_("   Info: {count}").format(count=result.info_count))
    
    # Issue breakdown by rule
    issues_by_rule = result.issues_by_rule()
    if issues_by_rule:
        vprint(_("   Issues by rule:"))
        for rule, count in list(issues_by_rule.items())[:10]:
            vprint(_("     - {rule}: {count}").format(rule=rule, count=count))
        if len(issues_by_rule) > 10:
            vprint(_("     ... and {more} more rules").format(more=len(issues_by_rule) - 10))
    
    # Processing speed
    if elapsed > 0:
        files_per_sec = result.files_checked / elapsed
        entries_per_sec = result.entries_checked / elapsed if result.entries_checked > 0 else 0
        vprint(_("   Processing speed:"))
        vprint(_("     - {speed:.1f} files/sec").format(speed=files_per_sec))
        if entries_per_sec > 0:
            vprint(_("     - {speed:.1f} entries/sec").format(speed=entries_per_sec))
    
    vprint_elapsed()
    vprint("")
    
    # Output (unless --check mode)
    if not args.check:
        if args.quiet:
            # Just summary line
            print(_("📊 {files} file(s), {errors} error(s), {warnings} warning(s)").format(
                files=result.files_checked, errors=result.error_count, warnings=result.warning_count))
        else:
            output = format_output(result, args.format)
            if args.output:
                with open(args.output, 'w', encoding='utf-8') as f:
                    f.write(output)
                print(_("📄 Report saved to: {file}").format(file=args.output))
            else:
                print(output)
    
    # Exit code: 0=success, 1=warnings, 2=errors
    if args.strict:
        sys.exit(2 if result.error_count > 0 else (1 if result.warning_count > 0 else (1 if result.issues else 0)))
    else:
        sys.exit(2 if result.error_count > 0 else (1 if result.warning_count > 0 else 0))


if __name__ == '__main__':
    main()
