'''

Short-Term Forecasting of Regional Electrical Load Based on CatBoost Model library  (STLFLib)

The KSPEU License Copyrigth © 2025 caapel

'''

from .dependency import *
from .serviceDB import *
from .preprocessing import *
from .core import *
from .validating import *
from .EDA import *

__version__ = '1.0.12'

# гиперпараметры для центрального окна интерфейса
GUI_model = 'br3_act'  # рабочая модель

GUI_max_depth_br3_act = 7
GUI_learn_period_br3_act = 7

GUI_max_depth_br2_act = 6
GUI_learn_period_br2_act = 8