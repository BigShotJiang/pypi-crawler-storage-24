"""Unit tests for wikicorpus.filter.

NLTK is mocked so no network calls are made during testing.
``_ensure_nltk`` is patched to a no-op and ``_lemmatizer`` is pre-set to a
real WordNetLemmatizer instance (which requires only the 'wordnet' corpus to
be installed locally; if not installed the lemmatizer falls back gracefully).
"""

import unittest
from unittest.mock import patch

from wikicorpus.filter import (
    INTERPRETIVE_KEYWORDS,
    get_interpretive_sections,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_section(header: str, text: str = "Some text.") -> dict:
    return {"header": header, "text": text}


# ---------------------------------------------------------------------------
# Tests for get_interpretive_sections
# ---------------------------------------------------------------------------

class TestGetInterpretiveSections(unittest.TestCase):
    """Tests for get_interpretive_sections."""

    def test_empty_input(self):
        self.assertEqual(get_interpretive_sections([]), [])

    def test_matching_section_returned(self):
        sections = [_make_section("Attribution"), _make_section("History")]
        result = get_interpretive_sections(sections)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["header"], "Attribution")

    def test_case_insensitive_match(self):
        sections = [_make_section("AUTHENTICITY AND PROVENANCE")]
        result = get_interpretive_sections(sections)
        self.assertGreater(len(result), 0)

    def test_partial_match_in_header(self):
        # "controversy" is a keyword; "Historical controversy" should match.
        sections = [_make_section("Historical controversy")]
        result = get_interpretive_sections(sections)
        self.assertEqual(len(result), 1)

    def test_non_matching_section_excluded(self):
        sections = [_make_section("Early life"), _make_section("Works")]
        result = get_interpretive_sections(sections)
        self.assertEqual(result, [])

    def test_custom_keywords_override(self):
        sections = [
            _make_section("Scientific analysis"),
            _make_section("Attribution"),
        ]
        # With custom keywords containing only "analysis", "Attribution" should
        # not match.
        result = get_interpretive_sections(sections, keywords=("analysis",))
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["header"], "Scientific analysis")

    def test_multiple_matching_sections(self):
        sections = [
            _make_section("Forgery allegations"),
            _make_section("Authorship debate"),
            _make_section("Legacy"),
        ]
        result = get_interpretive_sections(sections)
        headers = [s["header"] for s in result]
        self.assertIn("Forgery allegations", headers)
        self.assertIn("Authorship debate", headers)
        self.assertNotIn("Legacy", headers)

    def test_section_missing_header_key(self):
        # Sections without a 'header' key should not raise.
        sections = [{"text": "No header here."}]
        result = get_interpretive_sections(sections)
        self.assertEqual(result, [])

    def test_default_keywords_constant_used(self):
        # All built-in keywords should match when present in a header.
        for kw in INTERPRETIVE_KEYWORDS:
            sections = [_make_section(kw.capitalize())]
            result = get_interpretive_sections(sections)
            self.assertEqual(len(result), 1, f"Keyword '{kw}' did not match.")


# ---------------------------------------------------------------------------
# Tests for get_candidate_sentences (NLTK mocked)
# ---------------------------------------------------------------------------

class TestGetCandidateSentences(unittest.TestCase):
    """Tests for get_candidate_sentences with NLTK bootstrapped lazily.

    To avoid triggering network downloads in CI, we patch ``_ensure_nltk``
    to a no-op and pre-install a real ``WordNetLemmatizer`` into the module
    so lemmatisation still functions (it uses only wordnet, which is a
    local file once installed).
    """

    def _run_candidates(self, sections, verb_categories=None):
        """Run get_candidate_sentences with NLTK lazy-init mocked."""
        from nltk.stem import WordNetLemmatizer
        import wikicorpus.filter as fmod
        from wikicorpus.filter import get_candidate_sentences

        with patch.object(fmod, "_ensure_nltk", return_value=None):
            # Pre-set the module-level lemmatizer so the function can use it.
            original_lemmatizer = fmod._lemmatizer
            original_ready = fmod._nltk_ready
            fmod._lemmatizer = WordNetLemmatizer()
            fmod._nltk_ready = True
            try:
                return get_candidate_sentences(sections, verb_categories=verb_categories)
            finally:
                fmod._lemmatizer = original_lemmatizer
                fmod._nltk_ready = original_ready

    def test_empty_sections(self):
        result = self._run_candidates([])
        self.assertEqual(result, [])

    def test_section_with_no_text(self):
        sections = [{"header": "Attribution", "text": ""}]
        result = self._run_candidates(sections)
        self.assertEqual(result, [])

    def test_sentence_with_epistemic_verb_detected(self):
        # "claim" is in the 'assertion' category.
        sections = [{"header": "Attribution", "text": "Scholars claim this work is genuine."}]
        result = self._run_candidates(sections)
        self.assertGreater(len(result), 0)
        self.assertIn("claim", result[0]["matched_verbs"])

    def test_verb_category_assigned(self):
        sections = [{"header": "Debate", "text": "Experts argue about the date."}]
        result = self._run_candidates(sections)
        self.assertGreater(len(result), 0)
        self.assertEqual(result[0]["verb_category"], "argumentation")

    def test_negation_detected(self):
        sections = [{"header": "Debate", "text": "Critics do not argue about this point."}]
        result = self._run_candidates(sections)
        self.assertGreater(len(result), 0)
        self.assertTrue(result[0]["negated"])

    def test_no_negation_without_negation_word(self):
        sections = [{"header": "Debate", "text": "Critics argue about this point."}]
        result = self._run_candidates(sections)
        self.assertGreater(len(result), 0)
        self.assertFalse(result[0]["negated"])

    def test_custom_verb_categories(self):
        custom = {"custom": ["posit"]}
        sections = [{"header": "Discussion", "text": "The author posits a new theory."}]
        result = self._run_candidates(sections, verb_categories=custom)
        self.assertGreater(len(result), 0)
        self.assertIn("posit", result[0]["matched_verbs"])
        self.assertEqual(result[0]["verb_category"], "custom")

    def test_sentence_without_epistemic_verb_excluded(self):
        sections = [{"header": "History", "text": "The painting was completed in 1503."}]
        result = self._run_candidates(sections)
        # No epistemic verbs should match in a purely factual sentence.
        self.assertEqual(result, [])

    def test_result_contains_required_keys(self):
        sections = [{"header": "Attribution", "text": "Scholars claim this work is genuine."}]
        result = self._run_candidates(sections)
        if result:
            keys = result[0].keys()
            for required_key in ("sentence", "section_header", "verb_category",
                                 "matched_verbs", "negated"):
                self.assertIn(required_key, keys)

    def test_section_header_propagated(self):
        sections = [{"header": "Provenance", "text": "Experts suggest the piece is authentic."}]
        result = self._run_candidates(sections)
        if result:
            self.assertEqual(result[0]["section_header"], "Provenance")


if __name__ == "__main__":
    unittest.main()
