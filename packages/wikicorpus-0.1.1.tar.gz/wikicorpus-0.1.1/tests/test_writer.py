"""Unit tests for wikicorpus.writer._safe_name (no I/O, no network)."""

import hashlib
import unittest

from wikicorpus.writer import _safe_name


def _expected_hash(name: str) -> str:
    """Return the 8-character MD5 hex suffix for *name*."""
    return hashlib.md5(name.encode("utf-8")).hexdigest()[:8]


class TestSafeName(unittest.TestCase):
    """Tests for _safe_name."""

    # ------------------------------------------------------------------
    # Basic transformations
    # ------------------------------------------------------------------

    def test_spaces_replaced_with_underscores(self):
        result = _safe_name("Painting forgeries")
        h = _expected_hash("Painting forgeries")
        self.assertIn("Painting_forgeries", result)
        self.assertTrue(result.endswith(h))

    def test_hyphens_preserved(self):
        result = _safe_name("anti-war art")
        # Hyphens should be kept in the prefix portion.
        self.assertIn("anti-war_art", result)

    def test_periods_stripped(self):
        # Periods are not in the allowed set [a-zA-Z0-9_-], so they are removed.
        result = _safe_name("U.S. history")
        self.assertNotIn(".", result)

    def test_alphanumeric_and_underscore_kept(self):
        name = "Hello_World_123"
        result = _safe_name(name)
        h = _expected_hash(name)
        # The cleaned prefix should be the name itself.
        expected_prefix = "Hello_World_123"
        self.assertTrue(result.startswith(expected_prefix))
        self.assertTrue(result.endswith(h))

    # ------------------------------------------------------------------
    # Non-ASCII and empty-after-cleaning
    # ------------------------------------------------------------------

    def test_non_ascii_stripped(self):
        name = "Über"
        result = _safe_name(name)
        h = _expected_hash(name)
        # "Über" → after stripping non-ASCII: "ber" (U is ASCII, ü is not).
        # The exact prefix depends on encoding; what matters is no error and
        # the hash suffix is appended.
        self.assertTrue(result.endswith(h))

    def test_purely_non_ascii_returns_hash_only(self):
        # A name that collapses to empty after cleaning should return only the hash.
        name = "\u4e2d\u6587"   # Chinese characters, all non-ASCII
        result = _safe_name(name)
        h = _expected_hash(name)
        self.assertEqual(result, h)

    def test_empty_string_returns_hash(self):
        name = ""
        result = _safe_name(name)
        h = _expected_hash(name)
        # Empty input: cleaned prefix is empty, so only the hash is returned.
        self.assertEqual(result, h)

    # ------------------------------------------------------------------
    # Truncation
    # ------------------------------------------------------------------

    def test_long_name_truncated_to_max_len(self):
        name = "A" * 200
        result = _safe_name(name, max_len=80)
        self.assertLessEqual(len(result), 80)

    def test_max_len_respected_exactly(self):
        name = "B" * 200
        result = _safe_name(name, max_len=40)
        self.assertLessEqual(len(result), 40)

    # ------------------------------------------------------------------
    # Uniqueness / collision prevention
    # ------------------------------------------------------------------

    def test_different_titles_produce_different_results(self):
        # "Foo Bar" and "foo bar" differ only in case, which the cleaning step
        # preserves; but even if cleaning collapsed them to the same prefix,
        # the hash suffix would differ.
        r1 = _safe_name("Foo Bar")
        r2 = _safe_name("foo bar")
        self.assertNotEqual(r1, r2)

    def test_same_title_always_produces_same_result(self):
        name = "Mona Lisa"
        self.assertEqual(_safe_name(name), _safe_name(name))

    def test_hash_suffix_always_present(self):
        for name in ["Hello", "World", "test-case", "Über", ""]:
            result = _safe_name(name)
            h = _expected_hash(name)
            self.assertTrue(
                result.endswith(h),
                f"_safe_name({name!r}) = {result!r} does not end with hash {h!r}",
            )

    def test_collision_via_hash(self):
        # Two names that would produce the same cleaned string (if hyphens
        # were stripped and underscores treated equally) must still be unique.
        r1 = _safe_name("anti-war")
        r2 = _safe_name("anti_war")
        # The cleaned prefixes are both "anti-war" and "anti_war" respectively
        # (hyphens are kept, underscores are kept), so they may still differ
        # in prefix — but the hash guarantees uniqueness regardless.
        h1 = _expected_hash("anti-war")
        h2 = _expected_hash("anti_war")
        self.assertNotEqual(h1, h2)
        self.assertTrue(r1.endswith(h1))
        self.assertTrue(r2.endswith(h2))


if __name__ == "__main__":
    unittest.main()
