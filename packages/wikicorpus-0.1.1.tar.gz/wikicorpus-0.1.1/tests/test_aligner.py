"""Unit tests for wikicorpus.aligner (pure functions only, no network)."""

import unittest

from wikicorpus.aligner import parse_property_spec, passes_property_filter


class TestParsePropertySpec(unittest.TestCase):
    """Tests for parse_property_spec."""

    def test_mandatory_suffix(self):
        mandatory, optional = parse_property_spec("P50!")
        self.assertEqual(mandatory, ["P50"])
        self.assertEqual(optional, [])

    def test_optional_suffix(self):
        mandatory, optional = parse_property_spec("P571?")
        self.assertEqual(mandatory, [])
        self.assertEqual(optional, ["P571"])

    def test_bare_token_is_mandatory(self):
        mandatory, optional = parse_property_spec("P170")
        self.assertEqual(mandatory, ["P170"])
        self.assertEqual(optional, [])

    def test_mixed_spec(self):
        mandatory, optional = parse_property_spec("P50! | P571? | P170?")
        self.assertEqual(mandatory, ["P50"])
        self.assertIn("P571", optional)
        self.assertIn("P170", optional)

    def test_multiple_mandatory(self):
        mandatory, optional = parse_property_spec("P50! | P31!")
        self.assertEqual(mandatory, ["P50", "P31"])
        self.assertEqual(optional, [])

    def test_empty_string(self):
        mandatory, optional = parse_property_spec("")
        self.assertEqual(mandatory, [])
        self.assertEqual(optional, [])

    def test_whitespace_only_tokens_ignored(self):
        mandatory, optional = parse_property_spec("P50! | | P571?")
        self.assertEqual(mandatory, ["P50"])
        self.assertEqual(optional, ["P571"])

    def test_lowercase_normalised_to_uppercase(self):
        mandatory, optional = parse_property_spec("p50!")
        self.assertEqual(mandatory, ["P50"])

    def test_bare_token_without_suffix_is_mandatory(self):
        mandatory, optional = parse_property_spec("P31 | P50?")
        self.assertIn("P31", mandatory)
        self.assertIn("P50", optional)


class TestPassesPropertyFilter(unittest.TestCase):
    """Tests for passes_property_filter."""

    def _make_entity(self, props: list[str]) -> dict:
        """Build a minimal entity dict with the given property IDs present."""
        return {"properties": {p: ["value"] for p in props}}

    def test_empty_lists_always_passes(self):
        entity = self._make_entity([])
        self.assertTrue(passes_property_filter(entity, [], []))

    def test_mandatory_all_present(self):
        entity = self._make_entity(["P50", "P31"])
        self.assertTrue(passes_property_filter(entity, ["P50", "P31"], []))

    def test_mandatory_one_missing(self):
        entity = self._make_entity(["P50"])
        self.assertFalse(passes_property_filter(entity, ["P50", "P31"], []))

    def test_optional_at_least_one_present(self):
        entity = self._make_entity(["P571"])
        self.assertTrue(passes_property_filter(entity, [], ["P571", "P170"]))

    def test_optional_none_present(self):
        entity = self._make_entity(["P31"])
        self.assertFalse(passes_property_filter(entity, [], ["P571", "P170"]))

    def test_mandatory_and_optional_both_satisfied(self):
        entity = self._make_entity(["P50", "P571"])
        self.assertTrue(passes_property_filter(entity, ["P50"], ["P571", "P170"]))

    def test_mandatory_satisfied_optional_not(self):
        entity = self._make_entity(["P50"])
        self.assertFalse(passes_property_filter(entity, ["P50"], ["P571", "P170"]))

    def test_mandatory_not_satisfied_optional_satisfied(self):
        entity = self._make_entity(["P571"])
        self.assertFalse(passes_property_filter(entity, ["P50"], ["P571"]))

    def test_entity_with_no_properties(self):
        entity = {"properties": {}}
        self.assertFalse(passes_property_filter(entity, ["P50"], []))

    def test_entity_missing_properties_key(self):
        entity = {}
        # Should not raise; entity_props defaults to {}
        self.assertFalse(passes_property_filter(entity, ["P50"], []))


if __name__ == "__main__":
    unittest.main()
