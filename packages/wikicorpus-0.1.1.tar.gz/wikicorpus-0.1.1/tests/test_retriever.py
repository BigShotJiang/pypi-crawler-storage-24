"""Unit tests for wikicorpus.retriever (pure functions only, no network)."""

import unittest

from wikicorpus.retriever import _category_api_title, _parse_sections


class TestCategoryApiTitle(unittest.TestCase):
    """Tests for _category_api_title."""

    def test_simple_label(self):
        self.assertEqual(_category_api_title("Painting forgeries"), "Category:Painting_forgeries")

    def test_already_capitalised(self):
        self.assertEqual(_category_api_title("Painting forgeries"), "Category:Painting_forgeries")

    def test_lowercase_first_letter_is_capitalised(self):
        self.assertEqual(_category_api_title("painting forgeries"), "Category:Painting_forgeries")

    def test_spaces_converted_to_underscores(self):
        result = _category_api_title("art history debates")
        self.assertEqual(result, "Category:Art_history_debates")

    def test_single_word(self):
        self.assertEqual(_category_api_title("Forgeries"), "Category:Forgeries")

    def test_leading_trailing_whitespace_stripped(self):
        self.assertEqual(_category_api_title("  Forgeries  "), "Category:Forgeries")

    def test_empty_string(self):
        # An empty name should produce "Category:" with an empty suffix.
        self.assertEqual(_category_api_title(""), "Category:")

    def test_already_has_underscores(self):
        self.assertEqual(_category_api_title("Painting_forgeries"), "Category:Painting_forgeries")


class TestParseSections(unittest.TestCase):
    """Tests for _parse_sections."""

    def test_empty_string(self):
        self.assertEqual(_parse_sections(""), [])

    def test_no_headers_returns_introduction(self):
        result = _parse_sections("Just some text with no headers.")
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["header"], "Introduction")
        self.assertEqual(result[0]["text"], "Just some text with no headers.")

    def test_single_level_header(self):
        text = "Intro text.\n\n== Section One ==\nContent of section one."
        result = _parse_sections(text)
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]["header"], "Introduction")
        self.assertIn("Intro text", result[0]["text"])
        self.assertEqual(result[1]["header"], "Section One")
        self.assertIn("Content of section one", result[1]["text"])

    def test_nested_headers(self):
        text = (
            "== Top Level ==\n"
            "Top text.\n"
            "=== Sub Section ===\n"
            "Sub text."
        )
        result = _parse_sections(text)
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]["header"], "Top Level")
        self.assertEqual(result[1]["header"], "Sub Section")

    def test_no_intro_text_before_first_header(self):
        text = "== Only Section ==\nOnly content."
        result = _parse_sections(text)
        # No intro section should be created when there is no text before the header.
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["header"], "Only Section")

    def test_multiple_sections(self):
        text = (
            "Introduction paragraph.\n\n"
            "== History ==\n"
            "History content.\n"
            "== Reception ==\n"
            "Reception content."
        )
        result = _parse_sections(text)
        headers = [s["header"] for s in result]
        self.assertIn("Introduction", headers)
        self.assertIn("History", headers)
        self.assertIn("Reception", headers)

    def test_section_text_does_not_include_header_line(self):
        text = "== Alpha ==\nAlpha body."
        result = _parse_sections(text)
        self.assertEqual(result[0]["text"], "Alpha body.")

    def test_header_with_extra_spaces(self):
        text = "==  Spaced Header  ==\nBody."
        result = _parse_sections(text)
        self.assertEqual(result[0]["header"], "Spaced Header")


if __name__ == "__main__":
    unittest.main()
