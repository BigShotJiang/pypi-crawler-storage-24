"""Corpus filtering: interpretive sections and candidate sentence extraction."""

import logging

import nltk
from nltk.stem import WordNetLemmatizer

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# NLTK resource bootstrap
# ---------------------------------------------------------------------------

_nltk_ready: bool = False
_lemmatizer: WordNetLemmatizer | None = None


def _ensure_nltk() -> None:
    """Download required NLTK resources silently if they are not present.

    Sets the module-level ``_nltk_ready`` flag and initialises ``_lemmatizer``
    so that this work is performed at most once per interpreter session.
    """
    global _nltk_ready, _lemmatizer
    if _nltk_ready:
        return
    for resource in (
        "punkt",
        "punkt_tab",
        "averaged_perceptron_tagger",
        "averaged_perceptron_tagger_eng",
        "wordnet",
    ):
        nltk.download(resource, quiet=True)
    _lemmatizer = WordNetLemmatizer()
    _nltk_ready = True


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

# Section headers that indicate interpretive content.
# Public so callers can read the defaults and extend them.
INTERPRETIVE_KEYWORDS: tuple[str, ...] = (
    "attribution",
    "provenance",
    "dating",
    "controversy",
    "authenticity",
    "authorship",
    "historiography",
    "reception",
    "debate",
    "forgery",
    "misattribution",
    "reattribution",
)

# Epistemic verb categories used for candidate sentence detection.
VERB_CATEGORIES: dict[str, list[str]] = {
    "argumentation": [
        "argue", "dispute", "contend", "refute", "contest", "challenge", "oppose",
    ],
    "assertion": [
        "claim", "state", "declare", "assert", "report", "attribute", "ascribe",
    ],
    "epistemic_uncertainty": [
        "believe", "think", "suppose", "assume", "suspect", "doubt",
        "question", "suggest",
    ],
    "inference": [
        "conclude", "deduce", "infer", "imply", "indicate", "derive", "propose",
    ],
    "revision": [
        "revise", "reassign", "reattribute", "reconsider", "overturn",
        "correct", "update",
    ],
}

_NEGATION_WORDS: frozenset[str] = frozenset({"not", "never", "no"})

# Penn Treebank verb POS tags.
_VERB_POS_PREFIX = "VB"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def get_interpretive_sections(
    sections: list[dict],
    keywords: tuple[str, ...] | None = None,
) -> list[dict]:
    """Filter sections whose header signals interpretive content.

    Matching is case-insensitive and partial (substring check).

    Args:
        sections: List of section dicts with keys ``'header'`` and ``'text'``.
        keywords: Tuple of lowercase keyword strings to match against section
            headers.  Defaults to :data:`INTERPRETIVE_KEYWORDS` when ``None``.

    Returns:
        Subset of *sections* whose headers match at least one keyword.
        Returns an empty list if no section matches.
    """
    active = keywords if keywords is not None else INTERPRETIVE_KEYWORDS
    result: list[dict] = []
    for section in sections:
        header_lower = section.get("header", "").lower()
        if any(kw in header_lower for kw in active):
            result.append(section)
    return result


def get_candidate_sentences(
    sections: list[dict],
    verb_categories: dict[str, list[str]] | None = None,
) -> list[dict]:
    """Extract sentences containing epistemic verbs from a list of sections.

    For each sentence the function:

    1. Tokenises with ``nltk.word_tokenize``.
    2. POS-tags with ``nltk.pos_tag``.
    3. Lemmatises every verb token (``VB*`` tags) with
       :class:`nltk.stem.WordNetLemmatizer`.
    4. Checks the lemma against *verb_categories*.
    5. Detects negation (``not``, ``never``, ``no``) within the three
       tokens that immediately precede each matched verb.

    NLTK resources are downloaded lazily on the first call to this function.

    Args:
        sections: List of section dicts with keys ``'header'`` and ``'text'``.
        verb_categories: Dict mapping category name to list of verb lemmas.
            Defaults to :data:`VERB_CATEGORIES` when ``None``.  A flat
            lemma→category lookup is derived from this dict at call time, so
            passing a custom dict fully controls which verbs are matched.

    Returns:
        List of dicts with keys:

        - ``'sentence'`` (str)
        - ``'section_header'`` (str)
        - ``'verb_category'`` (str) – first matched category name.
        - ``'matched_verbs'`` (list[str]) – all matched lemmas in the sentence.
        - ``'negated'`` (bool) – ``True`` if a negation word precedes any
          matched verb.
    """
    _ensure_nltk()

    active_cats = verb_categories if verb_categories is not None else VERB_CATEGORIES
    verb_to_category: dict[str, str] = {
        verb: category
        for category, verbs in active_cats.items()
        for verb in verbs
    }

    candidates: list[dict] = []

    for section in sections:
        text = section.get("text", "")
        if not text:
            continue

        try:
            sentences = nltk.sent_tokenize(text)
        except Exception as exc:
            logger.warning("Sentence tokenisation failed: %s", exc)
            continue

        for sentence in sentences:
            try:
                tokens = nltk.word_tokenize(sentence)
                tagged: list[tuple[str, str]] = nltk.pos_tag(tokens)
            except Exception as exc:
                logger.warning("Tokenisation/tagging failed: %s", exc)
                continue

            matched_verbs: list[str] = []
            first_category: str | None = None
            negated = False

            for i, (token, pos) in enumerate(tagged):
                if not pos.startswith(_VERB_POS_PREFIX):
                    continue

                lemma = _lemmatizer.lemmatize(token.lower(), pos="v")
                category = verb_to_category.get(lemma)
                if category is None:
                    continue

                matched_verbs.append(lemma)
                if first_category is None:
                    first_category = category

                # Check for negation within 3 tokens before this verb.
                window_start = max(0, i - 3)
                preceding = {t.lower() for t, _ in tagged[window_start:i]}
                if preceding & _NEGATION_WORDS:
                    negated = True

            if matched_verbs:
                candidates.append(
                    {
                        "sentence": sentence,
                        "section_header": section.get("header", ""),
                        "verb_category": first_category,
                        "matched_verbs": matched_verbs,
                        "negated": negated,
                    }
                )

    return candidates
