"""Wikipedia article retrieval utilities."""

import logging
import re
import time

import requests

from wikicorpus import HEADERS

logger = logging.getLogger(__name__)

API_URL = "https://en.wikipedia.org/w/api.php"


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _category_api_title(category_name: str) -> str:
    """Convert a human-readable category name to a Wikipedia API category title.

    Handles capitalisation and space-to-underscore conversion so callers can
    pass plain labels such as ``'Painting forgeries'``.

    Args:
        category_name: Human-readable category label.

    Returns:
        A string of the form ``'Category:Painting_forgeries'``.
    """
    normalised = category_name.strip().replace(" ", "_")
    if normalised:
        normalised = normalised[0].upper() + normalised[1:]
    return f"Category:{normalised}"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def resolve_category_url(category_name: str) -> str:
    """Resolve a human-readable category name to its full Wikipedia URL.

    Args:
        category_name: Human-readable category label, e.g. ``'Painting forgeries'``.

    Returns:
        Full URL such as
        ``'https://en.wikipedia.org/wiki/Category:Painting_forgeries'``.
    """
    api_title = _category_api_title(category_name)          # "Category:Foo_bar"
    name_part = api_title[len("Category:"):]               # "Foo_bar"
    return f"https://en.wikipedia.org/wiki/Category:{name_part}"


def get_category_articles(category_name: str) -> list[dict]:
    """Retrieve all articles belonging to a Wikipedia category.

    Uses the ``categorymembers`` list endpoint and handles pagination via
    ``cmcontinue`` so that categories with more than 500 members are fully
    retrieved.

    Args:
        category_name: Human-readable category label.

    Returns:
        List of dicts, each with keys ``'title'`` and ``'url'``.
    """
    cat_title = _category_api_title(category_name)
    articles: list[dict] = []

    params: dict = {
        "action": "query",
        "list": "categorymembers",
        "cmtitle": cat_title,
        "cmlimit": 500,
        "cmnamespace": 0,   # article namespace only
        "format": "json",
    }

    while True:
        try:
            response = requests.get(
                API_URL, params=params, headers=HEADERS, timeout=30
            )
            response.raise_for_status()
            data = response.json()
        except Exception as exc:
            logger.warning("Error fetching category '%s': %s", category_name, exc)
            break

        members = data.get("query", {}).get("categorymembers", [])
        for member in members:
            title = member["title"]
            articles.append(
                {
                    "title": title,
                    "url": (
                        "https://en.wikipedia.org/wiki/"
                        + title.replace(" ", "_")
                    ),
                }
            )

        if "continue" in data:
            params["cmcontinue"] = data["continue"]["cmcontinue"]
            time.sleep(1)
        else:
            break

    return articles


def get_article_content(title: str) -> dict:
    """Retrieve the full plain-text content of a Wikipedia article.

    Makes two API calls:

    1. ``prop=extracts`` to get the full plain-text extract with section
       headers formatted as wiki markup (``== Header ==``).
    2. ``prop=links`` to get internal Wikipedia links (namespace 0).

    A 1-second delay is applied between the two calls only when the extract
    fetch succeeds.

    Args:
        title: Wikipedia article title.

    Returns:
        Dict with keys:

        - ``'title'`` (str) – article title.
        - ``'full_text'`` (str) – complete plain-text extract.
        - ``'sections'`` (list[dict]) – each entry has ``'header'`` and
          ``'text'`` keys.
        - ``'links'`` (list[str]) – titles of internally linked articles.
    """
    # ------------------------------------------------------------------
    # 1. Fetch extract
    # ------------------------------------------------------------------
    extract_params = {
        "action": "query",
        "prop": "extracts",
        "explaintext": True,
        "exsectionformat": "wiki",
        "titles": title,
        "format": "json",
    }

    full_text = ""
    _fetch_ok = False
    try:
        response = requests.get(
            API_URL, params=extract_params, headers=HEADERS, timeout=30
        )
        response.raise_for_status()
        data = response.json()
        pages = data.get("query", {}).get("pages", {})
        if pages:
            page = next(iter(pages.values()))
            full_text = page.get("extract", "")
        _fetch_ok = True
    except Exception as exc:
        logger.warning("Error fetching extract for '%s': %s", title, exc)

    sections = _parse_sections(full_text)

    if _fetch_ok:
        time.sleep(1)

    # ------------------------------------------------------------------
    # 2. Fetch internal links (with pagination)
    # ------------------------------------------------------------------
    links: list[str] = []
    link_params: dict = {
        "action": "query",
        "prop": "links",
        "pllimit": "max",
        "plnamespace": 0,
        "titles": title,
        "format": "json",
    }

    data: dict = {}
    while True:
        try:
            response = requests.get(
                API_URL, params=link_params, headers=HEADERS, timeout=30
            )
            response.raise_for_status()
            data = response.json()
            pages = data.get("query", {}).get("pages", {})
            if pages:
                page = next(iter(pages.values()))
                for link in page.get("links", []):
                    links.append(link["title"])
        except Exception as exc:
            logger.warning("Error fetching links for '%s': %s", title, exc)
            break

        if "continue" in data:
            link_params["plcontinue"] = data["continue"]["plcontinue"]
            time.sleep(1)
        else:
            break

    return {
        "title": title,
        "full_text": full_text,
        "sections": sections,
        "links": links,
    }


# ---------------------------------------------------------------------------
# Section parsing
# ---------------------------------------------------------------------------

_SECTION_RE = re.compile(r"^(={2,6})\s*(.+?)\s*\1\s*$", re.MULTILINE)


def _parse_sections(text: str) -> list[dict]:
    """Parse a Wikipedia plain-text extract into a list of sections.

    Section boundaries are detected by lines matching ``== Header ==``
    (two to six equals signs).  Text before the first header is returned
    as an ``'Introduction'`` section.

    Args:
        text: Plain-text extract from the Wikipedia API.

    Returns:
        List of dicts with keys ``'header'`` (str) and ``'text'`` (str).
    """
    if not text:
        return []

    matches = list(_SECTION_RE.finditer(text))

    if not matches:
        return [{"header": "Introduction", "text": text.strip()}]

    sections: list[dict] = []

    intro = text[: matches[0].start()].strip()
    if intro:
        sections.append({"header": "Introduction", "text": intro})

    for idx, match in enumerate(matches):
        header = match.group(2).strip()
        start = match.end()
        end = matches[idx + 1].start() if idx + 1 < len(matches) else len(text)
        body = text[start:end].strip()
        sections.append({"header": header, "text": body})

    return sections
