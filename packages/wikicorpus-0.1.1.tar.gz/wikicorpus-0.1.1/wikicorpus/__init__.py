"""wikicorpus: retrieve and filter Wikipedia articles for knowledge extraction."""

__version__ = "0.1.1"

HEADERS: dict[str, str] = {"User-Agent": "wikicorpus/0.1 (research project)"}
