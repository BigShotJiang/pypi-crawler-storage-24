"""Wikidata entity alignment utilities."""

import logging

import requests

from wikicorpus import HEADERS

logger = logging.getLogger(__name__)

WIKIDATA_API = "https://www.wikidata.org/w/api.php"


def get_wikidata_entity(wikipedia_title: str) -> dict | None:
    """Query Wikidata for the entity linked to a Wikipedia article.

    Calls ``wbgetentities`` with ``sites=enwiki`` to look up the entity by
    its Wikipedia page title.

    Args:
        wikipedia_title: Wikipedia article title (e.g. ``'Mona Lisa'``).

    Returns:
        Dict with keys:

        - ``'qid'`` (str) – Wikidata item ID (e.g. ``'Q12418'``).
        - ``'labels'`` (dict[str, str]) – language code → label string.
        - ``'properties'`` (dict[str, list[str]]) – property ID → list of
          value strings.

        Returns ``None`` if no entity is found or the request fails.
    """
    params = {
        "action": "wbgetentities",
        "sites": "enwiki",
        "titles": wikipedia_title,
        "props": "claims|labels",
        "format": "json",
    }

    try:
        response = requests.get(
            WIKIDATA_API, params=params, headers=HEADERS, timeout=30
        )
        response.raise_for_status()
        data = response.json()
    except Exception as exc:
        logger.warning(
            "Error fetching Wikidata entity for '%s': %s", wikipedia_title, exc
        )
        return None

    entities = data.get("entities", {})
    if not entities:
        return None

    entity_id, entity_data = next(iter(entities.items()))

    # "-1" signals that no matching entity was found.
    if entity_id == "-1":
        return None

    # ------------------------------------------------------------------
    # Labels
    # ------------------------------------------------------------------
    labels: dict[str, str] = {}
    for lang, label_data in entity_data.get("labels", {}).items():
        try:
            labels[lang] = label_data["value"]
        except (KeyError, TypeError):
            pass

    # ------------------------------------------------------------------
    # Claims → properties
    # ------------------------------------------------------------------
    properties: dict[str, list[str]] = {}
    for prop_id, claim_list in entity_data.get("claims", {}).items():
        values: list[str] = []
        for claim in claim_list:
            try:
                mainsnak = claim.get("mainsnak", {})
                datavalue = mainsnak.get("datavalue", {})
                value = datavalue.get("value")
                if value is None:
                    continue
                if isinstance(value, str):
                    values.append(value)
                elif isinstance(value, dict):
                    if "id" in value:           # entity reference (Q-item)
                        values.append(value["id"])
                    elif "text" in value:       # monolingual text
                        values.append(value["text"])
                    elif "time" in value:       # time value
                        values.append(value["time"])
                    elif "amount" in value:     # quantity
                        values.append(str(value["amount"]))
                    else:
                        values.append(str(value))
            except Exception:
                pass
        if values:
            properties[prop_id] = values

    return {
        "qid": entity_id,
        "labels": labels,
        "properties": properties,
    }


def parse_property_spec(spec: str) -> tuple[list[str], list[str]]:
    """Parse a pipe-separated property specification string.

    Each token is a Wikidata property ID optionally suffixed with:

    - ``!`` – **mandatory**: every mandatory property must be present.
    - ``?`` – **optional**: at least one optional property must be present.

    Tokens with no suffix are treated as mandatory.

    Args:
        spec: String such as ``"P50! | P571? | P170?"``.

    Returns:
        A ``(mandatory, optional)`` tuple of lists of uppercase property IDs
        with suffixes stripped, e.g. ``(["P50"], ["P571", "P170"])``.
    """
    mandatory: list[str] = []
    optional: list[str] = []
    for token in spec.split("|"):
        token = token.strip()
        if not token:
            continue
        if token.endswith("!"):
            mandatory.append(token[:-1].strip().upper())
        elif token.endswith("?"):
            optional.append(token[:-1].strip().upper())
        else:
            mandatory.append(token.upper())
    return mandatory, optional


def passes_property_filter(
    entity: dict,
    mandatory: list[str],
    optional: list[str],
) -> bool:
    """Check whether a Wikidata entity satisfies the property filter.

    Filter logic:

    - **All** mandatory properties must be present in the entity.
    - If *optional* is non-empty, **at least one** optional property must be
      present.
    - If only mandatory properties are specified, all of them must be present.
    - If only optional properties are specified, at least one must be present.
    - If both lists are non-empty, both conditions must hold simultaneously.
    - If both lists are empty the function always returns ``True``.

    Args:
        entity: Entity dict as returned by :func:`get_wikidata_entity`.
        mandatory: Property IDs that must **all** be present.
        optional: Property IDs where **at least one** must be present.

    Returns:
        ``True`` if the entity passes the filter.
    """
    entity_props = entity.get("properties", {})

    if not all(prop in entity_props for prop in mandatory):
        return False

    if optional and not any(prop in entity_props for prop in optional):
        return False

    return True
