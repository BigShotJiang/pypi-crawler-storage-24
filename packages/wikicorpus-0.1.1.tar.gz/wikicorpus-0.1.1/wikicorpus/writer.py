"""Corpus output utilities: per-article files and root index."""

import hashlib
import json
import logging
import os
import re

logger = logging.getLogger(__name__)

_NON_ALNUM_RE = re.compile(r"[^a-zA-Z0-9_-]")


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _safe_name(name: str, max_len: int = 80) -> str:
    """Convert an arbitrary string to a safe, unique filesystem component.

    1. Computes a deterministic 8-character MD5 hash suffix from *name*.
    2. Replaces spaces with underscores.
    3. Strips every character that is not alphanumeric, an underscore, or a
       hyphen (hyphens and underscores are preserved).
    4. Truncates the cleaned prefix so the full result fits in *max_len*
       characters (prefix + ``_`` + 8-hex-hash).
    5. If the cleaned prefix is empty (e.g. purely non-ASCII input), returns
       the hash alone so the result is never an empty string.

    The MD5 suffix makes every distinct input produce a distinct output,
    preventing silent directory collisions when two article titles differ
    only in characters that are stripped by the cleaning step.

    Args:
        name: Input string (e.g. article title or category label).
        max_len: Maximum length of the returned string (default 80).

    Returns:
        A filesystem-safe string of at most *max_len* characters that is
        unique with respect to the original *name*.
    """
    short_hash = hashlib.md5(name.encode("utf-8")).hexdigest()[:8]
    cleaned = _NON_ALNUM_RE.sub("", name.replace(" ", "_"))
    prefix = cleaned[: max_len - 9]   # reserve 9 chars for "_" + 8-hex-hash
    return f"{prefix}_{short_hash}" if prefix else short_hash


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def save_article(
    article: dict,
    entity: dict | None,
    candidate_sentences: list[dict],
    output_dir: str,
    category: str,
) -> None:
    """Persist all data for a single article to disk.

    Creates the directory ``<output_dir>/<safe_category>/<safe_title>/`` and
    writes four files:

    - ``full_text.txt``  – plain-text extract.
    - ``sections.json``  – list of section dicts.
    - ``wikidata.json``  – Wikidata entity dict (or ``null``).
    - ``candidates.json``– list of candidate-sentence dicts.

    Any I/O error is logged as a warning without re-raising.

    Args:
        article: Dict returned by :func:`wikicorpus.retriever.get_article_content`.
        entity: Dict returned by :func:`wikicorpus.aligner.get_wikidata_entity`,
            or ``None``.
        candidate_sentences: List returned by
            :func:`wikicorpus.filter.get_candidate_sentences`.
        output_dir: Root output directory path.
        category: Human-readable category label used to derive the
            subdirectory name.
    """
    safe_cat = _safe_name(category)
    safe_title = _safe_name(article.get("title", "unknown"))
    article_dir = os.path.join(output_dir, safe_cat, safe_title)

    try:
        os.makedirs(article_dir, exist_ok=True)
    except OSError as exc:
        logger.warning("Could not create directory '%s': %s", article_dir, exc)
        return

    files: dict[str, object] = {
        "full_text.txt": article.get("full_text", ""),
        "sections.json": article.get("sections", []),
        "wikidata.json": entity,
        "candidates.json": candidate_sentences,
    }

    for filename, content in files.items():
        path = os.path.join(article_dir, filename)
        try:
            with open(path, "w", encoding="utf-8") as fh:
                if filename.endswith(".json"):
                    json.dump(content, fh, ensure_ascii=False, indent=2)
                else:
                    fh.write(content)  # type: ignore[arg-type]
        except OSError as exc:
            logger.warning("Could not write '%s': %s", path, exc)


def save_index(all_articles: list[dict], output_dir: str) -> None:
    """Write a root-level ``index.json`` summarising every processed article.

    Each entry in the index contains:

    - ``'title'`` (str)
    - ``'url'`` (str)
    - ``'category'`` (str)
    - ``'qid'`` (str | None) – Wikidata QID if available.
    - ``'has_target_properties'`` (bool)
    - ``'candidate_sentence_count'`` (int)
    - ``'interpretive_section_count'`` (int)

    Args:
        all_articles: List of summary dicts accumulated during the pipeline run.
            Expected keys match those listed above.
        output_dir: Root output directory where ``index.json`` is written.
    """
    index = [
        {
            "title": entry.get("title", ""),
            "url": entry.get("url", ""),
            "category": entry.get("category", ""),
            "qid": entry.get("qid"),
            "has_target_properties": entry.get("has_target_properties", False),
            "candidate_sentence_count": entry.get("candidate_sentence_count", 0),
            "interpretive_section_count": entry.get("interpretive_section_count", 0),
        }
        for entry in all_articles
    ]

    os.makedirs(output_dir, exist_ok=True)
    path = os.path.join(output_dir, "index.json")
    try:
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(index, fh, ensure_ascii=False, indent=2)
    except OSError as exc:
        logger.warning("Could not write index '%s': %s", path, exc)
