"""Command-line interface for wikicorpus."""

import argparse
import copy
import json
import logging
import os
import sys

from .aligner import get_wikidata_entity, parse_property_spec, passes_property_filter
from .filter import (
    INTERPRETIVE_KEYWORDS,
    VERB_CATEGORIES,
    get_candidate_sentences,
    get_interpretive_sections,
)
from .retriever import get_category_articles, get_article_content
from .writer import save_article, save_index

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _configure_logging(verbose: bool) -> None:
    """Set up root logging at WARNING or INFO level."""
    level = logging.INFO if verbose else logging.WARNING
    logging.basicConfig(
        format="%(levelname)s: %(message)s",
        level=level,
        stream=sys.stderr,
    )


def _parse_categories(args: argparse.Namespace) -> list[str]:
    """Extract category names from CLI arguments.

    Accepts either a pipe-delimited string (``--categories``) or a text file
    (``--categories-file``).  Exits with a helpful message when neither is
    supplied.

    Args:
        args: Parsed :class:`argparse.Namespace` object.

    Returns:
        Non-empty list of stripped category name strings.
    """
    if args.categories:
        return [c.strip() for c in args.categories.split("|") if c.strip()]

    if args.categories_file:
        path = args.categories_file
        if not os.path.isfile(path):
            sys.exit(f"Error: categories file not found: {path}")
        categories: list[str] = []
        with open(path, "r", encoding="utf-8") as fh:
            for line in fh:
                stripped = line.strip()
                if stripped and not stripped.startswith("#"):
                    categories.append(stripped)
        if not categories:
            sys.exit(f"Error: no categories found in '{path}'.")
        return categories

    # Neither flag was provided — print a helpful message and exit.
    print(
        "Error: you must supply categories via --categories or --categories-file.\n"
        "\n"
        "Examples:\n"
        '  wikicorpus --categories "Painting forgeries | Document forgeries"\n'
        "  wikicorpus --categories-file categories.txt\n"
        "\n"
        "For --categories-file, create a plain text file with one category per line:\n"
        "  # This is a comment line (ignored)\n"
        "  Painting forgeries\n"
        "  Document forgeries\n",
        file=sys.stderr,
    )
    sys.exit(1)


# ---------------------------------------------------------------------------
# Verb-category and section-keyword builders
# ---------------------------------------------------------------------------

def _build_verb_categories(args: argparse.Namespace) -> dict[str, list[str]]:
    """Construct the effective verb-category dict from CLI arguments.

    Starts from a deep copy of :data:`~wikicorpus.filter.VERB_CATEGORIES` and
    applies, in order:

    1. ``--verbs-file``: loads a JSON object mapping category names to verb
       lists and **merges** each entry into the active dict.  Existing
       categories receive the extra verbs appended (duplicates removed);
       new category names are created.
    2. ``--add-verbs``: pipe-separated list of bare lemmas appended to the
       ``'custom'`` category (created if absent).

    Args:
        args: Parsed :class:`argparse.Namespace`.

    Returns:
        Effective verb-category dict to pass to
        :func:`~wikicorpus.filter.get_candidate_sentences`.
    """
    cats: dict[str, list[str]] = copy.deepcopy(VERB_CATEGORIES)

    if args.verbs_file:
        if not os.path.isfile(args.verbs_file):
            sys.exit(f"Error: verbs file not found: {args.verbs_file}")
        try:
            with open(args.verbs_file, encoding="utf-8") as fh:
                extra: dict = json.load(fh)
        except (json.JSONDecodeError, OSError) as exc:
            sys.exit(f"Error reading verbs file: {exc}")
        if not isinstance(extra, dict):
            sys.exit("Error: verbs file must be a JSON object mapping category names to verb lists.")
        for cat_name, verbs in extra.items():
            if not isinstance(verbs, list):
                sys.exit(f"Error: verbs file entry '{cat_name}' must be a list.")
            if cat_name in cats:
                merged = list(dict.fromkeys(cats[cat_name] + [v for v in verbs if isinstance(v, str)]))
                cats[cat_name] = merged
            else:
                cats[cat_name] = [v for v in verbs if isinstance(v, str)]

    if args.add_verbs:
        extra_lemmas = [v.strip().lower() for v in args.add_verbs.split("|") if v.strip()]
        if extra_lemmas:
            existing = cats.get("custom", [])
            cats["custom"] = list(dict.fromkeys(existing + extra_lemmas))

    return cats


def _build_section_keywords(args: argparse.Namespace) -> tuple[str, ...]:
    """Construct the effective section-keyword tuple from CLI arguments.

    Starts from :data:`~wikicorpus.filter.INTERPRETIVE_KEYWORDS` and applies,
    in order:

    1. ``--sections-file``: loads a JSON array of keyword strings and
       **appends** any that are not already present.
    2. ``--add-sections``: pipe-separated keywords appended to the active list.

    Args:
        args: Parsed :class:`argparse.Namespace`.

    Returns:
        Effective keyword tuple to pass to
        :func:`~wikicorpus.filter.get_interpretive_sections`.
    """
    keywords: list[str] = list(INTERPRETIVE_KEYWORDS)

    if args.sections_file:
        if not os.path.isfile(args.sections_file):
            sys.exit(f"Error: sections file not found: {args.sections_file}")
        try:
            with open(args.sections_file, encoding="utf-8") as fh:
                extra = json.load(fh)
        except (json.JSONDecodeError, OSError) as exc:
            sys.exit(f"Error reading sections file: {exc}")
        if not isinstance(extra, list):
            sys.exit("Error: sections file must be a JSON array of keyword strings.")
        for kw in extra:
            if isinstance(kw, str):
                kw = kw.strip().lower()
                if kw and kw not in keywords:
                    keywords.append(kw)

    if args.add_sections:
        for kw in args.add_sections.split("|"):
            kw = kw.strip().lower()
            if kw and kw not in keywords:
                keywords.append(kw)

    return tuple(keywords)


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def main() -> None:
    """Entry point for the ``wikicorpus`` CLI command."""
    parser = argparse.ArgumentParser(
        prog="wikicorpus",
        description=(
            "Retrieve and filter Wikipedia articles by category "
            "to build a corpus for knowledge extraction."
        ),
    )

    # Mutually exclusive category inputs are not enforced at the argparse
    # level so we can print a custom help message when neither is given.
    parser.add_argument(
        "--categories",
        metavar='"Cat1 | Cat2"',
        help=(
            'Quoted string of Wikipedia category names separated by " | ". '
            'Example: "Painting forgeries | Document forgeries"'
        ),
    )
    parser.add_argument(
        "--categories-file",
        metavar="PATH",
        help=(
            "Path to a .txt file with one category name per line. "
            "Blank lines and lines starting with # are ignored."
        ),
    )
    parser.add_argument(
        "--output",
        default="./corpus",
        metavar="DIR",
        help="Output directory (default: ./corpus).",
    )
    parser.add_argument(
        "--filter-wikidata",
        action="store_true",
        help=(
            "Skip articles with no Wikidata entity. "
            "If --wikidata-properties is also provided, additionally require "
            "that the entity satisfies the property constraints."
        ),
    )
    parser.add_argument(
        "--wikidata-properties",
        metavar='"P50! | P571?"',
        help=(
            "Pipe-separated Wikidata property IDs controlling the property "
            "filter. Suffix each ID with ! (mandatory: all must be present) "
            "or ? (optional: at least one must be present). Tokens without a "
            "suffix are treated as mandatory. "
            'Example: "P50! | P571? | P170?". '
            "If omitted, --filter-wikidata keeps all articles that have a "
            "valid Wikidata entity, regardless of their properties."
        ),
    )
    parser.add_argument(
        "--filter-sections",
        action="store_true",
        help="Skip articles with no interpretive sections.",
    )
    parser.add_argument(
        "--filter-sentences",
        action="store_true",
        help="Skip articles with no candidate epistemic sentences.",
    )
    parser.add_argument(
        "--verbs-file",
        metavar="PATH",
        help=(
            "Path to a JSON file mapping category names to lists of verb lemmas. "
            "Merged into the built-in verb categories: existing categories gain "
            "the extra verbs; new category names are created. "
            'Example: {"revision": ["posit", "maintain"], "custom": ["allege"]}'
        ),
    )
    parser.add_argument(
        "--add-verbs",
        metavar='"verb1 | verb2"',
        help=(
            "Pipe-separated verb lemmas to add to the 'custom' verb category "
            "on top of whatever --verbs-file (or the built-in list) provides. "
            'Example: "allege | posit | maintain"'
        ),
    )
    parser.add_argument(
        "--sections-file",
        metavar="PATH",
        help=(
            "Path to a JSON file containing an array of section-header keywords. "
            "Appended to the built-in keyword list (duplicates ignored). "
            'Example: ["analysis", "interpretation", "methodology"]'
        ),
    )
    parser.add_argument(
        "--add-sections",
        metavar='"kw1 | kw2"',
        help=(
            "Pipe-separated section-header keywords to add on top of "
            "--sections-file / the built-in list. "
            'Example: "analysis | interpretation"'
        ),
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable progress logging to stderr.",
    )

    args = parser.parse_args()

    _configure_logging(args.verbose)

    # ------------------------------------------------------------------
    # Parse Wikidata property spec
    # ------------------------------------------------------------------
    mandatory_props: list[str] = []
    optional_props: list[str] = []
    props_configured = False

    if args.wikidata_properties:
        mandatory_props, optional_props = parse_property_spec(
            args.wikidata_properties
        )
        props_configured = bool(mandatory_props or optional_props)

    if args.wikidata_properties and not args.filter_wikidata:
        print(
            "Warning: --wikidata-properties is set but --filter-wikidata is not active.\n"
            "The property spec will annotate the index but no articles will be filtered.",
            file=sys.stderr,
        )

    if args.filter_wikidata and not props_configured:
        print(
            "Warning: --filter-wikidata is set but --wikidata-properties was "
            "not provided (or resolved to an empty list). "
            "All articles with a valid Wikidata entity will be retained.",
            file=sys.stderr,
        )

    # ------------------------------------------------------------------
    # Build effective verb categories and section keywords
    # ------------------------------------------------------------------
    active_verb_cats = _build_verb_categories(args)
    active_keywords = _build_section_keywords(args)

    categories = _parse_categories(args)
    os.makedirs(args.output, exist_ok=True)

    # ------------------------------------------------------------------
    # Counters for the final summary
    # ------------------------------------------------------------------
    n_retrieved = 0
    n_after_wikidata = 0
    n_after_sections = 0
    n_after_sentences = 0
    n_candidate_sentences = 0

    all_index_entries: list[dict] = []

    # ------------------------------------------------------------------
    # Main pipeline
    # ------------------------------------------------------------------
    for category in categories:
        logger.info("Processing category: %s", category)

        articles = get_category_articles(category)
        logger.info("  Found %d articles in '%s'.", len(articles), category)
        n_retrieved += len(articles)

        for article in articles:
            title = article["title"]
            logger.info("  Article: %s", title)

            # --- Fetch content ---
            content = get_article_content(title)

            # --- Wikidata alignment ---
            entity = get_wikidata_entity(title)

            # Evaluate property filter (used both for filtering and the index).
            if entity and props_configured:
                article_has_target = passes_property_filter(
                    entity, mandatory_props, optional_props
                )
            else:
                article_has_target = bool(entity)

            if args.filter_wikidata:
                if not entity:
                    logger.info("    Skipped (Wikidata filter): no entity.")
                    continue
                if props_configured and not article_has_target:
                    logger.info(
                        "    Skipped (Wikidata filter): entity present but "
                        "property constraints not satisfied."
                    )
                    continue
            n_after_wikidata += 1

            # --- Section filtering ---
            interpretive = get_interpretive_sections(
                content.get("sections", []), keywords=active_keywords
            )

            if args.filter_sections and not interpretive:
                logger.info("    Skipped (no interpretive sections).")
                continue
            n_after_sections += 1

            # --- Sentence filtering ---
            # Scan interpretive sections when they exist; otherwise fall back
            # to all sections so the sentence filter still has input.
            sections_for_candidates = interpretive or content.get("sections", [])
            candidates = get_candidate_sentences(
                sections_for_candidates, verb_categories=active_verb_cats
            )

            if args.filter_sentences and not candidates:
                logger.info("    Skipped (no candidate sentences).")
                continue
            n_after_sentences += 1
            n_candidate_sentences += len(candidates)

            # --- Persist ---
            save_article(content, entity, candidates, args.output, category)

            all_index_entries.append(
                {
                    "title": title,
                    "url": article["url"],
                    "category": category,
                    "qid": entity["qid"] if entity else None,
                    "has_target_properties": article_has_target,
                    "candidate_sentence_count": len(candidates),
                    "interpretive_section_count": len(interpretive),
                }
            )

    # ------------------------------------------------------------------
    # If no Wikidata filter was applied, the counts equal n_retrieved.
    # Fill in pass-through counts for disabled filters.
    # ------------------------------------------------------------------
    if not args.filter_wikidata:
        n_after_wikidata = n_retrieved
    if not args.filter_sections:
        n_after_sections = n_after_wikidata
    if not args.filter_sentences:
        n_after_sentences = n_after_sections

    # ------------------------------------------------------------------
    # Save root index
    # ------------------------------------------------------------------
    save_index(all_index_entries, args.output)

    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------
    if props_configured:
        prop_parts = (
            [f"{p}!" for p in mandatory_props]
            + [f"{p}?" for p in optional_props]
        )
        prop_summary = " | ".join(prop_parts)
    else:
        prop_summary = "none (all entities retained)"

    # Build human-readable config summaries for verb categories and keywords.
    verb_summary_parts = [
        f"{cat}({len(verbs)})" for cat, verbs in active_verb_cats.items()
    ]
    kw_added = [kw for kw in active_keywords if kw not in INTERPRETIVE_KEYWORDS]

    print(f"Categories processed : {len(categories)}")
    print(f"Articles retrieved   : {n_retrieved}")
    print(f"After Wikidata filter: {n_after_wikidata}")
    print(f"Wikidata properties  : {prop_summary}")
    print(f"After section filter : {n_after_sections}")
    print(f"Section keywords     : {len(active_keywords)} active"
          + (f" (+{len(kw_added)} custom: {', '.join(kw_added)})" if kw_added else ""))
    print(f"After sentence filter: {n_after_sentences}")
    print(f"Verb categories      : {', '.join(verb_summary_parts)}")
    print(f"Candidate sentences  : {n_candidate_sentences}")
    print(f"Output directory     : {os.path.abspath(args.output)}")
