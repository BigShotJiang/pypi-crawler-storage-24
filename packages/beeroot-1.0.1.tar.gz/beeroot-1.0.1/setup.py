from setuptools import setup, find_packages

setup(
    name="beeroot",
    version="1.0.1",
    description="Stop babysitting your LLM API calls. Adaptive rate gate + multi-agent pipeline.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="carlex22",
    url="https://github.com/carlex22/beeROOT",
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=[
        "requests>=2.31.0",
        "pyyaml>=6.0",
        "pandas>=2.0",
        "GitPython>=3.1.41",
    ],
    extras_require={
        "groq":   ["groq>=0.4.2"],
        "server": ["fastapi>=0.109.0", "uvicorn[standard]>=0.27.0"],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    keywords=[
        "llm", "rate-limiting", "backpressure", "multi-agent",
        "openai", "groq", "openrouter", "workflow", "yaml",
        "batch-processing", "distributed", "pipeline"
    ],
)
