import os
import subprocess
from pathlib import Path
import pytest

@pytest.fixture
def tmp_workspace(tmp_path: Path) -> Path:
    """Create a temporary workspace with 3 fake git repos."""
    for name in ["repo-alpha", "repo-beta", "repo-gamma"]:
        repo_dir = tmp_path / name
        repo_dir.mkdir()
        subprocess.run(["git", "init"], cwd=repo_dir, capture_output=True)
        subprocess.run(
            ["git", "remote", "add", "origin", f"git@gitlab.com:group/{name}.git"],
            cwd=repo_dir, capture_output=True,
        )
        (repo_dir / "README.md").write_text(f"# {name}")
        subprocess.run(["git", "add", "."], cwd=repo_dir, capture_output=True)
        subprocess.run(
            ["git", "commit", "-m", "init"],
            cwd=repo_dir, capture_output=True,
            env={**os.environ, "GIT_AUTHOR_NAME": "Test", "GIT_AUTHOR_EMAIL": "t@t.com",
                 "GIT_COMMITTER_NAME": "Test", "GIT_COMMITTER_EMAIL": "t@t.com"},
        )
    return tmp_path

@pytest.fixture
def tmp_hub(tmp_workspace: Path) -> Path:
    """Create a workspace with .project-hub initialized."""
    hub_dir = tmp_workspace / ".project-hub"
    hub_dir.mkdir()
    (hub_dir / "config.yaml").write_text("forges:\n  gitlab.com:\n    type: gitlab\n")
    (hub_dir / "workspace.md").write_text("")
    return tmp_workspace
