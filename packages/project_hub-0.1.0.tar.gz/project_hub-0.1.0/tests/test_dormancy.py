from pathlib import Path
from project_hub.core.workspace import detect_state, WorkspaceState


def test_active_when_project_hub_exists(tmp_path):
    (tmp_path / ".project-hub").mkdir()
    assert detect_state(tmp_path) == WorkspaceState.ACTIVE


def test_disabled_when_no_project_hub_file(tmp_path):
    (tmp_path / ".no-project-hub").touch()
    assert detect_state(tmp_path) == WorkspaceState.DISABLED_OPT_OUT


def test_disabled_when_no_project_hub_wins_over_project_hub(tmp_path):
    (tmp_path / ".project-hub").mkdir()
    (tmp_path / ".no-project-hub").touch()
    assert detect_state(tmp_path) == WorkspaceState.DISABLED_OPT_OUT


def test_disabled_when_parent_has_project_hub(tmp_path):
    (tmp_path / ".project-hub").mkdir()
    child = tmp_path / "sub-repo"
    child.mkdir()
    assert detect_state(child) == WorkspaceState.DISABLED_SUB_REPO


def test_dormant_when_nothing(tmp_path):
    assert detect_state(tmp_path) == WorkspaceState.DORMANT


def test_dormant_when_parent_has_no_project_hub(tmp_path):
    child = tmp_path / "some-dir"
    child.mkdir()
    assert detect_state(child) == WorkspaceState.DORMANT
