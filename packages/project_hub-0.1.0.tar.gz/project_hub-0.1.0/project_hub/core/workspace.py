from __future__ import annotations

import asyncio
from datetime import datetime
from enum import Enum
from pathlib import Path

from .cache import Cache
from .config import Config, load_config, save_config
from .discovery import discover_repos
from .events import diff_mrs, diff_pipelines, diff_vulns, filter_events
from .models import Event, EventType, Repo
from ..git.ops import check_pull_status_sync, fetch_all, fetch_one, pull_safe_one
from ..gitlab.auth import resolve_token
from ..gitlab.client import AuthenticationError, GitLabClient


class WorkspaceState(str, Enum):
    ACTIVE = "active"
    DISABLED_OPT_OUT = "disabled_opt_out"    # .no-project-hub
    DISABLED_SUB_REPO = "disabled_sub_repo"  # parent has .project-hub
    DORMANT = "dormant"


def detect_state(cwd: Path) -> WorkspaceState:
    # .no-project-hub wins over everything
    if (cwd / ".no-project-hub").exists():
        return WorkspaceState.DISABLED_OPT_OUT
    # .project-hub/ in CWD = active
    if (cwd / ".project-hub").is_dir():
        return WorkspaceState.ACTIVE
    # .project-hub/ in immediate parent = disabled (we're inside a sub-repo)
    parent = cwd.parent
    if parent != cwd and (parent / ".project-hub").is_dir():
        return WorkspaceState.DISABLED_SUB_REPO
    # Nothing found = dormant
    return WorkspaceState.DORMANT


class Workspace:
    def __init__(self, root: Path):
        self.root = root
        self.config: Config
        self.cache: Cache
        self.repos: list[Repo] = []
        self._gitlab_clients: dict[str, GitLabClient] = {}
        self._usernames: dict[str, str] = {}  # forge_host -> username
        self._sync_status: str = "idle"  # "idle" | "in_progress"
        self._refresh_running: bool = False
        self._refresh_task: asyncio.Task | None = None

    async def start(self) -> None:
        """Initialize cache, discover repos, create GitLab clients."""
        self.config = load_config(self.root / ".project-hub" / "config.yaml")
        self.cache = Cache(self.root / ".project-hub" / "cache.db")
        await self.cache.initialize()
        self.repos = discover_repos(self.root, self.config)
        self._init_gitlab_clients()

    def _init_gitlab_clients(self) -> None:
        """Create one GitLabClient per unique forge host.

        Repos whose host has no token get downgraded to has_forge=False.
        Also resolves the authenticated username for each client.
        """
        hosts = {r.forge_host for r in self.repos if r.has_forge and r.forge_host}
        for host in hosts:
            token = resolve_token(host)
            if token:
                self._gitlab_clients[host] = GitLabClient(host, token)
            else:
                for r in self.repos:
                    if r.forge_host == host:
                        r.has_forge = False
        for host, client in self._gitlab_clients.items():
            username = client.get_username()
            if username:
                self._usernames[host] = username

    @property
    def sync_status(self) -> str:
        return self._sync_status

    async def refresh_once(self, notify_callback=None) -> None:
        """Single refresh cycle. No-op if already running."""
        if self._refresh_running:
            return
        self._refresh_running = True
        try:
            await self._do_refresh(notify_callback)
        finally:
            self._refresh_running = False

    async def _do_refresh(self, notify_callback=None) -> None:
        """Fetch git + forge data, diff against cache, store, notify."""
        import logging

        logger = logging.getLogger(__name__)

        self._sync_status = "in_progress"
        try:
            await self._do_refresh_inner(logger, notify_callback)
        finally:
            self._sync_status = "idle"

    async def _do_refresh_inner(self, logger, notify_callback=None) -> None:
        repo_paths = [Path(r.path) for r in self.repos]

        # 1. Git fetch all (parallel)
        logger.info(f"Starting git fetch for {len(repo_paths)} repos...")
        await fetch_all(repo_paths)
        logger.info("Git fetch completed")

        # 1b. Pull status computation (parallel)
        pull_results = await asyncio.gather(
            *(asyncio.to_thread(check_pull_status_sync, Path(r.path)) for r in self.repos)
        )
        for repo, ps in zip(self.repos, pull_results):
            if ps is not None:
                await self.cache.store_pull_status(repo.name, ps)

        # 2. Forge data (parallel, bounded concurrency)
        semaphore = asyncio.Semaphore(10)
        auth_events: list[Event] = []
        forge_tasks = []

        for repo in self.repos:
            if not repo.has_forge or repo.forge_host not in self._gitlab_clients:
                continue
            client = self._gitlab_clients[repo.forge_host]
            forge_tasks.append(
                self._fetch_forge_for_repo(repo, client, semaphore, auth_events)
            )

        logger.info(f"Fetching forge data for {len(forge_tasks)} repos...")
        results = await asyncio.gather(*forge_tasks, return_exceptions=True)
        logger.info("Forge data fetch completed")

        # 3. Diff with cache -> generate events
        all_events: list[Event] = list(auth_events)
        total_mrs, total_pipelines, total_vulns = 0, 0, 0

        for result in results:
            if isinstance(result, Exception):
                logger.error(f"Exception during forge fetch: {result}")
                continue
            repo_name, mrs, pipelines, vulns = result

            old_mrs = await self.cache.get_mrs(repo_name)
            old_pipelines = await self.cache.get_pipelines(repo_name)
            old_vulns = await self.cache.get_vulns(repo_name)

            logger.debug(
                f"{repo_name}: {len(mrs)} MRs, {len(pipelines)} pipelines, {len(vulns)} vulns"
            )

            repo_events = (
                diff_mrs(old_mrs, mrs, repo_name)
                + diff_pipelines(old_pipelines, pipelines, repo_name)
                + diff_vulns(old_vulns, vulns, repo_name)
            )
            repo_obj = next((r for r in self.repos if r.name == repo_name), None)
            username = self._usernames.get(repo_obj.forge_host, "") if repo_obj and repo_obj.forge_host else ""
            repo_events = filter_events(
                repo_events,
                self.config.watch_mrs_mode,
                self.config.watch_pipelines_mode,
                self.config.watch_vulns_mode,
                username,
                mrs,
                pipelines,
            )
            all_events.extend(repo_events)

            total_mrs += len(mrs)
            total_pipelines += len(pipelines)
            total_vulns += len(vulns)

            # 4. Store new state
            await self.cache.store_mrs(repo_name, mrs)
            await self.cache.store_pipelines(repo_name, pipelines)
            await self.cache.store_vulns(repo_name, vulns)

        logger.info(
            f"Refresh complete: {total_mrs} MRs, {total_pipelines} pipelines, {total_vulns} vulns, {len(all_events)} events"
        )

        if all_events:
            await self.cache.store_events(all_events)
            if notify_callback:
                await notify_callback()

        # Update last refresh timestamp
        await self.cache.set_metadata("last_refresh", datetime.now().isoformat())

    async def _fetch_forge_for_repo(
        self,
        repo: Repo,
        client: GitLabClient,
        semaphore: asyncio.Semaphore,
        auth_events: list[Event],
    ) -> tuple[str, list, list, list]:
        """Fetch MR/pipeline/vuln data for one repo with semaphore."""
        async with semaphore:
            try:
                mrs = await asyncio.to_thread(
                    client.list_merge_requests, repo.project_path
                )
                for mr in mrs:
                    mr.repo_name = repo.name
                pipelines = await asyncio.to_thread(
                    client.list_pipelines, repo.project_path
                )
                for p in pipelines:
                    p.repo_name = repo.name
                vulns = await asyncio.to_thread(
                    client.get_vulnerabilities, repo.project_path
                )
                for v in vulns:
                    v.repo_name = repo.name
                return repo.name, mrs, pipelines, vulns
            except AuthenticationError:
                auth_events.append(
                    Event(
                        id=None,
                        type=EventType.AUTH_EXPIRED,
                        repo_name=repo.name,
                        summary=f"Authentication failed for {repo.forge_host}",
                        detail="",
                        created_at=datetime.now(),
                    )
                )
                return repo.name, [], [], []

    async def refresh_loop(self, notify_callback=None) -> None:
        """Periodic refresh: immediate first cycle, then every cache_ttl seconds."""
        while True:
            await self.refresh_once(notify_callback)
            await asyncio.sleep(self.config.cache_ttl)

    async def stop(self) -> None:
        """Cancel refresh task and close cache."""
        if self._refresh_task:
            self._refresh_task.cancel()
            try:
                await self._refresh_task
            except asyncio.CancelledError:
                pass
        await self.cache.close()

    def get_state(self) -> dict:
        """Return current workspace state for the web UI."""
        return {"repos": self.repos, "ready": True}

    def get_state_dict(self) -> dict:
        """Return workspace state dict for the web UI (standalone mode).

        Includes repo list plus cached MR/pipeline/vuln/event data.
        Cache reads use synchronous sqlite3 — this method is intended
        to be called from a sync context passed to create_app().
        """
        from collections import defaultdict
        from ..git.ops import git_status

        mrs = self.cache.get_mrs_sync(None)
        pipelines = self.cache.get_pipelines_sync(None)
        vulns = self.cache.get_vulns_sync(None)
        events = self.cache.get_unseen_events_sync()
        pull_statuses = self.cache.get_all_pull_statuses_sync()
        pinned = self.cache.get_pinned_sync()
        repo_order = self.cache.get_repo_order_sync()

        # Group by repo
        repo_mrs: dict[str, list] = defaultdict(list)
        repo_pipelines: dict[str, list] = defaultdict(list)
        repo_vulns: dict[str, list] = defaultdict(list)
        for mr in mrs:
            repo_mrs[mr.repo_name].append(mr)
        for p in pipelines:
            repo_pipelines[p.repo_name].append(p)
        for v in vulns:
            repo_vulns[v.repo_name].append(v)

        # Build per-repo entries
        inactive = {"resolved", "dismissed"}
        repos_data = []
        for r in self.repos:
            rpips = repo_pipelines[r.name]
            rvulns = repo_vulns[r.name]
            entry = {
                **r.to_dict(),
                "mr_count": len(repo_mrs[r.name]),
                "pipeline_status": rpips[0].status if rpips else None,
                "vuln_critical": sum(1 for v in rvulns if v.severity == "critical" and v.state not in inactive),
                "vuln_high": sum(1 for v in rvulns if v.severity == "high" and v.state not in inactive),
                "branch": None, "ahead": 0, "behind": 0,
                "pull_status": pull_statuses.get(r.name),
            }
            try:
                git_st = git_status(Path(entry["path"]))
                entry["branch"] = git_st.branch
                entry["ahead"] = git_st.ahead
                entry["behind"] = git_st.behind
            except Exception:
                pass
            repos_data.append(entry)

        # Sort: pinned first, then custom order, then alphabetical
        def sort_key(name):
            if name in pinned:
                return (0, pinned.index(name))
            if repo_order and name in repo_order:
                return (1, repo_order.index(name))
            return (1, 999, name)

        repos_data.sort(key=lambda r: sort_key(r["name"]))

        return {
            "ready": True,
            "repos": repos_data,
            "sync_status": self._sync_status,
            "usernames": dict(self._usernames),
            "pinned": pinned,
            "repo_order": repo_order,
            "excluded": self.config.exclude,
            "forges": self.config.forges,
            "mrs": [mr.to_dict() for mr in mrs],
            "pipelines": [p.to_dict() for p in pipelines],
            "vulns": [v.to_dict() for v in vulns],
            "events": [e.to_dict() for e in events],
            "last_refresh": self.cache.get_metadata_sync("last_refresh"),
        }

    # --- Per-repo actions ---

    def _find_repo(self, name: str):
        return next((r for r in self.repos if r.name == name), None)

    async def fetch_repo(self, repo_name: str) -> None:
        repo = self._find_repo(repo_name)
        if repo:
            await fetch_one(Path(repo.path))

    async def pull_repo(self, repo_name: str) -> dict:
        repo = self._find_repo(repo_name)
        if not repo:
            return {"error": f"repo {repo_name} not found"}
        result = await pull_safe_one(Path(repo.path), self.config.pull_strategy)
        return {"repo": repo_name, "status": result.status.value, "message": result.message}

    async def get_pipeline_jobs_web(self, repo_name: str, pipeline_id: int) -> list[dict]:
        repo = self._find_repo(repo_name)
        if not repo or not repo.has_forge:
            return []
        client = self._gitlab_clients.get(repo.forge_host)
        if not client:
            return []
        jobs = await asyncio.to_thread(client.get_pipeline_jobs, repo.project_path, pipeline_id)
        return [j.to_dict() for j in jobs]

    def web_app_kwargs(self) -> dict:
        """Return kwargs dict for web.app.create_app()."""
        return dict(
            get_state=self.get_state_dict,
            trigger_refresh=self.refresh_once,
            dismiss_event=lambda eid: self.cache.mark_events_seen([eid]),
            dismiss_all_events=self.cache.mark_all_events_seen,
            fetch_repo=self.fetch_repo,
            pull_repo=self.pull_repo,
            get_pipeline_jobs=self.get_pipeline_jobs_web,
            pin_repo=self.cache.pin_repo,
            unpin_repo=self.cache.unpin_repo,
            save_repo_order=self.cache.save_repo_order,
            exclude_repo=self.exclude_repo,
            include_repo=self.include_repo,
            rescan=self.rescan,
        )

    # --- Repo management ---

    async def exclude_repo(self, repo_name: str) -> None:
        if repo_name not in self.config.exclude:
            self.config.exclude.append(repo_name)
            save_config(self.root / ".project-hub" / "config.yaml", self.config)
        await self.rescan()

    async def include_repo(self, repo_name: str) -> None:
        self.config.exclude = [r for r in self.config.exclude if r != repo_name]
        save_config(self.root / ".project-hub" / "config.yaml", self.config)
        await self.rescan()

    async def rescan(self) -> None:
        self.repos = discover_repos(self.root, self.config)
        self._init_gitlab_clients()
