from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from enum import Enum


class PullStatus(str, Enum):
    UPDATED = "updated"
    ALREADY_UP_TO_DATE = "already_up_to_date"
    SKIPPED_DIRTY = "skipped_dirty"
    SKIPPED_CONFLICT = "skipped_conflict"
    SKIPPED_AHEAD_ONLY = "skipped_ahead_only"
    ERROR = "error"


class EventType(str, Enum):
    PIPELINE_FAILED = "pipeline_failed"
    PIPELINE_FIXED = "pipeline_fixed"
    MR_NEW_COMMENT = "mr_new_comment"
    MR_APPROVED = "mr_approved"
    MR_CHANGES_REQUESTED = "mr_changes_requested"
    MR_MERGED = "mr_merged"
    VULN_NEW = "vuln_new"
    VULN_RESOLVED = "vuln_resolved"
    AUTH_EXPIRED = "auth_expired"


@dataclass
class Repo:
    name: str  # directory name
    path: str  # absolute path
    remote_url: str  # origin URL
    forge_host: str | None  # e.g. "gitlab.com"
    forge_type: str | None  # "gitlab" or None
    has_forge: bool
    project_path: str | None  # e.g. "myunisoft/myu-pa/services/pa-services-gateway"

    def to_dict(self) -> dict:
        return {
            "name": self.name, "path": self.path, "remote_url": self.remote_url,
            "forge_host": self.forge_host, "forge_type": self.forge_type,
            "has_forge": self.has_forge, "project_path": self.project_path,
        }


@dataclass
class GitStatus:
    branch: str | None
    ahead: int
    behind: int
    dirty: bool


@dataclass
class MR:
    id: int
    iid: int
    title: str
    author: str
    state: str
    source_branch: str
    target_branch: str
    web_url: str
    user_notes_count: int
    approved: bool
    created_at: str
    updated_at: str
    repo_name: str  # filled by caller, not from API

    def to_dict(self) -> dict:
        return {
            "id": self.id, "iid": self.iid, "title": self.title,
            "author": self.author, "state": self.state,
            "source_branch": self.source_branch, "target_branch": self.target_branch,
            "web_url": self.web_url, "user_notes_count": self.user_notes_count,
            "approved": self.approved, "created_at": self.created_at,
            "updated_at": self.updated_at, "repo_name": self.repo_name,
        }


@dataclass
class Pipeline:
    id: int
    status: str
    ref: str
    web_url: str
    created_at: str
    repo_name: str

    def to_dict(self) -> dict:
        return {
            "id": self.id, "status": self.status, "ref": self.ref,
            "web_url": self.web_url, "created_at": self.created_at,
            "repo_name": self.repo_name,
        }


@dataclass
class Job:
    id: int
    name: str
    status: str
    stage: str
    web_url: str

    def to_dict(self) -> dict:
        return {
            "id": self.id, "name": self.name, "status": self.status,
            "stage": self.stage, "web_url": self.web_url,
        }


@dataclass
class Vulnerability:
    id: int
    name: str
    severity: str
    state: str
    source: str  # reportType: SAST, DEPENDENCY_SCANNING, etc.
    web_url: str
    repo_name: str
    mitigation_state: str | None = None  # OPEN, RESOLVED, etc.
    mitigation_details: str | None = None
    location: str | None = None  # "file.py:123"
    solution: str | None = None  # scanner-recommended fix

    def to_dict(self) -> dict:
        return {
            "id": self.id, "name": self.name, "severity": self.severity,
            "state": self.state, "source": self.source, "web_url": self.web_url,
            "repo_name": self.repo_name, "mitigation_state": self.mitigation_state,
            "mitigation_details": self.mitigation_details,
            "location": self.location, "solution": self.solution,
        }


@dataclass
class Event:
    id: int | None  # DB-assigned
    type: EventType
    repo_name: str
    summary: str
    detail: str
    created_at: datetime
    seen: bool = False

    def to_dict(self) -> dict:
        return {
            "id": self.id, "type": self.type.value, "repo_name": self.repo_name,
            "summary": self.summary, "detail": self.detail,
            "created_at": self.created_at.isoformat()
            if isinstance(self.created_at, datetime) else self.created_at,
            "seen": self.seen,
        }


@dataclass
class RepoResult:
    repo: str
    status: str
    message: str | None = None
