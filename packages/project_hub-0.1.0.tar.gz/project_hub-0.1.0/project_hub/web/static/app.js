// --- Theme toggle (2-state: dark ↔ light) ---
function cycleTheme() {
    var html = document.documentElement;
    var next = html.getAttribute("data-theme") === "light" ? "dark" : "light";
    html.setAttribute("data-theme", next);
    localStorage.setItem("theme", next);
}
(function() {
    var saved = localStorage.getItem("theme");
    // Migrate "auto" from old 3-state toggle
    if (saved === "auto") saved = "dark";
    if (saved) {
        document.documentElement.setAttribute("data-theme", saved);
        localStorage.setItem("theme", saved);
    }
})();

// --- Events panel ---
function toggleEventsPanel() {
    var panel = document.getElementById("events-panel");
    var overlay = document.getElementById("events-overlay");
    var isOpen = panel.getAttribute("data-open") === "true";
    panel.setAttribute("data-open", !isOpen);
    overlay.setAttribute("data-open", !isOpen);
}

// --- Toast auto-dismiss ---
document.addEventListener("htmx:oobAfterSwap", function(e) {
    if (e.detail.target && e.detail.target.closest(".toast-zone")) {
        var toast = e.detail.target.closest(".toast-zone").lastElementChild;
        if (toast) setTimeout(function() { toast.remove(); }, 5000);
    }
});

// --- Drag & drop flag for htmx polling ---
window.isDragging = false;
window.justDragged = false;

// --- Table sort tracking + persistence ---
window.tableSorted = false;
var _restoringSort = false;

document.addEventListener("click", function(e) {
    var th = e.target.closest("table.sortable thead th:not(.no-sort)");
    if (!th || _restoringSort) return;
    window.tableSorted = true;

    // Save sort state after the library has applied classes
    setTimeout(function() {
        var container = th.closest("[id$='-content']");
        if (!container) return;
        var page = container.id.replace("-content", "");
        var ths = Array.from(th.closest("thead tr").children);
        var col = ths.indexOf(th);
        var dir = th.classList.contains("dir-u") ? "u" : "d";
        localStorage.setItem("sort_" + page, JSON.stringify({col: col, dir: dir}));
    }, 10);
});

// --- Restore sort after htmx content swap ---
document.addEventListener("htmx:afterSwap", function(e) {
    initSortableGrids();

    var target = e.detail.target;
    if (!target || !target.id || !target.id.endsWith("-content")) return;
    var page = target.id.replace("-content", "");
    var saved = localStorage.getItem("sort_" + page);
    if (!saved) return;
    try {
        var sort = JSON.parse(saved);
        var table = target.querySelector("table.sortable");
        if (!table) return;
        var th = table.querySelectorAll("thead th")[sort.col];
        if (!th || th.classList.contains("no-sort")) return;
        _restoringSort = true;
        // First click sorts ascending (dir-d in this library means descending)
        th.click();
        // Library defaults to dir-d on first click; if we need dir-u, click again
        if (sort.dir === "u") {
            setTimeout(function() { th.click(); _restoringSort = false; }, 10);
        } else {
            setTimeout(function() { _restoringSort = false; }, 10);
        }
    } catch(ex) { _restoringSort = false; }
});

function initSortableGrids() {
    document.querySelectorAll(".card-grid").forEach(function(grid) {
        if (grid._sortable) return;
        grid._sortable = new Sortable(grid, {
            animation: 150,
            ghostClass: "sortable-ghost",
            onStart: function() { window.isDragging = true; },
            onEnd: function() {
                window.justDragged = true;
                setTimeout(function() { window.justDragged = false; }, 200);
                saveOrder().then(function() {
                    window.isDragging = false;
                });
            }
        });
    });
}

function saveOrder() {
    var grids = document.querySelectorAll(".card-grid");
    var order = [];
    grids.forEach(function(g) {
        g.querySelectorAll("[data-repo]").forEach(function(card) {
            order.push(card.dataset.repo);
        });
    });
    return fetch("/action/reorder", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({order: order})
    });
}

function resetOrder() {
    fetch("/action/reorder", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({order: []})
    }).then(function() {
        htmx.ajax("GET", "/fragment/dashboard", {target: "#dashboard-content", swap: "innerHTML"});
    });
}

// --- Desktop notifications ---
function toggleDesktopNotifications(enabled) {
    if (enabled && Notification.permission === "default") {
        Notification.requestPermission().then(function(perm) {
            if (perm !== "granted") {
                document.getElementById("desktop-notif-toggle").checked = false;
                localStorage.setItem("desktop_notif", "false");
                return;
            }
            localStorage.setItem("desktop_notif", "true");
        });
    } else {
        localStorage.setItem("desktop_notif", enabled ? "true" : "false");
    }
}

var _prevUnseenCount = null;

document.addEventListener("htmx:afterSwap", function(e) {
    // Restore notification toggle on events panel load
    if (e.detail.target && e.detail.target.id === "events-panel") {
        var toggle = document.getElementById("desktop-notif-toggle");
        if (toggle) toggle.checked = localStorage.getItem("desktop_notif") === "true";
    }

    // Check for new high-severity events
    if (!e.detail.target || e.detail.target.id !== "events-panel") return;
    if (localStorage.getItem("desktop_notif") !== "true") return;
    if (typeof Notification === "undefined" || Notification.permission !== "granted") return;

    var items = e.detail.target.querySelectorAll(".event-item");
    var count = items.length;
    if (_prevUnseenCount !== null && count > _prevUnseenCount && items[0]) {
        var badge = items[0].querySelector("[class*='badge-']");
        var type = badge ? badge.textContent.trim() : "";
        var HIGH_SEVERITY = ["AUTH_EXPIRED", "PIPELINE_FAILED", "VULN_NEW"];
        if (HIGH_SEVERITY.includes(type)) {
            var summary = items[0].querySelector("p");
            new Notification("project-hub", {
                body: summary ? summary.textContent : type,
                tag: "project-hub-" + count
            });
        }
    }
    _prevUnseenCount = count;
});

// --- Filter toggle ---
function setFilter(page, mode) {
    localStorage.setItem("filter_" + page, mode);
    window.tableSorted = false;
    updateFilterButtons();
    var target = document.getElementById(page + "-content");
    if (target) htmx.trigger(target, "do-refresh");
}

var _filterDefaults = { vulns: "active" };

function updateFilterButtons() {
    document.querySelectorAll(".filter-toggle").forEach(function(group) {
        group.querySelectorAll("button[data-filter]").forEach(function(btn) {
            var page = btn.dataset.filterPage;
            var mode = btn.dataset.filter;
            var fallback = _filterDefaults[page] || "all";
            var current = localStorage.getItem("filter_" + page) || fallback;
            btn.classList.toggle("filter-active", mode === current);
        });
    });
}

document.addEventListener("DOMContentLoaded", updateFilterButtons);
