# Anyscale CLI / SDK

`anyscale` PyPI package: terminal CLI and programmatic SDK for the Anyscale platform · Python, Click, Pydantic v1

Architecture map (domains, dependencies, entry points, navigation): @docs/map.md
