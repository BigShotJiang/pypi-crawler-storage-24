def main():
    print("Hello from buildingdatamodel!")


if __name__ == "__main__":
    main()
