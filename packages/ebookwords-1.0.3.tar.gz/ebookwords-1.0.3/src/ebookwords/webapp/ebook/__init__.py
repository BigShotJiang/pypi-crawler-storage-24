import fastapi as fa
import jinja2
from starlette import responses
import tempfile
from pathlib import Path
from epubwords.adapter import ebook

from epubwords.adapter import db

# TODO How to add an editable field in a HTML table, using no javascript?
# TODO How to store a tokenized paragraph in an SQLModel db without losing information?

environment = jinja2.Environment(
    loader=jinja2.PackageLoader("epubwords", "webapp/ebook")
)
router = fa.APIRouter()


@router.post("/upload", response_class=responses.RedirectResponse)
def upload_file(
    uploaded_files: list[fa.UploadFile] = fa.File(),
    database_client: db.DatabaseClient = fa.Depends(db.get_database_client),
    ebook_extractor: ebook.EbookExtractor = fa.Depends(ebook.get_ebook_extractor),
    natural_language_processor=None,
    markup_renderer=None,
):
    for uploaded_file in uploaded_files:
        if uploaded_file.filename is None:
            continue
        suffix = Path(uploaded_file.filename).suffix
        if suffix != ".epub":
            continue
        with tempfile.NamedTemporaryFile(suffix=suffix) as file:
            file_path = Path(file.name)
            file.write(uploaded_file.file.read())
            extracted = ebook_extractor.extract_ebook(file_path)
        if extracted is None:
            continue

        chapters = []
        for c in extracted.chapters:
            chapter = db.Chapter(
                title=c.title,
                html="".join(f"<p>{p}</p>" for p in c.paragraphs),
                text="",
            )
            chapters.append(chapter)
        ebook = db.Ebook(title=extracted.title, chapters=chapters)
        database_client.add_ebook(ebook)

    return responses.RedirectResponse(url="/", status_code=303)


@router.get("/", response_class=responses.HTMLResponse)
def list_ebooks(
    database_client: db.DatabaseClient = fa.Depends(db.get_database_client),
):
    ebooks = database_client.get_ebook_list()
    template = environment.get_template("ebooks.html")
    html = template.render(ebooks=ebooks)
    return html


@router.get("/{ebook_id}", response_class=responses.HTMLResponse)
def list_chapters(
    ebook_id: int,
    database_client: db.DatabaseClient = fa.Depends(db.get_database_client),
):
    ebook = database_client.get_ebook(ebook_id)
    chapters = database_client.get_chapter_list(ebook_id)
    template = environment.get_template("chapters.html")
    html = template.render(ebook=ebook, chapters=chapters)
    return html


@router.get("/{ebook_id}/{chapter_number}", response_class=responses.HTMLResponse)
def show_chapter(
    ebook_id: int,
    chapter_number: int,
    database_client: db.DatabaseClient = fa.Depends(db.get_database_client),
):
    ebook = database_client.get_ebook(ebook_id)
    chapter = database_client.get_chapter(ebook_id, chapter_number)
    template = environment.get_template("chapter.html")
    html = template.render(chapter=chapter)
    return html
