import typing


class NaturalLanguageProcessor(typing.Protocol):
    def tokenize(self, text: str) -> list[str]: ...


class SpacyProcessor:
    def tokenize(self, text: str) -> list[str]:
        raise NotImplementedError()


def get_natural_language_processor():
    return SpacyProcessor()
