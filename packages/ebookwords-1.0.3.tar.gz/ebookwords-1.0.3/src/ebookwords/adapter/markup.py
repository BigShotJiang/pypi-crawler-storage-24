import typing as ty


class MarkupRenderer(ty.Protocol):
    def wrap_tokens_with_spans(self, tokens: list[str]) -> str: ...


class HtmlRenderer:
    def wrap_tokens_with_spans(self, tokens: list[str]) -> str: ...


def get_markup_renderer() -> MarkupRenderer:
    return HtmlRenderer()
