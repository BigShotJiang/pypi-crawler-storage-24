import datetime
import typing
import sqlmodel as sql

# TODO How can migrations be done with SQLModel using sqlite?


class Chapter(typing.NamedTuple):
    title: str
    text: str
    html: str


class Ebook(typing.NamedTuple):
    title: str
    chapters: list[Chapter]


class EbookRecord(typing.NamedTuple):
    id: int
    date_added: datetime.datetime
    title: str


class ChapterRecord(typing.NamedTuple):
    chapter_number: int
    title: str
    text: str
    html: str


class DatabaseClient(typing.Protocol):
    def add_ebook(self, ebook: Ebook) -> None: ...
    def get_ebook_list(self) -> typing.Iterator[EbookRecord]: ...
    def get_chapter_list(self, ebook_id: int) -> typing.Iterator[ChapterRecord]: ...
    def get_ebook(self, ebook_id: int) -> EbookRecord | None: ...
    def get_chapter(
        self, ebook_id: int, chapter_number: int
    ) -> ChapterRecord | None: ...


class SqlEbook(sql.SQLModel, table=True):
    __tablename__ = "ebook"  # type: ignore

    id: int | None = sql.Field(default=None, primary_key=True)
    date_added: datetime.datetime = sql.Field(default_factory=datetime.datetime.now)
    title: str


class SqlChapter(sql.SQLModel, table=True):
    __tablename__ = "chapter"  # type: ignore

    id: int | None = sql.Field(default=None, primary_key=True)
    ebook_id: int | None = sql.Field(default=None, foreign_key="ebook.id")
    chapter_number: int
    title: str
    text: str
    html: str


class SqlDatabaseClient:
    def __init__(self, database_path: str) -> None:
        database_url = f"sqlite:///{database_path}"
        self.engine = sql.create_engine(database_url, echo=True)
        sql.SQLModel.metadata.create_all(self.engine)

    def add_ebook(self, ebook: Ebook) -> None:
        with sql.Session(self.engine) as session:
            ebook_item = SqlEbook(title=ebook.title)
            session.add(ebook_item)
            session.commit()
            for i, chapter in enumerate(ebook.chapters):
                chapter_item = SqlChapter(
                    ebook_id=ebook_item.id,
                    chapter_number=i,
                    title=chapter.title,
                    text=chapter.text,
                    html=chapter.html,
                )
                session.add(chapter_item)
                session.commit()

    def get_ebook_list(self) -> typing.Iterator[EbookRecord]:
        with sql.Session(self.engine) as session:
            statement = sql.select(SqlEbook)
            results = session.exec(statement)
            for ebook_item in results:
                yield EbookRecord(
                    id=ebook_item.id or -1,
                    date_added=ebook_item.date_added,
                    title=ebook_item.title,
                )

    def get_chapter_list(self, ebook_id: int) -> typing.Iterator[ChapterRecord]:
        with sql.Session(self.engine) as session:
            statement = sql.select(SqlChapter.chapter_number, SqlChapter.title)
            statement = statement.where(SqlChapter.ebook_id == ebook_id)
            results = session.exec(statement)

            for chapter_number, chapter_title in results:
                yield ChapterRecord(
                    chapter_number=chapter_number,
                    title=chapter_title,
                    text="",
                    html="",
                )

    def get_ebook(self, ebook_id: int) -> EbookRecord | None:
        with sql.Session(self.engine) as session:
            statement = sql.select(SqlEbook)
            statement = statement.where(SqlEbook.id == ebook_id)
            results = session.exec(statement)
            ebook_item = results.first()
            if not ebook_item:
                return None
            return EbookRecord(
                id=ebook_id,
                date_added=ebook_item.date_added,
                title=ebook_item.title,
            )

    def get_chapter(self, ebook_id: int, chapter_number: int) -> ChapterRecord | None:
        with sql.Session(self.engine) as session:
            statement = sql.select(SqlChapter.title, SqlChapter.text, SqlChapter.html)
            statement = statement.where(SqlChapter.ebook_id == ebook_id)
            statement = statement.where(SqlChapter.chapter_number == chapter_number)
            results = session.exec(statement)
            result = results.first()
            if result is None:
                return None
            title, text, html = result
            return ChapterRecord(
                chapter_number=chapter_number,
                title=title,
                text=text,
                html=html,
            )


def get_database_client() -> SqlDatabaseClient:
    from epubwords.config import environment

    return SqlDatabaseClient(database_path=environment.sqlite_file)
