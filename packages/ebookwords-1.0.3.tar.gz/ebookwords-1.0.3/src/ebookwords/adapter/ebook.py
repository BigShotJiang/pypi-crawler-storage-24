import typing

import zipfile
from pathlib import Path

import lxml.etree as etree
import tempfile
import nh3
import contextlib
from dataclasses import dataclass

# TODO How to use lxml to remove all tags except a couple?


class Chapter(typing.NamedTuple):
    title: str
    paragraphs: list[str]


class Ebook(typing.NamedTuple):
    title: str
    chapters: list[Chapter]


class EbookExtractor(typing.Protocol):
    def extract_ebook(self, file: typing.BinaryIO) -> Ebook: ...


class EpubChapter(typing.NamedTuple):
    title: str
    body: etree.Element


class Epub(typing.NamedTuple):
    root: etree.Element
    manifest: etree.Element
    spine: etree.Element
    content_folder: Path


# TODO separate files for parsing and extractions


@dataclass
class EpubExtractor:
    parser: etree.XMLParser

    @contextlib.contextmanager
    def _load(self, epub_file: typing.BinaryIO) -> typing.Generator[Epub, None, None]:
        with tempfile.NamedTemporaryFile(suffix="epub") as file:
            file.write(epub_file.read())
            with tempfile.TemporaryDirectory() as folder:
                epub_folder = Path(folder)
                with zipfile.ZipFile(file.name) as zf:
                    zf.extractall(epub_folder)
                yield self._parse_epub_folder(epub_folder)

    def _parse_epub_folder(self, epub_folder: Path) -> Epub:
        root_file = self._get_epub_root_file(epub_folder)
        content_folder = root_file.parent
        root = etree.parse(root_file).getroot()

        manifest = root.find("{*}manifest")
        if manifest is None:
            raise Exception()
        manifest = manifest

        spine = root.find("{*}spine")
        if spine is None:
            raise Exception()
        spine = spine

        self.parser = etree.XMLParser(recover=True)

        return Epub(
            root=root,
            manifest=manifest,
            spine=spine,
            content_folder=content_folder,
        )

    @staticmethod
    def _get_epub_root_file(epub_folder: Path) -> Path:
        container_file = Path(epub_folder) / "META-INF" / "container.xml"
        root = etree.parse(container_file).getroot()
        rootfile = root[0][0].get("full-path")
        if rootfile is None:
            raise Exception()
        return epub_folder / rootfile

    def extract_ebook(self, file: typing.BinaryIO) -> Ebook:
        with self._load(file) as epub:
            title = self._extract_title(epub)
            chapters = self._extract_chapters(epub)
            return Ebook(title, list(chapters))

    def _extract_title(self, epub: Epub) -> str:
        title = epub.root.find("{*}metadata/{*}title")
        if title is None or title.text is None:
            raise Exception()
        return title.text

    def _extract_chapters(self, epub: Epub):
        for element in epub.spine:
            chapter = self._parse_chapter_from_spine(epub, element)
            body = self._clean_element(chapter.body)
            paragraphs = self._get_paragraphs(body)
            yield Chapter(chapter.title, list(paragraphs))

    def _get_paragraphs(self, element: etree.Element) -> typing.Iterator[str]:
        xpath = ".//p | .//h1 | .//h2 | .//h3 | .//h4 | .//h5 | .//h6"
        for paragraph in element.xpath(xpath):
            if paragraph.text:
                yield paragraph.text

    def _clean_element(self, child: etree.Element) -> etree.Element:
        html = etree.tostring(child, method="html", encoding="unicode")
        html = nh3.clean(
            html,
            tags={
                "p",
                "h1",
                "h2",
                "h3",
                "h4",
                "h5",
                "h6",
            },
        )
        html = f"<div>{html}</div>"
        element = etree.fromstring(html, parser=self.parser)
        return element

    def _parse_chapter_from_spine(
        self, epub: Epub, spine_element: etree.Element
    ) -> EpubChapter:
        idref = spine_element.get("idref")
        if idref is None:
            raise Exception()

        xpath = f"{{*}}item[@id='{idref}']"
        item = epub.manifest.find(xpath)
        if item is None:
            raise Exception()

        item_path = item.get("href")
        if item_path is None:
            raise Exception()

        chapter_path = epub.content_folder / item_path
        chapter_element = etree.parse(chapter_path, self.parser).getroot()

        title_element = chapter_element.find("{*}head/{*}title")
        if title_element is not None and title_element.text is not None:
            title = title_element.text
        else:
            title = chapter_path.stem

        body = chapter_element.find("{*}body")
        if body is None:
            raise Exception()

        return EpubChapter(title, body)


def get_ebook_extractor() -> EbookExtractor:
    return EpubExtractor(parser=etree.XMLParser(recover=True))


@dataclass
class EpubParser:
    parser: etree.XMLParser

    # TODO move parsing logic here
