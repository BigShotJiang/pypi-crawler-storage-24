from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="Duekngs",
    version="0.2.0",
    packages=find_packages(),
    author="Dhairya Parmar",
    description="AI Lab Practical Algorithms in Python",
    long_description=long_description,
    long_description_content_type="text/markdown",
    license="MIT",
)