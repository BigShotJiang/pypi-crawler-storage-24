def run_dee5():
    #create file name history.aiml

    #<?xml version="1.0" encoding="UTF-8"?>
    #<aiml version="1.0.1">

    #<category>
    #<pattern>WHAT IS HISTORY</pattern>
    #<template>
    #History is the course of political, economic and military events over time, from the Dawn of Man to the Age of AI.
    #</template>
    #</category>

    #<category>
    #<pattern>WHO INVENTED THE LIGHT</pattern>
    #<template>Thomas Edison.</template>
    #</category>

    #<category>
    #<pattern>WHO INVENTED THE STEAM</pattern>
    #<template>James Watt.</template>
    #</category>

    #<category>
    #<pattern>AMERICAN CIVIL WAR</pattern>
    #<template>I am very interested in the war between the States.</template>
    #</category>

    #</aiml>


    import aiml

    print("--------SYMDS2024015--------")
    print("--------Laukik Nibre--------\n")

    kernel = aiml.Kernel()

    kernel.learn("history.aiml")

    while True:
        message = input("Enter your message: ")
        print(kernel.respond(message))