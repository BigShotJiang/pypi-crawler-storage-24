def run_dee9():
    import numpy as np
    import skfuzzy as fuzz
    from skfuzzy import control as ctrl
    import matplotlib.pyplot as plt

    print("--------SYMDS2024015--------")
    print("--------Laukik Nibre--------\n")

    # Fuzzy variables
    quality = ctrl.Antecedent(np.arange(0,11,1),'quality')
    service = ctrl.Antecedent(np.arange(0,11,1),'service')
    tip = ctrl.Consequent(np.arange(0,26,1),'tip')

    # Auto membership functions
    quality.automf(3)
    service.automf(3)

    # Tip membership functions
    tip['low'] = fuzz.trimf(tip.universe,[0,0,13])
    tip['medium'] = fuzz.trimf(tip.universe,[0,13,25])
    tip['high'] = fuzz.trimf(tip.universe,[13,25,25])

    # View membership graphs
    quality.view()
    service.view()
    tip.view()

    # Rules
    rule1 = ctrl.Rule(quality['poor'] | service['poor'], tip['low'])
    rule2 = ctrl.Rule(service['average'], tip['medium'])
    rule3 = ctrl.Rule(quality['good'] | service['good'], tip['high'])

    # Control system
    tipping_ctrl = ctrl.ControlSystem([rule1,rule2,rule3])
    tipping = ctrl.ControlSystemSimulation(tipping_ctrl)

    # Inputs
    tipping.input['quality'] = 6.5
    tipping.input['service'] = 9.8

    # Compute result
    tipping.compute()

    print("Suggested tip:", tipping.output['tip'])

    # Show output graph
    tip.view(sim=tipping)
    plt.show()