#text to speech

def run_dee6():
    import pyttsx3

    print("--------SYMDS2024015--------")
    print("--------Laukik Nibre--------\n")

    engine = pyttsx3.init()

    text = "My name is Laukik Nibre"

    engine.say(text)
    engine.runAndWait()

    #text to hindi
    import pyttsx3
    from googletrans import Translator
    from gtts import gTTS

    engine = pyttsx3.init()

    # Take input
    t1 = input("Enter something: ")

    # Speak original text
    engine.say(t1)
    engine.runAndWait()

    # Translate
    translator = Translator()
    t = translator.translate(t1, dest='hi')

    print("Translated text:", t.text)

    # Convert translated text to audio
    speech = gTTS(text=t.text, lang='hi')
    speech.save("laukik.mp3")

    print("Audio saved as laukik.mp3")


    #Text to french
    from googletrans import Translator

    text = input("Enter text: ")

    translator = Translator()

    result = translator.translate(text, dest='fr')

    print("French translation:", result.text)

