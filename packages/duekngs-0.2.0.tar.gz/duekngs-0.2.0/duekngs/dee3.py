def run_dee3():
    print("--------SYMDS2024015--------")
    print("--------Laukik Nibre--------\n")

    board = [' ' for i in range(9)]

    def print_board():
        print(board[0] + "|" + board[1] + "|" + board[2])
        print("-+-+-")
        print(board[3] + "|" + board[4] + "|" + board[5])
        print("-+-+-")
        print(board[6] + "|" + board[7] + "|" + board[8])
        print()

    def check_winner(b, player):
        win = [(0,1,2),(3,4,5),(6,7,8),
            (0,3,6),(1,4,7),(2,5,8),
            (0,4,8),(2,4,6)]

        for x,y,z in win:
            if b[x]==b[y]==b[z]==player:
                return True
        return False

    def minimax(b, isMax):

        if check_winner(b,'O'):
            return 1
        if check_winner(b,'X'):
            return -1
        if ' ' not in b:
            return 0

        if isMax:
            best = -100
            for i in range(9):
                if b[i]==' ':
                    b[i]='O'
                    best = max(best, minimax(b, False))
                    b[i]=' '
            return best
        else:
            best = 100
            for i in range(9):
                if b[i]==' ':
                    b[i]='X'
                    best = min(best, minimax(b, True))
                    b[i]=' '
            return best

    def best_move():
        bestVal = -100
        move = -1

        for i in range(9):
            if board[i]==' ':
                board[i]='O'
                moveVal = minimax(board, False)
                board[i]=' '

                if moveVal > bestVal:
                    move = i
                    bestVal = moveVal

        return move

    while True:

        print_board()
        pos = int(input("Enter your move (1-9): ")) - 1

        if board[pos]==' ':
            board[pos]='X'
        else:
            print("Invalid move")
            continue

        if check_winner(board,'X'):
            print_board()
            print("You Win!")
            break

        if ' ' not in board:
            print_board()
            print("Draw")
            break

        ai = best_move()
        board[ai]='O'

        if check_winner(board,'O'):
            print_board()
            print("AI Wins!")
            break