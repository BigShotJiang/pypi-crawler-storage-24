#!/usr/bin/env python3
"""
Screen Time Brute-Force — Rich TUI Visualization

Wraps bruteforce.py with a fancy terminal UI for timelapse recording.
"""

import time
import sys
import os
import signal
import subprocess
import threading
import argparse
import random
from datetime import datetime

try:
    from rich.live import Live
    from rich.layout import Layout
    from rich.panel import Panel
    from rich.text import Text
    from rich.console import Console
    from rich.align import Align
    from rich.table import Table
except ImportError:
    print("[!] Missing 'rich' library. Install with: pip install rich")
    sys.exit(1)

from bruteforce.bruteforce import (
    load_state, save_state, load_pin_order,
    ensure_settings_open, open_dialog, check_sheet_status,
    try_pin, reset_clock, ensure_sudo, advance_clock,
    dismiss_and_reopen, save_and_set_fast_animations,
    PIN_CSV, STATE_FILE,
)

# Amber palette
AMBER_BRIGHT = "#ffb000"
AMBER_MID = "#cc8800"
AMBER_DIM = "#664400"
AMBER_BG = "#1a1000"
UNTRIED_DIM = "#2a2218"
BORDER_COLOR = "#885500"
SUCCESS_GREEN = "#00ff88"



class BruteForceTUI:
    def __init__(self, all_pins: list[str], tried: set[str]):
        self.all_pins = all_pins
        self.total = len(all_pins)
        self.tried = tried
        self.pin_status: dict[str, str] = {}
        for p in tried:
            self.pin_status[p] = "failed"
        self.current_pin = ""
        self.log_lines: list[str] = []
        self.start_time = time.time()
        self.pins_done = 0
        self.console = Console()

    def log(self, msg: str):
        ts = datetime.now().strftime("%H:%M:%S")
        self.log_lines.append(f"{ts}  {msg}")
        if len(self.log_lines) > 10:
            self.log_lines = self.log_lines[-10:]

    def set_current(self, pin: str):
        if self.current_pin and self.pin_status.get(self.current_pin) == "current":
            self.pin_status[self.current_pin] = "failed"
        self.current_pin = pin
        self.pin_status[pin] = "current"

    def mark_failed(self, pin: str):
        self.pin_status[pin] = "failed"
        self.pins_done += 1

    def mark_success(self, pin: str):
        self.pin_status[pin] = "success"

    def render_grid(self, grid_width: int, grid_height: int) -> Text:
        """Render a braille-dot grid that scales all PINs to fit the terminal.
        Each braille char is a 2x4 dot matrix. PINs fill left-to-right,
        top-to-bottom, scaled so the full set always fills the grid."""
        DOT_BITS = [
            [0x01, 0x02, 0x04, 0x40],  # left column
            [0x08, 0x10, 0x20, 0x80],  # right column
        ]

        chars_wide = grid_width
        chars_tall = grid_height
        capacity = chars_wide * chars_tall * 8  # total dot slots

        # Pre-build a flat array: which PIN index maps to each dot slot
        # PINs fill sequentially; if capacity > total, later slots are empty
        # If total > capacity, we evenly sample (but usually capacity >> 10000)
        text = Text()
        for char_row in range(chars_tall):
            for char_col in range(chars_wide):
                code = 0x2800
                char_style = UNTRIED_DIM
                has_current = False
                has_success = False
                has_failed = False

                for dc in range(2):
                    for dr in range(4):
                        # Flat dot index within the grid
                        dot_row = char_row * 4 + dr
                        dot_col = char_col * 2 + dc
                        dot_idx = dot_row * (chars_wide * 2) + dot_col

                        # Map dot index to PIN index proportionally
                        pin_idx = dot_idx * self.total // capacity
                        if pin_idx >= self.total:
                            continue

                        pin = self.all_pins[pin_idx]
                        status = self.pin_status.get(pin)
                        if status in ("failed", "current", "success"):
                            code |= DOT_BITS[dc][dr]
                        if status == "current":
                            has_current = True
                        elif status == "success":
                            has_success = True
                        elif status == "failed":
                            has_failed = True

                if has_current:
                    char_style = f"bold {AMBER_BRIGHT}"
                elif has_success:
                    char_style = f"bold {SUCCESS_GREEN}"
                elif has_failed:
                    char_style = AMBER_MID

                text.append(chr(code), style=char_style)
            if char_row < chars_tall - 1:
                text.append("\n")
        return text

    def render_sidebar(self) -> Text:
        text = Text()
        done = len(self.tried)

        text.append("PINS\n", style=f"bold {AMBER_DIM}")
        text.append(f"{done}", style=f"bold {AMBER_BRIGHT}")
        text.append(f"/{self.total}\n\n", style=AMBER_DIM)

        if self.pins_done > 0:
            elapsed = time.time() - self.start_time
            per_pin = elapsed / self.pins_done

            text.append("SPEED\n", style=f"bold {AMBER_DIM}")
            text.append(f"{per_pin:.1f}s", style=f"bold {AMBER_BRIGHT}")
            text.append("/pin\n\n", style=AMBER_DIM)

            remaining = self.total - done
            eta_secs = remaining * per_pin
            m, s = divmod(int(eta_secs), 60)
            h, m = divmod(m, 60)
            eta = f"{h}h{m:02d}m" if h else f"{m}m{s:02d}s"
            text.append("ETA\n", style=f"bold {AMBER_DIM}")
            text.append(eta, style=f"bold {AMBER_BRIGHT}")
        else:
            text.append("SPEED\n", style=f"bold {AMBER_DIM}")
            text.append("--\n\n", style=AMBER_DIM)
            text.append("ETA\n", style=f"bold {AMBER_DIM}")
            text.append("--", style=AMBER_DIM)
        return text

    def render_progress_bar(self, width: int) -> Text:
        done = len(self.tried)
        pct = done / self.total * 100 if self.total else 0
        bar_width = max(10, width - 14)
        filled = int(bar_width * done / self.total) if self.total else 0
        empty = bar_width - filled

        text = Text()
        text.append("█" * filled, style=AMBER_MID)
        text.append("░" * empty, style=UNTRIED_DIM)
        text.append(f" {pct:5.1f}%", style=f"bold {AMBER_BRIGHT}")
        return text

    def render_status_bar(self) -> Text:
        text = Text()
        done = len(self.tried)
        elapsed = time.time() - self.start_time
        m, s = divmod(int(elapsed), 60)
        h, m = divmod(m, 60)
        elapsed_str = f"{h}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"

        text.append(" ◆ ", style=f"bold {AMBER_BRIGHT}")
        text.append(f"{done}/{self.total} tried", style=AMBER_MID)
        text.append("  │  ", style=AMBER_DIM)
        text.append(f"elapsed {elapsed_str}", style=AMBER_MID)

        if self.pins_done > 0:
            per_pin = elapsed / self.pins_done
            remaining = self.total - done
            eta_secs = remaining * per_pin
            em, es = divmod(int(eta_secs), 60)
            eh, em = divmod(em, 60)
            eta = f"{eh}h{em:02d}m" if eh else f"{em}m{es:02d}s"
            text.append("  │  ", style=AMBER_DIM)
            text.append(f"{per_pin:.1f}s/pin", style=AMBER_MID)
            text.append("  │  ", style=AMBER_DIM)
            text.append(f"ETA {eta}", style=f"bold {AMBER_BRIGHT}")

        if self.current_pin:
            text.append("  │  ", style=AMBER_DIM)
            text.append(f"PIN {self.current_pin}", style=f"bold {AMBER_BRIGHT}")

        return text

    def render_log(self) -> Text:
        text = Text()
        for i, line in enumerate(self.log_lines):
            if i > 0:
                text.append("\n")
            # Highlight timestamps
            if len(line) >= 8:
                text.append(line[:8], style=AMBER_DIM)
                msg = line[8:]
                if "FOUND" in msg:
                    text.append(msg, style=f"bold {SUCCESS_GREEN}")
                elif "Bypassed" in msg:
                    text.append(msg, style=f"bold {AMBER_BRIGHT}")
                elif "Lockout" in msg or "bypass" in msg.lower():
                    text.append(msg, style=AMBER_MID)
                elif "failed" in msg.lower() or "Cannot" in msg:
                    text.append(msg, style="bold red")
                else:
                    text.append(msg, style=AMBER_DIM)
            else:
                text.append(line, style=AMBER_DIM)
        return text

    def render(self) -> Layout:
        width = self.console.size.width
        height = self.console.size.height

        # Dynamic log height based on terminal size
        log_h = max(4, min(12, height // 5))

        # Fixed sizes: header=3, log=log_h, body borders=2
        body_h = height - 3 - log_h
        # Grid: subtract panel borders (2) from body height
        grid_h = max(1, body_h - 2)
        # Grid width: total width minus sidebar(10) minus grid panel borders(2) minus sidebar borders(2)
        grid_w = max(10, width - 16 - 4)

        layout = Layout()
        layout.split_column(
            Layout(name="header", size=3),
            Layout(name="body"),
            Layout(name="log", size=log_h),
        )

        # Header: progress bar
        layout["header"].update(
            Panel(
                Align.center(self.render_progress_bar(width - 4)),
                title="[bold]Screen Time Brute-Force[/bold]",
                title_align="center",
                border_style=BORDER_COLOR,
                style=f"on {AMBER_BG}",
            )
        )

        # Body: grid + sidebar
        body_layout = Layout()
        body_layout.split_row(
            Layout(name="grid", ratio=1),
            Layout(name="sidebar", size=16),
        )
        body_layout["grid"].update(
            Panel(
                self.render_grid(grid_w, grid_h),
                border_style=BORDER_COLOR,
                style=f"on {AMBER_BG}",
            )
        )
        body_layout["sidebar"].update(
            Panel(
                self.render_sidebar(),
                border_style=BORDER_COLOR,
                style=f"on {AMBER_BG}",
            )
        )
        layout["body"].update(body_layout)

        # Log with status bar as subtitle
        layout["log"].update(
            Panel(
                self.render_log(),
                subtitle=self.render_status_bar(),
                subtitle_align="center",
                border_style=BORDER_COLOR,
                style=f"on {AMBER_BG}",
            )
        )

        return layout

    def bypass_lockout(self, lockout_mins: int) -> bool:
        advance = int(lockout_mins * 1.2) + 1
        self.log(f"Lockout {lockout_mins}min → bypassing ({advance}min advance)...")

        if not advance_clock(advance):
            self.log("Clock advance failed!")
            return False

        if not dismiss_and_reopen():
            self.log("Could not reopen dialog after bypass!")
            return False

        reset_clock()
        self.log("Bypassed!")
        return True


def demo_mode(args):
    """Simulate brute-force with fake data — no system calls, no state changes."""
    # Generate fake PIN list (or use real CSV if available)
    if os.path.exists(PIN_CSV):
        all_pins = load_pin_order()
    else:
        all_pins = [f"{i:04d}" for i in range(10000)]

    # Start ~30% done for a more interesting initial view
    pre_tried = set(all_pins[:len(all_pins) * 3 // 10])
    tui = BruteForceTUI(all_pins, pre_tried)
    tui.tried = set(pre_tried)
    tui.pins_done = len(pre_tried)
    remaining = [p for p in all_pins if p not in pre_tried]

    tui.log("DEMO MODE — no system changes")
    tui.log(f"Simulating {len(all_pins)} PINs, {len(pre_tried)} pre-tried")
    tui.log("Starting brute-force...")

    lockout_every = random.randint(8, 14)  # trigger fake lockout periodically
    pins_since_lockout = 0

    with Live(tui.render(), console=tui.console, refresh_per_second=8, screen=True) as live:
        def on_exit(sig, frame):
            live.stop()
            sys.exit(0)
        signal.signal(signal.SIGINT, on_exit)
        signal.signal(signal.SIGTERM, on_exit)

        for pin in remaining:
            tui.set_current(pin)
            tui.log(f"Trying {pin}...")
            live.update(tui.render())

            # Simulate lockout every N pins
            pins_since_lockout += 1
            if pins_since_lockout >= lockout_every:
                pins_since_lockout = 0
                lockout_every = random.randint(8, 14)
                mins = random.choice([1, 5, 15])
                advance = int(mins * 1.2) + 1
                tui.log(f"Lockout {mins}min → bypassing ({advance}min advance)...")
                live.update(tui.render())
                time.sleep(random.uniform(0.3, 0.6))
                tui.log("Bypassed!")
                live.update(tui.render())

            # Simulate PIN attempt delay
            time.sleep(random.uniform(0.05, 0.15))

            tui.tried.add(pin)
            tui.mark_failed(pin)
            live.update(tui.render())

        tui.log(f"Exhausted all {tui.total} PINs")
        live.update(tui.render())
        time.sleep(3)


def main():
    parser = argparse.ArgumentParser(description="Screen Time PIN brute-force (TUI)")
    parser.add_argument("--reset", action="store_true", help="Clear state and start fresh")
    parser.add_argument("--start", type=int, default=0, metavar="N", help="Skip first N PINs (start at index N)")
    parser.add_argument("--demo", action="store_true", help="Demo mode: simulate without touching system")
    args = parser.parse_args()

    if args.demo:
        demo_mode(args)
        return

    if args.reset:
        if os.path.exists(STATE_FILE):
            os.remove(STATE_FILE)
        print("[*] State cleared.")

    if not os.path.exists(PIN_CSV):
        print(f"[!] Missing {PIN_CSV}")
        sys.exit(1)

    all_pins = load_pin_order()
    state = load_state()
    tried = set(state["tried"])

    if args.start > 0:
        skipped = set(all_pins[:args.start])
        tried |= skipped
        state["tried"] = list(tried)
    remaining_pins = [p for p in all_pins if p not in tried]

    tui = BruteForceTUI(all_pins, tried)
    tui.log(f"Loaded {len(all_pins)} PINs, {len(tried)} tried, {len(remaining_pins)} remaining")

    # Animations
    tui.log("Disabling animations...")
    save_and_set_fast_animations()

    # Sudo
    tui.log("Checking sudo...")
    r = subprocess.run(["sudo", "-n", "true"], capture_output=True)
    if r.returncode != 0:
        subprocess.run(["sudo", "-v"])

    def sudo_keepalive():
        while True:
            time.sleep(30)
            subprocess.run(["sudo", "-n", "-v"], capture_output=True)
    threading.Thread(target=sudo_keepalive, daemon=True).start()

    # Reset clock
    reset_clock()

    # Open settings
    ensure_settings_open()

    # Open dialog
    if not open_dialog():
        if check_sheet_status() == "none":
            print("[!] Could not open PIN dialog")
            sys.exit(1)

    tui.log("Starting brute-force...")

    found_pin = None
    exhausted = False

    with Live(tui.render(), console=tui.console, refresh_per_second=4, screen=True) as live:
        def on_exit(sig, frame):
            save_state(state)
            live.stop()
            print(f"\n[!] Interrupted at PIN {tui.current_pin}")
            print(f"[*] {len(tried)}/{tui.total} tried. Run again to resume.")
            sys.exit(1)
        signal.signal(signal.SIGINT, on_exit)
        signal.signal(signal.SIGTERM, on_exit)

        for pin in remaining_pins:
            tui.set_current(pin)
            tui.log(f"Trying {pin}...")
            live.update(tui.render())

            # Ensure settings and dialog are open
            status = check_sheet_status()
            if status == "none":
                ensure_settings_open()
                if not open_dialog():
                    tui.log(f"Cannot open dialog at PIN {pin}")
                    save_state(state)
                    live.stop()
                    sys.exit(1)
                status = check_sheet_status()

            # Bypass lockout if needed
            if status.startswith("lockout:"):
                lockout_mins = int(status.split(":")[1])
                if not tui.bypass_lockout(lockout_mins):
                    tui.log(f"Bypass failed at PIN {pin}")
                    save_state(state)
                    live.stop()
                    sys.exit(1)
                live.update(tui.render())

            # Enter PIN
            result = try_pin(pin)

            if result == "success":
                tried.add(pin)
                tui.mark_success(pin)
                state["tried"] = list(tried)
                save_state(state)
                elapsed = time.time() - tui.start_time
                tui.log(f"PIN FOUND: {pin}  ({len(tried)} attempts, {elapsed:.1f}s)")
                live.update(tui.render())
                found_pin = pin
                time.sleep(5)
                break

            elif result.startswith("lockout:"):
                lockout_mins = int(result.split(":")[1])
                tui.log(f"Lockout triggered ({lockout_mins}min)")

            tried.add(pin)
            tui.mark_failed(pin)
            state["tried"] = list(tried)
            if tui.pins_done % 10 == 0:
                save_state(state)
            live.update(tui.render())
        else:
            save_state(state)
            exhausted = True
            elapsed = time.time() - tui.start_time
            tui.log(f"Exhausted all {tui.total} PINs in {elapsed:.1f}s")
            live.update(tui.render())
            time.sleep(3)

    # Print results after TUI exits so they persist in the terminal
    elapsed = time.time() - tui.start_time
    if found_pin:
        print(f"\n{'='*50}")
        print(f"  PIN FOUND: {found_pin}")
        print(f"  Attempts:  {len(tried)}")
        print(f"  Time:      {elapsed:.1f}s")
        print(f"{'='*50}")
    elif exhausted:
        print(f"\n[*] Exhausted all {tui.total} PINs in {elapsed:.1f}s — no match found.")


if __name__ == "__main__":
    main()
