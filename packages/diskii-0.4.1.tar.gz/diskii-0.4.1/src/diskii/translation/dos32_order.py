"""DOS 3.2-ordered translator (13 sectors per track)."""

from ..exceptions import CorruptedImageError
from ..exceptions import IOError as DiskiiIOError
from .interface import SectorTranslator, TranslationMode


class DOS32OrderTranslator(SectorTranslator):
    """Translator for DOS 3.2-ordered images (.d13 files).

    DOS 3.2-ordered images use 13 sectors per track instead of
    the standard 16 sectors per track used in DOS 3.3.
    """

    mode = TranslationMode.DOS32_ORDER
    SECTORS_PER_TRACK = 13

    def _calculate_total_sectors(self) -> int:
        """Calculate total sectors from file size."""
        return self.file_path.stat().st_size // self.SECTOR_SIZE

    @property
    def total_blocks(self) -> int:
        """Get total number of blocks (sectors / 2)."""
        return self.total_sectors // 2

    def read_sector(self, track: int, sector: int) -> bytes:
        """Read a DOS 3.2 sector."""
        if track < 0 or sector < 0 or sector >= self.SECTORS_PER_TRACK:
            raise ValueError(f"Invalid track/sector: {track}/{sector}")

        # Calculate linear sector number
        linear_sector = track * self.SECTORS_PER_TRACK + sector

        if linear_sector >= self.total_sectors:
            raise ValueError(
                f"Sector {track}/{sector} out of range (max {self.total_sectors - 1})"
            )

        try:
            offset = linear_sector * self.SECTOR_SIZE
            self.file_handle.seek(offset)
            data = self.file_handle.read(self.SECTOR_SIZE)

            if len(data) != self.SECTOR_SIZE:
                raise CorruptedImageError(
                    f"Sector {track}/{sector} incomplete: got {len(data)} bytes, "
                    f"expected {self.SECTOR_SIZE}",
                    str(self.file_path),
                )
            return data

        except OSError as e:
            raise DiskiiIOError(f"Error reading sector {track}/{sector}: {e}") from e

    def write_sector(self, track: int, sector: int, data: bytes) -> None:
        """Write a DOS 3.2 sector."""
        if len(data) != self.SECTOR_SIZE:
            raise ValueError(
                f"Sector data must be exactly {self.SECTOR_SIZE} bytes, got {len(data)}"
            )

        if track < 0 or sector < 0 or sector >= self.SECTORS_PER_TRACK:
            raise ValueError(f"Invalid track/sector: {track}/{sector}")

        # Calculate linear sector number
        linear_sector = track * self.SECTORS_PER_TRACK + sector

        if linear_sector >= self.total_sectors:
            raise ValueError(
                f"Sector {track}/{sector} out of range (max {self.total_sectors - 1})"
            )

        try:
            offset = linear_sector * self.SECTOR_SIZE
            self.file_handle.seek(offset)
            self.file_handle.write(data)
            self.file_handle.flush()

        except OSError as e:
            raise DiskiiIOError(f"Error writing sector {track}/{sector}: {e}") from e

    def read_block(self, block_num: int) -> bytes:
        """Read block by combining two consecutive sectors."""
        if block_num < 0 or block_num >= self.total_blocks:
            raise ValueError(
                f"Block {block_num} out of range (0-{self.total_blocks - 1})"
            )

        # Convert block to track/sector (13 sectors per track)
        sector_num = block_num * 2
        track = sector_num // self.SECTORS_PER_TRACK
        base_sector = sector_num % self.SECTORS_PER_TRACK

        # Read two consecutive sectors
        sector1_data = self.read_sector(track, base_sector)

        # Handle edge case where second sector would go to next track
        if base_sector < self.SECTORS_PER_TRACK - 1:
            sector2_data = self.read_sector(track, base_sector + 1)
        else:
            # Second sector is on next track
            if track + 1 < self.total_sectors // self.SECTORS_PER_TRACK:
                sector2_data = self.read_sector(track + 1, 0)
            else:
                # No second sector - pad with zeros
                sector2_data = b"\x00" * self.SECTOR_SIZE

        return sector1_data + sector2_data

    def write_block(self, block_num: int, data: bytes) -> None:
        """Write block by splitting into two consecutive sectors."""
        if len(data) != 512:
            raise ValueError(f"Block data must be exactly 512 bytes, got {len(data)}")

        if block_num < 0 or block_num >= self.total_blocks:
            raise ValueError(
                f"Block {block_num} out of range (0-{self.total_blocks - 1})"
            )

        # Convert block to track/sector (13 sectors per track)
        sector_num = block_num * 2
        track = sector_num // self.SECTORS_PER_TRACK
        base_sector = sector_num % self.SECTORS_PER_TRACK

        # Write first sector (first 256 bytes)
        self.write_sector(track, base_sector, data[:256])

        # Write second sector (last 256 bytes)
        if base_sector < self.SECTORS_PER_TRACK - 1:
            self.write_sector(track, base_sector + 1, data[256:])
        else:
            # Second sector is on next track
            if track + 1 < self.total_sectors // self.SECTORS_PER_TRACK:
                self.write_sector(track + 1, 0, data[256:])
