"""Factory for creating appropriate translators based on image format."""

from pathlib import Path
from typing import BinaryIO, cast

from ..types import FilesystemType, SectorOrdering
from .dos32_order import DOS32OrderTranslator
from .dos_order import DOSOrderTranslator
from .dos_ordered_block import DOSOrderedBlockTranslator
from .interface import BlockTranslator, SectorTranslator, TranslationMode
from .prodos_order import ProDOSOrderTranslator
from .prodos_ordered_sector import ProDOSOrderedSectorTranslator


class TranslatorFactory:
    """Factory for creating appropriate sector/block translators."""

    @classmethod
    def create_translator(
        self,
        filesystem_type: FilesystemType,
        sector_ordering: SectorOrdering,
        file_handle: BinaryIO,
        file_path: Path,
    ) -> SectorTranslator | BlockTranslator:
        """Create appropriate translator based on filesystem and ordering.

        Args:
            filesystem_type: The filesystem stored on the disk
            sector_ordering: The physical sector ordering of the disk image
            file_handle: Open file handle to the disk image
            file_path: Path to the disk image file

        Returns:
            Appropriate translator instance

        Raises:
            ValueError: If combination is not supported
        """
        # Map combinations to translator classes
        translator_map = {
            # Native format combinations (no translation needed)
            (FilesystemType.PRODOS, SectorOrdering.PRODOS_ORDER): ProDOSOrderTranslator,
            (FilesystemType.DOS33, SectorOrdering.DOS_ORDER): DOSOrderTranslator,
            (FilesystemType.DOS32, SectorOrdering.DOS32_ORDER): DOS32OrderTranslator,
            # Cross-format combinations (translation required)
            (
                FilesystemType.PRODOS,
                SectorOrdering.DOS_ORDER,
            ): DOSOrderedBlockTranslator,
            (
                FilesystemType.DOS33,
                SectorOrdering.PRODOS_ORDER,
            ): ProDOSOrderedSectorTranslator,
        }

        combination = (filesystem_type, sector_ordering)
        translator_class = translator_map.get(combination)

        if translator_class is None:
            raise ValueError(
                f"Unsupported combination: {filesystem_type.value} filesystem "
                f"with {sector_ordering.value} ordering"
            )

        return cast(
            SectorTranslator | BlockTranslator,
            translator_class(file_handle, file_path),
        )

    @classmethod
    def get_translation_mode(
        self, filesystem_type: FilesystemType, sector_ordering: SectorOrdering
    ) -> TranslationMode:
        """Get the translation mode for a filesystem/ordering combination.

        Args:
            filesystem_type: The filesystem stored on the disk
            sector_ordering: The physical sector ordering of the disk image

        Returns:
            Appropriate translation mode
        """
        # Most combinations use the sector ordering as the mode
        ordering_to_mode = {
            SectorOrdering.PRODOS_ORDER: TranslationMode.PRODOS_ORDER,
            SectorOrdering.DOS_ORDER: TranslationMode.DOS_ORDER,
            SectorOrdering.DOS32_ORDER: TranslationMode.DOS32_ORDER,
        }

        return ordering_to_mode.get(sector_ordering, TranslationMode.DOS_ORDER)

    @classmethod
    def supports_combination(
        self, filesystem_type: FilesystemType, sector_ordering: SectorOrdering
    ) -> bool:
        """Check if a filesystem/ordering combination is supported.

        Args:
            filesystem_type: The filesystem stored on the disk
            sector_ordering: The physical sector ordering of the disk image

        Returns:
            True if combination is supported
        """
        supported_combinations = {
            (FilesystemType.PRODOS, SectorOrdering.PRODOS_ORDER),
            (FilesystemType.PRODOS, SectorOrdering.DOS_ORDER),
            (FilesystemType.DOS33, SectorOrdering.DOS_ORDER),
            (FilesystemType.DOS33, SectorOrdering.PRODOS_ORDER),
            (FilesystemType.DOS32, SectorOrdering.DOS32_ORDER),
        }

        return (filesystem_type, sector_ordering) in supported_combinations
