"""Reorder command implementation."""

import argparse
from pathlib import Path

from ...detection import detect_sector_ordering
from ...exceptions import DiskiiError
from ...types import SectorOrdering
from ..utils import confirm_action, create_backup, print_success, print_warning


def run_reorder(args: argparse.Namespace) -> None:
    """Run the reorder command to change sector ordering."""
    source_path = Path(args.source)
    dest_path = Path(args.dest)

    if not source_path.exists():
        raise DiskiiError(f"Source image not found: {source_path}")

    if dest_path.exists():
        if not confirm_action(f"Destination {dest_path} already exists. Overwrite?"):
            print("Cancelled")
            return

    # Detect source and destination sector orderings
    source_ordering = detect_sector_ordering(source_path)
    dest_ordering = detect_sector_ordering(dest_path)

    # Check if reordering is needed
    if source_ordering == dest_ordering:
        print_warning(f"Source and destination both use {source_ordering.value}")
        if not confirm_action("Continue anyway?"):
            print("Cancelled")
            return

    backup_path = None
    try:
        # Create backup if requested
        if getattr(args, "backup", False):
            backup_path = create_backup(source_path)
            print_success(f"Created backup: {backup_path}")

        # Read entire source image
        source_data = source_path.read_bytes()

        # Reorder sectors
        reordered_data = _reorder_sectors(source_data, source_ordering, dest_ordering)

        # Write reordered data to destination
        dest_path.write_bytes(reordered_data)

        print_success(f"Reordered {source_path} -> {dest_path}")
        print(f"Sector ordering: {source_ordering.value} -> {dest_ordering.value}")

    except Exception as e:
        if backup_path:
            print_warning(f"Error occurred, backup available at: {backup_path}")
        raise DiskiiError(f"Reordering failed: {e}") from e


def _reorder_sectors(
    data: bytes, source_ordering: SectorOrdering, dest_ordering: SectorOrdering
) -> bytes:
    """Reorder disk image data between different sector orderings."""

    # If same ordering, just return the data
    if source_ordering == dest_ordering:
        return data

    # Determine disk geometry based on size
    data_size = len(data)

    # Standard 140KB disk (35 tracks, 16 sectors)
    if data_size == 35 * 16 * 256:
        tracks = 35
        sectors_per_track = 16
        sector_size = 256
    # DOS 3.2 disk (35 tracks, 13 sectors)
    elif data_size == 35 * 13 * 256:
        tracks = 35
        sectors_per_track = 13
        sector_size = 256
    # Larger ProDOS disks - treat as sector-based with virtual geometry
    elif data_size % 512 == 0 and data_size >= 35 * 16 * 512:
        # Convert from block-based to sector-based thinking
        # ProDOS blocks are 512 bytes = 2 sectors, so total sectors = size / 256
        total_sectors = data_size // 256
        tracks = 35
        sectors_per_track = total_sectors // tracks
        sector_size = 256

        # For ProDOS block-based disks, treat them as regular sector-based disks
        # since the interleaving still applies at the sector level
    else:
        raise DiskiiError(f"Unsupported disk size: {data_size} bytes")

    # DOS sector interleave pattern (for DOS-ordered disks)
    dos_interleave = [0, 7, 14, 6, 13, 5, 12, 4, 11, 3, 10, 2, 9, 1, 8, 15]

    # Create output buffer
    output_data = bytearray(data_size)

    # Reorder each sector
    for track in range(tracks):
        for logical_sector in range(
            min(sectors_per_track, 16)
        ):  # DOS interleave only applies to 16-sector disks
            # Calculate source physical sector
            if source_ordering == SectorOrdering.DOS_ORDER and sectors_per_track == 16:
                source_physical_sector = dos_interleave[logical_sector]
            else:
                source_physical_sector = logical_sector

            # Calculate destination physical sector
            if dest_ordering == SectorOrdering.DOS_ORDER and sectors_per_track == 16:
                dest_physical_sector = dos_interleave[logical_sector]
            else:
                dest_physical_sector = logical_sector

            # Calculate byte offsets
            source_offset = (
                track * sectors_per_track + source_physical_sector
            ) * sector_size
            dest_offset = (
                track * sectors_per_track + dest_physical_sector
            ) * sector_size

            # Copy sector data
            if source_offset + sector_size <= len(data):
                output_data[dest_offset : dest_offset + sector_size] = data[
                    source_offset : source_offset + sector_size
                ]

    return bytes(output_data)


def _reorder_blocks(
    data: bytes, source_ordering: SectorOrdering, dest_ordering: SectorOrdering
) -> bytes:
    """Reorder block-based disk images.

    Note: In the current implementation, ProDOS block-based disks are handled
    as sector-based disks by _reorder_sectors(). This function is kept for
    compatibility but should return data unchanged for pure block operations.
    """
    # For block-based operations without sector interleaving, return unchanged
    return data
