#!/usr/bin/env python3
"""Main entry point for diskii command line interface."""

import argparse
import sys
from pathlib import Path
from typing import NoReturn

from ..exceptions import DiskiiError


def create_parser() -> argparse.ArgumentParser:
    """Create the main argument parser."""
    parser = argparse.ArgumentParser(
        prog="diskii",
        description="Apple II disk image manipulation tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""Examples:
  diskii info mydisk.dsk                  # Show single disk information
  diskii info "*.dsk" --summary           # Show summary for multiple disks
  diskii extract mydisk.po                # Extract all files from one disk
  diskii extract "*.dsk" --output extracted/ # Extract from multiple disks
  diskii extract mydisk.dsk HELLO.BAS    # Extract specific file
  diskii add mydisk.po myfile.txt *.bas   # Add multiple files to disk
  diskii create blank.po --name MYDISK    # Create blank ProDOS disk
  diskii reorder mydisk.dsk output.po     # Reorder DOS-ordered to ProDOS-ordered
  diskii basic detokenize HELLO.BAS       # Detokenize BASIC program

For more help on a specific command, use: diskii <command> --help""",
    )

    subparsers = parser.add_subparsers(
        dest="command", help="Available commands", metavar="<command>"
    )

    # info command
    info_parser = subparsers.add_parser(
        "info",
        help="Show disk image information",
        description=(
            "Display information about one or more disk images including format, "
            "files, and free space."
        ),
    )
    info_parser.add_argument("image", help="Disk image file (supports wildcards)")
    info_parser.add_argument(
        "--detailed", "-d", action="store_true", help="Show detailed file metadata"
    )
    info_parser.add_argument(
        "--tree", "-t", action="store_true", help="Show files in tree format"
    )
    info_parser.add_argument(
        "--summary", "-s", action="store_true", help="Show summary for multiple disks"
    )

    # extract command
    extract_parser = subparsers.add_parser(
        "extract",
        help="Extract files from disk image(s)",
        description="Extract files from disk images. Use wildcards for multiple disks.",
    )
    extract_parser.add_argument("image", help="Disk image file (supports wildcards)")
    extract_parser.add_argument(
        "files", nargs="*", help="Files to extract (default: all files)"
    )
    extract_parser.add_argument(
        "--output-dir",
        "-o",
        type=Path,
        help="Output directory (default: current directory)",
    )
    extract_parser.add_argument(
        "--raw",
        "-r",
        action="store_true",
        help="Extract BASIC programs as raw binary (default is text conversion)",
    )
    extract_parser.add_argument(
        "--preserve-types",
        action="store_true",
        help="Preserve Apple II file type information",
    )

    # add command
    add_parser = subparsers.add_parser(
        "add",
        help="Add files to disk image",
        description="Add one or more files to a disk image.",
    )
    add_parser.add_argument("image", help="Disk image file")
    add_parser.add_argument("files", nargs="+", help="Files to add")
    add_parser.add_argument(
        "--type", help="Override file type detection (e.g., TXT, BIN, BAS)"
    )
    add_parser.add_argument(
        "--backup", "-b", action="store_true", help="Create backup before writing"
    )

    # create command
    create_parser = subparsers.add_parser(
        "create",
        help="Create blank disk image",
        description="Create a new blank disk image.",
    )
    create_parser.add_argument("image", help="Output disk image file")
    create_parser.add_argument(
        "--format",
        choices=["prodos", "dos33", "dos32"],
        help="Disk format (auto-detected from extension if not specified)",
    )
    create_parser.add_argument("--size", help="Disk size (e.g., 140K, 800K, 32M)")
    create_parser.add_argument("--name", help="Volume name")

    # reorder command
    reorder_parser = subparsers.add_parser(
        "reorder",
        help="Reorder sectors between different orderings",
        description=(
            "Reorder a disk image between different sector orderings without "
            "changing the filesystem. Common reorderings: .dsk (DOS-ordered) ↔ "
            ".po (ProDOS-ordered), .do ↔ .po, .dsk ↔ .hdv. The filesystem and "
            "all files remain unchanged - only the physical sector arrangement "
            "is reordered."
        ),
    )
    reorder_parser.add_argument(
        "source", help="Source disk image (.dsk, .do, .po, .hdv, .d13)"
    )
    reorder_parser.add_argument(
        "dest", help="Destination disk image (sector ordering determined by extension)"
    )
    reorder_parser.add_argument(
        "--backup",
        "-b",
        action="store_true",
        help="Create backup of source before reordering",
    )

    # basic command
    basic_parser = subparsers.add_parser(
        "basic",
        help="BASIC program utilities",
        description="Utilities for working with Apple II BASIC programs.",
    )
    basic_subparsers = basic_parser.add_subparsers(
        dest="basic_command", help="BASIC operations"
    )

    # basic tokenize
    tokenize_parser = basic_subparsers.add_parser(
        "tokenize", help="Convert BASIC text to tokens"
    )
    tokenize_parser.add_argument("input", help="Text file or '-' for stdin")
    tokenize_parser.add_argument(
        "--variant",
        choices=["applesoft", "integer"],
        default="applesoft",
        help="BASIC variant",
    )
    tokenize_parser.add_argument(
        "--output", "-o", help="Output file (default: stdout as hex)"
    )

    # basic detokenize
    detokenize_parser = basic_subparsers.add_parser(
        "detokenize", help="Convert BASIC tokens to text"
    )
    detokenize_parser.add_argument("input", help="Tokenized file")
    detokenize_parser.add_argument(
        "--variant",
        choices=["applesoft", "integer"],
        default="applesoft",
        help="BASIC variant",
    )
    detokenize_parser.add_argument(
        "--output", "-o", help="Output text file (default: stdout)"
    )

    # basic validate
    validate_parser = basic_subparsers.add_parser(
        "validate", help="Validate BASIC syntax"
    )
    validate_parser.add_argument("input", help="BASIC text file")
    validate_parser.add_argument(
        "--variant",
        choices=["applesoft", "integer"],
        default="applesoft",
        help="BASIC variant",
    )

    # basic extract
    extract_basic_parser = basic_subparsers.add_parser(
        "extract", help="Extract and detokenize BASIC files from disk"
    )
    extract_basic_parser.add_argument("image", help="Disk image file")
    extract_basic_parser.add_argument(
        "files", nargs="*", help="BASIC files to extract (default: all BASIC files)"
    )
    extract_basic_parser.add_argument(
        "--output-dir", "-o", type=Path, help="Output directory"
    )

    return parser


def main() -> NoReturn:
    """Main entry point for the diskii CLI."""
    parser = create_parser()
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    try:
        # Import commands dynamically to avoid circular imports
        if args.command == "info":
            from .commands.info import run_info

            run_info(args)
        elif args.command == "extract":
            from .commands.extract import run_extract

            run_extract(args)
        elif args.command == "add":
            from .commands.add import run_add

            run_add(args)
        elif args.command == "create":
            from .commands.create import run_create

            run_create(args)
        elif args.command == "reorder":
            from .commands.reorder import run_reorder

            run_reorder(args)
        elif args.command == "basic":
            from .commands.basic import run_basic

            run_basic(args)
        else:
            print(f"Unknown command: {args.command}", file=sys.stderr)
            sys.exit(1)

    except DiskiiError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except KeyboardInterrupt:
        print("\nInterrupted", file=sys.stderr)
        sys.exit(130)
    except Exception as e:
        print(f"Unexpected error: {e}", file=sys.stderr)
        sys.exit(1)

    sys.exit(0)


if __name__ == "__main__":
    main()
