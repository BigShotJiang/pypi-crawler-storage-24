"""Common file entry interface for different filesystems."""

import struct
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .dos import DOSFilename
    from .image import UnifiedDiskImage
    from .prodos.filesystem import ProDOSSubdirectory

from .exceptions import InvalidFileError


class FileType(Enum):
    """Common file types across DOS and ProDOS."""

    # DOS 3.3 types
    TEXT = "TXT"  # DOS: T
    INTEGER_BASIC = "INT"  # DOS: I
    APPLESOFT_BASIC = "BAS"  # DOS: A
    BINARY = "BIN"  # DOS: B
    SPECIAL = "SPC"  # DOS: S
    RELOCATABLE = "REL"  # DOS: R

    # ProDOS types (using hex values)
    PRODOS_UNK = 0x00  # Unknown
    PRODOS_BAD = 0x01  # Bad blocks
    PRODOS_PCD = 0x02  # Pascal code
    PRODOS_PTX = 0x03  # Pascal text
    PRODOS_TXT = 0x04  # ASCII text
    PRODOS_PDA = 0x05  # Pascal data
    PRODOS_BIN = 0x06  # Binary
    PRODOS_FNT = 0x07  # Font
    PRODOS_FOT = 0x08  # Foto
    PRODOS_BA3 = 0x09  # Business BASIC (3.0)
    PRODOS_DA3 = 0x0A  # Business BASIC data
    PRODOS_WPF = 0x0B  # Word processor
    PRODOS_SOS = 0x0F  # SOS system
    PRODOS_DIR = 0x0F  # Directory
    PRODOS_RPD = 0x10  # RPS data
    PRODOS_RPI = 0x11  # RPS index
    PRODOS_AFD = 0x12  # AppleFile discard
    PRODOS_AFM = 0x13  # AppleFile model
    PRODOS_AFR = 0x14  # AppleFile report
    PRODOS_SCL = 0x15  # Screen library
    PRODOS_PFS = 0x16  # PFS document
    PRODOS_ADB = 0x19  # AppleWorks database
    PRODOS_AWP = 0x1A  # AppleWorks word processor
    PRODOS_ASP = 0x1B  # AppleWorks spreadsheet


@dataclass
class FileEntry(ABC):
    """Abstract base class for file entries."""

    filename: str
    file_type: FileType | int | str
    size: int
    locked: bool

    @abstractmethod
    def read_data(
        self, image: Any | None = None, *, strip_binary_headers: bool = False
    ) -> bytes:
        """Read the file's data content per DOS 3.3 specification.
        Args:
            image: Disk image reference (may be required for some implementations)
            strip_binary_headers: If True, strip DOS headers from binary files only.
        """
        pass

    @property
    @abstractmethod
    def is_directory(self) -> bool:
        """Check if this entry represents a directory."""
        pass

    @property
    @abstractmethod
    def creation_date(self) -> datetime | None:
        """Get file creation date if available."""
        pass

    @property
    @abstractmethod
    def modification_date(self) -> datetime | None:
        """Get file modification date if available."""
        pass


@dataclass
class DOSFileEntry(FileEntry):
    def _extract_binary_data_only(self, file_data: bytes) -> bytes:
        """Extract just the data portion from binary files (optional convenience).
        Tries to detect and parse DOS binary headers to extract just the program data.
        """
        try:
            # Try DOS standard format (start_addr + length + data)
            if len(file_data) >= 4:
                start_addr, data_length = struct.unpack("<HH", file_data[0:4])
                # Valid DOS header: reasonable address and length that fits
                # (match DOS writer logic)
                if (
                    0x0800 <= start_addr <= 0xFFFF
                    and 0 < data_length <= len(file_data) - 4
                    and data_length < 32768
                    and data_length != start_addr  # Avoid false positives
                    and data_length <= 16384
                ):  # More conservative size limit
                    return file_data[4 : 4 + data_length]

            # Try diskii 4-byte size header format FIRST (more specific than 2-byte)
            if len(file_data) >= 4:
                potential_length = struct.unpack("<I", file_data[0:4])[0]
                data_available = len(file_data) - 4

                # Check if header length is reasonable and within normal limits
                if 0 < potential_length <= 65536:  # Max reasonable size
                    if potential_length <= data_available:
                        # Standard case: extract exact amount specified in header
                        return file_data[4 : 4 + potential_length]
                    else:
                        # Edge case: header claims more data than available after header
                        # (file might be truncated to sector boundary)
                        # Extract available data and pad with zeros to match claim
                        data_portion = file_data[4:]
                        missing_bytes = max(0, potential_length - len(data_portion))
                        padding = bytes(missing_bytes)  # Create zero padding
                        return data_portion + padding

            # Try diskii 2-byte size header format (used by our DOS writer)
            if len(file_data) >= 2:
                potential_length = struct.unpack("<H", file_data[0:2])[0]
                data_available = len(file_data) - 2

                # Check if header length is reasonable and fits in available data
                # This format is used by our DOS writer - files are padded
                if 0 < potential_length <= 65536 and potential_length <= data_available:
                    return file_data[2 : 2 + potential_length]
        except struct.error:
            # If struct parsing fails, return all data
            pass

        # Fallback: return all data (headers couldn't be parsed)
        return file_data

    """DOS 3.3 file entry."""

    track: int
    sector: int
    length_sectors: int
    dos_type: str  # T, I, A, B, S, R
    _raw_filename_bytes: bytes | None = None  # Raw 30-byte filename from catalog
    _image: "UnifiedDiskImage | None" = None  # Image reference for file reading

    def __post_init__(self) -> None:
        # Convert DOS type to common FileType
        dos_to_common = {
            "T": FileType.TEXT,
            "I": FileType.INTEGER_BASIC,
            "A": FileType.APPLESOFT_BASIC,
            "B": FileType.BINARY,
            "S": FileType.SPECIAL,
            "R": FileType.RELOCATABLE,
        }
        self.file_type = dos_to_common.get(self.dos_type, self.dos_type)

    @property
    def is_directory(self) -> bool:
        """DOS 3.3 doesn't have directories."""
        return False

    @property
    def creation_date(self) -> datetime | None:
        """DOS 3.3 doesn't store creation dates."""
        return None

    @property
    def modification_date(self) -> datetime | None:
        """DOS 3.3 doesn't store modification dates."""
        return None

    @property
    def actual_size(self) -> int:
        """Get actual file content size (not allocated sector size).

        For DOS files, this reads the file content and determines the true size:
        - Binary files: uses DOS binary header if valid
        - Text/BASIC files: finds logical end of content
        - Others: falls back to allocated size
        """
        try:
            data = self.read_data()

            if self.file_type == FileType.BINARY:
                # For binary files, try to extract just the data portion
                binary_data = self._extract_binary_data_only(data)
                if len(binary_data) < len(data):
                    return len(binary_data)

            # For Integer BASIC files, parse the line structure to find program end
            if self.file_type == FileType.INTEGER_BASIC:
                pos = 0
                while pos < len(data):
                    # Check if we have enough bytes for a line header
                    if pos + 3 > len(data):
                        break

                    # Read line length
                    line_length = data[pos]
                    if line_length == 0:
                        # Zero length indicates end of program
                        return pos

                    # Validate line length is reasonable
                    if line_length < 4 or pos + line_length > len(data):
                        # Invalid line length - program ends here
                        return pos

                    # Read line number (2 bytes, little endian)
                    line_number = data[pos + 1] | (data[pos + 2] << 8)

                    # Validate line number is reasonable (1-63999)
                    if line_number == 0 or line_number > 63999:
                        # Invalid line number - program ends here
                        return pos

                    # Check that line ends with 0x01 (end-of-line token)
                    end_of_line_pos = pos + line_length - 1
                    if end_of_line_pos >= len(data) or data[end_of_line_pos] != 0x01:
                        # Line doesn't end with proper token - program ends here
                        return pos

                    # Move to next line
                    pos += line_length

                # Reached end of data
                return pos

            # For text and Applesoft BASIC files, find logical end
            elif self.file_type in [FileType.TEXT, FileType.APPLESOFT_BASIC]:
                # Find last non-null byte
                for i in range(len(data) - 1, -1, -1):
                    if data[i] != 0:
                        return i + 1

            # Fall back to raw data length
            return len(data)

        except Exception:
            # If any error occurs, fall back to sector-based size
            return self.size

    @property
    def raw_filename_bytes(self) -> bytes:
        """Get raw filename bytes as stored in DOS catalog."""
        if self._raw_filename_bytes is not None:
            return self._raw_filename_bytes

        # If no raw bytes stored, generate from display filename
        from .dos import create_catalog_filename_bytes

        try:
            return create_catalog_filename_bytes(self.filename)
        except ValueError:
            # Fallback for invalid filenames
            padded = self.filename.ljust(30)[:30]
            return padded.encode("ascii", errors="replace")

    def set_raw_filename_bytes(self, raw_bytes: bytes) -> None:
        """Set raw filename bytes and update display filename.

        Args:
            raw_bytes: 30-byte raw filename from DOS catalog
        """
        if len(raw_bytes) != 30:
            raise ValueError("DOS filename must be exactly 30 bytes")

        self._raw_filename_bytes = raw_bytes

        # Update display filename from raw bytes
        from .dos import DOSFilename

        dos_filename = DOSFilename(raw_bytes)
        self.filename = dos_filename.padded_name

    def get_dos_filename(self) -> "DOSFilename":
        """Get DOSFilename object for advanced filename operations.

        Returns:
            DOSFilename instance with raw and display representations
        """
        from .dos import DOSFilename

        return DOSFilename(self.raw_filename_bytes)

    def set_filename(self, new_filename: str) -> None:
        """Set filename with DOS validation and encoding.

        Args:
            new_filename: New filename to set

        Raises:
            ValueError: If filename is invalid for DOS
        """
        from .dos import DOSFilename, validate_dos_filename

        if not validate_dos_filename(new_filename):
            raise ValueError(f"Invalid DOS filename: {new_filename}")

        # Create DOSFilename and update both raw and display
        dos_filename = DOSFilename.from_display_name(new_filename)
        self._raw_filename_bytes = dos_filename.raw_bytes
        self.filename = dos_filename.padded_name

    def set_locked(self, locked: bool) -> None:
        """Set the locked status of this DOS file.

        Args:
            locked: True to lock the file, False to unlock

        Note:
            This only updates the memory representation. To persist changes,
            the catalog must be rewritten to disk.
        """
        self.locked = locked

    def get_catalog_entry_bytes(self) -> bytes:
        """Get the 35-byte catalog entry for this file.

        Returns:
            35-byte catalog entry data suitable for writing to DOS catalog
        """
        entry = bytearray(35)

        # Bytes 0-1: Track/sector of first T/S list
        entry[0] = self.track
        entry[1] = self.sector

        # Byte 2: File type and flags
        dos_type_map = {
            "T": 0x00,  # Text
            "I": 0x01,  # Integer BASIC
            "A": 0x02,  # Applesoft BASIC
            "B": 0x04,  # Binary
            "S": 0x08,  # Special/Typeless
            "R": 0x10,  # Relocatable
        }

        type_byte = dos_type_map.get(self.dos_type, 0x04)  # Default to binary

        # Set lock bit (bit 6) if file is locked
        if self.locked:
            type_byte |= 0x40

        entry[2] = type_byte

        # Bytes 3-32: Raw filename bytes (30 characters)
        raw_filename = self.raw_filename_bytes
        entry[3:33] = raw_filename

        # Bytes 33-34: File length in sectors (little-endian)
        length_bytes = struct.pack("<H", self.length_sectors)
        entry[33:35] = length_bytes

        return bytes(entry)

    def read_data(
        self, image: Any | None = None, *, strip_binary_headers: bool = False
    ) -> bytes:
        """Read file data from the DOS 3.3 disk image (CiderPress compatible).
        Args:
            image: Disk image reference (optional, uses self._image if not provided)
            strip_binary_headers: If True, strip DOS headers from binary files only.
        Returns:
            File content bytes matching self.size (CiderPress compatible behavior)
        """
        if hasattr(self, "_image") and self._image:
            from .dos import DOSTrackSectorList
            from .exceptions import DiskiiError

            try:
                ts_list = DOSTrackSectorList(self._image, self.track, self.sector)
                sectors = ts_list.read_sectors()
            except Exception as e:
                raise DiskiiError(f"Failed to read file data: {e}") from e

            if not sectors:
                return b""

            # Combine all sectors into file data
            file_data = bytearray()
            for sector_data in sectors:
                file_data.extend(sector_data)

            # Return exactly self.size bytes (CiderPress compatible)
            # This matches the size calculation in _calculate_dos_file_size
            if self.dos_type == "T":  # Text files
                # For text files, return data up to first null byte
                for i, byte_val in enumerate(file_data):
                    if byte_val == 0:
                        return bytes(file_data[:i])
                # If no null found, return all data limited to file size
                return bytes(file_data[: self.size])

            elif self.dos_type in ["I", "A"]:  # Integer/Applesoft BASIC
                # Return content after 2-byte length header, limited to file size
                if len(file_data) >= 2:
                    content_start = 2  # Skip 2-byte length header
                    return bytes(file_data[content_start : content_start + self.size])
                return b""

            elif self.dos_type == "B":  # Binary files
                if strip_binary_headers:
                    # Extract data portion only, trying to detect headers
                    return self._extract_binary_data_only(file_data)
                else:
                    # Default: return content after headers, exactly self.size bytes
                    # Try to detect header format and skip appropriately
                    if len(file_data) >= 4:
                        # Check for diskii 4-byte format (length prefix)
                        potential_length = struct.unpack("<I", file_data[0:4])[0]
                        if potential_length == self.size:
                            return bytes(file_data[4 : 4 + self.size])

                        # Check for diskii 2-byte format (length prefix)
                        if len(file_data) >= 2:
                            potential_length_2 = struct.unpack("<H", file_data[0:2])[0]
                            if potential_length_2 == self.size:
                                return bytes(file_data[2 : 2 + self.size])

                        # Check for standard DOS format (start_addr + length + data)
                        if len(file_data) >= 4:
                            start_addr, data_length = struct.unpack(
                                "<HH", file_data[0:4]
                            )
                            if data_length == self.size:
                                return bytes(file_data[4 : 4 + self.size])

                    # Fallback: assume first few bytes are headers, return self.size
                    # Try different header sizes (4 bytes most common for diskii format)
                    for header_size in [4, 2, 0]:
                        if len(file_data) >= header_size + self.size:
                            return bytes(
                                file_data[header_size : header_size + self.size]
                            )
                        elif header_size == 0:  # Last resort: return what we have
                            if len(file_data) >= self.size:
                                return bytes(file_data[: self.size])
                            else:
                                # If severely truncated (< half expected), return raw
                                # This handles error cases and malformed files
                                if len(file_data) < self.size // 2:
                                    return bytes(file_data)
                                # Otherwise pad with zeros (CiderPress behavior)
                                return bytes(file_data) + bytes(
                                    self.size - len(file_data)
                                )

                    # Last resort: return exactly self.size bytes, padding if necessary
                    # This matches CiderPress behavior
                    if len(file_data) >= self.size:
                        return bytes(file_data[: self.size])
                    else:
                        # Pad with zeros to reach catalog size
                        padded_data = bytes(file_data) + bytes(
                            self.size - len(file_data)
                        )
                        return padded_data

            else:  # S, R, and other types
                # Apply sector length limit and file size limit
                max_data_length = self.length_sectors * 256
                return bytes(file_data[: min(self.size, max_data_length)])

        raise InvalidFileError(
            "No image reference available for file reading", self.filename
        )

    def read_data_at(self, offset: int, length: int) -> bytes:
        """Read file data at a specific offset.

        Args:
            offset: Byte offset within the file
            length: Number of bytes to read

        Returns:
            Data read from the specified position

        Raises:
            ValueError: If offset is negative or beyond file size
        """
        if offset < 0:
            raise ValueError("Offset cannot be negative")

        # For random access, we need to read the raw sectors without
        # applying file type-specific processing
        if hasattr(self, "_image") and self._image:
            from .dos import DOSTrackSectorList

            ts_list = DOSTrackSectorList(self._image, self.track, self.sector)
            sectors = ts_list.read_sectors()

            if not sectors:
                return b""

            # Combine all sectors into raw file data
            raw_data = bytearray()
            for sector_data in sectors:
                raw_data.extend(sector_data)

            # For random access, we preserve the full sector data including nulls
            # This is important for DOS random access text files
            if offset >= len(raw_data):
                return b""

            end_pos = min(offset + length, len(raw_data))
            return bytes(raw_data[offset:end_pos])

        raise InvalidFileError(
            "No image reference available for file reading", self.filename
        )

    def write_data_at(self, offset: int, data: bytes) -> None:
        """Write file data at a specific offset.

        Args:
            offset: Byte offset within the file
            data: Data to write

        Raises:
            ValueError: If offset is negative
            NotImplementedError: Writing is not yet implemented
        """
        if offset < 0:
            raise ValueError("Offset cannot be negative")

        # TODO: Implement random access writing
        # This requires updating the track/sector list and potentially
        # allocating new sectors if the file grows
        raise NotImplementedError("Random access writing not yet implemented")

    def get_raw_size(self) -> int:
        """Get the raw size of the file including all sectors.

        For random access operations, this returns the total size
        of all sectors in the track/sector list, not the logical
        file size which may be smaller.

        Returns:
            Raw size in bytes of all allocated sectors
        """
        if hasattr(self, "_image") and self._image:
            from .dos import DOSTrackSectorList

            ts_list = DOSTrackSectorList(self._image, self.track, self.sector)
            sectors = ts_list.read_sectors()

            return len(sectors) * 256  # DOS sectors are 256 bytes each

        return 0

    def read_as_text(self) -> str:
        """Read BASIC file as plain text (detokenized if necessary).

        Returns:
            Plain text BASIC program
        """
        if self.dos_type not in ("A", "I"):
            raise InvalidFileError(
                f"Cannot read file type '{self.dos_type}' as BASIC text", self.filename
            )

        # Read raw file data
        data = self.read_data()

        # Import here to avoid circular imports
        from .basic_tokenizer import (
            detokenize_applesoft,
            detokenize_integer_basic,
        )

        # Detect if data is tokenized or already plain text
        if self._is_tokenized_data(data):
            # Detokenize based on file type
            if self.dos_type == "A":  # Applesoft
                return detokenize_applesoft(data)
            else:  # Integer BASIC
                return detokenize_integer_basic(data)
        else:
            # Already plain text
            try:
                return data.decode("ascii")
            except UnicodeDecodeError:
                # Fallback for non-ASCII data
                return data.decode("ascii", errors="replace")

    def read_as_tokens(self) -> bytes:
        """Read BASIC file as tokenized bytes.

        Returns:
            Tokenized BASIC program bytes
        """
        if self.dos_type not in ("A", "I"):
            raise InvalidFileError(
                f"Cannot read file type '{self.dos_type}' as BASIC tokens",
                self.filename,
            )

        # Read raw file data
        data = self.read_data()

        # If already tokenized, return as-is
        if self._is_tokenized_data(data):
            return data

        # Need to tokenize plain text
        from .basic_tokenizer import tokenize_applesoft, tokenize_integer_basic

        try:
            text = data.decode("ascii")
            if self.dos_type == "A":  # Applesoft
                return tokenize_applesoft(text)
            else:  # Integer BASIC
                return tokenize_integer_basic(text)
        except UnicodeDecodeError as e:
            # Cannot tokenize non-ASCII data
            raise InvalidFileError(
                "Cannot tokenize non-ASCII BASIC program", self.filename
            ) from e

    def _is_tokenized_data(self, data: bytes) -> bool:
        """Check if data appears to be tokenized BASIC.

        Args:
            data: File data to check

        Returns:
            True if data appears tokenized, False if plain text
        """
        if len(data) < 4:
            return False

        # Check for BASIC program structure:
        # - First 2 bytes: next line pointer (usually 0 for single line)
        # - Next 2 bytes: line number (little-endian, should be reasonable)
        try:
            line_num = struct.unpack("<H", data[2:4])[0]

            # Reasonable line numbers are typically 1-63999
            if not (1 <= line_num <= 63999):
                return False

            # Look for tokens in the data (high bit set for Applesoft)
            token_count = sum(1 for b in data[4 : min(len(data), 50)] if b >= 128)

            # If we have tokens, likely tokenized; if not, likely plain text
            return token_count > 0

        except (struct.error, IndexError):
            return False


@dataclass
class ProDOSFileEntry(FileEntry):
    """ProDOS file entry."""

    storage_type: int  # 1=seedling, 2=sapling, 3=tree, 0xD=subdirectory
    key_block: int
    blocks_used: int
    aux_type: int
    created: datetime | None = None
    modified: datetime | None = None
    access: int = 0  # Access permissions
    _image: "UnifiedDiskImage | None" = None  # Image reference for file reading
    _full_path: str | None = None  # Full path for hierarchical access

    @property
    def is_directory(self) -> bool:
        """Check if this is a subdirectory."""
        return self.storage_type == 0x0D

    @property
    def creation_date(self) -> datetime | None:
        """Get creation date."""
        return self.created

    @property
    def modification_date(self) -> datetime | None:
        """Get modification date."""
        return self.modified

    @property
    def is_seedling(self) -> bool:
        """Check if this is a seedling file (≤ 512 bytes)."""
        return self.storage_type == 1

    @property
    def is_sapling(self) -> bool:
        """Check if this is a sapling file (513-131,072 bytes)."""
        return self.storage_type == 2

    @property
    def is_tree(self) -> bool:
        """Check if this is a tree file (> 131,072 bytes)."""
        return self.storage_type == 3

    @property
    def full_path(self) -> str:
        """Get the full path of this file (including directory path).

        Returns the full path if it has been set during directory traversal,
        otherwise returns just the filename.
        """
        return self._full_path if self._full_path is not None else self.filename

    def read_data(
        self, image: Any | None = None, *, strip_binary_headers: bool = False
    ) -> bytes:
        """Read file data from the ProDOS image per specification.
        Args:
            image: Disk image reference (optional, uses self._image if not provided)
            strip_binary_headers: If True, strip DOS headers from binary files only.
        """
        if hasattr(self, "_image") and self._image:
            from .file_reading import read_prodos_file_data

            return read_prodos_file_data(self, self._image)
        raise InvalidFileError(
            "No image reference available for file reading",
            getattr(self, "filename", "unknown"),
        )

    def get_file_type_description(self) -> str:
        """Get human-readable description of the file type."""
        from .prodos import get_file_type_description

        if isinstance(self.file_type, int):
            file_type_int = self.file_type
        elif hasattr(self.file_type, "value") and isinstance(self.file_type.value, int):
            file_type_int = self.file_type.value
        else:
            file_type_int = 0
        return get_file_type_description(file_type_int)

    def get_aux_type_description(self) -> str | None:
        """Get human-readable description of the auxiliary type."""
        from .prodos import get_aux_type_description

        if isinstance(self.file_type, int):
            file_type_int = self.file_type
        elif hasattr(self.file_type, "value") and isinstance(self.file_type.value, int):
            file_type_int = self.file_type.value
        else:
            file_type_int = 0
        return get_aux_type_description(file_type_int, self.aux_type)

    def get_file_category(self) -> str:
        """Get general category of the file (Executable, Text, Data, etc.)."""
        from .prodos import get_file_category

        if isinstance(self.file_type, int):
            file_type_int = self.file_type
        elif hasattr(self.file_type, "value") and isinstance(self.file_type.value, int):
            file_type_int = self.file_type.value
        else:
            file_type_int = 0
        return get_file_category(file_type_int)

    def is_executable(self) -> bool:
        """Check if this file is executable."""
        from .prodos import is_executable_type

        if isinstance(self.file_type, int):
            file_type_int = self.file_type
        elif hasattr(self.file_type, "value") and isinstance(self.file_type.value, int):
            file_type_int = self.file_type.value
        else:
            file_type_int = 0
        return is_executable_type(file_type_int)

    def is_text_file(self) -> bool:
        """Check if this is a text file."""
        from .prodos import is_text_type

        if isinstance(self.file_type, int):
            file_type_int = self.file_type
        elif hasattr(self.file_type, "value") and isinstance(self.file_type.value, int):
            file_type_int = self.file_type.value
        else:
            file_type_int = 0
        return is_text_type(file_type_int)

    def is_graphics_file(self) -> bool:
        """Check if this is a graphics file."""
        from .prodos import is_graphics_type

        if isinstance(self.file_type, int):
            file_type_int = self.file_type
        elif hasattr(self.file_type, "value") and isinstance(self.file_type.value, int):
            file_type_int = self.file_type.value
        else:
            file_type_int = 0
        return is_graphics_type(file_type_int)

    def get_load_address(self) -> int | None:
        """Get load address for binary files, None for other types."""
        if self.file_type == 0x06:  # Binary file
            return self.aux_type
        return None

    def get_record_length(self) -> int | None:
        """Get record length for text files, None for other types."""
        if self.file_type == 0x04:  # Text file
            return self.aux_type if self.aux_type > 0 else None
        return None

    def read_subdirectory(self) -> "ProDOSSubdirectory":
        """Read subdirectory contents if this is a directory entry."""
        if not self.is_directory:
            raise ValueError(f"{self.filename} is not a directory")

        if hasattr(self, "_image") and self._image:
            from .prodos.filesystem import ProDOSSubdirectory

            return ProDOSSubdirectory(self._image, self.key_block, self.filename)

        raise InvalidFileError(
            "No image reference available for subdirectory reading", self.filename
        )

    def is_basic_file(self) -> bool:
        """Check if this is a BASIC program file."""
        return self.file_type in (0xFC, 0xFA)  # BAS (Applesoft) or INT (Integer)

    def read_as_text(self) -> str:
        """Read BASIC file as plain text (detokenized if necessary).

        Returns:
            Plain text BASIC program
        """
        if not self.is_basic_file():
            raise InvalidFileError(
                f"Cannot read file type ${self.file_type:02X} as BASIC text",
                self.filename,
            )

        # Read raw file data
        data = self.read_data()

        # Import here to avoid circular imports
        from .basic_tokenizer import detokenize_applesoft, detokenize_integer_basic

        # Detect if data is tokenized or already plain text
        if self._is_tokenized_data(data):
            # Detokenize based on file type
            if self.file_type == 0xFC:  # Applesoft BAS
                return detokenize_applesoft(data)
            else:  # Integer BASIC
                return detokenize_integer_basic(data)
        else:
            # Already plain text
            try:
                return data.decode("ascii")
            except UnicodeDecodeError:
                # Fallback for non-ASCII data
                return data.decode("ascii", errors="replace")

    def read_as_tokens(self) -> bytes:
        """Read BASIC file as tokenized bytes.

        Returns:
            Tokenized BASIC program bytes
        """
        if not self.is_basic_file():
            raise InvalidFileError(
                f"Cannot read file type ${self.file_type:02X} as BASIC tokens",
                self.filename,
            )

        # Read raw file data
        data = self.read_data()

        # If already tokenized, return as-is
        if self._is_tokenized_data(data):
            return data

        # Need to tokenize plain text
        from .basic_tokenizer import tokenize_applesoft, tokenize_integer_basic

        try:
            text = data.decode("ascii")
            if self.file_type == 0xFC:  # Applesoft BAS
                return tokenize_applesoft(text)
            else:  # Integer BASIC
                return tokenize_integer_basic(text)
        except UnicodeDecodeError as e:
            # Cannot tokenize non-ASCII data
            raise InvalidFileError(
                "Cannot tokenize non-ASCII BASIC program", self.filename
            ) from e

    def _is_tokenized_data(self, data: bytes) -> bool:
        """Check if data appears to be tokenized BASIC.

        Args:
            data: File data to check

        Returns:
            True if data appears tokenized, False if plain text
        """
        if len(data) < 4:
            return False

        # Check for BASIC program structure:
        # - First 2 bytes: next line pointer (usually 0 for single line)
        # - Next 2 bytes: line number (little-endian, should be reasonable)
        try:
            line_num = struct.unpack("<H", data[2:4])[0]

            # Reasonable line numbers are typically 1-63999
            if not (1 <= line_num <= 63999):
                return False

            # Look for tokens in the data
            if self.file_type == 0xFC:  # Applesoft - tokens are 128-255
                token_count = sum(1 for b in data[4 : min(len(data), 50)] if b >= 128)
            else:  # Integer BASIC - tokens are in different ranges
                token_count = sum(
                    1 for b in data[4 : min(len(data), 50)] if 16 <= b <= 102
                )

            # If we have tokens, likely tokenized; if not, likely plain text
            return token_count > 0

        except (struct.error, IndexError):
            return False


def normalize_filename(filename: str, target_system: str = "host") -> str:
    """Normalize filename for different systems.

    Args:
        filename: Original filename
        target_system: "host", "dos", or "prodos"
    """
    if target_system == "dos":
        # DOS 3.3 requirements: max 30 chars, high ASCII, must start with letter
        cleaned = filename.upper()[:30]
        if not cleaned or not cleaned[0].isalpha():
            cleaned = "A" + cleaned[:29]
        return cleaned

    elif target_system == "prodos":
        # ProDOS requirements: max 15 chars, letters/digits/periods only
        cleaned = ""
        for char in filename[:15]:
            if char.isalnum() or char == ".":
                cleaned += char.upper()
        if not cleaned or not cleaned[0].isalpha():
            cleaned = "A" + cleaned[:14]
        return cleaned

    else:  # host system
        # Convert high ASCII to regular ASCII, remove invalid chars
        cleaned = ""
        for char in filename:
            if ord(char) > 127:
                char = chr(ord(char) - 128)  # Convert high ASCII
            if char.isprintable() and char not in '<>:"/\\|?*':
                cleaned += char
        return cleaned or "unnamed"


def convert_file_type(
    file_type: FileType | int | str, target_system: str
) -> FileType | int | str:
    """Convert file type between systems."""
    if target_system == "dos":
        # Convert to DOS single character
        if isinstance(file_type, FileType):
            type_map: dict[FileType, str] = {
                FileType.TEXT: "T",
                FileType.INTEGER_BASIC: "I",
                FileType.APPLESOFT_BASIC: "A",
                FileType.BINARY: "B",
                FileType.SPECIAL: "S",
                FileType.RELOCATABLE: "R",
            }
            return type_map.get(file_type, "B")  # Default to binary
        # For non-enum types, check if it's a valid DOS type, otherwise default to "B"
        if isinstance(file_type, str) and file_type in ["T", "I", "A", "B", "S", "R"]:
            return file_type
        return "B"  # Default to binary for unknown types

    elif target_system == "prodos":
        # Convert to ProDOS hex type
        if isinstance(file_type, FileType):
            prodos_type_map: dict[FileType, int] = {
                FileType.TEXT: 0x04,
                FileType.INTEGER_BASIC: 0xFA,  # Integer BASIC
                FileType.APPLESOFT_BASIC: 0xFC,  # Applesoft BASIC
                FileType.BINARY: 0x06,
            }
            return prodos_type_map.get(file_type, 0x06)  # Default to binary
        return (
            int(file_type)
            if isinstance(file_type, (int, str)) and str(file_type).isdigit()
            else 0x06
        )

    return file_type
