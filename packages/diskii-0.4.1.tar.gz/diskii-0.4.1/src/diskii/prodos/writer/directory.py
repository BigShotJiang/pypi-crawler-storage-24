"""ProDOS directory creation and manipulation."""

import struct
from datetime import UTC, datetime
from typing import Any

from ...exceptions import (
    FileNotFoundError,
    FilesystemError,
    InvalidFileError,
)
from .allocator import (
    ProDOSBlockAllocator,
    _invalidate_image_cache,
    datetime_to_prodos_date,
)


def _validate_directory_space(image: Any, filename: str) -> None:
    """Validate that directory space is available, creating continuation
    blocks if needed."""
    # Basic validation that the image is not corrupted
    # The actual space allocation will be handled by _add_directory_entry
    # which can create continuation blocks as needed

    try:
        volume_block = image.read_block(2)
        if len(volume_block) != 512:
            raise FilesystemError(
                f"Invalid volume directory block size: {len(volume_block)}"
            )

        # Check volume directory header signature (storage type = 0xF at offset 4)
        volume_storage_type = (volume_block[4] >> 4) & 0x0F
        if volume_storage_type != 0x0F:
            raise FilesystemError(
                f"Invalid volume directory signature: expected 0xF, got "
                f"0x{volume_storage_type:X}"
            )
    except Exception as e:
        raise FilesystemError(f"Cannot validate directory structure: {e}") from e


def _add_directory_entry(
    image: Any,
    filename: str,
    file_type: int,
    file_size: int,
    storage_type: int,
    key_block: int,
    blocks_used: int,
    aux_type: int,
    created: datetime,
) -> None:
    """Add a directory entry for a new file."""

    # Read volume directory header block
    volume_block = image.read_block(2)
    volume_data = bytearray(volume_block)

    # Validate volume directory block structure
    if len(volume_data) != 512:
        raise FilesystemError(
            f"Invalid volume directory block size: {len(volume_data)}"
        )

    # Check volume directory header signature (storage type = 0xF at offset 4)
    volume_storage_type = (volume_data[4] >> 4) & 0x0F
    if volume_storage_type != 0x0F:
        raise FilesystemError(
            f"Invalid volume directory signature: expected 0xF, got "
            f"0x{volume_storage_type:X}"
        )

    # Verify this is actually a volume directory by checking the volume name length
    volume_name_length = volume_data[4] & 0x0F
    if volume_name_length == 0 or volume_name_length > 15:
        raise FilesystemError(f"Invalid volume name length: {volume_name_length}")

    # Find an empty directory entry (storage type = 0)
    # Search through all directory blocks including continuation blocks
    entry_size = 39
    entries_per_block = 13

    # Prepare the directory entry data first
    name_bytes = filename.upper().encode("ascii")
    if len(name_bytes) > 15:
        name_bytes = name_bytes[:15]

    # Build directory entry
    entry_data = bytearray(entry_size)

    # Byte 0: Storage type + name length
    entry_data[0] = (storage_type << 4) | len(name_bytes)

    # Bytes 1-15: Filename (padded with spaces)
    entry_data[1 : 1 + len(name_bytes)] = name_bytes

    # Byte 16: File type
    entry_data[16] = file_type

    # Bytes 17-18: Key block (little endian)
    struct.pack_into("<H", entry_data, 17, key_block)

    # Bytes 19-20: Blocks used (little endian)
    struct.pack_into("<H", entry_data, 19, blocks_used)

    # Bytes 21-23: End of file (file size, 3 bytes little endian)
    entry_data[21] = file_size & 0xFF
    entry_data[22] = (file_size >> 8) & 0xFF
    entry_data[23] = (file_size >> 16) & 0xFF

    # Bytes 24-27: Creation date/time
    date_bytes = datetime_to_prodos_date(created)
    entry_data[24:28] = date_bytes

    # Byte 30: Access permissions (default: read/write/rename)
    entry_data[30] = 0xE3

    # Bytes 31-32: Auxiliary type
    struct.pack_into("<H", entry_data, 31, aux_type)

    # Bytes 33-36: Last modified date/time (same as creation)
    entry_data[33:37] = date_bytes

    # Bytes 37-38: Header pointer (key block of directory containing this entry)
    # For volume directory entries this is always block 2; for subdirectory
    # entries it would be the subdirectory's key block.
    struct.pack_into("<H", entry_data, 37, 2)

    # Search for empty slot starting with volume directory block
    current_block_num = 2
    current_block_data = volume_data
    visited_blocks = set()

    while current_block_num != 0:
        # Prevent infinite loops
        if current_block_num in visited_blocks:
            break
        visited_blocks.add(current_block_num)

        # Determine how many entries to check in this block
        if current_block_num == 2:
            # Volume directory block - skip volume header (first entry)
            start_entry = 1
            max_entries = entries_per_block
        else:
            # Continuation block - all entries are available
            start_entry = 0
            max_entries = entries_per_block

        # Check each entry in this block
        for i in range(start_entry, max_entries):
            if current_block_num == 2:
                # Volume directory block: skip volume header
                offset = 4 + 39 + ((i - 1) * entry_size)
            else:
                # Continuation block: entries start after prev/next pointers
                offset = 4 + (i * entry_size)

            if offset + entry_size > len(current_block_data):
                break

            # Check if entry is empty (storage type = 0)
            storage_and_length = current_block_data[offset]
            existing_storage_type = (storage_and_length >> 4) & 0x0F

            if existing_storage_type == 0:
                # Found empty entry, write the file entry
                current_block_data[offset : offset + entry_size] = entry_data

                # Update file count in volume directory header (always in block 2)
                current_file_count = struct.unpack("<H", volume_data[0x25:0x27])[0]
                new_file_count = current_file_count + 1
                struct.pack_into("<H", volume_data, 0x25, new_file_count)

                # Write updated blocks
                image.write_block(
                    2, bytes(volume_data)
                )  # Always update volume directory
                if current_block_num != 2:
                    image.write_block(
                        current_block_num, bytes(current_block_data)
                    )  # Update continuation block if different

                # Invalidate file list cache after successful creation
                _invalidate_image_cache(image)
                return

        # No empty slot in this block, check for next block
        if len(current_block_data) >= 4:
            next_block = struct.unpack("<H", current_block_data[2:4])[0]
        else:
            next_block = 0

        if next_block == 0:
            # No more continuation blocks, need to create one
            allocator = ProDOSBlockAllocator(image)
            try:
                new_blocks = allocator.find_free_blocks(1)
                new_block = new_blocks[0]
                allocator.allocate_blocks([new_block])
            except FilesystemError as e:
                raise FilesystemError(
                    "Disk is full - cannot allocate directory continuation block"
                ) from e

            # Create new continuation block
            new_block_data = bytearray(512)

            # Set prev/next pointers
            struct.pack_into(
                "<H", new_block_data, 0, current_block_num
            )  # Previous block
            struct.pack_into("<H", new_block_data, 2, 0)  # Next block (none yet)

            # Add our entry as the first entry in the new block
            new_block_data[4 : 4 + entry_size] = entry_data

            # Update current block to point to new block
            struct.pack_into("<H", current_block_data, 2, new_block)

            # Update file count in volume directory header
            current_file_count = struct.unpack("<H", volume_data[0x25:0x27])[0]
            new_file_count = current_file_count + 1
            struct.pack_into("<H", volume_data, 0x25, new_file_count)

            # Write all updated blocks
            image.write_block(2, bytes(volume_data))  # Volume directory
            image.write_block(
                current_block_num, bytes(current_block_data)
            )  # Current block with updated next pointer
            image.write_block(
                new_block, bytes(new_block_data)
            )  # New continuation block

            # Invalidate file list cache after successful creation
            _invalidate_image_cache(image)
            return
        else:
            # Move to next continuation block
            current_block_num = next_block
            current_block_data = bytearray(image.read_block(current_block_num))

    raise FilesystemError("Directory continuation failed - possible circular reference")


def create_prodos_directory(image: Any, directory_path: str) -> None:
    """Create a new ProDOS directory.

    Args:
        image: ProDOS disk image
        directory_path: Path of directory to create (e.g., "SUBDIR" or "DIR1/SUBDIR")
    """
    from ..types import ProDOSFileType

    # For now, only support creating directories in the volume directory (root)
    # TODO: Add support for nested subdirectories
    if "/" in directory_path:
        raise FilesystemError(
            f"Nested subdirectory creation not yet supported: {directory_path}"
        )

    directory_name = directory_path.upper()

    # Validate directory name
    if not (1 <= len(directory_name) <= 15):
        raise InvalidFileError(
            f"Directory name must be 1-15 characters: {directory_name}"
        )

    # Check if directory already exists
    from ..filesystem import parse_prodos_directory

    volume = parse_prodos_directory(image)
    files = volume.parse()

    for file_entry in files:
        if file_entry.filename.upper() == directory_name:
            raise FilesystemError(f"Directory already exists: {directory_name}")

    # Allocate blocks for the directory
    allocator = ProDOSBlockAllocator(image)

    # A directory needs at least 1 block for the directory structure
    directory_blocks = allocator.find_free_blocks(1)
    if not directory_blocks:
        raise FilesystemError("No space available for directory")

    directory_block = directory_blocks[0]

    try:
        # Create directory structure in the allocated block
        _create_directory_block(image, directory_block, directory_name)

        # Add directory entry to volume directory
        _add_directory_entry(
            image,
            directory_name,
            ProDOSFileType.DIR,  # Directory file type is $0F
            0,  # No data length for directories
            0x0D,  # Directory storage type
            directory_block,  # key_block
            1,  # blocks_used - directory uses 1 block
            0,  # aux_type
            datetime.now(UTC),  # created
        )

        # Mark blocks as allocated in bitmap
        allocator.allocate_blocks(directory_blocks)

        # Invalidate file list cache after successful directory creation
        _invalidate_image_cache(image)

    except Exception:
        # Clean up on failure
        try:
            allocator.deallocate_blocks(directory_blocks)
        except Exception:
            pass
        raise


def delete_prodos_directory(image: Any, directory_path: str) -> None:
    """Delete a ProDOS directory.

    Args:
        image: ProDOS disk image
        directory_path: Path of directory to delete (e.g., "SUBDIR" or "DIR1/SUBDIR")
    """
    # For now, only support deleting directories in the volume directory (root)
    # TODO: Add support for nested subdirectories
    if "/" in directory_path:
        raise FilesystemError(
            f"Nested subdirectory deletion not yet supported: {directory_path}"
        )

    directory_name = directory_path.upper()

    # Find the directory entry
    from ..filesystem import parse_prodos_directory

    volume = parse_prodos_directory(image)
    files = volume.parse()

    directory_entry = None
    for file_entry in files:
        if file_entry.filename.upper() == directory_name and file_entry.is_directory:
            directory_entry = file_entry
            break

    if directory_entry is None:
        raise FileNotFoundError(directory_name, str(image.file_path))

    # Check if directory is empty
    # TODO: Parse subdirectory to check if it contains files
    # For now, assume it's safe to delete

    # Free the directory's blocks
    allocator = ProDOSBlockAllocator(image)

    # For directories, the key_pointer is the directory block
    if hasattr(directory_entry, "key_pointer") and directory_entry.key_pointer > 0:
        allocator.deallocate_blocks([directory_entry.key_pointer])

    # Remove directory entry from volume directory
    _remove_directory_entry(image, directory_name)

    # Invalidate file list cache after successful directory deletion
    _invalidate_image_cache(image)


def _create_directory_block(image: Any, block_num: int, directory_name: str) -> None:
    """Create the directory structure in a block.
    Args:
        image: ProDOS disk image
        block_num: Block number to write directory structure to
        directory_name: Name of the directory
    """
    # Create directory block with ProDOS directory structure
    dir_data = bytearray(512)

    # Directory header (first entry)
    # Storage type (0xE = directory header) + name length
    dir_data[0x00] = 0xE0 | len(directory_name)

    # Directory name
    dir_data[0x01 : 0x01 + len(directory_name)] = directory_name.encode("ascii")

    # Reserved bytes
    for i in range(len(directory_name) + 1, 0x14):
        dir_data[i] = 0x00

    # Creation date/time (use current time)
    creation_time = datetime_to_prodos_date(datetime.now(UTC))
    dir_data[0x18:0x1C] = creation_time

    # Version ($00), min_version ($00), access ($E3), entry_length ($27)
    dir_data[0x1C] = 0x00  # version
    dir_data[0x1D] = 0x00  # min_version
    dir_data[0x1E] = 0xE3  # access (read/write/rename/destroy)
    dir_data[0x1F] = 0x27  # entry_length (39 bytes)

    # Entries per block ($0D = 13), file_count (initially 0)
    dir_data[0x20] = 0x0D  # entries_per_block
    dir_data[0x21] = 0x00  # file_count low
    dir_data[0x22] = 0x00  # file_count high

    # Parent pointers (for subdirectories - point back to volume)
    dir_data[0x23] = 0x02  # parent_pointer low (volume directory is block 2)
    dir_data[0x24] = 0x00  # parent_pointer high
    dir_data[0x25] = 0x01  # parent_entry (entry 1 in volume directory)
    dir_data[0x26] = 0x27  # parent_entry_length

    # Rest of block remains zeros (empty directory entries)

    # Write the directory block
    image.write_block(block_num, bytes(dir_data))


def _remove_directory_entry(image: Any, filename: str) -> None:
    """Remove a file/directory entry from the volume directory.
    Args:
        image: ProDOS disk image
        filename: Name of file/directory to remove
    """
    # Read volume directory header block
    volume_data = bytearray(image.read_block(2))
    entry_size = 39  # ProDOS directory entry size

    # Start after volume header (first entry at offset 4 + 39 = 43)
    for entry_num in range(1, 13):  # Skip header entry (0), check entries 1-12
        offset = 4 + entry_num * entry_size

        if offset + entry_size > len(volume_data):
            break

        # Check storage type and name
        storage_and_length = volume_data[offset]
        storage_type = (storage_and_length >> 4) & 0x0F
        name_length = storage_and_length & 0x0F

        if storage_type != 0 and name_length > 0:
            entry_filename = volume_data[offset + 1 : offset + 1 + name_length].decode(
                "ascii"
            )

            if entry_filename.upper() == filename.upper():
                # Found the entry, mark as deleted (storage type = 0)
                volume_data[offset] = 0  # Clear storage type and name length

                # Clear the entire entry
                volume_data[offset : offset + entry_size] = bytes(entry_size)

                # Update file count in volume directory header
                current_file_count = struct.unpack("<H", volume_data[0x25:0x27])[0]
                new_file_count = max(0, current_file_count - 1)  # Prevent underflow
                struct.pack_into("<H", volume_data, 0x25, new_file_count)

                # Write updated directory block
                image.write_block(2, bytes(volume_data))

                # Invalidate file list cache after successful deletion
                _invalidate_image_cache(image)
                return

    # TODO: Handle directory continuation blocks
    raise FileNotFoundError(filename, str(image.file_path))
