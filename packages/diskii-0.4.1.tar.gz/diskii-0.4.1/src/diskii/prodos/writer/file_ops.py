"""ProDOS file creation, deletion, truncation, and move operations."""

from datetime import UTC, datetime
from typing import Any

from ...exceptions import (
    FileNotFoundError,
    FilesystemError,
    InvalidFileError,
)
from ..filesystem import ProDOSVolumeDirectory
from .allocator import (
    ProDOSBlockAllocator,
    _invalidate_image_cache,
)
from .directory import (
    _add_directory_entry,
    _validate_directory_space,
)


def create_prodos_file(
    image: Any,
    filename: str,
    file_type: int,
    data: bytes,
    aux_type: int = 0,
    created: datetime | None = None,
) -> None:
    """Create a new file on a ProDOS disk image.

    Args:
        image: UnifiedDiskImage instance
        filename: Name of the file to create
        file_type: ProDOS file type (e.g., 0x04 for text, 0x06 for binary)
        data: File content bytes
        aux_type: Auxiliary type information
        created: Creation date (defaults to current time)

    Raises:
        InvalidFileError: If filename already exists or is invalid
        FilesystemError: If not enough free space
    """
    if created is None:
        created = datetime.now(UTC)

    # Validate filename
    if not filename or len(filename) > 15:
        raise InvalidFileError(f"Invalid filename: {filename}")

    # Check if file already exists
    existing_files = image.get_file_list()
    for existing_file in existing_files:
        if existing_file.filename.upper() == filename.upper():
            raise InvalidFileError(f"File already exists: {filename}")

    # Determine storage type based on file size
    file_size = len(data)

    if file_size <= 512:
        # Seedling file - single data block
        storage_type = 1
        blocks_needed = 1
    elif file_size <= 131072:  # 256 blocks * 512 bytes
        # Sapling file - index block + data blocks
        storage_type = 2
        data_blocks_needed = (file_size + 511) // 512
        blocks_needed = data_blocks_needed + 1  # +1 for index block
    else:
        # Tree file - master index + index blocks + data blocks
        storage_type = 3
        data_blocks_needed = (file_size + 511) // 512
        index_blocks_needed = (data_blocks_needed + 255) // 256
        blocks_needed = (
            data_blocks_needed + index_blocks_needed + 1
        )  # +1 for master index

    # Allocate blocks (but don't mark them as allocated yet)
    allocator = ProDOSBlockAllocator(image)
    allocated_blocks = allocator.find_free_blocks(blocks_needed)

    # Pre-validate directory space is available before making any changes
    try:
        _validate_directory_space(image, filename)
    except FilesystemError as e:
        raise FilesystemError(f"Cannot create file {filename}: {e}") from e

    # Save original directory state for rollback
    original_directory_block = image.read_block(2)

    try:
        # Write file data based on storage type
        if storage_type == 1:
            # Seedling: write data directly to block
            key_block = allocated_blocks[0]
            padded_data = data.ljust(512, b"\x00")
            image.write_block(key_block, padded_data)

        elif storage_type == 2:
            # Sapling: create index block pointing to data blocks
            key_block = allocated_blocks[0]
            data_blocks = allocated_blocks[1:]

            # Create index block using ProDOS split-block format
            # Low bytes in first half (0-255), high bytes in second half (256-511)
            index_data = bytearray(512)
            for i, data_block in enumerate(data_blocks):
                if i < 256:  # Max 256 pointers per index block
                    low_byte = data_block & 0xFF
                    high_byte = (data_block >> 8) & 0xFF
                    index_data[i] = low_byte  # Low byte in first half
                    index_data[i + 256] = high_byte  # High byte in second half

            image.write_block(key_block, bytes(index_data))

            # Write data blocks
            for i, data_block in enumerate(data_blocks):
                start_offset = i * 512
                end_offset = min(start_offset + 512, len(data))
                block_data = data[start_offset:end_offset].ljust(512, b"\x00")
                image.write_block(data_block, block_data)

        else:  # storage_type == 3
            # Tree: create master index pointing to index blocks pointing to data blocks
            key_block = allocated_blocks[0]
            remaining_blocks = allocated_blocks[1:]

            data_blocks_needed = (file_size + 511) // 512
            index_blocks_needed = (data_blocks_needed + 255) // 256

            index_blocks = remaining_blocks[:index_blocks_needed]
            data_blocks = remaining_blocks[index_blocks_needed:]

            # Create master index block using ProDOS split-block format
            master_index = bytearray(512)
            for i, index_block in enumerate(index_blocks):
                if i < 256:
                    low_byte = index_block & 0xFF
                    high_byte = (index_block >> 8) & 0xFF
                    master_index[i] = low_byte  # Low byte in first half
                    master_index[i + 256] = high_byte  # High byte in second half

            image.write_block(key_block, bytes(master_index))

            # Create index blocks and write data
            data_block_index = 0
            for _, index_block in enumerate(index_blocks):
                index_data = bytearray(512)

                for j in range(256):  # Each index block can point to 256 data blocks
                    if data_block_index < len(data_blocks):
                        # Use ProDOS split-block format
                        data_block_num = data_blocks[data_block_index]
                        low_byte = data_block_num & 0xFF
                        high_byte = (data_block_num >> 8) & 0xFF
                        index_data[j] = low_byte  # Low byte in first half
                        index_data[j + 256] = high_byte  # High byte in second half

                        # Write data block
                        start_offset = data_block_index * 512
                        end_offset = min(start_offset + 512, len(data))
                        block_data = data[start_offset:end_offset].ljust(512, b"\x00")
                        image.write_block(data_blocks[data_block_index], block_data)

                        data_block_index += 1
                    else:
                        break

                image.write_block(index_block, bytes(index_data))

        # Create directory entry first (before marking blocks allocated)
        _add_directory_entry(
            image,
            filename,
            file_type,
            file_size,
            storage_type,
            key_block,
            len(allocated_blocks),
            aux_type,
            created,
        )

        # Only mark blocks as allocated after directory entry is successfully created
        allocator.allocate_blocks(allocated_blocks)

    except Exception as e:
        # Comprehensive rollback on any failure
        try:
            # Restore original directory state
            image.write_block(2, original_directory_block)
        except Exception as restore_error:
            # If directory restore fails, this is a critical filesystem corruption
            raise FilesystemError(
                f"CRITICAL: Failed to restore directory after error in "
                f"{filename}: {restore_error}. Original error: {e}"
            ) from e

        # Note: We don't need to deallocate blocks since we never marked them
        # as allocated
        # The bitmap remains unchanged if we failed before allocate_blocks()

        raise FilesystemError(f"Failed to create file {filename}: {e}") from e


def delete_prodos_file(image: Any, filename: str) -> None:
    """Delete a file from a ProDOS disk image.

    Args:
        image: UnifiedDiskImage instance
        filename: Name of the file to delete

    Raises:
        FileNotFoundError: If file doesn't exist
    """
    from .directory import _remove_directory_entry

    # Find the file in directory
    directory = ProDOSVolumeDirectory(image)
    files = directory.parse()

    target_file = None
    for file_entry in files:
        if file_entry.filename.upper() == filename.upper():
            target_file = file_entry
            break

    if target_file is None:
        raise FileNotFoundError(filename, str(image.file_path))

    # Collect blocks to deallocate
    blocks_to_free = []

    # Add key block
    blocks_to_free.append(target_file.key_block)

    # Add data blocks based on storage type
    if target_file.storage_type == 1:
        # Seedling: only the key block (already added)
        pass
    elif target_file.storage_type == 2:
        # Sapling: read index block and add data blocks using ProDOS split-block format
        index_data = image.read_block(target_file.key_block)
        for i in range(256):
            # ProDOS split-block format: low byte at offset i, high byte at offset i+256
            low_byte = index_data[i]
            high_byte = index_data[i + 256] if i + 256 < len(index_data) else 0
            data_block = low_byte | (high_byte << 8)
            if data_block != 0:
                blocks_to_free.append(data_block)
    elif target_file.storage_type == 3:
        # Tree: read master index, then index blocks, then data blocks using
        # ProDOS split-block format
        master_index = image.read_block(target_file.key_block)
        for i in range(256):
            # ProDOS split-block format for master index
            low_byte = master_index[i]
            high_byte = master_index[i + 256] if i + 256 < len(master_index) else 0
            index_block = low_byte | (high_byte << 8)

            if index_block != 0:
                blocks_to_free.append(index_block)

                # Read index block and add data blocks using ProDOS split-block format
                index_data = image.read_block(index_block)
                for j in range(256):
                    # ProDOS split-block format for data block pointers
                    low_byte = index_data[j]
                    high_byte = index_data[j + 256] if j + 256 < len(index_data) else 0
                    data_block = low_byte | (high_byte << 8)
                    if data_block != 0:
                        blocks_to_free.append(data_block)

    # Deallocate blocks
    allocator = ProDOSBlockAllocator(image)
    allocator.deallocate_blocks(blocks_to_free)

    # Remove directory entry
    _remove_directory_entry(image, filename)


def truncate_prodos_file(image: Any, filename: str, new_size: int) -> None:
    """Truncate a ProDOS file to a new size.
    Args:
        image: ProDOS disk image
        filename: Name of file to truncate
        new_size: New size in bytes
    """
    # Find the file entry
    from ..filesystem import parse_prodos_directory

    volume = parse_prodos_directory(image)
    files = volume.parse()

    file_entry = None
    for f in files:
        if f.filename.upper() == filename.upper() and not f.is_directory:
            file_entry = f
            break

    if file_entry is None:
        raise FileNotFoundError(filename, str(image.file_path))

    current_size = file_entry.size

    if new_size == current_size:
        return  # No change needed

    if new_size > current_size:
        # Expanding file - read current data, pad with zeros, write back
        current_data = file_entry.read_data()
        new_data = current_data + b"\x00" * (new_size - current_size)

        # Delete and recreate the file with new data
        delete_prodos_file(image, filename)
        # Ensure cache is invalidated before creating new file
        _invalidate_image_cache(image)
        from ...fileentry import convert_file_type

        file_type_int = convert_file_type(file_entry.file_type, "prodos")
        assert isinstance(file_type_int, int)  # Ensure ProDOS returns int
        create_prodos_file(
            image,
            filename,
            file_type_int,
            new_data,
            aux_type=getattr(file_entry, "aux_type", 0),
        )

    else:
        # Shrinking file - read current data, truncate, write back
        current_data = file_entry.read_data()
        new_data = current_data[:new_size]

        # Delete and recreate the file with truncated data
        delete_prodos_file(image, filename)
        # Ensure cache is invalidated before creating new file
        _invalidate_image_cache(image)
        from ...fileentry import convert_file_type

        file_type_int = convert_file_type(file_entry.file_type, "prodos")
        assert isinstance(file_type_int, int)  # Ensure ProDOS returns int
        create_prodos_file(
            image,
            filename,
            file_type_int,
            new_data,
            aux_type=getattr(file_entry, "aux_type", 0),
        )


def move_prodos_file(image: Any, src_filename: str, dest_filename: str) -> None:
    """Move/rename a ProDOS file.
    Args:
        image: ProDOS disk image
        src_filename: Current filename
        dest_filename: New filename
    """
    # For ProDOS, moving/renaming within the same directory is just a name change
    # in the directory entry. For now, implement simple rename functionality.

    # Find the source file entry in the volume directory
    volume_data = bytearray(image.read_block(2))
    entry_size = 39  # ProDOS directory entry size

    # Start after volume header (first entry at offset 4 + 39 = 43)
    for entry_num in range(1, 13):  # Skip header entry (0), check entries 1-12
        offset = 4 + entry_num * entry_size

        if offset + entry_size > len(volume_data):
            break

        # Check storage type and name
        storage_and_length = volume_data[offset]
        storage_type = (storage_and_length >> 4) & 0x0F
        name_length = storage_and_length & 0x0F

        if storage_type != 0 and name_length > 0:
            entry_filename = volume_data[offset + 1 : offset + 1 + name_length].decode(
                "ascii"
            )

            if entry_filename.upper() == src_filename.upper():
                # Found the entry, update the filename
                new_name = dest_filename.upper()
                if len(new_name) > 15:
                    raise ValueError(f"Filename too long: {len(new_name)} > 15")

                # Update storage type and name length byte
                volume_data[offset] = (storage_type << 4) | len(new_name)

                # Clear old name area (15 bytes max)
                for i in range(15):
                    volume_data[offset + 1 + i] = 0x00

                # Write new name
                name_bytes = new_name.encode("ascii")
                volume_data[offset + 1 : offset + 1 + len(name_bytes)] = name_bytes

                # Write updated directory block
                image.write_block(2, bytes(volume_data))

                # Invalidate file list cache after successful move/rename
                _invalidate_image_cache(image)
                return

    # TODO: Handle directory continuation blocks
    raise FileNotFoundError(src_filename, str(image.file_path))
