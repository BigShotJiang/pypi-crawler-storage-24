# sendok 🥄

**sendok** (Scaffolding Engine for Nimble Documentation Organizer Kit) es una herramienta de desarrollo simple y rápida para gestionar la documentación de proyectos y acelerar tu flujo de trabajo en la terminal.

[🇺🇸 English](README.md) | [🇮🇩 Bahasa Indonesia](README_id.md) | [🇯🇵 日本語](README_ja.md) | [🇨🇳 中文](README_zh.md)

---

## ✨ Características Principales

- **🚀 Documentación Instantánea**: Inicializa la carpeta `docs/` con plantillas estándar (SSH, Git, Node, NVM, Angular, GitHub CLI).
- **🌐 Soporte Multi-idioma**: Plantillas en 5 idiomas (EN, ID, ES, JA, ZH).
- **🍴 Git Helper (gg)**: ¡Gestiona Git de forma interactiva! Soporta auto-init, staging (unstage/discard) y reparación automática de errores de *dubious ownership*.
- **🛡️ Administrador de Respaldos (bum)**: Respalda tu proyecto de manera inteligente. Ignora carpetas pesadas (`node_modules`) manteniendo archivos sensibles (`.env`).
- **📡 Escaneo de Red**: Ver quién está en la misma red (detecta marca/vendedor del dispositivo).
- **⚡ Atajos Globales (Shorthands)**: Comandos de una sola letra para tareas comunes (Reload, Limpiar pantalla, Info de IP, etc.).
- **🎨 Interfaz Interactiva**: Menú fácil de usar impulsado por `questionary`.

---

## 🛠️ Instalación

### Desde el Código Fuente (Recomendado para Atajos Globales)
1. Clona este repositorio.
2. Ingresa a la carpeta del proyecto.
3. Ejecuta el siguiente comando:
```bash
pip install -e .
```

---

## 🚀 Guía de Uso

### 1. Menú Interactivo
Ejecuta la herramienta con tu idioma preferido para abrir el menú de navegación:
- **`sendok es`** : Menú en Español.
- **`sendok en`** : Menú en Inglés.
- **`sendok id`** : Menú en Indonesio.
- **`sendok ja`** : Menú en Japonés.
- **`sendok zh`** : Menú en Chino.

### 2. Atajos Globales (Directo en la Terminal)
Después de la instalación, puedes usar estos comandos directamente desde tu terminal:

| Comando | Función |
| :--- | :--- |
| **`r`** | Refrescar terminal y VS Code |
| **`gg`** | Ejecutar Git GUI Helper (Interactivo) |
| **`c`** | Limpiar la pantalla de la terminal (`cls` o `clear`) |
| **`p`** | Mostrar información de IP (`ipconfig` o `ifconfig`) |
| **`bum`** | Ejecutar el Administrador de Respaldos para la carpeta actual |
| **`dc`** | Ejecutar `docker compose` |
| **`l`** | Ejecutar `npm start` |
| **`ll`** | Ejecutar `npm run dev` |
| **`lll`** | Ejecutar `npm run build` |

### 3. Características de Git Helper (`gg`)
Usa el comando **`gg`** para una gestión de Git más sencilla sin memorizar comandos de la terminal:

| Acción del Menú | Equivalente de Comando Git | Descripción |
| :--- | :--- | :--- |
| **Auto-Init** | `git init` | Crea automáticamente un repo si no se encuentra. |
| **Staging** | `git add` | Añadir archivos a la cola de commit. |
| **Unstage** | `git reset` | Quitar archivos de la cola (seguro). |
| **Discard** | `git restore` | Descartar ediciones y resetear archivo (¡cuidado!). |
| **Commit** | `git commit` | Registrar cambios de forma permanente. |
| **Push/Pull** | `git push/pull` | Sincronizar con el servidor (GitLab/GitHub). |
| **Branch** | `git branch` | Gestionar ramas de código. |
| **Remove Git** | `rd /s /q .git` | Restaurar carpeta a la normalidad (borrar Git). |
| **Auto-Fix** | `git config ...` | Corregir automáticamente errores de *dubious ownership*. |

### 4. Subcomandos Estándar
- **`sendok init [id|en|es|ja|zh]`**: Crear la carpeta de documentación.
- **`sendok reload`**: Refrescar terminal y la interfaz de VS Code.
- **`sendok list`**: Ver la lista de plantillas disponibles.
- **`sendok clean`**: Eliminar la carpeta `docs/`.
- **`sendok about`**: Mostrar información del desarrollador de la aplicación.

---

## 🛡️ Administrador de Respaldos (bum)

La función `bum` crea una carpeta de respaldo con marca de tiempo en `.bum/[carpeta_del_proyecto]-[fecha]-[hora]`.
Este proceso ignora automáticamente:
- `node_modules`, `.git`, `venv`, `.venv`
- `dist`, `build`, `__pycache__`
- La carpeta `.bum` en sí misma (para evitar recursividad)

---

## 👤 Autor
- **Hasan Askari** (marhaendev)
- **Website**: [hasanaskari.com](https://hasanaskari.com)
- **Correo electrónico**: marhaendev@gmail.com

 🥄 *¡Simple. Rápido. Documentando como un profesional!*

---

### ❓ Solución: Comando No Encontrado
Si aparece el error `command not found: sendok` o `gg` después de la instalación:
1. **Windows**: Asegúrate de que la carpeta `Scripts` de Python esté en el PATH del sistema (generalmente `C:\Users\<User>\AppData\Roaming\Python\Python3x\Scripts`).
2. **Linux/macOS**: Asegúrate de que `~/.local/bin` esté en tu PATH. Añade esto a tu `.bashrc` o `.zshrc`:
   ```bash
   export PATH="$HOME/.local/bin:$PATH"
   ```
3. **Reiniciar Terminal**: Cierra y vuelve a abrir tu terminal después de realizar los cambios.
