import click
import os
import shutil
from pathlib import Path
import questionary
import socket
import subprocess
import requests
import json

# --- KONFIGURASI I18N ---
TEMPLATES_FILES = ["ssh.md", "git.md", "node.md", "nvm.md", "angular.md", "gh.md"]

LANGUAGES = {
    "id": "Bahasa Indonesia 🇮🇩",
    "en": "English 🇺🇸",
    "es": "Español 🇪🇸",
    "ja": "日本語 🇯🇵",
    "zh": "中文 🇨🇳"
}

# Kamus pesan sistem untuk setiap bahasa
I18N = {
    "id": {
        "menu_prompt": "Apa yang ingin Anda lakukan dengan sendok?",
        "menu_init": "init",
        "menu_list": "list",
        "menu_clean": "clean",
        "menu_help": "help",
        "menu_about": "about",
        "menu_exit": "exit",
        "select_lang_prompt": "Pilih bahasa untuk dokumentasi:",
        "folder_created": "📁 Folder {path} berhasil dibuat.",
        "folder_exists": "ℹ️ Folder {path} sudah ada.",
        "using_lang": "🌐 Menggunakan bahasa: {lang}",
        "file_copied": "✅ Berhasil menyendok: {file}",
        "file_exists_skipping": "⏭️ File {file} sudah ada, melewati.",
        "file_overwritten": "🔄 File {file} diperbarui ke bahasa {lang}.",
        "done_msg": "\n🥄 Selesai! Selamat mendokumentasikan proyek Anda.",
        "list_title": "\n📋 Daftar Template Dokumentasi (sendok):",
        "total": "Total: {count} template tersedia.\n",
        "clean_confirm": "Apakah Anda yakin ingin menghapus folder {path} beserta isinya?",
        "clean_yes": "Yes (Hapus Sekarang)",
        "clean_no": "No (Batalkan)",
        "clean_success": "🗑️ Folder {path} berhasil dihapus.",
        "clean_cancel": "❌ Pembatalan penghapusan.",
        "clean_not_found": "ℹ️ Folder docs tidak ditemukan.",
        "template_not_found": "⚠️ Template {file} tidak ditemukan di '{lang}', membuat file kosong.",
        "about_msg": "\n🥄 sendok (Scaffolding Engine for Nimble Documentation Organizer Kit)\n👤 Pembuat: marhaendev\n🌐 Website: hasanaskari.com\n📧 Email  : marhaendev@gmail.com\n✨ Simpel. Cepat. Menyendok dokumen dengan mahir!",
        "farewell": "Sampai jumpa! 🥄",
        "desc_ssh.md": "Panduan Setup SSH",
        "desc_git.md": "Panduan Lengkap Git",
        "desc_node.md": "Panduan Node.js & NPM",
        "desc_nvm.md": "Panduan NVM untuk Windows",
        "desc_angular.md": "Panduan Angular CLI",
        "desc_gh.md": "Panduan GitHub CLI",
        "help_usage": "Penggunaan: python -m sendok [COMMAND] [BAHASA]",
        "help_desc": "Alat bantu pembuatan dokumentasi proyek otomasi.",
        "help_commands_title": "Perintah yang Tersedia:",
        "help_cmd_init": "Inisialisasi dokumen di folder docs/",
        "help_cmd_list": "Lihat daftar template yang tersedia",
        "help_cmd_clean": "Bersihkan/hapus folder dokumentasi",
        "help_cmd_about": "Informasi pengembang aplikasi",
        "help_cmd_bum": "Backup Manager: Cadangkan proyek ke .bum",
        "help_cmd_dc": "Jalankan 'docker compose' (dc)",
        "help_cmd_id": "Jalankan menu dalam Bahasa Indonesia",
        "help_cmd_en": "Jalankan menu dalam Bahasa Inggris",
        "help_cmd_es": "Jalankan menu dalam Bahasa Spanyol",
        "help_cmd_ja": "Jalankan menu dalam Bahasa Jepang",
        "help_cmd_zh": "Jalankan menu dalam Bahasa Mandarin",
        "help_footer": "\nGunakan 'python -m sendok [COMMAND] --help' untuk bantuan lebih lanjut.",
        "menu_docs": "docs (Kelola Dokumentasi)",
        "menu_create": "create",
        "menu_bum": "bum (Backup Manager)",
        "bum_confirm": "Apakah Anda yakin ingin mencadangkan folder ini ke {path}?",
        "bum_yes": "Yes (Cadangkan Sekarang)",
        "bum_no": "No (Batalkan)",
        "bum_start": "📦 Memulai pencadangan proyek...",
        "bum_success": "✅ Berhasil! Cadangan disimpan di: {path}",
        "bum_cancel": "❌ Pencadangan dibatalkan.",
        "help_cmd_c": "Bersihkan layar terminal (clear/cls)",
        "help_cmd_l": "Jalankan 'npm start'",
        "help_cmd_ll": "Jalankan 'npm run dev'",
        "help_cmd_lll": "Jalankan 'npm run build'",
        "help_cmd_p": "Tampilkan informasi IP (ipconfig/ifconfig)",
        "help_cmd_gg": "Jalankan Git GUI Helper (Interaktif)",
        "help_cmd_reload": "Refresh terminal & VS Code (r)",
        "help_cmd_scan": "Cek siapa saja yang ada di satu jaringan",
        "scan_start": "🔍 Memindai perangkat di satu jaringan...",
        "scan_found": "✅ Ditemukan {count} perangkat aktif.",
        "scan_error_root": "❌ Error: Pemindaian jaringan membutuhkan hak akses Admin/Root.",
        "scan_header_ip": "Alamat IP",
        "scan_header_mac": "Alamat MAC",
        "scan_header_vendor": "Merek/Vendor",
        "scan_header_type": "Tipe/OS",
        "dc_install_os_desc": "📦 Deteksi OS: {os} ({distro}) - Package Manager: {pkg}",
        "dc_install_start": "🚀 Memulai instalasi Docker & Docker Compose...",
        "dc_install_unsupported": "❌ OS atau Distro ini tidak didukung otomatis: {distro}",
        "dc_install_win_warning": "⚠️ Anda berada di Windows. Gunakan Docker Desktop atau jalankan dc install di dalam WSL (Linux).",
        "dc_install_success": "✅ Docker & Docker Compose berhasil diinstal!",
        "dc_install_error": "❌ Terjadi kesalahan saat instalasi: {error}",
        "dc_status_title": "📊 Status Docker & Sistem",
        "dc_status_os": "Sistem Operasi",
        "dc_status_docker": "Versi Docker",
        "dc_status_compose": "Versi Compose",
        "dc_status_not_found": "Tidak ditemukan (Gunakan 'dc install')",
        "dc_status_available": "Tersedia"
    },
    "es": {
        "menu_prompt": "¿Qué te gustaría hacer con sendok?",
        "menu_init": "init",
        "menu_list": "list",
        "menu_clean": "clean",
        "menu_help": "help",
        "menu_about": "about",
        "menu_exit": "exit",
        "select_lang_prompt": "Selecciona el idioma de la documentación:",
        "folder_created": "📁 Carpeta {path} creada con éxito.",
        "folder_exists": "ℹ️ La carpeta {path} ya existe.",
        "using_lang": "🌐 Usando idioma: {lang}",
        "file_copied": "✅ Documento copiado con éxito: {file}",
        "file_exists_skipping": "⏭️ El archivo {file} ya existe, omitiendo.",
        "file_overwritten": "🔄 Archivo {file} actualizado al idioma {lang}.",
        "done_msg": "\n🥄 ¡Hecho! Disfruta documentando tu proyecto.",
        "list_title": "\n📋 Lista de Plantillas de Documentación (sendok):",
        "total": "Total: {count} plantillas disponibles.\n",
        "clean_confirm": "¿Estás seguro de que deseas eliminar la carpeta {path} dan todo su contenido?",
        "clean_yes": "Sí (Eliminar ahora)",
        "clean_no": "No (Cancelar)",
        "clean_success": "🗑️ Carpeta {path} eliminada con éxito.",
        "clean_cancel": "❌ Eliminación cancelada.",
        "clean_not_found": "ℹ️ No se encontró la carpeta docs.",
        "template_not_found": "⚠️ Plantilla {file} no encontrada en '{lang}', creando archivo vacío.",
        "about_msg": "\n🥄 sendok (Scaffolding Engine for Nimble Documentation Organizer Kit)\n👤 Autor: marhaendev\n🌐 Website: hasanaskari.com\n📧 Email : marhaendev@gmail.com\n✨ ¡Simple. Rápido. Documentando como un profesional!",
        "farewell": "¡Hasta luego! 🥄",
        "desc_ssh.md": "Guía de configuración de SSH",
        "desc_git.md": "Guía completa de Git",
        "desc_node.md": "Guía de Node.js y NPM",
        "desc_nvm.md": "Guía de NVM para Windows",
        "desc_angular.md": "Guía de Angular CLI",
        "desc_gh.md": "Guía de GitHub CLI",
        "help_usage": "Uso: python -m sendok [COMMAND] [IDIOMA]",
        "help_desc": "Herramienta de automatización para la creación de documentación de proyectos.",
        "help_commands_title": "Comandos Disponibles:",
        "help_cmd_init": "Inicializar documentos en la carpeta docs/",
        "help_cmd_list": "Ver lista de plantillas disponibles",
        "help_cmd_clean": "Limpiar/eliminar carpeta de documentación",
        "help_cmd_about": "Informasi pengembang aplikasi",
        "help_cmd_bum": "Backup Manager: Respaldar proyecto en .bum",
        "help_cmd_dc": "Ejecutar 'docker compose' (dc)",
        "help_cmd_id": "Ejecutar menú en indonesio",
        "help_cmd_en": "Ejecutar menú en inglés",
        "help_cmd_es": "Ejecutar menú en español",
        "help_cmd_ja": "Ejecutar menú en japonés",
        "help_cmd_zh": "Ejecutar menú en chino",
        "help_footer": "\nUsa 'python -m sendok [COMMAND] --help' para más información.",
        "menu_docs": "docs (Gestionar Documentación)",
        "menu_create": "create",
        "menu_bum": "bum (Backup Manager)",
        "bum_confirm": "¿Estás seguro de que deseas respaldar esta carpeta en {path}?",
        "bum_yes": "Sí (Respaldar ahora)",
        "bum_no": "No (Cancelar)",
        "bum_start": "📦 Iniciando respaldo del proyecto...",
        "bum_success": "✅ ¡Éxito! Respaldo guardado en: {path}",
        "bum_cancel": "❌ Respaldo cancelado.",
        "help_cmd_c": "Limpiar pantalla de la terminal",
        "help_cmd_l": "Ejecutar 'npm start'",
        "help_cmd_ll": "Ejecutar 'npm run dev'",
        "help_cmd_lll": "Ejecutar 'npm run build'",
        "help_cmd_p": "Mostrar información de IP (ipconfig/ifconfig)",
        "help_cmd_gg": "Ejecutar Git GUI Helper (Interactivo)",
        "help_cmd_reload": "Refrescar terminal y VS Code (r)",
        "help_cmd_scan": "Ver quién está en la misma red",
        "scan_start": "🔍 Escaneando dispositivos en una sola red...",
        "scan_found": "✅ Se encontraron {count} dispositivos activos.",
        "scan_error_root": "❌ Error: El escaneo de red requiere privilegios de Admin/Root.",
        "scan_header_ip": "Dirección IP",
        "scan_header_mac": "Dirección MAC",
        "scan_header_vendor": "Marca/Vendedor",
        "scan_header_type": "Tipo/SO",
        "dc_install_os_desc": "📦 Detección de SO: {os} ({distro}) - Gestor de Paquetes: {pkg}",
        "dc_install_start": "🚀 Iniciando instalación de Docker & Docker Compose...",
        "dc_install_unsupported": "❌ OS o Distro no soportada automáticamente: {distro}",
        "dc_install_win_warning": "⚠️ Estás en Windows. Usa Docker Desktop atau ejecuta 'dc install' dentro de WSL (Linux).",
        "dc_install_success": "✅ ¡Docker & Docker Compose instalados correctamente!",
        "dc_install_error": "❌ Error durante la instalación: {error}",
        "dc_status_title": "📊 Estado de Docker y Sistema",
        "dc_status_os": "Sistema Operativo",
        "dc_status_docker": "Versión de Docker",
        "dc_status_compose": "Versión de Compose",
        "dc_status_not_found": "No encontrado (Usa 'dc install')",
        "dc_status_available": "Disponible"
    },
    "ja": {
        "menu_prompt": "sendokで何をしますか？",
        "menu_init": "init",
        "menu_list": "list",
        "menu_clean": "clean",
        "menu_help": "help",
        "menu_about": "about",
        "menu_exit": "exit",
        "select_lang_prompt": "ドキュメントの言語を選択してください：",
        "folder_created": "📁 フォルダ {path} が正常に作成されました。",
        "folder_exists": "ℹ️ フォルダ {path} は既に存在します。",
        "using_lang": "🌐 使用言語: {lang}",
        "file_copied": "✅ ドキュメントのコピーに成功しました: {file}",
        "file_exists_skipping": "⏭️ ファイル {file} は既に存在するため、スキップします。",
        "file_overwritten": "🔄 ファイル {file} を {lang} 言語に更新しました。",
        "done_msg": "\n🥄 完了！プロジェクトのドキュメント作成をお楽しみください。",
        "list_title": "\n📋 利用可能なドキュメントテンプレート（sendok）:",
        "total": "合計: {count} 個のテンプレートが利用可能です。\n",
        "clean_confirm": "フォルダ {path} とその全内容を削除してもよろしいですか？",
        "clean_yes": "はい（今すぐ削除）",
        "clean_no": "いいえ（キャンセル）",
        "clean_success": "🗑️ フォルダ {path} が正常に削除されました。",
        "clean_cancel": "❌ 削除がキャンセルされました。",
        "clean_not_found": "ℹ️ docsフォルダが見つかりません。",
        "template_not_found": "⚠️ '{lang}' にテンプレート {file} が見つかりません。空の文件を作成します。",
        "about_msg": "\n🥄 sendok (Scaffolding Engine for Nimble Documentation Organizer Kit)\n👤 作成者: marhaendev\n🌐 Website: hasanaskari.com\n📧 メール: marhaendev@gmail.com\n✨ シンプル。スピーディ。プロのようにドキュメントを作成！",
        "farewell": "またお会いしましょう！ 🥄",
        "desc_ssh.md": "SSHセットアップガイド",
        "desc_git.md": "Git完全ガイド",
        "desc_node.md": "Node.js & NPMガイド",
        "desc_nvm.md": "Windows用NVMガイド",
        "desc_angular.md": "Angular CLIガイド",
        "desc_gh.md": "GitHub CLIガイド",
        "help_usage": "使用法: python -m sendok [COMMAND] [言語]",
        "help_desc": "プロジェクトドキュメント作成自動化ツール。",
        "help_commands_title": "利用可能なコマンド:",
        "help_cmd_init": "docs/ フォルダにドキュメントを初期化する",
        "help_cmd_list": "利用可能なテンプレート一覧を表示",
        "help_cmd_clean": "ドキュメントフォルダをクリーンアップ/削除",
        "help_cmd_about": "Informasi pengembang aplikasi",
        "help_cmd_bum": "Backup Manager: プロジェクトを .bum にバックアップ",
        "help_cmd_dc": "'docker compose' を実行する (dc)",
        "help_cmd_id": "インドネシア語でメニューを実行",
        "help_cmd_en": "英語でメニューを実行",
        "help_cmd_es": "スペイン語でメニューを実行",
        "help_cmd_ja": "日本語でメニューを実行",
        "help_cmd_zh": "中国語でメニューを実行",
        "help_footer": "\n詳細は 'python -m sendok [COMMAND] --help' を使用してください。",
        "menu_docs": "docs (ドキュメント管理)",
        "menu_create": "create",
        "menu_bum": "bum (バックアップマネージャー)",
        "bum_confirm": "このフォルダを {path} にバックアップしてもよろしいですか？",
        "bum_yes": "はい（今すぐバックアップ）",
        "bum_no": "いいえ（キャンセル）",
        "bum_start": "📦 プロジェクトのバックアップを開始しています...",
        "bum_success": "✅ 成功！バックアップが保存されました: {path}",
        "bum_cancel": "❌ バックアップがキャンセルされました。",
        "help_cmd_c": "ターミナル画面をクリアする",
        "help_cmd_l": "'npm start' を実行する",
        "help_cmd_ll": "'npm run dev' を実行する",
        "help_cmd_lll": "'npm run build' を実行する",
        "help_cmd_p": "IP情報を表示する (ipconfig/ifconfig)",
        "help_cmd_gg": "Git GUI ヘルパーを実行する (対話型)",
        "help_cmd_reload": "ターミナルと VS Code を更新 (r)",
        "help_cmd_scan": "同じネットワーク内のユーザーを確認する",
        "scan_start": "🔍 ネットワーク上のデバイスをスキャン中...",
        "scan_found": "✅ {count} 台のアクティブなデバイスが見つかりました。",
        "scan_error_root": "❌ エラー：ネットワークスキャンには管理者権限（Root）が必要です。",
        "scan_header_ip": "IPアドレス",
        "scan_header_mac": "MACアドレス",
        "scan_header_vendor": "メーカー/ベンダー",
        "scan_header_type": "タイプ/OS",
        "dc_install_os_desc": "📦 OS検出: {os} ({distro}) - パッケージマネージャー: {pkg}",
        "dc_install_start": "🚀 Docker & Docker Compose のインストールを開始します...",
        "dc_install_unsupported": "❌ このOSまたはディストリビューションは自動サポートされていません: {distro}",
        "dc_install_win_warning": "⚠️ Windows環境です。Docker Desktopを使用するか、WSL（Linux）内で 'dc install' を実行してください。",
        "dc_install_success": "✅ Docker & Docker Compose のインストールが成功しました！",
        "dc_install_error": "❌ インストール中にエラーが発生しました: {error}",
        "dc_status_title": "📊 Docker とシステムのステータス",
        "dc_status_os": "オペレーティングシステム",
        "dc_status_docker": "Docker バージョン",
        "dc_status_compose": "Compose バージョン",
        "dc_status_not_found": "見つかりません ('dc install' を使用してください)",
        "dc_status_available": "利用可能"
    },
    "zh": {
        "menu_prompt": "你想用 sendok 做什么？",
        "menu_init": "init",
        "menu_list": "list",
        "menu_clean": "clean",
        "menu_help": "help",
        "menu_about": "about",
        "menu_exit": "exit",
        "select_lang_prompt": "选择文档语言：",
        "folder_created": "📁 文件夹 {path} 创建成功。",
        "folder_exists": "ℹ️ 文件夹 {path} 已存在。",
        "using_lang": "🌐 使用语言: {lang}",
        "file_copied": "✅ 成功复制文档: {file}",
        "file_exists_skipping": "⏭️ 文件 {file} 已存在，跳过。",
        "file_overwritten": "🔄 文件 {file} 已更新为 {lang} 语言。",
        "done_msg": "\n🥄 完成！祝你文档编写愉快。",
        "list_title": "\n📋 可用文档模板 (sendok):",
        "total": "总计: {count} 个可用模板。\n",
        "clean_confirm": "你确定要删除文件夹 {path} 及其所有内容吗？",
        "clean_yes": "是（立即删除）",
        "clean_no": "否（取消）",
        "clean_success": "🗑️ 文件夹 {path} 已成功删除。",
        "clean_cancel": "❌ 删除已取消。",
        "clean_not_found": "ℹ️ 未找到 docs 文件夹。",
        "template_not_found": "⚠️ 在 '{lang}' 中未找到模板 {file}，正创建一个空文件。",
        "about_msg": "\n🥄 sendok (Scaffolding Engine for Nimble Documentation Organizer Kit)\n👤 作者: marhaendev\n🌐 网站: hasanaskari.com\n邮箱: marhaendev@gmail.com\n✨ 简单。快速。像专业人士一样编写文档！",
        "farewell": "再见！ 🥄",
        "desc_ssh.md": "SSH 设置指南",
        "desc_git.md": "Git 完整指南",
        "desc_node.md": "Node.js & NPM 指南",
        "desc_nvm.md": "Windows 版 NVM 指南",
        "desc_angular.md": "Angular CLI 指南",
        "desc_gh.md": "GitHub CLI 指南",
        "help_usage": "用法: python -m sendok [COMMAND] [语言]",
        "help_desc": "项目文档支架自动化工具。",
        "help_commands_title": "可用命令:",
        "help_cmd_init": "在 docs/ 文件夹中初始化文档",
        "help_cmd_list": "查看可用模板列表",
        "help_cmd_clean": "清理/删除文档文件夹",
        "help_cmd_about": "查看应用开发人员信息",
        "help_cmd_bum": "Backup Manager: 将项目备份到 .bum",
        "help_cmd_id": "运行印尼语菜单",
        "help_cmd_en": "运行英语菜单",
        "help_cmd_es": "运行西班牙语菜单",
        "help_cmd_ja": "运行日语菜单",
        "help_cmd_zh": "运行中文菜单",
        "help_footer": "\n使用 'python -m sendok [COMMAND] --help' 获取更多信息。",
        "menu_docs": "docs (管理文档)",
        "menu_create": "create",
        "menu_bum": "bum (备份管理器)",
        "bum_confirm": "你确定要将此文件夹备份到 {path} 吗？",
        "bum_yes": "是（立即备份）",
        "bum_no": "否（取消）",
        "bum_start": "📦 正在开始项目备份...",
        "bum_success": "✅ 成功！备份已存储在: {path}",
        "bum_cancel": "❌ 备份已取消。",
        "help_cmd_c": "清屏",
        "help_cmd_l": "运行 'npm start'",
        "help_cmd_ll": "运行 'npm run dev'",
        "help_cmd_lll": "运行 'npm run build'",
        "help_cmd_p": "显示 IP 信息 (ipconfig/ifconfig)",
        "help_cmd_gg": "运行 Git GUI 助手 (交互式)",
        "help_cmd_reload": "刷新终端和 VS Code (r)",
        "help_cmd_scan": "查看同一网络中的在线用户",
        "scan_start": "🔍 正在扫描网络中的设备...",
        "scan_found": "✅ 发现 {count} 个活动设备。",
        "scan_error_root": "❌ 错误：网络扫描需要管理员/Root 权限。",
        "scan_header_ip": "IP 地址",
        "scan_header_mac": "MAC 地址",
        "scan_header_vendor": "品牌/厂商",
        "scan_header_type": "类型/系统",
        "dc_install_os_desc": "📦 系统检测: {os} ({distro}) - 包管理器: {pkg}",
        "dc_install_start": "🚀 开始安装 Docker 和 Docker Compose...",
        "dc_install_unsupported": "❌ 自动安装不支持此系统或发行版: {distro}",
        "dc_install_win_warning": "⚠️ 您正在使用 Windows。请使用 Docker Desktop 或在 WSL (Linux) 中运行 'dc install'。",
        "dc_install_success": "✅ Docker & Docker Compose 安装成功！",
        "dc_install_error": "❌ 安装过程中出错: {error}",
        "dc_status_title": "📊 Docker 与系统状态",
        "dc_status_os": "操作系统",
        "dc_status_docker": "Docker 版本",
        "dc_status_compose": "Compose 版本",
        "dc_status_not_found": "未找到 (使用 'dc install')",
        "dc_status_available": "可用"
    },
    "en": {
        "menu_prompt": "What would you like to do with sendok?",
        "menu_init": "init",
        "menu_list": "list",
        "menu_clean": "clean",
        "menu_help": "help",
        "menu_about": "about",
        "menu_exit": "exit",
        "select_lang_prompt": "Select documentation language:",
        "folder_created": "📁 Folder {path} successfully created.",
        "folder_exists": "ℹ️ Folder {path} already exists.",
        "using_lang": "🌐 Using language: {lang}",
        "file_copied": "✅ Successfully spooned: {file}",
        "file_exists_skipping": "⏭️ File {file} already exists, skipping.",
        "file_overwritten": "🔄 File {file} updated to {lang}.",
        "done_msg": "\n🥄 Done! Happy documenting your project.",
        "list_title": "\n📋 Available Documentation Templates (sendok):",
        "total": "Total: {count} templates available.\n",
        "clean_confirm": "Are you sure you want to delete {path} and all its contents?",
        "clean_yes": "Yes (Delete Now)",
        "clean_no": "No (Cancel)",
        "clean_success": "🗑️ Folder {path} successfully deleted.",
        "clean_cancel": "❌ Deletion cancelled.",
        "clean_not_found": "ℹ️ Folder docs not found.",
        "template_not_found": "⚠️ Template {file} not found in '{lang}', creating empty file.",
        "about_msg": "\n🥄 sendok (Scaffolding Engine for Nimble Documentation Organizer Kit)\n👤 Author: marhaendev\n🌐 Website: hasanaskari.com\n📧 Email : marhaendev@gmail.com\n✨ Simple. Fast. Spooning documents like a pro!",
        "farewell": "See you later! 🥄",
        "desc_ssh.md": "SSH Setup Guide",
        "desc_git.md": "Git Complete Guide",
        "desc_node.md": "Node.js & NPM Guide",
        "desc_nvm.md": "NVM for Windows Guide",
        "desc_angular.md": "Angular CLI Guide",
        "desc_gh.md": "GitHub CLI Guide",
        "help_usage": "Usage: python -m sendok [COMMAND] [LANGUAGE]",
        "help_desc": "Project documentation scaffolding automation tool.",
        "help_commands_title": "Available Commands:",
        "help_cmd_init": "Initialize documents in docs/ folder",
        "help_cmd_list": "List available documentation templates",
        "help_cmd_clean": "Clean/delete documentation folder",
        "help_cmd_about": "Application developer information",
        "help_cmd_bum": "Backup Manager: Backup project to .bum",
        "help_cmd_dc": "Run 'docker compose' (dc)",
        "help_cmd_id": "Run interactive menu in Indonesian",
        "help_cmd_en": "Run interactive menu in English",
        "help_cmd_es": "Run interactive menu in Spanish",
        "help_cmd_ja": "Run interactive menu in Japanese",
        "help_cmd_zh": "Run interactive menu in Chinese",
        "help_footer": "\nUse 'python -m sendok [COMMAND] --help' for more info.",
        "menu_docs": "docs (Manage Documentation)",
        "menu_create": "create",
        "menu_bum": "bum (Backup Manager)",
        "bum_confirm": "Are you sure you want to backup this folder to {path}?",
        "bum_yes": "Yes (Backup Now)",
        "bum_no": "No (Cancel)",
        "bum_start": "📦 Starting project backup...",
        "bum_success": "✅ Success! Backup stored at: {path}",
        "bum_cancel": "❌ Backup cancelled.",
        "help_cmd_c": "Clear terminal screen",
        "help_cmd_l": "Run 'npm start'",
        "help_cmd_ll": "Run 'npm run dev'",
        "help_cmd_lll": "Run 'npm run build'",
        "help_cmd_p": "Show IP information (ipconfig/ifconfig)",
        "help_cmd_gg": "Run Git GUI Helper (Interactive)",
        "help_cmd_reload": "Refresh terminal & VS Code (r)",
        "help_cmd_scan": "Check who is in the same network",
        "scan_start": "🔍 Scanning devices in one network...",
        "scan_found": "✅ Found {count} active devices.",
        "scan_error_root": "❌ Error: Network scanning requires Admin/Root privileges.",
        "scan_header_ip": "IP Address",
        "scan_header_mac": "MAC Address",
        "scan_header_vendor": "Brand/Vendor",
        "scan_header_type": "Type/OS",
        "dc_install_os_desc": "📦 OS Detection: {os} ({distro}) - Package Manager: {pkg}",
        "dc_install_start": "🚀 Starting Docker & Docker Compose installation...",
        "dc_install_unsupported": "❌ This OS or Distro is not automatically supported: {distro}",
        "dc_install_win_warning": "⚠️ You are on Windows. Use Docker Desktop or run 'dc install' inside WSL (Linux).",
        "dc_install_success": "✅ Docker & Docker Compose successfully installed!",
        "dc_install_error": "❌ Error during installation: {error}",
        "dc_status_title": "📊 Docker & System Status",
        "dc_status_os": "Operating System",
        "dc_status_docker": "Docker Version",
        "dc_status_compose": "Compose Version",
        "dc_status_not_found": "Not Found (Use 'dc install')",
        "dc_status_available": "Available"
    }
}

def _t(key, ui_lang='en', **kwargs):
    """Fungsi pembantu untuk mengambil pesan i18n. Default ke 'en'."""
    lang_dict = I18N.get(ui_lang, I18N['en'])
    # Pastikan fallback ke 'en' jika key tidak ada di 'id'
    text = lang_dict.get(key, I18N['en'].get(key, f"Missing key: {key}"))
    return text.format(**kwargs)

def show_custom_help(lang='en'):
    """Menampilkan bantuan Click yang sudah diterjemahkan."""
    click.echo(f"\n{_t('help_usage', lang)}")
    click.echo(f"\n{_t('help_desc', lang)}")
    click.echo(f"\n{_t('help_commands_title', lang)}")
    click.echo(f"  {'r':16} : {_t('help_cmd_reload', lang)}")
    click.echo(f"  {'gg':16} : {_t('help_cmd_gg', lang)}")
    click.echo(f"  {'p':16} : {_t('help_cmd_p', lang)}")
    click.echo(f"  {'c':16} : {_t('help_cmd_c', lang)}")
    click.echo(f"  {'l':16} : {_t('help_cmd_l', lang)}")
    click.echo(f"  {'ll':16} : {_t('help_cmd_ll', lang)}")
    click.echo(f"  {'lll':16} : {_t('help_cmd_lll', lang)}")
    click.echo(f"  {'bum':16} : {_t('help_cmd_bum', lang)}")
    click.echo(f"  {'dc':16} : {_t('help_cmd_dc', lang)}")
    click.echo(f"  {'sendok scan':16} : {_t('help_cmd_scan', lang)}")
    click.echo(f"  {'sendok id':16} : {_t('help_cmd_id', lang)}")
    click.echo(f"  {'sendok en':16} : {_t('help_cmd_en', lang)}")
    click.echo(f"  {'sendok es':16} : {_t('help_cmd_es', lang)}")
    click.echo(f"  {'sendok ja':16} : {_t('help_cmd_ja', lang)}")
    click.echo(f"  {'sendok zh':16} : {_t('help_cmd_zh', lang)}")
    click.echo(f"  {'sendok init':16} : {_t('help_cmd_init', lang)}")
    click.echo(f"  {'sendok list':16} : {_t('help_cmd_list', lang)}")
    click.echo(f"  {'sendok clean':16} : {_t('help_cmd_clean', lang)}")
    click.echo(_t('help_footer', lang))
    click.echo(_t('about_msg', lang))

# --- CLI IMPLEMENTATION ---

@click.group(invoke_without_command=True)
@click.pass_context
def cli(ctx):
    """sendok (Scaffolding Engine for Nimble Documentation Organizer Kit) CLI Tool."""
    # Deteksi bahasa dari subcommand jika ada, default adalah 'en'
    lang = 'en'
    if ctx.invoked_subcommand in LANGUAGES:
        lang = ctx.invoked_subcommand

    if ctx.invoked_subcommand is None:
        _run_interactive_menu(ctx, lang)

@cli.command(name='gg')
def git_gui_command():
    """Git GUI Helper: Manage your git repository interactively."""
    from . import git_gui
    git_gui.main_menu()

def git_gui_shorthand():
    """Shorthand 'gg' to run Git GUI directly."""
    from sendok import git_gui
    git_gui.main_menu()

@cli.command(name='reload')
def reload_command():
    """Refresh terminal and VS Code UI."""
    clear_screen()
    # Try to trigger VS Code refresh by running 'code .'
    try:
        subprocess.run("code .", shell=True, check=False)
        click.secho("🥄 Spoon Reload: Success! Terminal cleaned and VS Code refreshed.", fg="green")
    except Exception:
        click.secho("🥄 Spoon Reload: Terminal cleaned.", fg="green")

def reload_shorthand():
    """Shorthand 'r' to reload."""
    reload_command.callback()

@cli.command(name="list")
@click.option('--lang', default='en', help='Language for terminal output')
def list_templates(lang):
    """View available documentation templates."""
    click.echo(_t("list_title", lang))
    click.echo("-" * 45)
    for filename in TEMPLATES_FILES:
        description = _t(f"desc_{filename}", lang)
        click.echo(f"🔹 {filename:12} : {description}")
    click.echo("-" * 45)
    click.echo(_t("total", lang, count=len(TEMPLATES_FILES)))

@cli.command()
@click.argument('lang', default='en', type=click.Choice(['id', 'en', 'es', 'ja', 'zh']))
@click.option('--force', is_flag=True, help='Overwrite existing files')
def init(lang, force):
    """Create docs/ folder and spoon documentation templates."""
    docs_dir = Path("docs")
    
    if not docs_dir.exists():
        docs_dir.mkdir()
        click.echo(_t("folder_created", lang, path=docs_dir))
    else:
        click.echo(_t("folder_exists", lang, path=docs_dir))

    # Robust template path detection
    base_dir = Path(__file__).resolve().parent
    template_src_dir = base_dir / "templates" / lang

    if not template_src_dir.exists():
        # Fallback check for different installation structures
        alt_path = base_dir / "sendok" / "templates" / lang
        if alt_path.exists():
            template_src_dir = alt_path
        else:
            click.echo(f"❌ Error: {lang} templates not found at {template_src_dir}")
            click.echo("Please try reinstalling the package: pip install --force-reinstall sendok")
            return

    click.echo(_t("using_lang", lang, lang=LANGUAGES.get(lang)))

    for filename in TEMPLATES_FILES:
        target_file = docs_dir / filename
        source_file = template_src_dir / filename
        
        if not target_file.exists() or force or True: # Always update/sync content
            if source_file.exists():
                shutil.copy(source_file, target_file)
                if not target_file.exists():
                    click.echo(_t("file_copied", lang, file=filename))
                else:
                    click.echo(_t("file_overwritten", lang, file=filename, lang=lang))
            else:
                with open(target_file, "w", encoding="utf-8") as f:
                    description = _t(f"desc_{filename}", lang)
                    f.write(f"# {description}\n")
                click.echo(_t("template_not_found", lang, file=filename, lang=lang))

    click.echo(_t("done_msg", lang))

@cli.command()
@click.option('--lang', default='en', help='Language for terminal output')
def about(lang):
    """Show information about the author."""
    click.echo(_t("about_msg", lang))

@cli.command()
@click.option('--lang', default='en', help='Language for terminal output')
def bum(lang):
    """Backup Manager: Backup current folder to .bum."""
    from datetime import datetime
    import os
    
    # Ambil nama folder saat ini
    current_folder_name = Path(os.getcwd()).name
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    
    bum_dir = Path(".bum")
    # Format baru: namafolder-YYYYMMDD-HHMMSS
    backup_path = bum_dir / f"{current_folder_name}-{timestamp}"
    
    confirmation = questionary.select(
        _t("bum_confirm", lang, path=bum_dir),
        choices=[
            _t("bum_no", lang),
            _t("bum_yes", lang)
        ],
        default=_t("bum_no", lang)
    ).ask()

    if confirmation == _t("bum_yes", lang):
        if not bum_dir.exists():
            bum_dir.mkdir()
        
        click.echo(_t("bum_start", lang))
        
        # Logika Ignore
        ignore_list = [
            "node_modules", ".git", "venv", ".venv", 
            "dist", "build", "__pycache__", ".bum",
            ".pytest_cache", ".mypy_cache"
        ]
        
        def ignore_func(directory, contents):
            return [c for c in contents if c in ignore_list]

        shutil.copytree(".", backup_path, ignore=ignore_func, dirs_exist_ok=True)
        click.echo(_t("bum_success", lang, path=backup_path))
    else:
        click.echo(_t("bum_cancel", lang))

@cli.command(name='scan')
@click.option('--lang', default='en', help='Language for terminal output')
def scan(lang):
    """Scan active devices in the same network."""
    from rich.table import Table
    from rich.console import Console

    # Check for root/admin privileges (scapy needs it)
    is_admin = False
    try:
        if os.name == 'nt':
            import ctypes
            is_admin = ctypes.windll.shell32.IsUserAnAdmin() != 0
        else:
            is_admin = os.getuid() == 0
    except AttributeError:
        pass

    if not is_admin:
        click.secho(_t("scan_error_root", lang), fg="red")
        return

    try:
        import scapy.all as scapy
    except ImportError:
        click.echo("❌ Scapy not found. Please install it with 'pip install scapy'")
        return

    click.echo(_t("scan_start", lang))
    
    # Auto-detect local subnet
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
        subnet = ".".join(local_ip.split(".")[:-1]) + ".0/24"
    except Exception:
        subnet = "192.168.1.0/24"

    # Helper for Hostname
    def get_hostname(ip):
        try:
            return socket.gethostbyaddr(ip)[0]
        except Exception:
            return "Unknown"

    # Helper for OS Discovery (TTL)
    def get_os_by_ttl(ip):
        try:
            # Send a simple ICMP packet to check TTL
            ans, unans = scapy.sr(scapy.IP(dst=ip)/scapy.ICMP(), timeout=1, verbose=False)
            if ans:
                ttl = ans[0][1].ttl
                if ttl <= 64: return "Linux/Android/iOS"
                if ttl <= 128: return "Windows"
            return "Unknown"
        except Exception:
            return "Unknown"

    # Helper for Vendor Lookup
    def get_vendor(mac):
        common_vendors = {
            "00:00:5E": "ICANN", "00:05:02": "Apple", "00:03:93": "Apple", "D8:0D:17": "Apple", 
            "00:1B:63": "Apple", "A4:2B:B0": "Samsung", "00:15:99": "Samsung", "00:00:0C": "Cisco", 
            "00:01:42": "Cisco", "00:1A:A9": "Intel", "00:1C:BF": "Intel", "B4:2E:99": "Xiaomi",
            "00:0C:29": "VMware", "08:00:27": "VirtualBox", "DC:A6:32": "Raspberry Pi",
            "B8:27:EB": "Raspberry Pi", "E4:5F:01": "Raspberry Pi", "00:E0:4C": "Realtek",
            "84:D8:1B": "TP-Link", "94:10:3E": "Oppo", "70:8A:09": "Vivo", "0C:D0:F8": "Huawei",
            "10:68:38": "AzureWave (ASUS/MSI)", "00:25:22": "ASRock", "BC:5F:F4": "ASRock",
            "00:21:70": "Dell", "00:26:B9": "Dell", "00:1E:0B": "HP", "00:25:B3": "HP",
            "AC:D1:B8": "Lite-On (Laptop)", "00:26:5E": "Hon Hai (Foxconn)", "28:D2:44": "Hon Hai"
        }
        prefix = mac.upper()[:8]
        if prefix in common_vendors:
            return common_vendors[prefix]
        
        try:
            url = f"https://api.macvendors.com/{mac}"
            response = requests.get(url, timeout=2)
            if response.status_code == 200:
                return response.text
        except Exception:
            pass
        return "Unknown"

    def guess_device_type(vendor, mac, hostname, os_ttl):
        first_byte = int(mac.split(":")[0], 16)
        is_randomized = (first_byte & 2) != 0
        
        v = vendor.lower()
        h = hostname.lower()
        
        # 1. Logic by Hostname (Strongest hint)
        if "iphone" in h or "ipad" in h: return "Apple (iOS Device)"
        if "android" in h or "galaxy" in h: return "Android Mobile"
        if "desktop" in h or "laptop" in h: return "Windows PC"
        
        # 2. Logic by TTL (Kernel check)
        if os_ttl == "Windows": return "Windows PC"
        if os_ttl == "Linux/Android/iOS":
            if "apple" in v: return "Apple (iPhone/Mac)"
            if is_randomized or any(x in v for x in ["samsung", "xiaomi", "oppo", "vivo", "huawei"]):
                return "Android/Mobile"
            return "Linux/Unix System"
            
        # 3. Logic by Vendor
        if "apple" in v: return "Apple Device"
        if any(x in v for x in ["samsung", "xiaomi", "oppo", "vivo", "huawei"]):
            return "Android Mobile"
        if any(x in v for x in ["intel", "realtek", "dell", "hp", "lenovo", "azurewave", "asrock", "hon hai", "lite-on"]):
            return "PC / Laptop"
        if "microsoft" in v: return "Windows PC"
        if "raspberry" in v: return "Linux (IoT)"
        if any(x in v for x in ["cisco", "tp-link", "d-link", "asus"]): return "Network Device"
        if "vmware" in v or "virtualbox" in v: return "Virtual Machine"
        if is_randomized: return "Mobile / Randomized MAC"
            
        return "Generic Device"

    # Perform ARP scan
    try:
        arp_request = scapy.ARP(pdst=subnet)
        broadcast = scapy.Ether(dst="ff:ff:ff:ff:ff:ff")
        arp_request_broadcast = broadcast/arp_request
        answered_list = scapy.srp(arp_request_broadcast, timeout=3, verbose=False)[0]

        devices = []
        for element in answered_list:
            ip = element[1].psrc
            mac = element[1].hwsrc
            vendor = get_vendor(mac)
            hostname = get_hostname(ip)
            os_ttl = get_os_by_ttl(ip)
            
            devices.append({
                "ip": ip, 
                "mac": mac,
                "vendor": vendor,
                "hostname": hostname,
                "type": guess_device_type(vendor, mac, hostname, os_ttl)
            })

        console = Console()
        table = Table(title=_t("scan_found", lang, count=len(devices)))
        table.add_column(_t("scan_header_ip", lang), style="cyan")
        table.add_column(_t("scan_header_mac", lang), style="magenta")
        table.add_column(_t("scan_header_vendor", lang), style="green")
        table.add_column(_t("scan_header_type", lang), style="yellow")

        for d in devices:
            # Combine Hostname into Type if known for cleaner look
            final_type = d["type"]
            if d["hostname"] != "Unknown":
                final_type = f"{d['type']} ({d['hostname']})"
                
            table.add_row(d["ip"], d["mac"], d["vendor"], final_type)

        console.print(table)
    except Exception as e:
        click.echo(f"❌ Error during scan: {str(e)}")

@cli.command(name='p')
def ip_info():
    """Show IP information."""
    os.system('ipconfig' if os.name == 'nt' else 'ifconfig')

@cli.command(name='c')
def clear_screen():
    """Clear terminal screen."""
    os.system('cls' if os.name == 'nt' else 'clear')

@cli.command(name='l')
def npm_start():
    """Run 'npm start'."""
    os.system('npm start')

@cli.command(name='ll')
def npm_dev():
    """Run 'npm run dev'."""
    os.system('npm run dev')

@cli.command(name='lll')
def npm_build():
    """Run 'npm run build'."""
    os.system('npm run build')

# Alias subcommands
@cli.command(name='id', help='Bahasa Indonesia UI')
@click.pass_context
def lang_id(ctx):
    _run_interactive_menu(ctx, 'id')

@cli.command(name='en', help='English UI')
@click.pass_context
def lang_en(ctx):
    _run_interactive_menu(ctx, 'en')

@cli.command(name='es', help='Español UI')
@click.pass_context
def lang_es(ctx):
    _run_interactive_menu(ctx, 'es')

@cli.command(name='ja', help='日本語 UI')
@click.pass_context
def lang_ja(ctx):
    _run_interactive_menu(ctx, 'ja')

@cli.command(name='zh', help='中文 UI')
@click.pass_context
def lang_zh(ctx):
    _run_interactive_menu(ctx, 'zh')

def _run_interactive_menu(ctx, lang):
    """Run interactive menu in specific language."""
    choice = questionary.select(
        _t("menu_prompt", lang),
        choices=[
            _t("menu_exit", lang),
            _t("menu_help", lang),
            _t("menu_docs", lang),
            _t("menu_bum", lang)
        ]
    ).ask()

    if choice == _t("menu_docs", lang):
        # Sub-menu untuk docs
        docs_choice = questionary.select(
            _t("menu_docs", lang),
            choices=[
                _t("menu_create", lang),
                _t("menu_list", lang),
                _t("menu_clean", lang)
            ]
        ).ask()
        
        if docs_choice == _t("menu_create", lang):
            selected_lang = questionary.select(
                _t("select_lang_prompt", lang),
                choices=[f"{code}: {name}" for code, name in LANGUAGES.items()]
            ).ask().split(":")[0]
            ctx.invoke(init, lang=selected_lang)
        elif docs_choice == _t("menu_list", lang):
            ctx.invoke(list_templates, lang=lang)
        elif docs_choice == _t("menu_clean", lang):
            ctx.invoke(clean, lang=lang)
            
    elif choice == _t("menu_bum", lang):
        ctx.invoke(bum, lang=lang)
    elif choice == _t("menu_help", lang):
        show_custom_help(lang)
    elif choice == _t("menu_exit", lang):
        click.echo(_t("farewell", lang))

@cli.command()
@click.option('--lang', default='en', help='Language for terminal output')
def clean(lang):
    """Delete existing docs/ folder."""
    docs_dir = Path("docs")
    if docs_dir.exists():
        confirmation = questionary.select(
            _t("clean_confirm", lang, path=docs_dir),
            choices=[
                _t("clean_no", lang),
                _t("clean_yes", lang)
            ],
            default=_t("clean_no", lang)
        ).ask()

        if confirmation == _t("clean_yes", lang):
            shutil.rmtree(docs_dir)
            click.echo(_t("clean_success", lang, path=docs_dir))
        else:
            click.echo(_t("clean_cancel", lang))
    else:
        click.echo(_t("clean_not_found", lang))

@cli.command(name='dc', context_settings=dict(ignore_unknown_options=True, allow_extra_args=True))
@click.argument('args', nargs=-1, type=click.UNPROCESSED)
@click.option('--lang', default='en', help='Language for terminal output')
def docker_compose(args, lang):
    """Run 'docker compose' commands. Use 'dc status' or 'dc install'."""
    if args:
        if args[0] == "install":
            install_docker_linux(lang)
            return
        elif args[0] == "status":
            get_dc_status(lang)
            return

    cmd = ["docker", "compose"] + list(args)
    try:
        subprocess.run(cmd)
    except FileNotFoundError:
        # If docker not found, suggest install
        click.echo("❌ Docker Compose not found. Try 'dc install' to install it.")

def get_dc_status(lang):
    """Check OS and Docker version information."""
    from rich.panel import Panel
    from rich.table import Table
    from rich.console import Console

    console = Console()
    
    # 1. OS Info
    os_name = os.name
    distro = "Windows"
    if os_name != 'nt':
        try:
            if os.path.exists("/etc/os-release"):
                with open("/etc/os-release", "r") as f:
                    lines = f.readlines()
                    os_info = {line.split("=")[0]: line.split("=")[1].strip().strip('"') for line in lines if "=" in line}
                    distro = os_info.get("PRETTY_NAME", os_info.get("ID", "Linux"))
        except Exception:
            distro = "Linux"

    # 2. Docker Info
    docker_version = _t("dc_status_not_found", lang)
    try:
        res = subprocess.run(["docker", "--version"], capture_output=True, text=True)
        if res.returncode == 0:
            docker_version = res.stdout.strip()
    except Exception:
        pass

    # 3. Compose Info
    compose_version = _t("dc_status_not_found", lang)
    try:
        res = subprocess.run(["docker", "compose", "version"], capture_output=True, text=True)
        if res.returncode == 0:
            compose_version = res.stdout.strip()
    except Exception:
        pass

    # 4. Show Display
    table = Table(show_header=False, padding=(0, 2))
    table.add_row(_t("dc_status_os", lang), f"[cyan]{distro}[/cyan]")
    table.add_row(_t("dc_status_docker", lang), f"[green]{docker_version}[/green]")
    table.add_row(_t("dc_status_compose", lang), f"[yellow]{compose_version}[/yellow]")

    console.print(Panel(table, title=f"[bold]{_t('dc_status_title', lang)}[/bold]", border_style="blue", expand=False))

def install_docker_linux(lang):
    """Adaptive Docker Installer for >20 Linux Distros."""
    if os.name == 'nt':
        click.echo(_t("dc_install_win_warning", lang))
        return

    click.echo(_t("dc_install_start", lang))
    
    # 1. Detect OS & Distro
    distro = "Unknown"
    pkg_manager = "Unknown"
    
    try:
        if os.path.exists("/etc/os-release"):
            with open("/etc/os-release", "r") as f:
                lines = f.readlines()
                os_info = {line.split("=")[0]: line.split("=")[1].strip().strip('"') for line in lines if "=" in line}
                distro = os_info.get("ID", "unknown").lower()
                distro_like = os_info.get("ID_LIKE", "").lower()
    except Exception:
        pass

    # 2. Map Distro to Package Manager
    # Debian Family
    if any(x in distro or x in distro_like for x in ["ubuntu", "debian", "mint", "kali", "pop", "elementary", "zorin"]):
        pkg_manager = "apt"
        install_script = [
            "sudo apt-get update",
            "sudo apt-get install -y ca-certificates curl gnupg",
            "sudo install -m 0755 -d /etc/apt/keyrings",
            "curl -fsSL https://download.docker.com/linux/" + (distro if distro in ["ubuntu", "debian"] else "ubuntu") + "/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg",
            "sudo chmod a+r /etc/apt/keyrings/docker.gpg",
            'echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/' + (distro if distro in ["ubuntu", "debian"] else "ubuntu") + ' $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null',
            "sudo apt-get update",
            "sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin"
        ]
    # RedHat Family
    elif any(x in distro or x in distro_like for x in ["fedora", "centos", "rhel", "rocky", "almalinux"]):
        pkg_manager = "dnf" if distro == "fedora" else "yum"
        repo_cmd = "sudo dnf config-manager --add-repo https://download.docker.com/linux/" + ("fedora" if distro == "fedora" else "centos") + "/docker-ce.repo"
        install_script = [
            f"sudo {pkg_manager} install -y yum-utils",
            repo_cmd,
            f"sudo {pkg_manager} install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin",
            "sudo systemctl start docker",
            "sudo systemctl enable docker"
        ]
    # Arch Family
    elif any(x in distro or x in distro_like for x in ["arch", "manjaro", "arcolinux"]):
        pkg_manager = "pacman"
        install_script = [
            "sudo pacman -Syu --noconfirm docker docker-compose",
            "sudo systemctl start docker",
            "sudo systemctl enable docker"
        ]
    # SUSE Family
    elif any(x in distro or x in distro_like for x in ["suse", "sles"]):
        pkg_manager = "zypper"
        install_script = [
            "sudo zypper install -y docker docker-compose",
            "sudo systemctl start docker",
            "sudo systemctl enable docker"
        ]
    # Alpine
    elif distro == "alpine":
        pkg_manager = "apk"
        install_script = [
            "sudo apk add docker docker-compose",
            "sudo addgroup root docker",
            "sudo rc-update add docker boot",
            "sudo service docker start"
        ]
    else:
        # Fallback generic or unsupported
        click.echo(_t("dc_install_unsupported", lang, distro=distro))
        return

    # 3. Execute installation
    try:
        click.echo(_t("dc_install_os_desc", lang, os=os.uname().sysname, distro=distro, pkg=pkg_manager))
        for cmd in install_script:
            click.echo(f"  > {cmd}")
            subprocess.run(cmd, shell=True, check=True)
        click.echo(_t("dc_install_success", lang))
    except Exception as e:
        click.echo(_t("dc_install_error", lang, error=str(e)))

def dc_shorthand():
    """Shorthand 'dc' for 'docker compose'."""
    import sys
    if len(sys.argv) > 1:
        if sys.argv[1] == "install":
            install_docker_linux('en')
            return
        elif sys.argv[1] == "status":
            get_dc_status('en')
            return
        
    cmd = ["docker", "compose"] + sys.argv[1:]
    try:
        subprocess.run(cmd)
    except FileNotFoundError:
        print("❌ Docker Compose not found. Try 'sendok dc install' to install it.")

if __name__ == "__main__":
    cli()
