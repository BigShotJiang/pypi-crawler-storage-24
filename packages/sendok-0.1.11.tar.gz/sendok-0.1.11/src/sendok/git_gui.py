import subprocess
import sys
import os
import shutil
from datetime import datetime
import zipfile
import io

# Try to import questionary, if not present, instruct user to install
try:
    import questionary
    from questionary import Style
except ImportError:
    print("Error: 'questionary' library is not installed.")
    print("Please run: pip install questionary")
    sys.exit(1)

# Import Rich for scrolling support
try:
    from rich.console import Console
    from rich.text import Text
    console = Console()
except ImportError:
    console = None

# Import prompt_toolkit for TUI Scroller
try:
    from prompt_toolkit.application import Application
    from prompt_toolkit.layout.containers import HSplit, Window
    from prompt_toolkit.layout.layout import Layout
    from prompt_toolkit.widgets import TextArea
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.layout.controls import FormattedTextControl
    HAS_TUI = True
except Exception as e:
    # Print error at the very top so user sees it
    print(f"\n[CRITICAL] TUI Import Error (Scrolling might be limited): {e}")
    HAS_TUI = False

# Custom style for the CLI
custom_style = Style([
    ('qmark', 'fg:#673ab7 bold'),       # Question mark
    ('question', 'bold'),               # Question text
    ('answer', 'fg:#f44336 bold'),      # Answer text
    ('pointer', 'fg:#673ab7 bold'),     # Pointer
    ('highlighted', 'fg:#673ab7 bold'), # Highlighted option
    ('selected', 'fg:#cc5454'),         # Selected checkbox
    ('separator', 'fg:#cc5454'),        # Separator
    ('instruction', ''),                # Instruction text
    ('text', ''),                       # Normal text
    ('disabled', 'fg:#858585 italic')   # Disabled option
])

def ask_yes_no(question):
    """Helper to replace confirm prompts with a No/Yes selection."""
    answer = questionary.select(
        question,
        choices=["No", "Yes"],
        style=custom_style
    ).ask()
    return answer == "Yes"

def run_git_command(command, interactive=False):
    """Run a git command and print output."""
    # Ensure git commands don't trigger pagers (like 'less') which block the UI
    if command.startswith("git ") and "--no-pager" not in command:
        command = "git --no-pager " + command[4:]
        
    def handle_git_error(error_msg):
        if "dubious ownership" in error_msg:
            print(f"\n[GIT ERROR] {error_msg.strip()}")
            print("-" * 50)
            print("Detected dubious ownership. Automatically fixing this for you...")
            
            folder = os.getcwd().replace("\\", "/")
            # Run the config command automatically
            subprocess.run(f'git config --global --add safe.directory "{folder}"', shell=True, check=False)
            print(f"Success! Folder '{folder}' added to Git safe list.")
            print("Retrying your command...")
            # We don't recursively call to avoid infinite loops, but the next user action will work.
        else:
            print(f"Error: {error_msg.strip()}")

    try:
        if interactive:
            subprocess.run(command, shell=True, check=True)
            return True
        else:
            result = subprocess.run(command, shell=True, capture_output=True, text=True)
            if result.returncode != 0:
                handle_git_error(result.stderr)
                return None
            
            if not result.stdout.strip() and not interactive:
                pass
                
            return result.stdout.rstrip()
    except subprocess.CalledProcessError as e:
        handle_git_error(str(e))
        return None

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def show_scrollable(title, content):
    """Display content in a scrollable interface."""
    if content is None:
        questionary.press_any_key_to_continue().ask()
        return

    if not content.strip():
        print(f"\nNo content found (Empty output) for {title}.")
        # Debug info for the user
        print(f"Current Directory: {os.getcwd()}")
        current_br = run_git_command("git branch --show-current")
        print(f"Current Branch: '{current_br}'")
        questionary.press_any_key_to_continue().ask()
        return

    if HAS_TUI:
        # Define Key Bindings
        kb = KeyBindings()
        
        @kb.add('q')
        @kb.add('escape')
        def _(event):
            event.app.exit()

        # Create TextArea widget
        text_area = TextArea(
            text=content,
            read_only=True,
            scrollbar=True,
            line_numbers=True,
            search_field=None,
            focusable=True,
        )

        # Build Layout
        root_container = HSplit([
            # Title Bar
            Window(
                content=FormattedTextControl(
                    f" {title} | Use Mouse Wheel or Arrows to Scroll | Press 'q' to Return "
                ),
                height=1,
                style='reverse'
            ),
            # Content Area
            text_area,
        ])

        try:
            app = Application(
                layout=Layout(root_container, focused_element=text_area),
                key_bindings=kb,
                full_screen=True,
                mouse_support=True
            )
            app.run()
            return
        except Exception as e:
            print(f"\n[CRITICAL] TUI App Run Error: {e}")
            print("Pesan ini sangat penting, tolong beritahukan ke saya!")
            print("Falling back to standard view...")
            questionary.press_any_key_to_continue().ask()
            # Continue to fallback below
            pass

    # Fallback to rich if prompt_toolkit TUI fails or not available
    if console:
        # Don't clear screen immediately to preserve potential debug prints above
        print(f"\n--- {title} ---")
        print("(Use Mouse Wheel or Arrows to scroll. Press 'q' to Quit.)")
        print("Note: If mouse doesn't work, ensure you are using a modern terminal like Windows Terminal.\n")
        
        with console.pager(styles=True):
            console.print(content)
    else:
        print(f"\n--- {title} ---")
        print(content)
        questionary.press_any_key_to_continue().ask()

def is_git_repo():
    """Verify if the current directory is a git repository."""
    result = subprocess.run("git rev-parse --is-inside-work-tree", shell=True, capture_output=True, text=True)
    return result.returncode == 0

def get_staged_files():
    """Get list of files currently in the staging area."""
    if not is_git_repo(): return []
    res = run_git_command("git diff --cached --name-status")
    if not res: return []
    return res.splitlines()

def get_changed_files():
    """Get list of untracked or modified files (not staged)."""
    if not is_git_repo(): return []
    # Using porcelain status to see everything
    res = run_git_command("git status --porcelain")
    if not res: return []
    return res.splitlines()

def get_status():
    if not is_git_repo():
        return []
    status = run_git_command("git status --porcelain")
    if not status:
        return []
    return status.splitlines()

def main_menu():
    if not is_git_repo():
        print(f"\n--- Git Helper (gg) | Directory: {os.getcwd()} ---")
        print("\n[INFO] This folder is not a Git repository yet.")
        
        if ask_yes_no("Would you like to initialize a new Git repository here? (git init)"):
            run_git_command("git init", interactive=True)
            print("Successfully initialized Git repository.")
            questionary.press_any_key_to_continue().ask()
        else:
            print("Exiting...")
            sys.exit(0)

    while True:
        clear_screen()
        current_branch = run_git_command("git branch --show-current") or "None"
        print(f"\n--- Git Helper (gg) | Branch: {current_branch} ---\n")
        
        choice = questionary.select(
            "What would you like to do?",
            choices=[
                "Exit",
                questionary.Separator(),
                "Status",
                "Staging",
                "Commit",
                "Push",
                "Pull",
                "Branch",
                "Log",
                "Clean",
                "Stash",
                questionary.Separator(),
                "Auto-Branch (Robot)",
                questionary.Separator(),
                "Remove Git (Restore Folder to Normal)"
            ],
            style=custom_style
        ).ask()

        if choice == "Exit":
            sys.exit(0)
        
        elif choice == "Remove Git (Restore Folder to Normal)":
            print("\n[WARNING] This will PERMANENTLY delete the Git history and settings for this folder.")
            print("Your code files will NOT be deleted, but they will return to 'normal' (no more green/git status).")
            
            if ask_yes_no("Are you absolutely sure you want to REMOVE Git from this folder?"):
                try:
                    import shutil
                    git_dir = os.path.join(os.getcwd(), ".git")
                    if os.path.exists(git_dir):
                        # Force remove hidden .git directory
                        if os.name == 'nt': # Windows
                            subprocess.run(['attrib', '-h', '-r', '-s', git_dir], check=False)
                            # Using rd /s /q for more reliable removal of .git on Windows
                            subprocess.run(f'rd /s /q "{git_dir}"', shell=True, check=True)
                        else:
                            shutil.rmtree(git_dir)
                        print("Success! Git has been removed. Folder is now normal.")
                    else:
                        print("Error: .git folder not found.")
                except Exception as e:
                    print(f"Failed to remove Git: {e}")
                
                questionary.press_any_key_to_continue().ask()
                # Exit as this is no longer a git repo
                sys.exit(0)

        elif choice == "Status":
            print("\n--- Git Status ---")
            run_git_command("git status", interactive=True)
            questionary.press_any_key_to_continue().ask()

        elif choice == "Pull":
            print("\n--- Git Pull ---")
            if ask_yes_no("Are you sure you want to pull?"):
                run_git_command("git pull", interactive=True)
            else:
                print("Pull canceled.")
            questionary.press_any_key_to_continue().ask()

        elif choice == "Staging":
            staging_flow()
            
        elif choice == "Push":
            push_flow()

        elif choice == "Commit":
            commit_flow()

        elif choice == "Branch":
            branch_flow()

        elif choice == "Log":
            print("\n--- Git Log ---")
            log_output = run_git_command("git log --oneline --graph --decorate -n 50")
            show_scrollable("Git Log", log_output)
        
        elif choice == "Clean":
            clean_flow()
            
        elif choice == "Stash":
            stash_flow()

        elif choice == "Auto-Branch (Robot)":
            autobranch_flow()

def autobranch_flow():
    import time
    print("\n--- Auto-Branch (Robot) ---")
    print("This mode will automatically save your changes (commit) and create new branches frequently.")
    print("Press Ctrl+C at any time to stop the robot and return to the main menu.\n")
    
    try:
        commit_interval_str = questionary.text("Commit interval in minutes (default 1):", default="1").ask()
        if commit_interval_str is None: return
        commit_interval = float(commit_interval_str)
        
        branch_interval_str = questionary.text("New branch interval in minutes (default 10):", default="10").ask()
        if branch_interval_str is None: return
        branch_interval = float(branch_interval_str)
    except ValueError:
        print("Invalid input. Please enter numbers only.")
        questionary.press_any_key_to_continue().ask()
        return

    print(f"\n[ROBOT] Active! Committing every {commit_interval} min, Branching every {branch_interval} min.")
    print("Press [Ctrl+C] to stop.\n")
    
    last_commit_time = datetime.now()
    last_branch_time = datetime.now()
    
    # Do an immediate commit check
    _do_auto_commit()

    try:
        while True:
            now = datetime.now()
            timestamp = now.strftime("%Y-%m-%d %H:%M:%S")
            
            # 1. Commit check
            diff_commit = (now - last_commit_time).total_seconds() / 60.0
            if diff_commit >= commit_interval:
                _do_auto_commit()
                last_commit_time = now
                
            # 2. Branch check
            diff_branch = (now - last_branch_time).total_seconds() / 60.0
            if diff_branch >= branch_interval:
                branch_name = now.strftime("%Y-%m-%d_%H%M")
                print(f"[{timestamp}] \033[93mWaktunya branch baru: {branch_name}\033[0m")
                run_git_command(f"git checkout -b {branch_name}")
                last_branch_time = now
                
            time.sleep(5) # Check status frequently
    except KeyboardInterrupt:
        print("\n\n[ROBOT] Stopped. Returning to main menu...")
        time.sleep(1)

def _do_auto_commit():
    status = run_git_command("git status --porcelain")
    if status:
        try:
            # Gunakan stderr dan stdout DEVNULL agar bersih
            subprocess.run("git add .", shell=True, stderr=subprocess.DEVNULL, stdout=subprocess.DEVNULL)
            
            # Cek apakah ada file yang berhasil masuk ke staging area
            check_staged = subprocess.run("git diff --cached --quiet", shell=True)
            if check_staged.returncode != 0: # 1 berarti ada perubahan yang di-stage
                now = datetime.now()
                timestamp = now.strftime("%Y-%m-%d %H:%M:%S")
                print(f"[{timestamp}] \033[96mMelakukan commit perubahan...\033[0m")
                subprocess.run(f'git commit -m "Auto-save at {timestamp}"', shell=True, stderr=subprocess.DEVNULL, stdout=subprocess.DEVNULL)
        except Exception as e:
            pass # Abaikan error senyap


def staging_flow():
    while True:
        clear_screen()
        staged = get_staged_files()
        changed = get_changed_files()
        
        # Filter changed to only those NOT staged or partially staged
        # Porcelain status: 'M ' = staged, ' M' = not staged, 'MM' = both, '??' = untracked
        not_staged = [line for line in changed if line[1] != ' ' or line[0] == '?']

        print(f"\n--- Staging Management ({len(staged)} staged, {len(not_staged)} changed) ---")
        
        action = questionary.select(
            "What would you like to do with your files?",
            choices=[
                "Back",
                questionary.Separator("--- Add to Staging ---"),
                "Stage All Changes (git add .)",
                "Select Files to Stage",
                questionary.Separator("--- Remove from Staging ---"),
                "Unstage All (git reset)",
                "Select Files to Unstage",
                questionary.Separator("--- Discard Changes ---"),
                "Discard ALL Changes (git restore .)",
                "Select Files to Discard"
            ],
            style=custom_style
        ).ask()

        if action == "Back" or action is None:
            break
        
        elif action == "Stage All Changes (git add .)":
            run_git_command("git add .")
            print("Done! All changes staged.")
            questionary.press_any_key_to_continue().ask()

        elif action == "Select Files to Stage":
            if not not_staged:
                print("No files to stage.")
                questionary.press_any_key_to_continue().ask()
                continue
            
            choices = []
            for line in not_staged:
                status = line[:2]
                file_path = line[3:]
                choices.append(questionary.Choice(f"{status} {file_path}", value=file_path))
            
            selected = questionary.checkbox("Select files to STAGE:", choices=choices).ask()
            if selected:
                for f in selected:
                    run_git_command(f'git add "{f}"')
                print(f"Staged {len(selected)} files.")
                questionary.press_any_key_to_continue().ask()

        elif action == "Unstage All (git reset)":
            if not staged:
                print("Nothing is staged.")
                questionary.press_any_key_to_continue().ask()
                continue
            if ask_yes_no("Unstage all files? (This won't delete your code edits)"):
                run_git_command("git reset")
                print("All files unstaged.")
                questionary.press_any_key_to_continue().ask()

        elif action == "Select Files to Unstage":
            if not staged:
                print("Nothing is staged.")
                questionary.press_any_key_to_continue().ask()
                continue
            
            choices = [questionary.Choice(f"{line}", value=line[2:].strip()) for line in staged]
            selected = questionary.checkbox("Select files to UNSTAGE:", choices=choices).ask()
            if selected:
                for f in selected:
                    run_git_command(f'git reset "{f}"')
                print(f"Unstaged {len(selected)} files.")
                questionary.press_any_key_to_continue().ask()

        elif action == "Discard ALL Changes (git restore .)":
            if not changed:
                print("No changes to discard.")
                questionary.press_any_key_to_continue().ask()
                continue
            print("\n[WARNING] This will PERMANENTLY delete your uncommitted code edits.")
            if ask_yes_no("Are you absolutely sure you want to DISCARD ALL?"):
                run_git_command("git restore .")
                # Also clean untracked if user confirmed
                if ask_yes_no("Also delete new/untracked files?"):
                    run_git_command("git clean -fd")
                print("Changes discarded.")
                questionary.press_any_key_to_continue().ask()

        elif action == "Select Files to Discard":
            if not changed:
                print("No changes to discard.")
                questionary.press_any_key_to_continue().ask()
                continue
            
            choices = []
            for line in changed:
                status = line[:2]
                file_path = line[3:]
                choices.append(questionary.Choice(f"{status} {file_path}", value=file_path))
            
            selected = questionary.checkbox("Select files to DISCARD (DELETE EDITS):", choices=choices).ask()
            if selected:
                print(f"\n[WARNING] Discarding {len(selected)} files...")
                if ask_yes_no("Confirm PERMANENT deletion of these edits?"):
                    for f in selected:
                        run_git_command(f'git restore "{f}"')
                    print("Files restored.")
                    questionary.press_any_key_to_continue().ask()

def commit_flow():
    print("\n--- Commit Changes ---")
    staged = get_staged_files()
    
    if not staged:
        print("\n[ERROR] Nothing staged for commit.")
        print("Please use the 'Staging' menu first to add files.")
        if ask_yes_no("Go to Staging menu now?"):
            staging_flow()
            # Refresh staged after coming back
            staged = get_staged_files()
            if not staged: return
        else:
            return

    print(f"\nStaged files ({len(staged)}):")
    for f in staged: print(f"  {f}")

    message = questionary.text("\nEnter commit message:", style=custom_style).ask()
    
    if not message:
        print("Commit canceled (empty message).")
        questionary.press_any_key_to_continue().ask()
        return

    if ask_yes_no(f"Commit with message: '{message}'?"):
        run_git_command(f'git commit -m "{message}"', interactive=True)
        
        if ask_yes_no("Do you want to Push now?"):
             branch = run_git_command("git branch --show-current")
             run_git_command(f"git push origin {branch}", interactive=True)
    
    questionary.press_any_key_to_continue().ask()

def branch_flow():
    current_branch = run_git_command("git branch --show-current")
    action = questionary.select(
        f"Branch Operations (Current: {current_branch}):",
        choices=[
            "Back",
            questionary.Separator(),
            "Switch Branch",
            "List Branches",
            "List Branch Files",
            "List Branch Changes",
            "Export Branch Files",
            "Delete Files from Branch",
            "Push Branches",
            "New Branch",
            "Delete Branch"
        ],
        style=custom_style
    ).ask()

    if action == "Back":
        return

    elif action == "Switch Branch":
        branches_raw = run_git_command("git branch --format=%(refname:short)")
        branches = branches_raw.splitlines() if branches_raw else []
        current = run_git_command("git branch --show-current") or ""
        
        if current in branches:
            branches.remove(current)

        # Add Back, then Separate Current Branch, then others
        choices = [
            "Back", 
            questionary.Separator("--- Current Branch ---"), 
            current,
            questionary.Separator("--- Other Branches ---")
        ] + branches
        
        target = questionary.select(
            "Switch Branch:",
            choices=choices,
            style=custom_style
        ).ask()
        
        if target == "Back":
            # Restart branch flow to keep user in branch menu
            branch_flow()
            return

        if target and target != current:
            run_git_command(f"git checkout {target}", interactive=True)

    elif action == "List Branches":
        print("\n--- Local Branches ---")
        branches_output = run_git_command("git branch -vv")
        show_scrollable("Local Branches", branches_output)

    elif action == "List Branch Files":
        branches_raw = run_git_command("git branch --format=%(refname:short)")
        branches = branches_raw.splitlines() if branches_raw else []
        
        target = questionary.select(
            "Select branch to list files:",
            choices=["Back", questionary.Separator()] + branches,
            style=custom_style
        ).ask()
        
        if target == "Back":
            branch_flow()
            return
            
        if target:
            print(f"\n--- Files in {target} ---")
            files_output = run_git_command(f"git ls-tree -r --name-only {target}")
            show_scrollable(f"Files in {target}", files_output)
            branch_flow() # Return to branch menu after listing
            return

    elif action == "List Branch Changes":
        branches_raw = run_git_command("git branch --format=%(refname:short)")
        branches = branches_raw.splitlines() if branches_raw else []
        
        target = questionary.select(
            "Select branch to check changes:",
            choices=["Back", questionary.Separator()] + branches,
            style=custom_style
        ).ask()
        
        if target == "Back":
            branch_flow()
            return
            
        if target:
            # Select base branch to compare against
            base = questionary.select(
                f"Compare {target} against (Select base branch):",
                choices=["main", "master", "Back", questionary.Separator()] + branches,
                style=custom_style
            ).ask()
            
            if base == "Back":
                branch_flow()
                return
                
            if base:
                print(f"\n--- Changes in {target} compared to {base} ---")
                # git diff --name-only base..target
                files_output = run_git_command(f"git diff --name-only {base}..{target}")
                
                if not files_output:
                    files_output = "(No differences found or branches are identical)"
                    
                show_scrollable(f"Changes: {base} -> {target}", files_output)
                branch_flow()
                return

    elif action == "Export Branch Files":
        # ... (existing export logic, kept as is just referenced by context if needed, but we are replacing the block above it mostly)
        # Wait, I need to make sure I don't break the existing Export logic by cutting it off.
        # The prompt target context seems to end before Export logic.
        # I will re-include Export Branch Files in the menu and then add the new elif block for Delete Files.
        
        # Actually, let's just insert the new menu item and block.
        pass 
         
    # RE-GENERITING FULL CONTENT FOR CLARITY because "Export Branch Files" logic is long and I don't want to mess it up.
    # I will target the Menu list and then append the new elif block BEFORE "New Branch".

    # Strategy: Replace the list choices first, then insert the elif block.
    # Actually, I can do it in one go if I include the new elif before "New Branch".
    
    # Wait, the previous tool call "replace_file_content" requires EXACT TargetContent.
    # The file content has "Export Branch Files" already.
    
    # Let's try to target the menu list first.

    elif action == "Export Branch Files":
        branches = run_git_command("git branch --format=%(refname:short)").split('\n')
        
        # Add "Export All Branches" option
        choices = ["Back", "Export All Branches", questionary.Separator()] + branches
        
        target = questionary.select(
            "Select branch to export:",
            choices=choices,
            style=custom_style
        ).ask()
        
        if target == "Back":
            branch_flow()
            return

        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        script_dir = os.path.dirname(os.path.abspath(__file__))
        export_base = os.path.join(script_dir, "gg", "export")

        if target == "Export All Branches":
            export_folder_name = f"branches-{timestamp}"
            export_path = os.path.join(export_base, export_folder_name)
            
            print(f"Exporting ALL branches to {export_path} ...")
            try:
                os.makedirs(export_path, exist_ok=True)
                
                for br in branches:
                    safe_branch = br.replace("/", "_").replace("\\", "_")
                    md_path = os.path.join(export_path, f"{safe_branch}.md")
                    
                    files_cmd = f"git ls-tree -r --name-only {br}"
                    files_output = run_git_command(files_cmd, interactive=False)
                    
                    with open(md_path, "w", encoding="utf-8") as md_file:
                        md_file.write(f"# Export of Branch: {br}\n")
                        md_file.write(f"# Date: {timestamp}\n\n")
                        if files_output:
                            md_file.write("## File List\n\n```text\n")
                            md_file.write(files_output)
                            md_file.write("\n```\n")
                        else:
                            md_file.write("(No files found)\n")
                            
                print(f"Success! Exported {len(branches)} branches to: {export_path}")
                
            except Exception as e:
                print(f"Export All failed: {e}")
                
        else:
            # Single branch export
            safe_branch = target.replace("/", "_").replace("\\", "_")
            export_name = f"{safe_branch}-{timestamp}"
            export_path = os.path.join(export_base, export_name)
            
            if os.path.exists(export_path):
                print(f"Error: Export path already exists: {export_path}")
            else:
                print(f"Exporting {target} to {export_path}.md ...")
                try:
                    # Create directory if needed
                    os.makedirs(export_base, exist_ok=True)
                    final_md_path = f"{export_path}.md"

                    # Run git ls-tree to get all files
                    files_cmd = f"git ls-tree -r --name-only {target}"
                    files_output = run_git_command(files_cmd, interactive=False)
                    
                    if not files_output:
                        print("No files found in branch.")
                        with open(final_md_path, "w", encoding="utf-8") as md_file:
                            md_file.write(f"# Export of Branch: {target}\n")
                            md_file.write(f"# Date: {timestamp}\n\n")
                            md_file.write("(No files found)\n")
                    else:
                        with open(final_md_path, "w", encoding="utf-8") as md_file:
                            md_file.write(f"# Export of Branch: {target}\n")
                            md_file.write(f"# Date: {timestamp}\n\n")
                            md_file.write("## File List\n\n")
                            md_file.write("```text\n")
                            md_file.write(files_output)
                            md_file.write("\n```\n")

                        print(f"Success! Exported to: {final_md_path}")
                        
                except Exception as e:
                    print(f"Export failed: {e}")
            
        questionary.press_any_key_to_continue().ask()
        branch_flow()
        return

    elif action == "Delete Files from Branch":
        branches_raw = run_git_command("git branch --format=%(refname:short)")
        branches = branches_raw.splitlines() if branches_raw else []
        
        target_branch = questionary.select(
            "Select branch to delete files from:",
            choices=["Back", questionary.Separator()] + branches,
            style=custom_style
        ).ask()
        
        if target_branch == "Back":
            branch_flow()
            return
            
        if target_branch:
            # 1. List root files of that branch
            files_cmd = f"git ls-tree --name-only {target_branch}"
            files_output = run_git_command(files_cmd)
            
            if not files_output:
                print("Branch is empty or error reading files.")
                questionary.press_any_key_to_continue().ask()
                branch_flow()
                return
                
            branch_files = files_output.splitlines()
            
            # 2. Select files to delete
            choices = ["Back", questionary.Separator()] + branch_files
            to_delete = questionary.checkbox(
                f"Select files/folders to DELETE from {target_branch}:",
                choices=choices,
                style=custom_style
            ).ask()
            
            if not to_delete or "Back" in to_delete:
                print("No files selected or Back chosen.")
                questionary.press_any_key_to_continue().ask()
                branch_flow()
                return
                
            if not ask_yes_no(f"PERMANENTLY DELETE {len(to_delete)} items from '{target_branch}'? (This creates a new commit)"):
                print("Operation canceled.")
                questionary.press_any_key_to_continue().ask()
                branch_flow()
                return

            # 3. Safe context switch
            current_branch = run_git_command("git branch --show-current")
            
            # Check for unmerged files (conflicts) before doing anything
            # 'U' in status indicates unmerged
            status_porcelain = run_git_command("git status --porcelain")
            if status_porcelain:
                if any(line.startswith('U') or line[1] == 'U' for line in status_porcelain.splitlines()):
                     print("\nCRITICAL: You have unmerged files/conflicts from a previous failed operation.")
                     print("Git is currently 'locked' until this is resolved.")
                     
                     if ask_yes_no("Do you want to RESET (Discard all uncommitted changes) to fix this?"):
                         run_git_command("git reset --hard HEAD", interactive=True)
                         print("Repository has been reset. You can now try the operation again.")
                     
                     questionary.press_any_key_to_continue().ask()
                     branch_flow()
                     return

            stashed = False
            
            if status_porcelain:
                print("Working directory is dirty. Stashing changes...")
                # Use double quotes for safety
                res = run_git_command('git stash push -m "Auto-stash for delete op"', interactive=True)
                if res is None: # Check for failure (run_git_command returns None on error)
                    print("Stash failed. Aborting to protect your changes.")
                    questionary.press_any_key_to_continue().ask()
                    branch_flow()
                    return
                stashed = True
            
            try:
                # Checkout target
                print(f"Switching to {target_branch}...")
                res = run_git_command(f"git checkout {target_branch}", interactive=True)
                if res is None:
                    raise Exception(f"Failed to switch to {target_branch}")
                
                # Check we are actually on the target (double verification)
                now_branch = run_git_command("git branch --show-current")
                if now_branch != target_branch:
                    raise Exception(f"Branch switch check failed. Current: {now_branch}")

                # Remove files
                for item in to_delete:
                    print(f"Deleting {item}...")
                    run_git_command(f'git rm -r "{item}"', interactive=True)
                
                # Verify Staging
                print("\n--- Staged Changes (Ready to Commit) ---")
                run_git_command("git status --short", interactive=True)
                
                # Commit
                run_git_command(f'git commit -m "Removed: {", ".join(to_delete)}"', interactive=True)
                print("Items removed and committed.")
                
                # Verify Commit
                print("\n--- Commit Result ---")
                run_git_command("git --no-pager show --stat --oneline HEAD", interactive=True)
                
                # Offer to Push
                if ask_yes_no(f"Push changes to origin/{target_branch}?"):
                    run_git_command(f"git push origin {target_branch}", interactive=True)
                
            except Exception as e:
                print(f"Error during operation: {e}")
            finally:
                # Return to original branch
                print(f"Returning to {current_branch}...")
                run_git_command(f"git checkout {current_branch}", interactive=True)
                
                if stashed:
                    print("Restoring stashed changes...")
                    run_git_command("git stash pop", interactive=True)
            
            questionary.press_any_key_to_continue().ask()
            branch_flow()
            return

    elif action == "Push Branches":
        push_flow()
                    
    elif action == "New Branch":
        print("\n--- Create New Branch ---")
        name = questionary.text("Enter new branch name (Leave empty to Cancel):").ask()
        
        if not name:
            print("Operation canceled.")
            questionary.press_any_key_to_continue().ask()
            branch_flow()
            return
            
        run_git_command(f"git checkout -b {name}", interactive=True)

    elif action == "Delete Branch":
        branches_raw = run_git_command("git branch --format=%(refname:short)")
        branches = branches_raw.splitlines() if branches_raw else []
        current = run_git_command("git branch --show-current") or ""
        # Filter out current branch to prevent error
        branch_choices = [b for b in branches if b != current]
        
        choices = ["Back", questionary.Separator()] + branch_choices
        
        to_delete = questionary.checkbox("Select branches to delete:", choices=choices, style=custom_style).ask()
        
        if not to_delete or "Back" in to_delete:
            print("No branches selected or Back chosen.")
            branch_flow()
            return

        if to_delete:
            if ask_yes_no(f"Are you sure you want to delete {len(to_delete)} branches?"):
                for b in to_delete:
                    run_git_command(f"git branch -D {b}", interactive=True)

    questionary.press_any_key_to_continue().ask()

def push_flow():
    print("\n--- Push Branches ---")
    branches_raw = run_git_command("git branch --format=%(refname:short)")
    branches = branches_raw.splitlines() if branches_raw else []
    current = run_git_command("git branch --show-current") or ""
    
    # Filter out current from list to re-add it specially
    other_branches = [b for b in branches if b != current]
    
    # Build choices
    choices = ["Back", questionary.Separator()]
    
    # Add Current Branch specially
    choices.append(questionary.Choice(
        title=f"{current} (Current Branch)",
        value=current
    ))
    
    # Add Separator if there are other branches
    if other_branches:
        choices.append(questionary.Separator("--- Other Branches ---"))
        for b in other_branches:
            choices.append(questionary.Choice(title=b, value=b))
    
    to_push = questionary.checkbox(
        "Select branches to push (Space to select, Enter to confirm):",
        choices=choices,
        style=custom_style
    ).ask()
    
    if not to_push or "Back" in to_push:
        print("No branches selected or Back chosen.")
        return
        
    if to_push:
        if ask_yes_no(f"Are you sure you want to PUSH {len(to_push)} branches?"):
            for b in to_push:
                print(f"Pushing {b}...")
                
                # Check result
                res = run_git_command(f"git push origin {b}")
                if res and "Everything up-to-date" not in res:
                    print(res)
                
                # If push fails, run_git_command returns None (due to check=True raising exception)
                # But we need to capture the exception to handle it gracefully and offer Force Push
                try:
                    subprocess.run(f"git push origin {b}", shell=True, check=True)
                except subprocess.CalledProcessError:
                    print(f"\nPush to {b} was REJECTED (Non-fast-forward).")
                    
                    if ask_yes_no(f"FORCE PUSH {b}? (Overwrites remote history)"):
                        run_git_command(f"git push --force-with-lease origin {b}", interactive=True)
            
            questionary.press_any_key_to_continue().ask()

def clean_flow():
    print("\n--- Clean Untracked Files ---")
    if ask_yes_no("This will remove all untracked files and directories. Are you sure?"):
        run_git_command("git clean -fd", interactive=True)
    else:
        print("Clean operation canceled.")
    questionary.press_any_key_to_continue().ask()

def stash_flow():
    action = questionary.select(
        "Stash Operations:",
        choices=[
            "Back",
            questionary.Separator(),
            "Stash Changes",
            "Pop Stash",
            "List Stashes"
        ],
        style=custom_style
    ).ask()

    if action == "Back":
        return

    if action == "Stash Changes":
        msg = questionary.text("Stash message (optional):").ask()
        cmd = f'git stash push -m "{msg}"' if msg else "git stash"
        run_git_command(cmd, interactive=True)
    elif action == "Pop Stash":
        run_git_command("git stash pop", interactive=True)
    elif action == "List Stashes":
        run_git_command("git stash list", interactive=True)
    
    questionary.press_any_key_to_continue().ask()

if __name__ == "__main__":
    try:
        main_menu()
    except KeyboardInterrupt:
        print("\n\nOperation canceled by user. Exiting...")
        sys.exit(0)
