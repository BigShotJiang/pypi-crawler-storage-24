# Windows用NVMガイド 🥄🐍

### バージョン管理
- `nvm list`: インストール済みのバージョンを表示
- `nvm install latest`: 最新バージョンをインストール
- `nvm use 18.16.0`: バージョンを切り替え
- `nvm alias default 18.16.0`: デフォルトバージョンに設定
