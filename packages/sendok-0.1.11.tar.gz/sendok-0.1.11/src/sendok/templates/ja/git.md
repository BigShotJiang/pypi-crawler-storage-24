# Git完全ガイド 🥄📂

### 初期設定
```bash
git config --global user.name "Your Name"
git config --global user.email "you@example.com"
```

### 基本コマンド
- `git init`: リポジトリの初期化
- `git add .`: 変更を追加
- `git commit -m "message"`: 変更を保存
- `git push origin main`: クラウドにアップロード
