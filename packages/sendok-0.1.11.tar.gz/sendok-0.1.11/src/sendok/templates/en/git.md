# Git Complete Guide (English Edition)

This document is a complete guide for using Git from basics to intermediate level for daily development workflows.

---

## 1. Initial Configuration
Before starting, make sure your name and email are registered in your local system.
```powershell
# Set username
git config --global user.name "Your Name"

# Set email
git config --global user.email "email@office.com"

# Check configuration results
git config --list
```

## 2. Basic Workflow (Day-to-Day)
Whenever you start working on something, these are the most commonly used commands:

| Command | Description |
| :--- | :--- |
| `git init` | Create a new git repository in the current folder. |
| `git status` | View file status (which changed, which have not been added). |
| `git add .` | Add **all** changes to the staging area (ready to commit). |
| `git add <file_name>` | Add only a specific file to the staging area. |
| `git commit -m "Message"` | Save changes permanently (snapshot). |
| `git log` | View commit history. |

## 3. Working with Remote (Server)
Once you have an SSH key connected to **git.citraborneo.co.id**:

```powershell
# Cloning (downloading) an existing repository
git clone git@git.citraborneo.co.id:username/project-name.git

# Pulling latest changes from the server
git pull origin <branch_name>

# Sending local changes to the server
git push origin <branch_name>

# Adding remote (if it doesn't exist yet)
git remote add origin git@git.citraborneo.co.id:username/project-name.git
```

## 4. Branching
Branching allows you to work on new features without breaking the main running code.

```powershell
# View list of branches
git branch

# Create a new branch
git branch new-feature

# Switch to another branch
git checkout new-feature
# (Shortcut to create & switch: git checkout -b new-feature)

# Delete a local branch
git branch -d branch-name

# Merging new-feature into main (do this on the main branch)
git merge new-feature
```

## 5. Handling Conflicts (Merge Conflict)
Conflicts occur if two people change the same line in the same file.
1. Git will mark the conflicting file.
2. Open the file, look for `<<<<<<<`, `=======`, and `>>>>>>>`.
3. Choose which code to keep, delete the markers.
4. Save the file, then:
   ```powershell
   git add <conflicting_file>
   git commit -m "Resolving conflict"
   ```

## 6. Advanced Commands (Useful Tools)

### Stashing
Use this if you are in the middle of work and suddenly have to switch branches but don't want to commit yet.
```powershell
# Stash temporarily
git stash

# Retrieve the work back
git stash pop
```

### Undoing Changes
```powershell
# Discard changes in a file that has not been added (restore)
git restore <file_name>

# Unstage a file (git add undo)
git restore --staged <file_name>

# Undo the last commit (but code remains in the file)
git reset --soft HEAD~1
```

## 7. Best Practices
- **Commit Small and Often**: Don't wait for the job to be 100% finished to commit.
- **Clear Commit Messages**: Use *"Adding login feature"* rather than *"Update"*.
- **Sync Before Push**: Always `git pull` before `git push` to avoid conflicts.
- **Main/Master Must Always Work**: Ensure the code in the main branch can always run.

---
*This document was created to simplify the Citra Borneo Indah IT team's workflow.*
