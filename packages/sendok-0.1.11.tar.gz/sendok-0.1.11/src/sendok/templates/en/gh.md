# GitHub CLI (`gh`) Complete Guide

GitHub CLI (`gh`) is the official command-line tool from GitHub that brings GitHub web features (Issues, PR, Repo) directly to your terminal.

---

## 1. Check Installation
Make sure `gh` is installed on your system:
```powershell
gh --version
```

## 2. Authentication (Important!)
Before starting, you must log in to your GitHub account:
```powershell
# Start an interactive login process
gh auth login
```
*Choose: GitHub.com > SSH > Yes (if you want to use existing key) > Login with a web browser.*

To check login status:
```powershell
gh auth status
```

## 3. Repository Management
| Command | Description |
| :--- | :--- |
| `gh repo create` | Create a new repository on GitHub. |
| `gh repo clone <owner/repo>` | Clone a repo (automatically using SSH if configured). |
| `gh repo fork` | Create a fork of someone else's repository. |
| `gh repo view --web` | Open the current repository page in the browser. |

## 4. Working with Pull Requests (PR)
This is the strongest feature of GitHub CLI.
```powershell
# View list of open PRs
gh pr list

# Create a new PR from the current branch
gh pr create --title "PR Message" --body "Change description"

# View your PR status
gh pr status

# Checkout to someone else's PR branch
gh pr checkout <pr-number>

# Merge PR (right from the terminal!)
gh pr merge
```

## 5. Managing Issues
```powershell
# View list of issues
gh issue list

# Create a new issue
gh issue create --title "Login bug" --body "Detailed bug description"

# View details of a specific issue
gh issue view <issue-number>
```

## 6. Gist (Quick Code Notes)
Gist is very useful for storing code snippets.
```powershell
# Create Gist from a file
gh gist create script.py

# Create a public Gist (default is secret)
gh gist create script.py --public
```

## 7. Aliases (Command Shortcuts)
You can create your own shortcuts to work faster.
```powershell
# Example: create 'gh pv' to open repo in web
gh alias set pv 'repo view --web'

# Example: create 'gh lpr' to view my PRs
gh alias set lpr 'pr list --author "@me"'
```

## 8. Productivity Tips
- **Open in Browser**: Almost all commands support the `--web` or `-w` flag to directly open the related page in the browser.
- **Auto-Completion**: If using PowerShell, make sure auto-completion is active so pressing TAB can complete commands automatically.
- **SSH Integration**: Since we have set up the SSH key in `ssh.md`, make sure when `gh auth login` you choose the **SSH** protocol, instead of HTTPS.

---
*Use this guide together with `git.md` for maximum terminal efficiency.*
