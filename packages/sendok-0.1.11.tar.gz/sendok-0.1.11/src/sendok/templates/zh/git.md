# Git 完整指南 🥄📂

### 初始配置
```bash
git config --global user.name "Your Name"
git config --global user.email "you@example.com"
```

### 基础命令
- `git init`: 初始化仓库
- `git add .`: 添加更改
- `git commit -m "message"`: 保存更改
- `git push origin main`: 上传到云端
