# Node.js & NPM 指南 🥄📦

### 常用命令
- `npm init -y`: 初始化项目
- `npm install`: 安装依赖
- `npm start`: 运行应用
- `npm run dev`: 开发模式
- `npm run build`: 构建生产版
