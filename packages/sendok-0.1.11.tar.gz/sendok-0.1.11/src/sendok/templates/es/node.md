# Guía de Node.js & NPM 🥄📦

### Comandos comunes
- `npm init -y`: Iniciar proyecto
- `npm install`: Instalar dependencias
- `npm start`: Ejecutar aplicación
- `npm run dev`: Modo desarrollo
- `npm run build`: Compilar para producción
