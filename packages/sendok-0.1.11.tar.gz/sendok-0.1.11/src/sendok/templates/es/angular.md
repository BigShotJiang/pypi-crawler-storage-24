# Guía de Angular CLI 🥄🅰️

### Comandos de creación
- `ng new mi-app`: Nuevo proyecto
- `ng serve`: Ejecutar localmente
- `ng generate component mi-comp`: Nuevo componente
- `ng build`: Compilar proyecto
