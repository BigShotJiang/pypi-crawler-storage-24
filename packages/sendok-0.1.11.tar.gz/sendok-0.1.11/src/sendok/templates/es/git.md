# Guía completa de Git 🥄📂

### Configuración inicial
```bash
git config --global user.name "Tu Nombre"
git config --global user.email "tu@email.com"
```

### Comandos básicos
- `git init`: Iniciar repositorio
- `git add .`: Agregar cambios
- `git commit -m "mensaje"`: Guardar cambios
- `git push origin main`: Subir a la nube
