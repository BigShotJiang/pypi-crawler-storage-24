"""sendok - Scaffolding Engine for Nimble Documentation Organizer Kit CLI Tool."""
__version__ = "0.1.0"
