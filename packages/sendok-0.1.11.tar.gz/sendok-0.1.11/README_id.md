# sendok 🥄

**sendok** (Scaffolding Engine for Nimble Documentation Organizer Kit) adalah alat bantu pengembangan yang simpel dan cepat untuk mengelola dokumentasi proyek serta mempercepat alur kerja terminal Anda.

[🇺🇸 English](README.md) | [🇪🇸 Español](README_es.md) | [🇯🇵 日本語](README_ja.md) | [🇨🇳 中文](README_zh.md)

---

## ✨ Fitur Utama

- **🚀 Dokumentasi Instan**: Inisialisasi folder `docs/` dengan template standar (SSH, Git, Node, NVM, Angular, GitHub CLI).
- **🌐 Dukungan Multi-bahasa**: Template tersedia dalam 5 bahasa (EN, ID, ES, JA, ZH).
- **🍴 Git Helper (gg)**: Kelola Git secara interaktif! Mendukung auto-init, staging (unstage/discard), dan perbaikan otomatis error *dubious ownership*.
- **🛡️ Backup Manager (bum)**: Cadangkan proyek Anda secara cerdas. Mengabaikan folder berat (`node_modules`) namun tetap menyertakan file penting (`.env`).
- **📡 Satu Jaringan Scan**: Cek siapa saja yang ada di satu jaringan (mendeteksi merek/vendor perangkat).
- **⚡ Pintasan Global (Shorthands)**: Perintah satu huruf untuk tugas umum (Reload, Clear screen, IP Info, dll).
- **🎨 Antarmuka Interaktif**: Menu yang ramah pengguna menggunakan `questionary`.

---

## 🛠️ Instalasi

### Dari Source (Rekomendasi untuk Pintasan Global)
1. Clone repositori ini.
2. Masuk ke folder proyek.
3. Jalankan perintah:
```bash
pip install -e .
```

---

## 🚀 Panduan Penggunaan

### 1. Menu Interaktif
Jalankan alat dengan bahasa pilihan Anda untuk membuka menu navigasi:
- **`sendok id`** : Menu dalam Bahasa Indonesia.
- **`sendok en`** : Menu dalam Bahasa Inggris.
- **`sendok es`** : Menu dalam Bahasa Spanyol.
- **`sendok ja`** : Menu dalam Bahasa Jepang.
- **`sendok zh`** : Menu dalam Bahasa Mandarin.

### 2. Pintasan Global (Langsung di Terminal)
Setelah instalasi, Anda dapat menggunakan perintah berikut dari mana saja tanpa prefix:

| Perintah | Fungsi |
| :--- | :--- |
| **`r`** | Menyegarkan terminal & tampilan VS Code |
| **`gg`** | Menjalankan Git GUI Helper (Interaktif) |
| **`c`** | Membersihkan layar terminal (`cls` atau `clear`) |
| **`p`** | Menampilkan informasi IP (`ipconfig` atau `ifconfig`) |
| **`bum`** | Menjalankan Backup Manager untuk folder saat ini |
| **`dc`** | Menjalankan `docker compose` |
| **`l`** | Menjalankan `npm start` |
| **`ll`** | Menjalankan `npm run dev` |
| **`lll`** | Menjalankan `npm run build` |

### 3. Fitur Git Helper (`gg`)
Gunakan perintah **`gg`** untuk manajemen Git yang lebih mudah tanpa perlu hafal perintah terminal:

| Aksi di Menu | Padanan Perintah Git | Deskripsi |
| :--- | :--- | :--- |
| **Auto-Init** | `git init` | Otomatis membuat repo jika belum ada. |
| **Staging** | `git add` | Memasukkan file ke antrean commit. |
| **Unstage** | `git reset` | Mengeluarkan file dari antrean (aman). |
| **Discard** | `git restore` | Membuang editan & reset file (hati-hati!). |
| **Commit** | `git commit` | Mencatat perubahan secara permanen. |
| **Push/Pull** | `git push/pull` | Sinkronisasi dengan server (GitLab/GitHub). |
| **Branch** | `git branch` | Kelola cabang kodingan. |
| **Remove Git** | `rd /s /q .git` | Balikin folder jadi normal (hapus Git). |
| **Auto-Fix** | `git config ...` | Otomatis benerin error *dubious ownership*. |

### 4. Perintah Standar (Subcommands)
- **`sendok init [id|en|es|ja|zh]`**: Membuat folder dokumentasi.
- **`sendok reload`**: Menyegarkan terminal dan tampilan VS Code.
- **`sendok list`**: Melihat daftar template yang tersedia.
- **`sendok clean`**: Menghapus folder `docs/`.
- **`sendok about`**: Informasi pembuat aplikasi.

---

## 🛡️ Backup Manager (bum)

Fitur `bum` akan membuat folder di `.bum/[folder_proyek]-[tanggal]-[jam]`.
Proses ini secara otomatis mengabaikan:
- `node_modules`, `.git`, `venv`, `.venv`
- `dist`, `build`, `__pycache__`
- Folder `.bum` itu sendiri (menghindari rekursif)

---

## 👤 Pembuat
- **Hasan Askari** (marhaendev)
- **Website**: [hasanaskari.com](https://hasanaskari.com)
- **Email**: marhaendev@gmail.com

🥄 *Simpel. Cepat. Menyendok dokumen dengan mahir!*

---

### ❓ Solusi: Perintah Tidak Ditemukan
Jika muncul error `command not found: sendok` atau `gg` setelah instalasi:
1. **Windows**: Pastikan folder `Scripts` Python Anda sudah masuk ke System PATH (biasanya di `C:\Users\<User>\AppData\Roaming\Python\Python3x\Scripts`).
2. **Linux/macOS**: Pastikan folder `~/.local/bin` ada di PATH Anda. Tambahkan ini ke `.bashrc` atau `.zshrc`:
   ```bash
   export PATH="$HOME/.local/bin:$PATH"
   ```
3. **Restart Terminal**: Tutup dan buka kembali terminal Anda setelah melakukan perubahan.
