# Panduan Angular CLI

Angular CLI (Command Line Interface) adalah alat untuk membuat, mengembangkan, dan memelihara aplikasi Angular langsung dari terminal.

---

## 1. Instalasi Angular CLI
Instal secara global agar perintah `ng` bisa digunakan di mana saja:
```powershell
npm install -g @angular/cli
```
Cek versi:
```powershell
ng version
```

## 2. Membuat Proyek Baru
```powershell
ng new nama-proyek-anda
```
*Tips: Pilih opsi CSS/SCSS dan Routing sesuai kebutuhan proyek.*

## 3. Menjalankan Aplikasi (Development)
```powershell
# Menjalankan server lokal (biasanya di localhost:4200)
ng serve

# Menjalankan dan otomatis membuka browser
ng serve -o

# Menjalankan di port berbeda
ng serve --port 5000
```

## 4. Generate (Membuat Komponen Baru)
Angular CLI sangat membantu dalam membuat struktur file yang rapi dan standar.

| Perintah | Singkatan | Deskripsi |
| :--- | :--- | :--- |
| `ng generate component` | `ng g c` | Membuat komponen baru (html, css, ts, spec). |
| `ng generate service` | `ng g s` | Membuat service untuk logika data. |
| `ng generate module` | `ng g m` | Membuat modul baru. |
| `ng generate interface` | `ng g i` | Membuat tipe data/interface. |

Contoh: `ng g c components/header`

## 5. Build untuk Produksi
Jika aplikasi sudah siap dideploy ke server:
```powershell
ng build --configuration production
```
Hasil build akan muncul di folder `/dist`.

## 6. Testing & Linting
```powershell
# Menjalankan unit test (Karma/Jasmine)
ng test

# Mengecek kualitas kode (linting)
ng lint
```

## 7. Tips Angular CLI
- **Dry Run**: Ingin tahu file apa saja yang akan dibuat tanpa benar-benar membuatnya? Gunakan flag `--dry-run`.
  Contoh: `ng g c test-komponen --dry-run`
- **Inline Style/Template**: Jika komponen sangat sederhana, gunakan:
  `ng g c simpel --inline-style --inline-template`

---
*Angular CLI memastikan standarisasi kode yang rapi untuk proyek skala besar.*
