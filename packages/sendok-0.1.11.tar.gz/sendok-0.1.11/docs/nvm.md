# Panduan NVM for Windows (Node Version Manager)

NVM (Node Version Manager) adalah alat untuk memasang dan mengelola banyak versi Node.js di satu komputer. Ini sangat penting jika Anda mengerjakan banyak proyek dengan kebutuhan versi Node.js yang berbeda.

---

## 1. Perintah Dasar
Berikut adalah perintah yang paling sering digunakan:

| Perintah | Deskripsi |
| :--- | :--- |
| `nvm list` | Melihat daftar versi Node.js yang sudah terinstal. |
| `nvm list available` | Melihat daftar versi Node.js yang tersedia untuk didownload. |
| `nvm install <version>` | Mendownload dan menginstal versi tertentu (contoh: `nvm install 18.16.0`). |
| `nvm use <version>` | Berpindah ke versi Node.js tertentu (membutuhkan akses Administrator di CMD/PowerShell). |
| `nvm uninstall <version>` | Menghapus versi Node.js tertentu. |

## 2. Cara Berpindah Versi
Untuk berpindah versi, jalankan terminal (PowerShell) sebagai **Administrator**:
```powershell
# Contoh berpindah ke versi 18
nvm use 18.20.2
```
Setelah itu, cek apakah versi sudah berubah:
```powershell
node -v
```

## 3. Masalah Umum (Troubleshooting)

### Perintah `node` Tidak Dikenali
Biasanya terjadi karena `nvm use` belum pernah dijalankan atau environment variable belum terupdate.
1. Jalankan `nvm use <versi>` kembali.
2. Restart terminal atau komputer.

### Izin Ditolak (Access Denied)
Jika saat menjalankan `nvm use` muncul error "Access Denied", pastikan Anda membuka terminal dengan cara **Klik Kanan > Run as Administrator**.

## 4. Tips
- Selalu gunakan versi **LTS (Long Term Support)** untuk proyek produksi agar lebih stabil.
- Ketik `nvm install latest` jika ingin mencoba fitur terbaru dari Node.js.
- Anda bisa melihat daftar lengkap perintah dengan mengetik cukup `nvm` saja.

---
*Dokumentasi ini membantu memastikan tim menggunakan versi lingkungan yang seragam.*
