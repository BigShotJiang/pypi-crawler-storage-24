# Panduan Pengaturan SSH (GitLab Kantor)

Dokumen ini berisi langkah-langkah untuk menghubungkan perangkat Anda ke GitLab kantor (**git.citraborneo.co.id**) menggunakan kunci SSH.

## 1. Cek Kunci yang Sudah Ada
Buka terminal (PowerShell atau Bash) dan jalankan:
```powershell
ls ~/.ssh
```
Jika sudah ada file `id_ed25519_office`, Anda bisa langsung ke langkah 3.

## 2. Membuat Kunci SSH Baru
Jika belum ada, buat kunci baru dengan perintah:
```powershell
ssh-keygen -t ed25519 -C "keterangan_perangkat" -f "$HOME/.ssh/id_ed25519_office"
```
*Catatan: Saat diminta passphrase, kosongkan saja (tekan Enter 2x).*

## 3. Konfigurasi File SSH
Buka file `~/.ssh/config` (buat baru jika belum ada) dan pastikan isinya seperti ini:

```text
Host git.citraborneo.co.id
  HostName git.citraborneo.co.id
  User git
  IdentityFile ~/.ssh/id_ed25519_office
  IdentitiesOnly yes

Host github.com
  HostName github.com
  User git
  IdentityFile ~/.ssh/id_ed25519_office
  IdentitiesOnly yes

Host *
  AddKeysToAgent yes
  IdentitiesOnly yes
```

## 4. Tambahkan ke GitLab
1.  Ambil isi kunci publik:
    ```powershell
    cat ~/.ssh/id_ed25519_office.pub
    ```
2.  Copy seluruh teks yang muncul (dimulai dengan `ssh-ed25519 ...`).
3.  Buka [https://git.citraborneo.co.id/-/profile/keys](https://git.citraborneo.co.id/-/profile/keys).
4.  Klik **Add new key**, tempel isinya, pilih **Usage Type: Authentication**, lalu simpan.

## 5. Verifikasi Koneksi
Jalankan perintah ini untuk memastikan semuanya berhasil:
```powershell
ssh -T git@git.citraborneo.co.id
```
Jika muncul pesan: **"Welcome to GitLab, @username!"**, berarti koneksi sudah berhasil.

---
**Tips:** Jika dimintai password saat `ssh -T`, periksa kembali format di file `~/.ssh/config`. Pastikan tidak ada kesalahan ketik pada path `IdentityFile`.
