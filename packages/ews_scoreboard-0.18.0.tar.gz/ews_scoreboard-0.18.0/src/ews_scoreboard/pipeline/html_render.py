"""
HTML Render: scoreboard JSON → AG Grid HTML dashboard.

Reads the scoreboard JSON + sube_bolge_ref.csv, encodes rows into compact
arrays, chunks them, and renders via Jinja2 template.

v300: gzip+base64 chunk encoding + Web Worker decompression.
"""

import base64
import gzip
import json
import math
import os
from collections import OrderedDict
from pathlib import Path

from jinja2 import Environment, FileSystemLoader

from ews_scoreboard.paths import get_template_path, get_template_v300_path, get_js_dir


# ── Constants ────────────────────────────────────────────────────────────
SEGMENTS_LIST = ["KUR-TIC", "KOBI", "MIKRO", "ESKK"]
SEG_MAP = {s: i for i, s in enumerate(SEGMENTS_LIST)}

DEFAULT_CHUNK_SIZE = 10_000
DEFAULT_TOP_N = 100


def _mio(v):
    """TL → milyon TL (float, 1 decimal). None stays None."""
    if v is None:
        return None
    try:
        fv = float(v)
    except (ValueError, TypeError):
        return None
    if fv != fv:  # NaN
        return None
    r = fv / 1_000_000
    if abs(r) >= 1:
        return round(r)
    return round(r, 1)


def _build_bolge_sube_maps(all_rows, ref_csv_path=None):
    """Build BOLGE_LIST, SUBE_LIST and their lookup maps from rows + optional ref CSV."""
    import csv as csv_mod

    _bolge_ref = {}
    _sube_ref = {}

    if ref_csv_path and os.path.exists(ref_csv_path):
        with open(ref_csv_path, encoding="utf-8") as f:
            reader = csv_mod.DictReader(f)
            for row in reader:
                bk = row.get("bolge_kodu", "")
                if bk and bk not in _bolge_ref:
                    _bolge_ref[bk] = row.get("bolge_adi", "")
                sk = row.get("sube_kodu", "")
                if sk and sk not in _sube_ref:
                    _sube_ref[sk] = row.get("sube_adi", "")

    # Ordered unique bölgeler from data
    _bolge_set = OrderedDict()
    for r in all_rows:
        bk = r.get("bolge_kodu")
        if bk is not None and bk not in _bolge_set:
            _bolge_set[bk] = _bolge_ref.get(str(bk), "")

    BOLGE_LIST = [{"kodu": k, "adi": v or f"Bölge {k}"} for k, v in _bolge_set.items()]
    BOLGE_MAP = {b["kodu"]: i for i, b in enumerate(BOLGE_LIST)}

    # Ordered unique şubeler from data
    _sube_set = OrderedDict()
    for r in all_rows:
        sk = r.get("sube_kodu")
        bk = r.get("bolge_kodu")
        if sk is not None and sk not in _sube_set:
            sa = _sube_ref.get(str(sk), f"Şube {sk}")
            _sube_set[sk] = {"adi": sa, "bolge_idx": BOLGE_MAP.get(bk, -1)}

    SUBE_LIST = [{"kodu": k, "adi": v["adi"], "bolge_idx": v["bolge_idx"]}
                 for k, v in _sube_set.items()]
    SUBE_MAP = {s["kodu"]: i for i, s in enumerate(SUBE_LIST)}

    return BOLGE_LIST, BOLGE_MAP, SUBE_LIST, SUBE_MAP


def _row_to_array(row, donemler, risk_donemler, BOLGE_MAP, SUBE_MAP):
    """Convert a dict row to compact array (v316 format)."""
    arr = [
        row.get("muta"),
        (row.get("unvan") or "")[:40],
        SEG_MAP.get(row.get("segment"), -1),
        _mio(row.get("son_risk", 0)),
        BOLGE_MAP.get(row.get("bolge_kodu"), -1),
        SUBE_MAP.get(row.get("sube_kodu"), -1),
    ]
    # EWS scores
    for d in donemler:
        v = row.get(f"ews{d}")
        if v == "YI":
            arr.append(-1)
        elif v is not None:
            try:
                arr.append(int(v))
            except (ValueError, TypeError):
                arr.append(None)
        else:
            arr.append(None)
    # Risk (milyon TL)
    for d in risk_donemler:
        arr.append(_mio(row.get(f"r{d}")))
    # Risk değişimi (milyon TL)
    for d in risk_donemler:
        arr.append(_mio(row.get(f"rd{d}")))
    # Son dönemle fark (milyon TL)
    for d in risk_donemler:
        arr.append(_mio(row.get(f"df{d}")))
    # Trending flags (6 int) + reason (1 str)
    arr.append(row.get("_hizli_yukselen", 0))
    arr.append(row.get("_rejim_degisimi", 0))
    arr.append(row.get("_potansiyel_yi", 0))
    arr.append(row.get("_erken_sinyal", 0))
    arr.append(row.get("_yakalanan", 0))
    arr.append(row.get("_kacirilan", 0))
    arr.append(row.get("_ews_neden", ""))
    arr.append(row.get("_ml_yi_prob", 0))
    return arr


def _build_trending_html(trending: dict) -> str:
    """Build self-contained HTML section for trending lists."""
    sections = [
        ("fastest_rising", "En Hizli Yükselenler", "Son 3 dönemde en çok artan EWS skorları", "#e74c3c"),
        ("regime_change", "Rejim Degisimi", "EUS bandından YIS bandına geçen firmalar", "#e67e22"),
        ("persistent_high", "Kalici Yüksek Risk", "Uzun süredir yüksek EWS skoru taşıyan firmalar", "#c0392b"),
        ("low_but_rising", "Düsük ama Yükselen", "Düşük skorlu ama hızla yükselen firmalar", "#f39c12"),
    ]

    if not any(trending.get(key) for key, *_ in sections):
        return ""

    cards_html = []
    for key, title, desc, color in sections:
        items = trending.get(key, [])
        if not items:
            continue

        rows_html = ""
        for item in items:
            muta = item.get("muta", "")
            unvan = item.get("unvan") or ""
            son_risk = item.get("son_risk", 0) or 0
            risk_mio = round(son_risk / 1_000_000, 2) if son_risk else 0
            score = item.get("score_last", "")
            reason = item.get("reason", "")
            rows_html += f"""<tr>
              <td style="font-weight:600">{muta}</td>
              <td>{unvan}</td>
              <td style="text-align:right">{score}</td>
              <td style="text-align:right">{risk_mio}</td>
              <td style="color:#666;font-size:12px">{reason}</td>
            </tr>"""

        cards_html.append(f"""
        <div style="margin-bottom:24px">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
            <span style="display:inline-block;width:4px;height:20px;background:{color};border-radius:2px"></span>
            <h3 style="margin:0;font-size:16px;color:#333">{title}</h3>
            <span style="font-size:13px;color:#888">({len(items)} firma)</span>
          </div>
          <p style="margin:0 0 8px 12px;font-size:13px;color:#666">{desc}</p>
          <table style="width:100%;border-collapse:collapse;font-size:13px">
            <thead>
              <tr style="background:#f8f9fa;border-bottom:2px solid #dee2e6">
                <th style="text-align:left;padding:6px 8px;width:100px">MUTA</th>
                <th style="text-align:left;padding:6px 8px">Unvan</th>
                <th style="text-align:right;padding:6px 8px;width:80px">EWS Skor</th>
                <th style="text-align:right;padding:6px 8px;width:100px">Risk (Mio)</th>
                <th style="text-align:left;padding:6px 8px">Neden</th>
              </tr>
            </thead>
            <tbody>{rows_html}</tbody>
          </table>
        </div>""")

    return f"""
    <div id="ews-trending-section" style="
        margin:20px auto;max-width:1400px;padding:20px;
        font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
        background:#fff;border:1px solid #e0e0e0;border-radius:8px;
        box-shadow:0 1px 3px rgba(0,0,0,0.08)">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;
                  border-bottom:2px solid #2c3e50;padding-bottom:12px">
        <h2 style="margin:0;font-size:20px;color:#2c3e50">Trending Listeler</h2>
        <button onclick="document.getElementById('ews-trending-cards').style.display=
          document.getElementById('ews-trending-cards').style.display==='none'?'block':'none'"
          style="padding:6px 16px;border:1px solid #ccc;border-radius:4px;background:#f8f9fa;
                 cursor:pointer;font-size:13px">Gizle/Göster</button>
      </div>
      <div id="ews-trending-cards">
        {"".join(cards_html)}
      </div>
    </div>"""


def render_html(scoreboard_or_path, output_html: Path = None,
                ref_csv_path: Path = None,
                trending_path: Path = None,
                chunk_size: int = DEFAULT_CHUNK_SIZE,
                top_n: int = DEFAULT_TOP_N,
                external_link: str = "",
                row_filter: callable = None,
                max_size_mb: float = 0,
                extra_data: dict = None):
    """Render scoreboard dict/JSON → standalone HTML dashboard.

    Args:
        scoreboard_or_path: Scoreboard dict veya JSON dosya yolu (backward compat).
        output_html: Output HTML path.
        ref_csv_path: Path to sube_bolge_ref.csv.
        trending_path: Path to sample_trending_lists.json.
        chunk_size: Rows per JS chunk (default 10000).
        top_n: Initial rows shown (default 100).
        external_link: URL prefix for row double-click.

    Returns:
        dict with status, row count, file size.
    """
    # Backward compat: str/Path → dosyadan oku, dict → doğrudan kullan
    if isinstance(scoreboard_or_path, dict):
        data = scoreboard_or_path
        json_dir = Path(output_html).parent if output_html else Path(".")
    else:
        json_path = Path(scoreboard_or_path)
        json_dir = json_path.parent
        with open(json_path, encoding="utf-8") as f:
            data = json.load(f)

    if output_html is None:
        html_dir = json_dir.parent / "html"
        html_dir.mkdir(parents=True, exist_ok=True)
        output_html = html_dir / "ews_dashboard.html"
    output_html = Path(output_html)

    if ref_csv_path is None:
        ref_csv_path = json_dir / "sube_bolge_ref.csv"

    if trending_path is None:
        trending_path = json_dir / "sample_trending_lists.json"

    # ── Load inline JS (d3 + d3-sankey) ──
    js_dir = get_js_dir()
    d3_js = ""
    d3_sankey_js = ""
    d3_path = js_dir / "d3.min.js"
    d3s_path = js_dir / "d3-sankey.min.js"
    if d3_path.exists():
        d3_js = d3_path.read_text(encoding="utf-8")
    if d3s_path.exists():
        d3_sankey_js = d3s_path.read_text(encoding="utf-8")

    meta = data["meta"]
    all_rows = data["rows"]
    donemler = meta.get("donemler", [])
    if not donemler:
        print("    [WARN] No periods in data, skipping HTML render")
        return {"html_path": str(output_html), "rows": 0, "chunks": 0, "size_kb": 0}
    risk_donemler = meta.get("risk_donemler", donemler)

    # ── Filter rows (optional) ──
    if row_filter:
        all_rows = [r for r in all_rows if row_filter(r)]

    # ── Sort by risk descending ──
    all_rows.sort(key=lambda r: r.get("son_risk") or 0, reverse=True)

    # ── Build lookup maps ──
    BOLGE_LIST, BOLGE_MAP, SUBE_LIST, SUBE_MAP = _build_bolge_sube_maps(
        all_rows, str(ref_csv_path))

    # ── Array encoding ──
    array_rows = [_row_to_array(r, donemler, risk_donemler, BOLGE_MAP, SUBE_MAP)
                  for r in all_rows]

    # ── Chunking ──
    n_rows = len(array_rows)
    n_chunks = math.ceil(n_rows / chunk_size) if n_rows > 0 else 1

    data_chunks = []
    for i in range(n_chunks):
        s = i * chunk_size
        e = min(s + chunk_size, n_rows)
        data_chunks.append(
            json.dumps(array_rows[s:e], ensure_ascii=False, separators=(",", ":"))
        )

    # ── Jinja2 render ──
    tmpl_path = get_template_path()
    tmpl_dir = str(tmpl_path.parent)
    tmpl_name = tmpl_path.name

    env = Environment(loader=FileSystemLoader(tmpl_dir))
    tmpl = env.get_template(tmpl_name)

    # ── Flow matrix + band snapshot ──
    flow_matrix = data.get("flow_matrix", [])
    flow_matrix_js = json.dumps(flow_matrix, ensure_ascii=False, separators=(",", ":"))
    band_snapshot = data.get("band_snapshot", {})
    band_snapshot_js = json.dumps(band_snapshot, ensure_ascii=False, separators=(",", ":"))

    # ── Diag index (EUS kapsam dışı teşhis) ──
    diag_index = data.get("diag_index", {})
    # row_filter aktifse, sadece filtrelenmiş MUTA'ların diag verisini tut
    if row_filter and diag_index:
        filtered_mutas = set()
        for r in all_rows:
            m = r.get("muta")
            if m is not None:
                filtered_mutas.add(m)
                filtered_mutas.add(str(m))
        diag_index = {k: v for k, v in diag_index.items() if k in filtered_mutas}
    # SQL_ADMIN_ONLY: full ve yönetici HTML'lerden SQL/SQL_DELTA bulgularını çıkar
    page_mode = extra_data.get("page_mode", "") if extra_data else ""
    try:
        from ews_scoreboard.diag_groups import SQL_ADMIN_ONLY
    except ImportError:
        SQL_ADMIN_ONLY = False
    if SQL_ADMIN_ONLY and page_mode != "admin" and diag_index:
        _sql_katmanlar = {"SQL", "SQL_DELTA"}
        for muta_key in diag_index:
            muta_data = diag_index[muta_key]
            if isinstance(muta_data, dict):
                for donem_key in muta_data:
                    donem_data = muta_data[donem_key]
                    if isinstance(donem_data, dict) and "bulgular" in donem_data:
                        donem_data["bulgular"] = [
                            b for b in donem_data["bulgular"]
                            if b.get("katman") not in _sql_katmanlar
                        ]
                    elif isinstance(donem_data, list):
                        muta_data[donem_key] = [
                            b for b in donem_data
                            if b.get("katman") not in _sql_katmanlar
                        ]
    # aciklama alanını HTML'den çıkar (frontend'de katman+kriter+deger'den üretilebilir)
    if diag_index:
        for muta_key in diag_index:
            muta_data = diag_index[muta_key]
            if isinstance(muta_data, dict):
                for donem_key in muta_data:
                    donem_data = muta_data[donem_key]
                    if isinstance(donem_data, dict) and "bulgular" in donem_data:
                        for finding in donem_data["bulgular"]:
                            finding.pop("aciklama", None)
                    elif isinstance(donem_data, list):
                        for finding in donem_data:
                            finding.pop("aciklama", None)

    # ── Diag groups config (frontend ikon render için) ──
    try:
        from ews_scoreboard.diag_groups import DIAG_GROUPS, KRITER_ACIKLAMA, KIK_COL_ACIKLAMA, MEMZUC_COL_ACIKLAMA
        diag_groups_js = json.dumps(DIAG_GROUPS, ensure_ascii=False, separators=(",", ":"))
        kriter_aciklama_js = json.dumps(
            {**KRITER_ACIKLAMA, **KIK_COL_ACIKLAMA, **MEMZUC_COL_ACIKLAMA},
            ensure_ascii=False, separators=(",", ":")
        )
    except ImportError:
        diag_groups_js = "{}"
        kriter_aciklama_js = "{}"

    diag_index_js = json.dumps(diag_index, ensure_ascii=False, separators=(",", ":")) if diag_index else "{}"

    html = tmpl.render(
        donemler=json.dumps(donemler, ensure_ascii=False),
        risk_donemler=json.dumps(risk_donemler, ensure_ascii=False),
        top_n=top_n,
        meta=meta,
        data_chunks=data_chunks,
        enumerate=enumerate,
        total_chunks=n_chunks,
        total_rows=n_rows,
        bolge_list_js=json.dumps(BOLGE_LIST, ensure_ascii=False, separators=(",", ":")),
        sube_list_js=json.dumps(SUBE_LIST, ensure_ascii=False, separators=(",", ":")),
        external_link=external_link,
        risk_birim="mio_tl",
        d3_js=d3_js,
        d3_sankey_js=d3_sankey_js,
        flow_matrix_js=flow_matrix_js,
        band_snapshot_js=band_snapshot_js,
        diag_index_js=diag_index_js,
        diag_groups_js=diag_groups_js,
        kriter_aciklama_js=kriter_aciklama_js,
        # Admin mode extras
        page_mode=extra_data.get("page_mode", "") if extra_data else "",
        backtest_summary_js=json.dumps(extra_data.get("backtest_summary", {}), ensure_ascii=False, separators=(",", ":"), default=str) if extra_data else "{}",
        backtest_firma_js=json.dumps(extra_data.get("backtest_firma", {}), ensure_ascii=False, separators=(",", ":"), default=str) if extra_data else "{}",
        ml_predictions_js=json.dumps(extra_data.get("ml_predictions", []), ensure_ascii=False, separators=(",", ":"), default=str) if extra_data else "[]",
    )

    # ── Write output ──
    output_html.parent.mkdir(parents=True, exist_ok=True)
    with open(output_html, "w", encoding="utf-8") as f:
        f.write(html)

    size_bytes = os.path.getsize(output_html)
    size_mb = size_bytes / 1024 / 1024
    size_str = f"{size_mb:.1f} MB" if size_bytes > 1024 * 1024 else f"{size_bytes / 1024:.1f} KB"

    print(f"    HTML: {output_html}")
    print(f"    Boyut: {size_str}  |  {n_rows} satır  |  {n_chunks} chunk")
    print(f"    Bölge: {len(BOLGE_LIST)}  |  Şube: {len(SUBE_LIST)}")

    if max_size_mb > 0 and size_mb > max_size_mb:
        print(f"    [WARN] Boyut limiti aşıldı: {size_mb:.1f} MB > {max_size_mb} MB")

    return {
        "html_path": str(output_html),
        "rows": n_rows,
        "chunks": n_chunks,
        "size_kb": size_bytes / 1024,
    }


# ── v300: gzip+base64 chunk encoding ────────────────────────────────────

def _row_to_array_v300(row, donemler, risk_donemler):
    """Convert a dict row to v300 compact array (no bolge/sube/flags/reason)."""
    arr = [
        row.get("muta"),
        (row.get("unvan") or "")[:40],
        SEG_MAP.get(row.get("segment"), -1),
        row.get("son_risk", 0),
    ]
    for d in donemler:
        v = row.get(f"ews{d}")
        if v == "YI":
            arr.append(-1)
        elif v is not None:
            try:
                arr.append(int(v))
            except (ValueError, TypeError):
                arr.append(None)
        else:
            arr.append(None)
    for d in risk_donemler:
        arr.append(row.get(f"r{d}"))
    return arr


def render_html_v300(json_path: Path, output_html: Path = None,
                     chunk_size: int = DEFAULT_CHUNK_SIZE,
                     top_n: int = DEFAULT_TOP_N,
                     row_filter: callable = None,
                     max_size_mb: float = 0):
    """Render scoreboard JSON → HTML with gzip+base64 chunks (v300 template).

    Uses Web Worker decompression for ~65% smaller HTML files.
    Ideal for large datasets (1M+ rows).
    """
    json_path = Path(json_path)
    json_dir = json_path.parent

    if output_html is None:
        html_dir = json_dir.parent / "html"
        html_dir.mkdir(parents=True, exist_ok=True)
        output_html = html_dir / "ews_dashboard.html"
    output_html = Path(output_html)

    # ── Load JSON ──
    with open(json_path, encoding="utf-8") as f:
        data = json.load(f)

    meta = data["meta"]
    all_rows = data["rows"]
    donemler = meta.get("donemler", [])
    if not donemler:
        print("    [WARN] No periods in data, skipping HTML render")
        return {"html_path": str(output_html), "rows": 0, "chunks": 0, "size_kb": 0}
    risk_donemler = meta.get("risk_donemler", donemler)

    # ── Filter rows (optional) ──
    if row_filter:
        all_rows = [r for r in all_rows if row_filter(r)]

    # ── Sort by risk descending ──
    all_rows.sort(key=lambda r: r.get("son_risk") or 0, reverse=True)

    # ── Array encoding (v300 format) ──
    array_rows = [_row_to_array_v300(r, donemler, risk_donemler) for r in all_rows]

    # ── Gzip + Base64 chunking ──
    n_rows = len(array_rows)
    n_chunks = math.ceil(n_rows / chunk_size) if n_rows > 0 else 1

    data_chunks = []
    raw_total = 0
    gz_total = 0

    for i in range(n_chunks):
        s = i * chunk_size
        e = min(s + chunk_size, n_rows)
        raw_json = json.dumps(array_rows[s:e], ensure_ascii=False, separators=(",", ":"))
        raw_bytes = raw_json.encode("utf-8")
        gz_bytes = gzip.compress(raw_bytes, compresslevel=6)
        b64_str = base64.b64encode(gz_bytes).decode("ascii")
        data_chunks.append(b64_str)
        raw_total += len(raw_bytes)
        gz_total += len(b64_str)

    compression_pct = (1 - gz_total / raw_total) * 100 if raw_total > 0 else 0

    # ── Jinja2 render (v300 template) ──
    tmpl_path = get_template_v300_path()
    tmpl_dir = str(tmpl_path.parent)
    tmpl_name = tmpl_path.name

    env = Environment(loader=FileSystemLoader(tmpl_dir))
    tmpl = env.get_template(tmpl_name)

    html = tmpl.render(
        donemler=json.dumps(donemler, ensure_ascii=False),
        risk_donemler=json.dumps(risk_donemler, ensure_ascii=False),
        top_n=top_n,
        meta=meta,
        data_chunks=data_chunks,
        enumerate=enumerate,
        total_chunks=n_chunks,
        total_rows=n_rows,
    )

    # ── Write output ──
    output_html.parent.mkdir(parents=True, exist_ok=True)
    with open(output_html, "w", encoding="utf-8") as f:
        f.write(html)

    size_bytes = os.path.getsize(output_html)
    size_mb = size_bytes / 1024 / 1024
    size_str = f"{size_mb:.1f} MB" if size_bytes > 1024 * 1024 else f"{size_bytes / 1024:.1f} KB"

    print(f"    HTML (v300): {output_html}")
    print(f"    Boyut: {size_str}  |  {n_rows} satır  |  {n_chunks} chunk")
    print(f"    Gzip kazanç: {compression_pct:.0f}%  (ham: {raw_total/1024/1024:.1f} MB → gz+b64: {gz_total/1024/1024:.1f} MB)")

    if max_size_mb > 0 and size_mb > max_size_mb:
        print(f"    [WARN] Boyut limiti aşıldı: {size_mb:.1f} MB > {max_size_mb} MB")

    return {
        "html_path": str(output_html),
        "rows": n_rows,
        "chunks": n_chunks,
        "size_kb": size_bytes / 1024,
        "compression_pct": compression_pct,
    }
