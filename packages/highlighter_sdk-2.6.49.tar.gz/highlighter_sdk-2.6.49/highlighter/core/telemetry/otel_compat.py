from __future__ import annotations

from opentelemetry.sdk.metrics.export import AggregationTemporality

try:  # Prefer public interfaces if available
    from opentelemetry.sdk.metrics.export import (  # type: ignore
        Gauge,
        Histogram,
        HistogramDataPoint,
        Metric,
        MetricsData,
        NumberDataPoint,
        ResourceMetrics,
        ScopeMetrics,
        Sum,
    )
except ImportError:  # Fallback to internal classes for older SDKs
    from opentelemetry.sdk.metrics._internal.point import (  # type: ignore
        Gauge,
        Histogram,
        HistogramDataPoint,
        Metric,
        MetricsData,
        NumberDataPoint,
        ResourceMetrics,
        ScopeMetrics,
        Sum,
    )

__all__ = [
    "AggregationTemporality",
    "Gauge",
    "Histogram",
    "HistogramDataPoint",
    "Metric",
    "MetricsData",
    "NumberDataPoint",
    "ResourceMetrics",
    "ScopeMetrics",
    "Sum",
]
