from .openobserve import OpenObserveClient

__all__ = ["OpenObserveClient"]
