"""Highlighter Runtime
===========================

This module provides the core runtime infrastructure for the Highlighter SDK, including
the main Runtime class that orchestrates agent execution, signal handling, configuration
management, and data processing workflows.

The Runtime class serves as the primary entry point for executing Highlighter agents,
handling various input sources (files, URLs, raw data), and managing the lifecycle
of processing tasks.

Key Components:
    - Runtime: Main class for orchestrating agent execution
    - Signal handling for graceful shutdown and configuration reloading
    - Network retry logic with circuit breaker patterns
    - Data source parsing and validation
    - Integration with Aiko Services framework

Example:
    Basic usage of the Runtime class:

    >>> from highlighter.core.runtime import Runtime
    >>> runtime = Runtime(agent_definition="path/to/agent.json")
    >>> runtime.run(files=["path/to/image.jpg"])
"""

from __future__ import annotations

import logging
import os
import signal
import sys
import threading
import time
from contextlib import suppress
from datetime import datetime
from pathlib import Path
from queue import Queue
from typing import Iterable, List, Optional, Union
from urllib.parse import urlparse
from uuid import UUID

import aiko_services as aiko
from aiko_services import Stream

# FIXME: (JOSH) the 'core' namespace should not require any other highlighter
# namespaces. If a module that is in 'core' needs to access namespaces outside
# of 'core' it should not be in 'core'.
from highlighter.agent.agent import HLAgent
from highlighter.cli.cli_logging import log_queue_size
from highlighter.client.gql_client import HLClient, close_all_thread_local_clients
from highlighter.client.tasks import TaskContext, lease_task
from highlighter.core.config import (
    HighlighterRuntimeConfig,
)
from highlighter.core.shutdown import runtime_stop_event
from highlighter.core.telemetry.metrics import RUNTIME_SHUTDOWN_US
from highlighter.core.thread_watch import dump_stacks, join_all, patch_threading

# ────────────────────────────────────────────
# Section 1: helpers originally inside _start
# ────────────────────────────────────────────

# Runtime configuration constants
THREAD_GRACEFUL_TIMEOUT = 5  # seconds per thread on shutdown


def derive_agent_name(agent_definition: Union[str, dict, os.PathLike], name: Optional[str]) -> Optional[str]:
    if name:
        return name
    if isinstance(agent_definition, dict):
        return agent_definition.get("name")
    try:
        definition_path = Path(agent_definition)
        if definition_path.exists():
            return definition_path.stem
    except Exception:
        return name
    return name


def _log_to_stderr_fallback(message: str) -> None:
    """Best-effort write used when structured logging might not reach stdout."""

    stream = getattr(sys, "stderr", None)
    if stream is None:
        return
    with suppress(Exception):
        stream.write(f"core.runtime: {message}\n")
        stream.flush()


class Runtime:
    """Core runtime class for executing Highlighter agents.

    The Runtime class orchestrates the execution of Highlighter agents, managing
    configuration, signal handling, and agent lifecycle.
    It supports multiple execution modes including stream initiation and task polling.

    Attributes:
        logger: Logger instance for runtime operations
        agent_definition: Path to agent definition file
        dump_definition: Optional path for dumping agent definition
        allow_non_machine_user: Whether to allow non-machine user tasks
        hl_cfg: Runtime configuration instance
        hl_client: Highlighter client for API communication
        queue_response: External response queue for test harness/CLI integration.
            This is distinct from HLAgent.process_task's per-task response queue.
    """

    def __init__(
        self,
        agent_definition: Union[str, dict, os.PathLike],
        dump_definition: Optional[str] = None,
        allow_non_machine_user: bool = False,
        name: Optional[str] = None,
        hl_cfg: Optional[HighlighterRuntimeConfig] = None,
        hl_client=None,
        # External response queue (test harness / CLI). Distinct from
        # HLAgent.process_task's per-task response queue.
        queue_response=None,
        telemetry_profiler=None,
        logger: Optional[logging.Logger] = None,
    ):
        """Initialize the Runtime instance.

        Args:
            agent_definition: Path to the agent definition JSON file
            dump_definition: Optional path to dump processed agent definition
            allow_non_machine_user: Allow processing tasks from non-machine users
            hl_cfg: Pre-configured runtime configuration
            hl_client: Highlighter client for API communication
            queue_response: External response queue for test/CLI stream integration.
                This is not the per-task response queue used by HLAgent.process_task.
            telemetry_profiler: Optional telemetry profiler instance
            logger: Optional logger instance
        """

        self._install_signal_handlers()
        patch_threading()

        self.agent = None
        self.agent_definition = agent_definition
        self.agent_name = derive_agent_name(agent_definition, name)
        self.dump_definition = dump_definition
        self.allow_non_machine_user = allow_non_machine_user
        self.hl_client = hl_client
        self.queue_response = queue_response
        self.telemetry_profiler = telemetry_profiler
        self._telemetry_flush_thread = None
        self._telemetry_flush_stop = threading.Event()

        self.load_config()
        self.hl_cfg = hl_cfg if hl_cfg is not None else self.hl_cfg  # override with passed in config

        root_logger = logging.getLogger()
        if not root_logger.handlers:
            raise RuntimeError(
                "No logging handlers are configured. Call configure_root_logger(...) before creating Runtime."
            )

        if logger:
            self.logger = logger
        else:
            self.logger = logging.getLogger(__name__)

    # ─────────────────────── signal handling section ───────────────────────
    def _complete_queued_work_then_shutdown(self, signum, frame):
        """Handle SIGTERM signal for graceful shutdown.

        This handler prevents new streams from being created and allows
        current queued work to complete before stopping the agent.

        Args:
            signum: Signal number received
            frame: Current stack frame (unused)
        """
        name = signal.Signals(signum).name
        msg = f"{name} received – preventing new streams, and stopping agent after current queued work"
        self._log_signal(level=logging.INFO, message=msg)
        self.agent.disable_create_stream()
        # Stop all streams after processing process_frame calls on the Aiko event queue
        self.agent.stop_all_streams(graceful=True)

    def _interrupt_and_shutdown(self, signum, frame):
        """Handle SIGINT signal for immediate shutdown.

        This handler stops all streams immediately and drains worker threads.
        Currently processing frames will complete but no new work will start.

        Args:
            signum: Signal number received
            frame: Current stack frame (unused)
        """
        # Restore the default SIGINT handler in case our handler hangs
        signal.signal(signum, signal.SIG_DFL)
        name = signal.Signals(signum).name
        msg = f"{name} received – stopping all streams, draining worker threads and stopping agent"
        self._log_signal(level=logging.INFO, message=msg)
        self.agent.disable_create_stream()
        # Stop all streams immediately.
        # NOTE: If a frame is currently being processed it won't be interrupted.
        self.agent.stop_all_streams(graceful=False)

    def _quick_abort(self, signum, frame):
        """Handle SIGABRT/SIGQUIT signals for emergency abort.

        This handler dumps thread stacks for debugging and then allows
        the default signal behavior (usually core dump) to proceed.

        Args:
            signum: Signal number received (SIGABRT or SIGQUIT)
            frame: Current stack frame (unused)
        """
        name = signal.Signals(signum).name
        msg = f"{name} received – dumping stacks, exiting HARD!"
        self._log_signal(level=logging.ERROR, message=msg)
        dump_stacks(level=logging.ERROR)
        # Re-raise default behaviour so the OS still gets a core dump / stack trace
        signal.signal(signum, signal.SIG_DFL)
        signal.raise_signal(signum)

    def reload_config(self, signum=None, frame=None):
        """Reload configuration at runtime.

        Can be called explicitly or as a signal handler (SIGHUP).
        Reloads the HighlighterRuntimeConfig from disk.

        Args:
            signum: Signal number (when used as signal handler)
            frame: Current stack frame (when used as signal handler)
        """
        self.logger.info("Reloading configuration...")
        try:
            self.load_config(force_reload=True)
            self.logger.info("Reloaded config complete.")
        except Exception as e:
            self.logger.error(f"Error reloading config: {e}")

    def _install_signal_handlers(self) -> None:
        """Register OS-level signal handlers.

        Registers handlers for graceful shutdown, configuration reload,
        and emergency abort. Must be called from the main thread.

        Signals handled:

        - SIGINT: Immediate shutdown
        - SIGTERM: Graceful shutdown after current work
        - SIGABRT: Emergency abort with diagnostics
        - SIGQUIT: Emergency abort with diagnostics (Unix only)
        - SIGHUP: Configuration reload (Unix only)
        - SIGBREAK: Immediate shutdown (Windows only)
        """
        signal.signal(signal.SIGINT, self._interrupt_and_shutdown)
        signal.signal(signal.SIGTERM, self._complete_queued_work_then_shutdown)
        signal.signal(signal.SIGABRT, self._quick_abort)
        try:  # not present on Windows
            signal.signal(signal.SIGQUIT, self._quick_abort)
            signal.signal(signal.SIGHUP, self.reload_config)
        except AttributeError:
            pass
        try:  # Windows only
            signal.signal(signal.SIGBREAK, self._interrupt_and_shutdown)
        except AttributeError:
            pass

    def load_config(self, *, force_reload: bool = False):
        """Load or reload the runtime configuration.

        Loads HighlighterRuntimeConfig from the standard configuration
        sources. Updates the instance's hl_cfg attribute.

        Raises:
            Exception: If configuration loading fails
        """
        self.hl_cfg = HighlighterRuntimeConfig.load(force_reload=force_reload)

    def _start_telemetry_flush_thread(self) -> None:
        if self.telemetry_profiler is None:
            return
        interval = getattr(self.hl_cfg.telemetry, "flush_interval_seconds", 0.0)
        if interval <= 0:
            return
        if self._telemetry_flush_thread and self._telemetry_flush_thread.is_alive():
            return

        self._telemetry_flush_stop.clear()

        def _worker() -> None:
            while not self._telemetry_flush_stop.wait(interval):
                with suppress(Exception):
                    self.telemetry_profiler.flush()

        self._telemetry_flush_thread = threading.Thread(
            target=_worker,
            name="TelemetryFlushThread",
            daemon=True,
        )
        self._telemetry_flush_thread.start()

    def _stop_telemetry_flush_thread(self) -> None:
        if not self._telemetry_flush_thread:
            return
        self._telemetry_flush_stop.set()
        self._telemetry_flush_thread.join(timeout=1.0)

    def start(self):
        """Start the runtime and initialize the agent.

        This method:

        1. Clears any previous stop events
        2. Loads configuration
        3. Initializes the centralized NetworkManager
        4. Creates and starts the HLAgent in a new thread
        """
        self.start_time = datetime.now()
        self.logger.info(f"Starting runtime on pid {os.getpid()}")
        runtime_stop_event.clear()

        from highlighter.core.network_manager import NetworkManager

        NetworkManager.initialize(
            config=self.hl_cfg.network,
            profiler=self.telemetry_profiler,
            logger=self.logger,
        )

        self.agent = HLAgent(
            self.agent_definition,
            name=self.agent_name,
            dump_definition=self.dump_definition,
            timeout_secs=self.hl_cfg.agent.timeout_secs,
            task_lease_duration_secs=self.hl_cfg.agent.task_lease_duration_secs,
            task_polling_period_secs=self.hl_cfg.agent.task_polling_period_secs,
            memory_gc_every_n_frames=self.hl_cfg.agent.memory_gc_every_n_frames,
            memory_gc_every_n_seconds=self.hl_cfg.agent.memory_gc_every_n_seconds,
            memory_malloc_trim_every_n_frames=self.hl_cfg.agent.memory_malloc_trim_every_n_frames,
            memory_malloc_trim_every_n_seconds=self.hl_cfg.agent.memory_malloc_trim_every_n_seconds,
            telemetry_profiler=self.telemetry_profiler,
            telemetry_gc_metrics_enabled=self.hl_cfg.telemetry.gc_metrics_enabled,
        )
        self.logger.info("Starting agent thread …")
        self.agent.run_in_new_thread()
        self._start_telemetry_flush_thread()

    def shutdown(self):
        """Shutdown the runtime gracefully.

        This method:

        1. Stops all agent streams
        2. Stops the agent
        3. Sets the runtime stop event
        4. Dumps thread stacks for debugging
        5. Waits for all threads to join with timeout
        """
        shutdown_span = None
        shutdown_start = None
        if self.telemetry_profiler is not None:
            shutdown_start = time.perf_counter()
            shutdown_span = self.telemetry_profiler.start_span(
                "hl.runtime.shutdown", attributes={"highlighter.shutdown.phase": "start"}
            )
            self.telemetry_profiler.record_process_metrics()
            self.telemetry_profiler.log(
                "INFO",
                "Runtime shutdown starting",
                attributes={"highlighter.shutdown.phase": "start"},
                span=shutdown_span,
            )
        if self.agent is not None:
            self.agent.stop_all_streams()
            self.agent.stop()
        runtime_stop_event.set()  # broadcast the shutdown request

        # Cleanup resources
        from highlighter.core.network_manager import NetworkManager

        NetworkManager.reset()
        close_all_thread_local_clients()

        dump_stacks(level=logging.INFO)
        join_all(timeout=THREAD_GRACEFUL_TIMEOUT)

        elapsed = datetime.now() - self.start_time
        # Using timedelta's string representation is more readable than fractional days.
        msg = f"Runtime shutdown complete. Ran for {elapsed}"
        self._log_signal(level=logging.INFO, message=msg)
        self._stop_telemetry_flush_thread()
        if self.telemetry_profiler is not None:
            if shutdown_start is not None:
                duration_us = (time.perf_counter() - shutdown_start) * 1_000_000
                self.telemetry_profiler.metric(
                    RUNTIME_SHUTDOWN_US,
                    duration_us,
                    "gauge",
                    unit="us",
                    attributes={"highlighter.shutdown.phase": "total"},
                )
            self.telemetry_profiler.record_process_metrics()
            if shutdown_span is not None:
                self.telemetry_profiler.end_span(shutdown_span)
            with suppress(Exception):
                self.telemetry_profiler.close()
            with suppress(Exception):
                from highlighter.core.telemetry import close_otel_log_handler

                close_otel_log_handler()

    def run(
        self,
        server: bool = False,
        stream_definitions: None | List[dict] = None,
        files: None | List[str | Path] = None,
        urls: None | List[str] = None,
        step_id: None | UUID = None,
        task_ids: None | List[UUID] = None,
    ) -> None:
        """Execute the runtime's main processing loop.

        This is the primary entry point for runtime execution. It:

        1. Starts the agent
        2. Initiate process inputs if specified
        3. Initiate processing tasks if specified
        4. Shuts down gracefully after completion

        Execution Modes:

        - Stream initiation: When files, urls, or stream_definitions are provided
        - Task polling: When step_id is provided
        - Specific tasks: When task_ids is provided
        """

        if step_id and task_ids:
            raise ValueError("--step-id and --task-ids are mutually exclusive")

        self.start()  # start agent

        if stream_definitions is None:
            stream_definitions = []
        if urls is None:
            urls = []
        if files is not None:
            for filename in files:
                file_url = f"file://{filename}"
                urls.append(file_url)
        for url in urls:
            stream_definitions.append({"data_sources": f"({len(url)}:{url})"})

        stream_ids = []
        task = TaskContext()
        for stream_id, stream_parameters in enumerate(stream_definitions or []):
            stream_id = str(stream_id)
            stream_ids.append(stream_id)
            # Extract subgraph_name from stream_parameters if present
            stream_params = stream_parameters.copy()
            graph_path = stream_params.pop("subgraph_name", None)
            # Pass the external queue_response (if provided) so callers can observe
            # stream events and frame outputs for non-task streams.
            self.agent.create_stream(
                stream_id=stream_id,
                graph_path=graph_path,
                parameters=stream_params,
                queue_response=self.queue_response,
            )
            self.agent.pipeline.stream_leases[stream_id].stream.variables["task"] = task

        # Wait for streams to stop
        iterations = 0

        if step_id:
            self.agent.poll_for_tasks_loop(step_id, allow_non_machine_user=self.allow_non_machine_user)

        elif task_ids:
            if not self.allow_non_machine_user:
                self.agent.check_user_is_machine()
            # TODO: load hl client if not passed in
            for task_id in [t.strip() for t in task_ids]:
                task = lease_task(
                    self.hl_client,
                    task_id=task_id,
                    lease_sec=self.hl_cfg.agent.task_lease_duration_secs,
                    set_status_to="RUNNING",
                )
                self.agent.process_task(task)

        if server:
            self.logger.info("Continuing to run in server mode")
            while True:
                time.sleep(1)
        else:
            while True:
                # process queue response for frame_id
                # process events - drain all events for frame_id
                if not any([stream_id in self.agent.pipeline.stream_leases for stream_id in stream_ids]):
                    break

                task.finalise_submissions_on_recording_state_off()

                iterations += 1
                if iterations % 10 == 0:
                    self.logger.info("Waiting for streams to stop")
                    if self.queue_response is not None:
                        log_queue_size(
                            self.logger,
                            logging.INFO,
                            self.queue_response,
                            "Stream output queue (external) size: %(qsize)s",
                            error_message="Unable to read external queue size",
                        )

                time.sleep(1)

        self.logger.info("Finished processing, joining worker threads")
        self.shutdown()

    def _log_signal(self, *, level: int, message: str) -> None:
        if self.logger.isEnabledFor(level):
            self.logger.log(level, message)
        else:
            _log_to_stderr_fallback(message)

    def create_stream(
        self,
        stream_id,
        graph_path=None,
        parameters=None,
        grace_time=None,
        queue_response=None,
        topic_response=None,
        frame_complete_hook=None,
        destroy_stream_hook=None,
    ):
        if self.agent is None:
            raise ValueError("Start runtime via runtime.start() before creating a stream")
        return self.agent.create_stream(
            stream_id=stream_id,
            graph_path=graph_path,
            parameters=parameters,
            grace_time=grace_time,
            queue_response=queue_response,
            topic_response=topic_response,
            frame_complete_hook=frame_complete_hook,
            destroy_stream_hook=destroy_stream_hook,
        )

    def destroy_stream(
        self, stream_id, graceful=False, use_thread_local=True, acquire_lock=True, diagnostic={}
    ):
        if self.agent is None:
            raise ValueError("Cannot destroy streams when agent is not running")
        return self.agent.destroy_stream(
            stream_id=stream_id,
            graceful=graceful,
            use_thread_local=use_thread_local,
            acquire_lock=acquire_lock,
            diagnostic=diagnostic,
        )

    def create_frame(
        self, stream: Stream, frame_data: dict, frame_id: int | None = None, graph_path: str | None = None
    ):
        if self.agent is None:
            raise ValueError("Cannot create frame when agent is not running")
        return self.agent.create_frame(stream, frame_data, frame_id=frame_id, graph_path=graph_path)
