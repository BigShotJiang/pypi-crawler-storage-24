import json
from typing import List, Optional

import click

from ..client import HLJSONEncoder, WorkflowOrderType
from ..core import GQLBaseModel


@click.group("workflow-order")
@click.pass_context
def workflow_order_group(ctx):
    pass


@workflow_order_group.command("delete")
@click.option("-i", "--id", type=str, required=True, help="The ID of the workflow order to delete")
@click.option("-y", "--yes", is_flag=True, help="Skip confirmation prompt")
@click.pass_context
def delete(ctx, id, yes):
    """Delete a workflow order"""
    if not yes:
        if not click.confirm(f"Are you sure you want to delete workflow order {id}?"):
            click.echo("Aborted.")
            return
    client = ctx.obj["client"]

    class DeleteWorkflowOrderPayload(GQLBaseModel):
        errors: List[str]
        workflow_order: Optional[WorkflowOrderType] = None

    result = client.deleteWorkflowOrder(return_type=DeleteWorkflowOrderPayload, id=id).gql_dict()
    click.echo(json.dumps(result, cls=HLJSONEncoder))
