import json
from typing import List, Optional

import click

from ..client import HLJSONEncoder, PipelineInstanceType
from ..core import GQLBaseModel


@click.group("pipeline-instance")
@click.pass_context
def pipeline_instance_group(ctx):
    pass


@pipeline_instance_group.command("delete")
@click.option("-i", "--id", type=str, required=True, help="The ID of the pipeline instance to delete")
@click.option("-y", "--yes", is_flag=True, help="Skip confirmation prompt")
@click.pass_context
def delete(ctx, id, yes):
    """Delete a pipeline instance"""
    if not yes:
        if not click.confirm(f"Are you sure you want to delete pipeline instance {id}?"):
            click.echo("Aborted.")
            return
    client = ctx.obj["client"]

    class DeletePipelineInstancePayload(GQLBaseModel):
        errors: List[str]
        pipeline_instance: Optional[PipelineInstanceType] = None

    result = client.deletePipelineInstance(return_type=DeletePipelineInstancePayload, id=id).gql_dict()
    click.echo(json.dumps(result, cls=HLJSONEncoder))
