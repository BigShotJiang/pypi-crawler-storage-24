def select_trainer(trainer_config_file):
    trainer_registry = [
        {
            "name": "yolov11",
            "matcher": lambda value: value and "yolo" in value.lower(),
            "trainer": "highlighter.trainers.yolov11.YoloV11Trainer",
        },
    ]

    for entry in trainer_registry:
        if entry["matcher"](trainer_config_file):
            return entry["name"], _import_trainer(entry["trainer"])

    raise ValueError(f"Unable to determine trainer from trainer_config_file '{trainer_config_file}'")


def _import_trainer(import_path):
    module_path, class_name = import_path.rsplit(".", 1)
    module = __import__(module_path, fromlist=[class_name])
    return getattr(module, class_name)
