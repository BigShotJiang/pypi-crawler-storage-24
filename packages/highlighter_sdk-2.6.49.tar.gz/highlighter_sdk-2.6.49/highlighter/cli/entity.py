import json
from typing import List, Optional

import click

from ..client import HLJSONEncoder
from ..core import GQLBaseModel


@click.group("entity")
@click.pass_context
def entity_group(ctx):
    pass


@entity_group.command("delete")
@click.option("-i", "--id", type=str, required=True, help="The ID of the entity to delete")
@click.option("-y", "--yes", is_flag=True, help="Skip confirmation prompt")
@click.pass_context
def delete(ctx, id, yes):
    """Delete an entity"""
    if not yes:
        if not click.confirm(f"Are you sure you want to delete entity {id}?"):
            click.echo("Aborted.")
            return
    client = ctx.obj["client"]

    class EntityType(GQLBaseModel):
        id: Optional[str] = None

    class DeleteEntityPayload(GQLBaseModel):
        errors: List[str]
        entity: Optional[EntityType] = None

    result = client.deleteEntity(return_type=DeleteEntityPayload, id=id).gql_dict()
    click.echo(json.dumps(result, cls=HLJSONEncoder))
