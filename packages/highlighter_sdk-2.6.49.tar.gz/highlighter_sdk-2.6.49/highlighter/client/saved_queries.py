from __future__ import annotations

from datetime import datetime
from typing import Iterator, List, Optional

from ..core import GQLBaseModel, paginate
from .base_models.page_info import PageInfo

__all__ = [
    "SavedQueryListType",
    "SavedQueryListTypeConnection",
    "iter_saved_queries",
]


class SavedQueryListType(GQLBaseModel):
    id: int
    query_type: str
    title: str
    color_hex: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class SavedQueryListTypeConnection(GQLBaseModel):
    page_info: PageInfo
    nodes: List[SavedQueryListType]


def iter_saved_queries(
    client,
    *,
    ids: Optional[List[object]] = None,
    page_size: int = 200,
) -> Iterator[SavedQueryListType]:
    """Iterate saved-query summaries."""
    kwargs = {"ids": ids}
    kwargs = {k: v for k, v in kwargs.items() if v is not None}
    return paginate(
        client.saved_queries,
        SavedQueryListTypeConnection,
        page_size=page_size,
        **kwargs,
    )
