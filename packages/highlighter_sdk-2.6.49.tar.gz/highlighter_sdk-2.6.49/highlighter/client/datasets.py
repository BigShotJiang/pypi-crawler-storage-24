from __future__ import annotations

from datetime import datetime
from typing import Iterator, List, Optional

from ..core import GQLBaseModel, paginate
from .base_models.page_info import PageInfo

__all__ = [
    "DatasetListType",
    "DatasetListTypeConnection",
    "iter_datasets",
]


class DatasetListType(GQLBaseModel):
    id: int
    name: str
    format: str
    hash_signature: Optional[str] = None
    location_uri: Optional[str] = None
    archived_at: Optional[datetime] = None


class DatasetListTypeConnection(GQLBaseModel):
    page_info: PageInfo
    nodes: List[DatasetListType]


def iter_datasets(
    client,
    *,
    format: Optional[str] = None,
    page_size: int = 200,
) -> Iterator[DatasetListType]:
    """Iterate dataset summaries, not full dataset records."""
    kwargs = {"format": format}
    kwargs = {k: v for k, v in kwargs.items() if v is not None}
    return paginate(
        client.datasets,
        DatasetListTypeConnection,
        page_size=page_size,
        **kwargs,
    )
