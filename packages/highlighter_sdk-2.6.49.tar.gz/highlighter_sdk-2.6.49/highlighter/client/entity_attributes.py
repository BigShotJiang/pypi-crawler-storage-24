from __future__ import annotations

from typing import Iterator, List, Optional

from ..core import GQLBaseModel, paginate
from .base_models.base_models import EntityAttributeType
from .base_models.page_info import PageInfo

__all__ = [
    "EntityAttributeTypeConnection",
    "iter_entity_attributes",
]


class EntityAttributeTypeConnection(GQLBaseModel):
    page_info: PageInfo
    nodes: List[EntityAttributeType]


def iter_entity_attributes(
    client,
    *,
    ids: Optional[List[object]] = None,
    object_class_ids: Optional[List[object]] = None,
    page_size: int = 200,
):
    kwargs = {"ids": ids, "objectClassIds": object_class_ids}
    kwargs = {k: v for k, v in kwargs.items() if v is not None}
    return paginate(
        client.entity_attributes,
        EntityAttributeTypeConnection,
        page_size=page_size,
        **kwargs,
    )
