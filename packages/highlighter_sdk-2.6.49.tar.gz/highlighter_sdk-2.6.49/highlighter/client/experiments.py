from __future__ import annotations

from typing import Iterator, List, Optional

from ..core import GQLBaseModel, paginate
from .base_models.base_models import ExperimentType
from .base_models.page_info import PageInfo

__all__ = [
    "ExperimentTypeConnection",
    "iter_experiments",
]


class ExperimentTypeConnection(GQLBaseModel):
    page_info: PageInfo
    nodes: List[ExperimentType]


def iter_experiments(client, *, ids: Optional[List[object]] = None, page_size: int = 200):
    kwargs = {"id": ids}
    kwargs = {k: v for k, v in kwargs.items() if v is not None}
    return paginate(
        client.experiments,
        ExperimentTypeConnection,
        page_size=page_size,
        **kwargs,
    )
