from __future__ import annotations

from typing import Iterator, List, Optional

from ..core import GQLBaseModel, paginate
from .base_models.base_models import MachineAgentVersion
from .base_models.page_info import PageInfo

__all__ = [
    "MachineAgentVersionConnection",
    "iter_machine_agent_versions",
]


class MachineAgentVersionConnection(GQLBaseModel):
    page_info: PageInfo
    nodes: List[MachineAgentVersion]


def iter_machine_agent_versions(
    client,
    *,
    is_published: Optional[bool] = None,
    page_size: int = 200,
):
    kwargs = {"isPublished": is_published}
    kwargs = {k: v for k, v in kwargs.items() if v is not None}
    return paginate(
        client.machine_agent_versions,
        MachineAgentVersionConnection,
        page_size=page_size,
        **kwargs,
    )
