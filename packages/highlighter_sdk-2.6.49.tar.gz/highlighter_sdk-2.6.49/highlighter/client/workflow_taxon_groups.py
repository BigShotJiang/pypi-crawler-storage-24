from __future__ import annotations

from datetime import datetime
from typing import Iterator, List, Optional

from ..core import GQLBaseModel, paginate
from .base_models.page_info import PageInfo

__all__ = [
    "WorkflowTaxonGroupListType",
    "WorkflowTaxonGroupListTypeConnection",
    "iter_workflow_taxon_groups",
]


class WorkflowTaxonGroupListType(GQLBaseModel):
    id: int
    sort_order: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class WorkflowTaxonGroupListTypeConnection(GQLBaseModel):
    page_info: PageInfo
    nodes: List[WorkflowTaxonGroupListType]


def iter_workflow_taxon_groups(
    client,
    *,
    workflow_id: object,
    page_size: int = 200,
) -> Iterator[WorkflowTaxonGroupListType]:
    """Iterate workflow taxon-group summaries."""
    if workflow_id is None:
        raise TypeError("workflow_id is required")
    return paginate(
        client.workflow_taxon_groups,
        WorkflowTaxonGroupListTypeConnection,
        page_size=page_size,
        workflowId=workflow_id,
    )
