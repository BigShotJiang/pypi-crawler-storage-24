import sqlite3
import os
from bs4 import BeautifulSoup
from datetime import datetime
import markdown
import pypandoc
import re
import importlib.resources as resources
from contextlib import contextmanager
import sys
import traceback
import subprocess
import ctypes
import time

from sculblog.diego_flavored_markdown import count_markdown_words
from sculblog.db import DbConn

#===============================
# Configuration and Utilities
#===============================

server_path = os.path.abspath(os.path.join('/', 'var', 'www', 'html'))
db_path = os.path.abspath(os.path.join(server_path, 'database', 'db.db'))
draft_db_path = os.path.abspath(os.path.join(server_path, 'database', 'drafts.db')) # the variable does not have an s. the filename does
potc_bin = os.environ.get('POTC_BIN', '/root/potc-c/potc')

# load libdtob for direct array append
_dtob_lib_path = os.environ.get('DTOB_LIB', '/root/dtob-doc/libdtob.so')
try:
    _dtob = ctypes.CDLL(_dtob_lib_path)
    _dtob.dtob_array_append_to_file.restype = ctypes.c_int
    _dtob.dtob_array_append_to_file.argtypes = [ctypes.c_char_p, ctypes.c_void_p]
    _dtob.dtob_kvset.restype = ctypes.c_void_p
    _dtob.dtob_kvset_put.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_void_p]
    _dtob.dtob_raw.restype = ctypes.c_void_p
    _dtob.dtob_raw.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
    _dtob.dtob_uint.restype = ctypes.c_void_p
    _dtob.dtob_uint.argtypes = [ctypes.c_uint64]
    _dtob.dtob_array.restype = ctypes.c_void_p
    _dtob.dtob_array_push.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    _dtob.dtob_encode.restype = ctypes.POINTER(ctypes.c_uint8)
    _dtob.dtob_encode.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t)]
except OSError:
    _dtob = None

input_header_message = "what is the header of the page? "

def sanitize_filename(filename: str) -> str:
    return re.sub(r'[^\w\-_\. ]', '_', filename)

def remove_extension(filename):
    return os.path.splitext(filename)[0]

def custom_date():
    now = datetime.now()
    year, day, month_abbr = now.year, now.day, now.strftime('%b')
    month = 'July' if month_abbr == 'Jul' else month_abbr
    return f"{year} {month} {day:02d}"

lua_filter = str(resources.files('sculblog') / 'subsection-wrapper.lua')

#===============================
# HTML and Content Management
#===============================


def write_page_html(file_path: str):
    try:
        html = pypandoc.convert_file(
            file_path,
            to='html',
            format='markdown+fenced_divs-markdown_in_html_blocks',
            extra_args=['--mathml', f'--lua-filter={lua_filter}']
        )
    except Exception as e:
        print(f"Error in write_page_html: {str(e)}")
        raise
    return html

def write_preview_html(html_content: str, char_len: int):
    try:
        # Parse HTML content
        soup = BeautifulSoup(html_content, 'html.parser')
        
        for s_tag in soup.find_all(['style', 'iframe']):
            s_tag.replace_with("")

        # Convert link tags to spans
        for a_tag in soup.find_all('a'):
            span_tag = soup.new_tag('span', **{'class': 'false-external-link'})
            span_tag.string = a_tag.get_text()
            a_tag.replace_with(span_tag)
        
        # Convert header tags to spans
        for h_tag in soup.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6']):
            span_tag = soup.new_tag('span', **{'class': 'preview-header'})
            span_tag.string = h_tag.get_text()
            h_tag.replace_with(span_tag)
        
        # Unwrap any tags that aren't standard text formatting elements
        for tag in soup.find_all():
            if tag.name not in ['span', 'sup', 'sub', 'em', 'strong', 'i', 'b',
                                's', 'strike', 'del',  # Strikethrough variations
                                'u',                   # Underline
                                'mark',                # Highlight/marking
                                'small',               # Smaller text
                                'q', 'cite',           # Quotations
                                'code', 'kbd',         # Code and keyboard input
                                'abbr',                # Abbreviations
                            ]:           
                tag.unwrap()
        
        # Get all text content to check length
        text_content = soup.get_text()
        
        # If text is longer than char_len, truncate
        if len(text_content) > char_len:
            # Find all text nodes and accumulate up to char_len
            text_nodes = []
            current_count = 0
            
            for element in soup.descendants:
                if isinstance(element, str) and current_count < char_len:
                    if current_count + len(element) <= char_len:
                        text_nodes.append((element, element))
                        current_count += len(element)
                    else:
                        # Truncate this text node
                        truncated = element[:char_len - current_count] + "..."
                        text_nodes.append((element, truncated))
                        current_count = char_len
                        break
            
            # Replace text nodes with truncated versions
            for original, truncated in text_nodes:
                if original != truncated:
                    original.replace_with(truncated)
        
        # Get final HTML with all tags properly closed
        clean_html = ''.join(str(tag) for tag in soup.contents)
        return clean_html
        
    except Exception as e:
        print(f"Error in write_preview_html: {str(e)}")
        print("Traceback:")
        traceback.print_exc()
        raise

#===============================
# Main Functions
#===============================

def strip_links(html):
    """Strip <a> tags from HTML, recording their positions as macrolinks/autolinks.

    Returns (stripped_html, macrolinks, autolinks) where:
      macrolinks = [{"href": str, "ref_start": int, "ref_end": int}, ...]
      autolinks  = [{"anchor": str, "def_start": int, "def_end": int,
                      "ref_start": int, "ref_end": int}, ...]
    """
    import json
    macrolinks = []
    autolinks = []

    # first pass: find all header positions by id (for autolink defslice resolution)
    header_positions = {}
    tag_re = re.compile(r'<[^>]+>')
    id_re = re.compile(r'<(?:h[1-6]|section|div)[^>]*\bid=["\']([^"\']+)["\'][^>]*>', re.IGNORECASE)

    # we need to compute header positions in the stripped text, so we do the
    # full strip first, then come back for autolinks. two-pass approach.

    # strip all <a> tags, keep inner text, track positions
    result = []
    pos = 0  # position in stripped output
    i = 0
    links = []  # temp storage: (href, ref_start, ref_end)

    while i < len(html):
        # look for <a ...>
        a_match = re.search(r'<a\s[^>]*>', html[i:])
        if not a_match:
            result.append(html[i:])
            break

        # everything before the <a> tag
        before = html[i:i + a_match.start()]
        result.append(before)
        pos += len(before)

        # parse the href
        tag_str = a_match.group()
        href_match = re.search(r'href=["\']([^"\']*)["\']', tag_str)
        href = href_match.group(1) if href_match else ""

        # find the closing </a>
        inner_start = i + a_match.start() + len(tag_str)
        close_match = re.search(r'</a\s*>', html[inner_start:], re.IGNORECASE)
        if not close_match:
            # malformed, just dump the rest
            result.append(html[i + a_match.start():])
            break

        inner_text = html[inner_start:inner_start + close_match.start()]
        ref_start = pos
        result.append(inner_text)
        pos += len(inner_text)
        ref_end = pos - 1  # inclusive

        links.append({"href": href, "ref_start": ref_start, "ref_end": ref_end})

        i = inner_start + close_match.start() + len(close_match.group())

    stripped_html = ''.join(result)

    # now find header/id positions in stripped_html for autolink defslice resolution
    stripped_text_pos = 0
    for m in re.finditer(r'<(?:h[1-6]|section|div)[^>]*\bid=["\']([^"\']+)["\'][^>]*>', stripped_html):
        anchor_id = m.group(1)
        # the defslice starts at the tag's content (after the opening tag)
        tag_end = m.end()
        # find the closing tag
        tag_name = re.match(r'<(\w+)', m.group()).group(1)
        close = re.search(r'</' + tag_name + r'\s*>', stripped_html[tag_end:], re.IGNORECASE)
        if close:
            def_start = tag_end
            def_end = tag_end + close.start() - 1
            header_positions[anchor_id] = (def_start, def_end)

    # classify links as macrolinks or autolinks
    for link in links:
        href = link["href"]
        if href.startswith("#"):
            # autolink — same-document reference
            anchor = href[1:]
            if anchor in header_positions:
                def_start, def_end = header_positions[anchor]
                autolinks.append({
                    "anchor": anchor,
                    "def_start": def_start,
                    "def_end": def_end,
                    "ref_start": link["ref_start"],
                    "ref_end": link["ref_end"],
                })
            # if anchor not found, skip silently (dangling ref)
        else:
            # macrolink — external or cross-document reference
            macrolinks.append({
                "href": href,
                "ref_start": link["ref_start"],
                "ref_end": link["ref_end"],
            })

    return stripped_html, macrolinks, autolinks


def compute_cid(content_path):
    """Compute Bromberg CID by calling potc singlehash. Returns 32 bytes or None."""
    try:
        result = subprocess.run([potc_bin, "singlehash", "-f", content_path],
                                capture_output=True, text=True)
        if result.returncode == 0 and len(result.stdout.strip()) == 64:
            return bytes.fromhex(result.stdout.strip())
    except Exception:
        pass
    return None


def generate_ruid():
    """Generate a random 32-byte RUID."""
    return os.urandom(32)


def _dtob_kv_entry(**fields):
    """Build a DtobValue kvset from keyword args via ctypes. Values can be bytes or int."""
    kv = _dtob.dtob_kvset()
    for key, val in fields.items():
        if isinstance(val, bytes):
            v = _dtob.dtob_raw(val, len(val))
        elif isinstance(val, int):
            v = _dtob.dtob_uint(val)
        else:
            continue
        _dtob.dtob_kvset_put(kv, key.encode(), v)
    return kv


def update_xvs(server_path, category, file_name, ruid, cid):
    """Append {ruid, cid, timestamp} to the .xvs DTOB file via libdtob."""
    if not _dtob:
        print("libdtob not loaded, skipping xvs")
        return ruid

    xvs_path = os.path.join(server_path, category, file_name + ".xvs")
    entry = _dtob_kv_entry(
        ruid=ruid,
        cid=cid if cid else b'\x00' * 32,
        timestamp=int(time.time()),
    )
    _dtob.dtob_array_append_to_file(xvs_path.encode(), entry)
    return ruid


def propagate_neolinks(server_path, category, file_name, version, macrolinks, ruid, db=None, title=None):
    """For each macrolink pointing to a local document, append a neolink to the target's .nl DTOB file
    and insert into neolinks_index SQLite table."""
    if not _dtob:
        print("libdtob not loaded, skipping neolink propagation")
        return

    for link in macrolinks:
        href = link["href"]
        if href.startswith("http://") or href.startswith("https://"):
            continue

        href_clean = href.split("#")[0].split("?")[0]
        if href_clean.endswith(".php"):
            href_clean = href_clean[:-4]
        href_clean = href_clean.rstrip("/")
        target_name = os.path.basename(href_clean)
        if not target_name:
            continue

        href_parts = href_clean.strip("/").split("/")
        target_category = href_parts[-2] if len(href_parts) >= 2 else category

        nl_path = os.path.join(server_path, target_category, target_name + ".nl")
        entry = _dtob_kv_entry(
            from_ruid=ruid,
            from_category=category.encode(),
            from_file=file_name.encode(),
            from_version=version,
            ref_start=link["ref_start"],
            ref_end=link["ref_end"],
        )
        _dtob.dtob_array_append_to_file(nl_path.encode(), entry)

        # also insert into neolinks_index for PHP server-side rendering
        if db:
            try:
                db.execute_query(
                    "INSERT INTO neolinks_index (target_category, target_file, from_ruid, from_category, from_file, from_title) VALUES (?, ?, ?, ?, ?, ?)",
                    [target_category, target_name, ruid, category, file_name, title or file_name]
                )
            except Exception:
                pass  # table might not exist yet

        print(f"  neolink → {target_category}/{target_name}")


def _parse_href_target(href, current_category):
    """Parse a macrolink href into (target_category, target_file_name).
    Returns (None, None) for external URLs."""
    if href.startswith("http://") or href.startswith("https://"):
        return None, None

    href_clean = href.split("#")[0].split("?")[0]
    if href_clean.endswith(".php"):
        href_clean = href_clean[:-4]
    href_clean = href_clean.rstrip("/")
    target_name = os.path.basename(href_clean)
    if not target_name:
        return None, None

    href_parts = href_clean.strip("/").split("/")
    target_category = href_parts[-2] if len(href_parts) >= 2 else current_category
    return target_category, target_name


def _resolve_target_ids(db, target_category, target_file_name):
    """Look up a target document's ruid and cid from netdoc_ids.
    Returns (ruid, cid) — zero-filled 32-byte blobs if not found."""
    zero = b'\x00' * 32
    if not db:
        return zero, zero
    row = db.execute_single_query(
        "SELECT ruid, cid FROM netdoc_ids WHERE category = ? AND file_name = ?",
        [target_category, target_file_name]
    )
    if row and row.get("ruid"):
        return (row["ruid"] or zero), (row["cid"] or zero)
    return zero, zero


def _store_netdoc_ids(db, category, file_name, draft, ruid, cid, title=None):
    """UPDATE the category table with ruid/cid and INSERT OR REPLACE into netdoc_ids."""
    if not db:
        return
    # update the category table row
    db.execute_query(
        f"UPDATE {category} SET ruid = ?, cid = ? WHERE file_name = ? AND draft = ?",
        [ruid, cid, file_name, draft]
    )
    # upsert into the lookup table
    db.execute_query(
        "INSERT OR REPLACE INTO netdoc_ids (ruid, cid, category, file_name, draft, title) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        [ruid, cid, category, file_name, draft, title]
    )


def _store_document_links(db, category, file_name, macrolinks, autolinks):
    """Persist macrolinks and autolinks into the document_links table."""
    if not db:
        return

    # clear existing links for this source document
    db.execute_query(
        "DELETE FROM document_links WHERE source_category = ? AND source_file = ?",
        [category, file_name]
    )

    # insert macrolinks
    for link in macrolinks:
        target_cat, target_fn = _parse_href_target(link["href"], category)
        if not target_cat or not target_fn:
            continue

        # look up target ruid and title
        target_ruid = None
        target_title = None
        row = db.execute_single_query(
            "SELECT ruid, title FROM netdoc_ids WHERE category = ? AND file_name = ?",
            [target_cat, target_fn]
        )
        if row:
            target_ruid = row.get("ruid")
            target_title = row.get("title")

        db.execute_query(
            "INSERT INTO document_links (source_category, source_file, link_type, "
            "target_ruid, target_category, target_file, target_title, ref_start, ref_end) "
            "VALUES (?, ?, 'macro', ?, ?, ?, ?, ?, ?)",
            [category, file_name, target_ruid, target_cat, target_fn,
             target_title, link["ref_start"], link["ref_end"]]
        )

    # insert autolinks
    for link in autolinks:
        db.execute_query(
            "INSERT INTO document_links (source_category, source_file, link_type, "
            "ref_start, ref_end, def_start, def_end, anchor) "
            "VALUES (?, ?, 'auto', ?, ?, ?, ?, ?)",
            [category, file_name, link["ref_start"], link["ref_end"],
             link["def_start"], link["def_end"], link["anchor"]]
        )


def write_netdoc(page_html, server_path, category, file_name, version, db=None):
    """Strip links from HTML, encode content as .nd DTOB, write link metadata,
    update XVS, store ruid/cid in SQLite, and propagate neolinks."""
    try:
        import tempfile

        stripped_html, macrolinks, autolinks = strip_links(page_html)
        nd_output = os.path.join(server_path, category, file_name + ".nd." + str(version))

        # encode the stripped content as DTOB (to temp file, then read bytes)
        with tempfile.NamedTemporaryFile(suffix='.html', mode='w', delete=False) as tmp:
            tmp.write('<div>' + stripped_html + '</div>')
            tmp_path = tmp.name

        cid = compute_cid(tmp_path)

        content_tmp = nd_output + ".content.tmp"
        subprocess.run(["dtob", "encode", tmp_path, content_tmp])
        os.unlink(tmp_path)

        with open(content_tmp, 'rb') as f:
            content_bytes = f.read()
        os.unlink(content_tmp)

        ruid = generate_ruid()

        # store ruid/cid in SQLite
        title_row = db.execute_single_query(
            f"SELECT header FROM {category} WHERE file_name = ? AND draft = ?",
            [file_name, version]
        ) if db else None
        title = title_row["header"] if title_row and title_row.get("header") else None
        _store_netdoc_ids(db, category, file_name, version, ruid, cid, title)

        if not _dtob:
            print("libdtob not loaded, can't build netdoc")
            return

        # build the full netdoc via libdtob ctypes
        root = _dtob.dtob_kvset()

        # 1. magic
        magic = b"24032026"
        _dtob.dtob_kvset_put(root, b"magic", _dtob.dtob_raw(magic, len(magic)))

        # 2. identifiers
        ids = _dtob.dtob_kvset()
        _dtob.dtob_kvset_put(ids, b"ruid", _dtob.dtob_raw(ruid, 32))
        _dtob.dtob_kvset_put(ids, b"cid", _dtob.dtob_raw(cid if cid else b'\x00' * 32, 32))
        _dtob.dtob_kvset_put(ids, b"sha256", _dtob.dtob_raw(b'\x00' * 32, 32))
        _dtob.dtob_kvset_put(root, b"ids", ids)

        # 3. paleolinks — macrolinks resolve href to target ruid+cid
        macro_arr = _dtob.dtob_array()
        for link in macrolinks:
            target_cat, target_fn = _parse_href_target(link["href"], category)
            if target_cat and target_fn:
                def_ruid, def_cid = _resolve_target_ids(db, target_cat, target_fn)
            else:
                def_ruid, def_cid = b'\x00' * 32, b'\x00' * 32
            entry = _dtob_kv_entry(
                def_ruid=def_ruid,
                ref_ruid=ruid,
                def_cid=def_cid,
                ref_cid=cid if cid else b'\x00' * 32,
                ref_start=link["ref_start"],
                ref_end=link["ref_end"],
            )
            _dtob.dtob_array_push(macro_arr, entry)
        paleo = _dtob.dtob_kvset()
        _dtob.dtob_kvset_put(paleo, b"macrolinks", macro_arr)
        _dtob.dtob_kvset_put(root, b"paleolinks", paleo)

        # autolinks — purely positional: defslice + refslice, no anchor
        auto_arr = _dtob.dtob_array()
        for link in autolinks:
            entry = _dtob_kv_entry(
                def_start=link["def_start"],
                def_end=link["def_end"],
                ref_start=link["ref_start"],
                ref_end=link["ref_end"],
            )
            _dtob.dtob_array_push(auto_arr, entry)
        autos = _dtob.dtob_kvset()
        _dtob.dtob_kvset_put(autos, b"autolinks", auto_arr)
        _dtob.dtob_kvset_put(root, b"autolinks", autos)

        # 4. content (raw DTOB bytes)
        _dtob.dtob_kvset_put(root, b"content", _dtob.dtob_raw(content_bytes, len(content_bytes)))

        # encode and write
        out_len = ctypes.c_size_t()
        _dtob.dtob_encode.restype = ctypes.POINTER(ctypes.c_uint8)
        _dtob.dtob_encode.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t)]
        encoded = _dtob.dtob_encode(root, ctypes.byref(out_len))
        if encoded:
            with open(nd_output, 'wb') as f:
                f.write(bytes(encoded[:out_len.value]))
            ctypes.CDLL(None).free(encoded)  # encoded is malloc'd bytes, not DtobValue

        # store document links in SQLite
        _store_document_links(db, category, file_name, macrolinks, autolinks)

        # update XVS
        update_xvs(server_path, category, file_name, ruid, cid)

        # propagate neolinks to local targets
        propagate_neolinks(server_path, category, file_name, version, macrolinks, ruid, db=db, title=title)

        print(f"netdoc: {len(macrolinks)} macrolinks, {len(autolinks)} autolinks, cid={'ok' if cid else 'failed'}")

    except Exception as e:
        if "dtob" in str(e).lower() or isinstance(e, FileNotFoundError):
            print("dtob not installed")
        else:
            print(f"netdoc error: {e}")

def post_updater(category, file_path, subcommand):
    try:
        draft_db = DbConn(draft_db_path)
        db = DbConn(db_path)

        page_html = write_page_html(file_path)
        file_name = os.path.splitext(os.path.basename(file_path))[0]

        with open(os.path.abspath(file_path), "r") as file: # this is to get word count
            markdown_content = file.read()
 
        post_data = {
            "text": page_html,
            "preview_html": write_preview_html(page_html, 1500),
            "word_count": count_markdown_words(markdown_content), 
        }
        
        # if it's not in there yet
        if not db.value_in_column(category, "file_name", file_name): 

            post_data["header"] = input(input_header_message)
            post_data["file_name"] = file_name
            post_data["date_splash"] = custom_date()
            
            # draft 0 is for preview. everything else is for regular drafts

            post_data["draft"] = 1
            if db.insert_row(category, post_data):
                pass
            else:
                raise Exception("Failed to insert data.")

            for x in [0,1]:
                draft_data = post_data.copy()
                draft_data["draft"] = x
                if draft_db.insert_row(category, draft_data): # this was post_data
                    pass
                else:
                    raise Exception("Failed to insert data.")

                print(f"Successfully inserted data for post {file_name}")

            write_netdoc(page_html, server_path, category, file_name, 1, db=db)

        # here it is in there already
        else:
            # db.update_row(category, "file_name", file_name, post_data)
            values = list(post_data.values()) + [file_name]

            # if it is draft, then it makes a copy and increments the draft counter. if it is preview, then it just updates the where draft is zero
            if subcommand == "draft": 

                set_clause = ", ".join([f"{col} = ?" for col in post_data.keys()])
                where_clause = f"WHERE file_name = ? AND draft = (SELECT MAX(draft) FROM {category} WHERE file_name = ?)"
                draft_columns = ', '.join(post_data.keys()) + ', file_name, draft'
                placeholders = ', '.join(['?'] * len(post_data))
                subquery_draft = f"(SELECT COALESCE(MAX(draft), 0) + 1 FROM {category} WHERE file_name = ?)"
                draft_values = list(post_data.values()) + [file_name, file_name, file_name, file_name]

                draft_query = f"""
                    INSERT INTO {category} ({draft_columns})
                    SELECT {placeholders}, ?, {subquery_draft}
                    FROM {category}
                    {where_clause}
                    LIMIT 1
                """

                draft_db.execute_query(draft_query, draft_values)
                columns = ', '.join([f"{key} = ?" for key in post_data.keys()])

                query = f"""
                    UPDATE {category}
                    SET draft = draft + 1, {columns}
                    WHERE file_name = ?
                """
                
                db.execute_query(query, values)

                draft_num = draft_db.execute_single_query(f"SELECT MAX(draft) as max_draft FROM {category} WHERE file_name = ?", [file_name])
                write_netdoc(page_html, server_path, category, file_name, draft_num["max_draft"], db=db)

            elif subcommand == "update":
                
                long_values = list(post_data.values()) + [file_name, file_name]
                set_clause = ", ".join([f"{col} = ?" for col in post_data.keys() if col != "date_splash"])
                where_clause = f" file_name = ? AND draft = (SELECT MAX(draft) FROM {category} WHERE file_name = ?)"
                query = F"UPDATE {category} SET {set_clause} WHERE {where_clause}"

                alt_where_clause = f" file_name = ? AND draft = 0"
                alt_query = F"UPDATE {category} SET {set_clause} WHERE {alt_where_clause}"

                draft_db.execute_query(alt_query, values)
                draft_db.execute_query(query, long_values)
                db.execute_query(query, long_values)

                draft_num = draft_db.execute_single_query(f"SELECT MAX(draft) as max_draft FROM {category} WHERE file_name = ?", [file_name])
                write_netdoc(page_html, server_path, category, file_name, draft_num["max_draft"], db=db)

            elif subcommand == "preview":
                
                set_clause = ", ".join([f"{col} = ?" for col in post_data.keys()])
                where_clause = "file_name = ? AND draft = 0"

                query = f"""
                    UPDATE {category}
                    SET {set_clause}
                    WHERE {where_clause} 
                """

                draft_db.execute_query(query, values)

                write_netdoc(page_html, server_path, category, file_name, 0, db=db)

            else:
                print(f"something is very wrong with subcommand {subcommand}")
            
    except Exception as e:
        print(f"An error of Exception type {type(e).__name__} occurred: {e}")   

def db_single_updater(func):
    def wrapper(category, file_path, *args, **kwargs):
        file_name = remove_extension(file_path)
        DbConn(db_path).update_row(category, "file_name", file_name, dict([func(*args, **kwargs)]))
    return wrapper

@db_single_updater
def hide():
    return "hide", "0"

@db_single_updater
def unhide():
    return "hide", ""

@db_single_updater
def date():
    date_splash = input("What is the date of the page? ")
    return "date_splash", date_splash

@db_single_updater
def header():
    header = input(input_header_message)
    return "header", header

def main():
    if len(sys.argv) < 4:
        print("Usage: sculblog <command> <category> <postname> \n\t  commands: preview, draft, hide, unhide, date, header")
        sys.exit(1)
        
    command, category, file_path = sys.argv[1], sys.argv[2], sys.argv[3]
    
    if command == "preview":
        post_updater(category, file_path, "preview")
    elif command == "draft":
        post_updater(category, file_path, "draft")
    elif command == "update":
        post_updater(category, file_path, "update")

    elif command == "hide":
        hide(category, file_path)
    elif command == "unhide":
        unhide(category, file_path)

    elif command == "date":
        date(category, file_path)
    elif command == "header":
        header(category, file_path)

    else:
        print('Invalid command. Command must be "preview", "draft", "hide", "unhide", "date", or "header"')
        sys.exit(1)

if __name__ == "__main__":
    main()
