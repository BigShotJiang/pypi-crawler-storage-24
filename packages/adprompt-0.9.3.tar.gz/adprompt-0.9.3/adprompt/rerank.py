from typing import List

from openai import BaseModel as OpenAIBaseModel


class RerankScore(OpenAIBaseModel):
    index: int
    score: float


class RerankResponse(OpenAIBaseModel):
    id: str
    model: str
    data: List[RerankScore]
