"""
CPU Backend Wrapper for Crayon
================================

This module wraps the compiled C++ extension for CPU tokenization.
Falls back to pure Python implementation if extension is not available.
"""

import sys
import os
import importlib.util

def _load_cpu_extension():
    """Load the compiled CPU extension with platform-specific naming."""
    
    # Determine the extension filename based on platform
    if sys.platform == "win32":
        # Windows: look for .pyd files with version info
        search_dirs = [
            os.path.dirname(__file__),  # Current directory
            os.path.join(os.path.dirname(__file__), "compiled"),  # Compiled subdirectory
        ]
        
        ext_file = None
        for search_dir in search_dirs:
            ext_files = [f for f in os.listdir(search_dir) 
                       if f.startswith('crayon_cpu') and f.endswith('.pyd')]
            if ext_files:
                ext_file = ext_files[0]
                break
        
        if not ext_file:
            raise ImportError("No compiled CPU extension found (.pyd file)")
    else:
        # Linux/macOS: look for .so files
        search_dirs = [
            os.path.dirname(__file__),  # Current directory
            os.path.join(os.path.dirname(__file__), "compiled"),  # Compiled subdirectory
        ]
        
        ext_file = None
        for search_dir in search_dirs:
            if os.path.exists(search_dir):
                ext_files = [f for f in os.listdir(search_dir) 
                           if f.startswith('crayon_cpu') and f.endswith('.so')]
                if ext_files:
                    ext_file = ext_files[0]
                    break
        
        if not ext_file:
            raise ImportError("No compiled CPU extension found (.so file)")
    
    # Load the extension
    ext_path = os.path.join(search_dir, ext_file)
    spec = importlib.util.spec_from_file_location('crayon_cpu_ext', ext_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load extension from {ext_path}")
    
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

# Try to load the compiled extension
try:
    _cpu_ext = _load_cpu_extension()
    print("✓ Using compiled C++ extension for maximum performance")
except ImportError as e:
    print(f"⚠ Compiled extension not available: {e}")
    print("🔄 Falling back to pure Python implementation (slower but functional)")
    
    # Load pure Python fallback
    try:
        from . import crayon_cpu_fallback as _cpu_ext
        print("✓ Pure Python fallback loaded successfully")
    except ImportError as fallback_error:
        raise ImportError(
            f"Failed to load both compiled extension and pure Python fallback:\n"
            f"Extension error: {e}\n"
            f"Fallback error: {fallback_error}\n"
            "This suggests a corrupted installation. Try reinstalling with:\n"
            "  pip install --force-reinstall xerv-crayon"
        )

# Export the required functions
tokenize = _cpu_ext.tokenize
load_dat = _cpu_ext.load_dat

# Export hardware info if available
if hasattr(_cpu_ext, 'get_hardware_info'):
    get_hardware_info = _cpu_ext.get_hardware_info
else:
    def get_hardware_info():
        return "CPU Backend [Unknown]"

__all__ = ['tokenize', 'load_dat', 'get_hardware_info']
