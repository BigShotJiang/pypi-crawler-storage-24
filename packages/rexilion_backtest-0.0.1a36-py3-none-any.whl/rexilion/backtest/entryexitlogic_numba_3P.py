from numba import njit
import numpy as np
from rexilion.backtest.formula_numba import (
    rolling_mean,
    rolling_ema,
    rolling_wma,
    rolling_std,
    rolling_min,
    rolling_max
)

# Mode IDs
MODE_MR = 0
MODE_MR_0 = 1
MODE_0_SIDELINE = 2
MODE_MOMENTUM = 3
MODE_MOMENTUM_SIDELINE = 4
MODE_MOMENTUM_0 = 5
MODE_MR_SMAMA = 6
MODE_MR_EMAMA = 7
MODE_MR_WMAMA = 8
MODE_MOMENTUM_SMAMA = 9
MODE_MOMENTUM_EMAMA = 10
MODE_MOMENTUM_WMAMA = 11
MODE_MR_SMA = 12
MODE_MR_EMA = 13
MODE_MR_WMA = 14
MODE_MOMENTUM_SMA = 15
MODE_MOMENTUM_EMA = 16
MODE_MOMENTUM_WMA = 17
MODE_MOM_SMA_SIDELINE = 18
MODE_MOM_EMA_SIDELINE = 19
MODE_MOM_WMA_SIDELINE = 20
MODE_MM_MR = 21
MODE_MM_MR_MID = 22
MODE_MM_MOMENTUM = 23
MODE_MM_MOMENTUM_MID = 24
MODE_MM_MR_SMA = 25
MODE_MM_MR_EMA = 26
MODE_MM_MR_WMA = 27
MODE_MM_MOMENTUM_SMA = 28
MODE_MM_MOMENTUM_EMA = 29
MODE_MM_MOMENTUM_WMA = 30
MODE_BB_MR = 31
MODE_BB_MOMENTUM = 32
MODE_BB_MR_SMA = 33
MODE_BB_MOMENTUM_SMA = 34


# ──────────────────────────────────────────────────────────────────────────────
# Helpers: deterministic tie-break for dual-side entries
# Convention:
#   1  => only long hit
#  -1  => only short hit
#   2  => both hit (conflict)  → FLAT
#   0  => neutral (no hits)    → CARRY prev
#
# NOTE: thr_short is POSITIVE magnitude.
#       For negative-tail short triggers on a zero-centered signal, use -thr_short.
# ──────────────────────────────────────────────────────────────────────────────
@njit(cache=True)
def _entry_from_dual_mom(x, thr_long, thr_short):
    long_hit  = x > thr_long
    short_hit = x < -thr_short
    if long_hit and not short_hit:
        return 1
    if short_hit and not long_hit:
        return -1
    if long_hit and short_hit:
        return 2      # both-hit => flat
    return 0          # neutral => carry


@njit(cache=True)
def _entry_from_dual_mr(x, thr_long, thr_short):
    long_hit  = x < -thr_long
    short_hit = x >  thr_short
    if long_hit and not short_hit:
        return 1
    if short_hit and not long_hit:
        return -1
    if long_hit and short_hit:
        return 2      # both-hit => flat
    return 0          # neutral => carry


# ──────────────────────────────────────────────────────────────────────────────
# THRESHOLD FAMILY (single stream + single window)
# Uses ONE processed stream and ONE rolling window.
# - processed: single series used for both long/short checks
# - rolling_window: single baseline window for MA/min/max families
# Entries still use thr_long / thr_short separately (asymmetric OK).
# ──────────────────────────────────────────────────────────────────────────────
@njit(cache=True)
def entry_exit_threshold(
    processed: np.ndarray,
    rolling_window: int,
    thr_long: float,
    thr_short: float,
    mode_id: int,
    weightage: float = 1.0
) -> np.ndarray:
    n = processed.shape[0]
    warmup = rolling_window

    pos = np.empty(n, np.int8)
    for i in range(warmup):
        pos[i] = 0

    # feature flags
    use_sma = (mode_id == MODE_MR_SMAMA or mode_id == MODE_MOMENTUM_SMAMA
               or mode_id == MODE_MR_SMA or mode_id == MODE_MOMENTUM_SMA
               or mode_id == MODE_MM_MOMENTUM_SMA or mode_id == MODE_MM_MR_SMA
               or mode_id == MODE_MOM_SMA_SIDELINE
               or mode_id == MODE_BB_MR or mode_id == MODE_BB_MOMENTUM
               or mode_id == MODE_BB_MR_SMA or mode_id == MODE_BB_MOMENTUM_SMA)
    use_ema = (mode_id == MODE_MR_EMAMA or mode_id == MODE_MOMENTUM_EMAMA
               or mode_id == MODE_MR_EMA or mode_id == MODE_MOMENTUM_EMA
               or mode_id == MODE_MM_MOMENTUM_EMA or mode_id == MODE_MM_MR_EMA
               or mode_id == MODE_MOM_EMA_SIDELINE)
    use_wma = (mode_id == MODE_MR_WMAMA or mode_id == MODE_MOMENTUM_WMAMA
               or mode_id == MODE_MR_WMA or mode_id == MODE_MOMENTUM_WMA
               or mode_id == MODE_MM_MOMENTUM_WMA or mode_id == MODE_MM_MR_WMA
               or mode_id == MODE_MOM_WMA_SIDELINE)
    use_std = (mode_id == MODE_BB_MR or mode_id == MODE_BB_MOMENTUM
               or mode_id == MODE_BB_MR_SMA or mode_id == MODE_BB_MOMENTUM_SMA)
    use_minmax = (mode_id == MODE_MM_MOMENTUM or mode_id == MODE_MM_MOMENTUM_MID
                  or mode_id == MODE_MM_MOMENTUM_EMA or mode_id == MODE_MM_MOMENTUM_SMA
                  or mode_id == MODE_MM_MOMENTUM_WMA or mode_id == MODE_MM_MR
                  or mode_id == MODE_MM_MR_MID
                  or mode_id == MODE_MM_MR_EMA or mode_id == MODE_MM_MR_SMA
                  or mode_id == MODE_MM_MR_WMA)

    # baselines (single series, single window)
    if use_sma:
        sma = rolling_mean(processed, rolling_window)
    else:
        sma = np.empty(1, np.float64)

    if use_ema:
        ema = rolling_ema(processed, rolling_window)
    else:
        ema = np.empty(1, np.float64)

    if use_wma:
        wma = rolling_wma(processed, rolling_window)
    else:
        wma = np.empty(1, np.float64)

    if use_std:
        std = rolling_std(processed, rolling_window)
    else:
        std = np.empty(1, np.float64)

    if use_minmax:
        mn = rolling_min(processed, rolling_window)
        mx = rolling_max(processed, rolling_window)
    else:
        mn = mx = np.empty(1, np.float64)

    # main loop
    for i in range(warmup, n):
        x = processed[i]
        prev = pos[i - 1]

        # ── MR family
        if mode_id == MODE_MR:
            d = _entry_from_dual_mr(x, thr_long, thr_short)
            pos[i] = 1 if d == 1 else (-1 if d == -1 else (0 if d == 2 else prev))

        elif mode_id == MODE_MR_0:
            d = _entry_from_dual_mr(x, thr_long, thr_short)
            if d == 1:
                pos[i] = 1
            elif d == -1:
                pos[i] = -1
            else:
                if (prev == 1 and x >= 0.0) or (prev == -1 and x <= 0.0):
                    pos[i] = 0
                else:
                    pos[i] = 0 if d == 2 else prev

        elif mode_id == MODE_MR_SMA:
            d = _entry_from_dual_mr(x, thr_long, thr_short)
            if d == 1:
                pos[i] = 1
            elif d == -1:
                pos[i] = -1
            else:
                if (prev == 1 and x >= sma[i]) or (prev == -1 and x <= sma[i]):
                    pos[i] = 0
                else:
                    pos[i] = 0 if d == 2 else prev

        elif mode_id == MODE_MR_EMA:
            d = _entry_from_dual_mr(x, thr_long, thr_short)
            if d == 1:
                pos[i] = 1
            elif d == -1:
                pos[i] = -1
            else:
                if (prev == 1 and x >= ema[i]) or (prev == -1 and x <= ema[i]):
                    pos[i] = 0
                else:
                    pos[i] = 0 if d == 2 else prev

        elif mode_id == MODE_MR_WMA:
            d = _entry_from_dual_mr(x, thr_long, thr_short)
            if d == 1:
                pos[i] = 1
            elif d == -1:
                pos[i] = -1
            else:
                if (prev == 1 and x >= wma[i]) or (prev == -1 and x <= wma[i]):
                    pos[i] = 0
                else:
                    pos[i] = 0 if d == 2 else prev

        # 0_sideline (single stream version)
        elif mode_id == MODE_0_SIDELINE:
            if (x > 0.0) and (x < thr_long):
                pos[i] = 1
            elif (x < 0.0) and (x > -thr_short):
                pos[i] = -1
            elif (prev == 1 and x >= thr_short) or (prev == -1 and x <= -thr_long):
                pos[i] = 0
            else:
                pos[i] = prev

        # ── Momentum family
        elif mode_id == MODE_MOMENTUM:
            d = _entry_from_dual_mom(x, thr_long, thr_short)
            pos[i] = 1 if d == 1 else (-1 if d == -1 else (0 if d == 2 else prev))

        elif mode_id == MODE_MOMENTUM_0:
            d = _entry_from_dual_mom(x, thr_long, thr_short)
            if d == 1:
                pos[i] = 1
            elif d == -1:
                pos[i] = -1
            else:
                if (prev == 1 and x <= 0.0) or (prev == -1 and x >= 0.0):
                    pos[i] = 0
                else:
                    pos[i] = 0 if d == 2 else prev

        elif mode_id == MODE_MOMENTUM_SIDELINE:
            d = _entry_from_dual_mom(x, thr_long, thr_short)
            if d == 1:
                pos[i] = 1
            elif d == -1:
                pos[i] = -1
            else:
                if (prev == 1 and x <= thr_long) or (prev == -1 and x >= -thr_short):
                    pos[i] = 0
                else:
                    pos[i] = 0 if d == 2 else prev

        elif mode_id == MODE_MOMENTUM_SMA:
            d = _entry_from_dual_mom(x, thr_long, thr_short)
            if d == 1:
                pos[i] = 1
            elif d == -1:
                pos[i] = -1
            else:
                if (prev == 1 and x <= sma[i]) or (prev == -1 and x >= sma[i]):
                    pos[i] = 0
                else:
                    pos[i] = 0 if d == 2 else prev

        elif mode_id == MODE_MOMENTUM_EMA:
            d = _entry_from_dual_mom(x, thr_long, thr_short)
            if d == 1:
                pos[i] = 1
            elif d == -1:
                pos[i] = -1
            else:
                if (prev == 1 and x <= ema[i]) or (prev == -1 and x >= ema[i]):
                    pos[i] = 0
                else:
                    pos[i] = 0 if d == 2 else prev

        elif mode_id == MODE_MOMENTUM_WMA:
            d = _entry_from_dual_mom(x, thr_long, thr_short)
            if d == 1:
                pos[i] = 1
            elif d == -1:
                pos[i] = -1
            else:
                if (prev == 1 and x <= wma[i]) or (prev == -1 and x >= wma[i]):
                    pos[i] = 0
                else:
                    pos[i] = 0 if d == 2 else prev

        # ── % around mean (single mean, asymmetric thresholds)
        elif mode_id == MODE_MR_SMAMA:
            m = sma[i]
            upS = m * (1.0 + thr_short) if m > 0 else m * (1.0 - thr_short)
            loL = m * (1.0 - thr_long)  if m > 0 else m * (1.0 + thr_long)
            if x > upS:
                pos[i] = -1
            elif x < loL:
                pos[i] = 1
            else:
                pos[i] = prev

        elif mode_id == MODE_MOMENTUM_SMAMA:
            m = sma[i]
            upL = m * (1.0 + thr_long)  if m > 0 else m * (1.0 - thr_long)
            loS = m * (1.0 - thr_short) if m > 0 else m * (1.0 + thr_short)
            if x > upL:
                pos[i] = 1
            elif x < loS:
                pos[i] = -1
            else:
                pos[i] = prev

        elif mode_id == MODE_MR_EMAMA:
            m = ema[i]
            upS = m * (1.0 + thr_short) if m > 0 else m * (1.0 - thr_short)
            loL = m * (1.0 - thr_long)  if m > 0 else m * (1.0 + thr_long)
            if x > upS:
                pos[i] = -1
            elif x < loL:
                pos[i] = 1
            else:
                pos[i] = prev

        elif mode_id == MODE_MOMENTUM_EMAMA:
            m = ema[i]
            upL = m * (1.0 + thr_long)  if m > 0 else m * (1.0 - thr_long)
            loS = m * (1.0 - thr_short) if m > 0 else m * (1.0 + thr_short)
            if x > upL:
                pos[i] = 1
            elif x < loS:
                pos[i] = -1
            else:
                pos[i] = prev

        elif mode_id == MODE_MR_WMAMA:
            m = wma[i]
            upS = m * (1.0 + thr_short) if m > 0 else m * (1.0 - thr_short)
            loL = m * (1.0 - thr_long)  if m > 0 else m * (1.0 + thr_long)
            if x > upS:
                pos[i] = -1
            elif x < loL:
                pos[i] = 1
            else:
                pos[i] = prev

        elif mode_id == MODE_MOMENTUM_WMAMA:
            m = wma[i]
            upL = m * (1.0 + thr_long)  if m > 0 else m * (1.0 - thr_long)
            loS = m * (1.0 - thr_short) if m > 0 else m * (1.0 + thr_short)
            if x > upL:
                pos[i] = 1
            elif x < loS:
                pos[i] = -1
            else:
                pos[i] = prev

        # ── Bollinger Bands family (single mean + std, asymmetric multipliers)
        elif mode_id == MODE_BB_MR:
            mid = sma[i]
            band = std[i]
            upS = mid + band * thr_short
            loL = mid - band * thr_long
            if x > upS:
                pos[i] = -1
            elif x < loL:
                pos[i] = 1
            else:
                pos[i] = prev

        elif mode_id == MODE_BB_MOMENTUM:
            mid = sma[i]
            band = std[i]
            upL = mid + band * thr_long
            loS = mid - band * thr_short
            if x > upL:
                pos[i] = 1
            elif x < loS:
                pos[i] = -1
            else:
                pos[i] = prev

        elif mode_id == MODE_BB_MR_SMA:
            mid = sma[i]
            band = std[i]
            upS = mid + band * thr_short
            loL = mid - band * thr_long
            if x > upS:
                pos[i] = -1
            elif x < loL:
                pos[i] = 1
            elif (prev == 1 and x >= mid) or (prev == -1 and x <= mid):
                pos[i] = 0
            else:
                pos[i] = prev

        elif mode_id == MODE_BB_MOMENTUM_SMA:
            mid = sma[i]
            band = std[i]
            upL = mid + band * thr_long
            loS = mid - band * thr_short
            if x > upL:
                pos[i] = 1
            elif x < loS:
                pos[i] = -1
            elif (prev == 1 and x <= mid) or (prev == -1 and x >= mid):
                pos[i] = 0
            else:
                pos[i] = prev

        # ── Min/Max families (single min/max)
        elif mode_id == MODE_MM_MR:
            if x < mn[i] * thr_long:
                pos[i] = 1
            elif x > mx[i] * thr_short:
                pos[i] = -1
            else:
                pos[i] = prev

        elif mode_id == MODE_MM_MR_MID:
            mid = (mn[i] + mx[i]) / 2.0
            if x < mn[i] * thr_long:
                pos[i] = 1
            elif x > mx[i] * thr_short:
                pos[i] = -1
            elif (prev == 1 and x >= mid) or (prev == -1 and x <= mid):
                pos[i] = 0
            else:
                pos[i] = prev

        elif mode_id == MODE_MM_MR_SMA:
            if x < mn[i] * thr_long:
                pos[i] = 1
            elif x > mx[i] * thr_short:
                pos[i] = -1
            elif (prev == 1 and x >= sma[i]) or (prev == -1 and x <= sma[i]):
                pos[i] = 0
            else:
                pos[i] = prev

        elif mode_id == MODE_MM_MR_EMA:
            if x < mn[i] * thr_long:
                pos[i] = 1
            elif x > mx[i] * thr_short:
                pos[i] = -1
            elif (prev == 1 and x >= ema[i]) or (prev == -1 and x <= ema[i]):
                pos[i] = 0
            else:
                pos[i] = prev

        elif mode_id == MODE_MM_MR_WMA:
            if x < mn[i] * thr_long:
                pos[i] = 1
            elif x > mx[i] * thr_short:
                pos[i] = -1
            elif (prev == 1 and x >= wma[i]) or (prev == -1 and x <= wma[i]):
                pos[i] = 0
            else:
                pos[i] = prev

        elif mode_id == MODE_MM_MOMENTUM:
            if x > mx[i] * thr_long:
                pos[i] = 1
            elif x < mn[i] * thr_short:
                pos[i] = -1
            else:
                pos[i] = prev

        elif mode_id == MODE_MM_MOMENTUM_MID:
            mid = (mn[i] + mx[i]) / 2.0
            if x > mx[i] * thr_long:
                pos[i] = 1
            elif x < mn[i] * thr_short:
                pos[i] = -1
            elif (prev == 1 and x <= mid) or (prev == -1 and x >= mid):
                pos[i] = 0
            else:
                pos[i] = prev

        elif mode_id == MODE_MM_MOMENTUM_SMA:
            if x > mx[i] * thr_long:
                pos[i] = 1
            elif x < mn[i] * thr_short:
                pos[i] = -1
            elif (prev == 1 and x <= sma[i]) or (prev == -1 and x >= sma[i]):
                pos[i] = 0
            else:
                pos[i] = prev

        elif mode_id == MODE_MM_MOMENTUM_EMA:
            if x > mx[i] * thr_long:
                pos[i] = 1
            elif x < mn[i] * thr_short:
                pos[i] = -1
            elif (prev == 1 and x <= ema[i]) or (prev == -1 and x >= ema[i]):
                pos[i] = 0
            else:
                pos[i] = prev

        elif mode_id == MODE_MM_MOMENTUM_WMA:
            if x > mx[i] * thr_long:
                pos[i] = 1
            elif x < mn[i] * thr_short:
                pos[i] = -1
            elif (prev == 1 and x <= wma[i]) or (prev == -1 and x >= wma[i]):
                pos[i] = 0
            else:
                pos[i] = prev

        else:
            pos[i] = prev

    out = np.empty(n, np.float64)
    for i in range(n):
        out[i] = pos[i] * weightage
    return out