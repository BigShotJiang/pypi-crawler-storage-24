from setuptools import setup, find_packages

setup(
    name="delayed_response",
    version="0.1.0",
    description="Décorateur pour s'assurer qu'une fonction prend un temps minimum",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="R.Rodolphe",
    author_email="ton.email@example.com",
    url="https://github.com/rodolphe/delayed_response",  # optionnel
    packages=find_packages(),
    python_requires=">=3.12",
    install_requires=[],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)