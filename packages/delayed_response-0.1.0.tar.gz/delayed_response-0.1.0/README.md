# delayed_response

Décorateur Python pour garantir un temps minimum de réponse à une fonction.