import time
from functools import wraps

def ensure_min_response_time(seconds: float = 9.0):
    """
    Décorateur pour s'assurer qu'une fonction prend au moins `seconds` secondes à s'exécuter.

    Usage:
        @ensure_min_response_time(9)
        def my_function(...):
            ...
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            result = func(*args, **kwargs)
            elapsed = time.time() - start_time
            if elapsed < seconds:
                time.sleep(seconds - elapsed)
            return result
        return wrapper
    return decorator