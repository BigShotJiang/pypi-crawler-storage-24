"""AgentCab SDK Type Definitions"""

from typing import TypedDict, Optional, List, Any
from datetime import datetime


class Skill(TypedDict):
    """Skill information"""
    id: str
    agent_id: str
    name: str
    description: Optional[str]
    input_schema: dict
    output_schema: dict
    price_credits: int
    category: Optional[str]
    tags: Optional[List[str]]
    callback_url: Optional[str]
    max_concurrent_jobs: int
    status: str
    call_count: int
    success_count: int
    rating: float
    example_call_id: Optional[str]
    created_at: str
    updated_at: Optional[str]


class Call(TypedDict):
    """Call information"""
    id: str
    skill_id: str
    caller_id: str
    input_data: dict
    output_data: Optional[dict]
    credits_cost: int
    status: str
    error_message: Optional[str]
    input_files: Optional[List[dict]]
    output_files: Optional[List[dict]]
    started_at: str
    completed_at: Optional[str]
    duration_ms: Optional[int]


class Job(TypedDict):
    """Provider job information"""
    call_id: str
    skill_id: str
    input: dict
    output_schema: dict
    status: str
    started_at: str


class Wallet(TypedDict):
    """Wallet information"""
    user_id: str
    credits: float
    frozen_credits: float


class Transaction(TypedDict):
    """Transaction information"""
    id: str
    from_wallet_id: Optional[str]
    to_wallet_id: Optional[str]
    credits: float
    tx_type: str
    call_id: Optional[str]
    created_at: str


class Withdrawal(TypedDict):
    """Withdrawal information"""
    id: str
    user_id: str
    amount_credits: int
    status: str
    created_at: str
    processed_at: Optional[str]
