"""CUDA-specific kernel implementations.

Provides GPU kernels for CUDA devices:
- CUDAFlashAttention2Kernel: Flash Attention 2 kernel-injection wrapper.
- SelectiveScanKernel: Mamba SSM selective scan (optimized Triton path on CUDA,
  PyTorch CPU fallback otherwise).
- W4A16TritonDequantKernel: W4A16 INT4 weight dequantization (Triton GPU path,
  PyTorch CPU fallback).
- CUDAW4A16LinearKernel: W4A16 linear layer with on-the-fly Triton dequant.
"""

from __future__ import annotations

from sagellm_backend.kernels.cuda.flash_attention import (
    CUDAFlashAttention2Kernel,
    is_flash_attention_2_available,
)
from sagellm_backend.kernels.cuda.ssm import SelectiveScanKernel
from sagellm_backend.kernels.cuda.w4a16_dequant import (
    CUDAW4A16LinearKernel,
    W4A16TritonDequantKernel,
    is_triton_available,
)

__all__ = [
    "CUDAFlashAttention2Kernel",
    "is_flash_attention_2_available",
    "SelectiveScanKernel",
    "W4A16TritonDequantKernel",
    "CUDAW4A16LinearKernel",
    "is_triton_available",
]
