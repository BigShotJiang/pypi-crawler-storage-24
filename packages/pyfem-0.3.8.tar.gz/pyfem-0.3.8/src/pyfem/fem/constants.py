# -*- coding: utf-8 -*-
"""
定义常数
"""
DTYPE = 'float64'

IS_DEBUG = False

LOGO = r"""
                 ____             
    ____  __  __/ __/__  ____ ___ 
   / __ \/ / / / /_/ _ \/ __ `__ \
  / /_/ / /_/ / __/  __/ / / / / /
 / .___/\__, /_/  \___/_/ /_/ /_/ 
/_/    /____/                     
"""

# IS_MPI = True
IS_MPI = False

# IS_PETSC = True
IS_PETSC = False
