import ast
import re
from enum import StrEnum
from pathlib import Path
from typing import cast

import pytest

import vcti.enum
from vcti.enum import (
    EnumValueCamelCase,
    EnumValueCapitalizedPhrase,
    EnumValueLowerCase,
    EnumValuePascalCase,
    EnumValueSameAsName,
    EnumValueSpaceSeparatedLower,
    auto_enum_value,
    create_enum_class,
)
from vcti.enum.value_generated_enums import (
    _camelcase,
    _humanize_lower,
    _pascalcase,
    _titleize,
    _words,
)


@pytest.mark.parametrize(
    "enum_class,expected_values",
    [
        (EnumValueSameAsName, ["FIRST_VALUE", "SECOND_VALUE"]),
        (EnumValueLowerCase, ["first_value", "second_value"]),
        (EnumValueCamelCase, ["firstValue", "secondValue"]),
        (EnumValuePascalCase, ["FirstValue", "SecondValue"]),
        (EnumValueCapitalizedPhrase, ["First Value", "Second Value"]),
        (EnumValueSpaceSeparatedLower, ["first value", "second value"]),
    ],
)
def test_enum_value_generators(enum_class, expected_values):
    """Test all enum value generators with parametrized inputs."""

    class ExampleEnum(enum_class):  # type: ignore[misc]
        FIRST_VALUE = auto_enum_value()
        SECOND_VALUE = auto_enum_value()

    # Verify that enum members have string values, not int values
    # Cast to Enum to help type checker understand these are enum members
    first_member = cast(StrEnum, ExampleEnum.FIRST_VALUE)
    second_member = cast(StrEnum, ExampleEnum.SECOND_VALUE)

    assert isinstance(first_member.value, str)
    assert isinstance(second_member.value, str)

    assert first_member.value == expected_values[0]
    assert second_member.value == expected_values[1]


@pytest.mark.parametrize(
    "enum_class,expected_doc_part",
    [
        (EnumValueSameAsName, "the same as its name"),
        (EnumValueLowerCase, "its name converted to lower case"),
        (EnumValuePascalCase, "its name converted to PascalCase"),
    ],
)
def test_enum_documentation(enum_class, expected_doc_part):
    """Test that enum classes have proper documentation."""
    assert expected_doc_part in enum_class.__doc__


def test_auto_enum_value_usage():
    """Test that auto_enum_value works correctly with enum classes."""

    class TestEnum(EnumValueLowerCase):
        TEST_MEMBER = auto_enum_value()

    assert isinstance(TestEnum.TEST_MEMBER.value, str)
    assert TestEnum.TEST_MEMBER.value == "test_member"


def test_enum_member_count():
    """Test that enum members are properly counted."""

    class TestEnum(EnumValuePascalCase):
        ONE = auto_enum_value()
        TWO = auto_enum_value()
        THREE = auto_enum_value()

    assert len(list(TestEnum)) == 3
    assert TestEnum.ONE.value == "One"
    assert TestEnum.TWO.value == "Two"
    assert TestEnum.THREE.value == "Three"


def test_create_enum_class_custom_generator():
    """create_enum_class produces an enum class with any custom generator."""
    MyEnum = create_enum_class(
        "MyEnum", lambda name: name.replace("_", "-").upper(), "custom", "SOME-TAG"
    )

    class Tags(MyEnum):  # type: ignore[misc]
        SOME_TAG = auto_enum_value()

    assert cast(StrEnum, Tags.SOME_TAG).value == "SOME-TAG"


def test_enum_members_are_strings():
    """Enum members are str subclass instances."""

    class Status(EnumValueLowerCase):
        ACTIVE = auto_enum_value()
        INACTIVE = auto_enum_value()

    assert isinstance(Status.ACTIVE, str)
    assert Status.ACTIVE == "active"


def test_enum_class_name():
    """Factory-created classes have correct __name__ and __qualname__."""
    assert EnumValueLowerCase.__name__ == "EnumValueLowerCase"
    assert EnumValueLowerCase.__qualname__ == "EnumValueLowerCase"
    assert EnumValuePascalCase.__name__ == "EnumValuePascalCase"


# ── Naming helper edge cases ──────────────────────────────


@pytest.mark.parametrize(
    "name,expected",
    [
        ("", []),
        ("SINGLE", ["single"]),
        ("A_B_C", ["a", "b", "c"]),
    ],
)
def test_words_edge_cases(name, expected):
    assert _words(name) == expected


@pytest.mark.parametrize(
    "func,input_name,expected",
    [
        (_camelcase, "", ""),
        (_pascalcase, "", ""),
        (_titleize, "", ""),
        (_humanize_lower, "", ""),
        (_camelcase, "SINGLE", "single"),
        (_pascalcase, "SINGLE", "Single"),
        (_titleize, "SINGLE", "Single"),
        (_humanize_lower, "SINGLE", "single"),
    ],
)
def test_naming_helpers_edge_cases(func, input_name, expected):
    assert func(input_name) == expected


# ── Stub drift test ───────────────────────────────────────


def test_pyi_stub_declares_all_exports():
    """The .pyi stub must declare every name in __all__ from the .py module."""
    import vcti.enum.value_generated_enums as mod

    stub_path = Path(mod.__file__).with_suffix(".pyi")
    assert stub_path.exists(), f"Stub file not found: {stub_path}"

    tree = ast.parse(stub_path.read_text())
    stub_names = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            stub_names.add(node.name)
        elif isinstance(node, ast.FunctionDef):
            stub_names.add(node.name)
        elif isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == "__all__":
                    if isinstance(node.value, ast.List):
                        for elt in node.value.elts:
                            if isinstance(elt, ast.Constant):
                                stub_names.add(elt.value)

    for name in mod.__all__:
        assert name in stub_names, f"'{name}' is in __all__ but missing from the .pyi stub"


# ── Package-level re-exports ─────────────────────────────


def test_package_reexports():
    """All public symbols are importable from vcti.enum directly."""
    import vcti.enum as pkg

    for name in [
        "auto_enum_value",
        "create_enum_class",
        "EnumValueSameAsName",
        "EnumValueLowerCase",
        "EnumValueCamelCase",
        "EnumValuePascalCase",
        "EnumValueCapitalizedPhrase",
        "EnumValueSpaceSeparatedLower",
        "EnumCoder",
        "setup_enum_for_pydantic",
        "enum_for_pydantic",
        "get_enum_field_description",
        "__version__",
    ]:
        assert hasattr(pkg, name), f"vcti.enum does not export '{name}'"


class TestVersion:
    def test_version_exists(self):
        assert hasattr(vcti.enum, "__version__")

    def test_version_is_valid_semver(self):
        assert re.match(r"^\d+\.\d+\.\d+", vcti.enum.__version__)
