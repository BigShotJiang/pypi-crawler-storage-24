import pytest
from pydantic import BaseModel, Field, ValidationError

from vcti.enum import (
    EnumValueLowerCase,
    auto_enum_value,
    enum_for_pydantic,
    get_enum_field_description,
    setup_enum_for_pydantic,
)


class TestSetupEnumForPydantic:
    """Tests for setup_enum_for_pydantic."""

    def test_attaches_coder(self):
        class Color(EnumValueLowerCase):
            RED = auto_enum_value()
            GREEN = auto_enum_value()

        setup_enum_for_pydantic(Color)
        assert hasattr(Color, "CODER")

    def test_default_value_first_member(self):
        class Status(EnumValueLowerCase):
            PENDING = auto_enum_value()
            ACTIVE = auto_enum_value()

        setup_enum_for_pydantic(Status)
        assert Status.DEFAULT_VALUE == "pending"

    def test_default_member_specified(self):
        class Status(EnumValueLowerCase):
            PENDING = auto_enum_value()
            ACTIVE = auto_enum_value()

        setup_enum_for_pydantic(Status, default_member="ACTIVE")
        assert Status.DEFAULT_VALUE == "active"

    def test_list_and_tuple_attached(self):
        class Format(EnumValueLowerCase):
            JSON = auto_enum_value()
            CSV = auto_enum_value()

        setup_enum_for_pydantic(Format)
        assert Format.LIST == ["json", "csv"]
        assert Format.TUPLE == ("json", "csv")

    def test_literal_attached(self):
        class Format(EnumValueLowerCase):
            JSON = auto_enum_value()
            CSV = auto_enum_value()

        setup_enum_for_pydantic(Format)
        assert hasattr(Format, "LITERAL")

    def test_custom_value_generator(self):
        class Format(EnumValueLowerCase):
            JSON = auto_enum_value()
            CSV = auto_enum_value()

        setup_enum_for_pydantic(Format, value_generator=lambda e: e.value.upper())
        assert Format.LIST == ["JSON", "CSV"]

    def test_returns_enum_coder(self):
        class Kind(EnumValueLowerCase):
            A = auto_enum_value()

        from vcti.enum import EnumCoder

        coder = setup_enum_for_pydantic(Kind)
        assert isinstance(coder, EnumCoder)


class TestEnumForPydanticDecorator:
    """Tests for enum_for_pydantic decorator."""

    def test_decorator_sets_default(self):
        @enum_for_pydantic(default="CSV")
        class Format(EnumValueLowerCase):
            JSON = auto_enum_value()
            CSV = auto_enum_value()

        assert Format.DEFAULT_VALUE == "csv"

    def test_decorator_no_default_uses_first(self):
        @enum_for_pydantic()
        class Format(EnumValueLowerCase):
            JSON = auto_enum_value()
            CSV = auto_enum_value()

        assert Format.DEFAULT_VALUE == "json"

    def test_decorator_returns_enum_class(self):
        @enum_for_pydantic()
        class Kind(EnumValueLowerCase):
            A = auto_enum_value()

        assert issubclass(Kind, EnumValueLowerCase)

    def test_decorator_custom_value_generator(self):
        @enum_for_pydantic(value_generator=lambda e: e.value.upper())
        class Kind(EnumValueLowerCase):
            alpha = auto_enum_value()

        assert Kind.LIST == ["ALPHA"]


class TestGetEnumFieldDescription:
    """Tests for get_enum_field_description."""

    def test_includes_values_and_default(self):
        @enum_for_pydantic(default="JSON")
        class Format(EnumValueLowerCase):
            JSON = auto_enum_value()
            CSV = auto_enum_value()

        desc = get_enum_field_description(Format)
        assert "json" in desc
        assert "csv" in desc
        assert "Default: json" in desc

    def test_exclude_default(self):
        @enum_for_pydantic(default="JSON")
        class Format(EnumValueLowerCase):
            JSON = auto_enum_value()
            CSV = auto_enum_value()

        desc = get_enum_field_description(Format, include_default=False)
        assert "Default" not in desc
        assert "json" in desc

    def test_without_setup(self):
        """Works on plain enum using member values directly."""

        class Plain(EnumValueLowerCase):
            A = auto_enum_value()
            B = auto_enum_value()

        desc = get_enum_field_description(Plain, include_default=False)
        assert "a" in desc
        assert "b" in desc

    def test_no_default_value_omits_default(self):
        """When no DEFAULT_VALUE attribute exists, default is excluded."""

        class Plain(EnumValueLowerCase):
            X = auto_enum_value()
            Y = auto_enum_value()

        desc = get_enum_field_description(Plain)
        assert "Default" not in desc
        assert "x" in desc
        assert "y" in desc


class TestPydanticModelIntegration:
    """End-to-end tests with actual Pydantic models."""

    def test_model_with_decorated_enum(self):
        """A Pydantic model accepts valid enum string values and applies defaults."""

        @enum_for_pydantic(default="JSON")
        class FileFormat(EnumValueLowerCase):
            JSON = auto_enum_value()
            CSV = auto_enum_value()
            PARQUET = auto_enum_value()

        class ExportConfig(BaseModel):
            format: FileFormat = Field(default=FileFormat.DEFAULT_VALUE)

        # Default applies
        config = ExportConfig()
        assert config.format == "json"

        # Accepts valid enum member
        config = ExportConfig(format=FileFormat.CSV)
        assert config.format == "csv"

    def test_model_rejects_invalid_value(self):
        """A Pydantic model rejects values not in the enum."""

        @enum_for_pydantic()
        class Status(EnumValueLowerCase):
            ACTIVE = auto_enum_value()
            INACTIVE = auto_enum_value()

        class UserConfig(BaseModel):
            status: Status

        with pytest.raises(ValidationError):
            UserConfig(status="deleted")

    def test_model_json_round_trip(self):
        """Enum values survive JSON serialization and deserialization."""

        @enum_for_pydantic(default="CSV")
        class FileFormat(EnumValueLowerCase):
            JSON = auto_enum_value()
            CSV = auto_enum_value()

        class ExportConfig(BaseModel):
            format: FileFormat = Field(default=FileFormat.DEFAULT_VALUE)

        original = ExportConfig(format=FileFormat.JSON)
        json_str = original.model_dump_json()
        restored = ExportConfig.model_validate_json(json_str)
        assert restored.format == original.format
