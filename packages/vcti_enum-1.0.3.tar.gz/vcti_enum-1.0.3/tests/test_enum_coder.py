from enum import Enum

import pytest

from vcti.enum import EnumCoder


class TestEnumCoder:
    class SampleEnum(Enum):
        FIRST_VALUE = 1
        SECOND_VALUE = 2

    def test_basic_serialization(self):
        enum_coder = EnumCoder(self.SampleEnum)
        assert enum_coder.encode(self.SampleEnum.FIRST_VALUE) == "FIRST_VALUE"
        assert enum_coder.decode("SECOND_VALUE") == self.SampleEnum.SECOND_VALUE

    def test_custom_mapping(self):
        enum_coder = EnumCoder(
            self.SampleEnum,
            value_generator=lambda enum_var: enum_var.name.lower().replace("_", "-"),
        )
        assert enum_coder.encode(self.SampleEnum.FIRST_VALUE) == "first-value"
        assert enum_coder.decode("second-value") == self.SampleEnum.SECOND_VALUE

    def test_default_value(self):
        default_value = self.SampleEnum.SECOND_VALUE
        enum_coder = EnumCoder(self.SampleEnum, default=default_value)
        assert enum_coder.default == enum_coder.encode(default_value)

    def test_no_default(self):
        enum_coder = EnumCoder(self.SampleEnum)
        assert enum_coder.default is None

    def test_illegal_value_exception(self):
        """Test that ValueError is raised when an illegal value is passed to decoder."""
        with pytest.raises(ValueError):
            enum_coder = EnumCoder(self.SampleEnum)
            enum_coder.decode("illegal_value")

    def test_encode_invalid_member(self):
        """Test that ValueError is raised when encoding a member from a different enum."""

        class OtherEnum(Enum):
            X = 1

        enum_coder = EnumCoder(self.SampleEnum)
        with pytest.raises(ValueError, match="is not a member of"):
            enum_coder.encode(OtherEnum.X)

    def test_string_properties(self):
        enum_coder = EnumCoder(self.SampleEnum, default=self.SampleEnum.SECOND_VALUE)
        assert enum_coder.tuple == ("FIRST_VALUE", "SECOND_VALUE")
        assert enum_coder.list == ["FIRST_VALUE", "SECOND_VALUE"]
        assert enum_coder.default == "SECOND_VALUE"

    def test_literal_property(self):
        enum_coder = EnumCoder(self.SampleEnum)
        literal = enum_coder.Literal
        assert literal is not None

    def test_get_mapping_info(self):
        enum_coder = EnumCoder(
            self.SampleEnum,
            value_generator=lambda e: e.name.lower(),
            default=self.SampleEnum.FIRST_VALUE,
        )
        info = enum_coder.get_mapping_info()
        assert info["enum_class"] == "SampleEnum"
        assert info["values"] == ("first_value", "second_value")
        assert info["default"] == "first_value"
        assert info["mapping"] == {
            "FIRST_VALUE": "first_value",
            "SECOND_VALUE": "second_value",
        }

    def test_duplicate_string_values_raises(self):
        """value_generator that maps multiple members to the same string should fail."""
        with pytest.raises(ValueError, match="duplicate string values"):
            EnumCoder(
                self.SampleEnum,
                value_generator=lambda e: "same",
            )

    def test_falsy_default_is_preserved(self):
        """A default member whose generated string is falsy (empty string) still works."""

        class FalsyEnum(Enum):
            EMPTY = 0
            OTHER = 1

        coder = EnumCoder(
            FalsyEnum,
            value_generator=lambda e: "" if e == FalsyEnum.EMPTY else "other",
            default=FalsyEnum.EMPTY,
        )
        assert coder.default == ""

    def test_repr_with_default(self):
        coder = EnumCoder(self.SampleEnum, default=self.SampleEnum.FIRST_VALUE)
        assert repr(coder) == "EnumCoder(SampleEnum, default='FIRST_VALUE')"

    def test_repr_without_default(self):
        coder = EnumCoder(self.SampleEnum)
        assert repr(coder) == "EnumCoder(SampleEnum)"
