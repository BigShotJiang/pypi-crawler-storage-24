"""Type stubs for value_generated_enums.py"""

from collections.abc import Callable
from enum import StrEnum
from enum import auto as auto_enum_value

__all__ = [
    "auto_enum_value",
    "create_enum_class",
    "EnumValueSameAsName",
    "EnumValueLowerCase",
    "EnumValueCamelCase",
    "EnumValuePascalCase",
    "EnumValueCapitalizedPhrase",
    "EnumValueSpaceSeparatedLower",
]

def create_enum_class(
    class_name: str,
    value_generator: Callable[[str], str],
    description: str,
    example_value: str,
) -> type[StrEnum]: ...

class EnumValueSameAsName(StrEnum):
    """Enum where the value of each member is the same as its name."""

    ...

class EnumValueLowerCase(StrEnum):
    """Enum where the value of each member is its name converted to lower case."""

    ...

class EnumValueCamelCase(StrEnum):
    """Enum where the value of each member is its name converted to camelCase."""

    ...

class EnumValuePascalCase(StrEnum):
    """Enum where the value of each member is its name converted to PascalCase."""

    ...

class EnumValueCapitalizedPhrase(StrEnum):
    """Enum where the value of each member is its name converted to a Capitalized Phrase."""

    ...

class EnumValueSpaceSeparatedLower(StrEnum):
    """Enum: value is the name as a space separated lowercase phrase."""

    ...
