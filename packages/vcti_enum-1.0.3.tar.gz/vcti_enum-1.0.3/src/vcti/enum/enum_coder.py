# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Enhanced Enum utilities for flexible serialization with configurable string mappings."""

from collections.abc import Callable
from enum import Enum
from typing import Any


class EnumCoder[E: Enum]:
    """
    Provides flexible serialization/deserialization for Enums with configurable string mappings.

    Example:
        class Color(Enum):
            RED = 1
            GREEN = 2

        # Create serializer with lowercase mapping
        color_coder = EnumCoder(
            Color,
            value_generator=lambda enum_var: enum_var.name.lower(),
            default=Color.RED
        )

        # Serialize/Encode
        color_coder.encode(Color.RED)  # "red"

        # Deserialize/Decode
        color_coder.decode("green")  # Color.GREEN
    """

    def __init__(
        self,
        enum_class: type[E],
        value_generator: Callable[[E], str] = lambda enum_var: enum_var.name,
        default: E | None = None,
    ):
        """
        Initialize the serializer.

        Args:
            enum_class: The Enum class to serialize
            value_generator: Function that converts enums to string values
            default: Default enum value for this serializer
        """
        self.enum_class: type[E] = enum_class
        self.value_generator: Callable[[E], str] = value_generator

        # Generate mappings
        self._enum_to_string: dict[E, str] = {
            member: value_generator(member) for member in enum_class
        }
        self._string_to_enum: dict[str, E] = {v: k for k, v in self._enum_to_string.items()}

        # Detect collisions in the reverse mapping
        if len(self._string_to_enum) != len(self._enum_to_string):
            from collections import Counter

            counts = Counter(self._enum_to_string.values())
            duplicates = {v for v, c in counts.items() if c > 1}
            raise ValueError(f"value_generator produced duplicate string values: {duplicates}")

        # Pre-compute stringified default
        self._default = self._enum_to_string.get(default) if default is not None else None

    def __repr__(self) -> str:
        default_part = f", default={self._default!r}" if self._default is not None else ""
        return f"EnumCoder({self.enum_class.__name__}{default_part})"

    @property
    def default(self) -> str | None:
        """The string representation of the default enum value (None if no default set)."""
        return self._default

    @property
    def tuple(self) -> tuple[str, ...]:
        """All possible string values for this enum."""
        return tuple(self._enum_to_string.values())

    @property
    def list(self) -> list[str]:
        """List of all possible string values."""
        return list(self.tuple)

    @property
    def Literal(self) -> Any:
        """
        Literal type containing all possible string values.

        Note: This creates a Literal type dynamically at runtime for use in type annotations.
        Due to Python's type system limitations, the return type is Any.

        Example:
            LogLevelStr = LogLevelCoder.Literal  # Get the Literal type
            my_level: LogLevelStr = "info"  # Type-checked value
        """
        from typing import Literal

        return Literal[*self.tuple]  # type: ignore

    def encode(self, enum_value: E) -> str:
        """Convert enum to its string representation.

        Args:
            enum_value: The enum member to encode.

        Returns:
            String representation of the enum value.

        Raises:
            ValueError: If enum_value is not a member of the configured enum class.
        """
        try:
            return self._enum_to_string[enum_value]
        except KeyError:
            raise ValueError(
                f"'{enum_value}' is not a member of {self.enum_class.__name__}. "
                f"Valid members: {tuple(m.name for m in self.enum_class)}"
            ) from None

    def decode(self, string_value: str) -> E:
        """Convert string back to enum value.

        Args:
            string_value: The string to decode into an enum member.

        Returns:
            The enum member corresponding to string_value.

        Raises:
            ValueError: If string_value doesn't match any enum value.
        """
        try:
            return self._string_to_enum[string_value]
        except KeyError:
            raise ValueError(
                f"'{string_value}' is not a valid representation. Valid values: {self.tuple}"
            ) from None

    def get_mapping_info(self) -> dict[str, Any]:
        """Get complete mapping information as a dictionary.

        Returns:
            Dictionary with keys: enum_class, values, default, mapping.
        """
        return {
            "enum_class": self.enum_class.__name__,
            "values": self.tuple,
            "default": self.default,
            "mapping": {e.name: self.encode(e) for e in self.enum_class},
        }


__all__ = [
    "EnumCoder",
]
