# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""vcti.enum package."""

from importlib.metadata import version

from .enum_coder import EnumCoder
from .enum_pydantic_helpers import (
    enum_for_pydantic,
    get_enum_field_description,
    setup_enum_for_pydantic,
)
from .value_generated_enums import (
    EnumValueCamelCase,
    EnumValueCapitalizedPhrase,
    EnumValueLowerCase,
    EnumValuePascalCase,
    EnumValueSameAsName,
    EnumValueSpaceSeparatedLower,
    auto_enum_value,
    create_enum_class,
)

__version__ = version("vcti-enum")

__all__ = [
    "__version__",
    "auto_enum_value",
    "create_enum_class",
    "EnumValueSameAsName",
    "EnumValueLowerCase",
    "EnumValueCamelCase",
    "EnumValuePascalCase",
    "EnumValueCapitalizedPhrase",
    "EnumValueSpaceSeparatedLower",
    "EnumCoder",
    "setup_enum_for_pydantic",
    "enum_for_pydantic",
    "get_enum_field_description",
]
