# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Enum base classes with automatic value generation from naming conventions.

Each class is created by a factory that binds a naming-convention function
(e.g. ``str.lower``, ``camelcase``) to ``_generate_next_value_``.
Subclasses use ``auto_enum_value()`` to generate member values automatically::

    from vcti.enum import EnumValueLowerCase, auto_enum_value

    class FileFormat(EnumValueLowerCase):
        JSON = auto_enum_value()    # value: "json"
        CSV  = auto_enum_value()    # value: "csv"

Static analysis and IDE support (autocomplete, hover, go-to-definition) are
provided by the companion stub file ``value_generated_enums.pyi``.
"""

from collections.abc import Callable
from enum import StrEnum
from enum import auto as auto_enum_value

# ════════════════════════════════════════════════════════════
# Naming-convention helpers (replace case-converter / inflection)
#
# Input is always UPPER_SNAKE_CASE enum member names, so a simple
# split-on-underscore approach covers all cases without third-party deps.
# ════════════════════════════════════════════════════════════


def _words(name: str) -> list[str]:
    """Split an UPPER_SNAKE_CASE name into lowercase words."""
    return [w.lower() for w in name.split("_") if w]


def _camelcase(name: str) -> str:
    """FIRST_VALUE → firstValue"""
    words = _words(name)
    return words[0] + "".join(w.capitalize() for w in words[1:]) if words else ""


def _pascalcase(name: str) -> str:
    """FIRST_VALUE → FirstValue"""
    return "".join(w.capitalize() for w in _words(name))


def _titleize(name: str) -> str:
    """FIRST_VALUE → First Value"""
    return " ".join(w.capitalize() for w in _words(name))


def _humanize_lower(name: str) -> str:
    """FIRST_VALUE → first value"""
    return " ".join(_words(name))


def create_enum_class(
    class_name: str,
    value_generator: Callable[[str], str],
    description: str,
    example_value: str,
) -> type[StrEnum]:
    """
    Factory function to create an Enum class with a custom value generator.

    Args:
        class_name: Name assigned to the created class (``__name__`` / ``__qualname__``).
        value_generator: A function that takes the enum member name and returns the desired value.
        description: Human-readable description of the naming convention (used in the docstring).
        example_value: Example output shown in the docstring.

    Returns:
        An Enum class with the custom value generator.
    """

    class GeneratedEnum(StrEnum):
        @staticmethod
        def _generate_next_value_(name: str, start: int, count: int, last_values: list) -> str:
            return value_generator(name)

    GeneratedEnum.__name__ = class_name
    GeneratedEnum.__qualname__ = class_name
    GeneratedEnum.__doc__ = (
        f"Enum where the value of each member is {description}.\n"
        f"\n"
        f"Example::\n"
        f"\n"
        f"    class ExampleEnum({class_name}):\n"
        f"        FIRST_VALUE = auto_enum_value()\n"
        f"        SECOND_VALUE = auto_enum_value()\n"
        f"\n"
        f"    >>> ExampleEnum.FIRST_VALUE.value\n"
        f"    '{example_value}'\n"
    )
    return GeneratedEnum


# ════════════════════════════════════════════════════════════
# Enum classes — one per naming convention
# ════════════════════════════════════════════════════════════

EnumValueSameAsName = create_enum_class(
    "EnumValueSameAsName",
    lambda name: name,
    "the same as its name",
    "FIRST_VALUE",
)
EnumValueLowerCase = create_enum_class(
    "EnumValueLowerCase",
    lambda name: name.lower(),
    "its name converted to lower case",
    "first_value",
)
EnumValueCamelCase = create_enum_class(
    "EnumValueCamelCase",
    _camelcase,
    "its name converted to camelCase",
    "firstValue",
)
EnumValuePascalCase = create_enum_class(
    "EnumValuePascalCase",
    _pascalcase,
    "its name converted to PascalCase",
    "FirstValue",
)
EnumValueCapitalizedPhrase = create_enum_class(
    "EnumValueCapitalizedPhrase",
    _titleize,
    "its name converted to a Capitalized Phrase",
    "First Value",
)
EnumValueSpaceSeparatedLower = create_enum_class(
    "EnumValueSpaceSeparatedLower",
    _humanize_lower,
    "its name converted to a space separated lowercase phrase",
    "first value",
)


__all__ = [
    "auto_enum_value",
    "create_enum_class",
    "EnumValueSameAsName",
    "EnumValueLowerCase",
    "EnumValueCamelCase",
    "EnumValuePascalCase",
    "EnumValueCapitalizedPhrase",
    "EnumValueSpaceSeparatedLower",
]
