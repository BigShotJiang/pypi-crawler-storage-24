# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Pydantic integration helpers for EnumCoder.

This module provides utilities to seamlessly integrate EnumCoder with Pydantic models,
making it easy to use enums with custom string representations.

Example:
    >>> from vcti.enum import EnumValueLowerCase, auto_enum_value, setup_enum_for_pydantic
    >>>
    >>> class FileFormat(EnumValueLowerCase):
    ...     JSON = auto_enum_value()
    ...     CSV = auto_enum_value()
    >>>
    >>> # Setup for Pydantic usage
    >>> setup_enum_for_pydantic(
    ...     FileFormat,
    ...     value_generator=lambda e: e.value,
    ...     default_member='JSON'
    ... )
    >>>
    >>> # Now you can use in Pydantic:
    >>> class MyModel(BaseModel):
    ...     format: FileFormat.LITERAL = Field(default=FileFormat.DEFAULT_VALUE)
"""

from collections.abc import Callable
from enum import Enum
from typing import Any

from .enum_coder import EnumCoder


def setup_enum_for_pydantic[E: Enum](
    enum_class: type[E],
    value_generator: Callable[[E], str] | None = None,
    default_member: str | None = None,
) -> EnumCoder[E]:
    """Setup an enum class for use in Pydantic models.

    This function creates an EnumCoder and attaches it and its properties
    to the enum class, making it easy to use in Pydantic Field definitions.

    Adds these attributes to the enum class:
    - CODER: The EnumCoder instance
    - DEFAULT_VALUE: Default string value
    - LIST: List of all string values
    - TUPLE: Tuple of all string values
    - LITERAL: Literal type of all values

    Args:
        enum_class: The enum class to setup
        value_generator: Function to convert enum to string (default: uses enum.value)
        default_member: Name of enum member to use as default

    Returns:
        The EnumCoder instance (also attached to enum_class.CODER)

    Example:
        >>> class Status(EnumValueLowerCase):
        ...     PENDING = auto_enum_value()
        ...     ACTIVE = auto_enum_value()
        >>>
        >>> setup_enum_for_pydantic(Status, default_member='PENDING')
        >>>
        >>> # Now available:
        >>> Status.DEFAULT_VALUE  # 'pending'
        >>> Status.LIST           # ['pending', 'active']
        >>> Status.CODER.encode(Status.ACTIVE)  # 'active'
    """
    # Default value generator: use the enum's value
    if value_generator is None:

        def _default_value_generator(e):
            return e.value

        value_generator = _default_value_generator

    # Determine default enum member
    default_enum = None
    if default_member:
        default_enum = getattr(enum_class, default_member)
    else:
        # Use first member as default
        default_enum = next(iter(enum_class))

    # Create the coder
    coder = EnumCoder(enum_class, value_generator=value_generator, default=default_enum)

    # Attach coder and properties to enum class
    setattr(enum_class, "CODER", coder)
    setattr(enum_class, "DEFAULT_VALUE", coder.default)
    setattr(enum_class, "LIST", coder.list)
    setattr(enum_class, "TUPLE", coder.tuple)
    setattr(enum_class, "LITERAL", coder.Literal)

    return coder


def enum_for_pydantic[E: Enum](
    default: str | None = None, value_generator: Callable[[Any], str] | None = None
) -> Callable[[type[E]], type[E]]:
    """Decorator version of setup_enum_for_pydantic.

    Args:
        default: Name of default enum member
        value_generator: Function to convert enum to string

    Returns:
        Decorator function

    Example:
        >>> @enum_for_pydantic(default='JSON')
        ... class FileFormat(EnumValueLowerCase):
        ...     JSON = auto_enum_value()
        ...     CSV = auto_enum_value()
        >>>
        >>> FileFormat.DEFAULT_VALUE  # 'json'
    """

    def decorator(enum_class: type[E]) -> type[E]:
        setup_enum_for_pydantic(
            enum_class, value_generator=value_generator, default_member=default
        )
        return enum_class

    return decorator


def get_enum_field_description(enum_class: type[Enum], include_default: bool = True) -> str:
    """Generate a description string for a Pydantic Field using this enum.

    Args:
        enum_class: The enum class (must have LIST and DEFAULT_VALUE attributes)
        include_default: Whether to include default value in description

    Returns:
        Description string suitable for Pydantic Field

    Example::

        from pydantic import BaseModel, Field
        from vcti.enum import (
            EnumValueLowerCase, auto_enum_value,
            enum_for_pydantic, get_enum_field_description,
        )

        @enum_for_pydantic(default='JSON')
        class FileFormat(EnumValueLowerCase):
            JSON = auto_enum_value()
            CSV = auto_enum_value()

        get_enum_field_description(FileFormat)
        # 'Supported values: (json/csv). Default: json'

        get_enum_field_description(FileFormat, include_default=False)
        # 'Supported values: (json/csv)'

        # Use in a Pydantic model Field:
        class ExportConfig(BaseModel):
            format: FileFormat = Field(
                default=FileFormat.DEFAULT_VALUE,
                description=get_enum_field_description(FileFormat),
            )
    """
    enum_list = getattr(enum_class, "LIST", [member.value for member in enum_class])
    values_str = "/".join(str(v) for v in enum_list)

    if include_default and hasattr(enum_class, "DEFAULT_VALUE"):
        default_value = getattr(enum_class, "DEFAULT_VALUE")
        return f"Supported values: ({values_str}). Default: {default_value}"
    else:
        return f"Supported values: ({values_str})"


__all__ = [
    "setup_enum_for_pydantic",
    "enum_for_pydantic",
    "get_enum_field_description",
]
