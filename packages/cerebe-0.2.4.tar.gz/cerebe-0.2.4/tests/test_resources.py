"""Tests for Agent, Session, Graph, and Storage resources — sync client."""

from __future__ import annotations

import json

from cerebe import Cerebe

# ── Agent Resource ──────────────────────────────────────────────────


class TestAgentIngestTrace:
    def test_sets_memory_type_to_execution_history(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"id": "mem_1"}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.agents.ingest_trace("tool called: search", "sess_1")

        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert data["memory_type"] == "execution_history"
        assert data["session_id"] == "sess_1"


class TestAgentWorkingMemory:
    def test_sets_memory_type_to_working(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"id": "mem_1"}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.agents.set_working_memory("current context", "sess_1", ttl_seconds=3600)

        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert data["memory_type"] == "working"
        assert data["metadata"]["ttl_seconds"] == 3600

    def test_get_working_memory(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"memories": []}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.agents.get_working_memory("sess_1")

        req = httpx_mock.get_request()
        assert req.method == "GET"
        assert "/api/v1/memory/session/sess_1" in str(req.url)
        assert "memory_types=working" in str(req.url)


# ── Session Resource ────────────────────────────────────────────────


class TestSessionList:
    def test_calls_correct_endpoint(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": [], "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.sessions.list()

        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/sessions"


class TestSessionUpdate:
    def test_sends_cognitive_state(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"session_id": "sess_1"}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.sessions.update("sess_1", {"focus": "math"})

        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert data["cognitive_state"] == {"focus": "math"}

    def test_uses_correct_endpoint(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.sessions.get("sess_1")

        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/session/sess_1"


# ── Graph Resource ──────────────────────────────────────────────────


class TestGraphTraverse:
    def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"nodes": []}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.graph.traverse(entity_name="calculus", depth=3)

        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert data["entity_name"] == "calculus"
        assert data["depth"] == 3


class TestGraphNeighbors:
    def test_calls_correct_endpoint(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"nodes": []}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.graph.neighbors("entity_1")

        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/graph/neighbors/entity_1"


class TestGraphTemporal:
    def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.graph.temporal("entity_1", "2026-01-01")

        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert data["entity_id"] == "entity_1"
        assert data["as_of_date"] == "2026-01-01"


# ── Storage Resource ────────────────────────────────────────────────


class TestStoragePresignedUpload:
    def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"upload_url": "https://s3..."}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.storage.presigned_upload("doc.pdf", "application/pdf", 1024, "abc123", "tenant_1")

        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert data["file_name"] == "doc.pdf"
        assert data["file_type"] == "application/pdf"
        assert data["tenant_id"] == "tenant_1"


class TestStorageAnalyzeContent:
    def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"type": "pdf"}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.storage.analyze_content("up_1", context="homework")

        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert data["upload_id"] == "up_1"
        assert data["context"] == "homework"


class TestStorageExtract:
    def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.storage.extract("https://example.com/doc.pdf", session_id="sess_1")

        req = httpx_mock.get_request()
        data = json.loads(req.read())
        assert data["url"] == "https://example.com/doc.pdf"
        assert data["session_id"] == "sess_1"
