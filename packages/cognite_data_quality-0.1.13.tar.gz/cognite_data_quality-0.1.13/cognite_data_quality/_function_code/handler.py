"""
Unified SHACL validation handler for Cognite Functions.

Routes validation requests to appropriate sub-handlers based on validation_type.
"""

from typing import Any

from handlers.instance_sync_cursor_validation import handle_instance_sync_cursor_validation
from handlers.instance_validation import handle_instance_validation
from handlers.orchestration_status import handle_orchestration_status
from handlers.orchestrator import handle_orchestrator
from handlers.partitioned_validation import handle_partitioned_validation
from handlers.raw_validation import handle_raw_validation_historic, handle_raw_validation_incremental
from handlers.test_rule import handle_test_rule
from handlers.timeseries_validation import handle_timeseries_validation


def handle(data: dict[str, Any], client, secrets: dict[str, str] | None = None) -> dict[str, Any]:
    """
    Unified SHACL validation handler with type-based dispatch.

    Args:
        data: Must contain 'validation_type' key with one of:
            - "instance": Basic instance validation (real-time)
            - "partitioned": Partitioned historic instance validation
            - "timeseries": Time series validation (normal/backfill)
            - "orchestrator": Historic validation orchestrator
            - "test": Test SHACL rules without writing to Records API
        client: Cognite client
        secrets: Function secrets (provided at deployment time for all handlers,
                 but only used by orchestrator for creating schedules/triggers)

    Returns:
        Validation results dict from the appropriate handler
    """
    validation_type = data.get("validation_type")

    if not validation_type:
        return {
            "status": "error",
            "error": "Missing required parameter: validation_type",
            "valid_types": [
                "instance",
                "instance_sync_cursor",
                "partitioned",
                "timeseries",
                "orchestrator",
                "orchestration_status",
                "test",
                "raw_incremental",
                "raw_historic",
            ],
        }

    # Route to appropriate handler
    # Note: secrets is available to all but only orchestrator uses it
    if validation_type == "instance":
        return handle_instance_validation(data, client)

    elif validation_type == "instance_sync_cursor":
        return handle_instance_sync_cursor_validation(data, client)

    elif validation_type == "partitioned":
        return handle_partitioned_validation(data, client)

    elif validation_type == "timeseries":
        return handle_timeseries_validation(data, client)

    elif validation_type == "orchestrator":
        return handle_orchestrator(data, client, secrets)

    elif validation_type == "orchestration_status":
        return handle_orchestration_status(data, client)

    elif validation_type == "test":
        return handle_test_rule(data, client)

    elif validation_type == "raw_incremental":
        return handle_raw_validation_incremental(data, client)

    elif validation_type == "raw_historic":
        return handle_raw_validation_historic(data, client)

    else:
        return {
            "status": "error",
            "error": f"Unknown validation_type: '{validation_type}'",
            "valid_types": [
                "instance",
                "instance_sync_cursor",
                "partitioned",
                "timeseries",
                "orchestrator",
                "orchestration_status",
                "test",
                "raw_incremental",
                "raw_historic",
            ],
        }
