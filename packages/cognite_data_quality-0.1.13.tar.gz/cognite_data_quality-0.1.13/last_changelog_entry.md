

### Fixed

- Add `orchestration_status.py` to `_get_embedded_function_files()` and `FunctionSettings.include_files` in `deploy.py` — file was missing from both the deployed function bundle and the PyPI package, causing `ModuleNotFoundError` at runtime
- Show live `validated_instances` by summing `processedCount` from in-progress partition cursors — previously showed 0 while partitions were running since the orchestration state is only updated on partition completion