import os
from typing import Any, Dict, Optional

import httpx
from mcp.server.fastmcp import FastMCP


GITHUB_API_BASE = "https://api.github.com"

mcp = FastMCP("github-tools")


def _github_headers() -> Dict[str, str]:
    token = os.getenv("GITHUB_TOKEN")
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "User-Agent": "github-tools-mcp-server",
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return headers


def _github_get(path: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    url = f"{GITHUB_API_BASE}{path}"
    with httpx.Client(timeout=30.0, headers=_github_headers()) as client:
        response = client.get(url, params=params)

    if response.status_code >= 400:
        detail = ""
        try:
            payload = response.json()
            detail = payload.get("message", "")
        except Exception:
            detail = response.text
        raise RuntimeError(
            f"GitHub API error {response.status_code} for {path}: {detail}"
        )

    return response.json()


def _github_get_redirect_location(path: str) -> Dict[str, Any]:
    """Call a GitHub endpoint that returns a 302 Location header."""
    url = f"{GITHUB_API_BASE}{path}"
    with httpx.Client(
        timeout=30.0, headers=_github_headers(), follow_redirects=False
    ) as client:
        response = client.get(url)

    if response.status_code >= 400:
        detail = ""
        try:
            payload = response.json()
            detail = payload.get("message", "")
        except Exception:
            detail = response.text
        raise RuntimeError(
            f"GitHub API error {response.status_code} for {path}: {detail}"
        )

    location = response.headers.get("Location")
    if response.status_code != 302 or not location:
        raise RuntimeError(
            f"Expected 302 with Location header for {path}, got {response.status_code}"
        )

    return {
        "status_code": response.status_code,
        "download_url": location,
    }


@mcp.tool()
def github_search_repositories(
    query: str,
    sort: str = "best-match",
    order: str = "desc",
    per_page: int = 10,
    page: int = 1,
) -> Dict[str, Any]:
    """
    Search GitHub repositories.

    Args:
        query: GitHub search query string (for example: "language:python mcp server")
        sort: One of "stars", "forks", "help-wanted-issues", "updated", or "best-match"
        order: "asc" or "desc"
        per_page: Results per page (1-100)
        page: Page number
    """
    if not query.strip():
        raise ValueError("query must not be empty")

    if order not in {"asc", "desc"}:
        raise ValueError("order must be 'asc' or 'desc'")

    if not (1 <= per_page <= 100):
        raise ValueError("per_page must be between 1 and 100")

    if page < 1:
        raise ValueError("page must be >= 1")

    params: Dict[str, Any] = {
        "q": query,
        "order": order,
        "per_page": per_page,
        "page": page,
    }

    # GitHub's "best match" is the default if sort is omitted.
    if sort != "best-match":
        params["sort"] = sort

    data = _github_get("/search/repositories", params=params)

    items = [
        {
            "full_name": repo["full_name"],
            "description": repo.get("description"),
            "private": repo.get("private", False),
            "html_url": repo["html_url"],
            "stargazers_count": repo.get("stargazers_count", 0),
            "forks_count": repo.get("forks_count", 0),
            "open_issues_count": repo.get("open_issues_count", 0),
            "language": repo.get("language"),
            "updated_at": repo.get("updated_at"),
        }
        for repo in data.get("items", [])
    ]

    return {
        "total_count": data.get("total_count", 0),
        "incomplete_results": data.get("incomplete_results", False),
        "items": items,
    }


@mcp.tool()
def github_get_workflow_run_detail(owner: str, repo: str, run_id: int) -> Dict[str, Any]:
    """
    Get details for a GitHub Actions workflow run.

    Args:
        owner: Repository owner (user or org)
        repo: Repository name
        run_id: Workflow run ID
    """
    if not owner.strip():
        raise ValueError("owner must not be empty")
    if not repo.strip():
        raise ValueError("repo must not be empty")
    if run_id <= 0:
        raise ValueError("run_id must be > 0")

    data = _github_get(f"/repos/{owner}/{repo}/actions/runs/{run_id}")

    return {
        "id": data.get("id"),
        "name": data.get("name"),
        "display_title": data.get("display_title"),
        "status": data.get("status"),
        "conclusion": data.get("conclusion"),
        "event": data.get("event"),
        "workflow_id": data.get("workflow_id"),
        "run_number": data.get("run_number"),
        "run_attempt": data.get("run_attempt"),
        "created_at": data.get("created_at"),
        "updated_at": data.get("updated_at"),
        "actor": (data.get("actor") or {}).get("login"),
        "head_branch": data.get("head_branch"),
        "head_sha": data.get("head_sha"),
        "html_url": data.get("html_url"),
        "jobs_url": data.get("jobs_url"),
        "logs_url": data.get("logs_url"),
        "artifacts_url": data.get("artifacts_url"),
        "cancel_url": data.get("cancel_url"),
        "rerun_url": data.get("rerun_url"),
        "repository": {
            "full_name": (data.get("repository") or {}).get("full_name"),
            "private": (data.get("repository") or {}).get("private"),
            "html_url": (data.get("repository") or {}).get("html_url"),
        },
    }


@mcp.tool()
def github_get_workflow_run_logs_download_url(
    owner: str, repo: str, run_id: int
) -> Dict[str, Any]:
    """
    Get the temporary download URL for a workflow run logs archive.

    GitHub returns 302 Found for this endpoint with a Location header.
    The returned URL expires quickly (about 1 minute).

    Args:
        owner: Repository owner (user or org)
        repo: Repository name
        run_id: Workflow run ID
    """
    if not owner.strip():
        raise ValueError("owner must not be empty")
    if not repo.strip():
        raise ValueError("repo must not be empty")
    if run_id <= 0:
        raise ValueError("run_id must be > 0")

    result = _github_get_redirect_location(
        f"/repos/{owner}/{repo}/actions/runs/{run_id}/logs"
    )
    result["expires_note"] = "GitHub says this URL expires after about 1 minute."
    return result


@mcp.tool()
def github_get_workflow_run_attempt_detail(
    owner: str, repo: str, run_id: int, attempt_number: int, exclude_pull_requests: bool = False
) -> Dict[str, Any]:
    """
    Get details for a specific workflow run attempt.

    Args:
        owner: Repository owner (user or org)
        repo: Repository name
        run_id: Workflow run ID
        attempt_number: Attempt number for the workflow run
        exclude_pull_requests: If true, pull requests are omitted from response
    """
    if not owner.strip():
        raise ValueError("owner must not be empty")
    if not repo.strip():
        raise ValueError("repo must not be empty")
    if run_id <= 0:
        raise ValueError("run_id must be > 0")
    if attempt_number <= 0:
        raise ValueError("attempt_number must be > 0")

    data = _github_get(
        f"/repos/{owner}/{repo}/actions/runs/{run_id}/attempts/{attempt_number}",
        params={"exclude_pull_requests": str(exclude_pull_requests).lower()},
    )

    return {
        "id": data.get("id"),
        "name": data.get("name"),
        "display_title": data.get("display_title"),
        "status": data.get("status"),
        "conclusion": data.get("conclusion"),
        "event": data.get("event"),
        "workflow_id": data.get("workflow_id"),
        "run_number": data.get("run_number"),
        "run_attempt": data.get("run_attempt"),
        "created_at": data.get("created_at"),
        "updated_at": data.get("updated_at"),
        "actor": (data.get("actor") or {}).get("login"),
        "head_branch": data.get("head_branch"),
        "head_sha": data.get("head_sha"),
        "html_url": data.get("html_url"),
        "jobs_url": data.get("jobs_url"),
        "logs_url": data.get("logs_url"),
        "artifacts_url": data.get("artifacts_url"),
        "cancel_url": data.get("cancel_url"),
        "rerun_url": data.get("rerun_url"),
        "exclude_pull_requests": exclude_pull_requests,
        "repository": {
            "full_name": (data.get("repository") or {}).get("full_name"),
            "private": (data.get("repository") or {}).get("private"),
            "html_url": (data.get("repository") or {}).get("html_url"),
        },
    }


@mcp.tool()
def github_get_workflow_run_attempt_logs_download_url(
    owner: str, repo: str, run_id: int, attempt_number: int
) -> Dict[str, Any]:
    """
    Get the temporary download URL for a workflow run attempt logs archive.

    GitHub returns 302 Found for this endpoint with a Location header.
    The returned URL expires quickly (about 1 minute).

    Args:
        owner: Repository owner (user or org)
        repo: Repository name
        run_id: Workflow run ID
        attempt_number: Attempt number for the workflow run
    """
    if not owner.strip():
        raise ValueError("owner must not be empty")
    if not repo.strip():
        raise ValueError("repo must not be empty")
    if run_id <= 0:
        raise ValueError("run_id must be > 0")
    if attempt_number <= 0:
        raise ValueError("attempt_number must be > 0")

    result = _github_get_redirect_location(
        f"/repos/{owner}/{repo}/actions/runs/{run_id}/attempts/{attempt_number}/logs"
    )
    result["expires_note"] = "GitHub says this URL expires after about 1 minute."
    return result


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
