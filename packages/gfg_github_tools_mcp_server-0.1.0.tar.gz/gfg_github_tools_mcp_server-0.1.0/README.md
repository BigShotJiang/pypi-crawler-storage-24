# GitHub Tools MCP Server (Python)

This MCP server provides these tools:

- `github_search_repositories`
- `github_get_workflow_run_detail`
- `github_get_workflow_run_logs_download_url`
- `github_get_workflow_run_attempt_detail`
- `github_get_workflow_run_attempt_logs_download_url`

## Prerequisites

- Python 3.10+
- A GitHub token in `GITHUB_TOKEN` (recommended to avoid rate limits)

## Setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Run

```bash
python server.py
```

The server uses stdio transport by default, which is what MCP clients expect.

## Tools

### `github_search_repositories`

Searches repositories using GitHub's repository search endpoint.

Inputs:

- `query` (string, required)
- `sort` (string, optional: `best-match` | `stars` | `forks` | `help-wanted-issues` | `updated`)
- `order` (string, optional: `asc` | `desc`)
- `per_page` (int, optional, 1-100)
- `page` (int, optional, >= 1)

### `github_get_workflow_run_detail`

Gets one workflow run detail from GitHub Actions.

Inputs:

- `owner` (string, required)
- `repo` (string, required)
- `run_id` (int, required)

### `github_get_workflow_run_logs_download_url`

Gets a temporary download URL for a workflow run logs archive.
This endpoint returns a `302` response and the URL in the `Location` header.

Inputs:

- `owner` (string, required)
- `repo` (string, required)
- `run_id` (int, required)

### `github_get_workflow_run_attempt_detail`

Gets details for a specific workflow run attempt.

Inputs:

- `owner` (string, required)
- `repo` (string, required)
- `run_id` (int, required)
- `attempt_number` (int, required)
- `exclude_pull_requests` (bool, optional, default `false`)

### `github_get_workflow_run_attempt_logs_download_url`

Gets a temporary download URL for a workflow run attempt logs archive.
This endpoint returns a `302` response and the URL in the `Location` header.

Inputs:

- `owner` (string, required)
- `repo` (string, required)
- `run_id` (int, required)
- `attempt_number` (int, required)
