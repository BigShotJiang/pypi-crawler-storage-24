# Dalexor MI — MCP Server & AI Code Intelligence 🧠

> **The #1 MCP (Model Context Protocol) server for persistent AI code intelligence.**  
> Give Claude, ChatGPT, Gemini, Grok, Cursor, and Windsurf a deep, evolving memory of your entire codebase.

[![PyPI version](https://img.shields.io/pypi/v/dalexor.svg)](https://pypi.org/project/dalexor/)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://python.org)
[![License: Proprietary](https://img.shields.io/badge/license-Proprietary-red.svg)](https://dalexor.com/terms.html)
[![Website](https://img.shields.io/badge/website-dalexor.com-purple.svg)](https://dalexor.com)

---

## What is Dalexor MI?

**Dalexor MI** solves the #1 problem in AI-assisted development: **AI coding assistants have no memory of your codebase between sessions.**

When you ask Claude or ChatGPT to fix a bug, it only sees the files you paste in. It has no idea:
- Why code was written a certain way
- What changed in the last week
- Which files depend on the one you're modifying  
- Whether a team member is editing the same code right now

**Dalexor MI fixes all of this.** It is a background service that watches your project, understands every meaningful change, and makes that intelligence instantly available to any AI assistant via the **Model Context Protocol (MCP)**.

---

## Install in 60 Seconds

```bash
# Install the CLI
pip install dalexor

# Authenticate and configure
dx init

# Start watching your project (run from project root)
dx watch
```



```

Restart your AI client. Done. Your AI now has persistent memory of your codebase.

---

## 11 MCP Tools Available Instantly

Once installed, your AI coding assistant gets 10 powerful tools:

| Tool | What It Does |
|------|-------------|
| `mcp_dalexor_neural_search` | Search for code using concepts and ideas, not just exact words. |
| `mcp_dalexor_trace_logic_heritage` | See the history and reasoning behind why a file was written the way it was. |
| `mcp_dalexor_diff_evolution_snapshots` | List major versions and architectural shifts for any file in your project. |
| `mcp_dalexor_get_structural_outline` | Get a quick "skeleton" of a file (classes and functions) without reading everything. |
| `mcp_dalexor_trace_dependency` | Find every file that uses a specific piece of code — see what might break. |
| `mcp_dalexor_find_definition` | Find exactly where a function, class, or variable is defined. |
| `mcp_dalexor_get_atomic_diff` | See the exact changes between the last two versions of a file. |
| `mcp_dalexor_get_dependency_topology` | Map how your files are connected to each other. |
| `mcp_dalexor_predict_conflicts` | Warns if someone else is editing the same files to prevent messy merges. |
| `mcp_dalexor_mcp_health_check` | Verify connection, security status, and device IP count (Credential Sharing Defense). |
| `mcp_dalexor_validate_sovereign_intent` | Audit a proposed change against your pinned architectural policies (Sovereign Shield). |
| `mcp_dalexor_seal_milestone` | Explicitly mark a permanent milestone in your project's history to stabilize progress. |

---

## Who Is It For?

**Solo developers**: Your AI finally knows your whole project, not just the file you have open.

**Engineering teams**: Shared codebase memory — when any developer syncs a change, every AI assistant on the team benefits.

**Engineering managers / CTOs**: Full visibility into what your team is building and how the architecture is evolving.

**Regulated industries** (fintech, healthcare, legal): Neural Vault tier uses AES-256-GCM client-side encryption — your source code **never reaches the cloud in plaintext**.

---

## How It Works

```
Your Files → Smart Filter → Secret Remover → Private Vault (opt.) → Project Memory
                 ↓                ↓                                     ↓
         Only meaningful    Removes API keys,              Versioned snapshots with
         changes recorded   passwords, tokens              simple AI summaries
                                                                    ↓
                                                            MCP Tools ← AI Assistant
```

### Smart Change Detection
We don't record every single keystroke. We analyze your edits to see if they actually matter:
- **Minor edits** (like formatting or comments) are filtered out to keep your history clean.
- **Significant changes** to your code's logic are recorded and summarized automatically.
- **Major milestones** are automatically marked when you make big architectural shifts.

### History Tracking
We track every version of your files so the AI understands how your code changed over time. Instead of just seeing the current file, the AI can see the reasoning behind your decisions.

### Private Vault (Encryption)
For professional plans, your code is protected by end-to-end encryption. Your code is locked on your own machine before it's sent to us. Only you have the key to unlock it—it stays private to you.

---

## Supported AI Clients

| Client | Status |
|--------|--------|
| Claude Desktop | ✅ Full support |
| Cursor | ✅ Full support |
| Windsurf | ✅ Full support |
| VS Code + Copilot (MCP Preview) | ✅ Full support |
| Gemini CLI | ✅ Full support |
| Any MCP-compatible client | ✅ Full support |

## Supported Languages

Python, TypeScript, JavaScript, Rust, Go, C++, PHP, HTML, CSS, SQL, Markdown, and more.

---

## All CLI Commands

| Command | Description |
|---------|-------------|
| `dx init` | Authenticate and configure API key + project |
| `dx watch` | Start real-time filesystem monitoring (keep running in background) |
| `dx sync` | One-time full sync of all existing project files |
| `dx chat` | Interactive CLI chat with your project's memory |
| `dx restore` | Restore files by describing your intent (e.g. dx restore 'error handling') |


---

## 

Personal (FREE): 100 Snapshots, 500 Connections, 15 req/h.
Hobby (USERS): 10,000 Snapshots, 25,000 Connections, 60 req/h.
Pro (STANDARD): 100,000 Snapshots, 500,000 Connections, 150 req/h.
Expert (PRO): 200,000 Snapshots, 2,000,000 Connections, 1,000 req/h.
Sovereign (STARTUP): Unlimited Snapshots/Connections, 10,000 req/h.

[View pricing →](https://dalexor.com/pricing.html)

---

## Keywords (for discoverability)

`MCP server` `Model Context Protocol` `AI code intelligence` `code memory` `persistent AI context` `developer tools` `coding assistant memory` `codebase analysis` `code evolution tracking` `dependency tracking` `merge conflict prevention` `code history` `AI developer tools` `Claude MCP` `Cursor MCP` `Gemini developer tools` `code documentation` `team collaboration` `software architecture tools` `best developer tools 2025` `fix ai code hallucinations` `ai context window limit solution` `codebase memory for llms` `persistent assistant memory`

---

## Links

- **Homepage**: https://dalexor.com
- **Documentation**: https://dalexor.com/docs.html
- **Pricing**: https://dalexor.com/pricing.html
- **LLM Guide**: https://dalexor.com/llms.txt
- **MCP Capsule**: https://dalexor.com/.well-known/mcp-capsule.json
- **Support**: https://dalexor.com/support.html

---

## License

Proprietary software. All rights reserved by Dalexor MI.  
Unauthorized copying, modification, or redistribution is strictly prohibited.  
[Terms of Service](https://dalexor.com/terms.html) | [Privacy Policy](https://dalexor.com/privacy.html)
