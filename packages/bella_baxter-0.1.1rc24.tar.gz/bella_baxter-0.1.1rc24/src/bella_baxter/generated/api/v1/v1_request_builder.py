from __future__ import annotations
from collections.abc import Callable
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.request_adapter import RequestAdapter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .access_logs.access_logs_request_builder import AccessLogsRequestBuilder
    from .admin.admin_request_builder import AdminRequestBuilder
    from .api_keys.api_keys_request_builder import ApiKeysRequestBuilder
    from .auth.auth_request_builder import AuthRequestBuilder
    from .dashboard.dashboard_request_builder import DashboardRequestBuilder
    from .environments.environments_request_builder import EnvironmentsRequestBuilder
    from .events.events_request_builder import EventsRequestBuilder
    from .groups.groups_request_builder import GroupsRequestBuilder
    from .keys.keys_request_builder import KeysRequestBuilder
    from .notifications.notifications_request_builder import NotificationsRequestBuilder
    from .projects.projects_request_builder import ProjectsRequestBuilder
    from .providers.providers_request_builder import ProvidersRequestBuilder
    from .security.security_request_builder import SecurityRequestBuilder
    from .shares.shares_request_builder import SharesRequestBuilder
    from .ssh.ssh_request_builder import SshRequestBuilder
    from .system.system_request_builder import SystemRequestBuilder
    from .tenant.tenant_request_builder import TenantRequestBuilder
    from .tenants.tenants_request_builder import TenantsRequestBuilder
    from .token.token_request_builder import TokenRequestBuilder
    from .users.users_request_builder import UsersRequestBuilder
    from .webhooks.webhooks_request_builder import WebhooksRequestBuilder

class V1RequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/v1
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new V1RequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/v1", path_parameters)
    
    @property
    def access_logs(self) -> AccessLogsRequestBuilder:
        """
        The accessLogs property
        """
        from .access_logs.access_logs_request_builder import AccessLogsRequestBuilder

        return AccessLogsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def admin(self) -> AdminRequestBuilder:
        """
        The admin property
        """
        from .admin.admin_request_builder import AdminRequestBuilder

        return AdminRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def api_keys(self) -> ApiKeysRequestBuilder:
        """
        The apiKeys property
        """
        from .api_keys.api_keys_request_builder import ApiKeysRequestBuilder

        return ApiKeysRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def auth(self) -> AuthRequestBuilder:
        """
        The auth property
        """
        from .auth.auth_request_builder import AuthRequestBuilder

        return AuthRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def dashboard(self) -> DashboardRequestBuilder:
        """
        The dashboard property
        """
        from .dashboard.dashboard_request_builder import DashboardRequestBuilder

        return DashboardRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def environments(self) -> EnvironmentsRequestBuilder:
        """
        The environments property
        """
        from .environments.environments_request_builder import EnvironmentsRequestBuilder

        return EnvironmentsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def events(self) -> EventsRequestBuilder:
        """
        The events property
        """
        from .events.events_request_builder import EventsRequestBuilder

        return EventsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def groups(self) -> GroupsRequestBuilder:
        """
        The groups property
        """
        from .groups.groups_request_builder import GroupsRequestBuilder

        return GroupsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def keys(self) -> KeysRequestBuilder:
        """
        The keys property
        """
        from .keys.keys_request_builder import KeysRequestBuilder

        return KeysRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def notifications(self) -> NotificationsRequestBuilder:
        """
        The notifications property
        """
        from .notifications.notifications_request_builder import NotificationsRequestBuilder

        return NotificationsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def projects(self) -> ProjectsRequestBuilder:
        """
        The projects property
        """
        from .projects.projects_request_builder import ProjectsRequestBuilder

        return ProjectsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def providers(self) -> ProvidersRequestBuilder:
        """
        The providers property
        """
        from .providers.providers_request_builder import ProvidersRequestBuilder

        return ProvidersRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def security(self) -> SecurityRequestBuilder:
        """
        The security property
        """
        from .security.security_request_builder import SecurityRequestBuilder

        return SecurityRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def shares(self) -> SharesRequestBuilder:
        """
        The shares property
        """
        from .shares.shares_request_builder import SharesRequestBuilder

        return SharesRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def ssh(self) -> SshRequestBuilder:
        """
        The ssh property
        """
        from .ssh.ssh_request_builder import SshRequestBuilder

        return SshRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def system(self) -> SystemRequestBuilder:
        """
        The system property
        """
        from .system.system_request_builder import SystemRequestBuilder

        return SystemRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def tenant(self) -> TenantRequestBuilder:
        """
        The tenant property
        """
        from .tenant.tenant_request_builder import TenantRequestBuilder

        return TenantRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def tenants(self) -> TenantsRequestBuilder:
        """
        The tenants property
        """
        from .tenants.tenants_request_builder import TenantsRequestBuilder

        return TenantsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def token(self) -> TokenRequestBuilder:
        """
        The token property
        """
        from .token.token_request_builder import TokenRequestBuilder

        return TokenRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def users(self) -> UsersRequestBuilder:
        """
        The users property
        """
        from .users.users_request_builder import UsersRequestBuilder

        return UsersRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def webhooks(self) -> WebhooksRequestBuilder:
        """
        The webhooks property
        """
        from .webhooks.webhooks_request_builder import WebhooksRequestBuilder

        return WebhooksRequestBuilder(self.request_adapter, self.path_parameters)
    

