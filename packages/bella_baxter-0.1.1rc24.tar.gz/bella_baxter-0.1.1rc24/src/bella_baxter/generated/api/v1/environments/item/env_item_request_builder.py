from __future__ import annotations
from collections.abc import Callable
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.request_adapter import RequestAdapter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .api_keys.api_keys_request_builder import ApiKeysRequestBuilder
    from .drift.drift_request_builder import DriftRequestBuilder
    from .notifications.notifications_request_builder import NotificationsRequestBuilder
    from .secret_drift_summary.secret_drift_summary_request_builder import SecretDriftSummaryRequestBuilder
    from .security.security_request_builder import SecurityRequestBuilder
    from .token.token_request_builder import TokenRequestBuilder
    from .tokens.tokens_request_builder import TokensRequestBuilder
    from .trust_domains.trust_domains_request_builder import TrustDomainsRequestBuilder
    from .webhooks.webhooks_request_builder import WebhooksRequestBuilder

class EnvItemRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/v1/environments/{env-id}
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new EnvItemRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/v1/environments/{env%2Did}", path_parameters)
    
    @property
    def api_keys(self) -> ApiKeysRequestBuilder:
        """
        The apiKeys property
        """
        from .api_keys.api_keys_request_builder import ApiKeysRequestBuilder

        return ApiKeysRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def drift(self) -> DriftRequestBuilder:
        """
        The drift property
        """
        from .drift.drift_request_builder import DriftRequestBuilder

        return DriftRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def notifications(self) -> NotificationsRequestBuilder:
        """
        The notifications property
        """
        from .notifications.notifications_request_builder import NotificationsRequestBuilder

        return NotificationsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def secret_drift_summary(self) -> SecretDriftSummaryRequestBuilder:
        """
        The secretDriftSummary property
        """
        from .secret_drift_summary.secret_drift_summary_request_builder import SecretDriftSummaryRequestBuilder

        return SecretDriftSummaryRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def security(self) -> SecurityRequestBuilder:
        """
        The security property
        """
        from .security.security_request_builder import SecurityRequestBuilder

        return SecurityRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def token(self) -> TokenRequestBuilder:
        """
        The token property
        """
        from .token.token_request_builder import TokenRequestBuilder

        return TokenRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def tokens(self) -> TokensRequestBuilder:
        """
        The tokens property
        """
        from .tokens.tokens_request_builder import TokensRequestBuilder

        return TokensRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def trust_domains(self) -> TrustDomainsRequestBuilder:
        """
        The trustDomains property
        """
        from .trust_domains.trust_domains_request_builder import TrustDomainsRequestBuilder

        return TrustDomainsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def webhooks(self) -> WebhooksRequestBuilder:
        """
        The webhooks property
        """
        from .webhooks.webhooks_request_builder import WebhooksRequestBuilder

        return WebhooksRequestBuilder(self.request_adapter, self.path_parameters)
    

