from __future__ import annotations
from collections.abc import Callable
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.request_adapter import RequestAdapter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .item.env_item_request_builder import EnvItemRequestBuilder

class EnvironmentsRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/v1/environments
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new EnvironmentsRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/v1/environments", path_parameters)
    
    def by_env_id(self,env_id: UUID) -> EnvItemRequestBuilder:
        """
        Gets an item from the bella_baxter.generated.api.v1.environments.item collection
        param env_id: Unique identifier of the item
        Returns: EnvItemRequestBuilder
        """
        if env_id is None:
            raise TypeError("env_id cannot be null.")
        from .item.env_item_request_builder import EnvItemRequestBuilder

        url_tpl_params = get_path_parameters(self.path_parameters)
        url_tpl_params["env%2Did"] = env_id
        return EnvItemRequestBuilder(self.request_adapter, url_tpl_params)
    

