from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from ....models.create_project_command import CreateProjectCommand
    from ....models.page_project_response import PageProjectResponse
    from ....models.project_operation_response import ProjectOperationResponse
    from .import_.import_request_builder import ImportRequestBuilder
    from .item.item_request_builder import ItemRequestBuilder
    from .search.search_request_builder import SearchRequestBuilder
    from .tags.tags_request_builder import TagsRequestBuilder

class ProjectsRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/v1/projects
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new ProjectsRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/v1/projects{?page*,size*,sortBy*,sortDir*,tag*}", path_parameters)
    
    def by_id(self,id: str) -> ItemRequestBuilder:
        """
        Gets an item from the bella_baxter.generated.api.v1.projects.item collection
        param id: Unique identifier of the item
        Returns: ItemRequestBuilder
        """
        if id is None:
            raise TypeError("id cannot be null.")
        from .item.item_request_builder import ItemRequestBuilder

        url_tpl_params = get_path_parameters(self.path_parameters)
        url_tpl_params["%2Did"] = id
        return ItemRequestBuilder(self.request_adapter, url_tpl_params)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[ProjectsRequestBuilderGetQueryParameters]] = None) -> Optional[PageProjectResponse]:
        """
        GET_api_v1_projects
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[PageProjectResponse]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from ....models.page_project_response import PageProjectResponse

        return await self.request_adapter.send_async(request_info, PageProjectResponse, None)
    
    async def post(self,body: CreateProjectCommand, request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> Optional[ProjectOperationResponse]:
        """
        POST_api_v1_projects
        param body: The request body
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[ProjectOperationResponse]
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = self.to_post_request_information(
            body, request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from ....models.project_operation_response import ProjectOperationResponse

        return await self.request_adapter.send_async(request_info, ProjectOperationResponse, None)
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[ProjectsRequestBuilderGetQueryParameters]] = None) -> RequestInformation:
        """
        GET_api_v1_projects
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def to_post_request_information(self,body: CreateProjectCommand, request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> RequestInformation:
        """
        POST_api_v1_projects
        param body: The request body
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = RequestInformation(Method.POST, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        request_info.set_content_from_parsable(self.request_adapter, "application/json", body)
        return request_info
    
    def with_url(self,raw_url: str) -> ProjectsRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: ProjectsRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return ProjectsRequestBuilder(self.request_adapter, raw_url)
    
    @property
    def import_(self) -> ImportRequestBuilder:
        """
        The import property
        """
        from .import_.import_request_builder import ImportRequestBuilder

        return ImportRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def search(self) -> SearchRequestBuilder:
        """
        The search property
        """
        from .search.search_request_builder import SearchRequestBuilder

        return SearchRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def tags(self) -> TagsRequestBuilder:
        """
        The tags property
        """
        from .tags.tags_request_builder import TagsRequestBuilder

        return TagsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @dataclass
    class ProjectsRequestBuilderGetQueryParameters():
        """
        GET_api_v1_projects
        """
        def get_query_parameter(self,original_name: str) -> str:
            """
            Maps the query parameters names to their encoded names for the URI template parsing.
            param original_name: The original query parameter name in the class.
            Returns: str
            """
            if original_name is None:
                raise TypeError("original_name cannot be null.")
            if original_name == "sort_by":
                return "sortBy"
            if original_name == "sort_dir":
                return "sortDir"
            if original_name == "page":
                return "page"
            if original_name == "size":
                return "size"
            if original_name == "tag":
                return "tag"
            return original_name
        
        page: Optional[int] = None

        size: Optional[int] = None

        sort_by: Optional[str] = None

        sort_dir: Optional[str] = None

        tag: Optional[str] = None

    
    @dataclass
    class ProjectsRequestBuilderGetRequestConfiguration(RequestConfiguration[ProjectsRequestBuilderGetQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    
    @dataclass
    class ProjectsRequestBuilderPostRequestConfiguration(RequestConfiguration[QueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

