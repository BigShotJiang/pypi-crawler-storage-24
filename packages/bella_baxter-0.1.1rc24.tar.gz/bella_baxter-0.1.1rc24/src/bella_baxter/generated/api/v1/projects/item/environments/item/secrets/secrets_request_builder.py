from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from ........models.all_environment_secrets_response import AllEnvironmentSecretsResponse
    from ........models.problem_details import ProblemDetails
    from .export.export_request_builder import ExportRequestBuilder
    from .manifest.manifest_request_builder import ManifestRequestBuilder
    from .version.version_request_builder import VersionRequestBuilder

class SecretsRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/v1/projects/{-id}/environments/{envSlug}/secrets
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new SecretsRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/v1/projects/{%2Did}/environments/{envSlug}/secrets", path_parameters)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> Optional[AllEnvironmentSecretsResponse]:
        """
        GET_api_v1_projects_projectRef_environments_envSlug_secrets
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[AllEnvironmentSecretsResponse]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        from ........models.problem_details import ProblemDetails

        error_mapping: dict[str, type[ParsableFactory]] = {
            "404": ProblemDetails,
        }
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from ........models.all_environment_secrets_response import AllEnvironmentSecretsResponse

        return await self.request_adapter.send_async(request_info, AllEnvironmentSecretsResponse, error_mapping)
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> RequestInformation:
        """
        GET_api_v1_projects_projectRef_environments_envSlug_secrets
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def with_url(self,raw_url: str) -> SecretsRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: SecretsRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return SecretsRequestBuilder(self.request_adapter, raw_url)
    
    @property
    def export(self) -> ExportRequestBuilder:
        """
        The export property
        """
        from .export.export_request_builder import ExportRequestBuilder

        return ExportRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def manifest(self) -> ManifestRequestBuilder:
        """
        The manifest property
        """
        from .manifest.manifest_request_builder import ManifestRequestBuilder

        return ManifestRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def version(self) -> VersionRequestBuilder:
        """
        The version property
        """
        from .version.version_request_builder import VersionRequestBuilder

        return VersionRequestBuilder(self.request_adapter, self.path_parameters)
    
    @dataclass
    class SecretsRequestBuilderGetRequestConfiguration(RequestConfiguration[QueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

