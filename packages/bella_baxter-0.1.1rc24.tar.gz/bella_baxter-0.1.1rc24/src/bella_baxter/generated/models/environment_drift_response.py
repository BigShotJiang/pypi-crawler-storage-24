from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .environment_drift_item import EnvironmentDriftItem
    from .environment_drift_summary import EnvironmentDriftSummary

@dataclass
class EnvironmentDriftResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The secrets property
    secrets: Optional[list[EnvironmentDriftItem]] = None
    # The siblings property
    siblings: Optional[list[str]] = None
    # The summary property
    summary: Optional[EnvironmentDriftSummary] = None
    # The thisEnv property
    this_env: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EnvironmentDriftResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EnvironmentDriftResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return EnvironmentDriftResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .environment_drift_item import EnvironmentDriftItem
        from .environment_drift_summary import EnvironmentDriftSummary

        from .environment_drift_item import EnvironmentDriftItem
        from .environment_drift_summary import EnvironmentDriftSummary

        fields: dict[str, Callable[[Any], None]] = {
            "secrets": lambda n : setattr(self, 'secrets', n.get_collection_of_object_values(EnvironmentDriftItem)),
            "siblings": lambda n : setattr(self, 'siblings', n.get_collection_of_primitive_values(str)),
            "summary": lambda n : setattr(self, 'summary', n.get_object_value(EnvironmentDriftSummary)),
            "thisEnv": lambda n : setattr(self, 'this_env', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("secrets", self.secrets)
        writer.write_collection_of_primitive_values("siblings", self.siblings)
        writer.write_object_value("summary", self.summary)
        writer.write_str_value("thisEnv", self.this_env)
        writer.write_additional_data_value(self.additional_data)
    

