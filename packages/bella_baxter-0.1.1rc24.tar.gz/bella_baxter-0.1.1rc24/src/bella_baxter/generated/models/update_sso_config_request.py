from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class UpdateSsoConfigRequest(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The clientSecret property
    client_secret: Optional[str] = None
    # The discoveryUrl property
    discovery_url: Optional[str] = None
    # The domains property
    domains: Optional[list[str]] = None
    # The metadataUrl property
    metadata_url: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> UpdateSsoConfigRequest:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: UpdateSsoConfigRequest
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return UpdateSsoConfigRequest()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "clientSecret": lambda n : setattr(self, 'client_secret', n.get_str_value()),
            "discoveryUrl": lambda n : setattr(self, 'discovery_url', n.get_str_value()),
            "domains": lambda n : setattr(self, 'domains', n.get_collection_of_primitive_values(str)),
            "metadataUrl": lambda n : setattr(self, 'metadata_url', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("clientSecret", self.client_secret)
        writer.write_str_value("discoveryUrl", self.discovery_url)
        writer.write_collection_of_primitive_values("domains", self.domains)
        writer.write_str_value("metadataUrl", self.metadata_url)
        writer.write_additional_data_value(self.additional_data)
    

