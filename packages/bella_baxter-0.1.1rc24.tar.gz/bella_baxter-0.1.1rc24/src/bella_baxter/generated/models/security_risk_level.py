from enum import Enum

class SecurityRiskLevel(str, Enum):
    None_ = "None",
    Low = "Low",
    Medium = "Medium",
    High = "High",
    Critical = "Critical",

