from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import ComposedTypeWrapper, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .group_operation_response_group_member1 import GroupOperationResponse_groupMember1
    from .group_response import GroupResponse

@dataclass
class GroupOperationResponse_group(ComposedTypeWrapper, Parsable):
    """
    Composed type wrapper for classes GroupOperationResponse_groupMember1, GroupResponse
    """
    # Composed type representation for type GroupOperationResponse_groupMember1
    group_operation_response_group_member1: Optional[GroupOperationResponse_groupMember1] = None
    # Composed type representation for type GroupResponse
    group_response: Optional[GroupResponse] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> GroupOperationResponse_group:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: GroupOperationResponse_group
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        result = GroupOperationResponse_group()
        if mapping_value and mapping_value.casefold() == "".casefold():
            from .group_operation_response_group_member1 import GroupOperationResponse_groupMember1

            result.group_operation_response_group_member1 = GroupOperationResponse_groupMember1()
        elif mapping_value and mapping_value.casefold() == "GroupResponse".casefold():
            from .group_response import GroupResponse

            result.group_response = GroupResponse()
        return result
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .group_operation_response_group_member1 import GroupOperationResponse_groupMember1
        from .group_response import GroupResponse

        if self.group_operation_response_group_member1:
            return self.group_operation_response_group_member1.get_field_deserializers()
        if self.group_response:
            return self.group_response.get_field_deserializers()
        return {}
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        if self.group_operation_response_group_member1:
            writer.write_object_value(None, self.group_operation_response_group_member1)
        elif self.group_response:
            writer.write_object_value(None, self.group_response)
    

