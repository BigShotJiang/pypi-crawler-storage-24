from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class TotpKeyImportResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The message property
    message: Optional[str] = None
    # The name property
    name: Optional[str] = None
    # The otpauthUrl property
    otpauth_url: Optional[str] = None
    # The qrCodeBase64 property
    qr_code_base64: Optional[str] = None
    # The success property
    success: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> TotpKeyImportResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: TotpKeyImportResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return TotpKeyImportResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "message": lambda n : setattr(self, 'message', n.get_str_value()),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
            "otpauthUrl": lambda n : setattr(self, 'otpauth_url', n.get_str_value()),
            "qrCodeBase64": lambda n : setattr(self, 'qr_code_base64', n.get_str_value()),
            "success": lambda n : setattr(self, 'success', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("message", self.message)
        writer.write_str_value("name", self.name)
        writer.write_str_value("otpauthUrl", self.otpauth_url)
        writer.write_str_value("qrCodeBase64", self.qr_code_base64)
        writer.write_bool_value("success", self.success)
        writer.write_additional_data_value(self.additional_data)
    

