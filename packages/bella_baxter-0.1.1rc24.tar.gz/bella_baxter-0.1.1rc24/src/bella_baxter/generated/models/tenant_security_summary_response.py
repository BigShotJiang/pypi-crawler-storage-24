from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .environment_risk_entry import EnvironmentRiskEntry

@dataclass
class TenantSecuritySummaryResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The criticalEnvironments property
    critical_environments: Optional[int] = None
    # The environmentsByRisk property
    environments_by_risk: Optional[list[EnvironmentRiskEntry]] = None
    # The healthyEnvironments property
    healthy_environments: Optional[int] = None
    # The highEnvironments property
    high_environments: Optional[int] = None
    # The mediumEnvironments property
    medium_environments: Optional[int] = None
    # The scannedEnvironments property
    scanned_environments: Optional[int] = None
    # The totalCritical property
    total_critical: Optional[int] = None
    # The totalEnvironments property
    total_environments: Optional[int] = None
    # The totalHigh property
    total_high: Optional[int] = None
    # The totalLow property
    total_low: Optional[int] = None
    # The totalMedium property
    total_medium: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> TenantSecuritySummaryResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: TenantSecuritySummaryResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return TenantSecuritySummaryResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .environment_risk_entry import EnvironmentRiskEntry

        from .environment_risk_entry import EnvironmentRiskEntry

        fields: dict[str, Callable[[Any], None]] = {
            "criticalEnvironments": lambda n : setattr(self, 'critical_environments', n.get_int_value()),
            "environmentsByRisk": lambda n : setattr(self, 'environments_by_risk', n.get_collection_of_object_values(EnvironmentRiskEntry)),
            "healthyEnvironments": lambda n : setattr(self, 'healthy_environments', n.get_int_value()),
            "highEnvironments": lambda n : setattr(self, 'high_environments', n.get_int_value()),
            "mediumEnvironments": lambda n : setattr(self, 'medium_environments', n.get_int_value()),
            "scannedEnvironments": lambda n : setattr(self, 'scanned_environments', n.get_int_value()),
            "totalCritical": lambda n : setattr(self, 'total_critical', n.get_int_value()),
            "totalEnvironments": lambda n : setattr(self, 'total_environments', n.get_int_value()),
            "totalHigh": lambda n : setattr(self, 'total_high', n.get_int_value()),
            "totalLow": lambda n : setattr(self, 'total_low', n.get_int_value()),
            "totalMedium": lambda n : setattr(self, 'total_medium', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("criticalEnvironments", self.critical_environments)
        writer.write_collection_of_object_values("environmentsByRisk", self.environments_by_risk)
        writer.write_int_value("healthyEnvironments", self.healthy_environments)
        writer.write_int_value("highEnvironments", self.high_environments)
        writer.write_int_value("mediumEnvironments", self.medium_environments)
        writer.write_int_value("scannedEnvironments", self.scanned_environments)
        writer.write_int_value("totalCritical", self.total_critical)
        writer.write_int_value("totalEnvironments", self.total_environments)
        writer.write_int_value("totalHigh", self.total_high)
        writer.write_int_value("totalLow", self.total_low)
        writer.write_int_value("totalMedium", self.total_medium)
        writer.write_additional_data_value(self.additional_data)
    

