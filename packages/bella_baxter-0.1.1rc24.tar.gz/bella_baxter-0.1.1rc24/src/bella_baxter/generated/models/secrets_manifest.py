from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .secret_manifest_item import SecretManifestItem

@dataclass
class SecretsManifest(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The environmentSlug property
    environment_slug: Optional[str] = None
    # The generatedAt property
    generated_at: Optional[datetime.datetime] = None
    # The projectSlug property
    project_slug: Optional[str] = None
    # The secrets property
    secrets: Optional[list[SecretManifestItem]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> SecretsManifest:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: SecretsManifest
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return SecretsManifest()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .secret_manifest_item import SecretManifestItem

        from .secret_manifest_item import SecretManifestItem

        fields: dict[str, Callable[[Any], None]] = {
            "environmentSlug": lambda n : setattr(self, 'environment_slug', n.get_str_value()),
            "generatedAt": lambda n : setattr(self, 'generated_at', n.get_datetime_value()),
            "projectSlug": lambda n : setattr(self, 'project_slug', n.get_str_value()),
            "secrets": lambda n : setattr(self, 'secrets', n.get_collection_of_object_values(SecretManifestItem)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("environmentSlug", self.environment_slug)
        writer.write_datetime_value("generatedAt", self.generated_at)
        writer.write_str_value("projectSlug", self.project_slug)
        writer.write_collection_of_object_values("secrets", self.secrets)
        writer.write_additional_data_value(self.additional_data)
    

