from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .drift_item import DriftItem
    from .drift_summary import DriftSummary

@dataclass
class DriftResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The environments property
    environments: Optional[list[str]] = None
    # The secrets property
    secrets: Optional[list[DriftItem]] = None
    # The summary property
    summary: Optional[DriftSummary] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> DriftResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: DriftResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return DriftResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .drift_item import DriftItem
        from .drift_summary import DriftSummary

        from .drift_item import DriftItem
        from .drift_summary import DriftSummary

        fields: dict[str, Callable[[Any], None]] = {
            "environments": lambda n : setattr(self, 'environments', n.get_collection_of_primitive_values(str)),
            "secrets": lambda n : setattr(self, 'secrets', n.get_collection_of_object_values(DriftItem)),
            "summary": lambda n : setattr(self, 'summary', n.get_object_value(DriftSummary)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_primitive_values("environments", self.environments)
        writer.write_collection_of_object_values("secrets", self.secrets)
        writer.write_object_value("summary", self.summary)
        writer.write_additional_data_value(self.additional_data)
    

