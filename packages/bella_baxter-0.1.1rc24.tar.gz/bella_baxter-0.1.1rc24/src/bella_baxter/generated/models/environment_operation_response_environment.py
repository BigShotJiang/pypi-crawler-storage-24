from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import ComposedTypeWrapper, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .environment_operation_response_environment_member1 import EnvironmentOperationResponse_environmentMember1
    from .environment_response import EnvironmentResponse

@dataclass
class EnvironmentOperationResponse_environment(ComposedTypeWrapper, Parsable):
    """
    Composed type wrapper for classes EnvironmentOperationResponse_environmentMember1, EnvironmentResponse
    """
    # Composed type representation for type EnvironmentOperationResponse_environmentMember1
    environment_operation_response_environment_member1: Optional[EnvironmentOperationResponse_environmentMember1] = None
    # Composed type representation for type EnvironmentResponse
    environment_response: Optional[EnvironmentResponse] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EnvironmentOperationResponse_environment:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EnvironmentOperationResponse_environment
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        result = EnvironmentOperationResponse_environment()
        if mapping_value and mapping_value.casefold() == "".casefold():
            from .environment_operation_response_environment_member1 import EnvironmentOperationResponse_environmentMember1

            result.environment_operation_response_environment_member1 = EnvironmentOperationResponse_environmentMember1()
        elif mapping_value and mapping_value.casefold() == "EnvironmentResponse".casefold():
            from .environment_response import EnvironmentResponse

            result.environment_response = EnvironmentResponse()
        return result
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .environment_operation_response_environment_member1 import EnvironmentOperationResponse_environmentMember1
        from .environment_response import EnvironmentResponse

        if self.environment_operation_response_environment_member1:
            return self.environment_operation_response_environment_member1.get_field_deserializers()
        if self.environment_response:
            return self.environment_response.get_field_deserializers()
        return {}
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        if self.environment_operation_response_environment_member1:
            writer.write_object_value(None, self.environment_operation_response_environment_member1)
        elif self.environment_response:
            writer.write_object_value(None, self.environment_response)
    

