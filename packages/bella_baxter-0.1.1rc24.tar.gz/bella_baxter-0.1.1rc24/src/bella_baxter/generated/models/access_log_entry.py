from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

@dataclass
class AccessLogEntry(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The action property
    action: Optional[str] = None
    # The actorType property
    actor_type: Optional[str] = None
    # The apiKeyId property
    api_key_id: Optional[UUID] = None
    # The apiKeyName property
    api_key_name: Optional[str] = None
    # The appClient property
    app_client: Optional[str] = None
    # The city property
    city: Optional[str] = None
    # The country property
    country: Optional[str] = None
    # The environmentId property
    environment_id: Optional[UUID] = None
    # The environmentSlug property
    environment_slug: Optional[str] = None
    # The id property
    id: Optional[UUID] = None
    # The ipAddress property
    ip_address: Optional[str] = None
    # The projectId property
    project_id: Optional[UUID] = None
    # The projectSlug property
    project_slug: Optional[str] = None
    # The providerId property
    provider_id: Optional[UUID] = None
    # The secretKey property
    secret_key: Optional[str] = None
    # The timestamp property
    timestamp: Optional[datetime.datetime] = None
    # The userAgent property
    user_agent: Optional[str] = None
    # The userId property
    user_id: Optional[UUID] = None
    # The userName property
    user_name: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> AccessLogEntry:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: AccessLogEntry
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return AccessLogEntry()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "action": lambda n : setattr(self, 'action', n.get_str_value()),
            "actorType": lambda n : setattr(self, 'actor_type', n.get_str_value()),
            "apiKeyId": lambda n : setattr(self, 'api_key_id', n.get_uuid_value()),
            "apiKeyName": lambda n : setattr(self, 'api_key_name', n.get_str_value()),
            "appClient": lambda n : setattr(self, 'app_client', n.get_str_value()),
            "city": lambda n : setattr(self, 'city', n.get_str_value()),
            "country": lambda n : setattr(self, 'country', n.get_str_value()),
            "environmentId": lambda n : setattr(self, 'environment_id', n.get_uuid_value()),
            "environmentSlug": lambda n : setattr(self, 'environment_slug', n.get_str_value()),
            "id": lambda n : setattr(self, 'id', n.get_uuid_value()),
            "ipAddress": lambda n : setattr(self, 'ip_address', n.get_str_value()),
            "projectId": lambda n : setattr(self, 'project_id', n.get_uuid_value()),
            "projectSlug": lambda n : setattr(self, 'project_slug', n.get_str_value()),
            "providerId": lambda n : setattr(self, 'provider_id', n.get_uuid_value()),
            "secretKey": lambda n : setattr(self, 'secret_key', n.get_str_value()),
            "timestamp": lambda n : setattr(self, 'timestamp', n.get_datetime_value()),
            "userAgent": lambda n : setattr(self, 'user_agent', n.get_str_value()),
            "userId": lambda n : setattr(self, 'user_id', n.get_uuid_value()),
            "userName": lambda n : setattr(self, 'user_name', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("action", self.action)
        writer.write_str_value("actorType", self.actor_type)
        writer.write_uuid_value("apiKeyId", self.api_key_id)
        writer.write_str_value("apiKeyName", self.api_key_name)
        writer.write_str_value("appClient", self.app_client)
        writer.write_str_value("city", self.city)
        writer.write_str_value("country", self.country)
        writer.write_uuid_value("environmentId", self.environment_id)
        writer.write_str_value("environmentSlug", self.environment_slug)
        writer.write_uuid_value("id", self.id)
        writer.write_str_value("ipAddress", self.ip_address)
        writer.write_uuid_value("projectId", self.project_id)
        writer.write_str_value("projectSlug", self.project_slug)
        writer.write_uuid_value("providerId", self.provider_id)
        writer.write_str_value("secretKey", self.secret_key)
        writer.write_datetime_value("timestamp", self.timestamp)
        writer.write_str_value("userAgent", self.user_agent)
        writer.write_uuid_value("userId", self.user_id)
        writer.write_str_value("userName", self.user_name)
        writer.write_additional_data_value(self.additional_data)
    

