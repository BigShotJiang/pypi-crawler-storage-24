from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .notification_channel_response_public_configuration import NotificationChannelResponse_publicConfiguration

@dataclass
class NotificationChannelResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The channelType property
    channel_type: Optional[str] = None
    # The createdAt property
    created_at: Optional[datetime.datetime] = None
    # The createdBy property
    created_by: Optional[str] = None
    # The environmentId property
    environment_id: Optional[str] = None
    # The eventTypes property
    event_types: Optional[list[str]] = None
    # The id property
    id: Optional[str] = None
    # The isActive property
    is_active: Optional[bool] = None
    # The name property
    name: Optional[str] = None
    # The projectId property
    project_id: Optional[str] = None
    # The publicConfiguration property
    public_configuration: Optional[NotificationChannelResponse_publicConfiguration] = None
    # The sensitiveKeys property
    sensitive_keys: Optional[list[str]] = None
    # The updatedAt property
    updated_at: Optional[datetime.datetime] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> NotificationChannelResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: NotificationChannelResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return NotificationChannelResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .notification_channel_response_public_configuration import NotificationChannelResponse_publicConfiguration

        from .notification_channel_response_public_configuration import NotificationChannelResponse_publicConfiguration

        fields: dict[str, Callable[[Any], None]] = {
            "channelType": lambda n : setattr(self, 'channel_type', n.get_str_value()),
            "createdAt": lambda n : setattr(self, 'created_at', n.get_datetime_value()),
            "createdBy": lambda n : setattr(self, 'created_by', n.get_str_value()),
            "environmentId": lambda n : setattr(self, 'environment_id', n.get_str_value()),
            "eventTypes": lambda n : setattr(self, 'event_types', n.get_collection_of_primitive_values(str)),
            "id": lambda n : setattr(self, 'id', n.get_str_value()),
            "isActive": lambda n : setattr(self, 'is_active', n.get_bool_value()),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
            "projectId": lambda n : setattr(self, 'project_id', n.get_str_value()),
            "publicConfiguration": lambda n : setattr(self, 'public_configuration', n.get_object_value(NotificationChannelResponse_publicConfiguration)),
            "sensitiveKeys": lambda n : setattr(self, 'sensitive_keys', n.get_collection_of_primitive_values(str)),
            "updatedAt": lambda n : setattr(self, 'updated_at', n.get_datetime_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("channelType", self.channel_type)
        writer.write_datetime_value("createdAt", self.created_at)
        writer.write_str_value("createdBy", self.created_by)
        writer.write_str_value("environmentId", self.environment_id)
        writer.write_collection_of_primitive_values("eventTypes", self.event_types)
        writer.write_str_value("id", self.id)
        writer.write_bool_value("isActive", self.is_active)
        writer.write_str_value("name", self.name)
        writer.write_str_value("projectId", self.project_id)
        writer.write_object_value("publicConfiguration", self.public_configuration)
        writer.write_collection_of_primitive_values("sensitiveKeys", self.sensitive_keys)
        writer.write_datetime_value("updatedAt", self.updated_at)
        writer.write_additional_data_value(self.additional_data)
    

