from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class E2EEncryptedPayload(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The algorithm property
    algorithm: Optional[str] = None
    # The ciphertext property
    ciphertext: Optional[str] = None
    # The encrypted property
    encrypted: Optional[bool] = None
    # The nonce property
    nonce: Optional[str] = None
    # The serverPublicKey property
    server_public_key: Optional[str] = None
    # The tag property
    tag: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> E2EEncryptedPayload:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: E2EEncryptedPayload
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return E2EEncryptedPayload()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "algorithm": lambda n : setattr(self, 'algorithm', n.get_str_value()),
            "ciphertext": lambda n : setattr(self, 'ciphertext', n.get_str_value()),
            "encrypted": lambda n : setattr(self, 'encrypted', n.get_bool_value()),
            "nonce": lambda n : setattr(self, 'nonce', n.get_str_value()),
            "serverPublicKey": lambda n : setattr(self, 'server_public_key', n.get_str_value()),
            "tag": lambda n : setattr(self, 'tag', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("algorithm", self.algorithm)
        writer.write_str_value("ciphertext", self.ciphertext)
        writer.write_bool_value("encrypted", self.encrypted)
        writer.write_str_value("nonce", self.nonce)
        writer.write_str_value("serverPublicKey", self.server_public_key)
        writer.write_str_value("tag", self.tag)
        writer.write_additional_data_value(self.additional_data)
    

