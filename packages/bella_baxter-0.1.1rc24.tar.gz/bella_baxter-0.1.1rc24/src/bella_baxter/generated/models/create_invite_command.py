from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .tenant_invite_role import TenantInviteRole

@dataclass
class CreateInviteCommand(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The email property
    email: Optional[str] = None
    # The expiresInDays property
    expires_in_days: Optional[int] = None
    # The role property
    role: Optional[TenantInviteRole] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> CreateInviteCommand:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: CreateInviteCommand
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return CreateInviteCommand()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .tenant_invite_role import TenantInviteRole

        from .tenant_invite_role import TenantInviteRole

        fields: dict[str, Callable[[Any], None]] = {
            "email": lambda n : setattr(self, 'email', n.get_str_value()),
            "expiresInDays": lambda n : setattr(self, 'expires_in_days', n.get_int_value()),
            "role": lambda n : setattr(self, 'role', n.get_enum_value(TenantInviteRole)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("email", self.email)
        writer.write_int_value("expiresInDays", self.expires_in_days)
        writer.write_enum_value("role", self.role)
        writer.write_additional_data_value(self.additional_data)
    

