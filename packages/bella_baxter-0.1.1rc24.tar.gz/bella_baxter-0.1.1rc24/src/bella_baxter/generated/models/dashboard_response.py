from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .access_log_entry import AccessLogEntry
    from .activity_by_day import ActivityByDay
    from .dashboard_count_pair import DashboardCountPair

@dataclass
class DashboardResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The activityByDay property
    activity_by_day: Optional[list[ActivityByDay]] = None
    # The apiKeys property
    api_keys: Optional[DashboardCountPair] = None
    # The environments property
    environments: Optional[DashboardCountPair] = None
    # The projects property
    projects: Optional[DashboardCountPair] = None
    # The providers property
    providers: Optional[int] = None
    # The recentActivity property
    recent_activity: Optional[list[AccessLogEntry]] = None
    # The secrets property
    secrets: Optional[int] = None
    # The users property
    users: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> DashboardResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: DashboardResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return DashboardResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .access_log_entry import AccessLogEntry
        from .activity_by_day import ActivityByDay
        from .dashboard_count_pair import DashboardCountPair

        from .access_log_entry import AccessLogEntry
        from .activity_by_day import ActivityByDay
        from .dashboard_count_pair import DashboardCountPair

        fields: dict[str, Callable[[Any], None]] = {
            "activityByDay": lambda n : setattr(self, 'activity_by_day', n.get_collection_of_object_values(ActivityByDay)),
            "apiKeys": lambda n : setattr(self, 'api_keys', n.get_object_value(DashboardCountPair)),
            "environments": lambda n : setattr(self, 'environments', n.get_object_value(DashboardCountPair)),
            "projects": lambda n : setattr(self, 'projects', n.get_object_value(DashboardCountPair)),
            "providers": lambda n : setattr(self, 'providers', n.get_int_value()),
            "recentActivity": lambda n : setattr(self, 'recent_activity', n.get_collection_of_object_values(AccessLogEntry)),
            "secrets": lambda n : setattr(self, 'secrets', n.get_int_value()),
            "users": lambda n : setattr(self, 'users', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("activityByDay", self.activity_by_day)
        writer.write_object_value("apiKeys", self.api_keys)
        writer.write_object_value("environments", self.environments)
        writer.write_object_value("projects", self.projects)
        writer.write_int_value("providers", self.providers)
        writer.write_collection_of_object_values("recentActivity", self.recent_activity)
        writer.write_int_value("secrets", self.secrets)
        writer.write_int_value("users", self.users)
        writer.write_additional_data_value(self.additional_data)
    

