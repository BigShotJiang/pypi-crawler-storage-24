from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class SshCaPublicKeyResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The ansibleSnippet property
    ansible_snippet: Optional[str] = None
    # The caPublicKey property
    ca_public_key: Optional[str] = None
    # The instructions property
    instructions: Optional[str] = None
    # The terraformSnippet property
    terraform_snippet: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> SshCaPublicKeyResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: SshCaPublicKeyResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return SshCaPublicKeyResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "ansibleSnippet": lambda n : setattr(self, 'ansible_snippet', n.get_str_value()),
            "caPublicKey": lambda n : setattr(self, 'ca_public_key', n.get_str_value()),
            "instructions": lambda n : setattr(self, 'instructions', n.get_str_value()),
            "terraformSnippet": lambda n : setattr(self, 'terraform_snippet', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("ansibleSnippet", self.ansible_snippet)
        writer.write_str_value("caPublicKey", self.ca_public_key)
        writer.write_str_value("instructions", self.instructions)
        writer.write_str_value("terraformSnippet", self.terraform_snippet)
        writer.write_additional_data_value(self.additional_data)
    

