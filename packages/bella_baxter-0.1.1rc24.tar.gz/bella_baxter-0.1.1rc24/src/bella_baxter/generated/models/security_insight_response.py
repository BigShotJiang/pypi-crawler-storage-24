from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class SecurityInsightResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The detail property
    detail: Optional[str] = None
    # The matchedPattern property
    matched_pattern: Optional[str] = None
    # The recommendation property
    recommendation: Optional[str] = None
    # The secretKey property
    secret_key: Optional[str] = None
    # The severity property
    severity: Optional[str] = None
    # The type property
    type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> SecurityInsightResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: SecurityInsightResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return SecurityInsightResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "detail": lambda n : setattr(self, 'detail', n.get_str_value()),
            "matchedPattern": lambda n : setattr(self, 'matched_pattern', n.get_str_value()),
            "recommendation": lambda n : setattr(self, 'recommendation', n.get_str_value()),
            "secretKey": lambda n : setattr(self, 'secret_key', n.get_str_value()),
            "severity": lambda n : setattr(self, 'severity', n.get_str_value()),
            "type": lambda n : setattr(self, 'type', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("detail", self.detail)
        writer.write_str_value("matchedPattern", self.matched_pattern)
        writer.write_str_value("recommendation", self.recommendation)
        writer.write_str_value("secretKey", self.secret_key)
        writer.write_str_value("severity", self.severity)
        writer.write_str_value("type", self.type)
        writer.write_additional_data_value(self.additional_data)
    

