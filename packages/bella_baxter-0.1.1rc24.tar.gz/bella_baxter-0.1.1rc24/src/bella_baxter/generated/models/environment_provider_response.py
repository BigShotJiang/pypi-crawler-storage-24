from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class EnvironmentProviderResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The assignedAt property
    assigned_at: Optional[datetime.datetime] = None
    # The id property
    id: Optional[str] = None
    # The providerDescription property
    provider_description: Optional[str] = None
    # The providerId property
    provider_id: Optional[str] = None
    # The providerName property
    provider_name: Optional[str] = None
    # The providerSlug property
    provider_slug: Optional[str] = None
    # The providerType property
    provider_type: Optional[str] = None
    # The region property
    region: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EnvironmentProviderResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EnvironmentProviderResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return EnvironmentProviderResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "assignedAt": lambda n : setattr(self, 'assigned_at', n.get_datetime_value()),
            "id": lambda n : setattr(self, 'id', n.get_str_value()),
            "providerDescription": lambda n : setattr(self, 'provider_description', n.get_str_value()),
            "providerId": lambda n : setattr(self, 'provider_id', n.get_str_value()),
            "providerName": lambda n : setattr(self, 'provider_name', n.get_str_value()),
            "providerSlug": lambda n : setattr(self, 'provider_slug', n.get_str_value()),
            "providerType": lambda n : setattr(self, 'provider_type', n.get_str_value()),
            "region": lambda n : setattr(self, 'region', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_datetime_value("assignedAt", self.assigned_at)
        writer.write_str_value("id", self.id)
        writer.write_str_value("providerDescription", self.provider_description)
        writer.write_str_value("providerId", self.provider_id)
        writer.write_str_value("providerName", self.provider_name)
        writer.write_str_value("providerSlug", self.provider_slug)
        writer.write_str_value("providerType", self.provider_type)
        writer.write_str_value("region", self.region)
        writer.write_additional_data_value(self.additional_data)
    

