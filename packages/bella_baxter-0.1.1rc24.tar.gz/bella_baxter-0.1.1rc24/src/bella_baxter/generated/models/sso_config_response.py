from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .sso_provider_type import SsoProviderType

@dataclass
class SsoConfigResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The configuredAt property
    configured_at: Optional[datetime.datetime] = None
    # The domains property
    domains: Optional[list[str]] = None
    # The enforced property
    enforced: Optional[bool] = None
    # The idpAlias property
    idp_alias: Optional[str] = None
    # The providerType property
    provider_type: Optional[SsoProviderType] = None
    # The spMetadataUrl property
    sp_metadata_url: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> SsoConfigResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: SsoConfigResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return SsoConfigResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .sso_provider_type import SsoProviderType

        from .sso_provider_type import SsoProviderType

        fields: dict[str, Callable[[Any], None]] = {
            "configuredAt": lambda n : setattr(self, 'configured_at', n.get_datetime_value()),
            "domains": lambda n : setattr(self, 'domains', n.get_collection_of_primitive_values(str)),
            "enforced": lambda n : setattr(self, 'enforced', n.get_bool_value()),
            "idpAlias": lambda n : setattr(self, 'idp_alias', n.get_str_value()),
            "providerType": lambda n : setattr(self, 'provider_type', n.get_enum_value(SsoProviderType)),
            "spMetadataUrl": lambda n : setattr(self, 'sp_metadata_url', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_datetime_value("configuredAt", self.configured_at)
        writer.write_collection_of_primitive_values("domains", self.domains)
        writer.write_bool_value("enforced", self.enforced)
        writer.write_str_value("idpAlias", self.idp_alias)
        writer.write_enum_value("providerType", self.provider_type)
        writer.write_str_value("spMetadataUrl", self.sp_metadata_url)
        writer.write_additional_data_value(self.additional_data)
    

