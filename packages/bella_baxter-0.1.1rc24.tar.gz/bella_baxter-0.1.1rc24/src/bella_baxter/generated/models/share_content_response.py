from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

@dataclass
class ShareContentResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The ciphertext property
    ciphertext: Optional[str] = None
    # The expiresAt property
    expires_at: Optional[datetime.datetime] = None
    # The iv property
    iv: Optional[str] = None
    # The label property
    label: Optional[str] = None
    # The shareId property
    share_id: Optional[UUID] = None
    # The viewsRemaining property
    views_remaining: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ShareContentResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ShareContentResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ShareContentResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "ciphertext": lambda n : setattr(self, 'ciphertext', n.get_str_value()),
            "expiresAt": lambda n : setattr(self, 'expires_at', n.get_datetime_value()),
            "iv": lambda n : setattr(self, 'iv', n.get_str_value()),
            "label": lambda n : setattr(self, 'label', n.get_str_value()),
            "shareId": lambda n : setattr(self, 'share_id', n.get_uuid_value()),
            "viewsRemaining": lambda n : setattr(self, 'views_remaining', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("ciphertext", self.ciphertext)
        writer.write_datetime_value("expiresAt", self.expires_at)
        writer.write_str_value("iv", self.iv)
        writer.write_str_value("label", self.label)
        writer.write_uuid_value("shareId", self.share_id)
        writer.write_int_value("viewsRemaining", self.views_remaining)
        writer.write_additional_data_value(self.additional_data)
    

