from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .import_secrets_request_type_overrides import ImportSecretsRequest_typeOverrides

@dataclass
class ImportSecretsRequest(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The keys property
    keys: Optional[list[str]] = None
    # The overwriteExisting property
    overwrite_existing: Optional[bool] = None
    # The sourceProviderId property
    source_provider_id: Optional[UUID] = None
    # The typeOverrides property
    type_overrides: Optional[ImportSecretsRequest_typeOverrides] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ImportSecretsRequest:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ImportSecretsRequest
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ImportSecretsRequest()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .import_secrets_request_type_overrides import ImportSecretsRequest_typeOverrides

        from .import_secrets_request_type_overrides import ImportSecretsRequest_typeOverrides

        fields: dict[str, Callable[[Any], None]] = {
            "keys": lambda n : setattr(self, 'keys', n.get_collection_of_primitive_values(str)),
            "overwriteExisting": lambda n : setattr(self, 'overwrite_existing', n.get_bool_value()),
            "sourceProviderId": lambda n : setattr(self, 'source_provider_id', n.get_uuid_value()),
            "typeOverrides": lambda n : setattr(self, 'type_overrides', n.get_object_value(ImportSecretsRequest_typeOverrides)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_primitive_values("keys", self.keys)
        writer.write_bool_value("overwriteExisting", self.overwrite_existing)
        writer.write_uuid_value("sourceProviderId", self.source_provider_id)
        writer.write_object_value("typeOverrides", self.type_overrides)
        writer.write_additional_data_value(self.additional_data)
    

