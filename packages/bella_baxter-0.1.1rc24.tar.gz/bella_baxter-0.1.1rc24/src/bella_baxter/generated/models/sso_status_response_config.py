from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import ComposedTypeWrapper, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .sso_config_response import SsoConfigResponse
    from .sso_status_response_config_member1 import SsoStatusResponse_configMember1

@dataclass
class SsoStatusResponse_config(ComposedTypeWrapper, Parsable):
    """
    Composed type wrapper for classes SsoConfigResponse, SsoStatusResponse_configMember1
    """
    # Composed type representation for type SsoConfigResponse
    sso_config_response: Optional[SsoConfigResponse] = None
    # Composed type representation for type SsoStatusResponse_configMember1
    sso_status_response_config_member1: Optional[SsoStatusResponse_configMember1] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> SsoStatusResponse_config:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: SsoStatusResponse_config
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        result = SsoStatusResponse_config()
        if mapping_value and mapping_value.casefold() == "SsoConfigResponse".casefold():
            from .sso_config_response import SsoConfigResponse

            result.sso_config_response = SsoConfigResponse()
        elif mapping_value and mapping_value.casefold() == "".casefold():
            from .sso_status_response_config_member1 import SsoStatusResponse_configMember1

            result.sso_status_response_config_member1 = SsoStatusResponse_configMember1()
        return result
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .sso_config_response import SsoConfigResponse
        from .sso_status_response_config_member1 import SsoStatusResponse_configMember1

        if self.sso_config_response:
            return self.sso_config_response.get_field_deserializers()
        if self.sso_status_response_config_member1:
            return self.sso_status_response_config_member1.get_field_deserializers()
        return {}
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        if self.sso_config_response:
            writer.write_object_value(None, self.sso_config_response)
        elif self.sso_status_response_config_member1:
            writer.write_object_value(None, self.sso_status_response_config_member1)
    

