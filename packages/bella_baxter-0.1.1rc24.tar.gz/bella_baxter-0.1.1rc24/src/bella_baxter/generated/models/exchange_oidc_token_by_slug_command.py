from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class ExchangeOidcTokenBySlugCommand(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The environmentSlug property
    environment_slug: Optional[str] = None
    # The oidcToken property
    oidc_token: Optional[str] = None
    # The projectSlug property
    project_slug: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ExchangeOidcTokenBySlugCommand:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ExchangeOidcTokenBySlugCommand
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ExchangeOidcTokenBySlugCommand()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "environmentSlug": lambda n : setattr(self, 'environment_slug', n.get_str_value()),
            "oidcToken": lambda n : setattr(self, 'oidc_token', n.get_str_value()),
            "projectSlug": lambda n : setattr(self, 'project_slug', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("environmentSlug", self.environment_slug)
        writer.write_str_value("oidcToken", self.oidc_token)
        writer.write_str_value("projectSlug", self.project_slug)
        writer.write_additional_data_value(self.additional_data)
    

