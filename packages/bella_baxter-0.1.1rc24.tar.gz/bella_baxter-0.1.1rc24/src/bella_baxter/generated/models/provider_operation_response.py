from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .provider_operation_response_provider import ProviderOperationResponse_provider

@dataclass
class ProviderOperationResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The message property
    message: Optional[str] = None
    # The provider property
    provider: Optional[ProviderOperationResponse_provider] = None
    # The success property
    success: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ProviderOperationResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ProviderOperationResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ProviderOperationResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .provider_operation_response_provider import ProviderOperationResponse_provider

        from .provider_operation_response_provider import ProviderOperationResponse_provider

        fields: dict[str, Callable[[Any], None]] = {
            "message": lambda n : setattr(self, 'message', n.get_str_value()),
            "provider": lambda n : setattr(self, 'provider', n.get_object_value(ProviderOperationResponse_provider)),
            "success": lambda n : setattr(self, 'success', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("message", self.message)
        writer.write_object_value("provider", self.provider)
        writer.write_bool_value("success", self.success)
        writer.write_additional_data_value(self.additional_data)
    

