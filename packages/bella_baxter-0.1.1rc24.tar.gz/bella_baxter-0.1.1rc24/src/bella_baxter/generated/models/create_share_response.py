from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

@dataclass
class CreateShareResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The expiresAt property
    expires_at: Optional[datetime.datetime] = None
    # The hasPassword property
    has_password: Optional[bool] = None
    # The label property
    label: Optional[str] = None
    # The maxViews property
    max_views: Optional[int] = None
    # The shareId property
    share_id: Optional[UUID] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> CreateShareResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: CreateShareResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return CreateShareResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "expiresAt": lambda n : setattr(self, 'expires_at', n.get_datetime_value()),
            "hasPassword": lambda n : setattr(self, 'has_password', n.get_bool_value()),
            "label": lambda n : setattr(self, 'label', n.get_str_value()),
            "maxViews": lambda n : setattr(self, 'max_views', n.get_int_value()),
            "shareId": lambda n : setattr(self, 'share_id', n.get_uuid_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_datetime_value("expiresAt", self.expires_at)
        writer.write_bool_value("hasPassword", self.has_password)
        writer.write_str_value("label", self.label)
        writer.write_int_value("maxViews", self.max_views)
        writer.write_uuid_value("shareId", self.share_id)
        writer.write_additional_data_value(self.additional_data)
    

