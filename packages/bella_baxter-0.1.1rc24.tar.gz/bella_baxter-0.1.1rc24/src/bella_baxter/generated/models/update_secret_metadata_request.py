from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .update_secret_metadata_request_tags import UpdateSecretMetadataRequest_tags

@dataclass
class UpdateSecretMetadataRequest(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The description property
    description: Optional[str] = None
    # The ignoreInScan property
    ignore_in_scan: Optional[bool] = None
    # The tags property
    tags: Optional[UpdateSecretMetadataRequest_tags] = None
    # The type property
    type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> UpdateSecretMetadataRequest:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: UpdateSecretMetadataRequest
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return UpdateSecretMetadataRequest()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .update_secret_metadata_request_tags import UpdateSecretMetadataRequest_tags

        from .update_secret_metadata_request_tags import UpdateSecretMetadataRequest_tags

        fields: dict[str, Callable[[Any], None]] = {
            "description": lambda n : setattr(self, 'description', n.get_str_value()),
            "ignoreInScan": lambda n : setattr(self, 'ignore_in_scan', n.get_bool_value()),
            "tags": lambda n : setattr(self, 'tags', n.get_object_value(UpdateSecretMetadataRequest_tags)),
            "type": lambda n : setattr(self, 'type', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("description", self.description)
        writer.write_bool_value("ignoreInScan", self.ignore_in_scan)
        writer.write_object_value("tags", self.tags)
        writer.write_str_value("type", self.type)
        writer.write_additional_data_value(self.additional_data)
    

