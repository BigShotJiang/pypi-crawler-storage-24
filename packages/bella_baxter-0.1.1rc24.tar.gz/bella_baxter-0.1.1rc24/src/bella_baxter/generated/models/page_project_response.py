from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .pageable_object import PageableObject
    from .project_response import ProjectResponse
    from .sort_object import SortObject

@dataclass
class PageProjectResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The content property
    content: Optional[list[ProjectResponse]] = None
    # The empty property
    empty: Optional[bool] = None
    # The first property
    first: Optional[bool] = None
    # The last property
    last: Optional[bool] = None
    # The number property
    number: Optional[int] = None
    # The numberOfElements property
    number_of_elements: Optional[int] = None
    # The pageable property
    pageable: Optional[PageableObject] = None
    # The size property
    size: Optional[int] = None
    # The sort property
    sort: Optional[SortObject] = None
    # The totalElements property
    total_elements: Optional[int] = None
    # The totalPages property
    total_pages: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> PageProjectResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: PageProjectResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return PageProjectResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .pageable_object import PageableObject
        from .project_response import ProjectResponse
        from .sort_object import SortObject

        from .pageable_object import PageableObject
        from .project_response import ProjectResponse
        from .sort_object import SortObject

        fields: dict[str, Callable[[Any], None]] = {
            "content": lambda n : setattr(self, 'content', n.get_collection_of_object_values(ProjectResponse)),
            "empty": lambda n : setattr(self, 'empty', n.get_bool_value()),
            "first": lambda n : setattr(self, 'first', n.get_bool_value()),
            "last": lambda n : setattr(self, 'last', n.get_bool_value()),
            "number": lambda n : setattr(self, 'number', n.get_int_value()),
            "numberOfElements": lambda n : setattr(self, 'number_of_elements', n.get_int_value()),
            "pageable": lambda n : setattr(self, 'pageable', n.get_object_value(PageableObject)),
            "size": lambda n : setattr(self, 'size', n.get_int_value()),
            "sort": lambda n : setattr(self, 'sort', n.get_object_value(SortObject)),
            "totalElements": lambda n : setattr(self, 'total_elements', n.get_int_value()),
            "totalPages": lambda n : setattr(self, 'total_pages', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("content", self.content)
        writer.write_bool_value("empty", self.empty)
        writer.write_bool_value("first", self.first)
        writer.write_bool_value("last", self.last)
        writer.write_int_value("number", self.number)
        writer.write_int_value("numberOfElements", self.number_of_elements)
        writer.write_object_value("pageable", self.pageable)
        writer.write_int_value("size", self.size)
        writer.write_object_value("sort", self.sort)
        writer.write_int_value("totalElements", self.total_elements)
        writer.write_int_value("totalPages", self.total_pages)
        writer.write_additional_data_value(self.additional_data)
    

