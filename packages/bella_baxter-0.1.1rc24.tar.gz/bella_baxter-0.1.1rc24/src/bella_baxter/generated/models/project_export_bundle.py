from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .environment_export_info import EnvironmentExportInfo
    from .project_export_info import ProjectExportInfo
    from .provider_export_info import ProviderExportInfo

@dataclass
class ProjectExportBundle(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The environments property
    environments: Optional[list[EnvironmentExportInfo]] = None
    # The exportVersion property
    export_version: Optional[str] = None
    # The exportedAt property
    exported_at: Optional[datetime.datetime] = None
    # The project property
    project: Optional[ProjectExportInfo] = None
    # The providers property
    providers: Optional[list[ProviderExportInfo]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ProjectExportBundle:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ProjectExportBundle
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return ProjectExportBundle()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .environment_export_info import EnvironmentExportInfo
        from .project_export_info import ProjectExportInfo
        from .provider_export_info import ProviderExportInfo

        from .environment_export_info import EnvironmentExportInfo
        from .project_export_info import ProjectExportInfo
        from .provider_export_info import ProviderExportInfo

        fields: dict[str, Callable[[Any], None]] = {
            "environments": lambda n : setattr(self, 'environments', n.get_collection_of_object_values(EnvironmentExportInfo)),
            "exportVersion": lambda n : setattr(self, 'export_version', n.get_str_value()),
            "exportedAt": lambda n : setattr(self, 'exported_at', n.get_datetime_value()),
            "project": lambda n : setattr(self, 'project', n.get_object_value(ProjectExportInfo)),
            "providers": lambda n : setattr(self, 'providers', n.get_collection_of_object_values(ProviderExportInfo)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_object_values("environments", self.environments)
        writer.write_str_value("exportVersion", self.export_version)
        writer.write_datetime_value("exportedAt", self.exported_at)
        writer.write_object_value("project", self.project)
        writer.write_collection_of_object_values("providers", self.providers)
        writer.write_additional_data_value(self.additional_data)
    

