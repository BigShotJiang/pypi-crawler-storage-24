from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import ComposedTypeWrapper, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .api_key_operation_response_api_key_member1 import ApiKeyOperationResponse_apiKeyMember1
    from .api_key_response import ApiKeyResponse

@dataclass
class ApiKeyOperationResponse_apiKey(ComposedTypeWrapper, Parsable):
    """
    Composed type wrapper for classes ApiKeyOperationResponse_apiKeyMember1, ApiKeyResponse
    """
    # Composed type representation for type ApiKeyOperationResponse_apiKeyMember1
    api_key_operation_response_api_key_member1: Optional[ApiKeyOperationResponse_apiKeyMember1] = None
    # Composed type representation for type ApiKeyResponse
    api_key_response: Optional[ApiKeyResponse] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ApiKeyOperationResponse_apiKey:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ApiKeyOperationResponse_apiKey
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        result = ApiKeyOperationResponse_apiKey()
        if mapping_value and mapping_value.casefold() == "".casefold():
            from .api_key_operation_response_api_key_member1 import ApiKeyOperationResponse_apiKeyMember1

            result.api_key_operation_response_api_key_member1 = ApiKeyOperationResponse_apiKeyMember1()
        elif mapping_value and mapping_value.casefold() == "ApiKeyResponse".casefold():
            from .api_key_response import ApiKeyResponse

            result.api_key_response = ApiKeyResponse()
        return result
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .api_key_operation_response_api_key_member1 import ApiKeyOperationResponse_apiKeyMember1
        from .api_key_response import ApiKeyResponse

        if self.api_key_operation_response_api_key_member1:
            return self.api_key_operation_response_api_key_member1.get_field_deserializers()
        if self.api_key_response:
            return self.api_key_response.get_field_deserializers()
        return {}
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        if self.api_key_operation_response_api_key_member1:
            writer.write_object_value(None, self.api_key_operation_response_api_key_member1)
        elif self.api_key_response:
            writer.write_object_value(None, self.api_key_response)
    

