from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import ComposedTypeWrapper, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .project_global_security_report import ProjectGlobalSecurityReport
    from .project_security_response_global_secrets_member1 import ProjectSecurityResponse_globalSecretsMember1

@dataclass
class ProjectSecurityResponse_globalSecrets(ComposedTypeWrapper, Parsable):
    """
    Composed type wrapper for classes ProjectGlobalSecurityReport, ProjectSecurityResponse_globalSecretsMember1
    """
    # Composed type representation for type ProjectGlobalSecurityReport
    project_global_security_report: Optional[ProjectGlobalSecurityReport] = None
    # Composed type representation for type ProjectSecurityResponse_globalSecretsMember1
    project_security_response_global_secrets_member1: Optional[ProjectSecurityResponse_globalSecretsMember1] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> ProjectSecurityResponse_globalSecrets:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: ProjectSecurityResponse_globalSecrets
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        result = ProjectSecurityResponse_globalSecrets()
        if mapping_value and mapping_value.casefold() == "ProjectGlobalSecurityReport".casefold():
            from .project_global_security_report import ProjectGlobalSecurityReport

            result.project_global_security_report = ProjectGlobalSecurityReport()
        elif mapping_value and mapping_value.casefold() == "".casefold():
            from .project_security_response_global_secrets_member1 import ProjectSecurityResponse_globalSecretsMember1

            result.project_security_response_global_secrets_member1 = ProjectSecurityResponse_globalSecretsMember1()
        return result
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .project_global_security_report import ProjectGlobalSecurityReport
        from .project_security_response_global_secrets_member1 import ProjectSecurityResponse_globalSecretsMember1

        if self.project_global_security_report:
            return self.project_global_security_report.get_field_deserializers()
        if self.project_security_response_global_secrets_member1:
            return self.project_security_response_global_secrets_member1.get_field_deserializers()
        return {}
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        if self.project_global_security_report:
            writer.write_object_value(None, self.project_global_security_report)
        elif self.project_security_response_global_secrets_member1:
            writer.write_object_value(None, self.project_security_response_global_secrets_member1)
    

