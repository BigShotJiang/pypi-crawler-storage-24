from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import ComposedTypeWrapper, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .create_user_response_user_member1 import CreateUserResponse_userMember1
    from .user_response import UserResponse

@dataclass
class CreateUserResponse_user(ComposedTypeWrapper, Parsable):
    """
    Composed type wrapper for classes CreateUserResponse_userMember1, UserResponse
    """
    # Composed type representation for type CreateUserResponse_userMember1
    create_user_response_user_member1: Optional[CreateUserResponse_userMember1] = None
    # Composed type representation for type UserResponse
    user_response: Optional[UserResponse] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> CreateUserResponse_user:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: CreateUserResponse_user
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        result = CreateUserResponse_user()
        if mapping_value and mapping_value.casefold() == "".casefold():
            from .create_user_response_user_member1 import CreateUserResponse_userMember1

            result.create_user_response_user_member1 = CreateUserResponse_userMember1()
        elif mapping_value and mapping_value.casefold() == "UserResponse".casefold():
            from .user_response import UserResponse

            result.user_response = UserResponse()
        return result
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .create_user_response_user_member1 import CreateUserResponse_userMember1
        from .user_response import UserResponse

        if self.create_user_response_user_member1:
            return self.create_user_response_user_member1.get_field_deserializers()
        if self.user_response:
            return self.user_response.get_field_deserializers()
        return {}
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        if self.create_user_response_user_member1:
            writer.write_object_value(None, self.create_user_response_user_member1)
        elif self.user_response:
            writer.write_object_value(None, self.user_response)
    

