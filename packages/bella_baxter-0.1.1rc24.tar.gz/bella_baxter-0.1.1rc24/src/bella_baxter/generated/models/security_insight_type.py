from enum import Enum

class SecurityInsightType(str, Enum):
    WeakEntropy = "WeakEntropy",
    KnownBreached = "KnownBreached",
    KnownKeyFormat = "KnownKeyFormat",
    KnownBadValue = "KnownBadValue",
    StaleSecret = "StaleSecret",
    DuplicateAcrossEnvironments = "DuplicateAcrossEnvironments",
    PolicyViolation = "PolicyViolation",
    AnomalousAccess = "AnomalousAccess",

