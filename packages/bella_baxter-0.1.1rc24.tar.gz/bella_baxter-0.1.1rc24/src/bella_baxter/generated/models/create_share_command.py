from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class CreateShareCommand(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The ciphertext property
    ciphertext: Optional[str] = None
    # The expiresAt property
    expires_at: Optional[datetime.datetime] = None
    # The iv property
    iv: Optional[str] = None
    # The label property
    label: Optional[str] = None
    # The maxViews property
    max_views: Optional[int] = None
    # The passwordHash property
    password_hash: Optional[str] = None
    # The passwordSalt property
    password_salt: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> CreateShareCommand:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: CreateShareCommand
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return CreateShareCommand()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "ciphertext": lambda n : setattr(self, 'ciphertext', n.get_str_value()),
            "expiresAt": lambda n : setattr(self, 'expires_at', n.get_datetime_value()),
            "iv": lambda n : setattr(self, 'iv', n.get_str_value()),
            "label": lambda n : setattr(self, 'label', n.get_str_value()),
            "maxViews": lambda n : setattr(self, 'max_views', n.get_int_value()),
            "passwordHash": lambda n : setattr(self, 'password_hash', n.get_str_value()),
            "passwordSalt": lambda n : setattr(self, 'password_salt', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("ciphertext", self.ciphertext)
        writer.write_datetime_value("expiresAt", self.expires_at)
        writer.write_str_value("iv", self.iv)
        writer.write_str_value("label", self.label)
        writer.write_int_value("maxViews", self.max_views)
        writer.write_str_value("passwordHash", self.password_hash)
        writer.write_str_value("passwordSalt", self.password_salt)
        writer.write_additional_data_value(self.additional_data)
    

