from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class EnvironmentDriftItem(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The envSpecific property
    env_specific: Optional[bool] = None
    # The inheritedIn property
    inherited_in: Optional[list[str]] = None
    # The isGlobal property
    is_global: Optional[bool] = None
    # The key property
    key: Optional[str] = None
    # The missingInSiblings property
    missing_in_siblings: Optional[list[str]] = None
    # The presentHere property
    present_here: Optional[bool] = None
    # The presentInSiblings property
    present_in_siblings: Optional[list[str]] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EnvironmentDriftItem:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EnvironmentDriftItem
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return EnvironmentDriftItem()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "envSpecific": lambda n : setattr(self, 'env_specific', n.get_bool_value()),
            "inheritedIn": lambda n : setattr(self, 'inherited_in', n.get_collection_of_primitive_values(str)),
            "isGlobal": lambda n : setattr(self, 'is_global', n.get_bool_value()),
            "key": lambda n : setattr(self, 'key', n.get_str_value()),
            "missingInSiblings": lambda n : setattr(self, 'missing_in_siblings', n.get_collection_of_primitive_values(str)),
            "presentHere": lambda n : setattr(self, 'present_here', n.get_bool_value()),
            "presentInSiblings": lambda n : setattr(self, 'present_in_siblings', n.get_collection_of_primitive_values(str)),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_bool_value("envSpecific", self.env_specific)
        writer.write_collection_of_primitive_values("inheritedIn", self.inherited_in)
        writer.write_bool_value("isGlobal", self.is_global)
        writer.write_str_value("key", self.key)
        writer.write_collection_of_primitive_values("missingInSiblings", self.missing_in_siblings)
        writer.write_bool_value("presentHere", self.present_here)
        writer.write_collection_of_primitive_values("presentInSiblings", self.present_in_siblings)
        writer.write_additional_data_value(self.additional_data)
    

