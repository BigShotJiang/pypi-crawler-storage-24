from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class SecurityReportSummary(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The critical property
    critical: Optional[int] = None
    # The high property
    high: Optional[int] = None
    # The low property
    low: Optional[int] = None
    # The medium property
    medium: Optional[int] = None
    # The passed property
    passed: Optional[int] = None
    # The totalScanned property
    total_scanned: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> SecurityReportSummary:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: SecurityReportSummary
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return SecurityReportSummary()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "critical": lambda n : setattr(self, 'critical', n.get_int_value()),
            "high": lambda n : setattr(self, 'high', n.get_int_value()),
            "low": lambda n : setattr(self, 'low', n.get_int_value()),
            "medium": lambda n : setattr(self, 'medium', n.get_int_value()),
            "passed": lambda n : setattr(self, 'passed', n.get_int_value()),
            "totalScanned": lambda n : setattr(self, 'total_scanned', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("critical", self.critical)
        writer.write_int_value("high", self.high)
        writer.write_int_value("low", self.low)
        writer.write_int_value("medium", self.medium)
        writer.write_int_value("passed", self.passed)
        writer.write_int_value("totalScanned", self.total_scanned)
        writer.write_additional_data_value(self.additional_data)
    

