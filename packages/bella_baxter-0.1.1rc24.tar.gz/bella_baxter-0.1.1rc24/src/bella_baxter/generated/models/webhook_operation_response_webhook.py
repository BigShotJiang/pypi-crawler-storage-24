from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import ComposedTypeWrapper, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .webhook_operation_response_webhook_member1 import WebhookOperationResponse_webhookMember1
    from .webhook_response import WebhookResponse

@dataclass
class WebhookOperationResponse_webhook(ComposedTypeWrapper, Parsable):
    """
    Composed type wrapper for classes WebhookOperationResponse_webhookMember1, WebhookResponse
    """
    # Composed type representation for type WebhookOperationResponse_webhookMember1
    webhook_operation_response_webhook_member1: Optional[WebhookOperationResponse_webhookMember1] = None
    # Composed type representation for type WebhookResponse
    webhook_response: Optional[WebhookResponse] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> WebhookOperationResponse_webhook:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: WebhookOperationResponse_webhook
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        try:
            child_node = parse_node.get_child_node("")
            mapping_value = child_node.get_str_value() if child_node else None
        except AttributeError:
            mapping_value = None
        result = WebhookOperationResponse_webhook()
        if mapping_value and mapping_value.casefold() == "".casefold():
            from .webhook_operation_response_webhook_member1 import WebhookOperationResponse_webhookMember1

            result.webhook_operation_response_webhook_member1 = WebhookOperationResponse_webhookMember1()
        elif mapping_value and mapping_value.casefold() == "WebhookResponse".casefold():
            from .webhook_response import WebhookResponse

            result.webhook_response = WebhookResponse()
        return result
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .webhook_operation_response_webhook_member1 import WebhookOperationResponse_webhookMember1
        from .webhook_response import WebhookResponse

        if self.webhook_operation_response_webhook_member1:
            return self.webhook_operation_response_webhook_member1.get_field_deserializers()
        if self.webhook_response:
            return self.webhook_response.get_field_deserializers()
        return {}
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        if self.webhook_operation_response_webhook_member1:
            writer.write_object_value(None, self.webhook_operation_response_webhook_member1)
        elif self.webhook_response:
            writer.write_object_value(None, self.webhook_response)
    

