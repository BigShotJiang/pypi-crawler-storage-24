from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class AuthDiagnostics(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The configuredKeycloakUrl property
    configured_keycloak_url: Optional[str] = None
    # The expectedIssuer property
    expected_issuer: Optional[str] = None
    # The hasAuthorizationHeader property
    has_authorization_header: Optional[bool] = None
    # The isAuthenticated property
    is_authenticated: Optional[bool] = None
    # The tokenAudience property
    token_audience: Optional[str] = None
    # The tokenClaims property
    token_claims: Optional[list[str]] = None
    # The tokenIssuer property
    token_issuer: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> AuthDiagnostics:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: AuthDiagnostics
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return AuthDiagnostics()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "configuredKeycloakUrl": lambda n : setattr(self, 'configured_keycloak_url', n.get_str_value()),
            "expectedIssuer": lambda n : setattr(self, 'expected_issuer', n.get_str_value()),
            "hasAuthorizationHeader": lambda n : setattr(self, 'has_authorization_header', n.get_bool_value()),
            "isAuthenticated": lambda n : setattr(self, 'is_authenticated', n.get_bool_value()),
            "tokenAudience": lambda n : setattr(self, 'token_audience', n.get_str_value()),
            "tokenClaims": lambda n : setattr(self, 'token_claims', n.get_collection_of_primitive_values(str)),
            "tokenIssuer": lambda n : setattr(self, 'token_issuer', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("configuredKeycloakUrl", self.configured_keycloak_url)
        writer.write_str_value("expectedIssuer", self.expected_issuer)
        writer.write_bool_value("hasAuthorizationHeader", self.has_authorization_header)
        writer.write_bool_value("isAuthenticated", self.is_authenticated)
        writer.write_str_value("tokenAudience", self.token_audience)
        writer.write_collection_of_primitive_values("tokenClaims", self.token_claims)
        writer.write_str_value("tokenIssuer", self.token_issuer)
        writer.write_additional_data_value(self.additional_data)
    

