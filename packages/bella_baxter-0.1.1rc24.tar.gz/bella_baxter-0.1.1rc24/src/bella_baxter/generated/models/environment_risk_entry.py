from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

@dataclass
class EnvironmentRiskEntry(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The critical property
    critical: Optional[int] = None
    # The environmentId property
    environment_id: Optional[UUID] = None
    # The environmentSlug property
    environment_slug: Optional[str] = None
    # The high property
    high: Optional[int] = None
    # The low property
    low: Optional[int] = None
    # The medium property
    medium: Optional[int] = None
    # The overallRisk property
    overall_risk: Optional[str] = None
    # The projectId property
    project_id: Optional[UUID] = None
    # The projectSlug property
    project_slug: Optional[str] = None
    # The scannedAt property
    scanned_at: Optional[datetime.datetime] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EnvironmentRiskEntry:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EnvironmentRiskEntry
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return EnvironmentRiskEntry()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "critical": lambda n : setattr(self, 'critical', n.get_int_value()),
            "environmentId": lambda n : setattr(self, 'environment_id', n.get_uuid_value()),
            "environmentSlug": lambda n : setattr(self, 'environment_slug', n.get_str_value()),
            "high": lambda n : setattr(self, 'high', n.get_int_value()),
            "low": lambda n : setattr(self, 'low', n.get_int_value()),
            "medium": lambda n : setattr(self, 'medium', n.get_int_value()),
            "overallRisk": lambda n : setattr(self, 'overall_risk', n.get_str_value()),
            "projectId": lambda n : setattr(self, 'project_id', n.get_uuid_value()),
            "projectSlug": lambda n : setattr(self, 'project_slug', n.get_str_value()),
            "scannedAt": lambda n : setattr(self, 'scanned_at', n.get_datetime_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("critical", self.critical)
        writer.write_uuid_value("environmentId", self.environment_id)
        writer.write_str_value("environmentSlug", self.environment_slug)
        writer.write_int_value("high", self.high)
        writer.write_int_value("low", self.low)
        writer.write_int_value("medium", self.medium)
        writer.write_str_value("overallRisk", self.overall_risk)
        writer.write_uuid_value("projectId", self.project_id)
        writer.write_str_value("projectSlug", self.project_slug)
        writer.write_datetime_value("scannedAt", self.scanned_at)
        writer.write_additional_data_value(self.additional_data)
    

