from enum import Enum

class TenantRole(str, Enum):
    Owner = "Owner",
    Admin = "Admin",
    User = "User",
    Viewer = "Viewer",

