from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

@dataclass
class EnvironmentSecuritySummaryEntry(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The critical property
    critical: Optional[int] = None
    # The environmentId property
    environment_id: Optional[UUID] = None
    # The environmentSlug property
    environment_slug: Optional[str] = None
    # The high property
    high: Optional[int] = None
    # The low property
    low: Optional[int] = None
    # The medium property
    medium: Optional[int] = None
    # The overallRisk property
    overall_risk: Optional[str] = None
    # The providerFetchFailed property
    provider_fetch_failed: Optional[bool] = None
    # The scannedAt property
    scanned_at: Optional[datetime.datetime] = None
    # The totalSecretsScanned property
    total_secrets_scanned: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> EnvironmentSecuritySummaryEntry:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: EnvironmentSecuritySummaryEntry
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return EnvironmentSecuritySummaryEntry()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "critical": lambda n : setattr(self, 'critical', n.get_int_value()),
            "environmentId": lambda n : setattr(self, 'environment_id', n.get_uuid_value()),
            "environmentSlug": lambda n : setattr(self, 'environment_slug', n.get_str_value()),
            "high": lambda n : setattr(self, 'high', n.get_int_value()),
            "low": lambda n : setattr(self, 'low', n.get_int_value()),
            "medium": lambda n : setattr(self, 'medium', n.get_int_value()),
            "overallRisk": lambda n : setattr(self, 'overall_risk', n.get_str_value()),
            "providerFetchFailed": lambda n : setattr(self, 'provider_fetch_failed', n.get_bool_value()),
            "scannedAt": lambda n : setattr(self, 'scanned_at', n.get_datetime_value()),
            "totalSecretsScanned": lambda n : setattr(self, 'total_secrets_scanned', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_int_value("critical", self.critical)
        writer.write_uuid_value("environmentId", self.environment_id)
        writer.write_str_value("environmentSlug", self.environment_slug)
        writer.write_int_value("high", self.high)
        writer.write_int_value("low", self.low)
        writer.write_int_value("medium", self.medium)
        writer.write_str_value("overallRisk", self.overall_risk)
        writer.write_bool_value("providerFetchFailed", self.provider_fetch_failed)
        writer.write_datetime_value("scannedAt", self.scanned_at)
        writer.write_int_value("totalSecretsScanned", self.total_secrets_scanned)
        writer.write_additional_data_value(self.additional_data)
    

