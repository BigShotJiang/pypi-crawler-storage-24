from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .sso_status_response_config import SsoStatusResponse_config

@dataclass
class SsoStatusResponse(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The approvalStatus property
    approval_status: Optional[str] = None
    # The config property
    config: Optional[SsoStatusResponse_config] = None
    # The rejectionReason property
    rejection_reason: Optional[str] = None
    # The requestedAt property
    requested_at: Optional[datetime.datetime] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> SsoStatusResponse:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: SsoStatusResponse
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return SsoStatusResponse()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .sso_status_response_config import SsoStatusResponse_config

        from .sso_status_response_config import SsoStatusResponse_config

        fields: dict[str, Callable[[Any], None]] = {
            "approvalStatus": lambda n : setattr(self, 'approval_status', n.get_str_value()),
            "config": lambda n : setattr(self, 'config', n.get_object_value(SsoStatusResponse_config)),
            "rejectionReason": lambda n : setattr(self, 'rejection_reason', n.get_str_value()),
            "requestedAt": lambda n : setattr(self, 'requested_at', n.get_datetime_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("approvalStatus", self.approval_status)
        writer.write_object_value("config", self.config)
        writer.write_str_value("rejectionReason", self.rejection_reason)
        writer.write_datetime_value("requestedAt", self.requested_at)
        writer.write_additional_data_value(self.additional_data)
    

