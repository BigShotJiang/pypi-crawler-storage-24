"""
Real integration tests for the Gemini provider.
Requires GEMINI_API_KEY in .env file.
"""
import os
import pytest
from dotenv import load_dotenv

load_dotenv()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
SKIP_REASON = "GEMINI_API_KEY not set in .env"


@pytest.mark.skipif(not GEMINI_API_KEY, reason=SKIP_REASON)
class TestGeminiProviderReal:
    """Test GeminiProvider with real API calls."""

    @pytest.fixture(autouse=True)
    def setup_provider(self):
        from fogcutter.providers.gemini import GeminiProvider
        self.provider = GeminiProvider(
            model="gemini-flash-latest",
            api_key=GEMINI_API_KEY,
        )

    def test_sample_returns_response(self):
        """Basic sync sample should return a non-empty list of strings."""
        results = self.provider.sample("What is 2 + 2? Answer in one word.", n=1, temperature=0.0)
        assert len(results) == 1, f"Expected 1 result, got {len(results)}"
        assert isinstance(results[0], str)
        assert len(results[0]) > 0, "Response should not be empty"
        print(f"  Response: {results[0]}")

    def test_sample_multiple(self):
        """Sampling n=3 should return 3 responses."""
        results = self.provider.sample(
            "What is the capital of Japan? Answer in one word.",
            n=3,
            temperature=0.7,
        )
        assert len(results) == 3, f"Expected 3 results, got {len(results)}"
        for i, r in enumerate(results):
            assert isinstance(r, str)
            print(f"  Response {i+1}: {r}")

    @pytest.mark.asyncio
    async def test_sample_async_returns_response(self):
        """Async sample should return responses."""
        results = await self.provider.sample_async(
            "What color is the sky on a clear day? One word.",
            n=1,
            temperature=0.0,
        )
        assert len(results) >= 1, f"Expected ≥1 result, got {len(results)}"
        assert isinstance(results[0], str)
        print(f"  Async response: {results[0]}")

    @pytest.mark.asyncio
    async def test_sample_async_multiple(self):
        """Async sample n=5 should return 5 parallel responses."""
        results = await self.provider.sample_async(
            "Name any color. One word only.",
            n=5,
            temperature=1.0,
        )
        assert len(results) >= 3, f"Expected ≥3 results, got {len(results)} (some may fail)"
        for i, r in enumerate(results):
            print(f"  Async response {i+1}: {r}")

    def test_factual_question_accuracy(self):
        """Test that the model gives correct factual answers."""
        results = self.provider.sample(
            "What is the chemical symbol for water? Reply with just the symbol.",
            n=1,
            temperature=0.0,
        )
        assert "H2O" in results[0].upper().replace(" ", ""), f"Expected H2O, got: {results[0]}"
