"""
Real integration tests for blackbox self-reflection scoring.
Requires GEMINI_API_KEY in .env file.
"""
import os
import pytest
from dotenv import load_dotenv

load_dotenv()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
SKIP_REASON = "GEMINI_API_KEY not set in .env"


@pytest.mark.skipif(not GEMINI_API_KEY, reason=SKIP_REASON)
class TestSelfReflectionReal:
    """Test self-reflection scoring with real Gemini API calls."""

    @pytest.fixture(autouse=True)
    def setup_provider(self):
        from fogcutter.providers.gemini import GeminiProvider
        self.provider = GeminiProvider(
            model="gemini-flash-latest",
            api_key=GEMINI_API_KEY,
        )

    @pytest.mark.asyncio
    async def test_correct_answer_high_score(self):
        """A clearly correct answer should get a high reflection score."""
        from fogcutter.blackbox.reflection import self_reflection_score

        score = await self_reflection_score(
            self.provider,
            query="What is the capital of France?",
            answer="The capital of France is Paris.",
        )
        print(f"  Reflection score (correct answer): {score}")
        assert isinstance(score, float)
        assert score >= 0.5, f"Expected ≥0.5 for correct answer, got {score}"

    @pytest.mark.asyncio
    async def test_wrong_answer_low_score(self):
        """A clearly wrong answer should get a low reflection score."""
        from fogcutter.blackbox.reflection import self_reflection_score

        score = await self_reflection_score(
            self.provider,
            query="What is the capital of France?",
            answer="The capital of France is Tokyo.",
        )
        print(f"  Reflection score (wrong answer): {score}")
        assert isinstance(score, float)
        assert score <= 0.5, f"Expected ≤0.5 for wrong answer, got {score}"

    @pytest.mark.asyncio
    async def test_score_in_valid_range(self):
        """Reflection score should always be between 0.0 and 1.0."""
        from fogcutter.blackbox.reflection import self_reflection_score

        score = await self_reflection_score(
            self.provider,
            query="What is 2 + 2?",
            answer="4",
        )
        print(f"  Reflection score (2+2=4): {score}")
        assert 0.0 <= score <= 1.0, f"Score {score} is out of [0.0, 1.0] range"
