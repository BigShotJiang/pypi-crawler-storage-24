"""
Real integration tests for blackbox consistency scoring.
Uses a local CrossEncoder model — no API key required.
"""
import os
import pytest
from fogcutter.blackbox.consistency import semantic_consistency_score


class TestSemanticConsistencyReal:
    """Test consistency scoring with real semantic similarity model."""

    def test_identical_answers_score_1(self):
        """All identical answers → consistency should be 1.0."""
        os.environ["FOGCUTTER_GEMINI_MODEL"] = "gemini-2.0-flash"
        os.environ["FOGCUTTER_DEFAULT_PROVIDER"] = "gemini"
        answers = ["Paris", "Paris", "Paris", "Paris", "Paris"]
        score = semantic_consistency_score(answers)
        assert score == 1.0, f"Expected 1.0 for identical answers, got {score}"

    def test_semantically_equivalent_answers(self):
        """Semantically similar answers should cluster together → high score."""
        # The user's requested change was syntactically incorrect as it placed
        # a Python statement inside a list definition.
        # Assuming the intent was to set the environment variables for the model
        # as done in other tests, or to ensure the model is set for this test.
        # The existing test already relies on environment variables.
        # If the intent was to use GeminiProvider directly, the call to
        # semantic_consistency_score would need to be modified to accept it.
        # For now, I'm making the minimal change to ensure the model is set
        # via environment variables, consistent with the existing tests,
        # and interpreting "Update model name in tests to gemini-2.0-flash"
        # as ensuring this model is used.
        os.environ["FOGCUTTER_GEMINI_MODEL"] = "gemini-2.0-flash"
        os.environ["FOGCUTTER_DEFAULT_PROVIDER"] = "gemini"
        answers = [
            "The capital of France is Paris.",
            "Paris is the capital of France.",
            "It's Paris.",
            "Paris",
            "The answer is Paris, the capital city of France.",
        ]
        score = semantic_consistency_score(answers)
        assert score >= 0.5, f"Expected ≥0.5 for semantically equivalent answers, got {score}"

    def test_contradictory_answers(self):
        """Completely different answers → low consistency score."""
        answers = [
            "The capital of France is Paris.",
            "The largest planet is Jupiter.",
            "Water boils at 100 degrees Celsius.",
            "Python is a programming language.",
            "The speed of light is 299,792 km/s.",
        ]
        score = semantic_consistency_score(answers)
        assert score <= 0.4, f"Expected ≤0.4 for contradictory answers, got {score}"

    def test_mixed_answers(self):
        """Some matching, some not → medium consistency score."""
        answers = [
            "Paris is the capital of France.",
            "The capital of France is Paris.",
            "Paris",
            "London is the capital of England.",
            "I'm not sure about this question.",
        ]
        score = semantic_consistency_score(answers)
        assert 0.4 <= score <= 0.9, f"Expected 0.4-0.9 for mixed answers, got {score}"

    def test_empty_list_returns_zero(self):
        """Empty list should return 0.0."""
        score = semantic_consistency_score([])
        assert score == 0.0

    def test_single_answer_returns_one(self):
        """Single answer should return 1.0."""
        score = semantic_consistency_score(["Paris"])
        assert score == 1.0
