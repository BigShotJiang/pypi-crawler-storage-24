"""
Real end-to-end integration tests for the FogCutter pipeline.
Requires GEMINI_API_KEY in .env file.
"""
import os
import pytest
from dotenv import load_dotenv

load_dotenv()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
SKIP_REASON = "GEMINI_API_KEY not set in .env"


@pytest.mark.skipif(not GEMINI_API_KEY, reason=SKIP_REASON)
class TestPipelineEndToEnd:
    """Full end-to-end pipeline tests with real LLM calls."""

    @pytest.fixture(autouse=True)
    def setup_env(self):
        """Set environment variables for the pipeline config."""
        os.environ["FOGCUTTER_GEMINI_MODEL"] = "gemini-flash-latest"
        os.environ["FOGCUTTER_DEFAULT_PROVIDER"] = "gemini"

    @pytest.mark.asyncio
    async def test_pipeline_factual_question(self):
        """Pipeline should return high confidence for a simple factual question."""
        import google.generativeai as genai
        genai.configure(api_key=GEMINI_API_KEY)

        from fogcutter.pipeline import FogCutterPipeline

        pipeline = FogCutterPipeline()
        result = await pipeline.run("What is the capital of France?", num_samples=3)

        print(f"\n  Pipeline result:")
        print(f"    Consistency: {result['consistency_score']:.4f}")
        print(f"    Reflection:  {result['reflection_score']:.4f}")
        print(f"    Status:      {result['status']}")
        print(f"    Best answer: {result['best_answer'][:100]}")

        # Validate structure
        assert "query" in result
        assert "consistency_score" in result
        assert "reflection_score" in result
        assert "status" in result
        assert "answers" in result
        assert "best_answer" in result

        # Validate types
        assert isinstance(result["consistency_score"], float)
        assert isinstance(result["reflection_score"], float)
        assert isinstance(result["answers"], list)
        assert len(result["answers"]) >= 1

        # For a simple factual question, we expect reasonable confidence
        assert result["consistency_score"] > 0.0
        assert result["reflection_score"] >= 0.0

    @pytest.mark.asyncio
    async def test_pipeline_returns_answers(self):
        """Pipeline should return actual text answers, not empty strings."""
        import google.generativeai as genai
        genai.configure(api_key=GEMINI_API_KEY)

        from fogcutter.pipeline import FogCutterPipeline

        pipeline = FogCutterPipeline()
        result = await pipeline.run("What is 2 + 2?", num_samples=2)

        assert len(result["answers"]) >= 1
        for answer in result["answers"]:
            assert isinstance(answer, str)
            assert len(answer) > 0, "Answer should not be empty"
            print(f"    Answer: {answer[:80]}")
