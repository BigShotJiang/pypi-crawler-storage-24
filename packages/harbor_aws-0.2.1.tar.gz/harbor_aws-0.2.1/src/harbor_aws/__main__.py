"""CLI entry point: python -m harbor_aws <command>

Commands:
    deploy   - Create harbor-aws EKS infrastructure in your AWS account
    status   - Check if infrastructure is deployed
    stop     - Delete all running pods (keeps infrastructure)
    destroy  - Tear down everything
"""

from __future__ import annotations

import argparse
import logging
import sys


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="harbor-aws",
        description="Harbor AWS — manage EKS/Fargate infrastructure for benchmarks",
    )
    parser.add_argument("-v", "--verbose", action="store_true", help="verbose output")

    sub = parser.add_subparsers(dest="command")

    # deploy
    deploy_p = sub.add_parser("deploy", help="deploy infrastructure (idempotent)")
    deploy_p.add_argument("--stack-name", default="harbor-aws", help="CloudFormation stack name (default: harbor-aws)")
    deploy_p.add_argument("--region", default="us-east-1", help="AWS region (default: us-east-1)")
    deploy_p.add_argument("--profile", default=None, help="AWS CLI profile name")
    deploy_p.add_argument("--runner-account", action="append", default=None, dest="runner_accounts",
                          help="AWS account ID allowed to assume the runner role (repeatable)")

    # status
    status_p = sub.add_parser("status", help="check infrastructure status")
    status_p.add_argument("--stack-name", default="harbor-aws")
    status_p.add_argument("--region", default="us-east-1")
    status_p.add_argument("--profile", default=None)

    # stop
    stop_p = sub.add_parser("stop", help="delete all running pods (keeps infrastructure)")
    stop_p.add_argument("--stack-name", default="harbor-aws")
    stop_p.add_argument("--region", default="us-east-1")
    stop_p.add_argument("--profile", default=None)

    # destroy
    destroy_p = sub.add_parser("destroy", help="tear down everything")
    destroy_p.add_argument("--stack-name", default="harbor-aws")
    destroy_p.add_argument("--region", default="us-east-1")
    destroy_p.add_argument("--profile", default=None)
    destroy_p.add_argument("-y", "--yes", action="store_true", help="skip confirmation")

    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(message)s",
    )
    logging.getLogger("botocore").setLevel(logging.WARNING)
    logging.getLogger("kubernetes").setLevel(logging.WARNING)

    commands = {"deploy": _deploy, "status": _status, "stop": _stop, "destroy": _destroy}
    if args.command in commands:
        commands[args.command](args)
    else:
        parser.print_help()
        sys.exit(1)


def _deploy(args: argparse.Namespace) -> None:
    from harbor_aws.cdk.deploy import deploy

    outputs = deploy(
        stack_prefix=args.stack_name,
        region=args.region,
        profile_name=args.profile,
        runner_account_ids=args.runner_accounts,
    )
    print("\nStack outputs:")
    for key, value in sorted(outputs.items()):
        print(f"  {key}: {value}")
    print(f"\nUse with Harbor:\n  harbor trials start -p ./task \\\n    --environment-import-path harbor_aws.adapter:AWSEnvironment \\\n    --ek stack_name={args.stack_name} --ek region={args.region}")


def _status(args: argparse.Namespace) -> None:
    import boto3

    session = boto3.Session(profile_name=args.profile, region_name=args.region)
    cfn = session.client("cloudformation")

    try:
        response = cfn.describe_stacks(StackName=args.stack_name)
        stack = response["Stacks"][0]
        print(f"Stack: {args.stack_name}")
        print(f"Status: {stack['StackStatus']}")
        print(f"Region: {args.region}")
        if stack.get("Outputs"):
            print("\nOutputs:")
            for o in stack["Outputs"]:
                print(f"  {o['OutputKey']}: {o['OutputValue']}")
    except Exception as e:
        if "does not exist" in str(e):
            print(f"Stack '{args.stack_name}' does not exist in {args.region}.")
            print(f"Deploy with: python -m harbor_aws deploy --region {args.region}")
        else:
            raise


def _stop(args: argparse.Namespace) -> None:
    import asyncio

    from harbor_aws.core.config import create_k8s_client, load_config_from_stack
    from harbor_aws.core.pods import delete_pod, list_pods

    config = asyncio.run(load_config_from_stack(
        stack_name=args.stack_name,
        region=args.region,
        profile_name=args.profile,
    ))
    api = create_k8s_client(config)

    pod_names = asyncio.run(list_pods(api, config))
    if not pod_names:
        print("No running pods.")
        return

    for name in pod_names:
        asyncio.run(delete_pod(api, config, name))
    print(f"Deleted {len(pod_names)} pod(s). Infrastructure ready for next run.")


def _destroy(args: argparse.Namespace) -> None:
    from harbor_aws.cdk.destroy import destroy, get_destroy_summary

    try:
        summary = get_destroy_summary(args.stack_name, args.region, args.profile)
    except Exception as e:
        if "does not exist" in str(e):
            print(f"Stack '{args.stack_name}' does not exist.")
            return
        raise

    outputs = summary["outputs"]
    ecr_count = summary["ecr_repo_count"]

    print(f"This will delete all harbor-aws resources in {args.region}:")
    print(f"  Stack:      {args.stack_name}")
    if outputs.get("EksClusterName"):
        print(f"  EKS:        cluster '{outputs['EksClusterName']}' (+ delete pods)")
    if ecr_count:
        print(f"  ECR:        {ecr_count} pull-through cache repos (docker-hub/*)")
    print(f"  + VPC, IAM roles, log groups")

    if not args.yes:
        confirm = input("\nProceed? [y/N] ")
        if confirm.lower() != "y":
            print("Cancelled.")
            return

    # Delete pods first (best-effort)
    try:
        _stop(args)
    except Exception:
        pass

    # Tear down infrastructure
    destroy(args.stack_name, args.region, args.profile)


if __name__ == "__main__":
    main()
