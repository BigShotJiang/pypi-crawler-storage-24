"""
LuxurAI SDK — client.py
Main client class. Everything starts here.
"""

from __future__ import annotations
from typing import Optional, List, Dict, Any

from .http       import HttpClient
from .models     import GenerationJob, GeneratedImage, WalletBalance, JobStatus, Resolution, APIKey
from .exceptions import LuxurAIError, AuthenticationError


# ─────────────────────────────────────────────
# Sub-clients
# ─────────────────────────────────────────────

class JobsClient:
    """client.jobs — poll and list generation jobs."""

    def __init__(self, http: HttpClient):
        self._http = http

    def get(self, job_id: str) -> GenerationJob:
        """Get current status of a job."""
        data = self._http.get(f"/api/ux/job/{job_id}")
        return _parse_job(data)

    def list(self, limit: int = 20) -> List[GenerationJob]:
        """List recent generation jobs."""
        data = self._http.get(f"/api/ux/history?limit={limit}")
        jobs = data if isinstance(data, list) else data.get("jobs", [])
        return [_parse_job(j) for j in jobs]


class WalletClient:
    """client.wallet — check LC balance."""

    def __init__(self, http: HttpClient):
        self._http = http

    def balance(self) -> WalletBalance:
        """Get current LC balance and recent ledger."""
        data   = self._http.get("/api/auth/wallet")
        lc     = float(data.get("balance_lc", 0))
        ledger = data.get("ledger", [])
        return WalletBalance(lc=lc, inr=round(lc * 0.25, 2), ledger=ledger)


class KeysClient:
    """client.keys — manage API keys."""

    def __init__(self, http: HttpClient):
        self._http = http

    def list(self) -> List[APIKey]:
        """List all API keys for your account."""
        data = self._http.get("/api/ux/apikey/list")
        keys = data if isinstance(data, list) else data.get("keys", [])
        return [_parse_key(k) for k in keys]

    def create(self, label: str = None) -> str:
        """
        Create a new API key.
        Returns the full key string — save it, it won't be shown again!
        """
        payload = {}
        if label:
            payload["label"] = label
        data = self._http.post("/api/ux/apikey/create", payload)
        return data.get("full_key") or data.get("api_key") or data.get("key", "")

    def revoke(self, key_id: str) -> bool:
        """Revoke/delete an API key by ID."""
        self._http.delete(f"/api/ux/apikey/{key_id}")
        return True

    def rotate(self, key_id: str) -> str:
        """Rotate an existing key — old key is immediately invalidated."""
        data = self._http.post(f"/api/ux/apikey/rotate?key_id={key_id}")
        return data.get("full_key") or data.get("api_key") or data.get("key", "")


# ─────────────────────────────────────────────
# Main Client
# ─────────────────────────────────────────────

class LuxurAI:
    """
    LuxurAI Python SDK — Official client.

    Usage:
        from luxurai import LuxurAI

        client = LuxurAI(api_key="lxr_v1_xxxx")

        # Generate — auto picks best model + resolution
        image = client.generate("a red dragon over mountains")
        image.save("dragon.png")

        # See all available models + resolutions
        info = client.models()
        print(info["models"])
        print(info["resolutions"])

        # Check balance
        balance = client.wallet.balance()
        print(f"{balance.lc} LC  =  Rs.{balance.inr:.2f}")

    Args:
        api_key:  Your LuxurAI API key (starts with lxr_v1_)
        base_url: API base URL (default: https://www.luxurai.in)
        timeout:  Request timeout in seconds (default: 30)
    """

    BASE_URL = "https://www.luxurai.in"

    def __init__(
        self,
        api_key:  str,
        base_url: str = None,
        timeout:  int = 30,
    ):
        if not api_key:
            raise AuthenticationError(
                "api_key is required. Get yours at luxurai.in → Dashboard → API Keys"
            )
        if not api_key.startswith("lxr_v1_"):
            raise AuthenticationError(
                f"Invalid API key format '{api_key[:12]}...' — LuxurAI keys start with 'lxr_v1_'"
            )

        self._http = HttpClient(
            api_key  = api_key,
            base_url = base_url or self.BASE_URL,
            timeout  = timeout,
        )

        # Sub-clients
        self.jobs   = JobsClient(self._http)
        self.wallet = WalletClient(self._http)
        self.keys   = KeysClient(self._http)

        # Model metadata cache — fetched once, backend is source of truth
        self._meta: Optional[Dict[str, Any]] = None

    # ── Model metadata ────────────────────────────────────────────────

    def models(self) -> Dict[str, Any]:
        """
        Fetch available models and resolutions from the LuxurAI backend.
        Cached for the lifetime of this client instance.

        Returns:
            {
              "models":             ["brainai-v1", ...],
              "default":            "brainai-v1",
              "resolutions":        ["512x512", "1024x1024", ...],
              "default_resolution": "1024x1024"
            }
        """
        if self._meta is None:
            try:
                self._meta = self._http.get("/api/ux/models")
            except Exception:
                # Fallback if server doesn't have /models yet
                self._meta = {
                    "models":             ["brainai-v1"],
                    "default":            "brainai-v1",
                    "resolutions":        ["512x512", "1024x1024", "1152x1152", "1920x1080"],
                    "default_resolution": "1024x1024",
                }
        return self._meta

    def _resolve_model(self, model: str) -> str:
        """Resolve 'auto' to backend default. Validate named models."""
        meta = self.models()
        if model == "auto":
            return meta.get("default", "brainai-v1")
        available = meta.get("models", ["brainai-v1"])
        if model not in available:
            raise LuxurAIError(
                f"Unknown model '{model}'. Available: {available} "
                f"(or use model='auto' to always pick the latest)"
            )
        return model

    def _resolve_resolution(self, resolution: str) -> str:
        """Resolve 'auto' to backend default resolution."""
        if resolution == "auto":
            meta = self.models()
            return meta.get("default_resolution", "1024x1024")
        return resolution

    # ── Core: generate ────────────────────────────────────────────────

    def generate(
        self,
        prompt:       str,
        *,
        model:        str  = "auto",
        resolution:   str  = "auto",
        fast:         bool = False,
        no_watermark: bool = False,
        wait:         bool = True,
        timeout:      int  = 300,
        verbose:      bool = True,
    ) -> "GeneratedImage | GenerationJob":
        """
        Generate an image from a text prompt.

        Args:
            prompt:       Text description of the image to generate
            model:        "auto" (default) or "brainai-v1"
            resolution:   "auto" (default), "512x512", "1024x1024",
                          "1152x1152", "1920x1080", "576x1024" etc.
            fast:         Fast mode — cheaper (default False)
            no_watermark: Remove watermark — costs extra LC (default False)
            wait:         Block until done (default True)
            timeout:      Max wait seconds (default 300)
            verbose:      Print progress (default True)

        Returns:
            GeneratedImage if wait=True  → .save(), .bytes(), .to_pil()
            GenerationJob  if wait=False → .wait(), .status

        Examples:
            image = client.generate("a sunset")
            image.save("sunset.png")

            job = client.generate("anime girl", wait=False)
            image = job.wait()
        """
        resolved_model      = self._resolve_model(model)
        resolved_resolution = self._resolve_resolution(resolution)

        if verbose and wait:
            print(f"  model={resolved_model}  resolution={resolved_resolution}")

        # api_key sent ONLY via Authorization header — never in body
        data = self._http.post("/api/ux/generate", {
            "prompt":       prompt,
            "resolution":   resolved_resolution,
            "fast":         fast,
            "no_watermark": no_watermark,
        })

        job = GenerationJob(
            id             = data["job_id"],
            prompt         = prompt,
            status         = JobStatus(data.get("status", "queued")),
            cost_lc        = float(data.get("cost_lc", 0)),
            resolution     = resolved_resolution,
            queue_position = data.get("queue_position"),
            eta_seconds    = data.get("eta_seconds"),
            _client        = self,
        )

        if verbose and not wait:
            pos = f" at queue #{job.queue_position}" if job.queue_position is not None else ""
            print(f"Job submitted{pos} — {job.cost_lc} LC deducted")
            print(f"  job.id = '{job.id}'")
            print(f"  call job.wait() to get the image")

        if wait:
            return job.wait(timeout=timeout, verbose=verbose)

        return job

    # ── Convenience ───────────────────────────────────────────────────

    def status(self) -> dict:
        """Check if generation is available (brainAI live or still training)."""
        return self._http.get("/api/ux/generation-status")

    def __repr__(self) -> str:
        key_preview = self._http.api_key[:16] + "..."
        model_info  = self._meta.get("default", "?") if self._meta else "not fetched yet"
        return (
            f"LuxurAI(api_key='{key_preview}', "
            f"base_url='{self._http.base_url}', "
            f"default_model='{model_info}')"
        )


# ─────────────────────────────────────────────
# Parsers
# ─────────────────────────────────────────────

def _parse_job(data: dict) -> GenerationJob:
    return GenerationJob(
        id             = data.get("job_id") or data.get("id", ""),
        prompt         = data.get("prompt", ""),
        status         = JobStatus(data.get("status", "pending")),
        cost_lc        = float(data.get("cost_lc", 0)),
        resolution     = data.get("resolution", "1024x1024"),
        queue_position = data.get("queue_position"),
        eta_seconds    = data.get("eta_seconds"),
        image_url      = data.get("image_url"),
    )


def _parse_key(data: dict) -> APIKey:
    return APIKey(
        id         = data.get("id", "") or data.get("key_id", ""),
        prefix     = data.get("key_prefix") or data.get("prefix", ""),
        created_at = data.get("created_at", ""),
        is_active  = data.get("is_active", True),
        label      = data.get("label"),
    )
