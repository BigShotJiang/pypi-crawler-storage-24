"""
LuxurAI Python SDK
~~~~~~~~~~~~~~~~~~
Official Python client for the LuxurAI API.

Usage:
    from luxurai import LuxurAI

    client = LuxurAI(api_key="lxr_v1_xxxx")

    image = client.generate("a red dragon over mountains")
    image.save("dragon.png")

    balance = client.wallet.balance()
    print(f"Balance: {balance.lc} LC")
"""

from .client import LuxurAI
from .models import (
    GenerationJob,
    GeneratedImage,
    WalletBalance,
    JobStatus,
    Resolution,
    APIKey,
)
from .exceptions import (
    LuxurAIError,
    AuthenticationError,
    InsufficientBalanceError,
    ModelTrainingError,
    RateLimitError,
    JobFailedError,
    JobTimeoutError,
)

__version__ = "0.2.0"
__author__  = "LuxurAI"
__all__ = [
    "LuxurAI",
    "GenerationJob",
    "GeneratedImage",
    "WalletBalance",
    "JobStatus",
    "Resolution",
    "APIKey",
    "LuxurAIError",
    "AuthenticationError",
    "InsufficientBalanceError",
    "ModelTrainingError",
    "RateLimitError",
    "JobFailedError",
    "JobTimeoutError",
]
