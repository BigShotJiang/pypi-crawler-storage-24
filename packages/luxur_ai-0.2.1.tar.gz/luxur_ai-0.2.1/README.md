# LuxurAI Python SDK

Official Python client for [LuxurAI](https://luxurai.in) — AI image generation.

## Install

```bash
pip install luxur-ai
```

## Quick Start

```python
from luxurai import LuxurAI

client = LuxurAI(api_key="lxr_v1_xxxx")

# Generate an image
image = client.generate("a red dragon flying over mountains")
image.save("dragon.png")
```

Get your API key at [luxurai.in](https://luxurai.in) → Dashboard → API Keys.

---

## Usage

### Generate image

```python
# Auto model + auto resolution (recommended)
image = client.generate("a sunset over the ocean")
image.save("sunset.png")

# Pick resolution
image = client.generate(
    "divine krishna playing flute",
    resolution = "1152x1152",   # brainAI native — best quality
)

# Non-blocking
job = client.generate("anime girl with blue hair", wait=False)
print(f"Queue: #{job.queue_position}  ETA: ~{job.eta_seconds}s")
image = job.wait()
image.save("output.png")
```

### Models & Resolutions (auto-discovery)

```python
info = client.models()
print(info["models"])             # ['brainai-v1']
print(info["default"])            # 'brainai-v1'
print(info["resolutions"])        # ['512x512', '1024x1024', '1152x1152', ...]
print(info["default_resolution"]) # '1024x1024'
```

`model="auto"` always uses the latest model from the backend — no SDK update needed when new models launch.

### Resolutions

```python
from luxurai import Resolution

client.generate("a mountain", resolution=Resolution.HD)      # 1024x1024
client.generate("a mountain", resolution=Resolution.NATIVE)  # 1152x1152 — brainAI native
client.generate("a mountain", resolution="1920x1080")        # any WxH works
```

### GeneratedImage

```python
image = client.generate("a cat")

image.save("cat.png")       # save to file
image.save("cat.jpg")       # format from extension
raw  = image.bytes()        # raw bytes
pil  = image.to_pil()       # PIL.Image (needs: pip install Pillow)
image.show()                # display in Jupyter / IPython
print(image.url)            # permanent S3 URL
```

### Wallet

```python
balance = client.wallet.balance()
print(f"{balance.lc} LC  =  Rs.{balance.inr:.2f}")
```

### Job history

```python
jobs = client.jobs.list(limit=10)
for job in jobs:
    print(job.id, job.status, job.cost_lc, "LC")
```

### API key management

```python
new_key = client.keys.create(label="my-app")
print(new_key)   # lxr_v1_xxxx — save this!

keys = client.keys.list()

client.keys.revoke(key_id="key_id_here")
client.keys.rotate(key_id="key_id_here")
```

### Check model status

```python
status = client.status()
print(status["available"])    # True/False
print(status["message"])      # "Generation is live!" or "Coming soon..."
```

---

## Error handling

```python
from luxurai import (
    LuxurAI,
    AuthenticationError,
    InsufficientBalanceError,
    ModelTrainingError,
    JobFailedError,
    JobTimeoutError,
)

try:
    image = client.generate("a dragon")
except AuthenticationError:
    print("Invalid API key")
except InsufficientBalanceError:
    print("Not enough LC — top up at luxurai.in")
except ModelTrainingError:
    print("Model still training — coming soon!")
except JobFailedError:
    print("Generation failed — try again")
except JobTimeoutError:
    print("Timed out — try again")
```

---

## Requirements

- Python 3.8+
- No required dependencies — pure stdlib
- Optional: `pip install Pillow` for `.to_pil()` and `.show()`

---

## License

MIT © [LuxurAI](https://luxurai.in)
