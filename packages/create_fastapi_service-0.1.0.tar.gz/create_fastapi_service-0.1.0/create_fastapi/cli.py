#!/usr/bin/env python3
"""
create-fastapi-service
======================
Production-grade FastAPI microservice generator.

Usage
-----
    python create_fastapi_app.py <service-name> [options]

    # or after `pip install -e .`:
    create-fastapi-service payment-service --all
    create-fastapi-service auth-service --postgres --redis --jwt

Options
-------
    --all          Enable every feature
    --postgres     Async PostgreSQL + SQLAlchemy + asyncpg
    --redis        Redis cache + @cache() decorator
    --jwt          JWT RS256 auth (RSA key-pair auto-generated)
    --kafka        Kafka producer/consumer (aiokafka)
    --docker       Dockerfile + docker-compose.yml
    --workers      Async background worker loop
    --alembic      Alembic migration scaffold
    --interactive  Prompt for each feature interactively
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
import textwrap
from pathlib import Path

# ---------------------------------------------------------------------------
# Feature registry
# ---------------------------------------------------------------------------

FEATURES: dict[str, str] = {
    "postgres": "PostgreSQL + async SQLAlchemy",
    "redis":    "Redis cache + @cache() decorator",
    "jwt":      "JWT RS256 authentication",
    "kafka":    "Kafka producer/consumer (aiokafka)",
    "docker":   "Dockerfile + docker-compose.yml",
    "workers":  "Async background worker",
    "alembic":  "Alembic migrations",
}

# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------


def run(cmd: str, cwd: Path | None = None) -> None:
    subprocess.run(cmd, shell=True, check=True, cwd=cwd)


def write(path: Path | str, content: str) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(textwrap.dedent(content).lstrip("\n"))


def touch(path: Path | str) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    if not p.exists():
        p.touch()


def banner(msg: str) -> None:
    bar = "─" * 60
    print(f"\n\033[1;36m{bar}\n  {msg}\n{bar}\033[0m")


def ok(msg: str) -> None:
    print(f"  \033[32m✓\033[0m  {msg}")


# ---------------------------------------------------------------------------
# Directory scaffold
# ---------------------------------------------------------------------------

DIRS: list[str] = [
    "app/api/v1/endpoints",
    "app/auth",
    "app/cache",
    "app/kafka",
    "app/workers",
    "app/logging",
    "app/middleware",
    "app/models",
    "app/repositories",
    "app/schemas",
    "app/services",
    "app/db",
    "app/dependencies",
    "app/utils",
    "app/core",
    "keys",
    "tests",
    "scripts",
    "migrations/versions",
]

# ===========================================================================
#  TEMPLATES
# ===========================================================================

# ── app/main.py ─────────────────────────────────────────────────────────────

def tpl_main(features: set[str]) -> str:
    imports = [
        "from fastapi import FastAPI",
        "from contextlib import asynccontextmanager",
        "from app.api.router import api_router",
        "from app.middleware.request_id import RequestIDMiddleware",
        "from app.middleware.request_context import RequestContextMiddleware",
        "from app.core.config import get_settings",
        "from app.logging.logger import get_logger",
    ]

    startup_body = []
    shutdown_body = []

    if "postgres" in features:
        imports.append("from app.db.session import engine")
        imports.append("from app.models.user_model import Base")
        startup_body.append(
            '    try:\n'
            '        async with engine.begin() as conn:\n'
            '            await conn.run_sync(Base.metadata.create_all)\n'
            '        logger.info("Database tables created/verified")\n'
            '    except Exception as _db_err:\n'
            '        logger.warning(f"Database unavailable at startup: {_db_err}")\n'
            '        logger.warning("Endpoints requiring DB will fail until PostgreSQL is reachable.")\n'
            '        logger.warning("Run: alembic upgrade head  (after starting Postgres)")'
        )
        shutdown_body.append(
            '    await engine.dispose()\n'
            '    logger.info("Database connection closed")'
        )

    if "redis" in features:
        imports.append("from app.cache.redis_client import get_redis, close_redis")
        startup_body.append(
            '    try:\n'
            '        _r = await get_redis()\n'
            '        await _r.ping()\n'
            '        logger.info("Redis connection verified")\n'
            '    except Exception as _redis_err:\n'
            '        logger.warning(f"Redis unavailable at startup: {_redis_err}")\n'
            '        logger.warning("Endpoints using @cache() will skip caching until Redis is reachable.")'
        )
        shutdown_body.append(
            '    await close_redis()\n'
            '    logger.info("Redis connection closed")'
        )

    if "kafka" in features:
        imports.append("from app.kafka.producer import start_producer, stop_producer")
        startup_body.append(
            '    try:\n'
            '        await start_producer()\n'
            '        logger.info("Kafka producer started")\n'
            '    except Exception as _kafka_err:\n'
            '        logger.warning(f"Kafka unavailable at startup: {_kafka_err}")\n'
            '        logger.warning("Kafka publish calls will fail until the broker is reachable.")'
        )
        shutdown_body.append('    await stop_producer()\n    logger.info("Kafka producer stopped")')

    if "workers" in features:
        imports.append("from app.workers.task_worker import start_worker, stop_worker")
        startup_body.append(
            '    try:\n'
            '        await start_worker()\n'
            '        logger.info("Background worker started")\n'
            '    except Exception as _worker_err:\n'
            '        logger.warning(f"Background worker failed to start: {_worker_err}")'
        )
        shutdown_body.append('    await stop_worker()\n    logger.info("Background worker stopped")')

    startup_str = "\n".join(startup_body) if startup_body else "    pass"
    shutdown_str = "\n".join(shutdown_body) if shutdown_body else "    pass"

    return "\n".join(imports) + f"""


settings = get_settings()
logger = get_logger("main")


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info(f"Starting {{settings.APP_NAME}} (env={{settings.ENV}})")
{startup_str}
    yield
{shutdown_str}
    logger.info(f"{{settings.APP_NAME}} shutdown complete")


def create_app() -> FastAPI:
    prefix = settings.service_prefix  # e.g. "/payment-service"

    app = FastAPI(
        title=settings.APP_NAME,
        version="0.1.0",
        # All docs/schema URLs scoped under the service prefix
        docs_url=f"{{prefix}}/docs",
        redoc_url=f"{{prefix}}/redoc",
        openapi_url=f"{{prefix}}/openapi.json",
        lifespan=lifespan,
    )

    # Middlewares (registered outermost-first)
    app.add_middleware(RequestContextMiddleware)
    app.add_middleware(RequestIDMiddleware)

    # All API routes mounted under the service prefix
    # e.g. /payment-service/api/v1/users
    app.include_router(api_router, prefix=prefix)

    return app


app = create_app()
"""


# ── app/core/config.py ──────────────────────────────────────────────────────

TPL_CONFIG = """\
from __future__ import annotations

from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # ── App ───────────────────────────────────────────────────────────
    APP_NAME: str = "FastAPI Service"
    ENV: str = "development"
    DEBUG: bool = False
    LOG_LEVEL: str = "INFO"

    # ── PostgreSQL ────────────────────────────────────────────────────
    POSTGRES_HOST: str = "localhost"
    POSTGRES_PORT: int = 5432
    POSTGRES_DB: str = "app"
    POSTGRES_USER: str = "postgres"
    POSTGRES_PASSWORD: str = "postgres"

    @property
    def database_url(self) -> str:
        return (
            f"postgresql+asyncpg://{self.POSTGRES_USER}:"
            f"{self.POSTGRES_PASSWORD}@{self.POSTGRES_HOST}:"
            f"{self.POSTGRES_PORT}/{self.POSTGRES_DB}"
        )

    # ── Redis ─────────────────────────────────────────────────────────
    REDIS_HOST: str = "localhost"
    REDIS_PORT: int = 6379
    REDIS_DB: int = 0

    # ── JWT ───────────────────────────────────────────────────────────
    JWT_PRIVATE_KEY_PATH: str = "keys/private.pem"
    JWT_PUBLIC_KEY_PATH: str = "keys/public.pem"
    JWT_ALGORITHM: str = "RS256"
    JWT_ACCESS_TOKEN_EXPIRE_MINUTES: int = 30

    # ── Kafka ─────────────────────────────────────────────────────────
    KAFKA_BOOTSTRAP_SERVERS: str = "localhost:9092"
    KAFKA_TOPIC: str = "events"

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def service_prefix(self) -> str:
        # e.g. APP_NAME="payment-service" -> "/payment-service"
        return "/" + self.APP_NAME.lower().replace(" ", "-")


@lru_cache
def get_settings() -> Settings:
    return Settings()
"""

# ── app/logging/logger.py ───────────────────────────────────────────────────

TPL_LOGGER = """\
from __future__ import annotations

import logging
import sys


def get_logger(name: str) -> logging.Logger:
    \"\"\"
    Return a named logger with the format:
        timestamp | level | service | message
    \"\"\"
    logger = logging.getLogger(name)

    if not logger.handlers:
        logger.setLevel(logging.INFO)

        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(
            logging.Formatter(
                fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
                datefmt="%Y-%m-%dT%H:%M:%S",
            )
        )
        logger.addHandler(handler)
        logger.propagate = False

    return logger
"""

# ── app/middleware/request_id.py ────────────────────────────────────────────

TPL_REQUEST_ID = """\
from __future__ import annotations

import uuid
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response


class RequestIDMiddleware(BaseHTTPMiddleware):
    \"\"\"Attach a UUID X-Request-ID header to every request and response.\"\"\"

    async def dispatch(self, request: Request, call_next) -> Response:
        request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
        request.state.request_id = request_id
        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        return response
"""

# ── app/middleware/request_context.py ───────────────────────────────────────

TPL_REQUEST_CONTEXT = """\
from __future__ import annotations

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response
from app.logging.logger import get_logger

logger = get_logger("request-context")


class RequestContextMiddleware(BaseHTTPMiddleware):
    \"\"\"Log every incoming request with method, path and status code.\"\"\"

    async def dispatch(self, request: Request, call_next) -> Response:
        logger.info(f"--> {request.method} {request.url.path}")
        response = await call_next(request)
        request_id = getattr(request.state, "request_id", "-")
        logger.info(
            f"<-- {request.method} {request.url.path} "
            f"status={response.status_code} request_id={request_id}"
        )
        return response
"""

# ── app/api/router.py ────────────────────────────────────────────────────────

TPL_API_ROUTER = """\
from fastapi import APIRouter
from app.api.v1.router import router as v1_router

api_router = APIRouter()

api_router.include_router(v1_router, prefix="/api/v1")
"""

# ── app/api/v1/router.py ─────────────────────────────────────────────────────

def tpl_v1_router() -> str:
    lines = [
        "from fastapi import APIRouter",
        "from app.api.v1.endpoints import health, users",
        "",
        "router = APIRouter()",
        "",
        'router.include_router(health.router, tags=["health"])',
        'router.include_router(users.router, prefix="/users", tags=["users"])',
    ]
    return "\n".join(lines) + "\n"


# ── app/api/v1/endpoints/health.py ──────────────────────────────────────────

TPL_HEALTH = """\
from fastapi import APIRouter
from datetime import datetime, timezone

router = APIRouter()


@router.get("/health", summary="Health check")
async def health_check():
    return {
        "status": "ok",
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
"""

# ── app/api/v1/endpoints/users.py ───────────────────────────────────────────

def tpl_users_endpoint(features: set[str]) -> str:
    auth_import = ""
    auth_dep = ""
    secure_endpoint = ""

    if "jwt" in features:
        auth_import = "from app.dependencies.auth import require_auth\n"
        auth_dep = ", current_user: dict = Depends(require_auth)"
        secure_endpoint = """

@router.get("/secure", summary="Protected endpoint (requires JWT)")
async def secure_route(current_user: dict = Depends(require_auth)):
    return {"message": "Access granted", "user": current_user}
"""

    return f"""\
from fastapi import APIRouter, Depends, HTTPException, status
from app.schemas.user_schema import UserCreate, UserUpdate, UserResponse
from app.services.user_service import UserService
from app.dependencies.auth import get_user_service
{auth_import}
router = APIRouter()


@router.get("/", response_model=list[UserResponse], summary="List all users")
async def list_users(
    service: UserService = Depends(get_user_service){auth_dep}
):
    return await service.list_users()


@router.get("/{{user_id}}", response_model=UserResponse, summary="Get user by ID")
async def get_user(
    user_id: int,
    service: UserService = Depends(get_user_service){auth_dep}
):
    user = await service.get_user(user_id)
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    return user


@router.post("/", response_model=UserResponse, status_code=status.HTTP_201_CREATED, summary="Create user")
async def create_user(
    payload: UserCreate,
    service: UserService = Depends(get_user_service)
):
    return await service.create_user(payload)


@router.put("/{{user_id}}", response_model=UserResponse, summary="Update user")
async def update_user(
    user_id: int,
    payload: UserUpdate,
    service: UserService = Depends(get_user_service){auth_dep}
):
    user = await service.update_user(user_id, payload)
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    return user


@router.delete("/{{user_id}}", status_code=status.HTTP_204_NO_CONTENT, summary="Delete user")
async def delete_user(
    user_id: int,
    service: UserService = Depends(get_user_service){auth_dep}
):
    deleted = await service.delete_user(user_id)
    if not deleted:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
{secure_endpoint}
"""


# ── app/schemas/user_schema.py ──────────────────────────────────────────────

TPL_USER_SCHEMA = """\
from __future__ import annotations

from pydantic import BaseModel, EmailStr, Field
from datetime import datetime


class UserBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=128)
    email: EmailStr


class UserCreate(UserBase):
    pass


class UserUpdate(BaseModel):
    name: str | None = Field(None, min_length=1, max_length=128)
    email: EmailStr | None = None


class UserResponse(UserBase):
    id: int
    created_at: datetime

    model_config = {"from_attributes": True}
"""

# ── app/models/user_model.py ─────────────────────────────────────────────────

def tpl_user_model(features: set[str]) -> str:
    if "postgres" in features:
        return """\
from __future__ import annotations

from datetime import datetime, timezone
from sqlalchemy import Integer, String, DateTime
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(128), nullable=False)
    email: Mapped[str] = mapped_column(String(256), unique=True, index=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        nullable=False,
    )
"""
    return """\
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone


@dataclass
class User:
    \"\"\"In-memory user model (no Postgres configured).\"\"\"
    id: int
    name: str
    email: str
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
"""


# ── app/db/session.py ────────────────────────────────────────────────────────

TPL_DB_SESSION = """\
from __future__ import annotations

from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from app.core.config import get_settings

settings = get_settings()

engine = create_async_engine(
    settings.database_url,
    pool_pre_ping=True,
    pool_size=10,
    max_overflow=20,
    echo=settings.DEBUG,
)

AsyncSessionLocal: async_sessionmaker[AsyncSession] = async_sessionmaker(
    bind=engine,
    expire_on_commit=False,
    autoflush=False,
    autocommit=False,
)


async def get_db() -> AsyncSession:
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
"""

# ── app/repositories/user_repository.py ─────────────────────────────────────

def tpl_user_repository(features: set[str]) -> str:
    if "postgres" in features:
        return """\
from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.models.user_model import User
from app.schemas.user_schema import UserCreate, UserUpdate


class UserRepository:
    def __init__(self, db: AsyncSession) -> None:
        self.db = db

    async def get_all(self) -> list[User]:
        result = await self.db.execute(select(User))
        return list(result.scalars().all())

    async def get_by_id(self, user_id: int) -> User | None:
        return await self.db.get(User, user_id)

    async def create(self, payload: UserCreate) -> User:
        user = User(name=payload.name, email=payload.email)
        self.db.add(user)
        await self.db.flush()
        await self.db.refresh(user)
        return user

    async def update(self, user: User, payload: UserUpdate) -> User:
        if payload.name is not None:
            user.name = payload.name
        if payload.email is not None:
            user.email = payload.email
        await self.db.flush()
        await self.db.refresh(user)
        return user

    async def delete(self, user: User) -> None:
        await self.db.delete(user)
        await self.db.flush()
"""
    return """\
from __future__ import annotations

from datetime import datetime, timezone
from app.models.user_model import User
from app.schemas.user_schema import UserCreate, UserUpdate

# In-memory store (replace with real DB layer when Postgres is enabled)
_store: dict[int, User] = {}
_counter = 0


class UserRepository:
    async def get_all(self) -> list[User]:
        return list(_store.values())

    async def get_by_id(self, user_id: int) -> User | None:
        return _store.get(user_id)

    async def create(self, payload: UserCreate) -> User:
        global _counter
        _counter += 1
        user = User(id=_counter, name=payload.name, email=payload.email)
        _store[user.id] = user
        return user

    async def update(self, user: User, payload: UserUpdate) -> User:
        if payload.name is not None:
            user.name = payload.name
        if payload.email is not None:
            user.email = payload.email
        _store[user.id] = user
        return user

    async def delete(self, user: User) -> None:
        _store.pop(user.id, None)
"""


# ── app/services/user_service.py ─────────────────────────────────────────────

def tpl_user_service(features: set[str]) -> str:
    redis_import = ""
    cache_decorator = ""
    if "redis" in features:
        redis_import = "from app.cache.decorators import cache\n"
        cache_decorator = "@cache(ttl=60)\n    "

    return f"""\
from __future__ import annotations

from app.repositories.user_repository import UserRepository
from app.schemas.user_schema import UserCreate, UserUpdate, UserResponse
from app.models.user_model import User
from app.logging.logger import get_logger
{redis_import}
logger = get_logger("user-service")


class UserService:
    \"\"\"
    Orchestration layer: API → Service → Repository → Database
    \"\"\"

    def __init__(self, repo: UserRepository) -> None:
        self.repo = repo

    async def list_users(self) -> list[UserResponse]:
        users = await self.repo.get_all()
        return [UserResponse.model_validate(u) for u in users]

    {cache_decorator}async def get_user(self, user_id: int) -> UserResponse | None:
        user = await self.repo.get_by_id(user_id)
        if not user:
            return None
        return UserResponse.model_validate(user)

    async def create_user(self, payload: UserCreate) -> UserResponse:
        logger.info(f"Creating user email={{payload.email}}")
        user = await self.repo.create(payload)
        logger.info(f"User created id={{user.id}}")
        return UserResponse.model_validate(user)

    async def update_user(self, user_id: int, payload: UserUpdate) -> UserResponse | None:
        user = await self.repo.get_by_id(user_id)
        if not user:
            return None
        updated = await self.repo.update(user, payload)
        return UserResponse.model_validate(updated)

    async def delete_user(self, user_id: int) -> bool:
        user = await self.repo.get_by_id(user_id)
        if not user:
            return False
        await self.repo.delete(user)
        logger.info(f"User deleted id={{user_id}}")
        return True
"""


# ── app/dependencies/auth.py ─────────────────────────────────────────────────

def tpl_dependencies_auth(features: set[str]) -> str:
    parts = ["""\
from __future__ import annotations

from fastapi import Depends
from app.services.user_service import UserService
from app.repositories.user_repository import UserRepository
"""]

    if "postgres" in features:
        parts.append("""\
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.session import get_db


async def get_db_session(db: AsyncSession = Depends(get_db)) -> AsyncSession:
    return db


async def get_user_service(db: AsyncSession = Depends(get_db)) -> UserService:
    return UserService(UserRepository(db))
""")
    else:
        parts.append("""\
_repo = UserRepository()


async def get_user_service() -> UserService:
    return UserService(_repo)
""")

    if "jwt" in features:
        parts.append("""\
from fastapi import HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from app.auth.jwt_handler import verify_token

_bearer = HTTPBearer()


async def require_auth(
    credentials: HTTPAuthorizationCredentials = Depends(_bearer),
) -> dict:
    payload = verify_token(credentials.credentials)
    if payload is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return payload
""")
    else:
        parts.append("""\
# JWT not enabled — stub dependency for development
async def require_auth() -> dict:
    return {"sub": "dev-user", "role": "admin"}
""")

    return "\n".join(parts)


# ── app/auth/jwt_handler.py ──────────────────────────────────────────────────

TPL_JWT_HANDLER = """\
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path

from jose import JWTError, jwt

from app.core.config import get_settings
from app.logging.logger import get_logger

settings = get_settings()
logger = get_logger("jwt-handler")


def _read_key(path: str) -> str:
    return Path(path).read_text()


def create_access_token(subject: str, extra: dict | None = None) -> str:
    \"\"\"Create a signed RS256 JWT access token.\"\"\"
    private_key = _read_key(settings.JWT_PRIVATE_KEY_PATH)
    expire = datetime.now(timezone.utc) + timedelta(
        minutes=settings.JWT_ACCESS_TOKEN_EXPIRE_MINUTES
    )
    payload = {
        "sub": subject,
        "exp": expire,
        "iat": datetime.now(timezone.utc),
        **(extra or {}),
    }
    return jwt.encode(payload, private_key, algorithm=settings.JWT_ALGORITHM)


def verify_token(token: str) -> dict | None:
    \"\"\"Verify a JWT and return its payload, or None if invalid.\"\"\"
    public_key = _read_key(settings.JWT_PUBLIC_KEY_PATH)
    try:
        return jwt.decode(token, public_key, algorithms=[settings.JWT_ALGORITHM])
    except JWTError as exc:
        logger.warning(f"JWT verification failed: {exc}")
        return None
"""

# ── app/cache/redis_client.py ────────────────────────────────────────────────

TPL_REDIS_CLIENT = """\
from __future__ import annotations

import redis.asyncio as aioredis
from app.core.config import get_settings
from app.logging.logger import get_logger

settings = get_settings()
logger = get_logger("redis-client")

_redis: aioredis.Redis | None = None


async def get_redis() -> aioredis.Redis:
    global _redis
    if _redis is None:
        _redis = aioredis.Redis(
            host=settings.REDIS_HOST,
            port=settings.REDIS_PORT,
            db=settings.REDIS_DB,
            decode_responses=True,
        )
        logger.info(f"Redis connected to {settings.REDIS_HOST}:{settings.REDIS_PORT}")
    return _redis


async def close_redis() -> None:
    global _redis
    if _redis:
        await _redis.aclose()
        _redis = None
"""

# ── app/cache/decorators.py ──────────────────────────────────────────────────

TPL_CACHE_DECORATOR = """\
from __future__ import annotations

import json
import functools
from typing import Any, Callable

from app.cache.redis_client import get_redis
from app.logging.logger import get_logger

logger = get_logger("cache")


def cache(ttl: int = 60):
    \"\"\"
    Async cache decorator backed by Redis.

    Usage::

        @cache(ttl=60)
        async def get_user(user_id: int):
            ...
    \"\"\"
    def decorator(fn: Callable) -> Callable:
        @functools.wraps(fn)
        async def wrapper(*args, **kwargs) -> Any:
            key = f"{fn.__module__}.{fn.__qualname__}:{args}:{kwargs}"
            redis = await get_redis()

            cached = await redis.get(key)
            if cached is not None:
                logger.debug(f"Cache HIT  key={key!r}")
                return json.loads(cached)

            logger.debug(f"Cache MISS key={key!r}")
            result = await fn(*args, **kwargs)
            await redis.setex(key, ttl, json.dumps(result, default=str))
            return result

        return wrapper
    return decorator
"""

# ── app/kafka/producer.py ────────────────────────────────────────────────────

TPL_KAFKA_PRODUCER = """\
from __future__ import annotations

import json
from aiokafka import AIOKafkaProducer
from app.core.config import get_settings
from app.logging.logger import get_logger

settings = get_settings()
logger = get_logger("kafka-producer")

_producer: AIOKafkaProducer | None = None


async def start_producer() -> None:
    global _producer
    _producer = AIOKafkaProducer(
        bootstrap_servers=settings.KAFKA_BOOTSTRAP_SERVERS,
        value_serializer=lambda v: json.dumps(v).encode(),
    )
    await _producer.start()
    logger.info(f"Kafka producer connected to {settings.KAFKA_BOOTSTRAP_SERVERS}")


async def stop_producer() -> None:
    global _producer
    if _producer:
        await _producer.stop()
        _producer = None


async def publish(topic: str, payload: dict) -> None:
    \"\"\"Publish a JSON payload to a Kafka topic.\"\"\"
    if _producer is None:
        raise RuntimeError("Kafka producer not started — call start_producer() first")
    await _producer.send_and_wait(topic, payload)
    logger.debug(f"Published to {topic}: {payload}")
"""

# ── app/kafka/consumer.py ────────────────────────────────────────────────────

TPL_KAFKA_CONSUMER = """\
from __future__ import annotations

import asyncio
import json
from aiokafka import AIOKafkaConsumer
from app.core.config import get_settings
from app.logging.logger import get_logger

settings = get_settings()
logger = get_logger("kafka-consumer")


async def consume(handler=None) -> None:
    \"\"\"
    Consume messages from the configured Kafka topic.

    Args:
        handler: async callable(msg: dict) -> None
    \"\"\"
    consumer = AIOKafkaConsumer(
        settings.KAFKA_TOPIC,
        bootstrap_servers=settings.KAFKA_BOOTSTRAP_SERVERS,
        value_deserializer=lambda v: json.loads(v.decode()),
        auto_offset_reset="earliest",
        enable_auto_commit=True,
    )
    await consumer.start()
    logger.info(f"Kafka consumer listening on topic={settings.KAFKA_TOPIC!r}")
    try:
        async for msg in consumer:
            logger.debug(f"Received offset={msg.offset} key={msg.key}")
            if handler:
                await handler(msg.value)
    finally:
        await consumer.stop()
"""

# ── app/workers/task_worker.py ───────────────────────────────────────────────

TPL_TASK_WORKER = """\
from __future__ import annotations

import asyncio
from app.logging.logger import get_logger

logger = get_logger("task-worker")

_task: asyncio.Task | None = None
_running = False


async def _worker_loop() -> None:
    logger.info("Background worker loop started")
    while _running:
        try:
            await _process_pending_tasks()
        except Exception as exc:
            logger.error(f"Worker error: {exc}")
        await asyncio.sleep(5)
    logger.info("Background worker loop stopped")


async def _process_pending_tasks() -> None:
    \"\"\"Replace this stub with your actual background task logic.\"\"\"
    logger.debug("Worker tick — processing pending tasks")


async def start_worker() -> None:
    global _task, _running
    _running = True
    _task = asyncio.create_task(_worker_loop())


async def stop_worker() -> None:
    global _task, _running
    _running = False
    if _task:
        _task.cancel()
        try:
            await _task
        except asyncio.CancelledError:
            pass
        _task = None
"""

# ── app/utils/tracing.py ─────────────────────────────────────────────────────

TPL_TRACING = """\
from __future__ import annotations

\"\"\"
OpenTelemetry tracing helpers.

Install the optional dependency to activate:
    uv add opentelemetry-sdk opentelemetry-instrumentation-fastapi

Then call setup_tracing() inside your lifespan startup.
\"\"\"

try:
    from opentelemetry import trace
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import (
        BatchSpanProcessor,
        ConsoleSpanExporter,
    )
    _OTEL_AVAILABLE = True
except ImportError:
    _OTEL_AVAILABLE = False


def setup_tracing(service_name: str = "fastapi-service") -> None:
    if not _OTEL_AVAILABLE:
        return
    provider = TracerProvider()
    provider.add_span_processor(BatchSpanProcessor(ConsoleSpanExporter()))
    trace.set_tracer_provider(provider)


def get_tracer(name: str):
    if not _OTEL_AVAILABLE:
        return _NoOpTracer()
    from opentelemetry import trace
    return trace.get_tracer(name)


class _NoOpTracer:
    \"\"\"Fallback tracer when OpenTelemetry is not installed.\"\"\"

    class _NoOpSpan:
        def __enter__(self):
            return self
        def __exit__(self, *_):
            pass

    def start_as_current_span(self, name: str, **_):
        return self._NoOpSpan()
"""

# ── gunicorn.conf.py ─────────────────────────────────────────────────────────

TPL_GUNICORN = """\
# gunicorn.conf.py — production WSGI/ASGI server configuration
import multiprocessing

# Workers
worker_class = "uvicorn.workers.UvicornWorker"
workers = multiprocessing.cpu_count() * 2 + 1
threads = 1

# Networking
host = "0.0.0.0"
port = 8000
bind = f"{host}:{port}"

# Timeouts
timeout = 120
keepalive = 5
graceful_timeout = 30

# Logging
accesslog = "-"
errorlog = "-"
loglevel = "info"
access_log_format = '%(h)s "%(r)s" %(s)s %(b)s %(D)sµs'

# Process naming
proc_name = "fastapi-service"

# Reload (disable in production)
reload = False
"""

# ── Dockerfile ───────────────────────────────────────────────────────────────

TPL_DOCKERFILE = """\
# ── Build stage ──────────────────────────────────────────────────────────────
FROM python:3.12-slim AS builder

WORKDIR /app

RUN pip install --no-cache-dir uv

COPY pyproject.toml requirements.txt* ./
RUN uv venv .venv && .venv/bin/pip install --no-cache-dir -r requirements.txt

# ── Runtime stage ─────────────────────────────────────────────────────────────
FROM python:3.12-slim AS runtime

WORKDIR /app

RUN addgroup --system appgroup && adduser --system --ingroup appgroup appuser

COPY --from=builder /app/.venv /app/.venv
COPY . .

RUN chown -R appuser:appgroup /app
USER appuser

ENV PATH="/app/.venv/bin:$PATH" \\
    PYTHONUNBUFFERED=1 \\
    PYTHONDONTWRITEBYTECODE=1

EXPOSE 8000

CMD ["gunicorn", "-c", "gunicorn.conf.py", "app.main:app"]
"""

# ── docker-compose.yml ───────────────────────────────────────────────────────

def tpl_compose(features: set[str]) -> str:
    services = """\
services:

  api:
    build: .
    ports:
      - "8000:8000"
    env_file: .env
    depends_on:
"""
    depends = []
    if "postgres" in features:
        depends.append("      - postgres")
    if "redis" in features:
        depends.append("      - redis")
    if "kafka" in features:
        depends.append("      - kafka")

    if depends:
        services += "\n".join(depends) + "\n"
    else:
        services = services.replace("    depends_on:\n", "")

    services += "    restart: unless-stopped\n"

    if "postgres" in features:
        services += """
  postgres:
    image: postgres:16-alpine
    environment:
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: postgres
      POSTGRES_DB: app
    ports:
      - "5432:5432"
    volumes:
      - pg_data:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U postgres"]
      interval: 5s
      timeout: 5s
      retries: 5
"""

    if "redis" in features:
        services += """
  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 5s
      timeout: 3s
      retries: 5
"""

    if "kafka" in features:
        services += """
  zookeeper:
    image: bitnami/zookeeper:latest
    environment:
      ALLOW_ANONYMOUS_LOGIN: "yes"

  kafka:
    image: bitnami/kafka:latest
    ports:
      - "9092:9092"
    environment:
      KAFKA_BROKER_ID: 1
      KAFKA_ZOOKEEPER_CONNECT: zookeeper:2181
      ALLOW_PLAINTEXT_LISTENER: "yes"
      KAFKA_LISTENERS: PLAINTEXT://:9092
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://localhost:9092
    depends_on:
      - zookeeper
"""

    volumes: list[str] = []
    if "postgres" in features:
        volumes.append("  pg_data:")
    if "redis" in features:
        volumes.append("  redis_data:")

    if volumes:
        services += "\nvolumes:\n" + "\n".join(volumes) + "\n"

    return services


# ── .env ─────────────────────────────────────────────────────────────────────

def tpl_env(service_name: str, features: set[str]) -> str:
    lines = [
        f"APP_NAME={service_name}",
        "ENV=development",
        "DEBUG=false",
        "LOG_LEVEL=INFO",
        "",
    ]
    if "postgres" in features:
        lines += [
            "# PostgreSQL",
            "POSTGRES_HOST=localhost",
            "POSTGRES_PORT=5432",
            "POSTGRES_DB=app",
            "POSTGRES_USER=postgres",
            "POSTGRES_PASSWORD=postgres",
            "",
        ]
    if "redis" in features:
        lines += [
            "# Redis",
            "REDIS_HOST=localhost",
            "REDIS_PORT=6379",
            "REDIS_DB=0",
            "",
        ]
    if "jwt" in features:
        lines += [
            "# JWT",
            "JWT_PRIVATE_KEY_PATH=keys/private.pem",
            "JWT_PUBLIC_KEY_PATH=keys/public.pem",
            "JWT_ALGORITHM=RS256",
            "JWT_ACCESS_TOKEN_EXPIRE_MINUTES=30",
            "",
        ]
    if "kafka" in features:
        lines += [
            "# Kafka",
            "KAFKA_BOOTSTRAP_SERVERS=localhost:9092",
            "KAFKA_TOPIC=events",
            "",
        ]
    return "\n".join(lines)


# ── pyproject.toml ───────────────────────────────────────────────────────────

def tpl_pyproject(service_name: str, features: set[str]) -> str:
    deps = [
        '"fastapi>=0.115.0"',
        '"uvicorn[standard]>=0.30.0"',
        '"pydantic[email]>=2.7.0"',
        '"pydantic-settings>=2.3.0"',
        '"python-dotenv>=1.0.0"',
        '"httpx>=0.27.0"',
    ]
    if "postgres" in features:
        deps += ['"sqlalchemy[asyncio]>=2.0.30"', '"asyncpg>=0.29.0"']
    if "redis" in features:
        deps.append('"redis>=5.0.4"')
    if "kafka" in features:
        deps.append('"aiokafka>=0.11.0"')
    if "jwt" in features:
        deps += ['"python-jose[cryptography]>=3.3.0"', '"passlib[bcrypt]>=1.7.4"']
    if "alembic" in features:
        deps.append('"alembic>=1.13.0"')

    deps_str = ",\n    ".join(deps)

    return f"""\
[project]
name = "{service_name}"
version = "0.1.0"
description = "Production FastAPI microservice"
requires-python = ">=3.12"
dependencies = [
    {deps_str}
]

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["app"]

[dependency-groups]
dev = [
    "pytest>=8.2.0",
    "pytest-asyncio>=0.23.0",
    "httpx>=0.27.0",
    "pytest-cov>=5.0.0",
]

[tool.pytest.ini_options]
asyncio_mode = "auto"
testpaths = ["tests"]

[tool.ruff]
line-length = 100
target-version = "py312"

[tool.ruff.lint]
select = ["E", "F", "I", "UP"]
"""


# ── README.md ────────────────────────────────────────────────────────────────

def tpl_readme(service_name: str, features: set[str]) -> str:
    feature_list = "\n".join(
        f"- **{k.upper()}**: {v}"
        for k, v in FEATURES.items()
        if k in features
    )
    if not feature_list:
        feature_list = "- Base FastAPI setup (no optional features)"

    docker_section = ""
    if "docker" in features:
        docker_section = """
## Docker

```bash
docker compose up --build
```

Services started:
- **api** — FastAPI on http://localhost:8000
"""
        if "postgres" in features:
            docker_section += "- **postgres** — PostgreSQL on :5432\n"
        if "redis" in features:
            docker_section += "- **redis** — Redis on :6379\n"
        if "kafka" in features:
            docker_section += "- **kafka** — Kafka on :9092\n"

    jwt_section = ""
    if "jwt" in features:
        jwt_section = """
## Authentication

JWT RS256 keys are pre-generated in `keys/`.

Obtain a token (example):
```python
from app.auth.jwt_handler import create_access_token
token = create_access_token(subject="user@example.com")
```

Use it in requests:
```
Authorization: Bearer <token>
```
"""

    return f"""\
# {service_name}

Production-ready FastAPI microservice generated by **create-fastapi-service**.

## Enabled Features

{feature_list}

## Quick Start

```bash
# Create and activate virtual environment
uv venv && source .venv/bin/activate

# Install dependencies
uv sync

# Copy and adjust environment variables
cp .env .env.local

# Run development server
uvicorn app.main:app --reload

# Run production server
gunicorn -c gunicorn.conf.py app.main:app
```

## API

| Method | Path                | Description     |
|--------|---------------------|-----------------|
| GET    | /health             | Health check    |
| GET    | /api/v1/users       | List users      |
| POST   | /api/v1/users       | Create user     |
| GET    | /api/v1/users/{{id}} | Get user by ID  |
| PUT    | /api/v1/users/{{id}} | Update user     |
| DELETE | /api/v1/users/{{id}} | Delete user     |

Interactive docs: http://localhost:8000/docs
{docker_section}{jwt_section}
## Architecture

```
Request → Middleware → Router → Endpoint → Service → Repository → Database
```

Each layer has a single responsibility:
- **Endpoint** — HTTP schema validation, request/response mapping
- **Service** — Business logic orchestration
- **Repository** — Data access abstraction
- **Model** — Persistence schema

## Project Structure

```
app/
├── api/v1/endpoints/   # HTTP handlers
├── auth/               # JWT RS256
├── cache/              # Redis + @cache()
├── core/               # Settings (pydantic-settings)
├── db/                 # Async SQLAlchemy session
├── dependencies/       # FastAPI Depends() factories
├── kafka/              # Producer / Consumer
├── logging/            # Structured logger
├── middleware/          # Request ID, context logging
├── models/             # ORM / dataclass models
├── repositories/       # DB queries
├── schemas/            # Pydantic I/O schemas
├── services/           # Business logic
├── utils/              # OpenTelemetry tracing
└── workers/            # Async background tasks
```

## Running Tests

```bash
pytest --cov=app tests/
```
"""


# ── tests/test_health.py ─────────────────────────────────────────────────────

TPL_TEST_HEALTH = """\
import pytest
from httpx import AsyncClient, ASGITransport
from app.main import app


@pytest.mark.asyncio
async def test_health():
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/api/v1/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ok"
"""

# ── alembic/env.py ───────────────────────────────────────────────────────────

TPL_ALEMBIC_ENV = """\
from logging.config import fileConfig
from sqlalchemy import engine_from_config, pool
from alembic import context
import asyncio
from sqlalchemy.ext.asyncio import AsyncEngine

config = context.config
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

from app.core.config import get_settings
from app.models.user_model import Base

settings = get_settings()
config.set_main_option("sqlalchemy.url", settings.database_url.replace("+asyncpg", ""))
target_metadata = Base.metadata


def run_migrations_offline() -> None:
    url = config.get_main_option("sqlalchemy.url")
    context.configure(url=url, target_metadata=target_metadata, literal_binds=True)
    with context.begin_transaction():
        context.run_migrations()


def do_run_migrations(connection):
    context.configure(connection=connection, target_metadata=target_metadata)
    with context.begin_transaction():
        context.run_migrations()


async def run_migrations_online() -> None:
    from app.db.session import engine
    async with engine.connect() as connection:
        await connection.run_sync(do_run_migrations)


def run_migrations() -> None:
    if context.is_offline_mode():
        run_migrations_offline()
    else:
        asyncio.run(run_migrations_online())


run_migrations()
"""

# ===========================================================================
#  GENERATOR
# ===========================================================================


def create_dirs(root: Path) -> None:
    for d in DIRS:
        (root / d).mkdir(parents=True, exist_ok=True)


def add_inits(root: Path) -> None:
    for dirpath, _, _ in os.walk(root / "app"):
        touch(Path(dirpath) / "__init__.py")
    for d in ("tests", "scripts"):
        touch(root / d / "__init__.py")


def generate_rsa_keys(root: Path) -> None:
    keys_dir = root / "keys"
    keys_dir.mkdir(exist_ok=True)
    priv = keys_dir / "private.pem"
    pub = keys_dir / "public.pem"
    try:
        run(f'openssl genrsa -out "{priv}" 2048')
        run(f'openssl rsa -in "{priv}" -pubout -out "{pub}"')
        ok("RSA key-pair generated in keys/")
    except subprocess.CalledProcessError:
        print("  [warn] openssl not found — placeholder key files created.")
        priv.write_text("# Replace with real RSA private key\n")
        pub.write_text("# Replace with real RSA public key\n")


def _uv_add(packages: list[str], root: Path, dev: bool = False) -> None:
    """Run `uv add` with a list of packages (avoids shell-quoting issues)."""
    cmd = ["uv", "add"]
    if dev:
        cmd += ["--dev"]
    cmd.extend(packages)
    subprocess.run(cmd, check=True, cwd=root)


def install_deps(root: Path, features: set[str]) -> None:
    base = [
        "fastapi>=0.115.0",
        "uvicorn[standard]>=0.30.0",
        "pydantic[email]>=2.7.0",
        "pydantic-settings>=2.3.0",
        "python-dotenv>=1.0.0",
        "httpx>=0.27.0",
    ]
    _uv_add(base, root)

    if "postgres" in features:
        _uv_add(["sqlalchemy[asyncio]>=2.0.30", "asyncpg>=0.29.0"], root)
    if "redis" in features:
        _uv_add(["redis>=5.0.4"], root)
    if "kafka" in features:
        _uv_add(["aiokafka>=0.11.0"], root)
    if "jwt" in features:
        _uv_add(["python-jose[cryptography]>=3.3.0", "passlib[bcrypt]>=1.7.4"], root)
    if "alembic" in features:
        _uv_add(["alembic>=1.13.0"], root)

    # dev deps
    _uv_add(
        ["pytest>=8.2.0", "pytest-asyncio>=0.23.0", "httpx>=0.27.0", "pytest-cov>=5.0.0"],
        root,
        dev=True,
    )


def export_requirements(root: Path) -> None:
    try:
        run("uv pip freeze > requirements.txt", cwd=root)
    except subprocess.CalledProcessError:
        pass


def generate(project: Path, features: set[str]) -> None:
    # ── 1. uv init ───────────────────────────────────────────────────────────
    banner("Initialising project with uv")
    run(f'uv init "{project.name}"', cwd=project.parent)
    ok(f"uv init complete — {project}")

    # ── 2. Directory scaffold ────────────────────────────────────────────────
    banner("Creating directory structure")
    create_dirs(project)
    add_inits(project)
    ok("Directories and __init__.py files created")

    # ── 3. Write all templates ───────────────────────────────────────────────
    banner("Writing source files")
    r = project  # shorthand

    # Core application
    write(r / "app/main.py",                   tpl_main(features))
    write(r / "app/core/config.py",            TPL_CONFIG)
    write(r / "app/logging/logger.py",         TPL_LOGGER)
    write(r / "app/middleware/request_id.py",  TPL_REQUEST_ID)
    write(r / "app/middleware/request_context.py", TPL_REQUEST_CONTEXT)
    write(r / "app/api/router.py",             TPL_API_ROUTER)
    write(r / "app/api/v1/router.py",          tpl_v1_router())
    write(r / "app/api/v1/endpoints/health.py", TPL_HEALTH)
    write(r / "app/api/v1/endpoints/users.py", tpl_users_endpoint(features))
    write(r / "app/schemas/user_schema.py",    TPL_USER_SCHEMA)
    write(r / "app/models/user_model.py",      tpl_user_model(features))
    write(r / "app/repositories/user_repository.py", tpl_user_repository(features))
    write(r / "app/services/user_service.py",  tpl_user_service(features))
    write(r / "app/dependencies/auth.py",      tpl_dependencies_auth(features))
    write(r / "app/utils/tracing.py",          TPL_TRACING)
    write(r / "gunicorn.conf.py",              TPL_GUNICORN)
    write(r / "tests/test_health.py",          TPL_TEST_HEALTH)

    # Feature-conditional files
    if "postgres" in features:
        write(r / "app/db/session.py", TPL_DB_SESSION)
        ok("PostgreSQL session (async SQLAlchemy)")

    if "redis" in features:
        write(r / "app/cache/redis_client.py",  TPL_REDIS_CLIENT)
        write(r / "app/cache/decorators.py",    TPL_CACHE_DECORATOR)
        ok("Redis client + @cache() decorator")

    if "jwt" in features:
        write(r / "app/auth/jwt_handler.py", TPL_JWT_HANDLER)
        ok("JWT RS256 handler")

    if "kafka" in features:
        write(r / "app/kafka/producer.py", TPL_KAFKA_PRODUCER)
        write(r / "app/kafka/consumer.py", TPL_KAFKA_CONSUMER)
        ok("Kafka producer + consumer (aiokafka)")

    if "workers" in features:
        write(r / "app/workers/task_worker.py", TPL_TASK_WORKER)
        ok("Async background worker")

    if "docker" in features:
        write(r / "Dockerfile",           TPL_DOCKERFILE)
        write(r / "docker-compose.yml",   tpl_compose(features))
        write(r / ".dockerignore",
              ".venv\n__pycache__\n*.pyc\n*.pyo\n.env\nkeys/\n.git\n")
        ok("Dockerfile + docker-compose.yml")

    if "alembic" in features:
        write(r / "migrations/env.py", TPL_ALEMBIC_ENV)
        write(r / "migrations/script.py.mako",
              "\"\"\"${message}\n\nRevision ID: ${up_revision}\n\"\"\"\n"
              "from alembic import op\nimport sqlalchemy as sa\n\n"
              "revision = ${repr(up_revision)!r}\ndown_revision = ${repr(down_revision)!r}\n"
              "branch_labels = ${repr(branch_labels)!r}\ndepends_on = ${repr(depends_on)!r}\n\n"
              "def upgrade(): pass\ndef downgrade(): pass\n")
        write(r / "alembic.ini",
              "[alembic]\nscript_location = migrations\n"
              "prepend_sys_path = .\nversion_path_separator = os\n\n"
              "[loggers]\nkeys = root,sqlalchemy,alembic\n\n"
              "[handlers]\nkeys = console\n\n"
              "[formatters]\nkeys = generic\n\n"
              "[logger_root]\nlevel = WARN\nhandlers = console\nqualname =\n\n"
              "[logger_sqlalchemy]\nlevel = WARN\nhandlers =\nqualname = sqlalchemy.engine\n\n"
              "[logger_alembic]\nlevel = INFO\nhandlers =\nqualname = alembic\n\n"
              "[handler_console]\nclass = StreamHandler\nargs = (sys.stderr,)\nlevel = NOTSET\n"
              "formatter = generic\n\n"
              "[formatter_generic]\nformat = %(levelname)-5.5s [%(name)s] %(message)s\n")
        ok("Alembic migration scaffold")

    # Config files
    write(r / ".env",           tpl_env(project.name, features))
    write(r / "pyproject.toml", tpl_pyproject(project.name, features))
    write(r / "README.md",      tpl_readme(project.name, features))

    # ── 4. Generate RSA keys ─────────────────────────────────────────────────
    if "jwt" in features:
        banner("Generating RSA key-pair for JWT RS256")
        generate_rsa_keys(project)

    # ── 5. Install dependencies ──────────────────────────────────────────────
    banner("Installing dependencies via uv")
    install_deps(project, features)
    export_requirements(project)
    ok("Dependencies installed — requirements.txt exported")

    # ── 6. Done ──────────────────────────────────────────────────────────────
    _print_instructions(project, features)


def _print_instructions(project: Path, features: set[str]) -> None:
    banner(f"Project '{project.name}' created successfully!")

    enabled = ", ".join(sorted(features)) if features else "none"
    print(f"\n  Features enabled: {enabled}\n")

    print("  \033[1mNext steps:\033[0m\n")
    print(f"    cd {project.name}")
    print("")
    print("  # .venv was created and all deps installed by the generator.")
    print("  # Recommended — let uv manage the venv (no activation needed):\n")
    print("    uv run uvicorn app.main:app --reload\n")
    print("  # Or activate manually (do NOT run 'uv venv' — it wipes the venv):\n")
    print("    source .venv/bin/activate")
    print("    uvicorn app.main:app --reload\n")
    print("  # If you accidentally ran 'uv venv', restore deps with:\n")
    print("    uv sync")
    print("    uv run uvicorn app.main:app --reload\n")

    if "docker" in features:
        print("  \033[1mOr with Docker:\033[0m\n")
        print("    docker compose up --build\n")

    if "jwt" in features:
        print("  \033[1mGenerate a token:\033[0m\n")
        print("    uv run python -c \"from app.auth.jwt_handler import create_access_token; "
              "print(create_access_token('user@example.com'))\"\n")

    if "alembic" in features:
        print("  \033[1mDatabase migrations:\033[0m\n")
        print('    uv run alembic revision --autogenerate -m "init"')
        print("    uv run alembic upgrade head\n")

    slug = project.name.lower().replace(" ", "-")
    print(f"  \033[1mAPI docs:\033[0m")
    print(f"    Swagger UI  →  http://localhost:8000/{slug}/docs")
    print(f"    ReDoc       →  http://localhost:8000/{slug}/redoc")
    print(f"    OpenAPI     →  http://localhost:8000/{slug}/openapi.json")
    print(f"    Health      →  http://localhost:8000/{slug}/api/v1/health\n")


# ===========================================================================
#  CLI
# ===========================================================================


def interactive_prompt() -> set[str]:
    print("\n\033[1mSelect features for your service:\033[0m\n")
    selected: set[str] = set()
    for key, desc in FEATURES.items():
        ans = input(f"  Enable {desc}? (y/N): ").strip().lower()
        if ans in ("y", "yes"):
            selected.add(key)
    return selected


def parse_args() -> tuple[str, set[str]]:
    parser = argparse.ArgumentParser(
        prog="create-fastapi-service",
        description="Generate a production-ready FastAPI microservice.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent("""\
            examples:
              create-fastapi-service payment-service --all
              create-fastapi-service auth-service --postgres --redis --jwt
              create-fastapi-service event-service --kafka --workers
              create-fastapi-service my-api --interactive
        """),
    )

    parser.add_argument("name", help="Service name (used as project directory name)")
    parser.add_argument("--all", action="store_true", help="Enable every feature")
    parser.add_argument("--interactive", action="store_true",
                        help="Prompt for each feature interactively")

    for key, desc in FEATURES.items():
        parser.add_argument(f"--{key}", action="store_true", help=f"Enable {desc}")

    args = parser.parse_args()

    if args.interactive:
        features = interactive_prompt()
    elif args.all:
        features = set(FEATURES.keys())
    else:
        features = {k for k in FEATURES if getattr(args, k)}

    return args.name, features


def main() -> None:
    service_name, features = parse_args()

    project = Path.cwd() / service_name

    if project.exists():
        print(f"\033[31mError: directory '{service_name}' already exists.\033[0m")
        sys.exit(1)

    print(f"\n\033[1;35mcreate-fastapi-service\033[0m  →  {service_name}")
    if features:
        print("  Features: " + ", ".join(sorted(features)))
    else:
        print("  Features: base only (use --all or specific flags to add more)")

    generate(project, features)


if __name__ == "__main__":
    main()
