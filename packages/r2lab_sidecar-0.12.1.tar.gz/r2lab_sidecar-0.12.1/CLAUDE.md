# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

r2lab-sidecar is a WebSocket-based companion service for the R2Lab wireless testbed at INRIA. It maintains real-time testbed status (nodes, phones, PDUs, leases) and broadcasts updates to connected clients including the R2Lab web interface.

## Commands

```bash
# Install in development mode
pip install -e .

# Run locally (no SSL, ws://localhost:10000)
r2lab-sidecar --devel --debug

# Deploy to staging (preplab)
make preplab

# Deploy to production
make r2lab

# Check version on infrastructure
make check
```

There are no tests, linting, or CI configured.

## Architecture

**Data flow:** Monitoring services on faraday → r2lab-sidecar (WebSocket server) → Web clients + R2Lab Django app

### Core Components

- **`r2lab_sidecar/server.py`** — The entire server in one file. Two classes:
  - `Category`: Manages state for one data category. Persistent categories (nodes, phones, pdus) store to JSON files; leases are non-persistent (replaced in full each time).
  - `SidecarServer`: AsyncIO WebSocket server that tracks clients, handles incoming messages, and broadcasts updates.

- **`web/`** — Vanilla JS/jQuery/Bootstrap debug client for connecting to the server and inspecting/sending messages. Not packaged with pip.

### Message Protocol

JSON messages with three fields: `category` (nodes/phones/pdus/leases), `action` (request/info/delete), `message` (payload).

- `request`: Ask server to broadcast current full state for a category
- `info`: Incremental update for id-based categories; full replacement for leases
- `delete`: Remove records by id from persistent categories

### Storage

Persistent categories save to `/var/lib/sidecar/{name}.json` (production) or `./{name}.json` (development fallback). Records are keyed by `id` field.

### Server Modes

- **Production:** `wss://r2lab-sidecar.inria.fr:443/` with SSL certs from `/etc/dsissl/auto/`
- **Development:** `ws://localhost:10000/` via `--devel` flag

## Deployment

Uses conda environment `r2lab-dev-313` on target hosts. The Makefile rsyncs git-tracked files and installs via `pip install -e`. The systemd service file is in `systemd/` but must be installed manually.
