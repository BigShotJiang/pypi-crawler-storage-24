"""
wechat_cloud 工具：云函数管理聚合。

合并原 wechat_cloud_env_list、wechat_cloud_func_list、wechat_cloud_func_info、
wechat_cloud_func_deploy、wechat_cloud_func_download。
"""
from typing import TYPE_CHECKING

from ..core.cli import _run_cli, _resolve_project_path
from ..core.errors import ErrorCode
from ..models.schemas import WechatCloudInput
from ..utils.response import _ok, _fail

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP


def register_cloud(mcp: "FastMCP") -> None:
    """将 wechat_cloud 工具注册到 FastMCP 实例。"""
    mcp.tool(
        name="wechat_cloud",
        annotations={
            "title": "云函数管理",
            "readOnlyHint": False,
            "destructiveHint": False,
            "idempotentHint": False,
            "openWorldHint": False,
        },
    )(wechat_cloud)


async def wechat_cloud(params: WechatCloudInput) -> str:
    """微信云开发环境与云函数管理。
    支持 action: env_list(列出环境), func_list(函数列表),
    func_info(函数信息), func_deploy(上传函数), func_download(下载函数)。
    返回 JSON: {success, data, message, error_code?}。
    """
    # env 必填校验
    if params.action in ("func_list", "func_info", "func_deploy", "func_download"):
        if not params.env:
            return _fail(
                ErrorCode.PARAM_MISSING,
                f"action='{params.action}' 缺少必填参数: env",
                hint="请提供云环境 ID。",
            )

    if params.action == "func_download":
        missing = [p for p in ["name", "download_path"] if not getattr(params, p)]
        if missing:
            return _fail(ErrorCode.PARAM_MISSING, f"action='func_download' 缺少必填参数: {', '.join(missing)}")

    try:
        if params.action == "env_list":
            return await _action_env_list(params)
        elif params.action == "func_list":
            return await _action_func_list(params)
        elif params.action == "func_info":
            return await _action_func_info(params)
        elif params.action == "func_deploy":
            return await _action_func_deploy(params)
        elif params.action == "func_download":
            return await _action_func_download(params)
        else:
            return _fail(ErrorCode.UNKNOWN_ERROR, f"未知 action: {params.action}")
    except ValueError as e:
        return _fail(ErrorCode.PROJECT_PATH_MISSING, str(e))
    except Exception as e:
        return _fail(ErrorCode.UNKNOWN_ERROR, f"执行失败：{type(e).__name__}: {e}")


async def _action_env_list(params: WechatCloudInput) -> str:
    proj = _resolve_project_path(params.project_path)
    args = ["cloud", "env", "list", "--project", proj]
    if params.appid:
        args.extend(["--appid", params.appid])
    if params.port is not None:
        args.extend(["--port", str(params.port)])
    if params.lang:
        args.extend(["--lang", params.lang])
    result = await _run_cli(*args)
    if result["success"]:
        return _ok({"stdout": result["stdout"]}, message="云环境列表获取成功。")
    return _fail(ErrorCode.UNKNOWN_ERROR, result.get("stderr") or "获取失败")


async def _action_func_list(params: WechatCloudInput) -> str:
    args = ["cloud", "functions", "list", "--env", params.env]
    if params.project_path:
        args.extend(["--project", params.project_path])
    if params.appid:
        args.extend(["--appid", params.appid])
    if params.port is not None:
        args.extend(["--port", str(params.port)])
    result = await _run_cli(*args)
    if result["success"]:
        return _ok({"env": params.env, "stdout": result["stdout"]}, message="云函数列表获取成功。")
    return _fail(ErrorCode.UNKNOWN_ERROR, result.get("stderr") or "获取失败")


async def _action_func_info(params: WechatCloudInput) -> str:
    if not params.names:
        return _fail(ErrorCode.PARAM_MISSING, "action='func_info' 缺少必填参数: names")
    args = ["cloud", "functions", "info", "--env", params.env, "--names"] + params.names
    if params.project_path:
        args.extend(["--project", params.project_path])
    if params.appid:
        args.extend(["--appid", params.appid])
    if params.port is not None:
        args.extend(["--port", str(params.port)])
    result = await _run_cli(*args)
    if result["success"]:
        return _ok({"env": params.env, "names": params.names, "stdout": result["stdout"]}, message="云函数信息获取成功。")
    return _fail(ErrorCode.UNKNOWN_ERROR, result.get("stderr") or "获取失败")


async def _action_func_deploy(params: WechatCloudInput) -> str:
    args = ["cloud", "functions", "deploy", "--env", params.env]
    if params.remote_npm_install:
        args.append("-r")
    if params.names:
        args.extend(["--names"] + params.names)
    if params.paths:
        args.extend(["--paths"] + params.paths)
    if params.project_path:
        args.extend(["--project", params.project_path])
    if params.appid:
        args.extend(["--appid", params.appid])
    if params.port is not None:
        args.extend(["--port", str(params.port)])
    result = await _run_cli(*args, timeout=120)
    if result["success"]:
        return _ok({"env": params.env}, message="云函数上传成功。")
    return _fail(ErrorCode.UNKNOWN_ERROR, result.get("stderr") or "上传失败")


async def _action_func_download(params: WechatCloudInput) -> str:
    args = ["cloud", "functions", "download", "--env", params.env, "--name", params.name, "--path", params.download_path]
    if params.project_path:
        args.extend(["--project", params.project_path])
    if params.appid:
        args.extend(["--appid", params.appid])
    if params.port is not None:
        args.extend(["--port", str(params.port)])
    result = await _run_cli(*args, timeout=120)
    if result["success"]:
        return _ok({"name": params.name, "path": params.download_path}, message=f"云函数 {params.name} 下载成功。")
    return _fail(ErrorCode.UNKNOWN_ERROR, result.get("stderr") or "下载失败")
