"""
wechat_screenshot 工具：截图（独立工具，无 action 参数）。

保持独立是因为 output_path 为特殊必填参数，与其他工具参数差异大。
"""
import os
from typing import TYPE_CHECKING

from ..core.config import CLI_TIMEOUT
from ..core.errors import ErrorCode
from ..core.node_bridge import _run_node_script
from ..models.schemas import WechatScreenshotInput
from ..utils.response import _ok, _fail

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP


def register_screenshot(mcp: "FastMCP") -> None:
    """将 wechat_screenshot 工具注册到 FastMCP 实例。"""
    mcp.tool(
        name="wechat_screenshot",
        annotations={
            "title": "捕获界面截图",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )(wechat_screenshot)


async def wechat_screenshot(params: WechatScreenshotInput) -> str:
    """实时捕获当前小程序模拟器的界面截图。
    默认支持截取长图，自动滚动并拼接。
    必须明确指定 output_path 参数以保存 PNG 文件。
    返回 JSON: {success, data: {path, width, height, segments}, message}。
    """
    try:
        result = await _run_node_script(
            "screenshot.js",
            "--port", str(params.auto_port),
            "--output", params.output_path,
            "--overlap", str(params.overlap),
            timeout=CLI_TIMEOUT + 60,
        )

        if not result.get("success"):
            error_msg = result.get("error") or result.get("message") or "未知错误"
            return _fail(ErrorCode.UNKNOWN_ERROR, f"截图失败：{error_msg}")

        abs_path = result.get("path", params.output_path)
        file_size = 0
        try:
            file_size = os.path.getsize(abs_path)
        except OSError:
            pass

        return _ok(
            {
                "path": abs_path,
                "width": result.get("width", 0),
                "height": result.get("height", 0),
                "segments": result.get("segments", 1),
                "file_size": file_size,
            },
            message=f"截图成功，共 {result.get('segments', 1)} 段，已保存至 {abs_path}。",
        )
    except Exception as e:
        return _fail(ErrorCode.UNKNOWN_ERROR, f"截图异常：{type(e).__name__}: {e}")
