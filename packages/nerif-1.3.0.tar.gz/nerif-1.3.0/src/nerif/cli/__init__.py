# CLI utilities for Nerif
