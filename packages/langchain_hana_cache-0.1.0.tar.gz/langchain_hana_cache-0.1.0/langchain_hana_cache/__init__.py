"""Semantic caching for LLM responses on SAP HANA Cloud.

Provides cache implementations that store LLM responses in SAP HANA Cloud
and return cached results for semantically similar prompts, reducing
token usage and latency.
"""

from langchain_hana_cache.llm_cache import HANASemanticLLMCache

__all__ = ["HANASemanticLLMCache"]
__version__ = "0.1.0"
