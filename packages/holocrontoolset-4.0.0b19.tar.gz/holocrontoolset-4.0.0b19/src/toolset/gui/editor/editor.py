"""Editor factory and base: open/save/close, recent files, and resource loading for all editors."""

from __future__ import annotations

import tempfile

from abc import abstractmethod
from contextlib import suppress
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Optional, Sequence, cast

import qtpy

from qtpy import QtCore
from qtpy.QtCore import QBuffer, QIODevice, QPoint, QTimer, QUrl, Qt
from qtpy.QtGui import QIcon, QPixmap
from qtpy.QtMultimedia import QMediaPlayer
from qtpy.QtWidgets import (
    QApplication,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QLabel,
    QMainWindow,
    QMenu,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QShortcut,  # pyright: ignore[reportPrivateImportUsage]
    QSlider,
    QStyle,
    QToolBar,
    QVBoxLayout,
    QWidget,
)

from loggerplus import RobustLogger
from pykotor.common.module import Module
from pykotor.common.stream import BinaryReader
from pykotor.extract.capsule import Capsule
from pykotor.extract.file import ResourceIdentifier
from pykotor.extract.installation import SearchLocation
from pykotor.resource.formats.erf import ERFType, read_erf, write_erf
from pykotor.resource.formats.erf.erf_data import ERF
from pykotor.resource.formats.gff.gff_auto import bytes_gff, read_gff
from pykotor.resource.formats.rim import read_rim, write_rim
from pykotor.resource.type import ResourceType
from pykotor.tools import module
from pykotor.tools.misc import is_any_erf_type_file, is_bif_file, is_capsule_file, is_rim_file, is_sav_file
from pykotor.tools.path import CaseAwarePath
from toolset.gui.common.tooltip_utils import copy_tooltips_to_form_labels
from toolset.gui.dialogs.load_from_module import LoadFromModuleDialog
from toolset.gui.dialogs.save.to_bif import BifSaveDialog, BifSaveOption
from toolset.gui.dialogs.save.to_module import SaveToModuleDialog
from toolset.gui.dialogs.save.to_rim import RimSaveDialog, RimSaveOption
from toolset.data.installation import HTInstallation
from toolset.gui.widgets.installation_toolbar import StandaloneWindowMixin
from toolset.gui.widgets.settings.installations import GlobalSettings, InstallationsWidget
from toolset.utils.window import TOOLSET_WINDOWS
from ui import stylesheet_resources  # noqa: PLC0415, F401, I001  # pylint: disable=C0415
from utility.error_handling import assert_with_variable_trace, format_exception_with_variables
from utility.system.os_helper import remove_any

if qtpy.API_NAME == "PySide2":
    from toolset.rcc import resources_rc_pyside2  # noqa: PLC0415, F401  # pylint: disable=C0415
elif qtpy.API_NAME == "PySide6":
    from toolset.rcc import resources_rc_pyside6  # noqa: PLC0415, F401  # pylint: disable=C0415
elif qtpy.API_NAME == "PyQt5":
    from toolset.rcc import resources_rc_pyqt5  # noqa: PLC0415, F401  # pylint: disable=C0415
elif qtpy.API_NAME == "PyQt6":
    from toolset.rcc import resources_rc_pyqt6  # noqa: PLC0415, F401  # pylint: disable=C0415
else:
    raise ImportError(f"Unsupported Qt bindings: {qtpy.API_NAME}")

if TYPE_CHECKING:
    import os

    from pathlib import PurePath

    from PyQt6.QtMultimedia import QMediaPlayer as PyQt6MediaPlayer
    from PySide6.QtMultimedia import QMediaPlayer as PySide6MediaPlayer
    from qtpy.QtGui import QFocusEvent, QMouseEvent, QShowEvent
    from qtpy.QtWidgets import (  # pyright: ignore[reportPrivateImportUsage]
        QAction,
        QLineEdit,
        QMenuBar,
    )

    from pykotor.common.language import LocalizedString
    from pykotor.resource.formats.rim.rim_data import RIM
    from toolset.data.installation import HTInstallation


class MediaPlayerWidget(QWidget):
    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.buffer: QBuffer = QBuffer(self)
        self.player: QMediaPlayer = QMediaPlayer(self)
        self.setupMediaPlayer()
        self._setupSignals()

        self.hideWidget()

    def setupMediaPlayer(self):
        from toolset.uic.qtpy.widgets.media_player_controls import Ui_Form

        self.ui = Ui_Form()
        self.ui.setupUi(self)

        self.speed_levels: list[float] = [1, 1.25, 1.5, 2, 5, 10]
        self.current_speed_index: int = 0

        # Store references for easier access
        self.playPauseButton = self.ui.playPauseButton
        self.stopButton = self.ui.stopButton
        self.muteButton = self.ui.muteButton
        self.timeLabel = self.ui.timeLabel
        self.timeSlider = self.ui.timeSlider

        # Set button icons
        self.playPauseButton.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MediaPlay))  # pyright: ignore[reportOptionalMemberAccess]
        self.stopButton.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MediaStop))  # pyright: ignore[reportOptionalMemberAccess]
        self.muteButton.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MediaVolume))  # pyright: ignore[reportOptionalMemberAccess]

        # Set button alignment
        for button in [self.playPauseButton, self.stopButton, self.muteButton]:
            self.ui.buttonLayout.setAlignment(button, Qt.AlignmentFlag.AlignBottom)

        # Setup time slider
        self.setupTimeSlider()

        self.hideWidget()

    def setupTimeSlider(self):
        # timeSlider is already created in the .ui file, just configure it
        self.timeSlider.setMouseTracking(True)
        self.dragPosition = QPoint()

        def sliderMousePressEvent(ev: QMouseEvent, slider: QSlider = self.timeSlider):
            if ev.button() == Qt.LeftButton:  # pyright: ignore[reportAttributeAccessIssue]
                self.player.pause()
                self.dragPosition = ev.pos()  # Store click position
                ev.accept()
            super(QSlider, slider).mousePressEvent(ev)

        def sliderMouseMoveEvent(ev: QMouseEvent, slider: QSlider = self.timeSlider):
            if ev.buttons() == Qt.LeftButton and not self.dragPosition.isNull():  # pyright: ignore[reportAttributeAccessIssue]
                value = int((ev.pos().x() / slider.width()) * slider.maximum())
                slider.setValue(value)
                self.player.setPosition(value)
                ev.accept()
            super(QSlider, slider).mouseMoveEvent(ev)

        def sliderMouseReleaseEvent(ev: QMouseEvent, slider: QSlider = self.timeSlider):
            if ev.button() == Qt.LeftButton and not self.dragPosition.isNull():  # pyright: ignore[reportAttributeAccessIssue]
                # Set the final value and clear dragPosition
                value = int((ev.pos().x() / slider.width()) * slider.maximum())
                slider.setValue(value)
                self.player.setPosition(value)
                self.player.play()
                self.dragPosition = QPoint()  # Reset drag position
                ev.accept()
            super(QSlider, slider).mouseReleaseEvent(ev)

        def sliderFocusOutEvent(ev: QFocusEvent, slider: QSlider = self.timeSlider):
            if not self.dragPosition.isNull():
                value = int((self.dragPosition.x() / slider.width()) * slider.maximum())
                slider.setValue(value)
                self.player.setPosition(value)
                self.player.play()
                ev.accept()
            super(QSlider, slider).focusOutEvent(ev)

        self.timeSlider.mouseMoveEvent = sliderMouseMoveEvent  # type: ignore[method-override]
        self.timeSlider.mousePressEvent = sliderMousePressEvent  # type: ignore[method-override]
        self.timeSlider.mouseReleaseEvent = sliderMouseReleaseEvent  # type: ignore[method-override]
        self.timeSlider.focusOutEvent = sliderFocusOutEvent  # type: ignore[method-override]

    def playPauseButtonClick(self):
        stateEnum = QMediaPlayer.State if qtpy.QT5 else QMediaPlayer.PlaybackState  # pyright: ignore[reportAttributeAccessIssue]
        stateGetter = self.player.state if qtpy.QT5 else self.player.playbackState  # pyright: ignore[reportAttributeAccessIssue]
        if stateGetter() == stateEnum.PlayingState:
            self.playPauseButton.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MediaPlay))  # pyright: ignore[reportOptionalMemberAccess]
            self.player.pause()
        else:
            self.playPauseButton.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MediaPause))  # pyright: ignore[reportOptionalMemberAccess]
            self.player.play()

    def _setupSignals(self):
        self.player.mediaStatusChanged.connect(self.mediaStateChanged)
        self.player.positionChanged.connect(self.positionChanged)
        self.player.durationChanged.connect(self.durationChanged)
        stateChanged = self.player.stateChanged if qtpy.QT5 else self.player.playbackStateChanged  # pyright: ignore[reportAttributeAccessIssue]
        stateChanged.connect(self.stateChanged)

        self.playPauseButton.clicked.connect(self.playPauseButtonClick)
        self.stopButton.clicked.connect(lambda *args: self.player.stop() or self.hideWidget())
        self.muteButton.clicked.connect(self.toggleMute)

    def stateChanged(self, state: QMediaPlayer.MediaStatus):
        stateEnum = QMediaPlayer.State if qtpy.QT5 else QMediaPlayer.PlaybackState  # pyright: ignore[reportAttributeAccessIssue]
        if state == stateEnum.PlayingState:
            self.showWidget()

    def format_time(self, msecs: int) -> str:
        secs = msecs // 1000
        mins = secs // 60
        hrs = mins // 60
        return f"{hrs:02}:{mins % 60:02}:{secs % 60:02}"

    def mediaStateChanged(self, state: QMediaPlayer.MediaStatus):
        if state == QMediaPlayer.MediaStatus.EndOfMedia:
            self.timeSlider.setValue(self.timeSlider.maximum())
            self.hideWidget()
        stateEnum = QMediaPlayer.State if qtpy.QT5 else QMediaPlayer.PlaybackState  # pyright: ignore[reportAttributeAccessIssue]
        if state == stateEnum.PlayingState:
            self.playPauseButton.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MediaPause))  # pyright: ignore[reportOptionalMemberAccess]
        else:
            self.playPauseButton.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MediaPlay))  # pyright: ignore[reportOptionalMemberAccess]

    def changePlaybackSpeed(self, direction: int):
        """Some qt bug prevents this from working properly. Requires a start and a play in order to take effect."""
        self.current_speed_index = max(0, min(len(self.speed_levels) - 1, self.current_speed_index + direction))
        newRate = self.speed_levels[self.current_speed_index]
        stateEnum = QMediaPlayer.State if qtpy.QT5 else QMediaPlayer.PlaybackState  # pyright: ignore[reportAttributeAccessIssue]
        stateGetter = self.player.state if qtpy.QT5 else self.player.playbackState  # pyright: ignore[reportAttributeAccessIssue]
        wasPlaying = stateGetter() == stateEnum.PlayingState
        currentPosition = self.player.position()
        self.player.setPlaybackRate(newRate)
        self.player.setPosition(currentPosition)
        if wasPlaying:
            self.player.play()

    def toggleMute(self):
        if qtpy.QT5:
            self.player.setMuted(not self.player.isMuted())  # pyright: ignore[reportAttributeAccessIssue]
            muted = self.player.isMuted()  # pyright: ignore[reportAttributeAccessIssue]
        else:
            audio_output = self.player.audioOutput()  # pyright: ignore[reportAttributeAccessIssue]
            if audio_output is None:
                return
            current_volume = audio_output.volume()
            if current_volume > 0:
                self.previous_volume = current_volume
                audio_output.setVolume(0)
                muted = True
            else:
                audio_output.setVolume(self.previous_volume if hasattr(self, "previous_volume") else 0.5)
                muted = False
        if muted:
            self.muteButton.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MediaVolumeMuted))  # pyright: ignore[reportOptionalMemberAccess]
        else:
            self.muteButton.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MediaVolume))  # pyright: ignore[reportOptionalMemberAccess]

    def positionChanged(self, position: int):
        if not self.timeSlider.isSliderDown():
            self.timeSlider.setValue(position)
        current_time = self.format_time(position)
        total_time = self.format_time(self.timeSlider.maximum())
        self.timeLabel.setText(f"{current_time} / {total_time}")

    def durationChanged(self, duration: int):
        self.timeSlider.setRange(0, duration)
        total_time = self.format_time(duration)
        current_time = self.format_time(self.timeSlider.value())
        self.timeLabel.setText(f"{current_time} / {total_time}")

    def showWidget(self):
        self.show()
        self.playPauseButton.show()
        self.stopButton.show()
        self.muteButton.show()
        self.timeLabel.show()
        self.timeSlider.show()

    def hideWidget(self):
        self.hide()
        self.playPauseButton.hide()
        self.stopButton.hide()
        self.muteButton.hide()
        self.timeLabel.hide()
        self.timeSlider.hide()

    def setVisible(self, visible: bool):  # noqa: FBT001
        """Override to control visibility based on player state."""
        stateEnum = QMediaPlayer.State if qtpy.QT5 else QMediaPlayer.PlaybackState  # pyright: ignore[reportAttributeAccessIssue]
        stateGetter = self.player.state if qtpy.QT5 else self.player.playbackState  # pyright: ignore[reportAttributeAccessIssue]
        if stateGetter() == stateEnum.PlayingState:
            return
        super().setVisible(visible)

    def showEvent(self, event: QShowEvent):
        """Override to prevent showing unless playing."""
        stateEnum = QMediaPlayer.State if qtpy.QT5 else QMediaPlayer.PlaybackState  # pyright: ignore[reportAttributeAccessIssue]
        stateGetter = self.player.state if qtpy.QT5 else self.player.playbackState  # pyright: ignore[reportAttributeAccessIssue]
        if stateGetter() != stateEnum.PlayingState:
            return
        super().showEvent(event)


class Editor(QMainWindow, StandaloneWindowMixin):
    """Editor is a base class for all file-specific editors.

    Provides methods for saving and loading files that are stored directly in folders and for files that are encapsulated in a MOD or RIM.

    ## Child Editor (Capsule Editor) Requirements

    A "child editor" or "capsule editor" is an editor that can contain other editors within it (e.g., ERF Editor containing multiple file editors).
    Creating a child editor from this base class requires careful setup:

    ### Required Setup:
    1. **Set Capsule Flag**: Set `self._is_capsule_editor = True` in your editor's `__init__` method
    2. **Handle Nested Saving**: Implement proper handling of nested capsule saving in your save methods
    3. **Parent-Child Relationships**: Understand that child editors modify data within their parent capsule

    ### Key Behaviors:
    - **Save Logic**: When `_is_capsule_editor` is True, the save process handles nested capsules differently
    - **Data Flow**: Child editors save their data back to their parent capsule, not to disk directly
    - **Nested Capsules**: Support for ERF/RIM files containing other ERF/RIM files (nested capsules)

    ### Implementation Example:
    ```python
    class MyCapsuleEditor(Editor):
        def __init__(self, parent, ...):
            super().__init__(parent, title, icon, read_types, write_types, installation)
            self._is_capsule_editor = True  # Required for capsule editor behavior
            # ... rest of initialization
    ```

    ### Save Process for Child Editors:
    1. Child editor saves its data to the in-memory capsule structure
    2. Parent capsule editor(s) handle writing the complete nested structure to disk
    3. Each level of nesting is properly serialized from inner to outer capsules

    ### Common Pitfalls:
    - Forgetting to set `_is_capsule_editor = True` causes incorrect save behavior
    - Not handling nested capsule paths properly in save operations
    - Incorrect parent-child data flow assumptions
    """

    newFile = QtCore.Signal()  # pyright: ignore[reportPrivateImportUsage]
    savedFile = QtCore.Signal(object, object, object, object)  # pyright: ignore[reportPrivateImportUsage]
    loadedFile = QtCore.Signal(object, object, object, object)  # pyright: ignore[reportPrivateImportUsage]

    CAPSULE_FILTER = "*.mod *.erf *.rim *.sav"

    def __init__(
        self,
        parent: QWidget | None,
        title: str,
        iconName: str,
        readSupported: list[ResourceType],
        writeSupported: list[ResourceType],
        installation: HTInstallation | None = None,
    ):
        """Initializes the editor.

        Args:
        ----
            parent: QWidget: The parent widget
            title: str: The title of the editor window
            iconName: str: The name of the icon to display
            readSupported: list[ResourceType]: The supported resource types for reading
            writeSupported: list[ResourceType]: The supported resource types for writing
            installation: HTInstallation | None: The installation context

        Initializes editor properties:
            - Sets up title, icon and parent widget
            - Sets supported read/write resource types
            - Initializes file filters for opening and saving
            - Sets up other editor properties.
        """
        super().__init__(parent)
        self._is_capsule_editor: bool = False
        self._installation: HTInstallation | None = installation
        self._logger = RobustLogger()
        self._global_settings: GlobalSettings = GlobalSettings()

        self._editorTitle: str = title
        self._filepath: Path | None = None
        self._resname: str | None = None
        self._restype: ResourceType | None = None
        self._revert: bytes | None = None
        self._is_save_game_resource: bool = False  # Flag to track if resource is from a save game

        # Create media player as a child widget (not added to any layout)
        # NOTE: Do NOT call setLayout() on a QMainWindow - it interferes with the
        # central widget mechanism and causes layout issues. The mediaPlayer is used
        # for audio playback via playSound() and doesn't need to be in a layout.
        self.mediaPlayer: MediaPlayerWidget = MediaPlayerWidget(self)
        self.setWindowTitle(title)
        self._setupIcon(iconName)

        self.setupEditorFilters(readSupported, writeSupported)

        # Unified editor toolbar: subclasses add installation combobox and custom controls via _populate_editor_toolbar.
        self._editor_toolbar: QToolBar = QToolBar(self)
        self._editor_toolbar.setObjectName("editorToolbar")
        self.addToolBar(Qt.ToolBarArea.TopToolBarArea, self._editor_toolbar)
        self._installation_combo: QComboBox | None = None
        self._installation_cache: dict[str, HTInstallation] = {}
        self._saved_installations: dict[str, dict[str, str | bool]] = {}
        self._installation_combo_in_update: bool = False

    def _populate_editor_toolbar(self, toolbar: QToolBar) -> None:
        """Override in subclasses to add installation combobox and editor-specific controls.

        Subclasses that need an installation should call _add_installation_combobox_to_toolbar(toolbar)
        and then add their own widgets. Call this at the end of the subclass __init__.
        """
        pass

    def _add_installation_combobox_to_toolbar(self, toolbar: QToolBar) -> None:
        """Add Installation: combobox and Reload/Manage buttons to the editor toolbar.

        Populates from GlobalSettings; when self._installation is already set (embedded),
        selects that installation in the combobox. Connects selection to _on_installation_changed.
        """
        from toolset.gui.common.localization import translate as tr

        toolbar.addWidget(QLabel(tr("Installation:")))
        self._installation_combo = QComboBox(self)
        self._installation_combo.setMinimumWidth(180)
        toolbar.addWidget(self._installation_combo)
        reload_btn = QPushButton(tr("Reload"), self)
        reload_btn.clicked.connect(self._reload_installation_combo)
        toolbar.addWidget(reload_btn)
        manage_btn = QPushButton(tr("Manage..."), self)
        manage_btn.clicked.connect(self._open_installations_manage_dialog)
        toolbar.addWidget(manage_btn)
        self._reload_installation_combo()
        self._installation_combo.currentIndexChanged.connect(self._on_installation_combo_changed)

    def _reload_installation_combo(self) -> None:
        """Reload installation list from GlobalSettings and preserve current selection or set from self._installation."""
        if self._installation_combo is None:
            return
        current_key = self._installation_combo.currentData()
        self._saved_installations = {
            name: {"path": config.path, "tsl": config.tsl, "name": name}
            for name, config in self._global_settings.installations().items()
        }
        self._installation_combo_in_update = True
        try:
            self._installation_combo.clear()
            self._installation_combo.addItem("(None)", None)
            for name, config in sorted(self._saved_installations.items()):
                self._installation_combo.addItem(f"{name} ({config['path']})", name)
            if self._installation is not None and hasattr(self._installation, "name"):
                key = getattr(self._installation, "name", None)
                idx = self._installation_combo.findData(key)
                if idx >= 0:
                    self._installation_combo.setCurrentIndex(idx)
            elif current_key is not None:
                idx = self._installation_combo.findData(current_key)
                if idx >= 0:
                    self._installation_combo.setCurrentIndex(idx)
        finally:
            self._installation_combo_in_update = False

    def _open_installations_manage_dialog(self) -> None:
        """Open Manage Installations dialog and reload combobox on save."""
        from toolset.gui.common.localization import translate as tr

        dialog = QDialog(self)
        dialog.setWindowTitle(tr("Manage Installations"))
        layout = QVBoxLayout(dialog)
        widget = InstallationsWidget(dialog)
        layout.addWidget(widget)
        button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel,
            dialog,
        )
        layout.addWidget(button_box)
        button_box.accepted.connect(dialog.accept)
        button_box.rejected.connect(dialog.reject)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            widget.save()
            self._reload_installation_combo()

    def _on_installation_combo_changed(self, _index: int) -> None:
        """Resolve selected installation and call _on_installation_changed."""
        if self._installation_combo_in_update:
            return
        installation = self._get_installation_from_combo()
        self._installation = installation
        self._on_installation_changed(installation)

    def _get_installation_from_combo(self) -> HTInstallation | None:
        """Resolve current combobox selection to HTInstallation."""
        if self._installation_combo is None:
            return None
        selected_name = self._installation_combo.currentData()
        if selected_name is None:
            return None
        cache_key = str(selected_name)
        if cache_key in self._installation_cache:
            return self._installation_cache[cache_key]
        config = self._saved_installations.get(cache_key)
        if config is None:
            return None
        try:
            installation = HTInstallation(
                config["path"],
                config["name"],
                tsl=bool(config.get("tsl")),
            )
            self._installation_cache[cache_key] = installation
            return installation
        except Exception as exc:
            self._logger.exception("Failed to create installation '%s': %s", cache_key, exc)
            QMessageBox.warning(
                self,
                "Invalid Installation",
                f"Could not load installation '{cache_key}'.",
            )
            return None

    def showEvent(self, event: QShowEvent):
        # Copy field tooltips to their labels once so hovering labels shows the same help
        if not getattr(self, "_tooltips_copied_to_labels", False):
            copy_tooltips_to_form_labels(self)
            self._tooltips_copied_to_labels = True  # type: ignore[attr-defined]
        # Set minimum size based on the current size
        self.setMinimumSize(
            self.size().width() + QApplication.font().pointSize() * 2,
            self.size().height(),
        )
        super().showEvent(event)

    def _setupMenus(self):
        """Sets up menu actions and keyboard shortcuts.

        Processing Logic:
        ----------------
            - Loops through menu actions and connects signals for New, Open, Save, Save As, Revert and Exit
            - Sets Revert action to disabled
            - Connects keyboard shortcuts for New, Open, Save, Save As, Revert and Exit.
        """
        menuBar: QMenuBar | None = self.menuBar()
        if menuBar is None:
            raise TypeError(f"self.menuBar().actions()[0].menu() returned a {type(menuBar).__name__} object, expected QMenu.")
        menuActions: list[QAction] = menuBar.actions()
        if len(menuActions) == 0:
            raise ValueError("Menu bar has no actions")
        menu: QMenu | None = cast("Optional[QMenu]", menuActions[0].menu())
        if menu is None:
            raise TypeError(f"self.menuBar().actions()[0].menu() returned a {type(menu).__name__} object, expected QMenu.")

        # Map action text to handler methods
        action_handlers = {
            "New": self.new,
            "Open": self.open,
            "Save": self.save,
            "Save As": self.save_as,
            "Revert": self.revert,
            "Exit": lambda *_: self.close(),
        }
        for action in menu.actions():
            handler = action_handlers.get(action.text())
            if handler is not None:
                action.triggered.connect(handler)
            if action.text() == "Revert":
                action.setEnabled(False)

        # Map shortcuts to handlers
        shortcut_handlers = {
            "Ctrl+N": self.new,
            "Ctrl+O": self.open,
            "Ctrl+S": self.save,
            "Ctrl+Shift+S": self.save_as,
            "Ctrl+R": self.revert,
            "Ctrl+Q": self.exit,
        }
        for shortcut, handler in shortcut_handlers.items():
            QShortcut(shortcut, self).activated.connect(handler)

    def _setup_menus(self):
        """Alias for _setupMenus() to match snake_case naming convention."""
        self._setupMenus()

    def _add_help_action(self, wiki_filename: str | None = None):
        """Add a help action to the menu bar with question mark icon.

        Args:
            wiki_filename: Name of the markdown file in the wiki directory (e.g., "GFF-File-Format.md").
                          If None, will try to auto-detect from editor class name.
        """
        from toolset.gui.editors.editor_wiki_mapping import EDITOR_WIKI_MAP

        # Auto-detect wiki file if not provided
        if wiki_filename is None:
            editor_class_name = self.__class__.__name__
            wiki_filename = EDITOR_WIKI_MAP.get(editor_class_name)
            if wiki_filename is None:
                # No wiki file for this editor, skip adding help
                return

        menubar: QMenuBar | None = self.menuBar()
        help_menu: QMenu | None = None

        # Check if Help menu already exists
        if menubar is not None:
            for action in menubar.actions():
                if action.text() == "Help":
                    help_menu = cast("Optional[QMenu]", action.menu())
                    break

        # Create Help menu if it doesn't exist
        if help_menu is None:
            help_menu = QMenu("Help", self)
            menubar.addMenu(help_menu)

        # Check if Documentation action already exists (idempotent)
        doc_action: QAction | None = None
        for action in help_menu.actions():
            if action.text() == "Documentation":
                doc_action = action
                break

        # Only add if it doesn't exist
        if doc_action is None:
            # Add help action with question mark icon
            style: QStyle | None = self.style()
            if style is not None:
                help_icon = style.standardIcon(QStyle.StandardPixmap.SP_MessageBoxQuestion)
            else:
                help_icon = QIcon()

            help_action = help_menu.addAction(help_icon, "Documentation")
            help_action.setShortcut("F1")
            help_action.triggered.connect(lambda: self._show_help_dialog(wiki_filename))

            QShortcut("F1", self).activated.connect(lambda: self._show_help_dialog(wiki_filename))

    def _show_help_dialog(self, wiki_filename: str):
        """Show the help dialog for this editor.

        Args:
            wiki_filename: Name of the markdown file in the wiki directory
        """
        from toolset.gui.dialogs.editor_help import EditorHelpDialog

        # Create non-blocking dialog
        dialog = EditorHelpDialog(self, wiki_filename)
        dialog.show()  # Non-blocking show

    def _setupIcon(self, iconName: str):
        iconVersion = "x" if self._installation is None else "2" if self._installation.tsl else "1"
        iconPath = f":/images/icons/k{iconVersion}/{iconName}.png"
        self.setWindowIcon(QIcon(QPixmap(iconPath)))

    def refreshWindowTitle(self):
        """Refreshes the window title based on the current state of the editor."""
        installationName = "No Installation" if self._installation is None else self._installation.name
        if self._filepath is None or self._resname is None or self._restype is None:
            self.setWindowTitle(f"{self._editorTitle}({installationName})")
            return

        relpath = self._filepath.relative_to(self._filepath.parent.parent) if self._filepath.parent.parent.name else self._filepath.parent
        if is_bif_file(relpath) or is_capsule_file(self._filepath):
            from toolset.gui.editors.erf import ERFEditor

            if not isinstance(self, ERFEditor):
                relpath /= f"{self._resname}.{self._restype.extension}"
        self.setWindowTitle(f"{relpath} - {self._editorTitle}({installationName})")

    def setupEditorFilters(self, readSupported: list[ResourceType], writeSupported: list[ResourceType]):
        writeSupported = readSupported.copy() if readSupported is writeSupported else writeSupported
        additional_formats = {"XML", "JSON", "CSV", "ASCII", "YAML"}
        for add_format in additional_formats:
            readSupported.extend(
                ResourceType.__members__[f"{restype.name}_{add_format}"] for restype in readSupported if f"{restype.name}_{add_format}" in ResourceType.__members__
            )
            writeSupported.extend(
                ResourceType.__members__[f"{restype.name}_{add_format}"] for restype in writeSupported if f"{restype.name}_{add_format}" in ResourceType.__members__
            )
        self._readSupported: list[ResourceType] = readSupported
        self._writeSupported: list[ResourceType] = writeSupported

        self._saveFilter: str = "All valid files ("
        for resource in writeSupported:
            self._saveFilter += f"*.{resource.extension}{'' if writeSupported[-1] == resource else ' '}"
        self._saveFilter += f" {self.CAPSULE_FILTER});;"
        for resource in writeSupported:
            self._saveFilter += f"{resource.category} File (*.{resource.extension});;"
        self._saveFilter += f"Save into module ({self.CAPSULE_FILTER})"

        self._openFilter: str = "All valid files ("
        for resource in readSupported:
            self._openFilter += f"*.{resource.extension}{'' if readSupported[-1] == resource else ' '}"
        self._openFilter += f" {self.CAPSULE_FILTER});;"
        for resource in readSupported:
            self._openFilter += f"{resource.category} File (*.{resource.extension});;"
        self._openFilter += f"Load from module ({self.CAPSULE_FILTER})"

    def getOpenedFileName(self) -> str:
        if self._filepath is not None and self._filepath.name and self._restype is not None:
            return f"{self._resname or ''}.{self._restype.extension}" if is_bif_file(self._filepath) or is_capsule_file(self._filepath) else self._filepath.name
        return ""

    def save_as(self):
        """Saves the file with the selected filepath.

        Processing Logic:
        ----------------
            - Gets the selected filepath and filter from a file dialog
            - Checks if the filepath is a capsule file and filter is for modules
            - If so, shows a dialog to select resource reference and type
            - Sets filepath, reference and type attributes from selection
            - Calls the save method
            - Refreshes the window title
            - Enables the Revert menu item
        """
        filepath_str, _filter = QFileDialog.getSaveFileName(self, "Save As", self.getOpenedFileName(), self._saveFilter, "")
        if not filepath_str:
            return
        error_msg, e, invalid = "", None, False
        try:
            identifier = ResourceIdentifier.from_path(filepath_str)
            if identifier.restype.is_invalid:
                invalid = True
        except ValueError as e:
            invalid = True
            RobustLogger().exception("ValueError raised, assuming invalid filename/extension '%s'", filepath_str)
            error_msg = str((e.__class__.__name__, str(e))).replace("\n", "<br>")
        if invalid:
            msgBox = QMessageBox(
                QMessageBox.Icon.Critical,
                "Invalid filename/extension",
                f"Check the filename and try again. Could not save!{f'<br><br>{error_msg}' if error_msg else ''}",
                parent=None,
                flags=Qt.WindowType.Window | Qt.WindowType.Dialog | Qt.WindowType.WindowStaysOnTopHint,
            )
            if error_msg:
                msgBox.setDetailedText(format_exception_with_variables(e))
            msgBox.exec()
            return

        if is_capsule_file(filepath_str) and f"Save into module ({self.CAPSULE_FILTER})" in self._saveFilter:
            if self._resname is None or self._restype is None:
                self._resname = "new"
                self._restype = self._writeSupported[0]

            dialog2 = SaveToModuleDialog(self._resname, self._restype, self._writeSupported)
            if dialog2.exec():
                self._resname = dialog2.resname()
                self._restype = dialog2.restype()
                self._filepath = Path(filepath_str)
        else:
            self._filepath = Path(filepath_str)
            self._resname, self._restype = identifier.unpack()
        self.save()

        self.refreshWindowTitle()
        menuBar: QMenuBar | None = self.menuBar()
        if menuBar is None:
            raise TypeError(f"self.menuBar().actions()[0].menu() returned a {type(menuBar).__name__} object, expected QMenu.")
        menuActions: list[QAction] = menuBar.actions()
        if len(menuActions) == 0:
            raise ValueError("Menu bar has no actions")
        menu: QMenu | None = cast("Optional[QMenu]", menuActions[0].menu())
        if menu is None:
            raise TypeError(f"self.menuBar().actions()[0].menu() returned a {type(menu).__name__} object, expected QMenu.")
        for action in menu.actions():
            if action.text() == "Revert":
                action.setEnabled(True)

    def save(self):
        """Saves the current data to file.

        Processing Logic:
        ----------------
            - Builds the data and extension to save
            - Checks the file extension and calls the appropriate save method
            - Catches any exceptions and writes to an error log.
        """
        if self._filepath is None:
            self.save_as()
            return

        try:
            data, data_ext = self.build()
            if data is None:  # HACK: nsseditor
                return
            from toolset.gui.editors.gff import GFFEditor

            # CRITICAL: For save game resources, ALWAYS preserve extra fields
            # Save game GFF files contain undocumented fields that must be preserved
            # to prevent save corruption. This is more important than the user setting.
            should_preserve_fields = self._is_save_game_resource or self._global_settings.attemptKeepOldGFFFields

            if (  # HACK: we need a proper save editor, but this is better than nothing.
                should_preserve_fields and self._restype is not None and self._restype.is_gff() and not isinstance(self, GFFEditor) and self._revert is not None
            ):
                if self._is_save_game_resource:
                    print("Save game resource detected: Preserving all extra GFF fields to prevent save corruption.")
                else:
                    print("Adding deleted fields from original gff into final gff.")
                old_gff = read_gff(self._revert)
                new_gff = read_gff(data)
                new_gff.root.add_missing(old_gff.root)
                data = bytes_gff(new_gff)
            self._revert = data

            self.refreshWindowTitle()

            if is_bif_file(self._filepath):
                self._saveEndsWithBif(data, data_ext)
            elif is_capsule_file(self._filepath.parent):
                self._saveNestedCapsule(data, data_ext)
            elif is_rim_file(self._filepath.name):
                self._saveEndsWithRim(data, data_ext)
            elif is_any_erf_type_file(self._filepath):
                self._saveEndsWithErf(data, data_ext)
            else:
                self._saveEndsWithOther(data, data_ext)
        except Exception as e:  # pylint: disable=W0718  # noqa: BLE001
            self.blinkWindow()
            RobustLogger().critical("Failed to write to file", exc_info=True)
            msgBox = QMessageBox(QMessageBox.Icon.Critical, "Failed to write to file", str((e.__class__.__name__, str(e))).replace("\n", "<br>"))
            msgBox.setDetailedText(format_exception_with_variables(e))
            msgBox.exec_()

    def _saveEndsWithBif(self, data: bytes, data_ext: bytes):
        """Saves data if dialog returns specific options.

        Args:
        ----
            data: bytes - Data to save
            data_ext: bytes - File extension

        Processing Logic:
        ----------------
            - Show save dialog to choose MOD or override save
            - If MOD chosen, show second dialog to set resref/restype
            - Set filepath based on option
            - Call save method.
        """
        dialog = BifSaveDialog(self)
        dialog.exec_()
        if dialog.option == BifSaveOption.MOD:
            str_filepath, filter = QFileDialog.getSaveFileName(self, "Save As", "", ".MOD File (*.mod)", "")
            if not str_filepath.strip():
                print(f"User cancelled filepath lookup in _saveEndsWithBif ({self._resname}.{self._restype})")
                return

            assert self._resname is not None
            assert self._restype is not None
            r_filepath = Path(str_filepath)
            dialog2 = SaveToModuleDialog(self._resname, self._restype, self._writeSupported)
            if dialog2.exec_():
                self._resname = dialog2.resname()
                self._restype = dialog2.restype()
                self._filepath = r_filepath
                self.save()
        elif dialog.option == BifSaveOption.Override:
            assert self._resname is not None
            assert self._restype is not None
            assert self._installation is not None
            self._filepath = self._installation.override_path() / f"{self._resname}.{self._restype.extension}"
            self.save()
        else:
            print(f"User closed out of BifSaveDialog in _saveEndsWithBif (({self._resname}.{self._restype}))")

    def _saveEndsWithRim(self, data: bytes, data_ext: bytes):
        """Saves resource data to a RIM file.

        Args:
        ----
            data: {Bytes containing resource data}
            data_ext: {Bytes containing additional resource data like MDX for MDL}.

        Processing Logic:
        ----------------
        Saves resource data to RIM file:
            - Checks for RIM saving disabled setting and shows dialog
            - Writes data to RIM file
            - Updates installation cache.
        """
        assert self._filepath is not None, assert_with_variable_trace(self._filepath is not None)
        assert self._resname is not None, assert_with_variable_trace(self._resname is not None)
        assert self._restype is not None, assert_with_variable_trace(self._restype is not None)

        if self._global_settings.disableRIMSaving:
            dialog = RimSaveDialog(self)
            dialog.exec_()
            if dialog.option == RimSaveOption.MOD:
                folderpath: Path = self._filepath.parent
                filename: str = f"{Module.find_root(self._filepath)}.mod"
                self._filepath = folderpath / filename
                # Re-save with the updated filepath
                self.save()
            elif dialog.option == RimSaveOption.Override:
                assert self._installation is not None
                self._filepath = self._installation.override_path() / f"{self._resname}.{self._restype.extension}"
                self.save()
            return

        rim: RIM = read_rim(self._filepath)

        # MDL is a special case - we need to save the MDX file with the MDL file.
        if self._restype == ResourceType.MDL:
            rim.set_data(self._resname, ResourceType.MDX, data_ext)

        rim.set_data(self._resname, self._restype, data)

        write_rim(rim, self._filepath)
        self.savedFile.emit(str(self._filepath), self._resname, self._restype, data)

        # Update installation cache
        if self._installation is not None:
            self._installation.reload_module(self._filepath.name)

    def _saveNestedCapsule(self, data: bytes, data_ext: bytes):
        assert self._filepath is not None, assert_with_variable_trace(self._filepath is not None)
        assert self._resname is not None, assert_with_variable_trace(self._resname is not None)
        assert self._restype is not None, assert_with_variable_trace(self._restype is not None)

        # Determine the physical file and the nested paths.
        c_filepath: CaseAwarePath = CaseAwarePath(self._filepath)
        nested_paths: list[PurePath] = []
        if is_any_erf_type_file(c_filepath) or is_rim_file(c_filepath):
            nested_paths.append(c_filepath)

        c_parent_filepath = c_filepath.parent
        while (  # Iterate all parents until we find a physical folder on disk.
            ResourceType.from_extension(c_parent_filepath.suffix).name in (ResourceType.ERF, ResourceType.MOD, ResourceType.SAV, ResourceType.RIM)
        ) and not c_parent_filepath.is_dir():
            nested_paths.append(c_parent_filepath)
            c_filepath = c_parent_filepath
            c_parent_filepath = c_filepath.parent

        # At this point, c_filepath points to the physical ERF/RIM on disk
        # and c_parent_filepath points to the physical folder containing the file.
        erf_or_rim: ERF | RIM = read_rim(c_filepath) if ResourceType.from_extension(c_parent_filepath.suffix) == ResourceType.RIM else read_erf(c_filepath)
        nested_capsules: list[tuple[PurePath, ERF | RIM]] = [(c_filepath, erf_or_rim)]
        for capsule_path in reversed(nested_paths[:-1]):
            nested_erf_or_rim_data = erf_or_rim.get(capsule_path.stem, ResourceType.from_extension(capsule_path.suffix))
            if nested_erf_or_rim_data is None:
                # Save all open editors to ensure nested resources are available
                for window in TOOLSET_WINDOWS:
                    if hasattr(window, 'save') and hasattr(window, '_filepath') and window._filepath is not None:
                        try:
                            window.save()
                        except Exception as e:
                            self._logger.warning(f"Failed to save editor {window.__class__.__name__}: {e}")
                # Re-read the capsule after saving
                erf_or_rim = read_rim(c_filepath) if ResourceType.from_extension(c_parent_filepath.suffix) == ResourceType.RIM else read_erf(c_filepath)
                nested_erf_or_rim_data = erf_or_rim.get(capsule_path.stem, ResourceType.from_extension(capsule_path.suffix))
                if nested_erf_or_rim_data is None:
                    msg = f"You must save the ERFEditor for '{capsule_path.relative_to(c_parent_filepath)}' before modifying its nested resources. Do so and try again."
                    raise ValueError(msg)

            erf_or_rim = read_rim(nested_erf_or_rim_data) if ResourceType.from_extension(capsule_path.suffix) == ResourceType.RIM else read_erf(nested_erf_or_rim_data)
            nested_capsules.append((capsule_path, erf_or_rim))

        # Let's now save each erf/rim to its parent.
        for index, (capsule_path, this_erf_or_rim) in enumerate(reversed(nested_capsules)):
            rel_capsule_path = capsule_path.relative_to(c_parent_filepath)
            if index == 0:
                if not self._is_capsule_editor:
                    print(f"Saving non ERF/RIM '{self._resname}.{self._restype.extension}' to '{rel_capsule_path}'")
                    this_erf_or_rim.set_data(self._resname, self._restype, data)
                continue
            child_index = len(nested_capsules) - index
            child_capsule_path, child_erf_or_rim = nested_capsules[child_index]
            if self._filepath != child_capsule_path or not self._is_capsule_editor:
                data = bytearray()
                print(f"Saving {child_capsule_path.relative_to(c_parent_filepath)} to {capsule_path.relative_to(c_parent_filepath)}")
                write_erf(child_erf_or_rim, data) if isinstance(child_erf_or_rim, ERF) else write_rim(child_erf_or_rim, data)
            this_erf_or_rim.set_data(child_capsule_path.stem, ResourceType.from_extension(child_capsule_path.suffix), bytes(data))

        print(f"All nested capsules saved, finally saving physical file '{c_filepath}'")
        write_erf(this_erf_or_rim, c_filepath) if isinstance(this_erf_or_rim, ERF) else write_rim(this_erf_or_rim, c_filepath)
        self.savedFile.emit(str(c_filepath), self._resname, self._restype, data)

    def _saveEndsWithErf(self, data: bytes, data_ext: bytes):
        # Create the mod file if it does not exist.
        """Saves data to an ERF/MOD file with the given extension.

        Args:
        ----
            data: {Bytes of data to save}
            data_ext: {Bytes of associated file extension if saving MDL}.

        Processing Logic:
        ----------------
            - Create the mod file if it does not exist
            - Read the existing ERF file
            - Set the ERF type based on file extension
            - For MDL, also save the MDX file data
            - Save the provided data and file reference
            - Write updated ERF back to file
            - Emit a signal that a file was saved
            - Reload the module in the installation cache.
        """
        assert self._filepath is not None, assert_with_variable_trace(self._filepath is not None)
        assert self._resname is not None, assert_with_variable_trace(self._resname is not None)
        assert self._restype is not None, assert_with_variable_trace(self._restype is not None)

        erftype: ERFType = ERFType.from_extension(self._filepath)
        c_filepath: CaseAwarePath = CaseAwarePath(self._filepath)

        if c_filepath.is_file():
            erf: ERF = read_erf(c_filepath)
        elif c_filepath.with_suffix(".rim").is_file():
            module.rim_to_mod(c_filepath)
            erf = read_erf(c_filepath)
        else:  # originally in a bif, user chose to save into erf/mod.
            print(f"Saving '{self._resname}.{self._restype}' to a blank new {erftype.name} file at '{c_filepath}'")
            erf = ERF(erftype)  # create a new ERF I guess.
        erf.erf_type = erftype

        # MDL is a special case - we need to save the MDX file with the MDL file.
        if self._restype == ResourceType.MDL:
            assert data_ext is not None, assert_with_variable_trace(data_ext is not None)
            erf.set_data(self._resname, ResourceType.MDX, data_ext)

        erf.set_data(self._resname, self._restype, data)

        write_erf(erf, c_filepath)
        self.savedFile.emit(str(c_filepath), self._resname, self._restype, data)

        # Update installation cache
        if self._installation is not None and c_filepath.parent == self._installation.module_path():
            self._installation.reload_module(c_filepath.name)

    def _saveEndsWithOther(self, data: bytes, data_ext: bytes):
        assert self._filepath is not None, assert_with_variable_trace(self._filepath is not None)
        c_filepath: CaseAwarePath = CaseAwarePath(self._filepath)
        with c_filepath.open("wb") as file:
            file.write(data)

        # MDL is a special case - we need to save the MDX file with the MDL file.
        if self._restype == ResourceType.MDL:
            with c_filepath.with_suffix(".mdx").open("wb") as file:
                file.write(data_ext)
        self.savedFile.emit(self._filepath, self._resname, self._restype, data)

    def open(self):
        """Opens a file dialog to select a file to open.

        Processing Logic:
        ----------------
            - Use QFileDialog to open a file dialog and get the selected filepath
            - Check if the selected file is a capsule file
            - If it is, show a LoadFromModuleDialog to get additional module data
            - Otherwise, directly load the file by path, reference, type and content
        """
        filepath_str, filter = QFileDialog.getOpenFileName(self, "Open file", "", self._openFilter)
        if not filepath_str.strip():
            return
        r_filepath = Path(filepath_str)

        if is_capsule_file(r_filepath) and f"Load from module ({self.CAPSULE_FILTER})" in self._openFilter:
            dialog = LoadFromModuleDialog(Capsule(r_filepath), self._readSupported)  # type: ignore[arg-type]
            if dialog.exec_():
                self._load_module_from_dialog_info(dialog, r_filepath)
        else:
            data: bytes = BinaryReader.load_file(r_filepath)
            res_ident: ResourceIdentifier = ResourceIdentifier.from_path(r_filepath).validate()
            self.load(r_filepath, res_ident.resname, res_ident.restype, data)

    def _load_module_from_dialog_info(self, dialog: LoadFromModuleDialog, c_filepath: Path):
        resname: str | None = dialog.resname()
        restype: ResourceType | None = dialog.restype()
        data: bytes | None = dialog.data()
        assert resname is not None, assert_with_variable_trace(resname is not None)
        assert restype is not None, assert_with_variable_trace(restype is not None)
        assert data is not None, assert_with_variable_trace(data is not None)

        self.load(c_filepath, resname, restype, data)

    @abstractmethod
    def build(self) -> tuple[bytes, bytes]: ...

    def centerAndAdjustWindow(self):
        # Get the screen geometry
        screen = QApplication.primaryScreen().geometry()

        # Calculate the new position to center the window
        new_x = (screen.width() - self.width()) // 2
        new_y = (screen.height() - self.height()) // 2

        # Adjust the position to ensure the window is fully visible
        new_x = max(0, min(new_x, screen.width() - self.width()))
        new_y = max(0, min(new_y, screen.height() - self.height()))

        # Set the new position
        self.move(new_x, new_y)

    # @property
    # def filepath(self):
    #    return self._resource.filepath()

    def load(
        self,
        filepath: os.PathLike | str,
        resref: str,
        restype: ResourceType,
        data: bytes,
    ):
        """Load a resource from a file.

        Args:
        ----
            filepath: Filepath to load resource from
            resref (str): Resource reference
            restype: ResourceType
            data (bytes): Resource data.

        Processing Logic:
        ----------------
            - Convert filepath to Path object if string
            - Set internal properties like filepath, resref, restype, data
            - Detect if resource is from a save game (for field preservation)
            - Enable "Revert" menu item
            - Refresh window title
            - Emit loadedFile signal with load details.
        """
        self._filepath = Path(filepath)  # pyright: ignore[reportGeneralTypeIssues]
        self._resname = resref
        self._restype = restype
        self._revert = data

        # Detect if this resource is from a save game
        # Check if any parent in the filepath is a .sav file
        self._is_save_game_resource = self._detect_save_game_resource(self._filepath)

        menu_bar: QMenuBar | None = cast("Optional[QMenuBar]", self.menuBar())
        assert menu_bar is not None, "Menu bar is None somehow? This should be impossible."
        menu_bar_actions: Sequence[QAction] = menu_bar.actions()  # pyright: ignore[reportAssignmentType]
        if len(menu_bar_actions) > 0:
            menu: QMenu | None = menu_bar_actions[0].menu()
            assert menu is not None, "Menu is somehow None"
            for action in menu_bar_actions:
                if action.text() == "Revert":
                    action.setEnabled(True)
                    break
        self.refreshWindowTitle()
        self.loadedFile.emit(str(self._filepath), self._resname, self._restype, data)

    def _detect_save_game_resource(self, filepath: Path) -> bool:
        """Detect if a resource is from a save game by checking the filepath.

        Save game resources are nested inside SAVEGAME.sav or cached module .sav files.
        This method checks if any parent in the path is a .sav file.

        Args:
        ----
            filepath: Path to check

        Returns:
        -------
            bool: True if resource is from a save game, False otherwise
        """
        current_path = filepath
        while current_path != current_path.parent:
            # Check if current path component is a .sav file
            if is_sav_file(current_path):
                return True
            # Check if parent is a .sav file (for nested resources)
            if is_sav_file(current_path.parent):
                return True
            current_path = current_path.parent
            # Stop if we've reached the root
            if not current_path.parts:
                break
        return False

    def exit(self):
        self.close()

    def new(self):
        self._revert = None
        self._filepath = None
        self._is_save_game_resource = False
        for action in self.menuBar().actions()[0].menu().actions():
            if action.text() != "Revert":
                continue
            action.setEnabled(False)
        self.refreshWindowTitle()
        self.newFile.emit()

    def revert(self):
        if self._revert is None:
            print("No data to revert from")
            self.blinkWindow()
            return
        assert self._filepath is not None, assert_with_variable_trace(self._filepath is not None)
        assert self._resname is not None, assert_with_variable_trace(self._resname is not None)
        assert self._restype is not None, assert_with_variable_trace(self._restype is not None)
        self.load(self._filepath, self._resname, self._restype, self._revert)

    def _loadLocstring(self, textbox: QLineEdit | QPlainTextEdit, locstring: LocalizedString):
        """Loads a LocalizedString into a textbox.

        Args:
        ----
            textbox: QLineEdit or QPlainTextEdit - Textbox to load string into
            locstring: LocalizedString - String to load


        Processing Logic:
        ----------------
            - Determines if textbox is QLineEdit or QPlainTextEdit
            - Sets textbox's locstring property
            - Checks if locstring has stringref or not
            - Sets textbox text and style accordingly.
        """
        setText: Callable[[str], None] = textbox.setPlainText if isinstance(textbox, QPlainTextEdit) else textbox.setText

        from toolset.gui.common.style.palette_utils import apply_locstring_background

        textbox.locstring = locstring  # pyright: ignore[reportAttributeAccessIssue]
        if locstring.stringref == -1:
            text = str(locstring)
            setText(text if text != "-1" else "")
            apply_locstring_background(textbox, from_tlk=False)
        elif self._installation is not None:
            setText(self._installation.talktable().string(locstring.stringref))
            apply_locstring_background(textbox, from_tlk=True)

    def blinkWindow(self, *, sound: bool = True):
        if sound:
            with suppress(Exception):
                self.playSound("dr_metal_lock")
        self.setWindowOpacity(0.7)
        QTimer.singleShot(125, lambda: self.setWindowOpacity(1))

    def play_byte_source_media(self, data: bytes | None) -> bool:
        if qtpy.QT5:
            from qtpy.QtMultimedia import QMediaContent

            if data:
                self.mediaPlayer.buffer = buffer = QBuffer(self)
                buffer.setData(data)
                buffer.open(QIODevice.OpenModeFlag.ReadOnly)
                self.mediaPlayer.player.setMedia(QMediaContent(), buffer)
                QTimer.singleShot(0, self.mediaPlayer.player.play)  # IMPORTANT!! in pyqt5/pyside2, ONLY works when singleShot from a timer. No idea why.
            else:
                self.blinkWindow()
                return False
            return True

        if qtpy.QT6:
            if data:
                self._play_byte_data_qt6(data)
            else:
                self.blinkWindow()
                return False
            return True
        raise RuntimeError(f"Unsupported QT_API value: {qtpy.API_NAME}")

    def _play_byte_data_qt6(self, data: bytes):
        from qtpy.QtMultimedia import QAudioOutput

        tempFile = tempfile.NamedTemporaryFile(delete=False, suffix=".wav")
        tempFile.write(data)
        tempFile.flush()
        tempFile.seek(0)
        tempFile.close()

        player: PyQt6MediaPlayer | PySide6MediaPlayer = cast("Any", self.mediaPlayer.player)
        audioOutput = QAudioOutput(self)  # pyright: ignore[reportCallIssue]
        player.setAudioOutput(audioOutput)  # type: ignore[attr-name]
        player.setSource(QUrl.fromLocalFile(tempFile.name))  # type: ignore[attr-name]
        audioOutput.setVolume(1)  # IMPORTANT!! volume starts off at 0% otherwise.
        player.mediaStatusChanged.connect(lambda status, file_name=tempFile.name: self.removeTempAudioFile(status, file_name))
        player.play()

    def playSound(self, resname: str, order: list[SearchLocation] | None = None) -> bool:
        """Plays a sound resource."""
        if not resname or not resname.strip() or self._installation is None:
            self.blinkWindow(sound=False)
            return False

        self.mediaPlayer.player.stop()

        data: bytes | None = self._installation.sound(
            resname,
            order
            if order is not None
            else [
                SearchLocation.MUSIC,
                SearchLocation.VOICE,
                SearchLocation.SOUND,
                SearchLocation.OVERRIDE,
                SearchLocation.CHITIN,
            ],
        )
        if not data:
            self.blinkWindow(sound=False)
        return self.play_byte_source_media(data)

    def removeTempAudioFile(
        self,
        status: QMediaPlayer.MediaStatus,
        filePathStr: str,
    ):
        print("<SDM> [removeTempAudioFile scope] status: ", status)
        if status == QMediaPlayer.MediaStatus.EndOfMedia:
            try:
                self.mediaPlayer.player.stop()
                QTimer.singleShot(33, lambda: remove_any(filePathStr))
            except OSError:
                self._logger.exception(f"Error removing temporary file {filePathStr}")

    def filepath(self) -> str | None:
        return str(self._filepath)
