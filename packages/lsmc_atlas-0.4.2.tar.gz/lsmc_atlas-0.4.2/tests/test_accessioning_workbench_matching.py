"""Matching and search tests for the Atlas accessioning workbench."""

from __future__ import annotations

import uuid
from datetime import date

import pytest
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.auth.dependencies import (
    CurrentUser,
    get_current_user,
    get_current_user_web,
    require_internal,
    require_read_write_web,
)
from app.auth.middleware import csrf_protect
from app.db.engine import get_db
from app.domain.services.accessioning_workbench import (
    AccessioningWorkbenchService,
    ContentRegistrationRequest,
    ReceiptRegistrationRequest,
)
from app.domain.services.orgs import SiteService
from app.domain.services.people import PatientCreate, PatientService
from app.domain.services.trfs import (
    TestCreate as AtlasTestCreate,
)
from app.domain.services.trfs import (
    TestService as AtlasTestService,
)
from app.domain.services.trfs import (
    TrfCreate,
    TrfService,
)
from app.main import app
from tests.tapdb_test_helpers import ensure_tapdb_org

pytestmark = pytest.mark.db


@pytest.fixture
def tenant_id() -> uuid.UUID:
    return uuid.uuid4()


@pytest.fixture
def user(tenant_id: uuid.UUID) -> CurrentUser:
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="matching@test.org",
        name="Matching User",
        tenant_id=tenant_id,
        roles=["INTERNAL_USER"],
    )


@pytest.fixture
def tenant_org(db_session: Session, tenant_id: uuid.UUID):
    return ensure_tapdb_org(
        db_session,
        tenant_id,
        name="matching-org",
        display_name="Matching Org",
        site_name="Matching Site",
        site_code="MATCH",
    )


@pytest.fixture
def site(tenant_org, db_session: Session):
    return SiteService(db_session).list_by_organization(tenant_org.euid)[0]


@pytest.fixture
def fake_bloom(monkeypatch):
    from app.domain.services import bloom_bridge
    from app.integrations.bloom_client import BloomOperationResult

    class FakeBloomClient:
        def create_empty_tube(self, payload, *, idempotency_key=None):
            return BloomOperationResult(
                external_euid="CNT-MATCH-0001",
                status="active",
                raw={
                    "container_euid": "CNT-MATCH-0001",
                    "status": "active",
                    "payload": payload,
                    "idempotency_key": idempotency_key,
                },
            )

        def register_accepted_material(self, payload, *, idempotency_key=None):  # pragma: no cover
            return BloomOperationResult(
                external_euid="SP-MATCH-0001",
                status="active",
                raw={
                    "specimen_euid": "SP-MATCH-0001",
                    "container_euid": payload.get("container_euid"),
                    "status": "active",
                },
            )

        def move_material_to_queue(  # pragma: no cover
            self,
            container_euid,
            queue_name,
            *,
            metadata=None,
            idempotency_key=None,
        ):
            return {
                "container_euid": container_euid,
                "current_queue": queue_name,
                "metadata": metadata or {},
                "idempotency_key": idempotency_key,
                "idempotent_replay": False,
            }

    fake = FakeBloomClient()

    def _fake_get_client(self, site_id=None):  # noqa: ARG001
        return fake

    monkeypatch.setattr(
        bloom_bridge.ContainerSpecimenBridgeService,
        "_get_bloom_client",
        _fake_get_client,
    )
    return fake


@pytest.fixture
def client(db_session: Session, user: CurrentUser):
    def override_get_db():
        yield db_session

    def override_user():
        return user

    async def override_csrf():
        return None

    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[get_current_user] = override_user
    app.dependency_overrides[get_current_user_web] = override_user
    app.dependency_overrides[require_internal] = override_user
    app.dependency_overrides[require_read_write_web] = override_user
    app.dependency_overrides[csrf_protect] = override_csrf

    with TestClient(app) as test_client:
        yield test_client

    app.dependency_overrides.clear()


def _service(db_session: Session, tenant_id: uuid.UUID) -> AccessioningWorkbenchService:
    return AccessioningWorkbenchService(db_session, tenant_id)


def _create_patient(db_session: Session, tenant_id: uuid.UUID, site_euid: str, actor_id: uuid.UUID):
    patient, _revision = PatientService(db_session, tenant_id).create(
        PatientCreate(
            first_name="Match",
            last_name="Patient",
            date_of_birth=date(1992, 2, 2),
            mrn="MRN-MATCH-1",
            site_id=site_euid,
        ),
        created_by=actor_id,
    )
    return patient


def _create_trf_and_test(
    db_session: Session,
    tenant_id: uuid.UUID,
    site_euid: str,
    actor_id: uuid.UUID,
    *,
    patient_euid: str,
):
    from app.domain.enums import OrderPatientRole
    from app.domain.services.order_relationships import OrderPatientLink

    trf, _revision = TrfService(db_session, tenant_id).create(
        TrfCreate(site_id=site_euid),
        tests=[
            AtlasTestCreate(
                product_code="EXOME",
                fulfillment_route_codes=["EXOME"],
                specimen_type_required="blood-whole",
                site_id=site_euid,
            )
        ],
        patient_links=[OrderPatientLink(patient_euid=patient_euid, role=OrderPatientRole.PROBAND)],
        created_by=actor_id,
    )
    test = AtlasTestService(db_session, tenant_id).list_for_trf(trf.euid)[0][0]
    return trf, test


def test_search_matches_returns_expected_entities(
    db_session: Session,
    tenant_id: uuid.UUID,
    tenant_org,
    site,
    user: CurrentUser,
    fake_bloom,
):
    actor_id = user.sub_uuid or uuid.uuid4()
    svc = _service(db_session, tenant_id)
    patient = _create_patient(db_session, tenant_id, site.euid, actor_id)
    trf, test = _create_trf_and_test(
        db_session,
        tenant_id,
        site.euid,
        actor_id,
        patient_euid=patient.euid,
    )
    item, _revision = svc.register_receipt(
        ReceiptRegistrationRequest(
            tracking_number="TRACK-MATCH-001",
            carrier="UPS",
            origin_site_id=site.euid,
            received_by="matcher",
        ),
        actor_id=actor_id,
    )
    svc.register_content(
        item.euid,
        ContentRegistrationRequest(content_type="Kit", barcode="KIT-MATCH-001"),
        actor_id=actor_id,
    )
    svc.register_content(
        item.euid,
        ContentRegistrationRequest(
            content_type="Tube",
            site_euid=site.euid,
            collection_site_euid=site.euid,
        ),
        actor_id=actor_id,
    )

    shipment_results = svc.search_matches("TRACK-MATCH-001")
    testkit_results = svc.search_matches("KIT-MATCH-001")
    patient_results = svc.search_matches("MRN-MATCH-1")
    dob_results = svc.search_matches("1992-02-02")
    trf_results = svc.search_matches(trf.euid)
    test_results = svc.search_matches(test.euid)

    assert shipment_results["shipments"][0]["number"]
    assert testkit_results["testkits"][0]["barcode"] == "KIT-MATCH-001"
    assert patient_results["patients"][0]["euid"] == patient.euid
    assert dob_results["patients"][0]["euid"] == patient.euid
    assert dob_results["patients"][0]["date_of_birth"] == "1992-02-02"
    assert trf_results["trfs"][0]["euid"] == trf.euid
    assert test_results["tests"][0]["euid"] == test.euid


def test_search_partial_renders_match_results(
    client: TestClient,
    db_session: Session,
    user: CurrentUser,
    tenant_org,
    site,
):
    actor_id = user.sub_uuid or uuid.uuid4()
    svc = _service(db_session, user.tenant_id)
    patient = _create_patient(db_session, user.tenant_id, site.euid, actor_id)
    trf, test = _create_trf_and_test(
        db_session,
        user.tenant_id,
        site.euid,
        actor_id,
        patient_euid=patient.euid,
    )
    item, _revision = svc.register_receipt(
        ReceiptRegistrationRequest(
            tracking_number="TRACK-PARTIAL-001",
            carrier="UPS",
            origin_site_id=site.euid,
            received_by="matcher",
        ),
        actor_id=actor_id,
    )

    response = client.get(
        f"/accessioning/work-items/{item.euid}/search",
        params={"q": "1992-02-02"},
    )

    assert response.status_code == 200
    assert "Match Results" in response.text
    assert "1992-02-02" in response.text
    assert patient.euid in response.text
