"""Service tests for the Atlas accessioning workbench."""

from __future__ import annotations

import uuid
from datetime import date

import pytest
from sqlalchemy.orm import Session

from app.domain.services.accessioning_workbench import (
    AccessioningWorkbenchService,
    CaptureReadyForReviewRequest,
    ContentRegistrationRequest,
    LinkRequest,
    MinimalChildRegistrationRequest,
    OutcomeRequest,
    ProvisionalOrderRequest,
    ProvisionalPatientInput,
    ReceiptRegistrationRequest,
)
from app.domain.services.audit import AuditService
from app.domain.services.intake import IntakeService
from app.domain.services.order_relationships import OrderRelationshipService
from app.domain.services.orgs import SiteService
from app.domain.services.people import PatientCreate, PatientService
from app.domain.services.shipments import (
    TestKitCreate as AtlasTestKitCreate,
)
from app.domain.services.shipments import (
    TestKitService as AtlasTestKitService,
)
from app.domain.services.trfs import (
    TestCreate as AtlasTestCreate,
)
from app.domain.services.trfs import (
    TestService as AtlasTestService,
)
from app.domain.services.trfs import (
    TrfCreate,
    TrfService,
)
from tests.tapdb_test_helpers import ensure_tapdb_org

pytestmark = pytest.mark.db


@pytest.fixture
def tenant_id() -> uuid.UUID:
    return uuid.uuid4()


@pytest.fixture
def actor_id() -> uuid.UUID:
    return uuid.uuid4()


@pytest.fixture
def tenant_org(db_session: Session, tenant_id: uuid.UUID):
    return ensure_tapdb_org(
        db_session,
        tenant_id,
        name="accessioning-org",
        display_name="Accessioning Org",
        site_name="Main Site",
        site_code="MAIN",
    )


@pytest.fixture
def site(tenant_org, db_session: Session):
    return SiteService(db_session).list_by_organization(tenant_org.euid)[0]


@pytest.fixture
def fake_bloom(monkeypatch):
    from app.domain.services import bloom_bridge
    from app.integrations.bloom_client import BloomOperationResult

    class FakeBloomClient:
        def __init__(self):
            self.created_tubes: list[dict[str, object]] = []
            self.accepted_material: list[dict[str, object]] = []

        def create_empty_tube(self, payload, *, idempotency_key=None):
            number = len(self.created_tubes) + 1
            container_euid = f"CNT-{number:04d}"
            self.created_tubes.append({"payload": payload, "idempotency_key": idempotency_key})
            return BloomOperationResult(
                external_euid=container_euid,
                status="active",
                raw={
                    "container_euid": container_euid,
                    "status": "active",
                    "payload": payload,
                    "idempotency_key": idempotency_key,
                },
            )

        def register_accepted_material(self, payload, *, idempotency_key=None):
            number = len(self.accepted_material) + 1
            specimen_euid = f"SP-{number:04d}"
            self.accepted_material.append({"payload": payload, "idempotency_key": idempotency_key})
            return BloomOperationResult(
                external_euid=specimen_euid,
                status="active",
                raw={
                    "specimen_euid": specimen_euid,
                    "container_euid": payload.get("container_euid"),
                    "status": "active",
                    "payload": payload,
                    "idempotency_key": idempotency_key,
                },
            )

        def move_material_to_queue(
            self,
            container_euid,
            queue_name,
            *,
            metadata=None,
            idempotency_key=None,
        ):
            return {
                "container_euid": container_euid,
                "current_queue": queue_name,
                "metadata": metadata or {},
                "idempotency_key": idempotency_key,
                "idempotent_replay": False,
            }

    fake = FakeBloomClient()

    def _fake_get_client(self, site_id=None):  # noqa: ARG001
        return fake

    monkeypatch.setattr(
        bloom_bridge.ContainerSpecimenBridgeService,
        "_get_bloom_client",
        _fake_get_client,
    )
    return fake


def _service(db_session: Session, tenant_id: uuid.UUID) -> AccessioningWorkbenchService:
    return AccessioningWorkbenchService(db_session, tenant_id)


def _create_patient(db_session: Session, tenant_id: uuid.UUID, site_euid: str, actor_id: uuid.UUID):
    patient, _revision = PatientService(db_session, tenant_id).create(
        PatientCreate(
            first_name="Pat",
            last_name="Ient",
            date_of_birth=date(1990, 1, 1),
            mrn=f"MRN-{str(actor_id)[:8]}",
            site_id=site_euid,
        ),
        created_by=actor_id,
    )
    return patient


def _create_trf_and_test(
    db_session: Session,
    tenant_id: uuid.UUID,
    site_euid: str,
    actor_id: uuid.UUID,
    *,
    patient_euid: str,
):
    from app.domain.enums import OrderPatientRole
    from app.domain.services.order_relationships import OrderPatientLink

    trf, _trf_revision = TrfService(db_session, tenant_id).create(
        TrfCreate(
            site_id=site_euid,
            clinical_notes="Order created in test",
        ),
        tests=[
            AtlasTestCreate(
                product_code="WGS",
                fulfillment_route_codes=["WGS"],
                specimen_type_required="blood-whole",
                site_id=site_euid,
            )
        ],
        patient_links=[OrderPatientLink(patient_euid=patient_euid, role=OrderPatientRole.PROBAND)],
        created_by=actor_id,
    )
    test = AtlasTestService(db_session, tenant_id).list_for_trf(trf.euid)[0][0]
    return trf, test


def _register_work_item(
    svc: AccessioningWorkbenchService,
    *,
    actor_id: uuid.UUID,
    site_euid: str,
    tracking_number: str = "TRACK-001",
    hand_delivery: bool = False,
):
    return svc.register_receipt(
        ReceiptRegistrationRequest(
            tracking_number=None if hand_delivery else tracking_number,
            carrier="UPS",
            received_by="operator-1",
            origin_site_id=site_euid,
            notes="intake test",
            package_condition="OK",
            hand_delivery=hand_delivery,
        ),
        actor_id=actor_id,
    )


def _find_node_by_kind(node: dict, kind: str) -> dict | None:
    if node.get("kind") == kind:
        return node
    for child in node.get("children", []):
        found = _find_node_by_kind(child, kind)
        if found is not None:
            return found
    return None


def _deepest_child(node: dict) -> dict:
    current = node
    while current.get("children"):
        current = current["children"][-1]
    return current


def test_register_receipt_is_idempotent_and_normalizes_hand_delivery(
    db_session: Session,
    tenant_id: uuid.UUID,
    tenant_org,
    site,
    actor_id: uuid.UUID,
):
    svc = _service(db_session, tenant_id)

    item, revision = _register_work_item(
        svc,
        actor_id=actor_id,
        site_euid=site.euid,
        hand_delivery=True,
    )
    repeat_item, repeat_revision = _register_work_item(
        svc,
        actor_id=actor_id,
        site_euid=site.euid,
        hand_delivery=True,
    )

    assert item.euid == repeat_item.euid
    assert revision.euid == repeat_revision.euid
    assert revision.queue == "PACKAGE_PROCESSING_PENDING"
    assert revision.receipt_metadata["carrier"] == "HAND_DELIVERY"


def test_register_tube_content_is_idempotent_for_same_registration_token_and_persists_placeholders(
    db_session: Session,
    tenant_id: uuid.UUID,
    tenant_org,
    site,
    actor_id: uuid.UUID,
    fake_bloom,
):
    svc = _service(db_session, tenant_id)
    item, _revision = _register_work_item(
        svc,
        actor_id=actor_id,
        site_euid=site.euid,
        tracking_number="TRACK-TUBE-IDEMPOTENT",
    )

    first_revision = svc.register_content(
        item.euid,
        ContentRegistrationRequest(
            content_type="Tube",
            site_euid=site.euid,
            collection_site_euid=site.euid,
            notes="Bench scan",
            label_print_requested=True,
            label_print_context="bench-printer-1",
            tube_image_metadata="tube-front.jpg",
            package_image_metadata="box-top.jpg",
            registration_token="tube-token-001",
        ),
        actor_id=actor_id,
    )
    replay_revision = svc.register_content(
        item.euid,
        ContentRegistrationRequest(
            content_type="Tube",
            site_euid=site.euid,
            collection_site_euid=site.euid,
            notes="Bench scan",
            label_print_requested=True,
            label_print_context="bench-printer-1",
            tube_image_metadata="tube-front.jpg",
            package_image_metadata="box-top.jpg",
            registration_token="tube-token-001",
        ),
        actor_id=actor_id,
    )

    detail = svc.get_work_item(item.euid)
    manifest_row = detail["manifest_items"][0]

    assert first_revision.euid == replay_revision.euid
    assert len(detail["manifest_items"]) == 1
    assert manifest_row["label_print_requested"] is True
    assert manifest_row["label_print_context"] == "bench-printer-1"
    assert manifest_row["tube_image_metadata"] == "tube-front.jpg"
    assert manifest_row["package_image_metadata"] == "box-top.jpg"
    assert len(fake_bloom.created_tubes) == 1


def test_register_nested_contents_and_create_provisional_trio_order(
    db_session: Session,
    tenant_id: uuid.UUID,
    tenant_org,
    site,
    actor_id: uuid.UUID,
):
    svc = _service(db_session, tenant_id)
    item, _revision = _register_work_item(
        svc,
        actor_id=actor_id,
        site_euid=site.euid,
        tracking_number="TRACK-NESTED",
    )

    revision = svc.register_content(
        item.euid,
        ContentRegistrationRequest(content_type="Kit", barcode="KIT-ROOT", kit_type="COLLECTION"),
        actor_id=actor_id,
    )
    root_kit_id = revision.package_manifest["items"][-1]["entity_id"]

    svc.register_content(
        item.euid,
        ContentRegistrationRequest(
            content_type="Kit",
            parent_type="TestKit",
            parent_id=root_kit_id,
            barcode="KIT-CHILD",
            kit_type="SUBKIT",
        ),
        actor_id=actor_id,
    )
    svc.register_content(
        item.euid,
        ContentRegistrationRequest(
            content_type="ChildShipment",
            parent_type="Shipment",
            tracking_number="TRACK-CHILD",
            carrier="FEDEX",
        ),
        actor_id=actor_id,
    )

    linked_revision = svc.create_provisional_order(
        item.euid,
        ProvisionalOrderRequest(
            site_id=site.euid,
            fulfillment_route_code="WGS",
            specimen_type_required="blood-whole",
            patients=[
                ProvisionalPatientInput(
                    role="PROBAND",
                    first_name="Alice",
                    last_name="Child",
                    date_of_birth="2017-01-01",
                    mrn="MRN-PROBAND",
                ),
                ProvisionalPatientInput(
                    role="MOTHER",
                    first_name="Mary",
                    last_name="Child",
                    date_of_birth="1986-02-02",
                    mrn="MRN-MOTHER",
                ),
                ProvisionalPatientInput(
                    role="FATHER",
                    first_name="Frank",
                    last_name="Child",
                    date_of_birth="1984-03-03",
                    mrn="MRN-FATHER",
                ),
            ],
        ),
        actor_id=actor_id,
    )

    detail = svc.get_work_item(item.euid)
    tree_types = {child["type"] for child in detail["tree"]["children"]}
    links = OrderRelationshipService(db_session, tenant_id).list_order_patient_links(
        order_euid=linked_revision.matching_state["test_euid"]
    )

    assert linked_revision.stage_status == "REGISTERED_MATCHED"
    assert linked_revision.matching_state["created_during_accessioning"] is True
    assert tree_types == {"Shipment", "TestKit"}
    assert {link.role.value for link in links} == {"PROBAND", "MOTHER", "FATHER"}


def test_minimal_capture_supports_recursive_tree_and_auto_primary_matching(
    db_session: Session,
    tenant_id: uuid.UUID,
    tenant_org,
    site,
    actor_id: uuid.UUID,
):
    svc = _service(db_session, tenant_id)
    item, _revision = _register_work_item(
        svc,
        actor_id=actor_id,
        site_euid=site.euid,
        tracking_number="TRACK-MINIMAL-001",
    )

    first_revision = svc.register_minimal_child(
        item.euid,
        MinimalChildRegistrationRequest(
            kind="TestKit",
            parent_node_id=f"root::{item.shipment_euid}",
            site_euid=site.euid,
            origin_site_id=site.euid,
        ),
        actor_id=actor_id,
    )
    editor = svc.get_minimal_editor(item.euid)
    kit_node = _find_node_by_kind(editor["root_node"], "Kit")
    assert kit_node is not None
    assert kit_node["label"].startswith("TKT-")

    second_revision = svc.register_minimal_child(
        item.euid,
        MinimalChildRegistrationRequest(
            kind="TRF",
            parent_node_id=kit_node["node_id"],
            route_code="WGS",
            product_code="WGS",
            specimen_type_required="blood-whole",
            site_euid=site.euid,
        ),
        actor_id=actor_id,
    )

    editor = svc.get_minimal_editor(item.euid)
    trf_node = _find_node_by_kind(editor["root_node"], "TRF")
    test_node = _find_node_by_kind(editor["root_node"], "Test")

    assert first_revision.queue == "PACKAGE_PROCESSING_PENDING"
    assert second_revision.matching_state["test_euid"]
    assert second_revision.matching_state["trf_euid"]
    assert trf_node is not None
    assert test_node is not None

    third_revision = svc.register_minimal_child(
        item.euid,
        MinimalChildRegistrationRequest(
            kind="Test",
            parent_node_id=trf_node["node_id"],
            route_code="EXOME",
            product_code="EXOME",
            specimen_type_required="saliva",
            site_euid=site.euid,
        ),
        actor_id=actor_id,
    )

    assert third_revision.matching_state.get("test_euid") is None
    assert len(third_revision.matching_state["test_euids"]) == 2

    ready_revision = svc.mark_capture_ready_for_review(
        item.euid,
        CaptureReadyForReviewRequest(),
        actor_id=actor_id,
    )
    assert ready_revision.queue == "MATCHING_PENDING"
    assert ready_revision.stage_status == "REGISTERED_UNMATCHED"


def test_minimal_capture_rejects_seventh_level_without_partial_write(
    db_session: Session,
    tenant_id: uuid.UUID,
    tenant_org,
    site,
    actor_id: uuid.UUID,
):
    svc = _service(db_session, tenant_id)
    item, _revision = _register_work_item(
        svc,
        actor_id=actor_id,
        site_euid=site.euid,
        tracking_number="TRACK-MINIMAL-DEPTH",
    )

    parent_node_id = f"root::{item.shipment_euid}"
    for _depth in range(6):
        svc.register_minimal_child(
            item.euid,
            MinimalChildRegistrationRequest(
                kind="Shipment",
                parent_node_id=parent_node_id,
                tracking_number=f"TRACK-DEPTH-{_depth}",
                carrier="UPS",
                origin_site_id=site.euid,
            ),
            actor_id=actor_id,
        )
        editor = svc.get_minimal_editor(item.euid)
        parent_node_id = _deepest_child(editor["root_node"])["node_id"]

    before = svc.get_minimal_editor(item.euid)
    with pytest.raises(ValueError, match="up to 6 nested levels"):
        svc.register_minimal_child(
            item.euid,
            MinimalChildRegistrationRequest(
                kind="Shipment",
                parent_node_id=parent_node_id,
                tracking_number="TRACK-DEPTH-FAIL",
                carrier="UPS",
                origin_site_id=site.euid,
            ),
            actor_id=actor_id,
        )
    after = svc.get_minimal_editor(item.euid)

    assert len(before["minimal_nodes"]) == len(after["minimal_nodes"])


def test_intake_scan_recognizes_barcode_less_kit_by_euid(
    db_session: Session,
    tenant_id: uuid.UUID,
    tenant_org,
    site,
    actor_id: uuid.UUID,
):
    kit = AtlasTestKitService(db_session, tenant_id).create(
        AtlasTestKitCreate(
            kit_barcode=None,
            kit_type="COLLECTION",
            origin_site_id=site.euid,
        ),
        created_by=actor_id,
    )

    result = IntakeService(db_session, tenant_id).scan_barcode(kit.euid, cross_tenant=False)

    assert result.found is True
    assert result.entity_type == "TestKit"
    assert result.entity_id == kit.euid
    assert result.entity_details["kit_barcode"] is None
    assert result.entity_details["display_label"] == kit.euid


def test_create_provisional_order_falls_back_to_hold_when_context_is_insufficient(
    db_session: Session,
    tenant_id: uuid.UUID,
    tenant_org,
    site,
    actor_id: uuid.UUID,
):
    svc = _service(db_session, tenant_id)
    item, _revision = _register_work_item(
        svc,
        actor_id=actor_id,
        site_euid=site.euid,
        tracking_number="TRACK-HOLD",
    )

    hold_revision = svc.create_provisional_order(
        item.euid,
        ProvisionalOrderRequest(
            site_id=site.euid,
            fulfillment_route_code="",
            patients=[],
        ),
        actor_id=actor_id,
    )

    assert hold_revision.queue == "HOLD_INVESTIGATE"
    assert hold_revision.stage_status == "HOLD"
    assert hold_revision.outcome_summary["exception_euid"]


def test_record_outcome_accepts_and_hands_off_to_bloom(
    db_session: Session,
    tenant_id: uuid.UUID,
    tenant_org,
    site,
    actor_id: uuid.UUID,
    fake_bloom,
):
    svc = _service(db_session, tenant_id)
    patient = _create_patient(db_session, tenant_id, site.euid, actor_id)
    trf, test = _create_trf_and_test(
        db_session,
        tenant_id,
        site.euid,
        actor_id,
        patient_euid=patient.euid,
    )
    item, _revision = _register_work_item(
        svc,
        actor_id=actor_id,
        site_euid=site.euid,
        tracking_number="TRACK-ACCEPT",
    )

    svc.register_content(
        item.euid,
        ContentRegistrationRequest(
            content_type="Tube",
            site_euid=site.euid,
            collection_site_euid=site.euid,
        ),
        actor_id=actor_id,
    )
    svc.link_work_item(
        item.euid,
        LinkRequest(
            trf_euid=trf.euid,
            test_euid=test.euid,
            patient_euid=patient.euid,
            collection_site_euid=site.euid,
            role_links=[(patient.euid, "PROBAND")],
        ),
        actor_id=actor_id,
    )

    accepted_revision = svc.record_outcome(
        item.euid,
        OutcomeRequest(
            outcome="ACCEPTED",
            patient_euid=patient.euid,
            starting_queue="extraction_prod",
        ),
        actor_id=actor_id,
    )

    assert accepted_revision.queue == "COMPLETED"
    assert accepted_revision.stage_status == "ACCEPTED"
    assert accepted_revision.outcome_summary["accepted"] is True
    assert accepted_revision.outcome_summary["current_queue"] == "extraction_prod"
    assert len(fake_bloom.accepted_material) == 1


def test_record_outcome_rejected_skips_bloom_and_enforces_reason(
    db_session: Session,
    tenant_id: uuid.UUID,
    tenant_org,
    site,
    actor_id: uuid.UUID,
    fake_bloom,
):
    svc = _service(db_session, tenant_id)
    patient = _create_patient(db_session, tenant_id, site.euid, actor_id)
    trf, test = _create_trf_and_test(
        db_session,
        tenant_id,
        site.euid,
        actor_id,
        patient_euid=patient.euid,
    )
    item, _revision = _register_work_item(
        svc,
        actor_id=actor_id,
        site_euid=site.euid,
        tracking_number="TRACK-REJECT",
    )
    svc.link_work_item(
        item.euid,
        LinkRequest(
            trf_euid=trf.euid,
            test_euid=test.euid,
            patient_euid=patient.euid,
            role_links=[(patient.euid, "PROBAND")],
        ),
        actor_id=actor_id,
    )

    with pytest.raises(ValueError, match="REJECTED requires a reason"):
        svc.record_outcome(
            item.euid,
            OutcomeRequest(outcome="REJECTED", patient_euid=patient.euid),
            actor_id=actor_id,
        )

    rejected_revision = svc.record_outcome(
        item.euid,
        OutcomeRequest(
            outcome="REJECTED",
            patient_euid=patient.euid,
            reason="Broken tube",
        ),
        actor_id=actor_id,
    )

    assert rejected_revision.queue == "COMPLETED"
    assert rejected_revision.stage_status == "REJECTED"
    assert rejected_revision.outcome_summary["reason"] == "Broken tube"
    assert fake_bloom.accepted_material == []


def test_accessioning_mutations_emit_audit_events(
    db_session: Session,
    tenant_id: uuid.UUID,
    tenant_org,
    site,
    actor_id: uuid.UUID,
    fake_bloom,
):
    svc = _service(db_session, tenant_id)
    patient = _create_patient(db_session, tenant_id, site.euid, actor_id)
    trf, test = _create_trf_and_test(
        db_session,
        tenant_id,
        site.euid,
        actor_id,
        patient_euid=patient.euid,
    )
    item, _revision = _register_work_item(
        svc,
        actor_id=actor_id,
        site_euid=site.euid,
        tracking_number="TRACK-AUDIT-001",
    )

    svc.register_content(
        item.euid,
        ContentRegistrationRequest(
            content_type="Tube",
            site_euid=site.euid,
            collection_site_euid=site.euid,
            registration_token="audit-tube-1",
        ),
        actor_id=actor_id,
    )
    svc.link_work_item(
        item.euid,
        LinkRequest(
            trf_euid=trf.euid,
            test_euid=test.euid,
            patient_euid=patient.euid,
            collection_site_euid=site.euid,
            role_links=[(patient.euid, "PROBAND")],
        ),
        actor_id=actor_id,
    )
    svc.record_outcome(
        item.euid,
        OutcomeRequest(
            outcome="ACCEPTED",
            patient_euid=patient.euid,
            starting_queue="extraction_prod",
        ),
        actor_id=actor_id,
    )

    events = AuditService(db_session, tenant_id=tenant_id).get_for_entity(
        "AccessionWorkItem",
        item.euid,
        limit=20,
    )
    actions = {event.action for event in events}
    stages = {str((event.details or {}).get("stage") or "") for event in events}

    assert {"CREATE", "UPDATE", "LINK", "STATUS_CHANGE"} <= actions
    assert {"receipt", "package_processing", "matching", "outcome"} <= stages


def test_linking_rejects_cross_tenant_test(
    db_session: Session,
    tenant_id: uuid.UUID,
    tenant_org,
    site,
    actor_id: uuid.UUID,
):
    svc = _service(db_session, tenant_id)
    item, _revision = _register_work_item(
        svc,
        actor_id=actor_id,
        site_euid=site.euid,
        tracking_number="TRACK-GUARD",
    )

    other_tenant_id = uuid.uuid4()
    other_org = ensure_tapdb_org(
        db_session,
        other_tenant_id,
        name="other-org",
        display_name="Other Org",
        site_name="Other Site",
        site_code="OTHER",
    )
    other_site = SiteService(db_session).list_by_organization(other_org.euid)[0]
    other_patient = _create_patient(db_session, other_tenant_id, other_site.euid, actor_id)
    _other_trf, other_test = _create_trf_and_test(
        db_session,
        other_tenant_id,
        other_site.euid,
        actor_id,
        patient_euid=other_patient.euid,
    )

    with pytest.raises(ValueError, match="Test not found"):
        svc.link_work_item(
            item.euid,
            LinkRequest(test_euid=other_test.euid),
            actor_id=actor_id,
        )
