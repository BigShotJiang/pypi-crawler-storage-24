"""Web route tests for the Atlas graph viewer."""

from __future__ import annotations

import uuid

import pytest
from fastapi.testclient import TestClient

from app.auth.dependencies import CurrentUser, get_current_user_web
from app.auth.rbac import Role
from app.db.engine import get_db
from app.main import app


@pytest.fixture(autouse=True)
def _clear_overrides():
    yield
    app.dependency_overrides.clear()


def _make_user(*roles: Role) -> CurrentUser:
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="graph-web@lsmc.bio",
        name="Graph Web",
        tenant_id=uuid.uuid4(),
        roles=[role.value for role in roles],
    )


def _client_with_user(user: CurrentUser) -> TestClient:
    def override_db():
        yield object()

    def override_user():
        return user

    app.dependency_overrides[get_db] = override_db
    app.dependency_overrides[get_current_user_web] = override_user
    return TestClient(app)


@pytest.mark.db
def test_graph_page_renders_with_cytoscape_bootstrap():
    client = _client_with_user(_make_user(Role.EXTERNAL_USER))

    response = client.get("/graph")
    assert response.status_code == 200
    assert "Graph Viewer" in response.text
    assert 'id="graph-canvas"' in response.text
    assert "AtlasGraphConfig" in response.text
    assert "/api/graph/data" in response.text


@pytest.mark.db
def test_dag_alias_redirects_to_graph_with_params():
    client = _client_with_user(_make_user(Role.EXTERNAL_USER))

    response = client.get("/dag?start_euid=AX1&depth=3", follow_redirects=False)
    assert response.status_code == 307
    assert response.headers.get("location") == "/graph?start_euid=AX1&depth=3"


def test_graph_requires_auth_redirect():
    client = TestClient(app)
    response = client.get("/graph", follow_redirects=False)
    assert response.status_code == 302
    assert response.headers.get("location") == "/auth/login"


@pytest.mark.db
def test_graph_nav_link_present_in_base_template():
    client = _client_with_user(_make_user(Role.EXTERNAL_USER))

    response = client.get("/graph")
    assert response.status_code == 200
    assert 'href="/graph"' in response.text
    assert ">Graph<" in response.text


@pytest.mark.db
def test_graph_query_defaults_reflect_request_params():
    client = _client_with_user(_make_user(Role.EXTERNAL_USER))

    response = client.get("/graph?start_euid=PAT-7&depth=6")
    assert response.status_code == 200
    assert 'id="graph-start-euid" type="text" value="PAT-7"' in response.text
    assert 'id="graph-depth" type="number" min="1" max="10" value="6"' in response.text


@pytest.mark.db
def test_graph_page_bootstraps_external_merge_paths():
    client = _client_with_user(_make_user(Role.EXTERNAL_USER))

    response = client.get("/graph?start_euid=PAT-7&depth=6&merge_ref=2")
    assert response.status_code == 200
    assert "/api/graph/external" in response.text
    assert "/api/graph/external/object" in response.text
    assert '"defaultMergeRef": 2' in response.text
