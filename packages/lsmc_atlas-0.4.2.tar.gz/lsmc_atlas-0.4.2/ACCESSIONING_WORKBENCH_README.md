# Atlas Accessioning Workbench

## Scope
- Atlas owns the accessioning UX, order-context linkage, collection-event metadata, queue state, and intake outcomes.
- Bloom remains the physical-material subsystem for containers/specimens and accepted-material ingress queue placement.
- R2 remains downstream QC and disposition authority after intake registration.

## Workflow
- Stage 1 receipt creates or reuses a shipment, records receipt metadata, and opens or reuses an Atlas accession work item.
- Stage 2 package processing registers one content item at a time while preserving shipment and kit containment lineage.
- Stage 3 matching links the shipment tree to `TRF.test`, records collection events and patient roles, then records `ACCEPTED`, `HOLD`, or `REJECTED`.
- No-order accessioning prefers provisional TRF/Test creation in Atlas and falls back to HOLD when site, patient, or route context is incomplete.

## Persistence
- Workbench queue and stage state are stored in the TapDB-backed `AccessionWorkItem` plus append-only revision records.
- Physical relationships stay in existing Atlas stores: shipment containment, test-kit lineage, document links, and Bloom external-object relations.
- Provisional TRFs and Tests carry `created_during_accessioning` plus the accession work-item provenance fields.

## Idempotency And Audit
- Receipt registration reuses the existing shipment-anchored work item when the inbound package was already registered.
- Stage 2 content registration stores a manifest fingerprint and a per-form registration token so duplicate submissions do not create duplicate Bloom tubes.
- Accepted-material handoff uses deterministic idempotency keys and only runs for `ACCEPTED`.
- Accession work-item receipt, content registration, matching, provisional-order, HOLD, and outcome transitions emit dedicated `AccessionWorkItem` audit events.

## Extension Hooks
- Stage 2 stores explicit label-print placeholders and tube/package image metadata placeholders on manifest items.
- Those placeholders are Atlas-native metadata only; they are the intended extension points for future printer drivers or image capture integrations.
