"""Resolve Atlas test/TRF/patient context for Bloom container lookups."""

from __future__ import annotations

from typing import Any

from app.domain.enums import OrderPatientRole
from app.domain.services.external_objects import ExternalObjectService
from app.domain.services.order_relationships import OrderRelationshipService
from app.domain.services.people import PatientService
from app.domain.services.shipments import ShipmentService, TestKitService
from app.domain.services.test_fulfillment_items import TestFulfillmentItemService
from app.domain.services.trfs import TestService, TrfService


class ContainerContextError(ValueError):
    """Base error for container context resolution."""


class ContainerNotFoundError(ContainerContextError):
    """Raised when a container EUID is not mapped in Atlas for a tenant."""


class ContainerContextInconsistentError(ContainerContextError):
    """Raised when mapped container relations are missing or inconsistent."""


class ContainerTenantMismatchError(ContainerContextError):
    """Raised when the container exists but belongs to a different tenant."""


class BloomQueryContextService:
    """Resolve Atlas context using a Bloom container EUID."""

    PROVIDER = "bloom"

    def __init__(self, db: Any, tenant_id):
        self.db = db
        self.tenant_id = tenant_id
        self.external_objects = ExternalObjectService(db, tenant_id)
        self.orders = TrfService(db, tenant_id)
        self.test_orders = TestService(db, tenant_id)
        self.fulfillment_items = TestFulfillmentItemService(db, tenant_id)
        self.patients = PatientService(db, tenant_id)
        self.shipments = ShipmentService(db, tenant_id)
        self.testkits = TestKitService(db, tenant_id)

    def get_trf_context_for_container(self, container_euid: str) -> dict[str, Any]:
        container = self.external_objects.get_external_object(
            provider=self.PROVIDER,
            object_type="container",
            external_euid=container_euid,
        )
        if container is None:
            mismatch_tenant_id = self._find_tenant_for_container_euid(container_euid)
            if mismatch_tenant_id is not None and mismatch_tenant_id != self.tenant_id:
                raise ContainerTenantMismatchError(
                    "Container tenant mismatch: "
                    f"requested={self.tenant_id} actual={mismatch_tenant_id}"
                )
            raise ContainerNotFoundError(f"Container not found: {container_euid}")

        relations = self.external_objects.list_relations_for_external_object(container.euid)
        trf_rel = self._single_relation(relations, "belongs_to_trf", "TRF")
        testkit_rel = self._single_relation(relations, "belongs_to_testkit", "TestKit")
        shipment_rel = self._single_relation(relations, "belongs_to_shipment", "Shipment")
        site_rel = self._single_relation(relations, "belongs_to_site", "Site")

        direct_test_relations = self._relations(relations, "belongs_to_test", "Test")
        direct_fulfillment_item_relations = self._relations(
            relations,
            "belongs_to_test_fulfillment_item",
            "TestFulfillmentItem",
        )

        direct_test_euids: list[str] = []
        direct_test_records: dict[str, Any] = {}
        for relation in direct_test_relations:
            test = self.test_orders.get_by_id(relation.local_entity_id, cross_tenant=False)
            if test is None:
                raise ContainerContextInconsistentError(
                    f"Container {container_euid} links to missing Test {relation.local_entity_id}"
                )
            if test.euid not in direct_test_records:
                direct_test_records[test.euid] = test
                direct_test_euids.append(test.euid)

        fulfillment_item_test_euids: list[str] = []
        fulfillment_item_entries: list[tuple[Any, Any]] = []
        seen_fulfillment_items: set[str] = set()
        for relation in direct_fulfillment_item_relations:
            if relation.local_entity_id in seen_fulfillment_items:
                continue
            seen_fulfillment_items.add(relation.local_entity_id)
            fulfillment_item = self.fulfillment_items.get(relation.local_entity_id)
            if fulfillment_item is None:
                raise ContainerContextInconsistentError(
                    "Container "
                    f"{container_euid} links to missing TestFulfillmentItem {relation.local_entity_id}"
                )
            linked_test = self.test_orders.get_by_id(fulfillment_item.test_euid, cross_tenant=False)
            if linked_test is None:
                raise ContainerContextInconsistentError(
                    f"Container {container_euid} links to fulfillment item {fulfillment_item.euid} "
                    f"with missing Test {fulfillment_item.test_euid}"
                )
            if linked_test.euid not in fulfillment_item_test_euids:
                fulfillment_item_test_euids.append(linked_test.euid)
            fulfillment_item_entries.append((fulfillment_item, linked_test))

        trf = None
        trf_rev = None
        if trf_rel is not None:
            trf_result = self.orders.get(trf_rel.local_entity_id, cross_tenant=False)
            if trf_result is None:
                raise ContainerContextInconsistentError(
                    f"Container {container_euid} links to missing TRF {trf_rel.local_entity_id}"
                )
            trf, trf_rev = trf_result

        derived_trf = None
        derived_trf_rev = None
        linked_test_euids = self._dedupe_preserve_order(
            direct_test_euids + fulfillment_item_test_euids
        )
        for linked_test_euid in linked_test_euids:
            linked_test = direct_test_records.get(linked_test_euid) or self.test_orders.get_by_id(
                linked_test_euid,
                cross_tenant=False,
            )
            if linked_test is None:
                raise ContainerContextInconsistentError(
                    f"Container {container_euid} links to missing Test {linked_test_euid}"
                )
            candidate_trf_result = self.orders.get(str(linked_test.order_id), cross_tenant=False)
            if candidate_trf_result is None:
                raise ContainerContextInconsistentError(
                    f"Container {container_euid} links to test {linked_test.euid} with missing TRF "
                    f"{linked_test.order_id}"
                )
            candidate_trf, candidate_trf_rev = candidate_trf_result
            if derived_trf is not None and str(derived_trf.euid) != str(candidate_trf.euid):
                raise ContainerContextInconsistentError(
                    f"Container {container_euid} links to tests across multiple TRFs"
                )
            derived_trf, derived_trf_rev = candidate_trf, candidate_trf_rev

        if (
            direct_test_euids
            and fulfillment_item_test_euids
            and set(direct_test_euids) != set(fulfillment_item_test_euids)
        ):
            raise ContainerContextInconsistentError(
                f"Container {container_euid} has conflicting direct-test and fulfillment-item links"
            )

        if trf is not None and derived_trf is not None and str(trf.euid) != str(derived_trf.euid):
            raise ContainerContextInconsistentError(
                f"Container {container_euid} links to mismatched TRF/Test topology"
            )
        if trf is None and derived_trf is not None:
            trf, trf_rev = derived_trf, derived_trf_rev

        if (
            trf is None
            and not linked_test_euids
            and not any(rel is not None for rel in (testkit_rel, shipment_rel, site_rel))
        ):
            raise ContainerContextInconsistentError(
                f"Container {container_euid} has no Atlas linkage context"
            )

        # Prefer graph-native Test↔Patient links. Fall back to the legacy TRF revision patient field.
        patient_id_from_links: str | None = None
        rel_svc = OrderRelationshipService(self.db, self.tenant_id)
        candidate_tests: list[tuple[Any, Any | None, list[Any] | None]] = []
        if trf is not None:
            candidate_tests.extend(self.test_orders.list_for_trf(trf.euid, cross_tenant=False))
        else:
            for linked_test_euid in linked_test_euids:
                linked_test = direct_test_records.get(
                    linked_test_euid
                ) or self.test_orders.get_by_id(
                    linked_test_euid,
                    cross_tenant=False,
                )
                if linked_test is None:
                    continue
                linked_test_result = self.test_orders.get_with_revision(
                    linked_test_euid, cross_tenant=False
                )
                linked_test_revision = (
                    linked_test_result[1] if linked_test_result is not None else None
                )
                candidate_tests.append(
                    (
                        linked_test,
                        linked_test_revision,
                        list(linked_test_revision.fulfillment_route_codes or []),
                    )
                )

        for test, _test_rev, _assays in candidate_tests:
            links = rel_svc.list_order_patient_links(order_euid=test.euid)
            if not links:
                continue
            proband = next(
                (lnk.patient_euid for lnk in links if lnk.role == OrderPatientRole.PROBAND),
                None,
            )
            patient_id_from_links = proband or links[0].patient_euid
            break

        patient_id = self._resolve_patient_id(
            container,
            patient_id_from_links or (getattr(trf_rev, "patient_id", None) if trf_rev else None),
        )
        patient = None
        patient_rev = None
        if patient_id is not None:
            patient_result = self.patients.get(patient_id, cross_tenant=False)
            if patient_result is None:
                raise ContainerContextInconsistentError(
                    f"Container {container_euid} links to missing Patient {patient_id}"
                )
            patient, patient_rev = patient_result

        tests: list[dict[str, Any]] = []
        for test, test_rev, fulfillment_routes in candidate_tests:
            if test_rev is None:
                continue
            tests.append(
                self._test_order_payload(
                    test=test,
                    test_rev=test_rev,
                    fulfillment_routes=fulfillment_routes,
                )
            )

        direct_test_payloads: list[dict[str, Any]] = []
        payload_by_test_euid = {str(item.get("test_euid")): item for item in tests}
        for direct_test_euid in direct_test_euids:
            payload = payload_by_test_euid.get(direct_test_euid)
            if payload is None:
                direct_test = direct_test_records.get(direct_test_euid)
                if direct_test is None:
                    continue
                direct_test_with_revision = self.test_orders.get_with_revision(
                    direct_test_euid, cross_tenant=False
                )
                if direct_test_with_revision is None:
                    continue
                payload = self._test_order_payload(
                    test=direct_test_with_revision[0],
                    test_rev=direct_test_with_revision[1],
                    fulfillment_routes=list(
                        direct_test_with_revision[1].fulfillment_route_codes or []
                    ),
                )
            direct_test_payloads.append(payload)

        direct_fulfillment_item_payloads: list[dict[str, Any]] = []
        for fulfillment_item, linked_test in fulfillment_item_entries:
            direct_fulfillment_item_payloads.append(
                {
                    "test_fulfillment_item_euid": fulfillment_item.euid,
                    "test_euid": linked_test.euid,
                    "required_material_type": fulfillment_item.required_material_type,
                    "platform": fulfillment_item.platform,
                    "routing_hint": fulfillment_item.routing_hint,
                    "intake_policy": fulfillment_item.intake_policy,
                }
            )

        links: dict[str, Any] = {}
        if testkit_rel is not None:
            kit_result = self.testkits.get_with_revision(
                testkit_rel.local_entity_id, cross_tenant=False
            )
            if kit_result is None:
                raise ContainerContextInconsistentError(
                    f"Container {container_euid} links to missing TestKit "
                    f"{testkit_rel.local_entity_id}"
                )
            kit, _kit_rev = kit_result
            links["testkit_euid"] = str(kit.euid)
            links["testkit_barcode"] = kit.kit_barcode
            links["testkit_label"] = kit.display_label

        if shipment_rel is not None:
            shipment_result = self.shipments.get(shipment_rel.local_entity_id, cross_tenant=False)
            if shipment_result is None:
                raise ContainerContextInconsistentError(
                    f"Container {container_euid} links to missing Shipment "
                    f"{shipment_rel.local_entity_id}"
                )
            shipment, _shipment_rev = shipment_result
            links["shipment_euid"] = str(shipment.euid)
            links["shipment_number"] = shipment.shipment_number

        if site_rel is not None:
            links["site_euid"] = str(site_rel.local_entity_id)

        trf_payload = (
            {
                "trf_euid": str(trf.euid),
                "trf_number": trf.order_number,
                "status": trf_rev.status if trf_rev else None,
                "trf_type": trf_rev.order_type if trf_rev else None,
                "submitted_at": (
                    trf_rev.submitted_at.isoformat()
                    if trf_rev and trf_rev.submitted_at is not None
                    else None
                ),
                "is_stat": bool(trf_rev.is_stat) if trf_rev else False,
            }
            if trf is not None
            else {}
        )
        patient_payload = (
            {
                "patient_euid": str(patient.euid),
                "first_name": patient_rev.first_name if patient_rev else None,
                "last_name": patient_rev.last_name if patient_rev else None,
                "date_of_birth": (
                    patient_rev.date_of_birth.isoformat()
                    if patient_rev and patient_rev.date_of_birth
                    else None
                ),
                "sex": patient_rev.sex if patient_rev else None,
                "mrn": patient_rev.mrn if patient_rev else None,
            }
            if patient is not None
            else {}
        )
        return {
            "atlas_tenant_id": str(self.tenant_id),
            "tenant_id": str(self.tenant_id),
            "container": {
                "external_object_euid": str(container.euid),
                "external_euid": container.external_euid,
                "status": container.status,
                "created_at": container.created_at.isoformat() if container.created_at else None,
                "modified_at": container.modified_at.isoformat() if container.modified_at else None,
            },
            "trf": trf_payload,
            "order": {
                "order_number": trf_payload.get("trf_number"),
                "order_euid": trf_payload.get("trf_euid"),
                "status": trf_payload.get("status"),
                "order_type": trf_payload.get("trf_type"),
            },
            "patient": patient_payload,
            "tests": tests,
            "test_orders": tests,
            "container_test_orders": direct_test_payloads,
            "container_test_fulfillment_items": direct_fulfillment_item_payloads,
            "links": links,
        }

    def _resolve_patient_id(
        self,
        container,
        order_patient_id: str | None,
    ) -> str | None:
        collection_event_patient_id = self._resolve_patient_from_collection_event(container.euid)
        if collection_event_patient_id is not None:
            return collection_event_patient_id
        if order_patient_id is not None:
            return order_patient_id

        return self._resolve_patient_from_specimen_relations(container.euid)

    def _resolve_patient_from_collection_event(self, container_object_id: str) -> str | None:
        from app.domain.services.collection_events import CollectionEventService

        container_relations = self.external_objects.list_relations_for_external_object(
            container_object_id
        )
        collection_rel = self._single_relation(
            container_relations,
            "has_collection_event",
            "CollectionEvent",
        )
        if collection_rel is None:
            return None
        event = CollectionEventService(self.db, self.tenant_id).get(collection_rel.local_entity_id)
        if event is None:
            raise ContainerContextInconsistentError(
                f"Container links to missing collection event {collection_rel.local_entity_id}"
            )
        return event[0].patient_id

    def _resolve_patient_from_specimen_relations(self, container_object_id: str) -> str | None:
        from app.domain.services.collection_events import CollectionEventService

        candidate_ids: set[str] = set()
        containment_relations = self.external_objects.list_relations_for_local_entity(
            local_entity_type="ExternalObject",
            local_entity_id=container_object_id,
        )
        for relation in containment_relations:
            if relation.relation_type != "contained_in":
                continue
            specimen = self.external_objects.get_external_object_by_id(relation.external_object_id)
            if specimen is None or specimen.object_type != "specimen" or specimen.is_deleted:
                continue
            relations = self.external_objects.list_relations_for_external_object(specimen.euid)
            collection_event_rel = self._single_relation(
                relations,
                "belongs_to_collection_event",
                "CollectionEvent",
            )
            if collection_event_rel is not None:
                event = CollectionEventService(self.db, self.tenant_id).get(
                    collection_event_rel.local_entity_id
                )
                if event is None:
                    raise ContainerContextInconsistentError(
                        "Container maps to specimen with missing collection event "
                        f"{collection_event_rel.local_entity_id}"
                    )
                candidate_ids.add(event[0].patient_id)
                continue
            patient_rel = self._single_relation(relations, "belongs_to_patient", "Patient")
            if patient_rel is not None:
                candidate_ids.add(patient_rel.local_entity_id)

        if not candidate_ids:
            return None
        if len(candidate_ids) > 1:
            raise ContainerContextInconsistentError(
                "Container maps to specimens with conflicting patient links"
            )
        return next(iter(candidate_ids))

    @staticmethod
    def _single_relation(
        relations: list[Any],
        relation_type: str,
        local_entity_type: str,
    ):
        matches = [
            relation
            for relation in relations
            if relation.relation_type == relation_type
            and relation.local_entity_type == local_entity_type
        ]
        if not matches:
            return None
        if len(matches) > 1:
            raise ContainerContextInconsistentError(
                f"Multiple relations found for {relation_type}/{local_entity_type}"
            )
        return matches[0]

    @staticmethod
    def _relations(
        relations: list[Any],
        relation_type: str,
        local_entity_type: str,
    ) -> list[Any]:
        return [
            relation
            for relation in relations
            if relation.relation_type == relation_type
            and relation.local_entity_type == local_entity_type
        ]

    @staticmethod
    def _dedupe_preserve_order(values: list[str]) -> list[str]:
        seen: set[str] = set()
        normalized: list[str] = []
        for value in values:
            clean = str(value or "").strip()
            if not clean or clean in seen:
                continue
            seen.add(clean)
            normalized.append(clean)
        return normalized

    def _test_order_payload(
        self,
        *,
        test,
        test_rev,
        fulfillment_routes: list[Any] | None,
    ) -> dict[str, Any]:
        return {
            "test_euid": str(test.euid),
            "status": test_rev.status,
            "product_code": test_rev.product_code,
            "product_name": test_rev.product_name,
            "fulfillment_routes": self._normalize_fulfillment_routes(fulfillment_routes),
        }

    @staticmethod
    def _normalize_fulfillment_routes(
        fulfillment_routes: list[Any] | None,
    ) -> list[dict[str, str | None]]:
        normalized: list[dict[str, str | None]] = []
        for item in fulfillment_routes or []:
            code: str | None = None
            name: str | None = None
            if isinstance(item, str):
                code = item
            elif isinstance(item, dict):
                code = item.get("code") or item.get("fulfillment_route_code") or item.get("name")
                name = item.get("name")
            elif isinstance(item, (list, tuple)) and item:
                code = str(item[0])
                if len(item) > 1 and item[1] is not None:
                    name = str(item[1])
            if code:
                normalized.append({"code": str(code), "name": name})
        return normalized

    def _find_tenant_for_container_euid(self, container_euid: str):
        # Cross-tenant fallback check for clearer mismatch diagnostics on global tokens.
        from app.persistence.tapdb.external_objects import TapdbExternalObjectRepository

        repository = TapdbExternalObjectRepository(self.db)
        for record in repository.list_external_objects(
            tenant_id=None,
            provider=self.PROVIDER,
            object_type="container",
            include_deleted=False,
        ):
            if record.external_euid == container_euid:
                return record.tenant_id
        return None
