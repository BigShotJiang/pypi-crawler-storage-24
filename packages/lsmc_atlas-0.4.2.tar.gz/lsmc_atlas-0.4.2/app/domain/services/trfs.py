"""Atlas TRF and Test services backed by TapDB repositories."""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from types import SimpleNamespace

from daylily_tapdb.models.instance import generic_instance
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.domain.enums import AuditAction, OrderStatus, OrderType, TestOrderStatus
from app.domain.services.fulfillment_runs import FulfillmentRunCreate, FulfillmentRunService
from app.domain.services.order_relationships import OrderPatientLink, OrderRelationshipService
from app.domain.services.webhook_emitter import emit_order_created, emit_order_status_changed
from app.persistence.tapdb.euid_helpers import get_instance_by_euid
from app.persistence.tapdb.people import PATIENT_TEMPLATE_CODE
from app.persistence.tapdb.trfs import (
    TapdbTestRecord as Test,
)
from app.persistence.tapdb.trfs import (
    TapdbTestRevisionRecord as TestRevision,
)
from app.persistence.tapdb.trfs import (
    TapdbTrfRecord as Trf,
)
from app.persistence.tapdb.trfs import (
    TapdbTrfRepository,
)
from app.persistence.tapdb.trfs import (
    TapdbTrfRevisionRecord as TrfRevision,
)

logger = logging.getLogger(__name__)


@dataclass
class TrfCreate:
    """Data for creating a new TRF."""

    clinician_id: str | None = None
    order_type: str = OrderType.CLINICAL.value
    is_stat: bool = False
    priority_notes: str | None = None
    indication: str | None = None
    clinical_notes: str | None = None
    icd10_codes: list[str] | None = None
    billing_info: dict | None = None
    site_id: str | None = None
    created_during_accessioning: bool = False
    accession_work_item_id: str | None = None


@dataclass
class TrfUpdate:
    """Data for updating a TRF (creates a new revision)."""

    clinician_id: str | None = None
    order_type: str | None = None
    is_stat: bool | None = None
    priority_notes: str | None = None
    indication: str | None = None
    clinical_notes: str | None = None
    icd10_codes: list[str] | None = None
    billing_info: dict | None = None
    site_id: str | None = None
    created_during_accessioning: bool | None = None
    accession_work_item_id: str | None = None
    note: str | None = None


@dataclass
class TestCreate:
    """Data for creating a Test."""

    product_code: str | None = None
    fulfillment_route_codes: list[str] = field(default_factory=list)
    product_name: str | None = None
    specimen_type_required: str | None = None
    special_instructions: str | None = None
    specimen_type: str | None = None
    priority: str = "NORMAL"
    clinical_notes: str | None = None
    site_id: str | None = None
    created_during_accessioning: bool = False
    accession_work_item_id: str | None = None


@dataclass
class TestUpdate:
    """Data for updating a Test."""

    product_code: str | None = None
    product_name: str | None = None
    fulfillment_route_codes: list[str] | None = None
    specimen_type_required: str | None = None
    special_instructions: str | None = None
    created_during_accessioning: bool | None = None
    accession_work_item_id: str | None = None
    note: str | None = None


def _resolved_fulfillment_route_codes(data: TestCreate) -> list[str]:
    return [str(code).strip() for code in data.fulfillment_route_codes if str(code).strip()]


class TrfService:
    """Service for TRF operations with tenant scoping."""

    def __init__(self, db: Session, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self._repo_cache: TapdbTrfRepository | None = None

    def _repo(self) -> TapdbTrfRepository:
        if self._repo_cache is None:
            self._repo_cache = TapdbTrfRepository(self.db)
        return self._repo_cache

    def _log_audit(
        self,
        *,
        tenant_id: uuid.UUID,
        action: AuditAction,
        entity_type: str,
        entity_id: str,
        user_id: uuid.UUID | None,
        details: dict | None = None,
    ) -> None:
        try:
            from app.domain.services.audit import AuditService

            AuditService(
                self.db, tenant_id=tenant_id, user_id=str(user_id) if user_id else None
            ).log(
                action=action,
                entity_type=entity_type,
                entity_id=entity_id,
                details=details,
                user_id=user_id,
            )
        except Exception:
            rollback = getattr(self.db, "rollback", None)
            if callable(rollback):
                rollback()
            logger.warning(
                "Audit logging failed for %s %s in tenant %s",
                entity_type,
                entity_id,
                tenant_id,
                exc_info=True,
            )

    def create(
        self,
        data: TrfCreate,
        tests: list[TestCreate] | None = None,
        patient_links: list[OrderPatientLink] | None = None,
        created_by: uuid.UUID | None = None,
    ) -> tuple[Trf, TrfRevision]:
        from app.domain.services.site_scope import resolve_tenant_site_euid

        resolved_site_id = resolve_tenant_site_euid(self.db, self.tenant_id, data.site_id)
        data.site_id = resolved_site_id
        trf, revision = self._repo().create_trf(
            tenant_id=self.tenant_id,
            data=data,
            created_by=created_by,
        )

        if tests:
            for test_data in tests:
                self._create_test(
                    trf.euid,
                    test_data,
                    created_by,
                    patient_links=patient_links,
                    site_id=resolved_site_id,
                )

        self._log_audit(
            tenant_id=self.tenant_id,
            action=AuditAction.CREATE,
            entity_type="TRF",
            entity_id=trf.euid,
            user_id=created_by,
            details={"trf_euid": trf.euid},
        )

        self.db.commit()
        emit_order_created(self.db, self.tenant_id, trf.euid, trf.order_number)
        return trf, revision

    def _create_test(
        self,
        trf_id: str,
        data: TestCreate,
        created_by: uuid.UUID | None,
        patient_links: list[OrderPatientLink] | None = None,
        site_id: str | None = None,
    ) -> Test:
        fulfillment_route_codes = _resolved_fulfillment_route_codes(data)
        if not fulfillment_route_codes:
            raise ValueError("Test requires at least one assay code")

        if not data.product_code:
            data.product_code = fulfillment_route_codes[0]
        if data.specimen_type_required is None:
            data.specimen_type_required = data.specimen_type
        if data.special_instructions is None:
            data.special_instructions = data.clinical_notes
        if data.site_id is None:
            data.site_id = site_id

        test, _revision = self._repo().create_test(
            tenant_id=self.tenant_id,
            trf_id=trf_id,
            data=data,
            created_by=created_by,
        )

        if patient_links:
            OrderRelationshipService(self.db, self.tenant_id).ensure_order_patient_links(
                order_euid=test.euid,
                links=patient_links,
                replace=False,
            )

        try:
            assay_run_svc = FulfillmentRunService(self.db, self.tenant_id)
            for fulfillment_route_code in fulfillment_route_codes:
                assay_run_svc.create(
                    FulfillmentRunCreate(
                        order_id=trf_id,
                        test_order_id=test.euid,
                        fulfillment_route_code=fulfillment_route_code,
                    ),
                    created_by=created_by,
                )
        except Exception:
            logger.warning(
                "Unable to initialize assay runs for test %s; continuing TRF flow",
                test.euid,
                exc_info=True,
            )

        return test

    def get_by_id(self, trf_id: str, cross_tenant: bool = False) -> tuple[Trf, TrfRevision] | None:
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().get_trf_with_revision(trf_id=trf_id, tenant_id=tenant_scope)

    def get(self, trf_id: str, cross_tenant: bool = False) -> tuple[Trf, TrfRevision] | None:
        return self.get_by_id(trf_id, cross_tenant=cross_tenant)

    def get_by_number(
        self, trf_number: str, cross_tenant: bool = False
    ) -> tuple[Trf, TrfRevision] | None:
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().get_trf_by_number_with_revision(
            trf_number=trf_number,
            tenant_id=tenant_scope,
        )

    def list_trfs(
        self,
        status: OrderStatus | None = None,
        limit: int = 100,
        offset: int = 0,
        cross_tenant: bool = False,
    ) -> list[tuple[Trf, TrfRevision]]:
        tenant_scope = None if cross_tenant else self.tenant_id
        rows = self._repo().list_trfs(tenant_id=tenant_scope, limit=limit, offset=offset)
        if status is None:
            return rows
        return [(trf, revision) for trf, revision in rows if revision.status == status.value]

    def list_by_patient(
        self,
        patient_id: str,
        limit: int = 100,
        cross_tenant: bool = False,
    ) -> list[dict]:
        tenant_scope = None if cross_tenant else self.tenant_id
        patient_inst = get_instance_by_euid(self.db, PATIENT_TEMPLATE_CODE, patient_id)
        if patient_inst is None:
            return []

        if not cross_tenant:
            props = (
                (patient_inst.json_addl or {}).get("properties")
                if isinstance(patient_inst.json_addl, dict)
                else {}
            )
            if isinstance(props, dict) and str(props.get("tenant_id") or ""):
                try:
                    if uuid.UUID(str(props["tenant_id"])) != self.tenant_id:
                        return []
                except (KeyError, ValueError):
                    pass

        from daylily_tapdb.models.lineage import generic_instance_lineage

        stmt = (
            select(generic_instance_lineage)
            .where(
                generic_instance_lineage.parent_instance_uid == patient_inst.uid,
                generic_instance_lineage.relationship_type == "order_patient",
                generic_instance_lineage.is_deleted.is_(False),
            )
            .limit(limit * 10)
        )
        edges = list(self.db.execute(stmt).scalars().all())

        trfs: dict[str, tuple[Trf, TrfRevision]] = {}
        repo = self._repo()
        for edge in edges:
            test_inst = self.db.execute(
                select(generic_instance).where(
                    generic_instance.uid == edge.child_instance_uid,
                    generic_instance.is_deleted.is_(False),
                )
            ).scalar_one_or_none()
            if test_inst is None:
                continue
            test_record = repo._to_test(test_inst)  # noqa: SLF001
            trf_id = test_record.order_id
            if trf_id in trfs:
                continue
            trf = repo.get_trf_by_id(trf_id=trf_id, tenant_id=tenant_scope)
            if trf is None:
                continue
            trf_rev = repo.get_latest_trf_revision(trf_id)
            if trf_rev is None:
                continue
            trfs[trf_id] = (trf, trf_rev)
            if len(trfs) >= limit:
                break

        result: list[dict] = []
        for trf, rev in sorted(
            trfs.values(),
            key=lambda row: row[0].created_at or datetime.min,
            reverse=True,
        ):
            result.append(
                {
                    "trf_euid": trf.euid,
                    "trf_number": trf.order_number,
                    "created_at": trf.created_at.strftime("%Y-%m-%d %H:%M")
                    if trf.created_at
                    else None,
                    "status": rev.status,
                }
            )
        return result

    def update(
        self,
        trf_id: str,
        data: TrfUpdate,
        updated_by: uuid.UUID | None = None,
        cross_tenant: bool = False,
    ) -> tuple[Trf, TrfRevision] | None:
        if data.site_id is not None:
            from app.domain.services.site_scope import resolve_tenant_site_euid

            target_tenant_id = self.tenant_id
            if cross_tenant:
                existing = self._repo().get_trf_by_id(trf_id=trf_id, tenant_id=None)
                if existing is not None:
                    target_tenant_id = existing.tenant_id
            data.site_id = resolve_tenant_site_euid(self.db, target_tenant_id, data.site_id)
        tenant_scope = None if cross_tenant else self.tenant_id
        result = self._repo().update_trf(
            trf_id=trf_id,
            data=data,
            updated_by=updated_by,
            tenant_id=tenant_scope,
        )
        if result is None:
            return None

        trf, revision = result
        self._log_audit(
            tenant_id=trf.tenant_id,
            action=AuditAction.UPDATE,
            entity_type="TRF",
            entity_id=trf.euid,
            user_id=updated_by,
        )
        self.db.commit()
        return trf, revision

    def change_status(
        self,
        trf_id: str,
        new_status: OrderStatus,
        reason: str | None = None,
        updated_by: uuid.UUID | None = None,
        cross_tenant: bool = False,
    ) -> tuple[Trf, TrfRevision] | None:
        current = self.get_by_id(trf_id, cross_tenant=cross_tenant)
        if current is None:
            return None
        trf, latest = current
        tenant_scope = None if cross_tenant else self.tenant_id

        submitted_at = (
            datetime.now(UTC) if new_status == OrderStatus.SUBMITTED else latest.submitted_at
        )
        result = self._repo().change_trf_status(
            trf_id=trf_id,
            new_status=new_status.value,
            reason=reason,
            updated_by=updated_by,
            tenant_id=tenant_scope,
            submitted_at=submitted_at,
        )
        if result is None:
            return None

        trf, revision = result
        self._log_audit(
            tenant_id=trf.tenant_id,
            action=AuditAction.STATUS_CHANGE,
            entity_type="TRF",
            entity_id=trf.euid,
            user_id=updated_by,
            details={"old_status": latest.status, "new_status": new_status.value},
        )
        self.db.commit()

        emit_order_status_changed(
            self.db,
            trf.tenant_id,
            trf.euid,
            trf.order_number,
            latest.status,
            new_status.value,
        )

        return trf, revision

    def submit(
        self,
        trf_id: str,
        updated_by: uuid.UUID | None = None,
        cross_tenant: bool = False,
    ) -> tuple[Trf, TrfRevision] | None:
        return self.change_status(
            trf_id,
            OrderStatus.ORDERED,
            reason="TRF submitted",
            updated_by=updated_by,
            cross_tenant=cross_tenant,
        )

    def _get_latest_revision(self, trf_id: str) -> TrfRevision | None:
        return self._repo().get_latest_trf_revision(trf_id)


class TestService:
    """Service for Test operations."""

    def __init__(self, db: Session, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self._repo_cache: TapdbTrfRepository | None = None

    def _repo(self) -> TapdbTrfRepository:
        if self._repo_cache is None:
            self._repo_cache = TapdbTrfRepository(self.db)
        return self._repo_cache

    def create(
        self,
        trf_id: str,
        data: TestCreate,
        created_by: uuid.UUID | None = None,
        cross_tenant: bool = False,
    ) -> tuple[Test, TestRevision] | None:
        trf_svc = TrfService(self.db, self.tenant_id)
        trf_result = trf_svc.get_by_id(trf_id, cross_tenant=cross_tenant)
        if trf_result is None:
            return None
        trf, _trf_rev = trf_result

        fulfillment_route_codes = _resolved_fulfillment_route_codes(data)
        if not fulfillment_route_codes:
            return None
        if data.product_code is None:
            data.product_code = fulfillment_route_codes[0]
        if data.specimen_type_required is None:
            data.specimen_type_required = data.specimen_type
        if data.special_instructions is None:
            data.special_instructions = data.clinical_notes
        if data.site_id is None:
            data.site_id = getattr(trf, "site_id", None)
        if not data.site_id:
            from app.domain.services.site_scope import resolve_tenant_site_euid

            data.site_id = resolve_tenant_site_euid(self.db, self.tenant_id, None)

        test, revision = self._repo().create_test(
            tenant_id=self.tenant_id,
            trf_id=trf_id,
            data=data,
            created_by=created_by,
        )

        try:
            assay_run_svc = FulfillmentRunService(self.db, self.tenant_id)
            for fulfillment_route_code in fulfillment_route_codes:
                assay_run_svc.create(
                    FulfillmentRunCreate(
                        order_id=trf_id,
                        test_order_id=test.euid,
                        fulfillment_route_code=fulfillment_route_code,
                    ),
                    created_by=created_by,
                )
        except Exception:
            logger.warning(
                "Unable to initialize assay runs for test %s",
                test.euid,
                exc_info=True,
            )

        self.db.commit()
        return test, revision

    def get_by_id(self, test_id: str, cross_tenant: bool = False) -> Test | None:
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().get_test_by_id(test_id=test_id, tenant_id=tenant_scope)

    def get_with_revision(
        self, test_id: str, cross_tenant: bool = False
    ) -> tuple[Test, TestRevision] | None:
        test = self.get_by_id(test_id, cross_tenant=cross_tenant)
        if test is None:
            return None
        revision = self._get_latest_revision(test.euid)
        if revision is None:
            return None
        return test, revision

    def list_by_trf(self, trf_id: str, cross_tenant: bool = False) -> list[Test]:
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().list_tests(trf_id=trf_id, tenant_id=tenant_scope)

    def list_for_trf(
        self, trf_id: str, cross_tenant: bool = False
    ) -> list[tuple[Test, TestRevision, list]]:
        rows: list[tuple[Test, TestRevision, list]] = []
        for test in self.list_by_trf(trf_id, cross_tenant=cross_tenant):
            revision = self._get_latest_revision(test.euid)
            if revision is None:
                continue
            fulfillment_routes = [
                SimpleNamespace(
                    fulfillment_route_code=code, fulfillment_route_name=None, panel_code=None
                )
                for code in (revision.fulfillment_route_codes or [])
            ]
            rows.append((test, revision, fulfillment_routes))
        return rows

    def change_status(
        self,
        test_id: str,
        new_status: TestOrderStatus,
        reason: str | None = None,
        updated_by: uuid.UUID | None = None,
        cross_tenant: bool = False,
    ) -> Test | None:
        tenant_scope = None if cross_tenant else self.tenant_id
        result = self._repo().change_test_status(
            test_id=test_id,
            new_status=new_status.value,
            reason=reason,
            updated_by=updated_by,
            tenant_id=tenant_scope,
        )
        if result is None:
            return None

        test, _revision = result
        self.db.commit()
        return test

    def _get_latest_revision(self, test_id: str) -> TestRevision | None:
        return self._repo().get_latest_test_revision(test_id)
