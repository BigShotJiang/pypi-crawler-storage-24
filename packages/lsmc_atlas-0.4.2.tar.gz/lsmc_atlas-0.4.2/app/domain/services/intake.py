"""Atlas intake service for shipment receipt and Bloom material handoff."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from enum import StrEnum

from app.domain.enums import (
    OrderStatus,
    TestOrderStatus,
)
from app.domain.services.bloom_bridge import AcceptedMaterialRequest, ContainerSpecimenBridgeService
from app.domain.services.bloom_status_events import compute_order_status_from_tests
from app.domain.services.external_objects import ExternalObjectService
from app.domain.services.shipments import ShipmentService, TestKitService
from app.domain.services.trfs import TestService, TrfService
from app.settings import settings


class MaterialIntakeOutcome(StrEnum):
    ACCEPTED = "ACCEPTED"
    HOLD = "HOLD"
    REJECTED = "REJECTED"


@dataclass
class ScanResult:
    """Result of scanning an intake identifier."""

    found: bool
    entity_type: str | None = None
    entity_id: str | None = None
    entity_details: dict | None = None


@dataclass
class MaterialOutcomeRequest:
    trf_euid: str
    test_euids: list[str]
    patient_euid: str
    outcome: MaterialIntakeOutcome
    shipment_euid: str | None = None
    testkit_euid: str | None = None
    specimen_template_code: str = "content/specimen/blood-whole/1.0"
    specimen_name: str | None = None
    container_euid: str | None = None
    container_template_code: str | None = None
    properties: dict[str, str | int | float | bool | None] = field(default_factory=dict)
    starting_queue: str | None = None
    queue_metadata: dict[str, str | int | float | bool | None] = field(default_factory=dict)
    reason: str | None = None
    idempotency_key: str | None = None


@dataclass
class MaterialOutcomeResult:
    outcome: str
    trf_euid: str
    test_euids: list[str]
    fulfillment_item_euids: list[str]
    patient_euid: str
    trf_status: str
    test_statuses: dict[str, str]
    container_euid: str | None = None
    specimen_euid: str | None = None
    current_queue: str | None = None
    accepted: bool = False


class IntakeService:
    """Service for Atlas intake operations."""

    def __init__(self, db, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self.orders = TrfService(db, tenant_id)
        self.test_orders = TestService(db, tenant_id)
        self.shipments = ShipmentService(db, tenant_id)
        self.testkits = TestKitService(db, tenant_id)
        self.external_objects = ExternalObjectService(db, tenant_id)

    def scan_barcode(self, barcode: str, cross_tenant: bool = False) -> ScanResult:
        """Identify test kits, shipments, or already-linked Bloom materials."""
        clean = str(barcode or "").strip()
        if not clean:
            return ScanResult(found=False)

        test_kit = self.testkits.get_by_barcode(clean, cross_tenant=cross_tenant)
        if test_kit is None:
            test_kit = self.testkits.get_by_id(clean, cross_tenant=cross_tenant)
        if test_kit is not None:
            return ScanResult(
                found=True,
                entity_type="TestKit",
                entity_id=test_kit.euid,
                entity_details={
                    "kit_barcode": test_kit.kit_barcode,
                    "display_label": test_kit.display_label,
                },
            )

        shipment = self.shipments.get_by_tracking_number(clean, cross_tenant=cross_tenant)
        if shipment is not None:
            return ScanResult(
                found=True,
                entity_type="Shipment",
                entity_id=shipment.euid,
                entity_details={"tracking_number": clean},
            )

        for object_type in ("container", "specimen"):
            obj = self.external_objects.get_external_object(
                provider="bloom",
                object_type=object_type,
                external_euid=clean,
            )
            if obj is None:
                continue
            return ScanResult(
                found=True,
                entity_type=f"Bloom{object_type.title()}",
                entity_id=obj.external_euid,
                entity_details={"external_object_euid": obj.euid, "status": obj.status},
            )

        return ScanResult(found=False)

    def receive_shipment(
        self,
        shipment_id: str,
        created_by: uuid.UUID | None = None,
        cross_tenant: bool = False,
        received_by: str | None = None,
        package_condition: str | None = None,
        note: str | None = None,
    ):
        """Mark a shipment as received in Atlas."""
        result = self.shipments.record_receipt(
            shipment_id,
            received_by=received_by,
            package_condition=package_condition,
            note=note or "Received at intake",
            updated_by=created_by,
            cross_tenant=cross_tenant,
        )
        return result[0] if result is not None else None

    def record_material_outcome(
        self,
        data: MaterialOutcomeRequest,
        *,
        actor_id: uuid.UUID | None = None,
    ) -> MaterialOutcomeResult:
        trf = self.orders.get(data.trf_euid, cross_tenant=False)
        if trf is None:
            raise ValueError(f"TRF not found: {data.trf_euid}")
        trf_record, trf_revision = trf

        test_status = self._status_for_outcome(data.outcome)
        test_statuses: dict[str, str] = {}

        for test_euid in data.test_euids:
            test = self.test_orders.get_by_id(test_euid, cross_tenant=False)
            if test is None:
                raise ValueError(f"Test not found: {test_euid}")
            if str(test.order_id) != str(trf_record.euid):
                raise ValueError(f"Test {test_euid} does not belong to TRF {trf_record.euid}")

        accepted_result = None
        if data.outcome == MaterialIntakeOutcome.ACCEPTED:
            starting_queue = str(data.starting_queue or "").strip()
            if not starting_queue:
                raise ValueError("starting_queue is required when outcome=ACCEPTED")
            accepted_result = ContainerSpecimenBridgeService(
                self.db, self.tenant_id
            ).register_accepted_material(
                AcceptedMaterialRequest(
                    trf_euid=trf_record.euid,
                    test_euids=data.test_euids,
                    patient_euid=data.patient_euid,
                    shipment_euid=data.shipment_euid,
                    testkit_euid=data.testkit_euid,
                    specimen_template_code=data.specimen_template_code,
                    specimen_name=data.specimen_name,
                    container_euid=data.container_euid,
                    container_template_code=data.container_template_code
                    or settings.bloom_default_container_template_code,
                    properties=dict(data.properties or {}),
                    starting_queue=starting_queue,
                    queue_metadata=dict(data.queue_metadata or {}),
                    idempotency_key=data.idempotency_key,
                ),
                actor_id=actor_id,
            )

        reason = data.reason or f"Intake outcome recorded: {data.outcome.value}"
        for test_euid in data.test_euids:
            changed = self.test_orders.change_status(
                test_euid,
                test_status,
                reason=reason,
                updated_by=actor_id,
                cross_tenant=False,
            )
            if changed is None:
                raise ValueError(f"Failed updating Test status: {test_euid}")
            test_statuses[test_euid] = test_status.value

        fallback_status = (
            trf_revision.status if trf_revision is not None else OrderStatus.ORDERED.value
        )
        trf_status = self._roll_up_order_status(trf_record.euid, fallback=fallback_status)
        current_trf = self.orders.get(trf_record.euid, cross_tenant=False)
        current_trf_status = current_trf[1].status if current_trf and current_trf[1] else None
        if current_trf_status != trf_status.value:
            self.orders.change_status(
                trf_record.euid,
                trf_status,
                reason=f"Rolled up from intake outcome {data.outcome.value}",
                updated_by=actor_id,
                cross_tenant=False,
            )

        return MaterialOutcomeResult(
            outcome=data.outcome.value,
            trf_euid=trf_record.euid,
            test_euids=list(data.test_euids),
            fulfillment_item_euids=(
                list(accepted_result.fulfillment_item_euids) if accepted_result is not None else []
            ),
            patient_euid=data.patient_euid,
            trf_status=trf_status.value,
            test_statuses=test_statuses,
            container_euid=accepted_result.container_euid if accepted_result else None,
            specimen_euid=accepted_result.specimen_euid if accepted_result else None,
            current_queue=accepted_result.current_queue if accepted_result else None,
            accepted=accepted_result is not None,
        )

    @staticmethod
    def _status_for_outcome(outcome: MaterialIntakeOutcome) -> TestOrderStatus:
        if outcome == MaterialIntakeOutcome.ACCEPTED:
            return TestOrderStatus.SPECIMEN_RECEIVED
        if outcome == MaterialIntakeOutcome.HOLD:
            return TestOrderStatus.ON_HOLD
        return TestOrderStatus.REJECTED

    def _roll_up_order_status(self, order_euid: str, *, fallback: str) -> OrderStatus:
        test_orders = self.test_orders.list_for_trf(order_euid, cross_tenant=False)
        statuses = [revision.status for _, revision, _ in test_orders if revision is not None]
        if not statuses:
            try:
                return OrderStatus(str(fallback))
            except ValueError:
                return OrderStatus.ORDERED
        return compute_order_status_from_tests(statuses)
