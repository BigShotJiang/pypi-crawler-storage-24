"""LSMC Hub - Shipment and Logistics Services (Pure TapDB).

Provides operations for Shipments and TestKits with:
- Tenant scoping
- Containment via TapDB lineage
- Status tracking via TapDB revisions
- EUID-native identity
"""

import logging
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime

from sqlalchemy.orm import Session

from app.domain.enums import (
    ShipmentStatus,
    TestKitStatus,
)
from app.persistence.tapdb.logistics import (
    TapdbLogisticsRepository,
    TapdbShipmentRecord,
    TapdbShipmentRevisionRecord,
    TapdbTestKitRecord,
    TapdbTestKitRevisionRecord,
)

logger = logging.getLogger(__name__)


@dataclass
class ShipmentCreate:
    """Data for creating a shipment."""

    carrier: str | None = None
    tracking_number: str | None = None
    origin_site_id: str | None = None
    origin_address: dict | None = None
    destination_address: dict | None = None
    temperature_requirement: str | None = None
    special_instructions: str | None = None


@dataclass
class ShipmentUpdate:
    """Data for updating a shipment (creates new revision)."""

    carrier: str | None = None
    tracking_number: str | None = None
    origin_address: dict | None = None
    destination_address: dict | None = None
    received_by: str | None = None
    package_condition: str | None = None
    temperature_requirement: str | None = None
    special_instructions: str | None = None
    note: str | None = None


@dataclass
class TestKitCreate:
    """Data for creating a test kit."""

    kit_barcode: str | None = None
    kit_type: str | None = None
    origin_site_id: str | None = None
    expiration_date: datetime | None = None


class ShipmentService:
    """Service for shipment operations (pure TapDB)."""

    def __init__(self, db: Session, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self._tapdb_repo: TapdbLogisticsRepository | None = None

    def _repo(self) -> TapdbLogisticsRepository:
        if self._tapdb_repo is None:
            self._tapdb_repo = TapdbLogisticsRepository(self.db)
        return self._tapdb_repo

    def create(
        self,
        data: ShipmentCreate,
        created_by: uuid.UUID | None = None,
    ) -> tuple[TapdbShipmentRecord, TapdbShipmentRevisionRecord]:
        """Create a new shipment. Returns (shipment, revision)."""
        from app.domain.services.site_scope import resolve_tenant_site_euid

        data.origin_site_id = resolve_tenant_site_euid(self.db, self.tenant_id, data.origin_site_id)
        shipment_number = self._repo().generate_next_shipment_number()
        shipment, revision = self._repo().create_shipment(
            tenant_id=self.tenant_id,
            shipment_number=shipment_number,
            data=data,
            created_by=created_by,
        )
        self.db.commit()
        return shipment, revision

    def update(
        self,
        shipment_id: str,
        data: ShipmentUpdate,
        updated_by: uuid.UUID | None = None,
        cross_tenant: bool = False,
    ) -> tuple[TapdbShipmentRecord, TapdbShipmentRevisionRecord] | None:
        """Update a shipment by creating a new revision (append-only)."""
        shipment = self.get_by_id(shipment_id, cross_tenant=cross_tenant)
        if not shipment:
            return None
        latest = self._get_latest_revision(shipment_id)
        if not latest:
            return None
        revision = self._repo().create_shipment_revision(
            shipment_id=shipment_id,
            status=latest.status,
            carrier=data.carrier if data.carrier is not None else latest.carrier,
            tracking_number=data.tracking_number
            if data.tracking_number is not None
            else latest.tracking_number,
            origin_site_id=latest.origin_site_id,
            origin_address=data.origin_address
            if data.origin_address is not None
            else latest.origin_address,
            destination_address=data.destination_address
            if data.destination_address is not None
            else latest.destination_address,
            shipped_at=latest.shipped_at,
            delivered_at=latest.delivered_at,
            received_at=latest.received_at,
            received_by=data.received_by if data.received_by is not None else latest.received_by,
            package_condition=(
                data.package_condition
                if data.package_condition is not None
                else latest.package_condition
            ),
            temperature_requirement=data.temperature_requirement
            if data.temperature_requirement is not None
            else latest.temperature_requirement,
            special_instructions=data.special_instructions
            if data.special_instructions is not None
            else latest.special_instructions,
            note=data.note,
            created_by=updated_by,
        )
        if revision is None:
            return None
        self.db.commit()
        return (shipment, revision)

    def get_by_id(self, shipment_id: str, cross_tenant: bool = False) -> TapdbShipmentRecord | None:
        """Get shipment by EUID."""
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().get_shipment_by_id(shipment_id=shipment_id, tenant_id=tenant_scope)

    def get(
        self, shipment_id: str, cross_tenant: bool = False
    ) -> tuple[TapdbShipmentRecord, TapdbShipmentRevisionRecord | None] | None:
        """Get shipment with latest revision."""
        shipment = self.get_by_id(shipment_id, cross_tenant=cross_tenant)
        if not shipment:
            return None
        revision = self._get_latest_revision(shipment_id)
        return (shipment, revision)

    def list_shipments(
        self,
        skip: int = 0,
        limit: int = 50,
        cross_tenant: bool = False,
    ) -> list[tuple[TapdbShipmentRecord, TapdbShipmentRevisionRecord | None]]:
        """List shipments with their latest revisions."""
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().list_shipments(tenant_id=tenant_scope, skip=skip, limit=limit)

    def get_by_tracking_number(
        self, tracking_number: str, cross_tenant: bool = False
    ) -> TapdbShipmentRecord | None:
        """Get shipment by tracking number."""
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().get_shipment_by_tracking_number(
            tracking_number=tracking_number, tenant_id=tenant_scope
        )

    def get_by_shipment_number(
        self, shipment_number: str, cross_tenant: bool = False
    ) -> tuple[TapdbShipmentRecord, TapdbShipmentRevisionRecord] | None:
        """Get shipment by shipment_number with latest revision."""
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().get_shipment_by_number(
            shipment_number=shipment_number, tenant_id=tenant_scope
        )

    def add_item(
        self,
        shipment_id: str,
        item_type: str,
        item_id: str,
        reason: str | None = None,
        created_by: uuid.UUID | None = None,
    ) -> bool:
        """Add an item to a shipment (TestKit or nested Shipment)."""
        result = self._repo().add_item_to_container(
            container_type="Shipment",
            container_id=shipment_id,
            item_type=item_type,
            item_id=item_id,
            reason=reason,
            created_by=created_by,
        )
        self.db.commit()
        return result

    def add_content(
        self,
        shipment_id: str,
        item_type: str,
        item_id: str,
        reason: str | None = None,
        created_by: uuid.UUID | None = None,
    ) -> bool:
        """Add an item to a shipment. Alias for add_item()."""
        return self.add_item(shipment_id, item_type, item_id, reason, created_by)

    def remove_item(
        self,
        shipment_id: str,
        item_type: str,
        item_id: str,
        reason: str | None = None,
        created_by: uuid.UUID | None = None,
    ) -> bool:
        """Remove an item from a shipment."""
        result = self._repo().remove_item_from_container(
            container_type="Shipment",
            container_id=shipment_id,
            item_type=item_type,
            item_id=item_id,
            reason=reason,
            created_by=created_by,
        )
        self.db.commit()
        return result

    def remove_content(
        self,
        shipment_id: str,
        item_type: str,
        item_id: str,
        reason: str | None = None,
        created_by: uuid.UUID | None = None,
    ) -> bool:
        """Remove an item from a shipment. Alias for remove_item()."""
        return self.remove_item(shipment_id, item_type, item_id, reason, created_by)

    def get_contents(self, shipment_id: str) -> list[dict]:
        """Get current contents of a shipment."""
        return self._repo().list_container_contents(
            container_type="Shipment", container_id=shipment_id
        )

    def get_containment_tree(self, shipment_id: str) -> dict:
        """Get hierarchical containment tree for a shipment."""
        return self._repo().get_shipment_containment_tree(shipment_id)

    def add_container_item(
        self,
        *,
        container_type: str,
        container_id: str,
        item_type: str,
        item_id: str,
        reason: str | None = None,
        created_by: uuid.UUID | None = None,
    ) -> bool:
        result = self._repo().add_item_to_container(
            container_type=container_type,
            container_id=container_id,
            item_type=item_type,
            item_id=item_id,
            reason=reason,
            created_by=created_by,
        )
        self.db.commit()
        return result

    def list_container_contents(self, *, container_type: str, container_id: str) -> list[dict]:
        return self._repo().list_container_contents(
            container_type=container_type,
            container_id=container_id,
        )

    def get_container_tree(self, *, container_type: str, container_id: str) -> dict:
        return self._repo().get_container_tree(
            container_type=container_type, container_id=container_id
        )

    def change_status(
        self,
        shipment_id: str,
        new_status: ShipmentStatus,
        reason: str | None = None,
        updated_by: uuid.UUID | None = None,
        cross_tenant: bool = False,
        received_by: str | None = None,
        package_condition: str | None = None,
    ) -> TapdbShipmentRecord | None:
        """Change shipment status."""
        shipment = self.get_by_id(shipment_id, cross_tenant=cross_tenant)
        if not shipment:
            return None
        latest = self._get_latest_revision(shipment_id)
        if not latest:
            return None
        if (
            latest.status == new_status.value
            and (received_by is None or received_by == latest.received_by)
            and (package_condition is None or package_condition == latest.package_condition)
        ):
            return shipment
        shipped_at = (
            datetime.now(UTC) if new_status == ShipmentStatus.IN_TRANSIT else latest.shipped_at
        )
        delivered_at = (
            datetime.now(UTC) if new_status == ShipmentStatus.DELIVERED else latest.delivered_at
        )
        received_at = (
            datetime.now(UTC) if new_status == ShipmentStatus.RECEIVED else latest.received_at
        )
        revision = self._repo().create_shipment_revision(
            shipment_id=shipment_id,
            status=new_status.value,
            carrier=latest.carrier,
            tracking_number=latest.tracking_number,
            origin_site_id=latest.origin_site_id,
            origin_address=latest.origin_address,
            destination_address=latest.destination_address,
            shipped_at=shipped_at,
            delivered_at=delivered_at,
            received_at=received_at,
            received_by=received_by if received_by is not None else latest.received_by,
            package_condition=(
                package_condition if package_condition is not None else latest.package_condition
            ),
            temperature_requirement=latest.temperature_requirement,
            special_instructions=latest.special_instructions,
            note=reason,
            created_by=updated_by,
        )
        if revision is None:
            return None
        self.db.commit()
        return shipment

    def record_receipt(
        self,
        shipment_id: str,
        *,
        received_by: str | None = None,
        package_condition: str | None = None,
        note: str | None = None,
        updated_by: uuid.UUID | None = None,
        cross_tenant: bool = False,
    ) -> tuple[TapdbShipmentRecord, TapdbShipmentRevisionRecord | None] | None:
        shipment = self.get_by_id(shipment_id, cross_tenant=cross_tenant)
        if shipment is None:
            return None
        latest = self._get_latest_revision(shipment_id)
        if latest is None:
            return None
        if (
            latest.status == ShipmentStatus.RECEIVED.value
            and (received_by is None or received_by == latest.received_by)
            and (package_condition is None or package_condition == latest.package_condition)
        ):
            return shipment, latest
        revision = self._repo().create_shipment_revision(
            shipment_id=shipment_id,
            status=ShipmentStatus.RECEIVED.value,
            carrier=latest.carrier,
            tracking_number=latest.tracking_number,
            origin_site_id=latest.origin_site_id,
            origin_address=latest.origin_address,
            destination_address=latest.destination_address,
            shipped_at=latest.shipped_at,
            delivered_at=latest.delivered_at,
            received_at=latest.received_at or datetime.now(UTC),
            received_by=received_by if received_by is not None else latest.received_by,
            package_condition=(
                package_condition if package_condition is not None else latest.package_condition
            ),
            temperature_requirement=latest.temperature_requirement,
            special_instructions=latest.special_instructions,
            note=note,
            created_by=updated_by,
        )
        if revision is None:
            return None
        self.db.commit()
        return shipment, revision

    def _get_latest_revision(self, shipment_id: str) -> TapdbShipmentRevisionRecord | None:
        """Get latest revision for a shipment."""
        return self._repo().get_latest_shipment_revision(shipment_id)


class TestKitService:
    """Service for test kit operations (pure TapDB)."""

    def __init__(self, db: Session, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self._tapdb_repo: TapdbLogisticsRepository | None = None

    def _repo(self) -> TapdbLogisticsRepository:
        if self._tapdb_repo is None:
            self._tapdb_repo = TapdbLogisticsRepository(self.db)
        return self._tapdb_repo

    def create(
        self,
        data: TestKitCreate,
        created_by: uuid.UUID | None = None,
    ) -> TapdbTestKitRecord:
        """Create a new test kit."""
        from app.domain.services.site_scope import resolve_tenant_site_euid

        data.origin_site_id = resolve_tenant_site_euid(self.db, self.tenant_id, data.origin_site_id)
        test_kit = self._repo().create_test_kit(
            tenant_id=self.tenant_id,
            data=data,
            created_by=created_by,
        )
        self.db.commit()
        return test_kit

    def get_by_id(self, test_kit_id: str, cross_tenant: bool = False) -> TapdbTestKitRecord | None:
        """Get test kit by EUID."""
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().get_test_kit_by_id(test_kit_id=test_kit_id, tenant_id=tenant_scope)

    def get_by_barcode(self, barcode: str, cross_tenant: bool = False) -> TapdbTestKitRecord | None:
        """Get test kit by barcode."""
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().get_test_kit_by_barcode(barcode=barcode, tenant_id=tenant_scope)

    def get_or_create_by_barcode(
        self,
        *,
        kit_barcode: str,
        kit_type: str | None = None,
        origin_site_id: str | None = None,
        created_by: uuid.UUID | None = None,
        cross_tenant: bool = False,
    ) -> tuple[TapdbTestKitRecord, bool]:
        """Get an existing TestKit by barcode or create it.

        Returns:
            (test_kit, created) where created=True if a new kit was created.
        """
        normalized = (kit_barcode or "").strip()
        if not normalized:
            raise ValueError("kit_barcode is required")
        existing = self.get_by_barcode(normalized, cross_tenant=cross_tenant)
        if existing is not None:
            return existing, False
        created_kit = self.create(
            TestKitCreate(
                kit_barcode=normalized,
                kit_type=kit_type,
                origin_site_id=origin_site_id,
            ),
            created_by=created_by,
        )
        return created_kit, True

    def list_kits(
        self,
        skip: int = 0,
        limit: int = 50,
        cross_tenant: bool = False,
    ) -> list[TapdbTestKitRecord]:
        """List test kits."""
        tenant_scope = None if cross_tenant else self.tenant_id
        return self._repo().list_test_kits(tenant_id=tenant_scope, skip=skip, limit=limit)

    def get_with_revision(
        self, test_kit_id: str, cross_tenant: bool = False
    ) -> tuple[TapdbTestKitRecord, TapdbTestKitRevisionRecord] | None:
        """Get test kit by EUID with its latest revision."""
        kit = self.get_by_id(test_kit_id, cross_tenant=cross_tenant)
        if not kit:
            return None
        revision = self._get_latest_revision(test_kit_id)
        if not revision:
            return None
        return kit, revision

    def _get_latest_revision(self, test_kit_id: str) -> TapdbTestKitRevisionRecord | None:
        """Get the latest revision for a test kit."""
        return self._repo().get_latest_test_kit_revision(test_kit_id)

    def get_contents(self, test_kit_id: str) -> list[dict]:
        """Get current contents of a test kit."""
        return self._repo().list_container_contents(
            container_type="TestKit", container_id=test_kit_id
        )

    def add_item(
        self,
        test_kit_id: str,
        item_type: str,
        item_id: str,
        reason: str | None = None,
        created_by: uuid.UUID | None = None,
    ) -> bool:
        result = self._repo().add_item_to_container(
            container_type="TestKit",
            container_id=test_kit_id,
            item_type=item_type,
            item_id=item_id,
            reason=reason,
            created_by=created_by,
        )
        self.db.commit()
        return result

    def get_containment_tree(self, test_kit_id: str) -> dict:
        return self._repo().get_container_tree(container_type="TestKit", container_id=test_kit_id)

    def mark_received(
        self,
        test_kit_id: str,
        reason: str | None = None,
        updated_by: uuid.UUID | None = None,
        cross_tenant: bool = False,
    ) -> tuple[TapdbTestKitRecord, TapdbTestKitRevisionRecord] | None:
        """Mark a test kit as RECEIVED (idempotent)."""
        kit = self.get_by_id(test_kit_id, cross_tenant=cross_tenant)
        if not kit:
            return None
        latest = self._get_latest_revision(test_kit_id)
        if not latest:
            return None
        if latest.status == TestKitStatus.RECEIVED.value:
            return (kit, latest)
        revision = self._repo().create_test_kit_revision(
            test_kit_id=test_kit_id,
            kit_type=latest.kit_type,
            status=TestKitStatus.RECEIVED.value,
            origin_site_id=latest.origin_site_id,
            expiration_date=latest.expiration_date,
            note=reason,
            created_by=updated_by,
        )
        if revision is None:
            return None
        self.db.flush()
        return (kit, revision)
