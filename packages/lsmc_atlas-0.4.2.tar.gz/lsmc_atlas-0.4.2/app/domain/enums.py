"""Domain enums decoupled from legacy ORM models.

These enums are the canonical runtime constants for Atlas services/routes.
"""

from enum import StrEnum


class LinkAction(StrEnum):
    LINK = "LINK"
    UNLINK = "UNLINK"


class ContainmentAction(StrEnum):
    ADD = "ADD"
    REMOVE = "REMOVE"


class AuditAction(StrEnum):
    VIEW = "VIEW"
    DOWNLOAD = "DOWNLOAD"
    CREATE = "CREATE"
    UPDATE = "UPDATE"
    STATUS_CHANGE = "STATUS_CHANGE"
    LINK = "LINK"
    UNLINK = "UNLINK"
    PERMISSION_CHANGE = "PERMISSION_CHANGE"
    LOGIN = "LOGIN"
    LOGOUT = "LOGOUT"
    INVITE_USER = "INVITE_USER"
    DOCS_ACCESS = "DOCS_ACCESS"


class AccessScope(StrEnum):
    TENANT = "TENANT"
    CROSS_TENANT = "CROSS_TENANT"
    SYSTEM = "SYSTEM"


class SystemGroup(StrEnum):
    CUSTOMER = "CUSTOMER"
    LSMC_STAFF = "LSMC_STAFF"
    ADMIN = "ADMIN"
    API_ACCESS = "API_ACCESS"


class OrderStatus(StrEnum):
    DRAFT = "DRAFT"
    ORDERED = "ORDERED"
    IN_PROGRESS = "IN_PROGRESS"
    QC_HOLD = "QC_HOLD"
    RESULTS_READY = "RESULTS_READY"
    CLOSED_NO_RESULTS = "CLOSED_NO_RESULTS"
    SUBMITTED = "SUBMITTED"
    ABANDONED = "ABANDONED"
    RECEIVING_IN_PROGRESS = "RECEIVING_IN_PROGRESS"
    ON_HOLD = "ON_HOLD"
    ACTIVE = "ACTIVE"
    COMPLETED_REPORT_READY = "COMPLETED_REPORT_READY"
    RELEASED = "RELEASED"
    AMENDED = "AMENDED"
    CANCELED = "CANCELED"
    REJECTED = "REJECTED"


class OrderType(StrEnum):
    RESEARCH = "RESEARCH"
    CLINICAL = "CLINICAL"
    OTHER = "OTHER"


class TestOrderStatus(StrEnum):
    PENDING = "PENDING"
    SPECIMEN_RECEIVED = "SPECIMEN_RECEIVED"
    IN_PROGRESS = "IN_PROGRESS"
    FAILED = "FAILED"
    ON_HOLD = "ON_HOLD"
    COMPLETED = "COMPLETED"
    CANCELED = "CANCELED"
    REJECTED = "REJECTED"


class OrderPatientRole(StrEnum):
    PROBAND = "PROBAND"
    FATHER = "FATHER"
    MOTHER = "MOTHER"
    SIBLING = "SIBLING"
    OTHER = "OTHER"


class FulfillmentRunState(StrEnum):
    DRAFT = "DRAFT"
    ORDERED = "ORDERED"
    RECEIVED = "RECEIVED"
    ACCESSIONED = "ACCESSIONED"
    IN_PROGRESS = "IN_PROGRESS"
    QC_HOLD = "QC_HOLD"
    FAILED = "FAILED"
    RESULTED = "RESULTED"
    AMENDED = "AMENDED"
    CANCELLED = "CANCELLED"


class ShipmentStatus(StrEnum):
    DRAFT = "DRAFT"
    READY_TO_SHIP = "READY_TO_SHIP"
    IN_TRANSIT = "IN_TRANSIT"
    DELIVERED = "DELIVERED"
    RECEIVED = "RECEIVED"
    CANCELED = "CANCELED"


class TestKitStatus(StrEnum):
    CREATED = "CREATED"
    RECEIVED = "RECEIVED"


class AccessionQueue(StrEnum):
    RECEIPT_PENDING = "RECEIPT_PENDING"
    PACKAGE_PROCESSING_PENDING = "PACKAGE_PROCESSING_PENDING"
    MATCHING_PENDING = "MATCHING_PENDING"
    HOLD_INVESTIGATE = "HOLD_INVESTIGATE"
    COMPLETED = "COMPLETED"


class AccessionStageStatus(StrEnum):
    REGISTERED_UNMATCHED = "REGISTERED_UNMATCHED"
    REGISTERED_MATCHED = "REGISTERED_MATCHED"
    ACCEPTED = "ACCEPTED"
    HOLD = "HOLD"
    REJECTED = "REJECTED"


class ReleasePackageStatus(StrEnum):
    DRAFT = "DRAFT"
    PENDING_REVIEW = "PENDING_REVIEW"
    APPROVED = "APPROVED"
    RELEASED = "RELEASED"
    REVOKED = "REVOKED"


class ExceptionType(StrEnum):
    MISSING_ID = "MISSING_ID"
    NO_MATCH = "NO_MATCH"
    AMBIGUOUS_MATCH = "AMBIGUOUS_MATCH"
    MISMATCH = "MISMATCH"
    MISSING_DATA = "MISSING_DATA"
    RECEIVED_NO_ORDER = "RECEIVED_NO_ORDER"
    DAMAGED_SPECIMEN = "DAMAGED_SPECIMEN"
    WRONG_SPECIMEN_TYPE = "WRONG_SPECIMEN_TYPE"
    MIA = "MIA"
    OTHER = "OTHER"


class ExceptionStatus(StrEnum):
    OPEN = "OPEN"
    ASSIGNED = "ASSIGNED"
    IN_PROGRESS = "IN_PROGRESS"
    RESOLVED = "RESOLVED"
    ESCALATED = "ESCALATED"
    CLOSED = "CLOSED"


class TokenStatus(StrEnum):
    ACTIVE = "ACTIVE"
    EXPIRED = "EXPIRED"
    REVOKED = "REVOKED"


class TokenScope(StrEnum):
    EXT_ORG = "ext_org"
    LSMC_INTERNAL = "lsmc_internal"
    ATLAS_ADMIN = "atlas_admin"


class TicketType(StrEnum):
    TECHNICAL = "TECHNICAL"
    BILLING = "BILLING"
    ORDER_ISSUE = "ORDER_ISSUE"
    SPECIMEN_ISSUE = "SPECIMEN_ISSUE"
    RESULT_INQUIRY = "RESULT_INQUIRY"
    ACCESS_REQUEST = "ACCESS_REQUEST"
    FEATURE_REQUEST = "FEATURE_REQUEST"
    OTHER = "OTHER"


class TicketPriority(StrEnum):
    LOW = "LOW"
    NORMAL = "NORMAL"
    HIGH = "HIGH"
    URGENT = "URGENT"


class TicketStatus(StrEnum):
    OPEN = "OPEN"
    ASSIGNED = "ASSIGNED"
    IN_PROGRESS = "IN_PROGRESS"
    WAITING_CUSTOMER = "WAITING_CUSTOMER"
    WAITING_INTERNAL = "WAITING_INTERNAL"
    RESOLVED = "RESOLVED"
    CLOSED = "CLOSED"


class WebhookEventType(StrEnum):
    ORDER_STATUS_CHANGED = "order.status.changed"
    ORDER_CREATED = "order.created"
    ARTIFACT_AVAILABLE = "artifact.available"
    RELEASE_PACKAGE_CREATED = "release.package.created"
    RELEASE_PACKAGE_RELEASED = "release.package.released"
    EXCEPTION_CREATED = "exception.created"
    EXCEPTION_RESOLVED = "exception.resolved"
    EXTERNAL_OBJECT_STATUS_CHANGED = "external_object.status.changed"
    EXTERNAL_OBJECT_DELETED = "external_object.deleted"
    ASSAY_RUN_STATUS_CHANGED = "fulfillment_run.status.changed"
    RESULTS_SET_PUBLISHED = "results_set.published"
