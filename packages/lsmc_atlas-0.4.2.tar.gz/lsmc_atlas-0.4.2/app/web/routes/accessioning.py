"""Atlas accessioning workbench web routes."""

from __future__ import annotations

import logging
import uuid
from datetime import datetime
from typing import Annotated

from fastapi import (
    APIRouter,
    Depends,
    File,
    Form,
    HTTPException,
    Query,
    Request,
    UploadFile,
    status,
)
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser, require_internal, require_read_write_web
from app.auth.middleware import csrf_protect
from app.db.engine import get_db
from app.domain.enums import AccessionQueue, AccessionStageStatus
from app.domain.services.accessioning_workbench import (
    AccessioningWorkbenchService,
    CaptureReadyForReviewRequest,
    ContentRegistrationRequest,
    LinkRequest,
    MinimalChildRegistrationRequest,
    OutcomeRequest,
    ProvisionalOrderRequest,
    ProvisionalPatientInput,
    ReceiptRegistrationRequest,
)
from app.domain.services.people import PatientService
from app.domain.services.site_scope import list_tenant_site_options
from app.domain.services.trfs import TestService, TrfService
from app.web.flash import flash
from app.web.routes.pages import get_template_context
from app.web.templates import templates

logger = logging.getLogger(__name__)

router = APIRouter(tags=["accessioning"])

QUEUE_LABELS = {
    AccessionQueue.RECEIPT_PENDING.value: "Receipt Queue",
    AccessionQueue.PACKAGE_PROCESSING_PENDING.value: "Package Processing Queue",
    AccessionQueue.MATCHING_PENDING.value: "Matching / Linking Queue",
    AccessionQueue.HOLD_INVESTIGATE.value: "Holds / Exceptions Queue",
}

QUEUE_DESCRIPTIONS = {
    AccessionQueue.RECEIPT_PENDING.value: "Inbound shipments not yet registered as received.",
    AccessionQueue.PACKAGE_PROCESSING_PENDING.value: "Received packages awaiting content registration.",
    AccessionQueue.MATCHING_PENDING.value: "Packages that need order context or linkage to TRF.test.",
    AccessionQueue.HOLD_INVESTIGATE.value: "Held or exception work requiring manual follow-up.",
}

QUEUE_ORDER = [
    AccessionQueue.RECEIPT_PENDING.value,
    AccessionQueue.PACKAGE_PROCESSING_PENDING.value,
    AccessionQueue.MATCHING_PENDING.value,
    AccessionQueue.HOLD_INVESTIGATE.value,
]

STARTING_QUEUES = ["extraction_prod", "extraction_rnd"]


def _service(db: Session, current_user: CurrentUser) -> AccessioningWorkbenchService:
    return AccessioningWorkbenchService(db, current_user.tenant_id)


def _safe_mode(mode: str | None) -> str:
    return "combined" if str(mode or "").strip().lower() == "combined" else "queue"


def _work_item_url(work_item_id: str, mode: str) -> str:
    return f"/accessioning/work-items/{work_item_id}?mode={mode}"


def _minimal_work_item_url(work_item_id: str) -> str:
    return f"/accessioning/minimal/work-items/{work_item_id}"


def _parse_optional_datetime(value: str | None) -> datetime | None:
    clean = str(value or "").strip()
    if not clean:
        return None
    try:
        return datetime.fromisoformat(clean)
    except ValueError:
        return None


def _parse_role_lines(raw: str | None) -> list[tuple[str, str]]:
    rows: list[tuple[str, str]] = []
    for line in str(raw or "").splitlines():
        clean = line.strip()
        if not clean or ":" not in clean:
            continue
        patient_euid, role = clean.split(":", 1)
        patient_euid = patient_euid.strip()
        role = role.strip().upper()
        if patient_euid and role:
            rows.append((patient_euid, role))
    return rows


def _build_patient_input(
    *,
    role: str,
    patient_euid: str | None,
    first_name: str | None,
    last_name: str | None,
    date_of_birth: str | None,
    mrn: str | None,
) -> ProvisionalPatientInput | None:
    if not any(
        [
            str(patient_euid or "").strip(),
            str(first_name or "").strip(),
            str(last_name or "").strip(),
            str(date_of_birth or "").strip(),
            str(mrn or "").strip(),
        ]
    ):
        return None
    return ProvisionalPatientInput(
        role=role,
        patient_euid=str(patient_euid or "").strip() or None,
        first_name=str(first_name or "").strip() or None,
        last_name=str(last_name or "").strip() or None,
        date_of_birth=str(date_of_birth or "").strip() or None,
        mrn=str(mrn or "").strip() or None,
    )


def _template_context(
    request: Request,
    current_user: CurrentUser,
    db: Session,
) -> dict:
    ctx = get_template_context(request, current_user, db)
    ctx["active_nav"] = "lsmc"
    ctx["queue_labels"] = QUEUE_LABELS
    ctx["queue_descriptions"] = QUEUE_DESCRIPTIONS
    ctx["queue_order"] = QUEUE_ORDER
    ctx["starting_queues"] = STARTING_QUEUES
    return ctx


def _site_options(db: Session, current_user: CurrentUser) -> list:
    return list_tenant_site_options(db, current_user.tenant_id, active_only=True)


def _patient_options(db: Session, current_user: CurrentUser) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for patient, revision in PatientService(db, current_user.tenant_id).list_patients(limit=100):
        rows.append(
            {
                "id": patient.euid,
                "label": f"{revision.first_name} {revision.last_name}".strip() or patient.euid,
                "mrn": revision.mrn or "",
            }
        )
    return rows


def _test_options(db: Session, current_user: CurrentUser) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    trf_service = TrfService(db, current_user.tenant_id)
    test_service = TestService(db, current_user.tenant_id)
    for trf, _revision in trf_service.list_trfs(limit=50):
        for test, test_revision, _routes in test_service.list_for_trf(trf.euid):
            rows.append(
                {
                    "test_euid": test.euid,
                    "trf_euid": trf.euid,
                    "label": f"{test.euid} | {test_revision.product_code or 'TEST'} | {trf.order_number}",
                }
            )
    return rows


def _find_minimal_node(root_node: dict[str, object], node_id: str) -> dict[str, object] | None:
    stack = [root_node]
    while stack:
        current = stack.pop()
        if str(current.get("node_id")) == str(node_id):
            return current
        for child in reversed(list(current.get("children", []) or [])):
            if isinstance(child, dict):
                stack.append(child)
    return None


def _minimal_editor_context(
    request: Request,
    current_user: CurrentUser,
    db: Session,
    *,
    work_item_id: str,
) -> dict:
    ctx = _template_context(request, current_user, db)
    detail = _service(db, current_user).get_minimal_editor(work_item_id)
    ctx.update(
        {
            "detail": detail,
            "site_options": _site_options(db, current_user),
            "standard_review_url": _work_item_url(work_item_id, "queue"),
        }
    )
    return ctx


@router.get("/accessioning", response_class=HTMLResponse, dependencies=[Depends(require_internal)])
async def accessioning_dashboard(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_internal)],
    db: Session = Depends(get_db),
    mode: str = Query("queue"),
):
    safe_mode = _safe_mode(mode)
    ctx = _template_context(request, current_user, db)
    dashboard = _service(db, current_user).dashboard(mode=safe_mode)
    ctx.update(
        {
            "mode": safe_mode,
            "dashboard": dashboard,
            "receipt_items": dashboard["receipt_items"],
            "package_items": dashboard["package_items"],
            "matching_items": dashboard["matching_items"],
            "hold_items": dashboard["hold_items"],
            "site_options": _site_options(db, current_user),
        }
    )
    return templates.TemplateResponse("accessioning/index.html", ctx)


@router.get(
    "/accessioning/queues/{queue_name}",
    response_class=HTMLResponse,
    dependencies=[Depends(require_internal)],
)
async def accessioning_queue_partial(
    request: Request,
    queue_name: str,
    current_user: Annotated[CurrentUser, Depends(require_internal)],
    db: Session = Depends(get_db),
    mode: str = Query("queue"),
):
    if queue_name not in QUEUE_LABELS:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Queue not found")
    items = _service(db, current_user).list_queue(queue_name, limit=25)
    ctx = {
        "request": request,
        "queue_name": queue_name,
        "queue_title": QUEUE_LABELS[queue_name],
        "queue_description": QUEUE_DESCRIPTIONS[queue_name],
        "items": items,
        "mode": _safe_mode(mode),
    }
    return templates.TemplateResponse("accessioning/_queue_list.html", ctx)


@router.post(
    "/accessioning/receipt",
    dependencies=[
        Depends(require_internal),
        Depends(require_read_write_web),
        Depends(csrf_protect),
    ],
)
async def accessioning_register_receipt(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_internal)],
    db: Session = Depends(get_db),
    mode: str = Form("queue"),
    tracking_number: str | None = Form(None),
    carrier: str | None = Form(None),
    received_at: str | None = Form(None),
    received_by: str | None = Form(None),
    origin_site_id: str | None = Form(None),
    notes: str | None = Form(None),
    package_condition: str | None = Form(None),
    hand_delivery: str | None = Form(None),
):
    safe_mode = _safe_mode(mode)
    svc = _service(db, current_user)
    try:
        item, _revision = svc.register_receipt(
            ReceiptRegistrationRequest(
                tracking_number=tracking_number,
                carrier=carrier,
                received_at=_parse_optional_datetime(received_at),
                received_by=received_by,
                origin_site_id=origin_site_id,
                notes=notes,
                package_condition=package_condition,
                hand_delivery=str(hand_delivery or "").lower() in {"1", "true", "on", "yes"},
                mode=safe_mode,
            ),
            actor_id=current_user.sub_uuid,
        )
    except ValueError as exc:
        flash(request, str(exc), "error")
        return RedirectResponse(
            url=f"/accessioning?mode={safe_mode}", status_code=status.HTTP_303_SEE_OTHER
        )
    flash(request, "Receipt registered in accessioning workbench.", "success")
    return RedirectResponse(
        url=_work_item_url(item.euid, safe_mode),
        status_code=status.HTTP_303_SEE_OTHER,
    )


@router.get(
    "/accessioning/minimal", response_class=HTMLResponse, dependencies=[Depends(require_internal)]
)
async def accessioning_minimal_dashboard(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_internal)],
    db: Session = Depends(get_db),
):
    ctx = _template_context(request, current_user, db)
    ctx.update({"site_options": _site_options(db, current_user)})
    return templates.TemplateResponse("accessioning/minimal_index.html", ctx)


@router.post(
    "/accessioning/minimal/receipt",
    dependencies=[
        Depends(require_internal),
        Depends(require_read_write_web),
        Depends(csrf_protect),
    ],
)
async def accessioning_minimal_register_receipt(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_internal)],
    db: Session = Depends(get_db),
    tracking_number: str | None = Form(None),
    carrier: str | None = Form(None),
    received_at: str | None = Form(None),
    received_by: str | None = Form(None),
    origin_site_id: str | None = Form(None),
    notes: str | None = Form(None),
    package_condition: str | None = Form(None),
    hand_delivery: str | None = Form(None),
):
    svc = _service(db, current_user)
    try:
        item, _revision = svc.register_receipt(
            ReceiptRegistrationRequest(
                tracking_number=tracking_number,
                carrier=carrier,
                received_at=_parse_optional_datetime(received_at),
                received_by=received_by,
                origin_site_id=origin_site_id,
                notes=notes,
                package_condition=package_condition,
                hand_delivery=str(hand_delivery or "").lower() in {"1", "true", "on", "yes"},
                mode="queue",
            ),
            actor_id=current_user.sub_uuid,
        )
    except ValueError as exc:
        flash(request, str(exc), "error")
        return RedirectResponse(
            url="/accessioning/minimal",
            status_code=status.HTTP_303_SEE_OTHER,
        )
    flash(request, "Receipt registered in minimal accessioning.", "success")
    return RedirectResponse(
        url=_minimal_work_item_url(item.euid),
        status_code=status.HTTP_303_SEE_OTHER,
    )


@router.get(
    "/accessioning/minimal/work-items/{work_item_id}",
    response_class=HTMLResponse,
    dependencies=[Depends(require_internal)],
)
async def accessioning_minimal_work_item(
    request: Request,
    work_item_id: str,
    current_user: Annotated[CurrentUser, Depends(require_internal)],
    db: Session = Depends(get_db),
):
    try:
        ctx = _minimal_editor_context(
            request,
            current_user,
            db,
            work_item_id=work_item_id,
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
    return templates.TemplateResponse("accessioning/minimal_work_item.html", ctx)


@router.get(
    "/accessioning/minimal/work-items/{work_item_id}/nodes/{node_id}",
    response_class=HTMLResponse,
    dependencies=[Depends(require_internal)],
)
async def accessioning_minimal_node_partial(
    request: Request,
    work_item_id: str,
    node_id: str,
    current_user: Annotated[CurrentUser, Depends(require_internal)],
    db: Session = Depends(get_db),
):
    try:
        ctx = _minimal_editor_context(
            request,
            current_user,
            db,
            work_item_id=work_item_id,
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
    node = _find_minimal_node(ctx["detail"]["root_node"], node_id)
    if node is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Node not found")
    ctx.update({"node": node, "work_item_id": work_item_id})
    return templates.TemplateResponse("accessioning/_minimal_node.html", ctx)


@router.get(
    "/accessioning/minimal/work-items/{work_item_id}/nodes/{node_id}/composer",
    response_class=HTMLResponse,
    dependencies=[Depends(require_internal)],
)
async def accessioning_minimal_composer(
    request: Request,
    work_item_id: str,
    node_id: str,
    current_user: Annotated[CurrentUser, Depends(require_internal)],
    db: Session = Depends(get_db),
    kind: str = Query(...),
):
    try:
        ctx = _minimal_editor_context(
            request,
            current_user,
            db,
            work_item_id=work_item_id,
        )
        normalized_kind = _service(db, current_user)._normalize_minimal_kind(kind)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
    parent_node = _find_minimal_node(ctx["detail"]["root_node"], node_id)
    if parent_node is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Node not found")
    ctx.update(
        {
            "parent_node": parent_node,
            "work_item_id": work_item_id,
            "kind": normalized_kind,
            "kind_label": _service(db, current_user)._minimal_kind_label(normalized_kind),
            "error_message": None,
        }
    )
    return templates.TemplateResponse("accessioning/_minimal_composer.html", ctx)


@router.post(
    "/accessioning/minimal/work-items/{work_item_id}/nodes/{node_id}/children",
    response_class=HTMLResponse,
    dependencies=[
        Depends(require_internal),
        Depends(require_read_write_web),
        Depends(csrf_protect),
    ],
)
async def accessioning_minimal_create_child(
    request: Request,
    work_item_id: str,
    node_id: str,
    current_user: Annotated[CurrentUser, Depends(require_internal)],
    db: Session = Depends(get_db),
    kind: str = Form(...),
    scan_value: str | None = Form(None),
    label: str | None = Form(None),
    notes: str | None = Form(None),
    kit_type: str | None = Form(None),
    tracking_number: str | None = Form(None),
    carrier: str | None = Form(None),
    origin_site_id: str | None = Form(None),
    document_type: str | None = Form(None),
    site_euid: str | None = Form(None),
    collection_site_euid: str | None = Form(None),
    route_code: str | None = Form(None),
    product_code: str | None = Form(None),
    specimen_type_required: str | None = Form(None),
    existing_euid: str | None = Form(None),
):
    svc = _service(db, current_user)
    try:
        svc.register_minimal_child(
            work_item_id,
            MinimalChildRegistrationRequest(
                kind=kind,
                parent_node_id=node_id,
                scan_value=scan_value,
                label=label,
                notes=notes,
                kit_type=kit_type,
                tracking_number=tracking_number,
                carrier=carrier,
                origin_site_id=origin_site_id,
                document_type=document_type,
                site_euid=site_euid,
                collection_site_euid=collection_site_euid,
                route_code=route_code,
                product_code=product_code,
                specimen_type_required=specimen_type_required,
                existing_euid=existing_euid,
            ),
            actor_id=current_user.sub_uuid,
        )
        ctx = _minimal_editor_context(
            request,
            current_user,
            db,
            work_item_id=work_item_id,
        )
        ctx.update({"work_item_id": work_item_id})
        return templates.TemplateResponse("accessioning/_minimal_editor.html", ctx)
    except ValueError as exc:
        ctx = _minimal_editor_context(
            request,
            current_user,
            db,
            work_item_id=work_item_id,
        )
        parent_node = _find_minimal_node(ctx["detail"]["root_node"], node_id)
        if parent_node is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Node not found"
            ) from exc
        normalized_kind = svc._normalize_minimal_kind(kind)
        ctx.update(
            {
                "parent_node": parent_node,
                "work_item_id": work_item_id,
                "kind": normalized_kind,
                "kind_label": svc._minimal_kind_label(normalized_kind),
                "error_message": str(exc),
            }
        )
        return templates.TemplateResponse(
            "accessioning/_minimal_composer.html",
            ctx,
            status_code=status.HTTP_400_BAD_REQUEST,
        )


@router.post(
    "/accessioning/minimal/work-items/{work_item_id}/review",
    dependencies=[
        Depends(require_internal),
        Depends(require_read_write_web),
        Depends(csrf_protect),
    ],
)
async def accessioning_minimal_send_to_review(
    request: Request,
    work_item_id: str,
    current_user: Annotated[CurrentUser, Depends(require_internal)],
    db: Session = Depends(get_db),
    note: str | None = Form(None),
):
    try:
        _service(db, current_user).mark_capture_ready_for_review(
            work_item_id,
            CaptureReadyForReviewRequest(note=note),
            actor_id=current_user.sub_uuid,
        )
    except ValueError as exc:
        flash(request, str(exc), "error")
        return RedirectResponse(
            url=_minimal_work_item_url(work_item_id),
            status_code=status.HTTP_303_SEE_OTHER,
        )
    flash(request, "Capture sent to matching review.", "success")
    return RedirectResponse(
        url=_work_item_url(work_item_id, "queue"),
        status_code=status.HTTP_303_SEE_OTHER,
    )


@router.get(
    "/accessioning/work-items/{work_item_id}",
    response_class=HTMLResponse,
    dependencies=[Depends(require_internal)],
)
async def accessioning_work_item(
    request: Request,
    work_item_id: str,
    current_user: Annotated[CurrentUser, Depends(require_internal)],
    db: Session = Depends(get_db),
    mode: str = Query("queue"),
):
    try:
        detail = _service(db, current_user).get_work_item(work_item_id)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc

    ctx = _template_context(request, current_user, db)
    ctx.update(
        {
            "mode": _safe_mode(mode),
            "detail": detail,
            "site_options": _site_options(db, current_user),
            "patient_options": _patient_options(db, current_user),
            "test_options": _test_options(db, current_user),
            "content_registration_token": str(uuid.uuid4()),
        }
    )
    return templates.TemplateResponse("accessioning/work_item.html", ctx)


@router.get(
    "/accessioning/work-items/{work_item_id}/search",
    response_class=HTMLResponse,
    dependencies=[Depends(require_internal)],
)
async def accessioning_match_search(
    request: Request,
    work_item_id: str,
    current_user: Annotated[CurrentUser, Depends(require_internal)],
    db: Session = Depends(get_db),
    q: str = Query("", max_length=256),
):
    try:
        _service(db, current_user).get_work_item(work_item_id)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc

    ctx = {
        "request": request,
        "results": _service(db, current_user).search_matches(q),
    }
    return templates.TemplateResponse("accessioning/_match_results.html", ctx)


@router.post(
    "/accessioning/work-items/{work_item_id}/contents",
    dependencies=[
        Depends(require_internal),
        Depends(require_read_write_web),
        Depends(csrf_protect),
    ],
)
async def accessioning_register_content(
    request: Request,
    work_item_id: str,
    current_user: Annotated[CurrentUser, Depends(require_internal)],
    db: Session = Depends(get_db),
    mode: str = Form("queue"),
    content_type: str = Form(...),
    parent_type: str = Form("Shipment"),
    parent_id: str | None = Form(None),
    barcode: str | None = Form(None),
    label: str | None = Form(None),
    notes: str | None = Form(None),
    kit_type: str | None = Form(None),
    tracking_number: str | None = Form(None),
    carrier: str | None = Form(None),
    origin_site_id: str | None = Form(None),
    document_euid: str | None = Form(None),
    document_type: str | None = Form(None),
    site_euid: str | None = Form(None),
    collection_site_euid: str | None = Form(None),
    defer_matching: str | None = Form(None),
    label_print_requested: str | None = Form(None),
    label_print_context: str | None = Form(None),
    tube_image_metadata: str | None = Form(None),
    package_image_metadata: str | None = Form(None),
    registration_token: str | None = Form(None),
    document_file: UploadFile | None = File(None),
):
    document_bytes = await document_file.read() if document_file is not None else None
    try:
        _service(db, current_user).register_content(
            work_item_id,
            ContentRegistrationRequest(
                content_type=content_type,
                parent_type=parent_type,
                parent_id=parent_id,
                barcode=barcode,
                label=label,
                notes=notes,
                kit_type=kit_type,
                tracking_number=tracking_number,
                carrier=carrier,
                origin_site_id=origin_site_id,
                document_euid=document_euid,
                document_filename=document_file.filename if document_file is not None else None,
                document_content_type=document_file.content_type
                if document_file is not None
                else None,
                document_bytes=document_bytes,
                document_type=document_type,
                site_euid=site_euid,
                collection_site_euid=collection_site_euid,
                defer_matching=str(defer_matching or "").lower() in {"1", "true", "on", "yes"},
                label_print_requested=str(label_print_requested or "").lower()
                in {"1", "true", "on", "yes"},
                label_print_context=label_print_context,
                tube_image_metadata=tube_image_metadata,
                package_image_metadata=package_image_metadata,
                registration_token=registration_token,
            ),
            actor_id=current_user.sub_uuid,
        )
    except ValueError as exc:
        flash(request, str(exc), "error")
        return RedirectResponse(
            url=_work_item_url(work_item_id, _safe_mode(mode)),
            status_code=status.HTTP_303_SEE_OTHER,
        )
    flash(request, f"{content_type} registered.", "success")
    return RedirectResponse(
        url=_work_item_url(work_item_id, _safe_mode(mode)),
        status_code=status.HTTP_303_SEE_OTHER,
    )


@router.post(
    "/accessioning/work-items/{work_item_id}/links",
    dependencies=[
        Depends(require_internal),
        Depends(require_read_write_web),
        Depends(csrf_protect),
    ],
)
async def accessioning_link_work_item(
    request: Request,
    work_item_id: str,
    current_user: Annotated[CurrentUser, Depends(require_internal)],
    db: Session = Depends(get_db),
    mode: str = Form("queue"),
    trf_euid: str | None = Form(None),
    test_euid: str | None = Form(None),
    patient_euid: str | None = Form(None),
    collection_site_euid: str | None = Form(None),
    role_lines: str | None = Form(None),
):
    try:
        _service(db, current_user).link_work_item(
            work_item_id,
            LinkRequest(
                trf_euid=trf_euid,
                test_euid=test_euid,
                patient_euid=patient_euid,
                collection_site_euid=collection_site_euid,
                role_links=_parse_role_lines(role_lines),
            ),
            actor_id=current_user.sub_uuid,
        )
    except ValueError as exc:
        flash(request, str(exc), "error")
        return RedirectResponse(
            url=_work_item_url(work_item_id, _safe_mode(mode)),
            status_code=status.HTTP_303_SEE_OTHER,
        )
    flash(request, "Matching and linkage updated.", "success")
    return RedirectResponse(
        url=_work_item_url(work_item_id, _safe_mode(mode)),
        status_code=status.HTTP_303_SEE_OTHER,
    )


@router.post(
    "/accessioning/work-items/{work_item_id}/provisional-order",
    dependencies=[
        Depends(require_internal),
        Depends(require_read_write_web),
        Depends(csrf_protect),
    ],
)
async def accessioning_create_provisional_order(
    request: Request,
    work_item_id: str,
    current_user: Annotated[CurrentUser, Depends(require_internal)],
    db: Session = Depends(get_db),
    mode: str = Form("queue"),
    site_id: str | None = Form(None),
    fulfillment_route_code: str | None = Form(None),
    specimen_type_required: str | None = Form(None),
    clinician_euid: str | None = Form(None),
    clinician_first_name: str | None = Form(None),
    clinician_last_name: str | None = Form(None),
    clinician_credentials: str | None = Form(None),
    clinical_notes: str | None = Form(None),
    proband_patient_euid: str | None = Form(None),
    proband_first_name: str | None = Form(None),
    proband_last_name: str | None = Form(None),
    proband_date_of_birth: str | None = Form(None),
    proband_mrn: str | None = Form(None),
    mother_patient_euid: str | None = Form(None),
    mother_first_name: str | None = Form(None),
    mother_last_name: str | None = Form(None),
    mother_date_of_birth: str | None = Form(None),
    mother_mrn: str | None = Form(None),
    father_patient_euid: str | None = Form(None),
    father_first_name: str | None = Form(None),
    father_last_name: str | None = Form(None),
    father_date_of_birth: str | None = Form(None),
    father_mrn: str | None = Form(None),
):
    patients = [
        patient
        for patient in [
            _build_patient_input(
                role="PROBAND",
                patient_euid=proband_patient_euid,
                first_name=proband_first_name,
                last_name=proband_last_name,
                date_of_birth=proband_date_of_birth,
                mrn=proband_mrn,
            ),
            _build_patient_input(
                role="MOTHER",
                patient_euid=mother_patient_euid,
                first_name=mother_first_name,
                last_name=mother_last_name,
                date_of_birth=mother_date_of_birth,
                mrn=mother_mrn,
            ),
            _build_patient_input(
                role="FATHER",
                patient_euid=father_patient_euid,
                first_name=father_first_name,
                last_name=father_last_name,
                date_of_birth=father_date_of_birth,
                mrn=father_mrn,
            ),
        ]
        if patient is not None
    ]

    try:
        revision = _service(db, current_user).create_provisional_order(
            work_item_id,
            ProvisionalOrderRequest(
                site_id=str(site_id or "").strip(),
                fulfillment_route_code=str(fulfillment_route_code or "").strip(),
                specimen_type_required=specimen_type_required,
                clinician_euid=clinician_euid,
                clinician_first_name=clinician_first_name,
                clinician_last_name=clinician_last_name,
                clinician_credentials=clinician_credentials,
                clinical_notes=clinical_notes,
                patients=patients,
            ),
            actor_id=current_user.sub_uuid,
        )
    except ValueError as exc:
        flash(request, str(exc), "error")
        return RedirectResponse(
            url=_work_item_url(work_item_id, _safe_mode(mode)),
            status_code=status.HTTP_303_SEE_OTHER,
        )

    if revision.stage_status == AccessionStageStatus.HOLD.value:
        flash(request, "Insufficient context for provisional order. Item moved to HOLD.", "warning")
    else:
        flash(request, "Provisional order created and linked.", "success")
    return RedirectResponse(
        url=_work_item_url(work_item_id, _safe_mode(mode)),
        status_code=status.HTTP_303_SEE_OTHER,
    )


@router.post(
    "/accessioning/work-items/{work_item_id}/outcome",
    dependencies=[
        Depends(require_internal),
        Depends(require_read_write_web),
        Depends(csrf_protect),
    ],
)
async def accessioning_record_outcome(
    request: Request,
    work_item_id: str,
    current_user: Annotated[CurrentUser, Depends(require_internal)],
    db: Session = Depends(get_db),
    mode: str = Form("queue"),
    outcome: str = Form(...),
    patient_euid: str | None = Form(None),
    reason: str | None = Form(None),
    starting_queue: str | None = Form(None),
):
    try:
        revision = _service(db, current_user).record_outcome(
            work_item_id,
            OutcomeRequest(
                outcome=outcome,
                patient_euid=patient_euid,
                reason=reason,
                starting_queue=starting_queue,
            ),
            actor_id=current_user.sub_uuid,
        )
    except ValueError as exc:
        flash(request, str(exc), "error")
        return RedirectResponse(
            url=_work_item_url(work_item_id, _safe_mode(mode)),
            status_code=status.HTTP_303_SEE_OTHER,
        )

    if revision.stage_status == AccessionStageStatus.HOLD.value:
        flash(request, "Outcome recorded as HOLD.", "warning")
    elif revision.stage_status == AccessionStageStatus.REJECTED.value:
        flash(request, "Outcome recorded as REJECTED.", "warning")
    else:
        flash(request, "Outcome recorded and accepted material handed off.", "success")

    return RedirectResponse(
        url=_work_item_url(work_item_id, _safe_mode(mode)),
        status_code=status.HTTP_303_SEE_OTHER,
    )
