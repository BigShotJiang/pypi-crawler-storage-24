"""Web routes for the read-only graph viewer."""

from __future__ import annotations

import json
import uuid

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser, get_current_user_web
from app.auth.rbac import Permission, has_permission
from app.db.engine import get_db
from app.settings import settings
from app.web.routes.pages import get_template_context
from app.web.templates import templates

router = APIRouter(tags=["graph"])


@router.get("/graph", response_class=HTMLResponse)
async def graph_page(
    request: Request,
    current_user: CurrentUser = Depends(get_current_user_web),
    db: Session = Depends(get_db),
    start_euid: str | None = Query(None),
    depth: int = Query(
        default=settings.graph_default_depth,
        ge=1,
        le=settings.graph_max_depth,
    ),
    tenant_id: uuid.UUID | None = Query(None),
    merge_ref: int | None = Query(None, ge=0),
):
    """Render the read-only graph explorer page."""
    can_cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    requested_tenant = tenant_id or current_user.tenant_id

    if requested_tenant != current_user.tenant_id and not can_cross_tenant:
        raise HTTPException(
            status_code=403, detail="Cross-tenant graph access requires cross_tenant:read"
        )

    ctx = get_template_context(request, current_user, db)
    ctx.update(
        {
            "active_nav": "graph",
            "graph_ui_config_json": json.dumps(
                {
                    "graphPath": "/api/graph/data",
                    "graphPagePath": "/graph",
                    "objectPathTemplate": "/api/graph/object/{euid}",
                    "externalGraphPath": "/api/graph/external",
                    "externalObjectPath": "/api/graph/external/object",
                    "canCrossTenant": can_cross_tenant,
                    "defaultTenantId": str(requested_tenant),
                    "defaultStartEuid": (start_euid or "").strip(),
                    "defaultDepth": depth,
                    "maxDepth": settings.graph_max_depth,
                    "defaultMergeRef": merge_ref,
                }
            ),
            "default_start_euid": (start_euid or "").strip(),
            "default_depth": depth,
            "max_depth": settings.graph_max_depth,
            "default_tenant_id": str(requested_tenant),
            "can_cross_tenant": can_cross_tenant,
            "merge_ref": merge_ref,
        }
    )
    return templates.TemplateResponse("graph/index.html", ctx)


@router.get("/dag")
async def dag_redirect(request: Request) -> RedirectResponse:
    """Compatibility alias that redirects to the canonical graph route."""
    target = "/graph"
    if request.url.query:
        target = f"{target}?{request.url.query}"
    return RedirectResponse(url=target, status_code=307)
