"""TapDB-backed persistence for Atlas accessioning work items."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from daylily_tapdb.factory import InstanceFactory
from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.template import generic_template
from daylily_tapdb.sequences import ensure_instance_prefix_sequence
from daylily_tapdb.templates import TemplateManager
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.persistence.tapdb.euid_helpers import get_child_instances, get_instance_by_euid

ACCESSION_WORK_ITEM_TEMPLATE_CODE = "atlas/accessioning/work-item/1.0/"
ACCESSION_WORK_ITEM_REV_TEMPLATE_CODE = "atlas/accessioning/work-item-revision/1.0/"

ACCESSION_WORK_ITEM_PREFIX = "AWB"
ACCESSION_WORK_ITEM_REV_PREFIX = "AWR"


def _parse_template_code(template_code: str) -> tuple[str, str, str, str]:
    parts = template_code.strip("/").split("/")
    if len(parts) != 4:
        raise ValueError(f"Invalid template code: {template_code}")
    return parts[0], parts[1], parts[2], parts[3]


def _parse_uuid(value: Any) -> uuid.UUID | None:
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return value
    try:
        return uuid.UUID(str(value))
    except (ValueError, AttributeError):
        return None


def _to_dt(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        candidate = value.strip()
        if not candidate:
            return None
        if candidate.endswith("Z"):
            candidate = candidate[:-1] + "+00:00"
        try:
            return datetime.fromisoformat(candidate)
        except ValueError:
            return None
    return None


@dataclass(frozen=True)
class TapdbAccessionWorkItemRecord:
    euid: str
    tenant_id: uuid.UUID
    shipment_euid: str
    created_at: datetime | None
    created_by: uuid.UUID | None


@dataclass(frozen=True)
class TapdbAccessionWorkItemRevisionRecord:
    euid: str
    work_item_id: str
    revision_no: int
    queue: str
    mode: str
    stage_status: str
    receipt_metadata: dict[str, Any]
    package_manifest: dict[str, Any]
    matching_state: dict[str, Any]
    outcome_summary: dict[str, Any]
    idempotency_keys: dict[str, Any]
    created_at: datetime | None
    created_by: uuid.UUID | None
    note: str | None


class TapdbAccessioningRepository:
    """Persistence adapter for shipment-anchored accessioning work items."""

    def __init__(self, db: Session):
        self.db = db
        self.templates = TemplateManager()
        self.factory = InstanceFactory(self.templates)
        self._templates_ready = False

    def create_work_item(
        self,
        *,
        tenant_id: uuid.UUID,
        shipment_euid: str,
        queue: str,
        mode: str,
        stage_status: str,
        receipt_metadata: dict[str, Any] | None = None,
        package_manifest: dict[str, Any] | None = None,
        matching_state: dict[str, Any] | None = None,
        outcome_summary: dict[str, Any] | None = None,
        idempotency_keys: dict[str, Any] | None = None,
        created_by: uuid.UUID | None = None,
        note: str | None = None,
    ) -> tuple[TapdbAccessionWorkItemRecord, TapdbAccessionWorkItemRevisionRecord]:
        self._ensure_templates()
        now = datetime.now(UTC)

        item_instance = self.factory.create_instance(
            session=self.db,
            template_code=ACCESSION_WORK_ITEM_TEMPLATE_CODE,
            name=f"accession:{shipment_euid}",
            properties={
                "tenant_id": str(tenant_id),
                "shipment_euid": str(shipment_euid),
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
            },
        )
        item_instance.name = item_instance.euid

        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=ACCESSION_WORK_ITEM_REV_TEMPLATE_CODE,
            name=f"{item_instance.euid}-rev-1",
            properties={
                "work_item_id": item_instance.euid,
                "revision_no": 1,
                "queue": str(queue),
                "mode": str(mode),
                "stage_status": str(stage_status),
                "receipt_metadata": dict(receipt_metadata or {}),
                "package_manifest": dict(package_manifest or {}),
                "matching_state": dict(matching_state or {}),
                "outcome_summary": dict(outcome_summary or {}),
                "idempotency_keys": dict(idempotency_keys or {}),
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
                "note": note,
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=item_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        self.db.flush()
        return self._to_work_item(item_instance), self._to_work_item_revision(revision_instance)

    def create_work_item_revision(
        self,
        *,
        work_item_id: str,
        queue: str,
        mode: str,
        stage_status: str,
        receipt_metadata: dict[str, Any],
        package_manifest: dict[str, Any],
        matching_state: dict[str, Any],
        outcome_summary: dict[str, Any],
        idempotency_keys: dict[str, Any],
        created_by: uuid.UUID | None = None,
        note: str | None = None,
    ) -> TapdbAccessionWorkItemRevisionRecord | None:
        work_item_instance = self._resolve_work_item_instance(work_item_id)
        if work_item_instance is None:
            return None
        latest = self.get_latest_work_item_revision(work_item_id)
        if latest is None:
            return None

        now = datetime.now(UTC)
        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=ACCESSION_WORK_ITEM_REV_TEMPLATE_CODE,
            name=f"{work_item_id}-rev-{latest.revision_no + 1}",
            properties={
                "work_item_id": work_item_id,
                "revision_no": latest.revision_no + 1,
                "queue": str(queue),
                "mode": str(mode),
                "stage_status": str(stage_status),
                "receipt_metadata": dict(receipt_metadata or {}),
                "package_manifest": dict(package_manifest or {}),
                "matching_state": dict(matching_state or {}),
                "outcome_summary": dict(outcome_summary or {}),
                "idempotency_keys": dict(idempotency_keys or {}),
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
                "note": note,
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=work_item_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        self.db.flush()
        return self._to_work_item_revision(revision_instance)

    def get_work_item(
        self,
        *,
        work_item_id: str,
        tenant_id: uuid.UUID | None,
    ) -> tuple[TapdbAccessionWorkItemRecord, TapdbAccessionWorkItemRevisionRecord] | None:
        item = self.get_work_item_by_id(work_item_id=work_item_id, tenant_id=tenant_id)
        if item is None:
            return None
        revision = self.get_latest_work_item_revision(work_item_id)
        if revision is None:
            return None
        return item, revision

    def get_work_item_by_id(
        self,
        *,
        work_item_id: str,
        tenant_id: uuid.UUID | None,
    ) -> TapdbAccessionWorkItemRecord | None:
        instance = self._resolve_work_item_instance(work_item_id)
        if instance is None or instance.is_deleted:
            return None
        record = self._to_work_item(instance)
        if tenant_id is not None and record.tenant_id != tenant_id:
            return None
        return record

    def get_work_item_by_shipment(
        self,
        *,
        shipment_euid: str,
        tenant_id: uuid.UUID | None,
    ) -> tuple[TapdbAccessionWorkItemRecord, TapdbAccessionWorkItemRevisionRecord] | None:
        normalized = str(shipment_euid or "").strip()
        if not normalized:
            return None
        for instance in self._instances_for_template(ACCESSION_WORK_ITEM_TEMPLATE_CODE):
            record = self._to_work_item(instance)
            if record.shipment_euid != normalized:
                continue
            if tenant_id is not None and record.tenant_id != tenant_id:
                continue
            revision = self.get_latest_work_item_revision(record.euid)
            if revision is None:
                continue
            return record, revision
        return None

    def get_latest_work_item_revision(
        self,
        work_item_id: str,
    ) -> TapdbAccessionWorkItemRevisionRecord | None:
        item_instance = self._resolve_work_item_instance(work_item_id)
        if item_instance is None:
            return None
        children = get_child_instances(
            self.db, item_instance, ACCESSION_WORK_ITEM_REV_TEMPLATE_CODE
        )
        if not children:
            return None
        revisions = [self._to_work_item_revision(child) for child in children]
        revisions.sort(key=lambda row: row.revision_no, reverse=True)
        return revisions[0]

    def list_work_items(
        self,
        *,
        tenant_id: uuid.UUID | None,
        queue: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[tuple[TapdbAccessionWorkItemRecord, TapdbAccessionWorkItemRevisionRecord]]:
        rows: list[tuple[TapdbAccessionWorkItemRecord, TapdbAccessionWorkItemRevisionRecord]] = []
        for instance in self._instances_for_template(ACCESSION_WORK_ITEM_TEMPLATE_CODE):
            item = self._to_work_item(instance)
            if tenant_id is not None and item.tenant_id != tenant_id:
                continue
            revision = self.get_latest_work_item_revision(item.euid)
            if revision is None:
                continue
            if queue is not None and revision.queue != queue:
                continue
            rows.append((item, revision))
        rows.sort(
            key=lambda row: (
                row[1].created_at or row[0].created_at or datetime.min.replace(tzinfo=UTC)
            ),
            reverse=True,
        )
        return rows[offset : offset + limit]

    def count_work_items(
        self,
        *,
        tenant_id: uuid.UUID | None,
        queue: str | None = None,
    ) -> int:
        return len(self.list_work_items(tenant_id=tenant_id, queue=queue, limit=100000, offset=0))

    def _ensure_templates(self) -> None:
        if self._templates_ready:
            return
        self._ensure_template(
            ACCESSION_WORK_ITEM_TEMPLATE_CODE,
            "Atlas Accession Work Item",
            ACCESSION_WORK_ITEM_PREFIX,
        )
        self._ensure_template(
            ACCESSION_WORK_ITEM_REV_TEMPLATE_CODE,
            "Atlas Accession Work Item Revision",
            ACCESSION_WORK_ITEM_REV_PREFIX,
        )
        self._templates_ready = True
        self.db.flush()
        self.templates.clear_cache()

    def _ensure_template(self, template_code: str, name: str, prefix: str) -> None:
        ensure_instance_prefix_sequence(self.db, prefix)
        category, type_name, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_template)
            .where(
                generic_template.category == category,
                generic_template.type == type_name,
                generic_template.subtype == subtype,
                generic_template.version == version,
            )
            .limit(1)
        )
        existing = self.db.execute(stmt).scalar_one_or_none()
        if existing is None:
            self.db.add(
                generic_template(
                    name=name,
                    polymorphic_discriminator="actor_template",
                    category=category,
                    type=type_name,
                    subtype=subtype,
                    version=version,
                    instance_prefix=prefix,
                    instance_polymorphic_identity="actor_instance",
                    json_addl={"managed_by": "lsmc-atlas", "domain": "accessioning"},
                    bstatus="active",
                    is_singleton=False,
                    is_deleted=False,
                )
            )
        elif existing.instance_prefix != prefix:
            existing.instance_prefix = prefix

    def _resolve_work_item_instance(self, work_item_id: str) -> generic_instance | None:
        return get_instance_by_euid(self.db, ACCESSION_WORK_ITEM_TEMPLATE_CODE, work_item_id)

    @staticmethod
    def _instance_properties(instance: generic_instance) -> dict[str, Any]:
        raw = instance.json_addl or {}
        props = raw.get("properties") if isinstance(raw, dict) else None
        if isinstance(props, dict):
            return dict(props)
        return {}

    def _instances_for_template(self, template_code: str) -> list[generic_instance]:
        category, type_name, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_instance)
            .where(
                generic_instance.category == category,
                generic_instance.type == type_name,
                generic_instance.subtype == subtype,
                generic_instance.version == version,
                generic_instance.is_deleted.is_(False),
            )
            .order_by(generic_instance.created_dt.asc())
        )
        return list(self.db.execute(stmt).scalars().all())

    def _to_work_item(self, instance: generic_instance) -> TapdbAccessionWorkItemRecord:
        props = self._instance_properties(instance)
        return TapdbAccessionWorkItemRecord(
            euid=instance.euid,
            tenant_id=_parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            shipment_euid=str(props.get("shipment_euid") or ""),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
        )

    def _to_work_item_revision(
        self, instance: generic_instance
    ) -> TapdbAccessionWorkItemRevisionRecord:
        props = self._instance_properties(instance)
        return TapdbAccessionWorkItemRevisionRecord(
            euid=instance.euid,
            work_item_id=str(props.get("work_item_id") or ""),
            revision_no=int(props.get("revision_no") or 1),
            queue=str(props.get("queue") or ""),
            mode=str(props.get("mode") or "queue"),
            stage_status=str(props.get("stage_status") or ""),
            receipt_metadata=dict(props.get("receipt_metadata") or {}),
            package_manifest=dict(props.get("package_manifest") or {}),
            matching_state=dict(props.get("matching_state") or {}),
            outcome_summary=dict(props.get("outcome_summary") or {}),
            idempotency_keys=dict(props.get("idempotency_keys") or {}),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
            note=str(props.get("note")).strip() if props.get("note") else None,
        )
