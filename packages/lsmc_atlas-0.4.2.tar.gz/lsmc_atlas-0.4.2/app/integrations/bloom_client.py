"""Bloom API client for container/specimen operations."""

from __future__ import annotations

import os
import time
from dataclasses import dataclass
from typing import Any

import httpx


class BloomClientError(RuntimeError):
    """Raised when a Bloom API operation fails."""


def _require_https_url(value: str, *, field_name: str) -> str:
    normalized = str(value or "").strip().rstrip("/")
    if not normalized:
        raise BloomClientError(f"{field_name} is required")
    if not normalized.startswith("https://"):
        raise BloomClientError(f"{field_name} must use an absolute https:// URL")
    return normalized


@dataclass
class BloomOperationResult:
    """Normalized result for Bloom write operations."""

    external_euid: str
    status: str
    raw: dict[str, Any]


def resolve_secret_value(secret_ref: str) -> str:
    """Resolve secret values from reference strings.

    Supported forms:
    - env:VAR_NAME
    - file:/absolute/path.txt
    - plain:literal-value   (dev only)
    - blm_<token>           (direct Bloom bearer token)
    - VAR_NAME              (implicit env var)
    """
    ref = (secret_ref or "").strip()
    if not ref:
        raise BloomClientError("Empty Bloom API secret reference")

    if ref.startswith("env:"):
        key = ref[4:].strip()
        value = os.environ.get(key, "")
        if not value:
            raise BloomClientError(f"Missing environment variable for secret ref: {ref}")
        return value

    if ref.startswith("file:"):
        path = ref[5:].strip()
        if not path:
            raise BloomClientError("Invalid file secret ref")
        try:
            return open(path, encoding="utf-8").read().strip()
        except OSError as exc:
            raise BloomClientError(f"Failed reading secret file: {path}") from exc

    if ref.startswith("plain:"):
        return ref[6:]

    # Treat direct Bloom bearer tokens as literal secrets so each org/site can
    # store its own token without requiring a process-level env var mapping.
    if ref.startswith("blm_"):
        return ref

    value = os.environ.get(ref, "")
    if not value:
        raise BloomClientError(f"Missing environment variable for secret ref: {ref}")
    return value


class BloomClient:
    """HTTP client wrapper for Bloom APIs."""

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        timeout_seconds: float = 20.0,
        max_retries: int = 2,
        retry_backoff_seconds: float = 0.25,
        verify_ssl: bool = True,
    ):
        clean_base_url = _require_https_url(base_url, field_name="Bloom base URL")
        if not api_key:
            raise BloomClientError("Bloom API key is required")

        self.base_url = clean_base_url
        self.api_key = api_key
        self.timeout = timeout_seconds
        self.max_retries = max(0, int(max_retries))
        self.retry_backoff_seconds = max(0.0, float(retry_backoff_seconds))
        self.verify_ssl = bool(verify_ssl)

    def _request(
        self,
        method: str,
        path: str,
        *,
        payload: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        url = f"{self.base_url}{path}"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key
        response: httpx.Response | None = None
        for attempt in range(self.max_retries + 1):
            try:
                with httpx.Client(timeout=self.timeout, verify=self.verify_ssl) as client:
                    response = client.request(
                        method, url, json=payload, headers=headers, params=params
                    )
            except httpx.HTTPError as exc:
                if attempt < self.max_retries:
                    time.sleep(self.retry_backoff_seconds * (2**attempt))
                    continue
                raise BloomClientError(f"Bloom request failed: {exc}") from exc

            if (
                response.status_code in (424, 429, 500, 502, 503, 504)
                and attempt < self.max_retries
            ):
                time.sleep(self.retry_backoff_seconds * (2**attempt))
                continue
            break

        if response is None:
            raise BloomClientError("Bloom request failed without response")

        if response.status_code >= 400:
            text = response.text.strip()
            raise BloomClientError(
                f"Bloom request failed ({response.status_code}) {method} {path}: {text}"
            )

        if not response.text:
            return {}
        try:
            data = response.json()
        except ValueError as exc:
            raise BloomClientError(f"Bloom returned non-JSON response for {method} {path}") from exc
        if isinstance(data, dict):
            return data
        raise BloomClientError(f"Bloom returned invalid JSON shape for {method} {path}")

    @staticmethod
    def _normalize_result(payload: dict[str, Any]) -> BloomOperationResult:
        external_euid = (
            payload.get("euid")
            or payload.get("specimen_euid")
            or payload.get("container_euid")
            or payload.get("id")
        )
        if not external_euid:
            raise BloomClientError("Bloom response missing identifier")
        return BloomOperationResult(
            external_euid=str(external_euid),
            status=str(payload.get("status") or "active"),
            raw=payload,
        )

    def create_object(
        self,
        payload: dict[str, Any],
        *,
        idempotency_key: str | None = None,
    ) -> BloomOperationResult:
        """Create an object using Bloom object-creation API."""
        data = self._request(
            "POST",
            "/api/v1/object-creation/create",
            payload=payload,
            idempotency_key=idempotency_key,
        )
        return self._normalize_result(data)

    def list_object_categories(self) -> list[dict[str, Any]]:
        data = self._request("GET", "/api/v1/object-creation/categories")
        categories = data.get("categories")
        if not isinstance(categories, list):
            raise BloomClientError("Bloom categories response has invalid shape")
        normalized: list[dict[str, Any]] = []
        for item in categories:
            if isinstance(item, dict):
                normalized.append(item)
        return normalized

    def get_graph_data(
        self,
        *,
        start_euid: str,
        depth: int,
    ) -> dict[str, Any]:
        return self._request(
            "GET",
            "/api/v1/graph/data",
            params={
                "start_euid": start_euid,
                "depth": depth,
            },
        )

    def get_graph_object_detail(
        self,
        *,
        euid: str,
    ) -> dict[str, Any]:
        return self._request(
            "GET",
            f"/api/v1/graph/object/{euid}",
        )

    def create_external_specimen(
        self,
        payload: dict[str, Any],
        *,
        idempotency_key: str | None = None,
    ) -> BloomOperationResult:
        data = self._request(
            "POST",
            "/api/v1/external/specimens",
            payload=payload,
            idempotency_key=idempotency_key,
        )
        return self._normalize_result(data)

    def register_accepted_material(
        self,
        payload: dict[str, Any],
        *,
        idempotency_key: str | None = None,
    ) -> BloomOperationResult:
        data = self._request(
            "POST",
            "/api/v1/external/atlas/beta/materials",
            payload=payload,
            idempotency_key=idempotency_key,
        )
        return self._normalize_result(data)

    def create_empty_tube(
        self,
        payload: dict[str, Any],
        *,
        idempotency_key: str | None = None,
    ) -> BloomOperationResult:
        data = self._request(
            "POST",
            "/api/v1/external/atlas/beta/tubes",
            payload=payload,
            idempotency_key=idempotency_key,
        )
        return self._normalize_result(data)

    def update_tube(
        self,
        container_euid: str,
        payload: dict[str, Any],
    ) -> BloomOperationResult:
        data = self._request(
            "PATCH",
            f"/api/v1/external/atlas/beta/tubes/{container_euid}",
            payload=payload,
        )
        return self._normalize_result(data)

    def update_beta_specimen(
        self,
        specimen_euid: str,
        payload: dict[str, Any],
    ) -> BloomOperationResult:
        data = self._request(
            "PATCH",
            f"/api/v1/external/atlas/beta/specimens/{specimen_euid}",
            payload=payload,
        )
        return self._normalize_result(data)

    def move_material_to_queue(
        self,
        material_euid: str,
        queue_name: str,
        *,
        metadata: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/api/v1/external/atlas/beta/queues/{queue_name}/items/{material_euid}",
            payload={"metadata": metadata or {}},
            idempotency_key=idempotency_key,
        )

    def claim_material_in_queue(
        self,
        material_euid: str,
        queue_name: str,
        *,
        metadata: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/api/v1/external/atlas/beta/queues/{queue_name}/items/{material_euid}/claim",
            payload={"metadata": metadata or {}},
            idempotency_key=idempotency_key,
        )

    def release_claim(
        self,
        claim_euid: str,
        *,
        reason: str | None = None,
        metadata: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/api/v1/external/atlas/beta/claims/{claim_euid}/release",
            payload={"reason": reason, "metadata": metadata or {}},
            idempotency_key=idempotency_key,
        )

    def reserve_material(
        self,
        material_euid: str,
        *,
        reason: str | None = None,
        metadata: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/api/v1/external/atlas/beta/materials/{material_euid}/reservations",
            payload={"reason": reason, "metadata": metadata or {}},
            idempotency_key=idempotency_key,
        )

    def release_reservation(
        self,
        reservation_euid: str,
        *,
        reason: str | None = None,
        metadata: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/api/v1/external/atlas/beta/reservations/{reservation_euid}/release",
            payload={"reason": reason, "metadata": metadata or {}},
            idempotency_key=idempotency_key,
        )

    def consume_material(
        self,
        material_euid: str,
        *,
        reason: str | None = None,
        metadata: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/api/v1/external/atlas/beta/materials/{material_euid}/consume",
            payload={"reason": reason, "metadata": metadata or {}},
            idempotency_key=idempotency_key,
        )

    def get_external_specimen(self, specimen_euid: str) -> BloomOperationResult:
        data = self._request("GET", f"/api/v1/external/specimens/{specimen_euid}")
        return self._normalize_result(data)

    def patch_external_specimen(
        self, specimen_euid: str, payload: dict[str, Any]
    ) -> BloomOperationResult:
        data = self._request(
            "PATCH", f"/api/v1/external/specimens/{specimen_euid}", payload=payload
        )
        return self._normalize_result(data)

    def find_external_specimens_by_reference(
        self, references: dict[str, str | None]
    ) -> list[dict[str, Any]]:
        params = {
            key: value
            for key, value in (references or {}).items()
            if value is not None and str(value).strip()
        }
        data = self._request(
            "GET",
            "/api/v1/external/specimens/by-reference",
            params=params,
        )
        items = data.get("items")
        if not isinstance(items, list):
            raise BloomClientError("Bloom by-reference lookup returned invalid shape")
        normalized: list[dict[str, Any]] = []
        for item in items:
            if isinstance(item, dict):
                normalized.append(item)
        return normalized

    def delete_content(
        self, specimen_euid: str, *, hard_delete: bool = False
    ) -> BloomOperationResult:
        params = {"hard_delete": "true"} if hard_delete else None
        data = self._request("DELETE", f"/api/v1/content/{specimen_euid}", params=params)
        if not data:
            data = {"euid": specimen_euid, "status": "deleted"}
        return self._normalize_result(data)
