"""Setup configuration for zymemory SDK."""

from setuptools import setup, find_packages
import os

# Read version
version = {}
with open(os.path.join("zymemory", "version.py")) as f:
    exec(f.read(), version)

# Read README
with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="zymemory",
    version=version["__version__"],
    author="Hey Maple",
    author_email="contact@heymaple.app",
    description="Python SDK for Zymemory - Long-term memory for AI applications",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/ranjalii/zymemory",
    packages=find_packages(exclude=["tests", "examples"]),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.25.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "black>=22.0.0",
            "mypy>=0.950",
            "flake8>=4.0.0",
        ],
    },
    keywords="ai memory llm chatbot assistant api sdk",
    project_urls={
        "Bug Reports": "https://github.com/ranjalii/zymemory/issues",
        "Source": "https://github.com/ranjalii/zymemory",
        "Documentation": "https://heymaple.app/docs",
    },
)
