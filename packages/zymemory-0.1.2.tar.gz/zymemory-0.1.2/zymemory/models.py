"""Data models for zymemory SDK."""

from typing import List, Dict, Any, Optional
from dataclasses import dataclass


@dataclass
class Memory:
    """Represents a memory in the system.

    Attributes:
        id: Unique memory identifier
        content: The memory content/text
        keywords: List of extracted keywords
        conversations: List of conversation turns
        created_at: ISO timestamp of creation
        link_count: Number of connections to other memories
    """
    id: int
    content: str
    keywords: List[str]
    conversations: List[tuple[str, str]]
    created_at: Optional[str] = None
    link_count: Optional[int] = None
    metadata: Optional[Dict[str, Any]] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Memory":
        """Create Memory from API response dictionary."""
        metadata = data.get("metadata", {})
        return cls(
            id=data["id"],
            content=data["content"],
            keywords=metadata.get("keywords", []),
            conversations=metadata.get("conversations", []),
            created_at=data.get("created_at"),
            link_count=metadata.get("link_count"),
            metadata=metadata
        )


@dataclass
class SearchResult:
    """Result from memory search.

    Attributes:
        memories: List of matching memories
        unassigned: List of unassigned conversation turns
    """
    memories: List[Memory]
    unassigned: List[Dict[str, Any]]

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SearchResult":
        """Create SearchResult from API response."""
        memories = [Memory.from_dict(m) for m in data.get("memories", [])]
        return cls(
            memories=memories,
            unassigned=data.get("unassigned", [])
        )


@dataclass
class MemoryList:
    """Paginated list of memories.

    Attributes:
        memories: List of memories on current page
        total: Total number of memories
        page: Current page number
        page_size: Number of items per page
    """
    memories: List[Memory]
    total: int
    page: int
    page_size: int

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MemoryList":
        """Create MemoryList from API response."""
        memories = [Memory.from_dict(m) for m in data.get("memories", [])]
        return cls(
            memories=memories,
            total=data["total"],
            page=data["page"],
            page_size=data["page_size"]
        )


@dataclass
class MemoryLink:
    """Link between two memories.

    Attributes:
        source_id: ID of source memory
        destination_id: ID of destination memory
        relationship: Type of relationship (optional)
    """
    source_id: int
    destination_id: int
    relationship: Optional[str] = None


@dataclass
class User:
    """Registered user.

    Attributes:
        id: User identifier
        external_id: External identifier
        name: User name
        token: User API token
        created_at: Creation timestamp
    """
    id: int
    external_id: str
    name: str
    token: str
    created_at: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "User":
        """Create User from API response."""
        return cls(
            id=data["id"],
            external_id=data["external_id"],
            name=data["name"],
            token=data["token"],
            created_at=data.get("created_at")
        )
