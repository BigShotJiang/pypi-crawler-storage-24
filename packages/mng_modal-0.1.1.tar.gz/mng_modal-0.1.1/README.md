# mng-modal

This package has been renamed to [imbue-mngr-modal](https://pypi.org/project/imbue-mngr-modal/).

Install the new package:

```
pip install imbue-mngr-modal
```
