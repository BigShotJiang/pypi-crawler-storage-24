"""
ALETHEIA Safety Database — Python SDK

Usage:
    from aletheia_safety import Aletheia

    client = Aletheia()                          # free tier (200 req/day)
    client = Aletheia(api_key="aletheia_live_…") # paid tier

    # Look up a compound
    compound = client.compound("hq-c-org-000001")
    compound = client.compound_by_cas("1071-83-6")

    # Search across all entity types
    results = client.search("sodium", type="compound", limit=10)

    # Compare compounds side-by-side
    comparison = client.compare(["hq-c-org-000001", "hq-c-org-000005"], context="human_adult")

    # Filter by risk level
    high_risk = client.filter(risk="high", context="food_contact")

    # Explore relationships
    graph = client.graph("hq-c-org-000001", depth=2)
"""

__version__ = "0.1.0"

import urllib.request
import urllib.error
import urllib.parse
import json


BASE_URL = "https://api.aletheia.holisticquality.io/api"


class AletheiaError(Exception):
    """Base exception for ALETHEIA API errors."""
    def __init__(self, status, error, message):
        self.status = status
        self.error = error
        super().__init__(f"[{status}] {error}: {message}")


class RateLimitError(AletheiaError):
    """Raised when rate limit is exceeded (HTTP 429)."""
    pass


class Aletheia:
    """Client for the ALETHEIA Safety Database API."""

    def __init__(self, api_key=None, base_url=None, timeout=30):
        """
        Initialize the ALETHEIA client.

        Args:
            api_key: API key for paid tiers (Developer/Pro/Enterprise).
                     Omit for free public tier (200 req/day per IP).
            base_url: Override the API base URL (default: production).
            timeout: Request timeout in seconds (default: 30).
        """
        self.api_key = api_key
        self.base_url = (base_url or BASE_URL).rstrip("/")
        self.timeout = timeout

    def _request(self, path, params=None):
        """Make a GET request to the API."""
        url = f"{self.base_url}{path}"
        if params:
            filtered = {k: v for k, v in params.items() if v is not None}
            if filtered:
                url += "?" + urllib.parse.urlencode(filtered)

        req = urllib.request.Request(url)
        req.add_header("User-Agent", f"aletheia-safety-python/{__version__}")
        if self.api_key:
            req.add_header("X-API-Key", self.api_key)

        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            body = {}
            try:
                body = json.loads(e.read())
            except Exception:
                pass
            error = body.get("error", f"HTTP {e.code}")
            message = body.get("message", e.reason)
            if e.code == 429:
                raise RateLimitError(429, error, message)
            raise AletheiaError(e.code, error, message)

    def _post(self, path, data):
        """Make a POST request to the API."""
        url = f"{self.base_url}{path}"
        payload = json.dumps(data).encode()

        req = urllib.request.Request(url, data=payload, method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("User-Agent", f"aletheia-safety-python/{__version__}")
        if self.api_key:
            req.add_header("X-API-Key", self.api_key)

        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            body = {}
            try:
                body = json.loads(e.read())
            except Exception:
                pass
            raise AletheiaError(e.code, body.get("error", f"HTTP {e.code}"), body.get("message", e.reason))

    # ── Compounds ─────────────────────────────────────────────────

    def compound(self, id, context=None):
        """
        Get a single compound by HQ ID.

        Args:
            id: Compound ID (e.g., "hq-c-org-000001")
            context: Safety context (e.g., "human_adult", "dog", "cat")

        Returns:
            dict with compound data including safety profile
        """
        return self._request(f"/compound/{id}", {"context": context})

    def compound_by_cas(self, cas):
        """
        Look up a compound by CAS number.

        Args:
            cas: CAS registry number (e.g., "1071-83-6")

        Returns:
            dict with compound data
        """
        return self._request(f"/compound/cas/{cas}")

    def compounds(self, limit=20, offset=0, search=None):
        """
        List compounds with pagination. Requires Developer+ tier.

        Args:
            limit: Results per page (max 200)
            offset: Pagination offset
            search: Optional search filter

        Returns:
            dict with results array and pagination info
        """
        return self._request("/compounds", {"limit": limit, "offset": offset, "search": search})

    def batch(self, ids):
        """
        Look up multiple compounds at once (max 20).

        Args:
            ids: List of compound IDs

        Returns:
            dict with results for each ID
        """
        return self._request("/compounds/batch", {"ids": ",".join(ids)})

    def compare(self, ids, context=None):
        """
        Compare 2-5 compounds side-by-side. Requires Developer+ tier.

        Args:
            ids: List of 2-5 compound IDs
            context: Safety context for comparison

        Returns:
            dict with comparison data and differentials
        """
        return self._request("/compounds/compare", {"ids": ",".join(ids), "context": context})

    # ── Search & Filter ───────────────────────────────────────────

    def search(self, query, type=None, limit=20, offset=0):
        """
        Full-text search across compounds, products, and materials.

        Args:
            query: Search term (min 2 characters)
            type: Filter by entity type ("compound", "product", "material")
            limit: Results per page (max 100)
            offset: Pagination offset

        Returns:
            dict with scored results and pagination
        """
        return self._request("/search", {"q": query, "type": type, "limit": limit, "offset": offset})

    def filter(self, risk=None, context=None, type=None, agency=None,
               hazard=None, cas_prefix=None, exposure=None,
               functional_use=None, year=None, year_min=None, year_max=None,
               limit=20, offset=0):
        """
        Filter compounds by risk level, context, regulatory agency, and more.

        Args:
            risk: Risk level ("high", "moderate", "low", "minimal")
            context: Safety context (e.g., "food_contact")
            type: Compound type (e.g., "preservative")
            agency: Regulatory agency (e.g., "EPA", "EFSA")
            hazard: Hazard classification
            cas_prefix: CAS number prefix
            exposure: Found-in category
            functional_use: EPA functional use category
            year: Year reviewed (exact)
            year_min: Year reviewed minimum
            year_max: Year reviewed maximum
            limit: Results per page
            offset: Pagination offset

        Returns:
            dict with filtered results
        """
        return self._request("/filter", {
            "risk": risk, "context": context, "type": type, "agency": agency,
            "hazard": hazard, "cas_prefix": cas_prefix, "exposure": exposure,
            "functional_use": functional_use, "year": year,
            "year_min": year_min, "year_max": year_max,
            "limit": limit, "offset": offset,
        })

    # ── Relationships & Graph ─────────────────────────────────────

    def relationships(self, id):
        """
        Get direct relationships for an entity.

        Args:
            id: Entity ID (compound, material, or product)

        Returns:
            dict with related entities
        """
        return self._request(f"/relationships/{id}")

    def graph(self, id, depth=1):
        """
        Multi-hop graph traversal from an entity.

        Args:
            id: Starting entity ID
            depth: Traversal depth (1-3)

        Returns:
            dict with nodes and edges
        """
        return self._request(f"/relationships/{id}/graph", {"depth": depth})

    def relationship_stats(self):
        """Get overall relationship graph statistics."""
        return self._request("/relationships/stats")

    # ── Regulatory ────────────────────────────────────────────────

    def regulatory(self, id):
        """
        Get regulatory classifications for a compound. Requires Developer+ tier.

        Args:
            id: Compound ID

        Returns:
            dict with regulatory data by agency
        """
        return self._request(f"/regulatory/{id}")

    def regulatory_agencies(self):
        """List all regulatory agencies with compound counts. Requires Developer+ tier."""
        return self._request("/regulatory/agencies")

    def regulatory_by_agency(self, agency):
        """
        Get all compounds classified by a specific agency. Requires Developer+ tier.

        Args:
            agency: Agency name (e.g., "EPA", "IARC", "EFSA")
        """
        return self._request(f"/regulatory/by-agency/{urllib.parse.quote(agency)}")

    # ── Found In (Exposure Sources) ───────────────────────────────

    def found_in(self, id):
        """
        Get exposure sources for a compound. Requires Developer+ tier.

        Args:
            id: Compound ID

        Returns:
            dict with categorized exposure sources
        """
        return self._request(f"/found-in/{id}")

    def found_in_categories(self):
        """List all exposure source categories. Requires Developer+ tier."""
        return self._request("/found-in/categories")

    def found_in_by_category(self, category):
        """
        Get compounds found in a specific category. Requires Developer+ tier.

        Args:
            category: Category name (e.g., "Food", "Cosmetics")
        """
        return self._request(f"/found-in/by-category/{urllib.parse.quote(category)}")

    # ── Materials & Products ──────────────────────────────────────

    def materials(self, limit=20, offset=0, search=None):
        """List materials. Requires Developer+ tier."""
        return self._request("/materials", {"limit": limit, "offset": offset, "search": search})

    def material(self, id):
        """Get a single material by ID."""
        return self._request(f"/material/{id}")

    def products(self, limit=20, offset=0, search=None):
        """List products. Requires Developer+ tier."""
        return self._request("/products", {"limit": limit, "offset": offset, "search": search})

    def product(self, id):
        """Get a single product by ID."""
        return self._request(f"/product/{id}")

    # ── Fragrance ─────────────────────────────────────────────────

    def fragrance(self, limit=20, offset=0):
        """List fragrance ingredients."""
        return self._request("/fragrance", {"limit": limit, "offset": offset})

    def fragrance_classes(self):
        """List fragrance ingredient classes."""
        return self._request("/fragrance/classes")

    def fragrance_search(self, query):
        """Search fragrance ingredients."""
        return self._request("/fragrance/search", {"q": query})

    # ── Reference ─────────────────────────────────────────────────

    def contexts(self):
        """List all 19 safety/exposure contexts with descriptions."""
        return self._request("/contexts")

    def badge_url(self, id):
        """
        Get the URL for an embeddable SVG safety badge.

        Args:
            id: Compound ID

        Returns:
            str: Badge URL (use in <img> tags)
        """
        return f"{self.base_url}/badge/{id}"

    # ── Export ─────────────────────────────────────────────────────

    def export(self, type="compounds", format="json"):
        """
        Bulk export data. Requires Developer+ tier. Counts as 10 requests.

        Args:
            type: "compounds", "materials", or "products"
            format: "json" or "csv"
        """
        return self._request("/export", {"type": type, "format": format})

    # ── Key Management ────────────────────────────────────────────

    def key_status(self):
        """Check your API key status, tier, and usage."""
        return self._request("/keys/status")

    def key_recover(self, email):
        """
        Request API key recovery email.

        Args:
            email: Email address associated with the key
        """
        return self._post("/keys/recover", {"email": email})

    # ── Health ────────────────────────────────────────────────────

    def health(self):
        """Check API health status."""
        return self._request("/health")
