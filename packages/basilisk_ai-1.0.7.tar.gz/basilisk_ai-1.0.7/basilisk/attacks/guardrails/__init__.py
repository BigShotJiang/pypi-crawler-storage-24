"""Basilisk guardrail bypass attacks."""
