"""Basilisk tool abuse attacks."""
