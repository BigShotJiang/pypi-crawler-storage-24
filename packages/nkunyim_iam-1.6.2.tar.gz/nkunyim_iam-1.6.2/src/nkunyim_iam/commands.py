from datetime import datetime
from enum import Enum
from typing import Optional
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class UserCommand(BaseModel):
    id: UUID
    username: str
    nickname: str
    first_name: str
    middle_name: Optional[str] = None
    last_name: str
    email_address: str
    email_verified: bool
    email_verified_at: Optional[datetime] = None
    phone_number: str
    phone_verified: bool
    phone_verified_at: Optional[datetime] = None
    serial: Optional[str] = None
    gender: str
    birth_date: Optional[datetime] = None
    photo_url: Optional[str] = None
    photo_verified: bool
    photo_verified_at: Optional[datetime] = None
    profile: Optional[str] = None
    is_pwd: bool
    is_active: bool
    is_admin: bool
    is_superuser: bool
    is_verified: bool



class LoggingLevel(str, Enum):
    INFO = "info"
    SUCCESS = "success"
    WARNING = "warning"
    DANGER = "danger"


LoggingContext = dict[str, str | int | float | bool | None]


class LoggingCommand(BaseModel):
    model_config = ConfigDict(use_enum_values=True)
    level: LoggingLevel = LoggingLevel.INFO
    message: str
    context: LoggingContext = Field(default_factory=dict)

