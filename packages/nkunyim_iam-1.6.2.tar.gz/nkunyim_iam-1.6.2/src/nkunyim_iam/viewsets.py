from rest_framework import viewsets
from rest_framework.permissions import (
    IsAuthenticatedOrReadOnly,
)

from nkunyim_iam.models import (
    Logging,
    User,
)
from nkunyim_iam.serializers import (
    LoggingSerializer,
    UserSerializer,
)



class UserViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticatedOrReadOnly]
    queryset = User.objects.all()
    serializer_class = UserSerializer
    filterset_fields = [
        'gender',
        'is_pwd',
        'is_superuser',
        'is_admin',
        'is_verified',
        'is_active'
    ]
    search_fields = ['first_name', 'last_name', 'username', 'nickname', 'email_address']



class LoggingViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticatedOrReadOnly]
    queryset = Logging.objects.all()
    serializer_class = LoggingSerializer
    filterset_fields = [
        'level',
    ]
    search_fields = ['message', 'context']
  
