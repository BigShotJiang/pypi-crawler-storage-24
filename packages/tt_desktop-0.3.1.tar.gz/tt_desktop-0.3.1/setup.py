from setuptools import setup, find_packages

setup(
    name="tt-desktop",
    version="0.3.1",
    description="TaskingTech Desktop Agent — cross-platform native computer control",
    author="Tasking.tech",
    url="https://tasking.tech",
    packages=find_packages(),
    install_requires=[
        "pyautogui>=0.9.54",
        "mss>=9.0.0",
        "Pillow>=10.0.0",
        "requests>=2.31.0",
        "pyperclip>=1.8.2",
    ],
    extras_require={
        "ocr": ["pytesseract>=0.3.10"],
        "tray": ["pystray>=0.19.5"],
        "app": ["pywebview>=4.0"],
    },
    entry_points={
        "console_scripts": [
            "tt-desktop=agent.main:main",
        ],
    },
    python_requires=">=3.8",
)
