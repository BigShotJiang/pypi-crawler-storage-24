"""
PullAI — Python SDK for running AI models locally.

Quick start::

    from pullai import PullAI

    ai = PullAI()           # connect to pullai serve (port 11500)
    ai.models()             # list installed models
    ai.pull("llm/mistral:7b")

    # Chat
    ai.chat("llm/mistral:7b", "What is Python?")

    # Image
    ai.image("image/sdxl", "a sunset on Mars", "mars.png")

    # Audio
    ai.speak("audio/kokoro", "Hello world!", "hello.wav")
    text = ai.transcribe("audio/whisper:base", "audio.mp3")

    # Video
    ai.video("video/wan:1.3b", "a flying cat", "cat.mp4")

    # 3D
    ai.model3d("3d/triposr", "chair.obj", image="photo.jpg")

    # Multi-turn conversation
    conv = ai.conversation("llm/mistral:7b")
    conv.say("My name is Marco.")
    conv.say("What is my name?")
    conv.start()   # interactive REPL
"""

from .client import PullAI, Conversation

__version__ = "6.0.0"
__author__  = "Metiu"
__all__     = ["PullAI", "Conversation"]
