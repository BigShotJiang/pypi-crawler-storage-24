# SmartBill Interface MCP Server

MCP server for interfacing with smartbill.ro for conducting financial operations.

## MCP Server - Stdio

### Run

```bash
export SMARTBILL_USERNAME="myname@mycompany.ro"
export SMARTBILL_TOKEN="xxxxxxxxxxxxxx"
uvx smartbill-interface
```

### Use from Claude Code

```json
"mcpServers": {
    "smartbill-interface": {
        "type": "stdio",
        "command": "uvx",
        "args": [
            "smartbill-interface"
        ]
        "env": {
            "SMARTBILL_USERNAME": "${SMARTBILL_USERNAME}",
            "SMARTBILL_TOKEN": "${SMARTBILL_TOKEN}"
        }
    }
}
```

Before running `claude`, export the 2 environment variables with the real values for your smartbill account:

```
export SMARTBILL_USERNAME="myname@mycompany.ro"
export SMARTBILL_TOKEN="xxxxxxxxxxxxxx"
```

#### Sample Prompt 1

`Get the payment status for a bill with CIF RO39999999, series XX2025, number 0003`

Response:

```
● smartbill-interface - _get_payment_status (MCP)(cif: "RO39999999", series: "XX2025", number: "0003")

● Here's the payment status for the bill:

  ┌───────────────┬────────┐
  │     Field     │ Amount │
  ├───────────────┼────────┤
  │ Total Amount  │ 111.62 │
  ├───────────────┼────────┤
  │ Paid Amount   │ 0.00   │
  ├───────────────┼────────┤
  │ Unpaid Amount │ 111.62 │
  └───────────────┴────────┘

The bill (series XX2025, number 0003, CIF RO39999999) is fully unpaid — no payments have been recorded against the total of 111.62.
```

#### Sample Prompt 2

`Get the bill with CIF RO39999999, series XX2025, number 0003`

Response:

```
smartbill-interface - _get_bill (MCP)(cif: "RO39999999", series: "XX2025", number: "0003")

● The bill was retrieved as a PDF blob. Let me extract and save it as a PDF file for you.

● Read 1 file (ctrl+o to expand)

● Bash(cat /home/mio/.claude/projects/myproject/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx/tool-results/mcp-smartbill-interface-_get_bill-1111111111111.txt | python3 -c…)

● The bill has been saved as bill_XX2025_0003.pdf (59 KB) in your working directory (/myproject/). You can open it directly from there.
```

### Test

Test using MCP Inspector UI:

```bash
npx @modelcontextprotocol/inspector uvx smartbill-interface
```

Test from the command line:

```bash
npx @modelcontextprotocol/inspector --cli --method tools/list uvx smartbill-interface | jq -r .tools.[].name

_get_payment_status
_get_bill
```
