#!/usr/bin/env python
#MCP server for interfacing with smartbill.ro for conducting financial operations
from urllib.request import urlopen, Request
from urllib.error import HTTPError
import mcp.server.fastmcp
import mcp.types
import logging
import xml.etree.ElementTree as ET
import os
import base64

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

SMARTBILL_BASE_URL = "https://ws.smartbill.ro/SBORO/api"
SMARTBILL_BILL_ID = "cif={cif}&seriesname={series}&number={number}"
SMARTBILL_PAYMENT_STATUS_URL = SMARTBILL_BASE_URL + "/invoice/paymentstatus?" + SMARTBILL_BILL_ID
SMARTBILL_GET_BILL_URL = SMARTBILL_BASE_URL + "/invoice/pdf?" + SMARTBILL_BILL_ID

def _build_auth() -> str:
    username = os.environ["SMARTBILL_USERNAME"]
    token = os.environ["SMARTBILL_TOKEN"]
    return base64.b64encode(f"{username}:{token}".encode()).decode()

mymcp = mcp.server.fastmcp.FastMCP("SmartBill Interface Server")

@mymcp.tool()
def _get_payment_status(cif: str, series: str, number: str) -> tuple[float, float, float]:
    """Get the payment status for a bill.

    Returns total amount, paid amount and unpaid amount.
    """
    logger.debug(f"_get_payment_status for bill with cif: {cif}, series: {series} and number: {number}")
    url = SMARTBILL_PAYMENT_STATUS_URL.format(cif=cif, series=series, number=number)
    req = Request(url, headers={
        "Content-Type": "application/xml",
        "Accept": "application/xml",
        "Authorization": f"Basic {_build_auth()}",
    })
    try:
        with urlopen(req) as response:
            xml_data = response.read()
            logger.debug(f"Received answer: {xml_data}")
            root = ET.fromstring(xml_data)
            total_amount = float(root.findtext("invoiceTotalAmount"))
            logger.debug(f"Answer contains total amount: {total_amount}")
            paid_amount = float(root.findtext("paidAmount"))
            logger.debug(f"Answer contains paid amount: {paid_amount}")
            unpaid_amount = float(root.findtext("unpaidAmount"))
            logger.debug(f"Answer contains unpaid amount: {unpaid_amount}")
            return total_amount, paid_amount, unpaid_amount
    except HTTPError as e:
        logger.error(f"HTTP error {e.code} for URL {url}: {e.reason}")
        raise

@mymcp.tool()
def _get_bill(cif: str, series: str, number: str) -> mcp.types.BlobResourceContents:
    """Get a bill.

    Returns the bill in PDF format as a blob.
    """
    logger.debug(f"_get_bill for bill with cif: {cif}, series: {series} and number: {number}")
    url = SMARTBILL_GET_BILL_URL.format(cif=cif, series=series, number=number)
    req = Request(url, headers={
        "Content-Type": "application/xml",
        "Accept": "application/xml",
        "Accept": "application/octet-stream",
        "Authorization": f"Basic {_build_auth()}",
        "Content-Disposition": "attachment; filename=\"bill.pdf\"",
    })
    try:
        with urlopen(req) as response:
            bill = response.read()
            logger.debug(f"Received {len(bill)} bytes")
            return mcp.types.BlobResourceContents(
                uri=url,
                blob=base64.b64encode(bill).decode(),
                mimeType="application/pdf",
            )
    except HTTPError as e:
        logger.error(f"HTTP error {e.code} for URL {url}: {e.reason}")
        raise

def main():
    """Entry point for the SmartBill MCP server."""
    missing = [v for v in ("SMARTBILL_USERNAME", "SMARTBILL_TOKEN") if not os.environ.get(v)]
    if missing:
        logger.error(f"Missing required environment variables: {', '.join(missing)}")
        return
    mymcp.run(transport="stdio")

if __name__ == "__main__":
    main()
