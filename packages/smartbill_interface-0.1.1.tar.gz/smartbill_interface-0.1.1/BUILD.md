# SmartBill Interface

## Build and Publish

```bash
uv build

#test publish
uv publish --token xxxxTESTxxxxxxx  --publish-url https://test.pypi.org/legacy/
uvx --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ smartbill-interface

#publish
uv publish --token xxxxxxxxxxxxxxx
```

## Run Locally

```bash
uvx --from . smartbill-interface

#or

uvx --from /mnt/c/projects/smartbill-mcp-server smartbill-interface

#or run from wheel file
uvx --from ./dist/smartbill_interface-0.1.1-py3-none-any.whl smartbill-interface
```
