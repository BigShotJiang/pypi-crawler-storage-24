<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="ui/public/logo-full-dark.svg">
    <source media="(prefers-color-scheme: light)" srcset="ui/public/logo-full.svg">
    <img alt="Telescope" src="https://raw.githubusercontent.com/eduardoslonski/telescope-ui/main/ui/public/logo-full.svg" height="80">
  </picture>
</p>

<p align="center">
  The visualization dashboard for <a href="https://github.com/eduardoslonski/telescope">Telescope</a> — a framework for post-training LLMs with reinforcement learning, designed for reasoning and agentic capabilities.
</p>

# Telescope UI

Telescope UI runs locally on your machine and syncs training data from Weights & Biases into a local DuckDB database, giving you a real-time dashboard to monitor runs, inspect rollouts, and analyze metrics.

## Installation

```bash
pip install telescope-ui
```

Requires Python 3.11+.

## Quick start

```bash
wandb login    # authenticate with W&B (once)
telescope      # starts the dashboard at http://localhost:8005
```

Telescope automatically discovers runs tagged with `telescope` in your W&B projects. The default training config already includes this tag, so runs appear in the UI automatically.

| Flag | Description |
|------|-------------|
| `--port PORT` | Port to serve on (default: 8005) |
| `--host HOST` | Host to bind to (default: 127.0.0.1) |
| `--no-browser` | Don't open the browser automatically |
| `--debug` | Enable verbose logging |

## Documentation

Full documentation at [docs.telescope.training](https://docs.telescope.training).

## Pages

### Overview

The landing page shows training progress bars, a customizable grid of metric charts (reward, time per step, grad norm, etc.), the full run configuration with cross-run comparison, and the training source code with diffs between runs.

### Metrics

All training metrics as real-time charts, organized into sections: custom metrics, reward, samples metrics, advantage, evals, rollouts, discarded rollouts, and timeline breakdowns. A custom view lets you build your own drag-and-drop dashboard layout that persists across sessions. Each chart supports EMA smoothing, outlier filtering, and manual y-axis ranges. Multiple runs are overlaid on the same charts for comparison.

### Rollouts

Browse every sample the model generated during training. Samples are organized by step and prompt group, showing prompts, completions, rewards, advantages, and golden answers. Supports multi-turn conversations and agentic environments with alternating assistant/tool turns. Render toggles for think blocks, markdown, LaTeX, and code. A companion metrics sidebar lets you correlate generations with training dynamics. A separate **Discarded Rollouts** page shows samples thrown away due to async staleness or zero advantage.

### Timeline

A Gantt-chart visualization of the full system — inference servers, orchestrator, and trainer GPUs — showing how they overlap in time. Inference requests appear as horizontal bars across concurrent lanes, color-coded by type. Trainer operations (forward, backward, loss, optimizer, weight broadcast) are shown per GPU rank. Click any event for a duration breakdown of sub-operations. Useful for identifying bottlenecks like trainer idle time, weight broadcast delays, or wasted compute on discarded samples.

### Infra

Hardware and system-level monitoring with three tabs:
- **Metrics** — GPU utilization, memory, temperature, power, PyTorch-level stats, CPU metrics, and vLLM server stats (queue depth, KV cache, throughput, latencies), filterable by role and node
- **Topology** — visual cluster map showing nodes, GPUs, role assignments, and hardware details
- **Model** — model architecture visualization with layer structure and parameter layout

### Evals

Inspect evaluation results at each eval step. Same sample viewer as Rollouts, adapted for eval data. Supports pass@k with expandable completions per prompt. Eval-specific metric charts in the sidebar track scores over training.

## Data storage

All synced data is stored locally at `~/.telescope/`. Override with the `TELESCOPE_DATA_DIR` environment variable. Database compression is available through the sidebar menu and can reduce size by 20-30%.

## License

MIT
