# SalesHub CLI

Command-line tool for managing SalesCode SalesHub deployments.

## Installation

```bash
pip install saleshub-cli
```

## Quick Start

```bash
# Configure your SalesHub instance
saleshub config set-url https://api.salescodeai.com
saleshub config set-tenant your-tenant-id

# Login
saleshub login

# Use the CLI
saleshub --help
```

## Features

- 🔐 Authentication & tenant management
- 📦 Data ingestion (products, outlets, distributors, etc.)
- 📊 Order management
- 🔄 Integration batch processing
- 📡 Real-time log streaming
- ⚙️ Settings management

## Development

```bash
# Clone and install in dev mode
git clone https://github.com/salescode-tools/saleshub-cli.git
cd saleshub-cli
pip install -e .

# Run
saleshub --help
```

## License

MIT
