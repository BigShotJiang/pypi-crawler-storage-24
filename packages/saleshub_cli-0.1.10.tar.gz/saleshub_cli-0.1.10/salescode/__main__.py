from salescode.cli import cli; cli()
