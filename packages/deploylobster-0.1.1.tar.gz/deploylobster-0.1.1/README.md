# deploylobster

DeployLobster CLI for preflight checks and deployment helpers.

## What it does today

- checks whether Docker is installed
- checks whether Docker Compose is installed

## Install

    pip install deploylobster

## Usage

    deploylobster
