import shutil
import subprocess
import sys


def check_command(command, label):
    try:
        subprocess.run(
            command,
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        print(f"✅ {label}")
        return True
    except Exception:
        print(f"❌ {label}")
        return False


def main():
    print("DeployLobster preflight")
    print("-----------------------")

    docker_path = shutil.which("docker")

    if docker_path is None:
        print("❌ Docker installed")
        print("❌ Docker Compose installed")
        docker_ok = False
        compose_ok = False
    else:
        docker_ok = check_command(["docker", "--version"], "Docker installed")
        compose_ok = check_command(["docker", "compose", "version"], "Docker Compose installed")

    print()
    print("This package currently provides basic host preflight checks.")
    print("More deployment helpers will be added in future releases.")

    return 0 if docker_ok and compose_ok else 1


if __name__ == "__main__":
    sys.exit(main())
