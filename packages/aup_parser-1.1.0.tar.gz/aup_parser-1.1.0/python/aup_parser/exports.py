from __future__ import annotations

import sqlite3
import struct
from pathlib import Path

try:
    import fcntl
except ImportError:  # pragma: no cover - platform-specific
    fcntl = None

from .types import (
    AudioOutputFileTD,
    AudioOutputResultTD,
    ClipWaveBlockRefTD,
    ProjectParsedTD,
    SampleFormatInfoTD,
)


def _safe_int(value: object) -> int | None:
    try:
        if value is None:
            return None
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        if isinstance(value, float):
            if not value.is_integer():
                return None
            return int(value)
        if isinstance(value, str):
            stripped = value.strip()
            if not stripped:
                return None
            return int(stripped)
        return int(value)
    except Exception:
        return None


def _safe_float(value: object) -> float | None:
    try:
        if value is None:
            return None
        if isinstance(value, bool):
            return float(int(value))
        if isinstance(value, (int, float)):
            return float(value)
        if isinstance(value, str):
            stripped = value.strip()
            if not stripped:
                return None
            return float(stripped)
        return float(value)
    except Exception:
        return None


def _sampleformat_to_description(sampleformat: int) -> SampleFormatInfoTD:
    return {
        "raw": sampleformat,
        "sample_width_bytes": sampleformat >> 16,
        "encoding_id": sampleformat & 0xFFFF,
    }


def _extract_channel_block_refs(project_parsed: ProjectParsedTD | None) -> dict[int, list[tuple[int, int]]]:
    if project_parsed is None:
        return {}

    channel_wave_blocks = project_parsed.get("channel_wave_blocks")
    if channel_wave_blocks is None:
        return {}

    channel_map: dict[int, list[tuple[int, int]]] = {}
    for item in channel_wave_blocks:
        channel = _safe_int(item.get("channel"))
        blockid = _safe_int(item.get("blockid"))
        start = _safe_int(item.get("start"))
        if channel is None or blockid is None or start is None:
            continue
        channel_map.setdefault(channel, []).append((start, blockid))

    ordered: dict[int, list[tuple[int, int]]] = {}
    for channel, refs in channel_map.items():
        unique = sorted(set(refs), key=lambda pair: (pair[0], pair[1]))
        ordered[channel] = unique
    return ordered


def _extract_clip_block_refs(project_parsed: ProjectParsedTD | None) -> dict[int, list[ClipWaveBlockRefTD]]:
    if project_parsed is None:
        return {}

    clip_wave_blocks = project_parsed.get("clip_wave_blocks")
    if clip_wave_blocks is None:
        return {}

    channel_map: dict[int, list[ClipWaveBlockRefTD]] = {}
    for item in clip_wave_blocks:
        channel = _safe_int(item.get("channel"))
        blockid = _safe_int(item.get("blockid"))
        block_start = _safe_int(item.get("block_start"))
        if channel is None or blockid is None or block_start is None:
            continue
        channel_map.setdefault(channel, []).append(item)

    ordered: dict[int, list[ClipWaveBlockRefTD]] = {}
    for channel, refs in channel_map.items():
        ordered[channel] = sorted(
            refs,
            key=lambda item: (
                _safe_float(item.get("clip_offset")) or 0.0,
                _safe_int(item.get("block_start")) or 0,
                _safe_int(item.get("blockid")) or 0,
            ),
        )
    return ordered


def _resolve_project_sample_rate(project_parsed: ProjectParsedTD | None) -> float | None:
    if project_parsed is None:
        return None
    parsed_rate = _safe_float(project_parsed.get("sample_rate"))
    if parsed_rate is None or parsed_rate <= 0:
        return None
    return parsed_rate


def _resolve_track_sample_rate(project_parsed: ProjectParsedTD | None) -> float | None:
    if project_parsed is None:
        return None
    tracks = project_parsed.get("wave_tracks")
    if not isinstance(tracks, list):
        return None

    rates: list[float] = []
    for track in tracks:
        if not isinstance(track, dict):
            continue
        rate = _safe_float(track.get("rate"))
        if rate is None or rate <= 0:
            continue
        if not any(abs(rate - known) < 1e-6 for known in rates):
            rates.append(rate)

    if not rates:
        return None
    if len(rates) > 1:
        raise ValueError(
            "Multiple wavetrack.rate values found "
            f"({rates}); cannot determine one export sample rate."
        )
    return rates[0]


def _write_wav_file(
    output_path: Path,
    payload: bytes,
    channel_count: int,
    sample_width: int,
    wav_format_code: int,
    sample_rate: int,
) -> int:
    data_len = len(payload)
    if data_len > 0xFFFFFFFF:
        raise ValueError("WAV payload is too large for RIFF container.")
    block_align = channel_count * sample_width
    byte_rate = sample_rate * block_align
    bits_per_sample = sample_width * 8
    if byte_rate > 0xFFFFFFFF:
        raise ValueError("WAV byte_rate overflow.")
    riff_chunk_size = data_len + 36
    if riff_chunk_size > 0xFFFFFFFF:
        raise ValueError("WAV chunk size overflow.")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("wb") as wav_file:
        wav_file.write(b"RIFF")
        wav_file.write(struct.pack("<I", riff_chunk_size))
        wav_file.write(b"WAVE")
        wav_file.write(b"fmt ")
        wav_file.write(struct.pack("<I", 16))
        wav_file.write(struct.pack("<H", wav_format_code))
        wav_file.write(struct.pack("<H", channel_count))
        wav_file.write(struct.pack("<I", sample_rate))
        wav_file.write(struct.pack("<I", byte_rate))
        wav_file.write(struct.pack("<H", block_align))
        wav_file.write(struct.pack("<H", bits_per_sample))
        wav_file.write(b"data")
        wav_file.write(struct.pack("<I", data_len))
        wav_file.write(payload)
    return len(payload)


def _disable_output_file_cache(file_obj) -> None:
    if fcntl is None or not hasattr(fcntl, "F_NOCACHE"):
        return
    try:
        fcntl.fcntl(file_obj.fileno(), fcntl.F_NOCACHE, 1)
    except OSError:
        # Cache hints are best-effort and should not break export.
        return


def _make_unique_directory_candidate(path: Path) -> Path:
    if not path.exists() or path.is_dir():
        return path

    base = path.parent / f"{path.stem}_channels"
    candidate = base
    index = 2
    while candidate.exists() and not candidate.is_dir():
        candidate = path.parent / f"{base.name}_{index}"
        index += 1
    return candidate


def _resolve_multichannel_output_dir(audio_output_path: Path) -> tuple[Path, bool]:
    # UX rule:
    # - if user passes file-like path (e.g. out.wav), map to out_channels/ directory.
    # - if user passes directory-like path, use as-is.
    requested = audio_output_path
    if requested.suffix:
        candidate = requested.parent / f"{requested.stem}_channels"
        return _make_unique_directory_candidate(candidate), True
    return _make_unique_directory_candidate(requested), False


def _resolve_single_channel_output_dir(audio_output_path: Path) -> Path:
    if audio_output_path.suffix:
        candidate = audio_output_path.parent / (audio_output_path.stem or "output")
        return _make_unique_directory_candidate(candidate)
    return _make_unique_directory_candidate(audio_output_path)


def _resolve_single_channel_output_file(audio_output_path: Path, file_name: str) -> Path:
    return _resolve_single_channel_output_dir(audio_output_path) / file_name


def _has_known_audio_extension(name: str) -> bool:
    lowered = name.lower()
    return any(
        lowered.endswith(ext)
        for ext in (
            ".wav",
            ".mp3",
            ".flac",
            ".aac",
            ".m4a",
            ".ogg",
            ".aif",
            ".aiff",
            ".wma",
            ".opus",
        )
    )


def _strip_known_audio_extension(name: str) -> str:
    lowered = name.lower()
    for ext in (".wav", ".mp3", ".flac", ".aac", ".m4a", ".ogg", ".aif", ".aiff", ".wma", ".opus"):
        if lowered.endswith(ext) and len(name) > len(ext):
            return name[: -len(ext)]
    return name


def _extract_original_audio_output_base(project_parsed: ProjectParsedTD | None) -> str | None:
    if project_parsed is None:
        return None

    preferred: list[str] = []
    fallback: list[str] = []

    for key in ("wave_clips_preview", "wave_tracks"):
        items = project_parsed.get(key)
        if not isinstance(items, list):
            continue
        for item in items:
            if not isinstance(item, dict):
                continue
            name = item.get("name")
            if not isinstance(name, str):
                continue
            trimmed = name.strip()
            if not trimmed:
                continue
            if _has_known_audio_extension(trimmed):
                preferred.append(trimmed)
            else:
                fallback.append(trimmed)

    for name in preferred + fallback:
        base = _sanitize_filename_component(_strip_known_audio_extension(name))
        if base:
            return base
    return None


def _sanitize_filename_component(raw: str) -> str:
    sanitized = "".join(ch if (ch.isalnum() or ch in "-_") else "_" for ch in raw)
    normalized = sanitized.strip("_")
    return normalized or "channel"


def _extract_channel_track_names(project_parsed: ProjectParsedTD | None) -> dict[int, str]:
    if project_parsed is None:
        return {}
    tracks = project_parsed.get("wave_tracks")
    if not isinstance(tracks, list):
        return {}

    names: dict[int, str] = {}
    for track in tracks:
        if not isinstance(track, dict):
            continue
        channel = _safe_int(track.get("channel"))
        name = track.get("name")
        if channel is None or not isinstance(name, str) or not name.strip():
            continue
        names.setdefault(channel, _sanitize_filename_component(name))
    return names


def _make_output_filename(
    channel: int,
    channel_track_names: dict[int, str],
    seen_names: dict[str, int],
) -> str:
    base = channel_track_names.get(channel, f"channel_{channel:02d}")
    count = seen_names.get(base, 0)
    seen_names[base] = count + 1
    if count == 0:
        return f"{base}.wav"
    return f"{base}_{count}.wav"


def _render_channel_timeline(
    refs: list[tuple[int, int]],
    block_samples: dict[int, bytes],
    sample_width: int,
) -> tuple[bytes, bool]:
    fragments: list[tuple[int, bytes]] = []
    for start_sample, block_id in sorted(refs, key=lambda pair: (pair[0], pair[1])):
        payload = block_samples.get(block_id)
        if payload is None:
            raise ValueError(f"Timeline references missing blockid in sampleblocks: blockid={block_id}")
        fragments.append((start_sample, payload))
    return _render_timeline_fragments(fragments, sample_width)


def _render_timeline_fragments(fragments: list[tuple[int, bytes]], sample_width: int) -> tuple[bytes, bool]:
    if not fragments:
        return (b"", False)

    sorted_fragments = sorted(fragments, key=lambda pair: pair[0])
    max_end_sample = 0
    normalized: list[tuple[int, bytes, int]] = []
    for start_sample, payload in sorted_fragments:
        if start_sample < 0:
            raise ValueError(f"Negative start sample in timeline refs: start={start_sample}")
        if len(payload) % sample_width != 0:
            raise ValueError(
                "Block payload byte length is not divisible by sample width: "
                f"bytes={len(payload)}, sample_width={sample_width}"
            )
        block_sample_count = len(payload) // sample_width
        end_sample = start_sample + block_sample_count
        max_end_sample = max(max_end_sample, end_sample)
        normalized.append((start_sample, payload, block_sample_count))

    timeline = bytearray(max_end_sample * sample_width)
    overlap_detected = False
    previous_end = 0
    for start_sample, payload, block_sample_count in normalized:
        if start_sample < previous_end:
            overlap_detected = True
        start_byte = start_sample * sample_width
        end_byte = start_byte + (block_sample_count * sample_width)
        timeline[start_byte:end_byte] = payload
        previous_end = max(previous_end, start_sample + block_sample_count)

    return (bytes(timeline), overlap_detected)


def _fragment_sample_count(fragment: tuple[int, int, int, int], sample_width: int) -> int:
    return (fragment[3] - fragment[2]) // sample_width


def _build_channel_fragments(
    refs: list[tuple[int, int]],
    block_sizes: dict[int, int],
    sample_width: int,
) -> tuple[list[tuple[int, int, int, int]], bool]:
    fragments: list[tuple[int, int, int, int]] = []
    overlap_detected = False
    previous_end = 0

    for start_sample, block_id in sorted(refs, key=lambda pair: (pair[0], pair[1])):
        block_size = block_sizes.get(block_id)
        if block_size is None:
            raise ValueError(f"Timeline references missing blockid in sampleblocks: blockid={block_id}")
        if block_size % sample_width != 0:
            raise ValueError(
                "Block payload byte length is not divisible by sample width: "
                f"bytes={block_size}, sample_width={sample_width}"
            )

        fragment = (start_sample, block_id, 0, block_size)
        fragment_sample_count = _fragment_sample_count(fragment, sample_width)
        if start_sample < previous_end:
            overlap_detected = True
            resolved = _apply_later_fragment_precedence(
                fragments=fragments,
                incoming_fragment=fragment,
                sample_width=sample_width,
            )
            fragments = resolved
            previous_end = fragments[-1][0] + _fragment_sample_count(fragments[-1], sample_width)
            continue

        fragments.append(fragment)
        previous_end = start_sample + fragment_sample_count

    return (fragments, overlap_detected)


def _apply_later_fragment_precedence(
    fragments: list[tuple[int, int, int, int]],
    incoming_fragment: tuple[int, int, int, int],
    sample_width: int,
) -> list[tuple[int, int, int, int]]:
    if not fragments:
        return [incoming_fragment]

    resolved = list(fragments)
    incoming_start = incoming_fragment[0]
    while resolved:
        previous_fragment = resolved[-1]
        previous_end = previous_fragment[0] + _fragment_sample_count(previous_fragment, sample_width)
        if incoming_start >= previous_end:
            break

        keep_sample_count = max(0, incoming_start - previous_fragment[0])
        if keep_sample_count == 0:
            resolved.pop()
            continue

        resolved[-1] = (
            previous_fragment[0],
            previous_fragment[1],
            previous_fragment[2],
            previous_fragment[2] + keep_sample_count * sample_width,
        )
        break

    resolved.append(incoming_fragment)
    return resolved


def _apply_clip_overlap_precedence(
    fragments: list[tuple[int, bytes]],
    sample_width: int,
) -> tuple[list[tuple[int, bytes]], bool]:
    ordered = sorted(fragments, key=lambda pair: pair[0])
    resolved: list[tuple[int, bytes]] = []
    overlap_detected = False
    previous_end = 0

    for start_sample, payload in ordered:
        if len(payload) % sample_width != 0:
            raise ValueError(
                "Block payload byte length is not divisible by sample width: "
                f"bytes={len(payload)}, sample_width={sample_width}"
            )
        sample_count = len(payload) // sample_width
        if sample_count <= 0:
            continue

        if start_sample < previous_end:
            overlap_detected = True
            skip_samples = min(previous_end - start_sample, sample_count)
            if skip_samples >= sample_count:
                continue
            payload = payload[skip_samples * sample_width :]
            start_sample = previous_end
            sample_count -= skip_samples

        resolved.append((start_sample, payload))
        previous_end = start_sample + sample_count

    return (resolved, overlap_detected)


def _apply_clip_overlap_precedence_fragments(
    fragments: list[tuple[int, int, int, int]],
    sample_width: int,
) -> tuple[list[tuple[int, int, int, int]], bool]:
    ordered = sorted(fragments, key=lambda pair: pair[0])
    resolved: list[tuple[int, int, int, int]] = []
    overlap_detected = False
    previous_end = 0

    for start_sample, block_id, source_from, source_to in ordered:
        if (source_to - source_from) % sample_width != 0:
            raise ValueError(
                "Block payload byte length is not divisible by sample width: "
                f"bytes={source_to - source_from}, sample_width={sample_width}"
            )
        sample_count = (source_to - source_from) // sample_width
        if sample_count <= 0:
            continue

        if start_sample < previous_end:
            overlap_detected = True
            skip_samples = min(previous_end - start_sample, sample_count)
            if skip_samples >= sample_count:
                continue
            source_from += skip_samples * sample_width
            start_sample = previous_end
            sample_count -= skip_samples

        resolved.append((start_sample, block_id, source_from, source_from + sample_count * sample_width))
        previous_end = start_sample + sample_count

    return (resolved, overlap_detected)


def _render_channel_from_clip_refs(
    refs: list[ClipWaveBlockRefTD],
    block_samples: dict[int, bytes],
    sample_width: int,
    project_sample_rate: float,
) -> tuple[bytes, bool, bool]:
    fragments: list[tuple[int, bytes]] = []
    unsupported_stretch = False

    for item in refs:
        block_id = _safe_int(item.get("blockid"))
        block_start = _safe_int(item.get("block_start"))
        if block_id is None or block_start is None:
            continue

        stretch_ratio = _safe_float(item.get("clip_stretch_ratio"))
        if stretch_ratio is not None and stretch_ratio > 0.0 and abs(stretch_ratio - 1.0) > 1e-9:
            unsupported_stretch = True
            continue

        payload = block_samples.get(block_id)
        if payload is None:
            raise ValueError(f"Clip references missing blockid in sampleblocks: blockid={block_id}")
        if len(payload) % sample_width != 0:
            raise ValueError(
                f"Block payload byte length is not divisible by sample width: blockid={block_id}, "
                f"bytes={len(payload)}, sample_width={sample_width}"
            )

        block_sample_count = len(payload) // sample_width
        block_end = block_start + block_sample_count

        trim_left_seconds = _safe_float(item.get("clip_trim_left")) or 0.0
        trim_right_seconds = _safe_float(item.get("clip_trim_right")) or 0.0
        clip_offset_seconds = _safe_float(item.get("clip_offset")) or 0.0
        clip_numsamples = _safe_int(item.get("clip_numsamples"))

        trim_left_samples = max(int(round(max(trim_left_seconds, 0.0) * project_sample_rate)), 0)
        trim_right_samples = max(int(round(max(trim_right_seconds, 0.0) * project_sample_rate)), 0)
        # Audacity's waveclip `offset` is sequence start time, not play start time.
        # Play start is quantized from (offset + trimLeft).
        clip_play_start_samples = int(
            round((clip_offset_seconds + max(trim_left_seconds, 0.0)) * project_sample_rate)
        )

        visible_start = trim_left_samples
        visible_end: int | None = None
        if clip_numsamples is not None and clip_numsamples >= 0:
            visible_end = clip_numsamples - trim_right_samples
            if visible_end < 0:
                visible_end = 0
            if visible_start > visible_end:
                visible_start = visible_end

        include_start = max(block_start, visible_start)
        include_end = block_end if visible_end is None else min(block_end, visible_end)
        if include_end <= include_start:
            continue

        source_from = (include_start - block_start) * sample_width
        source_to = (include_end - block_start) * sample_width
        timeline_start = clip_play_start_samples + (include_start - visible_start)
        if timeline_start < 0:
            available = include_end - include_start
            skip_samples = min(-timeline_start, available)
            if skip_samples >= available:
                continue
            source_from += skip_samples * sample_width
            timeline_start += skip_samples
        if source_from >= source_to:
            continue
        fragments.append((timeline_start, payload[source_from:source_to]))

    resolved_fragments, overlap_detected = _apply_clip_overlap_precedence(fragments, sample_width)
    stream, _ = _render_timeline_fragments(resolved_fragments, sample_width)
    return (stream, overlap_detected, unsupported_stretch)


def _build_channel_fragments_from_clip_refs(
    refs: list[ClipWaveBlockRefTD],
    block_sizes: dict[int, int],
    sample_width: int,
    project_sample_rate: float,
) -> tuple[list[tuple[int, int, int, int]], bool, bool]:
    fragments: list[tuple[int, int, int, int]] = []
    unsupported_stretch = False

    for item in refs:
        block_id = _safe_int(item.get("blockid"))
        block_start = _safe_int(item.get("block_start"))
        if block_id is None or block_start is None:
            continue

        stretch_ratio = _safe_float(item.get("clip_stretch_ratio"))
        if stretch_ratio is not None and stretch_ratio > 0.0 and abs(stretch_ratio - 1.0) > 1e-9:
            unsupported_stretch = True
            continue

        block_size = block_sizes.get(block_id)
        if block_size is None:
            raise ValueError(f"Clip references missing blockid in sampleblocks: blockid={block_id}")
        if block_size % sample_width != 0:
            raise ValueError(
                f"Block payload byte length is not divisible by sample width: blockid={block_id}, "
                f"bytes={block_size}, sample_width={sample_width}"
            )

        block_sample_count = block_size // sample_width
        block_end = block_start + block_sample_count

        trim_left_seconds = _safe_float(item.get("clip_trim_left")) or 0.0
        trim_right_seconds = _safe_float(item.get("clip_trim_right")) or 0.0
        clip_offset_seconds = _safe_float(item.get("clip_offset")) or 0.0
        clip_numsamples = _safe_int(item.get("clip_numsamples"))

        trim_left_samples = max(int(round(max(trim_left_seconds, 0.0) * project_sample_rate)), 0)
        trim_right_samples = max(int(round(max(trim_right_seconds, 0.0) * project_sample_rate)), 0)
        clip_play_start_samples = int(
            round((clip_offset_seconds + max(trim_left_seconds, 0.0)) * project_sample_rate)
        )

        visible_start = trim_left_samples
        visible_end: int | None = None
        if clip_numsamples is not None and clip_numsamples >= 0:
            visible_end = clip_numsamples - trim_right_samples
            if visible_end < 0:
                visible_end = 0
            if visible_start > visible_end:
                visible_start = visible_end

        include_start = max(block_start, visible_start)
        include_end = block_end if visible_end is None else min(block_end, visible_end)
        if include_end <= include_start:
            continue

        source_from = (include_start - block_start) * sample_width
        source_to = (include_end - block_start) * sample_width
        timeline_start = clip_play_start_samples + (include_start - visible_start)
        if timeline_start < 0:
            available = include_end - include_start
            skip_samples = min(-timeline_start, available)
            if skip_samples >= available:
                continue
            source_from += skip_samples * sample_width
            timeline_start += skip_samples
        if source_from >= source_to:
            continue

        fragments.append((timeline_start, block_id, source_from, source_to))

    resolved_fragments, overlap_detected = _apply_clip_overlap_precedence_fragments(fragments, sample_width)
    return (resolved_fragments, overlap_detected, unsupported_stretch)


def _resolve_timeline_data_length(
    fragments: list[tuple[int, int, int, int]],
    sample_width: int,
) -> int:
    if not fragments:
        return 0

    max_end_sample = max(
        fragment[0] + _fragment_sample_count(fragment, sample_width)
        for fragment in fragments
    )
    return max_end_sample * sample_width


def _write_wav_header(
    wav_file,
    *,
    data_len: int,
    channel_count: int,
    sample_width: int,
    wav_format_code: int,
    sample_rate: int,
) -> None:
    if data_len > 0xFFFFFFFF:
        raise ValueError("WAV payload is too large for RIFF container.")
    block_align = channel_count * sample_width
    byte_rate = sample_rate * block_align
    bits_per_sample = sample_width * 8
    if byte_rate > 0xFFFFFFFF:
        raise ValueError("WAV byte_rate overflow.")
    riff_chunk_size = data_len + 36
    if riff_chunk_size > 0xFFFFFFFF:
        raise ValueError("WAV chunk size overflow.")

    wav_file.write(b"RIFF")
    wav_file.write(struct.pack("<I", riff_chunk_size))
    wav_file.write(b"WAVE")
    wav_file.write(b"fmt ")
    wav_file.write(struct.pack("<I", 16))
    wav_file.write(struct.pack("<H", wav_format_code))
    wav_file.write(struct.pack("<H", channel_count))
    wav_file.write(struct.pack("<I", sample_rate))
    wav_file.write(struct.pack("<I", byte_rate))
    wav_file.write(struct.pack("<H", block_align))
    wav_file.write(struct.pack("<H", bits_per_sample))
    wav_file.write(b"data")
    wav_file.write(struct.pack("<I", data_len))


def _build_silence_chunk(length: int, *, sample_width: int, wav_format_code: int) -> bytes:
    if length <= 0:
        return b""
    if wav_format_code == 1 and sample_width == 1:
        return b"\x80" * length
    return b"\x00" * length


def _write_silence(
    wav_file,
    *,
    byte_length: int,
    sample_width: int,
    wav_format_code: int,
    chunk_size: int = 1024 * 1024,
) -> None:
    if byte_length <= 0:
        return

    remaining = byte_length
    while remaining > 0:
        next_size = min(remaining, chunk_size)
        wav_file.write(
            _build_silence_chunk(
                next_size,
                sample_width=sample_width,
                wav_format_code=wav_format_code,
            )
        )
        remaining -= next_size


def _write_blob_range(
    wav_file,
    *,
    conn: sqlite3.Connection,
    row_id: int,
    source_from: int = 0,
    source_to: int | None = None,
    chunk_size: int = 1024 * 1024,
) -> int:
    written = 0
    with conn.blobopen("sampleblocks", "samples", row_id, readonly=True) as blob:
        blob_len = len(blob)
        end = blob_len if source_to is None else min(source_to, blob_len)
        if source_from < 0 or source_from > end:
            raise ValueError(
                f"Requested blob slice is out of bounds: row_id={row_id}, "
                f"source_from={source_from}, source_to={source_to}, blob_len={blob_len}"
            )

        blob.seek(source_from)
        remaining = end - source_from
        while remaining > 0:
            chunk = blob.read(min(remaining, chunk_size))
            if not chunk:
                raise ValueError(
                    f"Unexpected EOF while reading sampleblocks blob: row_id={row_id}, remaining={remaining}"
                )
            wav_file.write(chunk)
            chunk_len = len(chunk)
            written += chunk_len
            remaining -= chunk_len

    return written


def _write_timeline_fragments_to_wav(
    output_path: Path,
    *,
    fragments: list[tuple[int, int, int, int]],
    conn: sqlite3.Connection,
    block_rows: dict[int, tuple[int, int]],
    sample_width: int,
    wav_format_code: int,
    sample_rate: int,
) -> int:
    data_len = _resolve_timeline_data_length(fragments, sample_width)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("wb") as wav_file:
        _disable_output_file_cache(wav_file)
        _write_wav_header(
            wav_file,
            data_len=data_len,
            channel_count=1,
            sample_width=sample_width,
            wav_format_code=wav_format_code,
            sample_rate=sample_rate,
        )
        current_sample = 0
        for start_sample, block_id, source_from, source_to in fragments:
            if start_sample > current_sample:
                _write_silence(
                    wav_file,
                    byte_length=(start_sample - current_sample) * sample_width,
                    sample_width=sample_width,
                    wav_format_code=wav_format_code,
                )

            row_info = block_rows.get(block_id)
            if row_info is None:
                raise ValueError(f"sampleblocks row metadata does not exist for blockid={block_id}")
            row_id, _ = row_info
            bytes_written = _write_blob_range(
                wav_file,
                conn=conn,
                row_id=row_id,
                source_from=source_from,
                source_to=source_to,
            )
            current_sample = start_sample + (bytes_written // sample_width)
    return data_len


def _write_overlapping_timeline_fragments_to_wav(
    output_path: Path,
    *,
    fragments: list[tuple[int, int, int, int]],
    conn: sqlite3.Connection,
    block_rows: dict[int, tuple[int, int]],
    sample_width: int,
    wav_format_code: int,
    sample_rate: int,
) -> int:
    data_len = _resolve_timeline_data_length(fragments, sample_width)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w+b") as wav_file:
        _disable_output_file_cache(wav_file)
        _write_wav_header(
            wav_file,
            data_len=data_len,
            channel_count=1,
            sample_width=sample_width,
            wav_format_code=wav_format_code,
            sample_rate=sample_rate,
        )
        data_offset = wav_file.tell()
        _write_silence(
            wav_file,
            byte_length=data_len,
            sample_width=sample_width,
            wav_format_code=wav_format_code,
        )

        for start_sample, block_id, source_from, source_to in fragments:
            row_info = block_rows.get(block_id)
            if row_info is None:
                raise ValueError(f"sampleblocks row metadata does not exist for blockid={block_id}")
            row_id, _ = row_info
            wav_file.seek(data_offset + (start_sample * sample_width))
            _write_blob_range(
                wav_file,
                conn=conn,
                row_id=row_id,
                source_from=source_from,
                source_to=source_to,
            )

    return data_len


def _write_block_sequence_to_wav(
    output_path: Path,
    *,
    block_ids: list[int],
    block_sizes: dict[int, int],
    conn: sqlite3.Connection,
    block_rows: dict[int, tuple[int, int]],
    sample_width: int,
    wav_format_code: int,
    sample_rate: int,
) -> int:
    data_len = sum(block_sizes.get(block_id, 0) for block_id in block_ids)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("wb") as wav_file:
        _disable_output_file_cache(wav_file)
        _write_wav_header(
            wav_file,
            data_len=data_len,
            channel_count=1,
            sample_width=sample_width,
            wav_format_code=wav_format_code,
            sample_rate=sample_rate,
        )
        for block_id in block_ids:
            row_info = block_rows.get(block_id)
            if row_info is None:
                raise ValueError(f"sampleblocks row metadata does not exist for blockid={block_id}")
            row_id, _ = row_info
            _write_blob_range(wav_file, conn=conn, row_id=row_id)
    return data_len


def export_audio_output(
    aup3_path: Path,
    audio_output_path: Path,
    project_parsed: ProjectParsedTD | None,
) -> AudioOutputResultTD:
    with sqlite3.connect(str(aup3_path)) as conn:
        metadata_cursor = conn.cursor()
        metadata_cursor.execute(
            "SELECT rowid, blockid, sampleformat, LENGTH(samples) FROM sampleblocks ORDER BY blockid"
        )
        saw_rows = False
        sampleformat_values: set[int | None] = set()
        block_sizes: dict[int, int] = {}
        block_rows: dict[int, tuple[int, int]] = {}
        blockid_order: list[int] = []
        for row_id, blockid, sampleformat_raw, sample_length in metadata_cursor:
            saw_rows = True
            sampleformat_values.add(_safe_int(sampleformat_raw))
            row_id_int = _safe_int(row_id)
            blockid_int = _safe_int(blockid)
            sample_length_int = _safe_int(sample_length)
            if row_id_int is None or blockid_int is None or sample_length_int is None:
                continue
            block_sizes[blockid_int] = sample_length_int
            block_rows[blockid_int] = (row_id_int, sample_length_int)
            blockid_order.append(blockid_int)

        if not saw_rows:
            raise ValueError("No sampleblocks found to export audio.")

        if len(sampleformat_values) != 1:
            values = sorted(value for value in sampleformat_values if value is not None)
            raise ValueError(f"Expected one sampleformat, found: {values}")

        sampleformat = next(iter(sampleformat_values)) or 0
        sample_width = sampleformat >> 16
        encoding_id = sampleformat & 0xFFFF
        if sample_width not in (1, 2, 3, 4):
            raise ValueError(f"Unsupported sample width from sampleformat={sampleformat}.")
        if encoding_id == 1:
            wav_format_code = 1
        elif encoding_id in (3, 15) and sample_width == 4:
            wav_format_code = 3
        elif encoding_id in (3, 15):
            raise ValueError(
                f"Unsupported float sample width from sampleformat={sampleformat}. Expected 4-byte float."
            )
        else:
            raise ValueError(
                f"Unsupported sampleformat encoding_id={encoding_id} from sampleformat={sampleformat}."
            )

        channel_block_refs = _extract_channel_block_refs(project_parsed)
        clip_block_refs = _extract_clip_block_refs(project_parsed)
        track_sample_rate_raw = _resolve_track_sample_rate(project_parsed)
        project_sample_rate_raw = _resolve_project_sample_rate(project_parsed)
        if track_sample_rate_raw is not None and track_sample_rate_raw > 0:
            resolved_sample_rate = int(round(track_sample_rate_raw))
        elif project_sample_rate_raw is not None and project_sample_rate_raw > 0:
            resolved_sample_rate = int(round(project_sample_rate_raw))
        else:
            raise ValueError(
                "sample rate metadata is unavailable in wavetrack.rate and project sample_rate."
            )
        clip_timeline_sample_rate = (
            track_sample_rate_raw
            if track_sample_rate_raw is not None and track_sample_rate_raw > 0
            else (
                project_sample_rate_raw
                if project_sample_rate_raw is not None and project_sample_rate_raw > 0
                else float(resolved_sample_rate)
            )
        )
        used_project_rate_for_clip_alignment = (
            (track_sample_rate_raw is None or track_sample_rate_raw <= 0)
            and project_sample_rate_raw is not None
            and project_sample_rate_raw > 0
        )

        sorted_channels = sorted(set(channel_block_refs.keys()) | set(clip_block_refs.keys()))
        channel_track_names = _extract_channel_track_names(project_parsed)
        overlap_channels: list[int] = []
        used_channel_timeline_renderer = False
        used_clip_timeline_renderer = False
        clip_channels_with_stretch: list[int] = []
        sampleformat_info = _sampleformat_to_description(sampleformat)

        if len(sorted_channels) >= 2:
            output_dir, normalized = _resolve_multichannel_output_dir(audio_output_path)
            output_dir.mkdir(parents=True, exist_ok=True)
            files: list[AudioOutputFileTD] = []
            total_written = 0
            seen_names: dict[str, int] = {}

            for channel in sorted_channels:
                fragments: list[tuple[int, int, int, int]] = []
                rendered = False
                used_clip_fragments = False

                clip_refs = clip_block_refs.get(channel)
                if clip_refs:
                    fragments, overlap_detected, unsupported_stretch = _build_channel_fragments_from_clip_refs(
                        clip_refs,
                        block_sizes,
                        sample_width,
                        clip_timeline_sample_rate,
                    )
                    if unsupported_stretch:
                        clip_channels_with_stretch.append(channel)
                    if fragments:
                        rendered = True
                        used_clip_fragments = True
                        used_clip_timeline_renderer = True
                        if overlap_detected:
                            overlap_channels.append(channel)

                if not rendered and channel in channel_block_refs:
                    used_channel_timeline_renderer = True
                    fragments, overlap_detected = _build_channel_fragments(
                        channel_block_refs[channel],
                        block_sizes,
                        sample_width,
                    )
                    if fragments and overlap_detected:
                        overlap_channels.append(channel)

                if not fragments:
                    continue

                file_path = output_dir / _make_output_filename(
                    channel,
                    channel_track_names,
                    seen_names,
                )
                if overlap_detected and not used_clip_fragments:
                    written = _write_overlapping_timeline_fragments_to_wav(
                        file_path,
                        fragments=fragments,
                        conn=conn,
                        block_rows=block_rows,
                        sample_width=sample_width,
                        wav_format_code=wav_format_code,
                        sample_rate=resolved_sample_rate,
                    )
                else:
                    written = _write_timeline_fragments_to_wav(
                        file_path,
                        fragments=fragments,
                        conn=conn,
                        block_rows=block_rows,
                        sample_width=sample_width,
                        wav_format_code=wav_format_code,
                        sample_rate=resolved_sample_rate,
                    )
                total_written += written
                files.append(
                    {
                        "channel": channel,
                        "audio_path": str(file_path),
                        "written_audio_bytes": written,
                    }
                )

            if clip_channels_with_stretch:
                channels = sorted(set(clip_channels_with_stretch))
                raise ValueError(
                    "Exact restoration is not supported for non-unity clip stretch ratio "
                    f"in channels={channels}."
                )

            return {
                "mode": "multi_channel_folder",
                "requested_output_path": str(audio_output_path),
                "output_path": str(output_dir),
                "path_was_normalized": normalized,
                "channel_count": len(files),
                "files": files,
                "sample_rate": resolved_sample_rate,
                "sample_width_bytes": sample_width,
                "wav_format_code": wav_format_code,
                "sampleformat": sampleformat_info,
                "total_written_audio_bytes": total_written,
                "note": (
                    "Multi-channel project exported as one mono WAV per channel using timeline placement."
                    if not normalized
                    else (
                        "Multi-channel project exported as one mono WAV per channel using timeline placement. "
                        f"Requested path was normalized to directory: {output_dir}"
                    )
                )
                + (
                    ""
                    if not used_clip_timeline_renderer
                    else " Clip metadata (offset/trim) was applied where available."
                )
                + (
                    ""
                    if not used_project_rate_for_clip_alignment
                    else " wavetrack.rate metadata was unavailable; used project sample_rate for clip alignment."
                )
                + (
                    ""
                    if not overlap_channels
                    else (
                        " Overlap detected in channels="
                        f"{overlap_channels}; overlapping regions were resolved with deterministic clip precedence."
                    )
                ),
            }

        single_channel = sorted_channels[0] if len(sorted_channels) == 1 else 0
        fragments: list[tuple[int, int, int, int]] = []
        note: str
        used_clip_fragments = False

        if len(sorted_channels) == 1:
            clip_refs = clip_block_refs.get(single_channel)
            if clip_refs:
                fragments, overlap_detected, unsupported_stretch = _build_channel_fragments_from_clip_refs(
                    clip_refs,
                    block_sizes,
                    sample_width,
                    clip_timeline_sample_rate,
                )
                if unsupported_stretch:
                    raise ValueError(
                        "Exact restoration is not supported for non-unity clip stretch ratio "
                        f"in channels={[single_channel]}."
                    )
                if fragments:
                    used_clip_fragments = True
                    used_clip_timeline_renderer = True
                    note = "Single-channel timeline WAV export."
                    if used_project_rate_for_clip_alignment:
                        note += " wavetrack.rate metadata was unavailable; used project sample_rate for clip alignment."
                    if overlap_detected:
                        note += (
                            " Overlap detected in channels="
                            f"{[single_channel]}; overlapping regions were resolved with deterministic clip precedence."
                        )
                else:
                    note = "Single-channel fallback WAV export by blockid order."
            else:
                note = "Single-channel fallback WAV export by blockid order."

            if not fragments and single_channel in channel_block_refs:
                used_channel_timeline_renderer = True
                fragments, overlap_detected = _build_channel_fragments(
                    channel_block_refs[single_channel],
                    block_sizes,
                    sample_width,
                )
                if fragments:
                    note = "Single-channel timeline WAV export."
                    if overlap_detected:
                        note += (
                            " Overlap detected in channels="
                            f"{[single_channel]}; later blocks overwrite earlier samples."
                        )

        if not fragments:
            note = (
                "Single-channel fallback WAV export by blockid order because channel timeline refs were unavailable."
                if not (used_channel_timeline_renderer or used_clip_timeline_renderer)
                else "Single-channel fallback WAV export by blockid order."
            )

        default_output_file_name = _make_output_filename(
            single_channel,
            channel_track_names,
            {},
        )
        output_base = _extract_original_audio_output_base(project_parsed)
        output_file_name = f"{output_base}.wav" if output_base is not None else default_output_file_name
        output_file = _resolve_single_channel_output_file(audio_output_path, output_file_name)

        if fragments:
            if overlap_detected and not used_clip_fragments:
                written = _write_overlapping_timeline_fragments_to_wav(
                    output_file,
                    fragments=fragments,
                    conn=conn,
                    block_rows=block_rows,
                    sample_width=sample_width,
                    wav_format_code=wav_format_code,
                    sample_rate=resolved_sample_rate,
                )
            else:
                written = _write_timeline_fragments_to_wav(
                    output_file,
                    fragments=fragments,
                    conn=conn,
                    block_rows=block_rows,
                    sample_width=sample_width,
                    wav_format_code=wav_format_code,
                    sample_rate=resolved_sample_rate,
                )
        else:
            written = _write_block_sequence_to_wav(
                output_file,
                block_ids=blockid_order,
                block_sizes=block_sizes,
                conn=conn,
                block_rows=block_rows,
                sample_width=sample_width,
                wav_format_code=wav_format_code,
                sample_rate=resolved_sample_rate,
            )

        return {
            "mode": "single_file",
            "requested_output_path": str(audio_output_path),
            "output_path": str(output_file),
            "path_was_normalized": output_file != audio_output_path,
            "channel_count": 1,
            "files": [
                {
                    "channel": 0,
                    "audio_path": str(output_file),
                    "written_audio_bytes": written,
                }
            ],
            "sample_rate": resolved_sample_rate,
            "sample_width_bytes": sample_width,
            "wav_format_code": wav_format_code,
            "sampleformat": sampleformat_info,
            "total_written_audio_bytes": written,
            "note": note,
        }
