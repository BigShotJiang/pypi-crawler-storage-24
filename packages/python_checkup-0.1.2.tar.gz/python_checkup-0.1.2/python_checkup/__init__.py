from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("python-checkup")
except PackageNotFoundError:
    # Fallback for local source execution without installed metadata.
    __version__ = "0.1.0"

__all__ = ["__version__"]
