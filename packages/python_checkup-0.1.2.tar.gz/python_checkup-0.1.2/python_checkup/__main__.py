from python_checkup.cli import main

main()
