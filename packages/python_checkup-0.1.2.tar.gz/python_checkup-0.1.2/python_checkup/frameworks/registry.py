from __future__ import annotations

import importlib.metadata
import logging
from collections.abc import Iterator
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from python_checkup.detection import FrameworkStack
    from python_checkup.frameworks import FrameworkPlugin

logger = logging.getLogger("python_checkup")

# Module-level cache populated on first call to discover_framework_plugins().
_PLUGIN_CACHE: list[FrameworkPlugin] | None = None


def discover_framework_plugins(*, reload: bool = False) -> list[FrameworkPlugin]:
    """Return all registered framework plugins.

    On the first call the list is built from built-in plugins plus any
    external plugins installed via the ``python_checkup.frameworks``
    entry-point group.  Subsequent calls return the cached list.

    Args:
        reload: If True, clear the cache and re-discover.  Useful in tests.
    """
    global _PLUGIN_CACHE  # noqa: PLW0603

    if _PLUGIN_CACHE is not None and not reload:
        return _PLUGIN_CACHE

    plugins: list[FrameworkPlugin] = list(_BUILTIN_PLUGINS)

    # External plugins registered via entry points
    eps = importlib.metadata.entry_points(group="python_checkup.frameworks")
    for ep in eps:
        try:
            plugin_cls = ep.load()
            plugin = plugin_cls()
            from python_checkup.frameworks import FrameworkPlugin as _Proto

            if isinstance(plugin, _Proto):
                plugins.append(plugin)
                logger.debug("Loaded framework plugin: %s (%s)", ep.name, ep.value)
            else:
                logger.warning(
                    "Framework plugin %s (%s) does not implement "
                    "FrameworkPlugin — skipped",
                    ep.name,
                    ep.value,
                )
        except Exception as exc:  # noqa: BLE001 PERF203
            logger.warning("Failed to load framework plugin %s: %s", ep.name, exc)

    _PLUGIN_CACHE = plugins
    return plugins


def get_plugins_for_stack(stack: FrameworkStack) -> list[FrameworkPlugin]:
    """Return only the plugins whose framework is in *stack*.

    Convenient helper used by analyzers (ruff, vulture, deptry, mypy) so
    they don't have to filter manually.
    """
    if not stack or not stack.all_frameworks:
        return []
    active_names = stack.names
    return [p for p in discover_framework_plugins() if p.name in active_names]


# ---------------------------------------------------------------------------
# Lazy-load built-in plugins (avoids circular imports at module load time)
# ---------------------------------------------------------------------------


def _load_builtin_plugins() -> list[FrameworkPlugin]:
    """Instantiate all built-in plugin classes."""
    # Import here to avoid circular-import issues at module init time.
    from python_checkup.frameworks.aiohttp import AiohttpPlugin
    from python_checkup.frameworks.celery import CeleryPlugin
    from python_checkup.frameworks.click import ClickPlugin
    from python_checkup.frameworks.django import DjangoPlugin
    from python_checkup.frameworks.dramatiq import DramatiqPlugin
    from python_checkup.frameworks.drf import DRFPlugin
    from python_checkup.frameworks.fastapi import FastAPIPlugin
    from python_checkup.frameworks.flask import FlaskPlugin
    from python_checkup.frameworks.pydantic import PydanticPlugin
    from python_checkup.frameworks.pytest_fw import PytestPlugin
    from python_checkup.frameworks.sqlalchemy import SQLAlchemyPlugin
    from python_checkup.frameworks.starlette import StarlettePlugin
    from python_checkup.frameworks.typer import TyperPlugin

    return [
        DjangoPlugin(),
        FastAPIPlugin(),
        FlaskPlugin(),
        CeleryPlugin(),
        SQLAlchemyPlugin(),
        PydanticPlugin(),
        PytestPlugin(),
        DRFPlugin(),
        StarlettePlugin(),
        ClickPlugin(),
        TyperPlugin(),
        AiohttpPlugin(),
        DramatiqPlugin(),
    ]


# Populated lazily via a module-level property-like call on first access.
# We use a sentinel so that tests that reload() get fresh instances.
class _LazyBuiltins(list):  # type: ignore[type-arg]
    """A list that loads its items on first iteration/access."""

    _loaded = False

    def _ensure_loaded(self) -> None:
        if not self._loaded:
            self.extend(_load_builtin_plugins())
            self._loaded = True

    def __iter__(self) -> Iterator[FrameworkPlugin]:
        self._ensure_loaded()
        return super().__iter__()

    def __len__(self) -> int:
        self._ensure_loaded()
        return super().__len__()

    def __getitem__(self, index: int) -> FrameworkPlugin:  # type: ignore[override]
        self._ensure_loaded()
        return super().__getitem__(index)  # type: ignore[no-any-return]


_BUILTIN_PLUGINS: list[FrameworkPlugin] = _LazyBuiltins()
