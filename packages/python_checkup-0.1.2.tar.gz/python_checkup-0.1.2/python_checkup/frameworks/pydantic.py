from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from python_checkup.analyzers.vulture_whitelists import (
    PYDANTIC_WHITELIST,
    WhitelistEntry,
)
from python_checkup.detection import (
    DetectionContext,
    FrameworkCategory,
    FrameworkInfo,
    _detect_pydantic,
)
from python_checkup.frameworks import StubsInfo

if TYPE_CHECKING:
    from python_checkup.models import Diagnostic


class PydanticPlugin:
    """Built-in Pydantic validation support."""

    @property
    def name(self) -> str:
        return "pydantic"

    @property
    def category(self) -> FrameworkCategory:
        return FrameworkCategory.VALIDATION

    def detect(self, context: DetectionContext) -> tuple[float, str | None]:
        return _detect_pydantic(context)

    def get_vulture_whitelist(self) -> list[WhitelistEntry]:
        return list(PYDANTIC_WHITELIST)

    def get_ruff_rules(self) -> list[str]:
        return []

    def get_implicit_dependencies(self) -> set[str]:
        return set()

    def check(
        self,
        root: Path,
        files: list[Path],
        framework: FrameworkInfo,
    ) -> list[Diagnostic]:
        return []  # No Pydantic-specific framework checks yet

    def get_stubs_info(self) -> StubsInfo | None:
        return StubsInfo(mypy_plugin="pydantic.mypy")
