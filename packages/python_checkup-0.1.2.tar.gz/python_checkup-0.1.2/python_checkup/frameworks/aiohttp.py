from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from python_checkup.analyzers.vulture_whitelists import WhitelistEntry
from python_checkup.detection import (
    DetectionContext,
    FrameworkCategory,
    FrameworkInfo,
    _detect_aiohttp,
)
from python_checkup.frameworks import StubsInfo

if TYPE_CHECKING:
    from python_checkup.models import Diagnostic


class AiohttpPlugin:
    """Built-in aiohttp framework support."""

    @property
    def name(self) -> str:
        return "aiohttp"

    @property
    def category(self) -> FrameworkCategory:
        return FrameworkCategory.WEB

    def detect(self, context: DetectionContext) -> tuple[float, str | None]:
        return _detect_aiohttp(context)

    def get_vulture_whitelist(self) -> list[WhitelistEntry]:
        return []

    def get_ruff_rules(self) -> list[str]:
        return ["ASYNC"]

    def get_implicit_dependencies(self) -> set[str]:
        return set()

    def check(
        self,
        root: Path,
        files: list[Path],
        framework: FrameworkInfo,
    ) -> list[Diagnostic]:
        return []

    def get_stubs_info(self) -> StubsInfo | None:
        return None
