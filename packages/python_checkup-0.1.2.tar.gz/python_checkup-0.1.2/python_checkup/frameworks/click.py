from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from python_checkup.analyzers.vulture_whitelists import WhitelistEntry
from python_checkup.detection import (
    DetectionContext,
    FrameworkCategory,
    FrameworkInfo,
    _detect_click,
)
from python_checkup.frameworks import StubsInfo

if TYPE_CHECKING:
    from python_checkup.models import Diagnostic


class ClickPlugin:
    """Built-in Click CLI framework support."""

    @property
    def name(self) -> str:
        return "click"

    @property
    def category(self) -> FrameworkCategory:
        return FrameworkCategory.CLI

    def detect(self, context: DetectionContext) -> tuple[float, str | None]:
        return _detect_click(context)

    def get_vulture_whitelist(self) -> list[WhitelistEntry]:
        return []

    def get_ruff_rules(self) -> list[str]:
        return []

    def get_implicit_dependencies(self) -> set[str]:
        return set()

    def check(
        self,
        root: Path,
        files: list[Path],
        framework: FrameworkInfo,
    ) -> list[Diagnostic]:
        return []

    def get_stubs_info(self) -> StubsInfo | None:
        return None
