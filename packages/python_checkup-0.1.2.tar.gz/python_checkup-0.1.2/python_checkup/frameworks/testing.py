from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from python_checkup.detection import (
    _CONFIDENCE_THRESHOLD,
    DetectionContext,
    FrameworkInfo,
)

if TYPE_CHECKING:
    from python_checkup.frameworks import FrameworkPlugin
    from python_checkup.models import Diagnostic


def assert_detects_framework(
    plugin: FrameworkPlugin,
    project_root: Path,
    expected_confidence_min: float = _CONFIDENCE_THRESHOLD,
) -> FrameworkInfo:
    """Assert that *plugin* detects its framework in *project_root*.

    Args:
        plugin: The plugin to test.
        project_root: Directory to scan (use ``tmp_path`` in tests).
        expected_confidence_min: Minimum accepted confidence (default: 0.5).

    Returns:
        The ``FrameworkInfo`` that would be added to the stack.

    Raises:
        AssertionError: If confidence is below the threshold.
    """
    context = DetectionContext.build(project_root)
    confidence, version = plugin.detect(context)
    if confidence < expected_confidence_min:
        raise AssertionError(
            f"Plugin '{plugin.name}' returned confidence {confidence:.2f}, "
            f"expected >= {expected_confidence_min}.  "
            f"Project root: {project_root}"
        )
    return FrameworkInfo(
        name=plugin.name,
        version=version,
        confidence=min(confidence, 1.0),
        category=plugin.category,
    )


def assert_check_finds(
    plugin: FrameworkPlugin,
    project_root: Path,
    expected_rule_ids: list[str],
) -> list[Diagnostic]:
    """Assert that *plugin.check()* produces at least the listed rule IDs.

    Args:
        plugin: The plugin to test.
        project_root: Directory containing source files.
        expected_rule_ids: Rule IDs that must appear in the results.

    Returns:
        All diagnostics produced by the plugin's checker.

    Raises:
        AssertionError: If any expected rule ID is absent.
    """
    files = list(project_root.rglob("*.py"))
    framework = FrameworkInfo(
        name=plugin.name,
        version=None,
        confidence=1.0,
        category=plugin.category,
    )
    diagnostics = plugin.check(project_root, files, framework)
    found_ids = {d.rule_id for d in diagnostics}
    missing = [rid for rid in expected_rule_ids if rid not in found_ids]
    if missing:
        raise AssertionError(
            f"Plugin '{plugin.name}' did not produce expected rule IDs: {missing}.\n"
            f"Produced: {sorted(found_ids)}"
        )
    return diagnostics


def assert_whitelist_suppresses(
    plugin: FrameworkPlugin,
    diagnostic_names: list[str],
    expected_suppressed: list[str],
) -> None:
    """Assert that the plugin's whitelist suppresses the expected symbol names.

    Args:
        plugin: The plugin to test.
        diagnostic_names: Vulture symbol names to check (e.g. "get_queryset").
        expected_suppressed: Names that should be suppressed by the whitelist.

    Raises:
        AssertionError: If any expected name is not suppressed.
    """
    whitelist = plugin.get_vulture_whitelist()
    not_suppressed = []
    for name in expected_suppressed:
        matched = any(entry.matches(name, "function") for entry in whitelist)
        if not matched:
            not_suppressed.append(name)
    if not_suppressed:
        raise AssertionError(
            f"Plugin '{plugin.name}' whitelist does not suppress: {not_suppressed}"
        )
