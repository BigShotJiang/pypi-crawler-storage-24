from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from python_checkup.analyzers.vulture_whitelists import FLASK_WHITELIST, WhitelistEntry
from python_checkup.detection import (
    DetectionContext,
    FrameworkCategory,
    FrameworkInfo,
    _detect_flask,
)
from python_checkup.frameworks import StubsInfo

if TYPE_CHECKING:
    from python_checkup.models import Diagnostic


class FlaskPlugin:
    """Built-in Flask framework support."""

    @property
    def name(self) -> str:
        return "flask"

    @property
    def category(self) -> FrameworkCategory:
        return FrameworkCategory.WEB

    def detect(self, context: DetectionContext) -> tuple[float, str | None]:
        return _detect_flask(context)

    def get_vulture_whitelist(self) -> list[WhitelistEntry]:
        return list(FLASK_WHITELIST)

    def get_ruff_rules(self) -> list[str]:
        return ["S201"]

    def get_implicit_dependencies(self) -> set[str]:
        from python_checkup.analyzers.deptry import _FRAMEWORK_IMPLICIT_DEPS

        return set(_FRAMEWORK_IMPLICIT_DEPS.get("flask", set()))

    def check(
        self,
        root: Path,
        files: list[Path],
        framework: FrameworkInfo,
    ) -> list[Diagnostic]:
        from python_checkup.analyzers.framework_checks import _check_flask

        return _check_flask(root, files, framework)

    def get_stubs_info(self) -> StubsInfo | None:
        return None  # Flask ships inline types
