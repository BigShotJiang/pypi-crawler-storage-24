from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from python_checkup.analyzers.vulture_whitelists import CELERY_WHITELIST, WhitelistEntry
from python_checkup.detection import (
    DetectionContext,
    FrameworkCategory,
    FrameworkInfo,
    _detect_celery,
)
from python_checkup.frameworks import StubsInfo

if TYPE_CHECKING:
    from python_checkup.models import Diagnostic


class CeleryPlugin:
    """Built-in Celery task-queue support."""

    @property
    def name(self) -> str:
        return "celery"

    @property
    def category(self) -> FrameworkCategory:
        return FrameworkCategory.TASK_QUEUE

    def detect(self, context: DetectionContext) -> tuple[float, str | None]:
        return _detect_celery(context)

    def get_vulture_whitelist(self) -> list[WhitelistEntry]:
        return list(CELERY_WHITELIST)

    def get_ruff_rules(self) -> list[str]:
        return []

    def get_implicit_dependencies(self) -> set[str]:
        from python_checkup.analyzers.deptry import _FRAMEWORK_IMPLICIT_DEPS

        return set(_FRAMEWORK_IMPLICIT_DEPS.get("celery", set()))

    def check(
        self,
        root: Path,
        files: list[Path],
        framework: FrameworkInfo,
    ) -> list[Diagnostic]:
        from python_checkup.analyzers.framework_checks import _check_celery

        return _check_celery(root, files, framework)

    def get_stubs_info(self) -> StubsInfo | None:
        return None
