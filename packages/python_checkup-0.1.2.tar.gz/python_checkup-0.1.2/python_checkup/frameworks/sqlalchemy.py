from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from python_checkup.analyzers.vulture_whitelists import (
    SQLALCHEMY_WHITELIST,
    WhitelistEntry,
)
from python_checkup.detection import (
    DetectionContext,
    FrameworkCategory,
    FrameworkInfo,
    _detect_sqlalchemy,
)
from python_checkup.frameworks import StubsInfo

if TYPE_CHECKING:
    from python_checkup.models import Diagnostic


class SQLAlchemyPlugin:
    """Built-in SQLAlchemy ORM support."""

    @property
    def name(self) -> str:
        return "sqlalchemy"

    @property
    def category(self) -> FrameworkCategory:
        return FrameworkCategory.ORM

    def detect(self, context: DetectionContext) -> tuple[float, str | None]:
        return _detect_sqlalchemy(context)

    def get_vulture_whitelist(self) -> list[WhitelistEntry]:
        return list(SQLALCHEMY_WHITELIST)

    def get_ruff_rules(self) -> list[str]:
        return []

    def get_implicit_dependencies(self) -> set[str]:
        return set()

    def check(
        self,
        root: Path,
        files: list[Path],
        framework: FrameworkInfo,
    ) -> list[Diagnostic]:
        from python_checkup.analyzers.framework_checks import _check_sqlalchemy

        return _check_sqlalchemy(root, files, framework)

    def get_stubs_info(self) -> StubsInfo:
        return StubsInfo(
            stubs_package="sqlalchemy-stubs",
            mypy_plugin="sqlalchemy.ext.mypy.plugin",
        )
