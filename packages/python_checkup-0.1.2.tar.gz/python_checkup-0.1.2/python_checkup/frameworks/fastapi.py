from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from python_checkup.analyzers.vulture_whitelists import (
    FASTAPI_WHITELIST,
    WhitelistEntry,
)
from python_checkup.detection import (
    DetectionContext,
    FrameworkCategory,
    FrameworkInfo,
    _detect_fastapi,
)
from python_checkup.frameworks import StubsInfo

if TYPE_CHECKING:
    from python_checkup.models import Diagnostic


class FastAPIPlugin:
    """Built-in FastAPI framework support."""

    @property
    def name(self) -> str:
        return "fastapi"

    @property
    def category(self) -> FrameworkCategory:
        return FrameworkCategory.WEB

    def detect(self, context: DetectionContext) -> tuple[float, str | None]:
        return _detect_fastapi(context)

    def get_vulture_whitelist(self) -> list[WhitelistEntry]:
        return list(FASTAPI_WHITELIST)

    def get_ruff_rules(self) -> list[str]:
        return ["FAST", "ASYNC"]

    def get_implicit_dependencies(self) -> set[str]:
        from python_checkup.analyzers.deptry import _FRAMEWORK_IMPLICIT_DEPS

        return set(_FRAMEWORK_IMPLICIT_DEPS.get("fastapi", set()))

    def check(
        self,
        root: Path,
        files: list[Path],
        framework: FrameworkInfo,
    ) -> list[Diagnostic]:
        from python_checkup.analyzers.framework_checks import _check_fastapi

        return _check_fastapi(root, files, framework)

    def get_stubs_info(self) -> StubsInfo | None:
        return None  # FastAPI ships inline types; no separate stubs package
