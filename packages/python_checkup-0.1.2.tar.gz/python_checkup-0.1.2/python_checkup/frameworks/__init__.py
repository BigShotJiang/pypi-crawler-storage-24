from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Protocol, runtime_checkable

from python_checkup.analyzers.vulture_whitelists import WhitelistEntry
from python_checkup.detection import DetectionContext, FrameworkCategory, FrameworkInfo

if TYPE_CHECKING:
    from python_checkup.models import Diagnostic


@dataclass(frozen=True)
class StubsInfo:
    """Mypy stubs and plugin information for a framework.

    Used by the mypy analyzer to emit advisory diagnostics when stubs
    are absent and to configure the mypy plugin path.
    """

    stubs_package: str | None = None  # e.g. "django-stubs"
    mypy_plugin: str | None = None  # e.g. "mypy_django_plugin.main"
    config_keys: dict[str, str] = field(default_factory=dict)


@runtime_checkable
class FrameworkPlugin(Protocol):
    """Protocol every framework plugin must satisfy.

    Both built-in plugins (``python_checkup/frameworks/django.py`` etc.)
    and external plugins installed via entry points implement this.
    """

    @property
    def name(self) -> str:
        """Framework name, e.g. ``'django'``, ``'fastapi'``."""
        ...

    @property
    def category(self) -> FrameworkCategory:
        """Framework category (WEB, ORM, TASK_QUEUE, …)."""
        ...

    def detect(
        self,
        context: DetectionContext,
    ) -> tuple[float, str | None]:
        """Return ``(confidence, version)`` for this framework.

        Args:
            context: Pre-built scanning context (files, deps, installed pkgs).

        Returns:
            Confidence in [0.0, 1.0] and installed version string (or None).
        """
        ...

    def get_vulture_whitelist(self) -> list[WhitelistEntry]:
        """Whitelist entries that suppress framework-specific Vulture FPs."""
        ...

    def get_ruff_rules(self) -> list[str]:
        """Additional Ruff rule prefixes to enable (e.g. ``["DJ", "S610"]``)."""
        ...

    def get_implicit_dependencies(self) -> set[str]:
        """Package names used implicitly — deptry won't flag these as DEP002."""
        ...

    def check(
        self,
        root: Path,
        files: list[Path],
        framework: FrameworkInfo,
    ) -> list[Diagnostic]:
        """Run framework-specific checks and return diagnostics."""
        ...

    def get_stubs_info(self) -> StubsInfo | None:
        """Return mypy stubs/plugin info, or ``None`` if not applicable."""
        ...


__all__ = [
    "FrameworkPlugin",
    "FrameworkCategory",
    "DetectionContext",
    "FrameworkInfo",
    "StubsInfo",
    "WhitelistEntry",
]
