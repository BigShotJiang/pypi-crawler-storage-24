from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from python_checkup.analyzers.vulture_whitelists import DJANGO_WHITELIST, WhitelistEntry
from python_checkup.detection import (
    DetectionContext,
    FrameworkCategory,
    FrameworkInfo,
    _detect_drf,
)
from python_checkup.frameworks import StubsInfo

if TYPE_CHECKING:
    from python_checkup.models import Diagnostic


class DRFPlugin:
    """Built-in Django REST Framework support."""

    @property
    def name(self) -> str:
        return "drf"

    @property
    def category(self) -> FrameworkCategory:
        return FrameworkCategory.API

    def detect(self, context: DetectionContext) -> tuple[float, str | None]:
        return _detect_drf(context)

    def get_vulture_whitelist(self) -> list[WhitelistEntry]:
        return list(DJANGO_WHITELIST)  # DRF entries are included in Django's whitelist

    def get_ruff_rules(self) -> list[str]:
        return []

    def get_implicit_dependencies(self) -> set[str]:
        return set()

    def check(
        self,
        root: Path,
        files: list[Path],
        framework: FrameworkInfo,
    ) -> list[Diagnostic]:
        return []  # DRF checks covered by Django plugin

    def get_stubs_info(self) -> StubsInfo | None:
        return None

    def get_parent(self) -> str | None:
        return "django"
