from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from python_checkup.analyzers.vulture_whitelists import PYTEST_WHITELIST, WhitelistEntry
from python_checkup.detection import (
    DetectionContext,
    FrameworkCategory,
    FrameworkInfo,
    _detect_pytest,
)
from python_checkup.frameworks import StubsInfo

if TYPE_CHECKING:
    from python_checkup.models import Diagnostic


class PytestPlugin:
    """Built-in pytest testing support."""

    @property
    def name(self) -> str:
        return "pytest"

    @property
    def category(self) -> FrameworkCategory:
        return FrameworkCategory.TESTING

    def detect(self, context: DetectionContext) -> tuple[float, str | None]:
        return _detect_pytest(context)

    def get_vulture_whitelist(self) -> list[WhitelistEntry]:
        return list(PYTEST_WHITELIST)

    def get_ruff_rules(self) -> list[str]:
        return ["PT"]

    def get_implicit_dependencies(self) -> set[str]:
        from python_checkup.analyzers.deptry import _FRAMEWORK_IMPLICIT_DEPS

        return set(_FRAMEWORK_IMPLICIT_DEPS.get("pytest", set()))

    def check(
        self,
        root: Path,
        files: list[Path],
        framework: FrameworkInfo,
    ) -> list[Diagnostic]:
        return []  # pytest checks are handled via conftest.py suppression in Phase 2

    def get_stubs_info(self) -> StubsInfo | None:
        return None  # pytest ships inline types
