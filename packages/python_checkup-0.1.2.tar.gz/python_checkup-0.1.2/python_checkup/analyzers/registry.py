from __future__ import annotations

import logging
from importlib.metadata import entry_points

from python_checkup.analyzers import Analyzer

logger = logging.getLogger("python_checkup")


async def discover_analyzers() -> list[Analyzer]:
    """Discover all analyzers whose underlying tools are available.

    Loads built-in and third-party analyzers via entry points, verifies
    protocol conformance, checks availability, and returns only those
    that are ready to run.
    """
    eps = entry_points(group="python-checkup.analyzers")
    available: list[Analyzer] = []
    unavailable: list[str] = []

    for ep in eps:
        try:
            analyzer_cls = ep.load()
            analyzer = analyzer_cls()

            # Verify the plugin satisfies the Analyzer protocol
            if not isinstance(analyzer, Analyzer):
                logger.warning(
                    "Plugin '%s' does not implement the Analyzer protocol, skipping",
                    ep.name,
                )
                unavailable.append(ep.name)
                continue

            if await analyzer.is_available():
                available.append(analyzer)
                logger.debug("Analyzer available: %s", ep.name)
            else:
                unavailable.append(ep.name)
                logger.debug("Analyzer not available: %s", ep.name)
        except Exception:
            logger.debug("Failed to load analyzer plugin '%s'", ep.name, exc_info=True)
            unavailable.append(ep.name)

    return available


async def get_analyzer(name: str) -> Analyzer | None:
    """Load a specific analyzer by name."""
    eps = entry_points(group="python-checkup.analyzers")
    for ep in eps:
        if ep.name == name:
            try:
                analyzer_cls = ep.load()
                analyzer = analyzer_cls()

                if not isinstance(analyzer, Analyzer):
                    logger.warning(
                        "Plugin '%s' does not implement the Analyzer protocol",
                        name,
                    )
                    return None

                if await analyzer.is_available():
                    return analyzer
            except Exception:
                logger.debug("Failed to load analyzer '%s'", name, exc_info=True)
    return None
