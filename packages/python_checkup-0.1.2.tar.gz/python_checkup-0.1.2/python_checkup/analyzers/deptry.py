from __future__ import annotations

import ast
import asyncio
import json
import logging
import shutil
from pathlib import Path

from python_checkup.analysis_request import AnalysisRequest
from python_checkup.models import Category, Diagnostic, Severity

# Packages that are used implicitly (not imported) by a framework — deptry
# would otherwise flag them as DEP002 (unused dependency).
_FRAMEWORK_IMPLICIT_DEPS: dict[str, set[str]] = {
    "django": {
        "django-extensions",
        "django_extensions",
        "django-cors-headers",
        "django_cors_headers",
        "corsheaders",
        "django-filter",
        "django_filters",
        "django-debug-toolbar",
        "debug_toolbar",
        "django-storages",
        "storages",
        "whitenoise",
        "django-celery-beat",
        "django_celery_beat",
        "django-celery-results",
        "django_celery_results",
        "django-allauth",
        "allauth",
        "djangorestframework",
        "rest_framework",
        "psycopg2",
        "psycopg2-binary",
        "psycopg",
        "mysqlclient",
        "gunicorn",
        "uvicorn",
        "uvicorn-worker",
        "dj-database-url",
        "dj_database_url",
    },
    "fastapi": {
        "uvicorn",
        "gunicorn",
        "python-multipart",  # Required for form/file uploads
        "python-jose",
        "python_jose",
        "passlib",
        "httpx",  # Used by TestClient
        "starlette",  # FastAPI dependency, might show as unused
    },
    "flask": {
        "gunicorn",
        "waitress",
        "python-dotenv",
        "dotenv",
        "flask-wtf",
        "flask_wtf",
        "flask-login",
        "flask_login",
        "flask-migrate",
        "flask_migrate",
        "flask-sqlalchemy",
        "flask_sqlalchemy",
    },
    "celery": {
        "redis",
        "kombu",
        "flower",
        "billiard",
        "amqp",
        "vine",
    },
    "pytest": {
        "pytest-cov",
        "pytest_cov",
        "pytest-asyncio",
        "pytest_asyncio",
        "pytest-mock",
        "pytest_mock",
        "pytest-xdist",
        "pytest_xdist",
        "pytest-env",
        "pytest_env",
        "pytest-django",
        "pytest_django",
        "pytest-flask",
        "pytest_flask",
        "pytest-httpx",
        "pytest_httpx",
        "factory-boy",
        "factory_boy",
        "faker",
        "freezegun",
        "responses",
        "httpretty",
        "anyio",
    },
}

logger = logging.getLogger("python_checkup")

# Error code descriptions and severity mappings
DEPTRY_CODES: dict[str, tuple[str, Severity]] = {
    "DEP001": ("Missing dependency", Severity.ERROR),
    "DEP002": ("Unused dependency", Severity.WARNING),
    "DEP003": ("Transitive dependency", Severity.WARNING),
    "DEP004": ("Misplaced dev dependency", Severity.WARNING),
}


class DeptryAnalyzer:
    """Check for unused, missing, and transitive dependencies."""

    @property
    def name(self) -> str:
        return "deptry"

    @property
    def category(self) -> Category:
        return Category.DEPENDENCIES

    async def is_available(self) -> bool:
        """Check if deptry is on PATH."""
        return shutil.which("deptry") is not None

    async def analyze(
        self,
        request: AnalysisRequest,
    ) -> list[Diagnostic]:
        """Run deptry with JSON output.

        deptry analyzes the project root, not individual files.
        """
        config = request.config_dict()
        project_root = str(request.project_root)

        cmd = ["deptry", project_root, "--json-output", "/dev/stdout"]

        timeout: int = 30
        if "timeout" in config and isinstance(config["timeout"], int | float):
            timeout = int(config["timeout"])

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(),
                timeout=timeout,
            )
        except asyncio.TimeoutError:
            logger.warning("deptry timed out")
            return []
        except FileNotFoundError:
            logger.warning("deptry not found")
            return []

        # deptry writes JSON to stdout via --json-output /dev/stdout
        output = stdout.decode()
        if not output.strip():
            return []

        try:
            issues: list[dict[str, object]] = json.loads(output)
        except json.JSONDecodeError:
            logger.error("Failed to parse deptry JSON")
            return []

        # Build implicit-dep set via plugin registry (Phase 6), falling back to
        # the hardcoded dict for any framework not covered by a plugin (Phase 3).
        implicit_deps: set[str] = set()
        if request.framework_stack and request.framework_stack.all_frameworks:
            from python_checkup.frameworks.registry import get_plugins_for_stack

            covered: set[str] = set()
            for plugin in get_plugins_for_stack(request.framework_stack):
                implicit_deps.update(plugin.get_implicit_dependencies())
                covered.add(plugin.name)
            # Fallback for any frameworks not in the registry
            for fw in request.framework_stack.all_frameworks:
                if fw.name not in covered:
                    implicit_deps.update(_FRAMEWORK_IMPLICIT_DEPS.get(fw.name, set()))
            if request.framework_stack.has("django"):
                implicit_deps.update(_parse_django_installed_apps(request.project_root))

        diagnostics: list[Diagnostic] = []
        for issue in issues:
            if not isinstance(issue, dict):
                continue

            error = issue.get("error", {})
            if not isinstance(error, dict):
                error = {}
            code = str(error.get("code", "DEP000"))

            # Skip DEP002 (unused dep) for known framework-implicit packages
            if code == "DEP002" and implicit_deps:
                module = str(issue.get("module", ""))
                normalised = module.lower().replace("-", "_")
                if normalised in implicit_deps or module.lower() in implicit_deps:
                    logger.debug("Suppressed DEP002 for implicit dep: %s", module)
                    continue

            location = issue.get("location", {})
            if not isinstance(location, dict):
                location = {}
            module = str(issue.get("module", "unknown"))

            desc, severity = DEPTRY_CODES.get(
                code, ("Dependency issue", Severity.WARNING)
            )

            file_path = str(location.get("file", "pyproject.toml"))
            line_val = location.get("line")
            col_val = location.get("column")

            diagnostics.append(
                Diagnostic(
                    file_path=Path(file_path),
                    line=int(line_val) if isinstance(line_val, int | float) else 0,
                    column=int(col_val) if isinstance(col_val, int | float) else 0,
                    severity=severity,
                    rule_id=code,
                    tool="deptry",
                    category=Category.DEPENDENCIES,
                    message=f"{desc}: {module}",
                    fix=_fix_suggestion(code, module),
                )
            )

        return diagnostics


def _fix_suggestion(code: str, module: str) -> str:
    match code:
        case "DEP001":
            return f"Add '{module}' to your project dependencies in pyproject.toml"
        case "DEP002":
            return (
                f"Remove '{module}' from your project dependencies (it's not imported)"
            )
        case "DEP003":
            return (
                f"Add '{module}' as a direct dependency instead of "
                "relying on it transitively"
            )
        case "DEP004":
            return (
                f"Move '{module}' from dev dependencies to main dependencies "
                "(it's imported in non-dev code)"
            )
        case _:
            return f"Review the dependency '{module}'"


_SKIP_DIRS: frozenset[str] = frozenset(
    {"node_modules", "site-packages", "__pypackages__"}
)


def _parse_django_installed_apps(project_root: Path) -> set[str]:
    discovered: set[str] = set()
    for settings_path in project_root.rglob("*.py"):
        # Skip virtual environments, hidden directories, and dependency trees
        if any(
            part.startswith(".") or part in _SKIP_DIRS for part in settings_path.parts
        ):
            continue
        if settings_path.name != "settings.py" and "settings" not in settings_path.stem:
            continue
        discovered.update(_extract_installed_apps_from_file(settings_path))
    return discovered


def _extract_installed_apps_from_file(settings_path: Path) -> set[str]:
    try:
        source = settings_path.read_text(errors="ignore")
        tree = ast.parse(source, filename=str(settings_path))
    except (OSError, SyntaxError):
        return set()

    for node in ast.walk(tree):
        if isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id == "INSTALLED_APPS"
            for target in node.targets
        ):
            return _extract_installed_app_values(node.value)
    return set()


def _extract_installed_app_values(node: ast.AST) -> set[str]:
    if not isinstance(node, (ast.List, ast.Tuple)):
        return set()

    packages: set[str] = set()
    for item in node.elts:
        if not isinstance(item, ast.Constant) or not isinstance(item.value, str):
            continue
        package = _django_app_to_package(item.value)
        if package:
            packages.add(package)
    return packages


def _django_app_to_package(app_name: str) -> str | None:
    root = app_name.strip().split(".")[0].lower().replace("-", "_")
    if not root or root in {"django", "tests", "test"}:
        return None
    return root
