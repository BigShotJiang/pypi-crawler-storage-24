from __future__ import annotations

import ast
from dataclasses import dataclass
from pathlib import Path


@dataclass
class AssignmentInfo:
    """Information about a top-level assignment in a Python module."""

    name: str
    node: ast.expr  # The right-hand-side value node
    line: int


def parse_file(path: Path) -> ast.Module | None:
    """Parse a Python source file, returning None on error."""
    try:
        source = path.read_text(errors="ignore")
        return ast.parse(source, filename=str(path))
    except (OSError, SyntaxError):
        return None


def extract_assignments(tree: ast.Module) -> dict[str, AssignmentInfo]:
    """Extract all top-level (module-level) simple assignments.

    Handles ``X = ...``, ``X: T = ...`` but *not* augmented assignment.
    Returns a dict keyed by the target name.
    """
    result: dict[str, AssignmentInfo] = {}
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    result[target.id] = AssignmentInfo(
                        name=target.id,
                        node=node.value,
                        line=node.lineno,
                    )
        elif (
            isinstance(node, ast.AnnAssign)
            and isinstance(node.target, ast.Name)
            and node.value is not None
        ):
            result[node.target.id] = AssignmentInfo(
                name=node.target.id,
                node=node.value,
                line=node.lineno,
            )
    return result


def get_list_string_values(node: ast.expr) -> list[str]:
    """Extract string constants from a List or Tuple literal."""
    if not isinstance(node, (ast.List, ast.Tuple)):
        return []
    return [
        elt.value
        for elt in node.elts
        if isinstance(elt, ast.Constant) and isinstance(elt.value, str)
    ]


def has_decorator(
    node: ast.FunctionDef | ast.AsyncFunctionDef | ast.ClassDef,
    *decorator_names: str,
) -> bool:
    """Return True if the node has any of the given decorator names."""
    for dec in node.decorator_list:
        name = _decorator_base_name(dec)
        if name in decorator_names:
            return True
    return False


def get_keyword_value(call: ast.Call, keyword: str) -> ast.expr | None:
    """Return the value node for a keyword argument, or None."""
    for kw in call.keywords:
        if kw.arg == keyword:
            return kw.value
    return None


def is_truthy_constant(node: ast.expr | None) -> bool:
    """Return True if node is a constant that is truthy (True, non-zero, non-empty)."""
    if node is None:
        return False
    if isinstance(node, ast.Constant):
        return bool(node.value)
    return False


def is_falsy_constant(node: ast.expr | None) -> bool:
    """Return True if node is a constant that is falsy (False, 0, empty string)."""
    if node is None:
        return False
    if isinstance(node, ast.Constant):
        return not bool(node.value)
    return False


def is_string_constant(node: ast.expr | None) -> bool:
    return isinstance(node, ast.Constant) and isinstance(node.value, str)


def get_string_value(node: ast.expr | None) -> str | None:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    return None


def is_call_to(node: ast.expr, *func_names: str) -> bool:
    """Return True if node is a Call to one of func_names (simple name call)."""
    if not isinstance(node, ast.Call):
        return False
    fn = node.func
    return (isinstance(fn, ast.Name) and fn.id in func_names) or (
        isinstance(fn, ast.Attribute) and fn.attr in func_names
    )


def has_keyword_true(call: ast.Call, keyword: str) -> bool:
    """Return True if call has ``keyword=True``."""
    val = get_keyword_value(call, keyword)
    return is_truthy_constant(val)


def _decorator_base_name(node: ast.expr) -> str | None:
    match node:
        case ast.Name():
            return node.id
        case ast.Attribute():
            return node.attr
        case ast.Call():
            return _decorator_base_name(node.func)
        case _:
            return None
