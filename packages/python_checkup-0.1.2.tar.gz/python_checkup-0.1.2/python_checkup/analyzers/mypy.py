from __future__ import annotations

import asyncio
import importlib.metadata
import json
import logging
import re
from pathlib import Path

import tomllib

from python_checkup.analysis_request import AnalysisRequest
from python_checkup.models import Category, Diagnostic, Severity

logger = logging.getLogger("python_checkup")

# Fallback regex for mypy < 1.7 (no JSON output support)
MYPY_LINE_RE = re.compile(
    r"^(.+?):(\d+):(?:(\d+):)?\s*(error|warning|note):\s*(.+?)(?:\s+\[(.+)\])?$"
)


class MypyAnalyzer:
    """Type checking via mypy."""

    @property
    def name(self) -> str:
        return "mypy"

    @property
    def category(self) -> Category:
        return Category.TYPE_SAFETY

    async def is_available(self) -> bool:
        """Check if mypy is importable."""
        try:
            import mypy.api  # noqa: F401

            return True
        except ImportError:
            return False

    async def analyze(
        self,
        request: AnalysisRequest,
    ) -> list[Diagnostic]:
        """Run mypy on the given files.

        Strategy:
        1. Try --output json first (mypy 1.7+)
        2. If that flag is unrecognized, fall back to text parsing
        3. Run in a thread pool since mypy.api.run() is blocking
        """
        files = request.files
        config = request.config_dict()

        if not files:
            return []

        timeout: int = 60
        if "timeout" in config and isinstance(config["timeout"], int | float):
            timeout = int(config["timeout"])

        # Build args for mypy.api.run()
        args = self._build_args(files, use_json=True)

        loop = asyncio.get_running_loop()

        try:
            stdout, stderr, exit_code = await asyncio.wait_for(
                loop.run_in_executor(None, self._run_mypy, args),
                timeout=timeout,
            )
        except asyncio.TimeoutError:
            logger.warning("mypy timed out after %ds", timeout)
            return []

        # Exit code 2 = fatal error (bad args, can't find files, etc.)
        if exit_code == 2:
            # Check if it's because --output json isn't supported
            if "unrecognized" in stderr.lower() or "error: argument" in stderr.lower():
                logger.debug(
                    "mypy doesn't support --output json, falling back to text parsing"
                )
                args = self._build_args(files, use_json=False)
                try:
                    stdout, stderr, exit_code = await asyncio.wait_for(
                        loop.run_in_executor(None, self._run_mypy, args),
                        timeout=timeout,
                    )
                except asyncio.TimeoutError:
                    logger.warning("mypy timed out after %ds (fallback)", timeout)
                    return []

                if exit_code == 2:
                    logger.error("mypy fatal error: %s", stderr)
                    return _parse_mypy_fatal_errors(stderr)
                diagnostics = self._parse_text_output(stdout)
                if request.framework_stack:
                    diagnostics.extend(
                        _check_framework_stubs(
                            request.framework_stack,
                            request.project_root,
                        )
                    )
                return diagnostics

            # Check if it's a missing mypy plugin (not installed in our env)
            plugin_match = _PLUGIN_IMPORT_RE.search(stderr)
            if plugin_match:
                plugin_name = plugin_match.group(1)
                missing_module = plugin_match.group(2)
                logger.warning(
                    "mypy plugin %r not available (missing %s), "
                    "retrying without project config",
                    plugin_name,
                    missing_module,
                )
                advisory = Diagnostic(
                    file_path=Path("pyproject.toml"),
                    line=0,
                    column=0,
                    severity=Severity.INFO,
                    rule_id="mypy-plugin-unavailable",
                    tool="mypy",
                    category=Category.TYPE_SAFETY,
                    message=(
                        f"mypy plugin '{plugin_name}' is not installed in "
                        f"python-checkup's environment (missing '{missing_module}'). "
                        "Type checking ran without the project's mypy config."
                    ),
                    fix=(
                        "This is expected when running via uvx. "
                        "The plugin provides better type inference for your "
                        "framework but is not required."
                    ),
                )
                # Retry without project config so mypy doesn't try to load the plugin
                args = self._build_args(files, use_json=True, skip_config=True)
                try:
                    stdout, stderr, exit_code = await asyncio.wait_for(
                        loop.run_in_executor(None, self._run_mypy, args),
                        timeout=timeout,
                    )
                except asyncio.TimeoutError:
                    logger.warning("mypy timed out after %ds (no-config)", timeout)
                    return [advisory]

                if exit_code == 2:
                    return [advisory, *_parse_mypy_fatal_errors(stderr)]

                diagnostics = (
                    [] if not stdout.strip() else self._parse_json_output(stdout)
                )
                diagnostics.insert(0, advisory)
                if request.framework_stack:
                    diagnostics.extend(
                        _check_framework_stubs(
                            request.framework_stack,
                            request.project_root,
                        )
                    )
                return diagnostics

            else:
                logger.error("mypy fatal error: %s", stderr)
                return _parse_mypy_fatal_errors(stderr)

        # Exit code 0 = clean, 1 = type errors found
        diagnostics = [] if not stdout.strip() else self._parse_json_output(stdout)

        # Phase 3: emit advisory diagnostics for missing framework stubs
        if request.framework_stack:
            diagnostics.extend(
                _check_framework_stubs(
                    request.framework_stack,
                    request.project_root,
                )
            )

        return diagnostics

    def _build_args(
        self,
        files: list[Path],
        use_json: bool,
        skip_config: bool = False,
    ) -> list[str]:
        args: list[str] = []

        if use_json:
            args.extend(["--output", "json"])

        args.extend(
            [
                "--no-color-output",
                "--no-error-summary",
                "--show-absolute-path",
                "--incremental",  # Use .mypy_cache/ for speed
            ]
        )

        if skip_config:
            # Ignore the project's mypy config (e.g. when a plugin isn't installed)
            args.append("--config-file=")

        # Pass file paths
        args.extend(str(f) for f in files)

        return args

    @staticmethod
    def _run_mypy(args: list[str]) -> tuple[str, str, int]:
        """Call mypy.api.run() -- must run in thread pool (blocking)."""
        from mypy.api import run

        return run(args)

    def _parse_json_output(self, stdout: str) -> list[Diagnostic]:
        """Parse mypy JSON Lines output (one JSON object per line)."""
        diagnostics: list[Diagnostic] = []

        for line in stdout.strip().splitlines():
            line = line.strip()
            if not line:
                continue

            try:
                item = json.loads(line)
            except json.JSONDecodeError:
                logger.debug("Skipping non-JSON mypy output line: %s", line[:80])
                continue

            severity = _map_mypy_severity(item.get("severity", "error"))
            code = item.get("code", "misc")

            diagnostics.append(
                Diagnostic(
                    file_path=Path(item["file"]),
                    line=item.get("line", 0),
                    column=item.get("column", 0),
                    severity=severity,
                    rule_id=f"mypy-{code}",
                    tool="mypy",
                    category=Category.TYPE_SAFETY,
                    message=item.get("message", ""),
                    fix=item.get("hint"),
                    end_line=item.get("end_line"),
                    end_column=item.get("end_column"),
                )
            )

        return diagnostics

    def _parse_text_output(self, stdout: str) -> list[Diagnostic]:
        """Fallback: parse mypy's traditional text output.

        Format: file.py:10:5: error: message [error-code]
        """
        diagnostics: list[Diagnostic] = []

        for line in stdout.strip().splitlines():
            match = MYPY_LINE_RE.match(line)
            if not match:
                continue

            filepath, lineno, colno, level, message, code = match.groups()

            # Skip notes -- they're supplementary info, not actionable findings
            if level == "note":
                continue

            severity = _map_mypy_severity(level)
            code = code or "misc"

            diagnostics.append(
                Diagnostic(
                    file_path=Path(filepath),
                    line=int(lineno),
                    column=int(colno) if colno else 0,
                    severity=severity,
                    rule_id=f"mypy-{code}",
                    tool="mypy",
                    category=Category.TYPE_SAFETY,
                    message=message.strip(),
                )
            )

        return diagnostics


def _check_framework_stubs(stack: object, project_root: Path) -> list[Diagnostic]:
    """Emit INFO-level advisories when framework stubs are not installed."""
    from python_checkup.detection import FrameworkStack
    from python_checkup.frameworks.registry import get_plugins_for_stack

    if not isinstance(stack, FrameworkStack):
        return []

    advisories: list[Diagnostic] = []
    config_plugins = _configured_mypy_plugins(project_root)

    for plugin in get_plugins_for_stack(stack):
        stubs_info = plugin.get_stubs_info()
        if not stubs_info:
            continue

        stubs_pkg = stubs_info.stubs_package
        plugin_name = stubs_info.mypy_plugin

        stubs_missing = False
        if stubs_pkg is not None:
            try:
                importlib.metadata.version(stubs_pkg)
            except importlib.metadata.PackageNotFoundError:
                stubs_missing = True

        plugin_missing = plugin_name is not None and plugin_name not in config_plugins

        if stubs_missing or plugin_missing:
            concerns: list[str] = []
            fixes: list[str] = []
            if stubs_missing and stubs_pkg is not None:
                concerns.append(f"without {stubs_pkg}")
                fixes.append(f"pip install {stubs_pkg}")
            if plugin_missing and plugin_name is not None:
                concerns.append(f"without mypy plugin '{plugin_name}'")
                fixes.append(
                    f"add '{plugin_name}' to [tool.mypy].plugins in pyproject.toml"
                )

            advisories.append(
                Diagnostic(
                    file_path=Path("pyproject.toml"),
                    line=0,
                    column=0,
                    severity=Severity.INFO,
                    rule_id="FW-STUBS-001",
                    tool="mypy",
                    category=Category.TYPE_SAFETY,
                    message=(
                        f"{plugin.name} project {' and '.join(concerns)}: "
                        "type checking accuracy is reduced"
                    ),
                    fix="; ".join(fixes),
                )
            )

    return advisories


def _configured_mypy_plugins(project_root: Path) -> set[str]:
    """Read the set of mypy plugins already declared in pyproject.toml."""
    config_path = project_root / "pyproject.toml"
    try:
        with config_path.open("rb") as handle:
            data = tomllib.load(handle)
    except (OSError, tomllib.TOMLDecodeError):
        return set()

    tool = data.get("tool", {})
    if not isinstance(tool, dict):
        return set()
    mypy_cfg = tool.get("mypy", {})
    if not isinstance(mypy_cfg, dict):
        return set()

    raw_plugins = mypy_cfg.get("plugins", [])
    if isinstance(raw_plugins, str):
        return {part.strip() for part in raw_plugins.split(",") if part.strip()}
    if isinstance(raw_plugins, list):
        return {str(item).strip() for item in raw_plugins if str(item).strip()}
    return set()


_MYPY_FATAL_RE = re.compile(r"^(.+?):(\d+):\s*(.+)$")
_PLUGIN_IMPORT_RE = re.compile(
    r'Error importing plugin ["\']([^"\']*)["\']: No module named ["\']([^"\']*)["\']'
)


def _parse_mypy_fatal_errors(stderr: str) -> list[Diagnostic]:
    """Convert mypy fatal-error stderr lines into Diagnostics.

    Handles lines like:
        app/utils/foo.py:44: multiple exception types must be parenthesized ...
    These are syntax errors in the target project that prevent mypy from
    running at all — surface them as ERROR diagnostics so the user sees them.
    """
    diagnostics: list[Diagnostic] = []
    for line in stderr.strip().splitlines():
        line = line.strip()
        if not line:
            continue
        m = _MYPY_FATAL_RE.match(line)
        if not m:
            continue
        filepath, lineno, message = m.groups()
        # Skip lines that look like internal mypy noise (no path separator)
        if not ("/" in filepath or "\\" in filepath or filepath.endswith(".py")):
            continue
        diagnostics.append(
            Diagnostic(
                file_path=Path(filepath),
                line=int(lineno),
                column=0,
                severity=Severity.ERROR,
                rule_id="mypy-syntax",
                tool="mypy",
                category=Category.TYPE_SAFETY,
                message=message.strip(),
                fix="Fix the syntax error so mypy can analyse this file",
            )
        )
    return diagnostics


def _map_mypy_severity(level: str) -> Severity:
    match level:
        case "error":
            return Severity.ERROR
        case "warning":
            return Severity.WARNING
        case _:
            return Severity.INFO
