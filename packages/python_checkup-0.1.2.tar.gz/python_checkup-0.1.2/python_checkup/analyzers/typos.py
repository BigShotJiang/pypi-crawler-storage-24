from __future__ import annotations

import asyncio
import json
import shutil
from pathlib import Path

from python_checkup.analysis_request import AnalysisRequest
from python_checkup.models import Category, Diagnostic, Severity


class TyposAnalyzer:
    """Source-code typo detection via typos."""

    @property
    def name(self) -> str:
        return "typos"

    @property
    def category(self) -> Category:
        return Category.QUALITY

    async def is_available(self) -> bool:
        return shutil.which("typos") is not None

    async def analyze(self, request: AnalysisRequest) -> list[Diagnostic]:
        if not request.files:
            return []

        cmd = ["typos", "--format", "json", *[str(path) for path in request.files]]
        timeout = request.config.timeout
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, _stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)

        # typos exits 0 when clean, 2 when typos found.
        if proc.returncode not in (0, 2):
            return []

        output = stdout.decode().strip()
        if not output:
            return []

        diagnostics: list[Diagnostic] = []
        for line in output.splitlines():
            try:
                raw = json.loads(line)
            except json.JSONDecodeError:
                continue

            if not isinstance(raw, dict):
                continue

            path = Path(str(raw.get("path", "unknown")))
            typo = str(raw.get("typo", ""))
            corrections = raw.get("corrections", [])
            fix: str | None = None
            if isinstance(corrections, list) and corrections:
                fix = (
                    f"Replace with: {', '.join(str(item) for item in corrections[:3])}"
                )

            diagnostics.append(
                Diagnostic(
                    file_path=path,
                    line=int(raw.get("line_num", 0) or 0),
                    column=int(raw.get("byte_offset", 0) or 0),
                    severity=Severity.INFO,
                    rule_id="TYPOS",
                    tool="typos",
                    category=Category.QUALITY,
                    message=f"Possible typo: {typo}",
                    fix=fix,
                )
            )

        return diagnostics
