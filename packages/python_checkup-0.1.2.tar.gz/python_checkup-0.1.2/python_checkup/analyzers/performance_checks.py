"""Performance anti-pattern checks via static AST analysis.

Detects real-world performance issues that neither Ruff nor mypy surface:

Rule ID convention: PERF-GEN-*   General Python patterns
                    PERF-DJ-*    Django ORM patterns
                    PERF-SA-*    SQLAlchemy patterns
                    PERF-ASYNC-* Async/await anti-patterns
"""

from __future__ import annotations

import ast
import logging
from pathlib import Path
from typing import TYPE_CHECKING

from python_checkup.analyzers.ast_helpers import parse_file
from python_checkup.models import Category, Diagnostic, Severity

if TYPE_CHECKING:
    from python_checkup.analysis_request import AnalysisRequest

logger = logging.getLogger("python_checkup")

# ---------------------------------------------------------------------------
# Async blocking-call detection
# ---------------------------------------------------------------------------

# stdlib / popular libs that block the event loop when called in async context
_BLOCKING_MODULES: dict[str, set[str]] = {
    "requests": {"get", "post", "put", "patch", "delete", "head", "options", "request"},
    "urllib.request": {"urlopen", "urlretrieve"},
    "http.client": {"HTTPConnection", "HTTPSConnection"},
    "smtplib": {"SMTP", "SMTP_SSL"},
    "ftplib": {"FTP"},
    "socket": {"create_connection", "getaddrinfo", "gethostbyname"},
    "time": {"sleep"},
    "subprocess": {"run", "call", "check_call", "check_output", "Popen"},
    "os": {"system", "popen"},
}

# Module-level attribute patterns like `requests.get(...)` → {obj: methods}
_BLOCKING_ATTR_CALLS: dict[str, set[str]] = {
    "requests": {"get", "post", "put", "patch", "delete", "head", "options", "request"},
    "time": {"sleep"},
    "subprocess": {"run", "call", "check_call", "check_output"},
    "os": {"system"},
}

# Bare name calls that are blocking (after `from X import Y`)
_BLOCKING_BARE_CALLS: set[str] = {"sleep", "urlopen"}


def _is_inside_async_def(node: ast.AST, parents: dict[ast.AST, ast.AST]) -> bool:
    current: ast.AST | None = parents.get(node)
    while current is not None:
        if isinstance(current, ast.AsyncFunctionDef):
            return True
        if isinstance(current, (ast.FunctionDef, ast.ClassDef)):
            return False
        current = parents.get(current)
    return False


def _build_parent_map(tree: ast.AST) -> dict[ast.AST, ast.AST]:
    parents: dict[ast.AST, ast.AST] = {}
    for parent in ast.walk(tree):
        for child in ast.iter_child_nodes(parent):
            parents[child] = parent
    return parents


def _check_async_blocking(f: Path, tree: ast.AST) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    parents = _build_parent_map(tree)

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if not _is_inside_async_def(node, parents):
            continue

        blocking_name: str | None = None

        if isinstance(node.func, ast.Attribute):
            obj = node.func.value
            method = node.func.attr
            obj_name = obj.id if isinstance(obj, ast.Name) else None
            if obj_name and method in _BLOCKING_ATTR_CALLS.get(obj_name, set()):
                blocking_name = f"{obj_name}.{method}()"
        elif isinstance(node.func, ast.Name):
            if node.func.id in _BLOCKING_BARE_CALLS:
                blocking_name = f"{node.func.id}()"

        if blocking_name:
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=node.lineno,
                    column=node.col_offset,
                    severity=Severity.ERROR,
                    rule_id="PERF-ASYNC-001",
                    tool="performance-checks",
                    category=Category.PERFORMANCE,
                    message=(
                        f"Blocking call {blocking_name} inside async function."
                        " This blocks the entire event loop."
                    ),
                    fix=(
                        "Use an async equivalent: httpx.AsyncClient, "
                        "asyncio.sleep, asyncio.create_subprocess_exec, etc."
                    ),
                )
            )

    return diags


# ---------------------------------------------------------------------------
# Django ORM performance patterns
# ---------------------------------------------------------------------------


def _is_queryset_call(node: ast.AST) -> bool:
    """Return True if node looks like a queryset method call chain."""
    if not isinstance(node, ast.Call):
        return False
    if isinstance(node.func, ast.Attribute):
        attr = node.func.attr
        if attr in (
            "all",
            "filter",
            "exclude",
            "order_by",
            "values",
            "values_list",
            "annotate",
            "aggregate",
        ):
            return True
    return False


def _check_django_perf(f: Path, tree: ast.AST) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    parents = _build_parent_map(tree)

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue

        # PERF-DJ-001: len(queryset) instead of queryset.count()
        if (
            isinstance(node.func, ast.Name)
            and node.func.id == "len"
            and len(node.args) == 1
            and _is_queryset_call(node.args[0])
        ):
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=node.lineno,
                    column=node.col_offset,
                    severity=Severity.WARNING,
                    rule_id="PERF-DJ-001",
                    tool="performance-checks",
                    category=Category.PERFORMANCE,
                    message=(
                        "len() on a queryset loads all objects into memory."
                        " Use .count() for a SQL COUNT query."
                    ),
                    fix="Replace len(qs) with qs.count()",
                )
            )

        # PERF-DJ-002: bool(queryset) instead of queryset.exists()
        if (
            isinstance(node.func, ast.Name)
            and node.func.id == "bool"
            and len(node.args) == 1
            and _is_queryset_call(node.args[0])
        ):
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=node.lineno,
                    column=node.col_offset,
                    severity=Severity.WARNING,
                    rule_id="PERF-DJ-002",
                    tool="performance-checks",
                    category=Category.PERFORMANCE,
                    message=(
                        "bool() on a queryset loads all objects into memory."
                        " Use .exists() for an efficient SQL EXISTS query."
                    ),
                    fix="Replace bool(qs) with qs.exists()",
                )
            )

        # PERF-DJ-003: list(queryset) used purely for truth testing (if list(qs))
        parent = parents.get(node)
        if (
            isinstance(node.func, ast.Name)
            and node.func.id == "list"
            and len(node.args) == 1
            and _is_queryset_call(node.args[0])
            and isinstance(parent, (ast.If, ast.While))
            and parent.test is node
        ):
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=node.lineno,
                    column=node.col_offset,
                    severity=Severity.WARNING,
                    rule_id="PERF-DJ-003",
                    tool="performance-checks",
                    category=Category.PERFORMANCE,
                    message=(
                        "list(queryset) used for truth testing loads all rows."
                        " Use .exists() instead."
                    ),
                    fix="Replace if list(qs): with if qs.exists():",
                )
            )

        # PERF-DJ-004: .order_by() on queryset inside a loop body
        if (
            isinstance(node.func, ast.Attribute)
            and node.func.attr == "order_by"
            and _is_inside_loop(node, parents)
        ):
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=node.lineno,
                    column=node.col_offset,
                    severity=Severity.INFO,
                    rule_id="PERF-DJ-004",
                    tool="performance-checks",
                    category=Category.PERFORMANCE,
                    message=(
                        "Queryset .order_by() called inside a loop."
                        " Move the query outside the loop."
                    ),
                    fix="Hoist the queryset construction above the loop",
                )
            )

        # PERF-DJ-005: Model.objects.all() then Python-side filter (list comprehension)
        # Detect [x for x in Model.objects.all() if condition]
        # handled in _check_queryset_listcomp below

    diags.extend(_check_queryset_listcomp(f, tree))
    return diags


def _check_queryset_listcomp(f: Path, tree: ast.AST) -> list[Diagnostic]:
    """PERF-DJ-005: list comprehension filtering over .all() → filter() in DB."""
    diags: list[Diagnostic] = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.ListComp, ast.GeneratorExp)):
            continue
        if not node.generators:
            continue
        gen = node.generators[0]
        # iter is a queryset .all() call and there is an `if` filter
        if (
            isinstance(gen.iter, ast.Call)
            and isinstance(gen.iter.func, ast.Attribute)
            and gen.iter.func.attr == "all"
            and gen.ifs
        ):
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=node.lineno,
                    column=node.col_offset,
                    severity=Severity.WARNING,
                    rule_id="PERF-DJ-005",
                    tool="performance-checks",
                    category=Category.PERFORMANCE,
                    message=(
                        "Filtering queryset results in Python with a list"
                        " comprehension. Use .filter() to push the condition"
                        " to the database."
                    ),
                    fix=(
                        "Replace [x for x in Model.objects.all() if cond]"
                        " with Model.objects.filter(cond)"
                    ),
                )
            )
    return diags


def _is_inside_loop(node: ast.AST, parents: dict[ast.AST, ast.AST]) -> bool:
    current: ast.AST | None = parents.get(node)
    while current is not None:
        if isinstance(current, (ast.For, ast.While)):
            return True
        if isinstance(current, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            return False
        current = parents.get(current)
    return False


# ---------------------------------------------------------------------------
# SQLAlchemy performance patterns
# ---------------------------------------------------------------------------


def _check_sqlalchemy_perf(f: Path, tree: ast.AST) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    parents = _build_parent_map(tree)

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue

        # PERF-SA-001: session.query(...).all() inside a loop
        if (
            isinstance(node.func, ast.Attribute)
            and node.func.attr == "all"
            and isinstance(node.func.value, ast.Call)
            and _is_sqlalchemy_query_chain(node.func.value)
            and _is_inside_loop(node, parents)
        ):
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=node.lineno,
                    column=node.col_offset,
                    severity=Severity.WARNING,
                    rule_id="PERF-SA-001",
                    tool="performance-checks",
                    category=Category.PERFORMANCE,
                    message=(
                        "SQLAlchemy query executed inside a loop. "
                        "This causes N+1 queries."
                    ),
                    fix=(
                        "Hoist the query outside the loop, or use "
                        "joinedload/selectinload to eager-load relationships."
                    ),
                )
            )

        # PERF-SA-002: .count() via len(session.query(...).all())
        if (
            isinstance(node.func, ast.Name)
            and node.func.id == "len"
            and len(node.args) == 1
            and isinstance(node.args[0], ast.Call)
            and isinstance(node.args[0].func, ast.Attribute)
            and node.args[0].func.attr == "all"
            and isinstance(node.args[0].func.value, ast.Call)
            and _is_sqlalchemy_query_chain(node.args[0].func.value)
        ):
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=node.lineno,
                    column=node.col_offset,
                    severity=Severity.WARNING,
                    rule_id="PERF-SA-002",
                    tool="performance-checks",
                    category=Category.PERFORMANCE,
                    message=(
                        "len(session.query(...).all()) loads all rows to count them."
                        " Use session.query(...).count() instead."
                    ),
                    fix="Replace len(q.all()) with q.count()",
                )
            )

    return diags


def _is_sqlalchemy_query_chain(node: ast.Call) -> bool:
    """True if node looks like session.query(...) or a chained filter/order_by."""
    if isinstance(node.func, ast.Attribute):
        attr = node.func.attr
        if attr in ("query", "filter", "filter_by", "order_by", "join", "options"):
            return True
    return False


# ---------------------------------------------------------------------------
# General Python performance patterns
# ---------------------------------------------------------------------------


def _check_general_perf(f: Path, tree: ast.AST) -> list[Diagnostic]:
    diags: list[Diagnostic] = []
    diags.extend(_check_string_concat_in_loop(f, tree))
    diags.extend(_check_regex_in_loop(f, tree))
    diags.extend(_check_repeated_attr_lookup(f, tree))
    return diags


def _check_string_concat_in_loop(f: Path, tree: ast.AST) -> list[Diagnostic]:
    """PERF-GEN-001: string += in a loop — should use list + ''.join()."""
    diags: list[Diagnostic] = []
    parents = _build_parent_map(tree)

    for node in ast.walk(tree):
        if not isinstance(node, ast.AugAssign):
            continue
        if not isinstance(node.op, ast.Add):
            continue
        # Check if value is a string (Constant str or BinOp involving str)
        if not _is_string_expr(node.value):
            continue
        if not _is_inside_loop(node, parents):
            continue
        diags.append(
            Diagnostic(
                file_path=f,
                line=node.lineno,
                column=node.col_offset,
                severity=Severity.WARNING,
                rule_id="PERF-GEN-001",
                tool="performance-checks",
                category=Category.PERFORMANCE,
                message=(
                    "String concatenation with += inside a loop creates O(n²) copies."
                    " Collect parts in a list and join at the end."
                ),
                fix=(
                    "Use parts = []; parts.append(...) inside the loop,"
                    " then result = ''.join(parts)"
                ),
            )
        )

    return diags


def _is_string_expr(node: ast.expr) -> bool:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return True
    if isinstance(node, ast.JoinedStr):
        return True
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        return _is_string_expr(node.left) or _is_string_expr(node.right)
    if isinstance(node, ast.Call):
        # str(...), repr(...), chr(...) always return strings
        if isinstance(node.func, ast.Name) and node.func.id in ("str", "repr", "chr"):
            return True
        # "...".join(), .format(), .strip(), etc.
        return isinstance(node.func, ast.Attribute) and node.func.attr in (
            "join",
            "format",
            "encode",
            "decode",
            "strip",
            "replace",
            "lower",
            "upper",
            "lstrip",
            "rstrip",
        )
    return False


def _check_regex_in_loop(f: Path, tree: ast.AST) -> list[Diagnostic]:
    """PERF-GEN-002: re.compile / re.match / re.search inside a loop."""
    diags: list[Diagnostic] = []
    parents = _build_parent_map(tree)

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if not _is_inside_loop(node, parents):
            continue
        if (
            isinstance(node.func, ast.Attribute)
            and isinstance(node.func.value, ast.Name)
            and node.func.value.id == "re"
            and node.func.attr
            in (
                "compile",
                "match",
                "search",
                "fullmatch",
                "findall",
                "finditer",
                "sub",
                "subn",
            )
        ):
            diags.append(
                Diagnostic(
                    file_path=f,
                    line=node.lineno,
                    column=node.col_offset,
                    severity=Severity.INFO,
                    rule_id="PERF-GEN-002",
                    tool="performance-checks",
                    category=Category.PERFORMANCE,
                    message=(
                        f"re.{node.func.attr}() called inside a loop."
                        " Pre-compile the pattern with re.compile() at module level."
                    ),
                    fix=(
                        "Move pattern = re.compile(r'...') outside the loop"
                        " and call pattern.match/search/etc. inside"
                    ),
                )
            )

    return diags


def _check_repeated_attr_lookup(f: Path, tree: ast.AST) -> list[Diagnostic]:
    """PERF-GEN-003: same attribute chain accessed 3+ times in a loop body."""
    diags: list[Diagnostic] = []

    for node in ast.walk(tree):
        if not isinstance(node, (ast.For, ast.While)):
            continue
        body_source = _collect_attr_accesses(node.body)
        for attr_chain, count in body_source.items():
            if count >= 3 and "." in attr_chain:
                # Get line from first occurrence — approximate with loop line
                diags.append(
                    Diagnostic(
                        file_path=f,
                        line=node.lineno,
                        column=node.col_offset,
                        severity=Severity.INFO,
                        rule_id="PERF-GEN-003",
                        tool="performance-checks",
                        category=Category.PERFORMANCE,
                        message=(
                            f"Attribute chain '{attr_chain}' accessed {count} times"
                            " inside a loop. Cache it in a local variable."
                        ),
                        fix=(
                            f"Add '{attr_chain.split('.')[0]}_cached ="
                            f" {attr_chain}' before the loop"
                        ),
                    )
                )

    return diags


def _attr_chain_name(node: ast.expr) -> str | None:
    """Return dotted name for simple attribute chains like a.b.c, else None."""
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        base = _attr_chain_name(node.value)
        if base:
            return f"{base}.{node.attr}"
    return None


def _collect_attr_accesses(stmts: list[ast.stmt]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for stmt in stmts:
        for n in ast.walk(stmt):
            if isinstance(n, ast.Attribute):
                name = _attr_chain_name(n)
                if name and "." in name:
                    counts[name] = counts.get(name, 0) + 1
    return counts


# ---------------------------------------------------------------------------
# Analyzer class
# ---------------------------------------------------------------------------

# Which checks to run based on whether certain frameworks are detected
_DJANGO_NAMES = {"django"}
_SA_NAMES = {"sqlalchemy"}


class PerformanceCheckAnalyzer:
    """Static performance anti-pattern detection."""

    @property
    def name(self) -> str:
        return "performance-checks"

    @property
    def category(self) -> Category:
        return Category.PERFORMANCE

    async def is_available(self) -> bool:
        return True

    async def analyze(self, request: AnalysisRequest) -> list[Diagnostic]:
        files = request.files
        if not files:
            return []

        framework_names: set[str] = set()
        if request.framework_stack and request.framework_stack.all_frameworks:
            framework_names = request.framework_stack.names

        run_django = bool(framework_names & _DJANGO_NAMES)
        run_sa = bool(framework_names & _SA_NAMES)

        diags: list[Diagnostic] = []
        for f in files:
            tree = parse_file(f)
            if tree is None:
                continue
            diags.extend(_check_async_blocking(f, tree))
            diags.extend(_check_general_perf(f, tree))
            if run_django:
                diags.extend(_check_django_perf(f, tree))
            if run_sa:
                diags.extend(_check_sqlalchemy_perf(f, tree))

        # Apply any user-disabled rules
        raw = request.config_dict().get("disabled_rules", [])
        disabled: set[str] = set(raw) if isinstance(raw, list) else set()
        if disabled:
            diags = [d for d in diags if d.rule_id not in disabled]

        return diags
