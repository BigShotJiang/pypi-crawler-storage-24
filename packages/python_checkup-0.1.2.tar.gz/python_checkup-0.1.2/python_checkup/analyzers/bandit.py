from __future__ import annotations

import asyncio
import json
import logging
import shutil
from pathlib import Path

from python_checkup.analysis_request import AnalysisRequest
from python_checkup.models import Category, Diagnostic, Severity

# Rules to suppress per framework when they're framework-sanctioned patterns.
# Values are either "suppress" (drop entirely), "demote" (reduce to INFO),
# or "elevate_to_warning" (raise INFO to WARNING).
_FRAMEWORK_BANDIT_ADJUSTMENTS: dict[str, dict[str, str]] = {
    "django": {
        # Django templates autoescape by default
        "B703": "suppress",
        # mark_safe() is checked by Ruff's DJ rules more accurately
        "B308": "suppress",
        # Binding to 0.0.0.0 is normal for containers/uvicorn
        "B104": "suppress",
        # Bare except/pass in Django request paths can hide security issues
        "B110": "elevate_to_warning",
    },
    "fastapi": {
        # Binding to 0.0.0.0 is standard for uvicorn
        "B104": "suppress",
    },
    "flask": {
        # Binding to 0.0.0.0 is standard for the dev server
        "B104": "suppress",
    },
}

logger = logging.getLogger("python_checkup")

# Bandit severity -> python-checkup Severity
BANDIT_SEVERITY_MAP: dict[str, Severity] = {
    "HIGH": Severity.ERROR,
    "MEDIUM": Severity.WARNING,
    "LOW": Severity.INFO,
}


class BanditAnalyzer:
    """Security scanning via Bandit."""

    @property
    def name(self) -> str:
        return "bandit"

    @property
    def category(self) -> Category:
        return Category.SECURITY

    async def is_available(self) -> bool:
        """Check if bandit is on PATH."""
        return shutil.which("bandit") is not None

    async def analyze(
        self,
        request: AnalysisRequest,
    ) -> list[Diagnostic]:
        files = request.files
        config = request.config_dict()
        if not files:
            return []

        cmd = ["bandit", "-f", "json", "--quiet"]

        str_paths = [str(f) for f in files]
        cmd.extend(str_paths)

        timeout: int = 60
        if "timeout" in config and isinstance(config["timeout"], int | float):
            timeout = int(config["timeout"])

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(),
                timeout=timeout,
            )
        except asyncio.TimeoutError:
            logger.warning("Bandit timed out")
            return []
        except FileNotFoundError:
            logger.warning("Bandit binary not found")
            return []

        # Exit codes: 0 = clean, 1 = issues found, 2 = error
        if proc.returncode == 2:
            logger.error("Bandit error: %s", stderr.decode())
            return []

        output = stdout.decode()
        if not output.strip():
            return []

        try:
            data = json.loads(output)
        except json.JSONDecodeError:
            logger.error("Failed to parse Bandit JSON output")
            return []

        results = data.get("results", [])
        if not isinstance(results, list):
            return []

        diagnostics = [_map_bandit_result(r) for r in results]

        # Phase 3: apply framework-specific rule adjustments
        if request.framework_stack and request.framework_stack.all_frameworks:
            diagnostics = _apply_framework_adjustments(
                diagnostics, request.framework_stack.names
            )

        # Suppress noisy Bandit rules in test files (same approach as
        # Ruff's per-file-ignores).  B101 (assert), B108 (temp dirs),
        # B603/B607 (subprocess), B404 (subprocess import), B105/B106
        # (hardcoded passwords) are standard practice in test suites.
        _test_suppressed = {"B101", "B108", "B603", "B607", "B404", "B105", "B106"}
        diagnostics = [
            d
            for d in diagnostics
            if not (d.rule_id in _test_suppressed and _is_test_file(d.file_path))
        ]

        return diagnostics


def _apply_framework_adjustments(
    diagnostics: list[Diagnostic],
    framework_names: set[str],
) -> list[Diagnostic]:
    """Suppress or demote Bandit findings that are sanctioned in a framework context."""
    # Merge adjustments from all detected frameworks
    merged: dict[str, str] = {}
    for name in framework_names:
        merged.update(_FRAMEWORK_BANDIT_ADJUSTMENTS.get(name, {}))

    if not merged:
        return diagnostics

    filtered: list[Diagnostic] = []
    for d in diagnostics:
        action = merged.get(d.rule_id)
        if action == "suppress":
            continue
        if action == "demote":
            d = Diagnostic(
                file_path=d.file_path,
                line=d.line,
                column=d.column,
                severity=Severity.INFO,
                rule_id=d.rule_id,
                tool=d.tool,
                category=d.category,
                message=d.message,
                fix=d.fix,
                help_url=d.help_url,
                end_line=d.end_line,
                end_column=d.end_column,
            )
        elif action == "elevate_to_warning" and d.severity == Severity.INFO:
            d = Diagnostic(
                file_path=d.file_path,
                line=d.line,
                column=d.column,
                severity=Severity.WARNING,
                rule_id=d.rule_id,
                tool=d.tool,
                category=d.category,
                message=d.message,
                fix=d.fix,
                help_url=d.help_url,
                end_line=d.end_line,
                end_column=d.end_column,
            )
        filtered.append(d)
    return filtered


def _is_test_file(path: Path) -> bool:
    """Return True if *path* looks like a test file or sits inside a tests/ dir."""
    parts = path.parts
    return (
        any(p in ("tests", "test") for p in parts)
        or path.name.startswith("test_")
        or path.name.endswith("_test.py")
    )


def _safe_int(val: object, default: int = 0) -> int:
    if val is None:
        return default
    if isinstance(val, int):
        return val
    try:
        return int(str(val))
    except (TypeError, ValueError):
        return default


def _map_bandit_result(raw: dict[str, object]) -> Diagnostic:
    severity = BANDIT_SEVERITY_MAP.get(
        str(raw.get("issue_severity", "LOW")),
        Severity.INFO,
    )

    test_id = str(raw.get("test_id", "B000"))

    # Build fix suggestion from CWE
    cwe = raw.get("issue_cwe")
    fix_text: str | None = None
    if isinstance(cwe, dict) and cwe.get("id"):
        fix_text = f"CWE-{cwe['id']}"

    help_url = raw.get("more_info")

    end_col = raw.get("end_col_offset")

    return Diagnostic(
        file_path=Path(str(raw.get("filename", "unknown"))),
        line=_safe_int(raw.get("line_number")),
        column=_safe_int(raw.get("col_offset")),
        severity=severity,
        rule_id=test_id,
        tool="bandit",
        category=Category.SECURITY,
        message=str(raw.get("issue_text", "")),
        fix=fix_text,
        help_url=str(help_url) if help_url else None,
        end_column=_safe_int(end_col) if end_col else None,
    )
