from __future__ import annotations

import ast
import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from python_checkup.detection import FrameworkStack
    from python_checkup.models import Diagnostic

logger = logging.getLogger("python_checkup")


@dataclass(frozen=True)
class WhitelistEntry:
    """A pattern-based rule for suppressing a Vulture diagnostic.

    All pattern fields are compiled as full-match regexes (``re.fullmatch``).
    ``None`` means "match anything".
    """

    name_pattern: str  # regex for the reported symbol name
    item_type: str | None  # "class", "function", "attribute", …; None = any
    reason: str  # shown in --verbose output
    parent_pattern: str | None = None  # regex for parent class; None = any

    def matches(self, name: str, item_type: str, parent: str | None = None) -> bool:
        if not re.fullmatch(self.name_pattern, name):
            return False
        if self.item_type is not None and self.item_type != item_type:
            return False
        return self.parent_pattern is None or (
            parent is not None and re.fullmatch(self.parent_pattern, parent) is not None
        )


# ---------------------------------------------------------------------------
# Django whitelist
# ---------------------------------------------------------------------------

DJANGO_WHITELIST: list[WhitelistEntry] = [
    # ---- Model Meta --------------------------------------------------------
    WhitelistEntry(
        name_pattern="Meta",
        item_type="class",
        reason="Django model/form/serializer Meta inner class",
    ),
    WhitelistEntry(
        name_pattern=(
            r"ordering|verbose_name|verbose_name_plural|db_table|"
            r"unique_together|index_together|constraints|indexes|"
            r"abstract|proxy|managed|app_label|default_related_name|"
            r"get_latest_by|default_manager_name|permissions|"
            r"default_permissions|ordering_fields|read_only_fields|"
            r"fields|exclude|widgets|labels|help_texts|error_messages|"
            r"initial|field_classes|depth|extra_kwargs|model"
        ),
        item_type="attribute",
        reason="Django model/form/serializer Meta attribute",
    ),
    # ---- ORM / model methods -----------------------------------------------
    WhitelistEntry(
        name_pattern=(
            r"__str__|__repr__|__unicode__|get_absolute_url|"
            r"clean|clean_fields|validate_unique|save|delete|"
            r"natural_key|get_next_by_.*|get_previous_by_.*|"
            r"get_FOO_display"
        ),
        item_type="function",
        reason="Django model method called by the framework or ORM",
    ),
    # ---- Class-based views -------------------------------------------------
    WhitelistEntry(
        name_pattern=(
            r"model|queryset|template_name|context_object_name|"
            r"form_class|success_url|paginate_by|ordering|fields_list|"
            r"pk_url_kwarg|slug_url_kwarg|slug_field|login_url|"
            r"permission_required|raise_exception|"
            r"get_queryset|get_context_data|get_object|get_form|"
            r"get_form_class|get_form_kwargs|form_valid|form_invalid|"
            r"get_success_url|dispatch|get|post|put|patch|delete|"
            r"head|options|get_extra_context"
        ),
        item_type=None,
        reason="Django class-based view attribute or method",
    ),
    # ---- Admin -------------------------------------------------------------
    WhitelistEntry(
        name_pattern=(
            r"list_display|list_filter|search_fields|readonly_fields|"
            r"fieldsets|inlines|actions|list_per_page|ordering|"
            r"raw_id_fields|autocomplete_fields|prepopulated_fields|"
            r"formfield_overrides|list_display_links|list_editable|"
            r"date_hierarchy|exclude|filter_horizontal|filter_vertical|"
            r"save_model|save_related|save_formset|get_queryset|"
            r"get_list_display|get_list_filter|has_add_permission|"
            r"has_change_permission|has_delete_permission|has_view_permission"
        ),
        item_type=None,
        reason="Django admin attribute or hook method",
    ),
    # ---- Management commands -----------------------------------------------
    WhitelistEntry(
        name_pattern=r"handle|add_arguments|help|requires_migrations_checks",
        item_type=None,
        parent_pattern="Command",
        reason="Django management command method or attribute",
    ),
    # ---- Middleware ---------------------------------------------------------
    WhitelistEntry(
        name_pattern=(
            r"process_request|process_response|process_view|"
            r"process_exception|process_template_response"
        ),
        item_type="function",
        reason="Django middleware hook",
    ),
    # ---- URL configuration -------------------------------------------------
    WhitelistEntry(
        name_pattern=r"urlpatterns|app_name",
        item_type="variable",
        reason="Django URL configuration module variable",
    ),
    # ---- Settings ----------------------------------------------------------
    WhitelistEntry(
        name_pattern=(
            r"INSTALLED_APPS|MIDDLEWARE|ROOT_URLCONF|TEMPLATES|"
            r"DATABASES|AUTH_PASSWORD_VALIDATORS|STATIC_URL|"
            r"DEFAULT_AUTO_FIELD|LANGUAGE_CODE|TIME_ZONE|"
            r"USE_I18N|USE_TZ|STATIC_ROOT|MEDIA_ROOT|MEDIA_URL|"
            r"ALLOWED_HOSTS|SECRET_KEY|DEBUG|BASE_DIR|WSGI_APPLICATION|"
            r"ASGI_APPLICATION|LOGGING|CACHES|EMAIL_BACKEND|"
            r"SESSION_ENGINE|AUTH_USER_MODEL|LOGIN_URL|LOGIN_REDIRECT_URL|"
            r"LOGOUT_REDIRECT_URL|CELERY_.*|CHANNEL_LAYERS|REST_FRAMEWORK"
        ),
        item_type="variable",
        reason="Django settings module variable",
    ),
    # ---- DRF viewset methods -----------------------------------------------
    WhitelistEntry(
        name_pattern=(
            r"serializer_class|permission_classes|authentication_classes|"
            r"pagination_class|filter_backends|filterset_class|"
            r"filterset_fields|lookup_field|lookup_url_kwarg|"
            r"list|create|retrieve|update|partial_update|destroy|"
            r"perform_create|perform_update|perform_destroy|"
            r"get_serializer|get_serializer_class|get_permissions|"
            r"get_authenticators|get_throttles|get_parsers|get_renderers"
        ),
        item_type=None,
        reason="Django REST Framework viewset/view attribute or method",
    ),
]

# ---------------------------------------------------------------------------
# FastAPI whitelist
# ---------------------------------------------------------------------------

FASTAPI_WHITELIST: list[WhitelistEntry] = [
    # Pydantic model config used in request/response models
    WhitelistEntry(
        name_pattern=r"model_config|Config",
        item_type=None,
        reason="Pydantic model configuration class or attribute",
    ),
    # Common dependency function name patterns
    WhitelistEntry(
        name_pattern=(
            r"get_db|get_session|get_current_user|get_settings|"
            r"get_redis|get_cache|get_client|verify_token|"
            r"common_parameters|pagination_params"
        ),
        item_type="function",
        reason="FastAPI dependency injection function (common naming pattern)",
    ),
    # Lifespan / startup / shutdown
    WhitelistEntry(
        name_pattern=(r"lifespan|startup_event|shutdown_event|on_startup|on_shutdown"),
        item_type="function",
        reason="FastAPI lifespan or event handler",
    ),
    # Exception handlers (common naming convention)
    WhitelistEntry(
        name_pattern=r".*_handler|.*_exception_handler",
        item_type="function",
        reason="FastAPI exception handler (name ends in _handler)",
    ),
    # Background tasks
    WhitelistEntry(
        name_pattern=r".*_task|.*_background|write_notification|send_.*",
        item_type="function",
        reason="FastAPI background task function",
    ),
]

# ---------------------------------------------------------------------------
# Flask whitelist
# ---------------------------------------------------------------------------

FLASK_WHITELIST: list[WhitelistEntry] = [
    # Blueprint instances
    WhitelistEntry(
        name_pattern=r"bp|blueprint|.*_bp|.*_blueprint",
        item_type="variable",
        reason="Flask Blueprint instance",
    ),
    # Application factory
    WhitelistEntry(
        name_pattern=r"create_app|make_app|application_factory",
        item_type="function",
        reason="Flask application factory (called by WSGI server or tests)",
    ),
    # Request lifecycle hooks (common names used with @app decorators)
    WhitelistEntry(
        name_pattern=(
            r"before_request|after_request|teardown_request|"
            r"before_first_request|teardown_appcontext"
        ),
        item_type="function",
        reason="Flask request lifecycle hook",
    ),
    # Context processors
    WhitelistEntry(
        name_pattern=r"inject_.*|.*_context|context_processor",
        item_type="function",
        reason="Flask context processor",
    ),
    # Error handlers (common naming pattern)
    WhitelistEntry(
        name_pattern=r".*_error|.*_not_found|handle_.*|not_found|forbidden|server_error",
        item_type="function",
        reason="Flask error handler",
    ),
    # CLI commands
    WhitelistEntry(
        name_pattern=r"init_db|create_tables|seed_data|.*_command",
        item_type="function",
        reason="Flask CLI command",
    ),
    # WSGI callable
    WhitelistEntry(
        name_pattern=r"application|wsgi_app",
        item_type="variable",
        reason="Flask WSGI application callable",
    ),
]

# ---------------------------------------------------------------------------
# Celery whitelist
# ---------------------------------------------------------------------------

CELERY_WHITELIST: list[WhitelistEntry] = [
    # Celery application instance
    WhitelistEntry(
        name_pattern=r"app|celery|celery_app|worker",
        item_type="variable",
        reason="Celery application instance",
    ),
    # Celery config attributes (in celeryconfig.py / settings)
    WhitelistEntry(
        name_pattern=(
            r"broker_url|result_backend|task_serializer|accept_content|"
            r"result_serializer|timezone|enable_utc|beat_schedule|"
            r"task_routes|task_always_eager|task_default_queue|"
            r"worker_max_tasks_per_child|task_acks_late|"
            r"CELERY_BROKER_URL|CELERY_RESULT_BACKEND|CELERY_.*"
        ),
        item_type="variable",
        reason="Celery configuration variable",
    ),
    # on_failure / on_retry / on_success task methods
    WhitelistEntry(
        name_pattern=r"on_failure|on_retry|on_success|run|apply_async",
        item_type="function",
        reason="Celery task lifecycle method",
    ),
]

# ---------------------------------------------------------------------------
# SQLAlchemy whitelist
# ---------------------------------------------------------------------------

SQLALCHEMY_WHITELIST: list[WhitelistEntry] = [
    # Declarative model metadata
    WhitelistEntry(
        name_pattern=r"__tablename__|__table_args__|__mapper_args__|__abstract__",
        item_type="attribute",
        reason="SQLAlchemy declarative model metadata",
    ),
    # Common __repr__ / __str__ on models
    WhitelistEntry(
        name_pattern=r"__repr__|__str__",
        item_type="function",
        reason="SQLAlchemy model string representation",
    ),
    # Base / engine / session module-level variables
    WhitelistEntry(
        name_pattern=r"Base|engine|Session|SessionLocal|async_session|metadata",
        item_type="variable",
        reason="SQLAlchemy core object (Base, engine, session)",
    ),
]

# ---------------------------------------------------------------------------
# Pydantic whitelist
# ---------------------------------------------------------------------------

PYDANTIC_WHITELIST: list[WhitelistEntry] = [
    WhitelistEntry(
        name_pattern=r"model_config|Config",
        item_type=None,
        reason="Pydantic model configuration",
    ),
    WhitelistEntry(
        name_pattern=r"model_validator|field_validator|model_post_init",
        item_type="function",
        reason="Pydantic validator method",
    ),
    WhitelistEntry(
        name_pattern=r"__get_validators__|__get_pydantic_core_schema__",
        item_type="function",
        reason="Pydantic custom type hook",
    ),
]

# ---------------------------------------------------------------------------
# pytest whitelist
# ---------------------------------------------------------------------------

PYTEST_WHITELIST: list[WhitelistEntry] = [
    # conftest fixtures are discovered by name — never called directly in code
    WhitelistEntry(
        name_pattern=r".*",  # All functions in conftest.py match
        item_type="function",
        reason="pytest fixture in conftest.py (discovered by name, not imported)",
        # NOTE: applied only to conftest.py files via separate logic
    ),
    # Common fixture names used across projects
    WhitelistEntry(
        name_pattern=(
            r"client|app|db|session|engine|redis|cache|"
            r"tmp_path|tmp_dir|monkeypatch|caplog|capsys|"
            r"event_loop|anyio_backend"
        ),
        item_type="function",
        reason="Common pytest fixture name",
    ),
]

# ---------------------------------------------------------------------------
# Decorator-aware suppression
# ---------------------------------------------------------------------------

# Map of framework names to the decorator names that protect functions/classes
FRAMEWORK_DECORATORS: dict[str, set[str]] = {
    "django": {
        "receiver",  # Signal handlers: @receiver(post_save, …)
        "register",  # Admin registration
        "action",  # DRF @action
        "login_required",
        "permission_required",
        "cache_page",
        "staff_member_required",
    },
    "fastapi": {
        "get",
        "post",
        "put",
        "delete",
        "patch",
        "head",
        "options",
        "websocket",
        "exception_handler",
        "on_event",
        "middleware",
    },
    "flask": {
        "route",
        "before_request",
        "after_request",
        "teardown_request",
        "before_first_request",
        "teardown_appcontext",
        "errorhandler",
        "template_filter",
        "template_global",
        "template_test",
        "context_processor",
        "command",  # @app.cli.command()
        "url_value_preprocessor",
        "url_defaults",
    },
    "celery": {
        "task",
        "shared_task",
        "periodic_task",
    },
    "pytest": {
        "fixture",
        "mark",
    },
}


def find_decorated_names(file_path: Path, framework_names: set[str]) -> set[str]:
    """Return names of functions/classes protected by framework decorators.

    Uses AST to detect e.g. ``@app.route``, ``@shared_task``, ``@receiver``.
    Only inspects decorators whose base name appears in the relevant framework's
    decorator set — so a random ``@my_decorator`` is not suppressed.
    """
    relevant_decorators: set[str] = set()
    for fw in framework_names:
        relevant_decorators.update(FRAMEWORK_DECORATORS.get(fw, set()))

    if not relevant_decorators:
        return set()

    try:
        source = file_path.read_text(errors="ignore")
        tree = ast.parse(source, filename=str(file_path))
    except (OSError, SyntaxError):
        return set()

    protected: set[str] = set()
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            continue
        for dec in node.decorator_list:
            name = _decorator_base_name(dec)
            if name and name in relevant_decorators:
                protected.add(node.name)
                break

    return protected


def _decorator_base_name(node: ast.expr) -> str | None:
    """Extract the leaf attribute/name from a decorator expression.

    Examples:
    - ``@shared_task``          → "shared_task"
    - ``@app.route(…)``        → "route"
    - ``@app.task(bind=True)`` → "task"
    - ``@receiver(post_save)`` → "receiver"
    """
    match node:
        case ast.Name():
            return node.id
        case ast.Attribute():
            return node.attr
        case ast.Call():
            return _decorator_base_name(node.func)
        case _:
            return None


# ---------------------------------------------------------------------------
# Per-framework whitelist registry
# ---------------------------------------------------------------------------

_FRAMEWORK_WHITELISTS: dict[str, list[WhitelistEntry]] = {
    "django": DJANGO_WHITELIST,
    "fastapi": FASTAPI_WHITELIST,
    "flask": FLASK_WHITELIST,
    "celery": CELERY_WHITELIST,
    "sqlalchemy": SQLALCHEMY_WHITELIST,
    "pydantic": PYDANTIC_WHITELIST,
    "pytest": PYTEST_WHITELIST,
    "drf": DJANGO_WHITELIST,  # DRF reuses Django's list (DRF entries are included)
}


def get_whitelists_for_stack(stack: FrameworkStack) -> list[WhitelistEntry]:
    """Return combined whitelist entries for all detected frameworks.

    Queries the plugin registry first, falling back to the built-in
    ``_FRAMEWORK_WHITELISTS`` dict for any names not covered by a plugin.
    """
    from python_checkup.frameworks.registry import get_plugins_for_stack

    entries: list[WhitelistEntry] = []
    seen_ids: set[int] = set()  # avoid duplicating the same list object
    covered: set[str] = set()

    for plugin in get_plugins_for_stack(stack):
        wl = plugin.get_vulture_whitelist()
        for entry in wl:
            if id(entry) not in seen_ids:
                entries.append(entry)
                seen_ids.add(id(entry))
        covered.add(plugin.name)

    # Fall back to hardcoded dict for frameworks not covered by a plugin
    for name in stack.names:
        if name not in covered:
            wl = _FRAMEWORK_WHITELISTS.get(name, [])
            if id(wl) not in seen_ids:
                entries.extend(wl)
                seen_ids.add(id(wl))

    return entries


# ---------------------------------------------------------------------------
# Filtering logic
# ---------------------------------------------------------------------------


def apply_framework_whitelists(
    diagnostics: list[Diagnostic],
    stack: FrameworkStack,
    files: list[Path],
) -> tuple[list[Diagnostic], int, list[dict[str, str | int | None]]]:
    """Remove Vulture diagnostics that are framework false positives.

    Returns (filtered_diagnostics, suppressed_count, suppressed_examples).
    """
    whitelists = get_whitelists_for_stack(stack)
    if not whitelists:
        return diagnostics, 0, []

    # Collect decorator-protected names across all files
    protected_names: set[str] = set()
    for f in files:
        protected_names.update(find_decorated_names(f, stack.names))

    symbol_parents = _collect_symbol_parents(files)

    # Also suppress all functions in conftest.py files when pytest detected
    conftest_functions: set[str] = set()
    if stack.has("pytest"):
        for f in files:
            if f.name == "conftest.py":
                conftest_functions.update(_names_in_file(f))

    filtered: list[Diagnostic] = []
    suppressed = 0
    suppressed_examples: list[dict[str, str | int | None]] = []

    for d in diagnostics:
        symbol_name = _extract_symbol_name(d.message)
        item_type = _extract_item_type(d.rule_id)
        parent_name = _lookup_parent_name(
            symbol_parents, d.file_path, symbol_name, item_type, d.line
        )

        # Decorator-protected names are never dead code
        if symbol_name and symbol_name in protected_names:
            logger.debug("Suppressed framework FP (decorator): %s", d.message)
            suppressed += 1
            suppressed_examples.append(
                {
                    "name": symbol_name,
                    "item_type": item_type,
                    "file_path": str(d.file_path),
                    "line": d.line,
                    "reason": "Protected by framework decorator",
                    "parent": parent_name,
                }
            )
            continue

        # pytest conftest functions
        if symbol_name and symbol_name in conftest_functions:
            logger.debug("Suppressed framework FP (conftest): %s", d.message)
            suppressed += 1
            suppressed_examples.append(
                {
                    "name": symbol_name,
                    "item_type": item_type,
                    "file_path": str(d.file_path),
                    "line": d.line,
                    "reason": "pytest conftest discovery by name",
                    "parent": parent_name,
                }
            )
            continue

        # Whitelist pattern matching
        matched_entry = None
        if symbol_name:
            matched_entry = _matches_any_whitelist(
                symbol_name,
                item_type,
                whitelists,
                parent=parent_name,
            )
        if symbol_name and matched_entry is not None:
            logger.debug("Suppressed framework FP (whitelist): %s", d.message)
            suppressed += 1
            suppressed_examples.append(
                {
                    "name": symbol_name,
                    "item_type": item_type,
                    "file_path": str(d.file_path),
                    "line": d.line,
                    "reason": matched_entry.reason,
                    "parent": parent_name,
                }
            )
            continue

        filtered.append(d)

    if suppressed:
        logger.info(
            "Suppressed %d Vulture false positive(s) for framework(s): %s",
            suppressed,
            ", ".join(sorted(stack.names)),
        )

    return filtered, suppressed, suppressed_examples


def _extract_symbol_name(message: str) -> str | None:
    """Extract the symbol name from a Vulture diagnostic message.

    Vulture messages look like:
    "Unused function: 'get_queryset' (80% confidence)"
    "Unused attribute: 'ordering' (60% confidence)"
    """
    import re

    m = re.search(r"'([^']+)'", message)
    return m.group(1) if m else None


def _extract_item_type(rule_id: str) -> str:
    """Extract item type from Vulture rule_id like 'V-function', 'V-attribute'."""
    # rule_id format: "V-<type>" e.g. "V-function"
    if rule_id.startswith("V-"):
        return rule_id[2:]
    return "unknown"


def _matches_any_whitelist(
    name: str,
    item_type: str,
    whitelists: list[WhitelistEntry],
    parent: str | None = None,
) -> WhitelistEntry | None:
    for candidate_type in _candidate_item_types(item_type):
        for entry in whitelists:
            if entry.matches(name, candidate_type, parent=parent):
                return entry
    return None


def _candidate_item_types(item_type: str) -> tuple[str, ...]:
    if item_type == "method":
        return ("method", "function")
    if item_type == "property":
        return ("property", "attribute")
    return (item_type,)


def _collect_symbol_parents(
    files: list[Path],
) -> dict[tuple[str, str, str, int], str | None]:
    collected: dict[tuple[str, str, str, int], str | None] = {}
    for file_path in files:
        try:
            source = file_path.read_text(errors="ignore")
            tree = ast.parse(source, filename=str(file_path))
        except (OSError, SyntaxError):
            continue

        resolved = str(file_path.resolve())

        class _Visitor(ast.NodeVisitor):
            def __init__(self, resolved_path: str) -> None:
                self.class_stack: list[str] = []
                self.resolved_path = resolved_path

            def visit_ClassDef(self, node: ast.ClassDef) -> None:
                parent = self.class_stack[-1] if self.class_stack else None
                collected[(self.resolved_path, "class", node.name, node.lineno)] = (
                    parent
                )
                self.class_stack.append(node.name)
                self.generic_visit(node)
                self.class_stack.pop()

            def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
                parent = self.class_stack[-1] if self.class_stack else None
                kind = "method" if parent else "function"
                collected[(self.resolved_path, kind, node.name, node.lineno)] = parent
                if parent:
                    collected[
                        (self.resolved_path, "function", node.name, node.lineno)
                    ] = parent
                self.generic_visit(node)

            def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
                parent = self.class_stack[-1] if self.class_stack else None
                kind = "method" if parent else "function"
                collected[(self.resolved_path, kind, node.name, node.lineno)] = parent
                if parent:
                    collected[
                        (self.resolved_path, "function", node.name, node.lineno)
                    ] = parent
                self.generic_visit(node)

            def visit_Assign(self, node: ast.Assign) -> None:
                if self.class_stack:
                    parent = self.class_stack[-1]
                    for target in node.targets:
                        if isinstance(target, ast.Name):
                            collected[
                                (
                                    self.resolved_path,
                                    "attribute",
                                    target.id,
                                    node.lineno,
                                )
                            ] = parent
                self.generic_visit(node)

            def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
                if self.class_stack and isinstance(node.target, ast.Name):
                    parent = self.class_stack[-1]
                    collected[
                        (self.resolved_path, "attribute", node.target.id, node.lineno)
                    ] = parent
                self.generic_visit(node)

        _Visitor(resolved).visit(tree)

    return collected


def _lookup_parent_name(
    symbol_parents: dict[tuple[str, str, str, int], str | None],
    file_path: Path,
    symbol_name: str | None,
    item_type: str,
    line: int,
) -> str | None:
    if symbol_name is None:
        return None

    resolved = str(file_path.resolve())
    for candidate_type in _candidate_item_types(item_type):
        exact = symbol_parents.get((resolved, candidate_type, symbol_name, line))
        if exact is not None:
            return exact

    best_match: tuple[int, str | None] | None = None
    for (path_str, kind, name, lineno), parent in symbol_parents.items():
        if path_str != resolved or name != symbol_name:
            continue
        if kind not in _candidate_item_types(item_type):
            continue
        distance = abs(lineno - line)
        if best_match is None or distance < best_match[0]:
            best_match = (distance, parent)

    return best_match[1] if best_match is not None else None


def _names_in_file(file_path: Path) -> set[str]:
    """Return all function/class names defined at module level in a file."""
    try:
        source = file_path.read_text(errors="ignore")
        tree = ast.parse(source, filename=str(file_path))
    except (OSError, SyntaxError):
        return set()
    return {
        node.name
        for node in ast.walk(tree)
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
    }
