from __future__ import annotations

from typing import Protocol, runtime_checkable

from python_checkup.analysis_request import AnalysisRequest
from python_checkup.models import Category, Diagnostic


@runtime_checkable
class Analyzer(Protocol):
    """Protocol that all analyzers must satisfy.

    Analyzers can be built-in or loaded via entry points.
    Each analyzer:
    - Has a unique name and primary category
    - Can check if its underlying tool is available
    - Runs analysis and returns a list of Diagnostics
    """

    @property
    def name(self) -> str:
        """Unique identifier, e.g. 'ruff', 'mypy', 'bandit'."""
        ...

    @property
    def category(self) -> Category:
        """Primary category this analyzer contributes to."""
        ...

    async def is_available(self) -> bool:
        """Check if the underlying tool is installed and runnable.

        Returns True if the tool is available, False otherwise.
        This should be fast (check PATH, try import, etc).
        """
        ...

    async def analyze(
        self,
        request: AnalysisRequest,
    ) -> list[Diagnostic]:
        """Run analysis on the given files.

        Args:
            request: Structured request describing project context, enabled
                categories, profile, files, and configuration.

        Returns:
            List of diagnostics found. Empty list means no issues.

        Raises:
            TimeoutError: If analysis exceeds configured timeout.
        """
        ...
