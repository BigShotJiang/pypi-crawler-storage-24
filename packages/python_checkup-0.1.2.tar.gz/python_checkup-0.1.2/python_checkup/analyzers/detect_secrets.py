from __future__ import annotations

import asyncio
import logging
from pathlib import Path

from python_checkup.analysis_request import AnalysisRequest
from python_checkup.models import Category, Diagnostic, Severity

logger = logging.getLogger("python_checkup")


class DetectSecretsAnalyzer:
    """Find hardcoded secrets using entropy and pattern analysis."""

    @property
    def name(self) -> str:
        return "detect-secrets"

    @property
    def category(self) -> Category:
        return Category.SECURITY

    async def is_available(self) -> bool:
        """Check if detect-secrets is importable."""
        try:
            from detect_secrets.core.secrets_collection import (
                SecretsCollection,  # noqa: F401
            )

            return True
        except ImportError:
            return False

    async def analyze(
        self,
        request: AnalysisRequest,
    ) -> list[Diagnostic]:
        """Scan files for hardcoded secrets.

        Uses the detect-secrets library API with default settings.
        Runs in a thread because the scan is CPU-bound.
        """
        files = request.files
        if not files:
            return []
        return await asyncio.to_thread(self._analyze_sync, files)

    def _analyze_sync(self, files: list[Path]) -> list[Diagnostic]:
        """Synchronous scan — called via ``asyncio.to_thread``."""
        try:
            from detect_secrets.core.secrets_collection import SecretsCollection
            from detect_secrets.settings import (
                default_settings,
            )
        except ImportError:
            return []

        secrets = SecretsCollection()

        with default_settings():
            for f in files:
                try:
                    secrets.scan_file(str(f))
                except Exception as exc:  # noqa: PERF203
                    logger.debug("detect-secrets failed on %s: %s", f, exc)
                    continue

        diagnostics: list[Diagnostic] = []
        for filename, secret_list in secrets.json().items():
            if not isinstance(secret_list, list):
                continue
            for secret in secret_list:
                if not isinstance(secret, dict):
                    continue
                secret_type = str(secret.get("type", "unknown"))
                rule_id = f"SECRET-{secret_type.upper().replace(' ', '-')}"

                line_number = secret.get("line_number", 0)
                if not isinstance(line_number, int):
                    line_number = 0

                diagnostics.append(
                    Diagnostic(
                        file_path=Path(str(filename)),
                        line=line_number,
                        column=0,
                        severity=Severity.ERROR,
                        rule_id=rule_id,
                        tool="detect-secrets",
                        category=Category.SECURITY,
                        message=f"Potential {secret_type} detected",
                        fix=(
                            "Move this secret to an environment variable or a "
                            "secrets manager (e.g., AWS Secrets Manager, HashiCorp "
                            "Vault, or a .env file excluded from version control)."
                        ),
                    )
                )

        return diagnostics
