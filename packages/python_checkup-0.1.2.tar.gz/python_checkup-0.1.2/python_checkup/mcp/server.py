from __future__ import annotations

import json
import logging
import sys
from pathlib import Path

from mcp.server.fastmcp import FastMCP

from python_checkup.models import Category, Diagnostic, HealthReport, Severity

# Configure logging to stderr (CRITICAL for stdio servers --
# any stdout output corrupts the JSON-RPC protocol)
logging.basicConfig(
    level=logging.INFO,
    format="%(name)s %(levelname)s: %(message)s",
    stream=sys.stderr,
)
logger = logging.getLogger("python-checkup-mcp")

mcp_server = FastMCP("python-checkup")


# Tool 1: Full health check


@mcp_server.tool()
async def python_checkup_diagnose(
    path: str,
    quick: bool = False,
) -> str:
    """Run a complete health check on a Python project or specific files.

    Returns a 0-100 health score with categorized diagnostics covering
    code quality, type safety, security, complexity, and dead code.

    Call this after making significant code changes, before committing,
    or when you want an overview of a project's health. Use quick=True
    to skip slow analyzers (mypy) for sub-3-second results.

    Args:
        path: Absolute path to the project directory or a specific file.
        quick: If True, skip slow analyzers (mypy) for faster results.
    """
    try:
        from python_checkup.config import load_config
        from python_checkup.discovery import discover_python_files
        from python_checkup.runner import run_analysis

        project_path = Path(path).resolve()
        if not project_path.exists():
            return f"Error: Path does not exist: {path}"

        # If path is a file, use its parent as project root
        if project_path.is_file():
            project_root = project_path.parent
            files = [project_path]
            config = load_config(project_root)
        else:
            project_root = project_path
            config = load_config(project_root)
            files = discover_python_files(project_root, config.ignore_files)

        skip: set[str] = set()
        if quick:
            skip.add("mypy")

        report = await run_analysis(
            project_root=project_root,
            config=config,
            files=files,
            skip_analyzers=skip,
            quiet=True,  # No Rich progress in MCP mode
        )

        return _format_report(report)

    except Exception as e:
        logger.exception("Error in python_checkup_diagnose")
        return f"Error running analysis: {e}"


# Tool 2: Lint specific files


@mcp_server.tool()
async def python_checkup_lint(
    paths: list[str],
) -> str:
    """Run Ruff linting on specific Python files.

    Returns lint issues with rule IDs, severity, messages, and auto-fix
    suggestions. Use this for quick feedback after editing Python files.
    Faster than a full diagnose since it only runs the linter.

    Args:
        paths: List of absolute file paths to lint.
    """
    try:
        from python_checkup.analyzers.ruff import RuffAnalyzer
        from python_checkup.config import load_config

        analyzer = RuffAnalyzer()
        if not await analyzer.is_available():
            return "Error: Ruff is not installed. Run: pip install ruff"

        file_paths = [Path(p).resolve() for p in paths]
        for p in file_paths:
            if not p.exists():
                return f"Error: File not found: {p}"

        from python_checkup.analysis_request import AnalysisRequest
        from python_checkup.plan import PROFILE_DEFAULT

        diagnostics = await analyzer.analyze(
            AnalysisRequest(
                project_root=file_paths[0].parent,
                files=file_paths,
                config=load_config(file_paths[0].parent),
                categories={
                    Category.QUALITY,
                    Category.SECURITY,
                    Category.COMPLEXITY,
                    Category.DEAD_CODE,
                },
                profile=PROFILE_DEFAULT,
            )
        )

        if not diagnostics:
            return "No lint issues found. Code looks clean!"

        return _format_diagnostics(diagnostics, max_items=30)

    except Exception as e:
        logger.exception("Error in python_checkup_lint")
        return f"Error running lint: {e}"


# Tool 3: Type check specific files


@mcp_server.tool()
async def python_checkup_typecheck(
    paths: list[str],
) -> str:
    """Run type checking (mypy) on specific Python files.

    Returns type errors with locations, error codes, and explanations.
    Use this when writing or modifying typed Python code to catch type
    mismatches, missing annotations, and incompatible assignments.

    Args:
        paths: List of absolute file paths to type-check.
    """
    try:
        from python_checkup.analyzers.registry import get_analyzer

        analyzer = await get_analyzer("mypy")
        if analyzer is None:
            return "Error: mypy is not installed. Run: pip install python-checkup"

        file_paths = [Path(p).resolve() for p in paths]
        for p in file_paths:
            if not p.exists():
                return f"Error: File not found: {p}"

        from python_checkup.analysis_request import AnalysisRequest
        from python_checkup.config import load_config
        from python_checkup.plan import PROFILE_DEFAULT

        diagnostics = await analyzer.analyze(
            AnalysisRequest(
                project_root=file_paths[0].parent,
                files=file_paths,
                config=load_config(file_paths[0].parent),
                categories={Category.TYPE_SAFETY},
                profile=PROFILE_DEFAULT,
            )
        )

        if not diagnostics:
            return "No type errors found. Types look correct!"

        return _format_diagnostics(diagnostics, max_items=30)

    except Exception as e:
        logger.exception("Error in python_checkup_typecheck")
        return f"Error running type check: {e}"


# Tool 4: Security scan specific files


@mcp_server.tool()
async def python_checkup_security(
    paths: list[str],
) -> str:
    """Run security analysis on specific Python files.

    Checks for vulnerabilities including SQL injection, hardcoded secrets,
    insecure deserialization, shell injection, and weak cryptography.
    Returns findings with CWE mappings and severity levels.

    Call this before committing code that handles user input, credentials,
    file operations, subprocess calls, or external data.

    Args:
        paths: List of absolute file paths to scan for security issues.
    """
    try:
        from python_checkup.analyzers.registry import get_analyzer
        from python_checkup.analyzers.ruff import RuffAnalyzer

        results: list[Diagnostic] = []

        file_paths = [Path(p).resolve() for p in paths]
        for p in file_paths:
            if not p.exists():
                return f"Error: File not found: {p}"

        # Try Bandit
        bandit = await get_analyzer("bandit")
        if bandit:
            from python_checkup.analysis_request import AnalysisRequest
            from python_checkup.config import load_config
            from python_checkup.plan import PROFILE_DEFAULT

            diagnostics = await bandit.analyze(
                AnalysisRequest(
                    project_root=file_paths[0].parent,
                    files=file_paths,
                    config=load_config(file_paths[0].parent),
                    categories={Category.SECURITY},
                    profile=PROFILE_DEFAULT,
                )
            )
            results.extend(diagnostics)

        # Also run Ruff S-rules (always available)
        ruff = RuffAnalyzer()
        if await ruff.is_available():
            from python_checkup.analysis_request import AnalysisRequest
            from python_checkup.config import load_config
            from python_checkup.plan import PROFILE_DEFAULT

            all_diags = await ruff.analyze(
                AnalysisRequest(
                    project_root=file_paths[0].parent,
                    files=file_paths,
                    config=load_config(file_paths[0].parent),
                    categories={Category.SECURITY},
                    profile=PROFILE_DEFAULT,
                )
            )
            security_diags = [d for d in all_diags if d.category == Category.SECURITY]
            results.extend(security_diags)

        # Deduplicate by (file, line, rule_id)
        seen: set[tuple[str, int, str]] = set()
        unique: list[Diagnostic] = []
        for d in results:
            key = (str(d.file_path), d.line, d.rule_id)
            if key not in seen:
                seen.add(key)
                unique.append(d)

        if not unique:
            return "No security issues found. Code looks secure!"

        return _format_diagnostics(unique, max_items=30)

    except Exception as e:
        logger.exception("Error in python_checkup_security")
        return f"Error running security scan: {e}"


# Tool 5: Explain a rule


@mcp_server.tool()
async def python_checkup_explain_rule(
    rule_id: str,
) -> str:
    """Explain a specific lint/analysis rule by its ID.

    Returns the rule's purpose, an example of code that violates it,
    an example of correct code, and the recommended fix pattern.
    Supports Ruff rules (F401, E501, S101, C901, etc.), Bandit rules
    (B101, B608, etc.), and mypy error codes (return-value, arg-type, etc.).

    Use this to understand a flagged issue before fixing it.

    Args:
        rule_id: The rule ID to explain (e.g., 'S101', 'F401', 'C901', 'B608').
    """
    try:
        from python_checkup.skills.rule_db import explain_rule

        explanation = explain_rule(rule_id)
        return explanation

    except Exception as e:
        logger.exception("Error in python_checkup_explain_rule")
        return f"Error explaining rule: {e}"


# Output formatting helpers


def _format_report(report: HealthReport) -> str:
    """Format a HealthReport for MCP output, keeping under token limit."""
    data: dict[str, object] = {
        "score": report.score,
        "label": report.label,
        "categoryScores": [
            {
                "category": cs.category.value,
                "score": cs.score,
                "weight": cs.weight,
                "issueCount": cs.issue_count,
                "details": cs.details,
            }
            for cs in report.category_scores
        ],
        "project": {
            "pythonVersion": report.project.python_version,
            "framework": report.project.framework,
            "totalFiles": report.project.total_files,
            "totalLines": report.project.total_lines,
            "detectedFrameworks": report.project.detected_frameworks,
            "frameworkDetails": report.project.framework_details,
        },
        "analyzersUsed": report.analyzers_used,
        "analyzersSkipped": report.analyzers_skipped,
        "durationMs": report.duration_ms,
        "totalIssues": len(report.diagnostics),
    }

    # Add top issues (limit to 50 to stay under token limit)
    max_issues = 50
    top = sorted(
        report.diagnostics,
        key=lambda d: (
            0 if d.severity == Severity.ERROR else 1,
            str(d.file_path),
        ),
    )[:max_issues]

    data["topIssues"] = [
        {
            "file": str(d.file_path),
            "line": d.line,
            "ruleId": d.rule_id,
            "severity": d.severity.value,
            "message": d.message,
            "fix": d.fix,
        }
        for d in top
    ]

    if len(report.diagnostics) > max_issues:
        data["truncated"] = True
        data["note"] = f"Showing top {max_issues} of {len(report.diagnostics)} issues."

    # Framework context for AI agents to give framework-specific advice
    if report.framework_report:
        fr = report.framework_report
        data["framework_context"] = {
            "primary": fr.primary_framework,
            "displayName": fr.display_name,
            "allDetected": fr.detected_frameworks,
            "suppressedFalsePositives": fr.suppressed_count,
            "securityIssues": [
                {
                    "rule": item.rule_id,
                    "status": item.status,
                    "message": item.description,
                    "fix": item.fix,
                }
                for item in fr.security_checklist
                if item.status in ("fail", "warning")
            ],
            "ecosystem": [
                {"status": item.status, "description": item.description}
                for item in fr.ecosystem
            ],
        }
    elif report.project.detected_frameworks:
        data["framework_context"] = {
            "primary": report.project.framework,
            "allDetected": report.project.detected_frameworks,
        }

    return json.dumps(data, indent=2)


def _format_diagnostics(
    diagnostics: list[Diagnostic],
    max_items: int = 30,
) -> str:
    sorted_diags = sorted(
        diagnostics,
        key=lambda d: (
            0 if d.severity == Severity.ERROR else 1,
            str(d.file_path),
        ),
    )[:max_items]

    items = [
        {
            "file": str(d.file_path),
            "line": d.line,
            "column": d.column,
            "ruleId": d.rule_id,
            "severity": d.severity.value,
            "message": d.message,
            "fix": d.fix,
            "helpUrl": d.help_url,
        }
        for d in sorted_diags
    ]

    result: dict[str, object] = {
        "totalIssues": len(diagnostics),
        "showing": len(items),
        "issues": items,
    }

    if len(diagnostics) > max_items:
        result["truncated"] = True

    return json.dumps(result, indent=2)


# Entry point


def start_mcp_server() -> None:
    """Start the MCP server on stdio transport."""
    logger.info("Starting python-checkup MCP server")
    mcp_server.run(transport="stdio")
