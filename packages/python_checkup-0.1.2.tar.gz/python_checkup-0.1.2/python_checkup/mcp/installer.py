from __future__ import annotations

import json
import sys
from pathlib import Path

from rich.console import Console

console = Console(file=sys.stderr)

# MCP config entry to install for each editor
MCP_CONFIG_ENTRY: dict[str, object] = {
    "command": "uvx",
    "args": ["python-checkup", "--mcp"],
}

# Editor config file locations and their JSON key for MCP servers
EDITOR_TARGETS: list[dict[str, object]] = [
    {
        "name": "Claude Code (project)",
        "path": Path(".mcp.json"),
        "key": "mcpServers",
        "relative": True,
    },
    {
        "name": "Cursor",
        "path": Path(".cursor/mcp.json"),
        "key": "mcpServers",
        "relative": True,
    },
    {
        "name": "VS Code",
        "path": Path(".vscode/mcp.json"),
        "key": "servers",  # VS Code uses "servers" not "mcpServers"
        "relative": True,
    },
]


def install_mcp_config(project_root: Path | None = None) -> list[str]:
    """Detect editors and write MCP server config.

    Only installs into editor directories that already exist (so we
    don't create .cursor/ for someone who doesn't use Cursor), except
    for .mcp.json which is always created for Claude Code.

    Returns list of paths where config was written.
    """
    root = project_root or Path.cwd()
    installed: list[str] = []

    for target in EDITOR_TARGETS:
        is_relative = bool(target["relative"])
        target_path = target["path"]
        if not isinstance(target_path, Path):
            continue  # pragma: no cover
        target_key = target["key"]
        if not isinstance(target_key, str):
            continue  # pragma: no cover
        target_name = target["name"]
        if not isinstance(target_name, str):
            continue  # pragma: no cover

        config_path = root / target_path if is_relative else Path.home() / target_path

        # Only install if the editor directory already exists
        # (don't create .cursor/ for someone who doesn't use Cursor)
        if is_relative:
            parent = config_path.parent
            if parent.name in (".cursor", ".vscode") and not parent.exists():
                continue

        try:
            _write_config(config_path, target_key)
            installed.append(str(config_path))
            console.print(
                f"  [green]Installed[/green] -> {config_path} ({target_name})"
            )
        except Exception as e:
            console.print(f"  [red]Failed[/red] -> {config_path}: {e}")

    # Always install .mcp.json (Claude Code project-level)
    claude_path = root / ".mcp.json"
    if str(claude_path) not in installed:
        try:
            _write_config(claude_path, "mcpServers")
            installed.append(str(claude_path))
            console.print(f"  [green]Installed[/green] -> {claude_path}")
        except Exception as e:
            console.print(f"  [red]Failed[/red] -> {claude_path}: {e}")

    return installed


def _write_config(path: Path, server_key: str) -> None:
    """Write or merge MCP config into a JSON file.

    Preserves existing server entries -- only adds/updates the
    ``python-checkup`` entry under the appropriate key.
    """
    existing: dict[str, object] = {}
    if path.exists():
        try:
            raw = path.read_text()
            loaded = json.loads(raw)
            if isinstance(loaded, dict):
                existing = loaded
        except (json.JSONDecodeError, OSError):
            existing = {}

    # Merge -- don't overwrite other servers
    servers = existing.get(server_key)
    if not isinstance(servers, dict):
        servers = {}
    servers["python-checkup"] = MCP_CONFIG_ENTRY
    existing[server_key] = servers

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(existing, indent=2) + "\n")
