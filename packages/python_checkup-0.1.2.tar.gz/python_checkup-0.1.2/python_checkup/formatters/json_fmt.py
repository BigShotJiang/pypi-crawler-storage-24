from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path
from typing import Any

from python_checkup.models import HealthReport


def format_json(report: HealthReport) -> str:
    data = asdict(report)
    return json.dumps(data, indent=2, default=_json_serializer)


def _json_serializer(obj: Any) -> Any:
    if isinstance(obj, Path):
        return str(obj)
    if hasattr(obj, "value"):  # Enum
        return obj.value
    msg = f"Object of type {type(obj)} is not JSON serializable"
    raise TypeError(msg)
