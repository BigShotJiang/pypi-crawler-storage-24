from __future__ import annotations

from urllib.parse import quote


def generate_badge_url(score: int) -> str:
    """Generate a shields.io badge URL for the given score.

    Example output:
        https://img.shields.io/badge/py--checkup-87%2F100-brightgreen
    """
    color = _badge_color(score)
    # shields.io uses single hyphens as field separators (label-value-color),
    # so literal hyphens in label/value must be doubled to "--"
    label = "python--checkup"
    value = quote(f"{score}/100")
    return f"https://img.shields.io/badge/{label}-{value}-{color}"


def generate_badge_markdown(score: int, repo_url: str = "") -> str:
    """Generate complete markdown for a README badge.

    If repo_url is provided, the badge links to it.
    """
    url = generate_badge_url(score)
    alt = f"python-checkup: {score}/100"
    if repo_url:
        return f"[![{alt}]({url})]({repo_url})"
    return f"![{alt}]({url})"


def _badge_color(score: int) -> str:
    if score >= 75:
        return "brightgreen"
    elif score >= 50:
        return "yellow"
    else:
        return "red"
