from __future__ import annotations

import logging
import subprocess
from pathlib import Path

logger = logging.getLogger("python_checkup")


class GitError(Exception):
    """Raised when a git command fails."""


def get_changed_files(
    project_root: Path,
    *,
    base: str = "main",
) -> list[Path]:
    """Get Python files changed between current branch and base.

    Uses merge-base to find the common ancestor, then lists files
    changed since that point. This matches what a PR would show.

    Returns empty list if not in a git repo or if git commands fail.
    """
    try:
        # Step 1: Verify we're in a git repo
        _run_git(["rev-parse", "--git-dir"], cwd=project_root)

        # Step 2: Get current branch name (for logging)
        current_branch = _run_git(
            ["rev-parse", "--abbrev-ref", "HEAD"],
            cwd=project_root,
        ).strip()
        logger.debug("Current branch: %s", current_branch)

        # Step 3: Find merge-base (common ancestor)
        try:
            merge_base = _run_git(
                ["merge-base", base, "HEAD"],
                cwd=project_root,
            ).strip()
            logger.debug("Merge base with %s: %s", base, merge_base[:10])
        except GitError:
            logger.warning(
                "Could not find merge-base with '%s'. Comparing directly against '%s'.",
                base,
                base,
            )
            merge_base = base

        # Step 4: Get changed files (committed)
        # --diff-filter=ACMR: Added, Copied, Modified, Renamed
        output = _run_git(
            [
                "diff",
                "--name-only",
                "--diff-filter=ACMR",
                "--relative",
                merge_base,
            ],
            cwd=project_root,
        )

        # Also include uncommitted changes (staged + unstaged)
        uncommitted = _run_git(
            [
                "diff",
                "--name-only",
                "--diff-filter=ACMR",
                "--relative",
                "HEAD",
            ],
            cwd=project_root,
        )

        # Combine and deduplicate
        all_files = set(output.strip().split("\n")) | set(
            uncommitted.strip().split("\n")
        )

        # Step 5: Filter to Python files that exist
        python_files: list[Path] = []
        for f in sorted(all_files):
            f = f.strip()
            if not f or not f.endswith(".py"):
                continue
            full_path = project_root / f
            if full_path.is_file():
                python_files.append(full_path)

        logger.info(
            "Found %d changed Python files (branch: %s, base: %s)",
            len(python_files),
            current_branch,
            base,
        )
        return python_files

    except GitError as e:
        logger.warning("Git diff failed: %s. Falling back to full scan.", e)
        return []


def _run_git(args: list[str], cwd: Path) -> str:
    """Run a git command and return stdout.

    Raises GitError if the command fails.
    """
    try:
        result = subprocess.run(  # nosec B603 B607
            ["git", *args],
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=10,
        )
    except FileNotFoundError as exc:
        raise GitError("git is not installed or not on PATH") from exc
    except subprocess.TimeoutExpired as exc:
        raise GitError(f"git {args[0]} timed out") from exc

    if result.returncode != 0:
        raise GitError(
            f"git {' '.join(args)} failed "
            f"(exit {result.returncode}): "
            f"{result.stderr.strip()}"
        )

    return result.stdout
