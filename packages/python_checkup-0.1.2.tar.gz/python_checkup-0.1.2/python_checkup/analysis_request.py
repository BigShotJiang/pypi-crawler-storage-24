from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

from python_checkup.config import CheckupConfig
from python_checkup.models import Category

if TYPE_CHECKING:
    from python_checkup.detection import FrameworkStack


@dataclass
class AnalysisRequest:
    """Input contract shared by all analyzers."""

    project_root: Path
    files: list[Path]
    config: CheckupConfig
    categories: set[Category]
    profile: str
    framework: str | None = None
    framework_stack: FrameworkStack | None = None  # Full multi-framework stack
    diff_base: str | None = None
    quiet: bool = False
    no_cache: bool = False
    metadata: dict[str, object] = field(default_factory=dict)

    def config_dict(self) -> dict[str, object]:
        """Return a mutable dict representation for legacy integrations."""
        data = self.config.__dict__.copy()
        data["framework"] = self.framework
        data["profile"] = self.profile
        data["categories"] = [
            category.value
            for category in sorted(self.categories, key=lambda c: c.value)
        ]
        data.update(self.metadata)
        return data
