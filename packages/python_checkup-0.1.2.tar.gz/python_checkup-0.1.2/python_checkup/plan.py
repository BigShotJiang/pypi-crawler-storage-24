from __future__ import annotations

from dataclasses import dataclass, field

from python_checkup.models import Category

PROFILE_QUICK = "quick"
PROFILE_DEFAULT = "default"
PROFILE_FULL = "full"

TYPE_BACKEND_MYPY = "mypy"
TYPE_BACKEND_BASEDPYRIGHT = "basedpyright"
TYPE_BACKEND_AUTO = "auto"

ALL_CATEGORIES = {
    Category.QUALITY,
    Category.TYPE_SAFETY,
    Category.SECURITY,
    Category.COMPLEXITY,
    Category.DEAD_CODE,
    Category.DEPENDENCIES,
}


@dataclass(frozen=True)
class ScanPlan:
    """Concrete execution plan for a single run."""

    profile: str = PROFILE_DEFAULT
    categories: frozenset[Category] = field(
        default_factory=lambda: frozenset(ALL_CATEGORIES)
    )
    skipped_categories: frozenset[Category] = field(default_factory=frozenset)
    type_backend: str = TYPE_BACKEND_AUTO
    include_optional: bool = False
    apply_fixes: bool = False
    show_fix_suggestions: bool = False
    diff_mode: bool = False

    def includes(self, category: Category) -> bool:
        """Return True if the category is enabled in this plan."""
        return category in self.categories


def parse_categories(value: str | None) -> frozenset[Category] | None:
    """Parse a comma-separated category list."""
    if value is None:
        return None

    mapping = {
        "quality": Category.QUALITY,
        "types": Category.TYPE_SAFETY,
        "type_safety": Category.TYPE_SAFETY,
        "security": Category.SECURITY,
        "complexity": Category.COMPLEXITY,
        "dead_code": Category.DEAD_CODE,
        "dead-code": Category.DEAD_CODE,
        "dependencies": Category.DEPENDENCIES,
    }

    categories: set[Category] = set()
    for part in value.split(","):
        key = part.strip().lower()
        if not key:
            continue
        category = mapping.get(key)
        if category is None:
            msg = f"Unknown category: {part}"
            raise ValueError(msg)
        categories.add(category)

    return frozenset(categories)


def build_scan_plan(
    *,
    profile: str = PROFILE_DEFAULT,
    only_categories: frozenset[Category] | None = None,
    skip_categories: frozenset[Category] | None = None,
    quick: bool = False,
    include_optional: bool | None = None,
    apply_fixes: bool = False,
    show_fix_suggestions: bool = False,
    diff_mode: bool = False,
    type_backend: str = TYPE_BACKEND_AUTO,
) -> ScanPlan:
    """Build a concrete plan from CLI options."""
    if quick:
        profile = PROFILE_QUICK

    categories = set(only_categories or ALL_CATEGORIES)
    actually_skipped: frozenset[Category] = frozenset()
    if skip_categories:
        actually_skipped = frozenset(skip_categories & categories)
        categories.difference_update(skip_categories)

    if include_optional is None:
        include_optional = profile == PROFILE_FULL

    return ScanPlan(
        profile=profile,
        categories=frozenset(categories),
        skipped_categories=actually_skipped,
        type_backend=type_backend,
        include_optional=include_optional,
        apply_fixes=apply_fixes,
        show_fix_suggestions=show_fix_suggestions,
        diff_mode=diff_mode,
    )
