---
name: python_checkup
description: >
  Python code health analyzer that provides a 0-100 health score across six dimensions:
  code quality, type safety, security, complexity, dead code, and dependencies.
  Use this skill to write clean, secure, well-typed Python code and fix issues found
  by python-checkup scans.
version: "0.1.0"
---

# python-checkup Skill

You have access to python-checkup, a fast Python code health analyzer that scores
codebases 0-100 across six categories. Use this knowledge to write better Python
code and fix issues proactively.

## Quick Reference

```bash
# Full scan (zero-config)
python-checkup .

# JSON output for programmatic use
python-checkup . --json

# Score only (for CI gates)
python-checkup . --score

# Quick mode (skip slow analyzers like mypy)
python-checkup . --quick

# Scan only changed files
python-checkup . --diff main

# Fail if score drops below threshold
python-checkup . --fail-under 75
```

## Diagnostic Workflow

When working on a Python project with python-checkup:

1. **Run**: Execute `python-checkup .` to get the current health score
2. **Read**: Review the category scores and top issues
3. **Fix**: Address issues starting with highest-severity errors
4. **Re-run**: Execute `python-checkup .` again to verify fixes
5. **Verify**: Confirm the score improved and no new issues appeared

Always fix ERROR-severity issues before WARNING-severity issues.
Always fix security issues before style issues.

## Score Interpretation

| Score Range | Label | What It Means |
|-------------|-------|---------------|
| 75-100 | Healthy | Production-ready, well-maintained |
| 50-74 | Needs Work | Functional but has significant issues |
| 0-49 | Critical | Major problems requiring immediate attention |

## Categories and Weights

| Category | Default Weight | What's Checked |
|----------|---------------|----------------|
| Code Quality | 25% | Lint rules (unused imports, style, naming) |
| Type Safety | 20% | Type errors, missing annotations |
| Security | 20% | Vulnerabilities, hardcoded secrets, unsafe calls |
| Complexity | 15% | Cyclomatic complexity, maintainability index |
| Dead Code | 10% | Unused functions, variables, imports |
| Dependencies | 10% | Known CVEs, unused/missing deps |

## Rules by Category

### Code Quality (Ruff)

**F401 -- Unused import**
```python
# Bad
import os  # never used

def greet():
    return "hello"
```
```python
# Good
def greet():
    return "hello"
```
Fix: Remove the unused import statement.

**F841 -- Local variable assigned but never used**
```python
# Bad
def process():
    result = compute()  # result never used
    return True
```
```python
# Good
def process():
    compute()
    return True
```
Fix: Remove the assignment or use the variable.

**E501 -- Line too long**
```python
# Bad
def send_notification(user_email, subject, body, cc_list, bcc_list, attachments, priority, template_name):
    pass
```
```python
# Good
def send_notification(
    user_email: str,
    subject: str,
    body: str,
    cc_list: list[str],
    bcc_list: list[str],
    attachments: list[Path],
    priority: int,
    template_name: str,
) -> None:
    pass
```
Fix: Break long lines at logical points (after commas in signatures, at operators in expressions).

**E711 -- Comparison to None**
```python
# Bad
if result == None:
    handle_missing()
```
```python
# Good
if result is None:
    handle_missing()
```
Fix: Use `is None` or `is not None` instead of `==` / `!=`.

**UP035 -- Deprecated import**
```python
# Bad
from typing import Dict, List, Optional
```
```python
# Good (Python 3.10+)
def process(items: list[str], mapping: dict[str, int], value: str | None) -> None:
    pass
```
Fix: Use built-in generics (`list`, `dict`, `set`, `tuple`) and `X | Y` union syntax.

**B006 -- Mutable default argument**
```python
# Bad
def add_item(item, items=[]):
    items.append(item)
    return items
```
```python
# Good
def add_item(item, items=None):
    if items is None:
        items = []
    items.append(item)
    return items
```
Fix: Use `None` as default and initialize inside the function.

**N801 -- Class name not CapWords**
```python
# Bad
class my_processor:
    pass
```
```python
# Good
class MyProcessor:
    pass
```
Fix: Use CapWords (PascalCase) for class names.

**SIM108 -- Use ternary operator**
```python
# Bad
if condition:
    x = a
else:
    x = b
```
```python
# Good
x = a if condition else b
```
Fix: Use a ternary expression for simple if/else assignments.

### Security (Ruff/Bandit)

**S101 -- Use of assert**
```python
# Bad -- assert is removed with python -O
assert user.is_admin, "Not authorized"
```
```python
# Good
if not user.is_admin:
    raise PermissionError("Not authorized")
```
Fix: Replace `assert` with explicit `if`/`raise` for security checks.

**S102 -- Use of exec**
```python
# Bad
exec(user_provided_code)
```
```python
# Good
import ast
tree = ast.parse(user_provided_code, mode='eval')
# Validate AST nodes before evaluation
```
Fix: Avoid `exec()` entirely. If dynamic code execution is required, use `ast.parse()` with validation.

**S105 -- Hardcoded password**
```python
# Bad
DB_PASSWORD = "super_secret_123"
```
```python
# Good
import os
DB_PASSWORD = os.environ["DB_PASSWORD"]
```
Fix: Load secrets from environment variables, a secrets manager, or config files excluded from version control.

**S108 -- Insecure temp file**
```python
# Bad
f = open("/tmp/myapp_data.txt", "w")
```
```python
# Good
import tempfile
with tempfile.NamedTemporaryFile(mode="w", delete=False) as f:
    f.write(data)
```
Fix: Use `tempfile` module functions for secure temp file creation.

**S301 -- Pickle usage**
```python
# Bad
import pickle
data = pickle.load(open("data.pkl", "rb"))
```
```python
# Good
import json
with open("data.json") as f:
    data = json.load(f)
```
Fix: Use `json`, `msgpack`, or other safe serialization. If pickle is required, only load from trusted sources.

**S602 -- subprocess with shell=True**
```python
# Bad
subprocess.call(f"grep {user_input} /var/log/app.log", shell=True)
```
```python
# Good
subprocess.run(["grep", user_input, "/var/log/app.log"], check=True)
```
Fix: Use a list of arguments instead of a shell string. Never interpolate user input into shell commands.

**S608 -- SQL injection**
```python
# Bad
query = f"SELECT * FROM users WHERE name = '{name}'"
cursor.execute(query)
```
```python
# Good
cursor.execute("SELECT * FROM users WHERE name = %s", (name,))
```
Fix: Use parameterized queries. Never construct SQL with string formatting.

### Complexity (Radon)

**C901 -- Function too complex**
```python
# Bad -- cyclomatic complexity > 10
def process(data, mode, flags):
    if mode == "a":
        if flags.get("x"):
            for item in data:
                if item.valid:
                    if item.type == 1:
                        # ... deep nesting continues
```
```python
# Good -- break into focused functions
def process(data, mode, flags):
    handler = _get_handler(mode)
    return handler(data, flags)

def _handle_mode_a(data, flags):
    items = _filter_valid(data)
    if flags.get("x"):
        return _process_with_x(items)
    return _process_default(items)
```
Fix: Extract helper functions, use early returns, replace nested conditions with guard clauses.

### Type Safety (mypy)

**mypy-return-value -- Missing return type**
```python
# Bad
def calculate(x, y):
    return x + y
```
```python
# Good
def calculate(x: int, y: int) -> int:
    return x + y
```
Fix: Add type annotations to function signatures.

**mypy-assignment -- Incompatible types**
```python
# Bad
name: str = 42
```
```python
# Good
name: str = "hello"
count: int = 42
```
Fix: Ensure assigned values match the declared type.

### Dead Code (Vulture)

**Unused function**
```python
# Bad
def old_handler(request):  # never called anywhere
    return render(request, "old.html")
```
Fix: Remove the function if it's truly unused. If it's used dynamically (e.g., signal handler, template tag), add it to a whitelist.

**Unused variable**
```python
# Bad
def process():
    temp = compute_intermediate()  # temp never read
    return final_result()
```
Fix: Remove the assignment, or prefix with `_` if the call has side effects: `_temp = compute_intermediate()`.

### Dependencies

**DEP001 -- Missing dependency**
A module is imported but not declared in pyproject.toml/requirements.txt.
Fix: Add the package to your project's dependencies.

**DEP002 -- Unused dependency**
A package is declared as a dependency but never imported.
Fix: Remove it from your dependency list, or move to dev dependencies if only used in tests.

**DEP003 -- Transitive dependency**
A module is imported but only available as a transitive dependency (dependency of a dependency).
Fix: Add it as a direct dependency to avoid breakage when the parent package updates.

**CVE vulnerabilities**
Known security vulnerabilities in installed packages.
Fix: Upgrade to the patched version listed in the vulnerability report.

## Priority Order for Fixes

When python-checkup reports multiple issues, fix them in this order:

1. **Security ERRORs** -- SQL injection, hardcoded secrets, unsafe deserialization
2. **Dependency vulnerabilities** -- Known CVEs in installed packages
3. **Type errors** -- Runtime crashes from type mismatches
4. **Code quality ERRORs** -- Unused imports (F401), undefined names (F821)
5. **Complexity** -- Functions with grade D/E/F
6. **Dead code** -- Unused functions and variables
7. **Warnings and style** -- Formatting, naming conventions

## Common Patterns for Bulk Fixes

**Remove all unused imports at once:**
```bash
ruff check --select F401 --fix .
```

**Auto-fix all safe Ruff rules:**
```bash
ruff check --fix .
```

**Upgrade deprecated typing imports:**
```bash
ruff check --select UP --fix .
```

## When Writing New Code

Apply these principles to avoid python-checkup issues from the start:

1. Always add type annotations to function signatures
2. Never hardcode secrets -- use environment variables
3. Keep functions under 20 lines and complexity grade C or better
4. Use parameterized queries for all database operations
5. Prefer `pathlib.Path` over string path manipulation
6. Use `subprocess.run()` with list args, never `shell=True`
7. Import only what you use
8. Use `None` as default for mutable arguments (lists, dicts, sets)
