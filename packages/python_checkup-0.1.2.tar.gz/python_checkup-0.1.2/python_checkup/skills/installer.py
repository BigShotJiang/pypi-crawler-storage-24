from __future__ import annotations

import logging
from pathlib import Path

from rich.console import Console
from rich.table import Table

from python_checkup.skills.agents import (
    AgentTarget,
    detect_installed_agents,
    get_agent_targets,
)

logger = logging.getLogger("python_checkup")
console = Console()

# Marker used to identify python-checkup content in append-mode files
APPEND_MARKER_START = "<!-- python-checkup:start -->"
APPEND_MARKER_END = "<!-- python-checkup:end -->"


def install_skill(
    agents: list[str] | None = None,
    project_level: bool = False,
    force: bool = False,
) -> list[Path]:
    """Install SKILL.md and AGENTS.md to detected agent directories.

    Args:
        agents: Specific agent names to install for. If None, auto-detect.
        project_level: Also install to .agents/python-checkup/ in current dir.
        force: Overwrite existing files without prompting.

    Returns:
        List of paths that were written to.
    """
    skill_content = _load_skill_content()
    agents_content = _generate_agents_content(skill_content)

    if agents:
        all_targets = get_agent_targets()
        targets = [t for t in all_targets if t.name in agents]
        if not targets:
            console.print(
                f"[red]No matching agents found for: {', '.join(agents)}[/red]"
            )
            console.print(
                "Available agents: "
                + ", ".join(t.name for t in all_targets if t.detection_dirs)
            )
            return []
    else:
        targets = detect_installed_agents()

    if project_level:
        all_targets = get_agent_targets()
        project_target = next(t for t in all_targets if t.name == "project-level")
        targets.append(project_target)

    # Default to Claude Code if nothing detected
    if not targets:
        console.print(
            "[yellow]No AI coding agents detected. "
            "Defaulting to Claude Code (~/.claude/).[/yellow]"
        )
        all_targets = get_agent_targets()
        claude_target = next(t for t in all_targets if t.name == "claude-code")
        targets = [claude_target]

    written_paths: list[Path] = []
    for target in targets:
        paths = _install_to_target(target, skill_content, agents_content, force)
        written_paths.extend(paths)

    # Summary
    if written_paths:
        console.print()
        table = Table(title="Installed skill files", show_header=True)
        table.add_column("Agent", style="cyan")
        table.add_column("Path", style="dim")
        for target in targets:
            for path in written_paths:
                if str(target.skill_dir) in str(path) or (
                    target.global_rules_file
                    and str(target.global_rules_file) in str(path)
                ):
                    table.add_row(target.display_name, str(path))
        console.print(table)
        console.print(
            f"\n[green]Installed python-checkup skill to"
            f" {len(targets)} agent(s).[/green]"
        )
    else:
        console.print("[yellow]No files were written.[/yellow]")

    return written_paths


def _install_to_target(
    target: AgentTarget,
    skill_content: str,
    agents_content: str,
    force: bool,
) -> list[Path]:
    """Write skill files to a single agent target."""
    paths: list[Path] = []

    if target.is_append and target.global_rules_file:
        # Windsurf: append to global_rules.md
        path = target.global_rules_file
        path.parent.mkdir(parents=True, exist_ok=True)

        if path.exists():
            existing = path.read_text()
            # Remove old python-checkup content if present
            if APPEND_MARKER_START in existing:
                before = existing[: existing.index(APPEND_MARKER_START)]
                after_marker = existing.find(APPEND_MARKER_END)
                if after_marker != -1:
                    after = existing[after_marker + len(APPEND_MARKER_END) :]
                else:
                    after = ""
                existing = before + after

            # Append new content with markers
            new_content = (
                existing.rstrip()
                + "\n\n"
                + APPEND_MARKER_START
                + "\n"
                + agents_content
                + "\n"
                + APPEND_MARKER_END
                + "\n"
            )
            path.write_text(new_content)
        else:
            content = (
                APPEND_MARKER_START
                + "\n"
                + agents_content
                + "\n"
                + APPEND_MARKER_END
                + "\n"
            )
            path.write_text(content)

        paths.append(path)
        console.print(f"  [green]\u2713[/green] Appended to {path}")

    else:
        # Standard: write SKILL.md and AGENTS.md to skill directory
        skill_dir = target.skill_dir
        skill_dir.mkdir(parents=True, exist_ok=True)

        skill_path = skill_dir / "SKILL.md"
        agents_path = skill_dir / "AGENTS.md"

        if skill_path.exists() and not force:
            console.print(
                f"  [yellow]\u26a0[/yellow] {skill_path} exists "
                "(use --force to overwrite)"
            )
        else:
            skill_path.write_text(skill_content)
            paths.append(skill_path)
            console.print(f"  [green]\u2713[/green] Wrote {skill_path}")

        if agents_path.exists() and not force:
            console.print(
                f"  [yellow]\u26a0[/yellow] {agents_path} exists "
                "(use --force to overwrite)"
            )
        else:
            agents_path.write_text(agents_content)
            paths.append(agents_path)
            console.print(f"  [green]\u2713[/green] Wrote {agents_path}")

    return paths


def _load_skill_content() -> str:
    """Load the SKILL.md template and inject current rule data."""
    # The SKILL.md template is bundled as package data
    skill_path = Path(__file__).parent / "SKILL.md"
    if skill_path.exists():
        return skill_path.read_text()

    # Fallback: generate from rule database
    from python_checkup.skills.rule_db import generate_skill_content

    return generate_skill_content()


def _generate_agents_content(skill_content: str) -> str:
    """Strip YAML frontmatter from SKILL.md to produce AGENTS.md content."""
    lines = skill_content.split("\n")
    if lines and lines[0].strip() == "---":
        for i, line in enumerate(lines[1:], start=1):
            if line.strip() == "---":
                return "\n".join(lines[i + 1 :]).lstrip("\n")
    return skill_content


def uninstall_skill(agents: list[str] | None = None) -> list[Path]:
    """Remove installed skill files.

    Args:
        agents: Specific agents to uninstall from. If None, remove from all.

    Returns:
        List of paths that were removed.
    """
    if agents:
        all_targets = get_agent_targets()
        targets = [t for t in all_targets if t.name in agents]
    else:
        targets = get_agent_targets()

    removed: list[Path] = []
    for target in targets:
        if target.is_append and target.global_rules_file:
            path = target.global_rules_file
            if path.exists():
                content = path.read_text()
                if APPEND_MARKER_START in content:
                    before = content[: content.index(APPEND_MARKER_START)]
                    after_marker = content.find(APPEND_MARKER_END)
                    if after_marker != -1:
                        after = content[after_marker + len(APPEND_MARKER_END) :]
                    else:
                        after = ""
                    path.write_text((before + after).strip() + "\n")
                    removed.append(path)
                    console.print(f"  [green]\u2713[/green] Removed from {path}")
        else:
            skill_dir = target.skill_dir
            for filename in ("SKILL.md", "AGENTS.md"):
                filepath = skill_dir / filename
                if filepath.exists():
                    filepath.unlink()
                    removed.append(filepath)
                    console.print(f"  [green]\u2713[/green] Removed {filepath}")
            # Remove directory if empty
            if skill_dir.exists() and not any(skill_dir.iterdir()):
                skill_dir.rmdir()

    return removed
