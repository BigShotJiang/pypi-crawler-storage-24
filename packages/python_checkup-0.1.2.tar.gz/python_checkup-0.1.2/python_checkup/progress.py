from __future__ import annotations

import sys
from collections.abc import Generator
from contextlib import contextmanager

from rich.console import Console
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TaskID,
    TextColumn,
    TimeElapsedColumn,
)


@contextmanager
def analysis_progress(
    analyzer_names: list[str],
    *,
    quiet: bool = False,
) -> Generator[AnalysisTracker, None, None]:
    """Context manager that shows a progress display during analysis.

    Args:
        analyzer_names: Names of analyzers that will run.
        quiet: If True, suppress all output (for --score and --json).
    """
    if quiet:
        yield AnalysisTracker(progress=None, tasks={})
        return

    console = Console(file=sys.stderr)
    progress = Progress(
        SpinnerColumn(),
        TextColumn("[bold blue]{task.description}[/bold blue]"),
        BarColumn(bar_width=20),
        TextColumn("[dim]{task.fields[status]}[/dim]"),
        TimeElapsedColumn(),
        console=console,
        transient=True,
    )

    with progress:
        tasks: dict[str, TaskID] = {}
        for name in analyzer_names:
            task_id = progress.add_task(f"  {name}", total=1, status="waiting...")
            tasks[name] = task_id

        yield AnalysisTracker(progress=progress, tasks=tasks)


class AnalysisTracker:
    """Tracks progress of individual analyzers."""

    def __init__(
        self,
        progress: Progress | None,
        tasks: dict[str, TaskID],
    ) -> None:
        self._progress = progress
        self._tasks = tasks

    def start(self, analyzer_name: str) -> None:
        if self._progress and analyzer_name in self._tasks:
            self._progress.update(
                self._tasks[analyzer_name],
                status="running...",
            )

    def complete(self, analyzer_name: str, issue_count: int) -> None:
        if self._progress and analyzer_name in self._tasks:
            status = f"done ({issue_count} issues)" if issue_count else "done"
            self._progress.update(
                self._tasks[analyzer_name],
                completed=1,
                status=status,
            )

    def fail(self, analyzer_name: str, error: str) -> None:
        if self._progress and analyzer_name in self._tasks:
            self._progress.update(
                self._tasks[analyzer_name],
                completed=1,
                status=f"[red]failed: {error}[/red]",
            )

    def skip(self, analyzer_name: str) -> None:
        if self._progress and analyzer_name in self._tasks:
            self._progress.update(
                self._tasks[analyzer_name],
                completed=1,
                status="[dim]skipped[/dim]",
            )
