from __future__ import annotations

import logging
import re
import subprocess
from fnmatch import fnmatch
from pathlib import Path

logger = logging.getLogger("python_checkup")

# Directories always ignored, regardless of config.
DEFAULT_IGNORE_DIRS: frozenset[str] = frozenset(
    {
        ".venv",
        "venv",
        ".env",
        "env",
        "__pycache__",
        ".git",
        "node_modules",
        ".tox",
        ".nox",
        ".mypy_cache",
        ".ruff_cache",
        ".pytest_cache",
        ".eggs",
        "build",
        "dist",
        ".hatch",
        ".pixi",
    }
)


def discover_python_files(
    root: Path,
    ignore_patterns: list[str] | None = None,
    ignore_dirs: list[str] | None = None,
    ignore_extra_patterns: list[str] | None = None,
    focus: list[str] | None = None,
) -> list[Path]:
    """Find all Python files in root, respecting .gitignore and config.

    Strategy:
    1. If inside a git repo, use `git ls-files` -- this automatically
       respects .gitignore, .git/info/exclude, and global gitignore.
    2. If not in a git repo, fall back to rglob with default ignores.

    In both cases, apply user-configured ignore patterns on top.

    Args:
        root: Project root directory.
        ignore_patterns: fnmatch glob patterns (legacy ``ignore.files`` key).
        ignore_dirs: Directory names to skip entirely (``ignore.dirs`` key).
        ignore_extra_patterns: Mixed glob + ``regex:``-prefixed patterns
            (``ignore.patterns`` key).
        focus: If set, restrict results to files under this subdirectory.
    """
    ignore_patterns = ignore_patterns or []
    ignore_dirs = ignore_dirs or []
    ignore_extra_patterns = ignore_extra_patterns or []

    # Try git-based discovery first
    files = _git_ls_files(root)
    if files is None:
        # Not a git repo -- fall back to rglob
        files = _rglob_discovery(root)

    if ignore_dirs:
        files = _apply_dir_filter(files, root, ignore_dirs)

    if ignore_patterns:
        files = _apply_ignore_patterns(files, root, ignore_patterns)

    if ignore_extra_patterns:
        files = _apply_mixed_patterns(files, root, ignore_extra_patterns)

    if focus:
        files = _apply_focus(files, root, focus if isinstance(focus, list) else [focus])

    return sorted(files)


def _git_ls_files(root: Path) -> list[Path] | None:
    """Use git ls-files to find tracked + untracked Python files.

    Returns None if not in a git repo.

    git ls-files --cached --others --exclude-standard gives us:
    - All tracked files (--cached)
    - Untracked files that aren't gitignored (--others --exclude-standard)
    """
    try:
        subprocess.run(  # noqa: S603  # nosec B603 B607
            ["git", "rev-parse", "--git-dir"],
            cwd=root,
            capture_output=True,
            check=True,
            timeout=5,
        )
    except (
        subprocess.CalledProcessError,
        FileNotFoundError,
        subprocess.TimeoutExpired,
    ):
        return None

    try:
        result = subprocess.run(  # noqa: S603  # nosec B603 B607
            [
                "git",
                "ls-files",
                "--cached",
                "--others",
                "--exclude-standard",
                "-z",
                "*.py",
            ],
            cwd=root,
            capture_output=True,
            text=True,
            timeout=10,
        )
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
        return None

    if result.returncode != 0:
        return None

    files: list[Path] = []
    for entry in result.stdout.split("\0"):
        entry = entry.strip()
        if not entry:
            continue
        full_path = (root / entry).resolve()
        if full_path.is_file():
            files.append(full_path)

    logger.debug("git ls-files found %d Python files", len(files))
    return files


def _rglob_discovery(root: Path) -> list[Path]:
    """Fallback file discovery using rglob with default ignores."""
    files: list[Path] = []
    for py_file in root.rglob("*.py"):
        try:
            relative = py_file.relative_to(root)
        except ValueError:
            continue

        parts = relative.parts
        if any(part in DEFAULT_IGNORE_DIRS for part in parts):
            continue

        # Skip egg-info directories
        if any(part.endswith(".egg-info") for part in parts):
            continue

        files.append(py_file)

    logger.debug("rglob found %d Python files", len(files))
    return files


def _apply_ignore_patterns(
    files: list[Path],
    root: Path,
    patterns: list[str],
) -> list[Path]:
    """Apply user-configured fnmatch glob ignore patterns.

    Supports simple glob patterns:
    - "tests/**" -- ignore everything under tests/
    - "*.generated.py" -- ignore files matching pattern
    - "migrations/" -- ignore directory by name
    """
    filtered: list[Path] = []
    for f in files:
        try:
            relative = str(f.relative_to(root))
        except ValueError:
            relative = str(f)

        if any(fnmatch(relative, pat) for pat in patterns):
            continue

        # Also check directory components
        try:
            parts = f.relative_to(root).parts
        except ValueError:
            parts = ()

        if any(fnmatch(part, pat.rstrip("/")) for part in parts for pat in patterns):
            continue

        filtered.append(f)

    skipped = len(files) - len(filtered)
    if skipped > 0:
        logger.debug("Ignore patterns filtered out %d files", skipped)

    return filtered


def _apply_dir_filter(
    files: list[Path],
    root: Path,
    ignore_dirs: list[str],
) -> list[Path]:
    """Strip files whose relative path contains any of the named dir components."""
    ignore_set = set(ignore_dirs)
    filtered: list[Path] = []
    for f in files:
        try:
            parts = f.relative_to(root).parts
        except ValueError:
            parts = f.parts
        if any(part in ignore_set for part in parts[:-1]):  # exclude filename itself
            continue
        filtered.append(f)

    skipped = len(files) - len(filtered)
    if skipped > 0:
        logger.debug("ignore_dirs filtered out %d files", skipped)

    return filtered


def _compile_mixed_pattern(pat: str) -> tuple[bool, re.Pattern[str] | str]:
    """Parse a pattern that may carry a ``regex:`` prefix.

    Returns ``(is_regex, compiled_re_or_glob_string)``.
    """
    if pat.startswith("regex:"):
        return True, re.compile(pat[6:])
    return False, pat


def _apply_mixed_patterns(
    files: list[Path],
    root: Path,
    patterns: list[str],
) -> list[Path]:
    """Apply a list of mixed glob / regex patterns.

    Patterns prefixed with ``regex:`` are compiled as regular expressions
    and matched against the relative path.  All other patterns are treated
    as fnmatch globs (same behaviour as ``_apply_ignore_patterns``).
    """
    compiled = [_compile_mixed_pattern(p) for p in patterns]
    filtered: list[Path] = []
    for f in files:
        try:
            relative = str(f.relative_to(root))
        except ValueError:
            relative = str(f)

        matched = False
        for is_regex, pat in compiled:
            if is_regex and isinstance(pat, re.Pattern):
                if pat.search(relative):
                    matched = True
                    break
            elif not is_regex and isinstance(pat, str) and fnmatch(relative, pat):
                matched = True
                break
        if not matched:
            filtered.append(f)

    skipped = len(files) - len(filtered)
    if skipped > 0:
        logger.debug("ignore_patterns filtered out %d files", skipped)

    return filtered


def _apply_focus(
    files: list[Path],
    root: Path,
    focus: list[str],
) -> list[Path]:
    """Restrict files to those under any of the focus paths."""
    scope_roots = [(root / f).resolve() for f in focus]
    filtered = [
        f
        for f in files
        if any(str(f.resolve()).startswith(str(sr)) for sr in scope_roots)
    ]
    logger.info(
        "Focus mode: restricted to %s (%d of %d files)",
        ", ".join(focus),
        len(filtered),
        len(files),
    )
    return filtered
