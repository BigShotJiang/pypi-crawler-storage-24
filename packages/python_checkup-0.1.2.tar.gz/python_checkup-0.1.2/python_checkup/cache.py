from __future__ import annotations

import hashlib
import json
import logging
import time
from pathlib import Path

from python_checkup import __version__
from python_checkup.models import Category, Diagnostic, Severity

logger = logging.getLogger("python_checkup")

# Include the package version so any python-checkup upgrade automatically
# invalidates the cache (analyzer logic may have changed).
CACHE_VERSION = f"v1-{__version__}"
# Maximum age for cache entries before cleanup (7 days)
CACHE_MAX_AGE_SECONDS = 7 * 24 * 60 * 60
# Maximum total cache size before cleanup (100 MB)
CACHE_MAX_SIZE_BYTES = 100 * 1024 * 1024


class AnalysisCache:
    """Per-file, per-analyzer cache backed by the local filesystem.

    Each file's diagnostics are cached independently, keyed on the
    SHA-256 hash of the file's content. When a file changes, its hash
    changes, so the old cache entry is never read again.

    The cache directory defaults to .python-checkup-cache/ in the project root.
    """

    def __init__(self, project_root: Path, enabled: bool = True) -> None:
        self.project_root = project_root
        self.enabled = enabled
        self.cache_dir = project_root / ".python-checkup-cache" / CACHE_VERSION
        self._hits = 0
        self._misses = 0

        if self.enabled:
            self._ensure_cache_dir()

    def _ensure_cache_dir(self) -> None:
        """Create cache directory and .gitignore if they don't exist."""
        self.cache_dir.mkdir(parents=True, exist_ok=True)

        gitignore = self.project_root / ".python-checkup-cache" / ".gitignore"
        if not gitignore.exists():
            gitignore.write_text("*\n")

    def _file_hash(self, path: Path) -> str:
        """Compute truncated SHA-256 hash of file contents.

        Returns first 16 hex chars (64 bits) of SHA-256.
        Reads file in binary mode to avoid encoding issues.
        """
        h = hashlib.sha256()
        try:
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(8192), b""):
                    h.update(chunk)
        except OSError:
            return "0" * 16
        return h.hexdigest()[:16]

    def _cache_key(self, analyzer_name: str, file_path: Path) -> str:
        """Build cache key: {analyzer_name}:{content_hash}."""
        content_hash = self._file_hash(file_path)
        return f"{analyzer_name}:{content_hash}"

    def _cache_path(self, cache_key: str) -> Path:
        # Replace colons for Windows compatibility
        safe_key = cache_key.replace(":", "_")
        return self.cache_dir / f"{safe_key}.json"

    def get(self, analyzer_name: str, file_path: Path) -> list[Diagnostic] | None:
        """Return cached diagnostics if file content hasn't changed.

        Returns None on cache miss. Returns list[Diagnostic] on hit
        (which may be an empty list, meaning "no issues found").
        """
        if not self.enabled:
            return None

        cache_key = self._cache_key(analyzer_name, file_path)
        cache_file = self._cache_path(cache_key)

        if not cache_file.exists():
            self._misses += 1
            return None

        try:
            raw = json.loads(cache_file.read_text())
            diagnostics = [_deserialize_diagnostic(d) for d in raw]
            self._hits += 1
            logger.debug("Cache hit: %s for %s", analyzer_name, file_path.name)
            return diagnostics
        except (json.JSONDecodeError, KeyError, TypeError, ValueError):
            logger.debug("Cache corrupted for %s, removing", cache_key)
            cache_file.unlink(missing_ok=True)
            self._misses += 1
            return None

    def set(
        self,
        analyzer_name: str,
        file_path: Path,
        diagnostics: list[Diagnostic],
    ) -> None:
        """Cache diagnostics for a file.

        Stores an empty list for clean files (so we know "no issues"
        vs "not yet analyzed").
        """
        if not self.enabled:
            return

        cache_key = self._cache_key(analyzer_name, file_path)
        cache_file = self._cache_path(cache_key)

        try:
            serialized = [_serialize_diagnostic(d) for d in diagnostics]
            cache_file.write_text(json.dumps(serialized, default=str))
        except OSError as e:
            logger.debug("Failed to write cache for %s: %s", cache_key, e)

    def get_stats(self) -> dict[str, int]:
        total = self._hits + self._misses
        return {
            "hits": self._hits,
            "misses": self._misses,
            "total": total,
            "hit_rate_pct": (round(self._hits / total * 100) if total > 0 else 0),
        }

    def clear(self) -> int:
        """Delete all cache entries. Returns number of entries deleted."""
        count = 0
        if self.cache_dir.exists():
            for f in self.cache_dir.glob("*.json"):
                f.unlink()
                count += 1
        logger.info("Cleared %d cache entries", count)
        return count

    def cleanup(self) -> int:
        """Remove stale cache entries older than CACHE_MAX_AGE_SECONDS.

        Also enforces CACHE_MAX_SIZE_BYTES by removing oldest entries
        first. Returns number of entries removed.
        """
        if not self.cache_dir.exists():
            return 0

        now = time.time()
        entries: list[tuple[Path, float, int]] = []
        removed = 0

        for f in self.cache_dir.glob("*.json"):
            stat = f.stat()
            age = now - stat.st_mtime
            if age > CACHE_MAX_AGE_SECONDS:
                f.unlink()
                removed += 1
            else:
                entries.append((f, stat.st_mtime, stat.st_size))

        # Enforce size limit: remove oldest first
        total_size = sum(size for _, _, size in entries)
        if total_size > CACHE_MAX_SIZE_BYTES:
            entries.sort(key=lambda e: e[1])  # oldest first
            for path, _, size in entries:
                if total_size <= CACHE_MAX_SIZE_BYTES:
                    break
                path.unlink()
                total_size -= size
                removed += 1

        if removed > 0:
            logger.debug("Cache cleanup: removed %d stale entries", removed)
        return removed


def _serialize_diagnostic(d: Diagnostic) -> dict[str, object]:
    return {
        "file_path": str(d.file_path),
        "line": d.line,
        "column": d.column,
        "severity": d.severity.value,
        "rule_id": d.rule_id,
        "tool": d.tool,
        "category": d.category.value,
        "message": d.message,
        "fix": d.fix,
        "help_url": d.help_url,
        "end_line": d.end_line,
        "end_column": d.end_column,
    }


def _deserialize_diagnostic(data: dict[str, object]) -> Diagnostic:
    file_path = data["file_path"]
    line = data["line"]
    column = data["column"]
    severity_val = data["severity"]
    rule_id = data["rule_id"]
    tool = data["tool"]
    category_val = data["category"]
    message = data["message"]

    if (
        not isinstance(file_path, str)
        or not isinstance(line, int)
        or not isinstance(column, int)
        or not isinstance(severity_val, str)
        or not isinstance(rule_id, str)
        or not isinstance(tool, str)
        or not isinstance(category_val, str)
        or not isinstance(message, str)
    ):
        msg = "Invalid diagnostic data types"
        raise TypeError(msg)

    fix = data.get("fix")
    help_url = data.get("help_url")
    end_line = data.get("end_line")
    end_column = data.get("end_column")

    return Diagnostic(
        file_path=Path(file_path),
        line=line,
        column=column,
        severity=Severity(severity_val),
        rule_id=rule_id,
        tool=tool,
        category=Category(category_val),
        message=message,
        fix=str(fix) if fix is not None else None,
        help_url=str(help_url) if help_url is not None else None,
        end_line=int(end_line) if isinstance(end_line, int | float | str) else None,
        end_column=int(end_column)
        if isinstance(end_column, int | float | str)
        else None,
    )
