from __future__ import annotations

import asyncio
import logging
import sys
import time
from pathlib import Path
from typing import TYPE_CHECKING

from python_checkup.analysis_request import AnalysisRequest
from python_checkup.analyzer_catalog import ANALYZER_CATALOG, get_analyzer_info
from python_checkup.analyzers.cached import CachedAnalyzer
from python_checkup.analyzers.registry import discover_analyzers
from python_checkup.cache import AnalysisCache
from python_checkup.config import CheckupConfig
from python_checkup.dedup import deduplicate
from python_checkup.detection import FrameworkStack, detect_frameworks
from python_checkup.discovery import discover_python_files
from python_checkup.models import (
    Category,
    CategoryCoverage,
    ChecklistItem,
    CoverageInfo,
    Diagnostic,
    FrameworkReport,
    HealthReport,
    ProjectInfo,
    Severity,
)
from python_checkup.plan import PROFILE_DEFAULT, ScanPlan, build_scan_plan
from python_checkup.progress import analysis_progress
from python_checkup.scoring.engine import compute_health_report
from python_checkup.scoring.framework_adjustments import ScoringContext

if TYPE_CHECKING:
    from python_checkup.analyzers import Analyzer

logger = logging.getLogger("python_checkup")

# Analyzers that benefit from per-file caching.
# mypy is excluded because it needs project-wide context
# (it relies on its own .mypy_cache/ instead).
CACHEABLE_ANALYZERS = {"ruff", "bandit", "radon", "vulture"}


def _detect_project_framework(
    project_root: Path,
    config: CheckupConfig | None = None,
) -> tuple[str | None, str | None, FrameworkStack]:
    """Detect the project framework stack and return (primary_name, label, stack)."""
    stack = detect_frameworks(project_root, config=config)
    if not stack.primary:
        return None, None, stack

    primary = stack.primary
    label = f"{primary.name}-{primary.version}" if primary.version else primary.name
    return primary.name, label, stack


def _filter_analyzers(
    all_analyzers: list[Analyzer],
    skip_analyzers: set[str],
    plan: ScanPlan,
    cache: AnalysisCache,
) -> tuple[list[Analyzer | CachedAnalyzer], list[str], list[str]]:
    """Filter analyzers based on skip list, plan, and cache settings.

    Returns (active, skipped_names, optional_unavailable).
    """
    active: list[Analyzer | CachedAnalyzer] = []
    skipped_names = [a.name for a in all_analyzers if a.name in skip_analyzers]
    optional_unavailable: list[str] = []

    for a in all_analyzers:
        if a.name in skip_analyzers:
            continue
        if _should_skip_analyzer(a.name, plan, skipped_names, optional_unavailable):
            continue
        if a.name in CACHEABLE_ANALYZERS and cache.enabled:
            active.append(CachedAnalyzer(a, cache))
        else:
            active.append(a)

    return active, skipped_names, optional_unavailable


def _should_skip_analyzer(
    name: str,
    plan: ScanPlan,
    skipped_names: list[str],
    optional_unavailable: list[str],
) -> bool:
    """Check if an analyzer should be skipped based on catalog info and plan."""
    info = get_analyzer_info(name)
    if info is None:
        return False
    if not info.categories.intersection(plan.categories):
        skipped_names.append(name)
        return True
    if plan.profile not in info.profiles:
        skipped_names.append(name)
        return True
    if info.optional and not plan.include_optional:
        optional_unavailable.append(name)
        skipped_names.append(name)
        return True
    return False


def _collect_results(
    results: list[tuple[str, list[Diagnostic] | None, dict[str, object]]],
) -> tuple[list[Diagnostic], list[str], list[float], list[str]]:
    """Collect diagnostics, used analyzers, MI scores, and failed names from results."""
    all_diagnostics: list[Diagnostic] = []
    analyzers_used: list[str] = []
    mi_scores: list[float] = []
    failed_names: list[str] = []

    for name, result, cfg in results:
        if result is not None:
            all_diagnostics.extend(result)
            analyzers_used.append(name)
            if name == "radon" and "_radon_mi_scores" in cfg:
                raw_mi = cfg["_radon_mi_scores"]
                if isinstance(raw_mi, list):
                    mi_scores = raw_mi
        else:
            failed_names.append(name)

    return all_diagnostics, analyzers_used, mi_scores, failed_names


def _handle_cache_stats(cache: AnalysisCache) -> dict[str, int] | None:
    """Collect cache statistics and run cleanup if cache is enabled."""
    if not cache.enabled:
        return None
    cache_stats = cache.get_stats()
    logger.info(
        "Cache: %d hits, %d misses (%d%% hit rate)",
        cache_stats["hits"],
        cache_stats["misses"],
        cache_stats["hit_rate_pct"],
    )
    cache.cleanup()
    return cache_stats


async def run_analysis(
    project_root: Path,
    config: CheckupConfig,
    files: list[Path] | None = None,
    skip_analyzers: set[str] | None = None,
    quiet: bool = False,
    no_cache: bool = False,
    plan: ScanPlan | None = None,
    diff_base: str | None = None,
) -> HealthReport:
    """Run all available analyzers with progress feedback.

    Args:
        project_root: Root directory to analyze.
        config: Resolved configuration.
        files: Specific files to analyze. If None, discovers all.
        skip_analyzers: Set of analyzer names to skip.
        quiet: Suppress progress output (for --score and --json).
        no_cache: If True, skip the cache entirely (fresh run).
    """
    start = time.monotonic()
    skip_analyzers = skip_analyzers or set()
    plan = plan or build_scan_plan(profile=PROFILE_DEFAULT)

    if files is None:
        files = discover_python_files(
            project_root,
            ignore_patterns=config.ignore_files,
            ignore_dirs=config.ignore_dirs,
            ignore_extra_patterns=config.ignore_patterns,
            focus=config.focus,
        )

    if not files:
        return _empty_report(start)

    cache = AnalysisCache(project_root, enabled=not no_cache)
    framework_name, framework_label, framework_stack = _detect_project_framework(
        project_root, config
    )

    all_analyzers = await discover_analyzers()
    active, skipped_names, optional_unavailable = _filter_analyzers(
        all_analyzers, skip_analyzers, plan, cache
    )

    if not active:
        logger.warning("No analyzers available after filtering")
        return _empty_report(start)

    # Run with progress tracking
    with analysis_progress([a.name for a in active], quiet=quiet) as tracker:

        async def run_one(
            analyzer: Analyzer | CachedAnalyzer,
            request: AnalysisRequest,
        ) -> tuple[str, list[Diagnostic] | None, dict[str, object]]:
            tracker.start(analyzer.name)
            try:
                result = await analyzer.analyze(request)
                tracker.complete(analyzer.name, len(result))
                return analyzer.name, result, request.metadata
            except asyncio.TimeoutError:
                tracker.fail(analyzer.name, "timed out")
                logger.warning("%s timed out", analyzer.name)
                return analyzer.name, None, request.metadata
            except Exception as e:
                error_str = str(e)[:50]
                tracker.fail(analyzer.name, error_str)
                logger.warning(
                    "%s failed: %s: %s",
                    analyzer.name,
                    type(e).__name__,
                    e,
                )
                return analyzer.name, None, request.metadata

        tasks = []
        for a in active:
            request = AnalysisRequest(
                project_root=project_root,
                files=files,
                config=config,
                categories=set(plan.categories),
                profile=plan.profile,
                framework=framework_name,
                framework_stack=framework_stack,
                diff_base=diff_base,
                quiet=quiet,
                no_cache=no_cache,
                metadata={},
            )
            tasks.append(run_one(a, request))
        results = await asyncio.gather(*tasks)

    all_diagnostics, analyzers_used, mi_scores, failed_names = _collect_results(results)
    skipped_names.extend(failed_names)

    cache_stats = _handle_cache_stats(cache)

    # Deduplicate (Ruff/Bandit overlap)
    all_diagnostics = deduplicate(all_diagnostics)

    if config.ignore_rules:
        all_diagnostics = [
            d for d in all_diagnostics if d.rule_id not in config.ignore_rules
        ]

    if config.disabled_framework_rules:
        disabled_fw = set(config.disabled_framework_rules)
        all_diagnostics = [d for d in all_diagnostics if d.rule_id not in disabled_fw]

    total_lines = sum(_count_lines(f) for f in files)
    detected_names = [fw.name for fw in framework_stack.all_frameworks]
    framework_details = {
        fw.name: fw.version
        for fw in framework_stack.all_frameworks
        if fw.version is not None
    }
    project = ProjectInfo(
        python_version=_detect_python_version(),
        framework=framework_label,
        total_files=len(files),
        total_lines=total_lines,
        detected_frameworks=detected_names,
        framework_details=framework_details,
    )

    duration_ms = int((time.monotonic() - start) * 1000)

    combined_metadata: dict[str, object] = {
        key: value
        for _name, _result, metadata in results
        for key, value in metadata.items()
    }

    coverage = _build_coverage(
        plan=plan,
        analyzers_used=analyzers_used,
        analyzers_skipped=skipped_names,
        optional_unavailable=optional_unavailable,
        request_metadata=combined_metadata,
    )

    # Suppression count from VultureAnalyzer (set in Phase 2).
    suppressed_count_raw = combined_metadata.get("vulture_suppressed_framework_fps", 0)
    suppressed_count = (
        int(suppressed_count_raw) if isinstance(suppressed_count_raw, int) else 0
    )
    suppressed_examples_raw = combined_metadata.get(
        "vulture_suppressed_framework_details", []
    )
    suppressed_examples = (
        suppressed_examples_raw if isinstance(suppressed_examples_raw, list) else []
    )

    scoring_context = _build_scoring_context(framework_stack, suppressed_count)
    fw_report = _build_framework_report(
        framework_stack,
        all_diagnostics,
        scoring_context,
        suppressed_count,
        suppressed_examples,
    )

    return compute_health_report(
        diagnostics=all_diagnostics,
        project=project,
        config=config,
        duration_ms=duration_ms,
        analyzers_used=analyzers_used,
        analyzers_skipped=skipped_names,
        mi_scores=mi_scores if mi_scores else None,
        cache_stats=cache_stats,
        coverage=coverage,
        scoring_context=scoring_context,
        framework_report=fw_report,
    )


def _count_lines(path: Path) -> int:
    """Count lines in a file, handling encoding errors."""
    try:
        return len(path.read_text(errors="ignore").splitlines())
    except OSError:
        return 0


def _detect_python_version() -> str:
    return f"{sys.version_info.major}.{sys.version_info.minor}"


def _check_stubs_installed(framework_stack: FrameworkStack) -> dict[str, bool]:
    """Return a mapping of framework name -> whether its stubs package is installed."""
    import importlib.metadata as _meta

    result: dict[str, bool] = {}
    for fw in framework_stack.all_frameworks:
        if fw.stubs_package:
            try:
                _meta.version(fw.stubs_package)
                result[fw.name] = True
            except _meta.PackageNotFoundError:
                result[fw.name] = False
    return result


def _build_scoring_context(
    framework_stack: FrameworkStack,
    suppressed_count: int,
) -> ScoringContext:
    """Build a ScoringContext from the detected framework stack."""
    stubs = _check_stubs_installed(framework_stack)
    return ScoringContext(
        framework_stack=framework_stack if framework_stack.primary else None,
        stubs_installed=stubs,
        whitelist_suppressed=suppressed_count,
    )


def _build_framework_report(
    framework_stack: FrameworkStack,
    diagnostics: list[Diagnostic],
    context: ScoringContext,
    suppressed_count: int,
    suppressed_examples: list[dict[str, str | int | None]],
) -> FrameworkReport | None:
    """Build a FrameworkReport from analysis results.

    Returns None when no primary framework was detected.
    """
    if not framework_stack.primary:
        return None

    primary = framework_stack.primary
    version = primary.version or ""
    display_parts = [primary.name.capitalize()]
    if version:
        display_parts = [f"{primary.name.capitalize()} {version}"]

    # Add companion names to display (Celery, DRF, etc.)
    companion_names = [
        fw.name.upper() if fw.name == "drf" else fw.name.capitalize()
        for fw in framework_stack.companions
    ]
    if companion_names:
        display_parts.extend(companion_names)
    display_name = " + ".join(display_parts)

    # Partition FW-* diagnostics into security checklist items
    security_checklist: list[ChecklistItem] = []
    advisory_count = 0

    fw_diagnostics = [d for d in diagnostics if d.rule_id.startswith("FW-")]
    for d in fw_diagnostics:
        if d.severity == Severity.INFO:
            advisory_count += 1
            status = "info"
        elif d.severity == Severity.WARNING:
            status = "warning"
        else:
            status = "fail"
        security_checklist.append(
            ChecklistItem(
                status=status,
                description=d.message,
                rule_id=d.rule_id,
                fix=d.fix,
            )
        )

    # Build ecosystem items (stubs, companions)
    ecosystem: list[ChecklistItem] = []
    for fw_name, has_stubs in context.stubs_installed.items():
        stubs_pkg = next(
            (
                fw.stubs_package
                for fw in framework_stack.all_frameworks
                if fw.name == fw_name
            ),
            None,
        )
        if stubs_pkg:
            if has_stubs:
                ecosystem.append(
                    ChecklistItem(
                        status="pass",
                        description=f"{stubs_pkg} installed (type checking enhanced)",
                    )
                )
            else:
                ecosystem.append(
                    ChecklistItem(
                        status="warning",
                        description=(
                            f"{stubs_pkg} not installed " "(type checking limited)"
                        ),
                        fix=f"pip install {stubs_pkg}",
                    )
                )

    # Note companion frameworks in ecosystem
    ecosystem.extend(
        ChecklistItem(
            status="info",
            description=f"{fw.name} detected ({fw.category.value} checks active)",
        )
        for fw in framework_stack.companions
    )

    return FrameworkReport(
        display_name=display_name,
        primary_framework=primary.name,
        detected_frameworks=[fw.name for fw in framework_stack.all_frameworks],
        security_checklist=security_checklist,
        ecosystem=ecosystem,
        suppressed_count=suppressed_count,
        suppressed_examples=suppressed_examples[:5],
        advisory_count=advisory_count,
    )


def _empty_report(start: float) -> HealthReport:
    return HealthReport(
        score=100,
        label="Healthy",
        category_scores=[],
        diagnostics=[],
        project=ProjectInfo(
            python_version=_detect_python_version(),
            framework=None,
            total_files=0,
            total_lines=0,
            detected_frameworks=[],
            framework_details={},
        ),
        duration_ms=int((time.monotonic() - start) * 1000),
        coverage=CoverageInfo(profile=PROFILE_DEFAULT, confidence="limited"),
    )


def _categorize_coverage(
    plan: ScanPlan,
    used_set: set[str],
    optional_unavailable: list[str],
) -> tuple[set[Category], list[CategoryCoverage], list[str]]:
    """Classify each planned category as scored, partial, or unavailable.

    Returns (scored_categories, category_coverage, partial_reasons).
    """
    scored_categories: set[Category] = set()
    category_coverage: list[CategoryCoverage] = []
    partial_reasons: list[str] = []

    for category in sorted(plan.categories, key=lambda c: c.value):
        category_analyzers = [
            info.name
            for info in ANALYZER_CATALOG.values()
            if category in info.categories
            and plan.profile in info.profiles
            and (plan.include_optional or not info.optional)
        ]
        used_for_category = [name for name in category_analyzers if name in used_set]
        if used_for_category:
            status, reason = _category_status(category, optional_unavailable)
            category_coverage.append(
                CategoryCoverage(
                    category=category,
                    status=status,
                    analyzers=used_for_category,
                    reason=reason,
                )
            )
            scored_categories.add(category)
            if reason:
                partial_reasons.append(f"{category.value}: {reason}")
        else:
            category_coverage.append(
                CategoryCoverage(
                    category=category,
                    status="unavailable",
                    analyzers=[],
                    reason="no analyzer ran for this category",
                )
            )

    # Add entries for categories explicitly skipped by the user
    category_coverage.extend(
        CategoryCoverage(
            category=category,
            status="skipped_by_user",
            analyzers=[],
            reason="excluded via --skip",
        )
        for category in sorted(plan.skipped_categories, key=lambda c: c.value)
    )

    return scored_categories, category_coverage, partial_reasons


def _category_status(
    category: Category,
    optional_unavailable: list[str],
) -> tuple[str, str]:
    """Return (status, reason) for a category that has at least one active analyzer."""
    if category == Category.SECURITY and "detect-secrets" in optional_unavailable:
        return "partial", "optional secret scan not installed"
    if category == Category.DEPENDENCIES and "dependency-vulns" in optional_unavailable:
        return "partial", "optional dependency vulnerability scan not installed"
    return "scored", ""


def _build_provenance(request_metadata: dict[str, object]) -> list[str]:
    """Build provenance notes from request metadata."""
    provenance: list[str] = []
    dep_source = request_metadata.get("dependency_vulns_source")
    dep_count = request_metadata.get("dependency_vulns_package_count")
    dep_note = request_metadata.get("dependency_vulns_note")
    if isinstance(dep_source, str) and isinstance(dep_count, int):
        provenance.append(
            f"Dependency vulnerabilities: scanned from {dep_source} "
            f"({dep_count} packages)"
        )
    elif isinstance(dep_note, str):
        provenance.append(f"Dependency vulnerabilities: skipped ({dep_note})")

    suppressed_count = request_metadata.get("vulture_suppressed_framework_fps")
    if isinstance(suppressed_count, int) and suppressed_count > 0:
        provenance.append(
            f"Vulture: {suppressed_count} framework-specific false positives suppressed"
        )
    return provenance


def _determine_confidence(
    partial_reasons: list[str],
    scored_categories: set[Category],
    plan: ScanPlan,
) -> str:
    """Determine the confidence level based on coverage gaps."""
    if len(scored_categories) < len(plan.categories):
        return "limited"
    if partial_reasons:
        return "partial"
    return "full"


def _build_coverage(
    *,
    plan: ScanPlan,
    analyzers_used: list[str],
    analyzers_skipped: list[str],
    optional_unavailable: list[str],
    request_metadata: dict[str, object] | None = None,
) -> CoverageInfo:
    used_set = set(analyzers_used)
    request_metadata = request_metadata or {}

    scored_categories, category_coverage, partial_reasons = _categorize_coverage(
        plan, used_set, optional_unavailable
    )

    confidence = _determine_confidence(partial_reasons, scored_categories, plan)
    provenance = _build_provenance(request_metadata)

    return CoverageInfo(
        profile=plan.profile,
        confidence=confidence,
        requested_categories=sorted(plan.categories, key=lambda c: c.value),
        scored_categories=sorted(scored_categories, key=lambda c: c.value),
        category_coverage=category_coverage,
        analyzers_used=analyzers_used,
        analyzers_missing=[],
        analyzers_optional_unavailable=optional_unavailable,
        partial_reasons=partial_reasons,
        provenance=provenance,
    )
