from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from python_checkup.models import Category, Diagnostic, Severity

if TYPE_CHECKING:
    from python_checkup.detection import FrameworkStack

# Map of framework name -> patterns found in mypy error messages that indicate
# the error is caused by missing framework stubs (not real application bugs).
_FRAMEWORK_MYPY_PATTERNS: dict[str, list[str]] = {
    "django": [
        "django",
        "Cannot find implementation or library stub for module named",
        "Module has no attribute",
        "Skipping analyzing",
    ],
    "fastapi": [
        "fastapi",
        "starlette",
        "Cannot find implementation or library stub for module named",
    ],
    "flask": [
        "flask",
        "werkzeug",
        "Cannot find implementation or library stub for module named",
    ],
    "sqlalchemy": [
        "sqlalchemy",
        "Cannot find implementation or library stub for module named",
    ],
    "celery": [
        "celery",
        "Cannot find implementation or library stub for module named",
    ],
}


@dataclass(frozen=True)
class ScoringContext:
    """Framework context that influences how diagnostics are scored.

    Passed to the scoring engine so penalty multipliers can account for
    framework tooling gaps (missing stubs, suppressed false positives).
    """

    framework_stack: FrameworkStack | None
    # Maps framework name -> whether its stubs package is installed.
    stubs_installed: dict[str, bool] = field(default_factory=dict)
    # Number of Vulture dead-code items suppressed via framework whitelists.
    whitelist_suppressed: int = 0


def compute_penalty_multiplier(
    diagnostic: Diagnostic,
    context: ScoringContext,
) -> float:
    """Return a multiplier (0.0–1.0) for a diagnostic's scoring penalty.

    1.0 = full penalty (default)
    0.5 = half penalty (framework context reduces confidence)
    0.3 = reduced penalty (stubs would likely fix this)
    0.0 = no penalty (fully explained by framework context)
    """
    if context.framework_stack is None:
        return 1.0

    # Type errors from mypy without stubs → reduced penalty because stubs
    # would likely resolve the false positives.
    if diagnostic.category == Category.TYPE_SAFETY and diagnostic.tool == "mypy":
        for fw_name, has_stubs in context.stubs_installed.items():
            if not has_stubs and _is_framework_type_error(diagnostic, fw_name):
                return 0.3

    # Framework-specific INFO-level advisory diagnostics (FW-*) should not
    # penalize as heavily as real errors.
    if diagnostic.rule_id.startswith("FW-") and diagnostic.severity == Severity.INFO:
        return 0.5

    return 1.0


def _is_framework_type_error(diagnostic: Diagnostic, fw_name: str) -> bool:
    """Return True if the mypy diagnostic is caused by a missing stubs package."""
    patterns = _FRAMEWORK_MYPY_PATTERNS.get(fw_name, [fw_name])
    msg_lower = diagnostic.message.lower()
    return any(p.lower() in msg_lower for p in patterns)
