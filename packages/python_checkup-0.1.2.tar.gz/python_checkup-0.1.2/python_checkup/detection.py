from __future__ import annotations

import importlib.metadata
import logging
from collections.abc import Callable
from contextlib import suppress
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import TypedDict

logger = logging.getLogger("python_checkup")


class FrameworkCategory(Enum):
    """Broad categories for framework classification."""

    WEB = "web"
    ORM = "orm"
    TASK_QUEUE = "task_queue"
    VALIDATION = "validation"
    TESTING = "testing"
    CLI = "cli"
    API = "api"  # REST/GraphQL layers on top of a web framework


@dataclass
class FrameworkInfo:
    """Detected framework with version and confidence."""

    name: str  # "django", "fastapi", "flask", …
    version: str | None
    confidence: float  # 0.0 - 1.0
    category: FrameworkCategory = FrameworkCategory.WEB
    parent: str | None = None  # e.g. "django" for DRF
    stubs_package: str | None = None  # e.g. "django-stubs"


@dataclass
class FrameworkStack:
    """All frameworks detected in a project."""

    primary: FrameworkInfo | None  # Highest-confidence web framework
    companions: list[FrameworkInfo]  # Task queues, ORMs, validators, …
    all_frameworks: list[FrameworkInfo]  # Everything at or above threshold

    @property
    def names(self) -> set[str]:
        """All detected framework names for quick membership tests."""
        return {f.name for f in self.all_frameworks}

    def has(self, name: str) -> bool:
        return name in self.names


# Directories to skip during file sampling and detection scans.
_EXCLUDED_DIRS = frozenset(
    {
        ".venv",
        "venv",
        ".env",
        "__pycache__",
        ".git",
        "node_modules",
        ".tox",
        ".mypy_cache",
        ".ruff_cache",
        "site-packages",
        ".eggs",
        "dist",
        "build",
    }
)

# Confidence threshold — below this we don't activate framework rules.
_CONFIDENCE_THRESHOLD = 0.5

# Categories eligible to be the *primary* framework.  Testing tools and
# validation libraries are companions, not the project's identity.
_PRIMARY_ELIGIBLE_CATEGORIES: frozenset[FrameworkCategory] = frozenset(
    {
        FrameworkCategory.WEB,
        FrameworkCategory.API,
        FrameworkCategory.CLI,
        FrameworkCategory.TASK_QUEUE,
        FrameworkCategory.ORM,
    }
)

# Priority file names whose content is most likely to contain framework signals.
_PRIORITY_FILE_NAMES = frozenset(
    {
        "app.py",
        "main.py",
        "api.py",
        "wsgi.py",
        "asgi.py",
        "settings.py",
        "config.py",
        "celery.py",
        "celeryconfig.py",
        "manage.py",
        "views.py",
        "models.py",
        "serializers.py",
        "tasks.py",
        "routes.py",
        "urls.py",
        "conftest.py",
        "setup.py",
    }
)

# Known frameworks — used to batch-query importlib.metadata once.
_KNOWN_PACKAGES = frozenset(
    {
        "django",
        "fastapi",
        "flask",
        "celery",
        "sqlalchemy",
        "pydantic",
        "pytest",
        "djangorestframework",
        "starlette",
        "aiohttp",
        "uvicorn",
        "click",
        "typer",
        "dramatiq",
    }
)


@dataclass
class DetectionContext:
    """Shared context computed once and reused by all detectors.

    Building this once avoids re-reading files and re-scanning directories
    for every individual detector, keeping total detection time well under
    the 500 ms budget even for large projects.
    """

    root: Path
    sampled_files: list[Path]
    sampled_content: dict[Path, str]  # content cache for sampled files
    dependency_packages: set[str]  # normalised package names from req files
    installed_packages: dict[str, str]  # name -> version from importlib.metadata

    @classmethod
    def build(cls, root: Path) -> DetectionContext:
        sampled = _sample_py_files(root, limit=30)
        content_cache: dict[Path, str] = {}
        for f in sampled:
            try:
                content_cache[f] = f.read_text(errors="ignore")
            except OSError:  # noqa: PERF203
                content_cache[f] = ""

        deps = _parse_all_dependency_files(root)
        installed = _batch_installed_packages(_KNOWN_PACKAGES)
        return cls(
            root=root,
            sampled_files=sampled,
            sampled_content=content_cache,
            dependency_packages=deps,
            installed_packages=installed,
        )

    def file_contents(self) -> list[str]:
        return list(self.sampled_content.values())

    def any_content_contains(self, *patterns: str) -> bool:
        return any(
            any(pat in text for pat in patterns)
            for text in self.sampled_content.values()
        )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def detect_frameworks(
    project_root: Path,
    config: object | None = None,
) -> FrameworkStack:
    """Detect ALL frameworks present using registered plugins.

    Builds a shared ``DetectionContext`` once, then runs each plugin's
    ``detect()`` method against it.  Returns a ``FrameworkStack`` with a
    primary web framework (if any) and companion frameworks (ORMs, task
    queues, validators, etc.).

    Args:
        project_root: Project directory to scan.
        config: Optional ``CheckupConfig`` — used to honour
            ``frameworks_disabled`` and ``frameworks`` overrides.
    """
    # Import here to avoid circular imports at module load time.
    from python_checkup.frameworks.registry import discover_framework_plugins

    # Config overrides
    if config is not None:
        if getattr(config, "frameworks_disabled", False):
            return FrameworkStack(primary=None, companions=[], all_frameworks=[])

        forced: list[str] | None = getattr(config, "frameworks", None)
        if forced is not None:
            return _build_stack_from_names(forced, project_root)

    context = DetectionContext.build(project_root)
    candidates: list[FrameworkInfo] = []

    for plugin in discover_framework_plugins():
        score, version = plugin.detect(context)
        if score >= _CONFIDENCE_THRESHOLD:
            stubs_info = plugin.get_stubs_info()
            parent = getattr(plugin, "get_parent", lambda: None)()
            candidates.append(
                FrameworkInfo(
                    name=plugin.name,
                    version=version,
                    confidence=min(score, 1.0),
                    category=plugin.category,
                    parent=parent,
                    stubs_package=stubs_info.stubs_package if stubs_info else None,
                )
            )
            logger.info(
                "Detected framework: %s%s (confidence: %.2f)",
                plugin.name,
                f"-{version}" if version else "",
                score,
            )

    if not candidates:
        return FrameworkStack(primary=None, companions=[], all_frameworks=[])

    candidates.sort(key=lambda f: f.confidence, reverse=True)

    # Primary = highest-confidence WEB framework, else highest-confidence
    # primary-eligible framework.  TESTING and VALIDATION are always companions.
    primary: FrameworkInfo | None = next(
        (f for f in candidates if f.category == FrameworkCategory.WEB),
        next(
            (f for f in candidates if f.category in _PRIMARY_ELIGIBLE_CATEGORIES),
            None,
        ),
    )
    companions = [f for f in candidates if f is not primary]

    return FrameworkStack(
        primary=primary,
        companions=companions,
        all_frameworks=candidates,
    )


def _build_stack_from_names(
    names: list[str],
    project_root: Path,
) -> FrameworkStack:
    """Build a FrameworkStack from an explicit list of framework names.

    Used when ``frameworks = ["django", "celery"]`` is set in config,
    bypassing auto-detection.  Versions come from installed packages.
    """
    from python_checkup.frameworks.registry import discover_framework_plugins

    plugins_by_name = {p.name: p for p in discover_framework_plugins()}
    context = DetectionContext.build(project_root)
    candidates: list[FrameworkInfo] = []

    for name in names:
        plugin = plugins_by_name.get(name)
        if plugin is None:
            logger.warning("Unknown framework in config.frameworks: %s — skipped", name)
            continue
        # Detect just to get the version; confidence forced to 1.0
        _, version = plugin.detect(context)
        stubs_info = plugin.get_stubs_info()
        candidates.append(
            FrameworkInfo(
                name=name,
                version=version,
                confidence=1.0,
                category=plugin.category,
                stubs_package=stubs_info.stubs_package if stubs_info else None,
            )
        )

    if not candidates:
        return FrameworkStack(primary=None, companions=[], all_frameworks=[])

    primary = next(
        (f for f in candidates if f.category == FrameworkCategory.WEB),
        next(
            (f for f in candidates if f.category in _PRIMARY_ELIGIBLE_CATEGORIES),
            None,
        ),
    )
    companions = [f for f in candidates if f is not primary]
    return FrameworkStack(
        primary=primary, companions=companions, all_frameworks=candidates
    )


def detect_framework(project_root: Path) -> FrameworkInfo | None:
    """Legacy single-framework detection.

    Delegates to ``detect_frameworks()`` and returns the primary framework
    if it exists and passes the confidence threshold. All existing callers
    continue to work unchanged.
    """
    stack = detect_frameworks(project_root)
    return stack.primary


# ---------------------------------------------------------------------------
# Detector implementations
# ---------------------------------------------------------------------------


def _detect_django(ctx: DetectionContext) -> tuple[float, str | None]:
    score = 0.0
    version = ctx.installed_packages.get("django")
    if version:
        score += 0.4  # Installed alone < threshold; requires one project signal

    if (ctx.root / "manage.py").exists():
        score += 0.3

    settings_files = [
        f for f in ctx.root.rglob("settings.py") if not _is_excluded(f, ctx.root)
    ]
    if settings_files:
        score += 0.1

    if ctx.any_content_contains("DJANGO_SETTINGS_MODULE"):
        score += 0.2

    if "django" in ctx.dependency_packages:
        score += 0.3

    if ctx.any_content_contains("from django", "import django"):
        score += 0.1

    return score, version


def _detect_fastapi(ctx: DetectionContext) -> tuple[float, str | None]:
    score = 0.0
    version = ctx.installed_packages.get("fastapi")
    if version:
        score += 0.4

    if ctx.installed_packages.get("uvicorn"):
        score += 0.2

    # Check root and up to 3 levels deep for entry-point files
    for name in ("main.py", "app.py", "api.py"):
        found = _find_file_recursive(ctx.root, name, max_depth=3)
        if found:
            try:
                content = found.read_text(errors="ignore")
                if "FastAPI()" in content or "from fastapi" in content:
                    score += 0.3
                    break
            except OSError:
                pass

    if "fastapi" in ctx.dependency_packages:
        score += 0.3

    if ctx.any_content_contains("from fastapi", "import fastapi"):
        score += 0.1

    return score, version


def _detect_flask(ctx: DetectionContext) -> tuple[float, str | None]:
    score = 0.0
    version = ctx.installed_packages.get("flask")
    if version:
        score += 0.4

    for env_file in (".flaskenv", ".env"):
        path = ctx.root / env_file
        if path.exists():
            try:
                if "FLASK_APP" in path.read_text(errors="ignore"):
                    score += 0.3
                    break
            except OSError:
                pass

    for name in ("app.py", "application.py", "wsgi.py"):
        found = _find_file_recursive(ctx.root, name, max_depth=3)
        if found:
            try:
                content = found.read_text(errors="ignore")
                if "Flask(__name__)" in content or "from flask" in content:
                    score += 0.3
                    break
            except OSError:
                pass

    if "flask" in ctx.dependency_packages:
        score += 0.3

    if ctx.any_content_contains("from flask", "import flask"):
        score += 0.1

    return score, version


def _detect_celery(ctx: DetectionContext) -> tuple[float, str | None]:
    score = 0.0
    version = ctx.installed_packages.get("celery")
    if version:
        score += 0.4

    for name in ("celery.py", "celeryconfig.py"):
        if _find_file_recursive(ctx.root, name, max_depth=3):
            score += 0.3
            break

    if "celery" in ctx.dependency_packages:
        score += 0.3

    if ctx.any_content_contains(
        "from celery", "import celery", "@shared_task", "@app.task"
    ):
        score += 0.2

    return score, version


def _detect_sqlalchemy(ctx: DetectionContext) -> tuple[float, str | None]:
    score = 0.0
    version = ctx.installed_packages.get("sqlalchemy")
    if version:
        score += 0.4

    # alembic/ directory is a very strong SQLAlchemy signal
    if (ctx.root / "alembic").is_dir():
        score += 0.3

    if "sqlalchemy" in ctx.dependency_packages:
        score += 0.3

    if ctx.any_content_contains(
        "from sqlalchemy", "import sqlalchemy", "declarative_base", "DeclarativeBase"
    ):
        score += 0.2

    return score, version


def _detect_pydantic(ctx: DetectionContext) -> tuple[float, str | None]:
    score = 0.0
    version = ctx.installed_packages.get("pydantic")
    if version:
        score += 0.4

    if "pydantic" in ctx.dependency_packages:
        score += 0.3

    if ctx.any_content_contains(
        "from pydantic", "import pydantic", "BaseModel", "model_validator"
    ):
        score += 0.2

    return score, version


def _detect_pytest(ctx: DetectionContext) -> tuple[float, str | None]:
    score = 0.0
    version = ctx.installed_packages.get("pytest")
    if version:
        score += 0.4

    # conftest.py is a pytest-specific convention
    if _find_file_recursive(ctx.root, "conftest.py", max_depth=3):
        score += 0.3

    # pytest.ini or [tool.pytest.ini_options] in pyproject.toml
    if (ctx.root / "pytest.ini").exists():
        score += 0.2
    else:
        pyproject = ctx.root / "pyproject.toml"
        if pyproject.exists():
            try:
                content = pyproject.read_text(errors="ignore")
                if "tool.pytest" in content:
                    score += 0.2
            except OSError:
                pass

    if "pytest" in ctx.dependency_packages:
        score += 0.2

    if ctx.any_content_contains("import pytest", "from pytest"):
        score += 0.1

    return score, version


def _detect_drf(ctx: DetectionContext) -> tuple[float, str | None]:
    """Detect Django REST Framework (companion to Django)."""
    score = 0.0
    version = ctx.installed_packages.get("djangorestframework")
    if version:
        score += 0.4

    if (
        "djangorestframework" in ctx.dependency_packages
        or "rest_framework" in ctx.dependency_packages
    ):
        score += 0.3

    if ctx.any_content_contains("from rest_framework", "import rest_framework"):
        score += 0.2

    # serializers.py is a strong DRF signal
    if _find_file_recursive(ctx.root, "serializers.py", max_depth=4):
        score += 0.1

    return score, version


def _detect_starlette(ctx: DetectionContext) -> tuple[float, str | None]:
    score = 0.0
    version = ctx.installed_packages.get("starlette")
    if version:
        score += 0.4

    if "starlette" in ctx.dependency_packages:
        score += 0.3

    if ctx.any_content_contains("from starlette", "Starlette()"):
        score += 0.2

    return score, version


def _detect_click(ctx: DetectionContext) -> tuple[float, str | None]:
    score = 0.0
    version = ctx.installed_packages.get("click")
    if version:
        score += 0.4

    if "click" in ctx.dependency_packages:
        score += 0.3

    if ctx.any_content_contains("@click.command", "@click.group", "from click"):
        score += 0.2

    return score, version


def _detect_typer(ctx: DetectionContext) -> tuple[float, str | None]:
    score = 0.0
    version = ctx.installed_packages.get("typer")
    if version:
        score += 0.4

    if "typer" in ctx.dependency_packages:
        score += 0.3

    if ctx.any_content_contains("typer.Typer()", "from typer", "import typer"):
        score += 0.2

    return score, version


def _detect_aiohttp(ctx: DetectionContext) -> tuple[float, str | None]:
    score = 0.0
    version = ctx.installed_packages.get("aiohttp")
    if version:
        score += 0.4

    if "aiohttp" in ctx.dependency_packages:
        score += 0.3

    if ctx.any_content_contains("from aiohttp", "aiohttp.web.Application"):
        score += 0.2

    return score, version


def _detect_dramatiq(ctx: DetectionContext) -> tuple[float, str | None]:
    score = 0.0
    version = ctx.installed_packages.get("dramatiq")
    if version:
        score += 0.4

    if "dramatiq" in ctx.dependency_packages:
        score += 0.3

    if ctx.any_content_contains("from dramatiq", "@dramatiq.actor"):
        score += 0.2

    return score, version


# ---------------------------------------------------------------------------
# Detector registry
#
# Maps framework name -> (detector_fn, metadata)
# metadata carries category, optional parent, optional stubs_package.
# ---------------------------------------------------------------------------

_DetectorFn = Callable[[DetectionContext], tuple[float, str | None]]


class _FrameworkMeta(TypedDict, total=False):
    category: FrameworkCategory
    parent: str
    stubs_package: str


_FRAMEWORK_DETECTORS: dict[str, tuple[_DetectorFn, _FrameworkMeta]] = {
    "django": (
        _detect_django,
        {"category": FrameworkCategory.WEB, "stubs_package": "django-stubs"},
    ),
    "fastapi": (
        _detect_fastapi,
        {"category": FrameworkCategory.WEB},
    ),
    "flask": (
        _detect_flask,
        {"category": FrameworkCategory.WEB},
    ),
    "starlette": (
        _detect_starlette,
        {"category": FrameworkCategory.WEB},
    ),
    "aiohttp": (
        _detect_aiohttp,
        {"category": FrameworkCategory.WEB},
    ),
    "celery": (
        _detect_celery,
        {"category": FrameworkCategory.TASK_QUEUE},
    ),
    "dramatiq": (
        _detect_dramatiq,
        {"category": FrameworkCategory.TASK_QUEUE},
    ),
    "sqlalchemy": (
        _detect_sqlalchemy,
        {"category": FrameworkCategory.ORM, "stubs_package": "sqlalchemy-stubs"},
    ),
    "pydantic": (
        _detect_pydantic,
        {"category": FrameworkCategory.VALIDATION},
    ),
    "drf": (
        _detect_drf,
        {"category": FrameworkCategory.API, "parent": "django"},
    ),
    "click": (
        _detect_click,
        {"category": FrameworkCategory.CLI},
    ),
    "typer": (
        _detect_typer,
        {"category": FrameworkCategory.CLI},
    ),
    "pytest": (
        _detect_pytest,
        {"category": FrameworkCategory.TESTING},
    ),
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _is_excluded(path: Path, root: Path) -> bool:
    try:
        parts = path.relative_to(root).parts
    except ValueError:
        return True
    return any(part in _EXCLUDED_DIRS for part in parts)


def _sample_py_files(root: Path, limit: int = 30) -> list[Path]:
    """Sample Python files, prioritising likely framework entry-points."""
    priority: list[Path] = []
    other: list[Path] = []

    for py_file in root.rglob("*.py"):
        if _is_excluded(py_file, root):
            continue
        if py_file.name in _PRIORITY_FILE_NAMES:
            priority.append(py_file)
        else:
            other.append(py_file)
        if len(priority) + len(other) >= limit * 4:
            break

    return (priority + other)[:limit]


def _find_file_recursive(
    root: Path,
    filename: str,
    max_depth: int = 3,
) -> Path | None:
    """Find a file by name within max_depth directory levels."""
    # Check root first
    candidate = root / filename
    if candidate.exists() and not _is_excluded(candidate, root):
        return candidate

    # Progressively deeper search
    for depth in range(1, max_depth + 1):
        pattern = "/".join(["*"] * depth) + f"/{filename}"
        for match in root.glob(pattern):
            if not _is_excluded(match, root):
                return match

    return None


def _parse_all_dependency_files(root: Path) -> set[str]:
    """Parse all known dependency files and return normalised package names."""
    packages: set[str] = set()

    req_candidates = [
        "requirements.txt",
        "requirements/base.txt",
        "requirements/main.txt",
        "requirements/prod.txt",
        "requirements/common.txt",
        "requirements/requirements.txt",
    ]
    for name in req_candidates:
        path = root / name
        if path.exists():
            try:
                for line in path.read_text(errors="ignore").splitlines():
                    line = line.strip().split("#")[0].split(";")[0]
                    if line and not line.startswith(("-", "http")):
                        pkg = _normalise_package_name(
                            line.split(">=")[0]
                            .split("==")[0]
                            .split("~=")[0]
                            .split("[")[0]
                        )
                        if pkg:
                            packages.add(pkg)
            except OSError:
                pass

    pyproject = root / "pyproject.toml"
    if pyproject.exists():
        try:
            content = pyproject.read_text(errors="ignore").lower()
            # Rough extraction — look for quoted package names after "dependencies"
            import re

            for match in re.findall(r'"([a-zA-Z0-9_\-]+)[>=~\["\s]', content):
                packages.add(_normalise_package_name(match))
        except OSError:
            pass

    pipfile = root / "Pipfile"
    if pipfile.exists():
        try:
            for line in pipfile.read_text(errors="ignore").splitlines():
                line = line.strip()
                if line and not line.startswith("[") and "=" in line:
                    pkg = _normalise_package_name(line.split("=")[0].strip().strip('"'))
                    if pkg:
                        packages.add(pkg)
        except OSError:
            pass

    return packages


def _normalise_package_name(name: str) -> str:
    """Normalise package name: lowercase + replace - with _."""
    return name.lower().replace("-", "_").strip()


def _batch_installed_packages(names: frozenset[str]) -> dict[str, str]:
    """Query importlib.metadata for multiple packages in one pass."""
    result: dict[str, str] = {}
    for name in names:
        with suppress(importlib.metadata.PackageNotFoundError):
            result[name] = importlib.metadata.version(name)
        # Also try underscore variant
        alt = name.replace("-", "_")
        if alt != name:
            with suppress(importlib.metadata.PackageNotFoundError):
                result[alt] = importlib.metadata.version(alt)
    return result


# ---------------------------------------------------------------------------
# Legacy helpers (kept for tests that import them directly)
# ---------------------------------------------------------------------------


def _in_dependency_files(root: Path, package: str) -> bool:
    """Check if package appears in requirements.txt or pyproject.toml.

    Kept for backward-compatibility with existing tests.
    """
    pkg_lower = _normalise_package_name(package)
    deps = _parse_all_dependency_files(root)
    return pkg_lower in deps or pkg_lower.replace("_", "-") in deps


def _has_imports(root: Path, patterns: list[str]) -> bool:
    """Check sampled Python files for import patterns.

    Kept for backward-compatibility with existing tests.
    """
    for py_file in _sample_py_files(root, limit=20):
        try:
            content = py_file.read_text(errors="ignore")
            if any(p in content for p in patterns):
                return True
        except OSError:  # noqa: PERF203
            continue
    return False
