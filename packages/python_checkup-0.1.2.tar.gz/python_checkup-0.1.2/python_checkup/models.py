from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path


class Severity(Enum):
    """Diagnostic severity levels."""

    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


class Category(Enum):
    """Analysis categories that map to scored dimensions."""

    QUALITY = "quality"
    TYPE_SAFETY = "type_safety"
    SECURITY = "security"
    COMPLEXITY = "complexity"
    DEAD_CODE = "dead_code"
    DEPENDENCIES = "dependencies"
    PERFORMANCE = "performance"


@dataclass(frozen=True)
class Diagnostic:
    """A single finding from an analyzer.

    This is the universal exchange type. Every analyzer produces these,
    every consumer (scoring, formatting, MCP) reads them.
    """

    file_path: Path
    line: int
    column: int
    severity: Severity
    rule_id: str  # e.g., "S101", "E501", "C901", "mypy-return-value"
    tool: str  # e.g., "ruff", "mypy", "bandit", "radon", "vulture"
    category: Category
    message: str
    fix: str | None = None  # Suggested remediation text
    help_url: str | None = None  # URL to rule documentation
    end_line: int | None = None
    end_column: int | None = None


@dataclass
class CategoryScore:
    """Score for a single analysis category."""

    category: Category
    score: int  # 0-100 (truncated, not rounded — 100 means truly perfect)
    weight: int  # Configured weight (0-100)
    issue_count: int
    error_count: int = 0
    warning_count: int = 0
    details: str = ""  # Human-readable summary, e.g. "8 errors, 15 warnings"
    status: str = "scored"  # scored, partial
    coverage_note: str = ""


@dataclass
class CategoryCoverage:
    """Coverage metadata for a single category."""

    category: Category
    status: str  # scored, partial, unavailable, skipped_by_user
    analyzers: list[str] = field(default_factory=list)
    reason: str = ""


@dataclass
class CoverageInfo:
    """Explains how complete an analysis run was."""

    profile: str
    confidence: str  # full, partial, limited
    requested_categories: list[Category] = field(default_factory=list)
    scored_categories: list[Category] = field(default_factory=list)
    category_coverage: list[CategoryCoverage] = field(default_factory=list)
    analyzers_used: list[str] = field(default_factory=list)
    analyzers_missing: list[str] = field(default_factory=list)
    analyzers_optional_unavailable: list[str] = field(default_factory=list)
    partial_reasons: list[str] = field(default_factory=list)
    provenance: list[str] = field(default_factory=list)


@dataclass
class ProjectInfo:
    """Metadata about the analyzed project."""

    python_version: str | None
    framework: str | None  # "django-5.1", "fastapi-0.115", "flask-3.1", None
    total_files: int
    total_lines: int
    packages: list[str] = field(default_factory=list)
    # Full stack detection (Phase 1)
    detected_frameworks: list[str] = field(default_factory=list)  # all names
    framework_details: dict[str, str] = field(default_factory=dict)  # name->version


@dataclass
class ChecklistItem:
    """A single item in a framework security or ecosystem checklist."""

    status: str  # "pass", "fail", "warning", "info"
    description: str
    rule_id: str | None = None
    fix: str | None = None


@dataclass
class FrameworkReport:
    """Framework-specific analysis summary produced during a run."""

    display_name: str  # e.g. "Django 5.1" or "FastAPI + Celery"
    primary_framework: str  # "django", "fastapi", …
    detected_frameworks: list[str]  # All detected framework names
    security_checklist: list[ChecklistItem] = field(default_factory=list)
    ecosystem: list[ChecklistItem] = field(default_factory=list)
    suppressed_count: int = 0  # Vulture false positives suppressed
    suppressed_examples: list[dict[str, str | int | None]] = field(default_factory=list)
    advisory_count: int = 0  # FW-* INFO diagnostics


@dataclass
class HealthReport:
    """Complete analysis result -- the top-level return type."""

    score: int  # 0-100 weighted overall (truncated, not rounded)
    label: str  # "Healthy", "Needs work", "Critical"
    category_scores: list[CategoryScore]
    diagnostics: list[Diagnostic]
    project: ProjectInfo
    duration_ms: int
    analyzers_used: list[str] = field(default_factory=list)
    analyzers_skipped: list[str] = field(default_factory=list)
    cache_stats: dict[str, int] | None = None  # hits, misses, hit_rate_pct
    coverage: CoverageInfo | None = None
    framework_report: FrameworkReport | None = None  # Phase 5
