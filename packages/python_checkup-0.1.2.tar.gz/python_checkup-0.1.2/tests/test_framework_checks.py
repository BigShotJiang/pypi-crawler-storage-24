"""Tests for the framework-specific checks analyzer (Phase 4)."""

from __future__ import annotations

import asyncio
from collections.abc import Generator
from pathlib import Path

import pytest

from python_checkup.analysis_request import AnalysisRequest
from python_checkup.analyzers.framework_checks import FrameworkCheckAnalyzer
from python_checkup.config import CheckupConfig
from python_checkup.detection import FrameworkCategory, FrameworkInfo, FrameworkStack
from python_checkup.models import Category, Severity


def _make_request(
    tmp_path: Path,
    framework_names: list[str],
    files: list[Path] | None = None,
) -> AnalysisRequest:
    fws = [
        FrameworkInfo(
            name=n, version=None, confidence=0.9, category=FrameworkCategory.WEB
        )
        for n in framework_names
    ]
    stack = FrameworkStack(
        primary=fws[0] if fws else None,
        companions=fws[1:],
        all_frameworks=fws,
    )
    return AnalysisRequest(
        project_root=tmp_path,
        files=files or list(tmp_path.rglob("*.py")),
        config=CheckupConfig(),
        categories={Category.SECURITY, Category.QUALITY},
        profile="default",
        framework=framework_names[0] if framework_names else None,
        framework_stack=stack,
        no_cache=True,
    )


@pytest.fixture
def analyzer() -> FrameworkCheckAnalyzer:
    return FrameworkCheckAnalyzer()


@pytest.fixture
def event_loop() -> Generator[asyncio.AbstractEventLoop, None, None]:
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


# ---------------------------------------------------------------------------
# is_available
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_always_available(analyzer: FrameworkCheckAnalyzer) -> None:
    assert await analyzer.is_available() is True


@pytest.mark.asyncio
async def test_no_diagnostics_without_framework(
    analyzer: FrameworkCheckAnalyzer, tmp_path: Path
) -> None:
    (tmp_path / "app.py").write_text("x = 1\n")
    stack = FrameworkStack(primary=None, companions=[], all_frameworks=[])
    request = AnalysisRequest(
        project_root=tmp_path,
        files=[tmp_path / "app.py"],
        config=CheckupConfig(),
        categories={Category.SECURITY},
        profile="default",
        framework=None,
        framework_stack=stack,
    )
    diags = await analyzer.analyze(request)
    assert diags == []


# ---------------------------------------------------------------------------
# Django settings checks
# ---------------------------------------------------------------------------


class TestDjangoSettingsChecks:
    @pytest.mark.asyncio
    async def test_fw_dj_001_debug_true(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        settings = tmp_path / "settings.py"
        settings.write_text("DEBUG = True\nSECRET_KEY = 'test-key'\n")
        request = _make_request(tmp_path, ["django"])
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-001" in rule_ids

    @pytest.mark.asyncio
    async def test_fw_dj_001_not_triggered_when_false(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        settings = tmp_path / "settings.py"
        settings.write_text("DEBUG = False\nSECRET_KEY = 'test'\n")
        request = _make_request(tmp_path, ["django"])
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-001" not in rule_ids

    @pytest.mark.asyncio
    async def test_fw_dj_002_wildcard_hosts(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "settings.py").write_text(
            "DEBUG = False\nALLOWED_HOSTS = ['*']\nSECRET_KEY = 's'\n"
        )
        request = _make_request(tmp_path, ["django"])
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-002" in rule_ids

    @pytest.mark.asyncio
    async def test_fw_dj_003_hardcoded_secret_key(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "settings.py").write_text(
            "DEBUG = False\nSECRET_KEY = 'my-hardcoded-secret'\n"
        )
        request = _make_request(tmp_path, ["django"])
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-003" in rule_ids

    @pytest.mark.asyncio
    async def test_fw_dj_011_insecure_default_key(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "settings.py").write_text(
            "DEBUG = False\n" "SECRET_KEY = 'django-insecure-abc123'\n"
        )
        request = _make_request(tmp_path, ["django"])
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-011" in rule_ids
        assert "FW-DJ-003" not in rule_ids  # Should use 011, not 003

    @pytest.mark.asyncio
    async def test_fw_dj_008_missing_csrf_middleware(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "settings.py").write_text(
            "DEBUG = False\n"
            "SECRET_KEY = 'xyz'\n"
            "MIDDLEWARE = ['django.middleware.security.SecurityMiddleware']\n"
        )
        request = _make_request(tmp_path, ["django"])
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-008" in rule_ids

    @pytest.mark.asyncio
    async def test_fw_dj_008_not_triggered_when_present(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "settings.py").write_text(
            "DEBUG = False\n"
            "SECRET_KEY = 'xyz'\n"
            "MIDDLEWARE = [\n"
            "    'django.middleware.security.SecurityMiddleware',\n"
            "    'django.middleware.csrf.CsrfViewMiddleware',\n"
            "]\n"
        )
        request = _make_request(tmp_path, ["django"])
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-008" not in rule_ids

    @pytest.mark.asyncio
    async def test_fw_dj_050_missing_default_auto_field(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "settings.py").write_text("DEBUG = False\nSECRET_KEY = 'xyz'\n")
        request = _make_request(tmp_path, ["django"])
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-050" in rule_ids

    @pytest.mark.asyncio
    async def test_fw_dj_050_not_triggered_when_set(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "settings.py").write_text(
            "DEBUG = False\n"
            "SECRET_KEY = 'xyz'\n"
            "DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'\n"
        )
        request = _make_request(tmp_path, ["django"])
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-050" not in rule_ids

    @pytest.mark.asyncio
    async def test_severity_error_for_critical_issues(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "settings.py").write_text("DEBUG = True\nSECRET_KEY = 'x'\n")
        request = _make_request(tmp_path, ["django"])
        diags = await analyzer.analyze(request)
        debug_diags = [d for d in diags if d.rule_id == "FW-DJ-001"]
        assert debug_diags
        assert debug_diags[0].severity == Severity.ERROR

    @pytest.mark.asyncio
    async def test_fw_dj_004_to_007_trigger_on_explicit_insecure_values(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "settings.py").write_text(
            "SECRET_KEY = 'x'\n"
            "CSRF_COOKIE_SECURE = False\n"
            "SESSION_COOKIE_SECURE = False\n"
            "SECURE_SSL_REDIRECT = False\n"
            "SECURE_HSTS_SECONDS = 0\n"
        )
        request = _make_request(tmp_path, ["django"])
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert {"FW-DJ-004", "FW-DJ-005", "FW-DJ-006", "FW-DJ-007"} <= rule_ids

    @pytest.mark.asyncio
    async def test_fw_dj_051_foreign_key_without_on_delete(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "models.py").write_text(
            "from django.db import models\n"
            "class Book(models.Model):\n"
            "    author = models.ForeignKey('Author')\n"
        )
        request = _make_request(tmp_path, ["django"])
        diags = await analyzer.analyze(request)
        assert "FW-DJ-051" in {d.rule_id for d in diags}

    @pytest.mark.asyncio
    async def test_fw_dj_053_login_required_on_class_based_view(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "views.py").write_text(
            "from django.contrib.auth.decorators import login_required\n"
            "from django.views import View\n"
            "@login_required\n"
            "class DashboardView(View):\n"
            "    pass\n"
        )
        request = _make_request(tmp_path, ["django"])
        diags = await analyzer.analyze(request)
        assert "FW-DJ-053" in {d.rule_id for d in diags}

    @pytest.mark.asyncio
    async def test_fw_dj_054_objects_get_without_try(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "views.py").write_text(
            "from app.models import User\n"
            "def detail():\n"
            "    return User.objects.get(id=1)\n"
        )
        request = _make_request(tmp_path, ["django"])
        diags = await analyzer.analyze(request)
        assert "FW-DJ-054" in {d.rule_id for d in diags}

    @pytest.mark.asyncio
    async def test_fw_dj_055_queryset_related_access_without_prefetch(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "views.py").write_text(
            "def render_books():\n"
            "    for book in Book.objects.all():\n"
            "        print(book.author.name)\n"
        )
        request = _make_request(tmp_path, ["django"])
        diags = await analyzer.analyze(request)
        assert "FW-DJ-055" in {d.rule_id for d in diags}


# ---------------------------------------------------------------------------
# FastAPI checks
# ---------------------------------------------------------------------------


class TestFastAPIChecks:
    @pytest.mark.asyncio
    async def test_fw_fa_004_sync_endpoint(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "main.py").write_text(
            "from fastapi import FastAPI\n"
            "app = FastAPI()\n\n"
            "@app.get('/items')\n"
            "def list_items():\n"  # sync def, not async def
            "    return []\n"
        )
        request = _make_request(tmp_path, ["fastapi"])
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-FA-003" in rule_ids

    @pytest.mark.asyncio
    async def test_fw_fa_004_not_triggered_for_async(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "main.py").write_text(
            "from fastapi import FastAPI\n"
            "app = FastAPI()\n\n"
            "@app.get('/items')\n"
            "async def list_items():\n"  # async def — OK
            "    return []\n"
        )
        request = _make_request(tmp_path, ["fastapi"])
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-FA-004" not in rule_ids

    @pytest.mark.asyncio
    async def test_fw_fa_050_deprecated_on_event(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "main.py").write_text(
            "from fastapi import FastAPI\n"
            "app = FastAPI()\n\n"
            "@app.on_event('startup')\n"
            "async def startup():\n"
            "    pass\n"
        )
        request = _make_request(tmp_path, ["fastapi"])
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-FA-050" in rule_ids

    @pytest.mark.asyncio
    async def test_fw_fa_002_cors_wildcard(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "main.py").write_text(
            "from fastapi import FastAPI\n"
            "from fastapi.middleware.cors import CORSMiddleware\n"
            "app = FastAPI()\n"
            "app.add_middleware(CORSMiddleware, allow_origins=['*'])\n"
        )
        request = _make_request(tmp_path, ["fastapi"])
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-FA-002" in rule_ids

    @pytest.mark.asyncio
    async def test_fw_fa_001_missing_cors_middleware(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "main.py").write_text(
            "from fastapi import FastAPI\n" "app = FastAPI()\n"
        )
        request = _make_request(tmp_path, ["fastapi"])
        diags = await analyzer.analyze(request)
        assert "FW-FA-001" in {d.rule_id for d in diags}

    @pytest.mark.asyncio
    async def test_fw_fa_003_005_and_052_route_metadata_checks(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "main.py").write_text(
            "from fastapi import FastAPI\n"
            "app = FastAPI()\n\n"
            "@app.post('/items')\n"
            "async def create_item(a: int, b: int, c: int, d: int, e: int, f: int):\n"
            "    return {'ok': True}\n"
        )
        request = _make_request(tmp_path, ["fastapi"])
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-FA-003" in rule_ids
        assert "FW-FA-005" in rule_ids
        assert "FW-FA-052" in rule_ids

    @pytest.mark.asyncio
    async def test_fw_fa_051_dependency_http_exception_without_finally(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "deps.py").write_text(
            "from fastapi import Depends, HTTPException\n"
            "def dep(token=Depends()):\n"
            "    raise HTTPException(status_code=401)\n"
        )
        request = _make_request(tmp_path, ["fastapi"])
        diags = await analyzer.analyze(request)
        assert "FW-FA-051" in {d.rule_id for d in diags}


# ---------------------------------------------------------------------------
# Flask checks
# ---------------------------------------------------------------------------


class TestFlaskChecks:
    @pytest.mark.asyncio
    async def test_fw_fl_001_debug_true(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "app.py").write_text(
            "from flask import Flask\n"
            "app = Flask(__name__)\n"
            "app.run(debug=True)\n"
        )
        request = _make_request(tmp_path, ["flask"])
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-FL-001" in rule_ids

    @pytest.mark.asyncio
    async def test_fw_fl_001_not_triggered_when_false(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "app.py").write_text(
            "from flask import Flask\n"
            "app = Flask(__name__)\n"
            "app.run(debug=False)\n"
        )
        request = _make_request(tmp_path, ["flask"])
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-FL-001" not in rule_ids

    @pytest.mark.asyncio
    async def test_fw_fl_002_hardcoded_secret_key(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "app.py").write_text(
            "from flask import Flask\n"
            "app = Flask(__name__)\n"
            "SECRET_KEY = 'my-secret'\n"
        )
        request = _make_request(tmp_path, ["flask"])
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-FL-002" in rule_ids

    @pytest.mark.asyncio
    async def test_fw_fl_003_004_005_006_and_050_missing_practices(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "app.py").write_text(
            "from flask import Flask\n"
            "app = Flask(__name__)\n"
            "app.run(host='0.0.0.0')\n"
        )
        request = _make_request(tmp_path, ["flask"])
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-FL-003" in rule_ids
        assert "FW-FL-004" in rule_ids
        assert "FW-FL-005" in rule_ids
        assert "FW-FL-006" in rule_ids
        assert "FW-FL-050" in rule_ids

    @pytest.mark.asyncio
    async def test_fw_fl_051_mutable_default_arg_and_052_many_routes(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        route_defs = "".join(
            f"@app.route('/r{i}')\ndef route_{i}(items=[]):\n    return ''\n\n"
            for i in range(11)
        )
        (tmp_path / "app.py").write_text(
            "from flask import Flask\n" "app = Flask(__name__)\n\n" + route_defs
        )
        request = _make_request(tmp_path, ["flask"])
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-FL-051" in rule_ids
        assert "FW-FL-052" in rule_ids


# ---------------------------------------------------------------------------
# Celery checks
# ---------------------------------------------------------------------------


class TestCeleryChecks:
    @pytest.mark.asyncio
    async def test_fw_cl_001_always_eager(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "celery.py").write_text(
            "from celery import Celery\n"
            "app = Celery()\n"
            "task_always_eager = True\n"
        )
        request = _make_request(tmp_path, ["celery"])
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-CL-001" in rule_ids

    @pytest.mark.asyncio
    async def test_fw_cl_002_003_004_missing_task_options(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "tasks.py").write_text(
            "from celery import shared_task\n"
            "@shared_task()\n"
            "def process(a, b, c, d, e, f):\n"
            "    return a\n"
        )
        request = _make_request(tmp_path, ["celery"])
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-CL-002" in rule_ids
        assert "FW-CL-003" in rule_ids
        assert "FW-CL-004" in rule_ids

    @pytest.mark.asyncio
    async def test_fw_cl_005_pickle_serializer(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "celery.py").write_text("task_serializer = 'pickle'\n")
        request = _make_request(tmp_path, ["celery"])
        diags = await analyzer.analyze(request)
        assert "FW-CL-005" in {d.rule_id for d in diags}


# ---------------------------------------------------------------------------
# SQLAlchemy checks
# ---------------------------------------------------------------------------


class TestSQLAlchemyChecks:
    @pytest.mark.asyncio
    async def test_fw_sa_002_echo_true(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "db.py").write_text(
            "from sqlalchemy import create_engine\n"
            "engine = create_engine('sqlite://', echo=True)\n"
        )
        request = _make_request(tmp_path, ["sqlalchemy"])
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-SA-002" in rule_ids

    @pytest.mark.asyncio
    async def test_fw_sa_002_not_triggered_without_echo(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "db.py").write_text(
            "from sqlalchemy import create_engine\n"
            "engine = create_engine('sqlite://')\n"
        )
        request = _make_request(tmp_path, ["sqlalchemy"])
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-SA-002" not in rule_ids

    @pytest.mark.asyncio
    async def test_fw_sa_003_missing_repr_and_004_session_without_with(
        self, analyzer: FrameworkCheckAnalyzer, tmp_path: Path
    ) -> None:
        (tmp_path / "models.py").write_text(
            "from sqlalchemy import Column, Integer\n"
            "from sqlalchemy.orm import Session\n"
            "class User(Base):\n"
            "    id = Column(Integer, primary_key=True)\n\n"
            "def get_users(engine):\n"
            "    session = Session(engine)\n"
            "    return session\n"
        )
        request = _make_request(tmp_path, ["sqlalchemy"])
        diags = await analyzer.analyze(request)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-SA-003" in rule_ids
        assert "FW-SA-004" in rule_ids


# ---------------------------------------------------------------------------
# Analyzer metadata
# ---------------------------------------------------------------------------


def test_analyzer_name(analyzer: FrameworkCheckAnalyzer) -> None:
    assert analyzer.name == "framework-checks"


def test_analyzer_category(analyzer: FrameworkCheckAnalyzer) -> None:
    assert analyzer.category == Category.SECURITY
