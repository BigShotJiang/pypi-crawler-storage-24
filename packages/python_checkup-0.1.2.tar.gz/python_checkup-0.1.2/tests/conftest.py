from __future__ import annotations

from pathlib import Path

import pytest

FIXTURES_DIR = Path(__file__).parent / "fixtures"


@pytest.fixture
def clean_project() -> Path:
    return FIXTURES_DIR / "clean_project"


@pytest.fixture
def messy_project() -> Path:
    return FIXTURES_DIR / "messy_project"


@pytest.fixture
def security_project() -> Path:
    return FIXTURES_DIR / "security_issues"


@pytest.fixture
def type_errors_project() -> Path:
    return FIXTURES_DIR / "type_errors"


@pytest.fixture
def complex_project() -> Path:
    return FIXTURES_DIR / "complex_project"


@pytest.fixture
def dead_code_project() -> Path:
    return FIXTURES_DIR / "dead_code_project"


@pytest.fixture
def tmp_project(tmp_path: Path) -> Path:
    """Create a minimal Python project in a temp directory."""
    src = tmp_path / "src"
    src.mkdir()
    (src / "__init__.py").write_text("")
    (src / "app.py").write_text(
        'def greet(name: str) -> str:\n    return f"Hello {name}"\n'
    )
    (tmp_path / "pyproject.toml").write_text(
        '[project]\nname = "test-project"\nversion = "0.1.0"\n'
    )
    return tmp_path
