"""Tests for individual framework plugins (protocol compliance)."""

from __future__ import annotations

from pathlib import Path

import pytest

from python_checkup.detection import (
    DetectionContext,
    FrameworkInfo,
)
from python_checkup.frameworks import (
    FrameworkCategory,
    FrameworkPlugin,
    StubsInfo,
    WhitelistEntry,
)
from python_checkup.frameworks.registry import discover_framework_plugins

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_context(root: Path) -> DetectionContext:
    return DetectionContext(
        root=root,
        sampled_files=[],
        sampled_content={},
        dependency_packages=set(),
        installed_packages={},
    )


def _make_fw_info(
    name: str, category: FrameworkCategory = FrameworkCategory.WEB
) -> FrameworkInfo:
    return FrameworkInfo(name=name, version="1.0", confidence=1.0, category=category)


# ---------------------------------------------------------------------------
# Protocol compliance — every plugin must implement all methods
# ---------------------------------------------------------------------------

ALL_PLUGINS = discover_framework_plugins()
ALL_PLUGIN_NAMES = [p.name for p in ALL_PLUGINS]


@pytest.mark.parametrize("plugin", ALL_PLUGINS, ids=lambda p: p.name)
class TestPluginProtocol:
    def test_is_framework_plugin_instance(
        self, plugin: FrameworkPlugin, tmp_path: Path
    ) -> None:
        assert isinstance(plugin, FrameworkPlugin)

    def test_name_is_string(self, plugin: FrameworkPlugin, tmp_path: Path) -> None:
        assert isinstance(plugin.name, str)
        assert len(plugin.name) > 0

    def test_category_is_framework_category(
        self, plugin: FrameworkPlugin, tmp_path: Path
    ) -> None:
        assert isinstance(plugin.category, FrameworkCategory)

    def test_detect_returns_tuple(
        self, plugin: FrameworkPlugin, tmp_path: Path
    ) -> None:
        ctx = _make_context(tmp_path)
        result = plugin.detect(ctx)
        assert isinstance(result, tuple)
        assert len(result) == 2
        confidence, version = result
        assert isinstance(confidence, float)
        assert version is None or isinstance(version, str)

    def test_detect_confidence_in_range(
        self, plugin: FrameworkPlugin, tmp_path: Path
    ) -> None:
        ctx = _make_context(tmp_path)
        confidence, _ = plugin.detect(ctx)
        assert (
            0.0 <= confidence <= 1.0 or confidence == 0.0
        )  # empty project = 0 confidence

    def test_get_vulture_whitelist_returns_list(
        self, plugin: FrameworkPlugin, tmp_path: Path
    ) -> None:
        result = plugin.get_vulture_whitelist()
        assert isinstance(result, list)
        for entry in result:
            assert isinstance(entry, WhitelistEntry)

    def test_get_ruff_rules_returns_list(
        self, plugin: FrameworkPlugin, tmp_path: Path
    ) -> None:
        result = plugin.get_ruff_rules()
        assert isinstance(result, list)
        for rule in result:
            assert isinstance(rule, str)

    def test_get_implicit_dependencies_returns_set(
        self, plugin: FrameworkPlugin, tmp_path: Path
    ) -> None:
        result = plugin.get_implicit_dependencies()
        assert isinstance(result, set)
        for dep in result:
            assert isinstance(dep, str)

    def test_check_returns_list(self, plugin: FrameworkPlugin, tmp_path: Path) -> None:
        fw = _make_fw_info(plugin.name, plugin.category)
        result = plugin.check(tmp_path, [], fw)
        assert isinstance(result, list)

    def test_get_stubs_info_returns_stubs_info_or_none(
        self, plugin: FrameworkPlugin, tmp_path: Path
    ) -> None:
        result = plugin.get_stubs_info()
        assert result is None or isinstance(result, StubsInfo)

    def test_detect_empty_project_low_confidence(
        self, plugin: FrameworkPlugin, tmp_path: Path
    ) -> None:
        """An empty directory should give confidence below threshold."""
        ctx = _make_context(tmp_path)
        confidence, _ = plugin.detect(ctx)
        # All our detectors use installed packages as a signal — in an empty
        # context (no installed packages, no dep files) confidence is 0.
        assert confidence < 0.5


# ---------------------------------------------------------------------------
# Framework-specific checks
# ---------------------------------------------------------------------------


class TestDjangoPlugin:
    def test_name_is_django(self) -> None:
        from python_checkup.frameworks.django import DjangoPlugin

        assert DjangoPlugin().name == "django"

    def test_category_is_web(self) -> None:
        from python_checkup.frameworks.django import DjangoPlugin

        assert DjangoPlugin().category == FrameworkCategory.WEB

    def test_stubs_info_has_django_stubs(self) -> None:
        from python_checkup.frameworks.django import DjangoPlugin

        info = DjangoPlugin().get_stubs_info()
        assert info is not None
        assert info.stubs_package == "django-stubs"

    def test_ruff_rules_includes_dj(self) -> None:
        from python_checkup.frameworks.django import DjangoPlugin

        rules = DjangoPlugin().get_ruff_rules()
        assert "DJ" in rules

    def test_whitelist_nonempty(self) -> None:
        from python_checkup.frameworks.django import DjangoPlugin

        wl = DjangoPlugin().get_vulture_whitelist()
        assert len(wl) > 0

    def test_implicit_deps_includes_gunicorn(self) -> None:
        from python_checkup.frameworks.django import DjangoPlugin

        deps = DjangoPlugin().get_implicit_dependencies()
        assert "gunicorn" in deps

    def test_check_django_debug_true(self, tmp_path: Path) -> None:
        from python_checkup.frameworks.django import DjangoPlugin

        settings = tmp_path / "settings.py"
        settings.write_text("DEBUG = True\nALLOWED_HOSTS = ['*']\n")
        fw = _make_fw_info("django")
        diags = DjangoPlugin().check(tmp_path, [settings], fw)
        rule_ids = {d.rule_id for d in diags}
        assert "FW-DJ-001" in rule_ids


class TestFastAPIPlugin:
    def test_name(self) -> None:
        from python_checkup.frameworks.fastapi import FastAPIPlugin

        assert FastAPIPlugin().name == "fastapi"

    def test_ruff_rules_include_fast(self) -> None:
        from python_checkup.frameworks.fastapi import FastAPIPlugin

        assert "FAST" in FastAPIPlugin().get_ruff_rules()

    def test_no_stubs(self) -> None:
        from python_checkup.frameworks.fastapi import FastAPIPlugin

        assert FastAPIPlugin().get_stubs_info() is None


class TestSQLAlchemyPlugin:
    def test_stubs_package(self) -> None:
        from python_checkup.frameworks.sqlalchemy import SQLAlchemyPlugin

        info = SQLAlchemyPlugin().get_stubs_info()
        assert info is not None
        assert info.stubs_package == "sqlalchemy-stubs"

    def test_category_is_orm(self) -> None:
        from python_checkup.frameworks.sqlalchemy import SQLAlchemyPlugin

        assert SQLAlchemyPlugin().category == FrameworkCategory.ORM


class TestPytestPlugin:
    def test_ruff_rules_include_pt(self) -> None:
        from python_checkup.frameworks.pytest_fw import PytestPlugin

        assert "PT" in PytestPlugin().get_ruff_rules()

    def test_category_is_testing(self) -> None:
        from python_checkup.frameworks.pytest_fw import PytestPlugin

        assert PytestPlugin().category == FrameworkCategory.TESTING

    def test_implicit_deps_include_pytest_cov(self) -> None:
        from python_checkup.frameworks.pytest_fw import PytestPlugin

        assert "pytest-cov" in PytestPlugin().get_implicit_dependencies()


class TestDRFPlugin:
    def test_category_is_api(self) -> None:
        from python_checkup.frameworks.drf import DRFPlugin

        assert DRFPlugin().category == FrameworkCategory.API

    def test_whitelist_nonempty(self) -> None:
        from python_checkup.frameworks.drf import DRFPlugin

        # DRF shares Django's whitelist
        assert len(DRFPlugin().get_vulture_whitelist()) > 0


class TestCeleryPlugin:
    def test_category_is_task_queue(self) -> None:
        from python_checkup.frameworks.celery import CeleryPlugin

        assert CeleryPlugin().category == FrameworkCategory.TASK_QUEUE

    def test_implicit_deps_include_redis(self) -> None:
        from python_checkup.frameworks.celery import CeleryPlugin

        assert "redis" in CeleryPlugin().get_implicit_dependencies()
