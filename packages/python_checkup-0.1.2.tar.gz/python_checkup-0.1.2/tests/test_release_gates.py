from __future__ import annotations

import json
import time
from pathlib import Path

from click.testing import CliRunner

from python_checkup.cli import main

FIXTURES_DIR = Path(__file__).parent / "fixtures"
CLEAN_PROJECT = FIXTURES_DIR / "clean_project"
MESSY_PROJECT = FIXTURES_DIR / "messy_project"


# End-to-end CLI smoke tests


class TestCLISmokeTests:
    """Subprocess-level smoke tests exercising the full CLI pipeline."""

    def setup_method(self) -> None:
        self.runner = CliRunner()

    def test_version_flag(self) -> None:
        result = self.runner.invoke(main, ["--version"])
        assert result.exit_code == 0
        assert "python-checkup" in result.output.lower()

    def test_help_flag(self) -> None:
        result = self.runner.invoke(main, ["--help"])
        assert result.exit_code == 0
        assert "--score" in result.output
        assert "--json" in result.output
        assert "--fail-under" in result.output

    def test_score_only_clean_project(self) -> None:
        """--score should output a single numeric line."""
        result = self.runner.invoke(main, [str(CLEAN_PROJECT), "--score"])
        assert result.exit_code == 0
        score = int(result.output.strip())
        assert 0 <= score <= 100

    def test_score_only_messy_project(self) -> None:
        result = self.runner.invoke(main, [str(MESSY_PROJECT), "--score"])
        assert result.exit_code == 0
        score = int(result.output.strip())
        assert 0 <= score <= 100

    def test_json_output_clean_project(self) -> None:
        """--json should produce valid JSON."""
        result = self.runner.invoke(main, [str(CLEAN_PROJECT), "--json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert isinstance(data, dict)
        assert "score" in data

    def test_json_output_messy_project(self) -> None:
        result = self.runner.invoke(main, [str(MESSY_PROJECT), "--json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert isinstance(data, dict)
        assert "score" in data

    def test_human_output_clean_project(self) -> None:
        """Default human output should contain score-related text."""
        result = self.runner.invoke(main, [str(CLEAN_PROJECT)])
        assert result.exit_code == 0
        # Human output includes score line and/or category breakdown
        assert any(
            keyword in result.output.lower()
            for keyword in ["score", "health", "healthy", "/100"]
        )

    def test_fail_under_pass(self) -> None:
        """--fail-under should exit 0 when score is above threshold."""
        result = self.runner.invoke(main, [str(CLEAN_PROJECT), "--fail-under", "0"])
        assert result.exit_code == 0

    def test_fail_under_fail(self) -> None:
        """--fail-under should exit 1 when score is below threshold."""
        result = self.runner.invoke(main, [str(MESSY_PROJECT), "--fail-under", "100"])
        assert result.exit_code == 1

    def test_profile_quick(self) -> None:
        """--profile quick should complete successfully."""
        result = self.runner.invoke(
            main, [str(CLEAN_PROJECT), "--score", "--profile", "quick"]
        )
        assert result.exit_code == 0
        score = int(result.output.strip())
        assert 0 <= score <= 100

    def test_profile_default(self) -> None:
        result = self.runner.invoke(
            main, [str(CLEAN_PROJECT), "--score", "--profile", "default"]
        )
        assert result.exit_code == 0
        score = int(result.output.strip())
        assert 0 <= score <= 100

    def test_quick_alias(self) -> None:
        """--quick should work as alias for --profile quick."""
        result = self.runner.invoke(main, [str(CLEAN_PROJECT), "--score", "--quick"])
        assert result.exit_code == 0
        score = int(result.output.strip())
        assert 0 <= score <= 100

    def test_verbose_flag(self) -> None:
        """--verbose should produce more detailed output."""
        result = self.runner.invoke(main, [str(MESSY_PROJECT), "--verbose"])
        assert result.exit_code == 0
        # Verbose output should include file:line references
        assert len(result.output) > 0

    def test_no_cache_flag(self) -> None:
        """--no-cache should complete successfully."""
        result = self.runner.invoke(main, [str(CLEAN_PROJECT), "--score", "--no-cache"])
        assert result.exit_code == 0
        score = int(result.output.strip())
        assert 0 <= score <= 100

    def test_skip_category(self) -> None:
        """--skip should exclude a category."""
        result = self.runner.invoke(
            main, [str(CLEAN_PROJECT), "--json", "--skip", "security"]
        )
        assert result.exit_code == 0
        data = json.loads(result.output)
        # Security category should not appear in scored categories
        if data.get("coverage"):
            scored = data["coverage"]["scored_categories"]
            assert "security" not in scored

    def test_only_category(self) -> None:
        """--only should restrict to a single category."""
        result = self.runner.invoke(
            main, [str(CLEAN_PROJECT), "--json", "--only", "quality"]
        )
        assert result.exit_code == 0
        data = json.loads(result.output)
        # Should only score quality-related categories
        if data.get("coverage"):
            scored = data["coverage"]["scored_categories"]
            for cat in scored:
                assert cat == "quality"

    def test_nonexistent_path(self) -> None:
        """Should error on a nonexistent path."""
        result = self.runner.invoke(main, ["/nonexistent/path/xyz"])
        assert result.exit_code != 0

    def test_badge_output(self) -> None:
        """--badge should produce a shields.io URL."""
        result = self.runner.invoke(main, [str(CLEAN_PROJECT), "--badge"])
        assert result.exit_code == 0
        assert "shields.io" in result.output or "img.shields.io" in result.output

    def test_type_backend_mypy(self) -> None:
        """--type-backend mypy should complete successfully."""
        result = self.runner.invoke(
            main, [str(CLEAN_PROJECT), "--score", "--type-backend", "mypy"]
        )
        assert result.exit_code == 0

    def test_type_backend_auto(self) -> None:
        """--type-backend auto is the default."""
        result = self.runner.invoke(
            main, [str(CLEAN_PROJECT), "--score", "--type-backend", "auto"]
        )
        assert result.exit_code == 0


# Golden output tests -- stable structural assertions


class TestGoldenOutput:
    """Validate stable output characteristics for known fixture projects.

    These are not byte-exact golden files (which are brittle). Instead,
    they assert structural properties that must remain stable across
    releases.
    """

    def setup_method(self) -> None:
        self.runner = CliRunner()

    def test_clean_project_scores_high(self) -> None:
        """A clean project should score >= 80."""
        result = self.runner.invoke(main, [str(CLEAN_PROJECT), "--score"])
        assert result.exit_code == 0
        score = int(result.output.strip())
        assert score >= 80, f"Clean project scored {score}, expected >= 80"

    def test_messy_project_scores_lower(self) -> None:
        """A messy project should score lower than a clean one."""
        clean_result = self.runner.invoke(main, [str(CLEAN_PROJECT), "--score"])
        messy_result = self.runner.invoke(main, [str(MESSY_PROJECT), "--score"])
        clean_score = int(clean_result.output.strip())
        messy_score = int(messy_result.output.strip())
        assert messy_score < clean_score, (
            f"Messy ({messy_score}) should score lower than clean ({clean_score})"
        )

    def test_clean_project_label_healthy(self) -> None:
        """Clean project JSON should report 'Healthy' label."""
        result = self.runner.invoke(main, [str(CLEAN_PROJECT), "--json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["label"] == "Healthy"

    def test_messy_project_has_diagnostics(self) -> None:
        """Messy project should produce diagnostics."""
        result = self.runner.invoke(main, [str(MESSY_PROJECT), "--json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert len(data["diagnostics"]) > 0

    def test_clean_project_few_diagnostics(self) -> None:
        """Clean project should have very few diagnostics."""
        result = self.runner.invoke(main, [str(CLEAN_PROJECT), "--json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        # Clean project may still have minor issues (e.g. no py.typed)
        # but should have far fewer than the messy one
        assert len(data["diagnostics"]) < 10

    def test_partial_coverage_reported(self) -> None:
        """Skipping a category should show partial/limited confidence."""
        result = self.runner.invoke(
            main,
            [str(CLEAN_PROJECT), "--json", "--skip", "type_safety,security"],
        )
        assert result.exit_code == 0
        data = json.loads(result.output)
        coverage = data.get("coverage", {})
        # With categories skipped, confidence should not be "full"
        # unless all remaining categories still run successfully
        assert coverage.get("confidence") in ("full", "partial", "limited")

    def test_human_output_contains_category_names(self) -> None:
        """Human output should mention category names."""
        result = self.runner.invoke(main, [str(CLEAN_PROJECT)])
        assert result.exit_code == 0
        output_lower = result.output.lower()
        # At least some category names should appear
        found = sum(
            1 for name in ["quality", "security", "complexity"] if name in output_lower
        )
        assert found >= 1, "Expected at least one category name in output"

    def test_quick_profile_fewer_analyzers(self) -> None:
        """Quick profile should use fewer analyzers than default."""
        quick_result = self.runner.invoke(
            main, [str(CLEAN_PROJECT), "--json", "--profile", "quick"]
        )
        default_result = self.runner.invoke(
            main, [str(CLEAN_PROJECT), "--json", "--profile", "default"]
        )
        quick_data = json.loads(quick_result.output)
        default_data = json.loads(default_result.output)
        assert len(quick_data["analyzers_used"]) <= len(default_data["analyzers_used"])


# JSON schema validation tests


class TestJSONSchema:
    """Validate that JSON output conforms to the expected schema.

    These tests freeze the top-level structure of the JSON output
    so downstream consumers (CI, editors, MCP) can rely on it.
    """

    def setup_method(self) -> None:
        self.runner = CliRunner()
        result = self.runner.invoke(main, [str(CLEAN_PROJECT), "--json"])
        assert result.exit_code == 0
        self.data = json.loads(result.output)

    def test_top_level_keys(self) -> None:
        """JSON output must contain all required top-level keys."""
        required_keys = {
            "score",
            "label",
            "category_scores",
            "diagnostics",
            "project",
            "duration_ms",
        }
        assert required_keys.issubset(self.data.keys()), (
            f"Missing keys: {required_keys - self.data.keys()}"
        )

    def test_score_is_integer(self) -> None:
        assert isinstance(self.data["score"], int)
        assert 0 <= self.data["score"] <= 100

    def test_label_is_string(self) -> None:
        assert isinstance(self.data["label"], str)
        assert self.data["label"] in ("Healthy", "Needs work", "Critical")

    def test_duration_ms_is_positive_int(self) -> None:
        assert isinstance(self.data["duration_ms"], int)
        assert self.data["duration_ms"] >= 0

    def test_category_scores_structure(self) -> None:
        """Each category score must have required fields."""
        scores = self.data["category_scores"]
        assert isinstance(scores, list)
        for cs in scores:
            assert "category" in cs, f"Missing 'category' in {cs}"
            assert "score" in cs
            assert "weight" in cs
            assert "issue_count" in cs
            assert isinstance(cs["score"], int | float)
            assert isinstance(cs["weight"], int)
            assert isinstance(cs["issue_count"], int)

    def test_category_score_valid_category(self) -> None:
        """Category values must be from the known enum."""
        valid_categories = {
            "quality",
            "type_safety",
            "security",
            "complexity",
            "dead_code",
            "dependencies",
        }
        for cs in self.data["category_scores"]:
            assert cs["category"] in valid_categories, (
                f"Unknown category: {cs['category']}"
            )

    def test_diagnostics_structure(self) -> None:
        """Each diagnostic must have required fields."""
        diagnostics = self.data["diagnostics"]
        assert isinstance(diagnostics, list)
        for d in diagnostics:
            assert "file_path" in d
            assert "line" in d
            assert "column" in d
            assert "severity" in d
            assert "rule_id" in d
            assert "tool" in d
            assert "category" in d
            assert "message" in d

    def test_diagnostic_severity_values(self) -> None:
        """Severity must be a valid enum value."""
        valid_severities = {"error", "warning", "info"}
        for d in self.data["diagnostics"]:
            assert d["severity"] in valid_severities, (
                f"Invalid severity: {d['severity']}"
            )

    def test_project_structure(self) -> None:
        """Project info must have required fields."""
        project = self.data["project"]
        assert isinstance(project, dict)
        assert "python_version" in project
        assert "total_files" in project
        assert "total_lines" in project
        assert isinstance(project["total_files"], int)
        assert isinstance(project["total_lines"], int)

    def test_analyzers_used_is_list(self) -> None:
        assert isinstance(self.data.get("analyzers_used", []), list)

    def test_analyzers_skipped_is_list(self) -> None:
        assert isinstance(self.data.get("analyzers_skipped", []), list)

    def test_coverage_structure(self) -> None:
        """Coverage info, if present, must have required fields."""
        coverage = self.data.get("coverage")
        if coverage is None:
            return  # Coverage is optional
        assert isinstance(coverage, dict)
        assert "profile" in coverage
        assert "confidence" in coverage
        assert coverage["confidence"] in ("full", "partial", "limited")

    def test_coverage_category_coverage_structure(self) -> None:
        """Each category coverage entry must have required fields."""
        coverage = self.data.get("coverage")
        if coverage is None:
            return
        for cc in coverage.get("category_coverage", []):
            assert "category" in cc
            assert "status" in cc
            assert cc["status"] in (
                "scored",
                "partial",
                "unavailable",
                "skipped_by_user",
            )


class TestJSONSchemaMesyProject:
    """Validate JSON schema for a project with diagnostics."""

    def setup_method(self) -> None:
        self.runner = CliRunner()
        result = self.runner.invoke(main, [str(MESSY_PROJECT), "--json"])
        assert result.exit_code == 0
        self.data = json.loads(result.output)

    def test_messy_has_diagnostics_with_file_paths(self) -> None:
        """Diagnostics should reference actual file paths."""
        for d in self.data["diagnostics"]:
            assert isinstance(d["file_path"], str)
            assert len(d["file_path"]) > 0

    def test_messy_has_positive_issue_counts(self) -> None:
        """At least one category should have issues."""
        total_issues = sum(cs["issue_count"] for cs in self.data["category_scores"])
        assert total_issues > 0

    def test_messy_json_roundtrip(self) -> None:
        """JSON output should survive a parse-serialize roundtrip."""
        serialized = json.dumps(self.data, indent=2)
        roundtripped = json.loads(serialized)
        assert roundtripped == self.data


# Performance gate tests


class TestPerformanceGates:
    """Verify that analysis completes within acceptable time budgets.

    These use generous limits (not benchmarks) to catch gross regressions.
    Times are for warm runs (cache may be present).
    """

    def setup_method(self) -> None:
        self.runner = CliRunner()

    def test_clean_project_under_budget(self) -> None:
        """Small clean project should complete in under 10 seconds."""
        # Warm the cache first
        self.runner.invoke(main, [str(CLEAN_PROJECT), "--score"])

        start = time.monotonic()
        result = self.runner.invoke(main, [str(CLEAN_PROJECT), "--score"])
        elapsed = time.monotonic() - start

        assert result.exit_code == 0
        assert elapsed < 10.0, f"Clean project took {elapsed:.1f}s, expected < 10s"

    def test_messy_project_under_budget(self) -> None:
        """Small messy project should complete in under 10 seconds."""
        # Warm the cache first
        self.runner.invoke(main, [str(MESSY_PROJECT), "--score"])

        start = time.monotonic()
        result = self.runner.invoke(main, [str(MESSY_PROJECT), "--score"])
        elapsed = time.monotonic() - start

        assert result.exit_code == 0
        assert elapsed < 10.0, f"Messy project took {elapsed:.1f}s, expected < 10s"

    def test_quick_profile_faster_than_default(self) -> None:
        """Quick profile should be no slower than default profile."""
        # Run each twice (warm cache)
        self.runner.invoke(main, [str(CLEAN_PROJECT), "--score", "--profile", "quick"])
        self.runner.invoke(
            main, [str(CLEAN_PROJECT), "--score", "--profile", "default"]
        )

        start = time.monotonic()
        self.runner.invoke(main, [str(CLEAN_PROJECT), "--score", "--profile", "quick"])
        quick_time = time.monotonic() - start

        start = time.monotonic()
        self.runner.invoke(
            main, [str(CLEAN_PROJECT), "--score", "--profile", "default"]
        )
        default_time = time.monotonic() - start

        # Quick should be at most as slow as default (with generous margin)
        # We use 2x margin because small fixtures have noisy timing
        assert quick_time < default_time * 2.0 + 0.5, (
            f"Quick ({quick_time:.2f}s) was much slower than "
            f"default ({default_time:.2f}s)"
        )

    def test_json_output_under_budget(self) -> None:
        """JSON serialization should not add significant overhead."""
        # Warm
        self.runner.invoke(main, [str(CLEAN_PROJECT), "--score"])
        self.runner.invoke(main, [str(CLEAN_PROJECT), "--json"])

        start = time.monotonic()
        result = self.runner.invoke(main, [str(CLEAN_PROJECT), "--json"])
        elapsed = time.monotonic() - start

        assert result.exit_code == 0
        assert elapsed < 10.0, f"JSON output took {elapsed:.1f}s, expected < 10s"
