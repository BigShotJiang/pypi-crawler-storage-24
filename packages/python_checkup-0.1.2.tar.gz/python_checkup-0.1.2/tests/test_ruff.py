from __future__ import annotations

import json
from pathlib import Path
from typing import cast
from unittest.mock import AsyncMock, patch

import pytest

from python_checkup.analysis_request import AnalysisRequest
from python_checkup.analyzers.ruff import RuffAnalyzer, _map_diagnostic
from python_checkup.config import CheckupConfig
from python_checkup.models import Category, Severity

SAMPLE_RUFF_OUTPUT = json.dumps(
    [
        {
            "code": "F401",
            "message": "`os` imported but unused",
            "filename": "/tmp/test/src/app.py",
            "location": {"row": 1, "column": 8},
            "end_location": {"row": 1, "column": 10},
            "fix": {
                "message": "Remove unused import: `os`",
                "applicability": "safe",
                "edits": [],
            },
            "url": "https://docs.astral.sh/ruff/rules/unused-import",
            "noqa_row": 1,
            "cell": None,
        },
        {
            "code": "S101",
            "message": "Use of `assert` detected",
            "filename": "/tmp/test/src/app.py",
            "location": {"row": 10, "column": 1},
            "end_location": {"row": 10, "column": 20},
            "fix": None,
            "url": "https://docs.astral.sh/ruff/rules/assert",
            "noqa_row": 10,
            "cell": None,
        },
    ]
)


def _request(
    files: list[Path],
    *,
    framework: str | None = None,
    categories: set[Category] | None = None,
) -> AnalysisRequest:
    root = files[0].parent if files else Path(".")
    return AnalysisRequest(
        project_root=root,
        files=files,
        config=CheckupConfig(),
        categories=categories
        if categories is not None
        else {
            Category.QUALITY,
            Category.SECURITY,
            Category.COMPLEXITY,
            Category.DEAD_CODE,
        },
        profile="default",
        framework=framework,
    )


class TestRuffAnalyzer:
    async def test_is_available(self) -> None:
        analyzer = RuffAnalyzer()
        # Ruff is a hard dependency, should be available
        assert await analyzer.is_available() is True

    async def test_name_and_category(self) -> None:
        analyzer = RuffAnalyzer()
        assert analyzer.name == "ruff"
        assert analyzer.category == Category.QUALITY

    @patch("asyncio.create_subprocess_exec")
    async def test_analyze_with_results(self, mock_exec: AsyncMock) -> None:
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (
            SAMPLE_RUFF_OUTPUT.encode(),
            b"",
        )
        mock_proc.returncode = 1  # Violations found
        mock_exec.return_value = mock_proc

        analyzer = RuffAnalyzer()
        results = await analyzer.analyze(_request([Path("/tmp/test/src/app.py")]))

        assert len(results) == 2
        assert results[0].rule_id == "F401"
        assert results[0].severity == Severity.ERROR
        assert results[0].category == Category.QUALITY
        assert results[0].fix == "Remove unused import: `os`"

        assert results[1].rule_id == "S101"
        assert results[1].severity == Severity.ERROR
        assert results[1].category == Category.SECURITY

    @patch("asyncio.create_subprocess_exec")
    async def test_analyze_clean_project(self, mock_exec: AsyncMock) -> None:
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"[]", b"")
        mock_proc.returncode = 0
        mock_exec.return_value = mock_proc

        analyzer = RuffAnalyzer()
        results = await analyzer.analyze(_request([Path("/tmp/test")]))
        assert results == []

    @patch("asyncio.create_subprocess_exec")
    async def test_analyze_error(self, mock_exec: AsyncMock) -> None:
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"", b"Error: invalid config")
        mock_proc.returncode = 2
        mock_exec.return_value = mock_proc

        analyzer = RuffAnalyzer()
        results = await analyzer.analyze(_request([Path("/tmp/test")]))
        assert results == []

    async def test_analyze_empty_files(self) -> None:
        analyzer = RuffAnalyzer()
        results = await analyzer.analyze(_request([]))
        assert results == []


class TestMapDiagnostic:
    def test_maps_f401(self) -> None:
        raw = {
            "code": "F401",
            "message": "`os` imported but unused",
            "filename": "/test.py",
            "location": {"row": 1, "column": 8},
            "end_location": {"row": 1, "column": 10},
            "fix": {
                "message": "Remove unused import",
                "applicability": "safe",
                "edits": [],
            },
            "url": "https://docs.astral.sh/ruff/rules/unused-import",
        }
        d = _map_diagnostic(cast(dict[str, object], raw))
        assert d.rule_id == "F401"
        assert d.severity == Severity.ERROR
        assert d.category == Category.QUALITY
        assert d.fix == "Remove unused import"
        assert d.line == 1
        assert d.column == 8

    def test_maps_security_rule(self) -> None:
        raw = {
            "code": "S608",
            "message": "Possible SQL injection",
            "filename": "/test.py",
            "location": {"row": 5, "column": 1},
            "end_location": {"row": 5, "column": 30},
            "fix": None,
            "url": "https://docs.astral.sh/ruff/rules/hardcoded-sql-expression",
        }
        d = _map_diagnostic(cast(dict[str, object], raw))
        assert d.category == Category.SECURITY
        assert d.severity == Severity.ERROR
        assert d.fix is None

    def test_maps_complexity_rule(self) -> None:
        raw = {
            "code": "C901",
            "message": "'foo' is too complex (15)",
            "filename": "/test.py",
            "location": {"row": 10, "column": 1},
            "end_location": {"row": 10, "column": 10},
            "fix": None,
        }
        d = _map_diagnostic(cast(dict[str, object], raw))
        assert d.category == Category.COMPLEXITY
        assert d.severity == Severity.WARNING

    def test_maps_style_rule(self) -> None:
        raw = {
            "code": "W291",
            "message": "Trailing whitespace",
            "filename": "/test.py",
            "location": {"row": 3, "column": 20},
            "end_location": {"row": 3, "column": 21},
            "fix": None,
        }
        d = _map_diagnostic(cast(dict[str, object], raw))
        assert d.severity == Severity.INFO


class TestIntegration:
    """Integration tests that actually run Ruff."""

    async def test_ruff_on_messy_project(self, messy_project: Path) -> None:
        analyzer = RuffAnalyzer()
        if not await analyzer.is_available():
            pytest.skip("Ruff not available")

        results = await analyzer.analyze(_request(list(messy_project.rglob("*.py"))))
        # messy_project has unused imports and eval
        assert len(results) > 0
        rule_ids = {d.rule_id for d in results}
        assert "F401" in rule_ids  # unused imports

    async def test_ruff_on_clean_project(self, clean_project: Path) -> None:
        analyzer = RuffAnalyzer()
        if not await analyzer.is_available():
            pytest.skip("Ruff not available")

        results = await analyzer.analyze(_request(list(clean_project.rglob("*.py"))))
        assert len(results) == 0


class TestFrameworkRules:
    """Tests that framework detection extends Ruff rule selection."""

    @patch("asyncio.create_subprocess_exec")
    async def test_django_extends_select(self, mock_exec: AsyncMock) -> None:
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"[]", b"")
        mock_proc.returncode = 0
        mock_exec.return_value = mock_proc

        analyzer = RuffAnalyzer()
        await analyzer.analyze(_request([Path("/tmp/test.py")], framework="django"))

        # Verify --extend-select was passed with Django rules
        call_args = mock_exec.call_args[0]
        assert "--extend-select" in call_args
        idx = call_args.index("--extend-select")
        rules = call_args[idx + 1]
        assert "DJ" in rules
        assert "S610" in rules
        assert "S611" in rules

    @patch("asyncio.create_subprocess_exec")
    async def test_fastapi_extends_select(self, mock_exec: AsyncMock) -> None:
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"[]", b"")
        mock_proc.returncode = 0
        mock_exec.return_value = mock_proc

        analyzer = RuffAnalyzer()
        await analyzer.analyze(_request([Path("/tmp/test.py")], framework="fastapi"))

        call_args = mock_exec.call_args[0]
        assert "--extend-select" in call_args
        idx = call_args.index("--extend-select")
        rules = call_args[idx + 1]
        assert "FAST" in rules
        assert "ASYNC" in rules

    @patch("asyncio.create_subprocess_exec")
    async def test_flask_extends_select(self, mock_exec: AsyncMock) -> None:
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"[]", b"")
        mock_proc.returncode = 0
        mock_exec.return_value = mock_proc

        analyzer = RuffAnalyzer()
        await analyzer.analyze(_request([Path("/tmp/test.py")], framework="flask"))

        call_args = mock_exec.call_args[0]
        assert "--extend-select" in call_args
        idx = call_args.index("--extend-select")
        rules = call_args[idx + 1]
        assert "S201" in rules

    @patch("asyncio.create_subprocess_exec")
    async def test_no_framework_no_extend(self, mock_exec: AsyncMock) -> None:
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"[]", b"")
        mock_proc.returncode = 0
        mock_exec.return_value = mock_proc

        analyzer = RuffAnalyzer()
        await analyzer.analyze(_request([Path("/tmp/test.py")]))

        call_args = mock_exec.call_args[0]
        assert "--extend-select" not in call_args

    @patch("asyncio.create_subprocess_exec")
    async def test_none_framework_no_extend(self, mock_exec: AsyncMock) -> None:
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"[]", b"")
        mock_proc.returncode = 0
        mock_exec.return_value = mock_proc

        analyzer = RuffAnalyzer()
        await analyzer.analyze(_request([Path("/tmp/test.py")], framework=None))

        call_args = mock_exec.call_args[0]
        assert "--extend-select" not in call_args


class TestCategoryFiltering:
    """Tests that Ruff respects active categories and filters diagnostics."""

    @patch("asyncio.create_subprocess_exec")
    async def test_skip_security_filters_s_rules(self, mock_exec: AsyncMock) -> None:
        """--skip security should suppress Ruff S-prefixed diagnostics."""
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (
            SAMPLE_RUFF_OUTPUT.encode(),
            b"",
        )
        mock_proc.returncode = 1
        mock_exec.return_value = mock_proc

        analyzer = RuffAnalyzer()
        # Only include QUALITY -- exclude SECURITY
        results = await analyzer.analyze(
            _request(
                [Path("/tmp/test/src/app.py")],
                categories={Category.QUALITY, Category.COMPLEXITY, Category.DEAD_CODE},
            )
        )

        # S101 should be filtered out, F401 should remain
        assert len(results) == 1
        assert results[0].rule_id == "F401"

    @patch("asyncio.create_subprocess_exec")
    async def test_skip_quality_filters_quality_rules(
        self, mock_exec: AsyncMock
    ) -> None:
        """--skip quality should suppress quality diagnostics from Ruff."""
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (
            SAMPLE_RUFF_OUTPUT.encode(),
            b"",
        )
        mock_proc.returncode = 1
        mock_exec.return_value = mock_proc

        analyzer = RuffAnalyzer()
        # Only include SECURITY -- exclude QUALITY
        results = await analyzer.analyze(
            _request(
                [Path("/tmp/test/src/app.py")],
                categories={Category.SECURITY},
            )
        )

        # F401 should be filtered out, S101 should remain
        assert len(results) == 1
        assert results[0].rule_id == "S101"

    @patch("asyncio.create_subprocess_exec")
    async def test_all_categories_returns_all(self, mock_exec: AsyncMock) -> None:
        """When all categories are active, all diagnostics pass through."""
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (
            SAMPLE_RUFF_OUTPUT.encode(),
            b"",
        )
        mock_proc.returncode = 1
        mock_exec.return_value = mock_proc

        analyzer = RuffAnalyzer()
        results = await analyzer.analyze(_request([Path("/tmp/test/src/app.py")]))

        assert len(results) == 2
