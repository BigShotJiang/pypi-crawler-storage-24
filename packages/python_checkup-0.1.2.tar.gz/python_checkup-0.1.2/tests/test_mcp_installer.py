from __future__ import annotations

import json
from pathlib import Path

from python_checkup.mcp.installer import install_mcp_config


class TestMCPInstaller:
    """Test auto-install of MCP config for various editors."""

    def test_install_creates_mcp_json(self, tmp_path: Path) -> None:
        """install_mcp_config should always create .mcp.json."""
        installed = install_mcp_config(tmp_path)
        assert len(installed) >= 1

        mcp_json = tmp_path / ".mcp.json"
        assert mcp_json.exists()
        data = json.loads(mcp_json.read_text())
        assert "mcpServers" in data
        assert "python-checkup" in data["mcpServers"]

    def test_install_config_entry_structure(self, tmp_path: Path) -> None:
        """The installed config should have command and args."""
        install_mcp_config(tmp_path)

        mcp_json = tmp_path / ".mcp.json"
        data = json.loads(mcp_json.read_text())
        entry = data["mcpServers"]["python-checkup"]
        assert "command" in entry
        assert "args" in entry
        assert entry["command"] == "uvx"
        assert "--mcp" in entry["args"]

    def test_install_merges_existing(self, tmp_path: Path) -> None:
        """Existing server entries should be preserved."""
        mcp_json = tmp_path / ".mcp.json"
        mcp_json.write_text(
            json.dumps({"mcpServers": {"other-tool": {"command": "other", "args": []}}})
        )

        install_mcp_config(tmp_path)

        data = json.loads(mcp_json.read_text())
        assert "other-tool" in data["mcpServers"]  # Preserved
        assert "python-checkup" in data["mcpServers"]  # Added

    def test_install_merges_with_non_server_keys(self, tmp_path: Path) -> None:
        """Other top-level keys in the config should be preserved."""
        mcp_json = tmp_path / ".mcp.json"
        mcp_json.write_text(json.dumps({"mcpServers": {}, "customSetting": True}))

        install_mcp_config(tmp_path)

        data = json.loads(mcp_json.read_text())
        assert data["customSetting"] is True
        assert "python-checkup" in data["mcpServers"]

    def test_install_handles_malformed_json(self, tmp_path: Path) -> None:
        """Malformed existing JSON should not crash; overwrite gracefully."""
        mcp_json = tmp_path / ".mcp.json"
        mcp_json.write_text("not valid json{{{")

        install_mcp_config(tmp_path)

        data = json.loads(mcp_json.read_text())
        assert "mcpServers" in data
        assert "python-checkup" in data["mcpServers"]

    def test_install_cursor_only_if_exists(self, tmp_path: Path) -> None:
        """Don't create .cursor/ if it doesn't exist."""
        install_mcp_config(tmp_path)
        assert not (tmp_path / ".cursor").exists()

    def test_install_cursor_when_present(self, tmp_path: Path) -> None:
        """Install into .cursor/mcp.json when .cursor/ exists."""
        (tmp_path / ".cursor").mkdir()
        install_mcp_config(tmp_path)
        cursor_config = tmp_path / ".cursor" / "mcp.json"
        assert cursor_config.exists()

        data = json.loads(cursor_config.read_text())
        assert "mcpServers" in data
        assert "python-checkup" in data["mcpServers"]

    def test_install_vscode_only_if_exists(self, tmp_path: Path) -> None:
        """Don't create .vscode/ if it doesn't exist."""
        install_mcp_config(tmp_path)
        assert not (tmp_path / ".vscode").exists()

    def test_install_vscode_when_present(self, tmp_path: Path) -> None:
        """Install into .vscode/mcp.json when .vscode/ exists."""
        (tmp_path / ".vscode").mkdir()
        install_mcp_config(tmp_path)
        vscode_config = tmp_path / ".vscode" / "mcp.json"
        assert vscode_config.exists()

        data = json.loads(vscode_config.read_text())
        # VS Code uses "servers" not "mcpServers"
        assert "servers" in data
        assert "python-checkup" in data["servers"]

    def test_install_all_editors(self, tmp_path: Path) -> None:
        """When all editor dirs exist, install to all."""
        (tmp_path / ".cursor").mkdir()
        (tmp_path / ".vscode").mkdir()

        installed = install_mcp_config(tmp_path)

        # Should install to .mcp.json, .cursor/mcp.json, .vscode/mcp.json
        assert len(installed) >= 3

    def test_install_returns_paths(self, tmp_path: Path) -> None:
        """install_mcp_config should return list of installed paths."""
        installed = install_mcp_config(tmp_path)
        assert isinstance(installed, list)
        for path_str in installed:
            assert Path(path_str).exists()
