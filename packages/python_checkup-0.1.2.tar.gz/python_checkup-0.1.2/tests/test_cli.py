from importlib.metadata import version

from click.testing import CliRunner

from python_checkup.cli import main


class TestCLI:
    def setup_method(self) -> None:
        self.runner = CliRunner()

    def test_version(self) -> None:
        result = self.runner.invoke(main, ["--version"])
        assert result.exit_code == 0
        assert version("python-checkup") in result.output

    def test_help(self) -> None:
        result = self.runner.invoke(main, ["--help"])
        assert result.exit_code == 0
        assert "python-checkup" in result.output

    def test_default_invocation(self) -> None:
        result = self.runner.invoke(main, ["."])
        assert result.exit_code == 0
