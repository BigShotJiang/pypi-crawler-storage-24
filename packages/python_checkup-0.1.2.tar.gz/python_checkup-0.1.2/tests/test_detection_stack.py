"""Tests for the multi-framework detection stack (Phase 1)."""

from __future__ import annotations

from pathlib import Path

import pytest

from python_checkup.detection import (
    FrameworkCategory,
    FrameworkStack,
    detect_frameworks,
)

# ---------------------------------------------------------------------------
# FrameworkStack properties
# ---------------------------------------------------------------------------


class TestFrameworkStack:
    def test_names_empty_stack(self) -> None:
        stack = FrameworkStack(primary=None, companions=[], all_frameworks=[])
        assert stack.names == set()

    def test_has_returns_false_on_empty(self) -> None:
        stack = FrameworkStack(primary=None, companions=[], all_frameworks=[])
        assert not stack.has("django")

    def test_has_returns_true_when_present(self, tmp_path: Path) -> None:
        (tmp_path / "manage.py").write_text("import django\n")
        (tmp_path / "requirements.txt").write_text("django>=4.2\n")
        stack = detect_frameworks(tmp_path)
        assert stack.has("django")

    def test_primary_is_web_framework(self, tmp_path: Path) -> None:
        # Django (web) + Celery (task queue) — Django should be primary
        (tmp_path / "manage.py").write_text("import django\n")
        (tmp_path / "requirements.txt").write_text("django>=4.2\ncelery>=5.0\n")
        (tmp_path / "celery.py").write_text(
            "from celery import Celery\napp = Celery()\n"
        )
        stack = detect_frameworks(tmp_path)
        assert stack.primary is not None
        assert stack.primary.name == "django"
        assert stack.primary.category == FrameworkCategory.WEB


# ---------------------------------------------------------------------------
# Multi-framework detection
# ---------------------------------------------------------------------------


class TestMultiFrameworkDetection:
    def test_detects_django_and_celery_together(self, tmp_path: Path) -> None:
        (tmp_path / "manage.py").write_text("import django\n")
        (tmp_path / "requirements.txt").write_text("django>=4.2\ncelery>=5.0\n")
        (tmp_path / "celery.py").write_text(
            "from celery import Celery\napp = Celery()\n"
        )

        stack = detect_frameworks(tmp_path)
        assert stack.has("django")
        assert stack.has("celery")
        assert stack.primary is not None
        assert stack.primary.name == "django"

    def test_detects_fastapi_and_sqlalchemy(self, tmp_path: Path) -> None:
        (tmp_path / "main.py").write_text(
            "from fastapi import FastAPI\napp = FastAPI()\n"
        )
        (tmp_path / "requirements.txt").write_text("fastapi\nsqlalchemy>=2.0\n")
        (tmp_path / "models.py").write_text(
            "from sqlalchemy import Column, Integer\n"
            "from sqlalchemy.orm import DeclarativeBase\n"
            "class Base(DeclarativeBase): pass\n"
        )

        stack = detect_frameworks(tmp_path)
        assert stack.has("fastapi")
        assert stack.has("sqlalchemy")

    def test_companions_list_excludes_primary(self, tmp_path: Path) -> None:
        (tmp_path / "manage.py").write_text("import django\n")
        (tmp_path / "requirements.txt").write_text("django>=4.2\ncelery>=5.0\n")
        (tmp_path / "celery.py").write_text(
            "from celery import Celery\napp = Celery()\n"
        )

        stack = detect_frameworks(tmp_path)
        companion_names = [f.name for f in stack.companions]
        assert "django" not in companion_names
        assert "celery" in companion_names

    def test_empty_project_returns_empty_stack(self, tmp_path: Path) -> None:
        (tmp_path / "app.py").write_text("print('hello')\n")
        stack = detect_frameworks(tmp_path)
        assert stack.primary is None
        assert stack.all_frameworks == []

    def test_generic_deps_dont_trigger_detection(self, tmp_path: Path) -> None:
        (tmp_path / "requirements.txt").write_text("requests\nnumpy\npandas\n")
        (tmp_path / "app.py").write_text("import requests\n")
        stack = detect_frameworks(tmp_path)
        assert stack.primary is None


# ---------------------------------------------------------------------------
# New framework detectors
# ---------------------------------------------------------------------------


class TestCeleryDetection:
    def test_detects_celery_from_celery_py_and_requirements(
        self, tmp_path: Path
    ) -> None:
        (tmp_path / "celery.py").write_text(
            "from celery import Celery\napp = Celery('tasks')\n"
        )
        (tmp_path / "requirements.txt").write_text("celery>=5.0\n")
        stack = detect_frameworks(tmp_path)
        assert stack.has("celery")

    def test_celery_confidence_below_threshold_without_project_signal(
        self, tmp_path: Path
    ) -> None:
        # No celery.py, no requirements — only import in code
        (tmp_path / "app.py").write_text("print('hello')\n")
        stack = detect_frameworks(tmp_path)
        assert not stack.has("celery")

    def test_celery_category_is_task_queue(self, tmp_path: Path) -> None:
        (tmp_path / "celery.py").write_text("from celery import Celery\n")
        (tmp_path / "requirements.txt").write_text("celery>=5.0\n")
        stack = detect_frameworks(tmp_path)
        celery_fw = next((f for f in stack.all_frameworks if f.name == "celery"), None)
        assert celery_fw is not None
        assert celery_fw.category == FrameworkCategory.TASK_QUEUE


class TestSQLAlchemyDetection:
    def test_detects_from_alembic_dir_and_requirements(self, tmp_path: Path) -> None:
        (tmp_path / "alembic").mkdir()
        (tmp_path / "requirements.txt").write_text("sqlalchemy>=2.0\n")
        stack = detect_frameworks(tmp_path)
        assert stack.has("sqlalchemy")

    def test_detects_from_imports_and_requirements(self, tmp_path: Path) -> None:
        (tmp_path / "models.py").write_text(
            "from sqlalchemy.orm import DeclarativeBase\n"
        )
        (tmp_path / "requirements.txt").write_text("sqlalchemy>=2.0\n")
        stack = detect_frameworks(tmp_path)
        assert stack.has("sqlalchemy")

    def test_sqlalchemy_category_is_orm(self, tmp_path: Path) -> None:
        (tmp_path / "alembic").mkdir()
        (tmp_path / "requirements.txt").write_text("sqlalchemy>=2.0\n")
        stack = detect_frameworks(tmp_path)
        sa_fw = next((f for f in stack.all_frameworks if f.name == "sqlalchemy"), None)
        assert sa_fw is not None
        assert sa_fw.category == FrameworkCategory.ORM


class TestPydanticDetection:
    def test_detects_from_imports_and_requirements(self, tmp_path: Path) -> None:
        (tmp_path / "schemas.py").write_text(
            "from pydantic import BaseModel\nclass User(BaseModel): name: str\n"
        )
        (tmp_path / "requirements.txt").write_text("pydantic>=2.0\n")
        stack = detect_frameworks(tmp_path)
        assert stack.has("pydantic")

    def test_pydantic_category_is_validation(self, tmp_path: Path) -> None:
        (tmp_path / "schemas.py").write_text("from pydantic import BaseModel\n")
        (tmp_path / "requirements.txt").write_text("pydantic>=2.0\n")
        stack = detect_frameworks(tmp_path)
        fw = next((f for f in stack.all_frameworks if f.name == "pydantic"), None)
        assert fw is not None
        assert fw.category == FrameworkCategory.VALIDATION


class TestPytestDetection:
    def test_detects_from_conftest_and_requirements(self, tmp_path: Path) -> None:
        (tmp_path / "conftest.py").write_text("import pytest\n")
        (tmp_path / "requirements.txt").write_text("pytest>=8.0\n")
        stack = detect_frameworks(tmp_path)
        assert stack.has("pytest")

    def test_pytest_category_is_testing(self, tmp_path: Path) -> None:
        (tmp_path / "conftest.py").write_text("import pytest\n")
        (tmp_path / "requirements.txt").write_text("pytest>=8.0\n")
        stack = detect_frameworks(tmp_path)
        fw = next((f for f in stack.all_frameworks if f.name == "pytest"), None)
        assert fw is not None
        assert fw.category == FrameworkCategory.TESTING


class TestDRFDetection:
    def test_detects_drf_from_imports_and_requirements(self, tmp_path: Path) -> None:
        # The PyPI package is "djangorestframework" (no hyphens)
        (tmp_path / "serializers.py").write_text(
            "from rest_framework import serializers\n"
        )
        (tmp_path / "requirements.txt").write_text("djangorestframework>=3.14\n")
        stack = detect_frameworks(tmp_path)
        assert stack.has("drf")

    def test_drf_has_parent_django(self, tmp_path: Path) -> None:
        (tmp_path / "serializers.py").write_text(
            "from rest_framework import serializers\n"
        )
        (tmp_path / "requirements.txt").write_text("rest_framework\n")
        stack = detect_frameworks(tmp_path)
        drf = next((f for f in stack.all_frameworks if f.name == "drf"), None)
        if drf:
            assert drf.parent == "django"
            assert drf.category == FrameworkCategory.API


# ---------------------------------------------------------------------------
# FrameworkInfo new fields
# ---------------------------------------------------------------------------


class TestFrameworkInfoFields:
    def test_django_has_stubs_package(self, tmp_path: Path) -> None:
        (tmp_path / "manage.py").write_text("import django\n")
        (tmp_path / "requirements.txt").write_text("django>=4.2\n")
        stack = detect_frameworks(tmp_path)
        assert stack.primary is not None
        assert stack.primary.stubs_package == "django-stubs"

    def test_fastapi_no_stubs_package(self, tmp_path: Path) -> None:
        (tmp_path / "main.py").write_text(
            "from fastapi import FastAPI\napp=FastAPI()\n"
        )
        (tmp_path / "requirements.txt").write_text("fastapi\n")
        stack = detect_frameworks(tmp_path)
        assert stack.primary is not None
        assert stack.primary.stubs_package is None


# ---------------------------------------------------------------------------
# ProjectInfo extended fields (via runner)
# ---------------------------------------------------------------------------


class TestProjectInfoFrameworkFields:
    """These are integration-level tests that verify runner populates the new fields."""

    @pytest.mark.asyncio
    async def test_detected_frameworks_populated(self, tmp_path: Path) -> None:
        from python_checkup.config import CheckupConfig
        from python_checkup.runner import run_analysis

        (tmp_path / "manage.py").write_text("import django\n")
        (tmp_path / "requirements.txt").write_text("django>=4.2\ncelery>=5.0\n")
        (tmp_path / "celery.py").write_text("from celery import Celery\napp=Celery()\n")
        (tmp_path / "app.py").write_text("x = 1\n")

        report = await run_analysis(
            tmp_path, CheckupConfig(), quiet=True, no_cache=True
        )
        assert "django" in report.project.detected_frameworks

    @pytest.mark.asyncio
    async def test_framework_details_includes_versions(self, tmp_path: Path) -> None:
        from python_checkup.config import CheckupConfig
        from python_checkup.runner import run_analysis

        (tmp_path / "main.py").write_text(
            "from fastapi import FastAPI\napp=FastAPI()\n"
        )
        (tmp_path / "requirements.txt").write_text("fastapi\n")
        (tmp_path / "app.py").write_text("x = 1\n")

        report = await run_analysis(
            tmp_path, CheckupConfig(), quiet=True, no_cache=True
        )
        # framework_details maps name->version for detected frameworks with versions
        assert isinstance(report.project.framework_details, dict)
