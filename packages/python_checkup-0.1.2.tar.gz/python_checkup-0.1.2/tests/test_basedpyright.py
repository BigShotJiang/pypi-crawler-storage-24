from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock, patch

from python_checkup.analysis_request import AnalysisRequest
from python_checkup.analyzers.basedpyright import BasedPyrightAnalyzer
from python_checkup.config import CheckupConfig
from python_checkup.models import Category, Severity


def _request(tmp_path: Path) -> AnalysisRequest:
    file_path = tmp_path / "app.py"
    file_path.write_text("x = 1\n")
    return AnalysisRequest(
        project_root=tmp_path,
        files=[file_path],
        config=CheckupConfig(),
        categories={Category.TYPE_SAFETY},
        profile="full",
    )


class TestBasedPyrightAnalyzer:
    def test_name_and_category(self) -> None:
        analyzer = BasedPyrightAnalyzer()
        assert analyzer.name == "basedpyright"
        assert analyzer.category == Category.TYPE_SAFETY

    @patch("shutil.which", return_value="/usr/bin/basedpyright")
    async def test_is_available_true(self, mock_which: AsyncMock) -> None:
        analyzer = BasedPyrightAnalyzer()
        assert await analyzer.is_available() is True

    @patch("asyncio.create_subprocess_exec")
    async def test_parses_json(self, mock_exec: AsyncMock, tmp_path: Path) -> None:
        output = {
            "generalDiagnostics": [
                {
                    "file": str(tmp_path / "app.py"),
                    "severity": "error",
                    "message": "Type mismatch",
                    "rule": "reportArgumentType",
                    "range": {
                        "start": {"line": 1, "character": 2},
                        "end": {"line": 1, "character": 5},
                    },
                }
            ]
        }
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (json.dumps(output).encode(), b"")
        mock_proc.returncode = 1
        mock_exec.return_value = mock_proc

        analyzer = BasedPyrightAnalyzer()
        results = await analyzer.analyze(_request(tmp_path))

        assert len(results) == 1
        assert results[0].severity == Severity.ERROR
        assert results[0].rule_id == "basedpyright-reportArgumentType"

    @patch("asyncio.create_subprocess_exec")
    async def test_invalid_json_returns_empty(
        self, mock_exec: AsyncMock, tmp_path: Path
    ) -> None:
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"not json", b"")
        mock_proc.returncode = 1
        mock_exec.return_value = mock_proc

        analyzer = BasedPyrightAnalyzer()
        results = await analyzer.analyze(_request(tmp_path))
        assert results == []
