from __future__ import annotations

import json
from pathlib import Path

from python_checkup.dependencies.discovery import discover_dependency_source


class TestDependencyDiscovery:
    def test_prefers_uv_lock(self, tmp_path: Path) -> None:
        (tmp_path / "uv.lock").write_text(
            "version = 1\n\n"
            '[[package]]\nname = "requests"\nversion = "2.31.0"\n'
            'source = { registry = "https://pypi.org/simple" }\n'
        )
        source = discover_dependency_source(tmp_path)
        assert source is not None
        assert source.kind == "uv-lock"
        assert source.is_locked is True
        assert source.packages[0].name == "requests"

    def test_falls_back_to_requirements(self, tmp_path: Path) -> None:
        (tmp_path / "requirements.txt").write_text("requests==2.31.0\n")
        source = discover_dependency_source(tmp_path)
        assert source is not None
        assert source.kind == "requirements"
        assert source.packages[0].version == "2.31.0"

    def test_falls_back_to_pyproject(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text(
            '[project]\nname = "demo"\nversion = "0.1.0"\n'
            'dependencies = ["requests>=2.31.0"]\n'
        )
        source = discover_dependency_source(tmp_path)
        assert source is not None
        assert source.kind == "pyproject"
        assert source.is_locked is False
        assert source.packages[0].name == "requests"

    def test_returns_none_when_no_source(self, tmp_path: Path) -> None:
        assert discover_dependency_source(tmp_path) is None


class TestPoetryLockParser:
    """Tests for poetry.lock parsing."""

    def test_poetry_lock_basic(self, tmp_path: Path) -> None:
        (tmp_path / "poetry.lock").write_text(
            '[[package]]\nname = "requests"\nversion = "2.31.0"\n\n'
            '[[package]]\nname = "flask"\nversion = "3.0.2"\n'
        )
        source = discover_dependency_source(tmp_path)
        assert source is not None
        assert source.kind == "poetry-lock"
        assert source.is_locked is True
        assert len(source.packages) == 2
        assert source.packages[0].name == "requests"
        assert source.packages[0].version == "2.31.0"
        assert source.packages[1].name == "flask"

    def test_poetry_lock_preferred_over_requirements(self, tmp_path: Path) -> None:
        (tmp_path / "poetry.lock").write_text(
            '[[package]]\nname = "requests"\nversion = "2.31.0"\n'
        )
        (tmp_path / "requirements.txt").write_text("requests==2.30.0\n")
        source = discover_dependency_source(tmp_path)
        assert source is not None
        assert source.kind == "poetry-lock"

    def test_uv_lock_preferred_over_poetry_lock(self, tmp_path: Path) -> None:
        (tmp_path / "uv.lock").write_text(
            "version = 1\n\n"
            '[[package]]\nname = "requests"\nversion = "2.31.0"\n'
            'source = { registry = "https://pypi.org/simple" }\n'
        )
        (tmp_path / "poetry.lock").write_text(
            '[[package]]\nname = "requests"\nversion = "2.30.0"\n'
        )
        source = discover_dependency_source(tmp_path)
        assert source is not None
        assert source.kind == "uv-lock"


class TestPipfileLockParser:
    """Tests for Pipfile.lock parsing."""

    def test_pipfile_lock_basic(self, tmp_path: Path) -> None:
        data = {
            "_meta": {"hash": {"sha256": "abc123"}},
            "default": {
                "requests": {"version": "==2.31.0"},
                "flask": {"version": "==3.0.2"},
            },
            "develop": {},
        }
        (tmp_path / "Pipfile.lock").write_text(json.dumps(data))
        source = discover_dependency_source(tmp_path)
        assert source is not None
        assert source.kind == "pipfile-lock"
        assert source.is_locked is True
        assert len(source.packages) == 2
        names = {p.name for p in source.packages}
        assert "requests" in names
        assert "flask" in names

    def test_pipfile_lock_includes_develop(self, tmp_path: Path) -> None:
        data = {
            "default": {"requests": {"version": "==2.31.0"}},
            "develop": {"pytest": {"version": "==8.0.0"}},
        }
        (tmp_path / "Pipfile.lock").write_text(json.dumps(data))
        source = discover_dependency_source(tmp_path)
        assert source is not None
        assert len(source.packages) == 2
        names = {p.name for p in source.packages}
        assert "pytest" in names

    def test_pipfile_lock_preferred_over_requirements(self, tmp_path: Path) -> None:
        data = {"default": {"requests": {"version": "==2.31.0"}}, "develop": {}}
        (tmp_path / "Pipfile.lock").write_text(json.dumps(data))
        (tmp_path / "requirements.txt").write_text("requests==2.30.0\n")
        source = discover_dependency_source(tmp_path)
        assert source is not None
        assert source.kind == "pipfile-lock"

    def test_poetry_lock_preferred_over_pipfile_lock(self, tmp_path: Path) -> None:
        (tmp_path / "poetry.lock").write_text(
            '[[package]]\nname = "requests"\nversion = "2.31.0"\n'
        )
        data = {"default": {"requests": {"version": "==2.30.0"}}, "develop": {}}
        (tmp_path / "Pipfile.lock").write_text(json.dumps(data))
        source = discover_dependency_source(tmp_path)
        assert source is not None
        assert source.kind == "poetry-lock"

    def test_pipfile_lock_corrupted_json(self, tmp_path: Path) -> None:
        (tmp_path / "Pipfile.lock").write_text("not json {{{")
        source = discover_dependency_source(tmp_path)
        # Should fall through to next source or None
        assert source is None
