from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Any, cast
from unittest.mock import patch

from python_checkup.diff import get_changed_files


class TestGetChangedFiles:
    def test_returns_empty_when_not_git_repo(self, tmp_path: Path) -> None:
        """Non-git directories return empty list."""
        result = get_changed_files(tmp_path, base="main")
        assert result == []

    @patch("python_checkup.diff._run_git")
    def test_returns_python_files_only(self, mock_git: object) -> None:
        """Non-Python files are filtered out."""

        def side_effect(args: list[str], cwd: Path) -> str:
            if args[0] == "rev-parse" and args[1] == "--git-dir":
                return ".git"
            if args[0] == "rev-parse" and args[1] == "--abbrev-ref":
                return "feature-branch"
            if args[0] == "merge-base":
                return "abc123"
            if args[0] == "diff":
                return "src/app.py\nsrc/views.py\nREADME.md\npackage.json\n"
            return ""

        cast(Any, mock_git).side_effect = side_effect

        root = Path("/tmp/test_project")
        with patch.object(Path, "is_file", return_value=True):
            files = get_changed_files(root, base="main")

        py_files = [f for f in files if str(f).endswith(".py")]
        non_py = [f for f in files if not str(f).endswith(".py")]
        assert len(non_py) == 0
        assert len(py_files) == 2

    @patch("python_checkup.diff._run_git")
    def test_handles_no_changes(self, mock_git: object) -> None:
        """Empty diff returns empty list."""

        def side_effect(args: list[str], cwd: Path) -> str:
            if args[0] == "rev-parse" and args[1] == "--git-dir":
                return ".git"
            if args[0] == "rev-parse" and args[1] == "--abbrev-ref":
                return "main"
            if args[0] == "merge-base":
                return "abc123"
            if args[0] == "diff":
                return ""
            return ""

        cast(Any, mock_git).side_effect = side_effect
        files = get_changed_files(Path("/tmp/test"), base="main")
        assert files == []


class TestGitIntegration:
    """Integration tests that require a real git repo."""

    def test_real_git_repo(self, tmp_path: Path) -> None:
        """Test with an actual git repository."""
        subprocess.run(
            ["git", "init"],
            cwd=tmp_path,
            capture_output=True,
        )
        subprocess.run(
            ["git", "config", "user.email", "test@test.com"],
            cwd=tmp_path,
            capture_output=True,
        )
        subprocess.run(
            ["git", "config", "user.name", "Test"],
            cwd=tmp_path,
            capture_output=True,
        )

        # Create and commit a file on main
        (tmp_path / "existing.py").write_text("x = 1\n")
        subprocess.run(
            ["git", "add", "."],
            cwd=tmp_path,
            capture_output=True,
        )
        subprocess.run(
            ["git", "commit", "-m", "initial"],
            cwd=tmp_path,
            capture_output=True,
        )
        subprocess.run(
            ["git", "branch", "-M", "main"],
            cwd=tmp_path,
            capture_output=True,
        )

        # Create a branch and add a new file
        subprocess.run(
            ["git", "checkout", "-b", "feature"],
            cwd=tmp_path,
            capture_output=True,
        )
        (tmp_path / "new_file.py").write_text("y = 2\n")
        subprocess.run(
            ["git", "add", "."],
            cwd=tmp_path,
            capture_output=True,
        )
        subprocess.run(
            ["git", "commit", "-m", "add feature"],
            cwd=tmp_path,
            capture_output=True,
        )

        files = get_changed_files(tmp_path, base="main")
        filenames = [f.name for f in files]
        assert "new_file.py" in filenames
        assert "existing.py" not in filenames
