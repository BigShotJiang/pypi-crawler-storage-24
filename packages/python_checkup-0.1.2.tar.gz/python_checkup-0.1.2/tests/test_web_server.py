from __future__ import annotations

import json
import threading
import time
from collections.abc import Generator
from http.client import HTTPConnection
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

import python_checkup.web.template as _template_mod
from python_checkup.models import (
    Category,
    CategoryScore,
    Diagnostic,
    HealthReport,
    ProjectInfo,
    Severity,
)
from python_checkup.web.server import (
    ReportServer,
    RunContext,
    _serialize_report,
)
from python_checkup.web.template import render_report_html


@pytest.fixture(autouse=True)
def _clear_template_cache() -> None:
    """Clear the module-level template cache before every test."""
    _template_mod._TEMPLATE_CACHE = None


def _make_report(
    score: int = 85,
    diags: list[Diagnostic] | None = None,
) -> HealthReport:
    if diags is None:
        diags = [
            Diagnostic(
                file_path=Path("src/app.py"),
                line=10,
                column=0,
                severity=Severity.WARNING,
                rule_id="E501",
                tool="ruff",
                category=Category.QUALITY,
                message="Line too long",
            ),
        ]
    return HealthReport(
        score=score,
        label="Healthy",
        category_scores=[
            CategoryScore(
                category=Category.QUALITY,
                score=90,
                weight=30,
                issue_count=1,
            ),
        ],
        diagnostics=diags,
        project=ProjectInfo(
            python_version="3.12",
            framework=None,
            total_files=10,
            total_lines=500,
        ),
        duration_ms=1234,
        analyzers_used=["ruff"],
        analyzers_skipped=[],
    )


# ── _serialize_report ──


class TestSerializeReport:
    def test_paths_serialized_as_strings(self) -> None:
        report = _make_report()
        data = json.loads(_serialize_report(report))
        assert data["diagnostics"][0]["file_path"] == "src/app.py"

    def test_enums_serialized_as_values(self) -> None:
        report = _make_report()
        data = json.loads(_serialize_report(report))
        assert data["diagnostics"][0]["severity"] == "warning"
        assert data["diagnostics"][0]["category"] == "quality"

    def test_valid_json_output(self) -> None:
        report = _make_report()
        raw = _serialize_report(report)
        data = json.loads(raw)
        assert isinstance(data, dict)
        assert "score" in data


# ── render_report_html ──


class TestRenderReportHtml:
    def test_placeholders_replaced(self) -> None:
        html = render_report_html(
            report_json='{"score": 85}',
            session_token="test-token-123",
            catalog_json='{"ruff": {}}',
            can_rerun=True,
            diff_base=None,
        )
        assert "test-token-123" in html
        assert '"score": 85' in html
        assert '"ruff": {}' in html
        assert "{{ REPORT_DATA }}" not in html
        assert "{{SESSION_TOKEN}}" not in html
        assert "{{ ANALYZER_CATALOG }}" not in html
        assert "{{ CAN_RERUN }}" not in html
        assert "{{DIFF_BASE}}" not in html

    def test_can_rerun_false(self) -> None:
        html = render_report_html(
            report_json="{}",
            session_token="tok",
            can_rerun=False,
            diff_base=None,
        )
        assert "const CAN_RERUN = false;" in html

    def test_can_rerun_true(self) -> None:
        html = render_report_html(
            report_json="{}",
            session_token="tok",
            can_rerun=True,
            diff_base=None,
        )
        assert "const CAN_RERUN = true;" in html

    def test_diff_base_injected(self) -> None:
        html = render_report_html(
            report_json="{}",
            session_token="tok",
            diff_base="origin/main",
        )
        assert '"origin/main"' in html
        assert "{{DIFF_BASE}}" not in html

    def test_diff_base_empty_when_none(self) -> None:
        html = render_report_html(
            report_json="{}",
            session_token="tok",
            diff_base=None,
        )
        assert "{{DIFF_BASE}}" not in html


# ── ReportServer ──


class TestReportServer:
    def test_url_contains_token(self) -> None:
        report = _make_report()
        server = ReportServer(report, port=9999)
        assert "token=" in server.url
        assert server.token in server.url
        assert "9999" in server.url

    def test_rerun_without_context_raises(self) -> None:
        report = _make_report()
        server = ReportServer(report, port=9999, run_context=None)
        with pytest.raises(RuntimeError, match="No run context"):
            server.rerun_analysis(["ruff"])


# ── RunContext ──


class TestRunContext:
    def test_dataclass_fields(self) -> None:
        ctx = RunContext(
            project_root=Path("/tmp/proj"),
            config=MagicMock(),
            files=[Path("a.py")],
            plan=MagicMock(),
            no_cache=True,
            diff_base="main",
        )
        assert ctx.project_root == Path("/tmp/proj")
        assert ctx.no_cache is True
        assert ctx.diff_base == "main"

    def test_defaults(self) -> None:
        ctx = RunContext(
            project_root=Path("/tmp"),
            config=MagicMock(),
            files=[],
            plan=MagicMock(),
        )
        assert ctx.no_cache is False
        assert ctx.diff_base is None


# ── HTTP handler integration tests ──


class TestHttpHandler:
    """Integration tests that spin up a real server on a random port."""

    @pytest.fixture
    def server_and_conn(
        self,
    ) -> Generator[tuple[ReportServer, HTTPConnection], None, None]:
        """Start a ReportServer in a background thread, return (server, conn)."""
        report = _make_report()
        server = ReportServer(report, port=0)  # port=0 won't work directly

        # We need to pick a free port
        import socket

        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
        sock.close()

        server = ReportServer(report, port=port)
        thread = threading.Thread(
            target=lambda: server.start(open_browser=False),
            daemon=True,
        )
        thread.start()
        time.sleep(0.3)  # Wait for server to be ready

        conn = HTTPConnection("127.0.0.1", port, timeout=5)
        yield server, conn
        if server._server:
            server._server.shutdown()

    def test_get_root_valid_token(
        self, server_and_conn: tuple[ReportServer, HTTPConnection]
    ) -> None:
        server, conn = server_and_conn
        conn.request("GET", f"/?token={server.token}")
        resp = conn.getresponse()
        assert resp.status == 200
        body = resp.read().decode()
        assert "python-checkup" in body
        assert server.token in body

    def test_get_root_invalid_token(
        self, server_and_conn: tuple[ReportServer, HTTPConnection]
    ) -> None:
        server, conn = server_and_conn
        conn.request("GET", "/?token=bad-token")
        resp = conn.getresponse()
        assert resp.status == 403

    def test_get_root_no_token(
        self, server_and_conn: tuple[ReportServer, HTTPConnection]
    ) -> None:
        server, conn = server_and_conn
        conn.request("GET", "/")
        resp = conn.getresponse()
        assert resp.status == 403

    def test_get_404(
        self, server_and_conn: tuple[ReportServer, HTTPConnection]
    ) -> None:
        server, conn = server_and_conn
        conn.request("GET", "/nonexistent")
        resp = conn.getresponse()
        assert resp.status == 404

    def test_post_rerun_no_context(
        self, server_and_conn: tuple[ReportServer, HTTPConnection]
    ) -> None:
        server, conn = server_and_conn
        # server has no run_context by default
        body = json.dumps({"analyzers": ["ruff"]}).encode()
        conn.request(
            "POST",
            "/api/rerun",
            body=body,
            headers={
                "Content-Type": "application/json",
                "X-Session-Token": server.token,
            },
        )
        resp = conn.getresponse()
        assert resp.status == 400
        data = json.loads(resp.read())
        assert "not available" in data["error"]

    def test_post_rerun_invalid_token(
        self, server_and_conn: tuple[ReportServer, HTTPConnection]
    ) -> None:
        server, conn = server_and_conn
        body = json.dumps({"analyzers": ["ruff"]}).encode()
        conn.request(
            "POST",
            "/api/rerun",
            body=body,
            headers={
                "Content-Type": "application/json",
                "X-Session-Token": "wrong-token",
            },
        )
        resp = conn.getresponse()
        assert resp.status == 403

    def test_post_rerun_no_token(
        self, server_and_conn: tuple[ReportServer, HTTPConnection]
    ) -> None:
        server, conn = server_and_conn
        body = json.dumps({"analyzers": ["ruff"]}).encode()
        conn.request(
            "POST",
            "/api/rerun",
            body=body,
            headers={"Content-Type": "application/json"},
        )
        resp = conn.getresponse()
        assert resp.status == 403

    def test_post_rerun_empty_body(
        self, server_and_conn: tuple[ReportServer, HTTPConnection]
    ) -> None:
        server, conn = server_and_conn
        conn.request(
            "POST",
            "/api/rerun",
            body=b"",
            headers={
                "Content-Type": "application/json",
                "X-Session-Token": server.token,
            },
        )
        resp = conn.getresponse()
        assert resp.status == 400

    def test_post_rerun_invalid_json(
        self, server_and_conn: tuple[ReportServer, HTTPConnection]
    ) -> None:
        server, conn = server_and_conn
        conn.request(
            "POST",
            "/api/rerun",
            body=b"not json",
            headers={
                "Content-Type": "application/json",
                "X-Session-Token": server.token,
                "Content-Length": "8",
            },
        )
        resp = conn.getresponse()
        assert resp.status == 400

    def test_post_rerun_empty_analyzers_list(
        self, server_and_conn: tuple[ReportServer, HTTPConnection]
    ) -> None:
        server, conn = server_and_conn
        # Give it a context so we get past the "not available" check
        ctx = MagicMock()
        ctx.diff_base = None
        server.run_context = ctx
        body = json.dumps({"analyzers": []}).encode()
        conn.request(
            "POST",
            "/api/rerun",
            body=body,
            headers={
                "Content-Type": "application/json",
                "X-Session-Token": server.token,
            },
        )
        resp = conn.getresponse()
        assert resp.status == 400
        data = json.loads(resp.read())
        assert "non-empty" in data["error"]

    def test_post_rerun_unknown_analyzer(
        self, server_and_conn: tuple[ReportServer, HTTPConnection]
    ) -> None:
        server, conn = server_and_conn
        ctx = MagicMock()
        ctx.diff_base = None
        server.run_context = ctx
        body = json.dumps({"analyzers": ["nonexistent-tool"]}).encode()
        conn.request(
            "POST",
            "/api/rerun",
            body=body,
            headers={
                "Content-Type": "application/json",
                "X-Session-Token": server.token,
            },
        )
        resp = conn.getresponse()
        assert resp.status == 400
        data = json.loads(resp.read())
        assert "Unknown" in data["error"]

    def test_post_404(
        self, server_and_conn: tuple[ReportServer, HTTPConnection]
    ) -> None:
        server, conn = server_and_conn
        conn.request(
            "POST",
            "/api/other",
            body=b"{}",
            headers={
                "Content-Type": "application/json",
                "X-Session-Token": server.token,
                "Content-Length": "2",
            },
        )
        resp = conn.getresponse()
        assert resp.status == 404

    def test_post_rerun_success(
        self, server_and_conn: tuple[ReportServer, HTTPConnection]
    ) -> None:
        """Test a successful re-run by mocking rerun_analysis."""
        server, conn = server_and_conn
        ctx = MagicMock()
        ctx.diff_base = None
        server.run_context = ctx

        new_report = _make_report(score=72)

        with patch.object(server, "rerun_analysis", return_value=(new_report, None)):
            body = json.dumps({"analyzers": ["ruff"]}).encode()
            conn.request(
                "POST",
                "/api/rerun",
                body=body,
                headers={
                    "Content-Type": "application/json",
                    "X-Session-Token": server.token,
                },
            )
            resp = conn.getresponse()
            assert resp.status == 200
            data = json.loads(resp.read())
            assert "report" in data
            assert data["report"]["score"] == 72
            assert data["diff_mode"] is False

    def test_post_rerun_analysis_error(
        self, server_and_conn: tuple[ReportServer, HTTPConnection]
    ) -> None:
        """Test that analysis errors return 500."""
        server, conn = server_and_conn
        ctx = MagicMock()
        ctx.diff_base = None
        server.run_context = ctx

        with patch.object(
            server,
            "rerun_analysis",
            side_effect=RuntimeError("mypy crashed"),
        ):
            body = json.dumps({"analyzers": ["ruff"]}).encode()
            conn.request(
                "POST",
                "/api/rerun",
                body=body,
                headers={
                    "Content-Type": "application/json",
                    "X-Session-Token": server.token,
                },
            )
            resp = conn.getresponse()
            assert resp.status == 500
            data = json.loads(resp.read())
            assert "mypy crashed" in data["error"]

    def test_get_html_contains_report_data(
        self, server_and_conn: tuple[ReportServer, HTTPConnection]
    ) -> None:
        """Verify the served HTML embeds the report JSON data."""
        server, conn = server_and_conn
        conn.request("GET", f"/?token={server.token}")
        resp = conn.getresponse()
        body = resp.read().decode()
        # Should contain the serialized score
        assert '"score": 85' in body
        # Should contain the analyzer name
        assert "ruff" in body
        # Should contain CAN_RERUN = false (no run_context)
        assert "const CAN_RERUN = false;" in body

    def test_get_html_can_rerun_true(
        self, server_and_conn: tuple[ReportServer, HTTPConnection]
    ) -> None:
        server, conn = server_and_conn
        ctx = MagicMock()
        ctx.diff_base = None
        server.run_context = ctx
        conn.request("GET", f"/?token={server.token}")
        resp = conn.getresponse()
        body = resp.read().decode()
        assert "const CAN_RERUN = true;" in body


class TestNullReport:
    """Tests for serving with report=None (no initial analysis)."""

    @pytest.fixture
    def null_server_and_conn(
        self,
    ) -> Generator[tuple[ReportServer, HTTPConnection], None, None]:
        import socket

        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
        sock.close()

        ctx = MagicMock()
        ctx.diff_base = None
        server = ReportServer(report=None, port=port, run_context=ctx)
        thread = threading.Thread(
            target=lambda: server.start(open_browser=False),
            daemon=True,
        )
        thread.start()
        time.sleep(0.3)

        conn = HTTPConnection("127.0.0.1", port, timeout=5)
        yield server, conn
        if server._server:
            server._server.shutdown()

    def test_null_report_serves_html(
        self, null_server_and_conn: tuple[ReportServer, HTTPConnection]
    ) -> None:
        server, conn = null_server_and_conn
        conn.request("GET", f"/?token={server.token}")
        resp = conn.getresponse()
        assert resp.status == 200
        body = resp.read().decode()
        assert "python-checkup" in body

    def test_null_report_embeds_null(
        self, null_server_and_conn: tuple[ReportServer, HTTPConnection]
    ) -> None:
        server, conn = null_server_and_conn
        conn.request("GET", f"/?token={server.token}")
        resp = conn.getresponse()
        body = resp.read().decode()
        assert "const REPORT = null;" in body
        # CAN_RERUN should be true since run_context is provided
        assert "const CAN_RERUN = true;" in body

    def test_null_report_rerun_works(
        self, null_server_and_conn: tuple[ReportServer, HTTPConnection]
    ) -> None:
        """First analysis via rerun endpoint when starting with no report."""
        server, conn = null_server_and_conn
        new_report = _make_report(score=65)

        with patch.object(server, "rerun_analysis", return_value=(new_report, None)):
            body = json.dumps({"analyzers": ["ruff"]}).encode()
            conn.request(
                "POST",
                "/api/rerun",
                body=body,
                headers={
                    "Content-Type": "application/json",
                    "X-Session-Token": server.token,
                },
            )
            resp = conn.getresponse()
            assert resp.status == 200
            data = json.loads(resp.read())
            assert data["report"]["score"] == 65
