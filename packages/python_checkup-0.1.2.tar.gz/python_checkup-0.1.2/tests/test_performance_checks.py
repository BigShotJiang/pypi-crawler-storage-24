"""Tests for the PerformanceCheckAnalyzer."""

from __future__ import annotations

import ast
import asyncio
import textwrap
from pathlib import Path

import pytest

from python_checkup.analyzers.performance_checks import (  # noqa: E402
    PerformanceCheckAnalyzer,
    _check_async_blocking,
    _check_django_perf,
    _check_general_perf,
    _check_sqlalchemy_perf,
)
from python_checkup.models import Category, Diagnostic, Severity

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _parse(src: str) -> ast.Module:
    return ast.parse(textwrap.dedent(src))


def _rule_ids(diags: list[Diagnostic]) -> list[str]:
    return [d.rule_id for d in diags]


DUMMY = Path("test.py")


# ---------------------------------------------------------------------------
# PERF-ASYNC-001: blocking call in async function
# ---------------------------------------------------------------------------


class TestAsyncBlocking:
    def test_requests_get_in_async(self) -> None:
        tree = _parse(
            """
            import requests

            async def fetch():
                return requests.get("http://example.com")
        """
        )
        diags = _check_async_blocking(DUMMY, tree)
        assert "PERF-ASYNC-001" in _rule_ids(diags)

    def test_time_sleep_in_async(self) -> None:
        tree = _parse(
            """
            import time

            async def handler():
                time.sleep(1)
        """
        )
        diags = _check_async_blocking(DUMMY, tree)
        assert "PERF-ASYNC-001" in _rule_ids(diags)

    def test_requests_get_in_sync_ok(self) -> None:
        tree = _parse(
            """
            import requests

            def fetch():
                return requests.get("http://example.com")
        """
        )
        diags = _check_async_blocking(DUMMY, tree)
        assert not diags

    def test_httpx_async_not_flagged(self) -> None:
        tree = _parse(
            """
            import httpx

            async def fetch():
                async with httpx.AsyncClient() as c:
                    return await c.get("http://example.com")
        """
        )
        diags = _check_async_blocking(DUMMY, tree)
        assert not diags

    def test_sleep_bare_in_async(self) -> None:
        tree = _parse(
            """
            from time import sleep

            async def handler():
                sleep(5)
        """
        )
        diags = _check_async_blocking(DUMMY, tree)
        assert "PERF-ASYNC-001" in _rule_ids(diags)
        assert diags[0].severity == Severity.ERROR

    def test_blocking_nested_in_sync_inside_async_not_flagged(self) -> None:
        """Sync function inside async function should not be flagged."""
        tree = _parse(
            """
            import requests

            async def outer():
                def inner():
                    return requests.get("http://example.com")
                return inner()
        """
        )
        diags = _check_async_blocking(DUMMY, tree)
        assert not diags


# ---------------------------------------------------------------------------
# PERF-DJ-001/002/003: Django ORM misuse
# ---------------------------------------------------------------------------


class TestDjangoOrmPerf:
    def test_len_on_queryset(self) -> None:
        tree = _parse(
            """
            count = len(Model.objects.all())
        """
        )
        diags = _check_django_perf(DUMMY, tree)
        assert "PERF-DJ-001" in _rule_ids(diags)

    def test_bool_on_queryset(self) -> None:
        tree = _parse(
            """
            if bool(Model.objects.filter(active=True)):
                pass
        """
        )
        diags = _check_django_perf(DUMMY, tree)
        assert "PERF-DJ-002" in _rule_ids(diags)

    def test_list_comp_filtering_all(self) -> None:
        tree = _parse(
            """
            active = [x for x in Model.objects.all() if x.active]
        """
        )
        diags = _check_django_perf(DUMMY, tree)
        assert "PERF-DJ-005" in _rule_ids(diags)

    def test_filter_in_db_is_ok(self) -> None:
        tree = _parse(
            """
            active = Model.objects.filter(active=True)
        """
        )
        diags = _check_django_perf(DUMMY, tree)
        assert not diags

    def test_count_is_ok(self) -> None:
        tree = _parse(
            """
            n = Model.objects.all().count()
        """
        )
        diags = _check_django_perf(DUMMY, tree)
        assert "PERF-DJ-001" not in _rule_ids(diags)

    def test_order_by_inside_loop(self) -> None:
        tree = _parse(
            """
            for category in categories:
                items = Item.objects.filter(cat=category).order_by("name")
        """
        )
        diags = _check_django_perf(DUMMY, tree)
        assert "PERF-DJ-004" in _rule_ids(diags)


# ---------------------------------------------------------------------------
# PERF-SA-001/002: SQLAlchemy patterns
# ---------------------------------------------------------------------------


class TestSQLAlchemyPerf:
    def test_query_all_inside_loop(self) -> None:
        tree = _parse(
            """
            for item in items:
                related = session.query(Related).filter_by(item_id=item.id).all()
        """
        )
        diags = _check_sqlalchemy_perf(DUMMY, tree)
        assert "PERF-SA-001" in _rule_ids(diags)

    def test_len_of_query_all(self) -> None:
        tree = _parse(
            """
            count = len(session.query(Model).all())
        """
        )
        diags = _check_sqlalchemy_perf(DUMMY, tree)
        assert "PERF-SA-002" in _rule_ids(diags)

    def test_query_all_outside_loop_ok(self) -> None:
        tree = _parse(
            """
            results = session.query(Model).all()
        """
        )
        diags = _check_sqlalchemy_perf(DUMMY, tree)
        assert not diags


# ---------------------------------------------------------------------------
# PERF-GEN-001/002/003: General Python patterns
# ---------------------------------------------------------------------------


class TestGeneralPerf:
    def test_string_concat_in_loop(self) -> None:
        tree = _parse(
            """
            result = ""
            for item in items:
                result += str(item)
        """
        )
        diags = _check_general_perf(DUMMY, tree)
        assert "PERF-GEN-001" in _rule_ids(diags)

    def test_string_concat_outside_loop_ok(self) -> None:
        tree = _parse(
            """
            result = "hello " + "world"
        """
        )
        diags = _check_general_perf(DUMMY, tree)
        assert "PERF-GEN-001" not in _rule_ids(diags)

    def test_re_compile_in_loop(self) -> None:
        tree = _parse(
            """
            import re
            for line in lines:
                m = re.match(r'\\d+', line)
        """
        )
        diags = _check_general_perf(DUMMY, tree)
        assert "PERF-GEN-002" in _rule_ids(diags)

    def test_re_module_level_ok(self) -> None:
        tree = _parse(
            """
            import re
            PATTERN = re.compile(r'\\d+')
            for line in lines:
                m = PATTERN.match(line)
        """
        )
        diags = _check_general_perf(DUMMY, tree)
        assert "PERF-GEN-002" not in _rule_ids(diags)

    def test_repeated_attr_in_loop(self) -> None:
        tree = _parse(
            """
            for x in items:
                a = obj.config.value
                b = obj.config.value
                c = obj.config.value
        """
        )
        diags = _check_general_perf(DUMMY, tree)
        assert "PERF-GEN-003" in _rule_ids(diags)


# ---------------------------------------------------------------------------
# Category and severity checks
# ---------------------------------------------------------------------------


class TestDiagnosticMetadata:
    def test_async_blocking_is_error(self) -> None:
        tree = _parse(
            """
            import requests
            async def f():
                requests.get("http://x.com")
        """
        )
        diags = _check_async_blocking(DUMMY, tree)
        assert all(d.severity == Severity.ERROR for d in diags)
        assert all(d.category == Category.PERFORMANCE for d in diags)

    def test_django_orm_warnings(self) -> None:
        tree = _parse(
            """
            n = len(Model.objects.all())
        """
        )
        diags = _check_django_perf(DUMMY, tree)
        assert all(d.category == Category.PERFORMANCE for d in diags)
        assert any(d.severity == Severity.WARNING for d in diags)

    def test_all_diags_have_fix(self) -> None:
        tree = _parse(
            """
            import requests
            async def f():
                requests.get("http://x.com")
        """
        )
        diags = _check_async_blocking(DUMMY, tree)
        assert all(d.fix is not None for d in diags)


# ---------------------------------------------------------------------------
# Analyzer class integration
# ---------------------------------------------------------------------------


class TestPerformanceCheckAnalyzer:
    @pytest.fixture
    def analyzer(self) -> PerformanceCheckAnalyzer:
        return PerformanceCheckAnalyzer()

    def test_name(self, analyzer: PerformanceCheckAnalyzer) -> None:
        assert analyzer.name == "performance-checks"

    def test_category(self, analyzer: PerformanceCheckAnalyzer) -> None:
        assert analyzer.category == Category.PERFORMANCE

    def test_is_available(self, analyzer: PerformanceCheckAnalyzer) -> None:
        assert asyncio.run(analyzer.is_available()) is True

    def test_analyze_no_files(
        self, analyzer: PerformanceCheckAnalyzer, tmp_path: Path
    ) -> None:
        from python_checkup.analysis_request import AnalysisRequest
        from python_checkup.config import CheckupConfig

        req = AnalysisRequest(
            files=[],
            project_root=tmp_path,
            config=CheckupConfig(),
            categories=set(),
            profile="default",
            framework_stack=None,
        )
        result = asyncio.run(analyzer.analyze(req))
        assert result == []

    def test_analyze_detects_async_blocking(
        self, analyzer: PerformanceCheckAnalyzer, tmp_path: Path
    ) -> None:
        from python_checkup.analysis_request import AnalysisRequest
        from python_checkup.config import CheckupConfig

        f = tmp_path / "views.py"
        f.write_text(
            "import requests\n"
            "async def fetch():\n"
            "    return requests.get('http://x.com')\n"
        )
        req = AnalysisRequest(
            files=[f],
            project_root=tmp_path,
            config=CheckupConfig(),
            categories=set(),
            profile="default",
            framework_stack=None,
        )
        result = asyncio.run(analyzer.analyze(req))
        rule_ids = [d.rule_id for d in result]
        assert "PERF-ASYNC-001" in rule_ids
