from pathlib import Path

from python_checkup.config import DEFAULT_WEIGHTS, CheckupConfig
from python_checkup.detection import FrameworkCategory, FrameworkInfo, FrameworkStack
from python_checkup.models import (
    Category,
    Diagnostic,
    ProjectInfo,
    Severity,
)
from python_checkup.scoring.engine import (
    CRITICAL_RULES,
    _score_complexity,
    _score_dead_code,
    _score_dependencies,
    _score_quality,
    _score_security,
    _score_type_safety,
    compute_health_report,
    redistribute_weights,
)
from python_checkup.scoring.framework_adjustments import (
    ScoringContext,
    compute_penalty_multiplier,
)


def _diag(
    rule_id: str = "F401",
    severity: Severity = Severity.ERROR,
    category: Category = Category.QUALITY,
    file_path: str = "test.py",
    line: int = 1,
    end_line: int | None = None,
) -> Diagnostic:
    return Diagnostic(
        file_path=Path(file_path),
        line=line,
        column=0,
        severity=severity,
        rule_id=rule_id,
        tool="test",
        category=category,
        message="test",
        end_line=end_line,
    )


class TestScoreQuality:
    def test_perfect_score(self) -> None:
        assert _score_quality([], 10.0) == 100.0

    def test_errors_penalized_more(self) -> None:
        diags = [_diag(severity=Severity.ERROR)] * 10
        score_errors = _score_quality(diags, 1.0)
        diags_warn = [_diag(severity=Severity.WARNING)] * 10
        score_warnings = _score_quality(diags_warn, 1.0)
        assert score_errors < score_warnings

    def test_normalized_by_kloc(self) -> None:
        diags = [_diag()] * 10
        small = _score_quality(diags, 1.0)
        large = _score_quality(diags, 10.0)
        assert large > small

    def test_floors_at_zero(self) -> None:
        diags = [_diag()] * 1000
        assert _score_quality(diags, 1.0) == 0.0

    def test_info_not_penalized(self) -> None:
        diags = [_diag(severity=Severity.INFO)] * 100
        assert _score_quality(diags, 1.0) == 100.0

    def test_mixed_severities(self) -> None:
        diags = [
            _diag(severity=Severity.ERROR),
            _diag(severity=Severity.WARNING),
            _diag(severity=Severity.INFO),
        ]
        score = _score_quality(diags, 1.0)
        # 100 - (3*1/1) - (1*1/1) = 96
        assert score == 96.0


class TestScoreTypeSafety:
    def test_perfect_score(self) -> None:
        assert _score_type_safety([], 100) == 100.0

    def test_all_files_with_errors(self) -> None:
        diags = [
            _diag(
                category=Category.TYPE_SAFETY,
                file_path=f"f{i}.py",
            )
            for i in range(10)
        ]
        assert _score_type_safety(diags, 10) == 0.0

    def test_partial_typing(self) -> None:
        diags = [
            _diag(
                category=Category.TYPE_SAFETY,
                file_path=f"f{i}.py",
            )
            for i in range(2)
        ]
        score = _score_type_safety(diags, 10)
        assert score == 80.0

    def test_no_files(self) -> None:
        assert _score_type_safety([], 0) == 100.0

    def test_warnings_dont_count(self) -> None:
        """Only errors count against file pass rate."""
        diags = [
            _diag(
                severity=Severity.WARNING,
                category=Category.TYPE_SAFETY,
                file_path="f1.py",
            )
        ]
        assert _score_type_safety(diags, 10) == 100.0

    def test_multiple_errors_same_file(self) -> None:
        """Multiple errors in one file only count once."""
        diags = [
            _diag(
                category=Category.TYPE_SAFETY,
                file_path="f1.py",
                line=i,
            )
            for i in range(5)
        ]
        score = _score_type_safety(diags, 10)
        assert score == 90.0  # Only 1 file fails out of 10


class TestScoreSecurity:
    def test_perfect_score(self) -> None:
        assert _score_security([]) == 100.0

    def test_high_severity(self) -> None:
        diags = [
            _diag(
                severity=Severity.ERROR,
                category=Category.SECURITY,
            )
        ]
        score = _score_security(diags)
        assert score == 85.0

    def test_critical_cap(self) -> None:
        diags = [
            _diag(
                rule_id="S608",
                severity=Severity.ERROR,
                category=Category.SECURITY,
            )
        ]
        score = _score_security(diags)
        assert score == 25.0

    def test_info_severity_no_penalty(self) -> None:
        """INFO-level findings are advisory and should not penalise the score."""
        diags = [
            _diag(
                severity=Severity.INFO,
                category=Category.SECURITY,
            )
        ] * 5
        score = _score_security(diags)
        assert score == 100.0

    def test_critical_cap_overrides_penalty(self) -> None:
        """Critical cap at 25 even if penalty-based score higher."""
        diags = [
            _diag(
                rule_id="B301",
                severity=Severity.WARNING,
                category=Category.SECURITY,
            )
        ]
        # Penalty: 100 - 5 = 95, but capped at 25
        score = _score_security(diags)
        assert score == 25.0

    def test_critical_plus_other_issues(self) -> None:
        """Critical + many other issues can go below 25."""
        diags = [
            _diag(
                rule_id="S608",
                severity=Severity.ERROR,
                category=Category.SECURITY,
            )
        ] + [
            _diag(
                severity=Severity.ERROR,
                category=Category.SECURITY,
            )
        ] * 10
        score = _score_security(diags)
        # 100 - 11*15 = -65, capped at 0
        assert score == 0.0

    def test_floors_at_zero(self) -> None:
        diags = [
            _diag(
                severity=Severity.ERROR,
                category=Category.SECURITY,
            )
        ] * 20
        assert _score_security(diags) == 0.0


class TestScoreComplexity:
    def test_from_mi_scores_excellent(self) -> None:
        """MI avg 80 (>= 65) should score 100."""
        assert _score_complexity([80.0, 70.0, 90.0], []) == 100.0

    def test_from_mi_scores_good(self) -> None:
        """MI avg 42.5 (between 20 and 65) should scale linearly."""
        score = _score_complexity([40.0, 45.0], [])
        assert 75.0 <= score <= 85.0  # MI 42.5 → ~80

    def test_from_mi_scores_poor(self) -> None:
        """MI avg 10 (< 20) should score low."""
        score = _score_complexity([10.0], [])
        assert score == 30.0  # 10 * 3.0

    def test_fallback_to_diagnostics(self) -> None:
        diags = [_diag(category=Category.COMPLEXITY)] * 5
        score = _score_complexity([], diags)
        assert score == 75.0

    def test_no_data(self) -> None:
        assert _score_complexity([], []) == 100.0

    def test_mi_takes_precedence(self) -> None:
        """MI scores are used even if diagnostics exist."""
        diags = [_diag(category=Category.COMPLEXITY)] * 10
        score = _score_complexity([90.0], diags)
        assert score == 100.0

    def test_mi_clamped(self) -> None:
        """MI scores above 100 clamped."""
        assert _score_complexity([120.0], []) == 100.0


class TestScoreDeadCode:
    def test_no_dead_code(self) -> None:
        assert _score_dead_code([], 1000) == 100.0

    def test_ten_percent_dead(self) -> None:
        diags = [
            _diag(
                category=Category.DEAD_CODE,
                line=1,
                end_line=100,
            )
        ]
        score = _score_dead_code(diags, 1000)
        assert score == 80.0

    def test_fifty_percent_dead(self) -> None:
        diags = [
            _diag(
                category=Category.DEAD_CODE,
                line=1,
                end_line=500,
            )
        ]
        score = _score_dead_code(diags, 1000)
        assert score == 0.0

    def test_no_files(self) -> None:
        assert _score_dead_code([], 0) == 100.0

    def test_single_line_dead_code(self) -> None:
        """Diagnostics without end_line count as 1 line."""
        diags = [_diag(category=Category.DEAD_CODE, line=5)] * 10
        score = _score_dead_code(diags, 1000)
        # 10/1000 = 1%, penalty = 2% -> score = 98
        assert score == 98.0


class TestScoreDependencies:
    def test_no_issues(self) -> None:
        assert _score_dependencies([]) == 100.0

    def test_vulnerability(self) -> None:
        diags = [
            _diag(
                rule_id="CVE-2024-1234",
                category=Category.DEPENDENCIES,
            )
        ]
        assert _score_dependencies(diags) == 90.0

    def test_unused_dep(self) -> None:
        diags = [
            _diag(
                rule_id="DEP002",
                category=Category.DEPENDENCIES,
            )
        ]
        assert _score_dependencies(diags) == 95.0

    def test_missing_dep(self) -> None:
        diags = [
            _diag(
                rule_id="DEP001",
                category=Category.DEPENDENCIES,
            )
        ]
        assert _score_dependencies(diags) == 97.0

    def test_transitive_dep(self) -> None:
        diags = [
            _diag(
                rule_id="DEP003",
                category=Category.DEPENDENCIES,
            )
        ]
        assert _score_dependencies(diags) == 98.0

    def test_ghsa_vulnerability(self) -> None:
        diags = [
            _diag(
                rule_id="GHSA-xxxx-yyyy",
                category=Category.DEPENDENCIES,
            )
        ]
        assert _score_dependencies(diags) == 90.0

    def test_floors_at_zero(self) -> None:
        diags = [
            _diag(
                rule_id="CVE-2024-0001",
                category=Category.DEPENDENCIES,
            )
        ] * 20
        assert _score_dependencies(diags) == 0.0


class TestRedistributeWeights:
    def test_all_categories(self) -> None:
        result = redistribute_weights(
            DEFAULT_WEIGHTS,
            {
                Category.QUALITY,
                Category.TYPE_SAFETY,
                Category.SECURITY,
                Category.COMPLEXITY,
                Category.DEAD_CODE,
                Category.DEPENDENCIES,
            },
        )
        assert sum(result.values()) == 100

    def test_single_category(self) -> None:
        result = redistribute_weights(DEFAULT_WEIGHTS, {Category.QUALITY})
        assert result[Category.QUALITY] == 100

    def test_two_categories(self) -> None:
        result = redistribute_weights(
            DEFAULT_WEIGHTS,
            {Category.QUALITY, Category.SECURITY},
        )
        assert sum(result.values()) == 100
        # quality=20, security=20 → equal weights redistribute to 50/50
        assert result[Category.QUALITY] == result[Category.SECURITY]

    def test_empty(self) -> None:
        result = redistribute_weights(DEFAULT_WEIGHTS, set())
        assert result == {}

    def test_weights_proportional(self) -> None:
        """Removed categories redistribute proportionally."""
        result = redistribute_weights(
            DEFAULT_WEIGHTS,
            {Category.QUALITY, Category.TYPE_SAFETY},
        )
        # quality=20, types=20, total=40 → equal → 50/50
        assert result[Category.QUALITY] + result[Category.TYPE_SAFETY] == 100
        assert result[Category.QUALITY] == result[Category.TYPE_SAFETY]


class TestComputeHealthReport:
    def _project(self, total_files: int = 50, total_lines: int = 5000) -> ProjectInfo:
        return ProjectInfo("3.12", None, total_files, total_lines)

    def test_empty_project(self) -> None:
        report = compute_health_report(
            diagnostics=[],
            project=ProjectInfo("3.12", None, 0, 0),
            config=CheckupConfig(),
            duration_ms=100,
            analyzers_used=["ruff"],
            analyzers_skipped=[],
        )
        assert report.score == 100
        assert report.label == "Healthy"

    def test_deterministic(self) -> None:
        diags = [_diag()] * 10
        project = self._project()
        r1 = compute_health_report(diags, project, CheckupConfig(), 100, ["ruff"], [])
        r2 = compute_health_report(diags, project, CheckupConfig(), 200, ["ruff"], [])
        assert r1.score == r2.score

    def test_label_healthy(self) -> None:
        config = CheckupConfig(thresholds={"healthy": 80, "needs_work": 60})
        r = compute_health_report(
            [],
            self._project(),
            config,
            100,
            ["ruff"],
            [],
        )
        assert r.label == "Healthy"

    def test_label_needs_work(self) -> None:
        """Many errors should produce 'Needs work' label."""
        config = CheckupConfig(thresholds={"healthy": 80, "needs_work": 60})
        # Create enough errors to drop quality below 80
        # With 5 KLOC, need many errors to drop below 80
        diags = [_diag()] * 200
        r = compute_health_report(
            diags,
            self._project(),
            config,
            100,
            ["ruff"],
            [],
        )
        assert r.label == "Needs work" or r.label == "Critical"

    def test_label_critical(self) -> None:
        config = CheckupConfig(thresholds={"healthy": 80, "needs_work": 60})
        # Flood all ruff-covered categories so overall score drops below 60
        diags = (
            [_diag(category=Category.QUALITY)] * 10000
            + [_diag(category=Category.SECURITY)] * 100
            + [_diag(category=Category.COMPLEXITY)] * 100
        )
        r = compute_health_report(
            diags,
            self._project(),
            config,
            100,
            ["ruff"],
            [],
        )
        assert r.label == "Critical"

    def test_scores_sorted_by_weight(self) -> None:
        """Category scores are sorted by weight, descending."""
        r = compute_health_report(
            [],
            self._project(),
            CheckupConfig(),
            100,
            ["ruff", "mypy", "bandit", "radon", "vulture"],
            [],
        )
        weights = [cs.weight for cs in r.category_scores]
        assert weights == sorted(weights, reverse=True)

    def test_mi_scores_used(self) -> None:
        """MI scores affect complexity scoring."""
        project = self._project()
        r_no_mi = compute_health_report(
            [],
            project,
            CheckupConfig(),
            100,
            ["radon"],
            [],
            mi_scores=None,
        )
        r_low_mi = compute_health_report(
            [],
            project,
            CheckupConfig(),
            100,
            ["radon"],
            [],
            mi_scores=[30.0, 40.0],
        )
        # Without MI: complexity defaults to 100 (no diagnostics)
        # With low MI: complexity around 35
        cs_no_mi = next(
            cs for cs in r_no_mi.category_scores if cs.category == Category.COMPLEXITY
        )
        cs_low_mi = next(
            cs for cs in r_low_mi.category_scores if cs.category == Category.COMPLEXITY
        )
        assert cs_no_mi.score > cs_low_mi.score

    def test_analyzers_in_report(self) -> None:
        r = compute_health_report(
            [],
            self._project(),
            CheckupConfig(),
            100,
            ["ruff", "mypy"],
            ["bandit"],
        )
        assert r.analyzers_used == ["ruff", "mypy"]
        assert r.analyzers_skipped == ["bandit"]

    def test_custom_thresholds(self) -> None:
        """Custom thresholds from config are respected."""
        config = CheckupConfig(thresholds={"healthy": 95, "needs_work": 90})
        r = compute_health_report(
            [_diag()],
            self._project(),
            config,
            100,
            ["ruff"],
            [],
        )
        # With a stricter threshold, even a small penalty
        # can drop below "Healthy"
        assert r.score < 100


class TestCriticalRules:
    def test_critical_rules_exist(self) -> None:
        """Critical rules set is populated."""
        assert len(CRITICAL_RULES) > 0

    def test_sql_injection_is_critical(self) -> None:
        assert "S608" in CRITICAL_RULES
        assert "B608" in CRITICAL_RULES

    def test_pickle_is_critical(self) -> None:
        assert "S301" in CRITICAL_RULES
        assert "B301" in CRITICAL_RULES


# ---------------------------------------------------------------------------
# Phase 5: Framework-aware scoring (ScoringContext + penalty multipliers)
# ---------------------------------------------------------------------------


def _fw_stack(name: str = "django") -> FrameworkStack:
    fw = FrameworkInfo(
        name=name,
        version="5.1",
        confidence=0.9,
        category=FrameworkCategory.WEB,
        stubs_package=f"{name}-stubs",
    )
    return FrameworkStack(primary=fw, companions=[], all_frameworks=[fw])


def _type_diag(
    message: str = (
        "Cannot find implementation or library stub for module named 'django'"
    ),
    tool: str = "mypy",
) -> Diagnostic:
    return Diagnostic(
        file_path=Path("app.py"),
        line=1,
        column=0,
        severity=Severity.ERROR,
        rule_id="import-error",
        tool=tool,
        category=Category.TYPE_SAFETY,
        message=message,
    )


def _fw_diag(
    rule_id: str = "FW-DJ-001", severity: Severity = Severity.ERROR
) -> Diagnostic:
    return Diagnostic(
        file_path=Path("settings.py"),
        line=1,
        column=0,
        severity=severity,
        rule_id=rule_id,
        tool="framework-checks",
        category=Category.SECURITY,
        message="DEBUG = True",
    )


class TestScoringContext:
    def test_no_stack_always_full_penalty(self) -> None:
        ctx = ScoringContext(
            framework_stack=None, stubs_installed={}, whitelist_suppressed=0
        )
        d = _type_diag()
        assert compute_penalty_multiplier(d, ctx) == 1.0

    def test_mypy_error_without_stubs_reduced_penalty(self) -> None:
        ctx = ScoringContext(
            framework_stack=_fw_stack("django"),
            stubs_installed={"django": False},
            whitelist_suppressed=0,
        )
        d = _type_diag()
        assert compute_penalty_multiplier(d, ctx) == 0.3

    def test_mypy_error_with_stubs_full_penalty(self) -> None:
        ctx = ScoringContext(
            framework_stack=_fw_stack("django"),
            stubs_installed={"django": True},
            whitelist_suppressed=0,
        )
        d = _type_diag()
        assert compute_penalty_multiplier(d, ctx) == 1.0

    def test_fw_info_advisory_half_penalty(self) -> None:
        ctx = ScoringContext(
            framework_stack=_fw_stack("django"),
            stubs_installed={},
            whitelist_suppressed=0,
        )
        d = _fw_diag("FW-DJ-050", Severity.INFO)
        assert compute_penalty_multiplier(d, ctx) == 0.5

    def test_fw_error_full_penalty(self) -> None:
        ctx = ScoringContext(
            framework_stack=_fw_stack("django"),
            stubs_installed={},
            whitelist_suppressed=0,
        )
        d = _fw_diag("FW-DJ-001", Severity.ERROR)
        assert compute_penalty_multiplier(d, ctx) == 1.0

    def test_non_framework_mypy_full_penalty(self) -> None:
        ctx = ScoringContext(
            framework_stack=_fw_stack("django"),
            stubs_installed={"django": False},
            whitelist_suppressed=0,
        )
        # Error message doesn't mention django — still full penalty
        d = _type_diag("Incompatible return value type (got 'int', expected 'str')")
        assert compute_penalty_multiplier(d, ctx) == 1.0


class TestPenaltyMultiplierInScoring:
    """Verify scoring functions use the multiplier when context is provided."""

    def test_quality_score_higher_with_context(self) -> None:
        # FW-* INFO diagnostic has 0.5 multiplier — same errors yield higher score
        diag = _fw_diag("FW-DJ-050", Severity.WARNING)
        diag_quality = Diagnostic(
            file_path=diag.file_path,
            line=1,
            column=0,
            severity=Severity.WARNING,
            rule_id="FW-DJ-050",
            tool="framework-checks",
            category=Category.QUALITY,
            message="test",
        )
        ctx = ScoringContext(
            framework_stack=_fw_stack("django"),
            stubs_installed={},
            whitelist_suppressed=0,
        )
        # FW-DJ-050 is WARNING so multiplier is 1.0 (only INFO gets 0.5)
        score_with = _score_quality([diag_quality], 1.0, ctx)
        score_without = _score_quality([diag_quality], 1.0, None)
        # Same penalty since WARNING FW-* doesn't get reduced
        assert score_with == score_without

    def test_type_safety_score_with_stub_gap(self) -> None:
        # Use distinct files so the "without context" path counts 5 unique error files
        diags = [
            Diagnostic(
                file_path=Path(f"file{i}.py"),
                line=1,
                column=0,
                severity=Severity.ERROR,
                rule_id="import-error",
                tool="mypy",
                category=Category.TYPE_SAFETY,
                message=(
                    "Cannot find implementation or library stub"
                    " for module named 'django'"
                ),
            )
            for i in range(5)
        ]
        ctx = ScoringContext(
            framework_stack=_fw_stack("django"),
            stubs_installed={"django": False},
            whitelist_suppressed=0,
        )
        score_with = _score_type_safety(diags, 10, ctx)
        score_without = _score_type_safety(diags, 10, None)
        # With context: 5 errors × 0.3 multiplier = 1.5 effective error files → score 85
        # Without context: 5 distinct error files → pass_rate 50%
        assert score_with > score_without

    def test_security_score_same_for_critical(self) -> None:
        # Critical rules should still cap at 25 regardless of context
        d = _diag(rule_id="B608", severity=Severity.ERROR, category=Category.SECURITY)
        ctx = ScoringContext(
            framework_stack=_fw_stack(), stubs_installed={}, whitelist_suppressed=0
        )
        score = _score_security([d], ctx)
        assert score <= 25.0
