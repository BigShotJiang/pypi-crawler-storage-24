from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock

import pytest

from python_checkup.analysis_request import AnalysisRequest
from python_checkup.analyzers.cached import CachedAnalyzer
from python_checkup.cache import AnalysisCache
from python_checkup.models import Category, Diagnostic, Severity
from python_checkup.plan import PROFILE_DEFAULT


@pytest.fixture
def mock_analyzer() -> AsyncMock:
    analyzer = AsyncMock()
    analyzer.name = "ruff"
    analyzer.category = Category.QUALITY
    analyzer.is_available.return_value = True
    return analyzer


@pytest.fixture
def cache(tmp_path: Path) -> AnalysisCache:
    return AnalysisCache(tmp_path, enabled=True)


@pytest.fixture
def python_files(tmp_path: Path) -> list[Path]:
    files = []
    for i in range(5):
        f = tmp_path / f"module_{i}.py"
        f.write_text(f"# module {i}\ndef func_{i}():\n    pass\n")
        files.append(f)
    return files


def _make_diagnostic(file_path: Path, rule_id: str = "F401") -> Diagnostic:
    return Diagnostic(
        file_path=file_path,
        line=1,
        column=1,
        severity=Severity.ERROR,
        rule_id=rule_id,
        tool="ruff",
        category=Category.QUALITY,
        message="test diagnostic",
    )


def _make_request(tmp_path: Path, files: list[Path]) -> AnalysisRequest:
    from python_checkup.config import CheckupConfig
    from python_checkup.models import Category

    return AnalysisRequest(
        project_root=tmp_path,
        files=files,
        config=CheckupConfig(),
        categories={Category.QUALITY},
        profile=PROFILE_DEFAULT,
    )


class TestCachedAnalyzer:
    @pytest.mark.asyncio
    async def test_cold_run_calls_analyzer(
        self,
        mock_analyzer: AsyncMock,
        cache: AnalysisCache,
        python_files: list[Path],
    ) -> None:
        """First run: all files should be sent to the analyzer."""
        diagnostics = [_make_diagnostic(python_files[0])]
        mock_analyzer.analyze.return_value = diagnostics

        cached = CachedAnalyzer(mock_analyzer, cache)
        request = _make_request(cache.project_root, python_files)
        result = await cached.analyze(request)

        called_request = mock_analyzer.analyze.call_args[0][0]
        assert called_request.files == python_files
        assert len(result) == 1

    @pytest.mark.asyncio
    async def test_warm_run_uses_cache(
        self,
        mock_analyzer: AsyncMock,
        cache: AnalysisCache,
        python_files: list[Path],
    ) -> None:
        """Second run on unchanged files: analyzer should NOT be called."""
        diagnostics = [_make_diagnostic(python_files[0])]
        mock_analyzer.analyze.return_value = diagnostics

        cached = CachedAnalyzer(mock_analyzer, cache)
        request = _make_request(cache.project_root, python_files)

        # First run -- populates cache
        await cached.analyze(request)
        assert mock_analyzer.analyze.call_count == 1

        # Second run -- should use cache
        result = await cached.analyze(request)
        assert mock_analyzer.analyze.call_count == 1  # NOT called again
        assert len(result) == 1

    @pytest.mark.asyncio
    async def test_partial_cache_hit(
        self,
        mock_analyzer: AsyncMock,
        cache: AnalysisCache,
        python_files: list[Path],
    ) -> None:
        """Modified files should be re-analyzed, unchanged files use cache."""
        diagnostics = [_make_diagnostic(python_files[0])]
        mock_analyzer.analyze.return_value = diagnostics

        cached = CachedAnalyzer(mock_analyzer, cache)
        request = _make_request(cache.project_root, python_files)

        # First run -- populates cache for all files
        await cached.analyze(request)

        # Modify one file
        python_files[2].write_text("# modified content\ndef new_func(): pass\n")

        # Set up mock for the second call (only the modified file)
        new_diagnostic = _make_diagnostic(python_files[2], "E501")
        mock_analyzer.analyze.return_value = [new_diagnostic]

        result = await cached.analyze(request)

        # Analyzer should be called with ONLY the modified file
        second_call_args = mock_analyzer.analyze.call_args_list[-1]
        uncached_files = second_call_args[0][0].files
        assert len(uncached_files) == 1
        assert uncached_files[0] == python_files[2]

        # Results should include both cached and fresh diagnostics
        assert len(result) == 2  # 1 from cache + 1 fresh

    @pytest.mark.asyncio
    async def test_clean_files_cached_as_empty(
        self,
        mock_analyzer: AsyncMock,
        cache: AnalysisCache,
        python_files: list[Path],
    ) -> None:
        """Files with no issues should be cached as empty list."""
        mock_analyzer.analyze.return_value = []

        cached = CachedAnalyzer(mock_analyzer, cache)
        request = _make_request(cache.project_root, python_files)

        # First run
        result = await cached.analyze(request)
        assert result == []
        assert mock_analyzer.analyze.call_count == 1

        # Second run -- all files cached (as empty)
        result = await cached.analyze(request)
        assert result == []
        assert mock_analyzer.analyze.call_count == 1  # NOT called again

    @pytest.mark.asyncio
    async def test_properties_delegate(
        self,
        mock_analyzer: AsyncMock,
        cache: AnalysisCache,
    ) -> None:
        cached = CachedAnalyzer(mock_analyzer, cache)
        assert cached.name == "ruff"
        assert cached.category == Category.QUALITY
