"""Tests for framework-aware Vulture whitelist suppression (Phase 2)."""

from __future__ import annotations

from pathlib import Path

from python_checkup.analyzers.vulture_whitelists import (
    WhitelistEntry,
    apply_framework_whitelists,
    find_decorated_names,
    get_whitelists_for_stack,
)
from python_checkup.detection import FrameworkCategory, FrameworkInfo, FrameworkStack
from python_checkup.models import Category, Diagnostic, Severity


def _make_vulture_diagnostic(
    name: str,
    item_type: str = "function",
    file_path: str = "app.py",
    line: int = 1,
) -> Diagnostic:
    """Build a synthetic Vulture-style Diagnostic."""
    return Diagnostic(
        file_path=Path(file_path),
        line=line,
        column=0,
        severity=Severity.WARNING,
        rule_id=f"V-{item_type}",
        tool="vulture",
        category=Category.DEAD_CODE,
        message=f"Unused {item_type}: '{name}' (80% confidence)",
    )


def _make_stack(*names: str) -> FrameworkStack:
    """Build a FrameworkStack with the given framework names."""
    fws = [
        FrameworkInfo(
            name=n, version=None, confidence=0.8, category=FrameworkCategory.WEB
        )
        for n in names
    ]
    return FrameworkStack(
        primary=fws[0] if fws else None,
        companions=fws[1:],
        all_frameworks=fws,
    )


# ---------------------------------------------------------------------------
# WhitelistEntry.matches
# ---------------------------------------------------------------------------


class TestWhitelistEntryMatches:
    def test_exact_name_match(self) -> None:
        entry = WhitelistEntry(name_pattern="Meta", item_type="class", reason="test")
        assert entry.matches("Meta", "class")
        assert not entry.matches("NotMeta", "class")

    def test_regex_name_match(self) -> None:
        entry = WhitelistEntry(
            name_pattern=r"get_.*|set_.*", item_type=None, reason="test"
        )
        assert entry.matches("get_queryset", "function")
        assert entry.matches("set_cache", "attribute")
        assert not entry.matches("fetch_data", "function")

    def test_item_type_filter(self) -> None:
        entry = WhitelistEntry(name_pattern=".*", item_type="function", reason="test")
        assert entry.matches("anything", "function")
        assert not entry.matches("anything", "class")

    def test_item_type_none_matches_any(self) -> None:
        entry = WhitelistEntry(name_pattern="model", item_type=None, reason="test")
        assert entry.matches("model", "attribute")
        assert entry.matches("model", "function")
        assert entry.matches("model", "variable")

    def test_parent_pattern_filter(self) -> None:
        entry = WhitelistEntry(
            name_pattern="handle",
            item_type="function",
            parent_pattern="Command",
            reason="test",
        )
        assert entry.matches("handle", "function", parent="Command")
        assert not entry.matches("handle", "function", parent="SomethingElse")
        assert not entry.matches("handle", "function", parent=None)


# ---------------------------------------------------------------------------
# get_whitelists_for_stack
# ---------------------------------------------------------------------------


class TestGetWhitelistsForStack:
    def test_empty_stack_returns_empty(self) -> None:
        stack = FrameworkStack(primary=None, companions=[], all_frameworks=[])
        assert get_whitelists_for_stack(stack) == []

    def test_django_stack_returns_entries(self) -> None:
        stack = _make_stack("django")
        entries = get_whitelists_for_stack(stack)
        assert len(entries) > 0
        # Should contain the Meta class entry
        meta_entries = [e for e in entries if e.name_pattern == "Meta"]
        assert meta_entries

    def test_no_duplicate_entries_for_drf_and_django(self) -> None:
        """drf reuses Django whitelist — must not double-count."""
        stack = _make_stack("django", "drf")
        entries_django_only = get_whitelists_for_stack(_make_stack("django"))
        entries_both = get_whitelists_for_stack(stack)
        # Should be the same length (deduplicated)
        assert len(entries_both) == len(entries_django_only)


# ---------------------------------------------------------------------------
# apply_framework_whitelists
# ---------------------------------------------------------------------------


class TestApplyFrameworkWhitelists:
    def test_django_meta_class_suppressed(self, tmp_path: Path) -> None:
        d = _make_vulture_diagnostic("Meta", item_type="class")
        stack = _make_stack("django")
        filtered, suppressed, details = apply_framework_whitelists([d], stack, [])
        assert suppressed == 1
        assert filtered == []
        assert details[0]["name"] == "Meta"

    def test_django_get_queryset_suppressed(self, tmp_path: Path) -> None:
        d = _make_vulture_diagnostic("get_queryset", item_type="function")
        stack = _make_stack("django")
        filtered, suppressed, details = apply_framework_whitelists([d], stack, [])
        assert suppressed == 1
        assert details[0]["reason"]

    def test_django_urlpatterns_suppressed(self, tmp_path: Path) -> None:
        d = _make_vulture_diagnostic("urlpatterns", item_type="variable")
        stack = _make_stack("django")
        filtered, suppressed, _details = apply_framework_whitelists([d], stack, [])
        assert suppressed == 1

    def test_real_dead_code_not_suppressed(self, tmp_path: Path) -> None:
        d = _make_vulture_diagnostic("_my_truly_unused_helper", item_type="function")
        stack = _make_stack("django")
        filtered, suppressed, details = apply_framework_whitelists([d], stack, [])
        assert suppressed == 0
        assert filtered == [d]
        assert details == []

    def test_empty_stack_returns_all(self, tmp_path: Path) -> None:
        d = _make_vulture_diagnostic("Meta", item_type="class")
        stack = FrameworkStack(primary=None, companions=[], all_frameworks=[])
        filtered, suppressed, details = apply_framework_whitelists([d], stack, [])
        assert suppressed == 0
        assert len(filtered) == 1
        assert details == []

    def test_multiple_diagnostics_mixed_suppression(self) -> None:
        diags = [
            _make_vulture_diagnostic("Meta", item_type="class"),  # suppressed
            _make_vulture_diagnostic(
                "get_queryset", item_type="function"
            ),  # suppressed
            _make_vulture_diagnostic("orphaned_helper", item_type="function"),  # kept
        ]
        stack = _make_stack("django")
        filtered, suppressed, details = apply_framework_whitelists(diags, stack, [])
        assert suppressed == 2
        assert len(filtered) == 1
        assert filtered[0].message == diags[2].message
        assert len(details) == 2

    def test_parent_pattern_management_command_suppressed(self, tmp_path: Path) -> None:
        command_file = tmp_path / "management_command.py"
        command_file.write_text(
            "class Command:\n"
            "    help = 'Import articles'\n"
            "\n"
            "    def handle(self, *args, **options):\n"
            "        return None\n"
        )
        diag = _make_vulture_diagnostic(
            "handle",
            item_type="method",
            file_path=str(command_file),
            line=4,
        )
        stack = _make_stack("django")
        filtered, suppressed, details = apply_framework_whitelists(
            [diag],
            stack,
            [command_file],
        )
        assert filtered == []
        assert suppressed == 1
        assert details[0]["parent"] == "Command"
        assert "management command" in str(details[0]["reason"]).lower()


# ---------------------------------------------------------------------------
# find_decorated_names
# ---------------------------------------------------------------------------


class TestFindDecoratedNames:
    def test_flask_route_decorator(self, tmp_path: Path) -> None:
        f = tmp_path / "views.py"
        f.write_text("@app.route('/')\n" "def index():\n" "    return 'hello'\n")
        names = find_decorated_names(f, {"flask"})
        assert "index" in names

    def test_celery_shared_task_decorator(self, tmp_path: Path) -> None:
        f = tmp_path / "tasks.py"
        f.write_text("@shared_task\n" "def send_email(to):\n" "    pass\n")
        names = find_decorated_names(f, {"celery"})
        assert "send_email" in names

    def test_django_receiver_decorator(self, tmp_path: Path) -> None:
        f = tmp_path / "signals.py"
        f.write_text(
            "from django.dispatch import receiver\n"
            "@receiver(post_save, sender=User)\n"
            "def handle_save(sender, **kwargs):\n"
            "    pass\n"
        )
        names = find_decorated_names(f, {"django"})
        assert "handle_save" in names

    def test_unrelated_decorator_not_protected(self, tmp_path: Path) -> None:
        f = tmp_path / "utils.py"
        f.write_text("@my_custom_decorator\n" "def helper():\n" "    pass\n")
        names = find_decorated_names(f, {"django"})
        assert "helper" not in names

    def test_empty_framework_set_returns_empty(self, tmp_path: Path) -> None:
        f = tmp_path / "app.py"
        f.write_text("@app.route('/')\ndef index(): pass\n")
        names = find_decorated_names(f, set())
        assert names == set()

    def test_syntax_error_returns_empty(self, tmp_path: Path) -> None:
        f = tmp_path / "broken.py"
        f.write_text("def broken syntax !!!\n")
        names = find_decorated_names(f, {"flask"})
        assert names == set()

    def test_pytest_fixture_detected(self, tmp_path: Path) -> None:
        f = tmp_path / "conftest.py"
        f.write_text(
            "import pytest\n"
            "@pytest.fixture\n"
            "def client(app):\n"
            "    return app.test_client()\n"
        )
        names = find_decorated_names(f, {"pytest"})
        assert "client" in names
