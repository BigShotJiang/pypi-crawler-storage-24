from __future__ import annotations

import json
from pathlib import Path

import pytest

from python_checkup.cache import (
    CACHE_VERSION,
    AnalysisCache,
    _deserialize_diagnostic,
    _serialize_diagnostic,
)
from python_checkup.models import Category, Diagnostic, Severity


@pytest.fixture
def cache(tmp_path: Path) -> AnalysisCache:
    """Create a cache in a temp directory."""
    return AnalysisCache(tmp_path, enabled=True)


@pytest.fixture
def sample_diagnostic() -> Diagnostic:
    return Diagnostic(
        file_path=Path("src/app.py"),
        line=10,
        column=5,
        severity=Severity.ERROR,
        rule_id="F401",
        tool="ruff",
        category=Category.QUALITY,
        message="'os' imported but unused",
        fix="Remove unused import: `os`",
    )


@pytest.fixture
def python_file(tmp_path: Path) -> Path:
    """Create a Python file for cache testing."""
    f = tmp_path / "src" / "app.py"
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_text("import os\n\ndef main():\n    pass\n")
    return f


class TestAnalysisCache:
    def test_cache_dir_created(self, tmp_path: Path) -> None:
        AnalysisCache(tmp_path)
        assert (tmp_path / ".python-checkup-cache" / CACHE_VERSION).is_dir()

    def test_gitignore_created(self, tmp_path: Path) -> None:
        AnalysisCache(tmp_path)
        gitignore = tmp_path / ".python-checkup-cache" / ".gitignore"
        assert gitignore.exists()
        assert gitignore.read_text() == "*\n"

    def test_cache_miss(self, cache: AnalysisCache, python_file: Path) -> None:
        result = cache.get("ruff", python_file)
        assert result is None

    def test_cache_hit(
        self,
        cache: AnalysisCache,
        python_file: Path,
        sample_diagnostic: Diagnostic,
    ) -> None:
        # Store diagnostics
        cache.set("ruff", python_file, [sample_diagnostic])

        # Retrieve -- should hit
        result = cache.get("ruff", python_file)
        assert result is not None
        assert len(result) == 1
        assert result[0].rule_id == "F401"
        assert result[0].message == "'os' imported but unused"

    def test_cache_empty_list(self, cache: AnalysisCache, python_file: Path) -> None:
        """Empty list means 'analyzed, no issues' -- not a cache miss."""
        cache.set("ruff", python_file, [])
        result = cache.get("ruff", python_file)
        assert result is not None
        assert result == []

    def test_cache_invalidation_on_change(
        self,
        cache: AnalysisCache,
        python_file: Path,
        sample_diagnostic: Diagnostic,
    ) -> None:
        # Cache for original content
        cache.set("ruff", python_file, [sample_diagnostic])
        assert cache.get("ruff", python_file) is not None

        # Modify the file
        python_file.write_text("import sys\n\ndef main():\n    pass\n")

        # Should be a cache miss (content hash changed)
        assert cache.get("ruff", python_file) is None

    def test_different_analyzers_independent(
        self,
        cache: AnalysisCache,
        python_file: Path,
        sample_diagnostic: Diagnostic,
    ) -> None:
        """Each analyzer has its own cache namespace."""
        cache.set("ruff", python_file, [sample_diagnostic])
        cache.set("bandit", python_file, [])

        ruff_result = cache.get("ruff", python_file)
        bandit_result = cache.get("bandit", python_file)

        assert ruff_result is not None and len(ruff_result) == 1
        assert bandit_result is not None and len(bandit_result) == 0

    def test_cache_stats(
        self,
        cache: AnalysisCache,
        python_file: Path,
        sample_diagnostic: Diagnostic,
    ) -> None:
        cache.set("ruff", python_file, [sample_diagnostic])

        # 1 hit
        cache.get("ruff", python_file)
        # 1 miss (different analyzer)
        cache.get("bandit", python_file)

        stats = cache.get_stats()
        assert stats["hits"] == 1
        assert stats["misses"] == 1
        assert stats["hit_rate_pct"] == 50

    def test_clear(
        self,
        cache: AnalysisCache,
        python_file: Path,
        sample_diagnostic: Diagnostic,
    ) -> None:
        cache.set("ruff", python_file, [sample_diagnostic])
        assert cache.get("ruff", python_file) is not None

        count = cache.clear()
        assert count >= 1
        # Need a fresh miss after clearing (reset stats to avoid confusion)
        cache._hits = 0
        cache._misses = 0
        assert cache.get("ruff", python_file) is None

    def test_disabled_cache(self, tmp_path: Path, python_file: Path) -> None:
        cache = AnalysisCache(tmp_path, enabled=False)
        cache.set("ruff", python_file, [])
        assert cache.get("ruff", python_file) is None

    def test_corrupted_cache_entry(
        self, cache: AnalysisCache, python_file: Path
    ) -> None:
        """Corrupted cache files should be treated as misses."""
        # Write valid data first
        cache.set("ruff", python_file, [])
        # Find and corrupt the cache file
        for f in cache.cache_dir.glob("*.json"):
            f.write_text("NOT VALID JSON {{{")

        result = cache.get("ruff", python_file)
        # Should be treated as a miss, not raise an error
        assert result is None


class TestSerialization:
    def test_roundtrip(self, sample_diagnostic: Diagnostic) -> None:
        serialized = _serialize_diagnostic(sample_diagnostic)
        deserialized = _deserialize_diagnostic(serialized)

        assert deserialized.file_path == sample_diagnostic.file_path
        assert deserialized.line == sample_diagnostic.line
        assert deserialized.column == sample_diagnostic.column
        assert deserialized.severity == sample_diagnostic.severity
        assert deserialized.rule_id == sample_diagnostic.rule_id
        assert deserialized.tool == sample_diagnostic.tool
        assert deserialized.category == sample_diagnostic.category
        assert deserialized.message == sample_diagnostic.message
        assert deserialized.fix == sample_diagnostic.fix

    def test_roundtrip_optional_fields_none(self) -> None:
        d = Diagnostic(
            file_path=Path("test.py"),
            line=1,
            column=0,
            severity=Severity.INFO,
            rule_id="I001",
            tool="test",
            category=Category.QUALITY,
            message="info",
        )
        serialized = _serialize_diagnostic(d)
        deserialized = _deserialize_diagnostic(serialized)
        assert deserialized.fix is None
        assert deserialized.help_url is None
        assert deserialized.end_line is None

    def test_json_compatibility(self, sample_diagnostic: Diagnostic) -> None:
        """Ensure serialized form is valid JSON."""
        serialized = _serialize_diagnostic(sample_diagnostic)
        json_str = json.dumps(serialized, default=str)
        parsed = json.loads(json_str)
        deserialized = _deserialize_diagnostic(parsed)
        assert deserialized.rule_id == sample_diagnostic.rule_id
