from __future__ import annotations

import json
from pathlib import Path
from typing import Any, cast
from unittest.mock import patch

import pytest

from python_checkup.analysis_request import AnalysisRequest
from python_checkup.analyzers.mypy import (
    MypyAnalyzer,
    _configured_mypy_plugins,
    _map_mypy_severity,
    _parse_mypy_fatal_errors,
)
from python_checkup.config import CheckupConfig
from python_checkup.detection import FrameworkCategory, FrameworkInfo, FrameworkStack
from python_checkup.models import Category, Severity

SAMPLE_MYPY_JSON_OUTPUT = "\n".join(
    [
        json.dumps(
            {
                "file": "/tmp/test/src/app.py",
                "line": 5,
                "column": 12,
                "end_line": 5,
                "end_column": 14,
                "message": 'Incompatible return value type (got "int", expected "str")',
                "hint": None,
                "code": "return-value",
                "severity": "error",
            }
        ),
        json.dumps(
            {
                "file": "/tmp/test/src/app.py",
                "line": 12,
                "column": 8,
                "end_line": 12,
                "end_column": 19,
                "message": (
                    "Incompatible types in assignment"
                    ' (expression has type "str",'
                    ' variable has type "int")'
                ),
                "hint": None,
                "code": "assignment",
                "severity": "error",
            }
        ),
    ]
)


def _request(files: list[Path]) -> AnalysisRequest:
    root = files[0].parent if files else Path(".")
    return AnalysisRequest(
        project_root=root,
        files=files,
        config=CheckupConfig(),
        categories={Category.TYPE_SAFETY},
        profile="default",
    )


def _stack(*framework_names: str) -> FrameworkStack:
    frameworks = [
        FrameworkInfo(
            name=name,
            version=None,
            confidence=1.0,
            category=(
                (FrameworkCategory.WEB if name == "django" else FrameworkCategory.ORM)
                if name in {"django", "sqlalchemy"}
                else FrameworkCategory.VALIDATION
            ),
        )
        for name in framework_names
    ]
    return FrameworkStack(
        primary=frameworks[0] if frameworks else None,
        companions=frameworks[1:],
        all_frameworks=frameworks,
    )


class TestMypyAnalyzer:
    async def test_name_and_category(self) -> None:
        analyzer = MypyAnalyzer()
        assert analyzer.name == "mypy"
        assert analyzer.category == Category.TYPE_SAFETY

    @patch.object(MypyAnalyzer, "_run_mypy")
    async def test_analyze_with_json_results(self, mock_run: object) -> None:
        cast(Any, mock_run).return_value = (SAMPLE_MYPY_JSON_OUTPUT, "", 1)

        analyzer = MypyAnalyzer()
        results = await analyzer.analyze(_request([Path("/tmp/test/src/app.py")]))

        assert len(results) == 2
        assert results[0].rule_id == "mypy-return-value"
        assert results[0].severity == Severity.ERROR
        assert results[0].category == Category.TYPE_SAFETY
        assert "Incompatible return value" in results[0].message

        assert results[1].rule_id == "mypy-assignment"

    @patch.object(MypyAnalyzer, "_run_mypy")
    async def test_analyze_clean_project(self, mock_run: object) -> None:
        cast(Any, mock_run).return_value = ("", "", 0)

        analyzer = MypyAnalyzer()
        results = await analyzer.analyze(_request([Path("/tmp/test/src/app.py")]))
        assert results == []

    @patch.object(MypyAnalyzer, "_run_mypy")
    async def test_analyze_fatal_error(self, mock_run: object) -> None:
        cast(Any, mock_run).return_value = ("", "fatal: cannot find module", 2)

        analyzer = MypyAnalyzer()
        results = await analyzer.analyze(_request([Path("/tmp/test/src/app.py")]))
        assert results == []

    async def test_analyze_empty_files(self) -> None:
        analyzer = MypyAnalyzer()
        results = await analyzer.analyze(_request([]))
        assert results == []

    @patch.object(MypyAnalyzer, "_run_mypy")
    async def test_fallback_to_text_parsing(self, mock_run: object) -> None:
        """Test that unrecognized --output json triggers text fallback."""
        text_output = (
            "/tmp/test/app.py:5: error: "
            "Incompatible return type [return-value]\n"
            "/tmp/test/app.py:10: warning: "
            "Unused type: ignore comment [unused-ignore]\n"
        )
        cast(Any, mock_run).side_effect = [
            ("", "error: argument --output: invalid choice", 2),
            (text_output, "", 1),
        ]

        analyzer = MypyAnalyzer()
        results = await analyzer.analyze(_request([Path("/tmp/test/app.py")]))

        assert len(results) == 2
        assert results[0].rule_id == "mypy-return-value"
        assert results[1].rule_id == "mypy-unused-ignore"

    def test_build_args_includes_standard_flags(self, tmp_path: Path) -> None:
        analyzer = MypyAnalyzer()
        args = analyzer._build_args([tmp_path / "app.py"], use_json=True)
        assert "--output" in args
        assert "json" in args
        assert "--no-color-output" in args

    def test_build_args_no_json(self, tmp_path: Path) -> None:
        analyzer = MypyAnalyzer()
        args = analyzer._build_args([tmp_path / "app.py"], use_json=False)
        assert "--output" not in args


class TestMypyFrameworkHelpers:
    def test_configured_mypy_plugins_from_pyproject(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text(
            "[tool.mypy]\n" "plugins = ['mypy_django_plugin.main', 'pydantic.mypy']\n"
        )
        plugins = _configured_mypy_plugins(tmp_path)
        assert "mypy_django_plugin.main" in plugins
        assert "pydantic.mypy" in plugins


class TestParseMypyFatalErrors:
    def test_parses_syntax_error_lines(self) -> None:
        stderr = (
            "app/services/force_generate.py:44: multiple exception types must be"
            ' parenthesized at "except KeyError, ValueError:"\n'
            "app/utils/logger_utils.py:45: multiple exception types must be"
            ' parenthesized at "except BlockingIOError, OSError:"\n'
        )
        diags = _parse_mypy_fatal_errors(stderr)
        assert len(diags) == 2
        assert diags[0].rule_id == "mypy-syntax"
        assert diags[0].line == 44
        assert str(diags[0].file_path) == "app/services/force_generate.py"
        assert diags[1].line == 45
        assert all(
            d.severity == Severity.ERROR and d.category == Category.TYPE_SAFETY
            for d in diags
        )
        assert all(d.fix is not None for d in diags)

    def test_ignores_lines_without_file_path(self) -> None:
        stderr = (
            "mypy: cannot find implementation or library stub for module named 'foo'"
        )
        diags = _parse_mypy_fatal_errors(stderr)
        assert diags == []

    def test_empty_stderr(self) -> None:
        assert _parse_mypy_fatal_errors("") == []
        assert _parse_mypy_fatal_errors("\n\n") == []

    def test_absolute_paths(self) -> None:
        stderr = (
            "/home/user/project/dag/engine/decorators.py:188:"
            " multiple exception types must be parenthesized"
        )
        diags = _parse_mypy_fatal_errors(stderr)
        assert len(diags) == 1
        assert diags[0].line == 188


class TestMypyFatalHandling:
    @patch.object(MypyAnalyzer, "_run_mypy")
    async def test_syntax_errors_become_diagnostics(self, mock_run: object) -> None:
        stderr = (
            "app/services/force_generate.py:44: multiple exception types must be"
            ' parenthesized at "except KeyError, ValueError:"'
        )
        cast(Any, mock_run).return_value = ("", stderr, 2)
        analyzer = MypyAnalyzer()
        results = await analyzer.analyze(_request([Path("/tmp/test/src/app.py")]))
        assert len(results) == 1
        assert results[0].rule_id == "mypy-syntax"
        assert results[0].line == 44


class TestMapMypySeverity:
    def test_error(self) -> None:
        assert _map_mypy_severity("error") == Severity.ERROR

    def test_warning(self) -> None:
        assert _map_mypy_severity("warning") == Severity.WARNING

    def test_note(self) -> None:
        assert _map_mypy_severity("note") == Severity.INFO


class TestMypyIntegration:
    """Integration tests that actually run mypy."""

    async def test_mypy_on_typed_file(self, tmp_path: Path) -> None:
        analyzer = MypyAnalyzer()
        if not await analyzer.is_available():
            pytest.skip("mypy not available")

        test_file = tmp_path / "test_typed.py"
        test_file.write_text(
            "def greet(name: str) -> str:\n    return 42  # type error\n"
        )

        results = await analyzer.analyze(_request([test_file]))
        assert len(results) > 0
        assert any("return-value" in d.rule_id for d in results)

    async def test_mypy_on_clean_file(self, tmp_path: Path) -> None:
        analyzer = MypyAnalyzer()
        if not await analyzer.is_available():
            pytest.skip("mypy not available")

        test_file = tmp_path / "clean.py"
        test_file.write_text(
            'def greet(name: str) -> str:\n    return f"Hello, {name}"\n'
        )

        results = await analyzer.analyze(_request([test_file]))
        assert len(results) == 0
