from __future__ import annotations

from io import StringIO
from pathlib import Path

from rich.console import Console

from python_checkup.formatters.terminal import (
    ANALYZER_EXTRA,
    _checklist_icon,
    _format_duration,
    _print_framework_section,
    _score_color,
    _select_high_impact,
    _sort_issues,
    print_report,
)
from python_checkup.models import (
    Category,
    CategoryScore,
    ChecklistItem,
    Diagnostic,
    FrameworkReport,
    HealthReport,
    ProjectInfo,
    Severity,
)


class TestScoreColor:
    def test_green_for_high_scores(self) -> None:
        assert _score_color(75) == "green"
        assert _score_color(100) == "green"

    def test_yellow_for_medium_scores(self) -> None:
        assert _score_color(50) == "yellow"
        assert _score_color(74.9) == "yellow"

    def test_red_for_low_scores(self) -> None:
        assert _score_color(0) == "red"
        assert _score_color(49.9) == "red"


class TestFormatDuration:
    def test_milliseconds(self) -> None:
        assert _format_duration(500) == "500ms"

    def test_seconds(self) -> None:
        assert _format_duration(2300) == "2.3s"

    def test_minutes(self) -> None:
        assert _format_duration(90000) == "1m 30s"


class TestSortIssues:
    def test_errors_before_warnings(self) -> None:
        issues = [
            Diagnostic(
                file_path=Path("a.py"),
                line=1,
                column=0,
                severity=Severity.WARNING,
                rule_id="W001",
                tool="test",
                category=Category.QUALITY,
                message="warning",
            ),
            Diagnostic(
                file_path=Path("a.py"),
                line=2,
                column=0,
                severity=Severity.ERROR,
                rule_id="E001",
                tool="test",
                category=Category.QUALITY,
                message="error",
            ),
        ]
        sorted_issues = _sort_issues(issues)
        assert sorted_issues[0].severity == Severity.ERROR
        assert sorted_issues[1].severity == Severity.WARNING

    def test_same_severity_sorted_by_file(self) -> None:
        issues = [
            Diagnostic(
                file_path=Path("z.py"),
                line=1,
                column=0,
                severity=Severity.ERROR,
                rule_id="E001",
                tool="test",
                category=Category.QUALITY,
                message="error",
            ),
            Diagnostic(
                file_path=Path("a.py"),
                line=1,
                column=0,
                severity=Severity.ERROR,
                rule_id="E002",
                tool="test",
                category=Category.QUALITY,
                message="error",
            ),
        ]
        sorted_issues = _sort_issues(issues)
        assert str(sorted_issues[0].file_path) == "a.py"


class TestHighImpact:
    def test_selects_from_worst_category(self) -> None:
        category_scores = [
            CategoryScore(
                category=Category.SECURITY,
                score=40,
                weight=20,
                issue_count=5,
            ),
            CategoryScore(
                category=Category.QUALITY,
                score=90,
                weight=25,
                issue_count=2,
            ),
        ]
        issues = [
            Diagnostic(
                file_path=Path("a.py"),
                line=1,
                column=0,
                severity=Severity.ERROR,
                rule_id="S105",
                tool="bandit",
                category=Category.SECURITY,
                message="Hardcoded password",
            ),
            Diagnostic(
                file_path=Path("b.py"),
                line=1,
                column=0,
                severity=Severity.ERROR,
                rule_id="F401",
                tool="ruff",
                category=Category.QUALITY,
                message="Unused import",
            ),
        ]
        selected = _select_high_impact(issues, category_scores)
        # Security issue should come first (worst category)
        assert selected[0].rule_id == "S105"

    def test_returns_max_three(self) -> None:
        issues = [
            Diagnostic(
                file_path=Path(f"f{i}.py"),
                line=1,
                column=0,
                severity=Severity.ERROR,
                rule_id=f"E{i:03d}",
                tool="test",
                category=Category.QUALITY,
                message=f"Issue {i}",
            )
            for i in range(10)
        ]
        selected = _select_high_impact(issues, [])
        assert len(selected) <= 3


class TestPrintReport:
    def test_does_not_crash_on_empty_report(self) -> None:
        """Empty report should render without errors."""
        report = HealthReport(
            score=100,
            label="Healthy",
            category_scores=[],
            diagnostics=[],
            project=ProjectInfo(
                python_version="3.12",
                framework=None,
                total_files=0,
                total_lines=0,
            ),
            duration_ms=50,
        )
        # Should not raise
        print_report(report)

    def test_verbose_does_not_crash(self) -> None:
        """Verbose mode should not crash with many issues."""
        diagnostics = [
            Diagnostic(
                file_path=Path(f"file{i}.py"),
                line=i,
                column=0,
                severity=Severity.WARNING,
                rule_id=f"W{i:03d}",
                tool="test",
                category=Category.QUALITY,
                message=f"Issue {i}",
            )
            for i in range(50)
        ]
        report = HealthReport(
            score=50,
            label="Needs work",
            category_scores=[],
            diagnostics=diagnostics,
            project=ProjectInfo(
                python_version="3.12",
                framework=None,
                total_files=50,
                total_lines=5000,
            ),
            duration_ms=100,
        )
        # Should not raise
        print_report(report, verbose=True)

    def test_show_fix_does_not_crash(self) -> None:
        """--fix mode should not crash."""
        diagnostics = [
            Diagnostic(
                file_path=Path("app.py"),
                line=1,
                column=0,
                severity=Severity.ERROR,
                rule_id="F401",
                tool="ruff",
                category=Category.QUALITY,
                message="Unused import",
                fix="Remove the import",
            ),
        ]
        report = HealthReport(
            score=80,
            label="Healthy",
            category_scores=[
                CategoryScore(
                    category=Category.QUALITY,
                    score=80,
                    weight=100,
                    issue_count=1,
                    error_count=1,
                    details="1 error",
                ),
            ],
            diagnostics=diagnostics,
            project=ProjectInfo(
                python_version="3.12",
                framework=None,
                total_files=1,
                total_lines=100,
            ),
            duration_ms=100,
        )
        print_report(report, show_fix=True)

    def test_diff_mode_does_not_crash(self) -> None:
        """Diff mode should show file count info."""
        report = HealthReport(
            score=90,
            label="Healthy",
            category_scores=[],
            diagnostics=[],
            project=ProjectInfo(
                python_version="3.12",
                framework=None,
                total_files=5,
                total_lines=500,
            ),
            duration_ms=100,
        )
        print_report(
            report,
            diff_mode=True,
            changed_file_count=5,
            total_file_count=100,
        )


class TestCoverageInstallHints:
    """Test that optional analyzer hints print uvx install commands."""

    def test_coverage_prints_uvx_hints(self, capsys: object) -> None:
        """Coverage section should show uvx --from hint for missing extras."""
        from python_checkup.models import CoverageInfo

        coverage = CoverageInfo(
            profile="full",
            confidence="partial",
            analyzers_optional_unavailable=["detect-secrets", "dependency-vulns"],
        )
        report = HealthReport(
            score=85,
            label="Healthy",
            category_scores=[],
            diagnostics=[],
            project=ProjectInfo(
                python_version="3.12",
                framework=None,
                total_files=10,
                total_lines=500,
            ),
            duration_ms=100,
            coverage=coverage,
        )
        # Should not crash and should include the uvx hint
        print_report(report)

    def test_analyzer_extra_mapping_complete(self) -> None:
        """All optional analyzers should have an extra mapping."""
        expected = {"dependency-vulns", "detect-secrets", "basedpyright", "typos"}
        assert set(ANALYZER_EXTRA.keys()) == expected


class TestWeightRedistributionExplanation:
    """Test that the human formatter explains weight redistribution."""

    def test_redistribution_note_for_unavailable_category(self, capsys: object) -> None:
        """When a category is unavailable, the output should note redistribution."""
        from python_checkup.models import CategoryCoverage, CoverageInfo

        coverage = CoverageInfo(
            profile="default",
            confidence="partial",
            category_coverage=[
                CategoryCoverage(
                    category=Category.TYPE_SAFETY,
                    status="unavailable",
                    reason="no type checker installed",
                ),
                CategoryCoverage(
                    category=Category.QUALITY,
                    status="scored",
                    analyzers=["ruff"],
                ),
            ],
        )
        report = HealthReport(
            score=85,
            label="Healthy",
            category_scores=[],
            diagnostics=[],
            project=ProjectInfo(
                python_version="3.12",
                framework=None,
                total_files=10,
                total_lines=500,
            ),
            duration_ms=100,
            coverage=coverage,
        )
        # Should not crash
        print_report(report)

    def test_redistribution_note_for_skipped_category(self, capsys: object) -> None:
        """When a category is skipped_by_user, output should note redistribution."""
        from python_checkup.models import CategoryCoverage, CoverageInfo

        coverage = CoverageInfo(
            profile="default",
            confidence="partial",
            category_coverage=[
                CategoryCoverage(
                    category=Category.DEAD_CODE,
                    status="skipped_by_user",
                ),
                CategoryCoverage(
                    category=Category.DEPENDENCIES,
                    status="unavailable",
                    reason="no lockfile",
                ),
            ],
        )
        report = HealthReport(
            score=90,
            label="Healthy",
            category_scores=[],
            diagnostics=[],
            project=ProjectInfo(
                python_version="3.12",
                framework=None,
                total_files=5,
                total_lines=200,
            ),
            duration_ms=50,
            coverage=coverage,
        )
        # Should not crash
        print_report(report)

    def test_no_redistribution_note_when_all_scored(self, capsys: object) -> None:
        """When all categories are scored, no redistribution note should appear."""
        from python_checkup.models import CategoryCoverage, CoverageInfo

        coverage = CoverageInfo(
            profile="default",
            confidence="full",
            category_coverage=[
                CategoryCoverage(
                    category=Category.QUALITY,
                    status="scored",
                    analyzers=["ruff"],
                ),
                CategoryCoverage(
                    category=Category.SECURITY,
                    status="scored",
                    analyzers=["bandit"],
                ),
            ],
        )
        report = HealthReport(
            score=95,
            label="Healthy",
            category_scores=[],
            diagnostics=[],
            project=ProjectInfo(
                python_version="3.12",
                framework=None,
                total_files=5,
                total_lines=200,
            ),
            duration_ms=50,
            coverage=coverage,
        )
        # Should not crash
        print_report(report)


# ---------------------------------------------------------------------------
# Phase 5: Framework section tests
# ---------------------------------------------------------------------------


def _make_fw_report(
    display_name: str = "Django 5.1",
    security: list[tuple[str, str, str | None]] | None = None,
    ecosystem: list[tuple[str, str]] | None = None,
    suppressed: int = 0,
    suppressed_examples: list[dict[str, str | int | None]] | None = None,
) -> FrameworkReport:
    checklist = [
        ChecklistItem(status=s, description=d, rule_id=r)
        for s, d, r in (security or [])
    ]
    eco = [ChecklistItem(status=s, description=d) for s, d in (ecosystem or [])]
    return FrameworkReport(
        display_name=display_name,
        primary_framework="django",
        detected_frameworks=["django"],
        security_checklist=checklist,
        ecosystem=eco,
        suppressed_count=suppressed,
        suppressed_examples=suppressed_examples or [],
        advisory_count=0,
    )


def _capture_framework_section(
    fw_report: FrameworkReport,
    *,
    verbose: bool = False,
) -> str:
    """Render the framework section to a string (no ANSI codes)."""
    buf = StringIO()
    console = Console(file=buf, highlight=False, markup=False, no_color=True)
    _print_framework_section(console, fw_report, verbose=verbose)
    return buf.getvalue()


class TestChecklistIcon:
    def test_pass_icon(self) -> None:
        assert "✓" in _checklist_icon("pass")

    def test_fail_icon(self) -> None:
        assert "✗" in _checklist_icon("fail")

    def test_warning_icon(self) -> None:
        assert "~" in _checklist_icon("warning")

    def test_info_icon(self) -> None:
        assert "·" in _checklist_icon("info")

    def test_unknown_status(self) -> None:
        assert _checklist_icon("unknown") == " "


class TestPrintFrameworkSection:
    def test_displays_framework_name(self) -> None:
        report = _make_fw_report("FastAPI 0.115")
        output = _capture_framework_section(report)
        assert "FastAPI 0.115" in output

    def test_shows_checklist_items(self) -> None:
        report = _make_fw_report(security=[("fail", "DEBUG = True", "FW-DJ-001")])
        output = _capture_framework_section(report)
        assert "DEBUG = True" in output
        assert "FW-DJ-001" in output

    def test_shows_ecosystem_items(self) -> None:
        report = _make_fw_report(ecosystem=[("warning", "django-stubs not installed")])
        output = _capture_framework_section(report)
        assert "django-stubs not installed" in output

    def test_suppression_count_shown(self) -> None:
        report = _make_fw_report(suppressed=5)
        output = _capture_framework_section(report)
        assert "5" in output
        assert "suppressed" in output

    def test_no_suppression_line_when_zero(self) -> None:
        report = _make_fw_report(suppressed=0)
        output = _capture_framework_section(report)
        assert "suppressed" not in output

    def test_verbose_shows_suppressed_examples(self) -> None:
        report = _make_fw_report(
            suppressed=2,
            suppressed_examples=[
                {
                    "name": "Meta",
                    "item_type": "class",
                    "reason": "Django model Meta inner class",
                },
                {
                    "name": "get_queryset",
                    "item_type": "function",
                    "reason": "Django class-based view attribute or method",
                },
            ],
        )
        output = _capture_framework_section(report, verbose=True)
        assert "Meta (class)" in output
        assert "get_queryset (function)" in output
        assert "Django model Meta inner class" in output

    def test_non_verbose_hides_suppressed_examples(self) -> None:
        report = _make_fw_report(
            suppressed=1,
            suppressed_examples=[
                {
                    "name": "Meta",
                    "item_type": "class",
                    "reason": "Django model Meta inner class",
                }
            ],
        )
        output = _capture_framework_section(report)
        assert "Meta (class)" not in output

    def test_empty_checklist_no_crash(self) -> None:
        report = _make_fw_report()
        # Should not raise
        _capture_framework_section(report)


class TestSelectHighImpactWithFramework:
    def _diag(
        self,
        rule_id: str,
        severity: Severity = Severity.ERROR,
        category: Category = Category.SECURITY,
    ) -> Diagnostic:
        return Diagnostic(
            file_path=Path("f.py"),
            line=1,
            column=0,
            severity=severity,
            rule_id=rule_id,
            tool="test",
            category=category,
            message="msg",
        )

    def test_fw_errors_boosted_to_top(self) -> None:
        fw_diag = self._diag("FW-DJ-001", Severity.ERROR, Category.SECURITY)
        regular = self._diag("B601", Severity.ERROR, Category.SECURITY)
        cs = CategoryScore(
            category=Category.SECURITY,
            score=10,
            weight=30,
            issue_count=2,
            error_count=2,
        )
        fw_report = _make_fw_report(security=[("fail", "DEBUG = True", "FW-DJ-001")])
        result = _select_high_impact([regular, fw_diag], [cs], fw_report)
        # FW-DJ-001 should appear first
        assert result[0].rule_id == "FW-DJ-001"

    def test_no_framework_report_uses_category(self) -> None:
        diag1 = self._diag("B601", Severity.ERROR, Category.SECURITY)
        diag2 = self._diag("E501", Severity.ERROR, Category.QUALITY)
        cs_security = CategoryScore(
            category=Category.SECURITY,
            score=20,
            weight=30,
            issue_count=1,
            error_count=1,
        )
        cs_quality = CategoryScore(
            category=Category.QUALITY,
            score=80,
            weight=25,
            issue_count=1,
            error_count=1,
        )
        result = _select_high_impact([diag1, diag2], [cs_security, cs_quality], None)
        # Lowest-scoring category (security) comes first
        assert result[0].rule_id == "B601"

    def test_max_three_items_returned(self) -> None:
        diags = [self._diag(f"E{i}") for i in range(10)]
        cs = CategoryScore(
            category=Category.SECURITY,
            score=50,
            weight=30,
            issue_count=10,
            error_count=10,
        )
        result = _select_high_impact(diags, [cs])
        assert len(result) <= 3


class TestPrintReportWithFrameworkReport:
    def test_print_report_with_framework_report_no_crash(self) -> None:
        fw_report = _make_fw_report(
            security=[
                ("fail", "DEBUG = True", "FW-DJ-001"),
                ("pass", "CSRF middleware enabled", None),
            ],
            ecosystem=[("warning", "django-stubs not installed")],
            suppressed=3,
        )
        report = HealthReport(
            score=72,
            label="Needs work",
            category_scores=[
                CategoryScore(
                    category=Category.SECURITY,
                    score=40,
                    weight=30,
                    issue_count=2,
                    error_count=1,
                )
            ],
            diagnostics=[],
            project=ProjectInfo(
                python_version="3.12",
                framework="django-5.1",
                total_files=10,
                total_lines=500,
                detected_frameworks=["django"],
                framework_details={"django": "5.1"},
            ),
            duration_ms=200,
            framework_report=fw_report,
        )
        # Should not crash
        print_report(report)
