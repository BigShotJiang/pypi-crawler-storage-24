from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest

from python_checkup.analysis_request import AnalysisRequest
from python_checkup.analyzers.bandit import BanditAnalyzer, _map_bandit_result
from python_checkup.config import CheckupConfig
from python_checkup.detection import FrameworkCategory, FrameworkInfo, FrameworkStack
from python_checkup.models import Category, Severity

SAMPLE_BANDIT_OUTPUT = json.dumps(
    {
        "results": [
            {
                "test_id": "B301",
                "test_name": "pickle",
                "issue_severity": "MEDIUM",
                "issue_confidence": "HIGH",
                "issue_text": "Pickle and modules that wrap it can be unsafe.",
                "filename": "/tmp/test/src/insecure.py",
                "line_number": 6,
                "col_offset": 15,
                "end_col_offset": 30,
                "line_range": [6],
                "issue_cwe": {
                    "id": 502,
                    "link": "https://cwe.mitre.org/data/definitions/502.html",
                },
                "more_info": "https://bandit.readthedocs.io/en/latest/plugins/b301_pickle.html",
            },
            {
                "test_id": "B602",
                "test_name": "subprocess_popen_with_shell_equals_true",
                "issue_severity": "HIGH",
                "issue_confidence": "HIGH",
                "issue_text": "subprocess call with shell=True identified.",
                "filename": "/tmp/test/src/insecure.py",
                "line_number": 9,
                "col_offset": 4,
                "end_col_offset": 40,
                "line_range": [9],
                "issue_cwe": {
                    "id": 78,
                    "link": "https://cwe.mitre.org/data/definitions/78.html",
                },
                "more_info": "https://bandit.readthedocs.io/en/latest/plugins/b602.html",
            },
        ],
        "metrics": {
            "_totals": {"loc": 200, "nosec": 0},
        },
    }
)


def _request(files: list[Path]) -> AnalysisRequest:
    root = files[0].parent if files else Path(".")
    return AnalysisRequest(
        project_root=root,
        files=files,
        config=CheckupConfig(),
        categories={Category.SECURITY},
        profile="default",
    )


def _django_stack() -> FrameworkStack:
    django = FrameworkInfo(
        name="django",
        version=None,
        confidence=1.0,
        category=FrameworkCategory.WEB,
    )
    return FrameworkStack(primary=django, companions=[], all_frameworks=[django])


class TestBanditAnalyzer:
    async def test_name_and_category(self) -> None:
        analyzer = BanditAnalyzer()
        assert analyzer.name == "bandit"
        assert analyzer.category == Category.SECURITY

    @patch("asyncio.create_subprocess_exec")
    async def test_analyze_with_results(self, mock_exec: AsyncMock) -> None:
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (SAMPLE_BANDIT_OUTPUT.encode(), b"")
        mock_proc.returncode = 1
        mock_exec.return_value = mock_proc

        analyzer = BanditAnalyzer()
        results = await analyzer.analyze(_request([Path("/tmp/test/src/insecure.py")]))

        assert len(results) == 2

        # B301 pickle -- MEDIUM severity
        assert results[0].rule_id == "B301"
        assert results[0].severity == Severity.WARNING
        assert results[0].category == Category.SECURITY

        # B602 shell=True -- HIGH severity
        assert results[1].rule_id == "B602"
        assert results[1].severity == Severity.ERROR

    @patch("asyncio.create_subprocess_exec")
    async def test_analyze_clean_project(self, mock_exec: AsyncMock) -> None:
        mock_proc = AsyncMock()
        clean_output = json.dumps({"results": [], "metrics": {}})
        mock_proc.communicate.return_value = (clean_output.encode(), b"")
        mock_proc.returncode = 0
        mock_exec.return_value = mock_proc

        analyzer = BanditAnalyzer()
        results = await analyzer.analyze(_request([Path("/tmp/test/src/app.py")]))
        assert results == []

    async def test_analyze_empty_files(self) -> None:
        analyzer = BanditAnalyzer()
        results = await analyzer.analyze(_request([]))
        assert results == []

    @patch("asyncio.create_subprocess_exec")
    async def test_django_suppresses_framework_sanctioned_rules(
        self, mock_exec: AsyncMock
    ) -> None:
        output = json.dumps(
            {
                "results": [
                    {
                        "test_id": "B703",
                        "issue_severity": "LOW",
                        "issue_text": "Potential XSS on markupsafe output.",
                        "filename": "/tmp/test/src/views.py",
                        "line_number": 4,
                        "col_offset": 0,
                    },
                    {
                        "test_id": "B308",
                        "issue_severity": "MEDIUM",
                        "issue_text": "Use of mark_safe.",
                        "filename": "/tmp/test/src/views.py",
                        "line_number": 6,
                        "col_offset": 0,
                    },
                ],
                "metrics": {},
            }
        )
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (output.encode(), b"")
        mock_proc.returncode = 1
        mock_exec.return_value = mock_proc

        analyzer = BanditAnalyzer()
        request = _request([Path("/tmp/test/src/views.py")])
        request.framework_stack = _django_stack()
        results = await analyzer.analyze(request)

        assert results == []

    @patch("asyncio.create_subprocess_exec")
    async def test_django_elevates_b110_to_warning(self, mock_exec: AsyncMock) -> None:
        output = json.dumps(
            {
                "results": [
                    {
                        "test_id": "B110",
                        "issue_severity": "LOW",
                        "issue_text": "Try, Except, Pass detected.",
                        "filename": "/tmp/test/src/views.py",
                        "line_number": 8,
                        "col_offset": 0,
                    }
                ],
                "metrics": {},
            }
        )
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (output.encode(), b"")
        mock_proc.returncode = 1
        mock_exec.return_value = mock_proc

        analyzer = BanditAnalyzer()
        request = _request([Path("/tmp/test/src/views.py")])
        request.framework_stack = _django_stack()
        results = await analyzer.analyze(request)

        assert len(results) == 1
        assert results[0].rule_id == "B110"
        assert results[0].severity == Severity.WARNING


class TestMapBanditResult:
    def test_high_severity(self) -> None:
        raw = {
            "test_id": "B602",
            "issue_severity": "HIGH",
            "issue_text": "subprocess with shell=True",
            "filename": "/test.py",
            "line_number": 5,
            "col_offset": 0,
            "end_col_offset": 10,
            "issue_cwe": {"id": 78, "link": "https://cwe.mitre.org/..."},
            "more_info": "https://bandit.readthedocs.io/...",
        }
        d = _map_bandit_result(raw)
        assert d.severity == Severity.ERROR
        assert d.rule_id == "B602"
        assert d.help_url == "https://bandit.readthedocs.io/..."

    def test_low_severity(self) -> None:
        raw = {
            "test_id": "B101",
            "issue_severity": "LOW",
            "issue_text": "Use of assert detected.",
            "filename": "/test.py",
            "line_number": 10,
            "col_offset": 0,
            "more_info": "https://bandit.readthedocs.io/...",
        }
        d = _map_bandit_result(raw)
        assert d.severity == Severity.INFO


class TestBanditIntegration:
    """Integration tests that actually run Bandit."""

    async def test_bandit_on_security_project(self, security_project: Path) -> None:
        analyzer = BanditAnalyzer()
        if not await analyzer.is_available():
            pytest.skip("Bandit not available")

        results = await analyzer.analyze(_request(list(security_project.rglob("*.py"))))
        assert len(results) > 0
        rule_ids = {d.rule_id for d in results}
        # security_issues fixture has pickle.load and shell=True
        assert "B301" in rule_ids or "B602" in rule_ids
