from __future__ import annotations

from unittest.mock import MagicMock, patch

from python_checkup.analysis_request import AnalysisRequest
from python_checkup.analyzers import Analyzer
from python_checkup.analyzers.registry import discover_analyzers, get_analyzer
from python_checkup.models import Category, Diagnostic


class _GoodAnalyzer:
    """A valid analyzer that satisfies the Protocol."""

    @property
    def name(self) -> str:
        return "good"

    @property
    def category(self) -> Category:
        return Category.QUALITY

    async def is_available(self) -> bool:
        return True

    async def analyze(self, request: AnalysisRequest) -> list[Diagnostic]:
        return []


class _BadPlugin:
    """A plugin that does NOT satisfy the Analyzer protocol."""

    def hello(self) -> str:
        return "I am not an analyzer"


class TestProtocolConformance:
    def test_good_analyzer_satisfies_protocol(self) -> None:
        analyzer = _GoodAnalyzer()
        assert isinstance(analyzer, Analyzer)

    def test_bad_plugin_fails_protocol(self) -> None:
        plugin = _BadPlugin()
        assert not isinstance(plugin, Analyzer)


class TestDiscoverAnalyzers:
    @patch("python_checkup.analyzers.registry.entry_points")
    async def test_skips_non_conforming_plugins(self, mock_eps: MagicMock) -> None:
        """Plugins that don't implement the Analyzer protocol are skipped."""
        bad_ep = MagicMock()
        bad_ep.name = "bad-plugin"
        bad_ep.load.return_value = _BadPlugin

        good_ep = MagicMock()
        good_ep.name = "good-plugin"
        good_ep.load.return_value = _GoodAnalyzer

        mock_eps.return_value = [bad_ep, good_ep]

        result = await discover_analyzers()

        assert len(result) == 1
        assert result[0].name == "good"

    @patch("python_checkup.analyzers.registry.entry_points")
    async def test_skips_broken_plugins(self, mock_eps: MagicMock) -> None:
        """Plugins that raise exceptions during load are skipped."""
        broken_ep = MagicMock()
        broken_ep.name = "broken"
        broken_ep.load.side_effect = ImportError("missing dep")

        mock_eps.return_value = [broken_ep]

        result = await discover_analyzers()
        assert result == []


class TestGetAnalyzer:
    @patch("python_checkup.analyzers.registry.entry_points")
    async def test_rejects_non_conforming(self, mock_eps: MagicMock) -> None:
        bad_ep = MagicMock()
        bad_ep.name = "bad"
        bad_ep.load.return_value = _BadPlugin

        mock_eps.return_value = [bad_ep]

        result = await get_analyzer("bad")
        assert result is None

    @patch("python_checkup.analyzers.registry.entry_points")
    async def test_returns_valid_analyzer(self, mock_eps: MagicMock) -> None:
        good_ep = MagicMock()
        good_ep.name = "good"
        good_ep.load.return_value = _GoodAnalyzer

        mock_eps.return_value = [good_ep]

        result = await get_analyzer("good")
        assert result is not None
        assert result.name == "good"
