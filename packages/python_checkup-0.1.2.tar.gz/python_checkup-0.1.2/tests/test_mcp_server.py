from __future__ import annotations

import json
from pathlib import Path

import pytest

from python_checkup.models import (
    Category,
    CategoryScore,
    ChecklistItem,
    FrameworkReport,
    HealthReport,
    ProjectInfo,
)


class TestMCPToolHandlers:
    """Test the tool handler functions directly (without MCP protocol)."""

    @pytest.mark.asyncio
    async def test_diagnose_nonexistent_path(self) -> None:
        from python_checkup.mcp.server import python_checkup_diagnose

        result = await python_checkup_diagnose("/nonexistent/path/xyz")
        assert "Error" in result

    @pytest.mark.asyncio
    async def test_diagnose_single_file(self, tmp_path: Path) -> None:
        bad_file = tmp_path / "bad.py"
        bad_file.write_text("import os\nimport sys\nprint('hello')\n")

        from python_checkup.mcp.server import python_checkup_diagnose

        result = await python_checkup_diagnose(str(bad_file))
        data = json.loads(result)
        assert "score" in data
        assert "categoryScores" in data
        assert isinstance(data["score"], int)

    @pytest.mark.asyncio
    async def test_diagnose_directory(self, tmp_path: Path) -> None:
        # Create a minimal project
        (tmp_path / "pyproject.toml").write_text(
            '[project]\nname = "test"\nversion = "0.1.0"\n'
        )
        src = tmp_path / "app.py"
        src.write_text("x: int = 1\n")

        from python_checkup.mcp.server import python_checkup_diagnose

        result = await python_checkup_diagnose(str(tmp_path))
        data = json.loads(result)
        assert "score" in data
        assert data["score"] >= 0

    @pytest.mark.asyncio
    async def test_diagnose_quick_mode(self, tmp_path: Path) -> None:
        src = tmp_path / "app.py"
        src.write_text("x: int = 1\n")

        from python_checkup.mcp.server import python_checkup_diagnose

        result = await python_checkup_diagnose(str(tmp_path), quick=True)
        data = json.loads(result)
        # Quick mode should skip mypy
        assert "score" in data

    @pytest.mark.asyncio
    async def test_lint_returns_json(self, tmp_path: Path) -> None:
        bad_file = tmp_path / "bad.py"
        bad_file.write_text("import os\nimport sys\nprint('hello')\n")

        from python_checkup.mcp.server import python_checkup_lint

        result = await python_checkup_lint([str(bad_file)])
        data = json.loads(result)
        assert "totalIssues" in data
        assert data["totalIssues"] > 0

    @pytest.mark.asyncio
    async def test_lint_clean_file(self, tmp_path: Path) -> None:
        clean_file = tmp_path / "clean.py"
        clean_file.write_text("x: int = 1\n")

        from python_checkup.mcp.server import python_checkup_lint

        result = await python_checkup_lint([str(clean_file)])
        assert "clean" in result.lower() or "no lint" in result.lower()

    @pytest.mark.asyncio
    async def test_lint_nonexistent_file(self) -> None:
        from python_checkup.mcp.server import python_checkup_lint

        result = await python_checkup_lint(["/nonexistent/file.py"])
        assert "Error" in result or "not found" in result.lower()

    @pytest.mark.asyncio
    async def test_typecheck_nonexistent_file(self) -> None:
        from python_checkup.mcp.server import python_checkup_typecheck

        result = await python_checkup_typecheck(["/nonexistent/file.py"])
        assert "Error" in result or "not found" in result.lower()

    @pytest.mark.asyncio
    async def test_security_clean_file(self, tmp_path: Path) -> None:
        clean_file = tmp_path / "clean.py"
        clean_file.write_text("x: int = 1\n")

        from python_checkup.mcp.server import python_checkup_security

        result = await python_checkup_security([str(clean_file)])
        assert "secure" in result.lower() or "no security" in result.lower()

    @pytest.mark.asyncio
    async def test_security_nonexistent_file(self) -> None:
        from python_checkup.mcp.server import python_checkup_security

        result = await python_checkup_security(["/nonexistent/file.py"])
        assert "Error" in result or "not found" in result.lower()

    @pytest.mark.asyncio
    async def test_explain_known_rule(self) -> None:
        from python_checkup.mcp.server import python_checkup_explain_rule

        result = await python_checkup_explain_rule("F401")
        assert "Unused import" in result
        assert "import" in result.lower()

    @pytest.mark.asyncio
    async def test_explain_unknown_rule(self) -> None:
        from python_checkup.mcp.server import python_checkup_explain_rule

        result = await python_checkup_explain_rule("ZZZZZ999")
        assert "unknown rule" in result.lower()

    @pytest.mark.asyncio
    async def test_explain_cross_reference(self) -> None:
        from python_checkup.mcp.server import python_checkup_explain_rule

        # S101 should cross-reference to B101 or vice versa
        result = await python_checkup_explain_rule("S101")
        assert "assert" in result.lower()

    @pytest.mark.asyncio
    async def test_explain_includes_examples(self) -> None:
        from python_checkup.mcp.server import python_checkup_explain_rule

        result = await python_checkup_explain_rule("F401")
        assert "Bad" in result
        assert "Good" in result or "fix" in result.lower()


class TestMCPFormatting:
    """Test the output formatting helpers."""

    @pytest.mark.asyncio
    async def test_report_format_has_required_fields(self, tmp_path: Path) -> None:
        src = tmp_path / "app.py"
        src.write_text("import os\nprint('hello')\n")

        from python_checkup.mcp.server import python_checkup_diagnose

        result = await python_checkup_diagnose(str(src))
        data = json.loads(result)

        assert "score" in data
        assert "label" in data
        assert "categoryScores" in data
        assert "project" in data
        assert "analyzersUsed" in data
        assert "totalIssues" in data
        assert "durationMs" in data

    @pytest.mark.asyncio
    async def test_diagnostics_format_has_required_fields(self, tmp_path: Path) -> None:
        bad_file = tmp_path / "bad.py"
        bad_file.write_text("import os\nimport sys\nprint('hello')\n")

        from python_checkup.mcp.server import python_checkup_lint

        result = await python_checkup_lint([str(bad_file)])
        data = json.loads(result)

        assert "totalIssues" in data
        assert "showing" in data
        assert "issues" in data
        for issue in data["issues"]:
            assert "file" in issue
            assert "line" in issue
            assert "ruleId" in issue
            assert "severity" in issue
            assert "message" in issue

    @pytest.mark.asyncio
    async def test_diagnose_includes_framework_context_for_detected_project(
        self, tmp_path: Path
    ) -> None:
        (tmp_path / "requirements.txt").write_text("flask>=3.0\n")
        (tmp_path / "app.py").write_text(
            "from flask import Flask\n"
            "app = Flask(__name__)\n"
            "SECRET_KEY = 'hardcoded'\n"
        )

        from python_checkup.mcp.server import python_checkup_diagnose

        result = await python_checkup_diagnose(str(tmp_path), quick=True)
        data = json.loads(result)

        assert "framework_context" in data
        assert data["framework_context"]["primary"] == "flask"
        assert "flask" in data["framework_context"]["allDetected"]
        assert isinstance(data["framework_context"].get("securityIssues", []), list)

    def test_format_report_includes_framework_context_and_security_issues(self) -> None:
        from python_checkup.mcp.server import _format_report

        report = HealthReport(
            score=70,
            label="Needs work",
            category_scores=[
                CategoryScore(
                    category=Category.SECURITY,
                    score=40,
                    weight=20,
                    issue_count=2,
                    error_count=1,
                    warning_count=1,
                    details="1 error, 1 warning",
                )
            ],
            diagnostics=[],
            project=ProjectInfo(
                python_version="3.12",
                framework="django-5.1",
                total_files=3,
                total_lines=120,
                detected_frameworks=["django", "celery"],
                framework_details={"django": "5.1", "celery": "5.3"},
            ),
            duration_ms=123,
            analyzers_used=["ruff", "framework-checks"],
            framework_report=FrameworkReport(
                display_name="Django 5.1 + Celery",
                primary_framework="django",
                detected_frameworks=["django", "celery"],
                security_checklist=[
                    ChecklistItem(
                        status="fail",
                        description="DEBUG = True",
                        rule_id="FW-DJ-001",
                        fix="Set DEBUG = False",
                    ),
                    ChecklistItem(
                        status="warning",
                        description="SESSION_COOKIE_SECURE not configured",
                        rule_id="FW-DJ-005",
                        fix="Set SESSION_COOKIE_SECURE = True",
                    ),
                    ChecklistItem(
                        status="info",
                        description="DEFAULT_AUTO_FIELD not set",
                        rule_id="FW-DJ-050",
                        fix="Add DEFAULT_AUTO_FIELD",
                    ),
                ],
                ecosystem=[
                    ChecklistItem(
                        status="warning",
                        description=(
                            "django-stubs not installed " "(type checking limited)"
                        ),
                    )
                ],
                suppressed_count=2,
            ),
        )

        data = json.loads(_format_report(report))

        assert data["framework_context"]["primary"] == "django"
        assert data["framework_context"]["displayName"] == "Django 5.1 + Celery"
        assert data["framework_context"]["suppressedFalsePositives"] == 2
        assert data["framework_context"]["securityIssues"] == [
            {
                "rule": "FW-DJ-001",
                "status": "fail",
                "message": "DEBUG = True",
                "fix": "Set DEBUG = False",
            },
            {
                "rule": "FW-DJ-005",
                "status": "warning",
                "message": "SESSION_COOKIE_SECURE not configured",
                "fix": "Set SESSION_COOKIE_SECURE = True",
            },
        ]
