"""Tests for the framework plugin registry (discovery, overrides, isolation)."""

from __future__ import annotations

from pathlib import Path

import pytest

from python_checkup.config import CheckupConfig
from python_checkup.detection import (
    FrameworkCategory,
    FrameworkInfo,
    FrameworkStack,
    _build_stack_from_names,
    detect_frameworks,
)
from python_checkup.frameworks.registry import (
    discover_framework_plugins,
    get_plugins_for_stack,
)

# ---------------------------------------------------------------------------
# Registry discovery
# ---------------------------------------------------------------------------


class TestDiscoverFrameworkPlugins:
    def test_returns_list(self) -> None:
        plugins = discover_framework_plugins()
        assert isinstance(plugins, list)
        assert len(plugins) > 0

    def test_all_builtin_frameworks_present(self) -> None:
        plugins = discover_framework_plugins()
        names = {p.name for p in plugins}
        expected = {
            "django",
            "fastapi",
            "flask",
            "celery",
            "sqlalchemy",
            "pydantic",
            "pytest",
            "drf",
            "starlette",
            "click",
            "typer",
            "aiohttp",
            "dramatiq",
        }
        assert expected.issubset(names)

    def test_no_duplicate_names(self) -> None:
        plugins = discover_framework_plugins()
        names = [p.name for p in plugins]
        assert len(names) == len(set(names)), "Duplicate plugin names detected"

    def test_reload_returns_fresh_list(self) -> None:
        p1 = discover_framework_plugins(reload=True)
        p2 = discover_framework_plugins(reload=True)
        # Objects may differ but names should be the same
        assert {p.name for p in p1} == {p.name for p in p2}

    def test_bad_entry_point_does_not_crash(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """A broken external plugin should be skipped, not crash the system."""
        import importlib.metadata

        class _BadEP:
            name = "bad_plugin"
            value = "nonexistent:Nope"

            def load(self) -> None:
                raise ImportError("intentional failure")

        original = importlib.metadata.entry_points

        def _patched_entry_points(**kwargs: str):  # type: ignore[no-untyped-def]
            group = kwargs.get("group")
            if group == "python_checkup.frameworks":
                return [_BadEP()]
            return original(**kwargs)

        monkeypatch.setattr(importlib.metadata, "entry_points", _patched_entry_points)
        # Should not raise
        plugins = discover_framework_plugins(reload=True)
        names = {p.name for p in plugins}
        assert "bad_plugin" not in names
        # Reload back to clean state
        discover_framework_plugins(reload=True)


class TestGetPluginsForStack:
    def _stack(self, *names: str) -> FrameworkStack:
        fws = [
            FrameworkInfo(
                name=n, version=None, confidence=0.9, category=FrameworkCategory.WEB
            )
            for n in names
        ]
        primary = fws[0] if fws else None
        companions = fws[1:]
        return FrameworkStack(
            primary=primary, companions=companions, all_frameworks=fws
        )

    def test_empty_stack_returns_empty(self) -> None:
        stack = FrameworkStack(primary=None, companions=[], all_frameworks=[])
        assert get_plugins_for_stack(stack) == []

    def test_single_framework_returns_one_plugin(self) -> None:
        stack = self._stack("django")
        plugins = get_plugins_for_stack(stack)
        assert len(plugins) == 1
        assert plugins[0].name == "django"

    def test_multiple_frameworks_returns_multiple_plugins(self) -> None:
        stack = self._stack("django", "celery")
        plugins = get_plugins_for_stack(stack)
        names = {p.name for p in plugins}
        assert "django" in names
        assert "celery" in names

    def test_unknown_framework_not_in_result(self) -> None:
        stack = self._stack("tornado_nonexistent")
        plugins = get_plugins_for_stack(stack)
        assert plugins == []


# ---------------------------------------------------------------------------
# Config overrides
# ---------------------------------------------------------------------------


class TestConfigOverrides:
    def test_frameworks_disabled_returns_empty_stack(self, tmp_path: Path) -> None:
        config = CheckupConfig(frameworks_disabled=True)
        stack = detect_frameworks(tmp_path, config=config)
        assert stack.primary is None
        assert stack.all_frameworks == []

    def test_forced_frameworks_overrides_detection(self, tmp_path: Path) -> None:
        config = CheckupConfig(frameworks=["flask"])
        stack = detect_frameworks(tmp_path, config=config)
        assert stack.primary is not None
        assert stack.primary.name == "flask"
        assert stack.primary.confidence == 1.0

    def test_forced_empty_list_returns_empty_stack(self, tmp_path: Path) -> None:
        config = CheckupConfig(frameworks=[])
        stack = detect_frameworks(tmp_path, config=config)
        assert stack.primary is None

    def test_unknown_forced_framework_warns(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        import logging

        with caplog.at_level(logging.WARNING, logger="python_checkup"):
            config = CheckupConfig(frameworks=["nonexistent_fw"])
            stack = detect_frameworks(tmp_path, config=config)
        assert stack.primary is None
        assert any("nonexistent_fw" in r.message for r in caplog.records)

    def test_disabled_framework_rules_filter(self, tmp_path: Path) -> None:
        """disabled_framework_rules are respected in config parsing."""
        config = CheckupConfig(disabled_framework_rules=["FW-DJ-001", "FW-DJ-002"])
        assert "FW-DJ-001" in config.disabled_framework_rules
        assert "FW-DJ-002" in config.disabled_framework_rules


# ---------------------------------------------------------------------------
# _build_stack_from_names helper
# ---------------------------------------------------------------------------


class TestBuildStackFromNames:
    def test_web_framework_becomes_primary(self, tmp_path: Path) -> None:
        stack = _build_stack_from_names(["django", "celery"], tmp_path)
        assert stack.primary is not None
        assert stack.primary.name == "django"

    def test_companions_populated(self, tmp_path: Path) -> None:
        stack = _build_stack_from_names(["django", "celery"], tmp_path)
        companion_names = {f.name for f in stack.companions}
        assert "celery" in companion_names

    def test_all_frameworks_populated(self, tmp_path: Path) -> None:
        stack = _build_stack_from_names(["fastapi", "sqlalchemy", "pytest"], tmp_path)
        names = {f.name for f in stack.all_frameworks}
        assert names == {"fastapi", "sqlalchemy", "pytest"}

    def test_unknown_name_skipped(self, tmp_path: Path) -> None:
        stack = _build_stack_from_names(["django", "nonexistent"], tmp_path)
        names = {f.name for f in stack.all_frameworks}
        assert "nonexistent" not in names
        assert "django" in names

    def test_confidence_forced_to_one(self, tmp_path: Path) -> None:
        stack = _build_stack_from_names(["flask"], tmp_path)
        assert stack.primary is not None
        assert stack.primary.confidence == 1.0


# ---------------------------------------------------------------------------
# testing.py utilities
# ---------------------------------------------------------------------------


class TestFrameworkTestingHelpers:
    def test_assert_detects_framework_pass(self, tmp_path: Path) -> None:
        from python_checkup.frameworks.flask import FlaskPlugin
        from python_checkup.frameworks.testing import assert_detects_framework

        # Minimal Flask project
        (tmp_path / "app.py").write_text(
            "from flask import Flask\napp = Flask(__name__)\n"
        )
        (tmp_path / "requirements.txt").write_text("flask>=3.0\n")

        info = assert_detects_framework(FlaskPlugin(), tmp_path)
        assert info.name == "flask"
        assert info.confidence >= 0.5

    def test_assert_detects_framework_fails_empty(self, tmp_path: Path) -> None:
        from python_checkup.frameworks.django import DjangoPlugin
        from python_checkup.frameworks.testing import assert_detects_framework

        with pytest.raises(AssertionError, match="confidence"):
            assert_detects_framework(DjangoPlugin(), tmp_path)

    def test_assert_check_finds_pass(self, tmp_path: Path) -> None:
        from python_checkup.frameworks.django import DjangoPlugin
        from python_checkup.frameworks.testing import assert_check_finds

        settings = tmp_path / "settings.py"
        settings.write_text("DEBUG = True\n")
        diags = assert_check_finds(DjangoPlugin(), tmp_path, ["FW-DJ-001"])
        assert any(d.rule_id == "FW-DJ-001" for d in diags)

    def test_assert_check_finds_fails_missing_rule(self, tmp_path: Path) -> None:
        from python_checkup.frameworks.flask import FlaskPlugin
        from python_checkup.frameworks.testing import assert_check_finds

        with pytest.raises(AssertionError, match="FW-ZZ-999"):
            assert_check_finds(FlaskPlugin(), tmp_path, ["FW-ZZ-999"])

    def test_assert_whitelist_suppresses_pass(self) -> None:
        # Use a whitelist entry that matches functions (conftest fixtures)
        from python_checkup.frameworks.pytest_fw import PytestPlugin
        from python_checkup.frameworks.testing import assert_whitelist_suppresses

        # "client" is a common pytest fixture name in PYTEST_WHITELIST
        assert_whitelist_suppresses(PytestPlugin(), ["client"], ["client"])

    def test_assert_whitelist_suppresses_fail(self) -> None:
        from python_checkup.frameworks.flask import FlaskPlugin
        from python_checkup.frameworks.testing import assert_whitelist_suppresses

        with pytest.raises(AssertionError):
            assert_whitelist_suppresses(
                FlaskPlugin(), ["nonexistent_func"], ["nonexistent_func"]
            )
