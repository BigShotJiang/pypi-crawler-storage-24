from __future__ import annotations

from pathlib import Path

import pytest

from python_checkup.analysis_request import AnalysisRequest
from python_checkup.analyzers.radon import RadonAnalyzer
from python_checkup.config import CheckupConfig
from python_checkup.models import Category


def _request(files: list[Path]) -> AnalysisRequest:
    root = files[0].parent if files else Path(".")
    return AnalysisRequest(
        project_root=root,
        files=files,
        config=CheckupConfig(),
        categories={Category.COMPLEXITY},
        profile="default",
        metadata={},
    )


class TestRadonAnalyzer:
    async def test_name_and_category(self) -> None:
        analyzer = RadonAnalyzer()
        assert analyzer.name == "radon"
        assert analyzer.category == Category.COMPLEXITY

    async def test_analyze_high_complexity(self, tmp_path: Path) -> None:
        analyzer = RadonAnalyzer()
        if not await analyzer.is_available():
            pytest.skip("Radon not available")

        # Write a deliberately complex function (CC >= 21, grade D)
        complex_file = tmp_path / "complex.py"
        lines = [
            "def tangled(a, b, c, d, e, f, g, h, i, j, k):",
            "    if a and b:",
            "        if c:",
            "            if d:",
            "                if e:",
            "                    if f:",
            "                        if g:",
            "                            return 1",
            "                        else:",
            "                            return 2",
            "                    else:",
            "                        return 3",
            "                else:",
            "                    return 4",
            "            else:",
            "                return 5",
            "        else:",
            "            return 6",
            "    elif b:",
            "        if c:",
            "            return 7",
            "        elif d:",
            "            return 8",
            "        elif e:",
            "            return 9",
            "        else:",
            "            return 10",
            "    elif c:",
            "        if d:",
            "            return 11",
            "        else:",
            "            return 12",
            "    elif d:",
            "        if e:",
            "            return 13",
            "        else:",
            "            return 14",
            "    elif e:",
            "        if f:",
            "            return 15",
            "        else:",
            "            return 16",
            "    elif f:",
            "        return 17",
            "    elif g:",
            "        return 18",
            "    elif h:",
            "        return 19",
            "    elif i:",
            "        return 20",
            "    elif j:",
            "        return 21",
            "    elif k:",
            "        return 22",
            "    else:",
            "        return 0",
        ]
        complex_file.write_text("\n".join(lines) + "\n")

        request = _request([complex_file])
        results = await analyzer.analyze(request)

        assert len(results) > 0
        assert results[0].tool == "radon"
        assert results[0].category == Category.COMPLEXITY
        assert "tangled" in results[0].message
        assert results[0].rule_id.startswith("CC-")

        # Check MI scores were stored
        assert "_radon_mi_scores" in request.metadata
        mi_scores = request.metadata["_radon_mi_scores"]
        assert isinstance(mi_scores, list)
        assert len(mi_scores) > 0

    async def test_analyze_simple_function(self, tmp_path: Path) -> None:
        analyzer = RadonAnalyzer()
        if not await analyzer.is_available():
            pytest.skip("Radon not available")

        simple_file = tmp_path / "simple.py"
        simple_file.write_text("def add(a: int, b: int) -> int:\n    return a + b\n")

        request = _request([simple_file])
        results = await analyzer.analyze(request)

        # Simple function (CC=1, grade A) should not produce diagnostics
        assert len(results) == 0

        # But MI score should still be computed
        assert "_radon_mi_scores" in request.metadata
        mi_scores = request.metadata["_radon_mi_scores"]
        assert isinstance(mi_scores, list)
        assert mi_scores[0] > 50  # Simple code = high MI

    async def test_analyze_empty_files(self) -> None:
        analyzer = RadonAnalyzer()
        results = await analyzer.analyze(_request([]))
        assert results == []
