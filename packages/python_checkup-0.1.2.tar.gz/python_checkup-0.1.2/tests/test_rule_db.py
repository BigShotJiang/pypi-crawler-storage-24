from __future__ import annotations

from python_checkup.skills.rule_db import (
    RULE_DATABASE,
    explain_rule,
    generate_skill_content,
    get_rule_doc,
)


class TestRuleDatabase:
    def test_has_minimum_rules(self) -> None:
        """Database should have at least 30 rules to be useful."""
        assert len(RULE_DATABASE) >= 30

    def test_all_rules_have_required_fields(self) -> None:
        for rule_id, doc in RULE_DATABASE.items():
            assert doc.rule_id == rule_id
            assert doc.name, f"{rule_id} missing name"
            assert doc.tool, f"{rule_id} missing tool"
            assert doc.category, f"{rule_id} missing category"
            assert doc.description, f"{rule_id} missing description"
            assert doc.example_bad, f"{rule_id} missing example_bad"
            assert doc.example_good, f"{rule_id} missing example_good"
            assert doc.fix, f"{rule_id} missing fix"

    def test_categories_are_valid(self) -> None:
        valid_categories = {
            "quality",
            "security",
            "complexity",
            "type_safety",
            "dead_code",
            "dependencies",
        }
        for rule_id, doc in RULE_DATABASE.items():
            assert doc.category in valid_categories, (
                f"{rule_id} has invalid category: {doc.category}"
            )

    def test_severities_are_valid(self) -> None:
        valid_severities = {"error", "warning", "info"}
        for rule_id, doc in RULE_DATABASE.items():
            assert doc.severity in valid_severities, (
                f"{rule_id} has invalid severity: {doc.severity}"
            )

    def test_covers_all_six_categories(self) -> None:
        """Database should have rules from every category."""
        categories = {doc.category for doc in RULE_DATABASE.values()}
        expected = {
            "quality",
            "security",
            "complexity",
            "type_safety",
            "dead_code",
            "dependencies",
        }
        assert categories == expected


class TestGetRuleDoc:
    def test_direct_lookup(self) -> None:
        doc = get_rule_doc("F401")
        assert doc is not None
        assert doc.name == "unused-import"

    def test_direct_lookup_security(self) -> None:
        doc = get_rule_doc("S101")
        assert doc is not None
        assert doc.category == "security"

    def test_bandit_alias(self) -> None:
        """Bandit B-prefix should map to Ruff S-prefix."""
        doc = get_rule_doc("B101")
        assert doc is not None
        assert doc.rule_id == "S101"

    def test_bandit_alias_602(self) -> None:
        doc = get_rule_doc("B602")
        assert doc is not None
        assert doc.rule_id == "S602"

    def test_mypy_bracket_alias(self) -> None:
        """mypy [error-code] should map to mypy-error-code."""
        doc = get_rule_doc("[return-value]")
        assert doc is not None
        assert doc.rule_id == "mypy-return-value"

    def test_mypy_bracket_alias_assignment(self) -> None:
        doc = get_rule_doc("[assignment]")
        assert doc is not None
        assert doc.rule_id == "mypy-assignment"

    def test_unknown_rule(self) -> None:
        assert get_rule_doc("XYZZY999") is None

    def test_non_digit_b_prefix_not_aliased(self) -> None:
        """B006 (mutable default) is in the DB directly, not as S006."""
        doc = get_rule_doc("B006")
        assert doc is not None
        assert doc.rule_id == "B006"


class TestExplainRule:
    def test_known_rule(self) -> None:
        explanation = explain_rule("S101")
        assert "assert" in explanation.lower()
        assert "security" in explanation.lower()
        assert "```python" in explanation

    def test_unknown_rule(self) -> None:
        explanation = explain_rule("UNKNOWN999")
        assert "Unknown rule" in explanation

    def test_explanation_has_sections(self) -> None:
        explanation = explain_rule("F401")
        assert "## F401" in explanation
        assert "Bad" in explanation
        assert "Good" in explanation
        assert "How to fix" in explanation

    def test_explanation_includes_help_url(self) -> None:
        explanation = explain_rule("F401")
        assert "Reference" in explanation
        assert "https://" in explanation

    def test_explanation_no_url_for_mypy(self) -> None:
        """mypy rules don't have help_url, so no Reference section."""
        explanation = explain_rule("mypy-return-value")
        assert "Reference" not in explanation


class TestGenerateSkillContent:
    def test_generates_content(self) -> None:
        content = generate_skill_content()
        assert "# python-checkup Skill" in content
        assert "Code Quality" in content
        assert "Security" in content

    def test_includes_rule_ids(self) -> None:
        content = generate_skill_content()
        assert "F401" in content
        assert "S101" in content
