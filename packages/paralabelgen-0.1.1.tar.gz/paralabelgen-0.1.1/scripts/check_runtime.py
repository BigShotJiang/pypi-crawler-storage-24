"""Runtime validation for the current labelgen workspace.

This script performs a minimal end-to-end check for both the default NLP path
and the deterministic fallback path. It is intended for local validation before
release work and is not part of the published package surface.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass

from labelgen import LabelGenerator, LabelGeneratorConfig


@dataclass(slots=True)
class RuntimeCheckResult:
    """Structured runtime validation summary."""

    extractor_name: str
    detector_name: str
    concept_count: int
    community_count: int
    paragraph_label_ids: list[list[str]]


def _run_pipeline(config: LabelGeneratorConfig) -> RuntimeCheckResult:
    """Run a tiny corpus through the configured pipeline."""

    paragraphs = [
        "OpenAI builds language models for developers.",
        "Developers use language models in production systems.",
        "Production systems need monitoring and deployment tooling.",
    ]
    generator = LabelGenerator(config)
    result = generator.fit_transform(paragraphs)
    return RuntimeCheckResult(
        extractor_name=generator.extractor_name,
        detector_name=generator.detector_name,
        concept_count=len(result.concepts),
        community_count=len(result.communities),
        paragraph_label_ids=[item.label_ids for item in result.paragraph_labels],
    )


def main() -> int:
    """Run runtime validation and print a JSON summary."""

    checks = {
        "default": _run_pipeline(LabelGeneratorConfig()),
        "fallback": _run_pipeline(
            LabelGeneratorConfig(
                use_nlp_extractor=False,
                use_graph_community_detection=False,
            )
        ),
    }
    print(json.dumps({key: asdict(value) for key, value in checks.items()}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
