# Local Validation Scripts

These scripts are intended for repository-local validation and release checks.
They are versioned with the repository, but they are not part of the published
package API.

## `check_runtime.py`

Runs a minimal end-to-end validation for:

- the default spaCy + Leiden pipeline
- the deterministic fallback pipeline

Example:

```bash
~/Repo/temp/.venv/bin/python scripts/check_runtime.py
```

## `run_techqa_eval.py`

Runs a small bounded comparison on cached TechQA data.

The script expects access to a local `TechQA.tar.gz` cache file. You can pass
it explicitly:

```bash
~/Repo/temp/.venv/bin/python scripts/run_techqa_eval.py \
  --archive-path /path/to/TechQA.tar.gz
```

Or provide it through an environment variable:

```bash
export TECHQA_ARCHIVE_PATH=/path/to/TechQA.tar.gz
~/Repo/temp/.venv/bin/python scripts/run_techqa_eval.py
```

The script emits a JSON summary with:

- sample preview paragraphs
- extractor and detector names
- concept and community counts
- representative extracted concepts
- first paragraph label IDs
