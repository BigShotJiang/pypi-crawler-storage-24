"""Run a small TechQA default-vs-fallback comparison.

The script samples a bounded number of paragraphs directly from the cached
TechQA tarball and runs both the default pipeline and the deterministic fallback
pipeline on the same sample. It is intended for local evaluation and release
validation, not as a published user-facing entrypoint.
"""

from __future__ import annotations

import argparse
import io
import json
import os
import random
import re
import tarfile
from dataclasses import asdict, dataclass
from pathlib import Path

from labelgen import LabelGenerator, LabelGeneratorConfig

TECHQA_MEMBER = "TechQA/technote_corpus/technotes.id_title_text"
_URL_LIKE_RE = re.compile(r"(?:https?://|www\.|<host>|<port>|docview\.wss)", re.IGNORECASE)
_BOILERPLATE_RE = re.compile(
    r"(?:subscribe|all active apars|direct links|references|apar information)",
    re.IGNORECASE,
)


@dataclass(slots=True)
class EvaluationSummary:
    """Compact summary for one pipeline configuration."""

    extractor_name: str
    detector_name: str
    concept_count: int
    community_count: int
    first_concepts: list[str]
    first_label_ids: list[str]


def _sample_paragraphs(
    archive_path: Path,
    *,
    sample_size: int,
    min_length: int,
    seed: int,
    byte_limit: int,
) -> list[str]:
    """Sample a bounded set of paragraphs from the TechQA corpus tarball."""

    rng = random.Random(seed)
    paragraphs: list[str] = []

    with tarfile.open(archive_path, "r:gz") as archive:
        member = archive.getmember(TECHQA_MEMBER)
        extracted = archive.extractfile(member)
        if extracted is None:
            raise RuntimeError("Failed to extract TechQA technote corpus from tarball.")
        reader = io.TextIOWrapper(extracted, encoding="utf-8", errors="ignore")
        for line in reader:
            parts = line.rstrip("\n").split("\t", 2)
            if len(parts) != 3:
                continue
            _, _, text = parts
            for chunk in text.split("\n\n"):
                cleaned = " ".join(chunk.split())
                if len(cleaned) < min_length:
                    continue
                if _should_skip_paragraph(cleaned):
                    continue
                if len(paragraphs) < sample_size:
                    paragraphs.append(cleaned)
                else:
                    index = rng.randint(0, len(paragraphs))
                    if index < sample_size:
                        paragraphs[index] = cleaned
            if len(paragraphs) >= sample_size and reader.buffer.tell() > byte_limit:
                break

    if not paragraphs:
        raise RuntimeError("No paragraphs were sampled from the TechQA corpus.")
    return paragraphs


def _should_skip_paragraph(text: str) -> bool:
    """Return whether a sampled paragraph is too boilerplate-heavy for evaluation."""

    if _URL_LIKE_RE.search(text):
        return True
    if _BOILERPLATE_RE.search(text):
        return True
    return False


def _evaluate(config: LabelGeneratorConfig, paragraphs: list[str]) -> EvaluationSummary:
    """Evaluate one pipeline configuration on the provided paragraphs."""

    generator = LabelGenerator(config)
    result = generator.fit_transform(paragraphs)
    first_labels = result.paragraph_labels[0].label_ids if result.paragraph_labels else []
    return EvaluationSummary(
        extractor_name=generator.extractor_name,
        detector_name=generator.detector_name,
        concept_count=len(result.concepts),
        community_count=len(result.communities),
        first_concepts=[concept.normalized for concept in result.concepts[:12]],
        first_label_ids=first_labels,
    )


def _build_parser() -> argparse.ArgumentParser:
    """Build the CLI argument parser."""

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--archive-path",
        type=Path,
        default=None,
        help=(
            "Path to the cached TechQA tarball. If omitted, the script checks "
            "TECHQA_ARCHIVE_PATH and then a small set of common local cache paths."
        ),
    )
    parser.add_argument("--sample-size", type=int, default=8)
    parser.add_argument("--min-length", type=int, default=120)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--byte-limit", type=int, default=2_000_000)
    parser.add_argument(
        "--output",
        type=Path,
        default=None,
        help="Optional path for writing the JSON summary.",
    )
    return parser


def _resolve_archive_path(configured_path: Path | None) -> Path:
    """Resolve the TechQA tarball path from CLI input, env, or known local paths."""

    candidates: list[Path] = []
    if configured_path is not None:
        candidates.append(configured_path)

    env_path = os.environ.get("TECHQA_ARCHIVE_PATH")
    if env_path:
        candidates.append(Path(env_path))

    home = Path.home()
    candidates.extend(
        [
            home
            / "Repo/temp/hf/hub/datasets--PrimeQA--TechQA/snapshots"
            / "60437bc79ab217679682217598a3693cab78365b/TechQA.tar.gz",
            home
            / "repo/temp/hf/hub/datasets--PrimeQA--TechQA/snapshots"
            / "60437bc79ab217679682217598a3693cab78365b/TechQA.tar.gz",
        ]
    )

    for candidate in candidates:
        if candidate.exists():
            return candidate

    raise FileNotFoundError(
        "Could not locate TechQA.tar.gz. Pass --archive-path or set "
        "TECHQA_ARCHIVE_PATH to the cached tarball."
    )


def main() -> int:
    """Run the TechQA comparison and emit a JSON summary."""

    parser = _build_parser()
    args = parser.parse_args()
    archive_path = _resolve_archive_path(args.archive_path)
    paragraphs = _sample_paragraphs(
        archive_path,
        sample_size=args.sample_size,
        min_length=args.min_length,
        seed=args.seed,
        byte_limit=args.byte_limit,
    )
    summary = {
        "archive_path": str(archive_path),
        "sample_count": len(paragraphs),
        "sample_preview": paragraphs[:3],
        "default": asdict(_evaluate(LabelGeneratorConfig(), paragraphs)),
        "fallback": asdict(
            _evaluate(
                LabelGeneratorConfig(
                    use_nlp_extractor=False,
                    use_graph_community_detection=False,
                ),
                paragraphs,
            )
        ),
    }
    payload = json.dumps(summary, indent=2)
    print(payload)
    if args.output is not None:
        args.output.write_text(payload, encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
