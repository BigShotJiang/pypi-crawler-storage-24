def main() -> None:
    print("Hello from test-asuka-mcp!")
