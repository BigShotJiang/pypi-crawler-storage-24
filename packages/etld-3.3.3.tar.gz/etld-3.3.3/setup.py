import os
from setuptools import setup, find_packages  # noqa: H301

# Leemos el súper README para que PyPI lo muestre bonito
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

NAME = "etld"
VERSION = "3.3.3"
PYTHON_REQUIRES = ">= 3.9"
REQUIRES = [
    "urllib3 >= 2.1.0, < 3.0.0",
    "python-dateutil >= 2.8.2",
    "pydantic >= 2",
    "typing-extensions >= 4.7.1",
]

setup(
    name=NAME,
    version=VERSION,
    description="ETL-D API: The Agentic Data & Finance Middleware",
    author="ETL-D",
    author_email="info@etl-d.net",
    url="https://api.etl-d.net",
    keywords=["OpenAPI", "OpenAPI-Generator", "ETL-D API", "Agentic", "Finance", "AI"],
    install_requires=REQUIRES,
    packages=find_packages(exclude=["test", "tests"]),
    include_package_data=True,
    long_description_content_type='text/markdown',
    long_description=long_description,  # <--- AQUÍ ESTÁ LA MAGIA
    package_data={"etld": ["py.typed"]},
)