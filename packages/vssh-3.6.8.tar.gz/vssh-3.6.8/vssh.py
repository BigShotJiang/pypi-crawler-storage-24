#!/usr/bin/env python3
"""
vssh: Distributed command & file transport daemon for server meshes
- Cluster transport protocol: RPC, file transfer, command execution, terminal
- Every node is a peer (client + server), full mesh topology
- Wire VPN → Tailscale automatic failover
- HMAC-SHA256 authentication, single TCP port 48291
"""

import socket, sys, os, struct, hashlib, time, threading, json, mmap, hmac as hmac_lib, zlib
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Tuple, Optional


# ========== Standalone Config (no mpop dependency) ==========
VSSH_DIR_CONF = Path.home() / '.vssh'

def _load_vssh_config():
    conf = {}
    cf = VSSH_DIR_CONF / 'config'
    if cf.exists():
        for line in cf.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith('#'): continue
            if '=' in line:
                k, v = line.split('=', 1)
                conf[k.strip()] = v.strip()
    return conf

def _load_vssh_secret():
    s = os.environ.get('VSSH_SECRET', '')
    if s: return s
    sf = VSSH_DIR_CONF / 'secret'
    if sf.exists():
        s = sf.read_text().strip()
        if s: return s
    conf = _load_vssh_config()
    s = conf.get('SECRET', '')
    if s: return s
    # Auto-generate on first install
    import secrets as _sec
    s = _sec.token_hex(16)
    VSSH_DIR_CONF.mkdir(parents=True, exist_ok=True)
    sf.write_text(s)
    return s

VSSH_CONFIG = _load_vssh_config()
SECRET = _load_vssh_secret()
PORT = 48291
HMAC_WINDOW = 60  # seconds - allow 60s clock skew

# ========== Tailscale Failover ==========
# Wire IP → Tailscale IP mapping for automatic fallback
# Loaded from ~/.vssh/config (TAILSCALE.<wire_ip> = <ts_ip>) or ~/.vssh/tailscale_map

def _load_tailscale_map() -> dict:
    """Load Wire VPN IP → Tailscale IP mapping.
    Priority: manual config > tailscale_map file > auto-detect (tailscale + wire server)
    """
    ts_map = {}

    # 1. From config: TAILSCALE.10.99.85.143 = 100.80.191.6
    for k, v in VSSH_CONFIG.items():
        if k.startswith('TAILSCALE.'):
            wire_ip = k[len('TAILSCALE.'):]
            ts_map[wire_ip] = v

    # 2. From dedicated file: ~/.vssh/tailscale_map
    ts_file = VSSH_DIR_CONF / 'tailscale_map'
    if ts_file.exists():
        try:
            for line in ts_file.read_text().splitlines():
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                parts = line.split()
                if len(parts) >= 2:
                    ts_map[parts[0]] = parts[1]  # wire_ip tailscale_ip
        except (OSError, ValueError):
            pass

    # 3. Auto-detect: cross-reference `tailscale status --json` + wire /peers
    if not ts_map:
        try:
            import urllib.request as _ur, subprocess as _sp2
            ts_out = _sp2.run(['tailscale', 'status', '--json'],
                              capture_output=True, text=True, timeout=5)
            if ts_out.returncode == 0:
                ts_data = json.loads(ts_out.stdout)
                ts_host = {}
                for peer in list(ts_data.get('Peer', {}).values()) + [ts_data.get('Self', {})]:
                    if not peer:
                        continue
                    name = peer.get('HostName', '').lower().split('.')[0]
                    ips = [ip for ip in peer.get('TailscaleIPs', []) if ':' not in ip]
                    if name and ips:
                        ts_host[name] = ips[0]
                for srv_ip in ['10.99.85.143', '158.247.247.115']:
                    try:
                        with _ur.urlopen(f'http://{srv_ip}:8790/peers', timeout=3) as r:
                            for p in json.loads(r.read()).get('peers', []):
                                name = p.get('node_name', '').lower()
                                wire_ip = p.get('vpn_ip', '')
                                ts_ip = ts_host.get(name)
                                if wire_ip and ts_ip:
                                    ts_map[wire_ip] = ts_ip
                        break
                    except Exception:
                        continue
        except Exception:
            pass

    return ts_map

TAILSCALE_MAP = _load_tailscale_map()
_FAILOVER_ACTIVE = {}  # host -> (tailscale_ip, timestamp) — Wire retry after 60s
_FAILOVER_RETRY_INTERVAL = 60  # seconds before retrying Wire after failover

def vssh_connect(host: str, timeout: float = 5.0) -> socket.socket:
    """Connect to vssh server with automatic Tailscale failover.

    1. Try Wire VPN IP (primary)
    2. If Wire fails → try Tailscale IP (fallback), cache for 60s
    3. After 60s, retry Wire — if Wire recovered, clear failover cache

    Returns connected socket or raises ConnectionError.
    """
    # If this host recently failed Wire, use cached Tailscale (but retry Wire after 60s)
    if host in _FAILOVER_ACTIVE:
        ts_ip, failover_time = _FAILOVER_ACTIVE[host]
        if time.time() - failover_time < _FAILOVER_RETRY_INTERVAL:
            # Still within retry window — use Tailscale directly
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(timeout)
                sock.connect((ts_ip, PORT))
                return sock
            except (OSError, socket.error):
                # Tailscale also failed — clear cache, fall through to Wire retry
                del _FAILOVER_ACTIVE[host]
        else:
            # 60s elapsed — try Wire again first (Wire may have recovered)
            del _FAILOVER_ACTIVE[host]

    # Primary: try Wire VPN IP
    # First attempt: 2s fast path
    # If timeout (cold WireGuard peer re-handshake), retry once with longer timeout
    _wire_refused = False
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(min(timeout, 2.0))  # 2s: fast path
        sock.connect((host, PORT))
        sock.settimeout(timeout)
        return sock
    except ConnectionRefusedError:
        _wire_refused = True  # Port closed — no point retrying
    except (ConnectionError, OSError, socket.timeout):
        pass  # Timeout — WireGuard may be re-handshaking, retry once

    if not _wire_refused:
        # Retry: wait 1s for WireGuard handshake to complete, then retry
        time.sleep(1.0)
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(min(timeout, 5.0))  # 5s: handshake should be done by now
            sock.connect((host, PORT))
            sock.settimeout(timeout)
            return sock
        except (ConnectionRefusedError, ConnectionError, OSError, socket.timeout):
            pass  # Wire truly failed, fall through to Tailscale

    # Fallback: try Tailscale IP
    ts_ip = TAILSCALE_MAP.get(host)
    if not ts_ip:
        raise ConnectionError(f'Wire failed for {host}, no Tailscale mapping')

    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        sock.connect((ts_ip, PORT))
        _FAILOVER_ACTIVE[host] = (ts_ip, time.time())
        print(f'[FAILOVER] {host} → {ts_ip} (Tailscale)')
        return sock
    except Exception:
        raise ConnectionError(
            f'Both Wire ({host}) and Tailscale ({ts_ip}) failed'
        )

# ========== Transfer Logging ==========
VSSH_DIR = Path.home() / '.vssh'
LOG_FILE = VSSH_DIR / 'transfer.log'
HISTORY_FILE = VSSH_DIR / 'history.log'
LOG_MAX_SIZE = 10 * 1024 * 1024  # 10MB max log size

def _rotate_log(path):
    """Rotate log file if it exceeds max size"""
    if path.exists() and path.stat().st_size > LOG_MAX_SIZE:
        backup = path.with_suffix('.log.1')
        if backup.exists():
            backup.unlink()
        path.rename(backup)

def log_transfer(op: str, host: str, path: str, size: int, duration: float, status: str):
    """Log a transfer to ~/.vssh/transfer.log"""
    try:
        VSSH_DIR.mkdir(exist_ok=True)
        speed = size / duration / 1024 / 1024 if duration > 0 else 0
        size_mb = size / 1024 / 1024
        ts = time.strftime('%Y-%m-%d %H:%M:%S')
        line = f'{ts} {op} {host}:{path} {size_mb:.1f}MB {duration:.1f}s {speed:.1f}MB/s {status}\n'

        _rotate_log(LOG_FILE)
        with open(LOG_FILE, 'a') as f:
            f.write(line)
    except OSError:
        pass  # Don't fail on logging errors

def log_event(op: str, host: str, detail: str, status: str = 'OK'):
    """Log any vssh event to ~/.vssh/history.log

    Unified history for all operations: SSH, RPC, PUT, GET, SESSION, etc.
    Format: timestamp op host detail status
    """
    try:
        VSSH_DIR.mkdir(exist_ok=True)
        ts = time.strftime('%Y-%m-%d %H:%M:%S')
        # Truncate detail to 200 chars to keep log readable
        detail_clean = detail.replace('\n', ' ').strip()[:200]
        line = f'{ts}\t{op}\t{host}\t{detail_clean}\t{status}\n'

        _rotate_log(HISTORY_FILE)
        with open(HISTORY_FILE, 'a') as f:
            f.write(line)
    except OSError:
        pass  # safe to ignore

def get_history(count: int = 20, op_filter: str = None, host_filter: str = None) -> list:
    """Get recent history entries, optionally filtered by op or host"""
    if not HISTORY_FILE.exists():
        return []

    entries = []
    with open(HISTORY_FILE) as f:
        for line in f:
            parts = line.strip().split('\t')
            if len(parts) < 4:
                continue
            ts, op, host, detail = parts[0], parts[1], parts[2], parts[3]
            status = parts[4] if len(parts) > 4 else 'OK'

            if op_filter and op_filter.upper() != op:
                continue
            if host_filter and host_filter != host:
                continue

            entries.append({'time': ts, 'op': op, 'host': host, 'detail': detail, 'status': status})

    return entries[-count:]

def get_transfer_stats(days: int = 7) -> dict:
    """Get transfer statistics for the last N days"""
    if not LOG_FILE.exists():
        return {'total': 0, 'size_mb': 0, 'by_op': {}, 'by_host': {}}

    cutoff = time.time() - days * 86400
    stats = {'total': 0, 'size_mb': 0, 'by_op': {}, 'by_host': {}, 'success': 0, 'fail': 0}

    with open(LOG_FILE) as f:
        for line in f:
            try:
                parts = line.strip().split()
                if len(parts) < 7:
                    continue
                date_str = parts[0] + ' ' + parts[1]
                ts = time.mktime(time.strptime(date_str, '%Y-%m-%d %H:%M:%S'))
                if ts < cutoff:
                    continue

                op = parts[2]
                target = parts[3]
                host = target.split(':')[0]
                size_mb = float(parts[4].replace('MB', ''))
                status = parts[-1]

                stats['total'] += 1
                stats['size_mb'] += size_mb
                stats['by_op'][op] = stats['by_op'].get(op, 0) + 1
                stats['by_host'][host] = stats['by_host'].get(host, 0) + 1
                if status == 'OK':
                    stats['success'] += 1
                else:
                    stats['fail'] += 1
            except Exception:
                continue

    return stats

# ========== Retry Configuration ==========
RETRY_MAX = 3        # Max retry attempts
RETRY_DELAY = 1      # Initial delay in seconds
RETRY_BACKOFF = 2    # Exponential backoff multiplier

def with_retry(func, *args, max_retries=RETRY_MAX, **kwargs):
    """Execute function with automatic retry on NETWORK failures only

    Uses exponential backoff: 1s, 2s, 4s
    Only retries on socket/connection errors, not on logical failures (False result)
    Returns (success, result) tuple
    """
    delay = RETRY_DELAY
    last_error = None

    for attempt in range(max_retries + 1):
        try:
            result = func(*args, **kwargs)
            # Return immediately - don't retry logical failures (False result)
            return result, result
        except (socket.error, ConnectionError, TimeoutError, OSError) as e:
            last_error = e
            if attempt < max_retries:
                print(f'  Retry {attempt + 1}/{max_retries} in {delay}s... ({e})')
                time.sleep(delay)
                delay *= RETRY_BACKOFF
            continue
        except Exception as e:
            # Non-retryable error (not network related)
            print(f'  Error: {e}')
            return False, None

    if last_error:
        print(f'  Failed after {max_retries} retries: {last_error}')
    return False, None

# ========== HMAC Authentication ==========
def compute_hmac(secret: str, timestamp: int) -> str:
    """Compute HMAC-SHA256(secret, timestamp)"""
    return hmac_lib.new(
        secret.encode(),
        str(timestamp).encode(),
        hashlib.sha256
    ).hexdigest()[:32]

def generate_hmac_token(secret: str) -> str:
    """Generate HMAC auth token for client use"""
    ts = int(time.time())
    h = compute_hmac(secret, ts)
    return f"hmac_{ts}_{h}"

def verify_auth(received: str, expected_secret: str) -> bool:
    """Verify auth - supports both HMAC and plaintext (backward compat)"""
    if not expected_secret:
        return False

    # HMAC auth: hmac_{timestamp}_{hash}
    if received.startswith("hmac_"):
        parts = received.split("_")
        if len(parts) != 3:
            return False
        try:
            ts = int(parts[1])
            received_hmac = parts[2]
        except (ValueError, IndexError):
            return False

        # Check timestamp within window
        now = int(time.time())
        if abs(now - ts) > HMAC_WINDOW:
            return False

        # Verify HMAC
        expected_hmac = compute_hmac(expected_secret, ts)
        return hmac_lib.compare_digest(received_hmac, expected_hmac)

    # Plaintext fallback (backward compat - will be deprecated)
    return received == expected_secret

def get_auth_token() -> str:
    """Get auth token - uses HMAC if SECRET is set, otherwise empty"""
    if SECRET:
        return generate_hmac_token(SECRET)
    return ""

# ========== Compression ==========
# File types that compress well (text, source code, logs)
COMPRESSIBLE_EXTS = {'.txt', '.log', '.py', '.js', '.ts', '.json', '.xml', '.html', '.css', '.md', '.yaml', '.yml', '.sh', '.sql', '.csv'}
COMPRESS_MIN_SIZE = 4096  # Don't compress files smaller than 4KB
COMPRESS_LEVEL = 6  # zlib level 1-9 (6 is good balance)

def should_compress(path: Path, size: int) -> bool:
    """Determine if file should be compressed based on extension and size"""
    if size < COMPRESS_MIN_SIZE:
        return False
    return path.suffix.lower() in COMPRESSIBLE_EXTS

def compress_data(data: bytes) -> bytes:
    """Compress data using zlib (gzip compatible)"""
    return zlib.compress(data, COMPRESS_LEVEL)

def decompress_data(data: bytes) -> bytes:
    """Decompress zlib data"""
    return zlib.decompress(data)

# ========== LAN Detection ==========
# Detect if target is on same LAN for faster direct transfer

def get_local_ips() -> list:
    """Get all local (non-VPN) IP addresses"""
    ips = []
    try:
        import subprocess
        # macOS/Linux: get IPs from ifconfig/ip
        if sys.platform == 'darwin':
            r = subprocess.run(['ifconfig'], capture_output=True, text=True, timeout=5)
            for line in r.stdout.split('\n'):
                if 'inet ' in line and '127.0.0.1' not in line:
                    parts = line.strip().split()
                    idx = parts.index('inet') + 1
                    ip = parts[idx]
                    # Skip VPN IPs (10.99.x.x for wire)
                    if not ip.startswith('10.99.'):
                        ips.append(ip)
        else:
            r = subprocess.run(['ip', '-4', 'addr'], capture_output=True, text=True, timeout=5)
            for line in r.stdout.split('\n'):
                if 'inet ' in line and '127.0.0.1' not in line:
                    # Format: inet 192.168.1.10/24 ...
                    parts = line.strip().split()
                    ip = parts[1].split('/')[0]
                    if not ip.startswith('10.99.'):
                        ips.append(ip)
    except (OSError, subprocess.SubprocessError):
        pass  # safe to ignore
    return ips

def get_public_ip() -> str:
    """Get public IP via external service"""
    try:
        import urllib.request
        # Try multiple services
        for url in ['https://api.ipify.org', 'https://ifconfig.me/ip', 'https://icanhazip.com']:
            try:
                with urllib.request.urlopen(url, timeout=3) as r:
                    return r.read().decode().strip()
            except (urllib.error.URLError, OSError):
                continue
    except Exception as e:
        pass  # e silenced
    return ''

def get_network_info_local() -> dict:
    """Get local network info (for client side)"""
    return {
        'local_ips': get_local_ips(),
        'public_ip': get_public_ip(),
    }

# Cache for network info (public IP doesn't change often)
_network_info_cache = {'public_ip': '', 'ts': 0}
_CACHE_TTL = 300  # 5 minutes

def get_cached_public_ip() -> str:
    """Get public IP with caching"""
    global _network_info_cache
    if time.time() - _network_info_cache['ts'] > _CACHE_TTL:
        _network_info_cache['public_ip'] = get_public_ip()
        _network_info_cache['ts'] = time.time()
    return _network_info_cache['public_ip']

def is_safe_network(host: str) -> Tuple[bool, str]:
    """Check if host is on a safe (encrypted) network

    Safe networks:
    - VPN (10.99.x.x) - WireGuard encrypted
    - LAN (192.168.x.x, 10.x.x.x non-VPN) - local network
    - localhost (127.x.x.x)

    Unsafe:
    - Public IP - unencrypted over internet!

    Returns: (is_safe, reason)
    """
    # Localhost - always safe
    if host.startswith('127.'):
        return True, "localhost"

    # VPN - encrypted by WireGuard
    if host.startswith('10.99.'):
        return True, "vpn"

    # Private IPs (LAN) - safe within local network
    if host.startswith('192.168.'):
        return True, "lan"
    if host.startswith('10.'):
        return True, "lan"
    if host.startswith('172.'):
        # 172.16.0.0 - 172.31.255.255
        try:
            second = int(host.split('.')[1])
            if 16 <= second <= 31:
                return True, "lan"
        except (ValueError, IndexError) as e:
            pass  # e silenced

    # Everything else is public IP - UNSAFE!
    return False, "public_ip_unencrypted"


def check_transfer_safety(host: str) -> bool:
    """Check if transfer to host is safe, block if not

    Returns: True if safe to proceed, False if blocked
    """
    is_safe, reason = is_safe_network(host)

    if is_safe:
        return True

    print(f"BLOCKED: {host} is a public IP")
    print(f"         vssh does NOT encrypt data - unsafe over internet!")
    print(f"")
    print(f"Safe alternatives:")
    print(f"  1. Use SSH/SCP:  scp file root@{host}:/path")
    print(f"  2. Use VPN IP:   vssh put file 10.99.x.x:/path")
    return False



# Wire VPN coordinator servers for name resolution
WIRE_SERVERS = ["10.99.85.143", "158.247.247.115", "10.99.74.131", "10.99.249.158"]
_name_cache = {}  # name -> vpn_ip
_name_cache_time = 0

def resolve_name(host: str) -> str:
    """Resolve server name to VPN IP via Wire VPN /peers API (coordinator-first)

    Priority:
      1. Fresh in-memory cache (< 60s) — avoids repeated network calls
      2. Wire coordinator /peers — source of truth (IPs change when nodes move)
      3. ~/.vssh/config static mapping — fallback when coordinator unreachable
    """
    global _name_cache, _name_cache_time
    # Strip user@ prefix
    if '@' in host:
        host = host.split('@', 1)[1]
    if not host or host[0].isdigit():
        return host
    # 1. Use fresh cache — coordinator already queried recently
    if host in _name_cache and time.time() - _name_cache_time < 60:
        return _name_cache[host]
    # 2. Query Wire coordinator (source of truth — IPs change when nodes move)
    import urllib.request
    for srv_ip in WIRE_SERVERS:
        try:
            req = urllib.request.Request(f"http://{srv_ip}:8790/peers")
            with urllib.request.urlopen(req, timeout=3) as resp:
                data = json.loads(resp.read())
                peers = data.get("peers", [])
                _name_cache.clear()
                for p in peers:
                    vpn_ip = p.get("vpn_ip", "")
                    nn = p.get("node_name", "")
                    if nn: _name_cache[nn] = vpn_ip
                _name_cache_time = time.time()
                if host in _name_cache:
                    return _name_cache[host]
                break  # got peers from coordinator, just no match for this host
        except (OSError, ValueError, TimeoutError):
            continue
    # 3. Fall back to static config (useful when all coordinators unreachable)
    if host in VSSH_CONFIG:
        return VSSH_CONFIG[host]
    return host


def resolve_best_ip(host: str, timeout: float = 0.5) -> str:
    """Resolve best IP for host - try LAN first if same network

    Returns: best IP to use (local IP if reachable, otherwise original host)
    """
    # Skip if host is already a local IP
    if host.startswith('192.168.') or host.startswith('10.') and not host.startswith('10.99.'):
        return host

    # Skip LAN detection for non-VPN IPs
    if not host.startswith('10.99.'):
        return host

    try:
        # Query target's network info via RPC
        sock = vssh_connect(host, timeout=2)

        # RPC call to get_network_info
        payload = json.dumps({})
        sock.sendall(f"RPC:{get_auth_token()}:get_network_info:{len(payload)}\n".encode())
        sock.sendall(payload.encode())

        # Read response
        resp_line = b''
        while b'\n' not in resp_line:
            chunk = sock.recv(1)
            if not chunk:
                break
            resp_line += chunk

        if resp_line.startswith(b'OK:'):
            resp_len = int(resp_line.decode().strip().split(':')[1])
            resp_data = b''
            while len(resp_data) < resp_len:
                resp_data += sock.recv(resp_len - len(resp_data))
            peer_info = json.loads(resp_data)
            sock.close()

            # Check if same public IP
            my_public = get_cached_public_ip()
            peer_public = peer_info.get('public_ip', '')

            if my_public and peer_public and my_public == peer_public:
                # Same NAT! Try local IPs
                peer_local_ips = peer_info.get('local_ips', [])
                for local_ip in peer_local_ips:
                    if try_connect(local_ip, PORT, timeout):
                        print(f'[LAN] Using {local_ip} (same network as {host})')
                        return local_ip

        sock.close()
    except Exception as e:
        pass  # safe to ignore

    return host

def try_connect(host: str, port: int, timeout: float = 0.5) -> bool:
    """Quick test if host:port is reachable"""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        sock.connect((host, port))
        sock.close()
        return True
    except OSError:
        return False

# ========== Persistent Session ==========
# Session management: multiple commands on single TCP connection
PERSISTENT_SESSIONS = {}  # session_id -> {'conn': socket, 'addr': addr, 'created': time, 'last_active': time}
SESSION_TIMEOUT = 300  # 5 min timeout
SESSION_LOCK = threading.Lock()

def generate_session_id() -> str:
    """Generate unique session ID"""
    import random
    return hashlib.sha256(f'{time.time()}{random.random()}'.encode()).hexdigest()[:16]

def cleanup_sessions():
    """Clean up expired sessions"""
    now = time.time()
    with SESSION_LOCK:
        expired = [sid for sid, s in PERSISTENT_SESSIONS.items()
                   if now - s.get('last_active', s['created']) > SESSION_TIMEOUT]
        for sid in expired:
            try:
                PERSISTENT_SESSIONS[sid]['conn'].close()
            except OSError:
                pass  # safe to ignore
            del PERSISTENT_SESSIONS[sid]
            print(f'[SESSION] Expired: {sid[:8]}...')
    return len(expired)

# ========== RPC System ==========
# Permission levels: read (query), write (modify), admin (system)
RPC_METHODS = {}
RPC_PERMISSIONS = {}

def rpc_method(name: str, permission: str = 'read'):
    """RPC method decorator"""
    def decorator(func):
        RPC_METHODS[name] = func
        RPC_PERMISSIONS[name] = permission
        return func
    return decorator

@rpc_method('get_gpu', 'read')
def _rpc_get_gpu(payload: dict) -> dict:
    """Return GPU status"""
    import subprocess
    try:
        r = subprocess.run(
            'nvidia-smi --query-gpu=name,memory.total,memory.used,memory.free,utilization.gpu,temperature.gpu --format=csv,noheader,nounits',
            shell=True, capture_output=True, text=True, timeout=10
        )
        if r.returncode != 0:
            return {'available': False, 'error': 'nvidia-smi failed'}

        gpus = []
        for line in r.stdout.strip().split('\n'):
            if line:
                parts = [p.strip() for p in line.split(',')]
                if len(parts) >= 6:
                    gpus.append({
                        'name': parts[0],
                        'memory_total': int(parts[1]),
                        'memory_used': int(parts[2]),
                        'memory_free': int(parts[3]),
                        'utilization': int(parts[4]),
                        'temperature': int(parts[5])
                    })
        return {'available': True, 'gpus': gpus}
    except Exception as e:
        return {'available': False, 'error': str(e)}

@rpc_method('get_disk', 'read')
def _rpc_get_disk(payload: dict) -> dict:
    """Return disk usage"""
    import subprocess
    path = payload.get('path', '/')
    if any(c in path for c in [';', '|', '&', '`', '$', '(', ')', '\n']):
        return {'error': 'invalid path'}
    try:
        r = subprocess.run(['df', '-B1', path], capture_output=True, text=True, timeout=10)
        lines = r.stdout.strip().split('\n')
        if len(lines) >= 2:
            parts = lines[1].split()
            return {
                'path': path,
                'total': int(parts[1]),
                'used': int(parts[2]),
                'free': int(parts[3]),
                'percent': int(parts[4].rstrip('%'))
            }
    except Exception as e:
        return {'error': str(e)}
    return {'error': 'parse failed'}

@rpc_method('get_memory', 'read')
def _rpc_get_memory(payload: dict) -> dict:
    """Return memory status"""
    import subprocess
    try:
        r = subprocess.run(['free', '-b'], capture_output=True, text=True, timeout=10)
        lines = r.stdout.strip().split('\n')
        if len(lines) >= 2:
            parts = lines[1].split()
            return {
                'total': int(parts[1]),
                'used': int(parts[2]),
                'free': int(parts[3]),
                'available': int(parts[6]) if len(parts) > 6 else int(parts[3])
            }
    except Exception as e:
        return {'error': str(e)}
    return {'error': 'parse failed'}

@rpc_method('get_load', 'read')
def _rpc_get_load(payload: dict) -> dict:
    """Return system load"""
    try:
        with open('/proc/loadavg') as f:
            parts = f.read().split()
            return {
                'load1': float(parts[0]),
                'load5': float(parts[1]),
                'load15': float(parts[2]),
                'processes': parts[3]
            }
    except (OSError, ValueError, IndexError):
        return {'error': 'load read failed'}

@rpc_method('get_processes', 'read')
def _rpc_get_processes(payload: dict) -> dict:
    """Return top processes"""
    import subprocess
    n = payload.get('n', 10)
    sort_by = payload.get('sort', 'cpu')  # cpu or mem
    try:
        if sort_by == 'mem':
            cmd = f'ps aux --sort=-%mem | head -{n+1}'
        else:
            cmd = f'ps aux --sort=-%cpu | head -{n+1}'
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
        lines = r.stdout.strip().split('\n')
        processes = []
        for line in lines[1:]:  # Skip header
            parts = line.split(None, 10)
            if len(parts) >= 11:
                processes.append({
                    'user': parts[0],
                    'pid': int(parts[1]),
                    'cpu': float(parts[2]),
                    'mem': float(parts[3]),
                    'command': parts[10][:100]
                })
        return {'processes': processes}
    except Exception as e:
        return {'error': str(e)}

@rpc_method('get_logs', 'read')
def _rpc_get_logs(payload: dict) -> dict:
    """Read log file"""
    import subprocess
    service = payload.get('service', 'syslog')
    lines = payload.get('lines', 50)

    log_paths = {
        'syslog': '/var/log/syslog',
        'auth': '/var/log/auth.log',
        'nginx': '/var/log/nginx/access.log',
        'nginx_error': '/var/log/nginx/error.log',
        'docker': '/var/log/docker.log',
    }

    # journalctl for systemd services
    if service not in log_paths:
        try:
            r = subprocess.run(
                ['journalctl', '-u', service, '-n', str(lines), '--no-pager'],
                capture_output=True, text=True, timeout=10
            )
            return {'service': service, 'lines': r.stdout.strip().split('\n')}
        except (subprocess.SubprocessError, OSError) as e:
            pass  # e silenced

    path = log_paths.get(service)
    if path and os.path.exists(path):
        try:
            r = subprocess.run(['tail', f'-{lines}', path], capture_output=True, text=True, timeout=10)
            return {'service': service, 'path': path, 'lines': r.stdout.strip().split('\n')}
        except Exception as e:
            return {'error': str(e)}

    return {'error': f'unknown service: {service}'}

@rpc_method('restart_service', 'admin')
def _rpc_restart_service(payload: dict) -> dict:
    """Restart service"""
    import subprocess
    service = payload.get('service')
    if not service:
        return {'error': 'service required'}

    # Allowed services only
    allowed = ['nginx', 'docker', 'ollama', 'chromadb', 'postgresql', 'redis', 'server-agent']
    if service not in allowed:
        return {'error': f'service not allowed: {service}', 'allowed': allowed}

    try:
        r = subprocess.run(['systemctl', 'restart', service], shell=False, capture_output=True, text=True, timeout=30)
        if r.returncode == 0:
            return {'success': True, 'service': service}
        else:
            return {'success': False, 'error': r.stderr.strip()}
    except Exception as e:
        return {'error': str(e)}

@rpc_method('service_status', 'read')
def _rpc_service_status(payload: dict) -> dict:
    """Check service status"""
    import subprocess
    service = payload.get('service')
    if not service:
        return {'error': 'service required'}

    try:
        r = subprocess.run(['systemctl', 'is-active', service], shell=False, capture_output=True, text=True, timeout=10)
        status = r.stdout.strip()
        return {'service': service, 'status': status, 'active': status == 'active'}
    except Exception as e:
        return {'error': str(e)}

@rpc_method('list_services', 'read')
def _rpc_list_services(payload: dict) -> dict:
    """List running services"""
    import subprocess
    try:
        r = subprocess.run(
            'systemctl list-units --type=service --state=running --no-pager --plain | grep -v "^$"',
            shell=True, capture_output=True, text=True, timeout=10
        )
        services = []
        for line in r.stdout.strip().split('\n')[1:]:  # Skip header
            parts = line.split()
            if len(parts) >= 4:
                services.append({
                    'name': parts[0].replace('.service', ''),
                    'load': parts[1],
                    'active': parts[2],
                    'sub': parts[3]
                })
        return {'services': services[:50]}  # Limit
    except Exception as e:
        return {'error': str(e)}

@rpc_method('docker_containers', 'read')
def _rpc_docker_containers(payload: dict) -> dict:
    """List Docker containers"""
    import subprocess
    try:
        r = subprocess.run(
            'docker ps --format "{{.Names}}\t{{.Status}}\t{{.Image}}"',
            shell=True, capture_output=True, text=True, timeout=10
        )
        containers = []
        for line in r.stdout.strip().split('\n'):
            if line:
                parts = line.split('\t')
                if len(parts) >= 3:
                    containers.append({
                        'name': parts[0],
                        'status': parts[1],
                        'image': parts[2]
                    })
        return {'containers': containers}
    except Exception as e:
        return {'error': str(e)}

@rpc_method('file_read', 'read')
def _rpc_file_read(payload: dict) -> dict:
    """Read file (text, size limited)"""
    path = payload.get('path')
    if not path:
        return {'error': 'path required'}

    # Security: block sensitive paths
    blocked = ['/etc/shadow', '/etc/passwd', '.ssh/', '.gnupg/', 'secret', 'password', 'credential']
    if any(b in path.lower() for b in blocked):
        return {'error': 'path not allowed'}

    try:
        p = Path(path)
        if not p.exists():
            return {'error': 'file not found'}
        if p.stat().st_size > 1024 * 1024:  # 1MB limit
            return {'error': 'file too large'}

        content = p.read_text(errors='replace')
        return {'path': path, 'size': len(content), 'content': content}
    except Exception as e:
        return {'error': str(e)}

@rpc_method('file_write', 'write')
def _rpc_file_write(payload: dict) -> dict:
    """Write file"""
    path = payload.get('path')
    content = payload.get('content')
    if not path or content is None:
        return {'error': 'path and content required'}

    # Security: block system paths
    blocked = ['/etc/', '/usr/', '/bin/', '/sbin/', '/var/log/', '/root/']
    if any(path.startswith(b) for b in blocked):
        return {'error': 'path not allowed'}

    try:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content)
        return {'success': True, 'path': path, 'size': len(content)}
    except Exception as e:
        return {'error': str(e)}

@rpc_method('get_network_info', 'read')
def _rpc_get_network_info(payload: dict) -> dict:
    """Return network info for LAN detection"""
    return {
        'local_ips': get_local_ips(),
        'public_ip': get_cached_public_ip(),
    }

# P2P signaling storage (in-memory, temporary)
_p2p_signals = {}  # {peer_ip: {external_ip, external_port, local_port, timestamp}}
_P2P_SIGNAL_TTL = 60  # 60 seconds

@rpc_method('p2p_signal', 'read')
def _rpc_p2p_signal(payload: dict) -> dict:
    """Exchange P2P signaling info for hole punching

    Payload: {external_ip, external_port, local_port, peer_vpn_ip (optional)}
    Returns: Peer's info if available, or stores sender's info
    """
    import time

    sender_ip = payload.get('_sender_ip', 'unknown')
    ext_ip = payload.get('external_ip')
    ext_port = payload.get('external_port')
    local_port = payload.get('local_port')
    peer_vpn_ip = payload.get('peer_vpn_ip')

    if not all([ext_ip, ext_port, local_port]):
        return {'error': 'external_ip, external_port, local_port required'}

    now = time.time()

    # Clean old signals
    expired = [k for k, v in _p2p_signals.items() if now - v.get('timestamp', 0) > _P2P_SIGNAL_TTL]
    for k in expired:
        del _p2p_signals[k]

    # Store sender's info
    _p2p_signals[sender_ip] = {
        'external_ip': ext_ip,
        'external_port': ext_port,
        'local_port': local_port,
        'timestamp': now
    }

    # If peer_vpn_ip specified, return their info if available
    if peer_vpn_ip and peer_vpn_ip in _p2p_signals:
        peer_info = _p2p_signals[peer_vpn_ip]
        return {
            'status': 'peer_found',
            'external_ip': peer_info['external_ip'],
            'external_port': peer_info['external_port'],
            'local_port': peer_info['local_port']
        }

    return {'status': 'registered', 'waiting_for_peer': True}

@rpc_method('p2p_get_peer', 'read')
def _rpc_p2p_get_peer(payload: dict) -> dict:
    """Get peer's P2P signal info"""
    peer_vpn_ip = payload.get('peer_vpn_ip')
    if not peer_vpn_ip:
        return {'error': 'peer_vpn_ip required'}

    if peer_vpn_ip in _p2p_signals:
        return _p2p_signals[peer_vpn_ip]

    return {'error': 'peer not found'}

@rpc_method('restart_service', 'admin')
def _rpc_restart_service(payload: dict) -> dict:
    """Restart a systemd service (admin only)"""
    import subprocess
    service = payload.get('service')
    if not service:
        return {'error': 'service name required'}
    # Security: only allow known services
    allowed = ['vssh', 'nginx', 'docker', 'postgresql', 'mysql', 'redis']
    if service not in allowed:
        return {'error': f'service not allowed, use: {allowed}'}
    try:
        r = subprocess.run(['sudo', 'systemctl', 'restart', service],
                          capture_output=True, text=True, timeout=30)
        return {'success': r.returncode == 0, 'stdout': r.stdout, 'stderr': r.stderr}
    except Exception as e:
        return {'error': str(e)}

def handle_rpc(method: str, payload: dict, sender_ip: str = None) -> str:
    """Handle RPC request"""
    if method not in RPC_METHODS:
        return json.dumps({'error': 'unknown_method', 'available': list(RPC_METHODS.keys())})

    try:
        # Add sender IP to payload for P2P signaling
        if sender_ip:
            payload['_sender_ip'] = sender_ip
        result = RPC_METHODS[method](payload)
        return json.dumps(result)
    except Exception as e:
        return json.dumps({'error': str(e)})

# Speed optimization constants
CHUNK = 1024 * 1024      # 1MB default chunk
BUF = 16 * 1024 * 1024   # 16MB socket buffer (was 4MB)
STREAMS = 8              # parallel streams (was 4)
MULTI_CONN = 4           # multi-connection for large files

# Adaptive chunking: adjust based on network speed
CHUNK_MIN = 256 * 1024   # 256KB for slow connections (<10MB/s)
CHUNK_MED = 1024 * 1024  # 1MB for medium connections (10-50MB/s)
CHUNK_MAX = 4 * 1024 * 1024  # 4MB for fast connections (>50MB/s)
_adaptive_chunk = CHUNK_MED  # Current adaptive chunk size (updated after measurements)

def get_adaptive_chunk(measured_speed: float = 0) -> int:
    """Get optimal chunk size based on measured network speed (bytes/sec)"""
    global _adaptive_chunk
    if measured_speed > 0:
        speed_mbps = measured_speed / (1024 * 1024)
        if speed_mbps > 50:
            _adaptive_chunk = CHUNK_MAX
        elif speed_mbps > 10:
            _adaptive_chunk = CHUNK_MED
        else:
            _adaptive_chunk = CHUNK_MIN
    return _adaptive_chunk

def measure_chunk_speed(sock, data: bytes) -> float:
    """Send data and measure speed, returns bytes/sec"""
    start = time.time()
    sock.sendall(data)
    elapsed = time.time() - start
    if elapsed > 0:
        return len(data) / elapsed
    return 0

def setup_socket(sock, is_send=True):
    """Socket optimization"""
    sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    # Set buffer size (may fail on macOS with smaller limits)
    try:
        if is_send:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, BUF)
        else:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, BUF)
    except OSError:
        pass  # macOS has 8MB limit, just use default
    # Linux TCP_QUICKACK
    try:
        sock.setsockopt(socket.IPPROTO_TCP, 12, 1)  # TCP_QUICKACK = 12
    except OSError:
        pass  # safe to ignore
    sock.settimeout(600)

def file_hash(path: Path) -> str:
    """Fast file hash (head+tail+size)"""
    if not path.exists():
        return ""
    size = path.stat().st_size
    with open(path, 'rb') as f:
        head = f.read(4096)
        f.seek(max(0, size - 4096))
        tail = f.read(4096)
    return hashlib.md5(head + tail + str(size).encode()).hexdigest()[:16]

def full_hash(path: Path) -> str:
    """Full MD5 (using mmap)"""
    size = path.stat().st_size
    if size == 0:
        return hashlib.md5(b'').hexdigest()
    md5 = hashlib.md5()
    with open(path, 'rb') as f:
        if size > CHUNK:
            # Fast hash with mmap
            with mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as mm:
                md5.update(mm)
        else:
            md5.update(f.read())
    return md5.hexdigest()

def partial_hash(path: Path, length: int) -> str:
    """MD5 of first `length` bytes - for resume verification"""
    if not path.exists():
        return ""
    size = path.stat().st_size
    if size == 0 or length == 0:
        return hashlib.md5(b'').hexdigest()

    read_len = min(size, length)
    md5 = hashlib.md5()
    with open(path, 'rb') as f:
        remaining = read_len
        while remaining > 0:
            chunk = f.read(min(CHUNK, remaining))
            if not chunk:
                break
            md5.update(chunk)
            remaining -= len(chunk)
    return md5.hexdigest()

# Bandwidth limiting (bytes/sec, 0 = unlimited)
RATE_LIMIT = 0

def set_rate_limit(limit_str: str):
    """Set rate limit from string like '10m', '100k', '50%'"""
    global RATE_LIMIT
    if not limit_str:
        RATE_LIMIT = 0
        return
    limit_str = limit_str.lower().strip()
    if limit_str.endswith('%'):
        # Percentage of estimated bandwidth (assume 100MB/s max)
        pct = int(limit_str[:-1])
        RATE_LIMIT = int(100 * 1024 * 1024 * pct / 100)
    elif limit_str.endswith('m'):
        RATE_LIMIT = int(float(limit_str[:-1]) * 1024 * 1024)
    elif limit_str.endswith('k'):
        RATE_LIMIT = int(float(limit_str[:-1]) * 1024)
    else:
        RATE_LIMIT = int(limit_str)

def send_file_fast(sock, path: Path, offset=0, length=None, callback=None):
    """Fast file send with adaptive chunking and rate limiting"""
    size = path.stat().st_size
    if length is None:
        length = size - offset

    sent = 0
    chunk_size = get_adaptive_chunk()  # Start with current adaptive size
    measured = False
    start_time = time.time()

    with open(path, 'rb') as f:
        f.seek(offset)
        remaining = length
        while remaining > 0:
            actual_chunk = min(chunk_size, remaining)
            chunk = f.read(actual_chunk)
            if not chunk:
                break

            # Measure speed on first chunk and adapt
            if not measured and len(chunk) >= CHUNK_MIN:
                speed = measure_chunk_speed(sock, chunk)
                chunk_size = get_adaptive_chunk(speed)
                measured = True
            else:
                sock.sendall(chunk)

            sent += len(chunk)
            remaining -= len(chunk)

            # Rate limiting
            if RATE_LIMIT > 0:
                elapsed = time.time() - start_time
                expected_time = sent / RATE_LIMIT
                if expected_time > elapsed:
                    time.sleep(expected_time - elapsed)

            if callback:
                callback(sent, length)
    return sent

def recv_file_fast(sock, path: Path, size: int, callback=None):
    """Fast file receive with adaptive chunking"""
    path.parent.mkdir(parents=True, exist_ok=True)
    received = 0
    chunk_size = get_adaptive_chunk()
    start = time.time()

    with open(path, 'wb') as f:
        while received < size:
            chunk = sock.recv(min(chunk_size, size - received))
            if not chunk:
                break
            f.write(chunk)
            received += len(chunk)

            # Adapt chunk size based on measured speed after first MB
            if received >= CHUNK_MED and chunk_size == CHUNK_MED:
                elapsed = time.time() - start
                if elapsed > 0:
                    speed = received / elapsed
                    chunk_size = get_adaptive_chunk(speed)

            if callback:
                callback(received, size)

    return received == size

# ========== Zero-copy sendfile ==========
def send_file_zerocopy(sock, path: Path, offset=0, length=None, callback=None) -> int:
    """Zero-copy file send using os.sendfile (Linux/macOS)

    Falls back to regular send if sendfile not available.
    Returns bytes sent.
    """
    import sys
    size = path.stat().st_size
    if length is None:
        length = size - offset

    sent = 0
    fd = os.open(str(path), os.O_RDONLY)
    sock_fd = sock.fileno()

    try:
        while sent < length:
            remaining = length - sent
            chunk = min(remaining, 8 * 1024 * 1024)  # 8MB chunks

            if sys.platform == 'darwin':
                # macOS sendfile: (fd, sock, offset, count) -> (sent, result)
                try:
                    n, _ = os.sendfile(fd, sock_fd, offset + sent, chunk)
                    if n == 0:
                        break
                    sent += n
                except OSError:
                    # Fallback to regular send
                    break
            else:
                # Linux sendfile: (sock, fd, offset, count) -> sent
                try:
                    n = os.sendfile(sock_fd, fd, offset + sent, chunk)
                    if n == 0:
                        break
                    sent += n
                except (OSError, AttributeError):
                    break

            if callback:
                callback(sent, length)

        # If sendfile didn't work, fall back to regular send
        if sent < length:
            with open(path, 'rb') as f:
                f.seek(offset + sent)
                while sent < length:
                    chunk = f.read(min(CHUNK, length - sent))
                    if not chunk:
                        break
                    sock.sendall(chunk)
                    sent += len(chunk)
                    if callback:
                        callback(sent, length)
    finally:
        os.close(fd)

    return sent

# ========== Rolling Checksum for Delta Sync (rsync algorithm) ==========
RSYNC_BLOCK = 4096  # Block size for rolling checksum

def rolling_checksum(data: bytes) -> int:
    """Adler-32 rolling checksum"""
    return zlib.adler32(data) & 0xffffffff

def strong_checksum(data: bytes) -> str:
    """MD5 for block verification"""
    return hashlib.md5(data).hexdigest()[:16]

def build_block_signatures(path: Path, block_size: int = RSYNC_BLOCK) -> list:
    """Build block signatures for delta sync

    Returns: [(weak_checksum, strong_checksum, offset), ...]
    """
    sigs = []
    with open(path, 'rb') as f:
        offset = 0
        while True:
            block = f.read(block_size)
            if not block:
                break
            sigs.append((
                rolling_checksum(block),
                strong_checksum(block),
                offset,
                len(block)
            ))
            offset += len(block)
    return sigs

def compute_delta(src_path: Path, remote_sigs: list, block_size: int = RSYNC_BLOCK) -> list:
    """Compute delta between local file and remote signatures

    Returns: list of operations
      ('DATA', offset, data) - send literal data
      ('COPY', remote_offset, length) - copy from remote
    """
    # Build lookup table: weak_checksum -> [(strong, offset, length), ...]
    sig_map = {}
    for weak, strong, offset, length in remote_sigs:
        if weak not in sig_map:
            sig_map[weak] = []
        sig_map[weak].append((strong, offset, length))

    delta = []
    with open(src_path, 'rb') as f:
        data = f.read()

    size = len(data)
    pos = 0
    literal_start = 0

    while pos + block_size <= size:
        block = data[pos:pos + block_size]
        weak = rolling_checksum(block)

        match = None
        if weak in sig_map:
            strong = strong_checksum(block)
            for s_strong, s_offset, s_length in sig_map[weak]:
                if s_strong == strong:
                    match = (s_offset, s_length)
                    break

        if match:
            # Emit literal data before match
            if pos > literal_start:
                delta.append(('DATA', literal_start, data[literal_start:pos]))
            # Emit copy reference
            delta.append(('COPY', match[0], match[1]))
            pos += block_size
            literal_start = pos
        else:
            pos += 1

    # Emit remaining literal data
    if size > literal_start:
        delta.append(('DATA', literal_start, data[literal_start:]))

    return delta

def apply_delta(dest_path: Path, delta: list, orig_path: Path = None) -> bool:
    """Apply delta to reconstruct file

    If orig_path is provided, uses it for COPY operations.
    Otherwise, dest_path must exist for COPY operations.
    """
    source_path = orig_path if orig_path else dest_path

    # Read source file for COPY operations
    source_data = b''
    if source_path and source_path.exists():
        with open(source_path, 'rb') as f:
            source_data = f.read()

    result = bytearray()
    for op in delta:
        if op[0] == 'DATA':
            result.extend(op[2])
        elif op[0] == 'COPY':
            offset, length = op[1], op[2]
            result.extend(source_data[offset:offset + length])

    dest_path.parent.mkdir(parents=True, exist_ok=True)
    with open(dest_path, 'wb') as f:
        f.write(result)
    return True

# ========== vssh_rsync: Delta Sync ==========
def rsync_put(local: str, remote: str, lan: bool = True) -> bool:
    """Delta sync upload - only transfers changed blocks

    Much faster for large files with small changes.
    """
    path = Path(local)
    if not path.is_file():
        print(f'Not a file: {local}')
        return False

    host, rpath = remote.split(':', 1)
    if lan:
        host = resolve_best_ip(host)

    if not check_transfer_safety(host):
        return False

    size = path.stat().st_size
    md5 = full_hash(path)

    sock = vssh_connect(host)
    setup_socket(sock, True)

    try:
        pass  # connected via vssh_connect
        # Request remote file signatures
        sock.sendall(f"RSYNC_SIG:{get_auth_token()}:{rpath}\n".encode())

        resp = sock.recv(64).decode().strip()
        if resp == 'NOFILE':
            # File doesn't exist, do full upload
            sock.close()
            print(f'{path.name} (new file, full upload)')
            return _put_file(path, host, rpath)

        if resp == 'SAME':
            print(f'Skipped (same): {path.name}')
            return True

        if not resp.startswith('SIG:'):
            print(f'Error: {resp}')
            return False

        # Receive signatures
        sig_size = int(resp.split(':')[1])
        sig_data = b''
        while len(sig_data) < sig_size:
            chunk = sock.recv(min(CHUNK, sig_size - len(sig_data)))
            if not chunk:
                break
            sig_data += chunk

        remote_sigs = json.loads(sig_data.decode())

        # Compute delta
        delta = compute_delta(path, remote_sigs)

        # Calculate delta stats
        data_bytes = sum(len(op[2]) for op in delta if op[0] == 'DATA')
        copy_bytes = sum(op[2] for op in delta if op[0] == 'COPY')

        if data_bytes == 0:
            print(f'Skipped (same): {path.name}')
            sock.sendall(b'SKIP\n')
            return True

        ratio = size / data_bytes if data_bytes > 0 else float('inf')
        print(f'{path.name} ({size/1024/1024:.1f}MB → {data_bytes/1024/1024:.2f}MB delta, {ratio:.1f}x)')

        # Close signature connection
        sock.close()

        # Send delta on new connection
        delta_json = json.dumps([
            (op[0], op[1], op[2].hex() if op[0] == 'DATA' else op[2])
            for op in delta
        ]).encode()

        sock2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        setup_socket(sock2, True)
        sock2.connect((host, PORT))
        sock2.sendall(f"RSYNC_DELTA:{get_auth_token()}:{rpath}:{len(delta_json)}:{md5}\n".encode())
        resp = sock2.recv(64).decode().strip()
        if resp != 'OK':
            print(f'Error: {resp}')
            sock2.close()
            return False

        start = time.time()
        sent = 0
        while sent < len(delta_json):
            chunk = delta_json[sent:sent + CHUNK]
            sock2.sendall(chunk)
            sent += len(chunk)
            pct = sent * 100 // len(delta_json)
            speed = sent / (time.time() - start + 0.001) / 1024 / 1024
            print(f'\r  ↑ {pct}% {speed:.1f}MB/s', end='', flush=True)
        print()

        resp = sock2.recv(64).decode().strip()
        sock2.close()
        elapsed = time.time() - start
        if resp == 'OK':
            effective_speed = size / elapsed / 1024 / 1024
            print(f'  Done {elapsed:.1f}s ({effective_speed:.1f}MB/s effective)')
            log_transfer('RSYNC', host, rpath, size, elapsed, 'OK')
            return True

        print(f'Error: {resp}')
        return False

    except Exception as e:
        print(f'Error: {e}')
        return False
    finally:
        try:
            sock.close()
        except OSError:
            pass  # safe to ignore

# ========== put_fast: Auto-select best method ==========
FAST_THRESHOLD = 500 * 1024 * 1024  # 500MB for parallel transfer
RSYNC_THRESHOLD = 10 * 1024 * 1024  # 10MB for delta sync

def put_fast(local: str, remote: str, lan: bool = True) -> bool:
    """Fast upload with auto-method selection

    - < 10MB: Regular PUT
    - 10-500MB: Regular PUT with compression (if applicable)
    - > 500MB: Parallel multi-connection

    Use rsync_put() explicitly for delta sync.
    """
    path = Path(local)
    if not path.is_file():
        print(f'Not a file: {local}')
        return False

    host, rpath = remote.split(':', 1)
    if lan:
        host = resolve_best_ip(host)

    if not check_transfer_safety(host):
        return False

    size = path.stat().st_size

    if size >= FAST_THRESHOLD:
        # Large file: use parallel connections
        print(f'[FAST] Using {MULTI_CONN} parallel connections')
        return put_large_file(path, host, rpath)
    else:
        # Regular transfer
        return _put_file(path, host, rpath)


# ========== P2P Transfer (NAT Hole-Punch) ==========
def put_p2p(local: str, remote: str, fallback: bool = True) -> bool:
    """Upload via P2P hole-punching (bypasses VPN relay)

    Attempts P2P direct transfer for higher speed between NAT'd hosts.
    Falls back to regular VPN transfer if P2P fails.

    Best for: Large files between NAT'd machines (e.g., local <-> remote)
    Speed: ~11MB/s P2P vs ~10MB/s VPN relay
    """
    try:
        from vssh_p2p import p2p_transfer_tcp
    except ImportError:
        print('[P2P] vssh_p2p module not found, using VPN')
        return put_fast(local, remote)

    path = Path(local)
    if not path.is_file():
        print(f'Not a file: {local}')
        return False

    host, rpath = remote.split(':', 1)

    # Try P2P first
    print(f'[P2P] Attempting direct transfer to {host}...')
    success = p2p_transfer_tcp(str(path), host, rpath)

    if success:
        return True

    if fallback:
        print('[P2P] Falling back to VPN relay...')
        return put_fast(local, remote)

    return False


# ========== Multi-connection Large File Transfer ==========
def put_large_file(path: Path, host: str, rpath: str) -> bool:
    """Large file multi-connection upload"""
    size = path.stat().st_size
    md5 = full_hash(path)

    # Chunk split
    chunk_size = size // MULTI_CONN
    chunks = []
    for i in range(MULTI_CONN):
        offset = i * chunk_size
        length = chunk_size if i < MULTI_CONN - 1 else (size - offset)
        chunks.append((i, offset, length))

    # Request transfer start via main connection
    sock = vssh_connect(host)
    setup_socket(sock, True)
    sock.sendall(f"PUTM:{get_auth_token()}:{rpath}:{size}:{md5}:{MULTI_CONN}\n".encode())

    resp = sock.recv(64).decode().strip()
    if resp == 'SKIP':
        print(f'Skipped (same): {path.name}')
        sock.close()
        return True
    if not resp.startswith('OK:'):
        print(f'Error: {resp}')
        sock.close()
        return False

    session_id = resp.split(':')[1]
    sock.close()

    print(f'{path.name} ({size/1024/1024:.1f}MB) - {MULTI_CONN} parallel connections')
    start = time.time()
    progress = [0] * MULTI_CONN
    lock = threading.Lock()

    def upload_chunk(idx, offset, length):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        setup_socket(s, True)
        try:
            s.connect((host, PORT))
            s.sendall(f"PUTC:{get_auth_token()}:{session_id}:{idx}:{offset}:{length}\n".encode())
            resp = s.recv(64).decode().strip()
            if resp != 'OK':
                return False

            def cb(sent, total):
                with lock:
                    progress[idx] = sent
                    total_sent = sum(progress)
                    pct = total_sent * 100 // size
                    speed = total_sent / (time.time() - start + 0.001) / 1024 / 1024
                    print(f'\r  ↑ {pct}% {speed:.1f}MB/s', end='', flush=True)

            send_file_fast(s, path, offset, length, cb)
            return s.recv(64).decode().strip() == 'OK'
        finally:
            s.close()

    with ThreadPoolExecutor(max_workers=MULTI_CONN) as ex:
        futures = [ex.submit(upload_chunk, *c) for c in chunks]
        results = [f.result() for f in futures]

    print()
    elapsed = time.time() - start
    if all(results):
        print(f'  Done {elapsed:.1f}s ({size/elapsed/1024/1024:.1f}MB/s)')
        return True
    return False

# ========== Client ==========
def put(local: str, remote: str, resume: bool = False, compress: bool = None, retry: int = 0, lan: bool = True) -> bool:
    """Upload file/directory

    Args:
        compress: None=auto, True=force, False=disable
        retry: Number of retry attempts (0=no retry, default)
        lan: Try LAN detection for faster transfer (default True)
    """
    path = Path(local)
    host, rpath = remote.split(':', 1)

    # LAN detection: try local IP if same network
    if lan:
        host = resolve_best_ip(host)

    # Safety check: block public IP
    if not check_transfer_safety(host):
        return False

    def do_put():
        if path.is_file():
            size = path.stat().st_size
            # Use resume for large files or when explicitly requested
            if resume or size > 100 * 1024 * 1024:
                return _put_file_resume(path, host, rpath)
            # Auto-compress compressible files < 50MB
            use_compress = compress if compress is not None else (should_compress(path, size) and size < 50 * 1024 * 1024)
            if use_compress:
                return _put_file_compressed(path, host, rpath)
            return _put_file(path, host, rpath)
        elif path.is_dir():
            return _put_dir(path, host, rpath)
        else:
            print(f'Not found: {local}')
            return False

    if retry > 0:
        success, _ = with_retry(do_put, max_retries=retry)
        return success
    else:
        return do_put()

def _put_file(path: Path, host: str, rpath: str) -> bool:
    """Upload single file"""
    size = path.stat().st_size
    md5 = full_hash(path)

    sock = vssh_connect(host)
    setup_socket(sock, True)

    try:
        pass  # connected via vssh_connect
        sock.sendall(f"PUT:{get_auth_token()}:{rpath}:{size}:{md5}\n".encode())

        resp = sock.recv(64).decode().strip()
        if resp == 'SKIP':
            print(f'Skipped (same): {path.name}')
            return True
        if resp != 'OK':
            print(f'Error: {resp}')
            return False

        print(f'{path.name} ({size/1024/1024:.1f}MB)')
        start = time.time()

        def progress(sent, total):
            pct = sent * 100 // total
            speed = sent / (time.time() - start + 0.001) / 1024 / 1024
            print(f'\r  ↑ {pct}% {speed:.1f}MB/s', end='', flush=True)

        send_file_fast(sock, path, callback=progress)
        print()

        resp = sock.recv(64).decode().strip()
        elapsed = time.time() - start
        if resp == 'OK':
            print(f'  Done {elapsed:.1f}s ({size/elapsed/1024/1024:.1f}MB/s)')
            log_transfer('PUT', host, rpath, size, elapsed, 'OK')
            return True
        log_transfer('PUT', host, rpath, size, elapsed, 'FAIL')
        return False

    finally:
        sock.close()

def _put_file_compressed(path: Path, host: str, rpath: str) -> bool:
    """Upload single file with compression (for compressible files < 50MB)"""
    size = path.stat().st_size
    md5 = full_hash(path)

    # Read and compress
    with open(path, 'rb') as f:
        original = f.read()
    compressed = compress_data(original)
    comp_size = len(compressed)
    ratio = size / comp_size if comp_size > 0 else 1

    # Only use compression if it actually helps
    if comp_size >= size * 0.9:  # Less than 10% savings
        return _put_file(path, host, rpath)  # Fall back to uncompressed

    sock = vssh_connect(host)
    setup_socket(sock, True)

    try:
        pass  # connected via vssh_connect
        sock.sendall(f"PUTZ:{get_auth_token()}:{rpath}:{comp_size}:{size}:{md5}\n".encode())

        resp = sock.recv(64).decode().strip()
        if resp == 'SKIP':
            print(f'Skipped (same): {path.name}')
            return True
        if resp != 'OK':
            print(f'Error: {resp}')
            return False

        print(f'{path.name} ({size/1024/1024:.1f}MB → {comp_size/1024/1024:.1f}MB, {ratio:.1f}x)')
        start = time.time()

        # Send compressed data
        sent = 0
        while sent < comp_size:
            chunk = compressed[sent:sent + CHUNK]
            sock.sendall(chunk)
            sent += len(chunk)
            pct = sent * 100 // comp_size
            speed = sent / (time.time() - start + 0.001) / 1024 / 1024
            print(f'\r  ↑ {pct}% {speed:.1f}MB/s', end='', flush=True)
        print()

        resp = sock.recv(64).decode().strip()
        if resp == 'OK':
            elapsed = time.time() - start
            print(f'  Done {elapsed:.1f}s ({size/elapsed/1024/1024:.1f}MB/s effective)')
            return True
        return False

    finally:
        sock.close()

def _put_file_resume(path: Path, host: str, rpath: str) -> bool:
    """Upload single file with resume support"""
    size = path.stat().st_size
    fhash = full_hash(path)
    phash = partial_hash(path, size)  # Hash of data we're sending

    sock = vssh_connect(host)
    setup_socket(sock, True)

    try:
        pass  # connected via vssh_connect
        # RESUME:secret:path:offset:total_size:partial_hash:full_hash
        sock.sendall(f"RESUME:{get_auth_token()}:{rpath}:{size}:{size}:{phash}:{fhash}\n".encode())

        resp = sock.recv(64).decode().strip()
        if resp == 'SKIP':
            print(f'Skipped (same): {path.name}')
            return True

        offset = 0
        if resp.startswith('OK:'):
            # Resume from offset
            offset = int(resp.split(':')[1])
            print(f'{path.name} ({size/1024/1024:.1f}MB) resuming from {offset/1024/1024:.1f}MB')
        elif resp.startswith('RESTART'):
            print(f'{path.name} ({size/1024/1024:.1f}MB) starting fresh')
        else:
            print(f'Error: {resp}')
            return False

        start = time.time()
        remaining = size - offset

        def progress(sent, total):
            pct = (offset + sent) * 100 // size
            speed = sent / (time.time() - start + 0.001) / 1024 / 1024
            print(f'\r  ↑ {pct}% {speed:.1f}MB/s', end='', flush=True)

        send_file_fast(sock, path, offset=offset, length=remaining, callback=progress)
        print()

        resp = sock.recv(64).decode().strip()
        if resp == 'OK':
            elapsed = time.time() - start
            print(f'  Done {elapsed:.1f}s ({remaining/elapsed/1024/1024:.1f}MB/s)')
            return True
        print(f'  Failed: {resp}')
        return False

    finally:
        sock.close()

def _put_dir(path: Path, host: str, rpath: str) -> bool:
    """Directory sync (parallel)"""
    files = {}
    for f in path.rglob('*'):
        if f.is_file():
            rel = str(f.relative_to(path))
            files[rel] = {'size': f.stat().st_size, 'hash': file_hash(f)}

    sock = vssh_connect(host, timeout=60)

    try:
        pass  # connected via vssh_connect
        manifest = json.dumps(files).encode()
        sock.sendall(f"SYNC:{get_auth_token()}:{rpath}:{len(manifest)}\n".encode())

        resp = sock.recv(64).decode().strip()
        if resp != 'OK':
            print(f'Error: {resp}')
            return False

        sock.sendall(manifest)

        buf = b''
        while b'\n' not in buf:
            buf += sock.recv(256)

        line, rest = buf.split(b'\n', 1)
        resp_len = int(line.decode().strip())

        need_data = rest
        while len(need_data) < resp_len:
            need_data += sock.recv(resp_len - len(need_data))
        need = json.loads(need_data[:resp_len].decode())

        if not need:
            print('Sync complete (no changes)')
            return True

        print(f'Transfer: {len(need)} files ({STREAMS} parallel streams)')

        # Parallel upload
        total = len(need)
        done = [0]
        lock = threading.Lock()

        def upload_one(rel):
            try:
                _put_file(path / rel, host, f"{rpath}/{rel}")
                with lock:
                    done[0] += 1
                return True
            except Exception as e:
                print(f'\n  Error {rel}: {e}')
                return False

        with ThreadPoolExecutor(max_workers=STREAMS) as ex:
            futures = [ex.submit(upload_one, rel) for rel in need]
            results = [f.result() for f in as_completed(futures)]

        return all(results)

    finally:
        sock.close()

# ========== Multiplexed Transfer ==========
def mput(files: list, host: str, base_rpath: str = '') -> dict:
    """Multiplexed put - send multiple files over single connection

    Args:
        files: list of (local_path, remote_path) tuples
        host: target host
        base_rpath: optional base path prefix for remote paths

    Returns:
        {'ok': N, 'skip': N, 'fail': N, 'errors': [...]}
    """
    if not files:
        return {'ok': 0, 'skip': 0, 'fail': 0, 'errors': []}

    sock = vssh_connect(host)
    setup_socket(sock, True)

    result = {'ok': 0, 'skip': 0, 'fail': 0, 'errors': []}

    try:
        pass  # connected via vssh_connect
        sock.sendall(f"MPUT:{get_auth_token()}:{len(files)}\n".encode())

        resp = sock.recv(64).decode().strip()
        if resp != 'OK':
            return {'ok': 0, 'skip': 0, 'fail': len(files), 'errors': [f'Server rejected: {resp}']}

        for local_path, remote_path in files:
            p = Path(local_path)
            if not p.exists():
                result['fail'] += 1
                result['errors'].append(f'{local_path}: not found')
                # Send skip marker
                sock.sendall(b'SKIP_FILE\n')
                continue

            rpath = f"{base_rpath}/{remote_path}" if base_rpath else remote_path
            size = p.stat().st_size
            md5 = full_hash(p)

            # Send file header
            sock.sendall(f"FILE:{rpath}:{size}:{md5}\n".encode())

            # Wait for server ready (may SKIP if already exists)
            resp = sock.recv(64).decode().strip()
            if resp == 'SKIP':
                result['skip'] += 1
                continue
            elif resp != 'OK':
                result['fail'] += 1
                result['errors'].append(f'{rpath}: {resp}')
                continue

            # Send file data
            sent = send_file_fast(sock, p)

            # Wait for confirmation
            resp = sock.recv(64).decode().strip()
            if resp == 'OK':
                result['ok'] += 1
            elif resp == 'HASH':
                result['fail'] += 1
                result['errors'].append(f'{rpath}: hash mismatch')
            else:
                result['fail'] += 1
                result['errors'].append(f'{rpath}: {resp}')

        # Send end marker
        sock.sendall(b'END\n')

        # Get final summary from server
        final = sock.recv(128).decode().strip()
        # Expected: DONE:ok:skip:fail

        return result

    except Exception as e:
        result['fail'] += len(files) - result['ok'] - result['skip']
        result['errors'].append(str(e))
        return result
    finally:
        sock.close()

def mput_dir(local_dir: str, remote: str) -> dict:
    """Multiplexed directory upload - all files over single connection"""
    host, rpath = remote.split(':', 1)
    path = Path(local_dir)

    if not path.is_dir():
        return {'ok': 0, 'skip': 0, 'fail': 1, 'errors': [f'{local_dir}: not a directory']}

    # Collect all files
    files = []
    for f in path.rglob('*'):
        if f.is_file():
            rel = str(f.relative_to(path))
            files.append((str(f), rel))

    if not files:
        return {'ok': 0, 'skip': 0, 'fail': 0, 'errors': []}

    print(f'mput: {len(files)} files → {host}:{rpath}')
    result = mput(files, host, rpath)
    print(f'  Done: {result["ok"]} ok, {result["skip"]} skip, {result["fail"]} fail')

    return result

def get(remote: str, local: str, retry: int = 0, lan: bool = True) -> bool:
    """Download (auto multi-connection for 100MB+)

    Args:
        retry: Number of retry attempts (0=no retry, default)
        lan: Try LAN detection for faster transfer (default True)
    """
    orig_host, rpath = remote.split(':', 1)
    host = resolve_best_ip(orig_host) if lan else orig_host

    # Safety check: block public IP
    if not check_transfer_safety(host):
        return False

    def do_get():
        sock = vssh_connect(host)
        setup_socket(sock, False)

        try:
            pass  # connected via vssh_connect
            sock.sendall(f"GET:{get_auth_token()}:{rpath}\n".encode())

            resp = sock.recv(256).decode().strip()
            if not resp.startswith('OK:'):
                print(f'Error: {resp}')
                return False

            _, size, md5_exp = resp.split(':')
            size = int(size)

            # Use multi-connection for files > 100MB
            if size > 100 * 1024 * 1024:
                sock.close()
                return _get_large_file(host, rpath, local, size, md5_exp)

            print(f'{Path(rpath).name} ({size/1024/1024:.1f}MB)')
            start = time.time()

            def progress(recv, total):
                pct = recv * 100 // total
                speed = recv / (time.time() - start + 0.001) / 1024 / 1024
                print(f'\r  ↓ {pct}% {speed:.1f}MB/s', end='', flush=True)

            if recv_file_fast(sock, Path(local), size, progress):
                print()
                elapsed = time.time() - start
                if full_hash(Path(local)) == md5_exp:
                    print(f'  Done {elapsed:.1f}s ({size/elapsed/1024/1024:.1f}MB/s)')
                    log_transfer('GET', host, rpath, size, elapsed, 'OK')
                    return True
                else:
                    print('  Hash mismatch!')
                    log_transfer('GET', host, rpath, size, elapsed, 'HASH')
            return False

        finally:
            sock.close()

    if retry > 0:
        success, _ = with_retry(do_get, max_retries=retry)
        return success
    else:
        return do_get()

def _get_large_file(host: str, rpath: str, local: str, size: int, md5_exp: str) -> bool:
    """Multi-connection download for large files"""
    # Request multi-connection session
    sock = vssh_connect(host)
    setup_socket(sock, True)

    try:
        pass  # connected via vssh_connect
        sock.sendall(f"GETM:{get_auth_token()}:{rpath}:{MULTI_CONN}\n".encode())

        resp = sock.recv(256).decode().strip()
        if not resp.startswith('OK:'):
            print(f'Error: {resp}')
            return False

        parts = resp.split(':')
        session_id = parts[1]
        # size and md5 confirmed from response
        sock.close()

        print(f'{Path(rpath).name} ({size/1024/1024:.1f}MB) - {MULTI_CONN} parallel connections')
        start = time.time()

        # Download chunks in parallel
        chunk_size = size // MULTI_CONN
        tmp_paths = []

        def download_chunk(idx):
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            setup_socket(s, True)
            try:
                s.connect((host, PORT))
                s.sendall(f"GETC:{get_auth_token()}:{session_id}:{idx}\n".encode())

                resp = s.recv(64).decode().strip()
                if not resp.startswith('OK:'):
                    return None

                _, offset, length = resp.split(':')
                offset, length = int(offset), int(length)

                tmp_path = Path(f'/tmp/vssh_get_{session_id}_{idx}')
                recv_file_fast(s, tmp_path, length)
                return tmp_path
            finally:
                s.close()

        with ThreadPoolExecutor(max_workers=MULTI_CONN) as ex:
            futures = {ex.submit(download_chunk, i): i for i in range(MULTI_CONN)}
            for future in as_completed(futures):
                idx = futures[future]
                result = future.result()
                if result:
                    tmp_paths.append((idx, result))

        # Sort by index and merge
        tmp_paths.sort(key=lambda x: x[0])

        if len(tmp_paths) != MULTI_CONN:
            print(f'  Error: only got {len(tmp_paths)}/{MULTI_CONN} chunks')
            return False

        # Merge chunks
        local_path = Path(local)
        local_path.parent.mkdir(parents=True, exist_ok=True)
        with open(local_path, 'wb') as f:
            for idx, tmp in tmp_paths:
                with open(tmp, 'rb') as cf:
                    while True:
                        chunk = cf.read(CHUNK)
                        if not chunk:
                            break
                        f.write(chunk)
                tmp.unlink()  # Clean up

        # Verify hash
        if full_hash(local_path) == md5_exp:
            elapsed = time.time() - start
            print(f'  Done {elapsed:.1f}s ({size/elapsed/1024/1024:.1f}MB/s)')
            return True
        else:
            print('  Hash mismatch!')
            return False

    except Exception as e:
        print(f'Error: {e}')
        return False

def sync(local_dir: str, remote: str, delete: bool = False) -> bool:
    return put(local_dir, remote)

def ssh(host: str, cmd: str) -> int:
    sock = vssh_connect(host, timeout=60)
    try:
        pass  # connected via vssh_connect
        sock.sendall(f"SSH:{get_auth_token()}:{cmd}\n".encode())
        resp = sock.recv(64)
        if not resp.startswith(b'OK'):
            print('Auth failed')
            return 1
        while True:
            data = sock.recv(4096)
            if not data:
                break
            text = data.decode('utf-8', errors='replace')
            if '__END__' in text:
                print(text.replace('__END__', '').rstrip())
                break
            print(text, end='')
        return 0
    except Exception as e:
        print(f'Error: {e}')
        return 1
    finally:
        sock.close()

def pipe_up(host: str, rpath: str) -> int:
    """Pipe stdin to remote file: cat file | vssh pipe host:/path"""
    import sys
    data = sys.stdin.buffer.read()
    if not data:
        print('Error: no input data', file=sys.stderr)
        return 1

    md5 = hashlib.md5(data).hexdigest()
    size = len(data)

    sock = vssh_connect(host)
    setup_socket(sock, True)
    try:
        pass  # connected via vssh_connect
        sock.sendall(f"PIPE_UP:{get_auth_token()}:{rpath}:{size}:{md5}\n".encode())

        resp = sock.recv(64).decode().strip()
        if resp != 'OK':
            print(f'Error: {resp}', file=sys.stderr)
            return 1

        # Send data
        sock.sendall(data)

        # Get result
        resp = sock.recv(64).decode().strip()
        if resp == 'OK':
            print(f'{rpath}: {size} bytes', file=sys.stderr)
            return 0
        print(f'Error: {resp}', file=sys.stderr)
        return 1
    except Exception as e:
        print(f'Error: {e}', file=sys.stderr)
        return 1
    finally:
        sock.close()

def pipe_down(host: str, cmd: str) -> int:
    """Pipe remote command to stdout: vssh pipe host:"cmd" > file"""
    import sys
    sock = vssh_connect(host)
    setup_socket(sock, False)
    try:
        pass  # connected via vssh_connect
        sock.sendall(f"PIPE_DOWN:{get_auth_token()}:{cmd}\n".encode())

        # Get header: OK:size\n (may include start of data)
        buf = sock.recv(256)
        if not buf.startswith(b'OK:'):
            print(f'Error: {buf.decode()}', file=sys.stderr)
            return 1

        # Parse header and extract any data that came with it
        newline_idx = buf.index(b'\n')
        size = int(buf[3:newline_idx].decode())
        data_start = buf[newline_idx + 1:]

        # Write any data that came with header
        if data_start:
            sys.stdout.buffer.write(data_start)

        # Stream remaining to stdout
        received = len(data_start)
        while received < size:
            chunk = sock.recv(min(get_adaptive_chunk(), size - received))
            if not chunk:
                break
            sys.stdout.buffer.write(chunk)
            received += len(chunk)

        sys.stdout.buffer.flush()
        print(f'{received} bytes', file=sys.stderr)
        return 0
    except Exception as e:
        print(f'Error: {e}', file=sys.stderr)
        return 1
    finally:
        sock.close()

def info(host: str) -> int:
    sock = vssh_connect(host, timeout=30)
    try:
        pass  # connected via vssh_connect
        sock.sendall(f"INFO:{get_auth_token()}\n".encode())
        resp = sock.recv(64)
        if not resp.startswith(b'OK'):
            print('Auth failed')
            return 1

        data = b''
        while True:
            chunk = sock.recv(4096)
            if not chunk or b'__END__' in chunk:
                data += chunk.replace(b'__END__', b'')
                break
            data += chunk

        info = json.loads(data.decode())
        print(f'''
╔══════════════════════════════════════════════════════════════╗
║  {info['hostname']:^60}  ║
╚══════════════════════════════════════════════════════════════╝

🖥️  System: {info['os']} | {info['kernel']} | {info['uptime']}
💻  CPU: {info['cpu']} ({info['cores']}cores) | Load: {info['load']}
🎮  GPU: {info['gpu']}
💾  Memory: {info['memory']}
🌐  IP: {info['ip']} | VPN: {info['vpn_ip']}
''')
        return 0
    except Exception as e:
        print(f'Error: {e}')
        return 1
    finally:
        sock.close()

def rpc(host: str, method: str, payload: dict = None) -> dict:
    """RPC call - structured method invocation"""
    sock = vssh_connect(host, timeout=60)
    try:
        pass  # connected via vssh_connect

        if payload:
            payload_json = json.dumps(payload).encode()
            sock.sendall(f"RPC:{get_auth_token()}:{method}:{len(payload_json)}\n".encode())
        else:
            sock.sendall(f"RPC:{get_auth_token()}:{method}:0\n".encode())

        resp = sock.recv(1024)
        if not resp.startswith(b'OK'):
            # Error response
            try:
                return json.loads(resp.replace(b'__END__', b'').decode())
            except (json.JSONDecodeError, ValueError, UnicodeDecodeError):
                return {'error': resp.decode().strip()}

        # Send payload
        if payload:
            sock.sendall(payload_json)

        # Receive response
        data = b''
        while True:
            chunk = sock.recv(4096)
            if not chunk or b'__END__' in chunk:
                data += chunk.replace(b'__END__', b'')
                break
            data += chunk

        return json.loads(data.decode())
    except Exception as e:
        return {'error': str(e)}
    finally:
        sock.close()

def rpc_list(host: str) -> dict:
    """List available RPC methods"""
    sock = vssh_connect(host, timeout=30)
    try:
        pass  # connected via vssh_connect
        sock.sendall(f"RPC_LIST:{get_auth_token()}\n".encode())

        data = b''
        while True:
            chunk = sock.recv(4096)
            if not chunk or b'__END__' in chunk:
                data += chunk.replace(b'__END__', b'')
                break
            data += chunk

        return json.loads(data.decode())
    except Exception as e:
        return {'error': str(e)}
    finally:
        sock.close()

# ========== Persistent Session Client ==========

# ========== PTY Terminal Client ==========
def pty_session(host: str, name: str = ''):
    """Connect to server with real PTY terminal (like SSH)"""
    import select as _select
    
    # Get local terminal size
    rows, cols = 24, 80
    try:
        import shutil
        ts = shutil.get_terminal_size()
        cols, rows = ts.columns, ts.lines
    except Exception:
        pass  # safe to ignore
    
    sock = vssh_connect(host, timeout=10)
    try:
        pass  # connected via vssh_connect
    except Exception as e:
        print(f'Connection failed: {e}')
        return 1
    
    # Send PTY_SESSION request
    sock.sendall(f"PTY_SESSION:{get_auth_token()}:{rows}:{cols}\n".encode())
    
    # Wait for PTY_OK
    resp = b''
    while b'\n' not in resp:
        chunk = sock.recv(64)
        if not chunk:
            print('Connection closed')
            return 1
        resp += chunk
    
    resp_str = resp.decode().strip()
    if resp_str != 'PTY_OK':
        print(f'PTY rejected: {resp_str}')
        return 1
    
    # Extra data after PTY_OK header
    extra = resp[resp.index(b'\n')+1:]
    
    # Enter raw terminal mode
    old_settings = None
    try:
        import tty as _tty, termios as _termios
        fd = sys.stdin.fileno()
        old_settings = _termios.tcgetattr(fd)
        _tty.setraw(fd)
    except Exception:
        pass  # safe to ignore
    
    sock.setblocking(False)
    
    try:
        # Write any extra data from handshake
        if extra:
            sys.stdout.buffer.write(extra)
            sys.stdout.buffer.flush()
        
        while True:
            try:
                readable, _, _ = _select.select([sys.stdin, sock], [], [], 0.1)
            except (OSError, ValueError):
                break
            
            for r in readable:
                if r == sys.stdin:
                    # stdin -> socket
                    try:
                        data = os.read(sys.stdin.fileno(), 1024)
                        if not data:
                            raise EOFError
                        sock.sendall(data)
                    except (EOFError, BrokenPipeError):
                        raise EOFError
                elif r == sock:
                    # socket -> stdout
                    try:
                        data = sock.recv(4096)
                        if not data:
                            raise EOFError
                        sys.stdout.buffer.write(data)
                        sys.stdout.buffer.flush()
                    except (BlockingIOError) as e:
                        pass  # e silenced
                    except (EOFError, ConnectionError):
                        raise EOFError
    except (EOFError, KeyboardInterrupt, ConnectionError, BrokenPipeError) as e:
        pass  # e silenced
    finally:
        # Restore terminal
        if old_settings:
            try:
                import termios as _termios
                _termios.tcsetattr(sys.stdin.fileno(), _termios.TCSADRAIN, old_settings)
            except Exception:
                pass  # safe to ignore
        sock.close()
        print()  # newline after raw mode
    
    return 0

class VsshSession:
    """Persistent session client - multiple commands on single connection"""

    def __init__(self, host: str, timeout: int = 60):
        self.host = host
        self.sock = None
        self.session_id = None
        self.timeout = timeout

    def connect(self) -> bool:
        """Connect session"""
        try:
            self.sock = vssh_connect(self.host, timeout=self.timeout)
            self.sock.sendall(f"SESSION:{get_auth_token()}\n".encode())

            # SESSION_OK:session_id response
            resp = b''
            while b'\n' not in resp:
                chunk = self.sock.recv(64)
                if not chunk:
                    break
                resp += chunk

            resp_str = resp.decode().strip()
            if resp_str.startswith('SESSION_OK:'):
                self.session_id = resp_str.split(':')[1]
                return True
            print(f'Session rejected: {resp_str}')
            return False
        except Exception as e:
            print(f'Session connect error: {e}')
            return False

    def rpc(self, method: str, payload: dict = None) -> dict:
        """RPC call within session"""
        if not self.session_id:
            return {'error': 'not connected'}

        try:
            if payload:
                payload_json = json.dumps(payload).encode()
                self.sock.sendall(f"CMD:{self.session_id}:RPC:{method}:{len(payload_json)}\n".encode())
                self.sock.sendall(payload_json)
            else:
                self.sock.sendall(f"CMD:{self.session_id}:RPC:{method}:0\n".encode())

            # RPC_RESULT:length - header and data may arrive together
            buf = b''
            while b'\n' not in buf:
                chunk = self.sock.recv(4096)
                if not chunk:
                    break
                buf += chunk

            nl_pos = buf.index(b'\n')
            header = buf[:nl_pos].decode().strip()
            extra = buf[nl_pos+1:]  # Data after header

            if header.startswith('RPC_RESULT:'):
                result_len = int(header.split(':')[1])
                data = extra
                while len(data) < result_len:
                    chunk = self.sock.recv(result_len - len(data))
                    if not chunk:
                        break
                    data += chunk
                return json.loads(data[:result_len].decode())
            elif header.startswith('ERR:'):
                return {'error': header}
            return {'error': 'invalid response'}
        except Exception as e:
            return {'error': str(e)}

    def ssh(self, command: str) -> tuple:
        """SSH command within session - returns (exit_code, output)"""
        if not self.session_id:
            return (1, 'not connected')

        try:
            cmd_bytes = command.encode()
            self.sock.sendall(f"CMD:{self.session_id}:SSH:{len(cmd_bytes)}\n".encode())
            self.sock.sendall(cmd_bytes)

            # SSH_RESULT:exit_code:length - header and output may arrive together
            buf = b''
            while b'\n' not in buf:
                chunk = self.sock.recv(4096)
                if not chunk:
                    break
                buf += chunk

            nl_pos = buf.index(b'\n')
            header = buf[:nl_pos].decode().strip()
            extra = buf[nl_pos+1:]  # Data after header

            if header.startswith('SSH_RESULT:'):
                parts = header.split(':')
                exit_code = int(parts[1])
                output_len = int(parts[2])
                output = extra
                while len(output) < output_len:
                    chunk = self.sock.recv(output_len - len(output))
                    if not chunk:
                        break
                    output += chunk
                return (exit_code, output[:output_len].decode(errors='replace'))
            return (1, header)
        except Exception as e:
            return (1, str(e))

    def info(self) -> dict:
        """Get session info"""
        if not self.session_id:
            return {'error': 'not connected'}

        try:
            self.sock.sendall(f"CMD:{self.session_id}:INFO:0\n".encode())

            buf = b''
            while b'\n' not in buf:
                chunk = self.sock.recv(4096)
                if not chunk:
                    break
                buf += chunk

            nl_pos = buf.index(b'\n')
            header = buf[:nl_pos].decode().strip()
            extra = buf[nl_pos+1:]

            if header.startswith('INFO_RESULT:'):
                info_len = int(header.split(':')[1])
                data = extra
                while len(data) < info_len:
                    chunk = self.sock.recv(info_len - len(data))
                    if not chunk:
                        break
                    data += chunk
                return json.loads(data[:info_len].decode())
            return {'error': header}
        except Exception as e:
            return {'error': str(e)}

    def close(self):
        """Close session"""
        if self.sock and self.session_id:
            try:
                self.sock.sendall(f"CLOSE:{self.session_id}\n".encode())
                self.sock.recv(32)  # CLOSE_OK
            except OSError as e:
                pass  # e silenced
            finally:
                self.sock.close()
                self.sock = None
                self.session_id = None

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *args):
        self.close()


# ========== Server ==========
def server():
    import subprocess
    import uuid

    sessions = {}  # Multi-connection session management

    print(f'''
╔═══════════════════════════════════════╗
║  vssh server v3 (high-speed)           ║
║  Port: {PORT} | Chunk: 1MB | Buffer: 16MB ║
╚═══════════════════════════════════════╝
''')

    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, BUF)
    srv.bind(('0.0.0.0', PORT))
    srv.listen(32)

    def handle(conn, addr):
        import subprocess  # Must be at top - Python treats it as local if imported anywhere in function
        try:
            setup_socket(conn, False)
            line = conn.recv(4096).decode().strip()
            parts = line.split(':')
            cmd, sec = parts[0], parts[1]

            if not verify_auth(sec, SECRET):
                conn.sendall(b'AUTH\n')
                return

            if cmd == 'PUT':
                rpath, size, md5_exp = ':'.join(parts[2:-2]), int(parts[-2]), parts[-1]
                p = Path(rpath)

                if p.exists() and full_hash(p) == md5_exp:
                    conn.sendall(b'SKIP\n')
                    return

                conn.sendall(b'OK\n')
                print(f'[↑] {addr[0]} → {rpath}')

                if recv_file_fast(conn, p, size):
                    if full_hash(p) == md5_exp:
                        conn.sendall(b'OK\n')
                        print(f'[↑] Done: {rpath}')
                    else:
                        conn.sendall(b'HASH\n')
                else:
                    conn.sendall(b'FAIL\n')

            elif cmd == 'PUTZ':
                # Compressed upload: PUTZ:auth:path:compressed_size:original_size:md5
                rpath = ':'.join(parts[2:-3])
                comp_size, orig_size, md5_exp = int(parts[-3]), int(parts[-2]), parts[-1]
                p = Path(rpath)

                if p.exists() and full_hash(p) == md5_exp:
                    conn.sendall(b'SKIP\n')
                    return

                conn.sendall(b'OK\n')
                ratio = orig_size / comp_size if comp_size > 0 else 1
                print(f'[↑Z] {addr[0]} → {rpath} ({ratio:.1f}x compression)')

                # Receive compressed data
                compressed = b''
                while len(compressed) < comp_size:
                    chunk = conn.recv(min(CHUNK, comp_size - len(compressed)))
                    if not chunk:
                        break
                    compressed += chunk

                if len(compressed) == comp_size:
                    try:
                        # Decompress and write
                        original = decompress_data(compressed)
                        p.parent.mkdir(parents=True, exist_ok=True)
                        with open(p, 'wb') as f:
                            f.write(original)

                        if full_hash(p) == md5_exp:
                            conn.sendall(b'OK\n')
                            print(f'[↑Z] Done: {rpath}')
                        else:
                            conn.sendall(b'HASH\n')
                    except Exception as e:
                        print(f'[ERR] Decompress failed: {e}')
                        conn.sendall(b'FAIL\n')
                else:
                    conn.sendall(b'FAIL\n')

            elif cmd == 'RESUME':
                # RESUME:secret:path:offset:total_size:partial_hash:full_hash
                rpath = ':'.join(parts[2:-4])
                offset, total_size = int(parts[-4]), int(parts[-3])
                phash_exp, fhash_exp = parts[-2], parts[-1]
                p = Path(rpath)

                # Check if file already complete
                if p.exists() and full_hash(p) == fhash_exp:
                    conn.sendall(b'SKIP\n')
                    print(f'[RESUME] {addr[0]} → {rpath} (already complete)')
                    return

                # Check partial file
                if p.exists():
                    current_size = p.stat().st_size
                    if current_size > 0 and current_size <= offset:
                        # Verify partial hash
                        if partial_hash(p, current_size) == phash_exp[:32]:
                            # Can resume from current position
                            conn.sendall(f'OK:{current_size}\n'.encode())
                            print(f'[RESUME] {addr[0]} → {rpath} from {current_size}/{total_size}')

                            # Receive remaining data (append mode)
                            remaining = total_size - current_size
                            with open(p, 'ab') as f:
                                received = 0
                                while received < remaining:
                                    chunk = conn.recv(min(CHUNK, remaining - received))
                                    if not chunk:
                                        break
                                    f.write(chunk)
                                    received += len(chunk)

                            # Verify final hash
                            if full_hash(p) == fhash_exp:
                                conn.sendall(b'OK\n')
                                print(f'[RESUME] Done: {rpath}')
                            else:
                                conn.sendall(b'HASH\n')
                            return

                # Cannot resume - start fresh
                conn.sendall(b'RESTART:0\n')
                print(f'[RESUME] {addr[0]} → {rpath} (restart)')

                # Receive full file
                if recv_file_fast(conn, p, total_size):
                    if full_hash(p) == fhash_exp:
                        conn.sendall(b'OK\n')
                        print(f'[RESUME] Done: {rpath}')
                    else:
                        conn.sendall(b'HASH\n')
                else:
                    conn.sendall(b'FAIL\n')

            elif cmd == 'PUTM':
                # Multi-connection start
                rpath, size, md5_exp, num_conn = ':'.join(parts[2:-3]), int(parts[-3]), parts[-2], int(parts[-1])
                p = Path(rpath)

                if p.exists() and full_hash(p) == md5_exp:
                    conn.sendall(b'SKIP\n')
                    return

                session_id = str(uuid.uuid4())[:8]
                sessions[session_id] = {
                    'path': p,
                    'size': size,
                    'md5': md5_exp,
                    'chunks': {},
                    'lock': threading.Lock()
                }
                conn.sendall(f'OK:{session_id}\n'.encode())
                print(f'[↑M] {addr[0]} → {rpath} (session: {session_id})')

            elif cmd == 'PUTC':
                # Receive chunk
                session_id, idx, offset, length = parts[2], int(parts[3]), int(parts[4]), int(parts[5])

                if session_id not in sessions:
                    conn.sendall(b'NOSESSION\n')
                    return

                sess = sessions[session_id]
                conn.sendall(b'OK\n')

                # Save chunk to temp file
                tmp_path = Path(f'/tmp/vssh_{session_id}_{idx}')
                if recv_file_fast(conn, tmp_path, length):
                    with sess['lock']:
                        sess['chunks'][idx] = tmp_path

                        # All chunks received?
                        if len(sess['chunks']) == MULTI_CONN:
                            # Merge files
                            sess['path'].parent.mkdir(parents=True, exist_ok=True)
                            with open(sess['path'], 'wb') as f:
                                for i in range(MULTI_CONN):
                                    with open(sess['chunks'][i], 'rb') as cf:
                                        f.write(cf.read())
                                    sess['chunks'][i].unlink()
                            del sessions[session_id]
                            print(f'[↑M] Done: {sess["path"]}')

                    conn.sendall(b'OK\n')
                else:
                    conn.sendall(b'FAIL\n')

            elif cmd == 'GET':
                rpath = ':'.join(parts[2:])
                p = Path(rpath)

                if not p.exists():
                    conn.sendall(b'NOTFOUND\n')
                    return

                size = p.stat().st_size
                md5 = full_hash(p)
                conn.sendall(f'OK:{size}:{md5}\n'.encode())
                print(f'[↓] {addr[0]} ← {rpath}')
                send_file_fast(conn, p)

            elif cmd == 'GETM':
                # Multi-connection download start
                # GETM:secret:path:num_conn
                rpath, num_conn = ':'.join(parts[2:-1]), int(parts[-1])
                p = Path(rpath)

                if not p.exists():
                    conn.sendall(b'NOTFOUND\n')
                    return

                size = p.stat().st_size
                md5 = full_hash(p)
                session_id = str(uuid.uuid4())[:8]

                # Calculate chunk info
                chunk_size = size // num_conn
                chunks = []
                for i in range(num_conn):
                    offset = i * chunk_size
                    length = chunk_size if i < num_conn - 1 else (size - offset)
                    chunks.append({'offset': offset, 'length': length})

                sessions[session_id] = {
                    'path': p,
                    'size': size,
                    'md5': md5,
                    'chunks': chunks,
                    'num_conn': num_conn
                }

                conn.sendall(f'OK:{session_id}:{size}:{md5}:{num_conn}\n'.encode())
                print(f'[↓M] {addr[0]} ← {rpath} (session: {session_id})')

            elif cmd == 'GETC':
                # Download chunk
                # GETC:secret:session_id:chunk_idx
                session_id, idx = parts[2], int(parts[3])

                if session_id not in sessions:
                    conn.sendall(b'NOSESSION\n')
                    return

                sess = sessions[session_id]
                if idx >= len(sess['chunks']):
                    conn.sendall(b'BADIDX\n')
                    return

                chunk = sess['chunks'][idx]
                conn.sendall(f"OK:{chunk['offset']}:{chunk['length']}\n".encode())
                send_file_fast(conn, sess['path'], offset=chunk['offset'], length=chunk['length'])

            elif cmd == 'SYNC':
                rpath, manifest_len = ':'.join(parts[2:-1]), int(parts[-1])
                conn.sendall(b'OK\n')

                manifest = b''
                while len(manifest) < manifest_len:
                    manifest += conn.recv(manifest_len - len(manifest))
                files = json.loads(manifest.decode())

                need = []
                remote_dir = Path(rpath)
                for rel, info in files.items():
                    rf = remote_dir / rel
                    if not rf.exists() or rf.stat().st_size != info['size'] or file_hash(rf) != info['hash']:
                        need.append(rel)

                need_json = json.dumps(need).encode()
                conn.sendall(f'{len(need_json)}\n'.encode())
                conn.sendall(need_json)
                print(f'[SYNC] {addr[0]} → {rpath}: {len(need)} needed')

            elif cmd == 'RSYNC_SIG':
                # Delta sync: send block signatures
                rpath = ':'.join(parts[2:])
                p = Path(rpath)

                if not p.exists():
                    conn.sendall(b'NOFILE\n')
                    return

                # Build and send signatures
                sigs = build_block_signatures(p)
                sig_json = json.dumps(sigs).encode()
                conn.sendall(f'SIG:{len(sig_json)}\n'.encode())
                conn.sendall(sig_json)
                print(f'[RSYNC] {addr[0]} ← {rpath} signatures ({len(sigs)} blocks)')

            elif cmd == 'RSYNC_DELTA':
                # Delta sync: receive and apply delta
                # RSYNC_DELTA:auth:path:delta_size:expected_md5
                rpath = ':'.join(parts[2:-2])
                delta_size, md5_exp = int(parts[-2]), parts[-1]
                p = Path(rpath)

                conn.sendall(b'OK\n')
                print(f'[RSYNC] {addr[0]} → {rpath} delta ({delta_size} bytes)')

                # Receive delta
                delta_data = b''
                while len(delta_data) < delta_size:
                    chunk = conn.recv(min(CHUNK, delta_size - len(delta_data)))
                    if not chunk:
                        break
                    delta_data += chunk

                if len(delta_data) != delta_size:
                    conn.sendall(b'FAIL\n')
                    return

                try:
                    # Parse delta
                    delta_raw = json.loads(delta_data.decode())
                    delta = [
                        (op[0], op[1], bytes.fromhex(op[2]) if op[0] == 'DATA' else op[2])
                        for op in delta_raw
                    ]

                    # Apply delta
                    if apply_delta(p, delta, p if p.exists() else None):
                        if full_hash(p) == md5_exp:
                            conn.sendall(b'OK\n')
                            print(f'[RSYNC] Done: {rpath}')
                        else:
                            conn.sendall(b'HASH\n')
                    else:
                        conn.sendall(b'FAIL\n')
                except Exception as e:
                    print(f'[RSYNC] Error: {e}')
                    conn.sendall(b'FAIL\n')

            elif cmd == 'SSH':
                cmdline = ':'.join(parts[2:])
                _dangerous = ['rm -rf /', 'mkfs ', 'dd if=/dev/zero']
                if any(d in cmdline for d in _dangerous):
                    conn.sendall(b'FAIL\n')
                    print(f'[SSH] BLOCKED dangerous: {cmdline}')
                else:
                    conn.sendall(b'OK\n')
                    print(f'[SSH] {addr[0]}: {cmdline}')
                    result = subprocess.run(cmdline, shell=True, capture_output=True, timeout=60)
                    conn.sendall(result.stdout + result.stderr + b'__END__')

            elif cmd == 'PTY_SESSION':
                # PTY_SESSION:auth:rows:cols  →  full bash PTY relay
                try:
                    rows = int(parts[2]) if len(parts) > 2 else 24
                    cols = int(parts[3]) if len(parts) > 3 else 80
                except (IndexError, ValueError):
                    rows, cols = 24, 80
                conn.sendall(b'PTY_OK\n')
                print(f'[PTY] {addr[0]} {rows}x{cols}')
                import pty as _pty, select as _sel, fcntl as _fcntl
                import termios as _ter, struct as _stru
                mfd, sfd = _pty.openpty()
                _fcntl.ioctl(sfd, _ter.TIOCSWINSZ,
                             _stru.pack('HHHH', rows, cols, 0, 0))
                proc = subprocess.Popen(
                    ['/bin/bash', '-l'],
                    stdin=sfd, stdout=sfd, stderr=sfd,
                    preexec_fn=os.setsid, close_fds=True
                )
                os.close(sfd)
                cfd = conn.fileno()
                try:
                    while proc.poll() is None:
                        r, _, _ = _sel.select([cfd, mfd], [], [], 0.05)
                        if cfd in r:
                            data = conn.recv(4096)
                            if not data:
                                break
                            try:
                                os.write(mfd, data)
                            except OSError:
                                break
                        if mfd in r:
                            try:
                                data = os.read(mfd, 4096)
                                if data:
                                    conn.sendall(data)
                            except OSError:
                                break
                finally:
                    try:
                        proc.terminate()
                        proc.wait(timeout=2)
                    except Exception:
                        pass
                    try:
                        os.close(mfd)
                    except Exception:
                        pass
                print(f'[PTY] {addr[0]} session ended')

            elif cmd == 'INFO':
                conn.sendall(b'OK\n')

                def run(cmd):
                    try:
                        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
                        return r.stdout.strip() or r.stderr.strip() or '-'
                    except (subprocess.SubprocessError, OSError):
                        return '-'

                info = {
                    'hostname': run('hostname'),
                    'os': run('cat /etc/os-release 2>/dev/null | grep PRETTY_NAME | cut -d= -f2 | tr -d \\"') or run('sw_vers -productName 2>/dev/null'),
                    'kernel': run('uname -r'),
                    'uptime': run('uptime -p 2>/dev/null || uptime | sed "s/.*up/up/"'),
                    'cpu': run('grep "model name" /proc/cpuinfo 2>/dev/null | head -1 | cut -d: -f2 | xargs') or run('sysctl -n machdep.cpu.brand_string 2>/dev/null'),
                    'cores': run('nproc 2>/dev/null || sysctl -n hw.ncpu 2>/dev/null'),
                    'load': run('cat /proc/loadavg 2>/dev/null | cut -d" " -f1-3') or run('sysctl -n vm.loadavg 2>/dev/null'),
                    'gpu': run('nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | head -1') or run('lspci 2>/dev/null | grep -i vga | cut -d: -f3 | head -1') or 'none',
                    'memory': run('free -h 2>/dev/null | grep Mem | awk \'{print "Total "$2" / Used "$3" / Free "$4}\'') or run('echo "$(( $(sysctl -n hw.memsize 2>/dev/null) / 1024 / 1024 / 1024 ))GB"'),
                    'ip': run('hostname -I 2>/dev/null | cut -d" " -f1') or run('ipconfig getifaddr en0 2>/dev/null'),
                    'vpn_ip': run('ip addr show 2>/dev/null | grep "10.99" | awk \'{print $2}\' | cut -d/ -f1') or '-'
                }
                conn.sendall(json.dumps(info).encode() + b'__END__')

            elif cmd == 'PIPE_UP':
                # Pipe stdin to file: PIPE_UP:auth:path:size:md5
                rpath, size, md5_exp = ':'.join(parts[2:-2]), int(parts[-2]), parts[-1]
                p = Path(rpath)
                conn.sendall(b'OK\n')
                print(f'[PIPE_UP] {addr[0]} → {rpath} ({size} bytes)')

                # Receive data
                data = b''
                while len(data) < size:
                    chunk = conn.recv(min(get_adaptive_chunk(), size - len(data)))
                    if not chunk:
                        break
                    data += chunk

                if len(data) == size:
                    # Verify and write
                    if hashlib.md5(data).hexdigest() == md5_exp:
                        p.parent.mkdir(parents=True, exist_ok=True)
                        with open(p, 'wb') as f:
                            f.write(data)
                        conn.sendall(b'OK\n')
                        print(f'[PIPE_UP] Done: {rpath}')
                    else:
                        conn.sendall(b'HASH\n')
                else:
                    conn.sendall(b'FAIL\n')

            elif cmd == 'PIPE_DOWN':
                # Pipe command output to stdout: PIPE_DOWN:auth:cmd
                cmdline = ':'.join(parts[2:])
                print(f'[PIPE_DOWN] {addr[0]}: {cmdline}')
                _dangerous = ['rm -rf /', 'mkfs ', 'dd if=/dev/zero']
                if any(d in cmdline for d in _dangerous):
                    conn.sendall(b'FAIL\n')
                    print(f'[PIPE_DOWN] BLOCKED dangerous: {cmdline}')
                else:
                    result = subprocess.run(cmdline, shell=True, capture_output=True, timeout=600)
                    output = result.stdout
                    conn.sendall(f'OK:{len(output)}\n'.encode())
                    conn.sendall(output)

            elif cmd == 'MPUT':
                # Multiplexed put: MPUT:auth:file_count
                file_count = int(parts[2]) if len(parts) > 2 else 0
                print(f'[MPUT] {addr[0]}: {file_count} files')
                conn.sendall(b'OK\n')

                ok_count = 0
                skip_count = 0
                fail_count = 0

                for _ in range(file_count):
                    # Read file header: FILE:path:size:md5 or SKIP_FILE
                    header = b''
                    while b'\n' not in header:
                        chunk = conn.recv(1024)
                        if not chunk:
                            break
                        header += chunk

                    if not header:
                        break

                    header_line = header.split(b'\n')[0].decode()

                    if header_line == 'SKIP_FILE':
                        fail_count += 1
                        continue

                    if not header_line.startswith('FILE:'):
                        fail_count += 1
                        continue

                    # Parse: FILE:path:size:md5
                    file_parts = header_line.split(':')
                    rpath = ':'.join(file_parts[1:-2])
                    size = int(file_parts[-2])
                    md5_exp = file_parts[-1]

                    p = Path(rpath)

                    # Check if file already exists with same hash
                    if p.exists() and full_hash(p) == md5_exp:
                        conn.sendall(b'SKIP\n')
                        skip_count += 1
                        print(f'  [SKIP] {rpath}')
                        continue

                    conn.sendall(b'OK\n')

                    # Receive file data
                    p.parent.mkdir(parents=True, exist_ok=True)
                    if recv_file_fast(conn, p, size):
                        if full_hash(p) == md5_exp:
                            conn.sendall(b'OK\n')
                            ok_count += 1
                            print(f'  [OK] {rpath} ({size} bytes)')
                        else:
                            conn.sendall(b'HASH\n')
                            fail_count += 1
                            print(f'  [HASH] {rpath}')
                    else:
                        conn.sendall(b'FAIL\n')
                        fail_count += 1
                        print(f'  [FAIL] {rpath}')

                # Wait for END marker
                end = conn.recv(64)
                conn.sendall(f'DONE:{ok_count}:{skip_count}:{fail_count}\n'.encode())
                print(f'[MPUT] Done: {ok_count} ok, {skip_count} skip, {fail_count} fail')

            elif cmd == 'RPC':
                # RPC protocol: RPC:secret:method:payload_length
                # Then receive payload (JSON)
                method = parts[2] if len(parts) > 2 else ''
                payload_len = int(parts[3]) if len(parts) > 3 else 0

                if method not in RPC_METHODS:
                    conn.sendall(json.dumps({
                        'error': 'unknown_method',
                        'available': list(RPC_METHODS.keys())
                    }).encode() + b'__END__')
                    return

                conn.sendall(b'OK\n')

                # Receive payload
                payload = {}
                if payload_len > 0:
                    payload_data = b''
                    while len(payload_data) < payload_len:
                        chunk = conn.recv(payload_len - len(payload_data))
                        if not chunk:
                            break
                        payload_data += chunk
                    try:
                        payload = json.loads(payload_data.decode())
                    except (json.JSONDecodeError, ValueError, UnicodeDecodeError):
                        payload = {}

                print(f'[RPC] {addr[0]}: {method}({payload})')
                result = handle_rpc(method, payload, sender_ip=addr[0])
                conn.sendall(result.encode() + b'__END__')

            elif cmd == 'RPC_LIST':
                # List available RPC methods
                methods_info = {}
                for name in RPC_METHODS:
                    methods_info[name] = {
                        'permission': RPC_PERMISSIONS.get(name, 'read')
                    }
                conn.sendall(json.dumps({'methods': methods_info}).encode() + b'__END__')

            # ========== Persistent Session Commands ==========
            elif cmd == 'SESSION':
                # SESSION:secret - create new session, keep connection
                cleanup_sessions()  # Clean old sessions
                session_id = generate_session_id()
                with SESSION_LOCK:
                    PERSISTENT_SESSIONS[session_id] = {
                        'conn': conn,
                        'addr': addr,
                        'created': time.time(),
                        'last_active': time.time()
                    }
                print(f'[SESSION] New: {session_id[:8]}... from {addr[0]}')
                conn.sendall(f'SESSION_OK:{session_id}\n'.encode())

                # Session loop: process commands until connection closes
                try:
                    while True:
                        # Read CMD:session_id:protocol:... format
                        cmd_line = b''
                        while True:
                            ch = conn.recv(1)
                            if not ch or ch == b'\n':
                                break
                            cmd_line += ch

                        if not cmd_line:
                            break

                        cmd_str = cmd_line.decode('utf-8', errors='ignore')
                        if cmd_str.startswith('CLOSE:'):
                            # CLOSE:session_id - close session
                            print(f'[SESSION] Close: {session_id[:8]}...')
                            conn.sendall(b'CLOSE_OK\n')
                            break

                        if not cmd_str.startswith('CMD:'):
                            conn.sendall(b'ERR:invalid_format\n')
                            continue

                        # CMD:session_id:protocol:payload_length
                        parts = cmd_str.split(':', 3)
                        if len(parts) < 4:
                            conn.sendall(b'ERR:missing_parts\n')
                            continue

                        _, sid, protocol, rest = parts
                        if sid != session_id:
                            conn.sendall(b'ERR:session_mismatch\n')
                            continue

                        # Update session activity time
                        with SESSION_LOCK:
                            if session_id in PERSISTENT_SESSIONS:
                                PERSISTENT_SESSIONS[session_id]['last_active'] = time.time()

                        if protocol == 'RPC':
                            # CMD:sid:RPC:method:payload_len
                            rpc_parts = rest.split(':', 1)
                            method = rpc_parts[0]
                            payload_len = int(rpc_parts[1]) if len(rpc_parts) > 1 else 0

                            payload = {}
                            if payload_len > 0:
                                payload_data = b''
                                while len(payload_data) < payload_len:
                                    chunk = conn.recv(payload_len - len(payload_data))
                                    if not chunk:
                                        break
                                    payload_data += chunk
                                try:
                                    payload = json.loads(payload_data.decode())
                                except (json.JSONDecodeError, ValueError, UnicodeDecodeError) as e:
                                    pass  # e silenced

                            result = handle_rpc(method, payload, sender_ip=addr[0])
                            conn.sendall(f'RPC_RESULT:{len(result)}\n'.encode())
                            conn.sendall(result.encode())

                        elif protocol == 'SSH':
                            # CMD:sid:SSH:command_length
                            cmd_len = int(rest)
                            command = b''
                            while len(command) < cmd_len:
                                chunk = conn.recv(cmd_len - len(command))
                                if not chunk:
                                    break
                                command += chunk

                            import subprocess
                            try:
                                r = subprocess.run(command.decode(), shell=True,
                                                 capture_output=True, timeout=120)
                                output = r.stdout + r.stderr
                                conn.sendall(f'SSH_RESULT:{r.returncode}:{len(output)}\n'.encode())
                                conn.sendall(output)
                            except subprocess.TimeoutExpired:
                                conn.sendall(b'SSH_RESULT:124:7\ntimeout')
                            except Exception as e:
                                err = str(e).encode()
                                conn.sendall(f'SSH_RESULT:1:{len(err)}\n'.encode())
                                conn.sendall(err)

                        elif protocol == 'INFO':
                            # CMD:sid:INFO:0 - server info
                            import platform
                            info_data = json.dumps({
                                'hostname': socket.gethostname(),
                                'platform': platform.system(),
                                'session_id': session_id,
                                'uptime': time.time() - PERSISTENT_SESSIONS.get(session_id, {}).get('created', time.time())
                            })
                            conn.sendall(f'INFO_RESULT:{len(info_data)}\n'.encode())
                            conn.sendall(info_data.encode())

                        else:
                            conn.sendall(f'ERR:unknown_protocol:{protocol}\n'.encode())

                finally:
                    # Clean up session
                    with SESSION_LOCK:
                        if session_id in PERSISTENT_SESSIONS:
                            del PERSISTENT_SESSIONS[session_id]
                    print(f'[SESSION] End: {session_id[:8]}...')
                return  # Exit handle() after session ends (conn.close() in finally)

        except Exception as e:
            print(f'[ERR] {e}')
        finally:
            conn.close()

    print('Server running...')
    try:
        while True:
            conn, addr = srv.accept()
            threading.Thread(target=handle, args=(conn, addr), daemon=True).start()
    except KeyboardInterrupt:
        print('\nStopped')


def _cmd_install(args):
    """Install/upgrade vssh as a system daemon. Idempotent — safe to re-run."""
    import sys as _sys, os as _os, platform as _plat, subprocess as _sp, shutil as _sh

    python_exe = _sys.executable
    secret = _load_vssh_secret()
    sf = VSSH_DIR_CONF / 'secret'
    secret_src = 'env' if _os.environ.get('VSSH_SECRET') else ('file' if sf.exists() else 'auto-generated')

    print(f"[vssh install]")
    print(f"  python  : {python_exe}")
    print(f"  secret  : {secret[:6]}...{secret[-4:]} ({secret_src})")

    # --- Step 1: Upgrade pip package ---
    print(f"  pip     : upgrading vssh...")
    pip_args = [python_exe, '-m', 'pip', 'install', 'git+https://github.com/meshpop/vssh.git', '--upgrade', '-q']
    if _plat.system() == 'Linux':
        pip_args.append('--break-system-packages')
    r = _sp.run(pip_args, capture_output=True, text=True)
    if r.returncode == 0:
        print(f"  pip     : \u2713 ok")
    else:
        print(f"  pip     : \u2717 {r.stderr.strip()[:120]}")

    # --- Step 2: Find installed vssh.py from pip (not the running script) ---
    installed_py = None
    try:
        r2 = _sp.run([python_exe, '-m', 'pip', 'show', 'vssh'],
                     capture_output=True, text=True)
        for _line in r2.stdout.splitlines():
            if _line.startswith('Location:'):
                _loc = _line.split(':', 1)[1].strip()
                _cand = _os.path.join(_loc, 'vssh.py')
                if _os.path.isfile(_cand):
                    installed_py = _cand
                break
    except Exception:
        pass
    if not installed_py:
        installed_py = _os.path.abspath(__file__)

    # --- Step 3: Copy vssh.py to /usr/local/bin/vssh.py ---
    target_py = '/usr/local/bin/vssh.py'
    try:
        import os.path as _osp
        if _osp.exists(target_py) and _osp.samefile(installed_py, target_py):
            print(f"  skipped : already up to date ({target_py})")
        else:
            _sh.copy2(installed_py, target_py)
            _os.chmod(target_py, 0o755)
            print(f"  copied  : {installed_py} \u2192 {target_py}")
    except PermissionError:
        print(f"  warning : cannot write {target_py} (need root) — using {installed_py}")
        target_py = installed_py

    # --- Step 4: Create /usr/local/bin/vssh wrapper with explicit python path ---
    wrapper = '/usr/local/bin/vssh'
    wrapper_txt = f'#!/bin/sh\nexec {python_exe} {target_py} "$@"\n'
    try:
        with open(wrapper, 'w') as _f:
            _f.write(wrapper_txt)
        _os.chmod(wrapper, 0o755)
        print(f"  wrapper : {wrapper}")
    except PermissionError:
        print(f"  warning : cannot write {wrapper} (need root)")

    if _plat.system() == 'Linux':
        svc_lines = [
            "[Unit]", "Description=vssh daemon", "After=network.target", "",
            "[Service]", "Type=simple",
            f"ExecStart={python_exe} {target_py} server",
            f"Environment=\"VSSH_SECRET={secret}\"",
            "Restart=always", "RestartSec=5",
            "StandardOutput=journal", "StandardError=journal", "",
            "[Install]", "WantedBy=multi-user.target", "",
        ]
        service = '\n'.join(svc_lines)
        svc_path = '/etc/systemd/system/vssh.service'
        try:
            with open(svc_path, 'w') as _f:
                _f.write(service)
            print(f"  service : {svc_path}")
            _sp.run(['systemctl', 'daemon-reload'], check=True, capture_output=True)
            _sp.run(['systemctl', 'enable', 'vssh'], check=True, capture_output=True)
            _sp.run(['systemctl', 'restart', 'vssh'], check=True, capture_output=True)
            import time; time.sleep(1)
            r = _sp.run(['systemctl', 'is-active', 'vssh'], capture_output=True, text=True)
            status = r.stdout.strip()
            print(f"  status  : {status}")
            if status == 'active':
                print("[vssh install] \u2713 Done. vssh daemon running.")
            else:
                print("[vssh install] \u2717 Service not active — check: journalctl -u vssh -n 20")
        except PermissionError:
            print("[vssh install] \u2717 Need root. Run: sudo vssh install")
        except Exception as e:
            print(f"[vssh install] \u2717 Error: {e}")

    elif _plat.system() == 'Darwin':
        home = _os.path.expanduser('~')
        plist_dir = _os.path.join(home, 'Library', 'LaunchAgents')
        _os.makedirs(plist_dir, exist_ok=True)
        plist_path = _os.path.join(plist_dir, 'com.vssh.server.plist')
        plist_lines = [
            '<?xml version="1.0" encoding="UTF-8"?>',
            '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">',
            '<plist version="1.0">',
            '<dict>',
            '    <key>Label</key>',
            '    <string>com.vssh.server</string>',
            '    <key>ProgramArguments</key>',
            '    <array>',
            f'        <string>{python_exe}</string>',
            f'        <string>{target_py}</string>',
            '        <string>server</string>',
            '    </array>',
            '    <key>EnvironmentVariables</key>',
            '    <dict>',
            '        <key>VSSH_SECRET</key>',
            f'        <string>{secret}</string>',
            '    </dict>',
            '    <key>RunAtLoad</key>',
            '    <true/>',
            '    <key>KeepAlive</key>',
            '    <true/>',
            '    <key>StandardOutPath</key>',
            '    <string>/tmp/vssh.log</string>',
            '    <key>StandardErrorPath</key>',
            '    <string>/tmp/vssh.err</string>',
            '</dict>',
            '</plist>',
        ]
        plist = '\n'.join(plist_lines)
        # Also fix pip entry point if it exists (may use wrong Python)
        for ep in [_os.path.join(_os.path.dirname(python_exe), 'vssh'),
                   '/opt/homebrew/bin/vssh', '/usr/local/bin/vssh']:
            if ep != wrapper and _os.path.exists(ep):
                try:
                    _sh.copy2(wrapper, ep)
                    _os.chmod(ep, 0o755)
                    print(f"  fixed   : {ep}")
                except Exception:
                    pass
        _sp.run(['launchctl', 'unload', plist_path], capture_output=True)
        with open(plist_path, 'w') as _f:
            _f.write(plist)
        print(f"  plist   : {plist_path}")
        r = _sp.run(['launchctl', 'load', plist_path], capture_output=True, text=True)
        if r.returncode == 0:
            import time; time.sleep(1)
            r2 = _sp.run(['pgrep', '-f', f'{target_py} server'], capture_output=True, text=True)
            if r2.stdout.strip():
                print("[vssh install] \u2713 Done. vssh daemon running.")
            else:
                print("[vssh install] \u2717 Process not found — check: cat /tmp/vssh.err")
        else:
            print(f"[vssh install] \u2717 launchctl error: {r.stderr.strip()}")
    else:
        print(f"[vssh install] \u2717 Unsupported OS: {_plat.system()}")


def _get_vssh_version():
    try:
        from importlib.metadata import version as _v
        return _v('vssh')
    except Exception:
        return '?'



def main():
    args = sys.argv[1:]
    # Handle --version and --help flags
    if args and args[0] in ("--version", "-v", "-V"):
        try:
            from importlib.metadata import version as _v
            print(f"vssh v{_v('vssh')}")
        except Exception:
            print(f"vssh v{_get_vssh_version()}")
        return
    if not args:
        print('''vssh v3 - Distributed command & file transport daemon for server meshes

Cluster status:
  status                           Connection status to all servers
  stats [days]                     Transfer statistics
  history [count] [op] [host]      Command history (default: last 20)

Remote execution:
  ssh  <host> "command"            Execute command (PTY)
  <host>                           Interactive terminal (shortcut)
  session <host>                   Persistent terminal session
  session-test <host>              Session test (3 RPC calls)

RPC (structured method calls):
  rpc  <host> <method> [JSON]      Remote procedure call
  rpc-list <host>                  List available methods
  info <host>                      Node info (JSON)

File transfer:
  put  <local> <host>:<remote>     Upload (auto-compress, MD5 skip)
  put  -z <local> <host>:<remote>  Force compression
  put  --resume <local> <host>:<remote>  Resume large files (100MB+)
  get  <host>:<remote> <local>     Download (auto multi-conn for 100MB+)
  sync <local_dir> <host>:<remote> Directory sync (8 parallel streams)
  mput <host>:<base> file1 file2   Multi-file upload (single connection)
  fast <local> <host>:<remote>     Auto-select best transfer method
  p2p  <local> <host>:<remote>     P2P direct (NAT hole-punch)
  rsync <local> <host>:<remote>    Delta sync (only changed blocks)

Pipes:
  pipe <host>:<path>               stdin → remote file
  pipe <host>:"cmd"                remote cmd → stdout

Server:
  server                           Start daemon

RPC examples:
  rpc g1 get_gpu                        GPU status
  rpc g1 get_disk '{"path":"/"}'        Disk usage
  rpc g1 get_processes '{"n":5}'        Top processes
  rpc g1 get_logs '{"service":"nginx","lines":20}'
  rpc g1 restart_service '{"service":"ollama"}'

Env: VSSH_SECRET
''')
        return

    cmd = args[0]
    if cmd == 'put':
        # Check for --resume, --compress, --retry, --limit flags
        resume = '--resume' in args or '-r' in args
        compress = True if ('-z' in args or '--compress' in args) else (False if '--no-compress' in args else None)
        retry = RETRY_MAX if '--retry' in args else 0
        no_lan = '--no-lan' in args
        # Parse --retry=N and --limit=X
        for a in args:
            if a.startswith('--retry='):
                retry = int(a.split('=')[1])
            elif a.startswith('--limit='):
                set_rate_limit(a.split('=')[1])
        put_args = [a for a in args[1:] if not a.startswith('-')]
        result = put(put_args[0], put_args[1], resume=resume, compress=compress, retry=retry, lan=not no_lan)
        log_event('PUT', put_args[1].split(':')[0], put_args[0] + ' -> ' + put_args[1], 'OK' if result else 'FAIL')
        sys.exit(0 if result else 1)
    elif cmd == 'get':
        retry = RETRY_MAX if '--retry' in args else 0
        no_lan = '--no-lan' in args
        for a in args:
            if a.startswith('--retry='):
                retry = int(a.split('=')[1])
        get_args = [a for a in args[1:] if not a.startswith('-')]
        result = get(get_args[0], get_args[1], retry=retry, lan=not no_lan)
        log_event('GET', get_args[0].split(':')[0], get_args[0] + ' -> ' + get_args[1], 'OK' if result else 'FAIL')
        sys.exit(0 if result else 1)
    elif cmd == 'sync':
        log_event('SYNC', args[2].split(':')[0] if ':' in args[2] else args[1], args[1] + ' <-> ' + args[2])
        sys.exit(0 if sync(args[1], args[2]) else 1)
    elif cmd == 'fast':
        # Fast upload with auto-method selection
        no_lan = '--no-lan' in args
        fast_args = [a for a in args[1:] if not a.startswith('-')]
        sys.exit(0 if put_fast(fast_args[0], fast_args[1], lan=not no_lan) else 1)
    elif cmd == 'p2p':
        # P2P direct transfer (NAT hole-punch, bypasses VPN relay)
        no_fallback = '--no-fallback' in args
        p2p_args = [a for a in args[1:] if not a.startswith('-')]
        if len(p2p_args) < 2:
            print('Usage: vssh p2p <local> <host>:<remote> [--no-fallback]')
            sys.exit(1)
        sys.exit(0 if put_p2p(p2p_args[0], p2p_args[1], fallback=not no_fallback) else 1)
    elif cmd == 'rsync':
        # Delta sync (only changed blocks)
        no_lan = '--no-lan' in args
        rsync_args = [a for a in args[1:] if not a.startswith('-')]
        sys.exit(0 if rsync_put(rsync_args[0], rsync_args[1], lan=not no_lan) else 1)
    elif cmd == 'ssh':
        host = resolve_name(args[1])
        log_event('SSH', args[1], args[2])
        sys.exit(ssh(host, args[2]))
    elif cmd == 'info':
        host = resolve_name(args[1])
        log_event('INFO', args[1], 'node info')
        sys.exit(info(host))
    elif cmd == 'rpc':
        host = resolve_name(args[1])
        method = args[2]
        payload = json.loads(args[3]) if len(args) > 3 else None
        result = rpc(host, method, payload)
        print(json.dumps(result, indent=2, ensure_ascii=False))
        status = 'OK' if 'error' not in result else 'FAIL'
        log_event('RPC', args[1], method, status)
        sys.exit(0 if status == 'OK' else 1)
    elif cmd == 'rpc-list':
        host = resolve_name(args[1])
        log_event('RPC', args[1], 'rpc-list')
        result = rpc_list(host)
        print(json.dumps(result, indent=2, ensure_ascii=False))
        sys.exit(0 if 'error' not in result else 1)
    elif cmd == 'session':
        # Interactive session - PTY mode (real terminal) by default
        name = args[1].split('@')[-1]  # strip user@
        host = resolve_name(name)
        if '--legacy' in args:
            # Legacy mode: line-by-line commands (no PTY)
            with VsshSession(host) as sess:
                if not sess.session_id:
                    print(f'Failed to connect to {name} ({host})')
                    sys.exit(1)
                print(f'Connected to {name}: {sess.session_id[:8]}... (type "exit" to quit)')
                while True:
                    try:
                        line = input(f'{name}> ').strip()
                    except (EOFError, KeyboardInterrupt):
                        print()
                        break
                    if not line:
                        continue
                    if line == 'exit' or line == 'quit':
                        break
                    if line == 'info':
                        print(json.dumps(sess.info(), indent=2))
                    elif line.startswith('rpc '):
                        parts = line.split(None, 2)
                        method = parts[1] if len(parts) > 1 else ''
                        payload = json.loads(parts[2]) if len(parts) > 2 else None
                        print(json.dumps(sess.rpc(method, payload), indent=2))
                    else:
                        code, out = sess.ssh(line)
                        print(out)
                        if code != 0:
                            print(f'[exit: {code}]')
        else:
            # PTY mode (default) - real terminal like SSH
            sys.exit(pty_session(host, name))
        sys.exit(0)
    elif cmd == 'session-test':
        # Session test
        host = args[1]
        print(f'Testing session to {host}...')
        start = time.time()
        with VsshSession(host) as sess:
            if not sess.session_id:
                print('Failed to connect')
                sys.exit(1)
            print(f'Connected: {sess.session_id[:8]}...')

            # 3 RPC calls on same connection
            for method in ['get_disk', 'get_memory', 'get_load']:
                t0 = time.time()
                result = sess.rpc(method)
                print(f'  {method}: {time.time()-t0:.3f}s')

            # SSH test
            t0 = time.time()
            code, out = sess.ssh('hostname')
            print(f'  ssh hostname: {time.time()-t0:.3f}s -> {out.strip()}')

            print(f'Session info: {sess.info()}')
        print(f'Total: {time.time()-start:.3f}s')
        sys.exit(0)
    elif cmd == 'stats':
        # Show transfer statistics
        days = 7
        if len(args) > 1:
            try:
                days = int(args[1])
            except (ValueError, TypeError) as e:
                pass  # e silenced
        stats = get_transfer_stats(days)
        print(f'Transfer Statistics (last {days} days)')
        print(f'  Total transfers: {stats["total"]}')
        print(f'  Total size: {stats["size_mb"]:.1f} MB')
        print(f'  Success: {stats["success"]}, Failed: {stats["fail"]}')
        if stats['by_op']:
            print(f'  By operation: {stats["by_op"]}')
        if stats['by_host']:
            print(f'  By host: {stats["by_host"]}')
        sys.exit(0)
    elif cmd == 'history':
        # Show command history
        count = 20
        op_filter = None
        host_filter = None
        for a in args[1:]:
            if a.isdigit():
                count = int(a)
            elif a.upper() in ('PUT', 'GET', 'SSH', 'RPC', 'SYNC', 'INFO', 'SESSION', 'DEPLOY'):
                op_filter = a
            elif a in SERVERS if 'SERVERS' in dir() else False:
                host_filter = a
            else:
                # Could be a hostname
                host_filter = a
        entries = get_history(count, op_filter, host_filter)
        if not entries:
            print('No history entries found.')
            sys.exit(0)
        # Print in a readable format
        for e in entries:
            status_icon = '+' if e['status'] == 'OK' else '-'
            print(f"  {status_icon} {e['time']}  {e['op']:<7} {e['host']:<6} {e['detail'][:80]}")
        print(f'\n  {len(entries)} entries')
        sys.exit(0)
    elif cmd == 'pipe-up':
        # Upload stdin to remote file
        if len(args) < 2:
            print("Usage: cat file | vssh pipe-up <host>:<path>")
            sys.exit(1)
        target = args[1]
        if ':' not in target:
            print("Error: format is host:path")
            sys.exit(1)
        host, path = target.split(':', 1)
        sys.exit(pipe_up(host, path.strip('"\'')) if not sys.stdin.isatty() else (print("Error: no input data") or 1))
    elif cmd == 'pipe-down':
        # Download remote command output to stdout
        if len(args) < 2:
            print("Usage: vssh pipe-down <host>:<cmd>")
            sys.exit(1)
        target = args[1]
        if ':' not in target:
            print("Error: format is host:cmd")
            sys.exit(1)
        host, cmd_str = target.split(':', 1)
        sys.exit(pipe_down(host, cmd_str.strip('"\'')))
    elif cmd == 'pipe':
        # Auto-detect: stdin available → upload, otherwise → download
        if len(args) < 2:
            print("Usage: vssh pipe <host>:<path_or_cmd>")
            print("       cat file | vssh pipe host:/path   # upload")
            print("       vssh pipe host:cmd > file          # download")
            print("\nExplicit:")
            print("       vssh pipe-up <host>:<path>   # upload stdin")
            print("       vssh pipe-down <host>:<cmd>  # download stdout")
            sys.exit(1)
        target = args[1]
        if ':' not in target:
            print("Error: format is host:path or host:cmd")
            sys.exit(1)
        host, path_or_cmd = target.split(':', 1)
        path_or_cmd = path_or_cmd.strip('"\'')
        # Detect stdin: if tty, no piped data. If not tty AND has data, it's piped.
        import select
        has_stdin = False
        if not sys.stdin.isatty():
            readable, _, _ = select.select([sys.stdin], [], [], 0.05)
            if readable:
                # Actually try to peek at data
                has_stdin = True
        if has_stdin:
            sys.exit(pipe_up(host, path_or_cmd))
        else:
            sys.exit(pipe_down(host, path_or_cmd))
    elif cmd == 'mput':
        # Multiplexed put: multiple files over single connection
        if len(args) < 3:
            print("Usage: vssh mput <host>:<base_path> <file1> [file2] ...")
            print("       vssh mput <host>:<base_path> <dir>/   # directory")
            print("\nExample:")
            print("  vssh mput server1:/backup file1.txt file2.txt")
            print("  vssh mput server1:/backup ./mydir/")
            sys.exit(1)
        target = args[1]
        if ':' not in target:
            print("Error: format is host:base_path")
            sys.exit(1)
        host, base_rpath = target.split(':', 1)

        # Check if it's a directory
        if len(args) == 3 and Path(args[2]).is_dir():
            result = mput_dir(args[2], target)
        else:
            # Multiple files
            files = [(f, Path(f).name) for f in args[2:] if Path(f).exists()]
            if not files:
                print("Error: no valid files found")
                sys.exit(1)
            print(f'mput: {len(files)} files → {host}:{base_rpath}')
            result = mput(files, host, base_rpath)
            print(f'  Done: {result["ok"]} ok, {result["skip"]} skip, {result["fail"]} fail')

        sys.exit(0 if result['fail'] == 0 else 1)
    elif cmd == 'up':
        # Start vssh daemon (systemd or direct)
        import subprocess as _sp, os as _os
        if _os.path.exists("/run/systemd/system"):
            r = _sp.run(["systemctl", "start", "vssh"], capture_output=True)
            if r.returncode == 0:
                print("vssh started")
            else:
                print(r.stderr.decode().strip() or "Failed to start vssh via systemctl")
        else:
            print("Starting vssh daemon...")
            server()
    elif cmd == 'down':
        # Stop vssh daemon
        import subprocess as _sp, os as _os
        if _os.path.exists("/run/systemd/system"):
            r = _sp.run(["systemctl", "stop", "vssh"], capture_output=True)
            if r.returncode == 0:
                print("vssh stopped")
            else:
                print(r.stderr.decode().strip() or "Failed to stop vssh via systemctl")
        else:
            import signal as _sig
            import glob as _glob
            killed = 0
            for _f in _glob.glob("/tmp/vssh_*.pid") + _glob.glob("/var/run/vssh.pid"):
                try:
                    _pid = int(open(_f).read().strip())
                    _os.kill(_pid, _sig.SIGTERM)
                    _os.unlink(_f)
                    killed += 1
                except (ValueError, OSError):
                    pass
            if killed:
                print(f"vssh stopped ({killed} process(es))")
            else:
                import subprocess as _sp2
                r = _sp2.run(["pkill", "-f", "vssh.*server"], capture_output=True)
                print("vssh stopped" if r.returncode == 0 else "vssh was not running")
    elif cmd == 'restart':
        # Restart vssh daemon
        import subprocess as _sp, os as _os
        if _os.path.exists("/run/systemd/system"):
            r = _sp.run(["systemctl", "restart", "vssh"], capture_output=True)
            if r.returncode == 0:
                print("vssh restarted")
            else:
                print(r.stderr.decode().strip() or "Failed to restart vssh via systemctl")
        else:
            import signal as _sig, glob as _glob
            for _f in _glob.glob("/tmp/vssh_*.pid") + _glob.glob("/var/run/vssh.pid"):
                try:
                    _pid = int(open(_f).read().strip())
                    _os.kill(_pid, _sig.SIGTERM)
                    _os.unlink(_f)
                except (ValueError, OSError):
                    pass
            print("Restarting vssh daemon...")
            server()
    elif cmd == 'server':
        server()
    elif cmd == 'install':
        _cmd_install(args)
    elif cmd == 'help' or cmd == '-h' or cmd == '--help':
        main_args_bak = sys.argv[1:]
        sys.argv = sys.argv[:1]
        main()
        sys.argv[1:] = main_args_bak
    elif cmd == 'status':
        import socket as _sock
        import concurrent.futures
        full_mode = '--full' in args or '-f' in args
        # Build server list: coordinator first (source of truth), config as supplement
        _servers = {}
        import urllib.request as _ureq
        for _srv_ip in WIRE_SERVERS:
            try:
                with _ureq.urlopen(f"http://{_srv_ip}:8790/peers", timeout=3) as _r:
                    _peers = json.loads(_r.read()).get("peers", [])
                    for _p in _peers:
                        _nn = _p.get("node_name", "")
                        _vip = _p.get("vpn_ip", "")
                        if _nn and _vip:
                            _servers[_nn] = _vip
                    break
            except (OSError, ValueError, TimeoutError):
                continue
        # Detect local node by trying to bind to each VPN IP
        def _is_local_ip(ip):
            try:
                _s = _sock.socket(_sock.AF_INET, _sock.SOCK_DGRAM)
                _s.bind((ip, 0)); _s.close(); return True
            except OSError:
                return False
        _my_vpn_ip = next((ip for ip in _servers.values() if _is_local_ip(ip)), "")
        # Also include any config entries not in coordinator (offline/static nodes)
        for k, v in VSSH_CONFIG.items():
            if k in ('SECRET', 'SSH_PORT', 'SCP_PORT'): continue
            if v and v[0].isdigit() and k not in _servers:
                _servers[k] = v

        def _check_node(name, ip):
            """Check a single node — connect + optional INFO query (Wire VPN → Tailscale fallback)"""
            if ip == _my_vpn_ip:
                return {'name': name, 'ip': ip, 'online': True, 'latency': 0, 'local': True}
            result = {'name': name, 'ip': ip, 'online': False, 'latency': 0}
            try:
                t0 = time.time()
                s = vssh_connect(ip, timeout=3.0)
                result['latency'] = (time.time() - t0) * 1000
                result['online'] = True

                if full_mode:
                    # Send INFO command to get node details
                    # Protocol: INFO:token\n -> OK\n -> JSON -> __END__
                    token = generate_hmac_token(SECRET)
                    s.sendall(f"INFO:{token}\n".encode())
                    # Read OK response first
                    ok_buf = s.recv(64)
                    if ok_buf.startswith(b'OK'):
                        buf = b""
                        deadline = time.time() + 3
                        while time.time() < deadline:
                            chunk = s.recv(8192)
                            if not chunk:
                                break
                            if b'__END__' in chunk:
                                buf += chunk.replace(b'__END__', b'')
                                break
                            buf += chunk
                        try:
                            result['info'] = json.loads(buf.decode())
                        except (json.JSONDecodeError, ValueError, UnicodeDecodeError) as e:
                            pass  # e silenced
                s.close()  # Always close — was only in full_mode, causing 13 dangling sockets on regular status
            except OSError:
                pass  # safe to ignore
            return result

        if full_mode:
            print(f"vssh v{_get_vssh_version()} - Cluster Status (full)")
        else:
            print(f"vssh v{_get_vssh_version()} - Connection Status")
        print("=" * 70)

        online = 0
        total = 0
        # Pre-warm WireGuard tunnels BEFORE status checks.
        # Fires short-timeout TCP probes to all peers simultaneously → triggers
        # WireGuard handshakes, then waits 1.2 s for them to finish.
        # By the time real checks run, all tunnels are warm → zero handshakes
        # during status → no disruption of the caller's active session.
        _peer_ips = [ip for ip in _servers.values() if ip and ip != _my_vpn_ip]
        def _prewarm(ip):
            try:
                _pw = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                _pw.settimeout(0.15)
                _pw.connect((ip, PORT))
                _pw.close()
            except Exception:
                pass
        with concurrent.futures.ThreadPoolExecutor(max_workers=len(_peer_ips) or 1) as _wp:
            list(_wp.map(_prewarm, _peer_ips))
        time.sleep(1.2)  # wait for WireGuard handshakes to complete

        # Run checks in parallel for speed — tunnels are warm, no handshakes
        results = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=14) as pool:
            futures = {pool.submit(_check_node, n, ip): n for n, ip in sorted(_servers.items()) if ip}
            for f in concurrent.futures.as_completed(futures):
                results.append(f.result())

        for r in sorted(results, key=lambda x: x['name']):
            total += 1
            if r['online']:
                online += 1
                if full_mode and 'info' in r:
                    d = r['info']
                    # Parse memory — could be string like "Total 955Mi / Used 573Mi / Free 77Mi"
                    mem_raw = d.get('memory', '')
                    if isinstance(mem_raw, str) and 'Total' in mem_raw:
                        import re
                        # "Total 955Mi / Used 573Mi / Free 77Mi"
                        nums = re.findall(r'(\d+)', mem_raw)
                        if len(nums) >= 2:
                            total_m = int(nums[0])
                            used_m = int(nums[1])
                            if total_m > 1024:
                                mem_str = f"{used_m/1024:.0f}/{total_m/1024:.0f}G"
                            else:
                                mem_str = f"{used_m}/{total_m}M"
                        else:
                            mem_str = mem_raw[:15]
                    elif isinstance(mem_raw, dict):
                        mt = mem_raw.get('total_mb', 0)
                        mu = mem_raw.get('used_mb', 0)
                        if mt > 1024:
                            mem_str = f"{mu/1024:.0f}/{mt/1024:.0f}G"
                        else:
                            mem_str = f"{mu:.0f}/{mt:.0f}M" if mt else "-"
                    elif isinstance(mem_raw, str) and mem_raw and mem_raw != '-':
                        mem_str = mem_raw[:15]
                    else:
                        mem_str = "-"
                    # Parse uptime — "up 3 days, 21 hours" or "up 10 weeks, 5 days, 21 hours"
                    uptime = d.get('uptime', '')
                    if isinstance(uptime, str) and uptime:
                        import re
                        week_m = re.search(r'(\d+)\s*week', uptime)
                        day_m = re.search(r'(\d+)\s*day', uptime)
                        hour_m = re.search(r'(\d+)\s*hour', uptime)
                        weeks = int(week_m.group(1)) if week_m else 0
                        days = int(day_m.group(1)) if day_m else 0
                        hours = int(hour_m.group(1)) if hour_m else 0
                        total_days = weeks * 7 + days
                        up_str = f"{total_days}d{hours}h"
                    elif isinstance(uptime, (int, float)):
                        days = int(uptime) // 86400
                        hours = (int(uptime) % 86400) // 3600
                        up_str = f"{days}d{hours}h"
                    else:
                        up_str = "-"
                    # Parse load — string like "0.75 0.60 0.60" or list
                    load = d.get('load', '')
                    if isinstance(load, str) and load:
                        load_str = load.split()[0] if load.split() else "-"
                    elif isinstance(load, list) and load:
                        load_str = f"{load[0]}"
                    else:
                        load_str = "-"
                    # CPU info
                    cores = d.get('cores', '')
                    cores_str = f"{cores}c" if cores else ""
                    print(f"  {r['name']:6s} ● {r['latency']:4.0f}ms  mem={mem_str:>12s}  load={load_str:>5s}  up={up_str:>7s}  {cores_str}")
                elif r.get('local'):
                    print(f"  {r['name']:6s} {r['ip']:18s} ● online  (local)")
                else:
                    print(f"  {r['name']:6s} {r['ip']:18s} ● online  ({r['latency']:.0f}ms)")
            else:
                print(f"  {r['name']:6s} {r['ip']:18s} ○ offline")
        print(f"\nTotal: {online}/{total} online")
    else:
        # Unknown command -> try as PTY session shortcut (vssh node3 = vssh session node3)
        host = resolve_name(cmd)
        rc = pty_session(host, cmd)
        if rc != 0:
            print(f'Run "vssh help" for usage')
        sys.exit(rc)

if __name__ == '__main__':
    main()
