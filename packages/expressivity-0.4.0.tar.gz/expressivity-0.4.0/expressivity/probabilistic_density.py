import time
import os
import json

import psutil
import torch
from torch import nn, optim
from torch.func import vmap, grad, stack_module_state, functional_call
from expressivity.space import ArchitecturalSpace
import matplotlib.pyplot as plt
from rich.console import Console
from rich.progress import (
    Progress,
    SpinnerColumn,
    BarColumn,
    TextColumn,
    TimeElapsedColumn,
)


console = Console()


class ArchitectureComparator:
    def __init__(
        self,
        A_space: ArchitecturalSpace,
        B_space: ArchitecturalSpace,
        base_space: ArchitecturalSpace = None,
        criterion=nn.MSELoss(),
        law=torch.distributions.Normal(0, 1),
    ) -> None:
        """
        Initialize the ArchitectureComparator.

        Parameters:
        - A_space (ArchitecturalSpace): The first architectural space.
        - B_space (ArchitecturalSpace): The second architectural space.
        - base_space (ArchitecturalSpace, optional): The base architectural space used for comparison.
        - criterion (nn.Module): Loss function used for training (default: nn.MSELoss).
        - law (torch.distributions.Distribution): Data distribution for sampling (default: Normal(0, 1)).
        """
        self.A_space = A_space
        self.B_space = B_space
        self.base_space = base_space
        self.criterion = criterion
        self.law = law

        assert (
            A_space.input_size == B_space.input_size
        ), "The input size of the two models must be the same"

        self.input_size = A_space.input_size

        assert len(A_space.parameters) == len(
            B_space.parameters
        ), "The number of architectures must be the same in space A and B"
        self.count = len(A_space.parameters)

        assert (
            A_space.automatic_mesurement_mode == B_space.automatic_mesurement_mode
            or A_space.automatic_mesurement_mode is None
            or B_space.automatic_mesurement_mode is None
        ), "The automatic mesurement mode must be the same in space A and B"

        if A_space.mesurement != B_space.mesurement:
            console.print(
                "[yellow]Warning:[/yellow] The mesurements of space A and B are different, you may not compare both model on an equal footing"
            )

        try:
            test_tensor = torch.zeros((1, *self.input_size))
            A_output_size = self._create_model(A_space, 0)(test_tensor).shape
            B_output_size = self._create_model(B_space, 0)(test_tensor).shape

            assert (
                A_output_size == B_output_size
            ), "The output size of the two models must be the same"

            self.output_size = A_output_size[1:]

            if base_space is not None:
                assert (
                    self.input_size == base_space.input_size
                ), "The input size of the two models must be the same"
                base_output_size = self._create_model(base_space, 0)(
                    test_tensor
                ).shape
                assert (
                    self.output_size == base_output_size[1:]
                ), "The output size of the two models must be the same"
                assert len(base_space.parameters) == self.count

        except Exception as e:
            console.print(f"[red]The input size is not correct:[/red] {e}")

    def compare(
        self,
        max_iterations: int = 10,
        sub_iterations: int = 1,
        variance_threashold: float | None = None,
        plot_mode: str | None = None,
        save_path: str | None = os.path.join(os.getcwd(), "results"),
    ) -> tuple[list[float]]:
        """
        Compare architectures by fitting one to the other and evaluating performance.

        Parameters:
        - max_iterations (int): Maximum number of gradient descent iterations.
        - sub_iterations (int): Number of attempts of the source architecture to minimize error at each iteration.
        - variance_threashold (float, optional): Threshold to stop iterations based on variance.
        - plot_mode (str, optional): Plot comparison results; "min" or "mean".
        - save_path (str | None): Directory to save results (images + data). Defaults to <cwd>/results/. Set to None to disable saving.

        Returns:
        - tuple[list[float]]: Minimum and mean losses for architectures A and B.
        """

        self.max_iterations = max_iterations
        self.sub_iterations = sub_iterations
        if variance_threashold is None:
            self.variance_threashold = 0
        else:
            self.variance_threashold = variance_threashold

        self.min_A_fit = [None for _ in range(self.count)]
        self.mean_A_fit = [None for _ in range(self.count)]
        self.min_B_fit = [None for _ in range(self.count)]
        self.mean_B_fit = [None for _ in range(self.count)]
        self.time_A = [None for _ in range(self.count)]
        self.time_B = [None for _ in range(self.count)]

        fits_per_model = 2
        total_steps = self.count * fits_per_model * max_iterations * sub_iterations

        with Progress(
            SpinnerColumn(),
            TextColumn("[bold blue]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(),
            console=console,
        ) as progress:
            global_task = progress.add_task("Overall", total=total_steps)

            for i in range(self.count):
                console.print(f"\n[bold]Model {i+1}/{self.count}[/bold]")

                if self.base_space is None:
                    source_A, target_A = self.A_space, self.B_space
                    source_B, target_B = self.B_space, self.A_space
                else:
                    source_A, target_A = self.A_space, self.base_space
                    source_B, target_B = self.B_space, self.base_space

                console.print(
                    f"  [cyan]{source_A.name}[/cyan] fits [magenta]{target_A.name}[/magenta]"
                )
                t0 = time.time()
                self.min_A_fit[i], self.mean_A_fit[i] = self._fit_source_to_target(
                    source_A, target_A, i, progress, global_task
                )
                self.time_A[i] = time.time() - t0

                console.print(
                    f"  [cyan]{source_B.name}[/cyan] fits [magenta]{target_B.name}[/magenta]"
                )
                t0 = time.time()
                self.min_B_fit[i], self.mean_B_fit[i] = self._fit_source_to_target(
                    source_B, target_B, i, progress, global_task
                )
                self.time_B[i] = time.time() - t0

                if self.min_B_fit[i] > self.min_A_fit[i]:
                    self.winnner = "A"
                    console.print(
                        f"  [bold green]Winner (min): {self.A_space.name}[/bold green]"
                    )
                else:
                    self.winnner = "B"
                    console.print(
                        f"  [bold green]Winner (min): {self.B_space.name}[/bold green]"
                    )

                if self.mean_B_fit[i] > self.mean_A_fit[i]:
                    if self.winnner == "A":
                        console.print(
                            f"  [bold green]{self.A_space.name} wins by all metrics[/bold green]"
                        )
                    else:
                        console.print(
                            f"  [yellow]However, {self.A_space.name} shows better mean convergence[/yellow]"
                        )
                else:
                    if self.winnner == "B":
                        console.print(
                            f"  [bold green]{self.B_space.name} wins by all metrics[/bold green]"
                        )
                    else:
                        console.print(
                            f"  [yellow]However, {self.B_space.name} shows better mean convergence[/yellow]"
                        )

        if save_path is not None:
            os.makedirs(save_path, exist_ok=True)
            self._save_data(save_path)
            self._save_plots(save_path)
            console.print(f"\n[bold green]Results saved to {save_path}[/bold green]")

        if plot_mode is not None:
            self.plot(plot_mode)

        return self.min_A_fit, self.mean_A_fit, self.min_B_fit, self.mean_B_fit

    def _create_model(self, space: ArchitecturalSpace, index: int) -> nn.Module:
        return space.architecture(**space.parameters[index])

    # ------------------------------------------------------------------ #
    #  Memory estimation & adaptive parallelism                           #
    # ------------------------------------------------------------------ #

    def _estimate_model_memory(
        self, space: ArchitecturalSpace, model_index: int
    ) -> int:
        model = self._create_model(space, model_index)
        param_bytes = sum(p.numel() * p.element_size() for p in model.parameters())
        del model
        # params + grads + adam(exp_avg + exp_avg_sq) + activation headroom
        return param_bytes * 6

    def _compute_max_parallel(
        self, source_space: ArchitecturalSpace, model_index: int
    ) -> int:
        total_runs = self.max_iterations * self.sub_iterations
        model_mem = self._estimate_model_memory(source_space, model_index)
        if model_mem == 0:
            return total_runs
        if torch.cuda.is_available():
            free_mem = torch.cuda.mem_get_info()[0]
        else:
            free_mem = psutil.virtual_memory().available
        max_p = int(free_mem * 0.7 / model_mem)
        return max(1, min(max_p, total_runs))

    @staticmethod
    def _get_device():
        return "cuda" if torch.cuda.is_available() else "cpu"

    # ------------------------------------------------------------------ #
    #  Dispatcher                                                         #
    # ------------------------------------------------------------------ #

    def _fit_source_to_target(
        self,
        source_space: ArchitecturalSpace,
        target_space: ArchitecturalSpace,
        model_index: int,
        progress: Progress = None,
        global_task=None,
    ) -> tuple[float]:
        max_parallel = self._compute_max_parallel(source_space, model_index)
        device = self._get_device()
        total_runs = self.max_iterations * self.sub_iterations
        n_chunks = (total_runs + max_parallel - 1) // max_parallel

        if max_parallel > 1:
            if n_chunks == 1:
                console.print(
                    f"    [bold green]⚡ Parallel mode[/bold green] — "
                    f"{total_runs} runs ({self.max_iterations} iter × {self.sub_iterations} sub) "
                    f"in a single batch on [bold]{device.upper()}[/bold]"
                )
            else:
                console.print(
                    f"    [bold green]⚡ Parallel mode[/bold green] — "
                    f"{total_runs} runs ({self.max_iterations} iter × {self.sub_iterations} sub) "
                    f"in {n_chunks} chunks of ≤{max_parallel} on [bold]{device.upper()}[/bold]"
                )
            try:
                return self._batched_fit(
                    source_space,
                    target_space,
                    model_index,
                    max_parallel,
                    device,
                    progress,
                    global_task,
                )
            except Exception as e:
                console.print(
                    f"    [yellow]Batched mode failed ({e}), falling back to sequential[/yellow]"
                )

        console.print(
            f"    [dim]Sequential mode — 1 run at a time on {device.upper()}[/dim]"
        )
        return self._sequential_fit(
            source_space, target_space, model_index, device, progress, global_task
        )

    # ------------------------------------------------------------------ #
    #  Batched AdamW step (operates on stacked param tensors)             #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _batched_adamw_step(
        params: dict,
        grads: dict,
        state: dict,
        lr: float,
        grad_clamp: float,
        betas: tuple = (0.9, 0.999),
        eps: float = 1e-8,
        weight_decay: float = 0.01,
    ) -> dict:
        state["step"] += 1
        t = state["step"]
        bc1 = 1 - betas[0] ** t
        bc2 = 1 - betas[1] ** t

        new_params = {}
        for key in params:
            g = grads[key].clamp(-grad_clamp, grad_clamp)

            m = betas[0] * state["exp_avg"][key] + (1 - betas[0]) * g
            v = betas[1] * state["exp_avg_sq"][key] + (1 - betas[1]) * g**2
            state["exp_avg"][key] = m
            state["exp_avg_sq"][key] = v

            m_hat = m / bc1
            v_hat = v / bc2

            # Decoupled weight decay + Adam update
            new_params[key] = params[key] * (1 - lr * weight_decay) - lr * m_hat / (
                v_hat.sqrt() + eps
            )

        return new_params

    # ------------------------------------------------------------------ #
    #  Batched fit (vmap) — iterations AND sub-iterations parallelized    #
    # ------------------------------------------------------------------ #

    def _batched_fit(
        self,
        source_space: ArchitecturalSpace,
        target_space: ArchitecturalSpace,
        model_index: int,
        max_parallel: int,
        device: str,
        progress: Progress = None,
        global_task=None,
    ) -> tuple[float]:

        total_runs = self.max_iterations * self.sub_iterations
        epochs = source_space.epoch[model_index]
        grad_clamp = source_space.grad_clamp[model_index]
        lr = source_space.lr[model_index]
        criterion = self.criterion

        mini_batch_count = (
            target_space.batch_size[model_index]
            // source_space.mini_batch_size[model_index]
        )
        mini_batch_size = source_space.mini_batch_size[model_index]
        shape = (mini_batch_count, mini_batch_size, *self.input_size)

        # -------------------------------------------------------------- #
        # 1) Pre-generate ALL data (one X + target per iteration)         #
        # -------------------------------------------------------------- #
        console.print("    [dim]Generating targets...[/dim]")
        all_X = []
        all_targets = []
        for i in range(self.max_iterations):
            X = self.law.sample(shape).to(device)
            target_model = self._create_model(target_space, model_index).to(device)
            target_model.eval()
            with torch.no_grad():
                t_out = target_model(
                    X.view(mini_batch_count * mini_batch_size, *self.input_size)
                )
                t_out = t_out.view(
                    mini_batch_count, mini_batch_size, *self.output_size
                )
            all_X.append(X)
            all_targets.append(t_out)
            del target_model
        # (max_iterations, mb_count, mb_size, *input/output_size)
        all_X = torch.stack(all_X)
        all_targets = torch.stack(all_targets)

        # Map each run to its iteration index
        # runs 0..sub-1 → iter 0, runs sub..2sub-1 → iter 1, etc.
        iter_indices = torch.arange(total_runs, device=device) // self.sub_iterations

        # -------------------------------------------------------------- #
        # 2) Base model for functional_call                               #
        # -------------------------------------------------------------- #
        base_model = self._create_model(source_space, model_index).to(device)
        base_model.train()
        for p in base_model.parameters():
            p.requires_grad_(False)

        def compute_loss(params, buffers, x, y):
            out = functional_call(base_model, (params, buffers), (x,))
            return criterion(out, y)

        # vmap over (params, buffers, x, y) — all per-run
        vmapped_grad_fn = vmap(grad(compute_loss), in_dims=(0, 0, 0, 0))
        vmapped_loss_fn = vmap(compute_loss, in_dims=(0, 0, 0, 0))

        # -------------------------------------------------------------- #
        # 3) Process runs in chunks                                       #
        # -------------------------------------------------------------- #
        all_losses = torch.zeros(total_runs, device=device)
        remaining = total_runs
        run_idx = 0

        while remaining > 0:
            chunk = min(remaining, max_parallel)
            chunk_iters = iter_indices[run_idx : run_idx + chunk]

            # Per-run data (advanced indexing into pre-generated tensors)
            chunk_X = all_X[chunk_iters]  # (chunk, mb_count, mb_size, *input)
            chunk_targets = all_targets[chunk_iters]

            console.print(
                f"    [dim]Chunk {run_idx // max_parallel + 1}: "
                f"runs {run_idx + 1}..{run_idx + chunk}/{total_runs}[/dim]"
            )

            # Create and stack source models
            models = [
                self._create_model(source_space, model_index).to(device)
                for _ in range(chunk)
            ]
            params, buffers = stack_module_state(models)
            del models
            params = {k: v.detach().requires_grad_(True) for k, v in params.items()}

            # Init Adam state
            adam_state = {
                "exp_avg": {k: torch.zeros_like(v) for k, v in params.items()},
                "exp_avg_sq": {k: torch.zeros_like(v) for k, v in params.items()},
                "step": 0,
            }

            # Training
            for epoch in range(epochs):
                for mb_idx in range(mini_batch_count):
                    grads = vmapped_grad_fn(
                        params,
                        buffers,
                        chunk_X[:, mb_idx],
                        chunk_targets[:, mb_idx],
                    )
                    with torch.no_grad():
                        params = self._batched_adamw_step(
                            params, grads, adam_state, lr, grad_clamp
                        )
                    params = {
                        k: v.detach().requires_grad_(True)
                        for k, v in params.items()
                    }

                # Log epoch (last mini-batch loss of the chunk)
                with torch.no_grad():
                    epoch_losses = vmapped_loss_fn(
                        params, buffers, chunk_X[:, -1], chunk_targets[:, -1]
                    )
                console.print(
                    f"      Epoch {epoch + 1}/{epochs}, "
                    f"Loss (mean): {epoch_losses.mean().item():.6f}"
                )

            # Final eval over all mini-batches
            with torch.no_grad():
                chunk_losses = torch.zeros(chunk, device=device)
                for mb_idx in range(mini_batch_count):
                    chunk_losses += vmapped_loss_fn(
                        params, buffers, chunk_X[:, mb_idx], chunk_targets[:, mb_idx]
                    )
                chunk_losses /= mini_batch_count

            all_losses[run_idx : run_idx + chunk] = chunk_losses

            if progress is not None:
                progress.advance(global_task, chunk)

            run_idx += chunk
            remaining -= chunk
            del params, buffers, adam_state
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

        del base_model, all_X, all_targets

        # -------------------------------------------------------------- #
        # 4) Reshape (max_iterations, sub_iterations) and aggregate       #
        # -------------------------------------------------------------- #
        all_losses = all_losses.view(self.max_iterations, self.sub_iterations)
        minimum = all_losses.min(dim=1).values  # best sub per iteration
        mean_vals = all_losses.mean(dim=1)  # mean sub per iteration

        for i in range(self.max_iterations):
            console.print(
                f"    Iteration {i + 1}/{self.max_iterations}: "
                f"min={minimum[i].item():.6f}, mean={mean_vals[i].item():.6f}"
            )

        return minimum.mean().item(), mean_vals.mean().item()

    # ------------------------------------------------------------------ #
    #  Sequential fit (fallback / CPU)                                    #
    # ------------------------------------------------------------------ #

    def _sequential_fit(
        self,
        source_space: ArchitecturalSpace,
        target_space: ArchitecturalSpace,
        model_index: int,
        device: str,
        progress: Progress = None,
        global_task=None,
    ) -> tuple[float]:

        minimum = torch.tensor([torch.inf] * self.max_iterations)
        mean = torch.zeros(self.max_iterations)

        epochs = source_space.epoch[model_index]
        grad_clamp = source_space.grad_clamp[model_index]
        criterion = self.criterion

        mini_batch_count = (
            target_space.batch_size[model_index]
            // source_space.mini_batch_size[model_index]
        )
        mini_batch_size = source_space.mini_batch_size[model_index]
        shape = (mini_batch_count, mini_batch_size, *self.input_size)

        for i in range(self.max_iterations):
            console.print(f"    [dim]Iteration {i+1}/{self.max_iterations}[/dim]")

            X = self.law.sample(shape).to(device)

            target_model = self._create_model(target_space, model_index).to(device)
            target_model.eval()
            with torch.no_grad():
                target_output = target_model(
                    X.view(mini_batch_count * mini_batch_size, *self.input_size)
                )
                target_output = target_output.view(
                    mini_batch_count, mini_batch_size, *self.output_size
                )
            del target_model

            for j in range(self.sub_iterations):
                console.print(
                    f"      [dim]Sub-iteration {j+1}/{self.sub_iterations}[/dim]"
                )
                source_model = self._create_model(source_space, model_index).to(device)
                optimizer = source_space.optimizer(
                    source_model.parameters(), source_space.lr[model_index]
                )

                # Train
                source_model.train()
                for epoch in range(epochs):
                    for mini_batch, target in zip(X, target_output):
                        optimizer.zero_grad()
                        output = source_model(mini_batch)
                        loss = criterion(output, target)
                        loss.backward()
                        torch.nn.utils.clip_grad_value_(
                            source_model.parameters(), grad_clamp
                        )
                        optimizer.step()
                    console.print(
                        f"        Epoch {epoch + 1}/{epochs}, Loss: {loss.item():.6f}"
                    )

                # Eval
                source_model.eval()
                eval_loss = 0
                with torch.no_grad():
                    for mini_batch, target in zip(X, target_output):
                        output = source_model(mini_batch)
                        eval_loss += criterion(output, target)
                eval_loss /= X.shape[0]
                loss_val = eval_loss.item()
                console.print(f"        [bold]Final loss: {loss_val:.6f}[/bold]")

                minimum[i] = min(minimum[i], loss_val)
                mean[i] += loss_val
                del source_model, optimizer

                if progress is not None:
                    progress.advance(global_task)

            mean[i] /= self.sub_iterations

            min_var = torch.var(minimum, unbiased=True)
            mean_var = torch.var(mean, unbiased=True)
            if max(min_var, mean_var) < self.variance_threashold:
                break

        return minimum.mean().item(), mean.mean().item()

    # ------------------------------------------------------------------ #
    #  Saving results                                                     #
    # ------------------------------------------------------------------ #

    def _save_data(self, save_path: str) -> None:
        data = {
            "A_space": self.A_space.name,
            "B_space": self.B_space.name,
            "mesurement_mode": self.A_space.automatic_mesurement_mode
            or self.B_space.automatic_mesurement_mode,
            "mesurements_A": self.A_space.mesurement,
            "mesurements_B": self.B_space.mesurement,
            "min_A_fit": self.min_A_fit,
            "mean_A_fit": self.mean_A_fit,
            "min_B_fit": self.min_B_fit,
            "mean_B_fit": self.mean_B_fit,
            "time_A": self.time_A,
            "time_B": self.time_B,
            "max_iterations": self.max_iterations,
            "sub_iterations": self.sub_iterations,
        }
        with open(os.path.join(save_path, "results.json"), "w") as f:
            json.dump(data, f, indent=2)

    def _save_plots(self, save_path: str) -> None:
        for mode in ["min", "mean"]:
            if mode == "min":
                values_A = self.min_A_fit
                values_B = self.min_B_fit
            else:
                values_A = self.mean_A_fit
                values_B = self.mean_B_fit

            if any(v is None for v in values_A + values_B):
                continue

            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

            ax1.plot(
                self.A_space.mesurement,
                values_A,
                label=f"{self.A_space.name} ({mode})",
                marker="o",
            )
            ax1.plot(
                self.B_space.mesurement,
                values_B,
                label=f"{self.B_space.name} ({mode})",
                marker="o",
            )
            ax1.set_xlabel("Number of Parameters")
            ax1.set_ylabel(f"{mode.capitalize()} Loss")
            ax1.set_title(f"{mode.capitalize()} Loss vs Parameters")
            ax1.legend()
            ax1.grid(True)

            ax2.plot(
                self.time_A,
                values_A,
                label=f"{self.A_space.name} ({mode})",
                marker="o",
            )
            ax2.plot(
                self.time_B,
                values_B,
                label=f"{self.B_space.name} ({mode})",
                marker="o",
            )
            ax2.set_xlabel("Time (s)")
            ax2.set_ylabel(f"{mode.capitalize()} Loss")
            ax2.set_title(f"{mode.capitalize()} Loss vs Time")
            ax2.legend()
            ax2.grid(True)

            plt.tight_layout()
            fig.savefig(os.path.join(save_path, f"{mode}_comparison.png"), dpi=150)
            plt.close(fig)

    # ------------------------------------------------------------------ #
    #  Plotting                                                           #
    # ------------------------------------------------------------------ #

    def plot(self, mode: str) -> None:
        if mode not in ["min", "mean"]:
            raise ValueError("Mode must be 'min' or 'mean'")

        if mode == "min":
            values_A = self.min_A_fit
            values_B = self.min_B_fit
        elif mode == "mean":
            values_A = self.mean_A_fit
            values_B = self.mean_B_fit

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

        # Plot 1: Performance vs number of parameters
        ax1.plot(
            self.A_space.mesurement,
            values_A,
            label=f"{self.A_space.name} ({mode})",
            marker="o",
        )
        ax1.plot(
            self.B_space.mesurement,
            values_B,
            label=f"{self.B_space.name} ({mode})",
            marker="o",
        )
        ax1.set_xlabel("Number of Parameters")
        ax1.set_ylabel(f"{mode.capitalize()} Loss")
        ax1.set_title(f"{mode.capitalize()} Loss vs Parameters")
        ax1.legend()
        ax1.grid(True)

        # Plot 2: Performance vs time
        ax2.plot(
            self.time_A,
            values_A,
            label=f"{self.A_space.name} ({mode})",
            marker="o",
        )
        ax2.plot(
            self.time_B,
            values_B,
            label=f"{self.B_space.name} ({mode})",
            marker="o",
        )
        ax2.set_xlabel("Time (s)")
        ax2.set_ylabel(f"{mode.capitalize()} Loss")
        ax2.set_title(f"{mode.capitalize()} Loss vs Time")
        ax2.legend()
        ax2.grid(True)

        plt.tight_layout()
        plt.show()

    def get_densities(self):
        """
        Compute and return the density of the comparison.

        Returns:
        - To be implemented if mathematically cool.
        """
        pass
