"""Allow running connectors as: python -m muleline.connectors.gmail"""
