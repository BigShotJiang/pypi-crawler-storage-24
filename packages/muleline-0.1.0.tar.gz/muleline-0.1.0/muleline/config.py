import os
from pathlib import Path

DATA_DIR = Path(os.environ.get("MULELINE_DATA_DIR", "./data"))
DB_PATH = DATA_DIR / "muleline.db"
UPLOAD_DIR = DATA_DIR / "uploads"
CHUNK_DIR = DATA_DIR / "chunks"
THUMB_DIR = DATA_DIR / "thumbnails"
FACE_CROP_DIR = DATA_DIR / "faces"

CHUNK_SIZE = int(os.environ.get("MULELINE_CHUNK_SIZE", 5 * 1024 * 1024))  # 5MB
MAX_UPLOAD_SIZE = int(os.environ.get("MULELINE_MAX_UPLOAD_SIZE", 500 * 1024 * 1024))  # 500MB
PENDING_UPLOAD_TTL = int(os.environ.get("MULELINE_UPLOAD_TTL", 86400))  # 24h
MAX_PENDING_UPLOADS = int(os.environ.get("MULELINE_MAX_PENDING", 20))

JWT_SECRET = os.environ.get("MULELINE_JWT_SECRET", "")
FACE_MATCH_THRESHOLD = float(os.environ.get("MULELINE_FACE_THRESHOLD", 0.55))

STRIPE_SECRET_KEY = os.environ.get("STRIPE_SECRET_KEY", "")
STRIPE_PUBLISHABLE_KEY = os.environ.get("STRIPE_PUBLISHABLE_KEY", "")
STRIPE_WEBHOOK_SECRET = os.environ.get("STRIPE_WEBHOOK_SECRET", "")
STRIPE_PRICE_CLOUD = os.environ.get("STRIPE_PRICE_CLOUD", "")
STRIPE_PRICE_PRO = os.environ.get("STRIPE_PRICE_PRO", "")
