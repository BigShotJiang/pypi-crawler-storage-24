from __future__ import annotations

from abc import ABC, abstractmethod


class StorageBackend(ABC):
    """Abstract base for storage backends. Implement to add NAS, S3, WebDAV, etc."""

    @abstractmethod
    def save(self, key: str, content: bytes, mime_type: str = "") -> bool:
        """Store content under the given key. Returns True on success."""
        ...

    @abstractmethod
    def read(self, key: str) -> bytes | None:
        """Read content by key. Returns None if not found."""
        ...

    @abstractmethod
    def delete(self, key: str) -> bool:
        """Delete content by key. Returns True if deleted."""
        ...

    @abstractmethod
    def exists(self, key: str) -> bool:
        """Check if key exists in storage."""
        ...

    @abstractmethod
    def url(self, key: str, expires: int = 3600) -> str | None:
        """Get a URL to access the file. Returns None if not supported."""
        ...
