from muleline.storage.base import StorageBackend
from muleline.storage.local import LocalStorage
from muleline.storage.s3 import S3Storage

__all__ = ["StorageBackend", "LocalStorage", "S3Storage"]

try:
    from muleline.storage.webdav import WebDAVStorage

    __all__ = [*__all__, "WebDAVStorage"]
except ImportError:
    pass

try:
    from muleline.storage.sftp import SFTPStorage

    __all__ = [*__all__, "SFTPStorage"]
except ImportError:
    pass

try:
    from muleline.storage.dropbox import DropboxStorage

    __all__ = [*__all__, "DropboxStorage"]
except ImportError:
    pass

try:
    from muleline.storage.gdrive import GoogleDriveStorage

    __all__ = [*__all__, "GoogleDriveStorage"]
except ImportError:
    pass
