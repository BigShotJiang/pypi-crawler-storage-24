#!/usr/bin/env bash
set -euo pipefail

VPS="root@65.108.52.69"
SPLASH_DIR="/Users/mediaserver/muleline/splash"
REMOTE_SERVE="/opt/muleline-splash"
CADDY_FILE="/opt/caddy/Caddyfile"
SNIPPET="$(dirname "$0")/Caddyfile.muleline"

echo "==> Uploading splash page..."
ssh "$VPS" "mkdir -p $REMOTE_SERVE"
scp -r "$SPLASH_DIR"/. "$VPS:$REMOTE_SERVE/"

echo "==> Checking if muleline.win block already in Caddyfile..."
if ssh "$VPS" "grep -q 'muleline.win' $CADDY_FILE"; then
    echo "    Block already present — skipping Caddyfile update."
else
    echo "==> Appending muleline.win block to Caddyfile..."
    ssh "$VPS" "cat >> $CADDY_FILE" < "$SNIPPET"
fi

echo "==> Reloading Caddy..."
ssh "$VPS" "docker exec caddy caddy reload --config /etc/caddy/Caddyfile --adapter caddyfile"

echo "==> Done. https://muleline.win should be live within seconds."
