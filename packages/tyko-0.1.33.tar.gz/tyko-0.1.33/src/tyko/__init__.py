from pkgutil import extend_path

__path__ = extend_path(__path__, __name__)

__version__ = "0.1.33"

from ._client import AuthenticationError, TykoClient, TykoError
from ._environment import capture_environment
from ._protocols import DataFrameLike, SeriesLike
from ._types import Environment, Experiment, Project, Run, RunParams, RunStatus

__all__ = [
    "TykoClient",
    "TykoCallback",
    "TykoError",
    "AuthenticationError",
    "Project",
    "Experiment",
    "Run",
    "RunParams",
    "RunStatus",
    "Environment",
    "DataFrameLike",
    "SeriesLike",
    "capture_environment",
    "__version__",
]


def __getattr__(name: str) -> object:
    if name == "TykoCallback":
        from .integrations import TykoCallback

        return TykoCallback
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
