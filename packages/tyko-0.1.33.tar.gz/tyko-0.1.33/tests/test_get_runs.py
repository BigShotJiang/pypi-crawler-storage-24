"""Tests for client.get_runs() — querying runs programmatically."""

from unittest.mock import MagicMock, patch

import pytest

from tyko._client import TykoClient


@pytest.fixture
def client() -> TykoClient:
    """Create a TykoClient with mocked HTTP and no sidecar."""
    with patch.dict("os.environ", {"TYKO_DISABLE_SIDECAR": "1"}, clear=False):
        c = TykoClient(api_url="http://localhost:8080", api_key="test-key")
    return c


class TestGetRuns:
    def test_returns_list_of_run_summaries(self, client: TykoClient) -> None:
        mock_response = MagicMock()
        mock_response.is_success = True
        mock_response.json.return_value = [
            {
                "id": "run-1",
                "name": "brave-eagle",
                "sequential": 1,
                "displayName": "brave-eagle-1",
                "projectId": "proj-1",
                "experimentName": "default",
                "state": "completed",
                "createdAt": "2026-03-22T10:00:00Z",
                "params": {"lr": 0.001},
                "environment": None,
                "metricNames": ["loss", "accuracy"],
            },
        ]

        with patch("httpx.get", return_value=mock_response) as mock_get:
            runs = client.get_runs(project="my-project")

        assert len(runs) == 1
        assert runs[0]["name"] == "brave-eagle"
        assert runs[0]["state"] == "completed"
        mock_get.assert_called_once()
        call_url = mock_get.call_args[0][0]
        assert "project=my-project" in call_url

    def test_filters_by_experiment(self, client: TykoClient) -> None:
        mock_response = MagicMock()
        mock_response.is_success = True
        mock_response.json.return_value = []

        with patch("httpx.get", return_value=mock_response) as mock_get:
            client.get_runs(project="proj", experiment="exp-1")

        call_url = mock_get.call_args[0][0]
        assert "experiment=exp-1" in call_url

    def test_filters_by_status(self, client: TykoClient) -> None:
        mock_response = MagicMock()
        mock_response.is_success = True
        mock_response.json.return_value = []

        with patch("httpx.get", return_value=mock_response) as mock_get:
            client.get_runs(project="proj", status="running")

        call_url = mock_get.call_args[0][0]
        assert "status=running" in call_url

    def test_limits_results(self, client: TykoClient) -> None:
        mock_response = MagicMock()
        mock_response.is_success = True
        mock_response.json.return_value = []

        with patch("httpx.get", return_value=mock_response) as mock_get:
            client.get_runs(project="proj", limit=10)

        call_url = mock_get.call_args[0][0]
        assert "limit=10" in call_url

    def test_project_required(self, client: TykoClient) -> None:
        with pytest.raises(TypeError):
            client.get_runs()  # type: ignore[call-arg]

    def test_returns_empty_list(self, client: TykoClient) -> None:
        mock_response = MagicMock()
        mock_response.is_success = True
        mock_response.json.return_value = []

        with patch("httpx.get", return_value=mock_response):
            runs = client.get_runs(project="empty-project")

        assert runs == []
