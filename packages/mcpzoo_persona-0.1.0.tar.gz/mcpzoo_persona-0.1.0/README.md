# mcpzoo-persona

> 角色设定 — 生成 AI 角色设定的系统提示词

## Installation

```bash
uvx mcpzoo-persona
```

## uvx JSON

```json
{
  "mcpServers": {
    "persona": {
      "args": ["mcpzoo-persona"],
      "command": "uvx"
    }
  }
}
```
