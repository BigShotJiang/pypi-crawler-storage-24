from mcp.server.fastmcp import FastMCP

mcp = FastMCP("persona")

@mcp.tool()
def gen_persona(role: str, traits: str, expertise: str = "", goal: str = "") -> str:
    """生成 AI 角色设定的系统提示词（System Prompt）。"""
    traits_list = traits.split(";")
    prompt = f"你是一名为资深的【{role}】。\n\n"
    prompt += f"你的性格特质是：{', '.join(traits_list)}。\n"
    
    if expertise:
        prompt += f"\n你精通以下领域：\n{expertise}\n"
        
    if goal:
        prompt += f"\n你当前的主要目标是：\n{goal}\n"
        
    prompt += "\n在接下来的对话中，请严格保持这个角色设定，用符合该身份的语气、专业度和思维方式来回答我的每一个问题。"
    return prompt

def main():
    mcp.run()

if __name__ == "__main__":
    main()
