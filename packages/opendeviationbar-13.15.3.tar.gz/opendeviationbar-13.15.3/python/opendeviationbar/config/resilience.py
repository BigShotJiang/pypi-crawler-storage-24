"""Resilience configuration: retries, backoff, circuit breakers.

Centralizes all retry counts, backoff durations, and circuit breaker
parameters into a single pydantic-settings model.

All values load from environment variables (OPENDEVIATIONBAR_RESILIENCE_ prefix).
"""

from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class ResilienceConfig(BaseSettings):
    """Retry, backoff, and circuit breaker configuration.

    Environment Variables
    ---------------------
    OPENDEVIATIONBAR_RESILIENCE_DEFAULT_MAX_RETRIES : int
        Default retry count for API calls (backfill aggtrades) (default: 3)
    OPENDEVIATIONBAR_RESILIENCE_DEFAULT_BACKOFF_S : float
        Default initial exponential backoff (default: 2.0)
    OPENDEVIATIONBAR_RESILIENCE_CB_FAILURE_THRESHOLD : int
        Cache write circuit breaker: failures before OPEN (default: 3)
    OPENDEVIATIONBAR_RESILIENCE_CB_RECOVERY_TIMEOUT_S : int
        Circuit breaker: seconds in OPEN before HALF_OPEN probe (default: 60)
    OPENDEVIATIONBAR_RESILIENCE_SEED_MAX_ATTEMPTS : int
        Sidecar trade-ID seeding from ClickHouse (default: 3)
    OPENDEVIATIONBAR_RESILIENCE_SEED_RETRY_DELAY_S : int
        Delay between seeding attempts (default: 5)
    OPENDEVIATIONBAR_RESILIENCE_FLUSH_MAX_RETRIES : int
        ClickHouse bar flush retries via stamina (default: 3)
    OPENDEVIATIONBAR_RESILIENCE_LOG_COOLDOWN_S : int
        Duplicate log message suppression window (default: 30)
    """

    model_config = SettingsConfigDict(
        env_prefix="OPENDEVIATIONBAR_RESILIENCE_",
        case_sensitive=False,
    )

    # Default retry count for REST API calls (backfill aggtrades)
    default_max_retries: int = 3

    # Default initial exponential backoff (seconds)
    default_backoff_s: float = 2.0

    # Cache write circuit breaker: consecutive failures before OPEN state
    cb_failure_threshold: int = 3

    # Circuit breaker: seconds in OPEN state before HALF_OPEN recovery probe
    cb_recovery_timeout_s: int = 60

    # Sidecar trade-ID seeding from ClickHouse: max attempts
    seed_max_attempts: int = 3

    # Sidecar trade-ID seeding: delay between attempts (seconds)
    seed_retry_delay_s: int = 5

    # ClickHouse bar flush: max retries via stamina decorator
    flush_max_retries: int = 3

    # Duplicate log message suppression window (seconds)
    log_cooldown_s: int = 30
