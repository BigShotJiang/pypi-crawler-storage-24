"""Network I/O timeout configuration.

Centralizes all hardcoded timeout values scattered across the codebase into a
single pydantic-settings model. Every HTTP request, socket probe, and process
wait uses a named timeout from this module.

All values load from environment variables (OPENDEVIATIONBAR_NET_ prefix).
"""

from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class NetworkConfig(BaseSettings):
    """Network I/O timeouts.

    Environment Variables
    ---------------------
    OPENDEVIATIONBAR_NET_HTTP_PROBE_TIMEOUT_S : int
        General HTTP health probes (symbol registry, health checks, threshold) (default: 5)
    OPENDEVIATIONBAR_NET_CLICKHOUSE_PROBE_TIMEOUT_S : float
        ClickHouse preflight /ping and port checks (default: 2.0)
    OPENDEVIATIONBAR_NET_CLICKHOUSE_SSH_TIMEOUT_S : int
        SSH tunnel establishment for ClickHouse (default: 8)
    OPENDEVIATIONBAR_NET_CLICKHOUSE_MUTATION_TIMEOUT_S : int
        Wait for ClickHouse mutations to drain (default: 120)
    OPENDEVIATIONBAR_NET_NOTIFICATION_TIMEOUT_S : int
        Telegram and Pushover notification sends (default: 10)
    OPENDEVIATIONBAR_NET_VISION_PROBE_TIMEOUT_S : int
        Binance Vision ZIP availability probe (default: 10)
    OPENDEVIATIONBAR_NET_VISION_MAX_LOOKBACK : int
        Max days to search backward for Vision data (default: 10)
    OPENDEVIATIONBAR_NET_PORT_CHECK_TIMEOUT_S : float
        TCP port availability check (default: 2.0)
    OPENDEVIATIONBAR_NET_REDIS_SOCKET_TIMEOUT_S : int
        Redis connect and socket timeout (default: 5)
    OPENDEVIATIONBAR_NET_HTTP_SERVER_SHUTDOWN_TIMEOUT_S : int
        Sidecar HTTP server graceful shutdown (default: 30)
    OPENDEVIATIONBAR_NET_TUNNEL_WAIT_TIMEOUT_S : int
        SSH tunnel process termination wait (default: 5)
    """

    model_config = SettingsConfigDict(
        env_prefix="OPENDEVIATIONBAR_NET_",
        case_sensitive=False,
    )

    # HTTP probes (symbol registry, health checks, threshold validation)
    http_probe_timeout_s: int = 5

    # ClickHouse preflight (/ping, port checks)
    clickhouse_probe_timeout_s: float = 2.0

    # SSH tunnel establishment
    clickhouse_ssh_timeout_s: int = 8

    # ClickHouse mutation drain wait
    clickhouse_mutation_timeout_s: int = 120

    # Telegram / Pushover notification sends
    notification_timeout_s: int = 10

    # Binance Vision ZIP availability probe
    vision_probe_timeout_s: int = 10

    # Max days to search backward for Vision data
    vision_max_lookback: int = 10

    # TCP port availability check
    port_check_timeout_s: float = 2.0

    # Redis connect and socket timeout
    redis_socket_timeout_s: int = 5

    # Sidecar HTTP server graceful shutdown
    http_server_shutdown_timeout_s: int = 30

    # SSH tunnel process termination wait
    tunnel_wait_timeout_s: int = 5
