"""
This module defines the core `Device` class, which represents a physical coffee
machine. It serves as the primary high-level interface for interacting with a
device, abstracting away the underlying transport and command details.
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from base64 import b64encode
from typing import Any, Dict, Optional

from cremalink.parsing.monitor.frame import MonitorFrame
from cremalink.parsing.monitor.model import MonitorSnapshot
from cremalink.parsing.monitor.profile import MonitorProfile
from cremalink.parsing.monitor.view import MonitorView
from cremalink.parsing.properties.settings import (
    build_profile_switch_cmd,
    decode_active_profile,
    decode_custom_recipe_names,
    decode_profile_names,
    decode_serial_number,
    decode_temperature,
    encode_temperature,
)
from cremalink.transports.base import DeviceTransport
from cremalink.devices import device_map
from cremalink.core.binary import hex_to_signed_decimal, signed_decimal_to_hex

logger = logging.getLogger(__name__)

APP_ID_HEX = "C0FFEEEE"


def _load_device_map(device_map_path: Optional[str]) -> Dict[str, Any]:
    """Loads a JSON device map from the given file path."""
    if not device_map_path:
        return {}
    with open(device_map_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data if isinstance(data, dict) else {}


def _encode_command(hex_command: str, app_id: Optional[str] = None) -> str:
    """
    Encodes a hexadecimal command string into the base64 format expected by the device.
    It prepends the command bytes with a current timestamp.
    """
    head = bytearray.fromhex(hex_command)
    timestamp = bytearray.fromhex(hex(int(time.time()))[2:])
    app_id_bytes = bytearray.fromhex(app_id) if app_id else b""
    return b64encode(head + timestamp + app_id_bytes).decode("utf-8")


@dataclass
class Device:
    """
    Represents a coffee machine, providing methods to control and monitor it.

    This class holds the device's state (e.g., IP, model) and uses a `DeviceTransport`
    object to handle the actual communication. Device-specific capabilities are
    loaded from a "device map" file.

    Attributes:
        transport: The transport object responsible for communication.
        dsn: Device Serial Number.
        model: The model identifier of the device.
        nickname: A user-defined name for the device.
        ip: The local IP address of the device.
        lan_key: The key used for LAN-based authentication.
        scheme: The communication scheme (e.g., 'http', 'mqtt').
        is_online: Boolean indicating if the device is currently reachable.
        last_seen: Timestamp of the last communication.
        firmware: The device's firmware version.
        serial: The device's serial number.
        coffee_count: The total number of coffees made.
        command_map: A mapping of command aliases to their hex codes.
        property_map: A mapping of property aliases to their technical names.
        monitor_profile: Configuration for parsing monitor data.
        extra: A dictionary for any other miscellaneous data.
    """

    transport: DeviceTransport
    dsn: Optional[str] = None
    model: Optional[str] = None
    nickname: Optional[str] = None
    ip: Optional[str] = None
    lan_key: Optional[str] = None
    scheme: Optional[str] = None
    is_online: Optional[bool] = None
    last_seen: Optional[str] = None
    firmware: Optional[str] = None
    serial: Optional[str] = None
    coffee_count: Optional[int] = None
    command_map: Dict[str, Any] = field(default_factory=dict)
    property_map: Dict[str, Any] = field(default_factory=dict)
    monitor_profile: MonitorProfile = field(default_factory=MonitorProfile)
    extra: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_map(
        cls,
        transport: DeviceTransport,
        device_map_path: Optional[str] = None,
        **kwargs,
    ) -> "Device":
        """
        Factory method to create a Device instance with a loaded device map.

        If `device_map_path` is not provided, it attempts to find one using the
        device's model.

        Args:
            transport: The communication transport to use.
            device_map_path: Optional path to the device map JSON file.
            **kwargs: Additional attributes to set on the Device instance.

        Returns:
            A configured Device instance.
        """
        if not device_map_path:
            device_map_path = device_map(cls.model) if cls.model else None

        map_data = _load_device_map(device_map_path)

        support = map_data.get("support", {})
        transport_name = transport.__class__.__name__

        if transport_name == "CloudTransport" and support.get("cloud") is False:
            logger.warning(
                "The device map indicates that CloudTransport is not supported for this device."
            )
        elif transport_name == "LocalTransport" and support.get("local") is False:
            logger.warning(
                "The device map indicates that LocalTransport is not supported for this device."
            )

        command_map = (
            map_data.get("command_map", {}) if isinstance(map_data, dict) else {}
        )
        property_map = (
            map_data.get("property_map", {}) if isinstance(map_data, dict) else {}
        )
        monitor_profile_data = (
            map_data.get("monitor_profile", {}) if isinstance(map_data, dict) else {}
        )
        monitor_profile = MonitorProfile.from_dict(monitor_profile_data)

        # If the transport supports it, pass the mappings to it.
        if hasattr(transport, "set_mappings"):
            try:
                transport.set_mappings(command_map, property_map)
            except Exception:
                pass  # Ignore if setting mappings fails

        return cls(
            transport=transport,
            command_map=command_map,
            property_map=property_map,
            monitor_profile=monitor_profile,
            **kwargs,
        )

    # --- Transport delegations ---
    def configure(self) -> None:
        """Configures the underlying transport."""
        self.transport.configure()

    def send_command(self, command: str) -> Any:
        """
        Encodes and sends a raw hex command to the device via the transport.

        Args:
            command: The hex command string to send.

        Returns:
            The response from the transport.
        """
        if self.property_map.get("app_id", None):
            app_id_hex = self._ensure_app_id()
            if not app_id_hex:
                raise ConnectionError("Could not set app_id, so cannot send command.")
            encoded = _encode_command(command, app_id_hex)
        else:
            encoded = _encode_command(command)

        return self.transport.send_command(encoded)

    def refresh_monitor(self) -> Any:
        """Requests a refresh of the device's monitoring data."""
        return self.transport.refresh_monitor()

    def get_properties(self) -> Any:
        """Fetches all available properties from the device."""
        return self.transport.get_properties()

    def get_property_aliases(self) -> list[str]:
        """Returns a list of all available property aliases from the device map."""
        return list(self.property_map.keys())

    def get_property(self, name: str) -> Any:
        """
        Fetches a single property by its alias or technical name.

        Args:
            name: The alias or name of the property to fetch.

        Returns:
            The value of the requested property.
        """
        actual_name = self.resolve_property(name, default=name)
        return self.transport.get_property(actual_name)

    def set_property(self, name: str, value: Any) -> Any:
        """
        Writes a value to a property by its alias or technical name.

        Args:
            name: The alias or technical name of the property to write.
            value: The value to write (typically a base64-encoded string).

        Returns:
            The response from the transport.
        """
        actual_name = self.resolve_property(name, default=name)
        return self.transport.set_property(actual_name, value)

    def health(self) -> Any:
        """Checks the health of the device connection."""
        return self.transport.health()

    # --- Command map helpers ---
    def do(self, drink_name: str) -> Any:
        """
        Executes a command by its friendly name (e.g., 'espresso').

        Args:
            drink_name: The name of the command to execute, as defined in the command_map.

        Returns:
            The response from the transport.

        Raises:
            ValueError: If the command name is not found in the device map.
        """
        key = drink_name.lower().strip()
        hex_command = self.command_map.get(key, {}).get("command")
        if not hex_command:
            raise ValueError(f"Command '{key}' not implemented; check device_map.")
        return self.send_command(hex_command)

    def get_commands(self) -> list[str]:
        """Returns a list of all available command names from the device map."""
        return list(self.command_map.keys())

    # --- Property map helpers ---
    def resolve_property(self, alias: str, default: Optional[str] = None) -> str:
        """
        Translates a property alias to its technical name using the property_map.

        Args:
            alias: The property alias to resolve.
            default: A default value to return if the alias is not found.

        Returns:
            The resolved technical name, or the alias/default if not found.
        """
        return self.property_map.get(alias, default or alias)

    # --- Monitor helpers ---
    def get_monitor_snapshot(self) -> MonitorSnapshot:
        """
        Retrieves the latest raw monitoring data from the transport.
        """
        return self.transport.get_monitor()

    def get_monitor(self) -> MonitorView:
        """
        Retrieves and parses monitoring data into a structured, human-readable view.

        Returns:
            A `MonitorView` instance containing parsed status information.
        """
        snapshot = self.get_monitor_snapshot()
        return MonitorView(snapshot=snapshot, profile=self.monitor_profile)

    def get_monitor_frame(self) -> Optional[MonitorFrame]:
        """
        Decodes the raw monitor data into a `MonitorFrame` for low-level analysis.

        Returns:
            A `MonitorFrame` if decoding is successful, otherwise None.
        """
        snapshot = self.get_monitor_snapshot()
        if not snapshot.raw_b64:
            return None
        try:
            return MonitorFrame.from_b64(snapshot.raw_b64)
        except Exception:
            return None

    def _ensure_app_id(self) -> bool:
        """Check the app_id matches the cremalink app id and try to set it"""
        app_id = self.get_property(self.property_map.get("app_id", "app_id")) or {}
        value = app_id.get("value")
        if value == "0":
            self._register_app_id(APP_ID_HEX)
            # sleep for a bit to allow the app id to get set
            time.sleep(7)
            return APP_ID_HEX
        elif value == hex_to_signed_decimal(APP_ID_HEX):
            self._refresh_app_id()
            return APP_ID_HEX
        return signed_decimal_to_hex(value)

    def _register_app_id(self, app_id_hex: str) -> Any:
        """
        Sends a command to register the app id with the cloud.
        The register command is just the timestamp + app_id.
        """
        command = _encode_command("", app_id_hex)
        return self.transport.send_command(
            command, self.property_map.get("device_connected", "app_device_connected")
        )

    def _refresh_app_id(self) -> Any:
        """Sends a command to refresh the registered app id with the cloud."""
        hex_command = self.command_map.get("refresh", {}).get("command")
        command = _encode_command(hex_command, APP_ID_HEX)
        return self.transport.send_command(command)

    # --- High-level settings accessors ---

    def get_serial_number(self) -> Optional[str]:
        """Return the machine serial number decoded from the serial_number property.

        Requires ``serial_number`` to be present in the device map's property_map
        (alias for d270_serialnumber on supported devices).

        Returns None if the property is not mapped, not available, or cannot be decoded.
        """
        alias = self.property_map.get("serial_number")
        if not alias:
            return None
        raw = self.get_property(alias)
        value = raw.get("value") if isinstance(raw, dict) else raw
        return decode_serial_number(value)

    def get_profile_names(self) -> dict[int, str]:
        """Return a {1-based index: name} mapping of user profile names.

        Reads ``profile_names_1_3`` and ``profile_names_4`` from the property_map
        (aliases for d051/d052 on supported devices).

        Returns an empty dict if the properties are not mapped or unavailable.
        """

        def _fetch(alias_key: str) -> Optional[str]:
            alias = self.property_map.get(alias_key)
            if not alias:
                return None
            raw = self.get_property(alias)
            return raw.get("value") if isinstance(raw, dict) else raw

        return decode_profile_names(
            _fetch("profile_names_1_3"),
            _fetch("profile_names_4"),
        )

    def get_active_profile(self) -> Optional[int]:
        """Return the current active profile as a 1-based index (1–4).

        Reads ``machine_settings_profile`` from the property_map
        (alias for d286 on supported devices).

        Returns None if the property is not mapped or cannot be decoded.
        """
        alias = self.property_map.get("machine_settings_profile")
        if not alias:
            return None
        raw = self.get_property(alias)
        value = raw.get("value") if isinstance(raw, dict) else raw
        return decode_active_profile(value)

    def set_profile(self, profile_1based: int) -> Any:
        """Switch the active user profile.

        Builds a signed frame and writes it to the ``data_request`` property
        (alias for app_data_request on supported devices).

        Args:
            profile_1based: Target profile number (1–4).

        Raises:
            ValueError: If ``data_request`` is not in the property_map.
            RuntimeError: If the crcmod package is not installed.
        """
        import base64

        alias = self.property_map.get("data_request")
        if not alias:
            raise ValueError(
                "data_request is not mapped for this device; cannot switch profiles."
            )
        cmd_bytes = build_profile_switch_cmd(profile_1based)
        b64_cmd = base64.b64encode(cmd_bytes).decode()
        return self.transport.set_property(alias, b64_cmd)

    def get_custom_recipe_names(self) -> dict[int, str]:
        """Return a {1-based slot index: name} mapping of custom recipe names.

        Reads ``custom_names_1_3`` and ``custom_names_4_6`` from the property_map
        (aliases for d053/d054 on supported devices).

        Returns an empty dict if the properties are not mapped or unavailable.
        """

        def _fetch(alias_key: str) -> Optional[str]:
            alias = self.property_map.get(alias_key)
            if not alias:
                return None
            raw = self.get_property(alias)
            return raw.get("value") if isinstance(raw, dict) else raw

        return decode_custom_recipe_names(
            _fetch("custom_names_1_3"),
            _fetch("custom_names_4_6"),
        )

    def get_temperature(self) -> Optional[str]:
        """Return the current brew temperature as a level string.

        Returns one of ``"low"``, ``"medium"``, ``"high"``, or None.

        Reads ``machine_settings_temperature`` from the property_map
        (alias for d281 on supported devices).
        """
        alias = self.property_map.get("machine_settings_temperature")
        if not alias:
            return None
        raw = self.get_property(alias)
        value = raw.get("value") if isinstance(raw, dict) else raw
        return decode_temperature(value)

    def set_temperature(self, level: str) -> Any:
        """Set the brew temperature.

        Args:
            level: One of ``"low"``, ``"medium"``, ``"high"``.

        Raises:
            ValueError: If *level* is not recognised, or the property is not mapped.
            RuntimeError: If the crcmod package is not installed.
        """
        alias = self.property_map.get("machine_settings_temperature")
        if not alias:
            raise ValueError(
                "machine_settings_temperature is not mapped for this device."
            )
        raw = self.get_property(alias)
        current_b64 = raw.get("value") if isinstance(raw, dict) else raw
        if not current_b64:
            raise ValueError(
                "Could not read current temperature blob; cannot encode update."
            )
        new_b64 = encode_temperature(current_b64, level)
        return self.transport.set_property(alias, new_b64)
