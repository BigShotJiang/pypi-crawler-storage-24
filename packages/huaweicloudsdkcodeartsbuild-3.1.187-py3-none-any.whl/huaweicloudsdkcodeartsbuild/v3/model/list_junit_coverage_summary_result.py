# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListJunitCoverageSummaryResult:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'unit_summary_list': 'list[ListJunitCoverageSummaryResultUnitSummaryList]'
    }

    attribute_map = {
        'unit_summary_list': 'unit_summary_list'
    }

    def __init__(self, unit_summary_list=None):
        r"""ListJunitCoverageSummaryResult

        The model defined in huaweicloud sdk

        :param unit_summary_list: 单元测试覆盖率报告列表
        :type unit_summary_list: list[:class:`huaweicloudsdkcodeartsbuild.v3.ListJunitCoverageSummaryResultUnitSummaryList`]
        """
        
        

        self._unit_summary_list = None
        self.discriminator = None

        if unit_summary_list is not None:
            self.unit_summary_list = unit_summary_list

    @property
    def unit_summary_list(self):
        r"""Gets the unit_summary_list of this ListJunitCoverageSummaryResult.

        单元测试覆盖率报告列表

        :return: The unit_summary_list of this ListJunitCoverageSummaryResult.
        :rtype: list[:class:`huaweicloudsdkcodeartsbuild.v3.ListJunitCoverageSummaryResultUnitSummaryList`]
        """
        return self._unit_summary_list

    @unit_summary_list.setter
    def unit_summary_list(self, unit_summary_list):
        r"""Sets the unit_summary_list of this ListJunitCoverageSummaryResult.

        单元测试覆盖率报告列表

        :param unit_summary_list: The unit_summary_list of this ListJunitCoverageSummaryResult.
        :type unit_summary_list: list[:class:`huaweicloudsdkcodeartsbuild.v3.ListJunitCoverageSummaryResultUnitSummaryList`]
        """
        self._unit_summary_list = unit_summary_list

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListJunitCoverageSummaryResult):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
