# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class UpdateBuildJobScm:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'branch': 'str',
        'url': 'str',
        'repo_id': 'str',
        'web_url': 'str',
        'scm_type': 'str',
        'is_auto_build': 'bool',
        'build_type': 'str',
        'depth': 'str',
        'end_point_id': 'str',
        'source': 'str'
    }

    attribute_map = {
        'branch': 'branch',
        'url': 'url',
        'repo_id': 'repo_id',
        'web_url': 'web_url',
        'scm_type': 'scm_type',
        'is_auto_build': 'is_auto_build',
        'build_type': 'build_type',
        'depth': 'depth',
        'end_point_id': 'end_point_id',
        'source': 'source'
    }

    def __init__(self, branch=None, url=None, repo_id=None, web_url=None, scm_type=None, is_auto_build=None, build_type=None, depth=None, end_point_id=None, source=None):
        r"""UpdateBuildJobScm

        The model defined in huaweicloud sdk

        :param branch: 代码分支
        :type branch: str
        :param url: 代码仓地址
        :type url: str
        :param repo_id: repo的id
        :type repo_id: str
        :param web_url: 代码仓http地址
        :type web_url: str
        :param scm_type: 仓库类别，Repo、Github等
        :type scm_type: str
        :param is_auto_build: 是否自动构建
        :type is_auto_build: bool
        :param build_type: 构建类别
        :type build_type: str
        :param depth: 克隆深度
        :type depth: str
        :param end_point_id: endpointId
        :type end_point_id: str
        :param source: source
        :type source: str
        """
        
        

        self._branch = None
        self._url = None
        self._repo_id = None
        self._web_url = None
        self._scm_type = None
        self._is_auto_build = None
        self._build_type = None
        self._depth = None
        self._end_point_id = None
        self._source = None
        self.discriminator = None

        if branch is not None:
            self.branch = branch
        self.url = url
        if repo_id is not None:
            self.repo_id = repo_id
        if web_url is not None:
            self.web_url = web_url
        self.scm_type = scm_type
        if is_auto_build is not None:
            self.is_auto_build = is_auto_build
        if build_type is not None:
            self.build_type = build_type
        if depth is not None:
            self.depth = depth
        if end_point_id is not None:
            self.end_point_id = end_point_id
        if source is not None:
            self.source = source

    @property
    def branch(self):
        r"""Gets the branch of this UpdateBuildJobScm.

        代码分支

        :return: The branch of this UpdateBuildJobScm.
        :rtype: str
        """
        return self._branch

    @branch.setter
    def branch(self, branch):
        r"""Sets the branch of this UpdateBuildJobScm.

        代码分支

        :param branch: The branch of this UpdateBuildJobScm.
        :type branch: str
        """
        self._branch = branch

    @property
    def url(self):
        r"""Gets the url of this UpdateBuildJobScm.

        代码仓地址

        :return: The url of this UpdateBuildJobScm.
        :rtype: str
        """
        return self._url

    @url.setter
    def url(self, url):
        r"""Sets the url of this UpdateBuildJobScm.

        代码仓地址

        :param url: The url of this UpdateBuildJobScm.
        :type url: str
        """
        self._url = url

    @property
    def repo_id(self):
        r"""Gets the repo_id of this UpdateBuildJobScm.

        repo的id

        :return: The repo_id of this UpdateBuildJobScm.
        :rtype: str
        """
        return self._repo_id

    @repo_id.setter
    def repo_id(self, repo_id):
        r"""Sets the repo_id of this UpdateBuildJobScm.

        repo的id

        :param repo_id: The repo_id of this UpdateBuildJobScm.
        :type repo_id: str
        """
        self._repo_id = repo_id

    @property
    def web_url(self):
        r"""Gets the web_url of this UpdateBuildJobScm.

        代码仓http地址

        :return: The web_url of this UpdateBuildJobScm.
        :rtype: str
        """
        return self._web_url

    @web_url.setter
    def web_url(self, web_url):
        r"""Sets the web_url of this UpdateBuildJobScm.

        代码仓http地址

        :param web_url: The web_url of this UpdateBuildJobScm.
        :type web_url: str
        """
        self._web_url = web_url

    @property
    def scm_type(self):
        r"""Gets the scm_type of this UpdateBuildJobScm.

        仓库类别，Repo、Github等

        :return: The scm_type of this UpdateBuildJobScm.
        :rtype: str
        """
        return self._scm_type

    @scm_type.setter
    def scm_type(self, scm_type):
        r"""Sets the scm_type of this UpdateBuildJobScm.

        仓库类别，Repo、Github等

        :param scm_type: The scm_type of this UpdateBuildJobScm.
        :type scm_type: str
        """
        self._scm_type = scm_type

    @property
    def is_auto_build(self):
        r"""Gets the is_auto_build of this UpdateBuildJobScm.

        是否自动构建

        :return: The is_auto_build of this UpdateBuildJobScm.
        :rtype: bool
        """
        return self._is_auto_build

    @is_auto_build.setter
    def is_auto_build(self, is_auto_build):
        r"""Sets the is_auto_build of this UpdateBuildJobScm.

        是否自动构建

        :param is_auto_build: The is_auto_build of this UpdateBuildJobScm.
        :type is_auto_build: bool
        """
        self._is_auto_build = is_auto_build

    @property
    def build_type(self):
        r"""Gets the build_type of this UpdateBuildJobScm.

        构建类别

        :return: The build_type of this UpdateBuildJobScm.
        :rtype: str
        """
        return self._build_type

    @build_type.setter
    def build_type(self, build_type):
        r"""Sets the build_type of this UpdateBuildJobScm.

        构建类别

        :param build_type: The build_type of this UpdateBuildJobScm.
        :type build_type: str
        """
        self._build_type = build_type

    @property
    def depth(self):
        r"""Gets the depth of this UpdateBuildJobScm.

        克隆深度

        :return: The depth of this UpdateBuildJobScm.
        :rtype: str
        """
        return self._depth

    @depth.setter
    def depth(self, depth):
        r"""Sets the depth of this UpdateBuildJobScm.

        克隆深度

        :param depth: The depth of this UpdateBuildJobScm.
        :type depth: str
        """
        self._depth = depth

    @property
    def end_point_id(self):
        r"""Gets the end_point_id of this UpdateBuildJobScm.

        endpointId

        :return: The end_point_id of this UpdateBuildJobScm.
        :rtype: str
        """
        return self._end_point_id

    @end_point_id.setter
    def end_point_id(self, end_point_id):
        r"""Sets the end_point_id of this UpdateBuildJobScm.

        endpointId

        :param end_point_id: The end_point_id of this UpdateBuildJobScm.
        :type end_point_id: str
        """
        self._end_point_id = end_point_id

    @property
    def source(self):
        r"""Gets the source of this UpdateBuildJobScm.

        source

        :return: The source of this UpdateBuildJobScm.
        :rtype: str
        """
        return self._source

    @source.setter
    def source(self, source):
        r"""Sets the source of this UpdateBuildJobScm.

        source

        :param source: The source of this UpdateBuildJobScm.
        :type source: str
        """
        self._source = source

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, UpdateBuildJobScm):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
