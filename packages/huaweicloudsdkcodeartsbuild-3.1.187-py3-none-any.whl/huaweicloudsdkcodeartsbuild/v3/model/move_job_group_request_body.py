# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class MoveJobGroupRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'group_id': 'str',
        'jobs': 'list[MoveJobGroupRequestBodyJobs]'
    }

    attribute_map = {
        'group_id': 'group_id',
        'jobs': 'jobs'
    }

    def __init__(self, group_id=None, jobs=None):
        r"""MoveJobGroupRequestBody

        The model defined in huaweicloud sdk

        :param group_id: 任务分组id
        :type group_id: str
        :param jobs: 任务组
        :type jobs: list[:class:`huaweicloudsdkcodeartsbuild.v3.MoveJobGroupRequestBodyJobs`]
        """
        
        

        self._group_id = None
        self._jobs = None
        self.discriminator = None

        if group_id is not None:
            self.group_id = group_id
        if jobs is not None:
            self.jobs = jobs

    @property
    def group_id(self):
        r"""Gets the group_id of this MoveJobGroupRequestBody.

        任务分组id

        :return: The group_id of this MoveJobGroupRequestBody.
        :rtype: str
        """
        return self._group_id

    @group_id.setter
    def group_id(self, group_id):
        r"""Sets the group_id of this MoveJobGroupRequestBody.

        任务分组id

        :param group_id: The group_id of this MoveJobGroupRequestBody.
        :type group_id: str
        """
        self._group_id = group_id

    @property
    def jobs(self):
        r"""Gets the jobs of this MoveJobGroupRequestBody.

        任务组

        :return: The jobs of this MoveJobGroupRequestBody.
        :rtype: list[:class:`huaweicloudsdkcodeartsbuild.v3.MoveJobGroupRequestBodyJobs`]
        """
        return self._jobs

    @jobs.setter
    def jobs(self, jobs):
        r"""Sets the jobs of this MoveJobGroupRequestBody.

        任务组

        :param jobs: The jobs of this MoveJobGroupRequestBody.
        :type jobs: list[:class:`huaweicloudsdkcodeartsbuild.v3.MoveJobGroupRequestBodyJobs`]
        """
        self._jobs = jobs

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, MoveJobGroupRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
