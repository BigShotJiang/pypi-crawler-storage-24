# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListRecordsResult:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'pagination': 'ListRecordsResultPagination',
        'data': 'list[BuildRecord]'
    }

    attribute_map = {
        'pagination': 'pagination',
        'data': 'data'
    }

    def __init__(self, pagination=None, data=None):
        r"""ListRecordsResult

        The model defined in huaweicloud sdk

        :param pagination: 
        :type pagination: :class:`huaweicloudsdkcodeartsbuild.v3.ListRecordsResultPagination`
        :param data: 工程构建记录列表
        :type data: list[:class:`huaweicloudsdkcodeartsbuild.v3.BuildRecord`]
        """
        
        

        self._pagination = None
        self._data = None
        self.discriminator = None

        if pagination is not None:
            self.pagination = pagination
        if data is not None:
            self.data = data

    @property
    def pagination(self):
        r"""Gets the pagination of this ListRecordsResult.

        :return: The pagination of this ListRecordsResult.
        :rtype: :class:`huaweicloudsdkcodeartsbuild.v3.ListRecordsResultPagination`
        """
        return self._pagination

    @pagination.setter
    def pagination(self, pagination):
        r"""Sets the pagination of this ListRecordsResult.

        :param pagination: The pagination of this ListRecordsResult.
        :type pagination: :class:`huaweicloudsdkcodeartsbuild.v3.ListRecordsResultPagination`
        """
        self._pagination = pagination

    @property
    def data(self):
        r"""Gets the data of this ListRecordsResult.

        工程构建记录列表

        :return: The data of this ListRecordsResult.
        :rtype: list[:class:`huaweicloudsdkcodeartsbuild.v3.BuildRecord`]
        """
        return self._data

    @data.setter
    def data(self, data):
        r"""Sets the data of this ListRecordsResult.

        工程构建记录列表

        :param data: The data of this ListRecordsResult.
        :type data: list[:class:`huaweicloudsdkcodeartsbuild.v3.BuildRecord`]
        """
        self._data = data

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListRecordsResult):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
