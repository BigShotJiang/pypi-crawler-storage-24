# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListKeystoreSearchResponseBodyResult:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'total': 'float',
        'keystore_list': 'list[ListKeystoreSearchResponseBodyResultKeystoreList]'
    }

    attribute_map = {
        'total': 'total',
        'keystore_list': 'keystore_list'
    }

    def __init__(self, total=None, keystore_list=None):
        r"""ListKeystoreSearchResponseBodyResult

        The model defined in huaweicloud sdk

        :param total: 总数
        :type total: float
        :param keystore_list: 文件列表
        :type keystore_list: list[:class:`huaweicloudsdkcodeartsbuild.v3.ListKeystoreSearchResponseBodyResultKeystoreList`]
        """
        
        

        self._total = None
        self._keystore_list = None
        self.discriminator = None

        if total is not None:
            self.total = total
        if keystore_list is not None:
            self.keystore_list = keystore_list

    @property
    def total(self):
        r"""Gets the total of this ListKeystoreSearchResponseBodyResult.

        总数

        :return: The total of this ListKeystoreSearchResponseBodyResult.
        :rtype: float
        """
        return self._total

    @total.setter
    def total(self, total):
        r"""Sets the total of this ListKeystoreSearchResponseBodyResult.

        总数

        :param total: The total of this ListKeystoreSearchResponseBodyResult.
        :type total: float
        """
        self._total = total

    @property
    def keystore_list(self):
        r"""Gets the keystore_list of this ListKeystoreSearchResponseBodyResult.

        文件列表

        :return: The keystore_list of this ListKeystoreSearchResponseBodyResult.
        :rtype: list[:class:`huaweicloudsdkcodeartsbuild.v3.ListKeystoreSearchResponseBodyResultKeystoreList`]
        """
        return self._keystore_list

    @keystore_list.setter
    def keystore_list(self, keystore_list):
        r"""Sets the keystore_list of this ListKeystoreSearchResponseBodyResult.

        文件列表

        :param keystore_list: The keystore_list of this ListKeystoreSearchResponseBodyResult.
        :type keystore_list: list[:class:`huaweicloudsdkcodeartsbuild.v3.ListKeystoreSearchResponseBodyResultKeystoreList`]
        """
        self._keystore_list = keystore_list

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListKeystoreSearchResponseBodyResult):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
