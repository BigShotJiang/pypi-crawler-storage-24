# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class DomainsStatusesRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'domain_ids': 'str'
    }

    attribute_map = {
        'domain_ids': 'domain_ids'
    }

    def __init__(self, domain_ids=None):
        r"""DomainsStatusesRequestBody

        The model defined in huaweicloud sdk

        :param domain_ids: **参数解释**： 租户id集合。 **约束限制**： 不涉及。 **取值范围**： 不涉及。
        :type domain_ids: str
        """
        
        

        self._domain_ids = None
        self.discriminator = None

        if domain_ids is not None:
            self.domain_ids = domain_ids

    @property
    def domain_ids(self):
        r"""Gets the domain_ids of this DomainsStatusesRequestBody.

        **参数解释**： 租户id集合。 **约束限制**： 不涉及。 **取值范围**： 不涉及。

        :return: The domain_ids of this DomainsStatusesRequestBody.
        :rtype: str
        """
        return self._domain_ids

    @domain_ids.setter
    def domain_ids(self, domain_ids):
        r"""Sets the domain_ids of this DomainsStatusesRequestBody.

        **参数解释**： 租户id集合。 **约束限制**： 不涉及。 **取值范围**： 不涉及。

        :param domain_ids: The domain_ids of this DomainsStatusesRequestBody.
        :type domain_ids: str
        """
        self._domain_ids = domain_ids

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, DomainsStatusesRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
