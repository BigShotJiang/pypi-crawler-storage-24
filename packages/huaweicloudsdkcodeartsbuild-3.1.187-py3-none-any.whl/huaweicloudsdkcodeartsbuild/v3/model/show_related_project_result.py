# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowRelatedProjectResult:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'total': 'float',
        'project_info_list': 'list[ShowRelatedProjectResultProjectInfoList]'
    }

    attribute_map = {
        'total': 'total',
        'project_info_list': 'project_info_list'
    }

    def __init__(self, total=None, project_info_list=None):
        r"""ShowRelatedProjectResult

        The model defined in huaweicloud sdk

        :param total: 总数
        :type total: float
        :param project_info_list: 项目信息列表
        :type project_info_list: list[:class:`huaweicloudsdkcodeartsbuild.v3.ShowRelatedProjectResultProjectInfoList`]
        """
        
        

        self._total = None
        self._project_info_list = None
        self.discriminator = None

        if total is not None:
            self.total = total
        if project_info_list is not None:
            self.project_info_list = project_info_list

    @property
    def total(self):
        r"""Gets the total of this ShowRelatedProjectResult.

        总数

        :return: The total of this ShowRelatedProjectResult.
        :rtype: float
        """
        return self._total

    @total.setter
    def total(self, total):
        r"""Sets the total of this ShowRelatedProjectResult.

        总数

        :param total: The total of this ShowRelatedProjectResult.
        :type total: float
        """
        self._total = total

    @property
    def project_info_list(self):
        r"""Gets the project_info_list of this ShowRelatedProjectResult.

        项目信息列表

        :return: The project_info_list of this ShowRelatedProjectResult.
        :rtype: list[:class:`huaweicloudsdkcodeartsbuild.v3.ShowRelatedProjectResultProjectInfoList`]
        """
        return self._project_info_list

    @project_info_list.setter
    def project_info_list(self, project_info_list):
        r"""Sets the project_info_list of this ShowRelatedProjectResult.

        项目信息列表

        :param project_info_list: The project_info_list of this ShowRelatedProjectResult.
        :type project_info_list: list[:class:`huaweicloudsdkcodeartsbuild.v3.ShowRelatedProjectResultProjectInfoList`]
        """
        self._project_info_list = project_info_list

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowRelatedProjectResult):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
