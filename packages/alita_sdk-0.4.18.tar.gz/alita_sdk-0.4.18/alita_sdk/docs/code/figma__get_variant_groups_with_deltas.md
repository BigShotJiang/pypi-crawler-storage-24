# figma - get_variant_groups_with_deltas

**Toolkit**: `figma`
**Method**: `get_variant_groups_with_deltas`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def get_variant_groups_with_deltas(frames: List[Dict]) -> List[Dict]:
    """
    Get variant groups with computed deltas for efficient output.

    Returns list of variant groups:
    [
        {
            'base_name': 'Login',
            'base_frame': {...full frame data...},
            'variants': [
                {'name': 'Login_Error', 'state': 'error', 'added': {...}, ...},
                ...
            ]
        }
    ]
    """
    groups = group_variants(frames)
    result = []

    for base_name, variant_list in groups.items():
        if len(variant_list) < 2:
            continue

        # Sort variants to find the "default" state as base
        sorted_variants = sorted(variant_list, key=lambda v: (
            0 if infer_state_from_name(v['name']) == 'default' else 1,
            v['name']
        ))

        base_variant = sorted_variants[0]
        base_frame = base_variant.get('frame', {})

        group_data = {
            'base_name': base_name,
            'base_frame': base_frame,
            'variants': [],
        }

        # Compute deltas for other variants
        for variant in sorted_variants[1:]:
            variant_frame = variant.get('frame', {})
            delta = compute_frame_delta(base_frame, variant_frame)
            group_data['variants'].append(delta)

        result.append(group_data)

    return result
```

## Helper Methods

```python
Helper: infer_state_from_name
def infer_state_from_name(name: str) -> str:
    """
    Infer screen state from name.

    Returns: default, error, success, loading, empty, or the detected state
    """
    name_lower = name.lower()

    state_keywords = {
        'error': ['error', 'fail', 'invalid', 'wrong'],
        'success': ['success', 'complete', 'done', 'confirmed'],
        'loading': ['loading', 'progress', 'spinner', 'wait'],
        'empty': ['empty', 'no data', 'no results', 'blank'],
        'disabled': ['disabled', 'inactive', 'locked'],
    }

    for state, keywords in state_keywords.items():
        if any(kw in name_lower for kw in keywords):
            return state

    return 'default'
```
