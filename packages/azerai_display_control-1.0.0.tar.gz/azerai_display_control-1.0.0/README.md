# 🖥️ AzerAI Display Control Plugin

Azərbaycan dilində qabaqcıl səsli AI asistenti üçün ekran və audio kontrol plugini.

## Xüsusiyyətlər

- 🔆 **Parlqlıq kontrolü** - Ekran parlqlığını tənzimlə (0-100%)
- 🔊 **Səs səviyyəsi** - Səs səviyyəsini tənzimlə (0-100%)
- 🔇 **Mute toggle** - Səsi bağla/aç
- 📊 **Ekran məlumatları** - Qətnamə, parlqlıq və s.
- 🎤 **Audio məlumatları** - Səs səviyyəsi, device info
- 🎵 **Arxa plan musiqisi** - Əməliyyat zamanı G4 notası
- 🎤 **Mikrofon kontrolü** - Əməliyyat zamanı danışığı bloklayır

## Quraşdırma

```bash
pip install azerai-display-control
```

## İstifadə

Plugin avtomatik olaraq AzerAI tərəfindən aşkar edilir.

### Əmrlər

- `"Parlqlığı 80% et"` - Ekran parlqlığını tənzimlə
- `"Səsi 50% et"` - Səs səviyyəsini tənzimlə
- `"Səsi bağla"` - Səsi susdur
- `"Səsi aç"` - Səsi aç
- `"Ekran məlumatları"` - Ekran haqqında məlumat
- `"Audio məlumatları"` - Səs haqqında məlumat

## Fayl struktur

```
azerai_display_control/
├── plugins/
│   └── display_control/
│       ├── __init__.py
│       └── main.py
└── __init__.py
```

## Platform Dəstəyi

### 🪟 **Windows**
- ✅ Parlqlıq kontrolü (PowerShell WMI)
- ✅ Səs səviyyəsi (PowerShell/NirCmd)
- ✅ Mute toggle (PowerShell/NirCmd)
- ✅ Ekran məlumatları (WMI)
- ✅ Audio məlumatları (PowerShell)

## Asılılıqlar

- `livekit-agents>=1.0.0` - AI agent framework
- `sounddevice>=0.4.6` - Audio çalma
- `scipy>=1.11.0` - Audio işləmə
- `numpy>=1.24.0` - Riyazi əməliyyatlar

## Xüsusiyyətlər

### 🔆 **Parlqlıq Kontrolü**
- 0-100% arası tənzimləmə
- Windows WMI ilə sistem inteqrasiyası
- Anında tətbiq

### 🔊 **Səs Kontrolü**
- 0-100% arası səs səviyyəsi
- NirCmd və ya PowerShell alternativi
- Mute toggle funksiyası

### 📊 **Məlumat Toplama**
- Ekran qətnaməsi
- Cari parlqlıq səviyyəsi
- Səs səviyyəsi və statusu
- Default audio device

## Lisenziya

MIT License
