"""
AzerAI Display Control Plugin - Plugin package
"""
