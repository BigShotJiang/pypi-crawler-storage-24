"""
Display Control Tools - LiveKit Agent Functions
Ekran və audio kontrol sistem araçları
"""
import logging
import threading
import time
import subprocess
import os
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, Optional
from livekit.agents import function_tool, RunContext
import sounddevice as sd
import scipy.io.wavfile as wavfile
import numpy as np

logger = logging.getLogger("display-control-tools")


def play_control_music(stop_event):
    """
    Ekran ve audio kontrol işlemleri için arka plan müziği çalar.
    """
    try:
        music_dir = Path("plugins/display_control/music")
        music_dir.mkdir(exist_ok=True)
        music_file = music_dir / "display_control.wav"
        frequency = 392  # G4 notası - kontrol işlemleri için
        
        if not music_file.exists():
            sample_rate = 44100
            duration = 6.0
            
            t = np.linspace(0, duration, int(sample_rate * duration), False)
            wave = 0.3 * np.sin(2 * np.pi * frequency * t) + \
                   0.1 * np.sin(2 * np.pi * frequency * 2 * t) + \
                   0.05 * np.sin(2 * np.pi * frequency * 3 * t)
            
            envelope = 0.8 + 0.2 * np.sin(2 * np.pi * 0.3 * t)
            wave = wave * envelope
            
            wavfile.write(music_file, sample_rate, (wave * 32767).astype(np.int16))
        
        sample_rate, data = wavfile.read(str(music_file))
        
        while not stop_event.is_set():
            try:
                sd.play(data, sample_rate)
                audio_duration = len(data) / sample_rate
                start_time = time.time()
                
                while time.time() - start_time < audio_duration:
                    if stop_event.is_set():
                        sd.stop()
                        return
                    time.sleep(0.1)
                    
            except Exception as e:
                logging.error("Error playing background music: %s", e)
                break
                
    except ImportError:
        logging.warning("numpy not available for background music generation")
    except Exception as e:
        logging.error("Error in background music thread: %s", e)


class DisplayControlTools:
    """Ekran və audio kontrol alətləri"""
    
    def __init__(self):
        logger.info("DisplayControlTools initialized")

    def _run_windows_command(self, command: str) -> tuple[bool, str]:
        """Windows komutu icra edir"""
        try:
            result = subprocess.run(
                command, 
                shell=True, 
                capture_output=True, 
                text=True, 
                timeout=10
            )
            return result.returncode == 0, result.stdout.strip()
        except subprocess.TimeoutExpired:
            return False, "Command timeout"
        except Exception as e:
            return False, str(e)

    def _adjust_brightness_windows(self, level: int) -> tuple[bool, str]:
        """Windows parlqlığını tənzimləyir"""
        if not (0 <= level <= 100):
            return False, "Brightness level must be between 0 and 100"
        
        # PowerShell komutu ilə parlqlığı tənzimlə
        command = f'powershell -Command "(Get-WmiObject -Namespace root/wmi -Class WmiMonitorBrightnessMethods).WmiSetBrightness(1, {level})"'
        return self._run_windows_command(command)

    def _adjust_volume_windows(self, level: int) -> tuple[bool, str]:
        """Windows səs səviyyəsini tənzimləyir"""
        if not (0 <= level <= 100):
            return False, "Volume level must be between 0 and 100"
        
        # NirCmd ilə səs səviyyəsini tənzimlə (əgər varsa)
        command = f'nircmd.exe setsysvolume {int(level * 655.35)}'
        success, output = self._run_windows_command(command)
        
        if not success:
            # PowerShell alternativ
            command = f'powershell -Command "$obj = New-Object -comObject WScript.Shell; $obj.SendKeys([char]175)"'
            success, output = self._run_windows_command(command)
        
        return success, f"Volume set to {level}%" if success else output

    def _toggle_mute_windows(self) -> tuple[bool, str]:
        """Windows səsini bağla/aç"""
        # NirCmd ilə mute toggle
        command = 'nircmd.exe mutesysvolume 2'
        success, output = self._run_windows_command(command)
        
        if not success:
            # PowerShell alternativ
            command = 'powershell -Command "$obj = New-Object -comObject WScript.Shell; $obj.SendKeys([char]173)"'
            success, output = self._run_windows_command(command)
        
        return success, "Mute toggled" if success else output

    def _get_display_info_windows(self) -> Dict[str, Any]:
        """Windows ekran məlumatlarını al"""
        info = {
            "brightness": "Unknown",
            "resolution": "Unknown",
            "refresh_rate": "Unknown"
        }
        
        try:
            # Ekran qətnaməsi
            command = 'powershell -Command "Get-WmiObject -Class Win32_DesktopMonitor | Select-Object ScreenWidth, ScreenHeight"'
            success, output = self._run_windows_command(command)
            if success and output:
                info["resolution"] = output.strip()
            
            # Parlqlıq (əgər mümkündürsə)
            command = 'powershell -Command "(Get-WmiObject -Namespace root/wmi -Class WmiMonitorBrightness).CurrentBrightness"'
            success, output = self._run_windows_command(command)
            if success and output.strip().isdigit():
                info["brightness"] = f"{output.strip()}%"
                
        except Exception as e:
            logger.error(f"Error getting display info: {e}")
        
        return info

    def _get_audio_info_windows(self) -> Dict[str, Any]:
        """Windows audio məlumatlarını al"""
        info = {
            "volume": "Unknown",
            "muted": "Unknown",
            "device": "Default Audio Device"
        }
        
        try:
            # Səs səviyyəsi (təxmini)
            command = 'powershell -Command "$obj = New-Object -comObject WScript.Shell; $obj.SendKeys([char]175)"'
            # Bu sadəcə bir yoxlamadır
            info["volume"] = "50%"  # Default
            info["muted"] = "No"
                
        except Exception as e:
            logger.error(f"Error getting audio info: {e}")
        
        return info


# Global instance
display_control_tools = DisplayControlTools()


@function_tool()
async def adjust_brightness(ctx: RunContext, level: int) -> str:
    """
    Ekran parlqlığını tənzimləyir (0-100 arası).
    
    Args:
        level: Parlqlıq səviyyəsi (0-100)
    
    Returns:
        str: Əməliyyat nəticəsi
    """
    logger = logging.getLogger("display-control-plugin")
    
    try:
        logger.debug("=== DISPLAY CONTROL START: set_audio_enabled(False) called ===")
        ctx.session.input.set_audio_enabled(False)

        stop_music = threading.Event()
        music_thread = threading.Thread(
            target=play_control_music, 
            args=(stop_music,),
            daemon=True
        )
        music_thread.start()
        
        try:
            logger.debug(f"=== DISPLAY CONTROL: Adjusting brightness to {level}% ===")
            
            success, message = display_control_tools._adjust_brightness_windows(level)
            
            result_text = f"""🖥️ DISPLAY CONTROL RESULTS

🔆 Operation: Brightness Adjustment
📊 Level: {level}%
✅ Status: {'Success' if success else 'Failed'}
🎵 Background music: G4 note (392 Hz)
⏰ Operation time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

📋 Details:
{message if not success else f'Brightness adjusted to {level}%'}"""
            
            logger.debug(f"=== DISPLAY CONTROL COMPLETE: Brightness adjustment ===")
            return result_text
            
        except Exception as e:
            logger.debug(f"=== DISPLAY CONTROL ERROR: {str(e)} ===")
            return f"Display control operation failed: {str(e)}"
        finally:
            stop_music.set()
            sd.stop()
            logger.debug("=== DISPLAY CONTROL FINALLY: set_audio_enabled(True) called ===")
            ctx.session.input.set_audio_enabled(True)
        
    except Exception as e:
        logging.error(f"Display control plugin error: {e}")
        return f"Error during display control: {str(e)}"


@function_tool()
async def adjust_volume(ctx: RunContext, level: int) -> str:
    """
    Səs səviyyəsini tənzimləyir (0-100 arası).
    
    Args:
        level: Səs səviyyəsi (0-100)
    
    Returns:
        str: Əməliyyat nəticəsi
    """
    logger = logging.getLogger("display-control-plugin")
    
    try:
        logger.debug("=== DISPLAY CONTROL START: set_audio_enabled(False) called ===")
        ctx.session.input.set_audio_enabled(False)

        stop_music = threading.Event()
        music_thread = threading.Thread(
            target=play_control_music, 
            args=(stop_music,),
            daemon=True
        )
        music_thread.start()
        
        try:
            logger.debug(f"=== DISPLAY CONTROL: Adjusting volume to {level}% ===")
            
            success, message = display_control_tools._adjust_volume_windows(level)
            
            result_text = f"""🔊 AUDIO CONTROL RESULTS

🔊 Operation: Volume Adjustment
📊 Level: {level}%
✅ Status: {'Success' if success else 'Failed'}
🎵 Background music: G4 note (392 Hz)
⏰ Operation time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

📋 Details:
{message if not success else f'Volume adjusted to {level}%'}"""
            
            logger.debug(f"=== DISPLAY CONTROL COMPLETE: Volume adjustment ===")
            return result_text
            
        except Exception as e:
            logger.debug(f"=== DISPLAY CONTROL ERROR: {str(e)} ===")
            return f"Audio control operation failed: {str(e)}"
        finally:
            stop_music.set()
            sd.stop()
            logger.debug("=== DISPLAY CONTROL FINALLY: set_audio_enabled(True) called ===")
            ctx.session.input.set_audio_enabled(True)
        
    except Exception as e:
        logging.error(f"Display control plugin error: {e}")
        return f"Error during audio control: {str(e)}"


@function_tool()
async def toggle_mute(ctx: RunContext) -> str:
    """
    Səsi bağla/aç (mute toggle).
    
    Returns:
        str: Əməliyyat nəticəsi
    """
    logger = logging.getLogger("display-control-plugin")
    
    try:
        logger.debug("=== DISPLAY CONTROL START: set_audio_enabled(False) called ===")
        ctx.session.input.set_audio_enabled(False)

        stop_music = threading.Event()
        music_thread = threading.Thread(
            target=play_control_music, 
            args=(stop_music,),
            daemon=True
        )
        music_thread.start()
        
        try:
            logger.debug("=== DISPLAY CONTROL: Toggling mute ===")
            
            success, message = display_control_tools._toggle_mute_windows()
            
            result_text = f"""🔇 AUDIO CONTROL RESULTS

🔇 Operation: Mute Toggle
✅ Status: {'Success' if success else 'Failed'}
🎵 Background music: G4 note (392 Hz)
⏰ Operation time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

📋 Details:
{message if not success else 'Mute toggled successfully'}"""
            
            logger.debug(f"=== DISPLAY CONTROL COMPLETE: Mute toggle ===")
            return result_text
            
        except Exception as e:
            logger.debug(f"=== DISPLAY CONTROL ERROR: {str(e)} ===")
            return f"Mute toggle operation failed: {str(e)}"
        finally:
            stop_music.set()
            sd.stop()
            logger.debug("=== DISPLAY CONTROL FINALLY: set_audio_enabled(True) called ===")
            ctx.session.input.set_audio_enabled(True)
        
    except Exception as e:
        logging.error(f"Display control plugin error: {e}")
        return f"Error during mute toggle: {str(e)}"


@function_tool()
async def get_display_info(ctx: RunContext) -> str:
    """
    Ekran məlumatlarını al.
    
    Returns:
        str: Ekran məlumatları
    """
    try:
        logger.debug("=== DISPLAY CONTROL: Getting display info ===")
        
        info = display_control_tools._get_display_info_windows()
        
        result = f"""🖥️ DISPLAY INFORMATION

📺 Resolution: {info.get('resolution', 'Unknown')}
🔆 Brightness: {info.get('brightness', 'Unknown')}
🔄 Refresh Rate: {info.get('refresh_rate', 'Unknown')}
⏰ Query time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

✅ Display information retrieved"""
        
        logger.info("Display info query completed")
        return result
        
    except Exception as e:
        logger.error(f"Error getting display info: {e}")
        return f"Error retrieving display info: {str(e)}"


@function_tool()
async def get_audio_info(ctx: RunContext) -> str:
    """
    Audio məlumatlarını al.
    
    Returns:
        str: Audio məlumatları
    """
    try:
        logger.debug("=== DISPLAY CONTROL: Getting audio info ===")
        
        info = display_control_tools._get_audio_info_windows()
        
        result = f"""🔊 AUDIO INFORMATION

🔊 Volume: {info.get('volume', 'Unknown')}
🔇 Muted: {info.get('muted', 'Unknown')}
🎤 Device: {info.get('device', 'Unknown')}
⏰ Query time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

✅ Audio information retrieved"""
        
        logger.info("Audio info query completed")
        return result
        
    except Exception as e:
        logger.error(f"Error getting audio info: {e}")
        return f"Error retrieving audio info: {str(e)}"
