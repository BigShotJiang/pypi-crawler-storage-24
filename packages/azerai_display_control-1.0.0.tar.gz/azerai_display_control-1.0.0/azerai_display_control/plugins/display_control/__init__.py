"""
AzerAI Display Control Plugin
"""

from .main import (
    adjust_brightness,
    adjust_volume,
    toggle_mute,
    get_display_info,
    get_audio_info
)

__all__ = [
    "adjust_brightness",
    "adjust_volume",
    "toggle_mute",
    "get_display_info",
    "get_audio_info"
]
