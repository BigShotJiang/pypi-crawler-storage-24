"""
AzerAI Display Control Plugin - Ekran və audio kontrol plugini

Plugin əsaslı, çoxdilli AI asistenti üçün ekran və audio modulu.
"""

__version__ = "1.0.0"
__author__ = "AzStudio Dev"
__email__ = "dev@azstudio.ai"

from .plugins.display_control.main import (
    adjust_brightness,
    adjust_volume,
    toggle_mute,
    get_display_info,
    get_audio_info
)

__all__ = [
    "adjust_brightness",
    "adjust_volume",
    "toggle_mute",
    "get_display_info",
    "get_audio_info"
]
