"""MateObserve CLI — manage the observability stack."""

from __future__ import annotations

import argparse
import shutil
import socket
import subprocess
import sys
from pathlib import Path


def _find_compose_file() -> Path:
    """Locate docker-compose.yml — checks source tree, CWD, then bundled copy."""
    # 1. Source / editable install: relative to this file
    src = Path(__file__).resolve().parents[2] / "docker" / "docker-compose.yml"
    if src.exists():
        return src
    # 2. CWD (user inside repo root)
    for name in ("docker-compose.yml", "docker/docker-compose.yml"):
        p = Path.cwd() / name
        if p.exists():
            return p
    # 3. Bundled with pip package
    bundled = Path(__file__).resolve().parent / "data" / "docker-compose.yml"
    if bundled.exists():
        return bundled
    # Not found — return bundled path so the error message is helpful
    return bundled


COMPOSE_FILE = _find_compose_file()


def _get_compose_cmd() -> list[str]:
    """Return the base compose command, preferring 'docker compose' plugin."""
    # Prefer the modern 'docker compose' plugin
    try:
        r = subprocess.run(
            ["docker", "compose", "version"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        if r.returncode == 0:
            return ["docker", "compose"]
    except FileNotFoundError:
        pass
    # Fall back to legacy standalone binary
    if shutil.which("docker-compose"):
        return ["docker-compose"]
    # Default — will produce a clear error from Docker
    return ["docker", "compose"]


def _run(args: list[str]) -> int:
    try:
        return subprocess.run(args).returncode
    except FileNotFoundError:
        print(
            "Error: Docker not found. Install it from https://docs.docker.com/get-docker/",
            file=sys.stderr,
        )
        return 1


def cmd_up() -> int:
    print("🧉 Starting MateObserve stack...")
    rc = _run(_get_compose_cmd() + ["-f", str(COMPOSE_FILE), "up", "-d"])
    if rc == 0:
        print("\nDashboard:  http://localhost:4000")
        print("Collector:  http://localhost:8001")
    return rc


def cmd_down() -> int:
    print("🧉 Stopping MateObserve stack...")
    return _run(_get_compose_cmd() + ["-f", str(COMPOSE_FILE), "down"])


def cmd_status() -> int:
    return _run(_get_compose_cmd() + ["-f", str(COMPOSE_FILE), "ps"])


def _check_command(name: str, args: list[str]) -> bool:
    try:
        subprocess.run(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except FileNotFoundError:
        return False


def _port_available(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(("127.0.0.1", port)) != 0


def cmd_doctor() -> int:
    print("🧉 Checking MateObserve environment...\n")
    ok = True

    # Docker
    if _check_command("docker", ["docker", "info"]):
        print("  ✓ Docker installed")
    else:
        print("  ✗ Docker not found — install it from https://docs.docker.com/get-docker/")
        ok = False

    # Docker Compose
    compose_cmd = _get_compose_cmd()
    if _check_command("docker compose", compose_cmd + ["version"]):
        print(f"  ✓ Docker Compose available ({' '.join(compose_cmd)})")
    else:
        print("  ✗ Docker Compose not available — install Docker Compose")
        ok = False

    # Port 4000 (dashboard)
    if _port_available(4000):
        print("  ✓ Port 4000 available (dashboard)")
    else:
        print("  ✗ Port 4000 in use — the dashboard needs this port")
        ok = False

    # Port 8001 (collector)
    if _port_available(8001):
        print("  ✓ Port 8001 available (collector)")
    else:
        print("  ✗ Port 8001 in use — the collector needs this port")
        ok = False

    print()
    if ok:
        print("MateObserve environment looks good.")
        return 0
    else:
        print("Some checks failed. Fix the issues above and try again.")
        return 1


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="mateobserve",
        description="MateObserve — simple observability for Python APIs 🧉",
    )
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("up", help="Start the MateObserve stack")
    sub.add_parser("down", help="Stop the MateObserve stack")
    sub.add_parser("status", help="Show running containers")
    sub.add_parser("doctor", help="Check environment readiness")

    args = parser.parse_args()

    commands = {
        "up": cmd_up,
        "down": cmd_down,
        "status": cmd_status,
        "doctor": cmd_doctor,
    }

    if args.command is None:
        parser.print_help()
        sys.exit(1)

    sys.exit(commands[args.command]())


if __name__ == "__main__":
    main()
