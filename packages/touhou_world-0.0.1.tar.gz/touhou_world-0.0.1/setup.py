
from setuptools import setup, find_packages

setup(
    name="touhou-world",  # PyPI 上的名字
    version="0.0.1",
    packages=find_packages(),
    description="Touhou Project Python Package",
    author="Patchouli-CN",
    url="https://github.com/Patchouli-CN/touhou-world",
)
