# omnicomp-gemini-oauth

Gemini OAuth-based omnicomp provider
