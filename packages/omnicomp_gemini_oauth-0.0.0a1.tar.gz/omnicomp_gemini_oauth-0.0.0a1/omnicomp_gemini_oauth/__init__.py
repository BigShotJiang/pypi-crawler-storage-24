"""Gemini OAuth-based omnicomp provider"""

__version__ = "0.0.0a1"
