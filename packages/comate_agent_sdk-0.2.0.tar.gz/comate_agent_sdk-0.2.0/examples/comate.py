# /// script
# requires-python = ">=3.11"
# dependencies = [
#     "comate-agent-sdk>=0.0.1",
#     "rich>=14.0",
#     "prompt-toolkit>=3.0",
# ]
# ///

"""Strong terminal agent compatibility entrypoint.

该入口保留 `uv run python examples/comate.py` 体验，优先启动 `comate_cli` 包中的 TUI；
若未安装 `comate_cli`，则回退到仓库内 `examples/terminal_agent`。
"""

from __future__ import annotations

import atexit
import asyncio
import inspect
import logging
import signal
import subprocess
import sys
import termios
import threading
from pathlib import Path

logger = logging.getLogger(__name__)


class _TerminalStateGuard:
    """Best-effort tty restore guard for abnormal shutdown paths."""

    def __init__(self) -> None:
        self._fd: int | None = None
        self._attrs: list[int | list[int | bytes]] | None = None
        self._enabled = False

        stdin = sys.__stdin__
        if stdin is None:
            return
        if not stdin.isatty():
            return
        try:
            self._fd = stdin.fileno()
            self._attrs = termios.tcgetattr(self._fd)
            self._enabled = True
        except Exception as exc:
            logger.debug(f"Terminal guard disabled: failed to snapshot tty attrs: {exc}")

    def restore(self, *, reason: str) -> None:
        if not self._enabled or self._fd is None or self._attrs is None:
            return

        try:
            termios.tcsetattr(self._fd, termios.TCSANOW, self._attrs)
            return
        except Exception as exc:
            logger.warning(f"tty restore failed ({reason}): {exc}", exc_info=True)

        try:
            subprocess.run(
                ["stty", "sane"],
                stdin=sys.__stdin__,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False,
            )
        except Exception as exc:
            logger.warning(f"stty sane fallback failed ({reason}): {exc}", exc_info=True)


class _ShutdownNoiseGuard:
    """Suppress KeyboardInterrupt noise in interpreter shutdown phase."""

    def __init__(self) -> None:
        self._shutdown_armed = False
        self._orig_unraisablehook = sys.unraisablehook

    def install(self) -> None:
        sys.unraisablehook = self._unraisablehook

    def begin_shutdown(self) -> None:
        if self._shutdown_armed:
            return
        self._shutdown_armed = True
        self._ignore_sigint_until_exit()

    def _ignore_sigint_until_exit(self) -> None:
        if threading.current_thread() is not threading.main_thread():
            return
        try:
            signal.signal(signal.SIGINT, signal.SIG_IGN)
            logger.debug("SIGINT is now ignored for final shutdown")
        except Exception as exc:
            logger.debug(f"Failed to switch SIGINT to SIG_IGN during shutdown: {exc}")

    def _unraisablehook(self, unraisable: object) -> None:
        exc_value = getattr(unraisable, "exc_value", None)
        if self._shutdown_armed and isinstance(exc_value, KeyboardInterrupt):
            logger.debug("Suppressed unraisable KeyboardInterrupt during shutdown")
            return

        self._orig_unraisablehook(unraisable)


class _ArgumentError(ValueError):
    """Raised when CLI arguments are invalid."""


def _ensure_local_examples_on_path() -> None:
    examples_dir = Path(__file__).resolve().parent
    repo_root = examples_dir.parent
    cli_pkg_root = repo_root / "packages" / "comate_cli"
    preferred_paths = (examples_dir, repo_root, cli_pkg_root)

    for path in reversed(preferred_paths):
        path_str = str(path)
        if path_str in sys.path:
            sys.path.remove(path_str)
        if path.exists():
            sys.path.insert(0, path_str)


def _usage_text() -> str:
    return (
        "Usage:\n"
        "  uv run python examples/comate.py [--rpc-stdio]\n"
        "  uv run python examples/comate.py resume <session_id> [--rpc-stdio]"
    )


def _parse_args(argv: list[str]) -> tuple[bool, str | None]:
    rpc_stdio = False
    positionals: list[str] = []
    for arg in argv:
        if arg == "--rpc-stdio":
            rpc_stdio = True
            continue
        if arg.startswith("-"):
            raise _ArgumentError(f"Unknown option: {arg}")
        positionals.append(arg)

    if not positionals:
        return rpc_stdio, None

    command = positionals[0]
    if command != "resume":
        raise _ArgumentError(f"Unknown command: {command}")
    if len(positionals) != 2:
        raise _ArgumentError("resume requires exactly one <session_id>")
    return rpc_stdio, positionals[1]


def _build_run_kwargs(run_callable: object, *, rpc_stdio: bool, resume_session_id: str | None) -> dict[str, object]:
    try:
        parameters = inspect.signature(run_callable).parameters
    except (TypeError, ValueError):
        parameters = {}

    if "resume_session_id" in parameters:
        return {
            "rpc_stdio": rpc_stdio,
            "resume_session_id": resume_session_id,
        }

    return {
        "rpc_stdio": rpc_stdio,
        "session_id": resume_session_id,
    }


def main() -> None:
    noise_guard = _ShutdownNoiseGuard()
    noise_guard.install()

    term_guard = _TerminalStateGuard()
    atexit.register(term_guard.restore, reason="atexit")
    atexit.register(noise_guard.begin_shutdown)

    _ensure_local_examples_on_path()
    try:
        from comate_cli.terminal_agent.app import run
    except ModuleNotFoundError:
        from terminal_agent.app import run

    try:
        rpc_stdio, resume_session_id = _parse_args(sys.argv[1:])
    except _ArgumentError as exc:
        sys.stderr.write(f"{exc}\n{_usage_text()}\n")
        raise SystemExit(2) from exc

    run_kwargs = _build_run_kwargs(
        run,
        rpc_stdio=rpc_stdio,
        resume_session_id=resume_session_id,
    )
    try:
        asyncio.run(run(**run_kwargs))
    except KeyboardInterrupt:
        noise_guard.begin_shutdown()
    finally:
        noise_guard.begin_shutdown()
        term_guard.restore(reason="main-finally")


if __name__ == "__main__":
    main()
