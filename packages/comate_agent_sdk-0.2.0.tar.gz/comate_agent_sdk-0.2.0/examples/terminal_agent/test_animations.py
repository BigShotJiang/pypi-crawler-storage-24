from __future__ import annotations

import sys
import unittest
from pathlib import Path

EXAMPLES_DIR = Path(__file__).resolve().parents[1]
if str(EXAMPLES_DIR) not in sys.path:
    sys.path.insert(0, str(EXAMPLES_DIR))

from terminal_agent.animations import breathing_dot_glyph


class TestBreathingDotGlyph(unittest.TestCase):
    def test_glyph_switches_every_one_second(self) -> None:
        self.assertEqual(breathing_dot_glyph(1000.00), "○")
        self.assertEqual(breathing_dot_glyph(1000.99), "○")
        self.assertEqual(breathing_dot_glyph(1001.00), "●")
        self.assertEqual(breathing_dot_glyph(1001.99), "●")
        self.assertEqual(breathing_dot_glyph(1002.00), "○")


if __name__ == "__main__":
    unittest.main(verbosity=2)
