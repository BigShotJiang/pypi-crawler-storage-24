from __future__ import annotations

import asyncio
import json
import logging
import time
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from collections.abc import AsyncIterator, Callable
from contextlib import nullcontext, suppress
from typing import TYPE_CHECKING, Literal

from comate_agent_sdk.agent.events import (
    AgentEvent,
    StepCompleteEvent,
    StepStartEvent,
    StopEvent,
    SubagentProgressEvent,
    SubagentToolCallEvent,
    SubagentToolResultEvent,
    TaskUpdatedEvent,
    TextEvent,
    ThinkingEvent,
    ToolCallEvent,
    ToolResultEvent,
    UsageDeltaEvent,
)
from comate_agent_sdk.agent.external_turns import ExternalTurnInput, build_team_inbox_turn_text
from comate_agent_sdk.agent.history import destroy_ephemeral_messages
from comate_agent_sdk.agent.llm import invoke_llm
from comate_agent_sdk.agent.tool_exec import _coerce_tool_arguments
from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.llm.messages import (
    AssistantMessage,
    ContentPartImageParam,
    ContentPartTextParam,
    ToolCall,
    ToolMessage,
    UserMessage,
)
from comate_agent_sdk.prompts import load_prompt, render_prompt
from comate_agent_sdk.system_tools.team.identity import resolve_runtime_team_agent_name

from .compaction import check_and_compact, generate_max_iterations_summary, precheck_and_compact
from .execution.state import RunningTaskState, TaskStreamOut, TurnEngineState
from .execution.stream_drain import EventDrainHub
from .execution.task_lifecycle import TaskLifecycleEmitter
from .execution.tool_execution import execute_tool_calls
from .lifecycle import (
    fire_session_start_if_needed as _fire_session_start_if_needed,
    fire_user_prompt_submit as _fire_user_prompt_submit,
    is_interrupt_requested as _is_interrupt_requested,
)
from .policy.stop_policy import should_continue_after_stop_block
from .policy.tool_call_interceptor import ToolCallInterceptor, is_yield_turn
from .policy.tool_policy import (
    enforce_ask_user_exclusive_policy,
    is_ask_user_question,
    policy_violation_message,
)

logger = logging.getLogger("comate_agent_sdk.agent")

if TYPE_CHECKING:
    from comate_agent_sdk.agent.core import AgentRuntime
    from comate_agent_sdk.tokens.views import TokenUsageEntry


@dataclass(slots=True)
class TurnSource:
    kind: Literal["user", "team_inbox"]
    content: str | list[ContentPartTextParam | ContentPartImageParam]
    inbox_event_keys: list[str] = field(default_factory=list)


def _source_matches_prefix(*, source: str, source_prefix: str) -> bool:
    if not source or not source_prefix:
        return False
    return source == source_prefix or source.startswith(f"{source_prefix}:")


def _render_plan_mode_prompt(template: str, *, active_plan_path: str | None) -> str:
    prompt = str(template or "").strip()
    if not prompt:
        return ""

    path_text = str(active_plan_path or "").strip()
    if "{{PLAN_FILE_PATH}}" in prompt:
        return render_prompt(
            prompt,
            variables={"PLAN_FILE_PATH": path_text},
            source="agent/plan_prompt.md",
        )

    if not path_text:
        return prompt

    return (
        f"{prompt}\n\n"
        "## Active Plan File:\n"
        f"- `plan_file_path`: {path_text}\n"
        "- You MUST only use Write/Edit/MultiEdit on this file while in Plan Mode.\n"
        "- ExitPlanMode will read this file for approval and will not create a new plan file."
    )


def _usage_belongs_to_task(event: UsageDeltaEvent, state: RunningTaskState) -> bool:
    return _source_matches_prefix(source=event.source, source_prefix=state.source_prefix)


def _usage_delta_tokens_for_progress(event: UsageDeltaEvent) -> int:
    """Subagent progress uses effective token consumption.

    We intentionally exclude cached prompt tokens to avoid inflated progress
    numbers when prompt cache hits are high.
    """
    prompt_tokens = max(int(event.delta_prompt_tokens), 0)
    cached_prompt_tokens = max(int(event.delta_prompt_cached_tokens), 0)
    completion_tokens = max(int(event.delta_completion_tokens), 0)
    prompt_new_tokens = max(prompt_tokens - cached_prompt_tokens, 0)
    return prompt_new_tokens + completion_tokens


def _resolve_task_metadata(
    *,
    tool_call_id: str,
    args: dict,
) -> tuple[str, str, str]:
    subagent_name = ""
    description = ""

    raw_name = args.get("subagent_type")
    if isinstance(raw_name, str):
        subagent_name = raw_name.strip()

    raw_desc = args.get("description")
    if isinstance(raw_desc, str):
        description = raw_desc.strip()

    if not subagent_name:
        subagent_name = "Agent"
    if not description:
        description = subagent_name

    source_prefix = f"subagent:{subagent_name}:{tool_call_id}"
    return subagent_name, description, source_prefix


def _normalize_tool_call_event_args(
    agent: "AgentRuntime",
    *,
    tool_name: str,
    raw_args: object,
) -> dict:
    if not isinstance(raw_args, dict):
        return {"_raw": str(raw_args)}

    tool = agent._tool_map.get(tool_name)
    if tool is None:
        return raw_args

    schema = tool.definition.parameters
    if not isinstance(schema, dict):
        return raw_args

    try:
        coerced = _coerce_tool_arguments(raw_args, schema)
    except Exception as exc:
        logger.debug(f"Failed to normalize ToolCallEvent args for {tool_name}: {exc}")
        return raw_args

    if isinstance(coerced, dict):
        return coerced
    return raw_args


def _check_team_inbox(agent: "AgentRuntime") -> list[str]:
    """兼容包装：轮询 team inbox，并将消息注入为 runtime coordination context。

    返回 shutdown_request 的发送方列表；非空表示调用方应回复并终止主循环。
    """
    shutdown_requesters, reminder = _read_team_inbox(agent)
    if reminder:
        _inject_team_inbox_context(agent, reminder)
    return shutdown_requesters


def _read_team_inbox(agent: "AgentRuntime") -> tuple[list[str], str | None]:
    """读取 team inbox 的未读消息。

    返回 (shutdown_requesters, reminder_text)。
    这里只做读取，不做注入，便于将注入时机放到 precheck_and_compact() 之后。
    """
    if bool(getattr(agent, "_team_session_managed", False)):
        return [], None
    if not getattr(agent, "is_team_member", False):
        return [], None
    team_name = getattr(agent, "_team_name", "").strip()
    agent_name = resolve_runtime_team_agent_name(
        runtime_name=getattr(agent, "name", None),
        is_subagent=bool(getattr(agent, "_is_subagent", False)),
    )
    if not team_name or not agent_name:
        return [], None

    try:
        from comate_agent_sdk.system_tools.team.inbox import Inbox, MessageType

        inbox = Inbox(team_name=team_name, agent_name=agent_name)
        messages = inbox.read_unread(mark_as_read=True)
        if not messages:
            return [], None

        shutdown_requesters: list[str] = []
        reminder_lines: list[str] = ["# Team Inbox — New Messages"]
        for envelope in messages:
            from_agent = str(envelope.get("from", "unknown") or "unknown").strip() or "unknown"
            timestamp = str(envelope.get("timestamp", "") or "").strip()
            raw_text = envelope.get("text", "")
            try:
                payload = json.loads(raw_text) if raw_text else {}
            except Exception:
                payload = {"raw": raw_text}

            msg_type = str(payload.get("type", "message") or "message").strip() or "message"
            content = str(payload.get("content", raw_text) or "").strip()

            reminder_lines.append(
                f"- [{timestamp}] From: {from_agent} | Type: {msg_type}\n  {content}"
            )
            if msg_type == MessageType.SHUTDOWN_REQUEST.value and from_agent not in shutdown_requesters:
                shutdown_requesters.append(from_agent)

        reminder = "\n".join(reminder_lines)
        logger.debug(
            f"[Team inbox] {len(messages)} 条消息读取完成: "
            f"team={team_name!r} agent={agent_name!r}"
        )
        return shutdown_requesters, reminder
    except Exception as exc:
        logger.debug(f"[Team inbox] 轮询失败（忽略）: {exc}")
        return [], None


def _inject_team_inbox_context(agent: "AgentRuntime", reminder: str) -> None:
    text = _wrap_runtime_coordination_reminder(reminder)
    if not text:
        return
    agent.add_hidden_system_reminder(
        text,
        metadata={
            "origin": "runtime_coordination",
            "coordination_kind": "team_inbox",
            "reminder_rule_ids": ["team_inbox"],
        },
    )


def _format_transport_events_as_team_inbox_turn(events: list[object]) -> str:
    lines = ["<team-inbox-turn>", "source: team_inbox", "messages:"]
    for event in events:
        timestamp = str(getattr(event, "timestamp", "") or "").strip()
        from_agent = str(getattr(event, "from_agent", "") or "").strip() or "unknown"
        message_type = str(getattr(event, "message_type", "") or "").strip() or "message"
        content = str(getattr(event, "content", "") or "").strip()
        lines.append(
            f"- [{timestamp}] from={from_agent} type={message_type}\n"
            f"  content={content}"
        )
    lines.append("</team-inbox-turn>")
    return "\n".join(lines)


async def _poll_runtime_team_inbox(agent: "AgentRuntime") -> None:
    poll_once = getattr(agent, "_poll_team_inbox_once", None)
    if callable(poll_once):
        await poll_once()


def _has_buffered_shutdown_request(agent: "AgentRuntime") -> bool:
    pending_events = getattr(agent, "_pending_inbox_events", [])
    for event in pending_events:
        message_type = str(getattr(event, "message_type", "") or "").strip()
        if message_type == "shutdown_request":
            return True
    return False


def _notify_chat_session_turn_complete(agent: "AgentRuntime") -> None:
    callback = getattr(agent, "_chat_session_turn_complete_callback", None)
    if callable(callback):
        callback()


def _consume_buffered_inbox_control_or_turn_source(
    agent: "AgentRuntime",
) -> tuple[list[str], TurnSource | None]:
    drain_pending = getattr(agent, "drain_pending_inbox_events", None)
    if not callable(drain_pending):
        return [], None

    pending_events = drain_pending()
    if not pending_events:
        return [], None

    shutdown_keys: list[str] = []
    shutdown_requesters: list[str] = []
    ignored_keys: list[str] = []
    conversational_events: list[object] = []
    for event in pending_events:
        message_type = str(getattr(event, "message_type", "") or "").strip()
        if message_type == "shutdown_request":
            shutdown_keys.append(str(getattr(event, "key", "") or "").strip())
            from_agent = str(getattr(event, "from_agent", "") or "").strip()
            if from_agent and from_agent not in shutdown_requesters:
                shutdown_requesters.append(from_agent)
            continue
        if message_type == "idle_notification":
            ignored_keys.append(str(getattr(event, "key", "") or "").strip())
            continue
        conversational_events.append(event)

    if shutdown_keys or ignored_keys:
        ack_pending = getattr(agent, "ack_pending_inbox_events", None)
        if callable(ack_pending):
            ack_pending(shutdown_keys + ignored_keys)
    if shutdown_keys:
        return shutdown_requesters, None

    if not conversational_events:
        return [], None

    return (
        [],
        TurnSource(
            kind="team_inbox",
            content=_format_transport_events_as_team_inbox_turn(conversational_events),
            inbox_event_keys=[
                str(getattr(event, "key", "") or "").strip()
                for event in conversational_events
                if str(getattr(event, "key", "") or "").strip()
            ],
        ),
    )


def _has_live_reminder_rule(agent: "AgentRuntime", rule_id: str) -> bool:
    normalized_rule_id = str(rule_id or "").strip()
    if not normalized_rule_id:
        return False

    for item in reversed(agent._context.conversation.items):
        if item.destroyed:
            continue
        raw_rule_ids = (item.metadata or {}).get("reminder_rule_ids", [])
        if not isinstance(raw_rule_ids, list):
            continue
        if normalized_rule_id in {str(raw_id).strip() for raw_id in raw_rule_ids}:
            return True
    return False


def _wrap_runtime_coordination_reminder(content: str) -> str:
    text = str(content or "").strip()
    if not text:
        return ""
    return f"<system-reminder>\n{text}\n</system-reminder>"


def _build_task_list_path(agent: "AgentRuntime", *, team_name: str) -> str:
    from comate_agent_sdk.system_tools.task.store import resolve_task_store_dir

    list_id = str(getattr(agent, "_task_namespace", "") or "").strip() or team_name
    return str((resolve_task_store_dir() / f"{list_id}.json").resolve())


def _resolve_team_coordination_role(
    agent: "AgentRuntime",
    *,
    members: list[dict] | None,
) -> str:
    agent_name = resolve_runtime_team_agent_name(
        runtime_name=getattr(agent, "name", None),
        is_subagent=bool(getattr(agent, "_is_subagent", False)),
    )
    if members is not None and agent_name:
        for member in members:
            if str(member.get("name", "") or "").strip() != agent_name:
                continue
            if str(member.get("agent_type", "") or "").strip() == "leader":
                return "leader"
            return "member"
    return "member" if bool(getattr(agent, "_is_subagent", False)) else "leader"


def _build_team_coordination_reminder(agent: "AgentRuntime") -> tuple[str | None, str | None]:
    """构建 team coordination runtime context。

    返回 (role, reminder_text)。非 team 模式或缺少必要上下文时返回 (None, None)。
    """
    if not getattr(agent, "is_team_member", False):
        return None, None

    team_name = getattr(agent, "_team_name", "").strip()
    agent_name = resolve_runtime_team_agent_name(
        runtime_name=getattr(agent, "name", None),
        is_subagent=bool(getattr(agent, "_is_subagent", False)),
    )
    if not team_name or not agent_name:
        return None, None

    from comate_agent_sdk.system_tools.team.config import TeamConfig
    from comate_agent_sdk.system_tools.team.inbox import Inbox

    team_cfg = TeamConfig(team_name=team_name)
    inbox = Inbox(team_name=team_name, agent_name=agent_name)
    members: list[dict] | None = None
    member_lines = "- (team roster unavailable)"
    leader_name = ""
    roster_unavailable = False

    try:
        members = team_cfg.list_members()
        teammates = [
            member
            for member in members
            if str(member.get("name", "") or "").strip() != agent_name
        ]
        if teammates:
            member_lines = "\n".join(
                f"- {str(member.get('name', '') or '').strip()} "
                f"({str(member.get('agent_type', 'unknown') or 'unknown').strip() or 'unknown'})"
                for member in teammates
                if str(member.get("name", "") or "").strip()
            ) or "- (no teammates registered yet)"
        else:
            member_lines = "- (no teammates registered yet)"

        for member in members:
            candidate_name = str(member.get("name", "") or "").strip()
            candidate_type = str(member.get("agent_type", "") or "").strip()
            if candidate_name and candidate_type == "leader":
                leader_name = candidate_name
                break
    except Exception as exc:
        roster_unavailable = True
        logger.debug(f"[Team coordination] 读取 TeamConfig 失败，使用降级上下文: {exc}")

    role = _resolve_team_coordination_role(agent, members=members)
    task_list_path = _build_task_list_path(agent, team_name=team_name)
    config_path = str(team_cfg.path)
    inbox_path = str(inbox.path)
    role_rule_id = f"team_coordination_{role}"

    if role == "leader":
        prompt_id = "agent/team_coordination_leader.md"
        if roster_unavailable:
            team_roster_section = (
                "**Team Roster:**\n"
                "- (team roster unavailable)"
            )
        else:
            team_roster_section = f"**Teammates:**\n{member_lines}"
        reminder = render_prompt(
            load_prompt(prompt_id),
            variables={
                "TEAM_NAME": team_name,
                "AGENT_NAME": agent_name,
                "TEAM_ROSTER_SECTION": team_roster_section,
                "TEAM_RESOURCES": "\n".join(
                    [
                        f"- Task list: {task_list_path}",
                        f"- Team config: {config_path}"
                    ]
                ),
            },
            source=prompt_id,
        )
        return role_rule_id, reminder

    prompt_id = "agent/team_coordination_member.md"
    effective_leader_name = leader_name
    if roster_unavailable:
        effective_leader_name = "(team roster unavailable)"
    elif not effective_leader_name or effective_leader_name == agent_name:
        effective_leader_name = "(no leader registered yet)"

    reminder = render_prompt(
        load_prompt(prompt_id),
        variables={
            "TEAM_NAME": team_name,
            "AGENT_NAME": agent_name,
            "TEAM_CONFIG_PATH": config_path,
            "TASK_LIST_PATH": task_list_path,
            "LEADER_NAME": effective_leader_name,
        },
        source=prompt_id,
    )
    return role_rule_id, reminder


def _inject_team_coordination_context(agent: "AgentRuntime") -> None:
    role_rule_id, reminder = _build_team_coordination_reminder(agent)
    if not role_rule_id or not reminder:
        return
    if _has_live_reminder_rule(agent, role_rule_id):
        return

    coordination_role = "leader" if role_rule_id.endswith("_leader") else "member"
    agent.add_hidden_system_reminder(
        _wrap_runtime_coordination_reminder(reminder),
        metadata={
            "origin": "runtime_coordination",
            "coordination_kind": "team_coordination",
            "coordination_role": coordination_role,
            "reminder_rule_ids": [role_rule_id],
        },
    )


def _send_team_idle_notification(agent: "AgentRuntime") -> None:
    """D1: 主循环正常结束时，向 leader 发送 idle_notification。"""
    if not getattr(agent, "is_team_member", False):
        return
    if not bool(getattr(agent, "_is_subagent", False)):
        return
    if bool(getattr(agent, "_suppress_team_idle_notification", False)):
        return
    team_name = getattr(agent, "_team_name", "").strip()
    agent_name = resolve_runtime_team_agent_name(
        runtime_name=getattr(agent, "name", None),
        is_subagent=bool(getattr(agent, "_is_subagent", False)),
    )
    if not team_name or not agent_name:
        return
    try:
        from comate_agent_sdk.system_tools.team.config import TeamConfig
        from comate_agent_sdk.system_tools.team.inbox import Inbox, MessageType, get_all_inboxes

        # 发给 leader（第一个 agent_type="leader" 的成员，或全体广播）
        team_cfg = TeamConfig(team_name=team_name)
        leaders = [
            m["name"]
            for m in team_cfg.list_members()
            if m.get("agent_type") == "leader" and m["name"] != agent_name
        ]
        recipients = leaders or [
            name
            for name in get_all_inboxes(team_name)
            if name != agent_name
        ]
        for recipient in recipients:
            inbox = Inbox(team_name=team_name, agent_name=recipient)
            inbox.append_message(
                from_agent=agent_name,
                message_type=MessageType.IDLE_NOTIFICATION,
                content=f"Agent '{agent_name}' has ended its turn and is now idle.",
            )
        logger.debug(
            f"[Team] idle_notification 已发送: agent={agent_name!r} "
            f"recipients={recipients!r}"
        )
    except Exception as exc:
        logger.debug(f"[Team] 发送 idle_notification 失败（忽略）: {exc}")


def _send_team_shutdown_response(
    agent: "AgentRuntime",
    *,
    recipients: list[str],
    extra_content: str = "",
) -> None:
    """收到 shutdown_request 后，向请求方回复 shutdown_response。"""
    if not getattr(agent, "is_team_member", False):
        return
    team_name = getattr(agent, "_team_name", "").strip()
    agent_name = resolve_runtime_team_agent_name(
        runtime_name=getattr(agent, "name", None),
        is_subagent=bool(getattr(agent, "_is_subagent", False)),
    )
    normalized_recipients = [
        str(recipient).strip()
        for recipient in recipients
        if str(recipient).strip() and str(recipient).strip() != agent_name
    ]
    if not team_name or not agent_name or not normalized_recipients:
        return
    try:
        from comate_agent_sdk.system_tools.team.inbox import Inbox, MessageType

        message_content = f"Agent '{agent_name}' acknowledged shutdown and is stopping."
        normalized_extra_content = str(extra_content or "").strip()
        if normalized_extra_content:
            message_content = f"{message_content}\n\n{normalized_extra_content}"

        for recipient in normalized_recipients:
            inbox = Inbox(team_name=team_name, agent_name=recipient)
            inbox.append_message(
                from_agent=agent_name,
                message_type=MessageType.SHUTDOWN_RESPONSE,
                content=message_content,
            )
        logger.debug(
            f"[Team] shutdown_response 已发送: agent={agent_name!r} "
            f"recipients={normalized_recipients!r}"
        )
    except Exception as exc:
        logger.debug(f"[Team] 发送 shutdown_response 失败（忽略）: {exc}")


async def _run_stop_hook(agent: "AgentRuntime", stop_reason: str) -> bool:
    return await should_continue_after_stop_block(
        agent,
        stop_reason,
        drain_hidden_immediately=False,
    )


async def _iter_task_stream_events(
    agent: "AgentRuntime",
    tool_call: ToolCall,
    subagent_name: str,
    description: str,
    current_task_state: RunningTaskState | None,
    out: TaskStreamOut,
    *,
    check_interrupt: Callable[[], bool] | None = None,
) -> AsyncIterator[AgentEvent]:
    agent_tool = agent._tool_map.get("Agent")
    create_runtime_func = getattr(agent_tool, "_create_subagent_runtime", None)
    if create_runtime_func is None:
        out.tool_message = ToolMessage(
            tool_call_id=tool_call.id,
            tool_name="Agent",
            content="Error: Agent tool is not properly configured for streaming",
            is_error=True,
        )
        return

    try:
        parsed_args = json.loads(tool_call.function.arguments)
    except json.JSONDecodeError:
        parsed_args = {"_raw": tool_call.function.arguments}
    args = parsed_args if isinstance(parsed_args, dict) else {"_raw": tool_call.function.arguments}

    raw_subagent_type = args.get("subagent_type", "")
    subagent_type = raw_subagent_type if isinstance(raw_subagent_type, str) else str(raw_subagent_type)
    raw_prompt = args.get("prompt", "")
    prompt = raw_prompt if isinstance(raw_prompt, str) else str(raw_prompt)

    # 提取新参数（team_name / name / isolation），None 防御
    raw_team_name = args.get("team_name", "")
    if raw_team_name is None:
        raw_team_name = ""
    team_name = raw_team_name if isinstance(raw_team_name, str) else str(raw_team_name)
    raw_name_param = args.get("name", "")
    if raw_name_param is None:
        raw_name_param = ""
    name_param = raw_name_param if isinstance(raw_name_param, str) else str(raw_name_param)
    raw_isolation = args.get("isolation", "")
    if raw_isolation is None:
        raw_isolation = ""
    isolation = raw_isolation if isinstance(raw_isolation, str) else str(raw_isolation)

    subagent_runtime = None
    try:
        subagent_runtime, agent_def = await create_runtime_func(
            subagent_type,
            tool_call.id,
            team_name=team_name,
            name=name_param,
            isolation=isolation,
        )
        if current_task_state is not None:
            current_task_state.usage_tracking_mode = "stream"
            runtime_source_prefix = getattr(subagent_runtime, "_subagent_source_prefix", None)
            if isinstance(runtime_source_prefix, str) and runtime_source_prefix:
                current_task_state.source_prefix = runtime_source_prefix

        result_text = ""
        tool_call_times: dict[str, float] = {}
        timeout = agent_def.timeout if agent_def and agent_def.timeout else None
        timeout_ctx = asyncio.timeout(timeout) if timeout else nullcontext()

        async with timeout_ctx:
            async for event in subagent_runtime.query_stream(prompt):
                if check_interrupt and check_interrupt():
                    out.tool_message = ToolMessage(
                        tool_call_id=tool_call.id,
                        tool_name="Agent",
                        content=f"Error: Subagent '{subagent_name}' cancelled due to user interrupt",
                        is_error=True,
                    )
                    return

                if isinstance(event, UsageDeltaEvent):
                    if current_task_state is not None and _usage_belongs_to_task(event, current_task_state):
                        delta_tokens = _usage_delta_tokens_for_progress(event)
                        current_task_state.tokens += delta_tokens
                        elapsed_ms = (time.monotonic() - current_task_state.started_at_monotonic) * 1000
                        yield SubagentProgressEvent(
                            tool_call_id=tool_call.id,
                            subagent_name=subagent_name,
                            description=description,
                            status="running",
                            elapsed_ms=elapsed_ms,
                            tokens=current_task_state.tokens,
                        )
                    continue

                if isinstance(event, ToolCallEvent):
                    tool_call_times[event.tool_call_id] = time.time()
                    yield SubagentToolCallEvent(
                        parent_tool_call_id=tool_call.id,
                        subagent_name=subagent_name,
                        tool=event.tool,
                        args=event.args,
                        tool_call_id=event.tool_call_id,
                    )
                    continue

                if isinstance(event, ToolResultEvent):
                    start_time = tool_call_times.get(event.tool_call_id, time.time())
                    duration_ms = (time.time() - start_time) * 1000
                    yield SubagentToolResultEvent(
                        parent_tool_call_id=tool_call.id,
                        subagent_name=subagent_name,
                        tool=event.tool,
                        tool_call_id=event.tool_call_id,
                        is_error=event.is_error,
                        duration_ms=duration_ms,
                    )
                    continue

                if isinstance(event, TaskUpdatedEvent):
                    yield event  # 上抛到父事件流，让父侧 UI 实时感知任务状态变化
                    continue

                if isinstance(event, TextEvent):
                    result_text += event.content

        # Worktree 结果处理
        worktree_dir = getattr(subagent_runtime, "_worktree_dir", None)
        worktree_branch = getattr(subagent_runtime, "_worktree_branch", "")
        if worktree_dir is not None:
            from comate_agent_sdk.subagent.agent_tool import finalize_worktree

            result_text = finalize_worktree(
                result_text, worktree_dir, Path(agent.options.cwd), worktree_branch
            )

        out.tool_message = ToolMessage(
            tool_call_id=tool_call.id,
            tool_name="Agent",
            content=result_text or "(no output)",
            is_error=False,
        )
    except asyncio.TimeoutError:
        # 超时时清理 worktree
        _worktree_dir = getattr(subagent_runtime, "_worktree_dir", None) if subagent_runtime else None
        _worktree_branch = getattr(subagent_runtime, "_worktree_branch", "") if subagent_runtime else ""
        if _worktree_dir is not None:
            from comate_agent_sdk.subagent.agent_tool import _cleanup_worktree

            _cleanup_worktree(_worktree_dir, Path(agent.options.cwd), _worktree_branch)

        out.tool_message = ToolMessage(
            tool_call_id=tool_call.id,
            tool_name="Agent",
            content=f"Error: Subagent '{subagent_name}' timeout after {timeout}s",
            is_error=True,
        )
    except asyncio.CancelledError:
        raise
    except Exception as exc:
        # 异常时清理 worktree
        _worktree_dir = getattr(subagent_runtime, "_worktree_dir", None) if subagent_runtime else None
        _worktree_branch = getattr(subagent_runtime, "_worktree_branch", "") if subagent_runtime else ""
        if _worktree_dir is not None:
            from comate_agent_sdk.subagent.agent_tool import _cleanup_worktree

            _cleanup_worktree(_worktree_dir, Path(agent.options.cwd), _worktree_branch)

        error_msg = f"Error in subagent '{subagent_name}': {exc}"
        logger.error(error_msg, exc_info=True)
        out.tool_message = ToolMessage(
            tool_call_id=tool_call.id,
            tool_name="Agent",
            content=error_msg,
            is_error=True,
        )


async def _emit_policy_repair_events(
    agent: "AgentRuntime",
    *,
    tool_calls: list[ToolCall],
    task_lifecycle: TaskLifecycleEmitter,
    drain_hub: EventDrainHub,
) -> AsyncIterator[AgentEvent]:
    results_by_id: dict[str, ToolMessage] = {}
    for call in tool_calls:
        if is_ask_user_question(call):
            results_by_id[call.id] = policy_violation_message(
                call=call,
                code="ASKUSER_EXCLUSIVE",
                message="AskUserQuestion must be called alone in a single assistant tool_calls response.",
                required_fix="Retry now with ONLY AskUserQuestion. Run other tools after the user answer in the next turn.",
            )
        else:
            results_by_id[call.id] = policy_violation_message(
                call=call,
                code="ASKUSER_BLOCKED_BY_ASK",
                message="Blocked because AskUserQuestion was present in the same tool_calls response.",
                required_fix="Retry without mixing tools with AskUserQuestion.",
            )

    step_number = 0
    for call in tool_calls:
        step_number += 1
        tool_name = str(call.function.name or "").strip()
        try:
            args = json.loads(call.function.arguments)
        except json.JSONDecodeError:
            args = {"_raw": call.function.arguments}
        args_dict = _normalize_tool_call_event_args(
            agent,
            tool_name=tool_name,
            raw_args=args,
        )

        is_task = tool_name == "Agent"
        task_subagent_name = "Agent"
        task_description = tool_name
        if is_task:
            task_subagent_name, task_description, _ = _resolve_task_metadata(
                tool_call_id=call.id,
                args=args_dict,
            )

        yield StepStartEvent(
            step_id=call.id,
            title=task_description if is_task else tool_name,
            step_number=step_number,
        )
        yield ToolCallEvent(
            tool=tool_name,
            args=args_dict,
            tool_call_id=call.id,
            display_name=task_description if is_task else tool_name,
        )

        tool_result = results_by_id[call.id]
        if is_task:
            async for event in task_lifecycle.emit_start(
                tool_call_id=call.id,
                subagent_name=task_subagent_name,
                description=task_description,
            ):
                yield event
            async for event in task_lifecycle.emit_stop(
                tool_call_id=call.id,
                subagent_name=task_subagent_name,
                description=task_description,
                duration_ms=0.0,
                tokens=0,
                tool_result=tool_result,
            ):
                yield event

        yield ToolResultEvent(
            tool=tool_name,
            result=tool_result.text,
            tool_call_id=call.id,
            is_error=True,
            screenshot_base64=None,
        )
        yield StepCompleteEvent(
            step_id=call.id,
            status="error",
            duration_ms=0.0,
        )
        async for hidden_event in drain_hub.drain_hidden_events():
            yield hidden_event


async def run_query_stream(
    agent: "AgentRuntime",
    message: str | list[ContentPartTextParam | ContentPartImageParam] | ExternalTurnInput,
) -> AsyncIterator[AgentEvent]:
    """流式执行：发送消息并逐步产出事件。"""

    usage_poll_interval_seconds = 0.08
    engine_state = TurnEngineState()
    task_lifecycle = TaskLifecycleEmitter(agent)

    drain_hub = EventDrainHub(
        agent,
        usage_queue=engine_state.usage_queue,
        subagent_event_queue=engine_state.subagent_event_queue,
        running_tasks=engine_state.running_tasks,
        usage_tokens_for_progress=_usage_delta_tokens_for_progress,
        usage_belongs_to_task=_usage_belongs_to_task,
    )

    def _on_usage_entry(entry: "TokenUsageEntry") -> None:
        source = entry.source or "unknown"
        usage = entry.usage
        engine_state.usage_queue.put_nowait(
            UsageDeltaEvent(
                source=source,
                model=entry.model,
                level=entry.level,
                delta_prompt_tokens=int(usage.prompt_tokens),
                delta_prompt_cached_tokens=int(usage.prompt_cached_tokens or 0),
                delta_completion_tokens=int(usage.completion_tokens),
                delta_total_tokens=int(usage.total_tokens),
            )
        )

    async def _execute_task_streaming(
        tool_call: ToolCall,
        meta: tuple[str, str],
    ) -> ToolMessage:
        subagent_name, description = meta
        current_task_state = engine_state.running_tasks.get(tool_call.id)
        out = TaskStreamOut()
        async for event in _iter_task_stream_events(
            agent,
            tool_call,
            subagent_name,
            description,
            current_task_state,
            out,
            check_interrupt=lambda: _is_interrupt_requested(agent),
        ):
            engine_state.subagent_event_queue.put_nowait(event)
        return out.tool_message or ToolMessage(
            tool_call_id=tool_call.id,
            tool_name="Agent",
            content="Error: streaming task produced no result",
            is_error=True,
        )

    async def _yield_interrupted_stop() -> AsyncIterator[AgentEvent]:
        async for usage_event in drain_hub.drain_usage_events():
            yield usage_event
        async for hidden_event in drain_hub.drain_hidden_events():
            yield hidden_event
        yield StopEvent(reason="interrupted")

    async def _emit_cancelled_task(tool_call_id: str) -> AsyncIterator[AgentEvent]:
        state = engine_state.running_tasks.pop(tool_call_id, None)
        elapsed_ms = 0.0
        total_tokens = 0
        subagent_name = "Agent"
        description = "Agent"
        if state is not None:
            elapsed_ms = (time.monotonic() - state.started_at_monotonic) * 1000
            total_tokens = state.tokens
            subagent_name = state.subagent_name
            description = state.description
            async for event in task_lifecycle.emit_cancelled(
                tool_call_id=tool_call_id,
                subagent_name=subagent_name,
                description=description,
                elapsed_ms=elapsed_ms,
                tokens=total_tokens,
            ):
                yield event
            async for hidden_event in drain_hub.drain_hidden_events():
                yield hidden_event

        yield StepCompleteEvent(
            step_id=tool_call_id,
            status="cancelled",
            duration_ms=elapsed_ms,
        )

    usage_observer_id = agent._token_cost.subscribe_usage(_on_usage_entry)
    tool_call_interceptor = ToolCallInterceptor()

    try:
        mode_snapshot = agent.get_mode()
        agent._active_mode_snapshot = mode_snapshot
        agent._context.set_plan_mode(mode_snapshot == "plan")
        if mode_snapshot == "plan":
            agent._context.mark_plan_mode_used()  # 标记此 turn 在 plan mode 下发生
            plan_prompt = _render_plan_mode_prompt(
                str(agent.options.plan_mode_prompt_template or ""),
                active_plan_path=agent.get_active_plan_path(),
            )
            if plan_prompt:
                agent.add_hidden_system_reminder(
                    plan_prompt,
                    metadata={
                        "origin": "system_reminder",
                        "reminder_rule_ids": ["plan_mode_prompt"],
                        "reminder_tools": ["PlanMode"],
                    },
                )

        await _fire_session_start_if_needed(agent)
        agent.reset_stop_hook_state()
        async for hidden_event in drain_hub.drain_hidden_events():
            yield hidden_event

        if isinstance(message, ExternalTurnInput):
            turn_sources: deque[TurnSource] = deque(
                [
                    TurnSource(
                        kind="team_inbox",
                        content=build_team_inbox_turn_text(message.turn),
                    )
                ]
            )
        else:
            turn_sources = deque([TurnSource(kind="user", content=message)])
        legacy_inbox_poll_enabled = not bool(
            getattr(agent, "_chat_session_disable_legacy_inbox_poll", False)
        )

        while turn_sources:
            next_turn_source = turn_sources[0]
            if legacy_inbox_poll_enabled and next_turn_source.kind == "user":
                await _poll_runtime_team_inbox(agent)
            if legacy_inbox_poll_enabled and _has_buffered_shutdown_request(agent):
                shutdown_requesters, _ = _consume_buffered_inbox_control_or_turn_source(agent)
                if shutdown_requesters:
                    _send_team_shutdown_response(agent, recipients=shutdown_requesters)
                    async for hidden_event in drain_hub.drain_hidden_events():
                        yield hidden_event
                    yield StopEvent(reason="shutdown_request")
                    return

            turn_source = turn_sources.popleft()
            if turn_source.kind == "team_inbox":
                agent._context.add_message(
                    UserMessage(
                        content=str(turn_source.content),
                        is_meta=True,
                    ),
                    item_type=ItemType.TEAM_INBOX_TURN,
                    metadata={
                        "origin": "team_inbox_auto_turn",
                        "turn_source": "team_inbox",
                        "message_count": len(turn_source.inbox_event_keys),
                    },
                )
            else:
                agent._context.add_message(UserMessage(content=turn_source.content))
                await _fire_user_prompt_submit(agent, turn_source.content)
            async for hidden_event in drain_hub.drain_hidden_events():
                yield hidden_event

            iterations = 0
            askuser_repair_attempted = False

            while True:
                if iterations >= agent.options.max_iterations:
                    summary = await generate_max_iterations_summary(agent)
                    async for usage_event in drain_hub.drain_usage_events():
                        yield usage_event
                    yield TextEvent(content=summary)
                    if await _run_stop_hook(agent, "max_iterations"):
                        async for hidden_event in drain_hub.drain_hidden_events():
                            yield hidden_event
                        iterations = max(0, agent.options.max_iterations - 1)
                        continue
                    async for hidden_event in drain_hub.drain_hidden_events():
                        yield hidden_event
                    yield StopEvent(reason="max_iterations")
                    return

                if _is_interrupt_requested(agent):
                    async for event in _yield_interrupted_stop():
                        yield event
                    return

                iterations += 1
                destroy_ephemeral_messages(agent)

                compacted, compaction_result_event, precheck_meta_events = await precheck_and_compact(agent)
                async for usage_event in drain_hub.drain_usage_events():
                    yield usage_event
                if compaction_result_event:
                    yield compaction_result_event
                for compaction_meta_event in precheck_meta_events:
                    yield compaction_meta_event
                if compacted:
                    iterations = 0

                # Team runtime coordination context 必须在 precheck_and_compact() 之后注入，
                # 否则本轮若触发压缩会被 purge_system_reminders() 清掉。
                _inject_team_coordination_context(agent)
                async for hidden_event in drain_hub.drain_hidden_events():
                    yield hidden_event

                llm_task = asyncio.create_task(invoke_llm(agent))
                while True:
                    async for usage_event in drain_hub.drain_usage_events():
                        yield usage_event
                    if _is_interrupt_requested(agent):
                        llm_task.cancel()
                        with suppress(asyncio.CancelledError):
                            await llm_task
                        async for event in _yield_interrupted_stop():
                            yield event
                        return
                    done, _ = await asyncio.wait(
                        {llm_task},
                        timeout=usage_poll_interval_seconds,
                        return_when=asyncio.ALL_COMPLETED,
                    )
                    async for usage_event in drain_hub.drain_usage_events():
                        yield usage_event
                    if done:
                        break

                response = await llm_task
                async for usage_event in drain_hub.drain_usage_events():
                    yield usage_event

                if response.thinking:
                    yield ThinkingEvent(content=response.thinking)

                if _is_interrupt_requested(agent):
                    async for event in _yield_interrupted_stop():
                        yield event
                    return

                if not response.has_tool_calls:
                    assistant_msg = AssistantMessage(
                        content=response.raw_content_blocks or response.content,
                        tool_calls=None,
                    )
                    agent._context.add_message(assistant_msg)
                    compacted, compaction_result_event, compaction_meta_events = await check_and_compact(agent, response)
                    async for usage_event in drain_hub.drain_usage_events():
                        yield usage_event
                    if compaction_result_event:
                        yield compaction_result_event
                    for compaction_meta_event in compaction_meta_events:
                        yield compaction_meta_event
                    if compacted:
                        iterations = 0
                    if response.content:
                        yield TextEvent(content=response.content)
                    if await _run_stop_hook(agent, "completed"):
                        async for hidden_event in drain_hub.drain_hidden_events():
                            yield hidden_event
                        continue
                    async for hidden_event in drain_hub.drain_hidden_events():
                        yield hidden_event
                    if legacy_inbox_poll_enabled and turn_source.inbox_event_keys:
                        ack_pending = getattr(agent, "ack_pending_inbox_events", None)
                        if callable(ack_pending):
                            ack_pending(turn_source.inbox_event_keys)
                    if legacy_inbox_poll_enabled:
                        await _poll_runtime_team_inbox(agent)
                        shutdown_requesters, continuation = _consume_buffered_inbox_control_or_turn_source(agent)
                        if shutdown_requesters:
                            _send_team_shutdown_response(agent, recipients=shutdown_requesters)
                            yield StopEvent(reason="shutdown_request")
                            return
                        if continuation is not None:
                            _notify_chat_session_turn_complete(agent)
                            turn_sources.append(continuation)
                            break
                    # D1: Team 模式 — 发送 idle_notification 给 leader
                    _send_team_idle_notification(agent)
                    yield StopEvent(reason="completed")
                    return

                if response.content:
                    yield TextEvent(content=response.content)

                tool_calls = list(response.tool_calls or [])
                assistant_msg = AssistantMessage(
                    content=response.raw_content_blocks or response.content,
                    tool_calls=tool_calls,
                )

                ask_policy = await enforce_ask_user_exclusive_policy(
                    agent,
                    assistant_message=assistant_msg,
                    tool_calls=tool_calls,
                    askuser_repair_attempted=askuser_repair_attempted,
                )
                askuser_repair_attempted = ask_policy.askuser_repair_attempted

                if ask_policy.repaired:
                    async for event in _emit_policy_repair_events(
                        agent,
                        tool_calls=tool_calls,
                        task_lifecycle=task_lifecycle,
                        drain_hub=drain_hub,
                    ):
                        yield event
                    async for hidden_event in drain_hub.drain_hidden_events():
                        yield hidden_event
                    continue

                tool_calls = ask_policy.tool_calls
                assistant_msg = AssistantMessage(
                    content=response.raw_content_blocks or response.content,
                    tool_calls=tool_calls,
                )

                intercept_result = tool_call_interceptor.intercept(
                    assistant_message=assistant_msg,
                    tool_calls=tool_calls,
                )
                tool_calls = intercept_result.tool_calls
                assistant_msg = intercept_result.assistant_message
                tool_call_diagnostics_by_id: dict[str, dict[str, object]] = {}
                if tool_calls and intercept_result.dropped_calls and is_yield_turn(tool_calls[0]):
                    dropped_calls = [
                        {
                            "tool_call_id": str(call.id or "").strip(),
                            "tool_name": str(call.function.name or "").strip(),
                        }
                        for call in intercept_result.dropped_calls
                    ]
                    tool_call_diagnostics_by_id[tool_calls[0].id] = {
                        "reason": "yield_turn_preempted_batch",
                        "dropped_calls": dropped_calls,
                    }
                    logger.info(
                        "YieldTurn intercepted mixed tool-call batch; dropped %d call(s)",
                        len(dropped_calls),
                    )

                expected_ids = [call.id for call in tool_calls if str(call.id).strip()]
                agent._context.begin_tool_barrier(expected_ids)

                engine_state.stop_reason = None
                async def _before_terminal_stop(reason: str) -> None:
                    if reason == "yielded":
                        _send_team_idle_notification(agent)

                async for event in execute_tool_calls(
                    agent,
                    assistant_msg=assistant_msg,
                    tool_calls=tool_calls,
                    engine_state=engine_state,
                    usage_poll_interval_seconds=usage_poll_interval_seconds,
                    task_lifecycle=task_lifecycle,
                    is_interrupt_requested=lambda: _is_interrupt_requested(agent),
                    run_stop_hook=lambda reason: _run_stop_hook(agent, reason),
                    normalize_tool_call_event_args=lambda tool_name, raw_args: _normalize_tool_call_event_args(
                        agent,
                        tool_name=tool_name,
                        raw_args=raw_args,
                    ),
                    resolve_task_metadata=lambda tool_call_id, args: _resolve_task_metadata(
                        tool_call_id=tool_call_id,
                        args=args,
                    ),
                    execute_task_streaming=_execute_task_streaming,
                    drain_usage_events=drain_hub.drain_usage_events,
                    drain_hidden_events=drain_hub.drain_hidden_events,
                    drain_subagent_events=drain_hub.drain_subagent_events,
                    emit_cancelled_task=_emit_cancelled_task,
                    yield_interrupted_stop=_yield_interrupted_stop,
                    before_terminal_stop=_before_terminal_stop,
                    tool_call_diagnostics_by_id=tool_call_diagnostics_by_id,
                ):
                    yield event

                if engine_state.stop_reason:
                    return

                compacted, compaction_result_event, compaction_meta_events = await check_and_compact(agent, response)
                async for usage_event in drain_hub.drain_usage_events():
                    yield usage_event
                if compaction_result_event:
                    yield compaction_result_event
                for compaction_meta_event in compaction_meta_events:
                    yield compaction_meta_event
                if compacted:
                    iterations = 0

    finally:
        agent._active_mode_snapshot = None
        agent._context.set_plan_mode(agent.get_mode() == "plan")
        agent._token_cost.unsubscribe_usage(usage_observer_id)
