from __future__ import annotations

import asyncio
import json
import logging
import time
from collections.abc import AsyncIterator, Awaitable, Callable
from contextlib import suppress
from pathlib import Path
from typing import TYPE_CHECKING, Any

from comate_agent_sdk.agent.events import (
    AgentEvent,
    PlanApprovalRequiredEvent,
    StepCompleteEvent,
    StepStartEvent,
    StopEvent,
    TaskUpdatedEvent,
    ToolCallEvent,
    ToolResultEvent,
    UserQuestionEvent,
)
from comate_agent_sdk.agent.tool_exec import execute_tool_call, extract_screenshot
from comate_agent_sdk.llm.messages import ToolCall, ToolMessage

from .state import RunningTaskState, TurnEngineState
from .task_lifecycle import TaskLifecycleEmitter
from .tool_messages import make_cancelled_tool_message
from .txn_commit import ToolTxnCommitter
from ..projection.tool_result_projection import (
    extract_diff_metadata,
    extract_plan_approval,
    extract_questions,
    extract_task_snapshot,
)

if TYPE_CHECKING:
    from comate_agent_sdk.agent.core import AgentRuntime

logger = logging.getLogger(__name__)


def _parse_tool_call_args(tool_call: ToolCall) -> dict:
    try:
        args = json.loads(tool_call.function.arguments)
    except json.JSONDecodeError:
        return {"_raw": tool_call.function.arguments}
    return args if isinstance(args, dict) else {"_raw": tool_call.function.arguments}


def _is_team_session_agent_args(args: dict) -> bool:
    team_name = args.get("team_name", "")
    if team_name is None:
        return False
    return bool(str(team_name).strip())


def _is_policy_denied(tool_result: ToolMessage) -> bool:
    payload = tool_result.raw_envelope
    if not isinstance(payload, dict):
        return False
    error = payload.get("error")
    if not isinstance(error, dict):
        return False
    return str(error.get("code", "") or "").strip() == "POLICY_DENIED"


def _attach_interceptor_metadata(
    tool_result: ToolMessage,
    interceptor_metadata: dict[str, Any] | None,
) -> None:
    if not interceptor_metadata:
        return
    payload = tool_result.raw_envelope
    if isinstance(payload, dict):
        meta = payload.get("meta")
        if not isinstance(meta, dict):
            meta = {}
            payload["meta"] = meta
        meta["interceptor"] = dict(interceptor_metadata)

    execution_meta = dict(tool_result.execution_meta or {})
    execution_meta["interceptor"] = dict(interceptor_metadata)
    tool_result.execution_meta = execution_meta


async def execute_tool_calls(
    agent: "AgentRuntime",
    *,
    assistant_msg,
    tool_calls: list[ToolCall],
    engine_state: TurnEngineState,
    usage_poll_interval_seconds: float,
    task_lifecycle: TaskLifecycleEmitter,
    is_interrupt_requested: Callable[[], bool],
    run_stop_hook: Callable[[str], Awaitable[bool]],
    normalize_tool_call_event_args: Callable[[str, object], dict],
    resolve_task_metadata: Callable[[str, dict], tuple[str, str, str]],
    execute_task_streaming: Callable[[ToolCall, tuple[str, str]], Awaitable[ToolMessage]],
    drain_usage_events: Callable[[], AsyncIterator[AgentEvent]],
    drain_hidden_events: Callable[[], AsyncIterator[AgentEvent]],
    drain_subagent_events: Callable[[], AsyncIterator[AgentEvent]],
    emit_cancelled_task: Callable[[str], AsyncIterator[AgentEvent]],
    yield_interrupted_stop: Callable[[], AsyncIterator[AgentEvent]],
    before_terminal_stop: Callable[[str], Awaitable[None]],
    tool_call_diagnostics_by_id: dict[str, dict[str, Any]] | None = None,
) -> AsyncIterator[AgentEvent]:
    results_by_id: dict[str, ToolMessage] = {}
    committer = ToolTxnCommitter(agent, assistant_message=assistant_msg, tool_calls=tool_calls)
    diagnostics_by_id = tool_call_diagnostics_by_id or {}

    step_number = 0
    idx = 0
    while idx < len(tool_calls):
        if is_interrupt_requested():
            for call in tool_calls[idx:]:
                results_by_id[call.id] = make_cancelled_tool_message(call)
            if await committer.commit_if_needed(results_by_id):
                async for hidden_event in drain_hidden_events():
                    yield hidden_event
            engine_state.stop_reason = "interrupted"
            async for event in yield_interrupted_stop():
                yield event
            return

        tool_call = tool_calls[idx]
        tool_name = tool_call.function.name

        raw_args = _parse_tool_call_args(tool_call)
        normalized_args = normalize_tool_call_event_args(str(tool_name or ""), raw_args)

        if (
            agent.options.task_parallel_enabled
            and tool_name == "Agent"
            and not _is_team_session_agent_args(normalized_args)
        ):
            group: list[ToolCall] = []
            args_by_id: dict[str, dict] = {}
            meta_by_id: dict[str, tuple[str, str]] = {}

            scan_idx = idx
            while scan_idx < len(tool_calls) and tool_calls[scan_idx].function.name == "Agent":
                task_call = tool_calls[scan_idx]
                task_raw_args = _parse_tool_call_args(task_call)
                task_args = normalize_tool_call_event_args("Agent", task_raw_args)
                if _is_team_session_agent_args(task_args):
                    break
                group.append(task_call)
                args_by_id[task_call.id] = task_args
                scan_idx += 1

            idx = scan_idx

            for task_call in group:
                step_number += 1
                task_args = args_by_id[task_call.id]

                subagent_name, description, source_prefix = resolve_task_metadata(
                    task_call.id,
                    task_args,
                )
                meta_by_id[task_call.id] = (subagent_name, description)
                engine_state.running_tasks[task_call.id] = RunningTaskState(
                    tool_call_id=task_call.id,
                    subagent_name=subagent_name,
                    description=description,
                    source_prefix=source_prefix,
                    started_at_monotonic=time.monotonic(),
                )

                yield StepStartEvent(
                    step_id=task_call.id,
                    title=description,
                    step_number=step_number,
                )
                yield ToolCallEvent(
                    tool="Agent",
                    args=task_args,
                    tool_call_id=task_call.id,
                    display_name=description,
                )
                async for event in task_lifecycle.emit_start(
                    tool_call_id=task_call.id,
                    subagent_name=subagent_name,
                    description=description,
                ):
                    yield event
                async for hidden_event in drain_hidden_events():
                    yield hidden_event

            semaphore = asyncio.Semaphore(max(1, int(agent.options.task_parallel_max_concurrency)))
            agent_tool = agent._tool_map.get("Agent")
            is_streaming = getattr(agent_tool, "_is_streaming_task", False)

            async def _run(task_call: ToolCall) -> tuple[ToolCall, ToolMessage, float]:
                start = time.time()
                async with semaphore:
                    if is_streaming:
                        tool_result = await execute_task_streaming(task_call, meta_by_id[task_call.id])
                    else:
                        tool_result = await execute_tool_call(agent, task_call)
                duration_ms = (time.time() - start) * 1000
                return task_call, tool_result, duration_ms

            futures = [asyncio.create_task(_run(task_call)) for task_call in group]
            pending = set(futures)
            group_results_by_id: dict[str, ToolMessage] = {}

            while pending:
                async for usage_event in drain_usage_events():
                    yield usage_event
                async for subagent_event in drain_subagent_events():
                    yield subagent_event

                if is_interrupt_requested():
                    for future in pending:
                        future.cancel()
                    await asyncio.gather(*pending, return_exceptions=True)

                    completed_ids = set(group_results_by_id.keys())
                    for task_call in group:
                        if task_call.id in completed_ids:
                            continue
                        cancelled = make_cancelled_tool_message(task_call)
                        group_results_by_id[task_call.id] = cancelled
                        async for event in emit_cancelled_task(task_call.id):
                            yield event

                    for task_call in group:
                        results_by_id[task_call.id] = group_results_by_id[task_call.id]
                    for call in tool_calls[idx:]:
                        results_by_id[call.id] = make_cancelled_tool_message(call)

                    if await committer.commit_if_needed(results_by_id):
                        async for hidden_event in drain_hidden_events():
                            yield hidden_event
                    engine_state.stop_reason = "interrupted"
                    async for event in yield_interrupted_stop():
                        yield event
                    return

                done, pending = await asyncio.wait(
                    pending,
                    timeout=usage_poll_interval_seconds,
                    return_when=asyncio.FIRST_COMPLETED,
                )

                async for usage_event in drain_usage_events():
                    yield usage_event
                async for subagent_event in drain_subagent_events():
                    yield subagent_event

                if not done:
                    continue

                for future in done:
                    task_call, tool_result, duration_ms = await future
                    subagent_name, description = meta_by_id.get(task_call.id, ("Agent", "Agent"))

                    state = engine_state.running_tasks.pop(task_call.id, None)
                    total_tokens = state.tokens if state is not None else 0

                    async for event in task_lifecycle.emit_stop(
                        tool_call_id=task_call.id,
                        subagent_name=subagent_name,
                        description=description,
                        duration_ms=duration_ms,
                        tokens=total_tokens,
                        tool_result=tool_result,
                    ):
                        yield event

                    screenshot_base64 = extract_screenshot(tool_result)
                    yield ToolResultEvent(
                        tool="Agent",
                        result=tool_result.text,
                        tool_call_id=task_call.id,
                        is_error=tool_result.is_error,
                        screenshot_base64=screenshot_base64,
                    )
                    yield StepCompleteEvent(
                        step_id=task_call.id,
                        status="error" if tool_result.is_error else "completed",
                        duration_ms=duration_ms,
                    )
                    async for hidden_event in drain_hidden_events():
                        yield hidden_event

                    group_results_by_id[task_call.id] = tool_result

            for task_call in group:
                results_by_id[task_call.id] = group_results_by_id[task_call.id]
            continue

        step_number += 1
        args_dict = normalized_args

        is_task = tool_name == "Agent"
        is_team_session_task = is_task and _is_team_session_agent_args(args_dict)
        is_task_stream = False
        if is_task and not is_team_session_task:
            agent_tool = agent._tool_map.get("Agent")
            is_task_stream = getattr(agent_tool, "_is_streaming_task", False)

        task_subagent_name = "Agent"
        task_description = str(tool_name or "")
        if is_task:
            task_subagent_name, task_description, task_source_prefix = resolve_task_metadata(
                tool_call.id,
                args_dict,
            )
        else:
            task_source_prefix = ""

        yield StepStartEvent(
            step_id=tool_call.id,
            title=task_description if is_task else str(tool_name),
            step_number=step_number,
        )
        yield ToolCallEvent(
            tool=str(tool_name),
            args=args_dict,
            tool_call_id=tool_call.id,
            display_name=task_description if is_task else str(tool_name),
        )

        if is_task and not is_team_session_task:
            engine_state.running_tasks[tool_call.id] = RunningTaskState(
                tool_call_id=tool_call.id,
                subagent_name=task_subagent_name,
                description=task_description,
                source_prefix=task_source_prefix,
                started_at_monotonic=time.monotonic(),
            )
            async for event in task_lifecycle.emit_start(
                tool_call_id=tool_call.id,
                subagent_name=task_subagent_name,
                description=task_description,
            ):
                yield event
            async for hidden_event in drain_hidden_events():
                yield hidden_event

        step_start_time = time.time()

        if is_task_stream:
            stream_task = asyncio.create_task(
                execute_task_streaming(
                    tool_call,
                    (task_subagent_name, task_description),
                )
            )
            while True:
                async for usage_event in drain_usage_events():
                    yield usage_event
                async for subagent_event in drain_subagent_events():
                    yield subagent_event

                if is_interrupt_requested():
                    stream_task.cancel()
                    with suppress(asyncio.CancelledError):
                        await stream_task

                    step_duration_ms = (time.time() - step_start_time) * 1000
                    cancelled_result = make_cancelled_tool_message(tool_call)
                    results_by_id[tool_call.id] = cancelled_result
                    async for event in emit_cancelled_task(tool_call.id):
                        yield event

                    for call in tool_calls[idx + 1 :]:
                        results_by_id[call.id] = make_cancelled_tool_message(call)

                    if await committer.commit_if_needed(results_by_id):
                        async for hidden_event in drain_hidden_events():
                            yield hidden_event

                    engine_state.stop_reason = "interrupted"
                    async for event in yield_interrupted_stop():
                        yield event
                    return

                done, _ = await asyncio.wait(
                    {stream_task},
                    timeout=usage_poll_interval_seconds,
                    return_when=asyncio.ALL_COMPLETED,
                )
                async for usage_event in drain_usage_events():
                    yield usage_event
                async for subagent_event in drain_subagent_events():
                    yield subagent_event
                if done:
                    break

            tool_result = await stream_task
        else:
            tool_result_task = asyncio.create_task(execute_tool_call(agent, tool_call))
            while True:
                async for usage_event in drain_usage_events():
                    yield usage_event

                if is_interrupt_requested():
                    tool_result_task.cancel()
                    with suppress(asyncio.CancelledError):
                        await tool_result_task

                    step_duration_ms = (time.time() - step_start_time) * 1000
                    if is_task and not is_team_session_task:
                        cancelled_result = make_cancelled_tool_message(tool_call)
                        results_by_id[tool_call.id] = cancelled_result
                        async for event in emit_cancelled_task(tool_call.id):
                            yield event
                    else:
                        yield StepCompleteEvent(
                            step_id=tool_call.id,
                            status="cancelled",
                            duration_ms=step_duration_ms,
                        )
                        results_by_id[tool_call.id] = make_cancelled_tool_message(tool_call)

                    for call in tool_calls[idx + 1 :]:
                        results_by_id[call.id] = make_cancelled_tool_message(call)

                    if await committer.commit_if_needed(results_by_id):
                        async for hidden_event in drain_hidden_events():
                            yield hidden_event

                    engine_state.stop_reason = "interrupted"
                    async for event in yield_interrupted_stop():
                        yield event
                    return

                done, _ = await asyncio.wait(
                    {tool_result_task},
                    timeout=usage_poll_interval_seconds,
                    return_when=asyncio.ALL_COMPLETED,
                )
                async for usage_event in drain_usage_events():
                    yield usage_event
                if done:
                    break

            tool_result = await tool_result_task

        step_duration_ms = (time.time() - step_start_time) * 1000
        _attach_interceptor_metadata(tool_result, diagnostics_by_id.get(tool_call.id))
        results_by_id[tool_call.id] = tool_result
        async for hidden_event in drain_hidden_events():
            yield hidden_event

        if is_task and not is_team_session_task:
            state = engine_state.running_tasks.pop(tool_call.id, None)
            total_tokens = state.tokens if state is not None else 0
            async for event in task_lifecycle.emit_stop(
                tool_call_id=tool_call.id,
                subagent_name=task_subagent_name,
                description=task_description,
                duration_ms=step_duration_ms,
                tokens=total_tokens,
                tool_result=tool_result,
            ):
                yield event

        screenshot_base64 = extract_screenshot(tool_result)
        diff_metadata = extract_diff_metadata(str(tool_name or ""), tool_result)
        interceptor_metadata = diagnostics_by_id.get(tool_call.id)
        merged_metadata = diff_metadata.copy() if isinstance(diff_metadata, dict) else {}
        if interceptor_metadata:
            merged_metadata["interceptor"] = dict(interceptor_metadata)
        yield ToolResultEvent(
            tool=str(tool_name),
            result=tool_result.text,
            tool_call_id=tool_call.id,
            is_error=tool_result.is_error,
            screenshot_base64=screenshot_base64,
            metadata=merged_metadata or None,
        )
        yield StepCompleteEvent(
            step_id=tool_call.id,
            status="error" if tool_result.is_error else "completed",
            duration_ms=step_duration_ms,
        )
        async for hidden_event in drain_hidden_events():
            yield hidden_event

        if _is_policy_denied(tool_result):
            executed_calls = tool_calls[: idx + 1]
            committer.retain_calls(executed_calls)
            if await committer.commit_if_needed(results_by_id):
                async for hidden_event in drain_hidden_events():
                    yield hidden_event
            async for usage_event in drain_usage_events():
                yield usage_event
            logger.info(
                "Stopped tool-call batch after POLICY_DENIED from %s; skipped %d remaining call(s)",
                tool_name,
                max(len(tool_calls) - idx - 1, 0),
            )
            return

        task_snapshot = extract_task_snapshot(str(tool_name), tool_result)
        if task_snapshot is not None:
            list_id, tasks = task_snapshot
            yield TaskUpdatedEvent(list_id=list_id, tasks=tasks)

        if str(tool_name) == "AskUserQuestion" and not tool_result.is_error:
            questions = extract_questions(tool_result)
            if questions:
                yield UserQuestionEvent(
                    questions=questions,
                    tool_call_id=tool_call.id,
                )
                if await committer.commit_if_needed(results_by_id):
                    async for hidden_event in drain_hidden_events():
                        yield hidden_event
                async for usage_event in drain_usage_events():
                    yield usage_event
                if await run_stop_hook("waiting_for_input"):
                    async for hidden_event in drain_hidden_events():
                        yield hidden_event
                    idx += 1
                    continue
                async for hidden_event in drain_hidden_events():
                    yield hidden_event
                yield StopEvent(reason="waiting_for_input")
                engine_state.stop_reason = "waiting_for_input"
                return

        if str(tool_name) == "ExitPlanMode" and not tool_result.is_error:
            plan_approval = extract_plan_approval(tool_result)
            if plan_approval is not None:
                plan_path = plan_approval["plan_path"]
                plan_markdown = ""
                try:
                    plan_markdown = Path(plan_path).read_text(encoding="utf-8")
                except Exception as exc:
                    logger.warning("ExitPlanMode: 无法读取计划文件 %s: %s", plan_path, exc)
                agent.arm_plan_approval(
                    plan_path=plan_path,
                    summary=plan_approval["summary"],
                    execution_prompt=plan_approval["execution_prompt"],
                )
                if await committer.commit_if_needed(results_by_id):
                    async for hidden_event in drain_hidden_events():
                        yield hidden_event
                async for usage_event in drain_usage_events():
                    yield usage_event
                budget_status = agent._context.get_budget_status()
                utilization_pct = int(budget_status.utilization_ratio * 100)
                yield PlanApprovalRequiredEvent(
                    plan_path=plan_path,
                    summary=plan_approval["summary"],
                    execution_prompt=plan_approval["execution_prompt"],
                    plan_markdown=plan_markdown,
                    context_utilization_pct=utilization_pct,
                )
                if await run_stop_hook("waiting_for_plan_approval"):
                    async for hidden_event in drain_hidden_events():
                        yield hidden_event
                    idx += 1
                    continue
                async for hidden_event in drain_hidden_events():
                    yield hidden_event
                yield StopEvent(reason="waiting_for_plan_approval")
                engine_state.stop_reason = "waiting_for_plan_approval"
                return

        if str(tool_name) == "YieldTurn" and not tool_result.is_error:
            if await committer.commit_if_needed(results_by_id):
                async for hidden_event in drain_hidden_events():
                    yield hidden_event
            async for usage_event in drain_usage_events():
                yield usage_event
            await before_terminal_stop("yielded")
            async for hidden_event in drain_hidden_events():
                yield hidden_event
            yield StopEvent(reason="yielded")
            engine_state.stop_reason = "yielded"
            return

        if is_interrupt_requested():
            for call in tool_calls[idx + 1 :]:
                results_by_id[call.id] = make_cancelled_tool_message(call)
            if await committer.commit_if_needed(results_by_id):
                async for hidden_event in drain_hidden_events():
                    yield hidden_event
            engine_state.stop_reason = "interrupted"
            async for event in yield_interrupted_stop():
                yield event
            return

        idx += 1

    if await committer.commit_if_needed(results_by_id):
        async for hidden_event in drain_hidden_events():
            yield hidden_event
