from __future__ import annotations

import asyncio
import logging
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from typing import Any, Literal

logger = logging.getLogger(__name__)

from comate_agent_sdk.agent.compaction import CompactionService
from comate_agent_sdk.agent.external_turns import (
    build_team_inbox_batch_external_turn,
    build_team_inbox_external_turn,
)
from comate_agent_sdk.agent.llm_levels import LLMLevel
from comate_agent_sdk.agent.options import RuntimeAgentOptions
from comate_agent_sdk.agent.plan_artifact import build_plan_artifact_path
from comate_agent_sdk.context import ContextIR
from comate_agent_sdk.context.fs import ContextFileSystem
from comate_agent_sdk.context.usage_tracker import ContextUsageTracker
from comate_agent_sdk.llm.base import BaseChatModel
from comate_agent_sdk.llm.messages import ContentPartImageParam, ContentPartTextParam, ToolCall, ToolMessage
from comate_agent_sdk.system_tools.team.identity import resolve_runtime_team_agent_name
from comate_agent_sdk.system_tools.team.inbox_transport import TeamInboxEnvelope, TeamInboxTransport
from comate_agent_sdk.system_tools.team.polling import (
    DEFAULT_TEAM_POLL_INTERVAL_SECONDS,
    resolve_team_poll_interval_seconds,
)
from comate_agent_sdk.tokens import TokenCost
from comate_agent_sdk.tools.decorator import Tool

from .runtime_context import RuntimeContextMixin
from .runtime_hooks import RuntimeHooksMixin
from .runtime_mcp import RuntimeMcpMixin


@dataclass
class AgentRuntime(
    RuntimeContextMixin,
    RuntimeHooksMixin,
    RuntimeMcpMixin,
):
    """运行态 Agent（会话/任务独占，可变）。"""

    llm: BaseChatModel | None = None
    level: LLMLevel | None = None
    options: RuntimeAgentOptions = field(default_factory=RuntimeAgentOptions)
    name: str | None = None
    template: "AgentTemplate | None" = field(default=None, repr=False)
    header_snapshot: dict[str, Any] | None = field(default=None, repr=False)
    _is_subagent: bool = field(default=False, repr=False)
    _parent_token_cost: TokenCost | None = field(default=None, repr=False)
    _subagent_run_id: str | None = field(default=None, repr=False)
    _subagent_source_prefix: str | None = field(default=None, repr=False, init=False)

    _context: ContextIR = field(default=None, repr=False, init=False)  # type: ignore[assignment]
    _task_store: Any | None = field(default=None, repr=False, init=False)
    _tool_map: dict[str, Tool] = field(default_factory=dict, repr=False, init=False)
    _compaction_service: CompactionService | None = field(default=None, repr=False, init=False)
    _token_cost: TokenCost = field(default=None, repr=False, init=False)  # type: ignore[assignment]
    _context_usage_tracker: ContextUsageTracker = field(default=None, repr=False, init=False)  # type: ignore[assignment]
    _context_fs: ContextFileSystem | None = field(default=None, repr=False, init=False)
    _session_id: str = field(default="", repr=False, init=False)
    _task_namespace: str = field(default="", repr=False, init=False)
    _team_name: str = field(default="", repr=False, init=False)
    _run_controller: "SessionRunController | None" = field(default=None, repr=False, init=False)
    _hook_engine: Any | None = field(default=None, repr=False, init=False)
    _pending_hidden_user_messages: list[str] = field(default_factory=list, repr=False, init=False)
    _hooks_session_started: bool = field(default=False, repr=False, init=False)
    _hooks_session_ended: bool = field(default=False, repr=False, init=False)
    _stop_hook_block_count: int = field(default=0, repr=False, init=False)
    _stop_hook_block_limit: int = field(default=3, repr=False, init=False)

    _mcp_manager: Any | None = field(default=None, repr=False, init=False)
    _mcp_loaded: bool = field(default=False, repr=False, init=False)
    _mcp_dirty: bool = field(default=False, repr=False, init=False)
    _mcp_pending_tool_names: list[str] = field(default_factory=list, repr=False, init=False)
    _mcp_load_lock: asyncio.Lock = field(default_factory=asyncio.Lock, repr=False, init=False)
    _lock_header_from_snapshot: bool = field(default=False, repr=False, init=False)
    _tools_allowlist_mode: bool = field(default=False, repr=False, init=False)
    _requested_tool_names: list[str] = field(default_factory=list, repr=False, init=False)
    _mode: Literal["act", "plan"] = field(default="act", repr=False, init=False)
    _active_mode_snapshot: Literal["act", "plan"] | None = field(default=None, repr=False, init=False)
    _pending_plan_approval: dict[str, str] | None = field(default=None, repr=False, init=False)
    _active_plan_path: str | None = field(default=None, repr=False, init=False)
    _team_session_tasks: dict[str, asyncio.Task[None]] = field(
        default_factory=dict,
        repr=False,
        init=False,
    )
    _inbox_poll_task: asyncio.Task[None] | None = field(default=None, repr=False, init=False)
    _inbox_poll_lock: asyncio.Lock = field(default_factory=asyncio.Lock, repr=False, init=False)
    _pending_inbox_events: list[TeamInboxEnvelope] = field(default_factory=list, repr=False, init=False)
    _pending_inbox_keys: set[str] = field(default_factory=set, repr=False, init=False)
    _acked_inbox_keys: set[str] = field(default_factory=set, repr=False, init=False)
    _team_inbox_epoch: int = field(default=0, repr=False, init=False)
    _suppress_team_idle_notification: bool = field(default=False, repr=False, init=False)
    _team_session_managed: bool = field(default=False, repr=False, init=False)
    _team_poll_interval_seconds: float = field(
        default=DEFAULT_TEAM_POLL_INTERVAL_SECONDS,
        repr=False,
        init=False,
    )
    _chat_session_disable_legacy_inbox_poll: bool = field(default=False, repr=False, init=False)
    _chat_session_discard_team_turns_callback: Any | None = field(default=None, repr=False, init=False)

    def __post_init__(self) -> None:
        if not isinstance(self.options, RuntimeAgentOptions):
            raise TypeError(
                f"options 必须是 RuntimeAgentOptions，收到：{type(self.options).__name__}"
            )

        from comate_agent_sdk.agent.init import init_runtime_from_template

        init_runtime_from_template(self)
        self._team_poll_interval_seconds = resolve_team_poll_interval_seconds()

    async def aclose(self) -> None:
        """Gracefully close runtime-owned resources.

        Keep this method idempotent so callers can safely invoke it during
        nested/duplicated shutdown paths.
        """
        team_session_tasks = list(self._team_session_tasks.values())
        self._team_session_tasks.clear()
        for team_session_task in team_session_tasks:
            team_session_task.cancel()
        if team_session_tasks:
            await asyncio.gather(*team_session_tasks, return_exceptions=True)

        await self._stop_inbox_poll_task_async()

        async with self._mcp_load_lock:
            manager = self._mcp_manager
            if manager is not None:
                try:
                    await manager.aclose()
                except Exception as exc:
                    logger.warning(f"关闭 MCP manager 失败（忽略）：{exc}", exc_info=True)
                finally:
                    self._mcp_manager = None

            self._remove_mcp_tools_from_agent()
            self._mcp_loaded = False
            self._mcp_dirty = False
            self._mcp_pending_tool_names = []

    async def _poll_team_inbox_once(self) -> None:
        if not self.is_team_member or self._team_session_managed:
            return

        async with self._inbox_poll_lock:
            poll_epoch = self._team_inbox_epoch
            team_name = str(self._team_name or "").strip()
            agent_name = resolve_runtime_team_agent_name(
                runtime_name=self.name,
                is_subagent=bool(self._is_subagent),
            )
            if not team_name or not agent_name:
                return

            transport = TeamInboxTransport(team_name=team_name, agent_name=agent_name)
            batch = transport.poll_new()
            if not batch.events:
                return

            enqueue_external_turn = getattr(self, "_chat_session_external_turn_callback", None)
            if callable(enqueue_external_turn):
                ack_keys: list[str] = []
                conversational_events: list[TeamInboxEnvelope] = []
                for event in batch.events:
                    if poll_epoch != self._team_inbox_epoch:
                        return
                    message_type = str(event.message_type or "").strip()
                    if message_type == "shutdown_request":
                        try:
                            result = await enqueue_external_turn(
                                build_team_inbox_external_turn(event)
                            )
                        except Exception as exc:
                            logger.warning(
                                f"Failed to enqueue external turn from inbox: {exc}",
                                exc_info=True,
                            )
                            continue
                        if bool(getattr(result, "should_ack", False)):
                            ack_keys.append(event.key)
                        continue
                    if message_type == "idle_notification":
                        ack_keys.append(event.key)
                        continue
                    conversational_events.append(event)
                if conversational_events:
                    try:
                        result = await enqueue_external_turn(
                            build_team_inbox_batch_external_turn(conversational_events)
                        )
                    except Exception as exc:
                        logger.warning(
                            f"Failed to enqueue batched external turn from inbox: {exc}",
                            exc_info=True,
                        )
                    else:
                        if bool(getattr(result, "should_ack", False)):
                            ack_keys.extend(event.key for event in conversational_events)
                if ack_keys:
                    transport.ack(ack_keys)
                    self._acked_inbox_keys.update(ack_keys)
                return

            for event in batch.events:
                if poll_epoch != self._team_inbox_epoch:
                    return
                if str(event.message_type or "").strip() == "idle_notification":
                    transport.ack([event.key])
                    self._acked_inbox_keys.add(event.key)
                    continue
                if event.key in self._pending_inbox_keys or event.key in self._acked_inbox_keys:
                    continue
                self._pending_inbox_events.append(event)
                self._pending_inbox_keys.add(event.key)

    async def _run_inbox_poll_loop(self) -> None:
        try:
            while True:
                await self._poll_team_inbox_once()
                await asyncio.sleep(self._team_poll_interval_seconds)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.warning(f"Team inbox poll loop exited with error: {exc}", exc_info=True)

    async def _stop_inbox_poll_task_async(self) -> None:
        inbox_poll_task = self._inbox_poll_task
        self._inbox_poll_task = None
        if inbox_poll_task is None:
            return
        inbox_poll_task.cancel()
        await asyncio.gather(inbox_poll_task, return_exceptions=True)

    def _stop_inbox_poll_task(self) -> None:
        inbox_poll_task = self._inbox_poll_task
        self._inbox_poll_task = None
        if inbox_poll_task is None:
            return
        inbox_poll_task.cancel()

    def _start_inbox_poll_task(self) -> None:
        if self._inbox_poll_task is not None and not self._inbox_poll_task.done():
            return
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            logger.debug("Skip starting inbox poll task because no running event loop is available")
            return
        self._inbox_poll_task = loop.create_task(self._run_inbox_poll_loop())

    def _sync_inbox_poll_task(self) -> None:
        should_poll = (
            self.is_team_member
            and not self._team_session_managed
            and callable(getattr(self, "_chat_session_external_turn_callback", None))
        )
        if should_poll:
            self._start_inbox_poll_task()
            return
        self._stop_inbox_poll_task()

    def drain_pending_inbox_events(self) -> list[TeamInboxEnvelope]:
        events = list(self._pending_inbox_events)
        self._pending_inbox_events.clear()
        self._pending_inbox_keys.clear()
        return events

    def ack_pending_inbox_events(self, keys: list[str]) -> None:
        normalized_keys = [str(key).strip() for key in keys if str(key).strip()]
        if not normalized_keys:
            return

        team_name = str(self._team_name or "").strip()
        agent_name = resolve_runtime_team_agent_name(
            runtime_name=self.name,
            is_subagent=bool(self._is_subagent),
        )
        if not team_name or not agent_name:
            return

        transport = TeamInboxTransport(team_name=team_name, agent_name=agent_name)
        transport.ack(normalized_keys)
        self._acked_inbox_keys.update(normalized_keys)

    def discard_team_coordination_backlog(self) -> int:
        """Invalidate team inbox state and drop any queued team turns."""
        self._team_inbox_epoch += 1

        dropped_count = len(self._pending_inbox_events)
        self._pending_inbox_events.clear()
        self._pending_inbox_keys.clear()
        self._acked_inbox_keys.clear()

        discard_team_turns = getattr(self, "_chat_session_discard_team_turns_callback", None)
        if callable(discard_team_turns):
            try:
                dropped_count += int(discard_team_turns())
            except Exception as exc:
                logger.warning(
                    f"Failed to discard chat-session team turns during namespace teardown: {exc}",
                    exc_info=True,
                )

        return dropped_count

    def has_active_team_session(self, *, team_name: str, name: str) -> bool:
        identity = self._team_session_identity(team_name=team_name, name=name)
        task = self._team_session_tasks.get(identity)
        if task is None:
            return False
        if task.done():
            self._team_session_tasks.pop(identity, None)
            return False
        return True

    def register_team_session(
        self,
        *,
        team_name: str,
        name: str,
        task: asyncio.Task[None],
    ) -> None:
        identity = self._team_session_identity(team_name=team_name, name=name)
        existing = self._team_session_tasks.get(identity)
        if existing is not None and not existing.done():
            raise ValueError(
                f"Team session '{name}' is already running in team '{team_name}'."
            )

        self._team_session_tasks[identity] = task

        def _cleanup(completed_task: asyncio.Task[None]) -> None:
            current = self._team_session_tasks.get(identity)
            if current is completed_task:
                self._team_session_tasks.pop(identity, None)

        task.add_done_callback(_cleanup)

    def list_active_team_session_names(self, *, team_name: str) -> list[str]:
        normalized_team_name = str(team_name or "").strip()
        if not normalized_team_name:
            return []

        active_names: list[str] = []
        stale_identities: list[str] = []
        prefix = f"{normalized_team_name}::"
        for identity, task in self._team_session_tasks.items():
            if not identity.startswith(prefix):
                continue
            if task.done():
                stale_identities.append(identity)
                continue
            _, _, raw_name = identity.partition("::")
            if raw_name:
                active_names.append(raw_name)

        for identity in stale_identities:
            self._team_session_tasks.pop(identity, None)

        return sorted(active_names)

    @staticmethod
    def _team_session_identity(*, team_name: str, name: str) -> str:
        return f"{team_name.strip()}::{name.strip()}"

    # Backward-compatible aliases kept for internal callers/tests that still use the old name.
    def has_active_background_subagent(self, *, team_name: str, name: str) -> bool:
        return self.has_active_team_session(team_name=team_name, name=name)

    def register_background_subagent(
        self,
        *,
        team_name: str,
        name: str,
        task: asyncio.Task[None],
    ) -> None:
        self.register_team_session(team_name=team_name, name=name, task=task)

    @property
    def is_team_member(self) -> bool:
        """当前 agent 是否处于 Team 模式（有 team_name）。"""
        return bool(self._team_name)

    def get_mode(self) -> Literal["act", "plan"]:
        return self._mode

    def set_mode(self, mode: Literal["act", "plan"] | str) -> None:
        normalized = str(mode).strip().lower()
        if normalized not in {"act", "plan"}:
            raise ValueError(f"Unsupported mode: {mode}")
        previous_mode = self._mode
        self._mode = normalized  # type: ignore[assignment]
        if previous_mode != "plan" and self._mode == "plan":
            try:
                self._active_plan_path = str(build_plan_artifact_path())
                logger.debug(f"set_mode: allocated active plan path: {self._active_plan_path}")
            except Exception as exc:
                logger.warning(f"set_mode: failed to allocate active plan path: {exc}", exc_info=True)
                self._active_plan_path = None
        elif self._mode != "plan":
            self._active_plan_path = None
        self._context.set_plan_mode(self._mode == "plan")

    def cycle_mode(self) -> Literal["act", "plan"]:
        next_mode: Literal["act", "plan"] = "plan" if self._mode == "act" else "act"
        self.set_mode(next_mode)
        return next_mode

    def get_active_plan_path(self) -> str | None:
        value = str(self._active_plan_path or "").strip()
        return value or None

    def arm_plan_approval(
        self,
        *,
        plan_path: str,
        summary: str,
        execution_prompt: str,
    ) -> None:
        self._pending_plan_approval = {
            "plan_path": plan_path,
            "summary": summary,
            "execution_prompt": execution_prompt,
        }

    def has_pending_plan_approval(self) -> bool:
        return self._pending_plan_approval is not None

    def pending_plan_approval(self) -> dict[str, str] | None:
        if self._pending_plan_approval is None:
            return None
        return dict(self._pending_plan_approval)

    def approve_plan(self, *, clear_context: bool = False) -> str:
        pending = self._pending_plan_approval
        self._pending_plan_approval = None
        self.set_mode("act")
        if pending is None:
            return "I have approved the plan. Please continue to execute the plan."

        if clear_context:
            self._context.clear_conversation()
            logger.debug("approve_plan: conversation cleared")

        plan_path = str(pending.get("plan_path", "")).strip()
        if plan_path:
            try:
                from pathlib import Path
                from comate_agent_sdk.llm.messages import UserMessage
                plan_markdown = Path(plan_path).read_text(encoding="utf-8").strip()
                if plan_markdown:
                    injection = f"<approved-plan>\n{plan_markdown}\n</approved-plan>"
                    self._context.add_message(UserMessage(content=injection, is_meta=True))
                    logger.debug(f"approve_plan: injected plan from {plan_path}")
            except Exception as exc:
                logger.warning(f"approve_plan: failed to read plan file: {exc}")

        execution_prompt = str(pending.get("execution_prompt", "")).strip()
        return execution_prompt or "I have approved the plan. Please continue to execute the plan."

    def reject_plan(self) -> None:
        self._pending_plan_approval = None
        self.set_mode("plan")

    # ── 懒加载委托方法（解决循环导入）────────────────────────────

    def _destroy_ephemeral_messages(self) -> None:
        from comate_agent_sdk.agent.history import destroy_ephemeral_messages

        destroy_ephemeral_messages(self)

    async def _execute_tool_call(self, tool_call: ToolCall) -> ToolMessage:
        from comate_agent_sdk.agent.tool_exec import execute_tool_call

        return await execute_tool_call(self, tool_call)

    def _extract_screenshot(self, tool_message: ToolMessage) -> str | None:
        from comate_agent_sdk.agent.tool_exec import extract_screenshot

        return extract_screenshot(tool_message)

    async def _invoke_llm(self) -> "ChatInvokeCompletion":
        from comate_agent_sdk.agent.llm import invoke_llm

        return await invoke_llm(self)

    async def _generate_max_iterations_summary(self) -> str:
        from comate_agent_sdk.agent.runner_engine import generate_max_iterations_summary

        return await generate_max_iterations_summary(self)

    async def _check_and_compact(self, response: "ChatInvokeCompletion") -> bool:
        from comate_agent_sdk.agent.runner_engine import check_and_compact

        compacted, _, _ = await check_and_compact(self, response)
        return compacted

    async def compact_context_manual(self) -> "ManualCompactionResult":
        from comate_agent_sdk.agent.runner_engine import manual_compact_context

        return await manual_compact_context(self)

    async def query(self, message: str) -> str:
        from comate_agent_sdk.agent.runner_engine import run_query

        return await run_query(self, message)

    async def query_stream(
        self,
        message: str | list[ContentPartTextParam | ContentPartImageParam],
    ) -> AsyncIterator["AgentEvent"]:
        from comate_agent_sdk.agent.runner_engine import run_query_stream

        async for event in run_query_stream(self, message):
            yield event

    def _setup_tool_strategy(self) -> None:
        from comate_agent_sdk.agent.setup import setup_tool_strategy

        setup_tool_strategy(self)

    def _setup_memory_usage(self) -> None:
        from comate_agent_sdk.agent.setup import setup_memory_usage

        setup_memory_usage(self)

    def _setup_subagents(self) -> None:
        from comate_agent_sdk.agent.setup import setup_subagents

        setup_subagents(self)

    def _setup_user_instruction(self) -> None:
        from comate_agent_sdk.agent.setup import setup_user_instruction

        setup_user_instruction(self)

    def _setup_auto_memory(self) -> None:
        from comate_agent_sdk.agent.setup import setup_auto_memory

        setup_auto_memory(self)

    def _setup_skills(self) -> None:
        from comate_agent_sdk.agent.setup import setup_skills

        setup_skills(self)

    async def _execute_skill_call(self, tool_call: ToolCall) -> ToolMessage:
        from comate_agent_sdk.agent.setup import execute_skill_call

        return await execute_skill_call(self, tool_call)

    def _rebuild_skill_tool(self) -> None:
        from comate_agent_sdk.agent.setup import rebuild_skill_tool

        rebuild_skill_tool(self)


from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from comate_agent_sdk.agent.compaction.models import ManualCompactionResult
    from comate_agent_sdk.agent.core.template import AgentTemplate
    from comate_agent_sdk.agent.events import AgentEvent
    from comate_agent_sdk.agent.interrupt import SessionRunController
    from comate_agent_sdk.llm.views import ChatInvokeCompletion
