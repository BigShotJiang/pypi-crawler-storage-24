from __future__ import annotations

import asyncio
import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.chat_session import ChatSession
from comate_agent_sdk.system_tools.team.inbox_transport import TeamInboxEnvelope
from comate_agent_sdk.subagent.agent_tool import _clear_team_namespace, _switch_parent_to_team_namespace


class _FakeChatModel:
    def __init__(self) -> None:
        self.model = "fake:model"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        raise AssertionError("This test should not call the LLM")


class _FakeMcpManager:
    def __init__(self) -> None:
        self.close_calls = 0

    async def aclose(self) -> None:
        self.close_calls += 1


class TestRuntimeShutdown(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        super().setUp()
        self._team_poll_patch = patch.dict(
            "os.environ",
            {"COMATE_TEAM_POLL_INTERVAL_SECONDS": "0.01"},
        )
        self._team_poll_patch.start()
        self.addCleanup(self._team_poll_patch.stop)

    def _build_runtime(self):
        template = Agent(
            llm=_FakeChatModel(),  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(),
                agents=(),
                offload_enabled=False,
                setting_sources=None,
            ),
        )
        return template, template.create_runtime(session_id="runtime-shutdown-test")

    async def test_runtime_aclose_is_idempotent(self) -> None:
        _, runtime = self._build_runtime()
        manager = _FakeMcpManager()
        runtime._mcp_manager = manager
        runtime._mcp_loaded = True
        runtime._mcp_dirty = True
        runtime._mcp_pending_tool_names = ["mcp__demo__tool"]

        await runtime.aclose()
        await runtime.aclose()

        self.assertEqual(manager.close_calls, 1)
        self.assertIsNone(runtime._mcp_manager)
        self.assertFalse(runtime._mcp_loaded)
        self.assertFalse(runtime._mcp_dirty)
        self.assertEqual(runtime._mcp_pending_tool_names, [])

    async def test_runtime_uses_shared_team_poll_interval_config(self) -> None:
        _, runtime = self._build_runtime()

        self.assertEqual(runtime._team_poll_interval_seconds, 0.01)

    async def test_chat_session_shutdown_closes_runtime_once(self) -> None:
        template, runtime = self._build_runtime()
        runtime.aclose = AsyncMock()  # type: ignore[method-assign]

        with tempfile.TemporaryDirectory() as tmp:
            session = ChatSession(
                template,
                runtime=runtime,
                session_id=runtime.options.session_id,
                cwd=Path(tmp),
            )
            await session.shutdown()
            await session.shutdown()

        self.assertTrue(session._closed)
        self.assertTrue(session._shutdown_completed)
        runtime.aclose.assert_awaited_once()

    async def test_runtime_aclose_cancels_background_subagent_tasks(self) -> None:
        _, runtime = self._build_runtime()
        cancelled = asyncio.Event()

        async def _run_forever() -> None:
            try:
                await asyncio.Event().wait()
            except asyncio.CancelledError:
                cancelled.set()
                raise

        background_task = asyncio.create_task(_run_forever())
        runtime.register_background_subagent(
            team_name="review-team",
            name="worker-1",
            task=background_task,
        )
        await asyncio.sleep(0)

        await runtime.aclose()

        self.assertTrue(cancelled.is_set())
        self.assertFalse(
            runtime.has_active_background_subagent(
                team_name="review-team",
                name="worker-1",
            )
        )

    async def test_runtime_aclose_cancels_inbox_poll_task(self) -> None:
        _, runtime = self._build_runtime()
        cancelled = asyncio.Event()

        async def _poll_forever() -> None:
            try:
                await asyncio.Event().wait()
            except asyncio.CancelledError:
                cancelled.set()
                raise

        runtime._inbox_poll_task = asyncio.create_task(_poll_forever())
        await asyncio.sleep(0)
        await runtime.aclose()

        self.assertTrue(cancelled.is_set())
        self.assertIsNone(runtime._inbox_poll_task)

    async def test_sync_inbox_poll_task_starts_only_when_team_mode_and_callback_present(self) -> None:
        _, runtime = self._build_runtime()

        runtime._sync_inbox_poll_task()
        self.assertIsNone(runtime._inbox_poll_task)

        runtime._team_name = "review-team"
        runtime._sync_inbox_poll_task()
        self.assertIsNone(runtime._inbox_poll_task)

        runtime._chat_session_external_turn_callback = AsyncMock()
        runtime._sync_inbox_poll_task()
        self.assertIsNotNone(runtime._inbox_poll_task)

        await runtime._stop_inbox_poll_task_async()
        self.assertIsNone(runtime._inbox_poll_task)

    async def test_team_namespace_switch_syncs_inbox_poll_task(self) -> None:
        _, runtime = self._build_runtime()
        runtime._chat_session_external_turn_callback = AsyncMock()

        _switch_parent_to_team_namespace(runtime, "review-team")
        self.assertIsNotNone(runtime._inbox_poll_task)

        _clear_team_namespace(runtime)
        await asyncio.sleep(0)
        self.assertIsNone(runtime._inbox_poll_task)

    async def test_clear_team_namespace_discards_runtime_inbox_backlog(self) -> None:
        _, runtime = self._build_runtime()
        runtime._team_name = "review-team"
        runtime._task_namespace = "review-team"
        runtime._pending_inbox_events.append(
            TeamInboxEnvelope(
                key="evt-1",
                from_agent="worker-1",
                message_type="message",
                content="done",
                timestamp="2026-03-11T00:00:00+00:00",
                raw_envelope={},
            )
        )
        runtime._pending_inbox_keys.add("evt-1")
        runtime._acked_inbox_keys.add("evt-acked")

        _clear_team_namespace(runtime)
        await asyncio.sleep(0)

        self.assertEqual(runtime._pending_inbox_events, [])
        self.assertEqual(runtime._pending_inbox_keys, set())
        self.assertEqual(runtime._acked_inbox_keys, set())
        self.assertEqual(runtime._team_name, "")


if __name__ == "__main__":
    unittest.main(verbosity=2)
