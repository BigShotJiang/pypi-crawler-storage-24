import asyncio
import json
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from unittest.mock import patch

from comate_agent_sdk import Agent
from comate_agent_sdk.agent import AgentConfig
from comate_agent_sdk.agent.chat_session import ChatSession, ChatSessionError
from comate_agent_sdk.agent.events import ExternalTurnPendingEvent, ExternalTurnScheduledEvent, StopEvent, TextEvent
from comate_agent_sdk.agent.external_turns import ExternalTurn
from comate_agent_sdk.agent.setup import resolve_auto_memory_dir
from comate_agent_sdk.agent.session_store import (
    ConversationState as _ConversationState,
    PERSISTENCE_SCHEMA_VERSION,
    build_conversation_event as _build_conversation_event,
    build_header_snapshot_event as _build_header_snapshot_event,
    default_session_root,
    external_turns_journal_path,
    events_jsonl_append as _events_jsonl_append,
    load_session_metadata,
    replay_external_turn_journal,
    replay_header_snapshot as _replay_header_snapshot,
    replay_conversation_events as _replay_conversation_events,
    replay_session_events as _replay_session_events,
)
from comate_agent_sdk.system_tools.task import TaskStore
from comate_agent_sdk.system_tools.team.config import TeamConfig
from comate_agent_sdk.system_tools.team.inbox import Inbox
from comate_agent_sdk.subagent.agent_tool import _clear_team_namespace, _switch_parent_to_team_namespace
from comate_agent_sdk.context.ir import ContextIR
from comate_agent_sdk.context.items import ContextItem, ItemType
from comate_agent_sdk.context.memory import UserInstructionConfig
from comate_agent_sdk.context.observer import EventType
from comate_agent_sdk.llm.messages import AssistantMessage, ToolMessage, UserMessage
from comate_agent_sdk.llm.views import ChatInvokeCompletion, ChatInvokeUsage
from comate_agent_sdk.tokens.views import TokenUsageEntry


class _FakeChatModel:
    def __init__(self) -> None:
        self.model = "fake:model"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        raise AssertionError("This test should not call the LLM")


class _SequenceChatModel:
    def __init__(self, completions: list[ChatInvokeCompletion]) -> None:
        self.model = "fake:model"
        self._completions = completions
        self._index = 0

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        del messages, tools, tool_choice, kwargs
        if self._index >= len(self._completions):
            raise AssertionError(f"Unexpected ainvoke call #{self._index + 1}")
        result = self._completions[self._index]
        self._index += 1
        return result


class TestChatSessionPersistence(unittest.TestCase):
    @staticmethod
    def _append_header_snapshot(path: Path, *, session_id: str = "s1", snapshot: dict | None = None) -> None:
        payload = snapshot or {
            "schema_version": 2,
            "header_items": [],
            "user_instruction_item": None,
        }
        _events_jsonl_append(
            path,
            _build_header_snapshot_event(
                session_id=session_id,
                snapshot=payload,
                turn_number=0,
            ),
        )

    @staticmethod
    def _make_usage_entry(
        *,
        model: str,
        prompt_tokens: int,
        completion_tokens: int,
        level: str = "MID",
    ) -> TokenUsageEntry:
        return TokenUsageEntry(
            model=model,
            timestamp=datetime.now(),
            usage=ChatInvokeUsage(
                prompt_tokens=prompt_tokens,
                prompt_cached_tokens=None,
                prompt_cache_creation_tokens=None,
                prompt_image_tokens=None,
                completion_tokens=completion_tokens,
                total_tokens=prompt_tokens + completion_tokens,
            ),
            level=level,
            source="agent",
        )

    def test_chat_session_constructs_with_session_options_clone(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            agent = Agent(
                llm=_FakeChatModel(),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                ),
            )

            self.assertIsNone(agent.config.session_id)

            session = ChatSession(
                agent,
                session_id="s1",
                cwd=root,
            )

            self.assertEqual(session.session_id, "s1")
            self.assertEqual(session._agent.options.session_id, "s1")
            self.assertEqual(
                session._storage_root,
                default_session_root("s1", cwd=root),
            )
            self.assertEqual(session._agent.options.cwd, root.resolve())
            self.assertEqual(session._agent._task_namespace, "s1")
            self.assertEqual(
                load_session_metadata(session._storage_root),
                {
                    "session_id": "s1",
                    "task_namespace": "s1",
                },
            )

            # 模板 agent 不应被 ChatSession 构造污染
            self.assertIsNone(agent.config.session_id)

    def test_env_task_namespace_overrides_session_default(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            agent = Agent(
                llm=_FakeChatModel(),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                    task_namespace="config-ns",
                ),
            )

            with patch.dict("os.environ", {"COMATE_TASK_LIST_ID": "shared-env"}):
                session = ChatSession(
                    agent,
                    session_id="s1",
                    cwd=root,
                )

            self.assertEqual(session._agent._task_namespace, "shared-env")
            self.assertEqual(
                load_session_metadata(session._storage_root),
                {
                    "session_id": "s1",
                    "task_namespace": "shared-env",
                },
            )

    def test_resume_restores_team_name_from_session_metadata(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            agent = Agent(
                llm=_FakeChatModel(),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                ),
            )

            session = ChatSession(
                agent,
                session_id="s1",
                cwd=root,
            )
            session._agent._team_name = "review-team"
            session._bind_task_namespace("review-team", persist=True)
            session._ensure_header_persisted()

            self.assertEqual(
                load_session_metadata(session._storage_root),
                {
                    "session_id": "s1",
                    "task_namespace": "review-team",
                    "team_name": "review-team",
                },
            )

            resumed = ChatSession.resume(
                agent,
                session_id="s1",
                cwd=root,
            )

            self.assertEqual(resumed._agent._task_namespace, "review-team")
            self.assertEqual(resumed._agent._team_name, "review-team")
            self.assertTrue(resumed._agent.is_team_member)

    def test_fork_session_drops_external_turn_journal(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            agent = Agent(
                llm=_FakeChatModel(),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                ),
            )
            session = ChatSession(
                agent,
                session_id="s1",
                cwd=root,
            )
            asyncio.run(
                session.enqueue_external_turn(
                    ExternalTurn(
                        turn_id="team_inbox:evt-1",
                        source="team_inbox",
                        source_event_id="evt-1",
                        dedupe_key="team_inbox:evt-1",
                        received_at="2026-03-11T00:00:00+00:00",
                        payload={
                            "from_agent": "worker-1",
                            "message_type": "message",
                            "content": "done",
                            "timestamp": "2026-03-11T00:00:00+00:00",
                        },
                        preview="done",
                    )
                )
            )

            self.assertTrue(external_turns_journal_path(session._storage_root).exists())

            forked = session.fork_session()

            self.assertFalse(external_turns_journal_path(forked._storage_root).exists())

    def test_fork_session_resets_team_name_metadata(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            agent = Agent(
                llm=_FakeChatModel(),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                ),
            )

            session = ChatSession(
                agent,
                session_id="s1",
                cwd=root,
            )
            session._agent._team_name = "review-team"
            session._bind_task_namespace("review-team", persist=True)
            forked = session.fork_session()

            self.assertEqual(
                load_session_metadata(forked._storage_root),
                {
                    "session_id": forked.session_id,
                    "task_namespace": forked.session_id,
                },
            )
            self.assertEqual(forked._agent._team_name, "")
            self.assertFalse(forked._agent.is_team_member)

    def test_delta_append_and_replay_basic(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            offload_root = root / "offload"
            path = root / "context.jsonl"

            before = _ConversationState.capture([])
            items = [
                ContextItem(
                    id="u1",
                    item_type=ItemType.USER_MESSAGE,
                    message=UserMessage(content="hi"),
                    content_text="hi",
                    token_count=2,
                ),
                ContextItem(
                    id="a1",
                    item_type=ItemType.ASSISTANT_MESSAGE,
                    message=AssistantMessage(content="hello"),
                    content_text="hello",
                    token_count=5,
                ),
            ]

            evt = _build_conversation_event(
                session_id="s1",
                turn_number=1,
                before=before,
                after_items=items,
                offload_root=offload_root,
            )
            _events_jsonl_append(path, evt)

            turn, replayed = _replay_conversation_events(path=path, offload_root=offload_root)
            self.assertEqual(turn, 1)
            self.assertEqual([i.id for i in replayed], ["u1", "a1"])
            self.assertEqual([i.item_type for i in replayed], [ItemType.USER_MESSAGE, ItemType.ASSISTANT_MESSAGE])

            # 确认没有把 header/system prompt 写进文件结构里
            raw = path.read_text(encoding="utf-8").strip()
            data = json.loads(raw)
            self.assertNotIn("context", data)

    def test_tool_offload_path_persisted_relative_and_rehydrated_absolute(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            offload_root = root / "offload"
            offload_root.mkdir(parents=True, exist_ok=True)
            path = root / "context.jsonl"

            rel = "tool_result/read/t1.json"
            abs_path = str(offload_root / rel)

            tool_msg = ToolMessage(
                tool_call_id="tc1",
                tool_name="read",
                content="very large content",
                is_error=False,
                destroyed=True,
                offloaded=True,
                offload_path=abs_path,
            )
            item = ContextItem(
                id="t1",
                item_type=ItemType.TOOL_RESULT,
                message=tool_msg,
                content_text="very large content",
                token_count=1000,
                destroyed=True,
                offloaded=True,
                offload_path=rel,
                tool_name="read",
            )

            before = _ConversationState.capture([])
            evt = _build_conversation_event(
                session_id="s1",
                turn_number=1,
                before=before,
                after_items=[item],
                offload_root=offload_root,
            )
            _events_jsonl_append(path, evt)

            line = path.read_text(encoding="utf-8").strip()
            data = json.loads(line)
            adds = data["conversation"]["adds"]
            self.assertEqual(adds[0]["offload_path"], rel)
            self.assertEqual(adds[0]["message"]["offload_path"], rel)
            self.assertEqual(adds[0]["message"]["content"], "")

            _, replayed = _replay_conversation_events(path=path, offload_root=offload_root)
            self.assertEqual(len(replayed), 1)
            replay_item = replayed[0]
            self.assertEqual(replay_item.offload_path, rel)
            self.assertIsInstance(replay_item.message, ToolMessage)
            self.assertEqual(replay_item.message.offload_path, abs_path)
            self.assertTrue(replay_item.message.destroyed)
            self.assertTrue(replay_item.message.offloaded)

    def test_updates_and_removes(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            offload_root = root / "offload"
            offload_root.mkdir(parents=True, exist_ok=True)
            path = root / "context.jsonl"

            u1 = ContextItem(
                id="u1",
                item_type=ItemType.USER_MESSAGE,
                message=UserMessage(content="q"),
                content_text="q",
                token_count=1,
            )
            t1_msg = ToolMessage(tool_call_id="tc1", tool_name="read", content="x", is_error=False)
            t1 = ContextItem(
                id="t1",
                item_type=ItemType.TOOL_RESULT,
                message=t1_msg,
                content_text="x",
                token_count=1,
                tool_name="read",
            )
            a1 = ContextItem(
                id="a1",
                item_type=ItemType.ASSISTANT_MESSAGE,
                message=AssistantMessage(content="a"),
                content_text="a",
                token_count=1,
            )

            before = _ConversationState.capture([])
            evt1 = _build_conversation_event(
                session_id="s1",
                turn_number=1,
                before=before,
                after_items=[u1, t1, a1],
                offload_root=offload_root,
            )
            _events_jsonl_append(path, evt1)

            # 第二轮：先捕获 before，再模拟 t1 被 destroyed + offloaded，同时删除 a1
            before2 = _ConversationState.capture([u1, t1, a1])

            rel = "tool_result/read/t1.json"
            t1.destroyed = True
            t1.offloaded = True
            t1.offload_path = rel
            t1_msg.destroyed = True
            t1_msg.offloaded = True
            t1_msg.offload_path = str(offload_root / rel)

            evt2 = _build_conversation_event(
                session_id="s1",
                turn_number=2,
                before=before2,
                after_items=[u1, t1],
                offload_root=offload_root,
            )
            _events_jsonl_append(path, evt2)

            turn, replayed = _replay_conversation_events(path=path, offload_root=offload_root)
            self.assertEqual(turn, 2)
            self.assertEqual([i.id for i in replayed], ["u1", "t1"])
            replay_t1 = replayed[1]
            self.assertTrue(replay_t1.destroyed)
            self.assertTrue(replay_t1.offloaded)
            self.assertEqual(replay_t1.offload_path, rel)
            self.assertIsInstance(replay_t1.message, ToolMessage)
            self.assertTrue(replay_t1.message.destroyed)
            self.assertTrue(replay_t1.message.offloaded)
            self.assertEqual(replay_t1.message.offload_path, str(offload_root / rel))

    def test_reset_on_reorder(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            offload_root = root / "offload"
            path = root / "context.jsonl"

            a = ContextItem(
                id="a",
                item_type=ItemType.USER_MESSAGE,
                message=UserMessage(content="a"),
                content_text="a",
                token_count=1,
            )
            b = ContextItem(
                id="b",
                item_type=ItemType.ASSISTANT_MESSAGE,
                message=AssistantMessage(content="b"),
                content_text="b",
                token_count=1,
            )

            evt1 = _build_conversation_event(
                session_id="s1",
                turn_number=1,
                before=_ConversationState.capture([]),
                after_items=[a, b],
                offload_root=offload_root,
            )
            _events_jsonl_append(path, evt1)

            evt2 = _build_conversation_event(
                session_id="s1",
                turn_number=2,
                before=_ConversationState.capture([a, b]),
                after_items=[b, a],
                offload_root=offload_root,
            )
            self.assertEqual(evt2["op"], "conversation_reset")
            _events_jsonl_append(path, evt2)

            turn, replayed = _replay_conversation_events(path=path, offload_root=offload_root)
            self.assertEqual(turn, 2)
            self.assertEqual([i.id for i in replayed], ["b", "a"])

    def test_replay_session_events_includes_usage_delta(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            offload_root = root / "offload"
            path = root / "context.jsonl"

            usage_entry = self._make_usage_entry(
                model="m1",
                prompt_tokens=12,
                completion_tokens=8,
            )
            _events_jsonl_append(
                path,
                {
                    "schema_version": PERSISTENCE_SCHEMA_VERSION,
                    "session_id": "s1",
                    "turn_number": 1,
                    "op": "usage_delta",
                    "usage": {
                        "adds": [usage_entry.model_dump(mode="json")]
                    },
                },
            )

            turn, replayed_items, replayed_usage = _replay_session_events(
                path=path,
                offload_root=offload_root,
            )
            self.assertEqual(turn, 1)
            self.assertEqual(replayed_items, [])
            self.assertEqual(len(replayed_usage), 1)
            self.assertEqual(replayed_usage[0].model, "m1")
            self.assertEqual(replayed_usage[0].usage.total_tokens, 20)

    def test_replay_session_events_usage_reset_clears_history(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            offload_root = root / "offload"
            path = root / "context.jsonl"

            entry_a = self._make_usage_entry(
                model="m1",
                prompt_tokens=10,
                completion_tokens=5,
            )
            entry_b = self._make_usage_entry(
                model="m2",
                prompt_tokens=6,
                completion_tokens=4,
            )
            entry_c = self._make_usage_entry(
                model="m3",
                prompt_tokens=3,
                completion_tokens=2,
            )

            _events_jsonl_append(
                path,
                {
                    "schema_version": PERSISTENCE_SCHEMA_VERSION,
                    "session_id": "s1",
                    "turn_number": 1,
                    "op": "usage_delta",
                    "usage": {
                        "adds": [
                            entry_a.model_dump(mode="json"),
                            entry_b.model_dump(mode="json"),
                        ]
                    },
                },
            )
            _events_jsonl_append(
                path,
                {
                    "schema_version": PERSISTENCE_SCHEMA_VERSION,
                    "session_id": "s1",
                    "turn_number": 2,
                    "op": "usage_reset",
                    "usage": {"entries": []},
                },
            )
            _events_jsonl_append(
                path,
                {
                    "schema_version": PERSISTENCE_SCHEMA_VERSION,
                    "session_id": "s1",
                    "turn_number": 3,
                    "op": "usage_delta",
                    "usage": {"adds": [entry_c.model_dump(mode="json")]},
                },
            )

            turn, _, replayed_usage = _replay_session_events(path=path, offload_root=offload_root)
            self.assertEqual(turn, 3)
            self.assertEqual(len(replayed_usage), 1)
            self.assertEqual(replayed_usage[0].model, "m3")
            self.assertEqual(replayed_usage[0].usage.total_tokens, 5)

    def test_replay_session_events_with_max_turn(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            offload_root = root / "offload"
            path = root / "context.jsonl"

            a = ContextItem(
                id="u1",
                item_type=ItemType.USER_MESSAGE,
                message=UserMessage(content="t1"),
                content_text="t1",
                token_count=1,
            )
            b = ContextItem(
                id="u2",
                item_type=ItemType.USER_MESSAGE,
                message=UserMessage(content="t2"),
                content_text="t2",
                token_count=1,
            )

            evt1 = _build_conversation_event(
                session_id="s1",
                turn_number=1,
                before=_ConversationState.capture([]),
                after_items=[a],
                offload_root=offload_root,
            )
            evt2 = _build_conversation_event(
                session_id="s1",
                turn_number=2,
                before=_ConversationState.capture([a]),
                after_items=[a, b],
                offload_root=offload_root,
            )
            _events_jsonl_append(path, evt1)
            _events_jsonl_append(path, evt2)

            turn, replayed_items, _ = _replay_session_events(
                path=path,
                offload_root=offload_root,
                max_turn=1,
            )
            self.assertEqual(turn, 1)
            self.assertEqual([item.id for item in replayed_items], ["u1"])

    def test_replay_header_snapshot_keeps_first_snapshot(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            path = root / "context.jsonl"
            first_snapshot = {
                "schema_version": 1,
                "header_items": [
                    {
                        "item_type": "system_prompt",
                        "message": None,
                        "content_text": "FIRST",
                        "token_count": 1,
                        "priority": 100,
                        "ephemeral": False,
                        "destroyed": False,
                        "tool_name": None,
                        "created_at": 0.0,
                        "metadata": {},
                        "cache_hint": False,
                        "offload_path": None,
                        "offloaded": False,
                        "is_tool_error": False,
                        "created_turn": 0,
                    }
                ],
                "memory_item": None,
            }
            second_snapshot = {
                "schema_version": 1,
                "header_items": [
                    {
                        "item_type": "system_prompt",
                        "message": None,
                        "content_text": "SECOND",
                        "token_count": 1,
                        "priority": 100,
                        "ephemeral": False,
                        "destroyed": False,
                        "tool_name": None,
                        "created_at": 0.0,
                        "metadata": {},
                        "cache_hint": False,
                        "offload_path": None,
                        "offloaded": False,
                        "is_tool_error": False,
                        "created_turn": 0,
                    }
                ],
                "memory_item": None,
            }
            _events_jsonl_append(
                path,
                _build_header_snapshot_event(
                    session_id="s1",
                    snapshot=first_snapshot,
                    turn_number=0,
                ),
            )
            _events_jsonl_append(
                path,
                _build_header_snapshot_event(
                    session_id="s1",
                    snapshot=second_snapshot,
                    turn_number=2,
                ),
            )
            replayed = _replay_header_snapshot(path=path)
            self.assertIsNotNone(replayed)
            header_items = replayed.get("header_items", [])
            self.assertEqual(header_items[0]["content_text"], "FIRST")

    def test_chat_session_resume_restores_usage_summary(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            session_root = default_session_root("s1", cwd=root)
            path = session_root / "context.jsonl"
            self._append_header_snapshot(path, session_id="s1")
            usage_entry = self._make_usage_entry(
                model="m1",
                prompt_tokens=11,
                completion_tokens=9,
            )
            _events_jsonl_append(
                path,
                {
                    "schema_version": PERSISTENCE_SCHEMA_VERSION,
                    "session_id": "s1",
                    "turn_number": 1,
                    "op": "usage_delta",
                    "usage": {
                        "adds": [usage_entry.model_dump(mode="json")]
                    },
                },
            )

            agent = Agent(
                llm=_FakeChatModel(),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                ),
            )
            session = ChatSession.resume(
                agent,
                session_id="s1",
                cwd=root,
            )

            usage = asyncio.run(session.get_usage())
            self.assertEqual(usage.entry_count, 1)
            self.assertEqual(usage.total_prompt_tokens, 11)
            self.assertEqual(usage.total_completion_tokens, 9)
            self.assertEqual(usage.total_tokens, 20)

    def test_clear_history_writes_usage_reset_event(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            session_root = default_session_root("s1", cwd=root)
            agent = Agent(
                llm=_FakeChatModel(),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                ),
            )

            session = ChatSession(
                agent,
                session_id="s1",
                cwd=root,
            )
            session.clear_history()

            lines = [
                json.loads(line)
                for line in (session_root / "context.jsonl").read_text(encoding="utf-8").splitlines()
                if line.strip()
            ]
            self.assertEqual([line["op"] for line in lines], ["header_snapshot", "conversation_reset", "usage_reset"])
            self.assertEqual(lines[0]["turn_number"], 0)
            self.assertEqual(lines[1]["turn_number"], 1)
            self.assertEqual(lines[2]["turn_number"], 1)

    def test_restore_conversation_to_turn_keeps_usage_history(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            session_root = default_session_root("s1", cwd=root)
            offload_root = session_root / "offload"
            context_path = session_root / "context.jsonl"
            self._append_header_snapshot(context_path, session_id="s1")

            u1 = ContextItem(
                id="u1",
                item_type=ItemType.USER_MESSAGE,
                message=UserMessage(content="turn1"),
                content_text="turn1",
                token_count=1,
            )
            a1 = ContextItem(
                id="a1",
                item_type=ItemType.ASSISTANT_MESSAGE,
                message=AssistantMessage(content="resp1"),
                content_text="resp1",
                token_count=1,
            )
            turn1_evt = _build_conversation_event(
                session_id="s1",
                turn_number=1,
                before=_ConversationState.capture([]),
                after_items=[u1, a1],
                offload_root=offload_root,
            )
            _events_jsonl_append(context_path, turn1_evt)

            u2 = ContextItem(
                id="u2",
                item_type=ItemType.USER_MESSAGE,
                message=UserMessage(content="turn2"),
                content_text="turn2",
                token_count=1,
            )
            a2 = ContextItem(
                id="a2",
                item_type=ItemType.ASSISTANT_MESSAGE,
                message=AssistantMessage(content="resp2"),
                content_text="resp2",
                token_count=1,
            )
            turn2_evt = _build_conversation_event(
                session_id="s1",
                turn_number=2,
                before=_ConversationState.capture([u1, a1]),
                after_items=[u1, a1, u2, a2],
                offload_root=offload_root,
            )
            _events_jsonl_append(context_path, turn2_evt)

            entry_1 = self._make_usage_entry(model="m1", prompt_tokens=10, completion_tokens=2)
            entry_2 = self._make_usage_entry(model="m1", prompt_tokens=8, completion_tokens=1)
            _events_jsonl_append(
                context_path,
                {
                    "schema_version": PERSISTENCE_SCHEMA_VERSION,
                    "session_id": "s1",
                    "turn_number": 1,
                    "op": "usage_delta",
                    "usage": {"adds": [entry_1.model_dump(mode="json")]},
                },
            )
            _events_jsonl_append(
                context_path,
                {
                    "schema_version": PERSISTENCE_SCHEMA_VERSION,
                    "session_id": "s1",
                    "turn_number": 2,
                    "op": "usage_delta",
                    "usage": {"adds": [entry_2.model_dump(mode="json")]},
                },
            )

            agent = Agent(
                llm=_FakeChatModel(),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                ),
            )
            session = ChatSession.resume(agent, session_id="s1", cwd=root)
            replaced_before_restore = sum(
                1
                for event in session._agent._context.event_bus.event_log
                if event.event_type == EventType.CONVERSATION_REPLACED
            )
            session.restore_conversation_to_turn(target_turn=1)
            replaced_after_restore = sum(
                1
                for event in session._agent._context.event_bus.event_log
                if event.event_type == EventType.CONVERSATION_REPLACED
            )

            replay_turn, replay_items, replay_usage = _replay_session_events(
                path=context_path,
                offload_root=offload_root,
            )
            self.assertEqual(replay_turn, 3)
            self.assertEqual([item.id for item in replay_items], ["u1", "a1"])
            self.assertEqual(len(replay_usage), 2)

            usage_summary = asyncio.run(session.get_usage())
            self.assertEqual(usage_summary.entry_count, 2)
            self.assertEqual(usage_summary.total_prompt_tokens, 18)
            self.assertEqual(usage_summary.total_completion_tokens, 3)
            self.assertGreaterEqual(replaced_before_restore, 1)
            self.assertEqual(replaced_after_restore, replaced_before_restore + 1)

    def test_resume_rehydrate_reminder_avoids_immediate_task_nudge(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            session_root = default_session_root("s1", cwd=root)
            offload_root = session_root / "offload"
            path = session_root / "context.jsonl"
            self._append_header_snapshot(path, session_id="s1")

            u1 = ContextItem(
                id="u1",
                item_type=ItemType.USER_MESSAGE,
                message=UserMessage(content="turn1"),
                content_text="turn1",
                token_count=1,
            )
            evt = _build_conversation_event(
                session_id="s1",
                turn_number=10,
                before=_ConversationState.capture([]),
                after_items=[u1],
                offload_root=offload_root,
            )
            _events_jsonl_append(path, evt)

            agent = Agent(
                llm=_FakeChatModel(),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                ),
            )
            session = ChatSession.resume(
                agent,
                session_id="s1",
                cwd=root,
            )
            reminder_item = session._agent._context.inject_due_reminders()
            self.assertIsNone(reminder_item)

    def test_resume_restores_task_details_from_latest_task_tool_in_history(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            store_root = root / "tasks"
            with patch.dict("os.environ", {"COMATE_TASK_STORE_DIR": str(store_root)}):
                legacy_store = TaskStore(list_id="default")
                legacy_store.create_task(subject="new progress")
                legacy_store.create_task(subject="new done")
                legacy_store.update_task("1", status="in_progress")
                legacy_store.update_task("2", status="completed")
                session_root = default_session_root("s1", cwd=root)
                offload_root = session_root / "offload"
                path = session_root / "context.jsonl"
                self._append_header_snapshot(path, session_id="s1")

                task_first = ContextItem(
                    id="t1",
                    item_type=ItemType.TOOL_RESULT,
                    message=ToolMessage(
                        tool_call_id="tc1",
                        tool_name="TaskUpdate",
                        content="first",
                        is_error=False,
                    ),
                    content_text="first",
                    token_count=1,
                    tool_name="TaskUpdate",
                    metadata={
                        "tool_raw_envelope": {
                            "ok": True,
                            "data": {
                                "list_id": "default",
                                "tasks": [
                                    {"id": "1", "subject": "old pending", "status": "pending", "open_blocked_by": []},
                                    {"id": "2", "subject": "old done", "status": "completed", "open_blocked_by": []},
                                ],
                            },
                        }
                    },
                    created_turn=4,
                )
                task_latest = ContextItem(
                    id="t2",
                    item_type=ItemType.TOOL_RESULT,
                    message=ToolMessage(
                        tool_call_id="tc2",
                        tool_name="TaskList",
                        content="latest",
                        is_error=False,
                    ),
                    content_text="latest",
                    token_count=1,
                    tool_name="TaskList",
                    metadata={
                        "tool_raw_envelope": {
                            "ok": True,
                            "data": {
                                "list_id": "default",
                                "tasks": [
                                    {"id": "3", "subject": "new progress", "status": "in_progress", "open_blocked_by": []},
                                    {"id": "4", "subject": "new done", "status": "completed", "open_blocked_by": []},
                                ],
                            },
                        }
                    },
                    created_turn=6,
                )
                evt = _build_conversation_event(
                    session_id="s1",
                    turn_number=8,
                    before=_ConversationState.capture([]),
                    after_items=[task_first, task_latest],
                    offload_root=offload_root,
                )
                _events_jsonl_append(path, evt)

                agent = Agent(
                    llm=_FakeChatModel(),  # type: ignore[arg-type]
                    config=AgentConfig(
                        tools=(),
                        agents=(),
                        offload_enabled=False,
                        setting_sources=None,
                    ),
                )
                session = ChatSession.resume(
                    agent,
                    session_id="s1",
                    cwd=root,
                )

                self.assertEqual(session._agent._task_namespace, "default")
                self.assertEqual(
                    load_session_metadata(session_root),
                    {
                        "session_id": "s1",
                        "task_namespace": "default",
                    },
                )
                task_state = session._agent._context.reminder_engine.get_task_state()
                self.assertEqual(task_state["turn_number_at_update"], 8)
                self.assertEqual(len(task_state["tasks"]), 1)
                self.assertEqual(task_state["tasks"][0]["id"], "1")
                self.assertEqual(task_state["tasks"][0]["subject"], "new progress")
                self.assertEqual(task_state["tasks"][0]["status"], "in_progress")
                self.assertEqual(task_state["tasks"][0]["open_blocked_by"], [])
                self.assertEqual(session._agent._context.reminder_engine.state.last_task_tool_turn, 8)
                self.assertEqual(session._agent._context.reminder_engine.state.task_open_count, 1)

    def test_resume_uses_rehydrate_when_task_payload_shape_is_invalid(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            with patch.dict("os.environ", {"COMATE_TASK_STORE_DIR": str(root / "tasks")}):
                session_root = default_session_root("s1", cwd=root)
                offload_root = session_root / "offload"
                path = session_root / "context.jsonl"
                self._append_header_snapshot(path, session_id="s1")

                task_item = ContextItem(
                    id="t1",
                    item_type=ItemType.TOOL_RESULT,
                    message=ToolMessage(
                        tool_call_id="tc1",
                        tool_name="TaskList",
                        content="invalid task payload",
                        is_error=False,
                    ),
                    content_text="invalid task payload",
                    token_count=1,
                    tool_name="TaskList",
                    metadata={
                        "tool_raw_envelope": {
                            "ok": True,
                            "data": {
                                "list_id": "default",
                                "tasks": "not-a-list",
                            },
                        }
                    },
                    created_turn=5,
                )
                evt = _build_conversation_event(
                    session_id="s1",
                    turn_number=7,
                    before=_ConversationState.capture([]),
                    after_items=[task_item],
                    offload_root=offload_root,
                )
                _events_jsonl_append(path, evt)

                agent = Agent(
                    llm=_FakeChatModel(),  # type: ignore[arg-type]
                    config=AgentConfig(
                        tools=(),
                        agents=(),
                        offload_enabled=False,
                        setting_sources=None,
                    ),
                )
                session = ChatSession.resume(
                    agent,
                    session_id="s1",
                    cwd=root,
                )

                self.assertEqual(session._agent._task_namespace, "default")
                task_state = session._agent._context.reminder_engine.get_task_state()
                self.assertEqual(task_state["tasks"], [])
                self.assertEqual(task_state["turn_number_at_update"], 7)
                self.assertEqual(session._agent._context.reminder_engine.state.task_open_count, 0)
                self.assertEqual(session._agent._context.reminder_engine.state.last_task_tool_turn, 7)

    def test_fork_session_resets_task_namespace_to_new_session_id(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            agent = Agent(
                llm=_FakeChatModel(),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                ),
            )

            session = ChatSession(
                agent,
                session_id="s1",
                cwd=root,
            )
            forked = session.fork_session()

            self.assertEqual(forked._agent._task_namespace, forked.session_id)
            self.assertNotEqual(forked._agent._task_namespace, session._agent._task_namespace)
            self.assertEqual(
                load_session_metadata(forked._storage_root),
                {
                    "session_id": forked.session_id,
                    "task_namespace": forked.session_id,
                },
            )

    def test_resume_requires_header_snapshot(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            session_root = default_session_root("s1", cwd=root)
            path = session_root / "context.jsonl"
            _events_jsonl_append(
                path,
                {
                    "schema_version": PERSISTENCE_SCHEMA_VERSION,
                    "session_id": "s1",
                    "turn_number": 1,
                    "op": "usage_delta",
                    "usage": {"adds": []},
                },
            )
            agent = Agent(
                llm=_FakeChatModel(),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                ),
            )
            with self.assertRaisesRegex(ChatSessionError, "header_snapshot"):
                ChatSession.resume(
                    agent,
                    session_id="s1",
                    cwd=root,
                )

    def test_resume_restores_header_snapshot_over_runtime_initialization(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            session_root = default_session_root("s1", cwd=root)
            path = session_root / "context.jsonl"
            snapshot_ctx = ContextIR()
            snapshot_ctx.set_system_prompt("SNAPSHOT_SYSTEM_PROMPT", cache=False)
            snapshot_ctx.set_memory_usage("SNAPSHOT_MEMORY_USAGE", cache=False)
            snapshot_ctx.set_user_instruction("SNAPSHOT_USER_INSTRUCTION", cache=False)
            self._append_header_snapshot(
                path,
                session_id="s1",
                snapshot=snapshot_ctx.export_header_snapshot(),
            )

            agent = Agent(
                llm=_FakeChatModel(),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                ),
            )
            session = ChatSession.resume(
                agent,
                session_id="s1",
                cwd=root,
            )
            prompt_item = session._agent._context.header.find_one_by_type(ItemType.SYSTEM_PROMPT)
            memory_usage_item = session._agent._context.header.find_one_by_type(ItemType.MEMORY_USAGE)
            env_item = session._agent._context.session_state.find_one_by_type(ItemType.SYSTEM_ENV)
            self.assertIsNotNone(prompt_item)
            self.assertIsNotNone(memory_usage_item)
            self.assertIsNone(env_item)
            self.assertEqual(prompt_item.content_text, "SNAPSHOT_SYSTEM_PROMPT")
            self.assertEqual(memory_usage_item.content_text, "SNAPSHOT_MEMORY_USAGE")
            # user_instruction 不纳入快照，由运行时重新注入（此 agent 未配置 user_instruction）
            self.assertIsNone(session._agent._context.user_instruction_item)
            self.assertIsNotNone(session._agent._context.memory)

    def test_resume_always_rebuilds_session_state_including_env(self) -> None:
        """Resume 时 session_state（env 等）始终运行时刷新，user_instruction 也是。"""
        from comate_agent_sdk.context.env import EnvOptions

        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            session_root = default_session_root("s1", cwd=root)
            path = session_root / "context.jsonl"
            self._append_header_snapshot(path, session_id="s1")

            agent = Agent(
                llm=_FakeChatModel(),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                    user_instruction="DUMMY_USER_INSTRUCTION",
                    env_options=EnvOptions(system_env=True, git_env=True),
                ),
            )

            session = ChatSession.resume(
                agent,
                session_id="s1",
                cwd=root,
            )

            self.assertEqual(session.session_id, "s1")
            # env 在 resume 后被重新注入
            self.assertIsNotNone(
                session._agent._context.session_state.find_one_by_type(ItemType.SYSTEM_ENV)
            )
            # user_instruction="DUMMY" 是字符串（非 UserInstructionConfig），不会注入
            self.assertIsNone(session._agent._context.user_instruction_item)

    def test_runtime_creates_auto_memory_file_for_main_agent(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            session_root = default_session_root("s1", cwd=root)
            agent = Agent(
                llm=_FakeChatModel(),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                ),
            )

            runtime = agent.create_runtime(
                cwd=root,
                session_id="s1",
            )

            auto_memory_path = resolve_auto_memory_dir(runtime) / "MEMORY.md"
            self.assertTrue(auto_memory_path.exists())
            self.assertIsNotNone(runtime._context.memory)

    def test_resume_loads_auto_memory_from_disk_not_snapshot(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            session_root = default_session_root("s1", cwd=root)
            path = session_root / "context.jsonl"
            self._append_header_snapshot(path, session_id="s1")

            auto_memory_path = session_root.parent / "memory" / "MEMORY.md"
            auto_memory_path.parent.mkdir(parents=True, exist_ok=True)
            auto_memory_path.write_text("AUTO_MEMORY_FROM_DISK", encoding="utf-8")

            agent = Agent(
                llm=_FakeChatModel(),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                ),
            )
            session = ChatSession.resume(
                agent,
                session_id="s1",
                cwd=root,
            )

            self.assertIsNone(session._agent._context.user_instruction_item)
            self.assertIsNotNone(session._agent._context.memory)
            self.assertIn("AUTO_MEMORY_FROM_DISK", session._agent._context.memory.content_text)

    def test_clear_history_rebuilds_user_instruction_and_auto_memory(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            session_root = default_session_root("s1", cwd=root)
            user_instruction_file = root / "AGENTS.md"
            user_instruction_file.write_text("USER_INSTRUCTION_TEXT", encoding="utf-8")

            auto_memory_path = session_root.parent / "memory" / "MEMORY.md"
            auto_memory_path.parent.mkdir(parents=True, exist_ok=True)
            auto_memory_path.write_text("AUTO_MEMORY_TEXT", encoding="utf-8")

            agent = Agent(
                llm=_FakeChatModel(),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                    user_instruction=UserInstructionConfig(files=[user_instruction_file]),
                ),
            )
            session = ChatSession(
                agent,
                session_id="s1",
                cwd=root,
            )
            session._agent._context.add_message(UserMessage(content="hello"))

            session.clear_history()

            self.assertIsNotNone(session._agent._context.user_instruction_item)
            self.assertIn(
                "USER_INSTRUCTION_TEXT",
                session._agent._context.user_instruction_item.content_text,
            )
            self.assertIsNotNone(session._agent._context.memory)
            self.assertIn(
                "AUTO_MEMORY_TEXT",
                session._agent._context.memory.content_text,
            )
            memory_usage_item = session._agent._context.header.find_one_by_type(ItemType.MEMORY_USAGE)
            self.assertIsNotNone(memory_usage_item)
            self.assertIn("Persistent auto memory directory", memory_usage_item.content_text)


class TestChatSessionInboxTurnPersistence(unittest.IsolatedAsyncioTestCase):
    async def test_runtime_poll_batches_conversational_team_inbox_events(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            with patch.dict(
                "os.environ",
                {
                    "COMATE_TEAMS_DIR": td,
                    "COMATE_TASK_STORE_DIR": td,
                    "COMATE_TEAM_POLL_INTERVAL_SECONDS": "0.01",
                },
            ):
                agent = Agent(
                    llm=_FakeChatModel(),  # type: ignore[arg-type]
                    config=AgentConfig(
                        tools=(),
                        agents=(),
                        offload_enabled=False,
                        setting_sources=None,
                        cwd=root,
                    ),
                )
                session = ChatSession(
                    agent,
                    session_id="s1",
                    cwd=root,
                )
                session._agent._team_poll_interval_seconds = 0.01
                TeamConfig(team_name="review-team").register_member(
                    name="team-lead",
                    agent_type="leader",
                )
                _switch_parent_to_team_namespace(session._agent, "review-team")

                inbox = Inbox(team_name="review-team", agent_name="team-lead")
                inbox.append_message(from_agent="worker-1", content="first update")
                inbox.append_message(from_agent="worker-2", content="second update")

                previous_callback = session._set_external_turn_callback()
                try:
                    await session._agent._poll_team_inbox_once()
                finally:
                    session._restore_external_turn_callback(previous_callback)

                scheduled = await session._scheduler.schedule_external_turn(
                    dispatch_reason="idle_auto"
                )

        self.assertIsNotNone(scheduled)
        assert scheduled is not None
        self.assertEqual(scheduled.turn.source, "team_inbox")
        messages = scheduled.turn.payload.get("messages")
        self.assertIsInstance(messages, list)
        assert isinstance(messages, list)
        self.assertEqual(len(messages), 2)
        self.assertEqual(messages[0]["content"], "first update")
        self.assertEqual(messages[1]["content"], "second update")
        records = replay_external_turn_journal(
            external_turns_journal_path(session._storage_root)
        )
        enqueued = [record for record in records if record.get("op") == "external_turn_enqueued"]
        self.assertEqual(len(enqueued), 1)

    async def test_runtime_poll_keeps_shutdown_request_as_control_turn(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            with patch.dict(
                "os.environ",
                {
                    "COMATE_TEAMS_DIR": td,
                    "COMATE_TASK_STORE_DIR": td,
                    "COMATE_TEAM_POLL_INTERVAL_SECONDS": "0.01",
                },
            ):
                agent = Agent(
                    llm=_FakeChatModel(),  # type: ignore[arg-type]
                    config=AgentConfig(
                        tools=(),
                        agents=(),
                        offload_enabled=False,
                        setting_sources=None,
                        cwd=root,
                    ),
                )
                session = ChatSession(
                    agent,
                    session_id="s1",
                    cwd=root,
                )
                session._agent._team_poll_interval_seconds = 0.01
                TeamConfig(team_name="review-team").register_member(
                    name="team-lead",
                    agent_type="leader",
                )
                _switch_parent_to_team_namespace(session._agent, "review-team")

                inbox = Inbox(team_name="review-team", agent_name="team-lead")
                inbox.append_message(from_agent="worker-1", content="regular update")
                inbox.append_message(
                    from_agent="worker-2",
                    message_type="shutdown_request",
                    content="please stop",
                )

                previous_callback = session._set_external_turn_callback()
                try:
                    await session._agent._poll_team_inbox_once()
                finally:
                    session._restore_external_turn_callback(previous_callback)

                first = await session._scheduler.schedule_external_turn(
                    dispatch_reason="control"
                )
                assert first is not None
                await session._scheduler.complete_external_turn(
                    turn_id=first.turn.turn_id,
                    dispatch_token=first.dispatch_token,
                )
                second = await session._scheduler.schedule_external_turn(
                    dispatch_reason="idle_auto"
                )

        self.assertIsNotNone(first)
        self.assertIsNotNone(second)
        assert first is not None
        assert second is not None
        self.assertEqual(first.turn.payload.get("message_type"), "shutdown_request")
        self.assertEqual(second.turn.source, "team_inbox")
        self.assertIsInstance(second.turn.payload.get("messages"), list)

    async def test_dynamic_team_mode_switch_starts_poll_and_auto_consumes_inbox(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            with patch.dict(
                "os.environ",
                {
                    "COMATE_TEAMS_DIR": td,
                    "COMATE_TASK_STORE_DIR": td,
                    "COMATE_TEAM_POLL_INTERVAL_SECONDS": "0.01",
                },
            ):
                agent = Agent(
                    llm=_SequenceChatModel(
                        [
                            ChatInvokeCompletion(content="handled after switch"),
                        ]
                    ),  # type: ignore[arg-type]
                    config=AgentConfig(
                        tools=(),
                        agents=(),
                        offload_enabled=False,
                        setting_sources=None,
                        cwd=root,
                    ),
                )
                session = ChatSession(
                    agent,
                    session_id="s1",
                    cwd=root,
                )
                session._agent._team_poll_interval_seconds = 0.01
                TeamConfig(team_name="review-team").register_member(name="team-lead", agent_type="leader")
                _switch_parent_to_team_namespace(session._agent, "review-team")
                Inbox(team_name="review-team", agent_name="team-lead").append_message(
                    from_agent="worker-1",
                    content="follow-up",
                )

                async def _collect_events() -> list[object]:
                    collected: list[object] = []
                    async for event in session.events():
                        collected.append(event)
                        if isinstance(event, StopEvent):
                            break
                    return collected

                events = await asyncio.wait_for(_collect_events(), timeout=3.0)

        self.assertTrue(any(isinstance(event, ExternalTurnPendingEvent) for event in events))
        self.assertTrue(
            any(isinstance(event, TextEvent) and event.content == "handled after switch" for event in events)
        )

    async def test_events_auto_consume_external_turn_when_idle(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            agent = Agent(
                llm=_SequenceChatModel(
                    [
                        ChatInvokeCompletion(content="handled inbox"),
                    ]
                ),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                    cwd=root,
                ),
            )
            session = ChatSession(
                agent,
                session_id="s1",
                cwd=root,
            )

            async def _collect_events() -> list[object]:
                collected: list[object] = []
                async for event in session.events():
                    collected.append(event)
                    if isinstance(event, StopEvent):
                        break
                return collected

            task = asyncio.create_task(_collect_events())
            await asyncio.sleep(0)
            await session.enqueue_external_turn(
                ExternalTurn(
                    turn_id="team_inbox:evt-1",
                    source="team_inbox",
                    source_event_id="evt-1",
                    dedupe_key="team_inbox:evt-1",
                    received_at="2026-03-11T00:00:00+00:00",
                    payload={
                        "from_agent": "worker-1",
                        "message_type": "message",
                        "content": "done",
                        "timestamp": "2026-03-11T00:00:00+00:00",
                    },
                    preview="done",
                )
            )
            events = await asyncio.wait_for(task, timeout=3.0)

        self.assertTrue(any(isinstance(event, ExternalTurnPendingEvent) for event in events))
        self.assertTrue(any(isinstance(event, ExternalTurnScheduledEvent) for event in events))
        self.assertTrue(
            any(isinstance(event, TextEvent) and event.content == "handled inbox" for event in events)
        )

    async def test_resume_requeues_scheduled_external_turn_without_terminal_record(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            agent = Agent(
                llm=_FakeChatModel(),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                    cwd=root,
                ),
            )
            session = ChatSession(
                agent,
                session_id="s1",
                cwd=root,
            )
            turn = ExternalTurn(
                turn_id="team_inbox:evt-1",
                source="team_inbox",
                source_event_id="evt-1",
                dedupe_key="team_inbox:evt-1",
                received_at="2026-03-11T00:00:00+00:00",
                payload={
                    "from_agent": "worker-1",
                    "message_type": "message",
                    "content": "done",
                    "timestamp": "2026-03-11T00:00:00+00:00",
                },
                preview="done",
            )
            await session.enqueue_external_turn(turn)
            session._ensure_header_persisted()
            scheduled = await session._scheduler.schedule_external_turn(dispatch_reason="idle_auto")
            self.assertIsNotNone(scheduled)

            resumed = ChatSession.resume(agent, session_id="s1", cwd=root)
            records = replay_external_turn_journal(external_turns_journal_path(resumed._storage_root))

        self.assertTrue(any(record.get("op") == "external_turn_requeued" for record in records))
        self.assertTrue(resumed._scheduler.has_pending_external_turns())

    async def test_clear_team_namespace_discards_team_external_turn_backlog(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            agent = Agent(
                llm=_FakeChatModel(),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                    cwd=root,
                ),
            )
            runtime = agent.create_runtime(
                session_id="s1",
                name="captain",
                team_name="review-team",
                task_namespace="review-team",
            )
            session = ChatSession(
                agent,
                runtime=runtime,
                session_id="s1",
                cwd=root,
            )
            turn = ExternalTurn(
                turn_id="team_inbox:evt-1",
                source="team_inbox",
                source_event_id="evt-1",
                dedupe_key="team_inbox:evt-1",
                received_at="2026-03-11T00:00:00+00:00",
                payload={
                    "from_agent": "worker-1",
                    "message_type": "message",
                    "content": "done",
                    "timestamp": "2026-03-11T00:00:00+00:00",
                },
                preview="done",
            )
            await session.enqueue_external_turn(turn)
            session._persist_initial_header_snapshot_if_needed()

            self.assertTrue(session._scheduler.has_pending_external_turns())

            _clear_team_namespace(runtime)
            resumed = ChatSession.resume(agent, session_id="s1", cwd=root)
            records = replay_external_turn_journal(external_turns_journal_path(session._storage_root))

        self.assertFalse(resumed._scheduler.has_pending_external_turns())
        self.assertTrue(
            any(
                record.get("op") == "external_turn_failed_terminal"
                and record.get("turn_id") == "team_inbox:evt-1"
                for record in records
            )
        )

    async def test_duplicate_external_turn_is_rejected_while_active_dispatch(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            agent = Agent(
                llm=_FakeChatModel(),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                    cwd=root,
                ),
            )
            session = ChatSession(
                agent,
                session_id="s1",
                cwd=root,
            )
            turn = ExternalTurn(
                turn_id="team_inbox:msg-1",
                source="team_inbox",
                source_event_id="msg-1",
                dedupe_key="team_inbox:msg-1",
                received_at="2026-03-11T00:00:00+00:00",
                payload={
                    "from_agent": "worker-1",
                    "message_type": "message",
                    "content": "done",
                    "timestamp": "2026-03-11T00:00:00+00:00",
                },
                preview="done",
            )

            first = await session.enqueue_external_turn(turn)
            self.assertTrue(first.accepted)
            scheduled = await session._scheduler.schedule_external_turn(dispatch_reason="idle_auto")
            self.assertIsNotNone(scheduled)

            duplicate = await session.enqueue_external_turn(turn)
            self.assertFalse(duplicate.accepted)
            self.assertTrue(duplicate.duplicate)
            self.assertTrue(duplicate.should_ack)

            assert scheduled is not None
            await session._scheduler.complete_external_turn(
                turn_id=turn.turn_id,
                dispatch_token=scheduled.dispatch_token,
            )
            scheduled_again = await session._scheduler.schedule_external_turn(dispatch_reason="idle_auto")

        self.assertIsNone(scheduled_again)

    async def test_chat_session_query_stream_does_not_auto_consume_team_inbox(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            agent = Agent(
                llm=_SequenceChatModel(
                    [
                        ChatInvokeCompletion(content="hello back"),
                    ]
                ),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                    cwd=root,
                ),
            )
            TeamConfig(team_name="review-team").register_member(name="captain", agent_type="leader")
            Inbox(team_name="review-team", agent_name="captain").append_message(
                from_agent="worker-1",
                content="done",
            )
            session = ChatSession(
                agent,
                session_id="s1",
                cwd=root,
            )
            session._agent._team_name = "review-team"
            session._agent._task_namespace = "review-team"

            async for _event in session.query_stream("hello"):
                pass

            resumed = ChatSession.resume(agent, session_id="s1", cwd=root)

        meta_users = [
            item
            for item in resumed._agent._context.conversation.items
            if item.item_type == ItemType.TEAM_INBOX_TURN
        ]
        self.assertEqual(len(meta_users), 0)

    async def test_auto_inbox_turn_persists_as_separate_turn(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            agent = Agent(
                llm=_SequenceChatModel(
                    [
                        ChatInvokeCompletion(content="hello back"),
                        ChatInvokeCompletion(content="handled inbox"),
                    ]
                ),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                    cwd=root,
                ),
            )
            TeamConfig(team_name="review-team").register_member(name="captain", agent_type="leader")
            session = ChatSession(
                agent,
                session_id="s1",
                cwd=root,
            )
            await session.send("hello")
            await session.enqueue_external_turn(
                ExternalTurn(
                    turn_id="team_inbox:msg-1",
                    source="team_inbox",
                    source_event_id="msg-1",
                    dedupe_key="team_inbox:msg-1",
                    received_at="2026-03-11T00:00:00+00:00",
                    payload={
                        "from_agent": "worker-1",
                        "message_type": "message",
                        "content": "done",
                        "timestamp": "2026-03-11T00:00:00+00:00",
                    },
                    preview="done",
                )
            )

            async def _consume_until_two_stops() -> None:
                stop_count = 0
                event_iter = session.events()
                try:
                    async for event in event_iter:
                        if isinstance(event, StopEvent):
                            stop_count += 1
                            if stop_count == 2:
                                break
                finally:
                    await event_iter.aclose()

            await asyncio.wait_for(_consume_until_two_stops(), timeout=5.0)

            resumed = ChatSession.resume(agent, session_id="s1", cwd=root)

        self.assertEqual(resumed._turn_number, 2)
        meta_users = [
            item
            for item in resumed._agent._context.conversation.items
            if item.item_type == ItemType.TEAM_INBOX_TURN
        ]
        self.assertEqual(len(meta_users), 1)

if __name__ == "__main__":
    unittest.main()
