from __future__ import annotations

import asyncio
import logging
from collections import deque
from collections.abc import Callable
from pathlib import Path
from typing import Any

from comate_agent_sdk.agent.events import ExternalTurnPendingEvent
from comate_agent_sdk.agent.external_turns import (
    ExternalTurn,
    ExternalTurnEnqueueResult,
    ScheduledExternalTurn,
    build_lease_expires_at,
    external_turn_to_dict,
    is_control_external_turn,
    make_dispatch_token,
    replay_external_turn_records,
)
from comate_agent_sdk.agent.session_store import (
    PERSISTENCE_SCHEMA_VERSION,
    events_jsonl_append,
    replay_external_turn_journal,
)

logger = logging.getLogger("comate_agent_sdk.agent.session_scheduler")


class SessionScheduler:
    def __init__(
        self,
        *,
        session_id: str,
        journal_path: Path,
        emit_event,
    ) -> None:
        self._session_id = session_id
        self._journal_path = journal_path
        self._emit_event = emit_event
        self._queued_external_turns: deque[ExternalTurn] = deque()
        self._queued_external_turn_ids: set[str] = set()
        self._terminal_turn_ids: set[str] = set()
        self._active_dispatch: tuple[str, str] | None = None
        self._lock = asyncio.Lock()

    def _is_turn_known(self, turn_id: str) -> bool:
        normalized_turn_id = str(turn_id or "").strip()
        if not normalized_turn_id:
            return False
        if normalized_turn_id in self._queued_external_turn_ids:
            return True
        if normalized_turn_id in self._terminal_turn_ids:
            return True
        if self._active_dispatch is None:
            return False
        return self._active_dispatch[0] == normalized_turn_id

    async def enqueue_external_turn(self, turn: ExternalTurn) -> ExternalTurnEnqueueResult:
        async with self._lock:
            if self._is_turn_known(turn.turn_id):
                return ExternalTurnEnqueueResult(
                    accepted=False,
                    duplicate=True,
                    should_ack=True,
                    turn_id=turn.turn_id,
                )
            self._append_record(
                {
                    "schema_version": PERSISTENCE_SCHEMA_VERSION,
                    "session_id": self._session_id,
                    "op": "external_turn_enqueued",
                    "turn": external_turn_to_dict(turn),
                }
            )
            self._queued_external_turns.append(turn)
            self._queued_external_turn_ids.add(turn.turn_id)

        await self._emit_event(
            ExternalTurnPendingEvent(
                turn_id=turn.turn_id,
                source=turn.source,
                dedupe_key=turn.dedupe_key,
                queue_size=self.external_turn_queue_size(),
                can_auto_consume=bool(turn.can_auto_consume),
                preview=turn.preview or None,
                delivery_mode="queued_for_later" if self.external_turn_queue_size() > 1 else "immediate_candidate",
            )
        )
        return ExternalTurnEnqueueResult(
            accepted=True,
            duplicate=False,
            should_ack=True,
            turn_id=turn.turn_id,
        )

    def recover_from_journal(self) -> None:
        records = replay_external_turn_journal(self._journal_path)
        replayed = replay_external_turn_records(records)
        self._terminal_turn_ids = set(replayed.terminal_turn_ids)
        self._queued_external_turns = deque(replayed.queued_turns)
        self._queued_external_turn_ids = {turn.turn_id for turn in replayed.queued_turns}
        for turn in replayed.dangling_scheduled_turns:
            recovered_turn = ExternalTurn(
                turn_id=turn.turn_id,
                source=turn.source,
                source_event_id=turn.source_event_id,
                dedupe_key=turn.dedupe_key,
                received_at=turn.received_at,
                payload=dict(turn.payload),
                can_auto_consume=turn.can_auto_consume,
                retry_count=turn.retry_count + 1,
                preview=turn.preview,
            )
            self._append_record(
                {
                    "schema_version": PERSISTENCE_SCHEMA_VERSION,
                    "session_id": self._session_id,
                    "op": "external_turn_requeued",
                    "reason": "resume_recovery",
                    "turn": external_turn_to_dict(recovered_turn),
                }
            )
            if recovered_turn.turn_id not in self._queued_external_turn_ids:
                self._queued_external_turns.append(recovered_turn)
                self._queued_external_turn_ids.add(recovered_turn.turn_id)

    def has_pending_external_turns(self) -> bool:
        return bool(self._queued_external_turns)

    def external_turn_queue_size(self) -> int:
        return len(self._queued_external_turns)

    def discard_external_turns(
        self,
        *,
        predicate: Callable[[ExternalTurn], bool],
        reason: str,
    ) -> list[str]:
        """Drop queued external turns and mark them terminal in the journal.

        This path is used during lifecycle transitions such as TeamDelete,
        where queued inbox turns must not survive namespace teardown or resume.
        The scheduler is mutated synchronously because callers already execute
        on the owning event loop thread after inbox polling has been invalidated.
        """
        discarded_turn_ids: list[str] = []
        kept_turns: deque[ExternalTurn] = deque()

        while self._queued_external_turns:
            turn = self._queued_external_turns.popleft()
            self._queued_external_turn_ids.discard(turn.turn_id)
            if turn.turn_id in self._terminal_turn_ids:
                continue
            if not predicate(turn):
                kept_turns.append(turn)
                self._queued_external_turn_ids.add(turn.turn_id)
                continue

            self._append_record(
                {
                    "schema_version": PERSISTENCE_SCHEMA_VERSION,
                    "session_id": self._session_id,
                    "op": "external_turn_failed_terminal",
                    "turn_id": turn.turn_id,
                    "reason": reason,
                    "source": turn.source,
                    "source_event_id": turn.source_event_id,
                }
            )
            self._terminal_turn_ids.add(turn.turn_id)
            discarded_turn_ids.append(turn.turn_id)

        self._queued_external_turns = kept_turns
        return discarded_turn_ids

    def has_control_external_turn(self) -> bool:
        return any(is_control_external_turn(turn) for turn in self._queued_external_turns)

    def pop_next_control_external_turn(self) -> ExternalTurn | None:
        for turn in self._queued_external_turns:
            if turn.turn_id in self._terminal_turn_ids:
                self._queued_external_turns.remove(turn)
                self._queued_external_turn_ids.discard(turn.turn_id)
                continue
            if is_control_external_turn(turn):
                self._queued_external_turns.remove(turn)
                self._queued_external_turn_ids.discard(turn.turn_id)
                return turn
        return None

    async def schedule_external_turn(
        self,
        *,
        dispatch_reason: str,
    ) -> ScheduledExternalTurn | None:
        async with self._lock:
            if self._active_dispatch is not None:
                return None
            turn = self.pop_next_control_external_turn()
            while turn is None and self._queued_external_turns:
                candidate = self._queued_external_turns.popleft()
                self._queued_external_turn_ids.discard(candidate.turn_id)
                if candidate.turn_id in self._terminal_turn_ids:
                    continue
                turn = candidate
            if turn is None:
                return None

            dispatch_token = make_dispatch_token()
            lease_expires_at = build_lease_expires_at()
            self._active_dispatch = (turn.turn_id, dispatch_token)
            self._append_record(
                {
                    "schema_version": PERSISTENCE_SCHEMA_VERSION,
                    "session_id": self._session_id,
                    "op": "external_turn_scheduled",
                    "turn_id": turn.turn_id,
                    "dispatch_token": dispatch_token,
                    "dispatch_reason": dispatch_reason,
                    "lease_expires_at": lease_expires_at,
                }
            )
            scheduled = ScheduledExternalTurn(
                turn=turn,
                dispatch_token=dispatch_token,
                lease_expires_at=lease_expires_at,
                dispatch_reason=dispatch_reason,
            )

        return scheduled

    async def complete_external_turn(self, *, turn_id: str, dispatch_token: str) -> bool:
        async with self._lock:
            if self._active_dispatch != (turn_id, dispatch_token):
                return False
            self._append_record(
                {
                    "schema_version": PERSISTENCE_SCHEMA_VERSION,
                    "session_id": self._session_id,
                    "op": "external_turn_completed",
                    "turn_id": turn_id,
                    "dispatch_token": dispatch_token,
                }
            )
            self._terminal_turn_ids.add(turn_id)
            self._active_dispatch = None
        return True

    async def requeue_external_turn(
        self,
        *,
        turn: ExternalTurn,
        dispatch_token: str,
        reason: str,
    ) -> bool:
        async with self._lock:
            if self._active_dispatch != (turn.turn_id, dispatch_token):
                return False
            retried_turn = ExternalTurn(
                turn_id=turn.turn_id,
                source=turn.source,
                source_event_id=turn.source_event_id,
                dedupe_key=turn.dedupe_key,
                received_at=turn.received_at,
                payload=dict(turn.payload),
                can_auto_consume=turn.can_auto_consume,
                retry_count=turn.retry_count + 1,
                preview=turn.preview,
            )
            self._append_record(
                {
                    "schema_version": PERSISTENCE_SCHEMA_VERSION,
                    "session_id": self._session_id,
                    "op": "external_turn_requeued",
                    "reason": reason,
                    "turn": external_turn_to_dict(retried_turn),
                }
            )
            self._queued_external_turns.appendleft(retried_turn)
            self._queued_external_turn_ids.add(retried_turn.turn_id)
            self._active_dispatch = None
        return True

    def _append_record(self, record: dict[str, Any]) -> None:
        events_jsonl_append(self._journal_path, record)
