from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import TYPE_CHECKING

from comate_agent_sdk.agent.session_store import normalize_cwd
from comate_agent_sdk.llm.messages import ToolCall, ToolMessage, UserMessage

logger = logging.getLogger("comate_agent_sdk.agent")

_AUTO_MEMORY_DIR = "memory"
_AUTO_MEMORY_FILE = "MEMORY.md"

if TYPE_CHECKING:
    from comate_agent_sdk.agent.core import AgentRuntime


def setup_tool_strategy(agent: "AgentRuntime") -> None:
    """设置工具策略提示（写入 ContextIR header）。"""
    from comate_agent_sdk.agent.tool_strategy import generate_tool_strategy

    tool_strategy = generate_tool_strategy(
        agent.options.tools,
        is_subagent=bool(getattr(agent, "_is_subagent", False)),
        is_team_member=bool(getattr(agent, "is_team_member", False)),
    )
    if tool_strategy:
        agent._context.set_tool_strategy(tool_strategy)


def setup_memory_usage(agent: "AgentRuntime") -> None:
    """设置 memory usage 静态提示（写入 ContextIR header）。"""
    prompt = agent._resolve_memory_usage_prompt()
    if prompt:
        agent._context.set_memory_usage(prompt, cache=True)


def setup_subagents(agent: "AgentRuntime") -> None:
    """设置 Subagent 支持

    1. 生成 Subagent 策略提示并写入 ContextIR header
    2. 创建 Agent 工具并添加到 tools 列表
    """
    from comate_agent_sdk.subagent.prompts import generate_subagent_prompt
    from comate_agent_sdk.subagent.agent_tool import create_agent_tool

    if not agent.options.agents or agent.options.tool_registry is None:
        return

    agent_tools = [t for t in agent.options.tools if t.name == "Agent"]
    user_agent_tools = [
        t
        for t in agent_tools
        if getattr(t, "_comate_agent_sdk_internal", False) is not True
    ]
    if user_agent_tools:
        raise ValueError(
            "启用 subagent 时检测到用户提供了同名工具 'Agent'。"
            "'Agent' 为 subagent 调度保留名，SDK 会注入系统 Agent 工具，禁止静默替换。"
            "解决方式：1) 将你的工具改名（不要叫 'Agent'）；"
            "2) 显式禁用 subagent（例如 agents=[]/()）；"
            "3) 或移除/调整 .agent/subagents 下的定义。"
        )

    # 生成 Subagent 策略提示并写入 ContextIR header
    subagent_prompt = generate_subagent_prompt(agent.options.agents)
    lock_header = bool(getattr(agent, "_lock_header_from_snapshot", False))
    if not lock_header:
        agent._context.set_subagent_strategy(subagent_prompt)

    # 避免重复添加 Agent 工具
    agent.options.tools[:] = [
        t
        for t in agent.options.tools
        if t.name != "Agent" or getattr(t, "_comate_agent_sdk_internal", False) is not True
    ]
    agent._tool_map.pop("Agent", None)

    # 创建 Agent 工具（根据配置决定是否流式）
    agent_tool = create_agent_tool(
        agents=agent.options.agents,
        parent_tools=agent.options.tools,
        tool_registry=agent.options.tool_registry,  # type: ignore[arg-type]
        parent_cwd=normalize_cwd(agent.options.cwd),
        parent_llm=agent.llm,
        parent_dependency_overrides=agent.options.dependency_overrides,  # type: ignore
        parent_llm_levels=agent.options.llm_levels,
        parent_token_cost=agent._token_cost,
        parent_runtime=agent,
        use_streaming_task=agent.options.use_streaming_task,
        parent_user_instruction=agent.options.user_instruction,
        parent_env_options=agent.options.env_options,
    )

    # 添加到工具列表
    agent.options.tools.append(agent_tool)
    agent._tool_map[agent_tool.name] = agent_tool

    logger.info(
        f"Initialized {len(agent.options.agents)} subagents: {[a.name for a in agent.options.agents]}"
    )

def setup_user_instruction(agent: "AgentRuntime") -> None:
    """设置 user_instruction 静态背景知识。"""
    from comate_agent_sdk.context.memory import (
        UserInstructionConfig,
        load_user_instruction_content,
    )

    if not isinstance(agent.options.user_instruction, UserInstructionConfig):
        logger.warning("user_instruction 参数不是 UserInstructionConfig 实例，跳过初始化")
        return

    # 加载文件内容
    content = load_user_instruction_content(agent.options.user_instruction)
    if not content:
        logger.warning("未能加载任何 user_instruction 内容")
        return

    # Token 检查
    token_count = agent._context.token_counter.count(content)
    if token_count > agent.options.user_instruction.max_tokens:
        logger.warning(
            f"User instruction 内容超出 token 上限: {token_count} > {agent.options.user_instruction.max_tokens} "
            f"(不会截断，但可能影响上下文预算)"
        )

    # 写入 ContextIR
    agent._context.set_user_instruction(
        content,
        cache=agent.options.user_instruction.cache,
    )
    logger.info(
        f"User instruction 已加载: {token_count} tokens 来自 {len(agent.options.user_instruction.files)} 个文件"
    )


def _resolve_session_root(agent: "AgentRuntime") -> Path:
    from comate_agent_sdk.agent.session_store import resolve_session_root

    return resolve_session_root(
        session_id=agent.options.session_id or agent._session_id,
        cwd=normalize_cwd(agent.options.cwd),
    )


def resolve_auto_memory_dir(agent: "AgentRuntime") -> Path:
    """解析 auto memory 目录（项目级持久化）。"""
    session_root = _resolve_session_root(agent).resolve()
    return (session_root.parent / _AUTO_MEMORY_DIR).resolve()


def setup_auto_memory(agent: "AgentRuntime") -> None:
    """主 agent 自动加载项目级 auto memory 并注入 ItemType.MEMORY。"""
    if bool(getattr(agent, "_is_subagent", False)):
        return

    try:
        memory_dir = resolve_auto_memory_dir(agent)
        memory_dir.mkdir(parents=True, exist_ok=True)
        memory_file = (memory_dir / _AUTO_MEMORY_FILE).resolve()
        if not memory_file.exists():
            memory_file.touch()
            logger.info(f"已创建 auto memory 文件: {memory_file}")
    except Exception as e:
        logger.warning(f"初始化 auto memory 目录失败: {e}")
        return

    try:
        content = memory_file.read_text(encoding="utf-8")
    except Exception as e:
        logger.warning(f"读取 auto memory 文件失败: {memory_file}: {e}")
        return

    agent._context.set_auto_memory(content, source_path=str(memory_file))
    token_count = agent._context.token_counter.count(content) if content.strip() else 0
    logger.info(f"Auto memory 已加载: {token_count} tokens 来自 {memory_file}")


def setup_skills(agent: "AgentRuntime") -> None:
    """设置 Skill 支持（基于模板已解析结果进行 prompt 注入 + Skill tool 创建）。"""
    from comate_agent_sdk.skill import create_skill_tool
    from comate_agent_sdk.skill.prompts import generate_skill_prompt

    if not agent.options.skills:
        return

    # 生成 Skill 策略提示并写入 ContextIR header
    skill_prompt = generate_skill_prompt(agent.options.skills)
    lock_header = bool(getattr(agent, "_lock_header_from_snapshot", False))
    if not lock_header and skill_prompt:  # 只有当有 active skills 时才注入
        agent._context.set_skill_strategy(skill_prompt)

    # 避免重复添加 Skill 工具（例如用户手动传入 tools 里已包含 Skill）
    agent.options.tools[:] = [t for t in agent.options.tools if t.name != "Skill"]
    agent._tool_map.pop("Skill", None)

    # 创建 Skill 工具（现在只包含简洁描述）
    skill_tool = create_skill_tool(agent.options.skills)
    agent.options.tools.append(skill_tool)
    agent._tool_map[skill_tool.name] = skill_tool

    logger.info(
        f"Initialized {len(agent.options.skills)} skill(s): {[s.name for s in agent.options.skills]}"
    )


async def execute_skill_call(agent: "AgentRuntime", tool_call: ToolCall) -> ToolMessage:
    """执行 Skill 调用（特殊处理）。"""
    args = json.loads(tool_call.function.arguments)
    skill_name = args.get("skill_name")

    # 查找 Skill
    skill_def = (
        next((s for s in agent.options.skills if s.name == skill_name), None)
        if agent.options.skills
        else None
    )
    if not skill_def:
        return ToolMessage(
            tool_call_id=tool_call.id,
            tool_name="Skill",
            content=f"Error: Unknown skill '{skill_name}'",
            is_error=True,
        )

    # 准备待注入的消息（将在 ToolMessage 添加到 context 后注入）
    metadata = (
        f'<skill-message>The "{skill_name}" skill is loading</skill-message>\n'
        f"<skill-name>{skill_name}</skill-name>"
    )
    full_prompt = skill_def.get_prompt()

    # 通过 ContextIR 管理 pending skill items
    agent._context.add_skill_injection(
        skill_name=skill_name,
        metadata_msg=UserMessage(content=metadata, is_meta=False),
        prompt_msg=UserMessage(content=full_prompt, is_meta=True),
    )

    # 返回 ToolMessage（调用方会先添加这个，再 flush pending items）
    return ToolMessage(
        tool_call_id=tool_call.id,
        tool_name="Skill",
        content=f"Skill '{skill_name}' loaded successfully and will remain active",
        is_error=False,
    )


def rebuild_skill_tool(agent: "AgentRuntime") -> None:
    """重建 Skill 工具（用于 Subagent Skills 筛选后更新工具描述）。"""
    from comate_agent_sdk.skill import create_skill_tool, generate_skill_prompt

    # 1. 移除旧的 Skill 工具
    agent.options.tools[:] = [t for t in agent.options.tools if t.name != "Skill"]
    agent._tool_map.pop("Skill", None)

    # 2. 移除 IR 中的旧 Skill 策略
    agent._context.remove_skill_strategy()

    # 3. 如果还有 skills，重新生成
    if agent.options.skills:
        skill_prompt = generate_skill_prompt(agent.options.skills)
        if skill_prompt:
            # 写入 IR header
            agent._context.set_skill_strategy(skill_prompt)

        # 创建新的 Skill 工具
        skill_tool = create_skill_tool(agent.options.skills)
        agent.options.tools.append(skill_tool)
        agent._tool_map["Skill"] = skill_tool

        logger.debug(f"Rebuilt Skill tool with {len(agent.options.skills)} skill(s)")
    else:
        logger.debug("Removed Skill tool (no skills remaining)")


def remove_skill_strategy(agent: "AgentRuntime") -> None:
    """辅助函数：仅移除 skill_strategy（用于调试/外部调用）。"""
    agent._context.remove_skill_strategy()
