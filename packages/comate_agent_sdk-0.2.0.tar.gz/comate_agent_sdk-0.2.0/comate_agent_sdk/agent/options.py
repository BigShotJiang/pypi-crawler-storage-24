from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from types import MappingProxyType
from typing import Any, Literal, Mapping

from comate_agent_sdk.agent.compaction import CompactionConfig
from comate_agent_sdk.agent.llm_levels import LLMLevel
from comate_agent_sdk.agent.system_prompt import SystemPromptType
from comate_agent_sdk.context.env import EnvOptions
from comate_agent_sdk.context.offload import OffloadPolicy
from comate_agent_sdk.llm.base import BaseChatModel, ToolChoice
from comate_agent_sdk.tools.decorator import Tool
from comate_agent_sdk.utils.paths import PathInput


def _freeze_value(value: Any) -> Any:
    if isinstance(value, Mapping):
        return MappingProxyType({k: _freeze_value(v) for k, v in value.items()})
    if isinstance(value, list):
        return tuple(_freeze_value(v) for v in value)
    if isinstance(value, tuple):
        return tuple(_freeze_value(v) for v in value)
    if isinstance(value, set):
        return frozenset(_freeze_value(v) for v in value)
    if isinstance(value, frozenset):
        return frozenset(_freeze_value(v) for v in value)
    return value


@dataclass(frozen=True, slots=True)
class AgentConfig:
    """不可变 Agent 配置（Template 层）。"""

    # LLM/tool/system prompt
    tools: tuple[Tool | str, ...] | None = None
    system_prompt: SystemPromptType = None
    max_iterations: int = 200
    tool_choice: ToolChoice = "auto"
    compaction: CompactionConfig | None = None
    include_cost: bool = False
    emit_compaction_meta_events: bool = False
    dependency_overrides: Mapping[str, Any] | None = None

    # Ephemeral
    ephemeral_storage_path: Path | None = None
    ephemeral_keep_recent: int | None = None

    # Context FileSystem / offload
    offload_enabled: bool = True
    offload_token_threshold: int = 2000
    offload_policy: OffloadPolicy | None = None

    # LLM retries
    llm_max_retries: int = 5
    llm_retry_base_delay: float = 1.0
    llm_retry_max_delay: float = 60.0
    llm_retryable_status_codes: frozenset[int] = field(
        default_factory=lambda: frozenset({429, 500, 502, 503, 504})
    )

    # Subagent
    agents: tuple[Any, ...] | None = None  # tuple[AgentDefinition, ...]
    cwd: PathInput = field(default_factory=lambda: Path.cwd().expanduser().resolve())

    # Agent (subagent) 并行执行配置
    task_parallel_enabled: bool = True
    task_parallel_max_concurrency: int = 4
    use_streaming_task: bool = False
    """是否使用流式 Agent（发射 SubagentToolCallEvent 等子事件，用于实时 UI 显示）"""

    # Skills / user instruction
    skills: tuple[Any, ...] | None = None  # tuple[SkillDefinition, ...]
    user_instruction: object | None = None  # UserInstructionConfig

    # Settings / env
    setting_sources: tuple[Literal["user", "project", "local"], ...] | None = (
        "user",
        "project",
        "local",
    )
    permission_mode: str = "default"
    tool_approval_callback: Any | None = None
    env_options: EnvOptions | None = None

    # MCP
    mcp_enabled: bool = True
    mcp_servers: Any = None

    # LLM levels + session
    llm_levels: Mapping[LLMLevel, BaseChatModel] | None = None
    session_id: str | None = None
    task_namespace: str | None = None
    role: str | None = None
    permission_rules_allow: tuple[str, ...] | None = None
    permission_rules_deny: tuple[str, ...] | None = None

    def __post_init__(self) -> None:
        from comate_agent_sdk.agent.session_store import normalize_cwd

        object.__setattr__(self, "tools", _freeze_value(self.tools))
        object.__setattr__(self, "dependency_overrides", _freeze_value(self.dependency_overrides))
        object.__setattr__(self, "llm_retryable_status_codes", frozenset(self.llm_retryable_status_codes))
        object.__setattr__(self, "agents", _freeze_value(self.agents))
        object.__setattr__(self, "skills", _freeze_value(self.skills))
        object.__setattr__(self, "mcp_servers", _freeze_value(self.mcp_servers))
        object.__setattr__(self, "llm_levels", _freeze_value(self.llm_levels))
        object.__setattr__(self, "permission_rules_allow", _freeze_value(self.permission_rules_allow))
        object.__setattr__(self, "permission_rules_deny", _freeze_value(self.permission_rules_deny))
        object.__setattr__(self, "cwd", normalize_cwd(self.cwd))


@dataclass
class RuntimeAgentOptions:
    """运行态可变配置（Runtime 层）。"""

    # LLM/tool/system prompt
    tools: list[Tool | str] | None = None
    system_prompt: SystemPromptType = None
    max_iterations: int = 200
    tool_choice: ToolChoice = "auto"
    compaction: CompactionConfig | None = None
    include_cost: bool = False
    emit_compaction_meta_events: bool = False
    dependency_overrides: dict | None = None

    # Ephemeral
    ephemeral_storage_path: Path | None = None
    ephemeral_keep_recent: int | None = None

    # Context FileSystem / offload
    offload_enabled: bool = True
    offload_token_threshold: int = 2000
    offload_policy: OffloadPolicy | None = None

    # LLM retries
    llm_max_retries: int = 5
    llm_retry_base_delay: float = 1.0
    llm_retry_max_delay: float = 60.0
    llm_retryable_status_codes: set[int] = field(
        default_factory=lambda: {429, 500, 502, 503, 504}
    )

    # Subagent
    agents: list | None = None  # list[AgentDefinition]
    tool_registry: object | None = None  # ToolRegistry
    cwd: Path | None = None

    # Agent (subagent) 并行执行配置
    task_parallel_enabled: bool = True
    task_parallel_max_concurrency: int = 4
    use_streaming_task: bool = False
    """是否使用流式 Agent（发射 SubagentToolCallEvent 等子事件，用于实时 UI 显示）"""

    # Skills / user instruction
    skills: list | None = None  # list[SkillDefinition]
    user_instruction: object | None = None  # UserInstructionConfig

    # Settings / env
    setting_sources: tuple[Literal["user", "project", "local"], ...] | None = (
        "user",
        "project",
        "local",
    )
    permission_mode: str = "default"
    tool_approval_callback: Any | None = None
    env_options: EnvOptions | None = None

    # MCP
    mcp_enabled: bool = True
    mcp_servers: Any = None

    # LLM levels + session
    llm_levels: dict[LLMLevel, BaseChatModel] | None = None
    session_id: str | None = None
    task_namespace: str | None = None
    team_name: str = ""
    role: str | None = None
    plan_mode_prompt_template: str | None = None
    permission_rules_allow: list[str] | None = None
    permission_rules_deny: list[str] | None = None


def _thaw_mapping(value: Mapping[str, Any] | None) -> dict[str, Any] | None:
    if value is None:
        return None
    return {k: v for k, v in value.items()}


def build_runtime_options(
    *,
    config: AgentConfig,
    resolved_agents: tuple[Any, ...] | None,
    resolved_skills: tuple[Any, ...] | None,
    resolved_user_instruction: object | None,
    resolved_llm_levels: Mapping[LLMLevel, BaseChatModel] | None,
    cwd: PathInput | None,
    session_id: str | None,
    task_namespace: str | None,
    team_name: str = "",
    resolved_settings: object | None = None,
) -> RuntimeAgentOptions:
    from comate_agent_sdk.agent.session_store import normalize_cwd

    settings_allow: list[str] | None = None
    settings_deny: list[str] | None = None
    if resolved_settings is not None:
        settings_allow = list(getattr(resolved_settings, "permissions_allow", None) or []) or None
        settings_deny = list(getattr(resolved_settings, "permissions_deny", None) or []) or None

    resolved_cwd = normalize_cwd(cwd if cwd is not None else config.cwd)

    return RuntimeAgentOptions(
        tools=list(config.tools) if config.tools is not None else None,
        system_prompt=config.system_prompt,
        max_iterations=config.max_iterations,
        tool_choice=config.tool_choice,
        compaction=config.compaction,
        include_cost=config.include_cost,
        emit_compaction_meta_events=config.emit_compaction_meta_events,
        dependency_overrides=_thaw_mapping(config.dependency_overrides),
        ephemeral_storage_path=config.ephemeral_storage_path,
        ephemeral_keep_recent=config.ephemeral_keep_recent,
        offload_enabled=config.offload_enabled,
        offload_token_threshold=config.offload_token_threshold,
        offload_policy=config.offload_policy,
        llm_max_retries=config.llm_max_retries,
        llm_retry_base_delay=config.llm_retry_base_delay,
        llm_retry_max_delay=config.llm_retry_max_delay,
        llm_retryable_status_codes=set(config.llm_retryable_status_codes),
        agents=list(resolved_agents) if resolved_agents is not None else None,
        tool_registry=None,
        cwd=resolved_cwd,
        task_parallel_enabled=config.task_parallel_enabled,
        task_parallel_max_concurrency=config.task_parallel_max_concurrency,
        use_streaming_task=config.use_streaming_task,
        skills=list(resolved_skills) if resolved_skills is not None else None,
        user_instruction=resolved_user_instruction,
        setting_sources=config.setting_sources,
        permission_mode=config.permission_mode,
        tool_approval_callback=config.tool_approval_callback,
        env_options=config.env_options,
        mcp_enabled=config.mcp_enabled,
        mcp_servers=config.mcp_servers,
        llm_levels=dict(resolved_llm_levels) if resolved_llm_levels is not None else None,
        session_id=session_id,
        task_namespace=task_namespace,
        team_name=team_name,
        role=config.role,
        permission_rules_allow=(
            list(config.permission_rules_allow)
            if config.permission_rules_allow is not None
            else settings_allow
        ),
        permission_rules_deny=(
            list(config.permission_rules_deny)
            if config.permission_rules_deny is not None
            else settings_deny
        ),
    )
