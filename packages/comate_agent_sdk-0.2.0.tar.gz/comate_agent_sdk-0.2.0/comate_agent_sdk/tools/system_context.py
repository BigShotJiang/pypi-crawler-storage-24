"""
System tool context for built-in Claude Code style tools.

设计目标：
- 为内置系统工具提供稳定的 project_root 与默认工作目录
- 通过 contextvars 在单次 tool call 执行期间注入上下文（并发安全）
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Iterator

from comate_agent_sdk.tokens import TokenCost
from comate_agent_sdk.utils.paths import PathInput, normalize_path_input

if TYPE_CHECKING:
    from comate_agent_sdk.agent.interrupt import SessionRunController
    from comate_agent_sdk.system_tools.task import TaskStore
    from comate_agent_sdk.llm.base import BaseChatModel
    from comate_agent_sdk.context.ir import ContextIR

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class SystemToolContext:
    project_root: Path
    session_id: str = "default"
    session_root: Path | None = None
    workspace_root: Path | None = None
    active_plan_path: Path | None = None
    agent_name: str | None = None
    subagent_name: str | None = None
    tool_call_id: str | None = None
    subagent_source_prefix: str | None = None
    token_cost: TokenCost | None = None
    llm_levels: dict[str, "BaseChatModel"] | None = None
    agent_context: "ContextIR | None" = None
    task_store: "TaskStore | None" = None
    extra_write_roots: tuple[Path, ...] = ()
    extra_read_roots: tuple[Path, ...] = ()
    run_controller: "SessionRunController | None" = None
    team_name: str = ""
    team_namespace_switcher: Callable[[str], None] | None = field(
        default=None, hash=False, compare=False,
    )
    team_session_lister: Callable[[str], list[str]] | None = field(
        default=None, hash=False, compare=False,
    )


_SYSTEM_TOOL_CONTEXT: ContextVar[SystemToolContext | None] = ContextVar(
    "comate_agent_sdk_system_tool_context",
    default=None,
)


def _normalize_optional_path(value: PathInput | None, *, field_name: str) -> Path | None:
    if value is None:
        return None
    return normalize_path_input(value, field_name=field_name)


def _normalize_path_roots(
    values: tuple[PathInput, ...],
    *,
    field_name: str,
) -> tuple[Path, ...]:
    normalized: list[Path] = []
    for index, value in enumerate(values):
        normalized.append(
            normalize_path_input(value, field_name=f"{field_name}[{index}]"),
        )
    return tuple(normalized)


def get_system_tool_context() -> SystemToolContext:
    """Dependency provider for system tools.

    Notes:
        - 由 Agent 在执行 tool call 时注入（见 Agent._execute_tool_call）
        - 当用户直接调用 Tool.execute（例如单元测试）时，也可以手动注入
    """
    ctx = _SYSTEM_TOOL_CONTEXT.get()
    if ctx is None:
        raise RuntimeError(
            "SystemToolContext 未注入。请通过 Agent 执行工具，或在测试中使用 bind_system_tool_context()。"
        )
    return ctx


@contextmanager
def bind_system_tool_context(
    *,
    project_root: PathInput,
    session_id: str = "default",
    session_root: PathInput | None = None,
    workspace_root: PathInput | None = None,
    active_plan_path: PathInput | None = None,
    agent_name: str | None = None,
    subagent_name: str | None = None,
    tool_call_id: str | None = None,
    subagent_source_prefix: str | None = None,
    token_cost: TokenCost | None = None,
    llm_levels: dict[str, "BaseChatModel"] | None = None,
    agent_context: "ContextIR | None" = None,
    task_store: "TaskStore | None" = None,
    extra_write_roots: tuple[PathInput, ...] = (),
    extra_read_roots: tuple[PathInput, ...] = (),
    run_controller: "SessionRunController | None" = None,
    team_name: str = "",
    team_namespace_switcher: Callable[[str], None] | None = None,
    team_session_lister: Callable[[str], list[str]] | None = None,
) -> Iterator[None]:
    """临时注入 SystemToolContext（并发安全）。"""
    root = normalize_path_input(project_root, field_name="project_root")
    resolved_session_root = _normalize_optional_path(session_root, field_name="session_root")

    if workspace_root is not None:
        resolved_workspace_root = normalize_path_input(
            workspace_root,
            field_name="workspace_root",
        )
    elif resolved_session_root is not None:
        resolved_workspace_root = (resolved_session_root / "workspace").resolve()
    else:
        resolved_workspace_root = (root / ".agent_workspace").resolve()
    resolved_active_plan_path = _normalize_optional_path(
        active_plan_path,
        field_name="active_plan_path",
    )

    normalized_extra_write_roots = _normalize_path_roots(
        extra_write_roots,
        field_name="extra_write_roots",
    )
    normalized_extra_read_roots = _normalize_path_roots(
        extra_read_roots,
        field_name="extra_read_roots",
    )

    token = _SYSTEM_TOOL_CONTEXT.set(
        SystemToolContext(
            project_root=root,
            session_id=session_id,
            session_root=resolved_session_root,
            workspace_root=resolved_workspace_root,
            active_plan_path=resolved_active_plan_path,
            agent_name=agent_name,
            subagent_name=subagent_name,
            tool_call_id=tool_call_id,
            subagent_source_prefix=subagent_source_prefix,
            token_cost=token_cost,
            llm_levels=llm_levels,
            agent_context=agent_context,
            task_store=task_store,
            extra_write_roots=normalized_extra_write_roots,
            extra_read_roots=normalized_extra_read_roots,
            run_controller=run_controller,
            team_name=team_name,
            team_namespace_switcher=team_namespace_switcher,
            team_session_lister=team_session_lister,
        )
    )
    try:
        yield
    finally:
        _SYSTEM_TOOL_CONTEXT.reset(token)
