"""Team 工具 — TeamCreate / TeamDelete / SendMessage。

TeamCreate/TeamDelete: 显式 Team 生命周期管理（仅主 agent 可用）。
SendMessage: Team 模式下的通信工具。

非 Team 模式下调用通信工具会返回错误提示，而非 RuntimeError。
"""

from __future__ import annotations

import logging
import os
import re
import shutil
from typing import Annotated, Any

from pydantic import BaseModel, Field

from comate_agent_sdk.system_tools.team.config import TeamConfig, resolve_teams_base_dir
from comate_agent_sdk.system_tools.team.identity import (
    normalize_agent_name,
    resolve_context_team_agent_name,
)
from comate_agent_sdk.system_tools.team.inbox import Inbox, MessageType, get_all_inboxes
from comate_agent_sdk.system_tools.tool_result import err, ok
from comate_agent_sdk.tools.decorator import tool
from comate_agent_sdk.tools.depends import Depends
from comate_agent_sdk.tools.system_context import SystemToolContext, get_system_tool_context

logger = logging.getLogger(__name__)

_BROADCAST_TARGET = "all"

# ── team_name 校验 ──────────────────────────────────────────────────────

_TEAM_NAME_PATTERN = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_-]*$")
_TEAM_NAME_BLACKLIST = frozenset({"none", "null", "undefined", "true", "false"})


def validate_team_name(raw: str) -> tuple[str, str | None]:
    """校验 team_name，返回 (normalized_name, error_message)。

    error_message 为 None 表示合法。
    """
    name = raw.strip()
    if not name:
        return "", "team_name 不能为空"
    if name.lower() in _TEAM_NAME_BLACKLIST:
        return "", f"team_name '{raw}' 是保留值，不允许使用"
    if "/" in name or "\\" in name or os.sep in name:
        return "", f"team_name '{raw}' 包含路径分隔符，不允许使用"
    if not _TEAM_NAME_PATTERN.match(name):
        return "", (
            f"team_name '{raw}' 不符合命名规范。"
            f"要求：字母或数字开头，仅允许字母、数字、下划线和连字符"
        )
    return name, None


_TEAM_CREATE_USAGE_RULES = """## When to Use

Use this tool proactively whenever:
- The user explicitly asks to use a team, swarm, or group of agents
- The user mentions wanting agents to work together, coordinate, or collaborate
- A task is complex enough that it would benefit from parallel work by multiple agents (e.g., building a full-stack feature with frontend and backend work, refactoring a codebase while keeping tests passing, implementing a multi-step project with research, planning, and coding phases)

When in doubt about whether a task warrants a team, prefer spawning a team.

## Choosing Agent Types for Teammates

When spawning teammates via the Agent tool, choose the \`subagent_type\` based on what tools the agent needs for its task. Each agent type has a different set of available tools — match the agent to the work:

- **Read-only agents** (e.g., Explorer, Plan) cannot edit or write files. Only assign them research, search, or planning tasks. Never assign them implementation work.
- **Full-capability agents** (e.g., general-purpose) have access to all tools including file editing, writing, and bash. Use these for tasks that require making changes.
- **Custom agents** defined in \`.agent/agents/\` may have their own tool restrictions. Check their descriptions to understand what they can and cannot do.

Always review the agent type descriptions and their available tools listed in the Agent tool prompt before selecting a \`subagent_type\` for a teammate.

Create a new team to coordinate multiple agents working on a project. Teams have a 1:1 correspondence with task lists (Team = TaskList).

\`\`\`
{
  "team_name": "my-project",
  "description": "Working on feature X"
}
\`\`\`

This creates:
- A team file at \`~/.agent/teams/{team-name}.json\`
- A corresponding task list directory at \`~/.agent/tasks/{team-name}/\`

## Team Workflow

1. **Create a team** with TeamCreate - this creates both the team and its task list
2. **Create tasks** using the Task tools (TaskCreate, TaskList, etc.) - they automatically use the team's task list
3. **Spawn teammates** using the Agent tool with \`team_name\` and \`name\` parameters to create teammates that join the team
4. **Assign tasks** using TaskUpdate with \`owner\` to give tasks to idle teammates
5. **Teammates work on assigned tasks** and mark them completed via TaskUpdate
6. **Teammates go idle between turns** - after each turn, teammates automatically go idle and send a notification. IMPORTANT: Be patient with idle teammates! Don't comment on their idleness until it actually impacts your work.
7. **Shutdown your team** - when the task is completed, gracefully shut down your teammates via SendMessage with type: "shutdown_request".

## Task Ownership

Tasks are assigned using TaskUpdate with the \`owner\` parameter. Any agent can set or change task ownership via TaskUpdate.

## Automatic Message Delivery

**IMPORTANT**: Messages from teammates are automatically delivered to you. You do NOT need to manually check your inbox.

When you spawn teammates:
- They will send you messages when they complete tasks or need help
- These messages appear automatically as new conversation turns (like user messages)
- If you're busy (mid-turn), messages are queued and delivered when your turn ends
- The UI shows a brief notification with the sender's name when messages are waiting

Messages will be delivered automatically.

When reporting on teammate messages, you do NOT need to quote the original message—it's already rendered to the user.

## Teammate Idle State

Teammates go idle after every turn—this is completely normal and expected. A teammate going idle immediately after sending you a message does NOT mean they are done or unavailable. Idle simply means they are waiting for input.

- **Idle teammates can receive messages.** Sending a message to an idle teammate wakes them up and they will process it normally.
- **Idle notifications are automatic.** The system sends an idle notification whenever a teammate's turn ends. You do not need to react to idle notifications unless you want to assign new work or send a follow-up message.
- **Do not treat idle as an error.** A teammate sending a message and then going idle is the normal flow—they sent their message and are now waiting for a response.
- **Peer DM visibility.** When a teammate sends a DM to another teammate, a brief summary is included in their idle notification. This gives you visibility into peer collaboration without the full message content. You do not need to respond to these summaries — they are informational.

## Discovering Team Members

Teammates can read the team config file to discover other team members:
- **Team config location**: \`~/.agent/teams/{team-name}/config.json\`

The config file contains a \`members\` array with each teammate's:
- \`name\`: Human-readable name (**always use this** for messaging and task assignment)
- \`agentId\`: Unique identifier (for reference only - do not use for communication)
- \`agentType\`: Role/type of the agent

**IMPORTANT**: Always refer to teammates by their NAME (e.g., "team-lead", "researcher", "tester"). Names are used for:
- \`target_agent_id\` when sending messages
- Identifying task owners

Example of reading team config:
\`\`\`
Use the Read tool to read ~/.agent/teams/{team-name}/config.json
\`\`\`

## Task List Coordination

Teams share a task list that all teammates can access at \`~/.agent/tasks/{team-name}/\`.

Teammates should:
1. Check TaskList periodically, **especially after completing each task**, to find available work or see newly unblocked tasks
   In Team mode, TaskList may intentionally block for about 5 seconds to reduce aggressive polling. Avoid spamming it; the delay is configurable via `COMATE_TASKLIST_TEAM_BLOCK_SECONDS`.
2. Claim unassigned, unblocked tasks with TaskUpdate (set \`owner\` to your name). **Prefer tasks in ID order** (lowest ID first) when multiple tasks are available, as earlier tasks often set up context for later ones
3. Update existing tasks with \`TaskUpdate\` when claiming, progressing, or completing work, then check TaskList for next work
4. Coordinate with other teammates by reading the task list status
5. If you identify follow-up work that needs a new task, notify the team lead via SendMessage instead of creating tasks yourself
6. If all available tasks are blocked, notify the team lead or help resolve blocking tasks

**IMPORTANT notes for communication with your team**:
- Do not use terminal tools to view your team's activity; always send a message to your teammates (and remember, refer to them by name).
- Your team cannot hear you if you do not use the SendMessage tool. Always send a message to your teammates if you are responding to them.
- Do NOT send structured JSON status messages like \`{"type":"idle",...}\` or \`{"type":"task_completed",...}\`. Just communicate in plain text when you need to message teammates.
- Use TaskUpdate to mark tasks completed.
- If you are an agent in the team, the system will automatically send idle notifications to the team lead when you stop.
"""

_TEAM_DELETE_USAGE_RULES = """Delete a team and clean up all its resources (config, inboxes, task files).

When to use:
- After all team agents have completed their work
- When you want to disband a team and release resources

This will:
- Remove team config and inbox files from ~/.agent/teams/{team_name}/
- Optionally clean up task files from ~/.agent/tasks/{team_name}.json
- Exit team namespace (switch back to session-based namespace)
"""


@tool(
    "Create a new team for multi-agent coordination. "
    "Must be called before launching agents with team_name parameter.",
    name="TeamCreate",
    usage_rules=_TEAM_CREATE_USAGE_RULES,
)
async def TeamCreate(
    team_name: str,
    description: str = "",
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    """
    Args:
        team_name: Team 名称（字母数字开头，允许 - 和 _）
        description: 团队描述（可选）
    """
    # 1. 校验 team_name
    validated_name, error = validate_team_name(team_name)
    if error:
        return err("INVALID_TEAM_NAME", error)

    # 2. 创建 TeamConfig
    try:
        team_cfg = TeamConfig(team_name=validated_name)
        # 检查是否已存在
        if team_cfg.path.exists():
            return err(
                "TEAM_EXISTS",
                f"Team '{validated_name}' already exists"
                "Team creation failed. You are not in Team mode."
                "Do not read the existing team config."
                "Do not reuse the existing team implicitly."
                "Do not spawn teammates with this team_name."
                "Do not continue the team workflow."
                "To proceed, either:"
                "- create a new team with a different name, or"
                "- delete the existing team first and then create it again."
                "If the user has not specified which option to take, stop here and ask."
            )
        # 注册主 agent 为 leader
        leader_name = resolve_context_team_agent_name(
            agent_name=getattr(ctx, "agent_name", None),
            subagent_name=ctx.subagent_name,
        )
        normalized_leader_name = normalize_agent_name(leader_name)
        team_cfg.register_member(name=normalized_leader_name, agent_type="leader")
    except Exception as exc:
        logger.error(f"TeamCreate failed to create config: {exc}", exc_info=True)
        return err("INTERNAL", f"TeamCreate failed: {exc}")

    # 3. 通过回调切换主 agent 到 team namespace
    switcher = ctx.team_namespace_switcher
    if switcher is not None:
        try:
            switcher(validated_name)
        except Exception as exc:
            logger.error(f"TeamCreate namespace switch failed: {exc}", exc_info=True)
            return err("NS_SWITCH_FAILED", f"Team created but namespace switch failed: {exc}")

    return ok(
        data={
            "team_name": validated_name,
            "config_path": str(team_cfg.path),
            "description": description,
        },
        meta={"leader": normalized_leader_name},
    )


@tool(
    "Delete a team and clean up all resources (config, inboxes, task files).",
    name="TeamDelete",
    usage_rules=_TEAM_DELETE_USAGE_RULES,
)
async def TeamDelete(
    team_name: str,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    """
    Args:
        team_name: 要删除的 Team 名称
    """
    # 1. 校验 team_name
    validated_name, error = validate_team_name(team_name)
    if error:
        return err("INVALID_TEAM_NAME", error)

    # 2. 检查 team 是否存在
    team_cfg = TeamConfig(team_name=validated_name)
    if not team_cfg.path.exists():
        return err("TEAM_NOT_FOUND", f"Team '{validated_name}' does not exist")

    team_session_lister = getattr(ctx, "team_session_lister", None)
    if callable(team_session_lister):
        active_sessions = [name for name in team_session_lister(validated_name) if str(name).strip()]
        if active_sessions:
            active_list = ", ".join(active_sessions)
            return err(
                "CONFLICT",
                (
                    f"Team '{validated_name}' still has active team sessions: {active_list}. "
                    "Send shutdown_request to those teammates before deleting the team."
                ),
                meta={"active_team_sessions": active_sessions},
            )

    cleaned: list[str] = []

    # 3. 清理 team 目录（config + inboxes）
    try:
        if team_cfg.team_dir.exists():
            shutil.rmtree(team_cfg.team_dir)
            cleaned.append(f"team_dir: {team_cfg.team_dir}")
    except Exception as exc:
        logger.warning(f"TeamDelete: 清理 team 目录失败: {exc}")

    # 4. 可选：清理 task 文件
    try:
        from comate_agent_sdk.system_tools.task.store import resolve_task_store_dir
        task_file = resolve_task_store_dir() / f"{validated_name}.json"
        if task_file.exists():
            task_file.unlink()
            cleaned.append(f"task_file: {task_file}")
    except Exception as exc:
        logger.warning(f"TeamDelete: 清理 task 文件失败: {exc}")

    # 5. 通过回调退出 team namespace
    switcher = ctx.team_namespace_switcher
    if switcher is not None:
        try:
            switcher("")  # 空字符串 → 退出 team namespace
        except Exception as exc:
            logger.warning(f"TeamDelete: namespace switch 失败: {exc}")

    return ok(
        data={
            "team_name": validated_name,
            "cleaned": cleaned,
        },
    )


def _team_context(ctx: SystemToolContext) -> tuple[str, str]:
    """返回 (team_name, agent_name)，若未处于 Team 模式则抛出 RuntimeError。"""
    team_name = ctx.team_name.strip()
    agent_name = normalize_agent_name(
        resolve_context_team_agent_name(
            agent_name=getattr(ctx, "agent_name", None),
            subagent_name=ctx.subagent_name,
        )
    )
    if not team_name:
        raise RuntimeError("不在 Team 模式下，无法使用消息工具")
    if not agent_name:
        raise RuntimeError("agent_name 未注入，无法使用消息工具")
    return team_name, agent_name


class SendMessageInput(BaseModel):
    to: str = Field(
        min_length=1,
        description=f"收件人 agent 名称，或 '{_BROADCAST_TARGET}'（广播给所有成员）",
    )
    content: str = Field(min_length=1, description="消息正文")
    type: str = Field(
        default=MessageType.MESSAGE.value,
        description="消息类型，参见 MessageType",
    )

    model_config = {"extra": "forbid"}


@tool(
    "Send a message to another agent or broadcast to all agents in the team. "
    "Only available in Team mode.",
    name="SendMessage",
)
async def SendMessage(
    params: SendMessageInput,
    ctx: Annotated[SystemToolContext, Depends(get_system_tool_context)] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    try:
        team_name, from_agent = _team_context(ctx)
    except RuntimeError as exc:
        return err("NOT_TEAM_MODE", str(exc))

    to = normalize_agent_name(params.to) if params.to.strip() != _BROADCAST_TARGET else _BROADCAST_TARGET
    try:
        msg_type = MessageType(params.type)
    except ValueError:
        return err("INVALID_TYPE", f"未知消息类型: {params.type!r}")

    try:
        if to == _BROADCAST_TARGET:
            # 广播：写入所有 team 成员的收件箱（排除自己）
            team_cfg = TeamConfig(team_name=team_name)
            recipients = [
                m["name"]
                for m in team_cfg.list_members()
                if m["name"] != from_agent
            ]
            # 如果没有注册成员，回退到已有收件箱文件
            if not recipients:
                recipients = [
                    name
                    for name in get_all_inboxes(team_name)
                    if name != from_agent
                ]
            for recipient in recipients:
                inbox = Inbox(team_name=team_name, agent_name=recipient)
                inbox.append_message(
                    from_agent=from_agent,
                    message_type=msg_type,
                    content=params.content,
                )
            return ok(
                data={
                    "recipients": recipients,
                    "type": msg_type.value,
                    "broadcast": True,
                },
                meta={"from": from_agent, "team": team_name},
            )
        else:
            inbox = Inbox(team_name=team_name, agent_name=to)
            inbox.append_message(
                from_agent=from_agent,
                message_type=msg_type,
                content=params.content,
            )
            return ok(
                data={"to": to, "type": msg_type.value, "broadcast": False},
                meta={"from": from_agent, "team": team_name},
            )
    except Exception as exc:
        logger.error(f"SendMessage failed: {exc}", exc_info=True)
        return err("INTERNAL", f"SendMessage failed: {exc}")
