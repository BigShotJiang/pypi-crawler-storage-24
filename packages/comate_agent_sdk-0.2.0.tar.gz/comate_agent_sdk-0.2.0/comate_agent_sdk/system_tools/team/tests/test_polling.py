from __future__ import annotations

import unittest
from unittest.mock import patch

from comate_agent_sdk.system_tools.team.polling import (
    DEFAULT_TEAM_POLL_INTERVAL_SECONDS,
    resolve_team_poll_interval_seconds,
)


class TestTeamPolling(unittest.TestCase):
    def test_default_interval_is_four_seconds(self) -> None:
        with patch.dict("os.environ", {}, clear=True):
            self.assertEqual(
                resolve_team_poll_interval_seconds(),
                DEFAULT_TEAM_POLL_INTERVAL_SECONDS,
            )

    def test_shared_env_overrides_team_poll_interval(self) -> None:
        with patch.dict("os.environ", {"COMATE_TEAM_POLL_INTERVAL_SECONDS": "1.25"}, clear=True):
            self.assertEqual(resolve_team_poll_interval_seconds(), 1.25)

    def test_team_session_legacy_env_remains_supported(self) -> None:
        with patch.dict(
            "os.environ",
            {"COMATE_TEAM_SESSION_POLL_INTERVAL_SECONDS": "0.2"},
            clear=True,
        ):
            self.assertEqual(
                resolve_team_poll_interval_seconds(
                    legacy_env_var="COMATE_TEAM_SESSION_POLL_INTERVAL_SECONDS"
                ),
                0.2,
            )


if __name__ == "__main__":
    unittest.main(verbosity=2)
