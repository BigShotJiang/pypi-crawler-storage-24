from __future__ import annotations

import asyncio
import json
import os
from unittest.mock import patch

from comate_agent_sdk.system_tools.team.config import TeamConfig
from comate_agent_sdk.system_tools.team.identity import DEFAULT_TEAM_LEAD_NAME
from comate_agent_sdk.system_tools.team.inbox import Inbox
from comate_agent_sdk.system_tools.team.tools import (
    SendMessage,
    SendMessageInput,
    TeamDelete,
    TeamCreate,
)
from comate_agent_sdk.tools.system_context import bind_system_tool_context


def _parse(raw: str) -> dict:
    return json.loads(raw)


def test_team_create_defaults_to_team_lead_when_context_agent_missing(tmp_path) -> None:
    asyncio.run(_test_team_create_defaults_to_team_lead_when_context_agent_missing(tmp_path))


async def _test_team_create_defaults_to_team_lead_when_context_agent_missing(tmp_path) -> None:
    switch_calls: list[str] = []
    with patch.dict("os.environ", {"COMATE_TEAMS_DIR": str(tmp_path)}):
        with bind_system_tool_context(
            project_root=tmp_path,
            team_namespace_switcher=switch_calls.append,
        ):
            result = _parse(await TeamCreate.execute(team_name="review-team"))

        assert result["ok"]
        assert result["meta"]["leader"] == DEFAULT_TEAM_LEAD_NAME
        assert switch_calls == ["review-team"]

        members = TeamConfig(team_name="review-team", base_dir=tmp_path).list_members()
        assert [(member["name"], member["agent_type"]) for member in members] == [
            (DEFAULT_TEAM_LEAD_NAME, "leader")
        ]


def test_send_message_accepts_main_agent_identity(tmp_path) -> None:
    asyncio.run(_test_send_message_accepts_main_agent_identity(tmp_path))


async def _test_send_message_accepts_main_agent_identity(tmp_path) -> None:
    with patch.dict("os.environ", {"COMATE_TEAMS_DIR": str(tmp_path)}):
        TeamConfig(team_name="review-team", base_dir=tmp_path).register_member(
            name="worker-1",
            agent_type="general-purpose",
        )

        with bind_system_tool_context(
            project_root=tmp_path,
            team_name="review-team",
            agent_name="leader",
        ):
            result = _parse(
                await SendMessage.execute(
                    params=SendMessageInput(to="worker-1", content="hello teammate")
                )
            )

        assert result["ok"]
        assert result["meta"]["from"] == "leader"

        messages = Inbox(
            team_name="review-team",
            agent_name="worker-1",
            base_dir=tmp_path,
        ).read_all()
        assert len(messages) == 1
        assert messages[0]["from"] == "leader"


def test_team_delete_rejects_active_team_sessions(tmp_path) -> None:
    asyncio.run(_test_team_delete_rejects_active_team_sessions(tmp_path))


async def _test_team_delete_rejects_active_team_sessions(tmp_path) -> None:
    switch_calls: list[str] = []
    with patch.dict("os.environ", {"COMATE_TEAMS_DIR": str(tmp_path)}):
        TeamConfig(team_name="review-team", base_dir=tmp_path).register_member(
            name="leader",
            agent_type="leader",
        )

        with bind_system_tool_context(
            project_root=tmp_path,
            team_name="review-team",
            agent_name="leader",
            team_namespace_switcher=switch_calls.append,
            team_session_lister=lambda team_name: ["worker-1"] if team_name == "review-team" else [],
        ):
            result = _parse(await TeamDelete.execute(team_name="review-team"))

        assert not result["ok"]
        assert result["error"]["code"] == "CONFLICT"
        assert result["meta"]["active_team_sessions"] == ["worker-1"]
        assert TeamConfig(team_name="review-team", base_dir=tmp_path).path.exists()
        assert switch_calls == []


def test_agent_name_case_normalization(tmp_path) -> None:
    """验证 agent 名字大小写规范化：防止 'Team-Lead' vs 'team-lead' 不匹配问题。"""
    asyncio.run(_test_agent_name_case_normalization(tmp_path))


async def _test_agent_name_case_normalization(tmp_path) -> None:
    """测试场景：
    1. TeamCreate 时使用大小写混合的 'Team-Lead'
    2. Teammate 发送消息时使用小写 'team-lead'
    3. 两者应该匹配，team-lead.json 应该被创建
    """
    switch_calls: list[str] = []
    with patch.dict("os.environ", {"COMATE_TEAMS_DIR": str(tmp_path)}):
        # 1. TeamCreate - leader_name 会被规范化为小写 'team-lead'
        with bind_system_tool_context(
            project_root=tmp_path,
            agent_name="Team-Lead",
            team_namespace_switcher=switch_calls.append,
        ):
            result = _parse(await TeamCreate.execute(team_name="test-team"))

        assert result["ok"]
        # verify leader 被规范化为小写
        assert result["meta"]["leader"] == DEFAULT_TEAM_LEAD_NAME

        # 2. 验证 config 中注册的也是小写 'team-lead'
        members = TeamConfig(team_name="test-team", base_dir=tmp_path).list_members()
        assert [(member["name"], member["agent_type"]) for member in members] == [
            (DEFAULT_TEAM_LEAD_NAME, "leader")
        ]

        # 3. 注册 teammate
        TeamConfig(team_name="test-team", base_dir=tmp_path).register_member(
            name="TEAMMATE",  # 大写，也会被规范化
            agent_type="general-purpose",
        )

        # 4. Teammate 发送消息给 team-lead（小写）
        with bind_system_tool_context(
            project_root=tmp_path,
            team_name="test-team",
            agent_name="teammate",
        ):
            result = _parse(
                await SendMessage.execute(
                    params=SendMessageInput(to=DEFAULT_TEAM_LEAD_NAME, content="task completed")
                )
            )

        assert result["ok"]

        # 5. 验证 team-lead.json 被创建（大小写正确匹配）
        messages = Inbox(
            team_name="test-team",
            agent_name=DEFAULT_TEAM_LEAD_NAME,
            base_dir=tmp_path,
        ).read_all()
        assert len(messages) == 1
        assert messages[0]["from"] == "teammate"
        assert json.loads(messages[0]["text"])["content"] == "task completed"
