from __future__ import annotations

from pathlib import Path

import pytest

from comate_agent_sdk.system_tools.task.models import TaskStatus
from comate_agent_sdk.system_tools.task.store import TaskStore, TaskStoreConflictError


def _store(tmp_path: Path) -> TaskStore:
    return TaskStore(store_dir=tmp_path, list_id="demo")


def test_create_and_list_tasks(tmp_path: Path) -> None:
    store = _store(tmp_path)
    first = store.create_task(subject="Design interface")
    second = store.create_task(subject="Implement backend", blocked_by=[first.id])

    tasks = store.list_tasks()
    assert [task.id for task in tasks] == ["1", "2"]
    assert second.blocked_by == ["1"]
    assert store.get_open_blocked_by("2") == ["1"]


def test_update_task_and_filter_open_blockers(tmp_path: Path) -> None:
    store = _store(tmp_path)
    first = store.create_task(subject="A")
    second = store.create_task(subject="B", blocked_by=[first.id])

    store.update_task(first.id, status=TaskStatus.COMPLETED)

    assert store.get_open_blocked_by(second.id) == []
    updated = store.update_task(second.id, status=TaskStatus.IN_PROGRESS, owner="worker")
    assert updated.status == TaskStatus.IN_PROGRESS
    assert updated.owner == "worker"


def test_cycle_detection_rejects_updates(tmp_path: Path) -> None:
    store = _store(tmp_path)
    first = store.create_task(subject="A")
    second = store.create_task(subject="B", blocked_by=[first.id])

    with pytest.raises(TaskStoreConflictError):
        store.update_task(first.id, blocked_by=[second.id])


def test_delete_rejects_when_task_is_still_depended_on(tmp_path: Path) -> None:
    store = _store(tmp_path)
    first = store.create_task(subject="A")
    store.create_task(subject="B", blocked_by=[first.id])

    with pytest.raises(TaskStoreConflictError):
        store.delete_task(first.id)


# P1: extend_blocked_by and add_reverse_dependencies

def test_extend_blocked_by_atomic(tmp_path: Path) -> None:
    store = _store(tmp_path)
    a = store.create_task(subject="A")
    b = store.create_task(subject="B")
    c = store.create_task(subject="C", blocked_by=[a.id])

    updated = store.update_task(c.id, extend_blocked_by=[b.id])
    assert updated.blocked_by == [a.id, b.id]


def test_add_reverse_dependencies(tmp_path: Path) -> None:
    store = _store(tmp_path)
    source = store.create_task(subject="Source")
    b = store.create_task(subject="B")
    c = store.create_task(subject="C")

    results = store.add_reverse_dependencies(source.id, [b.id, c.id])
    assert len(results) == 2
    assert store.get_task(b.id).blocked_by == [source.id]
    assert store.get_task(c.id).blocked_by == [source.id]


def test_add_reverse_dependencies_cycle(tmp_path: Path) -> None:
    store = _store(tmp_path)
    a = store.create_task(subject="A")
    b = store.create_task(subject="B", blocked_by=[a.id])

    # a 已经 blocked_by nothing，b blocked_by a
    # 让 a blocked_by b 会形成环
    with pytest.raises(TaskStoreConflictError):
        store.add_reverse_dependencies(b.id, [a.id])
