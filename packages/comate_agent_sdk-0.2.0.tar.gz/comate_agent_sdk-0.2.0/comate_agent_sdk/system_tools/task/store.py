from __future__ import annotations

import asyncio
import errno
import logging
import os
import tempfile
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, ClassVar, Iterator

from comate_agent_sdk.system_tools.task.models import TaskItem, TaskListModel, TaskStatus, utc_now_iso

logger = logging.getLogger(__name__)

_TASK_STORE_DIR_ENV = "COMATE_TASK_STORE_DIR"
_TASK_LIST_ID_ENV = "COMATE_TASK_LIST_ID"
_DEFAULT_TASK_LIST_ID = "default"
_LOCK_TIMEOUT_SECONDS = 2.0
_LOCK_POLL_INTERVAL_SECONDS = 0.05


class TaskStoreError(RuntimeError):
    """TaskStore 基础异常。"""


class TaskStoreTimeoutError(TaskStoreError):
    """文件锁超时。"""


class TaskStoreConflictError(TaskStoreError):
    """依赖冲突、环、缺失引用等逻辑错误。"""


def resolve_task_store_dir(store_dir: Path | None = None) -> Path:
    if store_dir is not None:
        return store_dir.expanduser().resolve()

    raw = str(os.environ.get(_TASK_STORE_DIR_ENV, "")).strip()
    if raw:
        return Path(raw).expanduser().resolve()
    return (Path.home() / ".agent" / "tasks").expanduser().resolve()


def resolve_task_list_id(list_id: str | None = None) -> str:
    resolved = str(list_id or os.environ.get(_TASK_LIST_ID_ENV, _DEFAULT_TASK_LIST_ID)).strip()
    return resolved or _DEFAULT_TASK_LIST_ID


def resolve_task_namespace(
    *,
    session_id: str,
    configured: str | None = None,
    persisted: str | None = None,
) -> str:
    """解析 runtime 级 task namespace。

    优先级：
    1. COMATE_TASK_LIST_ID
    2. 代码显式配置的 namespace
    3. session 持久化 metadata 中记录的 namespace
    4. session_id
    """
    env_value = str(os.environ.get(_TASK_LIST_ID_ENV, "")).strip()
    if env_value:
        return env_value

    for candidate in (configured, persisted, session_id):
        resolved = str(candidate or "").strip()
        if resolved:
            return resolved

    return _DEFAULT_TASK_LIST_ID


class TaskStore:
    """文件系统持久化 + 进程级文件锁 + 协程级 asyncio.Lock。

    Team 模式下多个 subagent 作为同进程 asyncio 协程并发访问同一个 list_id 文件。
    fcntl flock 是进程级锁，同进程协程不互斥，因此额外使用 asyncio.Lock 做协程级保护。
    """

    # 按文件路径维护协程级锁（ClassVar，所有 TaskStore 实例共享）
    _asyncio_locks: ClassVar[dict[str, asyncio.Lock]] = {}

    def __init__(
        self,
        store_dir: Path | None = None,
        list_id: str | None = None,
    ) -> None:
        self.store_dir = resolve_task_store_dir(store_dir)
        self.list_id = resolve_task_list_id(list_id)
        self.path = (self.store_dir / f"{self.list_id}.json").resolve()
        self.lock_path = (self.store_dir / f"{self.list_id}.lock").resolve()

    def _get_async_lock(self) -> asyncio.Lock:
        """返回此文件对应的协程级锁（按路径共享）。"""
        key = str(self.path)
        if key not in self._asyncio_locks:
            self._asyncio_locks[key] = asyncio.Lock()
        return self._asyncio_locks[key]

    async def async_create_task(
        self,
        *,
        subject: str,
        description: str = "",
        owner: str = "",
        blocked_by: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> TaskItem:
        """协程安全版 create_task（用于 Team 模式下并发 subagent）。"""
        async with self._get_async_lock():
            return self.create_task(
                subject=subject,
                description=description,
                owner=owner,
                blocked_by=blocked_by,
                metadata=metadata,
            )

    async def async_update_task(self, task_id: str, **updates: Any) -> TaskItem:
        """协程安全版 update_task（用于 Team 模式下并发 subagent）。"""
        async with self._get_async_lock():
            return self.update_task(task_id, **updates)

    async def async_delete_task(self, task_id: str) -> bool:
        """协程安全版 delete_task（用于 Team 模式下并发 subagent）。"""
        async with self._get_async_lock():
            return self.delete_task(task_id)

    async def async_add_reverse_dependencies(
        self, source_id: str, target_ids: list[str]
    ) -> list[TaskItem]:
        """协程安全版 add_reverse_dependencies。"""
        async with self._get_async_lock():
            return self.add_reverse_dependencies(source_id, target_ids)

    def create_task(
        self,
        *,
        subject: str,
        description: str = "",
        owner: str = "",
        blocked_by: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> TaskItem:
        def _mutate(model: TaskListModel) -> TaskItem:
            task_id = str(model.next_id)
            normalized_blocked_by = self._normalize_dependency_ids(
                blocked_by or [],
                existing_tasks=model.tasks,
                task_id=task_id,
            )
            now = utc_now_iso()
            task = TaskItem(
                id=task_id,
                subject=subject.strip(),
                description=description.strip(),
                owner=owner.strip(),
                blocked_by=normalized_blocked_by,
                metadata=dict(metadata or {}),
                created_at=now,
                updated_at=now,
            )
            if self._detect_cycle(model.tasks, task):
                raise TaskStoreConflictError("Task dependency cycle detected")
            model.tasks[task_id] = task
            model.next_id += 1
            model.updated_at = now
            return task

        return self._with_write_model(_mutate)

    def get_task(self, task_id: str) -> TaskItem | None:
        model = self._load()
        return model.tasks.get(str(task_id).strip())

    def update_task(self, task_id: str, **updates: Any) -> TaskItem:
        normalized_task_id = str(task_id).strip()
        extend_blocked_by = updates.pop("extend_blocked_by", None)

        def _mutate(model: TaskListModel) -> TaskItem:
            existing = model.tasks.get(normalized_task_id)
            if existing is None:
                raise TaskStoreConflictError(f"Task not found: {normalized_task_id}")

            payload = existing.model_dump(mode="python")
            if "subject" in updates and updates["subject"] is not None:
                payload["subject"] = str(updates["subject"]).strip()
            if "description" in updates and updates["description"] is not None:
                payload["description"] = str(updates["description"]).strip()
            if "owner" in updates and updates["owner"] is not None:
                payload["owner"] = str(updates["owner"]).strip()
            if "status" in updates and updates["status"] is not None:
                payload["status"] = updates["status"]
            if "blocked_by" in updates and updates["blocked_by"] is not None:
                payload["blocked_by"] = self._normalize_dependency_ids(
                    list(updates["blocked_by"]),
                    existing_tasks=model.tasks,
                    task_id=normalized_task_id,
                )
            elif extend_blocked_by is not None:
                current = list(payload["blocked_by"])
                current.extend(extend_blocked_by)
                payload["blocked_by"] = self._normalize_dependency_ids(
                    current,
                    existing_tasks=model.tasks,
                    task_id=normalized_task_id,
                )
            if "metadata" in updates and updates["metadata"] is not None:
                payload["metadata"] = dict(updates["metadata"])

            payload["updated_at"] = utc_now_iso()
            candidate = TaskItem.model_validate(payload)
            if self._detect_cycle(model.tasks, candidate):
                raise TaskStoreConflictError("Task dependency cycle detected")
            model.tasks[normalized_task_id] = candidate
            model.updated_at = candidate.updated_at
            return candidate

        return self._with_write_model(_mutate)

    def add_reverse_dependencies(self, source_id: str, target_ids: list[str]) -> list[TaskItem]:
        """给 target_ids 中每个任务的 blocked_by 追加 source_id。原子操作。"""
        normalized_source = str(source_id).strip()

        def _mutate(model: TaskListModel) -> list[TaskItem]:
            if normalized_source not in model.tasks:
                raise TaskStoreConflictError(f"Source task not found: {normalized_source}")
            updated: list[TaskItem] = []
            for raw_id in target_ids:
                target_id = str(raw_id).strip()
                target = model.tasks.get(target_id)
                if target is None:
                    raise TaskStoreConflictError(f"Target task not found: {target_id}")
                if normalized_source in target.blocked_by:
                    continue
                new_deps = list(target.blocked_by) + [normalized_source]
                normalized = self._normalize_dependency_ids(
                    new_deps, existing_tasks=model.tasks, task_id=target_id
                )
                payload = target.model_dump(mode="python")
                payload["blocked_by"] = normalized
                payload["updated_at"] = utc_now_iso()
                candidate = TaskItem.model_validate(payload)
                if self._detect_cycle(model.tasks, candidate):
                    raise TaskStoreConflictError(
                        f"Cycle detected: adding {normalized_source} → {target_id}"
                    )
                model.tasks[target_id] = candidate
                updated.append(candidate)
            model.updated_at = utc_now_iso()
            return updated

        return self._with_write_model(_mutate)

    def list_tasks(self, status_filter: list[TaskStatus] | None = None) -> list[TaskItem]:
        model = self._load()
        tasks = list(model.tasks.values())
        if status_filter:
            allowed = {TaskStatus(status) for status in status_filter}
            tasks = [task for task in tasks if task.status in allowed]
        return sorted(tasks, key=lambda item: int(item.id))

    def delete_task(self, task_id: str) -> bool:
        normalized_task_id = str(task_id).strip()

        def _mutate(model: TaskListModel) -> bool:
            if normalized_task_id not in model.tasks:
                return False
            for task in model.tasks.values():
                if normalized_task_id in task.blocked_by:
                    raise TaskStoreConflictError(
                        f"Cannot delete task {normalized_task_id}; other tasks depend on it"
                    )
            del model.tasks[normalized_task_id]
            model.updated_at = utc_now_iso()
            return True

        return self._with_write_model(_mutate)

    def add_dependency(self, task_id: str, blocked_by_id: str) -> None:
        task = self.get_task(task_id)
        if task is None:
            raise TaskStoreConflictError(f"Task not found: {task_id}")
        dependencies = list(task.blocked_by)
        dependencies.append(str(blocked_by_id).strip())
        self.update_task(task_id, blocked_by=dependencies)

    def get_open_blocked_by(self, task_id: str) -> list[str]:
        task = self.get_task(task_id)
        if task is None:
            return []
        model = self._load()
        result: list[str] = []
        for dependency_id in task.blocked_by:
            dependency = model.tasks.get(dependency_id)
            if dependency is None:
                continue
            if dependency.status != TaskStatus.COMPLETED:
                result.append(dependency_id)
        return result

    def list_id_value(self) -> str:
        return self.list_id

    def get_reverse_dependents(self, task_id: str) -> list[str]:
        model = self._load()
        target_id = str(task_id).strip()
        dependents = [
            item.id
            for item in model.tasks.values()
            if target_id in item.blocked_by
        ]
        return sorted(dependents, key=int)

    def _load(self) -> TaskListModel:
        def _reader() -> TaskListModel:
            self.store_dir.mkdir(parents=True, exist_ok=True)
            if not self.path.exists():
                return TaskListModel(id=self.list_id)
            raw = self.path.read_text(encoding="utf-8").strip()
            if not raw:
                return TaskListModel(id=self.list_id)
            return TaskListModel.model_validate_json(raw)

        with self._acquire_lock(exclusive=False):
            return _reader()

    def _save(self, model: TaskListModel) -> None:
        self.store_dir.mkdir(parents=True, exist_ok=True)
        serialized = model.model_dump_json(indent=2)
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=str(self.store_dir),
            prefix=f".{self.list_id}.",
            suffix=".tmp",
            delete=False,
        ) as temp_file:
            temp_file.write(serialized)
            temp_path = Path(temp_file.name)
        os.replace(temp_path, self.path)

    def _with_write_model(self, callback):
        with self._acquire_lock(exclusive=True):
            model = self._load_unlocked()
            result = callback(model)
            self._save(model)
            return result

    def _load_unlocked(self) -> TaskListModel:
        self.store_dir.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            return TaskListModel(id=self.list_id)
        raw = self.path.read_text(encoding="utf-8").strip()
        if not raw:
            return TaskListModel(id=self.list_id)
        return TaskListModel.model_validate_json(raw)

    def _normalize_dependency_ids(
        self,
        dependency_ids: list[str],
        *,
        existing_tasks: dict[str, TaskItem],
        task_id: str,
    ) -> list[str]:
        normalized: list[str] = []
        seen: set[str] = set()
        for raw_id in dependency_ids:
            dependency_id = str(raw_id).strip()
            if not dependency_id or dependency_id in seen:
                continue
            if dependency_id == task_id:
                raise TaskStoreConflictError("Task cannot depend on itself")
            if dependency_id not in existing_tasks:
                raise TaskStoreConflictError(f"Dependency task not found: {dependency_id}")
            seen.add(dependency_id)
            normalized.append(dependency_id)
        return normalized

    def _detect_cycle(
        self,
        existing_tasks: dict[str, TaskItem],
        candidate: TaskItem,
    ) -> bool:
        graph = {
            task_id: list(task.blocked_by)
            for task_id, task in existing_tasks.items()
        }
        graph[candidate.id] = list(candidate.blocked_by)

        visited: set[str] = set()
        visiting: set[str] = set()

        def _visit(task_id: str) -> bool:
            if task_id in visiting:
                return True
            if task_id in visited:
                return False
            visiting.add(task_id)
            for dependency_id in graph.get(task_id, []):
                if _visit(dependency_id):
                    return True
            visiting.remove(task_id)
            visited.add(task_id)
            return False

        return _visit(candidate.id)

    @contextmanager
    def _acquire_lock(self, *, exclusive: bool) -> Iterator[None]:
        import fcntl

        self.store_dir.mkdir(parents=True, exist_ok=True)
        lock_mode = fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH
        start = time.monotonic()
        with self.lock_path.open("a+", encoding="utf-8") as lock_file:
            while True:
                try:
                    fcntl.flock(lock_file.fileno(), lock_mode | fcntl.LOCK_NB)
                    break
                except OSError as exc:
                    if exc.errno not in {errno.EACCES, errno.EAGAIN}:
                        raise
                    if time.monotonic() - start >= _LOCK_TIMEOUT_SECONDS:
                        raise TaskStoreTimeoutError(
                            f"Timed out acquiring task store lock for list '{self.list_id}'"
                        ) from exc
                    time.sleep(_LOCK_POLL_INTERVAL_SECONDS)
            try:
                yield
            finally:
                fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)
