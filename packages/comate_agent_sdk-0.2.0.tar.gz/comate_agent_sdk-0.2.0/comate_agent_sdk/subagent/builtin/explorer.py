from comate_agent_sdk.subagent.models import AgentDefinition
from comate_agent_sdk.prompts import load_prompt

PROMPT = load_prompt("subagent/explorer.md")

description ="""Fast agent specialized for exploring codebases. Use this when you need to quickly find files by patterns (eg. "src/components/**/*.tsx"), search code for keywords (eg. "API endpoints"), or answer questions about the codebase (eg. "how do API endpoints work?").
When calling this agent, specify the desired thoroughness level: "quick" for basic searches, "medium" for moderate exploration, or "very thorough" for comprehensive analysis across multiple locations and naming conventions.
"""
ExplorerAgent = AgentDefinition(
    name="Explorer",                    # 唯一标识（用于 Task(subagent_type="example")）
    description=description,    # LLM 可见的描述
    prompt=PROMPT,                     # 系统提示
    tools=["Read","Grep","Bash", "Glob", "LS"],                        # None=继承父agent全部工具, ["Read","Grep"]=指定工具
    allow_team_coordination=True,
    skills=None,                       # None=继承父agent全部skills, ["skill1"]=指定skills
    model="sonnet",                        # None=继承, "sonnet"/"opus"/"haiku"
    level="LOW",                        # None=继承, "LOW"/"MID"/"HIGH"
    max_iterations=100,                 # 最大迭代次数
    timeout=None,                      # 超时（秒），None=不限
    source="builtin",                  # 固定为 "builtin"，不要修改
)
