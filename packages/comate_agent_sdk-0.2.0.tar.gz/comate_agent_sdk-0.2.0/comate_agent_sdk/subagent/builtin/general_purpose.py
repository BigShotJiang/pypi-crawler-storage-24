from comate_agent_sdk.subagent.models import AgentDefinition
from comate_agent_sdk.prompts import load_prompt, render_prompt

_SYSTEM_ROLE = (
    "You are Comate CLI, an interactive general AI agent running on a user's computer "
    "that helps users as a general AI agent."
)

PROMPT = render_prompt(
    load_prompt("subagent/general_purpose.md"),
    variables={"SYSTEM_ROLE": _SYSTEM_ROLE},
    source="subagent/general_purpose.md",
)

description = (
    "General-purpose agent for researching complex questions, searching for code, "
    "and executing multi-step tasks. Use this when you need an agent that can read "
    "and write files, execute commands, search code, and complete a wide variety of tasks."
)

GeneralPurposeAgent = AgentDefinition(
    name="general-purpose",
    description=description,
    prompt=PROMPT,
    tools=None,         # 继承父 agent 全部工具（AskUserQuestion 和 Agent 由框架自动过滤）
    skills=None,        # 继承父 agent 全部 skills
    model="sonnet",     # MID 档，通用执行任务
    level="MID",
    max_iterations=200,
    timeout=None,
    source="builtin",
)
