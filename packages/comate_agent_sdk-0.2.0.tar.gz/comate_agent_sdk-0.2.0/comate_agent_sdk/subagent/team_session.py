from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from comate_agent_sdk.agent.chat_session import ChatSession
from comate_agent_sdk.agent.events import StopEvent, TextEvent, ToolResultEvent
from comate_agent_sdk.system_tools.team.config import TeamConfig
from comate_agent_sdk.system_tools.team.identity import resolve_runtime_team_agent_name
from comate_agent_sdk.system_tools.team.inbox_transport import TeamInboxTransport
from comate_agent_sdk.system_tools.team.polling import (
    DEFAULT_TEAM_POLL_INTERVAL_SECONDS,
    resolve_team_poll_interval_seconds,
)

if TYPE_CHECKING:
    from comate_agent_sdk.agent.core.runtime import AgentRuntime

logger = logging.getLogger("comate_agent_sdk.subagent.team_session")

class TeamSessionTurnTimeoutError(RuntimeError):
    """A team-session turn exceeded its configured timeout."""


def _truncate_message(text: str, *, max_chars: int = 1200) -> str:
    normalized = str(text or "").strip()
    if len(normalized) <= max_chars:
        return normalized
    return f"{normalized[:max_chars]}\n...(truncated)"


def _resolve_leader_recipients(team_name: str, sender_name: str) -> list[str]:
    try:
        from comate_agent_sdk.system_tools.team.inbox import get_all_inboxes

        team_cfg = TeamConfig(team_name=team_name)
        leaders = [
            str(member.get("name", "")).strip()
            for member in team_cfg.list_members()
            if member.get("agent_type") == "leader"
            and str(member.get("name", "")).strip()
            and str(member.get("name", "")).strip() != sender_name
        ]
        if leaders:
            return leaders
        return [
            recipient
            for recipient in get_all_inboxes(team_name)
            if recipient.strip() and recipient.strip() != sender_name
        ]
    except Exception as exc:
        logger.debug(f"[Team session] Failed to resolve leader recipients: {exc}")
        return []


def send_team_session_status_message(
    *,
    team_name: str,
    sender_name: str,
    subagent_type: str,
    status: str,
    content: str,
) -> None:
    try:
        from comate_agent_sdk.system_tools.team.inbox import Inbox, MessageType

        recipients = _resolve_leader_recipients(team_name, sender_name)
        if not recipients:
            logger.debug(
                f"[Team session] No leader recipient found: "
                f"team={team_name!r} sender={sender_name!r}"
            )
            return

        preview = _truncate_message(content)
        message = f"Team session '{sender_name}' ({subagent_type}) {status}."
        if preview:
            message = f"{message}\n\n{preview}"

        for recipient in recipients:
            inbox = Inbox(team_name=team_name, agent_name=recipient)
            inbox.append_message(
                from_agent=sender_name,
                message_type=MessageType.MESSAGE,
                content=message,
            )
    except Exception as exc:
        logger.warning(
            f"[Team session] Failed to send status message: "
            f"team={team_name!r} sender={sender_name!r} status={status!r}: {exc}",
            exc_info=True,
        )


def send_team_session_direct_message(
    *,
    team_name: str,
    sender_name: str,
    content: str,
) -> None:
    try:
        from comate_agent_sdk.system_tools.team.inbox import Inbox, MessageType

        normalized_content = str(content or "").strip()
        if not normalized_content:
            return

        recipients = _resolve_leader_recipients(team_name, sender_name)
        if not recipients:
            logger.debug(
                f"[Team session] No leader recipient found for direct reply: "
                f"team={team_name!r} sender={sender_name!r}"
            )
            return

        for recipient in recipients:
            inbox = Inbox(team_name=team_name, agent_name=recipient)
            inbox.append_message(
                from_agent=sender_name,
                message_type=MessageType.MESSAGE,
                content=normalized_content,
            )
    except Exception as exc:
        logger.warning(
            f"[Team session] Failed to send direct message: "
            f"team={team_name!r} sender={sender_name!r}: {exc}",
            exc_info=True,
        )


def _read_inbox_turn_input(*, team_name: str, agent_name: str) -> tuple[list[str], str | None]:
    from comate_agent_sdk.system_tools.team.inbox import Inbox, MessageType

    inbox = Inbox(team_name=team_name, agent_name=agent_name)
    messages = inbox.read_unread(mark_as_read=True)
    if not messages:
        return [], None

    shutdown_requesters: list[str] = []
    reminder_lines: list[str] = ["# Team Inbox — New Messages"]

    for envelope in messages:
        from_agent = str(envelope.get("from", "unknown") or "unknown").strip() or "unknown"
        timestamp = str(envelope.get("timestamp", "") or "").strip()
        raw_text = envelope.get("text", "")
        try:
            payload = json.loads(raw_text) if raw_text else {}
        except Exception:
            payload = {"raw": raw_text}

        message_type = str(payload.get("type", "message") or "message").strip() or "message"
        content = str(payload.get("content", raw_text) or "").strip()

        if message_type == MessageType.SHUTDOWN_REQUEST.value:
            if from_agent not in shutdown_requesters:
                shutdown_requesters.append(from_agent)
            continue
        if message_type == MessageType.IDLE_NOTIFICATION.value:
            continue

        reminder_lines.append(
            f"- [{timestamp}] From: {from_agent} | Type: {message_type}\n  {content}"
        )

    if len(reminder_lines) == 1:
        return shutdown_requesters, None
    return shutdown_requesters, "\n".join(reminder_lines)


def _drain_team_session_turn_input(
    *,
    team_name: str,
    agent_name: str,
) -> tuple[list[str], str | None, list[str]]:
    transport = TeamInboxTransport(team_name=team_name, agent_name=agent_name)
    batch = transport.poll_new()
    if not batch.events:
        return [], None, []

    shutdown_requesters: list[str] = []
    shutdown_keys: list[str] = []
    ignored_keys: list[str] = []
    conversational_events: list[object] = []
    conversational_keys: list[str] = []

    for event in batch.events:
        message_type = str(event.message_type or "").strip()
        if message_type == "shutdown_request":
            shutdown_keys.append(event.key)
            if event.from_agent not in shutdown_requesters:
                shutdown_requesters.append(event.from_agent)
            continue
        if message_type == "idle_notification":
            ignored_keys.append(event.key)
            continue
        conversational_events.append(event)
        conversational_keys.append(event.key)

    if shutdown_keys:
        ack_keys = ignored_keys + shutdown_keys
        transport.ack(ack_keys)
        return shutdown_requesters, None, ack_keys

    reminder_lines: list[str] = ["# Team Inbox — New Messages"]
    for event in conversational_events:
        reminder_lines.append(
            f"- [{event.timestamp}] From: {event.from_agent} | Type: {event.message_type}\n"
            f"  {event.content}"
        )

    if not conversational_keys:
        if ignored_keys:
            transport.ack(ignored_keys)
        return [], None, ignored_keys

    ack_keys = ignored_keys + conversational_keys
    transport.ack(ack_keys)
    return [], "\n".join(reminder_lines), ack_keys


@dataclass(slots=True)
class TeamSessionActor:
    session: ChatSession
    runtime: "AgentRuntime"
    parent_runtime: "AgentRuntime | None"
    subagent_type: str
    team_name: str
    agent_name: str
    initial_prompt: str
    timeout_seconds: float | None = None
    poll_interval_seconds: float = DEFAULT_TEAM_POLL_INTERVAL_SECONDS
    pending_shutdown_recipients: list[str] | None = None

    async def run(self) -> None:
        terminal_status = ""
        terminal_content = ""
        try:
            await self._run_turn(self.initial_prompt, is_followup_turn=False)
            while True:
                next_prompt = await self._wait_for_next_prompt()
                if next_prompt is None:
                    break
                await self._run_turn(next_prompt, is_followup_turn=True)
            if self.pending_shutdown_recipients:
                terminal_status = "shutdown"
        except TeamSessionTurnTimeoutError as exc:
            terminal_status = "timed out"
            terminal_content = str(exc)
        except asyncio.CancelledError:
            terminal_status = "cancelled"
            raise
        except Exception as exc:
            terminal_status = "failed"
            terminal_content = f"Actor crashed: {exc}"
            logger.error(
                f"Team session actor failed: team={self.team_name!r} "
                f"agent={self.agent_name!r} error={exc}",
                exc_info=True,
            )
        finally:
            worktree_note = self._finalize_terminal_worktree_note()
            if terminal_status == "failed":
                message = terminal_content
                if worktree_note:
                    message = f"{message}\n\n{worktree_note}"
                send_team_session_status_message(
                    team_name=self.team_name,
                    sender_name=self.agent_name,
                    subagent_type=self.subagent_type,
                    status=terminal_status,
                    content=message,
                )
            elif terminal_status == "timed out":
                message = terminal_content
                if worktree_note:
                    message = f"{message}\n\n{worktree_note}"
                send_team_session_status_message(
                    team_name=self.team_name,
                    sender_name=self.agent_name,
                    subagent_type=self.subagent_type,
                    status=terminal_status,
                    content=message,
                )
            elif terminal_status == "shutdown" and self.pending_shutdown_recipients:
                from comate_agent_sdk.agent.runner_engine.query_stream import _send_team_shutdown_response

                _send_team_shutdown_response(
                    self.runtime,
                    recipients=self.pending_shutdown_recipients,
                    extra_content=worktree_note,
                )
            elif terminal_status == "cancelled" and worktree_note:
                logger.info(
                    f"[Team session] Cancelled with preserved worktree: "
                    f"team={self.team_name!r} agent={self.agent_name!r}\n{worktree_note}"
                )
            with contextlib.suppress(Exception):
                await self.session.shutdown()

    async def _run_turn(self, prompt: str, *, is_followup_turn: bool) -> None:
        del is_followup_turn
        stop_reason = ""
        final_text = ""
        send_message_success = False
        try:
            if self.timeout_seconds and self.timeout_seconds > 0:
                async with asyncio.timeout(self.timeout_seconds):
                    async for event in self.session.query_stream(prompt):
                        if isinstance(event, StopEvent):
                            stop_reason = event.reason
                        elif isinstance(event, TextEvent):
                            normalized_text = str(event.content or "").strip()
                            if normalized_text:
                                final_text = normalized_text
                        elif (
                            isinstance(event, ToolResultEvent)
                            and event.tool == "SendMessage"
                            and not event.is_error
                        ):
                            send_message_success = True
            else:
                async for event in self.session.query_stream(prompt):
                    if isinstance(event, StopEvent):
                        stop_reason = event.reason
                    elif isinstance(event, TextEvent):
                        normalized_text = str(event.content or "").strip()
                        if normalized_text:
                            final_text = normalized_text
                    elif (
                        isinstance(event, ToolResultEvent)
                        and event.tool == "SendMessage"
                        and not event.is_error
                    ):
                        send_message_success = True
        except asyncio.TimeoutError:
            raise TeamSessionTurnTimeoutError(
                f"The team session turn timed out after {self.timeout_seconds}s. "
                "The session has been stopped."
            ) from None

        self._refresh_parent_task_state()
        if stop_reason == "completed" and final_text and not send_message_success:
            send_team_session_direct_message(
                team_name=self.team_name,
                sender_name=self.agent_name,
                content=final_text,
            )
        if stop_reason in {"waiting_for_input", "waiting_for_plan_approval"}:
            send_team_session_status_message(
                team_name=self.team_name,
                sender_name=self.agent_name,
                subagent_type=self.subagent_type,
                status="requires unsupported interaction",
                content=(
                    f"Turn stopped with reason={stop_reason!r}. "
                    "Team sessions must coordinate via SendMessage only."
                ),
            )
        elif stop_reason == "max_iterations":
            send_team_session_status_message(
                team_name=self.team_name,
                sender_name=self.agent_name,
                subagent_type=self.subagent_type,
                status="hit max iterations",
                content="Turn reached max_iterations and then returned to idle.",
            )
        if stop_reason:
            from comate_agent_sdk.agent.runner_engine.query_stream import (
                _send_team_idle_notification,
            )

            self.runtime._suppress_team_idle_notification = False
            try:
                _send_team_idle_notification(self.runtime)
            finally:
                self.runtime._suppress_team_idle_notification = True

    async def _wait_for_next_prompt(self) -> str | None:
        while True:
            shutdown_requesters, reminder, _ = _drain_team_session_turn_input(
                team_name=self.team_name,
                agent_name=self.agent_name,
            )
            if shutdown_requesters:
                self.pending_shutdown_recipients = shutdown_requesters
                return None
            if reminder:
                return reminder
            await asyncio.sleep(self.poll_interval_seconds)

    def _refresh_parent_task_state(self) -> None:
        if self.parent_runtime is None or not self.parent_runtime.is_team_member:
            return
        try:
            from comate_agent_sdk.subagent.agent_tool import _refresh_parent_task_state

            _refresh_parent_task_state(self.parent_runtime)
        except Exception as exc:
            logger.debug(
                f"[Team session] Failed to refresh parent task state: "
                f"team={self.team_name!r} agent={self.agent_name!r} error={exc}"
            )

    def _finalize_terminal_worktree_note(self) -> str:
        worktree_dir = getattr(self.runtime, "_worktree_dir", None)
        branch_name = str(getattr(self.runtime, "_worktree_branch", "") or "").strip()
        parent_cwd = getattr(self.runtime, "_worktree_parent_cwd", None)
        if not isinstance(worktree_dir, Path) or not isinstance(parent_cwd, Path):
            return ""

        from comate_agent_sdk.subagent.agent_tool import (
            _cleanup_worktree_if_exists,
            _worktree_has_changes,
        )

        if _worktree_has_changes(worktree_dir):
            return (
                "[Worktree Result]\n"
                f"worktree_path: {worktree_dir}\n"
                f"worktree_branch: {branch_name}\n"
                "has_changes: true"
            )

        _cleanup_worktree_if_exists(worktree_dir, parent_cwd, branch_name)
        return ""


def start_team_session(
    *,
    runtime: "AgentRuntime",
    parent_runtime: "AgentRuntime | None",
    subagent_type: str,
    initial_prompt: str,
    timeout_seconds: float | None,
) -> asyncio.Task[None]:
    runtime._team_session_managed = True
    runtime._suppress_team_idle_notification = True
    session_id = str(uuid.uuid4())
    runtime.options.session_id = session_id
    runtime._session_id = session_id

    session = ChatSession(
        runtime.template,
        runtime=runtime,
        session_id=session_id,
        cwd=runtime.options.cwd,
    )
    session._header_persisted = False
    session._persist_session_metadata(force=True)
    session._restore_task_state_from_task_store()
    agent_name = resolve_runtime_team_agent_name(
        runtime_name=runtime.name,
        is_subagent=bool(runtime._is_subagent),
    )
    actor = TeamSessionActor(
        session=session,
        runtime=runtime,
        parent_runtime=parent_runtime,
        subagent_type=subagent_type,
        team_name=runtime._team_name,
        agent_name=agent_name,
        initial_prompt=initial_prompt,
        timeout_seconds=timeout_seconds,
        poll_interval_seconds=resolve_team_poll_interval_seconds(
            legacy_env_var="COMATE_TEAM_SESSION_POLL_INTERVAL_SECONDS"
        ),
    )
    return asyncio.create_task(
        actor.run(),
        name=f"team-session:{runtime._team_name}:{agent_name}",
    )
