# Changelog

All notable changes to BilgeAI will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-03-07

### Added

**CLI Commands (12)**
- `bilge init` - Interactive project setup with provider selection (Anthropic/OpenAI/Google/Local)
- `bilge profile` - Hardware profiling (CPU, RAM, GPU, disk, software)
- `bilge analyze` - Dataset + tokenizer analysis with PII scanning and LLM insights
- `bilge doctor` - 8 pre-flight validation checks including API key validation
- `bilge explain` - Decision explanation engine with full LLM explanations after bilge run
- `bilge run` - Training script generation with dry-run default and cost estimation
- `bilge history` - List past training runs from experiment memory
- `bilge diff` - Compare two training runs side-by-side
- `bilge export` - Export runs as Markdown, JSON, or LaTeX
- `bilge replay` - Replay a previous training run with same config
- `bilge chart` - Generate loss/metric charts (matplotlib + ASCII fallback)
- `bilge update` - Self-update via PyPI

**LLM-First Optimization Engine**
- GuardrailEngine with 3 hardware safety rules (VRAMQuantization, VRAMBatchSize, DistributedStrategy)
- LLMOptimizer for full TrainingConfig generation via LLM
- HybridEngine orchestrating guardrails + LLM + post-validation clamping
- 4 LLM providers: Anthropic (Claude), OpenAI, Google (Gemini), Local (Ollama/vLLM/LM Studio)
- Structured JSON output with 3-layer fallback for local models
- GENERATE_CONFIG_PROMPT with 15 practical ML guidelines
- REVIEW_SCRIPT_PROMPT with 10 critical review instructions
- EVALUATE_DATASET_PROMPT for LLM-powered dataset quality assessment
- Post-processing safety: `_fix_load_dataset_file_type()` regex correction
- Provider-specific error handling with retry logic (max 2, exponential backoff)

**Code Generation**
- Jinja2-based code generator with black formatting
- 3 training templates: SFT+LoRA, DPO, RLHF/PPO
- Dataset file type auto-detection (parquet/csv/json) with directory support
- Correct `data_files` vs `data_dir` parameter selection
- `torchrun_command` for multi-GPU/node launch commands
- ast.parse() validation with fallback to template output

**Hardware Support**
- NVIDIA GPU profiling (pynvml + torch.cuda)
- AMD ROCm GPU detection
- Intel XPU GPU detection
- Apple Silicon MPS support with bf16
- Multi-GPU auto-config (DDP, FSDP, DeepSpeed ZeRO 2/3)
- Multi-node distributed training

**Data Analysis**
- Dataset loading (JSONL, JSON, CSV, Parquet)
- Format auto-detection (Alpaca, ShareGPT, custom)
- Token distribution analysis (P50/P90/P99)
- Data quality checks (empty rows, duplicates, encoding)
- Regex-based PII scanner (email, phone, TC Kimlik, credit cards)
- NER-based PII scanner (spaCy/transformers fallback)
- LLMDatasetEvaluator for AI-driven dataset insights

**Experiment Tracking**
- SQLite experiment store (RunRecord)
- Reproducibility layer (seed management, env snapshot, config hash)
- Training config saved to `.bilge/training_config.json`
- Run comparison (diff) and replay

**Export & Visualization**
- Markdown, JSON, LaTeX report export
- Loss curve charts (matplotlib + ASCII fallback)

**Integrations**
- HuggingFace Hub client, model push, model card generation
- Workflow hints system (recommended next steps after each command)
- Updated model support: gpt-4.1, gemini-2.5, claude-opus-4

**Extensibility**
- Plugin architecture with 10 hook points (ABC-based)
- Plugin discovery via entry_points
- Anonymous opt-in telemetry

**Testing**
- 308 tests across unit and integration suites
- 18 pytest fixtures

[0.1.0]: https://github.com/bugrabilge/bilge-ai/releases/tag/v0.1.0
