# API Setup Guide

## Quick Start

```bash
pip install bilgeai
bilge init
```

`bilge init` guides you interactively:
1. Model name (e.g., `meta-llama/Llama-3.1-8B`)
2. Dataset path
3. **Provider selection** (Anthropic/OpenAI/Google/Local)
4. API key or local endpoint configuration
5. Connection validation

## Provider API Key Setup

### Anthropic (Claude)

1. Go to https://console.anthropic.com
2. Create a new API key from the API Keys page
3. Set as environment variable:
   ```bash
   export ANTHROPIC_API_KEY=sk-ant-...
   ```

Recommended models:
- `claude-sonnet-4-20250514` (default, balanced)
- `claude-opus-4-20250514` (most capable)
- `claude-haiku-4-5-20251001` (fast and cheap)

### OpenAI

1. Go to https://platform.openai.com/api-keys
2. Create a new API key
3. Set as environment variable:
   ```bash
   export OPENAI_API_KEY=sk-...
   ```

Recommended models:
- `gpt-4.1` (default, powerful)
- `gpt-4.1-mini` (fast and cheap)
- `gpt-4.1-nano` (fastest, cheapest)
- `o3` (reasoning model)
- `o4-mini` (reasoning, budget)

### Google (Gemini)

1. Go to https://aistudio.google.com/apikey
2. Create an API key
3. Set as environment variable:
   ```bash
   export GEMINI_API_KEY=AI...
   ```

Recommended models:
- `gemini-2.5-flash` (default, fast)
- `gemini-2.5-pro` (most capable)
- `gemini-2.0-flash` (previous gen, stable)

### Local (Ollama/vLLM/LM Studio)

No API key required. Only endpoint URL and model name needed.

**Ollama:**
```bash
# Install Ollama and pull a model
ollama pull llama3.1:8b
# BilgeAI automatically uses http://localhost:11434/v1
```

**vLLM:**
```bash
python -m vllm.entrypoints.openai.api_server --model meta-llama/Llama-3-8B
# base_url: http://localhost:8000/v1
```

## bilge.yaml Configuration

```yaml
schema_version: "0.1.0"
model:
  name: meta-llama/Llama-3.1-8B
data:
  path: ./train.jsonl
  format: auto
llm:
  provider: anthropic          # anthropic | openai | google | local
  model: claude-sonnet-4-20250514
  api_key_env: ANTHROPIC_API_KEY
  # base_url: null             # Only for local provider
privacy:
  scan_pii: true
```

**Important:** API keys are NOT stored in bilge.yaml! Only the environment variable name is saved.

## API Key Validation

```bash
# Connection check
bilge doctor
```

`bilge doctor` validates your API key and guides you if there's an issue.

## Cost

`bilge run` shows estimated cost at the start:
```
Estimated LLM cost: ~$0.02 (claude-sonnet-4-20250514)
Note: Prices may not be up to date. Check your provider dashboard for exact costs.
```

Local provider cost is $0.00.
