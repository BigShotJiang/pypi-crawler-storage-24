"""BilgeAI - Smart LLM Training Orchestrator."""

__version__ = "0.1.0"
