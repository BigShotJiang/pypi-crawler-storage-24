"""Software version detection (PyTorch, CUDA, etc.). All imports are lazy."""


def detect_torch_version() -> str | None:
    """Detect installed PyTorch version without requiring it."""
    try:
        import torch

        return torch.__version__
    except ImportError:
        return None


def detect_transformers_version() -> str | None:
    """Detect installed transformers version."""
    try:
        import transformers

        return transformers.__version__
    except ImportError:
        return None


def detect_peft_version() -> str | None:
    """Detect installed PEFT version."""
    try:
        import peft

        return peft.__version__
    except ImportError:
        return None
