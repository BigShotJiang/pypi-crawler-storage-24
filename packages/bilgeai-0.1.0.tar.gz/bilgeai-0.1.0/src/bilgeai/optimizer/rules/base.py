"""Base rule interface."""

from abc import ABC, abstractmethod

from bilgeai.analyzer.models import DatasetProfile
from bilgeai.optimizer.models import TrainingConfig
from bilgeai.profiler.models import HardwareProfile


class Rule(ABC):
    """Abstract base class for optimization rules."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Rule name for logging."""
        ...

    @property
    @abstractmethod
    def priority(self) -> int:
        """Priority level: P0 (highest) to P4 (lowest)."""
        ...

    @abstractmethod
    def apply(
        self,
        config: TrainingConfig,
        hardware: HardwareProfile,
        dataset: DatasetProfile,
    ) -> TrainingConfig:
        """Apply this rule to the training config. Returns modified config."""
        ...
