"""BilgeAI plugin system."""

from bilgeai.plugins.base import BilgePlugin, HookType
from bilgeai.plugins.manager import PluginManager

__all__ = ["BilgePlugin", "HookType", "PluginManager"]
