"""CLI output hints and error helpers."""

from rich.console import Console

WORKFLOW_HINTS: dict[str, list[tuple[str, str]]] = {
    "profile": [("bilge analyze", "")],
    "analyze": [("bilge doctor", "")],
    "doctor": [("bilge run", "")],
    "run": [
        ("bilge explain", "See why each parameter was chosen"),
        ("bilge run --start", "Start training"),
    ],
    "explain": [("bilge run --start", "")],
}


def show_next_hint(command: str, console: Console) -> None:
    """Show the recommended next command after successful execution."""
    hints = WORKFLOW_HINTS.get(command)
    if not hints:
        return
    for cmd, description in hints:
        if description:
            console.print(f"\n[dim]Next >> [bold]{cmd}[/bold] — {description}[/dim]")
        else:
            console.print(f"\n[dim]Next >> [bold]{cmd}[/bold][/dim]")
