"""bilge doctor - Pre-flight validation checks."""

import typer
from rich.console import Console
from rich.table import Table

from bilgeai.validation.preflight import run_preflight_checks

console = Console()


def doctor_command() -> None:
    """Run pre-flight validation checks."""
    console.print("[bold]Running pre-flight checks...[/bold]\n")

    report = run_preflight_checks()

    table = Table(title="Pre-flight Checks", show_header=True)
    table.add_column("Check", style="cyan")
    table.add_column("Status")
    table.add_column("Details")

    status_icons = {
        "pass": "[green]PASS[/green]",
        "warn": "[yellow]WARN[/yellow]",
        "fail": "[red]FAIL[/red]",
    }

    for check in report.checks:
        table.add_row(check.name, status_icons[check.status], check.message)

    console.print(table)

    # Show suggestions for failures/warnings
    suggestions = [c for c in report.checks if c.suggestion]
    if suggestions:
        console.print("\n[bold]Suggestions:[/bold]")
        for check in suggestions:
            icon = "[red]>[/red]" if check.status == "fail" else "[yellow]>[/yellow]"
            console.print(f"  {icon} {check.suggestion}")

    # Summary
    console.print(
        f"\n[bold]Summary:[/bold] "
        f"[green]{report.num_pass} passed[/green], "
        f"[yellow]{report.num_warn} warnings[/yellow], "
        f"[red]{report.num_fail} failed[/red]"
    )

    if not report.passed:
        console.print("\n[red]Some checks failed. Fix the issues above, then re-run:[/red]")
        console.print("  [bold]bilge doctor[/bold]")
        raise typer.Exit(1)
    else:
        console.print("\n[green]All critical checks passed![/green]")

        from bilgeai.cli.hints import show_next_hint

        show_next_hint("doctor", console)
