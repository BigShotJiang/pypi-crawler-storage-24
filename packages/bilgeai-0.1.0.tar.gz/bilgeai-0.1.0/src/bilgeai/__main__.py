"""Support running BilgeAI as `python -m bilgeai`."""

from bilgeai.cli.app import app

app()
