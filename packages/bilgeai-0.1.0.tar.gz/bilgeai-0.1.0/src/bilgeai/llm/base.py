"""Base LLM client abstraction."""

from __future__ import annotations

from abc import ABC, abstractmethod

from pydantic import BaseModel


class LLMResponse(BaseModel):
    """Response from an LLM."""

    content: str
    model: str
    source: str  # "local" or "remote"
    tokens_used: int | None = None


class LLMClient(ABC):
    """Abstract base class for LLM clients."""

    @abstractmethod
    def generate(self, prompt: str, system: str | None = None) -> LLMResponse:
        """Generate a response from the LLM."""

    @abstractmethod
    def is_available(self) -> bool:
        """Check if this LLM backend is reachable."""

    @property
    @abstractmethod
    def source_name(self) -> str:
        """Return the source identifier (e.g., 'local_llm', 'remote_api')."""
