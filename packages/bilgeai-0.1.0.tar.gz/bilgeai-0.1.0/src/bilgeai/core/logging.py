"""BilgeAI logging configuration using Rich."""

import logging

from rich.console import Console
from rich.logging import RichHandler

console = Console()

_configured = False


def setup_logging(verbose: bool = False) -> None:
    """Configure logging with Rich handler."""
    global _configured
    if _configured:
        return

    level = logging.DEBUG if verbose else logging.INFO

    logging.basicConfig(
        level=level,
        format="%(message)s",
        datefmt="[%X]",
        handlers=[RichHandler(console=console, rich_tracebacks=True, show_path=False)],
    )

    _configured = True


def get_logger(name: str) -> logging.Logger:
    """Get a named logger."""
    setup_logging()
    return logging.getLogger(name)
