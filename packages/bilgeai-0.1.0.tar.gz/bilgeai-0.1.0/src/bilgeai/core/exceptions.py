"""BilgeAI exception hierarchy."""


class BilgeError(Exception):
    """Base exception for all BilgeAI errors."""

    def __init__(self, message: str, suggestion: str | None = None) -> None:
        super().__init__(message)
        self.suggestion = suggestion


class HardwareError(BilgeError):
    """Hardware-related errors: OOM, CUDA incompatibility, etc."""


class DataError(BilgeError):
    """Data-related errors: format issues, empty dataset, PII found, etc."""


class ConfigError(BilgeError):
    """Configuration errors: invalid parameter combinations, missing fields, etc."""


class TrainingRuntimeError(BilgeError):
    """Unexpected errors during training execution.

    Named TrainingRuntimeError (not RuntimeError) to avoid shadowing Python's builtin.
    """


class LLMError(BilgeError):
    """LLM API errors: invalid key, rate limit, network failure."""
