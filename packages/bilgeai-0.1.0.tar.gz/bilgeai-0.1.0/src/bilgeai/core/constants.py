"""BilgeAI constants."""

from pathlib import Path
from typing import Literal

# Project file names
CONFIG_FILE = "bilge.yaml"
PROJECT_DIR = ".bilge"
SCHEMA_VERSION = "0.1.0"
SUPPORTED_MAX_VERSION = "0.1.0"

# Provider type
ProviderType = Literal["anthropic", "openai", "google", "local"]

# Default model families supported in Phase 1
SUPPORTED_MODEL_FAMILIES = ["llama", "mistral", "qwen"]

# Dataset format types
DATASET_FORMATS = ["alpaca", "sharegpt", "custom", "unknown"]

# Quantization options
QUANTIZATION_OPTIONS = ["none", "4bit", "8bit"]

# VRAM thresholds (GB) for rule engine decisions
VRAM_VERY_LOW = 6.0
VRAM_LOW = 12.0
VRAM_MEDIUM = 24.0

# Default training parameters
DEFAULT_LEARNING_RATE = 2e-4
DEFAULT_WARMUP_RATIO = 0.03
DEFAULT_WEIGHT_DECAY = 0.01
DEFAULT_LORA_RANK = 16
DEFAULT_LORA_ALPHA = 32
DEFAULT_LORA_DROPOUT = 0.05

# PII regex patterns
PII_PATTERNS: dict[str, str] = {
    "email": r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}",
    "phone_tr": r"(?:\+90|0)\s?[0-9]{3}\s?[0-9]{3}\s?[0-9]{2}\s?[0-9]{2}",
    "tc_kimlik": r"\b[1-9][0-9]{10}\b",
    "credit_card": r"\b[0-9]{4}[\s-]?[0-9]{4}[\s-]?[0-9]{4}[\s-]?[0-9]{4}\b",
    "phone_intl": r"\+[1-9][0-9]{6,14}",
}

# Provider defaults
PROVIDER_DEFAULTS: dict[str, dict[str, str]] = {
    "anthropic": {
        "model": "claude-sonnet-4-20250514",
        "api_key_env": "ANTHROPIC_API_KEY",
    },
    "openai": {
        "model": "gpt-4.1",
        "api_key_env": "OPENAI_API_KEY",
    },
    "google": {
        "model": "gemini-2.5-flash",
        "api_key_env": "GEMINI_API_KEY",
    },
    "local": {
        "model": "local-model",
        "api_key_env": "",
        "base_url": "http://localhost:11434/v1",
    },
}

# Approximate pricing per 1M tokens (USD)
# Format: {model_prefix: (input_cost, output_cost)}
# Note: Prices may not be up to date. Check your provider dashboard for exact costs.
MODEL_PRICING: dict[str, tuple[float, float]] = {
    # Anthropic
    "claude-opus": (15.0, 75.0),
    "claude-sonnet": (3.0, 15.0),
    "claude-haiku": (0.25, 1.25),
    # OpenAI
    "gpt-4.1": (2.0, 8.0),
    "gpt-4.1-mini": (0.4, 1.6),
    "gpt-4.1-nano": (0.1, 0.4),
    "o3": (2.0, 8.0),
    "o4-mini": (1.1, 4.4),
    "gpt-4o": (2.5, 10.0),
    "gpt-4o-mini": (0.15, 0.6),
    # Google
    "gemini-2.5-pro": (1.25, 10.0),
    "gemini-2.5-flash": (0.15, 0.6),
    "gemini-2.0-flash": (0.1, 0.4),
    "gemini-1.5-pro": (3.5, 10.5),
}

# Estimated token counts per bilge run LLM call
ESTIMATED_TOKENS_CONFIG_OPTIMIZE = 3000  # ~2K input + ~1K output
ESTIMATED_TOKENS_SCRIPT_REVIEW = 5000  # ~3K input + ~2K output
ESTIMATED_TOKENS_DATASET_EVAL = 1500  # ~1K input + ~500 output


# Cache and data paths
def get_project_dir(base: Path | None = None) -> Path:
    """Get the .bilge project directory."""
    return (base or Path.cwd()) / PROJECT_DIR


def get_config_path(base: Path | None = None) -> Path:
    """Get the bilge.yaml path."""
    return (base or Path.cwd()) / CONFIG_FILE
