# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 0.1.x   | Yes                |

## Reporting a Vulnerability

If you discover a security vulnerability in BilgeAI, **please do not open a public GitHub issue.**

Instead, report it privately:

1. Go to [Security Advisories](https://github.com/bugrabilge/bilge-ai/security/advisories/new)
2. Click **"Report a vulnerability"**
3. Provide a clear description, steps to reproduce, and potential impact

You will receive an acknowledgment within 48 hours and a detailed response within 7 days.

## Security Design

BilgeAI handles sensitive data during training workflows. Here's how we protect it:

### API Keys
- API keys are **never** stored in config files — only environment variable names are saved
- `bilge init` masks key input in the terminal
- Keys are validated with a minimal test call, then discarded from memory

### PII Scanning
- `bilge analyze` includes regex-based PII detection (email, phone, credit card, TC Kimlik)
- Optional NER-based scanning via spaCy/transformers
- PII findings are displayed locally and never transmitted

### LLM Data Handling
- Only dataset **statistics** and **sample rows** (5-10) are sent to LLM providers for analysis
- Full datasets are never uploaded
- Local provider option available for air-gapped environments

### Dependencies
- Pre-commit hooks include `detect-private-key` check
- CI runs on every push with linting and test validation
