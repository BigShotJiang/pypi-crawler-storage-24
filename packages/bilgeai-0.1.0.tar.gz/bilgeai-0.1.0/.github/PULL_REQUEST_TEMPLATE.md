## Summary

Brief description of what this PR does.

## Changes

-
-

## Related Issue

Closes #

## Checklist

- [ ] Tests pass (`pytest tests/`)
- [ ] Lint clean (`ruff check src/`)
- [ ] Format clean (`ruff format --check src/`)
- [ ] Documentation updated (if applicable)
- [ ] CHANGELOG.md updated (if user-facing change)
