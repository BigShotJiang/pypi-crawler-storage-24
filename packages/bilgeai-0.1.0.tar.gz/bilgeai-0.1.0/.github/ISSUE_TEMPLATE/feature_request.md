---
name: Feature Request
about: Suggest a new feature for BilgeAI
title: "[FEATURE] "
labels: enhancement
assignees: ""
---

## Problem

What problem does this feature solve?

## Proposed Solution

Describe the feature you'd like.

## Alternatives Considered

Any alternative approaches you've thought about.

## Additional Context

Examples, mockups, or references.
