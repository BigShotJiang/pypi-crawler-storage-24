---
name: Bug Report
about: Report a bug in BilgeAI
title: "[BUG] "
labels: bug
assignees: ""
---

## Description

A clear description of the bug.

## Steps to Reproduce

1. Run `bilge ...`
2. ...
3. See error

## Expected Behavior

What you expected to happen.

## Actual Behavior

What actually happened. Include full error output if possible.

## Environment

- OS: (e.g., Windows 11, Ubuntu 22.04, macOS 14)
- Python: (e.g., 3.11.9)
- BilgeAI version: (run `bilge --version`)
- GPU: (run `bilge profile`)

## Additional Context

Any other info (config file, dataset format, etc.)
