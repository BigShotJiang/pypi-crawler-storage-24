"""Tests for the hardware profiler."""

from bilgeai.profiler.models import GPUInfo, HardwareProfile


class TestGPUInfo:
    def test_basic_creation(self):
        gpu = GPUInfo(name="Test GPU", vram_gb=8.0)
        assert gpu.name == "Test GPU"
        assert gpu.vram_gb == 8.0
        assert gpu.cuda_version is None

    def test_full_creation(self):
        gpu = GPUInfo(
            name="NVIDIA RTX 3070",
            vram_gb=8.0,
            cuda_version="12.1",
            compute_capability="8.6",
            driver_version="535.104",
        )
        assert gpu.cuda_version == "12.1"
        assert gpu.compute_capability == "8.6"


class TestHardwareProfile:
    def test_no_gpu(self, hw_no_gpu):
        assert hw_no_gpu.gpus == []
        assert hw_no_gpu.cuda_available is False
        assert hw_no_gpu.torch_version is None

    def test_with_gpu(self, hw_mid_gpu):
        assert len(hw_mid_gpu.gpus) == 1
        assert hw_mid_gpu.cuda_available is True
        assert hw_mid_gpu.gpus[0].vram_gb == 8.0

    def test_serialization(self, hw_mid_gpu):
        data = hw_mid_gpu.model_dump()
        restored = HardwareProfile.model_validate(data)
        assert restored.cpu_name == hw_mid_gpu.cpu_name
        assert restored.gpus[0].name == hw_mid_gpu.gpus[0].name
