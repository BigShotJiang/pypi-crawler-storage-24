"""Tests for exception hierarchy."""

from bilgeai.core.exceptions import (
    BilgeError,
    ConfigError,
    DataError,
    HardwareError,
    TrainingRuntimeError,
)


class TestExceptionHierarchy:
    def test_all_inherit_from_bilge_error(self):
        assert issubclass(HardwareError, BilgeError)
        assert issubclass(DataError, BilgeError)
        assert issubclass(ConfigError, BilgeError)
        assert issubclass(TrainingRuntimeError, BilgeError)

    def test_does_not_shadow_runtime_error(self):
        assert not issubclass(TrainingRuntimeError, RuntimeError)

    def test_suggestion_field(self):
        err = ConfigError("bad config", suggestion="Try bilge init")
        assert err.suggestion == "Try bilge init"
        assert str(err) == "bad config"

    def test_no_suggestion(self):
        err = HardwareError("GPU not found")
        assert err.suggestion is None
