"""Tests for the PII scanner."""

from bilgeai.analyzer.privacy import scan_for_pii


class TestPIIScanner:
    def test_detect_email(self):
        rows = [{"text": "Contact me at user@example.com for info"}]
        findings = scan_for_pii(rows)
        assert any(f.pii_type == "email" for f in findings)

    def test_detect_phone_tr(self):
        rows = [{"text": "Numaram: +90 532 123 45 67"}]
        findings = scan_for_pii(rows)
        assert any(f.pii_type == "phone_tr" for f in findings)

    def test_detect_credit_card(self):
        rows = [{"text": "Kart: 4111-1111-1111-1111"}]
        findings = scan_for_pii(rows)
        assert any(f.pii_type == "credit_card" for f in findings)

    def test_no_pii(self):
        rows = [
            {"text": "Python is a programming language"},
            {"text": "Machine learning is fun"},
        ]
        findings = scan_for_pii(rows)
        assert len(findings) == 0

    def test_multiple_pii_types(self):
        rows = [{"text": "Email: a@b.com, Phone: +90 532 123 45 67"}]
        findings = scan_for_pii(rows)
        types = {f.pii_type for f in findings}
        assert "email" in types
        assert "phone_tr" in types

    def test_count_multiple_occurrences(self):
        rows = [
            {"text": "user1@test.com"},
            {"text": "user2@test.com"},
            {"text": "no pii here"},
        ]
        findings = scan_for_pii(rows)
        email_finding = next(f for f in findings if f.pii_type == "email")
        assert email_finding.count == 2
