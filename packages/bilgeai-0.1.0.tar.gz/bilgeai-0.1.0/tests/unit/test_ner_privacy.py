"""Tests for NER-based PII scanning."""

from bilgeai.analyzer.ner_privacy import _build_findings, scan_with_ner


class TestBuildFindings:
    def test_basic_findings(self):
        entity_indices = {
            "PERSON": [0, 1, 3],
            "ORG": [2],
        }
        findings = _build_findings(entity_indices)
        assert len(findings) == 2

        person_finding = next(f for f in findings if f.pii_type == "ner_person")
        assert person_finding.count == 3
        assert person_finding.sample_indices == [0, 1, 3]

    def test_empty_indices_skipped(self):
        entity_indices = {
            "PERSON": [],
            "ORG": [1],
        }
        findings = _build_findings(entity_indices)
        assert len(findings) == 1
        assert findings[0].pii_type == "ner_org"

    def test_duplicate_indices_deduplicated(self):
        entity_indices = {"PERSON": [0, 0, 1, 1, 2]}
        findings = _build_findings(entity_indices)
        assert findings[0].count == 3  # unique: 0, 1, 2

    def test_sample_indices_limited(self):
        entity_indices = {"LOC": list(range(20))}
        findings = _build_findings(entity_indices)
        assert len(findings[0].sample_indices) <= 5


class TestScanWithNer:
    def test_returns_list_when_no_ner_available(self):
        """When neither spaCy nor transformers is available, returns empty list."""
        rows = [{"text": "John Smith lives at 123 Main St"}]
        # This will likely return [] in test env without spaCy/transformers NER
        result = scan_with_ner(rows)
        assert isinstance(result, list)

    def test_empty_rows(self):
        result = scan_with_ner([])
        assert result == []
