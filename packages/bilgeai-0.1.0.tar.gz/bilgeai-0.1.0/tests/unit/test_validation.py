"""Tests for pre-flight validation."""

from bilgeai.validation.preflight import (
    CheckResult,
    PreflightReport,
    _check_config_exists,
    _check_dependencies,
    _check_disk_space,
    _check_python_version,
    run_preflight_checks,
)


class TestCheckResult:
    def test_pass(self):
        r = CheckResult("test", "pass", "ok")
        assert r.status == "pass"
        assert r.suggestion is None

    def test_fail_with_suggestion(self):
        r = CheckResult("test", "fail", "bad", suggestion="fix it")
        assert r.suggestion == "fix it"


class TestPreflightReport:
    def test_all_pass(self):
        report = PreflightReport(
            checks=[
                CheckResult("a", "pass", "ok"),
                CheckResult("b", "pass", "ok"),
            ]
        )
        assert report.passed is True
        assert report.num_pass == 2
        assert report.num_fail == 0

    def test_with_failure(self):
        report = PreflightReport(
            checks=[
                CheckResult("a", "pass", "ok"),
                CheckResult("b", "fail", "bad"),
            ]
        )
        assert report.passed is False
        assert report.num_fail == 1

    def test_warn_still_passes(self):
        report = PreflightReport(
            checks=[
                CheckResult("a", "pass", "ok"),
                CheckResult("b", "warn", "maybe"),
            ]
        )
        assert report.passed is True
        assert report.num_warn == 1


class TestIndividualChecks:
    def test_config_exists(self, tmp_path):
        (tmp_path / "bilge.yaml").write_text("model:\n  name: test")
        result = _check_config_exists(tmp_path)
        assert result.status == "pass"

    def test_config_missing(self, tmp_path):
        result = _check_config_exists(tmp_path)
        assert result.status == "fail"

    def test_python_version(self):
        result = _check_python_version()
        assert result.status == "pass"  # We're running 3.10+

    def test_dependencies(self):
        result = _check_dependencies()
        assert result.status == "pass"  # Core deps are installed

    def test_disk_space(self, tmp_path):
        result = _check_disk_space(tmp_path)
        assert result.status in ("pass", "warn", "fail")


class TestRunPreflight:
    def test_runs_without_error(self, tmp_path):
        report = run_preflight_checks(tmp_path)
        assert isinstance(report, PreflightReport)
        assert len(report.checks) > 0
