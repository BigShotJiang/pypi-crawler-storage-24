"""Tests for HuggingFace Hub client."""

import pytest

from bilgeai.hub.client import HubClient, ModelInfo


class TestModelInfo:
    def test_basic_creation(self):
        info = ModelInfo(model_id="meta-llama/Llama-3-8B")
        assert info.model_id == "meta-llama/Llama-3-8B"
        assert info.size_gb is None

    def test_with_size(self):
        info = ModelInfo(
            model_id="test/model",
            size_bytes=16_000_000_000,
            size_gb=14.9,
            architecture="LlamaForCausalLM",
        )
        assert info.size_gb == pytest.approx(14.9)
        assert info.architecture == "LlamaForCausalLM"


class TestHubClient:
    def test_client_creation(self):
        client = HubClient()
        assert client._api is None

    def test_lazy_api_init_fails_without_package(self):
        """Should raise ImportError if huggingface_hub not installed."""
        client = HubClient()
        # We can't guarantee huggingface_hub is installed in test env
        # Just verify the method exists and is callable
        assert callable(client.get_model_info)
        assert callable(client.validate_model_exists)
        assert callable(client.validate_dataset_exists)
        assert callable(client.estimate_model_vram)

    def test_estimate_vram_with_model_info(self):
        """Test VRAM estimation logic with mocked model info."""
        client = HubClient()

        # Mock the get_model_info to return a known size
        info = ModelInfo(model_id="test/7b", size_gb=14.0)
        client.get_model_info = lambda _: info

        # Full precision: 14 * 1.0 * 1.2 = 16.8
        result = client.estimate_model_vram("test/7b", "none")
        assert result == pytest.approx(16.8)

        # 4-bit: 14 * 0.25 * 1.2 = 4.2
        result = client.estimate_model_vram("test/7b", "4bit")
        assert result == pytest.approx(4.2)

        # 8-bit: 14 * 0.5 * 1.2 = 8.4
        result = client.estimate_model_vram("test/7b", "8bit")
        assert result == pytest.approx(8.4)

    def test_estimate_vram_no_info(self):
        """VRAM estimation returns None when model info unavailable."""
        client = HubClient()
        client.get_model_info = lambda _: None
        result = client.estimate_model_vram("unknown/model")
        assert result is None
