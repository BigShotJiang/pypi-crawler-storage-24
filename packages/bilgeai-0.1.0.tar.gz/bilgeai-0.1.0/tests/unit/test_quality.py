"""Tests for data quality checks."""

from bilgeai.analyzer.quality import (
    check_duplicates,
    check_empty_rows,
    check_encoding_issues,
    run_quality_checks,
)


class TestQualityChecks:
    def test_detect_empty_rows(self):
        rows = [
            {"text": "hello"},
            {"text": ""},
            {"text": "world"},
        ]
        issue = check_empty_rows(rows)
        assert issue is not None
        assert issue.issue_type == "empty_row"
        assert issue.count == 1

    def test_no_empty_rows(self):
        rows = [{"text": "hello"}, {"text": "world"}]
        assert check_empty_rows(rows) is None

    def test_detect_duplicates(self):
        rows = [
            {"text": "hello"},
            {"text": "world"},
            {"text": "hello"},
        ]
        issue = check_duplicates(rows)
        assert issue is not None
        assert issue.issue_type == "duplicate"
        assert issue.count == 1

    def test_no_duplicates(self):
        rows = [{"text": "hello"}, {"text": "world"}]
        assert check_duplicates(rows) is None

    def test_detect_encoding_issues(self):
        rows = [{"text": "hello \ufffd world"}]
        issue = check_encoding_issues(rows)
        assert issue is not None
        assert issue.issue_type == "encoding_error"

    def test_run_all_checks(self):
        rows = [
            {"text": "hello"},
            {"text": ""},
            {"text": "hello"},
        ]
        issues = run_quality_checks(rows)
        types = {i.issue_type for i in issues}
        assert "empty_row" in types
        assert "duplicate" in types
