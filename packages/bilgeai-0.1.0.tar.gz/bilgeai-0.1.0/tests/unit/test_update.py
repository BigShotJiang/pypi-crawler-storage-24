"""Tests for bilge update command."""

from unittest.mock import patch

from bilgeai.cli.commands.update import _get_latest_version


class TestGetLatestVersion:
    def test_returns_string_or_none(self):
        # This will either return a version or None depending on network
        result = _get_latest_version()
        assert result is None or isinstance(result, str)

    @patch("urllib.request.urlopen")
    def test_returns_none_on_error(self, mock_urlopen):
        mock_urlopen.side_effect = Exception("Network error")
        result = _get_latest_version()
        assert result is None


class TestUpdateCommand:
    def test_update_registered(self):
        from bilgeai.cli.app import app

        command_names = [cmd.name for cmd in app.registered_commands]
        assert "update" in command_names
