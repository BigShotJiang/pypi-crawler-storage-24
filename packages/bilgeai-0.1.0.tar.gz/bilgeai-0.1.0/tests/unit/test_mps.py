"""Tests for Apple Silicon MPS support."""

from unittest.mock import MagicMock, patch

from bilgeai.profiler.gpu import _detect_apple_mps
from bilgeai.profiler.models import GPUInfo


class TestMPSDetection:
    def test_mps_not_available(self):
        with patch.dict("sys.modules", {"torch": MagicMock()}):
            import sys

            mock_torch = sys.modules["torch"]
            mock_torch.backends.mps.is_available.return_value = False
            result = _detect_apple_mps()
            # Returns None if MPS not available or import fails
            assert result is None or result == []

    def test_mps_detection_no_torch(self):
        """Should return None when torch is not installed."""
        with patch.dict("sys.modules", {"torch": None}):
            result = _detect_apple_mps()
            assert result is None


class TestAppleGPUInfo:
    def test_apple_vendor(self):
        gpu = GPUInfo(name="Apple M2 Pro", vram_gb=12.0, vendor="apple")
        assert gpu.vendor == "apple"
        assert gpu.cuda_version is None
        assert gpu.compute_capability is None
