#----------------------------------------------------------------
# Generated CMake target import file for configuration "MinSizeRel".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "eccodes_memfs" for configuration "MinSizeRel"
set_property(TARGET eccodes_memfs APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(eccodes_memfs PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib64/libeccodes_memfs.so"
  IMPORTED_SONAME_MINSIZEREL "libeccodes_memfs.so"
  )

list(APPEND _cmake_import_check_targets eccodes_memfs )
list(APPEND _cmake_import_check_files_for_eccodes_memfs "${_IMPORT_PREFIX}/lib64/libeccodes_memfs.so" )

# Import target "eccodes" for configuration "MinSizeRel"
set_property(TARGET eccodes APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(eccodes PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_MINSIZEREL "eccodes_memfs;eckit_geo;libaec::aec-shared"
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib64/libeccodes.so"
  IMPORTED_SONAME_MINSIZEREL "libeccodes.so"
  )

list(APPEND _cmake_import_check_targets eccodes )
list(APPEND _cmake_import_check_files_for_eccodes "${_IMPORT_PREFIX}/lib64/libeccodes.so" )

# Import target "codes_info" for configuration "MinSizeRel"
set_property(TARGET codes_info APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(codes_info PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/codes_info"
  )

list(APPEND _cmake_import_check_targets codes_info )
list(APPEND _cmake_import_check_files_for_codes_info "${_IMPORT_PREFIX}/bin/codes_info" )

# Import target "codes_count" for configuration "MinSizeRel"
set_property(TARGET codes_count APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(codes_count PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/codes_count"
  )

list(APPEND _cmake_import_check_targets codes_count )
list(APPEND _cmake_import_check_files_for_codes_count "${_IMPORT_PREFIX}/bin/codes_count" )

# Import target "codes_split_file" for configuration "MinSizeRel"
set_property(TARGET codes_split_file APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(codes_split_file PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/codes_split_file"
  )

list(APPEND _cmake_import_check_targets codes_split_file )
list(APPEND _cmake_import_check_files_for_codes_split_file "${_IMPORT_PREFIX}/bin/codes_split_file" )

# Import target "codes_export_resource" for configuration "MinSizeRel"
set_property(TARGET codes_export_resource APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(codes_export_resource PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/codes_export_resource"
  )

list(APPEND _cmake_import_check_targets codes_export_resource )
list(APPEND _cmake_import_check_files_for_codes_export_resource "${_IMPORT_PREFIX}/bin/codes_export_resource" )

# Import target "grib_histogram" for configuration "MinSizeRel"
set_property(TARGET grib_histogram APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(grib_histogram PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/grib_histogram"
  )

list(APPEND _cmake_import_check_targets grib_histogram )
list(APPEND _cmake_import_check_files_for_grib_histogram "${_IMPORT_PREFIX}/bin/grib_histogram" )

# Import target "grib_filter" for configuration "MinSizeRel"
set_property(TARGET grib_filter APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(grib_filter PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/grib_filter"
  )

list(APPEND _cmake_import_check_targets grib_filter )
list(APPEND _cmake_import_check_files_for_grib_filter "${_IMPORT_PREFIX}/bin/grib_filter" )

# Import target "grib_ls" for configuration "MinSizeRel"
set_property(TARGET grib_ls APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(grib_ls PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/grib_ls"
  )

list(APPEND _cmake_import_check_targets grib_ls )
list(APPEND _cmake_import_check_files_for_grib_ls "${_IMPORT_PREFIX}/bin/grib_ls" )

# Import target "grib_dump" for configuration "MinSizeRel"
set_property(TARGET grib_dump APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(grib_dump PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/grib_dump"
  )

list(APPEND _cmake_import_check_targets grib_dump )
list(APPEND _cmake_import_check_files_for_grib_dump "${_IMPORT_PREFIX}/bin/grib_dump" )

# Import target "grib2ppm" for configuration "MinSizeRel"
set_property(TARGET grib2ppm APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(grib2ppm PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/grib2ppm"
  )

list(APPEND _cmake_import_check_targets grib2ppm )
list(APPEND _cmake_import_check_files_for_grib2ppm "${_IMPORT_PREFIX}/bin/grib2ppm" )

# Import target "grib_set" for configuration "MinSizeRel"
set_property(TARGET grib_set APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(grib_set PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/grib_set"
  )

list(APPEND _cmake_import_check_targets grib_set )
list(APPEND _cmake_import_check_files_for_grib_set "${_IMPORT_PREFIX}/bin/grib_set" )

# Import target "grib_get" for configuration "MinSizeRel"
set_property(TARGET grib_get APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(grib_get PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/grib_get"
  )

list(APPEND _cmake_import_check_targets grib_get )
list(APPEND _cmake_import_check_files_for_grib_get "${_IMPORT_PREFIX}/bin/grib_get" )

# Import target "grib_get_data" for configuration "MinSizeRel"
set_property(TARGET grib_get_data APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(grib_get_data PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/grib_get_data"
  )

list(APPEND _cmake_import_check_targets grib_get_data )
list(APPEND _cmake_import_check_files_for_grib_get_data "${_IMPORT_PREFIX}/bin/grib_get_data" )

# Import target "grib_copy" for configuration "MinSizeRel"
set_property(TARGET grib_copy APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(grib_copy PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/grib_copy"
  )

list(APPEND _cmake_import_check_targets grib_copy )
list(APPEND _cmake_import_check_files_for_grib_copy "${_IMPORT_PREFIX}/bin/grib_copy" )

# Import target "grib_compare" for configuration "MinSizeRel"
set_property(TARGET grib_compare APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(grib_compare PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/grib_compare"
  )

list(APPEND _cmake_import_check_targets grib_compare )
list(APPEND _cmake_import_check_files_for_grib_compare "${_IMPORT_PREFIX}/bin/grib_compare" )

# Import target "codes_parser" for configuration "MinSizeRel"
set_property(TARGET codes_parser APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(codes_parser PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/codes_parser"
  )

list(APPEND _cmake_import_check_targets codes_parser )
list(APPEND _cmake_import_check_files_for_codes_parser "${_IMPORT_PREFIX}/bin/codes_parser" )

# Import target "grib_index_build" for configuration "MinSizeRel"
set_property(TARGET grib_index_build APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(grib_index_build PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/grib_index_build"
  )

list(APPEND _cmake_import_check_targets grib_index_build )
list(APPEND _cmake_import_check_files_for_grib_index_build "${_IMPORT_PREFIX}/bin/grib_index_build" )

# Import target "bufr_index_build" for configuration "MinSizeRel"
set_property(TARGET bufr_index_build APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(bufr_index_build PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/bufr_index_build"
  )

list(APPEND _cmake_import_check_targets bufr_index_build )
list(APPEND _cmake_import_check_files_for_bufr_index_build "${_IMPORT_PREFIX}/bin/bufr_index_build" )

# Import target "bufr_ls" for configuration "MinSizeRel"
set_property(TARGET bufr_ls APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(bufr_ls PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/bufr_ls"
  )

list(APPEND _cmake_import_check_targets bufr_ls )
list(APPEND _cmake_import_check_files_for_bufr_ls "${_IMPORT_PREFIX}/bin/bufr_ls" )

# Import target "bufr_dump" for configuration "MinSizeRel"
set_property(TARGET bufr_dump APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(bufr_dump PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/bufr_dump"
  )

list(APPEND _cmake_import_check_targets bufr_dump )
list(APPEND _cmake_import_check_files_for_bufr_dump "${_IMPORT_PREFIX}/bin/bufr_dump" )

# Import target "bufr_set" for configuration "MinSizeRel"
set_property(TARGET bufr_set APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(bufr_set PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/bufr_set"
  )

list(APPEND _cmake_import_check_targets bufr_set )
list(APPEND _cmake_import_check_files_for_bufr_set "${_IMPORT_PREFIX}/bin/bufr_set" )

# Import target "bufr_get" for configuration "MinSizeRel"
set_property(TARGET bufr_get APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(bufr_get PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/bufr_get"
  )

list(APPEND _cmake_import_check_targets bufr_get )
list(APPEND _cmake_import_check_files_for_bufr_get "${_IMPORT_PREFIX}/bin/bufr_get" )

# Import target "bufr_copy" for configuration "MinSizeRel"
set_property(TARGET bufr_copy APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(bufr_copy PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/bufr_copy"
  )

list(APPEND _cmake_import_check_targets bufr_copy )
list(APPEND _cmake_import_check_files_for_bufr_copy "${_IMPORT_PREFIX}/bin/bufr_copy" )

# Import target "bufr_compare" for configuration "MinSizeRel"
set_property(TARGET bufr_compare APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(bufr_compare PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/bufr_compare"
  )

list(APPEND _cmake_import_check_targets bufr_compare )
list(APPEND _cmake_import_check_files_for_bufr_compare "${_IMPORT_PREFIX}/bin/bufr_compare" )

# Import target "gts_get" for configuration "MinSizeRel"
set_property(TARGET gts_get APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(gts_get PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/gts_get"
  )

list(APPEND _cmake_import_check_targets gts_get )
list(APPEND _cmake_import_check_files_for_gts_get "${_IMPORT_PREFIX}/bin/gts_get" )

# Import target "gts_compare" for configuration "MinSizeRel"
set_property(TARGET gts_compare APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(gts_compare PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/gts_compare"
  )

list(APPEND _cmake_import_check_targets gts_compare )
list(APPEND _cmake_import_check_files_for_gts_compare "${_IMPORT_PREFIX}/bin/gts_compare" )

# Import target "gts_copy" for configuration "MinSizeRel"
set_property(TARGET gts_copy APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(gts_copy PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/gts_copy"
  )

list(APPEND _cmake_import_check_targets gts_copy )
list(APPEND _cmake_import_check_files_for_gts_copy "${_IMPORT_PREFIX}/bin/gts_copy" )

# Import target "gts_dump" for configuration "MinSizeRel"
set_property(TARGET gts_dump APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(gts_dump PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/gts_dump"
  )

list(APPEND _cmake_import_check_targets gts_dump )
list(APPEND _cmake_import_check_files_for_gts_dump "${_IMPORT_PREFIX}/bin/gts_dump" )

# Import target "gts_filter" for configuration "MinSizeRel"
set_property(TARGET gts_filter APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(gts_filter PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/gts_filter"
  )

list(APPEND _cmake_import_check_targets gts_filter )
list(APPEND _cmake_import_check_files_for_gts_filter "${_IMPORT_PREFIX}/bin/gts_filter" )

# Import target "gts_ls" for configuration "MinSizeRel"
set_property(TARGET gts_ls APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(gts_ls PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/gts_ls"
  )

list(APPEND _cmake_import_check_targets gts_ls )
list(APPEND _cmake_import_check_files_for_gts_ls "${_IMPORT_PREFIX}/bin/gts_ls" )

# Import target "grib_count" for configuration "MinSizeRel"
set_property(TARGET grib_count APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(grib_count PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/grib_count"
  )

list(APPEND _cmake_import_check_targets grib_count )
list(APPEND _cmake_import_check_files_for_grib_count "${_IMPORT_PREFIX}/bin/grib_count" )

# Import target "bufr_count" for configuration "MinSizeRel"
set_property(TARGET bufr_count APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(bufr_count PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/bufr_count"
  )

list(APPEND _cmake_import_check_targets bufr_count )
list(APPEND _cmake_import_check_files_for_bufr_count "${_IMPORT_PREFIX}/bin/bufr_count" )

# Import target "gts_count" for configuration "MinSizeRel"
set_property(TARGET gts_count APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(gts_count PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/gts_count"
  )

list(APPEND _cmake_import_check_targets gts_count )
list(APPEND _cmake_import_check_files_for_gts_count "${_IMPORT_PREFIX}/bin/gts_count" )

# Import target "codes_bufr_filter" for configuration "MinSizeRel"
set_property(TARGET codes_bufr_filter APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(codes_bufr_filter PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/codes_bufr_filter"
  )

list(APPEND _cmake_import_check_targets codes_bufr_filter )
list(APPEND _cmake_import_check_files_for_codes_bufr_filter "${_IMPORT_PREFIX}/bin/codes_bufr_filter" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
