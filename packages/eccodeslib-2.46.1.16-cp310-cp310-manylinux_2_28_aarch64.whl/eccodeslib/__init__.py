__version__ = '2.46.1.16'
__commit_hash__ = '89ebf00a432c7674ee23e1d0f47ba70b8995d602'
findlibs_dependencies = ["eckitlib"]
