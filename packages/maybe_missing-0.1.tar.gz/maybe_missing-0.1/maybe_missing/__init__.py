from enum import Enum as _Enum, auto as _auto
from typing import (
    Final as _Final,
    Literal as _Literal,
    TypeAlias as _TypeAlias,
    TypeVar as _TypeVar,
)

__all__ = ["Maybe", "MISSING"]

_T = _TypeVar("_T")


class _MissingSentinel(_Enum):
    MISSING = _auto()


Maybe: _TypeAlias = _T | _Literal[_MissingSentinel.MISSING]

MISSING: _Final = _MissingSentinel.MISSING
