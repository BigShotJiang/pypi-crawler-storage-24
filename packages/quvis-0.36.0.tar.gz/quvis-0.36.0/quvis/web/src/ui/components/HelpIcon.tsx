import React, { useState } from 'react';
import { colors } from '../theme/colors.js';

const iconStyle: React.CSSProperties = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: '20px',
    height: '20px',
    borderRadius: '50%',
    backgroundColor: colors.background.hover,
    color: colors.text.secondary,
    fontSize: '14px',
    cursor: 'pointer',
    border: `1px solid ${colors.border.main}`,
    flexShrink: 0,
};

const tooltipStyle: React.CSSProperties = {
    position: 'absolute',
    bottom: 'calc(100% + 8px)',
    left: '50%',
    transform: 'translateX(-50%)',
    backgroundColor: 'rgba(0, 0, 0, 0.85)',
    color: colors.text.secondary,
    padding: '8px 12px',
    borderRadius: '4px',
    fontSize: '16px',
    fontWeight: 'normal',
    fontFamily: '"Arial", sans-serif',
    zIndex: 1000,
    pointerEvents: 'none',
    whiteSpace: 'normal',
    boxShadow: '0 2px 5px rgba(0,0,0,0.2)',
    width: '330px',
    textAlign: 'center',
};

type HelpIconProps =
    | { mode: 'tooltip'; text: string }
    | { mode: 'modal'; onClick: () => void };

const HelpIcon: React.FC<HelpIconProps> = (props) => {
    const [tooltipVisible, setTooltipVisible] = useState(false);

    if (props.mode === 'tooltip') {
        return (
            <div style={{ position: 'relative', display: 'inline-flex' }}>
                <div
                    style={iconStyle}
                    onMouseEnter={() => setTooltipVisible(true)}
                    onMouseLeave={() => setTooltipVisible(false)}
                >
                    ?
                </div>
                {tooltipVisible && (
                    <div style={tooltipStyle}>{props.text}</div>
                )}
            </div>
        );
    }

    return (
        <div style={iconStyle} onClick={props.onClick}>
            ?
        </div>
    );
};

export default HelpIcon;
