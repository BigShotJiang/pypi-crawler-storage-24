import React, { useState, useEffect } from 'react';
import { colors } from '../theme/colors.js';
import HelpIcon from './HelpIcon.js';
import { AppConstants } from '../../config/constants.js';
import { CoreConnectivity } from '../../config/defaults.js';

const version = "v0.36.0";


interface PlaygroundParameterSelectionProps {
    onGenerate: (params: PlaygroundParams) => void;
    constants: AppConstants;
}

interface PlaygroundParams {
    algorithm: string;
    numQubits: number;
    physicalQubits: number;
    topology: string;
    optimizationLevels: number[];
    customParams?: Record<string, any>;
    qasm?: string;
    heavyHexDistance?: number;
    numCores: number;
    coreConnectivity: CoreConnectivity;
}

const PlaygroundParameterSelection: React.FC<
    PlaygroundParameterSelectionProps
> = ({ onGenerate, constants }) => {
    const [algorithm, setAlgorithm] = useState<string>('qft');
    const [logicalQubits, setLogicalQubits] = useState<number>(constants.qubits.default);
    const [physicalQubits, setPhysicalQubits] = useState<number>(constants.qubits.default);
    const [topology, setTopology] = useState<string>('grid');
    const [heavyHexDistance, setHeavyHexDistance] = useState<number>(constants.heavy_hex_distance.default);
    const [gridSize, setGridSize] = useState<number>(constants.grid_size.default);
    const [optimizationLevels, setOptimizationLevels] = useState<number[]>([constants.optimization_level.default]);
    const [customParams, setCustomParams] = useState<Record<string, any>>({});
    const [numCores, setNumCores] = useState<number>(1);
    const [coreConnectivity, setCoreConnectivity] = useState<CoreConnectivity>('all-to-all');

    const [isGenerating, setIsGenerating] = useState(false);
    const [logicalQubitsInput, setLogicalQubitsInput] = useState<string>(
        logicalQubits.toString()
    );
    const [physicalQubitsInput, setPhysicalQubitsInput] = useState<string>(
        physicalQubits.toString()
    );
    const [qasmContent, setQasmContent] = useState<string | null>(null);
    const [qasmValidationStatus, setQasmValidationStatus] = useState<
        'idle' | 'loading' | 'success' | 'error'
    >('idle');
    const [qasmValidationError, setQasmValidationError] = useState<string | null>(null);
    const [isHelpOpen, setIsHelpOpen] = useState(false);

    useEffect(() => {
        if (topology === 'heavy_hex') {
            const d = heavyHexDistance;
            const calculatedPhysicalQubits = (5 * d * d - 2 * d - 1) / 2;
            if (physicalQubits !== calculatedPhysicalQubits) {
                setPhysicalQubits(calculatedPhysicalQubits);
            }
            if (logicalQubits > calculatedPhysicalQubits) {
                setLogicalQubits(calculatedPhysicalQubits);
            }
        } else if (topology === 'grid') {
            const calculatedPhysicalQubits = gridSize * gridSize;
            if (physicalQubits !== calculatedPhysicalQubits) {
                setPhysicalQubits(calculatedPhysicalQubits);
            }
            if (logicalQubits > calculatedPhysicalQubits) {
                setLogicalQubits(calculatedPhysicalQubits);
            }
        } else {
            if (physicalQubits < logicalQubits) {
                setPhysicalQubits(logicalQubits);
            }
        }
    }, [logicalQubits, physicalQubits, topology, heavyHexDistance, gridSize]);

    useEffect(() => {
        setLogicalQubitsInput(logicalQubits.toString());
    }, [logicalQubits]);

    useEffect(() => {
        setPhysicalQubitsInput(physicalQubits.toString());
    }, [physicalQubits]);

    // Snap physicalQubits to nearest multiple of numCores
    useEffect(() => {
        if (numCores <= 1) return;
        if (topology === 'heavy_hex' || topology === 'grid') return;
        const snapped = Math.round(physicalQubits / numCores) * numCores;
        if (snapped !== physicalQubits && snapped > 0) {
            setPhysicalQubits(snapped);
        }
    }, [numCores, physicalQubits, topology]);


    const containerStyle: React.CSSProperties = {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        minHeight: '100vh',
        width: '100vw',
        backgroundColor: colors.background.main,
        color: colors.text.primary,
        fontFamily: '"Arial", sans-serif',
        padding: '20px',
        boxSizing: 'border-box',
    };

    const mainTitleStyle: React.CSSProperties = {
        fontSize: '48px',
        fontWeight: 'bold',
        color: colors.primary.accent,
        textShadow: `2px 2px 4px ${colors.shadow.text}`,
        marginBottom: '8px',
        textAlign: 'center',
    };

    const versionStyle: React.CSSProperties = {
        fontSize: '14px',
        color: colors.text.disabled,
        marginBottom: '30px',
        textAlign: 'center',
    };

    const linkStyle: React.CSSProperties = {
        color: colors.primary.accent,
        textDecoration: 'none',
    };

    // All sections share the same card style for visual consistency
    const sectionStyle: React.CSSProperties = {
        marginBottom: '20px',
        width: '100%',
        maxWidth: '400px',
        padding: '20px 24px',
        backgroundColor: colors.background.panelSolid,
        borderRadius: '12px',
        border: `1px solid ${colors.border.main}`,
        boxSizing: 'border-box',
    };

    const columnsContainerStyle: React.CSSProperties = {
        display: 'flex',
        gap: '40px',
        justifyContent: 'center',
        alignItems: 'flex-start',
        width: '100%',
        maxWidth: '1100px',
        marginBottom: '40px',
    };

    const columnStyle: React.CSSProperties = {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        flex: 1,
        minWidth: '400px',
    };

    const sectionTitleStyle: React.CSSProperties = {
        fontSize: '20px',
        fontWeight: 'bold',
        color: colors.text.primary,
        marginBottom: '16px',
        marginTop: 0,
        textAlign: 'center',
    };

    const buttonGroupStyle: React.CSSProperties = {
        display: 'flex',
        justifyContent: 'center',
        gap: '12px',
        flexWrap: 'wrap',
    };

    // Topology and connectivity buttons use flex-stretch for uniform sizing
    const stretchButtonGroupStyle: React.CSSProperties = {
        display: 'flex',
        justifyContent: 'center',
        gap: '10px',
        flexWrap: 'wrap',
        width: '100%',
    };

    const circuitButtonStyle = (isActive: boolean): React.CSSProperties => ({
        padding: '12px 24px',
        fontSize: '16px',
        fontWeight: 'bold',
        border: `2px solid ${isActive ? colors.primary.accent : colors.border.main}`,
        borderRadius: '12px',
        backgroundColor: isActive
            ? colors.primary.accent
            : colors.background.main,
        color: isActive ? colors.background.main : colors.text.primary,
        cursor: 'pointer',
        transition: 'all 0.3s ease',
        minWidth: '90px',
        textAlign: 'center',
        boxShadow: isActive ? `0 4px 15px ${colors.primary.accent}40` : 'none',
    });

    const topologyButtonStyle = (isActive: boolean): React.CSSProperties => ({
        padding: '10px 16px',
        fontSize: '15px',
        fontWeight: '600',
        border: `2px solid ${isActive ? colors.primary.accent : colors.border.main}`,
        borderRadius: '8px',
        backgroundColor: isActive
            ? colors.primary.accent
            : colors.background.main,
        color: isActive ? colors.background.main : colors.text.primary,
        cursor: 'pointer',
        transition: 'all 0.3s ease',
        flex: '1 1 0',
        minWidth: '80px',
        textAlign: 'center',
        boxShadow: isActive ? `0 2px 10px ${colors.primary.accent}40` : 'none',
    });

    const sliderContainerStyle: React.CSSProperties = {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'stretch',
        gap: '12px',
    };

    const sliderLabelStyle: React.CSSProperties = {
        fontSize: '17px',
        fontWeight: '600',
        color: colors.text.primary,
        textAlign: 'left',
    };

    const sliderWrapperStyle: React.CSSProperties = {
        display: 'flex',
        alignItems: 'center',
        gap: '16px',
        width: '100%',
    };

    const sliderStyle: React.CSSProperties = {
        flex: 1,
        height: '6px',
        background: colors.border.main,
        borderRadius: '3px',
        outline: 'none',
        WebkitAppearance: 'none',
        cursor: 'pointer',
    };

    const sliderValueStyle: React.CSSProperties = {
        fontSize: '16px',
        fontWeight: 'bold',
        color: colors.primary.accent,
        width: '64px',
        flexShrink: 0,
        textAlign: 'center',
        backgroundColor: colors.background.main,
        padding: '7px 10px',
        borderRadius: '6px',
        border: `1px solid ${colors.border.main}`,
        boxSizing: 'border-box',
    };

    const helperTextStyle: React.CSSProperties = {
        fontSize: '15px',
        color: colors.text.secondary,
        textAlign: 'left',
    };

    const isButtonDisabled = isGenerating;
    const generateButtonStyle: React.CSSProperties = {
        padding: '18px 60px',
        fontSize: '22px',
        fontWeight: 'bold',
        backgroundColor: isButtonDisabled
            ? colors.background.panel
            : colors.primary.accent,
        color: isButtonDisabled ? colors.text.disabled : colors.background.main,
        border: 'none',
        borderRadius: '12px',
        cursor: isButtonDisabled ? 'not-allowed' : 'pointer',
        transition: 'all 0.3s ease',
        opacity: isButtonDisabled ? 0.6 : 1,
        boxShadow: isButtonDisabled
            ? 'none'
            : `0 4px 20px ${colors.primary.accent}40`,
    };

    const qaoacParamsStyle: React.CSSProperties = {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'stretch',
        gap: '12px',
        marginTop: '16px',
        padding: '16px',
        backgroundColor: colors.background.panel,
        borderRadius: '8px',
        border: `1px solid ${colors.border.main}`,
    };

    const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        setQasmValidationStatus('loading');
        setQasmValidationError(null);

        const reader = new FileReader();
        reader.onload = async (event) => {
            const content = event.target?.result as string;
            setQasmContent(content);

            try {
                const response = await fetch('/api/validate-qasm', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ qasm: content }),
                });

                const result = await response.json();
                if (response.ok && result.valid) {
                    setQasmValidationStatus('success');
                    setLogicalQubits(result.num_qubits);
                } else {
                    setQasmValidationStatus('error');
                    setQasmValidationError(result.error || 'Failed to validate QASM');
                    setLogicalQubits(constants.qubits.min); // Reset to minimum
                }
            } catch (err) {
                setQasmValidationStatus('error');
                setQasmValidationError('Network error while validating QASM');
            }
        };
        reader.onerror = () => {
            setQasmValidationStatus('error');
            setQasmValidationError('Failed to read file');
        };
        reader.readAsText(file);
    };

    const handleGenerate = async () => {
        if (isGenerating) return;

        setIsGenerating(true);

        const params: PlaygroundParams = {
            algorithm,
            numQubits: logicalQubits,
            physicalQubits: physicalQubits,
            topology,
            optimizationLevels,
            customParams: getCustomParams(),
            ...(algorithm === 'custom_qasm' && qasmContent ? { qasm: qasmContent } : {}),
            ...(topology === 'heavy_hex' ? { heavyHexDistance } : {}),
            numCores,
            coreConnectivity,
        };

        try {
            onGenerate(params);
        } finally {
            setIsGenerating(false);
        }
    };

    const getCustomParams = () => {
        const params: Record<string, any> = {};

        // Add algorithm-specific parameters
        if (algorithm === 'qaoa') {
            params.reps = customParams.reps || constants.qaoa_reps.default;
        }

        return params;
    };

    const handleCustomParamChange = (key: string, value: any) => {
        setCustomParams((prev) => ({
            ...prev,
            [key]: value,
        }));
    };

    const handleLogicalQubitsInputChange = (
        e: React.ChangeEvent<HTMLInputElement>
    ) => {
        setLogicalQubitsInput(e.target.value);
    };

    const handleLogicalQubitsInputBlur = () => {
        let value = parseInt(logicalQubitsInput, 10);
        if (isNaN(value)) {
            value = constants.qubits.min;
        }
        setLogicalQubits(Math.max(constants.qubits.min, Math.min(value, constants.qubits.max)));
    };

    const handlePhysicalQubitsInputChange = (
        e: React.ChangeEvent<HTMLInputElement>
    ) => {
        setPhysicalQubitsInput(e.target.value);
    };

    const handlePhysicalQubitsInputBlur = () => {
        let value = parseInt(physicalQubitsInput, 10);
        if (isNaN(value)) {
            value = logicalQubits;
        }
        setPhysicalQubits(Math.max(logicalQubits, Math.min(value, constants.qubits.max)));
    };

    const renderQAOAParams = () => {
        if (algorithm === 'qaoa') {
            return (
                <div style={qaoacParamsStyle}>
                    <div style={sliderLabelStyle}>QAOA Layers (p-value)</div>
                    <div style={sliderWrapperStyle}>
                        <input
                            type="range"
                            min={constants.qaoa_reps.min}
                            max={constants.qaoa_reps.max}
                            value={customParams.reps || constants.qaoa_reps.default}
                            onChange={(e) =>
                                handleCustomParamChange(
                                    'reps',
                                    parseInt(e.target.value)
                                )
                            }
                            style={sliderStyle}
                        />
                        <input
                            type="number"
                            min={constants.qaoa_reps.min}
                            max={constants.qaoa_reps.max}
                            value={customParams.reps || constants.qaoa_reps.default}
                            onChange={(e) =>
                                handleCustomParamChange(
                                    'reps',
                                    parseInt(e.target.value)
                                )
                            }
                            style={sliderValueStyle}
                        />
                    </div>
                </div>
            );
        }

        if (algorithm === 'custom_qasm') {
            return (
                <div style={qaoacParamsStyle}>
                    <div style={{ ...sliderLabelStyle, display: 'flex', alignItems: 'center', gap: '8px' }}>
                        Upload QASM File
                        <HelpIcon mode="modal" onClick={() => setIsHelpOpen(true)} />
                    </div>
                    <input
                        type="file"
                        accept=".qasm,.txt"
                        onChange={handleFileUpload}
                        style={{
                            padding: '10px',
                            backgroundColor: colors.background.main,
                            color: colors.text.primary,
                            borderRadius: '8px',
                            border: `1px solid ${colors.border.main}`,
                            width: '100%',
                            boxSizing: 'border-box'
                        }}
                    />

                    {qasmValidationStatus === 'loading' && (
                        <div style={{ color: colors.text.secondary, marginTop: '8px' }}>
                            Validating QASM...
                        </div>
                    )}

                    {qasmValidationStatus === 'success' && (
                        <div style={{ color: colors.state.success, marginTop: '8px', textAlign: 'center' }}>
                            ✓ Valid QASM<br />
                            <span style={{ fontSize: '14px', color: colors.text.secondary }}>
                                Parsed {logicalQubits} logical qubits
                            </span>
                        </div>
                    )}

                    {qasmValidationStatus === 'error' && (
                        <div style={{ color: colors.state.error, marginTop: '8px', fontSize: '14px', wordBreak: 'break-word', textAlign: 'center' }}>
                            ✗ Validation Failed<br />
                            {qasmValidationError}
                        </div>
                    )}
                </div>
            );
        }

        return null;
    };

    const renderHelpModal = () => {
        if (!isHelpOpen) return null;

        return (
            <div style={{
                position: 'fixed',
                top: 0,
                left: 0,
                width: '100vw',
                height: '100vh',
                backgroundColor: 'rgba(0, 0, 0, 0.7)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                zIndex: 1000,
            }}>
                <div style={{
                    backgroundColor: colors.background.panelSolid,
                    border: `1px solid ${colors.border.active}`,
                    borderRadius: '12px',
                    padding: '30px',
                    maxWidth: '600px',
                    width: '90%',
                    boxShadow: `0 10px 30px ${colors.shadow.dark}`,
                    position: 'relative',
                }}>
                    <button
                        onClick={() => setIsHelpOpen(false)}
                        style={{
                            position: 'absolute',
                            top: '15px',
                            right: '20px',
                            background: 'none',
                            border: 'none',
                            color: colors.text.muted,
                            fontSize: '24px',
                            cursor: 'pointer',
                        }}
                    >
                        ×
                    </button>
                    <h2 style={{ ...sectionTitleStyle, textAlign: 'left', color: colors.primary.accent }}>
                        Generating QASM from Qiskit
                    </h2>
                    <p style={{ color: colors.text.secondary, marginBottom: '20px', lineHeight: '1.5' }}>
                        You can easily export any `QuantumCircuit` to OpenQASM 2.0 format using the `qiskit.qasm2` module.
                    </p>
                    <div style={{
                        backgroundColor: colors.background.main,
                        padding: '15px',
                        borderRadius: '8px',
                        border: `1px solid ${colors.border.main}`,
                        overflowX: 'auto',
                    }}>
                        <pre style={{ margin: 0, color: colors.text.primary, fontSize: '14px', fontFamily: 'monospace', lineHeight: '1.4' }}>
                            <span style={{ color: '#c678dd' }}>from</span> qiskit <span style={{ color: '#c678dd' }}>import</span> QuantumCircuit<br />
                            <span style={{ color: '#c678dd' }}>from</span> qiskit <span style={{ color: '#c678dd' }}>import</span> qasm2<br />
                            <br />
                            <span style={{ color: '#5c6370', fontStyle: 'italic' }}># Create your circuit</span><br />
                            qc = QuantumCircuit(<span style={{ color: '#d19a66' }}>2</span>)<br />
                            qc.h(<span style={{ color: '#d19a66' }}>0</span>)<br />
                            qc.cx(<span style={{ color: '#d19a66' }}>0</span>, <span style={{ color: '#d19a66' }}>1</span>)<br />
                            <br />
                            <span style={{ color: '#5c6370', fontStyle: 'italic' }}># Export to OpenQASM 2.0 string</span><br />
                            qasm_str = qasm2.dumps(qc)<br />
                            <br />
                            <span style={{ color: '#5c6370', fontStyle: 'italic' }}># Or save directly to a file</span><br />
                            qasm2.dump(qc, <span style={{ color: '#98c379' }}>"my_circuit.qasm"</span>)
                        </pre>
                    </div>
                </div>
            </div>
        );
    };

    const qubitsPerCoreLabel = () => {
        if (topology === 'grid') {
            return `${Math.ceil(Math.sqrt(physicalQubits / numCores)) ** 2} qubits per core`;
        } else if (topology === 'heavy_hex') {
            const target = physicalQubits / numCores;
            const hhQ = (d: number) => (5 * d * d - 2 * d - 1) / 2;
            let d = 3;
            while (hhQ(d) < target && d < 100) d += 2;
            return `${hhQ(d)} qubits per core (d=${d})`;
        }
        return `${Math.floor(physicalQubits / numCores)} qubits per core`;
    };

    return (
        <div style={containerStyle}>
            <style>
                {`
                    /* Hide number input spinners */
                    input[type="number"]::-webkit-outer-spin-button,
                    input[type="number"]::-webkit-inner-spin-button {
                        -webkit-appearance: none;
                        margin: 0;
                    }

                    input[type="number"] {
                        -moz-appearance: textfield;
                    }
                `}
            </style>
            <h1 style={mainTitleStyle}>Quvis</h1>
            <p style={versionStyle}>
                Version {version} &nbsp;·&nbsp; Made by{' '}
                <a
                    href="https://github.com/alejandrogonzalvo/"
                    target="_blank"
                    rel="noopener noreferrer"
                    style={linkStyle}
                >
                    @alejandrogonzalvo
                </a> — Source code on request.
            </p>

            <div style={columnsContainerStyle}>
                {/* Left Column: Circuit + Logical Qubits + Multicore */}
                <div style={columnStyle}>
                    {/* Circuit Selection */}
                    <div style={sectionStyle}>
                        <h2 style={sectionTitleStyle}>Circuit</h2>
                        <div style={buttonGroupStyle}>
                            <button
                                style={circuitButtonStyle(algorithm === 'ghz')}
                                onClick={() => setAlgorithm('ghz')}
                            >
                                GHZ
                            </button>
                            <button
                                style={circuitButtonStyle(algorithm === 'qft')}
                                onClick={() => setAlgorithm('qft')}
                            >
                                QFT
                            </button>
                            <button
                                style={circuitButtonStyle(algorithm === 'qaoa')}
                                onClick={() => setAlgorithm('qaoa')}
                            >
                                QAOA
                            </button>
                            <button
                                style={circuitButtonStyle(algorithm === 'custom_qasm')}
                                onClick={() => setAlgorithm('custom_qasm')}
                            >
                                Custom QASM
                            </button>
                        </div>
                        {renderQAOAParams()}
                    </div>

                    {/* Logical Qubits Slider */}
                    {algorithm !== 'custom_qasm' && (
                        <div style={sectionStyle}>
                            <div style={sliderContainerStyle}>
                                <div style={sliderLabelStyle}>Logical Qubits</div>
                                <div style={sliderWrapperStyle}>
                                    <input
                                        type="range"
                                        min={constants.qubits.min}
                                        max={topology === 'heavy_hex' ? physicalQubits : constants.qubits.max}
                                        value={logicalQubits}
                                        onChange={(e) =>
                                            setLogicalQubits(
                                                parseInt(e.target.value)
                                            )
                                        }
                                        style={sliderStyle}
                                    />
                                    <input
                                        type="number"
                                        min={constants.qubits.min}
                                        max={topology === 'heavy_hex' ? physicalQubits : constants.qubits.max}
                                        value={logicalQubitsInput}
                                        onChange={handleLogicalQubitsInputChange}
                                        onBlur={handleLogicalQubitsInputBlur}
                                        style={sliderValueStyle}
                                    />
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Multicore: Number of Cores + Core Connectivity */}
                    <div style={sectionStyle}>
                        <h2 style={sectionTitleStyle}>Multicore</h2>
                        <div style={sliderContainerStyle}>
                            <div style={sliderLabelStyle}>Number of Cores</div>
                            <div style={sliderWrapperStyle}>
                                <input
                                    type="range"
                                    min={1}
                                    max={5}
                                    step={1}
                                    value={numCores}
                                    onChange={(e) => setNumCores(parseInt(e.target.value))}
                                    style={sliderStyle}
                                />
                                <div style={sliderValueStyle}>{numCores}</div>
                            </div>
                            {numCores > 1 && (
                                <div style={helperTextStyle}>{qubitsPerCoreLabel()}</div>
                            )}
                        </div>

                        {numCores > 1 && (
                            <div style={{ ...sliderContainerStyle, marginTop: '20px' }}>
                                <div style={sliderLabelStyle}>Core Connectivity</div>
                                <div style={stretchButtonGroupStyle}>
                                    <button
                                        style={topologyButtonStyle(coreConnectivity === 'all-to-all')}
                                        onClick={() => setCoreConnectivity('all-to-all')}
                                    >
                                        All-to-All
                                    </button>
                                    <button
                                        style={topologyButtonStyle(coreConnectivity === 'grid')}
                                        onClick={() => setCoreConnectivity('grid')}
                                    >
                                        Grid
                                    </button>
                                    <button
                                        style={topologyButtonStyle(coreConnectivity === 'line')}
                                        onClick={() => setCoreConnectivity('line')}
                                    >
                                        Line
                                    </button>
                                    <button
                                        style={topologyButtonStyle(coreConnectivity === 'ring')}
                                        onClick={() => setCoreConnectivity('ring')}
                                    >
                                        Ring
                                    </button>
                                </div>
                            </div>
                        )}
                    </div>
                </div>

                {/* Right Column: Topology + Physical Qubits + Optimization */}
                <div style={columnStyle}>
                    {/* Topology Selection */}
                    <div style={sectionStyle}>
                        <h2 style={sectionTitleStyle}>Topology</h2>
                        <div style={stretchButtonGroupStyle}>
                            <button
                                style={topologyButtonStyle(topology === 'line')}
                                onClick={() => setTopology('line')}
                            >
                                Line
                            </button>
                            <button
                                style={topologyButtonStyle(topology === 'ring')}
                                onClick={() => setTopology('ring')}
                            >
                                Ring
                            </button>
                            <button
                                style={topologyButtonStyle(topology === 'grid')}
                                onClick={() => setTopology('grid')}
                            >
                                Grid
                            </button>
                            <button
                                style={topologyButtonStyle(topology === 'heavy_hex')}
                                onClick={() => setTopology('heavy_hex')}
                            >
                                Heavy Hex
                            </button>
                            <button
                                style={topologyButtonStyle(topology === 'full')}
                                onClick={() => setTopology('full')}
                            >
                                Full
                            </button>
                        </div>
                    </div>

                    {/* Physical Qubits / Size Parameter */}
                    {topology === 'heavy_hex' ? (
                        <div style={sectionStyle}>
                            <div style={sliderContainerStyle}>
                                <div style={sliderLabelStyle}>Heavy Hex Distance (d)</div>
                                <div style={sliderWrapperStyle}>
                                    <input
                                        type="range"
                                        min={constants.heavy_hex_distance.min}
                                        max={constants.heavy_hex_distance.max}
                                        step={constants.heavy_hex_distance.step}
                                        value={heavyHexDistance}
                                        onChange={(e) =>
                                            setHeavyHexDistance(
                                                parseInt(e.target.value)
                                            )
                                        }
                                        style={sliderStyle}
                                    />
                                    <div style={sliderValueStyle}>
                                        {heavyHexDistance}
                                    </div>
                                </div>
                                <div style={helperTextStyle}>
                                    Calculated Physical Qubits: {physicalQubits}
                                </div>
                            </div>
                        </div>
                    ) : topology === 'grid' ? (
                        <div style={sectionStyle}>
                            <div style={sliderContainerStyle}>
                                <div style={sliderLabelStyle}>Grid Row Size (n)</div>
                                <div style={sliderWrapperStyle}>
                                    <input
                                        type="range"
                                        min={constants.grid_size.min}
                                        max={constants.grid_size.max}
                                        step="1"
                                        value={gridSize}
                                        onChange={(e) =>
                                            setGridSize(parseInt(e.target.value))
                                        }
                                        style={sliderStyle}
                                    />
                                    <div style={sliderValueStyle}>
                                        {gridSize}
                                    </div>
                                </div>
                                <div style={helperTextStyle}>
                                    Calculated Physical Qubits: {gridSize * gridSize}
                                </div>
                            </div>
                        </div>
                    ) : (
                        <div style={sectionStyle}>
                            <div style={sliderContainerStyle}>
                                <div style={sliderLabelStyle}>Physical Qubits</div>
                                <div style={sliderWrapperStyle}>
                                    <input
                                        type="range"
                                        min={logicalQubits}
                                        max={constants.qubits.max}
                                        value={physicalQubits}
                                        onChange={(e) =>
                                            setPhysicalQubits(
                                                parseInt(e.target.value)
                                            )
                                        }
                                        style={sliderStyle}
                                    />
                                    <input
                                        type="number"
                                        min={logicalQubits}
                                        max={constants.qubits.max}
                                        value={physicalQubitsInput}
                                        onChange={handlePhysicalQubitsInputChange}
                                        onBlur={handlePhysicalQubitsInputBlur}
                                        style={sliderValueStyle}
                                    />
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Compiler: Optimization Level */}
                    <div style={sectionStyle}>
                        <h2 style={sectionTitleStyle}>Compiler</h2>
                        <div style={sliderContainerStyle}>
                            <div style={{ ...sliderLabelStyle, display: 'flex', alignItems: 'center', gap: '8px' }}>
                                Optimization Level
                                <HelpIcon
                                    mode="tooltip"
                                    text="The optimization level of the Qiskit transpiler. Higher levels produce more efficient circuits but take longer to compile."
                                />
                            </div>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                                {[
                                    { value: 0, label: 'Level 0 — No optimization' },
                                    { value: 1, label: 'Level 1 — Light optimization' },
                                    { value: 2, label: 'Level 2 — Heavy optimization' },
                                    { value: 3, label: 'Level 3 — Max optimization' },
                                ].map(({ value, label }) => {
                                    const isChecked = optimizationLevels.includes(value);
                                    return (
                                        <label
                                            key={value}
                                            style={{
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: '12px',
                                                cursor: 'pointer',
                                                fontSize: '15px',
                                                fontWeight: '600',
                                                color: colors.text.primary,
                                                padding: '10px 14px',
                                                borderRadius: '8px',
                                                border: `2px solid ${isChecked ? colors.primary.accent : colors.border.main}`,
                                                backgroundColor: isChecked
                                                    ? `${colors.primary.accent}15`
                                                    : colors.background.main,
                                                transition: 'all 0.3s ease',
                                            }}
                                        >
                                            <div
                                                style={{
                                                    width: '20px',
                                                    height: '20px',
                                                    borderRadius: '4px',
                                                    border: `2px solid ${isChecked ? colors.primary.accent : colors.border.main}`,
                                                    backgroundColor: isChecked ? colors.primary.accent : 'transparent',
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    justifyContent: 'center',
                                                    flexShrink: 0,
                                                    transition: 'all 0.3s ease',
                                                }}
                                            >
                                                {isChecked && (
                                                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                                                        <path
                                                            d="M2 6L5 9L10 3"
                                                            stroke={colors.background.main}
                                                            strokeWidth="2"
                                                            strokeLinecap="round"
                                                            strokeLinejoin="round"
                                                        />
                                                    </svg>
                                                )}
                                            </div>
                                            <input
                                                type="checkbox"
                                                checked={isChecked}
                                                onChange={() => {
                                                    setOptimizationLevels((prev) => {
                                                        if (prev.includes(value)) {
                                                            if (prev.length === 1) return prev;
                                                            return prev.filter((v) => v !== value);
                                                        }
                                                        return [...prev, value].sort();
                                                    });
                                                }}
                                                style={{ display: 'none' }}
                                            />
                                            {label}
                                        </label>
                                    );
                                })}
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <button
                onClick={handleGenerate}
                style={generateButtonStyle}
                disabled={isGenerating || (algorithm === 'custom_qasm' && qasmValidationStatus !== 'success')}
            >
                {isGenerating ? 'Generating...' : 'Visualize'}
            </button>
            {renderHelpModal()}
        </div>
    );
};

export default PlaygroundParameterSelection;
export type { PlaygroundParams };
