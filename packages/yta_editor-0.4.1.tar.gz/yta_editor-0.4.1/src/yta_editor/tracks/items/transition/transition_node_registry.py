"""
TODO: I think this has to be moved from here
"""
from typing import Union


class TransitionNodeRegistry:
    """
    The registry containing the nodes we accept and
    make available in the platform.
    """

    _registry: dict = {}
    """
    *For internal use only*

    The registry itself, containing the names as keys
    and the specific `_TransitionProcessor` instances
    as values.
    """

    @classmethod
    def register(
        cls,
        name: str,
        node_processor_class: '_TransitionProcessor',
        opengl_context: Union['Context', None] = None
    ) -> None:
        """
        Register the `node_processor_class` with the given
        `name`.
        """
        cls._registry[name] = node_processor_class(
            opengl_context = opengl_context
        )

    @classmethod
    def get(
        cls,
        name: str
    ) -> '_TransitionProcessor':
        """
        Get the `node_processor_class` with the given `name`.
        """
        return cls._registry[name]

    @classmethod
    def all(
        cls
    ) -> dict[str, '_TransitionProcessor']:
        """
        Get the registry as a dict.
        """
        return dict(cls._registry)
    
    @classmethod
    def is_registered(
        cls,
        name: str
    ) -> bool:
        """
        Check if the registry with the given `name` is
        registered or not.
        """
        return cls._registry.get(name, None) is not None
    
    @classmethod
    def get_default(
        cls
    ) -> Union['_TransitionProcessor', None]:
        """
        Get the default registry, that is the first one
        if the registry contains some, or `None` if there
        are no items registered.
        """
        first_key = TransitionNodeRegistry.get_default_key()

        return (
            cls._registry[first_key]
            if first_key is not None else
            None
        )
    
    @classmethod
    def get_default_key(
        cls
    ) -> Union[str, None]:
        """
        Get the default key of the registry, that is the
        first one if the registry contains some, or `None`
        if there are no items registered.
        """
        return next(iter(cls._registry), None)

# TODO: This must be moved to an initializer, not here
def register_transition_processor_nodes():
    """
    Method to be called by the app to register the
    specific transition node processors we want to
    be implemented and available.

    These are the transitions that we have currently
    available:
    - `circle_opening`
    - `circle_closing`
    - `crossfade`
    - `distorted_crossfade`
    - `slide`
    - `bars_falling`
    - `alphapedia_mask`
    """
    from yta_editor.tracks.items.transition.transition_node_registry import TransitionNodeRegistry
    from yta_editor_nodes.processor.video.transitions import CircleOpeningTransitionProcessor, CircleClosingTransitionProcessor, CrossfadeTransitionProcessor, DistortedCrossfadeTransitionProcessor, SlideTransitionProcessor, BarsFallingTransitionProcessor, AlphaPediaMaskTransitionProcessor

    # Modify it to make more nodes available
    # TODO: This could be a json or something like this
    # and maybe according to the version of the software
    nodes = {
        'circle_opening': CircleOpeningTransitionProcessor,
        'circle_closing': CircleClosingTransitionProcessor,
        'crossfade': CrossfadeTransitionProcessor,
        'distorted_crossfade': DistortedCrossfadeTransitionProcessor,
        'slide': SlideTransitionProcessor,
        'bars_falling': BarsFallingTransitionProcessor,
        'alphapedia_mask': AlphaPediaMaskTransitionProcessor
    }

    for name, node_class in nodes.items():
        TransitionNodeRegistry.register(
            name,
            node_class,
            # TODO: What about the 'opengl_context' (?)
        )