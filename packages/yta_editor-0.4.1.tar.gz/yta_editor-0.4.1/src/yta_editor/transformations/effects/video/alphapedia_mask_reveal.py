from yta_editor.transformations.effects.video import VideoEffectSingleNodeBaseInputAndMaskInput
from yta_editor_nodes.processor.video.alphapedia_mask_reveal import AlphaPediaMaskRevealVideoNodeProcessor


class AlphaPediaMaskRevealVideoEffect(VideoEffectSingleNodeBaseInputAndMaskInput):
    """
    The effect that will modify the video by
    revealing it with an alpha video mask according
    to the provided conditions.
    """

    def __init__(
        self,
        mask_input_filename: str,
        do_use_gpu: bool = True
    ):
        super().__init__(
            node_processor = AlphaPediaMaskRevealVideoNodeProcessor,
            mask_input_filename = mask_input_filename,
            parameters = {},
            do_use_gpu = do_use_gpu
        )