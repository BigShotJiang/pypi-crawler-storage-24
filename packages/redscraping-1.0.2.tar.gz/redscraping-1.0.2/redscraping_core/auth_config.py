# autoscraper/auth_config.py

# Paste the contents of your credentials.json inside this dictionary!
CLIENT_CONFIG = {
    "installed": {
        "client_id": "861412162331-9j22akmd5vcgjtsho316d06kqob6mcku.apps.googleusercontent.com",
        "project_id": "vocal-mapper-387607",
        "auth_uri": "https://accounts.google.com/o/oauth2/auth",
        "token_uri": "https://oauth2.googleapis.com/token",
        "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
        "client_secret": "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",
        "redirect_uris": [
            "http://localhost"
        ]
    }
}