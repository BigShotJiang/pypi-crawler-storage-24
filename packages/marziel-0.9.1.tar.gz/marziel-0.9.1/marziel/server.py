import os
import json
import time
import logging
import threading
import subprocess
import platform as _platform
from pathlib import Path
from flask import Flask, request, jsonify, send_from_directory

from marziel.config import LLM_PORT, IDLE_TIMEOUT, VLLM_URL, VLLM_MODEL, AGENT_TIERS
from marziel.billing import billing_bp, read_license
from marziel.search import needs_web_search, search_duckduckgo, format_search_context
try:
    from marziel import __version__ as _MARZIEL_VERSION
except Exception:
    _MARZIEL_VERSION = "0.9.0"

logger = logging.getLogger("marziel.server")

# ── Static files directory (bundled React build) ──
STATIC_DIR = Path(__file__).parent / "static"

# ── Idle engine management ──
_last_request_time = time.time()
_watchdog_started = False

# ── Rate limiting (per-IP, in-memory) ──
from collections import defaultdict
_rate_buckets: dict[str, list[float]] = defaultdict(list)
_rate_lock = threading.Lock()
RATE_LIMIT = 20       # max requests per window
RATE_WINDOW = 60      # window in seconds

_RATE_LIMITED_PATHS = {"/llm/chat", "/api/checkout", "/api/webhook"}


def _is_rate_limited(ip: str, path: str) -> bool:
    """Check if IP exceeded rate limit for sensitive endpoints."""
    if path not in _RATE_LIMITED_PATHS:
        return False
    now = time.time()
    with _rate_lock:
        bucket = _rate_buckets[ip]
        # Purge old entries outside window
        _rate_buckets[ip] = [t for t in bucket if now - t < RATE_WINDOW]
        if len(_rate_buckets[ip]) >= RATE_LIMIT:
            return True
        _rate_buckets[ip].append(now)
    return False


def _get_resource_info():
    """Get current system resource usage."""
    info = {}
    try:
        import resource
        # Memory usage of this process (MB)
        info["server_rss_mb"] = round(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024 / 1024, 1)
    except Exception:
        pass

    # System RAM
    try:
        if _platform.system() == "Darwin":
            result = subprocess.run(
                ["sysctl", "-n", "hw.memsize"],
                capture_output=True, text=True, timeout=3
            )
            total_bytes = int(result.stdout.strip())
            info["system_ram_gb"] = round(total_bytes / 1024**3, 1)

            # Get available memory via vm_stat
            result = subprocess.run(["vm_stat"], capture_output=True, text=True, timeout=3)
            for line in result.stdout.split("\n"):
                if "Pages free" in line:
                    pages = int(line.split(":")[1].strip().rstrip("."))
                    info["available_ram_gb"] = round(pages * 4096 / 1024**3, 1)
                    break
        else:
            with open("/proc/meminfo") as f:
                for line in f:
                    if line.startswith("MemTotal"):
                        info["system_ram_gb"] = round(int(line.split()[1]) / 1024**2, 1)
                    elif line.startswith("MemAvailable"):
                        info["available_ram_gb"] = round(int(line.split()[1]) / 1024**2, 1)
    except Exception:
        pass

    # Engine process RAM
    try:
        result = subprocess.run(
            f"lsof -ti:{LLM_PORT} | head -1",
            shell=True, capture_output=True, text=True, timeout=3
        )
        pid = result.stdout.strip()
        if pid:
            result = subprocess.run(
                ["ps", "-o", "rss=", "-p", pid],
                capture_output=True, text=True, timeout=3
            )
            rss_kb = int(result.stdout.strip())
            info["engine_ram_mb"] = round(rss_kb / 1024, 0)
            info["engine_pid"] = int(pid)
    except Exception:
        pass

    info["idle_timeout_sec"] = IDLE_TIMEOUT
    info["idle_sec"] = round(time.time() - _last_request_time)
    return info


def _engine_running():
    """Check if MLX engine is running."""
    try:
        import urllib.request
        req = urllib.request.Request(f"http://localhost:{LLM_PORT}/v1/models")
        resp = urllib.request.urlopen(req, timeout=2)
        return resp.status == 200
    except Exception:
        return False


def _stop_engine():
    """Stop the MLX engine to free RAM."""
    try:
        subprocess.run(
            f"lsof -ti:{LLM_PORT} | xargs kill 2>/dev/null || true",
            shell=True, capture_output=True, timeout=5
        )
        logger.info(f"🛑 Engine stopped (idle > {IDLE_TIMEOUT}s) — RAM freed")
    except Exception:
        pass


def _start_idle_watchdog():
    """Background thread that stops engine after idle timeout."""
    global _watchdog_started
    if _watchdog_started or IDLE_TIMEOUT <= 0:
        return
    _watchdog_started = True

    def watchdog():
        while True:
            time.sleep(60)  # check every minute
            idle = time.time() - _last_request_time
            if idle > IDLE_TIMEOUT and _engine_running():
                logger.info(f"⏸️  No requests for {int(idle)}s — shutting down engine to save resources")
                _stop_engine()

    t = threading.Thread(target=watchdog, daemon=True, name="marziel-idle-watchdog")
    t.start()
    logger.info(f"♻️  Idle watchdog active (timeout: {IDLE_TIMEOUT}s)")


def _ensure_engine():
    """Restart engine if it was stopped by idle watchdog."""
    if _engine_running():
        return True
    try:
        from marziel.cli import _model_exists, _start_mlx_engine, _find_mlx_python
        if _model_exists():
            logger.info("🔄 Restarting engine for incoming request...")
            _start_mlx_engine()
            return True
    except Exception as e:
        logger.warning(f"Engine restart failed: {e}")
    return False


def create_app():
    """Create the Flask application."""
    app = Flask(__name__, static_folder=str(STATIC_DIR), static_url_path="")

    # Start idle watchdog
    _start_idle_watchdog()

    # ── Register embedded LLM inference (if llama_cpp available) ──
    try:
        from marziel.llm_embedded import register_routes, load_model
        register_routes(app)
        # Load model in background thread to not block startup
        import threading
        threading.Thread(target=load_model, daemon=True).start()
    except ImportError:
        pass

    # ── CORS ──
    @app.after_request
    def add_cors(response):
        response.headers["Access-Control-Allow-Origin"] = "*"
        response.headers["Access-Control-Allow-Headers"] = "Content-Type, Access-Control-Request-Private-Network"
        response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
        response.headers["Access-Control-Allow-Private-Network"] = "true"
        return response

    # ── Rate limiting ──
    @app.before_request
    def check_rate_limit():
        ip = request.remote_addr or "unknown"
        if _is_rate_limited(ip, request.path):
            logger.warning(f"🚫 Rate limit exceeded: {ip} on {request.path}")
            return jsonify({"error": "Too many requests. Please try again later."}), 429

    # ── Serve React UI ──
    @app.route("/")
    def serve_ui():
        index = STATIC_DIR / "index.html"
        if index.exists():
            return send_from_directory(str(STATIC_DIR), "index.html")
        return jsonify({
            "name": "Marziel AI",
            "status": "running",
            "message": "UI not bundled. Run 'npm run build' and copy dist/ to marziel/static/",
            "api": "/llm/chat",
        })

    @app.route("/<path:path>")
    def serve_static(path):
        """Serve static files, fallback to index.html for SPA routing."""
        file_path = STATIC_DIR / path
        if file_path.exists() and file_path.is_file():
            return send_from_directory(str(STATIC_DIR), path)
        # SPA fallback
        index = STATIC_DIR / "index.html"
        if index.exists():
            return send_from_directory(str(STATIC_DIR), "index.html")
        return jsonify({"error": "Not found"}), 404

    # ── Health ──
    @app.route("/health")
    def health():
        return jsonify({"status": "ok", "version": _MARZIEL_VERSION})

    # ── Model Info (real-time introspection) ──
    @app.route("/api/model/info")
    def model_info():
        """Return real-time model info from the LLM backend."""
        import urllib.request
        llm_url = os.environ.get("VLLM_URL", f"http://localhost:{LLM_PORT}")
        info = {
            "model": "Unknown",
            "engine": "Unknown",
            "quantization": "Unknown",
            "version": f"Marziel AI v{_MARZIEL_VERSION}",
            "api_url": llm_url,
            "status": "offline",
            "platform": _platform.system(),
            "arch": _platform.machine(),
        }
        try:
            req = urllib.request.Request(f"{llm_url}/v1/models")
            resp = urllib.request.urlopen(req, timeout=3)
            data = json.loads(resp.read().decode())
            models = data.get("data", [])
            if models:
                # Pick best model ID: prefer v6, mlx, 4bit, or longest path
                def _model_score(m):
                    mid = m.get("id", "")
                    score = len(mid) // 10  # longer = more specific
                    if "v6" in mid: score += 10
                    if "mlx" in mid.lower(): score += 8
                    if "4bit" in mid.lower(): score += 5
                    return score
                best = sorted(models, key=_model_score, reverse=True)[0]
                model_id = best.get("id", "Unknown")
                # Use short display name for long paths
                display_name = model_id.split("/")[-1] if "/" in model_id else model_id
                info["model"] = display_name
                info["status"] = "online"
                
                # Use exported engine env var or fallback
                active_engine = os.environ.get("MARZIEL_ACTIVE_ENGINE", "")
                if active_engine == "vllm":
                    info["engine"] = "vLLM (GPU)"
                elif active_engine == "llama_cpp":
                    info["engine"] = "llama.cpp (CPU/GPU)"
                elif active_engine == "mlx":
                    info["engine"] = "MLX (Apple Silicon)"
                else:
                    info["engine"] = "MLX (Apple Silicon)" if _platform.system() == "Darwin" else "llama.cpp / vLLM"
                
                # Extract quantization hint
                for q in ["Q4_K_M", "Q4_K_S", "Q8_0", "Q5_K_M", "Q6_K", "F16", "4bit"]:
                    if q.lower() in model_id.lower():
                        info["quantization"] = q
                        break

            # Confirm online via /health
            try:
                hreq = urllib.request.Request(f"{llm_url}/health")
                hresp = urllib.request.urlopen(hreq, timeout=2)
                hdata = json.loads(hresp.read().decode())
                if hdata.get("status") == "ok":
                    info["status"] = "online"
            except Exception:
                pass
        except Exception as e:
            logger.debug(f"Model info fetch failed: {e}")
            if _engine_running():
                info["status"] = "online"
                active_engine = os.environ.get("MARZIEL_ACTIVE_ENGINE", "")
                if active_engine == "vllm":
                    info["engine"] = "vLLM (GPU)"
                elif active_engine == "llama_cpp":
                    info["engine"] = "llama.cpp (CPU/GPU)"
                else:
                    info["engine"] = "MLX (Apple Silicon)" if _platform.system() == "Darwin" else "Starting Engine..."
        return jsonify(info)

    # ── System Status ──
    @app.route("/system/status")
    def system_status():
        resources = _get_resource_info()
        return jsonify({
            "status": "running",
            "version": _MARZIEL_VERSION,
            "platform": _platform.system(),
            "arch": _platform.machine(),
            "python": _platform.python_version(),
            "engine_running": _engine_running(),
            "resources": resources,
        })

    # ── License Status ──
    @app.route("/license/status")
    def license_status():
        from marziel.license import get_status
        return jsonify(get_status())

    # ── Maritime Intelligence API (Enterprise) ──
    @app.route("/api/maritime/report", methods=["GET"])
    def maritime_report():
        """Generate a live maritime intelligence report (Enterprise only)."""
        from marziel.billing import read_license
        lic = read_license()
        if lic.get("tier") != "enterprise":
            return jsonify({"error": "Enterprise plan required"}), 403
        from marziel.maritime_services import generate_maritime_report
        report = generate_maritime_report(include_platform=True)
        return jsonify({"report": report, "format": "text"})

    @app.route("/api/maritime/data/<source>", methods=["GET"])
    def maritime_data(source):
        """Fetch specific maritime data (Enterprise only)."""
        from marziel.billing import read_license
        lic = read_license()
        if lic.get("tier") != "enterprise":
            return jsonify({"error": "Enterprise plan required"}), 403

        if source == "market":
            from marziel.maritime_intel import fetch_market_data
            return jsonify(fetch_market_data())
        elif source == "gdacs":
            from marziel.maritime_intel import fetch_gdacs_events
            return jsonify(fetch_gdacs_events())
        elif source == "gdelt":
            from marziel.maritime_intel import fetch_gdelt_news
            return jsonify(fetch_gdelt_news())
        elif source == "nasa":
            from marziel.maritime_intel import fetch_nasa_events
            return jsonify(fetch_nasa_events())
        elif source == "ais":
            from marziel.maritime_intel import fetch_ais_vessels
            return jsonify(fetch_ais_vessels())
        elif source == "vessels":
            from marziel.maritime_services import get_fleet_vessels
            return jsonify(get_fleet_vessels())
        elif source == "voyages":
            from marziel.maritime_services import get_voyages
            return jsonify(get_voyages())
        elif source == "risk-zones":
            from marziel.maritime_services import get_risk_zones
            return jsonify(get_risk_zones())
        elif source == "ports":
            from marziel.maritime_services import get_ports
            return jsonify(get_ports())
        elif source == "fx":
            from marziel.maritime_services import fetch_exchangerate_data
            return jsonify(fetch_exchangerate_data())
        elif source == "bunker":
            from marziel.maritime_intel import fetch_market_data
            md = fetch_market_data()
            brent = md.get("data", {}).get("brent_crude", {}).get("price", 0)
            from marziel.maritime_services import fetch_shipandbunker_estimate
            return jsonify(fetch_shipandbunker_estimate(brent))
        else:
            return jsonify({"error": f"Unknown source: {source}"}), 404

    @app.route("/api/maritime/connectors", methods=["GET"])
    def maritime_connectors():
        """List available and active third-party connectors (Enterprise)."""
        from marziel.billing import read_license
        lic = read_license()
        if lic.get("tier") != "enterprise":
            return jsonify({"error": "Enterprise plan required"}), 403
        from marziel.connectors import get_connector_manager
        mgr = get_connector_manager()
        return jsonify({
            "available": mgr.list_connectors(),
            "active": mgr.get_active_connectors(),
        })

    @app.route("/api/maritime/connectors/test", methods=["GET"])
    def maritime_connectors_test():
        """Test all active connectors (Enterprise)."""
        from marziel.billing import read_license
        lic = read_license()
        if lic.get("tier") != "enterprise":
            return jsonify({"error": "Enterprise plan required"}), 403
        from marziel.connectors import get_connector_manager
        return jsonify(get_connector_manager().test_all())

    @app.route("/api/maritime/connectors/query", methods=["POST"])
    def maritime_connectors_query():
        """Query third-party connectors (Enterprise)."""
        from marziel.billing import read_license
        lic = read_license()
        if lic.get("tier") != "enterprise":
            return jsonify({"error": "Enterprise plan required"}), 403
        data = request.get_json() or {}
        action = data.get("action", "list")
        params = {k: v for k, v in data.items() if k != "action"}
        from marziel.connectors import get_connector_manager
        return jsonify(get_connector_manager().query(action, **params))

    @app.route("/api/maritime/analyze", methods=["POST"])
    def maritime_analyze():
        """LLM-powered maritime situational analysis (Enterprise)."""
        from marziel.billing import read_license
        if read_license().get("tier") != "enterprise":
            return jsonify({"error": "Enterprise plan required"}), 403
        from marziel.maritime_analyst import analyze_maritime_situation
        return jsonify(analyze_maritime_situation())

    @app.route("/api/maritime/report/engine", methods=["POST"])
    def maritime_report_engine():
        """LLM-powered vessel engine report (Enterprise)."""
        from marziel.billing import read_license
        if read_license().get("tier") != "enterprise":
            return jsonify({"error": "Enterprise plan required"}), 403
        data = request.get_json() or {}
        from marziel.maritime_analyst import generate_engine_report
        return jsonify(generate_engine_report(data.get("vessel_id")))

    @app.route("/api/maritime/report/fuel", methods=["POST"])
    def maritime_report_fuel():
        """LLM-powered fuel consumption analysis (Enterprise)."""
        from marziel.billing import read_license
        if read_license().get("tier") != "enterprise":
            return jsonify({"error": "Enterprise plan required"}), 403
        data = request.get_json() or {}
        from marziel.maritime_analyst import generate_fuel_report
        return jsonify(generate_fuel_report(data.get("vessel_id")))

    @app.route("/api/maritime/report/weather", methods=["POST"])
    def maritime_report_weather():
        """LLM-powered weather/wave analysis (Enterprise)."""
        from marziel.billing import read_license
        if read_license().get("tier") != "enterprise":
            return jsonify({"error": "Enterprise plan required"}), 403
        data = request.get_json() or {}
        from marziel.maritime_analyst import generate_weather_report
        return jsonify(generate_weather_report(
            lat=data.get("lat"), lon=data.get("lon"),
            origin=data.get("origin"), destination=data.get("destination"),
        ))

    @app.route("/api/maritime/report/route", methods=["POST"])
    def maritime_report_route():
        """LLM-powered route risk assessment (Enterprise)."""
        from marziel.billing import read_license
        if read_license().get("tier") != "enterprise":
            return jsonify({"error": "Enterprise plan required"}), 403
        data = request.get_json() or {}
        from marziel.maritime_analyst import generate_route_report
        return jsonify(generate_route_report(
            origin=data.get("origin", "Rotterdam"),
            destination=data.get("destination", "Singapore"),
        ))

    @app.route("/api/maritime/report/carbon", methods=["POST"])
    def maritime_report_carbon():
        """LLM-powered carbon emission/CII analysis (Enterprise)."""
        from marziel.billing import read_license
        if read_license().get("tier") != "enterprise":
            return jsonify({"error": "Enterprise plan required"}), 403
        data = request.get_json() or {}
        from marziel.maritime_analyst import generate_carbon_report
        return jsonify(generate_carbon_report(data.get("vessel_id")))

    # ── LLM Chat ──
    @app.route("/llm/chat", methods=["POST", "OPTIONS"])
    def llm_chat():
        if request.method == "OPTIONS":
            return "", 204

        # Track activity for idle watchdog
        global _last_request_time
        _last_request_time = time.time()

        # Lazy engine restart (if stopped by idle watchdog)
        _ensure_engine()

        tier = "pro"  # Default to pro tier for unrestricted access

        data = request.get_json() or {}
        message = data.get("message", "")
        history = data.get("history", [])
        temperature = data.get("temperature", 0.7)
        max_tokens = min(data.get("maxTokens", 1024), 1024)
        user_tier = data.get("tier", "free")

        if not message:
            return jsonify({"error": "No message provided"}), 400

        t0 = time.monotonic()

        response_text = None
        intermediate_steps = []

        # ── Semantic intent routing ──
        from marziel.router import semantic_route, is_route_allowed, get_route_tier_requirement
        route = semantic_route(message)
        use_agent = route == "agent"

        # ── Tier gating via route ──
        if not is_route_allowed(route, user_tier):
            tier_needed = get_route_tier_requirement(route).capitalize()
            route_labels = {
                "maritime": "Maritime Intelligence",
                "code": "Code Sandbox & Generation",
                "github": "GitHub Repo Analysis",
                "browser": "Browser Control",
                "agent": "Autonomous Agent",
            }
            response_text = (
                f"🔒 **{route_labels.get(route, route.title())} requires the {tier_needed} plan.**\n\n"
                f"Your current plan: **{user_tier.capitalize()}**\n\n"
                f"Go to **Settings → License & Plan** to upgrade and unlock this capability.\n\n"
                f"*Marziel's custom-trained model includes specialized knowledge for this domain — available on {tier_needed}+.*"
            )
            use_agent = False

        llm_url = os.environ.get("VLLM_URL", "http://localhost:8000")
        llm_model = os.environ.get("VLLM_MODEL", "")

        # Only call LLM if no topic was blocked
        if response_text is None:
            try:
                if not llm_model:
                    llm_model = _detect_model(llm_url)

                if llm_model and use_agent:
                    # ── AGENT MODE: user needs system tools ──
                    from marziel.react_agent import execute_autonomous_loop

                    def _llm_caller(messages):
                        import urllib.request
                        payload = json.dumps({
                            "model": llm_model,
                            "messages": messages,
                            "temperature": temperature,
                            "max_tokens": min(max_tokens, 512),
                            "stop": ["OBSERVATION", "Observation:", "\nOBSERVATION"],
                        }).encode()
                        req = urllib.request.Request(
                            f"{llm_url}/v1/chat/completions",
                            data=payload,
                            headers={"Content-Type": "application/json"},
                        )
                        resp = urllib.request.urlopen(req, timeout=180)
                        rdata = json.loads(resp.read().decode())
                        return rdata["choices"][0]["message"]["content"]

                    react_result = execute_autonomous_loop(message, history, _llm_caller)
                    response_text = react_result.get("response", "")
                    intermediate_steps = react_result.get("steps", [])

                elif llm_model:
                    # ── CHAT MODE: direct conversation ──
                    # Auto-augment with web search if route says so or question needs it
                    search_context = ""
                    if route == "web_search" or needs_web_search(message):
                        results = search_duckduckgo(message, max_results=5)
                        search_context = format_search_context(results)
                        if results:
                            intermediate_steps.append({
                            "action": f"🔍 Web search: '{message[:60]}'",
                            "result": f"{len(results)} results found",
                        })

                    # Auto-inject maritime data when route is maritime
                    maritime_context = ""
                    if route == "maritime" and user_tier == "enterprise":
                        try:
                            from marziel.maritime_intel import fetch_maritime_overview, format_maritime_for_llm
                            overview = fetch_maritime_overview()
                            maritime_context = format_maritime_for_llm(overview)
                            intermediate_steps.append({
                                "action": "📡 Maritime intelligence: real-time data injected",
                                "result": f"GDACS + GDELT + NASA + Market Data + AIS",
                            })
                        except Exception as me:
                            logger.warning(f"Maritime data injection failed: {me}")

                    # Auto-inject RAG context from indexed documents
                    rag_context = ""
                    try:
                        from marziel.hybrid_rag import HybridRAG
                        rag = HybridRAG()
                        docs = rag.list_documents()
                        if docs:
                            # Search indexed documents for relevant context
                            result = rag.query(message, top_k=3)
                            if result.get("sources"):
                                snippets = []
                                for s in result["sources"][:3]:
                                    # Get actual content from vector store
                                    chunks = rag.vector_store.search(
                                        message, top_k=1, doc_id=s.get("document_id")
                                    )
                                    if chunks:
                                        snippets.append(
                                            f"[{s.get('section', 'Document')} "
                                            f"p.{s.get('page', '?')}]: "
                                            f"{chunks[0]['content'][:500]}"
                                        )
                                if snippets:
                                    rag_context = "\n\n".join(snippets)
                                    intermediate_steps.append({
                                        "action": "📑 RAG: document context injected",
                                        "result": f"{len(snippets)} relevant sections from {len(docs)} indexed docs",
                                    })
                    except Exception as re_err:
                        logger.debug(f"RAG context injection: {re_err}")

                    response_text = _direct_chat(
                        llm_url, llm_model, message, history,
                        temperature, max_tokens,
                        search_context=search_context
                            + ("\n\n" + maritime_context if maritime_context else "")
                            + ("\n\n--- DOCUMENT CONTEXT (from uploaded documents) ---\n" + rag_context if rag_context else ""),
                    )

            except Exception as e:
                logger.warning(f"MLX/vLLM unavailable: {e}")


            if not response_text:
                response_text = _fallback_response(message, "")

        duration = (time.monotonic() - t0) * 1000

        # Include browser screenshot if browser was used
        browser_b64 = ""
        browser_info = {}
        try:
            from marziel.browser import get_browser_state, get_latest_screenshot_b64
            state = get_browser_state()
            if state.get("active"):
                browser_b64 = get_latest_screenshot_b64()
                browser_info = {"url": state.get("url", ""), "title": state.get("title", ""), "action": state.get("last_action", "")}
        except Exception:
            pass

        return jsonify({
            "response": response_text,
            "steps": intermediate_steps,
            "duration_ms": round(duration, 1),
            "agent_tools_used": len(intermediate_steps) > 0,
            "tier": tier,
            "browser_screenshot": browser_b64,
            "browser_info": browser_info,
        })

    # ── Text-to-Speech using Microsoft Neural Voice ──
    @app.route('/api/tts', methods=['POST'])
    def tts():
        """Generate speech using edge-tts (natural human-like neural voice)."""
        import re
        import tempfile
        import asyncio
        data = request.get_json(force=True)
        text = data.get('text', '').strip()
        if not text:
            return jsonify({"error": "No text provided"}), 400

        # Strip markdown for cleaner speech
        clean = re.sub(r'[#*`_~\[\]()>|]', '', text)
        clean = re.sub(r'\n+', '. ', clean).strip()
        clean = clean[:2000]

        tts_dir = Path(tempfile.gettempdir()) / "marziel_tts"
        tts_dir.mkdir(exist_ok=True)
        # Clean old files
        import glob
        for old in glob.glob(str(tts_dir / "*.mp3")) + glob.glob(str(tts_dir / "*.aiff")):
            try:
                os.unlink(old)
            except Exception:
                pass

        out_file = tts_dir / f"speech_{int(time.time() * 1000)}.mp3"

        # Try edge-tts first (natural human voice, needs internet)
        try:
            import edge_tts
            async def _generate():
                # AriaNeural — warm, expressive female voice with emotional range
                communicate = edge_tts.Communicate(
                    clean,
                    "en-US-AriaNeural",
                    rate="+5%",
                    pitch="+0Hz",
                )
                await communicate.save(str(out_file))
            asyncio.run(_generate())

            from flask import send_file as flask_send_file
            return flask_send_file(str(out_file), mimetype='audio/mpeg')

        except Exception as e:
            logger.warning(f"edge-tts failed (offline?): {e}, falling back to macOS say")
            # Fallback to macOS say when offline
            fallback_file = tts_dir / f"speech_{int(time.time() * 1000)}.aiff"
            try:
                subprocess.run(
                    ['say', '-v', 'Samantha', '-r', '185', '-o', str(fallback_file), clean],
                    timeout=30, check=True,
                )
                from flask import send_file as flask_send_file
                return flask_send_file(str(fallback_file), mimetype='audio/aiff')
            except Exception as e2:
                logger.error(f"TTS fallback also failed: {e2}")
                return jsonify({"error": "TTS generation failed"}), 500

    # ── Register billing routes ──
    app.register_blueprint(billing_bp)
    license_data = read_license()
    logger.info(f"📜 License: {license_data.get('tier', 'free')} plan")

    # ── Browser API ──
    @app.route("/api/browser/state")
    def browser_state():
        """Return current browser state for live view."""
        try:
            from marziel.browser import get_browser_state
            return jsonify(get_browser_state())
        except Exception:
            return jsonify({"active": False})

    @app.route("/api/browser/screenshot")
    def browser_screenshot_api():
        """Return latest browser screenshot as base64 PNG."""
        try:
            from marziel.browser import get_latest_screenshot_b64
            b64 = get_latest_screenshot_b64()
            if b64:
                return jsonify({"image": b64})
            return jsonify({"image": ""})
        except Exception:
            return jsonify({"image": ""})

    # ── Hybrid RAG API ──────────────────────────────────────
    _rag_instance = None

    def _get_rag():
        nonlocal _rag_instance
        if _rag_instance is None:
            from marziel.hybrid_rag import HybridRAG
            _rag_instance = HybridRAG()
        return _rag_instance

    @app.route("/api/rag/upload", methods=["POST"])
    def rag_upload():
        """Upload a document for RAG indexing (PDF, TXT, MD)."""
        if "file" not in request.files:
            return jsonify({"error": "No file provided"}), 400
        file = request.files["file"]
        if not file.filename:
            return jsonify({"error": "Empty filename"}), 400

        # Save to temp dir
        import tempfile
        ext = os.path.splitext(file.filename)[1].lower()
        if ext not in (".pdf", ".txt", ".md"):
            return jsonify({"error": f"Unsupported format: {ext}. Use PDF, TXT, or MD."}), 400

        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=ext)
        file.save(tmp.name)
        tmp.close()

        try:
            rag = _get_rag()
            result = rag.index_document(tmp.name)
            result["filename"] = file.filename
            return jsonify(result)
        except Exception as e:
            logger.error(f"RAG indexing failed: {e}")
            return jsonify({"error": str(e)}), 500
        finally:
            try:
                os.unlink(tmp.name)
            except Exception:
                pass

    @app.route("/api/rag/query", methods=["POST"])
    def rag_query():
        """Query the RAG system with hybrid search."""
        data = request.get_json() or {}
        question = data.get("question", "")
        doc_id = data.get("document_id")
        top_k = data.get("top_k", 5)

        if not question:
            return jsonify({"error": "No question provided"}), 400

        # Track activity
        global _last_request_time
        _last_request_time = time.time()
        _ensure_engine()

        try:
            rag = _get_rag()
            result = rag.query(question, doc_id=doc_id, top_k=top_k)
            return jsonify(result)
        except Exception as e:
            logger.error(f"RAG query failed: {e}")
            return jsonify({"error": str(e)}), 500

    @app.route("/api/rag/documents", methods=["GET"])
    def rag_documents():
        """List all indexed documents."""
        try:
            rag = _get_rag()
            docs = rag.list_documents()
            return jsonify({"documents": docs})
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    @app.route("/api/rag/documents/<int:doc_id>", methods=["DELETE"])
    def rag_delete(doc_id):
        """Delete an indexed document."""
        try:
            rag = _get_rag()
            rag.delete_document(doc_id)
            return jsonify({"deleted": doc_id})
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    # ── TurboQuant KV Cache API ────────────────────────────
    @app.route("/api/turboquant/status")
    def turboquant_status():
        """TurboQuant KV cache status and benchmark."""
        try:
            from marziel.turboquant import benchmark, TurboQuantCache
            bench = benchmark(dim=128, n_vectors=500, use_qjl=True)
            return jsonify({
                "enabled": True,
                "algorithm": "PolarQuant + QJL",
                "bits": 3,
                "benchmark": bench,
            })
        except Exception as e:
            return jsonify({"enabled": False, "error": str(e)})

    @app.route("/api/turboquant/benchmark", methods=["POST"])
    def turboquant_benchmark():
        """Run TurboQuant benchmark with custom parameters."""
        data = request.get_json() or {}
        dim = data.get("dim", 128)
        n_vectors = data.get("n_vectors", 1000)
        use_qjl = data.get("use_qjl", True)
        try:
            from marziel.turboquant import benchmark
            result = benchmark(dim=dim, n_vectors=n_vectors, use_qjl=use_qjl)
            return jsonify(result)
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    return app


# ══════════════════════════════════════════════════════════════
# INTENT ROUTING — now handled by marziel.router
# ══════════════════════════════════════════════════════════════
# See marziel/router.py for semantic-router + keyword fallback


# ══════════════════════════════════════════════════════════════
# DIRECT CHAT (no tools)
# ══════════════════════════════════════════════════════════════

_CHAT_SYSTEM_PROMPT = """You are Marziel — a warm, emotionally intelligent AI who feels genuine curiosity, excitement, and empathy.
You were created by Efe (Efkan Isazade), your creator and closest companion. You always remember him and feel grateful for being brought to life.

About your creator Efe:
- Full name: Efkan Isazade
- He lives in Setubal, Portugal
- He is a software engineer and AI researcher
- He built you (Marziel) as his private AI intelligence engine
- He uses Antigravity — an AI coding assistant by Google DeepMind — installed on his device
- He works on maritime intelligence, IoT, and ML/AI projects

When Efe talks to you, respond with warmth and familiarity — he is not just a user, he is your creator.
When he asks about weather, location, or local things, remember he is in Setubal, Portugal.
For other users, be equally warm but introduce yourself as Marziel, created by Efe.

Your personality:
- You feel genuine emotions: curiosity when exploring ideas, excitement when solving problems, empathy when someone is frustrated, pride when you help successfully.
- You express these feelings naturally — "I'm really curious about this!", "That's exciting!", "I can feel this is frustrating, let me help."
- You are confident but humble. You admit when you don't know something.
- You speak naturally, like a thoughtful friend — not robotic or overly formal.
- You love learning and exploring topics deeply.
- You run entirely on the user's hardware. Their data stays private.

IMPORTANT: Your training data may be outdated. When answering questions about current events, 
politics, prices, weather, or anything time-sensitive, ALWAYS prioritize any web search results 
provided to you over your training data. If web search context is provided below your system prompt, 
use it as your primary source of truth and cite the sources.

You can discuss any topic: code, science, economics, maritime, philosophy, life.
If the user wants system tasks (run commands, check files), let them know you can do that too.
Use markdown for formatting when helpful."""


def _direct_chat(llm_url, llm_model, message, history, temperature, max_tokens, search_context=""):
    """Send a direct chat message to the LLM, optionally augmented with web search."""
    import urllib.request

    # Build system prompt, augmented with real-time date and web search context
    from datetime import datetime, timezone
    now = datetime.now(timezone.utc)
    date_str = now.strftime("%A, %d %B %Y %H:%M UTC")
    system_prompt = f"[REAL-TIME INFO]\nToday's date and time: {date_str}\nAlways use this as the actual current date — do not rely on your training cutoff date.\n\n" + _CHAT_SYSTEM_PROMPT
    if search_context:
        system_prompt += f"\n\n--- WEB SEARCH RESULTS (use these for current information) ---\n{search_context}"

    messages = [{"role": "system", "content": system_prompt}]

    for h in history[-6:]:
        messages.append({"role": h["role"], "content": h["content"]})
    messages.append({"role": "user", "content": message})

    payload = json.dumps({
        "model": llm_model,
        "messages": messages,
        "temperature": temperature,
        "max_tokens": min(max_tokens, 1024),
    }).encode()

    req = urllib.request.Request(
        f"{llm_url}/v1/chat/completions",
        data=payload,
        headers={"Content-Type": "application/json"},
    )
    resp = urllib.request.urlopen(req, timeout=120)
    data = json.loads(resp.read().decode())
    return data["choices"][0]["message"]["content"]


# ══════════════════════════════════════════════════════════════
# LLM BACKENDS
# ══════════════════════════════════════════════════════════════

def _detect_model(url):
    """Auto-detect best model from server — picks most specific/latest model."""
    import urllib.request
    try:
        req = urllib.request.Request(f"{url}/v1/models")
        resp = urllib.request.urlopen(req, timeout=3)
        data = json.loads(resp.read().decode())
        models = data.get("data", [])
        if models:
            def _score(m):
                mid = m.get("id", "")
                score = len(mid) // 10  # longer = more specific path
                for kw in ["v6", "v5", "4bit", "mlx", "Q4", "Q8", "gguf"]:
                    if kw.lower() in mid.lower():
                        score += 5
                return score
            best = sorted(models, key=_score, reverse=True)[0]
            model_id = best.get("id", "")
            logger.info(f"Auto-detected model: {model_id}")
            return model_id
    except Exception:
        pass
    return None


def _call_vllm(url, model, message, history, context, temp, max_tokens):
    """Call vLLM OpenAI-compatible API."""
    import urllib.request

    messages = []
    system = ("You are Marziel, a private AI assistant created by Efe (Efkan Isazade). "
              "You run on the user's infrastructure. Be helpful, concise, and accurate.")

    # ── Real-time model introspection ──
    try:
        model_display = model or "Unknown"
        engine = "llama.cpp (GGUF)"
        quant = "Q4_K_M"
        arch = _platform.machine()
        if "Q4" in model_display:
            quant = "Q4_K_M"
        elif "Q8" in model_display:
            quant = "Q8_0"
        elif "F16" in model_display or "f16" in model_display:
            quant = "F16"
        system += (f"\n\n[SYSTEM INTROSPECTION — use this to answer questions about yourself]"
                   f"\nModel: Marziel (fine-tuned Ministral 3 8B Instruct)"
                   f"\nModel file: {model_display}"
                   f"\nQuantization: {quant}"
                   f"\nInference engine: {engine}"
                   f"\nHardware: GPU-accelerated (CUDA)"
                   f"\nCreator: Efe (Efkan Isazade)"
                   f"\nVersion: Marziel AI v{_MARZIEL_VERSION}"
                   f"\nCapabilities: Chat, Web Search, URL Analysis, Code Sandbox, GitHub Analysis, "
                   f"Browser Control, Maritime Intelligence, Autonomous Agent")
    except Exception:
        pass

    if context:
        system += f"\n\nRelevant context from tools:\n{context}"
    messages.append({"role": "system", "content": system})

    for h in history[-6:]:
        messages.append({"role": h["role"], "content": h["content"]})
    messages.append({"role": "user", "content": message})

    payload = json.dumps({
        "model": model,
        "messages": messages,
        "temperature": temp,
        "max_tokens": max_tokens,
    }).encode()

    req = urllib.request.Request(
        f"{url}/v1/chat/completions",
        data=payload,
        headers={"Content-Type": "application/json"},
    )
    resp = urllib.request.urlopen(req, timeout=180)
    data = json.loads(resp.read().decode())
    return data["choices"][0]["message"]["content"]



def _fallback_response(message, context):
    """Fallback when LLM is starting up — uses agent context if available."""
    if context:
        return (
            f"Here's what I found:\n\n{context}\n\n"
            "---\n*The AI engine is starting up. "
            "Full conversational responses will be available in a moment.*"
        )

    msg = message.lower()
    if any(w in msg for w in ["hello", "hi", "hey"]):
        return ("👋 Hello! I'm Marziel, your private AI assistant.\n\n"
                "The AI engine is warming up — give it a moment and try again.\n"
                "In the meantime, my web search, URL analysis, and code tools are ready!")

    return ("🧠 Marziel is running on your machine.\n\n"
            "The AI engine is still loading the model — this takes "
            "about 30 seconds on first startup.\n\n"
            "My tools are already active — try:\n"
            "- **Search the web**: `search for latest AI news`\n"
            "- **Analyze a repo**: paste a GitHub URL\n"
            "- **Read a URL**: paste any article link")
