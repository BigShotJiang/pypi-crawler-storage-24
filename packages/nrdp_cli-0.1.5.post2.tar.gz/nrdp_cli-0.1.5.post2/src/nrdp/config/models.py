from dataclasses import dataclass, field
from pathlib import Path


@dataclass(slots=True)
class InterpolationConfig:
    """插值配置（用于配置文件解析）"""

    spline_order: int = 3
    workers: int = 4

    def to_interpolator_config(self):
        """转换为内部使用的 InterpolatorConfig"""
        from nrdp.domain.interpolator import InterpolatorConfig

        return InterpolatorConfig(
            spline_order=self.spline_order,
            workers=self.workers,
        )


@dataclass(slots=True)
class DatasetSplitConfig:
    enabled: bool = False
    split_csv: Path | None = None


@dataclass(slots=True)
class DatasetConfig:
    dataset_name: str
    data_dir: Path
    label_dir: Path
    output_dir: Path
    plan_output_path: Path
    logs_dir: Path
    png_output_dir: Path
    nrdp_times: int
    splits: DatasetSplitConfig = field(default_factory=DatasetSplitConfig)
    interpolation: InterpolationConfig = None  # type: ignore

    def __post_init__(self):
        if self.nrdp_times < 0 or self.nrdp_times == 1:
            raise ValueError("nrdp.times* must be 0 or >= 2")
        if self.interpolation is None:
            self.interpolation = InterpolationConfig()

    @property
    def logs_path(self) -> Path:
        return self.logs_dir
