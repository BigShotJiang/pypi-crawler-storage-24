from pathlib import Path

import typer

from nrdp import __version__
from nrdp.commands.get import write_dataset_template, write_plan_template
from nrdp.commands.plan import execute_plan
from nrdp.commands.print import execute_print
from nrdp.commands.run import run_pipeline
from nrdp.commands.split import execute_split
from nrdp.commands.start import execute_start


app = typer.Typer(help="NRDP CLI")


def _version_text() -> str:
    return f"nrdp {__version__}"


def _print_version(value: bool) -> None:
    if not value:
        return
    typer.echo(_version_text())
    raise typer.Exit()


@app.callback()
def root_callback(
    version: bool = typer.Option(
        False,
        "--version",
        "-v",
        is_eager=True,
        callback=_print_version,
    ),
) -> None:
    return None


@app.command()
def get(
    plan_template: bool = typer.Option(False, "--plan-template"),
) -> None:
    if plan_template:
        write_plan_template(Path.cwd())
        return

    write_dataset_template(Path.cwd())


@app.command()
def plan(
    input: Path | None = typer.Option(None, "--input"),
    fix: bool = typer.Option(False, "--fix"),
    plan_path: Path | None = typer.Option(None, "--plan"),
    in_place: bool = typer.Option(False, "--in-place"),
    output: Path | None = typer.Option(None, "--output"),
    verbose: bool = typer.Option(False, "--verbose"),
    workers: int = typer.Option(4, "--workers", min=1),
) -> None:
    if fix:
        if plan_path is None:
            raise typer.BadParameter("--plan is required when using --fix")

        from nrdp.config.parser import load_config_document
        from nrdp.commands.plan import repair_plan_document
        from nrdp.output.plan_writer import write_plan_document

        repaired = repair_plan_document(load_config_document(plan_path))
        destination = plan_path if in_place else output
        if destination is None:
            destination = plan_path.with_name(f"{plan_path.stem}_fixed{plan_path.suffix}")
        write_plan_document(destination, repaired)
        return

    if input is None:
        raise typer.BadParameter("--input is required unless using --fix")

    _, has_errors = execute_plan(input_path=input, verbose=verbose, workers=workers)
    if has_errors:
        raise typer.Exit(code=1)


@app.command()
def start(
    plan: Path = typer.Option(..., "--plan"),
    verbose: bool = typer.Option(False, "--verbose"),
    workers: int = typer.Option(4, "--workers", min=1),
    spline_order: int | None = typer.Option(
        None,
        "--spline-order", "-o",
        help="B-Spline 插值阶数 (1=线性, 3=三次, 5=五次)",
    ),
) -> None:
    try:
        execute_start(
            plan_path=plan,
            verbose=verbose,
            workers=workers,
            spline_order=spline_order,
        )
    except ValueError as exc:
        typer.echo(str(exc))
        raise typer.Exit(code=1) from exc


@app.command()
def run(
    input: Path = typer.Option(..., "--input"),
    verbose: bool = typer.Option(False, "--verbose"),
    workers: int = typer.Option(4, "--workers", min=1),
) -> None:
    run_pipeline(config_path=input, verbose=verbose, workers=workers)


@app.command()
def split(
    plan: Path = typer.Option(..., "--plan"),
    verbose: bool = typer.Option(False, "--verbose"),
) -> None:
    try:
        execute_split(plan_path=plan, verbose=verbose)
    except FileNotFoundError as exc:
        typer.echo(str(exc))
        raise typer.Exit(code=1) from exc
    except ValueError as exc:
        typer.echo(str(exc))
        raise typer.Exit(code=1) from exc


@app.command()
def version() -> None:
    typer.echo(_version_text())


@app.command("print")
def print_cmd(
    plan: Path = typer.Option(..., "--plan"),
    verbose: bool = typer.Option(False, "--verbose"),
    workers: int = typer.Option(4, "--workers", min=1),
) -> None:
    """Generate PNG visualization of interpolation results."""
    try:
        execute_print(plan_path=plan, verbose=verbose, workers=workers)
    except FileNotFoundError as exc:
        typer.echo(str(exc))
        raise typer.Exit(code=1) from exc
    except ValueError as exc:
        typer.echo(str(exc))
        raise typer.Exit(code=1) from exc


def main() -> None:
    app()
