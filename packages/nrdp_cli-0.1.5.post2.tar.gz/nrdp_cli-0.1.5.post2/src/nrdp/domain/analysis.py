from dataclasses import dataclass

import numpy as np

from nrdp.domain.interpolation import (
    build_adaptive_pair_insertions,
    build_fixed_pair_insertions,
)


@dataclass(slots=True)
class SampleAnalysis:
    sample_id: str
    axis: int | None
    tumor_indices: list[int]
    segments: list[list[int]]
    plan_status: dict | None | str


def analyze_sample(
    sample_id: str,
    data_shape: tuple[int, int, int],
    label: np.ndarray,
    times: int,
) -> SampleAnalysis:
    dims = list(data_shape)
    min_value = min(dims)
    if dims.count(min_value) != 1:
        return SampleAnalysis(sample_id, None, [], [], None)

    axis = dims.index(min_value)
    tumor_indices = [
        idx for idx in range(label.shape[axis]) if np.any(np.take(label, idx, axis=axis) > 0)
    ]
    if len(tumor_indices) < 2:
        return SampleAnalysis(sample_id, axis, tumor_indices, [], None)

    segments: list[list[int]] = []
    current = [tumor_indices[0]]
    for idx in tumor_indices[1:]:
        if idx == current[-1] + 1:
            current.append(idx)
        else:
            segments.append(current)
            current = [idx]
    segments.append(current)

    executable_segments = [segment for segment in segments if len(segment) >= 2]
    if not executable_segments:
        return SampleAnalysis(sample_id, axis, tumor_indices, segments, None)

    current_slides = dims[axis]
    other_dims = [dim for index, dim in enumerate(dims) if index != axis]
    target_slides = (sum(other_dims) + 1) // 2

    if times == 0:
        inserted_slices = target_slides - current_slides
        if inserted_slices <= 0:
            return SampleAnalysis(sample_id, axis, tumor_indices, segments, None)
        pair_insertions = build_adaptive_pair_insertions(
            segments=executable_segments,
            total_insertions=inserted_slices,
        )
        mode = "adaptive"
    else:
        pair_insertions = build_fixed_pair_insertions(executable_segments, times)
        inserted_slices = sum(item["insertions"] for item in pair_insertions)
        mode = "fixed"

    if not pair_insertions or inserted_slices <= 0:
        return SampleAnalysis(sample_id, axis, tumor_indices, segments, None)

    segment_plans: list[dict[str, object]] = []
    cursor = 0
    for segment_index, segment in enumerate(executable_segments):
        pair_count = len(segment) - 1
        segment_pairs = pair_insertions[cursor:cursor + pair_count]
        cursor += pair_count
        segment_plans.append(
            {
                "segment_index": segment_index,
                "tumor_slice_index": list(segment),
                "pairs": [
                    {
                        "left": pair["left"],
                        "right": pair["right"],
                    }
                    for pair in segment_pairs
                ],
                "assigned_insertions": sum(pair["insertions"] for pair in segment_pairs),
            }
        )

    return SampleAnalysis(
        sample_id=sample_id,
        axis=axis,
        tumor_indices=tumor_indices,
        segments=segments,
        plan_status={
            "mode": mode,
            "times": times,
            "current_slides": current_slides,
            "target_slides": target_slides,
            "inserted_slices": inserted_slices,
            "interpolable_pairs": len(pair_insertions),
            "nrdp_slides": current_slides + inserted_slices,
            "segment_plans": segment_plans,
            "pair_insertions": pair_insertions,
        },
    )
