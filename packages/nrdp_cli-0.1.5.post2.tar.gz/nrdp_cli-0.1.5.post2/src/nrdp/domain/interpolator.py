from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

import numpy as np
from scipy.ndimage import map_coordinates

from nrdp.domain.interpolation import build_fixed_pair_insertions, interpolate_binary_mask

SplineOrder = Literal[1, 3, 5]


@dataclass(slots=True)
class InterpolatorConfig:
    """插值器配置"""

    spline_order: SplineOrder = 3
    workers: int = 4


class SliceInterpolator:
    """切片插值器，支持 B-Spline 插值"""

    def __init__(self, config: InterpolatorConfig | None = None):
        self.config = config or InterpolatorConfig()

    def interpolate_slice(
        self,
        slice_a: np.ndarray,
        slice_b: np.ndarray,
        alpha: float,
        binary: bool = False,
    ) -> np.ndarray:
        """
        在两个切片之间插值生成新切片

        Args:
            slice_a: 左侧切片
            slice_b: 右侧切片
            alpha: 插值权重，0=完全 slice_a, 1=完全 slice_b
            binary: 是否为二值标签

        Returns:
            插值后的切片
        """
        if binary:
            return interpolate_binary_mask(slice_a, slice_b, alpha)
        return self._bspline_interpolate(slice_a, slice_b, alpha)

    def _bspline_interpolate(
        self,
        slice_a: np.ndarray,
        slice_b: np.ndarray,
        alpha: float,
    ) -> np.ndarray:
        """
        B-Spline 插值实现

        使用 scipy.ndimage.map_coordinates 在两个切片之间进行插值
        """
        # 将两个切片沿新轴堆叠，形成 (2, H, W) 的体积
        stacked = np.stack([slice_a, slice_b], axis=0)
        original_dtype = slice_a.dtype

        # 构建坐标网格
        # 在第0维（切片维度）上进行插值，alpha=0 对应第一个切片，alpha=1 对应第二个
        shape = slice_a.shape
        z_coord = np.full(shape, alpha, dtype=np.float32)

        # 构建 y, x 坐标网格（保持原始位置）
        y_coords, x_coords = np.meshgrid(
            np.arange(shape[0], dtype=np.float32),
            np.arange(shape[1], dtype=np.float32),
            indexing='ij'
        )

        # 组合坐标：(3, H, W) - (z, y, x)
        coordinates = np.stack([z_coord, y_coords, x_coords], axis=0)

        # 使用 map_coordinates 进行 B-Spline 插值
        interpolated = map_coordinates(
            stacked,
            coordinates,
            order=self.config.spline_order,
            mode='nearest',
        )

        return interpolated.astype(original_dtype)

    def expand_volume(
        self,
        volume: np.ndarray,
        *,
        axis: int,
        pair_insertions: list[dict[str, int]] | None = None,
        segments: list[list[int]] | None = None,
        times: int | None = None,
        binary: bool = False,
    ) -> np.ndarray:
        """
        扩展体积数据，在指定轴的连续段之间插入插值切片

        Args:
            volume: 输入体积数据
            axis: 扩展轴 (0=X, 1=Y, 2=Z)
            pair_insertions: 每对相邻切片的插值计划
            segments: 连续切片索引段列表（旧兼容路径）
            times: 扩展倍数（旧兼容路径）
            binary: 是否为二值标签

        Returns:
            扩展后的体积数据
        """
        if pair_insertions is None:
            if times is None or segments is None:
                raise ValueError("pair_insertions or (segments and times) must be provided")
            if times <= 1 or not segments:
                return volume.copy()
            pair_insertions = build_fixed_pair_insertions(segments, times)

        if not pair_insertions:
            return volume.copy()

        # 收集需要在每个 left 索引后插入的切片
        inserts_by_left: dict[int, list[np.ndarray]] = {}
        for pair in pair_insertions:
            insertions = int(pair["insertions"])
            if insertions <= 0:
                continue
            left = int(pair["left"])
            right = int(pair["right"])
            left_slice = np.take(volume, left, axis=axis)
            right_slice = np.take(volume, right, axis=axis)
            generated: list[np.ndarray] = []
            for step in range(1, insertions + 1):
                alpha = step / (insertions + 1)
                generated.append(self.interpolate_slice(left_slice, right_slice, alpha, binary))
            inserts_by_left.setdefault(left, []).extend(generated)

        # 构建输出体积
        slices: list[np.ndarray] = []
        for index in range(volume.shape[axis]):
            slices.append(np.take(volume, index, axis=axis))
            slices.extend(inserts_by_left.get(index, []))

        return np.stack(slices, axis=axis)
