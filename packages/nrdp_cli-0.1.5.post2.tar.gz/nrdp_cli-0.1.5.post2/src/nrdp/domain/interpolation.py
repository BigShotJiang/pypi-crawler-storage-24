from __future__ import annotations

import numpy as np


def collect_contiguous_segments(indices: list[int]) -> list[list[int]]:
    if not indices:
        return []

    segments: list[list[int]] = []
    current = [indices[0]]
    for idx in indices[1:]:
        if idx == current[-1] + 1:
            current.append(idx)
        else:
            segments.append(current)
            current = [idx]
    segments.append(current)
    return segments


def build_fixed_pair_insertions(segments: list[list[int]], times: int) -> list[dict[str, int]]:
    if times < 2:
        raise ValueError("fixed expansion requires times >= 2")

    return [
        {"left": left, "right": right, "insertions": times - 1}
        for segment in segments
        for left, right in zip(segment, segment[1:])
    ]


def build_adaptive_pair_insertions(
    *,
    segments: list[list[int]],
    total_insertions: int,
) -> list[dict[str, int]]:
    segment_pairs: list[list[dict[str, int]]] = [
        [
            {"left": left, "right": right, "insertions": 0}
            for left, right in zip(segment, segment[1:])
        ]
        for segment in segments
        if len(segment) >= 2
    ]
    if total_insertions <= 0 or not segment_pairs:
        return []

    total_pair_count = sum(len(pairs) for pairs in segment_pairs)
    base_insertions = total_insertions // total_pair_count
    remainder = total_insertions % total_pair_count

    for pairs in segment_pairs:
        for pair in pairs:
            pair["insertions"] = base_insertions

    if remainder:
        segment_extras = [0] * len(segment_pairs)
        fractional_rank: list[tuple[float, int, int]] = []
        assigned = 0

        for segment_index, pairs in enumerate(segment_pairs):
            exact_share = remainder * len(pairs) / total_pair_count
            base_share = int(exact_share)
            segment_extras[segment_index] = base_share
            assigned += base_share
            fractional_rank.append((exact_share - base_share, len(pairs), segment_index))

        leftover = remainder - assigned
        fractional_rank.sort(key=lambda item: (-item[0], -item[1], item[2]))
        for _, _, segment_index in fractional_rank[:leftover]:
            segment_extras[segment_index] += 1

        for segment_index, extra_count in enumerate(segment_extras):
            if extra_count <= 0:
                continue
            pairs = segment_pairs[segment_index]
            for extra_index in range(extra_count):
                pairs[extra_index % len(pairs)]["insertions"] += 1

    return [pair for pairs in segment_pairs for pair in pairs]


def expanded_tumor_slice_indices_for_pairs(
    axis_length: int,
    tumor_indices: list[int],
    pair_insertions: list[dict[str, int]],
) -> list[int]:
    if not tumor_indices:
        return []

    insertions_by_left = {
        pair["left"]: pair["insertions"]
        for pair in pair_insertions
        if pair["insertions"] > 0
    }
    tumor_set = set(tumor_indices)
    output_index = 0
    expanded: list[int] = []

    for input_index in range(axis_length):
        if input_index in tumor_set:
            expanded.append(output_index)
            output_index += 1
            extra = insertions_by_left.get(input_index, 0)
            for offset in range(extra):
                expanded.append(output_index + offset)
            output_index += extra
        else:
            output_index += 1

    return expanded


def expanded_tumor_slice_indices(axis_length: int, tumor_indices: list[int], times: int) -> list[int]:
    if len(tumor_indices) < 2 or times <= 1:
        return list(tumor_indices)

    pair_insertions = build_fixed_pair_insertions(
        collect_contiguous_segments(tumor_indices),
        times,
    )
    return expanded_tumor_slice_indices_for_pairs(axis_length, tumor_indices, pair_insertions)


def interpolate_binary_mask(mask_a: np.ndarray, mask_b: np.ndarray, alpha: float) -> np.ndarray:
    blended = (1.0 - alpha) * mask_a.astype(np.float32) + alpha * mask_b.astype(np.float32)
    return (blended >= 0.5).astype(np.uint8)
