from __future__ import annotations

import csv
import shutil
from pathlib import Path
from typing import Any

from nrdp.config.parser import load_config_document, load_dataset_config
from nrdp.output.writers import (
    ensure_output_dir,
    resolve_command_log_path,
    write_split_summary_csv,
)
from nrdp.runtime.reporting import CommandReporter


def _sample_id_from_name(path: Path) -> str:
    return path.name.split(".")[0]


def _load_assignments(path: Path) -> dict[str, str]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames or "id" not in reader.fieldnames or "split" not in reader.fieldnames:
            raise ValueError(f"{path}: split CSV must contain id and split columns")

        assignments: dict[str, str] = {}
        for row in reader:
            sample_id = row["id"].strip()
            split_name = row["split"].strip()
            if split_name not in {"train", "test"}:
                raise ValueError(f"{path}: unsupported split value {split_name!r} for {sample_id}")
            previous = assignments.get(sample_id)
            if previous is not None and previous != split_name:
                raise ValueError(f"{path}: conflicting split assignment for {sample_id}")
            assignments[sample_id] = split_name
    return assignments


def _paired_outputs(output_dir: Path) -> list[tuple[str, Path, Path]]:
    pairs: list[tuple[str, Path, Path]] = []
    for data_path in sorted((output_dir / "data").glob("*.nrrd")):
        sample_id = _sample_id_from_name(data_path)
        label_path = output_dir / "label" / data_path.name.replace(".image.", ".label.")
        if not label_path.exists():
            raise ValueError(f"{sample_id}: missing interpolated label output")
        pairs.append((sample_id, data_path, label_path))
    return pairs


def execute_split(plan_path: Path, verbose: bool = False) -> dict[str, Any]:
    document = load_config_document(plan_path)
    config = load_dataset_config(Path(document["nrdp"]["json_path*"]))
    split_root = ensure_output_dir(config.output_dir / "split")
    reporter = CommandReporter(
        verbose=verbose,
        log_path=resolve_command_log_path(config.logs_dir, "split"),
    )
    try:
        assignments = _load_assignments(config.splits.split_csv)
        pairs = _paired_outputs(config.output_dir)

        reporter.phase("Split", total=len(pairs))

        rows: list[dict[str, object]] = []
        for sample_id, data_path, label_path in pairs:
            if sample_id not in assignments:
                raise ValueError(f"{sample_id}: missing split assignment in {config.splits.split_csv}")
            split_name = assignments[sample_id]
            target_data = ensure_output_dir(split_root / split_name / "data") / data_path.name
            target_label = ensure_output_dir(split_root / split_name / "label") / label_path.name
            shutil.copy2(data_path, target_data)
            shutil.copy2(label_path, target_label)
            rows.append(
                {
                    "patient_id": sample_id,
                    "split": split_name,
                    "data_path": str(target_data),
                    "label_path": str(target_label),
                    "status": "copied",
                }
            )
            reporter.advance()
            reporter.debug(f"split sample {sample_id} -> {split_name}")

        reporter.finish_phase()
        write_split_summary_csv(split_root / "split.csv", rows)
        reporter.print_summary()
        return {"total": len(rows)}
    finally:
        reporter.close()
