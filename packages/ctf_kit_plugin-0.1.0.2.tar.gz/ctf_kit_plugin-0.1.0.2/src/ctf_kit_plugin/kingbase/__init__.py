"""
pip install APScheduler -i https://pypi.tuna.tsinghua.edu.cn/simple
"""
try:
    import apscheduler
except ImportError:
    print("请执行如下命令安装 APScheduler：")
    print('pip install APScheduler -i https://pypi.tuna.tsinghua.edu.cn/simple')
    exit(1)


