from typing import Any, Dict, Optional, TypeVar
from fastapi import HTTPException
from fastapi.responses import JSONResponse

from holo_core.exception.error_code import ErrorCode
from holo_core.schemas.response_schemas import ApiResponse

# 定义泛型类型变量
T = TypeVar('T')


def success(data: Any = None, message: str = "操作成功", code: ErrorCode = ErrorCode.SUCCESS,
            to_json: bool = False):
    """
    成功响应

    Args:
        data: 响应数据
        message: 响应消息
        code: 错误码
        to_json: 是否转换为JSON格式

    Returns:
        ApiResponse或dict: 成功响应
    """
    if not isinstance(data, ApiResponse):
        response = ApiResponse(success=True, code=code.code, message=message, data=data)
    else:
        response = data
    if to_json:
        return response.model_dump()
    return response


def error(message: str = "操作失败", code: ErrorCode = ErrorCode.SERVER_ERROR,
          details: Any = None) -> ApiResponse:
    """
    错误响应

    Args:
        message: 错误消息
        code: 错误码
        details: 详细信息

    Returns:
        ApiResponse: 错误响应
    """
    return ApiResponse(
        success=False,
        code=code.code,
        message=message if message else code.message,
        details=details,
        data=None
    )


def error_resp(message: str = "操作失败", code: ErrorCode = ErrorCode.SERVER_ERROR,
               status_code: int = 400, details: Any = None) -> JSONResponse:
    """
    错误响应

    Args:
        message: 错误消息
        code: 错误码
        status_code: HTTP状态码
        details: 详细信息

    Returns:
        JSONResponse: 错误响应
    """
    response = error(message, code, details)
    return JSONResponse(
        content=response.model_dump(),
        status_code=status_code
    )


def handle_validation_error(exc) -> JSONResponse:
    """
    处理验证错误

    Args:
        exc: 验证异常

    Returns:
        JSONResponse: 错误响应
    """
    # 获取第一个验证错误的详细信息
    error_detail = exc.errors()[0] if exc.errors() else {}
    field = error_detail.get("loc", [-1])[-1] if error_detail.get("loc") else "unknown"
    error_msg = error_detail.get("msg", "验证失败")

    details = {
        "field": field,
        "message": error_msg
    }

    return error_resp(
        message=f"参数验证失败: {error_msg}",
        code=ErrorCode.VALIDATION_ERROR,
        status_code=422,
        details=details
    )


def not_found(message: str = "资源不存在",
              details: Optional[Dict[str, Any]] = None) -> JSONResponse:
    """
    资源不存在响应

    Args:
        message: 错误信息
        details: 详细错误信息

    Returns:
        JSONResponse: JSON响应
    """
    return error_resp(
        code=ErrorCode.NOT_FOUND,
        message=message,
        details=details,
        status_code=404
    )


def unauthorized(message: str = "未授权",
                 details: Optional[Dict[str, Any]] = None) -> JSONResponse:
    """
    未授权响应

    Args:
        message: 错误信息
        details: 详细错误信息

    Returns:
        JSONResponse: JSON响应
    """
    return error_resp(
        code=ErrorCode.TOKEN_INVALID,
        message=message,
        details=details,
        status_code=401
    )


def forbidden(message: str = "权限不足",
              details: Optional[Dict[str, Any]] = None) -> JSONResponse:
    """
    权限不足响应

    Args:
        message: 错误信息
        details: 详细错误信息

    Returns:
        JSONResponse: JSON响应
    """
    return error_resp(
        code=ErrorCode.PERMISSION_DENIED,
        message=message,
        details=details,
        status_code=403
    )


def server_error(message: str = "服务器内部错误",
                 details: Optional[Dict[str, Any]] = None) -> JSONResponse:
    """
    服务器内部错误响应

    Args:
        message: 错误信息
        details: 详细错误信息

    Returns:
        JSONResponse: JSON响应
    """
    return error_resp(
        code=ErrorCode.SERVER_ERROR,
        message=message,
        details=details,
        status_code=500
    )


def raise_http_exception(code: ErrorCode, detail: str = None, headers: Dict[str, Any] = None) -> None:
    """
    抛出HTTP异常

    Args:
        code: 错误码
        detail: 详细信息，如果为None则使用错误码对应的消息
        headers: 响应头

    Raises:
        HTTPException: FastAPI的HTTP异常
    """
    if detail is None:
        detail = code.message
    raise HTTPException(
        status_code=code.http_status,
        detail={"code": code.value, "success": False, "message": detail},
        headers=headers
    )
