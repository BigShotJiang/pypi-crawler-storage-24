from abc import ABC

from starlette.requests import Request

from holo_plugin.fastapi.middleware.token_auth_middleware import TokenAuthMiddleware


class BearerAuthMiddleware(TokenAuthMiddleware, ABC):

    def get_token(self, request: Request) -> str:
        """
        从Authorization中获取token
        :param request:
        :return:
        """
        return request.headers.get("Authorization", "").replace("Bearer ", "")