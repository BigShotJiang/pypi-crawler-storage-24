from abc import ABC

from starlette.requests import Request

from holo_plugin.fastapi.middleware.token_auth_middleware import TokenAuthMiddleware


class CookieAuthMiddleware(TokenAuthMiddleware, ABC):

    def get_token(self, request: Request) -> str:
        """
        从Cookie中获取token
        :param request:
        :return:
        """
        return request.cookies.get("token", "")