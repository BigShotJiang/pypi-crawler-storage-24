from abc import ABC, abstractmethod

from starlette.requests import Request

from holo_plugin.fastapi.middleware.auth_middleware import AuthMiddleware


class TokenAuthMiddleware(AuthMiddleware, ABC):
    """
    Token认证中间件
    """
    async def authenticate(self, request: Request) -> bool:
        # 1. 从请求中获取token（示例：从headers中获取）
        token = await self.get_token(request)
        if not token:
            return  False
        request.state.token = token
        # 2、通过token获取用户信息
        user = await self.get_current_user(token)
        if not user:
            return  False
        # 3、将用户信息存入请求上下文（request.state）
        request.state.user = user
        return True

    @abstractmethod
    async def get_token(self, request: Request) -> str:
        """
        从请求中获取token
        :param request:
        :return:
        """
        pass

    @abstractmethod
    async def get_current_user(self, token: str):
        """
        从token中获取用户信息
        :param token:
        :return:
        """
        pass