import threading
import traceback
from typing import Dict, Any, List

import yaml
from apscheduler.job import Job
from apscheduler.jobstores.base import JobLookupError
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.interval import IntervalTrigger

from .job_utils import wrap_job
from .schemas import SchedulerJob
from ctf_kit_core.util import logging_utils, module_utils

logger = logging_utils.get_logger('APSTaskScheduler')

# 加载配置文件
def load_job_config(config_path: str) -> Dict[str, Any]:
    """加载定时任务配置"""
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            config = yaml.safe_load(f)
        return config.get("jobs", {})
    except Exception as e:
        logger.error(f"加载任务配置失败：{str(e)}")
        return {}

# 兼容函数：获取任务状态
def get_job_status(job: Job) -> str:
    """
    兼容获取任务状态
    - running: 任务正常运行（有下一次执行时间）
    - paused: 任务已暂停（无下一次执行时间）
    """
    if job.next_run_time is not None:
        return "running"
    else:
        return "paused"

# 兼容函数：获取任务标签
def get_job_tags(job: Job) -> List[str]:
    """兼容获取任务标签（适配不同APScheduler版本）"""
    try:
        # 优先读取公有属性
        return job.tags if hasattr(job, "tags") else []
    except:
        # 兼容旧版本私有属性
        return job._tags if hasattr(job, "_tags") else []

class APSTaskScheduler:
    """基于APScheduler的单例调度器（适配FastAPI，修复属性兼容问题）"""
    _instance = None
    _lock = threading.Lock()

    def __new__(cls, job_config_yaml_file: str):
        cls.job_config_yaml_file=job_config_yaml_file
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    # 初始化后台调度器（非阻塞，适配FastAPI主线程）
                    cls._instance.scheduler = BackgroundScheduler(timezone="Asia/Shanghai")  # 指定时区
                    cls._instance.job_config = load_job_config(job_config_yaml_file)
                    cls._instance.is_running = False
        return cls._instance

    def register_jobs_from_config(self):
        """从配置文件注册所有启用的任务"""
        for job_id, job_config in self.job_config.items():
            if not job_config.get("enabled", False):
                logger.info(f"任务 {job_id} 已禁用，跳过注册")
                continue

            # 导入任务函数
            func_path = job_config.get("func")
            task_func = module_utils.import_func(func_path)
            if not task_func:
                continue

            job = SchedulerJob(job_id=job_id, run_func=task_func)
            # 解析调度配置
            task_type = job_config.get("type")
            job.scheduled_type = task_type
            job.tags = job_config.get("tags", [])
            job.run_func_kwargs=job_config.get("func_kwargs", {})

            # 创建触发器
            if task_type == "interval":
                job.scheduled_config = job_config.get("interval", {})
            elif task_type == "cron":
                job.scheduled_config = job_config.get("cron", {})
            else:
                logger.error(f"任务 {job_id} 配置错误：不支持的调度类型 {task_type}")
                continue
            # 注册任务
            self.register_job(job)

    def register_job(self, job:SchedulerJob):
        """注册任务"""
        try:
            # 包装任务函数
            wrapped_func = wrap_job(job.run_func, job)
            # 创建触发器
            if job.scheduled_type == "interval":
                trigger = IntervalTrigger(**job.scheduled_config)
            elif job.scheduled_type == "cron":
                if job.scheduled_cron:
                    trigger = CronTrigger.from_crontab(job.scheduled_cron)
                else:
                    trigger = CronTrigger(**job.scheduled_config)
            else:
                logger.error(f"任务 {job.job_id} 配置错误：不支持的调度类型 {job.scheduled_type}")
                return

            self.scheduler.add_job(
                func=wrapped_func,
                kwargs=job.run_func_kwargs,
                trigger=trigger,
                id=job.job_id,
                tags=job.tags,  # 显式指定标签
                replace_existing=job.replace_existing
            )
            logger.info(f"任务 {job.job_id} 注册成功 | 类型：{job.scheduled_type}")
        except Exception as e:
            logger.error(f"注册任务 {job.job_id} 失败：{str(e)}", traceback.format_exc())

    def start(self):
        """启动调度器（FastAPI启动时调用）"""
        if self.is_running:
            logger.warning("调度器已在运行中")
            return

        # 注册任务
        self.register_jobs_from_config()
        # 启动调度器
        self.scheduler.start()
        self.is_running = True
        logger.info("APScheduler 定时任务调度器启动成功（FastAPI 集成模式）")

    def stop(self):
        """停止调度器（FastAPI关闭时调用）"""
        if not self.is_running:
            logger.warning("调度器未运行")
            return

        self.scheduler.shutdown()
        self.is_running = False
        logger.info("APScheduler 定时任务调度器已停止")

    def reload_config(self):
        """热重载配置文件并更新任务"""
        logger.info("开始热重载任务配置...")
        # 重新加载配置
        self.job_config = load_job_config(self.job_config_yaml_file)
        # 移除所有现有任务
        self.scheduler.remove_all_jobs()
        # 重新注册任务
        self.register_jobs_from_config()
        logger.info("任务配置热重载完成")

    def get_job_info(self, task_id: str = None) -> Dict[str, Any]:
        """获取任务信息（单个/所有），修复属性兼容问题"""
        if task_id:
            job = self.scheduler.get_job(task_id)
            if not job:
                return {"code": 404, "msg": f"任务 {task_id} 不存在"}
            # 兼容获取状态和标签
            status = get_job_status(job)
            tags = get_job_tags(job)
            next_run_time = job.next_run_time.strftime("%Y-%m-%d %H:%M:%S") if job.next_run_time else None
            return {
                "code": 200,
                "data": {
                    "task_id": job.id,
                    "status": status,
                    "next_run_time": next_run_time,
                    "tags": tags,
                    "trigger": str(job.trigger)
                }
            }
        else:
            # 获取所有任务
            jobs = self.scheduler.get_jobs()
            job_list = []
            for job in jobs:
                status = get_job_status(job)
                tags = get_job_tags(job)
                next_run_time = job.next_run_time.strftime("%Y-%m-%d %H:%M:%S") if job.next_run_time else None
                job_list.append({
                    "task_id": job.id,
                    "status": status,
                    "next_run_time": next_run_time,
                    "tags": tags,
                    "trigger": str(job.trigger)
                })
            return {"code": 200, "data": job_list}

    def pause_job(self, task_id: str) -> Dict[str, str]:
        """暂停指定任务"""
        try:
            self.scheduler.pause_job(task_id)
            logger.info(f"任务 {task_id} 已暂停")
            return {"code": 200, "msg": f"任务 {task_id} 暂停成功"}
        except JobLookupError:
            return {"code": 404, "msg": f"任务 {task_id} 不存在"}
        except Exception as e:
            logger.error(f"暂停任务 {task_id} 失败：{str(e)}")
            return {"code": 500, "msg": f"暂停失败：{str(e)}"}

    def resume_job(self, task_id: str) -> Dict[str, str]:
        """恢复指定任务"""
        try:
            self.scheduler.resume_job(task_id)
            logger.info(f"任务 {task_id} 已恢复")
            return {"code": 200, "msg": f"任务 {task_id} 恢复成功"}
        except JobLookupError:
            return {"code": 404, "msg": f"任务 {task_id} 不存在"}
        except Exception as e:
            logger.error(f"恢复任务 {task_id} 失败：{str(e)}")
            return {"code": 500, "msg": f"恢复失败：{str(e)}"}

    def remove_job(self, task_id: str) -> Dict[str, str]:
        """删除指定任务"""
        try:
            self.scheduler.remove_job(task_id)
            logger.info(f"任务 {task_id} 已删除")
            return {"code": 200, "msg": f"任务 {task_id} 删除成功"}
        except JobLookupError:
            return {"code": 404, "msg": f"任务 {task_id} 不存在"}
        except Exception as e:
            logger.error(f"删除任务 {task_id} 失败：{str(e)}")
            return {"code": 500, "msg": f"删除失败：{str(e)}"}

if __name__ == '__main__':
    # 全局调度器实例（FastAPI中直接导入使用）
    aps_scheduler = APSTaskScheduler()
    aps_scheduler.start()
    # aps_scheduler.stop()