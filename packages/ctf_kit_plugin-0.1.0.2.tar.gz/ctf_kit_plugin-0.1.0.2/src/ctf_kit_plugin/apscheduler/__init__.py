"""
pip install PyYAML APScheduler -i https://pypi.tuna.tsinghua.edu.cn/simple
"""
try:
    import apscheduler,yaml
except ImportError:
    print("请执行如下命令安装 APScheduler：")
    print('pip install PyYAML APScheduler -i https://pypi.tuna.tsinghua.edu.cn/simple')
    exit(1)


