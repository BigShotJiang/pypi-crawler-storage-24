from typing import Callable,Optional,Literal,Dict,Any

from pydantic import BaseModel, Field


class SchedulerJob(BaseModel):
    """定时调度任务"""
    job_id:str
    run_func: Callable[..., None]
    run_func_kwargs: Optional[Dict[str, Any]] = Field(default={})
    scheduled_type: Optional[Literal['interval', 'cron']] = Field(default='cron')
    scheduled_config:Optional[Dict[str, Any]] = Field(default={})
    scheduled_cron: Optional[str] = Field(default=None)
    tags: Optional[list[str]] = Field(default=[])
    replace_existing: Optional[bool] = Field(default=True)

