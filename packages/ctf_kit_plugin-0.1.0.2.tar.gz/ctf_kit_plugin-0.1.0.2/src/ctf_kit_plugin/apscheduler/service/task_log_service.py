import typing


class JobLogService:
    """任务日志记录"""

    def add_start_log(self, job_id: str, *args, **kwargs) -> str:
        """
        添加开始日志
        :param job_id: 任务id
        :param args:
        :param kwargs:
        :return: task_id
        """
        pass

    def add_end_log(self, task_id: str, run_status: typing.Literal[200, 500],
                    fail_msg: str = None, *args, **kwargs):
        """
        添加结束日志
        :param task_id:  task_id
        :param run_status: 运行状态
        :param fail_msg: 错误信息
        :param args:
        :param kwargs:
        :return:
        """
        pass
