import traceback
from functools import wraps
from typing import Callable

from ctf_kit_core.application.context.application_context import ApplicationContext
from .schemas import SchedulerJob
from ctf_kit_core.util import logging_utils

logger = logging_utils.get_logger('APSTaskScheduler')

job_log_service = ApplicationContext.get_singleton_instance("job_log_service")

def wrap_job(func: Callable, job:SchedulerJob) -> Callable:
    """任务包装器：添加日志和异常捕获"""

    @wraps(func)
    def wrapper(*args, **kwargs):
        logger.info(f"任务 {func.__name__} 开始执行")
        task_id = job_log_service.add_start_log(job.job_id)
        try:
            result = func(*args, **kwargs)
            logger.info(f"任务 {func.__name__} 执行完成")
            job_log_service.add_end_log(task_id, run_status=200)
            return result
        except Exception as e:
            logger.error(f"任务 {func.__name__} 执行失败：{str(e)}", exc_info=True)
            job_log_service.add_end_log(task_id, run_status=500, fail_msg=str(e)+"\n"+traceback.format_exc())

    return wrapper