from allianceauth.services.hooks import get_extension_logger
from django.shortcuts import render, redirect
from django.views.generic import TemplateView
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from .permissions import PERMISSION_CAN_MANAGE
from .forms import AddBrForm
from .models.filterentities import FilterEntity
from .models.battlereport import BattleReport
from .models.killmails import KillCompensation
from .models.charmail import CharMailParse
from eveuniverse.models import EveEntity
from allianceauth.framework.api.user import get_main_character_from_user
from django.utils.decorators import method_decorator
from esi.decorators import tokens_required
from django.conf import settings
from django.utils.translation import gettext as _
from django.db.models import Q
from django.db.models import Sum

logger = get_extension_logger(__name__)

@method_decorator(tokens_required(scopes="esi-mail.read_mail.v1 esi-mail.send_mail.v1 esi-ui.open_window.v1"), name="dispatch")
class DashboardView(LoginRequiredMixin, PermissionRequiredMixin,TemplateView): 
    template_name = 'br_compensations/dashboard.html'
    permission_required = f'br_compensations.{PERMISSION_CAN_MANAGE}'
    
    
    def get_context_data(self, filter=None, **kwargs):
        context = super().get_context_data(**kwargs)

        character = get_main_character_from_user(self.request.user)
        
        # Получаем параметр сортировки из GET запроса
        sort_by = self.request.GET.get('sort', '-created_at')
        context['current_sort'] = sort_by
        
        data = []
        dbFilters = FilterEntity.objects.all()
            
        for f in dbFilters:
            entry_icon = ""
            match f.entity_type:
                case FilterEntity.ALLIANCE:
                    entry_icon = f"https://images.evetech.net/alliances/{f.entity_id}/logo?size=32"
                case FilterEntity.CORPORATION:
                    entry_icon = f"https://images.evetech.net/corporations/{f.entity_id}/logo?size=32"
                case FilterEntity.CHARACTER:
                    entry_icon = f"https://images.evetech.net/characters/{f.entity_id}/portrait?size=32"
                case _:
                    entry_icon = ''
            
            try:
                #entry = EveEntity.objects.get(id=f.entity_id)
                
                data.append({
                    'filter': {
                        'id': f.entity_id,
                        'type': f.entity_type,
                        },
                    'display_name': f.name,
                    "icon": entry_icon
                })
            except Exception as e:
                logger.error(f"Ошибка при поиске в ESI: {e}")
                try:
                    EveEntity.objects.resolve_name(id=f.entity_id)
                    entry = EveEntity.objects.get(id=f.entity_id)
                
                    data.append({
                        'filter': {
                            'id': f.entity_id,
                            'type': f.entity_type,
                            },
                        'display_name': entry.name,
                        "icon": entry_icon
                    })
                except Exception as e:
                    logger.error(f"Ошибка при поиске в eve universe: {e}")
            
        match filter:
            case 'rejected':
                kills = KillCompensation.objects.filter(status = KillCompensation.STATUS_REJECT).all()
                context['listTitle'] = _('Отмененные компенсации')
            case 'accepted':
                kills = KillCompensation.objects.filter(status = KillCompensation.STATUS_COMPLETE).all()
                context['listTitle'] = _('Выполненные компенсации')
            case 'all':
                kills = KillCompensation.objects.all()
                context['listTitle'] = _('Все компенсации')
            case BattleReport.BATTLEREPORT:
                kills = KillCompensation.objects.filter(source__report_type = BattleReport.BATTLEREPORT, status = KillCompensation.STATUS_NEW).all()
                context['listTitle'] = _('Баттл репорты')
            case BattleReport.KILLMAIL:
                kills = KillCompensation.objects.filter(source__report_type = BattleReport.KILLMAIL, status = KillCompensation.STATUS_NEW).all()
                context['listTitle'] = _('Киллмэйл')
            case _:
                kills = KillCompensation.objects.filter(status = KillCompensation.STATUS_NEW).all()
                context['listTitle'] = _('Текущие компенсации')
        
        context["data"] = sorted(data, key=lambda filter: filter['display_name'])
        context["total_loss"] = kills.aggregate(Sum('loss_value'))['loss_value__sum']
        
        # Применяем сортировку к полному набору данных
        valid_sort_fields = {
            'character_name': 'character_name',
            '-character_name': '-character_name',
            'status': 'status',
            '-status': '-status',
            'loss_value': 'loss_value',
            '-loss_value': '-loss_value',
            'timestamp': 'timestamp',
            '-timestamp': '-timestamp',
            'created_at': 'created_at',
            '-created_at': '-created_at',
        }
        
        if sort_by in valid_sort_fields:
            kills_queryset = kills.order_by(valid_sort_fields[sort_by])
        else:
            kills_queryset = kills.order_by('-created_at', 'status', 'timestamp', '-loss_value')
        
        # Пагинация для killmails
        page_size = 20
        page = self.request.GET.get('page', 1)
        paginator = Paginator(kills_queryset, page_size)
        
        try:
            killmails_page = paginator.page(page)
        except PageNotAnInteger:
            killmails_page = paginator.page(1)
        except EmptyPage:
            killmails_page = paginator.page(paginator.num_pages)
        
        context["killmails"] = killmails_page
        context["is_paginated"] = paginator.num_pages > 1
        context["page_obj"] = killmails_page
        context["paginator"] = paginator
        
        context["mailparser"] = CharMailParse.objects.get(character_id=character.character_id) if character and CharMailParse.objects.filter(character_id = character.character_id).exists() else None
        context["parse_check"] = 'checked' if context['mailparser'] is not None else ''
        context["character_id"] = character.character_id
        context["show_api"] = settings.DEBUG
        
        return context
    
    def post(self, request, *args, **kwargs):
        """
        Обрабатывает POST запросы (например, после выбора персонажа).
        Перенаправляем на GET запрос той же страницы.
        """
        filter_param = kwargs.get('filter', None)
        if filter_param:
            return redirect(f"/br_compensations/dashboard/{filter_param}/")
        return redirect('/br_compensations/dashboard/')


class BattleReportsView(LoginRequiredMixin,PermissionRequiredMixin, TemplateView):
    template_name="br_compensations/reports.html"
    permission_required = f'br_compensations.{PERMISSION_CAN_MANAGE}'
    
    def get_context_data(self, filter:str = None, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Получаем параметр сортировки из GET запроса
        sort_by = self.request.GET.get('sort', '-added_at')
        context['current_sort'] = sort_by
        
        match filter:
            case 'complete':
                reports_queryset = BattleReport.objects.filter(status = BattleReport.PROCESS_COMPLETE)
            case 'failed':
                reports_queryset = BattleReport.objects.filter(status = BattleReport.PROCESS_FAILED)
            case 'all':
                reports_queryset = BattleReport.objects.all()
            case _:
                reports_queryset = BattleReport.objects.filter(Q(status = BattleReport.PROCESS_NEW)|Q(status = BattleReport.PROCESS_PROCESSING)|Q(status = BattleReport.PROCESS_REINITIALIZE))
        
        # Применяем сортировку к полному набору данных
        valid_sort_fields = {
            'report_type': 'report_type',
            '-report_type': '-report_type',
            'uid': 'uid',
            '-uid': '-uid',
            'updatedAt': 'updatedAt',
            '-updatedAt': '-updatedAt',
            'comment': 'comment',
            '-comment': '-comment',
            'status': 'status',
            '-status': '-status',
            'added_at': 'added_at',
            '-added_at': '-added_at',
        }
        
        if sort_by in valid_sort_fields:
            reports_queryset = reports_queryset.order_by(valid_sort_fields[sort_by])
        else:
            reports_queryset = reports_queryset.order_by('-added_at', '-updatedAt')
        
        # Пагинация для reports
        page_size = 20
        page = self.request.GET.get('page', 1)
        paginator = Paginator(reports_queryset, page_size)
        
        try:
            reports_page = paginator.page(page)
        except PageNotAnInteger:
            reports_page = paginator.page(1)
        except EmptyPage:
            reports_page = paginator.page(paginator.num_pages)
        
        context["reports"] = reports_page
        context["is_paginated"] = paginator.num_pages > 1
        context["page_obj"] = reports_page
        context["paginator"] = paginator
        context["form"] = AddBrForm()
        context["show_api"] = False
        return context
    
    def post(self,request):
        brForm = AddBrForm(request.POST)
        if brForm.is_valid():
            report = BattleReport(link = brForm.cleaned_data['link'], comment = brForm.cleaned_data['comment'])
            report.save()
            return redirect('/br_compensations/reports/')
        return render(request,'/br_compensations/reports.html',{"form":brForm, "reports": BattleReport.objects.all()})

    
dashboard = DashboardView.as_view()
reports = BattleReportsView.as_view()