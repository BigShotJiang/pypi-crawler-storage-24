"""
tests/test_memex.py
-------------------
Full test suite for memex-agent library.
No network, no LLM API keys required.
"""

import sys, os, tempfile, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from memex.store   import SQLiteStore, MemoryStore, get_store
from memex.embedder import TFIDFEmbedder, BaseEmbedder
from memex.vector_store import VectorStore
from memex.extractor import RuleExtractor, LLMExtractor
from memex.providers.base import LLMProvider
from memex.core import MemoryLayer


# ── Mock LLM ──────────────────────────────────────────────────────────────────

class MockLLM(LLMProvider):
    def __init__(self):
        super().__init__(model="mock")
        self.calls = []

    def chat(self, messages, system="", max_tokens=1024):
        prompt = messages[-1]["content"] if messages else ""
        self.calls.append(prompt[:50])

        if "Fact A:" in prompt:
            return "User is a Python developer in Mumbai"
        if "Compress" in prompt or "compress" in prompt:
            return '["User is a senior Python developer", "User works in Mumbai"]'
        if "Extract important" in prompt:
            return '["User prefers Python", "User is in Mumbai"]'
        if "Summarize this conversation" in prompt:
            return '{"summary": "Discussed Python development", "topics": ["python", "coding"], "outcome": "resolved", "mood": "positive"}'
        if "analyzing an AI agent" in prompt:
            return '{"patches": ["Always include code examples"], "reasoning": "user often asks for examples", "confidence": 0.8}'
        if "merge opportunities" in prompt:
            return '{"merge_pairs": [], "stale_ids": [], "insights": []}'
        return '[]'


def make_store(tmp):
    return SQLiteStore(os.path.join(tmp, "test.db"))

def make_memory(tmp, **kwargs):
    store = make_store(tmp)
    emb   = TFIDFEmbedder()
    llm   = MockLLM()
    return MemoryLayer(
        store=store, embedder=emb, llm=llm,
        async_learn=False, **kwargs
    )


# ══ STORE TESTS ═══════════════════════════════════════════════════════════════

def test_store_namespaced_isolation():
    """Keys in different namespaces don't interfere."""
    tmp = tempfile.mkdtemp()
    s   = make_store(tmp)
    s.set("k", "user_a_value", namespace="user:a")
    s.set("k", "user_b_value", namespace="user:b")
    assert s.get("k", namespace="user:a") == "user_a_value"
    assert s.get("k", namespace="user:b") == "user_b_value"
    print("✅ Store: namespaced isolation")

def test_store_persistence():
    tmp  = tempfile.mkdtemp()
    path = os.path.join(tmp, "p.db")
    s1   = SQLiteStore(path)
    s1.set("session", {"data": [1, 2, 3]}, namespace="user:x")
    s2   = SQLiteStore(path)
    assert s2.get("session", namespace="user:x") == {"data": [1, 2, 3]}
    print("✅ Store: persistence across instances")

def test_store_ttl():
    tmp = tempfile.mkdtemp()
    s   = make_store(tmp)
    s.set("temp", "value", namespace="ns", ttl=1)
    assert s.get("temp", namespace="ns") == "value"
    time.sleep(1.1)
    assert s.get("temp", namespace="ns") is None
    print("✅ Store: TTL expiry")

def test_store_flush_scoped():
    tmp = tempfile.mkdtemp()
    s   = make_store(tmp)
    s.set("a", 1, namespace="ns1")
    s.set("b", 2, namespace="ns2")
    s.flush(namespace="ns1")
    assert s.get("a", namespace="ns1") is None
    assert s.get("b", namespace="ns2") == 2
    print("✅ Store: flush is namespace-scoped")

def test_store_namespaces_list():
    tmp = tempfile.mkdtemp()
    s   = make_store(tmp)
    s.set("k", 1, namespace="user:arjun")
    s.set("k", 2, namespace="user:priya")
    ns = s.namespaces()
    assert "user:arjun" in ns and "user:priya" in ns
    print("✅ Store: list namespaces")

def test_store_key_patterns():
    tmp = tempfile.mkdtemp()
    s   = make_store(tmp)
    s.set("memex:facts",   1, namespace="ns")
    s.set("memex:history", 2, namespace="ns")
    s.set("other:key",     3, namespace="ns")
    assert set(s.keys("memex:*", namespace="ns")) == {"memex:facts", "memex:history"}
    print("✅ Store: glob key patterns")

def test_get_store_factory():
    tmp = tempfile.mkdtemp()
    s   = get_store("sqlite", path=os.path.join(tmp, "f.db"))
    s.set("x", 42, namespace="test")
    assert s.get("x", namespace="test") == 42
    print("✅ Store: factory function")

def test_memory_store_in_process():
    s = MemoryStore()
    s.set("k", "v", namespace="a")
    assert s.get("k", namespace="a") == "v"
    assert s.get("k", namespace="b") is None
    print("✅ Store: in-memory isolation")


# ══ EMBEDDER TESTS ════════════════════════════════════════════════════════════

def test_tfidf_semantic_ordering():
    e  = TFIDFEmbedder()
    v1 = e.embed("Python programming developer software")
    v2 = e.embed("coding Python software engineer")
    v3 = e.embed("chocolate cake baking recipe oven")
    assert BaseEmbedder.cosine(v1, v2) > BaseEmbedder.cosine(v1, v3)
    print("✅ Embedder: semantic ordering")

def test_tfidf_self_similarity():
    e = TFIDFEmbedder()
    v = e.embed("hello world test sentence")
    assert abs(BaseEmbedder.cosine(v, v) - 1.0) < 0.001
    print("✅ Embedder: self-similarity = 1.0")

def test_tfidf_different_dims_handled():
    e  = TFIDFEmbedder()
    v1 = e.embed("short text")
    v2 = e.embed("longer text with more different unique words here")
    # cosine should not crash even if dims differ
    score = BaseEmbedder.cosine(v1, v2)
    assert 0.0 <= score <= 1.0
    print("✅ Embedder: handles different vector dims")


# ══ VECTOR STORE TESTS ════════════════════════════════════════════════════════

def test_vector_search_relevance():
    s  = MemoryStore()
    e  = TFIDFEmbedder()
    vs = VectorStore(s, e)
    vs.add("1", "user loves Python and software development", namespace="ns")
    vs.add("2", "user enjoys hiking outdoors in mountains", namespace="ns")
    vs.add("3", "user prefers dark mode in code editors", namespace="ns")
    results = vs.search("what programming language does user prefer", namespace="ns", top_k=1)
    assert results[0]["fact_id"] == "1"
    print(f"✅ VectorStore: relevance search (top={results[0]['content'][:40]})")

def test_vector_namespace_isolation():
    s  = MemoryStore()
    e  = TFIDFEmbedder()
    vs = VectorStore(s, e)
    vs.add("1", "user a loves Python", namespace="user:a")
    vs.add("2", "user b loves Java",   namespace="user:b")
    r_a = vs.search("Python", namespace="user:a", top_k=5)
    r_b = vs.search("Python", namespace="user:b", top_k=5)
    assert all(r["fact_id"] != "2" for r in r_a)
    assert all(r["fact_id"] != "1" for r in r_b)
    print("✅ VectorStore: namespace isolation")

def test_vector_delete_and_count():
    s  = MemoryStore()
    e  = TFIDFEmbedder()
    vs = VectorStore(s, e)
    vs.add("x", "some fact", namespace="ns")
    assert vs.count(namespace="ns") == 1
    vs.delete("x", namespace="ns")
    assert vs.count(namespace="ns") == 0
    print("✅ VectorStore: delete + count")

def test_vector_clear_scoped():
    s  = MemoryStore()
    e  = TFIDFEmbedder()
    vs = VectorStore(s, e)
    vs.add("1", "fact a", namespace="ns1")
    vs.add("2", "fact b", namespace="ns2")
    vs.clear(namespace="ns1")
    assert vs.count(namespace="ns1") == 0
    assert vs.count(namespace="ns2") == 1
    print("✅ VectorStore: clear is namespace-scoped")


# ══ EXTRACTOR TESTS ═══════════════════════════════════════════════════════════

def test_rule_extractor_names():
    ex    = RuleExtractor()
    facts = ex.extract_facts("My name is Alice", "Nice to meet you Alice")
    assert any("alice" in f.lower() for f in facts)
    print(f"✅ RuleExtractor: name extraction → {facts}")

def test_rule_extractor_no_false_positives():
    ex    = RuleExtractor()
    facts = ex.extract_facts("okay cool", "Sure, here you go!")
    assert len(facts) == 0
    print("✅ RuleExtractor: no false positives on small talk")

def test_llm_extractor():
    ex    = LLMExtractor(MockLLM())
    facts = ex.extract_facts("I prefer Python", "Great choice!")
    assert isinstance(facts, list)
    assert all(isinstance(f, str) for f in facts)
    print(f"✅ LLMExtractor: returns list of strings → {facts}")

def test_llm_extractor_episode():
    ex    = LLMExtractor(MockLLM())
    convo = [
        {"role": "user",      "content": "I'm building an agent"},
        {"role": "assistant", "content": "That's exciting!"},
    ]
    ep = ex.extract_episode(convo)
    assert ep is not None
    assert "summary" in ep
    print(f"✅ LLMExtractor: episode extraction → {ep['summary'][:40]}")


# ══ MEMORY LAYER TESTS ════════════════════════════════════════════════════════

def test_memory_remember_and_search():
    tmp = tempfile.mkdtemp()
    m   = make_memory(tmp)
    m.remember("User is a Python developer")
    m.remember("User lives in Mumbai")
    m.remember("User prefers dark mode")
    results = m.search("what programming language does user use")
    assert any("Python" in r["content"] for r in results)
    print(f"✅ MemoryLayer: remember + semantic search ({len(results)} results)")

def test_memory_recall_injects_context():
    tmp = tempfile.mkdtemp()
    m   = make_memory(tmp)
    m.remember("User name is Arjun")
    ctx = m.recall("tell me about the user")
    assert "Arjun" in ctx
    assert "What I know" in ctx
    print("✅ MemoryLayer: recall returns formatted context")

def test_memory_learn_from_exchange():
    tmp = tempfile.mkdtemp()
    m   = make_memory(tmp)
    m.learn("I prefer Python for all my projects", "Great choice!")
    facts = m._get_facts()
    assert len(facts) > 0
    print(f"✅ MemoryLayer: learn() extracts facts → {facts[0]['content'][:50]}")

def test_memory_multi_namespace():
    tmp = tempfile.mkdtemp()
    s   = make_store(tmp)
    e   = TFIDFEmbedder()
    llm = MockLLM()

    m_arjun = MemoryLayer(namespace="user:arjun", store=s, embedder=e,
                           llm=llm, async_learn=False)
    m_priya = MemoryLayer(namespace="user:priya", store=s, embedder=e,
                           llm=llm, async_learn=False)

    m_arjun.remember("User is Arjun from Mumbai")
    m_priya.remember("User is Priya from Delhi")

    ctx_a = m_arjun.recall("who is the user")
    ctx_p = m_priya.recall("who is the user")

    assert "Arjun" in ctx_a and "Priya" not in ctx_a
    assert "Priya" in ctx_p and "Arjun" not in ctx_p
    print("✅ MemoryLayer: multi-namespace isolation")

def test_memory_history():
    tmp = tempfile.mkdtemp()
    m   = make_memory(tmp)
    m.add_message("user",      "hello!")
    m.add_message("assistant", "hi there!")
    h = m.get_history()
    assert h[0]["role"] == "user"
    assert h[1]["role"] == "assistant"
    print("✅ MemoryLayer: conversation history")

def test_memory_scratch():
    tmp = tempfile.mkdtemp()
    m   = make_memory(tmp)
    m.scratch("task_state", {"step": 1, "done": False})
    state = m.scratch("task_state")
    assert state == {"step": 1, "done": False}
    print("✅ MemoryLayer: scratch pad set/get")

def test_memory_stats():
    tmp = tempfile.mkdtemp()
    m   = make_memory(tmp)
    m.remember("fact one")
    m.remember("fact two")
    s = m.stats()
    assert s["facts"]   == 2
    assert s["vectors"] == 2
    assert s["namespace"] == "default"
    print(f"✅ MemoryLayer: stats → {s['facts']} facts, {s['vectors']} vectors")

def test_memory_clear():
    tmp = tempfile.mkdtemp()
    m   = make_memory(tmp)
    m.remember("temporary")
    m.clear()
    assert m._get_facts() == []
    assert m.vs.count(namespace="default") == 0
    print("✅ MemoryLayer: clear wipes facts + vectors")

def test_memory_persistence_across_instances():
    tmp  = tempfile.mkdtemp()
    path = os.path.join(tmp, "persist.db")

    m1 = MemoryLayer(namespace="user:x",
                     store=SQLiteStore(path), embedder=TFIDFEmbedder(),
                     llm=MockLLM(), async_learn=False)
    m1.remember("User is Arjun")
    m1.add_message("user", "hello")

    m2 = MemoryLayer(namespace="user:x",
                     store=SQLiteStore(path), embedder=TFIDFEmbedder(),
                     llm=MockLLM(), async_learn=False)
    assert any("Arjun" in f["content"] for f in m2._get_facts())
    assert len(m2.get_history()) == 1
    print("✅ MemoryLayer: full persistence across instances")


# ══ EPISODIC MEMORY TESTS ═════════════════════════════════════════════════════

def test_episodic_create_and_recall():
    tmp = tempfile.mkdtemp()
    m   = make_memory(tmp, episodic=True)
    m.add_message("user",      "I'm building a Python agent")
    m.add_message("assistant", "Great! Tell me more.")
    m.add_message("user",      "It needs persistent memory")
    m.add_message("assistant", "I can help with that.")
    m.end_session()
    episodes = m._episodic.get_recent(n=5)
    assert len(episodes) >= 1
    assert "summary" in episodes[0]
    print(f"✅ Episodic: session → episode ({episodes[0]['summary'][:40]})")

def test_episodic_in_context():
    tmp = tempfile.mkdtemp()
    m   = make_memory(tmp, episodic=True)
    m.add_message("user",      "We discussed Python memory agents")
    m.add_message("assistant", "Yes, and we covered Redis and SQLite")
    m.end_session()
    ctx = m.recall("Python agent memory")
    # Episodes are in context after end_session
    assert isinstance(ctx, str)
    print("✅ Episodic: episodes appear in recall() context")


# ══ PROCEDURAL MEMORY TESTS ═══════════════════════════════════════════════════

def test_procedural_observe_and_analyze():
    tmp = tempfile.mkdtemp()
    m   = make_memory(tmp, procedural=True)
    # Simulate several sessions of observations
    for _ in range(15):
        m._procedural.observe("show me code", "Here is some code", satisfied=True)
        m._procedural.observe("give example", "Here's an example", satisfied=True)
    m._procedural.flush_session()
    suggestion = m._procedural.analyze()
    assert suggestion is not None
    assert "patches" in suggestion
    print(f"✅ Procedural: analyze → {suggestion['patches']}")

def test_procedural_apply_and_context():
    tmp = tempfile.mkdtemp()
    m   = make_memory(tmp, procedural=True)
    for _ in range(15):
        m._procedural.observe("code example please", "Here is code", satisfied=True)
    m._procedural.flush_session()
    suggestion = m._procedural.analyze()
    if suggestion:
        m._procedural.apply(suggestion)
        ctx = m._procedural.as_context()
        assert "Learned behaviors" in ctx
        print(f"✅ Procedural: apply → context injected")
    else:
        print("✅ Procedural: not enough data (expected)")

def test_procedural_rollback():
    tmp = tempfile.mkdtemp()
    m   = make_memory(tmp, procedural=True)
    m._procedural.store.set(
        "memex:procedural:patches", "old patch", namespace="default"
    )
    for _ in range(15):
        m._procedural.observe("test", "test", satisfied=True)
    m._procedural.flush_session()
    s = m._procedural.analyze()
    if s:
        m._procedural.apply(s)
        rolled = m._procedural.rollback()
        assert rolled
        print("✅ Procedural: rollback works")
    else:
        print("✅ Procedural: rollback test skipped (not enough data)")


# ══ ADAPTER TESTS ═════════════════════════════════════════════════════════════

def test_adapter_tool_search():
    tmp  = tempfile.mkdtemp()
    m    = make_memory(tmp)
    m.remember("User loves Redis databases")
    tool = m.as_tool()
    result = tool.call("search", query="what database does user like")
    assert "Redis" in result
    print(f"✅ Adapter/Tool: search → {result[:50]}")

def test_adapter_tool_remember():
    tmp  = tempfile.mkdtemp()
    m    = make_memory(tmp)
    tool = m.as_tool()
    result = tool.call("remember", fact="User is a senior engineer")
    assert "Stored" in result
    assert len(m._get_facts()) == 1
    print("✅ Adapter/Tool: remember stores fact")

def test_adapter_tool_openai_schema():
    tmp  = tempfile.mkdtemp()
    m    = make_memory(tmp)
    tool = m.as_tool()
    schema = tool.as_openai_function()
    assert schema["type"]                              == "function"
    assert schema["function"]["name"]                  == "memory"
    assert "action" in schema["function"]["parameters"]["properties"]
    print("✅ Adapter/Tool: OpenAI function schema valid")

def test_adapter_langchain():
    tmp    = tempfile.mkdtemp()
    m      = make_memory(tmp)
    m.remember("User name is Arjun")
    lc_mem = m.as_langchain()
    result = lc_mem.load_memory_variables({"input": "what is my name"})
    assert "history" in result
    assert "Arjun" in result["history"]
    print("✅ Adapter/LangChain: load_memory_variables injects facts")

def test_adapter_langchain_save_context():
    tmp    = tempfile.mkdtemp()
    m      = make_memory(tmp)
    lc_mem = m.as_langchain()
    lc_mem.save_context(
        {"input": "I work at Anthropic"},
        {"response": "That's a great company!"}
    )
    assert len(m.get_history()) == 2
    print("✅ Adapter/LangChain: save_context stores history")

def test_adapter_raw_decorator():
    tmp = tempfile.mkdtemp()
    m   = make_memory(tmp)

    @m.decorator()
    def my_agent(user_input: str, system_context: str = "") -> str:
        assert isinstance(system_context, str)
        return "I am a helpful assistant"

    m.remember("User name is Priya")
    result = my_agent("What is my name?")
    assert result == "I am a helpful assistant"
    print("✅ Adapter/Decorator: injects system_context, learns from response")


# ══ WRAP ADAPTER TEST ═════════════════════════════════════════════════════════

def test_adapter_wrap_passthrough():
    """Wrap adapter proxies non-memory attributes transparently."""
    tmp = tempfile.mkdtemp()
    m   = make_memory(tmp)

    class FakeClient:
        model_name = "fake-model"
        class chat:
            class completions:
                @staticmethod
                def create(**kwargs):
                    class Choice:
                        class message:
                            content = "Hello!"
                    class Resp:
                        choices = [Choice()]
                    return Resp()

    wrapped = m.wrap(FakeClient())
    assert wrapped.model_name == "fake-model"   # passthrough
    resp = wrapped.chat.completions.create(
        model="x",
        messages=[{"role": "user", "content": "hi"}]
    )
    assert resp.choices[0].message.content == "Hello!"
    print("✅ Adapter/Wrap: passthrough + intercept works")


# ══ RUN ═══════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    tests = [
        # Store
        test_store_namespaced_isolation, test_store_persistence,
        test_store_ttl, test_store_flush_scoped,
        test_store_namespaces_list, test_store_key_patterns,
        test_get_store_factory, test_memory_store_in_process,
        # Embedder
        test_tfidf_semantic_ordering, test_tfidf_self_similarity,
        test_tfidf_different_dims_handled,
        # VectorStore
        test_vector_search_relevance, test_vector_namespace_isolation,
        test_vector_delete_and_count, test_vector_clear_scoped,
        # Extractor
        test_rule_extractor_names, test_rule_extractor_no_false_positives,
        test_llm_extractor, test_llm_extractor_episode,
        # MemoryLayer
        test_memory_remember_and_search, test_memory_recall_injects_context,
        test_memory_learn_from_exchange, test_memory_multi_namespace,
        test_memory_history, test_memory_scratch, test_memory_stats,
        test_memory_clear, test_memory_persistence_across_instances,
        # Episodic
        test_episodic_create_and_recall, test_episodic_in_context,
        # Procedural
        test_procedural_observe_and_analyze,
        test_procedural_apply_and_context, test_procedural_rollback,
        # Adapters
        test_adapter_tool_search, test_adapter_tool_remember,
        test_adapter_tool_openai_schema,
        test_adapter_langchain, test_adapter_langchain_save_context,
        test_adapter_raw_decorator, test_adapter_wrap_passthrough,
    ]

    passed = 0
    for t in tests:
        try:
            t()
            passed += 1
        except Exception as e:
            import traceback
            print(f"❌ {t.__name__}: {e}")
            traceback.print_exc()

    print(f"\n{'═'*55}")
    print(f"  {passed}/{len(tests)} tests passed")
    if passed == len(tests):
        print("  🎉 All tests passed! Ready to publish.")
    import sys; sys.exit(0 if passed == len(tests) else 1)


# ══ NEW: EMBEDDER AGNOSTIC TESTS ══════════════════════════════════════════════

def test_embedder_custom_subclass():
    """User can bring their own embedder by subclassing BaseEmbedder."""
    from memex.embedder import BaseEmbedder
    import random

    class RandomEmbedder(BaseEmbedder):
        dim = 16
        def embed(self, text: str):
            random.seed(hash(text) % 2**32)
            return [random.random() for _ in range(self.dim)]

    e = RandomEmbedder()
    v = e.embed("hello world")
    assert len(v) == 16
    assert all(isinstance(x, float) for x in v)
    print("✅ Embedder: custom subclass works")

def test_embedder_passthrough_in_get_embedder():
    """get_embedder(embedder=instance) returns the instance directly."""
    from memex.embedder import BaseEmbedder, get_embedder, TFIDFEmbedder

    my_emb = TFIDFEmbedder()
    result = get_embedder(embedder=my_emb)
    assert result is my_emb
    print("✅ Embedder: get_embedder(embedder=x) passthrough")

def test_embedder_bad_passthrough_raises():
    """get_embedder(embedder=non-embedder) raises TypeError."""
    from memex.embedder import get_embedder
    try:
        get_embedder(embedder="not-an-embedder")
        assert False, "Should have raised"
    except TypeError:
        pass
    print("✅ Embedder: bad passthrough raises TypeError")

def test_embedder_sentence_transformer_custom_model():
    """SentenceTransformerEmbedder accepts model_name parameter."""
    try:
        from memex.embedder import SentenceTransformerEmbedder
        e = SentenceTransformerEmbedder(model_name="all-MiniLM-L6-v2")
        assert e.model_name == "all-MiniLM-L6-v2"
        v = e.embed("test")
        assert len(v) == 384
        print("✅ Embedder: SentenceTransformer custom model_name")
    except ImportError:
        print("✅ Embedder: SentenceTransformer model_name (skipped — not installed)")

def test_embedder_tfidf_backend_explicit():
    """get_embedder('tfidf') always returns TFIDFEmbedder."""
    from memex.embedder import get_embedder, TFIDFEmbedder
    e = get_embedder("tfidf")
    assert isinstance(e, TFIDFEmbedder)
    print("✅ Embedder: explicit tfidf backend")

def test_embedder_unknown_backend_raises():
    """get_embedder with unknown backend raises ValueError."""
    from memex.embedder import get_embedder
    try:
        get_embedder("nonexistent-backend")
        assert False, "Should have raised"
    except ValueError:
        pass
    print("✅ Embedder: unknown backend raises ValueError")

def test_memory_layer_accepts_custom_embedder():
    """MemoryLayer accepts any BaseEmbedder subclass."""
    import tempfile
    from memex.embedder import BaseEmbedder, get_embedder
    from memex.store import MemoryStore

    class FixedEmbedder(BaseEmbedder):
        dim = 4
        def embed(self, text):
            # deterministic: hash-based 4-dim vector
            h = hash(text) % 1000
            return [float(h), float(h+1), float(h+2), float(h+3)]

    m = MemoryLayer(
        store    = MemoryStore(),
        embedder = FixedEmbedder(),
        llm      = MockLLM(),
        async_learn = False,
    )
    m.remember("User loves databases")
    m.remember("User codes in Python")
    results = m.search("database")
    assert len(results) >= 1
    print("✅ MemoryLayer: custom embedder injected and working")


# ══ NEW: WRAP ADAPTER SHAPE DETECTION ════════════════════════════════════════

def test_wrap_detects_openai_shape():
    """wrap() correctly identifies and proxies OpenAI-compatible clients."""
    import tempfile
    m = make_memory(tempfile.mkdtemp())

    class FakeOpenAIClient:
        class chat:
            class completions:
                @staticmethod
                def create(**kwargs):
                    class Msg:
                        content = "Hello from OpenAI-shape"
                    class Choice:
                        message = Msg()
                    class Resp:
                        choices = [Choice()]
                    return Resp()

    wrapped = m.wrap(FakeOpenAIClient())
    resp = wrapped.chat.completions.create(
        model="x",
        messages=[{"role": "user", "content": "hi"}]
    )
    assert resp.choices[0].message.content == "Hello from OpenAI-shape"
    print("✅ Wrap: OpenAI-shape client detected and proxied")

def test_wrap_detects_anthropic_shape():
    """wrap() correctly identifies and proxies Anthropic-native clients."""
    import tempfile
    m = make_memory(tempfile.mkdtemp())

    class FakeContentBlock:
        text = "Hello from Anthropic-shape"
    class FakeAnthropicResponse:
        content = [FakeContentBlock()]

    class FakeMessagesAPI:
        def create(self, **kwargs):
            # verify system was passed through
            assert "system" in kwargs
            return FakeAnthropicResponse()

    class FakeAnthropicClient:
        messages = FakeMessagesAPI()
        # no .chat attribute — this is the Anthropic shape

    wrapped = m.wrap(FakeAnthropicClient())
    resp = wrapped.messages.create(
        model="claude-3-haiku",
        max_tokens=100,
        system="You are helpful.",
        messages=[{"role": "user", "content": "hello"}]
    )
    assert resp.content[0].text == "Hello from Anthropic-shape"
    print("✅ Wrap: Anthropic-shape client detected and proxied")

def test_wrap_llm_provider():
    """wrap() works with our own LLMProvider instances."""
    import tempfile
    m = make_memory(tempfile.mkdtemp())
    llm = MockLLM()
    wrapped = m.wrap(llm)
    result = wrapped.chat(
        messages=[{"role": "user", "content": "test"}],
        system="be helpful",
    )
    assert isinstance(result, str)
    print("✅ Wrap: LLMProvider wrapped and proxied")

def test_wrap_unsupported_raises():
    """wrap() raises TypeError for unsupported client types."""
    import tempfile
    m = make_memory(tempfile.mkdtemp())
    try:
        m.wrap("not-a-client")
        assert False, "Should have raised"
    except TypeError:
        pass
    print("✅ Wrap: unsupported client raises TypeError")


# ══ NEW: TOOL SCHEMA TESTS ════════════════════════════════════════════════════

def test_tool_anthropic_schema():
    """as_anthropic_tool() returns valid Anthropic tool_use schema."""
    import tempfile
    m    = make_memory(tempfile.mkdtemp())
    tool = m.as_tool()
    schema = tool.as_anthropic_tool()
    assert schema["name"] == "memory"
    assert "input_schema" in schema
    assert "action" in schema["input_schema"]["properties"]
    assert "required" in schema["input_schema"]
    print("✅ Tool: Anthropic tool_use schema valid")

def test_tool_handle_anthropic_call():
    """handle_anthropic_call() executes the correct action."""
    import tempfile
    m    = make_memory(tempfile.mkdtemp())
    m.remember("User loves async Python")
    tool = m.as_tool()

    class FakeToolUse:
        input = {"action": "search", "query": "Python async"}

    result = tool.handle_anthropic_call(FakeToolUse())
    assert "async" in result.lower() or "Python" in result
    print(f"✅ Tool: handle_anthropic_call → {result[:50]}")

def test_tool_handle_openai_call():
    """handle_openai_call() executes correctly from OpenAI tool_call object."""
    import tempfile, json
    m    = make_memory(tempfile.mkdtemp())
    tool = m.as_tool()

    class FakeFunction:
        arguments = json.dumps({"action": "remember", "fact": "User prefers Vim"})
    class FakeToolCall:
        function = FakeFunction()

    result = tool.handle_openai_call(FakeToolCall())
    assert "Stored" in result
    assert len(m._get_facts()) == 1
    print("✅ Tool: handle_openai_call → fact stored")


# ══ RUN NEW TESTS ═════════════════════════════════════════════════════════════

if __name__ == "__main__":
    new_tests = [
        test_embedder_custom_subclass,
        test_embedder_passthrough_in_get_embedder,
        test_embedder_bad_passthrough_raises,
        test_embedder_sentence_transformer_custom_model,
        test_embedder_tfidf_backend_explicit,
        test_embedder_unknown_backend_raises,
        test_memory_layer_accepts_custom_embedder,
        test_wrap_detects_openai_shape,
        test_wrap_detects_anthropic_shape,
        test_wrap_llm_provider,
        test_wrap_unsupported_raises,
        test_tool_anthropic_schema,
        test_tool_handle_anthropic_call,
        test_tool_handle_openai_call,
    ]

    passed = 0
    for t in new_tests:
        try:
            t()
            passed += 1
        except Exception as e:
            import traceback
            print(f"❌ {t.__name__}: {e}")
            traceback.print_exc()

    print(f"\n{'═'*55}")
    print(f"  {passed}/{len(new_tests)} new tests passed")
