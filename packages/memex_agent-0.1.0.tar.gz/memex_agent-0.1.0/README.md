# memex-agent

**Drop-in persistent memory for any Python AI agent.**  
Zero infrastructure. Any LLM. Any embedding model. Any framework. Own your data.

```bash
pip install memex-agent
```

---

## The problem

Every time your agent starts a new conversation, it forgets everything. Your users have to repeat themselves. Context is lost. The agent feels dumb.

Existing solutions (Mem0, LangMem) either require a managed cloud service, or spin up Qdrant + Neo4j + Postgres before you write a single line of code. And most are tightly coupled to one LLM provider or one framework.

**Memex fills the gap**: persistent memory that works out of the box, plugs into whatever you're already building, and stores data in a single SQLite file you own.

---

## Quickstart — three integration patterns

**Pattern 1 — Wrap your existing client (zero friction)**

```python
import openai
from memex import MemoryLayer

memory = MemoryLayer(namespace="user:arjun")
client = memory.wrap(openai.OpenAI())   # or anthropic.Anthropic(), or get_provider("ollama")

# Use exactly as before — memory is injected and learned automatically
response = client.chat.completions.create(
    model    = "gpt-4o-mini",
    messages = [{"role": "user", "content": "What's my name?"}]
)
```

**Pattern 2 — Before / After (full control)**

```python
memory = MemoryLayer()

ctx   = memory.recall(user_input)        # → formatted string, inject into system prompt
reply = your_llm(system + ctx, messages) # your LLM call, completely untouched
memory.learn(user_input, reply)           # extract + store facts, non-blocking
```

**Pattern 3 — Framework adapter**

```python
# LangChain — works with any LangChain LLM (ChatOpenAI, ChatAnthropic, Ollama, ...)
chain = ConversationChain(llm=your_llm, memory=memory.as_langchain())

# OpenAI function calling
tools = [memory.as_tool().as_openai_function()]

# Anthropic tool_use
tools = [memory.as_tool().as_anthropic_tool()]

# CrewAI
agent = Agent(role="assistant", tools=memory.as_tool().as_crewai())

# LlamaIndex
engine = ReActAgent.from_tools(memory.as_tool().as_llamaindex_tool())

# Plain function decorator
@memory.decorator()
def my_agent(user_input: str, system_context: str = "") -> str:
    return call_your_llm(system_context, user_input)
```

---

## What makes it truly agnostic

### LLM — bring any model

```python
from memex import MemoryLayer, get_provider

# Auto-detect from environment variables
memory = MemoryLayer()

# Explicit — any of these work identically
memory = MemoryLayer(llm=get_provider("anthropic",  model="claude-3-5-haiku-20241022"))
memory = MemoryLayer(llm=get_provider("openai",     model="gpt-4o-mini"))
memory = MemoryLayer(llm=get_provider("openrouter", model="google/gemini-flash-1.5"))
memory = MemoryLayer(llm=get_provider("ollama",     model="llama3.2"))       # local, free
memory = MemoryLayer(llm=get_provider("gemini",     model="gemini-1.5-flash"))

# Or implement your own provider — 4 lines
from memex import LLMProvider

class MyLLM(LLMProvider):
    def chat(self, messages, system="", max_tokens=1024) -> str:
        return my_custom_llm_call(system, messages)

memory = MemoryLayer(llm=MyLLM(model="my-model"))
```

Environment variable auto-detection order:
`ANTHROPIC_API_KEY` → `OPENROUTER_API_KEY` → `OPENAI_API_KEY` → `GEMINI_API_KEY` → Ollama (local)

### Embedding model — bring any embedder

```python
from memex import MemoryLayer, get_embedder

# Auto-detect: OpenAI key → Ollama → sentence-transformers → TF-IDF
memory = MemoryLayer()

# Explicit
memory = MemoryLayer(embedder=get_embedder("openai",               model="text-embedding-3-large"))
memory = MemoryLayer(embedder=get_embedder("ollama",               model="mxbai-embed-large"))     # local, free
memory = MemoryLayer(embedder=get_embedder("sentence-transformers", model="BAAI/bge-small-en-v1.5"))
memory = MemoryLayer(embedder=get_embedder("cohere",               model="embed-v4.0"))
memory = MemoryLayer(embedder=get_embedder("tfidf"))               # zero deps, always works

# Or implement your own — 3 lines
from memex import BaseEmbedder

class MyEmbedder(BaseEmbedder):
    dim = 1536
    def embed(self, text: str) -> list[float]:
        return my_embedding_api(text)

memory = MemoryLayer(embedder=MyEmbedder())
```

Embedding model comparison:

| Embedder | Dim | Cost | Quality | Setup |
|---|---|---|---|---|
| TF-IDF | variable | free | basic | zero deps |
| Ollama nomic-embed-text | 768 | free | good | `ollama pull nomic-embed-text` |
| sentence-transformers all-MiniLM | 384 | free | good | `pip install sentence-transformers` |
| sentence-transformers BAAI/bge-large | 1024 | free | great | `pip install sentence-transformers` |
| OpenAI text-embedding-3-small | 1536 | ~$0.02/1M tokens | great | `OPENAI_API_KEY` |
| OpenAI text-embedding-3-large | 3072 | ~$0.13/1M tokens | best | `OPENAI_API_KEY` |
| Cohere embed-v4.0 | 1024 | paid | great, multilingual | `COHERE_API_KEY` |

### Storage — bring any backend

```python
from memex import MemoryLayer, get_store

# Auto-detect: Redis if available → SQLite
memory = MemoryLayer()

# Explicit
memory = MemoryLayer(store=get_store("sqlite", path="./memory.db"))
memory = MemoryLayer(store=get_store("redis",  redis_url="redis://localhost:6379"))
memory = MemoryLayer(store=get_store("memory"))   # in-process, no persistence (testing)

# Or implement your own — subclass BaseStore (4 abstract methods)
from memex import BaseStore

class MyStore(BaseStore):
    def set(self, key, value, namespace="default", ttl=None): ...
    def get(self, key, namespace="default", default=None): ...
    def delete(self, key, namespace="default"): ...
    def keys(self, pattern="*", namespace="default"): ...
    def exists(self, key, namespace="default"): ...
    def flush(self, namespace="default"): ...
    def namespaces(self): ...
    def stats(self): ...
```

Storage backend comparison:

| Backend | Latency | Persistence | Vector search | Setup |
|---|---|---|---|---|
| SQLite (default) | ~1–3ms | ✅ single file | cosine scan | zero |
| SQLite + sqlite-vec | ~1–2ms | ✅ single file | ANN index | `pip install sqlite-vec` |
| Redis | <0.5ms | ✅ configurable | Redis-VSS (HNSW) | `redis-server` |
| Memory | <0.1ms | ❌ | cosine scan | zero (testing) |

### Agentic framework — plug into anything

```python
memory = MemoryLayer()

# OpenAI function calling
tools = [memory.as_tool().as_openai_function()]
result = memory.as_tool().handle_openai_call(tool_call)

# Anthropic tool_use
tools = [memory.as_tool().as_anthropic_tool()]
result = memory.as_tool().handle_anthropic_call(tool_use_block)

# LangChain (any LLM — ChatOpenAI, ChatAnthropic, ChatOllama, ...)
memory.as_langchain()    # → BaseChatMemory-compatible object

# CrewAI
memory.as_tool().as_crewai()         # → list of two Tool objects

# LlamaIndex
memory.as_tool().as_llamaindex_tool() # → list of FunctionTool objects

# Wrap any OpenAI-compatible client
memory.wrap(openai.OpenAI())
memory.wrap(together_client)
memory.wrap(litellm_client)

# Wrap Anthropic native SDK
memory.wrap(anthropic.Anthropic())

# Wrap our own providers
memory.wrap(get_provider("ollama"))

# Plain decorator — framework-free
@memory.decorator()
def my_agent(user_input: str, system_context: str = "") -> str: ...
```

---

## Memory types

All memory types are opt-in and independently toggleable:

```python
memory = MemoryLayer(
    namespace  = "user:arjun",
    semantic   = True,     # facts about the user (default on)
    episodic   = True,     # conversation summaries
    procedural = True,     # self-improving prompt patches
    background = True,     # background consolidation daemon
)
```

### Semantic memory (on by default)

Stores durable facts extracted from conversations. Semantically retrieved — only the most relevant facts are injected per turn. Context stays fixed-size regardless of how many facts accumulate.

```python
memory.remember("User is a Python developer in Mumbai")
memory.learn(user_msg, assistant_reply)   # passive extraction, non-blocking

ctx = memory.recall("what does the user work on?")
# → "## What I know about this user:\n  [a1b2] User is a Python developer..."
```

### Episodic memory

Summaries of past conversations — gives the agent a sense of history, not just facts.

```python
memory = MemoryLayer(episodic=True)

# ... conversation happens ...
memory.end_session()   # creates episode summary, stores it

# Next session: episodes automatically appear in recall()
ctx = memory.recall("async Python")
# → includes: "[2026-03-07] Debugged async issue, solved with asyncio.gather (outcome: resolved)"
```

### Procedural memory

The agent learns *how* to respond better over time. Tracks satisfaction signals, finds patterns, suggests system prompt improvements.

```python
memory = MemoryLayer(procedural=True)

# After several sessions:
suggestions = memory.suggest_prompt_improvements()
# → {"patches": ["Always include code examples"], "confidence": 0.85}

memory.apply_prompt_improvements(suggestions)  # developer reviews first
memory.rollback_prompt()                        # undo if things get worse
```

---

## Multi-user namespacing

One database, fully isolated per user and per agent:

```python
# Different users — completely isolated
mem_arjun = MemoryLayer(namespace="user:arjun")
mem_priya = MemoryLayer(namespace="user:priya")

# Different agents for the same user
mem_coder     = MemoryLayer(namespace="user:arjun:agent:coder")
mem_assistant = MemoryLayer(namespace="user:arjun:agent:assistant")

# Shared org-level knowledge
mem_org = MemoryLayer(namespace="org:acme")
```

---

## Installation

```bash
# Minimal — SQLite + TF-IDF, zero dependencies
pip install memex-agent

# With your LLM provider
pip install memex-agent anthropic         # Claude
pip install memex-agent openai            # GPT-4, OpenRouter
pip install memex-agent google-generativeai  # Gemini

# With your embedding model
pip install memex-agent sentence-transformers  # local HuggingFace models
pip install memex-agent openai                 # OpenAI embeddings (text-embedding-3)
pip install memex-agent cohere                 # multilingual

# With sqlite-vec for local ANN vector search
pip install memex-agent sqlite-vec

# With Redis
pip install memex-agent redis

# With framework adapters
pip install memex-agent langchain
pip install memex-agent crewai
pip install memex-agent llama-index

# Everything
pip install memex-agent[all]
```

---

## API reference

### `MemoryLayer`

| Method | Description |
|---|---|
| `recall(query)` | Memory context string for system prompt injection |
| `learn(user_msg, reply)` | Extract facts from exchange, non-blocking |
| `remember(fact)` | Store a fact directly |
| `search(query)` | Semantic search → list of fact dicts |
| `search_episodes(query)` | Semantic search over past episodes |
| `add_message(role, content)` | Append to conversation history |
| `get_history(last_n)` | Retrieve conversation history |
| `end_session()` | Finalize session — creates episode, flushes observations |
| `scratch(key, value?)` | Temporary agent state (get/set) |
| `suggest_prompt_improvements()` | Analyze patterns → suggest prompt patches |
| `apply_prompt_improvements(s)` | Apply a suggestion |
| `rollback_prompt()` | Revert last procedural patch |
| `clear()` | Wipe all memory for this namespace |
| `stats()` | Counts, backend info, embedder info |
| `wrap(client)` | Wrap OpenAI-compat, Anthropic native, or LLMProvider |
| `as_langchain()` | LangChain BaseChatMemory-compatible object |
| `as_tool()` | MemexTool with OpenAI, Anthropic, CrewAI, LlamaIndex schemas |
| `decorator()` | `@memory.decorator()` for plain functions |

### `MemexTool`

| Method | Description |
|---|---|
| `call(action, **kwargs)` | Execute directly: `search`, `remember`, `recall_all` |
| `as_openai_function()` | OpenAI / OpenRouter function calling schema |
| `as_anthropic_tool()` | Anthropic tool_use schema |
| `as_crewai()` | List of CrewAI Tool objects |
| `as_llamaindex_tool()` | List of LlamaIndex FunctionTool objects |
| `handle_openai_call(tool_call)` | Execute from OpenAI tool_call object |
| `handle_anthropic_call(tool_use)` | Execute from Anthropic tool_use block |

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                           MemoryLayer                                │
│                                                                       │
│  recall(query)                                                        │
│    → VectorStore.search()   top-K semantic facts                      │
│    → EpisodicMemory          recent + relevant episodes               │
│    → ProceduralMemory        learned behavior patches                 │
│    → formatted string ready to append to any system prompt            │
│                                                                       │
│  learn(user_msg, reply)  [background thread — never blocks]           │
│    → Extractor.extract_facts()                                        │
│    → Consolidator.check_and_merge()   dedup before insert             │
│    → store + index                                                    │
│                                                                       │
│  wrap(client)   auto-detects: OpenAI-compat | Anthropic | LLMProvider│
└──────────────────────────┬──────────────────────────────────────────┘
                            │
         ┌──────────────────┴──────────────────┐
         │                                      │
  ┌──────▼──────────┐               ┌───────────▼───────────┐
  │   BaseStore     │               │     VectorStore        │
  │                 │               │                        │
  │  SQLiteStore    │               │  sqlite-vec (ANN)      │
  │  RedisStore     │               │  Redis-VSS  (HNSW)     │
  │  MemoryStore    │               │  cosine scan (zero-dep)│
  │  [your own]     │               │                        │
  └─────────────────┘               └────────────────────────┘

  ┌──────────────────────────────────────────────────────────────┐
  │                BaseEmbedder (pluggable)                        │
  │  TFIDFEmbedder · OpenAIEmbedder · OllamaEmbedder             │
  │  SentenceTransformerEmbedder · CohereEmbedder · [your own]   │
  └──────────────────────────────────────────────────────────────┘

  ┌──────────────────────────────────────────────────────────────┐
  │                LLMProvider (pluggable)                         │
  │  Anthropic · OpenAI · OpenRouter · Ollama · Gemini · [yours] │
  └──────────────────────────────────────────────────────────────┘

  ┌──────────────────────────────────────────────────────────────┐
  │                Adapters (framework-agnostic)                   │
  │  OpenAI function calling · Anthropic tool_use                 │
  │  LangChain · CrewAI · LlamaIndex · decorator                  │
  └──────────────────────────────────────────────────────────────┘
```

---

## Comparison

| | **memex-agent** | Mem0 | LangMem |
|---|---|---|---|
| Zero-dep start | ✅ TF-IDF + SQLite | ❌ Qdrant + OpenAI | ❌ LangGraph |
| LLM agnostic | ✅ any | ✅ any | ✅ LangChain LLMs |
| Embedding agnostic | ✅ 5 built-in + BYO | partial | partial |
| Storage agnostic | ✅ SQLite/Redis/BYO | Qdrant/Postgres | Postgres |
| Framework agnostic | ✅ | ✅ | ❌ LangChain only |
| OpenAI tool schema | ✅ | ✅ | ✅ |
| Anthropic tool schema | ✅ | ✅ | ❌ |
| Local/offline | ✅ Ollama + SQLite | partial | ❌ |
| Multi-user namespacing | ✅ | ✅ | ❌ |
| Episodic memory | ✅ | ✅ | ❌ |
| Procedural memory | ✅ | ❌ | partial |
| Background consolidation | ✅ | ❌ | ❌ |
| Graph memory | ❌ | ✅ Neo4j | ❌ |
| Self-hostable | ✅ single file | ✅ 3 containers | ✅ |
| Codebase size | ~1200 lines | large | large |

---

## License

MIT
