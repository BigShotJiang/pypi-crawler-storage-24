"""
memex/episodic.py
-----------------
Episodic memory — stores summaries of past conversations.

Semantic memory answers: "what do I know about this user?"
Episodic memory answers: "what have we talked about before?"

Episodes are created when:
  - end_session() is called explicitly
  - conversation exceeds max_turns (auto-summarize)
  - agent is initialized and prior session had no episode

Each episode stores:
  summary, topics, outcome, mood, turn_count, timestamp

Retrieval:
  - By recency (last N episodes)
  - By topic similarity (semantic search on summaries)
  - By time range
"""

import uuid
from datetime import datetime
from typing import Optional

from .store import BaseStore
from .extractor import BaseExtractor
from .vector_store import VectorStore

EPISODES_KEY = "memex:episodes"


class EpisodicMemory:
    """
    Manages conversation episode storage and retrieval.
    """

    def __init__(
        self,
        store:     BaseStore,
        vs:        VectorStore,
        extractor: BaseExtractor,
        namespace: str = "default",
        max_episode_turns: int = 100,
    ):
        self.store     = store
        self.vs        = vs
        self.extractor = extractor
        self.ns        = namespace
        self.max_turns = max_episode_turns

    # ── Episode creation ──────────────────────────────────────────────────────

    def create_episode(self, conversation: list[dict]) -> Optional[dict]:
        """
        Summarize a conversation and store it as an episode.
        Returns the episode dict or None if conversation is too short.
        """
        if len(conversation) < 2:
            return None

        ep_data = self.extractor.extract_episode(conversation)
        if not ep_data:
            return None

        episode = {
            "id":          str(uuid.uuid4())[:8],
            "summary":     ep_data.get("summary", ""),
            "topics":      ep_data.get("topics", []),
            "outcome":     ep_data.get("outcome", "unknown"),
            "mood":        ep_data.get("mood", "neutral"),
            "turn_count":  len(conversation),
            "created_at":  datetime.utcnow().isoformat(),
        }

        # Persist
        episodes = self._load()
        episodes.append(episode)
        self._save(episodes)

        # Index summary for semantic search
        if episode["summary"]:
            self.vs.add(
                fact_id   = f"ep:{episode['id']}",
                content   = episode["summary"],
                namespace = f"{self.ns}:episodes",
            )

        return episode

    # ── Retrieval ─────────────────────────────────────────────────────────────

    def get_recent(self, n: int = 3) -> list[dict]:
        """Return the N most recent episodes."""
        episodes = self._load()
        return sorted(episodes, key=lambda e: e["created_at"], reverse=True)[:n]

    def search(self, query: str, top_k: int = 3) -> list[dict]:
        """Find episodes relevant to a query by semantic similarity."""
        results    = self.vs.search(query, namespace=f"{self.ns}:episodes", top_k=top_k)
        by_ep_id   = {f"ep:{e['id']}": e for e in self._load()}
        hydrated   = []
        for r in results:
            ep = by_ep_id.get(r["fact_id"])
            if ep:
                ep = dict(ep)
                ep["_score"] = r["score"]
                hydrated.append(ep)
        return hydrated

    def get_by_topic(self, topic: str) -> list[dict]:
        """Return episodes that include a given topic."""
        return [e for e in self._load()
                if topic.lower() in [t.lower() for t in e.get("topics", [])]]

    def as_context(self, query: str = "", n_recent: int = 2) -> str:
        """
        Build episode context string for system prompt injection.
        Combines recent episodes + query-relevant episodes.
        """
        seen  = set()
        items = []

        # Recent episodes always included
        for ep in self.get_recent(n=n_recent):
            seen.add(ep["id"])
            items.append(ep)

        # Relevant episodes if query provided
        if query:
            for ep in self.search(query, top_k=2):
                if ep["id"] not in seen:
                    seen.add(ep["id"])
                    items.append(ep)

        if not items:
            return ""

        lines = []
        for ep in items:
            ts = ep["created_at"][:10]
            lines.append(
                f"  [{ts}] {ep['summary']} "
                f"(topics: {', '.join(ep['topics'][:3])}; outcome: {ep['outcome']})"
            )
        return "\n\n## Past conversations:\n" + "\n".join(lines)

    def count(self) -> int:
        return len(self._load())

    def clear(self):
        self._save([])
        self.vs.clear(namespace=f"{self.ns}:episodes")

    # ── Internal ──────────────────────────────────────────────────────────────

    def _load(self) -> list[dict]:
        return self.store.get(EPISODES_KEY, namespace=self.ns, default=[])

    def _save(self, episodes: list[dict]):
        # Keep last 500 episodes max
        if len(episodes) > 500:
            episodes = episodes[-500:]
        self.store.set(EPISODES_KEY, episodes, namespace=self.ns)
