"""
memex/adapters/wrap.py
----------------------
Wraps any LLM client transparently — injects memory context before
the call, extracts facts from the response after.

Supports two client shapes automatically:

  OpenAI-compatible  (openai, openrouter, together, litellm, ...)
    client.chat.completions.create(messages=[...])
    response.choices[0].message.content

  Anthropic native  (anthropic.Anthropic())
    client.messages.create(messages=[...], system=...)
    response.content[0].text

Also wraps our own LLMProvider interface:
    memory.wrap(get_provider("ollama"))

Usage:
    import openai
    from memex import MemoryLayer

    memory = MemoryLayer(namespace="user:arjun")

    # OpenAI / OpenRouter / any OpenAI-compatible
    client = memory.wrap(openai.OpenAI())

    # Anthropic native SDK
    import anthropic
    client = memory.wrap(anthropic.Anthropic())

    # Our own provider
    from memex import get_provider
    client = memory.wrap(get_provider("ollama"))
"""


def _extract_reply(response) -> str:
    """Extract the assistant text from any response shape."""
    # OpenAI-compatible: response.choices[0].message.content
    if hasattr(response, "choices"):
        try:
            return response.choices[0].message.content or ""
        except Exception:
            pass
    # Anthropic native: response.content[0].text
    if hasattr(response, "content"):
        try:
            c = response.content
            if isinstance(c, list) and c:
                return c[0].text if hasattr(c[0], "text") else str(c[0])
            return str(c)
        except Exception:
            pass
    # Fallback: str()
    return str(response)


def _extract_user_msg(kwargs: dict) -> str:
    """Extract the last user message from call kwargs."""
    messages = kwargs.get("messages", [])
    user_msgs = [m["content"] for m in messages if m.get("role") == "user"]
    return user_msgs[-1] if user_msgs else ""


# ── OpenAI-compatible proxy ───────────────────────────────────────────────────

class _OAICompletionsProxy:
    def __init__(self, completions, memory):
        self._completions = completions
        self._memory      = memory

    def create(self, **kwargs):
        query = _extract_user_msg(kwargs)
        ctx   = self._memory.recall(query) if query else ""

        if ctx:
            messages = list(kwargs.get("messages", []))
            sys_msgs = [i for i, m in enumerate(messages) if m.get("role") == "system"]
            if sys_msgs:
                messages[sys_msgs[-1]] = {
                    **messages[sys_msgs[-1]],
                    "content": messages[sys_msgs[-1]]["content"] + ctx,
                }
            else:
                messages = [{"role": "system", "content": ctx.strip()}] + messages
            kwargs = {**kwargs, "messages": messages}

        response = self._completions.create(**kwargs)

        try:
            reply = _extract_reply(response)
            if query and reply:
                self._memory.learn(query, reply)
                self._memory.add_message("user",      query)
                self._memory.add_message("assistant", reply)
        except Exception:
            pass

        return response


class _OAIChatProxy:
    def __init__(self, chat, memory):
        self.completions = _OAICompletionsProxy(chat.completions, memory)


# ── Anthropic native proxy ────────────────────────────────────────────────────

class _AnthropicMessagesProxy:
    def __init__(self, messages_api, memory):
        self._api    = messages_api
        self._memory = memory

    def create(self, **kwargs):
        query = _extract_user_msg(kwargs)
        ctx   = self._memory.recall(query) if query else ""

        if ctx:
            existing_system = kwargs.get("system", "")
            kwargs = {**kwargs, "system": (existing_system + ctx).strip()}

        response = self._api.create(**kwargs)

        try:
            reply = _extract_reply(response)
            if query and reply:
                self._memory.learn(query, reply)
                self._memory.add_message("user",      query)
                self._memory.add_message("assistant", reply)
        except Exception:
            pass

        return response


class _AnthropicClientProxy:
    def __init__(self, client, memory):
        self._client = client
        self._memory = memory
        self.messages = _AnthropicMessagesProxy(client.messages, memory)

    def __getattr__(self, name):
        return getattr(self._client, name)


# ── LLMProvider proxy ─────────────────────────────────────────────────────────

class _LLMProviderProxy:
    """
    Wraps our own LLMProvider so it auto-injects memory on every .chat() call.
    """
    def __init__(self, provider, memory):
        self._provider = provider
        self._memory   = memory
        self.model     = provider.model

    def chat(self, messages, system="", max_tokens=1024):
        user_msgs = [m["content"] for m in messages if m.get("role") == "user"]
        query     = user_msgs[-1] if user_msgs else ""
        ctx       = self._memory.recall(query) if query else ""

        augmented_system = (system + ctx).strip() if ctx else system
        response = self._provider.chat(messages, augmented_system, max_tokens)

        if query and response:
            self._memory.learn(query, response)
            self._memory.add_message("user",      query)
            self._memory.add_message("assistant", response)

        return response

    def __repr__(self):
        return f"WrappedProvider({self._provider!r})"


# ── Public factory ────────────────────────────────────────────────────────────

class WrappedClient:
    """
    Auto-detecting transparent wrapper.
    Detects client type and proxies the right interface.
    All other attributes pass through to the original client.
    """

    def __new__(cls, client, memory):
        from ..providers.base import LLMProvider

        # Our own LLMProvider
        if isinstance(client, LLMProvider):
            return _LLMProviderProxy(client, memory)

        # Anthropic native SDK
        if hasattr(client, "messages") and not hasattr(client, "chat"):
            return _AnthropicClientProxy(client, memory)

        # OpenAI-compatible (openai, openrouter, together, litellm, ...)
        if hasattr(client, "chat") and hasattr(client.chat, "completions"):
            inst = object.__new__(_OAICompatWrapper)
            inst.__init__(client, memory)
            return inst

        raise TypeError(
            f"Cannot wrap {type(client).__name__}. "
            "Supported: openai.OpenAI(), anthropic.Anthropic(), "
            "or any LLMProvider from memex.providers."
        )


class _OAICompatWrapper:
    def __init__(self, client, memory):
        self._client = client
        self._memory = memory
        self.chat    = _OAIChatProxy(client.chat, memory)

    def __getattr__(self, name):
        return getattr(self._client, name)

    def __repr__(self):
        return f"WrappedClient({self._client!r}, ns={self._memory.namespace!r})"
