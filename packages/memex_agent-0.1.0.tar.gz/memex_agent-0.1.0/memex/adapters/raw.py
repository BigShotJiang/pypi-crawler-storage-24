"""
memex/adapters/raw.py
---------------------
Decorator for plain Python agent functions.

memory = MemoryLayer()

@memory.decorator()
def my_agent(user_input: str, system_context: str = "") -> str:
    # system_context is auto-injected with relevant memories
    return call_llm(system_context, user_input)

# Memory is automatically learned from each call
reply = my_agent("What's my name?")
"""

import functools


def make_decorator(memory_layer):
    """
    Returns a decorator that:
    1. Injects memory context as `system_context` kwarg
    2. Learns from (user_input, return_value) after each call
    """

    def decorator(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            # Get user input from first positional arg or 'user_input' kwarg
            user_input = args[0] if args else kwargs.get("user_input", "")

            # Inject memory context
            ctx = memory_layer.recall(str(user_input))
            kwargs["system_context"] = ctx

            # Call the original function
            result = fn(*args, **kwargs)

            # Learn from the exchange
            if user_input and result:
                memory_layer.learn(str(user_input), str(result))
                memory_layer.add_message("user", str(user_input))
                memory_layer.add_message("assistant", str(result))

            return result
        return wrapper
    return decorator
