"""
memex/adapters/langchain.py
----------------------------
LangChain-compatible memory object. Works with any LangChain LLM —
there is no dependency on a specific model or provider here.

Usage (bring your own LLM):
    from langchain.chains import ConversationChain
    from memex import MemoryLayer

    memory = MemoryLayer(namespace="user:arjun", episodic=True)
    chain  = ConversationChain(
        llm    = your_langchain_llm,   # ChatOpenAI, ChatAnthropic, Ollama, etc.
        memory = memory.as_langchain(),
    )
    response = chain.predict(input="What's my name?")

Also works with LCEL chains:
    from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder

    lc_mem = memory.as_langchain()
    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are helpful. {history}"),
        ("human",  "{input}"),
    ])
    chain  = prompt | your_llm
    ctx    = lc_mem.load_memory_variables({"input": user_input})
"""

from typing import Any


class MemexLangChainMemory:
    """
    Implements the LangChain BaseMemory interface on top of MemoryLayer.
    Framework-agnostic — works with any LangChain LLM.
    """

    memory_key = "history"

    def __init__(self, memory_layer):
        self.memory = memory_layer

    # ── LangChain BaseMemory interface ────────────────────────────────────────

    @property
    def memory_variables(self) -> list[str]:
        return [self.memory_key]

    def load_memory_variables(self, inputs: dict) -> dict:
        """Called before LLM — returns memory context keyed by memory_key."""
        query = inputs.get("input", inputs.get("human_input", ""))
        ctx   = self.memory.recall(str(query))
        return {self.memory_key: ctx}

    def save_context(self, inputs: dict, outputs: dict) -> None:
        """Called after LLM — stores history and triggers fact extraction."""
        user_msg = inputs.get("input", inputs.get("human_input", ""))
        asst_msg = outputs.get("response", outputs.get("output", ""))
        if user_msg:
            self.memory.add_message("user", str(user_msg))
        if asst_msg:
            self.memory.add_message("assistant", str(asst_msg))
        if user_msg and asst_msg:
            self.memory.learn(str(user_msg), str(asst_msg))

    def clear(self) -> None:
        self.memory.clear()

    # ── Pydantic compatibility (LangChain v0.1+) ──────────────────────────────

    class Config:
        arbitrary_types_allowed = True

    def dict(self, **kwargs) -> dict:
        return {"memory_key": self.memory_key}
