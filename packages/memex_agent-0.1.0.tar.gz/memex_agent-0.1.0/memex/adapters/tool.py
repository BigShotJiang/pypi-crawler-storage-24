"""
memex/adapters/tool.py
-----------------------
Memory as a callable tool for any tool-use agent.

Supports all major tool schemas:
  as_openai_function()   OpenAI / OpenRouter / LiteLLM function calling
  as_anthropic_tool()    Anthropic tool_use format
  as_crewai()            CrewAI tools list
  as_llamaindex_tool()   LlamaIndex FunctionTool
  as_dict()              Raw dict — map to any other framework

Usage:
    tool = MemoryLayer().as_tool()

    # OpenAI
    response = openai_client.chat.completions.create(
        tools=[tool.as_openai_function()], ...
    )
    if response.choices[0].finish_reason == "tool_calls":
        result = tool.handle_openai_call(response.choices[0].message.tool_calls[0])

    # Anthropic
    response = anthropic_client.messages.create(
        tools=[tool.as_anthropic_tool()], ...
    )
    if response.stop_reason == "tool_use":
        result = tool.handle_anthropic_call(response.content[-1])

    # CrewAI
    agent = Agent(role="assistant", tools=tool.as_crewai())

    # LlamaIndex
    engine = ReActAgent.from_tools([tool.as_llamaindex_tool()])

    # Raw call (any framework)
    result = tool.call("search", query="what does user prefer?")
    result = tool.call("remember", fact="User loves Python")
"""

import json


class MemexTool:
    """
    Exposes MemoryLayer as a callable tool with schemas for every major framework.
    """

    name        = "memory"
    description = (
        "Persistent memory tool. "
        "Actions: 'search' to recall relevant facts, "
        "'remember' to store a fact, "
        "'recall_all' to list all stored facts."
    )

    def __init__(self, memory_layer):
        self.memory = memory_layer

    # ── Core execution ────────────────────────────────────────────────────────

    def call(self, action: str, **kwargs) -> str:
        """
        Execute a memory action directly.

        Actions:
          search(query)    → top relevant facts as text
          remember(fact)   → store a fact
          recall_all()     → all facts as text
          end_session()    → finalize session, create episode
        """
        if action == "search":
            query   = kwargs.get("query", "")
            results = self.memory.search(query)
            if not results:
                return "No relevant memories found."
            lines = [f"- [{r['id']}] {r['content']}" for r in results]
            return "Relevant memories:\n" + "\n".join(lines)

        elif action == "remember":
            fact = kwargs.get("fact", "")
            if not fact:
                return "Error: fact cannot be empty"
            self.memory.remember(fact)
            return f"Stored: {fact}"

        elif action == "recall_all":
            facts = self.memory._get_facts()
            if not facts:
                return "No memories stored."
            lines = [f"- [{f['id']}] {f['content']}" for f in facts]
            return "All memories:\n" + "\n".join(lines)

        elif action == "end_session":
            self.memory.end_session()
            return "Session ended and episode saved."

        return f"Unknown action: {action}"

    # ── OpenAI function calling ───────────────────────────────────────────────

    def as_openai_function(self) -> dict:
        """
        OpenAI / OpenRouter / LiteLLM function calling format.

        response = client.chat.completions.create(
            tools=[tool.as_openai_function()], ...
        )
        """
        return {
            "type": "function",
            "function": {
                "name":        self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": {
                        "action": {
                            "type":        "string",
                            "enum":        ["search", "remember", "recall_all"],
                            "description": "Memory action to perform",
                        },
                        "query": {
                            "type":        "string",
                            "description": "Search query (required for 'search')",
                        },
                        "fact": {
                            "type":        "string",
                            "description": "Fact to store (required for 'remember')",
                        },
                    },
                    "required": ["action"],
                },
            },
        }

    def handle_openai_call(self, tool_call) -> str:
        """Handle a tool_call object from an OpenAI response."""
        try:
            args   = json.loads(tool_call.function.arguments)
            action = args.pop("action")
            return self.call(action, **args)
        except Exception as e:
            return f"Memory tool error: {e}"

    # ── Anthropic tool_use ────────────────────────────────────────────────────

    def as_anthropic_tool(self) -> dict:
        """
        Anthropic tool_use format.

        response = anthropic_client.messages.create(
            tools=[tool.as_anthropic_tool()], ...
        )
        """
        return {
            "name":        self.name,
            "description": self.description,
            "input_schema": {
                "type": "object",
                "properties": {
                    "action": {
                        "type":        "string",
                        "enum":        ["search", "remember", "recall_all"],
                        "description": "Memory action to perform",
                    },
                    "query": {
                        "type":        "string",
                        "description": "Search query (required for 'search')",
                    },
                    "fact": {
                        "type":        "string",
                        "description": "Fact to store (required for 'remember')",
                    },
                },
                "required": ["action"],
            },
        }

    def handle_anthropic_call(self, tool_use_block) -> str:
        """
        Handle a tool_use content block from an Anthropic response.
        Pass response.content[-1] when stop_reason == 'tool_use'.
        """
        try:
            inp    = tool_use_block.input if hasattr(tool_use_block, "input") else tool_use_block
            action = inp.pop("action") if isinstance(inp, dict) else inp["action"]
            kwargs = {k: v for k, v in (inp.items() if isinstance(inp, dict) else inp.items())
                      if k != "action"}
            return self.call(action, **kwargs)
        except Exception as e:
            return f"Memory tool error: {e}"

    # ── CrewAI ────────────────────────────────────────────────────────────────

    def as_crewai(self) -> list:
        """
        Returns a list of two CrewAI Tool objects: search + remember.
        pip install crewai

        agent = Agent(role="assistant", tools=tool.as_crewai())
        """
        try:
            from crewai.tools import tool as crewai_tool
            memory = self.memory

            @crewai_tool("Search Memory")
            def search_memory(query: str) -> str:
                """Search persistent memory for facts relevant to a query."""
                return MemexTool(memory).call("search", query=query)

            @crewai_tool("Store Memory")
            def store_memory(fact: str) -> str:
                """Store an important fact in persistent memory."""
                return MemexTool(memory).call("remember", fact=fact)

            return [search_memory, store_memory]
        except ImportError:
            raise ImportError("pip install crewai to use as_crewai()")

    # ── LlamaIndex ────────────────────────────────────────────────────────────

    def as_llamaindex_tool(self):
        """
        LlamaIndex FunctionTool.
        pip install llama-index

        agent = ReActAgent.from_tools([tool.as_llamaindex_tool()])
        """
        try:
            from llama_index.core.tools import FunctionTool
            memory = self.memory

            def search_memory(query: str) -> str:
                """Search persistent memory for facts about the user."""
                return MemexTool(memory).call("search", query=query)

            def store_memory(fact: str) -> str:
                """Store an important fact in persistent memory."""
                return MemexTool(memory).call("remember", fact=fact)

            return [
                FunctionTool.from_defaults(fn=search_memory),
                FunctionTool.from_defaults(fn=store_memory),
            ]
        except ImportError:
            raise ImportError("pip install llama-index to use as_llamaindex_tool()")

    # ── Generic dict ──────────────────────────────────────────────────────────

    def as_dict(self) -> dict:
        """
        Generic tool dict — adapt to any framework's tool format.
        Follows the OpenAI schema shape as a common baseline.
        """
        return self.as_openai_function()
