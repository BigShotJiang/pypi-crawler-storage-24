"""
memex/consolidator.py
---------------------
Prevents memory explosion:
  1. Deduplication  — merge near-duplicates before insert (hot path, fast)
  2. Summarization  — compress at MAX_FACTS threshold
  3. Background loop — daemon thread re-reads memory, finds patterns
"""

import json
import threading
from .vector_store import VectorStore
from .providers.base import LLMProvider

MERGE_PROMPT = """Merge these two similar facts into one concise fact (max 150 chars).
Prefer more recent/specific info when they conflict.
Fact A: {a}
Fact B: {b}
Reply with ONLY the merged fact."""

SUMMARIZE_PROMPT = """Compress these {n} facts into {target} concise summaries (max 150 chars each).
Facts:
{facts}
Reply ONLY with JSON array: ["summary 1", ...]"""

BG_PROMPT = """Review these memories and find merge opportunities or staleness.
{facts}
Reply ONLY with JSON:
{{"merge_pairs": [[id_a, id_b]], "stale_ids": [id], "insights": ["new insight"]}}"""


class Consolidator:
    DEDUP_THRESHOLD = 0.88
    MAX_FACTS       = 100
    SUMMARIZE_TO    = 30

    def __init__(self, vs: VectorStore, llm: LLMProvider):
        self.vs   = vs
        self.llm  = llm
        self._stop = threading.Event()

    def check_and_merge(self, content: str, facts: list[dict],
                        namespace: str = "default") -> tuple[str | None, str | None]:
        similar = self.vs.find_similar(content, namespace=namespace,
                                       threshold=self.DEDUP_THRESHOLD)
        if not similar:
            return None, None
        best     = similar[0]
        existing = next((f for f in facts if str(f["id"]) == str(best["fact_id"])), None)
        if not existing:
            return None, None
        merged = self._call(MERGE_PROMPT.format(a=existing["content"], b=content))
        print(f"  🔀 Merged (cos={best['score']:.2f}): {merged[:60]}")
        return merged, str(best["fact_id"])

    def should_summarize(self, n: int) -> bool:
        return n >= self.MAX_FACTS

    def summarize(self, facts: list[dict]) -> list[str]:
        text = "\n".join(f"- {f['content']}" for f in facts)
        print(f"  🗜️  Compressing {len(facts)} → {self.SUMMARIZE_TO}...")
        raw  = self._call(SUMMARIZE_PROMPT.format(
            n=len(facts), target=self.SUMMARIZE_TO, facts=text
        ), max_tokens=2000)
        raw  = raw.strip().lstrip("```json").lstrip("```").rstrip("```").strip()
        try:
            out = json.loads(raw)
            assert isinstance(out, list)
            return [str(s) for s in out]
        except Exception:
            return [f["content"] for f in facts[-self.SUMMARIZE_TO:]]

    def start_background(self, get_fn, update_fn, interval: int = 300):
        self._stop.clear()
        def loop():
            while not self._stop.wait(interval):
                try:
                    self._bg_pass(get_fn, update_fn)
                except Exception as e:
                    print(f"  ⚠️  BG consolidation error: {e}")
        t = threading.Thread(target=loop, daemon=True, name="memex-bg")
        t.start()

    def stop_background(self):
        self._stop.set()

    def _bg_pass(self, get_fn, update_fn):
        facts = get_fn()
        if len(facts) < 5:
            return
        text = "\n".join(f"[{f['id']}] {f['content']}" for f in facts[:50])
        raw  = self._call(BG_PROMPT.format(facts=text), max_tokens=800)
        raw  = raw.strip().lstrip("```json").lstrip("```").rstrip("```").strip()
        try:
            r         = json.loads(raw)
            by_id     = {str(f["id"]): f for f in facts}
            changes   = 0
            for pair in r.get("merge_pairs", [])[:5]:
                fa = by_id.get(str(pair[0]))
                fb = by_id.get(str(pair[1]))
                if fa and fb:
                    merged = self._call(MERGE_PROMPT.format(
                        a=fa["content"], b=fb["content"]))
                    fa["content"] = merged
                    facts  = [f for f in facts if str(f["id"]) != str(pair[1])]
                    by_id  = {str(f["id"]): f for f in facts}
                    changes += 1
            for sid in r.get("stale_ids", [])[:3]:
                facts = [f for f in facts if str(f["id"]) != str(sid)]
                changes += 1
            insights = r.get("insights", [])
            if changes > 0 or insights:
                update_fn(facts, insights)
                print(f"  🌙 BG pass: {changes} changes, {len(insights)} insights")
        except Exception:
            pass

    def _call(self, prompt: str, max_tokens: int = 300) -> str:
        return self.llm.chat(
            messages=[{"role": "user", "content": prompt}],
            max_tokens=max_tokens,
        )
