"""
memex/core.py
-------------
MemoryLayer — the single object you plug into any agent or framework.

Three integration patterns:

  Pattern 1 — Wrap (zero friction)
  ─────────────────────────────────
    client = memory.wrap(openai.OpenAI())
    # All calls automatically get memory context injected
    # and facts extracted after each response

  Pattern 2 — Before / After (manual control)
  ─────────────────────────────────────────────
    ctx   = memory.recall(user_input)        # before LLM call
    reply = your_llm.chat(ctx, user_input)
    memory.learn(user_input, reply)           # after LLM call

  Pattern 3 — Framework adapter
  ──────────────────────────────
    chain = LLMChain(memory=memory.as_langchain())
    agent = Agent(tools=[memory.as_tool()])

All memory types are optional and independently togglable:
  semantic   = True    facts about the user (default on)
  episodic   = False   conversation summaries (opt-in)
  procedural = False   self-improving prompt patches (opt-in)
"""

import queue
import threading
import uuid
from datetime import datetime
from typing import Optional, Any

from .store import BaseStore, get_store
from .embedder import BaseEmbedder, get_embedder
from .vector_store import VectorStore
from .extractor import BaseExtractor, get_extractor
from .consolidator import Consolidator
from .providers.base import LLMProvider
from .providers import get_provider


SEMANTIC_KEY = "memex:facts"
HISTORY_KEY  = "memex:history"
SCRATCH_PFX  = "memex:scratch:"

MAX_CONTEXT_CHARS = 6000


class MemoryLayer:
    """
    Drop-in persistent memory for any Python agent.

    Args:
        namespace:   Scope for all memory. Use "user:{id}" for multi-user.
        store:       Storage backend. Auto-detected if not provided.
        embedder:    Embedding model. Auto-detected if not provided.
        llm:         LLM provider for extraction + consolidation.
        semantic:    Enable semantic (fact) memory. Default True.
        episodic:    Enable episodic (conversation summary) memory.
        procedural:  Enable procedural (self-improving prompt) memory.
        background:  Run background consolidation daemon.
        bg_interval: Background loop interval in seconds.
        top_k:       Facts to inject per turn.
        max_history: Conversation history window.
        async_learn: Non-blocking memory writes (default True).

    Examples:
        # Minimal
        mem = MemoryLayer()

        # Multi-user with explicit config
        mem = MemoryLayer(
            namespace  = "user:arjun",
            store      = SQLiteStore(".memex.db"),
            llm        = get_provider("openrouter", model="mistralai/mistral-7b"),
            episodic   = True,
            procedural = True,
        )
    """

    def __init__(
        self,
        namespace:   str = "default",
        store:       Optional[BaseStore]   = None,
        embedder:    Optional[BaseEmbedder] = None,
        llm:         Optional[LLMProvider]  = None,
        semantic:    bool = True,
        episodic:    bool = False,
        procedural:  bool = False,
        background:  bool = False,
        bg_interval: int  = 300,
        top_k:       int  = 6,
        max_history: int  = 50,
        async_learn: bool = True,
    ):
        self.namespace   = namespace
        self.store       = store or get_store("auto")
        self.embedder    = embedder or get_embedder()
        self.llm         = llm
        self.top_k       = top_k
        self.max_history = max_history
        self.async_learn = async_learn

        # Try to get LLM from env if not provided
        if self.llm is None:
            try:
                self.llm = get_provider("auto")
            except Exception:
                pass

        # Core components
        self.vs          = VectorStore(self.store, self.embedder)
        self.extractor   = get_extractor(self.llm)
        self.consolidator = Consolidator(self.vs, self.llm) if self.llm else None

        # Optional memory types
        self._episodic   = None
        self._procedural = None

        if episodic:
            from .episodic import EpisodicMemory
            self._episodic = EpisodicMemory(
                self.store, self.vs, self.extractor, namespace=namespace
            )

        if procedural and self.llm:
            from .procedural import ProceduralMemory
            self._procedural = ProceduralMemory(
                self.store, self.llm, namespace=namespace
            )

        if background and self.consolidator:
            self.consolidator.start_background(
                get_fn    = self._get_facts,
                update_fn = self._bg_update,
                interval  = bg_interval,
            )

        # Async write queue
        self._queue: queue.Queue = queue.Queue()
        if async_learn:
            self._start_writer()

        print(f"[MemoryLayer] 🧠 ns={namespace!r} "
              f"semantic={semantic} episodic={episodic} procedural={procedural}")

    # ── Primary API ───────────────────────────────────────────────────────────

    def recall(self, query: str = "", include_episodes: bool = True) -> str:
        """
        Build a memory context string ready to inject into any system prompt.

        Args:
            query:            Used for semantic search. Pass the user's message.
            include_episodes: Include past conversation episodes.

        Returns:
            Formatted string to append to your system prompt.
        """
        parts = []

        # Semantic facts
        facts = self._search_facts(query) if query else self._recent_facts()
        if facts:
            total = len(self._get_facts())
            lines = "\n".join(
                f"  [{f['id']}] {f['content']}"
                + (f" (relevance={f['_score']})" if "_score" in f else "")
                for f in facts
            )
            parts.append(
                f"## What I know about this user ({len(facts)} of {total}):\n{lines}"
            )

        # Episodic memory
        if self._episodic and include_episodes:
            ep_ctx = self._episodic.as_context(query=query)
            if ep_ctx:
                parts.append(ep_ctx.strip())

        # Procedural patch
        if self._procedural:
            proc_ctx = self._procedural.as_context()
            if proc_ctx:
                parts.append(proc_ctx.strip())

        if not parts:
            return ""

        ctx = "\n\n".join(parts)
        if len(ctx) > MAX_CONTEXT_CHARS:
            ctx = ctx[:MAX_CONTEXT_CHARS] + "\n  ...(truncated)"
        return "\n\n" + ctx

    def learn(self, user_msg: str, assistant_msg: str):
        """
        Extract and store facts from a completed exchange.
        Non-blocking by default (async_learn=True).
        """
        if self.async_learn:
            self._queue.put(("learn", user_msg, assistant_msg))
        else:
            self._do_learn(user_msg, assistant_msg)

        # Record observation for procedural memory (always sync, cheap)
        if self._procedural:
            satisfied = self._procedural.infer_satisfaction(user_msg)
            self._procedural.observe(user_msg, assistant_msg, satisfied)

    def remember(self, fact: str):
        """Directly store a fact string without extraction."""
        if self.async_learn:
            self._queue.put(("fact", fact))
        else:
            self._store_fact(fact)

    def end_session(self):
        """
        Mark the end of a conversation session.
        Creates an episode summary if episodic memory is enabled.
        Flushes procedural observations.
        """
        if self._episodic:
            history = self._get_history()
            if history:
                ep = self._episodic.create_episode(history)
                if ep:
                    print(f"  📖 Episode saved: {ep['summary'][:60]}...")
            self._clear_history()

        if self._procedural:
            self._procedural.flush_session()

    def suggest_prompt_improvements(self) -> Optional[dict]:
        """
        Analyze observations and suggest system prompt improvements.
        Returns None if not enough data yet.
        Requires procedural=True.
        """
        if not self._procedural:
            raise RuntimeError("procedural=True required")
        return self._procedural.analyze()

    def apply_prompt_improvements(self, suggestion: dict) -> str:
        """Apply a suggestion from suggest_prompt_improvements()."""
        if not self._procedural:
            raise RuntimeError("procedural=True required")
        return self._procedural.apply(suggestion)

    def rollback_prompt(self) -> bool:
        """Revert the last procedural patch."""
        if not self._procedural:
            raise RuntimeError("procedural=True required")
        return self._procedural.rollback()

    # ── History API ───────────────────────────────────────────────────────────

    def add_message(self, role: str, content: str):
        """Add a message to conversation history."""
        history = self._get_history()
        history.append({"role": role, "content": content,
                         "ts": datetime.utcnow().isoformat()})
        if len(history) > self.max_history:
            history = history[-self.max_history:]
        self.store.set(HISTORY_KEY, history, namespace=self.namespace)

    def get_history(self, last_n: int = 20) -> list[dict]:
        """Return recent conversation history as role/content dicts."""
        return [{"role": m["role"], "content": m["content"]}
                for m in self._get_history()[-last_n:]]

    # ── Search API ────────────────────────────────────────────────────────────

    def search(self, query: str, top_k: Optional[int] = None) -> list[dict]:
        """Semantic search over stored facts."""
        return self._search_facts(query, top_k=top_k or self.top_k)

    def search_episodes(self, query: str) -> list[dict]:
        """Search past conversation episodes."""
        if not self._episodic:
            return []
        return self._episodic.search(query)

    # ── Scratch pad ───────────────────────────────────────────────────────────

    def scratch(self, key: str, value: Any = None,
                ttl: Optional[int] = None) -> Any:
        """
        Simple scratch pad for temporary agent state.
        scratch("key", value)    → set
        scratch("key")           → get
        """
        full_key = f"{SCRATCH_PFX}{key}"
        if value is None:
            return self.store.get(full_key, namespace=self.namespace)
        self.store.set(full_key, value, namespace=self.namespace, ttl=ttl)

    # ── Adapter factory methods ───────────────────────────────────────────────

    def as_langchain(self):
        """Return a LangChain-compatible memory object."""
        from .adapters.langchain import MemexLangChainMemory
        return MemexLangChainMemory(self)

    def as_tool(self):
        """Return a tool dict for tool-use agents (OpenAI/CrewAI format)."""
        from .adapters.tool import MemexTool
        return MemexTool(self)

    def wrap(self, client):
        """
        Wrap an OpenAI-compatible client to auto-inject memory.
        Works with openai.OpenAI(), anthropic client, or any
        object with a .chat.completions.create() method.
        """
        from .adapters.wrap import WrappedClient
        return WrappedClient(client, self)

    def decorator(self):
        """Return a @memory.remember decorator for plain functions."""
        from .adapters.raw import make_decorator
        return make_decorator(self)

    # ── Utility ───────────────────────────────────────────────────────────────

    def clear(self):
        """Wipe all memory for this namespace."""
        self.store.flush(namespace=self.namespace)
        self.vs.clear(namespace=self.namespace)
        if self._episodic:
            self._episodic.clear()
        if self._procedural:
            self._procedural.clear()

    def stats(self) -> dict:
        s = {
            "namespace":       self.namespace,
            "facts":           len(self._get_facts()),
            "vectors":         self.vs.count(namespace=self.namespace),
            "history":         len(self._get_history()),
            "store":           self.store.stats(),
            "embedder":        type(self.embedder).__name__,
            "llm":             repr(self.llm) if self.llm else "none",
        }
        if self._episodic:
            s["episodes"] = self._episodic.count()
        if self._procedural:
            s["procedural"] = self._procedural.stats()
        return s

    # ── Internal ─────────────────────────────────────────────────────────────

    def _do_learn(self, user_msg: str, assistant_msg: str):
        """Extract facts and store them."""
        facts = self.extractor.extract_facts(user_msg, assistant_msg)
        for fact in facts:
            self._store_fact(fact)

    def _store_fact(self, content: str):
        facts = self._get_facts()

        # Dedup check
        if self.consolidator:
            merged, existing_id = self.consolidator.check_and_merge(
                content, facts, namespace=self.namespace
            )
            if merged and existing_id:
                for f in facts:
                    if str(f["id"]) == existing_id:
                        f["content"]    = merged
                        f["updated_at"] = datetime.utcnow().isoformat()
                        break
                self._save_facts(facts)
                self.vs.delete(existing_id, namespace=self.namespace)
                self.vs.add(existing_id, merged, namespace=self.namespace)
                return

        # Explosion check
        if self.consolidator and self.consolidator.should_summarize(len(facts)):
            summaries = self.consolidator.summarize(facts)
            self.vs.clear(namespace=self.namespace)
            facts = []
            for s in summaries:
                nid = str(uuid.uuid4())[:8]
                facts.append({
                    "id": nid, "content": s,
                    "created_at": datetime.utcnow().isoformat(),
                    "updated_at": datetime.utcnow().isoformat(),
                    "access_count": 0, "is_summary": True,
                })
                self.vs.add(nid, s, namespace=self.namespace)
            self._save_facts(facts)
            return

        # Insert
        fact_id = str(uuid.uuid4())[:8]
        entry   = {
            "id": fact_id, "content": content,
            "created_at": datetime.utcnow().isoformat(),
            "updated_at": datetime.utcnow().isoformat(),
            "access_count": 0,
        }
        facts.append(entry)
        self._save_facts(facts)
        self.vs.add(fact_id, content, namespace=self.namespace)
        print(f"  💾 [{self.namespace}] {content[:70]}")

    def _search_facts(self, query: str, top_k: Optional[int] = None) -> list[dict]:
        results  = self.vs.search(query, namespace=self.namespace,
                                  top_k=top_k or self.top_k)
        by_id    = {str(f["id"]): f for f in self._get_facts()}
        hydrated = []
        for r in results:
            f = by_id.get(str(r["fact_id"]))
            if f:
                f = dict(f)
                f["_score"] = round(r["score"], 3)
                hydrated.append(f)
        if hydrated:
            accessed  = {f["id"] for f in hydrated}
            all_facts = self._get_facts()
            for f in all_facts:
                if f["id"] in accessed:
                    f["access_count"] = f.get("access_count", 0) + 1
            self._save_facts(all_facts)
        return hydrated

    def _recent_facts(self) -> list[dict]:
        all_f = self._get_facts()
        return sorted(all_f, key=lambda f: f.get("updated_at", ""),
                      reverse=True)[:self.top_k]

    def _get_facts(self) -> list[dict]:
        return self.store.get(SEMANTIC_KEY, namespace=self.namespace, default=[])

    def _save_facts(self, facts: list[dict]):
        self.store.set(SEMANTIC_KEY, facts, namespace=self.namespace)

    def _get_history(self) -> list[dict]:
        return self.store.get(HISTORY_KEY, namespace=self.namespace, default=[])

    def _clear_history(self):
        self.store.set(HISTORY_KEY, [], namespace=self.namespace)

    def _bg_update(self, updated: list[dict], insights: list[str]):
        self._save_facts(updated)
        self.vs.clear(namespace=self.namespace)
        for f in updated:
            self.vs.add(str(f["id"]), f["content"], namespace=self.namespace)
        for insight in insights:
            self._store_fact(f"[insight] {insight}")

    def _start_writer(self):
        def worker():
            while True:
                try:
                    item = self._queue.get(timeout=5)
                    if item[0] == "learn":
                        self._do_learn(item[1], item[2])
                    elif item[0] == "fact":
                        self._store_fact(item[1])
                    self._queue.task_done()
                except queue.Empty:
                    continue
                except Exception as e:
                    print(f"  ⚠️  Writer error: {e}")
        t = threading.Thread(target=worker, daemon=True, name="memex-writer")
        t.start()
