"""
memex-agent — Drop-in persistent memory for any Python AI agent.

Zero infrastructure. Any model. Own your data.

Quick start:
    from memex import MemoryLayer

    memory = MemoryLayer()

    # Wrap any client
    client = memory.wrap(openai.OpenAI())           # OpenAI-compatible
    client = memory.wrap(anthropic.Anthropic())      # Anthropic native
    client = memory.wrap(get_provider("ollama"))     # Our own providers

    # Manual before/after
    ctx   = memory.recall(user_input)
    reply = your_llm(ctx + system_prompt, user_input)
    memory.learn(user_input, reply)

    # Framework adapters
    chain = ConversationChain(memory=memory.as_langchain())
    tools = [memory.as_tool().as_openai_function()]
    tools = [memory.as_tool().as_anthropic_tool()]
"""

from .core     import MemoryLayer
from .store    import BaseStore, SQLiteStore, RedisStore, MemoryStore, get_store
from .embedder import (
    BaseEmbedder,
    TFIDFEmbedder,
    SentenceTransformerEmbedder,
    OpenAIEmbedder,
    OllamaEmbedder,
    CohereEmbedder,
    get_embedder,
)
from .providers import LLMProvider, get_provider, list_providers

__version__ = "0.1.0"
__author__  = "Memex Contributors"
__license__ = "MIT"

__all__ = [
    # Main object
    "MemoryLayer",
    # Storage
    "BaseStore", "SQLiteStore", "RedisStore", "MemoryStore", "get_store",
    # Embedders — all implementations exported so users can subclass/inspect
    "BaseEmbedder",
    "TFIDFEmbedder",
    "SentenceTransformerEmbedder",
    "OpenAIEmbedder",
    "OllamaEmbedder",
    "CohereEmbedder",
    "get_embedder",
    # LLM Providers
    "LLMProvider", "get_provider", "list_providers",
    # Version
    "__version__",
]
