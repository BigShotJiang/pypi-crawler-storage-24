"""
memex/store.py
--------------
Namespaced persistent storage.

Backends (auto-detected):
  redis   → RedisStore    sub-ms, requires server
  sqlite  → SQLiteStore   ~1-3ms, zero infra, WAL, TTL
  memory  → MemoryStore   in-process, no persistence (tests)

Every key is scoped to a namespace so one database file
safely holds memory for multiple users and agents.

Namespace conventions:
  "default"                  single-user app
  "user:arjun"               all agents for this user
  "user:arjun:agent:coder"   specific agent conversation
  "org:acme"                 shared org-level knowledge
"""

import json
import os
import sqlite3
from abc import ABC, abstractmethod
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Optional


# ── Abstract base ─────────────────────────────────────────────────────────────

class BaseStore(ABC):
    backend: str = "base"

    @abstractmethod
    def set(self, key: str, value: Any, namespace: str = "default",
            ttl: Optional[int] = None) -> bool: ...

    @abstractmethod
    def get(self, key: str, namespace: str = "default",
            default: Any = None) -> Any: ...

    @abstractmethod
    def delete(self, key: str, namespace: str = "default") -> bool: ...

    @abstractmethod
    def exists(self, key: str, namespace: str = "default") -> bool: ...

    @abstractmethod
    def keys(self, pattern: str = "*", namespace: str = "default") -> list[str]: ...

    @abstractmethod
    def flush(self, namespace: str = "default") -> bool: ...

    @abstractmethod
    def namespaces(self) -> list[str]: ...

    @abstractmethod
    def stats(self) -> dict: ...


# ── SQLite backend ─────────────────────────────────────────────────────────────

class SQLiteStore(BaseStore):
    """
    SQLite KV store with:
    - WAL mode for fast concurrent reads
    - Namespace column — one DB, many users/agents
    - TTL expiry (checked on read, cleaned up periodically)
    - Optional sqlite-vec extension for vector search
    - Raw SQL access: store.query(sql, params)
    """
    backend = "sqlite"

    def __init__(self, path: str = ".memex.db"):
        import threading
        self.path      = os.path.abspath(path)
        self._lock     = threading.Lock()
        self._conn     = self._connect()
        self._vec_loaded = False
        self._init_schema()
        self._try_load_vec()
        print(f"[Store] 🗄️  SQLite → {self.path}")

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA cache_size=-64000")
        conn.execute("PRAGMA temp_store=MEMORY")
        conn.execute("PRAGMA foreign_keys=ON")
        return conn

    def _init_schema(self):
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS kv (
                namespace  TEXT NOT NULL DEFAULT 'default',
                key        TEXT NOT NULL,
                value      TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                expires_at TEXT,
                PRIMARY KEY (namespace, key)
            );
            CREATE INDEX IF NOT EXISTS idx_kv_ns  ON kv(namespace);
            CREATE INDEX IF NOT EXISTS idx_kv_exp ON kv(expires_at)
                WHERE expires_at IS NOT NULL;
        """)
        self._conn.commit()

    def _try_load_vec(self):
        """Try to load sqlite-vec extension for vector search."""
        try:
            import sqlite_vec
            self._conn.enable_load_extension(True)
            sqlite_vec.load(self._conn)
            self._conn.enable_load_extension(False)
            self._vec_loaded = True
            # Create vector table (will be populated by VectorStore)
            print("[Store] ⚡ sqlite-vec loaded — local ANN search enabled")
        except Exception:
            pass  # graceful fallback to cosine scan

    def _now(self) -> str:
        return datetime.utcnow().isoformat()

    def _is_expired(self, expires_at: Optional[str]) -> bool:
        return expires_at is not None and expires_at < self._now()

    # ── Core API ──────────────────────────────────────────────────────────────

    def set(self, key: str, value: Any, namespace: str = "default",
            ttl: Optional[int] = None) -> bool:
        expiry = (datetime.utcnow() + timedelta(seconds=ttl)).isoformat() if ttl else None
        with self._lock:
            self._conn.execute("""
                INSERT INTO kv (namespace, key, value, updated_at, expires_at)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(namespace, key) DO UPDATE SET
                  value=excluded.value,
                  updated_at=excluded.updated_at,
                  expires_at=excluded.expires_at
            """, (namespace, key, json.dumps(value), self._now(), expiry))
            self._conn.commit()
        return True

    def get(self, key: str, namespace: str = "default", default: Any = None) -> Any:
        with self._lock:
            row = self._conn.execute(
                "SELECT value, expires_at FROM kv WHERE namespace=? AND key=?",
                (namespace, key)
            ).fetchone()
        if row is None:
            return default
        if self._is_expired(row["expires_at"]):
            self.delete(key, namespace)
            return default
        return json.loads(row["value"])

    def delete(self, key: str, namespace: str = "default") -> bool:
        with self._lock:
            cur = self._conn.execute(
                "DELETE FROM kv WHERE namespace=? AND key=?", (namespace, key)
            )
            self._conn.commit()
        return cur.rowcount > 0

    def exists(self, key: str, namespace: str = "default") -> bool:
        with self._lock:
            row = self._conn.execute(
                "SELECT 1 FROM kv WHERE namespace=? AND key=? "
                "AND (expires_at IS NULL OR expires_at > ?)",
                (namespace, key, self._now())
            ).fetchone()
        return row is not None

    def keys(self, pattern: str = "*", namespace: str = "default") -> list[str]:
        like = pattern.replace("*", "%").replace("?", "_")
        with self._lock:
            rows = self._conn.execute(
                "SELECT key FROM kv WHERE namespace=? AND key LIKE ? "
                "AND (expires_at IS NULL OR expires_at > ?)",
                (namespace, like, self._now())
            ).fetchall()
        return [r["key"] for r in rows]

    def flush(self, namespace: str = "default") -> bool:
        with self._lock:
            self._conn.execute("DELETE FROM kv WHERE namespace=?", (namespace,))
            self._conn.commit()
        return True

    def flush_all(self) -> bool:
        with self._lock:
            self._conn.execute("DELETE FROM kv")
            self._conn.commit()
        return True

    def namespaces(self) -> list[str]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT DISTINCT namespace FROM kv ORDER BY namespace"
            ).fetchall()
        return [r["namespace"] for r in rows]

    def query(self, sql: str, params=()) -> list[sqlite3.Row]:
        """Raw SQL access for advanced queries."""
        with self._lock:
            return self._conn.execute(sql, params).fetchall()

    def stats(self) -> dict:
        total = self._conn.execute("SELECT COUNT(*) as n FROM kv").fetchone()["n"]
        ns_counts = self._conn.execute(
            "SELECT namespace, COUNT(*) as n FROM kv GROUP BY namespace"
        ).fetchall()
        size = os.path.getsize(self.path) if os.path.exists(self.path) else 0
        return {
            "backend":     "sqlite",
            "path":        self.path,
            "total_keys":  total,
            "file_size":   f"{size / 1024:.1f} KB",
            "sqlite_vec":  self._vec_loaded,
            "namespaces":  {r["namespace"]: r["n"] for r in ns_counts},
        }


# ── Redis backend ──────────────────────────────────────────────────────────────

class RedisStore(BaseStore):
    backend = "redis"

    def __init__(self, redis_url: str = "redis://localhost:6379"):
        import redis as redis_lib
        self._r = redis_lib.from_url(
            redis_url, decode_responses=True, socket_connect_timeout=1
        )
        self._r.ping()
        self.redis_url = redis_url
        print(f"[Store] ⚡ Redis → {redis_url}")

    def _k(self, namespace: str, key: str) -> str:
        return f"{namespace}:{key}"

    def set(self, key: str, value: Any, namespace: str = "default",
            ttl: Optional[int] = None) -> bool:
        payload = json.dumps({"v": value, "ts": datetime.utcnow().isoformat()})
        rkey    = self._k(namespace, key)
        if ttl:
            self._r.setex(rkey, ttl, payload)
        else:
            self._r.set(rkey, payload)
        return True

    def get(self, key: str, namespace: str = "default", default: Any = None) -> Any:
        raw = self._r.get(self._k(namespace, key))
        return json.loads(raw)["v"] if raw else default

    def delete(self, key: str, namespace: str = "default") -> bool:
        return bool(self._r.delete(self._k(namespace, key)))

    def exists(self, key: str, namespace: str = "default") -> bool:
        return bool(self._r.exists(self._k(namespace, key)))

    def keys(self, pattern: str = "*", namespace: str = "default") -> list[str]:
        prefix = f"{namespace}:"
        raw    = self._r.keys(f"{prefix}{pattern}")
        return [k[len(prefix):] for k in raw]

    def flush(self, namespace: str = "default") -> bool:
        keys = self._r.keys(f"{namespace}:*")
        if keys:
            self._r.delete(*keys)
        return True

    def namespaces(self) -> list[str]:
        all_keys = self._r.keys("*")
        return list({k.rsplit(":", 1)[0] for k in all_keys if ":" in k})

    def stats(self) -> dict:
        info = self._r.info("memory")
        return {
            "backend":     "redis",
            "url":         self.redis_url,
            "total_keys":  self._r.dbsize(),
            "used_memory": info.get("used_memory_human", "?"),
        }


# ── In-memory (testing) ────────────────────────────────────────────────────────

class MemoryStore(BaseStore):
    backend = "memory"

    def __init__(self):
        self._data: dict[tuple, Any] = {}
        print("[Store] 💭 In-memory (no persistence)")

    def _k(self, ns: str, key: str):
        return (ns, key)

    def set(self, key: str, value: Any, namespace: str = "default",
            ttl: Optional[int] = None) -> bool:
        self._data[self._k(namespace, key)] = value
        return True

    def get(self, key: str, namespace: str = "default", default: Any = None) -> Any:
        return self._data.get(self._k(namespace, key), default)

    def delete(self, key: str, namespace: str = "default") -> bool:
        return self._data.pop(self._k(namespace, key), None) is not None

    def exists(self, key: str, namespace: str = "default") -> bool:
        return self._k(namespace, key) in self._data

    def keys(self, pattern: str = "*", namespace: str = "default") -> list[str]:
        import fnmatch
        return [k for ns, k in self._data if ns == namespace
                and fnmatch.fnmatch(k, pattern)]

    def flush(self, namespace: str = "default") -> bool:
        for k in list(self._data):
            if k[0] == namespace:
                del self._data[k]
        return True

    def namespaces(self) -> list[str]:
        return list({ns for ns, _ in self._data})

    def stats(self) -> dict:
        return {"backend": "memory", "total_keys": len(self._data)}


# ── Factory ────────────────────────────────────────────────────────────────────

def get_store(backend: str = "auto", **kwargs) -> BaseStore:
    """
    Get a store instance.

    Args:
        backend: "auto" | "sqlite" | "redis" | "memory"
        path:      SQLite DB path (default ".memex.db")
        redis_url: Redis connection URL

    Auto: tries Redis first, falls back to SQLite.
    """
    if backend == "sqlite":
        return SQLiteStore(path=kwargs.get("path", ".memex.db"))
    if backend == "redis":
        return RedisStore(redis_url=kwargs.get("redis_url", "redis://localhost:6379"))
    if backend == "memory":
        return MemoryStore()
    if backend == "auto":
        try:
            return RedisStore(redis_url=kwargs.get("redis_url", "redis://localhost:6379"))
        except Exception:
            return SQLiteStore(path=kwargs.get("path", ".memex.db"))
    raise ValueError(f"Unknown backend: {backend!r}")
