"""
memex/extractor.py
------------------
Passive memory extraction — extracts facts from a completed
conversation exchange WITHOUT modifying the user's LLM prompts.

This is the key design difference from v0.1-v0.3:
  OLD: inject <memory> tag instructions into system prompt
  NEW: after the LLM responds, send the exchange to a cheap
       extraction call separately — the user's main LLM is untouched.

Two extraction modes:
  LLMExtractor   — uses a small/cheap LLM call, high quality
  RuleExtractor  — regex heuristics, zero cost, lower quality
                   (fallback when no LLM available)
"""

import re
from abc import ABC, abstractmethod
from typing import Optional
from .providers.base import LLMProvider


EXTRACT_PROMPT = """Extract important long-term facts from this conversation exchange.

Only extract facts that are:
- Durable (still true in a week/month)
- About the user (name, preferences, goals, skills, context)
- Specific enough to be useful

Conversation:
User: {user_msg}
Assistant: {assistant_msg}

Reply with ONLY a JSON array of fact strings. Each under 150 chars.
If nothing worth remembering: reply []
No explanation. No markdown.

Examples of good facts:
["User's name is Arjun", "User prefers Python over JavaScript", "User is building a SaaS in Mumbai"]

Examples of bad facts (skip these):
["User said hello", "User asked a question", "Assistant helped"]"""


EXTRACT_EPISODE_PROMPT = """Summarize this conversation into a compact episode record.

Conversation:
{conversation}

Reply with ONLY a JSON object:
{{
  "summary": "2-3 sentence summary of what was discussed and accomplished",
  "topics": ["topic1", "topic2"],
  "outcome": "what was resolved/learned/decided (or 'unresolved')",
  "mood": "user sentiment: positive/neutral/frustrated/excited"
}}
No explanation. No markdown fences."""


class BaseExtractor(ABC):
    @abstractmethod
    def extract_facts(self, user_msg: str, assistant_msg: str) -> list[str]:
        """Extract facts from a single exchange."""
        ...

    @abstractmethod
    def extract_episode(self, conversation: list[dict]) -> Optional[dict]:
        """Summarize a full conversation into an episode."""
        ...


class LLMExtractor(BaseExtractor):
    """
    Uses a small LLM call to extract facts after each exchange.
    Runs in background — never blocks the main agent response.
    """

    def __init__(self, llm: LLMProvider):
        self.llm = llm

    def extract_facts(self, user_msg: str, assistant_msg: str) -> list[str]:
        import json
        raw = self.llm.chat(
            messages=[{"role": "user", "content": EXTRACT_PROMPT.format(
                user_msg=user_msg[:1000],
                assistant_msg=assistant_msg[:500],
            )}],
            max_tokens=400,
        )
        raw = raw.strip()
        if raw.startswith("```"):
            raw = raw.split("\n", 1)[-1].rsplit("```", 1)[0].strip()
        try:
            facts = json.loads(raw)
            return [str(f).strip() for f in facts if isinstance(f, str) and f.strip()]
        except Exception:
            return []

    def extract_episode(self, conversation: list[dict]) -> Optional[dict]:
        import json
        if len(conversation) < 2:
            return None
        convo_text = "\n".join(
            f"{m['role'].title()}: {m['content'][:300]}"
            for m in conversation[-20:]  # cap at last 20 messages
        )
        raw = self.llm.chat(
            messages=[{"role": "user", "content": EXTRACT_EPISODE_PROMPT.format(
                conversation=convo_text
            )}],
            max_tokens=400,
        )
        raw = raw.strip()
        if raw.startswith("```"):
            raw = raw.split("\n", 1)[-1].rsplit("```", 1)[0].strip()
        try:
            ep = json.loads(raw)
            assert "summary" in ep
            return ep
        except Exception:
            return None


class RuleExtractor(BaseExtractor):
    """
    Zero-cost heuristic extraction using regex patterns.
    Lower quality than LLM extraction but works with no API calls.
    Used as fallback when no LLM extractor is configured.
    """

    # Patterns that strongly suggest a memorable fact
    PATTERNS = [
        (r"\bmy name is ([A-Z][a-z]+)\b",          "User's name is {}"),
        (r"\bi(?:'m| am) (?:a |an )?([^,.!?]{3,40})", "User is {}"),
        (r"\bi (?:work|live|study) (?:at|in|for) ([^,.!?]{3,40})", "User {} at {}"),
        (r"\bi (?:prefer|love|hate|use|like) ([^,.!?]{3,40})", "User prefers {}"),
        (r"\bmy (?:email|phone|location|city) is ([^,.!?]{3,40})", "User's {} is {}"),
    ]

    def extract_facts(self, user_msg: str, assistant_msg: str) -> list[str]:
        facts = []
        text  = user_msg.lower()
        for pattern, template in self.PATTERNS:
            m = re.search(pattern, text, re.IGNORECASE)
            if m:
                try:
                    facts.append(template.format(*m.groups()))
                except Exception:
                    facts.append(m.group(0))
        return facts[:3]  # cap at 3 per exchange

    def extract_episode(self, conversation: list[dict]) -> Optional[dict]:
        # Rule-based episode: just count turns and topics
        if len(conversation) < 2:
            return None
        topics = set()
        for m in conversation:
            words = re.findall(r"\b[a-z]{5,}\b", m.get("content", "").lower())
            topics.update(words[:3])
        return {
            "summary": f"Conversation with {len(conversation)} messages.",
            "topics":  list(topics)[:5],
            "outcome": "unknown",
            "mood":    "neutral",
        }


def get_extractor(llm: Optional[LLMProvider] = None) -> BaseExtractor:
    """Get the best available extractor."""
    if llm is not None:
        return LLMExtractor(llm)
    return RuleExtractor()
