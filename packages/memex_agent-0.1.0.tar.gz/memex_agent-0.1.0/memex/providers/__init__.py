"""
memex/providers/__init__.py
---------------------------
Model-agnostic LLM provider layer.

Supported providers (auto-detected from env vars):
  - Anthropic   (ANTHROPIC_API_KEY)       claude-3-5-haiku, claude-3-5-sonnet, ...
  - OpenAI      (OPENAI_API_KEY)          gpt-4o-mini, gpt-4o, ...
  - OpenRouter  (OPENROUTER_API_KEY)      any model via openrouter.ai
  - Ollama      (OLLAMA_HOST, optional)   llama3, mistral, gemma, ... (local)
  - Gemini      (GEMINI_API_KEY)          gemini-flash, gemini-pro, ...

All providers expose the same interface:
    provider.chat(messages, system, max_tokens) -> str

Usage:
    from memex.providers import get_provider, LLMProvider

    # Auto-detect from env
    llm = get_provider()

    # Explicit
    llm = get_provider("openrouter", model="google/gemini-flash-1.5")
    llm = get_provider("ollama", model="llama3.2")
    llm = get_provider("anthropic", model="claude-3-5-haiku-20241022")
"""

from .base import LLMProvider, Message
from .anthropic_provider import AnthropicProvider
from .openai_provider import OpenAIProvider
from .openrouter_provider import OpenRouterProvider
from .ollama_provider import OllamaProvider
from .gemini_provider import GeminiProvider

import os

# Registry of all providers
_PROVIDERS = {
    "anthropic":  AnthropicProvider,
    "openai":     OpenAIProvider,
    "openrouter": OpenRouterProvider,
    "ollama":     OllamaProvider,
    "gemini":     GeminiProvider,
}

# Default models per provider
_DEFAULTS = {
    "anthropic":  "claude-3-5-haiku-20241022",
    "openai":     "gpt-4o-mini",
    "openrouter": "anthropic/claude-3-haiku",
    "ollama":     "llama3.2",
    "gemini":     "gemini-1.5-flash",
}


def get_provider(name: str = "auto", model: str | None = None, **kwargs) -> LLMProvider:
    """
    Get a provider by name, or auto-detect from environment variables.

    Args:
        name:   Provider name or "auto"
        model:  Model string override (optional)
        **kwargs: Passed to provider constructor (e.g. api_key, base_url)

    Returns:
        Configured LLMProvider instance

    Raises:
        EnvironmentError: if name="auto" and no provider is available
    """
    if name == "auto":
        name, model = _auto_detect(model)

    if name not in _PROVIDERS:
        raise ValueError(
            f"Unknown provider '{name}'. "
            f"Available: {list(_PROVIDERS.keys())}"
        )

    resolved_model = model or _DEFAULTS[name]
    provider = _PROVIDERS[name](model=resolved_model, **kwargs)
    print(f"[LLM] 🤖 {name} / {resolved_model}")
    return provider


def _auto_detect(requested_model: str | None = None) -> tuple[str, str | None]:
    """
    Detect an available provider from the environment.
    Returns (provider_name, model_or_None).
    Raises EnvironmentError if nothing is available.
    """
    if os.getenv("ANTHROPIC_API_KEY"):
        return "anthropic", requested_model
    if os.getenv("OPENROUTER_API_KEY"):
        return "openrouter", requested_model
    if os.getenv("OPENAI_API_KEY"):
        return "openai", requested_model
    if os.getenv("GEMINI_API_KEY"):
        return "gemini", requested_model

    # Try Ollama — verify server is up AND at least one model is pulled
    try:
        import json, urllib.request
        host = os.getenv("OLLAMA_HOST", "http://localhost:11434")
        resp = urllib.request.urlopen(f"{host}/api/tags", timeout=1)
        data = json.loads(resp.read())
        pulled = [m["name"] for m in data.get("models", [])]
        if pulled:
            # Use requested model if specified and available, else first pulled model
            if requested_model and any(requested_model in p for p in pulled):
                return "ollama", requested_model
            default = _DEFAULTS["ollama"]
            if any(default in p for p in pulled):
                return "ollama", default
            # Fall back to whatever is actually installed
            return "ollama", pulled[0]
        # Ollama is running but no models pulled
    except Exception:
        pass

    raise EnvironmentError(
        "No LLM provider detected. Options:\n"
        "  export ANTHROPIC_API_KEY=sk-ant-...\n"
        "  export OPENAI_API_KEY=sk-...\n"
        "  export OPENROUTER_API_KEY=sk-or-...\n"
        "  export GEMINI_API_KEY=...\n"
        "  ollama serve && ollama pull llama3.2   # free, local"
    )


def list_providers() -> dict:
    """Return available providers and their status."""
    status = {}
    for name in _PROVIDERS:
        key_map = {
            "anthropic":  "ANTHROPIC_API_KEY",
            "openai":     "OPENAI_API_KEY",
            "openrouter": "OPENROUTER_API_KEY",
            "gemini":     "GEMINI_API_KEY",
            "ollama":     None,
        }
        env = key_map.get(name)
        if env:
            status[name] = "✅ configured" if os.getenv(env) else "❌ no API key"
        else:
            status[name] = "⚙️  local (no key needed)"
    return status


__all__ = [
    "LLMProvider", "Message", "get_provider", "list_providers",
    "AnthropicProvider", "OpenAIProvider", "OpenRouterProvider",
    "OllamaProvider", "GeminiProvider",
]
