"""memex/providers/openai_provider.py"""
import os
from .base import LLMProvider


class OpenAIProvider(LLMProvider):
    """OpenAI — gpt-4o-mini, gpt-4o, o1-mini, ..."""

    def __init__(self, model: str = "gpt-4o-mini",
                 api_key: str | None = None,
                 base_url: str | None = None, **kwargs):
        super().__init__(model)
        from openai import OpenAI
        self._client = OpenAI(
            api_key=api_key or os.getenv("OPENAI_API_KEY"),
            base_url=base_url,
        )

    def chat(self, messages: list[dict], system: str = "", max_tokens: int = 1024) -> str:
        full_messages = []
        if system:
            full_messages.append({"role": "system", "content": system})
        full_messages.extend(messages)

        resp = self._client.chat.completions.create(
            model=self.model,
            max_tokens=max_tokens,
            messages=full_messages,
        )
        return resp.choices[0].message.content
