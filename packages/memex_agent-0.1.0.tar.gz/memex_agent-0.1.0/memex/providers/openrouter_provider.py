"""
memex/providers/openrouter_provider.py
--------------------------------------
OpenRouter gives access to 200+ models through a single OpenAI-compatible API.
https://openrouter.ai/models

Popular models:
  anthropic/claude-3-haiku          (fast, cheap)
  anthropic/claude-3.5-sonnet       (smart)
  google/gemini-flash-1.5           (fast, multimodal)
  google/gemini-pro-1.5             (powerful)
  meta-llama/llama-3.2-3b-instruct  (free tier available)
  mistralai/mistral-7b-instruct     (fast, free tier)
  deepseek/deepseek-chat            (very cheap)
  qwen/qwen-2.5-72b-instruct        (strong open model)
  openai/gpt-4o-mini                (OpenAI via OpenRouter)
"""

import os
from .base import LLMProvider

OPENROUTER_BASE = "https://openrouter.ai/api/v1"


class OpenRouterProvider(LLMProvider):
    """
    OpenRouter — route to any of 200+ models with one API key.
    Uses the OpenAI-compatible SDK.
    """

    def __init__(
        self,
        model:   str = "anthropic/claude-3-haiku",
        api_key: str | None = None,
        site_url: str = "https://github.com/your-org/memex-agent",
        site_name: str = "Memex Agent",
        **kwargs,
    ):
        super().__init__(model)
        from openai import OpenAI
        self._client = OpenAI(
            api_key=api_key or os.getenv("OPENROUTER_API_KEY"),
            base_url=OPENROUTER_BASE,
            default_headers={
                "HTTP-Referer": site_url,
                "X-Title": site_name,
            },
        )

    def chat(self, messages: list[dict], system: str = "", max_tokens: int = 1024) -> str:
        full_messages = []
        if system:
            full_messages.append({"role": "system", "content": system})
        full_messages.extend(messages)

        resp = self._client.chat.completions.create(
            model=self.model,
            max_tokens=max_tokens,
            messages=full_messages,
        )
        return resp.choices[0].message.content
