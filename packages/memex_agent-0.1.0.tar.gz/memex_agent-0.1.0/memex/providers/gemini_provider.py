"""memex/providers/gemini_provider.py"""
import os
from .base import LLMProvider


class GeminiProvider(LLMProvider):
    """Google Gemini — gemini-1.5-flash, gemini-1.5-pro, gemini-2.0-flash, ..."""

    def __init__(self, model: str = "gemini-1.5-flash",
                 api_key: str | None = None, **kwargs):
        super().__init__(model)
        import google.generativeai as genai
        genai.configure(api_key=api_key or os.getenv("GEMINI_API_KEY"))
        self._genai = genai

    def chat(self, messages: list[dict], system: str = "", max_tokens: int = 1024) -> str:
        cfg = self._genai.types.GenerationConfig(max_output_tokens=max_tokens)
        model = self._genai.GenerativeModel(
            model_name=self.model,
            system_instruction=system or None,
            generation_config=cfg,
        )
        # Convert to Gemini format
        history = []
        for m in messages[:-1]:
            history.append({
                "role": "user" if m["role"] == "user" else "model",
                "parts": [m["content"]],
            })
        chat = model.start_chat(history=history)
        resp = chat.send_message(messages[-1]["content"])
        return resp.text
