"""
memex/providers/ollama_provider.py
-----------------------------------
Ollama — run models locally, zero API cost, full privacy.
https://ollama.ai

Install: curl -fsSL https://ollama.ai/install.sh | sh
Models:  ollama pull llama3.2 / mistral / gemma2 / qwen2.5 / phi3

Popular models for memory agents:
  llama3.2       — fast, 3B, good instruction following
  llama3.1:8b    — stronger, still fast on CPU
  mistral        — excellent reasoning, 7B
  gemma2:9b      — Google's open model, very capable
  qwen2.5:7b     — strong multilingual
  phi3:mini      — very fast, 3.8B
"""

import os
import json
import urllib.request
import urllib.error
from .base import LLMProvider


class OllamaProvider(LLMProvider):
    """
    Ollama local inference — no API key, runs on your machine.
    Supports any model you've pulled via `ollama pull <model>`.
    """

    def __init__(
        self,
        model:    str = "llama3.2",
        host:     str | None = None,
        **kwargs,
    ):
        super().__init__(model)
        self.host = (host or os.getenv("OLLAMA_HOST", "http://localhost:11434")).rstrip("/")
        self._verify_connection()

    def _verify_connection(self):
        try:
            urllib.request.urlopen(f"{self.host}/api/tags", timeout=2)
        except urllib.error.URLError:
            raise ConnectionError(
                f"Ollama not reachable at {self.host}. "
                "Start it with: ollama serve"
            )

    def chat(self, messages: list[dict], system: str = "", max_tokens: int = 1024) -> str:
        payload = {
            "model":    self.model,
            "messages": messages,
            "stream":   False,
            "options":  {"num_predict": max_tokens},
        }
        if system:
            payload["system"] = system

        data    = json.dumps(payload).encode()
        req     = urllib.request.Request(
            f"{self.host}/api/chat",
            data=data,
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=120) as resp:
            result = json.loads(resp.read())
        return result["message"]["content"]
