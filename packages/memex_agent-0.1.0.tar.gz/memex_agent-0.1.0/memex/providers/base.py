"""
memex/providers/base.py
-----------------------
Abstract base class all providers must implement.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional


@dataclass
class Message:
    role: str     # "user" | "assistant" | "system"
    content: str


class LLMProvider(ABC):
    """
    Minimal interface every provider must implement.
    One method: chat() → str.
    """

    def __init__(self, model: str, **kwargs):
        self.model = model

    @abstractmethod
    def chat(
        self,
        messages: list[dict],        # [{"role": ..., "content": ...}]
        system:   str = "",
        max_tokens: int = 1024,
    ) -> str:
        """Send messages and return the assistant reply as a string."""
        ...

    def __repr__(self):
        return f"{self.__class__.__name__}(model={self.model!r})"
