"""memex/providers/anthropic_provider.py"""
import os
from .base import LLMProvider


class AnthropicProvider(LLMProvider):
    """Anthropic Claude — claude-3-5-haiku, claude-3-5-sonnet, claude-opus-4, ..."""

    def __init__(self, model: str = "claude-3-5-haiku-20241022",
                 api_key: str | None = None, **kwargs):
        super().__init__(model)
        import anthropic
        self._client = anthropic.Anthropic(api_key=api_key or os.getenv("ANTHROPIC_API_KEY"))

    def chat(self, messages: list[dict], system: str = "", max_tokens: int = 1024) -> str:
        resp = self._client.messages.create(
            model=self.model,
            max_tokens=max_tokens,
            system=system,
            messages=messages,
        )
        return resp.content[0].text
