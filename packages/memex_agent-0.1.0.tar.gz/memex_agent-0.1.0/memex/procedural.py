"""
memex/procedural.py
--------------------
Procedural memory — the agent learns HOW to behave better over time.

Unlike semantic (facts about user) and episodic (past conversations),
procedural memory stores learned BEHAVIORS:
  "User always wants code examples → always include them"
  "User prefers bullet points → format responses as lists"
  "User is an expert, skip basics → assume deep knowledge"

How it works:
  1. Observe: track implicit satisfaction signals per turn
     (short ack = likely satisfied, "no that's wrong" = not)
  2. Accumulate: collect observations over N sessions
  3. Analyze: ask LLM to find patterns and propose prompt patches
  4. Apply: developer reviews + applies patches (never automatic)
  5. Rollback: if things get worse, revert to previous version

Design principles:
  - Additive patches only (never full rewrites)
  - Developer stays in the loop (suggest, not auto-apply)
  - Conservative (require pattern across 3+ sessions before suggesting)
  - Versioned (every prompt version stored, rollback available)
"""

import json
import uuid
from datetime import datetime
from typing import Optional
from .store import BaseStore
from .providers.base import LLMProvider


ANALYZE_PROMPT = """You are analyzing an AI agent's conversation history to improve its system prompt.

Below are observations from {n_sessions} recent sessions with this user.
Each observation notes what worked well and what didn't.

Observations:
{observations}

Current system prompt addition (if any):
{current_patch}

Based on these patterns, suggest 1-3 SMALL, SPECIFIC improvements to the system prompt.
Each suggestion should:
- Be a single concise instruction (under 100 chars)
- Address a clear pattern seen in multiple sessions
- Be additive (don't remove existing instructions)

Reply ONLY with a JSON object:
{{
  "patches": ["instruction 1", "instruction 2"],
  "reasoning": "brief explanation of patterns found",
  "confidence": 0.0-1.0
}}
No markdown. No explanation outside the JSON."""


OBS_KEY   = "memex:procedural:observations"
PATCH_KEY = "memex:procedural:patches"
HIST_KEY  = "memex:procedural:history"


class ProceduralMemory:
    """
    Tracks agent behavior patterns and suggests system prompt improvements.

    Usage:
        proc = ProceduralMemory(store, llm, namespace="user:arjun")

        # During conversation — record observations
        proc.observe(user_msg, assistant_msg, satisfied=True)

        # Periodically (or on demand) — analyze and get suggestions
        suggestions = proc.analyze()
        print(suggestions["patches"])  # review these

        # If you like them:
        proc.apply(suggestions)

        # In your system prompt:
        extra = proc.as_context()  # inject learned behaviors
    """

    MIN_SESSIONS_TO_SUGGEST = 3   # require patterns across 3+ sessions
    MAX_OBSERVATIONS        = 200  # keep rolling window

    def __init__(
        self,
        store:     BaseStore,
        llm:       LLMProvider,
        namespace: str = "default",
    ):
        self.store = store
        self.llm   = llm
        self.ns    = namespace
        self._session_obs: list[dict] = []   # current session buffer

    # ── Observation ───────────────────────────────────────────────────────────

    def observe(self, user_msg: str, assistant_msg: str,
                satisfied: Optional[bool] = None):
        """
        Record an observation about a conversation turn.

        satisfied=True   → user seemed happy (explicit thanks, short ack)
        satisfied=False  → user seemed unhappy (correction, "no", "wrong")
        satisfied=None   → unknown / neutral
        """
        obs = {
            "user_msg":      user_msg[:200],
            "assistant_msg": assistant_msg[:200],
            "satisfied":     satisfied,
            "ts":            datetime.utcnow().isoformat(),
        }
        self._session_obs.append(obs)

    def infer_satisfaction(self, user_msg: str) -> Optional[bool]:
        """
        Heuristically infer if user was satisfied by their follow-up.
        Call this with the NEXT user message to infer satisfaction
        about the PREVIOUS assistant message.
        """
        msg   = user_msg.lower().strip()
        happy = ["thanks", "perfect", "great", "exactly", "yes", "correct",
                 "awesome", "nice", "got it", "that works", "helpful"]
        unhappy = ["no", "wrong", "that's not", "not right", "incorrect",
                   "that's wrong", "not what i", "doesn't work", "error"]

        for w in happy:
            if w in msg:
                return True
        for w in unhappy:
            if w in msg:
                return False
        return None

    def flush_session(self):
        """Persist current session observations to store."""
        if not self._session_obs:
            return
        all_obs = self.store.get(OBS_KEY, namespace=self.ns, default=[])
        all_obs.extend(self._session_obs)
        if len(all_obs) > self.MAX_OBSERVATIONS:
            all_obs = all_obs[-self.MAX_OBSERVATIONS:]
        self.store.set(OBS_KEY, all_obs, namespace=self.ns)
        self._session_obs = []

    # ── Analysis ─────────────────────────────────────────────────────────────

    def analyze(self) -> Optional[dict]:
        """
        Analyze observations and suggest prompt improvements.
        Returns None if not enough data yet.
        """
        self.flush_session()
        all_obs = self.store.get(OBS_KEY, namespace=self.ns, default=[])

        # Need minimum observations to make suggestions
        if len(all_obs) < self.MIN_SESSIONS_TO_SUGGEST * 3:
            return None

        # Format observations for LLM
        obs_text = "\n".join(
            f"- [{o['ts'][:10]}] {'✓' if o['satisfied'] else '✗' if o['satisfied'] is False else '?'} "
            f"User: {o['user_msg'][:80]}"
            for o in all_obs[-50:]  # analyze last 50
        )

        current = self.get_current_patch()
        raw = self.llm.chat(
            messages=[{"role": "user", "content": ANALYZE_PROMPT.format(
                n_sessions   = max(1, len(all_obs) // 5),
                observations = obs_text,
                current_patch= current or "(none)",
            )}],
            max_tokens=500,
        )
        raw = raw.strip()
        if raw.startswith("```"):
            raw = raw.split("\n", 1)[-1].rsplit("```", 1)[0].strip()
        try:
            result = json.loads(raw)
            result["generated_at"] = datetime.utcnow().isoformat()
            return result
        except Exception:
            return None

    # ── Apply / Rollback ──────────────────────────────────────────────────────

    def apply(self, suggestion: dict) -> str:
        """
        Apply a suggestion returned by analyze().
        Saves previous version for rollback.
        Returns the new patch string.
        """
        patches  = suggestion.get("patches", [])
        new_text = "\n".join(f"- {p}" for p in patches)

        # Save to history for rollback
        history = self.store.get(HIST_KEY, namespace=self.ns, default=[])
        history.append({
            "patch":      self.get_current_patch(),
            "applied_at": datetime.utcnow().isoformat(),
        })
        self.store.set(HIST_KEY, history, namespace=self.ns)

        # Save new patch
        self.store.set(PATCH_KEY, new_text, namespace=self.ns)
        print(f"  🧠 Procedural patch applied ({len(patches)} rules)")
        return new_text

    def rollback(self) -> bool:
        """Revert to the previous prompt patch."""
        history = self.store.get(HIST_KEY, namespace=self.ns, default=[])
        if not history:
            return False
        prev = history.pop()
        self.store.set(PATCH_KEY, prev["patch"] or "", namespace=self.ns)
        self.store.set(HIST_KEY, history, namespace=self.ns)
        print("  ↩️  Procedural memory rolled back")
        return True

    def get_current_patch(self) -> str:
        return self.store.get(PATCH_KEY, namespace=self.ns, default="") or ""

    def as_context(self) -> str:
        """Return learned behaviors for injection into system prompt."""
        patch = self.get_current_patch()
        if not patch:
            return ""
        return f"\n\n## Learned behaviors for this user:\n{patch}"

    def stats(self) -> dict:
        obs     = self.store.get(OBS_KEY, namespace=self.ns, default=[])
        history = self.store.get(HIST_KEY, namespace=self.ns, default=[])
        return {
            "observations":     len(obs) + len(self._session_obs),
            "patch_versions":   len(history) + 1,
            "current_patch":    bool(self.get_current_patch()),
        }

    def clear(self):
        self.store.delete(OBS_KEY, namespace=self.ns)
        self.store.delete(PATCH_KEY, namespace=self.ns)
        self.store.delete(HIST_KEY, namespace=self.ns)
        self._session_obs = []
