"""
memex/embedder.py
-----------------
Embedding engine — fully model-agnostic.

Built-in implementations:
  TFIDFEmbedder                zero deps, zero cost, good for <1k facts
  SentenceTransformerEmbedder  any HuggingFace model, local, free
  OpenAIEmbedder               text-embedding-3-small/large, or any OpenAI-compat API
  OllamaEmbedder               any Ollama model (local, free, private)
  CohereEmbedder               embed-v4.0, multilingual

Bring your own:
  class MyEmbedder(BaseEmbedder):
      def embed(self, text: str) -> List[float]: ...

Auto-detection via get_embedder():
  OPENAI_API_KEY set?            → OpenAIEmbedder (text-embedding-3-small)
  Ollama reachable?              → OllamaEmbedder (nomic-embed-text)
  sentence-transformers installed? → SentenceTransformerEmbedder
  fallback                       → TFIDFEmbedder
"""

import math
import os
import re
from abc import ABC, abstractmethod
from typing import List, Optional


# ── Base class ────────────────────────────────────────────────────────────────

class BaseEmbedder(ABC):
    """
    Abstract base for all embedding models.
    Subclass this to use any embedding model with Memex.
    """
    dim: int = 0

    @abstractmethod
    def embed(self, text: str) -> List[float]:
        """Embed a single string. Returns a float vector."""
        ...

    def embed_many(self, texts: List[str]) -> List[List[float]]:
        """Embed a list of strings. Override for native batching."""
        return [self.embed(t) for t in texts]

    @staticmethod
    def cosine(a: List[float], b: List[float]) -> float:
        """Cosine similarity between two vectors. Handles different dims."""
        if len(a) != len(b):
            n = max(len(a), len(b))
            a = a + [0.0] * (n - len(a))
            b = b + [0.0] * (n - len(b))
        dot = sum(x * y for x, y in zip(a, b))
        na  = math.sqrt(sum(x * x for x in a))
        nb  = math.sqrt(sum(x * x for x in b))
        return dot / (na * nb) if na and nb else 0.0


# ── TF-IDF (zero-dep) ─────────────────────────────────────────────────────────

class TFIDFEmbedder(BaseEmbedder):
    """
    Zero-dependency TF-IDF bag-of-words embedder.
    No API key, no pip packages, works everywhere.
    Accuracy degrades past ~1k facts — use any other embedder for production.
    """

    def __init__(self):
        self._vocab: dict[str, int]   = {}
        self._idf:   dict[str, float] = {}
        self._ndocs  = 0
        self.dim     = 0

    def _tokenize(self, text: str) -> list[str]:
        return re.findall(r"[a-z]+", text.lower())

    def embed(self, text: str) -> List[float]:
        tokens = self._tokenize(text)
        self._ndocs += 1
        for t in set(tokens):
            if t not in self._vocab:
                self._vocab[t] = len(self._vocab)
            self._idf[t] = self._idf.get(t, 0) + 1
        self.dim = len(self._vocab)

        tf: dict[str, int] = {}
        for t in tokens:
            tf[t] = tf.get(t, 0) + 1
        total = max(len(tokens), 1)
        vec   = [0.0] * len(self._vocab)
        for t, cnt in tf.items():
            if t in self._vocab:
                tf_v  = cnt / total
                idf_v = math.log((self._ndocs + 1) / (self._idf.get(t, 0) + 1)) + 1
                vec[self._vocab[t]] = tf_v * idf_v
        return vec


# ── Sentence Transformers (local HuggingFace) ─────────────────────────────────

class SentenceTransformerEmbedder(BaseEmbedder):
    """
    Local embeddings via sentence-transformers (HuggingFace).
    pip install sentence-transformers

    Any model from https://huggingface.co/models?pipeline_tag=sentence-similarity

    Popular models:
      all-MiniLM-L6-v2             384-dim,  22MB,  fast, English       (default)
      all-mpnet-base-v2            768-dim,  420MB, better quality
      paraphrase-multilingual-MiniLM-L12-v2  384-dim, 50+ languages
      BAAI/bge-small-en-v1.5       384-dim,  strong retrieval benchmark
      BAAI/bge-large-en-v1.5       1024-dim, best local quality
    """

    def __init__(self, model_name: str = "all-MiniLM-L6-v2"):
        from sentence_transformers import SentenceTransformer
        self.model_name = model_name
        self._model     = SentenceTransformer(model_name)
        self.dim        = self._model.get_sentence_embedding_dimension()

    def embed(self, text: str) -> List[float]:
        return self._model.encode(text, normalize_embeddings=True).tolist()

    def embed_many(self, texts: List[str]) -> List[List[float]]:
        vecs = self._model.encode(texts, normalize_embeddings=True, batch_size=32)
        return [v.tolist() for v in vecs]


# ── OpenAI (and any OpenAI-compatible endpoint) ───────────────────────────────

class OpenAIEmbedder(BaseEmbedder):
    """
    OpenAI embedding API — or any OpenAI-compatible endpoint.
    pip install openai

    Models:
      text-embedding-3-small   1536-dim, cheapest, fast          (default)
      text-embedding-3-large   3072-dim, highest quality
      text-embedding-ada-002   1536-dim, legacy

    Works with Azure OpenAI, Together AI, or any compatible API via base_url.

    Examples:
      OpenAIEmbedder()
      OpenAIEmbedder(model="text-embedding-3-large")
      OpenAIEmbedder(base_url="https://api.together.xyz/v1", api_key="...")
    """

    DIM_MAP = {
        "text-embedding-3-small": 1536,
        "text-embedding-3-large": 3072,
        "text-embedding-ada-002": 1536,
    }

    def __init__(
        self,
        model:    str = "text-embedding-3-small",
        api_key:  Optional[str] = None,
        base_url: Optional[str] = None,
    ):
        from openai import OpenAI
        self.model   = model
        self._client = OpenAI(
            api_key  = api_key or os.getenv("OPENAI_API_KEY"),
            base_url = base_url,
        )
        self.dim = self.DIM_MAP.get(model, 1536)

    def embed(self, text: str) -> List[float]:
        resp = self._client.embeddings.create(input=[text], model=self.model)
        return resp.data[0].embedding

    def embed_many(self, texts: List[str]) -> List[List[float]]:
        resp = self._client.embeddings.create(input=texts, model=self.model)
        return [d.embedding for d in sorted(resp.data, key=lambda x: x.index)]


# ── Ollama (local, free, private) ─────────────────────────────────────────────

class OllamaEmbedder(BaseEmbedder):
    """
    Local embeddings via Ollama — no API key, fully private.
    Install: curl -fsSL https://ollama.ai/install.sh | sh

    Pull a model first:
      ollama pull nomic-embed-text    (recommended)
      ollama pull mxbai-embed-large
      ollama pull all-minilm

    Models:
      nomic-embed-text       768-dim,  fast, excellent quality  (default)
      mxbai-embed-large      1024-dim, best local quality
      all-minilm             384-dim,  very fast
      snowflake-arctic-embed 1024-dim, strong retrieval
    """

    def __init__(
        self,
        model: str = "nomic-embed-text",
        host:  Optional[str] = None,
    ):
        import urllib.request, urllib.error
        self.model = model
        self.host  = (host or os.getenv("OLLAMA_HOST", "http://localhost:11434")).rstrip("/")
        self.dim   = 768

        try:
            urllib.request.urlopen(f"{self.host}/api/tags", timeout=2)
        except urllib.error.URLError:
            raise ConnectionError(
                f"Ollama not reachable at {self.host}. "
                "Run: ollama serve && ollama pull nomic-embed-text"
            )

    def embed(self, text: str) -> List[float]:
        import json, urllib.request
        data = json.dumps({"model": self.model, "prompt": text}).encode()
        req  = urllib.request.Request(
            f"{self.host}/api/embeddings",
            data=data,
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read())
        vec = result["embedding"]
        self.dim = len(vec)
        return vec


# ── Cohere ────────────────────────────────────────────────────────────────────

class CohereEmbedder(BaseEmbedder):
    """
    Cohere embedding API — excellent multilingual support.
    pip install cohere

    Models:
      embed-v4.0                   1024-dim, latest, multilingual  (default)
      embed-multilingual-v3.0      1024-dim, 100+ languages
      embed-english-v3.0           1024-dim, English only, faster
    """

    def __init__(
        self,
        model:   str = "embed-v4.0",
        api_key: Optional[str] = None,
    ):
        import cohere
        self.model   = model
        self._client = cohere.Client(api_key or os.getenv("COHERE_API_KEY"))
        self.dim     = 1024

    def embed(self, text: str) -> List[float]:
        resp = self._client.embed(
            texts      = [text],
            model      = self.model,
            input_type = "search_document",
        )
        return resp.embeddings[0]

    def embed_many(self, texts: List[str]) -> List[List[float]]:
        resp = self._client.embed(
            texts      = texts,
            model      = self.model,
            input_type = "search_document",
        )
        return resp.embeddings


# ── Factory ───────────────────────────────────────────────────────────────────

def get_embedder(
    backend:  str = "auto",
    model:    Optional[str] = None,
    embedder: Optional[BaseEmbedder] = None,
    **kwargs,
) -> BaseEmbedder:
    """
    Get an embedder by backend name, or pass your own instance.

    Args:
        backend:  "auto" | "tfidf" | "sentence-transformers" |
                  "openai" | "ollama" | "cohere"
        model:    Model name override (backend-specific)
        embedder: Your own BaseEmbedder instance — returned directly

    Auto-detection order (backend="auto"):
      1. OPENAI_API_KEY in env  → OpenAIEmbedder (text-embedding-3-small)
      2. Ollama reachable       → OllamaEmbedder (nomic-embed-text)
      3. sentence-transformers  → SentenceTransformerEmbedder (all-MiniLM-L6-v2)
      4. fallback               → TFIDFEmbedder

    Examples:
        get_embedder()
        get_embedder("openai", model="text-embedding-3-large")
        get_embedder("ollama", model="mxbai-embed-large")
        get_embedder("sentence-transformers", model="BAAI/bge-small-en-v1.5")
        get_embedder(embedder=MyEmbedder())
    """
    if embedder is not None:
        if not isinstance(embedder, BaseEmbedder):
            raise TypeError(f"embedder must subclass BaseEmbedder, got {type(embedder)}")
        print(f"[Embedder] 🔌 Custom / {type(embedder).__name__}")
        return embedder

    if backend == "tfidf":
        print("[Embedder] 📊 TF-IDF (zero-dep)")
        return TFIDFEmbedder()

    if backend in ("sentence-transformers", "st"):
        m = model or "all-MiniLM-L6-v2"
        print(f"[Embedder] 🤖 sentence-transformers / {m}")
        return SentenceTransformerEmbedder(model_name=m)

    if backend == "openai":
        m = model or "text-embedding-3-small"
        print(f"[Embedder] ☁️  OpenAI / {m}")
        return OpenAIEmbedder(model=m, **kwargs)

    if backend == "ollama":
        m = model or "nomic-embed-text"
        print(f"[Embedder] 🦙 Ollama / {m}")
        return OllamaEmbedder(model=m, **kwargs)

    if backend == "cohere":
        m = model or "embed-v4.0"
        print(f"[Embedder] 🪄 Cohere / {m}")
        return CohereEmbedder(model=m, **kwargs)

    if backend == "auto":
        if os.getenv("OPENAI_API_KEY"):
            try:
                e = OpenAIEmbedder(model=model or "text-embedding-3-small")
                print(f"[Embedder] ☁️  OpenAI / {e.model} (auto-detected)")
                return e
            except Exception:
                pass
        try:
            e = OllamaEmbedder(model=model or "nomic-embed-text")
            print(f"[Embedder] 🦙 Ollama / {e.model} (auto-detected)")
            return e
        except Exception:
            pass
        try:
            m = model or "all-MiniLM-L6-v2"
            e = SentenceTransformerEmbedder(model_name=m)
            print(f"[Embedder] 🤖 sentence-transformers / {m} (auto-detected)")
            return e
        except ImportError:
            pass
        print("[Embedder] 📊 TF-IDF (zero-dep fallback — "
              "set OPENAI_API_KEY or run Ollama for better results)")
        return TFIDFEmbedder()

    raise ValueError(
        f"Unknown backend: {backend!r}. "
        "Use 'auto', 'tfidf', 'sentence-transformers', 'openai', 'ollama', or 'cohere'."
    )
