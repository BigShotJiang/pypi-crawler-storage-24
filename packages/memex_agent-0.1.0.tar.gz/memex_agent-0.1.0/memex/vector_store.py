"""
memex/vector_store.py
---------------------
Semantic vector search, namespace-aware.

Backends (auto-selected):
  1. Redis Vector (HNSW ANN)     — requires Redis Stack
  2. sqlite-vec (ANN in SQLite)  — requires sqlite-vec pip package
  3. Local cosine scan           — zero deps, O(n), fine for <5k facts

Vectors stored under namespace so one store serves multiple users/agents.
"""

import json
import struct
from typing import List, Optional
from .store import BaseStore
from .embedder import BaseEmbedder

VECTOR_KEY = "memex:vec:index"


class VectorStore:
    def __init__(self, store: BaseStore, embedder: BaseEmbedder):
        self.store    = store
        self.embedder = embedder
        self._use_redis_vec  = False
        self._use_sqlite_vec = False

        if store.backend == "redis":
            self._use_redis_vec = self._init_redis_vec()
        elif store.backend == "sqlite" and getattr(store, "_vec_loaded", False):
            self._use_sqlite_vec = self._init_sqlite_vec()

        backend = (
            "redis-vector"  if self._use_redis_vec  else
            "sqlite-vec"    if self._use_sqlite_vec else
            "cosine-scan"
        )
        print(f"[VectorStore] 🔍 {backend}")

    # ── Init ──────────────────────────────────────────────────────────────────

    def _init_redis_vec(self) -> bool:
        try:
            from redis.commands.search.field import VectorField, TextField
            from redis.commands.search.indexDefinition import IndexDefinition, IndexType
            dim = getattr(self.embedder, "dim", 384)
            r   = self.store._r
            try:
                r.ft("memex_vec_idx").info()
                return True
            except Exception:
                pass
            r.ft("memex_vec_idx").create_index(
                (
                    TextField("content"),
                    TextField("namespace"),
                    VectorField("embedding", "HNSW", {
                        "TYPE": "FLOAT32", "DIM": dim,
                        "DISTANCE_METRIC": "COSINE",
                        "M": 16, "EF_CONSTRUCTION": 200,
                    }),
                ),
                definition=IndexDefinition(
                    prefix=["memex:vec:"],
                    index_type=IndexType.HASH
                ),
            )
            return True
        except Exception:
            return False

    def _init_sqlite_vec(self) -> bool:
        try:
            dim = getattr(self.embedder, "dim", 384)
            self.store._conn.executescript(f"""
                CREATE VIRTUAL TABLE IF NOT EXISTS vec_facts
                USING vec0(embedding FLOAT[{dim}]);
            """)
            self.store._conn.commit()
            return True
        except Exception:
            return False

    # ── Core API ──────────────────────────────────────────────────────────────

    def add(self, fact_id: str, content: str, namespace: str = "default",
            vector: Optional[List[float]] = None):
        vec = vector or self.embedder.embed(content)

        if self._use_redis_vec:
            packed = struct.pack(f"{len(vec)}f", *vec)
            self.store._r.hset(f"memex:vec:{namespace}:{fact_id}", mapping={
                "content": content, "namespace": namespace,
                "fact_id": fact_id, "embedding": packed,
            })
        elif self._use_sqlite_vec:
            # Store in sqlite-vec virtual table + metadata in kv
            self._sqlite_vec_add(fact_id, content, namespace, vec)
        else:
            # Local cosine fallback — store vectors in KV
            idx = self.store.get(VECTOR_KEY, namespace=namespace, default={})
            idx[fact_id] = {"content": content, "vector": vec}
            self.store.set(VECTOR_KEY, idx, namespace=namespace)

    def search(self, query: str, namespace: str = "default",
               top_k: int = 5) -> List[dict]:
        q_vec = self.embedder.embed(query)
        if self._use_redis_vec:
            return self._redis_search(q_vec, namespace, top_k)
        elif self._use_sqlite_vec:
            return self._sqlite_vec_search(q_vec, namespace, top_k)
        else:
            return self._cosine_search(q_vec, namespace, top_k)

    def delete(self, fact_id: str, namespace: str = "default"):
        if self._use_redis_vec:
            self.store._r.delete(f"memex:vec:{namespace}:{fact_id}")
        elif self._use_sqlite_vec:
            self.store._conn.execute(
                "DELETE FROM vec_facts WHERE rowid IN "
                "(SELECT rowid FROM vec_meta WHERE fact_id=? AND namespace=?)",
                (fact_id, namespace)
            )
            self.store._conn.execute(
                "DELETE FROM vec_meta WHERE fact_id=? AND namespace=?",
                (fact_id, namespace)
            )
            self.store._conn.commit()
        else:
            idx = self.store.get(VECTOR_KEY, namespace=namespace, default={})
            idx.pop(fact_id, None)
            self.store.set(VECTOR_KEY, idx, namespace=namespace)

    def clear(self, namespace: str = "default"):
        if self._use_redis_vec:
            keys = self.store._r.keys(f"memex:vec:{namespace}:*")
            if keys:
                self.store._r.delete(*keys)
        elif self._use_sqlite_vec:
            self.store._conn.execute(
                "DELETE FROM vec_facts WHERE rowid IN "
                "(SELECT rowid FROM vec_meta WHERE namespace=?)", (namespace,)
            )
            self.store._conn.execute(
                "DELETE FROM vec_meta WHERE namespace=?", (namespace,)
            )
            self.store._conn.commit()
        else:
            self.store.set(VECTOR_KEY, {}, namespace=namespace)

    def count(self, namespace: str = "default") -> int:
        if self._use_redis_vec:
            return len(self.store._r.keys(f"memex:vec:{namespace}:*"))
        elif self._use_sqlite_vec:
            r = self.store._conn.execute(
                "SELECT COUNT(*) as n FROM vec_meta WHERE namespace=?", (namespace,)
            ).fetchone()
            return r["n"] if r else 0
        else:
            return len(self.store.get(VECTOR_KEY, namespace=namespace, default={}))

    def find_similar(self, text: str, namespace: str = "default",
                     threshold: float = 0.85) -> List[dict]:
        return [r for r in self.search(text, namespace=namespace, top_k=5)
                if r["score"] >= threshold]

    # ── sqlite-vec helpers ────────────────────────────────────────────────────

    def _sqlite_vec_add(self, fact_id: str, content: str,
                        namespace: str, vec: List[float]):
        # Ensure meta table exists
        self.store._conn.executescript("""
            CREATE TABLE IF NOT EXISTS vec_meta (
                rowid     INTEGER PRIMARY KEY,
                fact_id   TEXT NOT NULL,
                namespace TEXT NOT NULL,
                content   TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_vm_ns ON vec_meta(namespace);
        """)
        # Insert into vec virtual table first to get rowid
        ser = json.dumps(vec)
        cur = self.store._conn.execute(
            "INSERT INTO vec_facts(embedding) VALUES (?)", (ser,)
        )
        rowid = cur.lastrowid
        self.store._conn.execute(
            "INSERT OR REPLACE INTO vec_meta(rowid, fact_id, namespace, content) "
            "VALUES (?, ?, ?, ?)", (rowid, fact_id, namespace, content)
        )
        self.store._conn.commit()

    def _sqlite_vec_search(self, q_vec: List[float],
                           namespace: str, top_k: int) -> List[dict]:
        try:
            ser  = json.dumps(q_vec)
            rows = self.store._conn.execute("""
                SELECT m.fact_id, m.content, v.distance
                FROM vec_facts v
                JOIN vec_meta m ON v.rowid = m.rowid
                WHERE m.namespace=?
                  AND v.embedding MATCH ?
                ORDER BY v.distance
                LIMIT ?
            """, (namespace, ser, top_k)).fetchall()
            return [{"fact_id": r["fact_id"], "content": r["content"],
                     "score": round(1 - r["distance"], 4)} for r in rows]
        except Exception:
            return self._cosine_search(q_vec, namespace, top_k)

    # ── Redis Vector search ───────────────────────────────────────────────────

    def _redis_search(self, q_vec: List[float],
                      namespace: str, top_k: int) -> List[dict]:
        from redis.commands.search.query import Query
        packed = struct.pack(f"{len(q_vec)}f", *q_vec)
        q = (
            Query(f"@namespace:{{{namespace}}} =>[KNN {top_k} @embedding $vec AS score]")
            .sort_by("score")
            .return_fields("content", "fact_id", "score")
            .paging(0, top_k)
            .dialect(2)
        )
        res = self.store._r.ft("memex_vec_idx").search(
            q, query_params={"vec": packed}
        )
        return [{"fact_id": r.fact_id, "content": r.content,
                 "score": round(1 - float(r.score), 4)} for r in res.docs]

    # ── Cosine fallback ───────────────────────────────────────────────────────

    def _cosine_search(self, q_vec: List[float],
                       namespace: str, top_k: int) -> List[dict]:
        idx    = self.store.get(VECTOR_KEY, namespace=namespace, default={})
        scored = [
            {"fact_id": fid, "content": e["content"],
             "score": self.embedder.cosine(q_vec, e["vector"])}
            for fid, e in idx.items()
        ]
        scored.sort(key=lambda x: x["score"], reverse=True)
        return scored[:top_k]
