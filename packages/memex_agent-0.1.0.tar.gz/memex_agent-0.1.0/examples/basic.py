"""
examples/basic.py
-----------------
Demonstrates all three integration patterns.
Works with zero configuration — no API keys, no Ollama required.

To use a real LLM for better fact extraction:
  export ANTHROPIC_API_KEY=sk-ant-...   # or any other supported key
  python examples/basic.py
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from memex import MemoryLayer, get_store
from memex.embedder import TFIDFEmbedder
from memex.store import MemoryStore

# ── Detect if a real LLM is available ────────────────────────────────────────
try:
    from memex import get_provider
    llm = get_provider("auto")
    print(f"✓ LLM detected — using it for fact extraction\n")
except EnvironmentError:
    llm = None
    print("ℹ  No LLM detected — using rule-based extraction (zero config mode)")
    print("   Set ANTHROPIC_API_KEY, OPENAI_API_KEY, etc. for better extraction\n")


def make_memory(namespace="demo:default"):
    """Create a MemoryLayer that always works, with or without an LLM."""
    return MemoryLayer(
        namespace   = namespace,
        store       = get_store("sqlite", path=".memex-demo.db"),
        embedder    = TFIDFEmbedder(),
        llm         = llm,
        async_learn = False,   # synchronous so demo output is clean
    )


# ─────────────────────────────────────────────────────────────────────────────
# Pattern 2: Manual recall() / learn()
# ─────────────────────────────────────────────────────────────────────────────

print("=" * 55)
print("  Pattern 2: Manual recall() / learn()")
print("=" * 55)

memory = make_memory("demo:user")
memory.clear()  # start fresh each run

# Store facts directly
memory.remember("User's name is Arjun")
memory.remember("User is building a Python agent in Mumbai")
memory.remember("User prefers concise answers with code examples")

# Simulate a user message
user_input = "What are good vector databases for my agent?"
ctx        = memory.recall(user_input)

print(f"\n📥 User: {user_input}")
print(f"\n🧠 Memory context (injected into system prompt):")
print(ctx if ctx.strip() else "  (no relevant facts yet)")

# Simulate an LLM reply and learn from it
fake_reply = "For a Python agent, SQLite+sqlite-vec is great for zero-infra, Qdrant for production."
memory.learn(user_input, fake_reply)

print(f"\n🤖 Agent: {fake_reply}")
s = memory.stats()
print(f"\n📊 Stats: {s['facts']} facts, backend={s['store']['backend']}")


# ─────────────────────────────────────────────────────────────────────────────
# Pattern 3a: @memory.decorator()
# ─────────────────────────────────────────────────────────────────────────────

print("\n" + "=" * 55)
print("  Pattern 3a: @memory.decorator()")
print("=" * 55)

memory2 = make_memory("demo:decorated")
memory2.clear()
memory2.remember("User loves Redis")

@memory2.decorator()
def my_agent(user_input: str, system_context: str = "") -> str:
    # system_context is auto-injected with relevant memories
    has_memory = "Redis" in system_context
    return f"Memory injected: {has_memory} | context length: {len(system_context)} chars"

result = my_agent("Tell me about databases")
print(f"\n🤖 {result}")


# ─────────────────────────────────────────────────────────────────────────────
# Pattern 3b: LangChain adapter
# ─────────────────────────────────────────────────────────────────────────────

print("\n" + "=" * 55)
print("  Pattern 3b: LangChain adapter interface")
print("=" * 55)

memory3 = make_memory("demo:langchain")
memory3.clear()
memory3.remember("User is an expert Python developer")
lc_mem = memory3.as_langchain()

variables = lc_mem.load_memory_variables({"input": "what do you know about me?"})
print(f"\n📥 load_memory_variables keys: {list(variables.keys())}")
ctx = variables['history']
print(f"🧠 Context snippet: {ctx[:100].strip()}..." if ctx.strip() else "  (no context yet)")

lc_mem.save_context(
    {"input":    "I prefer dark mode"},
    {"response": "Noted! I'll remember that."}
)
print(f"💾 Saved exchange — history now has {len(memory3.get_history())} messages")


# ─────────────────────────────────────────────────────────────────────────────
# Multi-user namespacing
# ─────────────────────────────────────────────────────────────────────────────

print("\n" + "=" * 55)
print("  Multi-user namespacing")
print("=" * 55)

# Use in-memory store so this is self-contained
shared_store = MemoryStore()
emb = TFIDFEmbedder()

mem_a = MemoryLayer(namespace="user:alice", store=shared_store, embedder=emb,
                    llm=llm, async_learn=False)
mem_b = MemoryLayer(namespace="user:bob",   store=shared_store, embedder=emb,
                    llm=llm, async_learn=False)

mem_a.remember("Alice is a frontend developer")
mem_b.remember("Bob is a data scientist")

ctx_a = mem_a.recall("what does the user do?")
ctx_b = mem_b.recall("what does the user do?")

alice_correct = "frontend" in ctx_a and "Bob" not in ctx_a
bob_correct   = "data" in ctx_b and "Alice" not in ctx_b

print(f"\n👤 Alice's context correct (has her facts, not Bob's): {alice_correct}")
print(f"👤 Bob's context correct   (has his facts, not Alice's): {bob_correct}")
assert alice_correct and bob_correct, "Namespace isolation failed!"
print("✅ Namespaces fully isolated")


# ─────────────────────────────────────────────────────────────────────────────
# Wrap adapter
# ─────────────────────────────────────────────────────────────────────────────

print("\n" + "=" * 55)
print("  Wrap adapter (mock client)")
print("=" * 55)

memory4 = make_memory("demo:wrap")
memory4.clear()
memory4.remember("User speaks Spanish")

class MockOpenAIClient:
    """Simulates openai.OpenAI() response shape."""
    class chat:
        class completions:
            @staticmethod
            def create(**kwargs):
                sys_msgs = [m for m in kwargs["messages"] if m["role"] == "system"]
                has_memory = any("Spanish" in m["content"] for m in sys_msgs)
                class Msg:
                    content = f"Got it! (memory injected: {has_memory})"
                class Choice:
                    message = Msg()
                class Resp:
                    choices = [Choice()]
                return Resp()

wrapped = memory4.wrap(MockOpenAIClient())
resp = wrapped.chat.completions.create(
    model    = "gpt-4o-mini",
    messages = [{"role": "user", "content": "What language do I speak?"}]
)
print(f"\n🤖 Response: {resp.choices[0].message.content}")


# ─────────────────────────────────────────────────────────────────────────────
# Tool schemas
# ─────────────────────────────────────────────────────────────────────────────

print("\n" + "=" * 55)
print("  Tool schemas")
print("=" * 55)

tool = memory4.as_tool()

oai_schema  = tool.as_openai_function()
anth_schema = tool.as_anthropic_tool()

print(f"\n📋 OpenAI schema:    name={oai_schema['function']['name']!r}, "
      f"params={list(oai_schema['function']['parameters']['properties'].keys())}")
print(f"📋 Anthropic schema: name={anth_schema['name']!r}, "
      f"params={list(anth_schema['input_schema']['properties'].keys())}")

# Direct tool call
result = tool.call("search", query="what language does user speak")
print(f"\n🔍 Tool search result: {result[:80]}")

# Cleanup
os.remove(".memex-demo.db") if os.path.exists(".memex-demo.db") else None

print("\n" + "=" * 55)
print("  ✅ All examples complete")
print("=" * 55)
