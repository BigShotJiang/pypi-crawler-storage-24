# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'columnar.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QGridLayout, QHBoxLayout,
    QHeaderView, QLabel, QListView, QPushButton,
    QSizePolicy, QSplitter, QVBoxLayout, QWidget)

from mtg_proxy_printer.ui.add_card import VerticalAddCardWidget
from mtg_proxy_printer.ui.page_card_table_view import PageCardTableView
from mtg_proxy_printer.ui.page_renderer import PageRenderer

class Ui_ColumnarCentralWidget(object):
    def setupUi(self, ColumnarCentralWidget):
        if not ColumnarCentralWidget.objectName():
            ColumnarCentralWidget.setObjectName(u"ColumnarCentralWidget")
        ColumnarCentralWidget.resize(992, 517)
        self.horizontalLayout = QHBoxLayout(ColumnarCentralWidget)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.central_widget_splitter = QSplitter(ColumnarCentralWidget)
        self.central_widget_splitter.setObjectName(u"central_widget_splitter")
        self.central_widget_splitter.setOrientation(Qt.Orientation.Horizontal)
        self.central_widget_splitter.setHandleWidth(2)
        self.central_widget_splitter.setChildrenCollapsible(False)
        self.gridLayoutWidget = QWidget(self.central_widget_splitter)
        self.gridLayoutWidget.setObjectName(u"gridLayoutWidget")
        self.document_view_layout = QGridLayout(self.gridLayoutWidget)
        self.document_view_layout.setObjectName(u"document_view_layout")
        self.document_view_layout.setContentsMargins(0, 0, 0, 0)
        self.document_view = QListView(self.gridLayoutWidget)
        self.document_view.setObjectName(u"document_view")
        self.document_view.setDragDropOverwriteMode(False)
        self.document_view.setDragDropMode(QAbstractItemView.DragDropMode.DragDrop)
        self.document_view.setDefaultDropAction(Qt.DropAction.MoveAction)
        self.document_view.setAlternatingRowColors(True)
        self.document_view.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.document_view.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)

        self.document_view_layout.addWidget(self.document_view, 2, 0, 1, 2)

        self.page_move_up = QPushButton(self.gridLayoutWidget)
        self.page_move_up.setObjectName(u"page_move_up")
        self.page_move_up.setEnabled(False)
        icon = QIcon(QIcon.fromTheme(u"arrow-up"))
        self.page_move_up.setIcon(icon)

        self.document_view_layout.addWidget(self.page_move_up, 3, 0, 1, 1)

        self.page_move_down = QPushButton(self.gridLayoutWidget)
        self.page_move_down.setObjectName(u"page_move_down")
        self.page_move_down.setEnabled(False)
        icon1 = QIcon(QIcon.fromTheme(u"arrow-down"))
        self.page_move_down.setIcon(icon1)

        self.document_view_layout.addWidget(self.page_move_down, 3, 1, 1, 1)

        self.document_view_label = QLabel(self.gridLayoutWidget)
        self.document_view_label.setObjectName(u"document_view_label")

        self.document_view_layout.addWidget(self.document_view_label, 1, 0, 1, 2)

        self.central_widget_splitter.addWidget(self.gridLayoutWidget)
        self.verticalLayoutWidget_2 = QWidget(self.central_widget_splitter)
        self.verticalLayoutWidget_2.setObjectName(u"verticalLayoutWidget_2")
        self.add_card_layout = QVBoxLayout(self.verticalLayoutWidget_2)
        self.add_card_layout.setObjectName(u"add_card_layout")
        self.add_card_layout.setContentsMargins(0, 0, 0, 0)
        self.add_card_widget_label = QLabel(self.verticalLayoutWidget_2)
        self.add_card_widget_label.setObjectName(u"add_card_widget_label")

        self.add_card_layout.addWidget(self.add_card_widget_label)

        self.add_card_widget = VerticalAddCardWidget(self.verticalLayoutWidget_2)
        self.add_card_widget.setObjectName(u"add_card_widget")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.add_card_widget.sizePolicy().hasHeightForWidth())
        self.add_card_widget.setSizePolicy(sizePolicy)

        self.add_card_layout.addWidget(self.add_card_widget)

        self.central_widget_splitter.addWidget(self.verticalLayoutWidget_2)
        self.verticalLayoutWidget_3 = QWidget(self.central_widget_splitter)
        self.verticalLayoutWidget_3.setObjectName(u"verticalLayoutWidget_3")
        self.page_content_view_layout = QVBoxLayout(self.verticalLayoutWidget_3)
        self.page_content_view_layout.setObjectName(u"page_content_view_layout")
        self.page_content_view_layout.setContentsMargins(0, 0, 0, 0)
        self.page_view_label = QLabel(self.verticalLayoutWidget_3)
        self.page_view_label.setObjectName(u"page_view_label")

        self.page_content_view_layout.addWidget(self.page_view_label)

        self.page_card_table_view = PageCardTableView(self.verticalLayoutWidget_3)
        self.page_card_table_view.setObjectName(u"page_card_table_view")
        self.page_card_table_view.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.page_card_table_view.setLineWidth(0)
        self.page_card_table_view.setDragDropMode(QAbstractItemView.DragDropMode.DragDrop)
        self.page_card_table_view.setDefaultDropAction(Qt.DropAction.MoveAction)
        self.page_card_table_view.setAlternatingRowColors(True)
        self.page_card_table_view.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.page_card_table_view.verticalHeader().setVisible(False)

        self.page_content_view_layout.addWidget(self.page_card_table_view)

        self.delete_selected_images_button = QPushButton(self.verticalLayoutWidget_3)
        self.delete_selected_images_button.setObjectName(u"delete_selected_images_button")
        self.delete_selected_images_button.setEnabled(False)
        icon2 = QIcon(QIcon.fromTheme(u"edit-delete"))
        self.delete_selected_images_button.setIcon(icon2)

        self.page_content_view_layout.addWidget(self.delete_selected_images_button)

        self.central_widget_splitter.addWidget(self.verticalLayoutWidget_3)
        self.verticalLayoutWidget = QWidget(self.central_widget_splitter)
        self.verticalLayoutWidget.setObjectName(u"verticalLayoutWidget")
        self.page_renderer_layout = QVBoxLayout(self.verticalLayoutWidget)
        self.page_renderer_layout.setObjectName(u"page_renderer_layout")
        self.page_renderer_layout.setContentsMargins(0, 0, 0, 0)
        self.page_renderer_label = QLabel(self.verticalLayoutWidget)
        self.page_renderer_label.setObjectName(u"page_renderer_label")

        self.page_renderer_layout.addWidget(self.page_renderer_label)

        self.page_renderer = PageRenderer(self.verticalLayoutWidget)
        self.page_renderer.setObjectName(u"page_renderer")
        self.page_renderer.setAcceptDrops(False)
        self.page_renderer.setRenderHints(QPainter.RenderHint.Antialiasing)

        self.page_renderer_layout.addWidget(self.page_renderer)

        self.central_widget_splitter.addWidget(self.verticalLayoutWidget)

        self.horizontalLayout.addWidget(self.central_widget_splitter)


        self.retranslateUi(ColumnarCentralWidget)

        QMetaObject.connectSlotsByName(ColumnarCentralWidget)
    # setupUi

    def retranslateUi(self, ColumnarCentralWidget):
        self.page_move_up.setText(QCoreApplication.translate("ColumnarCentralWidget", u"Move up", None))
        self.page_move_down.setText(QCoreApplication.translate("ColumnarCentralWidget", u"Move down", None))
        self.document_view_label.setText(QCoreApplication.translate("ColumnarCentralWidget", u"All pages:", None))
        self.add_card_widget_label.setText(QCoreApplication.translate("ColumnarCentralWidget", u"Add new cards:", None))
        self.page_view_label.setText(QCoreApplication.translate("ColumnarCentralWidget", u"Current page:", None))
        self.delete_selected_images_button.setText(QCoreApplication.translate("ColumnarCentralWidget", u"Remove selected", None))
        self.page_renderer_label.setText("")
        pass
    # retranslateUi

