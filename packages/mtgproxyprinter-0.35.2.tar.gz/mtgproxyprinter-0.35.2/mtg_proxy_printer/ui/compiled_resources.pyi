#  Copyright © 2020-2026  Thomas Hess <thomas.hess@udo.edu>
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program. If not, see <http://www.gnu.org/licenses/>.

"""
Declares the interface created by the PySide6 resource compiler.
This is only used for type hinting.
"""

import typing

qt_version: list[int] = ...
rcc_version: int = ...
qt_resource_data: bytes = ...
qt_resource_name: bytes = ...
qt_resource_struct: bytes = ...

def qCleanupResources() -> None: ...
def qInitResources() -> None: ...

del typing
