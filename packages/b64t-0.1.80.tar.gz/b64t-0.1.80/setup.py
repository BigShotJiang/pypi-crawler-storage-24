#!/usr/bin/env python3
"""Minimal setup.py for backward compatibility."""
from setuptools import setup

setup()
