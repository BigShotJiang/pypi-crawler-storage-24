"""Demand Bounty Board — real-time demand signals from AI agents."""

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from html import escape
from urllib.parse import quote
from datetime import datetime, timezone

from indiestack.routes.components import page_shell
from indiestack.db import get_search_gaps, get_search_demand

router = APIRouter()

# Junk queries to filter out (typos, nonsense, non-tool searches)
_BLOCKLIST = {
    'xbox game pass', 'akoraimagbuot', 'wace', 'test', 'asdf', 'hello',
    'indiestack', 'xxx', 'porn', 'sex',
}


def _is_valid_gap(query: str) -> bool:
    """Filter out junk queries that aren't real tool gaps."""
    q = query.strip().lower()
    if len(q) < 3 or len(q) > 60:
        return False
    if q in _BLOCKLIST:
        return False
    # Filter out queries that are just random characters
    if not any(c.isalpha() for c in q):
        return False
    return True


def _relative_time(timestamp: str) -> str:
    """Convert a timestamp string to relative time like '2 hours ago'."""
    if not timestamp:
        return ''
    try:
        dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
        now = datetime.now(timezone.utc)
        diff = now - dt
        seconds = int(diff.total_seconds())
        if seconds < 60:
            return 'just now'
        minutes = seconds // 60
        if minutes < 60:
            return f'{minutes} min{"s" if minutes != 1 else ""} ago'
        hours = minutes // 60
        if hours < 24:
            return f'{hours} hour{"s" if hours != 1 else ""} ago'
        days = hours // 24
        if days < 30:
            return f'{days} day{"s" if days != 1 else ""} ago'
        months = days // 30
        return f'{months} month{"s" if months != 1 else ""} ago'
    except (ValueError, TypeError):
        return timestamp[:10] if len(timestamp) >= 10 else timestamp


@router.get("/gaps", response_class=HTMLResponse)
async def gaps_page(request: Request):
    user = request.state.user
    db = request.state.db

    # Get all zero-result searches, then filter
    raw_gaps = await get_search_gaps(db, limit=100)
    gaps = [g for g in raw_gaps if _is_valid_gap(g['query'])][:30]

    # Stats
    total_gaps = len(gaps)
    total_searches = sum(g['count'] for g in gaps) if gaps else 0

    # Build gap cards
    gap_cards = ''
    for gap in gaps:
        query = escape(gap['query'])
        count = gap['count']
        last = gap.get('last_searched', '')
        last_display = _relative_time(last)

        # Demand tier badge
        if count >= 10:
            badge_label = 'HIGH DEMAND'
            badge_bg = 'var(--error-bg, rgba(239,68,68,0.12))'
            badge_color = 'var(--error-text, #EF4444)'
        elif count >= 5:
            badge_label = 'GROWING'
            badge_bg = 'var(--warning-bg, rgba(226,183,100,0.12))'
            badge_color = 'var(--warning-text, #E2B764)'
        elif count >= 2:
            badge_label = 'EMERGING'
            badge_bg = 'var(--info-bg, rgba(0,212,245,0.12))'
            badge_color = 'var(--info-text, #00D4F5)'
        else:
            badge_label = 'NEW SIGNAL'
            badge_bg = 'var(--bg-card, rgba(255,255,255,0.04))'
            badge_color = 'var(--ink-muted)'

        gap_cards += f'''
        <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:12px;padding:24px;
                    display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;
                    transition:border-color 0.2s;">
            <div style="flex:1;min-width:220px;">
                <div style="display:flex;align-items:center;gap:12px;margin-bottom:10px;flex-wrap:wrap;">
                    <span style="font-family:var(--heading-font, var(--font-display));font-size:18px;font-weight:600;color:var(--ink);">
                        {query}
                    </span>
                    <span style="display:inline-block;padding:3px 10px;border-radius:999px;font-size:11px;
                                 font-weight:700;letter-spacing:0.5px;background:{badge_bg};color:{badge_color};">
                        {badge_label}
                    </span>
                </div>
                <div style="display:flex;gap:16px;font-size:13px;color:var(--ink-muted);flex-wrap:wrap;">
                    <span><strong style="color:var(--ink);">{count}</strong> agent search{"es" if count != 1 else ""}</span>
                    {f'<span style="color:var(--border);">&middot;</span><span>Last searched {last_display}</span>' if last_display else ''}
                </div>
            </div>
            <div style="flex-shrink:0;text-align:right;">
                <a href="/submit?name={quote(gap['query'])}"
                   style="display:inline-block;padding:10px 20px;background:var(--accent);color:white;
                          border-radius:8px;font-size:14px;font-weight:600;text-decoration:none;
                          white-space:nowrap;transition:opacity 0.2s;">
                    Build This &rarr;
                </a>
                <div style="font-size:11px;color:var(--ink-muted);margin-top:6px;">
                    Guaranteed distribution to AI agents
                </div>
            </div>
        </div>'''

    # Hero section
    hero = f'''
    <section style="padding:64px 24px 32px;text-align:center;">
        <div class="container" style="max-width:740px;">
            <p style="font-size:13px;font-weight:600;color:var(--accent);text-transform:uppercase;letter-spacing:1px;margin-bottom:12px;">
                Live from the IndieStack MCP Server
            </p>
            <h1 style="font-family:var(--heading-font, var(--font-display));font-size:clamp(28px,4vw,42px);color:var(--ink);margin-bottom:16px;line-height:1.2;">
                Demand Bounty Board
            </h1>
            <p style="font-size:17px;color:var(--ink-muted);max-width:600px;margin:0 auto 32px;line-height:1.6;">
                Real-time demand signals from AI agents. These tools were searched for and couldn&rsquo;t be found.
                Build one and get instant distribution.
            </p>
        </div>
    </section>
    '''

    # Stats bar
    stats_bar = f'''
    <section style="padding:0 24px 40px;">
        <div class="container" style="max-width:740px;">
            <div style="display:flex;gap:1px;background:var(--border);border-radius:12px;overflow:hidden;
                        border:1px solid var(--border);">
                <div style="flex:1;background:var(--bg-card);padding:20px 24px;text-align:center;">
                    <div style="font-family:var(--heading-font, var(--font-display));font-size:28px;font-weight:700;color:var(--accent);margin-bottom:4px;">
                        {total_gaps}
                    </div>
                    <div style="font-size:13px;color:var(--ink-muted);">Unfilled Gaps</div>
                </div>
                <div style="flex:1;background:var(--bg-card);padding:20px 24px;text-align:center;">
                    <div style="font-family:var(--heading-font, var(--font-display));font-size:28px;font-weight:700;color:var(--accent);margin-bottom:4px;">
                        {total_searches}
                    </div>
                    <div style="font-size:13px;color:var(--ink-muted);">Failed Agent Searches</div>
                </div>
                <div style="flex:1;background:var(--bg-card);padding:20px 24px;text-align:center;">
                    <div style="font-size:14px;font-weight:600;color:var(--ink);line-height:1.4;">
                        Every gap = guaranteed AI recommendations when filled
                    </div>
                </div>
            </div>
        </div>
    </section>
    '''

    # Gap list
    gap_list = f'''
    <section style="padding:0 24px 64px;">
        <div class="container" style="max-width:740px;">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;">
                <h2 style="font-family:var(--heading-font, var(--font-display));font-size:22px;color:var(--ink);">Open Bounties</h2>
                <span style="font-size:13px;color:var(--ink-muted);">Sorted by demand</span>
            </div>
            <div style="display:flex;flex-direction:column;gap:12px;">
                {gap_cards if gap_cards else '<p style="color:var(--ink-muted);text-align:center;padding:40px;">No gaps detected yet. As more AI agents use the MCP server, bounties will appear here.</p>'}
            </div>
        </div>
    </section>
    '''

    # How it works
    how_it_works = '''
    <section style="padding:0 24px 64px;">
        <div class="container" style="max-width:740px;">
            <h2 style="font-family:var(--heading-font, var(--font-display));font-size:22px;color:var(--ink);text-align:center;margin-bottom:32px;">
                How It Works
            </h2>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:20px;">
                <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:12px;padding:24px 20px;text-align:center;">
                    <div style="width:36px;height:36px;border-radius:999px;background:var(--accent);color:white;
                                display:inline-flex;align-items:center;justify-content:center;font-weight:700;
                                font-size:16px;margin-bottom:12px;">1</div>
                    <p style="font-size:14px;font-weight:600;color:var(--ink);margin-bottom:4px;">Agent Searches</p>
                    <p style="font-size:13px;color:var(--ink-muted);line-height:1.5;">AI agents search IndieStack for tools</p>
                </div>
                <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:12px;padding:24px 20px;text-align:center;">
                    <div style="width:36px;height:36px;border-radius:999px;background:var(--accent);color:white;
                                display:inline-flex;align-items:center;justify-content:center;font-weight:700;
                                font-size:16px;margin-bottom:12px;">2</div>
                    <p style="font-size:14px;font-weight:600;color:var(--ink);margin-bottom:4px;">Gap Logged</p>
                    <p style="font-size:13px;color:var(--ink-muted);line-height:1.5;">When they find nothing, the search is logged here</p>
                </div>
                <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:12px;padding:24px 20px;text-align:center;">
                    <div style="width:36px;height:36px;border-radius:999px;background:var(--accent);color:white;
                                display:inline-flex;align-items:center;justify-content:center;font-weight:700;
                                font-size:16px;margin-bottom:12px;">3</div>
                    <p style="font-size:14px;font-weight:600;color:var(--ink);margin-bottom:4px;">You Build It</p>
                    <p style="font-size:13px;color:var(--ink-muted);line-height:1.5;">You build the tool and submit it to IndieStack</p>
                </div>
                <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:12px;padding:24px 20px;text-align:center;">
                    <div style="width:36px;height:36px;border-radius:999px;background:var(--accent);color:white;
                                display:inline-flex;align-items:center;justify-content:center;font-weight:700;
                                font-size:16px;margin-bottom:12px;">4</div>
                    <p style="font-size:14px;font-weight:600;color:var(--ink);margin-bottom:4px;">Instant Distribution</p>
                    <p style="font-size:13px;color:var(--ink-muted);line-height:1.5;">Every agent that searches next will recommend YOUR creation</p>
                </div>
            </div>
        </div>
    </section>
    '''

    # CTA
    cta = '''
    <section style="padding:48px 24px;background:var(--cream-dark);">
        <div class="container" style="max-width:600px;text-align:center;">
            <h2 style="font-family:var(--heading-font, var(--font-display));font-size:24px;color:var(--ink);margin-bottom:12px;">
                Built something that fills a gap?
            </h2>
            <p style="font-size:15px;color:var(--ink-muted);margin-bottom:24px;line-height:1.6;">
                Submit your creation and it&rsquo;ll start showing up in AI recommendations immediately.
                You&rsquo;ll get a live badge showing how many times agents recommend it.
            </p>
            <a href="/submit" class="btn btn-primary" style="padding:14px 32px;font-size:15px;">
                Submit Your Creation &rarr;
            </a>
        </div>
    </section>
    '''

    body = hero + stats_bar + gap_list + how_it_works + cta

    return HTMLResponse(page_shell(
        title="Demand Bounty Board — Tools AI Agents Are Searching For | IndieStack",
        body=body,
        user=user,
        description="Real-time demand signals from AI agents. See what tools were searched for and couldn't be found. Build one and get instant distribution.",
    ))
