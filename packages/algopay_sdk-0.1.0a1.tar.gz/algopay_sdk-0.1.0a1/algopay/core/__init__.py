"""Core types and configuration."""
