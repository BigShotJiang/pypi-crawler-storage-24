"""Async WebSocket client for /api/v2/agent/ws."""

from __future__ import annotations

import asyncio
import json
import uuid
from dataclasses import dataclass
from typing import Any, Optional
from urllib.parse import urlencode

import websockets
from websockets.asyncio.client import ClientConnection


@dataclass
class WsClientConfig:
    """Configuration for agent websocket client connections."""

    base_url: str
    user_id: Optional[str]
    user_token: str
    thread_id: Optional[str] = None
    user_language: Optional[str] = None
    debug: bool = False
    connect_timeout_seconds: float = 20.0
    reconnect_attempts: int = 3
    reconnect_backoff_seconds: float = 1.5


class AgentWsV3Client:
    """Client wrapper for the agent websocket message contract."""

    def __init__(self, config: WsClientConfig) -> None:
        self.config = config
        self._ws: Optional[ClientConnection] = None
        self._recv_task: Optional[asyncio.Task[None]] = None
        self._incoming_queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue()
        self._closed = False
        self._thread_id_ready = asyncio.Event()
        self._user_id_ready = asyncio.Event()
        if self.config.thread_id:
            self._thread_id_ready.set()
        if self.config.user_id:
            self._user_id_ready.set()

    def _debug_print_raw(self, direction: str, raw: Any) -> None:
        if not self.config.debug:
            return

        if isinstance(raw, bytes):
            try:
                rendered = raw.decode("utf-8")
            except UnicodeDecodeError:
                rendered = repr(raw)
        else:
            rendered = str(raw)

        print(f"[DEBUG][{direction}] {rendered}")

    @property
    def thread_id(self) -> str:
        return self.config.thread_id or ""

    def set_thread_id(self, thread_id: str) -> None:
        if not thread_id:
            return
        self.config.thread_id = thread_id
        self._thread_id_ready.set()

    @property
    def user_id(self) -> str:
        return self.config.user_id or ""

    def set_user_id(self, user_id: str) -> None:
        if not user_id:
            return
        self.config.user_id = user_id
        self._user_id_ready.set()

    @property
    def incoming_queue(self) -> asyncio.Queue[dict[str, Any]]:
        return self._incoming_queue

    def _build_ws_url(self) -> str:
        query_params: dict[str, str] = {
            "userToken": self.config.user_token,
        }
        if self.config.user_id:
            query_params["user_id"] = self.config.user_id
        if self.config.thread_id:
            query_params["thread_id"] = self.config.thread_id
        if self.config.user_language:
            # Backward compatibility: server accepts both user_language and User_language.
            query_params["User_language"] = self.config.user_language
        return f"{self.config.base_url}?{urlencode(query_params)}"

    async def wait_for_thread_id(self, timeout_seconds: float = 10.0) -> str:
        if self.config.thread_id:
            return self.config.thread_id
        try:
            await asyncio.wait_for(self._thread_id_ready.wait(), timeout=timeout_seconds)
        except asyncio.TimeoutError as exc:
            raise RuntimeError(
                f"Timed out waiting for thread_id from websocket metadata ({timeout_seconds}s)"
            ) from exc
        if not self.config.thread_id:
            raise RuntimeError("thread_id is still unavailable")
        return self.config.thread_id

    async def wait_for_user_id(self, timeout_seconds: float = 10.0) -> str:
        if self.config.user_id:
            return self.config.user_id
        try:
            await asyncio.wait_for(self._user_id_ready.wait(), timeout=timeout_seconds)
        except asyncio.TimeoutError as exc:
            raise RuntimeError(
                f"Timed out waiting for user_id from websocket metadata ({timeout_seconds}s)"
            ) from exc
        if not self.config.user_id:
            raise RuntimeError("user_id is still unavailable")
        return self.config.user_id

    async def connect(self) -> None:
        """Open websocket and start background receive loop."""
        if self._ws is not None:
            return

        self._closed = False
        url = self._build_ws_url()
        attempt = 0
        last_error: Optional[Exception] = None

        while attempt < max(1, self.config.reconnect_attempts):
            attempt += 1
            try:
                self._ws = await asyncio.wait_for(
                    websockets.connect(url, ping_interval=None),
                    timeout=self.config.connect_timeout_seconds,
                )
                self._recv_task = asyncio.create_task(self._recv_loop())
                return
            except Exception as exc:  # pragma: no cover - network dependent
                last_error = exc
                if attempt >= self.config.reconnect_attempts:
                    break
                await asyncio.sleep(self.config.reconnect_backoff_seconds * attempt)

        if last_error is not None:
            raise last_error
        raise RuntimeError("Failed to connect to websocket endpoint")

    async def reconnect(self, *, new_thread: bool = False) -> None:
        """Reconnect with optional new thread_id."""
        await self.close(send_terminate=False)
        if new_thread:
            self.config.thread_id = str(uuid.uuid4())
            self._thread_id_ready.set()
        await self.connect()

    async def close(self, *, send_terminate: bool = True) -> None:
        """Close websocket and receiver task."""
        if self._closed:
            return
        self._closed = True

        if send_terminate and self._ws is not None:
            try:
                await self.send_terminate()
            except Exception:
                pass

        if self._recv_task is not None and not self._recv_task.done():
            self._recv_task.cancel()
            try:
                await self._recv_task
            except asyncio.CancelledError:
                pass
            except Exception:
                pass

        if self._ws is not None:
            ws = self._ws
            self._ws = None
            try:
                # Don't block shutdown for too long if peer doesn't complete close handshake.
                await asyncio.wait_for(ws.close(), timeout=0.35)
            except Exception:
                transport = getattr(ws, "transport", None)
                if transport is not None and not transport.is_closing():
                    transport.abort()

    async def send_raw(self, payload: dict[str, Any]) -> None:
        if self._ws is None:
            raise RuntimeError("WebSocket is not connected")
        raw_text = json.dumps(payload, ensure_ascii=False)
        self._debug_print_raw("SEND", raw_text)
        await self._ws.send(raw_text)

    async def send_query(
        self,
        query: str,
        *,
        attachments: Optional[list[dict[str, Any]]] = None,
        scenario: Optional[str] = None,
        config: Optional[dict[str, Any]] = None,
        system_prompt: Optional[str] = None,
        language: Optional[str] = None,
    ) -> None:
        """Send query payload expected by agent websocket."""
        payload: dict[str, Any] = {
            "type": "query",
            "query": query,
            "attachments": attachments or [],
        }
        if self.config.user_id:
            payload["user_id"] = self.config.user_id
        if scenario:
            payload["scenario"] = scenario
        if config is not None:
            payload["config"] = config
        if system_prompt:
            payload["system_prompt"] = system_prompt
        if language:
            payload["language"] = language
        await self.send_raw(payload)

    async def send_interrupt(self) -> None:
        await self.send_raw({"type": "interrupt"})

    async def send_terminate(self) -> None:
        await self.send_raw({"type": "terminate"})

    async def send_answer(
        self,
        *,
        message_id: str,
        answers: dict[str, str],
        as_type: str = "ask_message",
    ) -> None:
        await self.send_raw(
            {
                "type": as_type,
                "message_id": message_id,
                "answers": answers,
            }
        )

    async def _recv_loop(self) -> None:
        """Continuously read websocket frames and enqueue JSON messages."""
        assert self._ws is not None
        try:
            async for raw in self._ws:
                self._debug_print_raw("RECV", raw)
                try:
                    payload = json.loads(raw)
                except json.JSONDecodeError:
                    payload = {"type": "_raw", "raw": raw}

                # Keep-alive frames should not spam the main render loop.
                if payload.get("type") == "heartbeat":
                    continue

                await self._incoming_queue.put(payload)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            await self._incoming_queue.put(
                {
                    "type": "_connection_error",
                    "error_message": str(exc),
                }
            )
