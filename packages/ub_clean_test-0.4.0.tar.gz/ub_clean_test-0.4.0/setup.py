from setuptools import setup, find_packages

setup(
    name="ub-clean-test",
    version="0.4.0",          
    author="pengyeqin",
    author_email="xxbj433@qq.com",
    description="机器人控制框架",
    packages=find_packages(),
    install_requires=[
        "numpy>=1.21.0",
        "scipy>=1.7.0",
    ],
)