# Vyper Guard — VS Code Extension

> Real-time security analysis for Vyper smart contracts, right in your editor.

## Features

- **🔴 Diagnostics on save** — Vulnerability findings appear as squiggly lines in the editor (errors, warnings, hints) the moment you save a `.vy` file.
- **🔧 Auto-fix** — Right-click → "Analyze & Auto-Fix" to generate patched code.
- **🛡️ Status bar** — Shows the security grade (A+/A/B/C/F) of the active file.
- **📁 Workspace scan** — Scan all `.vy` files at once.
- **⚙️ Configurable** — Set severity threshold, choose detectors, custom executable path.

## How It Works

The extension calls the `vyper-guard` CLI as a subprocess with `--format json`, parses the output, and maps findings to VS Code diagnostics. **Zero coupling** with the Python internals — the CLI is the only interface.

## Requirements

1. **Install vyper-guard** (the Python CLI):
   ```bash
   pip install vyper-guard
   ```

2. **Install this extension** from the VS Code marketplace (or build locally).

## Settings

| Setting | Default | Description |
|---------|---------|-------------|
| `vyperGuardian.executablePath` | `vyper-guard` | Path to the CLI binary |
| `vyperGuardian.analyzeOnSave` | `true` | Auto-scan on save |
| `vyperGuardian.severityThreshold` | `INFO` | Minimum severity to show |
| `vyperGuardian.enabledDetectors` | `all` | Comma-separated detector list |

## Building from Source

```bash
cd vscode-extension
npm install
npm run compile
# Package as .vsix
npx @vscode/vsce package
```

Then install the `.vsix` file:
- VS Code → Extensions → ⋯ → "Install from VSIX…"

## Architecture

```
┌─────────────────────────────────┐
│       VS Code Extension         │
│  (TypeScript, runs in VS Code)  │
│                                 │
│  • onDidSaveTextDocument        │
│  • DiagnosticCollection         │
│  • StatusBarItem                │
│  • Commands (analyze, fix)      │
│                                 │
│         ┌──────────┐            │
│         │ execFile │            │
│         └────┬─────┘            │
└──────────────┼──────────────────┘
               │  vyper-guard analyze file.vy --format json
               ▼
┌─────────────────────────────────┐
│      vyper-guard CLI          │
│  (Python, runs as subprocess)   │
│                                 │
│  12 detectors │ auto-fix │ JSON │
└─────────────────────────────────┘
```

The extension and CLI are **completely decoupled**. The CLI can be updated independently.
