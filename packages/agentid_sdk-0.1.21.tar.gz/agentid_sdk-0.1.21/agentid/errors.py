from __future__ import annotations


class SecurityBlockError(RuntimeError):
    """
    Raised when AgentID guard blocks the request.
    """

    def __init__(self, reason: str | None = None):
        self.reason = reason
        super().__init__(reason or "AgentID: Security Blocked")


class SecurityViolationException(RuntimeError):
    """
    Raised when local capability enforcement blocks or redacts by policy.
    """

    def __init__(self, reason: str | None = None):
        self.reason = reason
        super().__init__(reason or "AgentID: Security policy violation")


class DependencyError(RuntimeError):
    """
    Raised when an AgentID dependency fails in fail-close mode.
    """

    def __init__(
        self,
        reason: str | None = None,
        *,
        status_code: int | None = None,
        dependency: str = "ingest",
    ):
        self.reason = reason
        self.status_code = status_code
        self.dependency = dependency
        status_label = str(status_code) if status_code is not None else "network"
        super().__init__(
            f"AgentID dependency failure ({dependency}): {reason or 'unknown'} [{status_label}]"
        )
