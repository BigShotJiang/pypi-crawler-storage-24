"""Submit tests to Databricks and wait for results."""

import base64
import os
import sys
import time
import datetime
from pathlib import Path

# Load credentials
env_path = Path.home() / ".config" / "burning-cost" / "databricks.env"
for line in env_path.read_text().splitlines():
    line = line.strip()
    if line and not line.startswith("#") and "=" in line:
        k, _, v = line.partition("=")
        os.environ[k.strip()] = v.strip()

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.workspace import ImportFormat, Language
from databricks.sdk.service.compute import ClusterSpec as ComputeClusterSpec
from databricks.sdk.service.jobs import (
    NotebookTask,
    SubmitTask,
    Task,
    Source,
)

w = WorkspaceClient()

WORKSPACE_DIR = "/Workspace/Shared/insurance-poisson-mixture-nn"
PROJECT = Path(__file__).parent

# Read all source files into a single test notebook
src_files = {}
for f in (PROJECT / "src" / "insurance_poisson_mixture_nn").glob("*.py"):
    src_files[f.name] = f.read_text()

test_files = {}
for f in (PROJECT / "tests").glob("*.py"):
    test_files[f.name] = f.read_text()

# Build notebook content — install package inline, write files, run pytest
cell_parts = []

# Cell 1: pip install
cell_parts.append(
    "%pip install torch polars scikit-learn statsmodels pytest pytest-cov 2>&1 | tail -5"
)

# Cell 2: write source files
write_code = ["import os, pathlib"]
write_code.append(
    "src_dir = pathlib.Path('/tmp/insurance_poisson_mixture_nn_pkg/src/insurance_poisson_mixture_nn')"
)
write_code.append("src_dir.mkdir(parents=True, exist_ok=True)")
write_code.append(
    "test_dir = pathlib.Path('/tmp/insurance_poisson_mixture_nn_pkg/tests')"
)
write_code.append("test_dir.mkdir(parents=True, exist_ok=True)")

for fname, content in src_files.items():
    escaped = content.replace("\\", "\\\\").replace('"""', '\\"\\"\\"').replace("'''", "\\'\\'\\'")
    write_code.append(f"(src_dir / {repr(fname)}).write_text({repr(content)})")

for fname, content in test_files.items():
    write_code.append(f"(test_dir / {repr(fname)}).write_text({repr(content)})")

# Write minimal pyproject.toml
pyproject = (PROJECT / "pyproject.toml").read_text()
write_code.append(
    f"(pathlib.Path('/tmp/insurance_poisson_mixture_nn_pkg') / 'pyproject.toml').write_text({repr(pyproject)})"
)

cell_parts.append("\n".join(write_code))

# Cell 3: pip install the local package
cell_parts.append(
    "%pip install -e /tmp/insurance_poisson_mixture_nn_pkg 2>&1 | tail -5"
)

# Cell 4: run pytest
cell_parts.append("""
import subprocess, sys
result = subprocess.run(
    [sys.executable, "-m", "pytest",
     "/tmp/insurance_poisson_mixture_nn_pkg/tests",
     "-v", "--tb=short", "-q"],
    capture_output=True, text=True,
    cwd="/tmp/insurance_poisson_mixture_nn_pkg",
)
print(result.stdout[-8000:] if len(result.stdout) > 8000 else result.stdout)
if result.stderr:
    print("STDERR:", result.stderr[-2000:])
assert result.returncode == 0, f"Tests failed (exit code {result.returncode})"
print("ALL TESTS PASSED")
""")

# Assemble notebook source
nb_lines = ["# Databricks notebook source"]
for cell in cell_parts:
    nb_lines.append("")
    nb_lines.append("# COMMAND ----------")
    nb_lines.append("")
    nb_lines.append(cell)

notebook_source = "\n".join(nb_lines)
notebook_path = f"{WORKSPACE_DIR}/run_tests"

# Upload notebook
print(f"Uploading test notebook to {notebook_path}...")
try:
    w.workspace.mkdirs(path=WORKSPACE_DIR)
except Exception:
    pass

w.workspace.import_(
    path=notebook_path,
    format=ImportFormat.SOURCE,
    language=Language.PYTHON,
    content=base64.b64encode(notebook_source.encode()).decode(),
    overwrite=True,
)
print("Notebook uploaded.")

# Submit job
print("Submitting job...")
run_waiter = w.jobs.submit(
    run_name="insurance-poisson-mixture-nn-tests",
    tasks=[
        SubmitTask(
            task_key="run_tests",
            notebook_task=NotebookTask(
                notebook_path=notebook_path,
                source=Source.WORKSPACE,
            ),
        )
    ],
)

print(f"Run submitted. Waiting for completion...")
run = run_waiter.result(timeout=datetime.timedelta(seconds=1200))

print(f"\nRun state: {run.state.life_cycle_state}")
if run.state.result_state:
    print(f"Result: {run.state.result_state}")

if str(run.state.result_state) in ("RunResultState.SUCCESS", "SUCCESS"):
    print("\nAll tests passed on Databricks.")
    sys.exit(0)
else:
    print("\nTests failed. Check Databricks run output.")
    sys.exit(1)
