"""Run the test suite on Databricks serverless compute.

This script uploads the library source to the Databricks workspace, then
executes pytest via a notebook job. Use this instead of running pytest locally
to avoid crashing the Raspberry Pi.

Usage:
    python run_tests_databricks.py

Requires:
    - ~/.config/burning-cost/databricks.env with DATABRICKS_HOST and
      DATABRICKS_TOKEN
    - Databricks SDK: pip install databricks-sdk
"""

import os
import subprocess
import sys
import time
from pathlib import Path

# Load Databricks credentials
env_file = Path.home() / ".config" / "burning-cost" / "databricks.env"
if env_file.exists():
    for line in env_file.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            key, _, value = line.partition("=")
            os.environ[key.strip()] = value.strip()

from databricks.sdk import WorkspaceClient
from databricks.sdk.service import jobs

PROJECT_ROOT = Path(__file__).parent
WORKSPACE_PATH = "/Workspace/insurance-poisson-mixture-nn"


def upload_sources(w: WorkspaceClient) -> None:
    """Upload source files to the Databricks workspace."""
    print("Uploading source files...")
    result = subprocess.run(
        [
            "databricks", "workspace", "import-dir",
            str(PROJECT_ROOT / "src"),
            f"{WORKSPACE_PATH}/src",
            "--overwrite",
        ],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        print(f"Warning: workspace import: {result.stderr}")

    result = subprocess.run(
        [
            "databricks", "workspace", "import-dir",
            str(PROJECT_ROOT / "tests"),
            f"{WORKSPACE_PATH}/tests",
            "--overwrite",
        ],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        print(f"Warning: tests import: {result.stderr}")


NOTEBOOK_CONTENT = '''
# Databricks notebook source
# COMMAND ----------
%pip install torch polars scikit-learn pytest statsmodels insurance-poisson-mixture-nn

# COMMAND ----------
import subprocess
result = subprocess.run(
    ["python", "-m", "pytest", "/Workspace/insurance-poisson-mixture-nn/tests",
     "-v", "--tb=short", "-x"],
    capture_output=True,
    text=True,
    cwd="/tmp",
)
print(result.stdout)
print(result.stderr)
assert result.returncode == 0, f"Tests failed with code {result.returncode}"
'''


def create_test_notebook(w: WorkspaceClient) -> str:
    """Create the test runner notebook and return its path."""
    notebook_path = f"{WORKSPACE_PATH}/run_tests"
    import base64
    w.workspace.import_(
        path=notebook_path,
        format="SOURCE",
        language="PYTHON",
        content=base64.b64encode(NOTEBOOK_CONTENT.encode()).decode(),
        overwrite=True,
    )
    return notebook_path


def run_job(w: WorkspaceClient, notebook_path: str) -> None:
    """Submit and wait for the test job."""
    print(f"Submitting test job...")
    run = w.jobs.submit(
        run_name="insurance-poisson-mixture-nn-tests",
        tasks=[
            jobs.SubmitTask(
                task_key="run_tests",
                notebook_task=jobs.NotebookTask(notebook_path=notebook_path),
                new_cluster=jobs.ClusterSpec(
                    spark_version="15.4.x-cpu-ml-scala2.12",
                    node_type_id="m5.large",
                    num_workers=0,
                    spark_conf={"spark.master": "local[*]"},
                ),
            )
        ],
    ).result()

    print(f"Run ID: {run.run_id}")
    print(f"State: {run.state.life_cycle_state}")
    if run.state.result_state:
        print(f"Result: {run.state.result_state}")
    if run.state.result_state and run.state.result_state.value == "SUCCESS":
        print("All tests passed.")
    else:
        print("Tests failed — check Databricks run output.")
        sys.exit(1)


if __name__ == "__main__":
    w = WorkspaceClient()
    upload_sources(w)
    notebook_path = create_test_notebook(w)
    run_job(w, notebook_path)
