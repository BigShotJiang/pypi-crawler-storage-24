# Databricks notebook source
# MAGIC %md
# MAGIC # Poisson Mixture DNN — Full Workflow Demo
# MAGIC
# MAGIC This notebook demonstrates `insurance-poisson-mixture-nn` end-to-end on
# MAGIC synthetic UK telematics motor data.
# MAGIC
# MAGIC **What we show:**
# MAGIC 1. Generate synthetic data with known structural/stochastic mixture
# MAGIC 2. Train the PM-DNN model
# MAGIC 3. Inspect component separation and pi calibration
# MAGIC 4. Decompose zero-claim policies into structural vs stochastic
# MAGIC 5. Compare against Poisson GLM, ZIP GLM, and Poisson DNN baselines
# MAGIC
# MAGIC **The core insight:** A telematics driver with pi=0.05 and zero claims is
# MAGIC almost certainly a structural zero. A driver with pi=0.8 and zero claims
# MAGIC was lucky. The PM-DNN tells you which is which.

# COMMAND ----------

# MAGIC %pip install insurance-poisson-mixture-nn[comparison] matplotlib

# COMMAND ----------

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from insurance_poisson_mixture_nn import (
    PoissonMixtureNN,
    PoissonMixtureTrainer,
    PoissonMixturePredictor,
)
from insurance_poisson_mixture_nn.synthetic import SyntheticMixtureData, FEATURE_NAMES
from insurance_poisson_mixture_nn.diagnostics import MixtureDiagnostics
from insurance_poisson_mixture_nn.comparison import ModelComparison

print("insurance-poisson-mixture-nn loaded successfully")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Synthetic telematics data
# MAGIC
# MAGIC We generate 10,000 synthetic UK motor policies. The covariates are:
# MAGIC - **annual_mileage_log**: log total miles driven (telematics recorded)
# MAGIC - **harsh_braking_rate**: harsh braking events per 1000 miles
# MAGIC - **night_drive_fraction**: fraction of miles driven 22:00–06:00
# MAGIC - **driver_age_scaled**: (age − 35) / 15
# MAGIC - **vehicle_value_log**: log vehicle value in GBP
# MAGIC - **motorway_fraction**: fraction of miles on motorways
# MAGIC - **speed_score**: composite speeding score [0, 1]
# MAGIC - **claims_last_year**: prior year claim indicator
# MAGIC
# MAGIC The ground truth mixture structure:
# MAGIC - `pi(x)` is a logistic function of mileage, braking, night driving
# MAGIC - Low-mileage smooth-driving policies → structural zeros (pi near 0)
# MAGIC - Active high-risk drivers → at-risk group (pi near 1)

# COMMAND ----------

data = SyntheticMixtureData(n_policies=10_000, seed=42)
summary = data.summary()

print("Dataset summary:")
for k, v in summary.items():
    print(f"  {k}: {v:.4f}" if isinstance(v, float) else f"  {k}: {v}")

# COMMAND ----------

# Visualise the ground truth structure
fig, axes = plt.subplots(1, 3, figsize=(14, 4))

axes[0].hist(data.true_pi, bins=50, color="#1565C0", alpha=0.8, edgecolor="none")
axes[0].set_xlabel("True pi (at-risk probability)")
axes[0].set_ylabel("Count")
axes[0].set_title(f"Ground Truth Pi\n(mean={data.true_pi.mean():.3f})")

axes[1].hist(data.true_lambda_0, bins=50, color="#2196F3", alpha=0.8)
axes[1].set_xlabel("True lambda_0 (safe group rate)")
axes[1].set_title(f"Ground Truth Lambda_0\n(mean={data.true_lambda_0.mean():.4f})")

axes[2].hist(data.true_lambda_1, bins=50, color="#F44336", alpha=0.8)
axes[2].set_xlabel("True lambda_1 (risky group rate)")
axes[2].set_title(f"Ground Truth Lambda_1\n(mean={data.true_lambda_1.mean():.3f})")

plt.tight_layout()
plt.savefig("/tmp/ground_truth.png", dpi=120, bbox_inches="tight")
plt.close()
display(plt.imread("/tmp/ground_truth.png"))

# COMMAND ----------

print(f"Structural zero fraction: {data.structural_zero_fraction():.1%}")
print(f"Zero-claim fraction: {summary['zero_claim_fraction']:.1%}")
print(f"Mean claims per policy: {summary['mean_claims']:.4f}")
print()
print("Structural zeros are the policies with near-zero mileage — they happened")
print("to have zero claims, but so would any Poisson(epsilon) process.")
print()
print("Stochastic zeros are active drivers who Poisson-sampled a zero this year.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Train the PM-DNN

# COMMAND ----------

X_train, y_train, exp_train = data.training_split()
X_val, y_val, exp_val = data.validation_split()
X_test, y_test, exp_test = data.test_split()

print(f"Training: {X_train.shape[0]:,} policies")
print(f"Validation: {X_val.shape[0]:,} policies")
print(f"Test: {X_test.shape[0]:,} policies")

# COMMAND ----------

model = PoissonMixtureNN(
    n_features=8,
    hidden_sizes=[64, 64, 32, 32, 16],
    dropout=0.1,
    batch_norm=True,
    activation="elu",
    constrain_separation=True,
)

n_params = sum(p.numel() for p in model.parameters())
print(f"Model parameters: {n_params:,}")
print(f"Architecture: {model.hidden_sizes}")
print(f"Constrained ordering (lambda_1 > lambda_0): {model.constrain_separation}")

# COMMAND ----------

trainer = PoissonMixtureTrainer(
    model,
    lr=1e-3,
    batch_size=512,
    max_epochs=200,
    patience=20,
    weight_decay=1e-4,
)

print("Training PM-DNN...")
history = trainer.fit(X_train, y_train, exp_train, X_val, y_val, exp_val)

print(f"\nTraining complete:")
print(f"  Epochs run: {history.n_epochs()}")
print(f"  Best val NLL: {history.best_val_nll:.4f}")
print(f"  Best epoch: {history.best_epoch}")
print(f"  Early stopping: {history.stopped_early}")
print(f"  NLL improvement: {history.improvement():.4f}")

# COMMAND ----------

# Plot training curves
predictor = PoissonMixturePredictor(model, device="cpu")
diag = MixtureDiagnostics(predictor)

fig = diag.training_curves(history)
fig.savefig("/tmp/training_curves.png", dpi=120, bbox_inches="tight")
plt.close()
display(plt.imread("/tmp/training_curves.png"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Component separation

# COMMAND ----------

fig = diag.component_separation(X_test, exp_test)
fig.savefig("/tmp/component_separation.png", dpi=120, bbox_inches="tight")
plt.close()
display(plt.imread("/tmp/component_separation.png"))

# COMMAND ----------

# Summary statistics on the test set
summary_diag = diag.summary_table(X_test, y_test, exp_test)
print("Model diagnostics on test set:")
for k, v in summary_diag.items():
    if isinstance(v, float):
        print(f"  {k}: {v:.4f}")
    else:
        print(f"  {k}: {v}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Pi calibration
# MAGIC
# MAGIC Does pi(x) correctly identify high-risk vs low-risk policies?
# MAGIC Policies in higher pi deciles should have higher observed claim rates.

# COMMAND ----------

fig = diag.pi_calibration(X_test, y_test, exp_test, n_deciles=10)
fig.savefig("/tmp/pi_calibration.png", dpi=120, bbox_inches="tight")
plt.close()
display(plt.imread("/tmp/pi_calibration.png"))

# COMMAND ----------

# Check: does predicted pi correlate with true group membership?
pi_test = predictor.predict_pi(X_test)
true_group_test = data.true_group_test()

mean_pi_safe = pi_test[true_group_test == 0].mean()
mean_pi_risky = pi_test[true_group_test == 1].mean()

print(f"Mean predicted pi for safe group (true group=0):  {mean_pi_safe:.4f}")
print(f"Mean predicted pi for risky group (true group=1): {mean_pi_risky:.4f}")
print()
if mean_pi_risky > mean_pi_safe:
    print("The model successfully assigns higher pi to the true risky group.")
else:
    print("Note: with limited training, separation may be partial.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Zero-claim decomposition
# MAGIC
# MAGIC For zero-claim policies: what fraction are structural zeros?
# MAGIC The PM-DNN assigns a posterior P(structural | Y=0, x) to each.

# COMMAND ----------

fig = diag.zero_decomposition(X_test, y_test, exp_test)
fig.savefig("/tmp/zero_decomposition.png", dpi=120, bbox_inches="tight")
plt.close()
display(plt.imread("/tmp/zero_decomposition.png"))

# COMMAND ----------

# Detailed zero-claim analysis
zero_mask = (y_test == 0)
X_zero = X_test[zero_mask]
exp_zero = exp_test[zero_mask]
pi_zero = predictor.predict_pi(X_zero)

print(f"Zero-claim policies in test set: {zero_mask.sum():,}")
print()
print(f"Among zero-claimers, predicted pi distribution:")
print(f"  Mean pi:    {pi_zero.mean():.3f}")
print(f"  Median pi:  {np.median(pi_zero):.3f}")
print(f"  % with pi < 0.3 (likely structural): {(pi_zero < 0.3).mean():.1%}")
print(f"  % with pi > 0.7 (likely stochastic): {(pi_zero > 0.7).mean():.1%}")
print()
print("These are the two groups that standard ZIP treats identically.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Pricing comparison: structural vs stochastic zeros
# MAGIC
# MAGIC What does this mean for premium calculation?

# COMMAND ----------

# Split zero-claimers into structural and stochastic based on pi threshold
structural_mask = pi_zero < 0.5
stochastic_mask = ~structural_mask

comps_zero = predictor.predict_components(X_zero, exp_zero)
expected_struct = comps_zero["expected"][structural_mask]
expected_stoch = comps_zero["expected"][stochastic_mask]

print("Expected claim frequency for zero-claim policies:")
print(f"  Structural zeros (pi < 0.5): mean expected = {expected_struct.mean():.4f}")
print(f"  Stochastic zeros (pi > 0.5): mean expected = {expected_stoch.mean():.4f}")
print()
ratio = expected_stoch.mean() / max(expected_struct.mean(), 1e-10)
print(f"  Ratio: stochastic/structural = {ratio:.1f}x")
print()
print("Stochastic zeros carry significantly higher expected frequency.")
print("A pricing model that ignores this distinction cross-subsidises risk groups.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. Model comparison
# MAGIC
# MAGIC Compare PM-DNN against Poisson GLM, ZIP GLM, and Poisson DNN.

# COMMAND ----------

# Use a subset for faster comparison fitting
n_comp = min(3000, len(X_train))
comp = ModelComparison(model, max_epochs_dnn=50, verbose=True)
results = comp.compare(
    X_train[:n_comp], y_train[:n_comp], exp_train[:n_comp],
    X_test, y_test, exp_test,
)

# COMMAND ----------

df = comp.results_dataframe()
print("Model comparison (sorted by test NLL, lower is better):")
print(df)

# COMMAND ----------

import polars as pl

fig, axes = plt.subplots(1, 2, figsize=(10, 4))

model_names = df["model"].to_list()
nlls = df["test_nll"].to_list()
ginis = df["gini"].to_list()

colours = ["#4CAF50" if n == "PM-DNN" else "#9E9E9E" for n in model_names]

axes[0].barh(model_names, nlls, color=colours)
axes[0].set_xlabel("Test NLL (lower is better)")
axes[0].set_title("Test Set NLL by Model")
axes[0].invert_xaxis()

axes[1].barh(model_names, ginis, color=colours)
axes[1].set_xlabel("Gini (higher is better)")
axes[1].set_title("Gini Coefficient by Model")

plt.tight_layout()
plt.savefig("/tmp/model_comparison.png", dpi=120, bbox_inches="tight")
plt.close()
display(plt.imread("/tmp/model_comparison.png"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Summary
# MAGIC
# MAGIC The PM-DNN provides three outputs that standard frequency models do not:
# MAGIC
# MAGIC | Output | What it is | How to use it |
# MAGIC |--------|-----------|--------------|
# MAGIC | `predict_expected(X, t)` | E[Y\|x] = mixture mean | Frequency in pricing |
# MAGIC | `predict_pi(X)` | P(at-risk\|x) | Structural zero score; NCD signal |
# MAGIC | `zero_decomposition(X, t)` | P(structural\|Y=0, x) | Distinguish lucky from safe |
# MAGIC
# MAGIC **The key pricing implication:** Two policyholders with identical covariate
# MAGIC profiles and zero claims last year should not necessarily receive the same
# MAGIC renewal premium. Their pi scores — derived from telematics behaviour patterns
# MAGIC — distinguish the structural zero from the stochastic zero. That distinction
# MAGIC is actuarially sound and FCA Consumer Duty aligned.

# COMMAND ----------

print("Demo complete.")
print(f"Best PM-DNN val NLL: {history.best_val_nll:.4f}")
print(f"Ordering constraint violations: {summary_diag['ordering_violated_count']}")
print(f"Gini coefficient: {summary_diag['gini']:.4f}")
