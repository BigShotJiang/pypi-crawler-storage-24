"""Tests for PoissonMixturePredictor inference API."""

import numpy as np
import pytest
import torch

from insurance_poisson_mixture_nn.model import PoissonMixtureNN
from insurance_poisson_mixture_nn.predictor import PoissonMixturePredictor


@pytest.fixture
def trained_predictor():
    """A predictor wrapping an initialised (not trained) tiny model."""
    model = PoissonMixtureNN(n_features=8, hidden_sizes=[8, 4])
    model.eval()
    return PoissonMixturePredictor(model, device="cpu")


@pytest.fixture
def X_test():
    rng = np.random.default_rng(7)
    return rng.standard_normal((50, 8)).astype(np.float32)


@pytest.fixture
def exposure_test():
    rng = np.random.default_rng(8)
    return rng.uniform(0.5, 1.0, 50).astype(np.float32)


class TestPoissonMixturePredictor:
    def test_predict_pi_shape(self, trained_predictor, X_test):
        pi = trained_predictor.predict_pi(X_test)
        assert pi.shape == (50,)

    def test_predict_pi_in_unit_interval(self, trained_predictor, X_test):
        pi = trained_predictor.predict_pi(X_test)
        assert (pi > 0).all() and (pi < 1).all()

    def test_predict_expected_shape(self, trained_predictor, X_test, exposure_test):
        freq = trained_predictor.predict_expected(X_test, exposure_test)
        assert freq.shape == (50,)

    def test_predict_expected_positive(self, trained_predictor, X_test, exposure_test):
        freq = trained_predictor.predict_expected(X_test, exposure_test)
        assert (freq > 0).all()

    def test_predict_expected_no_exposure_defaults_to_one(self, trained_predictor, X_test):
        freq = trained_predictor.predict_expected(X_test, exposure=None)
        assert freq.shape == (50,)

    def test_predict_structural_zero_score_complements_pi(self, trained_predictor, X_test):
        pi = trained_predictor.predict_pi(X_test)
        score = trained_predictor.predict_structural_zero_score(X_test)
        np.testing.assert_allclose(score, 1.0 - pi, rtol=1e-5)

    def test_predict_components_keys(self, trained_predictor, X_test, exposure_test):
        comps = trained_predictor.predict_components(X_test, exposure_test)
        required = {"pi", "lambda_0", "lambda_1", "rate_0", "rate_1", "expected"}
        assert required.issubset(comps.keys())

    def test_predict_components_shapes(self, trained_predictor, X_test, exposure_test):
        comps = trained_predictor.predict_components(X_test, exposure_test)
        for key, arr in comps.items():
            assert arr.shape == (50,), f"Wrong shape for {key}"

    def test_predict_components_lambda_ordering(self, trained_predictor, X_test, exposure_test):
        comps = trained_predictor.predict_components(X_test, exposure_test)
        assert (comps["lambda_1"] > comps["lambda_0"]).all()

    def test_predict_components_rate_ordering(self, trained_predictor, X_test, exposure_test):
        comps = trained_predictor.predict_components(X_test, exposure_test)
        assert (comps["rate_1"] > comps["rate_0"]).all()

    def test_predict_components_expected_consistent(self, trained_predictor, X_test, exposure_test):
        comps = trained_predictor.predict_components(X_test, exposure_test)
        expected_manual = (
            comps["pi"] * comps["rate_1"] + (1 - comps["pi"]) * comps["rate_0"]
        )
        np.testing.assert_allclose(comps["expected"], expected_manual, rtol=1e-5)

    def test_classify_zero_returns_strings(self, trained_predictor, X_test):
        labels = trained_predictor.classify_zero(X_test)
        assert labels.dtype.kind in ("U", "S", "O")  # unicode, bytes, or object string
        valid = {"structural", "stochastic"}
        assert set(np.unique(labels)).issubset(valid)

    def test_classify_zero_shape(self, trained_predictor, X_test):
        labels = trained_predictor.classify_zero(X_test)
        assert labels.shape == (50,)

    def test_classify_zero_threshold_affects_result(self, trained_predictor, X_test):
        labels_low = trained_predictor.classify_zero(X_test, threshold=0.1)
        labels_high = trained_predictor.classify_zero(X_test, threshold=0.9)
        # With threshold=0.1, few are classified structural; with 0.9, many are
        n_struct_low = (labels_low == "structural").sum()
        n_struct_high = (labels_high == "structural").sum()
        assert n_struct_high >= n_struct_low

    def test_zero_decomposition_keys(self, trained_predictor, X_test, exposure_test):
        decomp = trained_predictor.zero_decomposition(X_test, exposure_test)
        required = {
            "p_zero_total",
            "p_zero_structural",
            "p_zero_stochastic",
            "posterior_structural",
        }
        assert required.issubset(decomp.keys())

    def test_zero_decomposition_sums_to_total(self, trained_predictor, X_test, exposure_test):
        decomp = trained_predictor.zero_decomposition(X_test, exposure_test)
        total = decomp["p_zero_structural"] + decomp["p_zero_stochastic"]
        np.testing.assert_allclose(total, decomp["p_zero_total"], rtol=1e-5)

    def test_zero_decomposition_posterior_in_unit_interval(self, trained_predictor, X_test, exposure_test):
        decomp = trained_predictor.zero_decomposition(X_test, exposure_test)
        posterior = decomp["posterior_structural"]
        assert (posterior >= 0).all() and (posterior <= 1).all()

    def test_p_zero_total_in_unit_interval(self, trained_predictor, X_test, exposure_test):
        decomp = trained_predictor.zero_decomposition(X_test, exposure_test)
        p_zero = decomp["p_zero_total"]
        assert (p_zero > 0).all() and (p_zero <= 1).all()

    def test_batched_inference_matches_single(self, trained_predictor, X_test):
        """Batched inference should produce same results as a single batch."""
        predictor_small_batch = PoissonMixturePredictor(
            trained_predictor.model, device="cpu", batch_size=10
        )
        pi_full = trained_predictor.predict_pi(X_test)
        pi_small = predictor_small_batch.predict_pi(X_test)
        np.testing.assert_allclose(pi_full, pi_small, rtol=1e-5)

    def test_single_policy_inference(self, trained_predictor):
        """Single-row inference should not crash."""
        X_single = np.random.randn(1, 8).astype(np.float32)
        pi = trained_predictor.predict_pi(X_single)
        assert pi.shape == (1,)

    def test_predict_expected_scales_with_exposure(self, trained_predictor, X_test):
        """Doubling exposure should double expected frequency."""
        exp1 = np.ones(50, dtype=np.float32)
        exp2 = np.full(50, 2.0, dtype=np.float32)
        freq1 = trained_predictor.predict_expected(X_test, exp1)
        freq2 = trained_predictor.predict_expected(X_test, exp2)
        np.testing.assert_allclose(freq2, 2.0 * freq1, rtol=1e-4)

    def test_deterministic_in_eval_mode(self, trained_predictor, X_test):
        """Predictor should be deterministic (model in eval mode, no dropout effect)."""
        pi1 = trained_predictor.predict_pi(X_test)
        pi2 = trained_predictor.predict_pi(X_test)
        np.testing.assert_array_equal(pi1, pi2)
