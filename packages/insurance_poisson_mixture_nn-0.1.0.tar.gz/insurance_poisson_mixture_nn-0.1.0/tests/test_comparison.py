"""Tests for ModelComparison and gini_coefficient."""

import numpy as np
import pytest

from insurance_poisson_mixture_nn.comparison import (
    ComparisonResult,
    ModelComparison,
    gini_coefficient,
)
from insurance_poisson_mixture_nn.model import PoissonMixtureNN


class TestGiniCoefficient:
    def test_perfect_model(self):
        """Perfect ranking: Gini = 1."""
        y_true = np.array([0, 0, 0, 1, 2, 3], dtype=float)
        y_pred = np.array([0.1, 0.2, 0.3, 0.8, 0.9, 1.0], dtype=float)
        # Not necessarily 1.0 for discrete data but should be close to max
        gini = gini_coefficient(y_true, y_pred)
        assert gini > 0.0

    def test_random_model_near_zero(self):
        """Random model (pred = constant) should give Gini near 0."""
        rng = np.random.default_rng(42)
        y_true = rng.poisson(0.2, 1000).astype(float)
        y_pred = np.ones(1000) * 0.2  # constant prediction
        gini = gini_coefficient(y_true, y_pred)
        # Constant prediction = no ranking = Gini ≈ 0
        assert abs(gini) < 0.1

    def test_all_zeros_y_true(self):
        """No claims: Gini undefined, should return 0."""
        y_true = np.zeros(10)
        y_pred = np.arange(1, 11, dtype=float)
        gini = gini_coefficient(y_true, y_pred)
        assert gini == 0.0

    def test_gini_in_valid_range(self):
        rng = np.random.default_rng(1)
        y_true = rng.poisson(0.15, 500).astype(float)
        y_pred = rng.uniform(0, 1, 500)
        gini = gini_coefficient(y_true, y_pred)
        assert -1.0 <= gini <= 1.0

    def test_better_predictor_higher_gini(self):
        rng = np.random.default_rng(10)
        y_true = rng.poisson(0.2, 1000).astype(float)
        # Good predictor: close to true
        y_good = y_true + rng.normal(0, 0.05, 1000)
        # Bad predictor: random noise
        y_bad = rng.uniform(0, 1, 1000)
        gini_good = gini_coefficient(y_true, y_good)
        gini_bad = gini_coefficient(y_true, y_bad)
        assert gini_good >= gini_bad - 0.1  # allow small tolerance


class TestComparisonResult:
    def test_dataclass_creation(self):
        result = ComparisonResult(
            model_name="Test Model",
            test_nll=0.5,
            gini=0.3,
            n_params=1000,
            notes="test",
        )
        assert result.model_name == "Test Model"
        assert result.test_nll == 0.5

    def test_optional_n_params(self):
        result = ComparisonResult(model_name="X", test_nll=1.0, gini=0.2)
        assert result.n_params is None


class TestModelComparison:
    @pytest.fixture
    def small_comparison_setup(self):
        rng = np.random.default_rng(42)
        n_tr, n_te = 200, 50
        X_tr = rng.standard_normal((n_tr, 4)).astype(np.float32)
        y_tr = rng.poisson(0.15, n_tr).astype(np.float32)
        exp_tr = rng.uniform(0.5, 1.0, n_tr).astype(np.float32)

        X_te = rng.standard_normal((n_te, 4)).astype(np.float32)
        y_te = rng.poisson(0.15, n_te).astype(np.float32)
        exp_te = rng.uniform(0.5, 1.0, n_te).astype(np.float32)

        model = PoissonMixtureNN(n_features=4, hidden_sizes=[8, 4])
        return model, X_tr, y_tr, exp_tr, X_te, y_te, exp_te

    def test_compare_returns_list(self, small_comparison_setup):
        model, X_tr, y_tr, exp_tr, X_te, y_te, exp_te = small_comparison_setup
        comp = ModelComparison(model, max_epochs_dnn=3, verbose=False)
        results = comp.compare(X_tr, y_tr, exp_tr, X_te, y_te, exp_te)
        assert isinstance(results, list)
        assert len(results) >= 1  # at least PM-DNN

    def test_pm_dnn_always_present(self, small_comparison_setup):
        model, X_tr, y_tr, exp_tr, X_te, y_te, exp_te = small_comparison_setup
        comp = ModelComparison(model, max_epochs_dnn=3, verbose=False)
        results = comp.compare(X_tr, y_tr, exp_tr, X_te, y_te, exp_te)
        names = [r.model_name for r in results]
        assert "PM-DNN" in names

    def test_all_nlls_finite(self, small_comparison_setup):
        model, X_tr, y_tr, exp_tr, X_te, y_te, exp_te = small_comparison_setup
        comp = ModelComparison(model, max_epochs_dnn=3, verbose=False)
        results = comp.compare(X_tr, y_tr, exp_tr, X_te, y_te, exp_te)
        for r in results:
            assert np.isfinite(r.test_nll), f"Non-finite NLL for {r.model_name}"

    def test_all_ginis_valid(self, small_comparison_setup):
        model, X_tr, y_tr, exp_tr, X_te, y_te, exp_te = small_comparison_setup
        comp = ModelComparison(model, max_epochs_dnn=3, verbose=False)
        results = comp.compare(X_tr, y_tr, exp_tr, X_te, y_te, exp_te)
        for r in results:
            assert -1.0 <= r.gini <= 1.0, f"Invalid Gini for {r.model_name}"

    def test_results_dataframe_returns_polars(self, small_comparison_setup):
        import polars as pl
        model, X_tr, y_tr, exp_tr, X_te, y_te, exp_te = small_comparison_setup
        comp = ModelComparison(model, max_epochs_dnn=3, verbose=False)
        comp.compare(X_tr, y_tr, exp_tr, X_te, y_te, exp_te)
        df = comp.results_dataframe()
        assert isinstance(df, pl.DataFrame)

    def test_results_dataframe_sorted_by_nll(self, small_comparison_setup):
        model, X_tr, y_tr, exp_tr, X_te, y_te, exp_te = small_comparison_setup
        comp = ModelComparison(model, max_epochs_dnn=3, verbose=False)
        comp.compare(X_tr, y_tr, exp_tr, X_te, y_te, exp_te)
        df = comp.results_dataframe()
        nlls = df["test_nll"].to_list()
        assert nlls == sorted(nlls)

    def test_poisson_dnn_baseline_included(self, small_comparison_setup):
        model, X_tr, y_tr, exp_tr, X_te, y_te, exp_te = small_comparison_setup
        comp = ModelComparison(model, max_epochs_dnn=3, verbose=False)
        results = comp.compare(X_tr, y_tr, exp_tr, X_te, y_te, exp_te)
        names = [r.model_name for r in results]
        assert "Poisson DNN" in names
