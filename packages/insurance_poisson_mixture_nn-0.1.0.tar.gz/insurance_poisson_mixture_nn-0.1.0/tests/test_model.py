"""Tests for PoissonMixtureNN model architecture and constraints."""

import numpy as np
import pytest
import torch
import torch.nn as nn

from insurance_poisson_mixture_nn.model import (
    MixtureProbHead,
    PoissonHead,
    PoissonMixtureNN,
    SharedTrunk,
)


class TestSharedTrunk:
    def test_output_shape(self):
        trunk = SharedTrunk(n_features=10, hidden_sizes=[16, 8])
        x = torch.randn(32, 10)
        z = trunk(x)
        assert z.shape == (32, 8)

    def test_out_features_attribute(self):
        trunk = SharedTrunk(n_features=5, hidden_sizes=[32, 16, 8])
        assert trunk.out_features == 8

    def test_single_hidden_layer(self):
        trunk = SharedTrunk(n_features=4, hidden_sizes=[16])
        x = torch.randn(10, 4)
        z = trunk(x)
        assert z.shape == (10, 16)

    def test_relu_activation(self):
        trunk = SharedTrunk(n_features=4, hidden_sizes=[8], activation="relu")
        x = torch.randn(5, 4)
        z = trunk(x)
        assert z.shape == (5, 8)

    def test_invalid_activation_raises(self):
        with pytest.raises(ValueError, match="Unknown activation"):
            SharedTrunk(n_features=4, hidden_sizes=[8], activation="tanh")

    def test_no_batch_norm(self):
        trunk = SharedTrunk(n_features=4, hidden_sizes=[8], batch_norm=False)
        x = torch.randn(5, 4)
        z = trunk(x)
        assert z.shape == (5, 8)

    def test_no_dropout(self):
        trunk = SharedTrunk(n_features=4, hidden_sizes=[8], dropout=0.0)
        x = torch.randn(5, 4)
        z = trunk(x)
        assert z.shape == (5, 8)

    def test_gradient_flows_through_trunk(self):
        trunk = SharedTrunk(n_features=4, hidden_sizes=[8])
        x = torch.randn(5, 4, requires_grad=True)
        z = trunk(x)
        loss = z.sum()
        loss.backward()
        assert x.grad is not None


class TestMixtureProbHead:
    def test_output_in_unit_interval(self):
        head = MixtureProbHead(in_features=16)
        z = torch.randn(100, 16)
        pi = head(z)
        assert pi.shape == (100,)
        assert (pi > 0).all()
        assert (pi < 1).all()

    def test_sigmoid_output(self):
        head = MixtureProbHead(in_features=4)
        z = torch.zeros(10, 4)
        pi = head(z)
        # With zero input and zero bias, sigmoid(bias) ≈ 0.5
        # Values should be near 0.5 but not guaranteed exactly
        assert (pi > 0).all() and (pi < 1).all()

    def test_extreme_logits(self):
        head = MixtureProbHead(in_features=1)
        # Force a very large positive output
        with torch.no_grad():
            head.linear.weight.fill_(1.0)
            head.linear.bias.fill_(100.0)
        z = torch.ones(5, 1)
        pi = head(z)
        assert (pi > 0.99).all()


class TestPoissonHead:
    def test_output_positive(self):
        head = PoissonHead(in_features=16)
        z = torch.randn(100, 16)
        rate = head(z)
        assert rate.shape == (100,)
        assert (rate > 0).all()

    def test_softplus_output(self):
        head = PoissonHead(in_features=4)
        z = torch.zeros(10, 4)
        rate = head(z)
        assert (rate > 0).all()


class TestPoissonMixtureNN:
    def test_forward_output_shapes(self, tiny_model):
        x = torch.randn(64, 8)
        pi, lam0, lam1 = tiny_model(x)
        assert pi.shape == (64,)
        assert lam0.shape == (64,)
        assert lam1.shape == (64,)

    def test_pi_in_unit_interval(self, tiny_model):
        x = torch.randn(100, 8)
        pi, _, _ = tiny_model(x)
        assert (pi > 0).all() and (pi < 1).all()

    def test_lambda_0_positive(self, tiny_model):
        x = torch.randn(100, 8)
        _, lam0, _ = tiny_model(x)
        assert (lam0 > 0).all()

    def test_lambda_1_positive(self, tiny_model):
        x = torch.randn(100, 8)
        _, _, lam1 = tiny_model(x)
        assert (lam1 > 0).all()

    def test_ordering_constraint_enforced(self, tiny_model):
        """With constrain_separation=True, lambda_1 > lambda_0 always."""
        x = torch.randn(200, 8)
        _, lam0, lam1 = tiny_model(x)
        assert (lam1 > lam0).all()

    def test_unconstrained_model_does_not_enforce_ordering(self):
        """Without constraint, the ordering is not guaranteed."""
        model = PoissonMixtureNN(n_features=8, hidden_sizes=[8, 4], constrain_separation=False)
        # We cannot guarantee ordering violation, but model should run
        x = torch.randn(100, 8)
        pi, lam0, lam1 = model(x)
        assert pi.shape == (100,)

    def test_expected_frequency_shape(self, tiny_model):
        x = torch.randn(50, 8)
        freq = tiny_model.expected_frequency(x)
        assert freq.shape == (50,)

    def test_expected_frequency_positive(self, tiny_model):
        x = torch.randn(50, 8)
        freq = tiny_model.expected_frequency(x)
        assert (freq > 0).all()

    def test_expected_frequency_with_exposure(self, tiny_model):
        # Use eval mode to disable dropout so two forward passes are identical.
        tiny_model.eval()
        x = torch.randn(10, 8)
        exposure = torch.ones(10) * 2.0
        freq_2yr = tiny_model.expected_frequency(x, exposure)
        freq_1yr = tiny_model.expected_frequency(x)
        # Double exposure should double expected frequency (linear in exposure)
        torch.testing.assert_close(freq_2yr, 2.0 * freq_1yr, rtol=1e-4, atol=1e-6)

    def test_structural_zero_score_shape(self, tiny_model):
        x = torch.randn(30, 8)
        score = tiny_model.structural_zero_score(x)
        assert score.shape == (30,)

    def test_structural_zero_score_complements_pi(self, tiny_model):
        # Eval mode ensures deterministic output from both calls.
        tiny_model.eval()
        x = torch.randn(30, 8)
        pi, _, _ = tiny_model(x)
        score = tiny_model.structural_zero_score(x)
        torch.testing.assert_close(score, 1.0 - pi, rtol=1e-5, atol=1e-7)

    def test_default_hidden_sizes(self):
        model = PoissonMixtureNN(n_features=5)
        assert model.hidden_sizes == [64, 64, 32, 32, 16]

    def test_custom_hidden_sizes(self):
        model = PoissonMixtureNN(n_features=5, hidden_sizes=[32, 16])
        x = torch.randn(10, 5)
        pi, lam0, lam1 = model(x)
        assert pi.shape == (10,)

    def test_batch_size_1(self, tiny_model):
        """Single-sample inference should not crash BatchNorm (eval mode)."""
        tiny_model.eval()
        x = torch.randn(1, 8)
        pi, lam0, lam1 = tiny_model(x)
        assert pi.shape == (1,)

    def test_gradient_flows_to_all_parameters(self, tiny_model):
        x = torch.randn(32, 8)
        pi, lam0, lam1 = tiny_model(x)
        loss = pi.sum() + lam0.sum() + lam1.sum()
        loss.backward()
        for name, param in tiny_model.named_parameters():
            assert param.grad is not None, f"No gradient for {name}"

    def test_n_features_stored(self):
        model = PoissonMixtureNN(n_features=15)
        assert model.n_features == 15

    def test_train_eval_mode_toggle(self, tiny_model):
        tiny_model.train()
        assert tiny_model.training
        tiny_model.eval()
        assert not tiny_model.training

    def test_ordering_after_many_random_inputs(self):
        """Stress test: ordering constraint holds for 1000 random inputs."""
        model = PoissonMixtureNN(n_features=8, hidden_sizes=[16, 8])
        x = torch.randn(1000, 8)
        _, lam0, lam1 = model(x)
        violations = (lam1 <= lam0).sum().item()
        assert violations == 0, f"{violations} ordering constraint violations"
