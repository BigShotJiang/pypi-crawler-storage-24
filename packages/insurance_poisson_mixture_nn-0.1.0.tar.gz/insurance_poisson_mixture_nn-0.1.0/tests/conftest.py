"""Shared fixtures for the insurance-poisson-mixture-nn test suite."""

import numpy as np
import pytest
import torch

from insurance_poisson_mixture_nn.model import PoissonMixtureNN
from insurance_poisson_mixture_nn.synthetic import SyntheticMixtureData


@pytest.fixture(scope="session")
def small_data():
    """Small synthetic dataset for fast tests."""
    return SyntheticMixtureData(n_policies=500, seed=0)


@pytest.fixture(scope="session")
def medium_data():
    """Medium synthetic dataset for trainer tests."""
    return SyntheticMixtureData(n_policies=2000, seed=1)


@pytest.fixture
def tiny_model():
    """Very small model for fast forward-pass tests."""
    return PoissonMixtureNN(n_features=8, hidden_sizes=[8, 4])


@pytest.fixture
def default_model():
    """Default 5-layer model matching paper architecture."""
    return PoissonMixtureNN(n_features=8)


@pytest.fixture
def rng():
    """Fixed numpy random generator."""
    return np.random.default_rng(42)


@pytest.fixture
def simple_batch(rng):
    """A simple (X, y, exposure) batch for 64 policies with 8 features."""
    X = rng.standard_normal((64, 8)).astype(np.float32)
    y = rng.poisson(lam=0.15, size=64).astype(np.float32)
    exposure = rng.uniform(0.5, 1.0, size=64).astype(np.float32)
    return X, y, exposure


@pytest.fixture
def torch_batch(simple_batch):
    """The simple_batch as torch tensors."""
    X, y, exposure = simple_batch
    return (
        torch.tensor(X),
        torch.tensor(y),
        torch.tensor(exposure),
    )
