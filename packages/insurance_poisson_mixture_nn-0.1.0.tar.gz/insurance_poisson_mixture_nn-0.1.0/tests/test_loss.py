"""Tests for the PoissonMixtureNLL loss function."""

import numpy as np
import pytest
import torch

from insurance_poisson_mixture_nn.loss import (
    PoissonMixtureNLL,
    poisson_log_pmf,
)


class TestPoissonLogPMF:
    def test_known_value_k0(self):
        """P(0; rate=1.0) = exp(-1) ≈ 0.3679."""
        k = torch.tensor([0.0])
        rate = torch.tensor([1.0])
        log_p = poisson_log_pmf(k, rate)
        expected = torch.tensor([-1.0])  # log(exp(-1)) = -1
        torch.testing.assert_close(log_p, expected, rtol=1e-5, atol=1e-6)

    def test_known_value_k1(self):
        """P(1; rate=1.0) = exp(-1) * 1 ≈ 0.3679."""
        k = torch.tensor([1.0])
        rate = torch.tensor([1.0])
        log_p = poisson_log_pmf(k, rate)
        expected = torch.tensor([-1.0])  # 1*log(1) - 1 - log(1!) = -1
        torch.testing.assert_close(log_p, expected, rtol=1e-5, atol=1e-6)

    def test_known_value_k2(self):
        """P(2; rate=2.0) = exp(-2) * 4 / 2 = exp(-2) * 2 ≈ 0.2707."""
        k = torch.tensor([2.0])
        rate = torch.tensor([2.0])
        log_p = poisson_log_pmf(k, rate)
        # 2*log(2) - 2 - log(2!) = 2*0.6931 - 2 - 0.6931 = 0.6931 - 2 = -1.3069
        expected = torch.log(torch.tensor([0.2707]))
        torch.testing.assert_close(log_p, expected, rtol=1e-3, atol=1e-4)

    def test_batch_computation(self):
        k = torch.tensor([0.0, 1.0, 2.0, 3.0])
        rate = torch.tensor([1.0, 1.0, 1.0, 1.0])
        log_p = poisson_log_pmf(k, rate)
        assert log_p.shape == (4,)
        # All should be <= 0 (log of probability)
        assert (log_p <= 0).all()

    def test_log_pmf_sums_to_near_one(self):
        """Sum of Poisson PMF over k=0..20 should be near 1 for rate=3."""
        rate = 3.0
        k_vals = torch.arange(0, 21, dtype=torch.float32)
        rate_tensor = torch.full_like(k_vals, rate)
        log_probs = poisson_log_pmf(k_vals, rate_tensor)
        total = log_probs.exp().sum().item()
        assert abs(total - 1.0) < 0.01

    def test_clamping_prevents_nan(self):
        """Very small rate should not produce NaN."""
        k = torch.tensor([0.0])
        rate = torch.tensor([1e-15])
        log_p = poisson_log_pmf(k, rate)
        assert not torch.isnan(log_p).any()

    def test_zero_count_large_rate(self):
        """P(0; rate=10) = exp(-10) — should be very negative but finite."""
        k = torch.tensor([0.0])
        rate = torch.tensor([10.0])
        log_p = poisson_log_pmf(k, rate)
        assert torch.isfinite(log_p).all()
        assert log_p.item() < -9.0


class TestPoissonMixtureNLL:
    def setup_method(self):
        self.loss_fn = PoissonMixtureNLL()

    def _make_batch(self, n=32, pi_val=0.5, lam0_val=0.01, lam1_val=0.3, rate_val=0.1):
        pi = torch.full((n,), pi_val)
        lam0 = torch.full((n,), lam0_val)
        lam1 = torch.full((n,), lam1_val)
        y = torch.zeros(n)  # all zeros
        exposure = torch.ones(n)
        return pi, lam0, lam1, y, exposure

    def test_returns_scalar_for_mean_reduction(self):
        pi, lam0, lam1, y, exp = self._make_batch()
        loss = self.loss_fn(pi, lam0, lam1, y, exp)
        assert loss.shape == ()

    def test_returns_scalar_for_sum_reduction(self):
        loss_fn = PoissonMixtureNLL(reduction="sum")
        pi, lam0, lam1, y, exp = self._make_batch()
        loss = loss_fn(pi, lam0, lam1, y, exp)
        assert loss.shape == ()

    def test_returns_batch_for_none_reduction(self):
        loss_fn = PoissonMixtureNLL(reduction="none")
        pi, lam0, lam1, y, exp = self._make_batch(n=16)
        loss = loss_fn(pi, lam0, lam1, y, exp)
        assert loss.shape == (16,)

    def test_invalid_reduction_raises(self):
        with pytest.raises(ValueError, match="reduction"):
            PoissonMixtureNLL(reduction="invalid")

    def test_nll_positive(self):
        """NLL should be positive for valid probability distributions."""
        pi, lam0, lam1, y, exp = self._make_batch()
        loss = self.loss_fn(pi, lam0, lam1, y, exp)
        assert loss.item() > 0

    def test_nll_is_finite(self):
        pi, lam0, lam1, y, exp = self._make_batch()
        loss = self.loss_fn(pi, lam0, lam1, y, exp)
        assert torch.isfinite(loss)

    def test_no_nan_with_extreme_pi(self):
        """pi near 0 or 1 should not produce NaN."""
        pi_near_zero = torch.full((10,), 1e-7)
        pi_near_one = torch.full((10,), 1.0 - 1e-7)
        lam0 = torch.full((10,), 0.01)
        lam1 = torch.full((10,), 0.3)
        y = torch.zeros(10)
        exp = torch.ones(10)

        for pi in [pi_near_zero, pi_near_one]:
            loss = self.loss_fn(pi, lam0, lam1, y, exp)
            assert torch.isfinite(loss), f"NaN with pi={pi[0].item()}"

    def test_no_nan_with_large_lambda(self):
        """Large lambda should not produce NaN (exposure-weighted)."""
        pi = torch.full((10,), 0.5)
        lam0 = torch.full((10,), 0.01)
        lam1 = torch.full((10,), 5.0)
        y = torch.tensor([0.0] * 5 + [1.0] * 5)
        exp = torch.ones(10)
        loss = self.loss_fn(pi, lam0, lam1, y, exp)
        assert torch.isfinite(loss)

    def test_lower_nll_for_better_predictions(self):
        """Model that predicts the true rate should have lower NLL."""
        # True rate is 0.2; compare prediction 0.2 vs 0.8
        y = torch.tensor([0.0] * 8 + [1.0] * 2)  # ~0.2 mean
        exp = torch.ones(10)
        lam1_good = torch.full((10,), 0.2)
        lam1_bad = torch.full((10,), 0.8)
        lam0 = torch.full((10,), 0.01)
        pi = torch.full((10,), 0.5)

        nll_good = self.loss_fn(pi, lam0, lam1_good, y, exp)
        nll_bad = self.loss_fn(pi, lam0, lam1_bad, y, exp)
        assert nll_good < nll_bad

    def test_exposure_scaling(self):
        """Doubling exposure for zero-claim policies increases NLL."""
        pi = torch.full((10,), 0.5)
        lam0 = torch.full((10,), 0.01)
        lam1 = torch.full((10,), 0.3)
        y = torch.zeros(10)
        exp_1 = torch.ones(10)
        exp_2 = torch.ones(10) * 2.0

        nll_1 = self.loss_fn(pi, lam0, lam1, y, exp_1)
        nll_2 = self.loss_fn(pi, lam0, lam1, y, exp_2)
        # Higher exposure for zero-claim policies makes zeros less likely → higher NLL
        assert nll_2 > nll_1

    def test_gradient_flows_through_loss(self):
        """Loss must be differentiable for gradient training."""
        pi = torch.tensor([0.3, 0.7, 0.5], requires_grad=True)
        lam0 = torch.tensor([0.01, 0.02, 0.01], requires_grad=True)
        lam1 = torch.tensor([0.3, 0.5, 0.4], requires_grad=True)
        y = torch.tensor([0.0, 1.0, 0.0])
        exp = torch.ones(3)

        loss = self.loss_fn(pi, lam0, lam1, y, exp)
        loss.backward()

        assert pi.grad is not None
        assert lam0.grad is not None
        assert lam1.grad is not None

    def test_per_sample_nll_shape(self):
        loss_fn = PoissonMixtureNLL()
        pi = torch.rand(20)
        lam0 = torch.rand(20) * 0.02
        lam1 = lam0 + torch.rand(20) * 0.3
        y = torch.randint(0, 3, (20,)).float()
        exp = torch.rand(20) + 0.5

        per_sample = loss_fn.per_sample_nll(pi, lam0, lam1, y, exp)
        assert per_sample.shape == (20,)
        assert (per_sample > 0).all()

    def test_mean_equals_sum_divided_by_n(self):
        n = 8
        pi = torch.rand(n)
        lam0 = torch.rand(n) * 0.02
        lam1 = lam0 + torch.rand(n) * 0.3
        y = torch.randint(0, 2, (n,)).float()
        exp = torch.ones(n)

        mean_fn = PoissonMixtureNLL(reduction="mean")
        sum_fn = PoissonMixtureNLL(reduction="sum")

        nll_mean = mean_fn(pi, lam0, lam1, y, exp)
        nll_sum = sum_fn(pi, lam0, lam1, y, exp)
        torch.testing.assert_close(nll_mean, nll_sum / n, rtol=1e-5, atol=1e-6)

    def test_l2_penalty_increases_loss(self):
        """L2 penalty on lambdas should strictly increase the loss."""
        pi = torch.rand(10)
        lam0 = torch.rand(10) * 0.1 + 0.5  # not tiny
        lam1 = lam0 + torch.rand(10) * 0.3
        y = torch.zeros(10)
        exp = torch.ones(10)

        no_penalty = PoissonMixtureNLL(l2_penalty=0.0)(pi, lam0, lam1, y, exp)
        with_penalty = PoissonMixtureNLL(l2_penalty=1.0)(pi, lam0, lam1, y, exp)
        assert with_penalty > no_penalty

    def test_mixture_approaches_poisson_when_pi_near_zero(self):
        """When pi → 0, mixture NLL ≈ Poisson NLL with rate lambda_0."""
        pi = torch.full((100,), 1e-7)
        lam0 = torch.full((100,), 0.2)
        lam1 = torch.full((100,), 0.5)
        y = torch.zeros(100)
        exp = torch.ones(100)

        mixture_nll = PoissonMixtureNLL()(pi, lam0, lam1, y, exp)
        # Pure Poisson(0.2) NLL for all zeros: 0.2 (rate) per observation
        pure_poisson_nll = 0.2
        assert abs(mixture_nll.item() - pure_poisson_nll) < 0.01
