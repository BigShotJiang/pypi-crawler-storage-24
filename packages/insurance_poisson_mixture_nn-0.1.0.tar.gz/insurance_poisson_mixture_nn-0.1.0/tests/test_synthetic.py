"""Tests for the SyntheticMixtureData generator."""

import numpy as np
import pytest

from insurance_poisson_mixture_nn.synthetic import (
    FEATURE_NAMES,
    SyntheticMixtureData,
    generate_telematics_features,
)


class TestGenerateTelematicsFeatures:
    def test_output_shape(self):
        X = generate_telematics_features(n=100, seed=42)
        assert X.shape == (100, 8)

    def test_float32_dtype(self):
        X = generate_telematics_features(n=50)
        assert X.dtype == np.float32

    def test_reproducible_with_seed(self):
        X1 = generate_telematics_features(n=50, seed=1)
        X2 = generate_telematics_features(n=50, seed=1)
        np.testing.assert_array_equal(X1, X2)

    def test_different_seeds_differ(self):
        X1 = generate_telematics_features(n=50, seed=1)
        X2 = generate_telematics_features(n=50, seed=2)
        assert not np.array_equal(X1, X2)

    def test_feature_names_length(self):
        assert len(FEATURE_NAMES) == 8

    def test_no_nan_or_inf(self):
        X = generate_telematics_features(n=500, seed=42)
        assert not np.isnan(X).any()
        assert not np.isinf(X).any()

    def test_night_drive_fraction_bounded(self):
        X = generate_telematics_features(n=1000, seed=42)
        night_drive = X[:, 2]  # night_drive_fraction
        assert (night_drive >= 0).all()
        assert (night_drive <= 1).all()

    def test_claims_last_year_binary(self):
        X = generate_telematics_features(n=1000, seed=42)
        claims = X[:, 7]  # claims_last_year
        assert set(np.unique(claims)).issubset({0.0, 1.0})

    def test_annual_mileage_log_positive(self):
        X = generate_telematics_features(n=500, seed=42)
        mileage_log = X[:, 0]
        assert (mileage_log > 0).all()

    def test_speed_score_bounded(self):
        X = generate_telematics_features(n=500, seed=42)
        speed = X[:, 6]
        assert (speed >= 0).all()
        assert (speed <= 1).all()


class TestSyntheticMixtureData:
    @pytest.fixture
    def data(self):
        return SyntheticMixtureData(n_policies=1000, seed=42)

    def test_X_shape(self, data):
        assert data.X.shape == (1000, 8)

    def test_y_shape(self, data):
        assert data.y.shape == (1000,)

    def test_exposure_shape(self, data):
        assert data.exposure.shape == (1000,)

    def test_true_pi_shape(self, data):
        assert data.true_pi.shape == (1000,)

    def test_true_lambda_0_shape(self, data):
        assert data.true_lambda_0.shape == (1000,)

    def test_true_lambda_1_shape(self, data):
        assert data.true_lambda_1.shape == (1000,)

    def test_true_group_shape(self, data):
        assert data.true_group.shape == (1000,)

    def test_y_non_negative(self, data):
        assert (data.y >= 0).all()

    def test_exposure_bounded(self, data):
        assert (data.exposure >= 0.5).all()
        assert (data.exposure <= 1.0).all()

    def test_true_pi_in_unit_interval(self, data):
        assert (data.true_pi >= 0).all()
        assert (data.true_pi <= 1).all()

    def test_ordering_constraint(self, data):
        """True lambda_1 > true lambda_0 always."""
        assert (data.true_lambda_1 > data.true_lambda_0).all()

    def test_true_group_binary(self, data):
        assert set(np.unique(data.true_group)).issubset({0, 1})

    def test_training_split_shape(self, data):
        X, y, exp = data.training_split()
        n_train = int(1000 * 0.7)
        assert X.shape[0] == n_train
        assert y.shape[0] == n_train
        assert exp.shape[0] == n_train

    def test_validation_split_shape(self, data):
        X, y, exp = data.validation_split()
        n_val = int(1000 * 0.15)
        assert X.shape[0] == n_val

    def test_test_split_no_overlap(self, data):
        """Train, val, test indices should be disjoint."""
        train_idx = set(data._train_idx.tolist())
        val_idx = set(data._val_idx.tolist())
        test_idx = set(data._test_idx.tolist())
        assert len(train_idx & val_idx) == 0
        assert len(train_idx & test_idx) == 0
        assert len(val_idx & test_idx) == 0

    def test_all_indices_covered(self, data):
        all_idx = set(data._train_idx.tolist()) | set(data._val_idx.tolist()) | set(data._test_idx.tolist())
        assert all_idx == set(range(1000))

    def test_structural_zero_fraction_reasonable(self, data):
        frac = data.structural_zero_fraction()
        assert 0 < frac < 1

    def test_summary_keys(self, data):
        s = data.summary()
        required_keys = [
            "n_policies", "n_train", "n_val", "n_test",
            "structural_zero_fraction", "mean_claims",
            "zero_claim_fraction", "mean_exposure",
        ]
        for k in required_keys:
            assert k in s

    def test_summary_n_policies(self, data):
        s = data.summary()
        assert s["n_policies"] == 1000

    def test_reproducibility(self):
        d1 = SyntheticMixtureData(n_policies=100, seed=999)
        d2 = SyntheticMixtureData(n_policies=100, seed=999)
        np.testing.assert_array_equal(d1.y, d2.y)
        np.testing.assert_array_equal(d1.true_pi, d2.true_pi)

    def test_different_seed_gives_different_data(self):
        d1 = SyntheticMixtureData(n_policies=100, seed=1)
        d2 = SyntheticMixtureData(n_policies=100, seed=2)
        assert not np.array_equal(d1.y, d2.y)

    def test_true_pi_test_returns_correct_subset(self, data):
        pi_test = data.true_pi_test()
        assert pi_test.shape == (len(data._test_idx),)
        np.testing.assert_array_equal(pi_test, data.true_pi[data._test_idx])

    def test_true_group_test_returns_correct_subset(self, data):
        group_test = data.true_group_test()
        np.testing.assert_array_equal(group_test, data.true_group[data._test_idx])

    def test_zero_claim_fraction_nonzero(self, data):
        s = data.summary()
        assert s["zero_claim_fraction"] > 0.0

    def test_no_nan_in_X(self, data):
        assert not np.isnan(data.X).any()

    def test_no_nan_in_y(self, data):
        assert not np.isnan(data.y).any()

    def test_lambda_upper_bound_respected(self, data):
        assert (data.true_lambda_0 <= data.lambda_0_max + 1e-6).all()

    def test_lambda1_above_minimum(self, data):
        assert (data.true_lambda_1 >= data.lambda_1_min - 1e-6).all()
