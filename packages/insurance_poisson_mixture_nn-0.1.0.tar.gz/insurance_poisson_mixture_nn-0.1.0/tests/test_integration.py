"""Integration tests: end-to-end training and prediction on synthetic data.

These tests verify that:
1. The full train-predict pipeline runs without errors
2. The model learns something meaningful from synthetic data (better than naive baseline)
3. The ordering constraint holds throughout training and inference
4. NLL decreases from epoch 0 to best epoch
"""

import numpy as np
import pytest

from insurance_poisson_mixture_nn.diagnostics import MixtureDiagnostics
from insurance_poisson_mixture_nn.model import PoissonMixtureNN
from insurance_poisson_mixture_nn.predictor import PoissonMixturePredictor
from insurance_poisson_mixture_nn.synthetic import SyntheticMixtureData
from insurance_poisson_mixture_nn.trainer import PoissonMixtureTrainer


@pytest.fixture(scope="module")
def trained_result():
    """Train a tiny model on synthetic data. Returns (model, predictor, data, history)."""
    data = SyntheticMixtureData(n_policies=1500, seed=42)
    X_tr, y_tr, exp_tr = data.training_split()
    X_val, y_val, exp_val = data.validation_split()
    X_te, y_te, exp_te = data.test_split()

    model = PoissonMixtureNN(n_features=8, hidden_sizes=[16, 8, 8])
    trainer = PoissonMixtureTrainer(
        model,
        lr=5e-3,
        batch_size=128,
        max_epochs=20,
        patience=5,
        device="cpu",
    )
    history = trainer.fit(X_tr, y_tr, exp_tr, X_val, y_val, exp_val)
    predictor = PoissonMixturePredictor(model, device="cpu")

    return model, predictor, data, history, X_te, y_te, exp_te


class TestEndToEndPipeline:
    def test_training_completes(self, trained_result):
        _, _, _, history, _, _, _ = trained_result
        assert history.n_epochs() > 0

    def test_best_val_nll_finite(self, trained_result):
        _, _, _, history, _, _, _ = trained_result
        assert np.isfinite(history.best_val_nll)

    def test_nll_decreases(self, trained_result):
        """Validation NLL at best epoch should be lower than at epoch 0."""
        _, _, _, history, _, _, _ = trained_result
        if history.n_epochs() >= 2:
            assert history.best_val_nll <= history.val_nll[0]

    def test_ordering_constraint_on_test_set(self, trained_result):
        import torch
        model, predictor, _, _, X_te, _, _ = trained_result
        comps = predictor.predict_components(X_te)
        assert (comps["lambda_1"] > comps["lambda_0"]).all()

    def test_expected_frequency_positive(self, trained_result):
        _, predictor, _, _, X_te, _, exp_te = trained_result
        freq = predictor.predict_expected(X_te, exp_te)
        assert (freq > 0).all()

    def test_pi_in_unit_interval(self, trained_result):
        _, predictor, _, _, X_te, _, _ = trained_result
        pi = predictor.predict_pi(X_te)
        assert (pi >= 0).all() and (pi <= 1).all()

    def test_structural_zero_score_complements_pi(self, trained_result):
        _, predictor, _, _, X_te, _, _ = trained_result
        pi = predictor.predict_pi(X_te)
        score = predictor.predict_structural_zero_score(X_te)
        np.testing.assert_allclose(score, 1.0 - pi, rtol=1e-5)

    def test_zero_decomposition_sums_correctly(self, trained_result):
        _, predictor, _, _, X_te, _, exp_te = trained_result
        decomp = predictor.zero_decomposition(X_te, exp_te)
        total = decomp["p_zero_structural"] + decomp["p_zero_stochastic"]
        np.testing.assert_allclose(total, decomp["p_zero_total"], rtol=1e-5)

    def test_pi_correlates_with_true_group(self, trained_result):
        """Predicted pi should be higher for true risky-group policies (coarse check)."""
        _, predictor, data, _, X_te, _, _ = trained_result
        pi = predictor.predict_pi(X_te)
        true_group = data.true_group_test()

        mean_pi_safe = pi[true_group == 0].mean()
        mean_pi_risky = pi[true_group == 1].mean()
        # Risky group should have higher predicted pi on average
        # (not guaranteed for an untrained model, but with 20 epochs should hold)
        assert mean_pi_risky >= mean_pi_safe - 0.1  # lenient tolerance


class TestDiagnosticsIntegration:
    def test_summary_table_runs(self, trained_result):
        _, predictor, _, _, X_te, y_te, exp_te = trained_result
        diag = MixtureDiagnostics(predictor)
        summary = diag.summary_table(X_te, y_te, exp_te)
        assert "gini" in summary
        assert "mean_pi" in summary
        assert "ordering_violated_count" in summary
        assert summary["ordering_violated_count"] == 0

    def test_summary_table_n_policies(self, trained_result):
        _, predictor, data, _, X_te, y_te, exp_te = trained_result
        diag = MixtureDiagnostics(predictor)
        summary = diag.summary_table(X_te, y_te, exp_te)
        assert summary["n_policies"] == len(y_te)

    def test_gini_in_valid_range(self, trained_result):
        _, predictor, _, _, X_te, y_te, exp_te = trained_result
        diag = MixtureDiagnostics(predictor)
        summary = diag.summary_table(X_te, y_te, exp_te)
        assert -1.0 <= summary["gini"] <= 1.0


class TestConstraintRobustness:
    """Verify ordering constraint across varied model sizes and initialisations."""

    @pytest.mark.parametrize("hidden_sizes", [
        [4],
        [8, 4],
        [32, 16, 8],
        [64, 64, 32, 32, 16],  # paper default
    ])
    def test_ordering_holds_for_various_architectures(self, hidden_sizes):
        import torch
        model = PoissonMixtureNN(n_features=8, hidden_sizes=hidden_sizes)
        model.eval()
        x = torch.randn(200, 8)
        _, lam0, lam1 = model(x)
        violations = (lam1 <= lam0).sum().item()
        assert violations == 0

    def test_ordering_holds_with_zero_input(self):
        import torch
        model = PoissonMixtureNN(n_features=8, hidden_sizes=[16, 8])
        model.eval()
        x = torch.zeros(50, 8)
        _, lam0, lam1 = model(x)
        assert (lam1 > lam0).all()

    def test_ordering_holds_with_extreme_input(self):
        import torch
        model = PoissonMixtureNN(n_features=8, hidden_sizes=[16, 8])
        model.eval()
        x = torch.randn(50, 8) * 100  # very large inputs
        _, lam0, lam1 = model(x)
        assert (lam1 > lam0).all()
