"""Model comparison module.

Benchmarks the Poisson mixture DNN against simpler baselines:
- Poisson GLM (log link, exposure offset)
- ZIP GLM (standard zero-inflated Poisson via statsmodels)
- Poisson DNN (same architecture, no mixture)

Returns a comparison DataFrame with NLL, Gini, and calibration metrics so
the improvement from the mixture formulation is quantifiable.

Design note: we depend on statsmodels for GLM baselines. This is an optional
dependency (``pip install insurance-poisson-mixture-nn[comparison]``). If
statsmodels is not installed, GLM comparisons are skipped with a warning.
"""

from __future__ import annotations

import warnings
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

__all__ = ["ModelComparison", "ComparisonResult", "gini_coefficient"]


def gini_coefficient(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Compute the Gini coefficient (normalised).

    The Gini coefficient measures the concentration of predicted risk. Higher
    is better — a perfect model separates zero-claimers from claimers perfectly.

    Args:
        y_true: Actual claim counts, shape (n,).
        y_pred: Predicted expected frequencies, shape (n,).

    Returns:
        Gini coefficient in [-1, 1]. Typically 0.1–0.5 for insurance models.
    """
    # Sort by predicted frequency ascending
    sort_idx = np.argsort(y_pred)
    y_sorted = y_true[sort_idx]
    n = len(y_sorted)
    cum_claims = np.cumsum(y_sorted)
    total_claims = cum_claims[-1]

    if total_claims == 0:
        return 0.0

    lorenz = cum_claims / total_claims
    # Area under Lorenz curve via trapezoidal rule
    area_lorenz = np.trapz(lorenz, dx=1.0 / n)
    # Perfect equality area = 0.5
    gini = 1.0 - 2.0 * area_lorenz
    return float(gini)


def _poisson_nll(y: np.ndarray, pred: np.ndarray) -> float:
    """Mean Poisson NLL for a vector of predictions."""
    pred_clamped = np.clip(pred, 1e-10, None)
    nll = pred_clamped - y * np.log(pred_clamped)  # Poisson NLL (up to constant)
    return float(np.mean(nll))


@dataclass
class ComparisonResult:
    """Results for a single model in the comparison.

    Attributes:
        model_name: Human-readable model name.
        test_nll: Mean negative log-likelihood on the test set.
        gini: Gini coefficient on the test set.
        n_params: Number of trainable parameters (where applicable).
        notes: Additional notes about the model.
    """

    model_name: str
    test_nll: float
    gini: float
    n_params: Optional[int] = None
    notes: str = ""


class ModelComparison:
    """Compare PM-DNN against standard insurance frequency baselines.

    Fits and evaluates:
    1. Poisson GLM (statsmodels, log link)
    2. ZIP GLM (statsmodels ZeroInflatedPoisson)
    3. Poisson DNN (same architecture as PM-DNN trunk but single Poisson head)
    4. PM-DNN (the full mixture model)

    The Poisson DNN baseline is built internally using PyTorch to ensure the
    comparison is fair: the only difference from PM-DNN is the absence of the
    mixture formulation.

    Args:
        pm_model: A trained PoissonMixtureNN instance.
        random_state: Random seed for reproducibility in baselines.
        max_epochs_dnn: Maximum training epochs for the Poisson DNN baseline.
        verbose: Print progress during fitting.

    Example::

        comp = ModelComparison(model, random_state=42)
        results = comp.compare(X_train, y_train, exp_train, X_test, y_test, exp_test)
        df = comp.results_dataframe()
        print(df.sort_values('test_nll'))
    """

    def __init__(
        self,
        pm_model,  # PoissonMixtureNN — avoid circular import with type string
        random_state: int = 42,
        max_epochs_dnn: int = 100,
        verbose: bool = True,
    ) -> None:
        self.pm_model = pm_model
        self.random_state = random_state
        self.max_epochs_dnn = max_epochs_dnn
        self.verbose = verbose
        self._results: list[ComparisonResult] = []

    def _log(self, msg: str) -> None:
        if self.verbose:
            print(msg)

    def compare(
        self,
        X_train: np.ndarray,
        y_train: np.ndarray,
        exposure_train: np.ndarray,
        X_test: np.ndarray,
        y_test: np.ndarray,
        exposure_test: np.ndarray,
    ) -> list[ComparisonResult]:
        """Fit all baseline models and collect test-set metrics.

        Args:
            X_train: Training features, shape (n_train, p).
            y_train: Training claim counts, shape (n_train,).
            exposure_train: Training exposure, shape (n_train,).
            X_test: Test features, shape (n_test, p).
            y_test: Test claim counts, shape (n_test,).
            exposure_test: Test exposure, shape (n_test,).

        Returns:
            List of ComparisonResult, one per model.
        """
        self._results = []

        # 1. Poisson GLM
        self._log("Fitting Poisson GLM baseline...")
        try:
            result = self._fit_poisson_glm(
                X_train, y_train, exposure_train, X_test, y_test, exposure_test
            )
            self._results.append(result)
        except ImportError:
            warnings.warn(
                "statsmodels not installed; skipping Poisson GLM baseline. "
                "Install with: pip install statsmodels",
                stacklevel=2,
            )

        # 2. ZIP GLM
        self._log("Fitting ZIP GLM baseline...")
        try:
            result = self._fit_zip_glm(
                X_train, y_train, exposure_train, X_test, y_test, exposure_test
            )
            self._results.append(result)
        except ImportError:
            warnings.warn(
                "statsmodels not installed; skipping ZIP GLM baseline.",
                stacklevel=2,
            )
        except Exception as e:
            warnings.warn(f"ZIP GLM fitting failed: {e}", stacklevel=2)

        # 3. Poisson DNN
        self._log("Fitting Poisson DNN baseline...")
        try:
            result = self._fit_poisson_dnn(
                X_train, y_train, exposure_train, X_test, y_test, exposure_test
            )
            self._results.append(result)
        except Exception as e:
            warnings.warn(f"Poisson DNN baseline failed: {e}", stacklevel=2)

        # 4. PM-DNN (already trained)
        self._log("Evaluating PM-DNN...")
        result = self._evaluate_pm_dnn(X_test, y_test, exposure_test)
        self._results.append(result)

        return self._results

    def _fit_poisson_glm(
        self,
        X_train: np.ndarray,
        y_train: np.ndarray,
        exposure_train: np.ndarray,
        X_test: np.ndarray,
        y_test: np.ndarray,
        exposure_test: np.ndarray,
    ) -> ComparisonResult:
        import statsmodels.api as sm

        X_tr_c = sm.add_constant(X_train)
        X_te_c = sm.add_constant(X_test)

        glm = sm.GLM(
            y_train,
            X_tr_c,
            family=sm.families.Poisson(),
            exposure=exposure_train,
        ).fit(disp=0)

        pred = glm.predict(X_te_c, exposure=exposure_test)
        nll = _poisson_nll(y_test, pred)
        gini = gini_coefficient(y_test, pred)

        return ComparisonResult(
            model_name="Poisson GLM",
            test_nll=nll,
            gini=gini,
            n_params=int(X_tr_c.shape[1]),
            notes="statsmodels GLM, log link, exposure offset",
        )

    def _fit_zip_glm(
        self,
        X_train: np.ndarray,
        y_train: np.ndarray,
        exposure_train: np.ndarray,
        X_test: np.ndarray,
        y_test: np.ndarray,
        exposure_test: np.ndarray,
    ) -> ComparisonResult:
        import statsmodels.api as sm
        from statsmodels.discrete.count_model import ZeroInflatedPoisson

        X_tr_c = sm.add_constant(X_train)
        X_te_c = sm.add_constant(X_test)

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            zip_model = ZeroInflatedPoisson(
                y_train,
                X_tr_c,
                exposure=exposure_train,
            ).fit(method="bfgs", maxiter=200, disp=0)

        pred = zip_model.predict(X_te_c, exposure=exposure_test)
        nll = _poisson_nll(y_test, pred)
        gini = gini_coefficient(y_test, pred)

        return ComparisonResult(
            model_name="ZIP GLM",
            test_nll=nll,
            gini=gini,
            n_params=int(2 * X_tr_c.shape[1]),
            notes="statsmodels ZeroInflatedPoisson, exposure offset",
        )

    def _fit_poisson_dnn(
        self,
        X_train: np.ndarray,
        y_train: np.ndarray,
        exposure_train: np.ndarray,
        X_test: np.ndarray,
        y_test: np.ndarray,
        exposure_test: np.ndarray,
    ) -> ComparisonResult:
        """Fit a simple Poisson DNN baseline (no mixture)."""
        import torch
        import torch.nn as nn
        from torch.utils.data import DataLoader

        from insurance_poisson_mixture_nn.model import SharedTrunk
        from insurance_poisson_mixture_nn.trainer import PoissonMixtureDataset

        n_features = X_train.shape[1]
        hidden = self.pm_model.hidden_sizes

        # Build a simple Poisson network with the same trunk
        trunk = SharedTrunk(n_features, hidden, activation=self.pm_model.activation)
        head = nn.Linear(trunk.out_features, 1)
        poisson_dnn = nn.Sequential(trunk.mlp, head)

        device = torch.device("cpu")
        poisson_dnn = poisson_dnn.to(device)
        optimiser = torch.optim.Adam(poisson_dnn.parameters(), lr=1e-3, weight_decay=1e-4)

        train_ds = PoissonMixtureDataset(X_train, y_train, exposure_train)
        train_loader = DataLoader(train_ds, batch_size=512, shuffle=True)

        for _ in range(self.max_epochs_dnn):
            poisson_dnn.train()
            for X_b, y_b, exp_b in train_loader:
                X_b, y_b, exp_b = X_b.to(device), y_b.to(device), exp_b.to(device)
                optimiser.zero_grad()
                raw = poisson_dnn(X_b).squeeze(-1)
                rate = nn.functional.softplus(raw) * exp_b
                # Poisson NLL
                loss = (rate - y_b * torch.log(rate.clamp(1e-10))).mean()
                loss.backward()
                optimiser.step()

        # Evaluate
        poisson_dnn.eval()
        with torch.no_grad():
            X_t = torch.tensor(X_test, dtype=torch.float32)
            exp_t = torch.tensor(exposure_test, dtype=torch.float32)
            raw = poisson_dnn(X_t).squeeze(-1)
            pred = (nn.functional.softplus(raw) * exp_t).numpy()

        nll = _poisson_nll(y_test, pred)
        gini = gini_coefficient(y_test, pred)
        n_params = sum(p.numel() for p in poisson_dnn.parameters())

        return ComparisonResult(
            model_name="Poisson DNN",
            test_nll=nll,
            gini=gini,
            n_params=n_params,
            notes=f"Same trunk as PM-DNN ({hidden}), single Poisson head",
        )

    def _evaluate_pm_dnn(
        self,
        X_test: np.ndarray,
        y_test: np.ndarray,
        exposure_test: np.ndarray,
    ) -> ComparisonResult:
        from insurance_poisson_mixture_nn.loss import PoissonMixtureNLL
        from insurance_poisson_mixture_nn.predictor import PoissonMixturePredictor

        import torch

        predictor = PoissonMixturePredictor(self.pm_model, device="cpu")
        comps = predictor.predict_components(X_test, exposure_test)
        pi = torch.tensor(comps["pi"])
        lam0 = torch.tensor(comps["lambda_0"])
        lam1 = torch.tensor(comps["lambda_1"])
        y_t = torch.tensor(y_test)
        exp_t = torch.tensor(exposure_test)

        loss_fn = PoissonMixtureNLL(reduction="mean")
        nll = loss_fn(pi, lam0, lam1, y_t, exp_t).item()
        gini = gini_coefficient(y_test, comps["expected"])
        n_params = sum(p.numel() for p in self.pm_model.parameters())

        return ComparisonResult(
            model_name="PM-DNN",
            test_nll=nll,
            gini=gini,
            n_params=n_params,
            notes="Two-component Poisson mixture, constrained lambda_1 > lambda_0",
        )

    def results_dataframe(self):
        """Return results as a Polars DataFrame.

        Requires polars to be installed (it is a core dependency).

        Returns:
            Polars DataFrame sorted by test_nll ascending.
        """
        import polars as pl

        rows = [
            {
                "model": r.model_name,
                "test_nll": round(r.test_nll, 6),
                "gini": round(r.gini, 4),
                "n_params": r.n_params,
                "notes": r.notes,
            }
            for r in self._results
        ]
        df = pl.DataFrame(rows)
        return df.sort("test_nll")
