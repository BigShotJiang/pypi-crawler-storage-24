"""Training loop for the Poisson mixture neural network.

The trainer handles:
- Mini-batch data loading with exposure columns
- Train/validation split (or accepts pre-split data)
- Early stopping on validation NLL
- ReduceLROnPlateau learning rate scheduling
- Training history for diagnostics

Design decision: we accept numpy arrays rather than PyTorch tensors at the API
boundary. This is consistent with scikit-learn convention and means callers
do not need to manage device placement. The trainer handles GPU/CPU internally.
"""

from __future__ import annotations

import copy
from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import torch
import torch.nn as nn
from torch import Tensor
from torch.utils.data import DataLoader, Dataset

from insurance_poisson_mixture_nn.loss import PoissonMixtureNLL
from insurance_poisson_mixture_nn.model import PoissonMixtureNN

__all__ = ["PoissonMixtureDataset", "TrainingHistory", "PoissonMixtureTrainer"]


class PoissonMixtureDataset(Dataset):
    """PyTorch Dataset for Poisson mixture training data.

    Stores features, claim counts, and exposure in a single object for
    efficient mini-batch sampling.

    Args:
        X: Feature matrix, shape (n, p). Float32 on creation.
        y: Claim counts, shape (n,). Must be non-negative integers.
        exposure: Policy exposure in years, shape (n,). Must be positive.
    """

    def __init__(
        self,
        X: np.ndarray,
        y: np.ndarray,
        exposure: np.ndarray,
    ) -> None:
        self.X = torch.tensor(X, dtype=torch.float32)
        self.y = torch.tensor(y, dtype=torch.float32)
        self.exposure = torch.tensor(exposure, dtype=torch.float32)

        if self.X.shape[0] != self.y.shape[0]:
            raise ValueError(
                f"X has {self.X.shape[0]} rows but y has {self.y.shape[0]} rows"
            )
        if self.X.shape[0] != self.exposure.shape[0]:
            raise ValueError(
                f"X has {self.X.shape[0]} rows but exposure has {self.exposure.shape[0]} rows"
            )

    def __len__(self) -> int:
        return self.X.shape[0]

    def __getitem__(self, idx: int) -> tuple[Tensor, Tensor, Tensor]:
        return self.X[idx], self.y[idx], self.exposure[idx]


@dataclass
class TrainingHistory:
    """Record of training and validation NLL by epoch.

    Attributes:
        train_nll: NLL on training data at each epoch.
        val_nll: NLL on validation data at each epoch.
        best_val_nll: Lowest validation NLL seen.
        best_epoch: Epoch at which best_val_nll was achieved.
        stopped_early: Whether training was halted by early stopping.
        lr_history: Learning rate at the end of each epoch.
    """

    train_nll: list[float] = field(default_factory=list)
    val_nll: list[float] = field(default_factory=list)
    lr_history: list[float] = field(default_factory=list)
    best_val_nll: float = float("inf")
    best_epoch: int = 0
    stopped_early: bool = False

    def n_epochs(self) -> int:
        """Number of training epochs completed."""
        return len(self.train_nll)

    def improvement(self) -> float:
        """Absolute NLL improvement from epoch 0 to best epoch."""
        if not self.val_nll:
            return 0.0
        return self.val_nll[0] - self.best_val_nll


class PoissonMixtureTrainer:
    """Trainer for PoissonMixtureNN with early stopping.

    Implements mini-batch gradient descent with:
    - Adam optimiser (paper default)
    - ReduceLROnPlateau learning rate scheduling
    - Early stopping based on validation NLL
    - Best-model restoration (returns weights from best epoch)

    Args:
        model: PoissonMixtureNN instance to train.
        lr: Initial learning rate for Adam. 1e-3 is a reasonable starting point.
        batch_size: Mini-batch size. 512 works well for typical insurance
            portfolios (100k–1M rows).
        max_epochs: Maximum number of training epochs.
        patience: Number of epochs to wait without validation improvement
            before stopping early.
        lr_patience: Number of epochs before reducing learning rate. Set to
            ``patience // 2`` if None.
        lr_factor: Factor by which to reduce LR on plateau.
        l2_penalty: L2 regularisation strength in the loss. 0.0 by default;
            use weight_decay on the optimiser instead for most use cases.
        device: PyTorch device string. Autodetects CUDA if available.
        weight_decay: Adam weight_decay parameter. Acts as L2 on all weights.
        num_workers: DataLoader worker processes. 0 on CPU is usually fastest
            for tabular data.

    Example::

        model = PoissonMixtureNN(n_features=10)
        trainer = PoissonMixtureTrainer(model, max_epochs=100, patience=10)
        history = trainer.fit(X_tr, y_tr, exp_tr, X_val, y_val, exp_val)
        print(f"Best val NLL: {history.best_val_nll:.4f} at epoch {history.best_epoch}")
    """

    def __init__(
        self,
        model: PoissonMixtureNN,
        lr: float = 1e-3,
        batch_size: int = 512,
        max_epochs: int = 200,
        patience: int = 15,
        lr_patience: Optional[int] = None,
        lr_factor: float = 0.5,
        l2_penalty: float = 0.0,
        device: Optional[str] = None,
        weight_decay: float = 1e-4,
        num_workers: int = 0,
    ) -> None:
        self.model = model
        self.lr = lr
        self.batch_size = batch_size
        self.max_epochs = max_epochs
        self.patience = patience
        self.lr_patience = lr_patience if lr_patience is not None else max(1, patience // 2)
        self.lr_factor = lr_factor
        self.l2_penalty = l2_penalty
        self.weight_decay = weight_decay
        self.num_workers = num_workers

        if device is None:
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self.device = torch.device(device)

        self.loss_fn = PoissonMixtureNLL(reduction="mean", l2_penalty=l2_penalty)

    def fit(
        self,
        X_train: np.ndarray,
        y_train: np.ndarray,
        exposure_train: np.ndarray,
        X_val: np.ndarray,
        y_val: np.ndarray,
        exposure_val: np.ndarray,
    ) -> TrainingHistory:
        """Train the model.

        Args:
            X_train: Training features, shape (n_train, p).
            y_train: Training claim counts, shape (n_train,).
            exposure_train: Training exposures, shape (n_train,).
            X_val: Validation features, shape (n_val, p).
            y_val: Validation claim counts, shape (n_val,).
            exposure_val: Validation exposures, shape (n_val,).

        Returns:
            TrainingHistory containing NLL curves and best epoch information.
        """
        model = self.model.to(self.device)
        optimiser = torch.optim.Adam(
            model.parameters(), lr=self.lr, weight_decay=self.weight_decay
        )
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimiser,
            mode="min",
            factor=self.lr_factor,
            patience=self.lr_patience,
        )

        train_ds = PoissonMixtureDataset(X_train, y_train, exposure_train)
        val_ds = PoissonMixtureDataset(X_val, y_val, exposure_val)

        train_loader = DataLoader(
            train_ds,
            batch_size=self.batch_size,
            shuffle=True,
            num_workers=self.num_workers,
        )
        val_loader = DataLoader(
            val_ds,
            batch_size=self.batch_size * 4,  # larger batches OK for eval
            shuffle=False,
            num_workers=self.num_workers,
        )

        history = TrainingHistory()
        best_weights: Optional[dict] = None
        no_improve = 0

        for epoch in range(self.max_epochs):
            # --- Training pass ---
            model.train()
            train_nll_accum = 0.0
            n_train = 0
            for X_b, y_b, exp_b in train_loader:
                X_b = X_b.to(self.device)
                y_b = y_b.to(self.device)
                exp_b = exp_b.to(self.device)

                optimiser.zero_grad()
                pi, lam0, lam1 = model(X_b)
                loss = self.loss_fn(pi, lam0, lam1, y_b, exp_b)
                loss.backward()
                # Gradient clipping prevents instability in early epochs
                nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                optimiser.step()

                train_nll_accum += loss.item() * X_b.shape[0]
                n_train += X_b.shape[0]

            train_nll = train_nll_accum / n_train

            # --- Validation pass ---
            val_nll = self._evaluate(model, val_loader)
            scheduler.step(val_nll)

            current_lr = optimiser.param_groups[0]["lr"]
            history.train_nll.append(train_nll)
            history.val_nll.append(val_nll)
            history.lr_history.append(current_lr)

            # Early stopping
            if val_nll < history.best_val_nll:
                history.best_val_nll = val_nll
                history.best_epoch = epoch
                best_weights = copy.deepcopy(model.state_dict())
                no_improve = 0
            else:
                no_improve += 1
                if no_improve >= self.patience:
                    history.stopped_early = True
                    break

        # Restore best weights
        if best_weights is not None:
            model.load_state_dict(best_weights)

        return history

    def _evaluate(self, model: PoissonMixtureNN, loader: DataLoader) -> float:
        """Compute mean NLL on a DataLoader without updating parameters."""
        model.eval()
        total_nll = 0.0
        n_total = 0
        with torch.no_grad():
            for X_b, y_b, exp_b in loader:
                X_b = X_b.to(self.device)
                y_b = y_b.to(self.device)
                exp_b = exp_b.to(self.device)
                pi, lam0, lam1 = model(X_b)
                loss = self.loss_fn(pi, lam0, lam1, y_b, exp_b)
                total_nll += loss.item() * X_b.shape[0]
                n_total += X_b.shape[0]
        return total_nll / n_total
