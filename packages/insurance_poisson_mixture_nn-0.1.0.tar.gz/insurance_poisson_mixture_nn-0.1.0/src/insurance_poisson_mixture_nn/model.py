"""Neural Poisson mixture model.

The model implements the two-component Poisson mixture architecture from the
PM-DNN paper (NAAJ 2025). A shared trunk processes input features, then three
separate output heads produce:

- pi(x): posterior probability that policyholder i is in the 'risky' group
- lambda_0(x): claim rate for the safe / structural-zero group
- lambda_1(x): claim rate for the risky / stochastic group

The key constraint is lambda_1 > lambda_0, enforced via reparameterisation:

    lambda_0 = softplus(a)
    lambda_1 = lambda_0 + softplus(b)

This is identical in spirit to constrained Gaussian means in mixture models and
avoids the label-switching problem that EM suffers from with neural sub-networks.
"""

from __future__ import annotations

import torch
import torch.nn as nn
from torch import Tensor

__all__ = ["PoissonMixtureNN", "SharedTrunk", "PoissonHead", "MixtureProbHead"]


def _build_mlp(
    in_features: int,
    hidden_sizes: list[int],
    activation: str,
    batch_norm: bool,
    dropout: float,
) -> nn.Sequential:
    """Build a multi-layer perceptron block.

    Args:
        in_features: Number of input features.
        hidden_sizes: List of hidden layer widths.
        activation: Activation function name. One of 'elu', 'relu', 'selu'.
        batch_norm: Whether to include BatchNorm1d after each linear layer.
        dropout: Dropout probability (0 disables dropout).

    Returns:
        Sequential module implementing the MLP trunk.
    """
    activation_map = {
        "elu": nn.ELU,
        "relu": nn.ReLU,
        "selu": nn.SELU,
        "gelu": nn.GELU,
    }
    if activation not in activation_map:
        raise ValueError(
            f"Unknown activation '{activation}'. Choose from: {list(activation_map)}"
        )
    act_cls = activation_map[activation]

    layers: list[nn.Module] = []
    current = in_features
    for width in hidden_sizes:
        layers.append(nn.Linear(current, width))
        if batch_norm:
            layers.append(nn.BatchNorm1d(width))
        layers.append(act_cls())
        if dropout > 0.0:
            layers.append(nn.Dropout(p=dropout))
        current = width
    return nn.Sequential(*layers), current


class SharedTrunk(nn.Module):
    """Shared representation network.

    Processes input covariates into a shared latent representation that all
    three output heads read from. Using a shared trunk rather than three
    independent networks reduces parameter count and encourages the heads to
    learn complementary representations.

    Args:
        n_features: Number of input features.
        hidden_sizes: Width of each hidden layer.
        activation: Activation function. ELU is recommended (paper default).
        batch_norm: Whether to include BatchNorm after each linear layer.
        dropout: Dropout probability applied after each activation.
    """

    def __init__(
        self,
        n_features: int,
        hidden_sizes: list[int],
        activation: str = "elu",
        batch_norm: bool = True,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        mlp, out_features = _build_mlp(
            n_features, hidden_sizes, activation, batch_norm, dropout
        )
        self.mlp = mlp
        self.out_features = out_features

    def forward(self, x: Tensor) -> Tensor:
        """Forward pass through the trunk.

        Args:
            x: Input tensor of shape (batch, n_features).

        Returns:
            Latent representation of shape (batch, out_features).
        """
        return self.mlp(x)


class MixtureProbHead(nn.Module):
    """Output head for the mixture probability pi(x).

    Produces the posterior probability that a given policyholder belongs to the
    risky (at-risk) group. Output is in (0, 1) via sigmoid.

    Args:
        in_features: Width of the trunk output.
    """

    def __init__(self, in_features: int) -> None:
        super().__init__()
        self.linear = nn.Linear(in_features, 1)

    def forward(self, z: Tensor) -> Tensor:
        """Compute pi(x).

        Args:
            z: Trunk output of shape (batch, in_features).

        Returns:
            Mixture probabilities of shape (batch,) in (0, 1).
        """
        return torch.sigmoid(self.linear(z)).squeeze(-1)


class PoissonHead(nn.Module):
    """Output head for a single Poisson rate parameter.

    Outputs a positive rate via softplus. No upper bound is applied here;
    the ordering constraint (lambda_0 < lambda_1) is handled in
    PoissonMixtureNN.forward().

    Args:
        in_features: Width of the trunk output.
    """

    def __init__(self, in_features: int) -> None:
        super().__init__()
        self.linear = nn.Linear(in_features, 1)

    def forward(self, z: Tensor) -> Tensor:
        """Compute a raw (unconstrained) Poisson rate.

        Args:
            z: Trunk output of shape (batch, in_features).

        Returns:
            Raw rates of shape (batch,), all positive.
        """
        return nn.functional.softplus(self.linear(z)).squeeze(-1)


class PoissonMixtureNN(nn.Module):
    """Neural Poisson mixture model for zero-inflated insurance claims.

    Implements the two-component Poisson mixture from the PM-DNN paper
    (NAAJ 2025). The model distinguishes:

    - **Structural zeros**: Policyholders in the safe group who will essentially
      never claim (lambda_0 near zero). For example, telematics drivers who
      installed a black box but never actually drive.
    - **Stochastic zeros**: Policyholders in the risky group (lambda_1 > 0)
      who happened not to claim during the observed period.

    The full mixture PMF is:

        P(Y=k | x) = (1 - pi(x)) * Poisson(k; lambda_0(x) * t)
                   +     pi(x)   * Poisson(k; lambda_1(x) * t)

    where t is the exposure in policy years.

    The ordering constraint lambda_1 > lambda_0 is enforced via
    reparameterisation::

        lambda_0 = softplus(raw_0)
        lambda_1 = lambda_0 + softplus(raw_gap)

    This avoids the label-switching problem present when both rates are
    unconstrained.

    Args:
        n_features: Number of input covariates.
        hidden_sizes: Width of each hidden layer in the shared trunk. The
            paper uses five layers; default mirrors this.
        dropout: Dropout probability. 0.0 disables dropout.
        batch_norm: Whether to apply BatchNorm1d after each linear layer.
        activation: Activation function for hidden layers. ELU is the paper
            default and recommended.
        constrain_separation: If True (default), enforce lambda_1 > lambda_0
            via reparameterisation. Set to False only for ablation studies.

    Example::

        model = PoissonMixtureNN(n_features=12)
        x = torch.randn(64, 12)
        pi, lam0, lam1 = model(x)
        # pi: (64,), lam0: (64,), lam1: (64,)
        assert (lam1 > lam0).all()
    """

    def __init__(
        self,
        n_features: int,
        hidden_sizes: list[int] | None = None,
        dropout: float = 0.1,
        batch_norm: bool = True,
        activation: str = "elu",
        constrain_separation: bool = True,
    ) -> None:
        super().__init__()

        if hidden_sizes is None:
            hidden_sizes = [64, 64, 32, 32, 16]

        self.n_features = n_features
        self.hidden_sizes = list(hidden_sizes)
        self.dropout = dropout
        self.batch_norm = batch_norm
        self.activation = activation
        self.constrain_separation = constrain_separation

        self.trunk = SharedTrunk(
            n_features=n_features,
            hidden_sizes=hidden_sizes,
            activation=activation,
            batch_norm=batch_norm,
            dropout=dropout,
        )
        trunk_out = self.trunk.out_features

        # Three output heads
        self.pi_head = MixtureProbHead(trunk_out)
        self.lambda0_head = PoissonHead(trunk_out)
        # If constrain_separation, this head outputs the GAP (lambda1 - lambda0)
        # If not constrained, outputs lambda1 directly.
        self.lambda1_head = PoissonHead(trunk_out)

    def forward(self, x: Tensor) -> tuple[Tensor, Tensor, Tensor]:
        """Forward pass returning all three mixture components.

        Args:
            x: Input feature tensor of shape (batch, n_features). Should be
               pre-processed (normalised, encoded categoricals, etc.).

        Returns:
            Tuple of (pi, lambda_0, lambda_1), each of shape (batch,):

            - **pi**: Posterior probability of belonging to the risky group,
              in (0, 1). Use 1 - pi as the structural zero score.
            - **lambda_0**: Poisson rate for the safe group, > 0. Typically
              small; approaches zero for near-structural-zero sub-populations.
            - **lambda_1**: Poisson rate for the risky group. Always greater
              than lambda_0 when constrain_separation=True.
        """
        z = self.trunk(x)
        pi = self.pi_head(z)
        lambda_0 = self.lambda0_head(z)

        if self.constrain_separation:
            gap = self.lambda1_head(z)
            lambda_1 = lambda_0 + gap
        else:
            lambda_1 = self.lambda1_head(z)

        return pi, lambda_0, lambda_1

    def expected_frequency(self, x: Tensor, exposure: Tensor | None = None) -> Tensor:
        """Compute the expected claim frequency (mixture mean).

        This is the primary pricing output:

            E[Y | x] = pi(x) * lambda_1(x) * t + (1 - pi(x)) * lambda_0(x) * t

        Args:
            x: Feature tensor of shape (batch, n_features).
            exposure: Exposure in policy years, shape (batch,). Defaults to 1.0.

        Returns:
            Expected claim counts of shape (batch,).
        """
        pi, lambda_0, lambda_1 = self.forward(x)
        if exposure is None:
            t = torch.ones_like(pi)
        else:
            t = exposure
        return (pi * lambda_1 + (1.0 - pi) * lambda_0) * t

    def structural_zero_score(self, x: Tensor) -> Tensor:
        """Compute the structural zero score (1 - pi(x)).

        A high score indicates the policyholder is likely in the safe/structural-zero
        group. This is directly usable as a pricing signal or for NCD ladder
        adjustment.

        Args:
            x: Feature tensor of shape (batch, n_features).

        Returns:
            Structural zero scores in (0, 1), shape (batch,).
        """
        pi, _, _ = self.forward(x)
        return 1.0 - pi
