"""Synthetic data generation for testing and demonstration.

Generates insurance-style claim data with known ground-truth mixture structure.
The covariates are inspired by UK telematics motor insurance: mileage, harsh
braking events, night-time driving fraction, driver age, and vehicle value.

The structural assignment (which policies are 'safe' vs 'risky') is a logistic
function of mileage and braking behaviour, matching intuition: low-mileage
drivers with smooth behaviour are more likely structural zeros.

Usage::

    data = SyntheticMixtureData(n_policies=10_000, seed=42)
    X_train, y_train, exp_train = data.training_split()
    X_val, y_val, exp_val = data.validation_split()
    X_test, y_test, exp_test = data.test_split()

    # Access ground truth for evaluation
    true_pi = data.true_pi          # shape (n,)
    true_lambda_0 = data.true_lambda_0
    true_lambda_1 = data.true_lambda_1
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np

__all__ = ["SyntheticMixtureData", "generate_telematics_features"]

# Feature column names for reference
FEATURE_NAMES = [
    "annual_mileage_log",    # log annual miles (telematics recorded)
    "harsh_braking_rate",    # harsh braking events per 1000 miles
    "night_drive_fraction",  # fraction of miles driven between 22:00 and 06:00
    "driver_age_scaled",     # (age - 35) / 15
    "vehicle_value_log",     # log vehicle value in GBP
    "motorway_fraction",     # fraction of miles on motorways
    "speed_score",           # composite speeding behaviour score [0,1]
    "claims_last_year",      # prior year claim indicator (0 or 1)
]


def generate_telematics_features(
    n: int,
    seed: Optional[int] = None,
) -> np.ndarray:
    """Generate a synthetic telematics feature matrix.

    Produces 8 features modelled on UK telematics motor insurance data:
    mileage, braking behaviour, night driving, driver demographics, and
    vehicle characteristics.

    Args:
        n: Number of policies.
        seed: Random seed for reproducibility.

    Returns:
        Feature matrix of shape (n, 8). Column names are in FEATURE_NAMES.
    """
    rng = np.random.default_rng(seed)

    # Annual mileage: log-normal, UK typical range 3000-20000 miles/year
    mileage = rng.lognormal(mean=8.5, sigma=0.6, size=n)  # exp(8.5) ≈ 5000 miles
    annual_mileage_log = np.log(mileage + 1.0)

    # Harsh braking rate: gamma-distributed, heavier in young drivers
    harsh_braking_rate = rng.gamma(shape=1.5, scale=2.0, size=n).clip(0, 20)

    # Night-time driving fraction: beta distribution
    night_drive_fraction = rng.beta(a=1.5, b=6.0, size=n)

    # Driver age: skewed towards younger drivers (telematics market)
    driver_age = rng.gamma(shape=4.0, scale=5.0, size=n).clip(18, 80) + 17
    driver_age_scaled = (driver_age - 35.0) / 15.0

    # Vehicle value: log-normal
    vehicle_value = rng.lognormal(mean=9.0, sigma=0.7, size=n)  # ~£8000 typical
    vehicle_value_log = np.log(vehicle_value)

    # Motorway fraction: beta
    motorway_fraction = rng.beta(a=2.0, b=3.0, size=n)

    # Speed score: beta, correlated weakly with harsh braking
    speed_score = rng.beta(a=1.5, b=4.0, size=n)
    speed_score = (speed_score + 0.2 * harsh_braking_rate / 20.0).clip(0, 1)

    # Prior year claims: Bernoulli with low rate
    claims_last_year = rng.binomial(1, p=0.08, size=n).astype(np.float64)

    X = np.column_stack([
        annual_mileage_log,
        harsh_braking_rate,
        night_drive_fraction,
        driver_age_scaled,
        vehicle_value_log,
        motorway_fraction,
        speed_score,
        claims_last_year,
    ])
    return X.astype(np.float32)


@dataclass
class SyntheticMixtureData:
    """Synthetic Poisson mixture dataset with known ground truth.

    Generates data from the two-component Poisson mixture:

        Y_i | group_i = 0 ~ Poisson(lambda_0_i * t_i)
        Y_i | group_i = 1 ~ Poisson(lambda_1_i * t_i)
        group_i ~ Bernoulli(pi_i)

    where pi_i, lambda_0_i, lambda_1_i are functions of covariates.

    Args:
        n_policies: Total number of synthetic policies.
        train_frac: Fraction of data for training.
        val_frac: Fraction of data for validation.
        seed: Random seed.
        lambda_0_max: Upper bound on the safe group rate. Kept small to
            simulate structural zeros (true lambda_0 drawn from Uniform(0, max)).
        lambda_1_min: Minimum risky group rate. Ensures the groups are separated.
        lambda_1_max: Maximum risky group rate.

    Attributes:
        X: Full feature matrix, shape (n_policies, 8).
        y: Observed claim counts, shape (n_policies,).
        exposure: Policy years, shape (n_policies,).
        true_pi: Ground-truth at-risk probability, shape (n_policies,).
        true_lambda_0: Ground-truth safe group rate, shape (n_policies,).
        true_lambda_1: Ground-truth risky group rate, shape (n_policies,).
        true_group: Ground-truth group assignments (0=safe, 1=risky), shape (n_policies,).
    """

    n_policies: int = 10_000
    train_frac: float = 0.7
    val_frac: float = 0.15
    seed: Optional[int] = 42
    lambda_0_max: float = 0.02
    lambda_1_min: float = 0.05
    lambda_1_max: float = 0.8

    def __post_init__(self) -> None:
        self._generate()

    def _generate(self) -> None:
        """Generate all synthetic data."""
        rng = np.random.default_rng(self.seed)
        n = self.n_policies

        # Generate features
        self.X = generate_telematics_features(n, seed=self.seed)

        # True pi: logistic function of mileage (neg), braking (pos), night (pos)
        # Low-mileage, low-braking drivers are more likely structural zeros (pi low)
        annual_mileage_log = self.X[:, 0]
        harsh_braking = self.X[:, 1]
        night_drive = self.X[:, 2]
        speed_score = self.X[:, 6]

        logit_pi = (
            -2.0                             # baseline: most policies are risky
            + 1.5 * (annual_mileage_log - annual_mileage_log.mean())  # high mileage → risky
            + 0.3 * harsh_braking            # harsh braking → risky
            + 1.2 * night_drive              # night driving → risky
            + 0.8 * speed_score              # speeding → risky
        )
        self.true_pi = 1.0 / (1.0 + np.exp(-logit_pi))

        # True lambda_0: small, varies slightly with features
        self.true_lambda_0 = (
            0.001 + (self.lambda_0_max - 0.001) * np.random.default_rng(self.seed + 1)
            .uniform(size=n)
        ) * np.float32(1.0)

        # True lambda_1: larger, function of risk features
        base_rate = (self.lambda_1_min + self.lambda_1_max) / 2.0
        log_rate_1 = (
            np.log(base_rate)
            + 0.4 * (annual_mileage_log - annual_mileage_log.mean())
            + 0.05 * harsh_braking
            + 0.3 * night_drive
        )
        self.true_lambda_1 = np.exp(log_rate_1).clip(self.lambda_1_min, self.lambda_1_max)

        # Exposure: uniform [0.5, 1.0] policy years (mid-term policies)
        self.exposure = rng.uniform(0.5, 1.0, size=n).astype(np.float32)

        # Group assignment
        self.true_group = rng.binomial(1, p=self.true_pi).astype(np.int32)

        # Claim counts: Poisson draws from the appropriate group rate
        rates = np.where(
            self.true_group == 0,
            self.true_lambda_0 * self.exposure,
            self.true_lambda_1 * self.exposure,
        )
        self.y = rng.poisson(lam=rates).astype(np.float32)

        # Train/val/test split indices
        indices = rng.permutation(n)
        n_train = int(n * self.train_frac)
        n_val = int(n * self.val_frac)

        self._train_idx = indices[:n_train]
        self._val_idx = indices[n_train : n_train + n_val]
        self._test_idx = indices[n_train + n_val :]

    def _split(
        self, idx: np.ndarray
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        return self.X[idx], self.y[idx], self.exposure[idx]

    def training_split(self) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Return (X, y, exposure) for the training set."""
        return self._split(self._train_idx)

    def validation_split(self) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Return (X, y, exposure) for the validation set."""
        return self._split(self._val_idx)

    def test_split(self) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Return (X, y, exposure) for the test set."""
        return self._split(self._test_idx)

    def true_pi_test(self) -> np.ndarray:
        """Ground-truth pi values for the test set."""
        return self.true_pi[self._test_idx]

    def true_group_test(self) -> np.ndarray:
        """Ground-truth group labels (0=safe, 1=risky) for the test set."""
        return self.true_group[self._test_idx]

    def structural_zero_fraction(self) -> float:
        """Fraction of policies that are true structural zeros (group=0)."""
        return float(np.mean(self.true_group == 0))

    def summary(self) -> dict:
        """Return a summary of the synthetic dataset."""
        return {
            "n_policies": self.n_policies,
            "n_train": len(self._train_idx),
            "n_val": len(self._val_idx),
            "n_test": len(self._test_idx),
            "structural_zero_fraction": self.structural_zero_fraction(),
            "mean_claims": float(self.y.mean()),
            "zero_claim_fraction": float(np.mean(self.y == 0)),
            "mean_exposure": float(self.exposure.mean()),
            "mean_true_pi": float(self.true_pi.mean()),
            "mean_true_lambda_0": float(self.true_lambda_0.mean()),
            "mean_true_lambda_1": float(self.true_lambda_1.mean()),
        }
