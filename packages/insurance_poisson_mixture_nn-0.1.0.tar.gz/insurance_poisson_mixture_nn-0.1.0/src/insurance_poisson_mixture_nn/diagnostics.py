"""Diagnostic plots and tables for Poisson mixture model evaluation.

Provides three main diagnostics:

1. **Component separation plot**: Histograms of lambda_0 and lambda_1 across
   the portfolio. If the model has learned meaningful separation, these
   distributions should be well-separated.

2. **Pi calibration plot**: Predicted at-risk probability pi vs. observed
   claim rate by decile. Ideally monotone — policies with high pi should
   have higher observed claim frequencies.

3. **Zero decomposition chart**: For zero-claim policies, the split between
   structural-zero attribution (low pi, low lambda_0) and stochastic-zero
   attribution (high pi, Poisson happened to give 0).

All plotting functions return matplotlib Figure objects and do NOT call
plt.show(), so callers control display/saving.
"""

from __future__ import annotations

from typing import Optional, TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    import matplotlib.pyplot as plt

__all__ = ["MixtureDiagnostics"]


class MixtureDiagnostics:
    """Diagnostic tools for a trained PoissonMixturePredictor.

    Args:
        predictor: A fitted PoissonMixturePredictor instance.

    Example::

        diag = MixtureDiagnostics(predictor)
        fig = diag.component_separation(X_test, exposure_test)
        fig.savefig("separation.png", dpi=150, bbox_inches="tight")
    """

    def __init__(self, predictor) -> None:
        self.predictor = predictor

    def component_separation(
        self,
        X: np.ndarray,
        exposure: Optional[np.ndarray] = None,
        bins: int = 50,
        figsize: tuple[int, int] = (10, 4),
    ):
        """Plot distributions of lambda_0 and lambda_1 across the portfolio.

        Good separation means lambda_0 is concentrated near zero and lambda_1
        is well above zero. Overlapping distributions indicate the constraint
        is not doing useful work — both components have converged to similar
        rates, which suggests the data may not have a genuine mixture structure.

        Args:
            X: Feature matrix, shape (n, p).
            exposure: Policy years, shape (n,). Optional.
            bins: Number of histogram bins.
            figsize: Figure size (width, height).

        Returns:
            matplotlib Figure.
        """
        import matplotlib.pyplot as plt

        comps = self.predictor.predict_components(X, exposure)
        lam0 = comps["lambda_0"]
        lam1 = comps["lambda_1"]
        pi = comps["pi"]

        fig, axes = plt.subplots(1, 3, figsize=figsize)

        # Lambda_0 distribution
        ax = axes[0]
        ax.hist(lam0, bins=bins, color="#2196F3", alpha=0.8, edgecolor="none")
        ax.set_xlabel("lambda_0 (safe group rate)")
        ax.set_ylabel("Count")
        ax.set_title("Safe Group Rate")
        ax.axvline(np.median(lam0), color="k", linestyle="--", linewidth=1,
                   label=f"Median: {np.median(lam0):.4f}")
        ax.legend(fontsize=8)

        # Lambda_1 distribution
        ax = axes[1]
        ax.hist(lam1, bins=bins, color="#F44336", alpha=0.8, edgecolor="none")
        ax.set_xlabel("lambda_1 (risky group rate)")
        ax.set_ylabel("Count")
        ax.set_title("Risky Group Rate")
        ax.axvline(np.median(lam1), color="k", linestyle="--", linewidth=1,
                   label=f"Median: {np.median(lam1):.4f}")
        ax.legend(fontsize=8)

        # Pi distribution
        ax = axes[2]
        ax.hist(pi, bins=bins, color="#4CAF50", alpha=0.8, edgecolor="none")
        ax.set_xlabel("pi (at-risk probability)")
        ax.set_ylabel("Count")
        ax.set_title("At-Risk Probability")
        ax.axvline(np.median(pi), color="k", linestyle="--", linewidth=1,
                   label=f"Median: {np.median(pi):.3f}")
        ax.legend(fontsize=8)

        fig.suptitle("Poisson Mixture Component Distributions", fontsize=12, y=1.02)
        fig.tight_layout()
        return fig

    def pi_calibration(
        self,
        X: np.ndarray,
        y: np.ndarray,
        exposure: Optional[np.ndarray] = None,
        n_deciles: int = 10,
        figsize: tuple[int, int] = (7, 5),
    ):
        """Plot predicted at-risk probability vs. observed claim rate by decile.

        Policies are sorted by predicted pi and grouped into deciles. For each
        decile, the mean predicted pi and mean observed claim rate (adjusted for
        exposure) are plotted. A well-calibrated model shows monotone increasing
        observed rate with increasing pi.

        Args:
            X: Feature matrix, shape (n, p).
            y: Observed claim counts, shape (n,).
            exposure: Policy years, shape (n,). Defaults to 1.0.
            n_deciles: Number of groups (10 = deciles, 5 = quintiles).
            figsize: Figure size.

        Returns:
            matplotlib Figure.
        """
        import matplotlib.pyplot as plt

        pi = self.predictor.predict_pi(X)
        if exposure is None:
            t = np.ones(len(y), dtype=np.float32)
        else:
            t = np.asarray(exposure, dtype=np.float32)

        # Observed frequency (claims per unit exposure)
        obs_freq = y / t.clip(1e-6)

        # Sort by pi and split into deciles
        sort_idx = np.argsort(pi)
        pi_sorted = pi[sort_idx]
        freq_sorted = obs_freq[sort_idx]

        decile_edges = np.array_split(np.arange(len(pi)), n_deciles)
        decile_pi = [pi_sorted[g].mean() for g in decile_edges]
        decile_obs = [freq_sorted[g].mean() for g in decile_edges]

        fig, ax = plt.subplots(figsize=figsize)
        ax.scatter(decile_pi, decile_obs, s=80, color="#1565C0", zorder=5)
        ax.plot(decile_pi, decile_obs, color="#1565C0", linewidth=1.5, alpha=0.7)

        # Diagonal reference (perfect calibration proportional)
        ax.set_xlabel(f"Mean predicted pi (at-risk probability)\nby {n_deciles}-ile")
        ax.set_ylabel("Mean observed claim frequency")
        ax.set_title("Pi Calibration by Decile")

        overall_freq = (y / t.clip(1e-6)).mean()
        ax.axhline(overall_freq, color="grey", linestyle=":", linewidth=1,
                   label=f"Portfolio mean: {overall_freq:.4f}")
        ax.legend()
        fig.tight_layout()
        return fig

    def zero_decomposition(
        self,
        X: np.ndarray,
        y: np.ndarray,
        exposure: Optional[np.ndarray] = None,
        figsize: tuple[int, int] = (8, 5),
    ):
        """Plot structural vs. stochastic attribution for zero-claim policies.

        For each zero-claim policy, the model assigns a posterior probability
        of being structural (P(structural | Y=0, x)). This plot shows the
        distribution of that posterior across the zero-claim book and the
        aggregate attribution.

        Args:
            X: Feature matrix for all policies, shape (n, p).
            y: Observed claim counts, shape (n,). We select zero-claim rows.
            exposure: Policy years, shape (n,). Optional.
            figsize: Figure size.

        Returns:
            matplotlib Figure.
        """
        import matplotlib.pyplot as plt

        zero_mask = (np.asarray(y) == 0)
        n_zeros = zero_mask.sum()

        if n_zeros == 0:
            fig, ax = plt.subplots(figsize=figsize)
            ax.text(0.5, 0.5, "No zero-claim policies in sample",
                    ha="center", va="center", transform=ax.transAxes)
            return fig

        X_zero = X[zero_mask]
        exp_zero = None if exposure is None else np.asarray(exposure)[zero_mask]

        decomp = self.predictor.zero_decomposition(X_zero, exp_zero)
        posterior_struct = decomp["posterior_structural"]

        fig, axes = plt.subplots(1, 2, figsize=figsize)

        # Histogram of posterior structural probability
        ax = axes[0]
        ax.hist(posterior_struct, bins=30, color="#FF9800", alpha=0.85, edgecolor="none")
        ax.set_xlabel("P(structural | Y=0, x)")
        ax.set_ylabel("Count")
        ax.set_title(f"Posterior Structural Probability\n(n={n_zeros:,} zero-claim policies)")
        ax.axvline(0.5, color="k", linestyle="--", linewidth=1)
        mean_struct = posterior_struct.mean()
        ax.axvline(mean_struct, color="#E91E63", linestyle="-", linewidth=1.5,
                   label=f"Mean: {mean_struct:.3f}")
        ax.legend(fontsize=9)

        # Pie chart of aggregate attribution
        ax = axes[1]
        n_structural = (posterior_struct > 0.5).sum()
        n_stochastic = n_zeros - n_structural
        ax.pie(
            [n_structural, n_stochastic],
            labels=["Structural\n(pi < 0.5)", "Stochastic\n(pi > 0.5)"],
            colors=["#2196F3", "#F44336"],
            autopct="%1.1f%%",
            startangle=90,
        )
        ax.set_title("Zero-Claim Attribution\n(hard threshold at 0.5)")

        fig.suptitle("Zero-Claim Decomposition: Structural vs. Stochastic", fontsize=11)
        fig.tight_layout()
        return fig

    def training_curves(
        self,
        history,  # TrainingHistory
        figsize: tuple[int, int] = (8, 4),
    ):
        """Plot training and validation NLL curves.

        Also shows the learning rate schedule on a secondary axis.

        Args:
            history: TrainingHistory object returned by PoissonMixtureTrainer.fit().
            figsize: Figure size.

        Returns:
            matplotlib Figure.
        """
        import matplotlib.pyplot as plt

        epochs = list(range(len(history.train_nll)))
        fig, ax1 = plt.subplots(figsize=figsize)

        ax1.plot(epochs, history.train_nll, label="Train NLL", color="#1565C0", linewidth=1.5)
        ax1.plot(epochs, history.val_nll, label="Val NLL", color="#F44336", linewidth=1.5)
        ax1.axvline(history.best_epoch, color="grey", linestyle="--", linewidth=1,
                    label=f"Best epoch: {history.best_epoch}")
        ax1.set_xlabel("Epoch")
        ax1.set_ylabel("Mean NLL")
        ax1.set_title("Training History")
        ax1.legend(loc="upper right")

        if history.lr_history:
            ax2 = ax1.twinx()
            ax2.plot(epochs, history.lr_history, color="#4CAF50", linewidth=1,
                     linestyle=":", alpha=0.7, label="LR")
            ax2.set_ylabel("Learning Rate", color="#4CAF50")
            ax2.tick_params(axis="y", labelcolor="#4CAF50")

        fig.tight_layout()
        return fig

    def summary_table(
        self,
        X: np.ndarray,
        y: np.ndarray,
        exposure: Optional[np.ndarray] = None,
    ) -> dict:
        """Compute a summary dictionary of model diagnostics.

        Returns metrics suitable for logging or printing, without requiring
        matplotlib.

        Args:
            X: Feature matrix, shape (n, p).
            y: Observed claim counts, shape (n,).
            exposure: Policy years, shape (n,).

        Returns:
            Dictionary of diagnostic metrics.
        """
        from insurance_poisson_mixture_nn.comparison import gini_coefficient

        comps = self.predictor.predict_components(X, exposure)
        pi = comps["pi"]
        lam0 = comps["lambda_0"]
        lam1 = comps["lambda_1"]
        expected = comps["expected"]

        gini = gini_coefficient(y, expected)
        separation = float(np.median(lam1) - np.median(lam0))
        ordering_violated = int((lam1 <= lam0).sum())

        zero_mask = (np.asarray(y) == 0)
        structural_frac = float(np.mean(pi[zero_mask] < 0.5)) if zero_mask.any() else float("nan")

        return {
            "n_policies": len(y),
            "mean_pi": float(np.mean(pi)),
            "mean_lambda_0": float(np.mean(lam0)),
            "mean_lambda_1": float(np.mean(lam1)),
            "median_lambda_gap": separation,
            "ordering_violated_count": ordering_violated,
            "gini": gini,
            "zero_claim_count": int(zero_mask.sum()),
            "pct_structural_among_zeros": structural_frac,
        }
