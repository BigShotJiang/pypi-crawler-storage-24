"""insurance-poisson-mixture-nn: Neural Poisson mixture model for UK insurance pricing.

Separates structural zero-claimers (policyholders who will never claim) from
stochastic zero-claimers (policyholders who could claim but did not this period).

Based on the PM-DNN architecture described in:
    'Poisson Mixture Deep Learning Neural Network Models for the Prediction of
    Drivers' Claims with Excessive Zero Claims Using Telematics Data'
    North American Actuarial Journal (NAAJ), 2025.
    DOI: 10.1080/10920277.2025.2570289

Example usage::

    from insurance_poisson_mixture_nn import PoissonMixtureNN, PoissonMixtureTrainer
    from insurance_poisson_mixture_nn.synthetic import SyntheticMixtureData

    # Generate synthetic data with known structure
    data = SyntheticMixtureData(n_policies=5000, seed=42)
    X_train, y_train, exp_train = data.training_split()
    X_val, y_val, exp_val = data.validation_split()

    # Build and train the model
    model = PoissonMixtureNN(n_features=X_train.shape[1])
    trainer = PoissonMixtureTrainer(model, max_epochs=100, patience=10)
    history = trainer.fit(X_train, y_train, exp_train, X_val, y_val, exp_val)

    # Predict
    from insurance_poisson_mixture_nn import PoissonMixturePredictor
    predictor = PoissonMixturePredictor(model)
    expected_freq = predictor.predict_expected(X_val, exp_val)
    pi_scores = predictor.predict_pi(X_val)
"""

from insurance_poisson_mixture_nn.model import PoissonMixtureNN
from insurance_poisson_mixture_nn.loss import PoissonMixtureNLL
from insurance_poisson_mixture_nn.trainer import PoissonMixtureTrainer, TrainingHistory
from insurance_poisson_mixture_nn.predictor import PoissonMixturePredictor

__version__ = "0.1.0"
__all__ = [
    "PoissonMixtureNN",
    "PoissonMixtureNLL",
    "PoissonMixtureTrainer",
    "TrainingHistory",
    "PoissonMixturePredictor",
]
