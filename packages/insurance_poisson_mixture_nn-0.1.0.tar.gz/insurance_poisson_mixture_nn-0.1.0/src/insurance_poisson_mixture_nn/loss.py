"""Numerically stable Poisson mixture negative log-likelihood loss.

The mixture log-likelihood for observation i with claim count y_i and
exposure t_i is:

    log p(y_i | x_i) = log[
        (1 - pi_i) * Poisson(y_i; lambda_0_i * t_i)
      +     pi_i   * Poisson(y_i; lambda_1_i * t_i)
    ]

Direct computation is numerically unstable when one component dominates
(log of near-zero probability). We use the log-sum-exp trick:

    log[a + b] = log_a + log(1 + exp(log_b - log_a))

which avoids underflow/overflow for large or small lambda values.

Optional L2 regularisation on model parameters can be added via the
``l2_penalty`` argument, though in practice weight_decay on the optimiser
achieves the same effect with less coupling.
"""

from __future__ import annotations

import torch
import torch.nn as nn
from torch import Tensor

__all__ = ["PoissonMixtureNLL", "poisson_log_pmf"]


def poisson_log_pmf(k: Tensor, rate: Tensor) -> Tensor:
    """Log PMF of Poisson(k; rate).

    Computes log p(k; rate) = k * log(rate) - rate - log(k!).

    Uses torch.special.gammaln for the log-factorial, which is more numerically
    stable than computing factorials directly and handles non-integer k (useful
    for testing with continuous approximations).

    Args:
        k: Observed counts, shape (batch,). Should be non-negative integers
           but this is not enforced for differentiability.
        rate: Poisson rate parameter, shape (batch,). Must be positive.

    Returns:
        Log probabilities of shape (batch,).
    """
    # Clamp rate to avoid log(0) — very small rates produce large negative logs
    # which is numerically acceptable. Zero rates would produce -inf.
    rate_clamped = rate.clamp(min=1e-10)
    log_pmf = k * torch.log(rate_clamped) - rate_clamped - torch.lgamma(k + 1.0)
    return log_pmf


def _mixture_log_prob(
    pi: Tensor,
    lambda_0: Tensor,
    lambda_1: Tensor,
    y: Tensor,
    exposure: Tensor,
) -> Tensor:
    """Compute log p(y | pi, lambda_0, lambda_1, exposure) for a batch.

    Uses log-sum-exp for numerical stability:

        log[w0 * p0 + w1 * p1]
        = log[exp(log(w0) + log(p0)) + exp(log(w1) + log(p1))]
        = logsumexp([log(w0) + log(p0), log(w1) + log(p1)])

    where w0 = 1 - pi, w1 = pi.

    Args:
        pi: At-risk probability, shape (batch,), in (0, 1).
        lambda_0: Safe group rate per unit exposure, shape (batch,).
        lambda_1: Risky group rate per unit exposure, shape (batch,).
        y: Observed claim counts, shape (batch,).
        exposure: Policy exposure in years, shape (batch,).

    Returns:
        Log mixture probability per observation, shape (batch,).
    """
    # Effective rates including exposure
    rate_0 = lambda_0 * exposure
    rate_1 = lambda_1 * exposure

    # Log-weights
    log_w0 = torch.log1p(-pi.clamp(max=1.0 - 1e-7))  # log(1 - pi)
    log_w1 = torch.log(pi.clamp(min=1e-7))

    # Log component probabilities
    log_p0 = poisson_log_pmf(y, rate_0)
    log_p1 = poisson_log_pmf(y, rate_1)

    # log-sum-exp across the two components (shape: batch x 2)
    log_components = torch.stack([log_w0 + log_p0, log_w1 + log_p1], dim=1)
    log_mix = torch.logsumexp(log_components, dim=1)

    return log_mix


class PoissonMixtureNLL(nn.Module):
    """Negative log-likelihood loss for the Poisson mixture model.

    This loss function trains all parameters jointly via gradient descent. No
    E-step/M-step decomposition is used; the mixture is optimised end-to-end,
    which is the key departure from classical EM-based mixture estimation and
    enables use with deep neural network sub-networks.

    The loss is normalised by batch size so that learning rate is insensitive
    to batch size.

    Args:
        reduction: How to reduce over the batch. 'mean' (default) divides by
            batch size. 'sum' returns the total NLL. 'none' returns per-sample
            losses.
        l2_penalty: If > 0, adds an L2 penalty on lambda_0 and lambda_1 to
            discourage the safe group rate from growing large. This is a soft
            version of the upper bound constraint. In most cases, using
            weight_decay on the optimiser is preferable.

    Example::

        loss_fn = PoissonMixtureNLL()
        pi, lam0, lam1 = model(x)
        loss = loss_fn(pi, lam0, lam1, y, exposure)
        loss.backward()
    """

    def __init__(
        self,
        reduction: str = "mean",
        l2_penalty: float = 0.0,
    ) -> None:
        super().__init__()
        if reduction not in ("mean", "sum", "none"):
            raise ValueError(
                f"reduction must be 'mean', 'sum', or 'none', got '{reduction}'"
            )
        self.reduction = reduction
        self.l2_penalty = l2_penalty

    def forward(
        self,
        pi: Tensor,
        lambda_0: Tensor,
        lambda_1: Tensor,
        y: Tensor,
        exposure: Tensor,
    ) -> Tensor:
        """Compute the mixture NLL.

        Args:
            pi: Mixture probability (risky group), shape (batch,).
            lambda_0: Safe group rate, shape (batch,).
            lambda_1: Risky group rate, shape (batch,).
            y: Observed claim counts, shape (batch,). Must be non-negative.
            exposure: Policy exposure in years, shape (batch,). Must be > 0.

        Returns:
            Scalar loss if reduction is 'mean' or 'sum', else shape (batch,).
        """
        log_prob = _mixture_log_prob(pi, lambda_0, lambda_1, y, exposure)
        nll = -log_prob

        if self.l2_penalty > 0.0:
            l2 = self.l2_penalty * (lambda_0.pow(2).mean() + lambda_1.pow(2).mean())
            nll = nll + l2

        if self.reduction == "mean":
            return nll.mean()
        elif self.reduction == "sum":
            return nll.sum()
        else:
            return nll

    def per_sample_nll(
        self,
        pi: Tensor,
        lambda_0: Tensor,
        lambda_1: Tensor,
        y: Tensor,
        exposure: Tensor,
    ) -> Tensor:
        """Return per-sample NLL without reduction.

        Useful for computing test-set NLL, comparing models, and identifying
        policies where the model fits poorly.

        Args:
            pi: Mixture probability, shape (batch,).
            lambda_0: Safe group rate, shape (batch,).
            lambda_1: Risky group rate, shape (batch,).
            y: Claim counts, shape (batch,).
            exposure: Policy years, shape (batch,).

        Returns:
            Per-sample NLL, shape (batch,).
        """
        return -_mixture_log_prob(pi, lambda_0, lambda_1, y, exposure)
