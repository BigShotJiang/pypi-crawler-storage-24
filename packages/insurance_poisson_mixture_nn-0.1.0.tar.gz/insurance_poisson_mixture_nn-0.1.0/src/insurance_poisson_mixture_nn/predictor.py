"""Prediction interface for trained PoissonMixtureNN models.

The predictor provides a clean inference API that abstracts away PyTorch
tensor handling from the caller. All inputs and outputs are numpy arrays,
consistent with scikit-learn convention.

Design rationale: we separate training (PoissonMixtureTrainer) from inference
(PoissonMixturePredictor) because inference is often done in a different
context — downstream scoring pipelines, batch jobs, or APIs — where the caller
should not need to manage PyTorch internals.
"""

from __future__ import annotations

from typing import Optional

import numpy as np
import torch
from torch import Tensor

from insurance_poisson_mixture_nn.model import PoissonMixtureNN

__all__ = ["PoissonMixturePredictor"]


class PoissonMixturePredictor:
    """Inference wrapper for a trained PoissonMixtureNN.

    Accepts numpy arrays, manages device placement, and returns numpy arrays.
    The model is put into eval mode on construction and stays there.

    Args:
        model: A trained PoissonMixtureNN instance.
        device: PyTorch device string. Autodetects CUDA if available.
        batch_size: Batch size for inference. Larger is faster; reduce if you
            hit GPU memory limits.

    Example::

        predictor = PoissonMixturePredictor(model)
        expected_freq = predictor.predict_expected(X_test, exposure_test)
        pi_scores = predictor.predict_pi(X_test)
        structural = predictor.classify_zero(X_test, threshold=0.3)
    """

    def __init__(
        self,
        model: PoissonMixtureNN,
        device: Optional[str] = None,
        batch_size: int = 4096,
    ) -> None:
        self.model = model
        self.batch_size = batch_size

        if device is None:
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self.device = torch.device(device)

        self.model.to(self.device)
        self.model.eval()

    def _to_tensor(self, arr: np.ndarray) -> Tensor:
        return torch.tensor(arr, dtype=torch.float32, device=self.device)

    def _run_batched(
        self, X: np.ndarray
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Run the model in batches, returning (pi, lam0, lam1) as numpy arrays."""
        n = X.shape[0]
        pi_all = np.empty(n, dtype=np.float32)
        lam0_all = np.empty(n, dtype=np.float32)
        lam1_all = np.empty(n, dtype=np.float32)

        with torch.no_grad():
            for start in range(0, n, self.batch_size):
                end = min(start + self.batch_size, n)
                X_b = self._to_tensor(X[start:end])
                pi_b, lam0_b, lam1_b = self.model(X_b)
                pi_all[start:end] = pi_b.cpu().numpy()
                lam0_all[start:end] = lam0_b.cpu().numpy()
                lam1_all[start:end] = lam1_b.cpu().numpy()

        return pi_all, lam0_all, lam1_all

    def predict_components(
        self,
        X: np.ndarray,
        exposure: Optional[np.ndarray] = None,
    ) -> dict[str, np.ndarray]:
        """Return all three mixture component outputs.

        Args:
            X: Feature matrix, shape (n, p).
            exposure: Policy years, shape (n,). Scales the rates. If None,
                rates are returned as per-unit-exposure values.

        Returns:
            Dictionary with keys:
            - ``'pi'``: At-risk probability, shape (n,).
            - ``'lambda_0'``: Safe group rate (per unit exposure), shape (n,).
            - ``'lambda_1'``: Risky group rate (per unit exposure), shape (n,).
            - ``'rate_0'``: Effective safe rate (lambda_0 * exposure), shape (n,).
            - ``'rate_1'``: Effective risky rate (lambda_1 * exposure), shape (n,).
            - ``'expected'``: Mixture expected count, shape (n,).
        """
        pi, lam0, lam1 = self._run_batched(X)
        if exposure is None:
            t = np.ones(X.shape[0], dtype=np.float32)
        else:
            t = np.asarray(exposure, dtype=np.float32)

        rate_0 = lam0 * t
        rate_1 = lam1 * t
        expected = pi * rate_1 + (1.0 - pi) * rate_0

        return {
            "pi": pi,
            "lambda_0": lam0,
            "lambda_1": lam1,
            "rate_0": rate_0,
            "rate_1": rate_1,
            "expected": expected,
        }

    def predict_expected(
        self,
        X: np.ndarray,
        exposure: Optional[np.ndarray] = None,
    ) -> np.ndarray:
        """Predict the expected claim count for each policy.

        This is the primary pricing output:
            E[Y | x] = pi(x) * lambda_1(x) * t + (1 - pi(x)) * lambda_0(x) * t

        Args:
            X: Feature matrix, shape (n, p).
            exposure: Policy years, shape (n,). Defaults to 1.0 per policy.

        Returns:
            Expected claim counts, shape (n,).
        """
        return self.predict_components(X, exposure)["expected"]

    def predict_pi(self, X: np.ndarray) -> np.ndarray:
        """Predict the at-risk probability pi(x).

        High values indicate the policyholder is likely in the risky group;
        low values indicate likely structural zeros.

        Args:
            X: Feature matrix, shape (n, p).

        Returns:
            At-risk probabilities in (0, 1), shape (n,).
        """
        pi, _, _ = self._run_batched(X)
        return pi

    def predict_structural_zero_score(self, X: np.ndarray) -> np.ndarray:
        """Predict the structural zero score (1 - pi(x)).

        High scores indicate likely structural zeros — policyholders who are
        unlikely to ever claim. Directly usable as an underwriting signal.

        Args:
            X: Feature matrix, shape (n, p).

        Returns:
            Structural zero scores in (0, 1), shape (n,).
        """
        return 1.0 - self.predict_pi(X)

    def classify_zero(
        self,
        X: np.ndarray,
        threshold: float = 0.5,
    ) -> np.ndarray:
        """Classify policyholders as structural or stochastic zeros.

        Uses the at-risk probability pi(x) with a threshold. Policyholders
        with pi < threshold are classified as structural zeros.

        Note: This classification is probabilistic and intended for portfolio
        analysis, not hard underwriting rules. Use predict_pi() for a continuous
        score in pricing models.

        Args:
            X: Feature matrix, shape (n, p).
            threshold: pi above which the policy is deemed 'stochastic zero'
                (at-risk but happened not to claim). Default 0.5.

        Returns:
            String array of shape (n,) with values 'structural' or 'stochastic'.
        """
        pi = self.predict_pi(X)
        labels = np.where(pi < threshold, "structural", "stochastic")
        return labels

    def zero_decomposition(
        self,
        X: np.ndarray,
        exposure: Optional[np.ndarray] = None,
    ) -> dict[str, np.ndarray]:
        """Decompose the zero-claim probability into structural and stochastic parts.

        For a policy with y=0 (no claim), the mixture gives:

            P(Y=0 | x) = (1-pi) * exp(-lambda_0 * t) + pi * exp(-lambda_1 * t)

        This method returns the two components and the posterior probability
        of being structural given y=0:

            P(structural | Y=0, x) = (1-pi) * exp(-lambda_0 * t) / P(Y=0 | x)

        Useful for portfolio analysis: for your zero-claim book, how many are
        genuinely safe vs. simply lucky?

        Args:
            X: Feature matrix, shape (n, p).
            exposure: Policy years, shape (n,). Defaults to 1.0.

        Returns:
            Dictionary with:
            - ``'p_zero_total'``: Total P(Y=0 | x), shape (n,).
            - ``'p_zero_structural'``: Structural contribution, shape (n,).
            - ``'p_zero_stochastic'``: Stochastic contribution, shape (n,).
            - ``'posterior_structural'``: P(structural | Y=0, x), shape (n,).
        """
        comps = self.predict_components(X, exposure)
        pi = comps["pi"]
        rate_0 = comps["rate_0"]
        rate_1 = comps["rate_1"]

        p_zero_struct = (1.0 - pi) * np.exp(-rate_0)
        p_zero_stoch = pi * np.exp(-rate_1)
        p_zero_total = p_zero_struct + p_zero_stoch

        # Avoid division by zero for near-impossible zero observations
        posterior_structural = np.where(
            p_zero_total > 1e-30,
            p_zero_struct / p_zero_total,
            0.5,
        )

        return {
            "p_zero_total": p_zero_total,
            "p_zero_structural": p_zero_struct,
            "p_zero_stochastic": p_zero_stoch,
            "posterior_structural": posterior_structural,
        }
