"""Async bridge utilities for the CLI.

Click commands are synchronous; the SDK is async. This module
bridges the two with a thin ``run_async`` wrapper and a
``get_client`` factory.
"""

from __future__ import annotations

import asyncio
import sys
from functools import wraps
from typing import Callable

import click
from fere_sdk import FereClient

from .config import load_config


def run_async(coro):
    """Run an async coroutine from synchronous context."""
    return asyncio.run(coro)


def async_command(f: Callable) -> Callable:
    """Decorator: wraps an async function for use as a Click command."""

    @wraps(f)
    def wrapper(*args, **kwargs):
        return run_async(f(*args, **kwargs))

    return wrapper


async def get_client(ctx: click.Context) -> FereClient:
    """Create an authenticated FereClient from config + CLI overrides.

    Raises click.ClickException if no agent name is configured.
    """
    cfg = load_config()

    # CLI flag overrides
    agent_name = ctx.obj.get("agent_override") or cfg.get("agent_name")
    base_url = ctx.obj.get("base_url_override") or cfg.get("base_url")
    key_path = cfg.get("key_path")

    if not agent_name:
        raise click.ClickException(
            "No agent configured. Run 'fere auth' first "
            "or pass --agent NAME."
        )

    return await FereClient.create(
        agent_name=agent_name,
        base_url=base_url,
        key_path=key_path,
    )


def is_tty() -> bool:
    """Check if stdin is a TTY (interactive terminal)."""
    return sys.stdin.isatty()
