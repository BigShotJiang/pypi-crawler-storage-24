"""Configuration management for the Fere CLI.

Stores persistent settings at ``~/.fere/config.json``.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

DEFAULT_BASE_URL = "https://api.fereai.xyz"
CONFIG_PATH = Path.home() / ".fere" / "config.json"


def load_config() -> dict[str, Any]:
    """Load config from disk, with env-var overrides."""
    cfg: dict[str, Any] = {
        "agent_name": None,
        "base_url": DEFAULT_BASE_URL,
        "default_output": "human",
        "key_path": None,
    }
    if CONFIG_PATH.exists():
        try:
            stored = json.loads(CONFIG_PATH.read_text())
            cfg.update(stored)
        except (json.JSONDecodeError, OSError):
            pass

    # Env overrides
    if env_agent := os.environ.get("FERE_AGENT_NAME"):
        cfg["agent_name"] = env_agent
    if env_url := os.environ.get("FERE_BASE_URL"):
        cfg["base_url"] = env_url

    return cfg


def save_config(cfg: dict[str, Any]) -> None:
    """Persist config to disk."""
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(cfg, indent=2))


def get_config_value(key: str) -> Any:
    """Get a single config value."""
    return load_config().get(key)


def set_config_value(key: str, value: str) -> None:
    """Set a single config value and persist."""
    cfg = load_config()
    # Coerce booleans
    if value.lower() in ("true", "false"):
        cfg[key] = value.lower() == "true"
    else:
        cfg[key] = value
    save_config(cfg)
