"""Portfolio commands: fere wallets, fere holdings, fere notifications."""

from __future__ import annotations

import click

from ..async_util import async_command, get_client
from ..output import print_error, print_success


@click.command()
@click.pass_context
@async_command
async def wallets(ctx):
    """Show wallet addresses (EVM + Solana)."""
    try:
        client = await get_client(ctx)
        data = await client.get_wallets()
        await client.close()

        print_success(data)
    except click.ClickException:
        raise
    except Exception as e:
        print_error(str(e))
        raise SystemExit(1)


@click.command()
@click.pass_context
@async_command
async def holdings(ctx):
    """Show token holdings across all chains."""
    try:
        client = await get_client(ctx)
        data = await client.get_holdings()
        await client.close()

        print_success(data)
    except click.ClickException:
        raise
    except Exception as e:
        print_error(str(e))
        raise SystemExit(1)


@click.command()
@click.option(
    "--limit", default=10, type=int, help="Number of notifications."
)
@click.option("--offset", default=0, type=int, help="Offset.")
@click.option("--type", "notif_type", default=None, help="Filter by type.")
@click.pass_context
@async_command
async def notifications(ctx, limit, offset, notif_type):
    """Show recent notifications."""
    try:
        client = await get_client(ctx)
        data = await client.get_notifications(
            limit=limit, offset=offset, type=notif_type
        )
        await client.close()

        print_success(data)
    except click.ClickException:
        raise
    except Exception as e:
        print_error(str(e))
        raise SystemExit(1)
