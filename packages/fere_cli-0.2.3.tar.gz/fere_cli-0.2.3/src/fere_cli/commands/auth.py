"""Auth commands: fere auth, fere whoami, fere credits, fere claim-daily."""

from __future__ import annotations

import dataclasses
from datetime import datetime

import click
from fere_sdk import FereClient
from rich.console import Console

from ..async_util import async_command, get_client, is_tty
from ..config import load_config, save_config
from ..output import is_json_mode, print_error, print_success

console = Console()


@click.command()
@click.option("--name", prompt=False, default=None, help="Agent name.")
@click.pass_context
@async_command
async def auth(ctx, name: str | None):
    """Authenticate and register a new agent (first-run setup)."""
    cfg = load_config()

    agent_name = ctx.obj.get("agent_override") or name or cfg.get("agent_name")
    if not agent_name:
        if is_tty():
            agent_name = click.prompt("Agent name")
        else:
            raise click.ClickException(
                "Agent name required. Pass --name or --agent."
            )

    base_url = ctx.obj.get("base_url_override") or cfg.get("base_url")
    key_path = cfg.get("key_path")

    try:
        client = await FereClient.create(
            agent_name=agent_name,
            base_url=base_url,
            key_path=key_path,
        )

        # Persist agent name to config
        cfg["agent_name"] = agent_name
        save_config(cfg)

        user = await client.get_user()
        await client.close()

        print_success(
            {
                "status": "authenticated",
                "agent_name": agent_name,
                "user": user,
            },
            quiet_value=agent_name,
        )
    except Exception as e:
        print_error(f"Authentication failed: {e}")
        raise SystemExit(1)


@click.command()
@click.pass_context
@async_command
async def whoami(ctx):
    """Show current agent identity."""
    try:
        client = await get_client(ctx)
        user = await client.get_user()
        await client.close()

        print_success(user)
    except click.ClickException:
        raise
    except Exception as e:
        print_error(str(e))
        raise SystemExit(1)


@click.command()
@click.pass_context
@async_command
async def credits(ctx):
    """Show available credit balance."""
    try:
        client = await get_client(ctx)
        balance = await client.get_credits()
        await client.close()

        print_success(
            {"credits_available": balance},
            quiet_value=str(balance),
        )
    except click.ClickException:
        raise
    except Exception as e:
        print_error(str(e))
        raise SystemExit(1)


def _fmt_dt(value: str | None) -> str:
    """Format an ISO 8601 UTC datetime string in the local timezone."""
    if not value:
        return ""
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone()
        tz_name = dt.strftime("%Z") or dt.strftime("%z")
        return (dt.strftime("%b %d, %Y at %I:%M %p ") + tz_name).replace(
            " 0", " "
        )
    except ValueError:
        return value


@click.command(name="claim-daily")
@click.pass_context
@async_command
async def claim_daily_credits(ctx):
    """Claim your daily credits bonus."""
    try:
        client = await get_client(ctx)
        result = await client.claim_daily_credits()
        await client.close()

        data = dataclasses.asdict(result)
        if not result.success:
            if result.error == "claim_cooldown":
                msg = (
                    "Already claimed today."
                    f" Next claim available at"
                    f" {_fmt_dt(result.next_claim_available_at)}"
                    if result.next_claim_available_at
                    else "Already claimed today."
                )
            elif result.error == "balance_too_high":
                bal = result.current_balance
                msg = (
                    f"Balance too high to claim (current: {bal} credits)."
                    if bal is not None
                    else "Balance too high to claim."
                )
            elif result.error == "user_not_found":
                msg = "User not found. Try logging in again."
            else:
                msg = result.error or "Daily claim failed."
            print_error(msg, details=data)
            raise SystemExit(1)
        if not is_json_mode() and data.get("next_claim_available_at"):
            data["next_claim_available_at"] = _fmt_dt(
                data["next_claim_available_at"]
            )
        print_success(data)
    except click.ClickException:
        raise
    except Exception as e:
        print_error(str(e))
        raise SystemExit(1)
