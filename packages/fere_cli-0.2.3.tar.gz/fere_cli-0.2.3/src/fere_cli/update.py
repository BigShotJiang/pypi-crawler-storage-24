from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import TYPE_CHECKING, Optional, Tuple

if TYPE_CHECKING:
    import click as _click

import click

from . import __version__

PYPI_URL = "https://pypi.org/pypi/fere-cli/json"
CHECK_INTERVAL_SECONDS = 86400  # once per day


def _state_file() -> Path:
    """Return path to the update-check state file."""
    config_dir = Path.home() / ".config" / "fere-cli"
    return config_dir / "update-check.json"


def _should_check() -> bool:
    """Return True if enough time has elapsed since last check."""
    sf = _state_file()
    if not sf.exists():
        return True
    try:
        data = json.loads(sf.read_text())
        last = data.get("last_check", 0)
        return (time.time() - last) >= CHECK_INTERVAL_SECONDS
    except Exception:
        return True


def _record_check() -> None:
    """Persist current timestamp so we skip checks for a day."""
    sf = _state_file()
    try:
        sf.parent.mkdir(parents=True, exist_ok=True)
        sf.write_text(json.dumps({"last_check": time.time()}))
    except Exception:
        pass


def _is_stable_version(version: str) -> bool:
    """Return True if version is a pure X.Y.Z."""
    parts = version.split(".")
    if len(parts) != 3:
        return False
    try:
        _ = (int(parts[0]), int(parts[1]), int(parts[2]))
    except ValueError:
        return False
    return True


def _is_prerelease(version: str) -> bool:
    """Return True if version has a pre-release suffix."""
    return not _is_stable_version(version)


def _parse_version_tuple(
    version: str,
) -> Optional[Tuple[int, int, int]]:
    """Parse the X.Y.Z prefix from a version string."""
    base = version.split("a")[0].split("b")[0].split("rc")[0]
    try:
        major, minor, patch = base.split(".")
        return int(major), int(minor), int(patch)
    except Exception:
        return None


def _parse_prerelease_index(version: str) -> int:
    """Return the numeric pre-release index (e.g. a2→2, rc1→1, stable→0).

    Used as a tiebreaker so a2 sorts above a1 regardless of PyPI dict order.
    Stable versions return 0 (they are ranked via the stability flag instead).
    """
    m = re.search(r"(?:a|b|rc)(\d+)$", version)
    return int(m.group(1)) if m else 0


def _fetch_pypi_releases(
    timeout: float = 2.0,
) -> Optional[dict]:
    """Fetch release data from PyPI. Returns None on error."""
    try:
        req = urllib.request.Request(
            PYPI_URL,
            headers={"User-Agent": "fere-cli"},
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except (
        urllib.error.URLError,
        TimeoutError,
        json.JSONDecodeError,
        OSError,
    ):
        return None


def _latest_from_releases(
    releases: dict,
    include_prerelease: bool = False,
) -> Optional[str]:
    """Pick the latest version from a PyPI releases dict."""
    versions = list(releases.keys())
    if not include_prerelease:
        versions = [v for v in versions if _is_stable_version(v)]

    parsed: list[Tuple[Tuple[int, int, int], int, int, str]] = []
    for v in versions:
        t = _parse_version_tuple(v)
        if t is not None:
            # stability: 1 for stable, 0 for pre-release (stable wins on tie)
            # pre_idx: numeric pre-release index (a2 > a1 regardless of order)
            stability = 1 if _is_stable_version(v) else 0
            pre_idx = _parse_prerelease_index(v)
            parsed.append((t, stability, pre_idx, v))

    if not parsed:
        return None

    parsed.sort(key=lambda item: (item[0], item[1], item[2]))
    return parsed[-1][3]


def get_latest_stable_version(
    timeout: float = 2.0,
) -> Optional[str]:
    """Fetch latest stable fere-cli version from PyPI."""
    data = _fetch_pypi_releases(timeout)
    if not data:
        return None
    return _latest_from_releases(
        data.get("releases", {}),
        include_prerelease=False,
    )


def get_latest_prerelease_version(
    timeout: float = 2.0,
) -> Optional[str]:
    """Fetch latest fere-cli version (including pre-releases)."""
    data = _fetch_pypi_releases(timeout)
    if not data:
        return None
    return _latest_from_releases(
        data.get("releases", {}),
        include_prerelease=True,
    )


def is_newer_version(latest: str, current: str) -> bool:
    """Return True if latest > current.

    When X.Y.Z base is equal, stable > pre-release so that a user on
    e.g. 0.2.0a1 is prompted to upgrade to the stable 0.2.0 release.
    """
    latest_t = _parse_version_tuple(latest)
    current_t = _parse_version_tuple(current)
    if latest_t is None or current_t is None:
        return False
    if latest_t != current_t:
        return latest_t > current_t
    # Same X.Y.Z base: stable release is newer than any pre-release.
    return _is_stable_version(latest) and not _is_stable_version(current)


def _perform_pipx_upgrade(pre: bool = False) -> bool:
    pipx_path = shutil.which("pipx")
    if not pipx_path:
        return False
    cmd = [pipx_path, "upgrade", "fere-cli"]
    if pre:
        cmd.append("--pip-args=--pre")
    try:
        subprocess.run(
            cmd,
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return True
    except subprocess.CalledProcessError:
        return False


def _perform_pip_upgrade(pre: bool = False) -> bool:
    python = sys.executable or "python"
    cmd = [python, "-m", "pip", "install", "--upgrade"]
    if pre:
        cmd.append("--pre")
    cmd.append("fere-cli")
    try:
        subprocess.run(
            cmd,
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return True
    except subprocess.CalledProcessError:
        return False


def perform_self_upgrade(pre: bool = False) -> bool:
    """Upgrade fere-cli via pipx (preferred) or pip."""
    if _perform_pipx_upgrade(pre=pre):
        return True
    return _perform_pip_upgrade(pre=pre)


def _do_prompt(current_is_pre: bool, latest: Optional[str]) -> None:
    """Handle version comparison and interactive prompt on the main thread."""
    if not latest:
        _record_check()
        return

    if not is_newer_version(latest, __version__):
        _record_check()
        return

    channel = "pre-release" if current_is_pre else "stable"
    click.echo(
        f"A new {channel} FereAI CLI version {latest} "
        f"is available (you have {__version__})."
    )

    try:
        should_upgrade = click.confirm(
            "Do you want to upgrade now?",
            default=False,
            show_default=True,
        )
    except (click.Abort, EOFError):
        _record_check()
        return

    if not should_upgrade:
        _record_check()
        return

    click.echo(f"Upgrading fere-cli ({channel})...")
    ok = perform_self_upgrade(pre=current_is_pre)
    _record_check()
    if ok:
        # Omit flags intentionally — they may contain secrets.
        subcmd = sys.argv[1] if len(sys.argv) > 1 else ""
        rerun = f"fere {subcmd}" if subcmd else "fere"
        click.echo(f"Upgrade completed. Please re-run: {rerun}")
        # sys.exit(0) intentionally skips remaining call_on_close
        # handlers — the process must restart after upgrade anyway.
        sys.exit(0)
    else:
        click.echo(
            "Upgrade failed. Manually upgrade with "
            "'pipx upgrade fere-cli' or "
            "'pip install --upgrade fere-cli'.",
            err=True,
        )


def maybe_check_for_updates(
    output_json: bool,
    quiet: bool,
    ctx: "Optional[_click.Context]" = None,
) -> None:
    """Check PyPI for newer CLI version, at most once per day.

    The PyPI fetch runs in a background thread so it never blocks the
    subcommand.  When *ctx* is provided the interactive prompt fires via
    ``ctx.call_on_close()`` on the main thread after the subcommand
    completes, avoiding any race with terminal I/O.  Without *ctx* the
    check runs synchronously (useful for tests / direct calls).

    - Skips non-interactive / piped usage.
    - Skips when output_json or quiet is enabled.
    - Skips when FERE_NO_UPDATE_CHECK=1 is set.
    - When current version is a pre-release, checks for
      the latest pre-release; otherwise checks stable only.
    - Never raises; on any error it silently returns.
    """
    if output_json or quiet:
        return

    if os.environ.get("FERE_NO_UPDATE_CHECK") == "1":
        return

    if not sys.stdin.isatty() or not sys.stdout.isatty():
        return

    if not _should_check():
        return

    current_is_pre = _is_prerelease(__version__)
    result: dict = {}
    fetch_done = threading.Event()

    def _bg_fetch() -> None:
        try:
            if current_is_pre:
                result["latest"] = get_latest_prerelease_version()
            else:
                result["latest"] = get_latest_stable_version()
        except Exception:
            pass
        finally:
            fetch_done.set()

    threading.Thread(target=_bg_fetch, daemon=True).start()

    def _prompt() -> None:
        # By the time the subcommand finishes the fetch is usually done;
        # wait at most 2 s for any remaining network time.
        fetch_done.wait(timeout=2.0)
        _do_prompt(current_is_pre, result.get("latest"))

    if ctx is not None:
        ctx.call_on_close(_prompt)
    else:
        _prompt()
