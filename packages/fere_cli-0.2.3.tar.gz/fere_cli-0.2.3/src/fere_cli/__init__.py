"""FereAI CLI — terminal interface for crypto trading and research."""

from importlib.metadata import PackageNotFoundError, version

try:
    # Always report the installed distribution version.
    __version__ = version("fere-cli")
except PackageNotFoundError:
    # Fallback for local/uninstalled source usage.
    __version__ = "0.0.0"
