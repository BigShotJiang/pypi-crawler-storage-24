"""ASCII art banner for the Fere CLI."""

from . import __version__

# Simplified spiral motif + stylized "FERE AI" text
# The spiral evokes the Fere AI logo's concentric swirl pattern
# Kept under 70 chars wide for comfortable 80-col terminal display
LOGO = r"""
     . · .
   ·       ·      _____ _____ ____  _____      _    ___
  ·  . · .  ·    |  ___|  ___|  _ \| ____|    / \  |_ _|
 ·  ·     ·  ·   | |_  | |_  | |_) |  _|     / _ \  | |
 ·  ·  .  ·  ·   |  _| |  _| |  _ <| |___   / ___ \ | |
 ·  ·     ·  ·   |_|   |___|_|_| \_\_____|  /_/   \_\___|
  ·  · . ·  ·
   ·       ·
     · . ·
"""


def get_banner() -> str:
    """Return the full banner string with version."""
    tagline = "crypto trading & research from your terminal"
    return f"{LOGO}\n  v{__version__} — {tagline}\n"
