from __future__ import annotations

import json
import types

import fere_cli.update as update


def test_is_stable_version_accepts_pure_semver() -> None:
    assert update._is_stable_version("0.1.0")
    assert update._is_stable_version("10.20.30")


def test_is_stable_version_rejects_prereleases() -> None:
    assert not update._is_stable_version("0.1.0a1")
    assert not update._is_stable_version("0.1.0rc1")
    assert not update._is_stable_version("1.2")
    assert not update._is_stable_version("1.2.3.4")
    assert not update._is_stable_version("foo")


def test_is_prerelease() -> None:
    assert update._is_prerelease("0.2.0a1")
    assert update._is_prerelease("0.2.0rc1")
    assert not update._is_prerelease("0.2.0")


def test_is_newer_version_compares_semver() -> None:
    assert update.is_newer_version("0.2.0", "0.1.0")
    assert update.is_newer_version("1.0.0", "0.9.9")
    assert not update.is_newer_version("0.1.0", "0.1.0")
    assert not update.is_newer_version("0.1.0", "0.2.0")


def test_is_newer_version_prerelease_prefix() -> None:
    assert update.is_newer_version("0.3.0a1", "0.2.0")
    assert not update.is_newer_version("0.2.0a1", "0.2.0")
    # stable is newer than same-base pre-release
    assert update.is_newer_version("0.2.0", "0.2.0a1")


def _make_fake_urlopen(releases: dict):
    class FakeResponse:
        def __init__(self, payload: bytes) -> None:
            self._payload = payload

        def read(self) -> bytes:
            return self._payload

        def __enter__(self) -> "FakeResponse":
            return self

        def __exit__(self, *exc: object) -> None:
            return None

    def fake_urlopen(req, timeout=0):
        payload = {"releases": releases}
        return FakeResponse(json.dumps(payload).encode("utf-8"))

    return fake_urlopen


def test_get_latest_stable_version_ignores_prereleases(
    monkeypatch,
) -> None:
    releases = {
        "0.1.0": [],
        "0.2.0a1": [],
        "0.2.0": [],
    }
    monkeypatch.setattr(
        update.urllib.request,
        "urlopen",
        _make_fake_urlopen(releases),
    )
    latest = update.get_latest_stable_version()
    assert latest == "0.2.0"


def test_get_latest_prerelease_version_includes_all(
    monkeypatch,
) -> None:
    releases = {
        "0.1.0": [],
        "0.2.0a1": [],
        "0.2.0": [],
        "0.3.0a1": [],
    }
    monkeypatch.setattr(
        update.urllib.request,
        "urlopen",
        _make_fake_urlopen(releases),
    )
    latest = update.get_latest_prerelease_version()
    assert latest == "0.3.0a1"


def test_latest_from_releases_prerelease_index_ordering() -> None:
    """a2 must beat a1 regardless of PyPI dict insertion order."""
    releases_a1_first = {"0.2.0a1": [], "0.2.0a2": []}
    releases_a2_first = {"0.2.0a2": [], "0.2.0a1": []}
    assert (
        update._latest_from_releases(releases_a1_first, include_prerelease=True)
        == "0.2.0a2"
    )
    assert (
        update._latest_from_releases(releases_a2_first, include_prerelease=True)
        == "0.2.0a2"
    )


def test_should_check_respects_interval(monkeypatch, tmp_path) -> None:
    sf = tmp_path / "update-check.json"
    monkeypatch.setattr(update, "_state_file", lambda: sf)

    # No file → should check
    assert update._should_check()

    # Just checked → skip
    update._record_check()
    assert not update._should_check()

    # Old timestamp → should check
    import time

    sf.write_text(json.dumps({"last_check": time.time() - 100_000}))
    assert update._should_check()


def test_maybe_check_skips_when_env_var_set_with_tty(
    monkeypatch, capsys
) -> None:
    """FERE_NO_UPDATE_CHECK=1 suppresses check even when TTY is active."""
    fake_tty = types.SimpleNamespace(isatty=lambda: True)
    monkeypatch.setattr(update.sys, "stdin", fake_tty)
    monkeypatch.setattr(update.sys, "stdout", fake_tty)
    monkeypatch.setenv("FERE_NO_UPDATE_CHECK", "1")
    monkeypatch.setattr(update, "_should_check", lambda: True)
    monkeypatch.setattr(
        update, "get_latest_stable_version", lambda **kw: "999.0.0"
    )
    monkeypatch.setattr(
        update, "is_newer_version", lambda latest, current: True
    )

    update.maybe_check_for_updates(output_json=False, quiet=False)
    captured = capsys.readouterr()
    assert captured.out == ""
    assert captured.err == ""


def test_maybe_check_skips_non_tty(monkeypatch, capsys) -> None:
    """Non-TTY stdin/stdout suppresses check regardless of env var."""
    fake_non_tty = types.SimpleNamespace(isatty=lambda: False)
    monkeypatch.setattr(update.sys, "stdin", fake_non_tty)
    monkeypatch.setattr(update.sys, "stdout", fake_non_tty)
    monkeypatch.delenv("FERE_NO_UPDATE_CHECK", raising=False)
    monkeypatch.setattr(update, "_should_check", lambda: True)
    monkeypatch.setattr(
        update, "get_latest_stable_version", lambda **kw: "999.0.0"
    )
    monkeypatch.setattr(
        update, "is_newer_version", lambda latest, current: True
    )

    update.maybe_check_for_updates(output_json=False, quiet=False)
    captured = capsys.readouterr()
    assert captured.out == ""
    assert captured.err == ""


def _setup_tty_with_update(monkeypatch, tmp_path):
    """Common setup: fake TTY, update available, state file in tmp_path."""
    import io

    sf = tmp_path / "update-check.json"
    monkeypatch.setattr(update, "_state_file", lambda: sf)
    # stdin only needs isatty(); stdout must also be writable for click.echo.
    fake_stdin = types.SimpleNamespace(isatty=lambda: True)

    class FakeTTYOut(io.StringIO):
        def isatty(self) -> bool:
            return True

    monkeypatch.setattr(update.sys, "stdin", fake_stdin)
    monkeypatch.setattr(update.sys, "stdout", FakeTTYOut())
    monkeypatch.delenv("FERE_NO_UPDATE_CHECK", raising=False)
    monkeypatch.setattr(update, "_should_check", lambda: True)
    monkeypatch.setattr(
        update, "get_latest_stable_version", lambda **kw: "999.0.0"
    )
    return sf


def test_maybe_check_user_declines_records_check(monkeypatch, tmp_path) -> None:
    """User declines upgrade → _record_check() persists timestamp."""
    sf = _setup_tty_with_update(monkeypatch, tmp_path)
    monkeypatch.setattr(update.click, "confirm", lambda *a, **kw: False)

    update.maybe_check_for_updates(output_json=False, quiet=False)

    assert sf.exists(), "_record_check() must write state file on decline"


def test_maybe_check_user_confirms_upgrades_and_exits(
    monkeypatch, tmp_path
) -> None:
    """User confirms upgrade → sys.exit(0) and state file written."""
    import pytest

    sf = _setup_tty_with_update(monkeypatch, tmp_path)
    monkeypatch.setattr(update.click, "confirm", lambda *a, **kw: True)
    monkeypatch.setattr(update, "perform_self_upgrade", lambda **kw: True)

    with pytest.raises(SystemExit) as exc_info:
        update.maybe_check_for_updates(output_json=False, quiet=False)

    assert exc_info.value.code == 0
    assert sf.exists(), "_record_check() must write state file on upgrade"
