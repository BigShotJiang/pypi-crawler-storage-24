#!/bin/sh
# FereAI CLI Installer
# Usage (recommended):
#   curl -fsSL https://api.fereai.xyz/install.sh | sh
# Install a specific version or channel:
#   curl -fsSL https://api.fereai.xyz/install.sh | sh -s -- 1.2.3
#   curl -fsSL https://api.fereai.xyz/install.sh | sh -s -- latest
# Or manual install:
#   pipx install fere-cli
#   python -m pip install --user fere-cli
#
# Installs the `fere` CLI tool via pipx (recommended) or pip.
# Supports macOS and Linux.
#
# Note: uses `local` keyword which is not in POSIX but is supported by
# all target shells (dash, bash, zsh, ash) on macOS and Linux.

set -eu

PACKAGE="fere-cli"

# Optional target/channel argument: stable (default), latest, or explicit version (X.Y.Z)
TARGET="${1:-stable}"

print_usage_and_exit() {
    echo "Usage: install.sh [stable|latest|X.Y.Z]" >&2
    exit 1
}

case "$TARGET" in
    stable) ;;
    latest) ;;
    *)
        echo "$TARGET" | grep -qE '^[0-9]+\.[0-9]+\.[0-9]+$' || print_usage_and_exit
        ;;
esac

# Colors (disabled if not a suitable TTY or when piped)
if [ -t 1 ] && [ -t 0 ] && [ "${TERM:-}" != "dumb" ] && [ -z "${NO_COLOR:-}" ] && [ -z "${FERE_NO_COLOR:-}" ]; then
    RED='\033[0;31m'
    GREEN='\033[0;32m'
    YELLOW='\033[0;33m'
    DIM='\033[2m'
    RESET='\033[0m'
else
    RED=''
    GREEN=''
    YELLOW=''
    DIM=''
    RESET=''
fi

info() {
    printf "%s%s%s\n" "$DIM" "$1" "$RESET"
}

success() {
    printf "%s%s%s\n" "$GREEN" "$1" "$RESET"
}

warn() {
    printf "%s%s%s\n" "$YELLOW" "$1" "$RESET" >&2
}

error() {
    printf "%sError: %s%s\n" "$RED" "$1" "$RESET" >&2
    exit 1
}

# Detect OS
OS="$(uname -s)"
case "$OS" in
    Darwin) OS_NAME="macOS" ;;
    Linux)  OS_NAME="Linux" ;;
    *)      error "Unsupported OS: $OS. Use 'pip install $PACKAGE' instead." ;;
esac

info "Installing FereAI CLI on ${OS_NAME} (target: ${TARGET})..."

# Check Python 3.10+
check_python() {
    local checked="" ver major minor cmd
    for cmd in python3 python; do
        if command -v "$cmd" >/dev/null 2>&1; then
            ver=$("$cmd" -c 'import sys; print("{}.{}".format(sys.version_info.major, sys.version_info.minor))' 2>/dev/null || true)
            if [ -n "$ver" ]; then
                major=$(printf "%s" "$ver" | cut -d. -f1)
                minor=$(printf "%s" "$ver" | cut -d. -f2)
                checked="${checked} $cmd($ver)"
                if [ "$major" -gt 3 ] || { [ "$major" -eq 3 ] && [ "$minor" -ge 10 ]; }; then
                    echo "$cmd"
                    return 0
                fi
            fi
        fi
    done
    warn "Checked Python interpreters:${checked}"
    return 1
}

PYTHON=$(check_python) || error "Python 3.10+ is required. Install it from https://python.org"
info "Found Python: $("$PYTHON" --version 2>/dev/null || echo "$PYTHON")"

# Derive package spec and extra args from target
PKG_SPEC="$PACKAGE"
PIP_EXTRA_ARGS=""
PIPX_EXTRA_ARGS=""

case "$TARGET" in
    stable)
        PKG_SPEC="$PACKAGE"
        ;;
    latest)
        PKG_SPEC="$PACKAGE"
        PIP_EXTRA_ARGS="--pre"
        # Single-token form (--opt=value) required; pipx receives it as one arg.
        PIPX_EXTRA_ARGS="--pip-args=--pre"
        ;;
    *)
        # Explicit version
        PKG_SPEC="$PACKAGE==$TARGET"
        ;;
esac

# Prefer pipx for isolated installs.
# Always use --force for idempotent behavior (fresh install or reinstall).
# This matches the pattern used by Deno, Bun, and uv installers, and avoids
# the fragile try-then-force-retry pattern with stderr suppression.
install_with_pipx() {
    if command -v pipx >/dev/null 2>&1; then
        info "Installing with pipx..."
        if [ -n "$PIPX_EXTRA_ARGS" ]; then
            pipx install --python "$PYTHON" --force "$PIPX_EXTRA_ARGS" "$PKG_SPEC" || return 1
        else
            pipx install --python "$PYTHON" --force "$PKG_SPEC" || return 1
        fi
        return 0
    fi
    return 1
}

install_pipx() {
    info "Installing pipx..."
    local _pipx_install_ok=0
    if command -v brew >/dev/null 2>&1; then
        brew install pipx && _pipx_install_ok=1
    fi
    # pip fallback for both macOS (if brew failed) and other systems
    if [ "$_pipx_install_ok" != "1" ]; then
        "$PYTHON" -m pip install --user pipx 2>/dev/null || {
            "$PYTHON" -m ensurepip --default-pip 2>/dev/null &&
            "$PYTHON" -m pip install --user pipx 2>/dev/null
        } && _pipx_install_ok=1
    fi
    return $((1 - _pipx_install_ok))
}

install_with_pip() {
    # Note: PIP_EXTRA_ARGS must be a single token; see PIPX_EXTRA_ARGS comment.
    info "Installing with pip (user install)..."
    if [ -n "$PIP_EXTRA_ARGS" ]; then
        "$PYTHON" -m pip install --user "$PIP_EXTRA_ARGS" "$PKG_SPEC"
    else
        "$PYTHON" -m pip install --user "$PKG_SPEC"
    fi
}

detect_user_bin() {
    local user_base dir
    # Prefer Python's user base if available
    if command -v "$PYTHON" >/dev/null 2>&1; then
        user_base=$("$PYTHON" -c 'import site, sys; sys.stdout.write(site.getuserbase())' 2>/dev/null || echo "")
        if [ -n "$user_base" ] && [ -d "$user_base/bin" ]; then
            echo "$user_base/bin"
            return 0
        fi
    fi

    # Common fallbacks
    for dir in "$HOME/.local/bin" "$HOME/bin"; do
        if [ -d "$dir" ]; then
            echo "$dir"
            return 0
        fi
    done

    return 1
}

expand_path() {
    local path="$1"
    case "$path" in
        "~")
            printf "%s\n" "${HOME:-}"
            ;;
        "~/"*)
            printf "%s\n" "${HOME:-}/${path#~/}"
            ;;
        *)
            printf "%s\n" "$path"
            ;;
    esac
}

append_path_export_if_missing() {
    local rc_file="$1"
    local user_bin="$2"
    local rc_path rc_dir

    [ -n "$rc_file" ] || return 1
    [ -n "$user_bin" ] || return 1

    rc_path=$(expand_path "$rc_file")
    [ -n "$rc_path" ] || return 1

    rc_dir=$(dirname "$rc_path")
    if [ ! -d "$rc_dir" ]; then
        mkdir -p "$rc_dir" 2>/dev/null || return 1
    fi

    touch "$rc_path" 2>/dev/null || return 1

    if grep -v "^[[:space:]]*#" "$rc_path" 2>/dev/null | grep -qE "(^|:|=\"|=)${user_bin}(:|\"|\\\$|$)"; then
        return 0
    fi
    # Also catch $HOME-relative variants (e.g. $HOME/.local/bin or ${HOME}/.local/bin)
    # to avoid duplicates when the user already has an equivalent entry.
    home_rel="${user_bin#"${HOME:-}"}"
    if [ "$home_rel" != "$user_bin" ]; then
        if grep -v "^[[:space:]]*#" "$rc_path" 2>/dev/null | grep -qE "(^|:|=\"|=)\\\$HOME${home_rel}(:|\"|\\\$|$)"; then
            return 0
        fi
        if grep -v "^[[:space:]]*#" "$rc_path" 2>/dev/null | grep -qE "(^|:|=\"|=)\\\$\{HOME\}${home_rel}(:|\"|\\\$|$)"; then
            return 0
        fi
    fi

    {
        echo ""
        echo "# Added by FereAI CLI installer"
        # Write $HOME-relative path when possible so the entry stays valid
        # even if the home directory path changes (e.g. LDAP migration).
        if [ "$home_rel" != "$user_bin" ]; then
            echo "export PATH=\"\$HOME${home_rel}:\$PATH\""
        else
            echo "export PATH=\"$user_bin:\$PATH\""
        fi
    } >>"$rc_path" 2>/dev/null || return 1

    return 0
}

detect_shell_rc() {
    local shell_path
    shell_path="${SHELL:-}"
    case "$shell_path" in
        *zsh) echo "~/.zshrc" ;;
        *bash)
            if [ "$OS" = "Darwin" ]; then
                echo "~/.bash_profile"
            else
                echo "~/.bashrc"
            fi
            ;;
        *fish) echo "~/.config/fish/config.fish" ;;
        *) echo "~/.profile" ;;
    esac
}

installed_with=""

# Try pipx first, then install pipx, then fall back to pip
if install_with_pipx; then
    installed_with="pipx"
elif install_pipx; then
    # Freshly-installed pipx may not be on PATH yet; resolve its location.
    _user_base=$("$PYTHON" -c 'import site; print(site.getuserbase())' 2>/dev/null || echo "")
    if [ -n "$_user_base" ] && [ -x "$_user_base/bin/pipx" ]; then
        export PATH="$_user_base/bin:$PATH"
        pipx ensurepath 2>/dev/null || true
    fi
    if install_with_pipx; then
        installed_with="pipx"
    else
        warn "pipx not available, falling back to pip..."
        install_with_pip || error "Installation failed. Please install manually: pip install $PACKAGE"
        installed_with="pip"
    fi
else
    warn "pipx not available, falling back to pip..."
    install_with_pip || error "Installation failed. Please install manually: pip install $PACKAGE"
    installed_with="pip"
fi

info "Installed $PKG_SPEC using: $installed_with"

# Verify installation
if command -v fere >/dev/null 2>&1; then
    version_str=$(fere --version 2>/dev/null || echo "")
    success "FereAI CLI installed successfully!"
    if [ -n "$version_str" ]; then
        info "Installed version: $version_str"
    fi
    echo ""
    info "Get started:"
    echo "  fere auth --name my-agent   # Set up your agent"
    echo "  fere chat \"hello\"          # Chat with the AI"
    echo "  fere --help                 # See all commands"
else
    warn "Installation complete, but 'fere' is not in PATH."
    user_bin=$(detect_user_bin || echo "")
    rc_file=$(detect_shell_rc)
    echo ""
    if [ -n "$user_bin" ]; then
        case "$rc_file" in
            *fish*)
                echo "Run this command in your fish shell:"
                echo ""
                echo "  fish_add_path \"$user_bin\""
                echo ""
                echo "This takes effect immediately in all fish sessions."
                ;;
            *)
                if append_path_export_if_missing "$rc_file" "$user_bin"; then
                    success "Updated your PATH in $rc_file to include '$user_bin'."
                    echo ""
                    info "Please restart your terminal so 'fere' is available in new shells."
                else
                    echo "To fix this, add the following line to $rc_file:"
                    echo ""
                    echo "  export PATH=\"$user_bin:\$PATH\""
                    echo ""
                    echo "After updating, restart your terminal so 'fere' is available."
                fi
                ;;
        esac
    else
        echo "Could not detect your user bin directory automatically."
        echo "Make sure the directory containing the 'fere' executable is on your PATH."
    fi
fi
