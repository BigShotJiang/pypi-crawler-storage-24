# meshpop-db

MeshPOP DB — Distributed search & key-value database.

> This package is a placeholder. Full release coming soon.

See [github.com/meshpop/meshdb](https://github.com/meshpop/meshdb) for source.
