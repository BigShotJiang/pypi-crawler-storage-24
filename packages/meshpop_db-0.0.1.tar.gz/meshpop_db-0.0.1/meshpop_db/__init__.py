"""MeshPOP DB — Distributed search & key-value database"""
