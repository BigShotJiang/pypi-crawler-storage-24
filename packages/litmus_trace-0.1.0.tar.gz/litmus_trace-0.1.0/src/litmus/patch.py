"""Direct SDK monkey-patching — no proxy needed.

Usage:
    import litmus
    litmus.record()          # start recording all LLM calls
    # ... your agent code, unchanged ...
    litmus.stop()            # save trace

    litmus.replay("trace.json")  # replay from a trace file
    # ... your agent code, gets recorded responses ...
    litmus.stop()
"""

from __future__ import annotations

import atexit
import functools
import json
import time
from pathlib import Path
from typing import Any

from litmus.models import (
    Trace,
    LLMCall,
    LLMRequest,
    LLMResponse,
    TraceMetadata,
)

# Global state
_active_trace: Trace | None = None
_mode: str | None = None  # "record" or "replay"
_replay_trace: Trace | None = None
_replay_index: int = 0
_output_dir: str = "./traces"
_original_transports: dict[str, Any] = {}
_patched: bool = False


def record(output_dir: str = "./traces", agent_id: str | None = None) -> Trace:
    """Start recording all LLM SDK calls. No proxy, no env vars, no setup.

    Call this before any LLM SDK usage. All calls to Anthropic/OpenAI
    will be intercepted and recorded.

    Returns the Trace object (also saved to disk on stop()).
    """
    global _active_trace, _mode, _output_dir

    _mode = "record"
    _output_dir = output_dir
    _active_trace = Trace(agent_id=agent_id, metadata=TraceMetadata.auto())

    _patch_sdks()
    atexit.register(stop)

    return _active_trace


def replay(trace_path: str) -> Trace:
    """Replay a recorded trace. All LLM calls return recorded responses.

    Call this before any LLM SDK usage. The agent's code runs unchanged
    but gets deterministic pre-recorded responses instead of real API calls.
    """
    global _active_trace, _mode, _replay_trace, _replay_index

    _mode = "replay"
    _replay_trace = Trace.load(trace_path)
    _replay_index = 0
    _active_trace = Trace(
        agent_id=_replay_trace.agent_id,
        metadata=TraceMetadata.auto(),
    )

    _patch_sdks()
    atexit.register(stop)

    return _replay_trace


def stop() -> str | None:
    """Stop recording/replaying and save the trace. Returns the file path."""
    global _active_trace, _mode, _replay_trace, _replay_index, _patched

    _unpatch_sdks()

    if _active_trace is None:
        return None

    if _mode == "record":
        _active_trace.complete()
        path = str(Path(_output_dir) / f"{_active_trace.trace_id}.trace.json")
        _active_trace.save(path)
        _active_trace = None
        _mode = None
        return path

    _active_trace = None
    _mode = None
    _replay_trace = None
    _replay_index = 0
    return None


def _patch_sdks() -> None:
    """Monkey-patch installed SDK HTTP transports."""
    global _patched
    if _patched:
        return
    _patched = True

    _try_patch_httpx()


def _unpatch_sdks() -> None:
    """Restore original SDK transports."""
    global _patched
    if not _patched:
        return
    _patched = False

    _try_unpatch_httpx()


def _try_patch_httpx() -> None:
    """Patch httpx.Client.send and httpx.AsyncClient.send.

    Both Anthropic and OpenAI Python SDKs use httpx under the hood.
    By patching httpx, we intercept ALL HTTP calls from both SDKs
    without needing to know their internal APIs.
    """
    try:
        import httpx
    except ImportError:
        return

    # Patch sync client
    original_sync_send = httpx.Client.send
    _original_transports["httpx_sync_send"] = original_sync_send

    @functools.wraps(original_sync_send)
    def patched_sync_send(self, request, **kwargs):
        if _should_intercept(str(request.url)):
            return _handle_sync_request(self, request, original_sync_send, **kwargs)
        return original_sync_send(self, request, **kwargs)

    httpx.Client.send = patched_sync_send

    # Patch async client
    original_async_send = httpx.AsyncClient.send
    _original_transports["httpx_async_send"] = original_async_send

    @functools.wraps(original_async_send)
    async def patched_async_send(self, request, **kwargs):
        if _should_intercept(str(request.url)):
            return await _handle_async_request(self, request, original_async_send, **kwargs)
        return await original_async_send(self, request, **kwargs)

    httpx.AsyncClient.send = patched_async_send


def _try_unpatch_httpx() -> None:
    """Restore original httpx send methods."""
    try:
        import httpx
    except ImportError:
        return

    if "httpx_sync_send" in _original_transports:
        httpx.Client.send = _original_transports.pop("httpx_sync_send")
    if "httpx_async_send" in _original_transports:
        httpx.AsyncClient.send = _original_transports.pop("httpx_async_send")


# Known LLM API host patterns
_LLM_HOSTS = {
    "api.anthropic.com",
    "api.openai.com",
    "api.mistral.ai",
    "api.cohere.com",
    "api.groq.com",
    "api.together.xyz",
    "api.fireworks.ai",
    "api.deepseek.com",
    "api.perplexity.ai",
    "openrouter.ai",
    "generativelanguage.googleapis.com",
}


def _should_intercept(url: str) -> bool:
    """Check if this URL is an LLM API call we should intercept."""
    if _mode is None:
        return False
    from urllib.parse import urlparse
    host = urlparse(url).hostname or ""
    return host in _LLM_HOSTS


def _detect_provider_from_url(url: str) -> str:
    """Map a URL to a provider name."""
    from urllib.parse import urlparse
    host = urlparse(url).hostname or ""
    mapping = {
        "api.anthropic.com": "anthropic",
        "api.openai.com": "openai",
        "api.mistral.ai": "mistral",
        "api.cohere.com": "cohere",
        "api.groq.com": "groq",
        "api.together.xyz": "together",
        "api.fireworks.ai": "fireworks",
        "api.deepseek.com": "deepseek",
        "api.perplexity.ai": "perplexity",
        "openrouter.ai": "openrouter",
        "generativelanguage.googleapis.com": "google",
    }
    return mapping.get(host, "unknown")


def _extract_model(body: dict | None) -> str | None:
    if not body:
        return None
    return body.get("model")


def _parse_body(content: bytes) -> dict | None:
    try:
        return json.loads(content) if content else None
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None


def _handle_sync_request(client, request, original_send, **kwargs):
    """Intercept a sync HTTP request — record or replay."""
    import httpx

    global _replay_index

    url = str(request.url)
    provider = _detect_provider_from_url(url)
    body_json = _parse_body(request.content)
    model = _extract_model(body_json)
    is_stream = body_json.get("stream", False) if body_json else False

    if _mode == "replay" and _replay_trace is not None:
        # Serve recorded response
        if _replay_index < len(_replay_trace.steps):
            step = _replay_trace.steps[_replay_index]
            _replay_index += 1

            if isinstance(step, LLMCall) and step.response:
                resp_body = json.dumps(step.response.body or {}).encode()

                if step.response.is_stream and step.response.stream_chunks:
                    raw_chunks = "".join(step.response.stream_chunks).encode()
                    resp = httpx.Response(
                        status_code=step.response.status_code,
                        headers={"content-type": "text/event-stream"},
                        stream=httpx.ByteStream(raw_chunks),
                        request=request,
                    )
                    return resp

                resp = httpx.Response(
                    status_code=step.response.status_code,
                    headers={"content-type": "application/json"},
                    content=resp_body,
                    request=request,
                )
                return resp

        # Exhausted
        import sys
        total = len(_replay_trace.steps) if _replay_trace else 0
        print(
            f"\n[litmus] Replay exhausted at step {_replay_index} — "
            f"your agent made more calls than the recording ({total} steps).\n"
            f"[litmus] This usually means the agent's behavior diverged from the original.",
            file=sys.stderr,
        )
        return httpx.Response(
            status_code=500,
            content=json.dumps({
                "error": f"Litmus replay exhausted — recording had {total} steps, agent requested step {_replay_index + 1}"
            }).encode(),
            request=request,
        )

    # Record mode — forward the real request and capture response
    llm_call = LLMCall(
        request=LLMRequest(
            provider=provider,
            model=model,
            method=request.method,
            path=str(request.url.raw_path, "utf-8") if isinstance(request.url.raw_path, bytes) else str(request.url.raw_path),
            body=body_json,
        )
    )

    start = time.monotonic()
    try:
        response = original_send(client, request, **kwargs)
    except Exception as e:
        llm_call.latency_ms = (time.monotonic() - start) * 1000
        llm_call.error = str(e)
        if _active_trace:
            _active_trace.add_step(llm_call)
        raise

    llm_call.latency_ms = (time.monotonic() - start) * 1000

    # Read response body for recording
    # For streaming, we need to wrap the stream to capture chunks
    if is_stream:
        chunks: list[str] = []
        original_stream = response.stream

        def recording_stream():
            for chunk in original_stream:
                if isinstance(chunk, bytes):
                    chunks.append(chunk.decode("utf-8", errors="replace"))
                else:
                    chunks.append(str(chunk))
                yield chunk

            llm_call.response = LLMResponse(
                status_code=response.status_code,
                is_stream=True,
                stream_chunks=chunks,
            )
            if _active_trace:
                _active_trace.add_step(llm_call)

        response.stream = recording_stream()
        return response

    # Non-streaming — read body
    resp_json = None
    try:
        resp_json = response.json()
    except Exception:
        pass

    llm_call.response = LLMResponse(
        status_code=response.status_code,
        body=resp_json,
        is_stream=False,
    )
    if _active_trace:
        _active_trace.add_step(llm_call)

    return response


async def _handle_async_request(client, request, original_send, **kwargs):
    """Intercept an async HTTP request — record or replay."""
    import httpx

    global _replay_index

    url = str(request.url)
    provider = _detect_provider_from_url(url)
    body_json = _parse_body(request.content)
    model = _extract_model(body_json)

    if _mode == "replay" and _replay_trace is not None:
        if _replay_index < len(_replay_trace.steps):
            step = _replay_trace.steps[_replay_index]
            _replay_index += 1

            if isinstance(step, LLMCall) and step.response:
                resp_body = json.dumps(step.response.body or {}).encode()

                if step.response.is_stream and step.response.stream_chunks:
                    raw_chunks = "".join(step.response.stream_chunks).encode()
                    return httpx.Response(
                        status_code=step.response.status_code,
                        headers={"content-type": "text/event-stream"},
                        stream=httpx.ByteStream(raw_chunks),
                        request=request,
                    )

                return httpx.Response(
                    status_code=step.response.status_code,
                    headers={"content-type": "application/json"},
                    content=resp_body,
                    request=request,
                )

        import sys
        total = len(_replay_trace.steps) if _replay_trace else 0
        print(
            f"\n[litmus] Async replay exhausted at step {_replay_index} — "
            f"recording had {total} steps.",
            file=sys.stderr,
        )
        return httpx.Response(
            status_code=500,
            content=json.dumps({
                "error": f"Litmus replay exhausted — recording had {total} steps"
            }).encode(),
            request=request,
        )

    # Record mode
    llm_call = LLMCall(
        request=LLMRequest(
            provider=provider,
            model=model,
            method=request.method,
            path=str(request.url.raw_path, "utf-8") if isinstance(request.url.raw_path, bytes) else str(request.url.raw_path),
            body=body_json,
        )
    )

    start = time.monotonic()
    try:
        response = await original_send(client, request, **kwargs)
    except Exception as e:
        llm_call.latency_ms = (time.monotonic() - start) * 1000
        llm_call.error = str(e)
        if _active_trace:
            _active_trace.add_step(llm_call)
        raise

    llm_call.latency_ms = (time.monotonic() - start) * 1000

    resp_json = None
    try:
        resp_json = response.json()
    except Exception:
        pass

    llm_call.response = LLMResponse(
        status_code=response.status_code,
        body=resp_json,
        is_stream=False,
    )
    if _active_trace:
        _active_trace.add_step(llm_call)

    return response
