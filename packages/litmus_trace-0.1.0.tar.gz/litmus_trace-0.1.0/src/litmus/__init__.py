"""Litmus — Record and deterministically replay AI agent executions."""

__version__ = "0.1.0"

# Primary API — one-liner, no proxy needed
from litmus.patch import record, replay, stop

# Proxy-based API (for advanced use / non-Python agents)
from litmus.sdk import init, shutdown

# Data models
from litmus.models import Trace, Step, LLMCall, ToolCall

# Analysis
from litmus.diff import compare, TraceDiff

# Provider management
from litmus.proxy.server import register_provider

__all__ = [
    # Primary API
    "record", "replay", "stop",
    # Proxy API
    "init", "shutdown",
    # Models
    "Trace", "Step", "LLMCall", "ToolCall",
    # Analysis
    "compare", "TraceDiff",
    # Providers
    "register_provider",
]
