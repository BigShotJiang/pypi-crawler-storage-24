"""Tests for API key redaction in traces."""

from litmus.proxy.server import _sanitize_headers


class TestRedaction:
    def test_redacts_api_key(self):
        headers = {"x-api-key": "sk-ant-abc123", "content-type": "application/json"}
        sanitized = _sanitize_headers(headers)
        assert sanitized["x-api-key"] == "[REDACTED]"
        assert sanitized["content-type"] == "application/json"

    def test_redacts_authorization(self):
        headers = {"Authorization": "Bearer sk-proj-abc123", "accept": "application/json"}
        sanitized = _sanitize_headers(headers)
        assert sanitized["Authorization"] == "[REDACTED]"
        assert sanitized["accept"] == "application/json"

    def test_redacts_google_key(self):
        headers = {"x-goog-api-key": "AIza123", "content-type": "application/json"}
        sanitized = _sanitize_headers(headers)
        assert sanitized["x-goog-api-key"] == "[REDACTED]"

    def test_strips_hop_by_hop(self):
        headers = {"host": "api.anthropic.com", "content-type": "application/json", "connection": "keep-alive"}
        sanitized = _sanitize_headers(headers)
        assert "host" not in sanitized
        assert "connection" not in sanitized
        assert sanitized["content-type"] == "application/json"

    def test_preserves_normal_headers(self):
        headers = {"content-type": "application/json", "anthropic-version": "2023-06-01", "user-agent": "test"}
        sanitized = _sanitize_headers(headers)
        assert sanitized == headers
