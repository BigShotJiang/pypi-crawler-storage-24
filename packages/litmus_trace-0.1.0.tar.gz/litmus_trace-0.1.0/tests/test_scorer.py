"""Tests for reliability scoring."""

import tempfile
from pathlib import Path

from litmus.models import Trace, LLMCall, LLMRequest, LLMResponse, TraceMetadata
from litmus.scorer import score_trace, run_ci


def _make_good_trace():
    trace = Trace(agent_id="test", metadata=TraceMetadata())
    trace.add_step(LLMCall(
        request=LLMRequest(provider="anthropic", model="claude-sonnet-4-20250514", method="POST", path="/v1/messages"),
        response=LLMResponse(
            status_code=200,
            body={"content": [{"type": "text", "text": "result"}], "stop_reason": "end_turn"},
        ),
        latency_ms=500,
    ))
    trace.complete()
    return trace


def _make_error_trace():
    trace = Trace(metadata=TraceMetadata())
    trace.add_step(LLMCall(
        request=LLMRequest(provider="anthropic", model="claude-sonnet-4-20250514", method="POST", path="/v1/messages"),
        response=LLMResponse(status_code=500, body={"error": "internal"}),
        latency_ms=500,
        error="500 Internal Server Error",
    ))
    trace.complete()
    return trace


class TestScorer:
    def test_good_trace_scores_high(self):
        score = score_trace(_make_good_trace())
        assert score.correctness >= 90
        assert score.efficiency >= 90
        assert score.overall >= 70

    def test_error_trace_scores_low(self):
        score = score_trace(_make_error_trace())
        assert score.correctness < 90
        assert len(score.errors) > 0

    def test_empty_trace_scores_zero_correctness(self):
        trace = Trace(metadata=TraceMetadata())
        trace.complete()
        score = score_trace(trace)
        assert score.correctness == 0

    def test_ci_report(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            # Save some traces
            good = _make_good_trace()
            good.save(str(Path(tmpdir) / "good.trace.json"))

            report = run_ci(tmpdir, threshold=50)
            assert report.trace_count == 1
            assert report.passed
            assert report.average_score > 0

    def test_ci_report_to_dict(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            good = _make_good_trace()
            good.save(str(Path(tmpdir) / "good.trace.json"))

            report = run_ci(tmpdir)
            d = report.to_dict()
            assert "passed" in d
            assert "average_score" in d
            assert "traces" in d
            assert len(d["traces"]) == 1
