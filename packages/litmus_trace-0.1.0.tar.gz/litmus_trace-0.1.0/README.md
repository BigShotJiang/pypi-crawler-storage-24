# Litmus

Record and deterministically replay AI agent executions.

## Install

```bash
pip install litmus-trace
```

## Quick Start

```bash
# Start the recording proxy
litmus proxy --mode record

# In another terminal, point your SDK at the proxy and run your agent
ANTHROPIC_BASE_URL=http://localhost:8787/anthropic python my_agent.py

# View the recorded trace
litmus view ./traces/lt-*.trace.json

# Replay it deterministically
litmus replay ./traces/lt-*.trace.json
```

## Or use the Python SDK

```python
import litmus

litmus.init()  # starts proxy, patches env vars
# ... your agent code runs normally ...
litmus.shutdown()  # saves trace
```
