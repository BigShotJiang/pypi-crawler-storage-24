"""A completely vanilla agent — no litmus imports, no instrumentation.
This is what a user's real code looks like. Zero changes needed."""

import anthropic
import json

client = anthropic.Anthropic()

tools = [
    {
        "name": "calculate",
        "description": "Math calculation",
        "input_schema": {
            "type": "object",
            "properties": {"expression": {"type": "string"}},
            "required": ["expression"],
        },
    },
]

messages = [{"role": "user", "content": "What is 99 * 3?"}]

print("Calling Claude...")
response = client.messages.create(
    model="claude-sonnet-4-20250514",
    max_tokens=256,
    tools=tools,
    messages=messages,
)

if response.stop_reason == "tool_use":
    for block in response.content:
        if block.type == "tool_use":
            result = eval(json.loads(json.dumps(block.input))["expression"], {"__builtins__": {}})
            print(f"Tool: {block.name}({block.input}) = {result}")
            messages.append({"role": "assistant", "content": response.content})
            messages.append({"role": "user", "content": [{"type": "tool_result", "tool_use_id": block.id, "content": str(result)}]})

    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=256,
        tools=tools,
        messages=messages,
    )

for block in response.content:
    if hasattr(block, "text"):
        print(f"Answer: {block.text}")
