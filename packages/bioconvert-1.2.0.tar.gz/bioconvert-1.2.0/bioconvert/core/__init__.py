class BioconvertError(Exception):
    pass
