"""
This is the main module of the “Frankenstein” architecture, with features for combining multiple submodels from different architectures that work in a coordinated way to provide responses with a high degree of accuracy.
The current module also includes pre-programmed functions for creating and loading files with the skeleton of the “Frankenstein” (frankenstein.json),
a function for the final assembly of the architecture based on the submodels configured in the “Frankenstein” file,
a function for packaging the submodels into a single closed model, and a function for inference of the generated “Frankenstein” model with the combination of all submodels.

Any alteration, customization, copying, or sharing of this module without prior authorization from Sapiens Technology®️ is strictly prohibited,
as are technical posts, public comments, or any disclosure of the technical information contained herein.
Failure to comply with these rules will result in legal proceedings initiated by our team of lawyers.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
from setuptools import setup, find_packages
package_name = 'FRANKENSTEIN_MODEL'
version = '5.2.9'
setup(
    name=package_name,
    version=version,
    author='SAPIENS TECHNOLOGY',
    packages=find_packages(),
    install_requires=[
        'TTS==0.22.0',
        'torch==2.4.1',
        'torchvision==0.19.1',
        'torchaudio==2.4.1',
        'transformers==4.45.2',
        'megatron-core==0.10.0',
        'paddleocr==2.7.3',
        'paddlepaddle==2.6.2',
        'moviepy==1.0.3',
        'sapiens-frankenstein',
        'sapiens-transformers',
        'utilities-nlp',
        'sapiens-loader',
        'SUBMODELS'
    ],
    url='https://github.com/sapiens-technology/FRANKENSTEIN',
    license='Proprietary Software'
)
"""
This is the main module of the “Frankenstein” architecture, with features for combining multiple submodels from different architectures that work in a coordinated way to provide responses with a high degree of accuracy.
The current module also includes pre-programmed functions for creating and loading files with the skeleton of the “Frankenstein” (frankenstein.json),
a function for the final assembly of the architecture based on the submodels configured in the “Frankenstein” file,
a function for packaging the submodels into a single closed model, and a function for inference of the generated “Frankenstein” model with the combination of all submodels.

Any alteration, customization, copying, or sharing of this module without prior authorization from Sapiens Technology®️ is strictly prohibited,
as are technical posts, public comments, or any disclosure of the technical information contained herein.
Failure to comply with these rules will result in legal proceedings initiated by our team of lawyers.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
