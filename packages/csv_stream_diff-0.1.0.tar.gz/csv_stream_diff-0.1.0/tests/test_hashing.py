from __future__ import annotations

from csvstreamdiff.hashing import NormalizationSettings, normalize_value, stable_bucket_for_key


def test_normalize_value_honors_whitespace_case_and_null_rules() -> None:
    settings = NormalizationSettings(
        case_insensitive=True,
        trim_whitespace=True,
        treat_null_as_equal=True,
    )

    assert normalize_value("  ABC  ", settings) == "abc"
    assert normalize_value("", settings) is None
    assert normalize_value(None, settings) is None


def test_stable_bucket_for_key_is_repeatable() -> None:
    key = ("customer-1", "2026-01-01")
    assert stable_bucket_for_key(key, 64) == stable_bucket_for_key(key, 64)
