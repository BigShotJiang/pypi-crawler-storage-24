# Copyright 2021 Vincent Texier <vit@free.fr>
#
# This software is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
from tikka.domains.entities.currency import Currency
from tikka.interfaces.adapters.network.node.node import NetworkNodeInterface
from tikka.interfaces.adapters.repository.currencies import (
    CurrenciesRepositoryInterface,
)
from tikka.interfaces.adapters.repository.currency import CurrencyRepositoryInterface


class Currencies:
    """
    Currencies domain class
    """

    def __init__(
        self,
        repository: CurrenciesRepositoryInterface,
        currency_repository: CurrencyRepositoryInterface,
        network: NetworkNodeInterface,
        code_name: str,
    ):
        """
        Init Currencies instance

        :param repository: CurrenciesRepositoryInterface instance
        :param currency_repository: CurrencyRepositoryInterface instance
        :param network: NodeCurrencyInterface instance
        :param code_name: Code name of current currency instance
        """
        self.repository = repository
        self.currency_repository = currency_repository
        self.network = network
        self.code_name = code_name

        self.init_currency_repository(self.code_name)

    def init_currency_repository(self, code_name: str):
        """
        Initialize current currency in its repository

        :return:
        """
        currency = self.currency_repository.get(code_name)
        # if first connection on this currency...
        if currency is None:
            # get currency from currencies yaml file
            currency = self.repository.get(code_name)
            if currency is None:
                raise ValueError("code name is unknown")
            self.currency_repository.set(currency)
            self.set_current(code_name)
        else:
            self.set_current(code_name)
            # update hash from currencies list (None -> hash)
            currency.genesis_hash = self.repository.get(  # type: ignore
                self.get_current().code_name
            ).genesis_hash
            self.currency_repository.update(currency)

    def get_current(self) -> Currency:
        """
        Return current Currency instance

        :return:
        """
        currency = self.currency_repository.get(self.code_name)
        assert currency is not None
        return currency

    def set_current(self, code_name: str) -> None:
        """
        Set current Currency instance by code name

        :param code_name: Currency code name
        :return:
        """
        self.code_name = code_name

    def code_names(self) -> list:
        """
        Return list of currency code names

        :return:
        """
        return self.repository.code_names()

    def names(self) -> list:
        """
        Return list of currency names

        :return:
        """
        return self.repository.names()

    def get_entry_point_urls(
        self,
    ) -> dict:
        """
        Return current currency entry point urls

        :return:
        """
        return self.repository.get_entry_point_urls(self.get_current().code_name)

    def network_update_properties(self):
        """
        Get currency properties from network and update currency

        :return:
        """
        currency = self.network.currency.get_instance()
        # patch genesis hash to be able to use test currencies locally
        currency.genesis_hash = self.repository.get(self.code_name).genesis_hash

        self.currency_repository.update(currency)

    def check_genesis_hash(self, hash_to_check: str, code_name: str) -> bool:
        """
        Return True if hash_to_check == currency by code_name genesis hash

        :param hash_to_check: Hash to check
        :param code_name: Currency code name
        :return:
        """
        currency = self.repository.get(code_name)
        # do not check if unknown genesis
        if currency is not None:
            if currency.genesis_hash is None:  # type: ignore
                return True
        else:
            return False

        return hash_to_check == currency.genesis_hash
