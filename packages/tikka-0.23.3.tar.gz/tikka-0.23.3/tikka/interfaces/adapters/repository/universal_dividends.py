# Copyright 2021 Vincent Texier <vit@free.fr>
#
# This software is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import abc
from typing import Any, Dict, List, Optional

from tikka.domains.entities.universal_dividend import UniversalDividend


class UniversalDividendsRepositoryInterface(abc.ABC):
    """
    UniversalDividendsRepositoryInterface class
    """

    COLUMN_ID = "universal_dividend_id"
    COLUMN_ADDRESS = "universal_dividend_address"
    COLUMN_IDENTITY_INDEX = "universal_dividend_identity_index"
    COLUMN_IDENTITY_NAME = "universal_dividend_identity_name"
    COLUMN_AMOUNT = "universal_dividend_amount"
    COLUMN_TIMESTAMP = "universal_dividend_timestamp"

    SORT_ORDER_ASCENDING = "ASC"
    SORT_ORDER_DESCENDING = "DESC"

    @abc.abstractmethod
    def add(self, universal_dividend: UniversalDividend) -> None:
        """
        Add a new Universal Dividend to account history in repository

        :param universal_dividend: UniversalDividend instance
        :return:
        """
        raise NotImplementedError

    @abc.abstractmethod
    def set_history(
        self, address: str, universal_dividends: List[UniversalDividend]
    ) -> None:
        """
        Set account universal_dividends history in repository

        :param address: Account address
        :param universal_dividends: List of UniversalDividend instances
        :return:
        """
        raise NotImplementedError

    @abc.abstractmethod
    def list(
        self,
        address: str,
        filters: Optional[Dict[str, Any]] = None,
        sort_column: str = COLUMN_TIMESTAMP,
        sort_order: str = SORT_ORDER_DESCENDING,
        limit: int = 100,
        offset: int = 0,
    ) -> List[UniversalDividend]:
        """
        List Universal Dividend created for address,
        from repository with optional filters and sort_column

        :param address: Account address
        :param filters: Dict with {column: value} filters or None
        :param sort_column: Sort column constant, default to UniversalDividendsRepositoryInterface.COLUMN_TIMESTAMP
        :param sort_order: Sort order constant UniversalDividendsRepositoryInterface.SORT_ORDER_ASCENDING or SORT_ORDER_DESCENDING
        :param limit: Number of rows to return
        :param offset: Offset of first row to return
        :return:
        """
        raise NotImplementedError

    @abc.abstractmethod
    def delete_by_address(self, address: str) -> None:
        """
        Delete Universal Dividend history for address

        :param address: Account address of history to delete
        :return:
        """
        raise NotImplementedError

    @abc.abstractmethod
    def delete_all(self) -> None:
        """
        Delete all Universal Dividend in repository

        :return:
        """
        raise NotImplementedError

    @abc.abstractmethod
    def count(self, address: str) -> int:
        """
        Return total number of Universal Dividends for address

        :return:
        """
        raise NotImplementedError
