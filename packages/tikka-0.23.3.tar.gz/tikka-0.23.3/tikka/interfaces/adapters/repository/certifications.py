# Copyright 2021 Vincent Texier <vit@free.fr>
#
# This software is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import abc
from typing import Any, Dict, List, Optional

from tikka.domains.entities.identity import Certification


class CertificationsRepositoryInterface(abc.ABC):
    """
    CertificationsRepositoryInterface class
    """

    COLUMN_ID = "certification_id"
    COLUMN_ISSUER_IDENTITY_INDEX = "certification_issuer_identity_index"
    COLUMN_ISSUER_IDENTITY_NAME = "certification_issuer_identity_name"
    COLUMN_ISSUER_IDENTITY_STATUS = "certification_issuer_identity_status"
    COLUMN_ISSUER_ADDRESS = "certification_issuer_address"
    COLUMN_RECEIVER_IDENTITY_INDEX = "certification_receiver_identity_index"
    COLUMN_RECEIVER_IDENTITY_NAME = "certification_receiver_identity_name"
    COLUMN_RECEIVER_IDENTITY_STATUS = "certification_receiver_identity_status"
    COLUMN_RECEIVER_ADDRESS = "certification_receiver_address"
    COLUMN_CREATED_ON = "certification_created_on"
    COLUMN_UPDATED_ON = "certification_updated_on"
    COLUMN_EXPIRE_ON = "certification_expire_on"

    SORT_ORDER_ASCENDING = "ASC"
    SORT_ORDER_DESCENDING = "DESC"

    @abc.abstractmethod
    def set_list(
        self, identity_index: int, certifications: List[Certification]
    ) -> None:
        """
        Set identity certification list in repository

        :param identity_index: Identity index
        :param certifications: List of Certification instances
        :return:
        """
        raise NotImplementedError

    @abc.abstractmethod
    def list(
        self,
        identity_index: int,
        filters: Optional[Dict[str, Any]] = None,
        sort_column: str = COLUMN_CREATED_ON,
        sort_order: str = SORT_ORDER_ASCENDING,
        limit: int = 10,
        offset: int = 0,
    ) -> List[Certification]:
        """
        List certifications from and to identity index, from repository with optional filters and sort_column

        :param identity_index: Identity index
        :param filters: Dict with {column: value} filters or None
        :param sort_column: Sort column constant, default to COLUMN_TIMESTAMP
        :param sort_order: Sort order constant SORT_ORDER_ASCENDING or SORT_ORDER_DESCENDING
        :param limit: Number of rows to return
        :param offset: Offset of first row to return
        :return:
        """
        raise NotImplementedError

    @abc.abstractmethod
    def delete_by_address(self, address: str, exclude: List[str]) -> None:
        """
        Delete certification history issued from or received by address
        (exclude certifications with address in exclude list)

        :param address: Account address of certifications to delete
        :param exclude: List of address to not delete
        :return:
        """
        raise NotImplementedError

    @abc.abstractmethod
    def delete_all(self) -> None:
        """
        Delete all certifications in repository

        :return:
        """
        raise NotImplementedError
