# Copyright 2021 Vincent Texier <vit@free.fr>
#
# This software is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
import os
import shutil
from pathlib import Path

import yaml

from tikka.domains.entities.constants import CURRENCIES_FILENAME, DATA_PATH
from tikka.domains.entities.currency import Currency
from tikka.interfaces.adapters.repository.currencies import (
    CurrenciesRepositoryInterface,
)

ASSETS_PATH = Path(__file__).parent.joinpath("assets")
DEFAULT_CURRENCIES_PATH = ASSETS_PATH.joinpath(CURRENCIES_FILENAME)


class FileCurrenciesRepository(CurrenciesRepositoryInterface):
    """
    FileCurrenciesRepository class
    """

    PARAMETER_NAME = "name"
    PARAMETER_SYMBOL = "symbol"
    PARAMETER_SS58_FORMAT = "ss58_format"
    PARAMETER_ENTRY_POINTS = "entry_points"
    PARAMETER_GENESIS_HASH = "genesis_hash"

    filepath = None

    def __init__(self, path: str):
        """
        Init FileCurrenciesRepository instance

        :param path: Path of directory to load currencies file
        :return:
        """
        if not Path(path).expanduser().exists():
            os.makedirs(Path(DATA_PATH).expanduser())
            path = str(Path(DATA_PATH).expanduser())

        self.filepath = Path(path).joinpath(CURRENCIES_FILENAME).expanduser()

        # copy default currencies in user config path
        shutil.copyfile(DEFAULT_CURRENCIES_PATH.expanduser(), self.filepath)

        with open(
            Path(DEFAULT_CURRENCIES_PATH).expanduser(), "r", encoding="utf-8"
        ) as filehandler:
            self.currencies = yaml.safe_load(filehandler)

    def get(self, code_name: str) -> Currency:
        __doc__ = (  # pylint: disable=redefined-builtin, unused-variable
            FileCurrenciesRepository.get.__doc__
        )
        parameters = self._parameters(code_name)
        return Currency(
            code_name,
            parameters[self.PARAMETER_NAME],
            parameters[self.PARAMETER_SS58_FORMAT],
            token_symbol=parameters[self.PARAMETER_SYMBOL],
            genesis_hash=parameters[self.PARAMETER_GENESIS_HASH],
        )

    def code_names(self) -> list:
        __doc__ = (  # pylint: disable=redefined-builtin, unused-variable
            FileCurrenciesRepository.code_names.__doc__
        )
        return list(self.currencies.keys())

    def names(self) -> list:
        __doc__ = (  # pylint: disable=redefined-builtin, unused-variable
            FileCurrenciesRepository.names.__doc__
        )
        names = []
        for code_name in self.currencies:
            names.append(self.currencies[code_name]["name"])

        return names

    def get_entry_point_urls(self, code_name: str) -> dict:
        """
        Return currency entry point urls

        :param code_name: Currency code name
        :return:
        """
        parameters = self._parameters(code_name)
        return parameters[self.PARAMETER_ENTRY_POINTS]

    def _parameters(self, code_name: str) -> dict:
        """
        Return currency parameters for code name

        :param code_name: Currency code name
        :return:
        """
        return self.currencies[code_name]
