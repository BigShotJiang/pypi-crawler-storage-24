create table datapods (
        url varchar(255) primary key not null,
        block integer default null -- fixme: set type to text to handle big int
);
