create table certifications (
    id varchar(255) unique primary key not null,
    issuer_identity_index integer not null,
    issuer_identity_name varchar(255) not null,
    issuer_identity_status integer not null,
    issuer_address varchar(255) not null,
    receiver_identity_index integer not null,
    receiver_identity_name varchar(255) not null,
    receiver_identity_status integer not null,
    receiver_address varchar(255) not null,
    created_on timestamp not null,
    updated_on timestamp not null,
    expire_on timestamp not null,
    UNIQUE (`issuer_identity_index`,`receiver_identity_index`)
);
