# Copyright 2021 Vincent Texier <vit@free.fr>
#
# This software is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
import logging
import sys
from typing import Optional

from PyQt5.QtGui import QFont, QMovie
from PyQt5.QtWidgets import QApplication, QDialog, QWidget

from tikka.domains.application import Application
from tikka.domains.entities.account import Account
from tikka.domains.entities.constants import DATA_PATH
from tikka.domains.entities.profile import Profile
from tikka.slots.pyqt.entities.constants import ADDRESS_MONOSPACE_FONT_NAME, ICON_LOADER
from tikka.slots.pyqt.entities.event_bus import EventBus
from tikka.slots.pyqt.entities.worker import (
    ThreadManager,
)
from tikka.slots.pyqt.resources.gui.windows.profile_change_account_rc import (
    Ui_ProfileChangeAccountDialog,
)
from tikka.slots.pyqt.windows.account_unlock import AccountUnlockWindow


class ProfileChangeAccountWindow(QDialog, Ui_ProfileChangeAccountDialog):
    """
    ProfileChangeAccountWindow class
    """

    def __init__(
        self,
        application: Application,
        account: Account,
        parent: Optional[QWidget] = None,
    ):
        """
        Init identity change account window

        :param application: Application instance
        :param account: Account owner instance
        :param parent: QWidget instance
        """
        super().__init__(parent=parent)
        self.setupUi(self)

        self.application = application
        self._ = self.application.translator.gettext

        self.event_bus = EventBus.instance()

        self.account = account
        self.destination_account: Optional[Account] = None
        self.destination_profile: Optional[Profile] = None

        # animated loading icon
        self.loader_movie = QMovie(ICON_LOADER)
        self.loader_movie.start()
        self.loaderIconLabel.setMovie(self.loader_movie)
        loader_icon_size_policy = self.loaderIconLabel.sizePolicy()
        loader_icon_size_policy.setRetainSizeWhenHidden(True)
        self.loaderIconLabel.setSizePolicy(loader_icon_size_policy)
        self.loaderIconLabel.hide()

        self.monospace_font = QFont(ADDRESS_MONOSPACE_FONT_NAME)
        self.monospace_font.setStyleHint(QFont.Monospace)
        self.addressValueLabel.setFont(self.monospace_font)

        self.changeAccountButton.setEnabled(False)

        # events
        self.accountComboBox.activated.connect(self.on_account_combobox_index_changed)
        self.changeAccountButton.clicked.connect(self._on_change_account_button_clicked)

        ##############################
        # ASYNC METHODS
        ##############################
        self.thread_manager: ThreadManager = ThreadManager(self)

        self.init_account_combo_box()

    def init_account_combo_box(self) -> None:
        """
        Init combobox with no identity accounts
        Avec séparateur entre noms et adresses
        """
        self.accountComboBox.clear()
        self.accountComboBox.addItem("-", userData=None)

        # Séparer les comptes
        named_accounts = []
        unnamed_accounts = []

        for account in self.application.accounts.get_list():
            profile = self.application.profiles.get(account.address)
            if profile is None:
                if account.name and account.name.strip():
                    named_accounts.append(account)
                else:
                    unnamed_accounts.append(account)

        # Trier
        named_accounts.sort(key=lambda acc: acc.name.lower())  # type: ignore
        unnamed_accounts.sort(key=lambda acc: acc.address.lower())

        # Ajouter les comptes avec nom
        if named_accounts:
            for account in named_accounts:
                self.accountComboBox.addItem(
                    f"{account.address} - {account.name}",
                    userData=account.address,
                )

            # Ajouter un séparateur si on a les deux catégories
            if unnamed_accounts:
                self.accountComboBox.insertSeparator(len(named_accounts) + 1)

        # Ajouter les comptes sans nom
        for account in unnamed_accounts:
            self.accountComboBox.addItem(
                account.address,
                userData=account.address,
            )

    def on_account_combobox_index_changed(self):
        """
        Triggered when account selection is changed

        :return:
        """
        destination_address = self.accountComboBox.currentData()
        self.destination_account = self.application.accounts.get_by_address(
            destination_address
        )
        self.update_ui()

    def update_ui(self):
        """
        Update UI fields

        :return:
        """
        self.addressValueLabel.setText(self.destination_account.address or "")
        self.changeAccountButton.setEnabled(
            self.accountComboBox.currentData() is not None
        )

        if self.destination_profile is not None:
            if "title" in self.destination_profile.data:
                self.profileValueLabel.setText(self.destination_profile.data["title"])
            else:
                self.profileValueLabel.setText(self._("Yes"))
        else:
            self.profileValueLabel.setText("")

    def _on_change_account_button_clicked(self):
        """
        Run when use click change account button

        :return:
        """
        if self.destination_account is None:
            self.errorLabel.setStyleSheet("color: red;")
            self.errorLabel.setText(self._("No account selected"))
            return

        if not self.application.wallets.is_unlocked(self.account.address):
            # ask password...
            dialog_code = AccountUnlockWindow(
                self.application, self.account, self
            ).exec_()
            if dialog_code == QDialog.Rejected:
                return

        if not self.application.wallets.is_unlocked(self.destination_account.address):
            # ask password...
            dialog_code = AccountUnlockWindow(
                self.application, self.destination_account, self
            ).exec_()
            if dialog_code == QDialog.Rejected:
                return

        self.loaderIconLabel.show()
        self.changeAccountButton.setDisabled(True)
        self.thread_manager.start(
            self.network_change_account, self._on_finished_network_change_account
        )

    def network_change_account(self):
        """
        Change owner account for identity on the network

        :return:
        """
        if self.destination_account is not None:
            source_profile = self.application.profiles.get(self.account.address)
            try:
                self.application.profiles.network_add(
                    self.application.wallets.get_keypair(
                        self.destination_account.address
                    ),
                    source_profile,
                )
            except Exception as exception:
                self.errorLabel.setStyleSheet("color: red;")
                self.errorLabel.setText(str(exception))
                logging.exception(exception)

            try:
                self.application.profiles.network_delete(
                    self.application.wallets.get_keypair(self.account.address)
                )
            except Exception as exception:
                self.errorLabel.setStyleSheet("color: red;")
                self.errorLabel.setText(str(exception))
                logging.exception(exception)

            try:
                self.application.profiles.network_update(self.account)
            except Exception as exception:
                logging.exception(exception)

            try:
                self.application.profiles.network_update(self.destination_account)
            except Exception as exception:
                logging.exception(exception)

    def _on_finished_network_change_account(self):
        """
        When async network_change_account is finished

        :return:
        """
        self.destination_profile = self.application.profiles.get(
            self.destination_account.address
        )
        self.loaderIconLabel.hide()
        self.update_ui()
        if self.destination_profile is not None:
            self.errorLabel.setStyleSheet("color: green;")
            self.errorLabel.setText(
                self._(
                    "Profile from {issuer_address} moved to {receiver_address}"
                ).format(
                    issuer_address=self.account.address,
                    receiver_address=self.destination_account.address,
                )
            )
            self.init_account_combo_box()
            self.changeAccountButton.setEnabled(False)
            self.event_bus.profile_account_changed.emit(
                self.account, self.destination_account
            )
            logging.debug(
                "profile_account_changed signal emitted from profile_change_account window %s -> #%s",
                self.account.address,
                self.destination_account.address,
            )
        else:
            self.changeAccountButton.setEnabled(True)


if __name__ == "__main__":
    qapp = QApplication(sys.argv)
    application_ = Application(DATA_PATH)
    account_ = Account("xxxx")
    ProfileChangeAccountWindow(application_, account_).exec_()
