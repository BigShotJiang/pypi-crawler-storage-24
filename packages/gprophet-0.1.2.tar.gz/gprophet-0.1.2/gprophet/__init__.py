"""
G-Prophet Python SDK
Official Python client for the G-Prophet External API.

Usage:
    from gprophet import GProphet

    client = GProphet(api_key="gp_sk_...")
    result = client.predict("AAPL", market="US", days=7)
    print(result)
"""

from gprophet.client import GProphet

__version__ = "0.1.2"
__all__ = ["GProphet", "__version__"]
