"""
reqsync.differ
~~~~~~~~~~~~~~
Compares what the code imports against what requirements.txt declares
and produces a structured DiffResult.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set

from .scanner import ScanResult, scan_imports
from .resolver import RequirementsFile, parse_requirements, resolve_packages, _normalise


@dataclass
class MissingPackage:
    """Imported in code but absent from requirements.txt."""
    import_name: str
    pip_name: str
    locations: list  # List[ImportLocation]


@dataclass
class UnusedPackage:
    """In requirements.txt but never imported in code."""
    pip_name: str
    version_spec: str
    line_no: int


@dataclass
class UnpinnedPackage:
    """In requirements.txt but has no version constraint."""
    pip_name: str
    line_no: int


@dataclass
class DiffResult:
    missing: List[MissingPackage] = field(default_factory=list)
    unused: List[UnusedPackage] = field(default_factory=list)
    unpinned: List[UnpinnedPackage] = field(default_factory=list)
    ok_count: int = 0
    scan: Optional[ScanResult] = None
    req_file: Optional[RequirementsFile] = None

    @property
    def is_clean(self) -> bool:
        return not self.missing and not self.unused

    def summary(self) -> str:
        parts = []
        if self.missing:
            parts.append(f"{len(self.missing)} missing")
        if self.unused:
            parts.append(f"{len(self.unused)} unused")
        if self.unpinned:
            parts.append(f"{len(self.unpinned)} unpinned")
        if self.ok_count:
            parts.append(f"{self.ok_count} ok")
        return " · ".join(parts) if parts else "all good"


def diff(
    root: str | Path = ".",
    req_file: str | Path = "requirements.txt",
    *,
    include_tests: bool = True,
    exclude_dirs: Set[str] | None = None,
    warn_unpinned: bool = True,
) -> DiffResult:
    """
    Scan *root* for imports and compare against *req_file*.

    Parameters
    ----------
    root : path-like
        Project root to scan.
    req_file : path-like
        Path to requirements file (default: requirements.txt).
    include_tests : bool
        Include test directories in the scan.
    exclude_dirs : set[str], optional
        Extra directory names to skip.
    warn_unpinned : bool
        Report packages in requirements.txt that have no version pin.

    Returns
    -------
    DiffResult
    """
    root = Path(root)
    scan = scan_imports(root, include_tests=include_tests, exclude_dirs=exclude_dirs)
    rf = parse_requirements(Path(root) / req_file if not Path(req_file).is_absolute() else req_file)

    # Resolve import names → pip names
    third_party = scan.third_party
    resolved: Dict[str, str] = {}
    mapping = resolve_packages(third_party)
    for import_name, pip_name in mapping.items():
        if pip_name:
            resolved[import_name] = _normalise(pip_name)

    # Names actually declared in requirements (normalised)
    declared: Set[str] = rf.names

    # Imported pip names (normalised)
    imported_pip: Set[str] = set(resolved.values())

    result = DiffResult(scan=scan, req_file=rf)

    # ── Missing: imported but not declared ────────────────────────────────────
    for import_name, pip_name in resolved.items():
        if pip_name not in declared:
            result.missing.append(MissingPackage(
                import_name=import_name,
                pip_name=pip_name,
                locations=scan.imports.get(import_name, []),
            ))

    # ── Unused: declared but never imported ───────────────────────────────────
    for norm_name, req in rf.requirements.items():
        if norm_name not in imported_pip:
            result.unused.append(UnusedPackage(
                pip_name=req.raw_name,
                version_spec=req.version_spec,
                line_no=req.line_no,
            ))

    # ── Unpinned: declared but no version spec ────────────────────────────────
    if warn_unpinned:
        for norm_name, req in rf.requirements.items():
            if not req.version_spec:
                result.unpinned.append(UnpinnedPackage(
                    pip_name=req.raw_name,
                    line_no=req.line_no,
                ))

    # ── OK count ──────────────────────────────────────────────────────────────
    result.ok_count = len(declared) - len(result.unused)

    return result
