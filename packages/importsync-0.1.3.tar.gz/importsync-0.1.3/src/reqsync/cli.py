"""
reqsync CLI
~~~~~~~~~~~
Commands:
  reqsync check           — show diff between imports and requirements.txt
  reqsync fix             — auto-update requirements.txt
  reqsync fix --dry-run   — preview changes without writing
  reqsync scan            — list all third-party imports found in code
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .differ import diff
from .fixer import fix
from .reporter import print_diff, print_fix_result
from .scanner import scan_imports


def cmd_check(args: argparse.Namespace) -> int:
    result = diff(
        root=args.root,
        req_file=args.req,
        include_tests=not args.no_tests,
        warn_unpinned=not args.no_unpinned,
    )
    print_diff(result, show_locations=args.locations)
    return 0 if result.is_clean else 1


def cmd_fix(args: argparse.Namespace) -> int:
    result = diff(
        root=args.root,
        req_file=args.req,
        include_tests=not args.no_tests,
    )
    changes = fix(
        result=result,
        root=args.root,
        req_file=args.req,
        add_missing=True,
        remove_unused=args.remove_unused,
        pin_versions=args.pin,
        dry_run=args.dry_run,
    )
    print_fix_result(changes)
    return 0


def cmd_scan(args: argparse.Namespace) -> int:
    result = scan_imports(
        root=args.root,
        include_tests=not args.no_tests,
    )
    third = sorted(result.third_party)
    print(f"\n  Found {len(third)} third-party import(s) in {args.root}:\n")
    for name in third:
        locs = result.imports[name]
        files = sorted({l.file for l in locs})
        print(f"    {name}  ({len(locs)} import(s) across {len(files)} file(s))")
    if result.errors:
        print(f"\n  Skipped {len(result.errors)} file(s) due to parse errors.")
    print()
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="reqsync",
        description="Keep requirements.txt in sync with what your code imports.",
    )
    parser.add_argument(
        "--root", default=".", metavar="DIR",
        help="Project root to scan (default: current directory)",
    )
    parser.add_argument(
        "--req", default="requirements.txt", metavar="FILE",
        help="Requirements file path (default: requirements.txt)",
    )
    parser.add_argument(
        "--no-tests", action="store_true",
        help="Exclude test directories from the scan",
    )

    sub = parser.add_subparsers(dest="command", required=True)

    # ── check ─────────────────────────────────────────────────────────────────
    p_check = sub.add_parser("check", help="Show diff between imports and requirements.txt")
    p_check.add_argument("--locations", action="store_true",
                         help="Show file:line for each missing import")
    p_check.add_argument("--no-unpinned", action="store_true",
                         help="Skip unpinned package warnings")
    p_check.set_defaults(func=cmd_check)

    # ── fix ───────────────────────────────────────────────────────────────────
    p_fix = sub.add_parser("fix", help="Auto-update requirements.txt")
    p_fix.add_argument("--dry-run", action="store_true",
                       help="Preview changes without writing")
    p_fix.add_argument("--remove-unused", action="store_true",
                       help="Also remove packages not imported anywhere (use with care)")
    p_fix.add_argument("--pin", action="store_true",
                       help="Pin added packages to installed version (e.g. requests>=2.31.0)")
    p_fix.set_defaults(func=cmd_fix)

    # ── scan ──────────────────────────────────────────────────────────────────
    p_scan = sub.add_parser("scan", help="List all third-party imports found in code")
    p_scan.set_defaults(func=cmd_scan)

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    sys.exit(args.func(args))


if __name__ == "__main__":
    main()
