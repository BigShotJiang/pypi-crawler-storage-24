"""
reqsync.scanner
~~~~~~~~~~~~~~~
Walks a project directory, parses every .py file with the AST,
and returns the set of top-level package names that are imported.
"""

from __future__ import annotations

import ast
import os
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Set


# Packages that are part of the Python standard library.
# We build this set at runtime so it's always accurate for the running interpreter.
_STDLIB: Set[str] = set(sys.stdlib_module_names) if hasattr(sys, "stdlib_module_names") else set()

# Supplement for Python < 3.10 that lacks sys.stdlib_module_names
_STDLIB_FALLBACK = {
    "abc", "ast", "asyncio", "base64", "builtins", "collections", "concurrent",
    "contextlib", "copy", "csv", "dataclasses", "datetime", "decimal", "difflib",
    "email", "enum", "functools", "gc", "glob", "gzip", "hashlib", "heapq",
    "hmac", "html", "http", "importlib", "inspect", "io", "itertools", "json",
    "keyword", "linecache", "locale", "logging", "math", "multiprocessing",
    "operator", "os", "pathlib", "pickle", "platform", "pprint", "queue",
    "random", "re", "shutil", "signal", "socket", "sqlite3", "ssl", "stat",
    "string", "struct", "subprocess", "sys", "tempfile", "textwrap", "threading",
    "time", "timeit", "traceback", "types", "typing", "unicodedata", "unittest",
    "urllib", "uuid", "warnings", "weakref", "xml", "xmlrpc", "zipfile", "zlib",
    "__future__", "_thread", "argparse", "codecs", "configparser", "ctypes",
    "curses", "dbm", "dis", "doctest", "encodings", "fileinput", "fnmatch",
    "fractions", "ftplib", "getopt", "getpass", "gettext", "grp", "imaplib",
    "ipaddress", "lzma", "mailbox", "mimetypes", "mmap", "netrc", "nis",
    "nntplib", "numbers", "optparse", "ossaudiodev", "parser", "pdb", "pickletools",
    "pipes", "pkgutil", "poplib", "posix", "posixpath", "pstats", "pty", "pwd",
    "py_compile", "pyclbr", "pydoc", "readline", "resource", "rlcompleter",
    "runpy", "sched", "secrets", "select", "selectors", "shelve", "shlex",
    "smtpd", "smtplib", "sndhdr", "spwd", "statistics", "sunau", "symtable",
    "sysconfig", "syslog", "tabnanny", "tarfile", "telnetlib", "termios", "test",
    "token", "tokenize", "trace", "tracemalloc", "tty", "turtle", "turtledemo",
    "uu", "venv", "wave", "webbrowser", "wsgiref", "xdrlib", "zoneinfo",
}

if not _STDLIB:
    _STDLIB = _STDLIB_FALLBACK


@dataclass
class ImportLocation:
    file: str
    line: int
    name: str


@dataclass
class ScanResult:
    """Everything the scanner found about a project's imports."""
    # top-level package name → list of locations where it's imported
    imports: Dict[str, List[ImportLocation]] = field(default_factory=dict)
    # files that failed to parse
    errors: List[str] = field(default_factory=list)

    @property
    def package_names(self) -> Set[str]:
        return set(self.imports.keys())

    @property
    def third_party(self) -> Set[str]:
        """Imports that are not stdlib and not relative."""
        return {k for k in self.imports if k not in _STDLIB}


def _top_level(module: str) -> str:
    """'google.cloud.bigquery' → 'google'"""
    return module.split(".")[0]


def _extract_imports(tree: ast.AST, filepath: str) -> List[ImportLocation]:
    locations: List[ImportLocation] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                name = _top_level(alias.name)
                if name:
                    locations.append(ImportLocation(filepath, node.lineno, name))
        elif isinstance(node, ast.ImportFrom):
            if node.module and node.level == 0:   # skip relative imports
                name = _top_level(node.module)
                if name:
                    locations.append(ImportLocation(filepath, node.lineno, name))
    return locations


def scan_imports(
    root: str | Path = ".",
    *,
    exclude_dirs: Set[str] | None = None,
    include_tests: bool = True,
) -> ScanResult:
    """
    Walk *root* and return a ScanResult of every import found.

    Parameters
    ----------
    root : path-like
        Project root to scan (default: current directory).
    exclude_dirs : set[str], optional
        Directory names to skip. Defaults: {'.git', '.venv', 'venv', '__pycache__',
        'node_modules', '.tox', 'dist', 'build', '.eggs', 'site-packages'}.
    include_tests : bool
        If False, skip directories named 'tests' or 'test'.
    """
    root = Path(root).resolve()
    default_excludes = {
        ".git", ".venv", "venv", "env", "__pycache__",
        "node_modules", ".tox", "dist", "build", ".eggs",
        "site-packages", ".mypy_cache", ".pytest_cache",
    }
    excluded = (exclude_dirs or set()) | default_excludes
    if not include_tests:
        excluded |= {"tests", "test"}

    result = ScanResult()

    for dirpath, dirnames, filenames in os.walk(root):
        # Prune excluded dirs in-place so os.walk skips them
        dirnames[:] = [d for d in dirnames if d not in excluded]

        for filename in filenames:
            if not filename.endswith(".py"):
                continue
            filepath = os.path.join(dirpath, filename)
            rel = os.path.relpath(filepath, root)
            try:
                source = Path(filepath).read_text(encoding="utf-8", errors="replace")
                tree = ast.parse(source, filename=filepath)
            except SyntaxError as e:
                result.errors.append(f"{rel}: SyntaxError at line {e.lineno}")
                continue
            except Exception as e:
                result.errors.append(f"{rel}: {e}")
                continue

            for loc in _extract_imports(tree, rel):
                result.imports.setdefault(loc.name, []).append(loc)

    return result
