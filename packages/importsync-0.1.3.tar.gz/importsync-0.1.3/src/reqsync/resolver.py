"""
reqsync.resolver
~~~~~~~~~~~~~~~~
Two jobs:
  1. Read and parse requirements.txt (or any req file).
  2. Map import names → installed pip package names via importlib.metadata.
     (e.g. import "PIL" → package "Pillow", import "cv2" → "opencv-python")
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Optional, Set

try:
    from importlib.metadata import packages_distributions, PackageNotFoundError
    _HAS_METADATA = True
except ImportError:
    _HAS_METADATA = False


# ── Requirements file parsing ─────────────────────────────────────────────────

# Regex for a valid requirement line (ignores comments, options, URLs)
_REQ_LINE = re.compile(
    r"^\s*(?P<name>[A-Za-z0-9]([A-Za-z0-9._-]*[A-Za-z0-9])?)"
    r"(?P<extras>\[[^\]]+\])?"
    r"(?P<spec>[^;#\n]*)"
    r"(?P<marker>[;][^#\n]*)?"
)


@dataclass
class Requirement:
    name: str           # normalised (lower, hyphens)
    raw_name: str       # as written in the file
    version_spec: str   # e.g. ">=2.0,<3"
    line_no: int
    raw_line: str


@dataclass
class RequirementsFile:
    path: str
    requirements: Dict[str, Requirement] = field(default_factory=dict)  # normalised name → Req
    skipped_lines: list = field(default_factory=list)

    @property
    def names(self) -> Set[str]:
        return set(self.requirements.keys())


def _normalise(name: str) -> str:
    """PEP 503 normalisation: lower-case, replace [-_.] with '-'."""
    return re.sub(r"[-_.]+", "-", name).lower()


def parse_requirements(path: str | Path = "requirements.txt") -> RequirementsFile:
    """Parse a requirements file and return a RequirementsFile."""
    path = Path(path)
    rf = RequirementsFile(path=str(path))

    if not path.exists():
        return rf

    for lineno, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        line = raw.strip()
        # skip blank, comments, options flags (-r, -c, --index-url …)
        if not line or line.startswith("#") or line.startswith("-"):
            rf.skipped_lines.append((lineno, raw))
            continue
        # skip VCS / URL requirements
        if re.match(r"(git\+|https?://|file://)", line, re.I):
            rf.skipped_lines.append((lineno, raw))
            continue

        m = _REQ_LINE.match(line)
        if not m:
            rf.skipped_lines.append((lineno, raw))
            continue

        raw_name = m.group("name")
        norm = _normalise(raw_name)
        spec = (m.group("spec") or "").strip()
        rf.requirements[norm] = Requirement(
            name=norm,
            raw_name=raw_name,
            version_spec=spec,
            line_no=lineno,
            raw_line=raw,
        )

    return rf


# ── Import → package name mapping ─────────────────────────────────────────────

# Hand-curated overrides for packages whose import name ≠ pip name.
# Format: import_name (lowercase) → pip package name (normalised)
_IMPORT_TO_PKG: Dict[str, str] = {
    "PIL":            "pillow",
    "pil":            "pillow",
    "cv2":            "opencv-python",
    "sklearn":        "scikit-learn",
    "skimage":        "scikit-image",
    "bs4":            "beautifulsoup4",
    "yaml":           "pyyaml",
    "dotenv":         "python-dotenv",
    "dateutil":       "python-dateutil",
    "Crypto":         "pycryptodome",
    "crypto":         "pycryptodome",
    "gi":             "pygobject",
    "wx":             "wxpython",
    "usb":            "pyusb",
    "serial":         "pyserial",
    "OpenSSL":        "pyopenssl",
    "openssl":        "pyopenssl",
    "magic":          "python-magic",
    "pkg_resources":  "setuptools",
    "attr":           "attrs",
    "google.cloud":   "google-cloud",
    "MySQLdb":        "mysqlclient",
    "psycopg2":       "psycopg2-binary",
    "jwt":            "pyjwt",
    "docx":           "python-docx",
    "pptx":           "python-pptx",
    "xlrd":           "xlrd",
    "openpyxl":       "openpyxl",
    "tzlocal":        "tzlocal",
    "nacl":           "pynacl",
    "paramiko":       "paramiko",
    "flask":          "flask",
    "django":         "django",
    "fastapi":        "fastapi",
    "starlette":      "starlette",
    "aiohttp":        "aiohttp",
    "httpx":          "httpx",
    "requests":       "requests",
    "numpy":          "numpy",
    "pandas":         "pandas",
    "matplotlib":     "matplotlib",
    "scipy":          "scipy",
    "tensorflow":     "tensorflow",
    "torch":          "torch",
    "transformers":   "transformers",
    "anthropic":      "anthropic",
    "openai":         "openai",
    "rich":           "rich",
    "typer":          "typer",
    "click":          "click",
    "tqdm":           "tqdm",
    "loguru":         "loguru",
    "icecream":       "icecream",
    "pydantic":       "pydantic",
    "sqlalchemy":     "sqlalchemy",
    "alembic":        "alembic",
    "celery":         "celery",
    "redis":          "redis",
    "pymongo":        "pymongo",
    "boto3":          "boto3",
    "botocore":       "botocore",
    "pytest":         "pytest",
    "hypothesis":     "hypothesis",
    "mypy":           "mypy",
    "black":          "black",
    "ruff":           "ruff",
}


def _build_metadata_map() -> Dict[str, str]:
    """
    Use importlib.metadata.packages_distributions() to build a mapping of
    importable top-level names → pip package names.
    Returns {} if metadata is unavailable.
    """
    if not _HAS_METADATA:
        return {}
    try:
        dist_map = packages_distributions()  # {import_name: [dist_name, ...]}
        return {k.lower(): _normalise(v[0]) for k, v in dist_map.items() if v}
    except Exception:
        return {}


def resolve_packages(import_names: Set[str]) -> Dict[str, Optional[str]]:
    """
    Given a set of import names (top-level), return a dict mapping each to its
    pip package name (normalised), or None if we can't determine it.

    Resolution order:
      1. Hand-curated override table
      2. importlib.metadata live environment scan
      3. Fall back to the import name itself (lower-cased, _ → -)
    """
    meta_map = _build_metadata_map()
    result: Dict[str, Optional[str]] = {}

    for name in import_names:
        lower = name.lower()
        if lower in _IMPORT_TO_PKG:
            result[name] = _normalise(_IMPORT_TO_PKG[lower])
        elif lower in meta_map:
            result[name] = meta_map[lower]
        else:
            # Best-effort: treat import name as package name
            result[name] = _normalise(name.replace("_", "-"))

    return result
