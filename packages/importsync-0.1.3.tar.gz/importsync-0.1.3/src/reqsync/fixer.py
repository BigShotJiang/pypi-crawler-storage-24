"""
reqsync.fixer
~~~~~~~~~~~~~
Rewrites requirements.txt to match what the code actually imports.
Preserves comments, ordering, and existing version pins.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path
from typing import Optional

from .differ import DiffResult, diff


def _get_installed_version(pip_name: str) -> Optional[str]:
    """Try to get the currently installed version of a package."""
    try:
        from importlib.metadata import version, PackageNotFoundError
        return version(pip_name)
    except Exception:
        return None


def fix(
    result: Optional[DiffResult] = None,
    *,
    root: str | Path = ".",
    req_file: str | Path = "requirements.txt",
    add_missing: bool = True,
    remove_unused: bool = False,
    pin_versions: bool = False,
    dry_run: bool = False,
) -> dict:
    """
    Update requirements.txt based on a DiffResult.

    Parameters
    ----------
    result : DiffResult, optional
        Pre-computed diff. If None, runs diff() automatically.
    root : path-like
        Project root (used if result is None).
    req_file : path-like
        Path to requirements file.
    add_missing : bool
        Add packages that are imported but missing from requirements.txt.
    remove_unused : bool
        Remove packages declared but never imported (careful — may include
        indirect deps or CLI tools). Default False for safety.
    pin_versions : bool
        When adding missing packages, try to pin to the installed version.
    dry_run : bool
        Print what would change without writing anything.

    Returns
    -------
    dict with keys: added (list), removed (list), unchanged (int)
    """
    if result is None:
        result = diff(root=root, req_file=req_file)

    req_path = (
        Path(req_file) if Path(req_file).is_absolute()
        else Path(root) / req_file
    )

    # Read existing lines (preserving comments/blanks)
    if req_path.exists():
        lines = req_path.read_text(encoding="utf-8").splitlines()
    else:
        lines = []

    added = []
    removed = []

    # ── Build set of lines to remove ─────────────────────────────────────────
    lines_to_remove: set[int] = set()
    if remove_unused:
        unused_names = {u.pip_name.lower() for u in result.unused}
        for i, line in enumerate(lines):
            stripped = line.strip()
            if stripped and not stripped.startswith("#"):
                pkg = stripped.split("==")[0].split(">=")[0].split("<=")[0].split("!=")[0].split("~=")[0].strip()
                if pkg.lower() in unused_names:
                    lines_to_remove.add(i)
                    removed.append(pkg)

    # ── Build lines to add ───────────────────────────────────────────────────
    new_lines = []
    if add_missing:
        for m in result.missing:
            if pin_versions:
                ver = _get_installed_version(m.pip_name)
                entry = f"{m.pip_name}>={ver}" if ver else m.pip_name
            else:
                entry = m.pip_name
            new_lines.append(entry)
            added.append(entry)

    # ── Apply changes ─────────────────────────────────────────────────────────
    final_lines = [l for i, l in enumerate(lines) if i not in lines_to_remove]
    if new_lines:
        if final_lines and final_lines[-1].strip():
            final_lines.append("")   # blank line before additions
        final_lines.extend(new_lines)

    output = "\n".join(final_lines)
    if final_lines:
        output += "\n"

    if dry_run:
        return {"added": added, "removed": removed, "unchanged": result.ok_count, "dry_run": True}

    req_path.write_text(output, encoding="utf-8")
    return {"added": added, "removed": removed, "unchanged": result.ok_count}
