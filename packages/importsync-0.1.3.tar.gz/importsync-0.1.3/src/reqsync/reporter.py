"""
reqsync.reporter
~~~~~~~~~~~~~~~~
Renders DiffResult to the terminal with ANSI color (no dependencies).
"""

from __future__ import annotations

import sys
from .differ import DiffResult


def _color() -> bool:
    try:
        return sys.stdout.isatty()
    except Exception:
        return False


C = _color()
G  = "\033[32m" if C else ""   # green
R  = "\033[31m" if C else ""   # red
Y  = "\033[33m" if C else ""   # yellow
B  = "\033[34m" if C else ""   # blue
CY = "\033[36m" if C else ""   # cyan
DM = "\033[2m"  if C else ""   # dim
BD = "\033[1m"  if C else ""   # bold
RS = "\033[0m"  if C else ""   # reset


def print_diff(result: DiffResult, *, show_locations: bool = False) -> None:
    """Print a human-readable diff report to stdout."""
    req_path = result.req_file.path if result.req_file else "requirements.txt"

    print(f"\n{BD}{CY}reqsync{RS}  {DM}{req_path}{RS}")
    print(f"{DM}{'─' * 44}{RS}")

    # ── Missing ───────────────────────────────────────────────────────────────
    if result.missing:
        print(f"\n  {R}{BD}Missing{RS}  {DM}(imported in code, not in requirements){RS}")
        for m in sorted(result.missing, key=lambda x: x.pip_name):
            locs = result.scan.imports.get(m.import_name, []) if result.scan else []
            loc_str = ""
            if show_locations and locs:
                sample = locs[0]
                loc_str = f"  {DM}← {sample.file}:{sample.line}{RS}"
            print(f"    {R}+{RS} {m.pip_name}{DM} (import {m.import_name}){RS}{loc_str}")
    else:
        print(f"\n  {G}✔{RS}  No missing packages")

    # ── Unused ────────────────────────────────────────────────────────────────
    if result.unused:
        print(f"\n  {Y}{BD}Unused{RS}  {DM}(in requirements, never imported){RS}")
        for u in sorted(result.unused, key=lambda x: x.pip_name):
            spec = u.version_spec or "(no pin)"
            print(f"    {Y}-{RS} {u.pip_name}  {DM}{spec}  line {u.line_no}{RS}")
    else:
        print(f"  {G}✔{RS}  No unused packages")

    # ── Unpinned ──────────────────────────────────────────────────────────────
    if result.unpinned:
        print(f"\n  {B}{BD}Unpinned{RS}  {DM}(no version constraint){RS}")
        for u in sorted(result.unpinned, key=lambda x: x.pip_name):
            print(f"    {B}~{RS} {u.pip_name}  {DM}line {u.line_no}{RS}")

    # ── Parse errors ──────────────────────────────────────────────────────────
    if result.scan and result.scan.errors:
        print(f"\n  {Y}{BD}Parse errors{RS}  {DM}(skipped){RS}")
        for e in result.scan.errors:
            print(f"    {DM}! {e}{RS}")

    # ── Summary ───────────────────────────────────────────────────────────────
    print(f"\n{DM}{'─' * 44}{RS}")
    summary = result.summary()
    color = G if result.is_clean else R
    print(f"  {color}{BD}{summary}{RS}\n")


def print_fix_result(changes: dict) -> None:
    """Print the result of a fix() call."""
    print(f"\n{BD}{CY}reqsync fix{RS}")
    print(f"{DM}{'─' * 44}{RS}\n")

    dry = changes.get("dry_run", False)
    label = f"{DM}(dry run){RS}" if dry else ""

    if changes["added"]:
        for pkg in changes["added"]:
            print(f"  {G}+{RS} {pkg}  {label}")
    if changes["removed"]:
        for pkg in changes["removed"]:
            print(f"  {R}-{RS} {pkg}  {label}")
    if not changes["added"] and not changes["removed"]:
        print(f"  {G}✔{RS}  Nothing to change")

    print()
