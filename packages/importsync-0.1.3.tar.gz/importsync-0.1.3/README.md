# importsync

> Keep `requirements.txt` in sync with what your code actually imports.

`importsync` scans every `.py` file in your project using Python's AST parser, figures out which third-party packages you import, and cross-references that against your `requirements.txt` — showing you what's **missing**, **unused**, or **unpinned**.

Zero runtime dependencies. Works on any Python 3.8+ project.

---

## Install

```bash
pip install importsync
```

---

## Usage

### Check for drift
```bash
importsync check
```



### Show file locations of missing imports
```bash
importsync check --locations
```

### Fix — add missing packages automatically
```bash
importsync fix
```

### Preview what fix would do (no writes)
```bash
importsync fix --dry-run
```

### Fix and pin to installed versions
```bash
importsync fix --pin
```

### Also remove unused packages (careful — may include transitive deps)
```bash
importsync fix --remove-unused
```

### See all third-party imports found in the project
```bash
importsync scan
```




## How it works

1. **Scan** — walks all `.py` files and extracts every `import` and `from ... import` statement using `ast.parse()` 
2. **Resolve** — maps import names to pip package names 
3. **Diff** — compares the resolved set against your `requirements.txt`.
4. **Fix** — rewrites `requirements.txt`, preserving comments and existing pins.

---

## Options reference

| Flag | Command | Description |
|---|---|---|
| `--root DIR` | all | Project root to scan (default: `.`) |
| `--req FILE` | all | Requirements file (default: `requirements.txt`) |
| `--no-tests` | all | Exclude `tests/` directories |
| `--locations` | check | Show file:line for each missing import |
| `--no-unpinned` | check | Hide unpinned warnings |
| `--dry-run` | fix | Preview without writing |
| `--pin` | fix | Pin to installed version when adding |
| `--remove-unused` | fix | Remove unused entries (use with care) |

---

## License

MIT
