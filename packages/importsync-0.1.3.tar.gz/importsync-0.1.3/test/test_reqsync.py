"""
Tests for reqsync.
Run with: pytest tests/ -v
"""

import os
import sys
import textwrap
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from reqsync.scanner import scan_imports, _STDLIB
from reqsync.resolver import parse_requirements, resolve_packages, _normalise
from reqsync.differ import diff
from reqsync.fixer import fix


# ── Helpers ───────────────────────────────────────────────────────────────────

def make_project(files: dict, tmp_path: Path) -> Path:
    """Write a dict of {rel_path: content} to a temp directory."""
    for rel, content in files.items():
        p = tmp_path / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(textwrap.dedent(content))
    return tmp_path


# ── Scanner ───────────────────────────────────────────────────────────────────

class TestScanner:
    def test_basic_imports(self, tmp_path):
        make_project({"app.py": """
            import requests
            import os
            from pathlib import Path
            from flask import Flask
        """}, tmp_path)
        result = scan_imports(tmp_path)
        assert "requests" in result.third_party
        assert "flask" in result.third_party
        assert "os" not in result.third_party     # stdlib
        assert "pathlib" not in result.third_party  # stdlib

    def test_relative_imports_excluded(self, tmp_path):
        make_project({"pkg/__init__.py": "", "pkg/mod.py": """
            from . import utils
            from .utils import helper
        """}, tmp_path)
        result = scan_imports(tmp_path)
        assert "utils" not in result.imports

    def test_nested_package(self, tmp_path):
        make_project({"app.py": "from google.cloud import bigquery"}, tmp_path)
        result = scan_imports(tmp_path)
        assert "google" in result.third_party

    def test_syntax_error_file_is_skipped(self, tmp_path):
        make_project({"bad.py": "def f(: pass"}, tmp_path)
        result = scan_imports(tmp_path)
        assert len(result.errors) == 1
        assert "bad.py" in result.errors[0]

    def test_venv_excluded(self, tmp_path):
        make_project({
            "app.py": "import requests",
            ".venv/lib/site.py": "import hidden_pkg",
        }, tmp_path)
        result = scan_imports(tmp_path)
        assert "hidden_pkg" not in result.third_party


# ── Resolver ─────────────────────────────────────────────────────────────────

class TestResolver:
    def test_known_aliases(self):
        mapping = resolve_packages({"PIL", "cv2", "yaml", "bs4"})
        assert mapping["PIL"] == "pillow"
        assert mapping["cv2"] == "opencv-python"
        assert mapping["yaml"] == "pyyaml"
        assert mapping["bs4"] == "beautifulsoup4"

    def test_fallback_identity(self):
        mapping = resolve_packages({"requests"})
        assert mapping["requests"] == "requests"

    def test_normalise(self):
        assert _normalise("PyYAML") == "pyyaml"
        assert _normalise("opencv_python") == "opencv-python"
        assert _normalise("Pillow") == "pillow"


class TestParseRequirements:
    def test_basic(self, tmp_path):
        (tmp_path / "requirements.txt").write_text(
            "requests>=2.28\nflask==2.3.0\n# comment\nnumpy\n"
        )
        rf = parse_requirements(tmp_path / "requirements.txt")
        assert "requests" in rf.names
        assert "flask" in rf.names
        assert "numpy" in rf.names
        assert rf.requirements["requests"].version_spec == ">=2.28"
        assert rf.requirements["flask"].version_spec == "==2.3.0"
        assert rf.requirements["numpy"].version_spec == ""

    def test_missing_file(self, tmp_path):
        rf = parse_requirements(tmp_path / "requirements.txt")
        assert rf.names == set()

    def test_extras(self, tmp_path):
        (tmp_path / "requirements.txt").write_text("uvicorn[standard]>=0.20\n")
        rf = parse_requirements(tmp_path / "requirements.txt")
        assert "uvicorn" in rf.names


# ── Differ ────────────────────────────────────────────────────────────────────

class TestDiff:
    def test_missing_detected(self, tmp_path):
        make_project({
            "app.py": "import requests\nimport httpx",
            "requirements.txt": "requests>=2.28\n",
        }, tmp_path)
        result = diff(tmp_path)
        missing_names = {m.pip_name for m in result.missing}
        assert "httpx" in missing_names
        assert "requests" not in missing_names

    def test_unused_detected(self, tmp_path):
        make_project({
            "app.py": "import requests",
            "requirements.txt": "requests>=2.28\nflask==2.3.0\n",
        }, tmp_path)
        result = diff(tmp_path)
        unused_names = {u.pip_name for u in result.unused}
        assert "flask" in unused_names

    def test_clean_project(self, tmp_path):
        make_project({
            "app.py": "import requests",
            "requirements.txt": "requests>=2.28\n",
        }, tmp_path)
        result = diff(tmp_path, warn_unpinned=False)
        assert result.is_clean

    def test_unpinned_detected(self, tmp_path):
        make_project({
            "app.py": "import requests",
            "requirements.txt": "requests\n",
        }, tmp_path)
        result = diff(tmp_path, warn_unpinned=True)
        unpinned = {u.pip_name for u in result.unpinned}
        assert "requests" in unpinned

    def test_stdlib_not_flagged(self, tmp_path):
        make_project({
            "app.py": "import os\nimport sys\nimport json\nimport pathlib",
            "requirements.txt": "",
        }, tmp_path)
        result = diff(tmp_path)
        assert result.is_clean


# ── Fixer ─────────────────────────────────────────────────────────────────────

class TestFix:
    def test_adds_missing(self, tmp_path):
        make_project({
            "app.py": "import requests\nimport httpx",
            "requirements.txt": "requests>=2.28\n",
        }, tmp_path)
        result = diff(tmp_path)
        changes = fix(result, root=tmp_path)
        assert "httpx" in changes["added"]
        content = (tmp_path / "requirements.txt").read_text()
        assert "httpx" in content

    def test_dry_run_doesnt_write(self, tmp_path):
        make_project({
            "app.py": "import requests\nimport httpx",
            "requirements.txt": "requests>=2.28\n",
        }, tmp_path)
        original = (tmp_path / "requirements.txt").read_text()
        result = diff(tmp_path)
        fix(result, root=tmp_path, dry_run=True)
        assert (tmp_path / "requirements.txt").read_text() == original

    def test_remove_unused(self, tmp_path):
        make_project({
            "app.py": "import requests",
            "requirements.txt": "requests>=2.28\nflask==2.3.0\n",
        }, tmp_path)
        result = diff(tmp_path)
        fix(result, root=tmp_path, remove_unused=True)
        content = (tmp_path / "requirements.txt").read_text()
        assert "flask" not in content
        assert "requests" in content
