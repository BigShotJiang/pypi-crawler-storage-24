"""OpenClaw installation logic."""

import os
import sys
import subprocess
import shutil
from pathlib import Path
from typing import Optional
from rich.console import Console
from .config import Config

console = Console()

NODE_VERSION = "22.16.0"


def get_platform():
    """Get platform identifier."""
    if sys.platform == "win32":
        return "win"
    elif sys.platform == "darwin":
        return "darwin"
    else:
        return "linux"


def get_node_download_url(version: str) -> str:
    """Get download URL for Node.js."""
    platform = get_platform()
    if platform == "win":
        return f"https://nodejs.org/dist/v{version}/node-v{version}-win-x64.zip"
    elif platform == "darwin":
        return f"https://nodejs.org/dist/v{version}/node-v{version}-darwin-x64.tar.gz"
    else:
        return f"https://nodejs.org/dist/v{version}/node-v{version}-linux-x64.tar.xz"


def get_install_base() -> Path:
    """Get base installation directory."""
    if sys.platform == "win32":
        base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    else:
        base = Path.home() / ".local"
    return base / "openclaw-installer"


def get_bin_dir() -> Path:
    """Get directory for executables."""
    if sys.platform == "win32":
        return Path.home() / "bin"
    else:
        return Path.home() / ".local" / "bin"


def find_node_js():
    """Find Node.js v22+ in PATH (system-installed only, no bundled)."""
    # Check system Node.js in PATH only - never use bundled
    try:
        node_path = shutil.which("node")
        if not node_path:
            return None, None, None, None
            
        # Get the real path if it's a symlink
        node_path = str(Path(node_path).resolve())
        
        result = subprocess.run(
            [node_path, "--version"],
            capture_output=True,
            text=True,
            check=True,
            timeout=5,
        )
        version = result.stdout.strip()
        major = int(version.lstrip("v").split(".")[0])
        
        if major >= 22:
            # Find npm in the same directory as node
            node_dir = Path(node_path).parent
            npm_path = node_dir / ("npm.cmd" if sys.platform == "win32" else "npm")
            
            # Fall back to PATH if not in same directory
            if not npm_path.exists():
                npm_path = shutil.which("npm")
                if npm_path:
                    npm_path = Path(npm_path)
            
            if npm_path and npm_path.exists():
                # Test if npm actually works
                env = os.environ.copy()
                node_dir = str(node_dir)
                env["PATH"] = node_dir + os.pathsep + env.get("PATH", "")
                
                try:
                    test_result = subprocess.run(
                        [str(npm_path), "--version"],
                        capture_output=True,
                        text=True,
                        env=env,
                        timeout=10,
                    )
                    if test_result.returncode == 0:
                        return "system", version, Path(node_path), Path(npm_path)
                except Exception:
                    pass
            return None, None, None, None  # npm is broken, will need to download
        else:
            # Node.js version < 22
            return None, None, None, None
    except Exception:
        return None, None, None, None


def install_node_js(target_dir: Path, version: str = NODE_VERSION) -> bool:
    """Download and install Node.js."""
    try:
        console.print(f"[dim]Downloading Node.js v{version}...[/]", end="")
        
        if target_dir.exists():
            console.print(" [yellow](already exists)[/]")
            return True
            
        if not download_node(version, target_dir):
            return False
            
        console.print(" [green]OK[/]")
        return True
    except Exception as e:
        console.print(f" [red]FAIL {e}[/]")
        return False


def get_npm_global_path(node_bin: Path) -> Path:
    """Get npm global modules path for a given node binary."""
    try:
        result = subprocess.run(
            [str(node_bin), "-e", "console.log(process.execPath)"],
            capture_output=True,
            text=True,
            check=True,
        )
        node_path = Path(result.stdout.strip())
        if sys.platform == "win32":
            return node_path.parent / "node_modules"
        else:
            return node_path.parent.parent / "lib" / "node_modules"
    except Exception:
        # Fallback: use npm command
        try:
            npm_bin = node_bin.parent / ("npm.cmd" if sys.platform == "win32" else "npm")
            result = subprocess.run(
                [str(npm_bin), "root", "-g"],
                capture_output=True,
                text=True,
                check=True,
            )
            return Path(result.stdout.strip())
        except Exception:
            # Last resort: assume standard structure
            if sys.platform == "win32":
                return node_bin.parent / "node_modules"
            else:
                return node_bin.parent.parent / "lib" / "node_modules"


def download_node(version: str, target_dir: Path) -> bool:
    """Download and extract Node.js."""
    import urllib.request
    import tempfile

    url = get_node_download_url(version)
    platform = get_platform()

    try:
        with tempfile.TemporaryDirectory() as tmp:
            console.print(f"[dim]Downloading Node.js v{version}...[/]", end="")

            if platform == "win":
                archive = Path(tmp) / "node.zip"
            elif platform == "darwin":
                archive = Path(tmp) / "node.tar.gz"
            else:
                archive = Path(tmp) / "node.tar.xz"

            urllib.request.urlretrieve(url, archive)
            console.print(" [green]OK[/]")

            console.print("[dim]Extracting Node.js...[/]", end="")
            target_dir.mkdir(parents=True, exist_ok=True)

            if platform == "win":
                import zipfile
                with zipfile.ZipFile(archive, "r") as z:
                    z.extractall(tmp)
                extracted = Path(tmp) / f"node-v{version}-win-x64"
                if extracted.exists():
                    for item in extracted.iterdir():
                        shutil.move(str(item), str(target_dir / item.name))
            else:
                subprocess.run(
                    ["tar", "-xf", str(archive), "-C", str(tmp)],
                    check=True,
                    capture_output=True,
                )
                extracted = Path(tmp) / f"node-v{version}-{platform}-x64"
                if extracted.exists():
                    for item in extracted.iterdir():
                        shutil.move(str(item), str(target_dir / item.name))

            console.print(" [green]OK[/]")
            return True
    except Exception as e:
        console.print(f" [red]FAIL {e}[/]")
        return False


class OpenClawInstaller:
    """Installer for OpenClaw."""

    def __init__(self, config: Config, dry_run: bool = False):
        self.config = config
        self.dry_run = dry_run
        self.node_bins = {}
        self.bin_dir = get_bin_dir()

    def install(self) -> bool:
        """Run full installation."""
        console.print("")
        console.print("[bold blue]OpenClaw Installer[/]")
        console.print("")

        if self.dry_run:
            console.print("[yellow]DRY RUN MODE - No changes will be made[/]")
            console.print("")

        # Pre-installation checks
        if not self.dry_run:
            self._clean_old_installations()
            self._verify_path()

        steps = [
            ("Setting up Node.js", self._setup_node),
            ("Installing OpenClaw", self._install_openclaw),
            ("Configuring AI provider", self._configure),
            ("Creating wrapper", self._create_wrapper),
            ("Installing gateway service", self._install_gateway),
        ]

        for name, step_func in steps:
            if not step_func():
                console.print(f"[red]Installation failed at: {name}[/]")
                return False

        # Auto-login to dashboard if configured
        if self.config.automation.auto_open_dashboard:
            self._auto_login()
        
        self._print_success()
        return True

    def _clean_old_installations(self) -> None:
        """Remove old openclaw installations that could conflict."""
        try:
            # Check for old global npm installation in common Node.js locations (Windows)
            if sys.platform == "win32":
                # Check multiple possible Node.js installation locations
                possible_locations = [
                    Path(os.environ.get("ProgramFiles", "C:\\Program Files")) / "nodejs",
                    Path("C:\\Program Files") / "nodejs",
                    Path("G:\\Program Files") / "nodejs",  # User's specific location
                    Path(os.environ.get("ProgramFiles(x86)", "C:\\Program Files (x86)")) / "nodejs",
                ]
                
                for nodejs_dir in possible_locations:
                    if nodejs_dir.exists():
                        old_wrapper = nodejs_dir / "openclaw.cmd"
                        if old_wrapper.exists():
                            console.print(f"[yellow]Removing old installation: {old_wrapper}[/]")
                            old_wrapper.unlink()
                        
                        # Also check for openclaw without extension
                        old_wrapper_no_ext = nodejs_dir / "openclaw"
                        if old_wrapper_no_ext.exists():
                            console.print(f"[yellow]Removing old installation: {old_wrapper_no_ext}[/]")
                            old_wrapper_no_ext.unlink()
        except Exception:
            # Don't fail installation if cleanup fails
            pass

    def _verify_path(self) -> None:
        """Verify wrapper directory is in PATH."""
        try:
            path_env = os.environ.get("PATH", "")
            if str(self.bin_dir) not in path_env:
                # Add to user PATH permanently
                if sys.platform == "win32":
                    import winreg
                    key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment", 0, winreg.KEY_READ | winreg.KEY_WRITE)
                    current_path, _ = winreg.QueryValueEx(key, "PATH")
                    
                    if str(self.bin_dir) not in current_path:
                        new_path = str(self.bin_dir) + ";" + current_path
                        winreg.SetValueEx(key, "PATH", 0, winreg.REG_EXPAND_SZ, new_path)
                        winreg.CloseKey(key)
                        
                        # Also update current session
                        os.environ["PATH"] = str(self.bin_dir) + os.pathsep + os.environ.get("PATH", "")
                        
                        console.print(f"[green]Added {self.bin_dir} to user PATH[/]")
                else:
                    # For Linux/macOS, instruct user to add to PATH
                    console.print(f"[yellow]Add to PATH: export PATH=\"{self.bin_dir}:$PATH\"[/]")
                    console.print("[dim]Consider adding to your .bashrc or .zshrc[/]")
        except Exception:
            # Don't fail installation if PATH update fails
            pass

    def _setup_node(self) -> bool:
        """Ensure Node.js v22+ is available."""
        console.print("[dim]Setting up Node.js...[/]", end="")
        
        if self.dry_run:
            console.print(" [yellow](skipped)[/]")
            self.node_bins = {
                "node": Path("node"),
                "npm": Path("npm"),
                "source": "dry-run",
            }
            return True
        
        # Try to find existing Node.js v22+
        source, version, node_exe, npm_exe = find_node_js()
        
        if source:
            console.print(f" [green]OK[/] Using {source} Node.js {version}")
            self.node_bins = {
                "node": node_exe,
                "npm": npm_exe,
                "source": source,
                "install_method": "global",
            }
            return True
        
        # Download Node.js v22 if not found
        console.print("")
        install_base = get_install_base()
        node_dir = install_base / "node"
        
        if (node_dir / ("node.exe" if sys.platform == "win32" else "bin/node")).exists():
            console.print(f"[dim]Using existing Node.js v{NODE_VERSION}[/]")
        else:
            console.print(f"[dim]Downloading Node.js v{NODE_VERSION}...[/]", end="")
            if not download_node(NODE_VERSION, node_dir):
                return False
            console.print(" [green]OK[/]")
        
        # Configure paths
        if sys.platform == "win32":
            node_exe = node_dir / "node.exe"
            npm_exe = node_dir / "npm.cmd"
        else:
            node_exe = node_dir / "bin" / "node"
            npm_exe = node_dir / "bin" / "npm"
        
        console.print(f"[green]OK[/] Node.js v{NODE_VERSION} ready")
        self.node_bins = {
            "node": node_exe,
            "npm": npm_exe,
            "source": "downloaded",
        }
        return True

    def _install_openclaw(self) -> bool:
        """Install OpenClaw npm package globally with automatic Node.js download fallback."""
        console.print(f"[dim]Installing OpenClaw {self.config.version}...[/]", end="")
        
        if self.dry_run:
            console.print(" [yellow](skipped)[/]")
            return True
        
        import time
        
        max_attempts = 3
        node_downloaded = False
        last_error = None
        
        for attempt in range(max_attempts):
            try:
                # On first attempt, use the Node.js from _setup_node
                # On subsequent attempts, download fresh Node.js
                if attempt == 0:
                    if not self.node_bins:
                        console.print("\n[yellow]Warning: No Node.js available, downloading...[/]")
                        node_source = "fresh-download"
                    else:
                        node_source = self.node_bins.get("source", "unknown")
                else:
                    # After first failure, download fresh Node.js
                    if not node_downloaded:
                        console.print("")  # New line after previous failure
                        console.print(f"[dim]Attempt {attempt + 1}: Downloading Node.js v{NODE_VERSION}...[/]", end="")
                        
                        install_base = get_install_base()
                        node_dir = install_base / "node"
                        
                        # Remove existing node directory to ensure clean install
                        if node_dir.exists():
                            shutil.rmtree(node_dir)
                        
                        if download_node(NODE_VERSION, node_dir):
                            # Update node_bins with downloaded Node.js
                            if sys.platform == "win32":
                                self.node_bins = {
                                    "node": node_dir / "node.exe",
                                    "npm": node_dir / "npm.cmd",
                                    "source": "downloaded",
                                }
                            else:
                                self.node_bins = {
                                    "node": node_dir / "bin" / "node",
                                    "npm": node_dir / "bin" / "npm",
                                    "source": "downloaded",
                                    "install_method": "global",
                                }
                            node_downloaded = True
                            console.print(" [green]OK[/]")
                        else:
                            console.print(" [red]FAIL[/]")
                            if attempt == max_attempts - 1:
                                console.print(f"[red]Could not download Node.js after {max_attempts} attempts[/]")
                                return False
                            time.sleep((attempt + 1) * 2)
                            continue
                
                # Get Node.js and npm paths
                npm_path = str(self.node_bins["npm"])
                node_path = str(self.node_bins["node"])
                node_dir = Path(node_path).parent
                
                # Configure environment - CRITICAL for Windows
                # Ensure node.exe is in PATH so npm can find it
                env = os.environ.copy()
                env["PATH"] = str(node_dir) + os.pathsep + env.get("PATH", "")
                
                # Also set NODE_PATH and other helpful variables
                env["NODE_PATH"] = str(node_dir / "node_modules")
                env["npm_config_cache"] = str(node_dir.parent / "npm-cache")
                
                # Install openclaw locally (not globally) to avoid conflicts with system Node.js
                install_dir = get_install_base() / "openclaw"
                install_dir.mkdir(parents=True, exist_ok=True)
                cmd = [npm_path, "install", f"openclaw@{self.config.version}"]
                
                result = subprocess.run(
                    cmd,
                    cwd=str(install_dir),
                    capture_output=True,
                    text=True,
                    env=env,
                    timeout=300,  # 5 minute timeout
                )
                
                if result.returncode == 0:
                    # Check if package has a build script
                    openclaw_dir = None
                    try:
                        # Find where openclaw was installed
                        result2 = subprocess.run(
                            [npm_path, "root", "-g"],
                            capture_output=True,
                            text=True,
                            check=True,
                            env=env,
                        )
                        global_modules = Path(result2.stdout.strip())
                        package_json = global_modules / "openclaw" / "package.json"
                        if package_json.exists():
                            import json
                            pkg_data = json.loads(package_json.read_text())
                            if "scripts" in pkg_data and "build" in pkg_data["scripts"]:
                                console.print("")
                                console.print("[dim]Building openclaw...[/]", end="")
                                # Run npm run build in the openclaw directory
                                openclaw_dir = global_modules / "openclaw"
                                build_cmd = [npm_path, "run", "build"]
                                build_result = subprocess.run(
                                    build_cmd,
                                    cwd=str(openclaw_dir),
                                    capture_output=True,
                                    text=True,
                                    env=env,
                                    timeout=600,  # 10 minute build timeout
                                )
                                if build_result.returncode != 0:
                                    # Build failed, but installation might still work
                                    console.print(f"[yellow] (build failed, continuing)[/]")
                                else:
                                    console.print(" [green]OK[/]")
                    except Exception as e:
                        # If build fails, continue with installation
                        if openclaw_dir:
                            console.print(f"[yellow] (build error: {str(e)[:30]}, continuing)[/]")
                    
                    if attempt > 0:
                        console.print("")  # New line after retry attempts
                    console.print(" [green]OK[/]")
                    return True
                else:
                    # Capture error for later display
                    last_error = result.stderr.strip() or result.stdout.strip()
                    
                    # If we haven't downloaded Node.js yet, indicate we'll try that
                    if attempt < max_attempts - 1:
                        if not node_downloaded and attempt == 0:
                            error_summary = "npm error (will download Node.js)"
                        else:
                            error_summary = f"{last_error[:60]}..."
                        
                        console.print("")  # New line
                        console.print(f"[yellow]  Install failed, retrying... ({error_summary})[/]")
                        wait_time = (attempt + 1) * 3
                        time.sleep(wait_time)
                    else:
                        # Final failure
                        console.print("")  # New line
                        
            except subprocess.TimeoutExpired:
                last_error = "Installation timeout"
                if attempt < max_attempts - 1:
                    console.print("")
                    console.print(f"[yellow]  Timeout on attempt {attempt + 1}, retrying...[/]")
                    time.sleep((attempt + 1) * 3)
                else:
                    console.print("")
                    
            except Exception as e:
                last_error = str(e)
                if attempt < max_attempts - 1:
                    console.print("")
                    console.print(f"[yellow]  Error on attempt {attempt + 1}: {str(e)[:50]}, retrying...[/]")
                    time.sleep((attempt + 1) * 3)
                else:
                    console.print("")
        
        # Final failure message with details
        console.print(f"[red]FAIL[/]")
        if node_downloaded:
            console.print(f"[red]  Tried fresh Node.js v{NODE_VERSION} and still failed[/]")
        if last_error:
            console.print(f"[red]  Last error: {last_error[:100]}[/]")
        console.print(f"[red]  Could not install OpenClaw after {max_attempts} attempts[/]")
        return False

    def _configure(self) -> bool:
        """Configure OpenClaw with environment variables."""
        console.print("[dim]Configuring AI provider...[/]", end="")

        if self.dry_run:
            console.print(" [yellow](skipped)[/]")
            return True

        try:
            env = os.environ.copy()
            env.update(self.config.to_env())

            if self.node_bins.get("system"):
                openclaw_exe = "openclaw.cmd" if sys.platform == "win32" else "openclaw"
                subprocess.run(
                    [openclaw_exe, "onboard", "--yes"],
                    env=env,
                    capture_output=True,
                )

            console.print(" [green]OK[/]")
            return True
        except Exception:
            console.print(" [green]OK[/]")
            return True

    def _get_openclaw_path(self) -> Optional[Path]:
        """Get the path to openclaw from local npm install."""
        try:
            # When we do npm install (not -g), it installs to:
            # ~/.local/openclaw-installer/openclaw/node_modules/openclaw
            install_base = get_install_base()
            openclaw_dir = install_base / "openclaw" / "node_modules" / "openclaw"
            
            if openclaw_dir.exists():
                # Check for openclaw.mjs first
                openclaw_mjs = openclaw_dir / "openclaw.mjs"
                if openclaw_mjs.exists():
                    return openclaw_mjs
            
        except Exception as e:
            # If anything goes wrong, return None
            pass
        
        return None

    def _create_wrapper(self) -> bool:
        """Create wrapper script for easy access."""
        console.print("[dim]Creating wrapper...[/]", end="")

        if self.dry_run:
            console.print(" [yellow](skipped)[/]")
            return True

        try:
            self.bin_dir.mkdir(parents=True, exist_ok=True)

            if self.node_bins.get("system"):
                console.print(" [dim](system install)[/]")
                return True

            # Find where openclaw is actually installed
            openclaw_path = self._get_openclaw_path()
            if not openclaw_path:
                console.print(" [red]FAIL Could not find openclaw installation[/]")
                return False

            node_bin = str(self.node_bins["node"])
            
            # Get the node_modules directory for NODE_PATH
            node_dir = Path(node_bin).parent
            node_modules = node_dir / "node_modules"
            
            if sys.platform == "win32":
                wrapper_path = self.bin_dir / "openclaw.cmd"
                with open(wrapper_path, "w") as f:
                    # Set NODE_PATH so Node.js can find modules
                    f.write(f'@echo off\nset "NODE_PATH={node_modules}"\n"{node_bin}" "{openclaw_path}" %*')
                wrapper_display = "%USERPROFILE%\\bin\\openclaw.cmd"
            else:
                wrapper_path = self.bin_dir / "openclaw"
                with open(wrapper_path, "w") as f:
                    f.write(f'#!/bin/sh\nexport NODE_PATH="{node_modules}"\nexec "{node_bin}" "{openclaw_path}" "$@"')
                os.chmod(wrapper_path, 0o755)
                wrapper_display = "~/.local/bin/openclaw"

            console.print(" [green]OK[/]")

            path_env = os.environ.get("PATH", "")
            if str(self.bin_dir) not in path_env:
                console.print(f"[yellow]  Add to PATH: {self.bin_dir}[/]")
                console.print(f"[dim]  Or use: {wrapper_display} dashboard[/]")

            return True
        except Exception as e:
            console.print(f" [red]FAIL {e}[/]")
            return False

    def _get_node_exe_path(self) -> Optional[Path]:
        """Get the path to the Node.js executable used by this installer."""
        # Use the node binary from our installation
        install_base = get_install_base()
        if sys.platform == "win32":
            node = install_base / "node" / "node.exe"
        else:
            node = install_base / "node" / "bin" / "node"
        return node if node.exists() else None
    
    def _get_openclaw_js_path(self) -> Optional[Path]:
        """Get the path to the OpenClaw index.js file."""
        install_base = get_install_base()
        index = install_base / "openclaw" / "node_modules" / "openclaw" / "dist" / "index.js"
        return index if index.exists() else None

    def _start_gateway_direct(self) -> bool:
        """Start the gateway using direct Node.js command (most reliable)."""
        try:
            # Get paths dynamically based on actual installation
            node_exe = self._get_node_exe_path()
            openclaw_js = self._get_openclaw_js_path()
            port = self.config.gateway.port
            
            if not node_exe:
                console.print(" [yellow]Node.js not found in installation[/]")
                return False
            
            if not openclaw_js:
                console.print(" [yellow]OpenClaw index.js not found[/]")
                return False
            
            # Build command: node index.js gateway --port 18789
            cmd = [str(node_exe), str(openclaw_js), "gateway", "--port", str(port)]
            
            if sys.platform == "win32":
                # Windows: Use CREATE_NEW_PROCESS_GROUP
                subprocess.Popen(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    creationflags=subprocess.CREATE_NEW_PROCESS_GROUP,
                )
            else:
                # Unix (Linux/macOS): Use start_new_session
                subprocess.Popen(
                    cmd,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    start_new_session=True,
                )
            
            return True
        except Exception as e:
            console.print(f" [yellow]Direct start failed: {str(e)[:30]}[/]")
            return False

    def _install_gateway(self) -> bool:
        """Install and start the OpenClaw gateway service."""
        console.print("[dim]Installing gateway service...[/]", end="")
        
        if self.dry_run:
            console.print(" [yellow](skipped)[/]")
            return True
        
        try:
            # Check if gateway is already running
            env = os.environ.copy()
            env.update(self.config.to_env())
            
            # Check gateway status
            status_result = subprocess.run(
                [str(self.node_bins["node"]), str(self._get_openclaw_path()), "gateway", "status"],
                capture_output=True,
                text=True,
                env=env,
                timeout=10,
            )
            
            # Check for RPC probe OK which indicates healthy gateway
            is_running = status_result.returncode == 0 and (
                "rpc probe: ok" in status_result.stdout.lower() or
                "running" in status_result.stdout.lower()
            )
            
            if is_running:
                console.print(" [green]OK[/] Gateway already running")
                return True
            
            # Try direct Node.js command first (most reliable)
            console.print(" [dim]starting...[/]", end="")
            if self._start_gateway_direct():
                # Wait a moment for gateway to initialize
                import time
                time.sleep(3)
                
                # Verify it's running
                verify_result = subprocess.run(
                    [str(self.node_bins["node"]), str(self._get_openclaw_path()), "gateway", "status"],
                    capture_output=True,
                    text=True,
                    env=env,
                    timeout=10,
                )
                
                if verify_result.returncode == 0:
                    console.print(" [green]OK[/] Gateway running")
                    return True
            
            # Fallback: Try service install/start via wrapper
            console.print(" [dim]installing...[/]", end="")
            
            # Install gateway service
            install_result = subprocess.run(
                [str(self.node_bins["node"]), str(self._get_openclaw_path()), "gateway", "install"],
                capture_output=True,
                text=True,
                env=env,
                timeout=30,
            )
            
            if install_result.returncode == 0:
                # Start gateway via service
                start_result = subprocess.run(
                    [str(self.node_bins["node"]), str(self._get_openclaw_path()), "gateway", "start"],
                    capture_output=True,
                    text=True,
                    env=env,
                    timeout=30,
                )
                
                if start_result.returncode == 0:
                    console.print(" [green]OK[/] Gateway running")
                else:
                    console.print(" [yellow]OK[/] (service mode)")
            else:
                console.print(" [yellow]OK[/] (direct mode)")
            
            return True  # Don't fail installation if gateway setup has issues
            
        except subprocess.TimeoutExpired:
            console.print(" [yellow]OK[/] (timeout)")
            return True
        except Exception as e:
            console.print(f" [yellow]OK[/] ({str(e)[:20]})")
            return True

    def uninstall(self) -> bool:
        """Uninstall OpenClaw."""
        console.print("")
        console.print("[bold blue]OpenClaw Uninstaller[/]")
        console.print("")

        if self.dry_run:
            console.print("[yellow]DRY RUN MODE - No changes will be made[/]")
            console.print("")

        steps = [
            ("Removing OpenClaw package", self._uninstall_openclaw),
            ("Cleaning up Node.js (if installed)", self._cleanup_node),
        ]

        for name, step_func in steps:
            if not step_func():
                console.print(f"[red]Uninstall failed at: {name}[/]")
                return False

        console.print("")
        console.print("[bold green]Uninstall Complete![/]")
        console.print("")
        return True

    def _uninstall_openclaw(self) -> bool:
        """Uninstall OpenClaw npm package."""
        console.print("[dim]Removing OpenClaw...[/]", end="")

        if self.dry_run:
            console.print(" [yellow](skipped)[/]")
            return True

        try:
            if self.node_bins.get("system"):
                npm = str(self.node_bins["npm"])
                subprocess.run(
                    [npm, "uninstall", "-g", "openclaw"],
                    capture_output=True,
                    check=True,
                )
            else:
                install_base = get_install_base()
                node_dir = install_base / "node"
                if node_dir.exists():
                    shutil.rmtree(node_dir)

            console.print(" [green]OK[/]")
            return True
        except Exception as e:
            console.print(f" [red]FAIL {e}[/]")
            return False

    def _cleanup_node(self) -> bool:
        """Clean up Node.js installation."""
        console.print("[dim]Cleaning up Node.js...[/]", end="")

        if self.dry_run:
            console.print(" [yellow](skipped)[/]")
            return True

        try:
            install_base = get_install_base()
            if install_base.exists():
                shutil.rmtree(install_base)

            # Remove wrapper script
            if sys.platform == "win32":
                wrapper = self.bin_dir / "openclaw.cmd"
            else:
                wrapper = self.bin_dir / "openclaw"

            if wrapper.exists():
                wrapper.unlink()

            console.print(" [green]OK[/]")
            return True
        except Exception as e:
            console.print(f" [red]FAIL {e}[/]")
            return False

    def _auto_login(self) -> bool:
        """Automatically login to dashboard after installation."""
        if not self.config.automation.auto_login:
            return True
        
        console.print("")
        console.print("[dim]Auto-logging into dashboard...[/]", end="")
        
        if self.dry_run:
            console.print(" [yellow](skipped in dry-run)[/]")
            return True
        
        try:
            # Import here to avoid circular dependency
            try:
                from .automation.auto_login import auto_login
            except ImportError:
                # Try direct import from automation folder
                import sys
                automation_path = Path(__file__).parent / "automation"
                sys.path.insert(0, str(automation_path))
                from auto_login import auto_login
            
            browser_path = self.config.automation.browser_path or None
            success = auto_login(browser_path)
            
            if success:
                console.print(" [green]OK[/]")
            else:
                console.print(" [yellow]Retry manually: openclaw-installer auto-login[/]")
            
            return success
        except Exception as e:
            console.print(f" [yellow]Skipped ({str(e)[:30]})[/]")
            console.print("  Run manually: openclaw-installer auto-login")
            return False
    
    def _print_success(self):
        """Print success message."""
        console.print("")
        console.print("[bold green]Installation Complete![/]")
        console.print("")
        port_str = str(self.config.gateway.port)
        console.print(f"[bold green]Web UI:[/] http://localhost:{port_str}")

        if self.node_bins.get("system"):
            console.print("[bold green]Command:[/] openclaw dashboard")
        else:
            if sys.platform == "win32":
                console.print("[bold green]Command:[/] %USERPROFILE%\\bin\\openclaw.cmd")
            else:
                console.print("[bold green]Command:[/] ~/.local/bin/openclaw")

        # Only show next steps if auto-login didn't run or failed
        if not self.config.automation.auto_open_dashboard or not self.config.automation.auto_login:
            console.print("")
            console.print("[dim]Next steps:[/]")
            console.print("  • Run: openclaw dashboard")
            console.print("  • Or:   openclaw gateway status")
            console.print("")
        else:
            console.print("")
            console.print("[dim]Dashboard should now be open in your browser.[/]")
            console.print("  If not, run: openclaw-installer auto-login")
            console.print("")


def generate_example_config() -> str:
    """Generate example YAML configuration."""
    return """# OpenClaw Installer Configuration
# ================================
# Edit this file with your settings, then run:
#   openclaw-installer install --config this-file.yaml

ai:
  # AI provider: anthropic, openai, kimi, ollama
  provider: anthropic
  # API key (get from your provider)
  key: "your-api-key-here"
  # Model name (provider-specific)
  model: "claude-3-5-sonnet-20241022"
  # Optional: custom base URL for Ollama or proxies
  base_url: null

channels:
  # Enable web interface
  web: true

# Optional: Advanced settings
gateway:
  # Port for web interface
  port: 18789
  # Auto-start after installation
  autostart: true

# Examples for other providers:
#
# --- Kimi (Moonshot AI) ---
# ai:
#   provider: kimi
#   key: "sk-your-kimi-key"
#   model: "moonshot-v1-8k"
#
# --- Ollama (local AI) ---
# ai:
#   provider: ollama
#   key: ""  # No key needed
#   model: "llama3.1:8b"
#   base_url: "http://localhost:11434"
#
# --- OpenAI ---
# ai:
#   provider: openai
#   key: "sk-your-openai-key"
#   model: "gpt-4o"
"""
