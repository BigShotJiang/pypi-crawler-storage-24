import asyncio
import requests
from xync_client.loader import TORM
from x_model import init_db
from xync_schema import models
import re


def is_email_regex(email):
    pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
    return bool(re.match(pattern, email))


async def login(email: str, password: str, agent):
    headers = {
        "origin": "https://app.airtm.com",
        "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36",
    }

    json_data = {
        "operationName": "Login",
        "variables": {
            "metadata": {
                "utm_referrer": "https://www.airtm.com/",
                "oauth_source": "INTERNAL",
            },
            "captcha": None,
            "email": email,
            "password": password,
        },
        "query": "mutation Login($email: Email!, $password: LimitedString!, $code: LimitedString, $emailCode: LimitedString, $phoneCode: LimitedString, $isMfaReset: Boolean, $metadata: JSON, $captcha: CaptchaClientResponse) {\n  login(\n    email: $email\n    password: $password\n    code: $code\n    emailCode: $emailCode\n    phoneCode: $phoneCode\n    isMfaReset: $isMfaReset\n    metadata: $metadata\n    captcha: $captcha\n  ) {\n    authenticationResponse {\n      expiresAt\n      jwt\n      __typename\n    }\n    challengeMethod\n    email\n    phone\n    __typename\n  }\n}",
    }

    response = requests.post("https://app.airtm.com/graphql", headers=headers, json=json_data).json()
    agent.state = {"jwt": response.get("data", {}).get("login", {}).get("authenticationResponse", {}).get("jwt", {})}
    await agent.save()


async def send(agent, currency: str, amount: int, login: str):
    headers = {
        "authorization": f"Bearer {agent.state['jwt']}",
        "baggage": "sentry-environment=production,sentry-release=webapp-milotic%4012.62.19,sentry-public_key=b300b9da8e85472da3e2423ef4595a1a,sentry-trace_id=1f28a49e35b9492a8238c2eb9e055114,sentry-sample_rate=0.1,sentry-sampled=false",
        "content-type": "application/json",
        "origin": "https://app.airtm.com",
        "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36",
    }
    if not is_email_regex(login):
        json_data = {
            "operationName": "FindUserByUsername",
            "variables": {
                "username": login,
            },
            "query": "query FindUserByUsername($username: String!) {\n  user: userByUsername(username: $username) {\n    id\n    email\n    isGuest\n    username\n    isBannedOrDeleted\n    avatar\n    __typename\n  }\n}",
        }

        login = requests.post("https://app.airtm.com/graphql", headers=headers, json=json_data).json()["data"]["user"][
            "email"
        ]

    json_data = {
        "operationName": "MakeSend",
        "variables": {
            "idMethod": "username",
            "captcha": None,
            "amount": f"{amount}",
            "concept": "1",
            "currency": currency,
            "email": login,
        },
        "query": "mutation MakeSend($email: Email!, $amount: BigNumber!, $currency: String!, $concept: String!, $idMethod: String, $mfaCode: String, $captcha: CaptchaClientResponse) {\n  makeSend(\n    email: $email\n    amount: $amount\n    currency: $currency\n    concept: $concept\n    idMethod: $idMethod\n    mfaCode: $mfaCode\n    captcha: $captcha\n  ) {\n    id\n    hash\n    __typename\n  }\n}",
    }

    response = requests.post("https://app.airtm.com/graphql", headers=headers, json=json_data)
    return response


async def main():
    _ = await init_db(TORM, True)
    agent = await models.PmAgent.filter(pm__norm="airtm", auth__isnull=False).first()
    await login(agent.auth.get("email"), agent.auth.get("password"), agent)
    await send(agent, login="xyncpay", amount=1, currency="USD")


if __name__ == "__main__":
    asyncio.run(main())
