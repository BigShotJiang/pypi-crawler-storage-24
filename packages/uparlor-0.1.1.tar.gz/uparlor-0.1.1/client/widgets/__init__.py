"""
基础 UI 组件 — 面板共用的核心 Widget

导入 scrollbar 模块以触发全局 ScrollBar.renderer 替换。
"""

from .helpers import _set_pane_subtitle
from .scrollbar import RoundedScrollBarRender  # noqa: F401 — 触发全局渲染器替换
from .prompt import PromptMixin
from .input_bar import InputBar, InputTextArea
from .tab_menu import TabMenuBase

__all__ = [
    '_set_pane_subtitle',
    'RoundedScrollBarRender',
    'PromptMixin',
    'InputBar',
    'InputTextArea',
    'TabMenuBase',
]
