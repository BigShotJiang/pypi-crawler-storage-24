# nutricare-data-packages

Nutricare 的数据访问基础包，封装 MongoDB 仓储与本地存储抽象基类。

## 安装

```bash
pip install nutricare-data-packages
```

## 快速使用

```python
from nutricare_data_packages import StorageBase


class ReportStorage(StorageBase):
    @property
    def storage_subdir(self) -> str:
        return "reports"

    def _write_impl(
        self, relative_path: str, data: bytes, **kwargs
    ) -> tuple[bool, dict | None]:
        target, _ = self.resolve_path(relative_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        return True, None

storage = ReportStorage()
relative_path = "daily/report.txt"
content = b"hello"
ok = storage.write(relative_path, content)
```

说明：
- MongoDB 连接串只从环境变量 `mongodb_url` 读取。
- 允许传入 `127.0.0.1:27017`、`mongodb:127.0.0.1:27017` 或完整 `mongodb://...`。
- `write` 是统一入口：自动做路径校验、md5 计算、元数据写入和幂等判断。
- `NUTRICARE_TICKET_ID` 与 `NUTRICARE_TASK_ID` 从环境变量读取。

## 本地构建与发布

```bash
python -m pip install --upgrade build twine
python -m build
python -m twine check dist/*
python -m twine upload dist/*
```
