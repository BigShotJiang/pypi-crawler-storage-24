import hashlib


def calculate_md5(data: bytes) -> str:
    return hashlib.md5(data, usedforsecurity=False).hexdigest()
