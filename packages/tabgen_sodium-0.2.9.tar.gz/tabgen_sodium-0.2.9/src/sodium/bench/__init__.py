import json
import pathlib

import pandas as pd

_DATA = pathlib.Path(__file__).parent / "_data"


def _load_queries() -> dict:
    with open(_DATA / "queries.json", encoding="utf-8") as f:
        return json.load(f)


def list_queries() -> list:
    """Return sorted list of all query IDs in the benchmark."""
    return sorted(int(k) for k in _load_queries())


def get_query(id) -> dict:
    """Return metadata for a single benchmark query (query, primary_key, base_url, etc.)."""
    queries = _load_queries()
    key = str(id)
    if key not in queries:
        raise KeyError(f"Query id={id} not found in benchmark.")
    return queries[key]


def get_schema(id) -> list:
    """Return the list of column names for a benchmark query."""
    path = _DATA / "schema" / f"{id}.csv"
    if not path.exists():
        raise FileNotFoundError(f"Schema not found: {path}")
    return list(pd.read_csv(path).columns)


def evaluate(id, output, out_root="eval_outputs"):
    """Evaluate agent predictions against bundled ground truth.

    Args:
        id:       Benchmark query ID.
        output:   Agent output as a pandas DataFrame or path to output.csv.
        out_root: Directory to write evaluation outputs (default: eval_outputs/).

    Returns:
        (llm_score, str_score) as floats in [0, 1].
    """
    import tempfile, os
    from sodium.bench.eval.evaluation import evaluate_id

    queries_path = str(_DATA / "queries.json")
    gt_root = str(_DATA / "gt")

    if isinstance(output, pd.DataFrame):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as f:
            output.to_csv(f, index=False)
            tmp_path = f.name
        try:
            _, _, llm_score, _, _, str_score = evaluate_id(id, tmp_path, queries_path, gt_root, out_root)
        finally:
            os.unlink(tmp_path)
    else:
        _, _, llm_score, _, _, str_score = evaluate_id(id, output, queries_path, gt_root, out_root)
    return llm_score, str_score
