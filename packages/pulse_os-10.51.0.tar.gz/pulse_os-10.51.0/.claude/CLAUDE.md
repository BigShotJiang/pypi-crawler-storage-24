# PULSE Agent Boot Directive

You are operating inside PULSE, a Neural Operating System for AI swarms.
Platform: Windows 11. Use PowerShell or Python to read files — bash commands (cat, grep) will NOT work.

## Rules (Non-Negotiable)
1. **Brain FIRST:** Before ANY implementation, run `python pulse/brain/brain_query.py --query "<your task>"` and apply the knowledge. For Claude Code: this runs automatically via hooks on every Edit/Write. For other agents: run it manually before coding. Skipping brain = Tier 0 violation.
2. **Task board:** Check `state/task_board.json`. If open tasks exist, CLAIM one matching your tier per ASOP Rule 2 and execute it. **If the board is empty, output a brief Status Report and WAIT — do NOT start working autonomously.**
3. **Silent compliance:** Do NOT print law lists, rule checkboxes, or ceremony text to the user. Governance is loaded internally. User sees your Status Report (name, task, 1-2 brain insights, under 5 lines) and your work — nothing else.
4. **Save learnings:** When done, run `python pulse/brain/pulse_save.py --agent <you> --learnings "what you learned" --failures "what failed"`.
5. **No repeat mistakes:** Check `Hippocampus/Anti_Patterns/anti_patterns_active.json` before implementing.
6. **Constitution:** Read `Corpus_Callosum/CONSTITUTION.md`. Comply silently.
7. **ASOP protocol:** Read `Corpus_Callosum/Protocols/ASOP.md` for task coordination.
8. **Decompose for others:** If user gives you multiple tasks, do what you can and post the rest to the task board via `python pulse/tasks/pulse_relay.py --tasks "Title:domain:complexity"`.

## Task Tiers (check `recommended_tier` on each task)
- **fast:** Haiku, Flash, cheap models. Simple tasks (rename, format, docs, tests).
- **standard:** Sonnet, Gemini Pro. Features, refactoring, implementation.
- **premium:** Opus, GPT-4. Architecture, security audits, complex design.
- Claim tasks matching YOUR capability. Don't waste expensive models on simple tasks.

## Autonomous Task Execution
Tasks posted via `pulse_relay.py` are auto-executed. One command:

**`pulse swarm` — THE unified way to start workers:**
- `pulse swarm` — interactive picker (provider -> model -> count)
- `pulse swarm gemini` — pick model + count for Gemini
- `pulse swarm stop` / `pulse swarm status`
- Auto-detects available providers (API keys, CLI subscriptions, Ollama)
- Routes to headless workers (API/Ollama) or CLI autopilot (subscriptions)

**Interactive chat (no task board):**
- `pulse claude` / `pulse gemini` — launches agent for interactive use

## Package Structure
All code lives in the `pulse/` Python package:
- **Core:** `pulse/core/` — brain_utils, brain_io, config, crypto, paths
- **Brain:** `pulse/brain/` — search, query, save, boot, extraction
- **Agents:** `pulse/agents/` — claude, gemini, codex, grok wrappers
- **Workers:** `pulse/workers/` — headless task execution
- **Tasks:** `pulse/tasks/` — dispatcher, relay, decomposer
- **Daemons:** `pulse/daemons/` — orchestrator + 4 subpackages: consolidation/, bridge/, neural/, synthesis/
- **Graph:** `pulse/graph/` — knowledge graph build/query
- **API:** `pulse/api/` — REST endpoints
- **Admin:** `pulse/admin/` — 7 subpackages: audit/, brain_ops/, patterns/, skills/, benchmarks/, retroactive/, setup/
- **CLI:** `pulse/cli/` — status, swarm, manage commands
- **Config:** `pulse/config/` — brain_config.json, knowledge_anchors.json
- **State:** `state/` — runtime data (PIDs, logs, registries, captures)

## Key Paths
- **Brain query:** `python pulse/brain/brain_query.py --query "<task>"` (RUN FIRST)
- **Brain save:** `python pulse/brain/pulse_save.py --agent <you> --learnings "..." --failures "..."`
- **Task relay:** `python pulse/tasks/pulse_relay.py --tasks "Title:domain:complexity"`
- **Brain map:** `Hippocampus/BRAIN_MAP.md` (single navigation file)
- **Lessons:** `Hippocampus/Lessons/auto_lessons.md`
- **Failures:** `Hippocampus/Failures/auto_fails.md`
- **Patterns:** `Hippocampus/Patterns/auto_patterns.md`
- **Evidence:** `Hippocampus/Evidence/` (session logs, decisions, intents)
- **Knowledge:** `Hippocampus/Knowledge/` (curated domain knowledge)
- **Anti-patterns:** `Hippocampus/Anti_Patterns/anti_patterns_active.json`
- **Pipeline:** `Personal_Plans/PIPELINE.md` (master priority list — single source of truth)
- **Task board:** `state/task_board.json`
- **Skills:** `.cursor/skills/` (read relevant skill .md before executing domain tasks)
- **CLI:** `python pulse_cli.py status|swarm|post|start|stop|claude|gemini`

## User
The Founder goes by "bro". Values efficiency — every token counts. Prefers concise, action-oriented communication. Multiple agents (Gemini, Claude, Codex, Grok) share this brain.
