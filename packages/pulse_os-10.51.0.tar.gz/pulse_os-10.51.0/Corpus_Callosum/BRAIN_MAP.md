# Hippocampus Brain Map
> The entire brain lives in `pulse_brain.db` (SQLite). One file, 16 tables, 200K+ rows.
> JSON files are GONE. SQLite is the single source of truth.

## What's In This Directory

```
Hippocampus/
  pulse_brain.db              ← THE BRAIN (all knowledge, graph, metrics)
  BRAIN_MAP.md                ← THIS FILE (your guide)
  Evidence/Sessions/          ← 3 operational files (active writes, not brain knowledge):
    current_session.json        - Live bridge session buffer (WANT/DONT_WANT/OBSERVATION)
    agent_sessions.json         - Task session records from pulse_save
    broadcast_alerts.json       - Brain health broadcast alerts
```

Everything else was migrated to SQLite and deleted. If you see other JSON/JSONL files, they're zombie empties from legacy code paths.

---

## SQLite Tables

### Knowledge (searchable via FTS5)
| Table | ~Rows | What It Stores |
|-------|-------|---------------|
| **lessons** | 8,500+ | What worked — engineering wins, successful approaches |
| **failures** | 4,800+ | What broke — bugs, crashes, wrong approaches |
| **patterns** | 4,600+ | Reusable solutions — "always do X when Y" |
| **facts** | 8,300+ | Declarative knowledge — "PULSE uses SQLite", "website on Vercel" |
| **intents** | 15,800+ | User wants + dont_wants + strategic intents |
| **evidence** | 11,200+ | Domain learnings + session observations |
| **schemas** | 435+ | Reusable heuristics — "Brain Query Before Action" |
| **anti_patterns** | 880+ | What to NEVER do — "never use sys.exit in library code" |
| **decisions** | 16+ | Architectural choices — "chose Stripe for payments" |
| **private** | 0 | Private/sensitive knowledge (gitignored) |
| **procedures** | 0 | Step-by-step workflows (not yet populated) |
| **episodic** | 0 | Session replay index (not yet populated) |

### Graph (knowledge topology)
| Table | ~Rows | What It Stores |
|-------|-------|---------------|
| **graph_nodes** | 34,900+ | Concepts, lessons, patterns as vertices (with degree) |
| **graph_edges** | 111,100+ | REQUIRES / LEADS_TO / PREVENTS / CAUSES / COACTIVATION / TEMPORAL |

### Operational
| Table | ~Rows | What It Stores |
|-------|-------|---------------|
| **retrieval_metrics** | 1,300+ | LTP signal — which items get retrieved most |
| **knowledge_fts** | 42,000+ | FTS5 full-text search index across ALL knowledge tables |

---

## How Search Works
1. Query hits `knowledge_fts` (FTS5) — one index covers ALL 12 knowledge tables
2. Ranked by: relevance (0.45) + recency (0.15) + salience (0.25) + LTP (0.15)
3. Epistemic qualifiers: [UNCERTAIN], [STALE Nd], [CONTESTED]
4. Top results returned to agent in ~3.7 seconds

## How Knowledge Enters
```
Agent conversation → capture log → bridge → extraction → SQLite + FTS5
```

## How Knowledge Improves
- **Consolidation** (every 6h): dedup, reconsolidation, mining, promotion, pruning
- **STDP/Hebbian**: Items retrieved together get linked (COACTIVATION edges)
- **Reward signal**: Task outcome propagates to informing knowledge items
- **Temporal decay**: Old items lose confidence unless reinforced

## Brain Dimensions (scoring)
| Dim | Name | Effect |
|-----|------|--------|
| D | Temporal decay | Old items decay unless reinforced |
| E | Wilson intervals | Confidence bounded by evidence count |
| A | Contradiction | Flagged items penalized |
| B | Agent trust | Per-agent reliability scoring |
| C | Provenance | Tracks capture → extraction → consolidation journey |
| F | Working memory | Recent retrievals get priority |

---
*Last updated: 2026-03-19 — v10.37.44 (Complete SQLite migration)*
