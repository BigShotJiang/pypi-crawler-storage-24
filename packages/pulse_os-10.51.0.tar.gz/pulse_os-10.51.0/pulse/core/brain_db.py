"""brain_db.py -- Runtime DB operations: connection, insert, upsert, search.

Schema constants and DDL (init_db, _KNOWLEDGE_COLS, _VALID_TABLES, etc.) live in
brain_db_schema.py.  Everything is re-exported here so all existing callers
continue to work unchanged.
"""
import math
import sqlite3
import threading
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional, List, Dict
from pulse.core.paths import get_state_dir, get_brain_dir
from pulse.core.brain_utils import _make_fingerprint as make_fingerprint
from pulse.core.brain_io import _acquire
from pulse.core.brain_db_schema import (
    _VALID_TABLES,
    _validate_table,
    _KNOWLEDGE_COLS,
    _knowledge_indexes,
    _tables_exist,
    init_db as _init_db_schema,
)

# Re-export schema symbols for backward compatibility.
__all__ = [
    "DB_PATH", "get_conn", "init_db", "force_checkpoint",
    "insert_knowledge", "upsert_knowledge", "bulk_upsert", "search",
    "_VALID_TABLES", "_validate_table", "_KNOWLEDGE_COLS",
    "_knowledge_indexes", "_tables_exist",
]

DB_PATH = get_brain_dir() / "pulse_brain.db"
_local = threading.local()
_db_initialized = False
_init_lock = threading.Lock()

# Item 55: Critical period tracking (P14 Neuroplasticity)
_CRITICAL_PERIOD_DOMAINS: dict = {}
_CRITICAL_PERIOD_SIZE = 10
# S37: protect _CRITICAL_PERIOD_DOMAINS mutations in hot path
_cp_lock = threading.Lock()


def force_checkpoint() -> bool:
    """Force a WAL TRUNCATE checkpoint. Returns True if no blockers."""
    try:
        conn = get_conn()
        result = conn.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
        return result is not None and result[0] == 0
    except Exception:
        return False


def get_conn() -> sqlite3.Connection:
    if not hasattr(_local, "conn"):
        DB_PATH.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(DB_PATH.resolve()), check_same_thread=False)
        try:
            import sqlite_vec
            conn.enable_load_extension(True)
            sqlite_vec.load(conn)
            conn.enable_load_extension(False)
        except Exception:
            pass
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA synchronous=NORMAL;")
        conn.execute("PRAGMA busy_timeout=60000;")  # P47 FIX: 60s (was 5s)
        conn.execute("PRAGMA wal_autocheckpoint=200;")
        conn.create_function("SQRT", 1, math.sqrt)
        conn.row_factory = sqlite3.Row
        _local.conn = conn
    global _db_initialized
    if not _db_initialized:
        # Fast path: skip heavy init_db if tables already exist.
        if _tables_exist(_local.conn):
            _db_initialized = True
        else:
            with _acquire(DB_PATH):
                with _init_lock:
                    if not _db_initialized:
                        if _tables_exist(_local.conn):
                            _db_initialized = True
                        else:
                            try:
                                init_db()
                                _db_initialized = True
                            except Exception:
                                raise
    return _local.conn


def init_db() -> None:
    """Create all tables and indexes. Uses the thread-local connection."""
    # Do NOT call get_conn() here -- causes infinite recursion
    _init_db_schema(_local.conn)


def insert_knowledge(table: str, data: Dict[str, Any]) -> Optional[str]:
    """Insert knowledge (idempotent via UNIQUE fingerprint)."""
    _validate_table(table)
    # BCM gate: suppress low-salience writes during high load
    try:
        signals = __import__("pulse.core.interoception", fromlist=["get_signals"]).get_signals()
        if signals.get("agent_load", 0) > 5 and float(data.get("salience", 1.0)) < 3.0:
            import logging as _bcm_log
            _bcm_log.getLogger("pulse.brain_db").debug("BCM gate: shedding low-salience item under load")
            return "bcm_shed"
    except Exception:
        pass
    conn = get_conn()
    content = data.get("content", "")
    fingerprint = data.get("fingerprint") or (make_fingerprint(content) if content else "null")
    item_id = data.get("id") or f"L-{fingerprint[:8]}"
    tags = json.dumps(data.get("tags", [])) if isinstance(data.get("tags"), list) else data.get("tags", "[]")
    cross_refs = json.dumps(data.get("cross_refs", [])) if isinstance(data.get("cross_refs"), list) else data.get("cross_refs", "[]")
    prov = json.dumps(data.get("_provenance", data.get("provenance", {})))
    meta = json.dumps(data.get("metadata", {})) if isinstance(data.get("metadata"), dict) else data.get("metadata", "{}")
    title = data.get("title", "")[:80]
    domain = data.get("domain", "general")
    agent = data.get("agent", "unknown")
    ts = data.get("timestamp", datetime.now(timezone.utc).isoformat())
    # Item 122: Catastrophic forgetting protection
    try:
        from pulse.core.forgetting_protection import protect_high_confidence
        item_id, fingerprint = protect_high_confidence(conn, table, fingerprint, item_id, ts)
    except Exception:
        pass

    import time as _time_mod
    for _retry in range(5):  # P47 FIX: 5 retries with longer backoff
        try:
            with conn:
                conn.execute(
                    f"INSERT OR IGNORE INTO {table} "
                    "(id, fingerprint, type, content, title, domain, agent, timestamp, "
                    "salience, confidence, consolidation_count, evidence_count, "
                    "access_count, decay_score, validity, tags, cross_refs, provenance, metadata) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (item_id, fingerprint, data.get("type", "lesson"), content,
                     title, domain, agent, ts,
                     float(data.get("salience", 1.0)), float(data.get("confidence", 0.5)),
                     int(data.get("consolidation_count", 1)), int(data.get("evidence_count", 1)),
                     int(data.get("access_count", 0)), float(data.get("decay_score", 1.0)),
                     data.get("validity", "valid"), tags, cross_refs, prov, meta))
                if conn.execute("SELECT changes()").fetchone()[0] > 0:
                    conn.execute(
                        "INSERT INTO knowledge_fts (item_id, content, title, domain, agent, table_name) "
                        "VALUES (?, ?, ?, ?, ?, ?)",
                        (item_id, content, title, domain, agent, table))
            break
        except sqlite3.OperationalError as _db_err:
            if "database is locked" in str(_db_err) and _retry < 4:
                _time_mod.sleep(2.0 * (_retry + 1))  # P47 FIX: backoff 2s, 4s, 6s, 8s
                continue
            raise
    # Item 55: Critical period for new domains (P14 Neuroplasticity)
    try:
        with _cp_lock:
            if domain not in _CRITICAL_PERIOD_DOMAINS:
                existing = conn.execute(f"SELECT COUNT(*) FROM {table} WHERE domain=?", (domain,)).fetchone()[0]
                if existing <= 1:
                    _CRITICAL_PERIOD_DOMAINS[domain] = _CRITICAL_PERIOD_SIZE
            if _CRITICAL_PERIOD_DOMAINS.get(domain, 0) > 0:
                conn.execute(f"UPDATE {table} SET salience=MIN(salience*2.0,10.0) WHERE id=?", (item_id,))
                conn.commit()
                _CRITICAL_PERIOD_DOMAINS[domain] -= 1
                if _CRITICAL_PERIOD_DOMAINS[domain] <= 0:
                    del _CRITICAL_PERIOD_DOMAINS[domain]
    except Exception:
        pass
    # F23: sub-threshold trace -- 3+ low-salience appearances -> promote
    try:
        row = conn.execute(
            f"SELECT salience, consolidation_count FROM {table} WHERE fingerprint = ?",
            (fingerprint,)).fetchone()
        if row and 0.1 <= float(row["salience"]) <= 0.4 and int(row["consolidation_count"]) >= 3:
            with conn:
                conn.execute(f"UPDATE {table} SET salience = 1.0 WHERE fingerprint = ?", (fingerprint,))
    except Exception:
        pass

    return item_id


def upsert_knowledge(table: str, data: dict) -> bool:
    """INSERT OR REPLACE a knowledge item into SQLite + FTS. For consolidation rewrites."""
    _validate_table(table)
    conn = get_conn()
    content = data.get("content", "")
    fp = data.get("fingerprint") or (make_fingerprint(content) if content else "null")
    item_id = data.get("id") or f"L-{fp[:8]}"
    tags = json.dumps(data.get("tags", [])) if isinstance(data.get("tags"), list) else data.get("tags", "[]")
    xrefs = json.dumps(data.get("cross_refs", [])) if isinstance(data.get("cross_refs"), list) else data.get("cross_refs", "[]")
    prov = json.dumps(data.get("_provenance", data.get("provenance", {})))
    meta = json.dumps(data.get("metadata", {})) if isinstance(data.get("metadata"), dict) else data.get("metadata", "{}")
    import time as _t
    for _retry in range(3):
        try:
            with conn:
                conn.execute(
                    f"INSERT OR REPLACE INTO {table} "
                    "(id, fingerprint, type, content, title, domain, agent, timestamp, "
                    "salience, confidence, consolidation_count, evidence_count, "
                    "access_count, decay_score, validity, tags, cross_refs, provenance, metadata) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (item_id, fp, data.get("type", "lesson"), content,
                     data.get("title", "")[:80], data.get("domain", "general"),
                     data.get("agent", "unknown"),
                     data.get("timestamp", datetime.now(timezone.utc).isoformat()),
                     float(data.get("salience", 1.0)), float(data.get("confidence", 0.5)),
                     int(data.get("consolidation_count", 1)), int(data.get("evidence_count", 1)),
                     int(data.get("access_count", 0)), float(data.get("decay_score", 1.0)),
                     data.get("validity", "valid"), tags, xrefs, prov, meta))
                conn.execute("DELETE FROM knowledge_fts WHERE item_id = ? AND table_name = ?",
                             (item_id, table))
                conn.execute(
                    "INSERT INTO knowledge_fts (item_id, content, title, domain, agent, table_name) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (item_id, content, data.get("title", "")[:80],
                     data.get("domain", "general"), data.get("agent", "unknown"), table))
            return True
        except sqlite3.OperationalError as _e:
            if "database is locked" in str(_e) and _retry < 2:
                _t.sleep(1.0 * (_retry + 1))
                continue
            return False
    return False

# bulk_upsert and search extracted to brain_db_helpers.py for Law 7 compliance.
from .brain_db_helpers import bulk_upsert, search