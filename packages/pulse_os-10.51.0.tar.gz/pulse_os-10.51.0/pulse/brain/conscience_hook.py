"""Backward-compat shim — moved to pulse.brain.integrity.conscience_hook."""
from pulse.brain.integrity.conscience_hook import *  # noqa: F401,F403
from pulse.brain.integrity.conscience_hook import _log, CONSCIENCE_LOG
