"""Plasticity subpackage -- STDP, Hebbian, reconsolidation, spaced retrieval, resurrection."""

# --- stdp.py ---
from pulse.brain.plasticity.stdp import (  # noqa: F401
    apply_stdp,
    _get_bcm_theta,
    _check_burst,
    _apply_reward_modulation,
    LTP_DELTA,
    LTD_DELTA,
    ANTI_CAUSAL_RATIO,
    TEMPORAL_WINDOW_S,
    SESSIONS_FILE,
    STDP_DIR,
    # Re-exported from stdp_hebbian via stdp.py:
    record_retrieval,
    _check_monopoly,
    _upsert_temporal_edge,
    apply_triplet_shortcuts,
)

# --- stdp_hebbian.py ---
from pulse.brain.plasticity.stdp_hebbian import (  # noqa: F401
    _ELIGIBILITY_TRACE,
    _SILENT_SYNAPSE_THRESHOLD,
)

# --- stdp_annealing.py ---
from pulse.brain.plasticity.stdp_annealing import (  # noqa: F401
    apply_stdp_with_annealing,
    compute_failure_ltd,
    get_maturity_state, # Updated to use the new function
)

# --- hebbian_knowledge.py ---
from pulse.brain.plasticity.hebbian_knowledge import (  # noqa: F401
    record_coactivation,
    apply_hebbian,
    _upsert_coact_edge,
    _normalize_outgoing_edges,
    COACT_FILE,
    HEBBIAN_LTP,
    HEBBIAN_LTD,
    MIN_COACT_ITEMS,
    MAX_OUTGOING_WEIGHT_SUM,
)

# --- reconsolidation.py ---
from pulse.brain.plasticity.reconsolidation import (  # noqa: F401
    get_domain_plasticity,
    get_reconsolidation_health,
    _get_labile_count,
    _get_reconsolidation_health,
    CRITICAL_PERIOD_MIDPOINT,
    CRITICAL_PERIOD_STEEPNESS,
    MIN_PLASTICITY,
    # Re-exported from reconsolidation_labile via reconsolidation.py:
    mark_labile,
    reinforce,
    contradict,
    tombstone_item,
    _sweep_expired,
    _resolve_superseded_chain,
    LABILE_ITEMS_FILE,
    TTL_SECONDS,
    _VALID_TABLES,
)

# --- reconsolidation_labile.py ---
from pulse.brain.plasticity.reconsolidation_labile import (  # noqa: F401
    _TABLE_TTL,
    _get_ttl,
    _lock,
    _labile_state,
)

# --- spaced_retrieval.py ---
from pulse.brain.plasticity.spaced_retrieval import (  # noqa: F401
    schedule_item,
    mark_recalled,
    get_due_items,
    get_due_domains,
    _schedule_next_retrieval,
)

# --- resurrection.py ---
from pulse.brain.plasticity.resurrection import (  # noqa: F401
    log_pruned,
    check_resurrection,
    register_resurrection_subscriber,
    _on_resurrection_event,
)
