"""Brain index subpackage: search index, rule embeddings, episodic index/writer, search utils."""

from pulse.brain.index.search_index import build_index, query_index, INDEX_FILE
from pulse.brain.index.rule_embeddings import (
    build_rule_index, search_similar, get_new_rules, embed_texts,
    EMBED_INDEX_FILE, EMBED_MODEL,
)
from pulse.brain.index.episodic_index import (
    append_entry, load_index, EPISODIC_INDEX_FILE,
)
from pulse.brain.index.episodic_writer import save_episode, build_session_summary
from pulse.brain.index.search_utils import (
    compute_salience, days_since, get_retrieval_count, SOURCE_WEIGHT,
)
