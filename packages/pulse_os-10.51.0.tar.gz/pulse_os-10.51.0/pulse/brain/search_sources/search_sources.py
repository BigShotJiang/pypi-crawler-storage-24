#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
# See LICENSE file for details.
"""
Brain Search Sources: Re-export all search functions (V43.13)

This module re-exports all search functions from the split modules.
Import from here to maintain backward compatibility.

Dependencies: search_sources_core + search_sources_ext
"""

import json
from .search_sources_core import search_anti_patterns, search_evidence, search_predictions
from .search_sources_ext import (
    search_wins, search_fails, search_domains, search_private,
    search_patterns, search_schemas, search_graph, search_procedures,
    search_meta_schemas,
)
from .search_sources_facts import search_facts
from .search_sources_episodic import search_episodic
from .search_sources_decisions import search_decisions
from .search_sources_capture import search_capture_log

def search_working_memory(query: str, config: dict = None) -> list:
    """Search current agent's working memory session for query matches."""
    try:
        from pulse.core.brain_analysis import text_similarity
        from pulse.brain.memory.working_memory import WORKING_MEMORY_DIR
        query_lower = query.lower().strip()
        if not query_lower:
            return []
        # Search all active sessions (any agent)
        all_items = []
        for sf in WORKING_MEMORY_DIR.glob("*_session.json"):
            try:
                sd = json.loads(sf.read_text(encoding="utf-8"))
                all_items.extend(sd.get("items", []))
            except Exception:
                continue
        hits = []
        for it in all_items:
            text = it.get("text", "")
            sim = text_similarity(query_lower[:80], text[:80].lower())
            if sim < 0.3:
                continue
            hits.append({
                "text": text[:200],
                "source": "working_memory",
                "salience": round(it.get("salience", 1.0) * sim * 2, 3),
                "confidence": 0.9,
                "accessed_count": it.get("accessed_count", 1),
            })
        hits.sort(key=lambda h: h["salience"], reverse=True)
        return hits[:10]
    except Exception:
        return []


__all__ = [
    "search_anti_patterns",
    "search_predictions",
    "search_wins",
    "search_fails",
    "search_domains",
    "search_patterns",
    "search_evidence",
    "search_private",
    "search_schemas",
    "search_procedures",
    "search_graph",
    "search_facts",
    "search_episodic",
    "search_working_memory",
    "search_decisions",
    "search_capture_log",
]
