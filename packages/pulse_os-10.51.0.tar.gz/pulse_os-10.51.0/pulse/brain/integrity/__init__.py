"""Integrity subpackage: gates, grounding, provenance, conscience, self-check."""

from pulse.brain.integrity.gate_checks import (
    gate1_anti_pattern,
    gate1_graded,
    gate2_failure_scan,
    gate4_decision_conflict,
    gate5_temporal_advisory,
    _extract_keywords,
    _keyword_overlap,
    _query_anti_patterns,
    _format_ap_block,
    _graded_gate_result,
    _is_relevant_to_content,
)
from pulse.brain.integrity.anti_pattern_gate import (
    main as gate_main,
    gate3_prediction_alert,
    _check_gate,
    _extract_content,
    _extract_file_path,
)
from pulse.brain.integrity.grounding import (
    maybe_promote,
    maybe_demote,
    RETRIEVAL_THRESHOLD,
    MAX_GROUND_EVENTS,
)
from pulse.brain.integrity.provenance import (
    append_provenance,
    get_provenance,
    trace_by_source,
)
from pulse.brain.integrity.conscience_hook import (
    audit_reasoning,
    audit_brain_write,
)
from pulse.brain.integrity.self_check import (
    verify_output,
    check_and_warn,
)
from pulse.brain.integrity.graph_rag_extractor import (
    extract_graph_rag_concepts,
)

__all__ = [
    # gate_checks
    "gate1_anti_pattern",
    "gate1_graded",
    "gate2_failure_scan",
    "gate4_decision_conflict",
    "gate5_temporal_advisory",
    # anti_pattern_gate
    "gate_main",
    "gate3_prediction_alert",
    # grounding
    "maybe_promote",
    "maybe_demote",
    "RETRIEVAL_THRESHOLD",
    "MAX_GROUND_EVENTS",
    # provenance
    "append_provenance",
    "get_provenance",
    "trace_by_source",
    # conscience_hook
    "audit_reasoning",
    "audit_brain_write",
    # self_check
    "verify_output",
    "check_and_warn",
    # graph_rag_extractor
    "extract_graph_rag_concepts",
]
