#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""Entry-point shim — delegates to brain_query/ package. Import via package only."""

import os
import sys
from pathlib import Path

# Windows Unicode fix — use reconfigure() to avoid replacing the stream object.
# Replacing sys.stdout/stderr corrupts terminal state when this runs as a hook
# subprocess alongside an active terminal session (causes numbers to glitch CLI).
if os.name == 'nt' and __name__ == '__main__' and hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')

# Ensure pulse package is importable when run directly
SCRIPT_DIR = Path(__file__).resolve().parent
ROOT_DIR = SCRIPT_DIR.parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from pulse.brain.brain_query import main

if __name__ == "__main__":
    try:
        main()
    except Exception:
        pass  # Never crash, never block agent
    sys.exit(0)
