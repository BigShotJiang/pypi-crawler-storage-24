# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""Session subpackage — session lifecycle, checkpoints, context, and cross-agent learning."""

from pulse.brain.session.session_lifecycle import (
    start_session,
    record_turn,
    end_session,
    get_recent_sessions,
    get_active_session,
    _get_session_turns,
    _record_interaction,
)
from pulse.brain.session.session_context import build_recent_sessions_context
_build_recent_sessions_context = build_recent_sessions_context  # backward compat alias
from pulse.brain.session.session_checkpoint import (
    save_checkpoint,
    load_latest_checkpoint,
)
from pulse.brain.session.context_envelope import get_context_envelope
from pulse.brain.session.cross_agent import (
    format_agent_tag,
    extract_cross_agent_intel,
)

__all__ = [
    "start_session",
    "record_turn",
    "end_session",
    "get_recent_sessions",
    "get_active_session",
    "_get_session_turns",
    "build_recent_sessions_context",
    "_build_recent_sessions_context",  # backward compat alias
    "_record_interaction",
    "save_checkpoint",
    "load_latest_checkpoint",
    "get_context_envelope",
    "format_agent_tag",
    "extract_cross_agent_intel",
]
