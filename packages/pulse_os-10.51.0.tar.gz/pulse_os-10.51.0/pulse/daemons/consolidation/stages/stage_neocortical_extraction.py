# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""
Phase C Item 15: Neocortical Semantic Extraction.
Physically moves heavily-consolidated, mature facts out of the Hippocampus 
into a stable Corpus_Callosum/Semantic long-term storage directory.
"""
import json
import logging
from pathlib import Path
from pulse.core.brain_db import get_conn
from pulse.core.brain_utils import ROOT_DIR

log = logging.getLogger("pulse.consolidation.neocortical")

SEMANTIC_DIR = ROOT_DIR / "Corpus_Callosum" / "Semantic"

def stage_neocortical_extraction(verbose: bool = False) -> dict:
    """
    Extracts highly consolidated (consolidation_count >= 5, confidence > 0.9)
    facts from the SQLite database and persists them as stable markdown/json 
    in the Corpus_Callosum, mirroring Neocortical slow-learning storage.
    """
    if verbose: log.info(f"[NEOCORTICAL DEBUG] ROOT_DIR: {ROOT_DIR}")
    SEMANTIC_DIR.mkdir(parents=True, exist_ok=True)
    conn = get_conn()
    
    extracted = 0
    try:
        # Find highly consolidated facts
        if verbose: log.info(f"[NEOCORTICAL DEBUG] Executing SELECT query...")
        rows = conn.execute("""
            SELECT id, title, content, domain, confidence, consolidation_count, timestamp
            FROM facts
            WHERE consolidation_count >= 5 AND confidence >= 0.9 AND validity = 'valid'
        """).fetchall()
        
        if verbose: log.info(f"[NEOCORTICAL DEBUG] Query returned {len(rows)} rows.")
        for row in rows:
            if verbose: log.info(f"[NEOCORTICAL DEBUG] Processing fact: id={row['id']}, conf={row['confidence']}, cons_count={row['consolidation_count']}")
            fact_id = row["id"]
            domain = row["domain"] or "general"
            domain_file = SEMANTIC_DIR / f"{domain.lower().replace(' ', '_')}.json"
            
            # Load existing domain semantic memory
            semantic_data = []
            if domain_file.exists():
                try:
                    semantic_data = json.loads(domain_file.read_text(encoding="utf-8"))
                except Exception:
                    pass
                    
            # Check if already extracted
            if any(f.get("id") == fact_id for f in semantic_data):
                continue
                
            # Append new semantic memory
            semantic_data.append({
                "id": fact_id,
                "title": row["title"],
                "content": row["content"],
                "confidence": float(row["confidence"]),
                "consolidations": int(row["consolidation_count"]),
                "extracted_at": row["timestamp"]
            })
            
            # Save to Neocortex (Corpus_Callosum)
            domain_file.write_text(json.dumps(semantic_data, indent=2), encoding="utf-8")
            
            # Update Hippocampus (SQLite) validity to permanent (moved to neocortex)
            with conn:
                conn.execute("UPDATE facts SET validity = 'permanent' WHERE id = ?", (fact_id,))
                
            extracted += 1
            if verbose:
                log.info(f"Extracted semantic fact to Neocortex: {row['title']}")
                
        return {"facts_extracted": extracted, "status": "success"}
    except Exception as e:
        log.warning(f"Neocortical extraction failed: {e}")
        return {"facts_extracted": 0, "status": "error"}
