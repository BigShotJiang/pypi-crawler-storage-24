# Copyright (c) 2026 PULSE Contributors. Proprietary.
"""Distiller daemon — offline batch knowledge extraction."""
from pulse.daemons.distiller.distiller_cli import run, main

__all__ = ["run", "main"]
