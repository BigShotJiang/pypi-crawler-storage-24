# -- coding: utf-8 --
# Project: fiuai_sdk_agent
# Created Date: 2026-03-17
# Author: liming
# Agent: Cursor
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

"""
LLMModelResolver - 模型偏好解析器

将请求级模型偏好 (auto/high/normal/具体模型名) 解析为 LLMModel

设计要点:
- 基类提供默认 tier -> 模型映射 (high -> QWEN_MAX, normal -> QWEN_PLUS)
- 子类通过覆盖类属性自定义各 agent 的映射
- resolve() 始终返回具体 LLMModel, 不返回 None

使用方式:
    # 1. 直接使用默认解析
    model = LLMModelResolver.resolve("high")  # -> QWEN_MAX

    # 2. Agent/Expert 自定义子类
    class TaxModelResolver(LLMModelResolver):
        HIGH_MODEL = LLMModel.QWEN_MAX
        DEFAULT_MODEL = LLMModel.QWEN_PLUS

    model = TaxModelResolver.resolve("auto")  # -> QWEN_PLUS (TaxExpert 自身默认)
"""

import logging
from typing import ClassVar

from .types import LLMModel

logger = logging.getLogger(__name__)

# 预设 tier 常量 (与 core/runtime.py 中一致, 此处冗余定义避免跨层依赖)
_TIER_AUTO = "auto"
_TIER_HIGH = "high"
_TIER_NORMAL = "normal"


class LLMModelResolver:
    """
    模型偏好解析器基类

    各 Agent/Expert 继承后覆盖 HIGH_MODEL / NORMAL_MODEL / DEFAULT_MODEL 即可自定义映射

    Attributes:
        HIGH_MODEL: high tier 对应的模型
        NORMAL_MODEL: normal tier 对应的模型
        DEFAULT_MODEL: auto 及 fallback 时使用的模型
    """

    HIGH_MODEL: ClassVar[LLMModel] = LLMModel.QWEN_MAX
    NORMAL_MODEL: ClassVar[LLMModel] = LLMModel.QWEN_PLUS
    DEFAULT_MODEL: ClassVar[LLMModel] = LLMModel.QWEN_PLUS

    @classmethod
    def resolve(cls, llm_model: str) -> LLMModel:
        """
        将模型偏好解析为具体 LLMModel

        优先级:
        1. auto → cls.DEFAULT_MODEL (agent 自身默认)
        2. high → cls.HIGH_MODEL
        3. normal → cls.NORMAL_MODEL
        4. 其他 → 匹配 LLMModel 枚举值; 不支持则 warning + cls.DEFAULT_MODEL

        Args:
            llm_model: 偏好值 (来自 x-fiuai-model header 或代码指定)

        Returns:
            始终返回具体的 LLMModel
        """
        if not llm_model or llm_model == _TIER_AUTO:
            return cls.DEFAULT_MODEL

        if llm_model == _TIER_HIGH:
            return cls.HIGH_MODEL

        if llm_model == _TIER_NORMAL:
            return cls.NORMAL_MODEL

        # 尝试匹配 LLMModel 枚举值 (如 "qwen-max", "deepseek-v3.2-exp")
        for model_enum in LLMModel:
            if model_enum.value == llm_model:
                return model_enum

        logger.warning(
            f"Unsupported llm_model '{llm_model}', "
            f"falling back to default {cls.DEFAULT_MODEL.value}"
        )
        return cls.DEFAULT_MODEL
