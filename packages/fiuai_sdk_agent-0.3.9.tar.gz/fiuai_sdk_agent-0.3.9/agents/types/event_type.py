# -- coding: utf-8 --
# Project: fiuai-sdk-agent
# Created Date: 2025-01-30
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

"""
Event 类型定义

设计原则:
- EventType 表示"行为语义"(前端怎么处理), 保持稳定(8种)
- EventContext 表示"路由目标"(消息显示在哪里)
- data 是类型化对象, 不是字符串
"""

from enum import StrEnum
from typing import Any, Optional, Dict
from datetime import datetime
from pydantic import BaseModel, Field

from fiuai_sdk_python.utils.ids import gen_id


# Redis Stream 配置
TASK_EVENT_STREAM_KEY_PREFIX = "task:events"


class EventType(StrEnum):
    """
    事件类型枚举
    
    设计原则: EventType 表示前端的"处理行为", 而非"内容类型"
    - 内容类型通过 artifact_type 扩展
    - 决策类型通过 decision_type 扩展
    """
    # 流式文本(前端增量渲染)
    CHUNK = "chunk"
    # 计划更新(前端更新 Plan 组件)
    PLAN = "plan"
    # 待决策(前端显示决策 UI, 系统暂停等待)
    INTERRUPT = "interrupt"
    # 任务终态(前端处理结束逻辑)
    TASK = "task"
    # 内容展示(前端渲染各类内容)
    ARTIFACT = "artifact"
    # 瞬态进度状态(前端渲染活动指示器, 不记录对话历史)
    PROGRESS = "progress"
    # 任务建议卡片(前端渲染可操作按钮, 点击弹 modal 提交后跳转 Task 页面)
    TASK_CARD = "task_card"
    # 心跳(传输层, 不进入业务逻辑)
    HEARTBEAT = "heartbeat"


class EventContext(BaseModel):
    """
    事件路由上下文
    
    决定消息显示在哪里:
    - 有 plan_id + step_id -> 显示在 Plan 组件的特定 Step
    - 有 plan_id -> 显示在 Plan 组件
    - 无 context -> 显示在主窗口
    """
    plan_id: Optional[str] = Field(default=None, description="关联的计划 ID")
    step_id: Optional[str] = Field(default=None, description="关联的步骤 ID")
    step_index: Optional[int] = Field(default=None, description="步骤索引")
    step_status: Optional[str] = Field(default=None, description="步骤状态")


class Event(BaseModel):
    """
    事件基类
    
    结构简化:
    - data 是类型化对象, 不是字符串
    - context 统一承载路由信息
    - 删除 metadata, tags, ttl 等冗余字段
    """
    id: str = Field(default_factory=gen_id, description="事件 ID")
    type: EventType = Field(description="事件类型")
    timestamp: datetime = Field(default_factory=datetime.now, description="时间戳")
    data: Any = Field(description="事件数据(类型化)")
    context: Optional[EventContext] = Field(default=None, description="路由上下文")


# ============================================================================
# 各事件类型的数据结构
# ============================================================================

class ChunkPurpose(StrEnum):
    """CHUNK 文本的意图"""
    REPLY = "reply"       # 正式回复 (默认; 主窗口终态内容)
    THINKING = "thinking"  # 思考/推理过程 (可折叠; Step 内过程文本)
    SUMMARY = "summary"   # 步骤总结 (Step 内结论文本)


class ChunkData(BaseModel):
    """
    CHUNK 事件数据

    流式文本块, 前端增量渲染; purpose 决定渲染位置与样式
    """
    content: str = Field(description="文本内容")
    done: bool = Field(default=False, description="True 表示这段文本结束")
    purpose: str = Field(
        default=ChunkPurpose.REPLY,
        description="文本意图: reply/thinking/summary",
    )


class TaskStatus(StrEnum):
    """任务状态"""
    SUCCESS = "success"
    FAILED = "failed"
    CANCELLED = "cancelled"
    WARNING = "warning"


class TaskData(BaseModel):
    """
    TASK 事件数据
    
    任务终态, 前端处理结束逻辑
    """
    status: TaskStatus = Field(description="任务状态")
    message: str = Field(default="", description="状态消息")


class TaskCardData(BaseModel):
    """
    TASK_CARD 事件数据
    
    任务建议卡片, 前端渲染为可操作按钮 (我猜你想... 点击执行)
    """
    task_name: str = Field(description="任务名称 (POST /task 的 task_name)")
    capability: str = Field(description="Capability 标识")
    title: str = Field(description="卡片标题 (如 '开票规划')")
    description: str = Field(description="建议描述 (如 '检测到您想进行开票操作')")
    suggested_context: Dict[str, Any] = Field(
        default_factory=dict,
        description="从对话中提取的上下文 (前端可用于预填 form)",
    )


# ============================================================================
# 兼容性: 旧版 EventData 格式(用于 Redis Stream 序列化)
# ============================================================================

class EventData(BaseModel):
    """
    事件序列化格式(用于 Redis Stream)
    
    保持与旧版兼容的字段结构, 但内部使用新的类型系统
    """
    event_id: str = Field(description="事件 ID")
    timestamp: datetime = Field(default_factory=datetime.now, description="事件时间")
    event_type: str = Field(description="事件类型")
    plan_id: Optional[str] = Field(default=None, description="计划 ID")
    step_id: Optional[str] = Field(default=None, description="步骤 ID")
    step_index: Optional[int] = Field(default=None, description="步骤索引")
    step_status: Optional[str] = Field(default=None, description="步骤状态")
    data: Any = Field(description="事件数据")
    
    @classmethod
    def from_event(cls, event: Event) -> "EventData":
        """从 Event 转换为 EventData(序列化格式)"""
        context = event.context or EventContext()
        return cls(
            event_id=event.id,
            timestamp=event.timestamp,
            event_type=event.type.value,
            plan_id=context.plan_id,
            step_id=context.step_id,
            step_index=context.step_index,
            step_status=context.step_status,
            data=event.data.model_dump() if isinstance(event.data, BaseModel) else event.data,
        )
