# -- coding: utf-8 --
# Project: fiuai_sdk_agent
# Created Date: 2026-03-10
# Author: liming
# Agent: Cursor
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

"""
Capability - 产品能力定义

产品视角的业务场景描述, 用于:
- Router LLM 受限分类 (description 字段)
- PlanFactory 按 Capability 注册 SOP
- 跨域 Expert 编排 (domains 字段)
- 场景特有业务规则传递 (knowledge 字段)
"""

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field, model_validator


class RequiredParam(BaseModel):
    """Capability 前置必填参数定义, 用于 task_name 映射时的表单/上下文校验."""

    name: str = Field(description="参数键名")
    type: Literal["str", "list", "dict", "number", "bool"] = Field(
        default="str",
        description="期望类型, 用于校验",
    )
    description: str = Field(
        default="",
        description="参数说明, 用于生成追问文案",
    )


class Capability(BaseModel):
    """
    产品能力定义

    一个 Capability 代表一个用户可感知的业务场景,
    可能跨多个 Expert domain, 可有预设 SOP 也可由 LLM 动态编排。

    Attributes:
        name: 能力唯一标识 (如 "data_query", "tax_declaration")
        description: 能力描述, Router LLM 分类时使用
        intent_type: 所属意图大类 (QUERY / TASK / CHAT)
        domains: 涉及的领域列表 (如 ["data", "finance"])
        knowledge: 该能力特有的业务规则, 注入 Plan.metadata 供 Expert 共享
        has_sop: 是否有预设 SOP (False 时走 LLM 动态 Plan)
    """

    name: str = Field(description="能力唯一标识")
    description: str = Field(description="能力描述, Router LLM 分类用")
    intent_type: str = Field(description="所属意图大类 (QUERY / TASK / CHAT)")
    domains: List[str] = Field(default_factory=list, description="涉及的领域列表")
    knowledge: Dict[str, Any] = Field(
        default_factory=dict,
        description="该能力特有的业务规则",
    )
    has_sop: bool = Field(default=True, description="是否有预设 SOP")
    tags: Optional[List[str]] = Field(
        default=None,
        description="标签, 用于分组和筛选",
    )
    # 按钮/Form 场景: Plan 创建前必须提供的参数 (名称 + 类型 + 追问文案)
    # 由 Intent 层做前置检查, 缺则 need_clarification 追问
    required_params: Optional[List[RequiredParam]] = Field(
        default=None,
        description="前置必填参数, 用于 task_name 映射时的表单/上下文校验",
    )

    @model_validator(mode="before")
    @classmethod
    def _normalize_required_params(cls, data: Any) -> Any:
        """兼容 List[str]: 自动转为 List[RequiredParam]."""
        if not isinstance(data, dict):
            return data
        params = data.get("required_params")
        if not params or not isinstance(params, list):
            return data
        normalized = []
        for p in params:
            if isinstance(p, str):
                normalized.append({"name": p, "type": "str", "description": ""})
            elif isinstance(p, dict) and "name" in p:
                normalized.append(p)
        if normalized:
            data["required_params"] = normalized
        return data
