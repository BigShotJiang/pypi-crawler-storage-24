# -- coding: utf-8 --
# Project: fiuai_sdk_agent
# Created Date: 2026-03-10
# Author: liming
# Agent: Cursor
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

"""
KnowledgeRegistry - 领域知识注册中心

按 domain 组织领域知识, 替代全局 StaticKnowledge 单例。
每个 Expert 通过 KnowledgeRegistry.get(domain) 获取自己领域的知识。

使用示例:
    # 定义领域知识
    class DataDomainKnowledge(DomainKnowledge):
        domain: str = "data"
        docytypes: DoctypeOverview
        doctype_metas: Dict[str, DocTypeMeta]

    # 注册
    KnowledgeRegistry.register(DataDomainKnowledge(...))

    # Expert 中使用
    knowledge = KnowledgeRegistry.get("data")
"""

from typing import Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from ..utils.logger import get_logger

logger = get_logger(__name__)


class DomainKnowledge(BaseModel):
    """
    领域知识基类

    每个 domain 的知识子类继承此基类, 自由扩展字段。

    Attributes:
        domain: 领域标识 (如 "data", "tax", "finance")
    """

    domain: str = Field(description="领域标识")
    model_config = ConfigDict(extra="allow")


class KnowledgeRegistry:
    """
    领域知识注册中心

    按 domain 管理领域知识, Expert 通过 get(domain) 获取。
    """

    _knowledge: Dict[str, DomainKnowledge] = {}

    @classmethod
    def register(cls, knowledge: DomainKnowledge) -> None:
        """
        注册领域知识

        Args:
            knowledge: DomainKnowledge 实例
        """
        if knowledge.domain in cls._knowledge:
            logger.warning(
                f"KnowledgeRegistry: overwriting knowledge for domain '{knowledge.domain}'"
            )
        cls._knowledge[knowledge.domain] = knowledge
        logger.debug(f"Registered knowledge for domain: {knowledge.domain}")

    @classmethod
    def get(cls, domain: str) -> Optional[DomainKnowledge]:
        """
        按 domain 获取领域知识

        Args:
            domain: 领域标识

        Returns:
            DomainKnowledge 实例, 未注册则返回 None
        """
        return cls._knowledge.get(domain)

    @classmethod
    def get_all(cls) -> List[DomainKnowledge]:
        """获取所有已注册的领域知识"""
        return list(cls._knowledge.values())

    @classmethod
    def has(cls, domain: str) -> bool:
        """检查 domain 是否有注册知识"""
        return domain in cls._knowledge

    @classmethod
    def clear(cls) -> None:
        """清空所有注册的知识 (主要用于测试)"""
        cls._knowledge.clear()
