def foo():
    return "foo"
