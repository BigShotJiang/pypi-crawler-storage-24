"""Tests for web dashboard."""
