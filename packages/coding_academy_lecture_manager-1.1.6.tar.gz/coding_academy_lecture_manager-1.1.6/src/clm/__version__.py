"""Version information for CLM."""

__version__ = "1.1.6"
