# pyright: reportUnsupportedDunderAll=false

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .bash import Bash
    from .cala import CalaSearch
    from .edit import Edit
    from .firecrawl import FirecrawlCrawl, FirecrawlExtract, FirecrawlMap, FirecrawlScrape, FirecrawlSearch
    from .gmail import GmailAddLabel, GmailListLabels, GmailRemoveLabel, GmailReply, GmailSearch, GmailSend
    from .google_maps import (
        GoogleMapsNearbySearch,
        GoogleMapsPlaceDetails,
        GoogleMapsTextSearch,
        GoogleMapsValidateAddress,
    )
    from .outlook import (
        OutlookArchive,
        OutlookCreateDraft,
        OutlookForward,
        OutlookGetAttachments,
        OutlookReadEmails,
        OutlookSend,
        OutlookTrash,
        OutlookUpdateEmail,
    )
    from .pinecone import (
        PineconeCreateIndex,
        PineconeDeleteVectors,
        PineconeFetchVectors,
        PineconeIndexStats,
        PineconeListIndexes,
        PineconeQuery,
        PineconeUpsertVectors,
    )
    from .read import Read
    from .scraperapi import (
        ScraperAPIAmazonProduct,
        ScraperAPIAmazonSearch,
        ScraperAPIAsyncScrape,
        ScraperAPIGoogleSearch,
        ScraperAPIScrape,
    )
    from .tavily import TavilyCrawl, TavilyExtract, TavilyMap, TavilySearch
    from .web_search import WebSearch
    from .write import Write

__all__ = [
    "Bash",
    "CalaSearch",
    "Edit",
    "FirecrawlCrawl",
    "FirecrawlExtract",
    "FirecrawlMap",
    "FirecrawlScrape",
    "FirecrawlSearch",
    "GmailAddLabel",
    "GmailListLabels",
    "GmailRemoveLabel",
    "GmailReply",
    "GmailSearch",
    "GmailSend",
    "GoogleMapsNearbySearch",
    "GoogleMapsPlaceDetails",
    "GoogleMapsTextSearch",
    "GoogleMapsValidateAddress",
    "OutlookArchive",
    "OutlookCreateDraft",
    "OutlookForward",
    "OutlookGetAttachments",
    "OutlookReadEmails",
    "OutlookSend",
    "OutlookTrash",
    "OutlookUpdateEmail",
    "PineconeCreateIndex",
    "PineconeDeleteVectors",
    "PineconeFetchVectors",
    "PineconeIndexStats",
    "PineconeListIndexes",
    "PineconeQuery",
    "PineconeUpsertVectors",
    "Read",
    "ScraperAPIAmazonProduct",
    "ScraperAPIAmazonSearch",
    "ScraperAPIAsyncScrape",
    "ScraperAPIGoogleSearch",
    "ScraperAPIScrape",
    "TavilyCrawl",
    "TavilyExtract",
    "TavilyMap",
    "TavilySearch",
    "WebSearch",
    "Write",
]

_LAZY_IMPORTS = {
    "Bash": ".bash",
    "CalaSearch": ".cala",
    "Edit": ".edit",
    "FirecrawlCrawl": ".firecrawl",
    "FirecrawlExtract": ".firecrawl",
    "FirecrawlMap": ".firecrawl",
    "FirecrawlScrape": ".firecrawl",
    "FirecrawlSearch": ".firecrawl",
    "GmailAddLabel": ".gmail",
    "GmailListLabels": ".gmail",
    "GmailRemoveLabel": ".gmail",
    "GmailReply": ".gmail",
    "GmailSearch": ".gmail",
    "GmailSend": ".gmail",
    "GoogleMapsNearbySearch": ".google_maps",
    "GoogleMapsPlaceDetails": ".google_maps",
    "GoogleMapsTextSearch": ".google_maps",
    "GoogleMapsValidateAddress": ".google_maps",
    "OutlookArchive": ".outlook",
    "OutlookCreateDraft": ".outlook",
    "OutlookForward": ".outlook",
    "OutlookGetAttachments": ".outlook",
    "OutlookReadEmails": ".outlook",
    "OutlookSend": ".outlook",
    "OutlookTrash": ".outlook",
    "OutlookUpdateEmail": ".outlook",
    "PineconeCreateIndex": ".pinecone",
    "PineconeDeleteVectors": ".pinecone",
    "PineconeFetchVectors": ".pinecone",
    "PineconeIndexStats": ".pinecone",
    "PineconeListIndexes": ".pinecone",
    "PineconeQuery": ".pinecone",
    "PineconeUpsertVectors": ".pinecone",
    "Read": ".read",
    "ScraperAPIAmazonProduct": ".scraperapi",
    "ScraperAPIAmazonSearch": ".scraperapi",
    "ScraperAPIAsyncScrape": ".scraperapi",
    "ScraperAPIGoogleSearch": ".scraperapi",
    "ScraperAPIScrape": ".scraperapi",
    "TavilyCrawl": ".tavily",
    "TavilyExtract": ".tavily",
    "TavilyMap": ".tavily",
    "TavilySearch": ".tavily",
    "WebSearch": ".web_search",
    "Write": ".write",
}


def __getattr__(name: str):
    if name in _LAZY_IMPORTS:
        import importlib

        mod = importlib.import_module(_LAZY_IMPORTS[name], __name__)
        val = getattr(mod, name)
        globals()[name] = val  # cache to bypass __getattr__ on subsequent access
        return val
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
