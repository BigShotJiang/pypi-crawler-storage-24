"""
Generic Pipeline Runner.

Main entry point for Generic Dataflow pipeline.
"""

import argparse
import logging
from datetime import date, datetime, timezone

import apache_beam as beam
import apache_beam.io.fileio  # noqa: F401 — ensures beam.io.fileio is accessible
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions
from apache_beam.io.gcp.bigquery import WriteToBigQuery, BigQueryDisposition
from gcp_pipeline_beam.pipelines.base.options import GCPPipelineOptions

from gcp_pipeline_core.job_control import (
    JobControlRepository,
    JobStatus,
    FailureStage,
    PipelineJob,
)

from .options import GenericPipelineOptions
from .transforms import ValidateFileDoFn, ParseAndValidateRecordDoFn
from ..config import SYSTEM_ID, ODP_DATASET
from ..schema import ENTITY_SCHEMAS, get_schema
from ..schema.registry import ENTITY_HEADERS

logger = logging.getLogger(__name__)


def run_pipeline(argv=None):
    """Run the Generic pipeline."""

    parser = argparse.ArgumentParser()
    known_args, pipeline_args = parser.parse_known_args(argv)

    pipeline_options = PipelineOptions(pipeline_args)
    generic_options = pipeline_options.view_as(GenericPipelineOptions)
    gcp_options = pipeline_options.view_as(GCPPipelineOptions)

    entity = generic_options.entity
    input_file = generic_options.source_file
    extract_date = generic_options.extract_date

    # Resolve ValueProviders to plain strings (GCPPipelineOptions uses
    # add_value_provider_argument which returns StaticValueProvider objects;
    # these must be resolved before embedding in row data for BQ inserts)
    def _resolve(val):
        return val.get() if hasattr(val, 'get') else str(val)

    output_table = _resolve(gcp_options.output_table)
    error_table = _resolve(gcp_options.error_table)
    run_id = _resolve(gcp_options.run_id)

    headers = ENTITY_HEADERS.get(entity)
    schema = ENTITY_SCHEMAS.get(entity)

    if not headers or not schema:
        raise ValueError(f"Unknown entity: {entity}")

    bq_schema = {'fields': schema.to_bq_schema()}

    # Resolve GCP project for job control
    gcp_project = _resolve(gcp_options.gcp_project) if hasattr(gcp_options, 'gcp_project') else None

    logger.info(f"Starting Generic pipeline for {entity}")
    logger.info(f"Input: {input_file}")
    logger.info(f"Output: {output_table}")
    logger.info(f"Run ID: {run_id}")

    # Parse extract_date to a date object for job control
    extract_date_obj = None
    if extract_date:
        try:
            extract_date_obj = datetime.strptime(str(extract_date), '%Y%m%d').date()
        except (ValueError, TypeError):
            extract_date_obj = date.today()
    else:
        extract_date_obj = date.today()

    # Create job control record
    job_repo = None
    if gcp_project:
        try:
            job_repo = JobControlRepository(project_id=gcp_project)
            job = PipelineJob(
                run_id=run_id,
                system_id=SYSTEM_ID,
                entity_type=entity,
                extract_date=extract_date_obj,
                source_files=[input_file],
                started_at=datetime.now(tz=timezone.utc),
            )
            job_repo.create_job(job)
            job_repo.update_status(run_id, JobStatus.RUNNING)
            logger.info(f"Job control record created: {run_id}")
        except Exception as e:
            logger.warning(f"Failed to create job control record: {e}")
            job_repo = None

    try:
        with beam.Pipeline(options=pipeline_options) as p:
            # Read file content
            file_content = (
                p
                | 'MatchFiles' >> beam.io.fileio.MatchFiles(input_file)
                | 'ReadMatches' >> beam.io.fileio.ReadMatches()
                | 'ReadContent' >> beam.Map(lambda f: f.read_utf8())
            )

            # Validate file structure
            validation_result = (
                file_content
                | 'ValidateFile' >> beam.ParDo(
                    ValidateFileDoFn(entity)
                ).with_outputs('valid', 'invalid')
            )

            # Parse and validate records from valid files
            lines = (
                validation_result.valid
                | 'ExtractLines' >> beam.FlatMap(lambda x: x['lines'])
            )

            parsed_records = (
                lines
                | 'ParseAndValidate' >> beam.ParDo(
                    ParseAndValidateRecordDoFn(
                        entity=entity,
                        headers=headers,
                        run_id=run_id,
                        source_file=input_file
                    )
                ).with_outputs('valid', 'errors')
            )

            # Write valid records to BigQuery
            _ = (
                parsed_records.valid
                | 'WriteValid' >> WriteToBigQuery(
                    output_table,
                    schema=bq_schema,
                    write_disposition=BigQueryDisposition.WRITE_APPEND,
                    create_disposition=BigQueryDisposition.CREATE_IF_NEEDED,
                    method='STREAMING_INSERTS',
                )
            )

            # Write error records to error table
            _ = (
                parsed_records.errors
                | 'WriteErrors' >> WriteToBigQuery(
                    error_table,
                    write_disposition=BigQueryDisposition.WRITE_APPEND,
                    create_disposition=BigQueryDisposition.CREATE_IF_NEEDED,
                    method='STREAMING_INSERTS',
                )
            )

        # Update job control to SUCCESS
        if job_repo:
            try:
                job_repo.update_status(run_id, JobStatus.SUCCESS)
                logger.info(f"Job control updated to SUCCESS: {run_id}")
            except Exception as e:
                logger.warning(f"Failed to update job control to SUCCESS: {e}")

        logger.info(f"Generic pipeline completed for {entity}")

    except Exception as exc:
        # Update job control to FAILED
        if job_repo:
            try:
                job_repo.mark_failed(
                    run_id=run_id,
                    error_code="PIPELINE_FAILED",
                    error_message=str(exc)[:500],
                    failure_stage=FailureStage.ODP_LOAD,
                )
                logger.info(f"Job control updated to FAILED: {run_id}")
            except Exception as e:
                logger.warning(f"Failed to update job control to FAILED: {e}")
        raise


if __name__ == '__main__':
    logging.getLogger().setLevel(logging.INFO)
    run_pipeline()

