"""
fw_server/types.py — JSON-serializable request/response schemas for the MCP bridge.

All types here are plain dicts or Pydantic-free dataclasses so they serialise
cleanly across the MCP stdio boundary.  The authoritative rich types live in
bileshke.types; this module provides the thin wire format.

Design constraints:
  KV₇:  No shared mutable state between lenses — every request is stateless.
  AX56: Grade field never accepts "Hakkalyakîn".
  AX57: Every response carries a transparency block.
  T6/KV₄: Composite score < 1.0.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional


# ── Lens identifiers (string constants matching bileshke.types.LensId) ──

LENS_IDS = (
    "Ontoloji",
    "Mereoloji",
    "FOL",
    "Bayes",
    "OyunTeorisi",
    "KategoriTeorisi",
    "Topoloji + Holografik",
)

# ── Epistemic grades (ascending order) ──

VALID_GRADES = ("Tasavvur", "Tasdik", "İlmelyakîn")
# Note: "Hakkalyakîn" is intentionally excluded (AX56).

# ── Kavaid constraint definitions (KV₁–KV₈) ──

KAVAID_DEFINITIONS: Dict[str, Dict[str, str]] = {
    "KV1": {
        "name": "Mana-yı Harfî / İsmî",
        "definition": "Dual classification — every entity viewed as harfî (sign pointing beyond itself) or ismî (sign pointing to itself).",
        "ref": "AX1",
    },
    "KV2": {
        "name": "Privation ontology",
        "definition": "Evil has no positive ontological substance; it is the absence or privation of good.",
        "ref": "AX3",
    },
    "KV3": {
        "name": "Observer non-interference",
        "definition": "The observer is şart-ı âdî (an ordinary condition) — observation does not create reality.",
        "ref": "AX7",
    },
    "KV4": {
        "name": "Ne ayn ne gayr convergence bound",
        "definition": "Composite score C must satisfy 0 < C < 1 — the map never equals the territory.",
        "ref": "T6",
    },
    "KV5": {
        "name": "Temsil → Hakikat functor",
        "definition": "Verification that analogy (temsil) faithfully maps to reality (hakikat).",
        "ref": "AX12",
    },
    "KV6": {
        "name": "Holographic omnipresence",
        "definition": "The holographic seed must be present — each part carries the imprint of the whole.",
        "ref": "AX15",
    },
    "KV7": {
        "name": "İhlâs / independence",
        "definition": "No shared mutable state between lenses — each instrument operates independently.",
        "ref": "AX20",
    },
    "KV8": {
        "name": "Hakikat-i eşya = Esmâ",
        "definition": "The true nature of things consists of the Divine Names — ontological grounding check.",
        "ref": "AX2",
    },
}


# ========================================================================
# Request schemas
# ========================================================================

@dataclass
class RunLensRequest:
    """Input for a single-lens execution."""
    lens_id: str            # Must be one of LENS_IDS
    params: Dict[str, Any] = field(default_factory=dict)
    # Lens-specific; adapters interpret these.
    # e.g. {"text": "...", "model": {...}} for FOL


@dataclass
class RunBileshkeRequest:
    """Input for the full composite pipeline."""
    lens_results: Optional[List[Dict[str, Any]]] = None
    # If None the engine runs all 7 lenses with defaults.
    weights: Optional[Dict[str, float]] = None
    ortam: Optional[List[int]] = None  # [1,1,1] = full coverage


@dataclass
class KavaidCheckRequest:
    """Input for a standalone kavaid evaluation."""
    composite_score: float = 0.0
    latife_bits: Optional[List[int]] = None   # 7-element list
    kavaid_overrides: Optional[Dict[str, bool]] = None


@dataclass
class InferenceChainRequest:
    """Input for inference chain verification."""
    chain_id: Optional[str] = None  # None → verify all
    text: Optional[str] = None       # For axiom reference extraction


@dataclass
class HCPIngestRequest:
    """Input for HCP context ingestion."""
    text: str = ""


@dataclass
class HCPQueryRequest:
    """Input for HCP retrieval."""
    question: str = ""
    keywords: Optional[List[str]] = None
    top_k: int = 5


# ========================================================================
# Response schemas
# ========================================================================

@dataclass
class LensResponse:
    """Output from a single lens."""
    lens_id: str
    score: float
    grade: str
    checks_passed: int = 0
    checks_total: int = 0
    detail: str = ""
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class BileshkeResponse:
    """Output from the composite engine."""
    composite_score: float = 0.0
    lens_results: List[Dict[str, Any]] = field(default_factory=list)
    kavaid_checks: Dict[str, bool] = field(default_factory=dict)
    latife_vektor: Dict[str, int] = field(default_factory=dict)
    ortam_vektor: Dict[str, int] = field(default_factory=dict)
    completeness: float = 0.0
    warnings: List[str] = field(default_factory=list)
    degree_distribution: Dict[str, str] = field(default_factory=dict)
    # AX57 transparency
    framework_disclosure: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class KavaidResponse:
    """Output from kavaid evaluation."""
    checks: Dict[str, bool] = field(default_factory=dict)
    descriptions: Dict[str, str] = field(default_factory=dict)
    all_pass: bool = False
    composite_score: float = 0.0
    kv4_warning: Optional[str] = None
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class InferenceChainResponse:
    """Output from inference chain verification."""
    chains_verified: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    hub_nodes: Dict[str, List[str]] = field(default_factory=dict)
    axiom_refs: Optional[Dict[str, List[str]]] = None
    all_valid: bool = False
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class HCPResponse:
    """Output from HCP operations."""
    action: str = ""  # "ingest" | "query" | "diagnostics"
    diagnostics: Optional[Dict[str, Any]] = None
    results: Optional[List[Dict[str, Any]]] = None
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class DusunResult:
    """Output from the dusun() universal analysis tool.

    AX5:  Integrating result — activates all relevant lenses into coordinated output.
    AX57: Carries full transparency disclosure.
    KV₄:  composite_score ∈ (0, 1) — never reaches 1.0.
    T15:  structural_claims weighted above detail_claims.
    """
    path: str = "P0"                  # Classified path: P0, P1, P2, P3
    mode: str = "analyze"             # "analyze" (MVP) or "validate" (future)
    composite_score: float = 0.0
    grade: str = "Tasavvur"
    lens_scores: Dict[str, float] = field(default_factory=dict)
    lens_errors: Dict[str, str] = field(default_factory=dict)
    kavaid: Dict[str, bool] = field(default_factory=dict)
    kavaid_pass_count: int = 0
    vocabulary_detected: List[str] = field(default_factory=list)
    fire_plan: List[str] = field(default_factory=list)
    patterns_applied: List[str] = field(default_factory=list)
    translation_hints: Dict[str, str] = field(default_factory=dict)
    anomalies: List[str] = field(default_factory=list)
    ax57_compact: str = ""
    shaping_directives: Dict[str, Any] = field(default_factory=dict)
    hcp_ingested: bool = False
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class FrameworkSummaryResponse:
    """Output from framework_summary across all modules."""
    bileshke: Dict[str, Any] = field(default_factory=dict)
    kavram_sozlugu: Dict[str, Any] = field(default_factory=dict)
    mereoloji: Dict[str, Any] = field(default_factory=dict)
    fol: Dict[str, Any] = field(default_factory=dict)
    bayes: Dict[str, Any] = field(default_factory=dict)
    oyun_teorisi: Dict[str, Any] = field(default_factory=dict)
    kategori_teorisi: Dict[str, Any] = field(default_factory=dict)
    holografik: Dict[str, Any] = field(default_factory=dict)
    kaskad: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class SentinelResponse:
    """Output from sentinel MCP tools.

    Wire format for sentinel_scan, sentinel_report, sentinel_status.
    """
    action: str = ""                                          # "scan" | "report" | "status"
    signal: Optional[Dict[str, Any]] = None                   # Active SentinelSignal
    incident: Optional[Dict[str, Any]] = None                 # Created Incident
    pattern_rule: Optional[Dict[str, Any]] = None             # Generalised PatternRule
    picker_options: Optional[List[Dict[str, str]]] = None     # Enhanced picker
    stats: Optional[Dict[str, Any]] = None                    # Registry statistics
    co_suggestions: Optional[List[Dict[str, Any]]] = None     # Vocabulary
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {k: v for k, v in asdict(self).items() if v is not None}
