"""Per-lens extraction prompt templates for MCP sampling (ctx.sample()).

Each prompt instructs the host LLM to extract lens-specific analytical
structure from text and return strict JSON.  Prompts are kept ≤ 500 tokens
to minimise sampling latency.

Usage:
    from fw_server.sampling_prompts import SAMPLING_PROMPTS
    prompt = SAMPLING_PROMPTS["Bayes"].format(text=user_text)
"""
from __future__ import annotations

from typing import Dict

SAMPLING_PROMPTS: Dict[str, str] = {}

# ── Bayes ────────────────────────────────────────────────────────────

SAMPLING_PROMPTS["Bayes"] = """\
Analyze the following text for Bayesian reasoning structure.
Extract any hypotheses, evidence items, and prior probabilities.

Return ONLY valid JSON matching this schema:
{{
  "hypotheses": [{{"name": "<hypothesis>", "prior": <float 0-1>}}],
  "evidence": [{{"name": "<evidence>", "likelihood": <float 0-1>, "likelihood_complement": <float 0-1>}}]
}}

If no Bayesian reasoning is found, return: {{"empty": true}}

Text:
{text}"""

# ── Mereoloji ────────────────────────────────────────────────────────

SAMPLING_PROMPTS["Mereoloji"] = """\
Analyze the following text for part-whole (mereological) structure.
Identify any wholes, their constituent parts, and part-whole relations.

Return ONLY valid JSON matching this schema:
{{
  "whole": "<name of the whole>",
  "parts": [{{"name": "<part name>", "telos": "<purpose/function>"}}],
  "relations": [{{"whole": "<whole>", "part": "<part>"}}]
}}

If no part-whole structure is found, return: {{"empty": true}}

Text:
{text}"""

# ── FOL ──────────────────────────────────────────────────────────────

SAMPLING_PROMPTS["FOL"] = """\
Analyze the following text for formal logic structure.
Identify axiom references (AX1-AX63, T1-T22, KV1-KV8), logical premises,
and conclusions.

Return ONLY valid JSON matching this schema:
{{
  "axiom_refs": ["AX1", "T6", ...],
  "premises": ["<premise statement>", ...],
  "conclusion": "<conclusion statement or empty string>"
}}

If no logical structure is found, return: {{"empty": true}}

Text:
{text}"""

# ── OyunTeorisi ──────────────────────────────────────────────────────

SAMPLING_PROMPTS["OyunTeorisi"] = """\
Analyze the following text for game-theoretic structure.
Identify players (with their nefs-makam level if mentioned: emmare,
levvame, mulhime, mutmainne), strategies, and payoff assessments.

Return ONLY valid JSON matching this schema:
{{
  "players": [{{"name": "<player>", "makam": "emmare|levvame|mulhime|mutmainne"}}],
  "strategies": [{{"player": "<player>", "name": "<strategy>", "type": "worldly|alignment|mixed"}}],
  "payoffs": [{{"player": "<player>", "my_strategy": "<str>", "opponent_strategy": "<str>", "payoff": <float>}}]
}}

If no game-theoretic structure is found, return: {{"empty": true}}

Text:
{text}"""

# ── KategoriTeorisi ──────────────────────────────────────────────────

SAMPLING_PROMPTS["KategoriTeorisi"] = """\
Analyze the following text for category-theoretic structure.
Identify objects, morphisms (arrows between objects), and functors.

Return ONLY valid JSON matching this schema:
{{
  "objects": ["<object name>", ...],
  "morphisms": [{{"name": "<morphism>", "source": "<obj>", "target": "<obj>"}}],
  "category_name": "<name>",
  "functor_kind": "<description or empty string>"
}}

If no categorical structure is found, return: {{"empty": true}}

Text:
{text}"""

# ── Topoloji + Holografik ────────────────────────────────────────────

SAMPLING_PROMPTS["Topoloji + Holografik"] = """\
Analyze the following text for holographic/fractal structure.
Identify self-similar patterns, part-whole isomorphisms, seed-like
structures, active Besmele dimensions (B01-B22), and fidelity pairs.

Return ONLY valid JSON matching this schema:
{{
  "seed_descriptions": [{{"name": "<unit>", "level": "<description>"}}],
  "dimensions_active": [<int 0-21>, ...],
  "fidelity_pairs": [{{"source": "<source>", "derivative": "<derivative>", "fidelity": <float 0-1>}}]
}}

If no holographic structure is found, return: {{"empty": true}}

Text:
{text}"""

# ── Ontoloji ─────────────────────────────────────────────────────────

SAMPLING_PROMPTS["Ontoloji"] = """\
Analyze the following text for ontological structure.
Identify concepts (kavramlar), referenced Divine Names (Esma-ul Husna),
dual classifications (harfi = reflecting Creator / ismi = self-referencing),
and whether entities discussed are living.

Return ONLY valid JSON matching this schema:
{{
  "concepts": [{{
    "name": "<concept>",
    "names_referenced": ["el-Hayy", "el-Hakim", ...],
    "dual_class": "harfi|ismi",
    "is_living": <bool>
  }}]
}}

If no ontological structure is found, return: {{"empty": true}}

Text:
{text}"""
