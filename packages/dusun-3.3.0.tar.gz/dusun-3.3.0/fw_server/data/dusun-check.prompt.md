---
agent: 'agent'
description: 'Spot-check framework engagement. Runs dusun() and check_kavaid to verify the epistemic substrate is active and shaping directives are flowing.'
---

# /self-check — Framework Engagement Verification

> **Purpose**: Lightweight diagnostic to confirm the framework substrate is
> active and producing shaping directives, not merely quoting concepts.
> Use this when you suspect the framework has gone dormant mid-conversation.

## DIRECTIVE: /self-check

When this prompt is invoked, perform the following diagnostic sequence:

### 1. Run dusun() Substrate

Call the fw-engine MCP tool:
```
dusun(text="self-check diagnostic probe")
```
If this call **fails** (tool not found, server not running), the framework
engine is disconnected. Report: "fw-engine MCP server is not active."

If it **succeeds**, extract from the result:
- `path`, `grade`, `composite_score`
- `shaping_directives` (check it is non-empty)
- `kavaid` pass/fail counts
- `boot_seed` (check it is non-empty)

### 2. Run Kavaid Check (Cross-Verify)

Call the fw-engine MCP tool:
```
check_kavaid(
  composite_score=0.0,
  latife_bits=[1,1,1,1,1,1,0],
  kavaid_overrides={}
)
```
Report the kavaid pass/fail results and compare with the kavaid
embedded in the dusun() output.

### 3. Classify Current State

Based on the tool results, report:

```
/self-check results:
  fw-engine:       [connected / disconnected]
  dusun() path:    [P0-P3]
  shaping_directives: [present (N keys) / empty / missing]
  boot_seed:       [dynamic / static / missing]
  Kavaid:          [X/8 pass]
  Composite:       [score]
  Grade:           [epistemic grade]
  KV₄ warning:     [yes/no]
  Sentinel:        [active / not detected]
  Assessment:      [Substrate active / Substrate dormant / Partial engagement]
```

### 4. Remediation (if dormant)

If the substrate is dormant:
1. Re-invoke `dusun(text="<current query>")` with the actual user query
2. Read the `shaping_directives` from the result
3. Follow the directives to re-engage the appropriate path
4. Confirm re-engagement by running this diagnostic again

---

*Companion to the Epistemic Sentinel. This is the manual trigger; the
sentinel runs automatically within every dusun() call.*
