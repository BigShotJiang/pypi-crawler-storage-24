---
agent: 'dusun-orchestrator'
description: 'Run full orchestrated dusun analysis with decomposed tools and optional review'
argument-hint: 'Enter the text or query to analyze'
---

# /dusun-orchestrated — Full Pipeline Analysis

> **Purpose**: Routes the user's query through the orchestrator agent, which
> calls the 5 decomposed MCP tools in sequence (route → lenses → score →
> synthesize → directives) with an optional review loop for anomalies.

## DIRECTIVE: /dusun-orchestrated

When this prompt is invoked with a user query, follow the orchestrator
protocol defined in your agent instructions:

1. **Route** the user's text through `route_text`
2. **Execute lenses** via `run_lenses` (skip for P0)
3. **Score** via `score_composite`
4. **Synthesize** via `synthesize_lenses` (if ≥2 lenses)
5. **Build directives** via `build_directives`
6. **Shape response** per `shaping_directives`
7. **Review** via `dusun-review` if anomalies detected

The user's input text is:

```
{{input}}
```