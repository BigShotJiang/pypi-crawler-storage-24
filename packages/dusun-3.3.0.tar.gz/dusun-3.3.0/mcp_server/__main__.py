"""Allow running with: python -m mcp_server"""
from mcp_server.server import mcp


def main():
    mcp.run()


if __name__ == "__main__":
    main()
