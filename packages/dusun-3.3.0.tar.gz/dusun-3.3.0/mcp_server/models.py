"""Compatibility wrapper for shared analysis models."""

from dusun_shared.models import (
    AnalysisStatus,
    DeepDiveResult,
    Finding,
    LensAnalysis,
    LensConnection,
    LensName,
    LENS_TO_TURKISH,
    Synthesis,
    TextComparison,
    TextInfo,
)

__all__ = [
    "AnalysisStatus",
    "DeepDiveResult",
    "Finding",
    "LensAnalysis",
    "LensConnection",
    "LensName",
    "LENS_TO_TURKISH",
    "Synthesis",
    "TextComparison",
    "TextInfo",
]
