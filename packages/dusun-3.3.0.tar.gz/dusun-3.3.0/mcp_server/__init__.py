"""
mcp_server — Next-generation MCP server for 7-lens analytical framework.

Outcome-oriented design: ~7 tools, structured Pydantic output,
persistent SQLite cache, session state for cross-tool accumulation.

Usage:
    python -m mcp_server          # start stdio MCP server
    fastmcp run mcp_server:mcp    # alternative via fastmcp CLI
"""
