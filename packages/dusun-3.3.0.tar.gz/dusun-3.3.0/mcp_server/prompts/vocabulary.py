"""Compatibility wrapper for shared vocabulary prompts."""

from dusun_shared.prompts.vocabulary import (
    COMPARISON_PROMPT,
    DEEP_DIVE_PROMPT,
    LENS_PROMPTS,
    SYNTHESIS_PROMPT,
)

__all__ = [
    "COMPARISON_PROMPT",
    "DEEP_DIVE_PROMPT",
    "LENS_PROMPTS",
    "SYNTHESIS_PROMPT",
]
