"""Engine layer — async LLM-calling core for analysis, synthesis, comparison."""
