"""Compatibility wrapper for the shared synthesis helpers."""

from dusun_shared.engine.synthesizer import (
    _clamp,
    _coerce_lens,
    _format_analyses_for_prompt,
    _parse_comparison,
    _parse_deep_dive,
    _parse_synthesis,
    run_comparison,
    run_deep_dive,
    run_synthesis,
)

__all__ = [
    "_clamp",
    "_coerce_lens",
    "_format_analyses_for_prompt",
    "_parse_comparison",
    "_parse_deep_dive",
    "_parse_synthesis",
    "run_comparison",
    "run_deep_dive",
    "run_synthesis",
]
