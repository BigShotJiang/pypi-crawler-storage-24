"""Compatibility wrapper for the shared lens runner."""

from dusun_shared.engine.lens_runner import (
    SamplingFn,
    _build_user_prompt,
    _clamp,
    _parse_analysis,
    run_lens_analysis,
)

__all__ = [
    "SamplingFn",
    "_build_user_prompt",
    "_clamp",
    "_parse_analysis",
    "run_lens_analysis",
]
