"""kaynak_metinler — curated Risale-i Nur source texts for calibration."""

from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent
