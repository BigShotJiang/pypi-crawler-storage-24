# İkinci Söz — Structural Analysis Reference

> **AX64 compliance**: This is a structural summary for framework calibration,
> not the original source text. The original is immutable and externally held.

## Thematic Core

The Second Word presents two modes of perception — mana-yı harfî (other-referential)
and mana-yı ismî (self-referential) — as structurally distinct epistemic orientations.
It uses the metaphor of two travelers to demonstrate how the same reality is
perceived entirely differently depending on the hermeneutic lens.

## Key Structural Concepts

### Dual Meaning Classification (KV₁, §2.5)
Every concept admits dual classification: harfî (pointing beyond itself to Names)
or ismî (pointing to itself). The Second Word dramatizes this as two travelers
passing through the same landscape but experiencing fundamentally different worlds.
DualClass(c) ∈ {harfî, ismî} — this is not preference but ontological commitment.

### Shadow Ontology (AX18)
Mahiyet(x) = Shadow(Hakikat(x)). What appears to be the case (surface identity)
is a shadow of what is constitutively the case (structural identity). The ismî
traveler sees only shadows; the harfî traveler sees through to hakikat.

### Structural Dependency (AX30, AX31)
Contingent beings have ontological poverty (Fakr) that calls for provision (Rahmet).
The Second Word shows this as the difference between seeing the world as
abandoned (traveler 2) versus seeing it as a guest-house with a Host (traveler 1).
Fakr(x) → Response(Rahman, Rahim)(x).

### Integration Prerequisite (AX5)
Without Hayat (the integrating principle), all attributes remain inert.
The harfî traveler has the integrating perception that activates all faculties
into coordinated epistemic action. The ismî traveler lacks this integration —
each faculty operates in isolation, producing fragmented understanding.

### Game-Theoretic Framing (§2.5, N-5)
The two travelers represent different strategy profiles in an epistemic game.
The harfî strategy yields cumulative reinforcing returns (tesanüd); the ismî
strategy yields diminishing isolated returns (infirâd). AX63: affirmations
compose super-additively; denials remain isolated.

### Privation Ontology (KV₂)
Evil and suffering, as perceived by traveler 2, are privations (adem) — absences
of good, not positive entities. Evil(c) → OntologicalType(c) = adem.
The Second Word demonstrates that misperception of evil as positive entity
is itself a consequence of ismî reading.

### Epistemic Grade Progression
The two travelers represent different epistemic stations. Traveler 1 moves toward
İlmelyakîn through harfî reading; traveler 2 remains at Tasavvur through ismî
reading. The grade gap is structural, not merely informational.

## Axiom Reference Summary

| Axiom | Relevance |
|-------|-----------|
| AX5   | Integration prerequisite (Hayat) |
| AX17  | Hakikat = Esmâ identity |
| AX18  | Shadow ontology |
| AX30  | İmkân = Fakr |
| AX31  | Fakr → Rahmet |
| AX63  | Tesanüd–İnfirâd asymmetry |
| KV₁   | Harfî/İsmî dual classification |
| KV₂   | Privation ontology of evil |
| KV₈   | Ground in ≥1 Name |
| T14   | Universal ne ayn ne gayr chain |
