# Birinci Söz — Structural Analysis Reference

> **AX64 compliance**: This is a structural summary for framework calibration,
> not the original source text. The original is immutable and externally held.

## Thematic Core

The First Word centers on **Bismillah** (In the Name of God) as the structural
key to intelligibility. Every being functions as a letter (mana-yı harfî) —
it points beyond itself to the Names (Esmâ) whose manifestation constitutes it.

## Key Structural Concepts

### Transparent Vessels (AX27)
Causes are not autonomous agents but transparent intermediaries — vessels (zarf)
that mediate multi-Name manifestation. A tree is not self-originative; it is a
tablacı (servant/carrier) through which Muhyî (Life-Giver), Musavvir (Shaper),
Rezzâk (Provider), and Hakîm (Wisdom) simultaneously manifest.

### Esmâ Ontology (AX17)
The reality (hakikat) of any being is the set of Names expressed in it:
Hakikat(x) = {n ∈ S_Isim | Tecelli(n, x) > 0}. The First Word demonstrates
this through the Bismillah lens — invoking the Name means recognizing the
constitutive structure behind appearances.

### Holographic Seed (AX37, T12)
The Besmele encodes the structure of the Fatiha, which encodes the structure
of the Kur'an: Structure(Besmele) ≅ Structure(Fatiha) ≅ Structure(Kur'an).
The smallest unit is structurally isomorphic to the whole — a holographic seed.

### Convergent Abstraction (§1.5)
Observable actions (S_Fiil) → operational principles (S_Isim) → core attributes
(S_Sifat) → foundational source (S_Zat). The convergent funnel: ∞ → 1001 → 7 → 1.

### Mereological Structure
The First Word operates as a part that contains the whole — it is both a discrete
unit and a compressed image of the entire Külliyat. Part-whole relations are
teleological: the purpose of the part is to manifest the structural pattern
of the whole (Ehadiyet reflection, AX13).

### Constitutive Dependency (AX30, AX34)
Every contingent being has ontological poverty (Fakr): it does not carry the
cause of its own existence. This poverty is not a defect but a functional
interface (AX34) through which provision (Rahmet) flows. The Bismillah
recognizes this dependency structure.

### Epistemic Grounding
The First Word establishes that the proper epistemic mode is harfî (KV₁) —
seeing through things to the Names they manifest, rather than stopping at
surface properties (ismî mode). This is the foundational epistemic commitment.

## Axiom Reference Summary

| Axiom | Relevance |
|-------|-----------|
| AX1   | Formal order from the Source of Wisdom |
| AX12  | Vahidiyet containment — Names unified |
| AX13  | Ehadiyet reflection — unity at every node |
| AX17  | Hakikat = Esmâ identity |
| AX18  | Shadow ontology — mahiyet as shadow of hakikat |
| AX27  | Transparent vessel ontology |
| AX30  | İmkân = Fakr |
| AX34  | Constitutive wounds as functional interfaces |
| AX37  | Holographic structure |
| T10   | Severed cause impossibility |
| T12   | Besmele seed triple isomorphism |
| KV₁   | Harfî classification default |
| KV₈   | Ground in ≥1 Name |
