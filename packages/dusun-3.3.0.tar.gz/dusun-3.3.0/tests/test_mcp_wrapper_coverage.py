"""
tests/test_mcp_wrapper_coverage.py — Tests for the 6 MCP wrappers that
had no wrapper-level coverage.

Covers:
  - hcp_create_workflow + hcp_advance_workflow (2-stage round-trip)
  - hcp_export_state + hcp_import_state (checkpoint round-trip)
  - hcp_sync_memory_bank (env-guard path)
  - calibrate_source_texts (error-resilient import)
  - sentinel_scan (wire format)
  - sentinel_report (wire format + kwarg correctness)
  - sentinel_status (wire format)

Design:
  KV₇: Tests are independent — each resets shared singletons.
  KV₃: Sentinel failures never propagate — verified by fire-and-forget.
"""

from __future__ import annotations

import json
import os
import pytest


# ═══════════════════════════════════════════════════════════════════════
# SECTION 1: HCP Workflow — create + advance round-trip
# ═══════════════════════════════════════════════════════════════════════


class TestHCPWorkflow:
    """Tests for hcp_create_workflow and hcp_advance_workflow wrappers."""

    def _reset_hcp(self):
        """Reset the HCP singleton so each test starts fresh."""
        import fw_server.server as srv
        srv._hcp_protocol = None

    def test_create_workflow_returns_valid_json(self):
        self._reset_hcp()
        from fw_server.server import hcp_create_workflow

        stages = [{"name": "stage_a"}, {"name": "stage_b"}]
        result = hcp_create_workflow(stages)
        parsed = json.loads(result)

        assert parsed.get("action") == "create_workflow"
        assert parsed.get("n_stages") == 2
        assert parsed.get("current_stage") == "stage_a"
        assert "workflow_id" in parsed

    def test_create_workflow_accepts_json_string(self):
        """_coerce() must handle JSON string for backward compat."""
        self._reset_hcp()
        from fw_server.server import hcp_create_workflow

        stages_json = json.dumps([{"name": "s1"}, {"name": "s2"}])
        result = hcp_create_workflow(stages_json)
        parsed = json.loads(result)

        assert parsed.get("action") == "create_workflow"
        assert parsed.get("n_stages") == 2

    def test_create_workflow_empty_stages_returns_error(self):
        self._reset_hcp()
        from fw_server.server import hcp_create_workflow

        result = hcp_create_workflow([])
        parsed = json.loads(result)
        assert "error" in parsed

    def test_advance_workflow_round_trip(self):
        """Create 2-stage workflow, advance twice, verify completion."""
        self._reset_hcp()
        from fw_server.server import hcp_create_workflow, hcp_advance_workflow

        # Create
        stages = [{"name": "analyze"}, {"name": "synthesize"}]
        create_result = json.loads(hcp_create_workflow(stages))
        wf_id = create_result["workflow_id"]

        # Advance stage 1
        adv1 = json.loads(hcp_advance_workflow(wf_id, "stage1 output"))
        assert adv1.get("action") == "advance_workflow"
        assert adv1.get("completed_stage") == "analyze"
        assert adv1.get("is_complete") is False or adv1.get("next_stage") is not None

        # Advance stage 2
        adv2 = json.loads(hcp_advance_workflow(wf_id, "stage2 output"))
        assert adv2.get("completed_stage") == "synthesize"
        assert adv2.get("is_complete") is True

    def test_advance_unknown_workflow_returns_error(self):
        self._reset_hcp()
        from fw_server.server import hcp_advance_workflow

        result = hcp_advance_workflow("nonexistent_workflow", "output")
        parsed = json.loads(result)
        assert "error" in parsed

    def test_advance_completed_workflow_returns_error(self):
        """Advancing past the last stage should return an error."""
        self._reset_hcp()
        from fw_server.server import hcp_create_workflow, hcp_advance_workflow

        stages = [{"name": "only_stage"}]
        create_result = json.loads(hcp_create_workflow(stages))
        wf_id = create_result["workflow_id"]

        # Advance once (completes the workflow)
        hcp_advance_workflow(wf_id, "done")

        # Advance again — should error
        result = json.loads(hcp_advance_workflow(wf_id, "extra"))
        assert "error" in result


# ═══════════════════════════════════════════════════════════════════════
# SECTION 2: HCP Export/Import — checkpoint round-trip
# ═══════════════════════════════════════════════════════════════════════


class TestHCPExportImport:
    """Tests for hcp_export_state and hcp_import_state wrappers."""

    def _reset_hcp(self):
        import fw_server.server as srv
        srv._hcp_protocol = None

    def test_export_returns_schema_version(self):
        self._reset_hcp()
        from fw_server.server import hcp_export_state

        result = json.loads(hcp_export_state())
        assert "schema_version" in result

    def test_export_import_round_trip_preserves_chunks(self):
        """Ingest → export → reset → import → verify chunk count."""
        self._reset_hcp()
        from fw_server.server import hcp_ingest, hcp_export_state, hcp_import_state

        # Ingest some content
        ingest_result = json.loads(hcp_ingest(
            "AX1 states formal composition. T6 provides the convergence bound."
        ))
        original_chunks = ingest_result.get("n_chunks", 0)
        assert original_chunks >= 1

        # Export
        exported = json.loads(hcp_export_state())
        assert "schema_version" in exported

        # Reset and import
        self._reset_hcp()
        import_result = json.loads(hcp_import_state(exported))

        assert import_result.get("action") == "import_state"
        assert import_result.get("n_chunks") == original_chunks

    def test_import_accepts_json_string(self):
        """_coerce() should handle JSON-encoded state string."""
        self._reset_hcp()
        from fw_server.server import hcp_export_state, hcp_import_state

        exported = hcp_export_state()  # already a JSON string
        # Pass the raw string (not parsed) — _coerce should handle it
        import_result = json.loads(hcp_import_state(exported))

        assert import_result.get("action") == "import_state"
        assert "n_chunks" in import_result

    def test_import_invalid_json_returns_error(self):
        self._reset_hcp()
        from fw_server.server import hcp_import_state

        result = json.loads(hcp_import_state("not valid json {{{"))
        assert "error" in result

    def test_import_wrong_type_returns_error(self):
        """Importing a list instead of dict should error."""
        self._reset_hcp()
        from fw_server.server import hcp_import_state

        result = json.loads(hcp_import_state([1, 2, 3]))
        assert "error" in result


# ═══════════════════════════════════════════════════════════════════════
# SECTION 3: hcp_sync_memory_bank — env guard
# ═══════════════════════════════════════════════════════════════════════


class TestHCPSyncMemoryBank:
    """Tests for hcp_sync_memory_bank wrapper."""

    def test_no_state_dir_returns_error(self):
        """When FW_STATE_DIR is unset, sync should return a clear error."""
        # Ensure env var is not set
        old_val = os.environ.pop("FW_STATE_DIR", None)
        try:
            from fw_server.server import hcp_sync_memory_bank
            result = json.loads(hcp_sync_memory_bank())
            assert "error" in result
            assert "FW_STATE_DIR" in result["error"]
        finally:
            if old_val is not None:
                os.environ["FW_STATE_DIR"] = old_val

    def test_with_state_dir_returns_result(self, tmp_path):
        """When FW_STATE_DIR points to a valid dir, sync should run."""
        import fw_server.server as srv
        srv._hcp_protocol = None

        old_val = os.environ.get("FW_STATE_DIR")
        os.environ["FW_STATE_DIR"] = str(tmp_path)
        try:
            from fw_server.server import hcp_sync_memory_bank
            result = json.loads(hcp_sync_memory_bank("test session note"))
            # Should either succeed with file info or return an
            # understandable error (not a crash)
            assert isinstance(result, dict)
        finally:
            if old_val is not None:
                os.environ["FW_STATE_DIR"] = old_val
            else:
                os.environ.pop("FW_STATE_DIR", None)
            srv._hcp_protocol = None


# ═══════════════════════════════════════════════════════════════════════
# SECTION 4: calibrate_source_texts
# ═══════════════════════════════════════════════════════════════════════


class TestCalibrateSourceTexts:
    """Tests for calibrate_source_texts wrapper."""

    def test_returns_valid_json(self):
        """calibrate_source_texts should always return valid JSON."""
        from fw_server.server import calibrate_source_texts

        result_str = calibrate_source_texts()
        parsed = json.loads(result_str)
        assert isinstance(parsed, dict)

    def test_result_has_expected_structure(self):
        """If calibration succeeds, result should have per-text and aggregate keys."""
        from fw_server.server import calibrate_source_texts

        parsed = json.loads(calibrate_source_texts())

        # On success, expect calibration structure
        if "error" not in parsed:
            # CalibrationResult.to_dict() should produce at least these
            assert "results" in parsed or "texts" in parsed or "aggregate" in parsed
        else:
            # On error, verify the error is descriptive (may be None if
            # the pipeline returned an empty CalibrationResult with error=None)
            assert parsed["error"] is None or len(parsed["error"]) > 0


# ═══════════════════════════════════════════════════════════════════════
# SECTION 5: Sentinel wrappers — scan, report, status
# ═══════════════════════════════════════════════════════════════════════


class TestSentinelScan:
    """Tests for sentinel_scan wrapper wire format."""

    def _reset_sentinel(self):
        from sentinel.engine import reset_sentinel
        reset_sentinel()

    def test_scan_returns_valid_json(self):
        self._reset_sentinel()
        from fw_server.server import sentinel_scan

        result = json.loads(sentinel_scan("This is a test sentence."))
        assert isinstance(result, dict)

    def test_scan_wire_format(self):
        """SentinelResponse must have action='scan' and stats."""
        self._reset_sentinel()
        from fw_server.server import sentinel_scan

        parsed = json.loads(sentinel_scan("Some analytical text."))

        if "error" not in parsed:
            assert parsed.get("action") == "scan"
            assert "stats" in parsed

    def test_scan_stats_structure(self):
        """Stats dict should contain incident_count and current_turn."""
        self._reset_sentinel()
        from fw_server.server import sentinel_scan

        parsed = json.loads(sentinel_scan("Testing stats structure."))

        if "error" not in parsed and "stats" in parsed:
            stats = parsed["stats"]
            assert "incident_count" in stats
            assert "current_turn" in stats

    def test_scan_empty_text_does_not_crash(self):
        """Empty text should not crash (KV₃ — fire-and-forget)."""
        self._reset_sentinel()
        from fw_server.server import sentinel_scan

        result = json.loads(sentinel_scan(""))
        assert isinstance(result, dict)

    def test_scan_signal_field_is_dict_or_none(self):
        """signal field should be None (no detection) or a valid dict."""
        self._reset_sentinel()
        from fw_server.server import sentinel_scan

        parsed = json.loads(sentinel_scan("You are wrong! This is terrible!"))

        if "error" not in parsed:
            signal = parsed.get("signal")
            assert signal is None or isinstance(signal, dict)
            if isinstance(signal, dict):
                assert "taxonomy_id" in signal
                assert "confidence" in signal


class TestSentinelReport:
    """Tests for sentinel_report wrapper wire format."""

    def _reset_sentinel(self):
        from sentinel.engine import reset_sentinel
        reset_sentinel()

    def test_report_returns_valid_json(self):
        self._reset_sentinel()
        from fw_server.server import sentinel_report

        result = json.loads(sentinel_report(
            taxonomy_id="FM-1",
            description="Test incident for coverage",
            context_snippet="some context",
        ))
        assert isinstance(result, dict)

    def test_report_wire_format(self):
        """Response should have action='report', incident dict, and stats."""
        self._reset_sentinel()
        from fw_server.server import sentinel_report

        parsed = json.loads(sentinel_report(
            taxonomy_id="CD-1",
            description="Confirmed drift detected in analysis",
            context_snippet="The model changed its conclusion mid-response",
        ))

        assert "error" not in parsed, f"sentinel_report failed: {parsed.get('error')}"
        assert parsed.get("action") == "report"
        assert "incident" in parsed
        assert "stats" in parsed
        # Incident should have an auto-assigned ID
        incident = parsed["incident"]
        assert "id" in incident or "taxonomy_id" in incident

    def test_report_empty_taxonomy_defaults_to_fm1(self):
        """Empty taxonomy_id should default to FM-1."""
        self._reset_sentinel()
        from fw_server.server import sentinel_report

        parsed = json.loads(sentinel_report(
            taxonomy_id="",
            description="No taxonomy given",
        ))

        assert "error" not in parsed, f"sentinel_report failed: {parsed.get('error')}"
        assert "incident" in parsed
        assert parsed["incident"].get("taxonomy_id") == "FM-1"


class TestSentinelStatus:
    """Tests for sentinel_status wrapper wire format."""

    def _reset_sentinel(self):
        from sentinel.engine import reset_sentinel
        reset_sentinel()

    def test_status_returns_valid_json(self):
        self._reset_sentinel()
        from fw_server.server import sentinel_status

        result = json.loads(sentinel_status())
        assert isinstance(result, dict)

    def test_status_wire_format(self):
        """Response should have action='status' and stats dict."""
        self._reset_sentinel()
        from fw_server.server import sentinel_status

        parsed = json.loads(sentinel_status())

        if "error" not in parsed:
            assert parsed.get("action") == "status"
            assert "stats" in parsed

    def test_status_stats_keys(self):
        """Stats should include core diagnostic keys."""
        self._reset_sentinel()
        from fw_server.server import sentinel_status

        parsed = json.loads(sentinel_status())

        if "error" not in parsed and "stats" in parsed:
            stats = parsed["stats"]
            assert "incident_count" in stats
            assert "pattern_rule_count" in stats
            assert "persistence" in stats

    def test_status_after_scan_reflects_turn(self):
        """After a scan, status should reflect the scan turn."""
        self._reset_sentinel()
        from fw_server.server import sentinel_scan, sentinel_status

        sentinel_scan("Pre-scan text for turn tracking.")
        parsed = json.loads(sentinel_status())

        if "error" not in parsed and "stats" in parsed:
            # current_turn should be >= 0 (scan was called)
            assert parsed["stats"].get("current_turn", -1) >= 0
