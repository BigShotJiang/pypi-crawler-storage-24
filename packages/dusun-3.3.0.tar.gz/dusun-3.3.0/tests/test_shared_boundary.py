"""Regression checks for the shared fw_server/mcp_server boundary."""

from __future__ import annotations

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from dusun_shared.engine.lens_runner import run_lens_analysis as shared_run_lens_analysis
from dusun_shared.engine.synthesizer import run_synthesis as shared_run_synthesis
from dusun_shared.models import LensName as SharedLensName
from mcp_server.engine.lens_runner import run_lens_analysis
from mcp_server.engine.synthesizer import run_synthesis
from mcp_server.models import LensName


def test_model_wrappers_point_to_shared_contracts() -> None:
    assert LensName is SharedLensName


def test_engine_wrappers_point_to_shared_helpers() -> None:
    assert run_lens_analysis is shared_run_lens_analysis
    assert run_synthesis is shared_run_synthesis


def test_fw_server_no_longer_imports_mcp_server_internals() -> None:
    server_path = Path(__file__).resolve().parent.parent / "fw_server" / "server.py"
    server_source = server_path.read_text(encoding="utf-8")

    assert "from mcp_server." not in server_source
    assert "import mcp_server." not in server_source
