"""
tests/test_decomposed_tools.py — Tests for the decomposed MCP tools (21–25).

Covers the 3 pure-computation tools that require no MCP context:
  - route_text (Tool 21): vocabulary detection + path classification + fire plan
  - score_composite (Tool 22): geometric mean + kavaid evaluation
  - build_directives (Tool 23): patterns + shaping + boot seed + AX57

Sampling-enabled tools (run_lenses, synthesize_lenses) are tested as
importable-and-callable; full integration requires real MCP context.

Design:
  KV₇: Tests are independent — no shared state.
  AX56: Hakkalyakîn grade never appears in outputs.
  T6/KV₄: Composite always < 0.95.
"""

from __future__ import annotations

import json
import pytest


# ═══════════════════════════════════════════════════════════════════════
# SECTION 1: route_text (Tool 21)
# ═══════════════════════════════════════════════════════════════════════


class TestRouteText:
    """Tests for the route_text pure-computation tool."""

    def test_returns_valid_json(self):
        from fw_server.server import route_text_tool
        result = route_text_tool("What is the meaning of existence?")
        parsed = json.loads(result)
        assert "error" not in parsed

    def test_output_keys(self):
        from fw_server.server import route_text_tool
        result = route_text_tool("Explain the ontological argument.")
        parsed = json.loads(result)
        assert "vocab" in parsed
        assert "path" in parsed
        assert "fire_plan" in parsed
        assert "combined" in parsed

    def test_path_is_valid(self):
        from fw_server.server import route_text_tool
        result = route_text_tool("A simple factual question: what is 2+2?")
        parsed = json.loads(result)
        assert parsed["path"] in ("P0", "P1", "P2", "P3")

    def test_vocab_is_list(self):
        from fw_server.server import route_text_tool
        result = route_text_tool("Test text")
        parsed = json.loads(result)
        assert isinstance(parsed["vocab"], list)

    def test_fire_plan_is_list(self):
        from fw_server.server import route_text_tool
        result = route_text_tool("Analyze the mereological structure.")
        parsed = json.loads(result)
        assert isinstance(parsed["fire_plan"], list)

    def test_context_merged_into_combined(self):
        from fw_server.server import route_text_tool
        result = route_text_tool("main text", context="extra context")
        parsed = json.loads(result)
        assert "main text" in parsed["combined"]
        assert "extra context" in parsed["combined"]

    def test_no_context_combined_equals_text(self):
        from fw_server.server import route_text_tool
        result = route_text_tool("standalone text")
        parsed = json.loads(result)
        assert parsed["combined"] == "standalone text"

    def test_rich_vocabulary_detects_patterns(self):
        """Text with known framework terms should trigger vocabulary detection."""
        from fw_server.server import route_text_tool
        result = route_text_tool(
            "Hudûs-u âlem delili ve mümkinat silsilesi "
            "vücub ve vücud mertebelerini gösterir."
        )
        parsed = json.loads(result)
        # Rich theological text should have non-empty vocab
        assert isinstance(parsed["vocab"], list)
        # Should route to P1+ for structural/epistemic content
        assert parsed["path"] in ("P0", "P1", "P2", "P3")


# ═══════════════════════════════════════════════════════════════════════
# SECTION 2: score_composite (Tool 22)
# ═══════════════════════════════════════════════════════════════════════


class TestScoreComposite:
    """Tests for the score_composite pure-computation tool."""

    def test_returns_valid_json(self):
        from fw_server.server import score_composite_tool
        result = score_composite_tool({"FOL": 0.8, "Bayes": 0.7})
        parsed = json.loads(result)
        assert "error" not in parsed

    def test_output_keys(self):
        from fw_server.server import score_composite_tool
        result = score_composite_tool({"FOL": 0.8})
        parsed = json.loads(result)
        for key in ("composite", "grade", "kavaid", "kavaid_pass_count", "anomalies"):
            assert key in parsed, f"Missing key: {key}"

    def test_composite_is_float(self):
        from fw_server.server import score_composite_tool
        result = score_composite_tool({"FOL": 0.8, "Bayes": 0.7})
        parsed = json.loads(result)
        assert isinstance(parsed["composite"], float)

    def test_kv4_cap_enforced(self):
        """Composite must always be < 0.95 (KV₄/T6 cap)."""
        from fw_server.server import score_composite_tool
        # All perfect scores should still be capped
        result = score_composite_tool({
            "FOL": 1.0, "Bayes": 1.0, "Ontoloji": 1.0,
            "Mereoloji": 1.0, "OyunTeorisi": 1.0,
            "KategoriTeorisi": 1.0, "Topoloji + Holografik": 1.0,
        })
        parsed = json.loads(result)
        assert parsed["composite"] <= 0.9499, f"KV4 breach: {parsed['composite']}"

    def test_geometric_mean_correctness(self):
        """Verify geometric mean calculation with known values."""
        from fw_server.server import score_composite_tool
        from math import prod
        scores = {"FOL": 0.64, "Bayes": 0.81}
        result = score_composite_tool(scores)
        parsed = json.loads(result)
        expected = round((0.64 * 0.81) ** 0.5, 4)
        assert abs(parsed["composite"] - expected) < 0.001

    def test_empty_scores_return_zero(self):
        from fw_server.server import score_composite_tool
        result = score_composite_tool({})
        parsed = json.loads(result)
        assert parsed["composite"] == 0.0

    def test_zero_scores_ignored(self):
        """Zero-value scores should not participate in geometric mean."""
        from fw_server.server import score_composite_tool
        result = score_composite_tool({"FOL": 0.8, "Bayes": 0.0})
        parsed = json.loads(result)
        # Only 0.8 participates → composite = 0.8
        assert abs(parsed["composite"] - 0.8) < 0.001

    def test_negative_scores_ignored(self):
        from fw_server.server import score_composite_tool
        result = score_composite_tool({"FOL": 0.8, "Bayes": -0.5})
        parsed = json.loads(result)
        assert abs(parsed["composite"] - 0.8) < 0.001

    def test_kavaid_checks_structure(self):
        from fw_server.server import score_composite_tool
        result = score_composite_tool({"FOL": 0.8})
        parsed = json.loads(result)
        checks = parsed["kavaid"]["checks"]
        for kv in ("KV1", "KV2", "KV3", "KV4", "KV5", "KV6", "KV7", "KV8"):
            assert kv in checks, f"Missing kavaid {kv}"
            assert isinstance(checks[kv], bool)

    def test_kavaid_pass_count_matches(self):
        from fw_server.server import score_composite_tool
        result = score_composite_tool({"FOL": 0.8})
        parsed = json.loads(result)
        checks = parsed["kavaid"]["checks"]
        expected_count = sum(1 for v in checks.values() if v)
        assert parsed["kavaid_pass_count"] == expected_count

    def test_kv4_true_when_below_threshold(self):
        from fw_server.server import score_composite_tool
        result = score_composite_tool({"FOL": 0.5})
        parsed = json.loads(result)
        assert parsed["kavaid"]["checks"]["KV4"] is True

    def test_kv5_true_when_scores_present(self):
        from fw_server.server import score_composite_tool
        result = score_composite_tool({"FOL": 0.5})
        parsed = json.loads(result)
        assert parsed["kavaid"]["checks"]["KV5"] is True

    def test_kv5_false_when_no_scores(self):
        from fw_server.server import score_composite_tool
        result = score_composite_tool({})
        parsed = json.loads(result)
        assert parsed["kavaid"]["checks"]["KV5"] is False

    def test_kv6_true_when_topo_fired(self):
        from fw_server.server import score_composite_tool
        result = score_composite_tool(
            {"FOL": 0.8},
            lens_names_fired=["topological"],
        )
        parsed = json.loads(result)
        assert parsed["kavaid"]["checks"]["KV6"] is True

    def test_kv6_false_when_no_topo(self):
        from fw_server.server import score_composite_tool
        result = score_composite_tool({"FOL": 0.8}, lens_names_fired=["fol"])
        parsed = json.loads(result)
        assert parsed["kavaid"]["checks"]["KV6"] is False

    def test_kv8_true_when_onto_fired(self):
        from fw_server.server import score_composite_tool
        result = score_composite_tool(
            {"FOL": 0.8},
            lens_names_fired=["ontological"],
        )
        parsed = json.loads(result)
        assert parsed["kavaid"]["checks"]["KV8"] is True

    def test_anomalies_empty_for_clean_run(self):
        from fw_server.server import score_composite_tool
        result = score_composite_tool(
            {"FOL": 0.8, "Bayes": 0.7},
            lens_names_fired=["fol", "bayesian", "topological", "ontological"],
        )
        parsed = json.loads(result)
        assert isinstance(parsed["anomalies"], list)

    def test_anomalies_for_kavaid_fail(self):
        """Missing KV6/KV8 should produce KAVAID-FAIL anomalies."""
        from fw_server.server import score_composite_tool
        result = score_composite_tool({"FOL": 0.8}, lens_names_fired=[])
        parsed = json.loads(result)
        kavaid_fails = [a for a in parsed["anomalies"] if "KAVAID-FAIL" in a]
        assert len(kavaid_fails) >= 1  # at least KV6 or KV8

    def test_grade_never_hakkalyakin(self):
        """AX56: Hakkalyakîn must never appear in grade output."""
        from fw_server.server import score_composite_tool
        result = score_composite_tool({
            "FOL": 0.99, "Bayes": 0.99, "Ontoloji": 0.99,
        })
        parsed = json.loads(result)
        assert "Hakkalyakîn" not in parsed["grade"]

    def test_json_string_input_coerced(self):
        """lens_scores passed as JSON string should be coerced to dict."""
        from fw_server.server import score_composite_tool
        result = score_composite_tool('{"FOL": 0.8}')
        parsed = json.loads(result)
        assert "error" not in parsed
        assert parsed["composite"] > 0


# ═══════════════════════════════════════════════════════════════════════
# SECTION 3: build_directives (Tool 23)
# ═══════════════════════════════════════════════════════════════════════


class TestBuildDirectives:
    """Tests for the build_directives pure-computation tool."""

    def _baseline_args(self):
        """Return minimal valid arguments for build_directives_tool."""
        return dict(
            path="P1",
            vocab=["hudus", "vucub"],
            lens_scores={"FOL": 0.8, "Bayes": 0.7},
            composite=0.72,
            grade="Tasdik",
            kavaid={"checks": {"KV1": True, "KV2": True, "KV3": True,
                               "KV4": True, "KV5": True, "KV6": True,
                               "KV7": True, "KV8": True}},
            kavaid_pass_count=8,
        )

    def test_returns_valid_json(self):
        from fw_server.server import build_directives_tool
        result = build_directives_tool(**self._baseline_args())
        parsed = json.loads(result)
        assert "error" not in parsed

    def test_output_keys(self):
        from fw_server.server import build_directives_tool
        result = build_directives_tool(**self._baseline_args())
        parsed = json.loads(result)
        for key in ("patterns", "shaping_directives", "translation_hints",
                     "ax57_compact", "boot_seed"):
            assert key in parsed, f"Missing key: {key}"

    def test_patterns_is_list(self):
        from fw_server.server import build_directives_tool
        result = build_directives_tool(**self._baseline_args())
        parsed = json.loads(result)
        assert isinstance(parsed["patterns"], list)

    def test_shaping_directives_is_dict(self):
        from fw_server.server import build_directives_tool
        result = build_directives_tool(**self._baseline_args())
        parsed = json.loads(result)
        assert isinstance(parsed["shaping_directives"], dict)

    def test_boot_seed_is_string(self):
        from fw_server.server import build_directives_tool
        result = build_directives_tool(**self._baseline_args())
        parsed = json.loads(result)
        assert isinstance(parsed["boot_seed"], str)

    def test_ax57_compact_is_string(self):
        from fw_server.server import build_directives_tool
        result = build_directives_tool(**self._baseline_args())
        parsed = json.loads(result)
        assert isinstance(parsed["ax57_compact"], str)

    def test_translation_hints_is_dict(self):
        from fw_server.server import build_directives_tool
        result = build_directives_tool(**self._baseline_args())
        parsed = json.loads(result)
        assert isinstance(parsed["translation_hints"], dict)

    def test_all_paths(self):
        """Each path P0–P3 should produce valid output."""
        from fw_server.server import build_directives_tool
        for p in ("P0", "P1", "P2", "P3"):
            args = self._baseline_args()
            args["path"] = p
            result = build_directives_tool(**args)
            parsed = json.loads(result)
            assert "error" not in parsed, f"Failed for path {p}: {parsed}"

    def test_with_anomalies(self):
        from fw_server.server import build_directives_tool
        args = self._baseline_args()
        args["anomalies"] = ["KV4-BREACH: composite=0.96"]
        result = build_directives_tool(**args)
        parsed = json.loads(result)
        assert "error" not in parsed

    def test_with_sentinel_signal(self):
        from fw_server.server import build_directives_tool
        args = self._baseline_args()
        args["sentinel_signal"] = {
            "confidence": 0.85,
            "assessment": "moderate risk",
        }
        result = build_directives_tool(**args)
        parsed = json.loads(result)
        assert "error" not in parsed

    def test_empty_vocab_and_scores(self):
        """Edge case: empty vocab and scores should not crash."""
        from fw_server.server import build_directives_tool
        result = build_directives_tool(
            path="P0",
            vocab=[],
            lens_scores={},
            composite=0.0,
            grade="Tasavvur",
            kavaid={"checks": {}},
            kavaid_pass_count=0,
        )
        parsed = json.loads(result)
        assert "error" not in parsed

    def test_json_string_coercion(self):
        """Arguments passed as JSON strings should be coerced."""
        from fw_server.server import build_directives_tool
        result = build_directives_tool(
            path="P1",
            vocab='["hudus"]',
            lens_scores='{"FOL": 0.8}',
            composite=0.8,
            grade="Tasdik",
            kavaid='{"checks": {"KV1": true}}',
            kavaid_pass_count=1,
        )
        parsed = json.loads(result)
        assert "error" not in parsed


# ═══════════════════════════════════════════════════════════════════════
# SECTION 4: run_lenses + synthesize_lenses (importability checks)
# ═══════════════════════════════════════════════════════════════════════


class TestSamplingToolsImportable:
    """Verify sampling-enabled tools are importable and handle no-context gracefully."""

    def test_run_lenses_importable(self):
        from fw_server.server import run_lenses_tool
        assert callable(run_lenses_tool)

    def test_synthesize_lenses_importable(self):
        from fw_server.server import synthesize_lenses_tool
        assert callable(synthesize_lenses_tool)

    @pytest.mark.asyncio
    async def test_run_lenses_no_ctx_returns_error(self):
        """run_lenses without MCP context should return an error JSON."""
        from fw_server.server import run_lenses_tool
        result = await run_lenses_tool(
            text="test",
            fire_plan=["FOL"],
            ctx=None,
        )
        parsed = json.loads(result)
        assert "error" in parsed
        assert "context" in parsed["error"].lower()

    @pytest.mark.asyncio
    async def test_synthesize_lenses_too_few_analyses(self):
        """synthesize_lenses with <2 analyses should return null synthesis."""
        from fw_server.server import synthesize_lenses_tool
        result = await synthesize_lenses_tool(
            text="test",
            analyses={"fol": {"summary": "x", "findings": []}},
            ctx=None,
        )
        parsed = json.loads(result)
        assert parsed.get("synthesis") is None
        assert "reason" in parsed

    @pytest.mark.asyncio
    async def test_synthesize_lenses_no_ctx_returns_error(self):
        """synthesize_lenses with ≥2 analyses but no ctx should error."""
        from fw_server.server import synthesize_lenses_tool
        result = await synthesize_lenses_tool(
            text="test",
            analyses={
                "fol": {"summary": "x", "findings": []},
                "bayesian": {"summary": "y", "findings": []},
            },
            ctx=None,
        )
        parsed = json.loads(result)
        assert "error" in parsed
        assert "context" in parsed["error"].lower()


# ═══════════════════════════════════════════════════════════════════════
# SECTION 5: Pipeline integration — route → score → directives
# ═══════════════════════════════════════════════════════════════════════


class TestDecomposedPipeline:
    """Integration tests chaining the 3 pure-computation tools."""

    def test_route_then_score_then_directives(self):
        """Full pipeline: route_text → score_composite → build_directives."""
        from fw_server.server import (
            route_text_tool,
            score_composite_tool,
            build_directives_tool,
        )

        # Step 1: Route
        route_out = json.loads(route_text_tool(
            "Hudûs delili, kâinatın hâdis olduğunu ispat eder."
        ))
        assert "error" not in route_out

        # Step 2: Create synthetic lens scores from fire plan
        synth_scores = {lens: 0.65 for lens in route_out["fire_plan"]}
        score_out = json.loads(score_composite_tool(synth_scores))
        assert "error" not in score_out
        assert score_out["composite"] <= 0.9499

        # Step 3: Build directives
        dir_out = json.loads(build_directives_tool(
            path=route_out["path"],
            vocab=route_out["vocab"],
            lens_scores=synth_scores,
            composite=score_out["composite"],
            grade=score_out["grade"],
            kavaid=score_out["kavaid"],
            kavaid_pass_count=score_out["kavaid_pass_count"],
            anomalies=score_out["anomalies"],
        ))
        assert "error" not in dir_out
        assert "shaping_directives" in dir_out
        assert "boot_seed" in dir_out

    def test_pipeline_grade_ceiling_ax56(self):
        """AX56: No pipeline output should produce Hakkalyakîn grade."""
        from fw_server.server import route_text_tool, score_composite_tool

        route_out = json.loads(route_text_tool("Perfect analysis text"))
        # Max scores
        max_scores = {lens: 0.99 for lens in route_out["fire_plan"]}
        if not max_scores:
            max_scores = {"FOL": 0.99}
        score_out = json.loads(score_composite_tool(max_scores))
        assert "Hakkalyakîn" not in score_out["grade"]
        assert score_out["composite"] <= 0.9499


# ═══════════════════════════════════════════════════════════════════════
# SECTION 6: Wrapper regression — dusun compat wrapper (ctx=None fallback)
# ═══════════════════════════════════════════════════════════════════════


class TestDusunWrapperRegression:
    """Regression tests for the dusun compat wrapper (ctx=None path).

    When MCP context is unavailable, the wrapper delegates to the regex
    fallback engine (fw_server.dusun._dusun).  These tests verify that
    the wrapper's fallback output has the same key structure as the
    granular pipeline.
    """

    EXPECTED_KEYS = {
        "path", "composite_score", "grade", "lens_scores",
        "vocabulary_detected", "fire_plan", "kavaid_pass_count",
    }

    @pytest.mark.asyncio
    async def test_wrapper_fallback_returns_expected_keys(self):
        """ctx=None: wrapper fallback output contains all expected keys."""
        from fw_server.server import dusun_tool

        raw = await dusun_tool(
            text="Hudûs delili, kâinatın hâdis olduğunu ispat eder.",
            ctx=None,
        )
        result = json.loads(raw)
        assert "error" not in result, f"Wrapper returned error: {result}"
        missing = self.EXPECTED_KEYS - result.keys()
        assert not missing, f"Missing keys in wrapper output: {missing}"

    @pytest.mark.asyncio
    async def test_wrapper_fallback_grade_not_hakkalyakin(self):
        """AX56: Wrapper fallback must never produce Hakkalyakîn grade."""
        from fw_server.server import dusun_tool

        raw = await dusun_tool(text="Perfect analysis text", ctx=None)
        result = json.loads(raw)
        assert "error" not in result
        assert "Hakkalyakîn" not in result.get("grade", "")

    @pytest.mark.asyncio
    async def test_wrapper_fallback_engine_field(self):
        """ctx=None path must report regex fallback engine."""
        from fw_server.server import dusun_tool

        raw = await dusun_tool(
            text="Kâinatta tesadüf yoktur, her şey hikmetle yaratılmıştır.",
            ctx=None,
        )
        result = json.loads(raw)
        assert "error" not in result
        assert "fallback" in result.get("engine", "").lower()
