"""Shared prompt assets for lens analysis and synthesis."""
