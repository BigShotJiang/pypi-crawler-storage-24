"""Per-lens vocabulary prompts shared across both servers."""

from __future__ import annotations

from dusun_shared.models import LensName


LENS_PROMPTS: dict[LensName, str] = {
    LensName.ONTOLOGICAL: """\
You are performing an **Ontological Analysis** of a foundational/philosophical text.

## Domain Vocabulary
Core terms: entity, substance, essence (mahiyet), attribute (sifat), property,
existence (vücud), being, necessary being (Vacib-ül Vücud), contingent being,
manifestation (tecelli), reality (hakikat), Names (esma/isim), acts (fiil),
works (eser), transparency (harfi meaning vs ismi meaning), poverty (fakr),
impotence (acz), emanation (tereşşuhat/sudur), indication (delalet).

## Analytical Targets
1. Identify the **core entities** and their ontological categories
2. Map **hierarchical relations** (is-a, part-of, depends-on)
3. Identify **constitutive dependencies** (what depends on what for existence)
4. Classify entities as **necessary vs contingent**
5. Trace **manifestation chains** (how higher realities appear in lower ones)
6. Identify **dual classifications** (harfi = transparent/pointing-beyond vs ismi = opaque/self-referential)

## Output Structure
For each finding provide:
- claim: the ontological claim
- evidence: the textual basis
- formal_notation: use predicate logic where possible (e.g., ∀x: Contingent(x) → ∃y: NecessaryBeing(y) ∧ Grounds(y,x))
- confidence: 0.0-1.0

List the domain-specific vocabulary terms you actually used in the analysis.""",
    LensName.MEREOLOGICAL: """\
You are performing a **Mereological Analysis** of a foundational/philosophical text.

## Domain Vocabulary
Core terms: part, whole, composition, constituent, aggregate, decomposition,
mereology, parthood, overlap, containment, nested structure, recursive,
teleological (purpose-driven), functional unit, integration, lattice,
part-whole relation, composed-of, consists-of, subdivided-into.
Source: külliyat (universals), cüz (particular), latife (subtle faculty),
unsur (element), uzuv (organ/member).

## Analytical Targets
1. Identify **whole-part structures** (what is composed of what)
2. Map **teleological relations** (what purpose each part serves in the whole)
3. Find **compositional hierarchies** (nested part-whole at multiple levels)
4. Identify **unity-in-multiplicity** patterns (how many parts form one whole)
5. Check for **mereological universalism** or **restrictivism** signals
6. Identify **functional dependencies** between parts

## Output Structure
For each finding provide:
- claim: the mereological claim
- evidence: the textual basis
- formal_notation: use parthood notation where possible (e.g., x ◁ y = "x is part of y", ⊕ for composition)
- confidence: 0.0-1.0

List the domain-specific vocabulary terms you actually used.""",
    LensName.FOL: """\
You are performing a **Formal Logic (FOL) Analysis** of a foundational/philosophical text.

## Domain Vocabulary
Core terms: premise, conclusion, inference, validity, soundness, entailment,
quantifier (∀ for-all, ∃ there-exists), predicate, proposition, implication (→),
biconditional (↔), conjunction (∧), disjunction (∨), negation (¬),
necessary condition, sufficient condition, if-and-only-if, modus ponens,
modus tollens, reductio ad absurdum, syllogism.

## Analytical Targets
1. Extract **premises and conclusions** from the text's arguments
2. **Formalize** key arguments in first-order predicate logic
3. Check **validity**: does the conclusion follow from the premises?
4. Check **soundness**: are the premises true?
5. Identify **implicit premises** (unstated assumptions)
6. Find **logical structure patterns** (analogical reasoning, argument from design, etc.)

## Output Structure
For each finding provide:
- claim: the logical claim or argument structure
- evidence: the textual passage being formalized
- formal_notation: REQUIRED — write the formal FOL expression (e.g., ∀x: Created(x) → ∃y: Creator(y) ∧ Causes(y,x))
- confidence: 0.0-1.0

List the domain-specific vocabulary terms you actually used.""",
    LensName.BAYESIAN: """\
You are performing a **Bayesian Analysis** of a foundational/philosophical text.

## Domain Vocabulary
Core terms: hypothesis, evidence, prior probability, posterior probability,
likelihood, Bayes' theorem, conditional probability, credence, degree of belief,
confirmation, disconfirmation, weight of evidence, update, base rate,
inference (istidlal), proof (burhan/ispat), indication (delil/emare/hüccet),
testimony (şehadet), sign (alamet/nişane), contingency.

## Analytical Targets
1. Identify **hypotheses** the text argues for or against
2. Identify **evidence** presented and its **weight**
3. Reconstruct **prior → posterior** updates (how evidence changes belief)
4. Quantify **likelihood ratios** where the text provides enough structure
5. Identify **cumulative evidence** patterns (multiple independent signs)
6. Check for **base rate** awareness or neglect

## Output Structure
For each finding provide:
- claim: the evidential/probabilistic claim
- evidence: the textual basis
- formal_notation: use probability notation where possible (e.g., P(Design|Order) = P(Order|Design)·P(Design)/P(Order))
- confidence: 0.0-1.0

List the domain-specific vocabulary terms you actually used.""",
    LensName.GAME_THEORETIC: """\
You are performing a **Game-Theoretic Analysis** of a foundational/philosophical text.

## Domain Vocabulary
Core terms: player/agent, strategy, payoff, utility, equilibrium (Nash),
cooperation, defection, dominant strategy, Pareto optimal, zero-sum,
incentive, dilemma, mechanism design, collective action, free-rider.
Source: nefs (self/ego with stations: emmare, levvame, mulhime, mutmainne),
rational choice, moral hazard, trust game, repeated game.

## Analytical Targets
1. Identify **agents/players** (explicit and implicit — including nefs, reason, heart)
2. Map **strategies** available to each agent
3. Identify **payoff structures** (what each agent values)
4. Find **equilibria** (stable outcomes from strategic interaction)
5. Identify **cooperation vs defection** dynamics
6. Check for **mechanism design** (how the text structures incentives)

## Output Structure
For each finding provide:
- claim: the game-theoretic claim
- evidence: the textual basis
- formal_notation: use game notation where possible (e.g., payoff matrix, strategy profile (s₁,s₂), Nash equilibrium)
- confidence: 0.0-1.0

List the domain-specific vocabulary terms you actually used.""",
    LensName.CATEGORY_THEORETIC: """\
You are performing a **Category-Theoretic Analysis** of a foundational/philosophical text.

## Domain Vocabulary
Core terms: object, morphism (arrow), functor, natural transformation,
category, composition, identity, isomorphism, homomorphism, diagram,
commutative diagram, universal property, adjoint, duality, equivalence,
pullback, pushforward, representable, presheaf, monad, endofunctor.

## Analytical Targets
1. Identify **objects** (concepts, entities) and **morphisms** (relationships, transformations)
2. Find **functorial mappings** (structure-preserving maps between domains)
3. Identify **natural transformations** (systematic ways one mapping relates to another)
4. Check for **universal properties** (optimal solutions to mapping problems)
5. Find **commutative diagrams** (where order of composition doesn't matter)
6. Identify **adjunctions** (paired concepts that are dual to each other)

## Output Structure
For each finding provide:
- claim: the category-theoretic claim
- evidence: the textual basis
- formal_notation: REQUIRED — use category notation (e.g., F: C → D for functors, η: F ⇒ G for natural transformations)
- confidence: 0.0-1.0

List the domain-specific vocabulary terms you actually used.""",
    LensName.TOPOLOGICAL: """\
You are performing a **Topological/Holographic Analysis** of a foundational/philosophical text.

## Domain Vocabulary
Core terms: continuity, connectedness, boundary, open/closed, neighborhood,
topology, dimension, compactness, manifold, homeomorphism, invariant,
holographic, fractal, self-similar, seed, microcosm, macrocosm,
scale invariance, recursive structure, encoding, projection, isomorphism.
Source: besmele-fatiha relation, küçük bir kainat (small universe),
mirror (ayna), reflection, shadow (gölge), pattern (nakış), seed-in-whole,
part encoding the whole (holographic principle).

## Analytical Targets
1. Identify **dimensional structure** (what dimensions/aspects does the text operate on)
2. Find **continuity properties** (what remains invariant under transformation)
3. Identify **holographic seeds** (parts that encode/compress the whole)
4. Map **fractal/self-similar patterns** (same structure at different scales)
5. Find **boundary conditions** (what marks the edge between domains)
6. Identify **topological invariants** (properties preserved under deformation)

## Output Structure
For each finding provide:
- claim: the topological/holographic claim
- evidence: the textual basis
- formal_notation: use topological or set notation where possible (e.g., Besmele ≅ₜₒₚ Fatiha, meaning topologically isomorphic)
- confidence: 0.0-1.0

List the domain-specific vocabulary terms you actually used.""",
}


SYNTHESIS_PROMPT = """\
You are synthesizing the results of multiple analytical lens analyses on a single text.

You have been given individual analyses from {lens_count} lenses: {lens_names}.

## Your Task
1. Identify **cross-lens connections**: where do different lenses reinforce, extend, or tension each other?
2. Discover **emergent insights**: what becomes visible ONLY through the combination that no single lens shows?
3. Build a **unified interpretation** that weaves the lens findings into a coherent multi-dimensional understanding.
4. For each cross-connection, assess its **strength** (0.0-1.0).

## Key Principle
The synthesis should be MORE than the sum of parts. Don't just list findings
from each lens — find the deeper structure that connects them.

## Individual Lens Analyses
{analyses_text}
"""


COMPARISON_PROMPT = """\
You are comparing analyses of multiple texts through the **{lens_name}** lens.

## Your Task
1. Identify **shared patterns** that appear across all texts under this lens
2. Identify **divergences** where the texts differ under this lens
3. Generate a **comparative insight**: what does the comparison reveal
   that analyzing each text individually doesn't show?

## Analyses to Compare
{analyses_text}
"""


DEEP_DIVE_PROMPT = """\
You are performing a **deep dive** into a specific finding from a {lens_name} analysis.

## Original Finding
{finding_text}

## Original Context
Text ID: {text_id}
Lens: {lens_name}

## Your Task
1. Explore this finding in much greater depth
2. Break it down into **sub-findings** (more granular claims)
3. Identify **connections to other lenses** that this finding opens up
4. Provide extended **formal notation** where applicable
5. Assess confidence more carefully with explicit reasoning

Go deeper. The original analysis was a first pass — this is the second, more rigorous pass.
"""


__all__ = [
    "COMPARISON_PROMPT",
    "DEEP_DIVE_PROMPT",
    "LENS_PROMPTS",
    "SYNTHESIS_PROMPT",
]
