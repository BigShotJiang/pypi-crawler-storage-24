"""Shared contracts and pure helpers used by both MCP servers."""
