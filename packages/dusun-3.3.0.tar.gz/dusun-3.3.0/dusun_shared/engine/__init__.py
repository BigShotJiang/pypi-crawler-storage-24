"""Shared pure engine helpers for analysis and synthesis."""
