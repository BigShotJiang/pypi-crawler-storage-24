"""Shared Pydantic models for structured analysis results."""

from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class LensName(str, Enum):
    """The 7 analytical lenses."""

    ONTOLOGICAL = "ontological"
    MEREOLOGICAL = "mereological"
    FOL = "fol"
    BAYESIAN = "bayesian"
    GAME_THEORETIC = "game_theoretic"
    CATEGORY_THEORETIC = "category_theoretic"
    TOPOLOGICAL = "topological"


LENS_TO_TURKISH: dict[LensName, str] = {
    LensName.ONTOLOGICAL: "Ontoloji",
    LensName.MEREOLOGICAL: "Mereoloji",
    LensName.FOL: "FOL",
    LensName.BAYESIAN: "Bayes",
    LensName.GAME_THEORETIC: "OyunTeorisi",
    LensName.CATEGORY_THEORETIC: "KategoriTeorisi",
    LensName.TOPOLOGICAL: "Topoloji + Holografik",
}


class Finding(BaseModel):
    """A single analytical finding from a lens."""

    claim: str = Field(description="The main analytical claim")
    evidence: str = Field(description="Textual evidence supporting the claim")
    formal_notation: Optional[str] = Field(
        None,
        description="Formal representation (logic formula, category diagram, probability expression)",
    )
    confidence: float = Field(
        ge=0.0,
        le=1.0,
        description="Confidence in this finding (0=speculative, 1=certain)",
    )


class LensConnection(BaseModel):
    """A connection between findings from two different lenses."""

    from_lens: LensName
    to_lens: LensName
    relationship: str = Field(description="How these findings relate")
    strength: float = Field(
        ge=0.0, le=1.0, description="Connection strength (0=weak, 1=strong)"
    )


class LensAnalysis(BaseModel):
    """Complete analysis result for one lens applied to one text."""

    text_id: str
    lens: LensName
    summary: str = Field(description="2-3 sentence overview of findings")
    findings: list[Finding] = Field(description="Ordered list of key findings")
    vocabulary_used: list[str] = Field(
        description="Domain-specific terms from this lens that were applied",
    )
    formal_section: Optional[str] = Field(
        None,
        description="Extended formal notation section (proofs, diagrams, equations)",
    )
    raw_prose: str = Field(description="Full narrative analysis text")
    model: str = Field(description="LLM model used for this analysis")


class Synthesis(BaseModel):
    """Cross-lens synthesis combining results from multiple lens analyses."""

    text_id: str
    lenses_included: list[LensName]
    unified_interpretation: str = Field(
        description="Unified narrative combining all lens perspectives",
    )
    cross_connections: list[LensConnection] = Field(
        description="Connections discovered between lens findings",
    )
    emergent_insights: list[str] = Field(
        description="Insights visible only through multi-lens combination",
    )
    overall_confidence: float = Field(
        ge=0.0,
        le=1.0,
        description="Overall confidence in the synthesis",
    )
    model: str = Field(description="LLM model used for synthesis")


class TextComparison(BaseModel):
    """Comparison of analyses across multiple texts."""

    text_ids: list[str]
    lens: LensName
    shared_patterns: list[str] = Field(
        description="Patterns found across all compared texts",
    )
    divergences: list[str] = Field(
        description="Where the texts diverge under this lens",
    )
    comparative_insight: str = Field(
        description="What the comparison reveals that individual analyses don't",
    )
    model: str = Field(description="LLM model used for comparison")


class DeepDiveResult(BaseModel):
    """Result of drilling deeper into a specific finding."""

    text_id: str
    lens: LensName
    original_finding: str = Field(description="The finding being explored")
    extended_analysis: str = Field(description="Deeper exploration of the finding")
    sub_findings: list[Finding] = Field(
        description="More granular findings within this area",
    )
    related_connections: list[LensConnection] = Field(
        description="Connections to other lenses discovered during deep dive",
    )
    model: str = Field(description="LLM model used for deep dive")


class AnalysisStatus(BaseModel):
    """Status of analyses completed in the current session."""

    text_id: str
    completed_lenses: list[LensName]
    pending_lenses: list[LensName]
    has_synthesis: bool
    cached_count: int = Field(description="Number of analyses in persistent cache")


class TextInfo(BaseModel):
    """Metadata about an available source text."""

    text_id: str
    title: str
    word_count: int
    preview: str = Field(description="First ~200 characters of the text")


__all__ = [
    "AnalysisStatus",
    "DeepDiveResult",
    "Finding",
    "LensAnalysis",
    "LensConnection",
    "LensName",
    "LENS_TO_TURKISH",
    "Synthesis",
    "TextComparison",
    "TextInfo",
]
