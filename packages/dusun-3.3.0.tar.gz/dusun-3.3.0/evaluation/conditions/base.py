"""Abstract interface for experimental conditions."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict


@dataclass
class ConditionOutput:
    """Standardised output from any condition."""

    condition_id: str  # "NAKED" | "SCAFFOLD_FULL" | "SCAFFOLD_PARTIAL" | "VOCAB_ONLY"
    text_id: str  # Corpus text ID
    raw_output: str  # The full text output (analysis)
    metadata: Dict[str, Any] = field(default_factory=dict)


class ConditionRunner(ABC):
    """Base class for all 4 experimental conditions."""

    @abstractmethod
    def condition_id(self) -> str: ...

    @abstractmethod
    async def run(self, text: str, text_id: str) -> ConditionOutput:
        """Run the condition on one text. Returns standardised output."""
        ...
