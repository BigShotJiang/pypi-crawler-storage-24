"""Condition 4: VOCABULARY_ONLY — Lens names in prompt, no MCP machinery.

The critical control: prompts the LLM to use the 7 lens names/descriptions
but WITHOUT any MCP infrastructure. Isolates whether the value is in the
structured machinery vs. just suggesting the right vocabulary.
"""

from __future__ import annotations

from .base import ConditionOutput, ConditionRunner

VOCABULARY_PROMPT = """\
Analyze the following text through these 7 analytical perspectives.
For each perspective, provide substantive analysis (not just mention).

1. **Ontological Analysis**: Identify the core entities, their categories,
   hierarchical relations, and constitutive dependencies.

2. **Mereological Analysis**: Identify whole-part structures, teleological
   relations between parts, and how parts relate to the whole.

3. **Formal Logic (FOL)**: Identify premises, conclusions, logical structure.
   Formalize key arguments. Check for validity and soundness.

4. **Bayesian Analysis**: Identify hypotheses, evidence, prior probabilities.
   Show how evidence updates beliefs. Quantify where possible.

5. **Game-Theoretic Analysis**: Identify agents/players, strategies, payoffs,
   equilibria. What incentive structures are at play?

6. **Category-Theoretic Analysis**: Identify objects, morphisms, functors.
   What structural transformations preserve essential properties?

7. **Topological/Holographic Analysis**: Identify dimensional structure,
   continuity properties, seed-whole relationships, fractal patterns.

After analyzing each lens, synthesize: How do the lenses connect?
What does the combination reveal that no single lens shows alone?

Text:
{text}
"""


class VocabularyOnlyRunner(ConditionRunner):
    """Condition 4 — lens names in prompt, no MCP machinery."""

    def __init__(self, llm_client):
        self.llm_client = llm_client

    def condition_id(self) -> str:
        return "VOCAB_ONLY"

    async def run(self, text: str, text_id: str) -> ConditionOutput:
        prompt = VOCABULARY_PROMPT.format(text=text)
        response = await self.llm_client.generate(prompt)
        return ConditionOutput(
            condition_id="VOCAB_ONLY",
            text_id=text_id,
            raw_output=response,
            metadata={"prompt_template": "VOCABULARY_PROMPT"},
        )
