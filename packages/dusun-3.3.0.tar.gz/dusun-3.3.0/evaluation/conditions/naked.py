"""Condition 1: NAKED — Raw LLM with no scaffold.

Calls the LLM directly with zero scaffolding — a generic
"analyse deeply" prompt with no lens names, no hints, no structure.
"""

from __future__ import annotations

from .base import ConditionOutput, ConditionRunner

NAKED_PROMPT = """\
Provide a deep, comprehensive, multi-dimensional analysis of the following text.
Consider all relevant perspectives: logical structure, relationships between parts,
underlying assumptions, implicit reasoning, and any hidden connections or patterns.
Be thorough and insightful.

Text:
{text}
"""


class NakedRunner(ConditionRunner):
    """Condition 1 — raw LLM, zero scaffold."""

    def __init__(self, llm_client):
        self.llm_client = llm_client

    def condition_id(self) -> str:
        return "NAKED"

    async def run(self, text: str, text_id: str) -> ConditionOutput:
        prompt = NAKED_PROMPT.format(text=text)
        response = await self.llm_client.generate(prompt)
        return ConditionOutput(
            condition_id="NAKED",
            text_id=text_id,
            raw_output=response,
            metadata={"prompt_template": "NAKED_PROMPT"},
        )
