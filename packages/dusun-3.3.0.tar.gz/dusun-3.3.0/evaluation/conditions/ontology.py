"""Primary analysis pathway: 7-Lens Ontological Framework.

This is the proven-optimal pathway. The 7-lens ontology provides
+207 Elo over baseline by partitioning the analytical search space
into 7 complementary dimensions. No computation required.

Evidence: Run 3 (Elo 1582), Run 5 (Elo 1605).
Wins all 5 pairwise criteria vs SCAFFOLD_FULL.

This module re-exports from vocabulary_only — the implementation is
identical. The rename signals that this is the primary pathway,
not a control condition.
"""

from .vocabulary_only import VocabularyOnlyRunner, VOCABULARY_PROMPT

OntologyRunner = VocabularyOnlyRunner

__all__ = ["OntologyRunner", "VOCABULARY_PROMPT"]
