"""Empirical MCP Evaluation — ablation experiment for the dusun cognitive scaffold."""
