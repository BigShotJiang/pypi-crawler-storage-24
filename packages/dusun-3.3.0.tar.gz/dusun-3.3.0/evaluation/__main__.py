"""CLI entry-point: python -m evaluation [--max-texts N] [--skip-generation] [--skip-judging]"""

import argparse
import asyncio
import logging
import sys

from .orchestrator import Experiment


def main() -> None:
    parser = argparse.ArgumentParser(description="Run dusun evaluation experiment")
    parser.add_argument("--max-texts", type=int, default=None,
                        help="Limit corpus to N texts (balanced across domains)")
    parser.add_argument("--skip-generation", action="store_true",
                        help="Skip Phase 2 (use cached outputs)")
    parser.add_argument("--skip-judging", action="store_true",
                        help="Skip Phase 3-4 (use cached scores/pairwise)")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    exp = Experiment()
    report = asyncio.run(exp.run(
        skip_generation=args.skip_generation,
        skip_judging=args.skip_judging,
        max_texts=args.max_texts,
    ))
    print(f"\n✅ Report: {report}")


if __name__ == "__main__":
    main()
