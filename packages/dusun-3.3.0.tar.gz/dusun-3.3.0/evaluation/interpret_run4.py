"""Run 4 results interpreter — maps output to pre-registered decision tree."""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

RUN_DIR = Path("evaluation/results/run_20260311_064520")


def _find_elo(report: str) -> dict[str, float]:
    """Extract Elo scores from Bradley-Terry table: | Condition | Strength | Elo |"""
    elos: dict[str, float] = {}
    in_bt_section = False
    for line in report.splitlines():
        if "Bradley-Terry" in line:
            in_bt_section = True
            continue
        if in_bt_section and line.startswith("##"):
            in_bt_section = False
        if not in_bt_section:
            continue
        # BT table: | COND | strength | elo |
        m = re.match(r"\|\s*(\w+)\s*\|\s*[\d.]+\s*\|\s*([\d]+)\s*\|", line)
        if m:
            cond, elo = m.group(1).upper(), float(m.group(2))
            if cond in {"NAKED", "SCAFFOLD_FULL", "SCAFFOLD_PARTIAL",
                        "VOCAB_ONLY", "TWOSTEP"}:
                elos[cond] = elo
    return elos


def _find_discovery(report: str) -> dict[str, float]:
    """Extract discovery scores from Summary Metrics table.
    
    Table format: | Condition | Lens Coverage | ADS | CLIS | Discovery |
    Discovery is the 4th number column (0-indexed: 3).
    """
    disc: dict[str, float] = {}
    in_summary = False
    for line in report.splitlines():
        if "Summary Metrics" in line:
            in_summary = True
            continue
        if in_summary and line.startswith("##"):
            in_summary = False
        if not in_summary:
            continue
        m = re.match(r"\|\s*(\w+)\s*\|(.+)", line)
        if m:
            cond = m.group(1).upper()
            if cond in {"NAKED", "SCAFFOLD_FULL", "SCAFFOLD_PARTIAL",
                        "VOCAB_ONLY", "TWOSTEP"}:
                nums = re.findall(r"[\d.]+", m.group(2))
                if len(nums) >= 4:
                    val = float(nums[3])  # Discovery is 4th column
                    if 0 < val < 5:
                        disc[cond] = val
    return disc


def _find_hypothesis(report: str, h_id: str) -> dict:
    """Extract hypothesis test result from JSON code block under ### H_id."""
    result = {"found": False, "p_value": None, "significant": None}
    lines = report.splitlines()
    # Find the section header
    for i, line in enumerate(lines):
        if line.strip() == f"### {h_id}":
            result["found"] = True
            # Collect JSON block after the header
            json_lines = []
            in_json = False
            for j in range(i + 1, min(i + 50, len(lines))):
                if lines[j].strip() == "```json":
                    in_json = True
                    continue
                if lines[j].strip() == "```" and in_json:
                    break
                if in_json:
                    json_lines.append(lines[j])
            if json_lines:
                try:
                    data = json.loads("\n".join(json_lines))
                    # Extract p-values from nested structure
                    p_values = []
                    for _key, val in data.items():
                        if isinstance(val, dict) and "p_value" in val:
                            p_values.append(val["p_value"])
                    if p_values:
                        result["p_value"] = min(p_values)
                        result["significant"] = result["p_value"] < 0.05
                except (json.JSONDecodeError, AttributeError):
                    pass
            break
    return result


def interpret():
    report_path = RUN_DIR / "report.md"
    if not report_path.exists():
        print(f"ERROR: {report_path} not found. Is Run 4 complete?")
        sys.exit(1)

    report = report_path.read_text(encoding="utf-8")
    print("=" * 60)
    print("RUN 4 RESULTS INTERPRETATION")
    print("=" * 60)

    # 1. Elo scores
    elos = _find_elo(report)
    print("\n## Elo Scores")
    for cond in ["TWOSTEP", "VOCAB_ONLY", "SCAFFOLD_FULL",
                 "SCAFFOLD_PARTIAL", "NAKED"]:
        score = elos.get(cond, "N/A")
        marker = ""
        if cond == "TWOSTEP" and isinstance(score, float):
            if score >= 1540:
                marker = " ✅ SUCCESS"
            elif score < 1490:
                marker = " ❌ FAILURE"
            else:
                marker = " ⚠️ AMBIGUOUS"
        print(f"  {cond:20s}: {score}{marker}")

    # 2. Discovery scores (from report table)
    disc = _find_discovery(report)
    print("\n## Discovery Scores")
    for cond in ["TWOSTEP", "SCAFFOLD_FULL", "VOCAB_ONLY",
                 "SCAFFOLD_PARTIAL", "NAKED"]:
        val = disc.get(cond, None)
        if val is not None:
            marker = ""
            if cond == "TWOSTEP":
                if val >= 1.40:
                    marker = " ✅ SUCCESS"
                elif val < 1.10:
                    marker = " ❌ FAILURE"
                else:
                    marker = " ⚠️ AMBIGUOUS"
            print(f"  {cond:20s}: {val:.3f}{marker}")
        else:
            print(f"  {cond:20s}: N/A")

    # 3. Hypotheses
    print("\n## Hypothesis Tests")
    for h_id in ["H9", "H10"]:
        result = _find_hypothesis(report, h_id)
        status = "found" if result["found"] else "NOT FOUND"
        p_str = f"p={result['p_value']}" if result["p_value"] else "p=?"
        sig = result["significant"]
        sig_str = "significant" if sig else ("not significant" if sig is False else "?")
        print(f"  {h_id}: {status}, {p_str}, {sig_str}")

    # 4. Decision tree
    twostep_elo = elos.get("TWOSTEP")
    twostep_disc = disc.get("TWOSTEP")

    print("\n## DECISION")
    if twostep_disc is not None and twostep_elo is not None:
        if twostep_disc >= 1.40 and twostep_elo >= 1540:
            print("  🏆 FULL SUCCESS — TWOSTEP is the production condition")
        elif twostep_disc >= 1.40 and twostep_elo < 1540:
            print("  ⚠️ PARTIAL — Discovery works, preference needs tuning")
        elif twostep_disc < 1.10:
            print("  ❌ FAIL — InsightBrief does not transfer discovery")
        elif twostep_disc >= 1.10 and twostep_elo >= 1540:
            print("  ⚠️ PARTIAL — Good overall, discovery benefit modest")
        else:
            print("  ⚠️ WEAK — Marginal on both metrics")
    else:
        print("  Could not determine — check report.md manually")
        print(f"  Elo: {twostep_elo}, Discovery: {twostep_disc}")

    print("\n## Raw Report (first 100 lines)")
    for line in report.splitlines()[:100]:
        print(f"  {line}")


if __name__ == "__main__":
    interpret()
