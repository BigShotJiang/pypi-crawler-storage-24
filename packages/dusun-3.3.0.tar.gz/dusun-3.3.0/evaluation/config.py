"""Global experiment configuration."""

from __future__ import annotations

import os
import subprocess
from pathlib import Path


def _get_git_commit() -> str:
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "HEAD"], text=True, stderr=subprocess.DEVNULL,
        ).strip()
    except Exception:
        return "unknown"


EVAL_ROOT = Path(__file__).resolve().parent
RESULTS_DIR = EVAL_ROOT / "results"

EXPERIMENT_CONFIG = {
    "version": "1.0",
    "seed": int(os.environ.get("EVAL_SEED", "42")),
    "judge_model": os.environ.get("EVAL_JUDGE_MODEL", "gpt-4o"),
    "judge_temperature": float(os.environ.get("EVAL_JUDGE_TEMPERATURE", "0.0")),
    "judge_repeat": int(os.environ.get("EVAL_JUDGE_REPEAT", "3")),
    "corpus_hash": None,  # set at runtime after loading corpus
    "git_commit": _get_git_commit(),
    "conditions": ["NAKED", "VOCAB_ONLY", "LLM_SCAFFOLD"],
    "partial_lenses": ["Ontoloji", "FOL", "Bayes"],
    # Deprecated (Run 1-5): SCAFFOLD_FULL, SCAFFOLD_PARTIAL, TWOSTEP
}

CONDITIONS = EXPERIMENT_CONFIG["conditions"]
PARTIAL_LENSES = EXPERIMENT_CONFIG["partial_lenses"]
