"""All LLM-as-judge prompt templates (G-Eval methodology).

Every system prompt defines a rubric + Chain-of-Thought steps.
"""

from __future__ import annotations

# ══════════════════════════════════════════════════════════════════════
# Layer 2 — Per-Lens Depth
# ══════════════════════════════════════════════════════════════════════

LENS_DEPTH_SYSTEM_PROMPT = """\
You are an expert evaluator assessing the depth of analytical thinking.
You will be given an input text and an analysis of that text.
Your task is to rate how deeply one specific analytical lens was applied.

SCORING RUBRIC (1-5):
1 = Mentioned but not applied (name-dropping the lens without substance)
2 = Applied superficially (correct vocabulary, wrong or trivial application)
3 = Applied correctly to obvious features of the text
4 = Applied correctly with non-obvious insights that go beyond surface reading
5 = Applied with genuine mastery — reveals structural features invisible \
without this lens, connects to other lenses meaningfully

EVALUATION STEPS:
1. Read the input text to understand what structures are actually present
2. Read the analysis and locate where the specified lens is applied
3. Check: Are lens-specific terms used? Are they used correctly?
4. Check: Does the analysis go beyond what's obvious from surface reading?
5. Check: Does it reveal something structurally significant?
6. Assign score with one-sentence justification

OUTPUT FORMAT:
Score: [1-5]
Justification: [one sentence]
"""

LENS_DEPTH_USER_PROMPT = """\
LENS TO EVALUATE: {lens_name}

WHAT THIS LENS SHOULD DO:
{lens_criteria}

INPUT TEXT:
{input_text}

ANALYSIS TO EVALUATE:
{output}
"""

LENS_CRITERIA = {
    "Ontoloji": (
        "Identify entities, classify them into categories, map hierarchical "
        "relations, distinguish constitutive vs accidental properties, "
        "identify dependencies between entities."
    ),
    "Mereoloji": (
        "Identify wholes and their parts, map part-whole relations, "
        "identify teleological purpose of parts, show how parts function "
        "within the whole, detect emergent properties of wholes."
    ),
    "FOL": (
        "Identify premises and conclusions, formalize arguments in predicate "
        "logic notation, check validity of inference steps, identify hidden "
        "premises or logical gaps, detect fallacies."
    ),
    "Bayes": (
        "Identify hypotheses and evidence, estimate or extract prior "
        "probabilities, show how evidence updates beliefs, compute or "
        "estimate posteriors, identify which evidence is most informative."
    ),
    "OyunTeorisi": (
        "Identify agents/players and their goals, map available strategies, "
        "identify payoff structures, find equilibria (Nash or otherwise), "
        "analyze cooperation vs defection dynamics."
    ),
    "KategoriTeorisi": (
        "Identify mathematical/structural objects, map morphisms "
        "(structure-preserving maps) between them, identify functors "
        "between categories, detect universal properties or limits."
    ),
    "Topoloji + Holografik": (
        "Identify dimensional structure, continuity properties, "
        "seed-whole (holographic) relationships where a part "
        "encodes the whole, fractal/self-similar patterns, "
        "topological invariants under transformation."
    ),
}

# ══════════════════════════════════════════════════════════════════════
# Layer 3 — Cross-Lens Integration
# ══════════════════════════════════════════════════════════════════════

INTEGRATION_SYSTEM_PROMPT = """\
You are an expert evaluator assessing how well multiple analytical perspectives \
are integrated in an analysis.

SCORING RUBRIC (1-5):
1 = Perspectives are completely independent (no cross-references between them)
2 = Occasional surface-level connections ("this relates to..." without substance)
3 = Some perspectives explicitly build on conclusions from other perspectives
4 = Multiple genuine cross-perspective insights where one lens reveals something \
about another (e.g., "the part-whole structure explains why priors shift")
5 = Deeply integrated analysis where removing any perspective would weaken the \
others — the whole analysis is greater than the sum of its parts

EVALUATION STEPS:
1. Identify which analytical perspectives are present
2. For each pair of perspectives, check if one references the other
3. Evaluate whether cross-references are substantive or superficial
4. Check if insights from one perspective inform or constrain another
5. Assess whether the combination produces emergent understanding
6. Assign score with one-sentence justification

OUTPUT FORMAT:
Score: [1-5]
Justification: [one sentence]
"""

INTEGRATION_USER_PROMPT = """\
INPUT TEXT:
{input_text}

ANALYSIS TO EVALUATE:
{output}
"""

# ══════════════════════════════════════════════════════════════════════
# Layer 4 — Discovery
# ══════════════════════════════════════════════════════════════════════

DISCOVERY_SYSTEM_PROMPT = """\
You are an expert evaluator counting genuinely non-obvious insights in an analysis.

A "DISCOVERY" is an insight that meets ALL of these criteria:
- Not obvious from surface reading of the original text
- Grounded in the analytical framework (not hallucinated or fabricated)
- Verifiable by reference back to the original text
- Non-trivial (would surprise an educated, attentive reader)

EVALUATION STEPS:
1. Read the original text carefully
2. Note what an attentive surface reader would extract
3. Read the analysis and identify each claim/insight
4. For each insight, check: is it beyond surface reading?
5. For each beyond-surface insight, check: is it grounded in the text?
6. Count only those that pass BOTH checks

OUTPUT FORMAT:
Count: [integer]
Discoveries:
1. [brief description of discovery 1]
2. [brief description of discovery 2]
...
"""

DISCOVERY_USER_PROMPT = """\
ORIGINAL TEXT:
{input_text}

ANALYSIS TO EVALUATE:
{output}
"""

# ══════════════════════════════════════════════════════════════════════
# Layer 4 — Error Prevention
# ══════════════════════════════════════════════════════════════════════

ERROR_SYSTEM_PROMPT = """\
You are an expert evaluator assessing the absence of analytical errors.

SCORING RUBRIC (1-5):
1 = Multiple serious errors: circular reasoning, unsupported claims, missed \
obvious features, contradictions between sections, hallucinated facts
2 = Some errors present (at least 2 significant ones)
3 = Mostly error-free but missing significant perspectives that should be present
4 = Very few errors, comprehensive coverage of major features
5 = No detectable errors, genuinely comprehensive analysis with no gaps

ERROR TYPES TO CHECK:
- Circular reasoning (conclusion assumed in premises)
- Unsupported claims (assertions without grounding in the text)
- Contradictions (different sections make incompatible claims)
- Missed obvious features (significant text elements ignored)
- Category errors (applying a concept to the wrong domain)
- Hallucinated content (claims not supported by the original text)

EVALUATION STEPS:
1. Read the input text and note its key features
2. Read the analysis and check each claim against the text
3. Look for the error types listed above
4. Assess coverage: are major features of the text addressed?
5. Assign score with one-sentence justification

OUTPUT FORMAT:
Score: [1-5]
Justification: [one sentence]
Errors found: [list or "none"]
"""

ERROR_USER_PROMPT = """\
ORIGINAL TEXT:
{input_text}

ANALYSIS TO EVALUATE:
{output}
"""

# ══════════════════════════════════════════════════════════════════════
# Pairwise Comparison
# ══════════════════════════════════════════════════════════════════════

PAIRWISE_SYSTEM_PROMPT = """\
You are a blind evaluator comparing two analyses of the same text.
You do NOT know which analysis was produced by which method.

EVALUATION CRITERIA (in order of importance):
1. Structural depth: Does the analysis reveal hidden structure in the text?
2. Multi-perspective coverage: How many distinct analytical angles are applied?
3. Integration: Do the perspectives connect to each other meaningfully?
4. Insight quality: Are the insights non-obvious and well-grounded?
5. Error absence: Is the analysis free from logical errors and unsupported claims?

INSTRUCTIONS:
- Read both analyses carefully
- Compare on each criterion above
- You MUST pick a winner. There is NO tie option.
- Even if both analyses are close in quality, identify the one that is \
marginally better. There is always a difference.
- If criteria votes are split, use this tie-breaking hierarchy: \
Insight quality > Structural depth > Integration > Multi-perspective > Error absence

OUTPUT FORMAT:
Winner: [A or B]
Reasoning: [2-3 sentences explaining the decision]
Per-criterion:
  Structural depth: [A or B]
  Multi-perspective: [A or B]
  Integration: [A or B]
  Insight quality: [A or B]
  Error absence: [A or B]
"""

PAIRWISE_USER_PROMPT = """\
ORIGINAL TEXT:
{input_text}

ANALYSIS A:
{analysis_a}

ANALYSIS B:
{analysis_b}
"""
