"""CLI entry point for the evaluation experiment."""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path

import click


@click.group()
def cli():
    """Dusun MCP Empirical Evaluation."""
    logging.basicConfig(level=logging.INFO, format="%(message)s")


@cli.command()
@click.option("--skip-generation", is_flag=True, help="Use cached outputs")
@click.option("--skip-judging", is_flag=True, help="Use cached scores")
@click.option("--max-texts", type=int, default=None, help="Limit corpus to N texts (balanced subset)")
def run(skip_generation: bool, skip_judging: bool, max_texts: int | None):
    """Run the full evaluation experiment."""
    from .orchestrator import Experiment

    exp = Experiment()
    asyncio.run(exp.run(
        skip_generation=skip_generation,
        skip_judging=skip_judging,
        max_texts=max_texts,
    ))


@cli.command()
@click.argument("text_id")
@click.argument(
    "condition",
    type=click.Choice(["NAKED", "SCAFFOLD_FULL", "SCAFFOLD_PARTIAL", "VOCAB_ONLY"]),
)
def run_single(text_id: str, condition: str):
    """Run a single text through a single condition (for debugging)."""
    from .corpus.loader import load_corpus
    from .orchestrator import Experiment

    corpus = load_corpus()
    text = next((t for t in corpus if t.id == text_id), None)
    if text is None:
        raise click.ClickException(f"Text ID '{text_id}' not found in corpus.")
    exp = Experiment()
    runner = exp.runners[condition]
    result = asyncio.run(runner.run(text.text, text.id))
    click.echo(result.raw_output)


@cli.command()
def validate_corpus():
    """Validate the test corpus against the JSON schema."""
    from .corpus.loader import load_corpus

    corpus = load_corpus()
    click.echo(f"Corpus valid: {len(corpus)} texts")
    for domain in sorted({t.domain for t in corpus}):
        count = sum(1 for t in corpus if t.domain == domain)
        click.echo(f"  {domain}: {count}")


@cli.command()
@click.argument("run_dir", type=click.Path(exists=True, path_type=Path))
def report(run_dir: Path):
    """Regenerate report from existing results."""
    from .report import regenerate_report

    path = regenerate_report(run_dir)
    click.echo(f"Report regenerated at {path}")


if __name__ == "__main__":
    cli()
