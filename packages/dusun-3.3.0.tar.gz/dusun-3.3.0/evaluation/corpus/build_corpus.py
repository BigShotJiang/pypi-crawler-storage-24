#!/usr/bin/env python3
"""Build the evaluation corpus with 54 real English texts.

Run:  python -m evaluation.corpus.build_corpus
Writes evaluation/corpus/texts.json and validates against schema.json.
"""
from __future__ import annotations

import json
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent


# ── helpers ──────────────────────────────────────────────────────────────────
def t(id_: str, domain: str, diff: str, text: str, source: str,
      lenses: list[str], connections: list[str], structures: list[str]) -> dict:
    """Shorthand constructor for a corpus entry."""
    return {
        "id": id_,
        "domain": domain,
        "difficulty": diff,
        "text": text.strip(),
        "source": source,
        "ground_truth": {
            "expected_lenses": lenses,
            "hidden_connections": connections,
            "key_structures": structures,
        },
    }


# ═══════════════════════════════════════════════════════════════════════════
#  THEO  –  Theology / Risale-i Nur inspired public-domain paraphrases
# ═══════════════════════════════════════════════════════════════════════════
THEO = [
    # ── easy ─────────────────────────────────────────────────────────────
    t("THEO-E-01", "THEO", "easy",
      "In the ontology of Islamic theology, every entity in the created world "
      "points to a higher reality. The concept of Bismillah — 'In the Name of "
      "God' — establishes a hierarchy of meaning: the lowest creature acts as a "
      "mirror reflecting divine attributes. Just as a letter has no meaning "
      "without the writer, each entity derives its significance from its "
      "Maker. This ontological hierarchy implies that concepts such as mercy, "
      "provision, and beauty are not abstract but are instantiated in concrete "
      "entities throughout the cosmos. To study the entities of nature is "
      "therefore to read a book whose every concept points upward in a "
      "purposeful hierarchy of existence.",
      "Paraphrase of Said Nursi, The Words, First Word (public domain translation)",
      ["Ontoloji"],
      ["Ontological hierarchy mirrors the semiotic structure of language"],
      ["entity-attribute hierarchy", "Bismillah as ontological key"]),

    t("THEO-E-02", "THEO", "easy",
      "Worship, in its theological sense, represents a whole-part relationship "
      "between the human entity and the cosmos. Every constituent of the body — "
      "the eye that sees beauty, the tongue that tastes provision — is a part "
      "whose telos is gratitude. The whole-part structure extends outward: "
      "humanity is a constituent of the created order, and the created order is "
      "itself a part-whole reflection of divine names. This mereological "
      "reading of worship shows that prayer is not an isolated act but the "
      "natural telos of every constituent entity of existence, each part "
      "fulfilling its role within the greater whole. The concept of worship "
      "thus sits within an ontological hierarchy from body to cosmos.",
      "Paraphrase of Said Nursi, The Words, Fourth Word (public domain translation)",
      ["Mereoloji", "Ontoloji"],
      ["Mereological worship mirrors biological part-whole organization"],
      ["whole-part worship structure", "telos of bodily constituents"]),

    t("THEO-E-03", "THEO", "easy",
      "Faith, considered from an ontological perspective, is the recognition "
      "that every concept in the visible world has an invisible counterpart. "
      "A seed buried in the earth is an entity that encodes the concept of a "
      "tree, itself part of a hierarchy of life. The entities of the natural "
      "world — seeds, eggs, drops of water — form a concept map that ascends "
      "through levels of complexity. In this hierarchy, faith is the cognitive "
      "act of grasping the ontological link between each entity and its "
      "origin. The concept of trust (tawakkul) follows naturally: once the "
      "hierarchy is seen, reliance on its Author becomes rational. This "
      "ontological reading of faith treats the cosmos as a text whose entities "
      "serve as signs.",
      "Paraphrase of Said Nursi, The Words, Seventh Word (public domain translation)",
      ["Ontoloji"],
      ["Seeds as ontological encodings parallel information theory"],
      ["ontological hierarchy of natural entities", "faith as concept recognition"]),

    # ── medium ───────────────────────────────────────────────────────────
    t("THEO-M-01", "THEO", "medium",
      "The argument for resurrection draws on a mereological analysis of the "
      "cosmos. Every whole-part system in nature exhibits cycles of death and "
      "renewal: the tree whose constituents decompose to nourish the seed; the "
      "day that dies into night only to be reborn. The telos of these cycles, "
      "the argument claims, points beyond the material. If every constituent "
      "of a part-whole system subserves a purpose, then the grandest whole — "
      "the universe itself — must also have a telos. That telos is the "
      "resurrection: the re-assembly of every constituent into a final, "
      "perfected whole. The ontological claim is that the concept of justice "
      "requires an afterlife in which every entity receives its due, completing "
      "the hierarchy of divine attributes. The entities of this world are "
      "therefore not ends but constituents of a larger eschatological whole "
      "whose part-whole structure demands completion.",
      "Paraphrase of Said Nursi, The Words, Tenth Word (public domain translation)",
      ["Mereoloji", "Ontoloji"],
      ["Eschatological whole-part reasoning parallels thermodynamic cycles"],
      ["mereological resurrection argument", "telos of cosmic constituents",
       "ontological hierarchy of justice"]),

    t("THEO-M-02", "THEO", "medium",
      "The proof of Divine Unity (Tawhid) proceeds by formal logic. Take as "
      "an axiom that every effect requires a cause proportionate to it. From "
      "this premise, consider the universe as an effect exhibiting order. The "
      "conclusion follows: its cause must possess knowledge, will, and power "
      "commensurate with that order. A second premise holds that unity of "
      "design implies unity of designer — for if multiple independent causes "
      "were at work, the conclusion would be chaos, not cosmos. The axiom of "
      "parsimony strengthens the argument: one cause is simpler than many, so "
      "the rational conclusion favors monotheism. From these premises, the "
      "formal logic of Tawhid reaches its conclusion: every entity in the "
      "hierarchy of being is a concept expressing a single ontological source. "
      "The axiom of proportionate causation, combined with the premise of "
      "observed order, yields the conclusion of one Creator.",
      "Paraphrase of Said Nursi, The Words, Twenty-Second Word (public domain translation)",
      ["FOL", "Ontoloji"],
      ["Formal-logical structure of Tawhid maps to first-order predicate calculus"],
      ["axiom-premise-conclusion chain", "ontological unity argument"]),

    t("THEO-M-03", "THEO", "medium",
      "Providence can be analyzed through a Bayesian lens. Let the hypothesis "
      "H be 'a Wise Creator sustains the world' and the evidence E be 'complex "
      "ecosystems exist.' The prior probability P(H) is non-trivial given the "
      "design intuition shared across cultures. The likelihood P(E|H) — the "
      "probability of observing intricate ecological balance given a wise "
      "sustainer — is high. By contrast, the likelihood P(E|not-H) under a "
      "purely random model is vanishingly small. Applying Bayes' theorem, the "
      "posterior probability P(H|E) is overwhelmingly in favor of Providence. "
      "This Bayesian analysis of theological concepts treats the entities of "
      "the natural world as data points in an ongoing inference. Each new "
      "entity — the honeybee's dance, the salmon's migration — increases the "
      "posterior, updating our probability estimate. The hierarchy of "
      "ecological design serves as cumulative evidence in a Bayesian ontology "
      "of nature.",
      "Paraphrase of Said Nursi, The Words, inspired by the Tenth and Thirty-Third Words",
      ["Bayes", "Ontoloji"],
      ["Bayesian providence argument structurally mirrors scientific hypothesis testing"],
      ["Bayesian inference for providence", "prior-likelihood-posterior chain"]),

    # ── hard ──────────────────────────────────────────────────────────────
    t("THEO-H-01", "THEO", "hard",
      "A comprehensive theological-philosophical synthesis can be constructed "
      "by layering multiple analytical frameworks. Begin with ontology: every "
      "entity in the cosmos instantiates a concept within a hierarchy of "
      "divine names. Layer on mereology: these entities form whole-part "
      "systems, each constituent serving a telos that contributes to the "
      "whole. Next, deploy formal logic: the axiom that purposeful design "
      "implies a designer yields, via the premise of observed order, the "
      "conclusion of divine wisdom. Bayesian reasoning then quantifies "
      "confidence: the prior probability of a wise Creator, updated by the "
      "likelihood of each new evidence of design, produces a posterior that "
      "approaches certainty. Even game theory enters: the rational strategy "
      "for a player facing infinite payoff (eternal felicity) versus finite "
      "cost (worship) lands on the equilibrium of faith, echoing Pascal. "
      "Finally, a holographic reading: each seed contains the dimension of "
      "the whole tree in fractal miniature, and the continuity of this "
      "pattern across scales suggests a topological unity. This multi-lens "
      "synthesis — from ontological hierarchy to Bayesian posterior to game-"
      "theoretic equilibrium — illustrates the depth available when category "
      "theory's morphisms map between theological objects, each functor "
      "preserving structure across domains as an arrow from creation to "
      "Creator.",
      "Synthetic multi-lens analysis after Said Nursi, The Words (public domain)",
      ["Ontoloji", "Mereoloji", "FOL", "Bayes", "OyunTeorisi",
       "KategoriTeorisi", "Topoloji + Holografik"],
      ["All seven lenses converge on a single theological conclusion",
       "Category-theoretic functors unify the lens transitions"],
      ["seven-lens theological synthesis", "axiom-premise-conclusion-posterior chain",
       "game-theoretic equilibrium of faith", "holographic seed-tree fractal"]),

    t("THEO-H-02", "THEO", "hard",
      "The holographic principle in theology proposes that every dimension of "
      "divine meaning is encoded at every scale of creation. Consider a seed: "
      "it is a topological object whose fractal internal structure contains, "
      "in compressed form, the continuity of the entire tree's plan. From the "
      "molecular dimension to the ecological, the same pattern recurrs with "
      "seed-like encodings. This holographic reading of scripture finds "
      "parallels in topology: the continuity of divine attributes across "
      "entities forms a space where every open neighborhood (any single "
      "creature) reflects the whole. Furthermore, the fractal nature of "
      "Qur'anic surahs — each containing the seed of every theme — mirrors "
      "this topological self-similarity. The dimension of meaning is not "
      "reduced as we zoom in; rather, each scale reveals the full holographic "
      "content. This analysis connects the ontological hierarchy of entities "
      "with the topological concept of continuous mapping: every entity maps "
      "to the concept of its Creator through a holographic functor that "
      "preserves dimension and continuity across the hierarchy.",
      "Synthetic holographic-theological analysis after Said Nursi's Twenty-Fifth Word",
      ["Topoloji + Holografik", "Ontoloji"],
      ["Topological self-similarity in scripture parallels mathematical fractal theory"],
      ["holographic seed principle", "topological continuity of divine attributes",
       "fractal self-similarity in textual structure"]),

    t("THEO-H-03", "THEO", "hard",
      "Pascal's Wager can be reformulated as a rigorous game-theoretic model. "
      "Define two players: the Individual and Nature (or God). The Individual "
      "has two strategies: 'Believe' and 'Disbelieve.' Nature has two states: "
      "'God exists' and 'God does not exist.' The payoff matrix is as follows: "
      "if the Individual believes and God exists, the payoff is infinite "
      "felicity; if they believe and God does not exist, the payoff is a "
      "finite cost of worship. If the player disbelieves and God exists, the "
      "payoff is infinite loss; if they disbelieve and God does not exist, "
      "the payoff is a finite hedonic gain. Under any probability assignment "
      "where P(God exists) > 0, the expected payoff of 'Believe' dominates "
      "'Disbelieve.' The Nash equilibrium for the rational player is therefore "
      "faith. This game-theoretic analysis connects to Bayesian reasoning: "
      "the prior probability of God's existence, however small, when "
      "multiplied by infinite payoff, yields an infinite posterior expected "
      "utility. The equilibrium of faith is thus not merely a strategy but "
      "a conclusion from the axiom of rational self-interest, the premise "
      "of possible infinite payoff, and the formal logic of dominance.",
      "Game-theoretic reformulation of Pascal's Wager (public domain argument)",
      ["OyunTeorisi", "Bayes", "FOL"],
      ["Game-theoretic dominance argument isomorphic to Bayesian expected utility"],
      ["payoff matrix of faith", "Nash equilibrium analysis",
       "prior-probability-infinite-payoff argument"]),
]

# ═══════════════════════════════════════════════════════════════════════════
#  PHIL  –  Philosophy (public domain: Plato, Aristotle, Descartes, Kant …)
# ═══════════════════════════════════════════════════════════════════════════
PHIL = [
    # ── easy ─────────────────────────────────────────────────────────────
    t("PHIL-E-01", "PHIL", "easy",
      "The Socratic method operates through formal logic applied to dialogue. "
      "Socrates begins with a premise proposed by his interlocutor — for "
      "example, 'Justice is the advantage of the stronger.' He then derives, "
      "through a chain of premises and conclusions, a contradiction: if the "
      "stronger sometimes errs about their advantage, then justice would "
      "sometimes be contrary to the stronger's interest, negating the axiom. "
      "The conclusion is that the original premise must be revised. This "
      "method is ontological in character: it examines the concept of justice "
      "as an entity in a hierarchy of ideas, asking what justice truly is "
      "rather than merely cataloguing instances. The entities under discussion "
      "— justice, strength, advantage — are treated as real concepts whose "
      "hierarchy can be discovered through dialectical reasoning.",
      "Based on Plato, Republic Book I (public domain, Jowett translation)",
      ["FOL", "Ontoloji"],
      ["Socratic elenchus has the structure of formal proof by contradiction"],
      ["premise-contradiction-conclusion chain", "ontological concept analysis"]),

    t("PHIL-E-02", "PHIL", "easy",
      "Plato's Allegory of the Cave presents a mereological picture of "
      "reality. The prisoners in the cave perceive shadows — mere parts of "
      "a whole reality they cannot see. Each shadow is a constituent of the "
      "prisoners' world, yet the telos of knowledge is to ascend from part "
      "to whole: from shadow to object, from object to the Form. The "
      "whole-part structure is ontological: the world of Forms is the "
      "complete whole, while the sensory world consists of constituent "
      "reflections. Each entity — a shadow on the wall — is a partial "
      "instantiation of a higher concept in the hierarchy of being. The "
      "part-whole relationship between shadow and Form defines the "
      "ontological hierarchy: shadows are constituents of appearance, "
      "while Forms constitute the whole of reality. The telos of the "
      "philosopher is to move from constituent parts to the unified whole.",
      "Based on Plato, Republic Book VII (public domain, Jowett translation)",
      ["Mereoloji", "Ontoloji"],
      ["The Cave allegory maps directly to mereological part-whole ascent"],
      ["shadow-Form part-whole hierarchy", "ontological ascent from constituents"]),

    t("PHIL-E-03", "PHIL", "easy",
      "Descartes' argument in the Meditations proceeds by formal logic from "
      "radical doubt to certainty. The axiom of the method is: accept nothing "
      "as true that can be doubted. From this axiom, the premise that senses "
      "sometimes deceive leads to the conclusion that sense-data is unreliable. "
      "A second premise — that an evil demon could fabricate all experience — "
      "extends the conclusion to all external knowledge. Yet one premise "
      "resists: the very act of doubting proves the doubter's existence. The "
      "conclusion 'I think, therefore I am' (Cogito ergo sum) is an axiom of "
      "self-evidence. Ontologically, the Cogito establishes the hierarchy of "
      "certain knowledge: the thinking entity is the foundational concept from "
      "which all other entities in the hierarchy of knowledge must be derived.",
      "Based on René Descartes, Meditations on First Philosophy (1641, public domain)",
      ["FOL", "Ontoloji"],
      ["Cartesian doubt has the structure of formal reductio ad absurdum"],
      ["axiom-of-doubt methodology", "Cogito as foundational entity in knowledge hierarchy"]),

    # ── medium ───────────────────────────────────────────────────────────
    t("PHIL-M-01", "PHIL", "medium",
      "Kant's Critique of Pure Reason introduces a revolutionary ontological "
      "framework. The concept of the 'thing-in-itself' (Ding an sich) "
      "establishes a hierarchy between phenomena (things as they appear) and "
      "noumena (things as they are). Every entity we perceive is filtered "
      "through the categories of the understanding — concepts like causality, "
      "substance, and unity — which form an a priori hierarchy. Kant's "
      "argument proceeds by formal logic: the premise that synthetic a priori "
      "judgments are possible leads to the conclusion that the mind actively "
      "structures experience. The axiom of transcendental idealism is that "
      "space and time are not properties of entities-in-themselves but forms "
      "of human intuition. From these premises, the conclusion follows that "
      "the ontological hierarchy we perceive is partly constituted by the "
      "mind. The entities of experience are therefore co-constituted: "
      "constituents of both the thing-in-itself and the cognitive whole, "
      "a mereological interplay of noumenal parts and phenomenal wholes.",
      "Based on Immanuel Kant, Critique of Pure Reason (1781, public domain)",
      ["Ontoloji", "FOL", "Mereoloji"],
      ["Kantian categories function as ontological filters analogous to Bayesian priors"],
      ["phenomena-noumena hierarchy", "synthetic a priori as axiom",
       "mereological mind-world constitution"]),

    t("PHIL-M-02", "PHIL", "medium",
      "Hume's problem of induction challenges the logical foundation of "
      "empirical reasoning and invites a Bayesian response. Hume's premise "
      "is that no finite number of observations can logically guarantee a "
      "universal conclusion: the formal logic of deduction cannot bridge the "
      "gap from 'all observed swans are white' to 'all swans are white.' The "
      "axiom that the future will resemble the past is itself unproven, "
      "making the conclusion of inductive reasoning formally invalid. The "
      "Bayesian response reframes the problem: instead of certainty, we "
      "assign a prior probability to hypotheses and update via the likelihood "
      "of new evidence. The posterior probability P(H|E) = P(E|H) × P(H) / P(E) "
      "captures our evolving confidence. Each new white-swan observation "
      "increases the posterior without ever reaching certainty. This Bayesian "
      "reading of Hume shows that the ontological concept of 'natural law' "
      "is not a fixed entity in a hierarchy of certainties but a probability "
      "estimate in an evolving hierarchy of credences.",
      "Based on David Hume, Enquiry Concerning Human Understanding (1748, public domain)",
      ["Bayes", "FOL", "Ontoloji"],
      ["Bayesian epistemology dissolves Hume's problem by replacing logical certainty with probabilistic updating"],
      ["induction-as-Bayesian-updating", "prior-likelihood-posterior chain",
       "ontological status of natural laws"]),

    t("PHIL-M-03", "PHIL", "medium",
      "The mind-body problem, as articulated by Descartes and refined by "
      "subsequent philosophy, is fundamentally a mereological puzzle. The "
      "question is whether the mind is a constituent part of the body (a "
      "part-whole physicalism) or a distinct entity in the ontological "
      "hierarchy. Substance dualism posits two kinds of entity — mental "
      "and physical — each occupying a separate branch of the ontological "
      "hierarchy, with no clear whole-part relationship between them. The "
      "telos of consciousness, on this view, is irreducible to the telos "
      "of its bodily constituents. Physicalism, by contrast, treats mental "
      "states as constituents of brain processes: the mind is a part of the "
      "body, and consciousness is the emergent property of the whole neural "
      "system whose constituent parts are neurons. This mereological framing "
      "— is the mind a part-whole of the body or a separate entity in the "
      "concept hierarchy? — remains the central ontological question of the "
      "philosophy of mind.",
      "Based on the mind-body debate from Descartes to Chalmers (philosophical tradition)",
      ["Mereoloji", "Ontoloji"],
      ["Mind-body mereology parallels the emergence problem in complex systems theory"],
      ["dualist vs physicalist part-whole models", "telos of consciousness",
       "ontological hierarchy of mental entities"]),

    # ── hard ──────────────────────────────────────────────────────────────
    t("PHIL-H-01", "PHIL", "hard",
      "Heidegger's Being and Time redefines ontology itself. For Heidegger, "
      "the fundamental question is not 'what entities exist' but 'what is "
      "the meaning of Being?' — a question about the concept that makes all "
      "entity-talk possible. Dasein (human existence) occupies a unique place "
      "in the hierarchy of entities because it is the entity that questions "
      "its own Being. Heidegger's formal analysis proceeds from the axiom "
      "that Dasein's Being is 'care' (Sorge): the conclusion is that "
      "temporal structure — past (thrownness), present (falling), future "
      "(projection) — constitutes the whole of Dasein's existence. Each "
      "temporal dimension is a constituent of the whole, a mereological "
      "structure where the parts (past, present, future) form the whole-"
      "part unity of lived time. The telos of Dasein is 'authenticity': "
      "owning one's finitude. From a topological perspective, Heidegger's "
      "ontological space exhibits continuity — there are no sharp breaks "
      "between modes of Being, only a continuous dimension of disclosure. "
      "The fractal character of everydayness — the same patterns of care "
      "repeating at every scale of human activity — gives Heideggerian "
      "ontology a holographic quality: each moment seeds the whole of a life.",
      "Based on Martin Heidegger, Being and Time (1927, philosophical tradition)",
      ["Ontoloji", "Mereoloji", "Topoloji + Holografik"],
      ["Heidegger's temporal mereology anticipates dynamical-systems topology"],
      ["Dasein as self-questioning entity", "temporal whole-part structure",
       "topological continuity of Being", "fractal everydayness"]),

    t("PHIL-H-02", "PHIL", "hard",
      "Wittgenstein's Tractatus presents a picture theory of meaning that is "
      "simultaneously ontological and formal-logical. The axiom of the "
      "Tractatus is: 'The world is everything that is the case.' From this "
      "axiom, the premise that the world consists of facts (not things) leads "
      "to the conclusion that entities are constituted by their relations, "
      "not by intrinsic properties. The ontological hierarchy runs: objects → "
      "states of affairs → facts → the world. Each level is a whole-part "
      "structure: objects are constituents of states of affairs, which are "
      "constituents of facts, which constitute the whole world. The telos of "
      "language is to picture these facts via a formal logic of propositions. "
      "Each proposition is a morphism — a structure-preserving map — from "
      "language to reality. In category-theoretic terms, the Tractatus "
      "defines a functor from the category of propositions (objects: sentences; "
      "arrows: logical connectives) to the category of facts (objects: states "
      "of affairs; arrows: material relations). This morphism preserves "
      "logical structure, and the identity arrow maps each true proposition "
      "to its corresponding fact.",
      "Based on Ludwig Wittgenstein, Tractatus Logico-Philosophicus (1921, public domain)",
      ["Ontoloji", "FOL", "Mereoloji", "KategoriTeorisi"],
      ["Tractarian picture theory is a category-theoretic functor between language and world"],
      ["ontological hierarchy: objects→facts→world", "whole-part propositional structure",
       "axiom-premise-conclusion logical scaffolding",
       "functor from propositions to facts"]),

    t("PHIL-H-03", "PHIL", "hard",
      "Deleuze's ontology of difference challenges the classical hierarchy "
      "of concepts. Rather than a hierarchy where general entities subsume "
      "particular ones, Deleuze proposes an ontology of pure difference: "
      "every entity is a singularity, not a copy of a higher concept. The "
      "ontological hierarchy is flattened into a plane of immanence where "
      "entities relate through continuous variation rather than taxonomic "
      "classification. From a topological viewpoint, this plane has the "
      "structure of a smooth manifold: continuity replaces discrete "
      "hierarchical steps, and each dimension of variation is equally real. "
      "The concept of the 'fold' (le pli) introduces a fractal geometry "
      "into ontology: entities are not atoms but folds within folds, each "
      "fold containing a holographic image of the whole. A seed does not "
      "represent a tree — it is a dimensional fold whose unfolding IS "
      "the tree. The Deleuzian entity is therefore a topological object "
      "whose identity is constituted by its continuous morphisms with "
      "other objects, much as in category theory an object is defined by "
      "its arrows (morphisms) rather than its internal anatomy. The "
      "functor concept translates: the map from one stratum of reality "
      "to another preserves relational structure while transforming content.",
      "Based on Gilles Deleuze, Difference and Repetition (1968, philosophical tradition)",
      ["Ontoloji", "Topoloji + Holografik", "KategoriTeorisi"],
      ["Deleuzian immanence is a topological space where category-theoretic arrows replace essential substances"],
      ["plane of immanence as smooth manifold", "fractal fold ontology",
       "morphism-based identity", "holographic seed-unfolding"]),
]

# ═══════════════════════════════════════════════════════════════════════════
#  MATH  –  Mathematics (public domain: Euclid, Cantor, Gödel …)
# ═══════════════════════════════════════════════════════════════════════════
MATH = [
    # ── easy ─────────────────────────────────────────────────────────────
    t("MATH-E-01", "MATH", "easy",
      "Set theory provides the foundational ontology of modern mathematics. "
      "A set is the most basic entity: a collection of distinct objects "
      "unified by a concept. The hierarchy of sets — elements, subsets, "
      "power sets — mirrors an ontological hierarchy of mathematical entities. "
      "The axiom of extensionality states that two sets are equal if and only "
      "if they have the same elements, grounding the concept of identity. "
      "From the premise that every mathematical entity can be represented as "
      "a set, the conclusion follows that set theory is the universal "
      "ontology of mathematics. The empty set is the foundational entity "
      "from which the entire hierarchy is constructed: from ∅ we build {∅}, "
      "then {∅, {∅}}, and so on. Each step in the hierarchy involves the "
      "concept of containment, a formal relation between entities.",
      "Based on naive set theory (Cantor, Zermelo, public domain mathematical tradition)",
      ["Ontoloji", "FOL"],
      ["Set-theoretic hierarchy is isomorphic to ontological concept hierarchies"],
      ["axiom of extensionality", "hierarchical set construction",
       "formal identity of entities"]),

    t("MATH-E-02", "MATH", "easy",
      "Probability theory formalizes reasoning under uncertainty through "
      "Bayesian and frequentist frameworks. The basic concept is a "
      "probability measure P on a sample space. Bayes' theorem — P(H|E) = "
      "P(E|H) × P(H) / P(E) — provides the fundamental rule for updating "
      "beliefs. Given a prior probability P(H) representing initial "
      "credence, the likelihood P(E|H) measuring how expected the evidence "
      "is under the hypothesis, we compute the posterior probability P(H|E). "
      "This Bayesian framework treats probability as a measure of rational "
      "belief. For example, if a medical test has a likelihood of 0.95 for "
      "detecting a disease, and the prior probability of the disease is "
      "0.01, the posterior after a positive test is much lower than the "
      "raw likelihood suggests, illustrating the base-rate fallacy. The "
      "probability calculus thus serves as a formal logic of uncertainty.",
      "Based on probability theory (Laplace, Bayes, Kolmogorov — public domain)",
      ["Bayes"],
      ["Bayesian updating is the probabilistic analogue of logical modus ponens"],
      ["prior-likelihood-posterior computation", "base-rate fallacy example"]),

    t("MATH-E-03", "MATH", "easy",
      "Euclidean geometry provides a paradigmatic example of axiomatic "
      "reasoning. Starting from five axioms — including the parallel "
      "postulate — and using formal logic, Euclid derives hundreds of "
      "theorems. Each proof follows a chain from premise to conclusion. "
      "Consider the proof that the angles of a triangle sum to 180 degrees: "
      "the premise that a line can be drawn parallel to any side, combined "
      "with the axiom of alternate interior angles, leads to the conclusion. "
      "The ontological hierarchy of Euclidean entities — points, lines, "
      "planes — forms a concept system where each higher entity is built "
      "from lower ones. A line segment has the topological property of "
      "continuity: between any two points there is always another point, "
      "giving the real line its characteristic dimension of one. This "
      "continuity is foundational to the topological study of space.",
      "Based on Euclid, Elements (c. 300 BCE, public domain)",
      ["FOL", "Ontoloji", "Topoloji + Holografik"],
      ["Euclidean axiomatics anticipates formal first-order theories"],
      ["axiomatic deduction chain", "ontological hierarchy of geometric entities",
       "topological continuity of the line"]),

    # ── medium ───────────────────────────────────────────────────────────
    t("MATH-M-01", "MATH", "medium",
      "Cantor's diagonal argument demonstrates that the real numbers are "
      "uncountably infinite — a landmark result in formal logic and set "
      "theory. The proof proceeds by contradiction. Assume the premise that "
      "all real numbers between 0 and 1 can be listed in a sequence. "
      "Construct a new number by changing the nth digit of the nth number: "
      "this entity differs from every number in the list. The conclusion "
      "contradicts the premise, proving the reals are uncountable. This "
      "argument establishes an ontological hierarchy among infinities: the "
      "countable infinity of natural numbers is a strictly smaller entity "
      "than the uncountable infinity of the reals. The concept of "
      "cardinality creates a hierarchy of infinite sets. From the axiom of "
      "the power set (∀S, P(S) has strictly greater cardinality), the "
      "conclusion follows that there is no largest infinity — the hierarchy "
      "of entities extends without bound.",
      "Based on Georg Cantor, diagonal argument (1891, public domain)",
      ["FOL", "Ontoloji"],
      ["Diagonal argument technique reappears in Gödel's and Turing's proofs"],
      ["proof by contradiction structure", "ontological hierarchy of infinities",
       "axiom-to-conclusion chain"]),

    t("MATH-M-02", "MATH", "medium",
      "The epsilon-delta definition of a limit captures the topological "
      "concept of continuity in precise formal terms. A function f is "
      "continuous at a point c if for every ε > 0 there exists a δ > 0 "
      "such that |x - c| < δ implies |f(x) - f(c)| < ε. This definition "
      "operates in the topological dimension of the real line, where "
      "continuity means that nearby points map to nearby values — a "
      "topological invariant. The concept generalizes: in any topological "
      "space, continuity is defined by the preservation of open sets under "
      "preimage. The holographic aspect appears when we recognize that "
      "local continuity at each point seeds global properties: a function "
      "continuous on a closed interval achieves its maximum (the Extreme "
      "Value Theorem). The fractal-like iteration of the epsilon-delta "
      "game at every point, each dimension of the domain contributing, "
      "builds global continuity from local seeds.",
      "Based on Weierstrass and Cauchy, epsilon-delta analysis (19th century, public domain)",
      ["Topoloji + Holografik"],
      ["Epsilon-delta continuity is the local-to-global seed of topological analysis"],
      ["epsilon-delta as topological continuity", "local-seed-to-global-property",
       "dimension of the real line"]),

    t("MATH-M-03", "MATH", "medium",
      "Graph theory can be elegantly reformulated in the language of "
      "category theory. A directed graph is a category where the objects "
      "are vertices and the arrows (morphisms) are edges. Composition of "
      "morphisms corresponds to path concatenation: if there is an arrow "
      "from A to B and an arrow from B to C, their composition is the "
      "path from A to C. The identity arrow at each object is the trivial "
      "path from a vertex to itself. A functor from one graph-category to "
      "another is a graph homomorphism: it maps objects to objects and "
      "arrows to arrows, preserving the compositional structure. This "
      "categorical perspective reveals the ontological hierarchy of graph "
      "properties: entities like 'connected component' and 'spanning tree' "
      "are natural concepts in this framework. The concept of a universal "
      "property — defining an entity by its morphisms rather than its "
      "internal structure — transforms graph theory from a study of "
      "entities to a study of relationships between objects via arrows.",
      "Based on category theory applied to graph theory (Eilenberg-Mac Lane tradition)",
      ["KategoriTeorisi", "Ontoloji"],
      ["Category theory reveals that graph properties are defined by morphisms, not elements"],
      ["graph as category (objects + arrows)", "functor as graph homomorphism",
       "universal-property ontology"]),

    # ── hard ──────────────────────────────────────────────────────────────
    t("MATH-H-01", "MATH", "hard",
      "Gödel's First Incompleteness Theorem is a landmark of formal logic. "
      "The theorem states: for any consistent formal system F capable of "
      "expressing arithmetic, there exists a sentence G such that neither G "
      "nor ¬G is provable in F. The proof uses a diagonal construction: "
      "Gödel assigns each formula a number, then constructs a sentence G "
      "that effectively says 'I am not provable in F.' If G were provable, "
      "F would prove a falsehood, contradicting the axiom of consistency. "
      "If ¬G were provable, F would prove its own consistency, which by "
      "the Second Incompleteness Theorem it cannot. The conclusion: G is "
      "true but unprovable. This establishes a profound ontological result: "
      "the hierarchy of mathematical truth extends beyond any single formal "
      "system. No axiom set can capture all true statements. The premise "
      "of formal completeness — that every true sentence has a proof — "
      "fails. The entities of mathematics (true propositions) form a "
      "hierarchy that no finite set of axioms and rules (a system of "
      "formal logic) can exhaust. From the concept of self-reference, "
      "the conclusion of incompleteness follows inexorably.",
      "Based on Kurt Gödel, On Formally Undecidable Propositions (1931, public domain)",
      ["FOL", "Ontoloji"],
      ["Gödel's self-reference technique parallels Cantor's diagonal and Turing's halting argument"],
      ["Gödel numbering and self-reference", "axiom-consistency-incompleteness chain",
       "ontological hierarchy of mathematical truth"]),

    t("MATH-H-02", "MATH", "hard",
      "Algebraic topology provides powerful tools for classifying topological "
      "spaces. The fundamental group π₁(X) captures the topology of loops: "
      "two paths are equivalent if one can be continuously deformed into the "
      "other. This continuity-based classification reveals the dimension of "
      "a space's 'holes.' A sphere has a trivial fundamental group (every "
      "loop can be contracted), while a torus has fundamental group Z × Z, "
      "reflecting two independent dimensions of non-contractible loops. "
      "Homology extends this: the nth homology group Hₙ(X) captures "
      "n-dimensional topological features. The Euler characteristic — an "
      "alternating sum V - E + F — is a topological invariant with a "
      "holographic quality: it encodes global information in a single "
      "number. Fractal objects push the boundaries: their Hausdorff "
      "dimension is non-integer, and the seed pattern at small scales "
      "reproduces the whole. Category theory unifies these constructions: "
      "homology is a functor from the category of topological spaces "
      "(objects: spaces; morphisms: continuous maps) to the category of "
      "abelian groups. Each arrow-preserving functor translates topological "
      "information into algebraic information, the morphisms between "
      "objects carrying structure across domains.",
      "Based on algebraic topology (Poincaré, Eilenberg, Steenrod — mathematical tradition)",
      ["Topoloji + Holografik", "KategoriTeorisi"],
      ["Homology as functor bridges topology and algebra via category-theoretic morphisms"],
      ["fundamental group and continuity", "fractal Hausdorff dimension",
       "homology functor (objects→groups, morphisms→homomorphisms)",
       "holographic Euler characteristic"]),

    t("MATH-H-03", "MATH", "hard",
      "Category theory is the mathematics of mathematical structure itself. "
      "A category C consists of objects and morphisms (arrows) between them, "
      "with an associative composition law and an identity arrow for each "
      "object. A functor F: C → D maps objects of C to objects of D and "
      "arrows of C to arrows of D, preserving composition and identity. "
      "A natural transformation α: F ⇒ G is a family of morphisms "
      "α_X: F(X) → G(X) for each object X, satisfying a coherence condition "
      "with every arrow. These three levels — categories, functors, natural "
      "transformations — form a hierarchy that can itself be organized into "
      "a 2-category, with objects as categories, 1-morphisms as functors, "
      "and 2-morphisms as natural transformations. This ontological "
      "hierarchy of entities and concepts — objects defined by their arrows "
      "rather than by internal structure — represents a radical shift. The "
      "Yoneda Lemma, the central result, states that an object is fully "
      "determined by its morphisms: the functor Hom(-, X) encodes everything "
      "about X. This morphism-centric ontology parallels the concept of "
      "holographic encoding: each arrow seedling contains information about "
      "the whole categorical structure, and continuity of structure is "
      "preserved across functorial dimensions.",
      "Based on Eilenberg-Mac Lane category theory and the Yoneda Lemma (mathematical tradition)",
      ["KategoriTeorisi", "Ontoloji", "Topoloji + Holografik"],
      ["Yoneda Lemma implies holographic principle: objects fully encoded by their morphisms"],
      ["category-functor-natural transformation hierarchy",
       "objects-defined-by-arrows ontology", "Yoneda embedding",
       "holographic morphism encoding"]),
]

# ═══════════════════════════════════════════════════════════════════════════
#  SCI  –  Science (public domain: Newton, Darwin, Einstein …)
# ═══════════════════════════════════════════════════════════════════════════
SCI = [
    # ── easy ─────────────────────────────────────────────────────────────
    t("SCI-E-01", "SCI", "easy",
      "Newton's laws of motion establish a formal logic of physical "
      "causation. The first axiom (law of inertia) states that an entity "
      "in motion remains in motion unless acted upon by a force. From this "
      "premise and the second axiom (F = ma), the conclusion follows that "
      "acceleration is proportional to applied force. The third axiom — "
      "every action has an equal and opposite reaction — completes the "
      "system. These three axioms form the foundational hierarchy of "
      "classical mechanics: every physical concept (momentum, energy, work) "
      "is derived from them. The ontological structure is clear: forces are "
      "the fundamental entities, and all observable phenomena — from the "
      "fall of an apple to the orbit of the Moon — are conclusions drawn "
      "from these premises via the formal logic of calculus.",
      "Based on Isaac Newton, Principia Mathematica (1687, public domain)",
      ["FOL", "Ontoloji"],
      ["Newton's laws have the structure of formal axioms from which theorems are derived"],
      ["three-axiom hierarchical system", "force as foundational entity",
       "premise-to-conclusion mechanical reasoning"]),

    t("SCI-E-02", "SCI", "easy",
      "The water cycle exemplifies mereological reasoning in Earth science. "
      "Water exists in a whole-part system: the ocean is the whole from "
      "which constituent molecules evaporate. These vaporous constituents "
      "rise, condense into droplets (each a part of a cloud), and "
      "precipitate as rain — returning each constituent to the whole. The "
      "telos of the cycle is the redistribution of water across the planet. "
      "Each part-whole transition — liquid to vapor, vapor to droplet, "
      "droplet to river — involves a change of state in which the "
      "constituent entity transforms while the mereological whole (the "
      "hydrosphere) is conserved. Mountains, watersheds, and aquifers are "
      "larger constituents whose part-whole relationship to the ocean "
      "defines the geography of water flow. The telos of each constituent "
      "river is to return its parts to the oceanic whole.",
      "Based on Earth science textbook descriptions of the hydrological cycle",
      ["Mereoloji"],
      ["Water cycle mereology mirrors circulatory systems in biology"],
      ["whole-part water system", "constituent state transitions",
       "telos of hydrological redistribution"]),

    t("SCI-E-03", "SCI", "easy",
      "Cell biology reveals a mereological hierarchy of living matter. The "
      "cell is the fundamental entity of life — a whole containing "
      "constituent organelles, each with a specific telos. The nucleus is a "
      "constituent whose telos is information storage; mitochondria are "
      "constituents whose telos is energy production. These parts form a "
      "whole-part unity: the cell functions only when its constituents "
      "collaborate. At a higher level, cells are themselves constituents of "
      "tissues, tissues of organs, organs of body systems, and systems of "
      "the organism as a whole. This mereological hierarchy — from molecule "
      "to organelle to cell to organism — reflects an ontological concept: "
      "each level of the hierarchy is an entity whose properties emerge "
      "from the interactions of its constituent parts. The part-whole "
      "relationship between DNA and the cell illustrates how information "
      "at the smallest scale shapes the telos of the organism.",
      "Based on introductory cell biology (Schleiden, Schwann, Virchow — public domain concepts)",
      ["Mereoloji", "Ontoloji"],
      ["Cellular mereology is analogous to computational modular architecture"],
      ["organelle-cell-tissue-organism hierarchy", "telos of cellular constituents",
       "emergent properties from part-whole interactions"]),

    # ── medium ───────────────────────────────────────────────────────────
    t("SCI-M-01", "SCI", "medium",
      "The second law of thermodynamics has deep ontological and Bayesian "
      "implications. The law states that the entropy of an isolated system "
      "never decreases — a premise from which profound conclusions follow. "
      "Entropy measures the probability of a macrostate: high-entropy states "
      "are overwhelmingly more probable (higher likelihood) than low-entropy "
      "ones. The Bayesian interpretation: given the prior that all "
      "microstates are equally likely, the posterior probability of finding "
      "a system in a high-entropy state is vastly greater. Every spontaneous "
      "process — heat flow, gas expansion, mixing — moves the system toward "
      "states of higher probability. The ontological hierarchy of "
      "thermodynamic concepts — temperature, entropy, free energy — forms a "
      "conceptual framework where each entity describes a different facet "
      "of disorder. The Bayesian posterior updating occurs continuously: "
      "each new microstate observation reinforces the overwhelmingly "
      "probable conclusion of increasing entropy.",
      "Based on thermodynamics (Clausius, Boltzmann, Gibbs — public domain)",
      ["Bayes", "Ontoloji"],
      ["Statistical mechanics is a Bayesian framework where entropy is the log of the posterior"],
      ["entropy as Bayesian probability", "prior-likelihood-posterior in statistical mechanics",
       "ontological hierarchy of thermodynamic concepts"]),

    t("SCI-M-02", "SCI", "medium",
      "Mendelian genetics can be analyzed through both Bayesian reasoning "
      "and mereological structure. An organism is a whole whose constituent "
      "traits — height, color, seed shape — are determined by genes, "
      "themselves constituents of chromosomes. Mendel's law of segregation "
      "states that each constituent allele separates during gamete "
      "formation; the law of independent assortment states that different "
      "constituent genes sort into gametes independently. The probability "
      "of a particular offspring genotype can be computed using Bayesian "
      "reasoning: given the prior (parental genotypes) and likelihood "
      "(Mendelian ratios), the posterior probability of each offspring "
      "genotype follows. For a Tt × Tt cross, the prior probability of "
      "each allele combination yields a posterior of 3:1 phenotypic ratio. "
      "The whole-part structure — alleles as parts of genes, genes as "
      "parts of chromosomes, chromosomes as constituents of the organism — "
      "creates a mereological hierarchy where the telos of each "
      "constituent gene is its contribution to the organism's phenotype.",
      "Based on Gregor Mendel, Experiments on Plant Hybridization (1866, public domain)",
      ["Bayes", "Mereoloji"],
      ["Mendelian probability is isomorphic to Bayesian prior-posterior updating"],
      ["allelic segregation as mereological decomposition",
       "prior-likelihood-posterior genetic ratios",
       "telos of constituent genes"]),

    t("SCI-M-03", "SCI", "medium",
      "Special relativity restructures the ontological hierarchy of "
      "physical concepts. Einstein's two premises — the constancy of the "
      "speed of light and the equivalence of inertial frames — lead, via "
      "formal logic, to the conclusion that space and time are not separate "
      "entities but constituents of a unified whole: spacetime. From the "
      "axiom of light-speed constancy, the conclusion of time dilation "
      "follows: a moving clock ticks slower. The ontological hierarchy is "
      "revolutionary: rather than space as one entity and time as another, "
      "both are mereological parts of a four-dimensional whole-part "
      "structure. Each event is a point in this topological manifold, and "
      "the continuity of worldlines through spacetime has a topological "
      "character. The dimension count jumps from 3+1 to a unified 4, "
      "and the topology of light cones partitions spacetime into causally "
      "connected and disconnected regions — a continuity constraint on "
      "physical influence.",
      "Based on Albert Einstein, On the Electrodynamics of Moving Bodies (1905, public domain)",
      ["Ontoloji", "FOL", "Mereoloji", "Topoloji + Holografik"],
      ["Spacetime unification is a mereological fusion with topological consequences"],
      ["spacetime as mereological whole", "axiom-premise-conclusion relativistic chain",
       "topological structure of light cones", "dimensional unification"]),

    # ── hard ──────────────────────────────────────────────────────────────
    t("SCI-H-01", "SCI", "hard",
      "Quantum field theory (QFT) represents the deepest ontological "
      "revolution in physics. In QFT, the fundamental entities are not "
      "particles but fields: entities pervading all of spacetime. A "
      "particle is merely an excitation — a localized constituent — of its "
      "underlying field. The ontological hierarchy is: fields are the "
      "fundamental entities, particles are constituents of field excitations, "
      "and interactions are morphisms between field states. Category theory "
      "provides natural language: the objects of the category are quantum "
      "states, and the arrows (morphisms) are S-matrix elements mapping "
      "initial to final states. A functor from the category of spacetime "
      "regions to the category of Hilbert spaces formalizes the "
      "axiomatic approach. The Bayesian aspect appears in measurement: "
      "the prior probability distribution over field configurations is "
      "updated by each measurement to yield a posterior. The probability "
      "of a detection event is the likelihood computed from the field's "
      "propagator. The holographic principle in its physical form states "
      "that the information content of a volume of space is encoded on "
      "its boundary — a topological insight where the dimension of the "
      "boundary seeds the full interior, with fractal-like information "
      "density at the Planck scale. This continuity between boundary and "
      "bulk defines the holographic character of quantum gravity.",
      "Based on quantum field theory (Dirac, Feynman, Schwinger — physics tradition)",
      ["Ontoloji", "KategoriTeorisi", "Bayes", "Topoloji + Holografik"],
      ["QFT's field ontology parallels category-theoretic structure-preservation"],
      ["field-particle ontological hierarchy", "S-matrix as morphism",
       "functor from spacetime to Hilbert space",
       "holographic boundary-bulk encoding", "Bayesian measurement updating"]),

    t("SCI-H-02", "SCI", "hard",
      "CRISPR-Cas9 gene editing reveals the mereological and game-theoretic "
      "structure of molecular biology. The CRISPR system is a whole whose "
      "constituents include the guide RNA (a part whose telos is target "
      "recognition), the Cas9 protein (a constituent whose telos is DNA "
      "cleavage), and the repair template (a part-whole mediator). The "
      "whole-part engineering proceeds: the guide RNA locates a specific DNA "
      "sequence, Cas9 cuts both strands, and cellular repair machinery fills "
      "the gap. From a game-theoretic perspective, gene editing can be modeled "
      "as a strategic interaction. The researcher is a player choosing a "
      "strategy (guide RNA sequence); Nature is a player whose strategy is "
      "the set of off-target sites. The payoff for a successful on-target "
      "edit is high; the payoff for off-target editing is negative. The Nash "
      "equilibrium occurs when the researcher's strategy minimizes off-target "
      "probability while maximizing on-target efficiency. This is a "
      "mixed-strategy equilibrium where the probability distribution over "
      "guide RNA designs reflects Bayesian prior knowledge about the "
      "likelihood of off-target binding.",
      "Based on CRISPR gene editing (Doudna, Charpentier — contemporary science, public knowledge)",
      ["Mereoloji", "OyunTeorisi", "Bayes"],
      ["CRISPR engineering is a game against Nature with Bayesian strategy optimization"],
      ["guide-Cas9-template mereological system", "telos of molecular constituents",
       "researcher-Nature game with Nash equilibrium",
       "Bayesian prior for off-target probability"]),

    t("SCI-H-03", "SCI", "hard",
      "General relativity's description of gravity as spacetime curvature "
      "exemplifies multiple analytical lenses. Einstein's field equations, "
      "G_μν = 8πT_μν, express a formal relationship: the axiom that matter "
      "tells spacetime how to curve, and spacetime tells matter how to move. "
      "Ontologically, the entities are not forces but geometric properties — "
      "curvature, geodesics, metric tensors — forming a hierarchy where the "
      "metric tensor is the foundational concept. From the premise of general "
      "covariance and the axiom of equivalence, the conclusion of gravitational "
      "time dilation follows. The topological aspects are profound: black "
      "holes alter the topology of spacetime itself, creating regions of "
      "non-trivial dimension. The event horizon is a boundary where "
      "continuity of causal structure breaks down. The holographic principle "
      "(Bekenstein-Hawking) states that black-hole entropy is proportional "
      "to the horizon area — a surface of dimension 2 encoding the "
      "information of the dimension-3 interior, a fractal-like compression "
      "where the boundary seeds the content of the whole. Each seed of "
      "curvature in the field equations generates the full topological "
      "structure of spacetime.",
      "Based on Einstein, General Theory of Relativity (1915, public domain)",
      ["Ontoloji", "FOL", "Topoloji + Holografik"],
      ["GR's geometric ontology and holographic horizon parallel information-theoretic bounds"],
      ["metric-tensor ontological hierarchy", "axiom-premise-conclusion gravitational chain",
       "topological structure of black holes", "holographic boundary encoding"]),
]

# ═══════════════════════════════════════════════════════════════════════════
#  ETH  –  Ethics (public domain: Aristotle, Kant, Mill, Rawls …)
# ═══════════════════════════════════════════════════════════════════════════
ETH = [
    # ── easy ─────────────────────────────────────────────────────────────
    t("ETH-E-01", "ETH", "easy",
      "The Golden Rule — 'treat others as you would wish to be treated' — "
      "appears across cultures as a foundational ethical concept. Its "
      "ontological status is debated: is it an entity in a hierarchy of "
      "moral truths, or a mere convention? If it exists as an objective "
      "concept in the hierarchy of ethics, it functions as an axiom from "
      "which further moral conclusions follow. From the premise 'I wish not "
      "to be harmed,' the conclusion 'I should not harm others' follows by "
      "the formal logic of symmetry. The entities involved — persons, "
      "interests, obligations — form a conceptual hierarchy where the "
      "Golden Rule sits at the apex. This concept has proven remarkably "
      "stable across ontological frameworks: whether grounded in divine "
      "command, social contract, or evolutionary biology, the hierarchy "
      "of ethical entities consistently produces the same foundational rule.",
      "Based on the Golden Rule across ethical traditions (public domain concept)",
      ["Ontoloji", "FOL"],
      ["The Golden Rule's logical symmetry mirrors formal axioms of identity"],
      ["ontological status of moral truths", "axiom-premise-conclusion ethical chain"]),

    t("ETH-E-02", "ETH", "easy",
      "Utilitarianism, as formulated by Bentham and Mill, is an ethical "
      "framework with inherent Bayesian and game-theoretic dimensions. The "
      "principle of utility — maximize the greatest happiness for the "
      "greatest number — requires estimating the probability of outcomes. "
      "A decision-maker assigns a prior probability to each possible "
      "consequence and evaluates the likelihood of happiness or suffering "
      "under each action. The posterior expected utility determines the "
      "optimal choice. In multi-agent scenarios, utilitarian calculation "
      "becomes a game: each player chooses a strategy to maximize collective "
      "payoff. The Nash equilibrium occurs when no player can improve total "
      "utility by changing their strategy unilaterally. The probability of "
      "cooperation versus defection depends on the payoff structure: when "
      "the payoff for mutual cooperation exceeds the equilibrium payoff of "
      "mutual defection, utilitarian ethics recommends cooperation as the "
      "rational strategy.",
      "Based on J. S. Mill, Utilitarianism (1863, public domain)",
      ["Bayes", "OyunTeorisi"],
      ["Utilitarian calculus is isomorphic to Bayesian expected-utility maximization"],
      ["prior-probability-based utility estimation", "Nash equilibrium of cooperation",
       "payoff structure determines optimal strategy"]),

    t("ETH-E-03", "ETH", "easy",
      "Aristotelian virtue ethics presents a mereological account of the "
      "good life. The virtuous person is a whole composed of constituent "
      "virtues — courage, temperance, justice, wisdom — each a part whose "
      "telos is human flourishing (eudaimonia). The whole-part structure is "
      "essential: no single virtue suffices; only the whole constellation "
      "of constituent virtues achieves the telos of happiness. Each virtue "
      "is itself a mean between extremes: courage is the part-whole balance "
      "between cowardice and rashness. The ontological hierarchy of virtues "
      "places practical wisdom (phronesis) at the top: it is the entity "
      "that discerns the right balance among constituent virtues. The "
      "concept of eudaimonia is not a feeling but an ontological state — "
      "the proper functioning of all mereological parts of the human soul. "
      "The telos of each constituent character trait is its contribution "
      "to the whole of a well-lived life.",
      "Based on Aristotle, Nicomachean Ethics (c. 340 BCE, public domain)",
      ["Mereoloji", "Ontoloji"],
      ["Aristotelian virtue structure parallels modular system design"],
      ["virtue-as-constituent mereology", "telos of eudaimonia",
       "ontological hierarchy of virtues"]),

    # ── medium ───────────────────────────────────────────────────────────
    t("ETH-M-01", "ETH", "medium",
      "Kant's categorical imperative is a formal-logical rule for moral "
      "reasoning. The first formulation — 'Act only according to that maxim "
      "by which you can at the same time will that it should become a "
      "universal law' — functions as an axiom of ethics. From this axiom, "
      "the conclusion follows that lying is impermissible: if everyone lied, "
      "the concept of truth (and thus lying itself) would collapse, a "
      "contradiction. The formal logic is: premise — 'Lying is universalizable'; "
      "derive — 'All persons lie'; conclude — 'Trust is destroyed, contradicting "
      "the premise.' The conclusion: lying cannot be universalized. This "
      "procedure repeats for any proposed maxim, each time deriving from the "
      "axiom of universalizability a conclusion about permissibility. "
      "Ontologically, the categorical imperative places moral law in the "
      "highest position in the hierarchy of practical entities: it is a "
      "concept that applies to all rational entities regardless of their "
      "desires. The hierarchy of ethical concepts — duty, obligation, "
      "permissibility — is derived from this single axiom via formal logic.",
      "Based on Immanuel Kant, Groundwork of the Metaphysics of Morals (1785, public domain)",
      ["FOL", "Ontoloji"],
      ["Kantian universalizability is a logical consistency test akin to formal proof by contradiction"],
      ["axiom of universalizability", "premise-contradiction-conclusion structure",
       "ontological hierarchy of duty"]),

    t("ETH-M-02", "ETH", "medium",
      "Rawls' veil of ignorance introduces game-theoretic reasoning into "
      "justice theory. Behind the veil, each player must choose principles "
      "of justice without knowing their position in society. This is a game "
      "of incomplete information where each player's strategy must account "
      "for the probability of occupying any social position. The Nash "
      "equilibrium of this game, Rawls argues, is the 'maximin' principle: "
      "each player rationally chooses the strategy that maximizes the payoff "
      "of the worst-off position. The Bayesian reasoning is: given a "
      "uniform prior probability over social positions (each equally "
      "likely), the posterior expected utility of a principle depends on "
      "the likelihood of each outcome. The payoff of the maximin strategy "
      "exceeds that of utilitarian averaging when players are risk-averse. "
      "The equilibrium principles — equal basic liberties and the difference "
      "principle — emerge as the rational strategy for any player behind the "
      "veil. The probability distribution over positions, combined with the "
      "posterior assessment of each principle's consequences, yields the "
      "Rawlsian conclusion.",
      "Based on John Rawls, A Theory of Justice (1971, political philosophy tradition)",
      ["OyunTeorisi", "Bayes"],
      ["Rawls' original position is structurally a game of incomplete information"],
      ["veil-of-ignorance game setup", "maximin Nash equilibrium",
       "Bayesian uniform prior over social positions"]),

    t("ETH-M-03", "ETH", "medium",
      "Bioethics confronts the mereological and ontological question of "
      "personhood. When does a developing embryo become a person — an entity "
      "with moral status? The whole-part analysis reveals the challenge: at "
      "each stage of development, new constituent parts are added — neural "
      "tissue, organ systems, consciousness — each part contributing to the "
      "emerging whole. The telos of development is a fully formed person, "
      "but at which point does the collection of constituent parts achieve "
      "the whole-part unity of personhood? The ontological hierarchy offers "
      "competing frameworks. The genetic view: the entity is a person from "
      "conception, when the DNA hierarchy is complete. The neurological view: "
      "personhood requires brain activity, a particular constituent reaching "
      "its telos. The viability view: the whole-part system must be capable "
      "of independent existence. Each concept of personhood defines a "
      "different threshold in the mereological hierarchy where constituents "
      "coalesce into a whole with moral standing. The part-whole analysis "
      "does not resolve the debate but clarifies the ontological commitments "
      "of each position.",
      "Based on bioethics literature on personhood (philosophical tradition)",
      ["Mereoloji", "Ontoloji"],
      ["Bioethical personhood debate is a mereological threshold problem"],
      ["developmental whole-part emergence", "telos of constituent formation",
       "ontological threshold of personhood"]),

    # ── hard ──────────────────────────────────────────────────────────────
    t("ETH-H-01", "ETH", "hard",
      "Meta-ethics investigates the ontological status of moral claims. "
      "Moral realism holds that ethical propositions are entities in an "
      "objective hierarchy: 'murder is wrong' describes a fact whose "
      "ontological standing is as real as any physical entity. The "
      "concept of moral truth creates a hierarchy parallel to mathematical "
      "truth. From the premise of moral realism and the axiom that rational "
      "agents can access moral truths, the conclusion follows that ethical "
      "disagreement is a failure of reasoning rather than a difference of "
      "taste. Non-cognitivism denies this: moral utterances are not entities "
      "in a concept hierarchy but expressions of attitude. The formal logic "
      "of the Frege-Geach problem challenges non-cognitivism: if 'stealing "
      "is wrong' expresses an attitude, how do we parse 'if stealing is "
      "wrong, then helping steal is wrong' — a conditional whose premise "
      "and conclusion seem to require truth-values? The axiom that conditionals "
      "work in formal logic only with truth-apt components threatens the "
      "non-cognitivist program. This debate positions concepts of moral "
      "truth in an ontological hierarchy where their entity-status itself "
      "is the central question.",
      "Based on meta-ethics debate: Moore, Mackie, Blackburn (philosophical tradition)",
      ["Ontoloji", "FOL"],
      ["The Frege-Geach problem reveals formal-logical constraints on moral ontology"],
      ["ontological hierarchy of moral truths", "Frege-Geach formal logic challenge",
       "axiom-premise-conclusion in meta-ethical argument"]),

    t("ETH-H-02", "ETH", "hard",
      "The ethics of artificial intelligence introduces novel game-theoretic "
      "and ontological challenges. Consider an autonomous vehicle facing a "
      "trolley-like dilemma: the AI player must choose a strategy — swerve "
      "left (hitting one pedestrian) or stay straight (hitting three). The "
      "payoff matrix assigns negative values to each outcome, and the "
      "equilibrium strategy depends on how we define the AI's utility "
      "function. From a Bayesian perspective, the AI has a prior probability "
      "distribution over possible scenarios (likelihood of pedestrians' "
      "positions, speeds) and must compute the posterior expected payoff of "
      "each strategy. The Nash equilibrium may differ from the utilitarian "
      "optimum if the AI is programmed with deontological constraints (never "
      "actively kill). The game-theoretic analysis extends to the designers: "
      "each company is a player whose strategy (programming choice) affects "
      "market equilibrium. The probability that a competitor adopts "
      "utilitarian programming creates a strategic interaction where the "
      "Nash equilibrium for the industry may not coincide with the social "
      "optimum. The ontological question — is the AI a moral entity in the "
      "hierarchy of moral agents? — depends on whether it possesses the "
      "concept of responsibility, an entity required for moral agency.",
      "Based on AI ethics literature (Wallach, Allen, Bostrom — contemporary ethical debate)",
      ["OyunTeorisi", "Bayes", "Ontoloji"],
      ["AI trolley problem is a multi-level game with Bayesian uncertainty"],
      ["AI payoff matrix", "Nash equilibrium of programming strategies",
       "Bayesian prior over pedestrian scenarios",
       "ontological status of AI moral agency"]),

    t("ETH-H-03", "ETH", "hard",
      "Levinas' ethics of the Other represents a radical departure from "
      "ontological ethics. For Levinas, the face of the Other is not an "
      "entity in a concept hierarchy but an irruption that shatters every "
      "hierarchy. The ontological tradition, from Plato to Heidegger, seeks "
      "to subsume the Other under a concept — to place every entity in its "
      "proper hierarchical position. Levinas reverses this: ethics precedes "
      "ontology. The face is the foundational entity that commands "
      "'Thou shalt not kill' before any ontological hierarchy is "
      "constructed. From a mereological perspective, the encounter with "
      "the Other reveals that the self is not a self-sufficient whole but "
      "a constituent in a part-whole relationship of responsibility. The "
      "telos of the self is not self-realization but service to the Other. "
      "This challenges the mereological hierarchy: the whole-part structure "
      "of ethics is inverted, as the part (the Other's call) defines the "
      "whole (moral existence). The continuity of ethical demand — from "
      "face-to-face encounter to global justice — exhibits a topological "
      "character: there are no gaps in the dimension of moral obligation. "
      "The seed of infinite responsibility in each singular face has a "
      "holographic quality: each encounter contains the whole of ethics "
      "in fractal miniature.",
      "Based on Emmanuel Levinas, Totality and Infinity (1961, philosophical tradition)",
      ["Ontoloji", "Mereoloji", "Topoloji + Holografik"],
      ["Levinas inverts mereological hierarchy: the part (Other) defines the whole (ethics)"],
      ["face-as-foundational entity", "inverted mereological ethics",
       "topological continuity of obligation",
       "holographic face containing the whole of ethics"]),
]

# ═══════════════════════════════════════════════════════════════════════════
#  LOGIC  –  Formal Logic (public domain: Aristotle, Frege, Gödel …)
# ═══════════════════════════════════════════════════════════════════════════
LOGIC = [
    # ── easy ─────────────────────────────────────────────────────────────
    t("LOGIC-E-01", "LOGIC", "easy",
      "Propositional logic is the foundation of formal logic. A proposition "
      "is an entity that is either true or false. The basic connectives — "
      "AND (∧), OR (∨), NOT (¬), IMPLIES (→), and BICONDITIONAL (↔) — "
      "form a hierarchy of logical operations. The axiom of bivalence "
      "states that every proposition has exactly one truth value. From any "
      "set of premises, we derive conclusions using rules like modus ponens: "
      "if P → Q is a premise and P is a premise, the conclusion Q follows. "
      "The concept of tautology — a formula true under all interpretations — "
      "sits at the top of the hierarchy of logical truths. The ontological "
      "status of logical entities (propositions, connectives, truth values) "
      "is debated: are they abstract entities in a Platonic hierarchy, or "
      "merely linguistic conventions? Regardless, the formal logic of "
      "propositions provides the foundational axiom system for all "
      "deductive reasoning.",
      "Based on propositional logic (Chrysippus, Boole, Frege — public domain tradition)",
      ["FOL", "Ontoloji"],
      ["Propositional logic is the base layer of the formal-logical hierarchy"],
      ["modus ponens as fundamental rule", "axiom of bivalence",
       "ontological status of logical entities"]),

    t("LOGIC-E-02", "LOGIC", "easy",
      "Logical fallacies are errors in formal logic where the conclusion "
      "does not follow from the premises. The fallacy of affirming the "
      "consequent illustrates: from the premise P → Q and the premise Q, "
      "one might incorrectly conclude P. The formal logic shows why: "
      "P → Q does not entail Q → P. Without the axiom of converse, the "
      "conclusion is invalid. Ad hominem attacks the arguer rather than the "
      "axiom; straw man misrepresents the premise; circular reasoning makes "
      "the conclusion identical to the premise. Each fallacy can be "
      "understood as a violation of a specific formal-logical rule. The "
      "ontological concept of 'valid argument' sits in a hierarchy above "
      "'sound argument': validity concerns form (the conclusion follows "
      "from premises), while soundness adds the requirement that premises "
      "are true entities. This hierarchy of logical concepts — from fallacy "
      "to valid form to sound argument — structures the teaching of "
      "formal logic and critical reasoning.",
      "Based on classical logic and informal fallacy taxonomy (Aristotle, public domain)",
      ["FOL", "Ontoloji"],
      ["Fallacy taxonomy is an ontological classification of logical errors"],
      ["premise-conclusion invalidity patterns", "formal-logical rule violations",
       "validity-soundness hierarchy"]),

    t("LOGIC-E-03", "LOGIC", "easy",
      "Modus ponens and modus tollens are the two fundamental inference "
      "rules of formal logic. Modus ponens: given the premise P → Q "
      "and the premise P, the conclusion Q follows. Modus tollens: given "
      "the premise P → Q and the premise ¬Q, the conclusion ¬P follows. "
      "Both are axioms of classical logic — they cannot be proven from "
      "simpler rules but serve as the foundation from which other "
      "conclusions are derived. The formal logic of these rules connects "
      "to the ontological hierarchy of deductive systems: propositional "
      "logic is the foundational entity, predicate logic extends it with "
      "quantifiers (∀ and ∃), and modal logic adds necessity and "
      "possibility. Each level of this hierarchy builds on the axioms "
      "of the lower level. The concept of a 'proof' — a finite sequence "
      "of premises and conclusions connected by inference rules — is the "
      "central entity of formal logic. Every conclusion in the hierarchy "
      "of mathematical truth traces back to axioms via such proof chains.",
      "Based on inference rules in classical logic (Aristotle, Frege — public domain)",
      ["FOL", "Ontoloji"],
      ["Inference rules form the ontological bedrock of all deductive reasoning"],
      ["modus ponens/tollens as foundational axioms",
       "propositional-predicate-modal logic hierarchy",
       "proof as chain of premises and conclusions"]),

    # ── medium ───────────────────────────────────────────────────────────
    t("LOGIC-M-01", "LOGIC", "medium",
      "Predicate logic (first-order logic) extends propositional logic with "
      "quantifiers that express generalizations. The universal quantifier ∀ "
      "('for all') and existential quantifier ∃ ('there exists') transform "
      "the expressive power of formal logic. The axiom schema ∀x P(x) → P(a) "
      "(universal instantiation) allows deriving specific conclusions from "
      "general premises. Consider the formal argument: premise (1) '∀x (Human(x) "
      "→ Mortal(x))'; premise (2) 'Human(Socrates)'; conclusion 'Mortal(Socrates).' "
      "This is formal logic at its purest: from axiom-like premises, specific "
      "conclusions follow via quantifier rules. The ontological import is "
      "significant: predicate logic commits us to a domain of entities — the "
      "things our variables range over. The concept of an 'interpretation' "
      "assigns entities to variables and truth-values to predicates, creating "
      "a hierarchy of possible models. A formula is valid if true under every "
      "interpretation — an axiom of formal logic that sits atop the hierarchy "
      "of logical truths.",
      "Based on first-order predicate logic (Frege, Russell, Tarski — logical tradition)",
      ["FOL", "Ontoloji"],
      ["Predicate logic's ontological commitments parallel set-theoretic foundations"],
      ["∀ and ∃ quantifier rules", "universal instantiation axiom",
       "model-theoretic hierarchy of interpretations"]),

    t("LOGIC-M-02", "LOGIC", "medium",
      "Natural deduction, developed by Gentzen, is a proof system where each "
      "connective has introduction and elimination rules. The axioms are "
      "replaced by assumptions: to prove P → Q in formal logic, assume P as "
      "a premise and derive Q as a conclusion. The → introduction rule "
      "discharges the assumption, yielding P → Q. The ∀ introduction rule "
      "requires proving P(x) for an arbitrary entity x, concluding ∀x P(x). "
      "This system reveals the ontological structure of formal logic itself: "
      "each connective is defined by its rules, and the hierarchy of proofs "
      "corresponds to a hierarchy of logical concepts. From a category-"
      "theoretic perspective, natural deduction proofs are morphisms in a "
      "category where the objects are propositions and the arrows are "
      "derivations. The composition of two morphisms (proofs) yields a "
      "combined proof. The identity arrow is the trivial proof from P to P. "
      "A functor from the category of proofs to the category of types "
      "(the Curry-Howard correspondence) reveals that proofs are programs "
      "and propositions are types — a profound morphism between logic "
      "and computation, each object in one domain mapping to an object in "
      "the other via a structure-preserving arrow.",
      "Based on Gentzen's natural deduction and Curry-Howard correspondence (logical tradition)",
      ["FOL", "KategoriTeorisi"],
      ["Curry-Howard is a functor between the category of proofs and the category of types"],
      ["introduction/elimination rule pairs", "proofs as morphisms",
       "Curry-Howard functor between propositions and types"]),

    t("LOGIC-M-03", "LOGIC", "medium",
      "Modal logic extends formal logic with operators for necessity (□) and "
      "possibility (◇). The axiom K — □(P → Q) → (□P → □Q) — distributes "
      "necessity over implication. Different modal systems add further axioms: "
      "S4 adds □P → □□P (positive introspection); S5 adds ◇P → □◇P ("
      "negative introspection). The premise of possible-worlds semantics "
      "(Kripke) is that each possible world is an entity in an ontological "
      "hierarchy of realities, connected by accessibility relations. The "
      "conclusion: □P means P holds in all accessible worlds; ◇P means P "
      "holds in some accessible world. The topology of possible worlds "
      "exhibits continuity properties: the accessibility relation defines "
      "a topological neighborhood structure where 'nearby' worlds share "
      "properties. The dimension of modal space depends on how many "
      "independent parameters vary across worlds — one dimension for "
      "temporal variation, another for deontic (moral) variation. This "
      "topological reading of modal logic reveals a holographic pattern: "
      "each world is a seed that, through its accessibility relations, "
      "encodes information about the whole modal space.",
      "Based on modal logic (Lewis, Kripke, public domain logical tradition)",
      ["FOL", "Ontoloji", "Topoloji + Holografik"],
      ["Kripke possible-worlds semantics gives modal logic a topological neighborhood structure"],
      ["necessity/possibility axioms", "Kripke accessibility topology",
       "dimensional modal space", "holographic world-network encoding"]),

    # ── hard ──────────────────────────────────────────────────────────────
    t("LOGIC-H-01", "LOGIC", "hard",
      "Gödel's Completeness Theorem for first-order logic states that every "
      "logically valid formula has a proof — a reassuring conclusion that "
      "semantic and syntactic truth coincide. The formal logic of the proof "
      "is intricate: from the axiom of compactness (if every finite subset "
      "of premises is satisfiable, the whole set is), the conclusion follows "
      "that any unprovable formula has a counter-model. The ontological "
      "implication is deep: the hierarchy of first-order truths is exactly "
      "captured by the hierarchy of formal proofs. Every entity in the "
      "semantic concept space (valid formulas) corresponds to an entity in "
      "the syntactic concept space (provable formulas). From a category-"
      "theoretic perspective, the Completeness Theorem establishes a "
      "functor between the category of models (objects: structures; "
      "morphisms: elementary embeddings) and the category of theories "
      "(objects: consistent axiom sets; arrows: interpretations). This "
      "functor is an equivalence: the morphisms preserve structure in "
      "both directions. The Completeness Theorem is thus a categorical "
      "isomorphism — every arrow in the model category has a corresponding "
      "arrow in the theory category, each object faithfully mapped.",
      "Based on Kurt Gödel, Completeness of First-Order Logic (1929, public domain)",
      ["FOL", "KategoriTeorisi", "Ontoloji"],
      ["Gödel Completeness as category-theoretic equivalence between semantic and syntactic categories"],
      ["completeness = semantic-syntactic correspondence",
       "compactness axiom to counter-model conclusion",
       "functor between model and theory categories", "categorical isomorphism"]),

    t("LOGIC-H-02", "LOGIC", "hard",
      "Intuitionistic logic rejects the law of excluded middle (P ∨ ¬P) as "
      "an axiom, requiring constructive proofs. In formal logic, this means "
      "a proof of ∃x P(x) must exhibit a specific entity x — not merely "
      "derive a contradiction from ∀x ¬P(x). The premise of constructivism "
      "is that mathematical entities exist only when constructed; the "
      "conclusion is that the classical conclusion of proof by contradiction "
      "is not always valid. The ontological hierarchy shifts: entities are "
      "not pre-existing objects in a Platonic hierarchy but constructions "
      "that come into being through proof. From a topological perspective, "
      "intuitionistic logic has a natural model: topological spaces where "
      "open sets represent propositions. Conjunction corresponds to "
      "intersection, disjunction to union, and ¬P to the interior of the "
      "complement. The dimension of this topological semantics captures the "
      "continuity of constructive reasoning. Heyting algebras formalize "
      "this: each concept is an open set, and the hierarchy of open sets "
      "models the hierarchy of intuitionistic truths. The holographic "
      "aspect emerges: each open neighborhood seeds the provability of "
      "local truths, and the fractal structure of nested open sets mirrors "
      "the nested structure of constructive proofs.",
      "Based on Brouwer's intuitionism and Heyting algebras (logical tradition)",
      ["FOL", "Ontoloji", "Topoloji + Holografik"],
      ["Intuitionistic logic is the internal logic of topological spaces"],
      ["rejection of excluded middle", "constructive existence proofs",
       "topological open-set semantics", "holographic nested provability"]),

    t("LOGIC-H-03", "LOGIC", "hard",
      "Paraconsistent logic challenges the classical axiom 'ex contradictione "
      "quodlibet' — from a contradiction, anything follows. In paraconsistent "
      "formal logic, a premise P and its negation ¬P can both hold without "
      "the conclusion being every proposition. This is achieved by modifying "
      "the axiom of explosion: contradictions are 'contained' rather than "
      "propagated. The ontological implications are profound: if contradictory "
      "entities can coexist in the hierarchy of truths, the concept of "
      "consistency itself requires redefinition. From a game-theoretic "
      "perspective, paraconsistent reasoning models strategic interactions "
      "where players hold contradictory beliefs. Each player's strategy "
      "may be based on inconsistent information; the equilibrium of the "
      "game is reached not by eliminating contradictions but by containing "
      "them. The payoff of tolerating local contradiction may exceed the "
      "payoff of global revision — a Nash equilibrium of belief management. "
      "The Bayesian dimension: given contradictory evidence (probability "
      "assignments that sum to more than 1), the prior must be modified. "
      "The likelihood of contradictory data under different hypotheses "
      "yields a posterior that navigates between conflicting premises, "
      "producing a nuanced conclusion rather than logical collapse.",
      "Based on paraconsistent logic (da Costa, Priest — contemporary logical tradition)",
      ["FOL", "OyunTeorisi", "Bayes", "Ontoloji"],
      ["Paraconsistent contradiction tolerance has game-theoretic equilibrium structure"],
      ["modified explosion axiom", "ontological coexistence of contradictions",
       "Nash equilibrium of inconsistent beliefs",
       "Bayesian navigation of contradictory evidence"]),
]


# ═══════════════════════════════════════════════════════════════════════════
#  Assemble & Validate
# ═══════════════════════════════════════════════════════════════════════════
def build() -> dict:
    corpus = {"version": "1.0", "texts": THEO + PHIL + MATH + SCI + ETH + LOGIC}
    return corpus


def validate(corpus: dict) -> list[str]:
    """Return a list of validation errors (empty = OK)."""
    import jsonschema
    schema = json.loads((HERE / "schema.json").read_text(encoding="utf-8"))
    errors: list[str] = []
    try:
        jsonschema.validate(corpus, schema)
    except jsonschema.ValidationError as e:
        errors.append(f"Schema: {e.message}")

    # Check count
    n = len(corpus["texts"])
    if n != 54:
        errors.append(f"Expected 54 texts, got {n}")

    # Check unique IDs
    ids = [t["id"] for t in corpus["texts"]]
    dupes = [i for i in ids if ids.count(i) > 1]
    if dupes:
        errors.append(f"Duplicate IDs: {set(dupes)}")

    # Check text lengths
    for entry in corpus["texts"]:
        tlen = len(entry["text"])
        if tlen < 100 or tlen > 5000:
            errors.append(f"{entry['id']}: text length {tlen} outside [100, 5000]")

    # Check keyword coverage
    from evaluation.judges.layer1_programmatic import LENS_GROUPS
    for entry in corpus["texts"]:
        text_lower = entry["text"].lower()
        for lens in entry["ground_truth"]["expected_lenses"]:
            if lens in LENS_GROUPS:
                hits = sum(1 for kw in LENS_GROUPS[lens] if kw.lower() in text_lower)
                if hits < 2:
                    errors.append(
                        f"{entry['id']}: expected lens '{lens}' has only {hits} keyword hits in text"
                    )

    return errors


def main() -> None:
    corpus = build()
    errors = validate(corpus)

    if errors:
        print("❌ Validation errors:")
        for e in errors:
            print(f"  • {e}")
        sys.exit(1)

    out = HERE / "texts.json"
    out.write_text(json.dumps(corpus, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"✅ Wrote {len(corpus['texts'])} texts to {out}")
    print("   All validations passed.")


if __name__ == "__main__":
    main()
