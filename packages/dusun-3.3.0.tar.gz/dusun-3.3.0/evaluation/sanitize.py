"""Output sanitisation — strip condition-identifying artifacts before judging."""

from __future__ import annotations

import re


def sanitize_for_judge(output: str, condition_id: str) -> str:  # noqa: ARG001
    """Strip MCP-specific markers that would reveal the condition to the judge."""
    mcp_artifacts = [
        r'"_framework_context":\s*\{[^}]*\}',
        r'"ax57_compact":\s*"[^"]*"',
        r'"boot_seed":\s*"[^"]*"',
        r'"kavaid":\s*\{[^}]*\}',
        r"\bAX\d+\b",
        r"\bKV[₁-₈]\b",
        r"\bBS-\d+\b",
        r"\bT\d{1,2}\b(?=\s|[,.])",
    ]
    sanitized = output
    for pattern in mcp_artifacts:
        sanitized = re.sub(pattern, "", sanitized)

    # TWOSTEP echo-stripping: remove phrases that leak "prior step" existence
    if condition_id == "TWOSTEP":
        echo_patterns = [
            r"(?i)\b(?:preliminary|prior|pre-?)[\s-]?analysis\s+"
            r"(?:found|identified|noted|detected|revealed|showed|indicated)\b",
            r"(?i)\ba prior analysis\b",
            r"(?i)\bpre-analysis\s+(?:findings|results|notes)\b",
            r"(?i)\b(?:the )?preliminary (?:analysis )?findings?\b",
            r"(?i)\bas (?:noted|identified|found) (?:in|by) the (?:preliminary|prior) analysis\b",
        ]
        for pattern in echo_patterns:
            sanitized = re.sub(pattern, "", sanitized)

    sanitized = re.sub(r"\n{3,}", "\n\n", sanitized)
    return sanitized.strip()
