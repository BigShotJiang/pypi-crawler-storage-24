"""Core get/push logic."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Callable, List, Optional

import tlc_shared_docs.config as cfg
import tlc_shared_docs.git_ops as git_ops

logger = logging.getLogger(__name__)


def _resolve_config(
    root: Path,
    conf: cfg.SharedConfig,
    central_url: Optional[str] = None,
    _detect_identity: Callable[[Path], str] = cfg.detect_repo_identity,
    _fetch_file: Callable[..., bytes | None] = git_ops.fetch_single_file,
) -> tuple[cfg.SharedConfig, List[str]]:
    """If *conf* is in central mode, fetch the config from the source repo.

    Returns ``(resolved_config, messages)``.
    """
    messages: List[str] = []

    # CLI --central flag overrides the mode field in shared.json
    source_url = central_url or (conf.source_repo.url if conf.mode == "central" else None)
    if not source_url:
        return conf, messages

    # Detect this repo's org/repo identity from git remote
    org_repo = _detect_identity(root)
    config_path = cfg.central_config_path(org_repo)

    # Build source repo settings, allowing CLI override of URL
    source = cfg.SourceRepo(
        url=source_url,
        branch=conf.source_repo.branch if conf.source_repo.url == source_url else "main",
    )
    if central_url:
        source = cfg.SourceRepo(url=central_url, branch=conf.source_repo.branch)

    messages.append(f"Central mode: looking up {config_path} from {source.url}")

    # Fetch the central config file from the shared docs repo
    content = _fetch_file(source.url, source.branch, config_path)
    if content is None:
        raise FileNotFoundError(
            f"Central config not found: {config_path} in {source.url} ({source.branch})"
        )

    central_data = json.loads(content.decode("utf-8"))
    central_files = cfg.parse_shared_files(central_data)
    central_uploads = cfg.parse_upload_config(central_data)

    # Warn if local config also had shared_files -- central wins
    if conf.shared_files:
        messages.append(
            "WARNING: Local shared.json contains shared_files entries, "
            "but central mode is active. Central config takes precedence."
        )

    return cfg.SharedConfig(
        source_repo=source,
        shared_files=central_files,
        mode="central",
        uploads=central_uploads,
    ), messages


def _expand_get_entries(
    conf: cfg.SharedConfig,
    _list_remote: Callable[..., List[str]] = git_ops.list_remote_files,
) -> tuple[List[cfg.SharedFile], List[str]]:
    """Expand glob entries in the get list into concrete SharedFile objects.

    Returns ``(expanded_files, messages)``.  Messages contain
    warning info for glob resolution.
    """
    plain: List[cfg.SharedFile] = []
    glob_entries: List[cfg.SharedFile] = []
    messages: List[str] = []

    # Separate plain paths from glob patterns
    for sf in conf.shared_files:
        if sf.action != "get":
            continue
        if cfg.is_glob(sf.remote_path):
            glob_entries.append(sf)
        else:
            plain.append(sf)

    # Resolve each glob pattern against the remote tree
    for sf in glob_entries:
        matched = _list_remote(
            conf.source_repo.url,
            conf.source_repo.branch,
            sf.remote_path,
        )
        if not matched:
            messages.append(f"WARNING: No remote files matched pattern: {sf.remote_path}")
            continue

        # Strip the non-glob prefix to preserve relative directory structure
        prefix = cfg.glob_prefix(sf.remote_path)

        for remote_path in matched:
            # Build a local path that preserves directory structure under local_path
            if prefix:
                relative = remote_path[len(prefix):].lstrip("/")
            else:
                relative = remote_path
            local_path = sf.local_path.rstrip("/") + "/" + relative

            plain.append(cfg.SharedFile(
                remote_path=remote_path,
                local_path=local_path,
                action="get",
            ))

        messages.append(
            f"Glob '{sf.remote_path}' matched {len(matched)} file(s)"
        )

    return plain, messages


def _noop_print(msg: str) -> None:
    """No-op print for test injection — messages are still collected."""
    pass


def get_files(
    project_root: Optional[Path] = None,
    dry_run: bool = False,
    central_url: Optional[str] = None,
    project: Optional[str] = None,
    clean: bool = False,
    _get_shas: Callable[..., dict[str, str]] = git_ops.get_remote_blob_shas,
    _sparse_checkout: Callable[..., tuple] = git_ops.sparse_checkout_files,
    _read_clone: Callable[..., bytes] = git_ops.read_file_from_clone,
    _cleanup: Callable[..., None] = git_ops.cleanup,
    _detect_identity: Callable[[Path], str] = cfg.detect_repo_identity,
    _fetch_file: Callable[..., bytes | None] = git_ops.fetch_single_file,
    _list_remote: Callable[..., List[str]] = git_ops.list_remote_files,
    _print: Callable[[str], None] = _noop_print,
) -> List[str]:
    """Pull shared files from the remote repo.

    Returns a list of human-readable status messages.
    *_print* is called immediately for each message (live progress).
    Dependency parameters (prefixed with _) allow test injection.
    """
    def emit(msg: str) -> None:
        messages.append(msg)
        _print(msg)

    root = project_root or cfg.find_project_root()
    cfg.ensure_shared_dir(root)
    conf = cfg.load_config(root, project=project)

    messages: List[str] = []

    # Resolve central mode if applicable
    conf, resolve_msgs = _resolve_config(
        root, conf, central_url,
        _detect_identity=_detect_identity,
        _fetch_file=_fetch_file,
    )
    for m in resolve_msgs:
        emit(m)

    # Central mode replaces shared_files, so re-apply project prefix
    if project and conf.mode == "central":
        conf = cfg._prefix_local_paths(conf, project)

    # Expand any glob patterns into concrete file entries
    emit(f"Fetching file list from {conf.source_repo.url}...")
    files_to_get, expand_msgs = _expand_get_entries(conf, _list_remote=_list_remote)
    for m in expand_msgs:
        emit(m)

    files_needed: List[cfg.SharedFile] = []
    skipped = 0
    updated = 0

    if not files_to_get:
        if not clean:
            if len(messages) <= 1:
                emit("No files with action=get found in shared.json")
            return messages
        # With --clean, continue even with no get entries (to remove stale files)
    else:
        remote_paths = [f.remote_path for f in files_to_get]

        # Query remote blob SHAs to detect unchanged files (cheap, no blobs)
        emit(f"Checking for changes ({len(remote_paths)} file(s))...")
        stored_hashes = cfg.load_hashes(root)
        remote_shas = _get_shas(
            conf.source_repo.url,
            conf.source_repo.branch,
            remote_paths,
        )

        # Filter: only fetch files whose SHA changed or that don't exist locally
        for sf in files_to_get:
            remote_sha = remote_shas.get(sf.remote_path)
            if remote_sha is None:
                files_needed.append(sf)
                continue
            stored_sha = stored_hashes.get(sf.remote_path)
            local = cfg.resolve_local_path(root, sf.local_path)
            if stored_sha == remote_sha and local.exists():
                emit(f"SKIP (unchanged): {sf.remote_path}")
                skipped += 1
            else:
                files_needed.append(sf)

        # Dry-run: show what would be fetched (but don't return yet — clean may follow)
        if dry_run:
            for sf in files_needed:
                emit(f"[dry-run] Would get: {sf.remote_path}")

    if dry_run:
        pass  # skip download in dry-run mode
    elif not files_needed:
        if files_to_get:
            emit("All files up to date.")
    else:
        # Sparse-checkout only the files that actually changed
        emit(f"Downloading {len(files_needed)} changed file(s)...")
        needed_paths = [sf.remote_path for sf in files_needed]
        clone_dir, _repo = _sparse_checkout(
            conf.source_repo.url,
            conf.source_repo.branch,
            needed_paths,
        )

        try:
            for sf in files_needed:
                try:
                    content = _read_clone(clone_dir, sf.remote_path)
                except FileNotFoundError:
                    emit(f"WARNING: Remote file not found: {sf.remote_path}")
                    continue

                # Write the fetched content to the local destination
                local = cfg.resolve_local_path(root, sf.local_path)
                local.parent.mkdir(parents=True, exist_ok=True)
                local.write_bytes(content)
                emit(f"OK: {sf.remote_path} -> {local.relative_to(root)}")
                updated += 1

                # Track the blob SHA so we can skip this file next time
                sha = remote_shas.get(sf.remote_path)
                if sha:
                    stored_hashes[sf.remote_path] = sha
        finally:
            _cleanup(clone_dir)

        # Persist updated hashes for future runs
        cfg.save_hashes(root, stored_hashes)

    # Clean: remove local files not in the current shared_files list
    cleaned = 0
    if clean:
        # Build set of expected local paths from all get entries
        expected_locals: set[Path] = set()
        for sf in files_to_get:
            expected_locals.add(cfg.resolve_local_path(root, sf.local_path))

        # Determine the scan directory (project subdir or shared root)
        sdir = cfg.shared_dir_path(root)
        scan_dir = sdir / project if project else sdir
        internal = {".gitignore", "shared.json", ".shared-hashes.json"}

        if scan_dir.is_dir():
            for local_file in scan_dir.rglob("*"):
                if not local_file.is_file():
                    continue
                rel = local_file.relative_to(sdir).as_posix()
                if rel in internal:
                    continue
                if local_file not in expected_locals:
                    if dry_run:
                        emit(f"[dry-run] Would remove: {local_file.relative_to(root)}")
                    else:
                        local_file.unlink()
                        emit(f"REMOVED: {local_file.relative_to(root)}")
                    cleaned += 1

    # Summary line
    proj_label = f" from {project}" if project else ""
    clean_label = f", {cleaned} removed" if clean else ""
    emit(f"Done: {len(files_to_get)} file(s) shared{proj_label}. {updated} updated, {skipped} unchanged{clean_label}.")

    return messages


def _discover_uploadable_files(
    project_root: Path,
    conf: cfg.SharedConfig,
) -> tuple[List[tuple[Path, str]], List[str]]:
    """Scan the shared directory for files not in ``shared_files``.

    Returns ``(candidates, messages)`` where each candidate is
    ``(local_path, remote_path)`` and messages contain DENIED warnings.

    Only files whose remote path matches an ``uploads.paths`` pattern
    are included; others produce a DENIED warning.
    """
    sdir = cfg.shared_dir_path(project_root)
    messages: List[str] = []

    # Internal files that are never uploaded
    internal = {".gitignore", "shared.json", ".shared-hashes.json"}

    # Collect all known local paths (from shared_files) so we skip them
    known_locals: set[Path] = set()
    for sf in conf.shared_files:
        known_locals.add(cfg.resolve_local_path(project_root, sf.local_path))

    upload_cfg = conf.uploads
    if not upload_cfg or not upload_cfg.allowed:
        return [], messages

    # Walk the shared directory for new files
    candidates: List[tuple[Path, str]] = []
    for local_file in sdir.rglob("*"):
        if not local_file.is_file():
            continue

        # Skip internal config/tracking files
        rel_to_shared = local_file.relative_to(sdir).as_posix()
        if rel_to_shared in internal:
            continue

        # Skip files already managed by shared_files entries
        if local_file in known_locals:
            continue

        # The remote path mirrors the relative path under shared dir
        remote_path = rel_to_shared

        # Check if any upload pattern permits this path
        permitted = any(
            cfg.glob_match(remote_path, pat) for pat in upload_cfg.paths
        )
        if permitted:
            candidates.append((local_file, remote_path))
        else:
            messages.append(f"DENIED: {remote_path} does not match any upload pattern")

    return candidates, messages


def push_files(
    project_root: Optional[Path] = None,
    dry_run: bool = False,
    force: bool = False,
    central_url: Optional[str] = None,
    project: Optional[str] = None,
    verbose: bool = False,
    _sparse_checkout: Callable[..., tuple] = git_ops.sparse_checkout_files,
    _cleanup: Callable[..., None] = git_ops.cleanup,
    _push: Callable[..., None] = git_ops.push_files,
    _detect_identity: Callable[[Path], str] = cfg.detect_repo_identity,
    _fetch_file: Callable[..., bytes | None] = git_ops.fetch_single_file,
    _get_shas: Callable[..., dict[str, str]] = git_ops.get_remote_blob_shas,
    _print: Callable[[str], None] = _noop_print,
) -> List[str]:
    """Push local shared files to the remote repo.

    Returns a list of human-readable status messages.
    *_print* is called immediately for each message (live progress).
    Dependency parameters (prefixed with _) allow test injection.
    """
    def emit(msg: str) -> None:
        messages.append(msg)
        _print(msg)

    root = project_root or cfg.find_project_root()
    conf = cfg.load_config(root, project=project)

    messages: List[str] = []

    # Resolve central mode if applicable
    conf, resolve_msgs = _resolve_config(
        root, conf, central_url,
        _detect_identity=_detect_identity,
        _fetch_file=_fetch_file,
    )
    for m in resolve_msgs:
        emit(m)

    # Central mode replaces shared_files, so re-apply project prefix
    if project and conf.mode == "central":
        conf = cfg._prefix_local_paths(conf, project)

    files_to_push = [f for f in conf.shared_files if f.action == "push"]

    if verbose:
        emit(f"[verbose] Project root: {root}")
        emit(f"[verbose] Source repo: {conf.source_repo.url} ({conf.source_repo.branch})")
        emit(f"[verbose] Mode: {conf.mode}")
        emit(f"[verbose] Push entries in config: {len(files_to_push)}")
        for sf in files_to_push:
            emit(f"[verbose]   remote_path={sf.remote_path}  local_path={sf.local_path}")

    # Discover new files eligible for upload (central mode only)
    upload_candidates, upload_msgs = _discover_uploadable_files(root, conf)
    for m in upload_msgs:
        emit(m)

    if not files_to_push and not upload_candidates:
        emit("No files with action=push found in shared.json")
        return messages

    if dry_run:
        for f in files_to_push:
            emit(f"[dry-run] Would push: {f.local_path} -> {f.remote_path}")
        for _, remote_path in upload_candidates:
            emit(f"[dry-run] Would upload: {remote_path}")
        return messages

    # Build the file map: remote_path -> local file bytes
    file_map: dict[str, bytes] = {}

    for sf in files_to_push:
        local = cfg.resolve_local_path(root, sf.local_path)
        if not local.exists():
            emit(f"WARNING: Local file not found, skipping: {local}")
            continue
        content = local.read_bytes()
        file_map[sf.remote_path] = content
        if verbose:
            emit(f"[verbose] Read {len(content)} bytes from {local}")

    # Add upload candidates to the file map
    for local_file, remote_path in upload_candidates:
        file_map[remote_path] = local_file.read_bytes()

    if not file_map:
        emit("No files to push (all missing locally).")
        return messages

    # Conflict check: verify no one else changed the remote since our last get.
    # Compare remote blob SHAs against stored hashes — if the remote SHA
    # differs from what we last pulled, someone else modified the file.
    if not force:
        emit("Checking for conflicts...")
        stored_hashes = cfg.load_hashes(root)
        try:
            remote_shas = _get_shas(
                conf.source_repo.url,
                conf.source_repo.branch,
                list(file_map.keys()),
            )
            for remote_path in file_map:
                remote_sha = remote_shas.get(remote_path)
                stored_sha = stored_hashes.get(remote_path)
                # New file (not on remote yet) — no conflict possible
                if remote_sha is None:
                    continue
                # File exists on remote but we never pulled it — conflict
                if stored_sha is None:
                    emit(
                        f"CONFLICT: {remote_path} exists on remote but was never "
                        f"pulled. Use --force to overwrite."
                    )
                    continue
                # Remote changed since our last pull — conflict
                if remote_sha != stored_sha:
                    emit(
                        f"CONFLICT: {remote_path} was modified on remote since "
                        f"last pull. Use --force to overwrite."
                    )
            if any("CONFLICT" in m for m in messages):
                emit("Push aborted due to conflicts. Use --force to overwrite.")
                return messages
        except git_ops.GitError as exc:
            logger.warning("Could not check remote for conflicts: %s", exc)

    # Build the commit message from the local repo identity
    repo_name = _repo_name_from_root(root)
    branch_name = _current_branch(root)
    commit_msg = f"Updated by {repo_name} on {branch_name}"

    emit(f"Pushing {len(file_map)} file(s) to {conf.source_repo.url}...")
    if verbose:
        emit(f"[verbose] Commit message: {commit_msg}")
        emit(f"[verbose] Force: {force}")
        for rp, content in file_map.items():
            emit(f"[verbose] file_map[{rp}] = {len(content)} bytes")

    actually_pushed = _push(
        url=conf.source_repo.url,
        branch=conf.source_repo.branch,
        file_map=file_map,
        commit_message=commit_msg,
        force=force,
        verbose=verbose,
        _print=_print,
    )

    if not actually_pushed:
        emit("No changes detected — all files already match remote. Nothing pushed.")
    else:
        for remote_path in actually_pushed:
            emit(f"OK: pushed {remote_path}")
        skipped_count = len(file_map) - len(actually_pushed)
        if skipped_count:
            emit(f"SKIP (unchanged): {skipped_count} file(s) already match remote")

    # Summary line
    proj_label = f" to {project}" if project else ""
    emit(f"Done: {len(actually_pushed)} of {len(file_map)} file(s) pushed{proj_label}.")

    return messages


def _repo_name_from_root(root: Path) -> str:
    """Best-effort repo name from the project root directory name."""
    return root.name


def _current_branch(root: Path) -> str:
    """Best-effort current branch name of the local repo."""
    try:
        from git import Repo
        repo = Repo(root)
        return str(repo.active_branch)
    except Exception as exc:
        logger.warning("Could not detect current branch: %s", exc)
        return "unknown"
