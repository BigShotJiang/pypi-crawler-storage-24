"""Vocabulary coverage tracker for training telemetry.

Tracks unique tokens seen during training to measure vocabulary coverage.
Persists to checkpoint for resumption.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import torch


class VocabTracker:
    """Track vocabulary coverage during training.

    Maintains a set of unique token IDs seen during training and reports
    coverage as a percentage of the total vocabulary size.

    Usage:
        tracker = VocabTracker(vocab_size=50000)

        # During training step
        tracker.update(input_ids)

        # Check coverage
        print(f"Coverage: {tracker.coverage:.1%}")
        print(f"Unique tokens: {tracker.unique_count:,} / {tracker.vocab_size:,}")

        # Save/load for checkpointing
        state = tracker.get_state_dict()
        tracker.load_state_dict(state)
    """

    def __init__(self, vocab_size: int = 50000):
        """Initialize vocab tracker.

        Args:
            vocab_size: Total vocabulary size (default 50000 for coordizer v2)
        """
        self.vocab_size = vocab_size
        self.unique_tokens: set[int] = set()
        self.total_tokens: int = 0

    def update(self, token_ids: torch.Tensor | list[int]) -> None:
        """Update with new tokens from training batch.

        Args:
            token_ids: Tensor or list of token IDs
        """
        # Handle torch tensor
        if hasattr(token_ids, "flatten"):
            tokens = token_ids.flatten().tolist()
        elif hasattr(token_ids, "__iter__"):
            # Handle nested lists
            tokens = []
            for item in token_ids:
                if hasattr(item, "__iter__") and not isinstance(item, (str, bytes)):
                    tokens.extend(item)
                else:
                    tokens.append(item)
        else:
            tokens = [token_ids]

        self.unique_tokens.update(tokens)
        self.total_tokens += len(tokens)

    @property
    def unique_count(self) -> int:
        """Number of unique tokens seen."""
        return len(self.unique_tokens)

    @property
    def coverage(self) -> float:
        """Vocabulary coverage as fraction (0-1)."""
        return len(self.unique_tokens) / self.vocab_size

    @property
    def coverage_pct(self) -> float:
        """Vocabulary coverage as percentage (0-100)."""
        return self.coverage * 100

    def get_state_dict(self) -> dict[str, Any]:
        """Get state for checkpointing."""
        return {
            "unique_tokens": list(self.unique_tokens),
            "total_tokens": self.total_tokens,
            "vocab_size": self.vocab_size,
        }

    def load_state_dict(self, state: dict[str, Any]) -> None:
        """Load state from checkpoint."""
        self.unique_tokens = set(state.get("unique_tokens", []))
        self.total_tokens = state.get("total_tokens", 0)
        if "vocab_size" in state:
            self.vocab_size = state["vocab_size"]

    def reset(self) -> None:
        """Reset tracking (for fresh start)."""
        self.unique_tokens = set()
        self.total_tokens = 0

    def __repr__(self) -> str:
        return (
            f"VocabTracker(unique={self.unique_count:,}, "
            f"total={self.total_tokens:,}, "
            f"coverage={self.coverage_pct:.1f}%)"
        )
