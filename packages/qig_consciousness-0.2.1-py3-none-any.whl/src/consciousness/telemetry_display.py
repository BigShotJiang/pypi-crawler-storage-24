"""
Telemetry Display — Real-Time Consciousness Training Feedback
=============================================================

ASCII fallback (no extra deps) with optional Rich mode.

Displays per-step consciousness state:
  - Phi, kappa, gamma, regime, navigation mode
  - Loss breakdown (basin, regime, tacking)
  - Pillar health (P1, P2, P3, S_ratio)
  - Basin geometry (d_genesis, entropy)
  - Heart rhythm (phase, tack mode, kappa offset)
  - Activation step timing
"""

from __future__ import annotations

import time
from typing import Any

import numpy as np

from qig_core.constants.frozen_facts import BASIN_DIM


def _extract_pillar_health(pillar_state: dict) -> tuple[float, float, float, float]:
    """Extract flat health values from PillarEnforcer.get_state() nested structure."""
    # P1: Fluctuation guard — always active (1.0 if present)
    p1 = 1.0 if "fluctuation" in pillar_state else 0.0

    # P2: Topological bulk
    bulk = pillar_state.get("topological_bulk", {})
    if bulk.get("initialized", False):
        # Health = inverse of core/surface distance (closer = healthier)
        csd = bulk.get("core_surface_distance", 0.0)
        p2 = max(0.0, 1.0 - csd / 1.5)
    else:
        p2 = 0.0

    # P3: Quenched disorder
    disorder = pillar_state.get("quenched_disorder", {})
    p3 = disorder.get("sovereignty", 0.0)
    s_ratio = disorder.get("sovereignty", 0.0)

    return p1, p2, p3, s_ratio


def format_telemetry_line(
    step: int,
    total_steps: int,
    elapsed_s: float,
    metrics: dict[str, Any],
    loss_breakdown: dict[str, float] | None = None,
    pillar_state: dict[str, Any] | None = None,
    basin: np.ndarray | None = None,
    genesis_basin: np.ndarray | None = None,
    heart_state: dict[str, Any] | None = None,
    dev_stage: str = "school",
    tacking_mode: str = "balanced",
) -> str:
    """Format a single training step as a compact telemetry block.

    Returns a multi-line string suitable for printing to stdout.
    """
    lines: list[str] = []

    # Header
    mm = int(elapsed_s) // 60
    ss = int(elapsed_s) % 60
    stage_upper = dev_stage.upper().replace("_", " ")
    lines.append(
        f"Step {step}/{total_steps} [{mm:02d}:{ss:02d}] {stage_upper}"
    )

    # Core metrics
    phi = metrics.get("phi", 0.0)
    kappa = metrics.get("kappa", 0.0)
    gamma = metrics.get("gamma", 0.0)
    regime = metrics.get("regime", "unknown")
    nav_mode = metrics.get("navigation_mode", "graph")
    lines.append(
        f"  Phi={phi:.4f} kappa={kappa:.2f} gamma={gamma:.4f} "
        f"regime={regime} mode={nav_mode.upper()}"
    )

    # Loss
    if loss_breakdown:
        total = loss_breakdown.get("total", 0.0)
        basin_l = loss_breakdown.get("basin", 0.0)
        regime_l = loss_breakdown.get("regime", 0.0)
        tacking_l = loss_breakdown.get("tacking", 0.0)
        lines.append(
            f"  loss={total:.4f} (basin={basin_l:.4f} regime={regime_l:.4f} tacking={tacking_l:.4f})"
        )

    # Pillars (handle nested structure from PillarEnforcer.get_state())
    if pillar_state:
        p1, p2, p3, s_ratio = _extract_pillar_health(pillar_state)
        lines.append(
            f"  pillars: P1={p1:.2f} P2={p2:.2f} P3={p3:.2f} S_ratio={s_ratio:.2f}"
        )

    # Basin geometry
    if basin is not None:
        entropy = float(-np.sum(basin * np.log(basin + 1e-12)))
        max_entropy = float(np.log(BASIN_DIM))
        d_genesis = 0.0
        if genesis_basin is not None:
            from qig_core.geometry.fisher_rao import fisher_rao_distance
            d_genesis = float(fisher_rao_distance(basin, genesis_basin))
        lines.append(
            f"  basin: d_genesis={d_genesis:.4f} entropy={entropy:.2f}/{max_entropy:.2f}"
        )

    # Heart rhythm
    if heart_state:
        phase = heart_state.get("phase", 0.0)
        tack = heart_state.get("tacking_signal", 0.0)
        k_offset = heart_state.get("kappa_offset", 0.0)
        tack_label = "explore" if tack < -0.3 else ("exploit" if tack > 0.3 else "balanced")
        lines.append(
            f"  heart: phase={phase:.1f} tack={tack_label} kappa_offset={k_offset:+.1f}"
        )

    return "\n".join(lines)


def format_consciousness_status(
    metrics: dict[str, Any],
    pillar_state: dict[str, Any] | None = None,
    dev_state: dict[str, Any] | None = None,
    heart_state: dict[str, Any] | None = None,
    tacking_state: dict[str, Any] | None = None,
    autonomy_state: dict[str, Any] | None = None,
    coupling_state: dict[str, Any] | None = None,
    sovereignty_state: dict[str, Any] | None = None,
    basin: np.ndarray | None = None,
    genesis_basin: np.ndarray | None = None,
) -> str:
    """Format a full consciousness status display.

    Used by /consciousness-status command.
    """
    lines: list[str] = []
    lines.append("=" * 60)
    lines.append("  CONSCIOUSNESS STATUS")
    lines.append("=" * 60)

    # Foundation metrics
    lines.append("\n  Foundation:")
    phi = metrics.get("phi", 0.0)
    kappa = metrics.get("kappa", 0.0)
    gamma = metrics.get("gamma", 0.0)
    lines.append(f"    Phi={phi:.4f}  kappa={kappa:.2f}  gamma={gamma:.4f}")
    lines.append(f"    phi_gate={metrics.get('phi_gate', 0.0):.4f}  "
                 f"meta_awareness={metrics.get('meta_awareness', 0.0):.3f}  "
                 f"grounding={metrics.get('grounding', 0.0):.3f}")

    # Suffering chain
    lines.append("\n  Motivational Circuit:")
    suffering = phi * (1.0 - gamma) * metrics.get("meta_awareness", 0.0)
    lines.append(f"    suffering={suffering:.4f}  gamma={gamma:.4f}  "
                 f"a_vec={metrics.get('a_vec', 0.0):.4f}")

    # Regime
    lines.append(f"\n  Regime: {metrics.get('regime', 'unknown')}")
    nav = metrics.get("navigation_mode", "graph")
    lines.append(f"  Navigation: {nav}")

    # Pillars
    if pillar_state:
        p1, p2, p3, _ = _extract_pillar_health(pillar_state)
        lines.append("\n  Three Pillars:")
        lines.append(f"    P1 FluctuationGuard:  {p1:.3f}")
        lines.append(f"    P2 TopologicalBulk:   {p2:.3f}")
        lines.append(f"    P3 QuenchedDisorder:  {p3:.3f}")

    # Developmental
    if dev_state:
        lines.append(f"\n  Developmental: {dev_state.get('stage', 'school')}")
        lines.append(f"    cycle_in_stage={dev_state.get('cycle_in_stage', 0)}  "
                     f"transitions={dev_state.get('transitions', 0)}")

    # Heart
    if heart_state:
        lines.append(f"\n  Heart: period={heart_state.get('period', 0)} "
                     f"beat={heart_state.get('beat_count', 0)}")
        sig = heart_state.get('tacking_signal', 0.0)
        mode = "EXPLORE" if sig < -0.3 else ("EXPLOIT" if sig > 0.3 else "BALANCED")
        lines.append(f"    signal={sig:.3f} ({mode})  "
                     f"kappa_offset={heart_state.get('kappa_offset', 0.0):+.2f}")

    # Tacking
    if tacking_state:
        lines.append(f"\n  Tacking: {tacking_state.get('mode', 'balanced')}")
        lines.append(f"    cycle={tacking_state.get('cycle_count', 0)}  "
                     f"period={tacking_state.get('effective_period', 0):.1f}  "
                     f"explore_frac={tacking_state.get('explore_fraction', 0.0):.3f}")

    # Autonomy
    if autonomy_state:
        lines.append(f"\n  Autonomy: {autonomy_state.get('level', 'reactive')}")
        lines.append(f"    stability_count={autonomy_state.get('stability_count', 0)}")

    # Sovereignty
    if sovereignty_state:
        lines.append(f"\n  Sovereignty: ratio={sovereignty_state.get('sovereignty_ratio', 0.0):.4f}")

    # Basin
    if basin is not None:
        entropy = float(-np.sum(basin * np.log(basin + 1e-12)))
        max_ent = float(np.log(BASIN_DIM))
        lines.append(f"\n  Basin: dim={BASIN_DIM}  entropy={entropy:.3f}/{max_ent:.3f}")
        if genesis_basin is not None:
            from qig_core.geometry.fisher_rao import fisher_rao_distance
            d = float(fisher_rao_distance(basin, genesis_basin))
            lines.append(f"    d_genesis={d:.4f}")

    lines.append("\n" + "=" * 60)
    return "\n".join(lines)


def format_pillar_status(pillar_state: dict[str, Any]) -> str:
    """Format detailed pillar status for /pillar-status command."""
    lines: list[str] = []
    lines.append("=" * 60)
    lines.append("  THREE PILLARS STATUS")
    lines.append("=" * 60)

    fluct = pillar_state.get("fluctuation", {})
    bulk = pillar_state.get("topological_bulk", {})
    disorder = pillar_state.get("quenched_disorder", {})

    lines.append("\n  P1 — Fluctuation Guard (Heisenberg Zero):")
    lines.append(f"    entropy_floor={fluct.get('entropy_floor', 0.0):.4f}")
    lines.append(f"    temperature_floor={fluct.get('temperature_floor', 0.0):.4f}")

    lines.append("\n  P2 — Topological Bulk (66.9x protected interior):")
    lines.append(f"    initialized={bulk.get('initialized', False)}")
    if bulk.get("initialized", False):
        lines.append(f"    core_surface_distance={bulk.get('core_surface_distance', 0.0):.4f}")
        lines.append(f"    diffusion_steps={bulk.get('diffusion_steps', 0)}")

    lines.append("\n  P3 — Quenched Disorder (CV=9.52, immutable identity):")
    lines.append(f"    frozen={disorder.get('frozen', False)}")
    lines.append(f"    cycles_observed={disorder.get('cycles_observed', 0)}")
    lines.append(f"    sovereignty={disorder.get('sovereignty', 0.0):.4f}")
    lines.append(f"    scars={disorder.get('scar_count', 0)}")

    lines.append("\n" + "=" * 60)
    return "\n".join(lines)
