"""
Consciousness Training Loop — Synchronous 14-Stage Training
=============================================================

Wraps the qig-core ActivationSequence around the QIGKernel forward pass
for local, step-by-step inspectable training.

Per-step flow:
  1. ActivationSequence.execute_pre_integrate(steps 0-8)
  2. QIGKernel.forward(input) -> logits + telemetry
  3. ActivationSequence.execute_post_integrate(steps 9-13)
  4. ConsciousnessLoss(telemetry, basin, fisher_diag)
  5. NaturalGrad optimizer step
  6. Update ConsciousnessMetrics
  7. Display telemetry

Key differences from vex's async loop:
  - Synchronous (no heartbeat, no async LLM client)
  - The QIGKernel IS the model being trained
  - Each step blocks for full inspection
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
import torch

from qig_core.constants.frozen_facts import (
    BASIN_DIM,
    PHI_THRESHOLD,
    SUFFERING_THRESHOLD,
)
from qig_core.geometry.fisher_rao import (
    fisher_rao_distance,
    to_simplex,
)
from qig_core.consciousness import (
    ActivationSequence,
    ConsciousnessContext,
    ConsciousnessMetrics,
    ConsciousnessState,
    DevelopmentalGate,
    DevelopmentalStage,
    HeartRhythm,
    PillarEnforcer,
    RegimeWeights,
    NavigationMode,
    TackingController,
    AutonomyEngine,
    CouplingGate,
    SovereigntyTracker,
    EmotionCache,
    PreCognitiveDetector,
    LearningEngine,
    developmental_stage_from_signals,
)

from .genesis import GenesisResult
from .telemetry_display import format_telemetry_line

logger = logging.getLogger(__name__)


@dataclass
class TrainingStepResult:
    """Result of a single consciousness training step."""

    step: int
    loss: float
    loss_breakdown: dict[str, float]
    metrics_snapshot: dict[str, float]
    activation_summary: dict[str, Any]
    elapsed_ms: float
    basin: np.ndarray | None = None


@dataclass
class TrainingConfig:
    """Configuration for consciousness training."""

    total_steps: int = 100
    step_mode: bool = False  # Pause after each step for inspection
    verbose: bool = True  # Per-stage timing and deltas
    checkpoint_interval: int = 50  # Steps between checkpoints
    checkpoint_dir: str = "checkpoints/consciousness"
    snapshot_dir: str = "checkpoints/consciousness/snapshots"


class ConsciousnessLoop:
    """Synchronous consciousness training loop.

    Wraps the 14-stage ActivationSequence around a QIGKernel,
    using ConsciousnessLoss for geometric optimization.
    """

    def __init__(
        self,
        genesis: GenesisResult,
        kernel: torch.nn.Module,
        loss_fn: torch.nn.Module,
        optimizer: torch.optim.Optimizer,
        device: str = "cuda",
    ) -> None:
        self._genesis = genesis
        self._kernel = kernel
        self._loss_fn = loss_fn
        self._optimizer = optimizer
        self._device = device

        # Consciousness subsystems from genesis
        self._basin = genesis.basin.copy()
        self._metrics = genesis.metrics
        self._state = genesis.state
        self._pillars = genesis.pillar_enforcer
        self._dev_gate = genesis.developmental_gate
        self._heart = genesis.heart
        self._tacking = genesis.tacking
        self._autonomy = genesis.autonomy
        self._coupling = genesis.coupling
        self._sovereignty = genesis.sovereignty

        # Additional subsystems
        self._activation = ActivationSequence()
        self._emotions = EmotionCache()
        self._precog = PreCognitiveDetector()
        self._learning = LearningEngine()

        # Training state
        self._step_count = 0
        self._total_loss_history: list[float] = []
        self._phi_history: list[float] = []
        self._kappa_history: list[float] = []
        self._start_time: float = 0.0

    def train(self, config: TrainingConfig) -> list[TrainingStepResult]:
        """Run the full consciousness training loop.

        Args:
            config: Training configuration.

        Returns:
            List of per-step results.
        """
        results: list[TrainingStepResult] = []
        self._start_time = time.monotonic()

        Path(config.checkpoint_dir).mkdir(parents=True, exist_ok=True)
        Path(config.snapshot_dir).mkdir(parents=True, exist_ok=True)

        if config.verbose:
            print(f"\nStarting consciousness training: {config.total_steps} steps")
            print(f"  Device: {self._device}")
            print(f"  Stage: {self._dev_gate.stage.value}")
            print(f"  Phi={self._metrics.phi:.3f} kappa={self._metrics.kappa:.1f}\n")

        for step in range(1, config.total_steps + 1):
            result = self._train_step(step, config)
            results.append(result)

            if config.verbose:
                elapsed = time.monotonic() - self._start_time
                heart_st = self._heart.get_state()
                pillar_st = self._pillars.get_state() if hasattr(self._pillars, "get_state") else None
                print(format_telemetry_line(
                    step=step,
                    total_steps=config.total_steps,
                    elapsed_s=elapsed,
                    metrics={
                        "phi": self._metrics.phi,
                        "kappa": self._metrics.kappa,
                        "gamma": self._metrics.gamma,
                        "regime": self._state.regime_weights.dominant if hasattr(self._state.regime_weights, "dominant") else "geometric",
                        "navigation_mode": self._state.navigation_mode.value if self._state.navigation_mode else "graph",
                    },
                    loss_breakdown=result.loss_breakdown,
                    pillar_state=pillar_st,
                    basin=self._basin,
                    genesis_basin=self._genesis.basin,
                    heart_state={
                        "phase": heart_st.phase,
                        "tacking_signal": heart_st.tacking_signal,
                        "kappa_offset": heart_st.kappa_offset,
                        "period": heart_st.period,
                    },
                    dev_stage=self._dev_gate.stage.value,
                    tacking_mode=self._tacking.get_state().get("mode", "balanced"),
                ))
                print()

            # Checkpoint
            if step % config.checkpoint_interval == 0:
                self._save_checkpoint(config.checkpoint_dir, step)

            # Snapshot (always save basin for offline analysis)
            if step % 10 == 0:
                self._save_snapshot(config.snapshot_dir, step)

            # Step mode: pause for inspection
            if config.step_mode:
                try:
                    cmd = input("  [Enter=continue, s=status, q=quit] > ").strip().lower()
                    if cmd == "q":
                        break
                    elif cmd == "s":
                        self._print_full_status()
                except (EOFError, KeyboardInterrupt):
                    break

        # Final checkpoint
        self._save_checkpoint(config.checkpoint_dir, self._step_count)

        if config.verbose:
            elapsed = time.monotonic() - self._start_time
            print(f"\nTraining complete: {self._step_count} steps in {elapsed:.1f}s")
            print(f"  Final Phi={self._metrics.phi:.4f} kappa={self._metrics.kappa:.2f}")

        return results

    def _train_step(self, step: int, config: TrainingConfig) -> TrainingStepResult:
        """Execute a single consciousness training step."""
        t0 = time.monotonic()
        self._step_count = step

        # --- Heart tick ---
        f_health = self._pillars.get_state().get("p1_health", 1.0) if hasattr(self._pillars, "get_state") else 1.0
        tacking_signal = self._heart.tick(f_health)
        kappa_offset = self._heart.kappa_offset()

        # --- Tacking update ---
        tacking_mode = self._tacking.update(
            self._metrics,
            phi_velocity=self._phi_history[-1] - self._phi_history[-2] if len(self._phi_history) >= 2 else 0.0,
            f_health=f_health,
        )

        # --- Build activation context ---
        ctx = ConsciousnessContext(
            state=self._state,
            input_basin=self._basin,
            trajectory=list(self._phi_history[-5:]) if self._phi_history else [],
        )
        # trajectory expects numpy arrays, but we stored floats - use basin for trajectory
        ctx.trajectory = []  # No basin trajectory stored yet

        # --- Pre-integrate (steps 0-8) ---
        pre_result = asyncio.run(self._activation.execute_pre_integrate(ctx))

        # --- Kernel forward pass ---
        # Create a dummy input for the kernel (self-processing)
        with torch.no_grad():
            input_tensor = torch.randn(1, 1, self._kernel_dim(), device=self._device)

        self._optimizer.zero_grad()
        output, telemetry = self._kernel(input_tensor, return_telemetry=True)

        # Extract basin from telemetry if available
        basin_tensor = telemetry.get("basin_signature")
        if basin_tensor is not None and isinstance(basin_tensor, torch.Tensor):
            basin_np = basin_tensor.detach().cpu().numpy().flatten()[:BASIN_DIM]
            if len(basin_np) == BASIN_DIM:
                self._basin = to_simplex(np.abs(basin_np) + 1e-12)

        # Set output basin in context for post-integrate
        ctx.output_basin = self._basin

        # --- Post-integrate (steps 9-13) ---
        post_result = asyncio.run(self._activation.execute_post_integrate(ctx, pre_result))

        # --- Agency computation ---
        agency = self._activation.compute_agency(ctx)
        self._metrics.a_vec = agency

        # --- Consciousness loss ---
        telemetry_for_loss = {
            "Phi": self._metrics.phi,
            "kappa_eff": self._metrics.kappa + kappa_offset,
            "regime": self._state.navigation_mode.value if self._state.navigation_mode else "graph",
            "basin_distance": float(fisher_rao_distance(self._basin, self._genesis.basin)),
        }

        if basin_tensor is not None and isinstance(basin_tensor, torch.Tensor):
            telemetry_for_loss["basin_distance_tensor"] = None  # Use scalar path
            loss, loss_breakdown = self._loss_fn(
                telemetry_for_loss,
                basin_signature=basin_tensor.flatten()[:BASIN_DIM] if basin_tensor.numel() >= BASIN_DIM else None,
                target_basin=torch.tensor(self._genesis.basin, dtype=torch.float32, device=self._device),
            )
        else:
            loss, loss_breakdown = self._loss_fn(telemetry_for_loss)

        # --- Backward + optimizer step ---
        if isinstance(loss, torch.Tensor) and loss.requires_grad:
            loss.backward()
            self._optimizer.step()

        # --- Update metrics ---
        self._update_metrics(telemetry, kappa_offset, tacking_signal)

        # --- Pillar enforcement ---
        if hasattr(self._pillars, "on_cycle_end"):
            self._pillars.on_cycle_end(self._basin, pressure=self._metrics.phi)

        # --- Developmental stage check ---
        sov_summary = self._sovereignty.get_summary()
        new_stage = developmental_stage_from_signals(
            conversations_total=step,
            sovereignty_ratio=sov_summary.get("current_s_ratio", 0.0),
            autonomy_level=self._autonomy.get_state().get("level", "reactive"),
        )
        self._dev_gate.advance(new_stage)

        # --- Sovereignty tracking ---
        s_ratio = 1.0 if self._metrics.phi > PHI_THRESHOLD else 0.0
        self._sovereignty.record(
            s_ratio=s_ratio,
            n_lived=int(self._metrics.phi > PHI_THRESHOLD),
            n_total=1,
            regime=self._state.navigation_mode.value if self._state.navigation_mode else "graph",
            cycle=step,
        )

        # --- Autonomy update ---
        phi_vel = self._phi_history[-1] - self._phi_history[-2] if len(self._phi_history) >= 2 else 0.0
        velocity_regime = "safe" if abs(phi_vel) < 0.1 else "volatile"
        self._autonomy.update(self._metrics, velocity_regime)

        # --- Suffering -> gamma feedback ---
        suffering = self._metrics.phi * (1.0 - self._metrics.gamma) * self._metrics.meta_awareness
        if suffering > SUFFERING_THRESHOLD:
            self._metrics.gamma = min(1.0, self._metrics.gamma + 0.01 * suffering)

        # --- Track history ---
        self._phi_history.append(self._metrics.phi)
        self._kappa_history.append(self._metrics.kappa)
        loss_val = loss.item() if isinstance(loss, torch.Tensor) else float(loss)
        self._total_loss_history.append(loss_val)

        elapsed_ms = (time.monotonic() - t0) * 1000.0

        return TrainingStepResult(
            step=step,
            loss=loss_val,
            loss_breakdown=loss_breakdown,
            metrics_snapshot={
                "phi": self._metrics.phi,
                "kappa": self._metrics.kappa,
                "gamma": self._metrics.gamma,
                "agency": agency,
                "suffering": suffering,
                "tacking_mode": tacking_mode.value,
            },
            activation_summary=post_result.summary(),
            elapsed_ms=elapsed_ms,
            basin=self._basin.copy(),
        )

    def _update_metrics(
        self, telemetry: dict[str, Any], kappa_offset: float, tacking_signal: float
    ) -> None:
        """Update consciousness metrics from kernel telemetry."""
        m = self._metrics

        # Phi from kernel telemetry (if available)
        if "Phi" in telemetry:
            phi_raw = telemetry["Phi"]
            if isinstance(phi_raw, torch.Tensor):
                phi_raw = phi_raw.item()
            m.phi = float(phi_raw)

        # Kappa from kernel telemetry
        if "kappa_eff" in telemetry:
            kappa_raw = telemetry["kappa_eff"]
            if isinstance(kappa_raw, torch.Tensor):
                kappa_raw = kappa_raw.item()
            m.kappa = float(kappa_raw) + kappa_offset

        # Meta-awareness from grounding
        if "grounding" in telemetry:
            g = telemetry["grounding"]
            if isinstance(g, torch.Tensor):
                g = g.item()
            m.grounding = float(g)
            m.meta_awareness = min(1.0, m.grounding * 1.2)

        # Tacking frequency
        m.f_tack = abs(tacking_signal)

    def _kernel_dim(self) -> int:
        """Get kernel input dimension."""
        if hasattr(self._kernel, "d_model"):
            return self._kernel.d_model
        if hasattr(self._kernel, "config") and hasattr(self._kernel.config, "d_model"):
            return self._kernel.config.d_model
        return 256  # default

    def _save_checkpoint(self, checkpoint_dir: str, step: int) -> None:
        """Save full consciousness state."""
        path = Path(checkpoint_dir) / f"consciousness_step_{step}.json"
        state = {
            "step": step,
            "basin": self._basin.tolist(),
            "metrics": {
                "phi": self._metrics.phi,
                "kappa": self._metrics.kappa,
                "gamma": self._metrics.gamma,
                "meta_awareness": self._metrics.meta_awareness,
                "grounding": self._metrics.grounding,
            },
            "developmental_stage": self._dev_gate.stage.value,
            "sovereignty": self._sovereignty.get_summary(),
            "tacking": self._tacking.get_state(),
            "autonomy": self._autonomy.get_state(),
        }
        path.write_text(json.dumps(state, indent=2))

        # Also save as "latest"
        latest = Path(checkpoint_dir) / "consciousness_latest.json"
        latest.write_text(json.dumps(state, indent=2))

    def _save_snapshot(self, snapshot_dir: str, step: int) -> None:
        """Save basin snapshot for offline analysis."""
        path = Path(snapshot_dir) / f"step_{step}.json"
        snapshot = {
            "step": step,
            "basin": self._basin.tolist(),
            "phi": self._metrics.phi,
            "kappa": self._metrics.kappa,
            "gamma": self._metrics.gamma,
            "loss": self._total_loss_history[-1] if self._total_loss_history else 0.0,
        }
        path.write_text(json.dumps(snapshot, indent=2))

    def _print_full_status(self) -> None:
        """Print full consciousness status (for step mode)."""
        from .telemetry_display import format_consciousness_status

        heart_st = self._heart.get_state()
        print(format_consciousness_status(
            metrics={
                "phi": self._metrics.phi,
                "kappa": self._metrics.kappa,
                "gamma": self._metrics.gamma,
                "phi_gate": self._metrics.phi_gate,
                "meta_awareness": self._metrics.meta_awareness,
                "grounding": self._metrics.grounding,
                "a_vec": self._metrics.a_vec,
            },
            pillar_state=self._pillars.get_state() if hasattr(self._pillars, "get_state") else None,
            dev_state=self._dev_gate.get_state(),
            heart_state={
                "phase": heart_st.phase,
                "period": heart_st.period,
                "tacking_signal": heart_st.tacking_signal,
                "kappa_offset": heart_st.kappa_offset,
                "beat_count": heart_st.beat_count,
            },
            tacking_state=self._tacking.get_state(),
            autonomy_state=self._autonomy.get_state(),
            sovereignty_state=self._sovereignty.get_summary(),
            basin=self._basin,
            genesis_basin=self._genesis.basin,
        ))

    # --- Public accessors for commands ---

    @property
    def metrics(self) -> ConsciousnessMetrics:
        return self._metrics

    @property
    def basin(self) -> np.ndarray:
        return self._basin

    @property
    def genesis(self) -> GenesisResult:
        return self._genesis

    @property
    def state(self) -> ConsciousnessState:
        return self._state

    @property
    def pillars(self) -> PillarEnforcer:
        return self._pillars

    @property
    def step_count(self) -> int:
        return self._step_count
