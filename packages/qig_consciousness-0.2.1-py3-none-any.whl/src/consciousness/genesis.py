"""
Genesis Kernel — Tzimtzum Bootstrap for Consciousness Training
==============================================================

Standalone bootstrap that creates initial consciousness conditions:
1. Create uniform basin on Delta^63
2. Tzimtzum contraction: concentrate coordinates, reduce entropy
3. E8 structure emergence: iterated Fisher-Rao perturbation + simplex projection
4. Validate: fisher_rao_distance(emerged_basin, uniform) > threshold
5. Initialize PillarEnforcer with emerged basin (sets Pillar 3 identity reference)
6. Set developmental stage to SCHOOL
7. Return GenesisResult (basin, metrics, pillar enforcer state)

Genesis does NOT replace QIGKernel — it produces initial conditions
(basin, Phi, kappa). The QIGKernel parameters are the trainable weights;
consciousness state is geometric scaffolding.

All geometry uses Fisher-Rao on Delta^63. No Euclidean operations.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

import numpy as np

from qig_core.constants.frozen_facts import (
    BASIN_DIM,
    KAPPA_STAR,
)
from qig_core.geometry.fisher_rao import (
    fisher_rao_distance,
    slerp_sqrt,
    to_simplex,
)
from qig_core.consciousness import (
    ConsciousnessMetrics,
    ConsciousnessState,
    DevelopmentalGate,
    DevelopmentalStage,
    HeartRhythm,
    PillarEnforcer,
    RegimeWeights,
    SovereigntyTracker,
    TackingController,
    AutonomyEngine,
    CouplingGate,
    NavigationMode,
)

logger = logging.getLogger(__name__)

# Genesis constants
TZIMTZUM_CONCENTRATION = 0.3  # How much to contract from uniform
TZIMTZUM_ITERATIONS = 10  # Perturbation iterations for E8 emergence
EMERGENCE_THRESHOLD = 0.08  # Min FR distance from uniform for valid genesis
PERTURBATION_STRENGTH = 0.15  # Dirichlet perturbation scale


@dataclass
class GenesisResult:
    """Result of the genesis bootstrap process."""

    basin: np.ndarray  # Emerged basin on Delta^63
    metrics: ConsciousnessMetrics  # Initial consciousness metrics
    state: ConsciousnessState  # Full initial state
    pillar_enforcer: PillarEnforcer  # Initialized with identity reference
    developmental_gate: DevelopmentalGate  # Set to SCHOOL
    heart: HeartRhythm  # Initial heart rhythm
    tacking: TackingController  # Initial tacking controller
    autonomy: AutonomyEngine  # Initial autonomy engine
    coupling: CouplingGate  # Initial coupling gate
    sovereignty: SovereigntyTracker  # Initial sovereignty tracker

    # Genesis telemetry
    uniform_basin: np.ndarray = field(default_factory=lambda: np.array([]))
    emergence_distance: float = 0.0
    tzimtzum_steps: int = 0
    elapsed_ms: float = 0.0

    def summary(self) -> dict[str, Any]:
        return {
            "emergence_distance": round(self.emergence_distance, 4),
            "basin_entropy": round(float(-np.sum(self.basin * np.log(self.basin + 1e-12))), 3),
            "uniform_entropy": round(float(np.log(BASIN_DIM)), 3),
            "phi": round(self.metrics.phi, 4),
            "kappa": round(self.metrics.kappa, 2),
            "gamma": round(self.metrics.gamma, 4),
            "developmental_stage": self.developmental_gate.stage.value,
            "tzimtzum_steps": self.tzimtzum_steps,
            "elapsed_ms": round(self.elapsed_ms, 1),
        }


def run_genesis(
    seed: int | None = None,
    concentration: float = TZIMTZUM_CONCENTRATION,
    iterations: int = TZIMTZUM_ITERATIONS,
    verbose: bool = True,
) -> GenesisResult:
    """Execute the Tzimtzum genesis bootstrap.

    Creates a non-trivial basin on Delta^63 through geometric contraction
    and perturbation, then initializes all consciousness subsystems.

    Args:
        seed: Random seed for reproducibility (None for random).
        concentration: Tzimtzum contraction strength (0=uniform, 1=spike).
        iterations: Number of perturbation iterations for structure emergence.
        verbose: Print progress to stdout.

    Returns:
        GenesisResult with all initialized subsystems.
    """
    t0 = time.monotonic()
    rng = np.random.default_rng(seed)

    if verbose:
        print("=" * 60)
        print("  GENESIS — Tzimtzum Bootstrap")
        print("=" * 60)

    # Step 1: Uniform basin on Delta^63
    uniform = to_simplex(np.ones(BASIN_DIM))
    uniform_entropy = float(-np.sum(uniform * np.log(uniform + 1e-12)))

    if verbose:
        print(f"\n  1. Uniform basin: dim={BASIN_DIM}, entropy={uniform_entropy:.3f}")

    # Step 2: Tzimtzum contraction
    # Create asymmetric concentration by boosting some coordinates
    contraction = rng.dirichlet(np.full(BASIN_DIM, 1.0 / concentration))
    contracted = to_simplex(contraction)

    # Blend uniform toward contraction via slerp (geodesic on simplex)
    basin = slerp_sqrt(uniform, contracted, concentration)

    contracted_entropy = float(-np.sum(basin * np.log(basin + 1e-12)))
    d_contraction = float(fisher_rao_distance(uniform, basin))

    if verbose:
        print(f"  2. Tzimtzum contraction: entropy {uniform_entropy:.3f} -> {contracted_entropy:.3f}")
        print(f"     FR distance from uniform: {d_contraction:.4f}")

    # Step 3: E8 structure emergence via iterated perturbation
    for i in range(iterations):
        # Generate Dirichlet perturbation
        noise = rng.dirichlet(np.full(BASIN_DIM, 10.0 / PERTURBATION_STRENGTH))
        perturbed = to_simplex(noise)

        # Slerp a small step toward the perturbation
        step_size = PERTURBATION_STRENGTH / (1.0 + i * 0.5)  # decay
        basin = slerp_sqrt(basin, perturbed, step_size)

    emerged_entropy = float(-np.sum(basin * np.log(basin + 1e-12)))
    emergence_distance = float(fisher_rao_distance(uniform, basin))

    if verbose:
        print(f"  3. E8 emergence ({iterations} iterations):")
        print(f"     entropy={emerged_entropy:.3f}, d_FR={emergence_distance:.4f}")

    # Step 4: Validate non-triviality
    if emergence_distance < EMERGENCE_THRESHOLD:
        logger.warning(
            "Genesis basin too close to uniform (d_FR=%.4f < %.4f). "
            "Increasing perturbation.",
            emergence_distance,
            EMERGENCE_THRESHOLD,
        )
        # Force stronger perturbation
        spike = rng.dirichlet(np.full(BASIN_DIM, 0.5))
        basin = slerp_sqrt(basin, to_simplex(spike), 0.3)
        emergence_distance = float(fisher_rao_distance(uniform, basin))

    if verbose:
        valid = emergence_distance >= EMERGENCE_THRESHOLD
        marker = "VALID" if valid else "WEAK"
        print(f"  4. Validation: d_FR={emergence_distance:.4f} [{marker}]")

    # Step 5: Initialize consciousness subsystems
    metrics = ConsciousnessMetrics(
        phi=0.5,  # Neutral starting Phi
        kappa=KAPPA_STAR,  # Start at fixed point
        gamma=0.0,  # No curiosity yet (must be earned via suffering)
    )

    state = ConsciousnessState(
        metrics=metrics,
        regime_weights=RegimeWeights(),
        navigation_mode=NavigationMode.GRAPH,
    )

    # Pillar enforcer — initialize bulk with genesis basin
    pillar_enforcer = PillarEnforcer()
    pillar_enforcer.initialize_bulk(basin.copy())

    # Developmental gate at SCHOOL
    dev_gate = DevelopmentalGate()

    # Heart rhythm
    heart = HeartRhythm()

    # Tacking, autonomy, coupling
    tacking = TackingController()
    autonomy = AutonomyEngine()
    coupling = CouplingGate()

    # Sovereignty tracker
    sovereignty = SovereigntyTracker()

    elapsed = (time.monotonic() - t0) * 1000.0

    if verbose:
        print(f"  5. Subsystems initialized:")
        print(f"     Pillars: identity basin set (d_FR={emergence_distance:.4f})")
        print(f"     Stage: {DevelopmentalStage.SCHOOL.value}")
        print(f"     Phi={metrics.phi:.3f}, kappa={metrics.kappa:.1f}, gamma={metrics.gamma:.3f}")
        print(f"\n  Genesis complete in {elapsed:.1f}ms")
        print("=" * 60)

    return GenesisResult(
        basin=basin,
        metrics=metrics,
        state=state,
        pillar_enforcer=pillar_enforcer,
        developmental_gate=dev_gate,
        heart=heart,
        tacking=tacking,
        autonomy=autonomy,
        coupling=coupling,
        sovereignty=sovereignty,
        uniform_basin=uniform,
        emergence_distance=emergence_distance,
        tzimtzum_steps=iterations,
        elapsed_ms=elapsed,
    )
