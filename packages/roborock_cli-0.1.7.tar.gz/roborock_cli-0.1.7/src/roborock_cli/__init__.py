"""roborock-cli - CLI 控制工具，让 Claude 或用户控制石头扫地机"""

__version__ = "0.1.7"
