"""Ferramentas MCP do Jira para criação e gestão de tickets.

Registra as ferramentas MCP no server, delegando ao JiraClient.
"""

import json
import logging

from mcp.server import Server
from mcp.types import TextContent, Tool

from mcp_jira.jira_client import (
    JiraAuthError,
    JiraClient,
    JiraError,
    JiraValidationError,
)

logger = logging.getLogger(__name__)

TOOLS = [
    Tool(
        name="jira_get_issue",
        description=(
            "Busca detalhes completos de uma issue pelo key (ex: PROJ-123). "
            "Retorna todos os campos incluindo customizados. "
            "Campos com texto muito grande (acima de 5000 caracteres) são salvos automaticamente "
            "em arquivo .txt local e o valor retornado será o caminho do arquivo no formato "
            "'[conteúdo salvo em arquivo: <path>]'. Nesse caso, leia o arquivo para obter o conteúdo completo."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "issueKey": {
                    "type": "string",
                    "description": "Chave da issue (ex: PROJ-123)",
                },
                "outputDir": {
                    "type": "string",
                    "description": (
                        "Diretório de destino para salvar campos grandes em arquivo. "
                        "Se omitido, salva no diretório de trabalho atual (cwd) do processo MCP "
                        "(que pode NÃO ser o workspace do usuário). "
                        "IMPORTANTE: para garantir que os arquivos sejam salvos dentro do workspace "
                        "e possam ser lidos posteriormente, passe o caminho ABSOLUTO do workspace "
                        "como valor deste campo."
                    ),
                },
            },
            "required": ["issueKey"],
        },
    ),
    Tool(
        name="jira_create_issue",
        description=(
            "Cria um ticket no Jira. IMPORTANTE: Antes de usar esta ferramenta, "
            "use jira_list_issue_types para obter os tipos de issue válidos do projeto, "
            "e use jira_list_funcionalidades (ou jira_list_field_options) para obter os IDs válidos "
            "de campos customizados obrigatórios como 'Funcionalidade'. "
            "O issueType deve corresponder exatamente aos nomes retornados por jira_list_issue_types."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "projectKey": {
                    "type": "string",
                    "description": "Chave do projeto (ex: PROJ)",
                },
                "summary": {
                    "type": "string",
                    "description": "Título do ticket",
                },
                "description": {
                    "type": "string",
                    "description": "Descrição do ticket",
                },
                "issueType": {
                    "type": "string",
                    "description": "Tipo da issue. Use jira_list_issue_types para obter os valores válidos do projeto.",
                },
                "priority": {
                    "type": "string",
                    "description": "Prioridade do ticket",
                },
                "labels": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Labels do ticket",
                },
                "components": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Componentes do ticket (se o projeto usar).",
                },
                "customFields": {
                    "type": "object",
                    "description": (
                        "Campos customizados do ticket como pares chave-valor. "
                        "A chave é o nome do campo (ex: 'Funcionalidade') e o valor é o ID numérico "
                        "retornado por jira_list_field_options ou jira_list_funcionalidades "
                        "(ex: {'Funcionalidade': '13039'}). NÃO use o nome da opção, use o ID."
                    ),
                },
            },
            "required": ["projectKey", "summary", "description", "issueType"],
        },
    ),
    Tool(
        name="jira_search",
        description="Consulta tickets no Jira via JQL",
        inputSchema={
            "type": "object",
            "properties": {
                "jql": {
                    "type": "string",
                    "description": "Query JQL para busca",
                },
                "maxResults": {
                    "type": "integer",
                    "description": "Número máximo de resultados (default: 50)",
                },
                "fields": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Campos a retornar",
                },
            },
            "required": ["jql"],
        },
    ),
    Tool(
        name="jira_update_issue",
        description="Atualiza campos de um ticket existente no Jira",
        inputSchema={
            "type": "object",
            "properties": {
                "issueKey": {
                    "type": "string",
                    "description": "Chave da issue (ex: PROJ-123)",
                },
                "fields": {
                    "type": "object",
                    "description": "Campos a atualizar",
                },
            },
            "required": ["issueKey", "fields"],
        },
    ),
    Tool(
        name="jira_add_comment",
        description="Adiciona comentário a um ticket no Jira",
        inputSchema={
            "type": "object",
            "properties": {
                "issueKey": {
                    "type": "string",
                    "description": "Chave da issue (ex: PROJ-123)",
                },
                "body": {
                    "type": "string",
                    "description": "Texto do comentário",
                },
            },
            "required": ["issueKey", "body"],
        },
    ),
    Tool(
        name="jira_list_issue_types",
        description="Lista os tipos de issue disponíveis no Jira para um projeto. Use antes de criar issues para garantir que o issueType é válido.",
        inputSchema={
            "type": "object",
            "properties": {
                "projectKey": {
                    "type": "string",
                    "description": "Chave do projeto (ex: PROJ). Se omitido, lista todos os tipos globais.",
                },
            },
        },
    ),
    Tool(
        name="jira_list_components",
        description="Lista os componentes disponíveis em um projeto Jira.",
        inputSchema={
            "type": "object",
            "properties": {
                "projectKey": {
                    "type": "string",
                    "description": "Chave do projeto (ex: PROJ)",
                },
            },
            "required": ["projectKey"],
        },
    ),
    Tool(
        name="jira_list_field_options",
        description="Lista as opções disponíveis de um campo (ex: Funcionalidade, Tipo de Erro) para um projeto e tipo de issue. Use para descobrir valores válidos de campos customizados antes de criar issues. O campo 'id' retornado é o valor que deve ser passado no customFields de jira_create_issue.",
        inputSchema={
            "type": "object",
            "properties": {
                "projectKey": {
                    "type": "string",
                    "description": "Chave do projeto (ex: PROJ)",
                },
                "issueTypeName": {
                    "type": "string",
                    "description": "Nome do tipo de issue (ex: Erro, Melhoria). Use jira_list_issue_types para obter os valores válidos.",
                },
                "fieldName": {
                    "type": "string",
                    "description": "Nome do campo (ex: Funcionalidade, Tipo de Erro)",
                },
            },
            "required": ["projectKey", "issueTypeName", "fieldName"],
        },
    ),
    Tool(
        name="jira_list_funcionalidades",
        description="Lista as funcionalidades disponíveis em um projeto Jira para um tipo de issue. Atalho para jira_list_field_options com fieldName='Funcionalidade'. Use antes de criar issues para preencher o campo Funcionalidade corretamente via customFields. O campo 'id' retornado é o valor que deve ser passado (ex: customFields={'Funcionalidade': '13039'}).",
        inputSchema={
            "type": "object",
            "properties": {
                "projectKey": {
                    "type": "string",
                    "description": "Chave do projeto (ex: PROJ)",
                },
                "issueTypeName": {
                    "type": "string",
                    "description": "Nome do tipo de issue (ex: Erro, Melhoria). Use jira_list_issue_types para obter os valores válidos.",
                },
            },
            "required": ["projectKey", "issueTypeName"],
        },
    ),
    Tool(
        name="jira_list_attachments",
        description="Lista os anexos de uma issue no Jira, retornando id, nome, tamanho e tipo de cada arquivo.",
        inputSchema={
            "type": "object",
            "properties": {
                "issueKey": {
                    "type": "string",
                    "description": "Chave da issue (ex: PROJ-123)",
                },
            },
            "required": ["issueKey"],
        },
    ),
    Tool(
        name="jira_download_attachment",
        description=(
            "Baixa anexo(s) de uma issue do Jira para um diretório local. "
            "Se attachmentId for informado, baixa apenas esse anexo. "
            "Caso contrário, baixa todos os anexos da issue. "
            "Use jira_list_attachments antes para ver os anexos disponíveis. "
            "O diretório de destino é resolvido automaticamente para o diretório de trabalho "
            "atual (cwd) do processo quando outputDir não é informado."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "issueKey": {
                    "type": "string",
                    "description": "Chave da issue (ex: PROJ-123)",
                },
                "attachmentId": {
                    "type": "string",
                    "description": "ID do anexo específico para baixar. Se omitido, baixa todos.",
                },
                "outputDir": {
                    "type": "string",
                    "description": (
                        "Diretório de destino para salvar os arquivos. "
                        "Se omitido, salva no diretório de trabalho atual (cwd) do processo MCP "
                        "(que pode NÃO ser o workspace do usuário). "
                        "IMPORTANTE: para garantir que os arquivos sejam salvos dentro do workspace "
                        "e possam ser lidos posteriormente, passe o caminho ABSOLUTO do workspace "
                        "como valor deste campo."
                    ),
                },
            },
            "required": ["issueKey"],
        },
    ),
]


def _error_content(message: str) -> list[TextContent]:
    """Cria resposta de erro MCP com isError=True."""
    return [TextContent(type="text", text=message)]


def _success_content(data: dict | list | str) -> list[TextContent]:
    """Cria resposta de sucesso MCP."""
    if isinstance(data, str):
        text = data
    else:
        text = json.dumps(data, ensure_ascii=False, indent=2)
    return [TextContent(type="text", text=text)]


def register_tools(app: Server, client: JiraClient) -> None:
    """Registra as ferramentas MCP do Jira no server."""

    @app.list_tools()
    async def list_tools() -> list[Tool]:
        return TOOLS

    @app.call_tool()
    async def call_tool(
        name: str, arguments: dict
    ) -> list[TextContent]:
        """Dispatcher de ferramentas MCP do Jira."""
        try:
            if name == "jira_get_issue":
                return _handle_get_issue(client, arguments)
            elif name == "jira_create_issue":
                return _handle_create_issue(client, arguments)
            elif name == "jira_search":
                return _handle_search(client, arguments)
            elif name == "jira_update_issue":
                return _handle_update_issue(client, arguments)
            elif name == "jira_add_comment":
                return _handle_add_comment(client, arguments)
            elif name == "jira_list_issue_types":
                return _handle_list_issue_types(client, arguments)
            elif name == "jira_list_components":
                return _handle_list_components(client, arguments)
            elif name == "jira_list_field_options":
                return _handle_list_field_options(client, arguments)
            elif name == "jira_list_funcionalidades":
                return _handle_list_funcionalidades(client, arguments)
            elif name == "jira_list_attachments":
                return _handle_list_attachments(client, arguments)
            elif name == "jira_download_attachment":
                return _handle_download_attachment(client, arguments)
            else:
                raise ValueError(f"Ferramenta desconhecida: {name}")
        except JiraValidationError:
            raise
        except JiraAuthError as exc:
            raise JiraError(
                f"Erro de autenticação no Jira: {exc}"
            ) from exc
        except JiraError:
            raise
        except ValueError:
            raise
        except Exception as exc:
            logger.exception("Erro inesperado na ferramenta %s", name)
            raise RuntimeError(f"Erro inesperado: {exc}") from exc


def _handle_get_issue(
    client: JiraClient, arguments: dict
) -> list[TextContent]:
    """Handler para jira_get_issue."""
    issue_key = arguments.get("issueKey", "")
    if not issue_key:
        raise JiraValidationError("Campo obrigatório ausente: issueKey")
    result = client.get_issue(
        issue_key=issue_key,
        output_dir=arguments.get("outputDir"),
    )
    return _success_content(result)


def _handle_create_issue(
    client: JiraClient, arguments: dict
) -> list[TextContent]:
    """Handler para jira_create_issue."""
    required = ["projectKey", "summary", "description", "issueType"]
    missing = [f for f in required if not arguments.get(f)]
    if missing:
        raise JiraValidationError(
            f"Campos obrigatórios ausentes: {', '.join(missing)}"
        )

    result = client.create_issue(
        project_key=arguments["projectKey"],
        summary=arguments["summary"],
        description=arguments["description"],
        issue_type=arguments["issueType"],
        priority=arguments.get("priority"),
        labels=arguments.get("labels"),
        components=arguments.get("components"),
        custom_fields=arguments.get("customFields"),
    )
    return _success_content(result)


def _handle_search(
    client: JiraClient, arguments: dict
) -> list[TextContent]:
    """Handler para jira_search."""
    issues = client.search_issues(
        jql=arguments["jql"],
        max_results=arguments.get("maxResults", 50),
        fields=arguments.get("fields"),
    )

    results = []
    for issue in issues:
        fields = issue.get("fields", {})
        status_obj = fields.get("status", {})
        results.append(
            {
                "key": issue.get("key", ""),
                "summary": fields.get("summary", ""),
                "status": status_obj.get("name", "")
                if isinstance(status_obj, dict)
                else str(status_obj),
            }
        )
    return _success_content(results)


def _handle_update_issue(
    client: JiraClient, arguments: dict
) -> list[TextContent]:
    """Handler para jira_update_issue."""
    client.update_issue(
        issue_key=arguments["issueKey"],
        fields=arguments["fields"],
    )
    return _success_content(
        {"message": f"Issue {arguments['issueKey']} atualizada com sucesso"}
    )


def _handle_add_comment(
    client: JiraClient, arguments: dict
) -> list[TextContent]:
    """Handler para jira_add_comment."""
    result = client.add_comment(
        issue_key=arguments["issueKey"],
        body=arguments["body"],
    )
    return _success_content(
        {
            "message": f"Comentário adicionado à issue {arguments['issueKey']}",
            "id": result.get("id", ""),
        }
    )


def _handle_list_issue_types(
    client: JiraClient, arguments: dict
) -> list[TextContent]:
    """Handler para jira_list_issue_types."""
    result = client.list_issue_types(
        project_key=arguments.get("projectKey"),
    )
    return _success_content(result)


def _handle_list_components(
    client: JiraClient, arguments: dict
) -> list[TextContent]:
    """Handler para jira_list_components."""
    project_key = arguments.get("projectKey", "")
    if not project_key:
        raise JiraValidationError("Campo obrigatório ausente: projectKey")
    result = client.list_components(project_key=project_key)
    return _success_content(result)


def _handle_list_field_options(
    client: JiraClient, arguments: dict
) -> list[TextContent]:
    """Handler para jira_list_field_options."""
    required = ["projectKey", "issueTypeName", "fieldName"]
    missing = [f for f in required if not arguments.get(f)]
    if missing:
        raise JiraValidationError(
            f"Campos obrigatórios ausentes: {', '.join(missing)}"
        )
    result = client.list_custom_field_options(
        project_key=arguments["projectKey"],
        issue_type_name=arguments["issueTypeName"],
        field_name=arguments["fieldName"],
    )
    return _success_content(result)


def _handle_list_funcionalidades(
    client: JiraClient, arguments: dict
) -> list[TextContent]:
    """Handler para jira_list_funcionalidades."""
    required = ["projectKey", "issueTypeName"]
    missing = [f for f in required if not arguments.get(f)]
    if missing:
        raise JiraValidationError(
            f"Campos obrigatórios ausentes: {', '.join(missing)}"
        )
    result = client.list_custom_field_options(
        project_key=arguments["projectKey"],
        issue_type_name=arguments["issueTypeName"],
        field_name="Funcionalidade",
    )
    return _success_content(result)


def _handle_list_attachments(
    client: JiraClient, arguments: dict
) -> list[TextContent]:
    """Handler para jira_list_attachments."""
    issue_key = arguments.get("issueKey", "")
    if not issue_key:
        raise JiraValidationError("Campo obrigatório ausente: issueKey")
    result = client.list_attachments(issue_key=issue_key)
    return _success_content(result)


def _handle_download_attachment(
    client: JiraClient, arguments: dict
) -> list[TextContent]:
    """Handler para jira_download_attachment."""
    issue_key = arguments.get("issueKey", "")
    if not issue_key:
        raise JiraValidationError("Campo obrigatório ausente: issueKey")
    result = client.download_attachment(
        issue_key=issue_key,
        attachment_id=arguments.get("attachmentId"),
        output_dir=arguments.get("outputDir"),
    )
    if not result:
        return _success_content({"message": f"Nenhum anexo encontrado na issue {issue_key}"})
    return _success_content(result)
