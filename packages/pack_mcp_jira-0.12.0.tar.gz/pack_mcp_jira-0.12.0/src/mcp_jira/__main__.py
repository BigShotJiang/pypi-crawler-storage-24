"""Permite executar o MCP Server do Jira com `python -m mcp_jira`."""

import asyncio
import logging
import os
import sys

from mcp_jira.server import main

if __name__ == "__main__":
    if os.name == "nt":
        sys.stdin.reconfigure(encoding="utf-8")
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    logging.basicConfig(level=logging.INFO, stream=sys.stderr)
    asyncio.run(main())
