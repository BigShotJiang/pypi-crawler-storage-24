# pack-mcp-jira

MCP Server para criação e gestão de tickets no Jira via Basic Auth (REST API v2).

## Variáveis de ambiente

| Variável | Descrição |
|---|---|
| `JIRA_URL` | URL base do Jira (ex: `https://jira.sua-empresa.com`) |
| `JIRA_TOKEN` | Token Basic Auth em base64 |

## Ferramentas disponíveis

| Ferramenta | Descrição |
|---|---|
| `jira_get_issue` | Busca detalhes de uma issue pelo key |
| `jira_create_issue` | Cria um novo ticket (suporta campos customizados via `customFields`) |
| `jira_search` | Consulta tickets via JQL |
| `jira_update_issue` | Atualiza campos de um ticket |
| `jira_add_comment` | Adiciona comentário a um ticket |
| `jira_list_issue_types` | Lista tipos de issue disponíveis em um projeto |
| `jira_list_components` | Lista componentes de um projeto |
| `jira_list_funcionalidades` | Lista funcionalidades disponíveis para um projeto e tipo de issue |
| `jira_list_field_options` | Lista opções de qualquer campo customizado (ex: Funcionalidade, Tipo de Erro) |
| `jira_list_attachments` | Lista os anexos de uma issue (id, nome, tamanho, tipo) |
| `jira_download_attachment` | Baixa anexo(s) de uma issue para um diretório local |

### Fluxo recomendado para criar issues

1. Use `jira_list_issue_types` para obter os tipos válidos do projeto
2. Use `jira_list_funcionalidades` para obter as funcionalidades disponíveis
3. Use `jira_create_issue` passando `issueType`, e campos customizados via `customFields` (ex: `{"Funcionalidade": "DASHBOARD"}`)

## Instalação

```bash
pip install pack-mcp-jira
```

## Configuração MCP

```json
{
  "mcpServers": {
    "jira": {
      "command": "pack-mcp-jira",
      "env": {
        "JIRA_URL": "https://jira.sua-empresa.com",
        "JIRA_TOKEN": "seu_token_base64"
      }
    }
  }
}
```
