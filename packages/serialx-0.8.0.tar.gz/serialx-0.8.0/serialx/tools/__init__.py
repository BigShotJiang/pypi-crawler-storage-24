"""Pyserial compatibility module."""
