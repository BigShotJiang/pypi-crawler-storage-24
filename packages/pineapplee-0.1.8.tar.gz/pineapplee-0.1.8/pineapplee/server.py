"""pineapplee.server — Pineapple File Server core."""

from flask import (Flask, request, send_from_directory,
                   render_template_string, jsonify, abort, Response)
from werkzeug.utils import secure_filename
import os, sys, shutil, zipfile, mimetypes, unicodedata, gzip, io, time, threading
from datetime import datetime

# ── App ─────────────────────────────────────────────────────────
app = Flask(__name__)

@app.after_request
def _compress(response):
    """Gzip JSON/text responses automatically (skip streaming responses)."""
    if (response.direct_passthrough
            or response.is_streamed
            or 'gzip' not in request.headers.get('Accept-Encoding', '')
            or response.status_code < 200 or response.status_code >= 300
            or response.content_encoding):
        return response
    ct = response.content_type or ''
    if not ('application/json' in ct or 'text/' in ct):
        return response
    data = response.get_data()
    if len(data) < 256:
        return response
    compressed = gzip.compress(data, compresslevel=4)
    if len(compressed) >= len(data):
        return response
    response.set_data(compressed)
    response.headers['Content-Encoding'] = 'gzip'
    response.headers['Content-Length'] = len(compressed)
    response.headers['Vary'] = 'Accept-Encoding'
    return response

# ── Runtime globals (set by main() before server starts) ────────
BASE_DIR   = None   # absolute, normalised
_BASE_REAL = None   # realpath (resolves symlinks)

MAX_UPLOAD_MB = 500

HIDDEN = {'__pycache__', 'node_modules', 'env', 'venv', 'dist'}

def _is_hidden(name):
    return (name.startswith('.')
            or name in HIDDEN
            or name.endswith('.egg-info'))

# ── Path helpers ─────────────────────────────────────────────────
def _under_base(p):
    rp = os.path.realpath(p)
    return rp == _BASE_REAL or rp.startswith(_BASE_REAL + os.sep)

def safe_path(rel):
    if not rel:
        return BASE_DIR
    # macOS uses NFD unicode for filenames; normalise to NFC then try NFD fallback
    rel = unicodedata.normalize('NFC', rel)
    joined = os.path.normpath(os.path.join(BASE_DIR, rel))
    if not os.path.exists(joined):
        joined_nfd = os.path.normpath(os.path.join(BASE_DIR, unicodedata.normalize('NFD', rel)))
        if os.path.exists(joined_nfd):
            joined = joined_nfd
    if not (joined == BASE_DIR or joined.startswith(BASE_DIR + os.sep)):
        abort(403)
    if not _under_base(joined):
        abort(403)
    return joined

def unique_name(d, n):
    if not os.path.exists(os.path.join(d, n)):
        return n
    stem, ext = os.path.splitext(n)
    for c in range(1, 10000):
        candidate = f"{stem} ({c}){ext}"
        if not os.path.exists(os.path.join(d, candidate)):
            return candidate
    return f"{stem}_{int(time.time() * 1000)}{ext}"

# ── File metadata ────────────────────────────────────────────────
ICONS = {
    '.py':'🐍','.js':'📜','.ts':'📜','.html':'🌐','.css':'🎨',
    '.json':'📋','.xml':'📋','.yaml':'📋','.yml':'📋','.toml':'📋',
    '.md':'📝','.txt':'📝','.log':'📝','.csv':'📊',
    '.pdf':'📕','.doc':'📘','.docx':'📘','.xls':'📗','.xlsx':'📗',
    '.ppt':'📙','.pptx':'📙',
    '.jpg':'🖼️','.jpeg':'🖼️','.png':'🖼️','.gif':'🖼️',
    '.svg':'🖼️','.bmp':'🖼️','.webp':'🖼️','.ico':'🖼️',
    '.mp4':'🎬','.avi':'🎬','.mov':'🎬','.mkv':'🎬','.webm':'🎬',
    '.mp3':'🎵','.wav':'🎵','.flac':'🎵','.aac':'🎵','.ogg':'🎵',
    '.zip':'📦','.tar':'📦','.gz':'📦','.rar':'📦','.7z':'📦',
    '.sh':'⚙️','.bat':'⚙️','.exe':'⚙️',
    '.java':'☕','.c':'⚙️','.cpp':'⚙️','.h':'⚙️',
    '.rb':'💎','.go':'🔵','.rs':'🦀','.swift':'🧡',
    '.sql':'🗃️','.db':'🗃️','.sqlite':'🗃️',
}
IMG_EXT = {'.jpg','.jpeg','.png','.gif','.svg','.bmp','.webp','.ico'}
VID_EXT = {'.mp4','.avi','.mov','.mkv','.webm','.ogv'}
AUD_EXT = {'.mp3','.wav','.flac','.aac','.ogg','.m4a'}
TXT_EXT = {'.txt','.md','.py','.js','.ts','.jsx','.tsx','.html','.css',
           '.json','.xml','.yaml','.yml','.toml','.cfg','.ini','.env',
           '.sh','.bat','.java','.c','.cpp','.h','.rb','.go','.rs',
           '.swift','.sql','.log','.csv','.gitignore','.vue','.svelte',
           '.php','.pl','.lua','.r','.m','.kt','.dart','.ex','.erl'}

def finfo(name, is_dir):
    ext = os.path.splitext(name)[1].lower()
    icon = '📁' if is_dir else ICONS.get(ext, '📄')
    if is_dir:           pt = 'folder'
    elif ext in IMG_EXT: pt = 'image'
    elif ext in VID_EXT: pt = 'video'
    elif ext in AUD_EXT: pt = 'audio'
    elif ext == '.pdf':  pt = 'pdf'
    elif ext in TXT_EXT: pt = 'text'
    else:                pt = 'other'
    return icon, pt

def human_size(n):
    for u in ('B','KB','MB','GB','TB'):
        if n < 1024:
            return f"{n:.0f} {u}" if u == 'B' else f"{n:.1f} {u}"
        n /= 1024
    return f"{n:.1f} PB"

def _raw_dir_size(path):
    """Recursive size using os.scandir (fastest stdlib approach)."""
    total = 0
    try:
        with os.scandir(path) as it:
            for e in it:
                try:
                    if e.is_file(follow_symlinks=False):
                        total += e.stat(follow_symlinks=False).st_size
                    elif e.is_dir(follow_symlinks=False):
                        total += _raw_dir_size(e.path)
                except (PermissionError, OSError):
                    pass
    except (PermissionError, OSError):
        pass
    return total

class _DirSizeCache:
    """Non-blocking TTL cache for directory sizes with background computation."""
    def __init__(self, ttl=60):
        self._cache = {}        # path -> (size, timestamp)
        self._computing = set() # paths currently being computed
        self._lock = threading.Lock()
        self._ttl = ttl

    def get_cached(self, path):
        """Return cached size or None if not available yet."""
        with self._lock:
            cached = self._cache.get(path)
            if cached and (time.monotonic() - cached[1]) < self._ttl:
                return cached[0]
        return None

    def get(self, path):
        """Return cached size, computing synchronously if needed (used by ZIP)."""
        cached = self.get_cached(path)
        if cached is not None:
            return cached
        sz = _raw_dir_size(path)
        with self._lock:
            self._cache[path] = (sz, time.monotonic())
        return sz

    def request_sizes(self, paths):
        """Return available sizes and start background computation for the rest."""
        result = {}
        to_compute = []
        with self._lock:
            now = time.monotonic()
            for p in paths:
                cached = self._cache.get(p)
                if cached and (now - cached[1]) < self._ttl:
                    result[p] = cached[0]
                elif p not in self._computing:
                    to_compute.append(p)
                    self._computing.add(p)
        # Fire background threads for uncached sizes
        for p in to_compute:
            t = threading.Thread(target=self._compute, args=(p,), daemon=True)
            t.start()
        return result

    def _compute(self, path):
        """Compute size in background thread and cache it."""
        try:
            sz = _raw_dir_size(path)
            with self._lock:
                self._cache[path] = (sz, time.monotonic())
        finally:
            with self._lock:
                self._computing.discard(path)

    def invalidate(self, path):
        """Bust cache for a path and all its parents up to BASE_DIR."""
        with self._lock:
            self._cache.pop(path, None)
            parent = os.path.dirname(path)
            while parent and parent != os.path.dirname(parent):
                self._cache.pop(parent, None)
                if parent == BASE_DIR:
                    break
                parent = os.path.dirname(parent)

_dir_cache = _DirSizeCache(ttl=30)

class _ScanCache:
    """Caches full directory scans, invalidated by dir mtime."""
    def __init__(self):
        self._cache = {}   # path -> (dir_mtime, entries)

    def get(self, path):
        try:
            dmtime = os.stat(path).st_mtime
        except OSError:
            dmtime = None
        cached = self._cache.get(path)
        if cached and cached[0] == dmtime:
            return cached[1]
        entries = self._scan(path)
        if entries is not None:
            self._cache[path] = (dmtime, entries)
        return entries

    def invalidate(self, path):
        self._cache.pop(path, None)

    @staticmethod
    def _scan(path):
        items = []
        try:
            with os.scandir(path) as it:
                for e in it:
                    if _is_hidden(e.name):
                        continue
                    try:
                        if e.is_symlink():
                            if not os.path.realpath(e.path).startswith(_BASE_REAL):
                                continue
                        isd = e.is_dir(follow_symlinks=False)
                        st = e.stat(follow_symlinks=False)
                        items.append(dict(
                            name=e.name, is_dir=isd,
                            size=st.st_size if not isd else -1,
                            mtime=st.st_mtime,
                        ))
                    except (PermissionError, OSError):
                        continue
        except PermissionError:
            return None
        return items

_scan_cache = _ScanCache()

PER_PAGE = 100

def _enrich(item):
    """Add display fields to a raw scan entry."""
    ic, pt = finfo(item['name'], item['is_dir'])
    sz = item['size']
    item['icon'] = ic
    item['preview'] = pt
    item['size_h'] = human_size(sz) if not item['is_dir'] else ''
    item['mtime_h'] = datetime.fromtimestamp(item['mtime']).strftime('%d %b %Y %H:%M')
    return item

# ── HTML Template ────────────────────────────────────────────────
TEMPLATE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Pineapple</title>
<link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🍍</text></svg>">
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{
  --bg:#f4f5f7;--surface:#fff;--border:#e5e7eb;--border-lt:#f3f4f6;
  --tx:#111827;--tx2:#6b7280;--tx3:#9ca3af;
  --blue:#2563eb;--blue-h:#1d4ed8;--blue-lt:#eff6ff;
  --red:#dc2626;--red-lt:#fef2f2;
  --green:#059669;--green-lt:#ecfdf5;
  --r:8px;--rl:12px;
}
html{height:100%}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',system-ui,sans-serif;
  background:var(--bg);color:var(--tx);min-height:100%;font-size:14px}
a{color:var(--blue);text-decoration:none}
a:hover{text-decoration:underline}
.hdr{background:var(--surface);border-bottom:1px solid var(--border);
  padding:14px 24px 10px;position:sticky;top:0;z-index:100}
.hdr-top{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
.logo{font-size:19px;font-weight:700;letter-spacing:-.3px;display:flex;align-items:center;gap:6px}
.logo span{font-size:22px}
.hdr-actions{display:flex;gap:6px;flex-wrap:wrap}
.crumbs{display:flex;align-items:center;gap:2px;margin-top:8px;font-size:13px;color:var(--tx2);flex-wrap:wrap}
.crumbs a{padding:2px 6px;border-radius:4px;cursor:pointer}
.crumbs a:hover{background:var(--blue-lt);text-decoration:none}
.crumbs .sep{color:var(--tx3);margin:0 2px;user-select:none}
.btn{display:inline-flex;align-items:center;gap:5px;padding:6px 14px;border-radius:var(--r);
  border:1px solid var(--border);background:var(--surface);color:var(--tx);font-size:13px;
  cursor:pointer;transition:all .15s;font-family:inherit;white-space:nowrap}
.btn:hover{background:var(--bg);border-color:var(--tx3)}
.btn-p{background:var(--blue);color:#fff;border-color:var(--blue)}
.btn-p:hover{background:var(--blue-h);border-color:var(--blue-h)}
.main{max-width:1200px;margin:0 auto;padding:0 24px 120px}
.ft{background:var(--surface);border-radius:var(--rl);border:1px solid var(--border);
  margin-top:16px;overflow:hidden}
.fr{display:grid;grid-template-columns:40px 34px 1fr 82px 130px 90px;
  align-items:center;padding:0 16px;min-height:42px;border-bottom:1px solid var(--border-lt);
  transition:background .1s;cursor:default}
.fr:last-child{border-bottom:none}
.fr:not(.fh):hover{background:#f8fafc}
.fr.sel{background:var(--blue-lt)}
.fh{background:#f9fafb;font-weight:600;font-size:11px;color:var(--tx2);
  text-transform:uppercase;letter-spacing:.04em;min-height:36px;cursor:default}
.fr .ico{font-size:18px;text-align:center;line-height:1}
.fr .nm{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;cursor:pointer}
.fr .nm.dir{font-weight:500}
.fr .sz,.fr .dt{font-size:13px;color:var(--tx2)}
.fr .sz{text-align:right;font-variant-numeric:tabular-nums}
.fr .acts{display:flex;gap:2px;justify-content:flex-end}
.fr:not(.fh) .acts{opacity:0;transition:opacity .15s}
.fr:not(.fh):hover .acts,.fr.sel .acts{opacity:1}
.ab{width:28px;height:28px;border:none;background:none;border-radius:6px;
  cursor:pointer;font-size:14px;display:flex;align-items:center;justify-content:center;
  color:var(--tx2);transition:background .1s}
.ab:hover{background:var(--border)}
.fr.parent-row{color:var(--tx2);font-size:13px;cursor:pointer}
.fr.parent-row:hover{background:var(--blue-lt)}
.sortable{cursor:pointer;user-select:none}
.sortable:hover{color:var(--tx)}
input[type=checkbox]{width:15px;height:15px;cursor:pointer;accent-color:var(--blue)}
.empty{text-align:center;padding:60px 20px;color:var(--tx2)}
.empty .big{font-size:48px;margin-bottom:12px}
.empty .sub{font-size:13px;color:var(--tx3);margin-top:4px}
.spinner{width:28px;height:28px;border:3px solid var(--border);border-top-color:var(--blue);
  border-radius:50%;animation:spin .6s linear infinite;margin:60px auto}
@keyframes spin{to{transform:rotate(360deg)}}
.selbar{position:fixed;bottom:20px;left:50%;transform:translateX(-50%);
  background:#1e293b;color:#fff;padding:10px 12px 10px 18px;border-radius:var(--rl);
  display:flex;align-items:center;gap:10px;box-shadow:0 8px 30px rgba(0,0,0,.22);
  font-size:13px;z-index:200;white-space:nowrap}
.selbar button{background:rgba(255,255,255,.13);color:#fff;border:none;padding:6px 12px;
  border-radius:6px;cursor:pointer;font-size:13px;font-family:inherit;transition:background .15s}
.selbar button:hover{background:rgba(255,255,255,.25)}
.selbar .dng{background:rgba(220,38,38,.6)}
.selbar .dng:hover{background:rgba(220,38,38,.8)}
.selbar .clr{background:none;font-size:16px;padding:4px 8px;opacity:.6}
.selbar .clr:hover{opacity:1}
.modal-bg{position:fixed;inset:0;background:rgba(0,0,0,.55);backdrop-filter:blur(4px);z-index:300}
.modal-box{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);
  background:var(--surface);border-radius:16px;z-index:301;
  box-shadow:0 20px 60px rgba(0,0,0,.3);max-width:92vw;max-height:92vh;
  display:flex;flex-direction:column;min-width:340px}
.modal-hdr{display:flex;justify-content:space-between;align-items:center;
  padding:14px 18px;border-bottom:1px solid var(--border);font-weight:600;font-size:14px}
.modal-hdr button{background:none;border:none;font-size:20px;cursor:pointer;
  color:var(--tx2);padding:2px 6px;border-radius:4px}
.modal-hdr button:hover{background:var(--bg)}
.modal-body{padding:18px;overflow:auto;max-height:80vh;display:flex;align-items:center;justify-content:center}
.modal-body img{max-width:100%;max-height:75vh;border-radius:8px}
.modal-body video{max-width:100%;max-height:75vh;border-radius:8px}
.modal-body audio{min-width:320px}
.modal-body iframe{width:75vw;height:78vh;border:none;border-radius:8px}
.modal-body pre{text-align:left;width:100%;max-height:75vh;overflow:auto;
  background:#f8f9fa;padding:16px;border-radius:8px;font-size:13px;line-height:1.5;
  font-family:'SF Mono',Menlo,Monaco,Consolas,monospace;white-space:pre-wrap;word-break:break-word}
.preview-msg{text-align:center;padding:40px;color:var(--tx2)}
.preview-msg .big{font-size:48px;margin-bottom:12px}
.drop-ov{position:fixed;inset:0;background:rgba(37,99,235,.08);
  border:3px dashed var(--blue);z-index:400;display:flex;align-items:center;
  justify-content:center;pointer-events:none}
.drop-ov div{text-align:center;color:var(--blue)}
.drop-ov .di{font-size:52px}
.drop-ov p{font-size:17px;font-weight:600;margin-top:8px}
.up-toast{position:fixed;top:20px;right:20px;background:var(--surface);
  border-radius:var(--rl);padding:14px 18px;box-shadow:0 4px 20px rgba(0,0,0,.15);
  z-index:250;min-width:280px;font-size:13px}
.up-info{display:flex;justify-content:space-between;margin-bottom:8px;font-weight:500}
.pbar{height:6px;background:var(--border);border-radius:3px;overflow:hidden}
.pfill{height:100%;background:var(--blue);border-radius:3px;transition:width .25s;width:0}
.toast-box{position:fixed;top:16px;right:16px;z-index:500;display:flex;flex-direction:column;gap:8px}
.toast{padding:10px 16px;border-radius:var(--r);font-size:13px;
  transform:translateX(120%);transition:transform .3s;
  box-shadow:0 2px 10px rgba(0,0,0,.1);max-width:340px}
.toast.show{transform:translateX(0)}
.toast-ok{background:var(--green-lt);color:#065f46;border:1px solid #6ee7b7}
.toast-err{background:var(--red-lt);color:#991b1b;border:1px solid #fca5a5}
.toast-info{background:var(--blue-lt);color:#1e40af;border:1px solid #93c5fd}
.pager{display:flex;align-items:center;justify-content:center;gap:6px;padding:12px 0;font-size:13px;color:var(--tx2)}
.pager button{background:var(--surface);border:1px solid var(--border);border-radius:6px;padding:5px 11px;
  cursor:pointer;font-size:13px;font-family:inherit;color:var(--tx);transition:background .15s}
.pager button:hover:not(:disabled){background:var(--blue-lt)}
.pager button:disabled{opacity:.35;cursor:default}
.pager button.active{background:var(--blue);color:#fff;border-color:var(--blue)}
.pager span{padding:0 4px}
@media(max-width:700px){
  .fr{grid-template-columns:36px 30px 1fr 80px}
  .sz,.dt{display:none}
  .fh .sz,.fh .dt{display:none}
  .main{padding:0 12px 120px}
  .hdr{padding:12px 14px 8px}
  .hdr-top{gap:8px}
}
</style>
</head>
<body>

<header class="hdr">
  <div class="hdr-top">
    <div class="logo"><span>🍍</span> Pineapple</div>
    <div class="hdr-actions">
      <button class="btn" id="btnNewFolder">+ Folder</button>
      <button class="btn btn-p" id="btnUpload">↑ Upload</button>
      <button class="btn" id="btnUploadDir">↑ Folder</button>
    </div>
  </div>
  <nav class="crumbs" id="crumbs"></nav>
</header>

<main class="main">
  <div class="ft" id="ft">
    <div class="fr fh">
      <div><input type="checkbox" id="sa"></div>
      <div></div>
      <div class="sortable" id="sortName">Name <span id="sn">↑</span></div>
      <div class="sortable sz" id="sortSize">Size <span id="ss"></span></div>
      <div class="sortable dt" id="sortDate">Date <span id="sd"></span></div>
      <div></div>
    </div>
    <div id="fl"></div>
    <div id="pager" class="pager" style="display:none"></div>
  </div>
  <div id="empty" class="empty" style="display:none">
    <div class="big">📂</div><p>This folder is empty</p>
    <p class="sub">Drop files here or click Upload</p>
  </div>
  <div id="loading" style="display:none"><div class="spinner"></div></div>
</main>

<div id="selbar" class="selbar" style="display:none">
  <span id="selcnt"></span>
  <button id="btnDlZip">📦 ZIP</button>
  <button id="btnDlEach">⬇ Download</button>
  <button class="dng" id="btnDelSel">🗑 Delete</button>
  <button class="clr" id="btnClearSel">✕</button>
</div>

<div id="modal" style="display:none">
  <div class="modal-bg" id="modalBg"></div>
  <div class="modal-box">
    <div class="modal-hdr"><span id="pvtitle"></span><button id="modalClose">✕</button></div>
    <div class="modal-body" id="pvbody"></div>
  </div>
</div>

<div id="dropov" class="drop-ov" style="display:none">
  <div><div class="di">📥</div><p>Drop files to upload</p></div>
</div>

<div id="uptoast" class="up-toast" style="display:none">
  <div class="up-info"><span>Uploading…</span><span id="uppct">0%</span></div>
  <div class="pbar"><div class="pfill" id="pfill"></div></div>
</div>

<div id="toasts" class="toast-box"></div>

<input type="file" id="fi" multiple style="display:none">
<input type="file" id="di" webkitdirectory style="display:none">

<script>
const INIT_PATH = {{ current_path | tojson }};

const App = {
  path: '',
  items: [],
  sel: new Set(),
  sortBy: 'name',
  sortDir: 'asc',
  page: 1,
  pages: 1,
  total: 0,
  dragC: 0,
  _sizeCtrl: null,
  _sizeTimer: null,

  init() {
    this.path = INIT_PATH;
    window.addEventListener('popstate', e => {
      this.path = (e.state && e.state.p) || '';
      this.page = 1;
      this.load();
    });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') this.closePv(); });

    document.getElementById('btnNewFolder').addEventListener('click', () => this.createFolder());
    document.getElementById('btnUpload').addEventListener('click', () => document.getElementById('fi').click());
    document.getElementById('btnUploadDir').addEventListener('click', () => document.getElementById('di').click());
    document.getElementById('fi').addEventListener('change', e => { this.upload(Array.from(e.target.files), false); e.target.value=''; });
    document.getElementById('di').addEventListener('change', e => {
      const files = Array.from(e.target.files);
      files.forEach(f => { f._rp = f.webkitRelativePath || f.name; });
      this.upload(files, true); e.target.value='';
    });
    document.getElementById('sa').addEventListener('change', e => this.selAll(e.target.checked));
    document.getElementById('sortName').addEventListener('click', () => this.sort('name'));
    document.getElementById('sortSize').addEventListener('click', () => this.sort('size'));
    document.getElementById('sortDate').addEventListener('click', () => this.sort('date'));
    document.getElementById('btnDlZip').addEventListener('click', () => this.dlZip());
    document.getElementById('btnDlEach').addEventListener('click', () => this.dlEach());
    document.getElementById('btnDelSel').addEventListener('click', () => this.delSel());
    document.getElementById('btnClearSel').addEventListener('click', () => this.clearSel());
    document.getElementById('modalBg').addEventListener('click', () => this.closePv());
    document.getElementById('modalClose').addEventListener('click', () => this.closePv());

    this.initDrag();
    this.load();
  },

  nav(p) {
    this.path = p;
    this.page = 1;
    if (this._sizeTimer) { clearTimeout(this._sizeTimer); this._sizeTimer = null; }
    history.pushState({p}, '', p ? '/browse/' + p : '/');
    this.load();
  },

  // Silent background refresh — no spinner, preserves scroll & selection
  async refresh() {
    const sort = `sort=${this.sortBy}&dir=${this.sortDir}&page=${this.page}`;
    const url = this.path ? `/api/list/${this.epath(this.path)}?${sort}` : `/api/list?${sort}`;
    try {
      const r = await fetch(url);
      if (!r.ok) return;
      const d = await r.json();
      this.items = d.items;
      this.page = d.page;
      this.pages = d.pages;
      this.total = d.total;
      // Drop selections for items that no longer exist
      const live = new Set(d.items.map(i => this.fp(i.name)));
      this.sel = new Set([...this.sel].filter(p => live.has(p)));
      this.renderItems();
      this.renderPager();
      this.fetchDirSizes();
      this.updBar();
    } catch(e) {}
  },

  async fetchDirSizes(retries) {
    // Cancel any in-flight sizes request (e.g. user navigated away)
    if (this._sizeCtrl) this._sizeCtrl.abort();
    if (this._sizeTimer) { clearTimeout(this._sizeTimer); this._sizeTimer = null; }
    const dirs = this.items.filter(i => i.is_dir && !i.size_h).map(i => i.name);
    if (!dirs.length) return;
    const ctrl = new AbortController();
    this._sizeCtrl = ctrl;
    const url = this.path ? `/api/sizes/${this.epath(this.path)}` : '/api/sizes';
    const attempt = retries || 0;
    try {
      const r = await fetch(url, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(dirs),
        signal: ctrl.signal
      });
      if (!r.ok) return;
      const d = await r.json();
      if (ctrl.signal.aborted) return;
      const sizes = d.sizes || {};
      // Update items that got sizes back
      this.items.forEach(it => {
        if (it.is_dir && sizes[it.name]) {
          it.size = sizes[it.name].size;
          it.size_h = sizes[it.name].size_h;
        }
      });
      // Update size cells in-place without re-rendering
      document.querySelectorAll('.fr[data-path]').forEach(row => {
        const p = row.dataset.path;
        const it = this.items.find(i => this.fp(i.name) === p);
        if (it && it.is_dir && it.size_h) {
          const sz = row.querySelector('.sz');
          if (sz) sz.textContent = it.size_h;
        }
      });
      // If some sizes are still computing in background, poll again
      if (d.pending > 0 && attempt < 15) {
        const delay = Math.min(1000 + attempt * 500, 4000);
        this._sizeTimer = setTimeout(() => this.fetchDirSizes(attempt + 1), delay);
      }
    } catch(e) {
      if (e.name === 'AbortError') return;
    }
  },

  async load() {
    const fl = document.getElementById('fl');
    const em = document.getElementById('empty');
    const ld = document.getElementById('loading');
    fl.innerHTML = ''; em.style.display = 'none'; ld.style.display = '';
    document.getElementById('pager').style.display = 'none';
    this.sel.clear(); this.updBar();

    const sort = `sort=${this.sortBy}&dir=${this.sortDir}&page=${this.page}`;
    const url = this.path ? `/api/list/${this.epath(this.path)}?${sort}` : `/api/list?${sort}`;
    try {
      const r = await fetch(url);
      if (!r.ok) throw new Error('Failed to load');
      const d = await r.json();
      this.items = d.items;
      this.page = d.page;
      this.pages = d.pages;
      this.total = d.total;
      this.renderCrumbs(d.breadcrumbs);
      this.renderItems();
      this.renderPager();
      this.fetchDirSizes();
    } catch(e) {
      this.toast('Error loading directory', 'err');
    }
    ld.style.display = 'none';
  },

  renderCrumbs(bc) {
    const c = document.getElementById('crumbs');
    c.innerHTML = '';
    bc.forEach((b, i) => {
      if (i > 0) {
        const sep = document.createElement('span');
        sep.className = 'sep'; sep.textContent = '/';
        c.appendChild(sep);
      }
      const a = document.createElement('a');
      a.textContent = i === 0 ? '🏠 Home' : b.name;
      a.addEventListener('click', e => { e.preventDefault(); this.nav(b.path); });
      c.appendChild(a);
    });
  },

  renderItems() {
    const fl = document.getElementById('fl');
    const em = document.getElementById('empty');
    fl.innerHTML = '';

    if (this.path) {
      const pp = this.path.split('/').slice(0,-1).join('/');
      const row = document.createElement('div');
      row.className = 'fr parent-row';
      row.innerHTML = '<div></div><div class="ico">⬆️</div><div class="nm">..</div><div class="sz"></div><div class="dt"></div><div></div>';
      row.addEventListener('click', () => this.nav(pp));
      fl.appendChild(row);
    }

    if (!this.items.length) {
      em.style.display = '';
    } else {
      em.style.display = 'none';
      this.items.forEach(it => {
        const fp = this.fp(it.name);
        const row = document.createElement('div');
        row.className = 'fr' + (this.sel.has(fp) ? ' sel' : '');
        row.dataset.path = fp;

        // checkbox
        const cbCell = document.createElement('div');
        const cb = document.createElement('input');
        cb.type = 'checkbox'; cb.checked = this.sel.has(fp);
        cb.addEventListener('click', e => { e.stopPropagation(); this.toggle(fp); });
        cbCell.appendChild(cb);

        // icon
        const icoCell = document.createElement('div');
        icoCell.className = 'ico'; icoCell.textContent = it.icon;

        // name
        const nmCell = document.createElement('div');
        nmCell.className = 'nm' + (it.is_dir ? ' dir' : '');
        nmCell.textContent = it.name;
        nmCell.addEventListener('click', () => this.click(it.is_dir, fp, it.name, it.preview, it.size));

        // size
        const szCell = document.createElement('div');
        szCell.className = 'sz'; szCell.textContent = it.size_h || (it.is_dir ? '…' : '');

        // date
        const dtCell = document.createElement('div');
        dtCell.className = 'dt'; dtCell.textContent = it.mtime_h;

        // actions
        const actsCell = document.createElement('div');
        actsCell.className = 'acts';
        if (!it.is_dir) {
          const btnPv = document.createElement('button');
          btnPv.className = 'ab'; btnPv.title = 'Preview'; btnPv.textContent = '👁';
          btnPv.addEventListener('click', e => { e.stopPropagation(); this.openPv(it.name, it.preview, it.size); });
          actsCell.appendChild(btnPv);
        }
        const btnDl = document.createElement('button');
        btnDl.className = 'ab'; btnDl.title = 'Download'; btnDl.textContent = '⬇';
        btnDl.addEventListener('click', e => { e.stopPropagation(); this.dl1(fp, it.name, it.is_dir); });

        const btnRn = document.createElement('button');
        btnRn.className = 'ab'; btnRn.title = 'Rename'; btnRn.textContent = '✏️';
        btnRn.addEventListener('click', e => { e.stopPropagation(); this.ren(fp, it.name); });

        const btnDel = document.createElement('button');
        btnDel.className = 'ab'; btnDel.title = 'Delete'; btnDel.textContent = '🗑';
        btnDel.addEventListener('click', e => { e.stopPropagation(); this.del1(fp, it.name); });

        actsCell.append(btnDl, btnRn, btnDel);
        row.append(cbCell, icoCell, nmCell, szCell, dtCell, actsCell);
        fl.appendChild(row);
      });
    }
  },

  click(isDir, fp, name, ptype, size) {
    if (isDir) this.nav(fp);
    else this.openPv(name, ptype, size);
  },

  toggle(fp) {
    if (this.sel.has(fp)) this.sel.delete(fp); else this.sel.add(fp);
    const rows = document.querySelectorAll(`.fr[data-path="${CSS.escape(fp)}"]`);
    rows.forEach(r => {
      const cb = r.querySelector('input[type=checkbox]');
      if (this.sel.has(fp)) { r.classList.add('sel'); if(cb) cb.checked = true; }
      else { r.classList.remove('sel'); if(cb) cb.checked = false; }
    });
    this.updBar();
  },

  selAll(checked) {
    if (checked) this.items.forEach(it => this.sel.add(this.fp(it.name)));
    else this.sel.clear();
    this.renderItems(); this.updBar();
  },

  clearSel() {
    this.sel.clear();
    const sa = document.getElementById('sa');
    sa.checked = false; sa.indeterminate = false;
    this.renderItems(); this.updBar();
  },

  updBar() {
    const bar = document.getElementById('selbar');
    const sa  = document.getElementById('sa');
    if (this.sel.size === 0) {
      bar.style.display = 'none';
      sa.checked = false; sa.indeterminate = false;
    } else {
      bar.style.display = 'flex';
      document.getElementById('selcnt').textContent = this.sel.size + ' selected';
      if (this.sel.size === this.items.length) { sa.checked = true; sa.indeterminate = false; }
      else { sa.checked = false; sa.indeterminate = true; }
    }
  },

  renderPager() {
    const pg = document.getElementById('pager');
    pg.innerHTML = '';
    if (this.pages <= 1) { pg.style.display = 'none'; return; }
    pg.style.display = 'flex';

    const info = document.createElement('span');
    info.textContent = `${this.total} items`;
    pg.appendChild(info);

    const prev = document.createElement('button');
    prev.textContent = '‹ Prev';
    prev.disabled = this.page <= 1;
    prev.addEventListener('click', () => this.goPage(this.page - 1));
    pg.appendChild(prev);

    // Show page numbers: first, last, and around current
    const show = new Set([1, this.pages]);
    for (let i = Math.max(1, this.page - 2); i <= Math.min(this.pages, this.page + 2); i++) show.add(i);
    const nums = Array.from(show).sort((a,b) => a - b);
    let last = 0;
    nums.forEach(n => {
      if (n - last > 1) {
        const dots = document.createElement('span');
        dots.textContent = '…';
        pg.appendChild(dots);
      }
      const btn = document.createElement('button');
      btn.textContent = n;
      if (n === this.page) btn.className = 'active';
      btn.addEventListener('click', () => this.goPage(n));
      pg.appendChild(btn);
      last = n;
    });

    const next = document.createElement('button');
    next.textContent = 'Next ›';
    next.disabled = this.page >= this.pages;
    next.addEventListener('click', () => this.goPage(this.page + 1));
    pg.appendChild(next);
  },

  goPage(n) {
    if (n < 1 || n > this.pages || n === this.page) return;
    this.page = n;
    this.load();
    window.scrollTo({top: 0, behavior: 'smooth'});
  },

  sort(by) {
    if (this.sortBy === by) this.sortDir = this.sortDir === 'asc' ? 'desc' : 'asc';
    else { this.sortBy = by; this.sortDir = 'asc'; }
    document.getElementById('sn').textContent = this.sortBy === 'name' ? (this.sortDir === 'asc' ? '↑' : '↓') : '';
    document.getElementById('ss').textContent = this.sortBy === 'size' ? (this.sortDir === 'asc' ? '↑' : '↓') : '';
    document.getElementById('sd').textContent = this.sortBy === 'date' ? (this.sortDir === 'asc' ? '↑' : '↓') : '';
    this.page = 1;
    this.load();
  },

  async upload(files, preserve) {
    if (!files.length) return;
    const fd = new FormData();
    for (const f of files) {
      fd.append('files', f);
      fd.append('paths', preserve && f._rp ? f._rp : f.name);
    }
    const url = this.path ? '/upload/' + this.epath(this.path) : '/upload';
    const toast = document.getElementById('uptoast');
    toast.style.display = '';
    try {
      await new Promise((ok, fail) => {
        const xhr = new XMLHttpRequest();
        xhr.upload.onprogress = e => {
          if (e.lengthComputable) {
            const pct = Math.round(e.loaded / e.total * 100);
            document.getElementById('pfill').style.width = pct + '%';
            document.getElementById('uppct').textContent = pct + '%';
          }
        };
        xhr.onload = () => {
          if (xhr.status === 200) ok();
          else if (xhr.status === 413) fail(new Error('File too large (max ' + MAX_MB + ' MB)'));
          else fail(new Error('Upload failed'));
        };
        xhr.onerror = () => fail(new Error('Upload failed'));
        xhr.open('POST', url);
        xhr.send(fd);
      });
      this.toast('Upload complete', 'ok');
    } catch(e) { this.toast(e.message, 'err'); }
    toast.style.display = 'none';
    document.getElementById('pfill').style.width = '0';
    this.refresh();
  },

  initDrag() {
    const ov = document.getElementById('dropov');
    document.addEventListener('dragenter', e => { e.preventDefault(); this.dragC++; if(this.dragC===1) ov.style.display=''; });
    document.addEventListener('dragleave', e => { e.preventDefault(); this.dragC--; if(this.dragC<=0){this.dragC=0;ov.style.display='none';} });
    document.addEventListener('dragover', e => e.preventDefault());
    document.addEventListener('drop', async e => {
      e.preventDefault(); this.dragC=0; ov.style.display='none';
      const items = e.dataTransfer.items;
      if (!items || !items.length) return;
      const files = [];
      const promises = [];
      for (const item of items) {
        if (item.webkitGetAsEntry) {
          const entry = item.webkitGetAsEntry();
          if (entry) promises.push(this.readEntry(entry, ''));
        } else { const f = item.getAsFile(); if (f) files.push(f); }
      }
      if (promises.length) { const r = await Promise.all(promises); r.flat().forEach(f => files.push(f)); }
      if (files.length) this.upload(files, files.some(f => f._rp));
    });
  },

  async readEntry(entry, prefix) {
    if (entry.isFile) return new Promise(ok => entry.file(f => { f._rp = prefix + f.name; ok([f]); }));
    if (entry.isDirectory) {
      const reader = entry.createReader();
      const entries = await this.readAllEntries(reader);
      const subs = await Promise.all(entries.map(e => this.readEntry(e, prefix + entry.name + '/')));
      return subs.flat();
    }
    return [];
  },

  readAllEntries(reader) {
    return new Promise(ok => {
      const all = [];
      const read = () => reader.readEntries(batch => { if (batch.length) { all.push(...batch); read(); } else ok(all); });
      read();
    });
  },

  async createFolder() {
    const name = prompt('New folder name:');
    if (!name || !name.trim()) return;
    try {
      const r = await fetch('/mkdir', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({path:this.path,name:name.trim()})});
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || 'Failed');
      this.toast('Folder created: ' + d.created, 'ok'); this.refresh();
    } catch(e) { this.toast(e.message, 'err'); }
  },

  async ren(fp, name) {
    const nn = prompt('Rename to:', name);
    if (!nn || !nn.trim() || nn.trim() === name) return;
    try {
      const r = await fetch('/rename', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({path:fp,new_name:nn.trim()})});
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || 'Failed');
      this.toast('Renamed to: ' + d.new_name, 'ok'); this.refresh();
    } catch(e) { this.toast(e.message, 'err'); }
  },

  async del1(fp, name) { if (!confirm('Delete "' + name + '"?')) return; await this.doDelete([fp]); },
  async delSel() { if (!confirm('Delete ' + this.sel.size + ' item(s)?')) return; await this.doDelete(Array.from(this.sel)); },

  async doDelete(paths) {
    try {
      const r = await fetch('/delete', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({paths})});
      const d = await r.json();
      if (d.deleted.length) this.toast(d.deleted.length + ' item(s) deleted', 'ok');
      if (d.errors.length) this.toast(d.errors.join(', '), 'err');
      this.sel.clear(); this.refresh();
    } catch(e) { this.toast('Delete failed', 'err'); }
  },

  dl1(fp, name, isDir) {
    if (isDir) { this.dlZipPaths([fp]); return; }
    const a = document.createElement('a');
    a.href = '/download/' + this.epath(fp); a.download = name;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
  },

  dlZip() { this.dlZipPaths(Array.from(this.sel)); },

  _setDlBusy(busy) {
    ['btnDlZip','btnDlEach'].forEach(id => {
      const b = document.getElementById(id);
      if (b) b.disabled = busy;
    });
  },

  async dlZipPaths(paths) {
    this._setDlBusy(true);
    const tid = this._zipToast('Zipping… please wait');
    try {
      const r = await fetch('/download-zip', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({paths})});
      if (!r.ok) throw new Error('ZIP failed');
      const blob = await r.blob();
      this._dismissToast(tid);
      this.toast('Download starting…', 'ok');
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = 'download.zip';
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 10000);
    } catch(e) {
      this._dismissToast(tid);
      this.toast('Download failed', 'err');
    }
    this._setDlBusy(false);
  },

  async dlEach() {
    const paths = Array.from(this.sel);
    const dirs  = paths.filter(p => { const it = this.items.find(i => this.fp(i.name) === p); return it && it.is_dir; });
    const files = paths.filter(p => !dirs.includes(p));
    if (dirs.length) { await this.dlZipPaths(dirs); }
    if (!files.length) return;
    this._setDlBusy(true);
    this.toast('Downloading ' + files.length + ' file' + (files.length > 1 ? 's' : '') + '…', 'info');
    for (let i = 0; i < files.length; i++) {
      const it = this.items.find(x => this.fp(x.name) === files[i]);
      const a = document.createElement('a');
      a.href = '/download/' + this.epath(files[i]); a.download = it ? it.name : '';
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      if (i < files.length - 1) await new Promise(r => setTimeout(r, 500));
    }
    this._setDlBusy(false);
  },

  // Persistent "working" toast that stays until dismissed
  _zipToast(msg) {
    const id = '_zt_' + Date.now();
    const t = document.createElement('div');
    t.id = id;
    t.className = 'toast toast-info';
    t.innerHTML = '<span style="margin-right:8px">⏳</span>' + msg;
    document.getElementById('toasts').appendChild(t);
    requestAnimationFrame(() => requestAnimationFrame(() => t.classList.add('show')));
    return id;
  },

  _dismissToast(id) {
    const t = document.getElementById(id);
    if (!t) return;
    t.classList.remove('show');
    setTimeout(() => t.remove(), 300);
  },

  async openPv(name, ptype, size) {
    const fp   = this.fp(name);
    const url  = '/preview/' + this.epath(fp);
    const body = document.getElementById('pvbody');
    document.getElementById('pvtitle').textContent = name;
    document.getElementById('modal').style.display = '';
    document.body.style.overflow = 'hidden';

    if (ptype === 'image') {
      const img = document.createElement('img');
      img.src = url; img.alt = name; body.appendChild(img);
    } else if (ptype === 'video') {
      body.innerHTML = '<video controls autoplay><source src="' + url + '"></video>';
    } else if (ptype === 'audio') {
      body.innerHTML = '<audio controls autoplay style="min-width:320px"><source src="' + url + '"></audio>';
    } else if (ptype === 'pdf') {
      body.innerHTML = '<iframe src="' + url + '"></iframe>';
    } else if (ptype === 'text') {
      const it = this.items.find(i => i.name === name);
      if (size > 1048576) {
        const msg = document.createElement('div');
        msg.className = 'preview-msg';
        msg.innerHTML = '<div class="big">📄</div><p>File too large to preview (' + (it ? it.size_h : '') + ')</p>';
        const dl = document.createElement('a');
        dl.href = '/download/' + this.epath(fp); dl.textContent = 'Download instead';
        dl.style.marginTop = '12px'; dl.style.display = 'block';
        msg.appendChild(dl); body.appendChild(msg);
      } else {
        body.innerHTML = '<div class="spinner"></div>';
        try {
          const r = await fetch(url);
          const t = await r.text();
          body.innerHTML = '';
          const pre = document.createElement('pre'); pre.textContent = t;
          body.appendChild(pre);
        } catch(e) { body.textContent = 'Failed to load preview'; }
      }
    } else {
      const msg = document.createElement('div');
      msg.className = 'preview-msg';
      msg.innerHTML = '<div class="big">📄</div><p>Preview not available for this file type</p>';
      const dl = document.createElement('a');
      dl.href = '/download/' + this.epath(fp); dl.textContent = 'Download file';
      dl.style.marginTop = '12px'; dl.style.display = 'block';
      msg.appendChild(dl); body.appendChild(msg);
    }
  },

  closePv() {
    document.getElementById('modal').style.display = 'none';
    document.body.style.overflow = '';
    document.getElementById('pvbody').innerHTML = '';
  },

  toast(msg, type) {
    const t = document.createElement('div');
    t.className = 'toast toast-' + (type === 'ok' ? 'ok' : type === 'err' ? 'err' : 'info');
    t.textContent = msg;
    document.getElementById('toasts').appendChild(t);
    requestAnimationFrame(() => requestAnimationFrame(() => t.classList.add('show')));
    setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 300); }, 3500);
  },

  fp(name)  { return this.path ? this.path + '/' + name : name; },
  epath(p)  { return p.split('/').map(encodeURIComponent).join('/'); },
};

const MAX_MB = {{ max_mb }};
App.init();
</script>
</body>
</html>"""


# ── Routes ───────────────────────────────────────────────────────
@app.route('/')
@app.route('/browse/')
@app.route('/browse/<path:subpath>')
def browse(subpath=''):
    safe_path(subpath)
    return render_template_string(TEMPLATE, current_path=subpath,
                                  max_mb=MAX_UPLOAD_MB)

@app.route('/api/list')
@app.route('/api/list/<path:subpath>')
def api_list(subpath=''):
    dp = safe_path(subpath)
    if not os.path.isdir(dp):
        return jsonify(error='Not found'), 404
    raw = _scan_cache.get(dp)
    if raw is None:
        return jsonify(error='Permission denied'), 403

    sb = request.args.get('sort', 'name')
    sd = request.args.get('dir', 'asc')
    page = max(1, int(request.args.get('page', 1)))
    per = max(1, min(500, int(request.args.get('per_page', PER_PAGE))))

    key = {'name': lambda x: x['name'].lower(),
           'size': lambda x: x['size'],
           'date': lambda x: x['mtime']}.get(sb, lambda x: x['name'].lower())
    rev = sd == 'desc'
    dirs = sorted([i for i in raw if i['is_dir']], key=key, reverse=rev)
    fils = sorted([i for i in raw if not i['is_dir']], key=key, reverse=rev)
    all_sorted = dirs + fils
    total = len(all_sorted)
    pages = max(1, (total + per - 1) // per)
    page = min(page, pages)
    start = (page - 1) * per
    page_items = [_enrich(dict(i)) for i in all_sorted[start:start + per]]

    crumbs = [dict(name='Home', path='')]
    if subpath:
        parts = subpath.split('/')
        for i, p in enumerate(parts):
            crumbs.append(dict(name=p, path='/'.join(parts[:i+1])))
    return jsonify(items=page_items, breadcrumbs=crumbs,
                   total=total, page=page, pages=pages, per_page=per)

@app.route('/api/sizes', methods=['POST'])
@app.route('/api/sizes/<path:subpath>', methods=['POST'])
def api_sizes(subpath=''):
    """Return available sizes instantly; trigger background calc for the rest."""
    dp = safe_path(subpath)
    if not os.path.isdir(dp):
        return jsonify(error='Not found'), 404
    names = request.get_json(silent=True) or []
    if not isinstance(names, list):
        return jsonify(error='Bad request'), 400
    # Build list of valid dir paths
    dir_paths = {}
    for name in names:
        if not isinstance(name, str):
            continue
        ep = os.path.join(dp, name)
        if _under_base(ep) and os.path.isdir(ep):
            dir_paths[name] = ep
    # Non-blocking: returns cached sizes, kicks off bg threads for the rest
    cached = _dir_cache.request_sizes(list(dir_paths.values()))
    result = {}
    pending = 0
    for name, ep in dir_paths.items():
        if ep in cached:
            sz = cached[ep]
            result[name] = {'size': sz, 'size_h': human_size(sz)}
        else:
            pending += 1
    return jsonify(sizes=result, pending=pending)

@app.route('/upload', methods=['POST'])
@app.route('/upload/<path:subpath>', methods=['POST'])
def upload(subpath=''):
    dp = safe_path(subpath)
    if not os.path.isdir(dp):
        return jsonify(error='Not found'), 404
    files = request.files.getlist('files')
    paths = request.form.getlist('paths')
    uploaded = []
    for i, f in enumerate(files):
        if not f.filename:
            continue
        rel = paths[i] if i < len(paths) else f.filename
        parts = rel.replace('\\', '/').split('/')
        safe_parts = [secure_filename(p) for p in parts if p and secure_filename(p)]
        if not safe_parts:
            continue
        fname = safe_parts[-1]
        target = dp
        for d in safe_parts[:-1]:
            target = os.path.join(target, d)
        if not _under_base(target):
            continue
        os.makedirs(target, exist_ok=True)
        fname = unique_name(target, fname)
        f.save(os.path.join(target, fname), buffer_size=256 * 1024)
        uploaded.append(fname)
    _dir_cache.invalidate(dp)
    _scan_cache.invalidate(dp)
    return jsonify(uploaded=uploaded, count=len(uploaded))

@app.route('/delete', methods=['POST'])
def delete():
    data = request.get_json(silent=True) or {}
    paths = data.get('paths', [])
    if not isinstance(paths, list):
        return jsonify(error='paths must be a list'), 400
    deleted, errors = [], []
    for rel in paths:
        if not isinstance(rel, str):
            continue
        ap = safe_path(rel)
        if ap == BASE_DIR:
            errors.append('Cannot delete root'); continue
        try:
            if os.path.islink(ap):
                os.unlink(ap)
            elif os.path.isdir(ap):
                shutil.rmtree(ap)
            elif os.path.isfile(ap):
                os.remove(ap)
            else:
                errors.append('Not found: ' + rel); continue
            deleted.append(rel)
            _dir_cache.invalidate(os.path.dirname(ap))
            _scan_cache.invalidate(os.path.dirname(ap))
        except OSError as ex:
            errors.append(f'{rel}: {ex.strerror}')
    return jsonify(deleted=deleted, errors=errors)

@app.route('/rename', methods=['POST'])
def rename():
    data = request.get_json(silent=True) or {}
    old = data.get('path', '')
    nn  = secure_filename(data.get('new_name', ''))
    if not nn:
        return jsonify(error='Invalid name'), 400
    ap = safe_path(old)
    if not os.path.exists(ap):
        return jsonify(error='Not found'), 404
    parent = os.path.dirname(ap)
    nn = unique_name(parent, nn)
    np = os.path.join(parent, nn)
    if not _under_base(np):
        abort(403)
    os.rename(ap, np)
    _dir_cache.invalidate(parent)
    _scan_cache.invalidate(parent)
    return jsonify(new_name=nn)

@app.route('/mkdir', methods=['POST'])
def mkdir():
    data   = request.get_json(silent=True) or {}
    parent = data.get('path', '')
    name   = secure_filename(data.get('name', ''))
    if not name:
        return jsonify(error='Invalid name'), 400
    pp = safe_path(parent)
    if not os.path.isdir(pp):
        return jsonify(error='Parent not found'), 404
    nd = os.path.join(pp, name)
    if not _under_base(nd):
        abort(403)
    if os.path.exists(nd):
        return jsonify(error='Already exists'), 409
    os.makedirs(nd)
    _dir_cache.invalidate(pp)
    _scan_cache.invalidate(pp)
    return jsonify(created=name)

@app.route('/download/<path:subpath>')
def download(subpath):
    ap = safe_path(subpath)
    if not os.path.isfile(ap):
        abort(404)
    parent = os.path.dirname(ap)
    fname = os.path.basename(ap)
    return send_from_directory(parent, fname, as_attachment=True,
                               conditional=True)

# Extensions that are already compressed — store without deflating
_ZIP_STORE_EXT = {
    '.jpg','.jpeg','.png','.gif','.webp','.heic',
    '.mp4','.avi','.mov','.mkv','.webm','.m4v',
    '.mp3','.aac','.flac','.ogg','.m4a','.wav',
    '.zip','.gz','.bz2','.xz','.7z','.rar','.tar',
    '.pdf','.docx','.xlsx','.pptx',
}

def _zip_method(filename):
    return zipfile.ZIP_STORED if os.path.splitext(filename)[1].lower() in _ZIP_STORE_EXT \
           else zipfile.ZIP_DEFLATED

class _ZipStream(io.RawIOBase):
    """Unseekable write stream that buffers ZipFile output for chunked yielding."""
    def __init__(self):
        self._buf = bytearray()
    def writable(self):
        return True
    def write(self, b):
        self._buf.extend(b)
        return len(b)
    def drain(self):
        chunk = bytes(self._buf)
        self._buf.clear()
        return chunk

def _generate_zip(file_list):
    """Yield ZIP bytes as a stream. file_list = [(abs_path, arcname), ...]."""
    stream = _ZipStream()
    with zipfile.ZipFile(stream, mode='w', allowZip64=True) as zf:
        for fpath, arcname in file_list:
            method = _zip_method(fpath)
            info = zipfile.ZipInfo(arcname)
            info.compress_type = method
            info.file_size = os.path.getsize(fpath)
            with open(fpath, 'rb') as src:
                with zf.open(info, 'w', force_zip64=True) as dest:
                    while True:
                        chunk = src.read(256 * 1024)
                        if not chunk:
                            break
                        dest.write(chunk)
            data = stream.drain()
            if data:
                yield data
    # Yield final central directory
    data = stream.drain()
    if data:
        yield data

@app.route('/download-zip', methods=['POST'])
def download_zip():
    data  = request.get_json(silent=True) or {}
    paths = data.get('paths', [])
    if not isinstance(paths, list) or not paths:
        return jsonify(error='No files selected'), 400

    # Build the flat list of (abs_path, arcname) pairs up front
    file_list = []
    for rel in paths:
        if not isinstance(rel, str):
            continue
        ap = safe_path(rel)
        if os.path.isfile(ap) and _under_base(ap):
            file_list.append((ap, os.path.basename(ap)))
        elif os.path.isdir(ap):
            dn = os.path.basename(ap)
            for root, _, fnames in os.walk(ap):
                if not _under_base(root):
                    continue
                for fn in fnames:
                    fp = os.path.join(root, fn)
                    if _under_base(fp):
                        file_list.append((fp, os.path.join(dn, os.path.relpath(fp, ap))))

    if not file_list:
        return jsonify(error='No files found'), 400

    return Response(
        _generate_zip(file_list),
        mimetype='application/zip',
        headers={
            'Content-Disposition': 'attachment; filename="download.zip"',
            'X-Accel-Buffering': 'no',
        }
    )

@app.route('/preview/<path:subpath>')
def preview(subpath):
    ap = safe_path(subpath)
    if not os.path.isfile(ap):
        abort(404)
    parent = os.path.dirname(ap)
    fname = os.path.basename(ap)
    mt = mimetypes.guess_type(ap)[0] or 'application/octet-stream'
    return send_from_directory(parent, fname, mimetype=mt, conditional=True)

@app.route('/favicon.ico')
def favicon():
    svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><text y=".9em" font-size="90">🍍</text></svg>'
    return svg, 200, {'Content-Type': 'image/svg+xml',
                      'Cache-Control': 'public, max-age=86400'}

@app.errorhandler(413)
def too_large(_e):
    return jsonify(error=f'File too large (max {MAX_UPLOAD_MB} MB)'), 413


# ── Cloudflared tunnel ───────────────────────────────────────────
import platform as _platform

CF_CACHE = os.path.join(os.path.expanduser('~'), '.pineapplee', 'bin')


def _cf_download_spec():
    """Return (url, fmt) for the current platform, or (None, None)."""
    base    = 'https://github.com/cloudflare/cloudflared/releases/latest/download/'
    system  = _platform.system().lower()
    machine = _platform.machine().lower()
    if system == 'darwin':
        slug = 'darwin-arm64' if machine in ('arm64', 'aarch64') else 'darwin-amd64'
        return base + f'cloudflared-{slug}.tgz', 'tgz'
    if system == 'linux':
        if machine in ('arm64', 'aarch64'):
            slug = 'linux-arm64'
        elif 'arm' in machine:
            slug = 'linux-arm'
        else:
            slug = 'linux-amd64'
        return base + f'cloudflared-{slug}', 'bin'
    if system == 'windows':
        return base + 'cloudflared-windows-amd64.exe', 'exe'
    return None, None


def _ensure_cloudflared():
    """Download cloudflared binary to CF_CACHE if not already there.
    Returns the binary path, or None on failure."""
    import urllib.request, tarfile as _tarfile

    ext      = '.exe' if _platform.system().lower() == 'windows' else ''
    bin_path = os.path.join(CF_CACHE, f'cloudflared{ext}')

    if os.path.isfile(bin_path):
        return bin_path

    url, fmt = _cf_download_spec()
    if not url:
        print('  ✗  Unsupported platform for cloudflared auto-download')
        return None

    os.makedirs(CF_CACHE, exist_ok=True)
    tmp = bin_path + '.tmp'
    print(f'  ⬇  Downloading cloudflared for {_platform.system()} '
          f'{_platform.machine()}…')
    try:
        urllib.request.urlretrieve(url, tmp)
        if fmt == 'tgz':
            with _tarfile.open(tmp, 'r:gz') as tf:
                for member in tf.getmembers():
                    nm = os.path.basename(member.name)
                    if nm == 'cloudflared':
                        fobj = tf.extractfile(member)
                        with open(bin_path, 'wb') as out:
                            out.write(fobj.read())
                        break
            os.unlink(tmp)
        else:
            os.rename(tmp, bin_path)
        if _platform.system().lower() != 'windows':
            os.chmod(bin_path, 0o755)
        # Remove macOS Gatekeeper quarantine flag so the binary can run
        if _platform.system().lower() == 'darwin':
            import subprocess as _sp
            _sp.run(['xattr', '-d', 'com.apple.quarantine', bin_path],
                    capture_output=True)
        print(f'  ✓  Saved to {bin_path}')
        return bin_path
    except Exception as exc:
        print(f'  ✗  Failed to download cloudflared: {exc}')
        try: os.unlink(tmp)
        except OSError: pass
        return None


def _start_tunnel(port):
    """Start a cloudflared quick tunnel. Returns (proc, public_url) or (None, None)."""
    import subprocess, threading, re

    bin_path = _ensure_cloudflared()
    if not bin_path:
        return None, None

    proc = subprocess.Popen(
        [bin_path, 'tunnel', '--url', f'http://127.0.0.1:{port}'],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    public_url = [None]
    ready      = threading.Event()

    def _reader():
        for line in proc.stdout:
            m = re.search(r'https://[a-z0-9-]+\.trycloudflare\.com', line)
            if m and not ready.is_set():
                public_url[0] = m.group(0)
                ready.set()

    threading.Thread(target=_reader, daemon=True).start()
    ready.wait(timeout=30)
    return proc, public_url[0]


# ── CLI banner ───────────────────────────────────────────────────
def _vlen(s):
    """Visible width of string, accounting for wide emoji characters."""
    w = 0
    for c in s:
        w += 2 if unicodedata.east_asian_width(c) in ('W', 'F') else 1
    return w

def _rpad(s, width):
    return s + ' ' * max(0, width - _vlen(s))

def _print_banner(serve_dir, local, public_url=None, net_url=None):
    rows = [('📂 Serving',    serve_dir),
            ('🔗 Local',      local)]
    if net_url:
        rows.append(('🌐 Network', net_url))
    if public_url:
        rows.append(('🌍 Public',  public_url))
    rows.append(('📦 Max upload', f'{MAX_UPLOAD_MB} MB'))

    LABEL_W  = 16
    max_val  = max(_vlen(v) for _, v in rows)
    W        = max(max_val + LABEL_W + 4, 46)
    B        = '━'
    title    = '🍍 Pineapple File Server'
    footer   = 'Press Ctrl+C to stop'

    print()
    print(f'  ┏{B * W}┓')
    print(f'  ┃{_rpad(" " + title, W)}┃')
    print(f'  ┣{B * W}┫')
    print(f'  ┃{" " * W}┃')
    for label, value in rows:
        line = f'  {label}  {value}'
        print(f'  ┃{_rpad(line, W)}┃')
    print(f'  ┃{" " * W}┃')
    print(f'  ┣{B * W}┫')
    print(f'  ┃{_rpad("  " + footer, W)}┃')
    print(f'  ┗{B * W}┛')
    print()


# ── Entry point ──────────────────────────────────────────────────
def main():
    import argparse, logging, socket, threading, time

    global BASE_DIR, _BASE_REAL

    from pineapplee import __version__

    parser = argparse.ArgumentParser(
        prog='pineapplee',
        description='🍍 Pineapple — beautiful local file server',
    )
    parser.add_argument('directory', nargs='?', default=None,
                        help='Directory to serve (default: current directory)')
    parser.add_argument('--port', '-p', type=int, default=8089,
                        help='Port to listen on (default: 8089)')
    parser.add_argument('--public', action='store_true',
                        help='Expose publicly via Cloudflare Tunnel')
    parser.add_argument('--version', '-v', action='version',
                        version=f'pineapplee {__version__}')
    args = parser.parse_args()

    # Resolve serve directory
    serve_dir = os.path.abspath(args.directory) if args.directory else os.path.abspath(os.getcwd())
    if not os.path.isdir(serve_dir):
        print(f'  ✗  Not a directory: {serve_dir}')
        sys.exit(1)

    # Set runtime globals
    BASE_DIR   = serve_dir
    _BASE_REAL = os.path.realpath(serve_dir)
    app.config['MAX_CONTENT_LENGTH'] = MAX_UPLOAD_MB * 1024 * 1024

    port  = args.port
    local = f'http://localhost:{port}'

    # Suppress werkzeug noise
    logging.getLogger('werkzeug').setLevel(logging.WARNING)

    # Detect LAN IP
    def _get_lan():
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(('8.8.8.8', 80))
            ip = s.getsockname()[0]
            s.close()
            return f'http://{ip}:{port}'
        except Exception:
            return None

    # ── --public mode: Flask in thread + cloudflared tunnel ──────
    if args.public:
        import socket as _socket
        from werkzeug.serving import make_server as _make_server

        _srv = _make_server('0.0.0.0', port, app)
        flask_thread = threading.Thread(target=_srv.serve_forever, daemon=True)
        flask_thread.start()

        # Wait until the port is actually accepting connections (max 10 s)
        deadline = time.time() + 10
        while time.time() < deadline:
            try:
                with _socket.create_connection(('127.0.0.1', port), timeout=0.1):
                    break
            except OSError:
                time.sleep(0.05)

        cf_proc, public_url = _start_tunnel(port)
        _print_banner(serve_dir, local, public_url=public_url,
                      net_url=_get_lan())
        if not public_url:
            print('  ⚠  Tunnel URL not obtained — server still running locally\n')

        _setup_request_log()
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            if cf_proc:
                cf_proc.terminate()
            print('\n  Server stopped.\n')

    # ── Normal local mode ────────────────────────────────────────
    else:
        is_reloader = os.environ.get('WERKZEUG_RUN_MAIN') == 'true'
        if not is_reloader:
            _print_banner(serve_dir, local, net_url=_get_lan())
        _setup_request_log()
        app.run(host='0.0.0.0', port=port, debug=False, use_reloader=True)


def _setup_request_log():
    M_ICONS = {'GET': '🔽', 'POST': '🔼', 'PUT': '📝', 'DELETE': '🗑 '}
    S_CLR   = {2: '\033[92m', 3: '\033[93m', 4: '\033[91m', 5: '\033[91m'}
    RST     = '\033[0m'

    @app.after_request
    def _log_req(response):
        method = request.method
        path   = request.path
        status = response.status_code
        icon   = M_ICONS.get(method, '  ')
        clr    = S_CLR.get(status // 100, '')
        ts     = datetime.now().strftime('%H:%M:%S')
        print(f'  {ts}  {icon} {method:<6} {clr}{status}{RST}  {path}')
        return response
