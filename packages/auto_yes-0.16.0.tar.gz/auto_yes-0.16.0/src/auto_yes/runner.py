"""Cross-platform PTY proxy runner.

Spawns a child process inside a pseudo-terminal, transparently forwards I/O
between the user's real terminal and the child, and injects auto-responses
whenever the output matches a known prompt pattern.

Anti-false-positive mechanisms:

- **typing suppress**: after a real user keystroke, suppress detection for
  ``_TYPING_SUPPRESS`` seconds so that echoed text does not trigger matches.
- **match cooldown**: after a successful match, suppress for
  ``_MATCH_COOLDOWN`` seconds to avoid terminal-redraw re-triggers.
- **buffer clear on input**: when the user types, the output buffer is
  discarded so stale prompt text cannot re-match.
- **escape sequence filtering**: terminal-generated sequences (focus events,
  cursor position reports) are not counted as user keystrokes.
- **approval delay**: optional ``delay`` parameter queues a pending approval
  that the user can cancel by pressing any key.

Unix  : built-in ``pty`` + ``select`` (zero external deps)
Windows: optional ``pywinpty`` -> fallback to subprocess pipes + threading
"""

import contextlib
import errno
import os
import signal
import sys
import time

from auto_yes import config as _cfg
from auto_yes.detector import PromptDetector

_BUFFER_LIMIT = 8192
_BUFFER_TRIM = 4096

_TYPING_SUPPRESS = 1.0
_MATCH_COOLDOWN = 0.05


def _is_escape_sequence(data):
    """Return True if *data* is a terminal-generated escape sequence rather
    than a real user keypress.

    Detected sequences: focus events (``ESC[I``, ``ESC[O``) and cursor
    position reports (``ESC[<digits>;<digits>R``).  Arrow keys, function
    keys, and Alt+key combos are real input and return False.
    """
    if len(data) < 3 or data[0:1] != b"\x1b" or data[1:2] != b"[":
        return False

    if len(data) == 3 and data[2:3] in (b"I", b"O"):
        return True

    if data[-1:] == b"R":
        inner = data[2:-1]
        if inner and all(
            c in b"0123456789;" for c in inner
        ):
            return True

    return False


class Runner:
    """PTY proxy that intercepts prompts and auto-responds."""

    def __init__(
        self,
        response="y",
        cooldown=0.5,
        verbose=False,
        categories=None,
        extra_patterns=None,
        delay=0.0,
        profile=None,
        log_file=None,
        quiet=False,
        heartbeat=0.0,
    ):
        self.response = response
        self.cooldown = cooldown
        self.verbose = verbose if not quiet else False
        self.quiet = quiet
        self.delay = delay
        self.profile = profile
        self.heartbeat = heartbeat
        self.detector = PromptDetector(
            categories=categories,
            extra_patterns=extra_patterns,
        )
        self._last_response_time = 0.0
        self._last_match_time = 0.0
        self._last_user_input = 0.0
        self._last_heartbeat_time = 0.0
        self._pid = os.getpid()
        self._response_count = 0
        self._start_time = None  # set when run starts
        self._log_fh = None
        if log_file:
            self._log_fh = open(log_file, "w", encoding="utf-8")  # noqa: SIM115
            self._log(f"auto-yes debug log — pid={self._pid} profile={profile}")
            self._log(f"patterns: {self.detector.pattern_strings}")

    def _log(self, msg):
        if self._log_fh is None:
            return
        import time as _t
        self._log_fh.write(f"[{_t.time():.3f}] {msg}\n")
        self._log_fh.flush()

    @property
    def pid(self):
        return self._pid

    # ------------------------------------------------------------------
    # public API
    # ------------------------------------------------------------------

    def run_command(self, command):
        """Run *command* (list or str) with auto-yes.  Returns exit code."""
        if sys.platform == "win32":
            return self._run_windows(command)
        return self._run_unix(command)

    def run_shell(self):
        """Launch an interactive shell session with auto-yes.  Returns exit code."""
        if sys.platform == "win32":
            shell = os.environ.get("COMSPEC", "cmd.exe")
            return self._run_windows([shell])

        shell = os.environ.get("SHELL", "/bin/sh")
        return self._run_unix([shell])

    # ==================================================================
    # Unix implementation
    # ==================================================================

    def _run_unix(self, command):
        import fcntl
        import pty
        import select
        import termios
        import tty

        env = os.environ.copy()
        env["AUTO_YES_ACTIVE"] = "1"

        stdin_fd = sys.stdin.fileno()
        stdout_fd = sys.stdout.fileno()

        stdin_is_tty = os.isatty(stdin_fd)
        old_tty_attrs = None
        if stdin_is_tty:
            old_tty_attrs = termios.tcgetattr(stdin_fd)

        master_fd, slave_fd = pty.openpty()

        if stdin_is_tty:
            try:
                winsz = fcntl.ioctl(stdout_fd, termios.TIOCGWINSZ, b"\x00" * 8)
                fcntl.ioctl(slave_fd, termios.TIOCSWINSZ, winsz)
            except OSError:
                pass

        pid = os.fork()

        if pid == 0:
            os.close(master_fd)
            os.setsid()
            fcntl.ioctl(slave_fd, termios.TIOCSCTTY, 0)

            os.dup2(slave_fd, 0)
            os.dup2(slave_fd, 1)
            os.dup2(slave_fd, 2)
            if slave_fd > 2:
                os.close(slave_fd)

            if isinstance(command, (list, tuple)):
                os.execvpe(command[0], command, env)
            else:
                os.execvpe("/bin/sh", ["/bin/sh", "-c", command], env)

        os.close(slave_fd)

        cmd_display = command if isinstance(command, str) else " ".join(command)
        _cfg.register_session(os.getpid(), self.profile or "", cmd_display)

        self._start_time = time.time()
        if self.verbose:
            import os as _os
            _pid = _os.getpid()
            Runner._log_unix(stdout_fd, f"PID {_pid} | watching for prompts | cooldown={self.cooldown}s | response='{self.response}'")

        prev_winch = signal.getsignal(signal.SIGWINCH)

        def _on_winch(_sig, _frame):
            try:
                ws = fcntl.ioctl(stdout_fd, termios.TIOCGWINSZ, b"\x00" * 8)
                fcntl.ioctl(master_fd, termios.TIOCSWINSZ, ws)
                os.kill(pid, signal.SIGWINCH)
            except (OSError, ProcessLookupError):
                pass

        signal.signal(signal.SIGWINCH, _on_winch)

        # --- SIGCHLD: reap zombie grandchildren (subagents) ---
        # Subagents spawned by the child may leave zombies if the child does
        # not wait for them. Install a SIGCHLD handler that reaps any
        # grandchild that exits, preventing zombie accumulation in long-running
        # overnight loops.  Only install if not already set to a custom handler
        # so we do not override an existing application handler.
        prev_sigchld = signal.getsignal(signal.SIGCHLD)
        if prev_sigchld in (signal.SIG_DFL, signal.SIG_IGN, None):
            def _on_sigchld(_sig, _frame):
                # Reap all available grandchildren without blocking.
                try:
                    while True:
                        wpid, _ = os.waitpid(-1, os.WNOHANG)
                        if wpid <= 0:
                            break
                except ChildProcessError:
                    pass
            signal.signal(signal.SIGCHLD, _on_sigchld)
        else:
            prev_sigchld = None  # signal already customised; leave it alone

        # --- SIGTERM / SIGINT: forward to child before exiting ---
        _terminate_requested = [False]

        def _on_terminate(_sig, _frame):
            _terminate_requested[0] = True

        prev_sigterm = signal.getsignal(signal.SIGTERM)
        prev_sigint = signal.getsignal(signal.SIGINT)
        signal.signal(signal.SIGTERM, _on_terminate)
        signal.signal(signal.SIGINT, _on_terminate)

        if stdin_is_tty:
            tty.setraw(stdin_fd)

        output_buf = bytearray()
        buf_dirty = False
        exit_code = 0
        pending = None  # (deadline, response_str, pattern_str) or None
        use_delay = self.delay > 0

        try:
            while True:
                # --- check for pending SIGTERM / SIGINT ---
                if _terminate_requested[0]:
                    with contextlib.suppress(OSError, ProcessLookupError):
                        os.kill(pid, signal.SIGTERM)
                    break

                watch_fds = [master_fd]
                if stdin_is_tty:
                    watch_fds.append(stdin_fd)

                try:
                    readable, _, _ = select.select(watch_fds, [], [], 0.05)
                except (OSError, InterruptedError):
                    continue

                now = time.time()

                # --- heartbeat: send Enter periodically to keep agents responsive ---
                if (
                    self.heartbeat > 0
                    and (now - self._last_heartbeat_time) >= self.heartbeat
                    and (now - self._last_user_input) >= _TYPING_SUPPRESS
                    and self._last_heartbeat_time > 0  # skip first tick
                ):
                    try:
                        os.write(master_fd, b"\r")
                    except OSError:
                        pass
                    self._last_heartbeat_time = now
                    if self.verbose:
                        self._log_unix(stdout_fd, f"heartbeat: sent Enter (interval={self.heartbeat:.0f}s)")
                elif self.heartbeat > 0 and self._last_heartbeat_time == 0.0:
                    self._last_heartbeat_time = now

                # --- pending approval: send if deadline reached ---
                if pending is not None:
                    deadline, resp, pat = pending
                    if now >= deadline:
                        self._send_response_unix(master_fd, stdout_fd, resp, pat)
                        pending = None
                        output_buf.clear()
                        buf_dirty = False

                # --- user input -> child ---
                if stdin_fd in readable:
                    try:
                        data = os.read(stdin_fd, 4096)
                        if not data:
                            break
                    except OSError:
                        break

                    if not _is_escape_sequence(data):
                        self._last_user_input = now
                        self._last_heartbeat_time = now  # reset heartbeat after user input
                        output_buf.clear()
                        buf_dirty = False
                        if pending is not None:
                            if self.verbose:
                                self._log_unix(
                                    stdout_fd,
                                    "user input detected, cancelling pending approval",
                                )
                            pending = None

                    try:
                        os.write(master_fd, data)
                    except OSError:
                        break

                # --- child output -> user ---
                if master_fd in readable:
                    try:
                        data = os.read(master_fd, 4096)
                        if not data:
                            break
                    except OSError as exc:
                        if exc.errno == errno.EIO:
                            # EIO means the child has closed its end of the
                            # PTY (i.e. the child exited).  Drain any buffered
                            # output then exit the loop.  This is the normal
                            # PTY teardown path on Linux and is not an error.
                            self._drain_pty(master_fd, stdout_fd)
                            break
                        raise

                    os.write(stdout_fd, data)

                    # Filter null bytes before buffering: some terminals emit
                    # \x00 bytes in PTY output (e.g. during initialisation).
                    # They are harmless to display but can confuse UTF-8
                    # decoding heuristics and the prompt detector, so strip
                    # them from the detection buffer.
                    filtered = data.replace(b"\x00", b"")
                    output_buf.extend(filtered)
                    if len(output_buf) > _BUFFER_LIMIT:
                        del output_buf[:-_BUFFER_TRIM]
                    buf_dirty = True

                    if self._log_fh is not None:
                        self._log(f"child output: {len(data)} bytes, buf={len(output_buf)}")
                        preview = data[:200].decode("utf-8", errors="replace")
                        self._log(f"  raw: {preview!r}")

                # --- prompt detection (only when new output arrived) ---
                if buf_dirty and pending is None and self._timing_allows(now):
                    text = output_buf.decode("utf-8", errors="replace")
                    result = self.detector.detect(text)

                    if self._log_fh is not None:
                        from auto_yes._ansi import clean_text as _ct
                        cleaned = _ct(text)
                        tail = cleaned[-300:] if len(cleaned) > 300 else cleaned
                        self._log(f"detect: result={result}")
                        self._log(f"  cleaned tail: {tail!r}")

                    if result is not None:
                        self._last_match_time = now
                        resp = result.suggested_response
                        if resp is None:
                            resp = self.response

                        if use_delay:
                            pending = (now + self.delay, resp, result.pattern)
                            if self.verbose:
                                self._log_unix(
                                    stdout_fd,
                                    f"prompt detected, waiting {self.delay:.1f}s "
                                    f"(matched: {result.pattern})",
                                )
                        else:
                            self._send_response_unix(master_fd, stdout_fd, resp, result.pattern)
                            output_buf.clear()
                    buf_dirty = False

                exit_code = self._reap_child(pid)
                if exit_code is not None:
                    self._drain_pty(master_fd, stdout_fd)
                    break

            if exit_code is None:
                exit_code = self._wait_child(pid)

        finally:
            _cfg.unregister_session(os.getpid())
            if old_tty_attrs is not None:
                termios.tcsetattr(stdin_fd, termios.TCSAFLUSH, old_tty_attrs)
            signal.signal(signal.SIGWINCH, prev_winch)
            if prev_sigchld is not None:
                signal.signal(signal.SIGCHLD, prev_sigchld)
            signal.signal(signal.SIGTERM, prev_sigterm)
            signal.signal(signal.SIGINT, prev_sigint)
            with contextlib.suppress(OSError):
                os.close(master_fd)

        if self.verbose and self._start_time is not None:
            elapsed = time.time() - self._start_time
            Runner._log_unix(stdout_fd, f"session ended | {self._response_count} prompt(s) auto-responded | uptime {int(elapsed)}s")

        return exit_code

    # ------------------------------------------------------------------

    def _timing_allows(self, now):
        """Return True if all timing guards have expired."""
        if (now - self._last_user_input) < _TYPING_SUPPRESS:
            self._log("suppressed: typing_suppress")
            return False
        if (now - self._last_match_time) < _MATCH_COOLDOWN:
            self._log("suppressed: match_cooldown")
            return False
        if (now - self._last_response_time) < self.cooldown:
            self._log("suppressed: cooldown")
            return False
        if _cfg.is_paused(self._pid):
            self._log("suppressed: paused")
            return False
        return True

    def _send_response_unix(self, master_fd, stdout_fd, response, pattern):
        """Write *response* to the child PTY and update timing state.

        Uses ``\\r`` (CR) instead of ``\\n`` (LF) because Enter key produces
        CR in a terminal.  TUI applications (Cursor Agent, Claude Code, etc.)
        put the PTY in raw mode where ICRNL is disabled — only ``\\r`` is
        recognised as Enter.  In cooked mode ``\\r`` is translated to ``\\n``
        by the line discipline, so it works in both modes.
        """
        try:
            os.write(master_fd, (response + "\r").encode())
        except OSError:
            return

        self._response_count += 1
        self._last_response_time = time.time()

        if self.verbose:
            self._log_unix(stdout_fd, f"responded '{response}' (matched: {pattern})")

    @staticmethod
    def _log_unix(stdout_fd, message):
        """Write a coloured notice to the user's terminal."""
        msg = f"\r\n\x1b[33m[auto-yes] {message}\x1b[0m\r\n"
        with contextlib.suppress(OSError):
            os.write(stdout_fd, msg.encode())

    # ------------------------------------------------------------------

    @staticmethod
    def _reap_child(pid):
        """Non-blocking waitpid.  Returns exit code or ``None``."""
        try:
            wpid, wstatus = os.waitpid(pid, os.WNOHANG)
        except ChildProcessError:
            return 0

        if wpid == 0:
            return None

        if os.WIFEXITED(wstatus):
            return os.WEXITSTATUS(wstatus)
        if os.WIFSIGNALED(wstatus):
            return 128 + os.WTERMSIG(wstatus)
        return 1

    @staticmethod
    def _wait_child(pid):
        """Blocking waitpid.  Returns exit code."""
        try:
            _, wstatus = os.waitpid(pid, 0)
        except ChildProcessError:
            return 0
        if os.WIFEXITED(wstatus):
            return os.WEXITSTATUS(wstatus)
        if os.WIFSIGNALED(wstatus):
            return 128 + os.WTERMSIG(wstatus)
        return 1

    @staticmethod
    def _drain_pty(master_fd, stdout_fd):
        """Flush any remaining bytes in the master PTY buffer."""
        import select as _sel

        try:
            while True:
                rlist, _, _ = _sel.select([master_fd], [], [], 0.1)
                if not rlist:
                    break
                data = os.read(master_fd, 4096)
                if not data:
                    break
                os.write(stdout_fd, data)
        except OSError:
            pass

    # ==================================================================
    # Windows implementation
    # ==================================================================

    def _run_windows(self, command):
        """Try ``pywinpty`` first; fall back to subprocess + pipes."""
        try:
            return self._run_windows_pty(command)
        except ImportError:
            return self._run_windows_pipe(command)

    def _run_windows_pty(self, command):
        """Windows PTY implementation via *pywinpty*."""
        from winpty import PtyProcess  # type: ignore[import-untyped]

        env = os.environ.copy()
        env["AUTO_YES_ACTIVE"] = "1"

        if isinstance(command, (list, tuple)):
            cmd_str = " ".join(command)
        else:
            cmd_str = command

        proc = PtyProcess.spawn(cmd_str, env=env)

        output_buf = b""
        try:
            while proc.isalive():
                try:
                    data = proc.read(4096)
                except EOFError:
                    break
                if not data:
                    continue

                raw = data.encode("utf-8") if isinstance(data, str) else data
                sys.stdout.buffer.write(raw)
                sys.stdout.buffer.flush()

                output_buf += raw
                if len(output_buf) > _BUFFER_LIMIT:
                    output_buf = output_buf[-_BUFFER_TRIM:]

                now = time.time()
                result = self._detect_if_ready(output_buf, now)
                if result is not None:
                    self._last_match_time = now
                    resp = result.suggested_response
                    if resp is None:
                        resp = self.response
                    try:
                        proc.write(resp + "\r")
                    except Exception:
                        continue
                    self._last_response_time = time.time()
                    output_buf = b""

                    if self.verbose:
                        msg = f"[auto-yes] responded '{resp}' (matched: {result.pattern})\n"
                        sys.stderr.write(msg)
        finally:
            if proc.isalive():
                proc.terminate()

        return proc.exitstatus or 0

    def _run_windows_pipe(self, command):
        """Minimal fallback using ``subprocess`` + threads (no PTY)."""
        import subprocess
        import threading

        env = os.environ.copy()
        env["AUTO_YES_ACTIVE"] = "1"

        use_shell = isinstance(command, str)
        proc = subprocess.Popen(
            command,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            env=env,
            shell=use_shell,
        )

        output_buf = bytearray()
        lock = threading.Lock()

        def _reader():
            assert proc.stdout is not None
            while True:
                byte = proc.stdout.read(1)
                if not byte:
                    break
                sys.stdout.buffer.write(byte)
                sys.stdout.buffer.flush()

                with lock:
                    output_buf.extend(byte)
                    if len(output_buf) > _BUFFER_LIMIT:
                        del output_buf[: len(output_buf) - _BUFFER_TRIM]

                    now = time.time()
                    result = self._detect_if_ready(bytes(output_buf), now)
                    if result is not None:
                        self._last_match_time = now
                        resp = result.suggested_response
                        if resp is None:
                            resp = self.response
                        try:
                            assert proc.stdin is not None
                            proc.stdin.write((resp + "\n").encode())
                            proc.stdin.flush()
                        except (OSError, BrokenPipeError):
                            pass
                        self._last_response_time = time.time()
                        output_buf.clear()

        reader_thread = threading.Thread(target=_reader, daemon=True)
        reader_thread.start()
        proc.wait()
        reader_thread.join(timeout=2)

        return proc.returncode or 0
