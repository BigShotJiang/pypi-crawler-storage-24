"""Command-line interface for auto-yes.

Usage (recommended)::

    auto-yes claude "fix tests"        wrap claude directly
    auto-yes cursor chat "fix bug"     wrap cursor agent CLI (runs ``agent``)
    auto-yes aider --model gpt-4      wrap aider with arguments
    auto-yes copilot                   wrap gh copilot

Usage (advanced)::

    auto-yes --on [OPTIONS]            start an auto-yes shell session
    auto-yes run [OPTIONS] -- CMD...   run a single command with auto-yes
    auto-yes list (-l, --list)         list all available CLI profiles
    auto-yes patterns [CATEGORY...]    list prompt patterns
    auto-yes add-pattern PATTERN       persist a custom pattern
    auto-yes del-pattern PATTERN       remove a custom pattern
"""

import argparse
import sys

from auto_yes import __version__
from auto_yes import config as _cfg
from auto_yes.patterns import (
    AI_CLI_NAMES,
    REGISTRY,
    available_categories,
    get_command,
    resolve_profile,
)
from auto_yes.runner import Runner

_PROG = "auto-yes"


# ------------------------------------------------------------------
# helpers
# ------------------------------------------------------------------


def _resolve_categories(cli_flags):
    """Turn the ``--cli`` flag values into a deduplicated category list.

    ``"all"`` expands to every registered category.
    ``"generic"`` is opt-in only (use ``--cli generic`` or ``--cli all``).
    """
    categories = []

    for name in cli_flags or []:
        if name == "all":
            for key in REGISTRY:
                if key not in categories:
                    categories.append(key)
        elif name in REGISTRY:
            if name not in categories:
                categories.append(name)
        else:
            print(
                f"warning: unknown CLI profile '{name}', ignored.  "
                f"available: {', '.join(sorted(REGISTRY))}",
                file=sys.stderr,
            )

    return categories


def _build_runner(opts, cfg):
    """Create a ``Runner`` from parsed CLI flags merged with persistent cfg."""
    auto_mode = getattr(opts, "auto", False)

    response = opts.response if opts.response is not None else cfg.get("response", "y")

    if auto_mode and opts.cooldown is None:
        cooldown = 0.05  # --auto: very short cooldown for batch operations
    else:
        cooldown = opts.cooldown if opts.cooldown is not None else cfg.get("cooldown", 0.5)

    delay = getattr(opts, "delay", None)
    if delay is None:
        delay = cfg.get("delay", 0.0)

    extra = list(cfg.get("custom_patterns", []))
    if hasattr(opts, "pattern") and opts.pattern:
        extra.extend(opts.pattern)

    cli_flags = getattr(opts, "cli", None) or []
    if auto_mode and not cli_flags:
        # --auto loads all AI profiles automatically
        cli_flags = ["all"]
    categories = _resolve_categories(cli_flags)

    log_file = getattr(opts, "log", None)

    verbose = opts.verbose or auto_mode
    quiet = getattr(opts, "quiet", False)

    heartbeat_opt = getattr(opts, "heartbeat", None)
    heartbeat = heartbeat_opt if heartbeat_opt is not None else cfg.get("heartbeat", 0.0)

    return Runner(
        response=response,
        cooldown=cooldown,
        verbose=verbose,
        categories=categories,
        extra_patterns=extra or None,
        delay=delay,
        log_file=log_file,
        quiet=quiet,
        heartbeat=heartbeat,
    )


def _make_opts_parser(prog):
    """Shared option flags for ``--on`` and ``run``."""
    parser = argparse.ArgumentParser(prog=prog, add_help=False)
    parser.add_argument("--response", default=None, help="text to send (default: y)")
    parser.add_argument(
        "--cooldown",
        type=float,
        default=None,
        help="seconds between auto-responses (default: 0.5)",
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="print a notice every time auto-yes responds",
    )
    parser.add_argument(
        "--pattern",
        action="append",
        default=[],
        help="additional regex pattern (repeatable)",
    )
    parser.add_argument(
        "--cli",
        action="append",
        default=[],
        help=f"AI CLI profile to load (repeatable, or 'all').  "
        f"choices: {', '.join(AI_CLI_NAMES)}",
    )
    parser.add_argument(
        "--log",
        default=None,
        help="write debug log to a file (raw output, cleaned text, detection events)",
    )
    parser.add_argument(
        "--delay",
        type=float,
        default=None,
        help="seconds to wait before auto-approving; "
        "press any key during the delay to cancel (default: 0 = immediate)",
    )
    parser.add_argument(
        "--auto",
        action="store_true",
        help="overnight/automation mode: load all AI profiles, use 0.05s cooldown, "
        "enable verbose.  Recommended for unattended loop runs.",
    )
    parser.add_argument(
        "--quiet", "-q",
        action="store_true",
        help="suppress all auto-yes output (no startup banner, no response notices)",
    )
    parser.add_argument(
        "--heartbeat",
        type=float,
        default=None,
        metavar="SECONDS",
        help="send Enter every N seconds of inactivity to keep agents responsive "
        "(e.g. --heartbeat 30).  0 = disabled (default)",
    )
    return parser


# ------------------------------------------------------------------
# sub-command handlers
# ------------------------------------------------------------------


def _handle_on(argv):
    parser = _make_opts_parser(f"{_PROG} --on")
    opts = parser.parse_args(argv)
    cfg = _cfg.load()
    runner = _build_runner(opts, cfg)

    response_display = opts.response or cfg.get("response", "y")
    loaded = _resolve_categories(opts.cli)
    import os as _os
    _pid = _os.getpid()
    print(f"\x1b[32m[auto-yes]\x1b[0m PID: \x1b[97m{_pid}\x1b[0m  (use 'auto-yes toggle {_pid}' to pause/resume from another terminal)")
    print(
        f"\x1b[32m[auto-yes]\x1b[0m session started. "
        f"prompts will be auto-responded with '{response_display}'."
    )
    print(f"\x1b[32m[auto-yes]\x1b[0m loaded profiles: {', '.join(loaded)}")
    print("\x1b[32m[auto-yes]\x1b[0m type 'exit' to end the session.")

    code = runner.run_shell()

    print("\n\x1b[32m[auto-yes]\x1b[0m session ended.")
    sys.exit(code)


def _handle_off():
    if _is_active():
        print(
            "\x1b[32m[auto-yes]\x1b[0m you are inside an auto-yes session. " "type 'exit' to leave."
        )
    else:
        print("\x1b[32m[auto-yes]\x1b[0m auto-yes is not active.")


def _handle_status():
    if _is_active():
        print("auto-yes: \x1b[32mactive\x1b[0m")
    else:
        print("auto-yes: \x1b[90minactive\x1b[0m")

    sessions = _cfg.list_sessions()
    if sessions:
        print(f"\nrunning sessions ({len(sessions)}):")
        for pid, info, paused in sessions:
            state = "\x1b[33mpaused\x1b[0m" if paused else "\x1b[32mactive\x1b[0m"
            elapsed = _format_elapsed(info.get("started", 0))
            profile = info.get("profile", "?")
            cmd = info.get("command", "?")
            print(f"  {pid:<8d} {profile:<12s} {state:<20s} {elapsed:>8s}  {cmd}")


def _handle_ls():
    sessions = _cfg.list_sessions()
    if not sessions:
        print("no running auto-yes sessions.")
        return

    print(
        f"  {'PID':<8s} {'PROFILE':<12s} {'STATUS':<10s} "
        f"{'UPTIME':>8s}  {'COMMAND'}"
    )
    print(
        f"  {'-' * 8:<8s} {'-' * 12:<12s} {'-' * 10:<10s} "
        f"{'-' * 8:>8s}  {'-' * 20}"
    )
    for pid, info, paused in sessions:
        state = "paused" if paused else "active"
        elapsed = _format_elapsed(info.get("started", 0))
        profile = info.get("profile") or "-"
        cmd = info.get("command", "?")
        print(f"  {pid:<8d} {profile:<12s} {state:<10s} {elapsed:>8s}  {cmd}")


def _handle_pause(argv):
    if not argv:
        print("usage: auto-yes pause <pid|all>", file=sys.stderr)
        sys.exit(1)

    target = argv[0]
    sessions = _cfg.list_sessions()

    if target == "all":
        if not sessions:
            print("no running sessions to pause.")
            return
        for pid, _info, _paused in sessions:
            _cfg.set_paused(pid, True)
        print(f"paused {len(sessions)} session(s).")
        return

    if not target.isdigit():
        print(f"error: '{target}' is not a valid PID or 'all'", file=sys.stderr)
        sys.exit(1)

    pid = int(target)
    live_pids = {p for p, _, _ in sessions}
    if pid not in live_pids:
        print(f"error: no running auto-yes session with PID {pid}", file=sys.stderr)
        sys.exit(1)

    _cfg.set_paused(pid, True)
    print(f"paused session {pid}.")


def _handle_continue(argv):
    if not argv:
        print("usage: auto-yes continue <pid|all>", file=sys.stderr)
        sys.exit(1)

    target = argv[0]
    sessions = _cfg.list_sessions()

    if target == "all":
        count = 0
        for pid, _info, paused in sessions:
            if paused:
                _cfg.set_paused(pid, False)
                count += 1
        if count:
            print(f"resumed {count} session(s).")
        else:
            print("no paused sessions.")
        return

    if not target.isdigit():
        print(f"error: '{target}' is not a valid PID or 'all'", file=sys.stderr)
        sys.exit(1)

    pid = int(target)
    live_pids = {p for p, _, _ in sessions}
    if pid not in live_pids:
        print(f"error: no running auto-yes session with PID {pid}", file=sys.stderr)
        sys.exit(1)

    _cfg.set_paused(pid, False)
    print(f"resumed session {pid}.")


def _format_elapsed(started):
    if not started:
        return "?"
    import time as _time

    delta = int(_time.time() - started)
    if delta < 60:
        return f"{delta}s"
    if delta < 3600:
        return f"{delta // 60}m"
    return f"{delta // 3600}h{(delta % 3600) // 60}m"


def _handle_run(argv):
    if "--" in argv:
        idx = argv.index("--")
        our_argv = argv[:idx]
        cmd_argv = argv[idx + 1 :]
    else:
        our_argv = []
        cmd_argv = argv

    if not cmd_argv:
        print("error: no command specified", file=sys.stderr)
        print(f"usage: {_PROG} run [OPTIONS] -- COMMAND...", file=sys.stderr)
        sys.exit(1)

    parser = _make_opts_parser(f"{_PROG} run")
    opts = parser.parse_args(our_argv)
    cfg = _cfg.load()
    runner = _build_runner(opts, cfg)

    code = runner.run_command(cmd_argv)
    sys.exit(code)


def _handle_patterns(argv):
    """List patterns, optionally filtered to specific categories."""
    cfg = _cfg.load()
    custom = cfg.get("custom_patterns", [])

    if argv:
        show_categories = argv
    else:
        show_categories = list(REGISTRY.keys())

    for name in show_categories:
        if name not in REGISTRY:
            print(f"unknown category: {name}", file=sys.stderr)
            continue

        entry = REGISTRY[name]
        pats = entry["patterns"]
        print(f"[{name}] {entry['description']} ({len(pats)})")
        if not pats:
            print("  (none)")
        for src, resp in pats:
            tag = f" -> '{resp}'" if resp is not None else ""
            print(f"  {src}{tag}")
        print()

    if custom:
        print(f"[custom] user-defined ({len(custom)})")
        for pat in custom:
            print(f"  {pat}")
        print()


def _handle_list():
    """List all available CLI profiles with description and pattern count."""
    print("available CLI profiles:\n")
    print(
        f"  {'PROFILE':<12s} {'COMMAND':<16s} "
        f"{'DESCRIPTION':<35s} {'PATTERNS':>8s}"
    )
    print(
        f"  {'-' * 12:<12s} {'-' * 16:<16s} "
        f"{'-' * 35:<35s} {'-' * 8:>8s}"
    )

    for name, desc in available_categories():
        count = len(REGISTRY[name]["patterns"])
        cmd = " ".join(get_command(name)) if name != "generic" else "-"
        marker = " (opt-in)" if name == "generic" else ""
        print(
            f"  {name:<12s} {cmd:<16s} "
            f"{desc:<35s} {count:>8d}{marker}"
        )

    total = sum(len(e["patterns"]) for e in REGISTRY.values())
    print(f"\n  {len(REGISTRY)} categories, {total} patterns total")
    print(
        "\ntip: run 'auto-yes <profile> [args...]' to wrap a tool directly "
        "(recommended)"
    )
    print("     e.g. auto-yes cursor chat 'fix the bug'")


def _handle_wrap(profile, argv):
    """Shorthand: ``auto-yes claude "fix tests"`` wraps the CLI tool directly.

    Equivalent to ``auto-yes run -v --cli <profile> -- <binary> <argv...>``.
    The real binary name is looked up from the REGISTRY ``command`` field.
    Verbose is on by default so users can see auto-yes in action.
    """
    log_file = None
    heartbeat = None
    filtered_argv = list(argv)
    if "--log" in filtered_argv:
        idx = filtered_argv.index("--log")
        if idx + 1 < len(filtered_argv):
            log_file = filtered_argv[idx + 1]
            del filtered_argv[idx : idx + 2]
    if "--heartbeat" in filtered_argv:
        idx = filtered_argv.index("--heartbeat")
        if idx + 1 < len(filtered_argv):
            try:
                heartbeat = float(filtered_argv[idx + 1])
            except ValueError:
                pass
            del filtered_argv[idx : idx + 2]
    argv = filtered_argv

    cfg = _cfg.load()
    response = cfg.get("response", "y")
    cooldown = cfg.get("cooldown", 0.5)
    delay = cfg.get("delay", 0.0)
    if heartbeat is None:
        heartbeat = cfg.get("heartbeat", 0.0)

    extra = list(cfg.get("custom_patterns", []))

    categories = _resolve_categories([profile])

    runner = Runner(
        response=response,
        cooldown=cooldown,
        verbose=True,
        categories=categories,
        extra_patterns=extra or None,
        delay=delay,
        profile=profile,
        log_file=log_file,
        heartbeat=heartbeat,
    )

    real_cmd = get_command(profile)

    if "--" in argv:
        idx = argv.index("--")
        cmd_argv = argv[idx + 1:]
    else:
        cmd_argv = real_cmd + list(argv)

    if not cmd_argv:
        cmd_argv = real_cmd

    cmd_display = " ".join(real_cmd)
    loaded = ", ".join(categories)
    import os as _os
    _pid = _os.getpid()
    print(f"\x1b[32m[auto-yes]\x1b[0m PID: \x1b[97m{_pid}\x1b[0m  toggle: auto-yes toggle {_pid}")
    print(
        f"\x1b[32m[auto-yes]\x1b[0m wrapping '{cmd_display}' "
        f"with profile: {loaded}"
    )

    code = runner.run_command(cmd_argv)
    sys.exit(code)


def _handle_toggle(argv):
    """Pause if active, resume if paused — for human-in-loop control."""
    if not argv:
        print("usage: auto-yes toggle <pid|all>", file=sys.stderr)
        sys.exit(1)
    target = argv[0]
    sessions = _cfg.list_sessions()
    if target == "all":
        if not sessions:
            print("no running sessions.")
            return
        for pid, _info, paused in sessions:
            _cfg.set_paused(pid, not paused)
            action = "resumed" if paused else "paused"
            print(f"  {action} session {pid}")
        return
    if not target.isdigit():
        print(f"error: '{target}' is not a valid PID or 'all'", file=sys.stderr)
        sys.exit(1)
    pid = int(target)
    live_pids = {p for p, _, _ in sessions}
    if pid not in live_pids:
        print(f"error: no running auto-yes session with PID {pid}", file=sys.stderr)
        sys.exit(1)
    _, _, paused = next((p, i, pa) for p, i, pa in sessions if p == pid)
    _cfg.set_paused(pid, not paused)
    action = "resumed" if paused else "paused"
    print(f"{action} session {pid}.")


def _handle_add_pattern(argv):
    if not argv:
        print("error: provide a regex pattern string", file=sys.stderr)
        sys.exit(1)
    pattern = argv[0]
    _cfg.add_pattern(pattern)
    print(f"added pattern: {pattern}")


def _handle_del_pattern(argv):
    if not argv:
        print("error: provide a regex pattern string", file=sys.stderr)
        sys.exit(1)
    pattern = argv[0]
    cfg = _cfg.remove_pattern(pattern)
    if pattern not in cfg.get("custom_patterns", []):
        print(f"removed pattern: {pattern}")
    else:
        print(f"pattern not found: {pattern}")


def _is_active():
    import os

    return os.environ.get("AUTO_YES_ACTIVE") == "1"


# ------------------------------------------------------------------
# help / banner
# ------------------------------------------------------------------

# retro-futuristic banner: bright→dim cyan for AUTO, bright→dim magenta for YES
_BANNER = (
    "\n"
    "  \x1b[96m▄▀█ █ █ ▀█▀ █▀█\x1b[0m  \x1b[90m//\x1b[0m  \x1b[95m█▄█ █▀▀ █▀\x1b[0m\n"
    "  \x1b[36m█▀█ █▄█  █  █▄█\x1b[0m  \x1b[90m//\x1b[0m  \x1b[35m █  ██▄ ▄█\x1b[0m\n"
    f"  \x1b[90m{'━' * 31}\x1b[0m\n"
    f"  \x1b[93mv{__version__}\x1b[0m \x1b[90m·\x1b[0m auto-respond to CLI prompts\n"
)

_HELP = f"""\
{_BANNER}
\x1b[1m\x1b[97mQUICK START\x1b[0m
  {_PROG} claude "fix the tests"           wrap claude (auto-responds all prompts)
  {_PROG} cursor chat "fix bug"            wrap cursor agent CLI
  {_PROG} run --auto -- ./overnight.sh     unattended automation (all profiles, fast)

\x1b[1m\x1b[97mCOMMANDS\x1b[0m
  {_PROG} <profile> [ARGS...]    Wrap an AI CLI tool directly — recommended.
                                  Profile is mapped to the real binary automatically.
                                  Run '{_PROG} list' to see all profiles.

  {_PROG} shell [OPTIONS]        Start an interactive shell session where every
                                  prompt is auto-responded. Type 'exit' to end.

  {_PROG} run [OPTIONS]          Run a single command with auto-yes.
    -- CMD...                     Use '--' to separate auto-yes options from CMD.

\x1b[1m\x1b[97mSESSION CONTROL\x1b[0m  (control a running auto-yes from another terminal)
  {_PROG} ls                     List all running auto-yes sessions with PID
  {_PROG} toggle <pid|all>       Pause if active, resume if paused  ← recommended
  {_PROG} pause  <pid|all>       Pause auto-responses (prompts pass through)
  {_PROG} continue <pid|all>     Resume auto-responses
  {_PROG} status                 Check if auto-yes is active in current shell

\x1b[1m\x1b[97mINFO COMMANDS\x1b[0m
  {_PROG} list, -l               List all AI CLI profiles and their pattern counts
  {_PROG} patterns [CAT...]      Show prompt patterns (all or filtered by category)
  {_PROG} add-pattern REGEX      Persist a custom prompt pattern
  {_PROG} del-pattern REGEX      Remove a custom prompt pattern

\x1b[1m\x1b[97mOPTIONS\x1b[0m  (for 'shell' and 'run')
  --auto               Overnight mode: all profiles, 0.05s cooldown, verbose
  --cli NAME           AI CLI profile to load (repeatable, or 'all')
                       choices: {', '.join(AI_CLI_NAMES)}
  --response TEXT      Text to send when a prompt is detected  (default: y)
  --cooldown FLOAT     Seconds between auto-responses           (default: 0.5)
  --delay FLOAT        Seconds to wait before approving — press any key to cancel
  --heartbeat SECONDS  Send Enter every N seconds of inactivity (e.g. --heartbeat 30)
  --verbose, -v        Show each auto-response as it happens
  --quiet, -q          Suppress all auto-yes output
  --pattern REGEX      Extra prompt pattern, repeatable
  --log FILE           Write debug log: raw bytes, cleaned text, detection events

\x1b[1m\x1b[97mEXAMPLES\x1b[0m
  # Wrap an AI tool (simplest, recommended)
  \x1b[96m{_PROG} claude "fix the tests"\x1b[0m
  \x1b[96m{_PROG} cursor chat "add unit tests"\x1b[0m
  \x1b[96m{_PROG} aider --model gpt-4o\x1b[0m

  # Overnight automation (unattended, all profiles)
  \x1b[96m{_PROG} run --auto -- claude "work through the backlog"\x1b[0m

  # Interactive shell session (claude + generic patterns)
  \x1b[36m{_PROG} shell --cli claude --cli generic\x1b[0m

  # Human-in-loop: pause auto-yes from another terminal
  \x1b[36m{_PROG} ls\x1b[0m                              # find the PID
  \x1b[36m{_PROG} toggle 12345\x1b[0m                    # pause it
  \x1b[36m{_PROG} toggle 12345\x1b[0m                    # resume it

  # Debug: see exactly what auto-yes is doing
  \x1b[36m{_PROG} run --cli claude -v --log debug.log -- claude "task"\x1b[0m
"""


# ------------------------------------------------------------------
# entry point
# ------------------------------------------------------------------


def main(argv=None):
    if argv is None:
        argv = sys.argv[1:]

    if not argv or argv[0] in ("-h", "--help"):
        print(_HELP)
        return

    if argv[0] in ("--version", "-V"):
        print(f"{_PROG} {__version__}")
        return

    cmd = argv[0]
    rest = argv[1:]

    dispatch = {
        "--on": lambda: _handle_on(rest),
        "on": lambda: _handle_on(rest),
        "shell": lambda: _handle_on(rest),
        "--off": _handle_off,
        "off": _handle_off,
        "status": _handle_status,
        "run": lambda: _handle_run(rest),
        "list": _handle_list,
        "-l": _handle_list,
        "--list": _handle_list,
        "ls": _handle_ls,
        "pause": lambda: _handle_pause(rest),
        "continue": lambda: _handle_continue(rest),
        "toggle": lambda: _handle_toggle(rest),
        "patterns": lambda: _handle_patterns(rest),
        "add-pattern": lambda: _handle_add_pattern(rest),
        "del-pattern": lambda: _handle_del_pattern(rest),
    }

    handler = dispatch.get(cmd)
    if handler is not None:
        handler()
        return

    # if cmd matches a known AI CLI profile (by name or binary), use wrap mode
    profile = resolve_profile(cmd)
    if profile is not None:
        _handle_wrap(profile, rest)
        return

    print(f"unknown command: {cmd}", file=sys.stderr)
    print(_HELP, file=sys.stderr)
    sys.exit(1)
