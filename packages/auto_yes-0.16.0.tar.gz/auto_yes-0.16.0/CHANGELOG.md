# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.16.0] - 2026-03-19

### Added

- `--heartbeat SECONDS` flag: automatically send Enter every N seconds of inactivity to keep
  Claude / Cursor Agent (and any other AI CLI tool) responsive when they are waiting for input.
  Works with `--on` / `shell`, `run`, and direct wrap mode (e.g. `auto-yes claude --heartbeat 30 "task"`).
  The timer resets on every real user keystroke so it never interrupts interactive typing.
  Disabled by default (`0`); can also be persisted in config via the `heartbeat` key.

## [0.15.0] - 2026-03-19

### Fixed

- Skip Unix-only tests (`TestReapChild`, `test_response_count_increments`) on Windows CI
  to resolve `ModuleNotFoundError: No module named 'termios'` and `AttributeError: module 'os' has no attribute 'fork'`
- CI now passes clean on all 12 matrix combinations: py3.10–3.13 × Linux / macOS / Windows

### Changed

- `pyproject.toml` version synced with `__init__.py` (was still at 0.13.0)

## [0.14.0] - 2026-03-19

### Added

- `auto-yes toggle <pid|all>`: single command to pause if active or resume if paused — recommended for human-in-loop control from a second terminal.
- `auto-yes shell`: alias for `--on`/`on`, starts an interactive shell session with auto-yes.
- `--quiet` / `-q` flag: suppress all `[auto-yes]` output (no startup banner, no per-response notices). Useful for scripting or when terminal noise is unwanted.
- Runner startup banner (verbose mode): prints PID, active patterns preview, cooldown, and response character when the session begins.
- Runner exit summary (verbose mode): prints session uptime and total auto-responded prompt count when the session ends.
- Runner `pid` property: exposes the process PID for programmatic access.
- PID display in `shell` and wrap modes: prints `auto-yes toggle <pid>` hint at startup so users know how to pause from another terminal.

### Changed

- `Runner.__init__` gains `quiet=False` parameter; when `True` forces `verbose=False` and suppresses all terminal output.
- Help text fully restructured with sections QUICK START, COMMANDS, SESSION CONTROL, INFO COMMANDS, OPTIONS, and EXAMPLES.

## [0.13.0] - 2026-03-19

### Added

- `--auto` flag: overnight/automation mode loads all AI profiles, sets 0.05s cooldown, enables verbose logging. Ideal for unattended loop runs in corporate environments where `--dangerously-skip-permissions` is restricted.
- Claude Code 2.x full compatibility: fixed two critical bugs preventing detection of real Claude Code ≥ 2.x TUI prompts.
- `--log` option: write debug log to a file with raw output, cleaned text, and detection events.

### Fixed

- **CRITICAL** Claude Code 2.x TUI cursor-forward sequences (`ESC[nC`) are now expanded to `n` spaces before ANSI stripping, restoring word separators in menus rendered without literal spaces.
- **CRITICAL** Claude Code 2.x `\r\r\n` line terminators: `clean_text()` now selects the last *non-empty* carriage-return segment per line, preventing content loss when lines end with a bare `\r`.
- Claude Code patterns expanded: added `❯ Allow for this session`, `❯ 1. Allow once`, `❯ 3. Always allow for this project`, `Do you want to proceed?`, and numbered/unnumbered Allow catch-alls.
- Runner null byte filtering: null bytes in PTY output are stripped before feeding the detection buffer, preventing decode errors on some terminal emulators.
- Runner grandchild reaper: `SIGCHLD` handler reaps zombie grandchildren (spawned subagents) to prevent PID table accumulation in overnight loops.
- Runner graceful shutdown: `SIGTERM`/`SIGINT` forwarded to child process for clean teardown instead of abrupt kill.
- Runner EIO handling: added explanatory comment and `_drain_pty` call before breaking on `EIO` (normal Linux PTY teardown path).

### Changed

- Test suite expanded from 219 to 270 tests:
  - Stress tests: 1 000+ rapid-prompt iterations, 1 MB buffer, encoding edge cases, ANSI bombs, false-positive gauntlet, concurrency.
  - Integration scenarios: 5 parallel agents, 10-iteration overnight loop, `--auto` flag end-to-end verification.
  - Runner hardening unit tests: timing guards, escape-sequence classification, child reaping.
  - Pattern completeness: every pattern in every category has a test that fires it.

## [0.12.0] - 2026-03-03

### Summary

Consolidated release incorporating all fixes and features from 0.10.x–0.11.x.

## [0.11.3] - 2026-03-03

### Fixed

- Consecutive prompts missed: `buf_dirty` flag was reset even when timing guards (cooldown) blocked detection, causing buffered prompts to never be re-checked
- Split `_detect_if_ready()` into `_timing_allows()` guard + inline detection; `buf_dirty` now stays True until detection actually runs

## [0.11.2] - 2026-03-03

### Fixed

- Claude Code patterns now match both ASCII `>` and Unicode `❯` (U+276F) via `[>❯]`; Claude Code uses `❯` as the selection indicator but patterns only had `>`
- Claude `❯ N. Yes` pattern generalised to any numbered option (`\d+`) not just `1`

## [0.11.1] - 2026-03-03

### Changed

- Output buffer changed from `bytes` to `bytearray` for in-place append (no full-buffer copy on each chunk)
- Added dirty flag to skip decode + regex processing when no new output arrived
- Moved `is_paused()` file check after timing guards to avoid unnecessary syscalls during cooldown

## [0.11.0] - 2026-03-03

### Added

- Session management: `auto-yes ls` lists running sessions with PID, profile, status, uptime
- `auto-yes pause <pid|all>` pauses auto-yes for a running session
- `auto-yes continue <pid|all>` resumes a paused session
- Session registry via PID files under `~/.config/auto-yes/sessions/`
- Stale session cleanup: dead PIDs are removed automatically on `ls`
- `status` command now shows running sessions

## [0.10.2] - 2026-03-03

### Fixed

- Cursor Agent: send just `\r` (Enter) instead of `y\r` for `(y)` prompts; the positive option is pre-selected by `→`, only Enter is needed to confirm

## [0.10.1] - 2026-03-03

### Added

- Full-buffer prompt matching: detect() now scans all non-empty lines (bottom-up) instead of only the last line, fixing missed multi-line menu prompts
- Typing suppress (1s): after a real user keystroke, suppress detection to prevent echo false positives
- Match cooldown (50ms): suppress re-triggers caused by terminal redraws
- Buffer clear on user input: discard stale output buffer when user types, preventing stale prompt re-matches
- Escape sequence filtering: distinguish terminal-generated sequences (focus events, cursor position reports) from real user keystrokes
- `--delay` option: queue pending response with configurable delay; press any key during the delay to cancel
- `_is_escape_sequence()` utility function for terminal event detection

### Fixed

- `clean_text()` now normalises `\r\n` to `\n` before processing bare `\r` overwrites; previously `\r\n` line endings (standard PTY output) caused all visible text to be discarded, breaking detection for every TUI program
- Send `\r` (CR) instead of `\n` (LF) when injecting responses into the PTY; TUI applications (Cursor Agent, Claude Code, etc.) run in raw mode where only CR is recognised as Enter
- Cursor Agent `Trust this workspace` pattern now sends `a` (the actual hotkey) instead of the default `y`

### Changed

- `Runner.__init__()` accepts new `delay` parameter (default: 0.0)
- `_run_unix()` proxy loop fully refactored with enhanced timing guards
- `_maybe_respond_unix()` split into `_detect_if_ready()`, `_send_response_unix()`, and `_log_unix()`
- Windows PTY and pipe implementations now use shared `_detect_if_ready()` timing guards

## [0.9.0] - 2026-02-27

### Added

- Cursor Agent CLI: `Skip (esc or n)` pattern for approval dialog last-line detection
- Cursor Agent CLI: support `→ Run (once) (y)` variant without `(enter)` suffix
- Generic: `need to ...?`, `require(d/s) ...?`, `necessary ...?` prompt patterns
- CI/CD: `publish.yml` workflow for automated PyPI release on version tags
- CI: `workflow_call` trigger so publish workflow can reuse full CI as gate

### Fixed

- Cursor Agent CLI: approval dialog was missed when `Skip (esc or n)` was the last visible line

## [0.1.0] - 2025-02-27

### Added

- PTY proxy runner with transparent I/O forwarding (Unix `pty` + `select`)
- Windows support via `pywinpty` with subprocess pipe fallback
- Smart prompt detection on the last visible line (avoids false positives)
- 25 built-in generic patterns (`[y/n]`, `Continue?`, `Are you sure?`, etc.)
- Categorized AI CLI profiles: Claude, Gemini, Codex, Copilot, Cursor, Grok, Auggie, Amp, Qwen
- `auto-yes --on` interactive shell session mode
- `auto-yes run -- CMD` single-command wrapper mode
- `auto-yes patterns [CATEGORY...]` pattern inspection
- `auto-yes add-pattern` / `del-pattern` persistent custom patterns
- Persistent configuration at `~/.config/auto-yes/config.json`
- ANSI escape code stripping for clean pattern matching
- Cooldown timer to prevent duplicate responses
- SIGWINCH forwarding for terminal resize propagation
- `--cli NAME` flag to load AI-tool-specific patterns
- `--verbose` mode showing each auto-response
- PEP 561 `py.typed` marker

[Unreleased]: https://github.com/clemente0731/auto-yes/compare/v0.12.0...HEAD
[0.12.0]: https://github.com/clemente0731/auto-yes/compare/v0.11.3...v0.12.0
[0.11.3]: https://github.com/clemente0731/auto-yes/compare/v0.11.2...v0.11.3
[0.11.2]: https://github.com/clemente0731/auto-yes/compare/v0.11.1...v0.11.2
[0.11.1]: https://github.com/clemente0731/auto-yes/compare/v0.11.0...v0.11.1
[0.11.0]: https://github.com/clemente0731/auto-yes/compare/v0.10.2...v0.11.0
[0.10.2]: https://github.com/clemente0731/auto-yes/compare/v0.10.1...v0.10.2
[0.10.1]: https://github.com/clemente0731/auto-yes/compare/v0.9.0...v0.10.1
[0.9.0]: https://github.com/clemente0731/auto-yes/compare/v0.1.0...v0.9.0
[0.1.0]: https://github.com/clemente0731/auto-yes/releases/tag/v0.1.0
