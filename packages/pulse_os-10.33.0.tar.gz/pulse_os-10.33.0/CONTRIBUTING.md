# Contributing to PULSE

Thank you for your interest in improving PULSE!

## How PULSE Works
PULSE is a Neural Operating System for AI Swarms. It uses an Autonomic System (daemons and tools), a Hippocampus (long-term memory), and a Prefrontal Cortex (task orchestration) to enable multiple AI agents to work together via a shared task board and constitutional governance.

## Development Setup
1. **Clone the repo:** `git clone https://github.com/Honesty0x/PULSE.git`
2. **Install dependencies:** `pip install -r requirements.txt`
3. **Configure environment:** Copy `.env.example` to `.env` and add your API keys.
4. **Verify installation:** Run `python tests/smoke_test.py`

## Adding a New Daemon
1. Create your Python script in `pulse/daemons/`.
2. Use `brain_utils` for shared state/board access.
3. Register your daemon in `pulse/daemons/orchestrator.py` to include it in the orchestrator boot sequence.

## Adding a New Skill
Skills are stored as Markdown files in `.cursor/skills/<domain>/`. Create a new `.md` file with clear instructions and examples for agents to follow when working in that domain.

## Code Style
- **Python Version:** 3.9+
- **Typing:** Use type hints for all function signatures.
- **Docstrings:** Required for all public functions and classes.
- **Structure:** Mimic the existing architecture (modular, path-guarded).

## Pull Request Process
1. Create a feature branch from `main`.
2. Implement your changes and add tests if applicable.
3. Ensure all tests pass: `python tests/smoke_test.py`.
4. Submit PR with a clear description of WHY and WHAT was changed.
