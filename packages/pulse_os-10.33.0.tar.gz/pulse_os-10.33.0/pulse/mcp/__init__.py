# PULSE MCP Server — exposes brain capabilities via Model Context Protocol.
