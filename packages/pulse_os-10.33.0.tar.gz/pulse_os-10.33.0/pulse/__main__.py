"""Allow running PULSE as: python -m pulse"""
from pulse.cli.main import main

main()
