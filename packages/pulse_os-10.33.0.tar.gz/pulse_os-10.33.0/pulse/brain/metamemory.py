"""
Phase 3B: Metamemory Module

Computes a domain-level confidence map based on database knowledge.
Identifies gaps and evaluates overall epistemic certainty per domain.
"""
import json
from datetime import datetime, timezone
from pulse.core.paths import get_state_dir
from pulse.core.brain_db import get_conn
from pulse.core.uncertainty import wilson_interval
from pulse.core.temporal import _days_since

METAMEMORY_FILE = get_state_dir() / "memory" / "metamemory_map.json"

def compute_metamemory() -> dict:
    """Computes and saves domain-level confidence map."""
    conn = get_conn()
    tables = ["lessons", "failures", "patterns", "facts"]
    
    domain_stats = {}
    
    with conn:
        for table in tables:
            # Query aggregates per domain
            res = conn.execute(f"""
                SELECT domain, 
                       COUNT(*) as item_count, 
                       AVG(confidence) as avg_conf,
                       SUM(evidence_count) as total_evidence,
                       MAX(timestamp) as latest_ts
                FROM {table}
                WHERE validity = 'valid'
                GROUP BY domain
            """)
            
            for row in res:
                d = row["domain"]
                if not d:
                    continue
                if d not in domain_stats:
                    domain_stats[d] = {
                        "item_count": 0,
                        "sum_conf": 0.0,
                        "total_evidence": 0,
                        "latest_ts": None
                    }
                
                ds = domain_stats[d]
                ds["item_count"] += row["item_count"]
                ds["sum_conf"] += (row["avg_conf"] * row["item_count"])
                ds["total_evidence"] += row["total_evidence"]
                
                # track newest timestamp
                ts = row["latest_ts"]
                if ts:
                    if not ds["latest_ts"] or ts > ds["latest_ts"]:
                        ds["latest_ts"] = ts

    # Finalize calculations
    metamemory_map = {}
    for d, stats in domain_stats.items():
        if stats["item_count"] == 0:
            continue
            
        avg_confidence = stats["sum_conf"] / stats["item_count"]
        lo, _ = wilson_interval(avg_confidence, stats["total_evidence"])
        staleness = _days_since(stats["latest_ts"]) if stats["latest_ts"] else 999
        
        # Coverage score heuristic: more items = better coverage, up to a limit
        coverage_score = min(1.0, stats["item_count"] / 50.0) 
        
        gap_flag = False
        if lo < 0.3 or staleness > 60 or coverage_score < 0.2:
            gap_flag = True

        # Competence level based on Wilson lower bound
        if lo > 0.8:
            competence_level = "expert"
        elif lo > 0.5:
            competence_level = "competent"
        elif lo > 0.2:
            competence_level = "novice"
        else:
            competence_level = "blind_spot"

        metamemory_map[d] = {
            "item_count": stats["item_count"],
            "avg_confidence": round(avg_confidence, 3),
            "wilson_lower": round(lo, 3),
            "coverage_score": round(coverage_score, 3),
            "staleness_days": round(staleness, 1),
            "gap_flag": gap_flag,
            "competence_level": competence_level,
        }
        
    METAMEMORY_FILE.parent.mkdir(parents=True, exist_ok=True)
    from pulse.core.brain_io import _acquire
    with _acquire(METAMEMORY_FILE):
        with open(METAMEMORY_FILE, "w", encoding="utf-8") as f:
            json.dump(metamemory_map, f, indent=2)
        
    return metamemory_map

def get_metamemory() -> dict:
    """Loads the latest metamemory map."""
    if not METAMEMORY_FILE.exists():
        return {}
    try:
        with open(METAMEMORY_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}
