#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""
Agent Boot Briefing: Load and format brain knowledge for injection.

(This module delegates to pulse/brain/boot/ for strict Separation of Concerns)
"""
from __future__ import annotations

from .boot.loaders import load_recent_brain, load_relevant_brain, _search_brain_for_task as search_brain_for_task, load_daemon_injections, load_curriculum
from .boot.formatters import build_brain_briefing

__all__ = ["load_recent_brain", "load_relevant_brain", "search_brain_for_task", "load_daemon_injections", "load_curriculum", "build_brain_briefing"]
