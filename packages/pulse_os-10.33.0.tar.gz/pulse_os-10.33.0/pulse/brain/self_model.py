"""
Phase 3C: Self-Model

Capabilities inventory + performance metrics + current operational state.
"""
from pulse.brain.metamemory import get_metamemory
import pulse.core.interoception as interoception
from pulse.admin.audit.agent_trust import _load_trust

def get_self_model() -> dict:
    """Constructs the explicit representation of the system's own capabilities."""
    
    # 1. Metamemory Gaps
    meta = get_metamemory()
    low_confidence_domains = [d for d, s in meta.items() if s.get("gap_flag")]
    
    # 2. Agent Trust
    trust_data = _load_trust().get("agents", {})
    
    # 3. System Health
    health = {}
    interoception.load_signals()
    if interoception._signals:
        for k, v in interoception._signals.items():
            health[k] = v.get("current_value", 0.0)
            
    # 4. Capabilities (Mocked from config or fixed for now)
    capabilities = {
        "read_code": True,
        "write_code": True,
        "run_tests": True,
        "search_web": False # example limitation
    }
            
    return {
        "identity": "PULSE OS",
        "health": health,
        "capabilities": capabilities,
        "trusted_agents": trust_data,
        "knowledge_gaps": low_confidence_domains,
        "limitations": [
            "Cannot directly observe human emotional state.",
            "Operates via asynchronous file-based swarm execution.",
            f"Currently has low confidence in domains: {', '.join(low_confidence_domains)}" if low_confidence_domains else "No critical knowledge gaps detected."
        ]
    }
