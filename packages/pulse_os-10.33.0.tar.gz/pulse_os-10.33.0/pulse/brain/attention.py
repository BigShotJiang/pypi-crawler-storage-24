"""
Phase 3A: Goal-conditioned attention vectors.
Weights search sources based on task type or context priorities.
"""

def get_attention_weights(task_type: str = "general") -> dict:
    """
    Returns multipliers for 15 search sources based on task type.
    Baseline is 1.0.
    """
    weights = {
        "hot_cache": 1.0,
        "index": 1.0,
        "predictions": 1.0,
        "anti_patterns": 1.0,
        "graph": 1.0,
        "facts": 1.0,
        "episodic": 1.0,
        "working_memory": 1.0,
        "decisions": 1.0,
        "wins": 1.0,
        "fails": 1.0,
        "domains": 1.0,
        "patterns": 1.0,
        "evidence": 1.0,
        "private": 1.0,
        "schemas": 1.0,
        "procedures": 1.0
    }
    
    task_type = str(task_type).lower()
    
    if "debug" in task_type or "fix" in task_type:
        weights["fails"] = 1.5
        weights["anti_patterns"] = 1.5
        weights["predictions"] = 1.5
        weights["episodic"] = 1.2
        
    elif "arch" in task_type or "design" in task_type:
        weights["schemas"] = 1.5
        weights["procedures"] = 1.5
        weights["graph"] = 1.5
        weights["patterns"] = 1.2
        
    elif "feature" in task_type or "impl" in task_type:
        weights["patterns"] = 1.3
        weights["wins"] = 1.3
        # In reality DMN is not a standard search source, but we boost relevant concepts
        weights["procedures"] = 1.3
        
    elif "review" in task_type or "audit" in task_type:
        weights["anti_patterns"] = 1.5
        weights["decisions"] = 1.5
        weights["fails"] = 1.2
        
    return weights

def apply_attention_to_results(results: dict, task_type: str) -> dict:
    """Applies attention weights to salience/confidence scores in search results."""
    weights = get_attention_weights(task_type)
    
    for source, hits in results.get("results", {}).items():
        if not isinstance(hits, list):
            continue
            
        weight = weights.get(source, 1.0)
        if weight == 1.0:
            continue
            
        for hit in hits:
            # We bump salience and recalculate the effective rank/confidence
            # Just keeping it simple: boost salience temporarily for this query context
            if "salience" in hit:
                hit["_attention_salience"] = float(hit["salience"]) * weight
            if "confidence" in hit:
                hit["_attention_confidence"] = min(1.0, float(hit["confidence"]) * weight)
                
    return results