#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
# See LICENSE file for details.
"""
Consolidation Daemon: Cross-session pattern mining + schema promotion.

Main orchestration loop. Stages are in consolidation_stages.py (Law 7 split).

Six stages:
  1. Dedup: Run existing pulse_dedup logic (text similarity merging)
  2. Pattern Mining: Find recurring sequences across past 7 days
  3. Schema Promotion: Promote high-confidence patterns to schemas.json
  4. Graph Update: Rebuild knowledge graph from current brain state
  5. Metacognitive Audit: Flag vague/unused/contradicted items
  6. Hierarchical Prune: Miller's Law 4±1 enforcement (Q8 Neural Hardening)

Runs every 6 hours via orchestrator.

Dependencies: Python stdlib + brain_utils (internal)
"""
import io
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

if os.name == 'nt' and __name__ == '__main__':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

SCRIPT_DIR = Path(__file__).resolve().parent
ROOT_DIR = SCRIPT_DIR.parent.parent.parent

# When run directly, ensure pulse package is importable
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from pulse.core.brain_utils import HIPPOCAMPUS_DIR, save_json, now_iso as _now_iso
from pulse.daemons.consolidation.consolidation_stages import (
    stage_dedup,
    stage_pattern_mining,
    stage_schema_promotion,
    stage_schema_promotion_from_sequences,
    register_discovered_procedures,
    stage_ltd_decay,
    stage_graph_update,
    stage_reconsolidation,
    stage_cross_domain_transfer,
    stage_promote_to_patterns,
    stage_metacognitive_audit,
    stage_hierarchical_prune,
    stage_truth_verification,
)

CONSOLIDATION_LOG = HIPPOCAMPUS_DIR / "Evidence" / "Metrics" / "consolidation_log.json"


# === MAIN CONSOLIDATION ===

def run_consolidation(verbose=False):
    """Run full 4-stage consolidation pipeline.

    Orchestrates all consolidation stages from consolidation_stages.py.
    Logs results to consolidation_log.json.
    """
    print("[CONSOLIDATION] Starting 4-stage consolidation...")
    start = time.time()

    # Stage 1: Dedup
    print("[CONSOLIDATION] Stage 1: Deduplication")
    dedup_result = stage_dedup(verbose=verbose)

    # Stage 1b: EchoRefine (D19 — cross-ref golden paths + constraints)
    print("[CONSOLIDATION] Stage 1b: EchoRefine Synthesis")
    try:
        from pulse.daemons.synthesis.echo_refine import run_once as echorefine_once
        echo_result = echorefine_once(verbose=verbose)
        if verbose:
            print(f"  [ECHOREFINE] {echo_result.get('entries', 0)} scanned, "
                  f"{echo_result.get('golden_aligned', 0)} aligned, "
                  f"{echo_result.get('constraint_conflicts', 0)} conflicts")
    except Exception as e:
        if verbose:
            print(f"  [ECHOREFINE] Skipped: {e}")

    # Stage 2: Pattern Mining
    print("[CONSOLIDATION] Stage 2: Pattern Mining")
    mining_result = stage_pattern_mining(verbose=verbose)

    # Stage 2b: Register discovered procedures (Fix 4)
    sequences = mining_result.get("sequences", [])
    print("[CONSOLIDATION] Stage 2b: Register Discovered Procedures")
    proc_count = register_discovered_procedures(sequences, verbose=verbose)

    # Verify procedure persistence
    proc_log = HIPPOCAMPUS_DIR / "Evidence" / "Metrics" / "procedural_log.json"
    if proc_log.exists():
        from pulse.core.brain_utils import load_json
        proc_data = load_json(proc_log)
        actual_count = len(proc_data) if isinstance(proc_data, list) else 0
        if verbose:
            print(f"  [PROCEDURES] Verified: {actual_count} procedures on disk")
    elif proc_count > 0:
        print(f"  [PROCEDURES] WARNING: registered {proc_count} but procedural_log.json missing!")

    # Stage 2c: LTD Decay (flag unretrieved old items)
    print("[CONSOLIDATION] Stage 2c: LTD Decay")
    ltd_result = stage_ltd_decay(verbose=verbose)

    # Stage 2d: Auto-reconsolidation (U6: merge similar entries)
    print("[CONSOLIDATION] Stage 2d: Reconsolidation")
    recon_result = stage_reconsolidation(verbose=verbose)

    # Stage 2e: Cross-Domain Transfer Detection
    print("[CONSOLIDATION] Stage 2e: Cross-Domain Transfer")
    transfer_result = stage_cross_domain_transfer(verbose=verbose)

    # Stage 2f: Cross-Region Mining
    print("[CONSOLIDATION] Stage 2f: Cross-Region Mining")
    try:
        from pulse.daemons.consolidation.consolidation_stages import stage_2f_cross_region_mining
        cross_region_result = stage_2f_cross_region_mining(verbose=verbose)
    except Exception as e:
        cross_region_result = {"status": "error", "error": str(e)}

    # Stage 3: Schema Promotion (cross-patterns)
    # Sacred Boundary #7: approval gate on brain self-modification
    print("[CONSOLIDATION] Stage 3: Schema Promotion")
    cross_patterns = mining_result.get("cross_patterns", [])
    try:
        from pulse.daemons.consolidation.approval_gate import check_approval
        approved_cp, blocked_cp = check_approval("schema_promotion", cross_patterns)
        if blocked_cp and verbose:
            print(f"  [APPROVAL] {len(blocked_cp)} schemas pending human review")
    except Exception:
        approved_cp = cross_patterns
    schema_result = stage_schema_promotion(approved_cp, verbose=verbose)

    # Stage 3b: Sequence -> Schema Promotion (Fix 2)
    print("[CONSOLIDATION] Stage 3b: Sequence Schema Promotion")
    seq_schema_result = stage_schema_promotion_from_sequences(sequences, verbose=verbose)

    # Stage 3c: Micro-Pattern Promotion
    print("[CONSOLIDATION] Stage 3c: Micro-Pattern Promotion")
    try:
        from pulse.daemons.consolidation.consolidation_stages import stage_3c_micro_pattern_promotion
        micro_pattern_result = stage_3c_micro_pattern_promotion(verbose=verbose)
    except Exception as e:
        micro_pattern_result = {"status": "error", "error": str(e)}

    # Stage 4: Knowledge Graph Update (Phase 7)
    print("[CONSOLIDATION] Stage 4: Knowledge Graph Update")
    graph_result = stage_graph_update(verbose=verbose)

    # Stage 4b: Promote high-confidence lessons/failures to patterns
    # Sacred Boundary #7: approval gate on pattern promotion
    print("[CONSOLIDATION] Stage 4b: Promote to Patterns")
    promote_result = stage_promote_to_patterns(verbose=verbose)
    try:
        from pulse.daemons.consolidation.approval_gate import check_approval
        promoted_items = promote_result.get("promoted", [])
        if isinstance(promoted_items, list) and len(promoted_items) > 0:
            approved_p, blocked_p = check_approval("promote_to_patterns", promoted_items)
            if blocked_p and verbose:
                print(f"  [APPROVAL] {len(blocked_p)} pattern promotions pending human review")
    except Exception:
        pass

    # Stage 4c: Abstraction (generalize recurring patterns)
    print("[CONSOLIDATION] Stage 4c: Abstraction")
    try:
        from pulse.daemons.consolidation.consolidation_stages import stage_4c_abstraction
        abstraction_result = stage_4c_abstraction(verbose=verbose)
    except Exception as e:
        abstraction_result = {"status": "error", "error": str(e)}

    # Stage 5: Metacognitive Audit (U9: brain quality check)
    print("[CONSOLIDATION] Stage 5: Metacognitive Audit")
    meta_result = stage_metacognitive_audit(verbose=verbose)

    # Stage 6: Hierarchical Prune (Miller's Law — Q8 Neural Hardening)
    print("[CONSOLIDATION] Stage 6: Hierarchical Prune")
    prune_result = stage_hierarchical_prune(verbose=verbose)

    # Stage 7: Brain Health Check (silent watchdog — detects pipeline breaks)
    print("[CONSOLIDATION] Stage 7: Brain Health Check")
    try:
        from pulse.admin.audit.brain_health import check_brain_health
        health_result = check_brain_health(verbose=verbose)
        if health_result.get("alerts"):
            for alert in health_result["alerts"]:
                print(f"  [HEALTH ALERT] {alert}")
    except Exception as e:
        health_result = {"status": "error", "error": str(e)}

    # Stage 8: Truth Verification (Dimension A — contradiction detection + penalties)
    print("[CONSOLIDATION] Stage 8: Truth Verification")
    try:
        truth_result = stage_truth_verification(verbose=verbose)
    except Exception as e:
        truth_result = {"status": "error", "error": str(e)}

    # Stage 9: Decision Consolidation (merge/deduplicate decision entries)
    print("[CONSOLIDATION] Stage 9: Decision Consolidation")
    try:
        from pulse.daemons.consolidation.consolidation_decisions import stage_decision_consolidation
        decision_result = stage_decision_consolidation(verbose=verbose)
    except Exception as e:
        decision_result = {"status": "error", "error": str(e)}

    # Stage 6b: Rebuild search index (hybrid fast-path for brain_search)
    print("[CONSOLIDATION] Stage 6b: Rebuild Search Index")
    try:
        from pulse.brain.search_index import build_index
        index_result = build_index(verbose=verbose)
    except Exception as e:
        index_result = {"status": "error", "error": str(e)}

    # Stage 10: Metamemory (domain confidence map refresh)
    print("[CONSOLIDATION] Stage 10: Metamemory")
    try:
        from pulse.daemons.consolidation.consolidation_stages import stage_10_metamemory
        metamemory_result = stage_10_metamemory(verbose=verbose)
    except Exception as e:
        metamemory_result = {"status": "error", "error": str(e)}

    # Stage 11: Causal Graph Reasoning (Phase 4B-4D — confounders + analogy scan)
    print("[CONSOLIDATION] Stage 11: Causal Graph Reasoning")
    try:
        from pulse.graph.causal_model import detect_confounders
        confounded = detect_confounders()
        causal_result = {"confounders_found": len(confounded), "pairs": [list(p) for p in confounded[:10]]}

        # Run analogy scan on high-degree nodes (find structural isomorphisms)
        from pulse.core.brain_db import get_conn
        conn = get_conn()
        top_nodes = conn.execute(
            "SELECT id, domain FROM graph_nodes ORDER BY degree DESC LIMIT 20"
        ).fetchall()
        analogy_matches = 0
        if len(top_nodes) >= 2:
            from pulse.graph.analogy import build_analogy
            seen = set()
            for i, n1 in enumerate(top_nodes):
                for n2 in top_nodes[i+1:]:
                    if n1["domain"] == n2["domain"]:
                        continue  # Only cross-domain
                    pair_key = tuple(sorted([n1["id"], n2["id"]]))
                    if pair_key in seen:
                        continue
                    seen.add(pair_key)
                    res = build_analogy(n1["id"], n2["id"])
                    if res.get("match"):
                        analogy_matches += 1
                    if analogy_matches >= 5 or len(seen) >= 30:
                        break
                if analogy_matches >= 5 or len(seen) >= 30:
                    break
        causal_result["analogy_matches"] = analogy_matches
        if verbose:
            print(f"  [CAUSAL] {len(confounded)} confounders, {analogy_matches} analogies")
    except Exception as e:
        causal_result = {"status": "error", "error": str(e)}

    # Stage 12: Goal Generation (Phase 5A — self-directed investigation)
    print("[CONSOLIDATION] Stage 12: Goal Generation")
    try:
        from pulse.daemons.synthesis.goal_engine import formulate_goals
        goal_result = formulate_goals(verbose=verbose)
    except Exception as e:
        goal_result = {"status": "error", "error": str(e)}

    # Stage 13: Prospective Memory Check (Phase 5B — deferred intentions)
    print("[CONSOLIDATION] Stage 13: Prospective Memory")
    try:
        from pulse.daemons.synthesis.prospective_memory import check_intentions
        intention_result = check_intentions(verbose=verbose)
    except Exception as e:
        intention_result = {"status": "error", "error": str(e)}

    # Stage 14: Sentinel Health Checks (Phase 5C)
    print("[CONSOLIDATION] Stage 14: Sentinel Checks")
    try:
        from pulse.admin.audit.sentinels import run_sentinels
        sentinel_result = run_sentinels(verbose=verbose)
    except Exception as e:
        sentinel_result = {"status": "error", "error": str(e)}

    # Stage 15: Autonomy Promotion Check (Phase 5D)
    print("[CONSOLIDATION] Stage 15: Autonomy Check")
    try:
        from pulse.core.autonomy_state import check_promotion
        promoted = check_promotion()
        autonomy_result = {"promoted": promoted}
    except Exception as e:
        autonomy_result = {"status": "error", "error": str(e)}

    # Stage 16: Pattern Evolution (Phase 6E — auto-generate regex)
    # Sacred Boundary #7: approval gate on self-generated patterns
    print("[CONSOLIDATION] Stage 16: Pattern Evolution")
    try:
        from pulse.brain.pattern_evolution import evolve_patterns
        evolution_result = evolve_patterns(verbose=verbose)
        new_patterns = evolution_result.get("new_patterns", [])
        if isinstance(new_patterns, list) and len(new_patterns) > 0:
            from pulse.daemons.consolidation.approval_gate import check_approval
            approved_ev, blocked_ev = check_approval("pattern_evolution", new_patterns)
            if blocked_ev and verbose:
                print(f"  [APPROVAL] {len(blocked_ev)} evolved patterns pending human review")
    except Exception as e:
        evolution_result = {"status": "error", "error": str(e)}

    # Stage 17: Associative Replay (Phase 6A — dreaming, low-activity only)
    print("[CONSOLIDATION] Stage 17: Associative Replay")
    try:
        from pulse.daemons.synthesis.associative_replay import run_replay
        replay_result = run_replay(verbose=verbose)
    except Exception as e:
        replay_result = {"status": "error", "error": str(e)}

    elapsed = round(time.time() - start, 2)

    # Write consolidation log
    log = {
        "timestamp": _now_iso(),
        "elapsed_seconds": elapsed,
        "stage_1_dedup": dedup_result,
        "stage_2_mining": {
            "sequences_found": len(sequences),
            "cross_patterns_found": len(cross_patterns),
        },
        "stage_2b_procedures": {"registered": proc_count},
        "stage_2c_ltd_decay": ltd_result,
        "stage_2d_reconsolidation": recon_result,
        "stage_2e_transfer": transfer_result,
        "stage_2f_cross_region": cross_region_result,
        "stage_3_schemas": schema_result,
        "stage_3b_sequence_schemas": seq_schema_result,
        "stage_3c_micro_patterns": micro_pattern_result,
        "stage_4_graph": graph_result,
        "stage_4b_promote_patterns": promote_result,
        "stage_4c_abstraction": abstraction_result,
        "stage_5_metacognition": meta_result,
        "stage_6_hierarchical_prune": prune_result,
        "stage_7_brain_health": health_result,
        "stage_8_truth_verification": truth_result,
        "stage_9_decision_consolidation": decision_result,
        "stage_6b_search_index": index_result,
        "stage_10_metamemory": metamemory_result,
        "stage_11_causal_graph": causal_result,
        "stage_12_goals": goal_result,
        "stage_13_prospective": intention_result,
        "stage_14_sentinels": sentinel_result,
        "stage_15_autonomy": autonomy_result,
        "stage_16_pattern_evolution": evolution_result,
        "stage_17_replay": replay_result,
    }

    CONSOLIDATION_LOG.parent.mkdir(parents=True, exist_ok=True)
    save_json(CONSOLIDATION_LOG, log)

    print(f"\n[CONSOLIDATION] Complete in {elapsed}s")
    print(f"  Dedup merged: {dedup_result.get('merged', 0)}")
    print(f"  Patterns found: {mining_result.get('total_found', 0)}")
    print(f"  Schemas: {schema_result.get('new_schemas', 0)} new, "
          f"{schema_result.get('total_schemas', 0)} total")

    return log


if __name__ == "__main__":
    v = "--verbose" in sys.argv or "-v" in sys.argv
    run_consolidation(verbose=v)
