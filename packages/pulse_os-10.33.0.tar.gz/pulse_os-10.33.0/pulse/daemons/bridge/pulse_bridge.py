#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
# See LICENSE file for details.
"""
PULSE Bridge Daemon (V7): Converts Raw Logs -> Structured Knowledge.
Watches capture logs for Claude/Gemini/Codex. Routing in bridge_routing.py.
"""
import time
import os
import sys
import io
from pathlib import Path

if os.name == 'nt' and __name__ == '__main__':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

SCRIPT_DIR = Path(__file__).resolve().parent
ROOT_DIR = SCRIPT_DIR.parent.parent.parent

# When run directly, ensure pulse package is importable
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from pulse.brain.wants_parser import parse_full
from pulse.core.pulse_crypto import PulseCrypto
from pulse.core.brain_utils import save_json, load_json_dict
from pulse.core.brain_io import _acquire
from pulse.brain.auto_capture import capture as auto_capture
from pulse.daemons.bridge.bridge_routing import append_to_evidence, route_knowledge
from pulse.daemons.bridge.reflex_arc import check_reflex, detect_mistakes
from pulse.core.brain_analysis import compute_item_salience, compute_item_confidence

# Config
STATE_DIR = ROOT_DIR / "state"
LOG_CLAUDE = STATE_DIR / "pulse_captured_claude.log"
LOG_GEMINI = STATE_DIR / "pulse_captured_gemini.log"
LOG_CODEX = STATE_DIR / "pulse_captured_codex.log"
STATE_FILE = STATE_DIR / "pulse_bridge_state.json"
POLL_INTERVAL = 1.0


class PulseBridge:
    def __init__(self, verbose=False):
        self.verbose = verbose
        self.running = True
        self.state = self._load_state()
        self.crypto = PulseCrypto()

        import signal
        signal.signal(signal.SIGTERM, self._handle_shutdown)
        signal.signal(signal.SIGINT, self._handle_shutdown)

        self.source_map = {
            "CLAUDE": "claude_daemon",
            "GEMINI": "gemini_daemon",
            "CODEX": "codex_daemon"
        }
        self.buffers = {
            "CLAUDE": {"user": None, "agent": []},
            "GEMINI": {"user": None, "agent": []},
            "CODEX": {"user": None, "agent": []}
        }
        self.last_activity = {"CLAUDE": 0.0, "GEMINI": 0.0, "CODEX": 0.0}
        self.idle_timeout_seconds = 30

    def _log(self, msg):
        if self.verbose:
            print(f"[BRIDGE] {msg}")

    def _handle_shutdown(self, signum, frame):
        self._log("Shutdown — flushing buffers...")
        self.running = False
        for source in self.buffers:
            if self.buffers[source]["user"] and self.buffers[source]["agent"]:
                self._flush_interaction(source)
        self._save_state()
        self._log("Goodbye.")
        sys.exit(0)

    def _load_state(self):
        default_pos = {str(f): 0 for f in [LOG_CLAUDE, LOG_GEMINI, LOG_CODEX]}
        data = load_json_dict(STATE_FILE)
        if not data:
            return {"positions": default_pos}
        positions = data.get("positions", {})
        for k, v in default_pos.items():
            positions.setdefault(k, v)
        return {"positions": positions}

    def _save_state(self):
        with _acquire(STATE_FILE):
            save_json(STATE_FILE, self.state)

    def _process_line(self, line, source):
        line = line.strip()
        if not line:
            return
        if " | SIG: " not in line:
            self._log(f"Dropping unsigned line from {source}")
            return

        content_part, signature = line.rsplit(" | SIG: ", 1)
        # For known agents use source_map, for workers use the worker_id directly
        daemon_id = self.source_map.get(source)
        if not daemon_id and source.startswith("WORKER_"):
            daemon_id = source.lower()
        if not self.crypto.verify_string(content_part, signature, daemon_id):
            print(f"[BRIDGE] INVALID SIGNATURE from {source}! POSSIBLE SPOOFING.")
            return

        import re
        match = re.match(r"^\[(.*?)\] (.*?): (.*)$", content_part)
        if not match:
            return

        ts, role, content = match.groups()
        buffer = self.buffers[source]
        self.last_activity[source] = time.time()

        if role == "USER":
            if buffer["user"] and buffer["agent"]:
                self._flush_interaction(source)
            buffer["user"] = content
            buffer["agent"] = []
        elif role in ["CLAUDE", "GEMINI", "CODEX", "ASSISTANT"]:
            if buffer["user"]:
                buffer["agent"].append(content)

    def _flush_interaction(self, source):
        buffer = self.buffers[source]
        if not buffer["user"]:
            return
        user_text = buffer["user"]
        agent_text = "\n".join(buffer["agent"])

        self._log(f"Parsing interaction from {source}...")

        parsed = parse_full(user_text, agent_text)
        append_to_evidence(parsed, user_text=user_text, agent_text=agent_text,
                           verbose=self.verbose)

        # Route extracted signals to long-term brain regions
        try:
            knowledge_items = []
            ts, domain = parsed.get("timestamp", ""), parsed.get("primary_domain", "general")
            emul = 1.0 + parsed.get("emotional_intensity", 0.0)  # 1.0x-2.0x

            for dw in parsed.get("dont_wants", []):
                desc = dw.get("dont_want", "").strip()
                if desc and len(desc) > 15:
                    rp = float(dw.get("priority", 1))
                    sal = compute_item_salience(desc, priority=rp, emotional_intensity=emul - 1.0)
                    conf = compute_item_confidence(desc, source_type="bridge")
                    knowledge_items.append({"type": "FAILURE", "description": desc,
                        "domain": domain, "timestamp": ts, "confidence": conf, "salience": sal})
            for want in parsed.get("wants", []):
                desc = want.get("want", "").strip()
                if desc and len(desc) > 15 and want.get("priority", 0) >= 2:
                    rp = float(want.get("priority", 1))
                    sal = compute_item_salience(desc, priority=rp, emotional_intensity=emul - 1.0)
                    conf = compute_item_confidence(desc, source_type="bridge")
                    knowledge_items.append({"type": "LEARNING", "description": desc,
                        "domain": domain, "timestamp": ts, "confidence": conf, "salience": sal})
            if knowledge_items:
                route_knowledge(knowledge_items, source=f"bridge_{source.lower()}",
                                verbose=self.verbose)
        except Exception as e:
            self._log(f"route_knowledge error: {e}")

        try:
            auto_capture(user_text, agent_text, session_id=source.lower())
        except Exception as e:
            self._log(f"auto_capture error: {e}")

        # Fact Extraction (Symposium P0)
        extracted_facts_count = 0
        try:
            from pulse.brain.fact_parser import parse_facts
            from pulse.brain.fact_store import store_facts as _store_facts
            facts = parse_facts(f"{user_text}\n{agent_text}" if agent_text else user_text)
            extracted_facts_count = len(facts)
            if facts:
                written = _store_facts(facts, source=f"bridge_{source.lower()}")
                if written: self._log(f"Stored {written} declarative facts")
        except Exception as e:
            self._log(f"fact_extraction error: {e}")

        # Decision Extraction (N0)
        extracted_decisions_count = 0
        try:
            from pulse.brain.decision_parser import parse_decisions
            from pulse.brain.decision_store import store_decision, check_anti_pattern_conflict
            decisions = parse_decisions(user_text, agent_text)
            for dec in decisions:
                dec.update(participants=[source.lower()], source_session=source.lower())
                dec.setdefault("domain", domain)
                dec["salience"] = compute_item_salience(dec["choice"], priority=2, emotional_intensity=emul - 1.0)
                dec["confidence"] = compute_item_confidence(dec["choice"], source_type="bridge")
                conflict = check_anti_pattern_conflict(dec["choice"])
                if conflict:
                    dec["_ap_conflict"] = conflict.get("description", "")[:80]
                if store_decision(dec):
                    extracted_decisions_count += 1
            if extracted_decisions_count and self.verbose:
                self._log(f"Stored {extracted_decisions_count} decisions")
        except Exception as e:
            import logging
            logging.getLogger("pulse.bridge").warning("decision_extraction error: %s", e)

        # Episodic Index (Symposium P1)
        try:
            from pulse.brain.episodic_index import append_entry
            from pulse.brain.context_envelope import get_context_envelope
            append_entry(agent=source.lower(), user_text=user_text, agent_text=agent_text,
                         wants_count=len(parsed.get("wants", [])), facts_count=extracted_facts_count,
                         emotional_intensity=parsed.get("emotional_intensity", 0.0),
                         context=get_context_envelope())
        except Exception as e:
            self._log(f"episodic_index error: {e}")

        # Reflex Arc (<10ms) + Reflex LLM (async)
        regex_hits = []
        try:
            regex_hits = detect_mistakes(f"{user_text}\n{agent_text}" if agent_text else user_text)
            check_reflex(user_text, agent_text, source)
        except Exception as e:
            self._log(f"reflex_arc error: {e}")
        try:
            from pulse.daemons.bridge.reflex_llm import enqueue_for_llm
            enqueue_for_llm(user_text, agent_text, source, regex_hits)
        except Exception as e:
            import logging
            logging.getLogger("pulse.bridge").warning("Reflex LLM enqueue failed: %s", e)

        buffer["user"] = None
        buffer["agent"] = []

    def _tail_file(self, filepath, source, chunk_size=500):
        if not filepath.exists():
            return
        key = str(filepath)
        pos = self.state["positions"].get(key, 0)
        current_size = filepath.stat().st_size
        if current_size < pos:
            pos = 0
        if current_size == pos:
            return
        with open(filepath, "r", encoding="utf-8") as f:
            f.seek(pos)
            count = 0
            while True:
                line = f.readline()
                if not line:
                    break
                self._process_line(line, source)
                count += 1
                if count % chunk_size == 0:
                    self.state["positions"][key] = f.tell()
                    self._save_state()
            self.state["positions"][key] = f.tell()
        self._save_state()

    def _discover_worker_logs(self):
        worker_logs = []
        for f in STATE_DIR.glob("pulse_captured_worker_*.log"):
            source = f.stem.replace("pulse_captured_", "").upper()
            if source not in self.buffers:
                self.buffers[source] = {"user": None, "agent": []}
                self.last_activity[source] = 0.0
            self.state["positions"].setdefault(str(f), 0)
            worker_logs.append((f, source))
        return worker_logs

    def run(self):
        print(f"[BRIDGE] Watching: {LOG_CLAUDE.name}, {LOG_GEMINI.name}, {LOG_CODEX.name} + workers")

        while self.running:
            self._tail_file(LOG_CLAUDE, "CLAUDE")
            self._tail_file(LOG_GEMINI, "GEMINI")
            self._tail_file(LOG_CODEX, "CODEX")
            for log_path, source in self._discover_worker_logs():
                self._tail_file(log_path, source)

            now = time.time()
            for source in self.buffers:
                last = self.last_activity.get(source, 0.0)
                buf = self.buffers[source]
                if buf["user"] and buf["agent"] and last > 0:
                    if (now - last) >= self.idle_timeout_seconds:
                        self._log(f"Idle flush for {source} ({now - last:.0f}s idle)")
                        self._flush_interaction(source)
                        self.last_activity[source] = 0.0

            time.sleep(POLL_INTERVAL)

if __name__ == "__main__":
    v = "--verbose" in sys.argv
    PulseBridge(verbose=v).run()
