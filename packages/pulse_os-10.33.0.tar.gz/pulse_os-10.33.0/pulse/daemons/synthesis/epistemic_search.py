#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""Epistemic Forager web search — browser-first with DDG fallback."""
from __future__ import annotations
import re
import time

MAX_RESULTS = 5
SEARCH_TIMEOUT = 10
_DDG_URL = "https://html.duckduckgo.com/html/"


def web_search(query: str) -> list[dict]:
    """Search the web. Returns [{title, url, snippet}].
    Try Playwright browser first (spec requirement), fall back to urllib DDG.
    """
    results = _browser_search(query)
    if results:
        return results
    return _ddg_search(query)


def _browser_search(query: str) -> list[dict]:
    """Use browser/core.py (Playwright) to search DuckDuckGo."""
    try:
        from pulse.browser.core import (
            browser_goto, browser_get_content, shutdown_browser,
        )
    except (ImportError, Exception):
        return []
    try:
        import urllib.parse
        encoded = urllib.parse.quote_plus(query)
        browser_goto(f"https://duckduckgo.com/?q={encoded}")
        time.sleep(2)  # Wait for results to render
        content = browser_get_content(None)  # Full page text
        if not content or len(content) < 50:
            return []
        return _parse_text_results(content)
    except Exception:
        return []
    finally:
        try:
            shutdown_browser()
        except Exception:
            pass


def _parse_text_results(content: str) -> list[dict]:
    """Parse browser page text into result dicts."""
    if not content:
        return []
    chunks = [c.strip() for c in content.split("\n\n") if len(c.strip()) > 20]
    results = []
    for chunk in chunks[:MAX_RESULTS]:
        lines = chunk.strip().split("\n")
        title = lines[0][:200] if lines else ""
        snippet = " ".join(lines[1:])[:300] if len(lines) > 1 else ""
        if title:
            results.append({"title": title, "url": "", "snippet": snippet})
    return results


def _ddg_search(query: str) -> list[dict]:
    """Fallback: DuckDuckGo HTML endpoint via urllib."""
    import urllib.request, urllib.parse
    try:
        data = urllib.parse.urlencode({"q": query}).encode()
        req = urllib.request.Request(
            _DDG_URL, data=data, method="POST",
            headers={"User-Agent": "PULSE/1.0 (epistemic-forager)"},
        )
        with urllib.request.urlopen(req, timeout=SEARCH_TIMEOUT) as resp:
            html = resp.read().decode("utf-8", errors="replace")
    except Exception:
        return []
    links = re.findall(
        r'class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>',
        html, re.DOTALL,
    )
    snippets = re.findall(
        r'class="result__snippet"[^>]*>(.*?)</(?:a|td)>',
        html, re.DOTALL,
    )
    results = []
    for i, (url, title_html) in enumerate(links[:MAX_RESULTS]):
        title = re.sub(r"<[^>]+>", "", title_html).strip()
        snippet = (
            re.sub(r"<[^>]+>", "", snippets[i]).strip()
            if i < len(snippets) else ""
        )
        if title and url:
            results.append({"title": title, "url": url, "snippet": snippet})
    return results
