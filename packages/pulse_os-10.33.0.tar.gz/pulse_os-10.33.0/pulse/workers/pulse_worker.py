#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
# See LICENSE file for details.
"""PULSE Background Worker — polls task board, claims tasks, executes via LLM tool loop.

(This module delegates to pulse/workers/runner/worker_main.py for strict Separation of Concerns)
"""
from __future__ import annotations

from pulse.workers.runner.worker_main import main

if __name__ == "__main__":
    main()
