"""Headless workers: task execution, LLM calls, tool use."""
