#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
# See LICENSE file for details.
"""
// PURPOSE: Grok Bridge for PULSE Brain.
// [Phase 2: Multi-Agent Orchestration]
"""

import sys
import os
from pathlib import Path
SCRIPT_DIR = Path(__file__).resolve().parent
ROOT_DIR = SCRIPT_DIR.parent.parent

# When run directly, ensure pulse package is importable
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

# Add project roots to path

from pulse.admin.pulse_transaction import BrainTransaction
from pulse.core.brain_utils import load_config, EVIDENCE_DIR

class PulseGrok:
    """
    // The Grok Agent Bridge.
    // Handles context injection and evidence capture for xAI models.
    """

    def __init__(self):
        self.tx = BrainTransaction(agent_id="grok_xai")
        self.config = load_config()

    def sync(self, domain: str, evidence_text: str):
        """// Captures evidence from a Grok interaction and signs it."""
        evidence = [{
            "evidence": evidence_text,
            "domain": domain,
            "type": "observation",
            "source": "grok_bridge",
            "timestamp": None # Transaction layer will handle this
        }]
        
        target_file = EVIDENCE_DIR / "Sessions" / "pulse_captured.json"
        success = self.tx.execute(target_file, evidence)
        
        if success:
            print(f"  [GROK_SYNC] Evidence captured and signed in {domain}")
        else:
            print(f"  [GROK_ERROR] Failed to sign evidence from Grok")

if __name__ == "__main__":
    # Example usage for manual sync
    grok = PulseGrok()
    if len(sys.argv) > 2:
        grok.sync(sys.argv[1], sys.argv[2])
    else:
        print("Usage: python pulse_grok.py <domain> <evidence_text>")
