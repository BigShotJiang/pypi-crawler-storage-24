"""REST API: brain, agents, system endpoints."""
