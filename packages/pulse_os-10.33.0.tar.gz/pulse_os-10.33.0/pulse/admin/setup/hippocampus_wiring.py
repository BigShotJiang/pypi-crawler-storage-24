# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
# See LICENSE file for details.
import os
from pathlib import Path
import re

# Base Paths
WINS = Path("Hippocampus/Lessons")
PATTERNS = Path("Hippocampus/Patterns")
LESSONS = Path("Hippocampus/Lessons")
OS_ROOT = "PULSE_OS.md"

def wire_synapse(file_path, target_links):
    if not file_path.exists():
        print(f"Skipping {file_path} - not found.")
        return
        
    content = file_path.read_text(encoding="utf-8")
    links_str = f"links: [{', '.join(target_links)}]"
    
    if "links: [" in content:
        # Update existing links (simple replace for this batch)
        new_content = re.sub(r"links: \[.*?\]", links_str, content)
    else:
        # Add new header
        domain = "pulse"
        if "architecture" in file_path.name.lower(): domain = "architecture"
        elif "compliance" in file_path.name.lower() or "security" in file_path.name.lower(): domain = "security"
        elif "skill" in file_path.name.lower(): domain = "git" # Temporary, to catch git skills
        elif "gemini" in file_path.name.lower(): domain = "gemini"
        elif "claude" in file_path.name.lower(): domain = "claude"
        elif "codex" in file_path.name.lower(): domain = "codex"
        
        header = f"---\ntype: semantic\ndomain: {domain}\n{links_str}\n---\n\n"
        new_content = header + content
        
    file_path.write_text(new_content, encoding="utf-8")
    print(f"Wired {file_path.name} -> {target_links}")

if __name__ == "__main__":
    # 1. Pulse Core Synapses (flat structure — all in Hippocampus/<region>/)
    wire_synapse(WINS / "pulse_wins.md", ["../Patterns/auto_patterns.md", "pulse_lessons.md", "../../PULSE_OS.md"])
    wire_synapse(PATTERNS / "auto_patterns.md", ["../Lessons/pulse_wins.md", "../Lessons/pulse_lessons.md", "../../PULSE_OS.md"])
    wire_synapse(LESSONS / "pulse_lessons.md", ["pulse_wins.md", "../Patterns/auto_patterns.md", "../../PULSE_OS.md"])

    # 2. Architecture Synapses
    wire_synapse(WINS / "architecture_wins.md", ["architecture_lessons.md", "../../PULSE_OS.md"])
    wire_synapse(LESSONS / "architecture_lessons.md", ["architecture_wins.md", "../../PULSE_OS.md"])

    # 3. Compliance/Skill Synapses (ensure they link to Laws)
    wire_synapse(WINS / "compliance_wins.md", ["../Patterns/skill_patterns.md", "skill_lessons.md", "../../PULSE_OS.md"])
    wire_synapse(PATTERNS / "skill_patterns.md", ["../Lessons/skill_lessons.md", "../../PULSE_OS.md"])
    wire_synapse(LESSONS / "skill_lessons.md", ["../Patterns/skill_patterns.md", "../../PULSE_OS.md"])

    # 4. Connect Core Skills to Laws & Constitution (already done by mass_synapse_wire.py, but ensuring consistency)
    wire_synapse(Path(".cursor/skills/ARCHITECT.md"), ["Corpus_Callosum/CONSTITUTION.md", "PULSE_OS.md"])
    wire_synapse(Path(".cursor/skills/SECURITY_VANGUARD.md"), ["Corpus_Callosum/CONSTITUTION.md"])
    wire_synapse(Path(".cursor/skills/BYZANTINE_SENTINEL.md"), ["Corpus_Callosum/CONSTITUTION.md"])
    wire_synapse(Path(".cursor/skills/SUPEREGO_ENFORCER.md"), ["Corpus_Callosum/CONSTITUTION.md"])
    wire_synapse(Path(".cursor/skills/ORCHESTRATOR.md"), ["PULSE_OS.md", "Corpus_Callosum/CONSTITUTION.md"])

    # Connect GIT_PRACTICES skills to Constitution and OS
    for skill_path in Path(".cursor/skills/GIT_PRACTICES").glob("*.md"):
        wire_synapse(skill_path, ["Corpus_Callosum/CONSTITUTION.md", "../../../PULSE_OS.md"])