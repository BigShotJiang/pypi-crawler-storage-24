"""Core utilities: paths, I/O, config, crypto."""
