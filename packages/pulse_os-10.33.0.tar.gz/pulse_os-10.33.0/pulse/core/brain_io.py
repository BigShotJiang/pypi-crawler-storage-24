# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
# See LICENSE file for details.
"""
Brain I/O: Transaction-safe JSON read/write with file locking.

Split from brain_utils.py for Law 7 compliance.
"""

import json
import logging
import os
import shutil
import time as _time
from pathlib import Path

_log = logging.getLogger("pulse.brain_io")

# C4: File locking for concurrent agent safety
try:
    from filelock import FileLock
    _HAS_FILELOCK = True
except ImportError:
    _HAS_FILELOCK = False

# C4: Lock cache — one FileLock per path, reused across calls
_lock_cache: dict[str, "FileLock"] = {}
_LOCK_TIMEOUT = 60  # seconds (raised for 24+ concurrent swarm agents)


def _get_lock(path: Path):
    """Get or create a FileLock for the given path. No-op if filelock unavailable."""
    if not _HAS_FILELOCK:
        return None
    key = str(path.resolve())
    if key not in _lock_cache:
        _lock_cache[key] = FileLock(str(path) + ".lock", timeout=_LOCK_TIMEOUT)
    return _lock_cache[key]


class _NoOpLock:
    """Context manager fallback when filelock is unavailable."""
    def __enter__(self): return self
    def __exit__(self, *a): pass


class _InstrumentedLock:
    """Wrapper that measures lock wait time and records contention events."""
    __slots__ = ("_lock", "_path")

    def __init__(self, lock, path: Path):
        self._lock = lock
        self._path = path

    def __enter__(self):
        t0 = _time.monotonic()
        self._lock.__enter__()
        wait = _time.monotonic() - t0
        if wait > 0.5:  # >500ms = meaningful contention
            _record_contention(self._path, wait)
        return self

    def __exit__(self, *a):
        return self._lock.__exit__(*a)


def _acquire(path: Path):
    """Return a context manager that locks the file path."""
    lock = _get_lock(path)
    if lock is None:
        return _NoOpLock()
    return _InstrumentedLock(lock, path)


# --- Contention tracking (D17: Predictive Swarm Choreographer) ---

_CONTENTION_FILE: Path | None = None  # lazy init


def _get_contention_file() -> Path:
    global _CONTENTION_FILE
    if _CONTENTION_FILE is None:
        try:
            from .brain_utils import STATE_DIR
            _CONTENTION_FILE = STATE_DIR / "health" / "contention_tracker.json"
        except Exception:
            _CONTENTION_FILE = Path("state/health/contention_tracker.json")
    return _CONTENTION_FILE


def _record_contention(path: Path, wait_seconds: float):
    """Append a contention event. Best-effort, never crashes the caller."""
    try:
        ct = _get_contention_file()
        ct.parent.mkdir(parents=True, exist_ok=True)
        fname = path.name
        data: dict = {}
        if ct.exists():
            try:
                with open(ct, "r", encoding="utf-8") as f:
                    data = json.load(f)
            except (json.JSONDecodeError, OSError):
                data = {}
        entry = data.get(fname, {"total_waits": 0, "total_seconds": 0.0,
                                  "max_wait": 0.0, "recent": []})
        entry["total_waits"] += 1
        entry["total_seconds"] = round(entry["total_seconds"] + wait_seconds, 3)
        entry["max_wait"] = round(max(entry["max_wait"], wait_seconds), 3)
        entry["recent"] = (entry.get("recent", []) + [
            {"wait": round(wait_seconds, 3), "t": _time.strftime("%Y-%m-%dT%H:%M:%S")}
        ])[-20:]  # keep last 20 events
        data[fname] = entry
        tmp = ct.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        os.replace(str(tmp), str(ct))
    except Exception:
        pass  # best-effort — never break the caller


def load_json(path: Path) -> list:
    """Load JSON file, return list (default empty). File-locked.
    On corruption: auto-restores from .bak if valid."""
    if not path.exists():
        return []
    try:
        with _acquire(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
    except json.JSONDecodeError:
        # Try recovering from backup
        bak = path.with_suffix(".bak")
        if bak.exists():
            try:
                with open(bak, "r", encoding="utf-8") as f:
                    data = json.load(f)
                # Backup is valid — restore it
                shutil.copy2(bak, path)
                _log.warning("Recovered %s from backup (original was corrupted)", path.name)
                return data
            except (json.JSONDecodeError, OSError):
                pass
        return []
    except OSError:
        return []


def load_json_dict(path: Path) -> dict:
    """Load JSON file, return dict (default empty). File-locked.
    On corruption: auto-restores from .bak if valid."""
    if not path.exists():
        return {}
    try:
        with _acquire(path):
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data if isinstance(data, dict) else {}
    except json.JSONDecodeError:
        bak = path.with_suffix(".bak")
        if bak.exists():
            try:
                with open(bak, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, dict):
                    shutil.copy2(bak, path)
                    _log.warning("Recovered %s from backup (original was corrupted)", path.name)
                    return data
            except (json.JSONDecodeError, OSError):
                pass
        return {}
    except OSError:
        return {}


def _replace_with_retry(tmp: Path, target: Path, max_attempts: int = 8):
    """os.replace with exponential backoff for Windows high-contention scenarios.
    WinError 5 (Access Denied) occurs when antivirus, Explorer, or concurrent
    swarm workers briefly hold the target file."""
    for attempt in range(max_attempts):
        try:
            os.replace(str(tmp), str(target))
            return
        except PermissionError:
            if attempt == max_attempts - 1:
                raise
            _time.sleep(0.05 * (2 ** attempt))  # 50ms, 100ms, 200ms ... 6.4s


def save_json(path: Path, data, indent: int = 2):
    """Transaction-safe JSON write with undo backup. File-locked."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    try:
        with _acquire(path):
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=indent, ensure_ascii=False)
            _replace_with_retry(tmp, path)
    except OSError:
        if tmp.exists():
            tmp.unlink()
        raise


def atomic_update_json(path: Path, updater, default=None):
    """Atomic read-modify-write under a single lock acquisition.
    `updater` is a callable that receives the loaded data and returns modified data.
    `default` is the initial value if file doesn't exist (dict or list)."""
    if default is None:
        default = {}
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    try:
        with _acquire(path):
            # Read
            if path.exists():
                try:
                    with open(path, "r", encoding="utf-8") as f:
                        data = json.load(f)
                except (json.JSONDecodeError, OSError):
                    data = default
            else:
                data = default
            # Modify
            data = updater(data)
            # Write
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            
            _replace_with_retry(tmp, path)
            return data
    except OSError:
        if tmp.exists():
            tmp.unlink()
        raise


def load_config() -> dict:
    """Load brain_config.json. Priority: user project dir > package default."""
    try:
        from .paths import get_project_dir, _is_dev_mode
        if not _is_dev_mode():
            user_config = get_project_dir() / "config" / "brain_config.json"
            if user_config.exists():
                return load_json_dict(user_config)
    except Exception:
        pass
    from .brain_utils import CONFIG_FILE
    return load_json_dict(CONFIG_FILE)
