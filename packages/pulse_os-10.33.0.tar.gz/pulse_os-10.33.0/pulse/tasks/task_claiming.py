# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""
Tier matching, atomic task claiming, and task finalization.

Split from task_ops.py for Law 7 compliance (<300 lines per file).
Imports lazy helpers from task_ops to avoid circular dependencies.
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path


# ---------------------------------------------------------------------------
# Constants (imported lazily from task_ops at call time)
# ---------------------------------------------------------------------------

def _ops():
    """Lazy import to avoid circular dependency at module level."""
    from pulse.tasks import task_ops
    return task_ops


# ---------------------------------------------------------------------------
# Tier detection & matching
# ---------------------------------------------------------------------------

def tier_matches_strict(task: dict, worker_tier: str) -> bool:
    """Flexible tier match -- capable workers can grab simpler tasks."""
    rec = task.get("recommended_tier", "standard")
    complexity = task.get("complexity", "")
    task_level = rec if rec in ("premium", "standard", "fast") else "standard"
    if complexity in ("high", "complex"):
        task_level = "premium"
    elif complexity in ("medium", "moderate"):
        task_level = "standard"
    elif complexity in ("low", "simple"):
        task_level = "fast"

    if worker_tier == "premium":
        return True
    if worker_tier == "standard":
        return task_level in ("standard", "fast")
    if worker_tier == "fast":
        return task_level == "fast"
    return False


def task_age_seconds(task: dict) -> float:
    """How long a task has been sitting open (seconds)."""
    created = task.get("created_at") or task.get("dispatched_at", "")
    if not created:
        return 9999  # no timestamp = treat as old (eligible for fallback)
    try:
        created_dt = datetime.fromisoformat(created.replace("Z", "+00:00"))
        return (datetime.now(timezone.utc) - created_dt).total_seconds()
    except (ValueError, TypeError):
        return 0.0


def tier_matches(task: dict, worker_tier: str) -> tuple[bool, bool]:
    """Returns (should_claim, is_fallback).

    Tier hierarchy is strict:
      premium -> can pick premium, standard, fast
      standard -> can pick standard, fast (NEVER premium)
      fast -> can pick fast ONLY

    Time-based fallback only allows picking DOWN, never UP:
      premium stale -> standard/fast can grab (already allowed by strict)
      No upward fallback -- fast never grabs standard/premium.
    """
    if tier_matches_strict(task, worker_tier):
        return True, False
    return False, False


# ---------------------------------------------------------------------------
# Task claiming (atomic)
# ---------------------------------------------------------------------------

def claim_task(board_path: Path, agent_id: str, tier: str = "standard") -> dict | None:
    """Atomically claim a tier-matching task. Returns task dict or None.

    Pass 1: strict tier match.  Pass 2: fallback on stale tasks (>60s).
    """
    import re
    # Guard: reject bare agent names — must contain _digits (worker index or PID)
    if not re.search(r'_\d+', agent_id):
        return None

    ops = _ops()
    atomic = ops._get_atomic_update()
    if not atomic:
        return None

    claimed = [None]
    now_str = ops._now_iso()
    crypto = ops._get_crypto()

    def _do_claim(board):
        if not isinstance(board, dict):
            return board

        # Pass 1: tier match
        for d in board.get("dispatches", []):
            for t in d.get("tasks", []):
                status = t.get("status")
                if status not in ("open", "escalated"):
                    continue
                # Guard: skip if recently claimed by another agent
                if status == "open" and t.get("claimed_by") and t.get("claimed_by") != agent_id:
                    claimed_at = t.get("claimed_at", "")
                    if claimed_at:
                        try:
                            ct = datetime.fromisoformat(claimed_at.replace("Z", "+00:00"))
                            if (datetime.now(timezone.utc) - ct).total_seconds() < 10:
                                continue
                        except (ValueError, TypeError):
                            pass
                eligible = t.get("eligible_agents")
                if eligible and agent_id not in eligible:
                    continue
                match, fallback = tier_matches(t, tier)
                if (match and not fallback) or status == "escalated":
                    t["status"] = "active"
                    t["claimed_by"] = agent_id
                    t["claimed_at"] = now_str
                    if crypto:
                        t["_claim_signature"] = crypto.sign_string(
                            f"{agent_id}:{t.get('task_id', '')}:{now_str}", agent_id
                        )
                    claimed[0] = dict(t)
                    return board

        # Pass 2: fallback (stale tasks)
        for d in board.get("dispatches", []):
            for t in d.get("tasks", []):
                if t.get("status") != "open":
                    continue
                eligible = t.get("eligible_agents")
                if eligible and agent_id not in eligible:
                    continue
                match, fallback = tier_matches(t, tier)
                if match and fallback:
                    t["status"] = "active"
                    t["claimed_by"] = agent_id
                    t["claimed_at"] = now_str
                    t["_tier_fallback"] = True
                    if crypto:
                        t["_claim_signature"] = crypto.sign_string(
                            f"{agent_id}:{t.get('task_id', '')}:{now_str}", agent_id
                        )
                    claimed[0] = dict(t)
                    return board
            return board

        return board

    # D17: Apply choreography stagger to reduce lock contention
    try:
        from pulse.daemons.synthesis.swarm_choreographer import get_stagger_ms
        stagger = get_stagger_ms(board_path.name)
        if stagger > 0:
            import time as _t, random as _r
            _t.sleep(_r.uniform(0, stagger / 1000.0))
    except Exception:
        pass

    atomic(board_path, _do_claim, default={"dispatches": []})
    return claimed[0]


def finalize_task(board_path: Path, task_id: str, agent_id: str,
                  outcome: str = "", status: str = "done",
                  tokens_in: int = 0, tokens_out: int = 0, cost: float = 0.0):
    """Mark a task as done/escalated/reopened on the board with stats."""
    ops = _ops()
    atomic = ops._get_atomic_update()
    if not atomic:
        return

    now = ops._now_iso()
    crypto = ops._get_crypto()

    def _update(board):
        if not isinstance(board, dict):
            return board
        for d in board.get("dispatches", []):
            for t in d.get("tasks", []):
                tid = t.get("task_id") or t.get("id", "")
                if tid != task_id:
                    continue
                # Guard: skip if already done (another agent beat us)
                if t.get("status") == "done" and status == "done":
                    return board
                # Absolute retry ceiling — force-close after 5 attempts
                board_retries = t.get("retry_count", 0)
                final_status = status
                final_outcome = outcome
                if final_status != "done" and board_retries >= 5:
                    final_status = "done"
                    final_outcome = outcome or f"POISON_PILL: force-closed after {board_retries} retries"

                if final_status == "done":
                    t["status"] = "done"
                    t["completed_at"] = now
                    # Wire prediction feedback — Oracle learns from task outcomes
                    try:
                        from pulse.daemons.neural.prediction_feedback import record_prediction_outcome
                        _success = "POISON_PILL" not in (final_outcome or "")
                        record_prediction_outcome(task_id, success=_success, agent_name=agent_id)
                    except Exception:
                        pass  # Never block task completion on feedback failure
                    if crypto:
                        t["_done_signature"] = crypto.sign_string(
                            f"{agent_id}:{task_id}:{now}", agent_id
                        )
                elif final_status == "escalated":
                    t["status"] = "escalated"
                    t["retry_count"] = board_retries + 1
                    current = t.get("recommended_tier", "standard")
                    t["escalate_to"] = "standard" if current == "fast" else "premium"
                else:
                    t["status"] = "open"
                    t["retry_count"] = board_retries + 1
                    t["claimed_by"] = None
                    t["claimed_at"] = None

                    # Self-escalation: bump tier if task is stuck
                    if board_retries >= 2:
                        old_tier = t.get("recommended_tier", "standard")
                        if old_tier == "fast":
                            t["recommended_tier"] = "standard"
                            print(f"[PULSE] Self-escalating task {tid}: fast -> standard (retry_count={board_retries})")
                        elif old_tier == "standard":
                            t["recommended_tier"] = "premium"
                            print(f"[PULSE] Self-escalating task {tid}: standard -> premium (retry_count={board_retries})")

                t["completed_by"] = agent_id
                t["outcome"] = (outcome.strip() or "Task completed without detailed output.")[:500]
                t["tokens_in"] = t.get("tokens_in", 0) + tokens_in
                t["tokens_out"] = t.get("tokens_out", 0) + tokens_out
                t["estimated_cost_usd"] = t.get("estimated_cost_usd", 0.0) + cost
                return board
        return board

    atomic(board_path, _update, default={"dispatches": []})
