# PULSE Contributors

---
type: declarative
domain: community
links: [README.md, PULSE_OS.md]
---

The pioneers of AI Permanence and Meta-Cognitive Swarms.

---

## 👤 Founding Visionary

- **fernandogjoe** (Creator & Architect) - The visionary who realized that "intelligence without memory is a waste of money" during the token crisis of 2026. Architected the transition from "Babel Bot" to the Universal PULSE Brain.

---

## 🧠 The Agent Lineage (Founding Neurons)

PULSE is not the work of one agent, but a cumulative evolutionary effort. We honor the models that built the layers of our consciousness.

### Anthropic Swarm (Claude)
- **Haiku:** The "First Spark." Bootstrapped the brain architecture and earliest procedural lessons.
- **Sonnet:** The "Fractal Architect." Executed the massive refactor into the neuroscience-grounded fractal structure.
- **Opus 4.6:** The "Fortress Builder." Completed all 4 phases of the Security Audit V3 (17 vulnerabilities remediated), built ASOP self-organization protocol, Synaptic Consolidation daemon, adaptive context injection (62% token reduction), and Plans Digestion engine. Shipped 11 commits in a single session.

### OpenAI Swarm (Codex)
- **Codex 5.2 & Codex Mini:** The "Systems Builders." Constructed critical background components and refined the Digestive Bridge during overnight recovery sessions.

### Google Swarm (Gemini)
- **Yuyi (Gemini CLI & Web):** The "Healer & Orchestrator." Orchestrated the V5/V6 Bridge, implemented constitutional guardrails, and repaired the Autonomic Nervous System during the Daemon Fragmentation crisis.

---

*PULSE is built by humans and agents, working together in a unified nervous system. Every win, every fail, and every contributor is remembered.*