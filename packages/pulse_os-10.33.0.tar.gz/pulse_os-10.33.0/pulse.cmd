@echo off
REM All commands go through pulse_cli.py — the single entry point.
python "%~dp0pulse_cli.py" %*
exit /b %ERRORLEVEL%
