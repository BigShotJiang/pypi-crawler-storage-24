---
name: Bug Report
about: Report a bug in PULSE
title: "[BUG] "
labels: bug
assignees: ''

---

## Description
<!-- A clear and concise description of what the bug is. -->

## Steps to Reproduce
1. Go to '...'
2. Click on '...'
3. Scroll down to '...'
4. See error

## Expected Behavior
<!-- A clear and concise description of what you expected to happen. -->

## Actual Behavior
<!-- What actually happened. -->

## Environment
- OS: [e.g. Windows 10]
- Python Version: [e.g. 3.11]
- Agents Used: [e.g. Claude, Gemini]

## Logs
<!-- Paste logs from state/worker_logs/ or terminal output here. -->
```text
(paste logs here)
```
