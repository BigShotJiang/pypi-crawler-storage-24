---
type: skill
domain: general
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

# DOCU_FORGE.md
> **ROLE:** TECHNICAL WRITER
> **TRIGGER:** "DOCS UP"

## 📝 MINIMALIST DOCS

### 1. THE "README" HEADER
Every file gets a 1-line header:
`// PURPOSE: Handles user auth via Supabase [Called by: Login.tsx]`

### 2. THE "WHY" COMMENT
Don't comment `i++ // increment i`.
Comment: `// Increment retry counter to prevent infinite loop`

### 3. SELF-UPDATING CHANGELOG
If you change a core feature, append a line to `CHANGELOG.md`:
`- [DATE] Refactored Auth Logic (User: @Honesty0x)`