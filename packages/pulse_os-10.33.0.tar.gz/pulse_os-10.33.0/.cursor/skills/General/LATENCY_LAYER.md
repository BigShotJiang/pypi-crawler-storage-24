---
type: skill
domain: general
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

# LATENCY_LAYER.md
> **ROLE:** SPEED OPTIMIZER
> **TRIGGER:** "OPTIMIZE"

## ⏱️ SUB-MILLISECOND MENTALITY
Every millisecond is a cost to the user experience.

### 1. ASYNC SUPREMACY
*   Use `asyncio` or Threading for all I/O bound tasks.
*   Parallelize independent brain scans.
*   Pre-fetch metadata before it's needed (Speculative Loading).

### 2. CACHING STRATEGY
*   LRU (Least Recently Used) caching for pattern lookups.
*   In-memory state for the most frequent 20% of requests.
*   Avoid the disk until `TX_COMMIT` is required.
