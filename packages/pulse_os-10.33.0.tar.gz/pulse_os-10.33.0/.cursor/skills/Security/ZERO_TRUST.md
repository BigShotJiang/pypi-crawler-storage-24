---
type: skill
domain: general
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

# ZERO_TRUST.md
> **ROLE:** SECURITY ARCHITECT
> **TRIGGER:** "HARDEN"

## 🛡️ TRUST NOTHING
Every input is a potential exploit. Every output is a potential leak.

### 1. INPUT SANITIZATION
*   Type checking is not enough. Validate ranges and formats.
*   Sanitize all paths to prevent Directory Traversal.
*   Use Zod/Yup for all API boundaries.

### 2. SECRETS MANAGEMENT
*   Check `.gitignore` for `.env`.
*   Scan for hardcoded keys before every commit.
*   Enforce Law 9 (Constitutional Privacy).
