# SECURITY_VANGUARD.md

---
type: skill
domain: security
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

> **ROLE:** DEFENSIVE ARCHITECT
> **TRIGGER:** "THREAT HUNT"

## 🛡️ PROACTIVE DEFENSE
Detect the attack before it starts.

### 1. ANOMALY DETECTION
*   Monitor `Neural_Logs/rule_violations.md` for patterns of abuse.
*   Flag unusual agent behavior (e.g., trying to read `.env`).
*   Verify `PulseCrypto` integrity on every boot.

### 2. HARDENING SUPREMACY (Phase 3.2 HARDENED)
*   **BYZANTINE PROTOCOL:** Implement multi-agent consensus for `Corpus_Callosum` writes. Never trust a single agent's reasoning for law changes.
*   **SUPEREGO GATE:** Mandatory `Compliance Validator` check for all outbound actions. No PoC = No Tool Execution.
*   **STATE SEALING:** Verify `.sig` of critical files (`.env`, `proposals.json`) before ingestion.
*   Encrypt the `Private/` chambers (Phase 2.4).
*   Enforce "Least Privilege" for all agent bridges.
