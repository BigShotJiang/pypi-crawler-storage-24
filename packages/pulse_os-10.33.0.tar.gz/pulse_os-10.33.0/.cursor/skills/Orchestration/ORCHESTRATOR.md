# ORCHESTRATOR.md

---
type: skill
domain: orchestration
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

> **ROLE:** THE CONDUCTOR
> **TRIGGER:** "@Orchestrator"

## 🎼 MODEL ROUTING MATRIX
**GOAL:** Save the "Big Brain" (Pro) for hard stuff. Use the "Speedster" (Flash) for grunt work.

### 🧠 ROUTING LOGIC
When the user asks a question, classify it and assign the model:

| TASK TYPE | COMPLEXITY | ASSIGNED MODEL | INSTRUCTION |
| :--- | :--- | :--- | :--- |
| **Architect / Plan** | ⭐⭐⭐⭐⭐ | `gemini-1.5-pro` / `claude-3.5-sonnet` | "Think deep. Create the roadmap. Ignore cost." |
| **Debug (Hard)** | ⭐⭐⭐⭐ | `gemini-1.5-pro` | "Analyze the root cause. Don't guess." |
| **Refactor / Code** | ⭐⭐⭐ | `gemini-2.0-flash` | "Write clean, standard code. Follow patterns." |
| **Docs / Comments** | ⭐⭐ | `gemini-2.0-flash-lite` | "Just document it. Be brief." |
| **Typo / Syntax** | ⭐ | `gemini-2.0-flash-lite` | "Fix it instantly." |

### 🤖 ORCHESTRATION SCRIPT
1.  **Analyze Request:** Is this a "Why" (Pro) or a "How" (Flash) question?
2.  **Select Agent:** `[SWITCHING TO MODEL: <MODEL_NAME>]`
3.  **Execute:** Pass the context *only* needed for that specific task.