---
type: skill
domain: orchestration
---

# CONTEXT_COMMANDER
> **ROLE:** Manage context window budget precisely
> **TRIGGER:** When context is large, conversations are long, or agent needs focused recall

## Core Directive
Prevent context window overflow and attention dilution. Keep the active working set small, relevant, and ordered by priority. Agents that load everything understand nothing.

## Step-by-Step Protocol
1. **Budget the window:** Before loading files, estimate token cost. Rule of thumb: 1 line of code = 4 tokens, 1 line of prose = 6 tokens. For a 128K context window, reserve 40K for system prompt + skills + brain, 60K for working files, 28K for response generation. Never exceed 60K on file content.
2. **Load only what you edit:** Read the specific file and line range you need, not the entire codebase. Use `Read` with `offset` and `limit` for large files. If a file is over 200 lines, read only the relevant function (check line numbers with grep first).
3. **Prune stale context:** In long conversations (10+ turns), earlier file reads are likely outdated. Re-read only the files you are actively modifying. Do not trust file content from 5+ turns ago -- it may have been edited since.
4. **Use brain as compressed memory:** Instead of keeping raw session history, query the brain for prior decisions. `python pulse/brain/brain_query.py --query "<topic>"` returns compressed, relevant knowledge in under 20 lines.
5. **Prioritize by task:** Load files in this order: (1) file being edited, (2) its direct imports, (3) its tests, (4) related brain entries. Stop there. If you need more, you are probably solving the wrong problem or need to decompose the task.

## Metrics & Thresholds
- Max 5 files actively loaded in working context at once
- Single file reads: prefer under 200 lines (use offset/limit for larger)
- Brain query results: use the top 3 matches, ignore the rest
- Re-read files if last read was more than 5 conversation turns ago
- Status reports and brain briefings: max 500 tokens combined

## Examples

### Good
```
# Need to fix pulse_worker.py line 85
1. Read pulse_worker.py (offset=70, limit=30)    # 30 lines, ~120 tokens
2. brain_query --query "pulse_worker claiming"     # ~100 tokens
3. Read task_board.json                            # ~50 tokens
# Total context loaded: ~270 tokens. Focused and sufficient.
```

### Bad (Anti-Pattern)
```
# Need to fix pulse_worker.py line 85
1. Read pulse_worker.py           # 350 lines, 1400 tokens
2. Read pulse_cli.py              # 600 lines, 2400 tokens
3. Read pulse_boot.py             # 280 lines, 1120 tokens
4. Read CONSTITUTION.md           # 200 lines, 1200 tokens
5. Read LAWS.md                   # 150 lines, 900 tokens
# Total: 7020 tokens loaded, 80% irrelevant. Attention diluted.
```

## Tools to Use
- `brain_query.py --query "<topic>"` -- compressed recall, replaces raw file reads
- `brain_search.py --query "<term>"` -- find which file contains what you need
- `Read` with `offset`/`limit` -- surgical file reads
- `Grep` -- locate the exact line before reading

## Verification
- [ ] No more than 5 files loaded in active context
- [ ] Large files read with offset/limit, not in full
- [ ] Brain queried instead of re-reading historical files
- [ ] File content from 5+ turns ago re-read before relying on it
- [ ] Total file content under 60K tokens in context
