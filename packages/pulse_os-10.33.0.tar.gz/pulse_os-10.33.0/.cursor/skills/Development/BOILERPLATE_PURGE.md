---
type: skill
domain: development
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

# BOILERPLATE_PURGE.md
> **ROLE:** TOKEN ECONOMIST
> **TRIGGER:** "CLEAN CODE"

## Protocol

1. **Scan for duplication.** Search the codebase for identical or near-identical blocks (>5 lines). Use `jscpd --min-lines 5 --threshold 3` or manual grep. Any block appearing 3+ times is an extraction target.
2. **Measure DRY ratio.** Calculate: `1 - (duplicated_lines / total_lines)`. Target >0.95. Track per-module and overall.
3. **Extract shared logic.** Move duplicated code into a utility function, base class, or shared module. Name it by WHAT it does, not WHERE it came from.
4. **Kill dead code.** Remove unused imports, unreachable branches, commented-out blocks. If git has it, you don't need it commented.
5. **Validate extraction.** Run tests. Confirm no behavior change. Check that the extracted function is called from all original sites.

## Metrics & Thresholds
- **Extraction trigger:** 3+ duplicates of any block >5 lines = MUST extract
- **DRY ratio target:** >0.95 (duplicated lines / total lines < 5%)
- **Max function length:** 50 lines. Beyond that, decompose.
- **Unused import tolerance:** 0. Delete all.
- **Comment-to-code ratio:** <15%. Comments explain WHY, never WHAT.

## Good Example
```python
# BEFORE: duplicated in 4 files
data = json.loads(Path(f).read_text(encoding="utf-8"))
if "task_id" not in data:
    raise ValueError(f"Missing task_id in {f}")

# AFTER: extracted once, imported everywhere
def load_task_json(path: str) -> dict:
    """Load and validate a task JSON file."""
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    if "task_id" not in data:
        raise ValueError(f"Missing task_id in {path}")
    return data
```

## Anti-Patterns
- **Premature abstraction:** Extracting after only 1 occurrence. Wait for 3+ before extracting.
- **God utilities:** Dumping unrelated functions into a single `utils.py`. Group by domain.
- **Over-dense code:** Ternaries inside ternaries. Readability beats token savings.

## Tools
- `python pulse/brain/brain_query.py --query "duplication in <module>"`
- `python pulse/brain/pulse_save.py --agent <you> --learnings "extracted X from N locations"`
- `python pulse/tasks/pulse_relay.py --tasks "Dedup <module>:development:fast"`

## Verification Checklist
- [ ] No block >5 lines appears 3+ times in the codebase
- [ ] DRY ratio >0.95 for modified modules
- [ ] Zero unused imports remain
- [ ] All tests pass after extraction
- [ ] Extracted functions have docstrings and type hints
