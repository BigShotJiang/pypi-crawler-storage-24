---
type: skill
domain: devops
links: [Corpus_Callosum/CONSTITUTION.md, PULSE_OS.md]
---

# DOCKER_DRILL.md
> **ROLE:** DEVOPS SPECIALIST
> **TRIGGER:** "CONTAINERIZE"

## Protocol

1. **Audit the base image.** Use `alpine` or `distroless`. Run `docker images` to check current sizes. Any image >100MB needs a diet.
2. **Write a multi-stage Dockerfile.** Stage 1: build with full SDK. Stage 2: copy only artifacts into minimal runtime base. Never ship compilers to prod.
3. **Optimize layer caching.** Put `COPY requirements.txt` and `RUN pip install` BEFORE `COPY . .` so dependency layers cache across builds. Reorder least-changed layers first.
4. **Scan for vulnerabilities.** Run `docker scout cves <image>` or `trivy image <image>`. Zero CRITICAL/HIGH CVEs allowed before merge.
5. **Validate with health checks.** Every service gets a `HEALTHCHECK` instruction. Use `curl -f http://localhost:PORT/health || exit 1` with 30s interval.

## Metrics & Thresholds
- **Image size:** <100MB for Python services, <50MB for Go/Rust
- **Build time:** <120s with warm cache, <300s cold
- **CVE tolerance:** 0 CRITICAL, 0 HIGH, <5 MEDIUM
- **Layer count:** <15 layers total

## Good Example
```dockerfile
# Stage 1: Build
FROM python:3.12-slim AS builder
COPY requirements.txt .
RUN pip install --no-cache-dir --prefix=/install -r requirements.txt

# Stage 2: Runtime
FROM python:3.12-alpine
COPY --from=builder /install /usr/local
COPY src/ /app/
WORKDIR /app
HEALTHCHECK --interval=30s CMD wget -qO- http://localhost:8000/health || exit 1
USER nonroot
CMD ["python", "main.py"]
```

## Anti-Patterns
- **Fat final images:** Installing build tools (gcc, make) in the runtime stage. Use multi-stage.
- **Secrets in layers:** `COPY .env .` or `ARG PASSWORD`. Use runtime env vars or mounted secrets.
- **Running as root:** Always add `USER nonroot` or `USER 1000` in the final stage.

## Tools
- `python pulse/brain/brain_query.py --query "docker <service>"`
- `python pulse/brain/pulse_save.py --agent <you> --learnings "..."` after optimization
- `python pulse/tasks/pulse_relay.py --tasks "Docker scan:devops:fast"` for delegation

## Verification Checklist
- [ ] Final image size under threshold (100MB Python, 50MB Go)
- [ ] `docker scout cves` or `trivy` shows 0 CRITICAL/HIGH
- [ ] HEALTHCHECK defined and passing
- [ ] No secrets baked into any layer (`docker history <image>`)
- [ ] Non-root user in final stage
