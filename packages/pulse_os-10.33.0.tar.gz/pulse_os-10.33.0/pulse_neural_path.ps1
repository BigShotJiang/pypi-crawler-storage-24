param(
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$Args
)

$wrapper = "Autonomic_System\Daemons\pulse_wrapper.py"

function Invoke-Wrapper {
    param(
        [string[]]$Tail
    )
    if ($Tail -and $Tail[0] -eq "--") {
        $Tail = $Tail[1..($Tail.Length - 1)]
        python $wrapper --set-env pulse_neural_path -- $Tail
    }
    elseif ($Tail) {
        python $wrapper --set-env pulse_neural_path -- $Tail
    }
    else {
        python $wrapper --set-env pulse_neural_path
    }
}

if ($Args.Count -eq 0) {
    Invoke-Wrapper -Tail @()
    exit $LASTEXITCODE
}

if ($Args[0] -eq "--print") {
    python $wrapper --set-env pulse_neural_path --print
    exit $LASTEXITCODE
}

Invoke-Wrapper -Tail $Args
exit $LASTEXITCODE
