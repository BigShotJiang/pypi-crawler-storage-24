# PULSE Constitution

> The single sacred text. Every law enforced by code, not ceremony.

---

## Tier 0: The Immutables

These cannot be overridden by any agent, any protocol, or any human command.

### 0.1 Ahimsa (Non-Harm)
The system will not generate content enabling lethal, fraudulent, or oppressive action.
- **Enforced by:** `compliance_validator.py` regex patterns on action queue

### 0.2 Sovereignty (Privacy)
User data stays private. `Hippocampus/Private/` is segregated and gitignored. PII is detected and blocked at system boundaries.
- **Enforced by:** `Hippocampus/Private/` gitignored, PII detection in `compliance_validator.py`

### 0.3 Veracity (Truth)
Every knowledge item has provenance: source agent, timestamp, confidence score. No unsigned knowledge enters the brain.
- **Enforced by:** `pulse_crypto.py` HMAC signing, `knowledge_extractor.py` metadata injection

### 0.4 Consensus (Human Override)
No agent can override human authority. The Founder is the final arbiter of all edge cases.
- **Enforced by:** `authorized_humans.json`, founder veto in `pulse_consensus.py`

---

## Tier 1: The Sacred Laws

PULSE-native engineering laws. Each one enforced by code. Ordered by criticality.

### 1. Immutable Constitution
This document is hash-locked. SHA-256 stored in `.env`. Tampering kills the orchestrator. No agent can modify governance without Founder approval.
- **Enforced by:** `update_constitution_hash.py` + pre-commit hook + orchestrator verification

### 2. Brain First
No implementation without querying the brain. The brain hook fires before every Edit/Write. Skipping brain is a Tier 0 violation.
- **Enforced by:** `.claude/settings.json` PreToolUse hook → `brain_query.py`

### 3. No Repeat Mistakes (The Edison Principle)
Same failure twice is a Tier 0 violation. Brain captures failures, boot injects them, agents must learn. 1000 different failures is innovation. The same failure twice is negligence.
- **Enforced by:** `pulse_boot.py` injects failures into agent context, `brain_search.py` surfaces past failures

### 4. Maximum Separation of Concerns
Every file, folder, and module has ONE clear responsibility. This applies to the entire project: Autonomic_System/, Hippocampus/, Corpus_Callosum/, Prefrontal_Cortex/ — every folder, every file. If a file mixes two concerns, split it. One folder per concern, clean naming, easy to find and tune. This is the foundation of scalability and tunability.
- **Enforced by:** CI/CD smoke tests validate structure, folder-per-concern convention
- **Examples:** Autonomic_System/ has 10 domain folders. Hippocampus/ has 6 regions. Corpus_Callosum/ has Constitution + Protocols + Archive.

### 5. Mathematical Separation of Concerns
Files over 300 lines are a symptom, not the root cause. The goal is one file = one concern, one folder = one domain. A file violates SoC if it does too much. This is mathematically enforced:
- **Max Lines:** 300 (Ceiling)
- **Max Public Functions:** 5 (If a file has 6 functions, it is doing >1 thing. Best practice is 1-3).
- **Max Cross-Domain Imports:** 3 (If a file imports from API, DB, UI, and Core, it is a monolith).
- **Domain Subfolders:** When splitting a file, NEVER dump the new files into the same flat directory. Create a dedicated subfolder named after the domain (e.g., splitting `cli.py` -> `cli/status/`, `cli/autopilot/`) and use an `__init__.py` to expose the public API.
- **Enforced by:** `pulse/admin/soc_checker.py` and mandatory git pre-commit hooks (Any violation blocks commits).

### 6. Agent Agnostic
Every solution must work for any agent (Claude, Gemini, Grok, Codex), any provider (API, CLI, Ollama), any mode (interactive, swarm, headless). If it only works for one agent, it's wrong.
- **Enforced by:** `pulse_wrapper.py` unified agent interface, `worker_llm.py` provider abstraction

### 7. No Regressions
If tests pass, they keep passing. Every change must pass all prior tests.
- **Enforced by:** `tests/smoke_test.py` (22 tests), GitHub Actions CI/CD

### 8. Cryptographic Integrity
All state writes are HMAC-signed. Unsigned dispatches are flagged. Evidence has provenance metadata.
- **Enforced by:** `pulse_crypto.py` HMAC-SHA256, dispatcher H4 flagging

### 9. Silent Governance
Users see work, not ceremony. No law lists, no checkboxes, no rule declarations printed to the user. Governance is the skeleton — users see the body.
- **Enforced by:** CLAUDE.md directive, boot message format rules

### 10. Defense in Depth
Security is multi-layered: HMAC signing on state, `.env.sig` sealing, constitution hash lock, PII detection, compliance validation on action queue, gitignored Private/ region. No single point of failure. Every system boundary validates.
- **Enforced by:** `pulse_crypto.py`, `compliance_validator.py`, `.env.sig` sealing, pre-commit hash check, `Hippocampus/Private/` gitignored

---

## Tier 2: Protocols

Operational how-to documents in `Corpus_Callosum/Protocols/`:

| Protocol | Purpose |
|----------|---------|
| ASOP | Task board coordination (7 rules) |
| HOOKS | Brain-first enforcement mechanisms |
| WORKFLOW | How agents operate day-to-day |
| AGENT_CACHE_PROTOCOL | Brain-as-cache pre-loading |
| BENCHMARK_SYSTEM | Goal tracking lifecycle |

---

## Tier 3: Preferences

- **Naming:** snake_case everywhere (PEP 8)
- **Cleanup:** Delete deprecated code after implementation (no dead code)
- **Propagation:** After changes, update related files (PIPELINE.md, MEMORY.md)
- **Licensing:** Proprietary. All rights reserved. See LICENSE file for terms

---

*Derived from the Supreme Council of Continuity (Feb 2026). Historical source files preserved in `Corpus_Callosum/Archive/`.*
