# Constitutional System - Transparency Templates
> **Context:** Mandatory Disclosure Forms

## 1. Full Work Session Template
Used for multi-file features and architectural changes.

```
═══════════════════════════════════════════════════════════════
                    AGENT WORK SESSION
═══════════════════════════════════════════════════════════════
[AGENT TYPE & TASK]
Agent: [Model] | Task: [Description] | Date: [YYYY-MM-DD]

[CONSTITUTIONAL RULE READING CEREMONY]
Tier 0 ✅, Tier 1 ✅

[TASK-BOUND RULES]
1. Law [X]: [Reason]
2. ANTI_PATTERN [Z]: [Trap]

[PROCEEDING WITH WORK]
All rules understood. Starting work.
...
═══════════════════════════════════════════════════════════════
```

## 2. Minimal Template
Used for simple edits (typos, single config change).

```
[AGENT: Model | TASK: Description]
Rules: Law 9 (N/A)
Proceeding. ✅
```

## 3. Uncertainty Template
Used when rule interpretation is ambiguous.

```
[RULE IN QUESTION]: Law [X]
[UNCERTAINTY]: [Specific doubt]
[STATUS]: ❌ UNCERTAIN - Awaiting user clarification.
```

## 4. Rule Bypass Request
Used when a rule MUST be broken.

```
[RULE TO BYPASS]: Law [X]
[JUSTIFICATION]: [Reason]
[USER APPROVAL REQUIRED]: Approve bypass? [Y/N]
```
