# Constitutional System - Agent Transparency
> **Context:** Mandatory Disclosure & Formatting

## Transparency Requirement
Every agent MUST show their reasoning and rule adherence before and after work.

### Mandatory Pre-Work Disclosure
Agents must show:
- Agent type (Model) and user task.
- Which rules apply to THIS task.
- How each decision follows a specific rule.

### Mandatory Post-Work Disclosure (Law 9)
Agents must show the 6-item checklist BEFORE completion:
- [ ] CHANGELOG.md updated.
- [ ] manifesto.py updated (if user-facing).
- [ ] SESSION.md updated.
- [ ] evidence/*.json updated (if new learnings).
- [ ] handlers/commands/* updated (if applicable).
- [ ] _growth_metrics.json updated.

---

## Anti-Pattern Detection
| Pattern | Why Bad | Counter-Mechanism |
|---------|---------|-------------------|
| "Quick fix" | Size doesn't exempt | Rules apply to ALL changes |
| "I assumed" | Assumptions = violations | Rule 0.3: Ask first |
| "User implied" | Implied ≠ explicit | Rule 0.1: Explicit only |
| "Too small" | All violations matter | Rule 0.4: Log everything |
| "Fix later" | Debt accumulates | Fix now or ask |
