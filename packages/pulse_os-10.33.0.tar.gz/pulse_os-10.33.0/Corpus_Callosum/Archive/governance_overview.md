# Constitutional System - Governance Overview
> **Context:** Rule Enforcement Strategy & Hierarchy

## Executive Summary
PULSE utilizes a 4-tier constitutional rule system to prevent silent bypasses and ensure agent accountability. Agents are constitutionally bound to ask first and never guess.

### Core Principles
1. **READ:** Mandatory rule ceremony.
2. **EXPLICIT:** Crystal clear enforcement protocols.
3. **ENFORCED:** Unambiguous consequences for violations.
4. **TRANSPARENT:** Agents declare followed rules.
5. **LOGGED:** Audit trail for all bypasses.

---

## Rule Hierarchy (4 Tiers)

### Tier 0: Meta-Rules (Inviolable)
- **Rule 0.1:** No bypass without approval.
- **Rule 0.2:** Mandatory rule declaration.
- **Rule 0.3:** Uncertainty = Ask.
- **Rule 0.4:** Violation logging.

### Tier 1: Critical Laws (Sacred 9)
Found in `Tier_1_Laws/`. These govern the engine, legal safety, and maintainability.

### Tier 2: Architectural Rules
Governs module boundaries (SoC), framework independence, and memory science.

### Tier 3: Operational Rules
Governs commit procedures, testing, and model-aware delegation.

### Tier 4: Preferences
Governs naming conventions, documentation style, and brand voice.

---

## Enforcement Mechanics
1. **Uncertainty Protocol:** STOP → Show doubt → Ask user → Wait.
2. **Bypass Protocol:** STOP → Justify → Ask approval → Log if YES.
3. **Propagation Checklist:** Law 9 compliance (6 mandatory items).
