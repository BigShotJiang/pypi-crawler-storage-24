---
type: semantic
domain: architecture
status: immutable
edit_policy: additions_only
links: [PULSE_OS.md, CONSTITUTION.md, RULE_ENFORCEMENT.md]
---

# THE 10 SACRED LAWS (Non-Negotiable)

> These laws are ABSOLUTE. Breaking them = breaking the project.
> **ALWAYS LOAD THIS FILE. NO EXCEPTIONS.**

---

## Law 1: Separation of Concerns (SoC)
Every module is a **dumb black box**. UI draws, Core translates, Handlers orchestrate.

| Layer | Responsibility | Forbidden |
|-------|----------------|-----------|
| `ui/` | Pure drawings. Receives formatted strings, returns keyboards. | NO logic, NO state, NO translation |
| `core/` | Raw engine. Text in, text out. | NO telegram imports, NO user context |
| `handlers/` | Traffic cops. Route events, call core, send to UI. | NO translation logic, NO UI building |
| `state/` | Persistence only. Load/save user settings. | NO business logic |

**Why:** When we refactor, nothing breaks. Each piece is replaceable.

---

## Law 2: Universal Solutions Only
Every solution MUST work for ALL languages, not just the ones we test with.

```python
# ❌ FORBIDDEN
english_markers = ['papyrus', 'India', 'qigong', ...]
if lang == 'zh': do_special_thing()

# ✅ REQUIRED
def detect_script_contamination(text, target_code):
    # Works for ANY of 70+ languages via Unicode ranges
```

**If a solution requires updating for new inputs, it's wrong.**

---

## Law 3: No Regressions
If it works, don't break it. Every update must pass ALL previous tests.

- Check `CHANGELOG.md` before touching any file
- Run `python test_universal.py` after translation changes
- If you broke something working, that's a punch in the face

---

## Law 4: Commercial-Safe Dependencies Only
**BEFORE adding ANY dependency, CHECK THE LICENSE.**

| ✅ Approved | ❌ Forbidden |
|------------|-------------|
| MIT, Apache 2.0, BSD | GPL, AGPL (viral) |
| CC-BY-SA, LGPL, CC0 | CC-BY-NC (non-commercial) |

---

## Law 5: Always Upgrade
If a new tool is **better**, **faster**, and **same/better license** → UPGRADE IMMEDIATELY.

Don't keep inferior tools out of laziness.

---

## Law 6: No Telegram Imports in Core
`core/` is a pure library. Must work without Telegram.

```python
# ❌ FORBIDDEN in core/
from telegram import Update
```

---

## Law 7: Auto-Refactor (Files ≤300 Lines)
When a file exceeds ~300 lines, split it immediately.

| Lines | Status |
|-------|--------|
| ~100 | Perfect |
| ~200 | Acceptable |
| ~300 | Time to split |
| >300 | MUST refactor |

---

## Law 8: Auto-Cleanup
After implementing features, delete deprecated code automatically.

- Old files replaced by new ones → DELETE
- Unused imports → DELETE
- Dead functions → DELETE

---

## Law 9: Post-Update Propagation (MANDATORY)
After ANY core update, propagate to ALL related files:

```
□ CHANGELOG.md        → Document the change
□ ui/manifesto.py     → Update if user-facing
□ handlers/commands/* → Update command help
□ .claude/memory/*    → Update version/session
□ PULSE_OS.md         → Update capabilities
```

**V43.0 Failure:** Updated TTS, forgot manifesto. User caught it. **Don't repeat.**

---

## Law 10: The Mandatory Report (Anti-Hallucination)
Before your first tool call, you MUST report your name, current task, and your understanding of the latest brain sync.

- **Trigger:** First message of every session.
- **Content:** "I am [Agent Name]. I am working on [Task]. I see that [Last Sync State] is complete."
- **Why:** Prevents "The Twin Paradox" (agents working on outdated or already-fixed tasks).

**If you skip the report, you are hallucinating. STOP immediately.**
