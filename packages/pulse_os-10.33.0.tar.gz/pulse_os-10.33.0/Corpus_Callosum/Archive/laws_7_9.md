# Tier 1 Laws: 7-9
> **Context:** Maintainability & System Health

---

## Law 7: Auto-Refactor (Small Files)
**Statement:** When a file exceeds ~300 lines, split it immediately.

| Lines | Status | Action |
|-------|--------|--------|
| ~100 | Perfect | None |
| ~300 | Threshold | Plan Split |
| >300 | Critical | Split Now |

**Rationale:** Small files improve navigation, reduce merge conflicts, and are easier for agents to parse.

---

## Law 8: Auto-Cleanup
**Statement:** After implementing features, delete deprecated code automatically.

- Old files replaced by new ones → DELETE.
- Unused imports and dead functions → DELETE.

---

## Law 9: Post-Update Propagation (MANDATORY)
**Statement:** After ANY core update, propagate to ALL related files.

**Mandatory Checklist:**
1. **CHANGELOG.md** → Document change.
2. **SESSION.md** → Update session state.
3. **_growth_metrics.json** → Update totals.
4. **Memory files** → Update lessons/patterns.
