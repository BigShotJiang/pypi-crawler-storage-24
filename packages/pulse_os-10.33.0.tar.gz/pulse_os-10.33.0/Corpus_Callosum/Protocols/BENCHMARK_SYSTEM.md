# Benchmark System Design

> **Version:** V43.12 | **Status:** active
> **Purpose:** Track goals with natural exponential decay + synthesis to lessons

---

## Lifecycle

```
CREATE -> ACTIVE -> ACHIEVED/FAILED -> SYNTHESIZED -> ARCHIVED
                        |                   |
                        v                   v
                   salience decay      evidence + lesson
```

---

## Exponential Decay

Formula: `salience(t) = e^(-t/100)`

Where `t` = days since benchmark creation.

| Days | Salience | Meaning |
|------|----------|---------|
| 0 | 1.000 | Fresh, high priority |
| 7 | 0.932 | Still very relevant |
| 30 | 0.741 | Moderately relevant |
| 69 | 0.502 | Half-life (50% salience) |
| 100 | 0.368 | Declining relevance |
| 150 | 0.223 | Low priority |
| 230 | 0.100 | Archive threshold |
| 365 | 0.026 | Historical only |

**Archive Rule:** When salience < 0.1 (~230 days), move to archive.
**Never Delete:** Archived benchmarks remain searchable.

---

## Benchmark Schema

```json
{
  "id": "BM-001",
  "description": "Goal description",
  "criteria": "Measurable success criteria",
  "status": "active|achieved|failed|archived",
  "created": "ISO-8601",
  "updated": "ISO-8601",
  "salience": 0.0,
  "want_id": "WANT-001 (optional)",
  "outcome": {
    "result": "achieved|failed",
    "notes": "What happened",
    "date": "ISO-8601"
  },
  "synthesized": false
}
```

---

## Synthesis Pipeline

When a benchmark completes (achieved or failed):

1. **Evidence Creation**
   - Achieved -> WIN evidence (confidence 0.9)
   - Failed -> FAIL evidence (confidence 0.85, weighted 2.5x in synthesis)

2. **Domain Classification**
   - Auto-classify by description keywords
   - Route to appropriate evidence file

3. **Brain Map Update**
   - Add benchmark -> evidence connection
   - Track synthesis date

4. **Growth Metrics**
   - Log synthesis event
   - Update counters

---

## CLI Reference

```bash
# List all benchmarks with salience
python .claude/automation/benchmark_tracker.py --list

# Create new benchmark
python .claude/automation/benchmark_tracker.py --create "Add TTS stats" --criteria "Shows engine counts"

# Mark achieved
python .claude/automation/benchmark_tracker.py --achieve BM-001 --notes "Implemented in V43.12"

# Mark failed
python .claude/automation/benchmark_tracker.py --fail BM-002 --reason "Blocked by dependency"

# Apply decay
python .claude/automation/benchmark_tracker.py --decay

# Archive stale
python .claude/automation/benchmark_tracker.py --archive

# Synthesize outcomes to lessons
python .claude/automation/benchmark_synthesizer.py --synthesize-all
python .claude/automation/benchmark_synthesizer.py --synthesize BM-001
```

---

## Integration

- WANTs can optionally create benchmarks
- Benchmarks decay naturally over time
- Completed benchmarks feed back into brain as evidence
- Evidence triggers pattern synthesis when threshold met

---

*V43.12: Benchmark System - goals with natural decay and knowledge synthesis*
