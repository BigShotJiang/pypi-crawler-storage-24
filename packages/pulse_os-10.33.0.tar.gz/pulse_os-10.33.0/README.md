<div align="center">

<img src="web/public/logo_icon.png" width="80" alt="PULSE" />

# PULSE OS

### Persistent AI Memory for Developer Workflows

[![PyPI version](https://img.shields.io/pypi/v/pulse-os?color=38bdf8&style=flat-square)](https://pypi.org/project/pulse-os/)
[![License: Proprietary](https://img.shields.io/badge/license-proprietary-red?style=flat-square)](LICENSE)
[![pulseos.dev](https://img.shields.io/badge/website-pulseos.dev-38bdf8?style=flat-square)](https://pulseos.dev)

**[Website](https://pulseos.dev) · [Install](https://pulseos.dev/install) · [Docs](https://pulseos.dev/docs) · [Pricing](https://pulseos.dev/pricing)**

</div>

---

## The Problem

Your AI agents forget everything between sessions. Claude helped you debug a tricky race condition on Tuesday — on Thursday, a different agent walks into the same trap. Every session starts from zero.

**PULSE gives your entire AI swarm a shared, persistent brain.**

---

## What It Does

PULSE runs alongside your existing tools. Every agent session — Claude Code, Gemini CLI, custom workers — automatically captures lessons, failures, and decisions into a local brain. Future sessions boot with that knowledge pre-loaded.

```bash
pip install pulse-os
pulse init
pulse activate PULSE-SOLO-cus_xxx-xxxxxxxxxxxxxxxxxxxxxxxx
pulse start
pulse status
```

```
  License:       SOLO (trialing) | trial ends 2026-03-15

  Orchestrator:  RUNNING
  Daemons:       7 alive

  Brain Evidence: 1,247 items
  Brain Health:  83 wants | 61 dont_wants | 24 anti-patterns
  Knowledge:     47 lessons | 29 fails | 18 patterns | 8 decisions
```

---

## Key Capabilities

**Persistent Memory**
Every session feeds the brain. Lessons, failures, patterns, decisions — captured automatically, deduplicated, and searchable in ~125ms across 10 parallel sources.

**Multi-Agent Swarm**
One command launches parallel workers across Claude, Gemini, OpenAI, and Ollama. Agents claim tasks from a shared board, execute, and report back without stepping on each other.

```bash
pulse swarm                    # Interactive: pick provider → model → count
pulse swarm gemini             # Launch Gemini workers
pulse swarm stop               # Kill all workers
```

**Constitutional Governance**
Agents operate under a hash-verified Constitution they cannot override. If the Constitution is tampered with, the system refuses to start.

**Knowledge Graph**
Causal relationships between concepts — CAUSES, PREVENTS, REQUIRES, LEADS_TO. The Prediction Engine queries the graph before task execution and injects failure-risk warnings into agent boot.

**Claude Code Native**
PULSE hooks into Claude Code automatically. Every Edit and Write fires a brain query before execution — relevant context injected without any manual prompting.

---

## Architecture

```
pulse/
├── core/           Brain I/O, crypto, LLM routing, paths
├── brain/          Search (10 sources), extraction, save, boot briefing
├── daemons/        Orchestrator + bridge + neural + consolidation + synthesis
├── workers/        Headless task execution, autopilot (CLI swarm)
├── tasks/          Task board, dispatcher, relay
├── graph/          Knowledge graph build + causal query
├── api/            REST endpoints (FastAPI)
└── cli/            47 commands
```

Your brain lives at `~/.pulse/projects/<hash>/` — local, private, never leaves your machine.

---

## Swarm Models

| Provider | Models |
|----------|--------|
| **Anthropic** | claude-haiku-4-5 · claude-sonnet-4-6 · claude-opus-4-6 |
| **Google** | gemini-2.5-flash · gemini-2.5-pro · gemini-3-flash-preview · gemini-3-pro-preview · gemini-3.1-pro-preview |
| **OpenAI** | o4-mini · gpt-5.2-codex · gpt-5.3-codex · gpt-5.1-codex-max · o3 |
| **Ollama** | Any pulled model + cloud-routed: qwen3-coder-next · devstral-2 · glm-5 · minimax-m2.5 · kimi-k2.5 |

---

## Plans

| | Solo — $14.97/mo | Pro — $29.97/mo |
|-|-----------------|-----------------|
| Brain pipeline | Full | Full |
| Swarm workers | Up to 5 | Unlimited |
| CLI commands | 47 | 47 |
| Web dashboard | ✓ | ✓ |
| Knowledge graph | View | Full RAG + Causal |
| Synthesis daemons | — | ✓ |
| Docker + self-host | — | ✓ |
| Trial | 7 days free | 7 days free |

[Start your free trial →](https://pulseos.dev/pricing)

---

## How Memory Works

```
Agent session
    ↓
Capture daemon intercepts conversation
    ↓
Bridge extracts: lessons · failures · patterns · decisions
    ↓
Brain stores in Hippocampus/ (local, cryptographically signed)
    ↓
Consolidation daemon deduplicates + mines patterns every 6h
    ↓
Next session: boot briefing injects relevant context
    ↓
Agent starts smarter than the last one
```

---

## License

Proprietary. Copyright © 2026 PULSE Contributors. All rights reserved.

Brain data stays 100% local — we never access or train on it.

[hello@pulseos.dev](mailto:hello@pulseos.dev)
