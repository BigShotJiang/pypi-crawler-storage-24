// PULSE API response types

export interface Agent {
  id: string
  model: string
  tier: 'fast' | 'standard' | 'premium'
  type: 'agent' | 'worker' | 'daemon'
  status: 'running' | 'idle' | 'dead'
  current_task: string | null
  last_heartbeat: string | null
  capabilities: string[]
  history: {
    tasks_completed: number
    domains: Record<string, number>
  }
}

export interface Task {
  id?: string
  task_id?: string
  title: string
  description: string
  domain: string
  status: 'open' | 'active' | 'done' | 'escalated'
  recommended_tier: string
  complexity: string
  claimed_by: string | null
  claimed_at: string | null
  completed_at: string | null
  outcome: string | null
  tokens_in: number
  tokens_out: number
  estimated_cost_usd: number
}

export interface Dispatch {
  prompt: string
  dispatched_at: string
  tasks: Task[]
}

export interface SystemOverview {
  agents: { total: number; active: number; working: number }
  tasks: { open: number; active: number; done: number }
  brain: { total_synapses: number; integrity_ratio: number }
  cost_usd: number
}

export interface BrainStats {
  status: string
  total_synapses: number
  signed_synapses: number
  integrity_ratio: number
  memory_velocity_ops_sec: number
  active_agents: number
  queue_depth: number
  uptime_seconds: number
}

export interface Worker {
  id: string
  model: string
  tier: string
  type: 'worker'
  status: 'running' | 'idle' | 'dead'
  current_task: string | null
  last_heartbeat: string | null
  history: {
    tasks_completed: number
    domains: Record<string, number>
  }
}
