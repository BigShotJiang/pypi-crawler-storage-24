import { useCallback } from 'react'
import { api } from '../api/client'
import { usePolling } from './usePolling'

/** Poll brain lessons every 30s */
export function useLessons() {
  const fetcher = useCallback(() => api.getLessons(), [])
  return usePolling(fetcher, 30000)
}

/** Poll brain failures every 30s */
export function useFailures() {
  const fetcher = useCallback(() => api.getFailures(), [])
  return usePolling(fetcher, 30000)
}

/** Poll brain patterns every 30s */
export function usePatterns() {
  const fetcher = useCallback(() => api.getPatterns(), [])
  return usePolling(fetcher, 30000)
}

/** Poll brain schemas every 30s */
export function useSchemas() {
  const fetcher = useCallback(() => api.getSchemas(), [])
  return usePolling(fetcher, 30000)
}

/** Poll brain procedures every 30s */
export function useProcedures() {
  const fetcher = useCallback(() => api.getProcedures(), [])
  return usePolling(fetcher, 30000)
}

/** Poll brain wants every 30s */
export function useWants() {
  const fetcher = useCallback(() => api.getWants(), [])
  return usePolling(fetcher, 30000)
}

/** Poll brain dont_wants every 30s */
export function useDontWants() {
  const fetcher = useCallback(() => api.getDontWants(), [])
  return usePolling(fetcher, 30000)
}

/** Poll brain strategic intents every 30s */
export function useStrategicIntents() {
  const fetcher = useCallback(() => api.getStrategicIntents(), [])
  return usePolling(fetcher, 30000)
}

/** Poll brain anti-patterns every 30s */
export function useAntiPatterns() {
  const fetcher = useCallback(() => api.getAntiPatterns(), [])
  return usePolling(fetcher, 30000)
}

/** Poll knowledge graph every 60s */
export function useKnowledgeGraph() {
  const fetcher = useCallback(() => api.getGraph(), [])
  return usePolling(fetcher, 60000)
}
