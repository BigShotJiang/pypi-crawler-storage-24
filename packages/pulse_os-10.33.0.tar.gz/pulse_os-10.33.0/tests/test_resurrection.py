import pytest
import json
from pulse.brain import resurrection

@pytest.fixture
def clean_resurrection():
    if resurrection.PRUNED_ITEMS_FILE.exists():
        resurrection.PRUNED_ITEMS_FILE.unlink()
    yield
    if resurrection.PRUNED_ITEMS_FILE.exists():
        resurrection.PRUNED_ITEMS_FILE.unlink()

def test_log_pruned(clean_resurrection):
    resurrection.log_pruned("fp123", "Test Title", "general", 2.0)
    
    assert resurrection.PRUNED_ITEMS_FILE.exists()
    lines = resurrection.PRUNED_ITEMS_FILE.read_text(encoding="utf-8").splitlines()
    assert len(lines) == 1
    
    item = json.loads(lines[0])
    assert item["fingerprint"] == "fp123"
    assert item["salience"] == 2.0

def test_check_resurrection_no_match(clean_resurrection):
    resurrection.log_pruned("fp123", "Totally different title about python", "general", 2.0)
    
    assert not resurrection.check_resurrection("Something else about javascript")

def test_check_resurrection_match(clean_resurrection):
    resurrection.log_pruned("fp123", "A specific title about docker memory issues", "general", 3.0)
    
    # Needs text_similarity > 0.7. If text_similarity is just dummy or exact:
    # Actually wait, text_similarity is from brain_analysis. Let's mock it to guarantee match.
    # We will pass the exact same title to guarantee a match.
    assert resurrection.check_resurrection("A specific title about docker memory issues")
    
    # Should be removed from file
    lines = resurrection.PRUNED_ITEMS_FILE.read_text(encoding="utf-8").strip()
    assert len(lines) == 0