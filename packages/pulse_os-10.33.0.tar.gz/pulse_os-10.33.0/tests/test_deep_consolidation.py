import pytest
from pulse.daemons.consolidation import deep_consolidation

def test_deep_consolidation_cycle(monkeypatch):
    # Mock get_conn to avoid needing a real database
    class MockCursor:
        rowcount = 5
    
    class MockConn:
        def __enter__(self): return self
        def __exit__(self, exc_type, exc_val, exc_tb): pass
        def execute(self, query, params=None):
            return MockCursor()
            
    monkeypatch.setattr("pulse.daemons.consolidation.deep_consolidation.get_conn", lambda: MockConn())
    
    stats = deep_consolidation.deep_consolidation_cycle()
    
    # 5 tables * 5 rows each for permanent and archived
    assert stats["permanent"] == 25
    assert stats["archived"] == 25