# OpenAI Admin Usage MCP Server (Python)

This MCP server exposes tools:

- `openai_get_organization_costs` -> calls `GET /v1/organization/costs`
- `openai_get_organization_usage_completions` -> calls `GET /v1/organization/usage/completions`
- `openai_get_organization_usage_audio_speeches` -> calls `GET /v1/organization/usage/audio_speeches`
- `openai_get_organization_usage_audio_transcriptions` -> calls `GET /v1/organization/usage/audio_transcriptions`
- `openai_get_organization_usage_code_interpreter_sessions` -> calls `GET /v1/organization/usage/code_interpreter_sessions`
- `openai_get_organization_usage_embeddings` -> calls `GET /v1/organization/usage/embeddings`
- `openai_get_organization_usage_images` -> calls `GET /v1/organization/usage/images`
- `openai_get_organization_usage_moderations` -> calls `GET /v1/organization/usage/moderations`
- `openai_get_organization_usage_vector_stores` -> calls `GET /v1/organization/usage/vector_stores`
- `openai_get_organization_users` -> calls `GET /v1/organization/users`
- `openai_get_organization_user` -> calls `GET /v1/organization/users/{user_id}`
- `openai_get_organization_projects` -> calls `GET /v1/organization/projects`

Both tools auto-follow pagination and return only merged `data` (no pagination fields in output).

## Requirements

- Python 3.10+
- OpenAI Admin key in `OPENAI_ADMIN_KEY` (preferred) or `OPENAI_API_KEY`

## Install

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .
```

## Run

```bash
export OPENAI_ADMIN_KEY="your_admin_key"
openai-admin-usage-mcp-server
```

## Tool Input

### `openai_get_organization_costs`

- `start_time` (required, date string `YYYY-MM-DD`)
- `bucket_width` (optional, default `"1d"`)
- `end_time` (optional, date string `YYYY-MM-DD`, exclusive)
- `group_by` (optional array; allowed values: `"project_id"`, `"line_item"`; you can pass one or both)
- `project_ids` (optional, list of project IDs)

### `openai_get_organization_usage_completions`

- `start_time` (required, date string `YYYY-MM-DD`)
- `bucket_width` (optional, only `"1d"` is supported; default `"1d"`)
- `end_time` (optional, date string `YYYY-MM-DD`, exclusive)
- `group_by` (optional array; allowed values: `"project_id"`, `"user_id"`, `"api_key_id"`, `"model"`, `"batch"`, `"service_tier"`; any combination is allowed)
- `project_ids` (optional, list of project IDs)
- `user_ids` (optional, list of user IDs)
- `api_key_ids` (optional, list of API key IDs)
- `models` (optional, list of model names)
- `batch` (optional, boolean)

### `openai_get_organization_usage_audio_speeches`

- `start_time` (required, date string `YYYY-MM-DD`)
- `bucket_width` (optional, only `"1d"` is supported; default `"1d"`)
- `end_time` (optional, date string `YYYY-MM-DD`, exclusive)
- `group_by` (optional array; allowed values: `"project_id"`, `"user_id"`, `"api_key_id"`, `"model"`; any combination is allowed)
- `project_ids` (optional, list of project IDs)
- `user_ids` (optional, list of user IDs)
- `api_key_ids` (optional, list of API key IDs)
- `models` (optional, list of model names)

### `openai_get_organization_usage_audio_transcriptions`

- `start_time` (required, date string `YYYY-MM-DD`)
- `bucket_width` (optional, only `"1d"` is supported; default `"1d"`)
- `end_time` (optional, date string `YYYY-MM-DD`, exclusive)
- `group_by` (optional array; allowed values: `"project_id"`, `"user_id"`, `"api_key_id"`, `"model"`; any combination is allowed)
- `project_ids` (optional, list of project IDs)
- `user_ids` (optional, list of user IDs)
- `api_key_ids` (optional, list of API key IDs)
- `models` (optional, list of model names)

### `openai_get_organization_usage_code_interpreter_sessions`

- `start_time` (required, date string `YYYY-MM-DD`)
- `bucket_width` (optional, only `"1d"` is supported; default `"1d"`)
- `end_time` (optional, date string `YYYY-MM-DD`, exclusive)
- `group_by` (optional array; only `"project_id"` is allowed)
- `project_ids` (optional, list of project IDs)

### `openai_get_organization_usage_embeddings`

- `start_time` (required, date string `YYYY-MM-DD`)
- `bucket_width` (optional, only `"1d"` is supported; default `"1d"`)
- `end_time` (optional, date string `YYYY-MM-DD`, exclusive)
- `group_by` (optional array; allowed values: `"project_id"`, `"user_id"`, `"api_key_id"`, `"model"`; any combination is allowed)
- `project_ids` (optional, list of project IDs)
- `user_ids` (optional, list of user IDs)
- `api_key_ids` (optional, list of API key IDs)
- `models` (optional, list of model names)

### `openai_get_organization_usage_images`

- `start_time` (required, date string `YYYY-MM-DD`)
- `bucket_width` (optional, only `"1d"` is supported; default `"1d"`)
- `end_time` (optional, date string `YYYY-MM-DD`, exclusive)
- `group_by` (optional array; allowed values: `"project_id"`, `"user_id"`, `"api_key_id"`, `"model"`, `"size"`, `"source"`; any combination is allowed)
- `project_ids` (optional, list of project IDs)
- `user_ids` (optional, list of user IDs)
- `api_key_ids` (optional, list of API key IDs)
- `models` (optional, list of model names)
- `sizes` (optional, list of `256x256`, `512x512`, `1024x1024`, `1792x1792`, `1024x1792`)
- `sources` (optional, list of `image.generation`, `image.edit`, `image.variation`)

### `openai_get_organization_usage_moderations`

- `start_time` (required, date string `YYYY-MM-DD`)
- `bucket_width` (optional, only `"1d"` is supported; default `"1d"`)
- `end_time` (optional, date string `YYYY-MM-DD`, exclusive)
- `group_by` (optional array; allowed values: `"project_id"`, `"user_id"`, `"api_key_id"`, `"model"`; any combination is allowed)
- `project_ids` (optional, list of project IDs)
- `user_ids` (optional, list of user IDs)
- `api_key_ids` (optional, list of API key IDs)
- `models` (optional, list of model names)

### `openai_get_organization_usage_vector_stores`

- `start_time` (required, date string `YYYY-MM-DD`)
- `bucket_width` (optional, only `"1d"` is supported; default `"1d"`)
- `end_time` (optional, date string `YYYY-MM-DD`, exclusive)
- `group_by` (optional array; only `"project_id"` is allowed)
- `project_ids` (optional, list of project IDs)

### `openai_get_organization_users`

- `emails` (optional, list of email addresses to filter users)

### `openai_get_organization_user`

- `user_id` (required, organization user ID string)

### `openai_get_organization_projects`

- `include_archived` (optional, boolean; if true includes archived projects)
