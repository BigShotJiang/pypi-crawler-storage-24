=========
Changelog
=========

26.6
====

* Added How Mantle Works and Development docs pages. 
* Fixed packaging to require runtime dependencies. 
* Added py.typed marker file for type checkers. 


26.5
====

* Default ``mantle.db`` converter now inherits ``cattrs.preconf.json``,
  allowing union passthrough behavior in the default converter.
* ``to_spec()`` now supports unions composed of basic types,
  for example ``int | str | bool | None``.


26.4
====

* Allow create/update to handle m2m assignment.
* Allow passing domain logic validator callable to create/update.
* Added validation helpers for composing validators and unique field/together checks.


26.3
====

* Added Query/create/update to the top-level API.


26.2
====

* Added create and update API.


26.1
====

* Added ``overrides``, ``spec``, and ``to_spec`` to main ``mantle`` namespace::

    from mantle import overrides, spec, to_spec

* Added support for date, datetime, time, timedelta, and UUID types in ``to_spec()``.
* Added support for ``None`` in ``@overrides`` decorator to skip fields from the spec.


25.1
====

Initial development version. Adds core django-readers integration and type-safe
``Query`` API.

Otherwise undocumented.

Likely, do not use.
