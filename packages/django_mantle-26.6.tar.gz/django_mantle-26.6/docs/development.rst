Development
===========

Getting Started
---------------

Clone `the repo <https://codeberg.org/carltongibson/django-mantle>`_ and install in editable mode with the docs and dev extras:

.. code-block:: bash

    pip install -e '.[docs,dev]'

Running Tests
-------------

Run the test suite with:

.. code-block:: bash

    just test

Run tests with coverage:

.. code-block:: bash

    just coverage

Run the type checker:

.. code-block:: bash

    just mypy
