# Zubbl Infrastructure (GCP + Terraform)

## Architecture

```
Internet → Cloudflare Worker → Cloud Armor → HTTPS LB → Cloud Run (API)
                                                       → Cloud Run (Worker)
                                                       → Cloud SQL (PostgreSQL)
                                                       → Memorystore (Redis)
                                                       → Cloud NAT → External APIs
```

## Cost: ~$42/mo (production)

## Quick Start

### 1. Prerequisites
```bash
brew install terraform
gcloud auth application-default login
```

### 2. Deploy Shared Resources
```bash
cd shared
terraform init
terraform apply
```

### 3. Deploy Production
```bash
cd environments/prod
terraform init
terraform apply \
  -var="db_password=$(openssl rand -hex 16)" \
  -var="jwt_secret=$(openssl rand -hex 32)" \
  -var="neo4j_uri=neo4j+s://xxx.databases.neo4j.io" \
  -var="neo4j_user=xxx" \
  -var="neo4j_password=xxx" \
  -var="pinecone_api_key=xxx" \
  -var="pinecone_index_host=xxx" \
  -var="sentry_dsn=xxx" \
  -var="lemonsqueezy_api_key=xxx" \
  -var="lemonsqueezy_webhook_secret=xxx"
```

### 4. Apply Database Schema
```bash
cloud-sql-proxy PROJECT:REGION:INSTANCE &
psql -h 127.0.0.1 -U zubbl -d zubbl -f src/api/schema_azure.sql
```

### 5. Push Docker Images
```bash
gcloud auth configure-docker asia-south1-docker.pkg.dev
docker build -t asia-south1-docker.pkg.dev/zubbl-prod/zubbl-docker/zubbl-api .
docker push asia-south1-docker.pkg.dev/zubbl-prod/zubbl-docker/zubbl-api
```

## Environments

| Env | LB | Min Instances | Cost |
|-----|-----|--------------|------|
| dev | No (direct Cloud Run URL) | 0 (scale-to-zero) | ~$18/mo |
| prod | Yes (Cloud Armor + TLS) | 1 (always warm) | ~$42/mo |
