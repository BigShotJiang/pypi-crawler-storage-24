"""
Zubbl - Self-Evolving AI Agent SDK
Your agent fails, Zubbl fixes it. No code changes, no redeployment.

Usage:
    from zubbl import ZubblClient

    zubbl = ZubblClient(api_key="your-api-key")
    agent = zubbl.wrap(your_agent)  # That's it. 3 lines.

    # Agent fails → Zubbl catches → auto-recovers → learns for next time

MIT License - https://zubbl.in
"""

from zubbl.interceptor import (
    FailureCategory,
    FailureInterceptor,
    FailurePattern,
    Fix,
    FixType,
    RecoveryResult,
)
from zubbl.sdk import ZubblClient, ZubblConfig
from zubbl.services import (
    GraphRecommendation,
    ServiceHealth,
    ServiceMixin,
    SimilarTrajectoryResult,
    SkillGap,
    TrainingStats,
)
from zubbl.types import (
    Feedback,
    Pattern,
    Policy,
    PolicyHealth,
    RLMode,
    Step,
    TaskStatus,
    Trajectory,
    UsageStats,
    ValidationMethod,
    ValidationResult,
)

# Apply service mixin — adds graph, vector, training, and streams methods
for _attr_name in dir(ServiceMixin):
    if not _attr_name.startswith("_"):
        setattr(ZubblClient, _attr_name, getattr(ServiceMixin, _attr_name))

__version__ = "0.2.0"
__all__ = [
    "ZubblClient",
    "ZubblConfig",
    "Trajectory",
    "Policy",
    "Feedback",
    "RLMode",
    "ValidationResult",
    "ValidationMethod",
    "PolicyHealth",
    "Step",
    "TaskStatus",
    "Pattern",
    "UsageStats",
    "FailureInterceptor",
    "RecoveryResult",
    "FailurePattern",
    "FailureCategory",
    "FixType",
    "Fix",
    # Services
    "SimilarTrajectoryResult",
    "GraphRecommendation",
    "SkillGap",
    "TrainingStats",
    "ServiceHealth",
]
