"""
Zubbl SDK - Main Client

The ZubblClient is the primary interface for integrating Zubbl with any AI agent.
It provides a simple 3-line integration that enables automatic learning and improvement.

Example:
    from zubbl import ZubblClient

    zubbl = ZubblClient(api_key="your-api-key")
    agent = zubbl.wrap(your_agent)  # That's it!
"""

import asyncio
import hashlib
import uuid
from datetime import datetime
from functools import wraps
from typing import Any, Callable, Dict, List, Optional

import httpx
from pydantic import BaseModel, Field

from zubbl.interceptor import FailureInterceptor, RecoveryResult
from zubbl.types import (
    Feedback,
    Policy,
    RLMode,
    Step,
    TaskStatus,
    Trajectory,
    UsageStats,
)


class ZubblConfig(BaseModel):
    """Configuration for ZubblClient"""

    api_key: str
    base_url: str = "https://api.zubbl.ai"
    rl_mode: RLMode = RLMode.LOCAL
    auto_ingest: bool = True  # Automatically ingest trajectories
    auto_query: bool = True  # Automatically query for policies before tasks
    auto_recover: bool = True  # Automatically recover from failures
    timeout: float = 30.0
    retry_attempts: int = 3
    local_cache: bool = True  # Cache policies locally for speed
    max_recovery_retries: int = 3  # Max retries for auto-recovery
    fallback_models: List[str] = Field(default_factory=list)  # Fallback models for recovery


class ZubblClient:
    """
    Zubbl Client - Make any AI agent self-evolving.

    Usage:
        # Basic (3 lines)
        from zubbl import ZubblClient
        zubbl = ZubblClient(api_key="your-api-key")
        agent = zubbl.wrap(your_agent)

        # Advanced
        zubbl = ZubblClient(
            api_key="your-api-key",
            rl_mode=RLMode.COREWEAVE,  # Use cloud RL
        )
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.zubbl.ai",
        rl_mode: RLMode = RLMode.LOCAL,
        auto_ingest: bool = True,
        auto_query: bool = True,
        timeout: float = 30.0,
        # SDK metadata headers (all optional, backward compatible)
        sdk_version: str = "0.1.0",
        agent_framework: Optional[str] = None,
        model: Optional[str] = None,
        environment: Optional[str] = None,
        **kwargs,
    ):
        self.config = ZubblConfig(
            api_key=api_key,
            base_url=base_url,
            rl_mode=rl_mode,
            auto_ingest=auto_ingest,
            auto_query=auto_query,
            timeout=timeout,
            **kwargs,
        )

        # Build headers with auth + SDK metadata
        headers = {"Authorization": f"Bearer {api_key}"}
        if sdk_version:
            headers["X-SDK-Version"] = sdk_version
        if agent_framework:
            headers["X-Agent-Framework"] = agent_framework
        if model:
            headers["X-Model"] = model
        if environment:
            headers["X-Environment"] = environment

        self._client = httpx.AsyncClient(
            base_url=base_url,
            headers=headers,
            timeout=timeout,
        )
        self._sync_client = httpx.Client(
            base_url=base_url,
            headers=headers,
            timeout=timeout,
        )
        self._policy_cache: Dict[str, Policy] = {}
        self._current_trajectory: Optional[Trajectory] = None
        self._steps_buffer: List[Step] = []
        self._current_policy: Optional[Policy] = None
        self._interceptor = FailureInterceptor(
            max_retries=kwargs.get("max_recovery_retries", 3),
            fallback_models=kwargs.get("fallback_models", []),
        )
        self._last_recovery: Optional[RecoveryResult] = None

    @property
    def current_policy(self) -> Optional[Policy]:
        """Get the policy that was queried for the current task.

        Use this to access recommendations without them being
        injected into agent method kwargs.
        """
        return self._current_policy

    @property
    def last_recovery(self) -> Optional[RecoveryResult]:
        """Get the result of the last auto-recovery attempt.

        Check this after a wrapped agent call to see if Zubbl
        intercepted a failure and recovered automatically.

        Example:
            result = agent.run("classify this image")
            if zubbl.last_recovery and zubbl.last_recovery.fix_applied:
                print(f"Zubbl auto-fixed: {zubbl.last_recovery.fix_applied}")
        """
        return self._last_recovery

    @property
    def interceptor(self) -> FailureInterceptor:
        """Access the failure interceptor for manual pattern management"""
        return self._interceptor

    # =========================================================================
    # Core API Methods
    # =========================================================================

    def wrap(self, agent: Any, auto_recover: Optional[bool] = None) -> Any:
        """
        Wrap an agent to enable automatic learning AND failure recovery.

        This is the main entry point - wrapping an agent automatically:
        1. Queries for relevant policies before each task
        2. Records the execution trajectory
        3. If agent fails: auto-recovers using known fix patterns
        4. Ingests all trajectories (success + failure) for learning
        5. Over time, pre-applies fixes before failures even happen

        Args:
            agent: Any AI agent (LangGraph, CrewAI, AutoGPT, custom, etc.)
            auto_recover: Override auto_recover setting for this agent.
                         When True, failures trigger automatic retry/fix.
                         Defaults to config.auto_recover.

        Returns:
            Wrapped agent with Zubbl learning + recovery capabilities

        Example:
            zubbl = ZubblClient(api_key="your-key")
            agent = zubbl.wrap(your_agent)  # auto_recover=True by default

            # Agent fails internally → Zubbl retries with a fix
            # → returns correct result. No code change. No redeploy.
        """
        recover = auto_recover if auto_recover is not None else self.config.auto_recover
        return ZubblWrappedAgent(self, agent, auto_recover=recover)

    def start_trajectory(self, task_description: str, metadata: Optional[Dict] = None) -> str:
        """Start recording a new trajectory"""
        trajectory_id = f"traj_{uuid.uuid4().hex[:16]}"
        self._current_trajectory = Trajectory(
            trajectory_id=trajectory_id,
            tenant_id=self._extract_tenant_id(),
            task_description=task_description,
            steps=[],
            status=TaskStatus.PARTIAL,
            metadata=metadata or {},
        )
        self._steps_buffer = []
        return trajectory_id

    def record_step(
        self,
        action: str,
        tool_name: Optional[str] = None,
        tool_input: Optional[Dict] = None,
        tool_output: Optional[Any] = None,
        reasoning: Optional[str] = None,
        tokens_used: int = 0,
        latency_ms: int = 0,
    ) -> None:
        """Record a single step in the current trajectory"""
        if self._current_trajectory is None:
            raise RuntimeError("No active trajectory. Call start_trajectory() first.")

        step = Step(
            step_id=f"step_{len(self._steps_buffer) + 1}",
            action=action,
            tool_name=tool_name,
            tool_input=tool_input,
            tool_output=tool_output,
            reasoning=reasoning,
            tokens_used=tokens_used,
            latency_ms=latency_ms,
        )
        self._steps_buffer.append(step)

    def end_trajectory(
        self,
        status: TaskStatus,
        actual_output: Optional[Any] = None,
        expected_output: Optional[Any] = None,
        agent_confidence: Optional[float] = None,
    ) -> Trajectory:
        """End the current trajectory and optionally ingest it.

        Args:
            status: Task execution status
            actual_output: What the agent actually produced (for validation)
            expected_output: What the correct answer should be (for validation)
            agent_confidence: Agent's self-reported confidence (0.0-1.0)
        """
        if self._current_trajectory is None:
            raise RuntimeError("No active trajectory.")

        self._current_trajectory.steps = self._steps_buffer
        self._current_trajectory.status = status
        self._current_trajectory.total_tokens = sum(s.tokens_used for s in self._steps_buffer)
        self._current_trajectory.total_latency_ms = sum(s.latency_ms for s in self._steps_buffer)
        self._current_trajectory.expected_output = expected_output
        self._current_trajectory.actual_output = actual_output
        self._current_trajectory.agent_confidence = agent_confidence

        trajectory = self._current_trajectory

        # Auto-ingest ALL trajectories (not just success)
        # Failures carry learning signal too, especially with expected_output
        if self.config.auto_ingest:
            self.ingest(trajectory)

        self._current_trajectory = None
        self._steps_buffer = []

        return trajectory

    # =========================================================================
    # API Endpoints
    # =========================================================================

    def ingest(self, trajectory: Trajectory) -> Dict[str, Any]:
        """
        Ingest a trajectory into Zubbl for learning.

        POST /ingest
        """
        response = self._sync_client.post(
            "/ingest",
            json=trajectory.model_dump(mode="json"),
        )
        response.raise_for_status()
        return response.json()

    async def ingest_async(self, trajectory: Trajectory) -> Dict[str, Any]:
        """Async version of ingest"""
        response = await self._client.post(
            "/ingest",
            json=trajectory.model_dump(mode="json"),
        )
        response.raise_for_status()
        return response.json()

    def query(self, task_description: str, context: Optional[Dict] = None) -> Optional[Policy]:
        """
        Query for a policy recommendation before starting a task.

        GET /query
        """
        task_hash = self._hash_task(task_description)

        # Check cache first
        if self.config.local_cache and task_hash in self._policy_cache:
            return self._policy_cache[task_hash]

        response = self._sync_client.get(
            "/query",
            params={
                "task": task_description,
                "context": str(context) if context else None,
                "rl_mode": self.config.rl_mode.value,
            },
        )

        if response.status_code == 404:
            return None  # No policy found for this task type

        response.raise_for_status()
        data = response.json()

        if data:
            policy = Policy(**data)
            if self.config.local_cache:
                self._policy_cache[task_hash] = policy
            return policy
        return None

    async def query_async(
        self, task_description: str, context: Optional[Dict] = None
    ) -> Optional[Policy]:
        """Async version of query"""
        task_hash = self._hash_task(task_description)

        if self.config.local_cache and task_hash in self._policy_cache:
            return self._policy_cache[task_hash]

        response = await self._client.get(
            "/query",
            params={
                "task": task_description,
                "context": str(context) if context else None,
                "rl_mode": self.config.rl_mode.value,
            },
        )

        if response.status_code == 404:
            return None

        response.raise_for_status()
        data = response.json()

        if data:
            policy = Policy(**data)
            if self.config.local_cache:
                self._policy_cache[task_hash] = policy
            return policy
        return None

    def feedback(
        self, trajectory_id: str, rating: float, comment: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Submit feedback for a trajectory.

        POST /feedback
        """
        feedback = Feedback(
            feedback_id=f"fb_{uuid.uuid4().hex[:12]}",
            trajectory_id=trajectory_id,
            rating=rating,
            comment=comment,
        )

        response = self._sync_client.post(
            "/feedback",
            json=feedback.model_dump(mode="json"),
        )
        response.raise_for_status()
        return response.json()

    def validate(
        self,
        trajectory_id: str,
        expected_output: Any,
        actual_output: Optional[Any] = None,
        agent_confidence: float = 0.0,
    ) -> Dict[str, Any]:
        """
        Post-hoc validation of a trajectory's output.

        Use this when the ground truth becomes available after the agent ran.
        Detects confident-but-wrong cases automatically.

        POST /validate

        Args:
            trajectory_id: ID of the trajectory to validate
            expected_output: The correct answer
            actual_output: What the agent produced (fetched from DB if not provided)
            agent_confidence: Agent's self-reported confidence (0.0-1.0)

        Returns:
            Dict with correctness_score, is_confidence_mismatch, etc.
        """
        response = self._sync_client.post(
            "/validate",
            json={
                "trajectory_id": trajectory_id,
                "expected_output": expected_output,
                "actual_output": actual_output,
                "agent_confidence": agent_confidence,
            },
        )
        response.raise_for_status()
        return response.json()

    def get_usage(self) -> UsageStats:
        """Get current usage statistics"""
        response = self._sync_client.get("/usage")
        response.raise_for_status()
        return UsageStats(**response.json())

    def sync_failure_patterns(self) -> Dict[str, Any]:
        """
        Sync failure patterns with the Zubbl server.

        Uploads local patterns learned this session, downloads patterns
        from previous sessions (including fixes that worked).

        Call this on startup to pre-load known fixes, and periodically
        to share new learnings with the server.

        Returns:
            Dict with sync stats (total patterns, patterns with fixes, etc.)
        """
        # Export local patterns
        local_patterns = self._interceptor.export_patterns()

        try:
            response = self._sync_client.post(
                "/failure-patterns/sync",
                json={"patterns": local_patterns},
            )
            response.raise_for_status()
            data = response.json()

            # Load server patterns into interceptor
            self._interceptor.load_patterns_from_server(data.get("patterns", []))
            self._interceptor.load_prompt_patches(data.get("prompt_patches", {}))

            return data.get("stats", {})
        except Exception:
            # Sync failure is non-critical — interceptor works locally
            return {"synced": False, "local_patterns": len(local_patterns)}

    def get_failure_stats(self) -> Dict[str, Any]:
        """
        Get failure recovery statistics.

        Shows how many failures Zubbl has auto-recovered,
        what fix types work best, and failure categories.
        """
        try:
            response = self._sync_client.get("/failure-patterns/stats")
            response.raise_for_status()
            return response.json()
        except Exception:
            return {"error": "Could not fetch stats"}

    # =========================================================================
    # Helper Methods
    # =========================================================================

    def _extract_tenant_id(self) -> str:
        """Extract tenant ID from API key (format: zubbl_<tenant_id>_<secret>)"""
        parts = self.config.api_key.split("_")
        if len(parts) >= 3:
            return "_".join(parts[1:-1])
        if len(parts) == 2:
            return parts[1]
        return hashlib.sha256(self.config.api_key.encode()).hexdigest()[:16]

    def _hash_task(self, task_description: str) -> str:
        """Create a hash for task caching"""
        normalized = task_description.lower().strip()
        return hashlib.md5(normalized.encode()).hexdigest()[:12]

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self._sync_client.close()

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self._client.aclose()


class ZubblWrappedAgent:
    """
    A wrapped agent that automatically:
    1. Records execution trajectories
    2. Queries policies before execution
    3. Intercepts failures and auto-recovers
    4. Learns from both successes and failures

    The auto_recover flag is the key difference from a simple wrapper:
    - auto_recover=False: Record + Learn only (old behavior)
    - auto_recover=True: Record + Learn + Fix failures in real-time (the product)
    """

    def __init__(self, client: ZubblClient, agent: Any, auto_recover: bool = True):
        self._client = client
        self._agent = agent
        self._auto_recover = auto_recover

    def __getattr__(self, name: str) -> Any:
        """Proxy all attribute access to the underlying agent"""
        attr = getattr(self._agent, name)

        # Wrap callable methods to record trajectories + auto-recover
        if callable(attr):
            return self._wrap_method(attr, name)
        return attr

    def __call__(self, *args, **kwargs):
        """Make the wrapped agent callable with auto-recovery"""
        task_desc = str(args[0]) if args else "default_task"

        # Query for policy before execution
        if self._client.config.auto_query:
            policy = self._client.query(task_desc)
            self._client._current_policy = policy

        # Start trajectory
        self._client.start_trajectory(task_desc)

        if self._auto_recover:
            return self._call_with_recovery(task_desc, args, kwargs)
        else:
            return self._call_without_recovery(args, kwargs)

    def _call_with_recovery(self, task_desc: str, args: tuple, kwargs: dict) -> Any:
        """Execute with auto-recovery — the core product behavior"""
        from zubbl.task_utils import normalize_task_type

        task_type = normalize_task_type(task_desc)

        # Use the interceptor for automatic failure recovery
        recovery = self._client._interceptor.intercept_and_recover(
            func=self._agent,
            args=args,
            kwargs=kwargs,
            task_description=task_desc,
            task_type=task_type,
        )

        # Store recovery result for inspection
        self._client._last_recovery = recovery

        if recovery.success:
            # Record what happened
            self._client.record_step(
                action="call_agent",
                tool_output=str(recovery.recovered_output)[:1000],
                latency_ms=recovery.latency_ms,
                reasoning=f"attempts={recovery.attempts}, fix={recovery.fix_applied.value if recovery.fix_applied else 'none'}",
            )

            # If a fix was applied, record it as a separate step (learning signal)
            if recovery.fix_applied:
                self._client.record_step(
                    action="zubbl_auto_recovery",
                    tool_name="interceptor",
                    tool_input={
                        "fix_type": recovery.fix_applied.value,
                        "original_error": recovery.original_error,
                        "attempts": recovery.attempts,
                    },
                    tool_output="recovery_successful",
                    reasoning=f"Auto-recovered from: {recovery.original_error}",
                )

            self._client.end_trajectory(TaskStatus.SUCCESS)
            return recovery.recovered_output
        else:
            # All recovery attempts failed
            self._client.record_step(
                action="call_agent",
                tool_output=f"ERROR: {recovery.original_error}",
                latency_ms=recovery.latency_ms,
                reasoning=f"All {recovery.attempts} recovery attempts failed",
            )
            self._client.end_trajectory(TaskStatus.FAILURE)
            raise RuntimeError(
                f"Agent failed and auto-recovery exhausted "
                f"({recovery.attempts} attempts): {recovery.original_error}"
            )

    def _call_without_recovery(self, args: tuple, kwargs: dict) -> Any:
        """Execute without auto-recovery (legacy behavior)"""
        self._client.record_step(
            action="call_agent",
            tool_input={"args": str(args)[:200], "kwargs": str(kwargs)[:200]},
        )

        try:
            result = self._agent(*args, **kwargs)
            self._client.record_step(
                action="agent_response",
                tool_output=str(result)[:200],
            )
            self._client.end_trajectory(TaskStatus.SUCCESS)
            return result
        except Exception as e:
            self._client.record_step(
                action="agent_error",
                tool_output=str(e),
            )
            self._client.end_trajectory(TaskStatus.FAILURE)
            raise

    def _wrap_method(self, method: Callable, method_name: str) -> Callable:
        """Wrap a method to record its execution + auto-recover from failures"""

        @wraps(method)
        def wrapper(*args, **kwargs):
            task_desc = kwargs.get("task", str(args[0]) if args else method_name)

            if self._client.config.auto_query:
                policy = self._client.query(task_desc)
                self._client._current_policy = policy

            self._client.start_trajectory(task_desc)

            if self._auto_recover:
                return self._method_with_recovery(method, method_name, task_desc, args, kwargs)
            else:
                return self._method_without_recovery(method, method_name, args, kwargs)

        @wraps(method)
        async def async_wrapper(*args, **kwargs):
            task_desc = kwargs.get("task", str(args[0]) if args else method_name)

            if self._client.config.auto_query:
                policy = await self._client.query_async(task_desc)
                self._client._current_policy = policy

            self._client.start_trajectory(task_desc)

            # Async recovery: run sync interceptor in executor
            # (native async interceptor)
            try:
                start_time = datetime.utcnow()
                result = await method(*args, **kwargs)
                latency = int((datetime.utcnow() - start_time).total_seconds() * 1000)

                self._client.record_step(
                    action=method_name,
                    tool_input={"args": str(args)[:200], "kwargs": str(kwargs)[:200]},
                    tool_output=str(result)[:1000],
                    latency_ms=latency,
                )
                self._client.end_trajectory(TaskStatus.SUCCESS)
                return result

            except Exception as e:
                self._client.record_step(
                    action=method_name,
                    tool_input={"args": str(args)[:200], "kwargs": str(kwargs)[:200]},
                    tool_output=f"ERROR: {str(e)}",
                )
                self._client.end_trajectory(TaskStatus.FAILURE)
                raise

        if asyncio.iscoroutinefunction(method):
            return async_wrapper
        return wrapper

    def _method_with_recovery(
        self, method: Callable, method_name: str, task_desc: str, args: tuple, kwargs: dict
    ) -> Any:
        """Execute a method with auto-recovery"""
        from zubbl.task_utils import normalize_task_type

        task_type = normalize_task_type(task_desc)

        recovery = self._client._interceptor.intercept_and_recover(
            func=method,
            args=args,
            kwargs=kwargs,
            task_description=task_desc,
            task_type=task_type,
        )

        self._client._last_recovery = recovery

        if recovery.success:
            self._client.record_step(
                action=method_name,
                tool_input={"args": str(args)[:200], "kwargs": str(kwargs)[:200]},
                tool_output=str(recovery.recovered_output)[:1000],
                latency_ms=recovery.latency_ms,
            )

            if recovery.fix_applied:
                self._client.record_step(
                    action="zubbl_auto_recovery",
                    tool_name="interceptor",
                    tool_input={
                        "fix_type": recovery.fix_applied.value,
                        "original_error": recovery.original_error,
                    },
                    tool_output="recovery_successful",
                    reasoning=f"Auto-recovered {method_name} from: {recovery.original_error}",
                )

            self._client.end_trajectory(TaskStatus.SUCCESS)
            return recovery.recovered_output
        else:
            self._client.record_step(
                action=method_name,
                tool_output=f"ERROR: {recovery.original_error}",
                reasoning=f"All {recovery.attempts} recovery attempts failed",
            )
            self._client.end_trajectory(TaskStatus.FAILURE)
            raise RuntimeError(
                f"{method_name} failed and auto-recovery exhausted "
                f"({recovery.attempts} attempts): {recovery.original_error}"
            )

    def _method_without_recovery(
        self, method: Callable, method_name: str, args: tuple, kwargs: dict
    ) -> Any:
        """Execute a method without auto-recovery (legacy behavior)"""
        try:
            start_time = datetime.utcnow()
            result = method(*args, **kwargs)
            latency = int((datetime.utcnow() - start_time).total_seconds() * 1000)

            self._client.record_step(
                action=method_name,
                tool_input={"args": str(args)[:200], "kwargs": str(kwargs)[:200]},
                tool_output=str(result)[:1000],
                latency_ms=latency,
            )
            self._client.end_trajectory(TaskStatus.SUCCESS)
            return result

        except Exception as e:
            self._client.record_step(
                action=method_name,
                tool_input={"args": str(args)[:200], "kwargs": str(kwargs)[:200]},
                tool_output=f"ERROR: {str(e)}",
            )
            self._client.end_trajectory(TaskStatus.FAILURE)
            raise

    @property
    def unwrapped(self) -> Any:
        """Get the original unwrapped agent"""
        return self._agent
