# Zubbl

**Self-Evolving AI Agent SDK** — Make any AI agent 20-50% smarter, automatically.

Zubbl combines **trajectory learning** (cross-task pattern extraction) with **reflexion** (per-task verbal self-correction) to create a dual-loop improvement system. Your agent fails, Zubbl captures it, reflects on what went wrong, learns a reusable policy, and improves next time. No code changes, no redeployment.

**Eval results:** Baseline 82% → Post-Zubbl 88% (+6 points) on HotPotQA hard reasoning tasks. 3 of 9 failures recovered via reflexion.

## Install

```bash
pip install zubbl
```

## Quick Start

```python
from zubbl import ZubblClient

zubbl = ZubblClient(api_key="your-api-key")
agent = zubbl.wrap(your_agent)  # That's it.
```

## How It Works — Dual Learning Loop

```
Agent fails a task
        │
        ├──► Trajectory Learning (cross-task)
        │      Captures execution trajectory → extracts patterns →
        │      scores policies → serves recommendations for similar tasks
        │
        └──► Reflexion (per-task, NeurIPS 2023)
               LLM generates verbal self-reflection on failure →
               agent retries with reflection in-context →
               successful retry becomes a new trajectory for cross-task learning
```

Based on: Reflexion (NeurIPS 2023), ExpeL (AAAI 2024), ACE (ICLR 2026).

## Project Structure

```
src/
  zubbl/       SDK package (core client, LLM wrapper, guardrails, interceptor)
  api/         FastAPI backend with migrations
  db/          Database client
  worker/      Background jobs (validator, reflector, RL worker)
edge/          Cloudflare Workers edge function
eval/          Benchmark eval harness (HotPotQA, MBPP)
k8s/           Kubernetes deployment configs
tests/         Test suite (pytest)
docs/          Documentation
scripts/       Deployment scripts
examples/      Usage examples
```

## Development

```bash
pip install -e ".[dev]"
pytest tests/
```

## Deployment

```bash
bash scripts/deploy.sh
```

See [docs/Deployment-Guide.md](docs/Deployment-Guide.md) for full instructions.

## Links

- **Docs:** https://docs.zubbl.ai
- **Website:** https://zubbl.ai

## License

MIT
