﻿# MediLink GCP Baseline

This folder documents the legacy baseline rebuild for the Apps Script plus XP/local Gmail helper integration. It exists to restore or reason about the older dual-flow integration path; it is not the canonical cloud runtime for the current repository.

For the maintained cloud runtime, use `cloud/orchestrator/` and its validator-first workflow.

## Scope of This Folder

This baseline path is specifically about the legacy combination of:

- Apps Script web app / Execution API assets in `MediLink/`
- local desktop OAuth flow used by `MediLink_Gmail.py`
- manual OTP handling and non-OTP attachment download flow

Use this folder when you need parity, rollback support, or investigation of the legacy integration path.

## Current Files

- `setup_gcp.sh`: bootstrap the dedicated GCP project and OAuth setup for the legacy baseline
- `post_setup_checklist.md`: manual follow-up and validation checklist
- `apps_script_link_and_redeploy.md`: how to link the Apps Script project to GCP and redeploy
- `local_token_refresh.md`: refresh and validate the local desktop token path
- `desktop_client_raw.json`: raw desktop OAuth client artifact
- `web_client_raw.json`: raw web OAuth client artifact

## Relationship to the Rest of the Repo

- `MediLink/`: legacy clinic-side Python and Apps Script workflow code
- `cloud/orchestrator/`: maintained cloud ingestion/runtime path
- `xp_client/`: XP-side consumer for the newer cloud queue flow
- `docs/MEDILINK_CLOUD_MIGRATION.md`: migration context and current posture

This folder should not be mistaken for the current cloud deployment surface.

## Typical Baseline Workflow

1. Review `post_setup_checklist.md`.
2. Run `setup_gcp.sh` with the required project, billing, support, and script identifiers.
3. Follow `apps_script_link_and_redeploy.md`.
4. Follow `local_token_refresh.md`.
5. Validate both the manual OTP path and the non-OTP attachment path.

## Handling Guidance

- Treat the raw client JSON files as sensitive operational artifacts.
- Keep additional legacy-baseline helpers inside this folder if they are still needed.
- Do not move current cloud runtime guidance here; keep that in `cloud/orchestrator/` and `docs/runbooks/`.
