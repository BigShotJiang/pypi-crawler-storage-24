import json, os, time, requests

# Google OAuth API endpoints
GOOGLE_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
GOOGLE_TOKENINFO_URL = "https://www.googleapis.com/oauth2/v1/tokeninfo"

# Refresh failure taxonomy (logged + used for cache-clear policy)
REFRESH_TAXONOMY_SUCCESS = "success"
REFRESH_TAXONOMY_INVALID_GRANT = "invalid_grant"
REFRESH_TAXONOMY_TRANSIENT_NETWORK = "transient_network"
REFRESH_TAXONOMY_SERVER_ERROR = "server_error"
REFRESH_TAXONOMY_RATE_LIMITED = "rate_limited"
REFRESH_TAXONOMY_OAUTH_CLIENT_ERROR = "oauth_client_error"
REFRESH_TAXONOMY_UNKNOWN = "unknown"
REFRESH_TAXONOMY_COOLDOWN = "cooldown"

_LAST_REFRESH_FAILURE_TS = 0.0
_LAST_FAILURE_TAXONOMY = None
_REFRESH_FAILURE_COOLDOWN_SEC = 3.0


def _parse_token_error_body(response):
    """Best-effort JSON body from token endpoint."""
    try:
        return response.json()
    except (ValueError, TypeError):
        return {}


def _classify_refresh_failure(status_code, oauth_body, request_exc):
    """
    Return (taxonomy, short_detail) for logging. oauth_body is dict with optional 'error' / 'error_description'.
    """
    if request_exc is not None:
        return REFRESH_TAXONOMY_TRANSIENT_NETWORK, str(request_exc)
    err = ""
    if isinstance(oauth_body, dict):
        err = str(oauth_body.get("error") or "").strip()
    if status_code >= 500:
        return REFRESH_TAXONOMY_SERVER_ERROR, "http_{}".format(status_code)
    if status_code == 429:
        return REFRESH_TAXONOMY_RATE_LIMITED, err or "http_429"
    if err in ("invalid_grant", "invalid_client"):
        return REFRESH_TAXONOMY_INVALID_GRANT, err
    if err in ("temporarily_unavailable", "slow_down"):
        return REFRESH_TAXONOMY_RATE_LIMITED, err
    if 400 <= status_code < 500:
        return REFRESH_TAXONOMY_OAUTH_CLIENT_ERROR, err or "http_{}".format(status_code)
    return REFRESH_TAXONOMY_UNKNOWN, "http_{}".format(status_code)


def _log_refresh_taxonomy_summary(log, taxonomy, detail, status_code=None, remediation=None):
    """Single high-signal line for support."""
    parts = ["OAuth_refresh", "taxonomy={}".format(taxonomy), "detail={}".format(detail)]
    if status_code is not None:
        parts.append("status_code={}".format(status_code))
    if remediation:
        parts.append("remediation={}".format(remediation))
    log(" ".join(parts), level="WARNING")


def refresh_access_token_detailed(refresh_token, credentials_path, log):
    """
    Refresh access token with retries on transient failures.
    Returns (token_dict, taxonomy_on_failure). On success, taxonomy is REFRESH_TAXONOMY_SUCCESS and dict has access_token.
    """
    global _LAST_REFRESH_FAILURE_TS, _LAST_FAILURE_TAXONOMY
    log("Refreshing access token.")
    try:
        with open(credentials_path, "r") as credentials_file:
            credentials = json.load(credentials_file)
    except (IOError, ValueError, KeyError) as e:
        _log_refresh_taxonomy_summary(
            log, REFRESH_TAXONOMY_UNKNOWN, "credentials_read_error: {}".format(e), remediation="check_credentials_path"
        )
        return {}, REFRESH_TAXONOMY_UNKNOWN

    data = {
        "client_id": credentials["web"]["client_id"],
        "client_secret": credentials["web"]["client_secret"],
        "refresh_token": refresh_token,
        "grant_type": "refresh_token",
    }

    max_attempts = 3
    backoff_delays = (0.0, 0.75, 1.5)
    last_taxonomy = REFRESH_TAXONOMY_UNKNOWN
    last_detail = ""
    last_status = None

    if _LAST_FAILURE_TAXONOMY in (
        REFRESH_TAXONOMY_TRANSIENT_NETWORK,
        REFRESH_TAXONOMY_SERVER_ERROR,
        REFRESH_TAXONOMY_RATE_LIMITED,
    ):
        elapsed = time.time() - _LAST_REFRESH_FAILURE_TS
        if elapsed < _REFRESH_FAILURE_COOLDOWN_SEC:
            log(
                "OAuth refresh deferred ({:.1f}s cooldown after transient failure taxonomy={}).".format(
                    _REFRESH_FAILURE_COOLDOWN_SEC, _LAST_FAILURE_TAXONOMY
                ),
                level="DEBUG",
            )
            return {}, REFRESH_TAXONOMY_COOLDOWN

    for attempt in range(max_attempts):
        delay = backoff_delays[attempt] if attempt < len(backoff_delays) else backoff_delays[-1]
        if delay > 0:
            time.sleep(delay)
        request_exc = None
        try:
            response = requests.post(GOOGLE_TOKEN_URL, data=data, timeout=30)
        except requests.exceptions.RequestException as e:
            request_exc = e
            response = None

        if request_exc is not None:
            last_taxonomy = REFRESH_TAXONOMY_TRANSIENT_NETWORK
            last_detail = str(request_exc)
            last_status = None
            log(
                "Refresh token attempt {}/{} network error: {}".format(attempt + 1, max_attempts, request_exc),
                level="DEBUG",
            )
            if attempt < max_attempts - 1:
                continue
            _LAST_REFRESH_FAILURE_TS = time.time()
            _LAST_FAILURE_TAXONOMY = last_taxonomy
            _log_refresh_taxonomy_summary(
                log,
                last_taxonomy,
                last_detail,
                remediation="check_network_firewall_clock",
            )
            return {}, last_taxonomy

        status = response.status_code
        last_status = status
        body_text = response.text
        log(
            "Refresh token response: Status code {}, Body:\n {}".format(status, body_text),
            level="DEBUG",
        )
        if status == 200:
            try:
                parsed = response.json()
            except (ValueError, TypeError):
                last_taxonomy = REFRESH_TAXONOMY_UNKNOWN
                last_detail = "invalid_json_in_200"
                if attempt < max_attempts - 1:
                    continue
                _LAST_REFRESH_FAILURE_TS = time.time()
                _LAST_FAILURE_TAXONOMY = last_taxonomy
                _log_refresh_taxonomy_summary(log, last_taxonomy, last_detail, status_code=status)
                return {}, last_taxonomy
            log("Access token refreshed successfully.")
            _LAST_FAILURE_TAXONOMY = None
            _LAST_REFRESH_FAILURE_TS = 0.0
            return parsed, REFRESH_TAXONOMY_SUCCESS

        oauth_body = _parse_token_error_body(response)
        last_taxonomy, last_detail = _classify_refresh_failure(status, oauth_body, None)

        if last_taxonomy == REFRESH_TAXONOMY_INVALID_GRANT:
            _LAST_REFRESH_FAILURE_TS = time.time()
            _LAST_FAILURE_TAXONOMY = last_taxonomy
            remed = "re_authenticate_consent_or_check_client_secret"
            _log_refresh_taxonomy_summary(
                log, last_taxonomy, last_detail, status_code=status, remediation=remed
            )
            return {}, last_taxonomy

        retryable = last_taxonomy in (
            REFRESH_TAXONOMY_TRANSIENT_NETWORK,
            REFRESH_TAXONOMY_SERVER_ERROR,
            REFRESH_TAXONOMY_RATE_LIMITED,
        )
        if retryable and attempt < max_attempts - 1:
            log(
                "Refresh failed ({}); retrying ({}/{})".format(last_taxonomy, attempt + 1, max_attempts),
                level="DEBUG",
            )
            continue

        _LAST_REFRESH_FAILURE_TS = time.time()
        _LAST_FAILURE_TAXONOMY = last_taxonomy
        remed = None
        if last_taxonomy == REFRESH_TAXONOMY_SERVER_ERROR:
            remed = "retry_later"
        elif last_taxonomy == REFRESH_TAXONOMY_RATE_LIMITED:
            remed = "wait_and_retry"
        elif last_taxonomy == REFRESH_TAXONOMY_OAUTH_CLIENT_ERROR:
            remed = "check_oauth_client_config"
        _log_refresh_taxonomy_summary(
            log, last_taxonomy, last_detail, status_code=last_status, remediation=remed
        )
        return {}, last_taxonomy

    return {}, last_taxonomy


def get_authorization_url(credentials_path, redirect_uri, scopes, log):
    """
    Build the Google OAuth authorization URL using the provided credentials file, redirect URI, and scopes.
    """
    with open(credentials_path, 'r') as credentials_file:
        credentials = json.load(credentials_file)
    client_id = credentials['web']['client_id']
    auth_url = (
        GOOGLE_AUTH_URL + "?" +
        "response_type=code&"
        "client_id={}&"
        "redirect_uri={}&"
        "scope={}&"
        "access_type=offline&"
        "prompt=consent"
    ).format(client_id, redirect_uri, scopes)
    log("Generated authorization URL: {}".format(auth_url))
    return auth_url


def exchange_code_for_token(auth_code, credentials_path, redirect_uri, log, retries=3):
    """
    Exchange an authorization code for tokens using credentials; retries a few times on failure.
    """
    for attempt in range(retries):
        try:
            with open(credentials_path, 'r') as credentials_file:
                credentials = json.load(credentials_file)
            token_url = GOOGLE_TOKEN_URL
            data = {
                'code': auth_code,
                'client_id': credentials['web']['client_id'],
                'client_secret': credentials['web']['client_secret'],
                'redirect_uri': redirect_uri,
                'grant_type': 'authorization_code'
            }
            response = requests.post(token_url, data=data)
            log("Token exchange response: Status code {}, Body: {}".format(response.status_code, response.text))
            token_response = response.json()
            if response.status_code == 200:
                token_response['token_time'] = time.time()
                return token_response
            else:
                log("Token exchange failed: {}".format(token_response))
                if attempt < retries - 1:
                    log("Retrying token exchange... (Attempt {}/{})".format(attempt + 1, retries))
        except (IOError, ValueError, KeyError, requests.exceptions.RequestException) as e:
            log("Error during token exchange: {}".format(e))
    return {}




def is_valid_authorization_code(auth_code, log):
    """
    Validate auth code shape without side effects.
    """
    if auth_code and isinstance(auth_code, str) and len(auth_code) > 0:
        return True
    log("Invalid authorization code format: {}".format(auth_code))
    return False


def clear_token_cache(token_path, log):
    """
    Delete token cache file if present.
    """
    if os.path.exists(token_path):
        os.remove(token_path)
        log("Cleared token cache.")


def load_token_file(token_path, log):
    """Load token data from file, return dict or None if file doesn't exist"""
    if os.path.exists(token_path):
        try:
            with open(token_path, 'r') as token_file:
                return json.load(token_file)
        except (IOError, ValueError) as e:
            log("Error loading token file: {}".format(e), level="ERROR")
            return None
    return None


def validate_token_data(token_data, log):
    """Validate token data structure. Returns True if valid, False otherwise."""
    if not isinstance(token_data, dict):
        log("Token data is not a dictionary", level="ERROR")
        return False

    if 'access_token' not in token_data or 'expires_in' not in token_data:
        log("Token file is missing required fields: access_token or expires_in", level="WARNING")
        return False

    return True


def compute_expiry(token_data, now, log):
    """Compute token expiry time. Returns expiry timestamp or None on error."""
    try:
        token_time = token_data.get('token_time', now)
        expires_at = token_time + token_data['expires_in']
        return expires_at
    except (KeyError, TypeError, ValueError) as e:
        log("Error calculating token expiry: {}".format(e), level="ERROR")
        return None


def is_token_expired(expires_at, now):
    """Check if token is expired. Returns True if expired."""
    return expires_at <= now


def refresh_and_save_token(token_path, credentials_path, refresh_token, log):
    """Refresh token and save to file. Returns new access_token or None on failure."""
    new_token_data, taxonomy = refresh_access_token_detailed(refresh_token, credentials_path, log)
    if "access_token" not in new_token_data:
        if taxonomy == REFRESH_TAXONOMY_INVALID_GRANT:
            clear_token_cache(token_path, log)
            log("Cleared token cache after invalid_grant; re-authentication required.", level="WARNING")
        else:
            log(
                "Refresh failed (taxonomy={}); token file left in place for retry.".format(taxonomy),
                level="WARNING",
            )
        return None

    # Preserve refresh_token if not in new response (Google refresh doesn't always return it)
    if "refresh_token" not in new_token_data and refresh_token:
        new_token_data["refresh_token"] = refresh_token

    # Save refreshed token
    if save_token_file(token_path, new_token_data, log):
        log("Access token refreshed successfully.", level="INFO")
        return new_token_data["access_token"]
    else:
        log("Failed to save refreshed token.", level="ERROR")
        return None


def save_token_file(token_path, token_data, log):
    """Save token data to file with token_time set"""
    try:
        token_data['token_time'] = time.time()
        with open(token_path, 'w') as token_file:
            json.dump(token_data, token_file)
        log("Token file saved successfully.", level="DEBUG")
        return True
    except (IOError, TypeError) as e:
        log("Error saving token file: {}".format(e), level="ERROR")
        return False


def get_access_token_with_refresh(token_path, credentials_path, log, quiet=False):
    """
    Get access token from file, refresh if expired, with proper validation.
    Returns access_token string or None if re-authentication needed.
    """
    token_data = load_token_file(token_path, log)
    if not token_data:
        if not quiet:
            log("Access token not found. Please authenticate.", level="INFO")
        return None

    if not validate_token_data(token_data, log):
        clear_token_cache(token_path, log)
        return None

    current_time = time.time()
    expires_at = compute_expiry(token_data, current_time, log)
    if expires_at is None:
        clear_token_cache(token_path, log)
        return None

    if not is_token_expired(expires_at, current_time):
        log("Access token is still valid. Expires in {} seconds.".format(int(expires_at - current_time)), level="DEBUG")
        return token_data['access_token']

    # Token expired, try to refresh
    log("Access token has expired. Current time: {}, Expiry time: {}".format(current_time, expires_at), level="DEBUG")
    refresh_token_value = token_data.get('refresh_token')
    if not refresh_token_value:
        log("Refresh token not found in token file. Re-authentication required.", level="WARNING")
        clear_token_cache(token_path, log)
        return None

    return refresh_and_save_token(token_path, credentials_path, refresh_token_value, log)


def refresh_access_token(refresh_token, credentials_path, log):
    """
    Refresh an access token using the stored client credentials.
    Returns dict with access_token and expires_in, or empty dict on failure.
    """
    data, _taxonomy = refresh_access_token_detailed(refresh_token, credentials_path, log)
    return data
