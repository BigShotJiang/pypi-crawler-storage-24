# MediLink_UI.py
from datetime import datetime
import os, sys
import json
import csv

# Set up paths using core utilities
from MediCafe.core_utils import setup_module_paths
setup_module_paths(__file__)

from MediCafe.core_utils import get_config_loader_with_fallback, extract_medilink_config
MediLink_ConfigLoader = get_config_loader_with_fallback()
import MediLink_DataMgmt
import MediLink_PatientProcessor
import MediLink_Display_Utils

try:
    from MediLink_RemittancePipeline import (
        group_records_for_merge,
        merge_remittance_group,
        canonical_to_posting_row,
    )
except ImportError:
    group_records_for_merge = None
    merge_remittance_group = None
    canonical_to_posting_row = None

try:
    from MediCafe.error_reporter import (
        collect_support_bundle,
        submit_support_bundle_email,
        list_queued_bundles,
        submit_all_queued_bundles,
        resolve_queued_bundles_flow,
    )
except ImportError:
    collect_support_bundle = None
    submit_support_bundle_email = None
    list_queued_bundles = None
    submit_all_queued_bundles = None
    resolve_queued_bundles_flow = None

def display_welcome():
    print("\n" + "-" * 60)
    print("          *~^~*:    Welcome to MediLink!    :*~^~*")
    print("-" * 60)

def display_menu(options, zero_option=None):
    print("Menu Options:")
    if zero_option is not None:
        print("0. {0}".format(zero_option))
    for i, option in enumerate(options):
        print("{0}. {1}".format(i + 1, option))
    try:
        sys.stdout.flush()
    except Exception:
        pass

def get_user_choice():
    """Get menu choice with flush-safe prompt so it appears under buffered/redirected stdout."""
    prompt = "Enter your choice: "
    try:
        sys.stdout.write(prompt)
        sys.stdout.flush()
    except Exception:
        pass
    return input().strip()

def display_exit_message():
    print("\nExiting MediLink.")

def display_invalid_choice():
    print("Invalid choice. Please select a valid option.")

def prompt_press_enter_to_continue():
    """Single place for 'Press Enter to continue' prompt. ASCII, XP/Python 3.4 compatible."""
    try:
        input("\nPress Enter to continue...")
    except Exception:
        pass

def display_section_header(title):
    """Print a 60-char separator, title, and separator. ASCII-only."""
    print("\n" + "="*60)
    print(title)
    print("="*60)

def display_connectivity_results(connectivity_results):
    """Print connectivity test results dict from MediLink_Down.test_endpoint_connectivity. ASCII-only."""
    print("\nConnectivity Test Results:")
    print("="*60)
    for endpoint, res in connectivity_results.items():
        print("\n{}: {}".format(endpoint, res["status"]))
        for detail in res["details"]:
            print("  - {}".format(detail))
    print("\n" + "="*60)

def view_remittance_summary(config):
    """
    View summary of remittance data from JSONL ledgers.
    Displays file ledger, posting queue, and parsed remittance counts.
    ASCII-only, XP/Python 3.4 compatible.
    """
    medi = extract_medilink_config(config)
    local_storage = medi.get('local_storage_path', '.')
    display_section_header("Remittance Data Summary")

    file_ledger_path = os.path.join(local_storage, 'remittance_file_ledger.jsonl')
    parsed_path = os.path.join(local_storage, 'remittance_parsed.jsonl')

    print("\nFile Ledger:")
    if os.path.exists(file_ledger_path):
        try:
            file_count = 0
            file_types = {}
            with open(file_ledger_path, 'r') as f:
                for line in f:
                    if line.strip():
                        file_count += 1
                        try:
                            record = json.loads(line)
                            ftype = record.get('file_type', 'unknown')
                            file_types[ftype] = file_types.get(ftype, 0) + 1
                        except Exception:
                            pass
            print("  Total files: {}".format(file_count))
            for ftype, count in file_types.items():
                print("    {}: {}".format(ftype, count))
        except Exception as e:
            print("  Error reading file ledger: {}".format(e))
    else:
        print("  No file ledger found. Run 'Sync now' to populate.")

    print("\nExport basis (merged view from remittance_parsed.jsonl):")
    if os.path.exists(parsed_path) and group_records_for_merge and merge_remittance_group:
        try:
            records = []
            with open(parsed_path, 'r') as f:
                for line in f:
                    if line.strip():
                        try:
                            records.append(json.loads(line))
                        except Exception:
                            pass
            groups = group_records_for_merge(records)
            merged_rows = []
            for _gk, rows in groups.items():
                merged_rows.append(merge_remittance_group(rows))
            claim_count = len(merged_rows)
            total_paid = 0.0
            total_allowed = 0.0
            total_patient_resp = 0.0
            for record in merged_rows:
                try:
                    total_paid += float(str(record.get('paid', '0') or '0').replace(',', ''))
                except (ValueError, TypeError, AttributeError):
                    pass
                try:
                    total_allowed += float(str(record.get('allowed', '0') or '0').replace(',', ''))
                except (ValueError, TypeError, AttributeError):
                    pass
                try:
                    total_patient_resp += float(str(record.get('patient_resp', '0') or '0').replace(',', ''))
                except (ValueError, TypeError, AttributeError):
                    pass
            print("  Merged claim groups: {}".format(claim_count))
            print("  Total paid (merged): ${:.2f}".format(total_paid))
            print("  Total allowed (merged): ${:.2f}".format(total_allowed))
            print("  Total patient responsibility (merged): ${:.2f}".format(total_patient_resp))
        except Exception as e:
            print("  Error summarizing parsed remittances: {}".format(e))
    elif os.path.exists(os.path.join(local_storage, 'posting_queue.jsonl')):
        print("  (Legacy) posting_queue.jsonl present; export uses remittance_parsed.jsonl only.")
        print("  Parsed file missing or merge helpers unavailable; sync to refresh remittance_parsed.jsonl.")
    else:
        print("  No remittance_parsed.jsonl yet. Run 'Sync now' to populate.")

    print("\nParsed Remittances:")
    if os.path.exists(parsed_path):
        try:
            record_count = 0
            payer_counts = {}
            with open(parsed_path, 'r') as f:
                for line in f:
                    if line.strip():
                        record_count += 1
                        try:
                            record = json.loads(line)
                            payer = record.get('payer_name', 'unknown')
                            payer_counts[payer] = payer_counts.get(payer, 0) + 1
                        except Exception:
                            pass
            print("  Total records: {}".format(record_count))
            if payer_counts:
                print("  By payer:")
                for payer, count in sorted(payer_counts.items(), key=lambda x: x[1], reverse=True)[:5]:
                    print("    {}: {}".format(payer, count))
        except Exception as e:
            print("  Error reading parsed remittances: {}".format(e))
    else:
        print("  No parsed remittances found. Run 'Sync now' to populate.")

    print("\n" + "="*60)
    prompt_press_enter_to_continue()

def view_remittance_details(config):
    """
    View detailed remittance data with per-file/claim drill-down.
    ASCII-only, XP/Python 3.4 compatible.
    """
    medi = extract_medilink_config(config)
    local_storage = medi.get('local_storage_path', '.')
    parsed_path = os.path.join(local_storage, 'remittance_parsed.jsonl')

    display_section_header("Remittance Details")

    if not os.path.exists(parsed_path):
        print("\nNo parsed remittance data found.")
        print("Run 'Sync now' to download and parse remittances.")
        prompt_press_enter_to_continue()
        return

    try:
        records = []
        with open(parsed_path, 'r') as f:
            for line in f:
                if line.strip():
                    try:
                        records.append(json.loads(line))
                    except Exception:
                        pass

        if not records:
            print("\nNo valid records found in parsed remittances.")
            prompt_press_enter_to_continue()
            return

        print("\nFound {} parsed remittance record(s).".format(len(records)))
        print("\nShowing first 10 records:")
        print("-" * 60)

        for i, record in enumerate(records[:10]):
            print("\nRecord {}:".format(i + 1))
            print("  Payer: {}".format(record.get('payer_name', 'N/A')))
            print("  Claim #: {}".format(record.get('claim_number', 'N/A')))
            print("  Patient: {}".format(record.get('patient_name', 'N/A')))
            print("  DOS: {}".format(record.get('dos', 'N/A')))
            print("  Status: {}".format(record.get('status', 'N/A')))
            print("  Paid: ${}".format(record.get('paid', '0.00')))
            print("  Allowed: ${}".format(record.get('allowed', '0.00')))
            print("  Patient Resp: ${}".format(record.get('patient_resp', '0.00')))

        if len(records) > 10:
            print("\n... and {} more record(s)".format(len(records) - 10))

        print("\n" + "="*60)

    except Exception as e:
        print("\nError reading remittance details: {}".format(e))

    prompt_press_enter_to_continue()

def export_remittance_data(config):
    """
    Export remittance data to CSV format (Option A: remittance_parsed.jsonl only, merged groups).
    ASCII-only, XP/Python 3.4 compatible.
    """
    medi = extract_medilink_config(config)
    local_storage = medi.get('local_storage_path', '.')
    parsed_path = os.path.join(local_storage, 'remittance_parsed.jsonl')

    display_section_header("Export Remittance Data")

    if not os.path.exists(parsed_path):
        print("\nNo remittance_parsed.jsonl found.")
        print("Run 'Sync now' or Claims Inquiry to populate canonical remittance rows first.")
        prompt_press_enter_to_continue()
        return

    if not (group_records_for_merge and merge_remittance_group and canonical_to_posting_row):
        print("\nExport helpers unavailable (MediLink_RemittancePipeline import failed).")
        prompt_press_enter_to_continue()
        return

    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        export_path = os.path.join(local_storage, "remittance_export_{}.csv".format(timestamp))

        records = []
        with open(parsed_path, 'r') as f:
            for line in f:
                if line.strip():
                    try:
                        records.append(json.loads(line))
                    except Exception:
                        pass

        if not records:
            print("\nNo records to export.")
            prompt_press_enter_to_continue()
            return

        groups = group_records_for_merge(records)
        posting_rows = []
        for _gk, rows in groups.items():
            merged = merge_remittance_group(rows)
            posting_rows.append(canonical_to_posting_row(merged))

        with open(export_path, 'w') as csvfile:
            fieldnames = ['patid', 'dos', 'payer_id', 'paid', 'allowed', 'patient_resp', 'status', 'source_claim_number']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames, lineterminator='\n')
            writer.writeheader()
            for record in posting_rows:
                writer.writerow({
                    'patid': record.get('patid', ''),
                    'dos': record.get('dos', ''),
                    'payer_id': record.get('payer_id', ''),
                    'paid': record.get('paid', '0.00'),
                    'allowed': record.get('allowed', '0.00'),
                    'patient_resp': record.get('patient_resp', '0.00'),
                    'status': record.get('status', ''),
                    'source_claim_number': record.get('source_claim_number', '')
                })

        print("\nExported {} merged row(s) (from {} JSONL line(s)) to:".format(len(posting_rows), len(records)))
        print("  {}".format(export_path))

    except Exception as e:
        print("\nError exporting remittance data: {}".format(e))

    prompt_press_enter_to_continue()

def tools_menu(config, medi):
    """Low-use maintenance tools submenu."""
    while True:
        display_section_header("Maintenance Tools")
        options = [
            "Rebuild submission index now",
            "Submit Error Report (email)",
            "Resolve Queued Error Reports",
            "Export Humana/Aetna list (by month, printable TXT)",
            "Export NACOR XML",
        ]
        display_menu(options, zero_option='Back')
        choice = get_user_choice().strip()
        if choice == '0':
            break
        if choice == '1':
            receipts_root = medi.get('local_claims_path', None)
            if not receipts_root:
                print("No receipts folder configured (local_claims_path missing).")
                continue
            try:
                from MediCafe.submission_index import build_initial_index
                receipts_root = os.path.normpath(receipts_root)
                print("Rebuilding submission index... (this may take a while)")
                count = build_initial_index(receipts_root)
                print("Index rebuild complete. Indexed {} records.".format(count))
            except Exception as e:
                print("Index rebuild error: {}".format(e))
        elif choice == '2':
            if collect_support_bundle is None or submit_support_bundle_email is None:
                print("Error reporting module not available.")
                continue
            try:
                print("\nSubmitting Error Report (email)...")
                zip_path = collect_support_bundle(include_traceback=True)
                if not zip_path:
                    print("Failed to create support bundle.")
                else:
                    ok = submit_support_bundle_email(zip_path)
                    if ok:
                        try:
                            os.remove(zip_path)
                        except Exception:
                            pass
                        print("Error report sent successfully. You do not need to send another report.")
                        prompt_press_enter_to_continue()
                    else:
                        print("Submission failed. Bundle saved at {} for manual handling.".format(zip_path))
            except Exception as e:
                print("Error during email report submission: {}".format(e))
        elif choice == '3':
            if resolve_queued_bundles_flow is None:
                print("Error reporting module not available.")
                continue
            try:
                resolve_queued_bundles_flow()
            except Exception as e:
                print("Error while processing queued bundles: {}".format(e))
        elif choice == '4':
            try:
                from MediLink.MediLink_Humana_Aetna_Export import run_humana_aetna_export
                display_section_header("Humana/Aetna Patient List Export")
                result = run_humana_aetna_export(config)
                if result.get('success'):
                    print("\nExport completed successfully!")
                    print("Total patients: {}".format(result.get('total_patients', 0)))
                    print("Months: {}".format(result.get('months', 0)))
                else:
                    print("\nExport completed with errors. See details above.")
                prompt_press_enter_to_continue()
            except ImportError as e:
                print("Error: Humana/Aetna export module not available: {}".format(e))
            except Exception as e:
                print("Error during Humana/Aetna export: {}".format(e))
                import traceback
                traceback.print_exc()
        elif choice == '5':
            try:
                from MediLink.MediLink_NACOR_Export import run_nacor_export
                display_section_header("NACOR XML Export")
                result = run_nacor_export(config)
                if result.get('success'):
                    print("\nExport completed successfully!")
                else:
                    print("\nExport completed with errors. See summary above.")
                prompt_press_enter_to_continue()
            except ImportError as e:
                print("Error: NACOR export module not available: {}".format(e))
            except Exception as e:
                print("Error during NACOR export: {}".format(e))
                import traceback
                traceback.print_exc()
        else:
            display_invalid_choice()

def display_patient_options(detailed_patient_data):
    """
    Displays a list of patients with their current suggested endpoints, prompting for selections to adjust.
    """
    print("\nPlease select the patients to adjust by entering their numbers separated by commas\n(e.g., 1,3,5):")
    # Can disable this extra print for now because the px list would already be on-screen.
    #for i, data in enumerate(detailed_patient_data, start=1):
    #    patient_info = "{0} ({1}) - {2}".format(data['patient_name'], data['patient_id'], data['surgery_date'])
    #    endpoint = data.get('suggested_endpoint', 'N/A')
    #    print("{:<3}. {:<30} Current Endpoint: {}".format(i, patient_info, endpoint))

def get_selected_indices(patient_count):
    """
    Collects user input for selected indices to adjust endpoints.
    
    Args:
        patient_count: Total number of patients available for selection
    
    Returns:
        List of valid zero-based indices selected by the user
    """
    selected_indices_input = input("> ")
    if not selected_indices_input.strip():
        return []
    return _parse_selection_input(selected_indices_input, patient_count)


def _parse_selection_input(raw_input, max_count):
    """
    Parse a selection string like "1,3,6-7" into zero-based indices.
    Returns a list of valid indices; prints warning for invalid entries.
    """
    if not raw_input:
        return []
    raw_input = raw_input.strip()
    if not raw_input:
        return []
    command = raw_input.lower()
    if command == 'all':
        return list(range(max_count))
    if command == 'none':
        return []

    selected_indices = []
    invalid_entries = []
    for part in raw_input.split(','):
        part = part.strip()
        if not part:
            continue
        if '-' in part:
            bounds = part.split('-', 1)
            if len(bounds) != 2:
                invalid_entries.append(part)
                continue
            start_str, end_str = bounds[0].strip(), bounds[1].strip()
            if start_str.isdigit() and end_str.isdigit():
                start_idx = int(start_str) - 1
                end_idx = int(end_str) - 1
                if start_idx > end_idx:
                    start_idx, end_idx = end_idx, start_idx
                for idx in range(start_idx, end_idx + 1):
                    if 0 <= idx < max_count:
                        selected_indices.append(idx)
                    else:
                        invalid_entries.append(part)
                        break
            else:
                invalid_entries.append(part)
        elif part.isdigit():
            idx = int(part) - 1
            if 0 <= idx < max_count:
                selected_indices.append(idx)
            else:
                invalid_entries.append(part)
        else:
            invalid_entries.append(part)
    # De-duplicate while preserving order
    seen = set()
    deduped = []
    for idx in selected_indices:
        if idx not in seen:
            seen.add(idx)
            deduped.append(idx)
    if invalid_entries:
        print("Warning: Invalid entries ignored: {}".format(", ".join(sorted(set(invalid_entries)))))
    return deduped


def _display_patient_selection_list(detailed_patient_data):
    """
    Display a simple list of patients in current order for manual selection.
    """
    print("\nSelect patients to submit (examples: 1,3,6-7, all, none).")
    print("{:<3} {:<8} {:<20} {:<12} {:<10}".format("No.", "ID", "Name", "DOS", "Endpoint"))
    print("-" * 60)
    for i, data in enumerate(detailed_patient_data, start=1):
        patient_id = data.get('patient_id', '') or data.get('patid', '')
        patient_name = (data.get('patient_name', '') or '')[:20]
        dos = data.get('surgery_date', '') or ''
        endpoint = data.get('confirmed_endpoint') or data.get('suggested_endpoint', '')
        print("{:<3} {:<8} {:<20} {:<12} {:<10}".format(i, patient_id, patient_name, dos, endpoint))


def _print_retry_policy_summary(total_count, retained_count, policy_label):
    excluded_count = max(0, int(total_count) - int(retained_count))
    print("\nRetry filter summary")
    print("-" * 40)
    print("  Total from selected file(s): {}".format(total_count))
    print("  Retained after retry policy: {}".format(retained_count))
    print("  Excluded by retry policy: {}".format(excluded_count))
    print("  Policy mode: {}".format(policy_label))
    print("-" * 40)


def _get_retry_last_choice(config):
    medi_cfg = config.get('MediLink_Config', {}) if isinstance(config, dict) else {}
    remember = bool(medi_cfg.get('retry_policy_remember_last_choice', False))
    last_choice = str(medi_cfg.get('retry_policy_last_choice', '') or '').strip()
    # Legacy: 5 was "Cancel submission" before cancel moved to 0
    if last_choice == '5':
        last_choice = '0'
    if not remember or last_choice not in ['0', '1', '2', '3', '4']:
        return '1'
    return last_choice


def _set_retry_last_choice(config, choice):
    try:
        medi_cfg = config.get('MediLink_Config', {}) if isinstance(config, dict) else {}
        if bool(medi_cfg.get('retry_policy_remember_last_choice', False)):
            medi_cfg['retry_policy_last_choice'] = str(choice)
    except Exception:
        pass


def backfill_missing_claim_keys(detailed_patient_data):
    """
    Set claim_key on patient dicts when absent, using the same compute_claim_key
    shape as MediLink_PatientProcessor (payer_id blank at parse time).
    Enables retry-policy ledger matching when upstream omitted the key.
    """
    if not detailed_patient_data:
        return
    try:
        from MediCafe.submission_index import compute_claim_key
    except Exception:
        return
    for d in detailed_patient_data:
        if not isinstance(d, dict):
            continue
        if d.get('claim_key'):
            continue
        try:
            pid = str(d.get('patient_id', '') or '').strip()
            ins = str(d.get('primary_insurance', '') or '').strip()
            dos = str(d.get('surgery_date_iso', d.get('surgery_date', '')) or '').strip()
            proc = str(d.get('primary_procedure_code', '') or '').strip()
            key = compute_claim_key(pid, '', ins, dos, proc)
            if any([pid, ins, dos, proc]):
                d['claim_key'] = key
        except Exception:
            pass


def apply_retry_policy(detailed_patient_data, config):
    """
    Apply custody-aware retry policy using submission attempts ledger.
    Returns:
      - filtered list if policy selected
      - original list if no prior attempts or user chooses submit-all
      - None if user cancels
    """
    try:
        from MediCafe import submission_attempts
    except Exception:
        return detailed_patient_data

    backfill_missing_claim_keys(detailed_patient_data)

    # Build claim key list for lookup
    claim_keys = [d.get('claim_key', '') for d in detailed_patient_data if d.get('claim_key')]
    if not claim_keys:
        return detailed_patient_data

    attempts = submission_attempts.load_attempts(config)
    if not attempts:
        return detailed_patient_data

    summary, latest = submission_attempts.summarize_attempts_for_claims(claim_keys, attempts)
    if summary.get("attempted", 0) <= 0:
        return detailed_patient_data

    print("\nPrior submission attempts detected for current patients:")
    print("  In-custody failures: {}".format(summary.get("in_custody", 0)))
    print("  Returned (rejected 277/999): {}".format(summary.get("returned_to_custody", 0)))
    print("  Out-of-custody (submitted/pending): {}".format(summary.get("out_of_custody", 0)))
    print("  No prior attempt: {}".format(summary.get("no_attempt", 0)))

    default_choice = _get_retry_last_choice(config)

    default_hint = " (default)" if default_choice == "1" else ""
    print("\nRetry policy options:")
    print("  0) Cancel submission")
    print("  1) Retry safe failures only{}".format(default_hint))
    print("  2) Retry safe failures + rejected (277/999)")
    print("  3) Manual select patients")
    print("  4) Submit all (ignore prior attempts)")
    choice = input("Select option [{}]: ".format(default_choice)).strip()
    if not choice:
        choice = default_choice
    if choice in ['0', '1', '2', '3', '4']:
        _set_retry_last_choice(config, choice)

    if choice == "0":
        return None
    if choice == "1":
        filtered = submission_attempts.filter_candidates(detailed_patient_data, latest, include_rejected=False)
        _print_retry_policy_summary(len(detailed_patient_data), len(filtered), "safe failures only")
        return filtered
    if choice == "2":
        filtered = submission_attempts.filter_candidates(detailed_patient_data, latest, include_rejected=True)
        _print_retry_policy_summary(len(detailed_patient_data), len(filtered), "safe failures + rejected")
        return filtered
    if choice == "3":
        _display_patient_selection_list(detailed_patient_data)
        selected = input("> ").strip().lower()
        if not selected:
            print("No selection made. Proceeding with safe failures only.")
            filtered = submission_attempts.filter_candidates(detailed_patient_data, latest, include_rejected=False)
            _print_retry_policy_summary(len(detailed_patient_data), len(filtered), "safe failures only")
            return filtered
        indices = _parse_selection_input(selected, len(detailed_patient_data))
        retained_count = len(indices)
        print("Manual selection retained {} patient(s).".format(retained_count))
        confirm_manual = input("Proceed with this selection? (Y/n): ").strip().lower()
        if confirm_manual not in ['', 'y', 'yes']:
            print("Manual selection cancelled. Proceeding with safe failures only.")
            filtered = submission_attempts.filter_candidates(detailed_patient_data, latest, include_rejected=False)
            _print_retry_policy_summary(len(detailed_patient_data), len(filtered), "safe failures only")
            return filtered
        filtered = [detailed_patient_data[i] for i in indices]
        _print_retry_policy_summary(len(detailed_patient_data), len(filtered), "manual selection")
        return filtered
    if choice == "4":
        _print_retry_policy_summary(len(detailed_patient_data), len(detailed_patient_data), "submit all")
        return detailed_patient_data
    print("Invalid selection. Proceeding with safe failures only.")
    filtered = submission_attempts.filter_candidates(detailed_patient_data, latest, include_rejected=False)
    _print_retry_policy_summary(len(detailed_patient_data), len(filtered), "safe failures only")
    return filtered

def display_patient_for_adjustment(patient_name, suggested_endpoint):
    """
    Displays the current endpoint for a selected patient and prompts for a change.
    """
    print("\n- {0} | Current Endpoint: {1}".format(patient_name, suggested_endpoint))

def get_endpoint_decision():
    """
    Asks the user if they want to change the endpoint.
    Ensures a valid entry of 'Y' or 'N'.
    """
    while True:
        decision = input("Change endpoint? (Y/N): ").strip().lower()
        if decision in ['y', 'n']:
            return decision
        else:
            print("Invalid input. Please enter 'Y' for Yes or 'N' for No.")

def display_endpoint_options(endpoints_config):
    """
    Displays the endpoint options to the user based on the provided mapping.

    Args:
        endpoints_config (dict): A dictionary mapping endpoint keys to their properties, 
                                 where each property includes a 'name' key for the user-friendly name.
                                 Example: {'Availity': {'name': 'Availity'}, 'OptumEDI': {'name': 'OptumEDI'}, ...}

    Returns:
        None
    """
    print("Select the new endpoint for the patient:")
    for index, (key, details) in enumerate(endpoints_config.items(), 1):
        # Safely get the name, fallback to key if 'name' is missing
        endpoint_name = details.get('name', key) if isinstance(details, dict) else key
        print("{0}. {1}".format(index, endpoint_name))

def get_new_endpoint_choice():
    """
    Gets the user's choice for a new endpoint.
    Single selection only.
    """
    while True:
        choice = input("Select desired endpoint (e.g. 1): ").strip()
        corrected_choice = choice.replace(' ', '')
        if corrected_choice.isdigit():
            return int(corrected_choice)
        else:
            print("Invalid input. Please enter a single number corresponding to the endpoint.")

# Display functions moved to MediLink_Display_Utils.py to eliminate circular dependencies

def extract_patient_last_names(file_path, config, max_names=5):
    """
    Extracts up to max_names unique patient last names from a Z file.
    
    Args:
        file_path: Path to the Z file
        config: Configuration dictionary needed for parsing fixed-width data
        max_names: Maximum number of last names to return (default: 5)
    
    Returns:
        A comma-separated string of last names, or empty string if extraction fails
    """
    # Check if file exists before attempting to read
    if not os.path.exists(file_path):
        return ""
    
    last_names = []
    seen_names = set()
    
    try:
        # Read and parse the fixed-width Z file
        for record_index, record in enumerate(MediLink_DataMgmt.read_fixed_width_data(file_path), start=1):
            if not isinstance(record, tuple) or len(record) != 5:
                try:
                    MediLink_ConfigLoader.log(
                        "extract_patient_last_names: skipping record {} (expected 5-tuple Medisoft row)".format(record_index),
                        level="WARNING",
                    )
                except Exception:
                    pass
                continue
            personal_info, insurance_info, service_info, service_info_2, service_info_3 = record
            try:
                # Parse the fixed-width data to extract patient information
                parsed_data = MediLink_DataMgmt.parse_fixed_width_data(
                    personal_info, insurance_info, service_info,
                    service_info_2, service_info_3, config
                )
                
                # Extract last name from parsed data
                last_name = parsed_data.get('LAST', '').strip()
                
                # Add to list if it's a valid, unique name and we haven't reached the limit
                if last_name and last_name not in seen_names and len(last_names) < max_names:
                    last_names.append(last_name)
                    seen_names.add(last_name)
                    
                    # Early exit if we've collected enough names
                    if len(last_names) >= max_names:
                        break
            except Exception:
                # Skip this record if parsing fails, continue with next
                continue
    except Exception:
        # If file reading fails, return empty string (will be handled gracefully in display)
        return ""
    
    # Return comma-separated list of last names
    return ", ".join(last_names) if last_names else ""

def user_select_files(file_list):
    # Handle empty file list
    if not file_list:
        print("\nNo files available to select.")
        return []
    
    # Load configuration for parsing Z files
    try:
        config, _ = MediLink_ConfigLoader.load_configuration()
    except Exception:
        config = None
    
    # Sort files by creation time in descending order
    file_list = sorted(file_list, key=os.path.getctime, reverse=True)[:10]  # Limit to max 10 files
    
    print("\nSelect the Z-form files to submit from the following list:\n")

    if file_list and config:
        MediLink_ConfigLoader.log("Reading {} fixed-width file(s) for display.".format(len(file_list)), config=config, level="INFO")
    formatted_files = []
    for i, file in enumerate(file_list):
        basename = os.path.basename(file)
        parts = basename.split('_')
        
        # Try to parse the timestamp from the filename
        if len(parts) > 2:
            try:
                timestamp_str = parts[1] + parts[2].split('.')[0]
                timestamp = datetime.strptime(timestamp_str, '%Y%m%d%H%M%S')
                formatted_date = timestamp.strftime('%m/%d %I:%M %p')  # Changed to 12HR format with AM/PM
            except ValueError:
                formatted_date = basename  # Fallback to original filename if parsing fails
        else:
            formatted_date = basename  # Fallback to original filename if no timestamp
        
        # Extract patient last names preview from the Z file
        patient_preview = ""
        if config:
            try:
                last_names_str = extract_patient_last_names(file, config, max_names=5)
                if last_names_str:
                    patient_preview = " - Patients: {}".format(last_names_str)
            except Exception:
                # Silently fail if extraction fails - just show date without preview
                pass
        
        formatted_files.append((formatted_date, file))
        # Display date with patient preview on the same line
        print("{}: {}{}".format(i + 1, formatted_date, patient_preview))
    if file_list and config:
        MediLink_ConfigLoader.log("Successfully read {} fixed-width file(s).".format(len(file_list)), config=config, level="INFO")
    
    selected_indices = input("\nEnter the numbers of the files to process, separated by commas\n(or press Enter to select all): ")
    if not selected_indices:
        return [file for _, file in formatted_files]
    
    # Parse and validate selected indices
    try:
        selected_indices = [int(i.strip()) - 1 for i in selected_indices.split(',')]
        # Validate indices are within range
        valid_indices = [idx for idx in selected_indices if 0 <= idx < len(formatted_files)]
        if not valid_indices:
            print("No valid file selections. Please enter numbers between 1 and {}.".format(len(formatted_files)))
            return []
        if len(valid_indices) < len(selected_indices):
            invalid_count = len(selected_indices) - len(valid_indices)
            print("Warning: {} invalid selection(s) were ignored.".format(invalid_count))
        selected_files = [formatted_files[i][1] for i in valid_indices]
        return selected_files
    except ValueError:
        print("Invalid input. Please enter numbers separated by commas (e.g., 1,3,5).")
        return []


def user_decision_on_suggestions(detailed_patient_data, config, insurance_edited, crosswalk):
    """
    Presents the user with all patient summaries and suggested endpoints,
    then asks for confirmation to proceed with all or specify adjustments manually.
    
    FIXED: Display now properly shows effective endpoints (user preferences over original suggestions)
    """
    if insurance_edited:
        # Display summaries only if insurance types were edited
        MediLink_Display_Utils.display_patient_summaries(detailed_patient_data, config)

    while True:
        proceed_input = input("Do you want to proceed with all suggested endpoints? (Y/N): ").strip().lower()
        if proceed_input in ['y', 'yes']:
            proceed = True
            break
        elif proceed_input in ['n', 'no']:
            proceed = False
            break
        else:
            print("Invalid input. Please enter 'Y' for yes or 'N' for no.")

    # If the user agrees to proceed with all suggested endpoints, confirm them.
    if proceed:
        return MediLink_DataMgmt.confirm_all_suggested_endpoints(detailed_patient_data), crosswalk
    # Otherwise, allow the user to adjust the endpoints manually.
    else:
        return select_and_adjust_files(detailed_patient_data, config, crosswalk)
   

def select_and_adjust_files(detailed_patient_data, config, crosswalk):
    """
    Allows users to select patients and adjust their endpoints by interfacing with UI functions.
    
    FIXED: Now properly updates suggested_endpoint and persists user preferences to crosswalk.
    """
    # Display options for patients
    display_patient_options(detailed_patient_data)

    # Get user-selected indices for adjustment
    selected_indices = get_selected_indices(len(detailed_patient_data))
    
    # Get an ordered list of endpoint keys
    medi = extract_medilink_config(config)
    endpoint_keys = list(medi.get('endpoints', {}).keys())
    
    # Iterate over each selected index and process endpoint changes
    for i in selected_indices:
        data = detailed_patient_data[i]
        current_effective_endpoint = MediLink_PatientProcessor.get_effective_endpoint(data)
        display_patient_for_adjustment(data['patient_name'], current_effective_endpoint)
        
        endpoint_change = get_endpoint_decision()
        if endpoint_change == 'y':
            display_endpoint_options(medi.get('endpoints', {}))
            endpoint_index = get_new_endpoint_choice() - 1  # Adjusting for zero-based index
            
            if 0 <= endpoint_index < len(endpoint_keys):
                selected_endpoint_key = endpoint_keys[endpoint_index]
                print("Endpoint changed to {0} for patient {1}.".format(medi.get('endpoints', {}).get(selected_endpoint_key, {}).get('name', selected_endpoint_key), data['patient_name']))
                
                # Use the new endpoint management system
                updated_crosswalk = MediLink_DataMgmt.update_suggested_endpoint_with_user_preference(
                    detailed_patient_data, i, selected_endpoint_key, config, crosswalk
                )
                if updated_crosswalk:
                    crosswalk = updated_crosswalk
                # STRATEGIC NOTE (Medicare Crossover UI): High-risk implementation requiring strategic decisions
                # 
                # CRITICAL QUESTIONS FOR IMPLEMENTATION:
                # 1. **Crossover Detection**: How to detect Medicare crossover failures?
                #    - Automatic from claim status API responses?
                #    - Manual user indication?
                #    - Time-based detection (no crossover after X days)?
                # 
                # 2. **Secondary Claim Workflow**: How should secondary claim creation be integrated?
                #    - Automatic prompt when crossover failure detected?
                #    - Manual option in patient management interface?
                #    - Batch processing for multiple failed crossovers?
                # 
                # 3. **Data Requirements**: What data is needed for secondary claims?
                #    - Medicare payment amount (required vs optional)?
                #    - Denial/adjustment reasons from Medicare?
                #    - Secondary payer eligibility verification?
                #
                # To implement: Add crossover failure detection and secondary claim creation UI
                # with proper validation and error handling for Medicare -> Secondary workflow
            else:
                print("Invalid selection. Keeping the current endpoint.")
                data['confirmed_endpoint'] = current_effective_endpoint
        else:
            data['confirmed_endpoint'] = current_effective_endpoint

    return detailed_patient_data, crosswalk
