"""
One-time or operator-triggered backfill for remittance_parsed.jsonl.

Re-reads each JSON object, applies best-effort source-fact touch-up (DOS normalize,
sparse claims_inquiry keys), re-applies resolve_remittance_dict against the current
submission crosswalk (local_claims_path), sets schema_version from MediLink_RemittancePipeline.

Does not re-parse source files; full recovery of file-derived fields requires re-decode
from source_file/checksum (out of scope for this utility).

Usage (from repo root, XP / Python 3.4+):
  python -m MediCafe.remittance_backfill --storage PATH [--receipts PATH] [--dry-run]

Backup remittance_parsed.jsonl before running in production.
"""
from __future__ import print_function
import argparse
import json
import os
import shutil
import sys
import time


def _load_jsonl(path):
    rows = []
    if not os.path.exists(path):
        return rows
    with open(path, 'r') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                if isinstance(obj, dict):
                    rows.append(obj)
            except (ValueError, TypeError):
                continue
    return rows


def _ensure_medilink_on_path():
    pkg_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    medilink_dir = os.path.join(pkg_root, 'MediLink')
    if os.path.isdir(medilink_dir) and medilink_dir not in sys.path:
        sys.path.insert(0, medilink_dir)


def _backfill_source_facts(rec):
    """Normalize DOS where possible; ensure claims_inquiry rows have explicit API contract keys."""
    if not isinstance(rec, dict):
        return
    try:
        from MediCafe.reconciliation import normalize_dos
    except ImportError:
        normalize_dos = None
    if normalize_dos:
        d = rec.get('dos', '')
        if d:
            nd = normalize_dos(d)
            if nd:
                rec['dos'] = nd
    ds = str(rec.get('data_source', '') or '').lower()
    if ds == 'claims_inquiry':
        rec['processed_date'] = _safe_str(rec.get('processed_date', ''))
        rec['lookup_mode'] = _safe_str(rec.get('lookup_mode', ''))
        if 'claim_xwalk_data' not in rec:
            rec['claim_xwalk_data'] = None
        if 'document_refs' not in rec:
            rec['document_refs'] = None


def _safe_str(value):
    if value is None:
        return ''
    return str(value)


def run_backfill(storage_path, receipts_root, dry_run=False):
    _ensure_medilink_on_path()
    try:
        from MediLink_RemittancePipeline import (
            SCHEMA_VERSION,
            build_crosswalk_lookups,
            resolve_remittance_dict,
        )
    except ImportError:
        print("ERROR: MediLink_RemittancePipeline not importable.", file=sys.stderr)
        return 1

    parsed_path = os.path.join(storage_path, 'remittance_parsed.jsonl')
    if not os.path.exists(parsed_path):
        print("No file at {}".format(parsed_path))
        return 0

    records = _load_jsonl(parsed_path)
    if not records:
        print("No records to backfill.")
        return 0

    lookups = build_crosswalk_lookups(receipts_root) if receipts_root else {
        'by_submitted_claim_number': {},
        'by_claim_key': {},
    }

    out_lines = []
    for rec in records:
        _backfill_source_facts(rec)
        resolve_remittance_dict(rec, lookups)
        rec['schema_version'] = SCHEMA_VERSION
        out_lines.append(json.dumps(rec, ensure_ascii=True))

    if dry_run:
        print("Dry-run: would rewrite {} line(s)".format(len(out_lines)))
        return 0

    backup = parsed_path + '.bak.' + str(int(time.time()))
    try:
        shutil.copy2(parsed_path, backup)
    except (OSError, IOError) as e:
        print("ERROR: could not backup to {}: {}".format(backup, e), file=sys.stderr)
        return 1

    new_path = parsed_path + '.new'
    try:
        with open(new_path, 'w') as f:
            for line in out_lines:
                f.write(line + '\n')
        os.replace(new_path, parsed_path)
    except (OSError, IOError) as e:
        print("ERROR: write failed: {}".format(e), file=sys.stderr)
        try:
            if os.path.exists(new_path):
                os.remove(new_path)
        except Exception:
            pass
        return 1

    print("Backfilled {} row(s); backup: {}".format(len(out_lines), backup))
    return 0


def main(argv=None):
    p = argparse.ArgumentParser(description='Backfill remittance_parsed.jsonl resolution fields')
    p.add_argument('--storage', required=True, help='MediLink local_storage_path directory')
    p.add_argument('--receipts', default='', help='local_claims_path (submission index); optional')
    p.add_argument('--dry-run', action='store_true', help='Do not write files')
    args = p.parse_args(argv)
    receipts = args.receipts or None
    return run_backfill(args.storage, receipts, dry_run=args.dry_run)


if __name__ == '__main__':
    sys.exit(main() or 0)
