﻿# Repository Tools

This folder contains auxiliary helper scripts that support cloud setup, auth checks, build validation, updater work, and focused experiments. These scripts are not the primary runtime path for MediCafe itself.

The canonical operator path for the cloud runtime remains:

```powershell
py -3.11 cloud/orchestrator/validate_and_complete_setup.py
```

## Current Tool Groups

### Auth and Gmail/GCP helpers

- `gmail_watch_bootstrap.py`
- `adc_check.py`
- `adc_file_check.py`
- `get_gmail_oauth_token.ps1`
- `verify_keyless_dwd.ps1`

### Build and updater helpers

- `copy_update_script.py`
- `prebuild_validation.py`
- `postbuild_validation.py`
- `verify_updater_fixes.py`
- `build_colors.py`

### Focused migration or one-off support scripts

- `replace_medilink_api_v3.py`
- `demo_humana_aetna_table.py`

### Local tool dependencies

- `requirements.txt`

## Usage Guidance

- Prefer the package CLI and `cloud/orchestrator/` validator flow for normal operations.
- Use scripts in this folder when you specifically need helper behavior that is not part of the packaged runtime.
- Prune or archive obsolete helpers instead of letting this folder become a second unofficial runtime surface.
