# tests/test_remittance_pipeline.py
"""Remittance merge/resolution helpers (Python 3.4+)."""
import os
import sys
import unittest

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
medilink_dir = os.path.join(parent_dir, 'MediLink')
if medilink_dir not in sys.path:
    sys.path.insert(0, medilink_dir)

from MediLink_RemittancePipeline import (  # noqa: E402
    merge_remittance_group,
    group_records_for_merge,
    canonical_to_posting_row,
    resolve_remittance_dict,
    build_crosswalk_lookups,
)


class TestMergeRemittanceGroup(unittest.TestCase):
    def test_single_row_has_merge_count(self):
        r = {'claim_number': '1', 'dos': '20250101', 'paid': '10', 'data_source': 'claims_inquiry'}
        m = merge_remittance_group([r])
        self.assertEqual(m.get('merge_source_count'), 1)
        self.assertTrue(m.get('merge_consistent'))

    def test_money_conflict_flag(self):
        rows = [
            {'paid': '10', 'allowed': '0', 'patient_resp': '0', 'status': 'A', 'data_source': 'parsed_file'},
            {'paid': '20', 'allowed': '0', 'patient_resp': '0', 'status': 'A', 'data_source': 'claims_inquiry'},
        ]
        m = merge_remittance_group(rows)
        self.assertTrue(m.get('money_conflict'))
        self.assertFalse(m.get('merge_consistent'))
        self.assertEqual(m.get('merge_source_count'), 2)

    def test_group_records_for_merge(self):
        recs = [
            {'internal_claim_key': 'k1', 'dos': '20250101', 'claim_number': 'x'},
            {'internal_claim_key': 'k1', 'dos': '20250101', 'claim_number': 'y'},
        ]
        g = group_records_for_merge(recs)
        self.assertEqual(len(g), 1)

    def test_merge_file_plus_api_preserves_api_breadcrumbs(self):
        file_row = {
            'claim_number': 'C1',
            'dos': '20250101',
            'paid': '100',
            'data_source': 'parsed_file',
            'processed_date': '',
            'claim_xwalk_data': None,
            'lookup_mode': '',
            'document_refs': None,
        }
        api_row = {
            'claim_number': 'C1',
            'dos': '20250101',
            'paid': '100',
            'data_source': 'claims_inquiry',
            'processed_date': '2025-01-10',
            'claim_xwalk_data': [{'stage': 'x'}],
            'lookup_mode': 'member',
            'document_refs': [{'id': 'd1'}],
        }
        m = merge_remittance_group([file_row, api_row])
        self.assertEqual(m.get('claim_xwalk_data'), [{'stage': 'x'}])
        self.assertEqual(m.get('lookup_mode'), 'member')
        self.assertEqual(m.get('processed_date'), '2025-01-10')
        self.assertEqual(m.get('document_refs'), [{'id': 'd1'}])

    def test_merge_inquiry_processed_date_when_file_has_different_date(self):
        file_row = {
            'claim_number': 'C1',
            'dos': '20250101',
            'paid': '1',
            'data_source': 'parsed_file',
            'processed_date': '20250101',
        }
        api_row = {
            'claim_number': 'C1',
            'dos': '20250101',
            'paid': '1',
            'data_source': 'claims_inquiry',
            'processed_date': '20250115',
        }
        m = merge_remittance_group([file_row, api_row])
        self.assertEqual(m.get('processed_date'), '20250101')
        self.assertEqual(m.get('inquiry_processed_date'), '20250115')
        self.assertTrue(m.get('source_conflict'))


class TestCanonicalToPostingRow(unittest.TestCase):
    def test_patid_from_internal(self):
        row = {
            'merge_source_count': 1,
            'merge_consistent': True,
            'internal_patid': '12345',
            'dos': '20250101',
            'payer_id': 'p',
            'paid': '1',
            'allowed': '2',
            'patient_resp': '3',
            'status': 'ok',
            'claim_number': 'CN',
        }
        out = canonical_to_posting_row(row)
        self.assertEqual(out['patid'], '12345')
        self.assertEqual(out['source_claim_number'], 'CN')

    def test_posting_row_ignores_legacy_patid_without_internal(self):
        row = {
            'merge_source_count': 1,
            'merge_consistent': True,
            'patid': 'LEGACY999',
            'internal_patid': '',
            'dos': '20250101',
            'payer_id': 'p',
            'paid': '0',
            'allowed': '0',
            'patient_resp': '0',
            'status': 'x',
            'claim_number': 'CN',
        }
        out = canonical_to_posting_row(row)
        self.assertEqual(out['patid'], '')


class TestResolveRemittanceDict(unittest.TestCase):
    def test_non_dict_unchanged(self):
        self.assertEqual(resolve_remittance_dict([], {}), [])

    def test_resolve_via_submitted_claim_number(self):
        lookups = {
            'by_submitted_claim_number': {
                'CLM01': {
                    'internal_patid': '99',
                    'internal_chart': 'C',
                    'claim_key': 'k',
                }
            },
            'by_claim_key': {},
        }
        rec = {'claim_number': 'CLM01', 'dos': '20250101'}
        resolve_remittance_dict(rec, lookups)
        self.assertEqual(rec.get('internal_patid'), '99')
        self.assertEqual(rec.get('match_status'), 'matched_exact')


class TestBuildCrosswalkLookups(unittest.TestCase):
    def test_empty_root(self):
        m = build_crosswalk_lookups('')
        self.assertIn('by_claim_key', m)
        self.assertIn('by_submitted_claim_number', m)


if __name__ == '__main__':
    unittest.main()
