# tests/test_remittance_backfill.py
"""
Unit tests for MediCafe.remittance_backfill.
Python 3.4.4 compatible.
"""
from contextlib import redirect_stdout
from io import StringIO
import json
import os
import sys
import tempfile
import unittest

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
medilink_dir = os.path.join(parent_dir, 'MediLink')
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)
if medilink_dir not in sys.path:
    sys.path.insert(0, medilink_dir)

from MediCafe.remittance_backfill import _backfill_source_facts, run_backfill


class TestBackfillSourceFacts(unittest.TestCase):
    def test_claims_inquiry_row_normalizes_dos_and_sets_sparse_keys(self):
        rec = {
            'data_source': 'claims_inquiry',
            'dos': '2025-01-01',
            'processed_date': None,
        }
        _backfill_source_facts(rec)
        self.assertEqual(rec.get('dos'), '20250101')
        self.assertEqual(rec.get('processed_date'), '')
        self.assertEqual(rec.get('lookup_mode'), '')
        self.assertIsNone(rec.get('claim_xwalk_data'))
        self.assertIsNone(rec.get('document_refs'))


class TestRunBackfill(unittest.TestCase):
    def test_dry_run_leaves_jsonl_unchanged(self):
        with tempfile.TemporaryDirectory() as storage:
            parsed_path = os.path.join(storage, 'remittance_parsed.jsonl')
            original_line = json.dumps({
                'claim_number': 'CLM01',
                'data_source': 'claims_inquiry',
                'dos': '2025-01-01',
                'processed_date': None,
            })
            with open(parsed_path, 'w') as f:
                f.write(original_line + '\n')

            with redirect_stdout(StringIO()):
                rc = run_backfill(storage, None, dry_run=True)

            self.assertEqual(rc, 0)
            with open(parsed_path, 'r') as f:
                self.assertEqual(f.read(), original_line + '\n')
            backups = [n for n in os.listdir(storage) if '.bak.' in n]
            self.assertEqual(backups, [])

    def test_rewrite_creates_backup_and_resolves_against_crosswalk(self):
        with tempfile.TemporaryDirectory() as tmp:
            storage = os.path.join(tmp, 'storage')
            receipts = os.path.join(tmp, 'receipts')
            os.makedirs(storage)
            os.makedirs(receipts)

            parsed_path = os.path.join(storage, 'remittance_parsed.jsonl')
            with open(parsed_path, 'w') as f:
                f.write(json.dumps({
                    'claim_number': 'CLM01',
                    'payer_id': '62308',
                    'data_source': 'claims_inquiry',
                    'dos': '2025-01-01',
                    'processed_date': None,
                }) + '\n')

            index_path = os.path.join(receipts, 'submission_index.jsonl')
            with open(index_path, 'w') as f:
                f.write(json.dumps({
                    'record_type': 'submission',
                    'submitted_claim_number': 'CLM01',
                    'claim_key': 'ck1',
                    'internal_patid': '12345',
                    'internal_chart': 'CHART1',
                    'patient_id': 'CHART1',
                    'payer_id': '62308',
                    'dos': '20250101',
                    'status': 'success',
                }) + '\n')

            with redirect_stdout(StringIO()):
                rc = run_backfill(storage, receipts, dry_run=False)

            self.assertEqual(rc, 0)
            with open(parsed_path, 'r') as f:
                rows = [json.loads(line) for line in f if line.strip()]
            self.assertEqual(len(rows), 1)
            row = rows[0]
            self.assertEqual(row.get('schema_version'), 1)
            self.assertEqual(row.get('dos'), '20250101')
            self.assertEqual(row.get('processed_date'), '')
            self.assertEqual(row.get('internal_patid'), '12345')
            self.assertEqual(row.get('internal_chart'), 'CHART1')
            self.assertEqual(row.get('internal_claim_key'), 'ck1')
            self.assertEqual(row.get('match_status'), 'matched_exact')
            self.assertEqual(row.get('match_basis'), 'submitted_claim_number')
            self.assertIsNone(row.get('claim_xwalk_data'))
            self.assertIsNone(row.get('document_refs'))
            self.assertEqual(row.get('lookup_mode'), '')

            backup_names = [n for n in os.listdir(storage) if n.startswith('remittance_parsed.jsonl.bak.')]
            self.assertEqual(len(backup_names), 1)
            self.assertFalse(os.path.exists(parsed_path + '.new'))


if __name__ == '__main__':
    unittest.main()
