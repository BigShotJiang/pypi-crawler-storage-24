import io
import os
import shutil
import sys
import tempfile
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from MediLink import MediLink_DataMgmt as data_mgmt
from MediLink import MediLink_Down as medilink_down


class WinSCPFilemaskTests(unittest.TestCase):

    def test_normalize_filemask_legacy_pipe_list_uses_semicolons(self):
        self.assertEqual(
            data_mgmt.normalize_filemask(['era', '277', '999']),
            '*.era;*.277;*.999'
        )
        self.assertEqual(
            data_mgmt.normalize_filemask('era|277|999'),
            '*.era;*.277;*.999'
        )

    def test_list_downloaded_files_filters_to_actionable_extensions(self):
        temp_root = tempfile.mkdtemp(prefix='mc_remit_dl_')
        try:
            with open(os.path.join(temp_root, 'winscp_download.log'), 'w') as handle:
                handle.write('log only')
            with open(os.path.join(temp_root, 'new.era'), 'w') as handle:
                handle.write('era data')
            with open(os.path.join(temp_root, 'note.docx'), 'w') as handle:
                handle.write('docx data')
            os.makedirs(os.path.join(temp_root, 'responses'))
            with open(os.path.join(temp_root, 'responses', 'old.era'), 'w') as handle:
                handle.write('moved already')

            found = data_mgmt.list_downloaded_files(temp_root, allowed_extensions=set(['.era']))

            self.assertEqual(found, ['new.era'])
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)


class RemittanceConnectivityTests(unittest.TestCase):

    def test_api_connectivity_uses_token_probe_not_remote_directory(self):
        class FakeClient(object):
            def get_access_token(self, endpoint_name, quiet_mode=False):
                self.endpoint_name = endpoint_name
                self.quiet_mode = quiet_mode
                return 'token-123'

        class FakeFactory(object):
            def __init__(self):
                self.client = FakeClient()

            def get_client(self):
                return self.client

        config = {
            'MediLink_Config': {
                'local_storage_path': '.',
                'endpoints': {
                    'OPTUMAI': {
                        'name': 'OptumAI',
                        'submission_method': 'api',
                        'api_url': 'https://example.test/api',
                        'token_url': 'https://example.test/token',
                        'client_id': 'client-id',
                        'client_secret': 'client-secret',
                    }
                }
            }
        }

        with patch.object(medilink_down, 'check_internet_connection', return_value=True):
            with patch.object(medilink_down, 'get_api_client_factory', return_value=FakeFactory()):
                results = medilink_down.test_endpoint_connectivity(config, 'OPTUMAI')

        result = results['OPTUMAI']
        self.assertEqual(result.get('transport'), 'api')
        self.assertEqual(result.get('status'), 'ok')
        self.assertEqual(result.get('reason'), 'token_ok')
        self.assertIn('Access token acquired successfully.', result.get('details', []))
        self.assertNotIn('Missing remote_directory_down', ' '.join(result.get('details', [])))

    def test_check_for_new_remittances_prints_transport_aware_summary(self):
        config = {
            'MediLink_Config': {
                'local_storage_path': '.',
                'endpoints': {
                    'OPTUMAI': {
                        'name': 'OptumAI',
                        'submission_method': 'api',
                        'api_url': 'https://example.test/api',
                        'token_url': 'https://example.test/token',
                        'client_id': 'client-id',
                        'client_secret': 'client-secret',
                    },
                    'AVAILITY': {
                        'name': 'Availity',
                        'submission_method': 'winscp',
                        'session_name': 'AvailitySession',
                        'remote_directory_down': '/ReceiveFiles',
                    },
                }
            }
        }
        probe_calls = []

        def fake_probe(_config, endpoint_key, endpoint_info, live_check=True, internet_ok=None, local_storage_path=None):
            probe_calls.append((endpoint_key, live_check))
            transport = medilink_down._infer_endpoint_transport(endpoint_info)
            if endpoint_key == 'OPTUMAI':
                return {
                    'transport': transport,
                    'status': 'ready',
                    'reason': 'api_ready',
                    'details': ['API transport detected; token probe not requested for this flow.'],
                }
            return {
                'transport': transport,
                'status': 'ok',
                'reason': 'winscp_probe_ok',
                'details': ['Connected to remote directory.'],
            }

        buffer = io.StringIO()
        with patch.object(medilink_down, 'check_internet_connection', return_value=True):
            with patch.object(medilink_down, 'tqdm', side_effect=lambda iterable, **kwargs: iterable):
                with patch.object(medilink_down, '_probe_endpoint_connectivity', side_effect=fake_probe):
                    with patch.object(
                        medilink_down,
                        'process_endpoint',
                        return_value=([], [], {'status': 'no_files', 'reason': 'no_files_downloaded', 'downloaded_files': 0})
                    ):
                        with patch('sys.stdout', new=buffer):
                            result = medilink_down.check_for_new_remittances(config, is_boot_scan=False)

        self.assertFalse(result)
        self.assertIn(('OPTUMAI', False), probe_calls)
        self.assertIn(('AVAILITY', True), probe_calls)

        rendered = buffer.getvalue()
        self.assertIn('API endpoints in this flow:', rendered)
        self.assertIn('OPTUMAI: validated (api_transport_no_file_sync)', rendered)
        self.assertNotIn('remote_directory_down', rendered)


if __name__ == '__main__':
    unittest.main()
