#!/usr/bin/env python
from __future__ import print_function

import csv
import os
import shutil
import sys
import tempfile
import unittest

try:
    from unittest.mock import patch, MagicMock
except ImportError:
    from mock import patch, MagicMock

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


class MediLinkContextualFlowTests(unittest.TestCase):

    def test_build_contextual_deductible_patient_tuples_matches_candidate_csv_rows(self):
        from MediLink import MediLink_main as medilink_main
        temp_root = tempfile.mkdtemp(prefix='mc_deductible_ctx_')
        try:
            csv_path = os.path.join(temp_root, 'patients.csv')
            with open(csv_path, 'w') as handle:
                writer = csv.DictWriter(handle, fieldnames=['Patient ID #2', 'Patient DOB', 'Primary Policy Number', 'Ins1 Payer ID', 'Surgery Date'])
                writer.writeheader()
                writer.writerow({
                    'Patient ID #2': '12345',
                    'Patient DOB': '01/15/1950',
                    'Primary Policy Number': 'MEM001',
                    'Ins1 Payer ID': '87726',
                    'Surgery Date': '03/26/2026',
                })
            prepared_data = [{'patid': '12345', 'surgery_date_iso': '2026-03-26'}]
            config = {'CSV_FILE_PATH': csv_path, 'MediLink_Config': {}}
            patients = medilink_main._build_contextual_deductible_patient_tuples(prepared_data, config)
            self.assertEqual(patients, [('12345', '01/15/1950', 'MEM001', '87726', '2026-03-26')])
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_remittances_menu_claim_status_option_launches_followup(self):
        from MediLink import MediLink_main as medilink_main
        with patch.object(medilink_main.MediLink_UI, 'display_section_header'):
            with patch.object(medilink_main.MediLink_UI, 'display_menu'):
                with patch.object(medilink_main.MediLink_UI, 'get_user_choice', side_effect=['4', '0']):
                    with patch.object(medilink_main, '_launch_claim_status_followup') as launch_mock:
                        medilink_main._remittances_menu({})
        launch_mock.assert_called_once_with()

    def test_prompt_post_submission_claim_status_followup_launches_on_yes(self):
        from MediLink import MediLink_main as medilink_main
        with patch('builtins.input', return_value='y'):
            with patch.object(medilink_main, '_launch_claim_status_followup', return_value=0) as launch_mock:
                rc = medilink_main._prompt_post_submission_claim_status_followup()
        self.assertEqual(rc, 0)
        launch_mock.assert_called_once_with()

    def test_handle_submission_runs_deductible_checkpoint_before_endpoint_review(self):
        from MediLink import MediLink_main as medilink_main
        candidate = {
            'patid': '12345',
            'patient_id': 'CH123',
            'patient_name': 'Test Patient',
            'primary_insurance': 'UNITED',
            'surgery_date': '03-26-26',
            'surgery_date_iso': '2026-03-26',
            'primary_procedure_code': '66984',
        }
        call_order = []
        with patch.object(medilink_main, 'prepare_submission_candidates', return_value=([dict(candidate)], {})):
            with patch.object(medilink_main, '_maybe_offer_contextual_deductible_review', side_effect=lambda prepared, cfg: call_order.append('deductible')):
                with patch('builtins.input', return_value='n'):
                    with patch.object(medilink_main.MediLink_UI, 'user_decision_on_suggestions', side_effect=lambda data, config, insurance_edited, crosswalk: (call_order.append('endpoint') or (data, None))):
                        with patch.object(medilink_main.MediLink_DataMgmt, 'confirm_all_suggested_endpoints', return_value=[dict(candidate)]):
                            with patch.object(medilink_main.MediLink_DataMgmt, 'organize_patient_data_by_endpoint', return_value={'AVAILITY': [dict(candidate)]}):
                                with patch.object(medilink_main.MediLink_Up, 'confirm_transmission', return_value=False):
                                    result = medilink_main.handle_submission([dict(candidate)], {'MediLink_Config': {}}, {})
        self.assertFalse(result)
        self.assertEqual(call_order, ['deductible', 'endpoint'])

    def test_handle_submission_returns_true_when_submit_claims_reports_success(self):
        from MediLink import MediLink_main as medilink_main
        candidate = {
            'patid': '12345',
            'patient_id': 'CH123',
            'patient_name': 'Test Patient',
            'primary_insurance': 'UNITED',
            'surgery_date': '03-26-26',
            'surgery_date_iso': '2026-03-26',
            'primary_procedure_code': '66984',
        }
        with patch.object(medilink_main, 'prepare_submission_candidates', return_value=([dict(candidate)], {})):
            with patch.object(medilink_main, '_maybe_offer_contextual_deductible_review', return_value=False):
                with patch('builtins.input', return_value='n'):
                    with patch.object(medilink_main.MediLink_UI, 'user_decision_on_suggestions', return_value=([dict(candidate)], None)):
                        with patch.object(medilink_main.MediLink_DataMgmt, 'confirm_all_suggested_endpoints', return_value=[dict(candidate)]):
                            with patch.object(medilink_main.MediLink_DataMgmt, 'organize_patient_data_by_endpoint', return_value={'AVAILITY': [dict(candidate)]}):
                                with patch.object(medilink_main.MediLink_Up, 'confirm_transmission', return_value=True):
                                    with patch.object(medilink_main.MediLink_Up, 'check_internet_connection', return_value=True):
                                        with patch.object(medilink_main.MediLink_Up, 'submit_claims', return_value={'AVAILITY': {'claim1': (True, 'ok')}}):
                                            result = medilink_main.handle_submission([dict(candidate)], {'MediLink_Config': {}}, {})
        self.assertTrue(result)


if __name__ == '__main__':
    unittest.main()