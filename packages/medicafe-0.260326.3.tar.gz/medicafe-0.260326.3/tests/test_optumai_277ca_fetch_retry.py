#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Tests for OPTUMAI search277CA delayed retry when success returns empty X12."""

from __future__ import print_function

import os
import sys
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


class Optumai277caFetchRetryTests(unittest.TestCase):
    def test_success_but_empty_payload_detected(self):
        from MediCafe.api_core import _optumai_search277ca_ack_success_but_payload_empty

        codes = ('000', '200')
        self.assertTrue(
            _optumai_search277ca_ack_success_but_payload_empty(
                {'statuscode': '000', 'x12ResponseData': None, 'message': None}, codes
            )
        )
        self.assertTrue(
            _optumai_search277ca_ack_success_but_payload_empty(
                {'statuscode': '000', 'x12ResponseData': '   ', 'message': ''}, codes
            )
        )
        self.assertFalse(
            _optumai_search277ca_ack_success_but_payload_empty(
                {'statuscode': '000', 'x12ResponseData': '~ST*277~'}, codes
            )
        )
        self.assertFalse(
            _optumai_search277ca_ack_success_but_payload_empty(
                {'statuscode': '404', 'x12ResponseData': None}, codes
            )
        )
        self.assertFalse(_optumai_search277ca_ack_success_but_payload_empty(None, codes))

    def test_delayed_retry_second_call_gets_payload(self):
        from MediCafe import api_core as api_core_mod

        payloads = [
            {'statuscode': '000', 'x12ResponseData': None, 'message': None},
            {'statuscode': '000', 'x12ResponseData': '~ST*277~BEG~', 'message': 'ok'},
        ]

        def fake_search(_client, _tid, _pid):
            return payloads.pop(0) if payloads else {}

        sleeps = []

        def fake_sleep(sec):
            sleeps.append(sec)

        with patch(
            'MediCafe.claim_actions_adapter.search_277ca_via_optumai', side_effect=fake_search
        ):
            ack, attempts, retried = api_core_mod._search_optumai_277ca_with_delayed_retry(
                None, 'tx1', '87726', sleep_fn=fake_sleep
            )
        self.assertEqual(attempts, 2)
        self.assertTrue(retried)
        self.assertEqual(sleeps, [1])
        self.assertIn('277', str(ack.get('x12ResponseData') or ''))

    def test_no_retry_when_first_has_payload(self):
        from MediCafe import api_core as api_core_mod

        calls = []

        def fake_search(_client, _tid, _pid):
            calls.append(1)
            return {'statuscode': '000', 'x12ResponseData': '~ST*277~', 'message': 'ok'}

        sleeps = []

        def fake_sleep(sec):
            sleeps.append(sec)

        with patch(
            'MediCafe.claim_actions_adapter.search_277ca_via_optumai', side_effect=fake_search
        ):
            ack, attempts, retried = api_core_mod._search_optumai_277ca_with_delayed_retry(
                None, 'tx1', '87726', sleep_fn=fake_sleep
            )
        self.assertEqual(attempts, 1)
        self.assertFalse(retried)
        self.assertEqual(sleeps, [])
        self.assertEqual(len(calls), 1)
        self.assertIn('277', str(ack.get('x12ResponseData') or ''))

    def test_no_retry_when_first_not_success(self):
        from MediCafe import api_core as api_core_mod

        def fake_search(_client, _tid, _pid):
            return {'statuscode': '404', 'x12ResponseData': None, 'message': 'nf'}

        sleeps = []

        def fake_sleep(sec):
            sleeps.append(sec)

        with patch(
            'MediCafe.claim_actions_adapter.search_277ca_via_optumai', side_effect=fake_search
        ):
            ack, attempts, retried = api_core_mod._search_optumai_277ca_with_delayed_retry(
                None, 'tx1', '87726', sleep_fn=fake_sleep
            )
        self.assertEqual(attempts, 1)
        self.assertFalse(retried)
        self.assertEqual(sleeps, [])
        self.assertEqual(ack.get('statuscode'), '404')


if __name__ == '__main__':
    unittest.main()
