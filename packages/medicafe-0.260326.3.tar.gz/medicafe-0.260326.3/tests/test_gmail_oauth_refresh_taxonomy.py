# -*- coding: utf-8 -*-
"""Unit tests for OAuth refresh taxonomy and retry behavior in gmail_oauth_utils."""
import json
import os
import tempfile
import unittest

import requests
from unittest.mock import MagicMock, patch

from MediLink import gmail_oauth_utils as gou


class _FakeLog(object):
    def __call__(self, msg, level="INFO"):
        pass


class TestGmailOAuthRefreshTaxonomy(unittest.TestCase):
    def setUp(self):
        self.log = _FakeLog()
        self.tmp = tempfile.mkdtemp()
        self.creds_path = os.path.join(self.tmp, "creds.json")
        with open(self.creds_path, "w") as f:
            json.dump(
                {
                    "web": {
                        "client_id": "cid",
                        "client_secret": "sec",
                    }
                },
                f,
            )
        gou._LAST_REFRESH_FAILURE_TS = 0.0
        gou._LAST_FAILURE_TAXONOMY = None

    def tearDown(self):
        try:
            import shutil

            shutil.rmtree(self.tmp, ignore_errors=True)
        except Exception:
            pass
        gou._LAST_REFRESH_FAILURE_TS = 0.0
        gou._LAST_FAILURE_TAXONOMY = None

    def test_invalid_grant_no_retry_clears_policy_path(self):
        mock_resp = MagicMock()
        mock_resp.status_code = 400
        mock_resp.text = '{"error":"invalid_grant"}'
        mock_resp.json.return_value = {"error": "invalid_grant"}

        with patch("MediLink.gmail_oauth_utils.requests.post", return_value=mock_resp) as post:
            data, tax = gou.refresh_access_token_detailed("rtok", self.creds_path, self.log)
        self.assertEqual(data, {})
        self.assertEqual(tax, gou.REFRESH_TAXONOMY_INVALID_GRANT)
        self.assertEqual(post.call_count, 1)

    def test_server_error_retries_then_fails(self):
        mock_resp = MagicMock()
        mock_resp.status_code = 503
        mock_resp.text = "unavailable"
        mock_resp.json.return_value = {}

        with patch("MediLink.gmail_oauth_utils.time.sleep"):
            with patch("MediLink.gmail_oauth_utils.requests.post", return_value=mock_resp) as post:
                data, tax = gou.refresh_access_token_detailed("rtok", self.creds_path, self.log)
        self.assertEqual(data, {})
        self.assertEqual(tax, gou.REFRESH_TAXONOMY_SERVER_ERROR)
        self.assertEqual(post.call_count, 3)

    def test_success_first_try(self):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.text = "{}"
        mock_resp.json.return_value = {"access_token": "a", "expires_in": 3600}

        with patch("MediLink.gmail_oauth_utils.requests.post", return_value=mock_resp) as post:
            data, tax = gou.refresh_access_token_detailed("rtok", self.creds_path, self.log)
        self.assertEqual(tax, gou.REFRESH_TAXONOMY_SUCCESS)
        self.assertEqual(data.get("access_token"), "a")
        self.assertEqual(post.call_count, 1)

    def test_network_error_retries(self):
        with patch("MediLink.gmail_oauth_utils.time.sleep"):
            with patch(
                "MediLink.gmail_oauth_utils.requests.post",
                side_effect=requests.exceptions.ConnectionError("boom"),
            ) as post:
                data, tax = gou.refresh_access_token_detailed("rtok", self.creds_path, self.log)
        self.assertEqual(data, {})
        self.assertEqual(tax, gou.REFRESH_TAXONOMY_TRANSIENT_NETWORK)
        self.assertEqual(post.call_count, 3)

    def test_refresh_and_save_keeps_file_on_transient_failure(self):
        token_path = os.path.join(self.tmp, "token.json")
        with open(token_path, "w") as f:
            json.dump(
                {
                    "access_token": "old",
                    "expires_in": 1,
                    "token_time": 0,
                    "refresh_token": "rt",
                },
                f,
            )

        with patch("MediLink.gmail_oauth_utils.time.sleep"):
            with patch(
                "MediLink.gmail_oauth_utils.requests.post",
                side_effect=requests.exceptions.Timeout("t"),
            ):
                out = gou.refresh_and_save_token(token_path, self.creds_path, "rt", self.log)
        self.assertIsNone(out)
        self.assertTrue(os.path.isfile(token_path))

    def test_refresh_and_save_clears_on_invalid_grant(self):
        token_path = os.path.join(self.tmp, "token.json")
        with open(token_path, "w") as f:
            json.dump(
                {
                    "access_token": "old",
                    "expires_in": 1,
                    "token_time": 0,
                    "refresh_token": "rt",
                },
                f,
            )

        mock_resp = MagicMock()
        mock_resp.status_code = 400
        mock_resp.text = '{"error":"invalid_grant"}'
        mock_resp.json.return_value = {"error": "invalid_grant"}

        with patch("MediLink.gmail_oauth_utils.requests.post", return_value=mock_resp):
            out = gou.refresh_and_save_token(token_path, self.creds_path, "rt", self.log)
        self.assertIsNone(out)
        self.assertFalse(os.path.isfile(token_path))


if __name__ == "__main__":
    unittest.main()
