#!/usr/bin/env python
from __future__ import print_function

import os
import tempfile
import unittest

from MediBot import MediBot_docx_index as docx_index


class DocxScheduleIndexTests(unittest.TestCase):

    def test_targeted_update_records_status_and_skips_unchanged_files(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            docx_path = os.path.join(tmpdir, 'sample.docx')
            with open(docx_path, 'wb') as handle:
                handle.write(b'docx payload')

            parse_calls = []
            original_parse = docx_index.parse_docx
            try:
                def fake_parse(filepath, surgery_dates=None, capture_schedule_positions=False):
                    parse_calls.append((filepath, capture_schedule_positions))
                    return {
                        '03-19-2026': {
                            '123': {
                                'diagnosis': 'H25.9',
                                'eye': 'OD',
                                'femto': ''
                            }
                        }
                    }

                docx_index.parse_docx = fake_parse

                _, first_stats = docx_index.update_docx_schedule_index(
                    tmpdir,
                    filepaths=[docx_path],
                    capture_schedule_positions=True,
                    source='gmail_download'
                )
                self.assertEqual(first_stats.get('parsed'), 1)
                self.assertEqual(len(parse_calls), 1)

                status = docx_index.load_docx_schedule_index_status(tmpdir)
                self.assertEqual(status.get('source'), 'gmail_download')
                self.assertEqual(status.get('mode'), 'targeted')
                self.assertEqual(status.get('requested_file_count'), 1)
                self.assertTrue(status.get('capture_schedule_positions'))
                self.assertEqual(status.get('stats', {}).get('parsed'), 1)

                _, second_stats = docx_index.update_docx_schedule_index(
                    tmpdir,
                    filepaths=[docx_path],
                    capture_schedule_positions=True,
                    source='gmail_download'
                )
                self.assertEqual(second_stats.get('parsed'), 0)
                self.assertEqual(second_stats.get('skipped'), 1)
                self.assertEqual(len(parse_calls), 1)
            finally:
                docx_index.parse_docx = original_parse

    def test_full_scan_status_records_source(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            docx_path = os.path.join(tmpdir, 'scan.docx')
            with open(docx_path, 'wb') as handle:
                handle.write(b'docx payload')

            original_parse = docx_index.parse_docx
            try:
                def fake_parse(filepath, surgery_dates=None, capture_schedule_positions=False):
                    return {
                        '03-20-2026': {
                            '456': {
                                'diagnosis': 'H26.9',
                                'eye': 'OS',
                                'femto': ''
                            }
                        }
                    }

                docx_index.parse_docx = fake_parse

                _, stats = docx_index.update_docx_schedule_index(
                    tmpdir,
                    filepaths=None,
                    capture_schedule_positions=False,
                    source='medibot_preprocess'
                )
                self.assertEqual(stats.get('parsed'), 1)

                status = docx_index.load_docx_schedule_index_status(tmpdir)
                self.assertEqual(status.get('source'), 'medibot_preprocess')
                self.assertEqual(status.get('mode'), 'full_scan')
                self.assertEqual(status.get('requested_file_count'), 1)
                self.assertFalse(status.get('capture_schedule_positions'))
                self.assertEqual(status.get('stats', {}).get('parsed'), 1)
            finally:
                docx_index.parse_docx = original_parse


    def test_parser_unavailable_full_scan_status_preserves_mode(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            original_parse = docx_index.parse_docx
            try:
                docx_index.parse_docx = None

                _, stats = docx_index.update_docx_schedule_index(
                    tmpdir,
                    filepaths=None,
                    capture_schedule_positions=False,
                    source='cli_rebuild'
                )
                self.assertEqual(stats.get('parsed'), 0)

                status = docx_index.load_docx_schedule_index_status(tmpdir)
                self.assertEqual(status.get('source'), 'cli_rebuild')
                self.assertEqual(status.get('mode'), 'full_scan')
                self.assertIsNone(status.get('requested_file_count'))
                self.assertFalse(status.get('parser_available'))
            finally:
                docx_index.parse_docx = original_parse

if __name__ == '__main__':
    unittest.main()

