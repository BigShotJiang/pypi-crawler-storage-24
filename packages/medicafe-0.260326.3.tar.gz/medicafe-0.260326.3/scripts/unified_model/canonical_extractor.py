#!/usr/bin/env python
"""
Phase D canonical extraction: build extracted_canonical_record and domain upsert payloads
from QA-pass rows. Deterministic keys. XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import json
import os
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_d_common import (
    CANONICALIZATION_VERSION,
    compute_canonical_key,
    compute_claim_key,
    compute_claim_line_key,
    compute_coverage_key,
    compute_encounter_key,
    compute_insurance_plan_key,
    compute_patient_key,
    compute_payer_key,
)
from patient_field_mapper import (
    extract_birth_date,
    extract_external_patient_id,
    extract_full_name,
    extract_surgery_date,
    is_valid_external_patient_id_5_digit,
    normalize_surgery_date_key,
)
from join_contract import (
    CSV_DOCX_AMBIGUOUS_DEFAULT_POLICY,
    CSV_DOCX_AMBIGUOUS_NEGOTIATION,
    JOIN_KEY_LABEL_PATIENT_SURGERY,
    extract_dat_join_identity,
)
from phase_d_v2_metrics import (
    DAT_V2_SKIP_INVALID_PATIENT_ID,
    DAT_V2_SKIP_MISSING_DOS_CLAIM_CHAIN,
    DAT_V2_SKIP_MISSING_PAYER_ANCHOR,
    V2_SOURCE_LANE_DAT,
    V2_SOURCE_LANE_REMIT,
    empty_extractor_v2_stats,
    v2_inc_payload,
    v2_inc_skip,
)


def _provenance_base(artifact_id, artifact_class, source_system, source_ref):
    """Build base provenance dict."""
    return {
        "artifact_id": artifact_id,
        "artifact_class": artifact_class,
        "source_system": source_system or "",
        "source_ref": source_ref or "",
        "extractor_version": CANONICALIZATION_VERSION,
    }


def extract_canonical_records(artifact_id, artifact_class, envelope, source_system, source_ref):
    """
    Extract canonical records from QA-pass envelope.
    Returns list of dicts: {canonical_type, canonical_key, canonical_json, provenance_json}.
    """
    records = []
    prov_base = _provenance_base(artifact_id, artifact_class, source_system, source_ref)

    if artifact_class == "csv" and envelope:
        rows = envelope.get("rows") or []
        for i, row in enumerate(rows):
            if not isinstance(row, dict):
                continue
            patient_id = extract_external_patient_id(row)
            birth_date = extract_birth_date(row)
            patient_key = compute_patient_key(source_system or "xp_local", patient_id, birth_date)
            canonical_json = json.dumps(row, separators=(",", ":"), ensure_ascii=True)
            prov = dict(prov_base, row_index=i)
            records.append({
                "canonical_type": "patient_csv_row",
                "canonical_key": patient_key,
                "canonical_json": canonical_json,
                "provenance_json": json.dumps(prov, separators=(",", ":"), ensure_ascii=True),
            })

    elif artifact_class == "jsonl" and envelope:
        rows = envelope.get("rows") or []
        for i, row in enumerate(rows):
            if not isinstance(row, dict):
                continue
            claim_num = row.get("claim_number") or row.get("Claim #") or ""
            payer_id = row.get("payer_id") or row.get("Payer ID") or ""
            claim_key = compute_canonical_key([claim_num, payer_id, str(i)])
            canonical_json = json.dumps(row, separators=(",", ":"), ensure_ascii=True)
            prov = dict(prov_base, row_index=i)
            records.append({
                "canonical_type": "remittance_row",
                "canonical_key": claim_key,
                "canonical_json": canonical_json,
                "provenance_json": json.dumps(prov, separators=(",", ":"), ensure_ascii=True),
            })

    elif artifact_class == "837" and envelope:
        member_id = envelope.get("member_id") or ""
        member_dob = envelope.get("member_dob") or ""
        payer_id = envelope.get("payer_id") or ""
        patient_key = compute_patient_key(source_system or "xp_local", member_id, member_dob)
        canonical_json = json.dumps(envelope, separators=(",", ":"), ensure_ascii=True)
        records.append({
            "canonical_type": "x12_member",
            "canonical_key": patient_key,
            "canonical_json": canonical_json,
            "provenance_json": json.dumps(prov_base, separators=(",", ":"), ensure_ascii=True),
        })

    elif artifact_class == "dat" and envelope:
        recs = envelope.get("records") or []
        for i, rec in enumerate(recs):
            if not isinstance(rec, dict):
                continue
            pat_id = rec.get("PATID") or rec.get("patient_id") or ""
            patient_key = compute_patient_key(source_system or "xp_local", pat_id, "")
            canonical_json = json.dumps(rec, separators=(",", ":"), ensure_ascii=True)
            prov = dict(prov_base, record_index=i)
            records.append({
                "canonical_type": "dat_record",
                "canonical_key": patient_key,
                "canonical_json": canonical_json,
                "provenance_json": json.dumps(prov, separators=(",", ":"), ensure_ascii=True),
            })

    elif artifact_class == "docx" and envelope:
        schedules = envelope.get("schedules") or {}
        patient_data = envelope.get("patient_data") or {}
        if schedules:
            for date_str, patients_dict in schedules.items():
                if not isinstance(patients_dict, dict):
                    continue
                for patient_id, details in patients_dict.items():
                    canonical_json = json.dumps(
                        details if isinstance(details, dict) else {"data": details},
                        separators=(",", ":"), ensure_ascii=True
                    )
                    patient_key = compute_patient_key(source_system or "xp_local", str(patient_id), "")
                    prov = dict(prov_base, schedule_key=date_str, patient_id=str(patient_id))
                    records.append({
                        "canonical_type": "docx_schedule",
                        "canonical_key": compute_canonical_key([patient_key, date_str or ""]),
                        "canonical_json": canonical_json,
                        "provenance_json": json.dumps(prov, separators=(",", ":"), ensure_ascii=True),
                    })
        elif patient_data:
            for patient_id, dates_dict in patient_data.items():
                if not isinstance(dates_dict, dict):
                    continue
                for date_str, details in dates_dict.items():
                    canonical_json = json.dumps(
                        details if isinstance(details, dict) else {"data": details},
                        separators=(",", ":"), ensure_ascii=True
                    )
                    patient_key = compute_patient_key(source_system or "xp_local", str(patient_id), "")
                    prov = dict(prov_base, schedule_key=date_str, patient_id=str(patient_id))
                    records.append({
                        "canonical_type": "docx_schedule",
                        "canonical_key": compute_canonical_key([patient_key, date_str or ""]),
                        "canonical_json": canonical_json,
                        "provenance_json": json.dumps(prov, separators=(",", ":"), ensure_ascii=True),
                    })

    if not records:
        prov_base["note"] = "minimal_artifact_summary"
        records.append({
            "canonical_type": "artifact_summary",
            "canonical_key": compute_patient_key(source_system or "xp_local", str(artifact_id), ""),
            "canonical_json": json.dumps({"artifact_class": artifact_class}, separators=(",", ":"), ensure_ascii=True),
            "provenance_json": json.dumps(prov_base, separators=(",", ":"), ensure_ascii=True),
        })

    return records


def _load_canonical_dict(text):
    """Best-effort decode of canonical/provenance JSON payloads."""
    try:
        data = json.loads(text or "{}")
    except (TypeError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _csv_docx_join_key(patient_id, surgery_date):
    """Stable join key for minimal upstream CSV and DOCX correlation."""
    patient_id = str(patient_id or "").strip()
    date_key = normalize_surgery_date_key(surgery_date)
    if not patient_id or not date_key:
        return ""
    return "{0}|{1}".format(patient_id, date_key)


def annotate_csv_docx_join(canonical_records):
    """
    Enrich patient_csv_row canonical_json with minimal DOCX schedule match fields.
    Returns compact telemetry for operator-facing reporting.
    """
    canonical_records = canonical_records or []
    csv_records = []
    csv_key_counts = {}
    docx_key_counts = {}
    docx_details_by_key = {}
    csv_records_by_key = {}
    docx_records_by_key = {}
    ambiguous_default_policy = CSV_DOCX_AMBIGUOUS_DEFAULT_POLICY
    ambiguous_negotiation = CSV_DOCX_AMBIGUOUS_NEGOTIATION

    for rec in canonical_records:
        ctype = rec.get("canonical_type") or ""
        if ctype == "patient_csv_row":
            row = _load_canonical_dict(rec.get("canonical_json"))
            join_key = _csv_docx_join_key(
                extract_external_patient_id(row),
                extract_surgery_date(row),
            )
            csv_records.append((rec, row, join_key))
            if join_key:
                csv_key_counts[join_key] = csv_key_counts.get(join_key, 0) + 1
                csv_records_by_key.setdefault(join_key, []).append(rec)
        elif ctype == "docx_schedule":
            provenance = _load_canonical_dict(rec.get("provenance_json"))
            data = _load_canonical_dict(rec.get("canonical_json"))
            join_key = _csv_docx_join_key(
                provenance.get("patient_id") or data.get("patient_id"),
                provenance.get("schedule_key") or data.get("schedule_key"),
            )
            if not join_key:
                continue
            docx_key_counts[join_key] = docx_key_counts.get(join_key, 0) + 1
            docx_records_by_key.setdefault(join_key, []).append(rec)
            docx_details_by_key.setdefault(join_key, []).append({
                "diagnosis": data.get("diagnosis"),
                "eye": data.get("eye"),
                "femto": data.get("femto"),
                "schedule_date": normalize_surgery_date_key(
                    provenance.get("schedule_key") or data.get("schedule_key")
                ),
            })

    ambiguous_keys = set(
        key for key, count in csv_key_counts.items() if int(count or 0) > 1
    )
    ambiguous_keys.update(
        key for key, count in docx_key_counts.items() if int(count or 0) > 1
    )

    matched_keys = set()
    csv_only_keys = set()
    ambiguous_examples = []
    for join_key in sorted(ambiguous_keys):
        join_parts = str(join_key or "").split("|", 1)
        patient_id = join_parts[0] if join_parts else ""
        schedule_date = join_parts[1] if len(join_parts) > 1 else ""
        ambiguous_examples.append({
            "join_key": join_key,
            "patient_id": patient_id,
            "schedule_date_key": schedule_date,
            "csv_candidate_count": int(csv_key_counts.get(join_key, 0) or 0),
            "docx_candidate_count": int(docx_key_counts.get(join_key, 0) or 0),
            "csv_artifact_ids": [
                rec.get("artifact_id") for rec in csv_records_by_key.get(join_key, [])
                if rec.get("artifact_id") is not None
            ],
            "docx_artifact_ids": [
                rec.get("artifact_id") for rec in docx_records_by_key.get(join_key, [])
                if rec.get("artifact_id") is not None
            ],
            "negotiation": ambiguous_negotiation,
            "selected_default": ambiguous_default_policy,
            "selected_status": "ambiguous",
        })
    for rec, row, join_key in csv_records:
        if not isinstance(row, dict):
            continue
        if join_key:
            row["docx_schedule_match_key"] = join_key
        if not join_key:
            row["docx_schedule_match_status"] = "no_join_key"
        elif join_key in ambiguous_keys:
            row["docx_schedule_match_status"] = "ambiguous"
            row["docx_schedule_match_policy"] = ambiguous_default_policy
            row["docx_schedule_match_reason"] = ambiguous_negotiation
            row["docx_schedule_csv_candidate_count"] = int(csv_key_counts.get(join_key, 0) or 0)
            row["docx_schedule_docx_candidate_count"] = int(docx_key_counts.get(join_key, 0) or 0)
        elif join_key in docx_key_counts:
            match = (docx_details_by_key.get(join_key) or [{}])[0]
            row["docx_schedule_match_status"] = "matched"
            row["docx_schedule_diagnosis"] = match.get("diagnosis")
            row["docx_schedule_eye"] = match.get("eye")
            row["docx_schedule_femto"] = match.get("femto")
            row["docx_schedule_date_key"] = match.get("schedule_date")
            matched_keys.add(join_key)
        else:
            row["docx_schedule_match_status"] = "csv_only"
            csv_only_keys.add(join_key)
        rec["canonical_json"] = json.dumps(row, separators=(",", ":"), ensure_ascii=True)

    docx_only_keys = set()
    for join_key in docx_key_counts:
        if join_key in csv_key_counts or join_key in ambiguous_keys:
            continue
        docx_only_keys.add(join_key)

    return {
        "join_key": JOIN_KEY_LABEL_PATIENT_SURGERY,
        "csv_candidate_count": sum(int(count or 0) for count in csv_key_counts.values()),
        "csv_join_key_count": len(csv_key_counts),
        "docx_candidate_count": sum(int(count or 0) for count in docx_key_counts.values()),
        "docx_join_key_count": len(docx_key_counts),
        "matched_count": len(matched_keys),
        "csv_only_count": len(csv_only_keys),
        "docx_only_count": len(docx_only_keys),
        "ambiguous_count": len(ambiguous_keys),
        "ambiguous_negotiation": ambiguous_negotiation,
        "ambiguous_default_policy": ambiguous_default_policy,
        "ambiguous_examples": ambiguous_examples[:5],
    }


def build_domain_upserts(canonical_records, artifact_id, source_system, entity_scope="v1"):
    """
    Build domain upsert payloads from canonical records.
    Returns (upserts_dict, v2_extractor_stats). v2_extractor_stats is None for v1.
    v1: patient from patient_csv_row and x12_member.
    v2: adds payer/plan/coverage/encounter/claim/claim_line from remittance_row and dat_record (PHASE_D_V2_ENTITY_UPSERT_SPEC subset).
    """
    entity_scope = str(entity_scope or "v1").strip().lower()
    if entity_scope not in ("v1", "v2"):
        entity_scope = "v1"
    v2_ext = empty_extractor_v2_stats() if entity_scope == "v2" else None
    upserts = {
        "patient": [],
        "payer": [],
        "insurance_plan": [],
        "coverage": [],
        "encounter": [],
        "claim": [],
        "claim_line": [],
    }
    seen_patients = set()

    def _merge_lineage(target, rec):
        target["canonical_type"] = rec.get("canonical_type") or ""
        target["canonical_key"] = rec.get("canonical_key") or ""
        target["source_system"] = source_system or "xp_local"
        return target

    for rec in canonical_records or []:
        ctype = rec.get("canonical_type") or ""
        cjson = rec.get("canonical_json") or "{}"
        try:
            data = json.loads(cjson)
        except (ValueError, TypeError):
            continue
        if ctype == "patient_csv_row" and isinstance(data, dict):
            patient_id = extract_external_patient_id(data)
            birth_date = extract_birth_date(data)
            full_name = extract_full_name(data)
            pk = compute_patient_key(source_system or "xp_local", patient_id, birth_date)
            if pk and pk not in seen_patients:
                seen_patients.add(pk)
                upserts["patient"].append(_merge_lineage({
                    "artifact_id": artifact_id,
                    "patient_key": pk,
                    "external_patient_id": patient_id,
                    "full_name": full_name,
                    "birth_date": birth_date,
                    "source_system": source_system or "xp_local",
                }, rec))
        elif ctype == "x12_member" and isinstance(data, dict):
            member_id = data.get("member_id") or ""
            dob = data.get("member_dob") or ""
            first_name = data.get("member_first_name") or ""
            last_name = data.get("member_last_name") or ""
            full_name = (first_name + " " + last_name).strip() or None
            pk = compute_patient_key(source_system or "xp_local", member_id, dob)
            if pk and pk not in seen_patients:
                seen_patients.add(pk)
                upserts["patient"].append(_merge_lineage({
                    "artifact_id": artifact_id,
                    "patient_key": pk,
                    "external_patient_id": member_id,
                    "full_name": full_name,
                    "birth_date": dob,
                    "source_system": source_system or "xp_local",
                }, rec))
        elif entity_scope == "v2" and ctype == "dat_record" and isinstance(data, dict):
            lane = V2_SOURCE_LANE_DAT
            pid_j, dos_j = extract_dat_join_identity(data)
            patient_id = str(
                pid_j
                or data.get("PATID")
                or data.get("patient_id")
                or data.get("patid")
                or extract_external_patient_id(data)
                or ""
            ).strip()
            birth_date = extract_birth_date(data) or ""
            full_name = extract_full_name(data)
            dos = str(
                dos_j
                or data.get("DOS")
                or data.get("DATE1")
                or data.get("date_of_service")
                or data.get("service_date")
                or ""
            ).strip()
            if not is_valid_external_patient_id_5_digit(patient_id):
                v2_inc_skip(v2_ext, lane, DAT_V2_SKIP_INVALID_PATIENT_ID, 1)
                continue
            pk = compute_patient_key(source_system or "xp_local", patient_id, birth_date)
            if pk and pk not in seen_patients:
                seen_patients.add(pk)
                upserts["patient"].append(_merge_lineage({
                    "artifact_id": artifact_id,
                    "patient_key": pk,
                    "external_patient_id": patient_id,
                    "full_name": full_name,
                    "birth_date": birth_date,
                    "source_system": source_system or "xp_local",
                }, rec))
                v2_inc_payload(v2_ext, lane, "patient", 1)
            ins_raw = str(
                data.get("PAYERID") or data.get("INSID") or data.get("payer_id") or data.get("insurance_id") or ""
            ).strip()
            if ins_raw and pk:
                endpoint = str(source_system or "xp_local")
                pay_key = compute_payer_key(ins_raw, endpoint)
                upserts["payer"].append(_merge_lineage({
                    "artifact_id": artifact_id,
                    "payer_key": pay_key,
                    "payer_external_id": ins_raw,
                    "payer_name": None,
                    "endpoint_name": endpoint,
                }, rec))
                v2_inc_payload(v2_ext, lane, "payer", 1)
                plan_ids_json = json.dumps([], separators=(",", ":"), ensure_ascii=True)
                plan_key = compute_insurance_plan_key(pay_key, plan_ids_json)
                upserts["insurance_plan"].append(_merge_lineage({
                    "artifact_id": artifact_id,
                    "plan_key": plan_key,
                    "payer_key": pay_key,
                    "medisoft_insurance_ids_json": plan_ids_json,
                }, rec))
                v2_inc_payload(v2_ext, lane, "insurance_plan", 1)
                if dos:
                    cov_key = compute_coverage_key(pk, plan_key, dos)
                    upserts["coverage"].append(_merge_lineage({
                        "artifact_id": artifact_id,
                        "coverage_key": cov_key,
                        "patient_key": pk,
                        "plan_key": plan_key,
                        "effective_start": dos,
                        "effective_end": None,
                        "active_flag": 1,
                    }, rec))
                    v2_inc_payload(v2_ext, lane, "coverage", 1)
                    enc_key = compute_encounter_key(pk, dos, artifact_id)
                    upserts["encounter"].append(_merge_lineage({
                        "artifact_id": artifact_id,
                        "encounter_key": enc_key,
                        "patient_key": pk,
                        "date_of_service": dos,
                        "source_artifact_id": artifact_id,
                        "diagnosis_code": str(data.get("DIAG") or "") or None,
                        "eye_side": str(data.get("EYE") or "") or None,
                    }, rec))
                    v2_inc_payload(v2_ext, lane, "encounter", 1)
                    claim_num = str(data.get("claim_number") or data.get("CLAIM") or "").strip()
                    cl_key = compute_claim_key(enc_key, pay_key, claim_num)
                    upserts["claim"].append(_merge_lineage({
                        "artifact_id": artifact_id,
                        "claim_key": cl_key,
                        "encounter_key": enc_key,
                        "payer_key": pay_key,
                        "claim_number": claim_num or None,
                        "status": None,
                        "charged_amount": None,
                        "allowed_amount": None,
                        "paid_amount": None,
                        "patient_resp_amount": None,
                        "source_artifact_id": artifact_id,
                    }, rec))
                    v2_inc_payload(v2_ext, lane, "claim", 1)
                    line_key = compute_claim_line_key(cl_key, 1)
                    upserts["claim_line"].append(_merge_lineage({
                        "artifact_id": artifact_id,
                        "claim_line_key": line_key,
                        "claim_key": cl_key,
                        "line_number": 1,
                        "cpt_code": str(data.get("CPT") or data.get("cpt") or "") or None,
                        "diagnosis_pointer": None,
                        "charged_amount": None,
                        "paid_amount": None,
                    }, rec))
                    v2_inc_payload(v2_ext, lane, "claim_line", 1)
                else:
                    v2_inc_skip(v2_ext, lane, DAT_V2_SKIP_MISSING_DOS_CLAIM_CHAIN, 1)
            elif pk:
                v2_inc_skip(v2_ext, lane, DAT_V2_SKIP_MISSING_PAYER_ANCHOR, 1)
        elif entity_scope == "v2" and ctype == "remittance_row" and isinstance(data, dict):
            rlane = V2_SOURCE_LANE_REMIT
            endpoint = str(source_system or "xp_local")
            payer_ext = str(data.get("payer_id") or data.get("Payer ID") or "").strip()
            payer_name = str(data.get("payer_name") or data.get("Payer Name") or "").strip() or None
            if payer_ext:
                pay_key = compute_payer_key(payer_ext, endpoint)
                upserts["payer"].append(_merge_lineage({
                    "artifact_id": artifact_id,
                    "payer_key": pay_key,
                    "payer_external_id": payer_ext,
                    "payer_name": payer_name,
                    "endpoint_name": endpoint,
                }, rec))
                v2_inc_payload(v2_ext, rlane, "payer", 1)
                plan_ids_json = json.dumps([], separators=(",", ":"), ensure_ascii=True)
                plan_key = compute_insurance_plan_key(pay_key, plan_ids_json)
                upserts["insurance_plan"].append(_merge_lineage({
                    "artifact_id": artifact_id,
                    "plan_key": plan_key,
                    "payer_key": pay_key,
                    "medisoft_insurance_ids_json": plan_ids_json,
                }, rec))
                v2_inc_payload(v2_ext, rlane, "insurance_plan", 1)
            pat_raw = str(
                data.get("patient_id") or data.get("PatID") or data.get("Patient ID") or ""
            ).strip()
            dos = str(
                data.get("date_of_service") or data.get("DOS") or data.get("Date") or data.get("service_date") or ""
            ).strip()
            if payer_ext and is_valid_external_patient_id_5_digit(pat_raw) and dos:
                pk = compute_patient_key(source_system or "xp_local", pat_raw, "")
                pay_key = compute_payer_key(payer_ext, endpoint)
                plan_ids_json = json.dumps([], separators=(",", ":"), ensure_ascii=True)
                plan_key = compute_insurance_plan_key(pay_key, plan_ids_json)
                if pk not in seen_patients:
                    seen_patients.add(pk)
                    upserts["patient"].append(_merge_lineage({
                        "artifact_id": artifact_id,
                        "patient_key": pk,
                        "external_patient_id": pat_raw,
                        "full_name": None,
                        "birth_date": None,
                        "source_system": source_system or "xp_local",
                    }, rec))
                    v2_inc_payload(v2_ext, rlane, "patient", 1)
                cov_key = compute_coverage_key(pk, plan_key, dos)
                upserts["coverage"].append(_merge_lineage({
                    "artifact_id": artifact_id,
                    "coverage_key": cov_key,
                    "patient_key": pk,
                    "plan_key": plan_key,
                    "effective_start": dos,
                    "effective_end": None,
                    "active_flag": 1,
                }, rec))
                v2_inc_payload(v2_ext, rlane, "coverage", 1)
                enc_key = compute_encounter_key(pk, dos, artifact_id)
                upserts["encounter"].append(_merge_lineage({
                    "artifact_id": artifact_id,
                    "encounter_key": enc_key,
                    "patient_key": pk,
                    "date_of_service": dos,
                    "source_artifact_id": artifact_id,
                    "diagnosis_code": None,
                    "eye_side": None,
                }, rec))
                v2_inc_payload(v2_ext, rlane, "encounter", 1)
                claim_num = str(data.get("claim_number") or data.get("Claim #") or data.get("Claim") or "").strip()
                cl_key = compute_claim_key(enc_key, pay_key, claim_num)
                upserts["claim"].append(_merge_lineage({
                    "artifact_id": artifact_id,
                    "claim_key": cl_key,
                    "encounter_key": enc_key,
                    "payer_key": pay_key,
                    "claim_number": claim_num or None,
                    "status": str(data.get("status") or data.get("Status") or "").strip() or None,
                    "charged_amount": None,
                    "allowed_amount": None,
                    "paid_amount": None,
                    "patient_resp_amount": None,
                    "source_artifact_id": artifact_id,
                }, rec))
                v2_inc_payload(v2_ext, rlane, "claim", 1)
                line_key = compute_claim_line_key(cl_key, 1)
                upserts["claim_line"].append(_merge_lineage({
                    "artifact_id": artifact_id,
                    "claim_line_key": line_key,
                    "claim_key": cl_key,
                    "line_number": 1,
                    "cpt_code": None,
                    "diagnosis_pointer": None,
                    "charged_amount": None,
                    "paid_amount": None,
                }, rec))
                v2_inc_payload(v2_ext, rlane, "claim_line", 1)
    if v2_ext is None:
        return upserts, None
    return upserts, v2_ext
