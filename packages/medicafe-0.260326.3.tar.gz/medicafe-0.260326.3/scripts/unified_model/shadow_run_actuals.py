#!/usr/bin/env python
"""
Shadow run report normalization and Phase D QA resolution for audit + health pack.
XP-compatible: Python 3.4+, stdlib only.
"""
from __future__ import print_function

import json
import os
import re
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

try:
    from phase_f_common import MISSING_MARKER, PHASES
except ImportError:
    MISSING_MARKER = "__MISSING__"
    PHASES = ("B", "C", "D", "E")

# Bump when SHADOW_ACTUAL_INT_FIELDS changes (MediCafe parity guard).
SHADOW_ACTUAL_FIELDS_VERSION = 1

SHADOW_ACTUAL_INT_FIELDS = (
    "phase_b_dat_manifest_rows_count",
    "phase_d_dat_selected_count",
    "phase_d_dat_qa_pass_count",
    "phase_d_dat_qa_reject_count",
    "phase_d_dat_canonical_record_count",
    "phase_d_dat_v2_payload_attempted_total",
    "phase_d_dat_v2_inserted_total",
    "phase_d_dat_v2_skipped_total",
    "phase_d_dat_v2_constraint_failed_total",
)


def _safe_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _shadow_payload_pipeline_status(payload):
    if not isinstance(payload, dict):
        return "unknown"
    if bool(payload.get("pipeline_ok")):
        return "ok"
    failed_phase = str(payload.get("failed_phase", "") or "").strip()
    error_code = str(payload.get("error_code", "") or "").strip()
    if failed_phase and error_code:
        return "fail:{0}:{1}".format(failed_phase, error_code)
    if failed_phase:
        return "fail:{0}".format(failed_phase)
    if error_code:
        return "fail:{0}".format(error_code)
    return "fail"


def _shadow_payload_post_medisoft_label(payload):
    if not isinstance(payload, dict):
        return "unknown"
    post_medisoft_status = str(payload.get("post_medisoft_status", "") or "").strip().lower() or "unknown"
    blocked_stage = str(payload.get("post_medisoft_blocked_stage", "") or "").strip().lower()
    if blocked_stage:
        return "{0}({1})".format(post_medisoft_status, blocked_stage)
    return post_medisoft_status


def normalize_shadow_actual(payload, path="", safe_int_fn=None):
    """
    Normalize shadow_run_report JSON into health-pack / audit counters.
    safe_int_fn: optional (value, default) -> int; defaults to _safe_int.
    """
    si = safe_int_fn if callable(safe_int_fn) else _safe_int
    if not isinstance(payload, dict):
        return {}
    run_id = str(payload.get("run_id", "") or "").strip()
    if not run_id and path:
        base = os.path.basename(path)
        if base.startswith("shadow_run_report_") and base.endswith(".json"):
            run_id = base[len("shadow_run_report_") : -len(".json")]
    if not run_id:
        return {}
    out = {
        "run_id": run_id,
        "generated_at_utc": str(payload.get("generated_at_utc", "") or "").strip(),
        "pipeline_status": _shadow_payload_pipeline_status(payload),
        "post_medisoft_label": _shadow_payload_post_medisoft_label(payload),
        "post_medisoft_status": str(payload.get("post_medisoft_status", "") or "").strip().lower() or "unknown",
    }
    for key in SHADOW_ACTUAL_INT_FIELDS:
        out[key] = si(payload.get(key), 0)
    return out


def parse_qa_canonical_summary_run_id(path):
    """Return run id from .../qa_canonical_summary_{rid}.json basename, or ''."""
    base = os.path.basename(path or "")
    m = re.match(r"^qa_canonical_summary_(.+)\.json$", base)
    return m.group(1) if m else ""


def _load_json_dict(path):
    if not path or not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def iter_recent_shadow_rows(reports_dir, limit=10):
    """
    List shadow_run_report_*.json by mtime descending; return
    [{"path", "payload", "norm"}, ...] (norm = normalize_shadow_actual).
    """
    try:
        lim = int(limit)
    except (TypeError, ValueError):
        lim = 10
    if lim <= 0 or not reports_dir or not os.path.isdir(reports_dir):
        return []
    try:
        names = os.listdir(reports_dir)
    except (OSError, IOError):
        return []
    candidates = []
    for name in names:
        if not (name.startswith("shadow_run_report_") and name.endswith(".json")):
            continue
        path = os.path.join(reports_dir, name)
        if not os.path.isfile(path):
            continue
        try:
            mtime = os.path.getmtime(path)
        except (OSError, IOError, ValueError):
            mtime = 0.0
        candidates.append((-mtime, name, path))
    candidates.sort(key=lambda x: (x[0], x[1]))
    out = []
    for _neg_m, _name, path in candidates[:lim]:
        payload = _load_json_dict(path)
        if not payload:
            continue
        norm = normalize_shadow_actual(payload, path, _safe_int)
        if not norm.get("run_id"):
            continue
        out.append({"path": path, "payload": payload, "norm": norm})
    return out


def select_latest_and_baseline_shadow(rows):
    """
    rows: iter_recent_shadow_rows output (mtime desc).
    Returns (latest_row_or_none, baseline_row_or_none).
    Baseline = newest prior row with pipeline_ok, preferring post_medisoft_status == exercised.
    """
    if not rows:
        return None, None
    latest = rows[0]
    rest = rows[1:]
    ok_rows = [r for r in rest if r.get("payload", {}).get("pipeline_ok") is True]
    if not ok_rows:
        return latest, None
    exercised = [
        r
        for r in ok_rows
        if str(r.get("payload", {}).get("post_medisoft_status", "") or "").strip().lower() == "exercised"
    ]
    baseline = exercised[0] if exercised else ok_rows[0]
    return latest, baseline


def _latest_report_path(reports_dir, prefix, suffixes=(".json",)):
    """Return (path, run_id) for newest file matching prefix."""
    candidates = []
    try:
        names = os.listdir(reports_dir)
    except Exception:
        return None, ""
    for name in names:
        if not name.startswith(prefix):
            continue
        if suffixes and not any(name.endswith(s) for s in suffixes):
            continue
        path = os.path.join(reports_dir, name)
        try:
            mt = os.path.getmtime(path)
        except Exception:
            mt = -1
        candidates.append((mt, name, path))
    if not candidates:
        return None, ""
    candidates.sort(key=lambda x: (x[0], x[1]))
    _mt, name, path = candidates[-1]
    m = re.match(r"^" + re.escape(prefix) + r"(.+?)\.[^.]+$", name)
    rid = m.group(1) if m else ""
    return path, rid


def format_top_v2_reasons_summary(qa_dict, max_pairs=2, max_len=200):
    """Compact top constraint/skip reasons from phase_d_v2_domain_metrics."""
    qa_dict = qa_dict if isinstance(qa_dict, dict) else {}
    dm = qa_dict.get("phase_d_v2_domain_metrics")
    if not isinstance(dm, dict):
        return ""
    pairs = []
    for bucket_key, label in (
        ("constraint_failed_by_reason", "cf"),
        ("skipped_by_reason", "sk"),
    ):
        block = dm.get(bucket_key)
        if not isinstance(block, dict):
            continue
        all_map = block.get("all")
        if not isinstance(all_map, dict):
            continue
        for reason, count in all_map.items():
            try:
                c = int(count)
            except (TypeError, ValueError):
                continue
            if c > 0 and reason:
                rs = str(reason)
                pairs.append((c, label, rs, "{0}:{1}={2}".format(label, rs, c)))
    # Stable ordering: count desc, then bucket label, then reason string.
    pairs.sort(key=lambda x: (-x[0], x[1], x[2]))
    parts = [p[3] for p in pairs[:max_pairs]]
    s = ",".join(parts)
    if len(s) > max_len:
        return s[: max_len - 3] + "..."
    return s


def resolve_phase_d_qa_dict(lab_dir, latest_shadow_payload, state):
    """
    Resolve Phase D qa_canonical_summary dict for regression breakdown.
    Returns (qa_dict, meta) where meta includes qa_alignment_source, phase_d_run_id,
    alignment_ok (bool), alignment_detail (str).
    """
    reports_dir = os.path.join(lab_dir, "reports")
    state = state if isinstance(state, dict) else {}
    payload = latest_shadow_payload if isinstance(latest_shadow_payload, dict) else {}
    shadow_run_id = str(payload.get("run_id") or "").strip()
    state_pipeline = str(state.get("last_shadow_pipeline_run_id") or "").strip()
    pipeline_coherent = bool(shadow_run_id and state_pipeline and shadow_run_id == state_pipeline)

    meta = {
        "qa_alignment_source": "",
        "phase_d_run_id": "",
        "alignment_ok": False,
        "alignment_detail": "",
    }

    paths = payload.get("source_summary_paths")
    primary_path = None
    expected_rid_from_primary = ""
    primary_path_missing = False
    if isinstance(paths, list):
        try:
            d_idx = list(PHASES).index("D")
        except ValueError:
            d_idx = -1
        if d_idx >= 0 and d_idx < len(paths):
            primary_path = paths[d_idx]
    if primary_path and str(primary_path).strip() and primary_path != MISSING_MARKER:
        expected_rid_from_primary = parse_qa_canonical_summary_run_id(primary_path)
        if os.path.isfile(primary_path):
            data = _load_json_dict(primary_path)
            if data:
                meta["qa_alignment_source"] = "shadow_source_summary_paths_d"
                meta["phase_d_run_id"] = expected_rid_from_primary or parse_qa_canonical_summary_run_id(primary_path)
                meta["alignment_ok"] = True
                meta["alignment_detail"] = "primary_path"
                return data, meta
        primary_path_missing = True

    phase_map = state.get("last_shadow_pipeline_phase_run_ids")
    if not isinstance(phase_map, dict):
        phase_map = {}
    d_rid = str(phase_map.get("D") or state.get("last_phase_d_run_id") or "").strip()
    if d_rid:
        cursor_path = os.path.join(reports_dir, "qa_canonical_summary_{0}.json".format(d_rid))
        if os.path.isfile(cursor_path):
            data = _load_json_dict(cursor_path)
            if data:
                meta["qa_alignment_source"] = "cursor_phase_d"
                meta["phase_d_run_id"] = d_rid
                if not pipeline_coherent:
                    meta["alignment_ok"] = False
                    meta["alignment_detail"] = "cursor_unanchored_mixed_snapshot"
                    return data, meta
                if primary_path_missing and expected_rid_from_primary and d_rid != expected_rid_from_primary:
                    meta["alignment_ok"] = False
                    meta["alignment_detail"] = "cursor_d_rid_mismatch_expected_from_shadow_path"
                    return data, meta
                meta["alignment_ok"] = True
                meta["alignment_detail"] = "cursor_anchored"
                return data, meta

    fb_path, fb_rid = _latest_report_path(reports_dir, "qa_canonical_summary_", (".json",))
    if fb_path and os.path.isfile(fb_path):
        data = _load_json_dict(fb_path)
        meta["qa_alignment_source"] = "fallback_latest"
        meta["phase_d_run_id"] = str(fb_rid or "")
        meta["alignment_ok"] = False
        meta["alignment_detail"] = "alignment_missed_fallback_latest"
        return data, meta

    meta["qa_alignment_source"] = "missing"
    meta["alignment_detail"] = "no_qa_summary_found"
    return {}, meta


def eval_drop_ratio_vs_baseline(latest_val, baseline_val):
    """Positive drop ratio when latest < baseline. Returns float or None if skipped."""
    try:
        b = int(baseline_val)
        l = int(latest_val)
    except (TypeError, ValueError):
        return None
    if b <= 0:
        return None
    drop = float(max(b - l, 0)) / float(b)
    return round(drop, 6)
