#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author: qicongsheng
def get_name():
    return 'knify'


def get_version():
    return '1.9.62'


def print_version():
    print('%s %s\r\nDevelopment tools for python.' % (get_name(), get_version()))
