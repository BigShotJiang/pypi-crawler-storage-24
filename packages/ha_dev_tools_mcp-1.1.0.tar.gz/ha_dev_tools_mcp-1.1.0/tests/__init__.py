"""Tests for Home Assistant Configuration Manager."""
