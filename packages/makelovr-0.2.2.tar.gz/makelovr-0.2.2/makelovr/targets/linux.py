import importlib.resources as resources
import os
import shutil
import subprocess

from ..core.archive import make_lovr
from ..core.downloader import download_lovr


def build_linux(config):

    build_dir = config["build_directory"]
    name = config["name"]
    version = config["lovr_version"]

    os.makedirs(build_dir, exist_ok=True)

    # -----------------------------
    # Build game archive
    # -----------------------------

    lovr_archive = os.path.join(build_dir, f"{name}.lovr")
    make_lovr(".", lovr_archive)

    # -----------------------------
    # Download engine
    # -----------------------------

    engine_dir = os.path.join(build_dir, "engine-linux")
    download_lovr(version, "linux", engine_dir)

    runtime_dir = os.path.join(build_dir, "runtime")
    lib_dir = os.path.join(runtime_dir, "lib")

    os.makedirs(runtime_dir, exist_ok=True)
    os.makedirs(lib_dir, exist_ok=True)

    # -----------------------------
    # Extract AppImage
    # -----------------------------

    appimage = next(f for f in os.listdir(engine_dir) if f.endswith(".AppImage"))

    appimage_path = os.path.join(engine_dir, appimage)

    os.chmod(appimage_path, 0o755)

    subprocess.run(
        ["bash", "-c", f"cd {engine_dir} && ./{appimage} --appimage-extract"],
        check=True,
    )

    squash = os.path.join(engine_dir, "squashfs-root")

    # -----------------------------
    # Copy lovr binary
    # -----------------------------

    shutil.copy(os.path.join(squash, "lovr"), os.path.join(runtime_dir, "lovr"))

    os.chmod(os.path.join(runtime_dir, "lovr"), 0o755)

    # -----------------------------
    # Copy shared libraries
    # -----------------------------

    for file in os.listdir(squash):

        if file.endswith(".so") or ".so." in file:
            shutil.copy(os.path.join(squash, file), os.path.join(lib_dir, file))

    # -----------------------------
    # Fuse executable
    # -----------------------------

    fuse = resources.files("makelovr.runtime") / "fuse"
    stub = resources.files("makelovr.runtime") / "lovr_fused"

    os.chmod(fuse, 0o755)
    os.chmod(stub, 0o755)

    out = os.path.join(build_dir, f"{name}-x86_64")

    subprocess.run(
        [
            str(fuse),
            "--stub",
            str(stub),
            "--runtime",
            runtime_dir,
            "--game",
            lovr_archive,
            "--out",
            out,
        ],
        check=True,
    )

    os.chmod(out, 0o755)

    # -----------------------------
    # Cleanup
    # -----------------------------

    shutil.rmtree(engine_dir, ignore_errors=True)
    shutil.rmtree(runtime_dir, ignore_errors=True)

    print("Linux fused executable:", out)
