::: albert.collections.notebooks.NotebookCollection
