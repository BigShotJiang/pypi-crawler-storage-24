from typing import List
from .config import ConfigMgr
from .dcmi import dcmi
from .topo import TopoSingleFactory
from .npu import NPU, EID, IP, process_roce
from .tool import get_server_unique_id
from .urma_device import UrmaDevice, get_urma_device_list

def get_eid_port(eid):
    last = eid[-2:]
    h = int(last, 16)
    p = ((~128) & h) >> 3
    return p

def get_eid_die_id(eid):
    low = eid[-2]
    die_id = 8 & int(low, 16)
    return die_id >> 3

    npu.level(0).net_instance_id = f"sp_{sp_id}_srv_{server_index}"

def process_level0_v1(npu):
    """
    v2规则中， die_id字段， mesh固定填0， 但实际前4个NPU的mesh使用die 0， 后4个NPU使用die1
    """
    mesh_port_map = {
        1:0,
        2:3,
        3:4,
        4:5,
        5:6,
        6:7,
        7:8,
    }
    topo = TopoSingleFactory.get_topo()
    max_fe = 0
    mesh_dev = None
    for urma_dev in npu.urma_dev_list:
        try:
            fe = urma_dev.get_fe_id()
            die_id = urma_dev.get_die_id()
        except Exception:
            continue
        if die_id == 1: # mesh的固定使用0, 过滤掉1
            continue
        if fe > max_fe:
            max_fe = fe
            mesh_dev = urma_dev
    
    for eid in mesh_dev.eid_list:
        p = get_eid_port(eid)
        if p > 7 or (int(eid[-3], 16) & 8) != 0:
            # EID中获取到的port id为1-9
            continue
        if (npu.device_id % 8) < 4:
            die_id = 0
        else:
            die_id = 1
        """
        v1规则中， 物理口从1-7， 需要重新映射
        """
        ports = [f"{die_id}/{mesh_port_map[p]}"]
        plane_id = f"plane_{die_id}"
        npu.level(0).append(EID(eid, ports, plane_id))

    sp_id = ConfigMgr().get("super_pod_id")
    server_index = ConfigMgr().get("server_index")
    # 标卡每4个卡在同一个mesh链接，因此每4个卡的net_instance_id相同
    npu.level(0).net_instance_id = f"sp_{sp_id}_srv_{server_index}"

def process_level0_v2(npu):
    """
    v2规则中， die id和物理口id按照规则编码
    """
    topo = TopoSingleFactory.get_topo()
    #for eid in npu.addr_list:
    max_fe = 0
    mesh_dev = None
    for urma_dev in npu.urma_dev_list:
        try:
            fe = urma_dev.get_fe_id()
            die_id = urma_dev.get_die_id()
        except Exception:
            continue
        if ((npu.device_id % 8) < 4 and die_id == 0) or ((npu.device_id % 8) >= 4 and die_id == 1):
            # POD前4个NPU使用0die组mesh，后4个NPU使用1die组mesh
            continue
        if fe > max_fe:
            max_fe = fe
            mesh_dev = urma_dev
    
    for eid in mesh_dev.eid_list:
        p = get_eid_port(eid)
        if p > 9 or (int(eid[-3], 16) & 8) != 0:
            # EID中获取到的port id为1-9
            continue
        die_id = get_eid_die_id(eid)
        ports = [f"{die_id}/{p - 1}"]  # 需要-1映射到0-8
        plane_id = f"plane_{die_id}"
        npu.level(0).append(EID(eid, ports, plane_id))

    #server_id = get_server_unique_id()
    sp_id = ConfigMgr().get("super_pod_id")
    server_index = ConfigMgr().get("server_index")
    # 标卡每4个卡在同一个mesh链接，因此每4个卡的net_instance_id相同

def process_level0(npu):
    topo = TopoSingleFactory.get_topo()
    #for eid in npu.addr_list:
    max_fe = 0
    mesh_dev = None
    for urma_dev in npu.urma_dev_list:
        try:
            fe = urma_dev.get_fe_id()
            die_id = urma_dev.get_die_id()
        except Exception:
            continue
        if die_id == 1:
            # POD前4个NPU使用0die组mesh，后4个NPU使用1die组mesh
            continue
        if fe > max_fe:
            max_fe = fe
            mesh_dev = urma_dev
    
    is_v2 = False
    for eid in mesh_dev.eid_list:
        p = get_eid_port(eid)
        if p > 9 or (int(eid[-3], 16) & 8) != 0:
            # EID中获取到的port id为1-9
            continue
        if p > 7:
            is_v2 = True
            break

    if is_v2:
        process_level0_v2(npu)
    else:
        process_level0_v1(npu)


def get_level1_config(phy_id):
    """
    获取端口规则 (die_id, fe_id, (ports))
    """
    mainboard_id = ConfigMgr().get("mainboard_id")
    if mainboard_id == 3 and (phy_id % 8 ) < 4:
        return [(0, 2,(1, 2)), (1, 2, (0,1,2,3,5,6))]
    if mainboard_id == 3 and (phy_id % 8 ) >= 4:
        return [(1, 2,(1, 2)), (0, 2, (0,1,2,3,4,5))]

def process_level1(npu):
    configs = get_level1_config(npu.device_id)
    for urma_dev in npu.urma_dev_list:
        fe_id = urma_dev.get_fe_id()
        try:
            die_id = urma_dev.get_die_id()
            eid = urma_dev.get_pg_eid()
        except Exception:
            continue
        for target_die, target_fe, ports in configs:
            if die_id == target_die and fe_id == target_fe:
                port_list = [f"{die_id}/{p}" for p in ports]
                plane_id = f"plane_pg_{0 if (len(ports) == 6) else 1}"
                npu.level(1).append(EID(eid, port_list, plane_id))

    npu.level(1).net_instance_id = f"""superpod_{ConfigMgr().get("super_pod_id")}"""

def process_npu_for_pod(npu):
    max_level = int(ConfigMgr().get("max_level"))
    levels = TopoSingleFactory.get_topo().get_level_list()[:max_level]
    for level in levels:
        if level == 0:
            try:
                process_level0(npu)
            except Exception as e:
                print(f"NPU {npu.device_id} level {level} exception {e}")
        if level == 1:
            try:
                process_level1(npu)
            except Exception as e:
                print(f"NPU {npu.device_id} level {level} exception {e}")
        if level == 3:
            try:
                process_roce(npu, level)
            except Exception as e:
                print(f"NPU {npu.device_id} level {level} exception {e}")

def process_rootinfo_pod(rootinfo):
    for npu in rootinfo.rank_list:
        try:
            npu.urma_dev_list = get_urma_device_list(npu.npu_id, "pod")
            process_npu_for_pod(npu)
        except Exception as e:
            print(e)