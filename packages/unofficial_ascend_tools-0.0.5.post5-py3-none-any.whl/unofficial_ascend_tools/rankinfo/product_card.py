from typing import List
from .config import ConfigMgr
from .dcmi import dcmi
from .topo import TopoSingleFactory
from .npu import NPU, EID, IP, process_roce
from .tool import get_server_unique_id
from .urma_device import get_urma_device_list

def get_eid_port(eid):
    last = eid[-2:]
    h = int(last, 16)
    p = ((~128) & h) >> 3
    return p

def get_eid_die_id(eid):
    low = eid[-2]
    die_id = 8 & int(low, 16)
    return die_id >> 3

def process_level0(npu):
    topo = TopoSingleFactory.get_topo()
    mesh_dev = npu.urma_dev_list[0] # 标卡仅一个urma device
    for eid in mesh_dev.eid_list:
        p = get_eid_port(eid)
        if p > 9:
            continue
        die_id = get_eid_die_id(eid)
        port_list = [f"{die_id}/{p}"]
        plane_id = f"plane_{die_id}"
        npu.level(0).append(EID(eid, port_list, plane_id))

    server_id = get_server_unique_id()
    # 标卡每4个卡在同一个mesh链接，因此每4个卡的net_instance_id相同
    npu.level(0).net_instance_id = f"{server_id}_{npu.phy_id // 4}"

def process_npu_for_card(npu):
    max_level = int(ConfigMgr().get("max_level"))
    levels = TopoSingleFactory.get_topo().get_level_list()[:max_level]
    for level in levels:
        if level == 0:
            process_level0(npu)
        if level == 3:
            process_roce(npu, level)

def process_rootinfo_card(rootinfo):
    for npu in rootinfo.rank_list:
        try:
            npu.urma_dev_list = get_urma_device_list(npu.npu_id)
            process_npu_for_card(npu)
        except Exception as e:
            print(f"NPU {npu.npu_id} process failed :{e}")
