from abc import ABC
import copy
import functools
from typing import List
from .interface import ToDict
from .urma_device import UrmaDevice
from .roce import get_npu_roce_ip
from .topo import TopoSingleFactory


def exclude_fields(*fields):
    """Decorator to exclude specified field names when converting objects to Dict"""

    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            data = func(*args, **kwargs)
            for field in fields:
                data.pop(field, None)
            return data

        return wrapper

    return decorator

def get_eid_fe(eid):
    x = eid[13:15]
    fe = int(x, 16)
    xx = (126 & fe) >> 1
    return xx

class Address(ToDict, ABC):
    """Base class for EID/IP addresses"""

    def __init__(self, addr, port_ids=None, plane_id="", addr_type="common type"):
        self.addr_type = addr_type
        self.addr = addr
        self.ports = [] if not port_ids else port_ids
        self.plane_id = plane_id


class EID(Address):
    def __init__(self, eid, ports=None, plane_id=None):
        super().__init__(eid, ports, plane_id, "EID")
        self.addr = eid
        self.ports = ports

    @exclude_fields()
    def to_dict(self):
        ret = copy.deepcopy(self.__dict__)
        ret["ports"] = self.ports
        return ret

    def get_fe(self):
        h = self.addr[13:15]
        fe = int(h, 16)
        xx = (126 & fe) >>1
        return xx

    def set_fe(self, fe):
        eid = self.addr
        self.addr = f"{eid[0:14]}{fe}{eid[15:]}"

    def is_d2d(self):
        p = int(self.addr[-3], 16)
        return no (p & 8)

    def get_port(self):
        return int(self.addr[-2:], 16)

class IP(Address):
    def __init__(self, addr, plane_id="", ports=None):
        super().__init__(addr, ports, plane_id, "IPV4")
        self.addr = addr

    @exclude_fields("port_ids", "die_id")
    def to_dict(self):
        ret = copy.deepcopy(self.__dict__)
        ret["ports"] = ["d2h"]
        return ret


class NetLayer(ToDict):
    def __init__(
        self,
        net_layer,
        net_instance_id,
        net_type,
        net_attr="",
        rank_addr_list: List[Address] = None,
    ):
        self.net_layer = net_layer
        self.net_instance_id = net_instance_id
        self.net_type = net_type
        self.net_attr = net_attr
        self.rank_addr_list = [] if not rank_addr_list else rank_addr_list

    @exclude_fields()
    def to_dict(self):
        return copy.deepcopy(self.__dict__)

    def append(self, eid):
        self.rank_addr_list.append(eid)
        self.rank_addr_list.sort(key = lambda x: len(x.ports), reverse=True)

class NPU(ToDict):
    def __init__(self, npu_id, device_id, level_list: List[NetLayer] = None):
        self.npu_id = npu_id
        self.device_id = device_id
        self.phy_id = device_id
        self.local_id = self.phy_id
        self.level_list = [] if not level_list else level_list
        self.level_map = {}
        self.addr_list = []
        self.urma_dev_list = []

    @exclude_fields("level_map", "phy_id", "addr_list", "urma_dev_list", "npu_id")
    def to_dict(self):
        for level in sorted(self.level_map.keys()):
            layer = self.level_map[level]
            self.level_list.append(layer)

        return copy.deepcopy(self.__dict__)

    def level(self, level):
        if level not in self.level_map.keys():
            net_type = "TOPO_FILE_DESC" if level == 0 else "CLOS"
            self.level_map[level] = NetLayer(level, "", net_type)
        return self.level_map[level]

def process_roce(npu, level):
    npu_ip_map = get_npu_roce_ip()
    topo = TopoSingleFactory.get_topo()
    try:
        ip = npu_ip_map[npu.phy_id % 8]
        if len(ip) == 0:
            return
    except KeyError:
        return

    ports = topo.get_ports_by_level(npu.phy_id, level)
    ipaddr = IP(ip, "roce", ports)
    npu.level(level).append(ipaddr)
    npu.level(level).net_instance_id = "cluster"

def get_max_fe(npu_addr_list):
    max_fe = 0
    for eid in npu_addr_list:
        fe = get_eid_fe(eid.addr)
        if fe > max_fe:
            max_fe = fe
    return fe
