#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Copyright 2025. Huawei Technologies Co.,Ltd. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
import ctypes
import functools
import os

EID_SIZE = 16

from enum import Enum


class DCMIChipSubCmd(Enum):
    DCMI_CHIP_SUB_CMD_SPOD_INFO = 1


class DcmiMainCmdEnum(Enum):
    DCMI_MAIN_CMD_CHIP_INF = 12


# Enum mapping from master commands to slave commands
MAIN_CMD_TO_SUB_CMD = {
    DcmiMainCmdEnum.DCMI_MAIN_CMD_CHIP_INF: DCMIChipSubCmd,
}

# Mocking ip starts from 0
_roce_ip_start = 0


class In4(ctypes.Structure):
    _fields_ = [
        ("reserved", ctypes.c_uint64),
        ("prefix", ctypes.c_uint32),
        ("addr", ctypes.c_uint32),
    ]


class In6(ctypes.Structure):
    _fields_ = [
        ("subnet_prefix", ctypes.c_uint64),
        ("interface_id", ctypes.c_uint64),
    ]


class EidInfo(ctypes.Structure):
    _fields_ = [
        ("eid", ctypes.c_ubyte * EID_SIZE),
        ("eid_index", ctypes.c_uint32),
        ("reserved", ctypes.c_ubyte * 4),
    ]


class CSuperPodInfo(ctypes.Structure):
    _reserve_len = 27
    _fields_ = [
        ("sdid", ctypes.c_uint),
        ("super_pod_size", ctypes.c_uint),
        ("super_pod_id", ctypes.c_uint),
        ("server_index", ctypes.c_uint),
        ("chassis_id", ctypes.c_uint),
        ("super_pod_type", ctypes.c_char),
        ("reserve", ctypes.c_char * _reserve_len),
    ]


class CBoardInfo(ctypes.Structure):
    _fields_ = [
        ("board_id", ctypes.c_uint),
        ("pcb_id", ctypes.c_uint),
        ("bom_id", ctypes.c_uint),
        ("slot_id", ctypes.c_uint),
    ]


@functools.lru_cache()
def _get_dcmi_lib():
    dcmi_lib = ctypes.CDLL("libdcmi.so", mode=os.RTLD_LAZY | os.RTLD_GLOBAL)
    return dcmi_lib


def dcmi_init():
    """DCMI initialization"""
    dcmi_lib = _get_dcmi_lib()
    dcmi_lib.dcmiv2_init.argtypes = None
    dcmi_lib.dcmiv2_init.restype = ctypes.c_int
    return dcmi_lib.dcmiv2_init()



def get_all_device_count():
    """Get total number of devices"""
    dcmi_lib = _get_dcmi_lib()
    dcmi_lib.dcmi_get_all_device_count.argtypes = [ctypes.POINTER(ctypes.c_int)]
    dcmi_lib.dcmi_get_all_device_count.restype = ctypes.c_int
    count = ctypes.c_int(0)
    dcmi_lib.dcmi_get_all_device_count(count)
    return count.value


def dcmi_get_card_list():
    """Get NPU ID list"""
    dcmi_lib = _get_dcmi_lib()
    list_len = 16
    dcmi_lib.dcmi_get_card_list.argtypes = [
        ctypes.POINTER(ctypes.c_int),
        ctypes.POINTER(ctypes.c_int * list_len),
        ctypes.c_int,
    ]
    dcmi_lib.dcmi_get_card_list.restype = ctypes.c_int
    card_num, card_list = ctypes.c_int(0), (ctypes.c_int * list_len)()
    dcmi_lib.dcmi_get_card_list(ctypes.byref(card_num), ctypes.byref(card_list), list_len)
    return card_num.value, card_list[: card_num.value]


def get_device_id_in_card(card_id):
    """Get the (number of chips, MCU_ID, CPU_ID) on the specified NPU management unit"""
    dcmi_lib = _get_dcmi_lib()
    dcmi_lib.dcmi_get_device_id_in_card.argtypes = [
        ctypes.c_int,
        ctypes.POINTER(ctypes.c_int),
        ctypes.POINTER(ctypes.c_int),
        ctypes.POINTER(ctypes.c_int),
    ]
    dcmi_lib.dcmi_get_device_id_in_card.restype = ctypes.c_int
    device_id_max, mcu_id, cpu_id = ctypes.c_int(0), ctypes.c_int(0), ctypes.c_int(0)
    dcmi_lib.dcmi_get_device_id_in_card(
        card_id,
        ctypes.byref(device_id_max),
        ctypes.byref(mcu_id),
        ctypes.byref(cpu_id),
    )
    return device_id_max.value, mcu_id.value, cpu_id.value


def get_super_pod_info(npu_id=0):
    """Get superpod information"""
    dcmi_lib = _get_dcmi_lib()
    dcmi_lib.dcmiv2_get_device_info.argtypes = [
        ctypes.c_int,
        ctypes.c_uint,
        ctypes.c_uint,
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_uint),
    ]
    dcmi_lib.dcmiv2_get_device_info.restype = ctypes.c_int
    main_cmd = DcmiMainCmdEnum.DCMI_MAIN_CMD_CHIP_INF.value
    sub_enum = MAIN_CMD_TO_SUB_CMD.get(DcmiMainCmdEnum.DCMI_MAIN_CMD_CHIP_INF, None)
    if sub_enum is None:
        raise KeyError
    sub_cmd = sub_enum.DCMI_CHIP_SUB_CMD_SPOD_INFO.value
    spod_info = CSuperPodInfo()
    size = ctypes.c_uint(ctypes.sizeof(CSuperPodInfo))
    ret = dcmi_lib.dcmiv2_get_device_info(
        npu_id,
        main_cmd,
        sub_cmd,
        ctypes.byref(spod_info),
        ctypes.byref(size),
    )
    if ret != 0:
        raise Exception("get spod info failed")
    return spod_info


def get_local_id(card_id):
    """Get local_id by card_id using dcmi_get_device_phyid_from_logicid. In Ascend950, card_id equals logic_id in a broad."""
    dcmi_lib = _get_dcmi_lib()
    dcmi_lib.dcmi_get_device_phyid_from_logicid.argtypes = [
        ctypes.c_int,
        ctypes.POINTER(ctypes.c_int),
    ]
    dcmi_lib.dcmi_get_device_phyid_from_logicid.restype = ctypes.c_int
    card_id = ctypes.c_int(card_id)
    local_id = ctypes.c_int(0)
    dcmi_lib.dcmi_get_device_phyid_from_logicid(card_id, local_id)
    return local_id.value


def get_device_board_info(npu_id=0):
    """Get board information, board_id can confirm whether it is a standard card form factor"""
    dcmi_lib = _get_dcmi_lib()
    dcmi_lib.dcmiv2_get_device_board_info.argtypes = [
        ctypes.c_int,
        ctypes.POINTER(CBoardInfo),
    ]
    dcmi_lib.dcmiv2_get_device_board_info.restype = ctypes.c_int
    board_info = CBoardInfo()
    ret = dcmi_lib.dcmiv2_get_device_board_info(npu_id, ctypes.byref(board_info))
    if ret != 0:
        raise Exception(f"get device board info failed {npu_id} {ret}")
    return board_info


def get_mainboard_id(npu_id):
    """Get mainboard_id to determine the number of P interconnects in the current standard card"""
    dcmi_lib = _get_dcmi_lib()
    dcmi_lib.dcmiv2_get_mainboard_id.argtypes = [
        ctypes.c_int,
        ctypes.POINTER(ctypes.c_uint),
    ]
    dcmi_lib.dcmiv2_get_mainboard_id.restype = ctypes.c_int
    mainboard_id = ctypes.c_uint(0)
    ret = dcmi_lib.dcmiv2_get_mainboard_id(npu_id, mainboard_id)
    if ret != 0:
        raise Exception(f"get mainboard id failed for {npu_id} {ret}")
    return mainboard_id.value


def is_dcmi_available() -> bool:
    """
    return true if dcmi for atlas 950 is avaiable
    """
    try:
        dcmi_lib = _get_dcmi_lib()
        return hasattr(dcmi_lib, "dcmi_get_eid_list_by_urma_dev_index")
    except OSError:
        return False


def get_card_id_device_id_from_phy_id(device_phy_id: int) -> (int, int):
    dcmi_lib = _get_dcmi_lib()
    card_id = ctypes.c_int(0)
    device_id = ctypes.c_int(0)
    dcmi_lib.dcmi_get_card_id_device_id_from_phyid(
        ctypes.byref(card_id), ctypes.byref(device_id), device_phy_id
    )
    return (card_id.value, device_id.value)

def is_dcmiv2()->bool:
    try:
        dcmi_lib = _get_dcmi_lib()
        return hasattr(dcmi_lib, "dcmiv2_get_dcmi_version")
    except OSError:
        return False

def get_card_id_device_id_from_phy_id(device_phy_id: int) ->(int, int):
    dcmi_lib = _get_dcmi_lib()
    card_id = ctypes.c_int(0)
    device_id = ctypes.c_int(0)
    dcmi_lib.dcmi_get_card_id_device_id_from_phyid(ctypes.byref(card_id), ctypes.byref(device_id), device_phy_id)
    return (card_id.value, device_id.value)

def get_urma_device_cnt_v2(npu_id):
    dcmi_lib = _get_dcmi_lib()
    dcmi_lib.dcmiv2_get_urma_device_cnt.argtypes = [
        ctypes.c_int,
        ctypes.POINTER(ctypes.c_int),
    ]
    dcmi_lib.dcmiv2_get_urma_device_cnt.restype = ctypes.c_int
    count = ctypes.c_int(0)
    ret = dcmi_lib.dcmiv2_get_urma_device_cnt(npu_id, ctypes.byref(count))
    if ret != 0:
        raise Exception(f"Get urma device cnt failed {npu_id} {ret}")
    return count.value

def get_eid_list_by_urma_dev_index_v2(npu_id, dev_index):
    """Get EID list information for the specified URMA device"""
    dcmi_lib = _get_dcmi_lib()
    dcmi_lib.dcmiv2_get_eid_list_by_urma_dev_index.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.POINTER(EidInfo),
        ctypes.POINTER(ctypes.c_int),
    ]
    dcmi_lib.dcmiv2_get_eid_list_by_urma_dev_index.restype = ctypes.c_int
    MAX_LEN = 32
    eid_ptr = (EidInfo * MAX_LEN)()
    eid_cnt = ctypes.c_int(MAX_LEN)
    eid_list = []
    ret = dcmi_lib.dcmiv2_get_eid_list_by_urma_dev_index(npu_id, dev_index, eid_ptr, ctypes.byref(eid_cnt))
    if ret != 0:
        return eid_list
    for j in range(eid_cnt.value):
        cur_eid_info = eid_ptr[j]
        eid_list.append(
            "".join([format(c, "02x") for c in cur_eid_info.eid[:EID_SIZE]])
        )
    return eid_list

def get_phyid_from_logicid(logic_id):
    dcmi_lib = _get_dcmi_lib()
    dcmi_lib.dcmiv2_get_chip_phyid_from_dev_id.argtypes=[ctypes.c_uint, ctypes.POINTER(ctypes.c_uint)]
    dcmi_lib.dcmiv2_get_chip_phyid_from_dev_id.restype=ctypes.c_int
    phy_id = ctypes.c_uint(0)
    ret = dcmi_lib.dcmiv2_get_chip_phyid_from_dev_id(ctypes.c_uint(logic_id), ctypes.byref(phy_id))
    if ret != 0:
        raise Exception(f"get phyid from logicid failed {logic_id} {ret}")
    return phy_id.value

def get_logicid_from_phyid(phy_id):
    dcmi_lib = _get_dcmi_lib()
    dcmi_lib.dcmiv2_get_dev_id_from_chip_phyid.argtypes=[ctypes.c_uint, ctypes.POINTER(ctypes.c_uint)]
    dcmi_lib.dcmiv2_get_dev_id_from_chip_phyid.restype=ctypes.c_int
    logic_id = ctypes.c_uint(0)
    dcmi_lib.dcmiv2_get_dev_id_from_chip_phyid(ctypes.c_uint(phy_id), ctypes.byref(logic_id))
    return logic_id.value
