# CHANGELOG

<!-- version list -->

## v1.1.1 (2026-03-18)

### Bug Fixes

- Fix Python ASGI adaptor to handle streaming responses correctly
  ([#82](https://github.com/cloudflare/workers-py/pull/82),
  [`d3ea87a`](https://github.com/cloudflare/workers-py/commit/d3ea87aff37c7a833f0602cc2a8018f1d5dde91b))

- Fix streaming responses in asgi module ([#82](https://github.com/cloudflare/workers-py/pull/82),
  [`d3ea87a`](https://github.com/cloudflare/workers-py/commit/d3ea87aff37c7a833f0602cc2a8018f1d5dde91b))


## v1.1.0 (2026-03-12)

### Features

- **workers-py**: Make workers cli install workers-runtime-sdk
  ([#74](https://github.com/cloudflare/workers-py/pull/74),
  [`a62f255`](https://github.com/cloudflare/workers-py/commit/a62f255e51555d212ecbb98f93e7145e251863f4))


## v1.0.2 (2026-03-12)

### Bug Fixes

- Fix types in workers-runtime-sdk ([#73](https://github.com/cloudflare/workers-py/pull/73),
  [`c46de58`](https://github.com/cloudflare/workers-py/commit/c46de58086d5f27341194fb48353bea7acc08312))


## v1.0.1 (2026-03-12)

### Bug Fixes

- Include correct files in wheel ([#71](https://github.com/cloudflare/workers-py/pull/71),
  [`b544b80`](https://github.com/cloudflare/workers-py/commit/b544b80423b249df41b58fb8f807cbee5ea170fb))


## v1.0.0 (2026-03-12)

- Initial Release
