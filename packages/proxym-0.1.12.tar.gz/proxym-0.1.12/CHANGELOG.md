# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.12] - 2026-03-21

### Docs
- Update docs/README.md

### Test
- Update tests/conftest.py
- Update tests/test_dashboard_integration.py

## [0.1.11] - 2026-03-21

### Other
- Update src/proxym/dashboard/hooks/useDashboardData.js

## [0.1.10] - 2026-03-21

### Docs
- Update docs/README.md
- Update project/README.md
- Update project/context.md

### Other
- Update project/analysis.toon
- Update project/calls.mmd
- Update project/calls.png
- Update project/compact_flow.mmd
- Update project/compact_flow.png
- Update project/dashboard.html
- Update project/evolution.toon
- Update project/flow.mmd
- Update project/flow.png
- Update project/flow.toon
- ... and 5 more files

## [0.1.9] - 2026-03-21

### Docs
- Update docs/README.md
- Update project/README.md

### Test
- Update tests/test_dashboard_live.py
- Update tests/test_dashboard_new.py

### Other
- Update .toonignore
- Update frontend/dashboard.html
- Update frontend/proxym-dashboard.jsx
- Update project/analysis.json
- Update project/analysis.yaml
- Update project/calls.png
- Update project/evolution.toon
- Update project/flow.png
- Update project/index.html
- Update project/project.toon
- ... and 4 more files

## [0.1.8] - 2026-03-21

### Docs
- Update docs/README.md
- Update project/CONTRIBUTING.md
- Update project/README.md
- Update project/api-changelog.md
- Update project/api.md
- Update project/architecture.md
- Update project/configuration.md
- Update project/context.md
- Update project/coverage.md
- Update project/dependency-graph.md
- ... and 2 more files

### Test
- Update tests/test_context.py
- Update tests/test_dashboard_live.py
- Update tests/test_mcp.py

### Other
- Update .code2docs.api_snapshot.json
- Update .env.example
- Update Makefile
- Update frontend/dashboard.html
- Update frontend/proxym-dashboard.jsx
- Update project/analysis.json
- Update project/analysis.toon
- Update project/analysis.yaml
- Update project/calls.mmd
- Update project/calls.png
- ... and 16 more files

## [0.1.7] - 2026-03-21

### Docs
- Update README.md
- Update docs/README.md

### Test
- Update tests/test_browser_profiles.py
- Update tests/test_clonebox_adapter.py
- Update tests/test_dashboard_live.py

### Other
- Update src/proxym/virt/profiles/browser.clonebox.yaml
- Update src/proxym/virt/profiles/cursor.clonebox.yaml
- Update src/proxym/virt/profiles/jetbrains.clonebox.yaml
- Update src/proxym/virt/profiles/vscode.clonebox.yaml
- Update src/proxym/virt/profiles/windsurf.clonebox.yaml

## [0.1.6] - 2026-03-21

### Test
- Update tests/test_dashboard_new.py

### Other
- Update frontend/dashboard.html
- Update frontend/proxym-dashboard.jsx

## [0.1.5] - 2026-03-21

### Docs
- Update README.md
- Update docs/README.md

### Test
- Update tests/test_dashboard_gui.py
- Update tests/test_dashboard_integration.py
- Update tests/test_dashboard_live.py
- Update tests/test_dashboard_new.py
- Update tests/test_dashboard_performance.py

### Other
- Update dashboard.html
- Update proxym-dashboard.jsx

## [0.1.4] - 2026-03-21

### Docs
- Update README.md

### Test
- Update tests/conftest.py
- Update tests/test_accounts.py
- Update tests/test_analyzer.py
- Update tests/test_dashboard.py
- Update tests/test_delta_buffer.py
- Update tests/test_e2e.py
- Update tests/test_router.py

## [0.1.3] - 2026-03-21

### Docs
- Update CHANGELOG.md
- Update README.md

### Other
- Update Dockerfile.jetson
- Update docker-compose.prod.yml
- Update proxym-dashboard.jsx
- Update quadlet/ollama.container
- Update quadlet/proxym.container
- Update quadlet/proxym.network
- Update quadlet/redis.container
- Update scripts/jetson-entrypoint.sh
- Update scripts/setup.sh
- Update src/proxym/dashboard/panel.jsx
- ... and 1 more files

## [0.1.2] - 2026-03-21

## [0.1.1] - 2026-03-21

### Docs
- Update README.md

### Test
- Update tests/conftest.py
- Update tests/test_accounts.py
- Update tests/test_analyzer.py
- Update tests/test_dashboard.py
- Update tests/test_delta_buffer.py
- Update tests/test_e2e.py
- Update tests/test_router.py

### Other
- Update .env.example
- Update .gitignore
- Update Dockerfile.jetson
- Update proxym-dashboard.jsx
- Update docker-compose.prod.yml
- Update project.sh
- Update quadlet/proxym.container
- Update quadlet/proxym.network
- Update quadlet/ollama.container
- Update quadlet/redis.container
- ... and 4 more files

