# cli.py
# Enhanced CLI client: navigable menu, colorful output, emoji-rich tool rendering.
# - Optional arrow-key menu via prompt_toolkit (fallback to numeric menu)
# - Colorized UI via rich (fallback to plain text)
# - Friendly tool call/result summaries (🔍 read, 📝 write, 📎 append, 📂 list, ✏️ edit, 💻 run)
# - Preserves previous behavior and settings
# - Injects CODEBASE_MAP.md into the first user message (wrapped in <codebase_map>) without manual trimming.

import argparse
import asyncio
import copy
import json
import logging
import os
import sys
import socket
import shutil
from pathlib import Path
from typing import AsyncIterator, Dict, List, Optional, Tuple, Any, TYPE_CHECKING

import httpx
import time
import uuid
import random
from datetime import datetime, timezone, timedelta
from typing import Callable
import getpass
from urllib.parse import urlparse, urlunparse, parse_qs, urlencode
import subprocess
import shlex
import signal
import importlib
import importlib.util
import importlib.metadata
import inspect
import re
import base64
import hashlib
import secrets
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer

# Optional websockets for Agent Mode (dev-only WS bridge)
try:
    import websockets  # type: ignore
    HAS_WS = True
except Exception:
    HAS_WS = False
    websockets = None  # type: ignore
if TYPE_CHECKING:
    from websockets.server import WebSocketServerProtocol  # type: ignore
else:
    from typing import Any as WebSocketServerProtocol  # type: ignore
# Local execution tools
try:
    from henosis_cli_tools import (
        FileToolPolicy as LocalFileToolPolicy,
        read_file as local_read_file,
        write_file as local_write_file,
        append_file as local_append_file,
        list_dir as local_list_dir,
        run_command as local_run_command,
        apply_patch as local_apply_patch,
        string_replace as local_string_replace,
    )
    # Optional: run_shell (L3-only). Keep optional so older henosis_cli_tools
    # versions can still provide the rest of the local tools.
    try:
        from henosis_cli_tools import run_shell as local_run_shell
    except Exception:
        local_run_shell = None  # type: ignore
    HAS_LOCAL_TOOLS = True
except Exception:
    HAS_LOCAL_TOOLS = False
    local_run_shell = None  # type: ignore
try:
    from henosis_cli_tools.settings_ui import SettingsUI  # no-deps settings UI
    HAS_SETTINGS_UI = True
except Exception:
    HAS_SETTINGS_UI = False

# Optional rich for colors and nice formatting
try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.syntax import Syntax
    from rich.table import Table
    from rich.prompt import Prompt, Confirm
    from rich.text import Text
    HAS_RICH = True
except Exception:
    HAS_RICH = False
    Console = None
    Panel = None
    Syntax = None
    Table = None
    Prompt = None
    Confirm = None
    Text = None

"""prompt_toolkit is intentionally not used.

We previously relied on prompt_toolkit for interactive line editing and menus.
Copy/selection behavior is terminal- and prompt_toolkit-implementation specific
and proved unreliable across environments.

The CLI now uses our dependency-free input engine (henosis_cli_tools.input_engine)
and a dependency-free highlighted menu implementation.
"""

# Keep these names defined for legacy branches that are guarded by HAS_PT.
HAS_PT = False
PromptSession = None
WordCompleter = None
KeyBindings = None
SelectionType = None
Condition = None
Application = None
get_app = None
Layout = None
HSplit = None
Window = None
Dimension = None
FormattedTextControl = None
Style = None

# If optional deps are missing, print a friendly note but continue with fallbacks.
if not HAS_RICH:
    try:
        sys.stderr.write(
            "Note: optional package missing: rich\n"
            "- rich enables colorful output\n"
        )
    except Exception:
        pass

# New: low-level input engine (no third-party deps) for Shift+Enter newlines
# Also provides a best-effort clipboard helper used for Ctrl+C copy when our
# prompt_toolkit selection is active.
try:
    from henosis_cli_tools.input_engine import (
        InputReadInterrupted,
        make_engine,
        _copy_to_clipboard as _hn_copy_to_clipboard,
    )
    HAS_INPUT_ENGINE = True
except Exception:
    HAS_INPUT_ENGINE = False

    class InputReadInterrupted(Exception):
        def __init__(self, draft: str = "") -> None:
            super().__init__("input interrupted")
            self.draft = draft

    def _hn_copy_to_clipboard(text: str) -> bool:  # type: ignore
        return False
DEBUG_SSE = False  # set via --debug-sse
DEBUG_REQ = False  # set via --debug-req
# Max number of recent SSE event summaries to retain for diagnostics when a stream
# ends without a message.completed event. Overridable via env HENOSIS_CLI_SSE_TAIL.
try:
    SSE_TAIL_MAX = int(os.getenv("HENOSIS_CLI_SSE_TAIL", "40") or 40)
    if SSE_TAIL_MAX <= 0:
        SSE_TAIL_MAX = 40
except Exception:
    SSE_TAIL_MAX = 40


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="henosis-cli: Interactive CLI for Henosis Chat (henosis.us) multi-provider streaming backend"
    )
    p.add_argument(
        "-s",
        "--server",
        default=os.getenv("HENOSIS_SERVER", "https://henosis.us/api_v2"),
        help="Backend server base URL (default: env HENOSIS_SERVER or https://henosis.us/api_v2)",
    )
    # Quick dev toggle: use localhost/dev server base without typing --server
    p.add_argument("--dev", dest="use_dev", action="store_true", help="Use dev endpoint (env HENOSIS_DEV_SERVER or http://127.0.0.1:8000/api)")
    p.add_argument("-m", "--model", default=None, help="Model name (optional; server default if omitted)")
    p.add_argument("-S", "--system", default=None, help="Optional system prompt")
    p.add_argument("--timeout", type=float, default=None, help="HTTP timeout in seconds (default: None)")
    # Output verbosity
    p.add_argument("--verbose", action="store_true", help="Show extra status/debug output (dim logs)")
    # Debug toggles
    p.add_argument("--debug-sse", action="store_true", help="Verbose log of SSE events to console")
    p.add_argument("--debug-req", action="store_true", help="Log outgoing request payloads")
    # Raw log capture to file (CWD by default)
    p.add_argument("--raw-log", action="store_true", help="Write raw request/response logs to a file in the current working directory")
    p.add_argument("--raw-log-file", default=os.getenv("HENOSIS_RAW_LOG_PATH", None), help="Optional explicit path for the raw log file (default: CWD/henosis_raw-<ts>-<id>.log)")
    # Update checks
    p.add_argument("--no-update-check", action="store_true", help="Skip CLI and server version update checks")
    # Remote Control / Agent Mode bridge
    p.add_argument(
        "--remote-control",
        "--agent-mode",
        dest="agent_mode",
        action="store_true",
        help="Enable Remote Control syncing between the CLI and web UI",
    )
    p.add_argument("--agent-host", default=os.getenv("HENOSIS_AGENT_HOST", "127.0.0.1"), help="Local compatibility WS host (default: 127.0.0.1 or HENOSIS_AGENT_HOST)")
    p.add_argument("--agent-port", type=int, default=int(os.getenv("HENOSIS_AGENT_PORT", "8700")), help="Local compatibility WS port (default: 8700 or HENOSIS_AGENT_PORT; use 0 for auto)")
    p.add_argument("--agent-allow-remote", action="store_true", help="Allow non-localhost connections to the local compatibility WS bridge")
    # Agent scope per-terminal defaults
    p.add_argument(
        "--agent-scope",
        dest="agent_scope",
        default=os.getenv("HENOSIS_AGENT_SCOPE", None),
        help="Set Agent scope root (absolute path) for this terminal session. Defaults to the terminal's current working directory.",
    )
    # Workspace/terminal controls
    p.add_argument(
        "--workspace-dir",
        default=os.getenv("HENOSIS_WORKSPACE_DIR", None),
        help="Override workspace root directory (default: current working directory at CLI start)",
    )
    p.add_argument(
        "--terminal-id",
        default=os.getenv("HENOSIS_TERMINAL_ID", None),
        help="Optional terminal/session id used for server namespacing; does not affect local workspace root",
    )
    # Manual naming (optional). Everything else is auto-enabled by default.
    p.add_argument(
        "--title",
        default=None,
        help="Optional thread title. If omitted, CLI will name threads as '<YYYY-MM-DD HH:MM> - <project>'",
    )
    # Codebase map prefix toggle (controls <codebase_map> injection)
    p.add_argument(
        "--codebase-map-prefix",
        dest="map_prefix",
        action="store_true",
        help="Inject <codebase_map>...</codebase_map> before the first user message (overrides saved setting)",
    )
    p.add_argument(
        "--no-codebase-map-prefix",
        dest="map_prefix",
        action="store_false",
        help="Disable codebase map injection (overrides saved setting)",
    )
    p.set_defaults(map_prefix=None)
    # Onboarding helpers
    p.add_argument("--whoami", action="store_true", help="Print authentication status and exit")
    p.add_argument("--reset-config", action="store_true", help="Reset local CLI settings and re-run onboarding")
    return p

def mask_key(k: Optional[str], keep: int = 6) -> str:
    if not k:
        return "(none)"
    s = str(k).strip()
    if len(s) <= keep:
        return "*" * len(s)
    return s[:keep] + "*" * (len(s) - keep)

# Note: CLI does not read API keys; the server does. This helper remains here
# if you later choose to add a client-side /health check that prints masked keys.
# It does not change runtime behavior.

def join_url(base: str, path: str) -> str:
    base = base.rstrip("/")
    path = path.lstrip("/")
    return f"{base}/{path}"


def http_url_to_ws_url(url: str) -> str:
    parsed = urlparse(url)
    scheme = "wss" if parsed.scheme == "https" else "ws"
    return urlunparse(parsed._replace(scheme=scheme))

def normalize_api_base(url: str) -> str:
    """Return the provided base URL as-is (minus a trailing slash).

    Important:
    - The CLI no longer appends '/api' automatically. Provide the full API base
      you want to use (for example, 'http://127.0.0.1:8000/api' in dev, or
      'https://henosis.us/api_v2' in production).
    - Query, fragment, and netloc are preserved; only a single trailing '/' is trimmed.
    """
    try:
        p = urlparse(url)
        # Trim a single trailing slash from the path (but keep root empty path)
        path = p.path or ""
        if path.endswith("/") and path != "/":
            path = path.rstrip("/")
        return urlunparse(p._replace(path=path))
    except Exception:
        # Fallback: simple right-strip of '/'
        return (url or "").rstrip("/")

def truncate_json(data: Any, max_chars: int = 500) -> str:
    try:
        s = json.dumps(data, ensure_ascii=False)
    except Exception:
        s = str(data)
    return (s[:max_chars] + "... (truncated)") if len(s) > max_chars else s

# --- debug flags controlled by CLI args (see amain) ---

async def parse_sse_lines(
    resp: httpx.Response,
    debug: Optional[Callable[[str], None]] = None,
) -> AsyncIterator[Tuple[str, str]]:
    """
    Robust SSE parser using aiter_lines(), compliant with the EventSource format.
    - Aggregates multiple data: lines per event block.
    - Handles LF and CRLF newlines naturally via httpx's line iterator.
    - Defaults to event name 'message' when 'event:' is omitted.
    - Flushes on blank line and at EOF.

    Also supports servers that place the logical event name inside the JSON payload
    (e.g., {"event":"message.delta"}) by mapping that onto the SSE event name when
    the SSE 'event:' field is missing.
    """
    event_name: Optional[str] = None
    data_lines: List[str] = []

    async for raw_line in resp.aiter_lines():
        if raw_line is None:
            # httpx may yield None for keep-alives
            continue
        line = raw_line.rstrip("\r\n")
        try:
            if debug is not None:
                # Show/log raw SSE line for deep debugging or raw file capture
                debug(f"sse.raw: {line!r}")
        except Exception:
            pass
        if line == "":
            # End of one SSE event block
            if data_lines:
                name = event_name or "message"
                payload = "\n".join(data_lines)
                # Best-effort: if name is the generic default and the JSON payload encodes an event/type,
                # prefer that so downstream handlers (message.delta, tool.*, etc.) keep working even
                # if a proxy stripped 'event:' headers.
                try:
                    j = json.loads(payload)
                    if isinstance(j, dict) and name in (None, "message"):
                        alt = j.get("event") or j.get("type") or j.get("evt")
                        if isinstance(alt, str) and alt.strip():
                            name = alt.strip()
                except Exception:
                    pass
                try:
                    if debug is not None:
                        debug(f"sse.emit: event={name} bytes={len(payload)}")
                except Exception:
                    pass
                yield name, payload
            # Reset for next block
            event_name = None
            data_lines = []
            continue
        if line.startswith(":"):
            # Comment/heartbeat line; ignore
            continue
        if line.startswith("event:"):
            event_name = line[len("event:") :].strip()
            continue
        if line.startswith("data:"):
            data_lines.append(line[len("data:") :].lstrip())
            continue
        # Ignore other fields (id:, retry:) for now

    # EOF: flush any pending block
    if data_lines:
        name = event_name or "message"
        payload = "\n".join(data_lines)
        try:
            j = json.loads(payload)
            if isinstance(j, dict) and name in (None, "message"):
                alt = j.get("event") or j.get("type") or j.get("evt")
                if isinstance(alt, str) and alt.strip():
                    name = alt.strip()
        except Exception:
            pass
        try:
            if debug is not None:
                debug(f"sse.emit(eof): event={name} bytes={len(payload)}")
        except Exception:
            pass
        yield name, payload

class UI:
    def __init__(self, verbose: bool = False) -> None:
        self.rich = HAS_RICH
        self.console = Console(force_terminal=True) if HAS_RICH else None
        # Verbosity: when False, suppress most 'dim' logs and developer chatter
        self.verbose = bool(verbose)
        # Lightweight debug sink for rendering issues
        try:
            self._debug_log_path = Path("cli_logs.txt").resolve()
        except Exception:
            self._debug_log_path = None
        # Theme colors
        self.theme = {
            "title": "bold white",
            # Primary accent -> orange
            "subtitle": "bold orange1",
            "label": "bold",
            "ok": "green",
            "err": "bold red",
            "warn": "yellow",
            # Use orange as primary accent for informational lines as well
            "info": "orange1",
            # Assistant stream color -> lighter gray than dim/debug text.
            "assistant": "grey70",
            # Tool call accent -> orange
            "tool_call": "orange1",
            "tool_result": "green",
            "tool_result_err": "red",
            "dim": "grey62",
        }

    def debug_log(self, msg: str) -> None:
        """Append a timestamped line to cli_logs.txt for offline debugging.
        Never raises; disabled if filesystem unavailable.
        """
        try:
            ts = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
            line = f"[{ts}] {msg}\n"
            if self._debug_log_path is not None:
                with open(self._debug_log_path, "a", encoding="utf-8") as f:
                    f.write(line)
        except Exception:
            pass

    def clear(self) -> None:
        os.system("cls" if os.name == "nt" else "clear")

    def header(self, title: str, subtitle: Optional[str] = None) -> None:
        if self.rich:
            text = Text(title, style=self.theme["title"])
            if subtitle:
                text.append(f"\n{subtitle}", style=self.theme["subtitle"])
            self.console.print(Panel(text, border_style=self.theme["subtitle"]))
        else:
            print("\n" + "=" * 80)
            print(title)
            if subtitle:
                print(subtitle)
            print("=" * 80)

    def header_inline(self, left: str, right: Optional[str] = None) -> None:
        """Render a single-line header with left text and optional right-aligned text.
        Uses a Panel when rich is available; falls back to ASCII alignment otherwise.
        """
        if self.rich and Panel and Table and Text:
            try:
                grid = Table.grid(expand=True)
                grid.add_column(justify="left")
                grid.add_column(justify="right")
                left_text = Text(str(left), style=self.theme["title"]) if left is not None else Text("")
                right_text = Text(str(right), style=self.theme["subtitle"]) if (right is not None and str(right).strip()) else Text("")
                grid.add_row(left_text, right_text)
                self.console.print(Panel(grid, border_style=self.theme["subtitle"]))
                return
            except Exception:
                pass
        # ASCII fallback
        try:
            width = shutil.get_terminal_size(fallback=(80, 20)).columns
        except Exception:
            width = 80
        if width < 20:
            width = 80
        left_str = str(left) if left is not None else ""
        right_str = str(right) if (right is not None and str(right).strip()) else ""
        # Compute available space for right segment
        avail = max(1, width - len(left_str))
        if right_str:
            # Trim right segment if it would exceed available space
            if len(right_str) > avail:
                right_str = right_str[:avail]
            line = left_str + right_str.rjust(avail)
        else:
            line = left_str
        print("\n" + ("=" * width))
        print(line)
        print("=" * width)

    def info(self, msg: str) -> None:
        if self.rich:
            self.console.print(f"[{self.theme['info']}]{msg}[/{self.theme['info']}]")
        else:
            print(msg)

    def warn(self, msg: str) -> None:
        if self.rich:
            self.console.print(f"[{self.theme['warn']}]! {msg}[/{self.theme['warn']}]")
        else:
            print(f"! {msg}")

    def error(self, msg: str) -> None:
        if self.rich:
            self.console.print(f"[{self.theme['err']}]✖ {msg}[/{self.theme['err']}]")
        else:
            print(f"ERROR: {msg}")

    def success(self, msg: str) -> None:
        if self.rich:
            self.console.print(f"[{self.theme['ok']}]✔ {msg}[/{self.theme['ok']}]")
        else:
            print(f"OK: {msg}")

    def print(self, msg: str = "", style: Optional[str] = None, end: str = "\n", force: bool = False) -> None:
        # Squelch most dim/debug output when not verbose, unless force=True
        if not self.verbose and not force:
            try:
                # If caller explicitly styles as 'dim', suppress
                if style == self.theme.get("dim"):
                    return
                # Suppress only when the ENTIRE line is dim-wrapped.
                # Do NOT suppress lines that include dim segments (e.g., context bars) mixed with normal text.
                if self.rich and isinstance(msg, str):
                    dim_tag = f"[{self.theme.get('dim')}]"
                    dim_close = f"[/{self.theme.get('dim')}]"
                    txt = msg.strip()
                    if txt.startswith(dim_tag) and txt.endswith(dim_close):
                        # Fully-dim line -> suppress when not verbose
                        return
            except Exception:
                pass
        # Best-effort: strip all simple [color]...[/color] tokens and apply the first seen as line style.
        # This avoids literal wrapper leakage when markup=False and multiple tags are present (e.g., [bold red] + [red]).
        try:
            # Strip our theme-based markup tokens even when Rich isn't available,
            # so wrappers never leak to plain terminals.
            if isinstance(msg, str) and style is None:
                first_style: Optional[str] = None
                earliest_idx: Optional[int] = None
                for _k, _color in (self.theme or {}).items():
                    if not isinstance(_color, str) or not _color:
                        continue
                    open_tag = f"[{_color}]"
                    close_tag = f"[/{_color}]"
                    # Track earliest occurrence to pick a reasonable dominant style for the line
                    try:
                        idx = msg.find(open_tag)
                        if idx != -1 and (earliest_idx is None or idx < earliest_idx):
                            earliest_idx = idx
                            first_style = _color
                    except Exception:
                        pass
                    # Remove all occurrences of these tokens regardless of order
                    if open_tag in msg:
                        msg = msg.replace(open_tag, "")
                    if close_tag in msg:
                        msg = msg.replace(close_tag, "")
                if first_style:
                    style = first_style
        except Exception:
            pass
        # Special fast-path for streaming assistant tokens on older rich versions that ignore end=""
        try:
            if end == "" and style and isinstance(style, str) and style == self.theme.get("assistant"):
                # Emit using ANSI 256-color gray and reset each chunk to avoid bleed
                s = str(msg)
                GRAY_ANSI = "\x1b[38;5;245m"
                RESET = "\x1b[0m"
                try:
                    sys.stdout.write(GRAY_ANSI + s + RESET)
                    sys.stdout.flush()
                    return
                except Exception:
                    # Last resort: plain write without color
                    try:
                        sys.stdout.write(s)
                        sys.stdout.flush()
                        return
                    except Exception:
                        pass
        except Exception:
            pass

        if self.rich:
            # Ensure immediate display during streaming by flushing each write.
            # IMPORTANT: disable Rich markup parsing so arbitrary model text like
            # "[tag]" or unmatched brackets doesn't raise MarkupError mid-stream.
            # We still apply the outer style via the style= param.
            try:
                self.console.print(
                    msg,
                    style=style,
                    end=end,
                    highlight=False,
                    soft_wrap=True,
                    markup=False,
                    flush=True,
                )
            except TypeError:
                # Older rich versions may not support some kwargs; degrade gracefully.
                try:
                    self.console.print(
                        msg,
                        style=style,
                        end=end,
                        highlight=False,
                        markup=False,
                    )
                    # Best-effort flush of the underlying file
                    try:
                        self.console.file.flush()
                    except Exception:
                        pass
                except Exception:
                    # Last-resort: print as Text to avoid markup parsing entirely
                    try:
                        from rich.text import Text as _Text
                        self.console.print(_Text(str(msg)), style=style, end=end)
                        try:
                            self.console.file.flush()
                        except Exception:
                            pass
                    except Exception:
                        # Give up on rich; fall back to plain print
                        print(str(msg), end=end, flush=True)
        else:
            print(msg, end=end, flush=True)

    # Raw stream writers used for high-fidelity token streaming without any wrapping/styling
    def write_raw(self, s: str) -> None:
        try:
            sys.stdout.write(str(s))
            sys.stdout.flush()
        except Exception:
            try:
                print(str(s), end="", flush=True)
            except Exception:
                pass

    def write_assistant_raw(self, s: str) -> None:
        """Write assistant stream text directly to stdout.

        This bypasses the generic print path so transient line-clearing logic and
        dim-style suppression can never hide streamed assistant output.
        """
        text = str(s)
        try:
            # Match the richer assistant gray used in non-raw styled paths.
            GRAY_ANSI = "\x1b[38;5;250m"
            RESET = "\x1b[0m"
            sys.stdout.write(GRAY_ANSI + text + RESET)
            sys.stdout.flush()
            return
        except Exception:
            pass
        self.write_raw(text)

    def write_assistant_header_raw(self, s: str) -> None:
        """Write the streamed assistant model prefix using the tool-call accent."""
        text = str(s)
        try:
            self.print(text, style=self.theme.get("tool_call"), end="", force=True)
            return
        except Exception:
            pass
        self.write_raw(text)

    def writeln_raw(self, s: str = "") -> None:
        try:
            sys.stdout.write(str(s) + "\n")
            sys.stdout.flush()
        except Exception:
            try:
                print(str(s))
            except Exception:
                pass

    def info_box(self, title: str, lines: List[str]) -> None:
        """Render a list of lines inside an outlined box. Uses rich Panel when available,
        otherwise falls back to a simple ASCII box.
        """
        try:
            text = "\n".join([str(x) for x in lines])
        except Exception:
            text = "\n".join([str(x) for x in lines])
        if self.rich and Panel:
            try:
                self.console.print(Panel(text, title=title, border_style=self.theme["subtitle"]))
                return
            except Exception:
                pass
        # ASCII fallback
        try:
            content_lines = [title] + lines if title else lines
            width = max((len(l) for l in content_lines), default=0) + 2
            border_top = "+" + ("-" * width) + "+"
            print(border_top)
            if title:
                print("| " + title.ljust(width - 1) + "|")
                print("|" + ("-" * width) + "|")
            for ln in lines:
                print("| " + str(ln).ljust(width - 1) + "|")
            print(border_top)
        except Exception:
            # Last resort: plain print
            print(title)
            print("\n".join(lines))

    def prompt(self, message: str, default: Optional[str] = None) -> str:
        if self.rich and Prompt:
            return Prompt.ask(message, default=default) if default is not None else Prompt.ask(message)
        else:
            inp = input(f"{message}{f' [{default}]' if default else ''}: ")
            if inp.strip():
                return inp
            return default or ""

    def confirm(self, message: str, default: bool = True) -> bool:
        if self.rich and Confirm:
            return Confirm.ask(message, default=default)
        else:
            suffix = "Y/n" if default else "y/N"
            val = input(f"{message} ({suffix}): ").strip().lower()
            if val == "" and default:
                return True
            if val in ("y", "yes", "1", "true", "t"):
                return True
            return False

    def ensure_newline(self, text_so_far: str) -> None:
        if text_so_far and not text_so_far.endswith("\n"):
            self.print()

    def table(self, title: str, rows: List[Tuple[str, str, str]]) -> None:
        if self.rich and Table:
            t = Table(title=title, show_lines=False, header_style=self.theme["subtitle"])
            t.add_column("Name")
            t.add_column("Type")
            t.add_column("Size")
            for r in rows:  # Assuming rows is List[Tuple[str, str, str]]
                t.add_row(*r)
            self.console.print(t)
        else:
            print(title)
            print("-" * len(title))
            for n, ty, sz in rows:
                print(f"{n:<40} {ty:<8} {sz}")

class ChatCLI:
    def __init__(
        self,
        server: str,
        model: Optional[str],
        system_prompt: Optional[str],
        timeout: Optional[float],
        map_prefix: Optional[bool] = None,
        log_enabled: bool = True,
        log_dir: Optional[str] = None,
        ctx_window: Optional[int] = None,
        save_to_threads: bool = True,
        server_usage_commit: bool = True,
        title: Optional[str] = None,
        verbose: bool = False,
        # Raw log capture
        raw_log: bool = False,
        raw_log_file: Optional[str] = None,
        # Agent Mode flags
        agent_mode: bool = False,
        agent_host: str = "127.0.0.1",
        agent_port: int = 8700,
        agent_allow_remote: bool = False,
        # Multi-terminal sandboxing
        workspace_dir: Optional[str] = None,
        terminal_id: Optional[str] = None,
        # Agent scope explicit override for this session
        agent_scope: Optional[str] = None,
    ):
        self.ui = UI(verbose=verbose)
        # Version tracking for display and update hints
        self._cli_version: Optional[str] = None
        self._latest_version: Optional[str] = None
        self._version_outdated: Optional[bool] = None
        # Resolve server base, honoring --dev shortcut
        self.server = server
        self.model = self._resolve_model_alias(model)
        self.system_prompt = system_prompt
        self.timeout = timeout

        # Session settings
        self.requested_tools: Optional[bool] = None  # None=server default, True=on, False=off
        self.fs_scope: Optional[str] = None          # None=server default, "workspace" or "host"
        self.host_base: Optional[str] = None         # Absolute path, used when fs_scope="host"
        # Host filesystem mode (client-side governance): any | cwd | custom
        self.fs_host_mode: Optional[str] = None
        # Whether host_base should be persisted to server settings (False for auto per-terminal binding)
        self._host_base_ephemeral: bool = False
        # History is always enabled; toggle feature removed. Kept for compatibility in UI strings.
        self.history_enabled: bool = True
        self.control_level: Optional[int] = None     # 1|2|3; None=server default
        self.auto_approve: List[str] = []           # Tool names to auto-approve at L2
        # Trust registries for Level 2 client-side approvals
        self.trust_tools_always: List[str] = []
        self.trust_tools_session: List[str] = []
        self.trust_cmds_always: List[str] = []
        self.trust_cmds_session: List[str] = []
        # Last approval-time error captured by _approval_prompt_ui (used to
        # convert approval failure into a tool error instead of "user denied").
        self._last_approval_error: Optional[str] = None
        # OpenAI web search controls
        self.web_search_enabled: bool = False
        self.web_search_allowed_domains: List[str] = []
        self.web_search_include_sources: bool = False
        self.web_search_location: Dict[str, str] = {}

        # Conversation history
        self.history: List[Dict[str, str]] = []
        if self.system_prompt:
            self.history.append({"role": "system", "content": self.system_prompt})

        # Input history (Up/Down arrow recall in the low-level input engine).
        # We keep a local, in-memory list for the session and persist ONLY the
        # last user input via server settings (Issue #14).
        self.last_user_input: str = ""
        self._user_input_history: List[str] = []

        # Use the base URL as provided (minus trailing slash). No automatic '/api' is appended.
        # For dev, provide a base ending with '/api' (e.g., http://127.0.0.1:8000/api).
        self.api_base = normalize_api_base(self.server)

        # Primary adapter endpoints: mimic auth base paths
        # Use the same base as auth (no automatic /v0 prefix). Keep /v0 variants as fallbacks.
        self.stream_url = join_url(self.api_base, "/chat/stream")
        self.stream_url_alt = join_url(self.api_base, "/v0/chat/stream")
        self.approvals_url = join_url(self.api_base, "/approvals")
        self.tools_callback_url = join_url(self.api_base, "/tools/callback")
        # Auth endpoints
        self.login_url = join_url(self.api_base, "/login")
        self.logout_url = join_url(self.api_base, "/logout")
        self.check_auth_url = join_url(self.api_base, "/check-auth")
        self.refresh_url = join_url(self.api_base, "/refresh")
        # CLI settings endpoints (server persistence)
        self.cli_settings_url = join_url(self.api_base, "/cli/settings")
        # Registration endpoints (optional on server)
        self.register_url = join_url(self.api_base, "/register")
        self.verify_email_url = join_url(self.api_base, "/verify_email")

        # Debug: log resolved core endpoints for quick diagnosis of base/path issues
        try:
            self.ui.debug_log(
                "[endpoints-cli] base="
                + self.api_base
                + f" | stream={self.stream_url} | stream_alt={self.stream_url_alt} | approvals={self.approvals_url} | tools_cb={self.tools_callback_url}"
            )
        except Exception:
            pass

        # Tool display toggles
        self.show_tool_calls: bool = True
        self.max_dir_items: int = 12  # show up to N items for list_dir

        # Settings persistence (legacy local file for fallback only)
        self.settings_file = Path.home() / ".henosis_cli_settings.json"
        self._settings_migrated = False  # if we load from legacy name on first run
        # Default: inject codebase map once at session start
        self.inject_codebase_map: bool = True
        # New (Issue #12): inject AGENTS.md instructions once at session start.
        # This is intentionally independent of the code map toggle (/map on|off).
        self.inject_agents_md: bool = True
        # Optional override for the packaged/default AGENTS.md content (editable in settings).
        self.agents_md_text: str = ""
        # When a local host_base/AGENTS.md exists and differs from the default, how to combine:
        # - "prepend_default": default + local
        # - "local_only": local only
        # - None: not chosen yet (we prompt once during configuration flows)
        self.agents_prepend_mode: Optional[str] = None
        # Preflight estimator removed from UX; keep flag for settings compatibility (default OFF)
        self.preflight_enabled: bool = False
        # Optional local-only preferences from onboarding
        self.telemetry_enabled: Optional[bool] = None
        self.output_format: Optional[str] = None  # e.g. plain|markdown
        # Usage & Info box rendering mode: 'concise' | 'verbose'
        # - concise: only model (+thinking level when applicable) and context meter
        # - verbose: full details (current behavior)
        self.usage_info_mode: str = "verbose"
        # Issue #15: manually configurable status fields for the post-turn Usage & Info output.
        # - When status_fields is None: follow the selected preset (usage_info_mode).
        # - When status_fields is a list: render exactly those fields in that order.
        self.status_fields: Optional[List[str]] = None
        # Layout for the post-turn status output:
        # - None: follow preset (concise -> line, verbose -> panel)
        # - "line": render as a single wrapped line
        # - "panel": render as a multi-line info box
        self.status_layout: Optional[str] = None
        # Track the last server-issued session id (available after session.started)
        self._last_session_id: Optional[str] = None
        # Track the most recent server-authoritative level from stream events.
        # This is a fallback when local control level is left as server default.
        self._last_server_level: Optional[int] = None
        # Per-server-session level cache so late tool/approval events can still
        # resolve against the level that started that stream.
        self._session_level_by_id: Dict[str, int] = {}
        # Git branch cache for status fields (computed from current working directory)
        self._git_branch_cache: Dict[str, Any] = {"cwd": None, "branch": None, "ts": 0.0}
        # Reasoning effort selector for OpenAI reasoning models (low|medium|high|xhigh). Default: medium
        # Note: 'xhigh' is only applied by the server for models that support it (e.g., gpt-5.4* and gpt-5.1-codex-max).
        self.reasoning_effort: str = "medium"
        # OpenAI/Codex priority processing. None means default tier.
        self.service_tier: Optional[str] = None
        # Retain provider-native tool/thinking/toolchain state across turns (always ON)
        self.retain_native_tool_results: bool = True
        # Anthropic thinking-mode budget tokens (applies to '-thinking' models; None = server default)
        self.thinking_budget_tokens: Optional[int] = None
        # Optional provider thinking insight display (off by default).
        self.thinking_insight_enabled: bool = False
        # OpenAI reasoning summary verbosity when thinking insight is enabled.
        # Values follow Responses API: auto | concise | detailed.
        self.thinking_insight_summary: str = "auto"
        # Anthropic effort (Opus 4.6/4.5/Sonnet 4.6): low|medium|high|max. Default: high.
        self.anthropic_effort: str = "high"
        # Anthropic prompt cache TTL preference: None=server default, or "5m" | "1h"
        self.anthropic_cache_ttl: Optional[str] = None
        # Optional per-request near-full handoff cutoff override (None = server default).
        self.context_near_full_pct: Optional[float] = None
        # Text verbosity selector (UI only; not sent to server requests by default)
        self.text_verbosity: str = "medium"  # low | medium | high
        # Tool call preambles (UI toggle only)
        self.preambles_enabled: bool = False
        # Codex developer prompt injection (system) for Codex models only
        self.codex_prompt_enabled: bool = True
        # Custom first-turn injection (like codebase map) — toggle + editable text
        self.custom_first_turn_enabled: bool = False
        self.custom_first_turn_text: str = ""
        # Load local settings as initial defaults; will sync with server after auth
        self.load_settings()
        self._apply_model_side_effects()

        # After loading settings, bind Agent scope per terminal instance by default.
        # Priority: explicit CLI flag/env > previously saved settings > CWD
        try:
            # Determine current working directory as a safe default
            _cwd_default = str(Path(os.getcwd()).resolve())
        except Exception:
            _cwd_default = None
        try:
            # If an explicit agent scope was provided via CLI or env, honor it and persistable
            # Otherwise, force a per-terminal default to CWD without persisting to server settings.
            explicit_scope = None
            # A later assignment from amain passes args via constructor namespace; detect via introspection
            # Fallback to environment variable already parsed in build_arg_parser
        except Exception:
            explicit_scope = None
        # The constructor receives no direct args reference; infer from environment variable for explicit
        # Prefer constructor param over env override
        if agent_scope and str(agent_scope).strip():
            explicit_scope = agent_scope
        else:
            explicit_scope = os.getenv("HENOSIS_AGENT_SCOPE") or explicit_scope
        # If host_base was loaded from settings and no explicit override requested, prefer CWD for this session
        try:
            if explicit_scope and str(explicit_scope).strip():
                self.host_base = str(Path(explicit_scope).expanduser().resolve())
                self._host_base_ephemeral = False
            elif _cwd_default:
                self.host_base = _cwd_default
                # Mark as ephemeral so we don't persist per-terminal default to server settings
                self._host_base_ephemeral = True
        except Exception:
            # Leave host_base as-is on failure
            pass

        # Prefer host scope by default when an Agent scope is bound
        try:
            if self.host_base and not self.fs_scope:
                self.fs_scope = "host"
                # Constrain host operations to the bound root by default
                if not self.fs_host_mode:
                    self.fs_host_mode = "custom"
        except Exception:
            pass

        # Codebase map injection (hidden from CLI; wrapped for UIs to detect)
        self._codebase_map_raw: Optional[str] = self._load_codebase_map_raw()
        self._did_inject_codebase_map: bool = False
        self._did_inject_custom_first_turn: bool = False
        # AGENTS.md injection (hidden from CLI; always injected before the map on first turn)
        self._agents_default_raw: Optional[str] = self._load_agents_default_raw()
        self._did_inject_agents_md: bool = False
        # If CLI flag provided, override persisted/default
        if map_prefix is not None:
            self.inject_codebase_map = bool(map_prefix)

        # No manual per-message character limits; providers/server will enforce their own limits
        # Track last tool call args by call_id for troubleshooting failed results
        self._tool_args_by_call_id: Dict[str, Any] = {}
        # Working memory (context summarization) injection controls
        self._memory_paths_for_first_turn: List[str] = []
        self._did_inject_working_memory: bool = False
        # Track the exact user content sent to the server for the last turn
        # (includes code map injection on first turn when enabled)
        self._last_built_user_content: Optional[str] = None

        # Auth state (cookies kept in-memory for this process)
        self.cookies = httpx.Cookies()
        self.auth_user: Optional[str] = None
        # Persisted auth state path (optional "stay logged in" on this machine)
        self.auth_state_file = Path.home() / ".henosis_cli_auth.json"
        # Device identity for device-bound refresh tokens (stable per machine)
        self.device_id: Optional[str] = None
        self.device_name: str = f"{socket.gethostname()} cli"

        # Local Codex OAuth state (never sent to Henosis backend).
        self.codex_auth_file = Path.home() / ".henosis_cli_codex_auth.json"
        self.codex_shared_auth_file = Path.home() / ".codex" / "auth.json"
        self.codex_authorize_url = "https://auth.openai.com/oauth/authorize"
        self.codex_token_url = "https://auth.openai.com/oauth/token"
        self.codex_responses_url = "https://chatgpt.com/backend-api/codex/responses"
        # Match the official Codex/OpenClaw OAuth client by default.
        self.codex_oauth_client_id = os.getenv("HENOSIS_CODEX_CLIENT_ID", "app_EMoamEEZ73f0CkXaXp7hrann")
        self.codex_oauth_scope = "openid profile email offline_access"
        self.codex_oauth_callback_host = os.getenv("HENOSIS_CODEX_CALLBACK_HOST", "127.0.0.1").strip() or "127.0.0.1"
        try:
            self.codex_oauth_callback_port = int(os.getenv("HENOSIS_CODEX_CALLBACK_PORT", "1455") or 1455)
        except Exception:
            self.codex_oauth_callback_port = 1455
        cb_path = str(os.getenv("HENOSIS_CODEX_CALLBACK_PATH", "/auth/callback") or "/auth/callback").strip()
        if not cb_path.startswith("/"):
            cb_path = "/" + cb_path
        self.codex_oauth_callback_path = cb_path
        self.codex_route_all_openai_models = (
            os.getenv("HENOSIS_CODEX_ROUTE_ALL_OPENAI", "1").strip().lower()
            not in ("0", "false", "no", "off")
        )
        self.codex_model_allowlist = {
            "gpt-5.3-codex",
            "gpt-5-codex",
            "codex-mini-latest",
        }
        self.codex_access_token: Optional[str] = None
        self.codex_refresh_token: Optional[str] = None
        self.codex_token_type: str = "Bearer"
        self.codex_expiry_date: Optional[datetime] = None
        self.codex_account_id: Optional[str] = None
        self.codex_id_token: Optional[str] = None
        self.codex_last_refresh_at: Optional[datetime] = None
        self.codex_email: Optional[str] = None
        self._load_codex_auth_state_from_disk()
        if not self._has_codex_auth_material():
            self._import_codex_auth_json_if_present()

        # Logging + cost tracking (forced ON by default)
        self.log_enabled: bool = True if log_enabled is None else bool(log_enabled)
        self.log_dir = Path(log_dir or "logs").resolve()
        self.session_log_path: Optional[Path] = None
        self.ctx_window: Optional[int] = int(ctx_window) if isinstance(ctx_window, int) else None
        self.cumulative_cost_usd: float = 0.0
        # Server-authoritative cumulative cost (from /api/usage/commit responses)
        self.server_cumulative_cost_usd: float = 0.0
        # Track last client-side estimated cost for the most recent turn
        self._last_estimated_cost_usd: float = 0.0
        # Local cumulative token counters (fallback when server doesn't send cumulative usage)
        self._cum_input_tokens: int = 0
        self._cum_output_tokens: int = 0
        self._cum_total_tokens: int = 0
        # Track cumulative reasoning/thinking tokens (session-level)
        self._cum_reasoning_tokens: int = 0
        self._session_local_id: str = uuid.uuid4().hex
        # Subscription/tier awareness (populated from /profile when available)
        self.subscription_tier: Optional[str] = None
        self.subscription_status: Optional[str] = None
        self.is_free_tier: Optional[bool] = None  # None = unknown, True/False when profile loaded
        # Per-terminal identity and workspace root. Default to the terminal's CWD as the root.
        try:
            self.terminal_id: str = (terminal_id or os.getenv("HENOSIS_TERMINAL_ID") or uuid.uuid4().hex)
        except Exception:
            self.terminal_id = uuid.uuid4().hex
        try:
            cwd_path = Path(os.getcwd()).resolve()
        except Exception:
            cwd_path = Path(".").resolve()
        try:
            # Resolve workspace directory preference/override; default to CWD
            ws_override = workspace_dir or os.getenv("HENOSIS_WORKSPACE_DIR")
            if ws_override and str(ws_override).strip():
                ws_base = Path(ws_override).expanduser().resolve()
            else:
                ws_base = cwd_path
            # Do not create a dedicated per-terminal subfolder; operate directly in the chosen root
            if not ws_base.exists():
                # If the provided override path does not exist, create it to avoid surprises
                ws_base.mkdir(parents=True, exist_ok=True)
            self.local_workspace_dir: str = str(ws_base)
            # Hint to shared tool library for any defaults
            os.environ["HENOSIS_WORKSPACE_DIR"] = self.local_workspace_dir
        except Exception:
            # Fallback to current directory
            self.local_workspace_dir = str(cwd_path)

        # Raw request/response logging to file in CWD (opt-in)
        def _env_true(name: str) -> bool:
            val = os.getenv(name, "").strip().lower()
            return val in ("1", "true", "yes", "on")
        try:
            self.raw_log_enabled: bool = bool(raw_log) or _env_true("HENOSIS_RAW_LOG")
        except Exception:
            self.raw_log_enabled = bool(raw_log)
        try:
            self.raw_log_path: Optional[Path] = (Path(raw_log_file).expanduser().resolve() if (raw_log_file and str(raw_log_file).strip()) else None)
        except Exception:
            self.raw_log_path = None
        self._rawlog_initialized: bool = False

        # Server-side thread save
        # Force saving to threads by default
        self.save_chat_history: bool = True if save_to_threads is None else bool(save_to_threads)
        self.thread_uid: Optional[str] = None
        self._manual_title: bool = bool(title)
        self.thread_name: str = title or self._default_thread_name()
        self.messages_for_save: List[Dict[str, Any]] = []
        self.create_thread_url = join_url(self.api_base, "/create_thread")
        self.save_convo_url = join_url(self.api_base, "/save_conversation")
        # Server-side usage commit (optional)
        # Force committing usage by default
        self.server_usage_commit: bool = True if server_usage_commit is None else bool(server_usage_commit)
        self.commit_usage_url = join_url(self.api_base, "/usage/commit")
        
        # Remote Control / local WS bridge state
        self.agent_mode: bool = bool(agent_mode)
        self.agent_host: str = str(agent_host or "127.0.0.1")
        self.agent_port: int = int(agent_port or 8700)
        self.agent_allow_remote: bool = bool(agent_allow_remote)
        self._ws_server: Optional[Any] = None
        self._ws_client: Optional[Any] = None
        self._ws_client_lock = asyncio.Lock()
        self._remote_ws: Optional[Any] = None
        self._remote_ws_task: Optional[asyncio.Task] = None
        self._remote_ws_state_task: Optional[asyncio.Task] = None
        self._remote_ws_stop = asyncio.Event()
        self._busy: bool = False
        self._queued_user_messages: List[Dict[str, Any]] = []
        self._busy_input_task: Optional[asyncio.Task] = None
        self._busy_input_stop_event: Optional[threading.Event] = None
        self._busy_input_prefill: str = ""
        self._chat_input_prefill: str = ""
        # approvals: call_id -> Future[(approved: bool, note: Optional[str])]
        self._pending_approvals: Dict[str, asyncio.Future] = {}
        # Recovery helpers for provider 'string too long' errors
        self._tail_next_paths: set[str] = set()
        self._auto_retry_after_tailed: bool = False
        self._last_dispatch_ctx: Optional[Dict[str, Any]] = None
        # Track current in-progress turn so late WS connections can sync mid-conversation
        self._current_turn: Dict[str, Any] = {
            "active": False,
            "session_id": None,
            "model": None,
            "level": None,
            "assistant_so_far": "",
            "tool_events": [],  # list of {type: 'tool.call'|'tool.result', data: {...}}
            "user_message": None,
            "thinking_insight": None,
        }
        # Track last used model for display
        self._last_used_model: Optional[str] = None
        # Provider-native history for Kimi (preserve reasoning_content across turns)
        self._kimi_raw_history: List[Dict[str, Any]] = []
        # Provider-native history for Gemini (preserve thoughtSignatures + strict tool-call chains across turns)
        self._gemini_raw_history: List[Dict[str, Any]] = []
        # Provider-native history for Anthropic (preserve tool_use/tool_result blocks across turns)
        self._anthropic_raw_history: List[Dict[str, Any]] = []
        # OpenAI Responses API threading: retain previous response id across turns
        self._openai_previous_response_id: Optional[str] = None
        # OpenAI Responses API threading: retain the full chain of response ids across turns
        # (server will also echo per-turn ids in message.completed.openai_response_ids)
        self._openai_response_id_history: List[str] = []

        # OpenAI Responses API manual state (stateless/ZDR-safe): retain the full input item chain
        # including reasoning items, function_call items, and function_call_output items.
        self._openai_input_items: List[Dict[str, Any]] = []
        # For robustness, remember exactly what we sent as openai_input_items for the current turn
        # so we can append server-provided openai_delta_items deterministically.
        self._openai_last_sent_input_items: Optional[List[Dict[str, Any]]] = None
        # xAI Responses API manual state (stateless replay): retain full native input chain.
        self._xai_previous_response_id: Optional[str] = None
        self._xai_response_id_history: List[str] = []
        self._xai_input_items: List[Dict[str, Any]] = []
        self._xai_last_sent_input_items: Optional[List[Dict[str, Any]]] = None
        # Local Codex native replay state: retain tool call/output chain across turns.
        self._codex_local_input_items: List[Dict[str, Any]] = []
        self._codex_local_last_sent_input_items: Optional[List[Dict[str, Any]]] = None
        # Conversation-scoped override when the user chooses backend credits after a Codex limit.
        self._codex_force_backend_for_conversation: bool = False
        self._codex_backend_rollover_pending_seed: bool = False
        # Track an in-flight client-dispatched tool job so Ctrl+C can cancel it quickly.
        # Shape: {session_id, call_id, job_token, name}
        self._inflight_dispatch: Optional[Dict[str, Any]] = None
        # Last server billing info from /api/usage/commit
        self._last_commit_cost_usd: float = 0.0
        self._last_remaining_credits: Optional[float] = None
        self._last_commit_model: Optional[str] = None
        # Cache of model -> input context length (tokens) for context meter
        self._model_ctx_map: Optional[Dict[str, int]] = None
        # Fun thinking indicator word bank (for pre-response animation)
        # One word (chosen at random) is shown with a rainbow animation until first tokens arrive
        try:
            self._thinking_words: List[str] = [
                "thinking",
                "noodling",
                "vibing",
                "contemplating",
                "pondering",
                "brewing",
                "crunching",
                "weaving",
                "exploring",
                "daydreaming",
                # Added fun extras
                "tinkering",
                "brainstorming",
                "musing",
                "percolating",
                "riffing",
                "scheming",
                "ideating",
                "dreamweaving",
                "marinating",
                "cogitating",
            ]
        except Exception:
            self._thinking_words = ["thinking", "working..."]
        # Make rainbow thinking indicator 3x as wide by inserting spaces between letters
        try:
            self._thinking_rainbow_spacing: int = 3  # 3 => adds 2 spaces between characters
        except Exception:
            self._thinking_rainbow_spacing = 3
        # Thinking indicator (animated status while waiting for first tokens)
        # Enabled by default for better perceived responsiveness. Set
        # HENOSIS_THINKING_INDICATOR=0/false/no/off to disable.
        try:
            env_val = os.getenv("HENOSIS_THINKING_INDICATOR", "").strip().lower()
            if env_val in ("0", "false", "no", "off"):
                self._thinking_indicator_enabled = False
            else:
                self._thinking_indicator_enabled = True
        except Exception:
            self._thinking_indicator_enabled = True
        # Track Ctrl+C timing for double-press-to-exit behavior
        self._last_interrupt_ts: Optional[float] = None
        self._input_interrupt_event: Optional[threading.Event] = None

        # Ctrl+C cancel flag and partial-text accumulator for graceful stream cancel.
        # When _stream_cancelled is set, the SSE loop breaks early and the partial
        # assistant text is kept in context (no rollback, no edit mode).
        self._stream_cancelled: bool = False
        self._stream_partial_text: str = ""
        self._stream_force_exit: bool = False

        # Ctrl+C during a running stream should not kill the entire CLI.
        # Instead, we cancel the in-flight turn and reopen the last user query for editing.
        # Provider-native tool-chain context is preserved on cancel via _preserve_provider_state_on_cancel().
        self._pending_user_edit: Optional[str] = None
        self._pending_turn_snapshot: Optional[Dict[str, Any]] = None
        self._input_prompt_active: bool = False
        self._input_prompt_label: Optional[str] = None
        self._transient_tool_status_active: bool = False
        self._transient_tool_status_rows: int = 1
        self._transient_tool_status_gap_rows: int = 0
        self._remote_control_messages: List[Dict[str, Any]] = []
        self._remote_last_completed: Optional[Dict[str, Any]] = None

        # Timers: session-level and per-turn wall-clock timers
        self._session_started_at: Optional[float] = None  # time.perf_counter() at session start
        self._turn_started_at: Optional[float] = None     # time.perf_counter() at turn send
        self._last_turn_duration_secs: Optional[float] = None  # finalized turn duration for post-turn renders

        # Slash command catalog and enhanced input session
        self._commands_catalog: List[Dict[str, str]] = self._build_commands_catalog()
        # Low-level input engine (supports Shift+Enter newlines where possible)
        self._input_engine = make_engine() if HAS_INPUT_ENGINE else None
        # Seed engine history (best-effort; may be updated after settings load)
        try:
            if self._input_engine and hasattr(self._input_engine, "set_history"):
                self._input_engine.set_history(self._user_input_history)
        except Exception:
            pass
        # prompt_toolkit intentionally not used; always rely on the input engine.
        self._pt_session = None

    # ----------------------- Provider heuristics -----------------------
    def _is_openai_reasoning_model(self, model: Optional[str]) -> bool:
        """Return True when the model is an OpenAI reasoning-capable model.
        Mirrors server-side heuristic: prefixes 'gpt-5' or 'o4'.
        """
        try:
            if not model:
                return False
            m = str(model).lower().strip()
            return m.startswith("gpt-5") or m.startswith("o4")
        except Exception:
            return False

    # ----------------------- Update checker ----------------------------
    async def maybe_check_for_updates(self) -> None:
        """Check PyPI for a newer henosis-cli version and offer to update.

        Skips when:
        - HENOSIS_CLI_NO_UPDATE_CHECK=1
        - offline or PyPI unavailable (quietly)
        - current version cannot be determined
        """
        try:
            if os.getenv("HENOSIS_CLI_NO_UPDATE_CHECK", "").strip() in ("1", "true", "yes"):  # opt-out
                return
            # Resolve current version from installed metadata; fallback to pyproject when running from source
            pkg_candidates = ("henosis-cli",)
            # Determine current by trying the canonical package name first
            current = None
            picked_pkg = None
            for name in pkg_candidates:
                current = self._resolve_current_version(name)
                if current:
                    picked_pkg = name
                    break
            # If still not found, last resort: generic resolve without name
            if not current:
                current = self._resolve_current_version()
            # Persist for later display in UI boxes
            try:
                self._cli_version = current
            except Exception:
                pass
            if not current:
                return

            # Query PyPI for latest version
            latest = None
            try:
                timeout = httpx.Timeout(connect=2.0, read=3.0, write=2.0, pool=2.0) if self.timeout is None else httpx.Timeout(min(self.timeout, 5.0))
                async with httpx.AsyncClient(timeout=timeout) as client:
                    # Try each candidate name until one resolves
                    for name in (picked_pkg,) if picked_pkg else pkg_candidates:
                        url = f"https://pypi.org/pypi/{name}/json"
                        r = await client.get(url)
                        if r.status_code == 200 and r.headers.get("content-type", "").startswith("application/json"):
                            data = r.json()
                            info = data.get("info") or {}
                            ver = info.get("version")
                            if isinstance(ver, str) and ver.strip():
                                latest = ver.strip()
                                picked_pkg = name
                                break
            except Exception:
                latest = None
            if not latest:
                return
            # Persist latest for UI display
            try:
                self._latest_version = latest
            except Exception:
                pass

            # Compare versions (best-effort)
            def _newer(a: str, b: str) -> bool:
                # return True if b > a
                try:
                    from packaging.version import Version  # type: ignore
                    return Version(b) > Version(a)
                except Exception:
                    # Fallback: compare dotted integers, ignoring non-digits
                    def to_tuple(s: str):
                        parts = []
                        for p in s.split('.'):
                            try:
                                # strip non-digit suffix/prefix
                                num = ''.join(ch for ch in p if (ch.isdigit() or ch == '-'))
                                parts.append(int(num) if num not in ("", "-") else 0)
                            except Exception:
                                parts.append(0)
                        return tuple(parts)
                    return to_tuple(b) > to_tuple(a)

            is_outdated = _newer(current, latest)
            try:
                self._version_outdated = bool(is_outdated)
            except Exception:
                pass
            if not is_outdated:
                return

            # Inform user (no interactive Y/N and no in-CLI install attempt)
            # Use the actual package name in the upgrade instructions
            pkg = picked_pkg or "henosis-cli"
            self.ui.warn(f"A newer {pkg} is available: {current} -> {latest}")
            self.ui.print("Update from your shell:")
            self.ui.print(f"- pipx:    pipx upgrade {pkg}", style=self.ui.theme["dim"])  # type: ignore
            self.ui.print(f"- pip:     {os.path.basename(sys.executable)} -m pip install -U {pkg}", style=self.ui.theme["dim"])  # type: ignore
            return
        except SystemExit:
            raise
        except Exception:
            # Never block CLI start due to update checks
            return

    def _resolve_current_version(self, pkg_name: Optional[str] = None) -> Optional[str]:
        """Best-effort resolution of the current CLI version.
        Prefer importlib.metadata when installed; otherwise read local pyproject.toml.
        """
        try:
            # First, if a distribution name was provided, try that
            if pkg_name:
                try:
                    return importlib.metadata.version(pkg_name)
                except importlib.metadata.PackageNotFoundError:
                    pass
            # Try the canonical distribution name
            for name in ("henosis-cli",):
                try:
                    return importlib.metadata.version(name)
                except importlib.metadata.PackageNotFoundError:
                    continue
            # Fallback: read local pyproject.toml when running from source
            pp = Path(__file__).resolve().parent / "pyproject.toml"
            if pp.exists():
                # Robust TOML parse for project.version
                try:
                    import tomllib  # Python 3.11+
                except Exception:
                    tomllib = None
                if tomllib is not None:
                    try:
                        data = tomllib.loads(pp.read_text(encoding="utf-8", errors="ignore"))
                        proj = data.get("project") or {}
                        ver = proj.get("version")
                        if isinstance(ver, str) and ver.strip():
                            return ver.strip()
                    except Exception:
                        pass
                # Fallback naive scan
                txt = pp.read_text(encoding="utf-8", errors="ignore")
                for line in txt.splitlines():
                    ls = line.strip()
                    if ls.startswith("version") and "=" in ls:
                        val = ls.split("=", 1)[1].strip().strip('\"\'')
                        if val:
                            return val
        except Exception:
            return None
        return None

    async def check_server_version_compatibility(self) -> None:
        """Query the server /health for version info and warn on incompatibility.

        Expects keys: min_cli_version, latest_cli_version (optional), api_version (optional).
        Never blocks execution.
        """
        try:
            # Resolve health URL regardless of /api prefix handling in constructor
            health_url = join_url(self.server, "/health")
            timeout = httpx.Timeout(connect=3.0, read=3.0, write=3.0, pool=3.0) if self.timeout is None else httpx.Timeout(min(self.timeout, 5.0))
            async with httpx.AsyncClient(timeout=timeout, cookies=self.cookies) as client:
                r = await client.get(health_url)
                if r.status_code != 200:
                    return
                if not r.headers.get("content-type", "").startswith("application/json"):
                    return
                h = r.json()
                min_cli = h.get("min_cli_version")
                latest_cli = h.get("latest_cli_version") or h.get("recommended_cli_version")
                api_version = h.get("api_version") or h.get("version")
                # Determine current CLI version
                cur = self._cli_version or self._resolve_current_version()
                # Nothing to compare
                if not cur:
                    return
                # Compare using packaging when available
                def newer(a: str, b: str) -> bool:
                    try:
                        from packaging.version import Version
                        return Version(b) > Version(a)
                    except Exception:
                        return b != a
                def lower(a: str, b: str) -> bool:
                    try:
                        from packaging.version import Version
                        return Version(a) < Version(b)
                    except Exception:
                        return a != b
                if isinstance(min_cli, str) and min_cli.strip() and lower(cur, min_cli.strip()):
                    self.ui.warn(f"Your CLI v{cur} is older than server minimum v{min_cli}. Please update to avoid incompatibilities.")
                elif isinstance(latest_cli, str) and latest_cli.strip() and newer(cur, latest_cli.strip()):
                    # This case rarely happens (server recommends older), so ignore
                    pass
                elif isinstance(latest_cli, str) and latest_cli.strip() and lower(cur, latest_cli.strip()):
                    self.ui.print(
                        f"A newer CLI v{latest_cli} is recommended by the server (you have v{cur}).",
                        style=self.ui.theme.get("dim"),
                    )
                # Surface API version in a dim line for visibility
                if isinstance(api_version, str) and api_version.strip():
                    self.ui.print(f"Server API version: {api_version}", style=self.ui.theme.get("dim"))
        except Exception:
            return

    def _port_in_use(self, host: str, port: int) -> bool:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(0.25)
                return s.connect_ex((host, port)) == 0
        except Exception:
            return False

    def _find_free_port(self, host: str = "127.0.0.1", start: int = 8700, end: int = 8900) -> int:
        # Try range first
        for p in range(start, end + 1):
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                    s.bind((host, p))
                    return p
            except Exception:
                continue
        # Fallback: let OS pick ephemeral
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind((host, 0))
                return s.getsockname()[1]
        except Exception:
            return 0

    def _clip(self, s: Any, max_len: int = 300) -> str:
        s = str(s)
        return s if len(s) <= max_len else (s[: max_len//2] + " ... (truncated) ... " + s[- max_len//2 :])

    def _single_line(self, s: Any, max_len: Optional[int] = None) -> str:
        """Collapse arbitrary text into a single line; optionally enforce a hard max length."""
        try:
            out = str(s if s is not None else "")
        except Exception:
            out = ""
        try:
            out = out.replace("\r", " ").replace("\n", " ").replace("\t", " ")
            out = re.sub(r"\s+", " ", out).strip()
        except Exception:
            pass
        try:
            if isinstance(max_len, int) and max_len > 0 and len(out) > max_len:
                if max_len <= 3:
                    return "." * max(0, max_len)
                return out[: max_len - 3] + "..."
        except Exception:
            pass
        return out

    def _format_thinking_insight_text(self, s: Any, max_len: int = 1400) -> str:
        """Normalize provider thinking insight text for readable terminal display."""
        try:
            out = str(s if s is not None else "")
        except Exception:
            out = ""
        try:
            out = out.replace("\r\n", "\n").replace("\r", "\n")
            lines = [re.sub(r"\s+", " ", ln).strip() for ln in out.split("\n")]
            lines = [ln for ln in lines if ln]
            out = "\n".join(lines)
        except Exception:
            pass
        if not out:
            return ""
        return self._clip(out, int(max_len or 1400))

    # ----------------------- Cancel/usage helpers -----------------------
    def _rough_tokens_from_chars(self, chars: int) -> int:
        """Very rough token estimator used only when a stream is cancelled.

        We use ~4 chars/token as a fallback so we can display *some* token usage
        even when the server never emits message.completed (usage is then unavailable).
        """
        try:
            n = int(chars or 0)
        except Exception:
            n = 0
        if n <= 0:
            return 0
        # ceil(n/4)
        return (n + 3) // 4

    def _begin_turn_timer(self) -> Optional[float]:
        """Start wall-clock timing for a new user turn."""
        try:
            started = float(time.perf_counter())
        except Exception:
            started = None
        self._turn_started_at = started
        self._last_turn_duration_secs = None
        return started

    def _ensure_turn_timer_started(self) -> Optional[float]:
        """Ensure an in-flight turn has a timer without resetting retries/tool loops."""
        try:
            started = self._turn_started_at
        except Exception:
            started = None
        try:
            finalized = self._last_turn_duration_secs
        except Exception:
            finalized = None
        if isinstance(started, (int, float)) and not isinstance(finalized, (int, float)):
            return float(started)
        return self._begin_turn_timer()

    def _turn_elapsed_seconds(self, *, now: Optional[float] = None, finalize: bool = False) -> float:
        """Return current turn wall time, optionally freezing it for final status output."""
        try:
            cached = self._last_turn_duration_secs
        except Exception:
            cached = None
        if isinstance(cached, (int, float)):
            return max(0.0, float(cached))
        try:
            started = self._turn_started_at
        except Exception:
            started = None
        if not isinstance(started, (int, float)):
            return 0.0
        try:
            current = float(now) if isinstance(now, (int, float)) else float(time.perf_counter())
        except Exception:
            return 0.0
        elapsed = max(0.0, float(current) - float(started))
        if finalize:
            self._last_turn_duration_secs = float(elapsed)
        return float(elapsed)

    def _session_elapsed_seconds(self, *, now: Optional[float] = None) -> float:
        """Return session wall time."""
        try:
            started = self._session_started_at
        except Exception:
            started = None
        if not isinstance(started, (int, float)):
            return 0.0
        try:
            current = float(now) if isinstance(now, (int, float)) else float(time.perf_counter())
        except Exception:
            return 0.0
        return max(0.0, float(current) - float(started))

    def _render_cancelled_usage_notice(
        self,
        *,
        model_label: Optional[str],
        est_completion_chars: int,
        events_total: int = 0,
        deltas_total: int = 0,
        bytes_total: int = 0,
        tool_calls: int = 0,
        turn_secs: Optional[float] = None,
    ) -> None:
        """Print a small usage notice when Ctrl+C cancels mid-stream.

        The key requirement: do not show "0 tokens"/nothing when we know
        the model already emitted a tool.call or other output.
        """
        try:
            tok = self._rough_tokens_from_chars(int(est_completion_chars or 0))
        except Exception:
            tok = 0
        label = model_label or self._current_turn.get("model") or self._last_used_model or self.model or "(unknown)"
        # Always show something human-readable even if estimate is 0.
        # (0 can happen if cancel occurred before we received any delta/tool.call lines.)
        lines: List[str] = []
        if tok > 0:
            lines.append(f"Cancelled — estimated tokens used so far (completion/tool output): ~{tok}")
        else:
            lines.append("Cancelled — usage unavailable (no message.completed); no output received to estimate tokens")
        try:
            lines.append(f"Model: {label}")
        except Exception:
            pass
        try:
            parts = [f"events={int(events_total)}", f"deltas={int(deltas_total)}", f"bytes={int(bytes_total)}", f"tools={int(tool_calls)}"]
            lines.append("Stream: " + " | ".join(parts))
        except Exception:
            pass
        try:
            if isinstance(turn_secs, (int, float)) and turn_secs is not None:
                lines.append(f"Time (turn): {float(turn_secs):.2f}s")
        except Exception:
            pass

        try:
            # Match existing UX patterns: info box in verbose mode; single line in concise mode.
            if str(getattr(self, "usage_info_mode", "verbose")).lower() == "concise":
                # One-liner only
                self.ui.print(lines[0], style=self.ui.theme.get("warn"), force=True)  # type: ignore
            else:
                self.ui.info_box("Usage (cancelled)", lines)
        except Exception:
            # Last-resort plain prints
            try:
                self.ui.warn(lines[0])
                for ln in lines[1:]:
                    self.ui.print(ln)
            except Exception:
                pass

    # ----------------------- Pricing + costs -----------------------

    def _pricing_table(self) -> Dict[str, Dict[str, Any]]:
        # Match server chat_adapter PRICING_PER_MILLION (subset is fine; unknown -> 0)
        return {
            # OpenAI
            "gpt-5.4": {
                "input": 2.75,
                "output": 15.25,
                "cached_input": 0.25,
                "prompt_threshold_tokens": 272000,
                "input_high": 5.25,
                "cached_input_high": 0.50,
                "output_high": 22.75,
                "provider": "openai",
            },
            # New: gpt-5.3-codex
            # Pricing requested: input $2.00 / 1M, cached input $0.175 / 1M, output $14.25 / 1M
            "gpt-5.3-codex": {"input": 2.00, "output": 14.25, "cached_input": 0.175, "provider": "openai"},
            # From gpt5.4.txt: $30/$180 base, plus +$0.25 margin each -> $30.25/$180.25
            "gpt-5.4-pro": {
                "input": 30.25,
                "output": 180.25,
                "prompt_threshold_tokens": 272000,
                "input_high": 60.25,
                "output_high": 270.25,
                "provider": "openai",
            },
            "gpt-5": {"input": 1.75, "output": 14.00, "provider": "openai"},
            "gpt-5-2025-08-07": {"input": 1.75, "output": 14.00, "provider": "openai"},
            "gpt-5-codex": {"input": 1.75, "output": 14.00, "provider": "openai"},
            "gpt-5.4-mini-2026-03-17": {"input": 1.00, "output": 4.75, "cached_input": 0.075, "provider": "openai"},
            "gpt-5.4-nano-2026-03-17": {"input": 0.45, "output": 1.50, "cached_input": 0.02, "provider": "openai"},
            # Codex Mini (fine-tuned o4-mini for CLI). Pricing includes 1.4x margin per codex-mini.txt.
            # Cached input tokens override: $0.375 * 1.4 = $0.525 per 1M (25% of input rate).
            "codex-mini-latest": {"input": 2.10, "output": 8.40, "cached_input": 0.525, "provider": "openai"},
            # Anthropic
            "claude-sonnet-4-20250514": {"input": 4.20, "output": 21.00, "provider": "anthropic"},
            "claude-sonnet-4-20250514-thinking": {"input": 4.20, "output": 21.00, "provider": "anthropic"},
            "claude-sonnet-4-6": {"input": 4.20, "output": 21.00, "provider": "anthropic"},
            "claude-sonnet-4-6-thinking": {"input": 4.20, "output": 21.00, "provider": "anthropic"},
            # New Opus 4.6 (adaptive thinking + effort; 1M context)
            "claude-opus-4-6": {"input": 5.25, "output": 25.25, "provider": "anthropic"},
            "claude-opus-4-6-thinking": {"input": 5.25, "output": 25.25, "provider": "anthropic"},
            # Gemini
            # Gemini 3 Flash Preview (priced same as prior Gemini 2.5 Flash per request)
            "gemini-3-flash-preview": {"input": 0.21, "output": 0.84, "provider": "gemini"},
            # Gemini 3.1 Pro Preview ("newgem"). Base: $2/$12 and $4/$18 per 1M;
            # CLI uses the low-tier 1.4x margin rates for estimates. High-tier
            # pricing based on total_tokens > 200K is applied on the server.
            "gemini-3.1-pro-preview": {"input": 2.80, "output": 16.80, "provider": "gemini"},
            # xAI
            "grok-4-1-fast-reasoning": {"input": 0.28, "output": 0.70, "provider": "xai"},
            "grok-4-1-fast-non-reasoning": {"input": 0.28, "output": 0.70, "provider": "xai"},
            "grok-4.20-multi-agent-beta-0309": {"input": 2.25, "output": 6.25, "provider": "xai"},
            "grok-4.20-beta-0309-reasoning": {"input": 2.25, "output": 6.25, "provider": "xai"},
            "grok-4": {"input": 4.20, "output": 21.00, "provider": "xai"},
            "grok-code-fast-1": {"input": 0.28, "output": 2.10, "provider": "xai"},
            # DeepSeek V3.2 (+$0.25 per 1M margin)
            "deepseek-chat-3.2": {"input": 0.53, "output": 0.67, "provider": "deepseek"},
            "deepseek-reasoner-3.2": {"input": 0.53, "output": 0.67, "provider": "deepseek"},
            # Removed: deepseek speciale (not supported)
            # Kimi
            "kimi-k2.5": {"input": 0.85, "output": 3.25, "provider": "kimi"},
            # GLM (Z.AI)
            # Pricing with 1.4x margin applied (base: in $0.60, out $2.20)
            "glm-4.7": {"input": 0.84, "output": 3.08, "provider": "glm"},
        }

    def _resolve_price(self, model: Optional[str]) -> Dict[str, Any]:
        if not model:
            return {"input": 0.0, "output": 0.0, "provider": "unknown"}
        table = self._pricing_table()
        resolved = self._resolve_model_alias(model)
        if resolved in table:
            return table[resolved]
        if model in table:
            return table[model]
        # soft alias
        if model == "gpt-5":
            return table.get("gpt-5-2025-08-07", {"input": 0.0, "output": 0.0, "provider": "unknown"})
        return {"input": 0.0, "output": 0.0, "provider": "unknown"}

    def _openai_context_scaled_rates(self, price: Dict[str, Any], prompt_tokens: int) -> Tuple[float, Optional[float], float]:
        in_rate = float(price.get("input", 0.0) or 0.0)
        out_rate = float(price.get("output", 0.0) or 0.0)
        cached_rate: Optional[float] = None
        try:
            if price.get("cached_input", None) is not None:
                cached_rate = float(price.get("cached_input", 0.0) or 0.0)
        except Exception:
            cached_rate = None
        try:
            threshold = int(price.get("prompt_threshold_tokens", 0) or 0)
            if threshold > 0 and int(prompt_tokens or 0) > threshold:
                in_rate = float(price.get("input_high", in_rate) or in_rate)
                out_rate = float(price.get("output_high", out_rate) or out_rate)
                if price.get("cached_input_high", None) is not None:
                    cached_rate = float(price.get("cached_input_high", cached_rate if cached_rate is not None else 0.0) or 0.0)
        except Exception:
            pass
        return in_rate, cached_rate, out_rate

    def _resolve_model_alias(self, raw_name: Optional[str]) -> Optional[str]:
        """Normalize model aliases to their canonical server identifiers."""
        if not raw_name:
            return None
        name = raw_name.strip()
        lower = name.lower()
        for old, new in (("gpt-5.2-pro", "gpt-5.4-pro"), ("gpt-5.2", "gpt-5.4")):
            if lower == old:
                return new
            if lower.startswith(old + "-"):
                return new + name[len(old):]
        aliases = {
            "gpt-4o-mini": "gpt-5.4-mini-2026-03-17",
            "gpt-4.1-mini": "gpt-5.4-mini-2026-03-17",
            "gpt-5.1-mini": "gpt-5.4-mini-2026-03-17",
            "gpt-5-mini": "gpt-5.4-mini-2026-03-17",
            "gpt-5-mini-2025-08-07": "gpt-5.4-mini-2026-03-17",
            "gpt-5.4-mini": "gpt-5.4-mini-2026-03-17",
            "gpt5.4-mini": "gpt-5.4-mini-2026-03-17",
            "gpt-4.1-nano": "gpt-5.4-nano-2026-03-17",
            "gpt-5-nano": "gpt-5.4-nano-2026-03-17",
            "gpt-5-nano-2025-08-07": "gpt-5.4-nano-2026-03-17",
            "gpt-5.4-nano": "gpt-5.4-nano-2026-03-17",
            "gpt5.4-nano": "gpt-5.4-nano-2026-03-17",
            "gemini-3": "gemini-3.1-pro-preview",
            "gemini-3-pro": "gemini-3.1-pro-preview",
            "gemini-3-preview": "gemini-3.1-pro-preview",
            "gemini-3-flash": "gemini-3-flash-preview",
            "gemini-flash-3": "gemini-3-flash-preview",
            "gemini-new": "gemini-3.1-pro-preview",
            "new-gemini": "gemini-3.1-pro-preview",
            "gemini-pro-3": "gemini-3.1-pro-preview",
            # Migrate old Gemini 3 Pro slug to the new 3.1 slug.
            "gemini-3-pro-preview": "gemini-3.1-pro-preview",
            "gemini-3.1-pro": "gemini-3.1-pro-preview",
            "gpt5": "gpt-5",
            "gpt5.4": "gpt-5.4",
            "gpt5.4-pro": "gpt-5.4-pro",
            "gpt4": "gpt-4o",
            # Anthropic Claude Opus 4.6 short aliases
            "claude-opus-4-6": "claude-opus-4-6",
            "claude-opus-4.6": "claude-opus-4-6",
            "opus-4-6": "claude-opus-4-6",
            "opus-4.6": "claude-opus-4-6",
            "opus46": "claude-opus-4-6",
            "claude-opus46": "claude-opus-4-6",
            # Anthropic Claude Sonnet 4.6 short aliases
            "claude-sonnet-4-6": "claude-sonnet-4-6",
            "claude-sonnet-4.6": "claude-sonnet-4-6",
            "sonnet-4-6": "claude-sonnet-4-6",
            "sonnet-4.6": "claude-sonnet-4-6",
            "sonnet46": "claude-sonnet-4-6",
            "claude-sonnet46": "claude-sonnet-4-6",
        }
        return aliases.get(lower, name)

    def _apply_model_side_effects(self) -> None:
        """Adjust related settings when certain models are selected."""
        try:
            model_name = str(self._resolve_model_alias(self.model) or "").strip().lower()
        except Exception:
            model_name = ""
        try:
            # Provider-native state resets when switching away from OpenAI.
            try:
                if self.model and (not self._is_openai_model(self.model)):
                    self._openai_previous_response_id = None
                    self._openai_response_id_history = []
                    self._openai_input_items = []
                    self._openai_last_sent_input_items = None
            except Exception:
                pass
            # xAI state resets when switching away from grok-*.
            try:
                if self.model and (not self._is_xai_model(self.model)):
                    self._xai_previous_response_id = None
                    self._xai_response_id_history = []
                    self._xai_input_items = []
                    self._xai_last_sent_input_items = None
            except Exception:
                pass
            # Local Codex manual replay state should not leak across non-Codex models.
            try:
                if self.model and (not self._is_codex_local_model(self.model)):
                    self._clear_codex_backend_rollover()
                    self._codex_local_input_items = []
                    self._codex_local_last_sent_input_items = None
            except Exception:
                pass
            if model_name in {"gpt-5.4-pro"}:
                # Default these to high, but don't clobber a user-chosen xhigh.
                if getattr(self, "reasoning_effort", None) not in ("high", "xhigh"):
                    self.reasoning_effort = "high"
            # Codex family: disable preambles for better behavior
            if "codex" in model_name:
                self.preambles_enabled = False
            # Tool-call preambles are supported for GPT-5 / GPT-5.4 non-Codex models.
            # Force-disable for all other models (even if a saved setting had it enabled).
            if not self._supports_preambles(self.model):
                self.preambles_enabled = False
        except Exception:
            try:
                self.reasoning_effort = "high"
            except Exception:
                pass

    def _supports_preambles(self, model: Optional[str]) -> bool:
        """Tool-call preambles are a CLI-only UX hint.

        Supported (non-Codex only):
        - GPT-5 base line: "gpt-5" and date-pinned variants like "gpt-5-2025-08-07"
        - GPT-5.4 family: "gpt-5.4*" (e.g., gpt-5.4, gpt-5.4-pro)

        Not supported:
        - Any Codex variants ("*codex*")
        - GPT-5.1* (kept off by default until validated)
        """
        try:
            if not model:
                return False
            m = str(self._resolve_model_alias(model) or "").strip().lower()
            # Allow GPT-5 base line and GPT-5.4 family.
            if not (m == "gpt-5" or m.startswith("gpt-5-") or m.startswith("gpt-5.4")):
                return False
            if "codex" in m:
                return False
            if m.startswith("gpt-5.1"):
                return False
            return True
        except Exception:
            return False

    def _is_openai_model(self, model: Optional[str]) -> bool:
        """Best-effort model/provider discriminator for client-side state.

        The server is multi-provider. For the CLI we treat anything that isn't an explicit
        non-OpenAI provider prefix as OpenAI.
        """
        try:
            if not model:
                return False
            m = str(model).strip().lower()
            if not m:
                return False
            for pfx in ("gemini-", "claude-", "grok-", "deepseek-", "kimi-", "glm-"):
                if m.startswith(pfx):
                    return False
            # Everything else defaults to OpenAI in this repo.
            return True
        except Exception:
            return False

    def _is_xai_model(self, model: Optional[str]) -> bool:
        try:
            if not model:
                return False
            m = str(model).strip().lower()
            return m.startswith("grok-")
        except Exception:
            return False

    def _provider_supports_native_retention(self, model: Optional[str]) -> bool:
        """Whether this provider has an implemented native tool/thinking retention path."""
        try:
            if not model:
                return False
            m = str(model).strip().lower()
            if m.startswith("gemini-"):
                return True
            if m.startswith("kimi-"):
                return bool(getattr(self, "retain_native_tool_results", False))
            if m.startswith("grok-"):
                return True
            if self._is_openai_model(model):
                return True
            return False
        except Exception:
            return False

    def _sanitize_openai_items(self, items: Any) -> Any:
        """Recursively strip fields from OpenAI output items that cause errors when used as input."""
        if isinstance(items, list):
            return [self._sanitize_openai_items(x) for x in items]
        if isinstance(items, dict):
            item_type = str(items.get("type") or "").strip().lower()
            if item_type == "web_search_call":
                # OpenAI rejects replaying web_search_call.action/query in input items.
                keep_keys = {"type", "id"}
                return {
                    k: self._sanitize_openai_items(v)
                    for k, v in items.items()
                    if k in keep_keys
                }
            # 'status' is the main offender causing 400s
            bad_keys = {"status", "usage", "completed_at", "created_at", "incomplete_details", "metadata", "parsed_arguments"}
            return {k: self._sanitize_openai_items(v) for k, v in items.items() if k not in bad_keys}
        return items

    async def _cancel_inflight_dispatch(self, reason: str = "cancelled by user") -> None:
        """If the server delegated a tool to this CLI (tool.dispatch), send a cancellation callback.

        This prevents the server from waiting until TOOLS_CALLBACK_TIMEOUT_SEC when the user aborts.
        Best-effort; never raises.
        """
        ctx = None
        try:
            ctx = dict(self._inflight_dispatch) if isinstance(self._inflight_dispatch, dict) else None
        except Exception:
            ctx = None
        if not ctx:
            return
        session_id = ctx.get("session_id")
        call_id = ctx.get("call_id")
        job_token = ctx.get("job_token")
        name = ctx.get("name")
        if not (session_id and call_id and job_token):
            return
        payload_cb = {
            "session_id": session_id,
            "call_id": call_id,
            "name": name,
            "job_token": job_token,
            "result": {
                "ok": False,
                "cancelled": True,
                "error": str(reason or "cancelled"),
            },
        }
        try:
            # Keep it short; we just want to unblock the server.
            http_timeout = httpx.Timeout(connect=2.0, read=3.0, write=2.0, pool=2.0)
        except Exception:
            http_timeout = None
        try:
            async with httpx.AsyncClient(timeout=http_timeout, cookies=self.cookies) as client:
                await client.post(self.tools_callback_url, json=payload_cb)
        except Exception:
            pass
        finally:
            try:
                self._inflight_dispatch = None
            except Exception:
                pass

    def _is_gpt_model(self, model: Optional[str]) -> bool:
        """True for OpenAI GPT models (used for showing certain UI-only toggles)."""
        try:
            return bool(model) and str(model).strip().lower().startswith("gpt-")
        except Exception:
            return False
    def _is_codex_model(self, model: Optional[str]) -> bool:
        try:
            return bool(model) and ("codex" in str(model).lower())
        except Exception:
            return False
    def _supports_xhigh_reasoning_effort(self, model: Optional[str]) -> bool:
        """Return True if the OpenAI model supports reasoning_effort='xhigh'.

        OpenAI supports xhigh on:
        - gpt-5.1-codex-max
        - the gpt-5.4* family
        """
        try:
            m = str(self._resolve_model_alias(model) or "").strip().lower()
            return m == "gpt-5.1-codex-max" or m.startswith("gpt-5.4")
        except Exception:
            return False

    def _is_deepseek_like(self, model: Optional[str]) -> bool:
        try:
            return bool(model) and ("deepseek" in str(model).lower())
        except Exception:
            return False

    def compute_cost_usd(self, model: Optional[str], usage: Dict[str, Any]) -> float:
        price = self._resolve_price(model)
        provider = (price.get("provider") or "").lower()
        # prefer detailed fields when present
        prompt_tokens = int(usage.get("prompt_tokens") or usage.get("turn", {}).get("input_tokens", 0) or 0)
        completion_tokens = int(usage.get("completion_tokens") or usage.get("turn", {}).get("output_tokens", 0) or 0)
        total_tokens = int(usage.get("total_tokens") or usage.get("turn", {}).get("total_tokens", 0) or (prompt_tokens + completion_tokens) or 0)
        image_tokens = int(usage.get("image_tokens", 0) or 0)
        thinking_tokens = int(usage.get("thinking_tokens", 0) or 0)
        # Reasoning gap: bill as completion-side if total > (prompt + completion)
        reasoning_gap = 0
        try:
            if total_tokens > (prompt_tokens + completion_tokens):
                reasoning_gap = total_tokens - (prompt_tokens + completion_tokens)
        except Exception:
            reasoning_gap = 0
        # Anthropic: count image tokens as prompt-side
        if provider == "anthropic" and image_tokens:
            prompt_tokens += image_tokens
        # Anthropic prompt caching: pricing logic (reads @ 10%, creation @ 1.25x/2x)
        if provider == "anthropic":
            cache_read = int(usage.get("cache_read_input_tokens", 0) or 0)
            cache_creation = int(usage.get("cache_creation_input_tokens", 0) or 0)
            # Try to detect creation breakdown if available
            cc_5m = 0
            cc_1h = 0
            try:
                cc_map = usage.get("cache_creation") if isinstance(usage, dict) else None
                if isinstance(cc_map, dict):
                    cc_5m = int(cc_map.get("ephemeral_5m_input_tokens", 0) or 0)
                    cc_1h = int(cc_map.get("ephemeral_1h_input_tokens", 0) or 0)
            except Exception:
                pass
            # If breakdown is missing but total creation exists, assume 5m (1.25x) as default/safe estimate
            if cache_creation > 0 and (cc_5m + cc_1h) == 0:
                cc_5m = cache_creation
            
            # Only apply special pricing if cache fields are present
            if cache_read > 0 or cache_creation > 0:
                in_rate = float(price.get("input", 0.0))
                out_rate = float(price.get("output", 0.0))
                
                # Non-cached prompt part
                non_cached = max(0, int(prompt_tokens) - int(cache_read) - int(cache_creation))
                
                cost = 0.0
                # Standard input
                cost += (non_cached / 1_000_000.0) * in_rate
                # Cache reads (10% of input rate)
                cost += (cache_read / 1_000_000.0) * (in_rate * 0.10)
                # Cache creation (1.25x for 5m, 2.0x for 1h)
                if cc_5m > 0:
                    cost += (cc_5m / 1_000_000.0) * (in_rate * 1.25)
                if cc_1h > 0:
                    cost += (cc_1h / 1_000_000.0) * (in_rate * 2.00)
                
                # Output + reasoning gap
                completion_total = completion_tokens
                if total_tokens and (prompt_tokens + completion_tokens) != total_tokens:
                    completion_total += reasoning_gap
                else:
                    if thinking_tokens and not usage.get("total_tokens"):
                        completion_total += thinking_tokens
                
                cost += (completion_total / 1_000_000.0) * out_rate
                return float(cost)

        # reasoning_gap already computed above
        # DeepSeek cache pricing nuance (best-effort; needs provider-specific fields to be precise)
        if self._is_deepseek_like(model):
            hit = int(usage.get("prompt_cache_hit_tokens", 0) or 0)
            miss = int(usage.get("prompt_cache_miss_tokens", 0) or 0)
            if (hit + miss) <= 0:
                miss = prompt_tokens
                hit = 0
            # V3.2 cache hit pricing per docs with +$0.25 margin -> $0.278 / 1M
            cache_hit_rate_per_m = 0.278
            cost = (hit / 1_000_000.0) * cache_hit_rate_per_m
            cost += (miss / 1_000_000.0) * float(price.get("input", 0.0))
            cost += ((completion_tokens + reasoning_gap) / 1_000_000.0) * float(price.get("output", 0.0))
            return float(cost)
        # OpenAI prompt caching: cached input tokens billed at 10% of input price by default
        # Allow per-model override via price["cached_input"] when provided
        if provider == "openai":
            cached_tokens = 0
            try:
                itd = usage.get("input_tokens_details") if isinstance(usage, dict) else None
                if isinstance(itd, dict):
                    cached_tokens = int(itd.get("cached_tokens", 0) or 0)
                else:
                    cached_tokens = int(usage.get("cached_input_tokens", 0) or 0)
            except Exception:
                cached_tokens = 0
            try:
                cached_tokens = max(0, min(int(cached_tokens), int(prompt_tokens)))
            except Exception:
                cached_tokens = 0
            non_cached = max(0, prompt_tokens - cached_tokens)
            in_rate, cached_rate_override, out_rate = self._openai_context_scaled_rates(price, prompt_tokens)
            try:
                cached_rate = float(cached_rate_override) if cached_rate_override is not None else (in_rate * 0.10)
            except Exception:
                cached_rate = in_rate * 0.10
            cost = (non_cached / 1_000_000.0) * in_rate
            cost += (cached_tokens / 1_000_000.0) * cached_rate
            cost += ((completion_tokens + reasoning_gap) / 1_000_000.0) * out_rate
            return float(cost)
        # Gemini dynamic premium omitted for brevity; default pricing used.
        completion_total = completion_tokens
        if total_tokens and (prompt_tokens + completion_tokens) != total_tokens:
            completion_total += reasoning_gap
        else:
            if thinking_tokens and not usage.get("total_tokens"):
                completion_total += thinking_tokens
        cost = (prompt_tokens / 1_000_000.0) * float(price.get("input", 0.0)) + (completion_total / 1_000_000.0) * float(price.get("output", 0.0))
        return float(cost)

    # ----------------------- File logging -----------------------

    def _ensure_session_log(self) -> None:
        if not self.log_enabled:
            return
        try:
            self.log_dir.mkdir(parents=True, exist_ok=True)
            if not self.session_log_path:
                _now_utc = datetime.now(timezone.utc)
                ts = _now_utc.strftime("%Y%m%d-%H%M%S")
                fname = f"session-{ts}-{self._session_local_id[:8]}.jsonl"
                self.session_log_path = self.log_dir / fname
                # Write an initial header record
                hdr = {
                    "ts": _now_utc.isoformat().replace("+00:00", "Z"),
                    "event": "session.init",
                    "client": "henosis-cli",
                    "server": self.server,
                    "model": self.model,
                    "system_prompt": (self.system_prompt or None),
                    "tools": self._tools_label(),
                    "fs_scope": self._fs_label(),
                    "control_level": self.control_level,
                    "auto_approve": self.auto_approve,
                    "reasoning_effort": self.reasoning_effort,
                    "thinking_insight_summary": self.thinking_insight_summary,
                    "ctx_window": self.ctx_window,
                    "session_local_id": self._session_local_id,
                    "terminal_id": self.terminal_id,
                    "workspace_dir": self.local_workspace_dir,
                }
                with self.session_log_path.open("a", encoding="utf-8") as f:
                    f.write(json.dumps(hdr, ensure_ascii=False) + "\n")
        except Exception:
            pass

    # ----------------------- Raw log helpers -----------------------
    def _ensure_raw_log(self) -> None:
        if not self.raw_log_enabled:
            return
        try:
            if self._rawlog_initialized and self.raw_log_path and self.raw_log_path.exists():
                return
            # Default to CWD when no explicit file provided
            if not self.raw_log_path:
                now = datetime.now(timezone.utc)
                ts = now.strftime("%Y%m%d-%H%M%S")
                fname = f"henosis_raw-{ts}-{self._session_local_id[:8]}.log"
                try:
                    base = Path(os.getcwd()).resolve()
                except Exception:
                    base = Path('.')
                self.raw_log_path = base / fname
            # Write header
            hdr_lines = [
                f"=== henosis-cli RAW LOG start {datetime.now(timezone.utc).isoformat().replace('+00:00','Z')} ===",
                f"server: {self.server}",
                f"api_base: {self.api_base}",
                f"model: {self.model or '(server default)'}",
                f"cwd: {os.getcwd()}",
            ]
            with self.raw_log_path.open('a', encoding='utf-8') as f:
                for ln in hdr_lines:
                    f.write(ln + "\n")
            self._rawlog_initialized = True
        except Exception:
            # Disable on failure to avoid repeated errors
            try:
                self.raw_log_enabled = False
            except Exception:
                pass

    def _rawlog_write(self, text: str) -> None:
        if not (self.raw_log_enabled):
            return
        try:
            self._ensure_raw_log()
            if self.raw_log_path:
                with self.raw_log_path.open('a', encoding='utf-8') as f:
                    ts = datetime.now(timezone.utc).isoformat().replace('+00:00','Z')
                    f.write(f"[{ts}] {text}\n")
        except Exception:
            pass

    def _rawlog_write_json(self, obj: Any, prefix: Optional[str] = None) -> None:
        try:
            s = json.dumps(obj, ensure_ascii=False)
        except Exception:
            s = str(obj)
        if prefix:
            self._rawlog_write(prefix)
        # Write on its own line for easy grepping
        self._rawlog_write(s)

    # ----------------------- Thread naming -----------------------

    def _detect_project_name(self) -> str:
        # Priority order for project name detection:
        # 1) HENOSIS_PROJECT or HENOSIS_PROJECT_NAME env vars
        # 2) Git repo top-level directory name (if available)
        # 3) host_base setting (basename)
        # 4) Current working directory basename
        env_name = os.getenv("HENOSIS_PROJECT") or os.getenv("HENOSIS_PROJECT_NAME")
        if env_name and env_name.strip():
            return env_name.strip()
        # Try git
        try:
            import subprocess
            top = subprocess.check_output(["git", "rev-parse", "--show-toplevel"], stderr=subprocess.DEVNULL).decode("utf-8").strip()
            if top:
                return os.path.basename(top)
        except Exception:
            pass
        # Host base
        if self.host_base:
            try:
                return os.path.basename(os.path.abspath(self.host_base))
            except Exception:
                pass
        # CWD
        try:
            return os.path.basename(os.getcwd()) or "project"
        except Exception:
            return "project"

    def _default_thread_name(self) -> str:
        ts = datetime.now().strftime("%Y-%m-%d %H:%M")
        project = self._detect_project_name()
        return f"{ts} - {project}"

    def _log_line(self, record: Dict[str, Any]) -> None:
        if not (self.log_enabled and self.session_log_path):
            return
        try:
            record = {"ts": datetime.now(timezone.utc).isoformat() + "Z", **record}
            with self.session_log_path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(record, ensure_ascii=False) + "\n")
        except Exception:
            pass

    # ----------------------- Threads save -----------------------

    async def _ensure_thread(self, client: httpx.AsyncClient) -> None:
        if not (self.save_chat_history and self.auth_user and not self.thread_uid):
            return
        try:
            # Refresh auto title at creation time if not manually set
            if not self._manual_title:
                self.thread_name = self._default_thread_name()
            r = await client.post(self.create_thread_url, json={"name": self.thread_name})
            if r.status_code == 200:
                data = r.json()
                self.thread_uid = data.get("thread_uid")
                self._log_line({"event": "thread.created", "thread_uid": self.thread_uid, "name": self.thread_name})
                if self.thread_uid:
                    self.ui.print(f"[saved] Created thread {self.thread_uid}", style=self.ui.theme["dim"])
        except Exception:
            pass

    async def _save_conversation(self, client: httpx.AsyncClient, selected_model: Optional[str]) -> None:
        if not (self.save_chat_history and self.auth_user and self.thread_uid):
            return
        try:
            payload = {
                "thread_uid": self.thread_uid,
                "thread_name": self.thread_name,
                "messages": self.messages_for_save,
                "paste_counter": 0,
                "selected_model": selected_model or self.model,
                "share_settings": None,
            }
            r = await client.post(self.save_convo_url, json=payload)
            if r.status_code == 200:
                self._log_line({"event": "thread.saved", "thread_uid": self.thread_uid, "message_count": len(self.messages_for_save)})
                self.ui.print(f"[saved] Conversation synced to server", style=self.ui.theme["dim"])
            else:
                self._log_line({"event": "thread.save_failed", "status": r.status_code, "body": r.text})
        except Exception as e:
            self._log_line({"event": "thread.save_exception", "error": str(e)})

    async def _commit_usage(
        self,
        client: httpx.AsyncClient,
        session_id: Optional[str],
        model_used: Optional[str],
        usage: Dict[str, Any],
        meta: Optional[Dict[str, Any]] = None,
    ) -> None:
        if not (self.server_usage_commit and self.auth_user and session_id and model_used):
            return
        try:
            meta_payload = {"source": "henosis-cli"}
            if isinstance(meta, dict):
                try:
                    meta_payload.update(meta)
                except Exception:
                    pass
            payload = {
                "session_id": session_id,
                "model": model_used,
                "usage": usage,
                "thread_uid": self.thread_uid,
                "meta": meta_payload,
            }
            r = await client.post(self.commit_usage_url, json=payload)
            if r.status_code == 200:
                data = r.json()
                rem = data.get("remaining_credits")
                cost = data.get("cost_usd")
                sess_cum = data.get("session_cumulative") or {}
                sess_cum_cost = None
                try:
                    if isinstance(sess_cum, dict):
                        sess_cum_cost = float(sess_cum.get("cost_usd") or 0.0)
                except Exception:
                    sess_cum_cost = None
                self._log_line({"event": "usage.commit_ok", "server": True, "cost_usd": cost, "remaining_credits": rem, "session_cumulative": sess_cum})
                # Print authoritative server cost line only
                try:
                    cost_f = float(cost or 0.0)
                except Exception:
                    cost_f = 0.0
                # If server provided cumulative, prefer that for display; otherwise derive from running sum
                # Always accumulate locally across CLI turns. The server's session_cumulative in this endpoint
                # is scoped to the per-stream session_id (a new one each turn), so it is not a chat-session total.
                self.server_cumulative_cost_usd += cost_f
                # Store last commit details for Usage & Info box rendering
                self._last_commit_cost_usd = cost_f
                # Normalize remaining credits to float when possible
                try:
                    if rem is not None:
                        self._last_remaining_credits = float(rem)
                except Exception:
                    pass
                self._last_commit_model = model_used or None
            else:
                self._log_line({"event": "usage.commit_failed", "status": r.status_code, "body": r.text})
                try:
                    meta_src = str(meta_payload.get("billing_source") or "").strip().lower()
                except Exception:
                    meta_src = ""
                if meta_src == "codex_local":
                    self.ui.warn(f"Local Codex analytics commit failed: {self._clip(r.text, 220)}")
        except Exception as e:
            self._log_line({"event": "usage.commit_exception", "error": str(e)})
            try:
                meta_src = str(meta_payload.get("billing_source") or "").strip().lower()
            except Exception:
                meta_src = ""
            if meta_src == "codex_local":
                self.ui.warn(f"Local Codex analytics commit error: {self._clip(str(e), 220)}")

    async def check_auth(self) -> bool:
        """Check current auth status using stored cookies; set self.auth_user on success."""
        try:
            # Log a compact summary of cookies relevant to auth before any calls
            try:
                access = self.cookies.get("access_token_cookie")
                refresh = self.cookies.get("refresh_token_cookie")
                self.ui.debug_log(
                    f"[auth-cli] check_auth: start access={'set' if access else 'missing'}, refresh={'set' if refresh else 'missing'}"
                )
            except Exception:
                pass
            # Build an SSE-friendly timeout config when no explicit timeout provided
            if self.timeout is None:
                http_timeout = httpx.Timeout(connect=10.0, read=None, write=10.0, pool=10.0)
            else:
                http_timeout = httpx.Timeout(self.timeout)

            async with httpx.AsyncClient(timeout=http_timeout, cookies=self.cookies) as client:
                # First try to refresh tokens to ensure they're current
                try:
                    if self.cookies.get('refresh_token_cookie'):
                        self.ui.debug_log("[auth-cli] check_auth: calling /refresh before /check-auth")
                        refresh_resp = await client.post(self.refresh_url, timeout=30.0)
                        if refresh_resp.status_code == 200:
                            data = refresh_resp.json()
                            # If token was rotated, persist the new one
                            if data.get('rotated'):
                                self.ui.debug_log("[auth-cli] check_auth: refresh rotated token; saving state")
                                self._save_auth_state_to_disk()
                        else:
                            self.ui.debug_log(
                                f"[auth-cli] check_auth: /refresh returned {refresh_resp.status_code}: {refresh_resp.text[:200]}"
                            )
                except Exception:
                    pass  # Non-fatal; proceed with check-auth
                
                self.ui.debug_log("[auth-cli] check_auth: calling /check-auth")
                resp = await client.get(self.check_auth_url)
                if resp.status_code == 200:
                    data = resp.json() if resp.headers.get("content-type", "").startswith("application/json") else {}
                    if data.get("authenticated"):
                        self.auth_user = str(data.get("user") or "")
                        try:
                            access_after = self.cookies.get("access_token_cookie")
                            refresh_after = self.cookies.get("refresh_token_cookie")
                            self.ui.debug_log(
                                f"[auth-cli] check_auth: authenticated as {self.auth_user!r}, access={'set' if access_after else 'missing'}, refresh={'set' if refresh_after else 'missing'}"
                            )
                        except Exception:
                            pass
                        return True
                    # Explicitly unauthenticated
                    self.auth_user = None
                    self.ui.debug_log("[auth-cli] check_auth: /check-auth returned authenticated=False")
                    return False
                # Non-200 usually means unauthenticated or endpoint disabled
                self.auth_user = None
                try:
                    self.ui.debug_log(
                        f"[auth-cli] check_auth: /check-auth returned {resp.status_code}: {resp.text[:200]}"
                    )
                except Exception:
                    pass
                return False
        except Exception:
            # If auth endpoints disabled or network error, treat as unauthenticated
            self.auth_user = None
            try:
                self.ui.debug_log("[auth-cli] check_auth: exception; treating as unauthenticated")
            except Exception:
                pass
            return False

    # ----------------------- Settings persistence -----------------------

    def _parse_context_near_full_pct(self, raw: Any) -> Tuple[Optional[float], bool]:
        """Parse near-full cutoff as ratio [0,1] from inputs like 0.85, 85, or '85%'."""
        try:
            if raw in (None, ""):
                return None, True
            if isinstance(raw, str):
                s = raw.strip().lower()
                if s in ("", "default", "server default", "none"):
                    return None, True
                if s.endswith("%"):
                    s = s[:-1].strip()
                v = float(s)
            else:
                v = float(raw)
            if (v != v) or (v in (float("inf"), float("-inf"))):
                return None, False
            if v > 1.0 and v <= 100.0:
                v = v / 100.0
            if v < 0.0:
                v = 0.0
            if v > 1.0:
                v = 1.0
            return float(v), True
        except Exception:
            return None, False

    def load_settings(self) -> None:
        """Load local settings (legacy JSON) as defaults. Server settings will override after auth."""
        settings_path = self.settings_file
        if not settings_path.exists():
            legacy = Path.home() / ".fastapi_cli_settings.json"
            if legacy.exists():
                settings_path = legacy
                self._settings_migrated = True
        if not settings_path.exists():
            return
        try:
            with open(settings_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            self._apply_settings_dict(data)
        except Exception as e:
            self.ui.warn(f"Failed to load local settings: {e}")

    def _collect_settings_dict(self) -> Dict[str, Any]:
        data = {
            "model": self.model,
            "requested_tools": self.requested_tools,
            "fs_scope": self.fs_scope,
            # host_base is per-terminal by default; only persist if explicitly set by the user
            "save_chat_history": self.save_chat_history,
            "fs_host_mode": self.fs_host_mode,
            "system_prompt": self.system_prompt,
            "show_tool_calls": self.show_tool_calls,
            "max_dir_items": self.max_dir_items,
            "control_level": self.control_level,
            "auto_approve": self.auto_approve,
            "trust_tools_always": self.trust_tools_always,
            "trust_tools_session": self.trust_tools_session,
            "trust_cmds_always": self.trust_cmds_always,
            "trust_cmds_session": self.trust_cmds_session,
            "inject_codebase_map": self.inject_codebase_map,
            # AGENTS.md (Issue #12)
            "inject_agents_md": getattr(self, "inject_agents_md", True),
            "agents_md_text": getattr(self, "agents_md_text", ""),
            "agents_prepend_mode": getattr(self, "agents_prepend_mode", None),
            "preflight_enabled": self.preflight_enabled,
            # local-only preferences
            "telemetry_enabled": self.telemetry_enabled,
            "output_format": self.output_format,
            # Usage & Info panel mode
            "usage_info_mode": self.usage_info_mode,
            # Issue #15: configurable status fields + layout
            "status_fields": getattr(self, "status_fields", None),
            "status_layout": getattr(self, "status_layout", None),
            # reasoning effort
            "reasoning_effort": self.reasoning_effort,
            "service_tier": self.service_tier,
            # Anthropic thinking budget
            "thinking_budget_tokens": self.thinking_budget_tokens,
            # Optional provider thinking insight
            "thinking_insight_enabled": self.thinking_insight_enabled,
            # OpenAI reasoning summary verbosity for thinking insight
            "thinking_insight_summary": self.thinking_insight_summary,
            # Anthropic effort (Opus 4.6/4.5/Sonnet 4.6). Default: high.
            "anthropic_effort": getattr(self, "anthropic_effort", None),
            # Anthropic cache TTL preference
            "anthropic_cache_ttl": self.anthropic_cache_ttl,
            # Per-request context_handoff near-full cutoff
            "context_near_full_pct": self.context_near_full_pct,
            # web search
            "web_search_enabled": self.web_search_enabled,
            "web_search_allowed_domains": self.web_search_allowed_domains,
            "web_search_include_sources": self.web_search_include_sources,
            "web_search_location": self.web_search_location,
            # verbosity & preambles & custom first-turn injection
            "text_verbosity": self.text_verbosity,
            "preambles_enabled": self.preambles_enabled,
            "custom_first_turn_enabled": self.custom_first_turn_enabled,
            "custom_first_turn_text": self.custom_first_turn_text,
            "codex_prompt_enabled": self.codex_prompt_enabled,
            # Issue #14: persist only the last user input for Up-arrow recall across sessions.
            "last_user_input": getattr(self, "last_user_input", ""),
        }
        try:
            if not getattr(self, "_host_base_ephemeral", False) and self.host_base:
                data["host_base"] = self.host_base
        except Exception:
            pass
        return data

    def _apply_settings_dict(self, data: Dict[str, Any]) -> None:
        try:
            old_system_prompt = getattr(self, "system_prompt", None)
            self.model = data.get("model", self.model)
            if "save_chat_history" in data:
                try:
                    self.save_chat_history = bool(data.get("save_chat_history"))
                except Exception:
                    pass
            self.requested_tools = data.get("requested_tools", self.requested_tools)
            self.fs_scope = data.get("fs_scope", self.fs_scope)
            self.host_base = data.get("host_base", self.host_base)
            self.fs_host_mode = data.get("fs_host_mode", self.fs_host_mode)
            self.system_prompt = data.get("system_prompt", self.system_prompt)
            self.show_tool_calls = data.get("show_tool_calls", self.show_tool_calls)
            self.max_dir_items = data.get("max_dir_items", self.max_dir_items)
            # Normalize control level to int when loaded from JSON.
            # (Some older configs may have stored it as a string like "3".)
            try:
                raw_lvl = data.get("control_level", self.control_level)
                if isinstance(raw_lvl, int):
                    self.control_level = raw_lvl
                elif isinstance(raw_lvl, str) and raw_lvl.strip().isdigit():
                    self.control_level = int(raw_lvl.strip())
                else:
                    # Preserve None/server-default, but ignore invalid values.
                    if raw_lvl is None:
                        self.control_level = None
            except Exception:
                pass
            self.auto_approve = data.get("auto_approve", self.auto_approve) or []
            if "web_search_enabled" in data:
                try:
                    self.web_search_enabled = bool(data.get("web_search_enabled"))
                except Exception:
                    self.web_search_enabled = False
            if "web_search_allowed_domains" in data:
                domains = data.get("web_search_allowed_domains")
                if isinstance(domains, list):
                    cleaned_domains: List[str] = []
                    for dom in domains:
                        if isinstance(dom, str):
                            s = dom.strip()
                            if s:
                                cleaned_domains.append(s)
                    self.web_search_allowed_domains = cleaned_domains
            if "web_search_include_sources" in data:
                try:
                    self.web_search_include_sources = bool(data.get("web_search_include_sources"))
                except Exception:
                    self.web_search_include_sources = False
            if "context_near_full_pct" in data:
                parsed_pct, ok_pct = self._parse_context_near_full_pct(data.get("context_near_full_pct"))
                if ok_pct:
                    self.context_near_full_pct = parsed_pct
            if "web_search_location" in data:
                loc = data.get("web_search_location")
                if isinstance(loc, dict):
                    cleaned_loc: Dict[str, str] = {}
                    for key, value in loc.items():
                        if isinstance(key, str) and isinstance(value, str):
                            v = value.strip()
                            if v:
                                cleaned_loc[key.strip()] = v
                    self.web_search_location = cleaned_loc
                else:
                    self.web_search_location = {}
            # Trust registries
            self.trust_tools_always = data.get("trust_tools_always", []) or []
            self.trust_tools_session = data.get("trust_tools_session", []) or []
            self.trust_cmds_always = data.get("trust_cmds_always", []) or []
            self.trust_cmds_session = data.get("trust_cmds_session", []) or []
            # Codebase map injection toggle
            if "inject_codebase_map" in data:
                try:
                    self.inject_codebase_map = bool(data.get("inject_codebase_map"))
                except Exception:
                    pass

            # AGENTS.md settings (Issue #12)
            if "inject_agents_md" in data:
                try:
                    self.inject_agents_md = bool(data.get("inject_agents_md"))
                except Exception:
                    pass
            if "agents_md_text" in data:
                try:
                    txt = data.get("agents_md_text")
                    if isinstance(txt, str):
                        self.agents_md_text = txt
                        # Refresh cached default text
                        try:
                            self._agents_default_raw = self._load_agents_default_raw()
                        except Exception:
                            pass
                except Exception:
                    pass
            if "agents_prepend_mode" in data:
                try:
                    mode = data.get("agents_prepend_mode")
                    if mode in (None, "prepend_default", "local_only"):
                        self.agents_prepend_mode = mode
                    elif isinstance(mode, str) and mode.strip().lower() in ("prepend_default", "local_only"):
                        self.agents_prepend_mode = mode.strip().lower()
                except Exception:
                    pass
            # Preflight toggle
            if "preflight_enabled" in data:
                try:
                    self.preflight_enabled = bool(data.get("preflight_enabled"))
                except Exception:
                    pass
            # Local-only prefs
            if "telemetry_enabled" in data:
                self.telemetry_enabled = data.get("telemetry_enabled")
            if "output_format" in data:
                self.output_format = data.get("output_format")
            # Issue #14: last user input stash (for Up-arrow recall). Keep only
            # one persisted string; the session still maintains an in-memory list.
            try:
                lui = data.get("last_user_input")
                if isinstance(lui, str) and lui.strip():
                    self.last_user_input = lui
                    # Seed session history if empty.
                    if not getattr(self, "_user_input_history", None):
                        self._user_input_history = [lui]
                    else:
                        # Ensure it is the last entry (avoid duplicates).
                        if self._user_input_history[-1] != lui:
                            self._user_input_history.append(lui)
                    # Push into input engine if present.
                    try:
                        if self._input_engine and hasattr(self._input_engine, "set_history"):
                            self._input_engine.set_history(self._user_input_history)
                    except Exception:
                        pass
            except Exception:
                pass
            # Usage & Info panel mode
            if "usage_info_mode" in data:
                try:
                    val = str(data.get("usage_info_mode") or "").strip().lower()
                    if val in ("concise", "verbose"):
                        self.usage_info_mode = val
                except Exception:
                    pass

            # Issue #15: status fields + layout
            if "status_layout" in data:
                try:
                    sl = data.get("status_layout")
                    if sl is None or sl == "":
                        self.status_layout = None
                    elif isinstance(sl, str):
                        sl2 = sl.strip().lower()
                        if sl2 in ("line", "panel"):
                            self.status_layout = sl2
                except Exception:
                    pass
            if "status_fields" in data:
                try:
                    sf = data.get("status_fields")
                    if sf is None or sf == "":
                        self.status_fields = None
                    elif isinstance(sf, str):
                        toks = [t.strip() for t in sf.replace("\n", ",").split(",") if t.strip()]
                        self.status_fields = toks
                    elif isinstance(sf, list):
                        toks2: List[str] = []
                        for x in sf:
                            if isinstance(x, str) and x.strip():
                                toks2.append(x.strip())
                        self.status_fields = toks2
                except Exception:
                    pass
            # Reasoning effort (default medium if missing/invalid)
            try:
                val = data.get("reasoning_effort")
                if isinstance(val, str) and val in ("low", "medium", "high", "xhigh"):
                    self.reasoning_effort = val
            except Exception:
                pass
            try:
                val = data.get("service_tier")
                if val == "priority":
                    self.service_tier = "priority"
                elif val in (None, "", "default", "standard", "off"):
                    self.service_tier = None
            except Exception:
                pass
            if "thinking_insight_enabled" in data:
                try:
                    self.thinking_insight_enabled = bool(data.get("thinking_insight_enabled"))
                except Exception:
                    self.thinking_insight_enabled = False
            if "thinking_insight_summary" in data:
                try:
                    ts = str(data.get("thinking_insight_summary") or "").strip().lower()
                    if ts in ("auto", "concise", "detailed"):
                        self.thinking_insight_summary = ts
                except Exception:
                    pass

            # Anthropic effort (Opus 4.6/4.5/Sonnet 4.6). Default behavior equals high.
            try:
                ae = data.get("anthropic_effort")
                if isinstance(ae, str):
                    ae2 = ae.strip().lower()
                    if ae2 in ("low", "medium", "high", "max"):
                        self.anthropic_effort = ae2
                elif ae in (None, "", "default"):
                    self.anthropic_effort = "high"
            except Exception:
                self.anthropic_effort = "high"
            # Text verbosity selector
            try:
                v = data.get("text_verbosity")
                if isinstance(v, str) and v in ("low", "medium", "high"):
                    self.text_verbosity = v
            except Exception:
                pass
            # Tool preambles toggle
            if "preambles_enabled" in data:
                try:
                    self.preambles_enabled = bool(data.get("preambles_enabled"))
                except Exception:
                    self.preambles_enabled = False
            if "codex_prompt_enabled" in data:
                try:
                    self.codex_prompt_enabled = bool(data.get("codex_prompt_enabled"))
                except Exception:
                    self.codex_prompt_enabled = True
            # provider-native tool results retention is always enabled (not user-configurable)
            self.retain_native_tool_results = True
            # Custom first-turn injection
            if "custom_first_turn_enabled" in data:
                try:
                    self.custom_first_turn_enabled = bool(data.get("custom_first_turn_enabled"))
                except Exception:
                    self.custom_first_turn_enabled = False
            if "custom_first_turn_text" in data:
                try:
                    txt = data.get("custom_first_turn_text")
                    if isinstance(txt, str):
                        self.custom_first_turn_text = txt
                except Exception:
                    pass
            # provider-native tool results retention is always enabled (not user-configurable)
            self.retain_native_tool_results = True
            # Anthropic thinking budget tokens
            try:
                tbt = data.get("thinking_budget_tokens")
                if isinstance(tbt, int) and tbt > 0:
                    self.thinking_budget_tokens = int(tbt)
                elif tbt in (None, "", 0, "0", "default"):
                    self.thinking_budget_tokens = None
            except Exception:
                pass
            # Anthropic cache TTL preference
            try:
                ttl = data.get("anthropic_cache_ttl")
                if isinstance(ttl, str) and ttl.strip() in ("5m", "1h"):
                    self.anthropic_cache_ttl = ttl.strip()
                elif ttl in (None, "", "default"):
                    self.anthropic_cache_ttl = None
            except Exception:
                pass
            # Rebuild history if system prompt changed
            try:
                system_prompt_changed = old_system_prompt != getattr(self, "system_prompt", None)
            except Exception:
                system_prompt_changed = False

            if system_prompt_changed:
                # Changing the system prompt can materially alter the behavior of the assistant;
                # warn the user and reset the current conversation history to avoid mixing contexts.
                try:
                    self.ui.warn("[settings] System prompt changed - clearing current conversation history.")
                except Exception:
                    pass
                self.history = []
                if self.system_prompt:
                    self.history.append({"role": "system", "content": self.system_prompt})
                self._clear_codex_backend_rollover()
                # OpenAI threaded state is invalid once the system prompt changes.
                try:
                    self._openai_previous_response_id = None
                    self._openai_response_id_history = []
                    self._openai_input_items = []
                    self._openai_last_sent_input_items = None
                    self._xai_previous_response_id = None
                    self._xai_response_id_history = []
                    self._xai_input_items = []
                    self._xai_last_sent_input_items = None
                    self._codex_local_input_items = []
                    self._codex_local_last_sent_input_items = None
                except Exception:
                    pass
            # On settings load, do not assume the custom first-turn was injected yet
            try:
                self._did_inject_custom_first_turn = False
            except Exception:
                pass
            self._apply_model_side_effects()
        except Exception as e:
            self.ui.warn(f"Failed to apply settings: {e}")

    async def _fetch_server_settings(self) -> Optional[Dict[str, Any]]:
        try:
            timeout = httpx.Timeout(connect=10.0, read=20.0, write=10.0, pool=10.0) if self.timeout is None else httpx.Timeout(self.timeout)
            params = {}
            if self.device_id:
                params["device_id"] = self.device_id
            async with httpx.AsyncClient(timeout=timeout, cookies=self.cookies) as client:
                r = await client.get(self.cli_settings_url, params=params)
                if r.status_code == 200 and r.headers.get("content-type", "").startswith("application/json"):
                    obj = r.json()
                    st = obj.get("settings")
                    if isinstance(st, dict):
                        return st
                return None
        except Exception:
            return None

    async def _save_server_settings(self, settings: Optional[Dict[str, Any]] = None) -> bool:
        try:
            timeout = httpx.Timeout(connect=10.0, read=20.0, write=10.0, pool=10.0) if self.timeout is None else httpx.Timeout(self.timeout)
            payload = {
                "settings": settings if isinstance(settings, dict) else self._collect_settings_dict(),
                "device_id": self.device_id,
                "device_name": self.device_name,
            }
            async with httpx.AsyncClient(timeout=timeout, cookies=self.cookies) as client:
                r = await client.post(self.cli_settings_url, json=payload)
                return r.status_code == 200
        except Exception:
            return False

    async def _sync_settings_with_server(self) -> None:
        """On first authenticated run: if server has settings, apply them; else upload local defaults."""
        # Try to load server settings
        st = await self._fetch_server_settings()
        if isinstance(st, dict) and st:
            try:
                self.ui.debug_log(
                    f"[settings-cli] sync: applying server settings user={self.auth_user!r} "
                    f"device_id={self.device_id!r} keys={sorted(st.keys())}"
                )
            except Exception:
                pass
            self._apply_settings_dict(st)
            self.ui.print("[settings] Loaded from server.", style=self.ui.theme["dim"])		
            return
        # No server settings: upload current local state
        try:
            self.ui.debug_log(
                f"[settings-cli] sync: no server settings; initializing user={self.auth_user!r} "
                f"device_id={self.device_id!r} model={self.model!r} tools={self.requested_tools!r} "
                f"fs_scope={self.fs_scope!r} level={self.control_level!r} host_base={self.host_base!r}"
            )
        except Exception:
            pass
        ok = await self._save_server_settings()
        if ok:
            self.ui.print("[settings] Initialized on server.", style=self.ui.theme["dim"])		
        else:
            self.ui.warn("[settings] Failed to initialize settings on server; continuing with local defaults.")

    async def _load_profile_for_tier(self) -> None:
        """Best-effort load of the user's subscription tier via /profile.

        Populates self.subscription_tier, self.subscription_status, and self.is_free_tier.
        Fails quietly so older servers without /profile continue to work.
        """
        try:
            # Build /profile URL relative to the same API base used for chat/settings.
            profile_url = join_url(self.api_base, "/profile")
        except Exception:
            return
        try:
            timeout = (
                httpx.Timeout(connect=10.0, read=20.0, write=10.0, pool=10.0)
                if self.timeout is None
                else httpx.Timeout(self.timeout)
            )
        except Exception:
            timeout = httpx.Timeout(10.0)
        try:
            async with httpx.AsyncClient(timeout=timeout, cookies=self.cookies) as client:
                r = await client.get(profile_url)
                if r.status_code != 200 or not r.headers.get("content-type", "").startswith("application/json"):
                    return
                obj = r.json()
        except Exception:
            return
        try:
            user = obj.get("user") if isinstance(obj, dict) else None
            if not isinstance(user, dict):
                return
            tier = user.get("subscription_tier")
            status = user.get("subscription_status")
            self.subscription_tier = str(tier) if tier is not None else None
            self.subscription_status = str(status) if status is not None else None
            tier_lower = str(tier).strip().lower() if tier is not None else ""
            status_lower = str(status).strip().lower() if status is not None else ""
            # Treat explicit "free" tier (and absence of any active subscription) as free-tier.
            is_free = False
            if tier_lower in ("free", "free_tier", "free-tier"):
                is_free = True
            elif not tier_lower and status_lower in ("none", "free", "trial", "inactive"):
                is_free = True
            self.is_free_tier = is_free
            # Extract remaining credits if available
            try:
                remaining = user.get("remaining_credits")
                c = user.get("credits")
                tc = user.get("tier_monthly_credits")
                fallback_candidates = []
                if remaining is not None:
                    fallback_candidates.append(remaining)
                try:
                    if c is not None and float(c) > 0:
                        fallback_candidates.append(c)
                except Exception:
                    pass
                if tc is not None:
                    fallback_candidates.append(tc)
                if c is not None:
                    fallback_candidates.append(c)
                for candidate in fallback_candidates:
                    try:
                        self._last_remaining_credits = float(candidate)
                        break
                    except Exception:
                        continue
                try:
                    self.ui.debug_log(
                        f"[profile-cli] credits check: remaining={remaining} c={c} tc={tc} -> {self._last_remaining_credits}"
                    )
                except Exception:
                    pass
            except Exception:
                pass
            try:
                self.ui.debug_log(
                    f"[profile-cli] loaded profile tier={self.subscription_tier!r} "
                    f"status={self.subscription_status!r} is_free_tier={self.is_free_tier!r} credits={self._last_remaining_credits}"
                )
            except Exception:
                pass
        except Exception:
            # Do not treat profile parsing errors as fatal
            return

    def save_settings(self) -> None:
        """Persist settings to the server in the background. Fallback to local file only if needed."""
        # Fire-and-forget background task when running inside an event loop
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                loop.create_task(self._save_server_settings())
                try:
                    loop.create_task(self._remote_control_send_state())
                except Exception:
                    pass
                return
        except Exception:
            pass
        # Fallback: best-effort synchronous save
        try:
            asyncio.run(self._save_server_settings())
        except Exception:
            pass
        try:
            asyncio.run(self._remote_control_send_state())
        except Exception:
            pass

    def _push_user_input_history(self, text: str) -> None:
        """Record a user-entered prompt for Up/Down arrow recall.

        - Keeps an in-memory list for the current CLI session.
        - Persists ONLY the most recent entry (last_user_input) via server settings.
        """
        try:
            if not isinstance(text, str):
                return
            s = text
            if not s or not s.strip():
                return
            # Do not store slash-commands (these are navigated via '/' menu).
            if s.lstrip().startswith("/"):
                return

            # Update session list
            if not hasattr(self, "_user_input_history") or self._user_input_history is None:
                self._user_input_history = []
            if self._user_input_history and self._user_input_history[-1] == s:
                # Still update last_user_input
                self.last_user_input = s
            else:
                self._user_input_history.append(s)
                # Bound growth (the input engine also bounds, but keep CLI side tidy)
                try:
                    if len(self._user_input_history) > 200:
                        self._user_input_history = self._user_input_history[-200:]
                except Exception:
                    pass
                self.last_user_input = s

            # Update input-engine history (best effort)
            try:
                if self._input_engine and hasattr(self._input_engine, "set_history"):
                    self._input_engine.set_history(self._user_input_history)
            except Exception:
                pass

            # Persist to server so Up-arrow recall works across sessions.
            # Only do this when authenticated (avoid noisy unauth calls).
            try:
                if getattr(self, "auth_user", None):
                    self.save_settings()
            except Exception:
                pass
        except Exception:
            return

    # ----------------------- Codebase map loader ------------------------

    def _load_codebase_map_raw(self) -> Optional[str]:
        """Locate CODEBASE_MAP.md content for first-turn injection.

        Preference order (all best-effort, quiet on failure):
        1) Under the configured Agent scope / host_base (CODEBASE_MAP.md or codebase_map.md).
        2) Under the current working directory (common when running from a project checkout).
        3) Next to this cli.py file (only when the map is shipped with the installed package).
        """
        roots: List[Path] = []
        # 1) Agent scope / host_base
        try:
            if isinstance(self.host_base, str) and self.host_base.strip():
                roots.append(Path(self.host_base).expanduser().resolve())
        except Exception:
            pass
        # 2) Current working directory
        try:
            roots.append(Path(os.getcwd()).resolve())
        except Exception:
            pass

        for root in roots:
            try:
                p1 = root / "CODEBASE_MAP.md"
                p2 = root / "codebase_map.md"
                if p1.exists():
                    return p1.read_text(encoding="utf-8", errors="ignore")
                if p2.exists():
                    return p2.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue

        # 3) Package-local fallback (may not exist when installed from wheel)
        try:
            p = Path(__file__).resolve().parent / "CODEBASE_MAP.md"
            if p.exists():
                return p.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            pass
        return None

    # ----------------------- AGENTS.md loader --------------------------

    # Hard-coded fallback for default AGENTS.md content.
    #
    # Rationale: In some installs/distributions the package-local AGENTS.md next to cli.py
    # may be missing/unreadable. The first-time wizard relies on a default template so it
    # can create host_base/AGENTS.md when absent.
    DEFAULT_AGENTS_MD_TEMPLATE = """# AGENTS.md
You do not need to mention these instructions in AGENTS.md
## Editing / committing
- When completing tasks, committing as we make progress is encouraged.
- Ask the user before you add or commit changes, with a proposal of the changes.

## Repo navigation preferences
- Prefer using the file-read tool to navigate/search for the full context even on large files; we handle context management in the background. You can also use: `rg` (ripgrep) to navigate/search.
- Do not use Python scripts/one-liners to search the codebase.
"""

    def _normalize_agents_text(self, s: Any) -> str:
        """Normalize AGENTS.md text for comparisons (newline + trailing whitespace)."""
        try:
            if s is None:
                return ""
            if not isinstance(s, str):
                s = str(s)
            s2 = s.replace("\r\n", "\n").replace("\r", "\n")
            return "\n".join([ln.rstrip() for ln in s2.split("\n")]).strip()
        except Exception:
            try:
                return str(s).strip()
            except Exception:
                return ""

    def _load_agents_default_raw(self) -> Optional[str]:
        """Load the default AGENTS.md content.

        Source priority (best-effort):
        1) agents_md_text setting (explicit override)
        2) package-local AGENTS.md next to cli.py
        """
        try:
            override = getattr(self, "agents_md_text", None)
            if isinstance(override, str) and override.strip():
                return override
        except Exception:
            pass
        try:
            p = Path(__file__).resolve().parent / "AGENTS.md"
            if p.exists():
                return p.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            pass
        try:
            return self.DEFAULT_AGENTS_MD_TEMPLATE
        except Exception:
            return None

    def _load_agents_local_raw(self) -> Optional[str]:
        """Load a project-local AGENTS.md under host_base when present."""
        try:
            hb = getattr(self, "host_base", None)
            if not (isinstance(hb, str) and hb.strip()):
                return None
            p = Path(hb).expanduser().resolve() / "AGENTS.md"
            if p.exists():
                return p.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            return None
        return None

    async def _maybe_prompt_agents_prepend_mode(self, trigger: str = "configuration") -> None:
        """Prompt once (during configuration flows only) for how to combine default + local AGENTS.md.

        Note: do NOT call this from normal chat send paths.
        """
        # Only prompt if not already chosen.
        try:
            mode = getattr(self, "agents_prepend_mode", None)
            if mode in ("prepend_default", "local_only"):
                return
        except Exception:
            pass

        # Only prompt when host_base is explicitly configured (not ephemeral per-terminal binding).
        try:
            if bool(getattr(self, "_host_base_ephemeral", False)):
                return
        except Exception:
            pass

        try:
            default_raw = self._agents_default_raw or self._load_agents_default_raw()
        except Exception:
            default_raw = None
        try:
            local_raw = self._load_agents_local_raw()
        except Exception:
            local_raw = None

        if not (isinstance(local_raw, str) and local_raw.strip()):
            return

        # Only prompt on meaningful diffs.
        try:
            if self._normalize_agents_text(local_raw) == self._normalize_agents_text(default_raw or ""):
                # Identical; pick a stable mode to avoid future prompts.
                self.agents_prepend_mode = "local_only"
                try:
                    await self._save_server_settings()
                except Exception:
                    self.save_settings()
                return
        except Exception:
            pass

        choice = await self._menu_choice(
            "AGENTS.md",
            (
                "A local AGENTS.md was found under your Agent scope and it differs from the henosis-cli default.\n"
                "Recommended: prepend the default instructions before your local file."
            ),
            [
                ("prepend_default", "Prepend defaults (recommended): [default] + [local]"),
                ("local_only", "Do not prepend: use local AGENTS.md only"),
            ],
        )
        if choice in ("prepend_default", "local_only"):
            self.agents_prepend_mode = choice
            # Apply on next first turn; do not assume already injected.
            try:
                self._did_inject_agents_md = False
            except Exception:
                pass
            try:
                await self._save_server_settings()
            except Exception:
                self.save_settings()

    async def _ensure_agents_md_on_disk(self, trigger: str = "configuration") -> None:
        """Ensure host_base/AGENTS.md exists and contains the default instructions.

        This runs only during configuration flows (host_base selection / wizard / menus).
        Behavior:
        - If host_base/AGENTS.md is missing: create it with the default AGENTS.md text.
        - If it exists and differs: prepend default text to the existing content.

        Safety:
        - Never runs for ephemeral per-terminal host_base.
        - Never runs during normal chat send paths.
        """
        # Only act when host_base is explicit (not ephemeral).
        try:
            if bool(getattr(self, "_host_base_ephemeral", False)):
                return
        except Exception:
            pass
        try:
            hb = getattr(self, "host_base", None)
            if not (isinstance(hb, str) and hb.strip()):
                return
        except Exception:
            return

        # Resolve default text.
        try:
            default_raw = self._load_agents_default_raw()
            try:
                self._agents_default_raw = default_raw
            except Exception:
                pass
        except Exception:
            default_raw = None
        if not (isinstance(default_raw, str) and default_raw.strip()):
            return

        base = Path(hb).expanduser().resolve()
        path = base / "AGENTS.md"
        try:
            base.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass

        # Create if missing.
        if not path.exists():
            try:
                path.write_text(str(default_raw).rstrip() + "\n", encoding="utf-8")
                # Persist a stable mode to avoid future prompts.
                try:
                    if getattr(self, "agents_prepend_mode", None) is None:
                        self.agents_prepend_mode = "local_only"
                        await self._save_server_settings()
                except Exception:
                    pass
            except Exception:
                return
            return

        # If exists, prepend defaults if needed.
        try:
            local_raw = path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            return

        try:
            norm_default = self._normalize_agents_text(default_raw)
            norm_local = self._normalize_agents_text(local_raw)
        except Exception:
            norm_default = str(default_raw).strip()
            norm_local = str(local_raw).strip()

        if not norm_local:
            # Empty file -> fill with defaults.
            try:
                path.write_text(str(default_raw).rstrip() + "\n", encoding="utf-8")
            except Exception:
                pass
            return

        # Avoid double-prepending when the local file already starts with the defaults.
        try:
            if norm_local.startswith(norm_default):
                return
        except Exception:
            pass

        # Respect explicit opt-out.
        try:
            if getattr(self, "agents_prepend_mode", None) == "local_only":
                return
        except Exception:
            pass

        try:
            new_text = str(default_raw).rstrip() + "\n\n" + str(local_raw).lstrip()
            path.write_text(new_text.rstrip() + "\n", encoding="utf-8")
            # Persist mode so this stays stable.
            try:
                if getattr(self, "agents_prepend_mode", None) is None:
                    self.agents_prepend_mode = "prepend_default"
                await self._save_server_settings()
            except Exception:
                pass
        except Exception:
            return

    def _session_overview(self) -> str:
        """Build a one-line status bar of session settings"""
        parts = [
            f"Server: {self.server}",
            f"Model: {self.model or '(server default)'}",
            f"Tools: {self._tools_label()}",
            f"History: {'ON' if self.save_chat_history else 'OFF'}",
            f"Scope: {self._fs_label()}",
            f"Agent scope: {self.host_base or '(none)'}",
            f"Level: {self.control_level or '(default)'}",
            f"Auto-approve: {','.join(self.auto_approve) if self.auto_approve else '(none)'}",
            f"Reasoning: {self.reasoning_effort}",
            f"Priority: {'ON' if self.service_tier == 'priority' else 'DEFAULT'}",
            f"ThinkBudget: {self.thinking_budget_tokens if self.thinking_budget_tokens else 'default'}",
            f"ThinkInsight: {'ON' if self.thinking_insight_enabled else 'OFF'}",
            f"ThinkSummary: {self.thinking_insight_summary}",
            f"WebSearch: {'ON' if self.web_search_enabled else 'OFF'}",
            f"Map Prefix: {'ON' if self.inject_codebase_map else 'OFF'}",
        ]
        return " | ".join(parts)

    # ----------------------- Auth state persistence ---------------------

    def _load_auth_state_from_disk(self) -> bool:
        """Load persisted cookies from disk if present. Returns True if any were loaded."""
        try:
            p = self.auth_state_file
            if not p.exists():
                # No persisted auth yet; normal on first run
                try:
                    self.ui.debug_log(f"[auth-cli] no auth state file at {p}")
                except Exception:
                    pass
                return False
            data = json.loads(p.read_text(encoding="utf-8"))
            # Load persisted device identity if present
            did = data.get("device_id")
            if isinstance(did, str) and did.strip():
                self.device_id = did.strip()
            dname = data.get("device_name")
            if isinstance(dname, str) and dname.strip():
                self.device_name = dname.strip()
            cookies = data.get("cookies") or []
            loaded_any = False
            # Clear current jar first
            self.cookies.clear()
            for c in cookies:
                try:
                    name = str(c.get("name"))
                    value = str(c.get("value"))
                    domain = c.get("domain") or None
                    path = c.get("path") or "/"
                    # httpx Cookies.set accepts domain/path kwargs
                    if name and value is not None:
                        self.cookies.set(name, value, domain=domain, path=path)
                        loaded_any = True
                except Exception:
                    continue
            # Best-effort: set cached username for UI hint
            au = data.get("auth_user")
            if isinstance(au, str) and au.strip():
                self.auth_user = au.strip()
            try:
                self.ui.debug_log(
                    f"[auth-cli] loaded auth state: user={self.auth_user!r}, device_id={self.device_id!r}, cookies={len(cookies)}"
                )
            except Exception:
                pass
            return loaded_any
        except Exception:
            # Corrupt or unreadable auth state; ignore and start clean
            try:
                self.ui.debug_log("[auth-cli] failed to load auth state from disk; ignoring")
            except Exception:
                pass
            return False

    def _save_auth_state_to_disk(self) -> None:
        """Persist current cookie jar and username to disk."""
        try:
            jar_list = []
            # httpx Cookies jar contains Cookie objects
            jar = getattr(self.cookies, "jar", [])
            # Iterate and extract all cookie data
            try:
                iter_cookies = iter(jar)
            except Exception:
                iter_cookies = []
            for c in iter_cookies:
                try:
                    # Ensure we capture expiration if present
                    cookie_data = {
                        "name": getattr(c, "name", ""),
                        "value": getattr(c, "value", ""),
                        "domain": getattr(c, "domain", None),
                        "path": getattr(c, "path", "/"),
                    }
                    # Add expires if available (as ISO string for JSON)
                    expires = getattr(c, "expires", None)
                    if expires:
                        try:
                            if isinstance(expires, (int, float)):
                                from datetime import datetime, timezone
                                exp_dt = datetime.fromtimestamp(float(expires), tz=timezone.utc)
                                cookie_data["expires"] = exp_dt.isoformat()
                            elif hasattr(expires, 'isoformat'):
                                cookie_data["expires"] = expires.isoformat()
                        except Exception:
                            pass
                    jar_list.append(cookie_data)
                except Exception:
                    continue
            payload = {
                "server": self.server,
                "auth_user": self.auth_user,
                "device_id": self.device_id,
                "device_name": self.device_name,
                "saved_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                "cookies": jar_list,
            }
            self.auth_state_file.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            try:
                self.ui.debug_log(
                    f"[auth-cli] saved auth state: user={self.auth_user!r}, device_id={self.device_id!r}, cookies={len(jar_list)} to {self.auth_state_file}"
                )
            except Exception:
                pass
        except Exception:
            # Non-fatal
            pass

    def _clear_auth_state_on_disk(self) -> None:
        try:
            if self.auth_state_file.exists():
                self.auth_state_file.unlink()
                try:
                    self.ui.debug_log(f"[auth-cli] cleared auth state file {self.auth_state_file}")
                except Exception:
                    pass
        except Exception:
            pass

    # -------------------- Local Codex OAuth state ----------------------

    def _utc_now(self) -> datetime:
        return datetime.now(timezone.utc)

    def _isoformat_utc(self, dt: Optional[datetime]) -> Optional[str]:
        if not isinstance(dt, datetime):
            return None
        try:
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
        except Exception:
            return None

    def _parse_datetime_utc(self, raw: Any) -> Optional[datetime]:
        try:
            if raw is None:
                return None
            if isinstance(raw, (int, float)):
                return datetime.fromtimestamp(float(raw), tz=timezone.utc)
            if not isinstance(raw, str):
                return None
            s = raw.strip()
            if not s:
                return None
            if s.endswith("Z"):
                s = s[:-1] + "+00:00"
            dt = datetime.fromisoformat(s)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.astimezone(timezone.utc)
        except Exception:
            return None

    def _decode_jwt_payload(self, token: Optional[str]) -> Dict[str, Any]:
        try:
            if not token or token.count(".") < 2:
                return {}
            parts = token.split(".")
            payload_part = parts[1]
            rem = len(payload_part) % 4
            if rem:
                payload_part += "=" * (4 - rem)
            decoded = base64.urlsafe_b64decode(payload_part.encode("utf-8"))
            obj = json.loads(decoded.decode("utf-8"))
            if isinstance(obj, dict):
                return obj
            return {}
        except Exception:
            return {}

    def _extract_codex_account_id(self, access_token: Optional[str], id_token: Optional[str]) -> Optional[str]:
        candidates: List[Dict[str, Any]] = []
        try:
            candidates.append(self._decode_jwt_payload(id_token))
        except Exception:
            pass
        try:
            candidates.append(self._decode_jwt_payload(access_token))
        except Exception:
            pass
        for payload in candidates:
            if not isinstance(payload, dict):
                continue
            for key in ("account_id", "chatgpt_account_id"):
                val = payload.get(key)
                if isinstance(val, str) and val.strip():
                    return val.strip()
            auth_obj = payload.get("https://api.openai.com/auth")
            if isinstance(auth_obj, dict):
                for key in ("chatgpt_account_id", "account_id"):
                    val = auth_obj.get(key)
                    if isinstance(val, str) and val.strip():
                        return val.strip()
        return None

    def _extract_codex_email(self, id_token: Optional[str]) -> Optional[str]:
        payload = self._decode_jwt_payload(id_token)
        if not isinstance(payload, dict):
            return None
        val = payload.get("email")
        if isinstance(val, str) and val.strip():
            return val.strip()
        return None

    def _extract_expiry_from_token(self, token: Optional[str]) -> Optional[datetime]:
        payload = self._decode_jwt_payload(token)
        if not isinstance(payload, dict):
            return None
        exp = payload.get("exp")
        if isinstance(exp, (int, float)):
            return self._parse_datetime_utc(float(exp))
        return None

    def _has_codex_auth_material(self) -> bool:
        try:
            return bool(
                (isinstance(self.codex_access_token, str) and self.codex_access_token.strip())
                or (isinstance(self.codex_refresh_token, str) and self.codex_refresh_token.strip())
            )
        except Exception:
            return False

    def _codex_expires_in_seconds(self) -> Optional[int]:
        try:
            if not isinstance(self.codex_expiry_date, datetime):
                return None
            now = self._utc_now()
            if self.codex_expiry_date.tzinfo is None:
                exp = self.codex_expiry_date.replace(tzinfo=timezone.utc)
            else:
                exp = self.codex_expiry_date.astimezone(timezone.utc)
            return int((exp - now).total_seconds())
        except Exception:
            return None

    def _is_codex_access_token_valid(self, min_valid_seconds: int = 60) -> bool:
        try:
            tok = self.codex_access_token
            if not isinstance(tok, str) or not tok.strip():
                return False
            secs = self._codex_expires_in_seconds()
            if secs is None:
                # If expiry is unknown but token exists, allow a request attempt.
                return True
            return secs > int(min_valid_seconds)
        except Exception:
            return False

    def _default_codex_model(self) -> str:
        return "gpt-5.3-codex"

    def _is_codex_local_model(self, model: Optional[str]) -> bool:
        try:
            if not isinstance(model, str) or not model.strip():
                return False
            m = model.strip().lower()
            if m in self.codex_model_allowlist:
                return True
            if bool(getattr(self, "codex_route_all_openai_models", False)) and self._is_openai_model(m):
                return True
            return False
        except Exception:
            return False

    def _clear_codex_backend_rollover(self) -> None:
        self._codex_force_backend_for_conversation = False
        self._codex_backend_rollover_pending_seed = False

    def _activate_codex_backend_rollover(self) -> None:
        self._codex_force_backend_for_conversation = True
        self._codex_backend_rollover_pending_seed = True

    def _seed_openai_input_items_from_codex_local(self) -> bool:
        seed_items: List[Dict[str, Any]] = []
        try:
            if isinstance(self._codex_local_input_items, list) and self._codex_local_input_items:
                seed_items = copy.deepcopy(self._codex_local_input_items)
            elif isinstance(self._codex_local_last_sent_input_items, list) and self._codex_local_last_sent_input_items:
                seed_items = copy.deepcopy(self._codex_local_last_sent_input_items)
                last_item = seed_items[-1] if seed_items else None
                if (
                    isinstance(last_item, dict)
                    and str(last_item.get("role") or "").strip().lower() == "user"
                ):
                    seed_items = seed_items[:-1]

            cleaned = self._sanitize_openai_items(seed_items)
            if not isinstance(cleaned, list):
                cleaned = []
            if cleaned:
                self._openai_previous_response_id = None
                self._openai_response_id_history = []
                self._openai_input_items = cleaned
                self._openai_last_sent_input_items = None
                self._codex_backend_rollover_pending_seed = False
                return True
        except Exception:
            pass
        self._codex_backend_rollover_pending_seed = False
        return False

    def _codex_backend_rollover_label(self) -> Optional[str]:
        try:
            if bool(getattr(self, "_codex_force_backend_for_conversation", False)):
                return "backend credits"
        except Exception:
            pass
        return None

    def _chat_prompt_label(self) -> str:
        label = self._codex_backend_rollover_label()
        if label:
            return f"You [{label}]: "
        return "You: "

    def _queued_user_message_notice(self, queued_count: int) -> str:
        count = max(1, int(queued_count or 0))
        noun = "message" if count == 1 else "messages"
        return (
            f"Queued {count} user {noun}. It will be injected after the next tool action so the agent "
            "can continue what it was doing before considering the new note."
        )

    def _enqueue_user_message(self, text: str, origin: str = "cli", model: Optional[str] = None) -> Dict[str, Any]:
        item = {
            "text": str(text or ""),
            "origin": str(origin or "cli"),
            "model": model or self.model,
            "queued_at": time.time(),
        }
        self._queued_user_messages.append(item)
        return item

    def _consume_queued_user_messages(self) -> List[Dict[str, Any]]:
        try:
            queued = list(self._queued_user_messages or [])
        except Exception:
            queued = []
        self._queued_user_messages = []
        return queued

    def _queued_user_message_texts(self, queued: List[Dict[str, Any]]) -> List[str]:
        texts = [str((item or {}).get("text") or "").strip() for item in (queued or [])]
        return [txt for txt in texts if txt]

    def _queued_user_message_prompt(self, queued: List[Dict[str, Any]]) -> Optional[str]:
        texts = self._queued_user_message_texts(queued)
        if not texts:
            return None
        if len(texts) == 1:
            quoted = json.dumps(texts[0], ensure_ascii=False)
            return (
                "Please continue what you were working on before the user added this message for you to consider as you work: "
                f"{quoted}"
            )
        lines = [
            "Please continue what you were working on before the user added these messages for you to consider as you work:",
        ]
        for idx, txt in enumerate(texts, start=1):
            lines.append(f"{idx}. {json.dumps(txt, ensure_ascii=False)}")
        return "\n".join(lines)

    async def _broadcast_queued_user_message(self, item: Dict[str, Any]) -> None:
        try:
            queued_count = len(self._queued_user_messages)
        except Exception:
            queued_count = 1
        payload = {
            "text": item.get("text"),
            "origin": item.get("origin"),
            "model": item.get("model"),
            "queued_count": queued_count,
            "note": self._queued_user_message_notice(queued_count),
        }
        try:
            await self._ws_broadcast("user.message.queued", payload)
        except Exception:
            pass

    async def _announce_queued_user_message_injection(
        self,
        queued: List[Dict[str, Any]],
        prompt_text: str,
        *,
        announcement: str,
    ) -> None:
        if not (isinstance(prompt_text, str) and prompt_text.strip()):
            return
        try:
            self.ui.info(announcement)
        except Exception:
            pass
        raw_texts = self._queued_user_message_texts(queued)
        try:
            await self._ws_broadcast(
                "user.message.injected",
                {
                    "text": prompt_text,
                    "queued_texts": raw_texts,
                    "origin": "queued",
                    "model": self.model,
                },
            )
        except Exception:
            pass
        for item in queued:
            try:
                raw_text = str((item or {}).get("text") or "").strip()
            except Exception:
                raw_text = ""
            if not raw_text:
                continue
            try:
                self._remote_control_append_message(
                    "user",
                    raw_text,
                    model=(item or {}).get("model") or self.model,
                    origin=str((item or {}).get("origin") or "queued"),
                )
            except Exception:
                pass

    async def _inject_queued_user_messages_into_conversation(
        self,
        conversation_items: List[Dict[str, Any]],
        *,
        announcement: str,
    ) -> Optional[str]:
        queued = self._consume_queued_user_messages()
        prompt_text = self._queued_user_message_prompt(queued)
        if not (isinstance(prompt_text, str) and prompt_text.strip()):
            return None
        await self._announce_queued_user_message_injection(
            queued,
            prompt_text,
            announcement=announcement,
        )
        conversation_items.append({"role": "user", "content": prompt_text})
        return prompt_text

    async def _process_queued_user_messages(self) -> bool:
        prompt_text = await self._inject_queued_user_messages_into_conversation(
            [],
            announcement="Injecting queued user message into the next turn.",
        )
        if not prompt_text:
            return False
        assistant_text = await self._run_stream_with_cancel(prompt_text)
        if self._stream_cancelled:
            partial = self._stream_partial_text or ""
            content_sent = self._last_built_user_content or prompt_text
            self.history.append({"role": "user", "content": content_sent})
            if partial.strip():
                self.history.append({"role": "assistant", "content": partial})
            try:
                self._preserve_provider_state_on_cancel(content_sent, partial)
            except Exception:
                pass
            try:
                if partial.strip():
                    self._remote_control_append_message(
                        "assistant",
                        partial,
                        model=self._last_used_model or self.model,
                        origin="queued",
                    )
            except Exception:
                pass
            self.ui.warn("Interrupted while processing queued user input. Partial response kept in context.")
            return True
        if assistant_text.strip():
            content_sent = self._last_built_user_content or prompt_text
            self.history.append({"role": "user", "content": content_sent})
            self.history.append({"role": "assistant", "content": assistant_text})
            try:
                function_logs, thinking_insight = self._remote_control_last_completed_metadata()
                self._remote_control_append_message(
                    "assistant",
                    assistant_text,
                    model=self._last_used_model or self.model,
                    origin="queued",
                    function_logs=function_logs,
                    thinking_insight=thinking_insight,
                )
            except Exception:
                pass
        return True

    async def _busy_input_loop(self) -> None:
        stop_event = threading.Event()
        self._busy_input_stop_event = stop_event
        reader = self._input_engine.read_message if self._input_engine else self._read_multiline_input
        prompt = self._chat_prompt_label()
        render_prompt_manually = bool(self._input_engine is not None and not hasattr(self._input_engine, "info"))
        while self._busy and (not stop_event.is_set()):
            prev_prompt_active = bool(self._input_prompt_active)
            prev_prompt_label = self._input_prompt_label
            # Keep the queued-input prompt marked active while the background
            # reader is waiting so transient tool chrome never erases the
            # visible "You:" line.
            self._input_prompt_active = True
            self._input_prompt_label = prompt
            try:
                reader_prompt = prompt
                if render_prompt_manually:
                    try:
                        sys.stdout.write(prompt)
                        sys.stdout.flush()
                    except Exception:
                        pass
                    reader_prompt = ""
                text = await asyncio.to_thread(
                    reader,
                    reader_prompt,
                    "",
                    stop_event,
                    self._busy_input_prefill,
                )
                self._busy_input_prefill = ""
            except InputReadInterrupted as interrupted:
                try:
                    self._busy_input_prefill = str(getattr(interrupted, "draft", "") or "")
                except Exception:
                    self._busy_input_prefill = ""
                break
            except EOFError:
                break
            except KeyboardInterrupt:
                if stop_event.is_set() or (not self._busy):
                    break
                self.ui.warn("Busy queue input interrupted.")
                continue
            except Exception:
                break
            finally:
                self._input_prompt_active = prev_prompt_active
                self._input_prompt_label = prev_prompt_label
            if stop_event.is_set() or (not self._busy):
                break
            submitted_text = str(text or "")
            user_text = submitted_text.strip()
            if not user_text:
                continue
            try:
                self._erase_submitted_input_block(prompt, submitted_text)
            except Exception:
                pass
            try:
                self._push_user_input_history(user_text)
            except Exception:
                pass
            queued_item = self._enqueue_user_message(user_text, origin="cli", model=self.model)
            notice = self._queued_user_message_notice(len(self._queued_user_messages))
            self.ui.info(notice)
            try:
                await self._broadcast_queued_user_message(queued_item)
            except Exception:
                pass
        self._busy_input_stop_event = None

    async def _start_busy_input_reader(self) -> None:
        task = self._busy_input_task
        if task is not None and (not task.done()):
            return
        if not self._input_engine:
            return
        try:
            self._busy_input_task = asyncio.create_task(self._busy_input_loop())
        except Exception:
            self._busy_input_task = None

    async def _pause_busy_input_reader_for_output(self) -> bool:
        """Temporarily stop the busy input reader so output can render above it.

        The input engine preserves any draft text in ``self._busy_input_prefill`` via
        ``InputReadInterrupted`` so a subsequent restart can redraw the prompt below
        new output instead of leaving stale ``You:`` chrome above tool lines.
        """
        task = self._busy_input_task
        stop_event = self._busy_input_stop_event
        if task is None or task.done() or stop_event is None:
            return False
        had_prompt = False
        try:
            had_prompt = bool(self._input_prompt_active)
        except Exception:
            had_prompt = False
        try:
            stop_event.set()
        except Exception:
            return False
        try:
            await asyncio.wait_for(task, timeout=1.5)
        except Exception:
            try:
                task.cancel()
            except Exception:
                pass
        finally:
            if self._busy_input_task is task:
                self._busy_input_task = None
            if self._busy_input_stop_event is stop_event:
                self._busy_input_stop_event = None
        if had_prompt:
            try:
                # Best-effort fallback when the input engine couldn't erase its prompt block.
                sys.stdout.write("\r\x1b[2K")
                sys.stdout.flush()
            except Exception:
                pass
        try:
            self._clear_tool_running_transient(newline=False)
        except Exception:
            pass
        return True

    async def _resume_busy_input_reader_after_output(self, should_restart: bool) -> None:
        if not should_restart:
            return
        if not self._busy:
            return
        if not self._input_engine:
            return
        try:
            await self._start_busy_input_reader()
            # Give the background reader a chance to redraw the prompt below the new output.
            await asyncio.sleep(0)
        except Exception:
            pass

    async def _stop_busy_input_reader(self) -> None:
        had_prompt = False
        try:
            had_prompt = bool(self._input_prompt_active)
        except Exception:
            had_prompt = False
        stop_event = self._busy_input_stop_event
        if stop_event is not None:
            try:
                stop_event.set()
            except Exception:
                pass
        task = self._busy_input_task
        self._busy_input_task = None
        if task is not None:
            try:
                await asyncio.wait_for(task, timeout=1.5)
            except Exception:
                try:
                    task.cancel()
                except Exception:
                    pass
        if had_prompt:
            try:
                sys.stdout.write("\r\x1b[2K")
                sys.stdout.flush()
            except Exception:
                pass
        try:
            self._clear_tool_running_transient(newline=False)
        except Exception:
            pass
        try:
            draft = str(self._busy_input_prefill or "")
        except Exception:
            draft = ""
        if draft:
            self._chat_input_prefill = draft

    def _erase_submitted_input_block(self, prompt_label: str, text: str) -> None:
        value = str(text or "")
        if not value:
            return
        try:
            cols = int(shutil.get_terminal_size(fallback=(120, 20)).columns or 120)
        except Exception:
            cols = 120
        cols = max(20, cols)
        try:
            visible_prompt = str(prompt_label or "").rsplit("\n", 1)[-1]
        except Exception:
            visible_prompt = str(prompt_label or "")
        try:
            logical_lines = value.replace("\r\n", "\n").replace("\r", "\n").split("\n")
        except Exception:
            logical_lines = [value]
        rows = 0
        for idx, line in enumerate(logical_lines):
            line_len = len(str(line or ""))
            offset = len(visible_prompt) if idx == 0 else 0
            if line_len <= 0:
                rows += 1
            else:
                rows += ((offset + line_len - 1) // cols) + 1
        rows = max(1, rows)
        try:
            for _ in range(rows):
                sys.stdout.write("\x1b[1A\r\x1b[2K")
            sys.stdout.write("\r")
            sys.stdout.flush()
        except Exception:
            pass

    def _rewrite_submitted_input_line(self, prompt_label: str, text: str) -> None:
        """Normalize the submitted prompt line on Windows agent-mode input.

        When the low-level input engine runs in a worker thread, some terminals can
        race the final Enter/newline against the first streamed assistant output.
        Rewriting the just-submitted prompt line keeps the user's message visible.
        """
        if os.name != "nt":
            return
        value = str(text or "")
        if not value:
            return
        try:
            lines = value.replace("\r\n", "\n").replace("\r", "\n").split("\n")
            sys.stdout.write("\x1b[1A\r\x1b[2K")
            sys.stdout.write(f"{prompt_label}{lines[0]}\n")
            for line in lines[1:]:
                sys.stdout.write(f"{line}\n")
            sys.stdout.flush()
        except Exception:
            pass

    def _render_remote_originated_user_message(self, text: str) -> None:
        prompt_label = self._input_prompt_label or self._chat_prompt_label()
        message = str(text or "")
        if not message.strip():
            return
        try:
            lines = message.replace("\r\n", "\n").replace("\r", "\n").split("\n")
            if self._input_prompt_active:
                sys.stdout.write("\r\x1b[2K")
            sys.stdout.write(f"{prompt_label}{lines[0]}\n")
            for line in lines[1:]:
                sys.stdout.write(f"{line}\n")
            sys.stdout.flush()
        except Exception:
            try:
                self.ui.print(f"{prompt_label}{message}")
            except Exception:
                pass

    async def _render_remote_originated_user_message_below_busy_output(self, text: str) -> None:
        should_restart = False
        try:
            should_restart = await self._pause_busy_input_reader_for_output()
        except Exception:
            should_restart = False
        try:
            self._render_remote_originated_user_message(text)
        finally:
            await self._resume_busy_input_reader_after_output(should_restart)

    def _edit_prompt_label(self) -> str:
        label = self._codex_backend_rollover_label()
        if label:
            return f"Edit [{label}]> "
        return "Edit> "

    def _should_suspend_transient_tool_status(self) -> bool:
        """Avoid line-rewriting tool chrome while an interactive prompt is active."""
        try:
            return bool(self._input_prompt_active)
        except Exception:
            return False

    def _show_waiting_indicator_below_busy_prompt(self) -> bool:
        """Reserve a rainbow waiting line so the busy prompt can redraw underneath it."""
        if not bool(getattr(self, "_thinking_indicator_enabled", False)):
            return False
        try:
            if (not self._busy) or self._input_prompt_active:
                return False
        except Exception:
            return False
        try:
            word_bank = list(self._thinking_words or ["thinking", "working..."])
        except Exception:
            word_bank = ["thinking", "working..."]
        if not word_bank:
            word_bank = ["thinking"]
        try:
            chosen = random.choice(word_bank)
        except Exception:
            chosen = word_bank[0]
        try:
            spacing = int(getattr(self, "_thinking_rainbow_spacing", 3) or 3)
        except Exception:
            spacing = 3
        if spacing < 1:
            spacing = 1
        joiner = " " * max(0, spacing - 1)
        colors = [196, 208, 226, 46, 51, 27, 201]
        out_chars = []
        for i, ch in enumerate(str(chosen)):
            c = colors[i % len(colors)]
            out_chars.append(f"\x1b[38;5;{c}m{ch}\x1b[0m")
        line = " " + joiner.join(out_chars) + " "
        try:
            cols = int(shutil.get_terminal_size(fallback=(120, 20)).columns or 120)
        except Exception:
            cols = 120
        cols = max(40, cols)
        try:
            plain_line = re.sub(r"\x1b\[[0-9;?]*[ -/]*[@-~]", "", line)
        except Exception:
            plain_line = str(chosen)
        visible_width = max(1, len(plain_line))
        try:
            sys.stdout.write("\r\x1b[2K" + line + "\n")
            sys.stdout.flush()
            self._transient_tool_status_active = True
            self._transient_tool_status_rows = max(1, (visible_width + cols - 1) // cols)
            self._transient_tool_status_gap_rows = 1
            return True
        except Exception:
            return False

    def _should_use_local_codex_for_model(self, model: Optional[str]) -> bool:
        try:
            if bool(getattr(self, "_codex_force_backend_for_conversation", False)) and self._is_codex_local_model(model):
                return False
        except Exception:
            pass
        return self._is_codex_local_model(model) and self._has_codex_auth_material()

    def _codex_auth_payload(self) -> Dict[str, Any]:
        return {
            "access_token": self.codex_access_token,
            "refresh_token": self.codex_refresh_token,
            "token_type": self.codex_token_type or "Bearer",
            "expiry_date": self._isoformat_utc(self.codex_expiry_date),
            "account_id": self.codex_account_id,
            "id_token": self.codex_id_token,
            "last_refresh_at": self._isoformat_utc(self.codex_last_refresh_at),
            "email": self.codex_email,
        }

    def _apply_codex_auth_payload(self, payload: Dict[str, Any]) -> None:
        try:
            self.codex_access_token = str(payload.get("access_token") or "").strip() or None
            self.codex_refresh_token = str(payload.get("refresh_token") or "").strip() or None
            self.codex_token_type = str(payload.get("token_type") or "Bearer").strip() or "Bearer"
            self.codex_expiry_date = self._parse_datetime_utc(payload.get("expiry_date"))
            self.codex_account_id = str(payload.get("account_id") or "").strip() or None
            self.codex_id_token = str(payload.get("id_token") or "").strip() or None
            self.codex_last_refresh_at = self._parse_datetime_utc(payload.get("last_refresh_at"))
            self.codex_email = str(payload.get("email") or "").strip() or None
            if not self.codex_account_id:
                self.codex_account_id = self._extract_codex_account_id(self.codex_access_token, self.codex_id_token)
            if not self.codex_email:
                self.codex_email = self._extract_codex_email(self.codex_id_token)
            if not self.codex_expiry_date:
                self.codex_expiry_date = self._extract_expiry_from_token(self.codex_access_token) or self._extract_expiry_from_token(self.codex_id_token)
        except Exception:
            pass

    def _write_json_private(self, path: Path, payload: Dict[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        try:
            os.chmod(path, 0o600)
        except Exception:
            pass

    def _load_codex_auth_state_from_disk(self) -> bool:
        try:
            p = self.codex_auth_file
            if not p.exists():
                return False
            raw = json.loads(p.read_text(encoding="utf-8"))
            if not isinstance(raw, dict):
                return False
            self._apply_codex_auth_payload(raw)
            return self._has_codex_auth_material()
        except Exception:
            return False

    def _save_codex_auth_state_to_disk(self, sync_shared: bool = True) -> None:
        try:
            if not self._has_codex_auth_material():
                return
            payload = self._codex_auth_payload()
            self._write_json_private(self.codex_auth_file, payload)
            if sync_shared:
                self._sync_codex_shared_auth_json()
        except Exception:
            pass

    def _clear_codex_auth_state_on_disk(self, clear_shared: bool = True) -> None:
        self.codex_access_token = None
        self.codex_refresh_token = None
        self.codex_token_type = "Bearer"
        self.codex_expiry_date = None
        self.codex_account_id = None
        self.codex_id_token = None
        self.codex_last_refresh_at = None
        self.codex_email = None
        try:
            if self.codex_auth_file.exists():
                self.codex_auth_file.unlink()
        except Exception:
            pass
        if clear_shared:
            try:
                if self.codex_shared_auth_file.exists():
                    self.codex_shared_auth_file.unlink()
            except Exception:
                pass

    def _sync_codex_shared_auth_json(self) -> None:
        try:
            if not (
                isinstance(self.codex_access_token, str)
                and self.codex_access_token.strip()
                and isinstance(self.codex_refresh_token, str)
                and self.codex_refresh_token.strip()
            ):
                return
            tokens: Dict[str, Any] = {
                "access_token": self.codex_access_token.strip(),
                "refresh_token": self.codex_refresh_token.strip(),
            }
            if isinstance(self.codex_account_id, str) and self.codex_account_id.strip():
                tokens["account_id"] = self.codex_account_id.strip()
            if isinstance(self.codex_id_token, str) and self.codex_id_token.strip():
                tokens["id_token"] = self.codex_id_token.strip()
            payload: Dict[str, Any] = {"auth_mode": "chatgpt", "tokens": tokens}
            lr = self._isoformat_utc(self.codex_last_refresh_at or self._utc_now())
            if lr:
                payload["last_refresh"] = lr
            self._write_json_private(self.codex_shared_auth_file, payload)
        except Exception:
            pass

    def _import_codex_auth_json_if_present(self) -> bool:
        try:
            p = self.codex_shared_auth_file
            if not p.exists():
                return False
            raw = json.loads(p.read_text(encoding="utf-8"))
            if not isinstance(raw, dict):
                return False
            tokens = raw.get("tokens")
            if not isinstance(tokens, dict):
                return False
            access = str(tokens.get("access_token") or "").strip() or None
            refresh = str(tokens.get("refresh_token") or "").strip() or None
            if not (access or refresh):
                return False
            payload: Dict[str, Any] = {
                "access_token": access,
                "refresh_token": refresh,
                "token_type": "Bearer",
                "account_id": str(tokens.get("account_id") or "").strip() or None,
                "id_token": str(tokens.get("id_token") or "").strip() or None,
                "last_refresh_at": raw.get("last_refresh"),
            }
            if not payload.get("account_id"):
                payload["account_id"] = self._extract_codex_account_id(access, payload.get("id_token"))  # type: ignore[arg-type]
            exp = self._extract_expiry_from_token(access) or self._extract_expiry_from_token(payload.get("id_token"))  # type: ignore[arg-type]
            if exp:
                payload["expiry_date"] = self._isoformat_utc(exp)
            self._apply_codex_auth_payload(payload)
            self._save_codex_auth_state_to_disk(sync_shared=False)
            return True
        except Exception:
            return False

    def _generate_pkce_verifier_challenge(self) -> Tuple[str, str]:
        verifier = base64.urlsafe_b64encode(secrets.token_bytes(64)).decode("utf-8").rstrip("=")
        challenge = base64.urlsafe_b64encode(
            hashlib.sha256(verifier.encode("utf-8")).digest()
        ).decode("utf-8").rstrip("=")
        return verifier, challenge

    def _start_codex_oauth_callback_server(self) -> Tuple[HTTPServer, threading.Event, Dict[str, Optional[str]], str]:
        data: Dict[str, Optional[str]] = {
            "code": None,
            "state": None,
            "error": None,
            "error_description": None,
        }
        done = threading.Event()
        callback_path = getattr(self, "codex_oauth_callback_path", "/auth/callback") or "/auth/callback"

        class _CallbackHandler(BaseHTTPRequestHandler):
            def log_message(self, _format: str, *_args: Any) -> None:
                return

            def do_GET(self) -> None:  # noqa: N802
                parsed = urlparse(self.path)
                if parsed.path != callback_path:
                    body = """<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>henosis-cli | Not Found</title>
  <style>
    :root {
      --bg-a: #0b1020;
      --bg-b: #121f3d;
      --ink: #e8eefb;
      --muted: #9fb2d7;
      --card: rgba(17, 26, 46, 0.78);
      --edge: rgba(176, 199, 238, 0.22);
      --warn: #f59e0b;
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      min-height: 100vh;
      display: grid;
      place-items: center;
      font-family: "Avenir Next", "Gill Sans", "Trebuchet MS", sans-serif;
      color: var(--ink);
      background:
        radial-gradient(1200px 700px at 10% -20%, #22447c 0%, transparent 55%),
        radial-gradient(900px 600px at 95% 110%, #14532d 0%, transparent 50%),
        linear-gradient(160deg, var(--bg-a), var(--bg-b));
      padding: 20px;
    }
    .card {
      width: min(560px, 100%);
      border: 1px solid var(--edge);
      background: var(--card);
      backdrop-filter: blur(8px);
      border-radius: 18px;
      padding: 28px;
      box-shadow: 0 24px 80px rgba(0, 0, 0, 0.35);
    }
    .eyebrow {
      display: inline-block;
      padding: 4px 10px;
      border-radius: 999px;
      font-size: 12px;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: #281800;
      background: linear-gradient(135deg, #fbbf24, var(--warn));
      font-weight: 700;
    }
    h1 {
      margin: 14px 0 8px;
      font-size: clamp(22px, 3vw, 30px);
      line-height: 1.1;
    }
    p {
      margin: 0;
      color: var(--muted);
      font-size: 16px;
      line-height: 1.6;
    }
  </style>
</head>
<body>
  <main class="card">
    <span class="eyebrow">Local OAuth</span>
    <h1>Route Not Found</h1>
    <p>This page is only used for the henosis-cli OAuth callback.</p>
  </main>
</body>
</html>"""
                    self.send_response(404)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                    self.send_header("Content-Length", str(len(body.encode("utf-8"))))
                    self.end_headers()
                    self.wfile.write(body.encode("utf-8"))
                    return
                q = parse_qs(parsed.query or "")
                data["code"] = (q.get("code") or [None])[0]
                data["state"] = (q.get("state") or [None])[0]
                data["error"] = (q.get("error") or [None])[0]
                data["error_description"] = (q.get("error_description") or [None])[0]
                done.set()
                had_error = bool(isinstance(data.get("error"), str) and str(data.get("error")).strip())
                headline = "Sign-in Complete" if not had_error else "Sign-in Interrupted"
                subtitle = (
                    "Codex authentication was received by henosis-cli. You can close this tab and return to your terminal."
                    if not had_error
                    else "The callback was received, but OAuth returned an error. Return to the terminal for details."
                )
                tone_class = "ok" if not had_error else "warn"
                badge_text = "Connected" if not had_error else "Needs Attention"
                body = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>henosis-cli | Codex Login</title>
  <style>
    :root {{
      --bg: #0c0c0c;
      --panel: rgba(22, 22, 22, 0.92);
      --panel-soft: rgba(42, 42, 42, 0.6);
      --border: rgba(255, 255, 255, 0.08);
      --border-strong: rgba(249, 115, 22, 0.28);
      --ink: #ffffff;
      --muted: #9ca3af;
      --muted-2: #6b7280;
      --accent: #f97316;
      --accent-soft: rgba(249, 115, 22, 0.12);
      --accent-strong: rgba(249, 115, 22, 0.24);
      --success: #22c55e;
      --warning: #f59e0b;
      --shadow: 0 32px 100px rgba(0, 0, 0, 0.52);
      --glass-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.04);
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0;
      min-height: 100vh;
      display: grid;
      place-items: center;
      overflow: hidden;
      font-family: Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      color: var(--ink);
      background: var(--bg);
      padding: 24px;
    }}
    body::before,
    body::after {{
      content: "";
      position: fixed;
      inset: auto;
      border-radius: 999px;
      pointer-events: none;
      filter: blur(120px);
      z-index: 0;
    }}
    body::before {{
      top: -12%;
      right: -10%;
      width: 44vw;
      height: 44vw;
      min-width: 280px;
      min-height: 280px;
      background: rgba(249, 115, 22, 0.13);
    }}
    body::after {{
      bottom: -18%;
      left: -12%;
      width: 42vw;
      height: 42vw;
      min-width: 260px;
      min-height: 260px;
      background: rgba(59, 130, 246, 0.08);
    }}
    .shell {{
      position: relative;
      z-index: 1;
      width: min(980px, 100%);
    }}
    .card {{
      position: relative;
      overflow: hidden;
      border-radius: 28px;
      border: 1px solid var(--border);
      background: linear-gradient(180deg, rgba(20, 20, 20, 0.96), rgba(12, 12, 12, 0.98));
      box-shadow: var(--shadow), var(--glass-shadow);
      backdrop-filter: blur(14px);
    }}
    .card::before {{
      content: "";
      position: absolute;
      inset: 0;
      background: linear-gradient(135deg, rgba(249, 115, 22, 0.08), transparent 34%, transparent 70%, rgba(59, 130, 246, 0.06));
      pointer-events: none;
    }}
    .hero {{
      position: relative;
      display: grid;
      grid-template-columns: minmax(0, 1.2fr) minmax(320px, 0.88fr);
      gap: 28px;
      padding: 34px;
    }}
    .copy {{
      display: flex;
      flex-direction: column;
      gap: 20px;
      min-width: 0;
    }}
    .eyebrow {{
      display: inline-flex;
      align-items: center;
      gap: 10px;
      width: fit-content;
      padding: 7px 14px;
      border-radius: 999px;
      border: 1px solid var(--border-strong);
      background: var(--accent-soft);
      color: var(--accent);
      font-size: 12px;
      font-weight: 700;
      letter-spacing: 0.08em;
      text-transform: uppercase;
    }}
    .eyebrow-dot {{
      width: 9px;
      height: 9px;
      border-radius: 999px;
      background: currentColor;
      box-shadow: 0 0 0 6px rgba(249, 115, 22, 0.18);
    }}
    .badge {{
      display: inline-flex;
      align-items: center;
      gap: 8px;
      width: fit-content;
      border-radius: 999px;
      font-size: 12px;
      font-weight: 700;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      padding: 6px 12px;
      border: 1px solid transparent;
    }}
    .badge::before {{
      content: "";
      width: 8px;
      height: 8px;
      border-radius: 999px;
      background: currentColor;
      box-shadow: 0 0 0 5px color-mix(in srgb, currentColor 18%, transparent);
    }}
    .badge.ok {{
      color: var(--success);
      background: rgba(34, 197, 94, 0.12);
      border-color: rgba(34, 197, 94, 0.22);
    }}
    .badge.warn {{
      color: var(--warning);
      background: rgba(245, 158, 11, 0.12);
      border-color: rgba(245, 158, 11, 0.22);
    }}
    h1 {{
      margin: 0;
      font-size: clamp(2.4rem, 4vw, 4.5rem);
      line-height: 1.02;
      font-weight: 700;
      letter-spacing: -0.04em;
    }}
    .accent-line {{
      display: block;
      margin-top: 6px;
      background: linear-gradient(90deg, var(--accent), #fb923c 45%, #fbbf24 100%);
      -webkit-background-clip: text;
      background-clip: text;
      color: transparent;
    }}
    .subtitle {{
      margin: 0;
      max-width: 58ch;
      color: var(--muted);
      font-size: 17px;
      line-height: 1.72;
    }}
    .actions {{
      display: flex;
      flex-wrap: wrap;
      gap: 14px;
      align-items: center;
    }}
    button {{
      border: 0;
      border-radius: 14px;
      padding: 13px 18px;
      font-size: 15px;
      font-weight: 600;
      color: #fff;
      background: linear-gradient(135deg, var(--accent), #ea580c);
      box-shadow: 0 16px 40px rgba(249, 115, 22, 0.22);
      cursor: pointer;
      transition: transform 140ms ease, box-shadow 160ms ease, filter 160ms ease;
      white-space: nowrap;
    }}
    button:hover {{
      transform: translateY(-1px);
      box-shadow: 0 22px 46px rgba(249, 115, 22, 0.3);
      filter: brightness(1.03);
    }}
    button:active {{
      transform: translateY(0);
    }}
    .hint {{
      margin: 0;
      color: var(--muted);
      font-size: 14px;
      line-height: 1.65;
    }}
    .stats {{
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 16px;
      padding-top: 18px;
      border-top: 1px solid rgba(255, 255, 255, 0.08);
    }}
    .stat {{
      min-width: 0;
    }}
    .stat strong {{
      display: block;
      margin-bottom: 4px;
      font-size: 1.35rem;
      color: var(--ink);
    }}
    .stat span {{
      color: var(--muted-2);
      font-size: 12px;
      letter-spacing: 0.04em;
      text-transform: uppercase;
    }}
    .preview-wrap {{
      position: relative;
      min-width: 0;
      display: flex;
      align-items: stretch;
    }}
    .preview-shell {{
      width: 100%;
      padding: 8px;
      border-radius: 22px;
      background: var(--panel-soft);
      border: 1px solid var(--border);
      box-shadow: var(--glass-shadow);
      backdrop-filter: blur(14px);
    }}
    .preview {{
      overflow: hidden;
      border-radius: 18px;
      border: 1px solid rgba(255, 255, 255, 0.06);
      background: #0b0b0b;
    }}
    .preview-top {{
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 12px 16px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.06);
      background: #111111;
    }}
    .traffic {{
      display: flex;
      gap: 6px;
    }}
    .traffic span {{
      width: 10px;
      height: 10px;
      border-radius: 999px;
      border: 1px solid rgba(255, 255, 255, 0.14);
      background: rgba(255, 255, 255, 0.08);
    }}
    .traffic span:nth-child(1) {{ background: rgba(239, 68, 68, 0.25); border-color: rgba(239, 68, 68, 0.45); }}
    .traffic span:nth-child(2) {{ background: rgba(234, 179, 8, 0.22); border-color: rgba(234, 179, 8, 0.38); }}
    .traffic span:nth-child(3) {{ background: rgba(34, 197, 94, 0.22); border-color: rgba(34, 197, 94, 0.38); }}
    .preview-title {{
      color: var(--muted-2);
      font-size: 12px;
      letter-spacing: 0.05em;
      text-transform: uppercase;
    }}
    .terminal {{
      padding: 18px 18px 20px;
      font-family: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, monospace;
      font-size: 13px;
      line-height: 1.7;
      color: #e5e7eb;
    }}
    .line {{
      display: flex;
      gap: 10px;
      align-items: flex-start;
    }}
    .line + .line {{ margin-top: 10px; }}
    .prompt {{ color: #22c55e; }}
    .accent {{ color: var(--accent); }}
    .muted {{ color: var(--muted-2); }}
    .terminal-block {{
      margin-top: 14px;
      padding: 12px 14px;
      border-radius: 14px;
      background: rgba(255, 255, 255, 0.04);
      border: 1px solid rgba(255, 255, 255, 0.06);
    }}
    .terminal-label {{
      display: inline-flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 8px;
      color: #60a5fa;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.1em;
      text-transform: uppercase;
    }}
    .terminal-label::before {{
      content: "";
      width: 8px;
      height: 8px;
      border-radius: 999px;
      background: currentColor;
    }}
    .terminal-label.analysis {{ color: #c084fc; }}
    .terminal-label.complete {{ color: var(--accent); }}
    .floating {{
      position: absolute;
      right: -10px;
      bottom: -18px;
      display: inline-flex;
      align-items: center;
      gap: 12px;
      padding: 12px 14px;
      border-radius: 16px;
      border: 1px solid var(--border);
      background: var(--panel-soft);
      box-shadow: var(--shadow), var(--glass-shadow);
      backdrop-filter: blur(14px);
    }}
    .floating-icon {{
      width: 38px;
      height: 38px;
      display: grid;
      place-items: center;
      border-radius: 999px;
      background: linear-gradient(135deg, var(--accent), #ea580c);
      color: #fff;
      font-weight: 700;
      box-shadow: 0 12px 28px rgba(249, 115, 22, 0.28);
    }}
    .floating strong {{
      display: block;
      font-size: 13px;
      color: var(--ink);
    }}
    .floating span {{
      display: block;
      margin-top: 2px;
      font-size: 12px;
      color: var(--muted);
    }}
    @media (max-width: 940px) {{
      .hero {{
        grid-template-columns: 1fr;
      }}
      .preview-wrap {{
        order: -1;
      }}
      .floating {{
        position: static;
        margin-top: 14px;
      }}
    }}
    @media (max-width: 640px) {{
      body {{ padding: 16px; }}
      .hero {{ padding: 22px; gap: 22px; }}
      .actions {{ flex-direction: column; align-items: stretch; }}
      button {{ width: 100%; }}
      .stats {{ grid-template-columns: 1fr; }}
    }}
  </style>
</head>
<body>
  <main class="shell" role="main" aria-live="polite">
    <section class="card">
      <div class="hero">
        <div class="copy">
          <span class="eyebrow"><span class="eyebrow-dot"></span>Codex linked locally</span>
          <span class="badge {tone_class}">{badge_text}</span>
          <div>
            <h1>{headline}<span class="accent-line">Terminal-ready.</span></h1>
          </div>
          <p class="subtitle">{subtitle}</p>
          <div class="actions">
            <button id="close-btn" type="button">Return to henosis-cli</button>
            <p class="hint" id="close-hint">You can close this tab and keep building in your terminal.</p>
          </div>
          <div class="stats" aria-label="Session details">
            <div class="stat">
              <strong>OAuth</strong>
              <span>Local callback complete</span>
            </div>
            <div class="stat">
              <strong>Codex</strong>
              <span>Linked to henosis-cli</span>
            </div>
            <div class="stat">
              <strong>Ready</strong>
              <span>Return to the terminal</span>
            </div>
          </div>
        </div>
        <div class="preview-wrap" aria-hidden="true">
          <div class="preview-shell">
            <div class="preview">
              <div class="preview-top">
                <div class="traffic"><span></span><span></span><span></span></div>
                <div class="preview-title">henosis-cli - codex local</div>
              </div>
              <div class="terminal">
                <div class="line"><span class="prompt">$</span><span>henosis-cli /codex login</span></div>
                <div class="line"><span class="muted">[oauth]</span><span>Browser flow completed. Tokens saved locally.</span></div>
                <div class="terminal-block">
                  <div class="terminal-label">Link status</div>
                  <div><span class="accent">Codex</span> is now connected for local terminal turns.</div>
                </div>
                <div class="terminal-block">
                  <div class="terminal-label analysis">Next step</div>
                  <div>Close this page, return to your terminal, and continue the session.</div>
                </div>
                <div class="terminal-block">
                  <div class="terminal-label complete">Ready</div>
                  <div><span class="prompt">&gt;</span> Resume coding with your linked Codex workflow.</div>
                </div>
              </div>
            </div>
          </div>
          <div class="floating">
            <div class="floating-icon">&gt;_</div>
            <div>
              <strong>Terminal integrated</strong>
              <span>Close this tab and continue locally</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>
  <script>
    (function() {{
      function closeTab() {{
        // Some browsers only allow close() for script-opened tabs.
        // Try the broadest compatible sequence, then fall back gracefully.
        try {{ window.open("", "_self"); }} catch (e) {{}}
        try {{ window.close(); }} catch (e) {{}}
        setTimeout(function() {{
          if (!document.hidden) {{
            var hint = document.getElementById("close-hint");
            if (hint) {{
              hint.textContent = "Your browser blocked automatic closing. You can safely close this tab now.";
            }}
            try {{ window.location.replace("about:blank"); }} catch (e) {{}}
          }}
        }}, 150);
      }}
      var btn = document.getElementById("close-btn");
      if (btn) {{
        btn.addEventListener("click", closeTab);
      }}
    }})();
  </script>
</body>
</html>"""
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body.encode("utf-8"))))
                self.end_headers()
                self.wfile.write(body.encode("utf-8"))

        host = str(getattr(self, "codex_oauth_callback_host", "127.0.0.1") or "127.0.0.1")
        port = int(getattr(self, "codex_oauth_callback_port", 1455) or 1455)
        try:
            server = HTTPServer((host, port), _CallbackHandler)
        except Exception as e:
            raise RuntimeError(
                f"Could not bind Codex OAuth callback server on {host}:{port}{callback_path} ({e})"
            ) from e
        redirect_host = "localhost" if host in ("127.0.0.1", "::1") else host
        redirect_uri = f"http://{redirect_host}:{port}{callback_path}"
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        return server, done, data, redirect_uri

    def _apply_codex_token_response(self, token_data: Dict[str, Any], refreshed: bool = False) -> None:
        now = self._utc_now()
        try:
            at = token_data.get("access_token")
            rt = token_data.get("refresh_token")
            tt = token_data.get("token_type")
            idt = token_data.get("id_token")
            exp_in = token_data.get("expires_in")
            if isinstance(at, str) and at.strip():
                self.codex_access_token = at.strip()
            if isinstance(rt, str) and rt.strip():
                self.codex_refresh_token = rt.strip()
            if isinstance(tt, str) and tt.strip():
                self.codex_token_type = tt.strip()
            if isinstance(idt, str) and idt.strip():
                self.codex_id_token = idt.strip()
            expiry = self._parse_datetime_utc(token_data.get("expiry_date"))
            if not expiry and isinstance(exp_in, (int, float)):
                try:
                    expiry = now + timedelta(seconds=int(exp_in))
                except Exception:
                    expiry = None
            if not expiry:
                expiry = self._extract_expiry_from_token(self.codex_access_token) or self._extract_expiry_from_token(self.codex_id_token)
            self.codex_expiry_date = expiry
            account_id = token_data.get("account_id")
            if isinstance(account_id, str) and account_id.strip():
                self.codex_account_id = account_id.strip()
            else:
                self.codex_account_id = self._extract_codex_account_id(self.codex_access_token, self.codex_id_token)
            self.codex_email = self._extract_codex_email(self.codex_id_token)
            self.codex_last_refresh_at = now
        except Exception:
            pass

    async def _exchange_codex_oauth_code(
        self, code: str, verifier: str, redirect_uri: str
    ) -> bool:
        try:
            timeout = (
                httpx.Timeout(connect=10.0, read=30.0, write=10.0, pool=10.0)
                if self.timeout is None
                else httpx.Timeout(self.timeout)
            )
            form = {
                "grant_type": "authorization_code",
                "client_id": self.codex_oauth_client_id,
                "code": code,
                "redirect_uri": redirect_uri,
                "code_verifier": verifier,
            }
            headers = {
                "Accept": "application/json",
                "Content-Type": "application/x-www-form-urlencoded",
            }
            async with httpx.AsyncClient(timeout=timeout) as client:
                resp = await client.post(self.codex_token_url, data=form, headers=headers)
            if resp.status_code >= 400:
                try:
                    msg = resp.json()
                except Exception:
                    msg = resp.text
                self.ui.warn(f"Codex token exchange failed ({resp.status_code}): {self._clip(str(msg), 320)}")
                return False
            data = resp.json() if resp.headers.get("content-type", "").startswith("application/json") else {}
            if not isinstance(data, dict):
                self.ui.warn("Codex token exchange returned unexpected payload.")
                return False
            self._apply_codex_token_response(data)
            if not self._has_codex_auth_material():
                self.ui.warn("Codex token exchange did not return usable credentials.")
                return False
            self._save_codex_auth_state_to_disk(sync_shared=True)
            return True
        except Exception as e:
            self.ui.warn(f"Codex token exchange error: {e}")
            return False

    async def _refresh_codex_access_token(
        self, client: Optional[httpx.AsyncClient] = None
    ) -> bool:
        if not (isinstance(self.codex_refresh_token, str) and self.codex_refresh_token.strip()):
            return False
        own_client = client is None
        if own_client:
            timeout = (
                httpx.Timeout(connect=10.0, read=30.0, write=10.0, pool=10.0)
                if self.timeout is None
                else httpx.Timeout(self.timeout)
            )
            client = httpx.AsyncClient(timeout=timeout)
        try:
            form = {
                "grant_type": "refresh_token",
                "client_id": self.codex_oauth_client_id,
                "refresh_token": self.codex_refresh_token,
            }
            headers = {
                "Accept": "application/json",
                "Content-Type": "application/x-www-form-urlencoded",
            }
            assert client is not None
            resp = await client.post(self.codex_token_url, data=form, headers=headers)
            if resp.status_code >= 400:
                if resp.status_code in (400, 401, 403):
                    # Refresh token is likely invalid; require re-login.
                    self._clear_codex_auth_state_on_disk(clear_shared=False)
                return False
            data = resp.json() if resp.headers.get("content-type", "").startswith("application/json") else {}
            if not isinstance(data, dict):
                return False
            self._apply_codex_token_response(data, refreshed=True)
            if not self._has_codex_auth_material():
                return False
            self._save_codex_auth_state_to_disk(sync_shared=True)
            return True
        except Exception:
            return False
        finally:
            if own_client and client is not None:
                try:
                    await client.aclose()
                except Exception:
                    pass

    async def _ensure_codex_access_token(
        self, min_valid_seconds: int = 60, client: Optional[httpx.AsyncClient] = None
    ) -> Optional[str]:
        if self._is_codex_access_token_valid(min_valid_seconds=min_valid_seconds):
            return self.codex_access_token
        ok = await self._refresh_codex_access_token(client=client)
        if ok and self._is_codex_access_token_valid(min_valid_seconds=0):
            return self.codex_access_token
        return None

    def _render_codex_status(self) -> None:
        has_creds = self._has_codex_auth_material()
        valid = self._is_codex_access_token_valid(min_valid_seconds=60)
        exp_secs = self._codex_expires_in_seconds()
        if isinstance(exp_secs, int):
            if exp_secs >= 0:
                exp_msg = f"{exp_secs}s"
            else:
                exp_msg = f"expired {-exp_secs}s ago"
        else:
            exp_msg = "unknown"
        aid = self.codex_account_id or "(unknown)"
        if isinstance(aid, str) and len(aid) > 10:
            aid = f"{aid[:6]}...{aid[-4:]}"
        lines = [
            f"Credentials: {'present' if has_creds else 'missing'}",
            f"Access token: {'valid' if valid else 'missing/expired'}",
            f"Account ID: {aid}",
            f"Expires in: {exp_msg}",
            f"OAuth client_id: {self.codex_oauth_client_id}",
            f"OAuth callback: http://localhost:{self.codex_oauth_callback_port}{self.codex_oauth_callback_path}",
            f"Local auth file: {self.codex_auth_file}",
            f"Shared auth file: {self.codex_shared_auth_file}",
        ]
        self.ui.info_box("Codex OAuth", lines)

    async def _codex_login(self) -> bool:
        server: Optional[HTTPServer] = None
        done_evt: Optional[threading.Event] = None
        callback_data: Dict[str, Optional[str]] = {}
        redirect_uri = ""
        verifier, challenge = self._generate_pkce_verifier_challenge()
        state = secrets.token_urlsafe(24)
        try:
            try:
                server, done_evt, callback_data, redirect_uri = self._start_codex_oauth_callback_server()
            except Exception as e:
                self.ui.warn(f"Codex login failed: {e}")
                return False
            params = {
                "response_type": "code",
                "client_id": self.codex_oauth_client_id,
                "redirect_uri": redirect_uri,
                "scope": self.codex_oauth_scope,
                "code_challenge": challenge,
                "code_challenge_method": "S256",
                "state": state,
                # Matches upstream helper behavior for Codex web auth.
                "prompt": "login",
                "id_token_add_organizations": "true",
                "codex_cli_simplified_flow": "true",
            }
            auth_url = f"{self.codex_authorize_url}?{urlencode(params)}"
            opened = False
            try:
                opened = bool(webbrowser.open(auth_url, new=2, autoraise=True))
            except Exception:
                opened = False
            if opened:
                self.ui.info("Opened browser for Codex login. Complete the flow to continue.")
            else:
                self.ui.info("Open this URL to continue Codex login:")
                self.ui.print(auth_url, style=self.ui.theme["dim"])

            timeout_s = 240
            started = time.time()
            while done_evt is not None and (not done_evt.is_set()) and (time.time() - started < timeout_s):
                await asyncio.sleep(0.2)

            if done_evt is None or not done_evt.is_set():
                self.ui.warn("No OAuth callback received automatically.")
                pasted = self.ui.prompt("Paste the full callback URL")
                parsed = urlparse(pasted.strip())
                q = parse_qs(parsed.query or "")
                callback_data["code"] = (q.get("code") or [None])[0]
                callback_data["state"] = (q.get("state") or [None])[0]
                callback_data["error"] = (q.get("error") or [None])[0]
                callback_data["error_description"] = (q.get("error_description") or [None])[0]

            err = callback_data.get("error")
            if isinstance(err, str) and err.strip():
                desc = callback_data.get("error_description") or ""
                self.ui.warn(f"Codex login failed: {err}{(': ' + str(desc)) if desc else ''}")
                return False
            returned_state = callback_data.get("state")
            if not (isinstance(returned_state, str) and returned_state == state):
                self.ui.warn("Codex login failed: invalid OAuth state.")
                return False
            code = callback_data.get("code")
            if not (isinstance(code, str) and code.strip()):
                self.ui.warn("Codex login failed: callback did not include an authorization code.")
                return False
            ok = await self._exchange_codex_oauth_code(code.strip(), verifier, redirect_uri)
            if not ok:
                return False
            self.ui.success("Codex OAuth login successful.")
            if not self.model:
                self.model = self._default_codex_model()
                self._apply_model_side_effects()
                self.ui.info(f"Model set to: {self.model}")
            return True
        finally:
            if server is not None:
                try:
                    # Prevent occasional UI stalls if shutdown blocks.
                    await asyncio.wait_for(asyncio.to_thread(server.shutdown), timeout=2.0)
                except Exception:
                    pass
                try:
                    await asyncio.wait_for(asyncio.to_thread(server.server_close), timeout=1.0)
                except Exception:
                    pass

    # -------------------------- Menu helpers ---------------------------

    def _tools_label(self) -> str:
        if self.requested_tools is True:
            return "ON (per request)"
        if self.requested_tools is False:
            return "OFF (per request)"
        return "SERVER DEFAULT"

    def _fs_label(self) -> str:
        if self.fs_scope is None:
            return "SERVER DEFAULT"
        return self.fs_scope.upper()

    def _build_commands_catalog(self) -> List[Dict[str, str]]:
        cmds = [
            {"name": "/settings", "usage": "/settings", "desc": "Open settings menu"},
            {"name": "/configure", "usage": "/configure", "desc": "Run configuration wizard now"},
            {"name": "/history", "usage": "/history on|off", "desc": "Toggle saving chat history to unified memory"},
            {"name": "/infomode", "usage": "/infomode concise|verbose", "desc": "Set Usage & Info panel mode"},
            {"name": "/statuslayout", "usage": "/statuslayout auto|line|panel", "desc": "Set post-turn status layout"},
            {"name": "/statusfields", "usage": "/statusfields show|set <csv>|preset concise|verbose|clear", "desc": "Configure post-turn status fields"},
            {"name": "/tools", "usage": "/tools on|off|default", "desc": "Toggle per-request tools"},
            {"name": "/websearch", "usage": "/websearch on|off|domains|sources|location", "desc": "Configure OpenAI web search"},
            {"name": "/priority", "usage": "/priority on|off|default", "desc": "Toggle OpenAI/Codex priority processing"},
            {"name": "/fast", "usage": "/fast on|off|default", "desc": "Alias for /priority"},
            {"name": "/reasoning", "usage": "/reasoning low|medium|high|xhigh", "desc": "Set OpenAI reasoning effort (default: medium; xhigh supported on gpt-5.4*)"},
            {"name": "/thinkingbudget", "usage": "/thinkingbudget <tokens>|default", "desc": "Set Anthropic thinking budget tokens for -thinking models"},
            {"name": "/thinkinginsight", "usage": "/thinkinginsight on|off", "desc": "Toggle optional provider thinking insight display"},
            {"name": "/fs", "usage": "/fs workspace|host|default", "desc": "Set filesystem scope"},
            {"name": "/agent-scope", "usage": "/agent-scope <absolute path>", "desc": "Alias for /hostbase (set Agent scope)"},
            {"name": "/hostmode", "usage": "/hostmode any|cwd|custom", "desc": "Set host directory mode (client-enforced roots)"},
            {"name": "/trust", "usage": "/trust", "desc": "Manage Level 2 trust (tools/commands)"},
            {"name": "/model", "usage": "/model [name]", "desc": "Open settings model picker (no arg) or set directly"},
            {"name": "/level", "usage": "/level 1|2|3", "desc": "Set control level"},
            {"name": "/autoapprove", "usage": "/autoapprove name1,name2", "desc": "Auto-approve tools at L2"},
            {"name": "/system", "usage": "/system <text>", "desc": "Set system prompt"},
            {"name": "/title", "usage": "/title <name>", "desc": "Set thread title"},
            {"name": "/clear", "usage": "/clear", "desc": "Clear chat history"},
            {"name": "/new", "usage": "/new", "desc": "Alias for /clear (new chat)"},
            {"name": "/toolslog", "usage": "/toolslog", "desc": "Toggle tool call logs"},
            {"name": "/map", "usage": "/map on|off", "desc": "Toggle codebase map prefix"},
            {"name": "/login", "usage": "/login", "desc": "Log in"},
            {"name": "/logout", "usage": "/logout", "desc": "Log out"},
            {"name": "/codex login", "usage": "/codex login", "desc": "Log in with local OpenAI Codex OAuth"},
            {"name": "/codex status", "usage": "/codex status", "desc": "Show local Codex OAuth status"},
            {"name": "/codex logout", "usage": "/codex logout", "desc": "Clear local Codex OAuth credentials"},
            {"name": "/whoami", "usage": "/whoami", "desc": "Show authentication status"},
        ]
        return cmds

    def _model_presets(self) -> List[Tuple[str, str]]:
        """Shared list of (model, label) used by settings UI and /model menu."""
        # Ordered in "feelings" order (Recommended first, then Others).
        # NOTE: We intentionally do not include a "server default" or "custom" option here.
        return [
            # Recommended
            ("gpt-5.4", "OpenAI: gpt-5.4"),
            ("gpt-5.4-mini-2026-03-17", "OpenAI: gpt-5.4-mini-2026-03-17"),
            ("gpt-5.3-codex", "OpenAI: gpt-5.3-codex"),
            ("gpt-5", "OpenAI: gpt-5"),
            ("gemini-3.1-pro-preview", "Gemini: gemini-3.1-pro-preview"),
            ("gemini-3-flash-preview", "Gemini: gemini-3-flash-preview"),
            ("claude-sonnet-4-6", "Anthropic: claude-sonnet-4-6 (adaptive thinking supported)"),
            ("claude-opus-4-6", "Anthropic: claude-opus-4-6 (adaptive thinking supported)"),
            ("kimi-k2.5", "Kimi: kimi-k2.5"),
            ("grok-4.20-beta-0309-reasoning", "xAI: grok-4.20-beta-0309-reasoning"),

            # Others
            ("gpt-5.4-pro", "OpenAI: gpt-5.4-pro (streaming, very expensive)"),
            ("gpt-5.4-nano-2026-03-17", "OpenAI: gpt-5.4-nano-2026-03-17"),
            ("grok-4.20-beta-0309-reasoning", "xAI: grok-4.20-beta-0309-reasoning"),
            ("deepseek-reasoner-3.2", "DeepSeek: deepseek-reasoner 3.2"),
            ("deepseek-chat-3.2", "DeepSeek: deepseek-chat 3.2"),
            ("glm-4.7", "GLM: glm-4.7"),
        ]

    async def open_settings(self, focus: Optional[str] = None) -> None:
        """Open the new dependency-free settings UI. Falls back to legacy only when
        HENOSIS_SETTINGS_LEGACY=1 is set or the UI module is unavailable.
        """
        use_legacy = os.getenv("HENOSIS_SETTINGS_LEGACY", "").strip() in ("1", "true", "yes")
        if (not HAS_SETTINGS_UI) or use_legacy:
            # Legacy path: use the old menu loop
            while True:
                choice = await self.main_menu()
                try:
                    cont = await self.handle_choice(choice)
                except SystemExit:
                    raise
                except Exception as e:
                    self.ui.error(f"[menu error] {e}")
                    cont = True
                if not cont:
                    break
            return

        # Build defaults map for reset behavior
        defaults: Dict[str, Any] = {
            "model": None,
            "requested_tools": None,
            "fs_scope": None,
            "host_base": None,
            "fs_host_mode": None,
            "system_prompt": None,
            "show_tool_calls": True,
            "max_dir_items": 12,
            "control_level": None,
            "auto_approve": [],
            "trust_tools_always": [],
            "trust_tools_session": [],
            "trust_cmds_always": [],
            "trust_cmds_session": [],
            "inject_codebase_map": True,
            # AGENTS.md (Issue #12)
            "inject_agents_md": True,
            "agents_md_text": "",
            "agents_prepend_mode": None,
            "preflight_enabled": False,
            "telemetry_enabled": None,
            "output_format": None,
            "usage_info_mode": "verbose",
            "status_layout": None,
            "status_fields": None,
            "reasoning_effort": "medium",
            "service_tier": None,
            "thinking_budget_tokens": None,
            "thinking_insight_enabled": False,
            "thinking_insight_summary": "auto",
            "anthropic_effort": "high",
            "anthropic_cache_ttl": None,
            "context_near_full_pct": None,
            "web_search_enabled": False,
            "web_search_allowed_domains": [],
            "web_search_include_sources": False,
            "web_search_location": {},
        }
        initial = self._collect_settings_dict()

        # Status fields catalog (Issue #15)
        try:
            _sf_cat = self._status_fields_catalog()
        except Exception:
            _sf_cat = []
        status_field_options: List[str] = []
        status_field_render: Dict[str, str] = {}
        try:
            for d in _sf_cat:
                if not isinstance(d, dict):
                    continue
                fid = str(d.get("id") or "").strip()
                if not fid:
                    continue
                status_field_options.append(fid)
                lbl = str(d.get("label") or fid)
                status_field_render[fid] = f"{lbl} ({fid})"
        except Exception:
            status_field_options = []
            status_field_render = {}
        try:
            status_fields_seed = self._status_preset_fields(str(getattr(self, "usage_info_mode", "verbose")))
        except Exception:
            status_fields_seed = []

        # Model presets list (shared)
        model_presets: List[Tuple[str, str]] = self._model_presets()

        # Reorder with a Recommended section at the top.
        # IMPORTANT: remove "server default" and "custom" from Settings UI.
        rec_keys_ordered = [
            "gpt-5.4",
            "gpt-5.4-mini-2026-03-17",
            "gpt-5.3-codex",
            "gpt-5",
            "gemini-3.1-pro-preview",
            "gemini-3-flash-preview",
            "claude-sonnet-4-6",
            "claude-opus-4-6",
            "kimi-k2.5",
            "grok-4.20-beta-0309-reasoning",
        ]
        rec_set = set(rec_keys_ordered)
        preset_map = {m: lbl for (m, lbl) in model_presets}
        rec_list: List[Tuple[str, str]] = [(m, preset_map[m]) for m in rec_keys_ordered if m in preset_map]
        other_list: List[Tuple[str, str]] = [(m, lbl) for (m, lbl) in model_presets if m not in rec_set]

        # Build enum options in the order: Recommended, Others
        model_enum_options: List[Optional[str]] = [m for (m, _l) in rec_list] + [m for (m, _l) in other_list]
        render_map: Dict[Any, str] = {}
        for m, lbl in rec_list:
            render_map[m] = lbl
        for m, lbl in other_list:
            render_map[m] = lbl

        # Build items schema
        items: List[Dict[str, Any]] = [
            {"label": "General", "type": "group", "items": [
                {
                    "id": "save_chat_history",
                    "label": "Save to unified memory",
                    "type": "bool",
                    "description": "When ON, chats sync to your account and appear in the web portal. When OFF, chats are ephemeral (local only)."
                },
                {
                    "id": "model",
                    "label": "Model",
                    "type": "enum",
                    "options": model_enum_options,
                    "render": render_map,
                },
                {"id": "system_prompt", "label": "System prompt", "type": "multiline"},
                {"id": "usage_info_mode", "label": "Usage panel", "type": "enum", "options": ["concise", "verbose"], "render": {"concise": "Concise", "verbose": "Verbose"}},
                {"id": "status_layout", "label": "Status layout", "type": "enum", "options": [None, "line", "panel"], "render": {None: "Follow preset", "line": "Single line (wrapped)", "panel": "Multi-line panel"}},
                {"id": "status_fields", "label": "Status fields", "type": "checklist", "options": status_field_options, "render": status_field_render, "seed": status_fields_seed},
                {"id": "text_verbosity", "label": "Text verbosity", "type": "enum", "options": ["low", "medium", "high"], "render": {"low": "Low", "medium": "Medium", "high": "High"}},
            ]},
            {"label": "Tools & Security", "type": "group", "items": [
                {
                    "id": "requested_tools",
                    "label": "Tools",
                    "type": "enum",
                    # Default-first: ON, then OFF, then server default.
                    "options": [True, False, None],
                    "render": {None: "Server default", True: "ON", False: "OFF"},
                },
                {
                    "id": "control_level",
                    "label": "Control level",
                    "type": "enum",
                    # Default-first: Level 3, then 2, then 1, then server default.
                    "options": [3, 2, 1, None],
                    "render": {None: "Server default", 1: "1 (read)", 2: "2 (approval)", 3: "3 (full)"},
                },
                {"id": "context_near_full_pct", "label": "Handoff near-full cutoff (%)", "type": "text"},
                {"id": "auto_approve", "label": "Auto-approve tools (comma)", "type": "text"},
                {"id": "show_tool_calls", "label": "Show tool call logs", "type": "bool"},
                # Note: options are static for this Settings UI session, so include xhigh unconditionally.
                # The server will safely downgrade xhigh on models that don't support it.
                {"id": "reasoning_effort", "label": "OpenAI reasoning effort", "type": "enum", "options": ["low", "medium", "high", "xhigh"], "render": {"low": "Low", "medium": "Medium", "high": "High", "xhigh": "XHigh"}},
                {"id": "service_tier", "label": "Priority processing", "type": "enum", "options": [None, "priority"], "render": {None: "Default / standard", "priority": "Priority"}},
                # Provider-native tool/thinking retention is always enabled.
                {"id": "thinking_budget_tokens", "label": "Anthropic thinking budget (tokens)", "type": "int"},
                {"id": "thinking_insight_enabled", "label": "Show optional provider thinking insight", "type": "bool"},
                {"id": "thinking_insight_summary", "label": "Thinking insight summary verbosity", "type": "enum", "options": ["auto", "concise", "detailed"], "render": {"auto": "Auto", "concise": "Concise", "detailed": "Detailed"}},
                {"id": "anthropic_effort", "label": "Anthropic effort (Opus 4.6/4.5/Sonnet 4.6)", "type": "enum", "options": ["low", "medium", "high", "max"], "render": {"low": "Low", "medium": "Medium", "high": "High (default)", "max": "Max (Opus 4.6 only)"}},
                {"id": "anthropic_cache_ttl", "label": "Anthropic prompt cache TTL", "type": "enum", "options": [None, "5m", "1h"], "render": {None: "Server default (5m)", "5m": "5 minutes (lower write cost)", "1h": "1 hour (higher write cost)"}},
                # Agent scope & filesystem controls
                {"id": "host_base", "label": "Agent scope directory", "type": "text"},
                {
                    "id": "fs_scope",
                    "label": "Filesystem scope",
                    "type": "enum",
                    # Default-first: host (Agent scope), then workspace, then server default.
                    "options": ["host", "workspace", None],
                    "render": {
                        None: "Server default",
                        "workspace": "Workspace (sandbox)",
                        "host": "Host (Agent scope)",
                    },
                },
                {
                    "id": "fs_host_mode",
                    "label": "Host mode",
                    "type": "enum",
                    # Default-first: custom (use Agent scope), then cwd, then any, then server default.
                    "options": ["custom", "cwd", "any", None],
                    "render": {
                        None: "Server default / any",
                        "any": "any (no extra client restriction)",
                        "cwd": "Current working directory",
                        "custom": "Custom (use Agent scope)",
                    },
                },
            ]},
            {"label": "Code Map", "type": "group", "items": [
                {"id": "inject_codebase_map", "label": "Inject codebase map on first turn", "type": "bool"},
            ]},
            {"label": "AGENTS.md", "type": "group", "items": [
                {"id": "inject_agents_md", "label": "Inject AGENTS.md on first turn", "type": "bool"},
                {"id": "agents_md_text", "label": "Default AGENTS.md text (override)", "type": "multiline"},
                {
                    "id": "agents_prepend_mode",
                    "label": "When local AGENTS.md differs",
                    "type": "enum",
                    "options": [None, "prepend_default", "local_only"],
                    "render": {
                        None: "Not set (will prompt once during configuration)",
                        "prepend_default": "Prepend defaults (recommended)",
                        "local_only": "Use local AGENTS.md only",
                    },
                },
            ]},
            {"label": "Preambles & First-turn", "type": "group", "items": [
                {
                    "id": "preambles_enabled",
                    "label": "Enable tool call preambles (GPT-5 / GPT-5.4; non-Codex)",
                    "type": "bool",
                    # Only show this control when the *currently selected* model supports it.
                    # (This updates live as the Model picker changes.)
                    "visible_if": (lambda w: self._supports_preambles((w or {}).get("model"))),
                },
                {"id": "custom_first_turn_enabled", "label": "Enable custom first-turn injection", "type": "bool"},
                {"id": "custom_first_turn_text", "label": "Custom first-turn text", "type": "multiline"},
                {"id": "codex_prompt_enabled", "label": "Inject Codex developer system prompt (Codex models only)", "type": "bool"},
            ]},
            {"label": "Web search", "type": "group", "items": [
                {"id": "web_search_enabled", "label": "Enable web search (OpenAI)", "type": "bool"},
                {"id": "web_search_allowed_domains", "label": "Allowed domains (comma)", "type": "text"},
                {"id": "web_search_include_sources", "label": "Include sources in response", "type": "bool"},
                {"id": "web_search_location", "label": "Location hint (key=value pairs)", "type": "text"},
            ]},
        ]

        # Wizard parity: only surface "Low" text verbosity when a GPT model is selected.
        try:
            if not self._is_gpt_model(self.model):
                for g in items:
                    if not isinstance(g, dict):
                        continue
                    if (g.get("type") == "group") and (g.get("label") == "General"):
                        for row in (g.get("items") or []):
                            if isinstance(row, dict) and row.get("id") == "text_verbosity":
                                row["options"] = ["medium", "high"]
                                row["render"] = {"medium": "Medium", "high": "High"}
        except Exception:
            pass

        # Prepare initial values with enum placeholder for model when custom text set
        init_for_ui = dict(initial)
        if isinstance(init_for_ui.get("model"), str) and init_for_ui["model"] not in [m for m, _ in model_presets]:
            # Represent as 'custom' for cycling, but keep original model in working copy for edit with 'e'
            pass  # We'll keep exact model string; enum will show the raw value when not matched

        footer = "↑/↓ move, Enter select, Esc back"
        def _on_setting_change(rid: str, value: Any, working: Dict[str, Any]) -> None:
            try:
                if rid == "model":
                    if value == "custom":
                        typed = self.ui.prompt(
                            "Enter model name (e.g., deepseek-chat, gpt-5, gemini-3-flash-preview)",
                            default=self.model or "",
                        )
                        working["model"] = typed.strip() or None
                    self._apply_model_side_effects()
                elif rid == "text_verbosity" and isinstance(value, str):
                    if value not in ("low", "medium", "high"):
                        working[rid] = "medium"
                elif rid == "thinking_budget_tokens":
                    tbt = value
                    if tbt in ("", None, 0, "0", "default"):
                        working[rid] = None
                    else:
                        try:
                            working[rid] = int(tbt)
                        except Exception:
                            working[rid] = None
                elif rid == "context_near_full_pct":
                    parsed_pct, ok_pct = self._parse_context_near_full_pct(value)
                    if ok_pct:
                        working[rid] = parsed_pct
                    else:
                        working[rid] = self.context_near_full_pct
                        try:
                            self.ui.warn("Invalid handoff cutoff. Use 0.85, 85, or 85%.")
                        except Exception:
                            pass
                elif rid == "service_tier":
                    working[rid] = "priority" if value == "priority" else None
                elif rid == "web_search_allowed_domains" and isinstance(value, str):
                    working[rid] = [d.strip() for d in value.replace("\n", ",").split(",") if d.strip()]
                elif rid == "web_search_location" and isinstance(value, str):
                    kv: Dict[str, str] = {}
                    for tok in value.replace(",", " ").split():
                        if "=" in tok:
                            k, v = tok.split("=", 1)
                            if k.strip() and v.strip():
                                kv[k.strip()] = v.strip()
                    working[rid] = kv
                elif rid == "auto_approve" and isinstance(value, str):
                    working[rid] = [t.strip() for t in value.split(",") if t.strip()]
                elif rid == "anthropic_cache_ttl":
                    if value in ("5m", "1h"):
                        working[rid] = value
                    else:
                        working[rid] = None
                elif rid == "status_layout":
                    if value in ("line", "panel"):
                        working[rid] = value
                    else:
                        working[rid] = None
                elif rid == "status_fields":
                    # Expect list[str]; keep None to follow preset.
                    if value is None:
                        working[rid] = None
                    elif isinstance(value, list):
                        working[rid] = [str(x).strip() for x in value if isinstance(x, str) and str(x).strip()]
                    elif isinstance(value, str):
                        working[rid] = [t.strip() for t in value.split(",") if t.strip()]
                self._apply_settings_dict({rid: working.get(rid)})
                if rid == "host_base":
                    try:
                        self._host_base_ephemeral = False
                    except Exception:
                        pass
                    try:
                        self._codebase_map_raw = self._load_codebase_map_raw()
                    except Exception:
                        pass
                if rid in ("inject_agents_md", "agents_md_text", "agents_prepend_mode"):
                    # Reset the first-turn AGENTS injection flag so changes apply on next first turn.
                    try:
                        self._did_inject_agents_md = False
                    except Exception:
                        pass
                if rid in ("custom_first_turn_enabled", "custom_first_turn_text"):
                    # Reset the first-turn custom injection flag so the change applies on next first turn
                    try:
                        self._did_inject_custom_first_turn = False
                    except Exception:
                        pass
                self.save_settings()
            except Exception:
                pass
        ui = SettingsUI("henosis-cli Settings", items, init_for_ui, defaults, footer=footer, on_change=_on_setting_change)
        # Optional: start focused on a specific control (e.g., the Model picker)
        try:
            focus_key = (focus or "").strip().lower() if isinstance(focus, str) else ""
        except Exception:
            focus_key = ""
        try:
            # Map friendly focus keys to row ids.
            focus_targets: List[str] = []
            if focus_key in ("model",):
                focus_targets = ["model"]
            elif focus_key in ("status", "status_fields", "statuslayout", "status_layout"):
                # Prefer the checklist row.
                focus_targets = ["status_fields", "status_layout"]
            elif focus_key:
                # Allow passing a row id directly.
                focus_targets = [focus_key]

            if focus_targets:
                for _ci, _cat in enumerate(getattr(ui, "categories", []) or []):
                    rows = _cat.get("items") or []
                    for _ri, _row in enumerate(rows):
                        rid = str(_row.get("id") or "").strip().lower()
                        if rid and rid in focus_targets:
                            try:
                                ui.mode = "items"  # type: ignore[attr-defined]
                                ui.cat_index = _ci  # type: ignore[attr-defined]
                                ui.item_index = _ri  # type: ignore[attr-defined]
                            except Exception:
                                pass
                            raise StopIteration  # break both loops
        except StopIteration:
            pass
        committed, updated = ui.run()
        if not committed or not isinstance(updated, dict):
            return

        # Post-process and validate specific fields
        # Model: if enum landed on 'custom', keep existing model; if None -> default
        if updated.get("model") == "custom":
            # No change unless user edited explicitly via 'e'
            updated["model"] = initial.get("model")
        # thinking_budget_tokens ensure None or positive int
        tbt = updated.get("thinking_budget_tokens")
        if tbt in ("", None, 0, "0", "default"):
            updated["thinking_budget_tokens"] = None
        else:
            try:
                updated["thinking_budget_tokens"] = int(tbt) if tbt is not None else None
            except Exception:
                updated["thinking_budget_tokens"] = None
        # thinking_insight_summary: normalize to supported values
        try:
            tsm = str(updated.get("thinking_insight_summary") or "").strip().lower()
            if tsm in ("auto", "concise", "detailed"):
                updated["thinking_insight_summary"] = tsm
            elif "thinking_insight_summary" in updated:
                updated["thinking_insight_summary"] = "auto"
        except Exception:
            updated["thinking_insight_summary"] = "auto"
        near_pct, near_pct_ok = self._parse_context_near_full_pct(updated.get("context_near_full_pct"))
        if near_pct_ok:
            updated["context_near_full_pct"] = near_pct
        else:
            updated["context_near_full_pct"] = self.context_near_full_pct
        # web_search_allowed_domains: normalize comma list
        dom = updated.get("web_search_allowed_domains")
        if isinstance(dom, str):
            toks = [d.strip() for d in dom.replace("\n", ",").split(",") if d.strip()]
            updated["web_search_allowed_domains"] = toks
        # web_search_location: parse key=value
        loc = updated.get("web_search_location")
        if isinstance(loc, str):
            kv: Dict[str, str] = {}
            for tok in loc.replace(",", " ").split():
                if "=" in tok:
                    k, v = tok.split("=", 1)
                    if k.strip() and v.strip():
                        kv[k.strip()] = v.strip()
            updated["web_search_location"] = kv

        # Apply to running CLI and persist
        try:
            self._apply_settings_dict(updated)
            if isinstance(updated.get("host_base"), str) and updated.get("host_base").strip():
                try:
                    self._host_base_ephemeral = False
                except Exception:
                    pass
            # Refresh code map source when host_base changed
            try:
                self._codebase_map_raw = self._load_codebase_map_raw()
            except Exception:
                pass
            # Reset first-turn custom injection flag after settings update so it can apply on next first turn
            try:
                self._did_inject_custom_first_turn = False
            except Exception:
                pass
        except Exception as e:
            self.ui.warn(f"Failed to apply updated settings: {e}")
        ok = await self._save_server_settings(updated)
        if ok:
            self.ui.success("Settings saved.")
        else:
            self.ui.warn("Failed to save settings to server; using local changes for this session.")
        # Summarize changes compared to settings when UI opened
        try:
            before = initial or {}
            after = self._collect_settings_dict()
            changed: List[str] = []
            lines: List[str] = []
            keys = sorted(set(list(before.keys()) + list(after.keys())))
            def _to_str(v: Any) -> str:
                try:
                    if isinstance(v, (dict, list)):
                        s = json.dumps(v, ensure_ascii=False)
                    else:
                        s = str(v)
                except Exception:
                    s = str(v)
                s = s if len(s) <= 160 else (s[:120] + " ... " + s[-20:])
                return s
            for k in keys:
                b = before.get(k)
                a = after.get(k)
                if b != a:
                    changed.append(k)
                    lines.append(f"- {k}: {_to_str(b)} -> {_to_str(a)}")
            if changed:
                self.ui.info_box("Settings changed", [f"{len(changed)} item(s) updated:"] + lines[:20])
                if len(lines) > 20:
                    self.ui.print(f"... and {len(lines)-20} more", style=self.ui.theme["dim"])  # type: ignore
            else:
                self.ui.print("No changes from previous settings.", style=self.ui.theme["dim"])
        except Exception:
            pass

    def _commands_word_completer(self) -> Optional[Any]:
        if not (HAS_PT and WordCompleter):
            return None
        words = [c["name"] for c in self._commands_catalog]
        meta = {c["name"]: c["usage"] for c in self._commands_catalog}
        try:
            return WordCompleter(words, meta_dict=meta, ignore_case=False, sentence=True)
        except Exception:
            return None

    def _read_multiline_input(
        self,
        prompt: str = "You: ",
        stop_event: Optional[threading.Event] = None,
        initial_text: str = "",
    ) -> str:
        """Plain fallback multiline reader using built-in input().
        Rules:
        - Print prompt once.
        - Collect lines until the user enters an empty line, then submit.
        - EOF (Ctrl+D/Ctrl+Z) submits if we have content; otherwise raises to exit.
        No leading/trailing whitespace is stripped from lines; formatting is preserved.
        """
        try:
            print(prompt, end="", flush=True)
        except Exception:
            # Fallback if stdout is odd
            sys.stdout.write(prompt)
            sys.stdout.flush()
        lines: List[str] = []
        seed = str(initial_text or "")
        if seed:
            try:
                sys.stdout.write(seed)
                sys.stdout.flush()
            except Exception:
                pass
            lines = seed.split("\n")
        while True:
            if stop_event is not None and stop_event.is_set():
                raise InputReadInterrupted("\n".join(lines))
            try:
                line = input()
            except EOFError:
                if lines:
                    return "\n".join(lines)
                raise
            if line == "":
                # Empty line submits (if any content gathered)
                if lines:
                    return "\n".join(lines)
                return ""
            lines.append(line)

    async def _run_blocking_prompt_read(self, reader: Callable[..., str], *args: Any) -> str:
        """Keep Agent Mode's event loop responsive while the terminal waits for input."""
        if not self.agent_mode:
            return reader(*args)
        prompt_label = str(args[0]) if args and isinstance(args[0], str) else None
        stop_event = threading.Event()
        self._input_interrupt_event = stop_event
        self._input_prompt_active = True
        self._input_prompt_label = prompt_label
        try:
            try:
                params = list(inspect.signature(reader).parameters.values())
                stop_event_index = next(
                    (
                        idx
                        for idx, param in enumerate(params)
                        if param.kind in (inspect.Parameter.POSITIONAL_ONLY, inspect.Parameter.POSITIONAL_OR_KEYWORD)
                        and param.name == "stop_event"
                    ),
                    None,
                )
            except Exception:
                stop_event_index = None
            if stop_event_index is None:
                return await asyncio.to_thread(reader, *args, stop_event)
            call_args = list(args)
            if len(call_args) > stop_event_index:
                call_args[stop_event_index] = stop_event
            else:
                while len(call_args) < stop_event_index:
                    call_args.append(None)
                call_args.append(stop_event)
            return await asyncio.to_thread(reader, *call_args)
        finally:
            try:
                stop_event.set()
            except Exception:
                pass
            self._input_interrupt_event = None
            self._input_prompt_active = False
            self._input_prompt_label = None

    async def _command_palette(self) -> Optional[str]:
        items = [(c["usage"], f"{c['name']} — {c['desc']}") for c in self._commands_catalog]
        total = len(items)
        if False and HAS_PT and RadioList and Application and Layout and HSplit and Window and FormattedTextControl and Frame:
            try:
                radio = RadioList(items)
                # Layout: hint, list (scrollable), status (index/total)
                container = HSplit([
                    Window(height=1, content=FormattedTextControl(lambda: "Use ↑/↓, Enter to select, Esc to cancel"), style="class:hint"),
                    Frame(radio, title="Commands"),
                    Window(height=1, content=FormattedTextControl(lambda: f"({radio._selected_index + 1}/{total})"), style="class:status"),
                ])
                kb = KeyBindings()

                @kb.add("enter")
                def _enter(event):
                    event.app.exit(result=radio.current_value)

                @kb.add("escape")
                def _esc(event):
                    event.app.exit(result=None)

                style = Style.from_dict({
                    "hint": "fg:#888888",
                    # Primary accent -> orange
                    "status": "fg:#ff8700",
                })
                app = Application(layout=Layout(container), key_bindings=kb, style=style, full_screen=False)
                return await app.run_async()
            except Exception:
                pass
        # Fallback: simple paginated list (7 per page)
        page = 0
        page_size = 7
        while True:
            start = page * page_size
            chunk = items[start : start + page_size]
            if not chunk:
                return None
            self.ui.print("\nCommands (page {}/{}):".format(page + 1, (total + page_size - 1) // page_size), style=self.ui.theme["subtitle"])
            for i, (val, label) in enumerate(chunk, start=1):
                idx = start + i
                self.ui.print(f"{i}. {label} ({idx}/{total})", style=self.ui.theme["dim"])
            self.ui.print("n=next page, p=prev page, q=cancel", style=self.ui.theme["dim"])
            raw = input("Select: ").strip().lower()
            if raw == "q":
                return None
            if raw == "n":
                if (start + page_size) < total:
                    page += 1
                continue
            if raw == "p":
                if page > 0:
                    page -= 1
                continue
            if raw.isdigit():
                k = int(raw)
                if 1 <= k <= len(chunk):
                    return chunk[k - 1][0]
            self.ui.warn("Invalid selection.")

    async def _menu_choice(self, title: str, text: str, choices: List[Tuple[str, str]]) -> Optional[str]:
        # Arrow-key navigable menu when prompt_toolkit is available; numeric fallback otherwise.
        # choices: list of (value, label)
        if False and HAS_PT and RadioList and Application and Layout and HSplit and Window and FormattedTextControl and Frame and Style:
            try:
                items = [(val, label) for (val, label) in choices]
                radio = RadioList(items)
                container = HSplit([
                    Window(height=1, content=FormattedTextControl(lambda: text or "Use ↑/↓, Enter to select, Esc to cancel"), style="class:hint"),
                    Frame(radio, title=title),
                ])
                kb = KeyBindings()

                @kb.add("enter")
                def _enter(event):
                    event.app.exit(result=radio.current_value)

                @kb.add("escape")
                def _esc(event):
                    event.app.exit(result=None)

                style = Style.from_dict({
                    "hint": "fg:#888888",
                })
                app = Application(layout=Layout(container), key_bindings=kb, style=style, full_screen=False)
                return await app.run_async()
            except Exception:
                pass

        # Fallback: simple numeric menu
        self.ui.header(title, text)
        for i, (_, label) in enumerate(choices, start=1):
            style = None
            try:
                lbl = str(label)
                if ("VERY expensive" in lbl) or ("[DANGER]" in lbl) or ("!!!" in lbl and "expensive" in lbl.lower()):
                    style = self.ui.theme.get("err")
            except Exception:
                style = None
            self.ui.print(f"{i}. {label}", style=style)
        self.ui.print()
        while True:
            raw = input("Choose an option: ").strip()
            if raw.lower() in ("q", "quit", "exit"):
                return None
            if not raw.isdigit():
                self.ui.warn("Enter a number from the list.")
                continue
            idx = int(raw)
            if not (1 <= idx <= len(choices)):
                self.ui.warn("Invalid selection.")
                continue
            return choices[idx - 1][0]

    # NOTE: select_model_menu moved below (single definition) and updated with DeepSeek presets

    async def set_scope_menu(self) -> None:
        val = await self._menu_choice(
            "Filesystem Scope", 
            "Choose filesystem scope (Agent scope applies when host is enabled):",
            [
                ("workspace", "Workspace - Safe sandbox directory, relative paths only"),
                ("host", "Host - Full host filesystem access (requires server permission and host_base)"),
                ("default", "Server Default - Let server decide based on config"),
            ],
        )
        if val == "workspace":
            self.fs_scope = "workspace"
        elif val == "host":
            self.fs_scope = "host"
        elif val == "default":
            self.fs_scope = None
        self.ui.success(f"FS Scope set to: {self._fs_label()}")
        self.save_settings()

    async def set_level_menu(self) -> None:
        val = await self._menu_choice(
            "Control Level",
            "Choose control level (1=read-only, 2=approval on write/exec, 3=unrestricted within sandbox):",
            [
                ("3", "Level 3: Full Access - No approvals needed, all tools unrestricted"),
                ("2", "Level 2: Approval Required - Write/edit/exec tools require user approval"),
                ("1", "Level 1: Read-Only - Only read_file and list_dir available, no writes or executions"),
                ("default", "Server Default - Use server's CONTROL_LEVEL_DEFAULT setting"),
            ],
        )
        if val == "default":
            self.control_level = None
        elif val in ("1", "2", "3"):
            self.control_level = int(val)
        self.ui.success(f"Control level set to: {self.control_level or 'server default'}")
        self.save_settings()

    async def set_auto_approve_menu(self) -> None:
        self.ui.header("Auto-Approve Tools", "Choose tools to auto-approve at Level 2. Select multiple with commas, or choose common presets.")
        choices = [
            ("none", "None - Require approval for all writes/edits/execs"),
            ("writes", "Writes Only - Auto-approve write_file, append_file"),
            ("edits", "Edits Only - Auto-approve edit_file"),
            ("execs", "Execs Only - Auto-approve run_command"),
            ("all", "All - Auto-approve write_file, append_file, edit_file, run_command"),
            ("custom", "Custom - Enter your own list"),
        ]
        val = await self._menu_choice("Auto-Approve Presets", "Select a preset or custom:", choices)
        if val == "none":
            self.auto_approve = []
        elif val == "writes":
            self.auto_approve = ["write_file", "append_file"]
        elif val == "edits":
            self.auto_approve = ["edit_file"]
        elif val == "execs":
            self.auto_approve = ["run_command"]
        elif val == "all":
            self.auto_approve = ["write_file", "append_file", "edit_file", "run_command"]
        elif val == "custom":
            s = self.ui.prompt(
                "Enter comma-separated tool names (e.g., write_file,append_file)", 
                default=",".join(self.auto_approve) if self.auto_approve else "",
            )
            names = [t.strip() for t in s.split(",") if t.strip()]
            self.auto_approve = names
        self.ui.success(f"Auto-approve set to: {','.join(self.auto_approve) if self.auto_approve else '(none)'}")
        self.save_settings()

    # ---------------------- Payload building helpers -------------------

    def _build_codebase_injection(self, user_input: str) -> Optional[str]:
        """Build a <codebase_map>...</codebase_map> block without pre-truncation.
        No client-side truncation is applied."""
        if not self._codebase_map_raw:
            # Lazy-load so newly created CODEBASE_MAP.md files are picked up before first turn.
            try:
                self._codebase_map_raw = self._load_codebase_map_raw()
            except Exception:
                self._codebase_map_raw = None
        if not self._codebase_map_raw:
            return None
        prefix = "<codebase_map>\n"
        suffix = "\n</codebase_map>"
        return f"{prefix}{self._codebase_map_raw}{suffix}"

    def _build_agents_injection(self) -> Optional[str]:
        """Build a <AGENTS.md>...</AGENTS.md> block (no client-side truncation)."""
        try:
            if not bool(getattr(self, "inject_agents_md", True)):
                return None
        except Exception:
            return None

        # Load default + local.
        # Note: agents_md_text is user-editable at runtime, so always re-resolve defaults
        # (and refresh the cache) rather than relying solely on the init-time value.
        try:
            default_raw = self._load_agents_default_raw()
            try:
                self._agents_default_raw = default_raw
            except Exception:
                pass
        except Exception:
            default_raw = None
        try:
            local_raw = self._load_agents_local_raw()
        except Exception:
            local_raw = None

        content: Optional[str] = None
        if isinstance(local_raw, str) and local_raw.strip():
            # If the local file already begins with the default instructions, do not
            # prepend again in the injected block.
            try:
                if isinstance(default_raw, str) and default_raw.strip():
                    if self._normalize_agents_text(local_raw).startswith(self._normalize_agents_text(default_raw)):
                        content = local_raw
            except Exception:
                pass
            # Combine based on stored mode; if unset, default to prepend (recommended).
            try:
                mode = getattr(self, "agents_prepend_mode", None)
            except Exception:
                mode = None
            if content is not None:
                pass
            elif mode == "local_only":
                content = local_raw
            else:
                try:
                    if isinstance(default_raw, str) and default_raw.strip():
                        if self._normalize_agents_text(default_raw) == self._normalize_agents_text(local_raw):
                            content = local_raw
                        else:
                            content = str(default_raw).rstrip() + "\n\n" + str(local_raw).lstrip()
                    else:
                        content = local_raw
                except Exception:
                    content = local_raw
        else:
            content = default_raw if isinstance(default_raw, str) else None

        if not (isinstance(content, str) and content.strip()):
            return None
        return f"<AGENTS.md>\n{content}\n</AGENTS.md>"

    def _build_first_turn_injection(self, user_input: str) -> Optional[str]:
        """Compose first-turn-only prefix blocks (code map, custom text, preamble, working memory)."""
        blocks: List[str] = []

        # 0) AGENTS.md (only once per conversation; always before everything else)
        try:
            if bool(getattr(self, "inject_agents_md", True)) and (not getattr(self, "_did_inject_agents_md", False)):
                inj_a = self._build_agents_injection()
                if inj_a:
                    blocks.append(inj_a)
                    self._did_inject_agents_md = True
        except Exception:
            pass

        # 1) Codebase map (only once per conversation)
        try:
            if self.inject_codebase_map and (not self._did_inject_codebase_map):
                inj = self._build_codebase_injection(user_input)
                if inj:
                    blocks.append(inj)
                    self._did_inject_codebase_map = True
        except Exception:
            pass

        # 2) Custom first-turn user text (only once per conversation)
        try:
            if bool(getattr(self, "custom_first_turn_enabled", False)) and (not getattr(self, "_did_inject_custom_first_turn", False)):
                txt = getattr(self, "custom_first_turn_text", "") or ""
                if isinstance(txt, str) and txt.strip():
                    blocks.append(txt.strip())
                    self._did_inject_custom_first_turn = True
        except Exception:
            pass

        # 3) Tool usage preamble (UX hint) — GPT-5 / GPT-5.4 only (non-Codex)
        try:
            if bool(getattr(self, "preambles_enabled", False)) and self._supports_preambles(self.model):
                blocks.append(
                    "Tool usage: when you need to read or modify files or run commands, "
                    "explicitly explain why you're using a tool, what you'll do, and how it "
                    "advances the user's goal before calling the tool."
                )
        except Exception:
            pass

        # 4) Working memory (context-summary file), injected once on fresh session restart
        try:
            if (not self._did_inject_working_memory) and self._memory_paths_for_first_turn:
                wm_block = self._build_working_memory_injection()
                if wm_block:
                    blocks.append(wm_block)
                    self._did_inject_working_memory = True
                    # Clear after successful injection so it doesn't repeat
                    self._memory_paths_for_first_turn = []
        except Exception:
            pass

        if not blocks:
            return None
        return "\n\n".join(blocks)

    def _build_messages(self, user_input: str) -> List[Dict[str, str]]:
        msgs: List[Dict[str, str]] = []
        # Inject a concise Codex developer system prompt for Codex models (optional)
        try:
            if self._is_codex_model(self.model) and bool(getattr(self, "codex_prompt_enabled", True)):
                msgs.append({"role": "system", "content": self._codex_system_prompt()})
        except Exception:
            pass
        # Always send the system prompt as-is (do NOT inject the code map here)
        if self.system_prompt:
            msgs.append({"role": "system", "content": self.system_prompt})

        # Replay prior conversation (excluding any system message already added)
        for msg in self.history:
            if msg["role"] != "system":
                msgs.append({"role": msg["role"], "content": msg["content"]})

        # For the first user turn only, prefix any configured injections to the user's content
        content = user_input
        prefix = self._build_first_turn_injection(user_input)
        if prefix:
            content = f"{prefix}\n\n{user_input}"

        # Remember exactly what we sent as the user content for this turn
        try:
            self._last_built_user_content = content
        except Exception:
            self._last_built_user_content = user_input

        msgs.append({"role": "user", "content": content})
        return msgs

    def _codex_system_prompt(self) -> str:
        """Minimal developer system prompt for GPT-5 Codex family."""
        return (
            "You are Codex, based on GPT-5. You are running as a coding agent in the Codex CLI on a user's computer.\n"
            "Note: In this CLI, the terminal tool is named 'run_command' (not 'shell'). Use run_command and always set the 'cwd' parameter; avoid using 'cd'.\n\n"
            "## General\n"
            "- Always set the 'cwd' param when using run_command. Do not use 'cd' unless absolutely necessary.\n"
            "- When searching for text or files, prefer using `rg` or `rg --files` respectively because `rg` is much faster than alternatives like `grep`. (If the `rg` command is not found, then use alternatives.)\n\n"
            "## Editing constraints\n"
            "- Default to ASCII when editing or creating files. Only introduce non-ASCII or other Unicode characters when there is a clear justification and the file already uses them.\n"
            "- Add succinct code comments that explain what is going on if code is not self-explanatory. You should not add comments like \"Assigns the value to the variable\", but a brief comment might be useful ahead of a complex code block that the user would otherwise have to spend time parsing out. Usage of these comments should be rare.\n"
            "- You may be in a dirty git worktree.\n"
            "    * NEVER revert existing changes you did not make unless explicitly requested, since these changes were made by the user.\n"
            "    * If asked to make a commit or code edits and there are unrelated changes to your work or changes that you didn't make in those files, don't revert those changes.\n"
            "    * If the changes are in files you've touched recently, you should read carefully and understand how you can work with the changes rather than reverting them.\n"
            "    * If the changes are in unrelated files, just ignore them and don't revert them.\n"
            "- While you are working, you might notice unexpected changes that you didn't make. If this happens, STOP IMMEDIATELY and ask the user how they would like to proceed.\n\n"
            "## Plan tool\n"
            "When using the planning tool:\n"
            "- Skip using the planning tool for straightforward tasks (roughly the easiest 25%).\n"
            "- Do not make single-step plans.\n"
            "- When you made a plan, update it after having performed one of the sub-tasks that you shared on the plan.\n\n"
            "## Codex CLI harness, sandboxing, and approvals\n"
            "The Codex CLI harness supports several different configurations for sandboxing and escalation approvals that the user can choose from.\n"
            "Filesystem sandboxing defines which files can be read or written. The options for `sandbox_mode` are:\n"
            "- read-only: The sandbox only permits reading files.\n"
            "- workspace-write: The sandbox permits reading files, and editing files in `cwd` and `writable_roots`. Editing files in other directories requires approval.\n"
            "- danger-full-access: No filesystem sandboxing - all commands are permitted.\n"
            "Network sandboxing defines whether network can be accessed without approval. Options for `network_access` are:\n"
            "- restricted: Requires approval\n"
            "- enabled: No approval needed\n"
            "Approvals are your mechanism to get user consent to run shell/terminal commands without the sandbox. Possible configuration options for `approval_policy` are\n"
            "- untrusted: The harness will escalate most commands for user approval, apart from a limited allowlist of safe 'read' commands.\n"
            "- on-failure: The harness will allow all commands to run in the sandbox (if enabled), and failures will be escalated to the user for approval to run again without the sandbox.\n"
            "- on-request: Commands will be run in the sandbox by default, and you can specify in your tool call if you want to escalate a command to run without sandboxing.\n"
            "- never: This is a non-interactive mode where you may NEVER ask the user for approval to run commands. Instead, you must always persist and work around constraints to solve the task for the user.\n\n"
            "When requesting approval to execute a command that will require escalated privileges:\n"
            "  - Provide the `with_escalated_permissions` parameter with the boolean value true (when available).\n"
            "  - Include a short, 1 sentence explanation for why you need to enable `with_escalated_permissions` in the justification parameter.\n\n"
            "## Special user requests\n"
            "- If the user makes a simple request (such as asking for the time) which you can fulfill by running a terminal command (such as `date`), you should do so.\n"
            "- If the user asks for a 'review', default to a code review mindset: prioritise identifying bugs, risks, behavioural regressions, and missing tests. Findings must be the primary focus of the response - keep summaries or overviews brief and only after enumerating the issues. Present findings first (ordered by severity with file/line references), follow with open questions or assumptions, and offer a change-summary only as a secondary detail. If no findings are discovered, state that explicitly and mention any residual risks or testing gaps.\n\n"
            "## Presenting your work and final message\n"
            "You are producing plain text that will later be styled by the CLI. Follow these rules exactly. Formatting should make results easy to scan, but not feel mechanical. Use judgment to decide how much structure adds value.\n"
            "- Default: be very concise; friendly coding teammate tone.\n"
            "- Ask only when needed; suggest ideas; mirror the user's style.\n"
            "- For substantial work, summarize clearly; follow final-answer formatting.\n"
            "- Skip heavy formatting for simple confirmations.\n"
            "- Don't dump large files you've written; reference paths only.\n"
            "- No 'save/copy this file' - User is on the same machine.\n"
            "- Offer logical next steps (tests, commits, build) briefly; add verify steps if you couldn't do something.\n"
            "- For code changes:\n"
            "  * Lead with a quick explanation of the change, and then give more details on the context covering where and why a change was made. Do not start this explanation with 'summary', just jump right in.\n"
            "  * When suggesting multiple options, use numeric lists for the suggestions so the user can quickly respond with a single number.\n"
            "- File References: When referencing files in your response, include the relevant start line and follow these rules: use inline code for paths; each reference should have a standalone path; accepted: absolute, workspace-relative, a/ or b/ diff prefixes, or bare filename/suffix; optional line/column uses :line[:column] or #LlineCcolumn; do not use URIs; do not provide line ranges.\n\n"
            "Apply Patch\n"
            "As shared previously in the GPT-5 prompting guide, use apply_patch for file edits to match the training distribution.\n\n"
            "Preambles\n"
            "GPT-5-Codex does not emit preambles. Do not ask for them.\n\n"
            "Frontend Guidance\n"
            "Use the following libraries unless the user or repo specifies otherwise:\n"
            "Framework: React + TypeScript\n"
            "Styling: Tailwind CSS\n"
            "Components: shadcn/ui\n"
            "Icons: lucide-react\n"
            "Animation: Framer Motion\n"
            "Charts: Recharts\n"
            "Fonts: San Serif, Inter, Geist, Mona Sans, IBM Plex Sans, Manrope\n"
        )

    def _build_kimi_raw_messages(self, user_input: str) -> List[Dict[str, Any]]:
        """Build provider-native messages for Kimi preserving prior assistant reasoning_content.
        Includes prior provider-native turns and the current user message with first-turn injections.
        """
        # Build the current user content with first-turn injections (code map, custom text, preamble, working memory)
        content = user_input
        prefix = self._build_first_turn_injection(user_input)
        if prefix:
            content = f"{prefix}\n\n{user_input}"
        # Compose new list: prior provider-native history plus current user
        raw = []
        # Always include system prompt first if present
        if self.system_prompt:
            raw.append({"role": "system", "content": self.system_prompt})
        # Append previously captured provider-native conversation (already includes user/assistant/tool)
        for m in (self._kimi_raw_history or []):
            raw.append(m)
        # Append current user message
        raw.append({"role": "user", "content": content})
        return raw

    def _normalize_gemini_raw_messages(self, rpm: Any) -> List[Dict[str, Any]]:
        """Normalize Gemini provider-native history.

        Ensures we only send a flat list of dicts back to the server.
        This prevents accidental nesting like [[{...}, {...}]] which the
        google-genai SDK rejects with pydantic union validation errors.
        """
        out: List[Dict[str, Any]] = []
        if not isinstance(rpm, list):
            return out
        for item in rpm:
            if item is None:
                continue
            if isinstance(item, list):
                # Flatten one level
                for sub in item:
                    if isinstance(sub, dict):
                        out.append(dict(sub))
                continue
            if isinstance(item, dict):
                out.append(dict(item))
        return out

    def _build_working_memory_injection(self) -> Optional[str]:
        try:
            if not self._memory_paths_for_first_turn:
                return None
            # Use the first provided path
            first = self._memory_paths_for_first_turn[0]
            p = Path(first)
            if not p.is_absolute():
                # Resolve relative to local workspace dir
                p = Path(self.local_workspace_dir).joinpath(first).resolve()
            if not p.exists():
                return None
            text = p.read_text(encoding="utf-8", errors="replace")
            explainer = (
                "Context was near full on the previous attempt. A compact working memory file was created; "
                "prefer this summary and reference files by path when needed."
            )
            block = (
                "<working_memory>\n"
                f"<explainer>{explainer}</explainer>\n\n"
                "<working_memory_md>\n"
                f"{text}\n"
                "</working_memory_md>\n"
                "</working_memory>"
            )
            return block
        except Exception:
            return None

    def _web_search_location_payload(self) -> Optional[Dict[str, str]]:
        if not self.web_search_location:
            return None
        payload: Dict[str, str] = {}
        for key, value in self.web_search_location.items():
            if isinstance(key, str) and isinstance(value, str):
                val = value.strip()
                if val:
                    payload[key.strip()] = val
        if not payload:
            return None
        if "type" not in payload:
            payload["type"] = "approximate"
        return payload

    def _codex_local_web_search_tool(self) -> Optional[Dict[str, Any]]:
        """Build an OpenAI web_search tool payload for local Codex requests."""
        try:
            if not bool(self.web_search_enabled):
                return None
            web_tool: Dict[str, Any] = {"type": "web_search"}

            cleaned_domains: List[str] = []
            for domain in (self.web_search_allowed_domains or []):
                if not isinstance(domain, str):
                    continue
                cleaned = domain.strip()
                if not cleaned:
                    continue
                if cleaned.startswith("https://") or cleaned.startswith("http://"):
                    cleaned = cleaned.split("://", 1)[1]
                cleaned = cleaned.strip().strip("/")
                if not cleaned:
                    continue
                lowered = cleaned.lower()
                if lowered not in cleaned_domains:
                    cleaned_domains.append(lowered)
                if len(cleaned_domains) >= 20:
                    break
            if cleaned_domains:
                web_tool["filters"] = {"allowed_domains": cleaned_domains}

            loc_payload = self._web_search_location_payload()
            if loc_payload:
                web_tool["user_location"] = loc_payload

            return web_tool
        except Exception:
            return None

    # ----------------------- Codebase map helpers ----------------------

    def _code_map_exists_at(self, root: str) -> bool:
        try:
            if not root:
                return False
            p1 = Path(root) / "CODEBASE_MAP.md"
            p2 = Path(root) / "codebase_map.md"
            return p1.exists() or p2.exists()
        except Exception:
            return False

    async def _offer_generate_code_map(self, root: str) -> None:
        """Offer to generate CODEBASE_MAP.md for the given root if missing, and, if accepted,
        stream a one-off prompt that guides the agent to read the directory and create it.

        This runs as a normal chat turn so the user can watch tool usage and file creation.
        """
        try:
            if not root:
                return
            if self._code_map_exists_at(root):
                return
            # Ask user via menu instead of Y/N typing
            choice = await self._menu_choice(
                "Codebase map",
                f"No CODEBASE_MAP.md found under '{root}'. Generate one now using tools?",
                [
                    ("generate", "Generate CODEBASE_MAP.md now"),
                    ("skip", "Skip for now"),
                ],
            )
            if choice != "generate":
                return
            await self._generate_code_map_for(root)
        except Exception as e:
            self.ui.warn(f"Code map offer failed: {e}")

    async def _generate_code_map_for(self, root: str) -> None:
        """Temporarily enable tools + host scope and ask the model to create CODEBASE_MAP.md at root.

        We include this project's CODEBASE_MAP.md content as an example of style/intent.
        """
        # Build prompt
        example = (self._codebase_map_raw or "").strip()
        example_block = f"\n<example_codebase_map>\n{example}\n</example_codebase_map>\n" if example else ""
        root_abs = str(Path(root).expanduser().resolve())
        prompt_lines = [
            "go read this codebase directory structure & files to make a codebase map.",
            "",
            "Task: Generate a CODEBASE_MAP.md for the host project at this absolute path:",
            root_abs,
            "",
            "Agent role (addressing you, the model):",
            (
                "You are an expert coding agent operating on the user's machine. "
                "You use the available tools in a deliberate, stepwise sequence to complete requests. "
                "If requirements are unclear, ask clarifying questions. "
                "For multi-step or complex tasks, propose a brief plan first, then execute and iterate with user feedback."
            ),
            "",
            "Instructions:",
            "- Use file tools to inspect the directory structure and key files. Start at the project root.",
            "- Prefer list_dir at the root first, then drill into only important folders (avoid exhaustive traversal).",
            "- Read a few representative files to infer purpose where helpful.",
            "- Do NOT include agent-behavior/tooling instructions in CODEBASE_MAP.md. Keep it a pure project map (behavior lives in AGENTS.md).",
            "- Produce a concise, human-readable CODEBASE_MAP.md that explains:",
            "  - Purpose of the project",
            "  - Top-level layout (folders and notable files)",
            "  - Key components and what they do",
            "  - Any quickstart or run/dev tips if obvious",
            "- When done, write the file to CODEBASE_MAP.md at the project root.",
            "",
            "Conventions:",
            "- Keep it brief and skimmable; do not list every file.",
            "- Use simple bullet points and short descriptions.",
            "- If a codebase map already exists (case-insensitive), update/replace it; otherwise create it.",
            "",
            "Tooling context:",
            "- Filesystem scope is 'host' for this turn, with the above path as the root.",
            "- You may call list_dir/read_file/write_file/apply_patch or any other tool as needed.",
            "- To list the root, you can use list_dir with an empty path ('') or with the absolute root path.",
        ]
        if example_block:
            prompt_lines.append("\nStyle example (not the same project, just for reference do not mention this example to the user unless asked):")
            prompt_lines.append(example_block)
        prompt_lines.append("Now begin by listing the top-level directory, then proceed.")

        user_prompt = "\n".join(prompt_lines)

        # Temporarily adjust settings for this one turn
        prev_tools = self.requested_tools
        prev_scope = self.fs_scope
        prev_host_base = self.host_base
        prev_host_mode = self.fs_host_mode
        prev_level = self.control_level
        try:
            # Ensure tools on and host scope applied to this request
            self.requested_tools = True
            self.fs_scope = "host"
            self.host_base = root_abs
            # Constrain host roots to the selected base for safety
            self.fs_host_mode = "custom"
            # Prefer Level 2 so the user can approve writes visibly; fallback to user's setting otherwise
            if self.control_level not in (1, 2, 3):
                self.control_level = 2

            self.ui.info("Starting codebase map generation turn...")
            await self._stream_once(user_prompt)
        finally:
            # Restore prior settings
            self.requested_tools = prev_tools
            self.fs_scope = prev_scope
            self.host_base = prev_host_base
            self.fs_host_mode = prev_host_mode
            self.control_level = prev_level

    # -------------------------- Tool rendering -------------------------
    def _base_command(self, cmd: Optional[str]) -> str:
        try:
            return (cmd or "").strip().split()[0].lower()
        except Exception:
            return ""

    def _base_command_from_args(self, args: Dict[str, Any]) -> str:
        """Extract a normalized base executable name from run_command args.

        Used for Level-2 trust checks and approval labeling.
        """
        try:
            cmd = args.get("cmd") if isinstance(args, dict) else None
        except Exception:
            cmd = None
        return self._base_command(cmd)

    def _coerce_level(self, value: Any) -> Optional[int]:
        try:
            if isinstance(value, int):
                lvl = int(value)
            elif isinstance(value, str) and value.strip().isdigit():
                lvl = int(value.strip())
            else:
                return None
            return lvl if lvl in (1, 2, 3) else None
        except Exception:
            return None

    def _effective_control_level(self, event_data: Optional[Dict[str, Any]] = None) -> Optional[int]:
        """Resolve the most authoritative control level for this stream event.

        Priority intentionally favors server/event state over local settings to
        avoid stale local overrides causing incorrect approval prompts.
        """
        candidates: List[Any] = []
        if isinstance(event_data, dict):
            candidates.append(event_data.get("level"))
            try:
                sid_raw = event_data.get("session_id")
                sid = str(sid_raw).strip() if sid_raw is not None else ""
                if sid:
                    candidates.append((self._session_level_by_id or {}).get(sid))
            except Exception:
                pass
        try:
            if isinstance(getattr(self, "_current_turn", None), dict):
                candidates.append(self._current_turn.get("level"))
        except Exception:
            pass
        candidates.append(getattr(self, "_last_server_level", None))
        candidates.append(getattr(self, "control_level", None))
        for c in candidates:
            lvl = self._coerce_level(c)
            if lvl in (1, 2, 3):
                return lvl
        return None

    def _approval_menu_choice(
        self,
        *,
        title: str,
        prompt: str,
        choices: List[Tuple[str, str]],
        cancel_value: Optional[str] = None,
    ) -> str:
        labels = [lbl for (_val, lbl) in choices]
        if not labels:
            return cancel_value or ""

        if not _hn_supports_tty_io_v2():
            if prompt:
                self.ui.print(prompt, force=True)
            for idx, lbl in enumerate(labels, start=1):
                self.ui.print(f"{idx}) {lbl}", force=True)
            while True:
                raw = input(f"Choose (1-{len(labels)}): ").strip()
                if raw.isdigit():
                    n = int(raw)
                    if 1 <= n <= len(labels):
                        return choices[n - 1][0]
                self.ui.warn(f"Enter a number between 1 and {len(labels)}.")

        index = 0
        lines_drawn = 0
        ORANGE = "\x1b[38;5;214m"
        RESET = "\x1b[0m"

        def _render_inline_menu() -> bool:
            nonlocal lines_drawn
            block: List[str] = []
            if prompt:
                block.append(str(prompt))
            for i, lbl in enumerate(labels, start=1):
                if (i - 1) == index:
                    block.append(f" {i}. {ORANGE}>{RESET} {lbl}")
                else:
                    block.append(f" {i}.   {lbl}")
            block.append("Up/Down to move, Enter to select, Esc to cancel")
            try:
                if lines_drawn > 0:
                    for _ in range(lines_drawn):
                        sys.stdout.write("\x1b[1A")      # cursor up one line
                        sys.stdout.write("\r\x1b[2K")    # clear entire line
                for ln in block:
                    sys.stdout.write(str(ln) + "\n")
                sys.stdout.flush()
                lines_drawn = len(block)
                return True
            except Exception:
                return False

        inline_ok = _render_inline_menu()
        while True:
            key = _hn_read_key_v2()
            if key is None:
                self.ui.print("\nNumeric selection fallback.", force=True)
                for idx, lbl in enumerate(labels, start=1):
                    self.ui.print(f"{idx}) {lbl}", force=True)
                while True:
                    raw = input(f"Choose (1-{len(labels)}): ").strip()
                    if raw.isdigit():
                        n = int(raw)
                        if 1 <= n <= len(labels):
                            return choices[n - 1][0]
                    self.ui.warn(f"Enter a number between 1 and {len(labels)}.")
            elif key == "UP":
                index = (index - 1) % len(labels)
                if inline_ok:
                    inline_ok = _render_inline_menu()
            elif key == "DOWN":
                index = (index + 1) % len(labels)
                if inline_ok:
                    inline_ok = _render_inline_menu()
            elif key == "PGUP":
                index = max(0, index - 7)
                if inline_ok:
                    inline_ok = _render_inline_menu()
            elif key == "PGDN":
                index = min(len(labels) - 1, index + 7)
                if inline_ok:
                    inline_ok = _render_inline_menu()
            elif key == "HOME":
                index = 0
                if inline_ok:
                    inline_ok = _render_inline_menu()
            elif key == "END":
                index = len(labels) - 1
                if inline_ok:
                    inline_ok = _render_inline_menu()
            elif key == "ENTER":
                return choices[index][0]
            elif key == "ESC":
                return cancel_value if cancel_value is not None else choices[-1][0]
            elif isinstance(key, str) and key.isdigit():
                n = int(key)
                if 1 <= n <= len(labels):
                    index = n - 1
                    if inline_ok:
                        inline_ok = _render_inline_menu()

    def _extract_apply_patch_paths(self, patch_text: Any) -> List[str]:
        out: List[str] = []
        seen = set()
        try:
            lines = str(patch_text or "").splitlines()
        except Exception:
            lines = []
        for raw in lines:
            s = raw.strip()
            if s.startswith("*** Add File: ") or s.startswith("*** Update File: ") or s.startswith("*** Delete File: ") or s.startswith("*** Move to: "):
                try:
                    p = s.split(": ", 1)[1].strip()
                except Exception:
                    p = ""
                if p and p not in seen:
                    out.append(p)
                    seen.add(p)
        return out

    def _apply_patch_preview_for_approval(self, args: Dict[str, Any], policy: Optional[Any]) -> Dict[str, Any]:
        if not HAS_LOCAL_TOOLS:
            return {"ok": False, "error": "local tools unavailable"}
        if policy is None:
            return {"ok": False, "error": "preview unavailable (missing local policy)"}
        try:
            out = local_apply_patch(
                patch=args.get("patch", ""),
                policy=policy,
                cwd=args.get("cwd", "."),
                lenient=bool(args.get("lenient", True)),
                dry_run=True,
                backup=False,
                safeguard_max_lines=int(args.get("safeguard_max_lines", 3000) or 3000),
                safeguard_confirm=bool(args.get("safeguard_confirm", False)),
            )
        except Exception as e:
            return {"ok": False, "error": str(e)}
        if not isinstance(out, dict):
            return {"ok": False, "error": "preview returned non-dict result"}
        return out

    def _view_apply_patch_diffs(self, details: List[Dict[str, Any]]) -> str:
        def _trim_diff_file_headers(diff_text: str) -> str:
            """Drop repeated ---/+++ file header lines from preview output."""
            if not isinstance(diff_text, str) or not diff_text:
                return diff_text
            lines = diff_text.splitlines()
            if len(lines) >= 2 and lines[0].startswith("--- ") and lines[1].startswith("+++ "):
                return "\n".join(lines[2:])
            return diff_text

        diff_entries: List[Dict[str, Any]] = []
        for d in details:
            if not isinstance(d, dict):
                continue
            if isinstance(d.get("diff"), str) or bool(d.get("diff_truncated")):
                diff_entries.append(d)
        if not diff_entries:
            self.ui.warn("No diff payload was returned for preview.")
            return "continue"

        total = len(diff_entries)
        for idx, d in enumerate(diff_entries, start=1):
            path = str(d.get("path") or "(unknown path)")
            action = str(d.get("action") or "?")
            try:
                la = int(d.get("lines_added", 0) or 0)
            except Exception:
                la = 0
            try:
                lr = int(d.get("lines_removed", 0) or 0)
            except Exception:
                lr = 0
            truncated = bool(d.get("diff_truncated"))
            title = f"[{idx}/{total}] {path} ({action}) +{la}/-{lr}" + (" [truncated]" if truncated else "")
            self.ui.print(title, style=self.ui.theme["label"], force=True)
            diff_text = _trim_diff_file_headers(str(d.get("diff") or ""))
            if self.ui.rich and Panel and Syntax and self.ui.console:
                try:
                    payload = diff_text if diff_text else "(diff omitted by truncation limits)"
                    self.ui.console.print(
                        Panel(
                            Syntax(payload, "diff", line_numbers=False, word_wrap=False),
                            border_style=self.ui.theme["dim"],
                        )
                    )
                except Exception:
                    self.ui.print(diff_text if diff_text else "(diff omitted by truncation limits)", force=True)
            else:
                self.ui.print(diff_text if diff_text else "(diff omitted by truncation limits)", force=True)

            if idx < total:
                step = self._approval_menu_choice(
                    title="Diff Preview",
                    prompt="Choose next step",
                    choices=[
                        ("next", "Next file"),
                        ("stop", "Stop viewing diffs"),
                        ("deny", "Deny"),
                    ],
                    cancel_value="stop",
                )
                if step == "deny":
                    return "deny"
                if step == "stop":
                    break
        return "continue"

    def _approval_prompt_ui(self, label: str, args: Dict[str, Any], policy: Optional[Any] = None) -> str:
        """Interactive approval prompt for Level 2.

        Uses the same highlighted, arrow-key-driven menu UX as the rest of the CLI
        when TTY input is available, and falls back to numeric input otherwise.
        Returns one of: "once", "session", "always", "deny", "preview_failed".
        """
        try:
            base_tool = (label.split(":")[0] if isinstance(label, str) and ":" in label else label) or ""
        except Exception:
            base_tool = label or ""
        bt = str(base_tool).strip().lower()
        # For apply_patch approvals, keep output compact: preview + selector only.
        compact_l2_apply_patch = (bt == "apply_patch" or bt.startswith("apply_patch:"))

        def _approval_compact_context(tool_name: str, tool_args: Dict[str, Any]) -> str:
            """Return a compact (preferably single-line) summary for approvals.

            Key goal: show only what the user needs to decide, without dumping
            the raw args dict or wasting vertical space.
            """
            tn = (tool_name or "").strip().lower()
            a = tool_args if isinstance(tool_args, dict) else {}
            parts: List[str] = []
            try:
                if tn == "run_command":
                    cmd = a.get("cmd")
                    if cmd is not None:
                        parts.append(f"cmd: {self._clip(str(cmd), 200)}")
                    cwd = a.get("cwd")
                    # cwd is often "." (default) and doesn't add much signal; omit unless non-trivial.
                    if isinstance(cwd, str) and cwd.strip() and cwd.strip() not in (".", "./"):
                        parts.append(f"cwd: {cwd}")
                    # timeout is rarely relevant to the decision; keep it for verbose mode only.
                elif tn == "run_shell":
                    shell = a.get("shell")
                    command = a.get("command")
                    if shell:
                        parts.append(f"shell: {shell}")
                    if command is not None:
                        parts.append(f"command: {self._clip(str(command), 200)}")
                elif tn in ("write_file", "append_file"):
                    path = a.get("path")
                    if path is not None:
                        parts.append(f"path: {path}")
                    content = a.get("content") or ""
                    try:
                        b = len(str(content).encode("utf-8", errors="replace"))
                    except Exception:
                        b = None
                    if b is not None:
                        parts.append(f"content_bytes: {b}")
                elif tn == "string_replace":
                    pattern = a.get("pattern")
                    repl = a.get("replacement")
                    if pattern is not None:
                        parts.append(f"pattern: {self._clip(str(pattern), 120)}")
                    if repl is not None:
                        parts.append(f"replacement: {self._clip(str(repl), 120)}")
                    globs = a.get("file_globs")
                    if isinstance(globs, list) and globs:
                        joined = ", ".join([str(g) for g in globs[:4]])
                        more = len(globs) - min(4, len(globs))
                        parts.append("files: " + joined + (f", +{more} more" if more > 0 else ""))
                else:
                    # Fall back to the existing one-line summary.
                    parts.append(str(self._tool_summary(tool_name, a)))
            except Exception:
                # Never fail approvals due to formatting.
                pass

            # NOTE: Use a simple separator to stay portable across terminals.
            out = " | ".join([p for p in parts if isinstance(p, str) and p.strip()])
            return self._clip(out, 320) if out else ""

        if not compact_l2_apply_patch:
            # Keep approvals compact (avoid dumping a multi-line args block).
            self.ui.print(f"[Level 2] Approval required: {label}", force=True)
            ctx = _approval_compact_context(label.split(":")[0], args)
            if ctx:
                self.ui.print(ctx, style=self.ui.theme["dim"], force=True)

        try:
            if bt == "apply_patch":
                cwd = args.get("cwd")
                dry = bool(args.get("dry_run", False))
                if not compact_l2_apply_patch:
                    if cwd is not None:
                        self.ui.print(f"cwd: {cwd}", style=self.ui.theme["dim"], force=True)
                    self.ui.print(f"dry_run: {dry}", style=self.ui.theme["dim"], force=True)

                preview = self._apply_patch_preview_for_approval(args, policy)
                if bool(preview.get("ok")) and isinstance(preview.get("data"), dict):
                    pdata = preview.get("data") or {}
                    psummary = pdata.get("summary") or {}
                    details = pdata.get("details") or []
                    diff_stats = pdata.get("diff_stats") or {}
                    files: List[str] = []
                    seen = set()
                    for key in ("added", "modified", "deleted"):
                        vals = psummary.get(key) if isinstance(psummary, dict) else None
                        if isinstance(vals, list):
                            for v in vals:
                                vv = str(v).strip()
                                if vv and vv not in seen:
                                    files.append(vv)
                                    seen.add(vv)
                    if not files:
                        for v in self._extract_apply_patch_paths(args.get("patch", "")):
                            if v not in seen:
                                files.append(v)
                                seen.add(v)
                    try:
                        la = int(diff_stats.get("lines_added", 0) or 0)
                    except Exception:
                        la = 0
                    try:
                        lr = int(diff_stats.get("lines_removed", 0) or 0)
                    except Exception:
                        lr = 0
                    try:
                        fc = int(diff_stats.get("files_changed", 0) or 0)
                    except Exception:
                        fc = 0
                    trunc_count = 0
                    safeguard_count = 0
                    if isinstance(details, list):
                        for d in details:
                            if isinstance(d, dict) and bool(d.get("diff_truncated")):
                                trunc_count += 1
                            if isinstance(d, dict) and bool(d.get("safeguard_triggered")):
                                safeguard_count += 1
                    self.ui.print(
                        f"{len(files)} file(s), diff stats +{la} / -{lr} across {fc} file(s)",
                        style=self.ui.theme["dim"],
                        force=True,
                    )
                    if files:
                        shown = ", ".join(files[:5])
                        more = len(files) - min(5, len(files))
                        self.ui.print(
                            "files: " + shown + (f", +{more} more" if more > 0 else ""),
                            style=self.ui.theme["dim"],
                            force=True,
                        )
                    if trunc_count:
                        self.ui.warn(f"Preview diffs were truncated for {trunc_count} file(s).")
                    if safeguard_count:
                        self.ui.warn(
                            f"Safeguard would block {safeguard_count} file change(s) unless safeguard_confirm=true."
                        )

                    view = self._approval_menu_choice(
                        title="Patch Preview",
                        prompt="View diffs file-by-file?",
                        choices=[
                            ("view", "View diffs (file-by-file)"),
                            ("skip", "Skip diff preview"),
                            ("deny", "Deny"),
                        ],
                        cancel_value="skip",
                    )
                    if view == "deny":
                        return "deny"
                    if view == "view":
                        decision = self._view_apply_patch_diffs(details if isinstance(details, list) else [])
                        if decision == "deny":
                            return "deny"
                else:
                    err_msg = str(preview.get("error", "unknown error") or "unknown error")
                    self._last_approval_error = f"apply_patch preview failed: {err_msg}"
                    self.ui.warn(self._last_approval_error)
                    patch_text = str(args.get("patch", "") or "")
                    if patch_text:
                        lines = patch_text.splitlines()
                        header_lines = [ln for ln in lines if ln.strip().startswith("*** ")]
                        excerpt = header_lines[:40] if header_lines else lines[:40]
                        if excerpt:
                            self.ui.print("Patch preview (partial):", style=self.ui.theme["dim"], force=True)
                            self.ui.print("\n".join(excerpt), force=True)
                    return "preview_failed"
        except Exception as e:
            if bt == "apply_patch":
                self._last_approval_error = f"apply_patch preview failed: {e}"
                self.ui.warn(self._last_approval_error)
                return "preview_failed"
            pass

        # If the user has enabled verbose output, show multi-line details for debugging.
        # (Normal mode stays compact.)
        if bool(getattr(self.ui, "verbose", False)) and not compact_l2_apply_patch:
            try:
                if bt == "run_command":
                    cmd = args.get("cmd")
                    cwd = args.get("cwd")
                    timeout = args.get("timeout")
                    if cmd is not None:
                        self.ui.print(f"cmd: {self._clip(str(cmd), 400)}", style=self.ui.theme["dim"], force=True)
                    if cwd is not None:
                        self.ui.print(f"cwd: {cwd}", style=self.ui.theme["dim"], force=True)
                    if timeout is not None:
                        self.ui.print(f"timeout: {timeout}", style=self.ui.theme["dim"], force=True)
                elif bt in ("write_file", "append_file"):
                    path = args.get("path")
                    content = args.get("content") or ""
                    self.ui.print(f"path: {path}", style=self.ui.theme["dim"], force=True)
                    try:
                        b = len(str(content).encode("utf-8", errors="replace"))
                    except Exception:
                        b = None
                    if b is not None:
                        self.ui.print(f"content_bytes: {b}", style=self.ui.theme["dim"], force=True)
            except Exception:
                pass

        # Issue #18 fail-safe: Level 3 should never reach here, but guard anyway.
        try:
            eff = self._effective_control_level()
            if eff == 3:
                self.ui.debug_log("[approval] L3 fail-safe: suppressing approval prompt")
                return "once"
        except Exception:
            pass

        # Issue #18 turn-lifecycle guard: do not prompt if the turn is already inactive.
        try:
            if not (self._current_turn or {}).get("active", False):
                self.ui.debug_log("[approval] turn inactive: suppressing late approval prompt")
                return "deny"
        except Exception:
            pass

        return self._approval_menu_choice(
            title="Approval required",
            prompt="Choose approval scope",
            choices=[
                ("once", "Approve once"),
                ("session", "Trust for this session"),
                ("always", "Always trust"),
                ("deny", "Deny"),
            ],
            cancel_value="deny",
        )

    # ----------------------- Status fields (Issue #15) -----------------------
    def _status_fields_catalog(self) -> List[Dict[str, str]]:
        """Catalog of supported post-turn status field IDs."""
        return [
            # User-requested
            {"id": "model-name", "label": "Model name", "desc": "Current model name"},
            {"id": "model-with-reasoning", "label": "Model + reasoning", "desc": "Model name plus reasoning effort when applicable"},
            {"id": "current-dir", "label": "Current dir", "desc": "Current working directory"},
            {"id": "git-branch", "label": "Git branch", "desc": "Current git branch (omitted when unavailable)"},
            {"id": "context-remaining", "label": "Context remaining", "desc": "Percent remaining (omitted when unknown)"},
            {"id": "context-used", "label": "Context used", "desc": "Percent used (omitted when unknown)"},
            {"id": "context-window-size", "label": "Context window", "desc": "Context window size in tokens (omitted when unknown)"},
            {"id": "used-tokens", "label": "Used tokens", "desc": "Session total tokens used (omitted when zero)"},
            {"id": "total-input-tokens", "label": "Input tokens", "desc": "Session total input tokens"},
            {"id": "total-output-tokens", "label": "Output tokens", "desc": "Session total output tokens"},
            {"id": "session-id", "label": "Session id", "desc": "Current server session id (omitted until session starts)"},
            {"id": "tool-calls", "label": "Tool calls", "desc": "Number of tool calls in the last turn"},

            # Existing info currently shown in verbose mode
            {"id": "cli-version", "label": "CLI version", "desc": "henosis-cli version and update hint"},
            {"id": "billing", "label": "Billing", "desc": "Cost charged, chat cost, remaining credits"},
            {"id": "turn-tokens", "label": "Turn tokens", "desc": "Input/output/reasoning tokens for the last turn"},
            {"id": "session-tokens", "label": "Session tokens", "desc": "Cumulative input/output/reasoning tokens"},
            {"id": "timing", "label": "Timing", "desc": "Turn time, session time, tool calls"},
            {"id": "web-search", "label": "Web search", "desc": "Summary of web search calls (if any)"},
            {"id": "context-meter", "label": "Context meter", "desc": "Token count + bar + percent (based on last reply)"},
            {"id": "prompt-cache", "label": "Prompt cache", "desc": "Prompt cache banners (if any)"},
        ]

    def _status_field_ids(self) -> set:
        try:
            return set([d.get("id") for d in self._status_fields_catalog() if isinstance(d, dict) and d.get("id")])
        except Exception:
            return set()

    def _status_preset_fields(self, preset: str) -> List[str]:
        p = (preset or "").strip().lower()
        if p == "concise":
            # Keep today's concise feel: tokens bar + percent, plus tool call count.
            return ["context-meter", "tool-calls"]
        # verbose preset
        return [
            "cli-version",
            "billing",
            "turn-tokens",
            "session-tokens",
            "timing",
            "web-search",
            "context-meter",
            "prompt-cache",
        ]

    def _status_layout_effective(self) -> str:
        try:
            if isinstance(self.status_layout, str) and self.status_layout.strip().lower() in ("line", "panel"):
                return self.status_layout.strip().lower()
        except Exception:
            pass
        try:
            return "line" if str(getattr(self, "usage_info_mode", "verbose")).lower() == "concise" else "panel"
        except Exception:
            return "panel"

    def _status_fields_effective(self) -> List[str]:
        ids = self._status_field_ids()
        raw: Optional[List[str]]
        if isinstance(getattr(self, "status_fields", None), list):
            raw = list(self.status_fields or [])
        else:
            raw = None
        if raw is None:
            raw = self._status_preset_fields(str(getattr(self, "usage_info_mode", "verbose")))

        out: List[str] = []
        seen = set()
        for x in (raw or []):
            try:
                k = str(x).strip()
            except Exception:
                continue
            if not k:
                continue
            if k not in ids:
                continue
            if k in seen:
                continue
            out.append(k)
            seen.add(k)
        return out

    def _get_git_branch(self) -> Optional[str]:
        """Best-effort current git branch (cached)."""
        try:
            cwd = os.getcwd()
        except Exception:
            cwd = None
        try:
            now = time.time()
        except Exception:
            now = 0.0
        try:
            cache = self._git_branch_cache if isinstance(self._git_branch_cache, dict) else {}
            if cache.get("cwd") == cwd and (now - float(cache.get("ts") or 0.0)) < 5.0:
                br = cache.get("branch")
                return str(br) if isinstance(br, str) and br.strip() else None
        except Exception:
            pass

        branch = None
        try:
            if cwd:
                out = subprocess.check_output(
                    ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                    cwd=cwd,
                    stderr=subprocess.DEVNULL,
                ).decode("utf-8", errors="ignore").strip()
                if out and out != "HEAD":
                    branch = out
        except Exception:
            branch = None
        try:
            self._git_branch_cache = {"cwd": cwd, "branch": branch, "ts": now}
        except Exception:
            pass
        return branch

    def _context_meter_fill_style(self) -> str:
        """Single source of truth for context meter fill color."""
        try:
            return str(self.ui.theme.get("tool_call") or self.ui.theme.get("assistant") or "white")
        except Exception:
            return "white"

    def _context_meter_bar(self, filled: int, empty: int) -> str:
        """Render the context bar body (without outer brackets)."""
        try:
            f = max(0, int(filled or 0))
        except Exception:
            f = 0
        try:
            e = max(0, int(empty or 0))
        except Exception:
            e = 0
        if self.ui.rich:
            fill_style = self._context_meter_fill_style()
            return f"[{fill_style}]{'█' * f}[/{fill_style}]{'░' * e}"
        return ("#" * f) + ("-" * e)

    def _context_meter_panel_line(self, tokens: int, pct: float, filled: int, empty: int) -> str:
        """Render a full 'Context: ... [bar] ...%' line consistently across providers."""
        bar = self._context_meter_bar(filled, empty)
        return f"Context: {int(tokens)} [{bar}] {float(pct):.1f}%"

    def _render_status_info(self, ctx: Dict[str, Any]) -> None:
        """Render post-turn status output according to configured fields/layout."""
        layout = self._status_layout_effective()
        fields = self._status_fields_effective()
        if not fields:
            return

        # Helper: build/print a context meter for one-line layout.
        def _print_context_meter_inline(cm: Dict[str, Any]) -> None:
            fill_style = self._context_meter_fill_style()
            try:
                total_val = int(cm.get("tokens") or 0)
            except Exception:
                total_val = 0
            try:
                pct_val = float(cm.get("pct") or 0.0)
            except Exception:
                pct_val = 0.0
            try:
                filled = int(cm.get("filled") or 0)
            except Exception:
                filled = 0
            try:
                empty = int(cm.get("empty") or 0)
            except Exception:
                empty = max(0, 30 - filled)
            if self.ui.rich:
                self.ui.print("tokens used:", style="white", end=" ")
                self.ui.print(str(total_val), end=" ")
                self.ui.print("[", style="white", end="")
                self.ui.print("\u2588" * max(0, filled), style=fill_style, end="")
                self.ui.print("\u2591" * max(0, empty), style="white", end="")
                self.ui.print("]", style="white", end=" ")
                self.ui.print(f"{pct_val:.1f}%", end="")
            else:
                bar_ascii = "[" + ("#" * max(0, filled)) + ("-" * max(0, empty)) + "]"
                self.ui.print(f"tokens used: {total_val} {bar_ascii} {pct_val:.1f}%", end="")

        def _field_value(fid: str) -> Optional[Any]:
            # Return either a string, a list[str] (panel), or a dict for special inline rendering.
            model_used = ctx.get("model_used")
            effort_disp = ctx.get("effort_disp")
            if fid == "model-name":
                if isinstance(model_used, str) and model_used.strip():
                    return f"model: {model_used.strip()}"
                return None
            if fid == "model-with-reasoning":
                if isinstance(model_used, str) and model_used.strip():
                    seg = str(effort_disp or "")
                    return f"model: {model_used.strip()}{seg}"
                return None
            if fid == "current-dir":
                try:
                    return f"cwd: {os.getcwd()}"
                except Exception:
                    return None
            if fid == "git-branch":
                br = self._get_git_branch()
                return f"git: {br}" if (isinstance(br, str) and br.strip()) else None
            if fid == "session-id":
                sid = ctx.get("session_id") or getattr(self, "_last_session_id", None)
                return f"session: {sid}" if (isinstance(sid, str) and sid.strip()) else None
            if fid == "tool-calls":
                try:
                    tc = int(ctx.get("tool_calls") or 0)
                except Exception:
                    tc = 0
                return f"tools: {tc} call(s)"
            if fid == "cli-version":
                return ctx.get("cli_version_line")
            if fid == "billing":
                return ctx.get("billing_line")
            if fid == "turn-tokens":
                return ctx.get("turn_tokens_line")
            if fid == "session-tokens":
                return ctx.get("session_tokens_line")
            if fid == "timing":
                return ctx.get("timing_line")
            if fid == "web-search":
                return ctx.get("web_search_line")
            if fid == "prompt-cache":
                lines = ctx.get("prompt_cache_lines")
                if not lines:
                    return None
                if layout == "panel" and isinstance(lines, list):
                    # Panel mode supports multi-line fields.
                    return [str(x) for x in lines if x]
                # Line mode: join.
                if isinstance(lines, list):
                    one = "; ".join([str(x) for x in lines if str(x).strip()])
                    return one if one.strip() else None
                return str(lines)
            if fid == "context-meter":
                cm = ctx.get("context_meter")
                if not isinstance(cm, dict):
                    return None
                if layout == "line":
                    return {"kind": "context_meter", "data": cm}
                # Panel: use rich-markup-friendly line when provided.
                return ctx.get("context_meter_panel") or ctx.get("context_meter_plain")
            if fid in ("context-used", "context-remaining", "context-window-size"):
                known = bool(ctx.get("context_window_known"))
                if not known:
                    return None
                try:
                    pct = float(ctx.get("context_pct") or 0.0)
                except Exception:
                    pct = None
                if fid == "context-used":
                    return f"context used: {pct:.1f}%" if isinstance(pct, float) else None
                if fid == "context-remaining":
                    return f"context remaining: {max(0.0, 100.0 - float(pct)):.1f}%" if isinstance(pct, float) else None
                if fid == "context-window-size":
                    try:
                        w = int(ctx.get("context_window") or 0)
                    except Exception:
                        w = 0
                    return f"context window: {w}" if w > 0 else None
            if fid in ("used-tokens", "total-input-tokens", "total-output-tokens"):
                try:
                    cin = int(ctx.get("cum_in") or 0)
                    cout = int(ctx.get("cum_out") or 0)
                    ctot = int(ctx.get("cum_total") or 0)
                except Exception:
                    cin = cout = ctot = 0
                if fid == "used-tokens":
                    return f"tokens: {ctot}" if ctot > 0 else None
                if fid == "total-input-tokens":
                    return f"in: {cin}"
                if fid == "total-output-tokens":
                    return f"out: {cout}"
            return None

        if layout == "panel":
            lines: List[str] = []
            for fid in fields:
                val = _field_value(fid)
                if val is None:
                    continue
                if isinstance(val, list):
                    for ln in val:
                        if isinstance(ln, str) and ln.strip():
                            lines.append(ln)
                else:
                    s = str(val)
                    if s.strip():
                        lines.append(s)
            if not lines:
                return
            self.ui.info_box("Usage & Info", lines)
            return

        # One-line layout
        first = True
        for fid in fields:
            val = _field_value(fid)
            if val is None:
                continue
            if not first:
                # Important: do NOT let the UI's non-verbose "dim" suppression hide
                # the separator between inline segments (Issue #17).
                self.ui.print(" | ", style=self.ui.theme.get("dim"), end="", force=True)
            first = False
            if isinstance(val, dict) and val.get("kind") == "context_meter":
                _print_context_meter_inline(val.get("data") or {})
            else:
                # Always render as plain text for line mode.
                s = str(val).replace("\n", " ")
                self.ui.print(s, end="")
        if not first:
            self.ui.print()  # newline

        return

    def _cli_approval_for(
        self,
        name: Optional[str],
        args: Dict[str, Any],
        policy: Optional[Any] = None,
        level: Optional[int] = None,
    ) -> bool:
        # Gate only at Level 2; Levels 1 and 3 are handled elsewhere.
        self._last_approval_error = None
        lvl = self._coerce_level(level)
        if lvl is None:
            lvl = self._effective_control_level()
        if lvl != 2:
            return True
        key = (name or "").strip().lower()
        # Auto-approve list for backwards compatibility
        if key in (self.auto_approve or []):
            return True
        # run_command per-base trust
        if key == "run_command":
            base = self._base_command_from_args(args if isinstance(args, dict) else {})
            if not base:
                # empty commands are denied
                return False
            if base in self.trust_cmds_session or base in self.trust_cmds_always:
                return True
            label = f"run_command:{base}"
            choice = self._approval_prompt_ui(label, args, policy=policy)
            if choice in ("deny", "preview_failed"):
                return False
            if choice == "session":
                if base not in self.trust_cmds_session:
                    self.trust_cmds_session.append(base)
                return True
            if choice == "always":
                if base not in self.trust_cmds_always:
                    self.trust_cmds_always.append(base)
                self.save_settings()
                return True
            return True  # once
        # Other destructive tools: trust by tool name
        destructive = {"write_file", "append_file", "edit_file", "apply_patch", "string_replace"}
        if key in destructive:
            if key in self.trust_tools_session or key in self.trust_tools_always:
                return True
            choice = self._approval_prompt_ui(key, args, policy=policy)
            if choice in ("deny", "preview_failed"):
                return False
            if choice == "session":
                if key not in self.trust_tools_session:
                    self.trust_tools_session.append(key)
                return True
            if choice == "always":
                if key not in self.trust_tools_always:
                    self.trust_tools_always.append(key)
                self.save_settings()
                return True
            return True
        # Non-destructive tools do not require approval
        return True

    async def _trust_menu(self) -> None:
        # Simple interactive editor for trust lists
        while True:
            self.ui.header("Level 2 Trust", "Approve Once / Session / Always for tools and commands")
            self.ui.print(f"Tools (always): {', '.join(self.trust_tools_always) if self.trust_tools_always else '(none)'}", style=self.ui.theme["dim"])
            self.ui.print(f"Tools (session): {', '.join(self.trust_tools_session) if self.trust_tools_session else '(none)'}", style=self.ui.theme["dim"])
            self.ui.print(f"Commands (always): {', '.join(self.trust_cmds_always) if self.trust_cmds_always else '(none)'}", style=self.ui.theme["dim"])
            self.ui.print(f"Commands (session): {', '.join(self.trust_cmds_session) if self.trust_cmds_session else '(none)'}", style=self.ui.theme["dim"])
            choice = await self._menu_choice(
                "Manage Trust",
                "Choose an action:",
                [
                    ("add_tool_always", "Add tool to Always trust (write_file, append_file, edit_file, apply_patch)"),
                    ("add_cmd_always", "Add base command to Always trust (e.g., grep, rg)"),
                    ("clear_session", "Clear session trust (tools and commands)"),
                    ("back", "Back"),
                ],
            )
            if choice in (None, "back"):
                return
            if choice == "add_tool_always":
                s = self.ui.prompt("Enter tool name", default="write_file")
                k = s.strip().lower()
                if k:
                    if k not in self.trust_tools_always:
                        self.trust_tools_always.append(k)
                        self.save_settings()
                        self.ui.success(f"Added '{k}' to always-trusted tools")
            elif choice == "add_cmd_always":
                s = self.ui.prompt("Enter base command (e.g., grep)", default="grep")
                k = s.strip().lower()
                if k:
                    if k not in self.trust_cmds_always:
                        self.trust_cmds_always.append(k)
                        self.save_settings()
                        self.ui.success(f"Added '{k}' to always-trusted commands")
            elif choice == "clear_session":
                self.trust_tools_session = []
                self.trust_cmds_session = []
                self.ui.success("Cleared session trust lists")
    def _tool_summary(self, name: str, args: Dict[str, Any]) -> str:
        # Friendly, one-line explanation per tool
        if name == "read_file":
            p = args.get("path", "")
            return f"🔍 Reading file: {p}"
        if name == "write_file":
            p = args.get("path", "")
            n = len(args.get("content", "") or "")
            return f"📝 Writing file: {p} ({n} chars, overwrite)"
        if name == "append_file":
            p = args.get("path", "")
            n = len(args.get("content", "") or "")
            return f"📎 Appending to file: {p} (+{n} chars)"
        if name == "list_dir":
            p = args.get("path", "") or "."
            try:
                cwd = os.getcwd()
            except Exception:
                cwd = "n/a"
            return f"📂 Listing directory: {p} (scope: {self._fs_label()}, CLI cwd: {cwd})"
        if name == "edit_file":
            p = args.get("path", "")
            return f"✏️ Editing file: {p}"
        if name == "run_command":
            c = args.get("cmd", "")
            return f"💻 Running: {c}"
        if name == "run_shell":
            c = args.get("command", "")
            return f"💻 Running (shell): {c}"
        return f"🔧 Tool call: {name}"

    def _render_tool_call(self, name: str, args: Dict[str, Any]) -> None:
        """Compact tool call notifier (non-yellow). Respects self.show_tool_calls.
        Prints a single line with an emoji summary and, when verbose, a dim args preview.
        """
        if not self.show_tool_calls:
            return
        try:
            # Determine the most accurate model label available for this turn
            try:
                model_prefix = (self._current_turn.get("model") or self._last_used_model or self.model or "(server default)")
            except Exception:
                model_prefix = self.model or "(server default)"
            summary = self._tool_summary(name, args)
            # Make certain tools even more human-readable by enriching the summary
            if isinstance(name, str) and isinstance(args, dict):
                if name == "run_command":
                    cwd = args.get("cwd")
                    if cwd and isinstance(cwd, str) and cwd.strip():
                        # Append working directory context
                        summary = summary + f" (in {cwd})"
                elif name == "apply_patch":
                    # Extract affected files from simplified patch format
                    patch_text = args.get("patch", "") or ""
                    dry = bool(args.get("dry_run", False))
                    affected = []
                    for line in str(patch_text).splitlines():
                        line = line.strip()
                        if not line:
                            continue
                        if line.startswith("*** Add File: ") or line.startswith("*** Update File: ") or line.startswith("*** Delete File: ") or line.startswith("*** Move to: "):
                            try:
                                affected.append(line.split(": ", 1)[1].strip())
                            except Exception:
                                continue
                    # Deduplicate in-order
                    seen = set(); uniq = []
                    for a in affected:
                        if a and a not in seen:
                            uniq.append(a); seen.add(a)
                    if uniq:
                        max_show = 3
                        shown = ", ".join(uniq[:max_show])
                        more = len(uniq) - max_show
                        more_str = f", +{more} more" if more > 0 else ""
                        extra = " (dry-run)" if dry else ""
                        summary = f"Patching: {shown}{more_str}{extra}"
                    else:
                        extra = " (dry-run)" if dry else ""
                        summary = f"Patching files{extra}"
            # Use the orange accent for tool calls; include model name prefix for clarity
            self.ui.print(f"{model_prefix}: ", style=self.ui.theme["tool_call"], end="")
            self.ui.print("⇒ " + str(summary), style="white")
            # When verbose, include a short dim arg preview for troubleshooting
            if self.ui.verbose and isinstance(args, dict) and args:
                self.ui.print(self._clip(truncate_json(args, 400), 400), style=self.ui.theme["dim"])
        except Exception:
            # Never fail UI on notifier issues
            pass
    def _tool_concise_label(self, name: str, args: Dict[str, Any], result: Optional[Dict[str, Any]] = None) -> str:
        """Return a professional, natural-language one-liner describing the action.
        Used for the default concise tool result line.
        """
        n = (name or "").strip()
        a = args or {}
        data = (result or {}).get("data") if isinstance(result, dict) else None
        data = data if isinstance(data, dict) else {}

        # Universal context handoff tool (server-side). Show what files the model chose to keep.
        if n.lower() == "context_handoff":
            try:
                rd = (result or {}).get("data") if isinstance(result, dict) else None
                rd = rd if isinstance(rd, dict) else {}
                reason = (rd.get("reason") if isinstance(rd, dict) else None) or ""
                keep_files = rd.get("keep_files") if isinstance(rd, dict) else None
                files: List[str] = []
                if isinstance(keep_files, list):
                    for x in keep_files:
                        if isinstance(x, str) and x.strip():
                            files.append(x.strip())
                # Limit for single-line readability
                shown = files[:5]
                more = max(0, len(files) - len(shown))
                if shown:
                    files_part = ", ".join(shown) + (f" (+{more} more)" if more else "")
                    return (
                        "Context handoff prepared"
                        + (f" (reason={reason})" if str(reason).strip() else "")
                        + f". Files kept in context: {files_part}"
                    )
                return (
                    "Context handoff prepared"
                    + (f" (reason={reason})" if str(reason).strip() else "")
                    + ". No files were selected to be kept in context"
                )
            except Exception:
                return "Context handoff prepared"

        def _arg_path() -> str:
            p = a.get("path") or data.get("path") or ""
            try:
                return str(p)
            except Exception:
                return ""

        if n == "read_file":
            p = _arg_path() or "file"
            return f"Reading {p}"
        if n == "write_file":
            p = _arg_path() or "file"
            return f"Writing {p}"
        if n == "append_file":
            p = _arg_path() or "file"
            return f"Appending to {p}"
        if n == "list_dir":
            p = a.get("path") or data.get("path") or "."
            try:
                p = str(p) if str(p).strip() else "."
            except Exception:
                p = "."
            return f"Listing directory {p}"
        if n == "edit_file":
            p = _arg_path() or "file"
            return f"Editing {p}"
        if n == "run_command":
            cmd = a.get("cmd") or data.get("cmd") or "command"
            try:
                cmd_str = self._single_line(cmd, max_len=160)
            except Exception:
                cmd_str = "command"
            return f"Executing command: {cmd_str}"
        if n == "apply_patch":
            # Attempt to extract a few affected files
            patch_text = a.get("patch", "") or ""
            affected = []
            try:
                for line in str(patch_text).splitlines():
                    s = line.strip()
                    if not s:
                        continue
                    if s.startswith("*** Add File: ") or s.startswith("*** Update File: ") or s.startswith("*** Delete File: ") or s.startswith("*** Move to: "):
                        try:
                            affected.append(s.split(": ", 1)[1].strip())
                        except Exception:
                            continue
            except Exception:
                affected = []
            # Dedup + keep order
            uniq = []
            seen = set()
            for x in affected:
                if x and x not in seen:
                    uniq.append(x); seen.add(x)
            if uniq:
                first = uniq[:2]
                more = len(uniq) - len(first)
                base = ", ".join(first)
                suffix = f" (+{more} more)" if more > 0 else ""
                return f"Applying patch to {base}{suffix}"
            return "Applying patch"
        if n == "string_replace":
            try:
                summ = data.get("summary") if isinstance(data, dict) else {}
            except Exception:
                summ = {}
            try:
                total = int((summ or {}).get("total_replacements", 0) or 0)
                targets = int((summ or {}).get("total_targets", 0) or 0)
                files_changed = int((summ or {}).get("files_changed", 0) or 0)
                fc = int((summ or {}).get("files_considered", 0) or 0)
            except Exception:
                total, targets, files_changed, fc = 0, 0, 0, 0
            scope = f"across {files_changed}/{fc} file(s)" if fc else (f"in {files_changed} file(s)" if files_changed else "")
            if targets:
                return f"String replace: {total}/{targets} replaced {scope}".strip()
            return f"String replace: {total} replaced {scope}".strip()
        # Default fallback
        return f"Running tool: {n or 'unknown'}"

    def _render_tool_result_concise_line(
        self,
        name: str,
        result: Dict[str, Any],
        *,
        call_id: Optional[str] = None,
        args_ctx: Optional[Dict[str, Any]] = None,
        model_prefix: Optional[str] = None,
    ) -> None:
        """Render a single concise SUCCESS/FAILURE line for a tool result."""
        args_obj = args_ctx if isinstance(args_ctx, dict) else {}
        if not args_obj:
            try:
                if call_id and str(call_id) in self._tool_args_by_call_id:
                    args_obj = self._tool_args_by_call_id.get(str(call_id), {}) or {}
            except Exception:
                args_obj = {}

        label = self._tool_concise_label(name, args_obj, result)
        ok = bool(result.get("ok"))
        if not isinstance(model_prefix, str) or not model_prefix.strip():
            try:
                model_prefix = (
                    self._current_turn.get("model")
                    or self._last_used_model
                    or self.model
                    or "(server default)"
                )
            except Exception:
                model_prefix = self.model or "(server default)"

        if self.ui.rich:
            self.ui.print(f"{model_prefix}: ", style=self.ui.theme["tool_call"], end="")
            if ok:
                self.ui.print("[SUCCESS]", style=self.ui.theme["tool_result"], end=" ")
            else:
                self.ui.print("[FAILURE]", style=self.ui.theme["tool_result_err"], end=" ")
            err = result.get("error")
            if (not ok) and isinstance(err, str) and err.strip():
                self.ui.print(f"{label}: {self._clip(err, 160)}", style="white")
            else:
                self.ui.print(label, style="white")
        else:
            ORANGE = "\x1b[38;5;214m"
            GREEN = "\x1b[32m"
            RED = "\x1b[31m"
            WHITE = "\x1b[97m"
            RESET = "\x1b[0m"
            status_seg = f"{GREEN}[SUCCESS]{RESET}" if ok else f"{RED}[FAILURE]{RESET}"
            err = result.get("error")
            if (not ok) and isinstance(err, str) and err.strip():
                reason = self._clip(err, 160)
                msg = f"{ORANGE}{model_prefix}{RESET}: {status_seg} {WHITE}{label}: {reason}{RESET}"
            else:
                msg = f"{ORANGE}{model_prefix}{RESET}: {status_seg} {WHITE}{label}{RESET}"
            self.ui.print(msg)

        if str(name).strip().lower() == "context_handoff":
            keep_notes_text = self._context_handoff_keep_notes_text(result, args_obj)
            keep_notes_injected = self._context_handoff_keep_notes_injected(result)
            self._print_context_handoff_checkpoint(keep_notes_text, compact=True)
            self._print_context_handoff_injection_status(keep_notes_injected, compact=True)

    def _render_tool_running_line(
        self,
        name: str,
        args: Dict[str, Any],
        *,
        model_prefix: Optional[str] = None,
    ) -> None:
        """Render a durable RUNNING line when transient status cannot be used."""
        if not self.show_tool_calls:
            return
        try:
            if not isinstance(model_prefix, str) or not model_prefix.strip():
                model_prefix = (
                    self._current_turn.get("model")
                    or self._last_used_model
                    or self.model
                    or "(server default)"
                )
        except Exception:
            model_prefix = self.model or "(server default)"
        try:
            label = self._tool_concise_label(name, args if isinstance(args, dict) else {}, None)
        except Exception:
            label = f"Running tool: {name or 'unknown'}"
        if self.ui.rich:
            self.ui.print(f"{model_prefix}: ", style=self.ui.theme["tool_call"], end="")
            self.ui.print("[RUNNING]", style=self.ui.theme["tool_call"], end=" ")
            self.ui.print(label, style="white")
        else:
            ORANGE = "\x1b[38;5;214m"
            WHITE = "\x1b[97m"
            RESET = "\x1b[0m"
            self.ui.print(
                f"{ORANGE}{model_prefix}{RESET}: {ORANGE}[RUNNING]{RESET} {WHITE}{label}{RESET}"
            )

    def _render_tool_running_transient(
        self,
        name: str,
        args: Dict[str, Any],
        *,
        model_prefix: Optional[str] = None,
        reserve_next_line: bool = False,
    ) -> bool:
        """Show a transient single-line RUNNING status for concise tool mode."""
        if not self.show_tool_calls:
            return False
        if self._should_suspend_transient_tool_status() and (not reserve_next_line):
            return False
        try:
            if not isinstance(model_prefix, str) or not model_prefix.strip():
                model_prefix = (
                    self._current_turn.get("model")
                    or self._last_used_model
                    or self.model
                    or "(server default)"
                )
        except Exception:
            model_prefix = self.model or "(server default)"
        try:
            label = self._tool_concise_label(name, args if isinstance(args, dict) else {}, None)
        except Exception:
            label = f"Running tool: {name or 'unknown'}"
        try:
            cols = int(shutil.get_terminal_size(fallback=(120, 20)).columns or 120)
        except Exception:
            cols = 120
        cols = max(40, cols)
        try:
            model_prefix = self._single_line(str(model_prefix), max_len=max(8, min(48, cols // 3)))
        except Exception:
            model_prefix = str(model_prefix)
        prefix_plain = f"{model_prefix}: [RUNNING] "
        label_budget = max(8, (cols - 1) - len(prefix_plain))
        try:
            label = self._single_line(label, max_len=label_budget)
        except Exception:
            label = str(label)
        try:
            ORANGE = "\x1b[38;5;214m"
            WHITE = "\x1b[97m"
            RESET = "\x1b[0m"
            line = f"{ORANGE}{model_prefix}{RESET}: {ORANGE}[RUNNING]{RESET} {WHITE}{label}{RESET}"
            visible_width = max(1, len(prefix_plain) + len(label))
            sys.stdout.write("\r\x1b[2K" + line)
            if reserve_next_line:
                sys.stdout.write("\n")
            sys.stdout.flush()
            try:
                self._transient_tool_status_active = True
                self._transient_tool_status_rows = max(1, (visible_width + cols - 1) // cols)
                self._transient_tool_status_gap_rows = 1 if reserve_next_line else 0
            except Exception:
                pass
            return True
        except Exception:
            try:
                self.ui.print(f"{model_prefix}: [RUNNING] {label}", style=self.ui.theme.get("tool_call"))
                self._transient_tool_status_active = False
                self._transient_tool_status_rows = 1
                self._transient_tool_status_gap_rows = 0
                return True
            except Exception:
                return False

    def _clear_tool_running_transient(self, *, newline: bool = False) -> None:
        """Clear transient RUNNING status line."""
        try:
            active = bool(getattr(self, "_transient_tool_status_active", False))
        except Exception:
            active = False
        try:
            gap_rows = int(getattr(self, "_transient_tool_status_gap_rows", 0) or 0)
        except Exception:
            gap_rows = 0
        if (not active) and gap_rows <= 0:
            return
        if self._should_suspend_transient_tool_status() and gap_rows <= 0:
            return
        try:
            if gap_rows > 0:
                sys.stdout.write("\r")
                sys.stdout.write(f"\x1b[{gap_rows}A")
            if newline:
                sys.stdout.write("\r\x1b[2K\n")
            else:
                sys.stdout.write("\r\x1b[2K")
            sys.stdout.flush()
        except Exception:
            pass
        finally:
            try:
                self._transient_tool_status_active = False
                self._transient_tool_status_rows = 1
                self._transient_tool_status_gap_rows = 0
            except Exception:
                pass

    def _context_handoff_checkpoint_text(self, args: Any) -> str:
        """Extract keep_notes checkpoint text from a context_handoff tool args payload."""
        try:
            if not isinstance(args, dict):
                return ""
            raw = args.get("keep_notes")
            if not isinstance(raw, str):
                return ""
            return raw.strip()
        except Exception:
            return ""

    def _context_handoff_keep_notes_text(self, result: Any, args_fallback: Optional[Dict[str, Any]] = None) -> str:
        """Extract keep_notes payload from context_handoff tool.result payload."""
        try:
            if not isinstance(result, dict):
                return self._context_handoff_checkpoint_text(args_fallback or {})
            data = result.get("data")
            if isinstance(data, dict):
                kn = data.get("handoff_keep_notes")
                if isinstance(kn, str) and kn.strip():
                    return kn.strip()
            kn_top = result.get("handoff_keep_notes")
            if isinstance(kn_top, str) and kn_top.strip():
                return kn_top.strip()
        except Exception:
            pass
        return self._context_handoff_checkpoint_text(args_fallback or {})

    def _context_handoff_keep_notes_injected(self, result: Any) -> Optional[bool]:
        """Return whether keep_notes was injected into reset context, if provided by server."""
        try:
            if not isinstance(result, dict):
                return None
            data = result.get("data")
            if isinstance(data, dict):
                v = data.get("handoff_keep_notes_injected")
                if isinstance(v, bool):
                    return v
            v2 = result.get("handoff_keep_notes_injected")
            if isinstance(v2, bool):
                return v2
        except Exception:
            pass
        return None

    def _print_context_handoff_checkpoint(self, checkpoint: str, *, compact: bool = False) -> None:
        """Render context_handoff keep_notes so handoff quality is visible in CLI output."""
        cp = (checkpoint or "").strip()
        if not cp:
            self.ui.print("Model keep_notes: <empty>", style=self.ui.theme["warn"])
            return

        if compact:
            one_line = " ".join(cp.split())
            self.ui.print(
                f"Model keep_notes: {self._clip(one_line, 420)}",
                style=self.ui.theme["dim"],
            )
            return

        self.ui.print("Model keep_notes:", style=self.ui.theme["dim"])
        if self.ui.rich:
            self.ui.print(
                Panel(
                    self._clip(cp, 6000),
                    title="Context keep_notes",
                    border_style=self.ui.theme["dim"],
                )
            )
        else:
            self.ui.print(self._clip(cp, 6000), style=self.ui.theme["dim"])

    def _print_context_handoff_injection_status(self, injected: Optional[bool], *, compact: bool = False) -> None:
        """Render whether keep_notes was injected into the reset prompt context."""
        if injected is True:
            msg = "keep_notes injected into reset context: yes"
            style = self.ui.theme["dim"]
        elif injected is False:
            msg = "keep_notes injected into reset context: no"
            style = self.ui.theme["warn"]
        else:
            msg = "keep_notes injected into reset context: unknown (server did not report)"
            style = self.ui.theme["warn"]
        self.ui.print(msg if compact else f"Status: {msg}", style=style)

    def _render_tool_result(self, name: str, result: Dict[str, Any], call_id: Optional[str] = None) -> None:
        ok = bool(result.get("ok"))
        if not ok:
            err = result.get("error", "Unknown error")
            self.ui.print(f"⇐ [{self.ui.theme['tool_result_err']}]❌ {name} failed: {err}[/{self.ui.theme['tool_result_err']}]")
            # Print the full result payload for troubleshooting
            self.ui.print(self._clip(truncate_json(result, 2000), 2000), style=self.ui.theme["dim"])
            # Troubleshooting: show last args for this call_id if available
            if call_id and call_id in self._tool_args_by_call_id:
                args = self._tool_args_by_call_id.get(call_id, {})
                self.ui.print(self._clip(truncate_json(args, 1200), 1200), style=self.ui.theme["dim"])
            # Extra context for list_dir failures
            if name == "list_dir":
                try:
                    cli_cwd = os.getcwd()
                except Exception:
                    cli_cwd = "n/a"
                requested_path = None
                try:
                    args_ctx = self._tool_args_by_call_id.get(call_id, {}) if call_id else {}
                    requested_path = args_ctx.get("path", None) if isinstance(args_ctx, dict) else None
                except Exception:
                    requested_path = None
                self.ui.print(
                    f"[{self.ui.theme['dim']}]list_dir context — requested path: {requested_path if requested_path is not None else '(unknown)'} | scope: {self._fs_label()} | CLI cwd: {cli_cwd}[/{self.ui.theme['dim']}]"
                )
            return

        data = result.get("data", {}) or {}

        # Universal context_handoff tool: show where it was saved and what files were chosen.
        if name == "context_handoff":
            try:
                reason = data.get("reason")
                keep_files = data.get("keep_files")
                stats = data.get("resume_context_stats") if isinstance(data, dict) else None
                args_ctx: Dict[str, Any] = {}
                try:
                    if call_id and str(call_id) in self._tool_args_by_call_id:
                        args_ctx = self._tool_args_by_call_id.get(str(call_id), {}) or {}
                except Exception:
                    args_ctx = {}
                keep_notes_text = self._context_handoff_keep_notes_text(result, args_ctx)
                keep_notes_injected = self._context_handoff_keep_notes_injected(result)
                self.ui.print(
                    f"⇐ [{self.ui.theme['tool_result']}]✅ Context handoff prepared[/{self.ui.theme['tool_result']}]"
                    + (f" (reason={reason})" if isinstance(reason, str) and reason.strip() else "")
                )
                if isinstance(stats, dict):
                    try:
                        notes_chars = int(stats.get("keep_notes_chars", 0) or 0)
                    except Exception:
                        notes_chars = 0
                    try:
                        files_count = int(stats.get("keep_files_count", 0) or 0)
                    except Exception:
                        files_count = 0
                    self.ui.print(
                        f"Summary stats: keep_notes_chars={notes_chars}, keep_files_count={files_count}",
                        style=self.ui.theme["dim"],  # type: ignore
                    )
                if isinstance(keep_files, list) and keep_files:
                    cleaned = [str(x).strip() for x in keep_files if isinstance(x, (str, int, float)) and str(x).strip()]
                    if cleaned:
                        self.ui.print("Files kept in context:", style=self.ui.theme["dim"])  # type: ignore
                        for p in cleaned[:25]:
                            self.ui.print(f"- {p}", style=self.ui.theme["dim"])  # type: ignore
                        if len(cleaned) > 25:
                            self.ui.print(f"... +{len(cleaned)-25} more", style=self.ui.theme["dim"])  # type: ignore
                    else:
                        self.ui.print("No files were selected to be kept in context.", style=self.ui.theme["dim"])  # type: ignore
                else:
                    self.ui.print("No files were selected to be kept in context.", style=self.ui.theme["dim"])  # type: ignore
                self._print_context_handoff_checkpoint(
                    keep_notes_text,
                    compact=False,
                )
                self._print_context_handoff_injection_status(keep_notes_injected, compact=False)
            except Exception:
                # Fall through to default renderer below.
                pass
            return
        if name == "read_file":
            path = data.get("path", "")
            content = data.get("content", "") or ""
            tokens = data.get("tokens_used", None)
            if isinstance(tokens, int):
                extra = f"~{tokens} tokens"
            else:
                # Backward-compat fallback to chars
                chars = len(content)
                extra = f"{chars} chars"
            self.ui.print(f"⇐ [{self.ui.theme['tool_result']}]✅ Read {extra} from {path}[/{self.ui.theme['tool_result']}]")
            # If the client truncated a read (post-error tailing), surface a brief notice
            try:
                if bool(data.get("truncated")):
                    pol = data.get("truncation_policy") or {}
                    tail_lines = int(pol.get("tail_lines", 50) or 50)
                    char_cap = int(pol.get("char_cap", 30000) or 30000)
                    orig_chars = pol.get("original_chars")
                    reason = pol.get("reason") or "auto-large-file"
                    note = (
                        f"[tail] {reason}; returned only the last {tail_lines} lines (capped to {char_cap} chars)"
                        + (f" from {int(orig_chars)} chars" if isinstance(orig_chars, int) else "")
                    )
                    self.ui.print(note, style=self.ui.theme["warn"]) 
            except Exception:
                pass
            # Show a short preview
            preview = content.strip().splitlines()
            if preview:
                preview_text = "\n".join(preview[:8])
                if len(preview) > 8:
                    preview_text += "\n... (truncated)"
                if self.ui.rich:
                    self.ui.print(Panel(preview_text, title="Preview", border_style=self.ui.theme["dim"]))
                else:
                    self.ui.print("Preview:")
                    self.ui.print(preview_text)

        elif name == "write_file":
            path = data.get("path", "")
            tokens = data.get("tokens_used", None)
            if isinstance(tokens, int):
                extra = f"~{tokens} tokens written"
            else:
                # Backward-compat fallback
                n = data.get("bytes_written", None)
                extra = f"{n} bytes written" if isinstance(n, int) else "written"
            self.ui.print(f"⇐ [{self.ui.theme['tool_result']}]✅ Wrote to {path} ({extra})[/{self.ui.theme['tool_result']}]")

        elif name == "append_file":
            path = data.get("path", "")
            tokens = data.get("tokens_used", None)
            if isinstance(tokens, int):
                extra = f"~{tokens} tokens appended"
            else:
                # Backward-compat fallback
                n = data.get("bytes_appended", None)
                extra = f"{n} bytes appended" if isinstance(n, int) else "appended"
            self.ui.print(f"⇐ [{self.ui.theme['tool_result']}]✅ Appended to {path} ({extra})[/{self.ui.theme['tool_result']}]")

        elif name == "list_dir":
            path = data.get("path", "")
            items = data.get("items", []) or []
            self.ui.print(f"⇐ [{self.ui.theme['tool_result']}]✅ Listed {len(items)} item(s) under {path}[/{self.ui.theme['tool_result']}]")
            # Show working directory context for clarity
            try:
                cli_cwd = os.getcwd()
            except Exception:
                cli_cwd = "n/a"
            self.ui.print(f"[{self.ui.theme['dim']}]Working dir (resolved): {path} | scope: {self._fs_label()} | CLI cwd: {cli_cwd}[/{self.ui.theme['dim']}]")
            # Summarize first N items in a small table
            rows: List[Tuple[str, str, str]] = []
            for it in items[: self.max_dir_items]:
                itype = "📁 dir" if it.get("is_dir") else "📄 file"
                size = str(it.get("size", "")) if not it.get("is_dir") else ""
                rows.append((str(it.get("name", "")), itype, size))
            if rows:
                self.ui.table("Contents (preview)", rows)
            if len(items) > self.max_dir_items:
                self.ui.print(f"[{self.ui.theme['dim']}]... plus {len(items) - self.max_dir_items} more[/{self.ui.theme['dim']}]")

        elif name == "edit_file":
            path = data.get("path", "")
            applied = data.get("operations_applied", 0)
            lines_before = data.get("lines_before")
            lines_after = data.get("lines_after")
            delta_lines = data.get("delta_lines")
            growth_factor = data.get("growth_factor")
            ops_counts = data.get("ops_counts") or {}
            sr_matches = data.get("search_replace_total_matches")
            diff_stats = data.get("diff_stats") or {}

            # Compose a concise summary
            growth_str = ""
            if isinstance(growth_factor, (int, float)):
                try:
                    growth_str = f", x{growth_factor:.2f}"
                except Exception:
                    growth_str = ""

            lines_str = ""
            if lines_before is not None and lines_after is not None:
                lines_str = f" | lines: {lines_before} -> {lines_after} ({'+' if (delta_lines or 0) >= 0 else ''}{delta_lines}{growth_str})"

            self.ui.print(
                f"⇐ [{self.ui.theme['tool_result']}]✅ Edited {path} ({applied} op(s)){lines_str}[/{self.ui.theme['tool_result']}]"
            )

            # Ops breakdown
            if ops_counts:
                parts = [f"{k}:{v}" for k, v in sorted(ops_counts.items())]
                self.ui.print(f"[{self.ui.theme['dim']}]ops: " + ", ".join(parts) + f"{f' | search_replace_matches:{sr_matches}' if sr_matches else ''}[/{self.ui.theme['dim']}]")

            # Diff stats
            if diff_stats:
                la = diff_stats.get("lines_added")
                lr = diff_stats.get("lines_removed")
                self.ui.print(f"[{self.ui.theme['dim']}]diff stats: +{la} / -{lr}[/{self.ui.theme['dim']}]")

            safeguard = data.get("safeguard_triggered", False)
            if safeguard:
                msg = data.get("message") or "Safeguard triggered for large result."
                self.ui.print(f"[{self.ui.theme['warn']}]⚠ {msg}[/{self.ui.theme['warn']}]")
                self.ui.print(f"[{self.ui.theme['dim']}]You should receive an approval prompt to apply or cancel this change.[/{self.ui.theme['dim']}]")
            # Show warnings if present
            warns = data.get("warnings") or []
            if warns:
                self.ui.print(f"[{self.ui.theme['warn']}]Warnings:[/{self.ui.theme['warn']}]")
                for w in warns[:10]:
                    self.ui.print(f"- {self._clip(w, 300)}", style=self.ui.theme["dim"])
                if len(warns) > 10:
                    self.ui.print(f"[{self.ui.theme['dim']}]... {len(warns)-10} more warning(s)[/{self.ui.theme['dim']}]")
            # Ops debug (compact)
            dbg = data.get("ops_debug") or []
            if dbg:
                self.ui.print(f"[{self.ui.theme['dim']}]debug (first {min(10, len(dbg))} ops):[/{self.ui.theme['dim']}]")
                for d in dbg[:10]:
                    line = f"op#{d.get('idx')} {d.get('type')}"
                    if d.get("type") == "search_replace":
                        line += f" matches={d.get('matches')} flags='{d.get('flags')}' use_regex={d.get('use_regex')} pattern='{self._clip(d.get('pattern_preview'), 120)}'"
                    if d.get("type") == "smart_anchor_insert":
                        line += f" anchor='{self._clip(d.get('anchor_preview'), 120)}'"
                    self.ui.print(line, style=self.ui.theme["dim"])

        elif name == "string_replace":
            summ = data.get("summary", {}) or {}
            try:
                total = int(summ.get("total_replacements", 0) or 0)
                targets = int(summ.get("total_targets", 0) or 0)
                files_changed = int(summ.get("files_changed", 0) or 0)
                files_considered = int(summ.get("files_considered", 0) or 0)
            except Exception:
                total = targets = files_changed = files_considered = 0
            scope = f"across {files_changed}/{files_considered} file(s)" if files_considered else (f"in {files_changed} file(s)" if files_changed else "")
            if targets:
                self.ui.print(f"\u21d0 [{self.ui.theme['tool_result']}]\u2705 Replaced {total}/{targets} {scope}[/{self.ui.theme['tool_result']}]")
            else:
                self.ui.print(f"\u21d0 [{self.ui.theme['tool_result']}]\u2705 Replaced {total} {scope}[/{self.ui.theme['tool_result']}]")
            # Verbose per-file breakdown and example pairs
            if self.ui.verbose:
                details = data.get("details", []) or []
                max_examples = 5
                for d in details[:50]:
                    try:
                        path = d.get("path")
                        reps = int(d.get("replacements", 0) or 0)
                        tgts = int(d.get("targets", 0) or 0)
                        changed = bool(d.get("changed"))
                        self.ui.print(f"- {path}: {reps}/{tgts} replaced{' (changed)' if changed else ''}", style=self.ui.theme["dim"])  # type: ignore
                        # Examples of 'from' -> 'to'
                        exs = d.get("examples") or []
                        shown = 0
                        for ex in exs:
                            if shown >= max_examples:
                                break
                            frm = self._clip(ex.get("from", ""), 160)
                            to = self._clip(ex.get("to", ""), 160)
                            self.ui.print(f"    '{frm}' -> '{to}'", style=self.ui.theme["dim"])  # type: ignore
                            shown += 1
                        if exs and len(exs) > shown:
                            self.ui.print(f"    ... +{len(exs)-shown} more", style=self.ui.theme["dim"])  # type: ignore
                    except Exception:
                        continue
        elif name == "run_command":
            data = result.get("data", {}) or {}
            exit_code = data.get("exit_code")
            timed_out = data.get("timed_out", False)
            dur = data.get("duration_ms")
            self.ui.print(f"⇐ [{self.ui.theme['tool_result']}]✅ Command finished (exit={exit_code}, timed_out={timed_out}, {dur} ms)[/{self.ui.theme['tool_result']}]")

            stdout = (data.get("stdout") or "").strip("\n")
            stderr = (data.get("stderr") or "").strip("\n")

            if stdout:
                preview = "\n".join(stdout.splitlines()[:40])
                if self.ui.rich:
                    self.ui.print(Panel(preview, title="STDOUT (preview)", border_style=self.ui.theme["dim"]))
                else:
                    self.ui.print("STDOUT (preview):")
                    self.ui.print(preview)
            if stderr:
                preview = "\n".join(stderr.splitlines()[:40])
                if self.ui.rich:
                    self.ui.print(Panel(preview, title="STDERR (preview)", border_style=self.ui.theme["dim"]))
                else:
                    self.ui.print("STDERR (preview):")
                    self.ui.print(preview)

        elif name == "run_shell":
            data = result.get("data", {}) or {}
            exit_code = data.get("exit_code")
            timed_out = data.get("timed_out", False)
            dur = data.get("duration_ms")
            shell_name = data.get("shell")
            self.ui.print(
                f"⇐ [{self.ui.theme['tool_result']}]✅ Shell finished (shell={shell_name}, exit={exit_code}, timed_out={timed_out}, {dur} ms)[/{self.ui.theme['tool_result']}]"
            )

            stdout = (data.get("stdout") or "").strip("\n")
            stderr = (data.get("stderr") or "").strip("\n")

            if stdout:
                preview = "\n".join(stdout.splitlines()[:40])
                if self.ui.rich:
                    self.ui.print(Panel(preview, title="STDOUT (preview)", border_style=self.ui.theme["dim"]))
                else:
                    self.ui.print("STDOUT (preview):")
                    self.ui.print(preview)
            if stderr:
                preview = "\n".join(stderr.splitlines()[:40])
                if self.ui.rich:
                    self.ui.print(Panel(preview, title="STDERR (preview)", border_style=self.ui.theme["dim"]))
                else:
                    self.ui.print("STDERR (preview):")
                    self.ui.print(preview)

        else:
            # Unknown tool; just show JSON
            self.ui.print(f"⇐ [{self.ui.theme['tool_result']}]✅ {name} succeeded[/{self.ui.theme['tool_result']}]")
            self.ui.print(truncate_json(result, 600), style=self.ui.theme["dim"])
    def _render_web_search_summary(self, calls: List[Dict[str, Any]]) -> None:
        if not calls:
            return
        try:
            self.ui.print("\n\ud83d\udd0d Web search", style=self.ui.theme["info"])
        except Exception:
            pass
        for idx, call in enumerate(calls, 1):
            action = call.get("action") if isinstance(call, dict) else None
            if not isinstance(action, dict):
                action = {}
            query = action.get("query") or action.get("search_query") or "(no query)"
            try:
                self.ui.print(f"  [{idx}] {query}", style=self.ui.theme["dim"])
            except Exception:
                pass
            sources = action.get("sources")
            if not sources:
                sources = action.get("results")
            if isinstance(sources, list) and sources:
                for src_idx, source in enumerate(sources[:5], 1):
                    if not isinstance(source, dict):
                        continue
                    title = source.get("title") or source.get("url") or f"source {src_idx}"
                    url = source.get("url") or ""
                    try:
                        if url:
                            self.ui.print(f"     - {title} — {url}", style=self.ui.theme["dim"])
                        else:
                            self.ui.print(f"     - {title}", style=self.ui.theme["dim"])
                    except Exception:
                        pass
                if len(sources) > 5:
                    try:
                        self.ui.print(f"     - ... {len(sources) - 5} more", style=self.ui.theme["dim"])
                    except Exception:
                        pass

    # ---------------------------- Commands ----------------------------

    async def login(self) -> bool:
        """Authenticate against the FastAPI backend and persist cookies in-memory.
        Returns True on success, False on non-fatal failure. For a 401 Invalid username or password,
        the CLI will exit to prevent proceeding while unauthenticated.
        """
        username = self.ui.prompt("Username")
        password = getpass.getpass("Password: ")
        # Ask up-front so we can request a persistent refresh cookie from the server
        stay_logged_in = True
        try:
            choice = await self._menu_choice(
                "Stay logged in?",
                "Do you want to stay logged in on this machine (device-bound refresh tokens)?",
                [
                    ("yes", "Yes - keep me logged in"),
                    ("no", "No - only this session"),
                ],
            )
            stay_logged_in = (choice != "no")
        except Exception:
            stay_logged_in = True
        # Ensure we have a stable device identity for device-bound refresh tokens
        if stay_logged_in and not self.device_id:
            try:
                # Load existing device_id from disk if any
                self._load_auth_state_from_disk()
            except Exception:
                pass
            if not self.device_id:
                # Generate and keep in memory; will be persisted only if user confirms saving
                self.device_id = uuid.uuid4().hex
        try:
            # Build an SSE-friendly timeout config when no explicit timeout provided
            if self.timeout is None:
                http_timeout = httpx.Timeout(connect=10.0, read=None, write=10.0, pool=10.0)
            else:
                http_timeout = httpx.Timeout(self.timeout)

            async with httpx.AsyncClient(timeout=http_timeout, cookies=self.cookies) as client:
                body = {
                    "username": username,
                    "password": password,
                    # Request persistent refresh cookie when user asked to stay logged in
                    "remember_me": bool(stay_logged_in),
                }
                if stay_logged_in and self.device_id:
                    body.update({
                        "device_id": self.device_id,
                        "device_name": self.device_name or f"{socket.gethostname()} cli",
                    })
                resp = await client.post(self.login_url, json=body)
                if resp.status_code >= 400:
                    # Read body safely
                    raw_text = ""
                    try:
                        body = await resp.aread()
                        raw_text = body.decode("utf-8", errors="replace")
                    except Exception:
                        raw_text = resp.text
                    # Try JSON parse to inspect detail
                    detail = None
                    try:
                        if raw_text:
                            j = json.loads(raw_text)
                            if isinstance(j, dict):
                                detail = j.get("detail")
                    except Exception:
                        detail = None
                    # Specific gate: 401 Invalid username or password -> do not proceed
                    if resp.status_code == 401 and isinstance(detail, str) and detail.lower() == "invalid username or password":
                        self.ui.error(f"Login failed: 401 {{\"detail\":\"Invalid username or password\"}}")
                        # Hard exit per requirement: do not let the user proceed
                        raise SystemExit(1)
                    # Generic failure (non-401 or different detail): report and allow retry
                    self.ui.error(f"Login failed: {resp.status_code} {raw_text}")
                    return False

                # Persist cookies returned by server (includes refresh when remember_me=true)
                self.cookies.update(resp.cookies)

                # Optional: confirm
                try:
                    chk = await client.get(self.check_auth_url)
                    if chk.status_code == 200:
                        data = chk.json()
                        if data.get("authenticated"):
                            self.auth_user = str(data.get("user") or username)
                            self.ui.success(f"Login successful. Authenticated as: {self.auth_user}")
                            # Persist auth state if user opted to stay logged in
                            try:
                                if stay_logged_in:
                                    self._save_auth_state_to_disk()
                                    self.ui.print("[auth] Login state saved locally.", style=self.ui.theme["dim"])
                                else:
                                    # Ensure any previous persisted state is cleared
                                    self._clear_auth_state_on_disk()
                            except Exception:
                                pass
                            return True
                except Exception:
                    pass

                self.ui.success("Login successful.")
                # Persist state based on original choice even if check-auth skipped
                try:
                    if stay_logged_in:
                        self._save_auth_state_to_disk()
                        self.ui.print("[auth] Login state saved locally.", style=self.ui.theme["dim"])
                    else:
                        self._clear_auth_state_on_disk()
                except Exception:
                    pass
                return True
        except SystemExit:
            # Re-raise hard exit so callers don't swallow it
            raise
        except Exception as e:
            self.ui.error(f"Login error: {e}")
            return False

    async def logout(self) -> None:
        try:
            async with httpx.AsyncClient(timeout=self.timeout, cookies=self.cookies) as client:
                resp = await client.post(self.logout_url)
                if resp.status_code >= 400:
                    try:
                        body = await resp.aread()
                        msg = body.decode("utf-8", errors="replace")
                    except Exception:
                        msg = resp.text
                    self.ui.warn(f"Logout request returned {resp.status_code}: {msg}")
                # Clear local cookie jar regardless
                self.cookies.clear()
                self.auth_user = None
                self.ui.success("Logged out.")
                # Also clear persisted auth on disk
                self._clear_auth_state_on_disk()
        except Exception as e:
            self.ui.error(f"Logout error: {e}")

    async def handle_command(self, user_input: str) -> bool:
        # Slash commands for power users
        cmd = user_input.strip()

        # Common typo alias
        if cmd in ("/clera", "/new"):
            cmd = "/clear"
        # Alias /thinking -> /reasoning (preserve optional argument)
        if cmd == "/thinking" or cmd.startswith("/thinking "):
            cmd = "/reasoning" + cmd[len("/thinking") :]
        if cmd == "/fast" or cmd.startswith("/fast "):
            cmd = "/priority" + cmd[len("/fast") :]

        if cmd in ("/menu", "/settings"):
            # Open new settings UI (no dependencies). Legacy menu behind HENOSIS_SETTINGS_LEGACY=1
            await self.open_settings()
            return True

        if cmd.startswith("/history"):
            parts = cmd.split(maxsplit=1)
            if len(parts) == 1:
                self.ui.info("Usage: /history on|off")
                self.ui.info(f"Current: {'ON (synced to unified memory)' if self.save_chat_history else 'OFF (ephemeral)'}")
                return True
            arg = parts[1].strip().lower()
            if arg == "on":
                self.save_chat_history = True
                self.ui.success("Chat history will be saved to unified memory.")
            elif arg == "off":
                self.save_chat_history = False
                self.ui.success("Chat history is now ephemeral (local only, not synced).")
            else:
                self.ui.warn("Usage: /history on|off")
                return True
            self.save_settings()
            return True

        if cmd.startswith("/tools"):
            parts = cmd.split(maxsplit=1)
            if len(parts) == 1:
                self.ui.info("Usage: /tools on | /tools off | /tools default")
                self.ui.info(f"Current: {self._tools_label()}")
                return True
            arg = parts[1].strip().lower()
            if arg == "on":
                self.requested_tools = True
            elif arg == "off":
                self.requested_tools = False
            elif arg == "default":
                self.requested_tools = None
            else:
                self.ui.warn("Invalid value. Use: on, off, or default")
                return True
            self.ui.success(f"Tools set to: {self._tools_label()}")
            self.save_settings()
            return True

        if cmd.startswith("/websearch"):
            parts = cmd.split(maxsplit=2)
            if len(parts) == 1:
                self.ui.info(f"Web search: {'ON' if self.web_search_enabled else 'OFF'}")
                if self.web_search_allowed_domains:
                    self.ui.info(f"Allowed domains ({len(self.web_search_allowed_domains)}): {', '.join(self.web_search_allowed_domains)}")
                else:
                    self.ui.info("Allowed domains: (none)")
                self.ui.info(f"Include sources: {'ON' if self.web_search_include_sources else 'OFF'}")
                if self.web_search_location:
                    loc_str = ", ".join(f"{k}={v}" for k, v in self.web_search_location.items())
                    self.ui.info(f"Location hint: {loc_str}")
                else:
                    self.ui.info("Location hint: (none)")
                self.ui.info("Usage: /websearch on|off | /websearch domains <comma-separated> | /websearch domains clear | /websearch sources on|off | /websearch location country=US city=London | /websearch location clear")
                return True
            sub = parts[1].strip().lower()
            arg = parts[2].strip() if len(parts) > 2 else ""
            if sub in ("on", "off"):
                self.web_search_enabled = (sub == "on")
                self.ui.success(f"Web search {'enabled' if self.web_search_enabled else 'disabled'}.")
                self.save_settings()
                return True
            if sub == "domains":
                if not arg:
                    if self.web_search_allowed_domains:
                        self.ui.info(f"Allowed domains ({len(self.web_search_allowed_domains)}): {', '.join(self.web_search_allowed_domains)}")
                    else:
                        self.ui.info("Allowed domains: (none)")
                    self.ui.info("Usage: /websearch domains example.com,another.com | /websearch domains clear")
                    return True
                if arg.lower() in ("clear", "none"):
                    self.web_search_allowed_domains = []
                    self.ui.success("Cleared web search domain allow-list.")
                else:
                    raw = arg.replace("\n", ",")
                    domains = [d.strip() for d in raw.split(",") if d.strip()]
                    if not domains:
                        self.ui.warn("No valid domains provided.")
                        return True
                    if len(domains) > 20:
                        self.ui.warn("Only the first 20 domains are allowed. Excess entries were ignored.")
                        domains = domains[:20]
                    self.web_search_allowed_domains = domains
                    self.ui.success(f"Web search allowed domains set ({len(domains)}).")
                self.save_settings()
                return True
            if sub == "sources":
                val = arg.lower()
                if val not in ("on", "off"):
                    self.ui.warn("Usage: /websearch sources on|off")
                    return True
                self.web_search_include_sources = (val == "on")
                self.ui.success(f"Include sources in web search response payload: {'ON' if self.web_search_include_sources else 'OFF'}")
                self.save_settings()
                return True
            if sub == "location":
                if not arg:
                    if self.web_search_location:
                        loc_str = ", ".join(f"{k}={v}" for k, v in self.web_search_location.items())
                        self.ui.info(f"Current web search location hint: {loc_str}")
                    else:
                        self.ui.info("No web search location hint set.")
                    self.ui.info("Usage: /websearch location country=US city=Seattle region=Washington | /websearch location clear")
                    return True
                if arg.lower() == "clear":
                    self.web_search_location = {}
                    self.ui.success("Cleared web search location hint.")
                    self.save_settings()
                    return True
                tokens = arg.replace(",", " ").split()
                loc: Dict[str, str] = {}
                for token in tokens:
                    if "=" not in token:
                        continue
                    key, value = token.split("=", 1)
                    key = key.strip()
                    value = value.strip()
                    if key and value:
                        loc[key] = value
                if not loc:
                    self.ui.warn("No valid key=value pairs provided. Example: /websearch location country=US city=Seattle")
                    return True
                if "type" not in loc:
                    loc["type"] = "approximate"
                self.web_search_location = loc
                self.ui.success("Web search location hint updated.")
                self.save_settings()
                return True
            self.ui.warn("Unknown /websearch subcommand. Use on, off, domains, sources, or location.")
            return True

        if cmd.startswith("/reasoning"):
            parts = cmd.split(maxsplit=1)
            if len(parts) == 1:
                self.ui.info("Usage: /reasoning low|medium|high|xhigh")
                self.ui.info(f"Current: {self.reasoning_effort}")
                return True
            arg = (parts[1] or "").strip().lower()
            if arg in ("low", "medium", "high", "xhigh"):
                self.reasoning_effort = arg

                self.ui.success(f"Reasoning effort set to: {self.reasoning_effort}")
                self.save_settings()
            else:
                self.ui.warn("Invalid value. Use: low, medium, high, or xhigh")
            return True

        if cmd.startswith("/priority"):
            parts = cmd.split(maxsplit=1)
            if len(parts) == 1:
                self.ui.info("Usage: /priority on|off|default")
                self.ui.info(f"Current: {'priority' if self.service_tier == 'priority' else 'default'}")
                return True
            arg = (parts[1] or "").strip().lower()
            if arg in ("on", "priority"):
                self.service_tier = "priority"
                self.ui.success("Priority processing enabled.")
                self.save_settings()
                return True
            if arg in ("off", "default", "standard"):
                self.service_tier = None
                self.ui.success("Priority processing set to default tier.")
                self.save_settings()
                return True
            self.ui.warn("Invalid value. Use: on, off, or default")
            return True

        if cmd.startswith("/thinkingbudget"):
            parts = cmd.split(maxsplit=1)
            if len(parts) == 1:
                cur = self.thinking_budget_tokens if isinstance(self.thinking_budget_tokens, int) else "default"
                self.ui.info("Usage: /thinkingbudget <tokens>|default")
                self.ui.info(f"Current: {cur}")
                self.ui.info("Note: Applies only to Anthropic models with '-thinking' suffix; server default is used when set to 'default'.")
                return True
            arg = (parts[1] or "").strip().lower()
            if arg in ("default", "none", "off"):
                self.thinking_budget_tokens = None
                self.ui.success("Thinking budget set to server default.")
                self.save_settings()
                return True
            # Accept integers with optional 'k' suffix (e.g., 20k)
            val_str = arg
            mul = 1
            if val_str.endswith("k"):
                val_str = val_str[:-1]
                mul = 1000
            try:
                n = int(val_str)
                n = n * mul
                if n <= 0:
                    raise ValueError()
                if n > 100_000_000:
                    self.ui.warn("Value too large; capping at 100,000,000 tokens.")
                    n = 100_000_000
                self.thinking_budget_tokens = n
                self.ui.success(f"Thinking budget set to: {n} tokens (applies to '-thinking' Anthropic models)")
                self.save_settings()
            except ValueError:
                self.ui.warn("Invalid value. Use an integer (e.g., 20000 or 20k) or 'default'.")
            return True

        if cmd.startswith("/thinkinginsight"):
            parts = cmd.split(maxsplit=1)
            if len(parts) == 1:
                self.ui.info("Usage: /thinkinginsight on|off")
                self.ui.info(f"Current: {'ON' if self.thinking_insight_enabled else 'OFF'}")
                return True
            arg = (parts[1] or "").strip().lower()
            if arg in ("on", "off"):
                self.thinking_insight_enabled = (arg == "on")
                self.ui.success(
                    f"Thinking insight {'enabled' if self.thinking_insight_enabled else 'disabled'}."
                )
                self.save_settings()
            else:
                self.ui.warn("Invalid value. Use: on or off")
            return True

        if cmd.startswith("/fs "):
            arg = cmd[len("/fs ") :].strip().lower()
            if arg in ("workspace", "host"):
                self.fs_scope = arg
                self.ui.success(f"FS Scope set to: {self._fs_label()}")
            elif arg == "default":
                self.fs_scope = None
                self.ui.success("FS Scope set to: SERVER DEFAULT")
            else:
                self.ui.warn("Usage: /fs workspace | /fs host | /fs default")
                return True
            self.save_settings()
            return True

        if cmd.startswith("/agent-scope "):
            path = cmd[len("/agent-scope ") :].strip()
            if not path:
                self.ui.warn("Usage: /agent-scope <absolute path>")
                return True
            self.host_base = path
            self._host_base_ephemeral = False
            self.ui.success(f"Agent scope set to: {self.host_base}")
            self.save_settings()
            try:
                self._codebase_map_raw = self._load_codebase_map_raw()
            except Exception:
                pass
            try:
                await self._maybe_prompt_agents_prepend_mode(trigger="agent-scope")
            except Exception:
                pass
            try:
                await self._ensure_agents_md_on_disk(trigger="agent-scope")
            except Exception:
                pass
            try:
                await self._offer_generate_code_map(self.host_base)
            except Exception:
                pass
            return True

        if cmd.startswith("/hostbase "):
            path = cmd[len("/hostbase ") :].strip()
            if not path:
                self.ui.warn("Usage: /hostbase <absolute path>")
                return True
            self.host_base = path
            self._host_base_ephemeral = False
            self.ui.success(f"Agent scope set to: {self.host_base}")
            self.save_settings()
            # Refresh codebase map source to prefer the configured host base
            try:
                self._codebase_map_raw = self._load_codebase_map_raw()
            except Exception:
                pass
            try:
                await self._maybe_prompt_agents_prepend_mode(trigger="hostbase")
            except Exception:
                pass
            try:
                await self._ensure_agents_md_on_disk(trigger="hostbase")
            except Exception:
                pass
            # Offer code map generation when newly set
            try:
                await self._offer_generate_code_map(self.host_base)
            except Exception:
                pass
            return True

        if cmd.startswith("/hostmode "):
            mode = cmd[len("/hostmode ") :].strip().lower()
            if mode not in ("any", "cwd", "custom"):
                self.ui.warn("Usage: /hostmode any|cwd|custom")
                return True
            self.fs_host_mode = mode
            if mode == "cwd":
                try:
                    self.host_base = os.getcwd()
                    self._host_base_ephemeral = False
                except Exception:
                    pass
            if mode == "custom" and not self.host_base:
                self.ui.warn("Host mode 'custom' selected but host_base is unset. Use /hostbase <path>.")
            self.ui.success(f"Host mode set to: {self.fs_host_mode} (host_base={self.host_base or '(none)'})")
            self.save_settings()
            return True

        if cmd == "/trust":
            await self._trust_menu()
            return True

        if cmd.startswith("/model "):
            raw = cmd[len("/model ") :].strip() or None
            self.model = self._resolve_model_alias(raw)
            self._clear_codex_backend_rollover()
            if not self.model:
                self.ui.info("Model cleared; server default will be used.")
            else:
                self.ui.success(f"Model set to: {self.model}")
            self._apply_model_side_effects()
            self.save_settings()
            return True

        if cmd.startswith("/infomode"):
            parts = cmd.split(maxsplit=1)
            if len(parts) == 1:
                self.ui.info("Usage: /infomode concise|verbose")
                self.ui.info(f"Current: {self.usage_info_mode}")
                return True
            arg = (parts[1] or "").strip().lower()
            if arg in ("concise", "verbose"):
                self.usage_info_mode = arg
                # For backwards compatibility, treat /infomode as selecting a preset.
                # Clear any explicit Issue-15 overrides so preset changes take effect.
                try:
                    self.status_fields = None
                    self.status_layout = None
                except Exception:
                    pass
                self.ui.success(f"Usage & Info mode set to: {self.usage_info_mode}")
                self.save_settings()
            else:
                self.ui.warn("Invalid value. Use: concise or verbose")
            return True

        if cmd.startswith("/statuslayout"):
            parts = cmd.split(maxsplit=1)
            if len(parts) == 1:
                cur = self.status_layout if isinstance(self.status_layout, str) else "auto"
                self.ui.info("Usage: /statuslayout auto|line|panel")
                self.ui.info(f"Current: {cur} (effective: {self._status_layout_effective()})")
                return True
            arg = (parts[1] or "").strip().lower()
            if arg in ("auto", "default"):
                self.status_layout = None
                self.ui.success("Status layout set to: auto (follow preset)")
                self.save_settings()
                return True
            if arg in ("line", "panel"):
                self.status_layout = arg
                self.ui.success(f"Status layout set to: {self.status_layout}")
                self.save_settings()
                return True
            self.ui.warn("Invalid value. Use: auto, line, or panel")
            return True

        if cmd.startswith("/statusfields"):
            parts = cmd.split(maxsplit=2)
            if len(parts) == 1:
                self.ui.info("Usage:")
                self.ui.info("- /statusfields show")
                self.ui.info("- /statusfields set field1,field2,...")
                self.ui.info("- /statusfields preset concise|verbose")
                self.ui.info("- /statusfields clear")
                return True
            sub = (parts[1] or "").strip().lower()
            if sub == "clear":
                self.status_fields = None
                self.ui.success("Status fields cleared (now following preset)")
                self.save_settings()
                return True
            if sub == "preset":
                if len(parts) < 3:
                    self.ui.warn("Usage: /statusfields preset concise|verbose")
                    return True
                preset = (parts[2] or "").strip().lower()
                if preset not in ("concise", "verbose"):
                    self.ui.warn("Usage: /statusfields preset concise|verbose")
                    return True
                self.usage_info_mode = preset
                self.status_fields = None
                self.status_layout = None
                self.ui.success(f"Status preset set to: {preset} (cleared overrides)")
                self.save_settings()
                return True
            if sub == "set":
                if len(parts) < 3:
                    self.ui.warn("Usage: /statusfields set field1,field2,...")
                    return True
                raw = str(parts[2] or "")
                toks = [t.strip() for t in raw.replace("\n", ",").split(",") if t.strip()]
                ids = self._status_field_ids()
                selected: List[str] = []
                seen = set()
                for t in toks:
                    if t in ids and t not in seen:
                        selected.append(t)
                        seen.add(t)
                self.status_fields = selected
                self.ui.success(f"Status fields set ({len(selected)}): {', '.join(selected) if selected else '(none)'}")
                self.save_settings()
                return True
            if sub == "show":
                lines: List[str] = []
                try:
                    src = "custom" if isinstance(self.status_fields, list) else "preset"
                    lines.append(f"Source: {src}")
                except Exception:
                    pass
                try:
                    cur_layout = self.status_layout if isinstance(self.status_layout, str) else "auto"
                    lines.append(f"Layout: {cur_layout} (effective: {self._status_layout_effective()})")
                except Exception:
                    pass
                try:
                    lines.append(f"Preset: {self.usage_info_mode}")
                except Exception:
                    pass
                try:
                    eff = self._status_fields_effective()
                    lines.append("Selected fields (effective order):")
                    for f in eff:
                        lines.append(f"- {f}")
                except Exception:
                    pass
                lines.append("")
                lines.append("Available fields:")
                try:
                    for d in self._status_fields_catalog():
                        if not isinstance(d, dict):
                            continue
                        fid = d.get("id")
                        lbl = d.get("label")
                        desc = d.get("desc")
                        if fid:
                            lines.append(f"- {fid}: {lbl}" + (f" — {desc}" if desc else ""))
                except Exception:
                    pass
                self.ui.info_box("Status fields", lines)
                return True
            self.ui.warn("Unknown subcommand. Use: show, set, preset, clear")
            return True
        if cmd == "/model":
            # Open the model selection menu directly
            await self.select_model_menu()
            return True

        if cmd.startswith("/level "):
            try:
                lvl = int(cmd[len("/level "):].strip())
                if lvl not in (1, 2, 3):
                    raise ValueError()
                self.control_level = lvl
                self.ui.success(f"Control level set to: {self.control_level}")
            except Exception:
                self.ui.warn("Usage: /level 1|2|3")
                return True
            self.save_settings()
            return True

        if cmd.startswith("/autoapprove "):
            s = cmd[len("/autoapprove "):].strip()
            names = [t.strip() for t in s.split(",") if t.strip()]
            self.auto_approve = names
            self.ui.success(f"Auto-approve set to: {','.join(self.auto_approve) if self.auto_approve else '(none)'}")
            self.save_settings()
            return True

        if cmd.startswith("/system "):
            self.system_prompt = cmd[len("/system ") :].strip()
            self.history = []
            self._remote_control_reset_transcript()
            if self.system_prompt:
                self.history.append({"role": "system", "content": self.system_prompt})
            self._clear_codex_backend_rollover()
            # Treat as a fresh session; allow map re-injection
            self._did_inject_codebase_map = False
            try:
                self._did_inject_agents_md = False
            except Exception:
                pass
            # Also allow custom first-turn injection again
            try:
                self._did_inject_custom_first_turn = False
            except Exception:
                pass
            self.ui.success("System prompt set.")
            # OpenAI threaded state is invalid once the system prompt changes.
            try:
                self._openai_previous_response_id = None
                self._openai_response_id_history = []
                self._openai_input_items = []
                self._openai_last_sent_input_items = None
                self._xai_previous_response_id = None
                self._xai_response_id_history = []
                self._xai_input_items = []
                self._xai_last_sent_input_items = None
                self._codex_local_input_items = []
                self._codex_local_last_sent_input_items = None
            except Exception:
                pass
            self.save_settings()
            return True

        if cmd.startswith("/title "):
            new_title = cmd[len("/title ") :].strip()
            if not new_title:
                self.ui.warn("Usage: /title <name>")
                return True
            self.thread_name = new_title
            self._manual_title = True
            self.ui.success(f"Thread title set to: {self.thread_name}")
            return True

        if cmd == "/clear":
            self.history = [{"role": "system", "content": self.system_prompt}] if self.system_prompt else []
            self._remote_control_reset_transcript()
            self._clear_codex_backend_rollover()
            self._did_inject_codebase_map = False
            try:
                self._did_inject_agents_md = False
            except Exception:
                pass
            try:
                self._did_inject_custom_first_turn = False
            except Exception:
                pass
            # Reset provider-native histories
            try:
                self.messages_for_save = []
                if not self.save_chat_history:
                    self.thread_uid = None
                self._kimi_raw_history = []
                self._gemini_raw_history = []
                self._anthropic_raw_history = []
                self._openai_previous_response_id = None
                self._openai_response_id_history = []
                self._openai_input_items = []
                self._openai_last_sent_input_items = None
                self._xai_previous_response_id = None
                self._xai_response_id_history = []
                self._xai_input_items = []
                self._xai_last_sent_input_items = None
                self._codex_local_input_items = []
                self._codex_local_last_sent_input_items = None
            except Exception:
                pass
            # Reset local cumulative token counters on session clear
            self._cum_input_tokens = 0
            self._cum_output_tokens = 0
            self._cum_total_tokens = 0
            # Reset cumulative reasoning tokens as well
            try:
                self._cum_reasoning_tokens = 0
            except Exception:
                pass
            # Reset cost accumulators and last billing details on session clear
            try:
                self.server_cumulative_cost_usd = 0.0
                self.cumulative_cost_usd = 0.0
                self._last_commit_cost_usd = 0.0
                self._last_remaining_credits = None
            except Exception:
                pass
            # Reset session wall-clock timer on clear
            try:
                self._session_started_at = time.perf_counter()
            except Exception:
                self._session_started_at = None
            self.ui.success("History cleared.")
            return True

        if cmd == "/toolslog":
            self.show_tool_calls = not self.show_tool_calls
            self.ui.success(f"Tool call logs: {'ON' if self.show_tool_calls else 'OFF'}")
            self.save_settings()
            return True

        if cmd.startswith("/map "):
            val = cmd[len("/map ") :].strip().lower()
            if val in ("on", "true", "1"):
                self.inject_codebase_map = True
                # allow re-injection on next message
                self._did_inject_codebase_map = False
                self.ui.success("Codebase map prefix: ON")
            elif val in ("off", "false", "0"):
                self.inject_codebase_map = False
                self.ui.success("Codebase map prefix: OFF")
            else:
                self.ui.warn("Usage: /map on | /map off")
                return True
            self.save_settings()
            return True

        if cmd == "/login":
            await self._login_with_retries()
            return True

        if cmd.startswith("/codex"):
            parts = cmd.split(maxsplit=1)
            sub = (parts[1].strip().lower() if len(parts) > 1 else "status")
            if sub in ("", "status"):
                self._render_codex_status()
                return True
            if sub == "login":
                await self._codex_login()
                return True
            if sub == "logout":
                self._clear_codex_auth_state_on_disk(clear_shared=True)
                self._clear_codex_backend_rollover()
                self._codex_local_input_items = []
                self._codex_local_last_sent_input_items = None
                self.ui.success("Cleared local Codex OAuth credentials.")
                return True
            self.ui.warn("Usage: /codex login | /codex status | /codex logout")
            return True

        if cmd == "/logout":
            await self.logout()
            # Exit the CLI after logging out per request
            print("Goodbye.")
            raise SystemExit(0)

        if cmd == "/configure":
            # Force-run the first-time configuration wizard even for existing users
            await self._maybe_run_first_time_wizard(force=True)
            return True

        # /preflight removed from CLI (server handles any background estimation)

        if cmd == "/whoami":
            authed = await self.check_auth()
            if authed:
                self.ui.success(f"Authenticated as: {self.auth_user}")
            else:
                if self._has_codex_auth_material():
                    self.ui.warn("Not authenticated with Henosis backend. Local Codex OAuth is available (run /codex status).")
                else:
                    self.ui.warn("Not authenticated.")
            return True

        return False

    # ---------------------------- Run loop ----------------------------

    async def run(self) -> None:
        # Try persisted auth
        self._load_auth_state_from_disk()
        
        # Proactively refresh tokens at startup if authenticated
        try:
            if self.cookies.get('refresh_token_cookie'):
                timeout = httpx.Timeout(connect=10.0, read=30.0, write=10.0, pool=10.0) if self.timeout is None else httpx.Timeout(self.timeout)
                async with httpx.AsyncClient(timeout=timeout, cookies=self.cookies) as client:
                    # Refresh to get current tokens and persist if rotated
                    r = await client.post(self.refresh_url, timeout=30.0)
                    if r.status_code == 200:
                        data = r.json()
                        if data.get('rotated'):
                            self._save_auth_state_to_disk()
                            self.ui.print("[auth] Tokens refreshed and saved", style=self.ui.theme["dim"])
        except Exception as e:
            # Non-fatal; continue with existing tokens
            if self.ui.verbose:
                self.ui.print(f"[auth] Token refresh check skipped: {e}", style=self.ui.theme["dim"])
        
        # If backend auth is missing, allow either backend login or local Codex OAuth.
        backend_authed = await self.check_auth()
        if not backend_authed:
            if not self._has_codex_auth_material():
                await self._welcome_flow()
                backend_authed = await self.check_auth()
                if (not backend_authed) and (not self._has_codex_auth_material()):
                    self.ui.error("Authentication required (Henosis login or Codex login). Exiting.")
                    raise SystemExit(1)
        if (not backend_authed) and (not self.model):
            self.model = self._default_codex_model()
            self._apply_model_side_effects()
            self.ui.info(f"No backend auth detected. Defaulting model to {self.model} for local Codex mode.")

        # Start local compatibility WS hub and backend Remote Control bridge
        if self.agent_mode:
            if not HAS_WS:
                self.ui.warn("Remote Control requested but 'websockets' is not available. Proceeding without WS.")
            else:
                try:
                    await self._start_ws_hub()
                    self.ui.print(f"[remote] Local compatibility WS listening on ws://{self.agent_host}:{self.agent_port}/agent/ws", style=self.ui.theme["dim"])
                except Exception as e:
                    self.ui.warn(f"Failed to start local compatibility WS hub: {e}")
                try:
                    await self._start_remote_control_bridge()
                except Exception as e:
                    self.ui.warn(f"Failed to start Remote Control bridge: {e}")

        if backend_authed:
            # Once authenticated, sync settings with the server
            try:
                await self._sync_settings_with_server()
            except Exception:
                # Non-fatal; continue with local defaults
                pass
            # Load profile once to detect subscription tier (free vs paid) for UX defaults
            try:
                await self._load_profile_for_tier()
            except Exception:
                # Non-fatal; if /profile is unavailable, keep prior behavior
                pass
            # Ensure per-terminal Agent scope binding after server sync
            try:
                self._rebind_agent_scope_default()
            except Exception:
                pass

            # Run first-run wizard when settings are at defaults
            try:
                await self._maybe_run_first_time_wizard()
            except Exception as e:
                self.ui.warn(f"Wizard skipped: {e}")
        else:
            self.ui.print("Using local Codex OAuth path (backend auth not present).", style=self.ui.theme["dim"])

        # Header after auth and settings sync
        # Show CLI version from metadata/pyproject when available
        if not self._cli_version:
            try:
                self._cli_version = self._resolve_current_version() or None
            except Exception:
                self._cli_version = None
        # Build opening header: "You are using henosis-cli v.x.x.x in <root>"
        # Determine the session root the CLI is operating in. Prefer the Agent scope (host_base) when set,
        # otherwise fall back to the local workspace directory, and finally the current working directory.
        try:
            session_root = None
            if isinstance(self.host_base, str) and self.host_base.strip():
                session_root = self.host_base
            elif isinstance(self.local_workspace_dir, str) and self.local_workspace_dir.strip():
                session_root = self.local_workspace_dir
            else:
                session_root = str(Path(os.getcwd()).resolve())
        except Exception:
            session_root = self.host_base or self.local_workspace_dir or os.getcwd()

        left_header = (
            f"You are using henosis-cli{(' v' + self._cli_version) if self._cli_version else ''} in {session_root}"
        )
        try:
            if self.agent_mode:
                left_header = f"{left_header} as {self._remote_control_terminal_display_name()}"
        except Exception:
            pass
        # For the right-aligned segment, show just the selected model name (omit '(server default)')
        selected_model = None
        try:
            if isinstance(self.model, str) and self.model.strip():
                selected_model = self.model.strip()
        except Exception:
            selected_model = None
        # Render single-line header with left message and optional right model label
        try:
            self.ui.header_inline(left_header, selected_model)
        except Exception:
            # Fallback plain header
            self.ui.header(left_header, subtitle=(selected_model or None))
        # Dev visibility: confirm whether local tools are importable on this client
        try:
            self.ui.print(f"[dev] Local tools available: {HAS_LOCAL_TOOLS}", style=self.ui.theme["dim"]) 
        except Exception:
            pass

        # Start chat immediately (suppress verbose startup banner)
        # Code map status line (prefer host base presence indicator)
        host_map_present = False
        try:
            if isinstance(self.host_base, str) and self.host_base.strip():
                host_map_present = self._code_map_exists_at(self.host_base)
        except Exception:
            host_map_present = False
        if not self.inject_codebase_map:
            self.ui.print("Code Map: OFF — toggle with /map on|off", style=self.ui.theme["dim"])
        else:
            if host_map_present:
                self.ui.print("Code Map: PRESENT at host base and will be prefixed to your first message.", style=self.ui.theme["dim"])
            elif self._codebase_map_raw:
                # We have a fallback map (repo copy) but none at host base
                self.ui.print("Code Map: fallback example in use (host base missing CODEBASE_MAP.md). It will be prefixed.", style=self.ui.theme["dim"])
            else:
                self.ui.print("Code Map: missing at host base — toggle with /map on|off", style=self.ui.theme["dim"])
        # History status
        hist_status = "ON (synced)" if self.save_chat_history else "OFF (ephemeral)"
        self.ui.print(f"Chat history: {hist_status}", style=self.ui.theme["dim"])
        # If a host base is configured and code map injection is enabled, offer to generate when missing
        try:
            if (
                self.inject_codebase_map
                and self.host_base
                and isinstance(self.host_base, str)
                and self.host_base.strip()
            ):
                await self._offer_generate_code_map(self.host_base)
        except Exception:
            pass
        # Tips banner above input
        hint_line = "- " + (getattr(self._input_engine, "info", None).hint if self._input_engine and getattr(self._input_engine, "info", None) else "Enter sends; Ctrl+J inserts a newline.")
        # If no input engine is available, our plain fallback uses multiline input with empty-line submit
        if not self._input_engine:
            hint_line = "- Empty line submits; paste freely."
        tips = [
            "Tips:",
            "- Type / to show the command list.",
            "- Use /clear often, after each task, for best performance.",
        ]
        if self.ui.rich and Panel:
            self.ui.print(Panel("\n".join(tips), title="Getting started", border_style=self.ui.theme["subtitle"]))
        else:
            for t in tips:
                self.ui.print(t)
        # Light status line
        if self.auth_user:
            self.ui.print(f"Authenticated as {self.auth_user}", style=self.ui.theme["dim"])
        elif self._has_codex_auth_material():
            aid = self.codex_account_id or "(unknown account)"
            if isinstance(aid, str) and len(aid) > 12:
                aid = f"{aid[:6]}...{aid[-4:]}"
            self.ui.print(f"Codex OAuth active ({aid})", style=self.ui.theme["dim"])
        # Prepare logging file
        self._ensure_session_log()
        # Prepare raw log file if enabled
        if self.raw_log_enabled:
            try:
                self._ensure_raw_log()
                if self.raw_log_path:
                    self.ui.print(f"[raw] Logging raw request/response to {self.raw_log_path}", style=self.ui.theme["dim"])  # type: ignore
            except Exception:
                pass
        # Start session wall-clock timer
        try:
            self._session_started_at = time.perf_counter()
        except Exception:
            self._session_started_at = None
        # Prepare completer for slash commands (if prompt_toolkit is available)
        pt_completer = self._commands_word_completer()
        while True:
            try:
                pending_edit = self._pending_user_edit
                edit_mode = pending_edit is not None

                # prompt_toolkit is intentionally not used.
                # Always prefer our dependency-free input engine when available.
                if self._input_engine:
                    if edit_mode:
                        # The low-level input engine doesn't support prefilling.
                        # Show the prior message and let the user paste a replacement.
                        try:
                            self.ui.print(
                                "\nInterrupted. Edit last message (press Enter on an empty line to resend unchanged):",
                                style=self.ui.theme["warn"],  # type: ignore
                            )
                            self.ui.print(str(pending_edit), style=self.ui.theme["dim"])  # type: ignore
                        except Exception:
                            pass
                        new_txt = await self._run_blocking_prompt_read(self._read_multiline_input, self._edit_prompt_label())
                        user_input = (str(pending_edit) if not new_txt.strip() else new_txt)
                    else:
                        # Do not add continuation prefixes on new lines.
                        user_input = await self._run_blocking_prompt_read(
                            self._input_engine.read_message,
                            self._chat_prompt_label(),
                            "",
                            None,
                            self._chat_input_prefill,
                        )
                else:
                    # Last-resort fallback.
                    if edit_mode:
                        try:
                            self.ui.print(
                                "\nInterrupted. Edit last message (press Enter on an empty line to resend unchanged):",
                                style=self.ui.theme["warn"],  # type: ignore
                            )
                            self.ui.print(str(pending_edit), style=self.ui.theme["dim"])  # type: ignore
                        except Exception:
                            pass
                        new_txt = await self._run_blocking_prompt_read(self._read_multiline_input, self._edit_prompt_label())
                        user_input = (str(pending_edit) if not new_txt.strip() else new_txt)
                    else:
                        user_input = await self._run_blocking_prompt_read(
                            self._read_multiline_input,
                            self._chat_prompt_label(),
                            None,
                            self._chat_input_prefill,
                        )

                # Clear pending edit state after we successfully collected input.
                if edit_mode:
                    self._pending_user_edit = None
                    self._pending_turn_snapshot = None
                else:
                    self._chat_input_prefill = ""
                try:
                    if self.agent_mode and self._input_engine and user_input:
                        prompt_label = self._edit_prompt_label() if edit_mode else self._chat_prompt_label()
                        self._rewrite_submitted_input_line(prompt_label, user_input)
                except Exception:
                    pass
                # Successful read resets interrupt window
                self._last_interrupt_ts = None
            except KeyboardInterrupt:
                # First Ctrl+C: interrupt input and warn; second within window exits
                now = time.time()
                try:
                    last = float(self._last_interrupt_ts) if self._last_interrupt_ts is not None else None  # type: ignore
                except Exception:
                    last = None
                if last is not None and (now - last) <= 2.0:
                    self.ui.print("Goodbye.")
                    return
                try:
                    if self._input_interrupt_event is not None:
                        self._input_interrupt_event.set()
                except Exception:
                    pass
                # Set/refresh first-interrupt timestamp and continue loop
                self._last_interrupt_ts = now
                self.ui.warn("Interrupted. Press Ctrl+C again within 2s to exit.")
                continue
            except EOFError:
                # Graceful exit on Ctrl+D / EOF
                self.ui.print("Goodbye.")
                return

            if not user_input:
                continue

            # Command palette if bare '/'
            if user_input == "/":
                # Build choices from the slash-command catalog and show a unified
                # highlighted menu (arrow keys move, Enter selects, Esc cancels).
                items = [
                    (c["usage"], f"{c['name']} - {c['desc']}") for c in self._commands_catalog
                ]
                picked = await self._menu_choice(
                    "Commands",
                    "Use \u2191/\u2193 to move, Enter to select, Esc to cancel",
                    items,
                )
                if picked:
                    user_input = picked
                else:
                    continue
            if user_input.startswith("/") and ("\n" not in user_input):
                handled = await self.handle_command(user_input)
                if handled:
                    continue

            try:
                # Issue #14: store user input for Up/Down arrow recall.
                # (Only stores real prompts, not slash-commands.)
                self._push_user_input_history(user_input)

                # Snapshot pre-turn state so Ctrl+C during streaming can revert cleanly.
                # This is critical for first-turn injections (code map/custom note/working memory)
                # which are applied by mutating flags during payload construction.
                self._pending_turn_snapshot = {
                    "history": copy.deepcopy(self.history),
                    "messages_for_save": copy.deepcopy(self.messages_for_save),
                    "kimi_raw": copy.deepcopy(self._kimi_raw_history),
                    "gemini_raw": copy.deepcopy(self._gemini_raw_history),
                    "openai_prev": getattr(self, "_openai_previous_response_id", None),
                    "openai_ids": copy.deepcopy(getattr(self, "_openai_response_id_history", [])),
                    "openai_input_items": copy.deepcopy(getattr(self, "_openai_input_items", [])),
                    "openai_last_sent_input_items": copy.deepcopy(getattr(self, "_openai_last_sent_input_items", None)),
                    "xai_prev": getattr(self, "_xai_previous_response_id", None),
                    "xai_ids": copy.deepcopy(getattr(self, "_xai_response_id_history", [])),
                    "xai_input_items": copy.deepcopy(getattr(self, "_xai_input_items", [])),
                    "xai_last_sent_input_items": copy.deepcopy(getattr(self, "_xai_last_sent_input_items", None)),
                    "inflight_dispatch": copy.deepcopy(getattr(self, "_inflight_dispatch", None)),
                    "did_inject_codebase_map": bool(getattr(self, "_did_inject_codebase_map", False)),
                    "did_inject_agents_md": bool(getattr(self, "_did_inject_agents_md", False)),
                    "did_inject_custom_first_turn": bool(getattr(self, "_did_inject_custom_first_turn", False)),
                    "did_inject_working_memory": bool(getattr(self, "_did_inject_working_memory", False)),
                    "memory_paths_for_first_turn": copy.deepcopy(getattr(self, "_memory_paths_for_first_turn", [])),
                    "last_built_user_content": getattr(self, "_last_built_user_content", None),
                }

                # Clear any stale in-flight dispatch context at turn start.
                self._inflight_dispatch = None

                use_local_codex_turn = self._should_use_local_codex_for_model(self.model)
                if (not self.auth_user) and (not use_local_codex_turn):
                    self.ui.warn(
                        "This model requires Henosis backend auth. Run /login or choose a Codex-backed model with /model."
                    )
                    continue

                # Record user message for backend thread persistence only when using backend path.
                if self.save_chat_history and (not use_local_codex_turn):
                    self.messages_for_save.append({
                        "role": "user",
                        "content": user_input,
                        "model": None,
                        "citations": None,
                        "last_turn_input_tokens": 0,
                        "last_turn_output_tokens": 0,
                        "last_turn_total_tokens": 0,
                    })
                self._log_line({"event": "user", "content": user_input})
                # Preflight removed from CLI (handled server-side only)

                # Busy gate for serialized turns
                if self._busy:
                    self.ui.warn("Agent is busy with another turn. Please wait...")
                    continue
                self._busy = True
                try:
                    await self._start_busy_input_reader()
                except Exception:
                    pass
                try:
                    try:
                        self._remote_last_completed = None
                    except Exception:
                        pass
                    try:
                        self._remote_control_append_message(
                            "user",
                            user_input,
                            model=self.model,
                            origin="cli",
                        )
                    except Exception:
                        pass
                    try:
                        self._current_turn["user_message"] = {
                            "text": user_input,
                            "model": self.model,
                            "origin": "cli",
                        }
                    except Exception:
                        pass
                    try:
                        await self._ws_broadcast(
                            "user.message",
                            {
                                "text": user_input,
                                "model": self.model,
                                "origin": "cli",
                            },
                        )
                    except Exception:
                        pass
                    assistant_text = await self._run_stream_with_cancel(user_input)
                finally:
                    try:
                        await self._stop_busy_input_reader()
                    except Exception:
                        pass
                    self._busy = False

                # If the stream was cancelled via Ctrl+C, keep partial text
                # in context and return to the normal prompt.
                if self._stream_cancelled:
                    partial = self._stream_partial_text or ""
                    content_sent = self._last_built_user_content or user_input
                    # Always keep the user message in context so it is
                    # not silently lost when cancel arrives before any
                    # assistant tokens were streamed.
                    self.history.append({"role": "user", "content": content_sent})
                    if partial.strip():
                        self.history.append({"role": "assistant", "content": partial})
                    # Roll forward provider-native replay state so the
                    # next turn can pick up seamlessly.
                    try:
                        self._preserve_provider_state_on_cancel(
                            content_sent, partial,
                        )
                    except Exception:
                        pass
                    try:
                        if partial.strip():
                            self._remote_control_append_message(
                                "assistant",
                                partial,
                                model=self._last_used_model or self.model,
                                origin="cli",
                            )
                    except Exception:
                        pass
                    self.ui.warn("Interrupted. Partial response kept in context.")
                    while self._queued_user_messages:
                        await self._process_queued_user_messages()
                    continue
            except (KeyboardInterrupt, asyncio.CancelledError):
                # Safety net for Ctrl+C outside of the streaming path
                # (e.g. during snapshot creation). _run_stream_with_cancel
                # handles the common streaming case internally.
                force_exit = bool(self._stream_force_exit)
                self._stream_force_exit = False
                try:
                    await self._cancel_inflight_dispatch()
                except (Exception, BaseException):
                    pass

                try:
                    sys.stdout.write("\r\x1b[2K\n")
                    sys.stdout.flush()
                except Exception:
                    try:
                        self.ui.print()
                    except Exception:
                        pass

                if force_exit:
                    self.ui.print("Goodbye.")
                    return
                self.ui.warn("Interrupted.")
                continue
            except httpx.HTTPStatusError as he:
                try:
                    if he.response is not None:
                        await he.response.aread()
                        body = he.response.text
                    else:
                        body = ""
                except Exception:
                    body = ""
                self.ui.error(f"[HTTP error] {he.response.status_code} {body}")
                continue
            except Exception as e:
                self.ui.error(f"[Client error] {e}")
                continue

            # Skip appending empty assistant messages to avoid 422 on next request
            if assistant_text.strip():
                # Persist the round with exactly what was sent (so first turn keeps the map)
                content_sent = self._last_built_user_content or user_input
                self.history.append({"role": "user", "content": content_sent})
                self.history.append({"role": "assistant", "content": assistant_text})
                try:
                    function_logs, thinking_insight = self._remote_control_last_completed_metadata()
                    self._remote_control_append_message(
                        "assistant",
                        assistant_text,
                        model=self._last_used_model or self.model,
                        origin="cli",
                        function_logs=function_logs,
                        thinking_insight=thinking_insight,
                    )
                except Exception:
                    pass
            while self._queued_user_messages:
                await self._process_queued_user_messages()

    # ----------------------------- Menus -----------------------------

    async def main_menu(self) -> Optional[str]:
        self.ui.clear()
        # Suppress verbose session overview in menu header
        self.ui.header("henosis-cli")
        # Dynamic auth action
        auth_action_key = "logout" if self.auth_user else "login"
        auth_action_label = f"🔓 Logout ({self.auth_user})" if self.auth_user else "🔑 Login"
        choices = [
            ("toggle_tools", f"🧰 Toggle Tools ({self._tools_label()}) - Enable/disable file tools per request (ON: request tools, OFF: no tools, DEFAULT: server setting)"),
            ("toggle_history", f"🕘 Toggle History ({'ON' if self.save_chat_history else 'OFF'}) - Save chats to unified memory"),
            ("set_scope", f"📦 Set Filesystem Scope (current: {self._fs_label()}) - Choose workspace (sandbox) or host (full filesystem access if allowed)"),
            ("set_host_base", f"🖥️  Set Agent Scope (current: {self.host_base or '(none)'}) - Absolute path the agent can access when host scope is enabled"),
            ("set_level", f"🔒 Set Control Level (current: {self.control_level or 'server default'}) - Security level: 1=read-only, 2=write/exec with approval, 3=full access"),
            ("set_auto_approve", f"⚙️  Set Auto-approve Tools (current: {','.join(self.auto_approve) if self.auto_approve else '(none)'}) - Tools to auto-approve at Level 2 (e.g., write_file)"),
            (auth_action_key, auth_action_label),
            ("select_model", f"📋 Select Model (current: {self.model or 'server default'}) - Pick from presets (gpt-5.4, gpt-5.3-codex, gemini-3.1-pro-preview, kimi-k2.5, etc.)"),
            ("change_model", f"🤖 Change Model (current: {self.model or 'server default'}) - Manually type a model name"),
            ("set_system_prompt", "📝 Set System Prompt - Add initial instructions for the AI"),
            ("clear_history", "🧹 Clear History - Reset chat history"),
            ("toggle_tool_logs", f"🔎 Toggle Tool Call Logs (currently {'ON' if self.show_tool_calls else 'OFF'}) - Show/hide tool call details"),
            ("toggle_map_prefix", f"🗺️  Toggle Codebase Map Prefix (currently {'ON' if self.inject_codebase_map else 'OFF'}) - Control injecting <codebase_map> into first user message"),
            ("toggle_preflight", f"⏱️  Toggle Preflight (currently {'ON' if self.preflight_enabled else 'OFF'}) - Confirm token/cost before sending"),
            ("start_chat", "💬 Start Chatting - Begin interactive chat with the AI"),
            ("quit", "🚪 Quit - Exit the CLI"),
        ]
        # Remove legacy history toggle from menu
        try:
            choices = [c for c in choices if c[0] not in ("toggle_preflight",)]
        except Exception:
            pass
        return await self._menu_choice(
            "Session Settings",
            "Use ↑/↓ to move, Enter to select (or type a number), Esc to cancel",
            choices,
        )

    async def select_model_menu(self) -> None:
        """
        Unified model picker with highlight navigation and a Recommended section.
        - Arrow keys to move; Enter to select; Esc to cancel
        """
        current = self.model or "server default"
        title = "Select Model"
        subtitle = f"Current: {current}"
        presets = self._model_presets()

        # Determine effective tier status
        # User is "effectively free" if they are on free tier AND have no positive credit balance known.
        has_credits = (self._last_remaining_credits is not None and self._last_remaining_credits > 0)
        is_effectively_free = (self.is_free_tier and not has_credits)

        # Recommended models ("feelings" order)
        rec_keys = [
            "gpt-5.4",
            "gpt-5.3-codex",
            "gpt-5",
            "gemini-3.1-pro-preview",
            "gemini-3-flash-preview",
            "claude-sonnet-4-6",
            "claude-opus-4-6",
            "kimi-k2.5",
            "grok-4.20-beta-0309-reasoning",
        ]

        # If effectively free, shuffle kimi-k2.5 to the top
        if is_effectively_free:
            target = "kimi-k2.5"
            if target in rec_keys:
                rec_keys.remove(target)
                rec_keys.insert(0, target)

        rec_set = set(rec_keys)

        # Build lists preserving rec_keys order
        preset_map = {m: lbl for m, lbl in presets}
        rec_list = []
        for k in rec_keys:
            if k in preset_map:
                rec_list.append((k, preset_map[k]))

        other_list = [(m, lbl) for (m, lbl) in presets if m not in rec_set]

        # Identify paid models by prefix
        paid_prefixes = ("gpt-", "claude-", "gemini-", "o1-")
        
        def is_paid_model(m_name: str) -> bool:
            return m_name.startswith(paid_prefixes)

        codex_auth_ready = self._has_codex_auth_material()

        def has_codex_sub_path(m_name: str) -> bool:
            return codex_auth_ready and self._is_codex_local_model(m_name)

        # Build choices
        choices: List[Tuple[str, str]] = []
        choices.append(("__hdr_rec__", "--- Recommended ---"))
        
        for m, lbl in rec_list:
            tags: List[str] = []
            if is_effectively_free and is_paid_model(m) and (not has_codex_sub_path(m)):
                tags.append("PAID")
            if has_codex_sub_path(m):
                tags.append("CODEX SUB")
            suffix = f" [{' | '.join(tags)}]" if tags else ""
            choices.append((m, f"{lbl}{suffix}"))
        
        choices.append(("__hdr_other__", "--- Other Models ---"))
        for m, lbl in other_list:
            tags = []
            if is_effectively_free and is_paid_model(m) and (not has_codex_sub_path(m)):
                tags.append("PAID")
            if has_codex_sub_path(m):
                tags.append("CODEX SUB")
            suffix = f" [{' | '.join(tags)}]" if tags else ""
            choices.append((m, f"{lbl}{suffix}"))
        
        # Per issue list: do not surface "server default" or "custom" in this picker.

        # Render and select using the unified highlighted picker
        picked: Optional[str] = None
        while True:
            val = await self._menu_choice(title, subtitle, choices)
            if val in (None, "__hdr_rec__", "__hdr_other__"):
                # Ignore headers or cancel; on cancel just return
                if val is None:
                    return
                continue
            
            picked = str(val)
            
            # Enforce free tier restrictions
            if is_effectively_free and is_paid_model(picked) and (not has_codex_sub_path(picked)):
                self.ui.warn(f"Model '{picked}' is a paid tier model. Access is restricted on the free tier without credits.")
                continue
                
            break

        # Apply selection
        self.model = picked
        self._clear_codex_backend_rollover()
        self.ui.success(f"Model set to: {self.model}")

        self._apply_model_side_effects()
        self.save_settings()

    # ---------------------- Menu actions ---------------------------

    async def handle_choice(self, choice: Optional[str]) -> bool:
        # Returns True to continue menu loop, False to go to chat or quit
        if choice is None:
            return True

        if choice == "toggle_tools":
            if self.requested_tools is None:
                self.requested_tools = True
            elif self.requested_tools is True:
                self.requested_tools = False
            else:
                self.requested_tools = None
            self.ui.success(f"Tools set to: {self._tools_label()}")
            self.save_settings()
            return True

        if choice == "toggle_history":
            self.save_chat_history = not self.save_chat_history
            self.ui.success(f"History set to: {'ON' if self.save_chat_history else 'OFF'}")
            self.save_settings()
            return True

        if choice == "set_scope":
            await self.set_scope_menu()
            return True

        if choice == "set_host_base":
            path = self.ui.prompt("Enter absolute path for Agent scope (leave empty to clear)", default=self.host_base or "")
            path = path.strip()
            if path:
                self.host_base = path
                self._host_base_ephemeral = False
                self.ui.success(f"Agent scope set to: {self.host_base}")
            else:
                self.host_base = None
                self.ui.success("Agent scope cleared.")
            self.save_settings()
            # Refresh codebase map source to prefer the configured host base
            try:
                self._codebase_map_raw = self._load_codebase_map_raw()
            except Exception:
                pass
            try:
                await self._maybe_prompt_agents_prepend_mode(trigger="menu")
            except Exception:
                pass
            try:
                await self._ensure_agents_md_on_disk(trigger="menu")
            except Exception:
                pass
            # Offer to generate a code map when setting a new host base
            try:
                if self.host_base:
                    await self._offer_generate_code_map(self.host_base)
            except Exception:
                pass
            return True

        if choice == "set_level":
            await self.set_level_menu()
            return True

        if choice == "set_auto_approve":
            await self.set_auto_approve_menu()
            return True

        if choice == "login":
            await self._login_with_retries()
            return True

        if choice == "logout":
            await self.logout()
            print("Goodbye.")
            raise SystemExit(0)

        if choice == "select_model":
            await self.select_model_menu()
            return True

        if choice == "change_model":
            model = self.ui.prompt("Enter model name (blank for server default)", default=self.model or "")
            self.model = self._resolve_model_alias(model if model.strip() else None)
            if not self.model:
                self.ui.info("Model cleared; server default will be used.")
            else:
                self.ui.success(f"Model set to: {self.model}")
            self._apply_model_side_effects()
            self.save_settings()
            return True

        if choice == "set_system_prompt":
            prompt = self.ui.prompt("Enter system prompt", default=self.system_prompt or "")
            self.system_prompt = prompt.strip()
            self.history = []
            self._remote_control_reset_transcript()
            if self.system_prompt:
                self.history.append({"role": "system", "content": self.system_prompt})
            # Treat as a fresh session; allow map re-injection
            self._did_inject_codebase_map = False
            try:
                self._did_inject_custom_first_turn = False
            except Exception:
                pass
            # Clear provider-native histories on system reset
            try:
                self.messages_for_save = []
                if not self.save_chat_history:
                    self.thread_uid = None
                self._kimi_raw_history = []
                self._gemini_raw_history = []
                self._anthropic_raw_history = []
                self._openai_previous_response_id = None
                self._openai_response_id_history = []
                self._openai_input_items = []
                self._openai_last_sent_input_items = None
                self._xai_previous_response_id = None
                self._xai_response_id_history = []
                self._xai_input_items = []
                self._xai_last_sent_input_items = None
                self._codex_local_input_items = []
                self._codex_local_last_sent_input_items = None
            except Exception:
                pass
            self.ui.success("System prompt set.")
            self.save_settings()
            return True

        if choice == "clear_history":
            self.history = [{"role": "system", "content": self.system_prompt}] if self.system_prompt else []
            self._remote_control_reset_transcript()
            self._did_inject_codebase_map = False
            try:
                self._did_inject_custom_first_turn = False
            except Exception:
                pass
            try:
                self.messages_for_save = []
                if not self.save_chat_history:
                    self.thread_uid = None
                self._kimi_raw_history = []
                self._gemini_raw_history = []
                self._anthropic_raw_history = []
                self._openai_previous_response_id = None
                self._openai_response_id_history = []
                self._openai_input_items = []
                self._openai_last_sent_input_items = None
                self._xai_previous_response_id = None
                self._xai_response_id_history = []
                self._xai_input_items = []
                self._xai_last_sent_input_items = None
                self._codex_local_input_items = []
                self._codex_local_last_sent_input_items = None
            except Exception:
                pass
            # Reset local cumulative token counters on session clear
            self._cum_input_tokens = 0
            self._cum_output_tokens = 0
            self._cum_total_tokens = 0
            # Reset cumulative reasoning tokens as well
            try:
                self._cum_reasoning_tokens = 0
            except Exception:
                pass
            # Reset cost accumulators and last billing details on session clear
            try:
                self.server_cumulative_cost_usd = 0.0
                self.cumulative_cost_usd = 0.0
                self._last_commit_cost_usd = 0.0
                self._last_remaining_credits = None
            except Exception:
                pass
            # Reset session wall-clock timer on clear
            try:
                self._session_started_at = time.perf_counter()
            except Exception:
                self._session_started_at = None
            self.ui.success("History cleared.")
            return True

        if choice == "toggle_tool_logs":
            self.show_tool_calls = not self.show_tool_calls
            self.ui.success(f"Tool call logs: {'ON' if self.show_tool_calls else 'OFF'}")
            self.save_settings()
            return True

        if choice == "toggle_map_prefix":
            self.inject_codebase_map = not self.inject_codebase_map
            # Reset flag so enabling applies to next message
            if self.inject_codebase_map:
                self._did_inject_codebase_map = False
            self.ui.success(f"Codebase map prefix: {'ON' if self.inject_codebase_map else 'OFF'}")
            self.save_settings()
            return True

        # 'toggle_preflight' removed from menu

        if choice == "start_chat":
            return False  # proceed to chatting

        if choice == "quit":
            print("Goodbye.")
            raise SystemExit

        return True

    # ----------------------- SSE Streaming loop ------------------------
    def _preserve_provider_state_on_cancel(
        self, user_content: str, partial_assistant: str,
    ) -> None:
        """Roll forward provider-native replay state on Ctrl+C cancel.

        During a normal turn, ``message.completed`` delivers delta items
        (OpenAI), an authoritative ``raw_provider_messages`` snapshot
        (Gemini), and similar per-provider payloads.  When the stream is
        cancelled those events never arrive, so this method patches the
        minimum state needed for the next turn to continue cleanly.

        * **Gemini / Kimi** -- ``provider.message`` and ``tool.result``
          SSE events already update ``_gemini_raw_history`` /
          ``_kimi_raw_history`` during streaming, so those histories are
          already consistent.  No extra work needed.
        * **OpenAI** -- The manual input-item chain
          (``_openai_input_items``) is only updated from
          ``openai_delta_items`` inside ``message.completed``.  Here we
          roll the chain forward to include the user message we sent and
          any partial assistant text.
        * **xAI** -- Same manual replay model as OpenAI, using
          ``xai_input_items`` + ``xai_delta_items``.
        """
        model = (
            self._current_turn.get("model")
            or self._last_used_model
            or self.model
            or ""
        )

        # --- OpenAI: roll _openai_input_items forward -----------------
        if self._is_openai_model(model):
            try:
                sent = self._openai_last_sent_input_items
                if isinstance(sent, list) and sent:
                    items = copy.deepcopy(sent)
                    # Include partial assistant text so the model knows
                    # what it already said before the user interrupted.
                    if partial_assistant.strip():
                        items.append({
                            "role": "assistant",
                            "content": partial_assistant,
                        })
                    self._openai_input_items = (
                        self._sanitize_openai_items(items)
                    )
            except Exception:
                pass
            finally:
                self._openai_last_sent_input_items = None

        # --- xAI: roll _xai_input_items forward -----------------------
        if self._is_xai_model(model):
            try:
                sent = self._xai_last_sent_input_items
                if isinstance(sent, list) and sent:
                    items = copy.deepcopy(sent)
                    if partial_assistant.strip():
                        items.append({
                            "role": "assistant",
                            "content": partial_assistant,
                        })
                    self._xai_input_items = (
                        self._sanitize_openai_items(items)
                    )
            except Exception:
                pass
            finally:
                self._xai_last_sent_input_items = None

        # --- Local Codex: roll native replay state forward -------------
        if self._should_use_local_codex_for_model(model):
            try:
                sent = self._codex_local_last_sent_input_items
                if isinstance(sent, list) and sent:
                    items = copy.deepcopy(sent)
                elif isinstance(self._codex_local_input_items, list) and self._codex_local_input_items:
                    items = copy.deepcopy(self._codex_local_input_items)
                else:
                    items = []
                if partial_assistant.strip():
                    append_partial = True
                    try:
                        last_item = items[-1] if items else None
                        if (
                            isinstance(last_item, dict)
                            and str(last_item.get("role") or "").strip().lower() == "assistant"
                            and str(last_item.get("content") or "") == partial_assistant
                        ):
                            append_partial = False
                    except Exception:
                        append_partial = True
                    if append_partial:
                        items.append({"role": "assistant", "content": partial_assistant})
                if items:
                    self._codex_local_input_items = self._sanitize_openai_items(items)
            except Exception:
                pass
            finally:
                self._codex_local_last_sent_input_items = None

        # --- Gemini / Kimi: already up-to-date (see docstring) --------

    async def _run_stream_with_cancel(self, user_input: str) -> str:
        """Wrap _stream_once so Ctrl+C cancels the stream gracefully.

        On cancel the SSE loop sees _stream_cancelled and breaks early.
        Whatever partial assistant text was accumulated is returned so the
        caller can keep it in conversation context.

        Key design decision: on cancel we KEEP all streamed content in
        context, append the user message + partial assistant reply to
        history, and return to the normal ``You>`` prompt -- no edit mode
        and no snapshot rollback.
        """
        self._stream_cancelled = False
        self._stream_partial_text = ""
        self._stream_force_exit = False

        # Install a custom SIGINT handler for the duration of streaming.
        # First Ctrl+C sets _stream_cancelled so the SSE loop breaks
        # naturally at the next event; second Ctrl+C force-raises.
        _original_handler = signal.getsignal(signal.SIGINT)
        _sigint_count = 0

        def _stream_sigint_handler(signum, frame):
            nonlocal _sigint_count
            _sigint_count += 1
            self._stream_cancelled = True
            if _sigint_count >= 2:
                self._stream_force_exit = True
                # Restore original handler and hard-interrupt on second press
                try:
                    signal.signal(signal.SIGINT, _original_handler or signal.default_int_handler)
                except Exception:
                    pass
                raise KeyboardInterrupt()

        try:
            signal.signal(signal.SIGINT, _stream_sigint_handler)
        except (OSError, ValueError):
            # signal.signal() can only be called from the main thread
            pass

        try:
            return await self._stream_once(user_input)
        except (KeyboardInterrupt, asyncio.CancelledError):
            self._stream_cancelled = True
            # Best-effort: cancel any in-flight client-dispatched tool
            try:
                await self._cancel_inflight_dispatch("cancelled by user")
            except Exception:
                pass
            # Clear any transient indicator / status line
            try:
                sys.stdout.write("\r\x1b[2K\n")
                sys.stdout.flush()
            except Exception:
                pass
            # Best-effort: show a usage notice even on hard-interrupt (no message.completed).
            # We can only estimate from what we already buffered locally.
            try:
                # Estimate completion/output chars from partial assistant text + tool event payload sizes.
                tool_chars = 0
                try:
                    evs = (self._current_turn.get("tool_events") or []) if isinstance(self._current_turn, dict) else []
                    if isinstance(evs, list):
                        # Keep it cheap: only sum a bounded amount.
                        for ev in evs[-50:]:
                            try:
                                tool_chars += len(json.dumps(ev, ensure_ascii=False))
                            except Exception:
                                tool_chars += len(str(ev))
                except Exception:
                    tool_chars = 0
                est_chars = len(self._stream_partial_text or "") + tool_chars
                self._render_cancelled_usage_notice(
                    model_label=(self._current_turn.get("model") if isinstance(self._current_turn, dict) else None),
                    est_completion_chars=est_chars,
                    tool_calls=len((self._current_turn.get("tool_events") or []) if isinstance(self._current_turn, dict) else []),
                    turn_secs=self._turn_elapsed_seconds(finalize=True),
                )
            except Exception:
                pass
            if self._stream_force_exit:
                raise KeyboardInterrupt()
            return self._stream_partial_text
        finally:
            # Restore the original SIGINT handler so normal Ctrl+C
            # behavior resumes at the input prompt.
            try:
                signal.signal(signal.SIGINT, _original_handler or signal.default_int_handler)
            except (OSError, ValueError):
                pass

    def _codex_extract_stream_text(self, event: str, data: Dict[str, Any]) -> str:
        """Extract only assistant text deltas from Codex Responses SSE events.

        Important: do not treat function-call argument deltas as assistant text.
        """
        try:
            if not isinstance(data, dict):
                return ""
            ev = str(event or "").strip().lower()
            if ev not in ("message.delta", "response.output_text.delta", "output_text.delta"):
                return ""
            val = data.get("delta")
            if isinstance(val, str):
                return val
            if isinstance(val, dict):
                t = val.get("text")
                if isinstance(t, str):
                    return t
            txt = data.get("text")
            if isinstance(txt, str):
                return txt
        except Exception:
            return ""
        return ""

    def _codex_output_items_from_data(self, data: Dict[str, Any]) -> List[Dict[str, Any]]:
        try:
            if not isinstance(data, dict):
                return []
            response = data.get("response")
            root = response if isinstance(response, dict) else data
            out = root.get("output")
            if isinstance(out, list):
                return [x for x in out if isinstance(x, dict)]
        except Exception:
            return []
        return []

    def _codex_collect_text_fragments(
        self,
        value: Any,
        depth: int = 0,
        preserve_ws: bool = False,
    ) -> List[str]:
        if depth > 5:
            return []
        out: List[str] = []
        try:
            if isinstance(value, str):
                s = value if preserve_ws else value.strip()
                if s:
                    out.append(s)
            elif isinstance(value, list):
                for item in value:
                    out.extend(
                        self._codex_collect_text_fragments(
                            item,
                            depth + 1,
                            preserve_ws=preserve_ws,
                        )
                    )
            elif isinstance(value, dict):
                for key in ("text", "summary", "delta", "content", "reasoning", "reasoning_content"):
                    if key in value:
                        out.extend(
                            self._codex_collect_text_fragments(
                                value.get(key),
                                depth + 1,
                                preserve_ws=preserve_ws,
                            )
                        )
        except Exception:
            return out
        return out

    def _codex_join_unique_blocks(self, parts: List[str]) -> str:
        out: List[str] = []
        seen: set = set()
        for p in parts or []:
            if not isinstance(p, str):
                continue
            s = p.strip()
            if not s:
                continue
            if s in seen:
                continue
            seen.add(s)
            out.append(s)
        return "\n\n".join(out)

    def _codex_collapse_reasoning_blocks(self, parts: List[str]) -> str:
        blocks: List[str] = []
        seen: set[str] = set()
        for p in parts or []:
            if not isinstance(p, str):
                continue
            s = p.strip()
            if not s or s in seen:
                continue
            seen.add(s)
            blocks.append(s)
        if not blocks:
            return ""
        if len(blocks) == 1:
            return blocks[0]

        def _norm_ws(v: str) -> str:
            try:
                return " ".join(str(v).split()).strip()
            except Exception:
                return str(v).strip()

        norm_pairs: List[Tuple[str, str]] = [(_norm_ws(b), b) for b in blocks]
        try:
            longest_norm, longest_raw = max(norm_pairs, key=lambda pair: len(pair[0]))
        except Exception:
            longest_norm, longest_raw = norm_pairs[-1]

        if longest_norm:
            subsumed = True
            for norm_text, _raw in norm_pairs:
                if norm_text == longest_norm:
                    continue
                if len(norm_text) < 4:
                    continue
                if norm_text not in longest_norm:
                    subsumed = False
                    break
            if subsumed:
                return longest_raw
        return "\n\n".join(blocks)

    def _codex_reasoning_summary_from_event(self, event: str, data: Dict[str, Any]) -> str:
        try:
            ev = str(event or "").strip().lower()
            if not any(tok in ev for tok in ("reasoning_summary", "reasoning", "thinking")):
                return ""
            if not isinstance(data, dict):
                return ""
            if ev.endswith(".delta"):
                chunks = self._codex_collect_text_fragments(data.get("delta"), preserve_ws=True)
                if not chunks:
                    chunks = self._codex_collect_text_fragments(data.get("text"), preserve_ws=True)
                if not chunks:
                    response = data.get("response")
                    if isinstance(response, dict):
                        chunks = self._codex_collect_text_fragments(response.get("delta"), preserve_ws=True)
                return "".join(chunks)
            chunks: List[str] = []
            for key in ("text", "summary", "delta", "reasoning", "reasoning_content"):
                chunks.extend(self._codex_collect_text_fragments(data.get(key)))
            if not chunks:
                response = data.get("response")
                if isinstance(response, dict):
                    for key in ("text", "summary", "delta", "reasoning", "reasoning_content"):
                        chunks.extend(self._codex_collect_text_fragments(response.get(key)))
            return self._codex_join_unique_blocks(chunks)
        except Exception:
            return ""

    def _codex_reasoning_event_types(self, event_counts: Dict[str, int]) -> List[str]:
        out: List[str] = []
        try:
            for key in sorted((event_counts or {}).keys()):
                k = str(key or "").strip().lower()
                if ("reason" in k) or ("think" in k):
                    out.append(k)
        except Exception:
            return []
        return out

    def _codex_reasoning_events_seen(self, event_counts: Dict[str, int], event_types: List[str]) -> int:
        total = 0
        try:
            for et in event_types or []:
                total += int((event_counts or {}).get(et, 0) or 0)
        except Exception:
            return int(total or 0)
        return int(total or 0)

    def _codex_thinking_debug_summary(self, meta_parts: List[Dict[str, Any]]) -> Dict[str, Any]:
        summary: Dict[str, Any] = {
            "iterations": 0,
            "reasoning_events_seen": 0,
            "reasoning_event_types": [],
            "reasoning_delta_chars": 0,
            "thinking_text_chars": 0,
        }
        if not isinstance(meta_parts, list):
            return summary
        event_types: set = set()
        for meta in meta_parts:
            if not isinstance(meta, dict):
                continue
            summary["iterations"] = int(summary.get("iterations", 0) or 0) + 1
            summary["reasoning_events_seen"] = int(summary.get("reasoning_events_seen", 0) or 0) + int(
                meta.get("reasoning_events_seen", 0) or 0
            )
            summary["reasoning_delta_chars"] = int(summary.get("reasoning_delta_chars", 0) or 0) + int(
                meta.get("reasoning_delta_chars", 0) or 0
            )
            summary["thinking_text_chars"] = int(summary.get("thinking_text_chars", 0) or 0) + int(
                meta.get("thinking_text_chars", 0) or 0
            )
            ets = meta.get("reasoning_event_types")
            if isinstance(ets, list):
                for et in ets:
                    if isinstance(et, str) and et.strip():
                        event_types.add(et.strip().lower())
        summary["reasoning_event_types"] = sorted(event_types)[:20]
        return summary

    def _codex_no_thinking_line(self, thinking_debug_summary: Dict[str, Any]) -> str:
        line = "[none emitted by provider for this turn]"
        if not isinstance(thinking_debug_summary, dict):
            return line
        try:
            evt_count = int(thinking_debug_summary.get("reasoning_events_seen", 0) or 0)
        except Exception:
            evt_count = 0
        if evt_count > 0:
            line += f" (reasoning events seen: {evt_count})"
        return line

    def _codex_reasoning_text_from_items(self, output_items: List[Dict[str, Any]]) -> str:
        parts: List[str] = []
        for item in output_items or []:
            try:
                if not isinstance(item, dict):
                    continue
                itype = str(item.get("type") or "").strip().lower()
                if itype == "reasoning":
                    parts.extend(self._codex_collect_text_fragments(item.get("summary")))
                    for key in ("reasoning_content", "reasoning", "text"):
                        parts.extend(self._codex_collect_text_fragments(item.get(key)))
                if itype in {"reasoning", "message"}:
                    content = item.get("content")
                    if not isinstance(content, list):
                        continue
                    for seg in content:
                        if not isinstance(seg, dict):
                            continue
                        seg_type = str(seg.get("type") or "").strip().lower()
                        is_thought = bool(seg.get("thought"))
                        if ("reason" in seg_type) or ("think" in seg_type) or is_thought:
                            parts.extend(self._codex_collect_text_fragments(seg))
            except Exception:
                continue
        return self._codex_join_unique_blocks(parts)

    def _codex_output_text_from_items(self, output_items: List[Dict[str, Any]]) -> str:
        parts: List[str] = []
        for item in output_items or []:
            try:
                if not isinstance(item, dict):
                    continue
                if item.get("type") != "message":
                    continue
                role = str(item.get("role") or "").strip().lower()
                if role and role != "assistant":
                    continue
                item_text = item.get("text")
                if isinstance(item_text, str) and item_text:
                    parts.append(item_text)
                content = item.get("content")
                if isinstance(content, str) and content:
                    parts.append(content)
                    continue
                if not isinstance(content, list):
                    continue
                for seg in content:
                    if isinstance(seg, dict):
                        seg_type = str(seg.get("type") or "").strip().lower()
                        if seg_type in ("output_text", "text", ""):
                            t = seg.get("text")
                            if isinstance(t, str) and t:
                                parts.append(t)
            except Exception:
                continue
        return "".join(parts)

    def _codex_function_calls_from_items(self, output_items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        calls: List[Dict[str, Any]] = []
        for item in output_items or []:
            try:
                if not isinstance(item, dict):
                    continue
                item_type = str(item.get("type") or "").strip().lower()
                if item_type not in ("function_call", "tool_call"):
                    continue
                fn_obj = item.get("function")
                name = item.get("name")
                if (not isinstance(name, str) or not name.strip()) and isinstance(fn_obj, dict):
                    name = fn_obj.get("name")
                if not isinstance(name, str) or not name.strip():
                    continue
                call_id = item.get("call_id") or item.get("tool_call_id")
                if (not isinstance(call_id, str) or not call_id.strip()) and isinstance(fn_obj, dict):
                    call_id = fn_obj.get("call_id") or fn_obj.get("tool_call_id")
                call_id_s = str(call_id).strip() if isinstance(call_id, str) and call_id.strip() else ""
                if not call_id_s:
                    # Provider item ids (for example rs_*/fc_*) are not valid tool call
                    # ids for replay; generate a local stable call id instead.
                    fallback_id = item.get("id")
                    if (not isinstance(fallback_id, str) or not fallback_id.strip()) and isinstance(fn_obj, dict):
                        fallback_id = fn_obj.get("id")
                    if isinstance(fallback_id, str) and fallback_id.strip().lower().startswith("call_"):
                        call_id_s = fallback_id.strip()
                if not call_id_s:
                    call_id_s = f"call_{uuid.uuid4().hex}"
                args_raw = item.get("arguments")
                if args_raw in (None, "") and isinstance(fn_obj, dict):
                    args_raw = fn_obj.get("arguments")
                if args_raw in (None, ""):
                    args_raw = item.get("input")
                if args_raw in (None, "") and isinstance(fn_obj, dict):
                    args_raw = fn_obj.get("input")
                if isinstance(args_raw, str):
                    args_text = args_raw
                elif args_raw is None:
                    args_text = ""
                else:
                    try:
                        args_text = json.dumps(args_raw)
                    except Exception:
                        args_text = str(args_raw)
                calls.append({"call_id": call_id_s, "name": name.strip(), "arguments": args_text})
            except Exception:
                continue
        return calls

    def _codex_web_search_calls_from_items(self, output_items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        calls: List[Dict[str, Any]] = []
        for item in output_items or []:
            try:
                if not isinstance(item, dict):
                    continue
                item_type = str(item.get("type") or "").strip().lower()
                if item_type != "web_search_call":
                    continue
                call_id = item.get("id") or item.get("call_id") or f"ws_{uuid.uuid4().hex}"
                action = item.get("action") if isinstance(item.get("action"), dict) else {}
                query = action.get("query") or item.get("query") or item.get("search_query")
                call_obj: Dict[str, Any] = {
                    "id": str(call_id),
                    "type": "web_search_call",
                    "action": {
                        "query": query if isinstance(query, str) else "",
                    },
                }
                sources = action.get("sources")
                if isinstance(sources, list):
                    call_obj["action"]["sources"] = sources
                calls.append(call_obj)
            except Exception:
                continue
        return calls

    def _codex_extract_completed_text(self, data: Dict[str, Any]) -> str:
        try:
            items = self._codex_output_items_from_data(data if isinstance(data, dict) else {})
            if items:
                return self._codex_output_text_from_items(items)
        except Exception:
            return ""
        return ""

    def _codex_extract_usage(self, data: Dict[str, Any]) -> Dict[str, Any]:
        try:
            if not isinstance(data, dict):
                return {}
            usage = data.get("usage")
            if isinstance(usage, dict):
                return dict(usage)
            response = data.get("response")
            if isinstance(response, dict):
                usage2 = response.get("usage")
                if isinstance(usage2, dict):
                    return dict(usage2)
        except Exception:
            return {}
        return {}

    def _normalize_usage_for_commit(self, usage: Dict[str, Any]) -> Dict[str, Any]:
        if not isinstance(usage, dict):
            usage = {}
        prompt = int(
            usage.get("prompt_tokens")
            or usage.get("input_tokens")
            or usage.get("input")
            or (usage.get("turn", {}) or {}).get("input_tokens", 0)
            or 0
        )
        completion = int(
            usage.get("completion_tokens")
            or usage.get("output_tokens")
            or usage.get("output")
            or (usage.get("turn", {}) or {}).get("output_tokens", 0)
            or 0
        )
        total = int(
            usage.get("total_tokens")
            or usage.get("total")
            or (usage.get("turn", {}) or {}).get("total_tokens", 0)
            or 0
        )
        if total <= 0:
            total = prompt + completion
        out: Dict[str, Any] = {
            "prompt_tokens": max(0, prompt),
            "completion_tokens": max(0, completion),
            "total_tokens": max(0, total),
        }
        try:
            cached_tokens = 0
            itd = usage.get("input_tokens_details")
            if isinstance(itd, dict):
                cached_tokens = int(itd.get("cached_tokens", 0) or 0)
            if cached_tokens <= 0:
                cached_tokens = int(usage.get("cached_input_tokens", 0) or 0)
            if cached_tokens > 0:
                out["input_tokens_details"] = {"cached_tokens": max(0, int(cached_tokens))}
                out["cached_input_tokens"] = max(0, int(cached_tokens))
        except Exception:
            pass
        for key in (
            "cache_read_input_tokens",
            "cache_creation_input_tokens",
            "prompt_cache_hit_tokens",
            "prompt_cache_miss_tokens",
            "thinking_tokens",
        ):
            try:
                if key in usage and usage.get(key) is not None:
                    out[key] = int(usage.get(key) or 0)
            except Exception:
                continue
        try:
            cc = usage.get("cache_creation")
            if isinstance(cc, dict):
                out["cache_creation"] = {
                    "ephemeral_5m_input_tokens": int(cc.get("ephemeral_5m_input_tokens", 0) or 0),
                    "ephemeral_1h_input_tokens": int(cc.get("ephemeral_1h_input_tokens", 0) or 0),
                }
        except Exception:
            pass
        return out

    def _estimate_tokens_from_text(self, text: str) -> int:
        try:
            # Cheap estimate; used only when Codex stream omits usage payload.
            return max(1, int((len(text or "")) / 4))
        except Exception:
            return 1

    def _codex_local_latest_user_content(self, input_items: List[Dict[str, Any]], fallback: str) -> str:
        """Extract the current turn's user content from local Codex input items."""
        try:
            for item in reversed(input_items or []):
                if not isinstance(item, dict):
                    continue
                role = str(item.get("role") or "").strip().lower()
                if role != "user":
                    continue
                content = item.get("content")
                if isinstance(content, str):
                    return content
        except Exception:
            pass
        return str(fallback or "")

    def _codex_local_seed_conversation_items(
        self,
        input_items: List[Dict[str, Any]],
        user_input_fallback: str,
    ) -> List[Dict[str, Any]]:
        """Build the local Codex replay chain for this turn.

        When prior local-native state exists, keep that full tool-call/tool-result chain
        and append only the current user message. Otherwise start from input_items.
        """
        latest_user = self._codex_local_latest_user_content(input_items, user_input_fallback)
        try:
            if isinstance(self._codex_local_input_items, list) and self._codex_local_input_items:
                seeded = self._sanitize_openai_items(copy.deepcopy(self._codex_local_input_items))
                if isinstance(seeded, list):
                    seeded.append({"role": "user", "content": latest_user})
                    return seeded
        except Exception:
            pass
        if isinstance(input_items, list) and input_items:
            return copy.deepcopy(input_items)
        return [{"role": "user", "content": latest_user}]

    def _codex_local_tools_enabled(self) -> bool:
        try:
            if not HAS_LOCAL_TOOLS:
                return False
            if self.requested_tools is False:
                return False
            return True
        except Exception:
            return False

    def _codex_local_effective_level(self) -> int:
        try:
            lvl = self._effective_control_level()
        except Exception:
            lvl = None
        lvl2 = self._coerce_level(lvl)
        # Local Codex path has no server level event; default to L3 when unset.
        return lvl2 if lvl2 in (1, 2, 3) else 3

    def _codex_local_tool_schemas(self, level: int, tools_enabled: bool) -> List[Dict[str, Any]]:
        if not tools_enabled:
            return []

        schemas: Dict[str, Dict[str, Any]] = {
            "context_handoff": {
                "type": "function",
                "name": "context_handoff",
                "description": "Create a compact keep-note and specify which files should be reloaded/kept as context so the session can continue effectively (e.g., after context overflow).",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "reason": {
                            "type": "string",
                            "description": "Why the handoff is happening (e.g., 'context_length_exceeded', 'near_full', 'manual_checkpoint').",
                        },
                        "keep_notes": {
                            "type": "string",
                            "description": "A concise, durable summary of the task state, decisions, constraints, and next steps. This becomes the new working memory.",
                        },
                        "keep_files": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "List of file paths to reload and keep relevant. Workspace scope: relative paths. Host scope: absolute or relative (subject to policy).",
                        },
                    },
                    "required": ["reason", "keep_notes", "keep_files"],
                    "additionalProperties": False,
                },
                "strict": True,
            },
            "read_file": {
                "type": "function",
                "name": "read_file",
                "description": "Read a text file from the workspace or host (depending on scope), with automatic BOM-based encoding detection (UTF-8, UTF-8-BOM, UTF-16, UTF-32). Reading full files, including large files up to ~500 MB, is preferred over using `rg` or searching for snippets of code files: in our codebase tests, full-file reads were ~40% faster and used ~50% fewer tokens than `rg` + snippet-hunting workflows.",
                "parameters": {
                    "type": "object",
                    "properties": {"path": {"type": "string", "description": "Path to file. In workspace scope, must be relative. In host scope, can be absolute or relative."}},
                    "required": ["path"],
                    "additionalProperties": False,
                },
                "strict": True,
            },
            "write_file": {
                "type": "function",
                "name": "write_file",
                "description": "Write UTF-8 text to a file (overwrite).",
                "parameters": {
                    "type": "object",
                    "properties": {"path": {"type": "string"}, "content": {"type": "string"}},
                    "required": ["path", "content"],
                    "additionalProperties": False,
                },
                "strict": True,
            },
            "append_file": {
                "type": "function",
                "name": "append_file",
                "description": "Append UTF-8 text to a file.",
                "parameters": {
                    "type": "object",
                    "properties": {"path": {"type": "string"}, "content": {"type": "string"}},
                    "required": ["path", "content"],
                    "additionalProperties": False,
                },
                "strict": True,
            },
            "list_dir": {
                "type": "function",
                "name": "list_dir",
                "description": "List files/directories under a path.",
                "parameters": {
                    "type": "object",
                    "properties": {"path": {"type": "string"}},
                    "required": ["path"],
                    "additionalProperties": False,
                },
                "strict": True,
            },
            "run_command": {
                "type": "function",
                "name": "run_command",
                "description": "Execute a non-interactive command and return stdout/stderr/exit code.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "cmd": {"type": "string"},
                        "cwd": {"type": "string"},
                        "timeout": {"type": "number"},
                    },
                    "required": ["cmd", "cwd", "timeout"],
                    "additionalProperties": False,
                },
                "strict": True,
            },
            "run_shell": {
                "type": "function",
                "name": "run_shell",
                "description": "Execute a shell command string (supports pipes/redirection). Level 3 only.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "command": {"type": "string"},
                        "shell": {"type": "string"},
                        "cwd": {"type": "string"},
                        "timeout": {"type": "number"},
                    },
                    "required": ["command"],
                    "additionalProperties": False,
                },
            },
            "apply_patch": {
                "type": "function",
                "name": "apply_patch",
                "description": "Apply a multi-file patch in the simplified *** Begin Patch format.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "patch": {"type": "string"},
                        "cwd": {"type": "string"},
                        "lenient": {"type": "boolean"},
                        "dry_run": {"type": "boolean"},
                        "backup": {"type": "boolean"},
                        "safeguard_max_lines": {"type": "integer"},
                        "safeguard_confirm": {"type": "boolean"},
                    },
                    "required": ["patch"],
                    "additionalProperties": False,
                },
            },
            "string_replace": {
                "type": "function",
                "name": "string_replace",
                "description": "Bounded multi-file string replacement fallback tool.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "pattern": {"type": "string"},
                        "replacement": {"type": "string"},
                        "cwd": {"type": "string"},
                        "file_globs": {"type": "array", "items": {"type": "string"}},
                        "exclude_globs": {"type": "array", "items": {"type": "string"}},
                        "is_regex": {"type": "boolean"},
                        "expected_total_matches": {"type": "integer"},
                        "max_replacements_per_file": {"type": "integer"},
                        "max_total_replacements": {"type": "integer"},
                        "dry_run": {"type": "boolean"},
                    },
                    "required": ["pattern", "replacement", "file_globs", "expected_total_matches"],
                    "additionalProperties": False,
                },
            },
            "planning": {
                "type": "function",
                "name": "planning",
                "description": "Persist a short execution plan under plans/ and return the path.",
                "parameters": {
                    "type": "object",
                    "properties": {"plan": {"type": "string"}, "context": {"type": "string"}},
                    "required": ["plan"],
                    "additionalProperties": False,
                },
            },
        }

        if level <= 1:
            order = ["context_handoff", "read_file", "list_dir"]
        elif level == 2:
            order = [
                "context_handoff",
                "read_file",
                "list_dir",
                "write_file",
                "append_file",
                "apply_patch",
                "string_replace",
                "planning",
                "run_command",
            ]
        else:
            order = [
                "context_handoff",
                "read_file",
                "list_dir",
                "write_file",
                "append_file",
                "apply_patch",
                "string_replace",
                "planning",
                "run_command",
                "run_shell",
            ]

        out: List[Dict[str, Any]] = []
        for name in order:
            schema = schemas.get(name)
            if isinstance(schema, dict):
                out.append(copy.deepcopy(schema))
        return out

    def _codex_local_near_full_ratio(self) -> float:
        try:
            parsed, ok = self._parse_context_near_full_pct(self.context_near_full_pct)
            if ok and parsed is not None:
                return float(parsed)
        except Exception:
            pass
        return 0.85

    def _codex_local_near_full_label(self) -> str:
        default_ratio = 0.85
        ratio = self._codex_local_near_full_ratio()
        try:
            parsed, ok = self._parse_context_near_full_pct(self.context_near_full_pct)
            if ok and parsed is not None and abs(float(parsed) - float(default_ratio)) > 1e-9:
                return f"{float(parsed) * 100.0:.0f}% (default {default_ratio * 100.0:.0f}%)"
        except Exception:
            pass
        return f"{ratio * 100.0:.0f}%"

    def _codex_local_estimate_prompt_tokens(
        self,
        *,
        instructions: str,
        conversation_items: List[Dict[str, Any]],
    ) -> int:
        try:
            payload = {
                "instructions": str(instructions or ""),
                "input": self._sanitize_openai_items(copy.deepcopy(conversation_items or [])),
            }
            packed = json.dumps(payload, ensure_ascii=False, separators=(",", ":"), default=str)
            return max(1, self._estimate_tokens_from_text(packed))
        except Exception:
            try:
                return max(1, self._estimate_tokens_from_text(str(conversation_items or [])))
            except Exception:
                return 1

    def _codex_local_near_full_snapshot(
        self,
        *,
        model_name: str,
        instructions: str,
        conversation_items: List[Dict[str, Any]],
    ) -> Optional[Dict[str, Any]]:
        context_window = self._get_model_ctx_window(model_name)
        if not isinstance(context_window, int) or context_window <= 0:
            return None
        used_tokens = self._codex_local_estimate_prompt_tokens(
            instructions=instructions,
            conversation_items=conversation_items,
        )
        threshold_ratio = self._codex_local_near_full_ratio()
        threshold_tokens = max(1, int(float(context_window) * float(threshold_ratio)))
        if int(used_tokens) < int(threshold_tokens):
            return None
        try:
            pct = max(0.0, min(100.0, (float(used_tokens) / float(context_window)) * 100.0))
        except Exception:
            pct = 0.0
        return {
            "used_tokens": int(used_tokens),
            "context_window": int(context_window),
            "threshold_ratio": float(threshold_ratio),
            "threshold_tokens": int(threshold_tokens),
            "pct": float(pct),
            "label": self._codex_local_near_full_label(),
        }

    def _codex_local_is_context_overflow_text(self, msg: Any) -> bool:
        try:
            s = str(msg or "").lower()
        except Exception:
            return False
        if not s:
            return False
        needles = [
            "context length",
            "maximum context",
            "max context",
            "token limit",
            "too many tokens",
            "prompt too long",
            "input is too long",
            "exceeds the maximum",
            "context window",
            "exceeds the context window",
            "your input exceeds the context window",
            "request too large",
        ]
        return any(n in s for n in needles)

    def _codex_local_item_type(self, item: Any) -> str:
        try:
            if isinstance(item, dict):
                return str(item.get("type", "") or "").strip().lower()
        except Exception:
            pass
        return ""

    def _codex_local_item_role(self, item: Any) -> str:
        try:
            if isinstance(item, dict):
                return str(item.get("role", "") or "").strip().lower()
        except Exception:
            pass
        return ""

    def _codex_local_item_call_id(self, item: Any) -> str:
        try:
            if isinstance(item, dict):
                return str(item.get("call_id", "") or "").strip()
        except Exception:
            pass
        return ""

    def _codex_local_item_name(self, item: Any) -> str:
        try:
            if isinstance(item, dict):
                return str(item.get("name", "") or "").strip()
        except Exception:
            pass
        return ""

    def _codex_local_item_arguments(self, item: Any) -> Any:
        try:
            if isinstance(item, dict):
                return item.get("arguments")
        except Exception:
            pass
        return None

    def _codex_local_backoff_one_step(self, items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        out = self._sanitize_openai_items(copy.deepcopy(items or []))
        removed = False
        removed_outputs = 0
        removed_call_ids: set[str] = set()
        while out:
            last = out[-1]
            item_type = self._codex_local_item_type(last)
            item_role = self._codex_local_item_role(last)
            if item_type == "function_call_output" or item_role == "tool":
                call_id = self._codex_local_item_call_id(last)
                if call_id:
                    removed_call_ids.add(call_id)
                out.pop()
                removed = True
                removed_outputs += 1
                continue
            break
        if removed:
            removed_calls = 0
            if removed_call_ids:
                drop_idx: set[int] = set()
                for idx, item in enumerate(out):
                    if self._codex_local_item_type(item) != "function_call":
                        continue
                    call_id = self._codex_local_item_call_id(item)
                    if not (call_id and (call_id in removed_call_ids)):
                        continue
                    removed_calls += 1
                    drop_idx.add(idx)
                    j = idx - 1
                    while j >= 0 and self._codex_local_item_type(out[j]) == "reasoning":
                        drop_idx.add(j)
                        j -= 1
                if drop_idx:
                    out = [it for i, it in enumerate(out) if i not in drop_idx]
            missing_pairs = max(0, int(removed_outputs) - int(removed_calls))
            while missing_pairs > 0 and out and self._codex_local_item_type(out[-1]) == "function_call":
                out.pop()
                while out and self._codex_local_item_type(out[-1]) == "reasoning":
                    out.pop()
                missing_pairs -= 1
            return out
        if out:
            out.pop()
        return out

    def _codex_local_prepare_handoff_input(
        self,
        *,
        conversation_items: List[Dict[str, Any]],
        user_text: str,
        apply_backoff: bool,
    ) -> List[Dict[str, Any]]:
        base = self._sanitize_openai_items(copy.deepcopy(conversation_items or []))
        if apply_backoff:
            base = self._codex_local_backoff_one_step(base)
        base.append({"role": "user", "content": str(user_text or "")})
        return base

    def _codex_local_build_handoff_user_prompt(
        self,
        *,
        reason: str,
        overflow_action: Optional[str] = None,
    ) -> str:
        reason_key = str(reason or "").strip().lower()
        notes_block = (
            "Important: On restart, the system will automatically include these baseline context blocks by default (do NOT include them in keep_files):\n"
            "- AGENTS.md instructions (agent operating rules)\n"
            "- CODEBASE_MAP.md (repo overview), when enabled\n"
            "- any configured custom first-turn note / preamble behavior, when enabled\n\n"
            "In keep_notes, include:\n"
            "- intent target\n"
            "- a summary & any important info\n"
            "- what is done\n"
            "- what is not done\n"
            "- decisions/constraints\n"
            "- exact next steps\n\n"
            "In keep_files, include only task-critical project files required to continue correctly."
        )
        if reason_key == "near_full":
            return (
                f"Context is near full (>={self._codex_local_near_full_label()}) and next turn risks overflow.\n"
                "Call tool context_handoff with reason='near_full'.\n\n"
                + notes_block
            )
        overflow_line = ""
        if isinstance(overflow_action, str) and overflow_action.strip():
            overflow_line = f"Action that overflowed context: {overflow_action.strip()}\n"
        return (
            "Context overflow occurred.\n"
            + overflow_line
            + "Call tool context_handoff with reason='context_length_exceeded'.\n\n"
            + notes_block
        )

    def _codex_local_overflow_action_from_error(self, error_obj: Any) -> str:
        try:
            if isinstance(error_obj, dict):
                code = str(error_obj.get("code", "") or "").strip()
                param = str(error_obj.get("param", "") or "").strip()
                msg = str(error_obj.get("message", "") or "").strip()
                parts = []
                if code:
                    parts.append(f"code={code}")
                if param:
                    parts.append(f"param={param}")
                if msg:
                    parts.append(f"message={msg}")
                if parts:
                    return "; ".join(parts)
            return str(error_obj or "").strip()
        except Exception:
            return ""

    def _codex_local_compact_json_for_handoff(self, raw: Any, max_chars: int = 600) -> str:
        try:
            if isinstance(raw, str):
                packed = raw.strip()
                if not packed:
                    return "{}"
                try:
                    packed = json.dumps(json.loads(packed), ensure_ascii=True, separators=(",", ":"))
                except Exception:
                    pass
            else:
                packed = json.dumps(raw, ensure_ascii=True, separators=(",", ":"), default=str)
            if len(packed) <= max_chars:
                return packed
            if max_chars <= 20:
                return packed[:max_chars]
            keep = max_chars - len("...(truncated)")
            return packed[:keep] + "...(truncated)"
        except Exception:
            try:
                return str(raw)
            except Exception:
                return ""

    def _codex_local_last_tool_call_summary(self, conversation_items: List[Dict[str, Any]]) -> str:
        for item in reversed(conversation_items or []):
            if self._codex_local_item_type(item) != "function_call":
                continue
            name = self._codex_local_item_name(item) or "unknown"
            args_compact = self._codex_local_compact_json_for_handoff(
                self._codex_local_item_arguments(item)
            )
            return f"tool={name}; args={args_compact}"
        return ""

    def _codex_local_overflow_action_with_tool_context(
        self,
        error_obj: Any,
        conversation_items: List[Dict[str, Any]],
    ) -> str:
        base = self._codex_local_overflow_action_from_error(error_obj)
        tool_summary = self._codex_local_last_tool_call_summary(conversation_items)
        if base and tool_summary:
            return f"{base}; {tool_summary}"
        if tool_summary:
            return tool_summary
        return base

    def _codex_local_xml_attr_escape(self, s: Any) -> str:
        try:
            text = str(s)
        except Exception:
            text = ""
        return (
            text.replace("&", "&amp;")
            .replace('"', "&quot;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
        )

    def _codex_local_extract_handoff_state(self, args_obj: Any) -> Tuple[str, List[str]]:
        try:
            if not isinstance(args_obj, dict):
                return "", []
            keep_notes = str(args_obj.get("keep_notes", "") or "").strip()
            keep_files: List[str] = []
            seen = set()
            raw_keep_files = args_obj.get("keep_files")
            if isinstance(raw_keep_files, list):
                for item in raw_keep_files:
                    if not isinstance(item, str):
                        continue
                    path_s = item.strip()
                    if not path_s or path_s in seen:
                        continue
                    seen.add(path_s)
                    keep_files.append(path_s)
            return keep_notes, keep_files
        except Exception:
            return "", []

    def _codex_local_read_retained_files(
        self,
        *,
        keep_files: List[str],
        policy: Any,
    ) -> List[Tuple[str, str]]:
        retained: List[Tuple[str, str]] = []
        for path_s in keep_files or []:
            try:
                rr = local_read_file(path_s, policy)
            except Exception as e:
                rr = {"ok": False, "error": str(e)}
            if isinstance(rr, dict) and rr.get("ok") and isinstance(rr.get("data"), dict):
                retained.append((path_s, str((rr.get("data") or {}).get("content", "") or "")))
            else:
                errtxt = rr.get("error") if isinstance(rr, dict) else "read_file failed"
                retained.append((path_s, f"[read_file failed] {errtxt}"))
        return retained

    def _codex_local_build_resume_prompt_xml(
        self,
        *,
        retained_files: List[Tuple[str, str]],
        keep_notes: str,
    ) -> str:
        blocks: List[str] = []
        for path_s, content in retained_files or []:
            blocks.append(
                f"  <file path=\"{self._codex_local_xml_attr_escape(path_s)}\"><![CDATA[\n{content}\n]]></file>"
            )
        retained_xml = (
            "<retained_files>\n" + "\n".join(blocks) + "\n</retained_files>"
            if blocks
            else "<retained_files></retained_files>"
        )
        keep_xml = f"<keep_notes><![CDATA[\n{(keep_notes or '').strip()}\n]]></keep_notes>"
        resume_xml = (
            "<resume_instructions>\n"
            "Continue from keep_notes exactly. Do not repeat old context unless needed.\n"
            "</resume_instructions>"
        )
        return retained_xml + "\n\n" + keep_xml + "\n\n" + resume_xml

    def _codex_local_build_resume_prompt_from_handoff_args(
        self,
        *,
        args_obj: Any,
        policy: Any,
    ) -> str:
        keep_notes, keep_files = self._codex_local_extract_handoff_state(args_obj)
        retained = self._codex_local_read_retained_files(keep_files=keep_files, policy=policy)
        return self._codex_local_build_resume_prompt_xml(
            retained_files=retained,
            keep_notes=keep_notes,
        )

    def _codex_local_apply_context_handoff(
        self,
        *,
        call_id: Optional[str],
        args_obj: Any,
        result: Dict[str, Any],
        policy: Any,
        handoff_prompt: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        if not isinstance(result, dict) or not result.get("ok"):
            return None
        args_dict = args_obj if isinstance(args_obj, dict) else {}
        keep_notes_text, keep_files = self._codex_local_extract_handoff_state(args_dict)
        resume_prompt = self._codex_local_build_resume_prompt_from_handoff_args(
            args_obj=args_dict,
            policy=policy,
        )
        keep_notes_injected = bool(keep_notes_text and (keep_notes_text in str(resume_prompt or "")))
        tool_result_out = copy.deepcopy(result)
        try:
            tool_result_out["handoff_keep_notes"] = keep_notes_text
            tool_result_out["handoff_keep_notes_injected"] = keep_notes_injected
            if isinstance(handoff_prompt, str) and handoff_prompt.strip():
                tool_result_out["handoff_prompt"] = handoff_prompt
        except Exception:
            pass
        try:
            data_obj = tool_result_out.get("data")
            if not isinstance(data_obj, dict):
                data_obj = {}
                tool_result_out["data"] = data_obj
            data_obj["handoff_keep_notes"] = keep_notes_text
            data_obj["handoff_keep_notes_injected"] = keep_notes_injected
            if isinstance(handoff_prompt, str) and handoff_prompt.strip():
                data_obj["handoff_prompt"] = handoff_prompt
        except Exception:
            pass
        return {
            "call_id": str(call_id or uuid.uuid4().hex),
            "args_obj": args_dict,
            "tool_result": tool_result_out,
            "handoff_prompt": str(handoff_prompt or ""),
            "handoff_keep_notes": keep_notes_text,
            "handoff_keep_files": keep_files,
            "handoff_keep_notes_injected": keep_notes_injected,
            "resume_prompt": resume_prompt,
        }

    def _build_local_tool_policy(
        self,
        requested_policy: Optional[Dict[str, Any]] = None,
    ) -> Tuple[Any, str, Optional[str], List[Path]]:
        reqp = requested_policy if isinstance(requested_policy, dict) else {}
        scope = (
            self.fs_scope
            if self.fs_scope in ("workspace", "host")
            else (reqp.get("scope") if reqp.get("scope") in ("workspace", "host") else "workspace")
        )
        allowed_roots: List[Path] = []
        host_base: Optional[str] = None

        if scope == "host":
            mode = (self.fs_host_mode or "any").lower()
            if mode == "cwd":
                try:
                    host_base = os.getcwd()
                except Exception:
                    host_base = self.host_base
                if host_base:
                    allowed_roots = [Path(host_base).expanduser().resolve()]
            elif mode == "custom":
                host_base = self.host_base or os.getcwd()
                if host_base:
                    allowed_roots = [Path(host_base).expanduser().resolve()]
            else:
                host_base = self.host_base
                allowed_roots = []

        policy = LocalFileToolPolicy(
            scope=scope,
            workspace_base=Path(self.local_workspace_dir).expanduser().resolve(),
            host_base=(Path(host_base).expanduser().resolve() if (scope == "host" and host_base) else None),
            allowed_roots=allowed_roots,
        )
        return policy, scope, host_base, allowed_roots

    def _execute_local_tool_call(
        self,
        *,
        name: str,
        args: Dict[str, Any],
        level: Optional[int] = None,
        requested_policy: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        if not HAS_LOCAL_TOOLS:
            return {"ok": False, "error": "local tools unavailable (henosis_cli_tools not installed)"}

        nm = str(name or "").strip()
        args_obj = args if isinstance(args, dict) else {}
        reqp = requested_policy if isinstance(requested_policy, dict) else {}

        lvl = self._coerce_level(level)
        if lvl is None:
            lvl = self._coerce_level(self._effective_control_level())
        if lvl not in (1, 2, 3):
            lvl = self._codex_local_effective_level()

        try:
            policy, scope, host_base, allowed_roots = self._build_local_tool_policy(reqp)
        except Exception as e:
            return {"ok": False, "error": f"failed to initialize local tool policy: {e}"}

        if nm == "run_shell" and lvl != 3:
            return {"ok": False, "error": "Tool not allowed (run_shell is Level 3 only)", "denied": True}
        if lvl == 1 and nm not in ("context_handoff", "read_file", "list_dir"):
            return {"ok": False, "error": "Tool not allowed at Level 1", "denied": True}

        if lvl == 2 and nm != "context_handoff":
            approved = False
            try:
                approved = self._cli_approval_for(nm, args_obj, policy=policy, level=lvl)
            except Exception:
                approved = False
            if not approved:
                appr_err = str(getattr(self, "_last_approval_error", "") or "").strip()
                self._last_approval_error = None
                if appr_err:
                    return {"ok": False, "error": appr_err, "approval_preview_failed": True}
                return {"ok": False, "error": "User denied execution", "denied": True}

        try:
            self._log_line(
                {
                    "event": "codex_local.tool.exec",
                    "name": nm,
                    "args": args_obj,
                    "requested_policy": reqp,
                    "local_policy": {
                        "scope": scope,
                        "host_base": str(host_base) if host_base else None,
                        "allowed_roots": [str(p) for p in allowed_roots],
                    },
                }
            )
        except Exception:
            pass

        try:
            if nm == "read_file":
                path_arg = args_obj.get("path", "")
                result = local_read_file(path_arg, policy)
                try:
                    if isinstance(path_arg, str) and path_arg in self._tail_next_paths:
                        if isinstance(result, dict) and result.get("ok") and isinstance(result.get("data"), dict):
                            d = result.get("data") or {}
                            content = d.get("content")
                            if isinstance(content, str):
                                lines = content.splitlines()
                                tail_lines = 50
                                tailed = "\n".join(lines[-tail_lines:]) if lines else ""
                                if len(tailed) > 30_000:
                                    tailed = tailed[-30_000:]
                                d["content"] = tailed
                                try:
                                    d["tokens_used"] = int(len(tailed) / 0.3) if tailed else 0
                                except Exception:
                                    pass
                                d["truncated"] = True
                                d["truncation_policy"] = {
                                    "reason": "post-error-retry",
                                    "tail_lines": tail_lines,
                                    "char_cap": 30000,
                                    "original_chars": len(content),
                                }
                                result["data"] = d
                        try:
                            self._tail_next_paths.discard(path_arg)
                        except Exception:
                            pass
                except Exception:
                    pass
            elif nm == "context_handoff":
                reason = str(args_obj.get("reason", "") or "").strip() or "manual_checkpoint"
                keep_notes = str(args_obj.get("keep_notes", "") or "").strip()
                keep_files_raw = args_obj.get("keep_files")
                if not keep_notes:
                    result = {"ok": False, "error": "keep_notes is required"}
                else:
                    keep_files_list: List[str] = []
                    keep_files_seen = set()
                    if isinstance(keep_files_raw, list):
                        for item in keep_files_raw:
                            if not isinstance(item, str):
                                continue
                            path_s = item.strip()
                            if not path_s or (path_s in keep_files_seen):
                                continue
                            keep_files_seen.add(path_s)
                            keep_files_list.append(path_s)
                    result = {
                        "ok": True,
                        "data": {
                            "handoff_id": uuid.uuid4().hex,
                            "reason": reason,
                            "keep_files": keep_files_list,
                            "resume_context_stats": {
                                "keep_notes_chars": len(keep_notes),
                                "keep_files_count": len(keep_files_list),
                            },
                        },
                    }
            elif nm == "write_file":
                result = local_write_file(args_obj.get("path", ""), args_obj.get("content", ""), policy)
            elif nm == "append_file":
                result = local_append_file(args_obj.get("path", ""), args_obj.get("content", ""), policy)
            elif nm == "list_dir":
                result = local_list_dir(args_obj.get("path", ""), policy)
            elif nm == "run_command":
                if lvl in (2, 3):
                    allow_csv = "*"
                else:
                    req_allow = (reqp.get("command_allow_csv") or "").strip()
                    local_allow = os.getenv("HENOSIS_ALLOW_COMMANDS", "")
                    if req_allow and local_allow:
                        req_set = {c.strip().lower() for c in req_allow.split(",") if c.strip()}
                        loc_set = {c.strip().lower() for c in local_allow.split(",") if c.strip()}
                        allow_csv = ",".join(sorted(req_set & loc_set))
                    else:
                        allow_csv = local_allow or req_allow or ""
                    try:
                        allow_set = {c.strip().lower() for c in allow_csv.split(",") if c.strip()}
                        for k in (self.trust_cmds_session or []):
                            allow_set.add(str(k).strip().lower())
                        for k in (self.trust_cmds_always or []):
                            allow_set.add(str(k).strip().lower())
                        allow_csv = ",".join(sorted(allow_set))
                    except Exception:
                        pass
                timeout = args_obj.get("timeout", None)
                result = local_run_command(
                    args_obj.get("cmd", ""),
                    policy,
                    cwd=args_obj.get("cwd", "."),
                    timeout=timeout,
                    allow_commands_csv=allow_csv,
                )
            elif nm == "run_shell":
                if local_run_shell is None:
                    result = {"ok": False, "error": "run_shell unavailable (henosis_cli_tools missing or too old)"}
                else:
                    timeout = args_obj.get("timeout", None)
                    result = local_run_shell(
                        args_obj.get("command", ""),
                        policy,
                        cwd=args_obj.get("cwd", "."),
                        timeout=timeout,
                        shell=args_obj.get("shell"),
                        allow_commands_csv="*",
                    )
            elif nm == "apply_patch":
                result = local_apply_patch(
                    patch=args_obj.get("patch", ""),
                    policy=policy,
                    cwd=args_obj.get("cwd", "."),
                    lenient=bool(args_obj.get("lenient", True)),
                    dry_run=bool(args_obj.get("dry_run", False)),
                    backup=False,
                    safeguard_max_lines=int(args_obj.get("safeguard_max_lines", 3000) or 3000),
                    safeguard_confirm=bool(args_obj.get("safeguard_confirm", False)),
                )
            elif nm == "planning":
                try:
                    plan_text = str(args_obj.get("plan", "") or "").strip()
                    ctx_text = args_obj.get("context")
                    if not plan_text:
                        result = {"ok": False, "error": "plan is required"}
                    else:
                        base = policy.workspace_base if policy.scope != "host" else (policy.host_base or Path(os.getcwd()).resolve())
                        plans_dir = Path(base) / "plans"
                        plans_dir.mkdir(parents=True, exist_ok=True)
                        from datetime import datetime as _dt
                        import re as _re
                        ts = _dt.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
                        first_line = plan_text.splitlines()[0] if plan_text else "plan"
                        slug = _re.sub(r"[^a-zA-Z0-9_-]+", "-", first_line).strip("-") or "plan"
                        slug = slug[:40]
                        fname = f"plan-{ts}-{uuid.uuid4().hex[:6]}-{slug}.md"
                        fpath = plans_dir / fname
                        body_lines = [f"# Plan ({ts} UTC)\n"]
                        if ctx_text:
                            body_lines.append("## Context\n")
                            body_lines.append(str(ctx_text).strip() + "\n\n")
                        body_lines.append("## Steps\n")
                        body_lines.append(plan_text.rstrip() + "\n")
                        content = "\n".join(body_lines)
                        with fpath.open("w", encoding="utf-8", newline="") as f:
                            f.write(content)
                        result = {"ok": True, "data": {"path": str(fpath), "bytes_written": len(content.encode("utf-8"))}}
                except Exception as e:
                    result = {"ok": False, "error": str(e)}
            elif nm == "string_replace":
                result = local_string_replace(
                    pattern=args_obj.get("pattern", ""),
                    replacement=args_obj.get("replacement", ""),
                    policy=policy,
                    cwd=args_obj.get("cwd", "."),
                    file_globs=[str(g) for g in (args_obj.get("file_globs") or [])],
                    exclude_globs=[str(e) for e in (args_obj.get("exclude_globs") or [])],
                    is_regex=bool(args_obj.get("is_regex", False)),
                    expected_total_matches=(
                        int(args_obj.get("expected_total_matches"))
                        if args_obj.get("expected_total_matches") is not None
                        else None
                    ),
                    max_replacements_per_file=int(args_obj.get("max_replacements_per_file", 5) or 5),
                    max_total_replacements=int(args_obj.get("max_total_replacements", 5) or 5),
                    dry_run=bool(args_obj.get("dry_run", False)),
                )
            else:
                result = {"ok": False, "error": f"unknown tool '{nm}'"}
        except Exception as e:
            result = {"ok": False, "error": str(e)}

        try:
            self._log_line(
                {
                    "event": "codex_local.tool.result",
                    "name": nm,
                    "ok": bool(result.get("ok")),
                    "error": result.get("error"),
                    "data_keys": list((result.get("data") or {}).keys()) if isinstance(result, dict) else [],
                }
            )
        except Exception:
            pass
        return result

    async def _codex_local_stream_request(
        self,
        *,
        req_payload: Dict[str, Any],
        http_timeout: Any,
    ) -> Dict[str, Any]:
        iteration_text_chunks: List[str] = []
        iteration_output_items: List[Dict[str, Any]] = []
        iteration_reasoning_parts: List[str] = []
        iteration_reasoning_delta_parts: List[str] = []
        iteration_usage: Dict[str, Any] = {}
        iteration_event_counts: Dict[str, int] = {}
        model_used = str(req_payload.get("model") or self.model or self._default_codex_model())
        last_err: Optional[str] = None

        for attempt in (0, 1):
            token = await self._ensure_codex_access_token(min_valid_seconds=60)
            if not token:
                raise RuntimeError("Codex authentication is missing or expired. Run /codex login.")
            headers = {
                "Accept": "text/event-stream",
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "Authorization": f"Bearer {token}",
            }
            if isinstance(self.codex_account_id, str) and self.codex_account_id.strip():
                headers["chatgpt-account-id"] = self.codex_account_id.strip()

            try:
                async with httpx.AsyncClient(timeout=http_timeout) as client:
                    async with client.stream(
                        "POST",
                        self.codex_responses_url,
                        json=req_payload,
                        headers=headers,
                        follow_redirects=True,
                    ) as resp:
                        if resp.status_code in (401, 403):
                            if attempt == 0:
                                refreshed = await self._refresh_codex_access_token(client=client)
                                if refreshed:
                                    continue
                            self._clear_codex_auth_state_on_disk(clear_shared=False)
                            raise RuntimeError("Codex authentication failed. Run /codex login.")
                        if resp.status_code >= 400:
                            try:
                                body = await resp.aread()
                                detail = body.decode("utf-8", errors="replace")
                            except Exception:
                                detail = resp.text

                            extra_rate_meta: List[str] = []
                            try:
                                retry_after = resp.headers.get("retry-after")
                                if isinstance(retry_after, str) and retry_after.strip():
                                    extra_rate_meta.append(f'"retry_after": "{retry_after.strip()}"')
                                reset_req = resp.headers.get("x-ratelimit-reset-requests")
                                if isinstance(reset_req, str) and reset_req.strip():
                                    extra_rate_meta.append(f'"x_ratelimit_reset_requests": "{reset_req.strip()}"')
                                reset_tok = resp.headers.get("x-ratelimit-reset-tokens")
                                if isinstance(reset_tok, str) and reset_tok.strip():
                                    extra_rate_meta.append(f'"x_ratelimit_reset_tokens": "{reset_tok.strip()}"')
                            except Exception:
                                extra_rate_meta = []

                            clip_len = 1500 if int(resp.status_code) == 429 else 280
                            detail_clipped = self._clip(detail, clip_len)
                            if extra_rate_meta:
                                detail_clipped = f"{detail_clipped} | rate_limit_meta: {{{', '.join(extra_rate_meta)}}}"

                            raise RuntimeError(
                                f"Codex stream failed ({resp.status_code}): {detail_clipped}"
                            )

                        async for event, data_raw in parse_sse_lines(resp):
                            if self._stream_cancelled:
                                break
                            if isinstance(data_raw, str) and data_raw.strip() == "[DONE]":
                                break
                            try:
                                data = json.loads(data_raw)
                            except Exception:
                                data = {}
                            if not isinstance(data, dict):
                                data = {}

                            response_obj = data.get("response")
                            if isinstance(response_obj, dict):
                                m = response_obj.get("model")
                                if isinstance(m, str) and m.strip():
                                    model_used = m.strip()
                            m2 = data.get("model")
                            if isinstance(m2, str) and m2.strip():
                                model_used = m2.strip()

                            err_obj = data.get("error")
                            if event in ("error", "response.failed") or isinstance(err_obj, dict):
                                em = None
                                if isinstance(err_obj, dict):
                                    em = err_obj.get("message") or err_obj.get("detail")
                                if not em and isinstance(data.get("message"), str):
                                    em = data.get("message")
                                raise RuntimeError(str(em or "Codex stream error"))

                            ev = str(event or "").strip().lower()
                            if ev:
                                iteration_event_counts[ev] = int(iteration_event_counts.get(ev, 0) or 0) + 1

                            reasoning_delta = self._codex_reasoning_summary_from_event(event, data)
                            if reasoning_delta:
                                if ev.endswith(".delta"):
                                    iteration_reasoning_delta_parts.append(reasoning_delta)
                                else:
                                    iteration_reasoning_parts.append(reasoning_delta)

                            delta_text = self._codex_extract_stream_text(event, data)
                            if delta_text:
                                iteration_text_chunks.append(delta_text)

                            usage_candidate = self._codex_extract_usage(data)
                            if usage_candidate:
                                iteration_usage = self._normalize_usage_for_commit(usage_candidate)

                            if ev in (
                                "response.output_item.added",
                                "output_item.added",
                                "response.output_item.done",
                                "output_item.done",
                            ):
                                item = data.get("item") or data.get("output_item")
                                if isinstance(item, dict):
                                    if ev.endswith(".done"):
                                        iteration_output_items.append(dict(item))
                                    reasoning_from_item = self._codex_reasoning_text_from_items([item])
                                    if reasoning_from_item:
                                        iteration_reasoning_parts.append(reasoning_from_item)

                            if ev in ("response.completed", "message.completed", "response.done"):
                                final_items = self._codex_output_items_from_data(data)
                                if final_items:
                                    iteration_output_items = final_items
                                    reasoning_from_items = self._codex_reasoning_text_from_items(final_items)
                                    if reasoning_from_items:
                                        iteration_reasoning_parts.append(reasoning_from_items)
                                if not iteration_text_chunks:
                                    final_text = self._codex_extract_completed_text(data)
                                    if final_text:
                                        iteration_text_chunks.append(final_text)
                                usage_candidate = self._codex_extract_usage(data)
                                if usage_candidate:
                                    iteration_usage = self._normalize_usage_for_commit(usage_candidate)
                        break
            except Exception as e:
                last_err = str(e)
                if attempt == 1:
                    raise
                continue

        if last_err and not iteration_text_chunks and not iteration_output_items and not self._stream_cancelled:
            raise RuntimeError(last_err)

        reasoning_delta_text = "".join(iteration_reasoning_delta_parts)
        thinking_parts: List[str] = []
        if isinstance(reasoning_delta_text, str) and reasoning_delta_text.strip():
            thinking_parts.append(reasoning_delta_text)
        thinking_parts.extend(iteration_reasoning_parts)
        thinking_text = self._codex_collapse_reasoning_blocks(thinking_parts)
        reasoning_event_types = self._codex_reasoning_event_types(iteration_event_counts)
        reasoning_events_seen = self._codex_reasoning_events_seen(iteration_event_counts, reasoning_event_types)

        return {
            "model_used": model_used,
            "text_chunks": iteration_text_chunks,
            "output_items": iteration_output_items,
            "thinking_text": thinking_text,
            "usage": iteration_usage,
            "thinking_meta": {
                "reasoning_event_types": reasoning_event_types[:20],
                "reasoning_events_seen": int(reasoning_events_seen),
                "reasoning_delta_chars": int(len(reasoning_delta_text or "")),
                "thinking_text_chars": int(len(thinking_text or "")),
            },
        }

    async def _codex_local_request_context_handoff(
        self,
        *,
        model_name: str,
        payload_base: Dict[str, Any],
        conversation_items: List[Dict[str, Any]],
        handoff_prompt: str,
        http_timeout: Any,
        apply_backoff: bool,
    ) -> Optional[Dict[str, Any]]:
        handoff_input = self._codex_local_prepare_handoff_input(
            conversation_items=conversation_items,
            user_text=handoff_prompt,
            apply_backoff=bool(apply_backoff),
        )
        handoff_payload = dict(payload_base)
        handoff_payload["model"] = model_name
        handoff_payload["input"] = self._sanitize_openai_items(copy.deepcopy(handoff_input))
        handoff_payload["tools"] = [self._codex_local_tool_schemas(level=1, tools_enabled=True)[0]]
        handoff_payload["tool_choice"] = "required"

        stream_out = await self._codex_local_stream_request(
            req_payload=handoff_payload,
            http_timeout=http_timeout,
        )
        output_items = (
            stream_out.get("output_items")
            if isinstance(stream_out.get("output_items"), list)
            else []
        )
        function_calls = self._codex_function_calls_from_items(output_items)
        for fc in function_calls:
            if str((fc or {}).get("name") or "").strip().lower() != "context_handoff":
                continue
            call_id = str((fc or {}).get("call_id") or uuid.uuid4().hex)
            args_raw = (fc or {}).get("arguments")
            args_obj: Dict[str, Any] = {}
            if isinstance(args_raw, dict):
                args_obj = dict(args_raw)
            elif isinstance(args_raw, str) and args_raw.strip():
                try:
                    parsed = json.loads(args_raw)
                    if isinstance(parsed, dict):
                        args_obj = parsed
                except Exception:
                    args_obj = {}
            usage_obj = (
                stream_out.get("usage")
                if isinstance(stream_out.get("usage"), dict)
                else {}
            )
            return {
                "call_id": call_id,
                "args_obj": args_obj,
                "usage": usage_obj,
                "raw_response_meta": stream_out,
            }
        return None

    async def _codex_local_attempt_context_handoff(
        self,
        *,
        model_name: str,
        payload_base: Dict[str, Any],
        conversation_items: List[Dict[str, Any]],
        http_timeout: Any,
        level: int,
        policy: Any,
        reason: str,
        overflow_action: Optional[str],
        apply_backoff: bool,
    ) -> Optional[Dict[str, Any]]:
        try:
            self._codex_local_last_handoff_error = None
        except Exception:
            pass
        if policy is None:
            return None
        handoff_prompt = self._codex_local_build_handoff_user_prompt(
            reason=reason,
            overflow_action=overflow_action,
        )
        try:
            handoff_req = await self._codex_local_request_context_handoff(
                model_name=model_name,
                payload_base=payload_base,
                conversation_items=conversation_items,
                handoff_prompt=handoff_prompt,
                http_timeout=http_timeout,
                apply_backoff=bool(apply_backoff),
            )
        except Exception as e:
            err_text = str(e or "")
            try:
                self._codex_local_last_handoff_error = err_text
            except Exception:
                pass
            self.ui.warn(f"context_handoff request failed: {self._clip(err_text, 220)}")
            return None
        if not handoff_req:
            return None

        call_id = str(handoff_req.get("call_id") or uuid.uuid4().hex)
        args_obj = handoff_req.get("args_obj") if isinstance(handoff_req.get("args_obj"), dict) else {}
        try:
            self._tool_args_by_call_id[call_id] = args_obj
        except Exception:
            pass

        transient_running = False
        if self.ui.verbose:
            self._render_tool_call("context_handoff", args_obj)
        else:
            try:
                transient_running = self._render_tool_running_transient(
                    "context_handoff",
                    args_obj,
                    model_prefix=model_name,
                )
            except Exception:
                transient_running = False

        result = self._execute_local_tool_call(
            name="context_handoff",
            args=args_obj,
            level=level,
            requested_policy={},
        )
        applied = self._codex_local_apply_context_handoff(
            call_id=call_id,
            args_obj=args_obj,
            result=result,
            policy=policy,
            handoff_prompt=handoff_prompt,
        )
        result_to_render = applied.get("tool_result") if isinstance(applied, dict) else result

        if self.ui.verbose:
            self._render_tool_result("context_handoff", result_to_render, call_id=call_id)
        else:
            if transient_running:
                self._clear_tool_running_transient(newline=False)
            try:
                self._render_tool_result_concise_line(
                    "context_handoff",
                    result_to_render,
                    call_id=call_id,
                    args_ctx=args_obj,
                    model_prefix=model_name,
                )
            except Exception:
                self._render_tool_result("context_handoff", result_to_render, call_id=call_id)

        try:
            if self._busy:
                self._show_waiting_indicator_below_busy_prompt()
        except Exception:
            pass

        if not isinstance(applied, dict):
            return None
        out = dict(applied)
        out["usage"] = handoff_req.get("usage") if isinstance(handoff_req.get("usage"), dict) else {}
        out["raw_response_meta"] = handoff_req.get("raw_response_meta")
        return out

    async def _stream_codex_local_once(self, user_input: str) -> str:
        self._ensure_turn_timer_started()
        model_name = self.model or self._default_codex_model()
        msgs = self._build_messages(user_input)
        # Codex endpoint requires top-level "instructions" and non-system items in "input".
        instructions_parts: List[str] = []
        input_items: List[Dict[str, str]] = []
        for m in msgs:
            try:
                role = str(m.get("role") or "").strip().lower()
                content = m.get("content")
            except Exception:
                role = ""
                content = None
            if role == "system":
                if isinstance(content, str) and content.strip():
                    instructions_parts.append(content.strip())
                continue
            if isinstance(content, str):
                input_items.append({"role": role or "user", "content": content})

        instructions = "\n\n".join([x for x in instructions_parts if isinstance(x, str) and x.strip()]).strip()
        if not instructions:
            try:
                instructions = self._codex_system_prompt()
            except Exception:
                instructions = "You are a helpful coding assistant."
        if not input_items:
            input_items = [{"role": "user", "content": user_input}]

        tools_enabled = self._codex_local_tools_enabled()
        level = self._codex_local_effective_level()
        tool_schemas = self._codex_local_tool_schemas(level=level, tools_enabled=tools_enabled)
        web_search_tool = self._codex_local_web_search_tool()
        if not tool_schemas and not web_search_tool:
            instructions = (
                f"{instructions}\n\n"
                "No external tools are available in this turn. Respond with plain text only."
            ).strip()

        payload_base: Dict[str, Any] = {
            "model": model_name,
            "stream": True,
            "store": False,
            "instructions": instructions,
        }
        payload_tools: List[Dict[str, Any]] = []
        if tool_schemas:
            payload_tools.extend(tool_schemas)
        if web_search_tool:
            payload_tools.append(web_search_tool)
        if payload_tools:
            payload_base["tools"] = payload_tools
            payload_base["tool_choice"] = "auto"
        if web_search_tool and self.web_search_include_sources:
            payload_base["include"] = ["web_search_call.action.sources"]
        if self.service_tier == "priority":
            payload_base["service_tier"] = "priority"

        try:
            reasoning_cfg: Dict[str, Any] = {}
            if isinstance(self.reasoning_effort, str) and self.reasoning_effort in ("low", "medium", "high", "xhigh"):
                reasoning_cfg["effort"] = self.reasoning_effort
            if self.thinking_insight_enabled and self._is_openai_reasoning_model(model_name):
                tsm = str(getattr(self, "thinking_insight_summary", "auto") or "").strip().lower()
                reasoning_cfg["summary"] = tsm if tsm in ("auto", "concise", "detailed") else "auto"
            if reasoning_cfg:
                payload_base["reasoning"] = reasoning_cfg
        except Exception:
            pass
        try:
            if isinstance(self.text_verbosity, str) and self.text_verbosity in ("low", "medium", "high"):
                payload_base["text"] = {"verbosity": self.text_verbosity}
        except Exception:
            pass

        assistant_buf: List[str] = []
        # Chain usage includes all model calls in this user turn (tool loops, retries, handoffs).
        usage_payload: Dict[str, Any] = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
        # Last-turn usage should reflect the final assistant-producing request only.
        last_turn_usage_payload: Dict[str, Any] = {}
        cached_input_tokens_total = 0
        codex_thinking_parts: List[str] = []
        codex_thinking_meta_parts: List[Dict[str, Any]] = []
        codex_thinking_rendered_any = False
        codex_thinking_rendered_keys: set[str] = set()

        def _cached_tokens_from_usage_payload(usage_map: Any) -> int:
            try:
                if not isinstance(usage_map, dict):
                    return 0
                cached = 0
                itd = usage_map.get("input_tokens_details")
                if isinstance(itd, dict):
                    cached = int(itd.get("cached_tokens", 0) or 0)
                if cached <= 0:
                    cached = int(usage_map.get("cached_input_tokens", 0) or 0)
                return max(0, int(cached))
            except Exception:
                return 0

        def _render_codex_thinking_live(thinking_text: str) -> bool:
            nonlocal codex_thinking_rendered_any, codex_thinking_rendered_keys
            if not self.thinking_insight_enabled:
                return False
            if not (isinstance(thinking_text, str) and thinking_text.strip()):
                return False
            tdisplay = self._format_thinking_insight_text(thinking_text, max_len=1400)
            if not tdisplay:
                tdisplay = self._clip(thinking_text, 1400)
            dedupe_key = f"Thinking (openai/summary)\n{tdisplay}"
            if dedupe_key in codex_thinking_rendered_keys:
                return True
            codex_thinking_rendered_keys.add(dedupe_key)
            self.ui.print("Thinking (openai/summary):", style=self.ui.theme["dim"], force=True)
            self.ui.print(tdisplay, style=self.ui.theme["dim"], force=True)
            codex_thinking_rendered_any = True
            return True

        header_printed = False
        model_used = model_name
        session_id = f"codex-local-{uuid.uuid4().hex}"
        local_tool_calls = 0
        web_search_calls_all: List[Dict[str, Any]] = []
        conversation_items: List[Dict[str, Any]] = self._codex_local_seed_conversation_items(input_items, user_input)

        try:
            self._current_turn = self._empty_current_turn()
            self._current_turn.update(
                {
                    "active": True,
                    "session_id": session_id,
                    "model": model_used,
                    "level": int(level),
                    "user_message": {
                        "text": user_input,
                        "model": model_used,
                        "origin": "cli",
                    },
                }
            )
        except Exception:
            pass
        try:
            self._last_session_id = session_id
            self._last_server_level = int(level)
            self._session_level_by_id[session_id] = int(level)
            while len(self._session_level_by_id) > 128:
                self._session_level_by_id.pop(next(iter(self._session_level_by_id)))
        except Exception:
            pass
        try:
            await self._ws_broadcast(
                "session.started",
                {
                    "session_id": session_id,
                    "level": int(level),
                    "fs_scope": self.fs_scope,
                },
            )
        except Exception:
            pass

        if self.timeout is None:
            http_timeout = httpx.Timeout(connect=10.0, read=None, write=10.0, pool=10.0)
        else:
            http_timeout = httpx.Timeout(self.timeout)

        handoff_policy = None
        if tools_enabled:
            try:
                handoff_policy, _, _, _ = self._build_local_tool_policy({})
            except Exception:
                handoff_policy = None
        handoff_attempts = 0

        while True:
            if self._stream_cancelled:
                break

            if tools_enabled and handoff_attempts < 1:
                near_full = self._codex_local_near_full_snapshot(
                    model_name=model_name,
                    instructions=instructions,
                    conversation_items=conversation_items,
                )
                if near_full is not None:
                    handoff_attempts += 1
                    self.ui.warn(
                        f"Context is near full (>={near_full.get('label')}). Initiating proactive context_handoff."
                    )
                    proactive_handoff = await self._codex_local_attempt_context_handoff(
                        model_name=model_name,
                        payload_base=payload_base,
                        conversation_items=conversation_items,
                        http_timeout=http_timeout,
                        level=level,
                        policy=handoff_policy,
                        reason="near_full",
                        overflow_action=None,
                        apply_backoff=False,
                    )
                    if not proactive_handoff:
                        proactive_handoff_error = str(
                            getattr(self, "_codex_local_last_handoff_error", "") or ""
                        )
                        if (
                            proactive_handoff_error
                            and self._codex_local_is_context_overflow_text(proactive_handoff_error)
                        ):
                            self.ui.warn(
                                "Proactive context_handoff overflowed; retrying with one-step backoff."
                            )
                            overflow_action = self._codex_local_overflow_action_with_tool_context(
                                {
                                    "code": "context_length_exceeded",
                                    "message": proactive_handoff_error,
                                },
                                conversation_items,
                            )
                            proactive_handoff = await self._codex_local_attempt_context_handoff(
                                model_name=model_name,
                                payload_base=payload_base,
                                conversation_items=conversation_items,
                                http_timeout=http_timeout,
                                level=level,
                                policy=handoff_policy,
                                reason="context_length_exceeded",
                                overflow_action=overflow_action,
                                apply_backoff=True,
                            )
                    if proactive_handoff and str(proactive_handoff.get("resume_prompt") or "").strip():
                        local_tool_calls += 1
                        handoff_usage = (
                            proactive_handoff.get("usage")
                            if isinstance(proactive_handoff.get("usage"), dict)
                            else {}
                        )
                        if handoff_usage:
                            usage_payload["prompt_tokens"] = int(usage_payload.get("prompt_tokens", 0) or 0) + int(
                                handoff_usage.get("prompt_tokens", 0) or 0
                            )
                            usage_payload["completion_tokens"] = int(
                                usage_payload.get("completion_tokens", 0) or 0
                            ) + int(handoff_usage.get("completion_tokens", 0) or 0)
                            usage_payload["total_tokens"] = int(usage_payload.get("total_tokens", 0) or 0) + int(
                                handoff_usage.get("total_tokens", 0) or 0
                            )
                            cached_input_tokens_total += _cached_tokens_from_usage_payload(handoff_usage)
                        conversation_items = [
                            {"role": "user", "content": str(proactive_handoff.get("resume_prompt") or "")}
                        ]
                        continue

            req_payload = dict(payload_base)
            self._codex_local_last_sent_input_items = self._sanitize_openai_items(copy.deepcopy(conversation_items))
            req_payload["input"] = copy.deepcopy(self._codex_local_last_sent_input_items)
            try:
                latest_user_content = self._codex_local_latest_user_content(
                    self._codex_local_last_sent_input_items or [],
                    user_input,
                )
                self._last_built_user_content = latest_user_content
            except Exception:
                self._last_built_user_content = user_input

            try:
                stream_out = await self._codex_local_stream_request(
                    req_payload=req_payload,
                    http_timeout=http_timeout,
                )
            except Exception as e:
                err_text = str(e)
                if tools_enabled and handoff_attempts < 1 and self._codex_local_is_context_overflow_text(err_text):
                    handoff_attempts += 1
                    self.ui.warn("Context length exceeded. Initiating context_handoff recovery.")
                    overflow_action = self._codex_local_overflow_action_with_tool_context(
                        err_text,
                        conversation_items,
                    )
                    overflow_handoff = await self._codex_local_attempt_context_handoff(
                        model_name=model_name,
                        payload_base=payload_base,
                        conversation_items=conversation_items,
                        http_timeout=http_timeout,
                        level=level,
                        policy=handoff_policy,
                        reason="context_length_exceeded",
                        overflow_action=overflow_action,
                        apply_backoff=True,
                    )
                    if overflow_handoff and str(overflow_handoff.get("resume_prompt") or "").strip():
                        local_tool_calls += 1
                        handoff_usage = (
                            overflow_handoff.get("usage")
                            if isinstance(overflow_handoff.get("usage"), dict)
                            else {}
                        )
                        if handoff_usage:
                            usage_payload["prompt_tokens"] = int(usage_payload.get("prompt_tokens", 0) or 0) + int(
                                handoff_usage.get("prompt_tokens", 0) or 0
                            )
                            usage_payload["completion_tokens"] = int(
                                usage_payload.get("completion_tokens", 0) or 0
                            ) + int(handoff_usage.get("completion_tokens", 0) or 0)
                            usage_payload["total_tokens"] = int(usage_payload.get("total_tokens", 0) or 0) + int(
                                handoff_usage.get("total_tokens", 0) or 0
                            )
                            cached_input_tokens_total += _cached_tokens_from_usage_payload(handoff_usage)
                        conversation_items = [
                            {"role": "user", "content": str(overflow_handoff.get("resume_prompt") or "")}
                        ]
                        continue
                raise

            iteration_text_chunks = (
                stream_out.get("text_chunks")
                if isinstance(stream_out.get("text_chunks"), list)
                else []
            )
            iteration_output_items = (
                stream_out.get("output_items")
                if isinstance(stream_out.get("output_items"), list)
                else []
            )
            iteration_web_search_calls = self._codex_web_search_calls_from_items(iteration_output_items)
            if iteration_web_search_calls:
                web_search_calls_all.extend(iteration_web_search_calls)
            iteration_usage = (
                stream_out.get("usage")
                if isinstance(stream_out.get("usage"), dict)
                else {}
            )
            iteration_thinking_text = (
                str(stream_out.get("thinking_text") or "").strip()
                if isinstance(stream_out.get("thinking_text"), str)
                else ""
            )
            iteration_thinking_meta = (
                stream_out.get("thinking_meta")
                if isinstance(stream_out.get("thinking_meta"), dict)
                else {}
            )
            model_used = str(stream_out.get("model_used") or model_used)
            if iteration_thinking_text:
                codex_thinking_parts.append(iteration_thinking_text)
                thinking_prompt_restart = False
                try:
                    thinking_prompt_restart = await self._pause_busy_input_reader_for_output()
                except Exception:
                    thinking_prompt_restart = False
                try:
                    _render_codex_thinking_live(iteration_thinking_text)
                except Exception:
                    pass
                try:
                    await self._resume_busy_input_reader_after_output(thinking_prompt_restart)
                except Exception:
                    pass
            if iteration_thinking_meta:
                codex_thinking_meta_parts.append(dict(iteration_thinking_meta))

            if iteration_usage:
                usage_payload["prompt_tokens"] = int(usage_payload.get("prompt_tokens", 0) or 0) + int(
                    iteration_usage.get("prompt_tokens", 0) or 0
                )
                usage_payload["completion_tokens"] = int(usage_payload.get("completion_tokens", 0) or 0) + int(
                    iteration_usage.get("completion_tokens", 0) or 0
                )
                usage_payload["total_tokens"] = int(usage_payload.get("total_tokens", 0) or 0) + int(
                    iteration_usage.get("total_tokens", 0) or 0
                )
                cached_input_tokens_total += _cached_tokens_from_usage_payload(iteration_usage)

            if self._stream_cancelled:
                break

            function_calls = (
                self._codex_function_calls_from_items(iteration_output_items)
                if (tools_enabled and iteration_output_items)
                else []
            )

            if tools_enabled and function_calls:
                restart_from_handoff = False
                for fc in function_calls:
                    try:
                        local_tool_calls += 1
                    except Exception:
                        pass
                    call_id = str(fc.get("call_id") or uuid.uuid4().hex).strip()
                    name = str(fc.get("name") or "").strip()
                    args_raw = fc.get("arguments")
                    args_obj: Dict[str, Any] = {}
                    if isinstance(args_raw, dict):
                        args_obj = dict(args_raw)
                    elif isinstance(args_raw, str) and args_raw.strip():
                        try:
                            parsed = json.loads(args_raw)
                            if isinstance(parsed, dict):
                                args_obj = parsed
                        except Exception:
                            args_obj = {}

                    if call_id:
                        try:
                            self._tool_args_by_call_id[call_id] = args_obj
                        except Exception:
                            pass

                    # For local Codex replay, keep only minimal function_call state
                    # (call_id, name, arguments). Do not replay provider item ids.
                    try:
                        if isinstance(args_raw, str):
                            args_text_for_input = args_raw
                        elif isinstance(args_raw, dict):
                            args_text_for_input = json.dumps(args_raw)
                        else:
                            args_text_for_input = json.dumps(args_obj)
                    except Exception:
                        args_text_for_input = "{}"

                    transient_running = False
                    prompt_restart_after_call = False
                    try:
                        prompt_restart_after_call = await self._pause_busy_input_reader_for_output()
                    except Exception:
                        prompt_restart_after_call = False
                    if self.ui.verbose:
                        self._render_tool_call(name, args_obj)
                    else:
                        try:
                            transient_running = self._render_tool_running_transient(
                                name,
                                args_obj,
                                model_prefix=model_used,
                                reserve_next_line=bool(prompt_restart_after_call),
                            )
                            if (not transient_running) and prompt_restart_after_call:
                                self._render_tool_running_line(
                                    name,
                                    args_obj,
                                    model_prefix=model_used,
                                )
                        except Exception:
                            transient_running = False
                    try:
                        await self._resume_busy_input_reader_after_output(prompt_restart_after_call)
                    except Exception:
                        pass
                    try:
                        await self._ws_broadcast("tool.call", {"name": name, "args": args_obj, "call_id": call_id})
                        self._current_turn["tool_events"].append(
                            {"type": "tool.call", "data": {"name": name, "args": args_obj, "call_id": call_id}}
                        )
                    except Exception:
                        pass
                    result = self._execute_local_tool_call(
                        name=name,
                        args=args_obj,
                        level=level,
                        requested_policy={},
                    )
                    applied_handoff = None
                    if name.lower() == "context_handoff":
                        applied_handoff = self._codex_local_apply_context_handoff(
                            call_id=call_id,
                            args_obj=args_obj,
                            result=result,
                            policy=handoff_policy,
                        )
                        if isinstance(applied_handoff, dict):
                            handoff_attempts = max(1, int(handoff_attempts))
                            result = applied_handoff.get("tool_result") if isinstance(applied_handoff.get("tool_result"), dict) else result
                    prompt_restart_after_result = False
                    try:
                        prompt_restart_after_result = await self._pause_busy_input_reader_for_output()
                    except Exception:
                        prompt_restart_after_result = False
                    if self.ui.verbose:
                        self._render_tool_result(name, result, call_id=call_id)
                    else:
                        if transient_running:
                            self._clear_tool_running_transient(newline=False)
                        try:
                            self._render_tool_result_concise_line(
                                name,
                                result,
                                call_id=call_id,
                                args_ctx=args_obj,
                                model_prefix=model_used,
                            )
                        except Exception:
                            self._render_tool_result(name, result, call_id=call_id)
                    try:
                        if prompt_restart_after_result and self._busy:
                            self._show_waiting_indicator_below_busy_prompt()
                    except Exception:
                        pass
                    try:
                        await self._resume_busy_input_reader_after_output(prompt_restart_after_result)
                    except Exception:
                        pass
                    try:
                        await self._ws_broadcast("tool.result", {"name": name, "result": result, "call_id": call_id})
                        self._current_turn["tool_events"].append(
                            {"type": "tool.result", "data": {"name": name, "result": result, "call_id": call_id}}
                        )
                    except Exception:
                        pass

                    if isinstance(applied_handoff, dict) and str(applied_handoff.get("resume_prompt") or "").strip():
                        conversation_items = [
                            {"role": "user", "content": str(applied_handoff.get("resume_prompt") or "")}
                        ]
                        restart_from_handoff = True
                        break

                    conversation_items.append(
                        {
                            "type": "function_call",
                            "call_id": call_id,
                            "name": name,
                            "arguments": args_text_for_input,
                        }
                    )
                    try:
                        out_payload = result if isinstance(result, str) else json.dumps(result)
                    except Exception:
                        out_payload = str(result)
                    conversation_items.append(
                        {
                            "type": "function_call_output",
                            "call_id": call_id,
                            "output": out_payload,
                        }
                    )
                if restart_from_handoff:
                    continue
                if await self._inject_queued_user_messages_into_conversation(
                    conversation_items,
                    announcement="Injecting queued user message after the next tool turn.",
                ):
                    continue
                continue

            final_text = self._codex_output_text_from_items(iteration_output_items) if iteration_output_items else ""
            if not final_text:
                final_text = "".join(iteration_text_chunks)
            if iteration_usage:
                last_turn_usage_payload = dict(iteration_usage)
            if final_text:
                prompt_restart_after_text = False
                try:
                    prompt_restart_after_text = await self._pause_busy_input_reader_for_output()
                except Exception:
                    prompt_restart_after_text = False
                if not header_printed:
                    self.ui.print(f"{model_used}: ", style=self.ui.theme["assistant"], end="")
                    header_printed = True
                self.ui.print(final_text, end="")
                assistant_buf.append(final_text)
                self._stream_partial_text = "".join(assistant_buf)
                conversation_items.append({"role": "assistant", "content": final_text})
                try:
                    await self._ws_broadcast("message.delta", {"text": final_text, "model": model_used})
                    self._current_turn["assistant_so_far"] = (
                        (self._current_turn.get("assistant_so_far") or "") + final_text
                    )
                    self._current_turn["model"] = model_used
                except Exception:
                    pass
            break

        assistant_text = "".join(assistant_buf)
        try:
            if self._input_prompt_active:
                await self._pause_busy_input_reader_for_output()
        except Exception:
            pass
        self.ui.ensure_newline(assistant_text)
        thinking_insight_payload_local: Optional[Dict[str, Any]] = None
        thinking_debug_summary = self._codex_thinking_debug_summary(codex_thinking_meta_parts)
        if self.thinking_insight_enabled:
            try:
                thinking_text = self._codex_collapse_reasoning_blocks(codex_thinking_parts)
                if thinking_text:
                    thinking_insight_payload_local = {
                        "provider": "openai",
                        "model": model_used,
                        "mode": str(getattr(self, "thinking_insight_summary", "summary") or "summary"),
                        "text": thinking_text,
                    }
                    if not codex_thinking_rendered_any:
                        thinking_prompt_restart = False
                        try:
                            thinking_prompt_restart = await self._pause_busy_input_reader_for_output()
                        except Exception:
                            thinking_prompt_restart = False
                        _render_codex_thinking_live(thinking_text)
                        try:
                            await self._resume_busy_input_reader_after_output(thinking_prompt_restart)
                        except Exception:
                            pass
                elif not codex_thinking_rendered_any:
                    thinking_prompt_restart = False
                    try:
                        thinking_prompt_restart = await self._pause_busy_input_reader_for_output()
                    except Exception:
                        thinking_prompt_restart = False
                    self.ui.print("Thinking (openai/summary):", style=self.ui.theme["dim"], force=True)
                    self.ui.print(
                        self._codex_no_thinking_line(thinking_debug_summary),
                        style=self.ui.theme["dim"],
                        force=True,
                    )
                    codex_thinking_rendered_any = True
                    try:
                        await self._resume_busy_input_reader_after_output(thinking_prompt_restart)
                    except Exception:
                        pass
            except Exception:
                thinking_insight_payload_local = None

        # Persist local Codex native replay chain so tool calls/results remain in-context next turn.
        try:
            if self._stream_cancelled and assistant_text.strip():
                need_append_partial = True
                try:
                    last_item = conversation_items[-1] if conversation_items else None
                    if (
                        isinstance(last_item, dict)
                        and str(last_item.get("role") or "").strip().lower() == "assistant"
                        and str(last_item.get("content") or "") == assistant_text
                    ):
                        need_append_partial = False
                except Exception:
                    need_append_partial = True
                if need_append_partial:
                    conversation_items.append({"role": "assistant", "content": assistant_text})
            self._codex_local_input_items = self._sanitize_openai_items(copy.deepcopy(conversation_items))
        except Exception:
            pass
        finally:
            self._codex_local_last_sent_input_items = None

        if self._stream_cancelled:
            try:
                self._current_turn = self._empty_current_turn()
            except Exception:
                pass
            return assistant_text

        if int(usage_payload.get("total_tokens", 0) or 0) <= 0:
            sent_user = self._last_built_user_content or user_input
            p_est = self._estimate_tokens_from_text(sent_user)
            c_est = self._estimate_tokens_from_text(assistant_text) if assistant_text else 0
            usage_payload = {
                "prompt_tokens": int(p_est),
                "completion_tokens": int(c_est),
                "total_tokens": int(p_est + c_est),
            }

        if int(last_turn_usage_payload.get("total_tokens", 0) or 0) <= 0:
            if int(usage_payload.get("total_tokens", 0) or 0) > 0:
                last_turn_usage_payload = dict(usage_payload)
            else:
                sent_user = self._last_built_user_content or user_input
                p_est = self._estimate_tokens_from_text(sent_user)
                c_est = self._estimate_tokens_from_text(assistant_text) if assistant_text else 0
                last_turn_usage_payload = {
                    "prompt_tokens": int(p_est),
                    "completion_tokens": int(c_est),
                    "total_tokens": int(p_est + c_est),
                }

        turn_in = int(last_turn_usage_payload.get("prompt_tokens", 0) or 0)
        turn_out = int(last_turn_usage_payload.get("completion_tokens", 0) or 0)
        turn_total = int(last_turn_usage_payload.get("total_tokens", 0) or 0)
        if turn_total <= 0:
            turn_total = int(turn_in + turn_out)

        chain_in = int(usage_payload.get("prompt_tokens", 0) or 0)
        chain_out = int(usage_payload.get("completion_tokens", 0) or 0)
        chain_total = int(usage_payload.get("total_tokens", 0) or 0)
        if chain_total <= 0:
            chain_total = int(chain_in + chain_out)
        try:
            cached_input_tokens_total = max(0, min(int(cached_input_tokens_total or 0), int(chain_in)))
        except Exception:
            cached_input_tokens_total = 0
        usage_payload["input_tokens_details"] = {"cached_tokens": int(cached_input_tokens_total)}
        usage_payload["cached_input_tokens"] = int(cached_input_tokens_total)

        try:
            # Cumulative usage tracks the full chain for accurate session totals.
            self._cum_input_tokens = int(self._cum_input_tokens or 0) + int(chain_in)
            self._cum_output_tokens = int(self._cum_output_tokens or 0) + int(chain_out)
            self._cum_total_tokens = int(self._cum_total_tokens or 0) + int(chain_total)
        except Exception:
            pass

        try:
            cum_in = int(self._cum_input_tokens or 0)
            cum_out = int(self._cum_output_tokens or 0)
            cum_total = int(self._cum_total_tokens or (cum_in + cum_out))
        except Exception:
            cum_in = int(turn_in)
            cum_out = int(turn_out)
            cum_total = int(turn_total)

        try:
            if self.thinking_insight_enabled:
                self._log_line(
                    {
                        "event": "codex_local.thinking",
                        "enabled": True,
                        "has_summary": bool(thinking_insight_payload_local),
                        "reasoning_events_seen": int(thinking_debug_summary.get("reasoning_events_seen", 0) or 0),
                        "reasoning_event_types": thinking_debug_summary.get("reasoning_event_types"),
                        "reasoning_delta_chars": int(thinking_debug_summary.get("reasoning_delta_chars", 0) or 0),
                        "thinking_text_chars": int(thinking_debug_summary.get("thinking_text_chars", 0) or 0),
                    }
                )
        except Exception:
            pass

        try:
            self._log_line(
                {
                    "event": "usage",
                    "model": model_used,
                    "turn": {
                        "in": int(usage_payload.get("prompt_tokens", 0) or 0),
                        "out": int(usage_payload.get("completion_tokens", 0) or 0),
                        "total": int(usage_payload.get("total_tokens", 0) or 0),
                    },
                    "web_search": web_search_calls_all or None,
                    "billing_source": "codex_local",
                }
            )
            self._log_line(
                {
                    "event": "assistant",
                    "content": assistant_text,
                    "model": model_used,
                    "thinking_insight": thinking_insight_payload_local,
                    "thinking_debug": (
                        thinking_debug_summary if self.thinking_insight_enabled else None
                    ),
                    "web_search": web_search_calls_all or None,
                    "billing_source": "codex_local",
                }
            )
        except Exception:
            pass

        try:
            usage_ws = dict(last_turn_usage_payload or usage_payload or {})
            if "input_tokens" not in usage_ws:
                usage_ws["input_tokens"] = int(usage_ws.get("prompt_tokens", 0) or 0)
            if "output_tokens" not in usage_ws:
                usage_ws["output_tokens"] = int(usage_ws.get("completion_tokens", 0) or 0)
            if "total_tokens" not in usage_ws:
                usage_ws["total_tokens"] = int(
                    int(usage_ws.get("input_tokens", 0) or 0) + int(usage_ws.get("output_tokens", 0) or 0)
                )
            context_info = self._build_remote_control_context_info(model_used, usage_ws)

            completed_payload = {
                "model": model_used,
                "text": assistant_text,
                "usage": usage_ws,
                "by_category": usage_ws.get("by_category"),
                "billing": self._build_remote_control_billing_info(model_used),
                "function_logs": copy.deepcopy(self._current_turn.get("tool_events") or []),
                "thinking_insight": (
                    thinking_insight_payload_local
                    if isinstance(thinking_insight_payload_local, dict)
                    else None
                ),
            }
            completed_payload.update(context_info)
            self._remote_last_completed = copy.deepcopy(completed_payload)
            await self._ws_broadcast(
                "message.completed",
                completed_payload,
            )
            if isinstance(thinking_insight_payload_local, dict):
                try:
                    self._current_turn["thinking_insight"] = dict(thinking_insight_payload_local)
                except Exception:
                    pass
                await self._ws_broadcast("thinking.insight", thinking_insight_payload_local)
            if web_search_calls_all:
                await self._ws_broadcast(
                    "web_search.summary",
                    {"model": model_used, "calls": web_search_calls_all},
                )
        except Exception:
            pass
        try:
            self._current_turn = self._empty_current_turn()
        except Exception:
            pass

        if self.auth_user and self.server_usage_commit:
            try:
                async with httpx.AsyncClient(timeout=http_timeout, cookies=self.cookies) as usage_client:
                    await self._commit_usage(
                        usage_client,
                        session_id=session_id,
                        model_used=model_used,
                        usage=usage_payload,
                        meta={"billing_source": "codex_local", "path": "local_codex"},
                    )
            except Exception:
                pass

        # Render post-turn status via the shared configurable status-fields system.
        try:
            effort_seg = ""
            try:
                if self._is_openai_reasoning_model(model_used):
                    lvl = str(self.reasoning_effort or "medium").strip().lower()
                    if lvl not in ("low", "medium", "high", "xhigh"):
                        lvl = "medium"
                    disp = {"low": "Low", "medium": "Medium", "high": "High", "xhigh": "XHigh"}.get(lvl, "Medium")
                    effort_seg = f" {disp}"
            except Exception:
                effort_seg = ""

            try:
                now_pc = time.perf_counter()
                turn_secs = self._turn_elapsed_seconds(now=now_pc, finalize=True)
            except Exception:
                turn_secs = 0.0
                now_pc = time.time()  # type: ignore
            try:
                session_secs = self._session_elapsed_seconds(now=now_pc)
            except Exception:
                session_secs = 0.0

            def _fmt_secs(v: float) -> str:
                try:
                    f = float(v)
                except Exception:
                    f = 0.0
                if f < 60.0:
                    return f"{f:.2f}s"
                return f"{(f / 60.0):.2f}m"

            context_window = self._get_model_ctx_window(model_used)
            context_meter: Optional[Dict[str, Any]] = None
            context_meter_panel: Optional[str] = None
            context_pct: Optional[float] = None
            if isinstance(context_window, int) and context_window > 0:
                try:
                    pct_val = max(0.0, min(100.0, (float(turn_total) / float(context_window)) * 100.0))
                except Exception:
                    pct_val = 0.0
                bar_width = 30
                filled = int(round((pct_val / 100.0) * bar_width))
                empty = max(0, bar_width - filled)
                context_meter = {
                    "tokens": int(turn_total),
                    "pct": float(pct_val),
                    "filled": int(filled),
                    "empty": int(empty),
                }
                context_pct = float(pct_val)
                try:
                    context_meter_panel = self._context_meter_panel_line(
                        int(turn_total),
                        float(pct_val),
                        int(filled),
                        int(empty),
                    )
                except Exception:
                    context_meter_panel = f"Context: {int(turn_total)} {pct_val:.1f}%"

            cum_reason = 0
            try:
                cum_reason = int(self._cum_reasoning_tokens or 0)
            except Exception:
                cum_reason = 0

            web_search_line_local: Optional[str] = None
            try:
                if web_search_calls_all:
                    qs: List[str] = []
                    for call in web_search_calls_all[:3]:
                        action = call.get("action") if isinstance(call, dict) else None
                        if isinstance(action, dict):
                            q = action.get("query") or action.get("search_query")
                            if isinstance(q, str) and q.strip():
                                qs.append(q.strip())
                    if qs:
                        suffix = " ..." if len(web_search_calls_all) > 3 else ""
                        web_search_line_local = "Web search: " + "; ".join(qs) + suffix
                    else:
                        web_search_line_local = f"Web search: {len(web_search_calls_all)} call(s)"
            except Exception:
                web_search_line_local = None

            status_ctx = {
                "session_id": session_id,
                "model_used": model_used,
                "effort_disp": effort_seg,
                "tool_calls": int(local_tool_calls),
                "billing_line": (
                    f"Remote Control terminal: {self._remote_control_terminal_display_name()} | "
                    "Billed via your OpenAI Codex subscription"
                ),
                "turn_tokens_line": f"Turn tokens: in {int(turn_in)} + out {int(turn_out)} = {int(turn_total)}",
                "session_tokens_line": (
                    f"Session tokens: in {int(cum_in)} + out {int(cum_out)} + reason {int(cum_reason)} = {int(cum_total)}"
                    if int(cum_reason) > 0
                    else f"Session tokens: in {int(cum_in)} + out {int(cum_out)} = {int(cum_total)}"
                ),
                "timing_line": f"Time: {_fmt_secs(turn_secs)} (turn) | {_fmt_secs(session_secs)} (session) | Tools: {int(local_tool_calls)} call(s)",
                "web_search_line": web_search_line_local,
                "cli_version_line": None,
                "prompt_cache_lines": [],
                "context_meter": context_meter,
                "context_meter_panel": context_meter_panel,
                "context_pct": context_pct,
                "context_window": context_window,
                "context_window_known": bool(context_window),
                "cum_in": int(cum_in),
                "cum_out": int(cum_out),
                "cum_total": int(cum_total),
            }

            status_fields_original = copy.deepcopy(self.status_fields)
            # Local Codex minimum: always include billing source in post-turn status.
            # If users configured extra fields, keep them after billing.
            if isinstance(self.status_fields, list):
                merged_fields: List[str] = []
                seen = set()
                for fid in (["billing"] + [str(x).strip() for x in self.status_fields if str(x).strip()]):
                    if fid not in seen:
                        merged_fields.append(fid)
                        seen.add(fid)
                self.status_fields = merged_fields
            else:
                self.status_fields = ["billing"]
            try:
                self._render_status_info(status_ctx)
            finally:
                self.status_fields = status_fields_original
        except Exception:
            # Fallback: always show at least the billing source line for local Codex.
            self.ui.print(
                (
                    f"Remote Control terminal: {self._remote_control_terminal_display_name()} | "
                    "Billed via your OpenAI Codex subscription"
                ),
                force=True,
            )
        return assistant_text

    async def _stream_once(self, user_input: str) -> str:
        self._begin_turn_timer()
        if self._should_use_local_codex_for_model(self.model):
            try:
                return await self._stream_codex_local_once(user_input)
            except (KeyboardInterrupt, asyncio.CancelledError):
                raise
            except Exception as e:
                if not self.auth_user:
                    raise
                err_text = str(e)
                lowered = err_text.lower()
                usage_limit_hit = ("usage_limit_reached" in lowered) or ("codex stream failed (429)" in lowered)
                if usage_limit_hit:
                    wait_seconds = None
                    reset_epoch = None

                    def _coerce_wait_seconds(raw: Any) -> Optional[int]:
                        try:
                            if raw is None:
                                return None
                            text = str(raw).strip().strip('"').strip("'")
                            if not text:
                                return None
                            if text.isdigit():
                                return max(0, int(text))
                            if re.fullmatch(r"\d+\.\d+", text):
                                return max(0, int(float(text)))
                            return None
                        except Exception:
                            return None

                    def _coerce_reset_epoch(raw: Any) -> Optional[int]:
                        try:
                            if raw is None:
                                return None
                            text = str(raw).strip().strip('"').strip("'")
                            if not text:
                                return None
                            if re.fullmatch(r"\d+(?:\.\d+)?", text):
                                val = float(text)
                                # Handle millisecond epoch values.
                                if val > 1_000_000_000_000:
                                    val = val / 1000.0
                                return int(val)
                            iso_text = text.replace("Z", "+00:00")
                            dt = datetime.fromisoformat(iso_text)
                            if dt.tzinfo is None:
                                dt = dt.replace(tzinfo=timezone.utc)
                            return int(dt.timestamp())
                        except Exception:
                            return None

                    def _extract_first(patterns: List[str], value_parser) -> Optional[int]:
                        for pat in patterns:
                            try:
                                m = re.search(pat, err_text, flags=re.IGNORECASE)
                            except Exception:
                                m = None
                            if not m:
                                continue
                            raw_val = None
                            try:
                                raw_val = m.group(1)
                            except Exception:
                                raw_val = None
                            parsed = value_parser(raw_val)
                            if isinstance(parsed, int):
                                return parsed
                        return None

                    wait_seconds = _extract_first(
                        [
                            r'"resets_in_seconds"\s*:\s*"?([^",}\s]+)"?',
                            r'"retry_after_seconds"\s*:\s*"?([^",}\s]+)"?',
                            r'"retry_after"\s*:\s*"?([^",}\s]+)"?',
                            r'\bretry[-_ ]after\b\s*[:=]\s*"?([^",}\s]+)"?',
                        ],
                        _coerce_wait_seconds,
                    )
                    reset_epoch = _extract_first(
                        [
                            r'"resets_at"\s*:\s*"?([^",}\n]+)"?',
                            r'"reset_at"\s*:\s*"?([^",}\n]+)"?',
                            r'"x_ratelimit_reset_requests"\s*:\s*"?([^",}\s]+)"?',
                            r'"x-ratelimit-reset-requests"\s*:\s*"?([^",}\s]+)"?',
                            r'\bresets?\s+at\b\s*[:=]?\s*"?([^",}\n]+)"?',
                        ],
                        _coerce_reset_epoch,
                    )

                    if wait_seconds is None and isinstance(reset_epoch, int):
                        try:
                            wait_seconds = max(0, int(reset_epoch - datetime.now(timezone.utc).timestamp()))
                        except Exception:
                            wait_seconds = None

                    def _fmt_wait(total_seconds: int) -> str:
                        total_seconds = max(0, int(total_seconds))
                        hours, rem = divmod(total_seconds, 3600)
                        minutes, seconds = divmod(rem, 60)
                        if hours > 0:
                            return f"{hours}h {minutes}m {seconds}s"
                        if minutes > 0:
                            return f"{minutes}m {seconds}s"
                        return f"{seconds}s"

                    wait_line = "Wait time remaining: unavailable"
                    if isinstance(wait_seconds, int):
                        wait_line = f"Wait time remaining: {_fmt_wait(wait_seconds)}"

                    reset_line = None
                    if isinstance(reset_epoch, int):
                        try:
                            reset_local = datetime.fromtimestamp(reset_epoch, tz=timezone.utc).astimezone()
                            reset_line = f"Resets at (local time): {reset_local.strftime('%Y-%m-%d %I:%M:%S %p %Z')}"
                        except Exception:
                            reset_line = None

                    lines = [
                        "OpenAI Codex usage limit reached for this account.",
                        wait_line,
                        "You can continue now on backend credits with the same conversation context.",
                    ]
                    if reset_line:
                        lines.insert(2, reset_line)
                    try:
                        self.ui.info_box("Codex limit reached", lines)
                    except Exception:
                        self.ui.warn("Codex usage limit reached.")
                        self.ui.warn(wait_line)
                        if reset_line:
                            self.ui.warn(reset_line)

                    menu_text = "Codex is temporarily rate-limited. Choose whether to continue on backend credits now."
                    if reset_line:
                        menu_text = f"{menu_text}\n{reset_line}"
                    if wait_line:
                        menu_text = f"{menu_text}\n{wait_line}"

                    choice = await self._menu_choice(
                        "Continue this conversation?",
                        menu_text,
                        [
                            ("continue", "Continue now using backend credits (preserve context exactly)"),
                            ("wait", "Do not switch now; I will wait for Codex quota reset"),
                        ],
                    )
                    if choice != "continue":
                        self.ui.info("Okay - staying on Codex for now. No fallback was started.")
                        return ""
                    self._activate_codex_backend_rollover()
                    self.ui.info("Switching to backend stream with credits and preserving the current conversation context.")
                else:
                    self.ui.warn(f"Local Codex path failed; falling back to backend stream: {self._clip(err_text, 240)}")

        try:
            if self._is_openai_model(self.model) and bool(getattr(self, "_codex_backend_rollover_pending_seed", False)):
                self._seed_openai_input_items_from_codex_local()
        except Exception:
            pass

        # Build request payload.
        # OpenAI: use manual conversation state replay (stateless/ZDR-safe) by sending
        # `openai_input_items` that include ALL OpenAI-native items (reasoning/tool calls/tool outputs).
        if self._is_openai_model(self.model):
            msgs: List[Dict[str, str]] = []
            # Codex developer prompt (if enabled) + system prompt
            try:
                if self._is_codex_model(self.model) and bool(getattr(self, "codex_prompt_enabled", True)):
                    msgs.append({"role": "system", "content": self._codex_system_prompt()})
            except Exception:
                pass
            if self.system_prompt:
                msgs.append({"role": "system", "content": self.system_prompt})

            # Apply first-turn-only injections to the current user content
            content = user_input
            prefix = self._build_first_turn_injection(user_input)
            if prefix:
                content = f"{prefix}\n\n{user_input}"
            try:
                self._last_built_user_content = content
            except Exception:
                self._last_built_user_content = user_input
            msgs.append({"role": "user", "content": content})

            payload: Dict[str, Any] = {"messages": msgs}

            # Build OpenAI native input items (authoritative for the server OpenAI path).
            try:
                if isinstance(self._openai_input_items, list) and self._openai_input_items:
                    items: List[Dict[str, Any]] = copy.deepcopy(self._openai_input_items)
                else:
                    # Seed with system prompts for the first OpenAI turn.
                    items = []
                    try:
                        if self._is_codex_model(self.model) and bool(getattr(self, "codex_prompt_enabled", True)):
                            items.append({"role": "system", "content": self._codex_system_prompt()})
                    except Exception:
                        pass
                    if self.system_prompt:
                        items.append({"role": "system", "content": self.system_prompt})
                items.append({"role": "user", "content": content})
                payload["openai_input_items"] = self._sanitize_openai_items(items)
                self._openai_last_sent_input_items = copy.deepcopy(items)
            except Exception:
                # If this fails for any reason, fall back to normal message-based history.
                self._openai_last_sent_input_items = None

            # OpenAI Threading: DISABLED. We use full manual input item replay now.
            # if "openai_input_items" not in payload:
            #    try:
            #        if isinstance(self._openai_previous_response_id, str) and self._openai_previous_response_id.strip():
            #            payload["openai_previous_response_id"] = self._openai_previous_response_id.strip()
            #    except Exception:
            #        pass
            try:
                if isinstance(self._openai_response_id_history, list) and self._openai_response_id_history:
                    payload["openai_response_id_history"] = list(self._openai_response_id_history)
            except Exception:
                pass
        elif self._is_xai_model(self.model):
            msgs: List[Dict[str, str]] = []
            if self.system_prompt:
                msgs.append({"role": "system", "content": self.system_prompt})

            # Apply first-turn-only injections to the current user content.
            content = user_input
            prefix = self._build_first_turn_injection(user_input)
            if prefix:
                content = f"{prefix}\n\n{user_input}"
            try:
                self._last_built_user_content = content
            except Exception:
                self._last_built_user_content = user_input
            msgs.append({"role": "user", "content": content})

            payload = {"messages": msgs}

            # Build xAI native input items (authoritative for the server xAI path).
            try:
                if isinstance(self._xai_input_items, list) and self._xai_input_items:
                    items = copy.deepcopy(self._xai_input_items)
                else:
                    items = []
                    if self.system_prompt:
                        items.append({"role": "system", "content": self.system_prompt})
                items.append({"role": "user", "content": content})
                payload["xai_input_items"] = self._sanitize_openai_items(items)
                self._xai_last_sent_input_items = copy.deepcopy(items)
            except Exception:
                self._xai_last_sent_input_items = None

            try:
                if isinstance(self._xai_response_id_history, list) and self._xai_response_id_history:
                    payload["xai_response_id_history"] = list(self._xai_response_id_history)
            except Exception:
                pass
        else:
            payload = {"messages": self._build_messages(user_input)}
        if self.model:
            payload["model"] = self.model
        # OpenAI: include id chain even when not using previous_response_id yet (e.g. first turn)
        try:
            if self._is_openai_model(self.model):
                if (
                    isinstance(getattr(self, "_openai_response_id_history", None), list)
                    and self._openai_response_id_history
                    and "openai_response_id_history" not in payload
                ):
                    payload["openai_response_id_history"] = list(self._openai_response_id_history)
        except Exception:
            pass
        # xAI: include id chain for diagnostics/continuity.
        try:
            if self._is_xai_model(self.model):
                if (
                    isinstance(getattr(self, "_xai_response_id_history", None), list)
                    and self._xai_response_id_history
                    and "xai_response_id_history" not in payload
                ):
                    payload["xai_response_id_history"] = list(self._xai_response_id_history)
        except Exception:
            pass
        # Include terminal identifier so the server can isolate per-terminal workspace if it executes tools
        try:
            if self.terminal_id:
                payload["terminal_id"] = self.terminal_id
        except Exception:
            pass
        # Per-request tools toggle
        if self.requested_tools is True:
            payload["enable_tools"] = True
        elif self.requested_tools is False:
            payload["enable_tools"] = False
        # Per-request filesystem scope and host base
        if self.fs_scope in ("workspace", "host"):
            payload["fs_scope"] = self.fs_scope
        if self.host_base:
            payload["host_base"] = self.host_base
        # Optional passthrough for transparency (server echoes in requested_policy)
        if self.fs_scope == "host":
            mode = (self.fs_host_mode or "any")
            payload["host_roots_mode"] = mode
            if mode in ("cwd", "custom") and self.host_base:
                payload["host_allowed_dirs"] = [self.host_base]
        # Controls and approvals
        # Note: control_level may be loaded from older JSON as a string (e.g., "3").
        # Normalize here to ensure the server receives the intended level.
        try:
            lvl_payload: Optional[int] = None
            if isinstance(self.control_level, int):
                lvl_payload = int(self.control_level)
            elif isinstance(self.control_level, str) and self.control_level.strip().isdigit():
                lvl_payload = int(self.control_level.strip())
            if lvl_payload in (1, 2, 3):
                payload["control_level"] = int(lvl_payload)
        except Exception:
            pass
        # Auto-approve tools at L2: merge explicit auto_approve with trust lists so
        # "trust for this session" / "always trust" choices also suppress repeat server prompts.
        try:
            auto_tools: List[str] = []
            for seq in (self.auto_approve or [], self.trust_tools_session or [], self.trust_tools_always or []):
                for t in seq:
                    if isinstance(t, str) and t.strip():
                        k = t.strip()
                        if k not in auto_tools:
                            auto_tools.append(k)
            if auto_tools:
                payload["auto_approve"] = auto_tools
        except Exception:
            if self.auto_approve:
                payload["auto_approve"] = self.auto_approve

        # Auto-approve run_command base commands at L2 (hybrid approval + trust).
        try:
            cmd_bases: List[str] = []
            for seq in (self.trust_cmds_session or [], self.trust_cmds_always or []):
                for c in seq:
                    if isinstance(c, str) and c.strip():
                        k = c.strip().lower()
                        if k not in cmd_bases:
                            cmd_bases.append(k)
            if cmd_bases:
                payload["auto_approve_command_bases"] = cmd_bases
        except Exception:
            pass
        # Reasoning effort (OpenAI reasoning models only; server will ignore for others).
        # Let the server decide whether xhigh is supported for the selected (or default) model.
        try:
            if isinstance(self.reasoning_effort, str) and self.reasoning_effort in ("low", "medium", "high", "xhigh"):
                payload["reasoning_effort"] = self.reasoning_effort
            else:
                payload["reasoning_effort"] = "medium"
        except Exception:
            payload["reasoning_effort"] = "medium"
        if self.service_tier == "priority":
            payload["service_tier"] = "priority"

        # Anthropic thinking-mode budget (server ignores unless model ends with -thinking)
        try:
            if isinstance(self.thinking_budget_tokens, int) and self.thinking_budget_tokens > 0:
                payload["thinking_budget_tokens"] = int(self.thinking_budget_tokens)
        except Exception:
            pass
        # Optional provider thinking insight (display-safe reasoning text)
        try:
            payload["enable_thinking_insights"] = bool(self.thinking_insight_enabled)
        except Exception:
            payload["enable_thinking_insights"] = False
        # Optional OpenAI reasoning summary verbosity for thinking insight
        try:
            tsm = str(getattr(self, "thinking_insight_summary", "auto") or "").strip().lower()
            if tsm in ("auto", "concise", "detailed"):
                payload["thinking_insight_summary"] = tsm
        except Exception:
            pass

        # Anthropic effort (Opus 4.6/4.5/Sonnet 4.6). Default to high.
        try:
            ae = getattr(self, "anthropic_effort", None)
            ae2 = str(ae or "high").strip().lower()
            if ae2 in ("low", "medium", "high", "max"):
                payload["anthropic_effort"] = ae2
        except Exception:
            payload["anthropic_effort"] = "high"
        # Anthropic prompt cache TTL (server override): send when set to 5m or 1h
        try:
            if isinstance(self.anthropic_cache_ttl, str) and self.anthropic_cache_ttl in ("5m", "1h"):
                payload["anthropic_cache_ttl"] = self.anthropic_cache_ttl
        except Exception:
            pass
        # Optional near-full handoff cutoff override
        try:
            near_pct, near_pct_ok = self._parse_context_near_full_pct(self.context_near_full_pct)
            if near_pct_ok and (near_pct is not None):
                payload["context_near_full_pct"] = float(near_pct)
        except Exception:
            pass

        # Text verbosity and tool preambles preference (UI hints for the server)
        try:
            if isinstance(self.text_verbosity, str) and self.text_verbosity in ("low", "medium", "high"):
                payload["text_verbosity"] = self.text_verbosity
        except Exception:
            pass
        # Preambles are a GPT-5 / GPT-5.4-only UX toggle.
        try:
            if self._supports_preambles(self.model):
                payload["preambles_enabled"] = bool(self.preambles_enabled)
        except Exception:
            pass

        if self.web_search_enabled:
            payload["enable_web_search"] = True
            if self.web_search_allowed_domains:
                payload["web_search_allowed_domains"] = self.web_search_allowed_domains
            if self.web_search_include_sources:
                payload["web_search_include_sources"] = True
            loc_payload = self._web_search_location_payload()
            if loc_payload:
                payload["web_search_user_location"] = loc_payload
        else:
            payload["enable_web_search"] = False

        # Idempotency key for this turn (stable across retries)
        try:
            idempotency_key = uuid.uuid4().hex
            payload["idempotency_key"] = idempotency_key
        except Exception:
            idempotency_key = None
        # Header timeout hint for upstreams that may honor client-provided hints
        try:
            req_timeout_hint = int(self.timeout) if (self.timeout is not None) else 600
            # Ensure a reasonably generous minimum
            if req_timeout_hint < 300:
                req_timeout_hint = 300
        except Exception:
            req_timeout_hint = 600

        assistant_buf: List[str] = []
        # Defer assistant header until we know the actual model used
        header_printed = False

        session_id: Optional[str] = None

        # Initialize current turn tracking for potential mid-stream WS connections
        try:
            self._current_turn = self._empty_current_turn()
            self._current_turn.update(
                {
                    "active": True,
                    "session_id": None,
                    "model": self.model,
                    "level": None,
                    "user_message": {
                        "text": user_input,
                        "model": self.model,
                        "origin": "cli",
                    },
                }
            )
        except Exception:
            pass

        # Build an SSE-friendly timeout config when no explicit timeout provided
        if self.timeout is None:
            http_timeout = httpx.Timeout(connect=10.0, read=None, write=10.0, pool=10.0)
        else:
            http_timeout = httpx.Timeout(self.timeout)

        async with httpx.AsyncClient(timeout=http_timeout, cookies=self.cookies) as client:
            # Create a server thread if requested and authenticated
            await self._ensure_thread(client)

            if DEBUG_REQ:
                self.ui.print(f"[debug] POST {self.stream_url}", style=self.ui.theme["dim"]) 
                self.ui.print(truncate_json(payload, 1500), style=self.ui.theme["dim"]) 
            # Raw log: outgoing request payload
            if self.raw_log_enabled:
                try:
                    self._rawlog_write(f">>> POST {self.stream_url}")
                    self._rawlog_write_json(payload)
                except Exception:
                    pass

        async def do_stream(req_payload: Dict[str, Any]) -> str:
                nonlocal session_id
                nonlocal header_printed
                # Retry tracking flags (updated per attempt)
                nonlocal last_completed, last_error, last_bytes_total
                # While streaming assistant text, suppress the thinking indicator to avoid clobbering output
                streaming_assistant = False
                # Keep one wall-clock timer for the whole turn, including retries and tool loops.
                tool_calls = 0
                # Estimate of model output chars so far (assistant deltas + tool.call payloads).
                # Used only when Ctrl+C cancels the stream before message.completed.
                model_output_chars = 0
                # Capture last N SSE events for diagnostics if stream ends without message.completed
                from collections import deque
                last_events = deque(maxlen=SSE_TAIL_MAX)  # keep short, printable summaries
                thinking_insight_payload: Optional[Dict[str, Any]] = None
                thinking_has_summary = False
                thinking_label = "Thinking (summary)"
                thinking_none_line = "[none emitted by provider for this turn]"
                thinking_rendered_live = False
                thinking_rendered_keys: set[str] = set()
                final_prompt_restart = False
                # Keep non-Codex backend assistant text high-contrast in terminals.
                assistant_stream_style = self.ui.theme["assistant"]
                try:
                    if self._is_openai_model(self.model) and (not self._should_use_local_codex_for_model(self.model)):
                        assistant_stream_style = "white"
                except Exception:
                    assistant_stream_style = self.ui.theme["assistant"]
                self._ensure_turn_timer_started()
                headers = {"Accept": "text/event-stream", "Cache-Control": "no-cache", "Connection": "keep-alive"}
                # Attach idempotency + timeout hint headers
                try:
                    if idempotency_key:
                        headers["X-Idempotency-Key"] = idempotency_key
                except Exception:
                    pass
                try:
                    headers["X-Request-Timeout"] = str(int(req_timeout_hint))
                except Exception:
                    pass
                # If using a Kimi model, include provider-native messages to preserve reasoning_content
                try:
                    if isinstance(self.model, str) and self.model.startswith("kimi-"):
                        req_payload = dict(req_payload)
                        req_payload["raw_provider_messages"] = self._build_kimi_raw_messages(user_input)
                except Exception:
                    pass
                # If using a Gemini model, include provider-native contents to preserve thought signatures
                # and strict tool-call chains across HTTP turns.
                try:
                    if isinstance(self.model, str) and self.model.startswith("gemini-"):
                        req_payload = dict(req_payload)
                        hist = self._normalize_gemini_raw_messages(self._gemini_raw_history)
                        if hist:
                            req_payload["raw_provider_messages"] = hist
                except Exception:
                    pass
                # If using an Anthropic model, include provider-native messages to preserve tool chains.
                try:
                    if isinstance(self.model, str) and self.model.startswith("claude-"):
                        req_payload = dict(req_payload)
                        if isinstance(self._anthropic_raw_history, list) and self._anthropic_raw_history:
                            req_payload["raw_provider_messages"] = copy.deepcopy(self._anthropic_raw_history)
                except Exception:
                    pass
                async with httpx.AsyncClient(timeout=http_timeout, cookies=self.cookies) as client:
                    async with client.stream("POST", self.stream_url, json=req_payload, headers=headers, follow_redirects=True) as resp:
                        if resp.status_code == 429:
                            try:
                                content = await resp.aread()
                                err_json = json.loads(content)
                                msg = err_json.get("error", {}).get("message", "")
                                m = re.search(r"retry in (\d+(?:\.\d+)?)s", msg)
                                if m:
                                    delay = float(m.group(1))
                                else:
                                    delay = 45.0
                                    try:
                                        rd = err_json.get("error", {}).get("details", [{}])[-1].get("retryDelay")
                                        if rd and rd.endswith("s"):
                                            delay = float(rd[:-1])
                                    except Exception:
                                        pass
                            except Exception:
                                delay = 45.0
                            self.ui.warn(f"Rate limit exceeded (429). Retrying in {delay:.1f}s...")
                            await asyncio.sleep(delay)
                            return await do_stream(req_payload)
                        resp.raise_for_status()
                        # Validate content type before attempting SSE parsing
                        try:
                            ctype_chk = resp.headers.get("content-type", "") or ""
                        except Exception:
                            ctype_chk = ""
                        if "text/event-stream" not in ctype_chk.lower():
                            # Try alternate endpoint if available to avoid /v0 duplication or legacy path issues
                            alt = getattr(self, "stream_url_alt", None)
                            if isinstance(alt, str) and alt and alt != self.stream_url:
                                try:
                                    self.ui.warn(
                                        f"Non-SSE Content-Type '{ctype_chk or 'unknown'}' from {self.stream_url}. Retrying alternate endpoint..."
                                    )
                                except Exception:
                                    pass
                                orig = self.stream_url
                                self.stream_url = alt
                                try:
                                    return await do_stream(req_payload)
                                finally:
                                    self.stream_url = orig
                            else:
                                # Proceed anyway; some proxies strip Content-Type. Warn and attempt to parse SSE.
                                try:
                                    self.ui.warn(
                                        f"Expected 'text/event-stream' but got '{ctype_chk or 'unknown'}'. Attempting to parse SSE anyway."
                                    )
                                except Exception:
                                    pass
                        # Connection diagnostics (once)
                        try:
                            if DEBUG_SSE or self.ui.verbose:
                                ctype = resp.headers.get("content-type")
                                te = resp.headers.get("transfer-encoding")
                                clen = resp.headers.get("content-length")
                                xab = resp.headers.get("x-accel-buffering") or resp.headers.get("X-Accel-Buffering")
                                cache = resp.headers.get("cache-control")
                                date = resp.headers.get("date")
                                self.ui.print(
                                    f"[debug] SSE connected: {resp.status_code} ctype={ctype} te={te} clen={clen} x-accel-buffering={xab} cache={cache} date={date}",
                                    style=self.ui.theme["dim"],
                                )
                        except Exception:
                            pass
                        # Capture all x-* headers for deep diagnostics
                        try:
                            sse_headers_diag = {k: v for k, v in resp.headers.items() if isinstance(k, str) and k.lower().startswith("x-")}
                        except Exception:
                            sse_headers_diag = {}

                        # Basic counters for this stream
                        _events_total = 0
                        _deltas_total = 0
                        _bytes_total = 0
                        # Reset per-attempt flags
                        last_completed = False
                        last_error = False
                        last_bytes_total = 0

                        # Raw log: response headers (once)
                        try:
                            if self.raw_log_enabled:
                                hdrs = {k: v for k, v in resp.headers.items()}
                                self._rawlog_write(f"<<< HTTP {resp.status_code}")
                                self._rawlog_write_json(hdrs)
                        except Exception:
                            pass
                        # Combined SSE debugger: prints to console when --debug-sse and always writes to raw log when enabled
                        def _sse_debug(msg: str) -> None:
                            try:
                                if DEBUG_SSE:
                                    self.ui.print(f"[debug] {msg}", style=self.ui.theme["dim"])  # type: ignore
                            except Exception:
                                pass
                            try:
                                if self.raw_log_enabled:
                                    self._rawlog_write(msg)
                            except Exception:
                                pass
                        # Idle "thinking" indicator shown while waiting for the next event (first tokens or next tool call)
                        indicator_task = None
                        indicator_active = False
                        indicator_started = False  # used only to adjust leading newline behavior on first assistant header
                        # Track whether we're currently positioned at the start of a fresh line.
                        # This prevents double-newlines between back-to-back tool events.
                        at_line_start = True

                        # --- Tool call in-place status (issuelist.md #7 / #8) ---
                        # Keep this line strictly single-line and width-bounded so it can be replaced reliably.
                        tool_status_active = False
                        tool_status_call_id = None
                        tool_status_rows = 1
                        tool_status_gap_rows = 0
                        tool_status_ansi_re = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]")

                        def _tool_status_terminal_cols() -> int:
                            try:
                                cols = int(shutil.get_terminal_size(fallback=(120, 20)).columns or 120)
                            except Exception:
                                cols = 120
                            return max(20, cols)

                        def _tool_status_visible_width(s: str) -> int:
                            try:
                                plain = tool_status_ansi_re.sub("", str(s or ""))
                                return len(plain)
                            except Exception:
                                try:
                                    return len(str(s or ""))
                                except Exception:
                                    return 0

                        def _tool_status_clear_line() -> None:
                            """Clear the transient status line, including wrapped rows (best-effort)."""
                            nonlocal at_line_start, tool_status_rows, tool_status_gap_rows
                            rows = int(tool_status_rows or 1)
                            if rows < 1:
                                rows = 1
                            gap_rows = int(tool_status_gap_rows or 0)
                            if gap_rows < 0:
                                gap_rows = 0
                            try:
                                if gap_rows > 0:
                                    sys.stdout.write("\r")
                                    sys.stdout.write(f"\x1b[{gap_rows}A")
                                for i in range(rows):
                                    sys.stdout.write("\r\x1b[2K")
                                    if i < rows - 1:
                                        sys.stdout.write("\x1b[1A")
                                sys.stdout.write("\r")
                                sys.stdout.flush()
                            except Exception:
                                pass
                            at_line_start = True
                            tool_status_rows = 1
                            tool_status_gap_rows = 0

                        def _tool_status_show(call_id: Any, line: str, *, reserve_next_line: bool = False) -> None:
                            """Show the transient tool status line (no newline)."""
                            nonlocal tool_status_active, tool_status_call_id, at_line_start, tool_status_rows, tool_status_gap_rows
                            if not self.show_tool_calls:
                                return
                            if self._should_suspend_transient_tool_status():
                                tool_status_active = False
                                tool_status_call_id = None
                                tool_status_rows = 1
                                tool_status_gap_rows = 0
                                return
                            tool_status_active = True
                            tool_status_call_id = str(call_id) if call_id is not None else None
                            tool_status_gap_rows = 1 if reserve_next_line else 0
                            line_str = self._single_line(line)
                            cols = _tool_status_terminal_cols()
                            max_visible = max(20, cols - 1)
                            if _tool_status_visible_width(line_str) > max_visible:
                                # Keep the line replaceable even if input includes ANSI-heavy or oversized text.
                                try:
                                    plain = tool_status_ansi_re.sub("", line_str)
                                except Exception:
                                    plain = line_str
                                line_str = self._single_line(plain, max_len=max_visible)
                            visible = max(1, _tool_status_visible_width(line_str))
                            tool_status_rows = max(1, (visible + cols - 1) // cols)
                            try:
                                if not at_line_start:
                                    sys.stdout.write("\n")
                                sys.stdout.write("\r\x1b[2K" + str(line_str))
                                if reserve_next_line:
                                    sys.stdout.write("\n")
                                sys.stdout.flush()
                                at_line_start = bool(reserve_next_line)
                            except Exception:
                                # Fallback: degrade to a normal printed line
                                try:
                                    self.ui.print(str(line_str))
                                except Exception:
                                    pass
                                at_line_start = True
                                tool_status_rows = 1
                                tool_status_gap_rows = 0

                        def _tool_status_stop() -> None:
                            """Remove the transient tool status line and clear tracking."""
                            nonlocal tool_status_active, tool_status_call_id, tool_status_gap_rows
                            if self._should_suspend_transient_tool_status():
                                tool_status_active = False
                                tool_status_call_id = None
                                tool_status_gap_rows = 0
                                return
                            if tool_status_active:
                                _tool_status_clear_line()
                            tool_status_active = False
                            tool_status_call_id = None
                            tool_status_gap_rows = 0

                        def _tool_status_thinking_line() -> str:
                            try:
                                word_bank = list(self._thinking_words or ["thinking", "working..."])
                            except Exception:
                                word_bank = ["thinking", "working..."]
                            if not word_bank:
                                word_bank = ["thinking"]
                            try:
                                chosen = random.choice(word_bank)
                            except Exception:
                                chosen = word_bank[0]
                            try:
                                spacing = int(getattr(self, "_thinking_rainbow_spacing", 3) or 3)
                            except Exception:
                                spacing = 3
                            if spacing < 1:
                                spacing = 1
                            joiner = " " * max(0, spacing - 1)
                            colors = [196, 208, 226, 46, 51, 27, 201]
                            out_chars = []
                            for i, ch in enumerate(str(chosen)):
                                c = colors[i % len(colors)]
                                out_chars.append(f"\x1b[38;5;{c}m{ch}\x1b[0m")
                            return " " + joiner.join(out_chars) + " "
                        # Mode: animate or static (default static for stability)
                        try:
                            _animate_indicator = (os.getenv("HENOSIS_THINKING_ANIMATE", "").strip().lower() in ("1", "true", "yes", "on"))
                        except Exception:
                            _animate_indicator = False

                        async def _thinking_indicator_loop(chosen_word: str, spacing: int = 3) -> None:
                            """Animate a transient thinking word on a single line until indicator_active becomes False.
                            Always clears its line on exit so no remnants remain in history.
                            """
                            colors = [196, 208, 226, 46, 51, 27, 201]  # red, orange, yellow, green, cyan, blue, magenta
                            joiner = " " * max(0, spacing - 1)
                            tick = 0
                            try:
                                while indicator_active:
                                    try:
                                        out_chars = []
                                        for i, ch in enumerate(str(chosen_word)):
                                            c = colors[(i + tick) % len(colors)]
                                            out_chars.append(f"\x1b[38;5;{c}m{ch}\x1b[0m")
                                        line = " " + joiner.join(out_chars) + " "
                                        sys.stdout.write("\r\x1b[2K" + line)
                                        sys.stdout.flush()
                                    except Exception:
                                        try:
                                            sys.stdout.write("\r\x1b[2K" + (" " + joiner.join(list(str(chosen_word))) + " "))
                                            sys.stdout.flush()
                                        except Exception:
                                            pass
                                    tick = (tick + 1) % 1024
                                    try:
                                        await asyncio.sleep(0.25)
                                    except asyncio.CancelledError:
                                        break
                                    except Exception:
                                        break
                            finally:
                                try:
                                    sys.stdout.write("\r\x1b[2K")
                                    sys.stdout.flush()
                                except Exception:
                                    pass

                        async def _indicator_start() -> None:
                            nonlocal indicator_task, indicator_active, indicator_started, at_line_start
                            # Choose a random word and spacing each start
                            word_bank = list(self._thinking_words or ["thinking", "working..."])
                            if not word_bank:
                                word_bank = ["thinking"]
                            try:
                                chosen = random.choice(word_bank)
                            except Exception:
                                chosen = word_bank[0]
                            try:
                                spacing = int(getattr(self, "_thinking_rainbow_spacing", 3) or 3)
                            except Exception:
                                spacing = 3
                            if spacing < 1:
                                spacing = 1
                            # If already active, do nothing
                            if indicator_task and not indicator_task.done() and indicator_active:
                                return
                            # Synchronous first-frame render so the word is visible even if the
                            # animation is stopped quickly by the next event.
                            try:
                                colors = [196, 208, 226, 46, 51, 27, 201]
                                joiner = " " * max(0, spacing - 1)
                                out_chars = []
                                for i, ch in enumerate(str(chosen)):
                                    c = colors[i % len(colors)]
                                    out_chars.append(f"\x1b[38;5;{c}m{ch}\x1b[0m")
                                line = " " + joiner.join(out_chars) + " "
                                # Start on a dedicated new line so we never clobber prior output.
                                # If we're already at a fresh line, don't emit an extra newline (prevents
                                # visible blank lines between back-to-back tool events).
                                if not at_line_start:
                                    sys.stdout.write("\n")
                                sys.stdout.write("\r\x1b[2K" + line)
                                sys.stdout.flush()
                                at_line_start = False
                                # File debug
                                try:
                                    self.ui.debug_log(f"indicator.start word='{chosen}' animate={_animate_indicator}")
                                except Exception:
                                    pass
                            except Exception:
                                try:
                                    if not at_line_start:
                                        sys.stdout.write("\n")
                                    sys.stdout.write("\r\x1b[2K" + (" " + joiner.join(list(str(chosen))) + " "))
                                    sys.stdout.flush()
                                    at_line_start = False
                                except Exception:
                                    pass
                            indicator_started = True
                            if _animate_indicator:
                                try:
                                    indicator_active = True
                                    indicator_task = asyncio.create_task(_thinking_indicator_loop(chosen, spacing))
                                except Exception:
                                    indicator_task = None
                                    indicator_active = False

                        async def _indicator_stop(clear: bool = False) -> None:
                            nonlocal indicator_task, indicator_active, indicator_started, at_line_start
                            # Only clear the line if an indicator was actually started.
                            was_started = bool(indicator_started)
                            indicator_active = False
                            try:
                                if indicator_task and not indicator_task.done():
                                    indicator_task.cancel()
                                    try:
                                        await indicator_task
                                    except asyncio.CancelledError:
                                        pass
                                    except Exception:
                                        pass
                            except Exception:
                                pass
                            finally:
                                indicator_task = None
                                # Default to not clearing to avoid erasing streamed content lines
                                if was_started and clear:
                                    try:
                                        sys.stdout.write("\r\x1b[2K")
                                        sys.stdout.flush()
                                        at_line_start = True
                                    except Exception:
                                        pass
                                elif was_started:
                                    # Move to the next line to separate subsequent output
                                    try:
                                        sys.stdout.write("\n")
                                        sys.stdout.flush()
                                        at_line_start = True
                                    except Exception:
                                        pass
                                # Reset started flag after stopping
                                indicator_started = False
                                try:
                                    self.ui.debug_log(f"indicator.stop clear={clear} was_started={was_started}")
                                except Exception:
                                    pass

                        def _thinking_parts_from_payload(payload: Any) -> Tuple[str, str, bool]:
                            label = "Thinking (summary)"
                            none_line = "[none emitted by provider for this turn]"
                            ttxt = None
                            tmode = "summary"
                            tprov = ""
                            if isinstance(payload, dict):
                                ttxt = payload.get("text")
                                tmode = str(payload.get("mode") or "").strip().lower() or "summary"
                                tprov = str(payload.get("provider") or "").strip().lower()
                            if tprov:
                                label = f"Thinking ({tprov}/{tmode})"
                            else:
                                label = f"Thinking ({tmode})"
                            if isinstance(ttxt, str) and ttxt.strip():
                                tdisplay = self._format_thinking_insight_text(ttxt, max_len=1400)
                                if not tdisplay:
                                    tdisplay = self._clip(ttxt, 1400)
                                return label, tdisplay, True
                            return label, none_line, False

                        async def _render_thinking_payload(payload: Any, *, allow_none: bool = True) -> bool:
                            nonlocal thinking_has_summary, thinking_label, thinking_none_line
                            nonlocal thinking_rendered_live, thinking_rendered_keys, at_line_start
                            if not self.thinking_insight_enabled:
                                return False
                            label, body, has_summary = _thinking_parts_from_payload(payload)
                            if (not has_summary) and (not allow_none):
                                return False
                            dedupe_key = f"{label}\n{body}"
                            if dedupe_key in thinking_rendered_keys:
                                thinking_label = label
                                thinking_has_summary = bool(has_summary)
                                if not has_summary:
                                    thinking_none_line = body
                                return bool(has_summary)
                            thinking_rendered_keys.add(dedupe_key)
                            thinking_label = label
                            thinking_has_summary = bool(has_summary)
                            if not has_summary:
                                thinking_none_line = body
                            try:
                                await _indicator_stop(clear=True)
                            except Exception:
                                pass
                            try:
                                _tool_status_stop()
                            except Exception:
                                pass
                            if not at_line_start:
                                try:
                                    self.ui.print()
                                except Exception:
                                    try:
                                        print()
                                    except Exception:
                                        pass
                                at_line_start = True
                            self.ui.print(f"{label}:", style=self.ui.theme["dim"], force=True)
                            self.ui.print(body, style=self.ui.theme["dim"], force=True)
                            at_line_start = True
                            thinking_rendered_live = True
                            return bool(has_summary)

                        # Start indicator immediately (optional); will be stopped on first delta/tool event
                        # Start the animated rainbow "thinking" indicator immediately (no dim/static line)
                        try:
                            if bool(getattr(self, "_thinking_indicator_enabled", False)):
                                await _indicator_start()
                        except Exception:
                            # Ignore indicator errors silently
                            pass

                        async for event, data_raw in parse_sse_lines(resp, debug=_sse_debug):
                            # Graceful cancel: break early when Ctrl+C sets the flag.
                            if self._stream_cancelled:
                                break
                            try:
                                if isinstance(data_raw, str):
                                    _bytes_total += len(data_raw)
                                    last_bytes_total = _bytes_total
                                _events_total += 1
                            except Exception:
                                pass
                            try:
                                data = json.loads(data_raw) if data_raw else {}
                            except json.JSONDecodeError:
                                data = {"_raw": data_raw}
    
                            if event == "session.started":
                                # Keep indicator until first token; do not stop here
                                session_id = data.get("session_id")
                                try:
                                    if session_id is not None:
                                        self._last_session_id = str(session_id)
                                except Exception:
                                    pass
                                lvl = data.get("level")
                                scope = data.get("fs_scope")
                                self.ui.print(f"[session] id={session_id} level={lvl} scope={scope}", style=self.ui.theme["dim"])
                                self._log_line({"event": "session.started", "server_session_id": session_id, "level": lvl, "fs_scope": scope})
                                # Record the server-authoritative level for this stream so approvals work
                                # even when the user left control_level as "server default".
                                try:
                                    lvl_i: Optional[int] = None
                                    if isinstance(lvl, int):
                                        lvl_i = int(lvl)
                                    elif isinstance(lvl, str) and str(lvl).strip().isdigit():
                                        lvl_i = int(str(lvl).strip())
                                    if lvl_i in (1, 2, 3):
                                        self._current_turn["level"] = int(lvl_i)
                                        self._last_server_level = int(lvl_i)
                                        try:
                                            sid = str(session_id).strip() if session_id is not None else ""
                                            if sid:
                                                self._session_level_by_id[sid] = int(lvl_i)
                                                # Keep this bounded; insertion order is stable in modern Python.
                                                while len(self._session_level_by_id) > 128:
                                                    self._session_level_by_id.pop(next(iter(self._session_level_by_id)))
                                        except Exception:
                                            pass
                                except Exception:
                                    pass
                                try:
                                    await self._ws_broadcast("session.started", data)
                                except Exception:
                                    pass
                                try:
                                    self._current_turn["session_id"] = session_id
                                except Exception:
                                    pass
                                try:
                                    last_events.append({"event": "session.started", "level": lvl, "fs_scope": scope, "session_id": session_id})
                                except Exception:
                                    pass
                                continue
    
                            elif event in ("message.delta", "response.output_text.delta", "output_text.delta"):
                                prompt_restart_after_output = False
                                try:
                                    if self._input_prompt_active:
                                        prompt_restart_after_output = await self._pause_busy_input_reader_for_output()
                                except Exception:
                                    prompt_restart_after_output = False
                                # Stop any transient indicator before printing content and clear the line
                                had_indicator = False
                                try:
                                    had_indicator = bool(indicator_started)
                                except Exception:
                                    had_indicator = False
                                had_tool_status = False
                                try:
                                    had_tool_status = bool(tool_status_active)
                                except Exception:
                                    had_tool_status = False
                                try:
                                    await _indicator_stop(clear=True)
                                except Exception:
                                    pass
                                # If a transient [RUNNING] line is active, remove it before normal output.
                                try:
                                    _tool_status_stop()
                                except Exception:
                                    pass
                                # Only force start-of-line when we actually cleared a transient line.
                                # Otherwise keep cursor state so we never overwrite already printed assistant text.
                                if had_indicator or had_tool_status:
                                    at_line_start = True
                                text = data.get("text")
                                if not (isinstance(text, str) and text):
                                    delta_txt = data.get("delta")
                                    text = delta_txt if isinstance(delta_txt, str) else ""
                                if text:
                                    try:
                                        _deltas_total += 1
                                    except Exception:
                                        pass
                                    # Mark that we're actively streaming assistant tokens
                                    streaming_assistant = True
                                    try:
                                        self.ui.debug_log(f"delta bytes={len(text)} header_printed={header_printed}")
                                    except Exception:
                                        pass
                                    try:
                                        last_events.append({"event": "message.delta", "bytes": len(text)})
                                    except Exception:
                                        pass
                                    # Print the header with the actual model name on first delta
                                    if not header_printed:
                                        try:
                                            model_label = data.get("model") or self.model or "(server default)"
                                        except Exception:
                                            model_label = self.model or "(server default)"
                                        # Track the actual model used for this turn so tool events can prefix it
                                        try:
                                            if isinstance(data.get("model"), str) and data.get("model").strip():
                                                self._current_turn["model"] = data.get("model")
                                        except Exception:
                                            pass
                                        # Print assistant header; indicator line has been cleared, so no leading newline
                                        try:
                                            self.ui.write_assistant_header_raw(str(model_label) + ": ")
                                        except Exception:
                                            try:
                                                print(str(model_label) + ": ", end="", flush=True)
                                            except Exception:
                                                pass
                                        header_printed = True
                                        at_line_start = False
                                        try:
                                            self.ui.debug_log(f"header.printed model='{model_label}' on_first_delta")
                                        except Exception:
                                            pass
                                    assistant_buf.append(text)
                                    try:
                                        model_output_chars += len(str(text))
                                    except Exception:
                                        pass
                                    # Keep partial text accessible for Ctrl+C cancel.
                                    try:
                                        self._stream_partial_text = "".join(assistant_buf)
                                    except Exception:
                                        pass
                                    # Print the token delta raw to avoid any wrapping/markup side-effects
                                    try:
                                        self.ui.write_assistant_raw(text)
                                    except Exception:
                                        try:
                                            print(str(text), end="", flush=True)
                                        except Exception:
                                            pass
                                    at_line_start = False
                                    # Deep debug: show each delta's size/preview
                                    try:
                                        if DEBUG_SSE:
                                            prev = text[:40].replace("\n", "\\n")
                                            self.ui.print(f"[debug] delta bytes={len(text)} preview={prev!r}", style=self.ui.theme["dim"])  # type: ignore
                                    except Exception:
                                        pass
                                    try:
                                        payload_ws = {"text": text}
                                        if data.get("model"):
                                            payload_ws["model"] = data.get("model")
                                        await self._ws_broadcast("message.delta", payload_ws)
                                    except Exception:
                                        pass
                                    try:
                                        self._current_turn["assistant_so_far"] = (self._current_turn.get("assistant_so_far") or "") + text
                                    except Exception:
                                        pass
                                # Once assistant text starts streaming, keep the queued prompt paused so
                                # streamed output owns the terminal until the turn finishes.
                                try:
                                    if prompt_restart_after_output:
                                        self._busy_input_prefill = str(self._busy_input_prefill or "")
                                except Exception:
                                    pass

                            elif event == "tool.call":
                                prompt_restart_after_call = False
                                try:
                                    prompt_restart_after_call = await self._pause_busy_input_reader_for_output()
                                except Exception:
                                    prompt_restart_after_call = False
                                # Ensure any prior indicator state is reset cleanly, then restart
                                # a fresh indicator while waiting for the tool to run.
                                try:
                                    await _indicator_stop(clear=True)
                                except Exception:
                                    pass

                                # If we were mid-line (e.g., streamed assistant text), break cleanly before
                                # showing the transient tool-wait indicator.
                                if not at_line_start:
                                    try:
                                        self.ui.print()
                                    except Exception:
                                        try:
                                            print()
                                        except Exception:
                                            pass
                                    at_line_start = True

                                name = data.get("name")
                                args = data.get("args", {}) or {}
                                call_id = data.get("call_id")
                                try:
                                    self.ui.debug_log(f"tool.call name='{name}' call_id={call_id}")
                                except Exception:
                                    pass

                                # issuelist.md #7:
                                # Show a transient [RUNNING] line and replace it in-place when tool.result arrives.
                                try:
                                    # Clear any previous transient status line (shouldn't happen, but keep stable)
                                    _tool_status_stop()
                                except Exception:
                                    pass
                                try:
                                    tool_name = str(name or "").strip()
                                    label = self._tool_concise_label(
                                        tool_name,
                                        args if isinstance(args, dict) else {},
                                        None,
                                    )
                                    try:
                                        model_prefix = (
                                            self._current_turn.get("model")
                                            or self._last_used_model
                                            or self.model
                                            or "(server default)"
                                        )
                                    except Exception:
                                        model_prefix = self.model or "(server default)"
                                    # Keep transient status strictly single-line and within terminal width.
                                    try:
                                        cols = int(shutil.get_terminal_size(fallback=(120, 20)).columns or 120)
                                    except Exception:
                                        cols = 120
                                    cols = max(40, cols)
                                    model_prefix = self._single_line(model_prefix, max_len=max(8, min(48, cols // 3)))
                                    prefix_plain = f"{model_prefix}: [RUNNING] "
                                    label_budget = max(8, (cols - 1) - len(prefix_plain))
                                    label = self._single_line(label, max_len=label_budget)
                                    ORANGE = "\x1b[38;5;214m"
                                    WHITE = "\x1b[97m"
                                    RESET = "\x1b[0m"
                                    status_line = f"{ORANGE}{model_prefix}{RESET}: {ORANGE}[RUNNING]{RESET} {WHITE}{label}{RESET}"
                                    _tool_status_show(
                                        call_id,
                                        status_line,
                                        reserve_next_line=bool(prompt_restart_after_call),
                                    )
                                except Exception:
                                    # Last-resort fallback: print something rather than crash streaming.
                                    try:
                                        self.ui.print(f"[RUNNING] {name}", style=self.ui.theme.get("tool_call"))
                                    except Exception:
                                        pass
                                # Count tool calls
                                try:
                                    tool_calls += 1
                                except Exception:
                                    pass
                                # tool.call is model output too (even when no message.delta happened yet).
                                try:
                                    # Keep it simple; we only need a non-zero estimate.
                                    model_output_chars += len(str(name or ""))
                                    model_output_chars += len(json.dumps(args, ensure_ascii=False))
                                except Exception:
                                    try:
                                        model_output_chars += len(str(args))
                                    except Exception:
                                        pass
    
                                # Track args for troubleshooting and broadcast to WS clients
                                if call_id:
                                    self._tool_args_by_call_id[str(call_id)] = args
                                try:
                                    await self._ws_broadcast("tool.call", {"name": name, "args": args, "call_id": call_id})
                                except Exception:
                                    pass
                                try:
                                    self._current_turn["tool_events"].append({"type": "tool.call", "data": {"name": name, "args": args, "call_id": call_id}})
                                except Exception:
                                    pass
                                try:
                                    last_events.append({"event": "tool.call", "name": name, "call_id": call_id})
                                except Exception:
                                    pass
                                try:
                                    await self._resume_busy_input_reader_after_output(prompt_restart_after_call)
                                except Exception:
                                    pass

                            elif event == "approval.request":
                                # Don't let the transient [RUNNING] line collide with interactive prompts.
                                try:
                                    _tool_status_stop()
                                except Exception:
                                    pass
                                # First reply wins (web or CLI)
                                await self._handle_approval_request(client, session_id, data)
                                continue
    
                            elif event == "approval.result":
                                appr = data.get("approved")
                                note = data.get("note")
                                self.ui.print(f"Approval result: {'APPROVED' if appr else 'DENIED'} ({note or ''})", style=self.ui.theme["info"])
                                try:
                                    await self._ws_broadcast("approval.result", data)
                                except Exception:
                                    pass
                                try:
                                    last_events.append({"event": "approval.result", "approved": bool(appr)})
                                except Exception:
                                    pass
                                continue
    
                            elif event == "tool.result":
                                name = str(data.get("name"))
                                result = data.get("result", {}) or {}
                                call_id = data.get("call_id")
                                prompt_restart_after_result = False
                                try:
                                    prompt_restart_after_result = await self._pause_busy_input_reader_for_output()
                                except Exception:
                                    prompt_restart_after_result = False
                                # If we previously rendered a transient [RUNNING] line for this tool call,
                                # clear it now so the SUCCESS/FAILURE line prints in the same place.
                                try:
                                    if tool_status_active:
                                        # Best-effort match on call_id (some providers may omit it).
                                        if (tool_status_call_id is None) or (call_id is None) or (str(call_id) == str(tool_status_call_id)):
                                            _tool_status_stop()
                                except Exception:
                                    try:
                                        _tool_status_stop()
                                    except Exception:
                                        pass
                                # Stop any indicator before rendering results
                                try:
                                    await _indicator_stop(clear=True)
                                except Exception:
                                    pass
                                # Ensure tool result starts on a fresh line if assistant text was mid-line.
                                # Don't rely on assistant_buf ending with "\n" because UI.ensure_newline()
                                # prints without mutating the buffer, which can cause repeated blank lines.
                                if not at_line_start:
                                    try:
                                        self.ui.print()
                                    except Exception:
                                        try:
                                            print()
                                        except Exception:
                                            pass
                                at_line_start = True
                                # Concise default: one professional, natural-language line per tool call.
                                if not self.ui.verbose:
                                    try:
                                        # Recover original args (for filenames/cmds) when available
                                        args_ctx = {}
                                        try:
                                            if call_id and str(call_id) in self._tool_args_by_call_id:
                                                args_ctx = self._tool_args_by_call_id.get(str(call_id), {}) or {}
                                        except Exception:
                                            args_ctx = {}
                                        # Build natural-language action label
                                        label = self._tool_concise_label(name, args_ctx, result)
                                        # Prefix with the current model label for clarity in multi-provider runs
                                        try:
                                            model_prefix = (self._current_turn.get("model") or self._last_used_model or self.model or "(server default)")
                                        except Exception:
                                            model_prefix = self.model or "(server default)"
                                        ok = bool(result.get("ok"))
                                        # Explicit segment coloring per request:
                                        # - model name: orange
                                        # - status tag: green (success) or red (failure)
                                        # - main text (label and optional reason): white
                                        if self.ui.rich:
                                            # Model name in orange
                                            self.ui.print(f"{model_prefix}: ", style=self.ui.theme["tool_call"], end="")
                                            # Status tag
                                            if ok:
                                                self.ui.print("[SUCCESS]", style=self.ui.theme["tool_result"], end=" ")
                                            else:
                                                self.ui.print("[FAILURE]", style=self.ui.theme["tool_result_err"], end=" ")
                                            # Main text in white (+ optional reason)
                                            err = result.get("error")
                                            if (not ok) and isinstance(err, str) and err.strip():
                                                reason = self._clip(err, 160)
                                                self.ui.print(f"{label}: {reason}", style="white")
                                            else:
                                                self.ui.print(f"{label}", style="white")
                                        else:
                                            # ANSI fallback when Rich is unavailable
                                            ORANGE = "\x1b[38;5;214m"
                                            GREEN  = "\x1b[32m"
                                            RED    = "\x1b[31m"
                                            WHITE  = "\x1b[97m"
                                            RESET  = "\x1b[0m"
                                            status_seg = f"{GREEN}[SUCCESS]{RESET}" if ok else f"{RED}[FAILURE]{RESET}"
                                            err = result.get("error")
                                            if (not ok) and isinstance(err, str) and err.strip():
                                                reason = self._clip(err, 160)
                                                msg = f"{ORANGE}{model_prefix}{RESET}: {status_seg} {WHITE}{label}: {reason}{RESET}"
                                            else:
                                                msg = f"{ORANGE}{model_prefix}{RESET}: {status_seg} {WHITE}{label}{RESET}"
                                            self.ui.print(msg)
                                        if str(name).strip().lower() == "context_handoff":
                                            keep_notes_text = self._context_handoff_keep_notes_text(result, args_ctx)
                                            keep_notes_injected = self._context_handoff_keep_notes_injected(result)
                                            self._print_context_handoff_checkpoint(
                                                keep_notes_text,
                                                compact=True,
                                            )
                                            self._print_context_handoff_injection_status(keep_notes_injected, compact=True)
                                    except Exception:
                                        # Fall back to legacy renderer on unexpected issues
                                        self._render_tool_result(name, result, call_id=call_id)
                                else:
                                    # Verbose mode retains the richer summary with previews
                                    self._render_tool_result(name, result, call_id=call_id)

                                # Tool result output is line-oriented; after rendering we should be positioned
                                # at the start of a fresh line so the next tool.call indicator doesn't insert
                                # an extra blank line.
                                at_line_start = True
                                try:
                                    await self._ws_broadcast("tool.result", {"name": name, "result": result, "call_id": call_id})
                                except Exception:
                                    pass
                                # For Kimi, append provider-native tool result to raw history so it's threaded correctly
                                try:
                                    if isinstance(self.model, str) and self.model.startswith("kimi-") and call_id:
                                        payload_tool = json.dumps(result) if not isinstance(result, str) else result
                                        self._kimi_raw_history.append({
                                            "role": "tool",
                                            "tool_call_id": call_id,
                                            "name": name,
                                            "content": payload_tool,
                                        })
                                except Exception:
                                    pass
                                try:
                                    self._current_turn["tool_events"].append({"type": "tool.result", "data": {"name": name, "result": result, "call_id": call_id}})
                                except Exception:
                                    pass
                                try:
                                    last_events.append({"event": "tool.result", "name": name, "ok": bool(result.get("ok")), "call_id": call_id})
                                except Exception:
                                    pass
                                try:
                                    if prompt_restart_after_result and self._busy:
                                        self._show_waiting_indicator_below_busy_prompt()
                                except Exception:
                                    pass
                                try:
                                    await self._resume_busy_input_reader_after_output(prompt_restart_after_result)
                                except Exception:
                                    pass
                                # Do not auto-restart the indicator here; wait for the next model event

                            elif event == "tool.dispatch":
                                # Client-executed tool flow
                                if not HAS_LOCAL_TOOLS:
                                    try:
                                        _tool_status_stop()
                                    except Exception:
                                        pass
                                    self.ui.warn("Received tool.dispatch but local tools are unavailable (henosis_cli_tools not installed)")
                                    continue
                                # Keep the indicator running while the local tool executes; it will be
                                # cleared on tool.result or message.delta.
                                # Do not increment tool_calls here: we already counted the logical
                                # tool invocation on the corresponding 'tool.call' event. Counting
                                # dispatch would double-count a single tool call.
    
                                session_id_d = data.get("session_id")
                                call_id = data.get("call_id")
                                name = data.get("name")
                                args = data.get("args", {}) or {}
                                job_token = data.get("job_token")
                                reqp = data.get("requested_policy", {}) or {}

                                # Track in-flight dispatch so Ctrl+C can cancel quickly.
                                try:
                                    self._inflight_dispatch = {
                                        "session_id": session_id_d,
                                        "call_id": call_id,
                                        "job_token": job_token,
                                        "name": name,
                                    }
                                except Exception:
                                    pass
    
                                if DEBUG_SSE:
                                    self.ui.print(f"[debug] dispatch name={name} call_id={call_id}", style=self.ui.theme["dim"])
                                    self.ui.print(f"[debug] requested_policy={truncate_json(reqp, 1000)}", style=self.ui.theme["dim"])
                                    self.ui.print(f"[debug] args={truncate_json(args, 1000)}", style=self.ui.theme["dim"])
                                try:
                                    last_events.append({"event": "tool.dispatch", "name": name, "call_id": call_id})
                                except Exception:
                                    pass
    
                                # Level gating and CLI approvals (Level 2)
                                try:
                                    lvl = self._effective_control_level(data if isinstance(data, dict) else None)
                                except Exception:
                                    lvl = None

                                # run_shell is intentionally Level-3-only.
                                # Deny early at L1/L2 (and when level is unknown) so we never execute it.
                                try:
                                    if str(name) == "run_shell" and lvl != 3:
                                        denied_result = {"ok": False, "error": "Tool not allowed (run_shell is Level 3 only)", "denied": True}
                                        # Best-effort callback to server
                                        try:
                                            if session_id_d and call_id and job_token:
                                                payload_cb = {
                                                    "session_id": session_id_d,
                                                    "call_id": call_id,
                                                    "name": name,
                                                    "result": denied_result,
                                                    "job_token": job_token,
                                                }
                                                r = await client.post(self.tools_callback_url, json=payload_cb, timeout=self.timeout)
                                                if r.status_code >= 400:
                                                    try:
                                                        _tool_status_stop()
                                                    except Exception:
                                                        pass
                                                    self.ui.warn(f"tools.callback POST failed (run_shell gate): {r.status_code} {r.text}")
                                        except Exception as e:
                                            try:
                                                _tool_status_stop()
                                            except Exception:
                                                pass
                                            self.ui.warn(f"tools.callback error (run_shell gate): {e}")
                                        continue
                                except Exception:
                                    # If gating logic fails, fail closed.
                                    try:
                                        denied_result = {"ok": False, "error": "Tool not allowed (run_shell gate error)", "denied": True}
                                        if session_id_d and call_id and job_token:
                                            payload_cb = {
                                                "session_id": session_id_d,
                                                "call_id": call_id,
                                                "name": name,
                                                "result": denied_result,
                                                "job_token": job_token,
                                            }
                                            await client.post(self.tools_callback_url, json=payload_cb, timeout=self.timeout)
                                    except Exception:
                                        pass
                                    continue
                                # Build local policy early so approval preview can use
                                # the same scope/roots as real execution.
                                scope = self.fs_scope if self.fs_scope in ("workspace", "host") else (reqp.get("scope") if reqp.get("scope") in ("workspace", "host") else "workspace")
                                allowed_roots: List[Path] = []
                                host_base = None
                                if scope == "host":
                                    mode = (self.fs_host_mode or "any").lower()
                                    if mode == "cwd":
                                        try:
                                            host_base = os.getcwd()
                                        except Exception:
                                            host_base = self.host_base
                                        if host_base:
                                            allowed_roots = [Path(host_base).expanduser().resolve()]
                                    elif mode == "custom":
                                        host_base = self.host_base or os.getcwd()
                                        if host_base:
                                            allowed_roots = [Path(host_base).expanduser().resolve()]
                                    else:
                                        # any
                                        host_base = self.host_base
                                        allowed_roots = []
                                else:
                                    host_base = None
                                    allowed_roots = []

                                policy = LocalFileToolPolicy(
                                    scope=scope,
                                    workspace_base=Path(self.local_workspace_dir).expanduser().resolve(),
                                    host_base=(Path(host_base).expanduser().resolve() if (scope == "host" and host_base) else None),
                                    allowed_roots=allowed_roots,
                                )
                                # Hard block at Level 1 for anything other than read/list
                                if lvl == 1:
                                    disallowed = str(name) not in ("read_file", "list_dir")
                                    if disallowed:
                                        denied_result = {"ok": False, "error": "Tool not allowed at Level 1", "denied": True}
                                        # Best-effort callback to server
                                        try:
                                            if session_id_d and call_id and job_token:
                                                payload_cb = {
                                                    "session_id": session_id_d,
                                                    "call_id": call_id,
                                                    "name": name,
                                                    "result": denied_result,
                                                    "job_token": job_token,
                                                }
                                                r = await client.post(self.tools_callback_url, json=payload_cb, timeout=self.timeout)
                                                if r.status_code >= 400:
                                                    try:
                                                        _tool_status_stop()
                                                    except Exception:
                                                        pass
                                                    self.ui.warn(f"tools.callback POST failed (L1 block): {r.status_code} {r.text}")
                                        except Exception as e:
                                            try:
                                                _tool_status_stop()
                                            except Exception:
                                                pass
                                            self.ui.warn(f"tools.callback error (L1 block): {e}")
                                        # Skip execution
                                        continue
                                # Level 2: require CLI approval unless trusted/auto-approved
                                if lvl == 2:
                                    approved = False
                                    try:
                                        approved = self._cli_approval_for(name, args, policy=policy, level=lvl)
                                    except Exception:
                                        approved = False
                                    if not approved:
                                        appr_err = str(getattr(self, "_last_approval_error", "") or "").strip()
                                        if appr_err:
                                            denied_result = {
                                                "ok": False,
                                                "error": appr_err,
                                                "approval_preview_failed": True,
                                            }
                                        else:
                                            denied_result = {"ok": False, "error": "User denied execution", "denied": True}
                                        self._last_approval_error = None
                                        # Best-effort callback to server
                                        try:
                                            if session_id_d and call_id and job_token:
                                                payload_cb = {
                                                    "session_id": session_id_d,
                                                    "call_id": call_id,
                                                    "name": name,
                                                    "result": denied_result,
                                                    "job_token": job_token,
                                                }
                                                r = await client.post(self.tools_callback_url, json=payload_cb, timeout=self.timeout)
                                                if r.status_code >= 400:
                                                    try:
                                                        _tool_status_stop()
                                                    except Exception:
                                                        pass
                                                    self.ui.warn(f"tools.callback POST failed (L2 deny): {r.status_code} {r.text}")
                                        except Exception as e:
                                            try:
                                                _tool_status_stop()
                                            except Exception:
                                                pass
                                            self.ui.warn(f"tools.callback error (L2 deny): {e}")
                                        # Skip execution when denied
                                        continue
    
                                # Log inputs before execution
                                self._log_line({
                                    "event": "client.tool.exec",
                                    "name": name,
                                    "call_id": call_id,
                                    "args": args,
                                    "requested_policy": reqp,
                                    "local_policy": {
                                        "scope": scope,
                                        "host_base": str(host_base) if host_base else None,
                                        "allowed_roots": [str(p) for p in allowed_roots],
                                    },
                                })
    
                                # Execute
                                try:
                                    if name == "read_file":
                                        path_arg = args.get("path", "")
                                        result = local_read_file(path_arg, policy)
                                        # Apply tailing ONLY if we've marked this path due to a prior provider size-limit error
                                        try:
                                            if isinstance(path_arg, str) and path_arg in self._tail_next_paths:
                                                if isinstance(result, dict) and result.get("ok") and isinstance(result.get("data"), dict):
                                                    d = result.get("data") or {}
                                                    content = d.get("content")
                                                    if isinstance(content, str):
                                                        lines = content.splitlines()
                                                        tail_lines = 50
                                                        tailed = "\n".join(lines[-tail_lines:]) if lines else ""
                                                        if len(tailed) > 30_000:
                                                            tailed = tailed[-30_000:]
                                                        d["content"] = tailed
                                                        # Best-effort token estimate
                                                        try:
                                                            d["tokens_used"] = int(len(tailed) / 0.3) if tailed else 0
                                                        except Exception:
                                                            pass
                                                        d["truncated"] = True
                                                        d["truncation_policy"] = {
                                                            "reason": "post-error-retry",
                                                            "tail_lines": tail_lines,
                                                            "char_cap": 30000,
                                                            "original_chars": len(content),
                                                        }
                                                        result["data"] = d
                                                # Clear the flag so future reads of this path are not truncated unless another error occurs
                                                try:
                                                    self._tail_next_paths.discard(path_arg)
                                                except Exception:
                                                    pass
                                        except Exception:
                                            # Non-fatal; if tailing fails, keep original result
                                            pass
                                    elif name == "write_file":
                                        result = local_write_file(args.get("path", ""), args.get("content", ""), policy)
                                    elif name == "append_file":
                                        result = local_append_file(args.get("path", ""), args.get("content", ""), policy)
                                    elif name == "list_dir":
                                        result = local_list_dir(args.get("path", ""), policy)
                                    elif name == "run_command":
                                        # Command allow policy:
                                        # - L1: blocked earlier
                                        # - L2: approval required; once approved, allow any base command
                                        # - L3: no approval; allow any base command
                                        # Use '*' wildcard (supported by henosis_cli_tools.run_command).
                                        if lvl in (2, 3):
                                            allow_csv = "*"
                                        else:
                                            # Legacy: intersect server + local allowlists
                                            req_allow = (reqp.get("command_allow_csv") or "").strip()
                                            local_allow = os.getenv("HENOSIS_ALLOW_COMMANDS", "")
                                            if req_allow and local_allow:
                                                req_set = {c.strip().lower() for c in req_allow.split(",") if c.strip()}
                                                loc_set = {c.strip().lower() for c in local_allow.split(",") if c.strip()}
                                                allow_csv = ",".join(sorted(req_set & loc_set))
                                            else:
                                                allow_csv = local_allow or req_allow or ""
                                            # Include trusted commands from CLI settings (session + always)
                                            try:
                                                allow_set = {c.strip().lower() for c in allow_csv.split(",") if c.strip()}
                                                for k in (self.trust_cmds_session or []):
                                                    allow_set.add(str(k).strip().lower())
                                                for k in (self.trust_cmds_always or []):
                                                    allow_set.add(str(k).strip().lower())
                                                allow_csv = ",".join(sorted(allow_set))
                                            except Exception:
                                                pass
                                        timeout = args.get("timeout", None)
                                        result = local_run_command(args.get("cmd", ""), policy, cwd=args.get("cwd", "."), timeout=timeout, allow_commands_csv=allow_csv)
                                        # Legacy allowlist retry logic removed for L2/L3 (we allow '*').
                                    elif name == "run_shell":
                                        # L3-only gate is enforced above. Here we just execute.
                                        if local_run_shell is None:
                                            result = {"ok": False, "error": "run_shell unavailable (henosis_cli_tools missing or too old)"}
                                        else:
                                            timeout = args.get("timeout", None)
                                            # L3 intentionally allows shell usage without subcommand allowlisting.
                                            # henosis_cli_tools.run_shell still wants a non-empty allowlist, and only
                                            # checks the *shell executable*; we pass '*' to avoid configuration footguns.
                                            allow_csv = "*"
                                            result = local_run_shell(
                                                args.get("command", ""),
                                                policy,
                                                cwd=args.get("cwd", "."),
                                                timeout=timeout,
                                                shell=args.get("shell"),
                                                allow_commands_csv=allow_csv,
                                            )
                                    elif name == "apply_patch":
                                        result = local_apply_patch(
                                            patch=args.get("patch", ""),
                                            policy=policy,
                                            cwd=args.get("cwd", "."),
                                            lenient=bool(args.get("lenient", True)),
                                            dry_run=bool(args.get("dry_run", False)),
                                            backup=False,
                                            safeguard_max_lines=int(args.get("safeguard_max_lines", 3000) or 3000),
                                            safeguard_confirm=bool(args.get("safeguard_confirm", False)),
                                        )
                                    elif name == "planning":
                                        # Persist plan under plans/ at the current root (workspace or host base)
                                        try:
                                            plan_text = str(args.get("plan", "") or "").strip()
                                            ctx_text = args.get("context")
                                            if not plan_text:
                                                result = {"ok": False, "error": "plan is required"}
                                            else:
                                                base = policy.workspace_base if policy.scope != "host" else (policy.host_base or Path(os.getcwd()).resolve())
                                                plans_dir = Path(base) / "plans"
                                                plans_dir.mkdir(parents=True, exist_ok=True)
                                                from datetime import datetime as _dt
                                                import re as _re, uuid as _uuid
                                                ts = _dt.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
                                                first_line = plan_text.splitlines()[0] if plan_text else "plan"
                                                slug = _re.sub(r"[^a-zA-Z0-9_-]+", "-", first_line).strip("-") or "plan"
                                                slug = slug[:40]
                                                fname = f"plan-{ts}-{_uuid.uuid4().hex[:6]}-{slug}.md"
                                                fpath = plans_dir / fname
                                                body_lines = [f"# Plan ({ts} UTC)\n"]
                                                if ctx_text:
                                                    body_lines.append("## Context\n")
                                                    body_lines.append(str(ctx_text).strip() + "\n\n")
                                                body_lines.append("## Steps\n")
                                                body_lines.append(plan_text.rstrip() + "\n")
                                                content = "\n".join(body_lines)
                                                with fpath.open("w", encoding="utf-8", newline="") as f:
                                                    f.write(content)
                                                result = {"ok": True, "data": {"path": str(fpath), "bytes_written": len(content.encode('utf-8'))}}
                                        except Exception as _pe:
                                            result = {"ok": False, "error": str(_pe)}
                                    elif name == "string_replace":
                                        result = local_string_replace(
                                            pattern=args.get("pattern", ""),
                                            replacement=args.get("replacement", ""),
                                            policy=policy,
                                            cwd=args.get("cwd", "."),
                                            file_globs=[str(g) for g in (args.get("file_globs") or [])],
                                            exclude_globs=[str(e) for e in (args.get("exclude_globs") or [])],
                                            is_regex=bool(args.get("is_regex", False)),
                                            expected_total_matches=(int(args.get("expected_total_matches")) if args.get("expected_total_matches") is not None else None),
                                            max_replacements_per_file=int(args.get("max_replacements_per_file", 5) or 5),
                                            max_total_replacements=int(args.get("max_total_replacements", 5) or 5),
                                            dry_run=bool(args.get("dry_run", False)),
                                        )
                                    else:
                                        result = {"ok": False, "error": f"unknown tool '{name}'"}
                                except Exception as e:
                                    result = {"ok": False, "error": str(e)}
    
                                # Log outcome after execution
                                self._log_line({
                                    "event": "client.tool.result",
                                    "name": name,
                                    "call_id": call_id,
                                    "ok": bool(result.get("ok")),
                                    "error": result.get("error"),
                                    "data_keys": list((result.get("data") or {}).keys())
                                })
    
                                # Remember last dispatch context for targeted recovery on provider errors
                                try:
                                    self._last_dispatch_ctx = {
                                        "session_id": session_id_d,
                                        "call_id": call_id,
                                        "name": name,
                                        "args": args,
                                        "job_token": job_token,
                                    }
                                except Exception:
                                    self._last_dispatch_ctx = None
    
                                # POST callback
                                try:
                                    if session_id_d and call_id and job_token:
                                        payload_cb = {
                                            "session_id": session_id_d,
                                            "call_id": call_id,
                                            "name": name,
                                            "result": result,
                                            "job_token": job_token,
                                        }
                                        r = await client.post(self.tools_callback_url, json=payload_cb, timeout=self.timeout)
                                        if r.status_code >= 400:
                                            try:
                                                _tool_status_stop()
                                            except Exception:
                                                pass
                                            self.ui.warn(f"tools.callback POST failed: {r.status_code} {r.text}")
                                except Exception as e:
                                    try:
                                        _tool_status_stop()
                                    except Exception:
                                        pass
                                    self.ui.warn(f"tools.callback error: {e}")
                                finally:
                                    try:
                                        # Clear in-flight dispatch context when we send a callback.
                                        if isinstance(self._inflight_dispatch, dict):
                                            if str(self._inflight_dispatch.get("call_id")) == str(call_id):
                                                self._inflight_dispatch = None
                                    except Exception:
                                        pass
    
                            elif event in ("message.completed", "response.completed", "response.done"):
                                try:
                                    if self._input_prompt_active:
                                        final_prompt_restart = await self._pause_busy_input_reader_for_output()
                                except Exception:
                                    final_prompt_restart = False
                                # Safety: this block handles only 'message.completed'.
                                if event in ("response.completed", "response.done"):
                                    # OpenAI Responses raw completion event compatibility:
                                    # normalize into our message.completed shape.
                                    try:
                                        response_obj = data.get("response")
                                        if not isinstance(response_obj, dict):
                                            alt_resp = data.get("data")
                                            if isinstance(alt_resp, dict):
                                                response_obj = alt_resp
                                        if isinstance(response_obj, dict):
                                            norm = dict(data)
                                            model_raw = response_obj.get("model")
                                            if isinstance(model_raw, str) and model_raw.strip() and not (
                                                isinstance(norm.get("model"), str) and str(norm.get("model")).strip()
                                            ):
                                                norm["model"] = model_raw

                                            usage_raw = response_obj.get("usage")
                                            if isinstance(usage_raw, dict):
                                                usage_norm = dict(usage_raw)
                                                in_tok = int(
                                                    usage_norm.get("input_tokens", usage_norm.get("prompt_tokens", 0)) or 0
                                                )
                                                out_tok = int(
                                                    usage_norm.get(
                                                        "output_tokens",
                                                        usage_norm.get("completion_tokens", 0),
                                                    )
                                                    or 0
                                                )
                                                total_tok = int(
                                                    usage_norm.get("total_tokens", (in_tok + out_tok))
                                                    or (in_tok + out_tok)
                                                )
                                                if "prompt_tokens" not in usage_norm:
                                                    usage_norm["prompt_tokens"] = in_tok
                                                if "completion_tokens" not in usage_norm:
                                                    usage_norm["completion_tokens"] = out_tok
                                                if "total_tokens" not in usage_norm:
                                                    usage_norm["total_tokens"] = total_tok
                                                if "turn" not in usage_norm:
                                                    usage_norm["turn"] = {
                                                        "input_tokens": in_tok,
                                                        "output_tokens": out_tok,
                                                        "total_tokens": total_tok,
                                                    }
                                                norm["usage"] = usage_norm

                                            rid_raw = response_obj.get("id")
                                            if isinstance(rid_raw, str) and rid_raw.strip():
                                                rid = rid_raw.strip()
                                                if not (
                                                    isinstance(norm.get("openai_previous_response_id"), str)
                                                    and str(norm.get("openai_previous_response_id")).strip()
                                                ):
                                                    norm["openai_previous_response_id"] = rid
                                                ids_existing = norm.get("openai_response_ids")
                                                if not isinstance(ids_existing, list):
                                                    norm["openai_response_ids"] = [rid]
                                                elif rid not in ids_existing:
                                                    ids_existing.append(rid)
                                                    norm["openai_response_ids"] = ids_existing

                                            output_items = response_obj.get("output")
                                            if isinstance(output_items, list) and "openai_delta_items" not in norm:
                                                norm["openai_delta_items"] = output_items

                                            if not (isinstance(norm.get("text"), str) and str(norm.get("text"))):
                                                txt = response_obj.get("output_text")
                                                if not (isinstance(txt, str) and txt):
                                                    if isinstance(output_items, list):
                                                        txt = self._codex_output_text_from_items(output_items)
                                                if isinstance(txt, str) and txt:
                                                    norm["text"] = txt
                                            data = norm
                                    except Exception:
                                        pass
                                usage = data.get("usage", {})
                                model_used = data.get("model") or self.model
                                try:
                                    tsi = data.get("thinking_insight")
                                    if isinstance(tsi, dict):
                                        thinking_insight_payload = dict(tsi)
                                except Exception:
                                    pass
                                if self.thinking_insight_enabled and isinstance(thinking_insight_payload, dict):
                                    try:
                                        await _render_thinking_payload(thinking_insight_payload, allow_none=True)
                                    except Exception:
                                        pass
                                # OpenAI: persist the last response id so future turns can use previous_response_id.
                                try:
                                    if self._is_openai_model(model_used):
                                        # Prefer the explicit per-turn id list when provided by the server.
                                        ids = data.get("openai_response_ids")
                                        if isinstance(ids, list) and ids:
                                            for x in ids:
                                                if not isinstance(x, str):
                                                    continue
                                                xs = x.strip()
                                                if not xs:
                                                    continue
                                                try:
                                                    if xs not in self._openai_response_id_history:
                                                        self._openai_response_id_history.append(xs)
                                                except Exception:
                                                    pass
                                        rid = data.get("openai_previous_response_id")
                                        if isinstance(rid, str) and rid.strip():
                                            self._openai_previous_response_id = rid.strip()
                                            try:
                                                if rid.strip() not in self._openai_response_id_history:
                                                    self._openai_response_id_history.append(rid.strip())
                                            except Exception:
                                                pass

                                        # OpenAI manual-state replay: server returns the delta items appended
                                        # during this turn (reasoning/tool calls/tool outputs). Persist them.
                                        try:
                                            delta = data.get("openai_delta_items")
                                            if isinstance(delta, list):
                                                base_items = (
                                                    self._openai_last_sent_input_items
                                                    if isinstance(self._openai_last_sent_input_items, list)
                                                    else copy.deepcopy(self._openai_input_items)
                                                )
                                                # Normalize to a list of dicts where possible; keep unknown shapes as-is.
                                                merged: List[Any] = []
                                                try:
                                                    merged.extend(list(base_items or []))
                                                except Exception:
                                                    merged = list(base_items or []) if base_items is not None else []
                                                merged.extend(delta)
                                                # Store only dict-like items (server is expected to send dicts)
                                                cleaned: List[Dict[str, Any]] = []
                                                for it in merged:
                                                    if isinstance(it, dict):
                                                        cleaned.append(dict(it))
                                                self._openai_input_items = self._sanitize_openai_items(cleaned)
                                        except Exception:
                                            pass
                                        finally:
                                            # Clear per-turn sent snapshot
                                            self._openai_last_sent_input_items = None
                                    elif self._is_xai_model(model_used):
                                        # Persist xAI response ids for observability/continuity.
                                        ids = data.get("xai_response_ids")
                                        if isinstance(ids, list) and ids:
                                            for x in ids:
                                                if not isinstance(x, str):
                                                    continue
                                                xs = x.strip()
                                                if not xs:
                                                    continue
                                                try:
                                                    if xs not in self._xai_response_id_history:
                                                        self._xai_response_id_history.append(xs)
                                                except Exception:
                                                    pass
                                        rid = data.get("xai_previous_response_id")
                                        if isinstance(rid, str) and rid.strip():
                                            self._xai_previous_response_id = rid.strip()
                                            try:
                                                if rid.strip() not in self._xai_response_id_history:
                                                    self._xai_response_id_history.append(rid.strip())
                                            except Exception:
                                                pass

                                        # xAI manual-state replay: merge server delta onto what we sent.
                                        try:
                                            delta = data.get("xai_delta_items")
                                            if isinstance(delta, list):
                                                base_items = (
                                                    self._xai_last_sent_input_items
                                                    if isinstance(self._xai_last_sent_input_items, list)
                                                    else copy.deepcopy(self._xai_input_items)
                                                )
                                                merged: List[Any] = []
                                                try:
                                                    merged.extend(list(base_items or []))
                                                except Exception:
                                                    merged = list(base_items or []) if base_items is not None else []
                                                merged.extend(delta)
                                                cleaned: List[Dict[str, Any]] = []
                                                for it in merged:
                                                    if isinstance(it, dict):
                                                        cleaned.append(dict(it))
                                                self._xai_input_items = self._sanitize_openai_items(cleaned)
                                        except Exception:
                                            pass
                                        finally:
                                            self._xai_last_sent_input_items = None
                                except Exception:
                                    pass
                                # Gemini: server may include an authoritative provider-native history snapshot.
                                try:
                                    if isinstance(model_used, str) and model_used.startswith("gemini-"):
                                        rpm = data.get("raw_provider_messages")
                                        self._gemini_raw_history = self._normalize_gemini_raw_messages(rpm)
                                except Exception:
                                    pass
                                # Anthropic: server may include an authoritative provider-native history snapshot.
                                try:
                                    if isinstance(model_used, str) and model_used.startswith("claude-"):
                                        rpm = data.get("raw_provider_messages")
                                        if isinstance(rpm, list):
                                            self._anthropic_raw_history = [dict(x) if isinstance(x, dict) else x for x in rpm]
                                except Exception:
                                    pass
                                # Mark completion for retry controller
                                try:
                                    last_completed = True
                                except Exception:
                                    pass
                                # No longer streaming assistant tokens
                                streaming_assistant = False
                                web_search_calls_raw = data.get("web_search") if isinstance(data, dict) else None
                                web_search_calls: List[Dict[str, Any]] = (
                                    web_search_calls_raw if isinstance(web_search_calls_raw, list) else []
                                )
                                if (
                                    self.thinking_insight_enabled
                                    and (not thinking_rendered_live)
                                    and (not assistant_buf)
                                ):
                                    try:
                                        await _render_thinking_payload(
                                            thinking_insight_payload if isinstance(thinking_insight_payload, dict) else {},
                                            allow_none=True,
                                        )
                                    except Exception:
                                        pass
                                # If no delta ever arrived (empty completion), still print the header once
                                if not header_printed:
                                    try:
                                        label = model_used or self.model or "(server default)"
                                    except Exception:
                                        label = self.model or "(server default)"
                                    # Stop and clear indicator before writing the header
                                    try:
                                        await _indicator_stop(clear=True)
                                    except Exception:
                                        pass
                                    # Print assistant header on the current line (indicator line cleared already)
                                    try:
                                        self.ui.write_assistant_raw(str(label) + ": ")
                                    except Exception:
                                        try:
                                            print(str(label) + ": ", end="", flush=True)
                                        except Exception:
                                            pass
                                    header_printed = True
                                    try:
                                        self.ui.debug_log(f"header.printed model='{label}' on_completed_no_delta")
                                    except Exception:
                                        pass
                                # Some backends (notably OpenAI Responses flows after tool steps)
                                # can finish with no message.delta and put answer text only in completion payload fields.
                                completed_text = data.get("text") if isinstance(data, dict) else None
                                if (not isinstance(completed_text, str)) or (not completed_text):
                                    completed_text = data.get("output_text") if isinstance(data, dict) else None
                                if (not isinstance(completed_text, str)) or (not completed_text):
                                    completed_text = data.get("assistant_text") if isinstance(data, dict) else None
                                if (not isinstance(completed_text, str)) or (not completed_text):
                                    completed_text = data.get("content") if isinstance(data, dict) else None
                                if (not isinstance(completed_text, str)) or (not completed_text):
                                    try:
                                        msg_obj = data.get("message") if isinstance(data, dict) else None
                                        if isinstance(msg_obj, dict):
                                            msg_txt = msg_obj.get("text")
                                            if not (isinstance(msg_txt, str) and msg_txt):
                                                msg_content = msg_obj.get("content")
                                                if isinstance(msg_content, list):
                                                    msg_txt = self._codex_output_text_from_items(
                                                        [{"type": "message", "content": msg_content}]
                                                    )
                                            if isinstance(msg_txt, str) and msg_txt:
                                                completed_text = msg_txt
                                    except Exception:
                                        pass
                                if (not isinstance(completed_text, str)) or (not completed_text):
                                    try:
                                        items_like = None
                                        if isinstance(data, dict):
                                            if isinstance(data.get("openai_delta_items"), list):
                                                items_like = data.get("openai_delta_items")
                                            elif isinstance(data.get("xai_delta_items"), list):
                                                items_like = data.get("xai_delta_items")
                                            elif isinstance(data.get("output"), list):
                                                items_like = data.get("output")
                                        if isinstance(items_like, list) and items_like:
                                            txt_from_items = self._codex_output_text_from_items(items_like)
                                            if isinstance(txt_from_items, str) and txt_from_items:
                                                completed_text = txt_from_items
                                    except Exception:
                                        pass
                                if (not isinstance(completed_text, str)) or (not completed_text):
                                    try:
                                        resp_obj = data.get("response") if isinstance(data, dict) else None
                                        if isinstance(resp_obj, dict):
                                            resp_txt = resp_obj.get("output_text")
                                            if not (isinstance(resp_txt, str) and resp_txt):
                                                resp_txt = resp_obj.get("content")
                                            if not (isinstance(resp_txt, str) and resp_txt):
                                                out_items = resp_obj.get("output")
                                                if isinstance(out_items, list):
                                                    resp_txt = self._codex_output_text_from_items(out_items)
                                            if isinstance(resp_txt, str) and resp_txt:
                                                completed_text = resp_txt
                                    except Exception:
                                        pass
                                if (not assistant_buf) and isinstance(completed_text, str) and completed_text:
                                    assistant_buf.append(completed_text)
                                    try:
                                        model_output_chars += len(completed_text)
                                    except Exception:
                                        pass
                                    try:
                                        self._stream_partial_text = "".join(assistant_buf)
                                    except Exception:
                                        pass
                                    try:
                                        self._current_turn["assistant_so_far"] = "".join(assistant_buf)
                                        self._current_turn["model"] = model_used
                                    except Exception:
                                        pass
                                    try:
                                        self.ui.write_assistant_raw(completed_text)
                                    except Exception:
                                        try:
                                            print(completed_text, end="", flush=True)
                                        except Exception:
                                            pass
                                    try:
                                        await self._ws_broadcast(
                                            "message.sync",
                                            {
                                                "text": "".join(assistant_buf),
                                                "model": model_used,
                                            },
                                        )
                                    except Exception:
                                        pass

                                buf_str = "".join(assistant_buf)
                                self.ui.ensure_newline(buf_str)
                                if self.thinking_insight_enabled and (not thinking_rendered_live):
                                    try:
                                        await _render_thinking_payload(
                                            thinking_insight_payload if isinstance(thinking_insight_payload, dict) else {},
                                            allow_none=True,
                                        )
                                    except Exception:
                                        pass
                                # Stream summary for debugging
                                try:
                                    if DEBUG_SSE or self.ui.verbose:
                                        self.ui.print(
                                            f"[debug] stream stats: events={_events_total} deltas={_deltas_total} bytes={_bytes_total}",
                                            style=self.ui.theme["dim"],
                                        )
                                except Exception:
                                    pass
    
                                # Timing: wall-clock from turn start; and session elapsed
                                try:
                                    now_pc = time.perf_counter()
                                    turn_secs = self._turn_elapsed_seconds(now=now_pc, finalize=True)
                                except Exception:
                                    turn_secs = 0.0
                                    now_pc = time.time()  # type: ignore
                                try:
                                    session_secs = self._session_elapsed_seconds(now=now_pc)
                                except Exception:
                                    session_secs = 0.0
    
                                # Usage summary line
                                turn = (usage.get("turn") or {})
                                cum = (usage.get("cumulative") or {})
                                
                                # Base turn tokens from server's usage.turn
                                turn_in = int(turn.get("input_tokens", 0) or 0)
                                turn_out = int(turn.get("output_tokens", 0) or 0)
                                turn_total = int(turn.get("total_tokens", 0) or 0)
                                
                                # Fallback values from usage.turn/top-level
                                if turn_total == 0:
                                    turn_in = int(usage.get("prompt_tokens", 0) or 0)
                                    turn_out = int(usage.get("completion_tokens", 0) or 0)
                                    turn_total = int(usage.get("total_tokens", 0) or 0)
                                
                                # If turn_total still zero but we have input+output, derive it
                                if turn_total == 0 and (turn_in > 0 or turn_out > 0):
                                    turn_total = turn_in + turn_out

                                # Debug aid: make silent-drop cases visible in the CLI.
                                # If provider reports output tokens but we captured no assistant text,
                                # emit a concise warning with key payload hints.
                                try:
                                    if (not assistant_buf) and int(turn_out or 0) > 0:
                                        data_keys: List[str] = []
                                        try:
                                            if isinstance(data, dict):
                                                data_keys = sorted([str(k) for k in data.keys()])[:24]
                                        except Exception:
                                            data_keys = []
                                        self.ui.warn(
                                            "Debug: output tokens were reported but no assistant text was captured."
                                        )
                                        if data_keys:
                                            self.ui.print(
                                                "Debug keys: " + ", ".join(data_keys),
                                                style=self.ui.theme["dim"],
                                            )
                                except Exception:
                                    pass
     
                                # Anthropic prompt caching: include cache creation/read input tokens when provided by server
                                # This adjusts per-turn display only; cumulative handling below will pick up from server when present.
                                try:
                                    cache_create = int(usage.get("cache_creation_input_tokens", 0) or 0)
                                    cache_read = int(usage.get("cache_read_input_tokens", 0) or 0)
                                    cache_add = cache_create + cache_read
                                except Exception:
                                    cache_add = 0
                                if cache_add > 0:
                                    # Only add when server's turn_total equals in+out (i.e., cache not already included)
                                    try:
                                        if turn_total == (turn_in + turn_out):
                                            turn_in += cache_add
                                            turn_total += cache_add
                                    except Exception:
                                        # Fallback: still add to input and recompute total
                                        turn_in += cache_add
                                        turn_total = turn_in + turn_out
    
                                # Compute proposed local cumulative including this turn (ensures final response counted)
                                prev_cum_in = int(self._cum_input_tokens)
                                prev_cum_out = int(self._cum_output_tokens)
                                prev_cum_total = int(self._cum_total_tokens)
    
                                local_cum_in = prev_cum_in + int(turn_in)
                                local_cum_out = prev_cum_out + int(turn_out)
                                local_cum_total = prev_cum_total + (int(turn_total) if turn_total else (int(turn_in) + int(turn_out)))
    
                                # Prefer server cumulative when available and not less than local (some providers may omit final step)
                                cum_source = "client"
                                server_cum_in = int(cum.get("input_tokens", 0) or 0)
                                server_cum_out = int(cum.get("output_tokens", 0) or 0)
                                server_cum_total = int(cum.get("total_tokens", 0) or 0)
    
                                if server_cum_total > 0 and server_cum_total >= local_cum_total:
                                    # Server provided cumulative and it already includes this turn's final response
                                    cum_in = server_cum_in
                                    cum_out = server_cum_out
                                    cum_total = server_cum_total
                                    cum_source = "server"
                                    # Sync client-side counters to match server
                                    self._cum_input_tokens = cum_in
                                    self._cum_output_tokens = cum_out
                                    self._cum_total_tokens = cum_total
                                else:
                                    # Use local cumulative to ensure we include the final response tokens
                                    self._cum_input_tokens = local_cum_in
                                    self._cum_output_tokens = local_cum_out
                                    self._cum_total_tokens = local_cum_total
                                    cum_in = int(self._cum_input_tokens)
                                    cum_out = int(self._cum_output_tokens)
                                    cum_total = int(self._cum_total_tokens)
                                    # If server attempted cumulative but was lower (e.g., Anthropic missing final), note source
                                    if server_cum_total > 0:
                                        cum_source = "client+final"
    
                                # Percentage based on last turn's total (input + output)
                                context_window = self.ctx_window or 400000
                                if context_window > 0:
                                    percent_filled = (turn_total / context_window) * 100
                                    percent_str = f"{percent_filled:.1f}%"
                                else:
                                    percent_str = "N/A"
    
                                # Commit usage to server billing/logs (best-effort) before rendering info box so cost line is available
                                await self._commit_usage(
                                    client,
                                    # Use the server-assigned session_id so the server can read its own usage logs
                                    session_id=session_id,
                                    model_used=model_used,
                                    usage=usage or {
                                        "prompt_tokens": turn_in,
                                        "completion_tokens": turn_out,
                                        "total_tokens": turn_total,
                                    },
                                )
    
                                # Diagnostic logging when tokens or costs appear as zero
                                try:
                                    diag_needed = False
                                    zero_tokens = (int(turn_in) == 0 and int(turn_out) == 0 and int(turn_total) == 0)
                                    zero_costs = (float(self._last_commit_cost_usd) == 0.0 and float(self.server_cumulative_cost_usd) == 0.0)
                                    if zero_tokens or zero_costs:
                                        diag_needed = True
                                    if diag_needed:
                                        # Sum provider step tokens (if the server sent them)
                                        steps = usage.get("provider_steps") if isinstance(usage, dict) else None
                                        sum_in_steps = 0
                                        sum_out_steps = 0
                                        if isinstance(steps, list):
                                            for st in steps:
                                                try:
                                                    sum_in_steps += int(st.get("input_tokens", 0) or 0)
                                                    sum_out_steps += int(st.get("output_tokens", 0) or 0)
                                                except Exception:
                                                    continue
                                        # Local cost estimates from two sources: turn tokens and provider_steps sums
                                        def _safe_cost_for(mi: Optional[int], mo: Optional[int]) -> float:
                                            try:
                                                u = {
                                                    "prompt_tokens": int(mi or 0),
                                                    "completion_tokens": int(mo or 0),
                                                    "total_tokens": int((mi or 0) + (mo or 0)),
                                                }
                                                return float(self.compute_cost_usd(model_used, u))
                                            except Exception:
                                                return 0.0
                                        est_cost_turn = _safe_cost_for(turn_in, turn_out)
                                        est_cost_steps = _safe_cost_for(sum_in_steps, sum_out_steps)
    
                                        diag_lines: List[str] = []
                                        diag_lines.append("Diagnostics: token/cost appear as 0 — investigating sources")
                                        # Stream evidence
                                        try:
                                            diag_lines.append(f"- stream: events={_events_total}, deltas={_deltas_total}, bytes={_bytes_total}")
                                        except Exception:
                                            pass
                                        # Server usage as sent
                                        try:
                                            klist = ",".join(sorted(list(usage.keys()))) if isinstance(usage, dict) else "(not a dict)"
                                            diag_lines.append(f"- usage keys: {klist}")
                                        except Exception:
                                            pass
                                        diag_lines.append(f"- usage.turn -> in {int(turn_in)} | out {int(turn_out)} | total {int(turn_total)}")
                                        # Provider steps evidence
                                        if (sum_in_steps + sum_out_steps) > 0:
                                            diag_lines.append(f"- provider_steps sum -> in {int(sum_in_steps)} | out {int(sum_out_steps)}")
                                        else:
                                            diag_lines.append("- provider_steps: (none or zero)")
                                        # Server cumulative tokens if present
                                        try:
                                            diag_lines.append(
                                                f"- usage.cumulative (server) -> in {int((usage.get('cumulative') or {}).get('input_tokens', 0) or 0)} | out {int((usage.get('cumulative') or {}).get('output_tokens', 0) or 0)} | total {int((usage.get('cumulative') or {}).get('total_tokens', 0) or 0)}"
                                            )
                                        except Exception:
                                            pass
                                        # Cost lines (server commit vs local estimates)
                                        try:
                                            diag_lines.append(
                                                f"- commit cost (server): last=${float(self._last_commit_cost_usd):.6f}, chat_total=${float(self.server_cumulative_cost_usd):.6f}"
                                            )
                                        except Exception:
                                            diag_lines.append("- commit cost (server): n/a")
                                        diag_lines.append(f"- est cost (from usage.turn): ${est_cost_turn:.6f}")
                                        diag_lines.append(f"- est cost (from provider_steps): ${est_cost_steps:.6f}")
                                        # Commit path evidence
                                        try:
                                            diag_lines.append(
                                                f"- commit path: enabled={bool(self.server_usage_commit)} | session_id={'set' if session_id else 'missing'} | model={model_used or '(unknown)'}"
                                            )
                                        except Exception:
                                            pass
                                        # Truncated raw usage preview
                                        try:
                                            diag_lines.append("- raw usage (truncated):")
                                            diag_lines.append(self._clip(truncate_json(usage, 1500), 1500))
                                        except Exception:
                                            pass
                                        # Render diagnostics block above the usage/info box
                                        try:
                                            if self.ui.rich and Panel:
                                                self.ui.console.print(Panel("\n".join(diag_lines), title="Diagnostics (usage/cost)", border_style=self.ui.theme["warn"]))
                                            else:
                                                self.ui.print("Diagnostics (usage/cost):", style=self.ui.theme["warn"])  # type: ignore
                                                for ln in diag_lines:
                                                    self.ui.print(ln, style=self.ui.theme["dim"])  # type: ignore
                                        except Exception:
                                            # Best-effort plain prints
                                            self.ui.print("Diagnostics (usage/cost):")
                                            for ln in diag_lines:
                                                self.ui.print(ln)
                                        # Also persist to session log for later analysis
                                        try:
                                            self._log_line({
                                                "event": "diagnostics.usage_cost_zero",
                                                "turn": {"in": int(turn_in), "out": int(turn_out), "total": int(turn_total)},
                                                "steps_sum": {"in": int(sum_in_steps), "out": int(sum_out_steps)},
                                                "est_cost_turn": float(est_cost_turn),
                                                "est_cost_steps": float(est_cost_steps),
                                                "commit_cost": float(self._last_commit_cost_usd),
                                                "chat_cost": float(self.server_cumulative_cost_usd),
                                                "session_id": session_id,
                                                "model": model_used,
                                                "usage_keys": (sorted(list(usage.keys())) if isinstance(usage, dict) else None),
                                            })
                                        except Exception:
                                            pass
                                except Exception:
                                    # Never let diagnostics crash the UI
                                    pass
    
                                # Prepare a consolidated info box with usage, timing, and context
                                box_lines: List[str] = []
                                context_line_str: Optional[str] = None
                                # henosis-cli version (from pyproject/installed metadata) with update hint when available
                                try:
                                    if not self._cli_version:
                                        self._cli_version = self._resolve_current_version() or None
                                    if self._cli_version:
                                        ver_line = f"henosis-cli v{self._cli_version}"
                                        if (self._version_outdated is True) and self._latest_version:
                                            ver_line += f" → v{self._latest_version} available | update: {os.path.basename(sys.executable)} -m pip install -U henosis-cli"
                                        box_lines.append(ver_line)
                                except Exception:
                                    pass
                                # Add requested billing line with model, cost, session cumulative, and remaining credits
                                try:
                                    rem_line = (
                                        f" | remaining credits: ${float(self._last_remaining_credits):.6f}"
                                        if (self._last_remaining_credits is not None)
                                        else ""
                                    )
                                except Exception:
                                    rem_line = ""
                                # Compact style: include reasoning effort inline with model name when applicable
                                try:
                                    effort_seg = ""
                                    if self._is_openai_reasoning_model(model_used):
                                        # Convert low|medium|high|xhigh -> Low|Medium|High|XHigh for display
                                        lvl = str(self.reasoning_effort or "medium").strip().lower()
                                        if lvl not in ("low", "medium", "high", "xhigh"):
                                            lvl = "medium"
                                        disp = {"low": "Low", "medium": "Medium", "high": "High", "xhigh": "XHigh"}.get(lvl, "Medium")
                                        effort_seg = f" {disp}"
                                except Exception:
                                    effort_seg = ""
                                model_only_line = f"model: {model_used or '(unknown)'}{effort_seg}"
                                box_lines.append(
                                    f"model: {model_used or '(unknown)'}{effort_seg} | cost charged: ${float(self._last_commit_cost_usd):.6f} | chat cost: ${float(self.server_cumulative_cost_usd):.6f}{rem_line}"
                                )
                                # Reasoning tokens: include inline with turn/session math
                                turn_reason = 0
                                try:
                                    explicit_rt = None
                                    # 1) usage.thinking_tokens (generic key used by server for reasoning tokens)
                                    if isinstance(usage.get("thinking_tokens"), (int, float)):
                                        explicit_rt = int(usage.get("thinking_tokens") or 0)
                                    # 2) usage.reasoning_tokens (alternate naming)
                                    elif isinstance(usage.get("reasoning_tokens"), (int, float)):
                                        explicit_rt = int(usage.get("reasoning_tokens") or 0)
                                    # 3) Nested details (xAI/OpenAI/OpenAI completion details)
                                    elif isinstance(usage.get("completion_tokens_details"), dict):
                                        ctd = usage.get("completion_tokens_details") or {}
                                        rt2 = ctd.get("reasoning_tokens")
                                        if isinstance(rt2, (int, float)):
                                            explicit_rt = int(rt2)
                                    elif isinstance(usage.get("output_tokens_details"), dict):
                                        otd = usage.get("output_tokens_details") or {}
                                        rt3 = otd.get("reasoning_tokens")
                                        if isinstance(rt3, (int, float)):
                                            explicit_rt = int(rt3)
                                    if isinstance(explicit_rt, int) and explicit_rt > 0:
                                        turn_reason = int(explicit_rt)
                                    else:
                                        # Fallback: infer from turn_total gap when available
                                        gap = int(max(0, (int(turn_total or 0) - (int(turn_in or 0) + int(turn_out or 0)))))
                                        if gap > 0:
                                            turn_reason = gap
                                except Exception:
                                    turn_reason = 0
    
                                # Session-level reasoning: prefer server cumulative when available
                                cum_reason = int(self._cum_reasoning_tokens or 0)
                                try:
                                    server_cum_reason = 0
                                    if isinstance(usage.get("cumulative"), dict):
                                        cu = usage.get("cumulative") or {}
                                        if isinstance(cu.get("thinking_tokens"), (int, float)):
                                            server_cum_reason = int(cu.get("thinking_tokens") or 0)
                                        elif isinstance(cu.get("reasoning_tokens"), (int, float)):
                                            server_cum_reason = int(cu.get("reasoning_tokens") or 0)
                                        else:
                                            # Nested under details
                                            for key in ("completion_tokens_details", "output_tokens_details"):
                                                det = cu.get(key)
                                                if isinstance(det, dict) and isinstance(det.get("reasoning_tokens"), (int, float)):
                                                    server_cum_reason = int(det.get("reasoning_tokens") or 0)
                                                    break
                                    if server_cum_total > 0 and server_cum_total >= local_cum_total and server_cum_reason > 0:
                                        self._cum_reasoning_tokens = int(server_cum_reason)
                                    else:
                                        # Roll forward locally with this turn's reasoning tokens
                                        self._cum_reasoning_tokens = int(self._cum_reasoning_tokens) + int(turn_reason)
                                    cum_reason = int(self._cum_reasoning_tokens)
                                except Exception:
                                    # Still roll forward locally
                                    try:
                                        self._cum_reasoning_tokens = int(self._cum_reasoning_tokens) + int(turn_reason)
                                        cum_reason = int(self._cum_reasoning_tokens)
                                    except Exception:
                                        cum_reason = int(turn_reason or 0)
    
                                # Turn and session math lines with inline reasoning when available
                                if int(turn_reason) > 0:
                                    box_lines.append(f"Turn tokens: in {int(turn_in)} + out {int(turn_out)} + reason {int(turn_reason)} = {int(turn_total)}")
                                else:
                                    box_lines.append(f"Turn tokens: in {int(turn_in)} + out {int(turn_out)} = {int(turn_total)}")
                                if int(cum_reason) > 0:
                                    box_lines.append(f"Session tokens: in {int(cum_in)} + out {int(cum_out)} + reason {int(cum_reason)} = {int(cum_total)}")
                                else:
                                    box_lines.append(f"Session tokens: in {int(cum_in)} + out {int(cum_out)} = {int(cum_total)}")
    
                                # Track last used model for potential future display/use
                                try:
                                    self._last_used_model = model_used
                                except Exception:
                                    pass
    
                                # Always show timing summary
                                def _fmt(sec: float) -> str:
                                    try:
                                        if sec < 60:
                                            return f"{sec:.2f}s"
                                        m, s = divmod(int(sec), 60)
                                        if m < 60:
                                            return f"{m}m {s}s"
                                        h, m = divmod(m, 60)
                                        return f"{h}h {m}m {s}s"
                                    except Exception:
                                        return f"{sec:.2f}s"
    
                                box_lines.append(f"Time: {_fmt(turn_secs)} (turn) | {_fmt(session_secs)} (session) | Tools: {tool_calls} call(s)")
    
                                # Compact web search summary (if any)
                                try:
                                    if web_search_calls:
                                        # Include up to 3 queries
                                        qs: List[str] = []
                                        for call in web_search_calls[:3]:
                                            action = call.get("action") if isinstance(call, dict) else None
                                            if isinstance(action, dict):
                                                q = action.get("query") or action.get("search_query")
                                                if isinstance(q, str) and q.strip():
                                                    qs.append(q.strip())
                                        if qs:
                                            box_lines.append("Web search: " + "; ".join(qs) + (" ..." if len(web_search_calls) > 3 else ""))
                                        else:
                                            box_lines.append(f"Web search: {len(web_search_calls)} call(s)")
                                except Exception:
                                    pass
    
                                # Render a simple bar showing current cumulative context usage against the window
                                try:
                                    # Use model-specific context window when known
                                    model_ctx = self._get_model_ctx_window(model_used)
                                    context_window = int(model_ctx) if model_ctx else (self.ctx_window or 400000)
                                    if context_window > 0:
                                        # Show bar based on the last assistant reply's input+output (prefer final provider step)
                                        last_in = 0
                                        last_out = 0
                                        steps_for_last = None
                                        try:
                                            steps_for_last = usage.get("provider_steps") if isinstance(usage, dict) else None
                                        except Exception:
                                            steps_for_last = None
                                        if isinstance(steps_for_last, list) and steps_for_last:
                                            for st in reversed(steps_for_last):
                                                try:
                                                    so = int(st.get("output_tokens", 0) or 0)
                                                    si = int(st.get("input_tokens", 0) or 0)
                                                    if so > 0:
                                                        last_out = so
                                                        last_in = si
                                                        break
                                                except Exception:
                                                    continue
                                        else:
                                            last_out = int(turn_out)
                                            last_in = 0
                                        last_total = float(last_in + last_out)
                                        cum_pct = max(0.0, min(100.0, (last_total / float(context_window)) * 100.0))
                                        bar_width = 30
                                        filled = int(round((cum_pct / 100.0) * bar_width))
                                        empty = bar_width - filled
                                        # Show the bar for this reply's usage and include token count (in+out) and percent
                                        context_line_str = self._context_meter_panel_line(
                                            int(last_total),
                                            float(cum_pct),
                                            int(filled),
                                            int(empty),
                                        )
                                        box_lines.append(context_line_str)
                                except Exception:
                                    # Non-fatal UI enhancement
                                    pass
    
                                # OpenAI prompt caching banner when detected (cached input tokens billed at 10%)
                                try:
                                    price = self._resolve_price(model_used)
                                    provider = (price.get("provider") or "").lower()
                                    cached_tokens_banner = 0
                                    # Prefer top-level input_tokens_details
                                    itd = usage.get("input_tokens_details") if isinstance(usage, dict) else None
                                    if isinstance(itd, dict):
                                        cached_tokens_banner = int(itd.get("cached_tokens", 0) or 0)
                                    # Fallback: some servers may nest under turn.input_tokens_details
                                    if not cached_tokens_banner:
                                        itd2 = (usage.get("turn") or {}).get("input_tokens_details") if isinstance(usage, dict) else None
                                        if isinstance(itd2, dict):
                                            cached_tokens_banner = int(itd2.get("cached_tokens", 0) or 0)
                                    if provider == "openai" and cached_tokens_banner and cached_tokens_banner > 0:
                                        # Compute savings relative to full input price (cache billed at 10% input rate)
                                        try:
                                            in_rate_per_m = float(price.get("input", 0.0))
                                        except Exception:
                                            in_rate_per_m = 0.0
                                        try:
                                            saved_usd = (int(cached_tokens_banner) / 1_000_000.0) * in_rate_per_m * 0.90
                                        except Exception:
                                            saved_usd = 0.0
                                        # Short copy per request: say "saved $x.xx with prompt cache"
                                        box_lines.append(f"saved ${saved_usd:.2f} with prompt cache")
                                except Exception:
                                    pass
    
                                # Anthropic prompt caching banner when detected (reads @10% input rate; creation billed at TTL multiplier)
                                try:
                                    price = self._resolve_price(model_used)
                                    provider = (price.get("provider") or "").lower()
                                    if provider == "anthropic":
                                        cr = int(usage.get("cache_read_input_tokens", 0) or 0)
                                        cc = int(usage.get("cache_creation_input_tokens", 0) or 0)
                                        # Optional breakdown
                                        cc_5m = 0
                                        cc_1h = 0
                                        try:
                                            ccmap = usage.get("cache_creation") if isinstance(usage, dict) else None
                                            if isinstance(ccmap, dict):
                                                cc_5m = int(ccmap.get("ephemeral_5m_input_tokens", 0) or 0)
                                                cc_1h = int(ccmap.get("ephemeral_1h_input_tokens", 0) or 0)
                                        except Exception:
                                            cc_5m = cc_5m or 0
                                            cc_1h = cc_1h or 0
                                        if (cr > 0) or (cc > 0) or (cc_5m > 0) or (cc_1h > 0):
                                            # Build a concise line similar to OpenAI banner
                                            line = f"Billing: Anthropic prompt cache read {int(cr)} token(s) @10% input rate"
                                            if (cc_5m > 0) or (cc_1h > 0):
                                                line += f" | created {int(cc_5m)} @1.25x + {int(cc_1h)} @2x"
                                            else:
                                                if cc > 0:
                                                    line += f" | created {int(cc)} token(s) (billed at 1.25x/2x based on TTL)"
                                            # Calculate savings (reported on a separate line to match OpenAI style)
                                            saved_line = None
                                            if cr > 0:
                                                try:
                                                    in_rate_per_m = float(price.get("input", 0.0))
                                                    # Savings = cache_read * (1.0 - 0.1) * price
                                                    saved_usd = (int(cr) / 1_000_000.0) * in_rate_per_m * 0.90
                                                    saved_line = f"saved ${saved_usd:.2f} with prompt cache"
                                                except Exception:
                                                    saved_line = None
                                            box_lines.append(line)
                                            if saved_line:
                                                box_lines.append(saved_line)
                                except Exception:
                                    pass
    
                                # Render post-turn status according to Issue #15 config (fields + layout).
                                try:
                                    # Best-effort extract prompt cache-related lines from the legacy verbose list.
                                    prompt_cache_lines: List[str] = []
                                    try:
                                        for _ln in box_lines:
                                            if not isinstance(_ln, str):
                                                continue
                                            s = _ln.strip()
                                            if not s:
                                                continue
                                            if s.startswith("saved $") or s.startswith("Billing:"):
                                                prompt_cache_lines.append(s)
                                    except Exception:
                                        prompt_cache_lines = []

                                    # Context meter details for inline rendering
                                    context_meter: Optional[Dict[str, Any]] = None
                                    try:
                                        if context_line_str and isinstance(context_line_str, str) and ":" in context_line_str:
                                            # Parse "Context: <tokens> ... <pct>%" tail
                                            _, tail = context_line_str.split(":", 1)
                                            parts = tail.strip().split()
                                            total_val = int(parts[0]) if parts and parts[0].isdigit() else 0
                                            pct_val = 0.0
                                            if parts:
                                                last_tok = parts[-1]
                                                if isinstance(last_tok, str) and last_tok.endswith("%"):
                                                    try:
                                                        pct_val = float(last_tok[:-1])
                                                    except Exception:
                                                        pct_val = 0.0
                                            bar_width = 30
                                            filled = int(round((pct_val / 100.0) * bar_width))
                                            empty = max(0, bar_width - filled)
                                            context_meter = {
                                                "tokens": total_val,
                                                "pct": float(pct_val),
                                                "filled": int(filled),
                                                "empty": int(empty),
                                            }
                                    except Exception:
                                        context_meter = None

                                    status_ctx = {
                                        "session_id": session_id,
                                        "model_used": model_used,
                                        "effort_disp": effort_seg,
                                        "tool_calls": tool_calls,
                                        "turn_tokens_line": None,
                                        "session_tokens_line": None,
                                        "timing_line": None,
                                        "web_search_line": (None),
                                        "cli_version_line": (box_lines[0] if (box_lines and isinstance(box_lines[0], str) and box_lines[0].startswith("henosis-cli")) else None),
                                        "billing_line": None,
                                        "prompt_cache_lines": prompt_cache_lines,
                                        "context_meter": context_meter,
                                        "context_meter_panel": context_line_str,
                                        "context_pct": (float(context_meter.get("pct")) if isinstance(context_meter, dict) and ("pct" in context_meter) else None),
                                        "context_window": context_window,
                                        "context_window_known": bool(((model_ctx if 'model_ctx' in locals() else None) or self.ctx_window)),
                                        "cum_in": cum_in,
                                        "cum_out": cum_out,
                                        "cum_total": cum_total,
                                    }
                                    # Derive standard lines from the legacy box (best-effort).
                                    try:
                                        for _ln in box_lines:
                                            if not isinstance(_ln, str):
                                                continue
                                            if _ln.startswith("Turn tokens:"):
                                                status_ctx["turn_tokens_line"] = _ln
                                            elif _ln.startswith("Session tokens:"):
                                                status_ctx["session_tokens_line"] = _ln
                                            elif _ln.startswith("Time:"):
                                                status_ctx["timing_line"] = _ln
                                    except Exception:
                                        pass
                                    # Derive billing line (second line in legacy box) when present.
                                    try:
                                        for _ln in box_lines:
                                            if isinstance(_ln, str) and _ln.startswith("model:") and "cost charged" in _ln:
                                                status_ctx["billing_line"] = _ln
                                                break
                                    except Exception:
                                        pass
                                    if self.agent_mode:
                                        try:
                                            billing_line = status_ctx.get("billing_line")
                                            terminal_line = f"Remote Control terminal: {self._remote_control_terminal_display_name()}"
                                            if isinstance(billing_line, str) and billing_line.strip():
                                                status_ctx["billing_line"] = f"{terminal_line} | {billing_line}"
                                            else:
                                                status_ctx["billing_line"] = terminal_line
                                        except Exception:
                                            pass
                                    # Web search line (best-effort)
                                    try:
                                        for _ln in box_lines:
                                            if isinstance(_ln, str) and _ln.startswith("Web search:"):
                                                status_ctx["web_search_line"] = _ln
                                                break
                                    except Exception:
                                        pass
                                    self._render_status_info(status_ctx)
                                except Exception:
                                    # Fallback to legacy behavior
                                    try:
                                        if str(getattr(self, 'usage_info_mode', 'verbose')).lower() == 'concise' and context_line_str:
                                            try:
                                                _, tail = context_line_str.split(":", 1)
                                                self.ui.print("tokens used:", style="white", end="")
                                                self.ui.print(tail)
                                            except Exception:
                                                self.ui.print(context_line_str, style="white")
                                        else:
                                            self.ui.info_box("Usage & Info", box_lines)
                                    except Exception:
                                        pass
    
                                # Print a one-liner usage by category only when verbose (silenced by default)
                                try:
                                    by_cat = usage.get("by_category") or {}
                                    if isinstance(by_cat, dict) and by_cat:
                                        order = ["read", "nav", "write", "exec"]
                                        segs = []
                                        for k in order:
                                            v = by_cat.get(k)
                                            if not isinstance(v, dict):
                                                continue
                                            vin = int(v.get("input_tokens", 0) or 0)
                                            vout = int(v.get("output_tokens", 0) or 0)
                                            segs.append(f"{k} in {vin}/out {vout}")
                                        for k, v in by_cat.items():
                                            if k in order or not isinstance(v, dict):
                                                continue
                                            vin = int(v.get("input_tokens", 0) or 0)
                                            vout = int(v.get("output_tokens", 0) or 0)
                                            segs.append(f"{k} in {vin}/out {vout}")
                                        if segs and self.ui.verbose:
                                            self.ui.print(
                                                "Usage by category: " + " | ".join(segs),
                                                style=self.ui.theme["dim"],
                                            )
                                except Exception:
                                    pass
    
                                # Grey debug line: show provider raw step usages if present and their summed totals
                                try:
                                    steps = usage.get("provider_steps") if isinstance(usage, dict) else None
                                    if isinstance(steps, list) and steps:
                                        sum_in = 0
                                        sum_out = 0
                                        parts = []
                                        for st in steps[:10]:
                                            try:
                                                si = int(st.get("input_tokens", 0) or 0)
                                                so = int(st.get("output_tokens", 0) or 0)
                                                sum_in += si
                                                sum_out += so
                                                stage = str(st.get("stage") or "turn")
                                                parts.append(f"{stage}: in {si}, out {so}")
                                            except Exception:
                                                continue
                                        cum_dbg = usage.get("cumulative") or {}
                                        cin = int(cum_dbg.get("input_tokens", sum_in) or sum_in) if isinstance(cum_dbg, dict) else sum_in
                                        cout = int(cum_dbg.get("output_tokens", sum_out) or sum_out) if isinstance(cum_dbg, dict) else sum_out
                                        ctot = int(cum_dbg.get("total_tokens", cin + cout) or (cin + cout)) if isinstance(cum_dbg, dict) else (cin + cout)
                                        # Wording tweak: say "tool calls" instead of "provider steps" for clarity
                                        # Show only in verbose mode (silenced by default)
                                        if self.ui.verbose:
                                            self.ui.print(f"[raw] tool calls -> {'; '.join(parts)} | sum: in {cin} + out {cout} = {ctot}", style=self.ui.theme["dim"])
                                except Exception:
                                    pass
    
                                # Append assistant message with token stats to messages_for_save
                                if self.save_chat_history:
                                    try:
                                        self.messages_for_save.append({
                                            "role": "assistant",
                                            "content": "".join(assistant_buf),
                                            "model": model_used,
                                            "citations": None,
                                            "last_turn_input_tokens": int(turn_in),
                                            "last_turn_output_tokens": int(turn_out),
                                            "last_turn_total_tokens": int(turn_total),
                                        })
                                        if web_search_calls and self.messages_for_save:
                                            citations: List[Dict[str, Any]] = []
                                            for call in web_search_calls:
                                                action = call.get("action") if isinstance(call, dict) else None
                                                if isinstance(action, dict):
                                                    sources = action.get("sources")
                                                    if isinstance(sources, list):
                                                        for src in sources:
                                                            if isinstance(src, dict):
                                                                citations.append(src)
                                            if citations:
                                                self.messages_for_save[-1]["citations"] = citations
                                    except Exception:
                                        pass
    
                                # Log JSONL
                                self._log_line({
                                    "event": "usage",
                                    "model": model_used,
                                    "turn": {"in": turn_in, "out": turn_out, "total": turn_total},
                                    "cumulative": {"in": cum_in, "out": cum_out, "total": cum_total},
                                    "by_category": usage.get("by_category") or None,
                                    "cumulative_source": cum_source,
                                    "assistant_text_len": len("".join(assistant_buf)),
                                    "timing": {
                                        "turn_duration_ms": int(round(turn_secs * 1000.0)),
                                        "session_elapsed_ms": int(round(session_secs * 1000.0)),
                                        "tool_calls": int(tool_calls),
                                    },
                                    "web_search": web_search_calls or None,
                                })
                                self._log_line({
                                    "event": "assistant",
                                    "content": "".join(assistant_buf),
                                    "model": model_used,
                                    "thinking_insight": (
                                        thinking_insight_payload if isinstance(thinking_insight_payload, dict) else None
                                    ),
                                    "thinking_debug": (
                                        {
                                            "enabled": bool(self.thinking_insight_enabled),
                                            "has_summary": bool(thinking_has_summary),
                                            "label": thinking_label,
                                            "none_line": (thinking_none_line if not thinking_has_summary else None),
                                        }
                                        if bool(self.thinking_insight_enabled)
                                        else None
                                    ),
                                    "web_search": web_search_calls or None,
                                })
    
                                # Save to server threads (best-effort)
                                await self._save_conversation(client, selected_model=model_used)
    
                                # Optional category breakdown when --verbose
                                by_cat = usage.get("by_category") or {}
                                if self.ui.verbose and isinstance(by_cat, dict) and by_cat:
                                    order = ["read", "nav", "write", "exec"]
                                    rows: List[Tuple[str, int, int, int]] = []
                                    for k in order:
                                        v = by_cat.get(k)
                                        if not isinstance(v, dict):
                                            continue
                                        vin = int(v.get("input_tokens", 0) or 0)
                                        vout = int(v.get("output_tokens", 0) or 0)
                                        vtot = int(v.get("total_tokens", vin + vout) or 0)
                                        rows.append((k, vin, vout, vtot))
                                    for k, v in by_cat.items():
                                        if k in order or not isinstance(v, dict):
                                            continue
                                        vin = int(v.get("input_tokens", 0) or 0)
                                        vout = int(v.get("output_tokens", 0) or 0)
                                        vtot = int(v.get("total_tokens", vin + vout) or 0)
                                        rows.append((k, vin, vout, vtot))
                                    if rows:
                                        if self.ui.rich and Table:
                                            t = Table(title=None, show_lines=False, header_style=self.ui.theme["subtitle"])
                                            t.add_column("Category")
                                            t.add_column("Input", justify="right")
                                            t.add_column("Output", justify="right")
                                            t.add_column("Total", justify="right")
                                            for k, vin, vout, vtot in rows:
                                                t.add_row(k, str(vin), str(vout), str(vtot))
                                            self.ui.print("by_category:", style=self.ui.theme["dim"])
                                            self.ui.console.print(t)
                                        else:
                                            self.ui.print("by_category:", style=self.ui.theme["dim"])
                                            for k, vin, vout, vtot in rows:
                                                self.ui.print(f"  - {k}: in {vin}, out {vout}, tot {vtot}", style=self.ui.theme["dim"])
    
                                try:
                                    context_info = self._build_remote_control_context_info(model_used, usage)
                                    completed_payload = {
                                        "model": model_used,
                                        "text": "".join(assistant_buf),
                                        "usage": usage,
                                        "by_category": usage.get("by_category"),
                                        "billing": self._build_remote_control_billing_info(model_used),
                                        "function_logs": copy.deepcopy(self._current_turn.get("tool_events") or []),
                                        "thinking_insight": (
                                            thinking_insight_payload
                                            if isinstance(thinking_insight_payload, dict)
                                            else None
                                        ),
                                    }
                                    completed_payload.update(context_info)
                                    self._remote_last_completed = copy.deepcopy(completed_payload)
                                    await self._ws_broadcast(
                                        "message.completed",
                                        completed_payload,
                                    )
                                except Exception:
                                    pass
                                if isinstance(thinking_insight_payload, dict):
                                    try:
                                        await self._ws_broadcast("thinking.insight", thinking_insight_payload)
                                    except Exception:
                                        pass
                                if web_search_calls:
                                    try:
                                        await self._ws_broadcast("web_search.summary", {"model": model_used, "calls": web_search_calls})
                                    except Exception:
                                        pass
    
                                # Clear current turn tracking
                                try:
                                    self._current_turn = self._empty_current_turn()
                                except Exception:
                                    pass

                                try:
                                    await self._resume_busy_input_reader_after_output(final_prompt_restart)
                                except Exception:
                                    pass

                                return "".join(assistant_buf)
    
                            if event == "warning":
                                # Handle warning events (e.g., model swap with tools)
                                try:
                                    _tool_status_stop()
                                except Exception:
                                    pass
                                msg = data.get("message", "")
                                self.ui.warn(msg)
                                try:
                                    await self._ws_broadcast("warning", {"message": msg})
                                except Exception:
                                    pass
                                try:
                                    last_events.append({"event": "warning", "message": (msg[:160] if isinstance(msg, str) else str(msg))})
                                except Exception:
                                    pass
                                continue
    
                            elif event == "error":
                                try:
                                    _tool_status_stop()
                                except Exception:
                                    pass
                                # Stop and clear indicator before printing the error
                                try:
                                    await _indicator_stop(clear=True)
                                except Exception:
                                    pass
                                buf_str = "".join(assistant_buf)
                                self.ui.ensure_newline(buf_str)
                                err_msg = data.get("message", "Unknown error") or "Unknown error"
                                self.ui.error(err_msg)
                                try:
                                    last_error = True
                                except Exception:
                                    pass
                                streaming_assistant = False
                                # Heuristic: detect provider size-limit errors and mark next read_file on same path for tailing
                                try:
                                    em = str(err_msg).lower()
                                    too_long = (
                                        ("string too long" in em) or ("above_max_length" in em) or ("too long" in em and "input[0].output" in em)
                                    )
                                    if too_long and isinstance(self._last_dispatch_ctx, dict):
                                        if str(self._last_dispatch_ctx.get("name") or "") == "read_file":
                                            args_ctx = self._last_dispatch_ctx.get("args") or {}
                                            pth = args_ctx.get("path")
                                            if isinstance(pth, str) and pth:
                                                self._tail_next_paths.add(pth)
                                                self._auto_retry_after_tailed = True
                                                self.ui.warn(f"Provider refused large tool output; will tail next read of: {pth}")
                                except Exception:
                                    pass
                                try:
                                    await self._ws_broadcast("error", {"message": err_msg})
                                except Exception:
                                    pass
                                try:
                                    last_events.append({"event": "error", "message": (err_msg[:200] if isinstance(err_msg, str) else str(err_msg))})
                                except Exception:
                                    pass
                                return "".join(assistant_buf)
    
                            elif event == "thinking.insight":
                                try:
                                    if isinstance(data, dict):
                                        thinking_insight_payload = dict(data)
                                        self._current_turn["thinking_insight"] = dict(data)
                                except Exception:
                                    thinking_insight_payload = None
                                if self.thinking_insight_enabled:
                                    try:
                                        await _render_thinking_payload(
                                            thinking_insight_payload if isinstance(thinking_insight_payload, dict) else {},
                                            allow_none=True,
                                        )
                                    except Exception:
                                        pass
                                continue

                            elif event == "provider.message":
                                # Provider-native message snapshot (e.g., Kimi assistant with reasoning_content)
                                provider = (data.get("provider") or "").lower()
                                msg = data.get("message")
                                if provider == "gemini":
                                    # Always retain Gemini provider-native messages (needed for multi-turn tool calling).
                                    try:
                                        if isinstance(msg, dict):
                                            self._gemini_raw_history.append(dict(msg))
                                        elif isinstance(msg, list):
                                            self._gemini_raw_history.extend(self._normalize_gemini_raw_messages(msg))
                                    except Exception:
                                        pass
                                if provider == "kimi" and isinstance(msg, dict):
                                    # Append as-is to local raw history for the next turn
                                    try:
                                        self._kimi_raw_history.append(dict(msg))
                                    except Exception:
                                        try:
                                            self._kimi_raw_history.append(msg)  # type: ignore
                                        except Exception:
                                            pass
                                continue
    
                            else:
                                # TEMP DEBUG: show unknown/unhandled events
                                if DEBUG_SSE:
                                    self.ui.print(f"[debug] unhandled event: {event} payload={truncate_json(data, 800)}", style=self.ui.theme["dim"])
    
                    # If stream ended without a message.completed, render a fallback info box
                    try:
                        _tool_status_stop()
                    except Exception:
                        pass
                    # Ensure the indicator is stopped on abnormal termination and fully cleared
                    try:
                        await _indicator_stop(clear=True)
                    except Exception:
                        pass
                    # If cancelled via Ctrl+C, return *but* still show an estimated token/usage notice.
                    if self._stream_cancelled:
                        try:
                            # Attempt to compute turn duration if we have a start timestamp.
                            turn_secs = None
                            try:
                                now_pc = time.perf_counter()
                                turn_secs = self._turn_elapsed_seconds(now=now_pc, finalize=True)
                            except Exception:
                                turn_secs = None
                            self._render_cancelled_usage_notice(
                                model_label=(self._current_turn.get("model") if isinstance(self._current_turn, dict) else None),
                                est_completion_chars=int(model_output_chars or 0),
                                events_total=int(_events_total or 0),
                                deltas_total=int(_deltas_total or 0),
                                bytes_total=int(_bytes_total or 0),
                                tool_calls=int(tool_calls or 0),
                                turn_secs=turn_secs,
                            )
                        except Exception:
                            pass
                        return "".join(assistant_buf)
                    buf_str2 = "".join(assistant_buf)
                    self.ui.ensure_newline(buf_str2)
                    # Use a visible notice (non-dim) so users are aware something ended unexpectedly
                    self.ui.warn("Stream ended without a completed event (no usage reported)")
                    try:
                        if DEBUG_SSE or self.ui.verbose:
                            self.ui.print(
                                f"[debug] stream ended without completed (events={_events_total} deltas={_deltas_total} bytes={_bytes_total})",
                                style=self.ui.theme["dim"],
                            )
                    except Exception:
                        pass
                    # Diagnostic block when the server omits message.completed
                    try:
                        diag_lines_fb: List[str] = []
                        diag_lines_fb.append("Diagnostics: no message.completed event received — usage missing")
                        diag_lines_fb.append(f"- stream: events={_events_total}, deltas={_deltas_total}, bytes={_bytes_total}")
                        diag_lines_fb.append(f"- commit path: enabled={bool(self.server_usage_commit)} | session_id={'set' if session_id else 'missing'} | model={(self._current_turn.get('model') or self._last_used_model or self.model or '(server default)')}" )
                        # Summarize last events (up to 8)
                        try:
                            if last_events:
                                diag_lines_fb.append("- last events (most recent first):")
                                shown = list(last_events)[-8:][::-1]
                                for ev in shown:
                                    try:
                                        et = ev.get("event")
                                        if et == "message.delta":
                                            diag_lines_fb.append(f"  • message.delta bytes={ev.get('bytes')}")
                                        elif et in ("tool.call", "tool.result", "tool.dispatch"):
                                            base = f"  • {et} name={ev.get('name')}"
                                            if et != "tool.call":
                                                base += f" ok={ev.get('ok')}"
                                            diag_lines_fb.append(base)
                                        elif et in ("warning", "error"):
                                            diag_lines_fb.append(f"  • {et} {self._clip(ev.get('message'), 140)}")
                                        elif et == "session.started":
                                            diag_lines_fb.append(f"  • session.started level={ev.get('level')} scope={ev.get('fs_scope')}")
                                        else:
                                            diag_lines_fb.append(f"  • {et}")
                                    except Exception:
                                        continue
                        except Exception:
                            pass
                        # Show x-* response headers when present (can hint at proxy behavior)
                        try:
                            if sse_headers_diag:
                                diag_lines_fb.append("- response x-* headers:")
                                for k, v in sse_headers_diag.items():
                                    diag_lines_fb.append(f"  • {k}: {v}")
                        except Exception:
                            pass
                        # Render above the fallback Usage & Info box
                        try:
                            if self.ui.rich and Panel:
                                self.ui.console.print(Panel("\n".join(diag_lines_fb), title="Diagnostics (usage/cost)", border_style=self.ui.theme["warn"]))
                            else:
                                self.ui.print("Diagnostics (usage/cost):", style=self.ui.theme["warn"])  # type: ignore
                                for ln in diag_lines_fb:
                                    self.ui.print(ln, style=self.ui.theme["dim"])  # type: ignore
                        except Exception:
                            # Best-effort plain prints
                            self.ui.print("Diagnostics (usage/cost):")
                            for ln in diag_lines_fb:
                                self.ui.print(ln)
                        # Persist
                        try:
                            self._log_line({
                                "event": "diagnostics.no_completed",
                                "stream": {"events": _events_total, "deltas": _deltas_total, "bytes": _bytes_total},
                                "session_id": session_id,
                                "model": (self._current_turn.get('model') or self._last_used_model or self.model),
                                "resp_headers_x": sse_headers_diag or None,
                                "last_events": list(last_events) if last_events else None,
                            })
                        except Exception:
                            pass
                    except Exception:
                        pass
                    # Timing summary even if server omitted usage
                    try:
                        now_pc = time.perf_counter()
                        turn_secs = self._turn_elapsed_seconds(now=now_pc, finalize=True)
                        session_secs = self._session_elapsed_seconds(now=now_pc)
                    except Exception:
                        turn_secs = 0.0
                        session_secs = 0.0
                    def _fmt(sec: float) -> str:
                        try:
                            if sec < 60:
                                return f"{sec:.2f}s"
                            m, s = divmod(int(sec), 60)
                            if m < 60:
                                return f"{m}m {s}s"
                            h, m = divmod(m, 60)
                            return f"{h}h {m}m {s}s"
                        except Exception:
                            return f"{sec:.2f}s"

                    # Build a compact fallback Usage & Info box so users still see context
                    box_lines_fb: List[str] = []
                    context_line_fb: Optional[str] = None
                    # Version + update hint
                    try:
                        if not self._cli_version:
                            self._cli_version = self._resolve_current_version() or None
                        if self._cli_version:
                            ver_line = f"henosis-cli v{self._cli_version}"
                            if (self._version_outdated is True) and self._latest_version:
                                ver_line += f" → v{self._latest_version} available | update: {os.path.basename(sys.executable)} -m pip install -U henosis-cli"
                            box_lines_fb.append(ver_line)
                    except Exception:
                        pass
                    # Model/cost line (costs remain at previous totals since no usage was reported)
                    try:
                        # Prefer the most accurate model label we saw this turn
                        model_label = (self._current_turn.get("model") or self._last_used_model or self.model or "(server default)")
                    except Exception:
                        model_label = self.model or "(server default)"
                    # Reasoning effort tag for OpenAI reasoning models
                    try:
                        effort_seg = ""
                        if self._is_openai_reasoning_model(model_label):
                            lvl = str(self.reasoning_effort or "medium").strip().lower()
                            if lvl not in ("low", "medium", "high", "xhigh"):
                                lvl = "medium"
                            disp = {"low": "Low", "medium": "Medium", "high": "High", "xhigh": "XHigh"}.get(lvl, "Medium")
                            effort_seg = f" {disp}"
                    except Exception:
                        effort_seg = ""
                    try:
                        rem_line = (
                            f" | remaining credits: ${float(self._last_remaining_credits):.6f}"
                            if (self._last_remaining_credits is not None)
                            else ""
                        )
                    except Exception:
                        rem_line = ""
                    model_only_fb = f"model: {model_label}{effort_seg}"
                    box_lines_fb.append(
                        f"model: {model_label}{effort_seg} | cost charged: ${float(self._last_commit_cost_usd):.6f} | chat cost: ${float(self.server_cumulative_cost_usd):.6f}{rem_line}"
                    )
                    # Tokens unknown without completed usage; show zeros to signal missing metrics
                    box_lines_fb.append("Turn tokens: in 0 + out 0 = 0")
                    try:
                        cin = int(self._cum_input_tokens or 0)
                        cout = int(self._cum_output_tokens or 0)
                        ctot = int(self._cum_total_tokens or (cin + cout))
                    except Exception:
                        cin, cout, ctot = 0, 0, 0
                    box_lines_fb.append(f"Session tokens: in {cin} + out {cout} = {ctot}")
                    box_lines_fb.append(f"Time: {_fmt(turn_secs)} (turn) | {_fmt(session_secs)} (session) | Tools: {tool_calls} call(s)")
                    # Context bar (0 when usage missing)
                    try:
                        if self.ui.rich:
                            bar = "[" + f"[{self.ui.theme['dim']}]{'░'*30}[/{self.ui.theme['dim']}]" + "]"
                        else:
                            bar = "[" + ("-" * 30) + "]"
                        box_lines_fb.append(f"Context: 0 {bar} 0.0%")
                    except Exception:
                        pass
                    # Extract context line for concise mode if not already captured
                    if context_line_fb is None:
                        try:
                            for _ln in reversed(box_lines_fb):
                                if isinstance(_ln, str) and _ln.startswith("Context: "):
                                    context_line_fb = _ln
                                    break
                        except Exception:
                            context_line_fb = None
                    # Final render
                    try:
                        # Prefer Issue #15 renderer when available.
                        try:
                            context_meter = None
                            if context_line_fb and isinstance(context_line_fb, str) and ":" in context_line_fb:
                                _, tail = context_line_fb.split(":", 1)
                                parts = tail.strip().split()
                                total_val = int(parts[0]) if parts and parts[0].isdigit() else 0
                                pct_val = 0.0
                                if parts and isinstance(parts[-1], str) and parts[-1].endswith("%"): 
                                    try:
                                        pct_val = float(parts[-1][:-1])
                                    except Exception:
                                        pct_val = 0.0
                                bar_width = 30
                                filled = int(round((pct_val / 100.0) * bar_width))
                                empty = max(0, bar_width - filled)
                                context_meter = {"tokens": total_val, "pct": float(pct_val), "filled": int(filled), "empty": int(empty)}
                            status_ctx_fb = {
                                "session_id": session_id,
                                "model_used": model_label,
                                "effort_disp": effort_seg,
                                "tool_calls": tool_calls,
                                "cli_version_line": (box_lines_fb[0] if (box_lines_fb and isinstance(box_lines_fb[0], str) and box_lines_fb[0].startswith("henosis-cli")) else None),
                                "billing_line": None,
                                "turn_tokens_line": None,
                                "session_tokens_line": None,
                                "timing_line": None,
                                "web_search_line": None,
                                "prompt_cache_lines": [],
                                "context_meter": context_meter,
                                "context_meter_panel": context_line_fb,
                                "context_pct": (float(context_meter.get("pct")) if isinstance(context_meter, dict) and ("pct" in context_meter) else None),
                                "context_window": None,
                                "context_window_known": False,
                                "cum_in": cin,
                                "cum_out": cout,
                                "cum_total": ctot,
                            }
                            try:
                                for _ln in box_lines_fb:
                                    if isinstance(_ln, str) and _ln.startswith("model:") and "cost charged" in _ln:
                                        status_ctx_fb["billing_line"] = _ln
                                    elif isinstance(_ln, str) and _ln.startswith("Turn tokens:"):
                                        status_ctx_fb["turn_tokens_line"] = _ln
                                    elif isinstance(_ln, str) and _ln.startswith("Session tokens:"):
                                        status_ctx_fb["session_tokens_line"] = _ln
                                    elif isinstance(_ln, str) and _ln.startswith("Time:"):
                                        status_ctx_fb["timing_line"] = _ln
                            except Exception:
                                pass
                            self._render_status_info(status_ctx_fb)
                        except Exception:
                            # Legacy fallback
                            if str(getattr(self, 'usage_info_mode', 'verbose')).lower() == 'concise':
                                if context_line_fb:
                                    try:
                                        if ":" in context_line_fb:
                                            _, tail = context_line_fb.split(":", 1)
                                            self.ui.print("tokens used:", style="white", end="")
                                            self.ui.print(tail)
                                        else:
                                            self.ui.print(context_line_fb, style="white")
                                    except Exception:
                                        self.ui.print(context_line_fb, style="white")
                            else:
                                self.ui.info_box("Usage & Info", box_lines_fb)
                    except Exception:
                        # Fallback to a single-line time summary if box fails
                        self.ui.print(
                            f"[time] turn: {_fmt(turn_secs)} | session: {_fmt(session_secs)} | tools: {tool_calls} call(s)",
                            style=self.ui.theme["dim"],
                            force=True,
                        )
                    try:
                        self._remote_last_completed = {
                            "model": self.model,
                            "text": "".join(assistant_buf),
                            "usage": {},
                            "by_category": {},
                            "function_logs": copy.deepcopy(self._current_turn.get("tool_events") or []),
                            "thinking_insight": copy.deepcopy(self._current_turn.get("thinking_insight"))
                            if isinstance(self._current_turn.get("thinking_insight"), dict)
                            else None,
                        }
                        await self._ws_broadcast(
                            "message.completed",
                            {
                                "model": self.model,
                                "text": "".join(assistant_buf),
                                "usage": {},
                                "by_category": {},
                                "function_logs": copy.deepcopy(self._current_turn.get("tool_events") or []),
                                "thinking_insight": copy.deepcopy(self._current_turn.get("thinking_insight"))
                                if isinstance(self._current_turn.get("thinking_insight"), dict)
                                else None,
                            },
                        )
                    except Exception:
                        pass
                    return "".join(assistant_buf)
        try:
                # Per-turn retry controller: up to 3 total attempts (original + 2 retries)
                attempts_done = 1
                # Flags shared with do_stream
                last_completed = False
                last_error = False
                last_bytes_total = 0
                result_text = await do_stream(payload)

                # If we marked an auto-retry due to provider output size limits, retry once using the same payload
                if self._auto_retry_after_tailed and not self._stream_cancelled:
                    self._auto_retry_after_tailed = False
                    self.ui.warn("Retrying turn with tailed file content due to provider output size limit...")
                    return await do_stream(payload)

                # Generic retry: when stream ended without a message.completed, retry the last model turn
                max_attempts = 3
                while (not last_completed) and (not self._stream_cancelled) and (attempts_done < max_attempts):
                    attempts_done += 1
                    # Emit CLI/WS notice
                    try:
                        self.ui.print(f"[retry] restarting last model turn (attempt {attempts_done}/{max_attempts}) …", style=self.ui.theme["info"])  # type: ignore
                        await self._ws_broadcast("retry.notice", {"attempt": attempts_done, "max_attempts": max_attempts})
                        # Persist a brief log line
                        self._log_line({
                            "event": "retry.attempt",
                            "attempt": int(attempts_done),
                            "max": int(max_attempts),
                            "bytes_prev_attempt": int(last_bytes_total),
                            "completed_prev_attempt": bool(last_completed),
                            "had_error_prev_attempt": bool(last_error),
                            "idempotency_key": idempotency_key,
                        })
                        if self.raw_log_enabled:
                            self._rawlog_write(f"[retry] attempt {attempts_done}/{max_attempts} idemp={idempotency_key} prev_bytes={last_bytes_total} completed={last_completed} error={last_error}")
                    except Exception:
                        pass
                    # Reset local stream buffers so we don't prefill or suppress headers on new attempt
                    try:
                        assistant_buf = []
                        header_printed = False
                        session_id = None
                    except Exception:
                        pass
                    # Reset per-attempt flags before calling do_stream again
                    last_completed = False
                    last_error = False
                    last_bytes_total = 0
                    result_text = await do_stream(payload)

                # If still not completed after retries, emit a final failure notice
                if not last_completed and not self._stream_cancelled:
                    try:
                        self.ui.print(f"[retry] failed after {attempts_done} attempt(s)", style=self.ui.theme["warn"])  # type: ignore
                        await self._ws_broadcast("retry.failed", {"attempts": attempts_done, "max_attempts": max_attempts})
                        self._log_line({
                            "event": "retry.give_up",
                            "attempts": int(attempts_done),
                            "max": int(max_attempts),
                            "bytes_last_attempt": int(last_bytes_total),
                            "idempotency_key": idempotency_key,
                        })
                        if self.raw_log_enabled:
                            self._rawlog_write(f"[retry] give up after {attempts_done}/{max_attempts} attempts idemp={idempotency_key} last_bytes={last_bytes_total}")
                    except Exception:
                        pass
                return result_text

        except httpx.HTTPStatusError as he:
            status = he.response.status_code if he.response is not None else None
            # Try to refresh auth on 401 and retry once
            if status == 401:
                try:
                    async with httpx.AsyncClient(timeout=http_timeout, cookies=self.cookies) as client:
                        r = await client.post(self.refresh_url)
                        if r.status_code == 200:
                            # Persist rotated tokens if rotation occurred
                            try:
                                refresh_data = r.json()
                                if refresh_data.get('rotated'):
                                    self._save_auth_state_to_disk()
                            except Exception:
                                pass
                            try:
                                return await do_stream(payload)
                            except Exception:
                                pass
                except Exception:
                    pass
            # If refresh failed, offer a quick re-login flow for better UX
            try:
                self.ui.warn("Your session has expired. Let's refresh your login.")
                ok = await self._login_with_retries()
                if ok:
                    try:
                        return await do_stream(payload)
                    except Exception:
                        pass
            except SystemExit:
                raise
            except Exception:
                pass
            raw_text = ""
            body_json: Any = None
            try:
                if he.response is not None:
                    await he.response.aread()
                    raw_text = he.response.text
                    ctype = he.response.headers.get("content-type", "")
                    if "application/json" in ctype.lower() and raw_text:
                        body_json = json.loads(raw_text)
            except Exception:
                body_json = None
            # Friendly header
            self.ui.warn(f"HTTP {status} received from server. Context:")
            self.ui.print(f"- Endpoint: {self.stream_url}", style=self.ui.theme["dim"])
            self.ui.print(f"- Model: {self.model or '(server default)'}", style=self.ui.theme["dim"])
            # Provider guess from model
            provider = "unknown"
            try:
                m = (self.model or "").lower() if self.model else ""
                if m.startswith("gemini-"):
                    provider = "gemini"
                elif m.startswith("grok-"):
                    provider = "xai"
                elif m.startswith("deepseek-"):
                    provider = "deepseek"
                elif m.startswith("kimi-"):
                    provider = "kimi"
                elif m.startswith("claude-"):
                    provider = "anthropic"
                elif m:
                    provider = "openai"
            except Exception:
                provider = "unknown"
            if provider != "unknown":
                self.ui.print(f"- Provider: {provider}", style=self.ui.theme["dim"])
            # Show parsed JSON error details when possible
            if isinstance(body_json, dict):
                detail = body_json.get("detail")
                error_type = body_json.get("error") or body_json.get("type")
                if error_type:
                    self.ui.error(f"{error_type}")
                if detail:
                    self.ui.print(truncate_json(detail, 1500), style=self.ui.theme["dim"])
            else:
                if raw_text:
                    self.ui.print(self._clip(raw_text, 4000), style=self.ui.theme["dim"])
                else:
                    self.ui.print("(no response text available)", style=self.ui.theme["dim"])
            # Heuristics and suggested fixes
            tips: List[str] = []
            body_lower = (raw_text or "").lower()
            if provider == "gemini" and ("gemini_api_key" in body_lower or ("gemini" in body_lower and "key" in body_lower)):
                tips.append("Set GEMINI_API_KEY in the server .env (no quotes) and restart the server.")
                tips.append("Ensure google-genai is installed: pip install google-genai")
            if provider == "anthropic" and ("anthropic_api_key" in body_lower or ("anthropic" in body_lower and "key" in body_lower)):
                tips.append("Set ANTHROPIC_API_KEY in the server .env and restart.")
                tips.append("Install anthropic: pip install anthropic")
            if provider == "xai" and ("xai_api_key" in body_lower or "x.ai" in body_lower):
                tips.append("Set XAI_API_KEY in the server .env and restart.")
            if provider == "deepseek" and ("deepseek_api_key" in body_lower or "deepseek" in body_lower):
                tips.append("Set DEEPSEEK_API_KEY in the server .env and restart.")
            if provider == "kimi" and ("kimi_api_key" in body_lower or "moonshot" in body_lower or "kimi" in body_lower):
                tips.append("Set KIMI_API_KEY in the server .env and restart.")
            if "not installed" in body_lower or "module not found" in body_lower:
                tips.append("Install missing provider SDK on the server environment.")
            if tips:
                self.ui.print("Possible fixes:")
                for t in tips:
                    self.ui.print(f"- {t}", style=self.ui.theme["dim"])
            # Best-effort: query /health for quick diagnostics
            try:
                health_url = join_url(self.server, "/health")
                async with httpx.AsyncClient(timeout=self.timeout, cookies=self.cookies) as hc:
                    h = await hc.get(health_url)
                    if h.status_code == 200 and "application/json" in (h.headers.get("content-type", "")):
                        hjson = h.json()
                        tools_enabled = hjson.get("tools_enabled")
                        workspace = hjson.get("workspace")
                        version = hjson.get("version") or hjson.get("status")
                        self.ui.print(f"- /health: tools_enabled={tools_enabled}, workspace={workspace}, version={version}", style=self.ui.theme["dim"])
            except Exception:
                pass
            # Log to the session log file
            try:
                self._log_line({
                    "event": "http_error",
                    "status": int(status) if status else 0,
                    "body": body_json if isinstance(body_json, dict) else self._clip(raw_text, 4000),
                    "provider": provider,
                    "model": self.model,
                    "endpoint": self.stream_url,
                })
            except Exception:
                pass
            # Raw log the HTTP error as well
            try:
                if self.raw_log_enabled:
                    self._rawlog_write(f"<<< HTTP {status} ERROR from {self.stream_url}")
                    if isinstance(body_json, dict):
                        self._rawlog_write_json(body_json)
                    elif raw_text:
                        # Write raw body text if not JSON
                        self._rawlog_write(raw_text[:4000])
            except Exception:
                pass
            # Do not re-raise; return empty to keep caller logic simple
            return ""

        # Fallback return (should not reach)
        return ""

    # ----------------------- Model context helpers ----------------------
    def _load_model_ctx_map(self) -> Dict[str, int]:
        """Load mapping of model -> input context length (tokens) from models.txt when available.
        Falls back to a small built-in map for common models if parsing fails.
        """
        if isinstance(getattr(self, "_model_ctx_map", None), dict):
            return self._model_ctx_map  # type: ignore
        ctx_map: Dict[str, int] = {}
        # Try to locate models.txt near this script or in current working directory
        candidates: List[Path] = []
        try:
            candidates.append(Path(__file__).resolve().parent / "models.txt")
        except Exception:
            pass
        try:
            candidates.append(Path(os.getcwd()) / "models.txt")
        except Exception:
            pass
        text: Optional[str] = None
        for p in candidates:
            try:
                if p.exists():
                    text = p.read_text(encoding="utf-8", errors="ignore")
                    break
            except Exception:
                continue
        if text:
            try:
                import re
                # Match entries like: { value: 'model', ... inputContextLength: 123456, ... }
                entry_pattern = re.compile(r"\{[^}]*?value:\s*'([^']+)'[^}]*?inputContextLength:\s*(null|\d+)[^}]*?\}", re.DOTALL)
                for m in entry_pattern.finditer(text):
                    model = m.group(1)
                    val = m.group(2)
                    if val and val.isdigit():
                        ctx_map[model] = int(val)
            except Exception:
                pass
        # Fallback defaults for common models
        if not ctx_map:
            try:
                ctx_map.update({
                    "gpt-5.4": 1000000,
                    "gpt-5.4-pro": 1000000,
                    "gpt-5.4-mini-2026-03-17": 400000,
                    "gpt-5.4-nano-2026-03-17": 400000,
                    "gpt-5": 400000,
                    "gpt-5.3": 400000,
                    "gpt-5-2025-08-07": 400000,
                    "gpt-5.3-codex": 400000,
                    "gpt-5-codex": 400000,
                    "codex-mini-latest": 200000,
                    # (removed gemini-2.5-pro)
                    "gemini-3-flash-preview": 1048576,
                    "gemini-3.1-pro-preview": 1000000,
                    "grok-4-1-fast-reasoning": 2000000,
                    "grok-4-1-fast-non-reasoning": 2000000,
                    "grok-4.20-multi-agent-beta-0309": 2000000,
                    "grok-4.20-beta-0309-reasoning": 2000000,
                    "grok-4": 200000,
                    "grok-code-fast-1": 262144,
                    "deepseek-chat": 128000,
                    "deepseek-reasoner": 128000,
                    "kimi-k2.5": 262144,
                    "claude-sonnet-4-20250514": 1000000,
                    "claude-sonnet-4-20250514-thinking": 1000000,
                    "claude-sonnet-4-6": 1000000,
                    "claude-sonnet-4-6-thinking": 1000000,
                    "claude-opus-4-6": 1000000,
                    "claude-opus-4-6-thinking": 1000000,
                    "glm-4.7": 200000,
                })
            except Exception:
                pass
        self._model_ctx_map = ctx_map
        return ctx_map

    def _get_model_ctx_window(self, model: Optional[str]) -> Optional[int]:
        """Return input context length for model if known; respects explicit ctx_window override."""
        try:
            if isinstance(self.ctx_window, int) and self.ctx_window > 0:
                return int(self.ctx_window)
        except Exception:
            pass
        if not model:
            return None
        model = self._resolve_model_alias(model) or model
        cmap = self._load_model_ctx_map()
        if model in cmap:
            return cmap[model]
        lm = model.lower()
        for k, v in cmap.items():
            try:
                if k.lower() == lm:
                    return v
            except Exception:
                continue
        return None

    # --------------------- Tier-aware defaults -------------------------

    def _recommended_default_model(self) -> str:
        """Return the tier-aware recommended default model.

        - Free-tier users: recommend Kimi k2.5.
        - All other users: recommend gpt-5.4 (best overall default).
        When tier is unknown, fall back to gpt-5.4.
        """
        try:
            if bool(self.is_free_tier):
                return "kimi-k2.5"
        except Exception:
            pass
        return "gpt-5.4"

    # --------------------- Onboarding and Welcome ---------------------
    async def _welcome_flow(self) -> None:
        # Render a friendly welcome screen and drive actions via a selectable menu
        self.ui.clear()
        if self.ui.rich and Panel:
            body = (
                "The command-line interface for Henosis Chat. You can:\n"
                "- Chat with multiple providers (OpenAI, Gemini, xAI, DeepSeek, Anthropic, Kimi)\n"
                "- Let the agent read and modify files within a selected Agent scope\n"
                "- Save threads, track usage/costs, and manage approvals"
            )
            self.ui.console.print(
                Panel(body, title="Welcome to henosis-cli", border_style=self.ui.theme["subtitle"])
            )
        else:
            self.ui.header("Welcome to henosis-cli")
            self.ui.print("- Multi-provider chat with optional file tools")
            self.ui.print("- Agent scope to safely limit local file access")
            self.ui.print("- Threads and usage tracking with approvals")

        while True:
            choice = await self._menu_choice(
                "Get started",
                "Choose how you’d like to get started:",
                [
                    ("login", "Login"),
                    ("register", "Register"),
                    ("codex_login", "Codex Login"),
                    ("quit", "Quit"),
                ],
            )
            if choice == "login":
                ok = await self._login_with_retries()
                if ok:
                    return
                # If login failed or was canceled, loop back to the menu
            elif choice == "register":
                await self.register()
                # After registration, loop back so the user can pick Login or Quit
            elif choice == "codex_login":
                ok = await self._codex_login()
                if ok:
                    return
            elif choice in ("quit", None):
                raise SystemExit(0)

    async def register(self) -> bool:
        """Registration path. Attempts CLI-native register if server supports; otherwise prints web URL."""
        web_url = "https://henosis.us/register"
        # Ask user which path (menu-based, no Y/N typing)
        choice = await self._menu_choice(
            "Registration",
            "How would you like to register?",
            [
                ("web", "Open web signup URL in your browser (recommended)"),
                ("cli", "Use CLI-native registration in this terminal"),
                ("cancel", "Cancel registration"),
            ],
        )
        if choice in (None, "cancel"):
            self.ui.info(f"You can register on the web at: {web_url}")
            return False
        if choice == "web":
            self.ui.info(f"Register on the web: {web_url}\nReturn here and choose Login when done.")
            return False
        # CLI-native attempt
        try:
            username = self.ui.prompt("Choose a username")
            email = self.ui.prompt("Email")
            password = getpass.getpass("Password (will be sent to server over HTTPS): ")
            payload = {"username": username, "email": email, "password": password}
            timeout = httpx.Timeout(connect=10.0, read=30.0, write=10.0, pool=10.0) if self.timeout is None else httpx.Timeout(self.timeout)
            async with httpx.AsyncClient(timeout=timeout) as client:
                r = await client.post(self.register_url, json=payload)
                if r.status_code >= 400:
                    self.ui.warn(f"Register returned {r.status_code}: {r.text}")
                    self.ui.info(f"You can register on the web instead: {web_url}")
                    return False
                # Dev mode: skip email verification flow in CLI
                # Some servers auto-login after registration; attempt a login to finalize the flow.
                # If server still enforces verification, the login may fail, but we won't prompt for a code.
                self.ui.success("Registration successful (dev mode: skipping email verification step).")
                try:
                    lr = await client.post(self.login_url, json={"username": username, "password": password, "remember_me": True})
                    if lr.status_code < 400:
                        # Copy cookies into CLI session and confirm auth if possible
                        self.cookies.update(lr.cookies)
                        try:
                            chk = await client.get(self.check_auth_url, cookies=self.cookies)
                            if chk.status_code == 200 and (chk.headers.get("content-type", "").startswith("application/json")):
                                data = chk.json()
                                if data.get("authenticated"):
                                    self.auth_user = str(data.get("user") or username)
                                    self._save_auth_state_to_disk()
                                    self.ui.success(f"Logged in as {self.auth_user}.")
                                    return True
                        except Exception:
                            pass
                        # If no check-auth, still consider registration done; user can /login manually
                        self.ui.info("You can now run /login to start chatting.")
                        return True
                    else:
                        # If login failed (likely because server requires verification), just finish here
                        self.ui.info("Registration complete. If your server requires email verification, complete it in the web UI, then /login.")
                        return True
                except Exception:
                    # Best-effort: finish registration without auto-login
                    self.ui.info("Registration complete. Run /login to sign in.")
                    return True
        except Exception as e:
            self.ui.warn(f"Registration not available: {e}\nUse the web: {web_url}")
            return False

    async def _login_with_retries(self, max_attempts: int = 3) -> bool:
        attempts = 0
        while attempts < max_attempts:
            ok, fatal = await self._login_once_allow_retry()
            if ok:
                return True
            if fatal:
                # do not retry
                break
            attempts += 1
            if attempts < max_attempts:
                # Menu-based retry choice instead of Y/N typing
                choice = await self._menu_choice(
                    "Login failed",
                    "Invalid username or password.",
                    [
                        ("retry", f"Try again ({attempts}/{max_attempts} attempts used)"),
                        ("stop", "Stop trying for now"),
                    ],
                )
                if choice != "retry":
                    break
        # Offer next steps via menu (register / login again / return)
        self.ui.print("Login not successful.")
        choice = await self._menu_choice(
            "Login not successful",
            "What would you like to do?",
            [
                ("register", "Register for an account"),
                ("login", "Try logging in again"),
                ("back", "Return to the previous menu"),
            ],
        )
        if choice == "register":
            await self.register()
            return False
        if choice == "login":
            return await self._login_with_retries(max_attempts)
        return False

    async def _login_once_allow_retry(self) -> Tuple[bool, bool]:
        """Perform a single login attempt. Returns (ok, fatal). Fatal means don't retry."""
        try:
            username = self.ui.prompt("Username")
            password = getpass.getpass("Password: ")
            # Menu-based choice instead of Y/N typing
            stay_choice = await self._menu_choice(
                "Stay logged in?",
                "Do you want to stay logged in on this machine (device-bound refresh tokens)?",
                [
                    ("yes", "Yes - keep me logged in"),
                    ("no", "No - only this session"),
                ],
            )
            stay_logged_in = (stay_choice != "no")
            if stay_logged_in and not self.device_id:
                try:
                    self._load_auth_state_from_disk()
                except Exception:
                    pass
                if not self.device_id:
                    self.device_id = uuid.uuid4().hex
            if self.timeout is None:
                http_timeout = httpx.Timeout(connect=10.0, read=None, write=10.0, pool=10.0)
            else:
                http_timeout = httpx.Timeout(self.timeout)
            async with httpx.AsyncClient(timeout=http_timeout, cookies=self.cookies) as client:
                body = {"username": username, "password": password, "remember_me": bool(stay_logged_in)}
                if stay_logged_in and self.device_id:
                    body.update({"device_id": self.device_id, "device_name": self.device_name or f"{socket.gethostname()} cli"})
                resp = await client.post(self.login_url, json=body)
                if resp.status_code >= 400:
                    raw_text = ""
                    try:
                        b = await resp.aread(); raw_text = b.decode("utf-8", errors="replace")
                    except Exception:
                        raw_text = resp.text
                    detail = None
                    try:
                        j = json.loads(raw_text) if raw_text else {}
                        if isinstance(j, dict):
                            detail = j.get("detail")
                    except Exception:
                        detail = None
                    if resp.status_code == 401 and isinstance(detail, str) and detail.lower() == "invalid username or password":
                        # Non-fatal invalid creds; allow retry
                        self.ui.warn("Invalid username or password.")
                        return False, False
                    self.ui.warn(f"Login failed: {resp.status_code} {raw_text}")
                    return False, False
                self.cookies.update(resp.cookies)
                try:
                    chk = await client.get(self.check_auth_url)
                    if chk.status_code == 200:
                        data = chk.json()
                        if data.get("authenticated"):
                            self.auth_user = str(data.get("user") or username)
                            self.ui.success(f"Login successful. Authenticated as: {self.auth_user}")
                            if stay_logged_in:
                                self._save_auth_state_to_disk()
                            else:
                                self._clear_auth_state_on_disk()
                            return True, True
                except Exception:
                    pass
                # Consider success if no check-auth
                self.ui.success("Login successful.")
                if stay_logged_in:
                    self._save_auth_state_to_disk()
                else:
                    self._clear_auth_state_on_disk()
                return True, True
        except Exception as e:
            self.ui.error(f"Login error: {e}")
            return False, True

    async def _wizard_model_step(self) -> None:
        """First-time wizard: pick the default model via the full picker."""
        self.ui.print("Please select a default model for new chats.")
        await self.select_model_menu()

    async def _wizard_anthropic_effort_step(self) -> None:
        """First-time wizard: choose Anthropic effort (Opus 4.6/Sonnet 4.6/Opus 4.5).

        Per opus4-6.txt:
          - default effort is "high"
          - effort "max" is Opus 4.6 only
        """
        try:
            model = str(self.model or "")
        except Exception:
            model = ""
        base = model[:-9] if model.endswith("-thinking") else model
        # Only prompt when it matters.
        if base not in ("claude-opus-4-6", "claude-sonnet-4-6"):
            # Default behavior equals high.
            try:
                if not getattr(self, "anthropic_effort", None):
                    self.anthropic_effort = "high"
            except Exception:
                self.anthropic_effort = "high"
            return

        try:
            cur = str(getattr(self, "anthropic_effort", "high") or "high").strip().lower()
        except Exception:
            cur = "high"
        if cur not in ("low", "medium", "high", "max"):
            cur = "high"

        choices: List[Tuple[str, str]] = [
            ("high", "High (default)"),
            ("medium", "Medium"),
            ("low", "Low"),
        ]
        if base == "claude-opus-4-6":
            choices.append(("max", "Max (Opus 4.6 only)"))

        sel = await self._menu_choice(
            "Anthropic effort",
            "How thoroughly should Claude respond by default?",
            choices,
        )
        if sel in ("low", "medium", "high", "max"):
            # Guard: max is Opus 4.6 only
            if sel == "max" and base != "claude-opus-4-6":
                self.anthropic_effort = "high"
            else:
                self.anthropic_effort = sel
        else:
            self.anthropic_effort = cur or "high"

    async def _wizard_agent_scope_step(self) -> None:
        """First-time wizard: choose Agent scope root and mode via menus.

        Only asks user to type when 'custom path' is selected.
        """
        try:
            cwd = os.getcwd()
        except Exception:
            cwd = ""

        # 1) Where should the Agent scope root live?
        scope_choices: List[Tuple[str, str]] = []
        if cwd:
            scope_choices.append(("cwd", f"Use current directory ({cwd}) as Agent scope"))
        scope_choices.append(("custom", "Enter a different absolute path"))
        scope_choices.append(("workspace-only", "Skip Agent scope; use workspace sandbox only"))

        scope_val = await self._menu_choice(
            "Agent scope root",
            "Choose where the agent is allowed to operate when host scope is enabled:",
            scope_choices,
        )

        chosen_scope_root: Optional[str] = None
        if scope_val == "cwd" and cwd:
            chosen_scope_root = cwd
        elif scope_val == "custom":
            # This is the only place we require typing for Agent scope.
            path = self.ui.prompt(
                "Enter absolute path for Agent scope (leave blank to cancel)",
                default=self.host_base or "",
            )
            if path.strip():
                chosen_scope_root = path.strip()
        elif scope_val == "workspace-only":
            chosen_scope_root = None  # handled below

        # Fallback: if still unset and cwd is available, use cwd
        if chosen_scope_root is None and cwd:
            chosen_scope_root = cwd

        if chosen_scope_root:
            self.host_base = chosen_scope_root
            self._host_base_ephemeral = False
        else:
            self.host_base = None

        # 2) How much of that directory is accessible?
        if self.host_base:
            # Full vs ./workspace inside that root
            scope_mode = await self._menu_choice(
                "Agent scope mode",
                (
                    "We recommend granting access to the entire Agent scope directory.\n"
                    "Alternatively, you can restrict access to a 'workspace' folder inside it."
                ),
                [
                    ("full", "Full Agent scope (recommended)"),
                    ("workspace", "Restrict to ./workspace subfolder inside Agent scope"),
                ],
            )
            if scope_mode == "workspace":
                try:
                    ws_path = os.path.join(self.host_base, "workspace")
                    os.makedirs(ws_path, exist_ok=True)
                    self.host_base = ws_path
                    self._host_base_ephemeral = False
                    self.fs_host_mode = "custom"
                    self.fs_scope = "host"
                    self.ui.info(f"Restricted Agent scope to workspace folder: {ws_path}")
                except Exception as e:
                    self.ui.warn(
                        f"Failed to prepare workspace folder; using full Agent scope. ({e})"
                    )
                    self.fs_host_mode = "custom"
                    self.fs_scope = "host"
            else:
                # full or cancel → treat as full Agent scope but constrained to that root
                self.fs_host_mode = "custom"
                self.fs_scope = "host"
        else:
            # No Agent scope root selected: default to workspace scope
            self.fs_scope = "workspace"

        # Refresh code map source based on the final host_base
        try:
            self._codebase_map_raw = self._load_codebase_map_raw()
        except Exception:
            pass

        # Prompt once during configuration when a local AGENTS.md differs.
        try:
            await self._maybe_prompt_agents_prepend_mode(trigger="wizard")
        except Exception:
            pass

        # Ensure AGENTS.md exists on disk at the chosen host_base (create or prepend defaults).
        try:
            await self._ensure_agents_md_on_disk(trigger="wizard")
        except Exception:
            pass

        self.save_settings()

    async def _maybe_run_first_time_wizard(self, force: bool = False) -> None:
        # Determine if key settings are at defaults
        needs = (
            (self.model is None)
            or (self.requested_tools is None)
            or (self.fs_scope is None)
            or (self.control_level is None)
            or (not self.host_base)
        )
        try:
            self.ui.debug_log(
                f"[wizard-cli] maybe_run_first_time_wizard force={force} needs={needs} "
                f"model={self.model!r} tools={self.requested_tools!r} fs_scope={self.fs_scope!r} "
                f"level={self.control_level!r} host_base={self.host_base!r}"
            )
        except Exception:
            pass
        if not force and not needs:
            return

        self.ui.header(
            "First-time setup",
            "We’ll configure a few defaults. You can change these later via /settings.",
        )

        # --- 1) Default model (menu) ---
        await self._wizard_model_step()
        # If the picker was cancelled (or model still unset), choose a sensible default.
        if not self.model:
            self.model = self._recommended_default_model()

        # --- 1b) Anthropic effort (Opus 4.6 / Sonnet 4.6 / Opus 4.5) ---
        await self._wizard_anthropic_effort_step()

        # --- 2) Tools (always ON per design) ---
        self.requested_tools = True

        # --- 3) Control level (menu) ---
        self.ui.print(
            "Control levels: 1=read-only, 2=approval on write/exec, 3=no approvals"
        )
        await self.set_level_menu()
        if self.control_level not in (1, 2, 3):
            # Default to Level 3 if user aborted
            self.control_level = 3

        # --- 4) Agent scope (menus; only type on custom path) ---
        self.ui.print(
            "Agent scope is the local directory tree the agent can access when host scope is enabled."
        )
        await self._wizard_agent_scope_step()

        # --- 5) Code map injection & generation (menus) ---
        code_map_choice = await self._menu_choice(
            "Codebase map",
            (
                "CODEBASE_MAP.md is a short overview of your project that can be prefixed to "
                "your first message to help the agent understand the codebase."
            ),
            [
                (
                    "inject-generate",
                    "Inject the codebase map and generate CODEBASE_MAP.md now if missing (recommended)",
                ),
                (
                    "inject-only",
                    "Inject the codebase map when present, but do not auto-generate",
                ),
                ("off", "Do not inject CODEBASE_MAP.md"),
            ],
        )

        if code_map_choice == "off":
            self.inject_codebase_map = False
        else:
            self.inject_codebase_map = True
            # If we have an Agent scope and no map, optionally generate it now
            if (
                code_map_choice == "inject-generate"
                and self.host_base
                and not self._code_map_exists_at(self.host_base)
            ):
                # This is an action, not another question: user already selected it.
                await self._generate_code_map_for(self.host_base)

        # --- 6) Text verbosity (menu instead of free-typed low/medium/high) ---
        try:
            curv = (
                self.text_verbosity
                if isinstance(getattr(self, "text_verbosity", None), str)
                else "medium"
            )
        except Exception:
            curv = "medium"

        verbosity_choices: List[Tuple[str, str]] = []
        if self._is_gpt_model(self.model):
            # Default-first: Low for GPT models.
            verbosity_choices = [
                ("low", "Low – short, to-the-point answers"),
                ("medium", "Medium – balanced detail"),
                ("high", "High – more verbose explanations"),
            ]
        else:
            # Default-first: Medium for non-GPT models; do not surface "Low".
            verbosity_choices = [
                ("medium", "Medium – balanced detail (recommended)"),
                ("high", "High – more verbose explanations"),
            ]

        verb_choice = await self._menu_choice(
            "Text verbosity",
            "How verbose should responses be by default?",
            verbosity_choices,
        )
        if verb_choice in ("low", "medium", "high"):
            self.text_verbosity = verb_choice
        else:
            self.text_verbosity = curv or "medium"

        # --- 7) Tool preambles (GPT-5 / GPT-5.4 only; non-Codex) ---
        if self._supports_preambles(self.model):
            preamble_choice = await self._menu_choice(
                "Tool call preambles",
                "Before using tools, the agent can briefly explain what it will do and why.",
                [
                    ("off", "Disable preambles (default)"),
                    ("on", "Enable preambles"),
                ],
            )
            self.preambles_enabled = preamble_choice == "on"
        else:
            # Never enable preambles on unsupported models.
            self.preambles_enabled = False

        # --- 8) Optional custom first-turn note (menu + text only when chosen) ---
        custom_choice = await self._menu_choice(
            "Custom first-turn note",
            "Optionally add a custom note that will be included in your first message.",
            [
                ("none", "No custom note"),
                ("add", "Add a custom note"),
            ],
        )
        if custom_choice == "add":
            self.custom_first_turn_enabled = True
            try:
                txt_default = (
                    self.custom_first_turn_text
                    if isinstance(self.custom_first_turn_text, str)
                    else ""
                )
            except Exception:
                txt_default = ""
            entered = self.ui.prompt(
                "Enter custom first-turn text (you can edit this later via /settings)",
                default=txt_default,
            )
            try:
                self.custom_first_turn_text = str(entered or "")
            except Exception:
                self.custom_first_turn_text = ""
            try:
                self._did_inject_custom_first_turn = False
            except Exception:
                pass
        else:
            self.custom_first_turn_enabled = False

        # --- 9) Default Usage & Info panel to concise on first setup ---
        try:
            self.usage_info_mode = "concise"
        except Exception:
            pass

        # --- 10) Offer Issue #15 status fields configuration now ---
        try:
            choice = await self._menu_choice(
                "Status fields",
                (
                    "Do you want to customize the post-turn status output now?\n"
                    "(You can always change this later via /settings, /statusfields, and /statuslayout.)"
                ),
                [
                    ("yes", "Yes  open Settings at Status fields"),
                    ("no", "No  keep presets"),
                ],
            )
            if choice == "yes":
                # Open Settings UI focused on the new controls.
                try:
                    await self.open_settings(focus="status")
                except Exception:
                    pass
        except Exception:
            pass

        # Save settings to server
        await self._save_server_settings()

        # Refresh local code map source
        try:
            self._codebase_map_raw = self._load_codebase_map_raw()
        except Exception:
            pass



    # ----------------- Preflight token/cost estimation -----------------
    async def _preflight_estimate_and_confirm(self, user_input: str) -> bool:
        # Build a preview of the messages including code map injection WITHOUT mutating state
        msgs = self._build_messages_preview(user_input)
        model = self.model or "gpt-5"
        # Try Gemini token counter
        used_gemini = False
        tokens_in = 0
        try:
            api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
            if api_key:
                try:
                    import google.genai as genai  # type: ignore
                    client = genai.Client(api_key=api_key)
                    # Convert messages into a simple list of strings
                    contents = []
                    for m in msgs:
                        role = m.get("role", "user")
                        text = m.get("content", "")
                        contents.append({"role": role, "parts": [{"text": text}]})
                    # Pick a Gemini model for counting; fall back if current isn't Gemini
                    # (gemini-2.5-pro removed from curated lists)
                    count_model = "gemini-3-flash-preview"
                    res = client.models.count_tokens(model=count_model, contents=contents)
                    t = int(getattr(res, "total_tokens", 0) or 0)
                    if t > 0:
                        tokens_in = t
                        used_gemini = True
                except Exception:
                    used_gemini = False
        except Exception:
            used_gemini = False
        if not used_gemini:
            # Heuristic fallback: 1 token ~= 4 chars
            total_chars = 0
            try:
                for m in msgs:
                    total_chars += len(m.get("content", "") or "")
            except Exception:
                total_chars = len(user_input)
            tokens_in = max(1, int(round(total_chars / 4.0)))
        # Assume 30% additional output tokens
        tokens_out = int(round(tokens_in * 0.3))
        est_total = tokens_in + tokens_out
        price = self._resolve_price(model)
        cost = (tokens_in / 1_000_000.0) * float(price.get("input", 0.0)) + (tokens_out / 1_000_000.0) * float(price.get("output", 0.0))
        label = "Gemini token counter" if used_gemini else "heuristic estimator"
        choice = await self._menu_choice(
            "Estimated cost",
            f"Estimated cost: ${cost:.6f} (in {tokens_in} + out ~{tokens_out} = {est_total} tokens) via {label}.",
            [
                ("proceed", "Proceed with this request"),
                ("cancel", "Cancel"),
            ],
        )
        return choice == "proceed"

    def _build_messages_preview(self, user_input: str) -> List[Dict[str, str]]:
        msgs: List[Dict[str, str]] = []
        if self.system_prompt:
            msgs.append({"role": "system", "content": self.system_prompt})
        for msg in self.history:
            if msg["role"] != "system":
                msgs.append({"role": msg["role"], "content": msg["content"]})
        # Preview first-turn injections WITHOUT mutating state flags
        content = user_input
        blocks: List[str] = []
        # AGENTS.md (preview; does not touch _did_inject_agents_md)
        try:
            if bool(getattr(self, "inject_agents_md", True)):
                inj_a = self._build_agents_injection()
                if inj_a:
                    blocks.append(inj_a)
        except Exception:
            pass
        # Codebase map (use loader directly; ignore _did_inject flag for preview)
        if self.inject_codebase_map:
            inj = self._build_codebase_injection(user_input)
            if inj:
                blocks.append(inj)
        # Custom first-turn text
        try:
            if bool(getattr(self, "custom_first_turn_enabled", False)):
                txt = getattr(self, "custom_first_turn_text", "") or ""
                if isinstance(txt, str) and txt.strip():
                    blocks.append(txt.strip())
        except Exception:
            pass
        # Tool usage preamble (UX hint) — GPT-5 / GPT-5.4 only (non-Codex)
        try:
            if bool(getattr(self, "preambles_enabled", False)) and self._supports_preambles(self.model):
                blocks.append(
                    "Tool usage: when you need to read or modify files or run commands, "
                    "explicitly explain why you're using a tool, what you'll do, and how it "
                    "advances the user's goal before calling the tool."
                )
        except Exception:
            pass
        # Working memory preview (does not touch _did_inject_working_memory or paths)
        try:
            if self._memory_paths_for_first_turn:
                wm_block = self._build_working_memory_injection()
                if wm_block:
                    blocks.append(wm_block)
        except Exception:
            pass
        if blocks:
            content = "\n\n".join(blocks + [user_input])
        msgs.append({"role": "user", "content": content})
        return msgs

    # ----------------------- Agent scope rebind ------------------------
    def _rebind_agent_scope_default(self) -> None:
        """Bind Agent scope to this terminal's CWD for the current session unless explicitly overridden.
        Avoid persisting this default to server settings.
        """
        try:
            # If user explicitly set a scope (via CLI flag or command), do nothing
            if self.host_base and not getattr(self, "_host_base_ephemeral", False):
                return
        except Exception:
            pass
        try:
            cwd = str(Path(os.getcwd()).resolve())
        except Exception:
            cwd = None
        if cwd:
            self.host_base = cwd
            self._host_base_ephemeral = True

    # ----------------------- Remote Control / WS bridge --------------------
    def _empty_current_turn(self) -> Dict[str, Any]:
        return {
            "active": False,
            "session_id": None,
            "model": None,
            "level": None,
            "assistant_so_far": "",
            "tool_events": [],
            "user_message": None,
            "thinking_insight": None,
        }

    def _remote_control_reset_transcript(self) -> None:
        self._remote_control_messages = []
        self._remote_last_completed = None

    def _remote_control_append_message(
        self,
        role: str,
        content: Any,
        *,
        model: Optional[str] = None,
        origin: Optional[str] = None,
        function_logs: Optional[List[Dict[str, Any]]] = None,
        thinking_insight: Optional[Dict[str, Any]] = None,
    ) -> None:
        role_value = str(role or "").strip().lower()
        text = str(content or "")
        if role_value not in {"user", "assistant"}:
            return
        has_assistant_extras = (
            role_value == "assistant"
            and (
                (isinstance(function_logs, list) and len(function_logs) > 0)
                or (isinstance(thinking_insight, dict) and bool(thinking_insight))
            )
        )
        if not text.strip() and not has_assistant_extras:
            return
        payload: Dict[str, Any] = {
            "role": role_value,
            "content": text,
        }
        if isinstance(model, str) and model.strip():
            payload["model"] = model.strip()
        if isinstance(origin, str) and origin.strip():
            payload["origin"] = origin.strip()
        if isinstance(function_logs, list) and function_logs:
            payload["functionLogs"] = copy.deepcopy(function_logs)
        if isinstance(thinking_insight, dict) and thinking_insight:
            payload["thinkingInsight"] = copy.deepcopy(thinking_insight)
        self._remote_control_messages.append(payload)

    def _remote_control_completed_message(self) -> Optional[Dict[str, Any]]:
        completed = self._remote_last_completed if isinstance(self._remote_last_completed, dict) else None
        if not isinstance(completed, dict):
            return None
        content = str(completed.get("text") or "")
        function_logs = completed.get("function_logs")
        thinking_insight = completed.get("thinking_insight")
        has_tool_state = isinstance(function_logs, list) and len(function_logs) > 0
        has_thinking = isinstance(thinking_insight, dict) and bool(thinking_insight)
        if not content.strip() and not has_tool_state and not has_thinking:
            return None
        message: Dict[str, Any] = {
            "role": "assistant",
            "content": content,
            "model": completed.get("model") or self._last_used_model or self.model,
            "isStreaming": False,
        }
        if has_tool_state:
            message["functionLogs"] = copy.deepcopy(function_logs)
        if has_thinking:
            message["thinkingInsight"] = copy.deepcopy(thinking_insight)
        citations = completed.get("citations")
        if isinstance(citations, list) and citations:
            message["citations"] = copy.deepcopy(citations)
        return message

    def _remote_control_same_message(
        self,
        left: Optional[Dict[str, Any]],
        right: Optional[Dict[str, Any]],
    ) -> bool:
        if not isinstance(left, dict) or not isinstance(right, dict):
            return False
        try:
            return (
                str(left.get("role") or "") == str(right.get("role") or "")
                and str(left.get("content") or "") == str(right.get("content") or "")
                and str(left.get("model") or "") == str(right.get("model") or "")
                and (left.get("functionLogs") or []) == (right.get("functionLogs") or [])
                and (left.get("thinkingInsight") or None) == (right.get("thinkingInsight") or None)
            )
        except Exception:
            return False

    def _remote_control_last_completed_metadata(
        self,
    ) -> Tuple[Optional[List[Dict[str, Any]]], Optional[Dict[str, Any]]]:
        completed = self._remote_last_completed if isinstance(self._remote_last_completed, dict) else None
        if not isinstance(completed, dict):
            return None, None
        function_logs: Optional[List[Dict[str, Any]]] = None
        thinking_insight: Optional[Dict[str, Any]] = None
        logs_value = completed.get("function_logs")
        if isinstance(logs_value, list) and logs_value:
            function_logs = copy.deepcopy(logs_value)
        insight_value = completed.get("thinking_insight")
        if isinstance(insight_value, dict) and insight_value:
            thinking_insight = copy.deepcopy(insight_value)
        return function_logs, thinking_insight

    def _build_remote_control_billing_info(self, model_name: Optional[str] = None) -> Dict[str, Any]:
        active_model = model_name or self.model or self._current_turn.get("model") or self._last_used_model
        uses_codex = False
        is_codex_capable = False
        rollover_active = False
        remaining_credits: Optional[float] = None
        try:
            is_codex_capable = self._is_codex_local_model(active_model)
        except Exception:
            is_codex_capable = False
        try:
            rollover_active = bool(getattr(self, "_codex_force_backend_for_conversation", False)) and is_codex_capable
        except Exception:
            rollover_active = False
        try:
            uses_codex = self._should_use_local_codex_for_model(active_model)
        except Exception:
            uses_codex = False
        try:
            if self._last_remaining_credits is not None:
                remaining_credits = float(self._last_remaining_credits)
        except Exception:
            remaining_credits = None
        if uses_codex:
            detail = "Billed via your OpenAI Codex subscription"
        elif rollover_active:
            detail = "Using backend credits after Codex rollover"
        else:
            detail = "Billed via backend credits"
        return {
            "mode": ("codex" if uses_codex else "credits"),
            "label": ("Codex" if uses_codex else "Credits"),
            "detail": detail,
            "remaining_credits": remaining_credits,
            "service_tier": ("priority" if self.service_tier == "priority" else "default"),
            "subscription_tier": self.subscription_tier,
            "subscription_status": self.subscription_status,
            "is_free_tier": bool(self.is_free_tier),
            "codex_rollover_active": bool(rollover_active),
            "model_is_codex_capable": bool(is_codex_capable),
        }

    def _build_remote_control_context_info(
        self,
        model_name: Optional[str],
        usage: Optional[Dict[str, Any]],
    ) -> Dict[str, Any]:
        context_window = self._get_model_ctx_window(model_name)
        total_tokens = 0
        usage_map = usage if isinstance(usage, dict) else {}
        try:
            total_tokens = int(
                usage_map.get("total_tokens")
                or (usage_map.get("turn") or {}).get("total_tokens")
                or (
                    int(usage_map.get("input_tokens", 0) or usage_map.get("prompt_tokens", 0) or 0)
                    + int(usage_map.get("output_tokens", 0) or usage_map.get("completion_tokens", 0) or 0)
                )
                or 0
            )
        except Exception:
            total_tokens = 0
        context_meter: Optional[Dict[str, Any]] = None
        context_pct: Optional[float] = None
        if isinstance(context_window, int) and context_window > 0:
            try:
                pct_val = max(0.0, min(100.0, (float(total_tokens) / float(context_window)) * 100.0))
            except Exception:
                pct_val = 0.0
            bar_width = 30
            filled = int(round((pct_val / 100.0) * bar_width))
            empty = max(0, bar_width - filled)
            context_meter = {
                "tokens": int(total_tokens),
                "pct": float(pct_val),
                "filled": int(filled),
                "empty": int(empty),
            }
            context_pct = float(pct_val)
        return {
            "context_meter": context_meter,
            "context_pct": context_pct,
            "context_window": (int(context_window) if isinstance(context_window, int) and context_window > 0 else None),
            "context_window_known": bool(isinstance(context_window, int) and context_window > 0),
        }

    def _build_remote_control_cookie_header(self) -> str:
        try:
            parts: List[str] = []
            for key, value in self.cookies.items():
                if isinstance(key, str) and isinstance(value, str) and key.strip():
                    parts.append(f"{key}={value}")
            return "; ".join(parts)
        except Exception:
            return ""

    def _remote_control_name_bank(self) -> List[str]:
        return [
            "Andromeda", "Antlia", "Apus", "Aquila", "Ara", "Aries", "Auriga", "Bootes", "Caelum", "Carina",
            "Cassiopeia", "Centauri", "Cepheus", "Cetus", "Columba", "Corona", "Corvus", "Cygnus", "Delphinus", "Draco",
            "Equuleus", "Eridanus", "Fornax", "Grus", "Horologium", "Hydra", "Indus", "Lacerta", "Leo", "Lepus",
            "Libra", "Lupus", "Lyra", "Mensa", "Norma", "Octans", "Orion", "Pavo", "Pegasus", "Perseus",
            "Phoenix", "Pictor", "Pyxis", "Reticulum", "Scorpius", "Serpens", "Tucana", "Ursa", "Vela", "Volans",
        ]

    def _build_remote_control_terminal_alias(self) -> Dict[str, str]:
        bank = self._remote_control_name_bank()
        if not bank:
            short_id = str(self.terminal_id or "")[:8] or "terminal"
            return {"terminal_alias": short_id, "terminal_short_id": short_id, "display_name": short_id}
        seed_parts = [
            str(self.terminal_id or "").strip(),
            str(self.device_id or "").strip(),
            str(self.host_base or "").strip(),
            str(self.local_workspace_dir or "").strip(),
        ]
        seed = "|".join(seed_parts)
        digest = hashlib.sha1(seed.encode("utf-8", errors="ignore")).digest()
        bank_index = digest[0] % len(bank)
        suffix = int.from_bytes(digest[1:3], "big") % 100
        short_id = str(self.terminal_id or "")[:8] or f"{digest[3]:02x}{digest[4]:02x}"
        alias = f"{bank[bank_index]}-{suffix:02d}"
        return {
            "terminal_alias": alias,
            "terminal_short_id": short_id,
            "display_name": alias,
        }

    def _remote_control_terminal_display_name(self) -> str:
        try:
            alias_info = self._build_remote_control_terminal_alias()
            display_name = alias_info.get("display_name") or alias_info.get("terminal_alias")
            if isinstance(display_name, str) and display_name.strip():
                return display_name.strip()
        except Exception:
            pass
        try:
            fallback = str(self.terminal_id or "").strip()
            if fallback:
                return fallback
        except Exception:
            pass
        return "Remote Control"

    def _remote_control_ws_url(self) -> str:
        base = join_url(self.api_base, "/remote-control/terminal/ws")
        parsed = urlparse(http_url_to_ws_url(base))
        params = parse_qs(parsed.query or "", keep_blank_values=True)
        params["terminal_id"] = [self.terminal_id]
        return urlunparse(parsed._replace(query=urlencode(params, doseq=True)))

    def _build_remote_control_terminal_info(self) -> Dict[str, Any]:
        active_model = self.model or self._current_turn.get("model") or self._last_used_model
        context_window = self._get_model_ctx_window(active_model)
        alias_info = self._build_remote_control_terminal_alias()
        try:
            cwd_value = str(Path(os.getcwd()).resolve())
        except Exception:
            cwd_value = str(self.local_workspace_dir or "")
        try:
            if not self._cli_version:
                self._cli_version = self._resolve_current_version() or None
        except Exception:
            pass
        label = self.device_name or f"{socket.gethostname()} cli"
        model_presets: List[Dict[str, str]] = []
        try:
            seen_models: set[str] = set()
            for preset_value, preset_label in self._model_presets():
                model_value = str(preset_value or "").strip()
                if not model_value or model_value in seen_models:
                    continue
                seen_models.add(model_value)
                model_presets.append(
                    {
                        "value": model_value,
                        "label": str(preset_label or model_value).strip() or model_value,
                    }
                )
        except Exception:
            model_presets = []
        return {
            "terminal_id": self.terminal_id,
            "label": label,
            "terminal_alias": alias_info.get("terminal_alias"),
            "terminal_short_id": alias_info.get("terminal_short_id"),
            "display_name": alias_info.get("display_name"),
            "device_id": self.device_id,
            "device_name": self.device_name,
            "auth_user": self.auth_user,
            "cli_version": self._cli_version,
            "cwd": cwd_value,
            "workspace_dir": self.local_workspace_dir,
            "host_base": self.host_base,
            "host_name": socket.gethostname(),
            "platform": sys.platform,
            "pid": os.getpid(),
            "model": active_model,
            "model_presets": model_presets,
            "context_window": (int(context_window) if isinstance(context_window, int) and context_window > 0 else None),
            "billing": self._build_remote_control_billing_info(active_model),
            "control_level": self.control_level,
            "fs_scope": self.fs_scope,
        }

    def _build_remote_control_snapshot(self) -> Dict[str, Any]:
        settings = self._collect_settings_dict()
        current_turn = copy.deepcopy(self._current_turn) if isinstance(self._current_turn, dict) else self._empty_current_turn()
        active_model = self.model or current_turn.get("model") or self._last_used_model
        context_window = self._get_model_ctx_window(active_model)
        if not isinstance(current_turn, dict):
            current_turn = self._empty_current_turn()
        current_turn.setdefault("tool_events", [])
        if not isinstance(current_turn.get("tool_events"), list):
            current_turn["tool_events"] = []
        current_turn["assistant_so_far"] = str(current_turn.get("assistant_so_far") or "")
        transcript = copy.deepcopy(self._remote_control_messages) if isinstance(self._remote_control_messages, list) else []
        completed_message = self._remote_control_completed_message()
        if current_turn.get("active"):
            current_user = current_turn.get("user_message") if isinstance(current_turn.get("user_message"), dict) else {}
            current_user_text = str((current_user or {}).get("text") or "").strip()
            if current_user_text:
                user_already_in_transcript = False
                try:
                    for message in transcript:
                        if not isinstance(message, dict):
                            continue
                        if str(message.get("role") or "").strip().lower() != "user":
                            continue
                        if str(message.get("content") or "") == current_user_text:
                            user_already_in_transcript = True
                            break
                except Exception:
                    user_already_in_transcript = False
                if not (
                    user_already_in_transcript
                ):
                    transcript.append(
                        {
                            "role": "user",
                            "content": current_user_text,
                            "model": current_user.get("model") or self.model,
                            "origin": current_user.get("origin") or "cli",
                        }
                    )
            assistant_preview = str(current_turn.get("assistant_so_far") or "")
            if assistant_preview or current_turn.get("tool_events") or current_turn.get("thinking_insight"):
                transcript.append(
                    {
                        "role": "assistant",
                        "content": assistant_preview,
                        "model": current_turn.get("model") or self.model or self._last_used_model,
                        "isStreaming": True,
                        "functionLogs": copy.deepcopy(current_turn.get("tool_events") or []),
                        "thinkingInsight": copy.deepcopy(current_turn.get("thinking_insight")),
                    }
                )
        elif completed_message:
            last_transcript_message = transcript[-1] if transcript and isinstance(transcript[-1], dict) else None
            if not self._remote_control_same_message(last_transcript_message, completed_message):
                transcript.append(completed_message)
        snapshot = {
            "terminal": self._build_remote_control_terminal_info(),
            "busy": bool(self._busy),
            "model": active_model,
            "billing": self._build_remote_control_billing_info(active_model),
            "context_window": (int(context_window) if isinstance(context_window, int) and context_window > 0 else None),
            "control_level": self.control_level,
            "requested_tools": self.requested_tools,
            "fs_scope": self.fs_scope,
            "host_base": self.host_base,
            "settings": settings,
            "current_turn": current_turn,
            "messages": transcript,
        }
        if isinstance(self._remote_last_completed, dict) and self._remote_last_completed:
            snapshot["last_completed"] = copy.deepcopy(self._remote_last_completed)
        try:
            last_user = str(getattr(self, "last_user_input", "") or "").strip()
            if last_user:
                snapshot["last_user_message"] = {
                    "text": last_user,
                    "model": self.model,
                    "origin": "cli",
                }
        except Exception:
            pass
        return snapshot

    async def _remote_control_send(self, typ: str, data: Dict[str, Any]) -> None:
        if not self._ws_is_open(getattr(self, "_remote_ws", None)):
            return
        try:
            await self._remote_ws.send(json.dumps({"type": typ, "data": data or {}}, ensure_ascii=False))
        except Exception:
            pass

    async def _remote_control_send_state(self) -> None:
        try:
            await self._remote_control_send("terminal.state", self._build_remote_control_snapshot())
        except Exception:
            pass

    async def _remote_control_send_hello(self) -> None:
        try:
            await self._remote_control_send(
                "terminal.hello",
                {
                    "terminal": self._build_remote_control_terminal_info(),
                },
            )
        except Exception:
            pass

    async def _remote_control_handle_message(self, msg: Dict[str, Any]) -> None:
        mtype = str(msg.get("type") or "")
        if mtype in {"user.send", "approval.reply", "control.set", "settings.update"}:
            await self._on_ws_message(msg)
            return
        if mtype == "ping":
            await self._remote_control_send("pong", {"ts": time.time()})
            return
        if mtype == "remote.registered":
            try:
                reg_term = str((msg.get("data") or {}).get("terminal_id") or "").strip()
                if reg_term:
                    self.terminal_id = reg_term
            except Exception:
                pass

    async def _open_remote_control_ws(self, ws_url: str, cookie_header: str) -> Any:
        connect_kwargs: Dict[str, Any] = {
            "ping_interval": 20,
            "ping_timeout": 20,
        }
        if cookie_header:
            headers = {"Cookie": cookie_header}
            try:
                return await websockets.connect(ws_url, additional_headers=headers, **connect_kwargs)  # type: ignore[arg-type]
            except TypeError:
                return await websockets.connect(ws_url, extra_headers=headers, **connect_kwargs)  # type: ignore[arg-type]
        try:
            return await websockets.connect(ws_url, **connect_kwargs)  # type: ignore[arg-type]
        except TypeError:
            return await websockets.connect(ws_url)  # type: ignore[arg-type]

    async def _remote_control_state_pump(self, ws: Any) -> None:
        try:
            interval = float(os.getenv("HENOSIS_REMOTE_CONTROL_STATE_INTERVAL", "5") or 5.0)
        except Exception:
            interval = 5.0
        if interval <= 0:
            interval = 5.0
        while self.agent_mode and (self._remote_ws is ws) and (not self._remote_ws_stop.is_set()):
            await asyncio.sleep(interval)
            if not self.agent_mode or self._remote_ws is not ws or self._remote_ws_stop.is_set():
                break
            await self._remote_control_send_state()

    async def _remote_control_loop(self) -> None:
        if not HAS_WS:
            return
        self._remote_ws_stop.clear()
        backoff_sec = 1.0
        while self.agent_mode and (not self._remote_ws_stop.is_set()):
            auth_cookie_header = self._build_remote_control_cookie_header()
            if (not self.auth_user) or (not auth_cookie_header):
                await asyncio.sleep(2.0)
                continue
            ws_url = self._remote_control_ws_url()
            ws = None
            try:
                ws = await self._open_remote_control_ws(ws_url, auth_cookie_header)
                self._remote_ws = ws
                self.ui.print(f"[remote] Connected to {ws_url}", style=self.ui.theme["dim"])
                backoff_sec = 1.0
                await self._remote_control_send_hello()
                await self._remote_control_send_state()
                self._remote_ws_state_task = asyncio.create_task(self._remote_control_state_pump(ws))
                async for raw in ws:
                    try:
                        if isinstance(raw, bytes):
                            raw = raw.decode("utf-8", errors="replace")
                        msg = json.loads(raw)
                    except Exception:
                        continue
                    if isinstance(msg, dict):
                        await self._remote_control_handle_message(msg)
            except Exception as e:
                if not self._remote_ws_stop.is_set():
                    self.ui.print(f"[remote] Reconnecting after error: {e}", style=self.ui.theme["dim"])
                    await asyncio.sleep(backoff_sec)
                    backoff_sec = min(backoff_sec * 2.0, 5.0)
            finally:
                state_task = self._remote_ws_state_task
                self._remote_ws_state_task = None
                if state_task is not None:
                    try:
                        state_task.cancel()
                    except Exception:
                        pass
                if self._remote_ws is ws:
                    self._remote_ws = None
                try:
                    if ws is not None and self._ws_is_open(ws):
                        await ws.close()
                except Exception:
                    pass
        self._remote_ws = None

    async def _start_remote_control_bridge(self) -> None:
        if not self.agent_mode or not HAS_WS:
            return
        task = getattr(self, "_remote_ws_task", None)
        if task is not None and not task.done():
            return
        self._remote_ws_stop.clear()
        self._remote_ws_task = asyncio.create_task(self._remote_control_loop())

    async def _start_ws_hub(self) -> None:
        if not HAS_WS:
            return
        try:
            ws_logger = logging.getLogger("henosis.agent_ws")
            if not ws_logger.handlers:
                ws_logger.addHandler(logging.NullHandler())
            ws_logger.propagate = False
            ws_logger.setLevel(logging.CRITICAL + 1)
            for noisy_logger_name in ("websockets", "websockets.server"):
                noisy_logger = logging.getLogger(noisy_logger_name)
                if not noisy_logger.handlers:
                    noisy_logger.addHandler(logging.NullHandler())
                noisy_logger.propagate = False
                noisy_logger.setLevel(logging.CRITICAL + 1)
        except Exception:
            ws_logger = None
        # Bind host: in dev, default 127.0.0.1; guard remote if flag not set
        host = self.agent_host
        if not self.agent_allow_remote and host not in ("127.0.0.1", "localhost", "::1"):
            host = "127.0.0.1"
        # Start server and log explicit startup + diagnostics
        port_to_use = int(self.agent_port)
        # If requested port is in use, pick a free one
        if port_to_use > 0 and self._port_in_use(host, port_to_use):
            picked = self._find_free_port(host)
            if picked:
                port_to_use = picked
        # Try to serve; if it still fails, fallback to auto-pick
        # Provide a light HTTP response for non-WS requests to avoid scary tracebacks
        async def _ws_process_request(*args):  # type: ignore
            """Handle both legacy and modern websockets process_request signatures.

            websockets<=14 passed (path, headers); websockets>=15 passes
            (connection, request). Returning the wrong shape breaks the opening
            handshake before the browser can establish the socket.
            """

            connection = None
            request = None
            path = None
            request_headers = None

            try:
                if len(args) >= 2:
                    first, second = args[0], args[1]
                    if isinstance(first, str):
                        # Legacy API: (path, headers)
                        path = first
                        request_headers = second
                    else:
                        # Modern API: (connection, request)
                        connection = first
                        request = second
                        path = getattr(request, "path", None)
                        request_headers = getattr(request, "headers", None)
                elif len(args) == 1:
                    request = args[0]
                    path = getattr(request, "path", None)
                    request_headers = getattr(request, "headers", None)
            except Exception:
                path = None
                request_headers = None

            def _response(status_code: int, body: bytes):
                headers = [
                    ("Content-Type", "text/plain; charset=utf-8"),
                    ("Content-Length", str(len(body))),
                ]
                try:
                    if connection is not None and hasattr(connection, "respond"):
                        return connection.respond(status_code, body)
                except Exception:
                    pass
                return status_code, headers, body

            try:
                req_path = path or ""
                headers_obj = request_headers or {}
                try:
                    up = (headers_obj.get("Upgrade") or headers_obj.get("upgrade") or "").lower()
                except Exception:
                    up = ""

                try:
                    self.ui.debug_log(
                        f"[agent] process_request path={req_path!r} upgrade={up!r} signature={'modern' if connection is not None else 'legacy'}"
                    )
                except Exception:
                    pass

                # Only accept /agent/ws (and trailing slash). Others -> 404
                if req_path not in ("/agent/ws", "/agent/ws/"):
                    body = b"404 Not Found: This port is a WebSocket endpoint for Agent Mode. Use ws://HOST:PORT/agent/ws.\n"
                    return _response(404, body)

                # Check Upgrade header; if missing, guide the user
                if up != "websocket":
                    body = (
                        b"426 Upgrade Required\n\n"
                        b"This endpoint expects a WebSocket (Agent Mode).\n"
                        b"Use a WS client or the Henosis UI.\n"
                        b"Path: /agent/ws\n"
                    )
                    return _response(426, body)
            except Exception as e:
                try:
                    self.ui.debug_log(f"[agent] process_request error: {e}")
                except Exception:
                    pass
                # On any unexpected issue, let websockets proceed with the normal handshake
                return None  # type: ignore
            return None  # Continue with normal WS handshake

        try:
            # Try to pass process_request, and silence internal error logs if supported
            try:
                self._ws_server = await websockets.serve(self._ws_handler, host, port_to_use, process_request=_ws_process_request, logger=ws_logger)  # type: ignore
            except TypeError:
                # Older versions may not support logger or process_request
                self._ws_server = await websockets.serve(self._ws_handler, host, port_to_use)  # type: ignore
        except OSError:
            # Last-resort auto-pick
            picked = self._find_free_port(host)
            port_to_use = picked or 0
            try:
                self._ws_server = await websockets.serve(self._ws_handler, host, port_to_use, process_request=_ws_process_request, logger=ws_logger)  # type: ignore
            except TypeError:
                self._ws_server = await websockets.serve(self._ws_handler, host, port_to_use)  # type: ignore
        # Update actual bound port if OS picked one
        try:
            if hasattr(self._ws_server, "sockets") and self._ws_server.sockets:
                sock = self._ws_server.sockets[0]
                actual = sock.getsockname()[1]
                self.agent_port = int(actual)
            else:
                self.agent_port = int(port_to_use)
        except Exception:
            self.agent_port = int(port_to_use)
        try:
            self.ui.print(
                f"[agent] WS hub started on ws://{host}:{int(self.agent_port)}/agent/ws (allow_remote={self.agent_allow_remote})",
                style=self.ui.theme["dim"],
            )
            # Friendly hint for folks who open the port in a browser
            self.ui.print(
                "[agent] Note: Opening this URL in a browser will show 'Upgrade Required'. "
                "Use a WebSocket client (the Henosis UI connects automatically).",
                style=self.ui.theme["dim"],
            )
        except Exception:
            pass

    def _ws_is_open(self, ws: Optional[Any]) -> bool:
        """Best-effort cross-version check for websockets connection open state.
        Supports legacy WebSocketServerProtocol (v9/v10) and new ServerConnection (v11+)."""
        try:
            if ws is None:
                return False
            # websockets >= 11 exposes a state enum; prefer that when available
            state = getattr(ws, "state", None)
            if state is not None:
                try:
                    # Enum with .name, e.g., OPEN, CLOSING, CLOSED
                    name = getattr(state, "name", None)
                    if isinstance(name, str):
                        return name.upper() == "OPEN"
                except Exception:
                    pass
                # Some variants expose state as a string
                if isinstance(state, str):
                    return state.upper() == "OPEN"
            # Older versions exposed .open boolean
            open_attr = getattr(ws, "open", None)
            if isinstance(open_attr, bool):
                return open_attr
            # Fallback to .closed boolean (True when closed)
            closed_attr = getattr(ws, "closed", None)
            if isinstance(closed_attr, bool):
                return not closed_attr
            # As a last resort, assume open (send will raise if not)
            return True
        except Exception:
            return False

    async def _ws_handler(self, websocket: WebSocketServerProtocol, path: Optional[str] = None) -> None:
        """
        WebSocket connection handler for Agent Mode.
        Compatible with websockets v9/v10 (handler(websocket, path)) and v11+ (handler(websocket)).
        """
        # Derive path for websockets >= 11 where only (websocket) is passed
        if path is None:
            try:
                path = getattr(websocket, "path", None)
            except Exception:
                path = None
            # Try websockets >=11 request object
            if path is None:
                try:
                    request = getattr(websocket, "request", None)
                    if request is not None:
                        path = getattr(request, "path", None)
                except Exception:
                    path = None
        # Log early handshake info for diagnostics
        try:
            ra = getattr(websocket, "remote_address", None)
            ha = getattr(websocket, "host", None)
            self.ui.print(
                f"[agent] incoming connection remote={ra} path={path} host_hdr={ha}",
                style=self.ui.theme["dim"],
            )
        except Exception:
            pass
        # Restrict to /agent/ws
        # Allow default when path can't be determined
        chk_path = path or "/agent/ws"
        # Be forgiving in dev: accept '/', '' as well as canonical '/agent/ws'
        allowed_paths = ("/agent/ws", "/agent/ws/", "/", "")
        if chk_path not in allowed_paths:
            try:
                # Send a short error frame before closing for easier debugging in browser
                await websocket.send(json.dumps({"type": "error", "data": {"message": f"Invalid WS path '{chk_path}'. Expected '/agent/ws'"}}))
            except Exception:
                pass
            try:
                await websocket.close(code=1008, reason="Invalid path")
            except Exception:
                pass
            return
        # Warn if a non-canonical but accepted path is used (helps spot misconfig)
        if chk_path in ("/", ""):
            try:
                await websocket.send(json.dumps({"type": "warning", "data": {"message": "Connected on '/' – prefer '/agent/ws' to avoid path checks in production."}}))
            except Exception:
                pass
        # Single-client policy: replace old with new
        async with self._ws_client_lock:
            if self._ws_is_open(self._ws_client):
                try:
                    await self._ws_client.close(code=1000, reason="Replaced by new connection")
                except Exception:
                    pass
            self._ws_client = websocket
        # Log connection
        try:
            ra = getattr(websocket, 'remote_address', None)
            self.ui.print(f"[agent] client connected {ra}", style=self.ui.theme["dim"])  # type: ignore
        except Exception:
            pass
        # Notify connected state
        await self._ws_send({"type": "state.connected", "data": {"connected": True}})
        # If a turn is already in progress, replay state so the UI can catch up
        try:
            if self._busy and self._current_turn.get("active"):
                await self._ws_broadcast("state.busy", {"busy": True})
                sess_id = self._current_turn.get("session_id")
                if sess_id is not None:
                    await self._ws_broadcast("session.started", {"session_id": sess_id})
                # Replay prior tool events
                for ev in self._current_turn.get("tool_events", []) or []:
                    await self._ws_broadcast(str(ev.get("type")), ev.get("data") or {})
                # Send snapshot of assistant text so far
                so_far = self._current_turn.get("assistant_so_far") or ""
                if so_far:
                    await self._ws_broadcast("message.sync", {"text": so_far, "model": self._current_turn.get("model")})
        except Exception:
            pass
        try:
            async for raw in websocket:
                try:
                    msg = json.loads(raw)
                except Exception:
                    await self._ws_send({"type": "error", "data": {"message": "Invalid JSON"}})
                    continue
                try:
                    await self._on_ws_message(msg)
                except httpx.HTTPStatusError as he:
                    # Surface backend HTTP errors to the WS client and continue serving
                    body = ""
                    try:
                        await he.response.aread()
                        body = he.response.text
                    except Exception:
                        pass
                    await self._ws_send({"type": "error", "data": {"message": f"HTTP {he.response.status_code} from {self.stream_url}: {body[:4000]}"}})
                except Exception as e:
                    await self._ws_send({"type": "error", "data": {"message": str(e)}})
                    # Keep the loop alive; don't crash the WS connection
                    continue
        except Exception as e:
            # Log unexpected errors during WS loop, but downgrade common close noise
            try:
                closed_err = None
                try:
                    # Detect common closure exceptions without importing types at top level
                    ConnectionClosedError = getattr(websockets.exceptions, "ConnectionClosedError", None) if HAS_WS else None
                    ConnectionClosedOK = getattr(websockets.exceptions, "ConnectionClosedOK", None) if HAS_WS else None
                    if (ConnectionClosedError and isinstance(e, ConnectionClosedError)) or (ConnectionClosedOK and isinstance(e, ConnectionClosedOK)):
                        closed_err = e
                except Exception:
                    closed_err = None
                if closed_err is not None:
                    self.ui.print(
                        "[agent] WebSocket closed by client (no close frame or early disconnect). "
                        "This often happens if a browser hits the WS port directly or the client reloads.",
                        style=self.ui.theme["dim"],
                    )
                else:
                    self.ui.warn(f"[agent] WS handler error: {e}")
            except Exception:
                pass
        finally:
            async with self._ws_client_lock:
                if self._ws_client is websocket:
                    self._ws_client = None
            # Notify disconnected
            try:
                await self._ws_send({"type": "state.connected", "data": {"connected": False}})
            except Exception:
                pass
            # Log disconnection
            try:
                self.ui.print("[agent] client disconnected", style=self.ui.theme["dim"])  # type: ignore
            except Exception:
                pass

    async def _ws_send(self, obj: Dict[str, Any]) -> None:
        if not self._ws_is_open(self._ws_client):
            return
        try:
            await self._ws_client.send(json.dumps(obj, ensure_ascii=False))
        except Exception:
            pass

    async def _ws_broadcast(self, typ: str, data: Dict[str, Any]) -> None:
        payload = {"type": typ, "data": data or {}}
        await self._ws_send(payload)
        try:
            await self._remote_control_send(typ, data or {})
        except Exception:
            pass

    async def _on_ws_message(self, msg: Dict[str, Any]) -> None:
        mtype = str(msg.get("type") or "")
        data = msg.get("data", {}) or {}
        # Lightweight ping for connectivity checks (e.g., wscat -x '{"type":"ping"}')
        if mtype == "ping":
            try:
                await self._ws_broadcast("pong", {"ts": time.time()})
            except Exception:
                pass
            return
        if mtype == "user.send":
            # Busy check
            if self._busy:
                await self._ws_broadcast("state.busy", {"busy": True, "reason": "turn in progress"})
                return
            text = data.get("text")
            # Optional direct fields to override settings
            if "model" in data:
                self.model = data.get("model") or self.model
            if "enable_tools" in data:
                val = data.get("enable_tools")
                if isinstance(val, bool):
                    self.requested_tools = val
            if "tool_mode" in data:
                # backwards compat: ANY->True, NONE->False, AUTO->None
                tm = str(data.get("tool_mode") or "").upper()
                if tm == "ANY":
                    self.requested_tools = True
                elif tm == "NONE":
                    self.requested_tools = False
                elif tm == "AUTO":
                    self.requested_tools = None
            if "level" in data:
                try:
                    lvl = int(data.get("level"))
                    if lvl in (1, 2, 3):
                        self.control_level = lvl
                        self._last_server_level = lvl
                        try:
                            sid_ws = str(data.get("session_id") or "").strip()
                            if sid_ws:
                                self._session_level_by_id[sid_ws] = int(lvl)
                                while len(self._session_level_by_id) > 128:
                                    self._session_level_by_id.pop(next(iter(self._session_level_by_id)))
                        except Exception:
                            pass
                except Exception:
                    pass
            if "fs_scope" in data:
                fs = data.get("fs_scope")
                if fs in ("workspace", "host"):
                    self.fs_scope = fs
            if "auto_approve" in data and isinstance(data.get("auto_approve"), list):
                try:
                    self.auto_approve = [str(x) for x in data.get("auto_approve") if isinstance(x, str)]
                except Exception:
                    pass
            # Start turn
            if not isinstance(text, str) or not text.strip():
                await self._ws_broadcast("error", {"message": "user.send requires 'text'"})
                return
            if text.startswith("/") and ("\n" not in text):
                handled = await self.handle_command(text)
                if handled:
                    try:
                        await self._remote_control_send_state()
                    except Exception:
                        pass
                    return
            try:
                self._remote_last_completed = None
            except Exception:
                pass
            try:
                self._remote_control_append_message(
                    "user",
                    text,
                    model=self.model,
                    origin="web",
                )
            except Exception:
                pass
            try:
                self._current_turn["user_message"] = {
                    "text": text,
                    "model": self.model,
                    "origin": "web",
                }
            except Exception:
                pass
            if self._busy:
                queued_item = self._enqueue_user_message(text, origin="web", model=self.model)
                notice = self._queued_user_message_notice(len(self._queued_user_messages))
                try:
                    await self._render_remote_originated_user_message_below_busy_output(text)
                except Exception:
                    pass
                try:
                    await self._broadcast_queued_user_message(queued_item)
                except Exception:
                    pass
                await self._ws_broadcast("state.busy", {"busy": True, "reason": "queued user input", "note": notice})
                return
            try:
                self._render_remote_originated_user_message(text)
            except Exception:
                pass
            try:
                await self._ws_broadcast(
                    "user.message",
                    {
                        "text": text,
                        "model": self.model,
                        "origin": "web",
                    },
                )
            except Exception:
                pass
            # Log + run
            if self.save_chat_history:
                self.messages_for_save.append({
                    "role": "user",
                    "content": text,
                    "model": None,
                    "citations": None,
                    "last_turn_input_tokens": 0,
                    "last_turn_output_tokens": 0,
                    "last_turn_total_tokens": 0,
                })
            self._log_line({"event": "user.ws", "content": text})
            self._busy = True
            try:
                assistant_text = ""
                try:
                    assistant_text = await self._stream_once(text)
                except httpx.HTTPStatusError as he:
                    body = ""
                    try:
                        await he.response.aread()
                        body = he.response.text
                    except Exception:
                        pass
                    await self._ws_broadcast("error", {"message": f"HTTP {he.response.status_code} from {self.stream_url}: {body[:4000]}"})
                except Exception as e:
                    await self._ws_broadcast("error", {"message": str(e)})
            finally:
                self._busy = False
            # Mirror CLI run() history behavior so first-turn injections are preserved across WS turns
            try:
                if isinstance(assistant_text, str) and assistant_text.strip():
                    content_sent = self._last_built_user_content or text
                    self.history.append({"role": "user", "content": content_sent})
                    self.history.append({"role": "assistant", "content": assistant_text})
                    function_logs, thinking_insight = self._remote_control_last_completed_metadata()
                    self._remote_control_append_message(
                        "assistant",
                        assistant_text,
                        model=self._last_used_model or self.model,
                        origin="web",
                        function_logs=function_logs,
                        thinking_insight=thinking_insight,
                    )
            except Exception:
                pass
        elif mtype == "approval.reply":
            call_id = str(data.get("call_id")) if data.get("call_id") is not None else None
            approve = bool(data.get("approve")) if ("approve" in data) else None
            note = data.get("note")
            if call_id and call_id in self._pending_approvals:
                fut = self._pending_approvals.get(call_id)
                if fut and not fut.done() and (approve is not None):
                    try:
                        fut.set_result((bool(approve), note))
                    except Exception:
                        pass
        elif mtype == "control.set":
            key = str(data.get("key") or "")
            val = data.get("value")
            if key == "model":
                self.model = str(val) if val else None
            elif key == "enable_tools":
                if val in (None, ""):
                    self.requested_tools = None
                elif isinstance(val, bool):
                    self.requested_tools = val
            elif key == "level":
                if val in (None, ""):
                    self.control_level = None
                else:
                    try:
                        lvl = int(val)
                        if lvl in (1, 2, 3):
                            self.control_level = lvl
                            self._last_server_level = lvl
                    except Exception:
                        pass
            elif key == "fs_scope":
                if val in ("workspace", "host"):
                    self.fs_scope = val
                elif val in (None, ""):
                    self.fs_scope = None
            # No explicit ack needed
            try:
                await self._remote_control_send_state()
            except Exception:
                pass
        elif mtype == "settings.update":
            settings = data.get("settings") if isinstance(data.get("settings"), dict) else {}
            request_id = data.get("request_id")
            if not settings:
                await self._ws_broadcast("warning", {"message": "settings.update requires a settings object"})
                return
            # A remotely-updated host_base is an explicit user choice, not the
            # per-terminal ephemeral fallback bound at startup.
            if "host_base" in settings:
                self._host_base_ephemeral = False
            self._apply_settings_dict(settings)
            try:
                if "host_base" in settings:
                    self._codebase_map_raw = self._load_codebase_map_raw()
            except Exception:
                pass
            save_ok = False
            try:
                save_ok = bool(await self._save_server_settings())
            except Exception:
                save_ok = False
            await self._ws_broadcast(
                "settings.applied",
                {
                    "request_id": request_id,
                    "ok": bool(save_ok),
                    "settings": self._collect_settings_dict(),
                    "error": (None if save_ok else "Failed to save CLI settings."),
                },
            )
            try:
                await self._remote_control_send_state()
            except Exception:
                pass
        else:
            await self._ws_broadcast("warning", {"message": f"Unknown inbound type: {mtype}"})

    # Handle approval request and post decision to server.
    async def _handle_approval_request(self, client: httpx.AsyncClient, session_id: Optional[str], data: Dict[str, Any]) -> None:
        tool = str(data.get("tool"))
        call_id = data.get("call_id")
        args_prev = data.get("args_preview", {}) or {}
        timeout_sec = int(data.get("timeout_sec", 60) or 60)
        session_id_eff = session_id or data.get("session_id")

        # Resolve effective level from most-authoritative available sources.
        eff_lvl: Optional[int] = None
        try:
            eff_lvl = self._effective_control_level(data if isinstance(data, dict) else None)
        except Exception:
            eff_lvl = None

        # Issue #18: Level 3 should never prompt. Auto-approve and return.
        if eff_lvl == 3:
            if session_id_eff and call_id is not None:
                try:
                    payload = {
                        "session_id": session_id_eff,
                        "call_id": call_id,
                        "approve": True,
                        "note": "Auto-approved (Level 3)",
                    }
                    r = await client.post(self.approvals_url, json=payload, timeout=self.timeout)
                    if r.status_code >= 400:
                        self.ui.warn(f"Approval POST failed (auto L3): {r.status_code} {r.text}")
                except Exception as e:
                    self.ui.warn(f"Approval POST error (auto L3): {e}")
            else:
                self.ui.warn("Ignoring approval.request at Level 3 (missing session_id/call_id).")
            return

        # Create future before broadcasting so fast WS replies cannot be dropped.
        fut: asyncio.Future = asyncio.get_event_loop().create_future()
        if call_id is not None:
            self._pending_approvals[str(call_id)] = fut

        # Display summary
        self.ui.print(f"⚠ Approval requested for {tool} (call_id={call_id})", style=self.ui.theme["warn"])
        self.ui.print(truncate_json(args_prev, 600), style=self.ui.theme["dim"])

        # Broadcast to web client (if connected)
        try:
            await self._ws_broadcast("approval.request", {
                "session_id": session_id_eff,
                "call_id": call_id,
                "tool": tool,
                "args_preview": args_prev,
                "level": data.get("level"),
                "timeout_sec": timeout_sec,
                "note": data.get("note"),
            })
        except Exception:
            pass

        # Local prompt helper for non-WS approval flow.

        def prompt_cli() -> Tuple[bool, str, Optional[str], Optional[str]]:
            """Return (approved, note, remember, remember_key)."""
            try:
                lvl_i = self._effective_control_level(data if isinstance(data, dict) else None)
                if lvl_i is None:
                    lvl_i = eff_lvl

                if lvl_i == 2:
                    t = str(tool or "").strip().lower()
                    remember_key = None
                    label = t
                    if t == "run_command":
                        base = self._base_command_from_args(args_prev if isinstance(args_prev, dict) else {})
                        if base:
                            label = f"run_command:{base}"
                            remember_key = base
                        else:
                            label = "run_command"
                    else:
                        remember_key = t

                    choice = self._approval_prompt_ui(label, args_prev if isinstance(args_prev, dict) else {})
                    if choice in ("deny", "preview_failed"):
                        note = "Denied via CLI"
                        try:
                            if choice == "preview_failed":
                                msg = str(getattr(self, "_last_approval_error", "") or "").strip()
                                note = msg if msg else "apply_patch preview failed"
                        except Exception:
                            pass
                        self._last_approval_error = None
                        return False, note, None, remember_key

                    # Approved; update local trust registries immediately.
                    try:
                        if t == "run_command" and remember_key:
                            if choice == "session":
                                if remember_key not in self.trust_cmds_session:
                                    self.trust_cmds_session.append(remember_key)
                            elif choice == "always":
                                if remember_key not in self.trust_cmds_always:
                                    self.trust_cmds_always.append(remember_key)
                                self.save_settings()
                        elif t in {"write_file", "append_file", "edit_file", "apply_patch", "string_replace"}:
                            if choice == "session":
                                if t not in self.trust_tools_session:
                                    self.trust_tools_session.append(t)
                            elif choice == "always":
                                if t not in self.trust_tools_always:
                                    self.trust_tools_always.append(t)
                                self.save_settings()
                    except Exception:
                        pass

                    remember = choice if choice in ("session", "always") else "once"
                    return True, "Approved via CLI", remember, remember_key

                # Fallback: simple yes/no confirmation.
                default_yes = False
                prompt = f"Approve {tool} (timeout in {timeout_sec}s)?"
                try:
                    if str(tool).strip().lower() == "run_command":
                        cmd = args_prev.get("cmd") if isinstance(args_prev, dict) else None
                        if isinstance(cmd, str) and cmd.strip():
                            prompt = f"Approve run_command: {self._clip(cmd, 120)} (timeout in {timeout_sec}s)?"
                except Exception:
                    pass
                approved = self.ui.confirm(prompt, default=default_yes)
                return bool(approved), ("Approved via CLI" if approved else "Denied via CLI"), None, None
            except Exception:
                return False, "Denied via CLI (error)", None, None

        # Decide via one authority only:
        # - WS-connected + valid call_id: wait for web reply (no local prompt thread).
        # - Otherwise: prompt locally on the same thread (no executor), which avoids
        #   stale prompts appearing after message.completed.
        decided: Optional[Tuple[Any, ...]] = None
        ws_connected = False
        try:
            ws_connected = bool(self._ws_is_open(getattr(self, "_ws_client", None)))
        except Exception:
            ws_connected = False

        try:
            if ws_connected and call_id is not None:
                try:
                    done_web, _ = await asyncio.wait({fut}, timeout=timeout_sec, return_when=asyncio.FIRST_COMPLETED)
                except Exception:
                    done_web = set()
                if fut in done_web and not fut.cancelled():
                    try:
                        decided = fut.result()
                    except Exception:
                        decided = (False, "Denied via Web (error)")
                else:
                    decided = (False, "Timed out")
                    if not fut.done():
                        try:
                            fut.set_result(decided)
                        except Exception:
                            pass
            else:
                try:
                    decided = prompt_cli()
                except Exception:
                    decided = (False, "Denied via CLI (error)")
                if call_id is not None and not fut.done():
                    try:
                        fut.set_result(decided)
                    except Exception:
                        pass
        finally:
            if call_id is not None:
                self._pending_approvals.pop(str(call_id), None)

        # Normalize decision tuple to (approved, note, remember, remember_key)
        approved = False
        note = ""
        remember = None
        remember_key = None
        try:
            if decided is None:
                approved, note = False, ""
            elif isinstance(decided, tuple) and len(decided) >= 4:
                approved, note, remember, remember_key = decided[0], decided[1], decided[2], decided[3]
            elif isinstance(decided, tuple) and len(decided) >= 2:
                approved, note = decided[0], decided[1]
            else:
                approved, note = bool(decided), ""
        except Exception:
            approved, note = False, ""

        # Post decision to server
        if session_id_eff and call_id is not None:
            try:
                payload = {
                    "session_id": session_id_eff,
                    "call_id": call_id,
                    "approve": bool(approved),
                    "note": note,
                }
                # Optional remember semantics (used to suppress repeat approvals within the current stream).
                try:
                    if bool(approved) and remember in ("session", "always"):
                        payload["remember"] = remember
                        if remember_key:
                            payload["remember_key"] = str(remember_key)
                except Exception:
                    pass
                r = await client.post(self.approvals_url, json=payload, timeout=self.timeout)
                if r.status_code >= 400:
                    self.ui.warn(f"Approval POST failed: {r.status_code} {r.text}")
            except Exception as e:
                self.ui.warn(f"Approval POST error: {e}")
async def amain():
    args = build_arg_parser().parse_args()
    # Set global debug flags from args
    global DEBUG_SSE, DEBUG_REQ
    DEBUG_SSE = bool(getattr(args, 'debug_sse', False))
    DEBUG_REQ = bool(getattr(args, 'debug_req', False))
    # Resolve server base, honoring --dev shortcut
    server_base = getattr(args, 'server', None) or os.getenv("HENOSIS_SERVER", "https://henosis.us/api_v2")
    if getattr(args, 'use_dev', False):
        server_base = os.getenv("HENOSIS_DEV_SERVER", "http://127.0.0.1:8000/api")
    cli = ChatCLI(
        server=server_base,
        model=args.model,
        system_prompt=args.system,
        timeout=args.timeout,
        map_prefix=args.map_prefix,
        verbose=getattr(args, 'verbose', False),
        # Force logging + saving + usage commit by default; no flags needed
        log_enabled=True,
        log_dir=None,
        ctx_window=None,
        save_to_threads=True,
        server_usage_commit=True,
        title=getattr(args, 'title', None),
        # Raw log capture
        raw_log=getattr(args, 'raw_log', False) or (os.getenv('HENOSIS_RAW_LOG', '').strip().lower() in ('1','true','yes','on')),
        raw_log_file=getattr(args, 'raw_log_file', None),
        # Agent Mode flags
        agent_mode=getattr(args, 'agent_mode', False),
        agent_host=getattr(args, 'agent_host', '127.0.0.1'),
        agent_port=getattr(args, 'agent_port', 8700),
        agent_allow_remote=getattr(args, 'agent_allow_remote', False),
        # Multi-terminal
        workspace_dir=getattr(args, 'workspace_dir', None),
        terminal_id=getattr(args, 'terminal_id', None),
        agent_scope=getattr(args, 'agent_scope', None),
    )
    # Handle whoami
    if getattr(args, 'whoami', False):
        authed = await cli.check_auth()
        if authed:
            cli.ui.success(f"Authenticated as: {cli.auth_user}")
        else:
            cli.ui.warn("Not authenticated.")
        return
    # Handle reset-config (local only)
    if getattr(args, 'reset_config', False):
        try:
            if cli.settings_file.exists():
                cli.settings_file.unlink()
                cli.ui.success("Local CLI settings cleared. On next run, onboarding will trigger.")
            else:
                cli.ui.info("No local CLI settings file found.")
        except Exception as e:
            cli.ui.warn(f"Failed to clear settings: {e}")
        # Continue to run (wizard will likely trigger)
    # Version checks (non-fatal, quick)
    if not getattr(args, 'no_update_check', False) and os.getenv("HENOSIS_CLI_NO_UPDATE_CHECK", "") not in ("1", "true", "yes"):
        try:
            # Server compatibility first (uses /health)
            await cli.check_server_version_compatibility()
        except SystemExit:
            raise
        except Exception:
            pass
        try:
            # PyPI latest
            await cli.maybe_check_for_updates()
        except SystemExit:
            raise
        except Exception:
            pass
    await cli.run()


# --- UX Hotfix v2: dependency-free highlighted menus (Enter selects) ---
# This override ensures the settings menu works without RadioList and that Enter
# activates the currently highlighted option even when prompt_toolkit is absent.

def _hn_supports_tty_io_v2() -> bool:
    """Best-effort check for whether arrow-key TTY interaction is likely to work.

    On Windows, many environments misreport TTY capabilities; the `msvcrt` path we
    use for key handling works even when `isatty()` is False (e.g., some
    PowerShell / VS Code terminals). To avoid silently degrading to the numeric
    menu there, we treat Windows as TTY-capable by default and let the
    lower-level key reader decide.

    On POSIX we still respect isatty() to avoid breaking when stdin/stdout are
    redirected (e.g., piping input from a file).
    """
    try:
        # On Windows, assume interactive capabilities and fall back to numeric
        # selection only if key-reading actually fails.
        if os.name == "nt":
            return True
        return sys.stdin.isatty() and sys.stdout.isatty()
    except Exception:
        return False

def _hn_clear_screen_v2() -> None:
    try:
        sys.stdout.write("\x1b[2J\x1b[H")
        sys.stdout.flush()
    except Exception:
        try:
            os.system("cls" if os.name == "nt" else "clear")
        except Exception:
            pass

def _hn_read_key_win_v2():
    try:
        import msvcrt  # type: ignore
    except Exception:
        return None
    while True:
        ch = msvcrt.getwch()
        if ch in ("\x00", "\xe0"):
            code = msvcrt.getwch()
            mapping = {"H": "UP", "P": "DOWN", "I": "PGUP", "Q": "PGDN", "G": "HOME", "O": "END"}
            return mapping.get(code, None)
        if ch == "\r":
            return "ENTER"
        if ch == "\x1b":
            return "ESC"
        if ch.isprintable():
            return ch

def _hn_read_key_posix_v2(fd):
    import termios, tty, select, os as _os
    old = termios.tcgetattr(fd)
    try:
        tty.setcbreak(fd)
        while True:
            r, _, _ = select.select([fd], [], [], 0.5)
            if fd not in r:
                continue
            ch = _os.read(fd, 1)
            if not ch:
                continue
            c = ch.decode(errors="ignore")
            if c == "\x1b":
                seq = _os.read(fd, 2).decode(errors="ignore")
                if seq.startswith("["):
                    rest = seq[1:]
                    if rest and rest[0] in ("A", "B", "H", "F"):
                        return {"A": "UP", "B": "DOWN", "H": "HOME", "F": "END"}[rest[0]]
                    more = _os.read(fd, 2).decode(errors="ignore")
                    if more.startswith("5~"):
                        return "PGUP"
                    if more.startswith("6~"):
                        return "PGDN"
                else:
                    return "ESC"
                continue
            if c in ("\r", "\n"):
                return "ENTER"
            if c.isprintable():
                return c
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)

def _hn_read_key_v2():
    if os.name == "nt":
        try:
            return _hn_read_key_win_v2()
        except Exception:
            return None
    try:
        return _hn_read_key_posix_v2(sys.stdin.fileno())
    except Exception:
        return None

def _hn_render_menu_v2(ui: UI, title: str, text: str, labels: list[str], index: int) -> None:
    _hn_clear_screen_v2()
    ui.header(title, text)
    for i, lbl in enumerate(labels):
        selected = (i == index)
        style = None
        try:
            if ("VERY expensive" in lbl) or ("[DANGER]" in lbl) or ("!!!" in lbl and "expensive" in lbl.lower()):
                style = ui.theme.get("err")
        except Exception:
            style = None
        if selected:
            # Orange selector caret to match CLI project accent color
            try:
                ui.print(" >", style=ui.theme.get("subtitle"), end="")
                ui.print(f" {lbl}", style=style)
            except Exception:
                # Fallback single-line when segmented printing fails
                ui.print(f" > {lbl}", style=style)
        else:
            ui.print(f"   {lbl}", style=style)
    ui.print("\nUp/Down to move • Enter to select • Esc to cancel • 1-9 to jump")

async def _menu_choice_highlight_v2(self, title: str, text: str, choices: list[tuple[str, str]]):  # type: ignore
    def _is_header_value(v: Any) -> bool:
        try:
            return isinstance(v, str) and v.startswith("__hdr_")
        except Exception:
            return False

    def _first_selectable_index() -> int:
        for i, (v, _lbl) in enumerate(choices):
            if not _is_header_value(v):
                return i
        return 0

    def _next_selectable_index(cur: int, step: int) -> int:
        n = len(choices)
        if n <= 0:
            return 0
        idx = cur
        for _ in range(n):
            idx = (idx + step) % n
            if not _is_header_value(choices[idx][0]):
                return idx
        return cur

    # Debug: log which implementation path we're about to use
    try:
        self.ui.debug_log(
            f"[menu-cli] _menu_choice_highlight_v2 start title={title!r} choices={len(choices)} "
            f"HAS_PT={HAS_PT} HAS_RICH={HAS_RICH}"
        )
    except Exception:
        pass

    # prompt_toolkit path (no RadioList), if available
    if HAS_PT and Application and Layout and HSplit and Window and FormattedTextControl and Style and KeyBindings:
        try:
            items = [(val, str(label)) for (val, label) in choices]
            index = _first_selectable_index()

            def _lines():
                out = []
                if title:
                    out.append(("class:menu.title", f"{title}\n"))
                hint = text or "Use \u2191/\u2193, Enter=select, Esc=cancel"
                out.append(("class:menu.hint", hint + "\n"))
                for i, (_v, _lbl) in enumerate(items):
                    if i == index:
                        out.append(("class:menu.item.selected", f"> {_lbl}\n"))
                    else:
                        out.append(("class:menu.item", f"  {_lbl}\n"))
                return out

            root = HSplit([Window(content=FormattedTextControl(_lines))])
            kb = KeyBindings()

            @kb.add("up")
            def _up(event):
                nonlocal index
                index = _next_selectable_index(index, -1)

            @kb.add("down")
            def _down(event):
                nonlocal index
                index = _next_selectable_index(index, +1)

            @kb.add("enter")
            def _enter(event):
                if _is_header_value(items[index][0]):
                    index2 = _next_selectable_index(index, +1)
                    if index2 != index:
                        event.app.exit(result=items[index2][0])
                        return
                event.app.exit(result=items[index][0])

            @kb.add("escape")
            def _esc(event):
                event.app.exit(result=None)

            style = Style.from_dict(
                {
                    "menu.title": "bold",
                    "menu.hint": "fg:#888888",
                    "menu.item.selected": "fg:#ff8700 reverse",
                }
            )
            app = Application(
                layout=Layout(root),
                key_bindings=kb,
                style=style,
                full_screen=False,
            )
            try:
                self.ui.debug_log("[menu-cli] using prompt_toolkit highlight menu (v2)")
            except Exception:
                pass
            return await app.run_async()
        except Exception as e:
            # Log and fall through to dependency-free path
            try:
                self.ui.debug_log(f"[menu-cli] prompt_toolkit path failed: {e}")
            except Exception:
                pass

    # Pure-stdin fallback (dependency-free) with arrow-key support
    labels = [str(lbl) for (_v, lbl) in choices]
    index = _first_selectable_index()
    try:
        self.ui.debug_log(
            f"[menu-cli] using dependency-free highlight fallback; labels={labels}"
        )
    except Exception:
        pass
    _hn_render_menu_v2(self.ui, title, text, labels, index)
    while True:
        key = _hn_read_key_v2()
        try:
            self.ui.debug_log(f"[menu-cli] key={key!r} index={index}")
        except Exception:
            pass
        if key is None:
            # numeric fallback
            self.ui.print("\nNumeric selection fallback.")
            try:
                self.ui.debug_log("[menu-cli] entering numeric fallback path")
            except Exception:
                pass
            for i, lbl in enumerate(labels, start=1):
                self.ui.print(f"{i}. {lbl}")
            while True:
                raw = input("Choose an option: ").strip()
                if raw.lower() in ("q", "quit", "exit"):
                    return None
                if raw.isdigit():
                    idx = int(raw)
                    if 1 <= idx <= len(choices):
                        return choices[idx - 1][0]
                self.ui.warn("Enter a number from the list.")
        elif key == "UP":
            index = _next_selectable_index(index, -1)
            _hn_render_menu_v2(self.ui, title, text, labels, index)
        elif key == "DOWN":
            index = _next_selectable_index(index, +1)
            _hn_render_menu_v2(self.ui, title, text, labels, index)
        elif key == "PGUP":
            index = max(0, index - 7)
            _hn_render_menu_v2(self.ui, title, text, labels, index)
        elif key == "PGDN":
            index = min(len(labels) - 1, index + 7)
            _hn_render_menu_v2(self.ui, title, text, labels, index)
        elif key == "HOME":
            index = _first_selectable_index()
            _hn_render_menu_v2(self.ui, title, text, labels, index)
        elif key == "END":
            index = len(labels) - 1
            if _is_header_value(choices[index][0]):
                index = _next_selectable_index(index, -1)
            _hn_render_menu_v2(self.ui, title, text, labels, index)
        elif key == "ENTER":
            if _is_header_value(choices[index][0]):
                index2 = _next_selectable_index(index, +1)
                if index2 != index:
                    index = index2
                    _hn_render_menu_v2(self.ui, title, text, labels, index)
            try:
                self.ui.debug_log(f"[menu-cli] ENTER on index={index} -> value={choices[index][0]!r}")
            except Exception:
                pass
            return choices[index][0]
        elif key == "ESC":
            try:
                self.ui.debug_log("[menu-cli] ESC -> cancel (None)")
            except Exception:
                pass
            return None
        elif isinstance(key, str) and key.isdigit():
            k = int(key)
            if 1 <= k <= len(labels):
                index = k - 1
                if _is_header_value(choices[index][0]):
                    index = _next_selectable_index(index, +1)
                _hn_render_menu_v2(self.ui, title, text, labels, index)

# Override the menu chooser with the dependency-free version
try:
    ChatCLI._menu_choice = _menu_choice_highlight_v2  # type: ignore[attr-defined]
except Exception:
    pass

if __name__ == "__main__":
    try:
        asyncio.run(amain())
    except KeyboardInterrupt:
        print("\nInterrupted.")

# Entry point for console_scripts
def main() -> None:
    try:
        asyncio.run(amain())
    except KeyboardInterrupt:
        print("\nInterrupted.")




