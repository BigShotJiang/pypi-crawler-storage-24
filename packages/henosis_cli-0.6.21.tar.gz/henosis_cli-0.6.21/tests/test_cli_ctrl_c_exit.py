import asyncio
import importlib


def _make_cli():
    cli_mod = importlib.import_module("cli")
    cli = cli_mod.ChatCLI(
        server="http://127.0.0.1:8000/api",
        model="gpt-5.4",
        system_prompt=None,
        timeout=5.0,
        map_prefix=False,
        log_enabled=False,
        save_to_threads=False,
        server_usage_commit=False,
        verbose=False,
    )
    cli.auth_user = "user@example.com"
    cli.codex_route_all_openai_models = False
    cli.codex_access_token = None
    cli.codex_refresh_token = None
    cli.codex_expiry_date = None
    return cli


def test_run_exits_when_stream_requests_force_exit(monkeypatch):
    cli = _make_cli()
    printed = []
    prompt_calls = {"count": 0}

    def capture_print(*args, **kwargs):
        printed.append(str(args[0]) if args else "")

    async def async_noop(*args, **kwargs):
        return None

    async def fake_check_auth():
        return True

    async def fake_prompt_read(*args, **kwargs):
        prompt_calls["count"] += 1
        if prompt_calls["count"] > 1:
            raise AssertionError("run() should exit after the forced streaming interrupt")
        return "hello from prompt"

    async def fake_run_stream_with_cancel(user_input):
        cli._stream_force_exit = True
        raise KeyboardInterrupt()

    monkeypatch.setattr(cli, "_load_auth_state_from_disk", lambda: None)
    monkeypatch.setattr(cli, "check_auth", fake_check_auth)
    monkeypatch.setattr(cli, "_sync_settings_with_server", async_noop)
    monkeypatch.setattr(cli, "_load_profile_for_tier", async_noop)
    monkeypatch.setattr(cli, "_maybe_run_first_time_wizard", async_noop)
    monkeypatch.setattr(cli, "_offer_generate_code_map", async_noop)
    monkeypatch.setattr(cli, "_cancel_inflight_dispatch", async_noop)
    monkeypatch.setattr(cli, "_ws_broadcast", async_noop)
    monkeypatch.setattr(cli, "_ensure_session_log", lambda: None)
    monkeypatch.setattr(cli, "_commands_word_completer", lambda: None)
    monkeypatch.setattr(cli, "_rebind_agent_scope_default", lambda: None)
    monkeypatch.setattr(cli, "_run_blocking_prompt_read", fake_prompt_read)
    monkeypatch.setattr(cli, "_run_stream_with_cancel", fake_run_stream_with_cancel)
    monkeypatch.setattr(cli.ui, "print", capture_print)
    monkeypatch.setattr(cli.ui, "warn", capture_print)
    monkeypatch.setattr(cli.ui, "info", capture_print)
    monkeypatch.setattr(cli.ui, "success", capture_print)
    monkeypatch.setattr(cli.ui, "error", capture_print)
    monkeypatch.setattr(cli.ui, "header", capture_print)
    monkeypatch.setattr(cli.ui, "header_inline", capture_print)
    cli._input_engine = None

    asyncio.run(cli.run())

    assert prompt_calls["count"] == 1
    assert any(line == "Goodbye." for line in printed)


def test_user_send_turn_is_persisted_into_remote_control_snapshot(monkeypatch):
    cli = _make_cli()
    ws_events = []
    rendered_messages = []

    async def fake_stream_once(user_input):
        cli._remote_last_completed = {
            "model": "gpt-5.4",
            "text": "assistant reply",
            "usage": {},
            "by_category": {},
            "function_logs": [
                {
                    "type": "tool.result",
                    "data": {
                        "name": "read_file",
                        "call_id": "call_1",
                        "result": {"ok": True},
                    },
                }
            ],
            "thinking_insight": {
                "provider": "openai",
                "model": "gpt-5.4",
                "mode": "concise",
                "text": "Checked the file first.",
            },
        }
        return "assistant reply"

    async def fake_ws_broadcast(event_type, data):
        ws_events.append((event_type, dict(data or {})))

    monkeypatch.setattr(cli, "_stream_once", fake_stream_once)
    monkeypatch.setattr(cli, "_ws_broadcast", fake_ws_broadcast)
    monkeypatch.setattr(cli, "_render_remote_originated_user_message", rendered_messages.append)

    asyncio.run(cli._on_ws_message({"type": "user.send", "data": {"text": "hello from web"}}))

    snapshot = cli._build_remote_control_snapshot()

    assert [message.get("content") for message in snapshot.get("messages") or []] == [
        "hello from web",
        "assistant reply",
    ]
    assert rendered_messages == ["hello from web"]
    assert snapshot["messages"][1]["functionLogs"] == [
        {
            "type": "tool.result",
            "data": {
                "name": "read_file",
                "call_id": "call_1",
                "result": {"ok": True},
            },
        }
    ]
    assert snapshot["messages"][1]["thinkingInsight"] == {
        "provider": "openai",
        "model": "gpt-5.4",
        "mode": "concise",
        "text": "Checked the file first.",
    }
    assert any(event_type == "user.message" for event_type, _payload in ws_events)


def test_settings_update_persists_explicit_host_base_and_sends_ack(monkeypatch):
    cli = _make_cli()
    cli.host_base = "C:/old"
    cli._host_base_ephemeral = True
    ws_events = []
    save_payloads = []
    state_pings = []

    async def fake_save_server_settings(settings=None):
        save_payloads.append(settings if settings is not None else cli._collect_settings_dict())
        return True

    async def fake_ws_broadcast(event_type, data):
        ws_events.append((event_type, dict(data or {})))

    async def fake_remote_control_send_state():
        state_pings.append(True)

    monkeypatch.setattr(cli, "_save_server_settings", fake_save_server_settings)
    monkeypatch.setattr(cli, "_ws_broadcast", fake_ws_broadcast)
    monkeypatch.setattr(cli, "_remote_control_send_state", fake_remote_control_send_state)
    monkeypatch.setattr(cli, "_load_codebase_map_raw", lambda: None)

    asyncio.run(
        cli._on_ws_message(
            {
                "type": "settings.update",
                "data": {
                    "request_id": "req-1",
                    "settings": {
                        "host_base": "C:/new-scope",
                        "fs_scope": "host",
                    },
                },
            }
        )
    )

    assert cli.host_base == "C:/new-scope"
    assert cli._host_base_ephemeral is False
    assert save_payloads
    assert save_payloads[0]["host_base"] == "C:/new-scope"
    assert any(
        event_type == "settings.applied"
        and payload.get("request_id") == "req-1"
        and payload.get("ok") is True
        and payload.get("settings", {}).get("host_base") == "C:/new-scope"
        for event_type, payload in ws_events
    )
    assert state_pings == [True]


def test_remote_control_snapshot_does_not_duplicate_active_user_when_queued_copy_exists():
    cli = _make_cli()
    cli._current_turn = cli._empty_current_turn()
    cli._current_turn.update(
        {
            "active": True,
            "user_message": {
                "text": "queued follow-up",
                "model": "gpt-5.4",
                "origin": "web",
            },
            "assistant_so_far": "",
            "tool_events": [],
        }
    )
    cli._remote_control_messages = [
        {
            "role": "user",
            "content": "queued follow-up",
            "model": "gpt-5.4",
            "origin": "web",
        }
    ]

    snapshot = cli._build_remote_control_snapshot()

    assert [message.get("content") for message in snapshot.get("messages") or []] == ["queued follow-up"]
