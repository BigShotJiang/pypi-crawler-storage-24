import asyncio
import copy
import importlib
import json
import threading
import time
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
import pytest


def _new_local_tmp() -> Path:
    base = Path.cwd() / ".pytest_local_tmp"
    base.mkdir(parents=True, exist_ok=True)
    p = base / f"codex-local-{uuid.uuid4().hex[:10]}"
    p.mkdir(parents=True, exist_ok=False)
    return p


def make_cli(tmp_path: Path, reset_state: bool = True):
    cli_mod = importlib.import_module("cli")
    cli = cli_mod.ChatCLI(
        server="http://127.0.0.1:8000/api",
        model=None,
        system_prompt=None,
        timeout=5.0,
        map_prefix=False,
        log_enabled=False,
        save_to_threads=False,
        server_usage_commit=False,
        verbose=False,
    )
    cli.codex_auth_file = tmp_path / "henosis_cli_codex_auth.json"
    cli.codex_shared_auth_file = tmp_path / "codex_shared_auth" / "auth.json"
    if reset_state:
        cli._clear_codex_auth_state_on_disk(clear_shared=False)
    return cli


def test_codex_local_normalize_usage_preserves_cached_tokens():
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    usage = {
        "input_tokens": 120,
        "output_tokens": 30,
        "input_tokens_details": {"cached_tokens": 70},
    }
    out = cli._normalize_usage_for_commit(usage)
    assert int(out.get("prompt_tokens") or 0) == 120
    assert int(out.get("completion_tokens") or 0) == 30
    assert int((out.get("input_tokens_details") or {}).get("cached_tokens") or 0) == 70
    assert int(out.get("cached_input_tokens") or 0) == 70


def test_codex_pkce_pair_has_expected_shape():
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    verifier, challenge = cli._generate_pkce_verifier_challenge()
    assert isinstance(verifier, str) and len(verifier) >= 43
    assert isinstance(challenge, str) and len(challenge) >= 43
    assert "=" not in verifier
    assert "=" not in challenge


def test_codex_auth_roundtrip_persists_local_and_shared():
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli.codex_access_token = "access-token-123"
    cli.codex_refresh_token = "refresh-token-123"
    cli.codex_token_type = "Bearer"
    cli.codex_account_id = "acct_1234567890"
    cli.codex_expiry_date = datetime.now(timezone.utc) + timedelta(hours=1)
    cli.codex_last_refresh_at = datetime.now(timezone.utc)
    cli.codex_id_token = "header.payload.sig"
    cli._save_codex_auth_state_to_disk(sync_shared=True)

    assert cli.codex_auth_file.exists()
    assert cli.codex_shared_auth_file.exists()

    other = make_cli(tmp_path, reset_state=False)
    assert other._load_codex_auth_state_from_disk() is True
    assert other.codex_access_token == "access-token-123"
    assert other.codex_refresh_token == "refresh-token-123"
    assert other.codex_account_id == "acct_1234567890"


def test_codex_import_from_shared_auth_json():
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    shared_payload = {
        "auth_mode": "chatgpt",
        "tokens": {
            "access_token": "imported-access",
            "refresh_token": "imported-refresh",
            "account_id": "acct_from_shared",
        },
        "last_refresh": "2026-02-25T00:00:00Z",
    }
    cli.codex_shared_auth_file.parent.mkdir(parents=True, exist_ok=True)
    cli.codex_shared_auth_file.write_text(json.dumps(shared_payload), encoding="utf-8")

    assert cli._import_codex_auth_json_if_present() is True
    assert cli.codex_access_token == "imported-access"
    assert cli.codex_refresh_token == "imported-refresh"
    assert cli.codex_account_id == "acct_from_shared"
    assert cli.codex_auth_file.exists()


def test_codex_logout_command_clears_files_and_memory():
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli.codex_access_token = "access-token-123"
    cli.codex_refresh_token = "refresh-token-123"
    cli.codex_account_id = "acct_123456"
    cli.codex_expiry_date = datetime.now(timezone.utc) + timedelta(hours=1)
    cli.codex_last_refresh_at = datetime.now(timezone.utc)
    cli._save_codex_auth_state_to_disk(sync_shared=True)
    assert cli.codex_auth_file.exists()
    assert cli.codex_shared_auth_file.exists()

    handled = asyncio.run(cli.handle_command("/codex logout"))
    assert handled is True
    assert cli.codex_access_token is None
    assert cli.codex_refresh_token is None
    assert cli._codex_local_input_items == []
    assert cli._codex_local_last_sent_input_items is None
    assert not cli.codex_auth_file.exists()
    assert not cli.codex_shared_auth_file.exists()


def test_new_alias_clears_history():
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli.system_prompt = "You are helpful."
    cli.history = [
        {"role": "system", "content": "You are helpful."},
        {"role": "user", "content": "hi"},
        {"role": "assistant", "content": "hello"},
    ]
    handled = asyncio.run(cli.handle_command("/new"))
    assert handled is True
    assert cli.history == [{"role": "system", "content": "You are helpful."}]


def test_thinking_alias_sets_reasoning_effort():
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli.reasoning_effort = "medium"

    handled = asyncio.run(cli.handle_command("/thinking high"))

    assert handled is True
    assert cli.reasoning_effort == "high"


def test_codex_model_routing_supports_all_openai_when_enabled():
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli.codex_route_all_openai_models = True
    assert cli._is_codex_local_model("gpt-5.4") is True
    cli.codex_route_all_openai_models = False
    assert cli._is_codex_local_model("gpt-5.4") is False
    assert cli._is_codex_local_model("gpt-5-codex") is True


def test_legacy_gpt_52_aliases_upgrade_to_gpt_54():
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)

    assert cli._resolve_model_alias("gpt-5.2") == "gpt-5.4"
    assert cli._resolve_model_alias("gpt-5.2-pro") == "gpt-5.4-pro"
    assert cli._resolve_model_alias("gpt-4o-mini") == "gpt-5.4-mini-2026-03-17"
    assert cli._resolve_model_alias("gpt-5-mini-2025-08-07") == "gpt-5.4-mini-2026-03-17"
    assert cli._resolve_model_alias("gpt-4.1-nano") == "gpt-5.4-nano-2026-03-17"
    assert cli._resolve_model_alias("gpt-5.4-mini") == "gpt-5.4-mini-2026-03-17"


def test_codex_function_call_parser_does_not_use_provider_item_id_as_call_id():
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    calls = cli._codex_function_calls_from_items(
        [
            {
                "type": "function_call",
                "id": "rs_000abc",
                "name": "read_file",
                "arguments": "{\"path\":\"cli.py\"}",
            }
        ]
    )
    assert len(calls) == 1
    assert calls[0]["name"] == "read_file"
    assert calls[0]["arguments"] == "{\"path\":\"cli.py\"}"
    assert isinstance(calls[0]["call_id"], str) and calls[0]["call_id"].startswith("call_")


def test_codex_local_seed_conversation_items_preserves_prior_tool_chain():
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli._codex_local_input_items = [
        {"role": "user", "content": "prove it"},
        {"type": "function_call", "call_id": "call_1", "name": "read_file", "arguments": "{\"path\":\"cli.py\"}"},
        {"type": "function_call_output", "call_id": "call_1", "output": "{\"ok\":true}"},
        {"role": "assistant", "content": "Done"},
    ]
    input_items = [
        {"role": "user", "content": "prove it"},
        {"role": "assistant", "content": "Done"},
        {"role": "user", "content": "what is last thing we define"},
    ]

    seeded = cli._codex_local_seed_conversation_items(input_items, "fallback user")
    assert seeded[-1] == {"role": "user", "content": "what is last thing we define"}
    assert any(
        isinstance(it, dict)
        and it.get("type") == "function_call_output"
        and it.get("call_id") == "call_1"
        for it in seeded
    )


def test_codex_local_seed_conversation_items_falls_back_to_input_items():
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli._codex_local_input_items = []
    input_items = [
        {"role": "user", "content": "u1"},
        {"role": "assistant", "content": "a1"},
        {"role": "user", "content": "u2"},
    ]

    seeded = cli._codex_local_seed_conversation_items(input_items, "fallback user")
    assert seeded == input_items
    assert seeded is not input_items


def test_codex_models_have_context_window_fallbacks():
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    assert isinstance(cli._get_model_ctx_window("gpt-5.3-codex"), int)
    assert int(cli._get_model_ctx_window("gpt-5.3-codex") or 0) > 0


def test_codex_rollover_continue_seeds_backend_payload_from_local_chain(monkeypatch):
    tmp_path = _new_local_tmp()
    cli_mod = importlib.import_module("cli")
    cli = make_cli(tmp_path)
    cli.model = "gpt-5.3-codex"
    cli.auth_user = "user@example.com"
    cli.codex_access_token = "access-token-123"
    cli.codex_refresh_token = "refresh-token-123"
    cli.codex_account_id = "acct_123456"
    cli._codex_local_input_items = [
        {"role": "user", "content": "prove it"},
        {"type": "function_call", "call_id": "call_1", "name": "read_file", "arguments": "{\"path\":\"cli.py\"}"},
        {"type": "function_call_output", "call_id": "call_1", "output": "{\"ok\":true}"},
        {"role": "assistant", "content": "Done"},
    ]

    captured: dict = {}

    class _CaptureStopResponse:
        status_code = 200
        headers = {"content-type": "text/event-stream"}
        text = ""

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        def raise_for_status(self):
            raise RuntimeError("stop after capture")

        async def aiter_lines(self):
            if False:
                yield ""

    class _CaptureAsyncClient:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        def stream(self, method, url, json=None, headers=None, follow_redirects=None):
            captured["method"] = method
            captured["url"] = url
            captured["json"] = json
            captured["headers"] = headers
            return _CaptureStopResponse()

    async def fake_local_codex(user_input: str):
        raise RuntimeError(
            'Codex stream failed (429): {"error":{"type":"usage_limit_reached","resets_in_seconds":120}}'
        )

    async def fake_menu_choice(*args, **kwargs):
        return "continue"

    monkeypatch.setattr(cli_mod.httpx, "AsyncClient", _CaptureAsyncClient)
    monkeypatch.setattr(cli, "_stream_codex_local_once", fake_local_codex)
    monkeypatch.setattr(cli, "_menu_choice", fake_menu_choice)

    with pytest.raises(RuntimeError, match="stop after capture"):
        asyncio.run(cli._stream_once("what is last thing we define"))

    payload = captured["json"]
    assert payload["openai_input_items"][: len(cli._codex_local_input_items)] == cli._codex_local_input_items
    assert payload["openai_input_items"][-1]["role"] == "user"
    assert payload["openai_input_items"][-1]["content"].endswith("what is last thing we define")
    assert payload["messages"][-1]["role"] == "user"
    assert payload["messages"][-1]["content"].endswith("what is last thing we define")
    assert cli._codex_force_backend_for_conversation is True
    assert cli._codex_backend_rollover_pending_seed is False
    assert cli._should_use_local_codex_for_model(cli.model) is False


def test_codex_rollover_override_clears_on_clear():
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli.model = "gpt-5.3-codex"
    cli.codex_access_token = "access-token-123"
    cli.codex_refresh_token = "refresh-token-123"
    cli._activate_codex_backend_rollover()

    assert cli._should_use_local_codex_for_model(cli.model) is False

    handled = asyncio.run(cli.handle_command("/clear"))

    assert handled is True
    assert cli._codex_force_backend_for_conversation is False
    assert cli._codex_backend_rollover_pending_seed is False
    assert cli._should_use_local_codex_for_model(cli.model) is True


def test_codex_rollover_prompt_label_reflects_backend_credits_mode():
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)

    assert cli._chat_prompt_label() == "You: "
    assert cli._edit_prompt_label() == "Edit> "

    cli._activate_codex_backend_rollover()

    assert cli._chat_prompt_label() == "You [backend credits]: "
    assert cli._edit_prompt_label() == "Edit [backend credits]> "


def test_codex_local_proactive_handoff_resets_context_before_next_request(monkeypatch):
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli.model = "gpt-5.3-codex"
    cli.ctx_window = 100
    cli.context_near_full_pct = 0.2
    cli.local_workspace_dir = str(tmp_path)
    cli._codex_local_input_items = [
        {"role": "user", "content": "x" * 600},
        {"role": "assistant", "content": "large prior turn"},
    ]

    captured = []

    async def fake_stream_request(*, req_payload, http_timeout):
        tools = req_payload.get("tools") or []
        tool_names = [t.get("name") for t in tools if isinstance(t, dict)]
        captured.append(
            {
                "tool_names": tool_names,
                "input": req_payload.get("input") or [],
            }
        )
        if tool_names == ["context_handoff"]:
            return {
                "model_used": "gpt-5.3-codex",
                "text_chunks": [],
                "output_items": [
                    {
                        "type": "function_call",
                        "call_id": "call_handoff",
                        "name": "context_handoff",
                        "arguments": json.dumps(
                            {
                                "reason": "near_full",
                                "keep_notes": "Continue the task from the retained checkpoint.",
                                "keep_files": ["keep.txt"],
                            }
                        ),
                    }
                ],
                "usage": {"prompt_tokens": 11, "completion_tokens": 2, "total_tokens": 13},
            }
        return {
            "model_used": "gpt-5.3-codex",
            "text_chunks": [],
            "output_items": [
                {
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": "done"}],
                }
            ],
            "usage": {"prompt_tokens": 20, "completion_tokens": 5, "total_tokens": 25},
        }

    monkeypatch.setattr(cli, "_codex_local_stream_request", fake_stream_request)
    monkeypatch.setattr(
        cli,
        "_codex_local_read_retained_files",
        lambda *, keep_files, policy: [("keep.txt", "retained context")],
    )

    out = asyncio.run(cli._stream_codex_local_once("ship it"))

    assert out == "done"
    assert captured[0]["tool_names"] == ["context_handoff"]
    assert "reason='near_full'" in captured[0]["input"][-1]["content"]
    resumed_prompt = captured[1]["input"][-1]["content"]
    assert "<keep_notes><![CDATA[" in resumed_prompt
    assert "Continue the task from the retained checkpoint." in resumed_prompt
    assert 'path="keep.txt"' in resumed_prompt
    assert "retained context" in resumed_prompt
    assert cli._codex_local_input_items[0]["role"] == "user"
    assert "<resume_instructions>" in cli._codex_local_input_items[0]["content"]


def test_codex_local_proactive_handoff_overflow_retries_with_backoff(monkeypatch):
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli.model = "gpt-5.3-codex"
    cli.ctx_window = 100
    cli.context_near_full_pct = 0.2
    cli.local_workspace_dir = str(tmp_path)
    cli._codex_local_input_items = [
        {"role": "user", "content": "x" * 600},
        {
            "type": "function_call",
            "call_id": "c_prev",
            "name": "read_file",
            "arguments": json.dumps({"path": "a.py"}),
        },
        {"type": "function_call_output", "call_id": "c_prev", "output": "{\"ok\":true}"},
    ]

    captured = []
    handoff_attempts = {"count": 0}

    async def fake_stream_request(*, req_payload, http_timeout):
        tools = req_payload.get("tools") or []
        tool_names = [t.get("name") for t in tools if isinstance(t, dict)]
        captured.append(
            {
                "tool_names": tool_names,
                "input": req_payload.get("input") or [],
            }
        )
        if tool_names == ["context_handoff"]:
            handoff_attempts["count"] += 1
            if handoff_attempts["count"] == 1:
                raise RuntimeError(
                    "Your input exceeds the context window of this model. Please adjust your input and try again."
                )
            return {
                "model_used": "gpt-5.3-codex",
                "text_chunks": [],
                "output_items": [
                    {
                        "type": "function_call",
                        "call_id": "call_handoff_retry",
                        "name": "context_handoff",
                        "arguments": json.dumps(
                            {
                                "reason": "context_length_exceeded",
                                "keep_notes": "Resume after proactive overflow using backoff.",
                                "keep_files": ["keep.txt"],
                            }
                        ),
                    }
                ],
                "usage": {"prompt_tokens": 10, "completion_tokens": 2, "total_tokens": 12},
            }
        return {
            "model_used": "gpt-5.3-codex",
            "text_chunks": [],
            "output_items": [
                {
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": "done"}],
                }
            ],
            "usage": {"prompt_tokens": 15, "completion_tokens": 3, "total_tokens": 18},
        }

    monkeypatch.setattr(cli, "_codex_local_stream_request", fake_stream_request)
    monkeypatch.setattr(
        cli,
        "_codex_local_read_retained_files",
        lambda *, keep_files, policy: [("keep.txt", "retained after proactive overflow")],
    )

    out = asyncio.run(cli._stream_codex_local_once("continue"))

    assert out == "done"
    assert captured[0]["tool_names"] == ["context_handoff"]
    assert "reason='near_full'" in captured[0]["input"][-1]["content"]
    assert captured[1]["tool_names"] == ["context_handoff"]
    retry_prompt = captured[1]["input"][-1]["content"]
    assert "reason='context_length_exceeded'" in retry_prompt
    assert "Action that overflowed context:" in retry_prompt
    assert "tool=read_file" in retry_prompt
    assert len(captured[1]["input"]) < len(captured[0]["input"])
    resumed_prompt = captured[2]["input"][-1]["content"]
    assert "Resume after proactive overflow using backoff." in resumed_prompt
    assert "retained after proactive overflow" in resumed_prompt


def test_codex_local_overflow_recovery_uses_context_handoff(monkeypatch):
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli.model = "gpt-5.3-codex"
    cli.ctx_window = 400000
    cli.local_workspace_dir = str(tmp_path)

    captured = []
    normal_attempts = {"count": 0}

    async def fake_stream_request(*, req_payload, http_timeout):
        tools = req_payload.get("tools") or []
        tool_names = [t.get("name") for t in tools if isinstance(t, dict)]
        captured.append(
            {
                "tool_names": tool_names,
                "input": req_payload.get("input") or [],
            }
        )
        if tool_names == ["context_handoff"]:
            return {
                "model_used": "gpt-5.3-codex",
                "text_chunks": [],
                "output_items": [
                    {
                        "type": "function_call",
                        "call_id": "call_overflow_handoff",
                        "name": "context_handoff",
                        "arguments": json.dumps(
                            {
                                "reason": "context_length_exceeded",
                                "keep_notes": "Resume after overflow using the compact handoff.",
                                "keep_files": ["keep.txt"],
                            }
                        ),
                    }
                ],
                "usage": {"prompt_tokens": 12, "completion_tokens": 3, "total_tokens": 15},
            }
        normal_attempts["count"] += 1
        if normal_attempts["count"] == 1:
            raise RuntimeError(
                "Your input exceeds the context window of this model. Please adjust your input and try again."
            )
        return {
            "model_used": "gpt-5.3-codex",
            "text_chunks": [],
            "output_items": [
                {
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": "recovered"}],
                }
            ],
            "usage": {"prompt_tokens": 18, "completion_tokens": 4, "total_tokens": 22},
        }

    monkeypatch.setattr(cli, "_codex_local_stream_request", fake_stream_request)
    monkeypatch.setattr(
        cli,
        "_codex_local_read_retained_files",
        lambda *, keep_files, policy: [("keep.txt", "overflow recovery file")],
    )

    out = asyncio.run(cli._stream_codex_local_once("continue"))

    assert out == "recovered"
    assert captured[0]["tool_names"] != ["context_handoff"]
    assert captured[1]["tool_names"] == ["context_handoff"]
    assert "reason='context_length_exceeded'" in captured[1]["input"][-1]["content"]
    resumed_prompt = captured[2]["input"][-1]["content"]
    assert "<keep_notes><![CDATA[" in resumed_prompt
    assert "Resume after overflow using the compact handoff." in resumed_prompt
    assert 'path="keep.txt"' in resumed_prompt
    assert "overflow recovery file" in resumed_prompt


def test_codex_local_reports_last_turn_tokens_not_chain_tokens(monkeypatch):
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli.model = "gpt-5.3-codex"
    cli.ctx_window = 100000
    cli.status_fields = ["turn-tokens", "session-tokens"]
    cli._cum_input_tokens = 100
    cli._cum_output_tokens = 40
    cli._cum_total_tokens = 140

    call_idx = {"n": 0}
    rendered_ctx: dict = {}

    async def fake_stream_request(*, req_payload, http_timeout):
        call_idx["n"] += 1
        if call_idx["n"] == 1:
            return {
                "model_used": "gpt-5.3-codex",
                "text_chunks": [],
                "output_items": [
                    {
                        "type": "function_call",
                        "call_id": "call_read",
                        "name": "list_dir",
                        "arguments": json.dumps({"path": "."}),
                    }
                ],
                "usage": {"prompt_tokens": 50, "completion_tokens": 5, "total_tokens": 55},
            }
        return {
            "model_used": "gpt-5.3-codex",
            "text_chunks": [],
            "output_items": [
                {
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": "done"}],
                }
            ],
            "usage": {"prompt_tokens": 7, "completion_tokens": 3, "total_tokens": 10},
        }

    monkeypatch.setattr(cli, "_codex_local_stream_request", fake_stream_request)
    monkeypatch.setattr(cli, "_render_status_info", lambda ctx: rendered_ctx.update(ctx))

    out = asyncio.run(cli._stream_codex_local_once("ship it"))

    assert out == "done"
    # Last-turn display should reflect only the final assistant-producing request.
    assert int(cli._cum_input_tokens or 0) == 157
    assert int(cli._cum_output_tokens or 0) == 48
    assert int(cli._cum_total_tokens or 0) == 205

    assert rendered_ctx.get("turn_tokens_line") == "Turn tokens: in 7 + out 3 = 10"
    assert rendered_ctx.get("session_tokens_line") == "Session tokens: in 157 + out 48 = 205"


def test_codex_reasoning_extractors_parse_summary_event_and_items():
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)

    ev_text = cli._codex_reasoning_summary_from_event(
        "response.reasoning_summary.delta",
        {"delta": {"text": "reasoning from delta"}},
    )
    assert "reasoning from delta" in ev_text

    ev_text_alt = cli._codex_reasoning_summary_from_event(
        "response.reasoning.delta",
        {"delta": {"text": "reasoning from alternate event"}},
    )
    assert "reasoning from alternate event" in ev_text_alt

    items_text = cli._codex_reasoning_text_from_items(
        [
            {
                "type": "reasoning",
                "summary": [{"type": "summary_text", "text": "reasoning from item"}],
            },
            {
                "type": "message",
                "role": "assistant",
                "content": [{"type": "output_text", "text": "final answer"}],
            },
        ]
    )
    assert "reasoning from item" in items_text
    assert "final answer" not in items_text

    collapsed = cli._codex_collapse_reasoning_blocks(
        [
            "**Preparing",
            "friendly",
            "greeting**",
            "**Preparing friendly greeting**",
        ]
    )
    assert collapsed == "**Preparing friendly greeting**"

    not_subsumed = cli._codex_collapse_reasoning_blocks(
        [
            "first branch reasoning",
            "second branch reasoning",
        ]
    )
    assert "first branch reasoning" in not_subsumed
    assert "second branch reasoning" in not_subsumed


def test_codex_local_stream_renders_thinking_insight_and_requests_summary(monkeypatch):
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli.model = "gpt-5.3-codex"
    cli.thinking_insight_enabled = True

    captured_payload: dict = {}
    printed: list = []

    async def fake_stream_request(*, req_payload, http_timeout):
        captured_payload.update(req_payload)
        return {
            "model_used": "gpt-5.3-codex",
            "text_chunks": [],
            "output_items": [
                {
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": "done"}],
                }
            ],
            "thinking_text": "local codex reasoning summary",
            "usage": {"prompt_tokens": 7, "completion_tokens": 3, "total_tokens": 10},
        }

    monkeypatch.setattr(cli, "_codex_local_stream_request", fake_stream_request)
    def _capture_print(*args, **kwargs):
        printed.append({"text": str(args[0]) if args else "", "kwargs": dict(kwargs)})

    monkeypatch.setattr(cli.ui, "print", _capture_print)

    out = asyncio.run(cli._stream_codex_local_once("ship it"))

    assert out == "done"
    reasoning_obj = captured_payload.get("reasoning") or {}
    assert isinstance(reasoning_obj, dict)
    assert reasoning_obj.get("summary") == "auto"
    assert any("Thinking (openai/summary):" in p["text"] for p in printed)
    assert any("local codex reasoning summary" in p["text"] for p in printed)
    thinking_idx = next(
        i for i, p in enumerate(printed) if "Thinking (openai/summary):" in p["text"]
    )
    output_idx = next(i for i, p in enumerate(printed) if "done" in p["text"])
    assert thinking_idx < output_idx
    assert any(
        "Thinking (openai/summary):" in p["text"] and bool(p["kwargs"].get("force"))
        for p in printed
    )


def test_codex_local_stream_renders_thinking_before_tool_result(monkeypatch):
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli.model = "gpt-5.3-codex"
    cli.thinking_insight_enabled = True
    cli.requested_tools = True

    printed: list = []
    call_idx = {"n": 0}

    async def fake_stream_request(*, req_payload, http_timeout):
        call_idx["n"] += 1
        if call_idx["n"] == 1:
            return {
                "model_used": "gpt-5.3-codex",
                "text_chunks": [],
                "output_items": [
                    {
                        "type": "function_call",
                        "call_id": "call_read",
                        "name": "read_file",
                        "arguments": json.dumps({"path": "cli.py"}),
                    }
                ],
                "thinking_text": "inspect the file before the tool result",
                "usage": {"prompt_tokens": 9, "completion_tokens": 2, "total_tokens": 11},
            }
        return {
            "model_used": "gpt-5.3-codex",
            "text_chunks": [],
            "output_items": [
                {
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": "done"}],
                }
            ],
            "thinking_text": "",
            "usage": {"prompt_tokens": 6, "completion_tokens": 2, "total_tokens": 8},
        }

    def _capture_print(*args, **kwargs):
        printed.append({"text": str(args[0]) if args else "", "kwargs": dict(kwargs)})

    monkeypatch.setattr(cli, "_codex_local_stream_request", fake_stream_request)
    monkeypatch.setattr(
        cli,
        "_execute_local_tool_call",
        lambda name, args, level, requested_policy: {"ok": True, "data": {"content": "stub"}},
    )
    monkeypatch.setattr(cli.ui, "print", _capture_print)

    out = asyncio.run(cli._stream_codex_local_once("ship it"))

    assert out == "done"
    thinking_idx = next(
        i for i, p in enumerate(printed) if "Thinking (openai/summary):" in p["text"]
    )
    tool_result_idx = next(i for i, p in enumerate(printed) if "[SUCCESS]" in p["text"])
    assert thinking_idx < tool_result_idx


def test_codex_local_stream_renders_thinking_empty_status(monkeypatch):
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli.model = "gpt-5.3-codex"
    cli.thinking_insight_enabled = True

    printed: list = []

    async def fake_stream_request(*, req_payload, http_timeout):
        return {
            "model_used": "gpt-5.3-codex",
            "text_chunks": [],
            "output_items": [
                {
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": "done"}],
                }
            ],
            "thinking_text": "",
            "thinking_meta": {
                "reasoning_event_types": ["response.reasoning.delta"],
                "reasoning_events_seen": 2,
                "reasoning_delta_chars": 0,
                "thinking_text_chars": 0,
            },
            "usage": {"prompt_tokens": 7, "completion_tokens": 3, "total_tokens": 10},
        }

    monkeypatch.setattr(cli, "_codex_local_stream_request", fake_stream_request)
    def _capture_print(*args, **kwargs):
        printed.append({"text": str(args[0]) if args else "", "kwargs": dict(kwargs)})

    monkeypatch.setattr(cli.ui, "print", _capture_print)

    out = asyncio.run(cli._stream_codex_local_once("ship it"))

    assert out == "done"
    assert any("Thinking (openai/summary):" in p["text"] for p in printed)
    assert any("none emitted by provider for this turn" in p["text"].lower() for p in printed)
    assert any(
        "Thinking (openai/summary):" in p["text"] and bool(p["kwargs"].get("force"))
        for p in printed
    )
    assert any(
        "none emitted by provider for this turn" in p["text"].lower() and bool(p["kwargs"].get("force"))
        for p in printed
    )


def test_backend_stream_renders_thinking_empty_status_when_enabled(monkeypatch):
    tmp_path = _new_local_tmp()
    cli_mod = importlib.import_module("cli")
    cli = make_cli(tmp_path)
    cli.model = "gpt-5.4"
    cli.auth_user = "user@example.com"
    cli.codex_route_all_openai_models = False
    cli.codex_access_token = None
    cli.codex_refresh_token = None
    cli.codex_expiry_date = None
    cli.thinking_insight_enabled = True
    printed = []

    def _capture_print(*args, **kwargs):
        printed.append({"text": str(args[0]) if args else "", "kwargs": dict(kwargs)})

    monkeypatch.setattr(cli.ui, "print", _capture_print)

    class _FakeStreamResp:
        status_code = 200
        headers = {"content-type": "text/event-stream"}
        text = ""

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        def raise_for_status(self):
            return None

        async def aiter_lines(self):
            payload_completed = {
                "model": "gpt-5.4",
                "usage": {"prompt_tokens": 5, "completion_tokens": 2, "total_tokens": 7},
                "text": "Hello world",
            }
            lines = [
                "event: message.completed",
                "data: " + json.dumps(payload_completed),
                "",
            ]
            for line in lines:
                yield line

    class _FakeAsyncClient:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        def stream(self, method, url, json=None, headers=None, follow_redirects=None):
            return _FakeStreamResp()

    monkeypatch.setattr(cli_mod.httpx, "AsyncClient", _FakeAsyncClient)

    out = asyncio.run(cli._stream_once("say hello"))

    assert out == "Hello world"
    assert any("Thinking (summary):" in p["text"] for p in printed)
    assert any("none emitted by provider for this turn" in p["text"].lower() for p in printed)
    assert any(
        "Thinking (summary):" in p["text"] and bool(p["kwargs"].get("force"))
        for p in printed
    )
    assert any(
        "none emitted by provider for this turn" in p["text"].lower() and bool(p["kwargs"].get("force"))
        for p in printed
    )


def test_backend_stream_renders_thinking_before_first_assistant_delta(monkeypatch):
    tmp_path = _new_local_tmp()
    cli_mod = importlib.import_module("cli")
    cli = make_cli(tmp_path)
    cli.model = "gpt-5.4"
    cli.auth_user = "user@example.com"
    cli.codex_route_all_openai_models = False
    cli.codex_access_token = None
    cli.codex_refresh_token = None
    cli.codex_expiry_date = None
    cli.thinking_insight_enabled = True

    printed = []

    def _capture_print(*args, **kwargs):
        printed.append({"text": str(args[0]) if args else "", "kwargs": dict(kwargs)})

    monkeypatch.setattr(cli.ui, "print", _capture_print)

    class _FakeStreamResp:
        status_code = 200
        headers = {"content-type": "text/event-stream"}
        text = ""

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        def raise_for_status(self):
            return None

        async def aiter_lines(self):
            payload_completed = {
                "model": "gpt-5.4",
                "usage": {"prompt_tokens": 5, "completion_tokens": 2, "total_tokens": 7},
            }
            lines = [
                "event: thinking.insight",
                'data: {"provider":"openai","mode":"summary","text":"plan before answer"}',
                "",
                "event: message.delta",
                'data: {"model":"gpt-5.4","text":"Hello "}',
                "",
                "event: message.delta",
                'data: {"text":"world"}',
                "",
                "event: message.completed",
                "data: " + json.dumps(payload_completed),
                "",
            ]
            for line in lines:
                yield line

    class _FakeAsyncClient:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        def stream(self, method, url, json=None, headers=None, follow_redirects=None):
            return _FakeStreamResp()

    monkeypatch.setattr(cli_mod.httpx, "AsyncClient", _FakeAsyncClient)

    out = asyncio.run(cli._stream_once("say hello"))

    assert out == "Hello world"
    thinking_label_idx = next(
        i for i, p in enumerate(printed) if "Thinking (openai/summary):" in p["text"]
    )
    thinking_text_idx = next(i for i, p in enumerate(printed) if "plan before answer" in p["text"])
    header_idx = next(i for i, p in enumerate(printed) if p["text"].startswith("gpt-5.4:"))
    assert thinking_label_idx < header_idx
    assert thinking_text_idx < header_idx
    assert sum(1 for p in printed if "Thinking (openai/summary):" in p["text"]) == 1


def test_backend_stream_sends_thinking_summary_passthrough(monkeypatch):
    tmp_path = _new_local_tmp()
    cli_mod = importlib.import_module("cli")
    cli = make_cli(tmp_path)
    cli.model = "gpt-5.4"
    cli.auth_user = "user@example.com"
    cli.codex_route_all_openai_models = False
    cli.codex_access_token = None
    cli.codex_refresh_token = None
    cli.codex_expiry_date = None
    cli.thinking_insight_enabled = True
    cli.thinking_insight_summary = "detailed"
    captured: dict = {}

    class _FakeStreamResp:
        status_code = 200
        headers = {"content-type": "text/event-stream"}
        text = ""

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        def raise_for_status(self):
            return None

        async def aiter_lines(self):
            payload_completed = {
                "model": "gpt-5.4",
                "usage": {"prompt_tokens": 5, "completion_tokens": 2, "total_tokens": 7},
                "text": "ok",
            }
            lines = [
                "event: message.completed",
                "data: " + json.dumps(payload_completed),
                "",
            ]
            for line in lines:
                yield line

    class _FakeAsyncClient:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        def stream(self, method, url, json=None, headers=None, follow_redirects=None):
            captured["json"] = dict(json or {})
            return _FakeStreamResp()

    monkeypatch.setattr(cli_mod.httpx, "AsyncClient", _FakeAsyncClient)

    out = asyncio.run(cli._stream_once("say hello"))

    assert out == "ok"
    assert captured.get("json", {}).get("thinking_insight_summary") == "detailed"


def test_priority_alias_updates_service_tier():
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)

    handled = asyncio.run(cli.handle_command("/fast on"))

    assert handled is True
    assert cli.service_tier == "priority"


def test_codex_local_priority_sets_service_tier_payload(monkeypatch):
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli.model = "gpt-5.3-codex"
    cli.service_tier = "priority"
    captured_payload: dict = {}

    async def fake_stream_request(*, req_payload, http_timeout):
        captured_payload.update(req_payload)
        return {
            "model_used": "gpt-5.3-codex",
            "text_chunks": [],
            "output_items": [
                {
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": "done"}],
                }
            ],
            "usage": {"prompt_tokens": 7, "completion_tokens": 3, "total_tokens": 10},
        }

    monkeypatch.setattr(cli, "_codex_local_stream_request", fake_stream_request)

    out = asyncio.run(cli._stream_codex_local_once("ship it"))

    assert out == "done"
    assert captured_payload.get("service_tier") == "priority"


def test_codex_local_message_completed_broadcast_includes_text(monkeypatch):
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli.model = "gpt-5.3-codex"
    events = []

    async def fake_stream_request(*, req_payload, http_timeout):
        return {
            "model_used": "gpt-5.3-codex",
            "text_chunks": [],
            "output_items": [
                {
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": "Remote reply"}],
                }
            ],
            "usage": {"prompt_tokens": 7, "completion_tokens": 3, "total_tokens": 10},
        }

    async def fake_ws_broadcast(event_type, data):
        events.append((event_type, dict(data or {})))

    monkeypatch.setattr(cli, "_codex_local_stream_request", fake_stream_request)
    monkeypatch.setattr(cli, "_ws_broadcast", fake_ws_broadcast)

    out = asyncio.run(cli._stream_codex_local_once("say hello"))

    assert out == "Remote reply"
    completed = next(payload for event_type, payload in events if event_type == "message.completed")
    assert completed["text"] == "Remote reply"


def test_transient_tool_status_is_suspended_while_input_prompt_is_active():
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli.show_tool_calls = True
    cli._input_prompt_active = True

    assert cli._should_suspend_transient_tool_status() is True
    assert cli._render_tool_running_transient("read_file", {"path": "cli.py"}) is False

    cli._input_prompt_active = False

    assert cli._should_suspend_transient_tool_status() is False


def test_busy_input_reader_marks_prompt_active_while_waiting():
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli.show_tool_calls = True
    entered = threading.Event()
    release = threading.Event()

    class _FakeBusyInputEngine:
        def read_message(
            self,
            prompt_label: str = "\nYou: ",
            cont_label: str = "... ",
            stop_event=None,
            initial_text: str = "",
        ) -> str:
            entered.set()
            while not release.is_set():
                if stop_event is not None and stop_event.is_set():
                    break
                time.sleep(0.01)
            return ""

    cli._input_engine = _FakeBusyInputEngine()

    async def _run() -> None:
        cli._busy = True
        await cli._start_busy_input_reader()
        assert await asyncio.to_thread(entered.wait, 1.0)
        assert cli._input_prompt_active is True
        assert cli._input_prompt_label == cli._chat_prompt_label()
        assert cli._should_suspend_transient_tool_status() is True
        assert cli._render_tool_running_transient("read_file", {"path": "cli.py"}) is False
        cli._busy = False
        release.set()
        await cli._stop_busy_input_reader()
        assert cli._input_prompt_active is False
        assert cli._input_prompt_label is None

    asyncio.run(_run())


def test_queued_user_message_injection_replays_raw_user_texts(monkeypatch):
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli.model = "gpt-5.3-codex"

    ws_events = []
    remote_messages = []

    async def fake_ws_broadcast(event_type, data):
        ws_events.append((event_type, dict(data or {})))

    monkeypatch.setattr(cli, "_ws_broadcast", fake_ws_broadcast)
    monkeypatch.setattr(
        cli,
        "_remote_control_append_message",
        lambda role, content, **kwargs: remote_messages.append(
            {"role": role, "content": content, **dict(kwargs)}
        ),
    )

    first = cli._enqueue_user_message("first queued note", origin="cli", model="gpt-5.3-codex")
    second = cli._enqueue_user_message("second queued note", origin="web", model="gpt-5.3-codex")

    asyncio.run(cli._announce_queued_user_message_injection([first, second], "combined prompt", announcement="Inject now"))

    injected_payload = next(payload for event_type, payload in ws_events if event_type == "user.message.injected")
    assert injected_payload["text"] == "combined prompt"
    assert injected_payload["queued_texts"] == ["first queued note", "second queued note"]
    assert [m["content"] for m in remote_messages] == ["first queued note", "second queued note"]
    assert remote_messages[0]["origin"] == "cli"
    assert remote_messages[1]["origin"] == "web"


def test_codex_local_injects_queued_messages_after_tool_turn(monkeypatch):
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli.model = "gpt-5.3-codex"
    cli.requested_tools = True

    payload_inputs = []
    ws_events = []
    stream_calls = {"n": 0}

    async def fake_stream_request(*, req_payload, http_timeout):
        payload_inputs.append(copy.deepcopy(req_payload.get("input") or []))
        stream_calls["n"] += 1
        if stream_calls["n"] == 1:
            return {
                "model_used": "gpt-5.3-codex",
                "text_chunks": [],
                "output_items": [
                    {
                        "type": "function_call",
                        "call_id": "call_read",
                        "name": "read_file",
                        "arguments": json.dumps({"path": "cli.py"}),
                    }
                ],
                "usage": {"prompt_tokens": 4, "completion_tokens": 1, "total_tokens": 5},
            }
        return {
            "model_used": "gpt-5.3-codex",
            "text_chunks": [],
            "output_items": [
                {
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": "done"}],
                }
            ],
            "usage": {"prompt_tokens": 3, "completion_tokens": 2, "total_tokens": 5},
        }

    async def fake_ws_broadcast(event_type, data):
        ws_events.append((event_type, dict(data or {})))

    monkeypatch.setattr(cli, "_codex_local_stream_request", fake_stream_request)
    monkeypatch.setattr(
        cli,
        "_execute_local_tool_call",
        lambda name, args, level, requested_policy: {"ok": True, "data": {"content": "stub"}},
    )
    monkeypatch.setattr(cli, "_ws_broadcast", fake_ws_broadcast)
    monkeypatch.setattr(cli, "_remote_control_append_message", lambda *args, **kwargs: None)

    cli._enqueue_user_message("queued follow-up", origin="web", model="gpt-5.3-codex")

    out = asyncio.run(cli._stream_codex_local_once("ship it"))

    assert out == "done"
    assert len(payload_inputs) == 2
    assert payload_inputs[0][-1]["role"] == "user"
    assert payload_inputs[0][-1]["content"].endswith("ship it")
    assert payload_inputs[1][-2]["type"] == "function_call_output"
    assert payload_inputs[1][-1]["role"] == "user"
    assert "queued follow-up" in payload_inputs[1][-1]["content"]
    assert next(payload for event_type, payload in ws_events if event_type == "user.message.injected")["queued_texts"] == ["queued follow-up"]


def test_busy_input_queue_rewrites_prompt_below_tool_output(monkeypatch):
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli.show_tool_calls = True
    cli._busy = True
    cli._busy_input_prefill = ""

    writes = []
    flushes = []
    entered = threading.Event()

    class _StdoutCapture:
        def write(self, text):
            writes.append(str(text))
            return len(str(text))

        def flush(self):
            flushes.append(True)

    class _FakeBusyInputEngine:
        def __init__(self):
            self.calls = 0

        def read_message(
            self,
            prompt_label: str = "\nYou: ",
            cont_label: str = "... ",
            stop_event=None,
            initial_text: str = "",
        ) -> str:
            self.calls += 1
            entered.set()
            if self.calls == 1:
                return "queued line one\nqueued line two"
            raise EOFError()

    cli._input_engine = _FakeBusyInputEngine()

    async def fake_broadcast(item):
        return None

    monkeypatch.setattr(cli, "_broadcast_queued_user_message", fake_broadcast)
    monkeypatch.setattr(cli, "_push_user_input_history", lambda text: None)
    monkeypatch.setattr(cli.ui, "info", lambda msg: None)
    monkeypatch.setattr(importlib.import_module("cli").sys, "stdout", _StdoutCapture())

    async def _run() -> None:
        task = asyncio.create_task(cli._busy_input_loop())
        assert await asyncio.to_thread(entered.wait, 1.0)
        await asyncio.sleep(0.05)
        cli._busy = False
        await task

    asyncio.run(_run())

    output = "".join(writes)
    assert "\x1b[1A\r\x1b[2K" in output
    assert cli._queued_user_messages[0]["text"] == "queued line one\nqueued line two"
    assert flushes


def test_pause_busy_input_reader_stashes_draft_and_clears_prompt(monkeypatch):
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli._busy = True

    writes = []
    entered = threading.Event()

    class _StdoutCapture:
        def write(self, text):
            writes.append(str(text))
            return len(str(text))

        def flush(self):
            return None

    class _FakeBusyInputEngine:
        def read_message(
            self,
            prompt_label: str = "\nYou: ",
            cont_label: str = "... ",
            stop_event=None,
            initial_text: str = "",
        ) -> str:
            entered.set()
            draft = "queued draft"
            while True:
                if stop_event is not None and stop_event.is_set():
                    raise importlib.import_module("cli").InputReadInterrupted(draft)
                time.sleep(0.01)

    cli._input_engine = _FakeBusyInputEngine()
    monkeypatch.setattr(importlib.import_module("cli").sys, "stdout", _StdoutCapture())

    async def _run() -> None:
        await cli._start_busy_input_reader()
        assert await asyncio.to_thread(entered.wait, 1.0)
        restarted = await cli._pause_busy_input_reader_for_output()
        assert restarted is True
        assert cli._busy_input_prefill == "queued draft"
        cli._busy = False

    asyncio.run(_run())

    output = "".join(writes)
    assert "\x1b[2K" in output


def test_stop_busy_input_reader_clears_prompt_and_stashes_draft(monkeypatch):
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli._busy = True

    writes = []
    entered = threading.Event()

    class _StdoutCapture:
        def write(self, text):
            writes.append(str(text))
            return len(str(text))

        def flush(self):
            return None

    class _FakeBusyInputEngine:
        def read_message(
            self,
            prompt_label: str = "\nYou: ",
            cont_label: str = "... ",
            stop_event=None,
            initial_text: str = "",
        ) -> str:
            entered.set()
            draft = "queued draft"
            while True:
                if stop_event is not None and stop_event.is_set():
                    raise importlib.import_module("cli").InputReadInterrupted(draft)
                time.sleep(0.01)

    cli._input_engine = _FakeBusyInputEngine()
    monkeypatch.setattr(importlib.import_module("cli").sys, "stdout", _StdoutCapture())

    async def _run() -> None:
        await cli._start_busy_input_reader()
        assert await asyncio.to_thread(entered.wait, 1.0)
        assert cli._input_prompt_active is True
        await cli._stop_busy_input_reader()
        assert cli._chat_input_prefill == "queued draft"
        assert cli._input_prompt_active is False

    asyncio.run(_run())

    output = "".join(writes)
    assert "\r\x1b[2K" in output


def test_pause_busy_input_reader_clears_reserved_waiting_indicator(monkeypatch):
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli._transient_tool_status_active = True
    cli._transient_tool_status_rows = 1
    cli._transient_tool_status_gap_rows = 1

    cli._clear_tool_running_transient(newline=False)

    assert cli._transient_tool_status_active is False
    assert cli._transient_tool_status_gap_rows == 0


def test_render_remote_originated_user_message_restarts_busy_prompt_below_output(monkeypatch):
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli._busy = True

    writes = []
    entered = threading.Event()
    release = threading.Event()

    class _StdoutCapture:
        def write(self, text):
            writes.append(str(text))
            return len(str(text))

        def flush(self):
            return None

    class _FakeBusyInputEngine:
        def __init__(self):
            self.calls = 0

        def read_message(
            self,
            prompt_label: str = "\nYou: ",
            cont_label: str = "... ",
            stop_event=None,
            initial_text: str = "",
        ) -> str:
            self.calls += 1
            entered.set()
            if self.calls == 1:
                while True:
                    if stop_event is not None and stop_event.is_set():
                        raise importlib.import_module("cli").InputReadInterrupted("draft one")
                    time.sleep(0.01)
            release.wait(1.0)
            raise EOFError()

    cli._input_engine = _FakeBusyInputEngine()
    monkeypatch.setattr(importlib.import_module("cli").sys, "stdout", _StdoutCapture())

    async def _run() -> None:
        await cli._start_busy_input_reader()
        assert await asyncio.to_thread(entered.wait, 1.0)
        await cli._render_remote_originated_user_message_below_busy_output("queued from web")
        release.set()
        cli._busy = False
        await cli._stop_busy_input_reader()

    asyncio.run(_run())

    output = "".join(writes)
    assert output.count("You: queued from web\n") == 1
    assert output.count("You: ") >= 2


def test_codex_local_tool_call_pauses_busy_prompt_and_renders_running_line(monkeypatch):
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli.model = "gpt-5.3-codex"
    cli.requested_tools = True
    cli._busy = True

    printed = []
    entered = threading.Event()
    release = threading.Event()
    stream_calls = {"n": 0}

    class _FakeBusyInputEngine:
        def __init__(self):
            self.calls = 0

        def read_message(
            self,
            prompt_label: str = "\nYou: ",
            cont_label: str = "... ",
            stop_event=None,
            initial_text: str = "",
        ) -> str:
            self.calls += 1
            entered.set()
            if self.calls == 1:
                while True:
                    if stop_event is not None and stop_event.is_set():
                        raise importlib.import_module("cli").InputReadInterrupted("busy draft")
                    time.sleep(0.01)
            release.wait(1.0)
            raise EOFError()

    async def fake_stream_request(*, req_payload, http_timeout):
        stream_calls["n"] += 1
        if stream_calls["n"] == 1:
            return {
                "model_used": "gpt-5.3-codex",
                "text_chunks": [],
                "output_items": [
                    {
                        "type": "function_call",
                        "call_id": "call_read",
                        "name": "read_file",
                        "arguments": json.dumps({"path": "cli.py"}),
                    }
                ],
                "usage": {"prompt_tokens": 5, "completion_tokens": 2, "total_tokens": 7},
            }
        return {
            "model_used": "gpt-5.3-codex",
            "text_chunks": [],
            "output_items": [
                {
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": "done"}],
                },
            ],
            "usage": {"prompt_tokens": 5, "completion_tokens": 2, "total_tokens": 7},
        }

    def _capture_print(*args, **kwargs):
        printed.append({"text": str(args[0]) if args else "", "kwargs": dict(kwargs)})

    monkeypatch.setattr(cli, "_codex_local_stream_request", fake_stream_request)
    monkeypatch.setattr(
        cli,
        "_execute_local_tool_call",
        lambda name, args, level, requested_policy: {"ok": True, "data": {"content": "stub"}},
    )
    stdout_writes = []

    class _StdoutCapture:
        def write(self, text):
            stdout_writes.append(str(text))
            return len(str(text))

        def flush(self):
            return None

    monkeypatch.setattr(cli.ui, "print", _capture_print)
    monkeypatch.setattr(importlib.import_module("cli").sys, "stdout", _StdoutCapture())
    cli._input_engine = _FakeBusyInputEngine()

    async def _run() -> str:
        await cli._start_busy_input_reader()
        assert await asyncio.to_thread(entered.wait, 1.0)
        out = await cli._stream_codex_local_once("ship it")
        release.set()
        cli._busy = False
        await cli._stop_busy_input_reader()
        return out

    out = asyncio.run(_run())

    assert out == "done"
    output = "".join(stdout_writes)
    assert "[RUNNING]" in output
    assert "Reading cli.py" in output
    assert any("[SUCCESS]" in p["text"] for p in printed)


def test_waiting_indicator_renders_above_busy_prompt_and_clears(monkeypatch):
    tmp_path = _new_local_tmp()
    cli_mod = importlib.import_module("cli")
    cli = make_cli(tmp_path)
    cli._busy = True
    cli._input_prompt_active = False
    cli._thinking_indicator_enabled = True
    cli._thinking_words = ["thinking"]
    cli._thinking_rainbow_spacing = 1

    writes = []

    class _StdoutCapture:
        def write(self, text):
            writes.append(str(text))
            return len(str(text))

        def flush(self):
            return None

    monkeypatch.setattr(cli_mod.sys, "stdout", _StdoutCapture())

    shown = cli._show_waiting_indicator_below_busy_prompt()
    cli._clear_tool_running_transient()

    output = "".join(writes)
    assert shown is True
    assert "\n" in output
    assert "\x1b[1A" in output
    assert cli._transient_tool_status_active is False


def test_backend_stream_final_status_renders_before_busy_prompt_returns(monkeypatch):
    tmp_path = _new_local_tmp()
    cli_mod = importlib.import_module("cli")
    cli = make_cli(tmp_path)
    cli.model = "gpt-5.4"
    cli.auth_user = "user@example.com"
    cli._busy = True
    cli._input_prompt_active = True
    cli._busy_input_task = object()
    cli._busy_input_stop_event = threading.Event()

    order = []

    async def fake_pause():
        order.append("pause")
        cli._input_prompt_active = False
        cli._busy_input_task = None
        cli._busy_input_stop_event = None
        return True

    async def fake_resume(should_restart: bool):
        order.append(f"resume:{should_restart}")
        cli._input_prompt_active = should_restart

    monkeypatch.setattr(cli, "_pause_busy_input_reader_for_output", fake_pause)
    monkeypatch.setattr(cli, "_resume_busy_input_reader_after_output", fake_resume)
    monkeypatch.setattr(cli, "_ensure_thread", lambda client: asyncio.sleep(0))
    monkeypatch.setattr(cli, "_save_conversation", lambda *args, **kwargs: asyncio.sleep(0))
    monkeypatch.setattr(cli, "_commit_usage", lambda *args, **kwargs: asyncio.sleep(0))
    monkeypatch.setattr(cli, "_ws_broadcast", lambda *args, **kwargs: asyncio.sleep(0))
    monkeypatch.setattr(cli, "_build_remote_control_context_info", lambda *args, **kwargs: {})
    monkeypatch.setattr(cli, "_build_remote_control_billing_info", lambda *args, **kwargs: {})
    monkeypatch.setattr(cli, "_render_status_info", lambda ctx: order.append("status"))
    monkeypatch.setattr(cli.ui, "ensure_newline", lambda text: order.append("ensure_newline"))
    monkeypatch.setattr(cli.ui, "print", lambda *args, **kwargs: None)
    monkeypatch.setattr(cli, "_show_waiting_indicator_below_busy_prompt", lambda: order.append("waiting") or True)

    class _FakeStreamResp:
        status_code = 200
        headers = {"content-type": "text/event-stream"}
        text = ""

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        def raise_for_status(self):
            return None

        async def aiter_lines(self):
            payload_completed = {
                "model": "gpt-5.4",
                "usage": {"prompt_tokens": 5, "completion_tokens": 2, "total_tokens": 7},
                "text": "done",
            }
            lines = [
                "event: message.completed",
                "data: " + json.dumps(payload_completed),
                "",
            ]
            for line in lines:
                yield line

    class _FakeAsyncClient:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        def stream(self, method, url, json=None, headers=None, follow_redirects=None):
            return _FakeStreamResp()

    monkeypatch.setattr(cli_mod.httpx, "AsyncClient", _FakeAsyncClient)

    out = asyncio.run(cli._stream_once("say hello"))

    assert out == "done"
    assert order.index("pause") < order.index("ensure_newline") < order.index("status")
    assert "waiting" not in order


def test_codex_local_final_status_renders_before_busy_prompt_returns(monkeypatch):
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli.model = "gpt-5.3-codex"
    cli._busy = True
    cli._input_prompt_active = True
    cli._busy_input_task = object()
    cli._busy_input_stop_event = threading.Event()

    order = []

    async def fake_pause():
        order.append("pause")
        cli._input_prompt_active = False
        cli._busy_input_task = None
        cli._busy_input_stop_event = None
        return True

    async def fake_resume(should_restart: bool):
        order.append(f"resume:{should_restart}")
        cli._input_prompt_active = should_restart

    async def fake_stream_request(*, req_payload, http_timeout):
        return {
            "model_used": "gpt-5.3-codex",
            "text_chunks": [],
            "output_items": [
                {
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": "done"}],
                }
            ],
            "usage": {"prompt_tokens": 7, "completion_tokens": 3, "total_tokens": 10},
        }

    monkeypatch.setattr(cli, "_pause_busy_input_reader_for_output", fake_pause)
    monkeypatch.setattr(cli, "_resume_busy_input_reader_after_output", fake_resume)
    monkeypatch.setattr(cli, "_codex_local_stream_request", fake_stream_request)
    monkeypatch.setattr(cli, "_render_status_info", lambda ctx: order.append("status"))
    monkeypatch.setattr(cli.ui, "ensure_newline", lambda text: order.append("ensure_newline"))
    monkeypatch.setattr(cli.ui, "print", lambda *args, **kwargs: None)
    monkeypatch.setattr(cli, "_ws_broadcast", lambda *args, **kwargs: asyncio.sleep(0))
    monkeypatch.setattr(cli, "_build_remote_control_context_info", lambda *args, **kwargs: {})
    monkeypatch.setattr(cli, "_build_remote_control_billing_info", lambda *args, **kwargs: {})

    out = asyncio.run(cli._stream_codex_local_once("ship it"))

    assert out == "done"
    assert order.index("pause") < order.index("ensure_newline") < order.index("status")
    assert not any(item.startswith("resume:") for item in order)


def test_codex_local_commit_usage_warns_when_analytics_commit_fails(monkeypatch):
    tmp_path = _new_local_tmp()
    cli = make_cli(tmp_path)
    cli.auth_user = "henosis"
    cli.server_usage_commit = True
    cli.thread_uid = "thread-1"

    warnings = []

    class _Resp:
        status_code = 500
        text = "server exploded"

    class _Client:
        async def post(self, url, json=None):
            return _Resp()

    monkeypatch.setattr(cli.ui, "warn", lambda msg: warnings.append(str(msg)))

    asyncio.run(
        cli._commit_usage(
            _Client(),
            session_id="sess-1",
            model_used="gpt-5.4",
            usage={"prompt_tokens": 12, "completion_tokens": 3, "total_tokens": 15},
            meta={"billing_source": "codex_local"},
        )
    )

    assert any("Local Codex analytics commit failed" in msg for msg in warnings)
