import os
import shutil
import uuid
from pathlib import Path

from henosis_cli_tools import tool_impl as ti


def test_normalize_and_strip_wrapping_quotes_basic():
    assert ti._normalize_and_strip_wrapping_quotes('"fastapi"') == "fastapi"
    assert ti._normalize_and_strip_wrapping_quotes("'fastapi'") == "fastapi"
    assert ti._normalize_and_strip_wrapping_quotes("\u201cfastapi\u201d") == "fastapi"
    assert ti._normalize_and_strip_wrapping_quotes('say "hello"') == 'say "hello"'


def _make_workspace() -> Path:
    root = Path(os.getcwd()) / "workspace" / f"issue7-{uuid.uuid4().hex[:8]}"
    root.mkdir(parents=True, exist_ok=False)
    return root


def test_read_file_and_list_dir_accept_wrapped_paths():
    workspace = _make_workspace()
    try:
        nested = workspace / "nested"
        nested.mkdir()
        target = nested / "note.txt"
        target.write_text("quoted path works", encoding="utf-8")

        pol = ti.FileToolPolicy(scope="workspace", workspace_base=workspace)

        read_res = ti.read_file('"nested/note.txt"', pol)
        assert read_res["ok"] is True
        assert read_res["data"]["content"] == "quoted path works"

        list_res = ti.list_dir('"nested"', pol)
        assert list_res["ok"] is True
        assert [item["name"] for item in list_res["data"]["items"]] == ["note.txt"]
    finally:
        shutil.rmtree(workspace, ignore_errors=True)


def test_run_command_accepts_wrapped_command_and_cwd():
    workspace = _make_workspace()
    try:
        pol = ti.FileToolPolicy(scope="workspace", workspace_base=workspace)

        res = ti.run_command(
            cmd="'python -c \"print(123)\"'",
            policy=pol,
            cwd='"."',
            timeout=30,
            allow_commands_csv="python",
        )

        assert res["ok"] is True
        assert res["data"]["exit_code"] == 0
        assert res["data"]["stdout"].strip() == "123"
    finally:
        shutil.rmtree(workspace, ignore_errors=True)


def test_apply_patch_accepts_wrapped_patch_paths_and_cwd():
    workspace = _make_workspace()
    try:
        target = workspace / "file.txt"
        target.write_text("before\n", encoding="utf-8")
        pol = ti.FileToolPolicy(scope="workspace", workspace_base=workspace)

        patch = """*** Begin Patch
*** Update File: "file.txt"
@@
-before
+after
*** End Patch
"""

        res = ti.apply_patch(patch=patch, policy=pol, cwd='"."', dry_run=True)

        assert res["ok"] is True
        assert res["data"]["details"][0]["path"].endswith("file.txt")
    finally:
        shutil.rmtree(workspace, ignore_errors=True)

def test_string_replace_accepts_wrapped_globs_and_cwd():
    workspace = _make_workspace()
    try:
        target = workspace / "sample.py"
        target.write_text("value = 1\n", encoding="utf-8")
        pol = ti.FileToolPolicy(scope="workspace", workspace_base=workspace)

        res = ti.string_replace(
            pattern="1",
            replacement="2",
            policy=pol,
            cwd='"."',
            file_globs=['"*.py"'],
            dry_run=True,
        )

        assert res["ok"] is True
        assert res["data"]["summary"]["files_changed"] == 1
    finally:
        shutil.rmtree(workspace, ignore_errors=True)
