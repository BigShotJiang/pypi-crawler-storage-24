import asyncio
import importlib
import threading


def _make_cli(agent_mode: bool = True):
    cli_mod = importlib.import_module("cli")
    return cli_mod.ChatCLI(
        server="http://127.0.0.1:8000/api",
        model="gpt-5.4",
        system_prompt=None,
        timeout=5.0,
        map_prefix=False,
        log_enabled=False,
        save_to_threads=False,
        server_usage_commit=False,
        verbose=False,
        agent_mode=agent_mode,
    )


def test_run_blocking_prompt_read_replaces_stop_event_for_input_engine_signature():
    cli = _make_cli(agent_mode=True)
    captured = {}

    def fake_reader(
        prompt_label: str = "\nYou: ",
        cont_label: str = "... ",
        stop_event=None,
        initial_text: str = "",
    ) -> str:
        captured["prompt_label"] = prompt_label
        captured["cont_label"] = cont_label
        captured["stop_event"] = stop_event
        captured["initial_text"] = initial_text
        return "typed"

    result = asyncio.run(
        cli._run_blocking_prompt_read(
            fake_reader,
            "You: ",
            "",
            None,
            "draft text",
        )
    )

    assert result == "typed"
    assert captured["prompt_label"] == "You: "
    assert captured["cont_label"] == ""
    assert isinstance(captured["stop_event"], threading.Event)
    assert captured["stop_event"].is_set() is True
    assert captured["initial_text"] == "draft text"
    assert cli._input_interrupt_event is None
    assert cli._input_prompt_active is False
    assert cli._input_prompt_label is None


def test_run_blocking_prompt_read_replaces_stop_event_for_multiline_signature():
    cli = _make_cli(agent_mode=True)
    captured = {}

    def fake_reader(
        prompt_label: str = "\nYou: ",
        stop_event=None,
        initial_text: str = "",
    ) -> str:
        captured["prompt_label"] = prompt_label
        captured["stop_event"] = stop_event
        captured["initial_text"] = initial_text
        return "typed"

    result = asyncio.run(
        cli._run_blocking_prompt_read(
            fake_reader,
            "You: ",
            None,
            "draft text",
        )
    )

    assert result == "typed"
    assert captured["prompt_label"] == "You: "
    assert isinstance(captured["stop_event"], threading.Event)
    assert captured["stop_event"].is_set() is True
    assert captured["initial_text"] == "draft text"
    assert cli._input_interrupt_event is None
    assert cli._input_prompt_active is False
    assert cli._input_prompt_label is None
