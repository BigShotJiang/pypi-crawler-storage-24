from fastapi import FastAPI
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, text
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import StaticPool

from app.routers import usage as usage_router


def _build_usage_app():
    engine = create_engine(
        "sqlite://",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)
    with engine.begin() as conn:
        conn.execute(
            text(
                """
                CREATE TABLE model_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT,
                    model_id TEXT,
                    tokens_input INTEGER,
                    tokens_output INTEGER,
                    cost REAL,
                    status TEXT,
                    billing_source TEXT,
                    cached_input_tokens INTEGER,
                    non_cached_input_tokens INTEGER,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
                """
            )
        )
        conn.execute(
            text(
                """
                CREATE TABLE users (
                    username TEXT PRIMARY KEY,
                    credits REAL,
                    subscription_tier TEXT,
                    subscription_status TEXT
                )
                """
            )
        )
        conn.execute(
            text("INSERT INTO users (username, credits, subscription_tier, subscription_status) VALUES ('henosis', 10.0, 'free', 'none')")
        )

    app = FastAPI()
    app.include_router(usage_router.router)

    def override_db():
        db = SessionLocal()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[usage_router.get_db] = override_db
    app.dependency_overrides[usage_router.get_current_user] = lambda: "henosis"
    return app, engine


def test_codex_local_commit_inserts_analytics_row_without_credit_deduction():
    app, engine = _build_usage_app()
    client = TestClient(app)

    payload = {
        "session_id": "sess-codex-local-1",
        "model": "gpt-5.4",
        "usage": {"prompt_tokens": 120, "completion_tokens": 30, "total_tokens": 150},
        "meta": {"billing_source": "codex_local"},
    }
    response = client.post("/api/usage/commit", json=payload)
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["ok"] is True
    assert body["remaining_credits"] == 10.0

    with Session(engine) as db:
        row = db.execute(
            text(
                "SELECT status, billing_source, tokens_input, tokens_output FROM model_logs LIMIT 1"
            )
        ).mappings().first()
        assert row is not None
        assert row["status"] == "codex_local"
        assert row["billing_source"] == "codex_local"
        credits = db.execute(text("SELECT credits FROM users WHERE username = 'henosis'")).scalar_one()
        assert float(credits) == 10.0


def test_codex_local_commit_not_suppressed_by_nearby_backend_row():
    app, engine = _build_usage_app()
    client = TestClient(app)

    with engine.begin() as conn:
        conn.execute(
            text(
                """
                INSERT INTO model_logs (
                    user_id, model_id, tokens_input, tokens_output, cost, status, billing_source, cached_input_tokens, non_cached_input_tokens, created_at
                ) VALUES (
                    'henosis', 'gpt-5.4', 120, 30, 0.5, 'success', 'backend_openai', 0, 120, CURRENT_TIMESTAMP
                )
                """
            )
        )

    payload = {
        "session_id": "sess-codex-local-2",
        "model": "gpt-5.4",
        "usage": {"prompt_tokens": 120, "completion_tokens": 30, "total_tokens": 150},
        "meta": {"billing_source": "codex_local"},
    }
    response = client.post("/api/usage/commit", json=payload)
    assert response.status_code == 200, response.text

    with Session(engine) as db:
        rows = db.execute(
            text(
                "SELECT status, billing_source FROM model_logs ORDER BY id ASC"
            )
        ).mappings().all()
        assert len(rows) == 2
        assert rows[0]["billing_source"] == "backend_openai"
        assert rows[1]["billing_source"] == "codex_local"
