import pytest


from app.routers.chat import (
    _responses_output_items,
    _responses_output_text_from_items,
    _responses_function_calls_from_items,
    _responses_usage_from_data,
    _responses_reasoning_text_from_items,
    _anthropic_thinking_text_from_blocks,
    _gemini_thought_text_from_message,
    _build_thinking_insight_payload,
)


def test_responses_output_text_from_items_extracts_output_text():
    data = {
        "id": "resp_123",
        "output": [
            {
                "type": "message",
                "role": "assistant",
                "content": [
                    {"type": "output_text", "text": "Hello"},
                    {"type": "output_text", "text": ", world"},
                ],
            }
        ],
    }
    items = _responses_output_items(data)
    assert _responses_output_text_from_items(items) == "Hello, world"


def test_responses_output_text_from_items_accepts_text_alias_segments():
    data = {
        "id": "resp_123_text_alias",
        "output": [
            {
                "type": "message",
                "role": "assistant",
                "content": [
                    {"type": "text", "text": "Hello"},
                    {"text": " from alias"},
                ],
            }
        ],
    }
    items = _responses_output_items(data)
    assert _responses_output_text_from_items(items) == "Hello from alias"


def test_responses_function_calls_from_items_extracts_function_call_items():
    data = {
        "id": "resp_123",
        "output": [
            {"type": "message", "role": "assistant", "content": [{"type": "output_text", "text": "..."}]},
            {"type": "function_call", "call_id": "call_1", "name": "read_file", "arguments": "{\"path\":\"README.md\"}"},
            {"type": "function_call", "call_id": "call_2", "name": "run_command", "arguments": "{\"cmd\":\"echo hi\",\"cwd\":\".\"}"},
        ],
    }
    items = _responses_output_items(data)
    calls = _responses_function_calls_from_items(items)
    assert calls == [
        {"call_id": "call_1", "name": "read_file", "arguments": "{\"path\":\"README.md\"}"},
        {"call_id": "call_2", "name": "run_command", "arguments": "{\"cmd\":\"echo hi\",\"cwd\":\".\"}"},
    ]


def test_responses_function_calls_from_items_accepts_tool_call_alias_and_dict_args():
    data = {
        "id": "resp_456",
        "output": [
            {
                "type": "tool_call",
                "tool_call_id": "tc_1",
                "function": {"name": "search_web", "arguments": {"q": "xai docs"}},
            }
        ],
    }
    items = _responses_output_items(data)
    calls = _responses_function_calls_from_items(items)
    assert calls == [
        {"call_id": "tc_1", "name": "search_web", "arguments": "{\"q\": \"xai docs\"}"},
    ]


def test_responses_usage_from_data_normalizes_usage_tokens():
    assert _responses_usage_from_data({"usage": {"input_tokens": 10, "output_tokens": 20, "total_tokens": 31}}) == {
        "input_tokens": 10,
        "output_tokens": 20,
        "total_tokens": 31,
    }
    # missing total => compute
    assert _responses_usage_from_data({"usage": {"input_tokens": 10, "output_tokens": 20}}) == {
        "input_tokens": 10,
        "output_tokens": 20,
        "total_tokens": 30,
    }
    # bad shapes => zeros
    assert _responses_usage_from_data({}) == {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}


def test_responses_reasoning_text_from_items_extracts_reasoning_summary():
    items = [
        {
            "type": "reasoning",
            "summary": [{"type": "summary_text", "text": "First reasoning summary"}],
            "encrypted_content": "opaque",
        },
        {
            "type": "message",
            "role": "assistant",
            "content": [{"type": "output_text", "text": "Visible answer"}],
        },
    ]
    text = _responses_reasoning_text_from_items(items)
    assert "First reasoning summary" in text
    assert "Visible answer" not in text


def test_anthropic_and_gemini_reasoning_extractors():
    anth = _anthropic_thinking_text_from_blocks(
        [
            {"type": "text", "text": "hello"},
            {"type": "thinking", "thinking": "anthropic thought"},
            {"type": "thinking", "thinking": "anthropic thought"},
        ]
    )
    assert anth == "anthropic thought"

    gem = _gemini_thought_text_from_message(
        {
            "role": "model",
            "parts": [
                {"type": "text", "text": "final answer"},
                {"type": "text", "text": "thought text", "thought": True},
            ],
        }
    )
    assert gem == "thought text"


def test_build_thinking_insight_payload_truncates():
    payload = _build_thinking_insight_payload(
        provider="openai",
        model="gpt-5",
        mode="summary",
        text="x" * 20,
        max_chars=10,
    )
    assert isinstance(payload, dict)
    assert payload["provider"] == "openai"
    assert payload["mode"] == "summary"
    assert payload["text"] == "x" * 10
    assert payload.get("truncated") is True
