from app.services.remote_control import RemoteControlService, TerminalConnection


def test_message_completed_replays_final_text_into_snapshot():
    service = RemoteControlService()

    updated = service._apply_terminal_event_locked(
        "term-1",
        {
            "terminal": {"terminal_id": "term-1"},
            "current_turn": {
                "active": True,
                "assistant_so_far": "",
                "tool_events": [],
            },
        },
        "message.completed",
        {
            "model": "gpt-5.4",
            "text": "Final answer from completion payload",
        },
    )

    assert updated["current_turn"]["active"] is False
    assert updated["current_turn"]["assistant_so_far"] == "Final answer from completion payload"
    assert updated["model"] == "gpt-5.4"
    assert updated["last_completed"]["text"] == "Final answer from completion payload"


def test_terminal_summary_includes_remote_control_metadata_fields():
    service = RemoteControlService()
    terminal = TerminalConnection(
        user_id="user-1",
        terminal_id="term-1",
        websocket=object(),
        hello={
            "terminal": {
                "terminal_id": "term-1",
                "label": "Workstation",
                "terminal_alias": "Orion-17",
                "terminal_short_id": "term-1",
                "display_name": "Orion-17",
                "cli_version": "1.2.3",
                "host_base": "C:/repo",
                "model_presets": [
                    {"value": "gpt-5.4", "label": "OpenAI: gpt-5.4"},
                ],
            }
        },
        snapshot={
            "terminal": {
                "terminal_id": "term-1",
                "cwd": "C:/repo/app",
            },
            "requested_tools": True,
            "fs_scope": "host",
            "control_level": 3,
            "current_turn": {
                "active": False,
                "tool_events": [],
            },
        },
    )

    summary = service._terminal_summary_locked(terminal)

    assert summary["label"] == "Workstation"
    assert summary["terminal_alias"] == "Orion-17"
    assert summary["terminal_short_id"] == "term-1"
    assert summary["display_name"] == "Orion-17"
    assert summary["cwd"] == "C:/repo/app"
    assert summary["host_base"] == "C:/repo"
    assert summary["requested_tools"] is True
    assert summary["fs_scope"] == "host"
    assert summary["control_level"] == 3
    assert summary["model_presets"] == [{"value": "gpt-5.4", "label": "OpenAI: gpt-5.4"}]


def test_settings_update_waits_for_terminal_state_before_mutating_snapshot():
    service = RemoteControlService()
    terminal = TerminalConnection(
        user_id="user-1",
        terminal_id="term-1",
        websocket=object(),
        snapshot={
            "terminal": {"terminal_id": "term-1"},
            "settings": {"host_base": "C:/old"},
            "host_base": "C:/old",
        },
    )
    service._terminals = {"user-1": {"term-1": terminal}}
    service._browsers = {
        "user-1": {
            "browser-1": type(
                "BrowserStub",
                (),
                {"selected_terminal_id": "term-1", "websocket": object()},
            )()
        }
    }

    class TerminalSocket:
        def __init__(self):
            self.payloads = []

        async def send_json(self, payload):
            self.payloads.append(payload)

    socket = TerminalSocket()
    terminal.websocket = socket

    import asyncio

    ok, terminal_id = asyncio.run(
        service.forward_browser_message(
            "user-1",
            "browser-1",
            "settings.update",
            {"settings": {"host_base": "C:/new"}},
        )
    )

    assert ok is True
    assert terminal_id == "term-1"
    assert socket.payloads == [
        {"type": "settings.update", "data": {"settings": {"host_base": "C:/new"}}}
    ]
    assert terminal.snapshot["settings"]["host_base"] == "C:/old"
    assert terminal.snapshot["host_base"] == "C:/old"
