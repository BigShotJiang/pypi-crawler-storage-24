import sys
from pathlib import Path
import json
from typing import Any, Dict, List, Optional

import pytest
from starlette.testclient import TestClient

# Ensure repository root is on sys.path so `import app` works regardless of how pytest is invoked
_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from app.main import app
from app.settings import settings


class FakeEvent:
    def __init__(
        self,
        typ: str,
        delta: Optional[Any] = None,
        error: Optional[Dict[str, Any]] = None,
        **extra: Any,
    ):
        self.type = typ
        self.delta = delta
        self.error = error
        for key, value in extra.items():
            setattr(self, key, value)


class FakeUsage:
    def __init__(self, input_tokens: int, output_tokens: int, cached_tokens: int = 0):
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens
        self.total_tokens = input_tokens + output_tokens
        # OpenAI Responses API exposes input_tokens_details.cached_tokens; emulate attribute access
        class _InputTokensDetails:
            def __init__(self, cached_tokens: int) -> None:
                self.cached_tokens = cached_tokens

        self.input_tokens_details = _InputTokensDetails(cached_tokens)


class FakeWebSearchCall:
    def __init__(self, action: Dict[str, Any]):
        self.type = "web_search_call"
        self.id = "ws_test_1"
        self.status = "completed"
        self.action = action


class FakeFinal:
    def __init__(self, text: str, usage: FakeUsage, output_items: List[Any]):
        self.output_text = text
        self.usage = usage
        self.output = output_items
        self.id = "resp_test_123"


class FakeResponsesStream:
    """Context manager that records request kwargs and yields a simple delta stream."""

    def __init__(
        self,
        recorded: List[Dict[str, Any]],
        kwargs: Dict[str, Any],
        include_sources: bool,
        stream_events: Optional[List[Any]] = None,
        emit_reasoning_item: Optional[bool] = None,
    ):
        self._recorded = recorded
        self._kwargs = kwargs
        self._include_sources = include_sources
        reasoning_obj = kwargs.get("reasoning") if isinstance(kwargs.get("reasoning"), dict) else {}
        self._include_reasoning_summary = bool(reasoning_obj.get("summary"))
        self._emit_reasoning_item = (
            self._include_reasoning_summary if emit_reasoning_item is None else bool(emit_reasoning_item)
        )
        self._stream_events = list(stream_events) if isinstance(stream_events, list) else None
        self._final: Optional[FakeFinal] = None
        # Persist the call
        self._recorded.append(dict(kwargs))

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def __iter__(self):
        if isinstance(self._stream_events, list):
            for ev in self._stream_events:
                yield ev
            return
        # Yield a single text delta
        yield FakeEvent("response.output_text.delta", delta="hello world")

    # The router calls get_final_response() after the stream
    def get_final_response(self) -> FakeFinal:
        if self._final is None:
            usage = FakeUsage(input_tokens=42, output_tokens=17, cached_tokens=0)
            # Provide a minimal web_search_call output item to simulate tool usage
            sources = []
            if self._include_sources:
                sources = [
                    {"title": "Example", "url": "https://example.com"},
                    {"title": "OpenAI", "url": "https://openai.com"},
                ]
            action = {
                "type": "search",
                "query": "positive news today",
            }
            if sources:
                action["sources"] = sources
            output_items: List[Any] = []
            if self._emit_reasoning_item:
                output_items.append(
                    {
                        "type": "reasoning",
                        "summary": [
                            {
                                "type": "summary_text",
                                "text": "Reasoning summary: checked context and selected final answer.",
                            }
                        ],
                    }
                )
            output_items.append(FakeWebSearchCall(action=action))
            self._final = FakeFinal("hello world", usage=usage, output_items=output_items)
        return self._final


class FakeResponses:
    def __init__(
        self,
        recorded: List[Dict[str, Any]],
        stream_events: Optional[List[Any]] = None,
        emit_reasoning_item: Optional[bool] = None,
    ):
        self._recorded = recorded
        self._stream_events = list(stream_events) if isinstance(stream_events, list) else None
        self._emit_reasoning_item = emit_reasoning_item

    def stream(self, **kwargs):  # matches client.responses.stream(**request_kwargs)
        include = kwargs.get("include") or []
        include_sources = isinstance(include, list) and ("web_search_call.action.sources" in include)
        return FakeResponsesStream(
            self._recorded,
            kwargs,
            include_sources,
            stream_events=self._stream_events,
            emit_reasoning_item=self._emit_reasoning_item,
        )


class FakeOpenAI:
    def __init__(
        self,
        api_key: Optional[str] = None,
        stream_events: Optional[List[Any]] = None,
        emit_reasoning_item: Optional[bool] = None,
    ):
        self.api_key = api_key
        self._recorded: List[Dict[str, Any]] = []
        self.responses = FakeResponses(
            self._recorded,
            stream_events=stream_events,
            emit_reasoning_item=emit_reasoning_item,
        )

    # Helper for tests
    @property
    def recorded_calls(self) -> List[Dict[str, Any]]:
        return self._recorded


@pytest.fixture(autouse=True)
def _env_keys(monkeypatch):
    # Ensure provider gates pass
    monkeypatch.setattr(settings, "OPENAI_API_KEY", "sk-test")
    # Enable v0 routes for test client
    monkeypatch.setattr(settings, "DISABLE_V0_ROUTES", False)
    yield


def _post_stream(client: TestClient, payload: Dict[str, Any]) -> List[str]:
    """Helper to collect SSE events from /v0/chat/stream into a list of event names."""
    r = client.post("/v0/chat/stream", json=payload)
    assert r.status_code == 200
    events: List[str] = []
    for line in r.iter_lines():
        s = line.decode("utf-8") if isinstance(line, (bytes, bytearray)) else str(line)
        if s.startswith("event:"):
            events.append(s[len("event:") :].strip())
    return events


def _collect_sse_events(client: TestClient, payload: Dict[str, Any]) -> List[Dict[str, Any]]:
    r = client.post("/v0/chat/stream", json=payload)
    assert r.status_code == 200
    out: List[Dict[str, Any]] = []
    current_event: Optional[str] = None
    for line in r.iter_lines():
        s = line.decode("utf-8") if isinstance(line, (bytes, bytearray)) else str(line)
        if s.startswith("event:"):
            current_event = s[len("event:") :].strip()
        elif s.startswith("data:"):
            raw = s[len("data:") :].strip()
            data_obj: Any = raw
            try:
                data_obj = json.loads(raw)
            except Exception:
                pass
            out.append({"event": current_event, "data": data_obj})
    return out


def _collect_completed_payload(client: TestClient, payload: Dict[str, Any]) -> Dict[str, Any]:
    r = client.post("/v0/chat/stream", json=payload)
    assert r.status_code == 200
    current_event: Optional[str] = None
    completed: Optional[Dict[str, Any]] = None
    for line in r.iter_lines():
        s = line.decode("utf-8") if isinstance(line, (bytes, bytearray)) else str(line)
        if s.startswith("event:"):
            current_event = s[len("event:") :].strip()
        elif s.startswith("data:"):
            try:
                obj = json.loads(s[len("data:") :].strip())
            except Exception:
                obj = None
            if current_event == "message.completed" and isinstance(obj, dict):
                completed = obj
    assert completed is not None, "Did not receive message.completed payload"
    return completed  # type: ignore


def test_openai_websearch_includes_tool_and_filters_and_location(monkeypatch):
    # Patch OpenAI class used in router to our fake
    recorded_holder: Dict[str, Any] = {}

    def _factory(api_key: Optional[str] = None):
        inst = FakeOpenAI(api_key)
        recorded_holder["inst"] = inst
        return inst

    import app.routers.chat as chat_router

    # Ensure legacy v0 route is mounted for tests regardless of settings at import time
    try:
        app.include_router(chat_router.router, prefix="/v0")
    except Exception:
        pass

    monkeypatch.setattr(chat_router, "OpenAI", _factory)  # type: ignore

    client = TestClient(app)

    payload = {
        "model": "gpt-5",
        "messages": [
            {"role": "user", "content": "What was a positive news story from today?"}
        ],
        # Tools can be off; web search is independent for OpenAI path
        "enable_tools": False,
        "enable_web_search": True,
        # messy domains to test cleaning and de-duplication
        "web_search_allowed_domains": [
            "https://OpenAI.com/",
            "pubmed.ncbi.nlm.nih.gov",
            "openai.com",
        ],
        "web_search_include_sources": True,
        "web_search_user_location": {
            "type": "approximate",
            "country": "US",
            "city": "Seattle",
            "region": "Washington",
        },
    }

    sse_events = _collect_sse_events(client, payload)
    events = [str(x.get("event") or "") for x in sse_events]
    # Ensure basic SSE lifecycle occurred
    assert "session.started" in events
    assert "message.completed" in events
    # OpenAI web search should be rendered as synthetic tool events in non-Codex flow
    ws_tool_calls = [
        x
        for x in sse_events
        if x.get("event") == "tool.call"
        and isinstance(x.get("data"), dict)
        and (x.get("data") or {}).get("name") == "web_search"
    ]
    assert ws_tool_calls, "expected a synthetic tool.call for web_search"

    # Validate captured OpenAI request payload
    fake: FakeOpenAI = recorded_holder["inst"]
    assert fake.recorded_calls, "OpenAI.responses.stream was not called"
    call = fake.recorded_calls[0]
    # tools should contain web_search tool with cleaned filters and user_location
    tools = call.get("tools") or []
    assert any(isinstance(t, dict) and t.get("type") == "web_search" for t in tools), "web_search tool missing"
    web_tool = next(t for t in tools if t.get("type") == "web_search")
    # Filters: allowed_domains should be lowercased, schemes/slashes stripped, de-duped
    filters = web_tool.get("filters") or {}
    allowed = filters.get("allowed_domains") or []
    assert "openai.com" in allowed
    assert "pubmed.ncbi.nlm.nih.gov" in allowed
    # No scheme/trailing slashes
    assert all(not d.startswith("http") for d in allowed)
    # User location should pass through as-is
    ul = web_tool.get("user_location") or {}
    assert ul.get("type") == "approximate"
    assert ul.get("country") == "US"
    assert ul.get("city") == "Seattle"
    assert ul.get("region") == "Washington"
    # include should request sources when asked
    include = call.get("include") or []
    assert "web_search_call.action.sources" in include
    # Validate SSE final payload includes web_search list with sources
    completed_payload = _collect_completed_payload(client, payload)
    assert isinstance(completed_payload.get("web_search"), list)
    ws = completed_payload["web_search"]
    assert ws and isinstance(ws[0], dict)
    action = ws[0].get("action") or {}
    assert action.get("type") == "search"
    assert action.get("query")
    # Since include_sources=True, we expect sources present
    sources = action.get("sources")
    assert isinstance(sources, list) and len(sources) >= 2


def test_openai_websearch_disabled_omits_tool(monkeypatch):
    # Patch OpenAI again
    calls: Dict[str, Any] = {}

    def _factory(api_key: Optional[str] = None):
        inst = FakeOpenAI(api_key)
        calls["inst"] = inst
        return inst

    import app.routers.chat as chat_router

    # Ensure legacy v0 route is mounted for tests
    try:
        app.include_router(chat_router.router, prefix="/v0")
    except Exception:
        pass

    monkeypatch.setattr(chat_router, "OpenAI", _factory)  # type: ignore

    client = TestClient(app)

    payload = {
        "model": "gpt-5",
        "messages": [{"role": "user", "content": "Hello"}],
        "enable_web_search": False,
    }

    events = _post_stream(client, payload)
    assert "session.started" in events
    assert "message.completed" in events

    fake: FakeOpenAI = calls["inst"]
    assert fake.recorded_calls
    call = fake.recorded_calls[0]
    tools = call.get("tools") or []
    # Should not contain web_search when disabled
    assert not any(t.get("type") == "web_search" for t in tools)


def test_openai_thinking_insight_opt_in_requests_reasoning_summary(monkeypatch):
    calls: Dict[str, Any] = {}

    def _factory(api_key: Optional[str] = None):
        inst = FakeOpenAI(api_key)
        calls["inst"] = inst
        return inst

    import app.routers.chat as chat_router

    try:
        app.include_router(chat_router.router, prefix="/v0")
    except Exception:
        pass

    monkeypatch.setattr(chat_router, "OpenAI", _factory)  # type: ignore
    monkeypatch.setattr(settings, "ENABLE_THINKING_INSIGHTS_DEFAULT", False)

    client = TestClient(app)
    payload = {
        "model": "gpt-5",
        "messages": [{"role": "user", "content": "solve this"}],
        "enable_tools": False,
        "enable_thinking_insights": True,
    }

    completed_payload = _collect_completed_payload(client, payload)
    fake: FakeOpenAI = calls["inst"]
    assert fake.recorded_calls
    call = fake.recorded_calls[0]
    reasoning = call.get("reasoning") or {}
    assert isinstance(reasoning, dict)
    assert reasoning.get("summary") == "auto"

    tsi = completed_payload.get("thinking_insight")
    assert isinstance(tsi, dict)
    assert tsi.get("provider") == "openai"
    assert tsi.get("mode") == "summary"
    assert "reasoning summary" in str(tsi.get("text", "")).lower()


def test_openai_thinking_insight_respects_server_default_when_flag_omitted(monkeypatch):
    calls: Dict[str, Any] = {}

    def _factory(api_key: Optional[str] = None):
        inst = FakeOpenAI(api_key)
        calls["inst"] = inst
        return inst

    import app.routers.chat as chat_router

    try:
        app.include_router(chat_router.router, prefix="/v0")
    except Exception:
        pass

    monkeypatch.setattr(chat_router, "OpenAI", _factory)  # type: ignore
    monkeypatch.setattr(settings, "ENABLE_THINKING_INSIGHTS_DEFAULT", True)

    client = TestClient(app)
    payload = {
        "model": "gpt-5",
        "messages": [{"role": "user", "content": "solve this"}],
        "enable_tools": False,
    }

    completed_payload = _collect_completed_payload(client, payload)
    fake: FakeOpenAI = calls["inst"]
    assert fake.recorded_calls
    call = fake.recorded_calls[0]
    reasoning = call.get("reasoning") or {}
    assert isinstance(reasoning, dict)
    assert reasoning.get("summary") == "auto"

    tsi = completed_payload.get("thinking_insight")
    assert isinstance(tsi, dict)
    assert tsi.get("provider") == "openai"


def test_openai_thinking_insight_summary_verbosity_passthrough(monkeypatch):
    calls: Dict[str, Any] = {}

    def _factory(api_key: Optional[str] = None):
        inst = FakeOpenAI(api_key)
        calls["inst"] = inst
        return inst

    import app.routers.chat as chat_router

    try:
        app.include_router(chat_router.router, prefix="/v0")
    except Exception:
        pass

    monkeypatch.setattr(chat_router, "OpenAI", _factory)  # type: ignore
    monkeypatch.setattr(settings, "ENABLE_THINKING_INSIGHTS_DEFAULT", False)

    client = TestClient(app)
    payload = {
        "model": "gpt-5",
        "messages": [{"role": "user", "content": "solve this"}],
        "enable_tools": False,
        "enable_thinking_insights": True,
        "thinking_insight_summary": "concise",
    }

    _collect_completed_payload(client, payload)
    fake: FakeOpenAI = calls["inst"]
    assert fake.recorded_calls
    call = fake.recorded_calls[0]
    reasoning = call.get("reasoning") or {}
    assert isinstance(reasoning, dict)
    assert reasoning.get("summary") == "concise"


def test_openai_service_tier_priority_passthrough(monkeypatch):
    calls: Dict[str, Any] = {}

    def _factory(api_key: Optional[str] = None):
        inst = FakeOpenAI(api_key)
        calls["inst"] = inst
        return inst

    import app.routers.chat as chat_router

    try:
        app.include_router(chat_router.router, prefix="/v0")
    except Exception:
        pass

    monkeypatch.setattr(chat_router, "OpenAI", _factory)  # type: ignore

    client = TestClient(app)
    payload = {
        "model": "gpt-5",
        "messages": [{"role": "user", "content": "solve this quickly"}],
        "enable_tools": False,
        "service_tier": "priority",
    }

    _collect_completed_payload(client, payload)
    fake: FakeOpenAI = calls["inst"]
    assert fake.recorded_calls
    call = fake.recorded_calls[0]
    assert call.get("service_tier") == "priority"


def test_openai_thinking_insight_streams_before_message_delta_when_reasoning_event_precedes(monkeypatch):
    calls: Dict[str, Any] = {}

    def _factory(api_key: Optional[str] = None):
        inst = FakeOpenAI(
            api_key,
            stream_events=[
                FakeEvent("response.reasoning.delta", delta={"text": "plan first"}),
                FakeEvent("response.output_text.delta", delta="hello world"),
            ],
            emit_reasoning_item=False,
        )
        calls["inst"] = inst
        return inst

    import app.routers.chat as chat_router

    try:
        app.include_router(chat_router.router, prefix="/v0")
    except Exception:
        pass

    monkeypatch.setattr(chat_router, "OpenAI", _factory)  # type: ignore
    monkeypatch.setattr(settings, "ENABLE_THINKING_INSIGHTS_DEFAULT", False)

    client = TestClient(app)
    payload = {
        "model": "gpt-5",
        "messages": [{"role": "user", "content": "solve this"}],
        "enable_tools": False,
        "enable_thinking_insights": True,
    }

    sse_events = _collect_sse_events(client, payload)
    names = [str(x.get("event") or "") for x in sse_events]
    assert "thinking.insight" in names
    assert "message.delta" in names
    assert names.index("thinking.insight") < names.index("message.delta")

    first_thinking = next(
        x for x in sse_events if x.get("event") == "thinking.insight" and isinstance(x.get("data"), dict)
    )
    thinking_data = first_thinking.get("data") or {}
    assert "plan first" in str(thinking_data.get("text", "")).lower()


def test_openai_thinking_insight_emits_placeholder_when_provider_omits_summary(monkeypatch):
    calls: Dict[str, Any] = {}

    def _factory(api_key: Optional[str] = None):
        inst = FakeOpenAI(
            api_key,
            stream_events=[FakeEvent("response.output_text.delta", delta="hello world")],
            emit_reasoning_item=False,
        )
        calls["inst"] = inst
        return inst

    import app.routers.chat as chat_router

    try:
        app.include_router(chat_router.router, prefix="/v0")
    except Exception:
        pass

    monkeypatch.setattr(chat_router, "OpenAI", _factory)  # type: ignore
    monkeypatch.setattr(settings, "ENABLE_THINKING_INSIGHTS_DEFAULT", False)

    client = TestClient(app)
    payload = {
        "model": "gpt-5",
        "messages": [{"role": "user", "content": "solve this"}],
        "enable_tools": False,
        "enable_thinking_insights": True,
    }

    sse_events = _collect_sse_events(client, payload)
    thinking_events = [x for x in sse_events if x.get("event") == "thinking.insight"]
    assert thinking_events, "expected thinking.insight even when provider emits no summary"
    last_thinking = thinking_events[-1].get("data")
    assert isinstance(last_thinking, dict)
    assert last_thinking.get("provider") == "openai"
    assert last_thinking.get("mode") == "summary"
    assert not str(last_thinking.get("text", "")).strip()


def test_openai_thinking_insight_coalesces_reasoning_chunks_without_duplicates(monkeypatch):
    calls: Dict[str, Any] = {}

    def _factory(api_key: Optional[str] = None):
        inst = FakeOpenAI(
            api_key,
            stream_events=[
                FakeEvent("response.reasoning.delta", delta={"text": "**Preparing"}),
                FakeEvent("response.reasoning.delta", delta={"text": "friendly"}),
                FakeEvent("response.reasoning.delta", delta={"text": "greeting**"}),
                FakeEvent(
                    "response.reasoning.done",
                    summary={"text": "**Preparing friendly greeting**"},
                ),
                FakeEvent("response.output_text.delta", delta="Hey there"),
            ],
            emit_reasoning_item=False,
        )
        calls["inst"] = inst
        return inst

    import app.routers.chat as chat_router

    try:
        app.include_router(chat_router.router, prefix="/v0")
    except Exception:
        pass

    monkeypatch.setattr(chat_router, "OpenAI", _factory)  # type: ignore
    monkeypatch.setattr(settings, "ENABLE_THINKING_INSIGHTS_DEFAULT", False)

    client = TestClient(app)
    payload = {
        "model": "gpt-5",
        "messages": [{"role": "user", "content": "say hi"}],
        "enable_tools": False,
        "enable_thinking_insights": True,
    }

    sse_events = _collect_sse_events(client, payload)
    thinking_events = [x for x in sse_events if x.get("event") == "thinking.insight"]
    assert len(thinking_events) == 1, "expected one coalesced thinking.insight event"
    thinking_data = thinking_events[0].get("data")
    assert isinstance(thinking_data, dict)
    assert "preparing friendly greeting" in str(thinking_data.get("text", "")).lower()

    names = [str(x.get("event") or "") for x in sse_events]
    assert "message.delta" in names
    assert names.index("thinking.insight") < names.index("message.delta")
