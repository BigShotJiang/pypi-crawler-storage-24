"""Legacy compatibility shim for older module entry paths.

The canonical console entrypoint is the main interactive CLI. This module keeps
the historical forwarder behavior for direct imports without advertising a
second package name.
"""

from __future__ import annotations


def main() -> None:
    from cli import main as _main

    _main()
