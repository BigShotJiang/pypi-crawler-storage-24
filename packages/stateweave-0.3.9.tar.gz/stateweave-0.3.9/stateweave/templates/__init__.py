"""StateWeave project templates."""
