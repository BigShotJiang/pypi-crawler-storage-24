from sqlalchemy import MetaData, Table, Column, String, Integer, Float, JSON

metadata = MetaData()

stockingpoint_data = Table(
    "stockingpoint_data",
    metadata,
    Column("scenario_id", String, nullable=False, primary_key=True),
    Column("key", String, nullable=False, primary_key=True),
    Column("echelon", Integer, nullable=False),
    Column("location", String, nullable=False),
    Column("ip_target", Float, nullable=True),
    Column("dem_dist", String, nullable=True),
    Column("dem_params", JSON, nullable=True),
)

demand_data = Table(
    "demand_data",
    metadata,
    Column("scenario_id", String, nullable=False, primary_key=True),
    Column("source_key", String, nullable=False, primary_key=True),
    Column("target_key", String, nullable=False, primary_key=True),
)

supply_data = Table(
    "supply_data",
    metadata,
    Column("scenario_id", String, nullable=False, primary_key=True),
    Column("source_key", String, nullable=False, primary_key=True),
    Column("target_key", String, nullable=False, primary_key=True),
    Column("lead_time", Float, nullable=False),
)


def get_metadata() -> MetaData:
    return metadata
