"""
Factory functions for the repositories that fall back to the default configured
settings. Useful for override runtime config uri during testing as well as for
public convenience.
"""

from functools import cache

from anystore.types import Uri

from ftm_lakehouse.core.api import ensure_api_uri
from ftm_lakehouse.core.settings import Settings
from ftm_lakehouse.repository.archive import ArchiveRepository
from ftm_lakehouse.repository.documents import DocumentRepository
from ftm_lakehouse.repository.entities import EntityRepository
from ftm_lakehouse.repository.job import J, JobRepository
from ftm_lakehouse.repository.mapping import MappingRepository
from ftm_lakehouse.storage.tags import TagStore
from ftm_lakehouse.storage.versions import VersionStore


@cache
def get_archive(dataset: str, uri: Uri | None = None) -> ArchiveRepository:
    """
    Get the archive repository for a dataset.

    Args:
        dataset: Dataset name
        uri: Dataset URI override (default: {LAKEHOUSE_URI}/{dataset})

    Returns:
        ArchiveRepository instance (cached)
    """
    settings = Settings()
    uri = uri or f"{settings.uri}/{dataset}"
    return ArchiveRepository(dataset, uri)


@cache
def get_entities(dataset: str, uri: Uri | None = None) -> EntityRepository:
    """
    Get the entity repository for a dataset.

    Args:
        dataset: Dataset name
        uri: Dataset URI override (default: {LAKEHOUSE_URI}/{dataset})

    Returns:
        EntityRepository instance (cached)
    """
    settings = Settings()
    uri = uri or f"{settings.uri}/{dataset}"
    return EntityRepository(dataset, uri)


@cache
def get_documents(dataset: str, uri: Uri | None = None) -> DocumentRepository:
    """
    Get the document repository for a dataset.

    Args:
        dataset: Dataset name
        uri: Dataset URI override (default: {LAKEHOUSE_URI}/{dataset})

    Returns:
        DocumentRepository instance (cached)
    """
    settings = Settings()
    uri = uri or f"{settings.uri}/{dataset}"
    return DocumentRepository(dataset, uri)


@cache
def get_mappings(dataset: str, uri: Uri | None = None) -> MappingRepository:
    """
    Get the mappings repository for a dataset.

    Args:
        dataset: Dataset name
        uri: Dataset URI override (default: {LAKEHOUSE_URI}/{dataset})

    Returns:
        MappingRepository instance (cached)
    """
    settings = Settings()
    uri = uri or f"{settings.uri}/{dataset}"
    return MappingRepository(dataset, uri)


@cache
def get_jobs(dataset: str, model: type[J], uri: Uri | None = None) -> JobRepository[J]:
    """
    Get the job repository for a dataset.

    Args:
        dataset: Dataset name
        model: Job model class
        uri: Dataset URI override (default: {LAKEHOUSE_URI}/{dataset})

    Returns:
        JobRepository instance (cached)
    """
    settings = Settings()
    uri = uri or f"{settings.uri}/{dataset}"
    return JobRepository(dataset, uri, model)


@cache
def get_versions(dataset: str, uri: Uri | None = None) -> VersionStore:
    """
    Get the version store for a dataset.

    Args:
        dataset: Dataset name
        uri: Dataset URI override (default: {LAKEHOUSE_URI}/{dataset})

    Returns:
        VersionStore instance (cached)
    """
    settings = Settings()
    uri = uri or f"{settings.uri}/{dataset}"
    uri = ensure_api_uri(uri)
    return VersionStore(uri)


@cache
def get_tags(
    dataset: str, uri: Uri | None = None, tenant: str | None = None
) -> TagStore:
    """
    Get the tag store for a dataset.

    Args:
        dataset: Dataset name
        uri: Dataset URI override (default: {LAKEHOUSE_URI}/{dataset})
        tenant: Tag tenant/namespace

    Returns:
        TagStore instance (cached)
    """
    settings = Settings()
    uri = uri or f"{settings.uri}/{dataset}"
    uri = ensure_api_uri(uri)
    return TagStore(uri, tenant)
