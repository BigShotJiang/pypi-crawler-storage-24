class ImproperlyConfigured(BaseException):
    pass
