"""File metadata model."""

from datetime import datetime
from pathlib import Path
from typing import Any, Generator, Self, TypeAlias

from anystore.model import Stats
from anystore.model.base import BaseModel
from anystore.types import HttpUrlStr
from anystore.util import guess_mimetype
from followthemoney import EntityProxy, StatementEntity
from ftmq.types import StatementEntities
from ftmq.util import DEFAULT_DATASET, make_entity
from pydantic import ConfigDict, computed_field, field_validator, model_validator

from ftm_lakehouse.core.conventions import path
from ftm_lakehouse.helpers.file import (
    make_file_id,
    make_folders,
    mime_to_schema,
    pick_mime,
)
from ftm_lakehouse.util import validate_checksum


class Document(BaseModel):
    """Condensed file metadata for flat csv streaming"""

    id: str
    checksum: str
    name: str
    mimetype: str
    path: str | None = None
    size: int | None = None
    updated_at: datetime | None = None
    public_url: HttpUrlStr | None = None

    @field_validator("checksum")
    @classmethod
    def check_checksum(cls, v: str) -> str:
        return validate_checksum(v)

    @classmethod
    def from_entity(cls, e: EntityProxy, public_url: str | None = None) -> Self:
        checksum = e.first("contentHash")
        if checksum is None or not e.id:
            raise ValueError(f"Missing contentHash for entity id `{e.id}`")
        return cls(
            id=e.id,
            checksum=checksum,
            name=e.caption,
            mimetype=pick_mime(e.get("mimeType"), guess_mimetype(e.caption)),
            size=e.first("fileSize") or 0,
            updated_at=getattr(e, "last_change", None),
            public_url=public_url,
        )

    @classmethod
    def from_entity_dict(
        cls, d: dict[str, Any], public_url: str | None = None
    ) -> Self | None:
        """Create a Document from an entity dict (as returned by query_raw).

        Returns None when required fields are missing.
        """
        props = d.get("properties", {})
        checksums = props.get("contentHash", [])
        if not checksums or not d.get("id"):
            return None
        caption = d.get("caption", "")
        mimetypes = props.get("mimeType", [])
        file_sizes = props.get("fileSize", [])
        return cls(
            id=d["id"],
            checksum=checksums[0],
            name=caption,
            mimetype=pick_mime(mimetypes, guess_mimetype(caption)),
            size=int(file_sizes[0]) if file_sizes else 0,
            updated_at=d.get("last_change"),
            public_url=public_url,
        )

    @property
    def relative_path(self) -> str:
        if self.path is None:
            return self.name
        return f"{self.path}/{self.name}"


class File(Stats):
    """File metadata model. Arbitrary data can be stored in `extra`, including
    ftm properties that should be added to the generated Entity"""

    model_config = ConfigDict(extra="allow")

    dataset: str
    """Dataset name"""
    checksum: str
    """SHA256 checksum (often referred to as `content_hash`)"""
    extra: dict[str, Any] = {}
    """Arbitrary extra data"""
    origin: str | None = None
    """Origin stage of this file"""

    @field_validator("checksum")
    @classmethod
    def check_checksum(cls, v: str) -> str:
        return validate_checksum(v)

    @field_validator("store")
    @classmethod
    def hide_store(cls, v: str) -> str:
        # always don't include original store uri
        return "lakehouse://"

    @model_validator(mode="before")
    @classmethod
    def collect_extra_fields(cls, data: Any) -> Any:
        if not isinstance(data, dict):
            return data
        known_fields = set(cls.model_fields.keys())
        known_fields.update(["id", "path", "parent"])  # computed_field
        extra = data.get("extra", {})
        extra_fields = {k: v for k, v in data.items() if k not in known_fields}
        if extra_fields:
            data = {k: v for k, v in data.items() if k in known_fields}
            data["extra"] = {**extra, **extra_fields}
        return data

    def to_entity(self) -> StatementEntity:
        """Make an entity for this File"""
        schema = mime_to_schema(self.mimetype)
        entity = make_entity(
            {"id": self.id, "schema": schema},
            entity_type=StatementEntity,
            default_dataset=self.dataset,
        )
        entity.add("contentHash", self.checksum)
        entity.add("fileName", self.name)
        entity.add("fileSize", self.size)
        entity.add("mimeType", self.mimetype)
        entity.add("parent", self.parent)
        for prop in schema.properties:
            if prop in self.extra:
                entity.add(prop, self.extra[prop])
        return entity

    def make_parents(self) -> StatementEntities:
        """Make parent `Folder` entities"""
        parent = Path(self.key).parent
        if parent.name:
            yield from make_folders(parent, dataset=self.dataset)

    def make_entities(self) -> StatementEntities:
        yield from self.make_parents()
        yield self.to_entity()

    @computed_field
    @property
    def id(self) -> str:
        """The entity id is generated by a hash of the file path and the
        checksum. Uses just the checksum as id if that's the key"""
        if self.key == self.checksum:
            return self.checksum
        return make_file_id(self.key, self.checksum)

    @computed_field
    @property
    def path(self) -> str:
        # "key" can be misleading in the codebase so this is an alias
        return self.key

    @computed_field
    @property
    def parent(self) -> str | None:
        for parent in reversed(list(self.make_parents())):
            return parent.id

    @property
    def blob_path(self) -> str:
        """Relative path to blob in dataset archive"""
        return path.archive_blob(self.checksum)

    @property
    def meta_path(self) -> str:
        """Relative path for this file's metadata json in dataset archive"""
        return path.archive_meta(self.checksum, self.id)

    @classmethod
    def from_info(cls, info: Stats, checksum: str, **data) -> Self:
        data["dataset"] = data.get("dataset", DEFAULT_DATASET)
        data["checksum"] = checksum
        return cls(**{**info.model_dump(), **data})

    def to_document(self) -> Document:
        return Document(
            id=self.id,
            checksum=self.checksum,
            name=self.name,
            path=self.path,
            size=self.size,
            mimetype=self.mimetype,
            updated_at=self.updated_at,
        )


Files: TypeAlias = Generator[File, None, None]
"""Type shorthand for a generator of `File` objects"""


Documents: TypeAlias = Generator[Document, None, None]
"""Type shorthand for a generator of `Document` objects"""
