"""Server lifespan management utilities.

Initializes the agent at startup and cleans up resources on shutdown.
"""

import inspect
import logging
from collections.abc import Sequence
from contextlib import asynccontextmanager

from fastapi import FastAPI
from idun_agent_schema.engine.guardrails import Guardrails

from ..core.config_builder import ConfigBuilder
from ..guardrails.base import BaseGuardrail
from ..telemetry import get_telemetry, sanitize_telemetry_config

logger = logging.getLogger(__name__)


def _parse_guardrails(guardrails_obj: Guardrails) -> Sequence[BaseGuardrail]:
    """Adds the position of the guardrails (input/output) and returns the lift of updated guardrails."""
    from ..guardrails.guardrails_hub.guardrails_hub import GuardrailsHubGuard as GHGuard

    if not guardrails_obj:
        return []

    return [GHGuard(guard, position="input") for guard in guardrails_obj.input] + [
        GHGuard(guard, position="output") for guard in guardrails_obj.output
    ]


async def cleanup_agent(app: FastAPI):
    """Clean up agent resources."""
    agent = getattr(app.state, "agent", None)
    if agent is not None:
        close_fn = getattr(agent, "close", None)
        if callable(close_fn):
            result = close_fn()
            if inspect.isawaitable(result):
                await result


async def configure_app(app: FastAPI, engine_config):
    """Initialize the agent, MCP registry, guardrails, and app state with the given engine config."""
    guardrails_obj = engine_config.guardrails
    guardrails = _parse_guardrails(guardrails_obj) if guardrails_obj else []

    logger.debug(f"Guardrails: {guardrails}")

    # Use ConfigBuilder's centralized agent initialization, passing the registry
    try:
        agent_instance = await ConfigBuilder.initialize_agent_from_config(engine_config)
    except Exception as e:
        raise ValueError(
            f"Error retrieving agent instance from ConfigBuilder: {e}"
        ) from e

    app.state.agent = agent_instance
    app.state.config = engine_config
    app.state.engine_config = engine_config

    app.state.guardrails = guardrails

    # SSO / OIDC setup
    sso_config = engine_config.sso
    if sso_config and sso_config.enabled:
        from ..server.auth import OIDCValidator

        app.state.sso_validator = OIDCValidator(sso_config)
        logger.info(f"🔒 SSO enabled — issuer: {sso_config.issuer}")
    else:
        app.state.sso_validator = None

    agent_name = getattr(agent_instance, "name", "Unknown")
    logger.info(f"✅ Agent '{agent_name}' initialized and ready to serve!")

    # Setup AGUI routes if the agent is a LangGraph agent
    from ..agent.adk.adk import AdkAgent
    from ..agent.langgraph.langgraph import LanggraphAgent

    if isinstance(agent_instance, (LanggraphAgent, AdkAgent)):
        try:
            app.state.copilotkit_agent = agent_instance.copilotkit_agent_instance
        except Exception as e:
            logger.warning(f"⚠️ Failed to setup AGUI routes: {e}")
            # Continue even if AGUI setup fails

    # Cache agent capabilities for discovery endpoint
    if hasattr(agent_instance, "discover_capabilities"):
        try:
            app.state.capabilities = agent_instance.discover_capabilities()
            logger.info(
                f"📋 Agent capabilities discovered: "
                f"input={app.state.capabilities.input.mode}, "
                f"output={app.state.capabilities.output.mode}"
            )
        except Exception as e:
            logger.warning(f"⚠️ Failed to discover agent capabilities: {e}")
            app.state.capabilities = None

    # Setup integrations (WhatsApp, etc.)
    if engine_config.integrations:
        from ..integrations import setup_integrations

        app.state.integrations = await setup_integrations(
            app, engine_config.integrations, agent_instance
        )
    else:
        app.state.integrations = []


@asynccontextmanager
async def lifespan(app: FastAPI):
    """FastAPI lifespan context to initialize and teardown the agent."""
    # Apply monkey patches for upstream ag-ui bugs (safe to remove once fixed upstream)
    from .patches import apply_all as _apply_ag_ui_patches

    _apply_ag_ui_patches()

    # Load config and initialize agent on startup
    logger.info("🚀 Server starting up...")
    if not app.state.engine_config:
        raise ValueError("Error: No Engine configuration found.")

    await configure_app(app, app.state.engine_config)

    try:
        telemetry = get_telemetry()
        app.state.telemetry = telemetry
        agent = getattr(app.state, "agent", None)
        telemetry.capture(
            "engine started",
            properties={
                "agent_type": type(agent).__name__ if agent is not None else None,
                "has_agent": agent is not None,
                "engine_config": sanitize_telemetry_config(app.state.engine_config),
            },
        )
    except Exception as e:
        logger.warning(f"⚠️ Failed to start telemetry: {e}")
        app.state.telemetry = None

    yield

    # Clean up on shutdown
    logger.info("🔄 Idun Agent Engine shutting down...")

    # Shutdown integrations
    for integration in getattr(app.state, "integrations", []):
        try:
            await integration.shutdown()
        except Exception as e:
            logger.warning(f"⚠️ Failed to shutdown integration: {e}")

    telemetry = getattr(app.state, "telemetry", None)
    if telemetry is not None:
        telemetry.capture("engine stopped")
    await cleanup_agent(app)
    if telemetry is not None:
        telemetry.shutdown()
    logger.info("✅ Agent resources cleaned up successfully.")
