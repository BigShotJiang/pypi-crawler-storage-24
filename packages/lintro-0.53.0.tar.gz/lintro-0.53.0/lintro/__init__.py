"""Lintro - A unified CLI core for code formatting, linting, and quality assurance."""

__version__ = "0.53.0"
