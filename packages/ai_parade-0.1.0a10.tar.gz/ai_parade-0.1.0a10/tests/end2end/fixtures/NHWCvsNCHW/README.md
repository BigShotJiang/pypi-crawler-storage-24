# Tests for channel order

Use this model to determine if the channel order is correctly set.

Before you can start testing download dependencies (`uv sync`) and run `init.sh`.
The init script generates a models and image to run on them.
The init script also prints what are the expected result and the wrong result.

Use these models with the `testImage.png` and observe the results.
