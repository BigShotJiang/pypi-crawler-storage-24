from enum import StrEnum


class AIRuntime(StrEnum):
	TensorFlow = "TensorFlow"
	PyTorch = "PyTorch"
	ExecuTorch = "ExecuTorch"
	LiteRT = "LiteRT"
	ncnn = "ncnn"
	ONNXRuntime = "ONNXRuntime"
	# New AI Runtime: update here
