from enum import StrEnum


class HardwareAcceleration(StrEnum):
	"""Enumeration for hardware acceleration options."""

	CPU = "CPU"
	GPU = "GPU"
	XNNPACK = "XNNPACK"
	NNAPI = "NNAPI"
	QNN = "QNN"
	Vulkan = "Vulkan"
	OpenGLES = "OpenGLES"
	OpenCL = "OpenCL"
	Mediatek = "Mediatek"
	Metal = "Metal"
	CoreML = "CoreML"
	GoogleTensor = "GoogleTensor"
	Exynos = "Exynos"


COMMON_HW_ACCELERATIONS = {
	HardwareAcceleration.CPU,
	HardwareAcceleration.GPU,
	HardwareAcceleration.XNNPACK,
	HardwareAcceleration.NNAPI,
	HardwareAcceleration.Vulkan,
	HardwareAcceleration.OpenGLES,
	HardwareAcceleration.OpenCL,
	# Apple specific:
	HardwareAcceleration.Metal,
	HardwareAcceleration.CoreML,
}
