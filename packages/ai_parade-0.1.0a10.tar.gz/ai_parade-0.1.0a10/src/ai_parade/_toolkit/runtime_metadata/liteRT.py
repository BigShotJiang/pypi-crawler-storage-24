from ..enums import (
	AIRuntime,
	HardwareAcceleration,
	ModelFormat,
	Platform,
	Quantization,
)
from ._common import ModelAttributes

runtime = AIRuntime.LiteRT
capabilities = {
	Platform.Android: {
		Quantization.none: {
			HardwareAcceleration.XNNPACK,
			HardwareAcceleration.GPU,  # == OpenCL or EGL
			HardwareAcceleration.QNN,
			HardwareAcceleration.Mediatek,
			HardwareAcceleration.GoogleTensor,
		},
		Quantization.int8: {
			HardwareAcceleration.XNNPACK,
			HardwareAcceleration.GPU,  # == OpenCL or EGL
			HardwareAcceleration.QNN,
			HardwareAcceleration.Mediatek,
			HardwareAcceleration.GoogleTensor,
		},
		Quantization.float16: {
			HardwareAcceleration.XNNPACK,
			HardwareAcceleration.GPU,  # == OpenCL or EGL
			HardwareAcceleration.QNN,
			HardwareAcceleration.Mediatek,
			HardwareAcceleration.GoogleTensor,
		},
	},
	Platform.IOS: {
		Quantization.none: {
			# ?todo:
			HardwareAcceleration.CPU,
			HardwareAcceleration.XNNPACK,
			HardwareAcceleration.GPU,  # ?todo: == Metal
		},
		Quantization.int8: {
			HardwareAcceleration.CPU,
			HardwareAcceleration.XNNPACK,
			HardwareAcceleration.GPU,
		},
		Quantization.float16: {
			HardwareAcceleration.CPU,
			HardwareAcceleration.XNNPACK,
			HardwareAcceleration.GPU,
		},
	},
}

format = ModelFormat.LiteRT
format_distinguishes = [ModelAttributes.Quantization]
