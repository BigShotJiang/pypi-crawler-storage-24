# AgenticConnect Python SDK

Pure-Python SDK that wraps the `acnx` CLI binary.

```bash
pip install agentic-connect
```
