"""AgenticConnect — Universal external interface for AI agents.

Pure-Python SDK that wraps the ``acnx`` CLI binary via subprocess.
Zero required dependencies; only stdlib: subprocess, json, pathlib, dataclasses.
"""

from __future__ import annotations

import json
import logging
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

__version__ = "0.1.0"

logger = logging.getLogger(__name__)


class ConnectError(Exception):
    """Raised when an acnx CLI command fails."""


@dataclass
class ConnectStore:
    """Interface to an ``.acnx`` connection store file.

    Parameters
    ----------
    path : str | Path
        Path to the ``.acnx`` file. Created automatically on first write
        if it does not exist.
    binary : str
        Name or path of the ``acnx`` CLI binary.
    """

    path: str | Path
    binary: str = "acnx"
    _resolved_binary: Optional[str] = field(default=None, repr=False, init=False)

    def __post_init__(self) -> None:
        self.path = Path(self.path)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _find_binary(self) -> str:
        if self._resolved_binary is not None:
            return self._resolved_binary

        import shutil

        found = shutil.which(self.binary)
        if found is None:
            raise ConnectError(
                f"Cannot find '{self.binary}' on PATH. "
                "Install AgenticConnect: curl -fsSL https://agentralabs.tech/install/connect | bash"
            )
        self._resolved_binary = found
        return found

    def _run(self, *args: str, check: bool = True) -> str:
        """Execute an acnx CLI command and return stdout."""
        cmd = [self._find_binary(), "--file", str(self.path), *args]
        logger.debug("Running: %s", " ".join(cmd))
        result = subprocess.run(cmd, capture_output=True, text=True)
        if check and result.returncode != 0:
            raise ConnectError(
                f"acnx command failed (exit {result.returncode}): {result.stderr.strip()}"
            )
        return result.stdout.strip()

    def _run_json(self, *args: str) -> Any:
        """Execute a command and parse JSON output."""
        raw = self._run(*args, "--format", "json")
        return json.loads(raw) if raw else {}

    # ------------------------------------------------------------------
    # Connection operations
    # ------------------------------------------------------------------

    def detect_protocol(self, url: str) -> dict[str, Any]:
        """Detect the protocol for a given URL. Returns protocol metadata."""
        return self._run_json("protocol", "detect", url)

    def create_connection(
        self,
        name: str,
        url: str,
        *,
        protocol: Optional[str] = None,
        auth: Optional[str] = None,
    ) -> str:
        """Create a new connection. Returns the connection ID."""
        args = ["connection", "create", name, url]
        if protocol:
            args.extend(["--protocol", protocol])
        if auth:
            args.extend(["--auth", auth])
        return self._run(*args)

    def test_connection(self, name: str) -> dict[str, Any]:
        """Test an existing connection. Returns test results."""
        return self._run_json("connection", "test", name)

    def list_connections(self, *, status: Optional[str] = None) -> list[dict[str, Any]]:
        """List all connections, optionally filtered by status."""
        args = ["connection", "list", "--format", "json"]
        if status:
            args.extend(["--status", status])
        raw = self._run(*args)
        return json.loads(raw) if raw else []

    # ------------------------------------------------------------------
    # Stats
    # ------------------------------------------------------------------

    def stats(self) -> dict[str, Any]:
        """Get connection store statistics."""
        raw = self._run("stats", "--format", "json")
        return json.loads(raw) if raw else {}

    # ------------------------------------------------------------------
    # File operations
    # ------------------------------------------------------------------

    def save(self) -> None:
        """Explicit save (most operations auto-save)."""
        pass

    @property
    def exists(self) -> bool:
        """Whether the .acnx file exists on disk."""
        return self.path.exists()
