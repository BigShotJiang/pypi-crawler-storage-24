# Copyright (C) 2014 the2nd <the2nd@otpme.org>
import os

try:
    if os.environ['OTPME_DEBUG_MODULE_LOADING'] == "True":
        msg = _("Loading module: {module_name}")
        msg = msg.format(module_name=__name__)
        print(msg)
except:
    pass

from .get_class import get_class

REGISTER_BEFORE = []
REGISTER_AFTER = []

modules = [
        'otpme.lib.smartcard.u2f.u2f',
        'otpme.lib.smartcard.fido2.fido2',
        'otpme.lib.smartcard.yubikey_hmac.yubikey_hmac',
        'otpme.lib.smartcard.yubikey_hotp.yubikey_hotp',
        'otpme.lib.smartcard.yubikey_piv.yubikey_piv',
        'otpme.lib.smartcard.yubikey_gpg.yubikey_gpg',
        ]

def register():
    """ Register modules. """
    from ..register import _register_modules
    _register_modules(modules)
