# ai-receipt-chain

> **This package has been consolidated into [`aiir`](https://pypi.org/project/aiir/).**

## Install the real package

```bash
pip install aiir
```

## What is AIIR?

**AI Integrity Receipts** — lightweight cryptographic commitment records
generated during AI inference that bind model identity, sampling configuration,
and output tokens into a tamper-evident hash chain.

- Zero external dependencies (Python stdlib only)
- Receipt generation in < 100 µs
- SHA-256 hash chains with O(1) amortized cost
- Works with any model format (GGUF, ONNX, cloud APIs)
- MCP server for Claude / Copilot / ChatGPT integration

## Links

- **PyPI**: [aiir](https://pypi.org/project/aiir/)
- **GitHub**: [invariant-systems-ai/receipt-action](https://github.com/invariant-systems-ai/receipt-action)
- **Paper**: [Attestable AI: Cryptographic Receipt-Binding for Local Generative Model Inference](https://arxiv.org/abs/XXXX.XXXXX)

---

*This package (`ai-receipt-chain`) exists to redirect users to the canonical `aiir` package.
Installing it will automatically install `aiir` as a dependency.*
