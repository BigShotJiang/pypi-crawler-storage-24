# CodeBrain

Structural intelligence for AI-assisted development. CodeBrain builds a
persistent knowledge graph of your codebase and validates changes before
they land — preventing AI coding agents from silently breaking things.

## The Problem

AI coding agents (Claude Code, Cursor, Copilot) generate code faster than
you can review it. They grep fragments, apply local fixes, and don't
maintain a mental model. When the AI removes a function, it doesn't know
3 other files call it.

CodeBrain knows.

## Quick Start

### 1. Install

```bash
pip install codebrain
```

Optional extras:

```bash
pip install codebrain[api]   # REST API server
pip install codebrain[llm]   # LLM-enhanced explanations
pip install codebrain[ts]    # TypeScript AST parser (tree-sitter)
pip install codebrain[all]   # Everything
```

### 2. Index your project

```bash
cd your-project
brain init
```

### 3. Connect to Claude Code

```bash
brain agent  # generates CLAUDE.md + MCP config
```

Or add to your MCP config manually:

```json
{
  "mcpServers": {
    "codebrain": {
      "command": "python",
      "args": ["-m", "codebrain.mcp_server"],
      "cwd": "/path/to/your/repo"
    }
  }
}
```

### 4. That's it

CodeBrain will automatically validate changes before Claude writes them.
When a change would break something, it says so — with the specific files
and callers that would be affected.

## What It Does

### Structural Safety Gate

Before an AI agent writes a file, CodeBrain checks if the change would break
callers in other files. If it would, the agent is told to fix the breakage first.

### Impact Analysis

"What would break if I change this?" — answers with specific files, symbols,
and call chains. Not grep results. Deterministic graph traversal.

### Risk Hotspots

Identifies the most structurally dangerous code — functions called by many files,
modules with high coupling, symbols where a signature change would cascade.

### Dead Code Detection

Finds unused symbols with confidence levels. High-confidence means it's really dead.
Medium means the file uses dynamic patterns. Low means it might be used indirectly.

### Comprehension Narratives

Plain English explanations: "store.py is the most depended-on file — 8 modules
import from it. Changes here have the highest blast radius in the codebase."

## CLI Commands

| Command | Description |
|---------|-------------|
| `brain init` | Index the current repository |
| `brain reindex` | Force a full rebuild |
| `brain status [--json]` | Show index statistics |
| `brain search <query> [--json]` | Find symbols by name |
| `brain trace <name> [--depth N] [--json]` | Forward call chain |
| `brain impact <name> [--depth N] [--json]` | Reverse impact analysis |
| `brain deps <name> [--json]` | Dependencies of a symbol or file |
| `brain deadcode [--json]` | Find unused functions/classes |
| `brain cycles [--json]` | Detect import cycles |
| `brain validate <file> [--json]` | Check if a file change is safe |
| `brain overview [--json]` | System-level codebase overview |
| `brain module <file> [--json]` | Module-level view |
| `brain context <name> [--json]` | LLM-optimized symbol context |
| `brain hotspots [--top N] [--json]` | Riskiest symbols |
| `brain coupling [--json]` | Module coupling analysis |
| `brain contracts [--json]` | Implicit contract detection |
| `brain layers [--json]` | Architectural layer inference |
| `brain doctor` | Diagnostic health check |
| `brain zoom [target] [--json]` | Multi-resolution navigation (system/package/module/symbol) |
| `brain ci [--base B] [--fail-on F] [--json]` | CI validation of changed files |
| `brain diff` | Show files changed since last index |
| `brain watch` | Start file watcher daemon |
| `brain repair` | Check database integrity, rebuild if corrupted |
| `brain mcp` | Start MCP server (stdio) |
| `brain hook install` | Install pre-commit hook |
| `brain hook uninstall` | Remove pre-commit hook |
| `brain agent` | Generate agent integration files |
| `brain serve [--host H] [--port P]` | Start REST API server |

All commands accept `--repo <path>` to specify a different repository root, `--verbose` for debug logging, and `--timeout N` to set analysis timeout in seconds (default: 120).

## MCP Tools (for AI agents)

22+ tools available via MCP protocol. Key tools:

| Tool | Purpose |
|------|---------|
| `propose_change` | Validate before writing — the structural safety gate |
| `impact_analysis` | Trace transitive dependents of any symbol |
| `get_file_context` | Full file understanding for LLM context |
| `get_symbol_context` | Full symbol understanding for LLM context |
| `ask_codebase` | Natural language questions about the codebase |
| `validate_change` | Check if a file change would break callers |
| `risk_hotspots` | Find structurally dangerous symbols |
| `find_dead_code` | Unused symbols with confidence levels |
| `codebase_overview` | System-level architecture summary |
| `get_task_context` | Pull relevant context for a development task |

See [docs/mcp-tools.md](docs/mcp-tools.md) for full documentation.

## Configuration

Create `.codebrain.toml` in your repo root:

```toml
[codebrain]
# Extra directories to skip during indexing
skip_dirs = ["__pycache__", ".git", "node_modules", "vendor"]

# File extensions to index
extensions = [".py", ".ts", ".tsx", ".js", ".jsx"]

# Watcher debounce interval (seconds)
watcher_debounce = 0.5

# File count threshold for parallel parsing
parallel_threshold = 50

# Maximum file size to index (KB)
max_file_size_kb = 1024
```

Environment variables override the config file:

| Variable | Description |
|----------|-------------|
| `CODEBRAIN_SKIP_DIRS` | Comma-separated skip directories |
| `CODEBRAIN_EXTENSIONS` | Comma-separated file extensions |
| `CODEBRAIN_DEBOUNCE` | Watcher debounce seconds |
| `CODEBRAIN_PARALLEL_THRESHOLD` | Parallel parsing threshold |
| `CODEBRAIN_MAX_WORKERS` | Max parallel worker processes |
| `CODEBRAIN_CLI_TIMEOUT` | CLI analysis timeout in seconds (default: 120) |

See [docs/configuration.md](docs/configuration.md) for full reference.

## Language Support

- **Python**: Full AST parsing (stable)
- **TypeScript/JavaScript**: tree-sitter parsing (`pip install codebrain[ts]`)
- **TypeScript fallback**: regex-based (experimental, limited coverage)

## CI Integration

### Pre-commit Hook

```bash
brain hook install   # validates staged files before every commit
brain hook uninstall # remove the hook
```

The hook blocks commits with critical structural violations. Use `git commit --no-verify` to bypass.

### CI Pipeline

```bash
brain ci --base main           # exits 1 if UNSAFE changes detected
brain ci --base main --json    # machine-readable output
brain ci --fail-on caution     # stricter: also fail on CAUTION
```

### GitHub Action

```yaml
# .github/workflows/codebrain.yml
name: CodeBrain Validation
on: [pull_request]
jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0
      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - run: pip install codebrain
      - run: brain ci --base origin/main --json
```

Or use the reusable composite action:

```yaml
- uses: ./.github/actions/codebrain-validate
  with:
    base-branch: main
    fail-on: unsafe
```

## VS Code Extension

See [`vscode-extension/`](vscode-extension/) — 5 commands (impact, context, search, validate, hotspots) plus validate-on-save with inline diagnostics.

## REST API

```bash
pip install codebrain[api]
brain serve --port 8484
```

~20 endpoints at `/api/status`, `/api/search`, `/api/impact/{name}`, `/api/hotspots`, etc. Interactive docs at `/docs`.

## Plugin System

Add custom language parsers by implementing `BaseParser` and registering via entry points:

```python
from codebrain.parser.base import BaseParser

class RustParser(BaseParser):
    def extensions(self) -> frozenset[str]:
        return frozenset({".rs"})

    def parse(self, path, repo_root):
        ...  # return ParsedFile
```

```toml
# pyproject.toml
[project.entry-points."codebrain.parsers"]
rust = "your_package.parser:RustParser"
```

## Architecture

```
Source Files  -->  Parser (Python/TS)  -->  ParsedFile (Nodes + Edges)
                                                  |
                                            GraphStore (SQLite)
                                                  |
                                            QueryEngine
                                                  |
                          CLI / MCP / REST API / VS Code / Agent Bridge
```

**Key abstractions:**

- **Node** — a code symbol (function, class, method, variable)
- **Edge** — a relationship (CALLS, IMPORTS, CONTAINS, EXTENDS, DATAFLOW)
- **GraphStore** — CRUD over the SQLite knowledge graph
- **QueryEngine** — impact analysis, call chains, dead code, cycles

## Validated on Real Codebases

CodeBrain has been tested on a 1,328-file mixed Python + TypeScript project (17,756 symbols, 111,793 edges):

- **Indexing**: 1,328 files in 135s, zero errors
- **Health score**: 93/100 in under 5s
- **Impact analysis**: Traces `getAstroData` → 48 dependents across 69 files
- **Contracts**: Found `Colors` + `Spacing` co-imported in 141/141 files (confidence 1.0)
- **Coupling**: Identified `logger.py` ↔ `main.py` (score 140)
- **Layers**: Detected architectural cycles in `kp-astrology` module
- **752 tests passing** across unit, integration, and real-world validation

## Development

```bash
git clone https://github.com/monk0062006/CodeBrain.git
cd CodeBrain
pip install -e ".[dev]"

pytest tests/ -v              # Run tests
mypy codebrain/               # Type checking
ruff check codebrain/         # Linting
pytest --cov=codebrain        # Coverage
```

## License

MIT
