"""Interactive prompt renderers and flow runner.

Each renderer takes a :class:`~tinyprompts.prompts.Prompt` and a file
descriptor (from :func:`~tinyprompts.terminal.cbreak_mode`), runs a
read-key / redraw loop, and returns the user's answer (or
:data:`~tinyprompts.prompts.CANCEL`).
"""

from __future__ import annotations

import re
import sys
from typing import Any

from tinyprompts.prompts import CANCEL, Choice, Prompt
from tinyprompts.terminal import (
    ARROW_HINT,
    BLOCK_CHAR,
    BULLET,
    CHECK_OFF,
    CHECK_ON,
    CORNER,
    CROSS,
    CURSOR_CHAR,
    RULE,
    TOGGLE_HINT,
    Style,
    bar,
    clear_lines,
    cbreak_mode,
    flush,
    header,
    read_key,
    styled,
    terminal_width,
)

# ---------------------------------------------------------------------------
# Renderer helpers
# ---------------------------------------------------------------------------


def _compute_window(cursor: int, total: int, max_visible: int) -> tuple[int, int]:
    """Return (start, end) indices for a windowed view centred on *cursor*."""
    if total <= max_visible:
        return 0, total
    half = max_visible // 2
    if cursor < half:
        start = 0
    elif cursor >= total - half:
        start = max(0, total - max_visible)
    else:
        start = cursor - half
    return start, min(start + max_visible, total)


def _render_choice_line(choice: Choice, *, is_cursor: bool, is_selected: bool) -> str:
    arrow = styled(Style.PRIMARY, CURSOR_CHAR) if is_cursor else " "
    check = styled(Style.ACCENT, CHECK_ON) if is_selected else styled(Style.MUTED, CHECK_OFF)
    label = styled(Style.TEXT, choice.label) if is_cursor else choice.label
    hint = f"  {styled(Style.MUTED, choice.hint)}" if choice.hint else ""
    return f"{bar()} {arrow} {check} {label}{hint}"


# ---------------------------------------------------------------------------
# Text renderer
# ---------------------------------------------------------------------------


def _render_text(prompt: Prompt, fd: int) -> Any:
    buf = list(prompt.default or "")
    error_msg = ""

    def _draw(*, final: bool = False) -> int:
        lines: list[str] = []
        if final:
            lines.append(header(Style.ACCENT, prompt.message, "".join(buf) or prompt.default or ""))
        else:
            lines.append(header(Style.PRIMARY, prompt.message))
            if prompt.hint:
                lines.append(f"{bar()}  {styled(Style.MUTED, prompt.hint)}")
            lines.append(bar())
            cursor_text = "".join(buf) + styled(Style.MUTED, BLOCK_CHAR)
            lines.append(f"{bar()}  {styled(Style.PRIMARY, CURSOR_CHAR)} {cursor_text}")
            if error_msg:
                lines.append(f"{bar()}  {styled(Style.ERROR, error_msg)}")
            lines.append(styled(Style.DIM, CORNER))
        return flush(lines)

    prev_lines = _draw()

    while True:
        key = read_key(fd)

        if key == "esc":
            clear_lines(prev_lines)
            return CANCEL

        if key == "enter":
            value = "".join(buf).strip() or prompt.default or ""
            if prompt.validate and not re.match(prompt.validate, value):
                error_msg = "Invalid input. Please try again."
                clear_lines(prev_lines)
                prev_lines = _draw()
                continue
            clear_lines(prev_lines)
            _draw(final=True)
            return value

        if key == "backspace":
            if buf:
                buf.pop()
        elif key == "space":
            buf.append(" ")
            error_msg = ""
        elif len(key) == 1 and key.isprintable():
            buf.append(key)
            error_msg = ""

        clear_lines(prev_lines)
        prev_lines = _draw()


# ---------------------------------------------------------------------------
# Multi-select renderer
# ---------------------------------------------------------------------------


def _build_multiselect_lines(
    prompt: Prompt,
    filtered: list[Choice],
    selected: set[Any],
    cursor: int,
    query: str,
    error_msg: str,
    sel_labels: list[str],
) -> list[str]:
    lines: list[str] = [header(Style.PRIMARY, prompt.message)]
    locked = prompt.locked_section

    if locked:
        tw = terminal_width()
        bar_len = max(0, tw - len(locked.title) - 30)
        rule = RULE * 2 + f" {locked.title} " + RULE * 2 + " always included " + RULE * bar_len
        lines.append(f"{bar()}  {styled(Style.DIM, rule)}")
        for it in locked.items:
            hint = f"  {styled(Style.MUTED, it.hint)}" if it.hint else ""
            lines.append(f"{bar()}    {styled(Style.MUTED, BULLET)} {it.label}{hint}")
        lines.append(bar())

    if prompt.searchable:
        lines.append(f"{bar()}  {styled(Style.MUTED, 'Search:')} {query}{styled(Style.MUTED, BLOCK_CHAR)}")
    lines.append(f"{bar()}  {styled(Style.MUTED, ARROW_HINT)}")
    lines.append(bar())

    n = len(filtered)
    if n == 0:
        lines.append(f"{bar()}  {styled(Style.MUTED, '(no matches)')}")
    else:
        max_v = min(prompt.max_visible, n)
        start, end = _compute_window(cursor, n, max_v)

        if start > 0:
            lines.append(f"{bar()}  {styled(Style.MUTED, f'\u2191 {start} more')}")

        for i in range(start, end):
            lines.append(_render_choice_line(
                filtered[i], is_cursor=(i == cursor), is_selected=(filtered[i].value in selected),
            ))

        remaining = n - end
        if remaining > 0:
            lines.append(f"{bar()}  {styled(Style.MUTED, f'\u2193 {remaining} more')}")

    lines.append(bar())
    summary = ", ".join(sel_labels) if sel_labels else "(none)"
    lines.append(f"{bar()}  {styled(Style.MUTED, 'Selected:')} {styled(Style.ACCENT, summary)}")

    if error_msg:
        lines.append(f"{bar()}  {styled(Style.ERROR, error_msg)}")

    lines.append(styled(Style.DIM, CORNER))
    return lines


def _render_multiselect(prompt: Prompt, fd: int) -> Any:
    choices = prompt.choices
    selected: set[Any] = set(prompt.initial)
    cursor = 0
    query = ""
    error_msg = ""
    locked = prompt.locked_section
    locked_values = [it.value for it in locked.items] if locked else []

    def _filtered() -> list[Choice]:
        if not query:
            return list(choices)
        q = query.lower()
        return [c for c in choices if q in c.label.lower() or q in str(c.value).lower()]

    def _sel_labels() -> list[str]:
        labels = [c.label for c in choices if c.value in selected]
        if locked:
            labels = [it.label for it in locked.items] + labels
        return labels

    def _draw(*, final: bool = False, cancel: bool = False) -> int:
        if cancel:
            cancelled_msg = CROSS + " Cancelled"
            return flush([
                header(Style.ERROR, prompt.message),
                f"{bar()}  {styled(Style.ERROR, cancelled_msg)}",
                styled(Style.DIM, CORNER),
            ])
        if final:
            summary = ", ".join(_sel_labels()) or "(none)"
            return flush([header(Style.ACCENT, prompt.message, summary)])
        return flush(_build_multiselect_lines(
            prompt, _filtered(), selected, cursor, query, error_msg, _sel_labels(),
        ))

    prev_lines = _draw()

    while True:
        key = read_key(fd)
        filtered = _filtered()

        if key == "esc":
            clear_lines(prev_lines)
            _draw(cancel=True)
            return CANCEL

        if key == "enter":
            if prompt.required and not selected and not locked_values:
                error_msg = "At least one selection is required."
                clear_lines(prev_lines)
                prev_lines = _draw()
                continue
            clear_lines(prev_lines)
            _draw(final=True)
            return locked_values + [c.value for c in choices if c.value in selected]

        if key == "up" and filtered:
            cursor = (cursor - 1) % len(filtered)
            error_msg = ""
        elif key == "down" and filtered:
            cursor = (cursor + 1) % len(filtered)
            error_msg = ""
        elif key == "space" and filtered and 0 <= cursor < len(filtered):
            val = filtered[cursor].value
            selected.symmetric_difference_update({val})
            error_msg = ""
        elif key == "backspace" and query:
            query = query[:-1]
            cursor = 0
            error_msg = ""
        elif prompt.searchable and len(key) == 1 and key.isprintable():
            query += key
            cursor = 0
            error_msg = ""

        clear_lines(prev_lines)
        prev_lines = _draw()


# ---------------------------------------------------------------------------
# Confirm renderer
# ---------------------------------------------------------------------------


def _render_confirm(prompt: Prompt, fd: int) -> Any:
    value = bool(prompt.default)

    def _draw(*, final: bool = False) -> int:
        if final:
            return flush([header(Style.ACCENT, prompt.message, "Yes" if value else "No")])

        yes = styled(Style.ACCENT, f"{CHECK_ON} Yes") if value else styled(Style.MUTED, f"{CHECK_OFF} Yes")
        no = styled(Style.MUTED, f"{CHECK_OFF} No") if value else styled(Style.ACCENT, f"{CHECK_ON} No")
        return flush([
            header(Style.PRIMARY, prompt.message),
            bar(),
            f"{bar()}  {styled(Style.PRIMARY, CURSOR_CHAR)} {yes}  {no}",
            f"{bar()}  {styled(Style.MUTED, TOGGLE_HINT)}",
            styled(Style.DIM, CORNER),
        ])

    prev_lines = _draw()

    while True:
        key = read_key(fd)

        if key == "esc":
            clear_lines(prev_lines)
            return CANCEL

        if key == "enter":
            clear_lines(prev_lines)
            _draw(final=True)
            return value

        if key in ("left", "right", "space", "tab"):
            value = not value
        elif key in ("y", "Y"):
            value = True
        elif key in ("n", "N"):
            value = False

        clear_lines(prev_lines)
        prev_lines = _draw()


# ---------------------------------------------------------------------------
# Flow runner
# ---------------------------------------------------------------------------

_RENDERERS = {
    "text": _render_text,
    "multiselect": _render_multiselect,
    "confirm": _render_confirm,
}


def run(prompts: list[Prompt]) -> dict[str, Any] | None:
    """Execute a sequence of prompts and collect answers.

    Returns a ``dict`` mapping each prompt's *key* to the user's answer,
    or ``None`` if the user cancelled (Esc / Ctrl-C) at any point.
    """
    results: dict[str, Any] = {}

    try:
        with cbreak_mode() as fd:
            for p in prompts:
                renderer = _RENDERERS[p.kind]
                value = renderer(p, fd)
                if value is CANCEL:
                    return None
                results[p.key] = value
    except KeyboardInterrupt:
        sys.stdout.write(
            f"\r\n{styled(Style.ERROR, CROSS)}  "
            f"{styled(Style.STRIKETHROUGH + Style.MUTED, 'Cancelled')}\r\n"
        )
        sys.stdout.flush()
        return None

    return results
