"""tinyprompts -- Dependency-free interactive CLI prompts.

A lightweight, stdlib-only Python library for building interactive CLI prompt
flows.  Define prompts with type hints on a dataclass, run them interactively,
and hand the result to whatever CLI framework you use.

Requires a Unix TTY (macOS / Linux).  Windows is not supported.
"""

from tinyprompts.prompts import (
    CANCEL,
    Choice,
    Confirm,
    LockedSection,
    MultiSelect,
    Prompt,
    Text,
    prompt,
)
from tinyprompts.renderer import run

__version__ = "0.0.1"

__all__ = [
    "CANCEL",
    "Choice",
    "Confirm",
    "LockedSection",
    "MultiSelect",
    "Prompt",
    "Text",
    "prompt",
    "run",
]
