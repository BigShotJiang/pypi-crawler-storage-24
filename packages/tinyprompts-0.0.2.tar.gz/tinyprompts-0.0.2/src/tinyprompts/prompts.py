"""Prompt model, type-hint descriptors, and dataclass bridge.

This module defines:

- **Choice** / **Prompt** -- the core data model for prompt specifications.
- **Text**, **MultiSelect**, **Confirm** -- lightweight descriptors intended
  for use inside ``typing.Annotated`` on dataclass fields (Typer-style API).
- **prompt()** -- introspect a dataclass and run interactive prompts to fill it.
"""

from __future__ import annotations

from dataclasses import MISSING, dataclass, fields
from typing import Any, TypeVar, get_type_hints

T = TypeVar("T")

CANCEL = object()
"""Sentinel returned internally when the user presses Escape."""


# ---------------------------------------------------------------------------
# Core data model
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Choice:
    """A single option in a multi-select prompt."""

    value: Any
    label: str
    hint: str = ""


@dataclass(frozen=True)
class LockedSection:
    """A group of always-included items shown above the selectable choices."""

    title: str
    items: tuple[Choice, ...]


@dataclass(frozen=True)
class Prompt:
    """Specification for a single prompt in a flow.

    Use the static constructors :meth:`text`, :meth:`multiselect`,
    and :meth:`confirm` rather than instantiating directly.
    """

    kind: str
    key: str
    message: str
    hint: str = ""
    default: Any = None
    validate: str = ""
    choices: tuple[Choice, ...] = ()
    initial: tuple[Any, ...] = ()
    required: bool = False
    searchable: bool = False
    max_visible: int = 8
    locked_section: LockedSection | None = None

    @staticmethod
    def text(
        key: str,
        message: str,
        *,
        hint: str = "",
        validate: str = "",
        default: str = "",
    ) -> Prompt:
        return Prompt(
            kind="text", key=key, message=message,
            hint=hint, default=default, validate=validate,
        )

    @staticmethod
    def multiselect(
        key: str,
        message: str,
        choices: list[Choice],
        *,
        initial: list[Any] | None = None,
        required: bool = False,
        searchable: bool = True,
        max_visible: int = 8,
        locked_section: LockedSection | None = None,
    ) -> Prompt:
        return Prompt(
            kind="multiselect", key=key, message=message,
            choices=tuple(choices),
            initial=tuple(initial or []),
            required=required, searchable=searchable,
            max_visible=max_visible, locked_section=locked_section,
        )

    @staticmethod
    def confirm(
        key: str,
        message: str,
        *,
        default: bool = False,
    ) -> Prompt:
        return Prompt(kind="confirm", key=key, message=message, default=default)


# ---------------------------------------------------------------------------
# Annotated descriptors  (Typer-style type-hint API)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Text:
    """Descriptor for a text-input field, used inside ``Annotated[str, Text(...)]``."""

    message: str
    hint: str = ""
    validate: str = ""


@dataclass(frozen=True)
class MultiSelect:
    """Descriptor for a multi-select field, used inside ``Annotated[list, MultiSelect(...)]``."""

    message: str
    choices: list[Choice] | None = None
    required: bool = False
    searchable: bool = True
    max_visible: int = 8
    locked_section: LockedSection | None = None


@dataclass(frozen=True)
class Confirm:
    """Descriptor for a yes/no confirmation, used inside ``Annotated[bool, Confirm(...)]``."""

    message: str


# ---------------------------------------------------------------------------
# Introspection helpers
# ---------------------------------------------------------------------------

_DESCRIPTOR_TYPES = (Text, MultiSelect, Confirm)


def _extract_descriptor(annotation: Any) -> Text | MultiSelect | Confirm | None:
    """Pull the tinyprompts descriptor out of an ``Annotated[...]`` type."""
    args = getattr(annotation, "__metadata__", None)
    if args is None:
        return None
    for arg in args:
        if isinstance(arg, _DESCRIPTOR_TYPES):
            return arg
    return None


def _prompts_from_dataclass(cls: type, defaults: dict[str, Any] | None = None) -> list[Prompt]:
    """Build a list of :class:`Prompt` objects by introspecting *cls*."""
    hints = get_type_hints(cls, include_extras=True)
    dc_fields = {f.name: f for f in fields(cls)}
    prompts: list[Prompt] = []

    for name, annotation in hints.items():
        desc = _extract_descriptor(annotation)
        if desc is None:
            continue

        field = dc_fields[name]
        default_val = defaults.get(name) if defaults else None

        if default_val is None:
            if field.default is not MISSING:
                default_val = field.default

        if isinstance(desc, Text):
            prompts.append(Prompt.text(
                key=name, message=desc.message,
                hint=desc.hint, validate=desc.validate,
                default=str(default_val) if default_val is not None else "",
            ))
        elif isinstance(desc, MultiSelect):
            initial = default_val if isinstance(default_val, list) else []
            prompts.append(Prompt.multiselect(
                key=name, message=desc.message,
                choices=desc.choices or [],
                initial=initial,
                required=desc.required,
                searchable=desc.searchable,
                max_visible=desc.max_visible,
                locked_section=desc.locked_section,
            ))
        elif isinstance(desc, Confirm):
            prompts.append(Prompt.confirm(
                key=name, message=desc.message,
                default=bool(default_val) if default_val is not None else False,
            ))

    return prompts


# ---------------------------------------------------------------------------
# Public high-level API
# ---------------------------------------------------------------------------


def prompt(cls: type[T], *, defaults: dict[str, Any] | None = None) -> T | None:
    """Run interactive prompts derived from a dataclass and return a populated instance.

    Returns ``None`` if the user cancels (Esc / Ctrl-C).
    """
    from tinyprompts.renderer import run

    prompt_list = _prompts_from_dataclass(cls, defaults)
    result = run(prompt_list)
    if result is None:
        return None
    return cls(**result)


