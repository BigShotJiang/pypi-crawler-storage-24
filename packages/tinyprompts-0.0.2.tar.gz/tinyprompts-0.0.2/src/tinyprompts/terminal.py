"""Low-level terminal I/O: cbreak mode, key reading, ANSI rendering primitives.

This module owns everything that touches ``termios``, ``tty``, ``os.read``,
and raw ANSI escape sequences.  The rest of the library never writes to
stdout directly -- it goes through the helpers defined here.
"""

from __future__ import annotations

import contextlib
import os
import select
import shutil
import sys
import termios
import tty
from typing import Generator

# ---------------------------------------------------------------------------
# Unicode glyphs
# ---------------------------------------------------------------------------

CURSOR_CHAR = "\u276f"
DIAMOND = "\u25c6"
DIAMOND_DONE = "\u25c7"
CHECK_ON = "\u25cf"
CHECK_OFF = "\u25cb"
BLOCK_CHAR = "\u2588"
PIPE = "\u2502"
CORNER = "\u2514"
RULE = "\u2500"
BULLET = "\u2022"
CROSS = "\u2716"
ARROW_HINT = "\u2191\u2193 move, space select, enter confirm"
TOGGLE_HINT = "\u2190\u2192 toggle, enter confirm"


# ---------------------------------------------------------------------------
# ANSI style constants
# ---------------------------------------------------------------------------


class Style:
    """ANSI true-color escape constants."""

    PRIMARY = "\033[38;2;255;201;0m"
    ACCENT = "\033[38;2;0;255;159m"
    TEXT = "\033[1;37m"
    MUTED = "\033[38;2;128;128;128m"
    DIM = "\033[38;2;90;90;90m"
    ERROR = "\033[38;2;255;80;80m"
    RESET = "\033[0m"
    BOLD = "\033[1m"
    STRIKETHROUGH = "\033[9m"
    HIDE_CURSOR = "\033[?25l"
    SHOW_CURSOR = "\033[?25h"


def styled(style: str, text: str) -> str:
    """Wrap *text* in an ANSI style and reset."""
    return f"{style}{text}{Style.RESET}"


# ---------------------------------------------------------------------------
# Composite line builders
# ---------------------------------------------------------------------------


def header(style: str, message: str, suffix: str = "") -> str:
    tail = f"  {styled(Style.DIM, suffix)}" if suffix else ""
    return f"{styled(style, DIAMOND)}  {styled(Style.TEXT, message)}{tail}"


def bar() -> str:
    return styled(Style.DIM, PIPE)


# ---------------------------------------------------------------------------
# Terminal primitives
# ---------------------------------------------------------------------------


@contextlib.contextmanager
def cbreak_mode() -> Generator[int, None, None]:
    """Enter cbreak mode on stdin, restore on exit.

    cbreak (as opposed to raw) keeps output post-processing and signal
    handling intact -- Ctrl-C still raises ``KeyboardInterrupt`` and
    ``\\n`` still maps to ``\\r\\n`` on output.
    """
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setcbreak(fd)
        sys.stdout.write(Style.HIDE_CURSOR)
        sys.stdout.flush()
        yield fd
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)
        sys.stdout.write(Style.SHOW_CURSOR)
        sys.stdout.flush()


_ESCAPE_SEQS = {"[A": "up", "[B": "down", "[C": "right", "[D": "left"}
_CHAR_MAP = {
    "\r": "enter",
    "\n": "enter",
    " ": "space",
    "\t": "tab",
    "\x7f": "backspace",
    "\x08": "backspace",
}


def read_key(fd: int) -> str:
    """Read a single keypress and return a semantic token.

    Returns one of: ``"up"``, ``"down"``, ``"right"``, ``"left"``,
    ``"space"``, ``"enter"``, ``"esc"``, ``"backspace"``, ``"tab"``,
    or the literal character typed.
    """
    ch = os.read(fd, 1).decode("utf-8", errors="replace")
    if ch == "\x1b":
        readable, _, _ = select.select([fd], [], [], 0.05)
        if readable:
            seq = os.read(fd, 2).decode("utf-8", errors="replace")
            return _ESCAPE_SEQS.get(seq, "esc")
        return "esc"
    return _CHAR_MAP.get(ch, ch)


def clear_lines(n: int) -> None:
    """Move cursor up *n* lines and erase everything below."""
    if n > 0:
        sys.stdout.write(f"\033[{n}A\033[J")
    else:
        sys.stdout.write("\033[J")


def terminal_width() -> int:
    return shutil.get_terminal_size().columns


def flush(lines: list[str]) -> int:
    """Write *lines* to stdout and return the count (for clear tracking)."""
    sys.stdout.write("\r\n".join(lines) + "\r\n")
    sys.stdout.flush()
    return len(lines)
