# tinyprompts

A dependency-free interactive CLI prompts library for Python. Zero `pip install` dependencies -- just the stdlib.

tinyprompts does one job: collect user input interactively with a pretty TUI, then hand back a typed result. It does not replace argparse, click, or typer -- it complements them.

> **Note:** The API may change before 1.0. Requires Python 3.9+ and a Unix TTY (macOS / Linux).
## Dependency
None. Your only dependency is Python 3.9+.

## Key Features

- Interactive prompts -- Text input (with regex validation), searchable multi-select, and yes/no confirmation, rendered in-terminal with keyboard navigation.
- Type-hint-first API -- Define prompts as a dataclass with `Annotated` fields. One dataclass, fully typed output.
- Bring your own CLI -- tinyprompts returns a dataclass (or dict). Wire it into argparse, click, typer, or nothing at all.
- Tiny footprint -- 4 source files, ~500 lines total. Easy to vendor, audit, or fork.
- (Not implemented) - Defer preload. Python has a slow start problem which make it bad for CLI. Instead of fighting it, start the user interactive part first, and load the heavy things in the background.

## Quickstart

```python
from dataclasses import dataclass, field
from typing import Annotated
from tinyprompts import Text, Confirm, MultiSelect, Choice, prompt

@dataclass
class ProjectSetup:
    name: Annotated[str, Text("Project name")] = "my-project"
    tools: Annotated[list[str], MultiSelect("Pick tools", choices=[
        Choice("ruff", "Linting"),
        Choice("pytest", "Testing"),
    ])] = field(default_factory=list)
    with_example: Annotated[bool, Confirm("Include example?")] = False

config = prompt(ProjectSetup)  # interactive TUI, returns ProjectSetup or None
```

## Pairing with argparse

tinyprompts doesn't own your CLI -- you do. Build your parser normally, then pass CLI values as defaults so `prompt()` only asks for what's missing:

```python
import argparse
from tinyprompts import prompt

parser = argparse.ArgumentParser()
parser.add_argument("--name", default=None)
parser.add_argument("--tools", nargs="*", choices=["ruff", "pytest"])
args = parser.parse_args()

defaults = {k: v for k, v in vars(args).items() if v is not None}
config = prompt(ProjectSetup, defaults=defaults)
```

The same pattern works with click, typer, or any framework that produces a dict of values.

## Install

```bash
pip install tinyprompts
```

