# -*- mode: python ; coding: utf-8 -*-
"""
PyInstaller spec file for AITF (AI Translation Framework)
Build command: pyinstaller aitf.spec
"""

import os
import sys
from PyInstaller.utils.hooks import collect_all, collect_submodules

# Get the project root directory
project_root = os.path.dirname(os.path.abspath(SPEC))

block_cipher = None

# Collect all data and submodules for problematic packages
# mediapipe
try:
    mediapipe_datas, mediapipe_binaries, mediapipe_hiddenimports = collect_all('mediapipe')
except:
    mediapipe_datas, mediapipe_binaries, mediapipe_hiddenimports = [], [], []

# Define data files to bundle
# Format: (source_path, destination_path)
added_files = [
    # Resource directories
    (os.path.join(project_root, 'Resource'), 'Resource'),
    (os.path.join(project_root, 'I18N'), 'I18N'),
    (os.path.join(project_root, 'Tools'), 'Tools'),
    (os.path.join(project_root, 'PluginScripts'), 'PluginScripts'),
    (os.path.join(project_root, 'ModuleFolders'), 'ModuleFolders'),
    (os.path.join(project_root, 'StevExtraction'), 'StevExtraction'),
] + mediapipe_datas

# Hidden imports (modules that might not be detected automatically)
hiddenimports = [
    'aitf_cli',
    'ModuleFolders',
    'PluginScripts',
    'StevExtraction',
] + mediapipe_hiddenimports + [
    'tiktoken',
    'jieba',
    'spacy',
    'sudachipy',
    'sudachidict_core',
    'transformers',
    'torch',
    'tensorflow',
    'onnxruntime',
    'mediapipe',
    'cv2',
    'PIL',
    'fitz',
    'pdfminer',
    'opencc',
    'rich',
    'questionary',
    'tqdm',
    'playwright',
    'requests',
    'httpx',
    'urllib3',
    'charset_normalizer',
    'certifi',
    'idna',
    'cryptography',
    'cffi',
    'pycparser',
    '_cffi_backend',
    'numpy',
    'scipy',
    'scikit_image',
    'skimage',
    'pandas',
    'pyarrow',
    'lxml',
    'html5lib',
    'bs4',
    'beautifulsoup4',
    'python_docx',
    'python_pptx',
    'xlrd',
    'openpyxl',
    'pyexcel',
    'pyexcel_ods3',
    'pyexcel_ods',
    'ezodf',
    'pillow',
    'webcolors',
    'webdriver_manager',
    'soupsieve',
    'puremagic',
    'python_magic',
    'magic',
    'markupsafe',
    'jinja2',
    'altair',
    'vega_datasets',
    'entrypoints',
    'gitpython',
    'gitdb2',
    'smmap2',
    'packaging',
    'platformdirs',
    'pep517',
    'pep621',
    'tomli',
    'flit_core',
    'hatchling',
    'setuptools',
    'wheel',
    'pip',
    'pygments',
    'pydantic',
    'pydantic_core',
    'annotated_types',
    'typing_extensions',
    'starlette',
    'anyio',
    'sniffio',
    'idna',
    'h11',
    'click',
    'requests_toolbelt',
    'oauthlib',
    'authlib',
    'cryptography',
    'cffi',
    'pycparser',
    'pkg_resources',
]

# Exclude unnecessary modules to reduce size
excludes = [
    'tkinter',
    'matplotlib',
    'IPython',
    'jupyter',
    'notebook',
    'spyder',
    'PyQt5',
    'PyQt6',
    'PySide2',
    'PySide6',
    'wx',
]

a = Analysis(
    ['aitf_cli/__init__.py'],
    pathex=[project_root],
    binaries=[],
    datas=added_files,
    hiddenimports=hiddenimports,
    excludes=excludes,
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='aitf',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,  # Set to False for GUI mode
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='aitf',
)
