from __future__ import annotations

import time
import tracemalloc
from typing import Any


def now() -> float:
    return time.perf_counter()


def safe_repr(value: Any, max_length: int = 120) -> str:
    try:
        text = repr(value)
    except Exception:
        text = f"<unrepresentable {type(value).__name__}>"

    if len(text) > max_length:
        return text[: max_length - 3] + "..."
    return text


def start_memory_tracking() -> bool:
    was_running = tracemalloc.is_tracing()
    if not was_running:
        tracemalloc.start()
    return was_running


def stop_memory_tracking(previously_running: bool) -> None:
    if not previously_running and tracemalloc.is_tracing():
        tracemalloc.stop()


def get_peak_memory_bytes() -> int:
    _, peak = tracemalloc.get_traced_memory()
    return int(peak)


def format_bytes(num_bytes: int) -> str:
    value = float(num_bytes)
    units = ["B", "KB", "MB", "GB", "TB"]

    for unit in units:
        if value < 1024 or unit == units[-1]:
            if unit == "B":
                return f"{int(value)} {unit}"
            return f"{value:.2f} {unit}"
        value /= 1024

    return f"{num_bytes} B"
