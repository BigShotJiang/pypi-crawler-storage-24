from __future__ import annotations
import time
from .config import MetricsConfig
from .stats import CallStats, CALL_REGISTRY
from .formatters import format_call_summary, format_metrics
from .context import emit_message
from .metrics import FunctionMetrics
from .utils import (
    get_peak_memory_bytes,
    now,
    safe_repr,
    start_memory_tracking,
    stop_memory_tracking,
)


def update_stats(
    func_name: str,
    elapsed: float,
    cpu_elapsed: float,
    config: MetricsConfig,
) -> None:
    if not config.track_calls:
        return

    stats = CALL_REGISTRY.setdefault(func_name, CallStats())
    stats.update(elapsed, cpu_elapsed)


def emit_summary(
    func_name: str,
    config: MetricsConfig,
) -> None:
    if not config.track_calls:
        return

    stats = CALL_REGISTRY.get(func_name)
    if stats is None:
        return

    emit_message(format_call_summary(func_name, stats, config), config)


def run_sync(func, config: MetricsConfig, *args, **kwargs):
    if not config.enabled:
        return func(*args, **kwargs)

    started_at = now()
    cpu_started_at = time.process_time()
    previously_running = False

    if config.show_memory:
        previously_running = start_memory_tracking()

    try:
        result = func(*args, **kwargs)
    except Exception as exc:
        elapsed = now() - started_at
        cpu_elapsed = time.process_time() - cpu_started_at
        peak_memory = get_peak_memory_bytes() if config.show_memory else None

        metric = FunctionMetrics(
            function_name=func.__name__,
            elapsed_seconds=elapsed,
            cpu_seconds=cpu_elapsed,
            peak_memory_bytes=peak_memory,
            args_repr=safe_repr(args) if config.show_args else None,
            kwargs_repr=safe_repr(kwargs) if config.show_args else None,
            exception_repr=repr(exc),
        )
        update_stats(func.__name__, elapsed, cpu_elapsed, config)
        emit_message(format_metrics(metric, config), config)
        emit_summary(func.__name__, config)

        if config.show_memory:
            stop_memory_tracking(previously_running)
        raise
    else:
        elapsed = now() - started_at
        cpu_elapsed = time.process_time() - cpu_started_at
        peak_memory = get_peak_memory_bytes() if config.show_memory else None

        metric = FunctionMetrics(
            function_name=func.__name__,
            elapsed_seconds=elapsed,
            cpu_seconds=cpu_elapsed,
            peak_memory_bytes=peak_memory,
            args_repr=safe_repr(args) if config.show_args else None,
            kwargs_repr=safe_repr(kwargs) if config.show_args else None,
            result_repr=safe_repr(result) if config.show_result else None,
        )
        update_stats(func.__name__, elapsed, cpu_elapsed, config)
        emit_message(format_metrics(metric, config), config)
        emit_summary(func.__name__, config)

        if config.show_memory:
            stop_memory_tracking(previously_running)
        return result


async def run_async(func, config: MetricsConfig, *args, **kwargs):
    if not config.enabled:
        return await func(*args, **kwargs)

    started_at = now()
    cpu_started_at = time.process_time()
    previously_running = False

    if config.show_memory:
        previously_running = start_memory_tracking()

    try:
        result = await func(*args, **kwargs)
    except Exception as exc:
        elapsed = now() - started_at
        cpu_elapsed = time.process_time() - cpu_started_at
        peak_memory = get_peak_memory_bytes() if config.show_memory else None

        metric = FunctionMetrics(
            function_name=func.__name__,
            elapsed_seconds=elapsed,
            cpu_seconds=cpu_elapsed,
            peak_memory_bytes=peak_memory,
            args_repr=safe_repr(args) if config.show_args else None,
            kwargs_repr=safe_repr(kwargs) if config.show_args else None,
            exception_repr=repr(exc),
        )
        update_stats(func.__name__, elapsed, cpu_elapsed, config)
        emit_message(format_metrics(metric, config), config)
        emit_summary(func.__name__, config)

        if config.show_memory:
            stop_memory_tracking(previously_running)
        raise
    else:
        elapsed = now() - started_at
        cpu_elapsed = time.process_time() - cpu_started_at
        peak_memory = get_peak_memory_bytes() if config.show_memory else None

        metric = FunctionMetrics(
            function_name=func.__name__,
            elapsed_seconds=elapsed,
            cpu_seconds=cpu_elapsed,
            peak_memory_bytes=peak_memory,
            args_repr=safe_repr(args) if config.show_args else None,
            kwargs_repr=safe_repr(kwargs) if config.show_args else None,
            result_repr=safe_repr(result) if config.show_result else None,
        )
        update_stats(func.__name__, elapsed, cpu_elapsed, config)
        emit_message(format_metrics(metric, config), config)
        emit_summary(func.__name__, config)

        if config.show_memory:
            stop_memory_tracking(previously_running)
        return result
