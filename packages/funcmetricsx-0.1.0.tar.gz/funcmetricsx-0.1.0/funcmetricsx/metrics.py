from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class FunctionMetrics:
    function_name: str
    elapsed_seconds: float
    cpu_seconds: float | None = None
    peak_memory_bytes: int | None = None
    args_repr: str | None = None
    kwargs_repr: str | None = None
    result_repr: str | None = None
    exception_repr: str | None = None

    @property
    def succeeded(self) -> bool:
        return self.exception_repr is None
