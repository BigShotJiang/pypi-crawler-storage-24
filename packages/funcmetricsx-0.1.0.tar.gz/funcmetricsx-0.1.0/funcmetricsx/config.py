from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Callable


@dataclass(slots=True)
class MetricsConfig:
    enabled: bool = True
    show_time: bool = True
    show_cpu_time: bool = True
    show_memory: bool = True
    show_args: bool = False
    show_result: bool = False
    track_calls: bool = True
    precision: int = 4
    logger: logging.Logger | None = None
    log_level: int = logging.INFO
    output: Callable[[str], None] | None = print
    prefix: str = "[funcmetricsx]"

    def __post_init__(self) -> None:
        if self.precision < 0:
            raise ValueError("precision must be >= 0")
        if self.logger is None and self.output is None:
            raise ValueError("Either logger or output must be provided")
