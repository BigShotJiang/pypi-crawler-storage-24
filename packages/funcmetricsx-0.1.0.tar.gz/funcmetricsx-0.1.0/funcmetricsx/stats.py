from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class CallStats:
    count: int = 0
    total_elapsed: float = 0.0
    total_cpu: float = 0.0
    last_elapsed: float = 0.0
    last_cpu: float = 0.0

    def update(self, elapsed: float, cpu: float | None) -> None:
        self.count += 1
        self.total_elapsed += elapsed
        self.last_elapsed = elapsed

        if cpu is not None:
            self.total_cpu += cpu
            self.last_cpu = cpu

    @property
    def avg_elapsed(self) -> float:
        if self.count == 0:
            return 0.0
        return self.total_elapsed / self.count

    @property
    def avg_cpu(self) -> float:
        if self.count == 0:
            return 0.0
        return self.total_cpu / self.count


CALL_REGISTRY: dict[str, CallStats] = {}
