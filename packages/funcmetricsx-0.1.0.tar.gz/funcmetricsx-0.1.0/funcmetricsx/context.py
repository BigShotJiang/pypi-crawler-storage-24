from __future__ import annotations

import time
from contextlib import contextmanager
from dataclasses import dataclass

from .config import MetricsConfig
from .formatters import format_metrics
from .metrics import FunctionMetrics
from .utils import (
    get_peak_memory_bytes,
    now,
    start_memory_tracking,
    stop_memory_tracking,
)


def emit_message(message: str, config: MetricsConfig) -> None:
    if config.logger is not None:
        config.logger.log(config.log_level, message)
    elif config.output is not None:
        config.output(message)


@dataclass(slots=True)
class BlockTimer:
    name: str
    config: MetricsConfig
    started_at: float = 0.0
    cpu_started_at: float = 0.0
    previously_running: bool = False

    def __enter__(self) -> "BlockTimer":
        self.started_at = now()
        self.cpu_started_at = time.process_time()
        if self.config.show_memory:
            self.previously_running = start_memory_tracking()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        elapsed = now() - self.started_at
        cpu_elapsed = time.process_time() - self.cpu_started_at
        peak_memory = get_peak_memory_bytes() if self.config.show_memory else None

        metrics = FunctionMetrics(
            function_name=self.name,
            elapsed_seconds=elapsed,
            cpu_seconds=cpu_elapsed,
            peak_memory_bytes=peak_memory,
            exception_repr=repr(exc) if exc is not None else None,
        )

        emit_message(format_metrics(metrics, self.config), self.config)

        if self.config.show_memory:
            stop_memory_tracking(self.previously_running)


@contextmanager
def measure_block(
    name: str,
    *,
    enabled: bool = True,
    show_time: bool = True,
    show_cpu_time: bool = True,
    show_memory: bool = True,
    precision: int = 4,
    logger=None,
    log_level=None,
    output=print,
    prefix: str = "[funcmetricsx]",
):
    config = MetricsConfig(
        enabled=enabled,
        show_time=show_time,
        show_cpu_time=show_cpu_time,
        show_memory=show_memory,
        precision=precision,
        logger=logger,
        log_level=log_level if log_level is not None else 20,
        output=output,
        prefix=prefix,
    )

    if not config.enabled:
        yield
        return

    timer = BlockTimer(name=name, config=config)
    timer.__enter__()
    try:
        yield
    except Exception as exc:
        timer.__exit__(type(exc), exc, exc.__traceback__)
        raise
    else:
        timer.__exit__(None, None, None)
