from __future__ import annotations

import inspect
from functools import wraps

from .config import MetricsConfig
from .core import run_sync, run_async


def metrics(
    *,
    enabled: bool = True,
    show_time: bool = True,
    show_cpu_time: bool = True,
    show_memory: bool = True,
    show_args: bool = False,
    show_result: bool = False,
    track_calls: bool = True,
    precision: int = 4,
    logger=None,
    log_level=None,
    output=print,
    prefix: str = "[funcmetricsx]",
):
    config = MetricsConfig(
        enabled=enabled,
        show_time=show_time,
        show_cpu_time=show_cpu_time,
        show_memory=show_memory,
        show_args=show_args,
        show_result=show_result,
        track_calls=track_calls,
        precision=precision,
        logger=logger,
        log_level=log_level if log_level is not None else 20,
        output=output,
        prefix=prefix,
    )

    def decorator(func):
        if inspect.iscoroutinefunction(func):

            @wraps(func)
            async def async_wrapper(*args, **kwargs):
                return await run_async(func, config, *args, **kwargs)

            return async_wrapper

        @wraps(func)
        def sync_wrapper(*args, **kwargs):
            return run_sync(func, config, *args, **kwargs)

        return sync_wrapper

    return decorator
