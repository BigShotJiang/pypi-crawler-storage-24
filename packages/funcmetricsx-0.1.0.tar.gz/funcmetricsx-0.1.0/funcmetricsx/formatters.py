from __future__ import annotations

from .config import MetricsConfig
from .metrics import FunctionMetrics
from .utils import format_bytes
from .stats import CallStats


def format_metrics(metrics: FunctionMetrics, config: MetricsConfig) -> str:
    parts: list[str] = [config.prefix, metrics.function_name]

    details: list[str] = []

    if config.show_time:
        details.append(f"time={metrics.elapsed_seconds:.{config.precision}f}s")

    if config.show_cpu_time and metrics.cpu_seconds is not None:
        details.append(f"cpu={metrics.cpu_seconds:.{config.precision}f}s")

    if config.show_memory and metrics.peak_memory_bytes is not None:
        details.append(f"peak_memory={format_bytes(metrics.peak_memory_bytes)}")

    if metrics.exception_repr is not None:
        details.append(f"exception={metrics.exception_repr}")
    elif config.show_result and metrics.result_repr is not None:
        details.append(f"result={metrics.result_repr}")

    if config.show_args:
        if metrics.args_repr:
            details.append(f"args={metrics.args_repr}")
        if metrics.kwargs_repr:
            details.append(f"kwargs={metrics.kwargs_repr}")

    return " | ".join(parts + details)


def format_call_summary(
    function_name: str, stats: CallStats, config: MetricsConfig
) -> str:
    details = [
        f"calls={stats.count}",
        f"avg_time={stats.avg_elapsed:.{config.precision}f}s",
        f"last_time={stats.last_elapsed:.{config.precision}f}s",
    ]

    if config.show_cpu_time:
        details.append(f"avg_cpu={stats.avg_cpu:.{config.precision}f}s")
        details.append(f"last_cpu={stats.last_cpu:.{config.precision}f}s")

    return " | ".join([config.prefix, f"{function_name} summary"] + details)
