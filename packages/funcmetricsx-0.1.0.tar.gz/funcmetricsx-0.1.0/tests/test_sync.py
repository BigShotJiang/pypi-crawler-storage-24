import time

from funcmetricsx import CALL_REGISTRY, metrics


def test_sync_metrics_output():
    messages = []
    CALL_REGISTRY.clear()

    @metrics(output=messages.append, show_memory=False)
    def work():
        time.sleep(0.01)
        return 123

    result = work()

    assert result == 123
    assert len(messages) == 2
    assert "work" in messages[0]
    assert "time=" in messages[0]
    assert "summary" in messages[1]
    assert "calls=1" in messages[1]


def test_sync_metrics_with_result():
    messages = []
    CALL_REGISTRY.clear()

    @metrics(output=messages.append, show_memory=False, show_result=True)
    def add(a, b):
        return a + b

    result = add(2, 3)

    assert result == 5
    assert "result=5" in messages[0]
    assert "summary" in messages[1]


def test_sync_metrics_exception_output():
    messages = []
    CALL_REGISTRY.clear()

    @metrics(output=messages.append, show_memory=False)
    def fail():
        raise ValueError("bad")

    try:
        fail()
    except ValueError:
        pass

    assert len(messages) == 2
    assert "exception=ValueError('bad')" in messages[0]
    assert "summary" in messages[1]
    assert "calls=1" in messages[1]
