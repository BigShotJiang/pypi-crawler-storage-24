from funcmetricsx.config import MetricsConfig
from funcmetricsx.formatters import format_metrics
from funcmetricsx.metrics import FunctionMetrics


def test_format_metrics_time_only():
    config = MetricsConfig(show_memory=False, output=lambda x: None)
    metric = FunctionMetrics(function_name="demo", elapsed_seconds=0.1234)

    text = format_metrics(metric, config)

    assert "demo" in text
    assert "time=0.1234s" in text


def test_format_metrics_memory():
    config = MetricsConfig(show_memory=True, output=lambda x: None)
    metric = FunctionMetrics(
        function_name="demo",
        elapsed_seconds=0.1,
        peak_memory_bytes=1024,
    )

    text = format_metrics(metric, config)

    assert "peak_memory=" in text
