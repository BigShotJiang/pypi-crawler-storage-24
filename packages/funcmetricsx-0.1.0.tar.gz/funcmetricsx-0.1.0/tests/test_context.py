import time

from funcmetricsx import measure_block


def test_measure_block_outputs():
    messages = []

    with measure_block("load_data", output=messages.append, show_memory=False):
        time.sleep(0.01)

    assert len(messages) == 1
    assert "load_data" in messages[0]
    assert "time=" in messages[0]
