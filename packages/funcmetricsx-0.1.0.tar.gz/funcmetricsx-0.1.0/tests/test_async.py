import asyncio

from funcmetricsx import metrics, CALL_REGISTRY


def test_async_metrics_output():
    messages = []
    CALL_REGISTRY.clear()

    @metrics(output=messages.append, show_memory=False)
    async def work():
        await asyncio.sleep(0.01)
        return "ok"

    result = asyncio.run(work())

    assert result == "ok"
    assert len(messages) == 2
    assert "work" in messages[0]
    assert "time=" in messages[0]
    assert "summary" in messages[1]
    assert "calls=1" in messages[1]
