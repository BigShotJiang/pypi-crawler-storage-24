from funcmetricsx import CALL_REGISTRY, metrics


def test_cpu_time_in_output():
    messages = []

    @metrics(
        output=messages.append, show_memory=False, show_cpu_time=True, track_calls=False
    )
    def work():
        total = 0
        for i in range(10000):
            total += i
        return total

    work()

    assert len(messages) == 1
    assert "cpu=" in messages[0]


def test_call_count_summary():
    messages = []
    CALL_REGISTRY.clear()

    @metrics(output=messages.append, show_memory=False, track_calls=True)
    def add(a, b):
        return a + b

    add(1, 2)
    add(3, 4)

    summary_lines = [m for m in messages if "summary" in m]
    assert len(summary_lines) == 2
    assert "calls=1" in summary_lines[0]
    assert "calls=2" in summary_lines[1]
