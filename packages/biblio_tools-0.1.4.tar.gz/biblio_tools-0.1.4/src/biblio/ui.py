from __future__ import annotations

import importlib
import io
import json
import re
import shlex
import shutil
import socket
import struct
import subprocess
import sys
import threading
from pathlib import Path
from typing import Any
import yaml

class _JobCancelledError(Exception):
    """Raised inside a background job when the user requests cancellation."""


from .bibtex import merge_srcbib
from .ingest import IngestRecord, canonical_citekey
from .config import BiblioConfig, load_biblio_config
from .docling import run_docling_for_key
from .graph import add_openalex_work_to_bib, expand_openalex_reference_graph, load_openalex_seed_records
from .openalex.openalex_resolve import ResolveOptions, resolve_srcbib_to_openalex
from .rag import default_biblio_rag_template, default_rag_config_path, sync_biblio_rag_config
from .rag_support import load_raw_rag_config, write_raw_rag_config
from .crossref import resolve_doi_by_title
from .grobid import check_grobid_server_as_dict, derive_start_cmd, get_absent_refs, grobid_out_root, run_grobid_for_key, run_grobid_match
from .pdf_fetch_oa import fetch_pdfs_oa
from .citekeys import load_citekeys_md
from .library import load_library, notes_path, update_entry
from .collections import (
    load_collections, create_collection, rename_collection, move_collection,
    delete_collection, add_papers as col_add_papers, remove_papers as col_remove_papers,
)
from .site import build_biblio_site
from .site import BiblioSiteOptions, _build_site_model, default_site_out_dir


def _try_import_indexio():
    try:
        import indexio  # noqa: PLC0415
        return indexio
    except ImportError:
        return None


_indexio_mod = _try_import_indexio()


def _rag_build_indexio(repo_root: Path) -> dict[str, Any]:
    """Build RAG index in-process using indexio. Auto-creates rag.yaml if needed."""
    sync_biblio_rag_config(repo_root)
    rag_cfg_path = default_rag_config_path(repo_root)
    result = _indexio_mod.build_index(
        config_path=rag_cfg_path,
        root=repo_root,
        sources_filter=["biblio_docling"],
    )
    source_stats = result.get("source_stats") or {}
    total_files = sum(s.get("files", 0) for s in source_stats.values())
    total_chunks = sum(s.get("chunks", 0) for s in source_stats.values())
    return {
        "ok": True,
        "indexed": total_files,
        "chunks": total_chunks,
        "collection": result.get("store"),
        "persist_dir": result.get("persist_directory"),
    }


def _rag_search_indexio(repo_root: Path, query: str, n_results: int) -> dict[str, Any]:
    """Search RAG index in-process using indexio."""
    rag_cfg_path = default_rag_config_path(repo_root)
    if not rag_cfg_path.exists():
        return {"ok": False, "error": "RAG config not found. Run 'Build RAG Index' first.", "results": []}
    try:
        data = _indexio_mod.query_index(
            config_path=rag_cfg_path,
            root=repo_root,
            query=query,
            k=n_results,
            corpus="bib",
        )
    except FileNotFoundError:
        return {"ok": False, "error": "RAG index not built yet. Run 'Build RAG Index' first.", "results": []}
    results = []
    for item in data.get("results") or []:
        source_path = item.get("source_path") or ""
        citekey = Path(source_path).stem if source_path else ""
        results.append({
            "id": f"{source_path}::{item.get('chunk_index', 0)}",
            "citekey": citekey,
            "chunk_index": item.get("chunk_index", 0),
            "text": item.get("snippet", ""),
            "distance": None,
        })
    return {"ok": True, "query": query, "results": results}


def _require_fastapi():
    try:
        fastapi = importlib.import_module("fastapi")
    except Exception as e:  # pragma: no cover
        raise RuntimeError(
            'UI features require `fastapi` and `uvicorn` (install with `pip install "biblio-tools[ui]"`).'
        ) from e
    responses = importlib.import_module("fastapi.responses")
    return fastapi, responses


def _require_uvicorn():
    try:
        return importlib.import_module("uvicorn")
    except Exception as e:  # pragma: no cover
        raise RuntimeError(
            'UI features require `uvicorn` (install with `pip install "biblio-tools[ui]"`).'
        ) from e


def find_available_port(host: str, start_port: int, *, max_tries: int = 25) -> int:
    for port in range(int(start_port), int(start_port) + int(max_tries)):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                sock.bind((host, port))
            except OSError:
                continue
            return port
    raise OSError(f"No available port found starting at {start_port} on host {host}")


def build_ui_model(cfg: BiblioConfig) -> dict[str, Any]:
    model = _build_site_model(
        cfg,
        BiblioSiteOptions(
            out_dir=default_site_out_dir(root=cfg.repo_root),
            include_graphs=True,
            include_docling=True,
            include_openalex=True,
        ),
    )
    papers = model["papers"]
    graph = model["graph"]
    paper_lookup = {paper["citekey"]: paper for paper in papers}
    return {
        "repo_root": str(cfg.repo_root),
        "papers": papers,
        "graph": graph,
        "status": model["status"],
        "paper_lookup": paper_lookup,
    }


def build_setup_report(cfg: BiblioConfig) -> dict[str, Any]:
    """Fast config-only report — no subprocess, no site model build."""
    cmd = list(cfg.docling_cmd)
    exe = cmd[0] if cmd else "docling"
    resolved = shutil.which(exe) if exe and "/" not in exe else (exe if exe else None)
    rag_path = default_rag_config_path(cfg.repo_root)
    rag_payload = _load_rag_mapping(cfg.repo_root)
    rag_sources = rag_payload.get("sources") or []
    if not isinstance(rag_sources, list):
        rag_sources = []
    stores = rag_payload.get("stores") or {}
    if not isinstance(stores, dict):
        stores = {}
    local_store = stores.get("local") if isinstance(stores.get("local"), dict) else {}
    return {
        "repo_root": str(cfg.repo_root),
        "config_path": str((cfg.repo_root / "bib" / "config" / "biblio.yml").resolve()),
        "docling": {
            "ok": None,
            "command": cmd,
            "resolved_executable": resolved,
            "message": "Click Re-check to verify." if resolved else f"Configured executable not found on PATH: {exe!r}",
            "returncode": None,
        },
        "docling_command_text": " ".join(cmd),
        "suggested_uv_command": str((cfg.repo_root / ".biblio" / "uv" / "docling" / "bin" / "docling").resolve()),
        "rag": {
            "config_path": str(rag_path),
            "exists": rag_path.exists(),
            "embedding_model": str(rag_payload.get("embedding_model") or ""),
            "chunk_size_chars": int(rag_payload.get("chunk_size_chars") or 1000),
            "chunk_overlap_chars": int(rag_payload.get("chunk_overlap_chars") or 200),
            "default_store": str(rag_payload.get("default_store") or "local"),
            "local_persist_directory": str(local_store.get("persist_directory") or ".cache/rag/chroma_db"),
            "source_ids": [
                str(item.get("id"))
                for item in rag_sources
                if isinstance(item, dict) and isinstance(item.get("id"), str)
            ],
            "follow_up_build_cmd": "rag build --config bib/config/rag.yaml --sources biblio_docling",
            "backend": "indexio" if _indexio_mod is not None else "vector_store",
        },
        "paths": {
            "citekeys": str(cfg.citekeys_path),
            "pdf_root": str(cfg.pdf_root),
            "out_root": str(cfg.out_root),
            "srcbib": str(cfg.bibtex_merge.src_dir),
            "openalex_out": str(cfg.openalex.out_jsonl),
        },
        "grobid": {
            "url": cfg.grobid.url,
            "installation_path": str(cfg.grobid.installation_path) if cfg.grobid.installation_path else None,
            "timeout_seconds": cfg.grobid.timeout_seconds,
            "consolidate_header": cfg.grobid.consolidate_header,
            "consolidate_citations": cfg.grobid.consolidate_citations,
            "derived_start_cmd": derive_start_cmd(cfg.grobid),
            "ok": None,
            "message": "Click Check to verify.",
            "latency_ms": None,
        },
    }


def check_docling_command(cfg: BiblioConfig) -> dict[str, Any]:
    """Run the configured Docling command with --help and return the result."""
    cmd = list(cfg.docling_cmd)
    exe = cmd[0] if cmd else "docling"
    resolved = shutil.which(exe) if exe and "/" not in exe else (exe if exe else None)
    result: dict[str, Any] = {
        "ok": False,
        "command": cmd,
        "resolved_executable": resolved,
        "message": "",
        "returncode": None,
    }
    if resolved is None:
        result["message"] = f"Configured executable not found on PATH: {exe!r}"
        return result
    try:
        proc = subprocess.run(
            [*cmd, "--help"],
            capture_output=True,
            text=True,
            timeout=20,
            check=False,
        )
        result["returncode"] = int(proc.returncode)
        result["ok"] = proc.returncode == 0
        out = (proc.stdout or "").strip()
        err = (proc.stderr or "").strip()
        if proc.returncode == 0:
            result["message"] = "Docling command responded to --help."
        else:
            detail = err or out or f"exit code {proc.returncode}"
            result["message"] = f"Docling command failed: {detail}"
    except Exception as e:
        result["message"] = f"Docling check failed: {e}"
    return result


def _config_path(repo_root: Path) -> Path:
    return (repo_root / "bib" / "config" / "biblio.yml").resolve()


def _load_config_mapping(repo_root: Path) -> dict[str, Any]:
    path = _config_path(repo_root)
    if not path.exists():
        return {}
    payload = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    if not isinstance(payload, dict):
        raise TypeError(f"Expected mapping in {path}, got {type(payload).__name__}")
    return payload


def _write_config_mapping(repo_root: Path, payload: dict[str, Any]) -> Path:
    path = _config_path(repo_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")
    return path


def _load_rag_mapping(repo_root: Path) -> dict[str, Any]:
    path = default_rag_config_path(repo_root)
    if path.exists():
        return load_raw_rag_config(path)
    payload = yaml.safe_load(default_biblio_rag_template()) or {}
    if not isinstance(payload, dict):
        raise TypeError("Expected mapping in default RAG template.")
    return payload


def _write_rag_mapping(repo_root: Path, payload: dict[str, Any]) -> Path:
    return write_raw_rag_config(default_rag_config_path(repo_root), payload)


def _update_grobid_config(repo_root: Path, updates: dict[str, Any]) -> Path:
    payload = _load_config_mapping(repo_root)
    grobid = payload.get("grobid")
    if not isinstance(grobid, dict):
        grobid = {}
        payload["grobid"] = grobid
    for key in ("url", "installation_path", "timeout_seconds", "consolidate_header", "consolidate_citations"):
        if key in updates and updates[key] is not None:
            grobid[key] = updates[key]
    return _write_config_mapping(repo_root, payload)


def _update_docling_command(repo_root: Path, cmd_value: str | list[str]) -> Path:
    payload = _load_config_mapping(repo_root)
    docling = payload.get("docling")
    if not isinstance(docling, dict):
        docling = {}
        payload["docling"] = docling
    docling["cmd"] = cmd_value
    return _write_config_mapping(repo_root, payload)


def _install_docling_uv(repo_root: Path) -> dict[str, Any]:
    uv = shutil.which("uv")
    if uv is None:
        raise FileNotFoundError("`uv` was not found on PATH.")
    env_dir = (repo_root / ".biblio" / "uv" / "docling").resolve()
    python_path = env_dir / "bin" / "python"
    docling_bin = env_dir / "bin" / "docling"
    env_dir.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run([uv, "venv", str(env_dir)], check=True, capture_output=True, text=True)
    subprocess.run([uv, "pip", "install", "--python", str(python_path), "docling"], check=True, capture_output=True, text=True)
    _update_docling_command(repo_root, [str(docling_bin)])
    return {
        "env_dir": str(env_dir),
        "python": str(python_path),
        "docling": str(docling_bin),
    }


def _static_dir() -> Path:
    return Path(__file__).parent / "static"


def _serve_index() -> str:
    html_path = _static_dir() / "index.html"
    if not html_path.exists():
        raise RuntimeError(
            f"UI static files not found at {html_path}. "
            "Run `make build-frontend` to build the frontend."
        )
    return html_path.read_text(encoding="utf-8")


def create_ui_app(cfg: BiblioConfig):
    fastapi, responses = _require_fastapi()
    static_files_mod = importlib.import_module("fastapi.staticfiles")
    app = fastapi.FastAPI(title="biblio ui", version="0.1")
    app.mount("/static", static_files_mod.StaticFiles(directory=str(_static_dir())), name="static")
    cfg_state: dict[str, BiblioConfig] = {"cfg": cfg}

    def current_cfg() -> BiblioConfig:
        return cfg_state["cfg"]

    def reload_cfg() -> BiblioConfig:
        updated = load_biblio_config(_config_path(cfg.repo_root), root=cfg.repo_root)
        cfg_state["cfg"] = updated
        return updated

    @app.get("/", response_class=responses.HTMLResponse)
    def index() -> str:
        return _serve_index()

    @app.get("/api/model", response_class=responses.JSONResponse)
    def model():
        payload = build_ui_model(current_cfg())
        payload.pop("paper_lookup", None)
        return payload

    @app.get("/api/papers", response_class=responses.JSONResponse)
    def papers():
        payload = build_ui_model(current_cfg())
        return payload["papers"]

    @app.get("/api/status", response_class=responses.JSONResponse)
    def status():
        payload = build_ui_model(current_cfg())
        return payload["status"]

    @app.get("/api/graph", response_class=responses.JSONResponse)
    def graph():
        payload = build_ui_model(current_cfg())
        return payload["graph"]

    @app.get("/api/graph-candidates", response_class=responses.JSONResponse)
    def graph_candidates():
        active_cfg = current_cfg()
        candidates_path = active_cfg.openalex.out_jsonl.parent / "graph_candidates.json"
        if not candidates_path.exists():
            return []
        return json.loads(candidates_path.read_text(encoding="utf-8"))

    @app.get("/api/files/pdf/{citekey}")
    def file_pdf(citekey: str):
        active_cfg = current_cfg()
        paper_path = active_cfg.pdf_root / Path(active_cfg.pdf_pattern.format(citekey=citekey))
        pdf_path = paper_path.resolve()
        if not pdf_path.exists() or not pdf_path.is_file():
            raise fastapi.HTTPException(status_code=404, detail=f"PDF not found for {citekey}")
        headers = {"Content-Disposition": f'inline; filename="{pdf_path.name}"'}
        return responses.FileResponse(str(pdf_path), media_type="application/pdf", headers=headers)

    @app.get("/api/files/docling/{citekey}/{path:path}")
    def file_docling_artifact(citekey: str, path: str):
        """Serve a file from the docling output directory for a citekey.

        Used to resolve relative image paths in rendered docling markdown, e.g.
        peyrache_2011_..._artifacts/image_000000_....png
        """
        active_cfg = current_cfg()
        # Resolve and jail to the docling output root to prevent path traversal
        out_root = active_cfg.out_root.resolve()
        artifact_path = (out_root / citekey / path).resolve()
        if not str(artifact_path).startswith(str(out_root)):
            raise fastapi.HTTPException(status_code=403, detail="Path traversal denied")
        if not artifact_path.exists() or not artifact_path.is_file():
            raise fastapi.HTTPException(status_code=404, detail=f"Artifact not found: {path}")
        return responses.FileResponse(str(artifact_path))

    @app.get("/api/setup", response_class=responses.JSONResponse)
    def setup():
        return build_setup_report(current_cfg())

    @app.post("/api/setup/rag-sync", response_class=responses.JSONResponse)
    def setup_rag_sync(payload: dict[str, Any]):
        active_cfg = current_cfg()
        force_init = bool(payload.get("force_init"))
        result = sync_biblio_rag_config(active_cfg.repo_root, force_init=force_init)
        return _action_result(
            f"Synchronized bibliography-owned RAG sources in {result.config_path}.",
            config_path=str(result.config_path),
            created=result.created,
            initialized=result.initialized,
            added=list(result.added),
            updated=list(result.updated),
            removed=list(result.removed),
            follow_up_cmd=result.follow_up_cmd,
        )

    @app.post("/api/setup/rag-config", response_class=responses.JSONResponse)
    def setup_rag_config(payload: dict[str, Any]):
        active_cfg = current_cfg()
        current = _load_rag_mapping(active_cfg.repo_root)
        current["embedding_model"] = str(payload.get("embedding_model") or current.get("embedding_model") or "")
        current["chunk_size_chars"] = int(payload.get("chunk_size_chars") or current.get("chunk_size_chars") or 1000)
        current["chunk_overlap_chars"] = int(payload.get("chunk_overlap_chars") or current.get("chunk_overlap_chars") or 200)
        current["default_store"] = str(payload.get("default_store") or current.get("default_store") or "local")
        stores = current.get("stores")
        if not isinstance(stores, dict):
            stores = {}
            current["stores"] = stores
        local_store = stores.get("local")
        if not isinstance(local_store, dict):
            local_store = {}
            stores["local"] = local_store
        local_store["persist_directory"] = str(
            payload.get("local_persist_directory") or local_store.get("persist_directory") or ".cache/rag/chroma_db"
        )
        if "read_only" not in local_store:
            local_store["read_only"] = False
        _write_rag_mapping(active_cfg.repo_root, current)
        return _action_result(
            "Saved bibliography-owned RAG config.",
            config_path=str(default_rag_config_path(active_cfg.repo_root)),
        )

    def _action_result(message: str, **extra: Any) -> dict[str, Any]:
        return {"ok": True, "message": message, **extra}

    openalex_job: dict[str, Any] = {
        "running": False,
        "completed": 0,
        "total": 0,
        "citekey": None,
        "message": "",
        "error": None,
        "counts": None,
    }
    graph_job: dict[str, Any] = {
        "running": False,
        "completed": 0,
        "total": 0,
        "seed_openalex_id": None,
        "message": "",
        "error": None,
        "candidates": 0,
        "cancelled": False,
    }
    docling_job: dict[str, Any] = {
        "running": False,
        "message": "",
        "error": None,
        "citekey": None,
        "md_path": None,
        "logs": "",
    }
    grobid_job: dict[str, Any] = {
        "running": False,
        "message": "",
        "error": None,
        "citekey": None,
        "completed": 0,
        "total": 0,
        "references_path": None,
        "logs": "",
        "cancelled": False,
    }
    openalex_lock = threading.Lock()
    graph_lock = threading.Lock()
    docling_lock = threading.Lock()
    grobid_lock = threading.Lock()

    def _openalex_snapshot() -> dict[str, Any]:
        with openalex_lock:
            return dict(openalex_job)

    def _graph_snapshot() -> dict[str, Any]:
        with graph_lock:
            return dict(graph_job)

    def _docling_snapshot() -> dict[str, Any]:
        with docling_lock:
            return dict(docling_job)

    def _grobid_snapshot() -> dict[str, Any]:
        with grobid_lock:
            return dict(grobid_job)

    @app.post("/api/actions/bibtex-merge", response_class=responses.JSONResponse)
    def action_bibtex_merge():
        active_cfg = current_cfg()
        n_sources, n_entries = merge_srcbib(active_cfg.bibtex_merge, dry_run=False)
        return _action_result(
            f"Merged {n_sources} source files into {n_entries} entries.",
            sources=n_sources,
            entries=n_entries,
        )

    @app.post("/api/actions/docling-run", response_class=responses.JSONResponse)
    def action_docling_run(payload: dict[str, Any]):
        active_cfg = current_cfg()
        citekey = str(payload.get("citekey") or "").strip()
        if not citekey:
            raise fastapi.HTTPException(status_code=400, detail="Missing citekey")
        with docling_lock:
            if docling_job["running"]:
                return {"ok": True, "async": True, **dict(docling_job)}
            docling_job.update(
                {
                    "running": True,
                    "message": f"Running Docling for {citekey}...",
                    "error": None,
                    "citekey": citekey,
                    "md_path": None,
                    "completed": 0,
                    "total": 1,
                }
            )

        def _run_docling() -> None:
            try:
                out = run_docling_for_key(active_cfg, citekey, force=False)
                with docling_lock:
                    docling_job["running"] = False
                    docling_job["message"] = f"Docling finished for {citekey}."
                    docling_job["error"] = None
                    docling_job["md_path"] = str(out.md_path)
                    docling_job["completed"] = 1
                    docling_job["total"] = 1
                    docling_job["logs"] = ""
            except subprocess.CalledProcessError as e:
                cmd = " ".join(str(part) for part in e.cmd) if isinstance(e.cmd, (list, tuple)) else str(e.cmd)
                logs = "\n".join(filter(None, [e.stdout, e.stderr])).strip()
                with docling_lock:
                    docling_job["running"] = False
                    docling_job["error"] = f"Docling command failed with exit code {e.returncode}: {cmd}"
                    docling_job["message"] = docling_job["error"]
                    docling_job["logs"] = logs
            except Exception as e:
                with docling_lock:
                    docling_job["running"] = False
                    docling_job["error"] = str(e)
                    docling_job["message"] = f"Docling failed: {e}"
                    docling_job["logs"] = ""

        threading.Thread(target=_run_docling, daemon=True).start()
        return {"ok": True, "async": True, **_docling_snapshot()}

    @app.get("/api/actions/docling-run/status", response_class=responses.JSONResponse)
    def action_docling_run_status():
        return _docling_snapshot()

    @app.post("/api/actions/docling-run/cancel", response_class=responses.JSONResponse)
    def action_docling_run_cancel():
        with docling_lock:
            if docling_job["running"]:
                docling_job["running"] = False
                docling_job["error"] = None
                docling_job["message"] = "Docling cancelled."
        return _docling_snapshot()

    @app.post("/api/actions/openalex-resolve", response_class=responses.JSONResponse)
    def action_openalex_resolve():
        with openalex_lock:
            if openalex_job["running"]:
                return {
                    "ok": True,
                    "async": True,
                    "message": openalex_job["message"] or "OpenAlex resolve already running.",
                    **dict(openalex_job),
                }
            openalex_job.update(
                {
                    "running": True,
                    "completed": 0,
                    "total": 0,
                    "citekey": None,
                    "message": "Starting OpenAlex resolve...",
                    "error": None,
                    "counts": None,
                }
            )

        def _progress(payload: dict[str, Any]) -> None:
            with openalex_lock:
                openalex_job["completed"] = int(payload.get("completed") or 0)
                openalex_job["total"] = int(payload.get("total") or 0)
                openalex_job["citekey"] = payload.get("citekey")
                completed = openalex_job["completed"]
                total = openalex_job["total"]
                citekey = openalex_job["citekey"]
                base = f"Resolving OpenAlex metadata {completed}/{total}" if total else "Resolving OpenAlex metadata..."
                openalex_job["message"] = f"{base}" + (f" ({citekey})" if citekey else "")

        def _run_job() -> None:
            active_cfg = current_cfg()
            try:
                counts = resolve_srcbib_to_openalex(
                    cfg=active_cfg.openalex_client,
                    cache=active_cfg.openalex_cache,
                    src_dir=active_cfg.openalex.src_dir,
                    src_glob=active_cfg.openalex.src_glob,
                    out_path=active_cfg.openalex.out_jsonl,
                    out_format="jsonl",
                    limit=None,
                    opts=ResolveOptions(
                        prefer_doi=True,
                        fallback_title_search=True,
                        per_page=int(active_cfg.openalex_client.per_page),
                        strict=False,
                        force=False,
                    ),
                    progress_cb=_progress,
                )
                with openalex_lock:
                    openalex_job["running"] = False
                    openalex_job["counts"] = counts
                    openalex_job["completed"] = counts["total"]
                    openalex_job["total"] = counts["total"]
                    openalex_job["citekey"] = None
                    openalex_job["message"] = f"Resolved OpenAlex metadata for {counts['resolved']} entries."
                    openalex_job["error"] = None
            except Exception as e:
                with openalex_lock:
                    openalex_job["running"] = False
                    openalex_job["error"] = str(e)
                    openalex_job["message"] = f"OpenAlex resolve failed: {e}"

        threading.Thread(target=_run_job, daemon=True).start()
        return {"ok": True, "async": True, **_openalex_snapshot()}

    @app.get("/api/actions/openalex-resolve/status", response_class=responses.JSONResponse)
    def action_openalex_resolve_status():
        return _openalex_snapshot()

    @app.post("/api/actions/openalex-resolve/cancel", response_class=responses.JSONResponse)
    def action_openalex_resolve_cancel():
        with openalex_lock:
            if openalex_job["running"]:
                openalex_job["running"] = False
                openalex_job["error"] = None
                openalex_job["message"] = "OpenAlex resolve cancelled."
        return _openalex_snapshot()

    @app.post("/api/actions/graph-expand", response_class=responses.JSONResponse)
    def action_graph_expand(payload: dict[str, Any] = {}):
        active_cfg = current_cfg()
        citekey_filter = str(payload.get("citekey") or "").strip() or None
        merge = bool(payload.get("merge", True))
        with graph_lock:
            if graph_job["running"]:
                return {"ok": True, "async": True, **dict(graph_job)}
            graph_job.update(
                {
                    "running": True,
                    "completed": 0,
                    "total": 0,
                    "seed_openalex_id": None,
                    "message": f"Starting graph expansion{f' for {citekey_filter}' if citekey_filter else ''}...",
                    "error": None,
                    "candidates": 0,
                }
            )

        input_path = active_cfg.openalex.out_jsonl
        output_path = active_cfg.openalex.out_jsonl.parent / "graph_candidates.json"
        # Always load full records so all_seed_ids covers the whole corpus
        all_records = load_openalex_seed_records(input_path)

        def _progress(p: dict[str, Any]) -> None:
            with graph_lock:
                if graph_job.get("cancelled"):
                    raise _JobCancelledError("Graph expansion cancelled by user")
                graph_job["completed"] = int(p.get("completed") or 0)
                graph_job["total"] = int(p.get("total") or 0)
                graph_job["seed_openalex_id"] = p.get("seed_openalex_id")
                graph_job["candidates"] = int(p.get("candidates") or 0)
                base = f"Expanding graph {graph_job['completed']}/{graph_job['total']}" if graph_job["total"] else "Expanding graph..."
                seed = graph_job["seed_openalex_id"]
                graph_job["message"] = f"{base}" + (f" ({seed})" if seed else "")

        def _run_graph() -> None:
            try:
                result = expand_openalex_reference_graph(
                    cfg=active_cfg.openalex_client,
                    cache=active_cfg.openalex_cache,
                    records=all_records,
                    out_path=output_path,
                    direction="both",
                    force=False,
                    merge=merge,
                    seed_citekeys=[citekey_filter] if citekey_filter else None,
                    progress_cb=_progress,
                )
                with graph_lock:
                    graph_job["running"] = False
                    graph_job["cancelled"] = False
                    graph_job["completed"] = result.total_inputs
                    graph_job["total"] = result.total_inputs
                    graph_job["seed_openalex_id"] = None
                    graph_job["candidates"] = result.candidates
                    graph_job["message"] = (
                        f"Graph expanded: {result.candidates} total candidates"
                        + (f" (added for {citekey_filter})" if citekey_filter else "") + "."
                    )
                    graph_job["error"] = None
            except _JobCancelledError:
                with graph_lock:
                    graph_job["running"] = False
                    graph_job["cancelled"] = False
                    graph_job["error"] = None
                    graph_job["message"] = "Graph expansion cancelled."
            except Exception as e:
                with graph_lock:
                    graph_job["running"] = False
                    graph_job["cancelled"] = False
                    graph_job["error"] = str(e)
                    graph_job["message"] = f"Graph expansion failed: {e}"

        threading.Thread(target=_run_graph, daemon=True).start()
        return {"ok": True, "async": True, **_graph_snapshot()}

    @app.get("/api/actions/graph-expand/status", response_class=responses.JSONResponse)
    def action_graph_expand_status():
        return _graph_snapshot()

    @app.post("/api/actions/graph-expand/cancel", response_class=responses.JSONResponse)
    def action_graph_expand_cancel():
        with graph_lock:
            if graph_job["running"]:
                graph_job["cancelled"] = True
                graph_job["message"] = "Cancelling graph expansion..."
        return _graph_snapshot()

    @app.post("/api/actions/grobid-run", response_class=responses.JSONResponse)
    def action_grobid_run(payload: dict[str, Any]):
        active_cfg = current_cfg()
        run_all = bool(payload.get("all"))
        citekey = str(payload.get("citekey") or "").strip()
        force = bool(payload.get("force"))

        if not run_all and not citekey:
            raise fastapi.HTTPException(status_code=400, detail="Missing citekey or all=true")

        with grobid_lock:
            if grobid_job["running"]:
                return {"ok": True, "async": True, **dict(grobid_job)}
            if run_all:
                keys = load_citekeys_md(active_cfg.citekeys_path) if active_cfg.citekeys_path.exists() else []
                keys = [k for k in keys if (active_cfg.pdf_root / active_cfg.pdf_pattern.format(citekey=k)).exists()]
                total = len(keys)
                msg = f"Running GROBID for all {total} papers with PDFs..."
            else:
                keys = [citekey]
                total = 1
                msg = f"Running GROBID for {citekey}..."
            grobid_job.update({
                "running": True,
                "message": msg,
                "error": None,
                "citekey": citekey if not run_all else None,
                "references_path": None,
                "completed": 0,
                "total": total,
                "cancelled": False,
            })

        def _run_grobid() -> None:
            failures = 0
            cancelled = False
            for idx, ck in enumerate(keys, start=1):
                with grobid_lock:
                    if grobid_job.get("cancelled"):
                        cancelled = True
                        break
                try:
                    out = run_grobid_for_key(active_cfg, ck, force=force)
                    with grobid_lock:
                        grobid_job["completed"] = idx
                        grobid_job["citekey"] = ck
                        grobid_job["references_path"] = str(out.references_path)
                        grobid_job["message"] = f"GROBID {idx}/{total}: {ck}"
                except Exception as e:
                    failures += 1
                    with grobid_lock:
                        grobid_job["completed"] = idx
                        grobid_job["citekey"] = ck
                        grobid_job["message"] = f"GROBID {idx}/{total}: {ck} failed: {e}"
            with grobid_lock:
                grobid_job["running"] = False
                grobid_job["cancelled"] = False
                if cancelled:
                    grobid_job["error"] = None
                    grobid_job["message"] = f"GROBID cancelled after {grobid_job['completed']}/{total} papers."
                elif failures == 0:
                    grobid_job["error"] = None
                    grobid_job["message"] = f"GROBID finished ({total} papers, {failures} failures)."
                else:
                    grobid_job["error"] = f"{failures} papers failed."
                    grobid_job["message"] = f"GROBID done with {failures} failures out of {total}."

        threading.Thread(target=_run_grobid, daemon=True).start()
        return {"ok": True, "async": True, **_grobid_snapshot()}

    @app.get("/api/actions/grobid-run/status", response_class=responses.JSONResponse)
    def action_grobid_run_status():
        return _grobid_snapshot()

    @app.post("/api/actions/grobid-run/cancel", response_class=responses.JSONResponse)
    def action_grobid_run_cancel():
        with grobid_lock:
            if grobid_job["running"]:
                grobid_job["cancelled"] = True
                grobid_job["message"] = "Cancelling GROBID..."
        return _grobid_snapshot()

    grobid_match_job: dict[str, Any] = {"running": False, "message": "", "error": None, "matched": 0, "links": 0}
    grobid_match_lock = threading.Lock()

    def _grobid_match_snapshot() -> dict[str, Any]:
        with grobid_match_lock:
            return dict(grobid_match_job)

    @app.post("/api/actions/grobid-match", response_class=responses.JSONResponse)
    def action_grobid_match():
        active_cfg = current_cfg()
        with grobid_match_lock:
            if grobid_match_job["running"]:
                return {"ok": True, "async": True, **dict(grobid_match_job)}
            grobid_match_job.update({"running": True, "message": "Matching GROBID references...", "error": None})

        def _run_match() -> None:
            try:
                _, matches = run_grobid_match(active_cfg)
                total_links = sum(len(v) for v in matches.values())
                with grobid_match_lock:
                    grobid_match_job["running"] = False
                    grobid_match_job["error"] = None
                    grobid_match_job["matched"] = len(matches)
                    grobid_match_job["links"] = total_links
                    grobid_match_job["message"] = (
                        f"Matched {len(matches)} papers with {total_links} local reference links."
                    )
            except Exception as e:
                with grobid_match_lock:
                    grobid_match_job["running"] = False
                    grobid_match_job["error"] = str(e)
                    grobid_match_job["message"] = f"GROBID match failed: {e}"

        threading.Thread(target=_run_match, daemon=True).start()
        return {"ok": True, "async": True, **_grobid_match_snapshot()}

    @app.get("/api/actions/grobid-match/status", response_class=responses.JSONResponse)
    def action_grobid_match_status():
        return _grobid_match_snapshot()

    @app.post("/api/actions/site-build", response_class=responses.JSONResponse)
    def action_site_build():
        result = build_biblio_site(current_cfg(), force=True)
        return _action_result(
            f"Built site with {result.papers_total} papers.",
            out_dir=str(result.out_dir),
            papers=result.papers_total,
        )

    @app.post("/api/actions/add-papers-bulk", response_class=responses.JSONResponse)
    def action_add_papers_bulk(payload: dict[str, Any]):
        active_cfg = current_cfg()
        dois: list[str] = [str(d).strip() for d in (payload.get("dois") or []) if str(d).strip()]
        if not dois:
            raise fastapi.HTTPException(status_code=400, detail="Missing dois list")
        added, failed = [], []
        for doi in dois:
            try:
                result = add_openalex_work_to_bib(
                    cfg=active_cfg.openalex_client,
                    cache=active_cfg.openalex_cache,
                    repo_root=active_cfg.repo_root,
                    doi=doi,
                )
                added.append(result.citekey)
            except Exception as e:
                failed.append({"doi": doi, "error": str(e)})
        return _action_result(
            f"Bulk add: {len(added)} added, {len(failed)} failed.",
            added=added,
            failed=failed,
        )

    @app.post("/api/actions/add-paper", response_class=responses.JSONResponse)
    def action_add_paper(payload: dict[str, Any]):
        active_cfg = current_cfg()
        doi = str(payload.get("doi") or "").strip() or None
        openalex_id = str(payload.get("openalex_id") or "").strip() or None
        if not doi and not openalex_id:
            raise fastapi.HTTPException(status_code=400, detail="Missing doi or openalex_id")
        result = add_openalex_work_to_bib(
            cfg=active_cfg.openalex_client,
            cache=active_cfg.openalex_cache,
            repo_root=active_cfg.repo_root,
            doi=doi,
            openalex_id=openalex_id,
        )
        return _action_result(
            f"Added paper as {result.citekey}.",
            citekey=result.citekey,
            openalex_id=result.openalex_id,
            doi=result.doi,
        )

    # ── drop paper from library (remove from citekeys.md) ────────────────────

    @app.delete("/api/papers/{citekey}", response_class=responses.JSONResponse)
    def drop_paper(citekey: str):
        from .citekeys import load_citekeys_md, remove_citekeys_md
        cfg = current_cfg()
        if not cfg.citekeys_path or not Path(cfg.citekeys_path).exists():
            raise fastapi.HTTPException(status_code=404, detail="citekeys.md not found")
        before = load_citekeys_md(cfg.citekeys_path)
        if citekey not in before:
            raise fastapi.HTTPException(status_code=404, detail=f"{citekey} not in citekeys.md")
        remove_citekeys_md(cfg.citekeys_path, [citekey])
        return {"ok": True, "removed": citekey}

    # ── refresh paper metadata from OpenAlex by DOI ───────────────────────────

    @app.post("/api/papers/{citekey}/refresh-metadata", response_class=responses.JSONResponse)
    def refresh_paper_metadata(citekey: str):
        """Re-fetch OpenAlex metadata for a single paper via its DOI."""
        cfg = current_cfg()
        # Find the paper's DOI from the resolved.jsonl or BibTeX
        doi = None
        if cfg.openalex.out_jsonl.exists():
            for line in cfg.openalex.out_jsonl.read_text(encoding="utf-8").splitlines():
                try:
                    row = json.loads(line)
                    if row.get("citekey") == citekey and row.get("doi"):
                        doi = row["doi"]
                        break
                except Exception:
                    pass
        if not doi:
            # Fall back to BibTeX
            from ._pybtex_utils import parse_bibtex_file, require_pybtex
            require_pybtex("refresh-metadata")
            src_dir = cfg.bibtex_merge.src_dir
            src_glob = cfg.bibtex_merge.src_glob
            for bib_path in sorted(p for p in src_dir.glob(src_glob) if p.is_file()):
                db = parse_bibtex_file(bib_path)
                if citekey in db.entries:
                    doi = str(db.entries[citekey].fields.get("doi") or "").strip() or None
                    break
        if not doi:
            raise fastapi.HTTPException(status_code=400, detail=f"No DOI found for {citekey}")
        try:
            result = add_openalex_work_to_bib(
                cfg=cfg.openalex_client, cache=cfg.openalex_cache,
                repo_root=cfg.repo_root, doi=doi,
            )
            return {"ok": True, "citekey": citekey, "openalex_id": result.openalex_id}
        except Exception as exc:
            raise fastapi.HTTPException(status_code=500, detail=str(exc))

    # ── normalize-citekeys action ─────────────────────────────────────────────

    @app.post("/api/actions/normalize-citekeys", response_class=responses.JSONResponse)
    def action_normalize_citekeys(payload: dict[str, Any]):
        """Preview or apply citekey normalization to author_year_Title format."""
        from ._pybtex_utils import parse_bibtex_file, require_pybtex
        require_pybtex("normalize-citekeys")
        apply = bool(payload.get("apply", False))
        active_cfg = current_cfg()
        src_dir = active_cfg.bibtex_merge.src_dir
        src_glob = active_cfg.bibtex_merge.src_glob
        bib_files = sorted(p for p in src_dir.glob(src_glob) if p.is_file())
        renames: list[dict[str, str]] = []
        seen_new: dict[str, str] = {}  # new_key -> old_key (dedup)
        _STANDARD = re.compile(r"^[a-z]+_\d{4}_[A-Za-z]")
        for bib_path in bib_files:
            db = parse_bibtex_file(bib_path)
            for old_key, entry in sorted(db.entries.items()):
                if _STANDARD.match(old_key):
                    continue  # already standard
                fields = entry.fields
                authors_raw = str(fields.get("author") or "")
                authors = [a.strip() for a in authors_raw.split(" and ") if a.strip()]
                year = str(fields.get("year") or "")
                title = str(fields.get("title") or "")
                rec = IngestRecord(
                    source_type="bibtex", source_ref=str(bib_path),
                    entry_type=entry.type, title=title or None,
                    authors=tuple(authors), year=year or None,
                    doi=str(fields.get("doi") or "") or None,
                    url=None, journal=None, booktitle=None, raw_id=old_key,
                )
                new_key = canonical_citekey(rec)
                if new_key == old_key:
                    continue
                # dedup suffix
                base = new_key
                idx = 2
                while new_key in seen_new and seen_new[new_key] != old_key:
                    new_key = f"{base}{idx}"
                    idx += 1
                seen_new[new_key] = old_key
                renames.append({"old": old_key, "new": new_key, "source_bib": str(bib_path)})
        if apply and renames:
            from pybtex.database.output.bibtex import Writer as BibWriter
            from pybtex.database import BibliographyData
            import copy as _copy
            rename_map = {r["old"]: r["new"] for r in renames}
            for bib_path_str in {r["source_bib"] for r in renames}:
                bib_path = Path(bib_path_str)
                db = parse_bibtex_file(bib_path)
                new_entries = {}
                for k, e in db.entries.items():
                    new_k = rename_map.get(k, k)
                    new_entries[new_k] = _copy.deepcopy(e)
                new_db = BibliographyData(entries=new_entries)
                buf = io.StringIO()
                BibWriter().write_stream(new_db, buf)
                bib_path.write_text(buf.getvalue(), encoding="utf-8")
            # update citekeys.md
            from .citekeys import load_citekeys_md, add_citekeys_md, remove_citekeys_md
            ck_path = active_cfg.citekeys_path
            if ck_path and Path(ck_path).exists():
                existing = load_citekeys_md(ck_path)
                updated = [rename_map.get(k, k) for k in existing]
                from .citekeys import _render_citekeys_md
                Path(ck_path).write_text(_render_citekeys_md(updated), encoding="utf-8")
        return {"ok": True, "renames": renames, "applied": apply and bool(renames)}

    # ── library endpoints ─────────────────────────────────────────────────────

    @app.get("/api/library", response_class=responses.JSONResponse)
    def get_library():
        return load_library(current_cfg())

    @app.post("/api/library/{citekey}", response_class=responses.JSONResponse)
    def update_library_entry(citekey: str, payload: dict[str, Any]):
        active_cfg = current_cfg()
        tags = payload.get("tags")
        if isinstance(tags, str):
            tags = [t.strip() for t in tags.split(",") if t.strip()] or None
        elif isinstance(tags, list):
            tags = [str(t).strip() for t in tags if str(t).strip()] or None
        entry = update_entry(
            active_cfg,
            citekey,
            status=payload.get("status") or None,
            tags=tags,
            priority=payload.get("priority") or None,
        )
        return {"ok": True, "citekey": citekey, "entry": entry}

    # ── paper context endpoint (AI-facing) ────────────────────────────────────

    @app.get("/api/papers/{citekey}/context", response_class=responses.JSONResponse)
    def paper_context(citekey: str):
        active_cfg = current_cfg()
        payload = build_ui_model(active_cfg)
        paper = payload.get("paper_lookup", {}).get(citekey)
        if not paper:
            raise fastapi.HTTPException(status_code=404, detail=f"Paper not found: {citekey}")
        lib = paper.get("library") or {}
        grobid = paper.get("grobid") or {}
        header = grobid.get("header") or {}
        np = notes_path(active_cfg, citekey)
        notes_text = np.read_text(encoding="utf-8") if np.exists() else None
        return {
            "citekey": citekey,
            "title": paper.get("title"),
            "authors": paper.get("authors") or [],
            "year": paper.get("year"),
            "doi": paper.get("doi"),
            "abstract": header.get("abstract"),
            "status": lib.get("status"),
            "tags": lib.get("tags") or [],
            "priority": lib.get("priority"),
            "docling_excerpt": (paper.get("docling") or {}).get("excerpt"),
            "reference_count": grobid.get("reference_count", 0),
            "local_refs": [r["target_citekey"] for r in (paper.get("graph") or {}).get("grobid_refs", [])],
            "openalex_id": (paper.get("graph") or {}).get("seed_openalex_id"),
            "notes": notes_text,
            "artifacts": {
                k: bool(v.get("exists"))
                for k, v in (paper.get("artifacts") or {}).items()
                if isinstance(v, dict) and "exists" in v
            },
        }

    # ── absent-refs endpoint ──────────────────────────────────────────────────

    @app.get("/api/papers/{citekey}/absent-refs", response_class=responses.JSONResponse)
    def paper_absent_refs(citekey: str):
        return {"absent_refs": get_absent_refs(current_cfg(), citekey)}

    # ── ref-resolutions cache (persist CrossRef DOI lookups) ──────────────────

    @app.get("/api/papers/{citekey}/ref-resolutions", response_class=responses.JSONResponse)
    def get_ref_resolutions(citekey: str):
        key = citekey.lstrip("@")
        cache_path = grobid_out_root(current_cfg()) / key / "_ref_resolutions.json"
        if not cache_path.exists():
            return {"resolutions": {}}
        try:
            return json.loads(cache_path.read_text(encoding="utf-8"))
        except Exception:
            return {"resolutions": {}}

    @app.post("/api/papers/{citekey}/ref-resolutions", response_class=responses.JSONResponse)
    def save_ref_resolutions(citekey: str, payload: dict[str, Any]):
        key = citekey.lstrip("@")
        cache_dir = grobid_out_root(current_cfg()) / key
        cache_dir.mkdir(parents=True, exist_ok=True)
        cache_path = cache_dir / "_ref_resolutions.json"
        data = json.dumps({"resolutions": payload.get("resolutions", {})}, indent=2)
        cache_path.write_text(data, encoding="utf-8")
        return {"ok": True}

    # ── ref-resolved markdown endpoint ────────────────────────────────────────

    @app.get("/api/papers/{citekey}/ref-md", response_class=responses.PlainTextResponse)
    def paper_ref_md(citekey: str):
        key = citekey.lstrip("@")
        md_path = current_cfg().out_root / key / f"{key}_ref_resolved.md"
        if not md_path.exists():
            return responses.PlainTextResponse("", status_code=200)
        return responses.PlainTextResponse(md_path.read_text(encoding="utf-8", errors="replace"))

    # ── figures endpoint ──────────────────────────────────────────────────────

    def _read_image_dimensions(path: Path) -> tuple[int, int]:
        """Read (width, height) from a PNG or JPEG file without external deps."""
        try:
            with open(path, "rb") as f:
                header = f.read(24)
                if header[:8] == b"\x89PNG\r\n\x1a\n":
                    w, h = struct.unpack(">II", header[16:24])
                    return w, h
                # JPEG: scan for SOF0/SOF1/SOF2 markers
                f.seek(2)
                while True:
                    marker = f.read(2)
                    if len(marker) < 2 or marker[0] != 0xFF:
                        break
                    if marker[1] in (0xC0, 0xC1, 0xC2):
                        f.read(3)  # length + precision
                        h, w = struct.unpack(">HH", f.read(4))
                        return w, h
                    length = struct.unpack(">H", f.read(2))[0]
                    f.seek(length - 2, 1)
        except Exception:
            pass
        return 0, 0

    @app.get("/api/papers/{citekey}/figures", response_class=responses.JSONResponse)
    def paper_figures(citekey: str):
        key = citekey.lstrip("@")
        out_dir = current_cfg().out_root / key
        artifacts_dir = out_dir / f"{key}_artifacts"
        if not artifacts_dir.exists():
            return {"figures": []}

        # Build stem -> caption map from Docling JSON if available
        caption_map: dict[str, str] = {}
        docling_json = out_dir / f"{key}.json"
        if docling_json.exists():
            try:
                doc = json.loads(docling_json.read_text())
                texts = doc.get("texts", [])
                for pic in doc.get("pictures", []):
                    uri = (pic.get("image") or {}).get("uri", "")
                    stem = Path(uri).name if uri else ""
                    captions = pic.get("captions", [])
                    if stem and captions:
                        ref = captions[0].get("$ref", "")
                        # ref format: '#/texts/44'
                        parts = ref.split("/")
                        if len(parts) == 3 and parts[1] == "texts":
                            idx = int(parts[2])
                            if 0 <= idx < len(texts):
                                caption_map[stem] = texts[idx].get("text", "")
            except Exception:
                pass

        figures = []
        for fpath in sorted(artifacts_dir.iterdir()):
            if fpath.suffix.lower() not in {".png", ".jpg", ".jpeg"}:
                continue
            w, h = _read_image_dimensions(fpath)
            figures.append({
                "path": f"{key}_artifacts/{fpath.name}",
                "name": fpath.name,
                "width": w,
                "height": h,
                "size_bytes": fpath.stat().st_size,
                "caption": caption_map.get(fpath.stem, ""),
            })
        return {"figures": figures}

    # ── collections endpoints ─────────────────────────────────────────────────

    @app.get("/api/collections", response_class=responses.JSONResponse)
    def api_get_collections():
        return load_collections(current_cfg())

    @app.post("/api/collections", response_class=responses.JSONResponse)
    def api_create_collection(payload: dict[str, Any]):
        name = str(payload.get("name") or "").strip()
        if not name:
            raise fastapi.HTTPException(status_code=400, detail="Missing name")
        col = create_collection(current_cfg(), name, payload.get("parent") or None)
        return col

    @app.patch("/api/collections/{col_id}", response_class=responses.JSONResponse)
    def api_update_collection(col_id: str, payload: dict[str, Any]):
        cfg = current_cfg()
        if "name" in payload:
            if not rename_collection(cfg, col_id, str(payload["name"]).strip()):
                raise fastapi.HTTPException(status_code=404, detail="Collection not found")
        if "parent" in payload:
            result = move_collection(cfg, col_id, payload["parent"] or None)
            if result is None:
                raise fastapi.HTTPException(status_code=400, detail="Move would create cycle or collection not found")
        return load_collections(cfg)

    @app.delete("/api/collections/{col_id}", response_class=responses.JSONResponse)
    def api_delete_collection(col_id: str):
        if not delete_collection(current_cfg(), col_id):
            raise fastapi.HTTPException(status_code=404, detail="Collection not found")
        return {"ok": True}

    @app.post("/api/collections/{col_id}/papers", response_class=responses.JSONResponse)
    def api_collection_add_papers(col_id: str, payload: dict[str, Any]):
        citekeys = payload.get("citekeys") or []
        if isinstance(citekeys, str):
            citekeys = [citekeys]
        col = col_add_papers(current_cfg(), col_id, [str(k) for k in citekeys])
        if col is None:
            raise fastapi.HTTPException(status_code=404, detail="Collection not found")
        return col

    @app.delete("/api/collections/{col_id}/papers", response_class=responses.JSONResponse)
    def api_collection_remove_papers(col_id: str, payload: dict[str, Any]):
        citekeys = payload.get("citekeys") or []
        if isinstance(citekeys, str):
            citekeys = [citekeys]
        col = col_remove_papers(current_cfg(), col_id, [str(k) for k in citekeys])
        if col is None:
            raise fastapi.HTTPException(status_code=404, detail="Collection not found")
        return col

    @app.post("/api/resolve-doi", response_class=responses.JSONResponse)
    def api_resolve_doi(payload: dict[str, Any]):
        title = str(payload.get("title") or "").strip()
        if not title:
            raise fastapi.HTTPException(status_code=400, detail="Missing title")
        return resolve_doi_by_title(title)

    # ── fetch OA PDFs endpoint ───────────────────────────────────────────────

    fetch_oa_job: dict[str, Any] = {
        "running": False, "message": "", "error": None,
        "completed": 0, "total": 0,
        "downloaded": 0, "skipped": 0, "no_url": 0, "errors": 0, "logs": "",
    }
    fetch_oa_lock = threading.Lock()

    def _fetch_oa_snapshot() -> dict[str, Any]:
        with fetch_oa_lock:
            return dict(fetch_oa_job)

    @app.post("/api/actions/fetch-pdfs-oa", response_class=responses.JSONResponse)
    def action_fetch_pdfs_oa(payload: dict[str, Any]):
        active_cfg = current_cfg()
        force = bool(payload.get("force"))
        with fetch_oa_lock:
            if fetch_oa_job["running"]:
                return {"ok": True, "async": True, **dict(fetch_oa_job)}
            fetch_oa_job.update({
                "running": True, "message": "Fetching OA PDFs...", "error": None,
                "completed": 0, "total": 0,
                "downloaded": 0, "skipped": 0, "no_url": 0, "errors": 0, "logs": "",
            })

        def _progress(p: dict[str, Any]) -> None:
            with fetch_oa_lock:
                fetch_oa_job["completed"] = int(p.get("completed") or 0)
                fetch_oa_job["total"] = int(p.get("total") or 0)
                ck = p.get("citekey")
                fetch_oa_job["message"] = (
                    f"Fetching OA PDFs {fetch_oa_job['completed']}/{fetch_oa_job['total']}"
                    + (f" ({ck})" if ck else "")
                )

        def _run() -> None:
            try:
                results = fetch_pdfs_oa(active_cfg, force=force, progress_cb=_progress)
                counts = {s: sum(1 for r in results if r.status == s) for s in ("downloaded", "skipped", "no_url", "error")}
                error_lines = [f"{r.citekey}: {r.error}" for r in results if r.status == "error"]
                with fetch_oa_lock:
                    fetch_oa_job.update({
                        "running": False, "error": None,
                        "completed": len(results), "total": len(results),
                        "downloaded": counts["downloaded"],
                        "skipped": counts["skipped"],
                        "no_url": counts["no_url"],
                        "errors": counts["error"],
                        "logs": "\n".join(error_lines),
                        "message": (
                            f"OA fetch done: {counts['downloaded']} downloaded, "
                            f"{counts['no_url']} no URL, {counts['skipped']} skipped, "
                            f"{counts['error']} errors."
                        ),
                    })
            except Exception as e:
                with fetch_oa_lock:
                    fetch_oa_job.update({
                        "running": False, "error": str(e),
                        "message": f"OA PDF fetch failed: {e}", "logs": str(e),
                    })

        threading.Thread(target=_run, daemon=True).start()
        return {"ok": True, "async": True, **_fetch_oa_snapshot()}

    @app.get("/api/actions/fetch-pdfs-oa/status", response_class=responses.JSONResponse)
    def action_fetch_pdfs_oa_status():
        return _fetch_oa_snapshot()

    # ── RAG build endpoint ────────────────────────────────────────────────────

    rag_build_job: dict[str, Any] = {
        "running": False, "message": "", "error": None,
        "indexed": 0, "chunks": 0, "completed": 0, "total": 0, "logs": "",
    }
    rag_build_lock = threading.Lock()

    def _rag_build_snapshot() -> dict[str, Any]:
        with rag_build_lock:
            return dict(rag_build_job)

    def _rag_python(active_cfg: BiblioConfig) -> str:
        return active_cfg.rag_python or sys.executable

    @app.post("/api/actions/rag-build", response_class=responses.JSONResponse)
    def action_rag_build():
        active_cfg = current_cfg()
        with rag_build_lock:
            if rag_build_job["running"]:
                return {"ok": True, "async": True, **dict(rag_build_job)}
            rag_build_job.update({
                "running": True,
                "message": "Building RAG index...",
                "error": None,
                "indexed": 0,
                "chunks": 0,
                "completed": 0,
                "total": 1,
            })

        def _run_rag_build() -> None:
            try:
                if _indexio_mod is not None:
                    data = _rag_build_indexio(active_cfg.repo_root)
                else:
                    vector_store_path = str(Path(__file__).parent / "vector_store.py")
                    python_exe = _rag_python(active_cfg)
                    proc = subprocess.run(
                        [python_exe, vector_store_path, "build",
                         "--root", str(active_cfg.repo_root),
                         "--persist-dir", str(active_cfg.rag_persist_dir)],
                        capture_output=True, text=True, timeout=600,
                    )
                    if proc.returncode != 0:
                        err = (proc.stderr or proc.stdout or "").strip()
                        raise RuntimeError(f"RAG build exited {proc.returncode}: {err[:500]}")
                    data = json.loads(proc.stdout.strip())
                if not data.get("ok"):
                    raise RuntimeError(data.get("error") or "RAG build returned ok=false")
                with rag_build_lock:
                    rag_build_job.update({
                        "running": False,
                        "error": None,
                        "indexed": data.get("indexed", 0),
                        "chunks": data.get("chunks", 0),
                        "completed": 1,
                        "total": 1,
                        "message": f"RAG index built: {data.get('indexed', 0)} papers, {data.get('chunks', 0)} chunks.",
                        "logs": "",
                    })
            except Exception as e:
                with rag_build_lock:
                    rag_build_job.update({
                        "running": False,
                        "error": str(e),
                        "message": f"RAG build failed: {e}",
                        "completed": 1,
                        "total": 1,
                        "logs": str(e),
                    })

        threading.Thread(target=_run_rag_build, daemon=True).start()
        return {"ok": True, "async": True, **_rag_build_snapshot()}

    @app.get("/api/actions/rag-build/status", response_class=responses.JSONResponse)
    def action_rag_build_status():
        return _rag_build_snapshot()

    # ── semantic search endpoint ──────────────────────────────────────────────

    @app.post("/api/search/semantic", response_class=responses.JSONResponse)
    def search_semantic(payload: dict[str, Any]):
        active_cfg = current_cfg()
        query = str(payload.get("query") or "").strip()
        n_results = int(payload.get("n_results") or 10)
        if not query:
            raise fastapi.HTTPException(status_code=400, detail="Missing query")
        try:
            if _indexio_mod is not None:
                data = _rag_search_indexio(active_cfg.repo_root, query, n_results)
            else:
                vector_store_path = str(Path(__file__).parent / "vector_store.py")
                python_exe = _rag_python(active_cfg)
                proc = subprocess.run(
                    [python_exe, vector_store_path, "search",
                     "--root", str(active_cfg.repo_root),
                     "--persist-dir", str(active_cfg.rag_persist_dir),
                     "--query", query,
                     "--n", str(n_results)],
                    capture_output=True, text=True, timeout=60,
                )
                if proc.returncode != 0:
                    err = (proc.stderr or proc.stdout or "").strip()
                    raise RuntimeError(f"RAG search exited {proc.returncode}: {err[:500]}")
                data = json.loads(proc.stdout.strip())
        except Exception as e:
            raise fastapi.HTTPException(status_code=500, detail=str(e))
        if not data.get("ok"):
            raise fastapi.HTTPException(status_code=503, detail=data.get("error") or "Search failed")
        # enrich results with paper metadata
        model = build_ui_model(active_cfg)
        paper_lookup = model.get("paper_lookup") or {}
        for item in data.get("results") or []:
            ck = item.get("citekey", "")
            paper = paper_lookup.get(ck)
            if paper:
                item["title"] = paper.get("title")
                item["year"] = paper.get("year")
                item["authors"] = paper.get("authors") or []
        return data

    @app.post("/api/setup/docling-check", response_class=responses.JSONResponse)
    def setup_docling_check():
        return check_docling_command(current_cfg())

    @app.post("/api/setup/grobid-check", response_class=responses.JSONResponse)
    def setup_grobid_check():
        return check_grobid_server_as_dict(current_cfg().grobid)

    @app.post("/api/setup/grobid-config", response_class=responses.JSONResponse)
    def setup_grobid_config(payload: dict[str, Any]):
        repo_root = current_cfg().repo_root
        _update_grobid_config(repo_root, payload)
        updated = reload_cfg()
        return {
            "ok": True,
            "message": "Saved GROBID config.",
            "setup": build_setup_report(updated),
        }

    @app.post("/api/setup/docling-command", response_class=responses.JSONResponse)
    def setup_docling_command(payload: dict[str, Any]):
        mode = str(payload.get("mode") or "raw").strip()
        repo_root = current_cfg().repo_root
        if mode == "conda":
            env_name = str(payload.get("env_name") or "").strip()
            if not env_name:
                raise fastapi.HTTPException(status_code=400, detail="Missing conda env name")
            _update_docling_command(repo_root, ["conda", "run", "-n", env_name, "docling"])
            updated = reload_cfg()
            return {
                "ok": True,
                "message": f"Updated Docling command to use conda env {env_name}.",
                "setup": build_setup_report(updated),
            }
        command = str(payload.get("command") or "").strip()
        if not command:
            raise fastapi.HTTPException(status_code=400, detail="Missing command")
        _update_docling_command(repo_root, shlex.split(command))
        updated = reload_cfg()
        return {
            "ok": True,
            "message": "Updated Docling command.",
            "setup": build_setup_report(updated),
        }

    @app.post("/api/setup/install-docling-uv", response_class=responses.JSONResponse)
    def setup_install_docling_uv():
        repo_root = current_cfg().repo_root
        try:
            install = _install_docling_uv(repo_root)
        except subprocess.CalledProcessError as e:
            cmd = " ".join(str(part) for part in e.cmd) if isinstance(e.cmd, (list, tuple)) else str(e.cmd)
            detail = (e.stderr or e.stdout or "").strip()
            msg = f"uv-based Docling install failed with exit code {e.returncode}: {cmd}"
            if detail:
                msg = f"{msg}\n{detail}"
            raise fastapi.HTTPException(status_code=500, detail=msg)
        except Exception as e:
            raise fastapi.HTTPException(status_code=500, detail=str(e))
        updated = reload_cfg()
        return {
            "ok": True,
            "message": f"Installed Docling into {install['env_dir']}.",
            "install": install,
            "setup": build_setup_report(updated),
        }

    return app


def serve_ui_app(cfg: BiblioConfig, *, host: str = "127.0.0.1", port: int = 8010) -> None:
    uvicorn = _require_uvicorn()
    app = create_ui_app(cfg)
    selected_port = find_available_port(str(host), int(port))
    print(f"[OK] UI available at http://{host}:{selected_port}")
    if selected_port != int(port):
        print(f"[INFO] Requested port {port} was unavailable; using {selected_port} instead.")
    uvicorn.run(app, host=host, port=int(selected_port))
