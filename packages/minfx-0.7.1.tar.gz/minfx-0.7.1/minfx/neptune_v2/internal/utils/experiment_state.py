__all__ = ['ExperimentState']
import enum
from minfx.neptune_v2.common.exceptions import NeptuneException
_API_TO_STATE = {}
_STATE_TO_API = {}

class ExperimentState(enum.Enum):
    ACTIVE = 'Active'
    INACTIVE = 'Inactive'

    @classmethod
    def from_string(cls, value):
        try:
            return cls(value.capitalize())
        except ValueError as e:
            raise NeptuneException(f"Can't map ExperimentState from string: {value}") from e

    @classmethod
    def from_api(cls, value):
        if value not in _API_TO_STATE:
            raise NeptuneException(f'Unknown ExperimentState from API: {value}')
        return _API_TO_STATE[value]

    def to_api(self):
        return _STATE_TO_API[self]
_API_TO_STATE.update({'running': ExperimentState.ACTIVE, 'idle': ExperimentState.INACTIVE})
_STATE_TO_API.update({ExperimentState.ACTIVE: 'running', ExperimentState.INACTIVE: 'idle'})