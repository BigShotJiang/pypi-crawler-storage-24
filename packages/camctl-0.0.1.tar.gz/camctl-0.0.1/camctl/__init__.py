"""camctl - A CLI for managing IP cameras. Install the Rust binary: cargo install camctl"""
__version__ = "0.0.1"
