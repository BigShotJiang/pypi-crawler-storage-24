"""
dgfip-fetcher - Outil de téléchargement automatisé des documents fiscaux depuis impots.gouv.fr
"""

__version__ = "0.1.0"
