from __future__ import annotations

from datetime import date, datetime

import numpy as np
import pandas as pd

from xtquant_rpc_client.serialization import from_proto_value, to_proto_value


def test_round_trip_nested_python_values() -> None:
    value = {
        "none": None,
        "bool": True,
        "int": -7,
        "uint": 9,
        "float": 1.25,
        "str": "abc",
        "bytes": b"xyz",
        "date": date(2026, 3, 21),
        "datetime": datetime(2026, 3, 21, 9, 30, 15),
        "list": [1, "two", False],
        99: {"nested": "ok"},
    }

    restored = from_proto_value(to_proto_value(value))

    assert restored["none"] is None
    assert restored["bool"] is True
    assert restored["int"] == -7
    assert restored["uint"] == 9
    assert restored["float"] == 1.25
    assert restored["str"] == "abc"
    assert restored["bytes"] == b"xyz"
    assert restored["date"] == date(2026, 3, 21)
    assert restored["datetime"] == datetime(2026, 3, 21, 9, 30, 15)
    assert restored["list"] == [1, "two", False]
    assert restored[99] == {"nested": "ok"}


def test_round_trip_dataframe_series_and_ndarray() -> None:
    frame = pd.DataFrame({"symbol": ["000001.SZ", "600000.SH"], "close": [12.3, 9.8]})
    series = pd.Series([1, 2, 3], name="weights", index=["a", "b", "c"])
    array = np.arange(6, dtype=np.int64).reshape(2, 3)

    restored_frame = from_proto_value(to_proto_value(frame))
    restored_series = from_proto_value(to_proto_value(series))
    restored_array = from_proto_value(to_proto_value(array))

    pd.testing.assert_frame_equal(restored_frame, frame)
    pd.testing.assert_series_equal(restored_series, series)
    assert np.array_equal(restored_array, array)
