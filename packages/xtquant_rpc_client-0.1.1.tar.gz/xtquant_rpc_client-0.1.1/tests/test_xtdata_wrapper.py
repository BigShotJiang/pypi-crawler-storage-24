from __future__ import annotations

import inspect

from xtquant_rpc_client import XtquantRpcClient, xtdata


def test_wrapper_signature_is_exposed() -> None:
    signature = inspect.signature(xtdata.get_market_data)
    assert "field_list" in signature.parameters
    assert signature.parameters["period"].default == "1d"


def test_wrapper_dispatches_via_default_invoke(monkeypatch) -> None:
    captured: dict[str, object] = {}

    def fake_invoke(domain, method, **kwargs):
        captured["domain"] = domain
        captured["method"] = method
        captured["kwargs"] = kwargs
        return "ok"

    monkeypatch.setattr("xtquant_rpc_client.xtdata.invoke", fake_invoke)

    result = xtdata.get_stock_list_in_sector("CSI300", real_timetag=123)

    assert result == "ok"
    assert captured["domain"] == "xtdata"
    assert captured["method"] == "get_stock_list_in_sector"
    assert captured["kwargs"] == {"sector_name": "CSI300", "real_timetag": 123}


def test_client_xtdata_stub_dispatches(monkeypatch) -> None:
    captured: dict[str, object] = {}

    def fake_invoke(self, domain, method, *args, **kwargs):
        captured["domain"] = domain
        captured["method"] = method
        captured["args"] = args
        captured["kwargs"] = kwargs
        return "ok"

    monkeypatch.setattr(XtquantRpcClient, "invoke", fake_invoke)

    client = XtquantRpcClient(host="127.0.0.1", port=50051, token="secret")
    signature = inspect.signature(client.xtdata.get_market_data)
    result = client.xtdata.get_market_data(stock_list=["000001.SZ"], period="1d")

    assert "stock_list" in signature.parameters
    assert signature.parameters["period"].default == "1d"
    assert result == "ok"
    assert captured["domain"] == "xtdata"
    assert captured["method"] == "get_market_data"
    assert captured["args"] == ()
    assert captured["kwargs"]["stock_list"] == ["000001.SZ"]
    assert captured["kwargs"]["period"] == "1d"
    assert captured["kwargs"]["field_list"] == []
    assert captured["kwargs"]["count"] == -1
