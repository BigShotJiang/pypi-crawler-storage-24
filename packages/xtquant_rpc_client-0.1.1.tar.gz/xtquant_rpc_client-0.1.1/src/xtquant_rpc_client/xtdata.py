from __future__ import annotations

from typing import Any

from .defaults import invoke
from .xtdata_methods import SUPPORTED_METHOD_SIGNATURES

__all__ = sorted(SUPPORTED_METHOD_SIGNATURES)


def _invoke_method(method: str, local_values: dict[str, Any]) -> Any:
    kwargs = dict(local_values)
    extra_kwargs = kwargs.pop("kwargs", {})
    kwargs.update(extra_kwargs)
    return invoke("xtdata", method, **kwargs)


def _make_wrapper(method: str, signature_text: str):
    namespace: dict[str, Any] = {}
    source = (
        f"def {method}{signature_text}:\n"
        f"    return _invoke_method('{method}', locals())\n"
    )
    exec(source, {"_invoke_method": _invoke_method}, namespace)
    func = namespace[method]
    func.__module__ = __name__
    func.__doc__ = f"Remote xtdata proxy for `{method}`."
    return func


for _method_name, _signature_text in SUPPORTED_METHOD_SIGNATURES.items():
    globals()[_method_name] = _make_wrapper(_method_name, _signature_text)
