from __future__ import annotations

from datetime import date, datetime
from typing import Any

import numpy as np
import pandas as pd
import pyarrow as pa

from xtquant_rpc.v1 import service_pb2


def _series_to_arrow_bytes(series: pd.Series) -> bytes:
    table = pa.Table.from_pandas(series.to_frame(name=series.name), preserve_index=True)
    sink = pa.BufferOutputStream()
    with pa.ipc.new_stream(sink, table.schema) as writer:
        writer.write_table(table)
    return sink.getvalue().to_pybytes()


def _series_from_arrow_bytes(payload: bytes, name: str | None) -> pd.Series:
    table = pa.ipc.open_stream(payload).read_all()
    frame = table.to_pandas()
    column_name = frame.columns[0]
    series = frame.iloc[:, 0]
    if name:
        series.name = name
    elif column_name is not None:
        series.name = column_name
    return series


def _dataframe_to_arrow_bytes(frame: pd.DataFrame) -> bytes:
    table = pa.Table.from_pandas(frame, preserve_index=True)
    sink = pa.BufferOutputStream()
    with pa.ipc.new_stream(sink, table.schema) as writer:
        writer.write_table(table)
    return sink.getvalue().to_pybytes()


def _dataframe_from_arrow_bytes(payload: bytes) -> pd.DataFrame:
    table = pa.ipc.open_stream(payload).read_all()
    return table.to_pandas()


def to_proto_value(value: Any) -> service_pb2.Value:
    proto = service_pb2.Value()
    if value is None:
        proto.null_value.SetInParent()
        return proto
    if isinstance(value, bool):
        proto.bool_value = value
        return proto
    if isinstance(value, np.bool_):
        proto.bool_value = bool(value)
        return proto
    if isinstance(value, int) and not isinstance(value, bool):
        if value >= 0:
            proto.uint_value = value
        else:
            proto.int_value = value
        return proto
    if isinstance(value, np.integer):
        int_value = int(value)
        if int_value >= 0:
            proto.uint_value = int_value
        else:
            proto.int_value = int_value
        return proto
    if isinstance(value, float):
        proto.float_value = value
        return proto
    if isinstance(value, np.floating):
        proto.float_value = float(value)
        return proto
    if isinstance(value, str):
        proto.string_value = value
        return proto
    if isinstance(value, bytes):
        proto.bytes_value = value
        return proto
    if isinstance(value, datetime):
        proto.datetime_value.iso_datetime = value.isoformat()
        return proto
    if isinstance(value, date):
        proto.date_value.iso_date = value.isoformat()
        return proto
    if isinstance(value, np.ndarray):
        proto.ndarray_value.shape.extend(int(dim) for dim in value.shape)
        proto.ndarray_value.dtype = value.dtype.str
        proto.ndarray_value.data = value.tobytes(order="C")
        return proto
    if isinstance(value, pd.DataFrame):
        proto.dataframe_value.arrow_ipc = _dataframe_to_arrow_bytes(value)
        return proto
    if isinstance(value, pd.Series):
        proto.series_value.arrow_ipc = _series_to_arrow_bytes(value)
        proto.series_value.name = "" if value.name is None else str(value.name)
        return proto
    if isinstance(value, tuple):
        value = list(value)
    if isinstance(value, list):
        proto.list_value.items.extend(to_proto_value(item) for item in value)
        return proto
    if isinstance(value, dict):
        for key, item in value.items():
            entry = proto.map_value.entries.add()
            entry.key.CopyFrom(to_proto_value(key))
            entry.value.CopyFrom(to_proto_value(item))
        return proto
    raise TypeError(f"Unsupported value type for protobuf serialization: {type(value)!r}")


def from_proto_value(value: service_pb2.Value) -> Any:
    kind = value.WhichOneof("kind")
    if kind == "null_value" or kind is None:
        return None
    if kind == "bool_value":
        return value.bool_value
    if kind == "int_value":
        return value.int_value
    if kind == "uint_value":
        return value.uint_value
    if kind == "float_value":
        return value.float_value
    if kind == "string_value":
        return value.string_value
    if kind == "bytes_value":
        return value.bytes_value
    if kind == "date_value":
        return date.fromisoformat(value.date_value.iso_date)
    if kind == "datetime_value":
        return datetime.fromisoformat(value.datetime_value.iso_datetime)
    if kind == "list_value":
        return [from_proto_value(item) for item in value.list_value.items]
    if kind == "map_value":
        result = {}
        for entry in value.map_value.entries:
            result[from_proto_value(entry.key)] = from_proto_value(entry.value)
        return result
    if kind == "ndarray_value":
        dtype = np.dtype(value.ndarray_value.dtype)
        data = np.frombuffer(value.ndarray_value.data, dtype=dtype)
        return data.reshape(tuple(value.ndarray_value.shape))
    if kind == "dataframe_value":
        return _dataframe_from_arrow_bytes(value.dataframe_value.arrow_ipc)
    if kind == "series_value":
        name = value.series_value.name or None
        return _series_from_arrow_bytes(value.series_value.arrow_ipc, name)
    raise TypeError(f"Unsupported protobuf value kind: {kind!r}")
