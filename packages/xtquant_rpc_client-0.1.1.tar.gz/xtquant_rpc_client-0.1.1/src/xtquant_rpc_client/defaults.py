from __future__ import annotations

from typing import Any

from .client import XtquantRpcClient

_default_client: XtquantRpcClient | None = None


def configure_default_client(host: str, port: int, token: str, timeout: float = 30.0) -> XtquantRpcClient:
    global _default_client
    if _default_client is not None:
        _default_client.close()
    _default_client = XtquantRpcClient(host=host, port=port, token=token, timeout=timeout)
    return _default_client


def get_default_client() -> XtquantRpcClient:
    if _default_client is None:
        raise RuntimeError("Default xtquant RPC client is not configured. Call configure_default_client(...) first.")
    return _default_client


def invoke(domain: str, method: str, *args: Any, **kwargs: Any) -> Any:
    return get_default_client().invoke(domain, method, *args, **kwargs)
