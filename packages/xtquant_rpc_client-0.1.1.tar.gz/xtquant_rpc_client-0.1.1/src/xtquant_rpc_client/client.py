from __future__ import annotations

from dataclasses import dataclass
from threading import Lock
from typing import Any

import grpc

from xtquant_rpc.v1 import service_pb2, service_pb2_grpc

from .exceptions import (
    AuthenticationError,
    DomainNotSupportedError,
    MethodNotSupportedError,
    RemoteInvocationError,
)
from .serialization import from_proto_value, to_proto_value
from .xtdata_stub import XtdataStub


@dataclass(slots=True)
class ConnectionConfig:
    host: str
    port: int
    token: str
    timeout: float = 30.0


class XtquantRpcClient:
    def __init__(self, host: str, port: int, token: str, timeout: float = 30.0) -> None:
        self.config = ConnectionConfig(host=host, port=port, token=token, timeout=timeout)
        self._lock = Lock()
        self._channel: grpc.Channel | None = None
        self._stub: service_pb2_grpc.XtquantRpcServiceStub | None = None
        self.xtdata: XtdataStub = XtdataStub(self)

    def _ensure_stub(self) -> service_pb2_grpc.XtquantRpcServiceStub:
        if self._stub is None:
            with self._lock:
                if self._stub is None:
                    target = f"{self.config.host}:{self.config.port}"
                    self._channel = grpc.insecure_channel(target)
                    self._stub = service_pb2_grpc.XtquantRpcServiceStub(self._channel)
        return self._stub

    def close(self) -> None:
        if self._channel is not None:
            self._channel.close()
        self._channel = None
        self._stub = None

    def invoke(self, domain: str, method: str, *args: Any, **kwargs: Any) -> Any:
        request = service_pb2.InvokeRequest(
            domain=domain,
            method=method,
            request_id="",
            auth_token=self.config.token,
        )
        request.args.extend(to_proto_value(arg) for arg in args)
        for key, value in kwargs.items():
            request.kwargs[key].CopyFrom(to_proto_value(value))

        try:
            response = self._ensure_stub().Invoke(request, timeout=self.config.timeout)
        except grpc.RpcError as exc:
            if exc.code() == grpc.StatusCode.UNAUTHENTICATED:
                raise AuthenticationError(exc.details() or "authentication failed") from exc
            raise RemoteInvocationError(exc.code().name, exc.details() or "gRPC transport error") from exc

        if response.ok:
            return from_proto_value(response.result)

        error_type = response.error_type or "RemoteInvocationError"
        message = response.error_message or "remote invocation failed"
        traceback_text = response.traceback
        if error_type == "DomainNotSupportedError":
            raise DomainNotSupportedError(message)
        if error_type == "MethodNotSupportedError":
            raise MethodNotSupportedError(message)
        if error_type == "AuthenticationError":
            raise AuthenticationError(message)
        raise RemoteInvocationError(error_type, message, traceback_text)
