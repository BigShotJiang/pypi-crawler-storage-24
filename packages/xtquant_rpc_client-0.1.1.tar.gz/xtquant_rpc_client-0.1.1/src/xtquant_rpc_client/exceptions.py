class XtquantRpcError(Exception):
    """Base exception raised by the xtquant RPC client."""


class AuthenticationError(XtquantRpcError):
    """Raised when the server rejects the provided token."""


class DomainNotSupportedError(XtquantRpcError):
    """Raised when the requested xtquant domain is not registered on the server."""


class MethodNotSupportedError(XtquantRpcError):
    """Raised when a domain does not expose the requested method."""


class RemoteInvocationError(XtquantRpcError):
    """Raised when the remote domain execution failed."""

    def __init__(self, error_type: str, error_message: str, traceback_text: str = "") -> None:
        self.error_type = error_type
        self.error_message = error_message
        self.traceback_text = traceback_text
        message = f"{error_type}: {error_message}" if error_type else error_message
        super().__init__(message)
