from __future__ import annotations

from collections.abc import Mapping, Sequence
from datetime import datetime
from typing import Any, Literal, TypeAlias

import pandas as pd
from numpy.typing import NDArray

FieldList: TypeAlias = Sequence[str]
StockCode: TypeAlias = str
StockList: TypeAlias = Sequence[StockCode]
MarketCode: TypeAlias = str
SectorName: TypeAlias = str
TableName: TypeAlias = str
PeriodLike: TypeAlias = str | tuple[int, int]
TimeString: TypeAlias = str
TimeLike: TypeAlias = str | datetime
DividendType: TypeAlias = Literal["none", "front", "back", "front_ratio", "back_ratio"] | str
ReportType: TypeAlias = Literal["report_time", "announce_time"] | str
TradingDateList: TypeAlias = list[int]
CalendarList: TypeAlias = list[str] | list[int]
JsonDict: TypeAlias = dict[str, Any]
NestedDict: TypeAlias = dict[str, Any]
FrameDict: TypeAlias = dict[str, pd.DataFrame]
ArrayDict: TypeAlias = dict[str, NDArray[Any]]
MarketDataResult: TypeAlias = FrameDict | ArrayDict
FinancialDataResult: TypeAlias = dict[StockCode, dict[TableName, pd.DataFrame]]
InstrumentDetail: TypeAlias = dict[str, Any] | None
PeriodList: TypeAlias = list[str] | list[tuple[int, int]]
TradingPeriodList: TypeAlias = list[list[int]] | list[tuple[int, int, int]]


class XtdataStub:
    """远程 xtdata 调用桩。

    该类型用于给 IDE 提供与 `xtquant.xtdata` 接近的方法补全、参数提示和返回值提示。
    返回类型基于迅投官方 xtdata 文档与 xtquant 实现做了保守建模：
    能稳定确认的接口给出具体类型，差异较大的接口使用 `Any` 或宽泛别名兜底。
    """

    def __init__(self, rpc_client: Any) -> None: ...

    # 基础连接与元数据
    def get_data_dir(self) -> str: ...
    # 获取指定 metaid 对应的字段列表。
    def get_field_list(self, metaid: int) -> list[str]: ...

    # 行情查询接口
    # 获取板块成分股列表，real_timetag 为空时取最新成分。
    def get_stock_list_in_sector(self, sector_name: SectorName, real_timetag: int | str = -1) -> list[str]: ...
    # 获取指数成分权重。
    def get_index_weight(self, index_code: StockCode) -> dict[str, float]: ...
    # 获取财务数据，返回 {股票代码: {报表名: DataFrame}}。
    def get_financial_data(
        self,
        stock_list: StockList,
        table_list: Sequence[TableName] = [],
        start_time: TimeString = '',
        end_time: TimeString = '',
        report_type: ReportType = 'report_time',
    ) -> FinancialDataResult: ...
    # 原始财务数据接口，返回结构与 get_financial_data 基本一致。
    def get_financial_data_ori(
        self,
        stock_list: StockList,
        table_list: Sequence[TableName] = [],
        start_time: TimeString = '',
        end_time: TimeString = '',
        report_type: ReportType = 'report_time',
    ) -> FinancialDataResult: ...
    # 获取历史行情原始结果；K 线返回字段到 DataFrame 的映射，tick 返回股票到 ndarray 的映射。
    def get_market_data_ori(
        self,
        field_list: FieldList = [],
        stock_list: StockList = [],
        period: PeriodLike = '1d',
        start_time: TimeLike = '',
        end_time: TimeLike = '',
        count: int = -1,
        dividend_type: DividendType = 'none',
        fill_data: bool = True,
        enable_read_from_server: bool = True,
        data_dir: str | None = None,
    ) -> MarketDataResult: ...
    # 获取历史行情数据；返回形态与 xtdata 文档一致。
    def get_market_data(
        self,
        field_list: FieldList = [],
        stock_list: StockList = [],
        period: PeriodLike = '1d',
        start_time: TimeLike = '',
        end_time: TimeLike = '',
        count: int = -1,
        dividend_type: DividendType = 'none',
        fill_data: bool = True,
    ) -> MarketDataResult: ...
    # 获取扩展行情原始结果；常见返回为 {股票代码: DataFrame}。
    def get_market_data_ex_ori(
        self,
        field_list: FieldList = [],
        stock_list: StockList = [],
        period: PeriodLike = '1d',
        start_time: TimeLike = '',
        end_time: TimeLike = '',
        count: int = -1,
        dividend_type: DividendType = 'none',
        fill_data: bool = True,
        enable_read_from_server: bool = True,
        data_dir: str | None = None,
    ) -> dict[str, pd.DataFrame]: ...
    # 获取扩展行情数据，通常返回 {股票代码: DataFrame}。
    def get_market_data_ex(
        self,
        field_list: FieldList = [],
        stock_list: StockList = [],
        period: PeriodLike = '1d',
        start_time: TimeLike = '',
        end_time: TimeLike = '',
        count: int = -1,
        dividend_type: DividendType = 'none',
        fill_data: bool = True,
    ) -> dict[str, pd.DataFrame]: ...
    # 获取本地缓存行情数据。
    def get_local_data(
        self,
        field_list: FieldList = [],
        stock_list: StockList = [],
        period: PeriodLike = '1d',
        start_time: TimeLike = '',
        end_time: TimeLike = '',
        count: int = -1,
        dividend_type: DividendType = 'none',
        fill_data: bool = True,
        data_dir: str | None = None,
    ) -> dict[str, pd.DataFrame]: ...
    # 获取 level2 快照数据，按 time 升序返回 ndarray。
    def get_l2_quote(
        self,
        field_list: FieldList = [],
        stock_code: StockCode = '',
        start_time: TimeString = '',
        end_time: TimeString = '',
        count: int = -1,
    ) -> NDArray[Any]: ...
    # 获取 level2 逐笔委托数据。
    def get_l2_order(
        self,
        field_list: FieldList = [],
        stock_code: StockCode = '',
        start_time: TimeString = '',
        end_time: TimeString = '',
        count: int = -1,
    ) -> NDArray[Any]: ...
    # 获取 level2 逐笔成交数据。
    def get_l2_transaction(
        self,
        field_list: FieldList = [],
        stock_code: StockCode = '',
        start_time: TimeString = '',
        end_time: TimeString = '',
        count: int = -1,
    ) -> NDArray[Any]: ...
    # 获取除权除息因子。
    def get_divid_factors(self, stock_code: StockCode, start_time: TimeString = '', end_time: TimeString = '') -> pd.DataFrame: ...
    # 旧版除权接口，返回字典结果。
    def getDividFactors(self, stock_code: StockCode, date: TimeString) -> dict[str, Any]: ...
    # 获取主力连续合约，区间查询时返回 Series。
    def get_main_contract(self, code_market: StockCode, start_time: TimeString = '', end_time: TimeString = '') -> str | pd.Series: ...
    # 获取次主力连续合约，区间查询时返回 Series。
    def get_sec_main_contract(self, code_market: StockCode, start_time: TimeString = '', end_time: TimeString = '') -> str | pd.Series: ...
    # 日期字符串转毫秒时间戳。
    def datetime_to_timetag(self, datetime: TimeString, format: str = '%Y%m%d%H%M%S') -> int: ...
    # 时间戳转日期字符串。
    def timetag_to_datetime(self, timetag: int, format: str) -> str: ...
    # 兼容旧命名的时间戳转日期字符串。
    def timetagToDateTime(self, timetag: int, format: str) -> str: ...
    # 获取市场交易日列表，返回毫秒时间戳列表。
    def get_trading_dates(self, market: MarketCode, start_time: TimeString = '', end_time: TimeString = '', count: int = -1) -> TradingDateList: ...
    # 获取全推快照，返回 {代码: 数据字典}。
    def get_full_tick(self, code_list: Sequence[str]) -> dict[str, JsonDict]: ...
    # 获取千档委买委卖队列数据。
    def get_l2thousand_queue(self, stock_code: StockCode, gear_num: int | None = None, price: float | tuple[float, float] | list[float] | None = None) -> Any: ...
    # 获取逐笔成交笔数统计。
    def get_transactioncount(self, code_list: Sequence[str]) -> dict[str, Any]: ...
    # 获取极速委托簿。
    def get_fullspeed_orderbook(self, code_list: Sequence[str]) -> dict[str, Any]: ...

    # 板块与基础信息
    # 获取板块列表。
    def get_sector_list(self) -> list[str]: ...
    # 获取板块信息，返回 DataFrame。
    def get_sector_info(self, sector_name: str = '') -> pd.DataFrame: ...
    # 获取合约基础信息，找不到时返回 None。
    def get_instrument_detail(self, stock_code: StockCode, iscomplete: bool = False) -> InstrumentDetail: ...
    # 批量获取合约基础信息。
    def get_instrument_detail_list(self, stock_list: StockList, iscomplete: bool = False) -> list[InstrumentDetail]: ...
    # 下载指数权重数据。
    def download_index_weight(self) -> bool: ...
    # 下载过期/历史合约信息。
    def download_history_contracts(self, incrementally: bool = True) -> bool: ...
    # 下载历史行情数据，同步执行。
    def download_history_data(
        self,
        stock_code: StockCode,
        period: PeriodLike,
        start_time: TimeLike = '',
        end_time: TimeLike = '',
        incrementally: bool | None = None,
    ) -> bool: ...
    # 下载财务数据，同步执行。
    def download_financial_data(
        self,
        stock_list: StockList,
        table_list: Sequence[TableName] = [],
        start_time: TimeString = '',
        end_time: TimeString = '',
        incrementally: bool | None = None,
    ) -> bool: ...
    # 获取合约类型枚举值。
    def get_instrument_type(self, stock_code: StockCode, variety_list: Sequence[int] | None = None) -> int: ...
    # 下载板块分类信息。
    def download_sector_data(self) -> bool: ...
    # 下载节假日数据。
    def download_holiday_data(self, incrementally: bool = True) -> bool: ...
    # 获取节假日列表，元素通常为 YYYYMMDD 字符串。
    def get_holidays(self) -> list[str]: ...
    # 获取市场最近一个交易日。
    def get_market_last_trade_date(self, market: MarketCode) -> str | int: ...
    # 获取交易日历。
    def get_trading_calendar(self, market: MarketCode, start_time: TimeString = '', end_time: TimeString = '') -> CalendarList: ...
    # 判断证券是否属于指定品种标签。
    def is_stock_type(self, stock: StockCode, tag: int) -> bool: ...

    # 债券、期权、ETF 等扩展数据
    # 下载可转债基础信息。
    def download_cb_data(self) -> bool: ...
    # 获取可转债基础信息。
    def get_cb_info(self, stockcode: StockCode) -> JsonDict | None: ...
    # 获取期权基础信息。
    def get_option_detail_data(self, optioncode: StockCode) -> JsonDict | None: ...
    # 获取期权标的基础信息。
    def get_option_undl_data(self, undl_code_ref: StockCode) -> JsonDict | None: ...
    # 获取期权合约列表。
    def get_option_list(self, undl_code: StockCode, dedate: str, opttype: str = '', isavailavle: bool = False) -> list[str]: ...
    # 获取历史期权列表。
    def get_his_option_list(self, undl_code: StockCode, dedate: str) -> list[str]: ...
    # 按时间区间获取历史期权列表。
    def get_his_option_list_batch(self, undl_code: StockCode, start_time: TimeString = '', end_time: TimeString = '') -> dict[str, list[str]]: ...
    # 获取新股申购信息。
    def get_ipo_info(self, start_time: TimeString = '', end_time: TimeString = '') -> pd.DataFrame | JsonDict: ...
    # 获取可用市场列表。
    def get_markets(self) -> list[str] | JsonDict: ...
    # 获取投研版市场列表。
    def get_wp_market_list(self) -> list[str]: ...
    # 获取历史 ST 数据。
    def get_his_st_data(self, stock_code: StockCode) -> pd.DataFrame | JsonDict: ...
    # 获取可用周期列表。
    def get_period_list(self) -> PeriodList: ...
    # 获取公式列表。
    def get_formulas(self) -> list[str] | JsonDict: ...
    # 获取行情服务配置。
    def get_quote_server_config(self) -> JsonDict: ...
    # 获取行情服务状态。
    def get_quote_server_status(self) -> JsonDict: ...
    # 获取 ETF 申赎清单信息。
    def get_etf_info(self) -> JsonDict: ...
    # 下载 ETF 申赎清单信息。
    def download_etf_info(self) -> bool: ...
    # 下载历史 ST 数据。
    def download_his_st_data(self) -> bool: ...
    # 获取港股经纪商字典。
    def get_hk_broker_dict(self) -> dict[str, str]: ...
    # 获取港股 broker queue 数据。
    def get_broker_queue_data(
        self,
        stock_list: StockList = [],
        start_time: TimeString = '',
        end_time: TimeString = '',
        count: int = -1,
        show_broker_name: bool = False,
    ) -> dict[str, pd.DataFrame]: ...
    # 获取最新交易日 K 线全推数据，返回 {字段: DataFrame}。
    def get_full_kline(
        self,
        field_list: FieldList = [],
        stock_list: StockList = [],
        period: PeriodLike = '1m',
        start_time: TimeString = '',
        end_time: TimeString = '',
        count: int = 1,
        dividend_type: DividendType = 'none',
        fill_data: bool = True,
    ) -> FrameDict: ...
    # 下载表格化数据。
    def download_tabular_data(
        self,
        stock_list: StockList,
        period: PeriodLike,
        start_time: TimeString = '',
        end_time: TimeString = '',
        incrementally: bool | None = None,
        download_type: str = 'validationbypage',
        source: str = '',
    ) -> bool: ...
    # 获取可交易合约列表。
    def get_trading_contract_list(self, stockcode: StockCode, date: str | None = None) -> list[str]: ...
    # 获取单个合约的交易时段。
    def get_trading_period(self, stock_code: StockCode) -> TradingPeriodList: ...
    # 获取单个合约 K 线交易时段。
    def get_kline_trading_period(self, stock_code: StockCode) -> TradingPeriodList: ...
    # 获取全部交易时段。
    def get_all_trading_periods(self) -> Mapping[str, TradingPeriodList]: ...
    # 获取全部 K 线交易时段。
    def get_all_kline_trading_periods(self) -> Mapping[str, TradingPeriodList]: ...
    # 获取授权市场列表。
    def get_authorized_market_list(self) -> list[str]: ...
    # 推算未来交易日历。
    def compute_coming_trading_calendar(self, market: MarketCode, start_time: TimeString = '', end_time: TimeString = '') -> CalendarList: ...
    # 获取表格化公式结果。
    def get_tabular_formula(
        self,
        codes: StockList,
        fields: FieldList,
        period: PeriodLike,
        start_time: TimeString,
        end_time: TimeString,
        count: int = -1,
        dividend_type: DividendType = 'none',
        **kwargs: Any,
    ) -> pd.DataFrame: ...
    # 获取可转债转股价信息。
    def bnd_get_conversion_price(self, stock_code: StockCode, start_time: TimeString = '', end_time: TimeString = '') -> pd.DataFrame | JsonDict: ...
    # 获取可转债赎回信息。
    def bnd_get_call_info(self, stock_code: StockCode, start_time: TimeString = '', end_time: TimeString = '') -> pd.DataFrame | JsonDict: ...
    # 获取可转债回售信息。
    def bnd_get_put_info(self, stock_code: StockCode, start_time: TimeString = '', end_time: TimeString = '') -> pd.DataFrame | JsonDict: ...
    # 获取可转债余额变化信息。
    def bnd_get_amount_change(self, stock_code: StockCode, start_time: TimeString = '', end_time: TimeString = '') -> pd.DataFrame | JsonDict: ...
    # 获取表格化行情数据，返回 DataFrame。
    def get_tabular_data(
        self,
        field_list: FieldList = [],
        stock_list: StockList = [],
        period: PeriodLike = '1d',
        start_time: TimeString = '',
        end_time: TimeString = '',
        count: int = -1,
        dividend_type: DividendType = 'none',
        fill_data: bool = True,
    ) -> pd.DataFrame: ...
    # 获取委托排名数据。
    def get_order_rank(
        self,
        code: StockCode,
        order_time: int | str,
        order_type: int | str,
        order_price: float,
        order_volume: int,
        order_left_volume: int,
    ) -> pd.DataFrame: ...
    # 获取当前连接订阅信息。
    def get_current_connect_sub_info(self) -> JsonDict | list[JsonDict]: ...
    # 获取全部订阅信息。
    def get_all_sub_info(self) -> JsonDict | list[JsonDict]: ...
