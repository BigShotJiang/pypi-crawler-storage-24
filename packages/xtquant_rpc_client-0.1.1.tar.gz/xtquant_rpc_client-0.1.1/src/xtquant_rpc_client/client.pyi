from __future__ import annotations

from typing import Any

from .xtdata_stub import XtdataStub


class ConnectionConfig:
    host: str
    port: int
    token: str
    timeout: float


class XtquantRpcClient:
    config: ConnectionConfig
    xtdata: XtdataStub

    def __init__(self, host: str, port: int, token: str, timeout: float = 30.0) -> None: ...
    def close(self) -> None: ...
    def invoke(self, domain: str, method: str, *args: Any, **kwargs: Any) -> Any: ...
