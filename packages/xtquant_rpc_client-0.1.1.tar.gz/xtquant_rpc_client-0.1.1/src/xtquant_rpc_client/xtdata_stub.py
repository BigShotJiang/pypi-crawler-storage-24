from __future__ import annotations

from typing import Any

from .xtdata_methods import SUPPORTED_METHOD_SIGNATURES


class XtdataStub:
    """Client-bound xtdata facade."""

    def __init__(self, rpc_client: Any) -> None:
        self._rpc_client = rpc_client

    def _invoke_method(self, method: str, local_values: dict[str, Any]) -> Any:
        kwargs = dict(local_values)
        kwargs.pop("self", None)
        extra_kwargs = kwargs.pop("kwargs", {})
        kwargs.update(extra_kwargs)
        return self._rpc_client.invoke("xtdata", method, **kwargs)


def _make_method(method: str, signature_text: str):
    namespace: dict[str, Any] = {}
    inner = signature_text[1:-1]
    signature = f"(self, {inner})" if inner else "(self)"
    source = (
        f"def {method}{signature}:\n"
        f"    return self._invoke_method('{method}', locals())\n"
    )
    exec(source, {}, namespace)
    func = namespace[method]
    func.__module__ = __name__
    func.__doc__ = f"Remote xtdata stub for `{method}`."
    return func


for _method_name, _signature_text in SUPPORTED_METHOD_SIGNATURES.items():
    setattr(XtdataStub, _method_name, _make_method(_method_name, _signature_text))

