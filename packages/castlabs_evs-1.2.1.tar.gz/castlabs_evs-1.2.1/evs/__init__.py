# Copyright 2020, castLabs GmbH

__version__ = '1.2.1'
