"""Atom feed generation for foliate."""

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from html import escape
from pathlib import Path
from typing import TYPE_CHECKING

from bs4 import BeautifulSoup

# Re-export FeedConfig from config for convenience
from .config import FeedConfig
from .markdown_utils import render_markdown
from .page import Page
from .page import parse_frontmatter_date as parse_frontmatter_date

if TYPE_CHECKING:
    from jinja2 import Environment

    from .config import Config

__all__ = ["FeedConfig", "FeedItem", "generate_feed"]


@dataclass
class FeedItem:
    """A single item in a feed."""

    title: str
    url: str
    content: str
    published: datetime
    updated: datetime
    summary: str | None = None


def format_atom_date(dt: datetime) -> str:
    """Format datetime as RFC 3339 for Atom.

    Args:
        dt: datetime object (should be in UTC)

    Returns:
        RFC 3339 formatted string like "2024-03-15T10:30:00Z"
    """
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def classify_pages(
    pages: list[Page],
    window_days: int,
    now: datetime | None = None,
) -> tuple[list[Page], list[Page]]:
    """Classify pages into 'new' and 'updated' categories.

    Args:
        pages: List of Page objects
        window_days: Number of days to look back
        now: Current datetime (for testing), defaults to now

    Returns:
        (new_pages, updated_pages) - both sorted by date descending
    """
    if now is None:
        now = datetime.now(timezone.utc)

    window_start = now - timedelta(days=window_days)
    new_pages: list[Page] = []
    updated_pages: list[Page] = []

    for page in pages:
        published = page.published_at
        modified = page.modified_at

        if published is None:
            continue

        # Is the page "new" (published within window)?
        is_new = published >= window_start

        if is_new:
            new_pages.append(page)
        elif modified and modified >= window_start:
            # Page was published before window but modified within
            updated_pages.append(page)
        # else: page is outside window entirely, skip

    # Sort by date descending, then by path ascending for deterministic order
    new_pages.sort(key=lambda p: (-(p.published_at or now).timestamp(), p.path))
    updated_pages.sort(key=lambda p: (-(p.modified_at or now).timestamp(), p.path))

    return new_pages, updated_pages


def extract_summary(html: str, max_length: int = 300) -> str:
    """Extract a plain text summary from HTML.

    Extracts the first paragraph and truncates if needed.

    Args:
        html: HTML content
        max_length: Maximum length of summary

    Returns:
        Plain text summary
    """
    if not html:
        return ""

    soup = BeautifulSoup(html, "html.parser")

    # Find first paragraph
    first_p = soup.find("p")
    if first_p:
        text = first_p.get_text()
    else:
        text = soup.get_text()

    text = text.strip()

    if len(text) > max_length:
        return text[:max_length] + "..."

    return text


def generate_updates_digest(pages: list[Page], site_url: str) -> str:
    """Generate HTML content for the updates digest entry.

    Args:
        pages: List of updated pages
        site_url: Base URL of the site

    Returns:
        HTML string with list of updated pages
    """
    if not pages:
        return ""

    lines = ["<p>The following pages were recently updated:</p>", "<ul>"]

    for page in pages:
        title = escape(page.title)
        url = escape(f"{site_url}{page.url}", quote=True)
        date_str = page.modified_at.strftime("%Y-%m-%d") if page.modified_at else ""

        lines.append(f'  <li><a href="{url}">{title}</a> - {date_str}</li>')

    lines.append("</ul>")
    return "\n".join(lines)


def create_feed_items(
    pages: list[Page],
    site_url: str,
    full_content: bool,
    max_items: int,
) -> list[FeedItem]:
    """Create FeedItem objects from pages.

    Args:
        pages: List of Page objects
        site_url: Base URL of the site
        full_content: Whether to include full content or summary
        max_items: Maximum number of items to include

    Returns:
        List of FeedItem objects
    """
    items: list[FeedItem] = []

    for page in pages[:max_items]:
        published = page.published_at

        if not published:
            continue
        modified = page.modified_at or published

        url = f"{site_url}{page.url}"
        content = page.html
        if not content and page.body:
            content = render_markdown(
                page.body,
                page.base_url or "/wiki/",
            )

        summary = extract_summary(content) if not full_content else None

        item = FeedItem(
            title=page.title,
            url=url,
            content=content if full_content else "",
            published=published,
            updated=modified,
            summary=summary,
        )
        items.append(item)

    return items


def generate_feed(
    pages: list[Page],
    config: "Config",
    templates: "Environment",
    output_dir: Path,
) -> None:
    """Generate Atom feed with new pages and updates digest.

    Args:
        pages: List of published Page objects
        config: Site configuration
        templates: Jinja2 environment
        output_dir: Build output directory
    """
    from . import __version__

    feed_config = config.feed
    if not feed_config.enabled:
        return

    site_url = config.site.url.rstrip("/")
    now = datetime.now(timezone.utc)

    # Filter out homepage content (only include wiki pages)
    wiki_prefix = config.build.wiki_prefix.strip("/")
    wiki_url_prefix = f"/{wiki_prefix}/" if wiki_prefix else "/"

    # Only include pages whose URL starts with wiki prefix
    # This excludes _homepage/ content which goes to /
    wiki_pages = [p for p in pages if p.url.startswith(wiki_url_prefix)]

    # If wiki prefix is empty, we can't distinguish - include all pages
    # Otherwise, only include wiki pages
    if wiki_prefix:
        feed_pages = wiki_pages
    else:
        feed_pages = pages

    # Classify pages
    new_pages, updated_pages = classify_pages(feed_pages, feed_config.window, now)

    # If no pages in either category, remove stale feed and skip generation
    if not new_pages and not updated_pages:
        feed_file = output_dir / "feed.xml"
        if feed_file.exists():
            feed_file.unlink()
        return

    # Create feed items for new pages
    new_items = create_feed_items(
        new_pages,
        site_url,
        feed_config.full_content,
        feed_config.items,
    )

    # Create updates digest entry if there are updated pages
    updates_entry = None
    if updated_pages:
        digest_content = generate_updates_digest(updated_pages, site_url)
        most_recent_update = updated_pages[0].modified_at
        if most_recent_update is not None:
            updates_entry = {
                "content": digest_content,
                "updated": format_atom_date(most_recent_update),
            }

    # Determine feed metadata
    feed_title = feed_config.title or config.site.name
    feed_description = feed_config.description or f"{config.site.name} - Recent updates"

    # Determine feed updated time (most recent of all entries)
    all_dates: list[datetime] = []
    if new_items:
        all_dates.extend(item.updated for item in new_items)
    if updates_entry and updated_pages:
        updated_at = updated_pages[0].modified_at
        if updated_at is not None:
            all_dates.append(updated_at)
    feed_updated = max(all_dates) if all_dates else now

    # Format items for template
    formatted_items = [
        {
            "title": item.title,
            "url": item.url,
            "published": format_atom_date(item.published),
            "updated": format_atom_date(item.updated),
            "content": item.content,
            "summary": item.summary,
        }
        for item in new_items
    ]

    # Render feed template
    try:
        template = templates.get_template("feed.xml")
    except Exception as e:
        from .logging import warning

        warning(f"Failed to load feed template: {e}")
        warning("Feed generation skipped. Ensure feed.xml template exists.")
        return
    wiki_url = f"{site_url}/{wiki_prefix}/" if wiki_prefix else f"{site_url}/"

    feed_xml = template.render(
        config=config,
        feed_title=feed_title,
        feed_description=feed_description,
        feed_updated=format_atom_date(feed_updated),
        new_items=formatted_items,
        updates_entry=updates_entry,
        full_content=feed_config.full_content,
        version=__version__,
        wiki_url=wiki_url,
    )

    # Write feed file
    (output_dir / "feed.xml").write_text(feed_xml, encoding="utf-8")
