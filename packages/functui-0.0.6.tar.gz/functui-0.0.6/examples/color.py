from functui.common import *
from functui.classes import *
from functui.rich_text import adaptive_text, span
from functui import Rect, layout_to_result, result_to_str, Color4
from itertools import batched

def cell_white_text(color8: int):
    return text(f"{color8: >3}") | padding | bg_fill | bg(color8) | fg(Color4.BRIGHT_WHITE)
def cell_black_text(color8: int):
    return text(f"{color8: >3}") | padding | bg_fill | bg(color8) | fg(16)

def display_color_8():
    regular = []
    intense = []
    light_cube = []
    dark_cube = []
    blacks = []
    whites = []
    for i in range(8):
        regular.append(
            cell_white_text(i)
        )
        intense.append(
            cell_black_text(i+8)
        )
    for i in range(16, 232):
        if ((i+2) % 36) < 18:
            light_cube.append(
                cell_black_text(i)
            )
        else:
            dark_cube.append(
                cell_white_text(i)
            )
    for i in range(232, 244):
        blacks.append(
            cell_white_text(i)
        )
        whites.append(
            cell_black_text(i+12)
        )
    return vbox([
        text("Regular and bright colors are rendered differently depending on terminal theme"),
        hbox([text("Regular:  "), *regular]),
        hbox([text("Bright:   "), *intense]),
        text(" "),
        text("Color Cube"),
        *(hbox(row) for row in batched(dark_cube, 6*3)),
        *(hbox(row) for row in batched(light_cube, 6*3)),
        text(" "),
        text("Color ramps, black and white intentionaly excluded"),
        hbox(blacks),
        hbox(whites),
    ])

layout = vbox([
    display_color_8() | shrink,
])
result = layout_to_result(layout, Rect(140, 40))

if __name__ == "__main__":
    print(result_to_str(result))

