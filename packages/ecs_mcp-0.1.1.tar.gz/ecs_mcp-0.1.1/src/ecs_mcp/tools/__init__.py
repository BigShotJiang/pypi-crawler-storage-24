"""Tool registry — import each tool module here to register its @mcp.tool() decorators."""

from ecs_mcp.tools import affinity  # noqa: F401

# To add a new integration, add an import here:
# from ecs_mcp.tools import hubspot  # noqa: F401
