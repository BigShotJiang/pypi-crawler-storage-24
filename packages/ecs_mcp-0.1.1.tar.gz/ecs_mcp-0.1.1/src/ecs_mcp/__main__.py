from ecs_mcp.server import main

main()
