"""ECS MCP Server bootstrap."""

from ecs_mcp import mcp
import ecs_mcp.tools  # noqa: F401 — registers all tool modules as a side effect


def main() -> None:
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
