"""ECS MCP Server — Affinity CRM integration."""

from mcp.server.fastmcp import FastMCP

# Shared FastMCP instance — imported by server.py and all tool modules
mcp = FastMCP("ecs-mcp")
