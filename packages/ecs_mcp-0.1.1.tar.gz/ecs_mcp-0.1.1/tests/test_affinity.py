"""Tests for the Affinity CRM tool."""

import pytest
import httpx
from pytest_httpx import HTTPXMock

from ecs_mcp.tools.affinity import (
    _get_api_key,
    _find_list_by_name,
    _find_organization,
    _create_organization,
    _create_list_entry,
    _find_person_by_email,
    _create_person,
    _create_note,
    create_deal,
    AFFINITY_BASE_URL,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def set_api_key(monkeypatch):
    monkeypatch.setenv("AFFINITY_API_KEY", "test-key")


@pytest.fixture
def async_client():
    return httpx.AsyncClient(base_url=AFFINITY_BASE_URL, auth=("", "test-key"))


# ---------------------------------------------------------------------------
# _get_api_key
# ---------------------------------------------------------------------------

def test_get_api_key_returns_key(monkeypatch):
    monkeypatch.setenv("AFFINITY_API_KEY", "my-secret-key")
    assert _get_api_key() == "my-secret-key"


def test_get_api_key_strips_whitespace(monkeypatch):
    monkeypatch.setenv("AFFINITY_API_KEY", "  my-key  ")
    assert _get_api_key() == "my-key"


def test_get_api_key_raises_when_missing(monkeypatch):
    monkeypatch.delenv("AFFINITY_API_KEY", raising=False)
    with pytest.raises(ValueError, match="AFFINITY_API_KEY"):
        _get_api_key()


def test_get_api_key_raises_when_empty(monkeypatch):
    monkeypatch.setenv("AFFINITY_API_KEY", "   ")
    with pytest.raises(ValueError, match="AFFINITY_API_KEY"):
        _get_api_key()


# ---------------------------------------------------------------------------
# _find_list_by_name
# ---------------------------------------------------------------------------

async def test_find_list_by_name_found(async_client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{AFFINITY_BASE_URL}/lists",
        json=[
            {"id": 1, "name": "Other List"},
            {"id": 42, "name": "ALL DEALS ECS"},
        ],
    )
    result = await _find_list_by_name(async_client, "ALL DEALS ECS")
    assert result == {"id": 42, "name": "ALL DEALS ECS"}


async def test_find_list_by_name_case_insensitive(async_client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{AFFINITY_BASE_URL}/lists",
        json=[{"id": 42, "name": "ALL DEALS ECS"}],
    )
    result = await _find_list_by_name(async_client, "all deals ecs")
    assert result["id"] == 42


async def test_find_list_by_name_not_found(async_client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{AFFINITY_BASE_URL}/lists",
        json=[{"id": 1, "name": "Other List"}],
    )
    result = await _find_list_by_name(async_client, "ALL DEALS ECS")
    assert result is None


async def test_find_list_by_name_empty(async_client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(url=f"{AFFINITY_BASE_URL}/lists", json=[])
    result = await _find_list_by_name(async_client, "ALL DEALS ECS")
    assert result is None


# ---------------------------------------------------------------------------
# _find_organization
# ---------------------------------------------------------------------------

async def test_find_organization_exact_match(async_client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{AFFINITY_BASE_URL}/organizations?term=Acme+Corp",
        json={"organizations": [
            {"id": 10, "name": "Acme Corp"},
            {"id": 11, "name": "Acme Corporation"},
        ]},
    )
    result = await _find_organization(async_client, "Acme Corp")
    assert result["id"] == 10


async def test_find_organization_fuzzy_fallback(async_client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{AFFINITY_BASE_URL}/organizations?term=Acme",
        json={"organizations": [{"id": 11, "name": "Acme Corporation"}]},
    )
    result = await _find_organization(async_client, "Acme")
    assert result["id"] == 11


async def test_find_organization_not_found(async_client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{AFFINITY_BASE_URL}/organizations?term=Unknown+Co",
        json={"organizations": []},
    )
    result = await _find_organization(async_client, "Unknown Co")
    assert result is None


# ---------------------------------------------------------------------------
# _create_organization
# ---------------------------------------------------------------------------

async def test_create_organization_with_domain(async_client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{AFFINITY_BASE_URL}/organizations",
        method="POST",
        json={"id": 99, "name": "Acme Corp", "domain": "acme.com"},
    )
    result = await _create_organization(async_client, "Acme Corp", domain="acme.com")
    assert result["id"] == 99
    request = httpx_mock.get_requests()[0]
    import json
    body = json.loads(request.content)
    assert body["domain"] == "acme.com"


async def test_create_organization_derives_domain(async_client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{AFFINITY_BASE_URL}/organizations",
        method="POST",
        json={"id": 99, "name": "Acme Corp", "domain": "acmecorp.com"},
    )
    await _create_organization(async_client, "Acme Corp")
    request = httpx_mock.get_requests()[0]
    import json
    body = json.loads(request.content)
    assert body["domain"] == "acmecorp.com"


async def test_create_organization_strips_special_chars_from_domain(async_client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{AFFINITY_BASE_URL}/organizations",
        method="POST",
        json={"id": 99, "name": "A & B Co.", "domain": "abco.com"},
    )
    await _create_organization(async_client, "A & B Co.")
    import json
    body = json.loads(httpx_mock.get_requests()[0].content)
    assert body["domain"] == "abco.com"


# ---------------------------------------------------------------------------
# _create_list_entry
# ---------------------------------------------------------------------------

async def test_create_list_entry(async_client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{AFFINITY_BASE_URL}/lists/42/list-entries",
        method="POST",
        json={"id": 500, "list_id": 42, "entity_id": 99},
    )
    result = await _create_list_entry(async_client, list_id=42, entity_id=99)
    assert result["id"] == 500
    import json
    body = json.loads(httpx_mock.get_requests()[0].content)
    assert body == {"entity_id": 99}


# ---------------------------------------------------------------------------
# _find_person_by_email
# ---------------------------------------------------------------------------

async def test_find_person_by_email_found(async_client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{AFFINITY_BASE_URL}/persons?term=jane%40acme.com",
        json={"persons": [
            {"id": 20, "first_name": "Jane", "last_name": "Doe", "emails": ["jane@acme.com"]},
        ]},
    )
    result = await _find_person_by_email(async_client, "jane@acme.com")
    assert result["id"] == 20


async def test_find_person_by_email_case_insensitive(async_client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{AFFINITY_BASE_URL}/persons?term=Jane%40Acme.com",
        json={"persons": [
            {"id": 20, "first_name": "Jane", "emails": ["jane@acme.com"]},
        ]},
    )
    result = await _find_person_by_email(async_client, "Jane@Acme.com")
    assert result["id"] == 20


async def test_find_person_by_email_not_found(async_client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{AFFINITY_BASE_URL}/persons?term=nobody%40acme.com",
        json={"persons": []},
    )
    result = await _find_person_by_email(async_client, "nobody@acme.com")
    assert result is None


async def test_find_person_by_email_no_email_match(async_client, httpx_mock: HTTPXMock):
    # Search returns results but none have the requested email
    httpx_mock.add_response(
        url=f"{AFFINITY_BASE_URL}/persons?term=jane%40acme.com",
        json={"persons": [
            {"id": 20, "first_name": "Jane", "emails": ["jane@other.com"]},
        ]},
    )
    result = await _find_person_by_email(async_client, "jane@acme.com")
    assert result is None


# ---------------------------------------------------------------------------
# _create_person
# ---------------------------------------------------------------------------

async def test_create_person_full_name_and_email(async_client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{AFFINITY_BASE_URL}/persons",
        method="POST",
        json={"id": 30, "first_name": "Jane", "last_name": "Doe"},
    )
    result = await _create_person(async_client, "Jane Doe", "jane@acme.com", org_id=99)
    assert result["id"] == 30
    import json
    body = json.loads(httpx_mock.get_requests()[0].content)
    assert body["first_name"] == "Jane"
    assert body["last_name"] == "Doe"
    assert body["emails"] == ["jane@acme.com"]
    assert body["organization_ids"] == [99]


async def test_create_person_single_name(async_client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{AFFINITY_BASE_URL}/persons",
        method="POST",
        json={"id": 31, "first_name": "Jane", "last_name": ""},
    )
    await _create_person(async_client, "Jane", "", org_id=99)
    import json
    body = json.loads(httpx_mock.get_requests()[0].content)
    assert body["first_name"] == "Jane"
    assert body["last_name"] == ""
    assert "emails" not in body


async def test_create_person_no_email_omits_field(async_client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{AFFINITY_BASE_URL}/persons",
        method="POST",
        json={"id": 32, "first_name": "Bob", "last_name": "Smith"},
    )
    await _create_person(async_client, "Bob Smith", "", org_id=5)
    import json
    body = json.loads(httpx_mock.get_requests()[0].content)
    assert "emails" not in body


# ---------------------------------------------------------------------------
# _create_note
# ---------------------------------------------------------------------------

async def test_create_note_with_person(async_client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{AFFINITY_BASE_URL}/notes",
        method="POST",
        json={"id": 77},
    )
    result = await _create_note(async_client, "Great lead from email", org_id=99, person_id=20)
    assert result["id"] == 77
    import json
    body = json.loads(httpx_mock.get_requests()[0].content)
    assert body["content"] == "Great lead from email"
    assert body["organization_ids"] == [99]
    assert body["person_ids"] == [20]


async def test_create_note_without_person(async_client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{AFFINITY_BASE_URL}/notes",
        method="POST",
        json={"id": 78},
    )
    await _create_note(async_client, "Note content", org_id=99)
    import json
    body = json.loads(httpx_mock.get_requests()[0].content)
    assert "person_ids" not in body


# ---------------------------------------------------------------------------
# create_deal (integration-style, all HTTP mocked)
# ---------------------------------------------------------------------------

def _mock_deal_requests(httpx_mock: HTTPXMock, *, existing_org=False, existing_person=False):
    """Register all Affinity HTTP responses for a create_deal call."""
    httpx_mock.add_response(
        url=f"{AFFINITY_BASE_URL}/lists",
        json=[{"id": 42, "name": "ALL DEALS ECS"}],
    )
    if existing_org:
        httpx_mock.add_response(
            url=f"{AFFINITY_BASE_URL}/organizations?term=Acme+Corp",
            json={"organizations": [{"id": 99, "name": "Acme Corp"}]},
        )
    else:
        httpx_mock.add_response(
            url=f"{AFFINITY_BASE_URL}/organizations?term=Acme+Corp",
            json={"organizations": []},
        )
        httpx_mock.add_response(
            url=f"{AFFINITY_BASE_URL}/organizations",
            method="POST",
            json={"id": 99, "name": "Acme Corp", "domain": "acme.com"},
        )
    httpx_mock.add_response(
        url=f"{AFFINITY_BASE_URL}/lists/42/list-entries",
        method="POST",
        json={"id": 500},
    )
    if existing_person:
        httpx_mock.add_response(
            url=f"{AFFINITY_BASE_URL}/persons?term=jane%40acme.com",
            json={"persons": [{"id": 20, "first_name": "Jane", "last_name": "Doe", "emails": ["jane@acme.com"]}]},
        )
    else:
        httpx_mock.add_response(
            url=f"{AFFINITY_BASE_URL}/persons?term=jane%40acme.com",
            json={"persons": []},
        )
        httpx_mock.add_response(
            url=f"{AFFINITY_BASE_URL}/persons",
            method="POST",
            json={"id": 30, "first_name": "Jane", "last_name": "Doe"},
        )
    httpx_mock.add_response(
        url=f"{AFFINITY_BASE_URL}/notes",
        method="POST",
        json={"id": 77},
    )


async def test_create_deal_minimal(httpx_mock: HTTPXMock):
    httpx_mock.add_response(url=f"{AFFINITY_BASE_URL}/lists", json=[{"id": 42, "name": "ALL DEALS ECS"}])
    httpx_mock.add_response(url=f"{AFFINITY_BASE_URL}/organizations?term=Acme+Corp", json={"organizations": []})
    httpx_mock.add_response(url=f"{AFFINITY_BASE_URL}/organizations", method="POST", json={"id": 99, "name": "Acme Corp", "domain": "acmecorp.com"})
    httpx_mock.add_response(url=f"{AFFINITY_BASE_URL}/lists/42/list-entries", method="POST", json={"id": 500})

    result = await create_deal(list_name="ALL DEALS ECS", organization_name="Acme Corp")

    assert "Successfully added" in result
    assert "Acme Corp" in result
    assert "ALL DEALS ECS" in result
    assert "created new organization" in result


async def test_create_deal_existing_org_reused(httpx_mock: HTTPXMock):
    httpx_mock.add_response(url=f"{AFFINITY_BASE_URL}/lists", json=[{"id": 42, "name": "ALL DEALS ECS"}])
    httpx_mock.add_response(
        url=f"{AFFINITY_BASE_URL}/organizations?term=Acme+Corp",
        json={"organizations": [{"id": 99, "name": "Acme Corp"}]},
    )
    httpx_mock.add_response(url=f"{AFFINITY_BASE_URL}/lists/42/list-entries", method="POST", json={"id": 500})

    result = await create_deal(list_name="ALL DEALS ECS", organization_name="Acme Corp")

    assert "found existing organization" in result
    # POST /organizations should NOT have been called
    post_org_calls = [r for r in httpx_mock.get_requests() if r.method == "POST" and "/organizations" in str(r.url)]
    assert len(post_org_calls) == 0


async def test_create_deal_list_not_found(httpx_mock: HTTPXMock):
    httpx_mock.add_response(url=f"{AFFINITY_BASE_URL}/lists", json=[{"id": 1, "name": "Other List"}])

    result = await create_deal(list_name="ALL DEALS ECS", organization_name="Acme Corp")

    assert "Error" in result
    assert "ALL DEALS ECS" in result


async def test_create_deal_full_details_new_everything(httpx_mock: HTTPXMock):
    _mock_deal_requests(httpx_mock, existing_org=False, existing_person=False)

    result = await create_deal(
        list_name="ALL DEALS ECS",
        organization_name="Acme Corp",
        domain="acme.com",
        contact_name="Jane Doe",
        contact_email="jane@acme.com",
        note="Met at conference, interested in our platform",
    )

    assert "Successfully added" in result
    assert "created new organization" in result
    assert "created new contact 'Jane Doe'" in result
    assert "note added" in result


async def test_create_deal_existing_contact_reused(httpx_mock: HTTPXMock):
    _mock_deal_requests(httpx_mock, existing_org=False, existing_person=True)

    result = await create_deal(
        list_name="ALL DEALS ECS",
        organization_name="Acme Corp",
        contact_name="Jane Doe",
        contact_email="jane@acme.com",
        note="Follow-up opportunity",
    )

    assert "found existing contact" in result
    # POST /persons should NOT have been called
    post_person_calls = [r for r in httpx_mock.get_requests() if r.method == "POST" and "/persons" in str(r.url)]
    assert len(post_person_calls) == 0


async def test_create_deal_note_truncated_in_status(httpx_mock: HTTPXMock):
    httpx_mock.add_response(url=f"{AFFINITY_BASE_URL}/lists", json=[{"id": 42, "name": "ALL DEALS ECS"}])
    httpx_mock.add_response(url=f"{AFFINITY_BASE_URL}/organizations?term=Acme+Corp", json={"organizations": [{"id": 99, "name": "Acme Corp"}]})
    httpx_mock.add_response(url=f"{AFFINITY_BASE_URL}/lists/42/list-entries", method="POST", json={"id": 500})
    httpx_mock.add_response(url=f"{AFFINITY_BASE_URL}/notes", method="POST", json={"id": 77})

    long_note = "A" * 200
    result = await create_deal(list_name="ALL DEALS ECS", organization_name="Acme Corp", note=long_note)

    assert "..." in result  # truncated in status line
    # But full note was sent to Affinity
    import json
    note_request = next(r for r in httpx_mock.get_requests() if r.method == "POST" and "/notes" in str(r.url))
    assert json.loads(note_request.content)["content"] == long_note


async def test_create_deal_no_contact_skips_person_and_note(httpx_mock: HTTPXMock):
    httpx_mock.add_response(url=f"{AFFINITY_BASE_URL}/lists", json=[{"id": 42, "name": "ALL DEALS ECS"}])
    httpx_mock.add_response(url=f"{AFFINITY_BASE_URL}/organizations?term=Acme+Corp", json={"organizations": []})
    httpx_mock.add_response(url=f"{AFFINITY_BASE_URL}/organizations", method="POST", json={"id": 99, "name": "Acme Corp", "domain": "acmecorp.com"})
    httpx_mock.add_response(url=f"{AFFINITY_BASE_URL}/lists/42/list-entries", method="POST", json={"id": 500})

    result = await create_deal(list_name="ALL DEALS ECS", organization_name="Acme Corp")

    assert "Contact" not in result
    assert "Note" not in result
    person_calls = [r for r in httpx_mock.get_requests() if "/persons" in str(r.url)]
    note_calls = [r for r in httpx_mock.get_requests() if "/notes" in str(r.url)]
    assert len(person_calls) == 0
    assert len(note_calls) == 0


async def test_create_deal_missing_api_key_raises(monkeypatch):
    monkeypatch.delenv("AFFINITY_API_KEY", raising=False)
    with pytest.raises(ValueError, match="AFFINITY_API_KEY"):
        await create_deal(list_name="ALL DEALS ECS", organization_name="Acme Corp")
