"""AST helper utilities for ESTree nodes."""

import copy
import re


def deep_copy(node):
    """Deep copy an AST node."""
    return copy.deepcopy(node)


def is_literal(node):
    """Check if node is a Literal."""
    return isinstance(node, dict) and node.get('type') == 'Literal'


def is_identifier(node):
    """Check if node is an Identifier."""
    return isinstance(node, dict) and node.get('type') == 'Identifier'


def is_string_literal(node):
    """Check if node is a string Literal."""
    return is_literal(node) and isinstance(node.get('value'), str)


def is_numeric_literal(node):
    """Check if node is a numeric Literal."""
    return is_literal(node) and isinstance(node.get('value'), (int, float))


def is_boolean_literal(node):
    """Check if node is a boolean-ish literal (true/false or !0/!1)."""
    return is_literal(node) and isinstance(node.get('value'), bool)


def is_null_literal(node):
    """Check if node is null literal."""
    return is_literal(node) and node.get('value') is None and node.get('raw') == 'null'


def is_undefined(node):
    """Check if node represents undefined (identifier or ``void 0``)."""
    if is_identifier(node) and node.get('name') == 'undefined':
        return True
    if (
        isinstance(node, dict)
        and node.get('type') == 'UnaryExpression'
        and node.get('operator') == 'void'
        and isinstance(node.get('argument'), dict)
        and node['argument'].get('type') == 'Literal'
        and node['argument'].get('value') == 0
    ):
        return True
    return False


def get_literal_value(node):
    """Extract the value from a literal node. Returns (value, True) or (None, False)."""
    if not is_literal(node):
        return None, False
    return node.get('value'), True


def make_literal(value, raw=None):
    """Create a Literal AST node."""
    if raw is not None:
        return {'type': 'Literal', 'value': value, 'raw': raw}

    match value:
        case str():
            escaped = value.replace('\\', '\\\\')
            escaped = escaped.replace('"', '\\"')
            escaped = escaped.replace('\n', '\\n')
            escaped = escaped.replace('\r', '\\r')
            escaped = escaped.replace('\t', '\\t')
            escaped = escaped.replace('\0', '\\0')
            raw = f'"{escaped}"'
        case bool():
            raw = 'true' if value else 'false'
        case int() | float():
            if isinstance(value, float) and value == int(value) and not (value == 0 and str(value).startswith('-')):
                raw = str(int(value))
            else:
                raw = str(value)
        case None:
            raw = 'null'
        case _:
            raw = str(value)
    return {'type': 'Literal', 'value': value, 'raw': raw}


def make_identifier(name):
    """Create an Identifier AST node."""
    return {'type': 'Identifier', 'name': name}


def make_expression_statement(expr):
    """Wrap an expression in an ExpressionStatement."""
    return {'type': 'ExpressionStatement', 'expression': expr}


def make_block_statement(body):
    """Create a BlockStatement."""
    return {'type': 'BlockStatement', 'body': body}


def make_var_declaration(name, init=None, kind='var'):
    """Create a VariableDeclaration with a single declarator."""
    return {
        'type': 'VariableDeclaration',
        'declarations': [{'type': 'VariableDeclarator', 'id': make_identifier(name), 'init': init}],
        'kind': kind,
    }


_IDENT_RE = re.compile(r'^[a-zA-Z_$][a-zA-Z0-9_$]*$')


def is_valid_identifier(name):
    """Check if a string is a valid JS identifier (for obj.prop access)."""
    if not isinstance(name, str) or not name:
        return False
    return bool(_IDENT_RE.match(name))


_CHILD_KEYS = {
    'Program': ('body',),
    'ExpressionStatement': ('expression',),
    'BlockStatement': ('body',),
    'VariableDeclaration': ('declarations',),
    'VariableDeclarator': ('id', 'init'),
    'FunctionDeclaration': ('id', 'params', 'body'),
    'FunctionExpression': ('id', 'params', 'body'),
    'ArrowFunctionExpression': ('params', 'body'),
    'ReturnStatement': ('argument',),
    'IfStatement': ('test', 'consequent', 'alternate'),
    'WhileStatement': ('test', 'body'),
    'DoWhileStatement': ('test', 'body'),
    'ForStatement': ('init', 'test', 'update', 'body'),
    'ForInStatement': ('left', 'right', 'body'),
    'ForOfStatement': ('left', 'right', 'body'),
    'SwitchStatement': ('discriminant', 'cases'),
    'SwitchCase': ('test', 'consequent'),
    'BreakStatement': ('label',),
    'ContinueStatement': ('label',),
    'LabeledStatement': ('label', 'body'),
    'ThrowStatement': ('argument',),
    'TryStatement': ('block', 'handler', 'finalizer'),
    'CatchClause': ('param', 'body'),
    'BinaryExpression': ('left', 'right'),
    'LogicalExpression': ('left', 'right'),
    'UnaryExpression': ('argument',),
    'UpdateExpression': ('argument',),
    'AssignmentExpression': ('left', 'right'),
    'MemberExpression': ('object', 'property'),
    'CallExpression': ('callee', 'arguments'),
    'NewExpression': ('callee', 'arguments'),
    'ConditionalExpression': ('test', 'consequent', 'alternate'),
    'SequenceExpression': ('expressions',),
    'ArrayExpression': ('elements',),
    'ObjectExpression': ('properties',),
    'Property': ('key', 'value'),
    'SpreadElement': ('argument',),
    'TemplateLiteral': ('quasis', 'expressions'),
    'TaggedTemplateExpression': ('tag', 'quasi'),
    'TemplateElement': (),
    'AssignmentPattern': ('left', 'right'),
    'ArrayPattern': ('elements',),
    'ObjectPattern': ('properties',),
    'RestElement': ('argument',),
    'ClassDeclaration': ('id', 'superClass', 'body'),
    'ClassExpression': ('id', 'superClass', 'body'),
    'ClassBody': ('body',),
    'MethodDefinition': ('key', 'value'),
    'YieldExpression': ('argument',),
    'AwaitExpression': ('argument',),
    'EmptyStatement': (),
    'Literal': (),
    'Identifier': (),
    'ThisExpression': (),
}

_SKIP_KEYS = frozenset(
    (
        'type',
        'raw',
        'value',
        'name',
        'operator',
        'kind',
        'computed',
        'method',
        'shorthand',
        'prefix',
        'async',
        'generator',
        'static',
        'sourceType',
        'start',
        'end',
        'loc',
        'range',
        'directive',
        'regex',
    )
)


def get_child_keys(node):
    """Get keys of a node that may contain child nodes/arrays."""
    if not isinstance(node, dict) or 'type' not in node:
        return ()
    node_type = node['type']
    keys = _CHILD_KEYS.get(node_type)
    if keys is not None:
        return keys
    # Fallback: return all keys that look like they might contain nodes
    return [
        k
        for k, v in node.items()
        if k not in _SKIP_KEYS
        and not (k == 'expression' and node_type != 'ExpressionStatement')
        and isinstance(v, (dict, list))
    ]


def replace_identifiers(node, param_map):
    """Replace Identifier nodes whose names are in param_map with deep copies.

    Skips non-computed property names in MemberExpressions.
    """
    if not isinstance(node, dict) or 'type' not in node:
        return
    for key in get_child_keys(node):
        child = node.get(key)
        if child is None:
            continue
        is_noncomputed_prop = key == 'property' and node.get('type') == 'MemberExpression' and not node.get('computed')
        if isinstance(child, list):
            for i, item in enumerate(child):
                if isinstance(item, dict) and item.get('type') == 'Identifier':
                    if not is_noncomputed_prop and item.get('name', '') in param_map:
                        child[i] = copy.deepcopy(param_map[item['name']])
                elif isinstance(item, dict) and 'type' in item:
                    replace_identifiers(item, param_map)
        elif isinstance(child, dict):
            if child.get('type') == 'Identifier':
                if not is_noncomputed_prop and child.get('name', '') in param_map:
                    node[key] = copy.deepcopy(param_map[child['name']])
            elif 'type' in child:
                replace_identifiers(child, param_map)


def identifiers_match(a, b):
    """Check if two nodes are the same identifier."""
    return is_identifier(a) and is_identifier(b) and a.get('name') == b.get('name')


def is_side_effect_free(node):
    """Check if an expression node is side-effect-free (safe to discard)."""
    if not isinstance(node, dict):
        return False
    match node.get('type'):
        case 'Literal' | 'Identifier':
            return True
        case 'MemberExpression':
            return is_side_effect_free(node.get('object')) and (
                not node.get('computed') or is_side_effect_free(node.get('property'))
            )
        case 'UnaryExpression':
            if node.get('operator') in ('-', '+', '!', '~', 'typeof', 'void'):
                return is_side_effect_free(node.get('argument'))
        case 'BinaryExpression' | 'LogicalExpression':
            return is_side_effect_free(node.get('left')) and is_side_effect_free(node.get('right'))
        case 'ConditionalExpression':
            return (
                is_side_effect_free(node.get('test'))
                and is_side_effect_free(node.get('consequent'))
                and is_side_effect_free(node.get('alternate'))
            )
        case 'ArrayExpression':
            return all(is_side_effect_free(el) for el in (node.get('elements') or []) if el)
        case 'ObjectExpression':
            return all(is_side_effect_free(prop.get('value')) for prop in (node.get('properties') or []))
        case 'TemplateLiteral':
            return all(is_side_effect_free(expr) for expr in (node.get('expressions') or []))
    return False


def get_member_names(node):
    """Extract (object_name, property_name) from a MemberExpression.

    Handles both computed (obj["prop"]) and non-computed (obj.prop) forms.
    Returns (str, str) or (None, None).
    """
    if not node or node.get('type') != 'MemberExpression':
        return None, None
    obj = node.get('object')
    prop = node.get('property')
    if not obj or not is_identifier(obj):
        return None, None
    if not prop:
        return None, None
    if node.get('computed'):
        if is_string_literal(prop):
            return obj['name'], prop['value']
        return None, None
    if is_identifier(prop):
        return obj['name'], prop['name']
    return None, None


def nodes_equal(a, b):
    """Check if two AST nodes are structurally equal (ignoring position info)."""
    if type(a) != type(b):
        return False
    match a:
        case dict():
            keys_a = {k for k in a if k not in ('start', 'end', 'loc', 'range')}
            keys_b = {k for k in b if k not in ('start', 'end', 'loc', 'range')}
            if keys_a != keys_b:
                return False
            return all(nodes_equal(a[k], b[k]) for k in keys_a)
        case list():
            return len(a) == len(b) and all(nodes_equal(x, y) for x, y in zip(a, b))
    return a == b
