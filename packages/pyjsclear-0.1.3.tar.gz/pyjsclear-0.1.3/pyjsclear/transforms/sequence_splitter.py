"""Split sequence expressions into individual statements.

Converts: (a(), b(), c()) in statement position → a(); b(); c();
Also splits multi-declarator var statements: var a = 1, b = 2 → var a = 1; var b = 2;
Also normalizes loop/if bodies to block statements.
"""

from ..traverser import traverse
from ..utils.ast_helpers import make_block_statement
from ..utils.ast_helpers import make_expression_statement
from .base import Transform


class SequenceSplitter(Transform):
    """Split sequence expressions and normalize control flow bodies."""

    def execute(self):
        self._normalize_bodies(self.ast)
        self._split_in_body_arrays(self.ast)
        return self.has_changed()

    def _normalize_bodies(self, ast):
        """Ensure if/while/for bodies are BlockStatements."""

        def enter(node, parent, key, index):
            node_type = node.get('type', '')
            if node_type not in (
                'IfStatement',
                'WhileStatement',
                'DoWhileStatement',
                'ForStatement',
                'ForInStatement',
                'ForOfStatement',
            ):
                return
            body = node.get('body')
            if body and body.get('type') != 'BlockStatement':
                node['body'] = make_block_statement([body])
                self.set_changed()
            if node_type == 'IfStatement':
                self._normalize_if_branches(node)

        traverse(ast, {'enter': enter})

    def _normalize_if_branches(self, node):
        """Wrap non-block consequent/alternate of IfStatement in BlockStatements."""
        consequent = node.get('consequent')
        if consequent and consequent.get('type') != 'BlockStatement':
            node['consequent'] = make_block_statement([consequent])
            self.set_changed()
        alternate = node.get('alternate')
        if alternate and alternate.get('type') not in ('BlockStatement', 'IfStatement', None):
            node['alternate'] = make_block_statement([alternate])
            self.set_changed()

    def _split_in_body_arrays(self, node):
        """Find all arrays that contain statements and split sequences + var decls in them."""
        if not isinstance(node, dict):
            return
        for key, child in node.items():
            if isinstance(child, list):
                # Check if this looks like a statement array
                if child and isinstance(child[0], dict) and 'type' in child[0]:
                    self._process_stmt_array(child)
                    # Recurse into items
                    for item in child:
                        self._split_in_body_arrays(item)
            elif isinstance(child, dict) and 'type' in child:
                self._split_in_body_arrays(child)

    def _extract_indirect_call_prefixes(self, stmt):
        """Extract dead prefix expressions from (0, fn)(args) patterns.

        Only extracts from:
        - Direct expression of ExpressionStatement
        - Direct init of VariableDeclarator
        - Argument of AwaitExpression in those positions
        - Argument of ReturnStatement
        """
        prefixes = []

        def extract_from_call(node):
            """If node is a CallExpression with SequenceExpression callee, extract prefixes."""
            if not isinstance(node, dict):
                return
            target = node
            if target.get('type') == 'AwaitExpression' and isinstance(target.get('argument'), dict):
                target = target['argument']
            if target.get('type') != 'CallExpression':
                return
            callee = target.get('callee')
            if not isinstance(callee, dict) or callee.get('type') != 'SequenceExpression':
                return
            exprs = callee.get('expressions', [])
            if len(exprs) <= 1:
                return
            prefixes.extend(exprs[:-1])
            target['callee'] = exprs[-1]

        stype = stmt.get('type', '')
        if stype == 'ExpressionStatement':
            extract_from_call(stmt.get('expression'))
        elif stype == 'VariableDeclaration':
            for d in stmt.get('declarations', []):
                extract_from_call(d.get('init'))
        elif stype == 'ReturnStatement':
            extract_from_call(stmt.get('argument'))
        # Also check assignment expressions in ExpressionStatements:
        # x = (0, fn)(args)
        if stype == 'ExpressionStatement':
            expr = stmt.get('expression')
            if isinstance(expr, dict) and expr.get('type') == 'AssignmentExpression':
                extract_from_call(expr.get('right'))

        return prefixes

    def _process_stmt_array(self, statements):
        """Split sequence expressions and multi-var declarations in a statement array."""
        i = 0
        while i < len(statements):
            statement = statements[i]
            if not isinstance(statement, dict):
                i += 1
                continue

            # Extract dead prefix from indirect call patterns: (0, fn)(args) → 0; fn(args);
            prefixes = self._extract_indirect_call_prefixes(statement)
            if prefixes:
                new_stmts = [make_expression_statement(expression) for expression in prefixes]
                new_stmts.append(statement)
                statements[i : i + 1] = new_stmts
                i += len(new_stmts)
                self.set_changed()
                continue

            # Split SequenceExpression in ExpressionStatement
            if (
                statement.get('type') == 'ExpressionStatement'
                and isinstance(statement.get('expression'), dict)
                and statement['expression'].get('type') == 'SequenceExpression'
            ):
                expressions = statement['expression'].get('expressions', [])
                if len(expressions) > 1:
                    new_stmts = [make_expression_statement(expression) for expression in expressions]
                    statements[i : i + 1] = new_stmts
                    i += len(new_stmts)
                    self.set_changed()
                    continue

            # Split multi-declarator VariableDeclaration
            # (but not inside for-loop init — those aren't in body arrays)
            if statement.get('type') == 'VariableDeclaration':
                decls = statement.get('declarations', [])
                if len(decls) > 1:
                    kind = statement.get('kind', 'var')
                    new_stmts = [
                        {
                            'type': 'VariableDeclaration',
                            'kind': kind,
                            'declarations': [declaration],
                        }
                        for declaration in decls
                    ]
                    statements[i : i + 1] = new_stmts
                    i += len(new_stmts)
                    self.set_changed()
                    continue

                # Split SequenceExpression in single declarator init
                if len(decls) == 1:
                    split_result = self._try_split_single_declarator_init(statement, decls[0])
                    if split_result:
                        statements[i : i + 1] = split_result
                        i += len(split_result)
                        self.set_changed()
                        continue

            i += 1

    @staticmethod
    def _try_split_single_declarator_init(stmt, declarator):
        """Split SequenceExpression from a single VariableDeclarator init.

        Handles both direct sequences and sequences inside AwaitExpression.
        Returns a list of replacement statements, or None.
        """
        init = declarator.get('init')
        if not isinstance(init, dict):
            return None

        # Direct: const x = (a, b, expr()) → a; b; const x = expr();
        if init.get('type') == 'SequenceExpression':
            exprs = init.get('expressions', [])
            if len(exprs) <= 1:
                return None
            prefix = [make_expression_statement(e) for e in exprs[:-1]]
            declarator['init'] = exprs[-1]
            prefix.append(stmt)
            return prefix

        # Await-wrapped: var x = await (a, b, expr()) → a; b; var x = await expr();
        if (
            init.get('type') == 'AwaitExpression'
            and isinstance(init.get('argument'), dict)
            and init['argument'].get('type') == 'SequenceExpression'
        ):
            exprs = init['argument'].get('expressions', [])
            if len(exprs) <= 1:
                return None
            prefix = [make_expression_statement(e) for e in exprs[:-1]]
            init['argument'] = exprs[-1]
            prefix.append(stmt)
            return prefix

        return None
