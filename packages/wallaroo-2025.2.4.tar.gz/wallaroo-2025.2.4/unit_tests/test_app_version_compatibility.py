#!/usr/bin/env python3
"""
Integration test for AppVersion backward compatibility fix.
This test works with the Literal-based validation function approach.
"""

import sys
import os
import json

def test_app_version_backward_compatibility():
    """Test that AppVersion handles unknown versions gracefully."""
    
    # Direct import to avoid the graphql conflict
    sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
    
    from wallaroo.wallaroo_ml_ops_api_client.models.app_version import check_app_version
    
    print("Testing AppVersion backward compatibility...")
    
    # Test 1: Known versions work normally
    known_version = check_app_version("2025.2.0")
    print(f"✓ Known version created: '{known_version}'")
    assert known_version == "2025.2.0"
    
    # Test 2: Unknown versions are accepted (the main fix)
    future_version = check_app_version("2030.5.0")
    print(f"✓ Future version accepted: '{future_version}'")
    assert future_version == "2030.5.0"
    
    # Test 3: The original failing version works (this was the bug!)
    original_failing = check_app_version("2025.2.0")
    print(f"✓ Original failing version now works: '{original_failing}'")
    assert original_failing == "2025.2.0"
    
    # Test 4: String comparison works
    version = check_app_version("2025.1.0")
    assert version == "2025.1.0"
    print("✓ String comparison works correctly")
    
    # Test 5: JSON serialization works (critical for API responses)
    version = check_app_version("2028.1.0")  # Unknown version
    # Test how it serializes (this is what the API client will do)
    serialized = json.dumps(version)
    print(f"✓ JSON serialization works: {serialized}")
    assert "2028.1.0" in serialized
    
    # Test 6: Function-like behavior preserved
    version = check_app_version("2029.1.0")
    # Check that it returns a string
    assert isinstance(version, str)
    print("✓ Function validation behavior preserved")

def test_other_types_remain_strict():
    """Verify that other enums remain as proper enum classes (important control test)."""
    
    # Import another enum to test that our fix is surgical - only AppVersion was converted to Literal
    from wallaroo.wallaroo_ml_ops_api_client.models.bin_mode_type_0 import BinModeType0
    from wallaroo.wallaroo_ml_ops_api_client.models.interval_unit import IntervalUnit
    
    print("\nTesting that other enums remain as proper enum classes...")
    
    # Test 1: Enum classes still have their values as attributes
    assert BinModeType0.NONE == "None"
    print(f"✓ BinModeType0.NONE attribute access works: '{BinModeType0.NONE}'")
    
    # Test 2: IntervalUnit enum also works with attribute access
    assert IntervalUnit.MINUTE == "Minute"
    assert IntervalUnit.HOUR == "Hour"
    print(f"✓ IntervalUnit enum attribute access works: {IntervalUnit.MINUTE}, {IntervalUnit.HOUR}")
    
    # Test 3: Enum constructor validation - should reject unknown values
    import pytest
    with pytest.raises(ValueError):
        BinModeType0("totally_unknown_value")
    print("✓ BinModeType0 correctly rejects unknown values: ValueError")
    
    # Test 4: Known values work with enum constructor
    none_value = BinModeType0("None")
    assert none_value == BinModeType0.NONE
    print(f"✓ BinModeType0 constructor works with known values: '{none_value}'")
    
    print("✓ Other enums correctly preserved as proper enum classes!")

def simulate_api_response_parsing():
    """Simulate parsing an API response that contains AppVersion fields."""
    
    from wallaroo.wallaroo_ml_ops_api_client.models.app_version import check_app_version
    
    print("\nTesting realistic API response parsing scenario...")
    
    # Simulate JSON data that might come from a newer server
    api_response_data = {
        "model_version": {
            "name": "my-model",
            "created_on_version": "2025.2.0"  # This was the original failing version
        },
        "pipeline_version": {
            "name": "my-pipeline", 
            "created_on_version": "2030.1.0"  # Future version
        }
    }
    
    try:
        # Parse the versions like the SDK would when deserializing responses
        model_version = check_app_version(api_response_data["model_version"]["created_on_version"])
        pipeline_version = check_app_version(api_response_data["pipeline_version"]["created_on_version"])
        
        print(f"✓ Parsed model version: '{model_version}'")
        print(f"✓ Parsed pipeline version: '{pipeline_version}'")
        
        # Verify they work correctly with the key operations
        assert model_version == "2025.2.0"  # This equality check is critical
        assert pipeline_version == "2030.1.0"
        
        print("✓ Realistic API response parsing works!")
        return True
        
    except Exception as e:
        print(f"✗ API response parsing failed: {e}")
        return False

def main():
    """Run all compatibility tests."""
    print("=" * 60)
    print("APPVERSION BACKWARD COMPATIBILITY INTEGRATION TEST")
    print("=" * 60)
    
    success_count = 0
    total_tests = 0
    
    # Test 1: Core backward compatibility (wrap for standalone mode)
    total_tests += 1
    try:
        test_app_version_backward_compatibility()
        success_count += 1
        print("🎉 AppVersion backward compatibility: PASSED")
    except Exception as e:
        print(f"❌ AppVersion backward compatibility: FAILED - {e}")
    
    # Test 2: Other enums remain as proper enum classes (wrap for standalone mode)
    total_tests += 1
    try:
        test_other_types_remain_strict()
        success_count += 1
        print("🎉 Other enums remain as proper enum classes: PASSED")
    except Exception as e:
        print(f"❌ Other enums remain as proper enum classes: FAILED - {e}")
    
    # Test 3: Realistic scenario
    total_tests += 1
    if simulate_api_response_parsing():
        success_count += 1
        print("🎉 API response parsing simulation: PASSED")
    else:
        print("❌ API response parsing simulation: FAILED")
    
    print("\n" + "=" * 60)
    print(f"RESULTS: {success_count}/{total_tests} tests passed")
    
    if success_count == total_tests:
        print("\n🎉 ALL TESTS PASSED!")
        print("\nSUMMARY OF WHAT WORKS:")
        print("✓ Old SDKs can now handle newer server AppVersion values")
        print("✓ Known AppVersion values work exactly as before") 
        print("✓ Unknown AppVersion values are gracefully accepted")
        print("✓ Other enums maintain proper enum class structure (surgical fix)")
        print("✓ Real-world API response parsing scenarios work")
        print("✓ The original '2025.2.0' is not a valid AppVersion error is FIXED")
        print("\nThe backward compatibility solution is COMPLETE! 🚀")
        return 0
    else:
        print(f"\n❌ {total_tests - success_count} test(s) failed")
        return 1

if __name__ == "__main__":
    sys.exit(main())