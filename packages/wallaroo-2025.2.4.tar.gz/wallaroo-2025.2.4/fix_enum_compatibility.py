#!/usr/bin/env python3
"""
Post-generation script to selectively convert AppVersion to Literal type for backward compatibility.

This script converts ONLY the AppVersion enum from a traditional enum class to a typing.Literal type,
allowing unknown AppVersion values to be accepted gracefully for backward compatibility when
older SDKs encounter newer server AppVersion values.

All other enums (IntervalUnit, Aggregation, Metric, etc.) remain as proper enum classes to maintain
test compatibility and proper attribute access patterns.

Additionally, this script fixes all files that try to instantiate AppVersion directly by replacing
those calls with the backward-compatible check_app_version function.
"""

import re
import sys
from pathlib import Path


def convert_app_version_to_literal():
    """Convert AppVersion enum class to Literal type for backward compatibility."""
    
    app_version_file = Path(__file__).parent / "wallaroo" / "wallaroo_ml_ops_api_client" / "models" / "app_version.py"
    
    if not app_version_file.exists():
        print(f"❌ app_version.py not found: {app_version_file}", file=sys.stderr)
        return False
    
    with open(app_version_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Extract enum values from the class definition
    # Look for lines like: VALUE_0 = "2024.1.0"
    value_pattern = r'^\s*VALUE_\d+ = "([^"]+)"'
    values = []
    for line in content.split('\n'):
        match = re.match(value_pattern, line)
        if match:
            values.append(match.group(1))
    
    if not values:
        print(f"❌ Could not extract enum values from AppVersion", file=sys.stderr)
        return False
    
    # Create Literal type definition
    literal_values = [f'"{value}"' for value in values]
    literal_type = f"Literal[{', '.join(literal_values)}]"
    
    # Create new file content with Literal type
    new_content = '''from typing import Literal, cast

"""Contains the definition for the AppVersion"""


AppVersion = ''' + literal_type + '''


def check_app_version(value: str) -> AppVersion:
    """Check if the provided value is a valid AppVersion.
    
    For backward compatibility, accepts any string value to allow
    older SDKs to work with newer server versions.
    """
    # Accept any string value for backward compatibility
    return cast(AppVersion, value)


def to_dict(obj) -> dict:
    """Get a dict representation of an object"""
    return obj
'''
    
    with open(app_version_file, 'w', encoding='utf-8') as f:
        f.write(new_content)
    
    print(f"✅ Successfully converted AppVersion to Literal type with values: {values}")
    return True


def fix_app_version_instantiations():
    """Fix all files that try to instantiate AppVersion directly."""
    
    models_dir = Path(__file__).parent / "wallaroo" / "wallaroo_ml_ops_api_client" / "models"
    
    # Find all Python files that contain AppVersion instantiation
    files_to_fix = []
    for py_file in models_dir.glob("*.py"):
        if py_file.name == "app_version.py":
            continue  # Skip the AppVersion definition file
            
        with open(py_file, 'r', encoding='utf-8') as f:
            content = f.read()
            
        if 'AppVersion(' in content:
            files_to_fix.append(py_file)
    
    print(f"🔍 Found {len(files_to_fix)} files with AppVersion instantiations to fix")
    
    for file_path in files_to_fix:
        fix_file_app_version_calls(file_path)
    
    return len(files_to_fix) > 0


def fix_file_app_version_calls(file_path):
    """Fix AppVersion instantiation calls in a specific file."""
    
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Check if the file imports AppVersion 
    if 'from ..models.app_version import AppVersion' not in content:
        print(f"⚠️  {file_path.name} doesn't import AppVersion correctly, skipping")
        return
    
    # Replace the import to also include check_app_version
    content = content.replace(
        'from ..models.app_version import AppVersion',
        'from ..models.app_version import AppVersion, check_app_version'
    )
    
    # Replace all AppVersion(...) calls with check_app_version(...)
    # Look for patterns like: AppVersion(_some_variable) or AppVersion(some_value)
    content = re.sub(r'\bAppVersion\s*\(([^)]+)\)', r'check_app_version(\1)', content)
    
    # Fix .value access patterns for AppVersion fields
    # Since AppVersion is now a string (Literal), it doesn't have .value attribute
    # Look for patterns like: some_app_version_field.value
    # This is trickier because we need to identify AppVersion fields specifically
    
    # Pattern 1: Direct field access like created_on_version.value
    # We'll look for common AppVersion field names
    app_version_fields = ['created_on_version', 'app_version', 'version']
    for field_name in app_version_fields:
        pattern = rf'\bself\.{field_name}\.value\b'
        replacement = f'self.{field_name}'
        content = re.sub(pattern, replacement, content)
        
        # Also handle cases without self prefix
        pattern = rf'\b{field_name}\.value\b'
        replacement = field_name
        content = re.sub(pattern, replacement, content)
    
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print(f"✅ Fixed AppVersion instantiations and .value accesses in {file_path.name}")


def verify_other_enums_remain_classes():
    """Verify that other enum files still contain proper enum classes."""
    
    models_dir = Path(__file__).parent / "wallaroo" / "wallaroo_ml_ops_api_client" / "models"
    enum_files = ["interval_unit.py", "aggregation.py", "metric.py"]
    
    for enum_file in enum_files:
        file_path = models_dir / enum_file
        if file_path.exists():
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            if "from enum import Enum" in content and "class " in content:
                print(f"✅ {enum_file} correctly preserved as enum class")
            else:
                print(f"⚠️  {enum_file} may not be a proper enum class")


if __name__ == "__main__":
    print("🔄 Converting AppVersion to Literal type for backward compatibility...")
    
    if convert_app_version_to_literal():
        print("🔧 Fixing AppVersion instantiation calls in other files...")
        fix_app_version_instantiations()
        
        print("🔍 Verifying other enums remain as proper classes...")
        verify_other_enums_remain_classes()
        print("✅ Selective enum conversion completed successfully")
    else:
        print("❌ Failed to convert AppVersion")
        sys.exit(1)
