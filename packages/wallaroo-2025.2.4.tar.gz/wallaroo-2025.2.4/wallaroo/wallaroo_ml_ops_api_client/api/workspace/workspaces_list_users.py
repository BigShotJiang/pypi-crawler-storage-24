from http import HTTPStatus
from typing import Any, Optional, Union, cast

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.workspaces_list_users_body import WorkspacesListUsersBody
from ...models.workspaces_list_users_response_200 import WorkspacesListUsersResponse200
from ...models.workspaces_list_users_response_400 import WorkspacesListUsersResponse400
from ...models.workspaces_list_users_response_401 import WorkspacesListUsersResponse401
from ...models.workspaces_list_users_response_500 import WorkspacesListUsersResponse500
from typing import cast



def _get_kwargs(
    *,
    body: WorkspacesListUsersBody,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/api/workspaces/list_users",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Optional[Union[WorkspacesListUsersResponse200, WorkspacesListUsersResponse400, WorkspacesListUsersResponse401, WorkspacesListUsersResponse500]]:
    if response.status_code == 200:
        response_200 = WorkspacesListUsersResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = WorkspacesListUsersResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = WorkspacesListUsersResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 500:
        response_500 = WorkspacesListUsersResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Response[Union[WorkspacesListUsersResponse200, WorkspacesListUsersResponse400, WorkspacesListUsersResponse401, WorkspacesListUsersResponse500]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: WorkspacesListUsersBody,

) -> Response[Union[WorkspacesListUsersResponse200, WorkspacesListUsersResponse400, WorkspacesListUsersResponse401, WorkspacesListUsersResponse500]]:
    """ List workspace users

     List the Users of a given Workspace

    Args:
        body (WorkspacesListUsersBody):  Request for listing Users belonging to a Workspace

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[WorkspacesListUsersResponse200, WorkspacesListUsersResponse400, WorkspacesListUsersResponse401, WorkspacesListUsersResponse500]]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: Union[AuthenticatedClient, Client],
    body: WorkspacesListUsersBody,

) -> Optional[Union[WorkspacesListUsersResponse200, WorkspacesListUsersResponse400, WorkspacesListUsersResponse401, WorkspacesListUsersResponse500]]:
    """ List workspace users

     List the Users of a given Workspace

    Args:
        body (WorkspacesListUsersBody):  Request for listing Users belonging to a Workspace

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[WorkspacesListUsersResponse200, WorkspacesListUsersResponse400, WorkspacesListUsersResponse401, WorkspacesListUsersResponse500]
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: WorkspacesListUsersBody,

) -> Response[Union[WorkspacesListUsersResponse200, WorkspacesListUsersResponse400, WorkspacesListUsersResponse401, WorkspacesListUsersResponse500]]:
    """ List workspace users

     List the Users of a given Workspace

    Args:
        body (WorkspacesListUsersBody):  Request for listing Users belonging to a Workspace

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[WorkspacesListUsersResponse200, WorkspacesListUsersResponse400, WorkspacesListUsersResponse401, WorkspacesListUsersResponse500]]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: Union[AuthenticatedClient, Client],
    body: WorkspacesListUsersBody,

) -> Optional[Union[WorkspacesListUsersResponse200, WorkspacesListUsersResponse400, WorkspacesListUsersResponse401, WorkspacesListUsersResponse500]]:
    """ List workspace users

     List the Users of a given Workspace

    Args:
        body (WorkspacesListUsersBody):  Request for listing Users belonging to a Workspace

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[WorkspacesListUsersResponse200, WorkspacesListUsersResponse400, WorkspacesListUsersResponse401, WorkspacesListUsersResponse500]
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
