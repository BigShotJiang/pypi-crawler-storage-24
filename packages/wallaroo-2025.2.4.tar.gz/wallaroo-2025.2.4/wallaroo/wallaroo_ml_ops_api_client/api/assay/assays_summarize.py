from http import HTTPStatus
from typing import Any, Optional, Union, cast

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.assays_summarize_body import AssaysSummarizeBody
from ...models.assays_summarize_response_200 import AssaysSummarizeResponse200
from ...models.assays_summarize_response_400 import AssaysSummarizeResponse400
from ...models.assays_summarize_response_401 import AssaysSummarizeResponse401
from ...models.assays_summarize_response_500 import AssaysSummarizeResponse500
from typing import cast



def _get_kwargs(
    *,
    body: AssaysSummarizeBody,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/api/assays/summarize",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Optional[Union[AssaysSummarizeResponse200, AssaysSummarizeResponse400, AssaysSummarizeResponse401, AssaysSummarizeResponse500]]:
    if response.status_code == 200:
        response_200 = AssaysSummarizeResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = AssaysSummarizeResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = AssaysSummarizeResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 500:
        response_500 = AssaysSummarizeResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Response[Union[AssaysSummarizeResponse200, AssaysSummarizeResponse400, AssaysSummarizeResponse401, AssaysSummarizeResponse500]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: AssaysSummarizeBody,

) -> Response[Union[AssaysSummarizeResponse200, AssaysSummarizeResponse400, AssaysSummarizeResponse401, AssaysSummarizeResponse500]]:
    """ Generate static baseline summary stats for a vector or windowed data

     Creates an interactive assay baseline.

    Args:
        body (AssaysSummarizeBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[AssaysSummarizeResponse200, AssaysSummarizeResponse400, AssaysSummarizeResponse401, AssaysSummarizeResponse500]]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: Union[AuthenticatedClient, Client],
    body: AssaysSummarizeBody,

) -> Optional[Union[AssaysSummarizeResponse200, AssaysSummarizeResponse400, AssaysSummarizeResponse401, AssaysSummarizeResponse500]]:
    """ Generate static baseline summary stats for a vector or windowed data

     Creates an interactive assay baseline.

    Args:
        body (AssaysSummarizeBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[AssaysSummarizeResponse200, AssaysSummarizeResponse400, AssaysSummarizeResponse401, AssaysSummarizeResponse500]
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: AssaysSummarizeBody,

) -> Response[Union[AssaysSummarizeResponse200, AssaysSummarizeResponse400, AssaysSummarizeResponse401, AssaysSummarizeResponse500]]:
    """ Generate static baseline summary stats for a vector or windowed data

     Creates an interactive assay baseline.

    Args:
        body (AssaysSummarizeBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[AssaysSummarizeResponse200, AssaysSummarizeResponse400, AssaysSummarizeResponse401, AssaysSummarizeResponse500]]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: Union[AuthenticatedClient, Client],
    body: AssaysSummarizeBody,

) -> Optional[Union[AssaysSummarizeResponse200, AssaysSummarizeResponse400, AssaysSummarizeResponse401, AssaysSummarizeResponse500]]:
    """ Generate static baseline summary stats for a vector or windowed data

     Creates an interactive assay baseline.

    Args:
        body (AssaysSummarizeBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[AssaysSummarizeResponse200, AssaysSummarizeResponse400, AssaysSummarizeResponse401, AssaysSummarizeResponse500]
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
