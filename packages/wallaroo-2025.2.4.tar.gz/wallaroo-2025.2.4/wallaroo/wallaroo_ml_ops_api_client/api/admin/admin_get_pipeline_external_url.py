from http import HTTPStatus
from typing import Any, Optional, Union, cast

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.admin_get_pipeline_external_url_body import AdminGetPipelineExternalUrlBody
from ...models.admin_get_pipeline_external_url_response_200 import AdminGetPipelineExternalUrlResponse200
from ...models.admin_get_pipeline_external_url_response_400 import AdminGetPipelineExternalUrlResponse400
from ...models.admin_get_pipeline_external_url_response_401 import AdminGetPipelineExternalUrlResponse401
from ...models.admin_get_pipeline_external_url_response_500 import AdminGetPipelineExternalUrlResponse500
from typing import cast



def _get_kwargs(
    *,
    body: AdminGetPipelineExternalUrlBody,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/api/admin/get_pipeline_external_url",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Optional[Union[AdminGetPipelineExternalUrlResponse200, AdminGetPipelineExternalUrlResponse400, AdminGetPipelineExternalUrlResponse401, AdminGetPipelineExternalUrlResponse500]]:
    if response.status_code == 200:
        response_200 = AdminGetPipelineExternalUrlResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = AdminGetPipelineExternalUrlResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = AdminGetPipelineExternalUrlResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 500:
        response_500 = AdminGetPipelineExternalUrlResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Response[Union[AdminGetPipelineExternalUrlResponse200, AdminGetPipelineExternalUrlResponse400, AdminGetPipelineExternalUrlResponse401, AdminGetPipelineExternalUrlResponse500]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: AdminGetPipelineExternalUrlBody,

) -> Response[Union[AdminGetPipelineExternalUrlResponse200, AdminGetPipelineExternalUrlResponse400, AdminGetPipelineExternalUrlResponse401, AdminGetPipelineExternalUrlResponse500]]:
    """ Returns the URL for the given pipeline that clients may send inferences to from outside of the
    cluster.

     Returns the external inference URL for a given pipeline.

    Args:
        body (AdminGetPipelineExternalUrlBody):  Request for pipeline URL-related operations.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[AdminGetPipelineExternalUrlResponse200, AdminGetPipelineExternalUrlResponse400, AdminGetPipelineExternalUrlResponse401, AdminGetPipelineExternalUrlResponse500]]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: Union[AuthenticatedClient, Client],
    body: AdminGetPipelineExternalUrlBody,

) -> Optional[Union[AdminGetPipelineExternalUrlResponse200, AdminGetPipelineExternalUrlResponse400, AdminGetPipelineExternalUrlResponse401, AdminGetPipelineExternalUrlResponse500]]:
    """ Returns the URL for the given pipeline that clients may send inferences to from outside of the
    cluster.

     Returns the external inference URL for a given pipeline.

    Args:
        body (AdminGetPipelineExternalUrlBody):  Request for pipeline URL-related operations.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[AdminGetPipelineExternalUrlResponse200, AdminGetPipelineExternalUrlResponse400, AdminGetPipelineExternalUrlResponse401, AdminGetPipelineExternalUrlResponse500]
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: AdminGetPipelineExternalUrlBody,

) -> Response[Union[AdminGetPipelineExternalUrlResponse200, AdminGetPipelineExternalUrlResponse400, AdminGetPipelineExternalUrlResponse401, AdminGetPipelineExternalUrlResponse500]]:
    """ Returns the URL for the given pipeline that clients may send inferences to from outside of the
    cluster.

     Returns the external inference URL for a given pipeline.

    Args:
        body (AdminGetPipelineExternalUrlBody):  Request for pipeline URL-related operations.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[AdminGetPipelineExternalUrlResponse200, AdminGetPipelineExternalUrlResponse400, AdminGetPipelineExternalUrlResponse401, AdminGetPipelineExternalUrlResponse500]]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: Union[AuthenticatedClient, Client],
    body: AdminGetPipelineExternalUrlBody,

) -> Optional[Union[AdminGetPipelineExternalUrlResponse200, AdminGetPipelineExternalUrlResponse400, AdminGetPipelineExternalUrlResponse401, AdminGetPipelineExternalUrlResponse500]]:
    """ Returns the URL for the given pipeline that clients may send inferences to from outside of the
    cluster.

     Returns the external inference URL for a given pipeline.

    Args:
        body (AdminGetPipelineExternalUrlBody):  Request for pipeline URL-related operations.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[AdminGetPipelineExternalUrlResponse200, AdminGetPipelineExternalUrlResponse400, AdminGetPipelineExternalUrlResponse401, AdminGetPipelineExternalUrlResponse500]
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
