from collections.abc import Mapping
from typing import Any, TypeVar, Optional, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast






T = TypeVar("T", bound="AddEdgeToPublishBody")



@_attrs_define
class AddEdgeToPublishBody:
    """ Request to publish a pipeline.

        Attributes:
            name (str):
            pipeline_publish_id (int):
            tags (list[str]):
     """

    name: str
    pipeline_publish_id: int
    tags: list[str]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        name = self.name

        pipeline_publish_id = self.pipeline_publish_id

        tags = self.tags




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "name": name,
            "pipeline_publish_id": pipeline_publish_id,
            "tags": tags,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        pipeline_publish_id = d.pop("pipeline_publish_id")

        tags = cast(list[str], d.pop("tags"))


        add_edge_to_publish_body = cls(
            name=name,
            pipeline_publish_id=pipeline_publish_id,
            tags=tags,
        )


        add_edge_to_publish_body.additional_properties = d
        return add_edge_to_publish_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
