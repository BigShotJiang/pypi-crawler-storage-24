# -*- coding: utf-8 -*-
"""将本地文件路径转换为可供前端预览和 LLM 消费的 URL。

``build_local_media_urls`` 是 ``send_file`` 和 ``desktop_screenshot``
等工具的公共辅助函数。它将本地文件拷贝到 ``UPLOADS_DIR``，使得
dashboard 前端可以通过 ``/api/files/<name>`` 访问该文件。
"""

from __future__ import annotations

import logging
import mimetypes
import os
import shutil
import uuid
from pathlib import Path
from typing import Optional, Tuple

logger = logging.getLogger(__name__)


def build_local_media_urls(
    file_path: str,
) -> Tuple[dict, Optional[str]]:
    """将本地文件路径转换为 source dict 和可选的 preview_url。

    Args:
        file_path: 本地文件的绝对路径。

    Returns:
        一个元组 ``(source, preview_url)``：

        - ``source`` — 符合 content block 规范的 dict，例如
          ``{"type": "url", "url": "file:///tmp/shot.png"}``。
        - ``preview_url`` — 如果文件成功拷贝到 uploads 目录，则返回
          ``"/api/files/<unique_name>"``，前端可直接访问；否则为 ``None``。
    """
    # 构建 file:// 形式的 source，供 LLM 侧消费
    abs_path = os.path.abspath(file_path)
    file_uri = Path(abs_path).as_uri()  # file:///...

    media_type = mimetypes.guess_type(abs_path)[0] or "application/octet-stream"

    source: dict = {
        "type": "url",
        "url": file_uri,
        "media_type": media_type,
    }

    # 尝试拷贝到 UPLOADS_DIR，生成 /api/files/... 的预览 URL
    preview_url: Optional[str] = None
    try:
        from ...constant import UPLOADS_DIR

        UPLOADS_DIR.mkdir(parents=True, exist_ok=True)

        ext = os.path.splitext(abs_path)[1] or ""
        unique_name = f"{uuid.uuid4().hex}{ext}"
        dest = UPLOADS_DIR / unique_name

        shutil.copy2(abs_path, str(dest))
        preview_url = f"/api/files/{unique_name}"
    except Exception as exc:
        logger.warning(
            "build_local_media_urls: 无法拷贝文件到 uploads 目录: %s",
            exc,
        )

    return source, preview_url
