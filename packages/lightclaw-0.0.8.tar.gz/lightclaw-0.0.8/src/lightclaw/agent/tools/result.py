# -*- coding: utf-8 -*-
"""Unified tool result type for LightClaw tools.

Replaces ``agentscope.tool.ToolResponse`` and ``agentscope.message.TextBlock``
etc. with framework-independent types.  All built-in tools return
``LightClawToolResult`` which carries structured ``content`` blocks.

The LangChain adapter layer (``builtins.py``) calls ``.to_str()`` to produce
the plain ``str`` that ``@tool`` wrappers expect.
"""

from __future__ import annotations

from typing import Any, Optional, Sequence


# ---------------------------------------------------------------------------
# Block types – lightweight dicts/TypedDicts, intentionally kept as plain
# ``dict`` factories so they serialise directly to JSON without any
# framework dependency.
# ---------------------------------------------------------------------------


def text_block(text: str) -> dict[str, str]:
    """Create a text content block."""
    return {"type": "text", "text": text}


def image_block(source: dict[str, Any]) -> dict[str, Any]:
    """Create an image content block."""
    return {"type": "image", "source": source}


def audio_block(source: dict[str, Any]) -> dict[str, Any]:
    """Create an audio content block."""
    return {"type": "audio", "source": source}


def video_block(source: dict[str, Any]) -> dict[str, Any]:
    """Create a video content block."""
    return {"type": "video", "source": source}


def file_block(
    source: dict[str, Any],
    filename: Optional[str] = None,
) -> dict[str, Any]:
    """Create a file content block."""
    block: dict[str, Any] = {"type": "file", "source": source}
    if filename is not None:
        block["filename"] = filename
    return block


# ---------------------------------------------------------------------------
# LightClawToolResult
# ---------------------------------------------------------------------------


class LightClawToolResult:
    """Unified return type for all LightClaw built-in tools.

    Drop-in replacement for ``agentscope.tool.ToolResponse``.
    Carries a list of content blocks (text / image / audio / video / file).

    Usage::

        # Simple text result
        return LightClawToolResult(text="Command succeeded.")

        # Structured content blocks
        return LightClawToolResult(content=[
            text_block("已成功发送文件"),
            image_block({"type": "url", "url": "file:///tmp/shot.png"}),
        ])
    """

    __slots__ = ("content",)

    def __init__(
        self,
        content: Optional[Sequence[dict[str, Any]]] = None,
        *,
        text: Optional[str] = None,
    ) -> None:
        if text is not None:
            # Convenience: ``LightClawToolResult(text="hello")``
            self.content: list[dict[str, Any]] = [text_block(text)]
        elif content is not None:
            self.content = list(content)
        else:
            self.content = []

    # -- Convenience helpers ------------------------------------------------

    def to_str(self) -> str:
        """Extract concatenated text from all text blocks.

        This is the primary interface consumed by the LangChain ``@tool``
        wrappers in ``builtins.py``.
        """
        texts: list[str] = []
        for block in self.content:
            if isinstance(block, dict) and block.get("type") == "text":
                t = block.get("text", "")
                if t:
                    texts.append(t)
        return "\n".join(texts) if texts else ""

    def __repr__(self) -> str:
        return f"LightClawToolResult(content={self.content!r})"
