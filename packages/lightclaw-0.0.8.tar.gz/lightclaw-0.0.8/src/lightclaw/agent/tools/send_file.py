# -*- coding: utf-8 -*-
# flake8: noqa: E501
# pylint: disable=line-too-long,too-many-return-statements
import os
import mimetypes

from .media_output import build_local_media_urls
from .result import (
    LightClawToolResult,
    text_block,
    image_block,
    audio_block,
    video_block,
    file_block,
)


def _auto_as_type(mt: str) -> str:
    if mt.startswith("image/"):
        return "image"
    if mt.startswith("audio/"):
        return "audio"
    if mt.startswith("video/"):
        return "video"
    return "file"


async def send_file_to_user(
    file_path: str,
) -> LightClawToolResult:
    """Send a file to the user.

    Args:
        file_path (`str`):
            Path to the file to send.

    Returns:
        `LightClawToolResult`:
            The tool result containing the file or an error message.
    """

    if not os.path.exists(file_path):
        return LightClawToolResult(text=f"Error: The file {file_path} does not exist.")

    if not os.path.isfile(file_path):
        return LightClawToolResult(text=f"Error: The path {file_path} is not a file.")

    # Detect MIME type
    mime_type, _ = mimetypes.guess_type(file_path)
    if mime_type is None:
        # Default to application/octet-stream for unknown types
        mime_type = "application/octet-stream"
    as_type = _auto_as_type(mime_type)

    try:
        # text
        if as_type == "text":
            with open(file_path, "r", encoding="utf-8") as file:
                return LightClawToolResult(text=file.read())

        source, preview_url = build_local_media_urls(file_path)
        filename = os.path.basename(file_path)

        if as_type == "image":
            block = image_block(source)
            block["filename"] = filename
            if preview_url:
                block["preview_url"] = preview_url
            return LightClawToolResult(
                content=[
                    block,
                    text_block("已成功发送文件"),
                ]
            )
        if as_type == "audio":
            return LightClawToolResult(
                content=[
                    audio_block(source),
                    text_block("已成功发送文件"),
                ]
            )
        if as_type == "video":
            return LightClawToolResult(
                content=[
                    video_block(source),
                    text_block("已成功发送文件"),
                ]
            )

        block = file_block(source, filename=filename)
        if preview_url:
            block["preview_url"] = preview_url
        return LightClawToolResult(
            content=[
                block,
                text_block("已成功发送文件"),
            ]
        )

    except Exception as e:
        return LightClawToolResult(text=f"Error: Send file failed due to \n{e}")
