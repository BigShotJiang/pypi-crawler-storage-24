---
name: install-skill
description: "通过 skillhub 搜索和安装 skill。当用户想要安装新 skill、查找可用 skill、搜索 skill、浏览 skill 商店、升级已有 skill 时使用此技能。触发词包括：安装技能、安装skill、搜索skill、skill商店、skillhub、装个技能、有什么技能、skill store、install skill、search skill。"
metadata:
  {
    "lightclaw":
      {
        "emoji": "📦"
      }
  }
---

# Skill 安装管理器

通过 skillhub CLI 搜索、安装和管理 skill。

## 前置条件：确保 skillhub 已安装

在执行任何操作前，先检查 skillhub 是否可用：

```bash
skillhub --version
```

如果命令不存在，自动安装 skillhub：

```bash
curl -fsSL https://skillhub-1251783334.cos.ap-guangzhou.myqcloud.com/install/install.sh | bash
```

安装完成后重新验证：

```bash
skillhub --version
```

## Skill 安装目录

Lightclaw 的 skill 目录位于工作区(workspace)下的 `skills` 目录。所有 skillhub 操作都应使用 `--dir` 参数指定该目录。

获取工作区 skills 目录的方式：找到当前工作区根目录，然后拼接 `skills`，例如 `~/.lightclaw/workspace/skills`。

## 核心工作流

### 1. 搜索 Skill

当用户想查找某个 skill 时，使用搜索功能：

```bash
skillhub search <关键词>
```

搜索结果会展示 skill 的名称（slug）、简介和版本号。将搜索结果整理后呈现给用户，帮助他们挑选合适的 skill。

如果搜索结果有多个匹配项，简要列出每个 skill 的名称和功能描述，让用户选择。

### 2. 安装 Skill

确认用户要安装的 skill 名称后，执行安装：

```bash
skillhub --dir <workspace>/skills install <skill-slug>
```

例如：

```bash
skillhub --dir ~/.lightclaw/workspace/skills install xiaohongshu-mcp
```

安装成功后，告知用户 skill 已安装到的路径，以及该 skill 的功能简介。

### 3. 列出已安装的 Skill

查看当前已安装的所有 skill：

```bash
skillhub --dir <workspace>/skills list
```

### 4. 升级 Skill

升级已安装的 skill 到最新版本：

```bash
skillhub --dir <workspace>/skills upgrade
```

## 操作指南

- 用户说"安装 xxx"或"装一个 xxx skill"时 → 先搜索确认 skill 存在，然后安装
- 用户说"有什么 xxx 相关的技能"或"搜索 xxx" → 执行搜索并展示结果
- 用户说"我装了哪些 skill"或"列出技能" → 列出已安装的 skill
- 用户说"更新技能"或"升级 skill" → 执行升级
- 如果用户提供的名称搜索不到结果，尝试换一些相关关键词再搜索，或者直接尝试安装（skillhub 支持远程精确匹配）
- 安装完成后，提醒用户可以在新的对话中使用该 skill
