# 接口降级与不稳定接口

## 已知不稳定接口（禁用/替换）

以下接口经常超时或断连，**不要使用**，用右侧替代方案：

| 禁用接口 | 问题 | 替代方案 |
|---------|------|---------|
| `stock_zh_a_st_em()` | 超时 | `stock_zh_a_spot_em()` 过滤含"ST"的行 |
| `stock_zh_b_spot_em()` | 超时 | `stock_zh_b_spot()` （新浪源） |
| `stock_zh_a_new_em()` | 超时 | `stock_new_a_spot_em()` |
| `stock_intraday_em()` | 断连 | `stock_intraday_sina(symbol, date)` |
| `futures_hist_em()` | 数据量大超时 | `futures_zh_daily_sina(symbol)` |
| `futures_hist_table_em()` | 数据量大超时 | `futures_zh_daily_sina(symbol)` |
| `bond_cov_comparison()` | 断连 | `bond_zh_cov()` 一览表含溢价率 |
| `forex_spot_em()` | 断连 | `currency_boc_sina()` 或 `tavily_search` |
| `stock_zh_index_spot_em()` | 断连 | `stock_zh_index_spot_sina()` |
| `index_news_sentiment_scope()` | 上游API已损坏 | 无替代，直接跳过 |

## 常用接口降级映射（em → sina）

| 主用接口（em 源） | 降级接口（sina 源） |
|-------------------|-------------------|
| `stock_zh_a_spot_em()` | `stock_zh_a_spot()` |
| `stock_zh_b_spot_em()` | `stock_zh_b_spot()` |
| `stock_zh_index_spot_em()` | `stock_zh_index_spot_sina()` |
| `stock_intraday_em()` | `stock_intraday_sina(symbol, date)` |

## 通用降级策略（三级）

akshare 接口失败时，按以下顺序降级：

```
第一级：换数据源后缀
  _em（东方财富）失败 → 尝试 _sina（新浪），参考上方映射表
  搜索：[x for x in dir(ak) if 'sina' in x and '关键词' in x]

第二级：browser_use 抓取网页
  用 browser-data-source 技能的 URL 映射，直接打开对应网页提取数据
  参考 skills/browser-data-source/SKILL.md 查找目标 URL

第三级：搜索兜底
  tavily_search("关键词 site:cls.cn OR site:eastmoney.com")
```

**铁律：不要在第一级失败后就告诉用户"查不到"。必须尝试完三级降级再说。**

## 备用数据源（browser_use 优先级）

1. **财联社** cls.cn — 实时电报、异动
2. **金十数据** jin10.com — 宏观日历
3. **新浪财经** finance.sina.com.cn — 综合资讯
4. **巨潮资讯** cninfo.com.cn — 上市公司公告

规则：先 akshare 后浏览器，每次最多访问 2 个站，标注来源。
