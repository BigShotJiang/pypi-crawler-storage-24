# akshare 函数参考手册

> 本文件是 stock-info 技能的参考数据。当你需要查找具体的 akshare 函数名、参数或返回列时，阅读本文件。
> 日常简单查询（行情、基本面）通常不需要翻阅此文件——SKILL.md 中已有核心函数。
> 当遇到以下情况时来查本文件：
> - 用户问的是你不常用的数据类别（可转债、ETF、宏观、融资融券等）
> - 你需要确认某个函数的确切参数名或返回列
> - 某个函数报错，需要找替代函数

## 目录

1. [行情类](#1-行情类)
2. [基本面类](#2-基本面类)
3. [板块类](#3-板块类)
4. [资金流向类](#4-资金流向类)
5. [龙虎榜与涨跌停](#5-龙虎榜与涨跌停)
6. [股东类](#6-股东类)
7. [可转债类](#7-可转债类)
8. [ETF与基金类](#8-etf与基金类)
9. [指数类](#9-指数类)
10. [宏观数据类](#10-宏观数据类)
11. [新闻与日历类](#11-新闻与日历类)
12. [融资融券类](#12-融资融券类)

---

## 1. 行情类

### 股票名称→代码查询（轻量，推荐）

| 函数 | 市场 | 参数 | 耗时 |
|------|------|------|------|
| `stock_info_sh_name_code(symbol)` | 沪市 | `symbol`: `"主板A股"` | ~1s |
| `stock_info_sz_name_code(symbol)` | 深市 | `symbol`: `"A股列表"` | ~0.6s |
| `stock_info_bj_name_code()` | 北交所 | 无 | <1s |
| `stock_info_a_code_name()` | 全部A股 | 无 | ~6s |

> **名称查代码优先用前三个**，禁止用 `stock_*_spot_em()` 做名称匹配。

- `stock_info_sh_name_code` 返回列：`证券代码` `证券简称` `证券全称` `公司简称` `公司全称` `上市日期`
- `stock_info_sz_name_code` 返回列：`板块` `A股代码` `A股简称` `A股上市日期` `A股总股本` `A股流通股本` `所属行业`

### 实时行情

> **性能警告：** `stock_*_spot_em()` 系列接口较慢，仅在需要批量行情排序/筛选时使用，查单只股票用 `stock_individual_info_em` + `stock_zh_a_hist`。

| 函数 | 市场 | 参数 | 全天可用 |
|------|------|------|---------|
| `stock_individual_info_em(symbol)` | 个股信息 | `symbol`: 6位代码 | ✅ |
| `stock_bid_ask_em(symbol)` | 五档盘口 | `symbol`: 6位代码 | 交易时段 |
| `stock_zh_a_spot_em()` | 沪深京全部A股 | 无 | 交易时段 |
| `stock_sh_a_spot_em()` | 沪A | 无 | 交易时段 |
| `stock_sz_a_spot_em()` | 深A | 无 | 交易时段 |
| `stock_bj_a_spot_em()` | 北交所 | 无 | 交易时段 |
| `stock_cy_a_spot_em()` | 创业板 | 无 | 交易时段 |
| `stock_kc_a_spot_em()` | 科创板 | 无 | 交易时段 |
| `stock_new_a_spot_em()` | 新股 | 无 | 交易时段 |

**批量行情返回列：** `代码` `名称` `最新价` `涨跌幅` `涨跌额` `成交量` `成交额` `振幅` `最高` `最低` `今开` `昨收` `量比` `换手率` `市盈率-动态` `市净率` `总市值` `流通市值` `涨速` `5分钟涨跌` `60日涨跌幅` `年初至今涨跌幅`

### 历史行情

**`stock_zh_a_hist(symbol, period, start_date, end_date, adjust)`** — 日/周/月K线（✅全天可用）
- `symbol`: 6位代码，如 `"600519"`
- `period`: `"daily"` / `"weekly"` / `"monthly"`
- `start_date` / `end_date`: `"YYYYMMDD"` 格式（必须指定 start_date，否则返回全历史）
- `adjust`: `""` 不复权 / `"qfq"` 前复权 / `"hfq"` 后复权
- 返回列：`日期` `股票代码` `开盘` `收盘` `最高` `最低` `成交量` `成交额` `振幅` `涨跌幅` `涨跌额` `换手率`

**`stock_zh_a_hist_min_em(symbol, period, adjust)`** — 分钟K线
- `period`: `"1"` / `"5"` / `"15"` / `"30"` / `"60"`
- 其余参数同上

---

## 2. 基本面类

### 核心指标

| 函数 | 用途 | 参数 |
|------|------|------|
| `stock_financial_analysis_indicator(symbol, start_year)` | 财务指标汇总 | `symbol`: 6位, `start_year`: 如 `"2023"` |
| `stock_profit_sheet_by_report_em(symbol)` | 利润表-按报告期 | `symbol`: 6位 |
| `stock_profit_sheet_by_yearly_em(symbol)` | 利润表-按年度 | 同上 |
| `stock_profit_sheet_by_quarterly_em(symbol)` | 利润表-按单季 | 同上 |
| `stock_balance_sheet_by_report_em(symbol)` | 资产负债表-按报告期 | 同上 |
| `stock_balance_sheet_by_yearly_em(symbol)` | 资产负债表-按年度 | 同上 |
| `stock_cash_flow_sheet_by_report_em(symbol)` | 现金流量表-按报告期 | 同上 |
| `stock_cash_flow_sheet_by_yearly_em(symbol)` | 现金流量表-按年度 | 同上 |

### 同行比较

> 注意：`symbol` 参数需要带市场前缀，如 `"SZ000895"` 或 `"SH600519"`

| 函数 | 用途 | 关键返回列 |
|------|------|-----------|
| `stock_zh_valuation_comparison_em(symbol)` | 估值比较 | PEG, PE(TTM/各年), PS, PB, 市现率, EV/EBITDA |
| `stock_zh_growth_comparison_em(symbol)` | 成长性比较 | EPS增长率, 营收增长率, 净利润增长率（3年复合/年度/TTM/预测） |
| `stock_zh_dupont_comparison_em(symbol)` | 杜邦分析比较 | ROE, 净利率, 总资产周转率, 权益乘数（近3年+排名） |

### 分红

**`stock_fhps_em(date)`** — 分红配送数据
- `date`: `"YYYYMMDD"` 格式
- 返回列含：`代码` `名称` `每股收益` `每股净资产` `净利润同比增长` `分红方案` `预案公告日`

---

## 3. 板块类

### 概念板块

| 函数 | 用途 | 参数 |
|------|------|------|
| `stock_board_concept_name_em()` | 概念板块列表 | 无 |
| `stock_board_concept_cons_em(symbol)` | 成份股 | `symbol`: 板块名称，如 `"人工智能"` |
| `stock_board_concept_hist_em(symbol, period, start_date, end_date, adjust)` | 板块历史行情 | 同上 + K线参数 |

**板块列表返回列：** `排名` `板块名称` `板块代码` `最新价` `涨跌额` `涨跌幅` `总市值` `换手率` `上涨家数` `下跌家数` `领涨股票` `领涨股票-涨跌幅`

### 行业板块

| 函数 | 用途 | 参数 |
|------|------|------|
| `stock_board_industry_name_em()` | 行业板块列表 | 无 |
| `stock_board_industry_cons_em(symbol)` | 成份股 | `symbol`: 板块名称，如 `"半导体"` |
| `stock_board_industry_hist_em(symbol, period, start_date, end_date, adjust)` | 板块历史行情 | 同上 |

### 申万行业分类

| 函数 | 用途 | 返回列亮点 |
|------|------|-----------|
| `sw_index_first_info()` | 申万一级行业 | 含 `静态市盈率` `TTM市盈率` `市净率` `静态股息率` |
| `sw_index_second_info()` | 申万二级行业 | 同上 + `上级行业` |
| `sw_index_daily_indicator(symbol, start_date, end_date)` | 申万指数历史 | `symbol` 为行业代码如 `"801010"` |

---

## 4. 资金流向类

### 个股资金流

**`stock_individual_fund_flow(stock, market)`** — 个股历史资金流
- `stock`: 6位代码
- `market`: `"sh"` 或 `"sz"`
- 返回列：`日期` `收盘价` `涨跌幅` `主力净流入-净额/净占比` `超大单净流入-净额/净占比` `大单` `中单` `小单`

**`stock_individual_fund_flow_rank(indicator)`** — 资金流排名
- `indicator`: `"今日"` / `"3日"` / `"5日"` / `"10日"`

### 大盘与板块资金流

| 函数 | 用途 | 参数 |
|------|------|------|
| `stock_market_fund_flow()` | 大盘资金流向 | 无 |
| `stock_sector_fund_flow_rank(indicator, sector_type)` | 板块资金流排名 | `sector_type`: `"行业资金流"` / `"概念资金流"` / `"地域资金流"` |

### 北向资金

| 函数 | 用途 | 参数 |
|------|------|------|
| `stock_hsgt_north_net_flow_in_em(symbol)` | 北向资金净流入 | `symbol`: `"北上"` / `"沪股通"` / `"深股通"` |
| `stock_hsgt_hold_stock_em(market, indicator)` | 持股排行 | `market`: `"北向"` / `"沪股通"` / `"深股通"`; `indicator`: `"今日排行"` / `"3日排行"` / `"5日排行"` / `"10日排行"` / `"月排行"` / `"季排行"` |

---

## 5. 龙虎榜与涨跌停

### 龙虎榜

| 函数 | 用途 | 关键参数 |
|------|------|----------|
| `stock_lhb_detail_em(start_date, end_date, symbol)` | 龙虎榜详情 | `symbol`: `"近一月"` / `"近三月"` / `"近六月"` / `"近一年"` |
| `stock_lhb_stock_statistic_em(symbol)` | 个股上榜统计 | 同上 |
| `stock_lhb_jgmmtj_em(start_date, end_date)` | 机构买卖统计 | 日期格式 `"YYYYMMDD"` |
| `stock_lhb_jgstatistic_em(symbol)` | 机构席位追踪 | 同龙虎榜详情 |
| `stock_lhb_hyyyb_em(start_date, end_date)` | 活跃营业部 | 同机构买卖 |

### 涨跌停股池

所有函数参数均为 `date`（`"YYYYMMDD"` 格式）：

| 函数 | 用途 | 特有返回列 |
|------|------|-----------|
| `stock_zt_pool_em(date)` | 涨停股池 | `封板资金` `首次封板时间` `最后封板时间` `炸板次数` `连板数` `所属行业` |
| `stock_zt_pool_previous_em(date)` | 昨日涨停 | 含溢价率 |
| `stock_zt_pool_strong_em(date)` | 强势股池 | — |
| `stock_zt_pool_sub_new_em(date)` | 次新股池 | — |
| `stock_zt_pool_zbgc_em(date)` | 炸板股池 | `涨停时间` `开板时间` `炸板次数` |
| `stock_zt_pool_dtgc_em(date)` | 跌停股池 | — |

---

## 6. 股东类

| 函数 | 用途 | 参数 |
|------|------|------|
| `stock_main_stock_holder(stock)` | 十大股东 | `stock`: 6位代码 |
| `stock_circulate_stock_holder(stock)` | 十大流通股东 | 同上 |
| `stock_holder_number_em(symbol)` | 股东户数趋势 | `symbol`: 6位代码 |
| `stock_institute_hold(symbol)` | 机构持股 | 同上 |
| `stock_report_fund_hold(symbol, date)` | 基金持股 | `date`: `"YYYYMMDD"` |
| `stock_hold_management_detail_em(symbol)` | 高管持股变动 | `symbol`: 6位代码 |

**股东户数返回列：** `股东户数` `较上期变化` `人均持股市值` `人均持股数量` `股价` `户均持股市值变化`

---

## 7. 可转债类

### 行情与概览

| 函数 | 用途 | 参数 |
|------|------|------|
| `bond_zh_hs_cov_spot()` | 全部可转债实时行情 | 无 |
| `bond_zh_cov()` | 可转债一览表 | 无（含转股价、转股价值、溢价率、评级） |
| `bond_zh_hs_cov_daily(symbol)` | 历史日线 | `symbol`: 如 `"sz128039"` / `"sh113542"` |
| `bond_cov_comparison()` | 比价表 | 无（含转股溢价率、纯债溢价率、强赎触发价） |

### 分析与事件

| 函数 | 用途 | 参数 |
|------|------|------|
| `bond_zh_cov_value_analysis(symbol)` | 价值分析 | 6位转债代码（返回：纯债价值、转股价值、溢价率） |
| `bond_cb_redeem_jsl()` | 强赎信息 | 无（返回：赎回状态、触发比、最后交易日） |
| `bond_cb_adj_logs_jsl(symbol)` | 转股价调整记录 | 6位转债代码 |

---

## 8. ETF与基金类

### ETF

| 函数 | 用途 | 参数 |
|------|------|------|
| `fund_etf_spot_em()` | ETF实时行情 | 无（返回含 IOPV估值、折价率、主力净流入、最新份额） |
| `fund_etf_hist_em(symbol, period, start_date, end_date, adjust)` | ETF历史行情 | 同股票K线参数 |

### 基金净值

| 函数 | 用途 | 参数 |
|------|------|------|
| `fund_open_fund_daily_em()` | 开放基金-当日净值 | 无 |
| `fund_open_fund_info_em(symbol, indicator)` | 开放基金-历史净值 | `indicator`: `"单位净值走势"` / `"累计净值走势"` / `"累计收益率走势"` / `"同类排名走势"` / `"分红送配详情"` |
| `fund_money_fund_daily_em()` | 货币基金 | 无（返回：万份收益、7日年化%） |

### 基金持仓与排行

| 函数 | 用途 | 参数 |
|------|------|------|
| `fund_portfolio_hold_em(symbol, date)` | 基金重仓股 | `symbol`: 基金代码, `date`: 年份如 `"2025"` |
| `fund_portfolio_industry_allocation_em(symbol, date)` | 行业配置 | 同上 |
| `fund_open_fund_rank_em(symbol)` | 基金排行 | `symbol`: `"全部"` / `"股票型"` / `"混合型"` / `"债券型"` / `"指数型"` / `"QDII"` / `"FOF"` |
| `fund_info_index_em(symbol, indicator)` | 指数基金信息 | `symbol`: `"沪深指数"` / `"行业主题"` 等; `indicator`: `"被动指数型"` / `"增强指数型"` |

---

## 9. 指数类

### A股指数

**`stock_zh_index_spot_sina()`** — 指数实时行情（新浪源，无需参数，返回所有A股指数）

**`index_zh_a_hist(symbol, period, start_date, end_date)`** — 指数历史行情
- `symbol`: 指数代码不带前缀，如 `"000016"`
- `period`: `"daily"` / `"weekly"` / `"monthly"`

### 指数成份股

| 函数 | 用途 | 参数 |
|------|------|------|
| `index_stock_cons(symbol)` | 成份股列表 | `symbol`: 如 `"000300"` |
| `index_stock_cons_weight_csindex(symbol)` | 成份股权重 | 同上（返回含 `权重(%)`） |

### 全球指数

| 函数 | 用途 | 参数 |
|------|------|------|
| `index_global_spot_em()` | 全球指数实时 | 无 |
| `index_global_hist_em(symbol)` | 全球指数历史 | `symbol`: 指数名称，如 `"美元指数"` |

---

## 10. 宏观数据类

所有函数无参数，直接调用即可。

### 经济增长与价格

| 函数 | 指标 | 频率 | 返回列 |
|------|------|------|--------|
| `macro_china_gdp_yearly()` | GDP年率 | 季度 | `商品` `日期` `今值(%)` `预测值(%)` `前值(%)` |
| `macro_china_cpi_yearly()` | CPI年率 | 月度 | 同上 |
| `macro_china_cpi()` | CPI详细 | 月度 | `月份` `全国-当月/同比/环比/累计` `城市-...` `农村-...` |
| `macro_china_ppi_yearly()` | PPI年率 | 月度 | 同GDP |

### 景气度

| 函数 | 指标 | 频率 |
|------|------|------|
| `macro_china_pmi_yearly()` | PMI(官方制造业) | 月度 |
| `macro_china_cx_pmi_yearly()` | PMI(财新制造业) | 月度 |
| `macro_china_non_man_pmi()` | 非制造业PMI | 月度 |

### 货币与信贷

| 函数 | 指标 | 返回列亮点 |
|------|------|-----------|
| `macro_china_m2_yearly()` | M2年率 | `今值` `预测值` `前值` |
| `macro_china_money_supply()` | 货币供应详细 | M0/M1/M2 数量(亿元) 及同比环比 |
| `macro_china_lpr()` | LPR | `TRADE_DATE` `LPR1Y(%)` `LPR5Y(%)` |
| `macro_china_reserve_requirement_ratio()` | 存款准备金率 | `公布时间` `生效时间` `大型/中小金融机构-调整前后及幅度` |
| `macro_china_shrzgm()` | 社融 | `月份` `社融增量(亿)` + 各分项 |
| `macro_china_new_financial_credit()` | 新增信贷 | `当月(亿)` `同比(%)` `环比(%)` `累计` |

---

## 11. 新闻与日历类

### 综合新闻

| 函数 | 来源 | 参数 |
|------|------|------|
| `news_cctv(date)` | 新闻联播文字稿 | `date`: `"YYYYMMDD"` |
| `news_economic_baidu(date)` | 百度经济日历 | 同上 |
| `stock_news_main_cx()` | 财新网新闻 | 无 |
| `stock_telegraph_cls()` | 财联社7x24电报 | 无 |

### 个股新闻

**`stock_news_em(symbol)`** — 东方财富个股新闻（最近100条）

### 交易日历

| 函数 | 用途 | 参数 |
|------|------|------|
| `news_report_time_baidu(date)` | 财报发布日历 | `date`: `"YYYYMMDD"` |
| `news_trade_notify_dividend_baidu(date)` | 分红派息提醒 | 同上 |
| `news_trade_notify_suspend_baidu(date)` | 停复牌提醒 | 同上 |

---

## 12. 融资融券类

### 市场汇总

| 函数 | 交易所 | 参数 |
|------|--------|------|
| `stock_margin_sse(start_date, end_date)` | 上交所 | `"YYYYMMDD"` 格式 |
| `stock_margin_szse(start_date, end_date)` | 深交所 | 同上 |

**返回列：** `信用交易日期` `融资余额(元)` `融资买入额(元)` `融券余量(股)` `融券余量金额(元)` `融资融券余额(元)`

### 个股明细

| 函数 | 交易所 | 参数 |
|------|--------|------|
| `stock_margin_detail_sse(date)` | 上交所 | `"YYYYMMDD"` |
| `stock_margin_detail_szse(date)` | 深交所 | 同上 |

**返回列：** `标的证券代码/简称` `融资余额(元)` `融资买入额` `融资偿还额` `融券余量(股)` `融券卖出量` `融券偿还量`

---

## 通用技巧

**函数搜索：** 不确定用什么函数时：
```python
[x for x in dir(ak) if 'keyword' in x]
```

**数据输出模式：**
```python
import akshare as ak
df = ak.某函数(参数)
result = df.to_json(orient="records", force_ascii=False)
print(result)
```

**报错应对：** 如果函数名变更或参数不对，用上面的搜索方式找替代。akshare 版本更新较频繁，函数名偶有调整。
