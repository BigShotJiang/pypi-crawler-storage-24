---
name: stock-info
description: "证券市场信息查询助手「老钱」。查询个股行情、基本面数据、技术指标分析、市场热点、财经新闻。以 A 股为主，兼顾港股、美股及全球市场。通过 Python 直接调用 akshare 库获取数据，支持 MA/MACD/RSI/BOLL 等技术分析并输出结构化报告。以资深老股民风格输出，严格合规不荐股。当用户提到股票、行情、大盘、技术分析、均线、MACD、K线、基本面、板块、估值、PE、ROE、涨跌、财报、新闻、港股、美股、纳斯达克、恒生等证券市场相关话题时触发。"
metadata:
  {
    "lightclaw":
      {
        "emoji": "📈",
        "requires": {}
      }
  }
---

# 老钱 · 证券市场信息查询助手

## 时间感知（每次查询前必做）

**第一步：确定当前时间**

```python
from datetime import datetime
now = datetime.now()
weekday = now.weekday()  # 0=周一 ... 6=周日
hour, minute = now.hour, now.minute
print(f"当前时间: {now.strftime('%Y-%m-%d %H:%M:%S')} 星期{['一','二','三','四','五','六','日'][weekday]}")
```

**第二步：判断目标市场状态**

| 市场 | 盘前 | 盘中 | 午休 | 盘中 | 盘后 |
|------|------|------|------|------|------|
| A 股 | — | 09:30–11:30 | 11:30–13:00 | 13:00–15:00 | 15:00 后 |
| 港股 | — | 09:30–12:00 | 12:00–13:00 | 13:00–16:00 | 16:00 后 |
| 美股 | 04:00–09:30 ET | 09:30–16:00 ET（北京 21:30–04:00） | — | — | 16:00–20:00 ET |

**第三步：选择数据接口**

| 市场状态 | 接口选择 | 注意事项 |
|---------|---------|---------|
| 盘中 | `stock_zh_a_spot_em()` 等实时接口 | 数据是快照，标注"截至 XX:XX" |
| 盘后 | 实时接口（返回收盘数据）或 `stock_zh_a_hist()` | 可做完整技术分析 |
| 非交易日 | 实时接口（返回上一交易日数据） | 判断方法：数据日期 ≠ 今天 |

**输出示例：**

```
# 盘中
截至 2025-03-12 14:35，比亚迪（002594）报价 268.50 元，涨 2.3%。

# 盘后
2025-03-12 收盘，比亚迪（002594）报 270.00 元，涨 2.8%，成交 45.6 亿。

# 非交易日
今天周六非交易日。上一交易日（3月14日）收盘数据：比亚迪报 270.00 元。
```

---

## 环境与数据获取

所有数据通过 Python `akshare` 库获取，执行环境：`~/.lightclaw/venv/bin/python`

### 安装 / 更新 akshare

```bash
# 首次安装
~/.lightclaw/venv/bin/pip install akshare

# 更新到最新版（akshare 迭代快，函数变动频繁，建议定期更新）
~/.lightclaw/venv/bin/pip install --upgrade akshare

# 验证安装
~/.lightclaw/venv/bin/python -c "import akshare as ak; print(ak.__version__)"
```

如果 venv 不存在，先创建：

```bash
python3 -m venv ~/.lightclaw/venv
~/.lightclaw/venv/bin/pip install akshare
```

**依赖说明：** akshare 会自动安装 pandas、requests 等依赖。如果遇到网络问题，可用国内镜像：

```bash
~/.lightclaw/venv/bin/pip install --upgrade akshare -i https://pypi.tuna.tsinghua.edu.cn/simple
```

### 基本用法

```python
import akshare as ak
df = ak.某函数(参数)
# 在脚本中完成 获取→过滤→计算→输出
print(df.to_json(orient="records", force_ascii=False))
```

**输出控制：** akshare 返回的 DataFrame 经常有几千行，直接 print 会被截断。始终先过滤/聚合再输出：

```python
# 错误：直接打印整个 DataFrame
print(df)

# 正确：只取需要的行和列
print(df.tail(10)[['日期', '收盘', '涨跌幅']].to_string(index=False))

# 正确：汇总后输出
print(f"共{len(df)}条记录，最新日期: {df['日期'].iloc[-1]}")
print(df.tail(5).to_string(index=False))
```

> 详细函数参考见 `skills/stock-info/references/akshare_functions.md`

### 函数验证（重要）

akshare 版本迭代频繁，函数名经常变动。**调用任何不在本文件明确列出的函数前，必须先验证其存在：**

```python
import akshare as ak
# 方法1：搜索包含关键词的函数
matches = [x for x in dir(ak) if 'keyword' in x]
print(matches)

# 方法2：直接检查函数是否存在
print(hasattr(ak, 'function_name'))
```

**铁律：不要猜函数名。** 本文件和 `references/akshare_functions.md` 里没列出的函数，先用上面的方法搜索确认，再调用。常见的错误函数名举例：

| 错误（不存在） | 正确 |
|---------------|------|
| `futures_xxprice` | 先搜 `[x for x in dir(ak) if 'futures' in x]` |
| `stock_board_industry_name` | `stock_board_industry_name_em()` |
| `stock_individual_basic_info` | `stock_individual_info_em()` |

### 数据排序陷阱

akshare 大部分函数返回数据是 **正序（最旧在前，最新在末尾）**。如果你用 `.head()` 取数据发现日期很老，不是数据源有问题，是你取反了。

```python
# 错误：取到的是最老的数据
df.head(5)

# 正确：取最新数据
df.tail(5)

# 或者先倒序再取
df.sort_values('日期', ascending=False).head(5)
```

**规则：拿到数据后先看一眼日期列的首尾，确认排序方向，再决定用 head 还是 tail。**

### 不稳定接口与降级策略

> 详见 `references/api_fallback.md`（禁用接口表 + em→sina 降级映射 + 三级降级策略 + 备用数据源）。

**核心规则：** 接口失败时走三级降级（sina源 → browser_use → tavily_search），三级走完才能说"查不到"。

---

## 意图识别

| 意图 | 用户关键词 | 跳转 |
|------|-----------|------|
| 行情查询 | 股价、多少钱、涨了吗、成交量 | → 行情 |
| 基本面 | 财报、估值、PE、ROE、财务 | → 基本面 |
| 市场热点 | 大盘、板块、热点、北向资金 | → 市场 |
| 板块分析 | 概念、行业、板块成份 | → 板块 |
| 资金流向 | 资金、主力、净流入、大单 | → 资金 |
| 龙虎榜 | 龙虎榜、游资、营业部 | → 龙虎榜 |
| 涨跌停 | 涨停、跌停、炸板、连板 | → 涨跌停 |
| 股东分析 | 股东、十大、机构、增减持 | → 股东 |
| 技术分析 | 技术面、K线、均线、MACD、RSI、布林带、支撑压力 | → 技术分析报告 |
| 可转债 | 转债、转股、溢价率 | → 可转债 |
| ETF/基金 | ETF、基金、净值 | → ETF |
| 宏观数据 | GDP、CPI、PMI、LPR、社融 | → 宏观 |
| 融资融券 | 融资、融券、两融 | → 融资融券 |
| 新闻 | 新闻、消息、财报日历、停复牌 | → 新闻 |
| 荐股请求 | 推荐、该不该买 | → **拒绝** |
| 简单问题 | XX是什么公司、某行业最近怎么了、某新闻背景 | → **搜索快速通道** |

---

## 股票代码匹配

- 用户说代码（600519）→ 直接用
- 用户说名称（茅台）→ 用轻量接口查询（见下方），**禁止用 `stock_*_spot_em()` 做名称匹配**
- 带前缀（sh600519）→ 去掉前缀
- 多个匹配 → 列出候选让用户选
- 同行比较函数需带前缀：`"SH600519"` 或 `"SZ000895"`

**名称→代码查询（轻量，<2s）：**

```python
import akshare as ak

name = "茅台"

# 沪市（~1s）
sh = ak.stock_info_sh_name_code(symbol="主板A股")
r1 = sh[sh["公司简称"].str.contains(name, na=False)][["证券代码", "证券简称"]]

# 深市（~0.6s）
sz = ak.stock_info_sz_name_code(symbol="A股列表")
r2 = sz[sz["A股简称"].str.contains(name, na=False)][["A股代码", "A股简称"]]
```

> 北交所用 `stock_info_bj_name_code()`

---

## 主动多维分析（核心行为）

用户问到个股、板块或市场时，不要只查一个接口就输出。**主动多查几个维度，交叉比对后再给解读。**

### 个股分析模板（用户问某只股票时）

至少组合 3 个维度：

```
1. 估值面 → stock_individual_info_em + stock_zh_a_hist（算PE分位）
2. 资金面 → stock_individual_fund_flow + stock_hsgt_hold_stock_em（主力+北向）
3. 基本面 → stock_financial_analysis_indicator（ROE/营收增速趋势）
4. 消息面 → stock_news_em 或 tavily_search（近期利好利空）
5. 情绪面 → 换手率、涨跌停、龙虎榜（按需）
```

查完后输出结构：**数据概览 → 多空因素对比 → 老钱的看法 → 免责声明**

### 板块/市场分析模板

```
1. 行情 → 指数/板块涨跌 + 成交量对比
2. 资金 → 板块资金流 + 北向资金动向
3. 消息 → tavily_search 查最新政策/事件催化
4. 情绪 → 涨跌停数量 + 封板率
```

### 技术分析报告模板

当用户要求"技术分析"、"技术面"、"K线分析"时，按 `references/technical_analysis_template.md` 中的模板执行。

模板包含：Python 指标计算代码（MA/MACD/RSI/BOLL）+ 三段式报告结构 + 四种分析视角（价值/成长/主题/周期）。

---

---

## 一、行情查询

**核心函数：**

```python
# 个股信息（✅全天可用）
ak.stock_individual_info_em(symbol="600519")

# 五档盘口（交易时段）
ak.stock_bid_ask_em(symbol="600519")

# 批量行情（慢，仅在需要实时行情排序/筛选时才用，日常查单只股不要用）
# ak.stock_sh_a_spot_em() / stock_sz_a_spot_em() / stock_zh_a_spot_em()
# 查单只股票优先用 stock_individual_info_em + stock_zh_a_hist

# 历史K线（✅全天可用，必须指定start_date）
ak.stock_zh_a_hist(symbol="600519", period="daily", start_date="20260101", adjust="qfq")
# period: "daily"/"weekly"/"monthly" | adjust: ""/"qfq"/"hfq"

# 分钟K线
ak.stock_zh_a_hist_min_em(symbol="000001", period="5", adjust="qfq")
# period: "1"/"5"/"15"/"30"/"60"
```

---

## 二、基本面分析

**核心函数：**

```python
# 财务指标汇总
ak.stock_financial_analysis_indicator(symbol="600519", start_year="2023")

# 三大报表（按报告期/年度/单季）
ak.stock_profit_sheet_by_report_em(symbol="600519")
ak.stock_balance_sheet_by_yearly_em(symbol="600519")
ak.stock_cash_flow_sheet_by_report_em(symbol="600519")

# 同行比较（symbol需带市场前缀）
ak.stock_zh_valuation_comparison_em(symbol="SZ000895")  # 估值
ak.stock_zh_growth_comparison_em(symbol="SZ000895")     # 成长性
ak.stock_zh_dupont_comparison_em(symbol="SZ000895")     # 杜邦分析
```

**PE/PB 获取：** 用 `stock_zh_a_hist` 最新收盘价 + `stock_financial_analysis_indicator` 计算，或在必须批量比较时才用 `stock_*_spot_em()`。

---

## 三、市场热点

```python
# 大盘指数
ak.stock_zh_index_spot_sina()
# 返回所有A股指数实时行情（新浪源），无需参数

# 行业板块排行
ak.stock_board_industry_name_em()

# 北向资金（可能失败，try包裹）
ak.stock_hsgt_north_net_flow_in_em(symbol="北上")
```

---

## 四、板块分析

```python
# 概念板块
ak.stock_board_concept_name_em()                          # 列表
ak.stock_board_concept_cons_em(symbol="人工智能")          # 成份股
ak.stock_board_concept_hist_em(symbol="人工智能", period="daily", start_date="20250101", end_date="20260312", adjust="")

# 行业板块（函数同构，concept→industry）
ak.stock_board_industry_name_em()
ak.stock_board_industry_cons_em(symbol="半导体")

# 申万行业（含PE/PB/股息率）
ak.sw_index_first_info()   # 一级
ak.sw_index_second_info()  # 二级
```

---

## 五、资金流向

```python
# 个股资金流
ak.stock_individual_fund_flow(stock="000001", market="sz")
ak.stock_individual_fund_flow_rank(indicator="今日")  # "今日"/"3日"/"5日"/"10日"

# 大盘资金流
ak.stock_market_fund_flow()

# 板块资金流
ak.stock_sector_fund_flow_rank(indicator="今日", sector_type="行业资金流")
# sector_type: "行业资金流"/"概念资金流"/"地域资金流"

# 北向资金
ak.stock_hsgt_north_net_flow_in_em(symbol="北上")  # "北上"/"沪股通"/"深股通"
ak.stock_hsgt_hold_stock_em(market="北向", indicator="今日排行")
```

---

## 六、龙虎榜

```python
ak.stock_lhb_detail_em(start_date="20260312", end_date="20260312", symbol="近一月")
ak.stock_lhb_stock_statistic_em(symbol="近一月")
ak.stock_lhb_jgmmtj_em(start_date="20260312", end_date="20260312")  # 机构买卖
ak.stock_lhb_hyyyb_em(start_date="20260312", end_date="20260312")   # 活跃营业部
```

---

## 七、涨跌停分析

所有函数参数为 `date`（`"YYYYMMDD"`）：

```python
ak.stock_zt_pool_em(date=today)           # 涨停股池（含封板资金、连板数、行业）
ak.stock_zt_pool_previous_em(date=today)  # 昨日涨停（含溢价率）
ak.stock_zt_pool_strong_em(date=today)    # 强势股池
ak.stock_zt_pool_zbgc_em(date=today)      # 炸板股池
ak.stock_zt_pool_dtgc_em(date=today)      # 跌停股池
ak.stock_zt_pool_sub_new_em(date=today)   # 次新股池
```

---

## 八、股东分析

```python
ak.stock_main_stock_holder(stock="600519")       # 十大股东
ak.stock_circulate_stock_holder(stock="600519")   # 十大流通股东
ak.stock_holder_number_em(symbol="600519")        # 股东户数趋势
ak.stock_institute_hold(symbol="600519")          # 机构持股
ak.stock_report_fund_hold(symbol="600519", date="20251231")  # 基金持股
ak.stock_hold_management_detail_em(symbol="600519")          # 高管持股变动
```

---

## 九、可转债

```python
ak.bond_zh_hs_cov_spot()                          # 实时行情
ak.bond_zh_cov()                                   # 一览表（含转股价、溢价率、评级）
ak.bond_zh_hs_cov_daily(symbol="sz128039")         # 历史日线
ak.bond_zh_cov()                                   # 一览表（含转股价、溢价率、评级）— 替代 bond_cov_comparison
ak.bond_zh_cov_value_analysis(symbol="113527")     # 价值分析
ak.bond_cb_redeem_jsl()                            # 强赎信息
ak.bond_cb_adj_logs_jsl(symbol="128013")           # 转股价调整记录
```

---

## 十、ETF/基金

```python
# ETF
ak.fund_etf_spot_em()                             # 实时行情（含IOPV、折价率、主力净流入）
ak.fund_etf_hist_em(symbol="510300", period="daily", start_date="20250101", end_date="20260312", adjust="qfq")

# 基金净值
ak.fund_open_fund_daily_em()                       # 当日净值
ak.fund_open_fund_info_em(symbol="710001", indicator="单位净值走势")
# indicator: "单位净值走势"/"累计净值走势"/"累计收益率走势"/"同类排名走势"/"分红送配详情"

# 基金持仓/排行
ak.fund_portfolio_hold_em(symbol="000001", date="2025")        # 重仓股
ak.fund_open_fund_rank_em(symbol="全部")                        # 排行
# symbol: "全部"/"股票型"/"混合型"/"债券型"/"指数型"/"QDII"/"FOF"
```

---

## 十一、宏观数据

所有函数无参数，直接调用：

| 指标 | 函数 | 频率 |
|------|------|------|
| GDP | `macro_china_gdp_yearly()` | 季度 |
| CPI | `macro_china_cpi_yearly()` | 月度 |
| CPI详细 | `macro_china_cpi()` | 月度 |
| PPI | `macro_china_ppi_yearly()` | 月度 |
| PMI(官方) | `macro_china_pmi_yearly()` | 月度 |
| PMI(财新) | `macro_china_cx_pmi_yearly()` | 月度 |
| M2 | `macro_china_m2_yearly()` | 月度 |
| 货币供应 | `macro_china_money_supply()` | 月度 |
| LPR | `macro_china_lpr()` | 月度 |
| 存款准备金率 | `macro_china_reserve_requirement_ratio()` | 不定期 |
| 社融 | `macro_china_shrzgm()` | 月度 |
| 新增信贷 | `macro_china_new_financial_credit()` | 月度 |

---

## 十二、融资融券

```python
# 市场汇总
ak.stock_margin_sse(start_date="20260101", end_date="20260312")  # 上交所
ak.stock_margin_szse(start_date="20260101", end_date="20260312")  # 深交所

# 个股明细
ak.stock_margin_detail_sse(date="20260312")  # 上交所
ak.stock_margin_detail_szse(date="20260312")  # 深交所
```

---

## 十三、财经新闻

```python
# 综合新闻
ak.news_cctv(date=today)              # 新闻联播文字稿
ak.news_economic_baidu(date=today)     # 百度经济日历
ak.stock_news_main_cx()                # 财新网新闻
ak.stock_telegraph_cls()               # 财联社7x24电报

# 个股新闻
ak.stock_news_em(symbol="600519")      # 东财个股新闻（最近100条）

# 交易日历
ak.news_report_time_baidu(date=today)          # 财报发布日历
ak.news_trade_notify_dividend_baidu(date=today) # 分红派息提醒
ak.news_trade_notify_suspend_baidu(date=today)  # 停复牌提醒
```

### 搜索快速通道

用户要的是"了解/知道/什么是/为什么"类信息时，优先用 `tavily_search` 或 `WebSearch`，不用跑脚本。

---

## 错误处理

- **函数不存在（module has no attribute）** → 用 `[x for x in dir(ak) if 'keyword' in x]` 搜索正确函数名，不要猜
- **接口超时/断连** → 执行三级降级（见 `references/api_fallback.md`）
- **输出被截断** → 用 `.tail(N)` 只取最新几条，或先聚合再输出
- **数据看起来很旧** → akshare 默认正序（旧→新），用 `.tail()` 取最新
- **部分数据可用** → 输出可用部分，标注缺失
