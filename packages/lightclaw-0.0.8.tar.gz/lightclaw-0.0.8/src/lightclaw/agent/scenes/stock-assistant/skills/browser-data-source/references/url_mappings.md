# 金融数据接口 → 源站 URL 完整映射

> 覆盖 993 个数据接口对应的源站网页地址，按类别分组。
> 当 SKILL.md 核心映射表未覆盖时查阅本文件。

## 目录

- [股票](#stock) (369)
- [宏观数据](#macro) (215)
- [基金](#fund) (88)
- [指数](#index) (87)
- [期货](#futures) (52)
- [期权](#option) (41)
- [债券/可转债](#bond) (39)
- [外汇](#fx) (11)
- [利率](#interest_rate) (14)
- [其他](#others) (34)
- [能源/碳排放](#energy) (8)
- [现货](#spot) (13)
- [货币](#currency) (5)
- [加密货币](#dc) (3)
- [学术/研究](#article) (4)
- [QDII](#qdii) (3)
- [事件](#event) (2)
- [银行](#bank) (1)
- [NLP](#nlp) (2)
- [高频数据](#hf) (1)
- [工具](#tool) (1)

---

## 股票

| 函数 | 目标地址 |
|------|---------|
| `stock_sse_summary` | `http://www.sse.com.cn/market/stockdata/statistic/` |
| `stock_szse_summary` | `http://www.szse.cn/market/overview/index.html` |
| `stock_szse_area_summary` | `http://www.szse.cn/market/overview/index.html` |
| `stock_szse_sector_summary` | `http://docs.static.szse.cn/www/market/periodical/month/W020220511355248518608.html` |
| `stock_sse_deal_daily` | `http://www.sse.com.cn/market/stockdata/overview/day/` |
| `stock_individual_info_em` | `http://quote.eastmoney.com/concept/sh603777.html?from=classic` |
| `stock_individual_basic_info_xq` | `https://xueqiu.com/snowman/S/SH601127/detail#/GSJJ` |
| `stock_bid_ask_em` | `https://quote.eastmoney.com/sz000001.html` |
| `stock_zh_a_spot_em` | `https://quote.eastmoney.com/center/gridlist.html#hs_a_board` |
| `stock_sh_a_spot_em` | `http://quote.eastmoney.com/center/gridlist.html#sh_a_board` |
| `stock_sz_a_spot_em` | `http://quote.eastmoney.com/center/gridlist.html#sz_a_board` |
| `stock_bj_a_spot_em` | `http://quote.eastmoney.com/center/gridlist.html#bj_a_board` |
| `stock_new_a_spot_em` | `http://quote.eastmoney.com/center/gridlist.html#newshares` |
| `stock_cy_a_spot_em` | `https://quote.eastmoney.com/center/gridlist.html#gem_board` |
| `stock_kc_a_spot_em` | `http://quote.eastmoney.com/center/gridlist.html#kcb_board` |
| `stock_zh_ab_comparison_em` | `https://quote.eastmoney.com/center/gridlist.html#ab_comparison` |
| `stock_zh_a_spot` | `https://vip.stock.finance.sina.com.cn/mkt/#hs_a` |
| `stock_individual_spot_xq` | `https://xueqiu.com/S/SH513520` |
| `stock_zh_a_hist` | `https://quote.eastmoney.com/concept/sh603777.html?from=classic(示例)` |
| `stock_zh_a_daily` | `https://finance.sina.com.cn/realstock/company/sh600006/nc.shtml(示例)` |
| `stock_zh_a_hist_tx` | `https://gu.qq.com/sh000919/zs` |
| `stock_zh_a_minute` | `http://finance.sina.com.cn/realstock/company/sh600519/nc.shtml` |
| `stock_zh_a_hist_min_em` | `https://quote.eastmoney.com/concept/sh603777.html` |
| `stock_intraday_em` | `https://quote.eastmoney.com/f1.html?newcode=0.000001` |
| `stock_intraday_sina` | `https://vip.stock.finance.sina.com.cn/quotes_service/view/cn_bill.php?symbol=sz000001` |
| `stock_zh_a_hist_pre_min_em` | `https://quote.eastmoney.com/concept/sh603777.html` |
| `stock_zh_a_tick_tx` | `http://gu.qq.com/sz300494/gp/detail(示例)` |
| `stock_zh_growth_comparison_em` | `https://emweb.securities.eastmoney.com/pc_hsf10/pages/index.html?type=web&code=000895&color=b#/thbj/czxbj` |
| `stock_zh_valuation_comparison_em` | `https://emweb.securities.eastmoney.com/pc_hsf10/pages/index.html?type=web&code=000895&color=b#/thbj/gzbj` |
| `stock_zh_dupont_comparison_em` | `https://emweb.securities.eastmoney.com/pc_hsf10/pages/index.html?type=web&code=000895&color=b#/thbj/dbfxbj` |
| `stock_zh_scale_comparison_em` | `https://emweb.securities.eastmoney.com/pc_hsf10/pages/index.html?type=web&code=000895&color=b#/thbj/gsgm` |
| `stock_zh_a_cdr_daily` | `https://finance.sina.com.cn/realstock/company/sh689009/nc.shtml` |
| `stock_zh_b_spot_em` | `http://quote.eastmoney.com/center/gridlist.html#hs_b_board` |
| `stock_zh_b_spot` | `http://vip.stock.finance.sina.com.cn/mkt/#hs_b` |
| `stock_zh_b_daily` | `https://finance.sina.com.cn/realstock/company/sh900901/nc.shtml` |
| `stock_zh_b_minute` | `http://finance.sina.com.cn/realstock/company/sh900901/nc.shtml` |
| `stock_zh_a_new` | `http://vip.stock.finance.sina.com.cn/mkt/#new_stock` |
| `stock_gsrl_gsdt_em` | `https://data.eastmoney.com/gsrl/gsdt.html` |
| `stock_zh_a_st_em` | `https://quote.eastmoney.com/center/gridlist.html#st_board` |
| `stock_zh_a_new_em` | `https://quote.eastmoney.com/center/gridlist.html#newshares` |
| `stock_xgsr_ths` | `https://data.10jqka.com.cn/ipo/xgsr/` |
| `stock_ipo_benefit_ths` | `https://data.10jqka.com.cn/ipo/syg/` |
| `stock_zh_a_stop_em` | `http://quote.eastmoney.com/center/gridlist.html#staq_net_board` |
| `stock_zh_kcb_spot` | `http://vip.stock.finance.sina.com.cn/mkt/#kcb` |
| `stock_zh_kcb_daily` | `https://finance.sina.com.cn/realstock/company/sh688001/nc.shtml(示例)` |
| `stock_zh_kcb_report_em` | `https://data.eastmoney.com/notices/kcb.html` |
| `stock_zh_ah_spot_em` | `https://quote.eastmoney.com/center/gridlist.html#ah_comparison` |
| `stock_zh_ah_spot` | `https://stockapp.finance.qq.com/mstats/#mod=list&id=hk_ah&module=HK&type=AH` |
| `stock_zh_ah_daily` | `https://gu.qq.com/hk02359/gp` |
| `stock_zh_ah_name` | `https://stockapp.finance.qq.com/mstats/#mod=list&id=hk_ah&module=HK&type=AH` |
| `stock_us_spot_em` | `https://quote.eastmoney.com/center/gridlist.html#us_stocks` |
| `stock_us_spot` | `https://finance.sina.com.cn/stock/usstock/sector.shtml` |
| `stock_us_hist` | `https://quote.eastmoney.com/us/ENTX.html#fullScreenChart` |
| `stock_individual_basic_info_us_xq` | `https://xueqiu.com/snowman/S/NVDA/detail#/GSJJ` |
| `stock_us_hist_min_em` | `https://quote.eastmoney.com/us/ATER.html` |
| `stock_us_daily` | `http://finance.sina.com.cn/stock/usstock/sector.shtml` |
| `stock_us_pink_spot_em` | `http://quote.eastmoney.com/center/gridlist.html#us_pinksheet` |
| `stock_us_famous_spot_em` | `http://quote.eastmoney.com/center/gridlist.html#us_wellknown` |
| `stock_hk_spot_em` | `http://quote.eastmoney.com/center/gridlist.html#hk_stocks` |
| `stock_hk_main_board_spot_em` | `https://quote.eastmoney.com/center/gridlist.html#hk_mainboard` |
| `stock_hk_spot` | `https://vip.stock.finance.sina.com.cn/mkt/#qbgg_hk` |
| `stock_individual_basic_info_hk_xq` | `https://xueqiu.com/S/00700` |
| `stock_hk_hist_min_em` | `http://quote.eastmoney.com/hk/00948.html` |
| `stock_hk_hist` | `https://quote.eastmoney.com/hk/08367.html` |
| `stock_hk_daily` | `http://stock.finance.sina.com.cn/hkstock/quotes/01336.html(个例)` |
| `stock_hk_famous_spot_em` | `https://quote.eastmoney.com/center/gridlist.html#hk_wellknown` |
| `stock_hk_security_profile_em` | `https://emweb.securities.eastmoney.com/PC_HKF10/pages/home/index.html?code=03900&type=web&color=w#/CompanyProfile` |
| `stock_hk_company_profile_em` | `https://emweb.securities.eastmoney.com/PC_HKF10/pages/home/index.html?code=03900&type=web&color=w#/CompanyProfile` |
| `stock_hk_financial_indicator_em` | `https://emweb.securities.eastmoney.com/PC_HKF10/pages/home/index.html?code=03900&type=web&color=w#/CoreReading` |
| `stock_hk_dividend_payout_em` | `https://emweb.securities.eastmoney.com/PC_HKF10/pages/home/index.html?code=03900&type=web&color=w#/CoreReading` |
| `stock_hk_growth_comparison_em` | `https://emweb.securities.eastmoney.com/PC_HKF10/pages/home/index.html?code=03900&type=web&color=w#/IndustryComparison` |
| `stock_hk_valuation_comparison_em` | `https://emweb.securities.eastmoney.com/PC_HKF10/pages/home/index.html?code=03900&type=web&color=w#/IndustryComparison` |
| `stock_hk_scale_comparison_em` | `https://emweb.securities.eastmoney.com/PC_HKF10/pages/home/index.html?code=03900&type=web&color=w#/IndustryComparison` |
| `stock_jgdy_tj_em` | `http://data.eastmoney.com/jgdy/tj.html` |
| `stock_jgdy_detail_em` | `http://data.eastmoney.com/jgdy/xx.html` |
| `stock_zyjs_ths` | `https://basic.10jqka.com.cn/new/000066/operate.html` |
| `stock_zygc_em` | `https://emweb.securities.eastmoney.com/PC_HSF10/BusinessAnalysis/Index?type=web&code=SH688041#` |
| `stock_gpzy_profile_em` | `https://data.eastmoney.com/gpzy/marketProfile.aspx` |
| `stock_gpzy_pledge_ratio_em` | `https://data.eastmoney.com/gpzy/pledgeRatio.aspx` |
| `stock_gpzy_pledge_ratio_detail_em` | `https://data.eastmoney.com/gpzy/pledgeDetail.aspx` |
| `stock_gpzy_distribute_statistics_company_em` | `https://data.eastmoney.com/gpzy/distributeStatistics.aspx` |
| `stock_gpzy_distribute_statistics_bank_em` | `https://data.eastmoney.com/gpzy/distributeStatistics.aspx` |
| `stock_gpzy_industry_data_em` | `https://data.eastmoney.com/gpzy/industryData.aspx` |
| `stock_sy_profile_em` | `https://data.eastmoney.com/sy/scgk.html` |
| `stock_sy_yq_em` | `https://data.eastmoney.com/sy/yqlist.html` |
| `stock_sy_jz_em` | `https://data.eastmoney.com/sy/jzlist.html` |
| `stock_sy_em` | `https://data.eastmoney.com/sy/list.html` |
| `stock_sy_hy_em` | `https://data.eastmoney.com/sy/hylist.html` |
| `stock_account_statistics_em` | `https://data.eastmoney.com/cjsj/gpkhsj.html` |
| `stock_analyst_rank_em` | `https://data.eastmoney.com/invest/invest/list.html` |
| `stock_analyst_detail_em` | `https://data.eastmoney.com/invest/invest/11000257131.html` |
| `stock_comment_em` | `https://data.eastmoney.com/stockcomment/` |
| `stock_comment_detail_zlkp_jgcyd_em` | `https://data.eastmoney.com/stockcomment/stock/600000.html` |
| `stock_comment_detail_zhpj_lspf_em` | `https://data.eastmoney.com/stockcomment/stock/600000.html` |
| `stock_comment_detail_scrd_focus_em` | `https://data.eastmoney.com/stockcomment/stock/600000.html` |
| `stock_comment_detail_scrd_desire_em` | `https://data.eastmoney.com/stockcomment/stock/600000.html` |
| `stock_hsgt_fund_flow_summary_em` | `https://data.eastmoney.com/hsgt/index.html#lssj` |
| `stock_sgt_settlement_exchange_rate_szse` | `https://www.szse.cn/szhk/hkbussiness/exchangerate/index.html` |
| `stock_sgt_settlement_exchange_rate_sse` | `http://www.sse.com.cn/services/hkexsc/disclo/ratios` |
| `stock_sgt_reference_exchange_rate_szse` | `https://www.szse.cn/szhk/hkbussiness/exchangerate/index.html` |
| `stock_sgt_reference_exchange_rate_sse` | `http://www.sse.com.cn/services/hkexsc/disclo/ratios/` |
| `stock_hk_ggt_components_em` | `https://quote.eastmoney.com/center/gridlist.html#hk_components` |
| `stock_hsgt_fund_min_em` | `https://data.eastmoney.com/hsgt/hsgtDetail/scgk.html` |
| `stock_hsgt_board_rank_em` | `https://data.eastmoney.com/hsgtcg/bk.html` |
| `stock_hsgt_hold_stock_em` | `https://data.eastmoney.com/hsgtcg/list.html` |
| `stock_hsgt_stock_statistics_em` | `http://data.eastmoney.com/hsgtcg/StockStatistics.aspx` |
| `stock_hsgt_institution_statistics_em` | `http://data.eastmoney.com/hsgtcg/InstitutionStatistics.aspx` |
| `stock_hsgt_sh_hk_spot_em` | `https://quote.eastmoney.com/center/gridlist.html#hk_sh_stocks` |
| `stock_hsgt_hist_em` | `https://data.eastmoney.com/hsgt/index.html` |
| `stock_hsgt_individual_em` | `https://data.eastmoney.com/hsgt/StockHdDetail/002008.html` |
| `stock_hsgt_individual_detail_em` | `http://data.eastmoney.com/hsgtcg/StockHdStatistics/002008.html(示例)` |
| `stock_tfp_em` | `https://data.eastmoney.com/tfpxx/` |
| `news_trade_notify_suspend_baidu` | `https://gushitong.baidu.com/calendar` |
| `news_trade_notify_dividend_baidu` | `https://gushitong.baidu.com/calendar` |
| `stock_news_em` | `https://so.eastmoney.com/news/s?keyword=603777` |
| `stock_news_main_cx` | `https://cxdata.caixin.com/pc/` |
| `news_report_time_baidu` | `https://gushitong.baidu.com/calendar` |
| `stock_dxsyl_em` | `https://data.eastmoney.com/xg/xg/dxsyl.html` |
| `stock_xgsglb_em` | `https://data.eastmoney.com/xg/xg/default_2.html` |
| `stock_ipo_ths` | `https://data.10jqka.com.cn/ipo/xgsgyzq/` |
| `stock_ipo_hk_ths` | `https://data.10jqka.com.cn/ipo/xgsgyzq/` |
| `stock_yjbb_em` | `http://data.eastmoney.com/bbsj/202003/yjbb.html` |
| `stock_yjkb_em` | `https://data.eastmoney.com/bbsj/202003/yjkb.html` |
| `stock_yjyg_em` | `https://data.eastmoney.com/bbsj/202003/yjyg.html` |
| `stock_yysj_em` | `https://data.eastmoney.com/bbsj/202003/yysj.html` |
| `stock_report_disclosure` | `http://www.cninfo.com.cn/new/commonUrl?url=data/yypl` |
| `stock_zh_a_disclosure_report_cninfo` | `http://www.cninfo.com.cn/new/commonUrl/pageOfSearch?url=disclosure/list/search` |
| `stock_zh_a_disclosure_relation_cninfo` | `http://www.cninfo.com.cn/new/commonUrl/pageOfSearch?url=disclosure/list/search` |
| `stock_industry_category_cninfo` | `https://webapi.cninfo.com.cn/#/apiDoc` |
| `stock_industry_change_cninfo` | `http://webapi.cninfo.com.cn/#/apiDoc` |
| `stock_share_change_cninfo` | `https://webapi.cninfo.com.cn/#/apiDoc` |
| `stock_allotment_cninfo` | `http://webapi.cninfo.com.cn/#/dataBrowse` |
| `stock_profile_cninfo` | `http://webapi.cninfo.com.cn/#/company` |
| `stock_ipo_summary_cninfo` | `https://webapi.cninfo.com.cn/#/company` |
| `stock_zcfz_em` | `https://data.eastmoney.com/bbsj/202003/zcfz.html` |
| `stock_zcfz_bj_em` | `https://data.eastmoney.com/bbsj/202003/zcfz.html` |
| `stock_lrb_em` | `http://data.eastmoney.com/bbsj/202003/lrb.html` |
| `stock_xjll_em` | `http://data.eastmoney.com/bbsj/202003/xjll.html` |
| `stock_ggcg_em` | `http://data.eastmoney.com/executive/gdzjc.html` |
| `stock_fhps_em` | `https://data.eastmoney.com/yjfp/` |
| `stock_fhps_detail_em` | `https://data.eastmoney.com/yjfp/detail/300073.html` |
| `stock_fhps_detail_ths` | `https://basic.10jqka.com.cn/new/603444/bonus.html` |
| `stock_hk_fhpx_detail_ths` | `https://stockpage.10jqka.com.cn/HK0700/bonus/` |
| `stock_fund_flow_individual` | `https://data.10jqka.com.cn/funds/ggzjl/#refCountId=data_55f13c2c_254` |
| `stock_fund_flow_concept` | `https://data.10jqka.com.cn/funds/gnzjl/#refCountId=data_55f13c2c_254` |
| `stock_fund_flow_industry` | `http://data.10jqka.com.cn/funds/hyzjl/#refCountId=data_55f13c2c_254` |
| `stock_fund_flow_big_deal` | `https://data.10jqka.com.cn/funds/ddzz` |
| `stock_individual_fund_flow` | `https://data.eastmoney.com/zjlx/detail.html` |
| `stock_individual_fund_flow_rank` | `http://data.eastmoney.com/zjlx/detail.html` |
| `stock_market_fund_flow` | `https://data.eastmoney.com/zjlx/dpzjlx.html` |
| `stock_sector_fund_flow_rank` | `https://data.eastmoney.com/bkzj/hy.html` |
| `stock_main_fund_flow` | `https://data.eastmoney.com/zjlx/list.html` |
| `stock_sector_fund_flow_summary` | `https://data.eastmoney.com/bkzj/BK1034.html` |
| `stock_sector_fund_flow_hist` | `https://data.eastmoney.com/bkzj/BK1034.html` |
| `stock_concept_fund_flow_hist` | `https://data.eastmoney.com/bkzj/BK0574.html` |
| `stock_cyq_em` | `https://quote.eastmoney.com/concept/sz000001.html` |
| `stock_gddh_em` | `https://data.eastmoney.com/gddh/` |
| `stock_zdhtmx_em` | `https://data.eastmoney.com/zdht/mx.html` |
| `stock_research_report_em` | `https://data.eastmoney.com/report/stock.jshtml` |
| `stock_notice_report` | `https://data.eastmoney.com/notices/hsa/5.html` |
| `stock_financial_report_sina` | `https://vip.stock.finance.sina.com.cn/corp/go.php/vFD_FinanceSummary/stockid/600600/displaytype/4.phtml?source=fzb&qq-pf-to=pcqq.group` |
| `stock_balance_sheet_by_report_em` | `https://emweb.securities.eastmoney.com/PC_HSF10/NewFinanceAnalysis/Index?type=web&code=sh600519#lrb-0` |
| `stock_balance_sheet_by_yearly_em` | `https://emweb.securities.eastmoney.com/PC_HSF10/NewFinanceAnalysis/Index?type=web&code=sh600519#lrb-0` |
| `stock_profit_sheet_by_report_em` | `https://emweb.securities.eastmoney.com/PC_HSF10/NewFinanceAnalysis/Index?type=web&code=sh600519#lrb-0` |
| `stock_profit_sheet_by_yearly_em` | `https://emweb.securities.eastmoney.com/PC_HSF10/NewFinanceAnalysis/Index?type=web&code=sh600519#lrb-0` |
| `stock_profit_sheet_by_quarterly_em` | `https://emweb.securities.eastmoney.com/PC_HSF10/NewFinanceAnalysis/Index?type=web&code=sh600519#lrb-0` |
| `stock_cash_flow_sheet_by_report_em` | `https://emweb.securities.eastmoney.com/PC_HSF10/NewFinanceAnalysis/Index?type=web&code=sh600519#lrb-0` |
| `stock_cash_flow_sheet_by_yearly_em` | `https://emweb.securities.eastmoney.com/PC_HSF10/NewFinanceAnalysis/Index?type=web&code=sh600519#lrb-0` |
| `stock_cash_flow_sheet_by_quarterly_em` | `https://emweb.securities.eastmoney.com/PC_HSF10/NewFinanceAnalysis/Index?type=web&code=sh600519#lrb-0` |
| `stock_financial_debt_new_ths` | `https://basic.10jqka.com.cn/astockpc/astockmain/index.html#/financen?code=000063` |
| `stock_financial_benefit_new_ths` | `https://basic.10jqka.com.cn/astockpc/astockmain/index.html#/financen?code=000063` |
| `stock_financial_cash_new_ths` | `https://basic.10jqka.com.cn/astockpc/astockmain/index.html#/financen?code=000063` |
| `stock_balance_sheet_by_report_delisted_em` | `https://emweb.securities.eastmoney.com/pc_hsf10/pages/index.html?type=web&code=SZ000013#/cwfx/zcfzb` |
| `stock_profit_sheet_by_report_delisted_em` | `https://emweb.securities.eastmoney.com/pc_hsf10/pages/index.html?type=web&code=SZ000013#/cwfx/lrb` |
| `stock_cash_flow_sheet_by_report_delisted_em` | `https://emweb.securities.eastmoney.com/pc_hsf10/pages/index.html?type=web&code=SZ000013#/cwfx/xjllb` |
| `stock_financial_hk_report_em` | `https://emweb.securities.eastmoney.com/PC_HKF10/FinancialAnalysis/index?type=web&code=00700` |
| `stock_financial_us_report_em` | `https://emweb.eastmoney.com/PC_USF10/pages/index.html?code=TSLA&type=web&color=w#/cwfx/zyzb` |
| `stock_financial_abstract` | `https://vip.stock.finance.sina.com.cn/corp/go.php/vFD_FinanceSummary/stockid/600004.phtml` |
| `stock_financial_abstract_new_ths` | `https://basic.10jqka.com.cn/new/000063/finance.html` |
| `stock_financial_analysis_indicator_em` | `https://emweb.securities.eastmoney.com/pc_hsf10/pages/index.html?type=web&code=SZ301389&color=b#/cwfx` |
| `stock_financial_analysis_indicator` | `https://money.finance.sina.com.cn/corp/go.php/vFD_FinancialGuideLine/stockid/600004/ctrl/2019/displaytype/4.phtml` |
| `stock_financial_hk_analysis_indicator_em` | `https://emweb.securities.eastmoney.com/PC_HKF10/NewFinancialAnalysis/index?type=web&code=00700` |
| `stock_financial_us_analysis_indicator_em` | `https://emweb.eastmoney.com/PC_USF10/pages/index.html?code=TSLA&type=web&color=w#/cwfx/zyzb` |
| `stock_history_dividend` | `http://vip.stock.finance.sina.com.cn/q/go.php/vInvestConsult/kind/lsfh/index.phtml` |
| `stock_gdfx_free_top_10_em` | `https://emweb.securities.eastmoney.com/PC_HSF10/ShareholderResearch/Index?type=web&code=SH688686#sdltgd-0` |
| `stock_gdfx_top_10_em` | `https://emweb.securities.eastmoney.com/PC_HSF10/ShareholderResearch/Index?type=web&code=SH688686#sdltgd-0` |
| `stock_gdfx_free_holding_change_em` | `https://data.eastmoney.com/gdfx/HoldingAnalyse.html` |
| `stock_gdfx_holding_change_em` | `https://data.eastmoney.com/gdfx/HoldingAnalyse.html` |
| `stock_management_change_ths` | `https://basic.10jqka.com.cn/new/688981/event.html` |
| `stock_shareholder_change_ths` | `https://basic.10jqka.com.cn/new/688981/event.html` |
| `stock_gdfx_free_holding_analyse_em` | `https://data.eastmoney.com/gdfx/HoldingAnalyse.html` |
| `stock_gdfx_holding_analyse_em` | `https://data.eastmoney.com/gdfx/HoldingAnalyse.html` |
| `stock_gdfx_free_holding_detail_em` | `https://data.eastmoney.com/gdfx/HoldingAnalyse.html` |
| `stock_gdfx_holding_detail_em` | `https://data.eastmoney.com/gdfx/HoldingAnalyse.html` |
| `stock_gdfx_free_holding_statistics_em` | `https://data.eastmoney.com/gdfx/HoldingAnalyse.html` |
| `stock_gdfx_holding_statistics_em` | `https://data.eastmoney.com/gdfx/HoldingAnalyse.html` |
| `stock_gdfx_free_holding_teamwork_em` | `https://data.eastmoney.com/gdfx/HoldingAnalyse.html` |
| `stock_gdfx_holding_teamwork_em` | `https://data.eastmoney.com/gdfx/HoldingAnalyse.html` |
| `stock_zh_a_gdhs` | `http://data.eastmoney.com/gdhs/` |
| `stock_zh_a_gdhs_detail_em` | `https://data.eastmoney.com/gdhs/detail/000002.html` |
| `stock_history_dividend_detail` | `https://vip.stock.finance.sina.com.cn/corp/go.php/vISSUE_ShareBonus/stockid/300670.phtml` |
| `stock_dividend_cninfo` | `http://webapi.cninfo.com.cn/#/company?companyid=600009` |
| `stock_ipo_info` | `https://vip.stock.finance.sina.com.cn/corp/go.php/vISSUE_NewStock/stockid/600004.phtml` |
| `stock_ipo_review_em` | `https://data.eastmoney.com/xg/gh/default.html` |
| `stock_ipo_tutor_em` | `https://data.eastmoney.com/xg/gh/default.html` |
| `stock_add_stock` | `https://vip.stock.finance.sina.com.cn/corp/go.php/vISSUE_AddStock/stockid/600004.phtml` |
| `stock_restricted_release_queue_sina` | `https://vip.stock.finance.sina.com.cn/q/go.php/vInvestConsult/kind/xsjj/index.phtml?symbol=sh600000` |
| `stock_restricted_release_summary_em` | `https://data.eastmoney.com/dxf/marketStatistics.html?type=day&startdate=2022-11-08&enddate=2022-12-19` |
| `stock_restricted_release_detail_em` | `https://data.eastmoney.com/dxf/detail.html` |
| `stock_restricted_release_queue_em` | `https://data.eastmoney.com/dxf/q/600000.html` |
| `stock_restricted_release_stockholder_em` | `https://data.eastmoney.com/dxf/q/600000.html` |
| `stock_circulate_stock_holder` | `https://vip.stock.finance.sina.com.cn/corp/go.php/vCI_CirculateStockHolder/stockid/600000.phtml` |
| `stock_sector_spot` | `http://finance.sina.com.cn/stock/sl/` |
| `stock_sector_detail` | `http://finance.sina.com.cn/stock/sl/#area_1` |
| `stock_info_sh_name_code` | `https://www.sse.com.cn/assortment/stock/list/share/` |
| `stock_info_sz_name_code` | `https://www.szse.cn/market/product/stock/list/index.html` |
| `stock_info_bj_name_code` | `https://www.bse.cn/nq/listedcompany.html` |
| `stock_info_sz_delist` | `https://www.szse.cn/market/stock/suspend/index.html` |
| `stock_staq_net_stop` | `https://quote.eastmoney.com/center/gridlist.html#staq_net_board` |
| `stock_info_sh_delist` | `https://www.sse.com.cn/assortment/stock/list/delisting/` |
| `stock_info_change_name` | `https://vip.stock.finance.sina.com.cn/corp/go.php/vCI_CorpInfo/stockid/300378.phtml` |
| `stock_info_sz_change_name` | `https://www.szse.cn/www/market/stock/changename/index.html` |
| `stock_fund_stock_holder` | `https://vip.stock.finance.sina.com.cn/corp/go.php/vCI_FundStockHolder/stockid/600004.phtml` |
| `stock_main_stock_holder` | `https://vip.stock.finance.sina.com.cn/corp/go.php/vCI_StockHolder/stockid/600004.phtml` |
| `stock_institute_hold` | `https://vip.stock.finance.sina.com.cn/q/go.php/vComStockHold/kind/jgcg/index.phtml` |
| `stock_institute_hold_detail` | `http://vip.stock.finance.sina.com.cn/q/go.php/vComStockHold/kind/jgcg/index.phtml` |
| `stock_institute_recommend` | `http://stock.finance.sina.com.cn/stock/go.php/vIR_RatingNewest/index.phtml` |
| `stock_institute_recommend_detail` | `http://stock.finance.sina.com.cn/stock/go.php/vIR_StockSearch/key/sz000001.phtml` |
| `stock_rank_forecast_cninfo` | `https://webapi.cninfo.com.cn/#/thematicStatistics` |
| `stock_industry_clf_hist_sw` | `http://www.swhyresearch.com/institute_sw/allIndex/downloadCenter/industryType` |
| `stock_industry_pe_ratio_cninfo` | `http://webapi.cninfo.com.cn/#/thematicStatistics` |
| `stock_new_gh_cninfo` | `https://webapi.cninfo.com.cn/#/xinguList` |
| `stock_new_ipo_cninfo` | `https://webapi.cninfo.com.cn/#/xinguList` |
| `stock_share_hold_change_sse` | `http://www.sse.com.cn/disclosure/credibility/supervision/change/` |
| `stock_share_hold_change_szse` | `http://www.szse.cn/disclosure/supervision/change/index.html` |
| `stock_share_hold_change_bse` | `https://www.bse.cn/disclosure/djg_sharehold_change.html` |
| `stock_hold_num_cninfo` | `https://webapi.cninfo.com.cn/#/thematicStatistics` |
| `stock_hold_change_cninfo` | `https://webapi.cninfo.com.cn/#/thematicStatistics` |
| `stock_hold_control_cninfo` | `https://webapi.cninfo.com.cn/#/thematicStatistics` |
| `stock_hold_management_detail_cninfo` | `https://webapi.cninfo.com.cn/#/thematicStatistics` |
| `stock_hold_management_detail_em` | `https://data.eastmoney.com/executive/list.html` |
| `stock_hold_management_person_em` | `https://data.eastmoney.com/executive/personinfo.html?name=%E5%90%B4%E8%BF%9C&code=001308` |
| `stock_cg_guarantee_cninfo` | `https://webapi.cninfo.com.cn/#/thematicStatistics` |
| `stock_cg_lawsuit_cninfo` | `http://webapi.cninfo.com.cn/#/thematicStatistics` |
| `stock_cg_equity_mortgage_cninfo` | `https://webapi.cninfo.com.cn/#/thematicStatistics` |
| `stock_price_js` | `https://www.ushknews.com/report.html` |
| `stock_qsjy_em` | `http://data.eastmoney.com/other/qsjy.html` |
| `stock_a_gxl_lg` | `https://legulegu.com/stockdata/guxilv` |
| `stock_hk_gxl_lg` | `https://legulegu.com/stockdata/market/hk/dv/hsi` |
| `stock_a_congestion_lg` | `https://legulegu.com/stockdata/ashares-congestion` |
| `stock_ebs_lg` | `https://legulegu.com/stockdata/equity-bond-spread` |
| `stock_buffett_index_lg` | `https://legulegu.com/stockdata/marketcap-gdp` |
| `stock_a_ttm_lyr` | `https://www.legulegu.com/stockdata/a-ttm-lyr` |
| `stock_a_all_pb` | `https://www.legulegu.com/stockdata/all-pb` |
| `stock_market_pe_lg` | `https://legulegu.com/stockdata/shanghaiPE` |
| `stock_index_pe_lg` | `https://legulegu.com/stockdata/sz50-ttm-lyr` |
| `stock_market_pb_lg` | `https://legulegu.com/stockdata/shanghaiPB` |
| `stock_index_pb_lg` | `https://legulegu.com/stockdata/sz50-pb` |
| `stock_zh_valuation_baidu` | `https://gushitong.baidu.com/stock/ab-002044` |
| `stock_value_em` | `https://data.eastmoney.com/gzfx/detail/300766.html` |
| `stock_zh_vote_baidu` | `https://gushitong.baidu.com/index/ab-000001` |
| `stock_hk_indicator_eniu` | `https://eniu.com/gu/hk01093/roe` |
| `stock_hk_valuation_baidu` | `https://gushitong.baidu.com/stock/hk-06969` |
| `stock_us_valuation_baidu` | `https://gushitong.baidu.com/stock/us-NVDA` |
| `stock_a_high_low_statistics` | `https://www.legulegu.com/stockdata/high-low-statistics` |
| `stock_a_below_net_asset_statistics` | `https://www.legulegu.com/stockdata/below-net-asset-statistics` |
| `stock_report_fund_hold` | `http://data.eastmoney.com/zlsj/2020-06-30-1-2.html` |
| `stock_report_fund_hold_detail` | `http://data.eastmoney.com/zlsj/ccjj/2020-12-31-008286.html` |
| `stock_lhb_detail_em` | `https://data.eastmoney.com/stock/tradedetail.html` |
| `stock_lhb_stock_statistic_em` | `https://data.eastmoney.com/stock/tradedetail.html` |
| `stock_lhb_jgmmtj_em` | `https://data.eastmoney.com/stock/jgmmtj.html` |
| `stock_lhb_jgstatistic_em` | `https://data.eastmoney.com/stock/jgstatistic.html` |
| `stock_lhb_hyyyb_em` | `https://data.eastmoney.com/stock/hyyyb.html` |
| `stock_lhb_yyb_detail_em` | `https://data.eastmoney.com/stock/lhb/yyb/10188715.html` |
| `stock_lhb_yybph_em` | `https://data.eastmoney.com/stock/yybph.html` |
| `stock_lhb_traderstatistic_em` | `https://data.eastmoney.com/stock/traderstatistic.html` |
| `stock_lhb_stock_detail_em` | `https://data.eastmoney.com/stock/lhb/600077.html` |
| `stock_lh_yyb_most` | `https://data.10jqka.com.cn/market/longhu/` |
| `stock_lh_yyb_capital` | `https://data.10jqka.com.cn/market/longhu/` |
| `stock_lh_yyb_control` | `https://data.10jqka.com.cn/market/longhu/` |
| `stock_lhb_detail_daily_sina` | `https://vip.stock.finance.sina.com.cn/q/go.php/vInvestConsult/kind/lhb/index.phtml` |
| `stock_lhb_ggtj_sina` | `https://vip.stock.finance.sina.com.cn/q/go.php/vLHBData/kind/ggtj/index.phtml` |
| `stock_lhb_yytj_sina` | `https://vip.stock.finance.sina.com.cn/q/go.php/vLHBData/kind/yytj/index.phtml` |
| `stock_lhb_jgzz_sina` | `https://vip.stock.finance.sina.com.cn/q/go.php/vLHBData/kind/jgzz/index.phtml` |
| `stock_lhb_jgmx_sina` | `https://vip.stock.finance.sina.com.cn/q/go.php/vLHBData/kind/jgzz/index.phtml` |
| `stock_ipo_declare_em` | `https://data.eastmoney.com/xg/xg/sbqy.html` |
| `stock_register_all_em` | `https://data.eastmoney.com/xg/ipo/` |
| `stock_register_kcb` | `https://data.eastmoney.com/xg/ipo/` |
| `stock_register_cyb` | `https://data.eastmoney.com/xg/ipo/` |
| `stock_register_sh` | `https://data.eastmoney.com/xg/ipo/` |
| `stock_register_sz` | `https://data.eastmoney.com/xg/ipo/` |
| `stock_register_bj` | `https://data.eastmoney.com/xg/ipo/` |
| `stock_register_db` | `https://data.eastmoney.com/xg/cyb/` |
| `stock_qbzf_em` | `https://data.eastmoney.com/other/gkzf.html` |
| `stock_pg_em` | `https://data.eastmoney.com/xg/pg/` |
| `stock_repurchase_em` | `https://data.eastmoney.com/gphg/hglist.html` |
| `stock_zh_a_gbjg_em` | `https://emweb.securities.eastmoney.com/pc_hsf10/pages/index.html#/gbjg` |
| `stock_dzjy_sctj` | `https://data.eastmoney.com/dzjy/dzjy_sctj.html` |
| `stock_dzjy_mrmx` | `https://data.eastmoney.com/dzjy/dzjy_mrmx.html` |
| `stock_dzjy_mrtj` | `https://data.eastmoney.com/dzjy/dzjy_mrtj.html` |
| `stock_dzjy_hygtj` | `https://data.eastmoney.com/dzjy/dzjy_hygtj.html` |
| `stock_dzjy_hyyybtj` | `https://data.eastmoney.com/dzjy/dzjy_hyyybtj.html` |
| `stock_dzjy_yybph` | `https://data.eastmoney.com/dzjy/dzjy_yybph.html` |
| `stock_yzxdr_em` | `http://data.eastmoney.com/yzxdr/` |
| `stock_margin_ratio_pa` | `https://stock.pingan.com/static/webinfo/margin/business.html?businessType=0` |
| `stock_margin_account_info` | `https://data.eastmoney.com/rzrq/zhtjday.html` |
| `stock_margin_sse` | `http://www.sse.com.cn/market/othersdata/margin/sum/` |
| `stock_margin_detail_sse` | `http://www.sse.com.cn/market/othersdata/margin/detail/` |
| `stock_margin_szse` | `https://www.szse.cn/disclosure/margin/margin/index.html` |
| `stock_margin_detail_szse` | `https://www.szse.cn/disclosure/margin/margin/index.html` |
| `stock_margin_underlying_info_szse` | `https://www.szse.cn/disclosure/margin/object/index.html` |
| `stock_profit_forecast_em` | `http://data.eastmoney.com/report/profitforecast.jshtml` |
| `stock_hk_profit_forecast_et` | `https://www.etnet.com.hk/www/sc/stocks/realtime/quote_profit.php?code=9999` |
| `stock_profit_forecast_ths` | `http://basic.10jqka.com.cn/new/600519/worth.html` |
| `stock_board_concept_index_ths` | `https://q.10jqka.com.cn/gn/detail/code/301558` |
| `stock_board_concept_info_ths` | `http://q.10jqka.com.cn/gn/detail/code/301558/` |
| `stock_board_concept_name_em` | `https://quote.eastmoney.com/center/boardlist.html#concept_board` |
| `stock_board_concept_spot_em` | `https://quote.eastmoney.com/bk/90.BK0818.html` |
| `stock_board_concept_cons_em` | `http://quote.eastmoney.com/center/boardlist.html#boards-BK06551` |
| `stock_board_concept_hist_em` | `http://quote.eastmoney.com/bk/90.BK0715.html` |
| `stock_board_concept_hist_min_em` | `http://quote.eastmoney.com/bk/90.BK0715.html` |
| `stock_concept_cons_futu` | `https://www.futunn.com/quote/sparks-us` |
| `stock_board_industry_summary_ths` | `https://q.10jqka.com.cn/thshy/` |
| `stock_board_industry_index_ths` | `https://q.10jqka.com.cn/thshy/detail/code/881270/` |
| `stock_board_industry_name_em` | `https://quote.eastmoney.com/center/boardlist.html#industry_board` |
| `stock_board_industry_spot_em` | `https://quote.eastmoney.com/bk/90.BK1027.html` |
| `stock_board_industry_cons_em` | `https://data.eastmoney.com/bkzj/BK1027.html` |
| `stock_board_industry_hist_em` | `https://quote.eastmoney.com/bk/90.BK1027.html` |
| `stock_board_industry_hist_min_em` | `http://quote.eastmoney.com/bk/90.BK1027.html` |
| `stock_hot_follow_xq` | `https://xueqiu.com/hq` |
| `stock_hot_tweet_xq` | `https://xueqiu.com/hq` |
| `stock_hot_deal_xq` | `https://xueqiu.com/hq` |
| `stock_hot_rank_em` | `http://guba.eastmoney.com/rank/` |
| `stock_hot_up_em` | `http://guba.eastmoney.com/rank/` |
| `stock_hk_hot_rank_em` | `https://guba.eastmoney.com/rank/` |
| `stock_hot_rank_detail_em` | `http://guba.eastmoney.com/rank/stock?code=000665` |
| `stock_hk_hot_rank_detail_em` | `https://guba.eastmoney.com/rank/stock?code=HK_00700` |
| `stock_irm_cninfo` | `https://irm.cninfo.com.cn/` |
| `stock_irm_ans_cninfo` | `https://irm.cninfo.com.cn/` |
| `stock_sns_sseinfo` | `https://sns.sseinfo.com/company.do?uid=65` |
| `stock_hot_rank_detail_realtime_em` | `http://guba.eastmoney.com/rank/stock?code=000665` |
| `stock_hk_hot_rank_detail_realtime_em` | `https://guba.eastmoney.com/rank/stock?code=HK_00700` |
| `stock_hot_keyword_em` | `http://guba.eastmoney.com/rank/stock?code=000665` |
| `stock_inner_trade_xq` | `https://xueqiu.com/hq/insider` |
| `stock_hot_rank_latest_em` | `http://guba.eastmoney.com/rank/stock?code=000665` |
| `stock_hk_hot_rank_latest_em` | `https://guba.eastmoney.com/rank/stock?code=HK_00700` |
| `stock_hot_search_baidu` | `https://gushitong.baidu.com/expressnews` |
| `stock_hot_rank_relate_em` | `http://guba.eastmoney.com/rank/stock?code=000665` |
| `stock_changes_em` | `http://quote.eastmoney.com/changes/` |
| `stock_board_change_em` | `https://quote.eastmoney.com/changes/` |
| `stock_zt_pool_em` | `https://quote.eastmoney.com/ztb/detail#type=ztgc` |
| `stock_zt_pool_previous_em` | `https://quote.eastmoney.com/ztb/detail#type=zrzt` |
| `stock_zt_pool_strong_em` | `https://quote.eastmoney.com/ztb/detail#type=qsgc` |
| `stock_zt_pool_sub_new_em` | `https://quote.eastmoney.com/ztb/detail#type=cxgc` |
| `stock_zt_pool_zbgc_em` | `https://quote.eastmoney.com/ztb/detail#type=zbgc` |
| `stock_zt_pool_dtgc_em` | `https://quote.eastmoney.com/ztb/detail#type=zbgc` |
| `stock_market_activity_legu` | `https://www.legulegu.com/stockdata/market-activity` |
| `stock_rank_cxfl_ths` | `https://data.10jqka.com.cn/rank/cxfl/` |
| `stock_rank_cxsl_ths` | `https://data.10jqka.com.cn/rank/cxsl/` |
| `stock_rank_xstp_ths` | `https://data.10jqka.com.cn/rank/xstp/` |
| `stock_rank_xxtp_ths` | `https://data.10jqka.com.cn/rank/xxtp/` |
| `stock_rank_ljqs_ths` | `https://data.10jqka.com.cn/rank/ljqs/` |
| `stock_rank_ljqd_ths` | `https://data.10jqka.com.cn/rank/ljqd/` |
| `stock_rank_xzjp_ths` | `https://data.10jqka.com.cn/financial/xzjp/` |
| `stock_esg_rate_sina` | `https://finance.sina.com.cn/esg/grade.shtml` |
| `stock_esg_msci_sina` | `https://finance.sina.com.cn/esg/grade.shtml` |
| `stock_esg_rft_sina` | `https://finance.sina.com.cn/esg/grade.shtml` |
| `stock_esg_zd_sina` | `https://finance.sina.com.cn/esg/grade.shtml` |
| `stock_esg_hz_sina` | `https://finance.sina.com.cn/esg/grade.shtml` |

## 宏观数据

| 函数 | 目标地址 |
|------|---------|
| `macro_cnbs` | `http://114.115.232.154:8080/` |
| `macro_china_qyspjg` | `http://data.eastmoney.com/cjsj/qyspjg.html` |
| `macro_china_fdi` | `https://data.eastmoney.com/cjsj/fdi.html` |
| `macro_china_lpr` | `https://data.eastmoney.com/cjsj/globalRateLPR.html` |
| `macro_china_urban_unemployment` | `https://data.stats.gov.cn/easyquery.htm?cn=A01&zb=A0203&sj=202304` |
| `macro_china_shrzgm` | `http://data.mofcom.gov.cn/gnmy/shrzgm.shtml` |
| `macro_china_gdp_yearly` | `https://datacenter.jin10.com/reportType/dc_chinese_gdp_yoy` |
| `macro_china_cpi_yearly` | `https://datacenter.jin10.com/reportType/dc_chinese_cpi_yoy` |
| `macro_china_cpi_monthly` | `https://datacenter.jin10.com/reportType/dc_chinese_cpi_mom` |
| `macro_china_ppi_yearly` | `https://datacenter.jin10.com/reportType/dc_chinese_ppi_yoy` |
| `macro_china_exports_yoy` | `https://datacenter.jin10.com/reportType/dc_chinese_exports_yoy` |
| `macro_china_imports_yoy` | `https://datacenter.jin10.com/reportType/dc_chinese_imports_yoy` |
| `macro_china_trade_balance` | `https://datacenter.jin10.com/reportType/dc_chinese_trade_balance` |
| `macro_china_gyzjz` | `https://data.eastmoney.com/cjsj/gyzjz.html` |
| `macro_china_industrial_production_yoy` | `https://datacenter.jin10.com/reportType/dc_chinese_industrial_production_yoy` |
| `macro_china_pmi_yearly` | `https://datacenter.jin10.com/reportType/dc_chinese_manufacturing_pmi` |
| `macro_china_cx_pmi_yearly` | `https://datacenter.jin10.com/reportType/dc_chinese_caixin_manufacturing_pmi` |
| `macro_china_cx_services_pmi_yearly` | `https://datacenter.jin10.com/reportType/dc_chinese_caixin_services_pmi` |
| `macro_china_non_man_pmi` | `https://datacenter.jin10.com/reportType/dc_chinese_non_manufacturing_pmi` |
| `macro_china_fx_reserves_yearly` | `https://datacenter.jin10.com/reportType/dc_chinese_fx_reserves` |
| `macro_china_m2_yearly` | `https://datacenter.jin10.com/reportType/dc_chinese_m2_money_supply_yoy` |
| `macro_china_new_house_price` | `http://data.eastmoney.com/cjsj/newhouse.html` |
| `macro_china_enterprise_boom_index` | `http://data.eastmoney.com/cjsj/qyjqzs.html` |
| `macro_china_national_tax_receipts` | `http://data.eastmoney.com/cjsj/nationaltaxreceipts.aspx` |
| `macro_china_bank_financing` | `https://data.eastmoney.com/cjsj/hyzs_list_EMI01516267.html` |
| `macro_china_insurance_income` | `https://data.eastmoney.com/cjsj/hyzs_list_EMM00088870.html` |
| `macro_china_mobile_number` | `https://data.eastmoney.com/cjsj/hyzs_list_EMI00225823.html` |
| `macro_china_vegetable_basket` | `https://data.eastmoney.com/cjsj/hyzs_list_EMI00009275.html` |
| `macro_china_agricultural_product` | `https://data.eastmoney.com/cjsj/hyzs_list_EMI00009274.html` |
| `macro_china_agricultural_index` | `https://data.eastmoney.com/cjsj/hyzs_list_EMI00662543.html` |
| `macro_china_energy_index` | `https://data.eastmoney.com/cjsj/hyzs_list_EMI00662539.html` |
| `macro_china_commodity_price_index` | `https://data.eastmoney.com/cjsj/hyzs_list_EMI00662535.html` |
| `macro_global_sox_index` | `https://data.eastmoney.com/cjsj/hyzs_list_EMI00055562.html` |
| `macro_china_yw_electronic_index` | `https://data.eastmoney.com/cjsj/hyzs_list_EMI00055551.html` |
| `macro_china_construction_index` | `https://data.eastmoney.com/cjsj/hyzs_list_EMI00662541.html` |
| `macro_china_construction_price_index` | `https://data.eastmoney.com/cjsj/hyzs_list_EMI00237146.html` |
| `macro_china_lpi_index` | `https://data.eastmoney.com/cjsj/hyzs_list_EMI00352262.html` |
| `macro_china_bdti_index` | `https://data.eastmoney.com/cjsj/hyzs_list_EMI00107668.html` |
| `macro_china_bsi_index` | `https://data.eastmoney.com/cjsj/hyzs_list_EMI00107667.html` |
| `macro_shipping_bci` | `https://data.eastmoney.com/cjsj/hyzs_list_EMI00107666.html` |
| `macro_shipping_bdi` | `https://data.eastmoney.com/cjsj/hyzs_list_EMI00107664.html` |
| `macro_shipping_bpi` | `https://data.eastmoney.com/cjsj/hyzs_list_EMI00107665.html` |
| `macro_shipping_bcti` | `https://data.eastmoney.com/cjsj/hyzs_list_EMI00107669.html` |
| `macro_china_new_financial_credit` | `http://data.eastmoney.com/cjsj/xzxd.html` |
| `macro_china_cpi` | `http://data.eastmoney.com/cjsj/cpi.html` |
| `macro_china_gdp` | `http://data.eastmoney.com/cjsj/gdp.html` |
| `macro_china_ppi` | `http://data.eastmoney.com/cjsj/ppi.html` |
| `macro_china_pmi` | `http://data.eastmoney.com/cjsj/pmi.html` |
| `macro_china_gdzctz` | `http://data.eastmoney.com/cjsj/gdzctz.html` |
| `macro_china_hgjck` | `https://data.eastmoney.com/cjsj/hgjck.html` |
| `macro_china_czsr` | `http://data.eastmoney.com/cjsj/czsr.html` |
| `macro_china_whxd` | `http://data.eastmoney.com/cjsj/whxd.html` |
| `macro_china_wbck` | `http://data.eastmoney.com/cjsj/wbck.html` |
| `macro_china_bond_public` | `https://www.chinamoney.com.cn/chinese/xzjfx/` |
| `macro_china_xfzxx` | `https://data.eastmoney.com/cjsj/xfzxx.html` |
| `macro_china_reserve_requirement_ratio` | `https://data.eastmoney.com/cjsj/ckzbj.html` |
| `macro_china_consumer_goods_retail` | `http://data.eastmoney.com/cjsj/xfp.html` |
| `macro_china_society_electricity` | `http://finance.sina.com.cn/mac/#industry-6-0-31-1` |
| `macro_china_society_traffic_volume` | `http://finance.sina.com.cn/mac/#industry-10-0-31-1` |
| `macro_china_postal_telecommunicational` | `http://finance.sina.com.cn/mac/#industry-11-0-31-1` |
| `macro_china_international_tourism_fx` | `http://finance.sina.com.cn/mac/#industry-15-0-31-3` |
| `macro_china_passenger_load_factor` | `http://finance.sina.com.cn/mac/#industry-20-0-31-1` |
| `macro_china_freight_index` | `http://finance.sina.com.cn/mac/#industry-22-0-31-2` |
| `macro_china_central_bank_balance` | `http://finance.sina.com.cn/mac/#fininfo-8-0-31-2` |
| `macro_china_insurance` | `http://finance.sina.com.cn/mac/#fininfo-19-0-31-3` |
| `macro_china_supply_of_money` | `http://finance.sina.com.cn/mac/#fininfo-1-0-31-1` |
| `macro_china_swap_rate` | `https://www.chinamoney.com.cn/chinese/bkcurvfxhis/?cfgItemType=72&curveType=FR007` |
| `macro_china_foreign_exchange_gold` | `http://finance.sina.com.cn/mac/#fininfo-5-0-31-2` |
| `macro_china_retail_price_index` | `http://finance.sina.com.cn/mac/#price-12-0-31-1` |
| `macro_china_real_estate` | `http://data.eastmoney.com/cjsj/hyzs_list_EMM00121987.html` |
| `macro_china_fx_gold` | `http://data.eastmoney.com/cjsj/hjwh.html` |
| `macro_china_money_supply` | `http://data.eastmoney.com/cjsj/hbgyl.html` |
| `macro_china_stock_market_cap` | `http://data.eastmoney.com/cjsj/gpjytj.html` |
| `macro_china_shibor_all` | `https://datacenter.jin10.com/reportType/dc_shibor` |
| `macro_china_hk_market_info` | `https://datacenter.jin10.com/reportType/dc_hk_market_info` |
| `macro_china_daily_energy` | `https://datacenter.jin10.com/reportType/dc_qihuo_energy_report` |
| `macro_china_rmb` | `https://datacenter.jin10.com/reportType/dc_rmb_data` |
| `macro_china_market_margin_sz` | `https://datacenter.jin10.com/reportType/dc_market_margin_sz` |
| `macro_china_market_margin_sh` | `https://datacenter.jin10.com/reportType/dc_market_margin_sse` |
| `macro_china_au_report` | `https://datacenter.jin10.com/reportType/dc_sge_report` |
| `macro_china_nbs_nation` | `https://data.stats.gov.cn/easyquery.htm` |
| `macro_china_nbs_region` | `https://data.stats.gov.cn/easyquery.htm` |
| `macro_stock_finance` | `https://data.10jqka.com.cn/macro/finance/` |
| `macro_rmb_loan` | `https://data.10jqka.com.cn/macro/loan/` |
| `macro_rmb_deposit` | `https://data.10jqka.com.cn/macro/rmb/` |
| `macro_china_hk_cpi` | `https://data.eastmoney.com/cjsj/foreign_8_0.html` |
| `macro_china_hk_cpi_ratio` | `https://data.eastmoney.com/cjsj/foreign_8_1.html` |
| `macro_china_hk_rate_of_unemployment` | `https://data.eastmoney.com/cjsj/foreign_8_2.html` |
| `macro_china_hk_gbp` | `https://data.eastmoney.com/cjsj/foreign_8_3.html` |
| `macro_china_hk_gbp_ratio` | `https://data.eastmoney.com/cjsj/foreign_8_4.html` |
| `macro_china_hk_building_volume` | `https://data.eastmoney.com/cjsj/foreign_8_5.html` |
| `macro_china_hk_building_amount` | `https://data.eastmoney.com/cjsj/foreign_8_6.html` |
| `macro_china_hk_trade_diff_ratio` | `https://data.eastmoney.com/cjsj/foreign_8_7.html` |
| `macro_china_hk_ppi` | `https://data.eastmoney.com/cjsj/foreign_8_8.html` |
| `macro_usa_gdp_monthly` | `https://datacenter.jin10.com/reportType/dc_usa_gdp` |
| `macro_usa_cpi_monthly` | `https://datacenter.jin10.com/reportType/dc_usa_cpi` |
| `macro_usa_cpi_yoy` | `https://data.eastmoney.com/cjsj/foreign_0_12.html` |
| `macro_usa_core_cpi_monthly` | `https://datacenter.jin10.com/reportType/dc_usa_core_cpi` |
| `macro_usa_personal_spending` | `https://datacenter.jin10.com/reportType/dc_usa_personal_spending` |
| `macro_usa_retail_sales` | `https://datacenter.jin10.com/reportType/dc_usa_retail_sales` |
| `macro_usa_import_price` | `https://datacenter.jin10.com/reportType/dc_usa_import_price` |
| `macro_usa_export_price` | `https://datacenter.jin10.com/reportType/dc_usa_export_price` |
| `macro_usa_lmci` | `https://datacenter.jin10.com/reportType/dc_usa_lmci` |
| `macro_usa_unemployment_rate` | `https://datacenter.jin10.com/reportType/dc_usa_unemployment_rate` |
| `macro_usa_job_cuts` | `https://datacenter.jin10.com/reportType/dc_usa_job_cuts` |
| `macro_usa_non_farm` | `https://datacenter.jin10.com/reportType/dc_nonfarm_payrolls` |
| `macro_usa_adp_employment` | `https://datacenter.jin10.com/reportType/dc_adp_nonfarm_employment` |
| `macro_usa_core_pce_price` | `https://datacenter.jin10.com/reportType/dc_usa_core_pce_price` |
| `macro_usa_real_consumer_spending` | `https://datacenter.jin10.com/reportType/dc_usa_real_consumer_spending` |
| `macro_usa_trade_balance` | `https://datacenter.jin10.com/reportType/dc_usa_trade_balance` |
| `macro_usa_current_account` | `https://datacenter.jin10.com/reportType/dc_usa_current_account` |
| `macro_usa_rig_count` | `https://datacenter.jin10.com/reportType/dc_rig_count_summary` |
| `macro_usa_ppi` | `https://datacenter.jin10.com/reportType/dc_usa_ppi` |
| `macro_usa_core_ppi` | `https://datacenter.jin10.com/reportType/dc_usa_core_ppi` |
| `macro_usa_api_crude_stock` | `https://datacenter.jin10.com/reportType/dc_usa_api_crude_stock` |
| `macro_usa_pmi` | `https://datacenter.jin10.com/reportType/dc_usa_pmi` |
| `macro_usa_ism_pmi` | `https://datacenter.jin10.com/reportType/dc_usa_ism_pmi` |
| `macro_usa_industrial_production` | `https://datacenter.jin10.com/reportType/dc_usa_industrial_production` |
| `macro_usa_durable_goods_orders` | `https://datacenter.jin10.com/reportType/dc_usa_durable_goods_orders` |
| `macro_usa_factory_orders` | `https://datacenter.jin10.com/reportType/dc_usa_factory_orders` |
| `macro_usa_services_pmi` | `https://datacenter.jin10.com/reportType/dc_usa_services_pmi` |
| `macro_usa_business_inventories` | `https://datacenter.jin10.com/reportType/dc_usa_business_inventories` |
| `macro_usa_ism_non_pmi` | `https://datacenter.jin10.com/reportType/dc_usa_ism_non_pmi` |
| `macro_usa_nahb_house_market_index` | `https://datacenter.jin10.com/reportType/dc_usa_nahb_house_market_index` |
| `macro_usa_house_starts` | `https://datacenter.jin10.com/reportType/dc_usa_house_starts` |
| `macro_usa_new_home_sales` | `https://datacenter.jin10.com/reportType/dc_usa_new_home_sales` |
| `macro_usa_building_permits` | `https://datacenter.jin10.com/reportType/dc_usa_building_permits` |
| `macro_usa_exist_home_sales` | `https://datacenter.jin10.com/reportType/dc_usa_exist_home_sales` |
| `macro_usa_house_price_index` | `https://datacenter.jin10.com/reportType/dc_usa_house_price_index` |
| `macro_usa_spcs20` | `https://datacenter.jin10.com/reportType/dc_usa_spcs20` |
| `macro_usa_pending_home_sales` | `https://datacenter.jin10.com/reportType/dc_usa_pending_home_sales` |
| `macro_usa_phs` | `http://data.eastmoney.com/cjsj/foreign_0_5.html` |
| `macro_usa_cb_consumer_confidence` | `https://cdn.jin10.com/dc/reports/dc_usa_cb_consumer_confidence_all.js?v=1578576859` |
| `macro_usa_nfib_small_business` | `https://cdn.jin10.com/dc/reports/dc_usa_nfib_small_business_all.js?v=1578576631` |
| `macro_usa_michigan_consumer_sentiment` | `https://cdn.jin10.com/dc/reports/dc_usa_michigan_consumer_sentiment_all.js?v=1578576228` |
| `macro_usa_eia_crude_rate` | `https://cdn.jin10.com/dc/reports/dc_usa_michigan_consumer_sentiment_all.js?v=1578576228` |
| `macro_usa_initial_jobless` | `https://cdn.jin10.com/dc/reports/dc_usa_michigan_consumer_sentiment_all.js?v=1578576228` |
| `macro_usa_crude_inner` | `https://datacenter.jin10.com/reportType/dc_eia_crude_oil_produce` |
| `macro_euro_gdp_yoy` | `https://datacenter.jin10.com/reportType/dc_eurozone_gdp_yoy` |
| `macro_euro_cpi_mom` | `https://datacenter.jin10.com/reportType/dc_eurozone_cpi_mom` |
| `macro_euro_cpi_yoy` | `https://datacenter.jin10.com/reportType/dc_eurozone_cpi_yoy` |
| `macro_euro_ppi_mom` | `https://datacenter.jin10.com/reportType/dc_eurozone_ppi_mom` |
| `macro_euro_retail_sales_mom` | `https://datacenter.jin10.com/reportType/dc_eurozone_retail_sales_mom` |
| `macro_euro_employment_change_qoq` | `https://datacenter.jin10.com/reportType/dc_eurozone_employment_change_qoq` |
| `macro_euro_unemployment_rate_mom` | `https://datacenter.jin10.com/reportType/dc_eurozone_unemployment_rate_mom` |
| `macro_euro_trade_balance` | `https://datacenter.jin10.com/reportType/dc_eurozone_trade_balance_mom` |
| `macro_euro_current_account_mom` | `https://datacenter.jin10.com/reportType/dc_eurozone_current_account_mom` |
| `macro_euro_industrial_production_mom` | `https://datacenter.jin10.com/reportType/dc_eurozone_industrial_production_mom` |
| `macro_euro_manufacturing_pmi` | `https://datacenter.jin10.com/reportType/dc_eurozone_manufacturing_pmi` |
| `macro_euro_services_pmi` | `https://datacenter.jin10.com/reportType/dc_eurozone_services_pmi` |
| `macro_euro_zew_economic_sentiment` | `https://datacenter.jin10.com/reportType/dc_eurozone_zew_economic_sentiment` |
| `macro_euro_sentix_investor_confidence` | `https://datacenter.jin10.com/reportType/dc_eurozone_sentix_investor_confidence` |
| `macro_germany_ifo` | `https://data.eastmoney.com/cjsj/foreign_1_0.html` |
| `macro_germany_cpi_monthly` | `https://data.eastmoney.com/cjsj/foreign_1_1.html` |
| `macro_germany_cpi_yearly` | `https://data.eastmoney.com/cjsj/foreign_1_2.html` |
| `macro_germany_trade_adjusted` | `https://data.eastmoney.com/cjsj/foreign_1_3.html` |
| `macro_germany_gdp` | `https://data.eastmoney.com/cjsj/foreign_1_4.html` |
| `macro_germany_retail_sale_monthly` | `https://data.eastmoney.com/cjsj/foreign_1_5.html` |
| `macro_germany_retail_sale_yearly` | `https://data.eastmoney.com/cjsj/foreign_1_6.html` |
| `macro_germany_zew` | `https://data.eastmoney.com/cjsj/foreign_1_7.html` |
| `macro_swiss_svme` | `http://data.eastmoney.com/cjsj/foreign_2_0.html` |
| `macro_swiss_trade` | `http://data.eastmoney.com/cjsj/foreign_2_1.html` |
| `macro_swiss_cpi_yearly` | `http://data.eastmoney.com/cjsj/foreign_2_2.html` |
| `macro_swiss_gdp_quarterly` | `http://data.eastmoney.com/cjsj/foreign_2_3.html` |
| `macro_swiss_gbd_yearly` | `http://data.eastmoney.com/cjsj/foreign_2_4.html` |
| `macro_swiss_gbd_bank_rate` | `http://data.eastmoney.com/cjsj/foreign_2_5.html` |
| `macro_japan_bank_rate` | `http://data.eastmoney.com/cjsj/foreign_3_0.html` |
| `macro_japan_cpi_yearly` | `http://data.eastmoney.com/cjsj/foreign_3_1.html` |
| `macro_japan_core_cpi_yearly` | `http://data.eastmoney.com/cjsj/foreign_2_2.html` |
| `macro_japan_unemployment_rate` | `http://data.eastmoney.com/cjsj/foreign_2_3.html` |
| `macro_japan_head_indicator` | `http://data.eastmoney.com/cjsj/foreign_3_4.html` |
| `macro_uk_halifax_monthly` | `http://data.eastmoney.com/cjsj/foreign_4_0.html` |
| `macro_uk_halifax_yearly` | `http://data.eastmoney.com/cjsj/foreign_4_1.html` |
| `macro_uk_trade` | `http://data.eastmoney.com/cjsj/foreign_4_2.html` |
| `macro_uk_bank_rate` | `http://data.eastmoney.com/cjsj/foreign_4_3.html` |
| `macro_uk_core_cpi_yearly` | `http://data.eastmoney.com/cjsj/foreign_4_4.html` |
| `macro_uk_core_cpi_monthly` | `http://data.eastmoney.com/cjsj/foreign_4_7.html` |
| `macro_uk_cpi_yearly` | `http://data.eastmoney.com/cjsj/foreign_4_6.html` |
| `macro_uk_cpi_monthly` | `http://data.eastmoney.com/cjsj/foreign_4_7.html` |
| `macro_uk_retail_monthly` | `http://data.eastmoney.com/cjsj/foreign_4_8.html` |
| `macro_uk_retail_yearly` | `http://data.eastmoney.com/cjsj/foreign_4_9.html` |
| `macro_uk_rightmove_yearly` | `http://data.eastmoney.com/cjsj/foreign_4_10.html` |
| `macro_uk_rightmove_monthly` | `http://data.eastmoney.com/cjsj/foreign_4_11.html` |
| `macro_uk_gdp_quarterly` | `http://data.eastmoney.com/cjsj/foreign_4_12.html` |
| `macro_uk_gdp_yearly` | `http://data.eastmoney.com/cjsj/foreign_4_13.html` |
| `macro_uk_unemployment_rate` | `http://data.eastmoney.com/cjsj/foreign_4_14.html` |
| `macro_australia_retail_rate_monthly` | `http://data.eastmoney.com/cjsj/foreign_5_0.html` |
| `macro_australia_trade` | `http://data.eastmoney.com/cjsj/foreign_5_1.html` |
| `macro_australia_unemployment_rate` | `http://data.eastmoney.com/cjsj/foreign_5_2.html` |
| `macro_australia_ppi_quarterly` | `http://data.eastmoney.com/cjsj/foreign_5_3.html` |
| `macro_australia_cpi_quarterly` | `http://data.eastmoney.com/cjsj/foreign_5_4.html` |
| `macro_australia_cpi_yearly` | `http://data.eastmoney.com/cjsj/foreign_5_5.html` |
| `macro_australia_bank_rate` | `http://data.eastmoney.com/cjsj/foreign_5_6.html` |
| `macro_canada_new_house_rate` | `http://data.eastmoney.com/cjsj/foreign_7_0.html` |
| `macro_canada_unemployment_rate` | `http://data.eastmoney.com/cjsj/foreign_7_1.html` |
| `macro_canada_trade` | `http://data.eastmoney.com/cjsj/foreign_7_2.html` |
| `macro_canada_retail_rate_monthly` | `http://data.eastmoney.com/cjsj/foreign_7_3.html` |
| `macro_canada_bank_rate` | `http://data.eastmoney.com/cjsj/foreign_7_4.html` |
| `macro_canada_core_cpi_yearly` | `http://data.eastmoney.com/cjsj/foreign_7_5.html` |
| `macro_canada_core_cpi_monthly` | `http://data.eastmoney.com/cjsj/foreign_7_6.html` |
| `macro_canada_cpi_yearly` | `http://data.eastmoney.com/cjsj/foreign_7_7.html` |
| `macro_canada_cpi_monthly` | `http://data.eastmoney.com/cjsj/foreign_7_8.html` |
| `macro_canada_gdp_monthly` | `http://data.eastmoney.com/cjsj/foreign_7_9.html` |
| `macro_cons_gold` | `https://datacenter.jin10.com/reportType/dc_etf_gold` |
| `macro_cons_silver` | `https://datacenter.jin10.com/reportType/dc_etf_sliver` |
| `macro_cons_opec_month` | `https://datacenter.jin10.com/reportType/dc_opec_report` |
| `macro_euro_lme_holding` | `https://datacenter.jin10.com/reportType/dc_lme_traders_report` |
| `macro_euro_lme_stock` | `https://datacenter.jin10.com/reportType/dc_lme_report` |
| `macro_usa_cftc_nc_holding` | `https://datacenter.jin10.com/reportType/dc_cftc_nc_report` |
| `macro_usa_cftc_c_holding` | `https://datacenter.jin10.com/reportType/dc_cftc_c_report` |
| `macro_usa_cftc_merchant_currency_holding` | `https://datacenter.jin10.com/reportType/dc_cftc_merchant_currency` |
| `macro_usa_cftc_merchant_goods_holding` | `https://datacenter.jin10.com/reportType/dc_cftc_merchant_goods` |
| `macro_usa_cme_merchant_goods_holding` | `https://datacenter.jin10.com/org` |
| `macro_info_ws` | `https://wallstreetcn.com/calendar` |
| `news_economic_baidu` | `https://gushitong.baidu.com/calendar` |

## 基金

| 函数 | 目标地址 |
|------|---------|
| `fund_name_em` | `http://fund.eastmoney.com/fund.html` |
| `fund_individual_basic_info_xq` | `https://danjuanfunds.com/funding/000001` |
| `fund_info_index_em` | `http://fund.eastmoney.com/trade/zs.html` |
| `fund_purchase_em` | `http://fund.eastmoney.com/Fund_sgzt_bzdm.html#fcode,asc_1` |
| `fund_etf_spot_em` | `https://quote.eastmoney.com/center/gridlist.html#fund_etf` |
| `fund_etf_category_ths` | `https://fund.10jqka.com.cn/datacenter/jz/kfs/etf/` |
| `fund_etf_spot_ths` | `https://fund.10jqka.com.cn/datacenter/jz/kfs/etf/` |
| `fund_lof_spot_em` | `https://quote.eastmoney.com/center/gridlist.html#fund_lof` |
| `fund_etf_category_sina` | `http://vip.stock.finance.sina.com.cn/fund_center/index.html#jjhqetf` |
| `fund_etf_hist_min_em` | `https://quote.eastmoney.com/sz159707.html` |
| `fund_lof_hist_min_em` | `https://quote.eastmoney.com/sz166009.html` |
| `fund_etf_hist_em` | `http://quote.eastmoney.com/sz159707.html` |
| `fund_lof_hist_em` | `https://quote.eastmoney.com/sz166009.html` |
| `fund_etf_hist_sina` | `http://vip.stock.finance.sina.com.cn/fund_center/index.html#jjhqetf` |
| `fund_open_fund_daily_em` | `http://fund.eastmoney.com/fund.html#os_0;isall_0;ft_;pt_1` |
| `fund_open_fund_info_em` | `http://fund.eastmoney.com/pingzhongdata/710001.js` |
| `fund_money_fund_daily_em` | `http://fund.eastmoney.com/HBJJ_pjsyl.html` |
| `fund_money_fund_info_em` | `https://fundf10.eastmoney.com/jjjz_000009.html` |
| `fund_financial_fund_daily_em` | `http://fund.eastmoney.com/lcjj.html#1_1__0__ljjz,desc_1_os1` |
| `fund_financial_fund_info_em` | `http://fundf10.eastmoney.com/jjjz_000791.html` |
| `fund_graded_fund_daily_em` | `http://fund.eastmoney.com/fjjj.html#1_1__0__zdf,desc_1` |
| `fund_graded_fund_info_em` | `http://fundf10.eastmoney.com/jjjz_004186.html` |
| `fund_etf_fund_daily_em` | `http://fund.eastmoney.com/cnjy_dwjz.html` |
| `fund_etf_fund_info_em` | `http://fundf10.eastmoney.com/jjjz_004186.html` |
| `fund_hk_fund_hist_em` | `http://overseas.1234567.com.cn/f10/FundJz/968092#FHPS` |
| `fund_etf_dividend_sina` | `https://finance.sina.com.cn/fund/quotes/510050/bc.shtml` |
| `fund_fh_em` | `http://fund.eastmoney.com/data/fundfenhong.html` |
| `fund_cf_em` | `http://fund.eastmoney.com/data/fundchaifen.html` |
| `fund_fh_rank_em` | `http://fund.eastmoney.com/data/fundleijifenhong.html` |
| `fund_open_fund_rank_em` | `https://fund.eastmoney.com/data/fundranking.html` |
| `fund_exchange_rank_em` | `https://fund.eastmoney.com/data/fbsfundranking.html` |
| `fund_money_rank_em` | `https://fund.eastmoney.com/data/hbxfundranking.html` |
| `fund_lcx_rank_em` | `https://fund.eastmoney.com/data/lcxfundranking.html#t;c0;r;sSYL_Z;ddesc;pn50;f;os1` |
| `fund_hk_rank_em` | `https://overseas.1234567.com.cn/FundList` |
| `fund_individual_achievement_xq` | `https://danjuanfunds.com/rn/funding/:code/RankInfo?symbol=000001&fd_type=2&btn_pos=1` |
| `fund_value_estimation_em` | `http://fund.eastmoney.com/fundguzhi.html` |
| `fund_individual_analysis_xq` | `https://danjuanfunds.com/funding/000001` |
| `fund_individual_profit_probability_xq` | `https://danjuanfunds.com/funding/000001` |
| `fund_individual_detail_hold_xq` | `https://danjuanfunds.com/rn/fund-detail/archive?id=103&code=000001` |
| `fund_overview_em` | `https://fundf10.eastmoney.com/jbgk_015641.html` |
| `fund_fee_em` | `https://fundf10.eastmoney.com/jjfl_015641.html` |
| `fund_individual_detail_info_xq` | `https://danjuanfunds.com/djapi/fund/detail/675091` |
| `fund_portfolio_hold_em` | `https://fundf10.eastmoney.com/ccmx_000001.html` |
| `fund_portfolio_bond_hold_em` | `https://fundf10.eastmoney.com/ccmx_000001.html` |
| `fund_portfolio_industry_allocation_em` | `https://fundf10.eastmoney.com/hytz_000001.html` |
| `fund_portfolio_change_em` | `https://fundf10.eastmoney.com/ccbd_000001.html` |
| `fund_rating_all` | `https://fund.eastmoney.com/data/fundrating.html` |
| `fund_rating_sh` | `https://fund.eastmoney.com/data/fundrating_3.html` |
| `fund_rating_zs` | `http://fund.eastmoney.com/data/fundrating_2.html` |
| `fund_rating_ja` | `https://fund.eastmoney.com/data/fundrating_4.html` |
| `fund_manager_em` | `https://fund.eastmoney.com/manager/default.html` |
| `fund_new_found_em` | `https://fund.eastmoney.com/data/xinfound.html` |
| `fund_new_found_ths` | `https://fund.10jqka.com.cn/datacenter/xfjj/` |
| `fund_scale_open_sina` | `https://vip.stock.finance.sina.com.cn/fund_center/index.html#jjhqetf` |
| `fund_scale_close_sina` | `https://vip.stock.finance.sina.com.cn/fund_center/index.html#jjhqetf` |
| `fund_scale_structured_sina` | `https://vip.stock.finance.sina.com.cn/fund_center/index.html#jjgmfjall` |
| `fund_etf_scale_sse` | `https://www.sse.com.cn/assortment/fund/etf/list/scale/` |
| `fund_etf_scale_szse` | `https://fund.szse.cn/marketdata/fundslist/index.html` |
| `fund_aum_em` | `https://fund.eastmoney.com/Company/lsgm.html` |
| `fund_aum_trend_em` | `http://fund.eastmoney.com/Company/default.html` |
| `fund_aum_hist_em` | `http://fund.eastmoney.com/Company/lsgm.html` |
| `reits_realtime_em` | `http://quote.eastmoney.com/center/gridlist.html#fund_reits_all` |
| `reits_hist_em` | `https://quote.eastmoney.com/sh508097.html` |
| `fund_report_stock_cninfo` | `https://webapi.cninfo.com.cn/#/thematicStatistics` |
| `fund_report_industry_allocation_cninfo` | `https://webapi.cninfo.com.cn/#/thematicStatistics` |
| `fund_report_asset_allocation_cninfo` | `https://webapi.cninfo.com.cn/#/thematicStatistics` |
| `fund_scale_change_em` | `https://fund.eastmoney.com/data/gmbdlist.html` |
| `fund_hold_structure_em` | `https://fund.eastmoney.com/data/cyrjglist.html` |
| `fund_stock_position_lg` | `https://legulegu.com/stockdata/fund-position/pos-stock` |
| `fund_balance_position_lg` | `https://legulegu.com/stockdata/fund-position/pos-pingheng` |
| `fund_linghuo_position_lg` | `https://legulegu.com/stockdata/fund-position/pos-linghuo` |
| `fund_announcement_dividend_em` | `https://fundf10.eastmoney.com/jjgg_000001_2.html` |
| `fund_announcement_report_em` | `https://fundf10.eastmoney.com/jjgg_000001_3.html` |
| `fund_announcement_personnel_em` | `http://fundf10.eastmoney.com/jjgg_000001_4.html` |
| `amac_member_info` | `https://gs.amac.org.cn/amac-infodisc/res/pof/member/index.html` |
| `amac_person_fund_org_list` | `https://gs.amac.org.cn/amac-infodisc/res/pof/person/personOrgList.html` |
| `amac_person_bond_org_list` | `https://gs.amac.org.cn/amac-infodisc/res/pof/person/personOrgList.html` |
| `amac_manager_info` | `https://gs.amac.org.cn/amac-infodisc/res/pof/manager/index.html` |
| `amac_manager_classify_info` | `https://gs.amac.org.cn/amac-infodisc/res/pof/manager/managerList.html` |
| `amac_member_sub_info` | `https://gs.amac.org.cn/amac-infodisc/res/pof/member/index.html?primaryInvestType=private` |
| `amac_fund_info` | `https://gs.amac.org.cn/amac-infodisc/res/pof/fund/index.html` |
| `amac_securities_info` | `https://gs.amac.org.cn/amac-infodisc/res/pof/securities/index.html` |
| `amac_aoin_info` | `https://gs.amac.org.cn/amac-infodisc/res/aoin/product/index.html` |
| `amac_fund_sub_info` | `https://gs.amac.org.cn/amac-infodisc/res/pof/subfund/index.html` |
| `amac_fund_account_info` | `https://gs.amac.org.cn/amac-infodisc/res/fund/account/index.html` |
| `amac_fund_abs` | `https://gs.amac.org.cn/amac-infodisc/res/fund/abs/index.html` |
| `amac_futures_info` | `https://gs.amac.org.cn/amac-infodisc/res/pof/futures/index.html` |
| `amac_manager_cancelled_info` | `https://gs.amac.org.cn/amac-infodisc/res/cancelled/manager/index.html` |

## 指数

| 函数 | 目标地址 |
|------|---------|
| `stock_zh_index_spot_em` | `https://quote.eastmoney.com/center/gridlist.html#index_sz` |
| `stock_zh_index_spot_sina` | `https://vip.stock.finance.sina.com.cn/mkt/#hs_s` |
| `stock_zh_index_daily` | `https://finance.sina.com.cn/realstock/company/sz399552/nc.shtml(示例)` |
| `stock_zh_index_daily_tx` | `https://gu.qq.com/sh000919/zs` |
| `stock_zh_index_daily_em` | `http://quote.eastmoney.com/center/hszs.html` |
| `index_zh_a_hist` | `http://quote.eastmoney.com/center/hszs.html` |
| `index_zh_a_hist_min_em` | `https://quote.eastmoney.com/center/hszs.html` |
| `stock_hk_index_spot_sina` | `https://vip.stock.finance.sina.com.cn/mkt/#zs_hk` |
| `stock_hk_index_daily_sina` | `https://stock.finance.sina.com.cn/hkstock/quotes/CES100.html` |
| `stock_hk_index_spot_em` | `https://quote.eastmoney.com/center/gridlist.html#hk_index` |
| `stock_hk_index_daily_em` | `https://quote.eastmoney.com/gb/zsHSTECF2L.html` |
| `index_us_stock_sina` | `https://stock.finance.sina.com.cn/usstock/quotes/.IXIC.html` |
| `index_global_spot_em` | `https://quote.eastmoney.com/center/gridlist.html#global_qtzs` |
| `index_global_hist_em` | `https://quote.eastmoney.com/gb/zsUDI.html` |
| `index_global_hist_sina` | `https://finance.sina.com.cn/stock/globalindex/quotes/UKX` |
| `index_stock_cons` | `http://vip.stock.finance.sina.com.cn/corp/view/vII_NewestComponent.php?page=1&indexid=399639` |
| `index_stock_cons_csindex` | `http://www.csindex.com.cn/zh-CN/indices/index-detail/000300` |
| `index_stock_cons_weight_csindex` | `http://www.csindex.com.cn/zh-CN/indices/index-detail/000300` |
| `index_all_cni` | `http://www.cnindex.com.cn/zh_indices/sese/index.html?act_menu=1&index_type=-1` |
| `index_hist_cni` | `http://www.cnindex.com.cn/module/index-detail.html?act_menu=1&indexCode=399001` |
| `index_detail_cni` | `http://www.cnindex.com.cn/module/index-detail.html?act_menu=1&indexCode=399001` |
| `index_detail_hist_cni` | `http://www.cnindex.com.cn/module/index-detail.html?act_menu=1&indexCode=399001` |
| `index_detail_hist_adjust_cni` | `http://www.cnindex.com.cn/module/index-detail.html?act_menu=1&indexCode=399001` |
| `index_option_50etf_qvix` | `http://1.optbbs.com/s/vix.shtml?50ETF` |
| `index_option_50etf_min_qvix` | `http://1.optbbs.com/s/vix.shtml?50ETF` |
| `index_option_300etf_qvix` | `https://1.optbbs.com/s/vix.shtml?300ETF` |
| `index_option_300etf_min_qvix` | `https://1.optbbs.com/s/vix.shtml?300ETF` |
| `index_option_500etf_qvix` | `http://1.optbbs.com/s/vix.shtml?500ETF` |
| `index_option_500etf_min_qvix` | `http://1.optbbs.com/s/vix.shtml?500ETF` |
| `index_option_cyb_qvix` | `http://1.optbbs.com/s/vix.shtml?CYB` |
| `index_option_cyb_min_qvix` | `http://1.optbbs.com/s/vix.shtml?CYB` |
| `index_option_kcb_qvix` | `http://1.optbbs.com/s/vix.shtml?KCB` |
| `index_option_kcb_min_qvix` | `http://1.optbbs.com/s/vix.shtml?KCB` |
| `index_option_100etf_qvix` | `http://1.optbbs.com/s/vix.shtml?100ETF` |
| `index_option_100etf_min_qvix` | `http://1.optbbs.com/s/vix.shtml?100ETF` |
| `index_option_300index_qvix` | `http://1.optbbs.com/s/vix.shtml?Index` |
| `index_option_300index_min_qvix` | `http://1.optbbs.com/s/vix.shtml?Index` |
| `index_option_1000index_qvix` | `http://1.optbbs.com/s/vix.shtml?Index1000` |
| `index_option_1000index_min_qvix` | `http://1.optbbs.com/s/vix.shtml?Index1000` |
| `index_option_50index_qvix` | `http://1.optbbs.com/s/vix.shtml?50index` |
| `index_option_50index_min_qvix` | `http://1.optbbs.com/s/vix.shtml?50index` |
| `sw_index_first_info` | `https://legulegu.com/stockdata/sw-industry-overview#level1` |
| `sw_index_second_info` | `https://legulegu.com/stockdata/sw-industry-overview#level1` |
| `sw_index_third_info` | `https://legulegu.com/stockdata/sw-industry-overview#level1` |
| `sw_index_third_cons` | `https://legulegu.com/stockdata/index-composition?industryCode=851921.SI` |
| `spot_goods` | `http://finance.sina.com.cn/futuremarket/spotprice.shtml#titlePos_0` |
| `index_yw` | `https://www.ywindex.com/Home/Product/index/` |
| `index_kq_fz` | `http://www.kqindex.cn/flzs/jiage` |
| `index_kq_fashion` | `http://ss.kqindex.cn:9559/rinder_web_kqsszs/index/index_page.do` |
| `index_sugar_msweet` | `http://www.msweet.com.cn/mtkj/sjzx13/index.html` |
| `index_inner_quote_sugar_msweet` | `http://www.msweet.com.cn/mtkj/sjzx13/index.html` |
| `index_outer_quote_sugar_msweet` | `http://www.msweet.com.cn/mtkj/sjzx13/index.html` |
| `index_eri` | `https://zs.zjpwq.net/` |
| `drewry_wci_index` | `https://infogram.com/world-container-index-1h17493095xl4zj` |
| `index_price_cflp` | `http://index.0256.cn/expx.htm` |
| `index_volume_cflp` | `http://index.0256.cn/expx.htm` |
| `stock_zh_index_hist_csindex` | `https://www.csindex.com.cn/zh-CN/indices/index-detail/H30374#/indices/family/detail?indexCode=H30374` |
| `index_pmi_com_cx` | `https://yun.ccxe.com.cn/indices/pmi` |
| `index_pmi_man_cx` | `https://yun.ccxe.com.cn/indices/pmi` |
| `index_pmi_ser_cx` | `https://yun.ccxe.com.cn/indices/pmi` |
| `index_dei_cx` | `https://yun.ccxe.com.cn/indices/dei` |
| `index_ii_cx` | `https://yun.ccxe.com.cn/indices/dei` |
| `index_si_cx` | `https://yun.ccxe.com.cn/indices/dei` |
| `index_fi_cx` | `https://yun.ccxe.com.cn/indices/dei` |
| `index_bi_cx` | `https://yun.ccxe.com.cn/indices/dei` |
| `index_nei_cx` | `https://yun.ccxe.com.cn/indices/nei` |
| `index_li_cx` | `https://yun.ccxe.com.cn/indices/nei` |
| `index_ci_cx` | `https://yun.ccxe.com.cn/indices/nei` |
| `index_ti_cx` | `https://yun.ccxe.com.cn/indices/nei` |
| `index_neaw_cx` | `https://yun.ccxe.com.cn/indices/nei` |
| `index_awpr_cx` | `https://yun.ccxe.com.cn/indices/nei` |
| `index_cci_cx` | `https://yun.ccxe.com.cn/indices/nei` |
| `index_qli_cx` | `https://yun.ccxe.com.cn/indices/qli` |
| `index_ai_cx` | `https://yun.ccxe.com.cn/indices/ai` |
| `index_bei_cx` | `https://yun.ccxe.com.cn/indices/bei` |
| `index_neei_cx` | `https://yun.ccxe.com.cn/indices/neei` |
| `stock_zh_index_value_csindex` | `https://www.csindex.com.cn/zh-CN/indices/index-detail/H30374#/indices/family/detail?indexCode=H30374` |
| `index_realtime_fund_sw` | `https://www.swsresearch.com/institute_sw/allIndex/releasedIndex` |
| `index_hist_fund_sw` | `https://www.swsresearch.com/institute_sw/allIndex/releasedIndex/fundDetail?code=807100` |
| `index_realtime_sw` | `https://www.swsresearch.com/institute_sw/allIndex/releasedIndex` |
| `index_hist_sw` | `https://www.swsresearch.com//institute_sw/allIndex/releasedIndex/releasedetail?code=801002&name=申万中小` |
| `index_min_sw` | `https://www.swsresearch.com//institute_sw/allIndex/releasedIndex/releasedetail?code=801001&name=申万中小` |
| `index_component_sw` | `https://www.swsresearch.com//institute_sw/allIndex/releasedIndex/releasedetail?code=801001&name=申万中小` |
| `index_analysis_daily_sw` | `https://www.swsresearch.com//institute_sw/allIndex/analysisIndex` |
| `index_analysis_weekly_sw` | `https://www.swsresearch.com//institute_sw/allIndex/analysisIndex` |
| `index_analysis_monthly_sw` | `https://www.swsresearch.com/institute_sw/allIndex/analysisIndex` |
| `index_news_sentiment_scope` | `https://www.chinascope.com/reasearch.html` |

## 期货

| 函数 | 目标地址 |
|------|---------|
| `futures_fees_info` | `http://openctp.cn/fees.html` |
| `futures_comm_info` | `https://www.9qihuo.com/qihuoshouxufei` |
| `futures_comm_js` | `https://www.jin10.com/` |
| `futures_rule` | `https://www.gtjaqh.com/pc/calendar.html` |
| `futures_inventory_99` | `https://www.99qh.com/data/stockIn?productId=61` |
| `futures_inventory_em` | `http://data.eastmoney.com/ifdata/kcsj.html` |
| `futures_dce_position_rank` | `http://www.dce.com.cn/dalianshangpin/xqsj/tjsj26/rtj/rcjccpm/index.html` |
| `futures_gfex_position_rank` | `http://www.gfex.com.cn/gfex/rcjccpm/hqsj_tjsj.shtml` |
| `futures_warehouse_receipt_czce` | `http://www.czce.com.cn/cn/jysj/cdrb/H770310index_1.htm` |
| `futures_warehouse_receipt_dce` | `http://www.dce.com.cn/dce/channel/list/187.html` |
| `futures_shfe_warehouse_receipt` | `https://tsite.shfe.com.cn/statements/dataview.html?paramid=dailystock&paramdate=20200703` |
| `futures_gfex_warehouse_receipt` | `http://www.gfex.com.cn/gfex/cdrb/hqsj_tjsj.shtml` |
| `futures_to_spot_dce` | `http://www.dce.com.cn/dalianshangpin/xqsj/tjsj26/jgtj/qzxcx/index.html` |
| `futures_to_spot_czce` | `http://www.czce.com.cn/cn/jysj/qzxtj/H770311index_1.htm` |
| `futures_to_spot_shfe` | `https://tsite.shfe.com.cn/statements/dataview.html?paramid=kx` |
| `futures_delivery_dce` | `http://www.dce.com.cn/dalianshangpin/xqsj/tjsj26/jgtj/jgsj/index.html` |
| `futures_delivery_czce` | `http://www.czce.com.cn/cn/jysj/ydjgcx/H770316index_1.htm` |
| `futures_delivery_shfe` | `https://tsite.shfe.com.cn/statements/dataview.html?paramid=kx` |
| `futures_delivery_match_dce` | `http://www.dce.com.cn/dalianshangpin/xqsj/tjsj26/jgtj/jgsj/index.html` |
| `futures_delivery_match_czce` | `http://www.czce.com.cn/cn/jysj/jgpd/H770308index_1.htm` |
| `futures_stock_shfe_js` | `https://datacenter.jin10.com/reportType/dc_shfe_weekly_stock` |
| `futures_hold_pos_sina` | `https://vip.stock.finance.sina.com.cn/q/view/vFutures_Positions_cjcc.php` |
| `futures_spot_sys` | `https://www.100ppi.com/sf/792.html` |
| `futures_contract_info_shfe` | `https://tsite.shfe.com.cn/bourseService/businessdata/summaryinquiry/` |
| `futures_contract_info_ine` | `https://www.ine.cn/bourseService/summary/?name=currinstrumentprop` |
| `futures_contract_info_dce` | `http://www.dce.com.cn/dce/channel/list/180.html` |
| `futures_contract_info_czce` | `http://www.czce.com.cn/cn/jysj/cksj/H770322index_1.htm` |
| `futures_contract_info_gfex` | `http://www.gfex.com.cn/gfex/hyxx/ywcs.shtml` |
| `futures_contract_info_cffex` | `http://www.gfex.com.cn/gfex/hyxx/ywcs.shtml` |
| `futures_zh_spot` | `https://finance.sina.com.cn/futuremarket/` |
| `futures_zh_realtime` | `https://vip.stock.finance.sina.com.cn/quotes_service/view/qihuohangqing.html#titlePos_1` |
| `futures_zh_minute_sina` | `http://vip.stock.finance.sina.com.cn/quotes_service/view/qihuohangqing.html#titlePos_3` |
| `futures_hist_em` | `https://qhweb.eastmoney.com/quote` |
| `futures_zh_daily_sina` | `https://finance.sina.com.cn/futures/quotes/V2105.shtml` |
| `futures_hq_subscribe_exchange_symbol` | `https://finance.sina.com.cn/money/future/hf.html` |
| `futures_foreign_commodity_realtime` | `https://finance.sina.com.cn/money/future/hf.html` |
| `futures_global_spot_em` | `https://quote.eastmoney.com/center/gridlist.html#futures_global` |
| `futures_global_hist_em` | `https://quote.eastmoney.com/globalfuture/HG25J.html` |
| `futures_foreign_hist` | `https://finance.sina.com.cn/futuremarket/` |
| `futures_foreign_detail` | `https://finance.sina.com.cn/futuremarket/` |
| `futures_settlement_price_sgx` | `https://www.sgx.com/zh-hans/research-education/derivatives` |
| `futures_main_sina` | `https://vip.stock.finance.sina.com.cn/quotes_service/view/qihuohangqing.html#titlePos_0` |
| `futures_contract_detail` | `https://finance.sina.com.cn/futures/quotes/V2101.shtml` |
| `futures_contract_detail_em` | `https://quote.eastmoney.com/qihuo/v2602F.html` |
| `futures_index_ccidx` | `http://www.ccidx.com/index.html` |
| `futures_spot_stock` | `https://data.eastmoney.com/ifdata/xhgp.html` |
| `futures_comex_inventory` | `https://data.eastmoney.com/pmetal/comex/by.html` |
| `futures_hog_core` | `https://zhujia.zhuwang.com.cn` |
| `futures_hog_cost` | `https://zhujia.zhuwang.com.cn` |
| `futures_hog_supply` | `https://zhujia.zhuwang.com.cn` |
| `index_hog_spot_price` | `https://hqb.nxin.com/pigindex/index.shtml` |
| `futures_news_shmet` | `https://www.shmet.com/newsFlash/newsFlash.html?searchKeyword=` |

## 期权

| 函数 | 目标地址 |
|------|---------|
| `option_contract_info_ctp` | `http://openctp.cn/instruments.html` |
| `option_risk_indicator_sse` | `http://www.sse.com.cn/assortment/options/risk/` |
| `option_current_day_sse` | `https://www.sse.com.cn/assortment/options/disclo/preinfo/` |
| `option_current_day_szse` | `https://www.sse.org.cn/option/quotation/contract/daycontract/index.html` |
| `option_daily_stats_sse` | `http://www.sse.com.cn/assortment/options/date/` |
| `option_daily_stats_szse` | `https://investor.szse.cn/market/option/day/index.html` |
| `option_cffex_sz50_list_sina` | `https://stock.finance.sina.com.cn/futures/view/optionsCffexDP.php/ho/cffex` |
| `option_cffex_hs300_list_sina` | `https://stock.finance.sina.com.cn/futures/view/optionsCffexDP.php` |
| `option_cffex_zz1000_list_sina` | `https://stock.finance.sina.com.cn/futures/view/optionsCffexDP.php` |
| `option_cffex_sz50_spot_sina` | `https://stock.finance.sina.com.cn/futures/view/optionsCffexDP.php/ho/cffex` |
| `option_cffex_hs300_spot_sina` | `https://stock.finance.sina.com.cn/futures/view/optionsCffexDP.php` |
| `option_cffex_zz1000_spot_sina` | `https://stock.finance.sina.com.cn/futures/view/optionsCffexDP.php` |
| `option_cffex_sz50_daily_sina` | `https://stock.finance.sina.com.cn/futures/view/optionsCffexDP.php/ho/cffex` |
| `option_cffex_hs300_daily_sina` | `https://stock.finance.sina.com.cn/futures/view/optionsCffexDP.php` |
| `option_cffex_zz1000_daily_sina` | `https://stock.finance.sina.com.cn/futures/view/optionsCffexDP.php` |
| `option_sse_list_sina` | `https://stock.finance.sina.com.cn/futures/view/optionsCffexDP.php` |
| `option_sse_expire_day_sina` | `https://stock.finance.sina.com.cn/futures/view/optionsCffexDP.php` |
| `option_sse_codes_sina` | `https://stock.finance.sina.com.cn/futures/view/optionsCffexDP.php` |
| `option_sse_spot_price_sina` | `https://stock.finance.sina.com.cn/futures/view/optionsCffexDP.php` |
| `option_sse_underlying_spot_price_sina` | `https://stock.finance.sina.com.cn/futures/view/optionsCffexDP.php` |
| `option_sse_greeks_sina` | `https://stock.finance.sina.com.cn/futures/view/optionsCffexDP.php` |
| `option_sse_minute_sina` | `https://stock.finance.sina.com.cn/futures/view/optionsCffexDP.php` |
| `option_sse_daily_sina` | `https://stock.finance.sina.com.cn/futures/view/optionsCffexDP.php` |
| `option_finance_minute_sina` | `https://stock.finance.sina.com.cn/option/quotes.html` |
| `option_minute_em` | `https://wap.eastmoney.com/quote/stock/151.cu2404P61000.html` |
| `option_current_em` | `https://quote.eastmoney.com/center/qqsc.html` |
| `option_lhb_em` | `https://data.eastmoney.com/other/qqlhb.html` |
| `option_value_analysis_em` | `https://data.eastmoney.com/other/valueAnal.html` |
| `option_risk_analysis_em` | `https://data.eastmoney.com/other/riskanal.html` |
| `option_premium_analysis_em` | `https://data.eastmoney.com/other/premium.html` |
| `option_commodity_contract_sina` | `https://stock.finance.sina.com.cn/futures/view/optionsDP.php` |
| `option_commodity_contract_table_sina` | `https://stock.finance.sina.com.cn/futures/view/optionsDP.php` |
| `option_commodity_hist_sina` | `https://stock.finance.sina.com.cn/futures/view/optionsDP.php` |
| `option_comm_info` | `https://www.9qihuo.com/qiquanshouxufei` |
| `option_margin` | `https://www.iweiai.com/qiquan/yuanyou` |
| `option_hist_shfe` | `https://www.shfe.com.cn/reports/tradedata/dailyandweeklydata/` |
| `option_hist_dce` | `http://www.dce.com.cn/dalianshangpin/xqsj/tjsj26/rtj/rxq/index.html` |
| `option_hist_czce` | `http://www.czce.com.cn/cn/jysj/mrhq/H770301index_1.htm` |
| `option_hist_gfex` | `http://www.gfex.com.cn/gfex/rihq/hqsj_tjsj.shtml` |
| `option_vol_gfex` | `http://www.gfex.com.cn/gfex/rihq/hqsj_tjsj.shtml` |
| `option_czce_hist` | `http://www.czce.com.cn/cn/jysj/lshqxz/H770319index_1.htm` |

## 债券/可转债

| 函数 | 目标地址 |
|------|---------|
| `bond_info_cm` | `https://www.chinamoney.com.cn/chinese/scsjzqxx/` |
| `bond_info_detail_cm` | `https://www.chinamoney.com.cn/chinese/zqjc/?bondDefinedCode=egfjh08154` |
| `bond_cash_summary_sse` | `https://bond.sse.com.cn/data/statistics/overview/bondow/` |
| `bond_deal_summary_sse` | `http://bond.sse.com.cn/data/statistics/overview/turnover/` |
| `bond_debt_nafmii` | `http://zhuce.nafmii.org.cn/fans/publicQuery/manager` |
| `bond_spot_quote` | `https://www.chinamoney.com.cn/chinese/mkdatabond/` |
| `bond_spot_deal` | `https://www.chinamoney.com.cn/chinese/mkdatabond/` |
| `bond_china_yield` | `https://yield.chinabond.com.cn/cbweb-pbc-web/pbc/historyQuery?startDate=2019-02-07&endDate=2020-02-04&gjqx=0&qxId=ycqx&locale=cn_ZH` |
| `bond_zh_hs_spot` | `https://vip.stock.finance.sina.com.cn/mkt/#hs_z` |
| `bond_zh_hs_daily` | `https://money.finance.sina.com.cn/bond/quotes/sh019315.html` |
| `bond_cb_profile_sina` | `https://money.finance.sina.com.cn/bond/info/sz128039.html` |
| `bond_cb_summary_sina` | `https://money.finance.sina.com.cn/bond/quotes/sh155255.html` |
| `bond_zh_hs_cov_spot` | `https://vip.stock.finance.sina.com.cn/mkt/#hskzz_z` |
| `bond_zh_hs_cov_daily` | `https://biz.finance.sina.com.cn/suggest/lookup_n.php?q=sh110048` |
| `bond_zh_hs_cov_min` | `https://quote.eastmoney.com/concept/sz128039.html` |
| `bond_zh_hs_cov_pre_min` | `https://quote.eastmoney.com/concept/sz128039.html` |
| `bond_zh_cov` | `https://data.eastmoney.com/kzz/default.html` |
| `bond_zh_cov_info` | `https://data.eastmoney.com/kzz/detail/123121.html` |
| `bond_zh_cov_info_ths` | `https://data.10jqka.com.cn/ipo/bond/` |
| `bond_cov_comparison` | `https://quote.eastmoney.com/center/fullscreenlist.html#convertible_comparison` |
| `bond_zh_cov_value_analysis` | `https://data.eastmoney.com/kzz/detail/113527.html` |
| `bond_sh_buy_back_em` | `https://quote.eastmoney.com/center/gridlist.html#bond_sh_buyback` |
| `bond_sz_buy_back_em` | `https://quote.eastmoney.com/center/gridlist.html#bond_sz_buyback` |
| `bond_buy_back_hist_em` | `https://quote.eastmoney.com/center/gridlist.html#bond_sh_buyback` |
| `bond_cb_jsl` | `https://www.jisilu.cn/data/cbnew/#cb` |
| `bond_cb_redeem_jsl` | `https://www.jisilu.cn/data/cbnew/#redeem` |
| `bond_cb_index_jsl` | `https://www.jisilu.cn/web/data/cb/index` |
| `bond_cb_adj_logs_jsl` | `https://app.jisilu.cn/data/cbnew/#cb` |
| `bond_china_close_return` | `https://www.chinamoney.com.cn/chinese/bkcurvclosedyhis/?bondType=CYCC000&reference=1` |
| `bond_zh_us_rate` | `https://data.eastmoney.com/cjsj/zmgzsyl.html` |
| `bond_gb_zh_sina` | `https://stock.finance.sina.com.cn/forex/globalbd/cn10yt.html` |
| `bond_gb_us_sina` | `https://stock.finance.sina.com.cn/forex/globalbd/cn10yt.html` |
| `bond_treasure_issue_cninfo` | `https://webapi.cninfo.com.cn/#/thematicStatistics` |
| `bond_local_government_issue_cninfo` | `https://webapi.cninfo.com.cn/#/thematicStatistics` |
| `bond_corporate_issue_cninfo` | `https://webapi.cninfo.com.cn/#/thematicStatistics` |
| `bond_cov_issue_cninfo` | `https://webapi.cninfo.com.cn/#/thematicStatistics` |
| `bond_cov_stock_issue_cninfo` | `https://webapi.cninfo.com.cn/#/thematicStatistics` |
| `bond_new_composite_index_cbond` | `https://yield.chinabond.com.cn/cbweb-mn/indices/single_index_query` |
| `bond_composite_index_cbond` | `https://yield.chinabond.com.cn/cbweb-mn/indices/single_index_query` |

## 外汇

| 函数 | 目标地址 |
|------|---------|
| `forex_spot_em` | `https://quote.eastmoney.com/center/gridlist.html#forex_all` |
| `forex_hist_em` | `https://quote.eastmoney.com/cnyrate/EURCNYC.html` |
| `currency_boc_sina` | `https://biz.finance.sina.com.cn/forex/forex.php?startdate=2012-01-01&enddate=2021-06-14&money_code=EUR&type=0` |
| `currency_boc_safe` | `https://www.safe.gov.cn/safe/rmbhlzjj/index.html` |
| `fx_spot_quote` | `http://www.chinamoney.com.cn/chinese/mkdatapfx/` |
| `fx_swap_quote` | `http://www.chinamoney.com.cn/chinese/mkdatapfx/` |
| `fx_c_swap_cm` | `https://www.chinamoney.org.cn/chinese/bkcurvfsw` |
| `fx_pair_quote` | `http://www.chinamoney.com.cn/chinese/mkdatapfx/` |
| `currency_pair_map` | `https://cn.investing.com/currencies/cny-jmd` |
| `macro_fx_sentiment` | `https://datacenter.jin10.com/reportType/dc_ssi_trends` |
| `fx_quote_baidu` | `https://gushitong.baidu.com/top/foreign-rmb` |

## 利率

| 函数 | 目标地址 |
|------|---------|
| `macro_bank_usa_interest_rate` | `https://datacenter.jin10.com/reportType/dc_usa_interest_rate_decision` |
| `macro_bank_euro_interest_rate` | `https://datacenter.jin10.com/reportType/dc_interest_rate_decision` |
| `macro_bank_newzealand_interest_rate` | `https://datacenter.jin10.com/reportType/dc_newzealand_interest_rate_decision` |
| `macro_bank_china_interest_rate` | `https://datacenter.jin10.com/reportType/dc_china_interest_rate_decision` |
| `macro_bank_switzerland_interest_rate` | `https://datacenter.jin10.com/reportType/dc_switzerland_interest_rate_decision` |
| `macro_bank_english_interest_rate` | `https://datacenter.jin10.com/reportType/dc_english_interest_rate_decision` |
| `macro_bank_australia_interest_rate` | `https://datacenter.jin10.com/reportType/dc_australia_interest_rate_decision` |
| `macro_bank_japan_interest_rate` | `https://datacenter.jin10.com/reportType/dc_japan_interest_rate_decision` |
| `macro_bank_russia_interest_rate` | `https://datacenter.jin10.com/reportType/dc_russia_interest_rate_decision` |
| `macro_bank_india_interest_rate` | `https://datacenter.jin10.com/reportType/dc_india_interest_rate_decision` |
| `macro_bank_brazil_interest_rate` | `https://datacenter.jin10.com/reportType/dc_brazil_interest_rate_decision` |
| `rate_interbank` | `https://data.eastmoney.com/shibor/shibor.aspx?m=sg&t=88&d=99333&cu=sgd&type=009065&p=79` |
| `repo_rate_hist` | `https://www.chinamoney.com.cn/chinese/bkfrr/` |
| `repo_rate_query` | `https://www.chinamoney.com.cn/chinese/bkfrr/` |

## 其他

| 函数 | 目标地址 |
|------|---------|
| `car_market_total_cpca` | `http://data.cpcadata.com/TotalMarket` |
| `car_market_man_rank_cpca` | `http://data.cpcadata.com/ManRank` |
| `car_market_cate_cpca` | `http://data.cpcadata.com/CategoryMarket` |
| `car_market_country_cpca` | `http://data.cpcadata.com/CountryMarket` |
| `car_market_segment_cpca` | `http://data.cpcadata.com/SegmentMarket` |
| `car_market_fuel_cpca` | `http://data.cpcadata.com/FuelMarket` |
| `car_sale_rank_gasgoo` | `https://i.gasgoo.com/data/ranking` |
| `news_cctv` | `https://tv.cctv.com/lm/xwlb` |
| `sunrise_daily` | `https://www.timeanddate.com/sun/china/` |
| `sunrise_monthly` | `https://www.timeanddate.com/sun/china/` |
| `air_quality_hebei` | `http://218.11.10.130:8080/#/application/home` |
| `air_city_table` | `https://www.aqistudy.cn/` |
| `air_quality_hist` | `https://www.zq12369.com/` |
| `air_quality_rank` | `https://www.zq12369.com/environment.php` |
| `air_quality_watch_point` | `https://www.zq12369.com/environment.php` |
| `fortune_rank` | `https://www.fortunechina.com/fortune500/node_65.htm` |
| `forbes_rank` | `https://www.forbeschina.com/lists` |
| `xincaifu_rank` | `http://www.xcf.cn/zhuanti/ztzz/hdzt1/500frb/index.html` |
| `hurun_rank` | `https://www.hurun.net/zh-CN/Rank/HsRankDetails?num=QWDD234E` |
| `movie_boxoffice_realtime` | `https://ys.endata.cn/BoxOffice/Movie` |
| `movie_boxoffice_daily` | `https://www.endata.com.cn/BoxOffice/BO/Day/index.html` |
| `movie_boxoffice_weekly` | `https://www.endata.com.cn/BoxOffice/BO/Week/oneWeek.html` |
| `movie_boxoffice_monthly` | `https://www.endata.com.cn/BoxOffice/BO/Month/oneMonth.html` |
| `movie_boxoffice_yearly` | `https://www.endata.com.cn/BoxOffice/BO/Year/index.html` |
| `movie_boxoffice_yearly_first_week` | `https://www.endata.com.cn/BoxOffice/BO/Year/firstWeek.html` |
| `movie_boxoffice_cinema_daily` | `https://www.endata.com.cn/BoxOffice/BO/Cinema/day.html` |
| `movie_boxoffice_cinema_weekly` | `https://www.endata.com.cn/BoxOffice/BO/Cinema/week.html` |
| `video_tv` | `https://www.endata.com.cn/Video/index.html` |
| `video_variety_show` | `https://www.endata.com.cn/Video/index.html` |
| `business_value_artist` | `https://www.endata.com.cn/Marketing/Artist/business.html` |
| `online_value_artist` | `https://www.endata.com.cn/Marketing/Artist/business.html` |
| `stock_js_weibo_report` | `https://datacenter.jin10.com/market` |
| `index_bloomberg_billionaires` | `https://www.bloomberg.com/billionaires/` |
| `index_bloomberg_billionaires_hist` | `https://stats.areppim.com/stats/links_billionairexlists.htm` |

## 能源/碳排放

| 函数 | 目标地址 |
|------|---------|
| `energy_carbon_domestic` | `http://www.tanjiaoyi.com/` |
| `energy_carbon_bj` | `https://www.bjets.com.cn/article/jyxx/` |
| `energy_carbon_sz` | `http://www.cerx.cn/dailynewsCN/index.htm` |
| `energy_carbon_eu` | `http://www.cerx.cn/dailynewsOuter/index.htm` |
| `energy_carbon_hb` | `http://www.cerx.cn/dailynewsOuter/index.htm` |
| `energy_carbon_gz` | `http://www.cnemission.com/article/hqxx/` |
| `energy_oil_hist` | `https://data.eastmoney.com/cjsj/oil_default.html` |
| `energy_oil_detail` | `https://data.eastmoney.com/cjsj/oil_default.html` |

## 现货

| 函数 | 目标地址 |
|------|---------|
| `spot_price_qh` | `https://www.99qh.com/data/spotTrend` |
| `spot_hist_sge` | `https://www.sge.com.cn/sjzx/mrhq` |
| `spot_quotations_sge` | `https://www.sge.com.cn/` |
| `spot_golden_benchmark_sge` | `https://www.sge.com.cn/sjzx/jzj` |
| `spot_silver_benchmark_sge` | `https://www.sge.com.cn/sjzx/shyjzj` |
| `spot_hog_soozhu` | `https://www.soozhu.com/price/data/center/` |
| `spot_hog_year_trend_soozhu` | `https://www.soozhu.com/price/data/center/` |
| `spot_hog_lean_price_soozhu` | `https://www.soozhu.com/price/data/center/` |
| `spot_hog_three_way_soozhu` | `https://www.soozhu.com/price/data/center/` |
| `spot_hog_crossbred_soozhu` | `https://www.soozhu.com/price/data/center/` |
| `spot_corn_price_soozhu` | `https://www.soozhu.com/price/data/center/` |
| `spot_soybean_price_soozhu` | `https://www.soozhu.com/price/data/center/` |
| `spot_mixed_feed_soozhu` | `https://www.soozhu.com/price/data/center/` |

## 货币

| 函数 | 目标地址 |
|------|---------|
| `currency_latest` | `https://currencyscoop.com/` |
| `currency_history` | `https://currencyscoop.com/` |
| `currency_time_series` | `https://currencyscoop.com/` |
| `currency_currencies` | `https://currencyscoop.com/` |
| `currency_convert` | `https://currencyscoop.com/` |

## 加密货币

| 函数 | 目标地址 |
|------|---------|
| `crypto_js_spot` | `https://datacenter.jin10.com/reportType/dc_bitcoin_current` |
| `crypto_bitcoin_hold_report` | `https://datacenter.jin10.com/dc_report?name=bitcoint` |
| `crypto_bitcoin_cme` | `https://datacenter.jin10.com/reportType/dc_cme_btc_report` |

## 学术/研究

| 函数 | 目标地址 |
|------|---------|
| `article_oman_rv` | `https://realized.oxford-man.ox.ac.uk/data/visualization` |
| `article_rlab_rv` | `https://dachxiu.chicagobooth.edu/` |
| `article_ff_crr` | `https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/data_library.html` |
| `article_epu_index` | `https://www.policyuncertainty.com/index.html` |

## QDII

| 函数 | 目标地址 |
|------|---------|
| `qdii_e_index_jsl` | `https://www.jisilu.cn/data/qdii/#qdiia` |
| `qdii_e_comm_jsl` | `https://www.jisilu.cn/data/qdii/#qdiia` |
| `qdii_a_index_jsl` | `https://www.jisilu.cn/data/qdii/#qdiia` |

## 事件

| 函数 | 目标地址 |
|------|---------|
| `migration_area_baidu` | `https://qianxi.baidu.com/?from=shoubai#city=0` |
| `migration_scale_baidu` | `https://qianxi.baidu.com/?from=shoubai#city=0` |

## 银行

| 函数 | 目标地址 |
|------|---------|
| `bank_fjcf_table_detail` | `https://www.cbirc.gov.cn/cn/view/pages/ItemDetail.html?docId=881574&itemId=4115&generaltype=9` |

## NLP

| 函数 | 目标地址 |
|------|---------|
| `nlp_ownthink` | `https://ownthink.com/` |
| `nlp_answer` | `https://ownthink.com/robot.html` |

## 高频数据

| 函数 | 目标地址 |
|------|---------|
| `hf_sp_500` | `https://github.com/FutureSharks/financial-data` |

## 工具

| 函数 | 目标地址 |
|------|---------|
| `tool_trade_date_hist_sina` | `https://finance.sina.com.cn` |
