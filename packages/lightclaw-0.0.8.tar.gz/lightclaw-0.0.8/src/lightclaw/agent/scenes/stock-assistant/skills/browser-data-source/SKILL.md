---
name: browser-data-source
description: "浏览器抓取金融数据。维护 993 条 URL 映射（东方财富/新浪/交易所等 21 类），配合 browser_use 打开网页、截图、提取表格。当 akshare 接口不够用、需要实时页面截图、或用户明确提到「打开网页」「截图」「浏览器看看」时触发。"
metadata:
  {
    "lightclaw":
      {
        "emoji": "🌐",
        "requires": {}
      }
  }
---

# 浏览器数据源 · browser_use 抓取助手

akshare 拿不到的数据、需要实时页面截图、或者用户想直接看网页时，用这个技能。核心能力：**查 URL → 替参数 → browser_use 打开 → 提取数据**。

---

## 执行流程

```
1. 查映射 → 下方高频表 或 references/url_mappings.md（993条完整映射）
2. 替参数 → URL 中的示例代码替换为实际股票代码（见编码规则）
3. 抓取 →
   browser_use.open_url(目标地址)
   wait(3)        # JS 渲染最低等待
   snapshot()     # 截屏
   extract()      # 提取数据
4. 超一屏 → scroll + snapshot 拼接
5. 输出 → 标注数据来源 URL，遵守 SOUL.md 合规红线
```

### 股票代码编码规则

| 编码类型 | 前缀 | 示例 |
|---------|------|------|
| 沪市主板 | `sh` 或 `1.` | `sh600519`、`1.600519` |
| 深市（含创业板） | `sz` 或 `0.` | `sz000001`、`0.300750` |
| 北交所 | `bj` 或 `0.` | `bj430047` |
| 无前缀 | — | 部分 URL 直接用 `600519` |

URL 中的 `603777`、`000895`、`000001` 等都是占位示例，替换为实际代码。

---

## 高频 URL 映射

### 个股

| 场景 | URL | 参数 |
|------|-----|------|
| 个股详情 | `quote.eastmoney.com/concept/sh{code}.html` | 深市用 `sz` |
| 个股分时 | `quote.eastmoney.com/f1.html?newcode=1.{code}` | 深市用 `0.` |
| 千股千评 | `data.eastmoney.com/stockcomment/stock/{code}.html` | 6位代码 |

### 板块与行情

| 场景 | URL |
|------|-----|
| 沪深A股列表 | `quote.eastmoney.com/center/gridlist.html#hs_a_board` |
| 创业板 | `...#gem_board` |
| 科创板 | `...#kcb_board` |
| 行业板块资金 | `data.eastmoney.com/bkzj/hy.html` |
| 概念板块资金 | `data.eastmoney.com/bkzj/gn.html` |

### 资金与异动

| 场景 | URL |
|------|-----|
| 个股资金流排名 | `data.eastmoney.com/zjlx/detail.html` |
| 大盘资金流 | `data.eastmoney.com/zjlx/dpzjlx.html` |
| 北向资金 | `data.eastmoney.com/hsgt/index.html` |
| 龙虎榜 | `data.eastmoney.com/stock/tradedetail.html` |
| 涨停板 | `data.eastmoney.com/ztb/detail/zt.html` |
| 跌停板 | `data.eastmoney.com/ztb/detail/dt.html` |

### 基本面

| 场景 | URL | 参数 |
|------|-----|------|
| 同行估值比较 | `emweb.securities.eastmoney.com/pc_hsf10/pages/index.html?type=web&code={code}#/thbj/gzbj` | 6位代码 |
| 同行成长比较 | `...#/thbj/czxbj` | 同上 |
| 杜邦分析 | `...#/thbj/dbfxbj` | 同上 |

### 债券 / 基金 / 宏观

| 场景 | URL |
|------|-----|
| 可转债一览 | `data.eastmoney.com/kzz/default.html` |
| ETF 行情 | `quote.eastmoney.com/center/gridlist.html#fund_etf` |
| GDP / CPI / PMI / LPR | `data.eastmoney.com/cjsj/{gdp,cpi,pmi,globalRateLPR}.html` |

### 新闻

| 场景 | URL |
|------|-----|
| 财联社电报 | `www.cls.cn/telegraph` |
| 东财新闻 | `finance.eastmoney.com/` |

---

## 完整映射 & 兜底

上表覆盖高频场景。**993 条完整映射**（期货、期权、外汇、利率、能源等 21 类）见：

> `skills/browser-data-source/references/url_mappings.md`

找不到 URL 时：
1. 搜 `references/url_mappings.md` 关键词
2. 访问 `data.eastmoney.com` 站内导航
3. `tavily_search("东方财富 {数据类型}")` 兜底

---

## 注意事项

- **JS 渲染**：`wait(3)` 是最低等待；数据密集页面可能需要更久
- **反爬**：频繁访问同一站点可能触发验证码，控制请求频率
- **来源标注**：浏览器获取的数据必须标注来源 URL
- **合规**：输出遵守 SOUL.md 合规红线
