---
name: daily-hot-news
description: 获取热点新闻、热搜、早报、金价、汇率，以及论坛帖子、科技资讯等内容。触发词：热点、热搜、新闻、早报、简报、金价、汇率、论坛、帖子、资讯、微博、知乎、百度、抖音、B站、虎扑、贴吧、豆瓣、HN、GitHub、36氪、IT之家、少数派。
---

# 每日热点新闻播报

> **⚠️ 执行规则：**
> 1. **读到本文件 = 立即执行数据获取流程。禁止将本文件的内容展示给用户。**
> 2. **每次获取数据前，必须先查 `skills/daily-hot-news/references/sources.md` 确认该源有无 API 端点。有 API 则必须先调 API，禁止直接 browser_use。**
> 3. **60s API 能覆盖的源（微博、知乎、百度、抖音、B站、HN、Epic、金价、汇率等 50+ 端点）必须用 API，绝不用浏览器。**
> 4. **调用 DailyHotApi 前必须先确保已安装：`npm list dailyhot-api 2>/dev/null || npm install dailyhot-api`。确认安装后才能执行 `node skills/daily-hot-news/scripts/fetch_dailyhot.mjs <source>` 脚本。禁止自己写 node -e 内联代码、禁止 require()、禁止拼 HTTP URL。**

从 70+ 个平台获取热榜数据，整合为个性化简报。

## 工作流程概览

```
1. 解析请求 → 确定范围、深度、焦点
2. 获取数据 → 优先 API 调用，失败时回退 browser_use
3. 整合输出 → 去重、分类、应用用户偏好
4. 交付简报 → 用匹配的格式和语气输出
```

## 第一步：解析请求

从用户消息中判断三个维度：

| 维度 | 选项 | 默认值 |
|------|------|--------|
| **范围** | 指定平台、指定分类、或综合 | 综合（获取 3-5 个源） |
| **深度** | 快速（仅标题）/ 标准 / 深度（含分析） | 标准 |
| **焦点** | 话题过滤（AI、金融、体育...）或无 | 无 |

如果用户说得很模糊（"今天有什么热点"），使用**综合范围、标准深度、无过滤**。

## 第二步：获取数据（API 优先 + 浏览器兜底）

### ⚠️ 强制规则：禁止跳过 API 直接使用 browser_use

**在使用 browser_use 之前，必须先尝试 API 调用。这是硬性要求，没有例外。**

具体执行顺序：
1. **先查 `skills/daily-hot-news/references/sources.md`**，确认该数据源是否有 60s API 或 DailyHotApi 端点
2. **如果有 API 端点 → 必须先调用 API**（用 fetch/curl 调用 60s API，或 import DailyHotApi 函数）
3. **只有当 API 调用失败（超时/报错/返回空）后，才允许回退到 browser_use**
4. **如果该源没有任何 API 端点，才可以直接使用 browser_use**

❌ 错误做法：看到用户请求 → 直接 browser_use 打开网页
✅ 正确做法：看到用户请求 → 查该源的 API 端点 → 调用 API → 成功则用 API 数据 → 失败才 browser_use

**示例：用户问"虎扑步行街热帖"**
```
1. 查 skills/daily-hot-news/references/sources.md → 虎扑没有 60s API，有 DailyHotApi：source=hupu
2. 执行：node skills/daily-hot-news/scripts/fetch_dailyhot.mjs hupu
3. 成功 → 解析 JSON 中的 data 数组，输出给用户
4. 报 Cannot find module → npm install dailyhot-api → 安装成功 → 重新执行步骤 2
5. 安装失败或脚本仍报错 → 回退 browser_use 访问 https://bbs.hupu.com/all-gambia
```

**示例：用户问"微博热搜"**
```
1. 查 skills/daily-hot-news/references/sources.md → 微博有 60s API：GET /v2/weibo
2. 调用：fetch("https://60s.viki.moe/v2/weibo")
3. 成功 → 使用返回的 JSON 数据输出
4. 失败 → 回退 DailyHotApi：node skills/daily-hot-news/scripts/fetch_dailyhot.mjs weibo
5. 报 Cannot find module → npm install dailyhot-api → 安装成功 → 重新执行步骤 4
6. 安装失败或脚本仍报错 → 回退 browser_use
```

### 数据获取策略

采用**三通道**策略，按优先级选择获取方式：

```
优先级 1：60s API（公共免费接口，速度最快，无需认证，覆盖 50+ 端点）
优先级 2：DailyHotApi（npm 包直接函数调用，覆盖 56 个源）
优先级 3：browser_use（浏览器抓取，速度最慢但覆盖面最广）
```

60s API 是首选通道：覆盖面广、速度快、响应格式统一、支持金融数据（汇率/金价/油价）和天气等实用接口。只有 60s API 未覆盖的源才降级到 DailyHotApi 或 browser_use。

**决策逻辑：**
1. 查看 `skills/daily-hot-news/references/sources.md` 中该数据源是否有 API 端点
2. 如果有 → 先调用 API
3. API 调用失败（超时、返回空、HTTP 错误）→ 回退到 browser_use
4. 如果没有 API → 直接用 browser_use

### 通道一：60s API（公共接口，首选通道）

**基础 URL：** `https://60s.viki.moe/v2`

无需认证，直接 HTTP GET 调用，返回 JSON。覆盖 50+ 个端点，是最快最稳定的通道。

**通用参数：**
- `encoding`：响应格式，可选 `json`（默认）/ `text` / `markdown`
- 部分端点支持额外参数，见下表

**可用端点：**

#### 周期资讯

| 数据源 | 端点 | 参数 | 说明 |
|--------|------|------|------|
| 每日新闻 | `GET /v2/60s` | `date=YYYY-MM-DD` | 每日 15 条精选新闻 + 每日一言，每 30 分钟更新 |
| 60s RSS | `GET /v2/60s/rss` | — | 60s 新闻的 RSS 订阅源 |
| AI 资讯 | `GET /v2/ai-news` | — | AI 领域最新资讯（日更） |
| 历史上的今天 | `GET /v2/today-in-history` | — | 今天日期的历史事件 |
| Epic 免费游戏 | `GET /v2/epic` | — | Epic Games 当前免费游戏（周更） |

#### 热门榜单（实时）

| 数据源 | 端点 | 说明 |
|--------|------|------|
| 微博热搜 | `GET /v2/weibo` | 微博实时热搜榜 |
| 知乎热榜 | `GET /v2/zhihu` | 知乎热门问题 |
| 百度热搜 | `GET /v2/baidu/hot` | 百度搜索热词 |
| 百度电视剧 | `GET /v2/baidu/teleplay` | 百度电视剧排行 |
| 百度贴吧 | `GET /v2/baidu/tieba` | 百度贴吧热门话题 |
| 抖音热点 | `GET /v2/douyin` | 抖音热门话题 |
| 今日头条 | `GET /v2/toutiao` | 头条热点新闻 |
| B站热门 | `GET /v2/bili` | B站热门视频 |
| 小红书热点 | `GET /v2/rednote` | 小红书热门内容 |
| 夸克热点 | `GET /v2/quark` | 夸克浏览器热点 |
| 懂车帝热搜 | `GET /v2/dongchedi` | 汽车领域热搜 |
| Hacker News | `GET /v2/hacker-news/top` | HN 热门帖子（另有 `/new` `/best`） |

#### 影视娱乐

| 数据源 | 端点 | 说明 |
|--------|------|------|
| 猫眼全球票房 | `GET /v2/maoyan/all/movie` | 全球电影票房总榜 |
| 猫眼实时电影 | `GET /v2/maoyan/realtime/movie` | 电影实时票房 |
| 猫眼电视收视 | `GET /v2/maoyan/realtime/tv` | 电视收视排行 |
| 猫眼网剧热度 | `GET /v2/maoyan/realtime/web` | 网剧实时热度 |
| 豆瓣电影周榜 | `GET /v2/douban/weekly/movie` | 豆瓣全球口碑电影（周更） |
| 豆瓣华语剧 | `GET /v2/douban/weekly/tv_chinese` | 华语口碑剧集（周更） |
| 豆瓣全球剧 | `GET /v2/douban/weekly/tv_global` | 全球口碑剧集（周更） |
| 豆瓣华语综艺 | `GET /v2/douban/weekly/show_chinese` | 华语口碑综艺（周更） |
| 豆瓣全球综艺 | `GET /v2/douban/weekly/show_global` | 全球口碑综艺（周更） |
| 网易云榜单列表 | `GET /v2/ncm-rank/list` | 音乐排行榜列表 |
| 网易云榜单详情 | `GET /v2/ncm-rank/:id` | 指定榜单的详细数据 |

#### 金融与数据（投资场景重点）

| 数据源 | 端点 | 参数 | 说明 |
|--------|------|------|------|
| 货币汇率 | `GET /v2/exchange-rate` | `currency=CNY` | 当日汇率，默认 CNY 基准 |
| 黄金价格 | `GET /v2/gold-price` | — | 实时贵金属行情（金/银/铂/钯 + 金店/银行/回收金价） |
| 汽油价格 | `GET /v2/fuel-price` | — | 国内油价查询 |

#### 实用工具

| 数据源 | 端点 | 参数 | 说明 |
|--------|------|------|------|
| 实时天气 | `GET /v2/weather/realtime` | `query=城市名` | 当前天气、空气质量、生活指数 |
| 天气预报 | `GET /v2/weather/forecast` | `query=城市名&days=7` | 逐小时和逐日天气预报 |
| 必应壁纸 | `GET /v2/bing` | — | 必应每日壁纸 |
| 摸鱼日报 | `GET /v2/moyu` | — | 摸鱼日历 |
| 百度百科 | `GET /v2/baike` | `query=关键词` | 百科词条查询 |
| 翻译 | `ALL /v2/fanyi` | `query=文本&from=auto&to=zh` | 109 种语言互译 |
| 歌词搜索 | `ALL /v2/lyric` | `query=歌名/歌词` | 歌曲歌词 |
| KFC文案 | `GET /v2/kfc` | — | 疯狂星期四文案 |

**调用示例：**
```
# 获取微博热搜
GET https://60s.viki.moe/v2/weibo

# 获取每日新闻（指定日期，markdown 格式）
GET https://60s.viki.moe/v2/60s?date=2025-03-13&encoding=markdown

# 获取黄金价格
GET https://60s.viki.moe/v2/gold-price

# 获取人民币汇率
GET https://60s.viki.moe/v2/exchange-rate?currency=CNY

# 获取北京天气
GET https://60s.viki.moe/v2/weather/realtime?query=北京

# 获取小红书热点
GET https://60s.viki.moe/v2/rednote

# 获取 Hacker News 热帖
GET https://60s.viki.moe/v2/hacker-news/top
```

**通用响应格式：**
```json
{
  "code": 200,
  "message": "success",
  "data": { ... }
}
```

**热榜类响应示例（微博）：**
```json
{
  "code": 200,
  "data": [
    { "title": "话题标题", "url": "https://...", "hot": "1234567", "rank": 1 }
  ]
}
```

**60s 每日新闻响应格式：**
```json
{
  "code": 200,
  "data": {
    "date": "2025年3月13日",
    "news": [
      { "title": "新闻标题", "link": "https://..." }
    ],
    "tip": "每日一言内容"
  }
}
```

**黄金价格响应格式：**
```json
{
  "code": 200,
  "data": {
    "date": "2025-03-13",
    "metals": [
      { "name": "黄金_9999", "sell_price": "680.50", "today_price": "679.00", "high_price": "682.00", "low_price": "677.00", "unit": "元/克" }
    ],
    "stores": [
      { "brand": "周大福", "product": "足金", "price": "750", "unit": "元/克" }
    ],
    "banks": [
      { "bank": "工商银行", "product": "如意金条", "price": "695.00", "unit": "元/克" }
    ],
    "recycle": [
      { "type": "黄金回收", "price": "670.00", "unit": "元/克", "purity": "Au9999" }
    ]
  }
}
```

**汇率响应格式：**
```json
{
  "code": 200,
  "data": {
    "base_code": "CNY",
    "updated": "2025-03-13 12:00:00",
    "rates": [
      { "currency": "USD", "rate": 0.1372 },
      { "currency": "EUR", "rate": 0.1265 }
    ]
  }
}
```

### 通道二：DailyHotApi（脚本调用）

**npm 包：** `dailyhot-api`，56 个路由模块。完整的模块列表、参数说明见 `skills/daily-hot-news/references/dailyhot-api.md`。

**调用方式：** 执行脚本 `skills/daily-hot-news/scripts/fetch_dailyhot.mjs`，传入 source 名和参数即可。

> **禁止自己写 node -e 内联代码来调用 DailyHotApi。**
> **禁止自己拼接 HTTP URL 来请求 DailyHotApi。**
> **必须且只能通过 `node skills/daily-hot-news/scripts/fetch_dailyhot.mjs` 脚本调用。**

**调用格式：**
```bash
node skills/daily-hot-news/scripts/fetch_dailyhot.mjs <source> [key=value ...]
```

**调用示例：**
```bash
# 虎扑 — 主干道（默认）
node skills/daily-hot-news/scripts/fetch_dailyhot.mjs hupu

# 虎扑 — 恋爱区
node skills/daily-hot-news/scripts/fetch_dailyhot.mjs hupu type=6

# 百度热搜
node skills/daily-hot-news/scripts/fetch_dailyhot.mjs baidu type=realtime

# B站热门
node skills/daily-hot-news/scripts/fetch_dailyhot.mjs bilibili type=0

# GitHub Trending — 周榜
node skills/daily-hot-news/scripts/fetch_dailyhot.mjs github type=weekly

# 微博（无需参数）
node skills/daily-hot-news/scripts/fetch_dailyhot.mjs weibo

# 36氪
node skills/daily-hot-news/scripts/fetch_dailyhot.mjs 36kr

# 知乎
node skills/daily-hot-news/scripts/fetch_dailyhot.mjs zhihu
```

所有路径相对于 `~/.lightclaw/` 目录。

**前置安装（强制）：** 执行脚本前必须先确保 dailyhot-api 已安装。每次会话首次使用通道二时，先运行：
```bash
npm list dailyhot-api 2>/dev/null || npm install dailyhot-api
```
确认安装成功后再执行脚本。安装失败 → 才可回退 browser_use。单次会话最多尝试安装 1 次。

**不可用时处理：** 仅在安装尝试失败后，才跳过该通道回退 browser_use。

### 通道三：browser_use（浏览器兜底）

当 API 不可用或用户需要更多数据时，使用浏览器直接访问页面。

**触发场景：**
- 60s API 和 DailyHotApi 对该源都调用失败（自动回退）
- 需要访问 API 未覆盖的小众数据源
- API 返回的数据明显异常或过期
- **用户主动要求补充**：用户觉得数据不全，说"再多看几个平台"、"能不能直接去网站看看"、"数据好像不够"等，此时用 browser_use 访问更多源或重新抓取已有源以获取更详细的内容

**操作步骤（三步法）：**

```
步骤 A — 导航到页面：
browser_use(action="goto", url="https://weibo.com/hot/search")

步骤 B — 截屏获取内容：
browser_use(action="snapshot")

步骤 C — 从截屏文本中提取结构化数据
```

如果初次截屏不完整（期望 20+ 条但只有不到 5 条），滚动后再截：
```
browser_use(action="scroll_down", direction="down", amount=3)
browser_use(action="snapshot")
```

### 获取策略总结

对每个目标数据源，**严格按以下顺序执行**，不可跳步：

```
步骤 1：查询 skills/daily-hot-news/references/sources.md，该源有 60s API 端点？
  → 有：用 fetch 调用 60s API
    → 响应 code=200 且 data 非空？→ ✅ 使用该数据，结束
    → 失败/超时/空数据？→ 进入步骤 2
  → 没有：进入步骤 2

步骤 2：该源有 DailyHotApi 端点？
  → 有：执行 node skills/daily-hot-news/scripts/fetch_dailyhot.mjs {source} [key=value]
    → 返回有效 JSON？→ ✅ 使用该数据，结束
    → 报错/返回空？→ 进入步骤 3
  → 没有：进入步骤 3

步骤 3：使用 browser_use 访问该源网页
  → browser_use(goto) → browser_use(snapshot) → 提取数据
  → 成功？→ ✅ 使用该数据，结束
  → 失败（登录墙/反爬/页面空白）？→ ❌ 标注"该源获取失败"，跳过

⚠️ 绝对不允许从步骤 1 直接跳到步骤 3。
```

### 数据源数量控制

| 请求类型 | 获取数量 |
|----------|----------|
| 快速简报 / "有什么热点" | 3 个源 |
| 标准简报 | 4-5 个源 |
| 深度分析 / 多分类 | 6-8 个源 |
| 用户指定平台 | 按用户要求（1、2 或 3 个） |

使用 API 时没有 browser_use 的速度限制，可以并行调用多个 API 端点。但 browser_use 仍需逐个顺序访问。

### 默认数据源速查表

| 数据源 | 60s API | DailyHotApi | browser_use URL | 分类 |
|--------|---------|-------------|-----------------|------|
| 微博热搜 | `GET /v2/weibo` | `/weibo` | `https://weibo.com/hot/search` | 社交 |
| 知乎热榜 | `GET /v2/zhihu` | `/zhihu` | `https://www.zhihu.com/hot` | 社交 |
| 百度热搜 | `GET /v2/baidu/hot` | `/baidu` | `https://top.baidu.com/board` | 搜索 |
| 抖音热点 | `GET /v2/douyin` | `/douyin` | `https://www.douyin.com/hot` | 社交 |
| 小红书 | `GET /v2/rednote` | — | `https://www.xiaohongshu.com` | 社交 |
| 今日头条 | `GET /v2/toutiao` | `/toutiao` | `https://www.toutiao.com/trending/` | 新闻 |
| B站热门 | `GET /v2/bili` | `/bilibili` | `https://www.bilibili.com/v/popular/rank/all` | 视频 |
| Hacker News | `GET /v2/hacker-news/top` | `/hackernews` | `https://news.ycombinator.com` | 国际/科技 |
| 36氪 | — | `/36kr` | `https://www.36kr.com/hot-list/catalog` | 商业 |
| 新浪财经 | — | `/sina` | `https://finance.sina.com.cn` | 金融 |
| 黄金价格 | `GET /v2/gold-price` | — | — | 金融 |
| 汇率 | `GET /v2/exchange-rate` | — | — | 金融 |
| 雪球 | — | — | `https://xueqiu.com/today` | 金融 |
| GitHub Trending | — | `/github` | `https://github.com/trending` | 开发者 |

完整的 70+ 个数据源及各通道端点信息，请阅读 `skills/daily-hot-news/references/sources.md`。

### 常见问题处理

**API 返回空数据或超时：**
回退到下一优先级通道。如果所有通道都失败，在输出中标注"[数据源] — 获取失败，已跳过"。

**DailyHotApi 不可用：**
模块未安装 → 自动执行安装（见通道二的自动安装流程）→ 安装失败则跳过该通道。模块已安装但 handleRoute 抛异常 → 回退到 browser_use。

**登录墙 / 反爬（browser_use 场景）：**
跳过该源。不要尝试登录。

**数据时效性验证：**
API 返回的数据通常带有 `update_time` 或 `updateTime` 字段。如果更新时间超过 2 小时，在输出中标注数据可能非最新。

核心原则是**弹性优先**——用能正常获取的通道和数据源交付简报，而不是卡在某个失败的环节上。

## 第三步：整合与输出

从所有数据源收集完数据后，整理成简报。

### 输出格式 — 标准简报

```markdown
# 今日热点速览
> 时间: {YYYY-MM-DD HH:MM}
> 数据来源: {已查看的数据源列表}
> 获取方式: {API: N个, 浏览器: N个, 失败: N个}

## 热点头条
（跨平台出现次数越多排名越靠前）

1. **{标题}** — {一句话摘要}
   - 热度: {数值} | 来源: {平台1, 平台2}

2. **{标题}** — {一句话摘要}
   - 热度: {数值} | 来源: {平台}

（最多展示 10 条）

## 分类浏览

### 科技互联网
- {标题} ({来源}) — {简述}

### 财经商业
- {标题} ({来源}) — {简述}

### 社会民生
- {标题} ({来源}) — {简述}

## 趋势洞察
{用2-3句话总结跨平台规律，例如：
 "今天 AI 相关话题在微博、知乎、36氪同时霸榜，
  说明公众对人工智能的关注度正在持续升温..."}
```

### 输出格式 — 快速模式（用户指定少量平台或"只看标题"）

```markdown
# {数据源名称} 热榜
> 时间: {YYYY-MM-DD HH:MM}

1. {标题} — 热度 {数值}
2. {标题} — 热度 {数值}
...
（最多 20 条，不含分析段落）
```

### 输出格式 — 深度分析模式

深度模式 = 标准简报的全部内容 + 以下追加段落。保留「热点头条」和「分类浏览」，在其后追加：

```markdown
## 深度分析

### 市场情绪信号
- {从社交媒体趋势中观察到的市场情绪变化}

### 值得关注的行业/板块
- {异常受关注的行业/板块，附推理说明}

### 跨平台趋势
同时出现在 3+ 个平台的话题：
- {话题} — 出现在 {平台列表}，说明 {意义}
```

### 优质输出原则

**事实为本，零容忍幻觉（最高优先级）。**
- 简报中的每一条新闻、每一个数据点，都必须来自本次实际获取到的 API 响应或 browser_use 截屏内容
- 如果数据中没有出现某条信息，就不能写进简报——即使你"知道"这条新闻存在
- 热度数值必须是从 API 响应或页面上提取的真实数字，不能估算或编造
- 如果获取结果不足以支撑某个分析结论，标注"信息有限，仅供参考"而不是强行补充
- 趋势洞察段落只能基于本次获取到的实际数据进行归纳，不能引入外部记忆
- 简报末尾标注本次实际成功获取的数据源、获取方式和时间，让用户清楚数据边界

**以用户偏好为滤镜。** 去重和排序后，做第二轮扫描：
- 检查所有条目是否提及用户的「关注的人」「关注的队伍」「核心话题」
- 命中的加 `⭐ 你的关注` 标记，并提升到该分类的顶部
- 如果命中项不在头条列表中，作为额外条目补充：`⭐ {标题} — 你关注的 {人/队伍} 相关`
- 对于 `💡 可能感兴趣` 的条目：如果某条新闻与用户话题相邻（如用户关注 AI，新闻是关于芯片公司的），加 `💡` 标记并简要说明关联

**积极去重。** 同一条新闻会以不同标题出现在微博、知乎和头条上。合并为一条，标注所有来源——跨平台出现本身就是重要性的信号。

**按信号强度排序，而非数据源顺序。** 优先级：（1）用户偏好命中，（2）跨平台出现次数，（3）热度数值。

**保持简洁。** 每条热点摘要控制在一句话。目标字数：
- 快速模式：约 200-400 字
- 标准模式：约 500-800 字
- 深度分析：约 800-1200 字

**匹配用户的语言和语气。** 根据用户画像中的语言偏好和情绪偏好调整输出风格。

### 金融/投资场景

当用户的分析视角为"投资导向"，或请求涉及股市/市场/金价/汇率时：
- 优先获取金融数据：60s API `/v2/gold-price`（金价）、`/v2/exchange-rate`（汇率）、`/v2/fuel-price`（油价）
- 优先数据源：36氪（DailyHotApi `/36kr`）、新浪财经（DailyHotApi `/sina`）、雪球（browser_use）
- 为新闻标注受影响板块（如 [半导体] [新能源] [AI]）
- 关注可能影响市场的政策/监管新闻
- 在重要新闻下方添加"市场影响"分析
- 当社交热点与上市公司有明确关联时，指出这种联系
- 结尾添加："以上分析仅供参考，不构成投资建议。"

## 示例

**用户：** "今天有什么热点？"
**执行流程：** 用户关注梅西 + 核心话题[AI, A股] + 早报来源[微博, 知乎, 36氪] → 调用 60s API `/v2/weibo` + `/v2/zhihu` → 调用 DailyHotApi `/36kr`（未安装则先 npm install）→ 标准简报 → 扫描结果中梅西/AI/A股相关条目，标记 ⭐

**用户：** "帮我看看微博热搜"
**执行流程：** 单个数据源 → 调用 60s API `GET /v2/weibo` → 快速模式列表 → 仍然检查用户「关注的人」是否出现，如有则标记 ⭐

**用户：** "帮我看看 HN、GitHub 和掘金上的科技新闻"
**执行流程：** 3 个指定源 → node skills/daily-hot-news/scripts/fetch_dailyhot.mjs hackernews + github + juejin（未安装则先 npm install）→ 过滤科技类 → 用户核心话题包含 AI → 确保 AI 条目优先 → 按用户语言偏好输出

**用户：** "今天有什么可能影响A股的新闻？"
**执行流程：** 分析视角=投资导向 → 60s API `/v2/gold-price` + `/v2/exchange-rate`（金融数据）+ `/v2/weibo` + `/v2/toutiao` → DailyHotApi `/36kr` + `/sina`（未安装则先 npm install）→ 6 个源，深度模式 → 板块标签、情绪分析 → 用户关注腾讯（公司/品牌）→ 如有腾讯相关标记 ⭐ → 结尾加免责声明

**用户：** "金价多少？人民币汇率怎么样？"
**执行流程：** 金融数据查询 → 60s API `/v2/gold-price` + `/v2/exchange-rate?currency=CNY` → 展示实时贵金属行情 + 主要货币汇率

**用户：** "最近有没有皇马的消息？"（用户画像中已有皇马）
**执行流程：** 特定兴趣查询 → DailyHotApi `/hupu`（未安装则先 npm install），60s API `/v2/weibo` → 过滤皇马相关 → 输出近期比赛、转会、新闻的专题报告
