# -*- coding: utf-8 -*-
"""Factory for creating chat models.

The legacy ``create_model_and_formatter()`` function (which depended on
AgentScope ``ChatModelBase`` / ``FormatterBase``) has been removed.

Use ``lightclaw.agent.langgraph.model_factory.create_chat_model`` for the
LangChain-based path.
"""

from __future__ import annotations

__all__: list[str] = []
