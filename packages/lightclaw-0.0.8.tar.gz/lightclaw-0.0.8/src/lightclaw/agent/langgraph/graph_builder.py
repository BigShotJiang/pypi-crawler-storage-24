# -*- coding: utf-8 -*-
"""Build a LangGraph ReAct agent graph from LightClawGraphConfig.

This is the single entry point for constructing the compiled graph.
It wraps ``create_agent`` from ``langchain.agents`` and applies
LightClaw-specific settings (system prompt, recursion limit, middleware).

Example:
    >>> from lightclaw.agent.langgraph import build_lightclaw_graph, LightClawGraphConfig
    >>> config = LightClawGraphConfig(model=model, tools=[...])
    >>> graph = build_lightclaw_graph(config)
    >>> result = graph.invoke({"messages": [("user", "hello")]})
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from langchain.agents import create_agent

if TYPE_CHECKING:
    from langgraph.graph.state import CompiledStateGraph

    from .config import LightClawGraphConfig


def build_lightclaw_graph(
    config: "LightClawGraphConfig",
) -> "CompiledStateGraph":
    """Build and compile a LangGraph ReAct agent.

    Args:
        config: LightClaw graph configuration containing model, tools,
            system prompt, iteration limits, and optional middleware.

    Returns:
        A compiled LangGraph state graph, ready for ``.invoke()``
        or ``.astream_events()``.
    """
    graph = create_agent(
        model=config.model,
        tools=list(config.tools),
        system_prompt=config.system_prompt or None,
        middleware=[config.middleware] if config.middleware else (),
    )
    return graph
