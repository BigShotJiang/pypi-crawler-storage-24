# -*- coding: utf-8 -*-
# flake8: noqa: E501
"""LangChain @tool wrappers for LightClaw's 8 built-in tools.

Each wrapper delegates to the original async implementation which returns
``LightClawToolResult``. Text-only results stay as plain strings; structured
media results are serialized to JSON so downstream renderers can preserve
images/files instead of collapsing them into text.

The original functions are NOT modified — this is a pure adapter layer.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

from langchain_core.tools import tool


def _serialize_tool_result(resp) -> str:
    """Return plain text for text-only tool results, JSON for media results."""
    content = list(getattr(resp, "content", []) or [])
    if not content:
        return getattr(resp, "to_str", lambda: "")()

    has_non_text = any(
        isinstance(block, dict) and block.get("type") != "text" for block in content
    )
    if has_non_text:
        return json.dumps(content, ensure_ascii=False)

    return getattr(resp, "to_str", lambda: "")()


# ---------------------------------------------------------------------------
# 1. execute_shell_command
# ---------------------------------------------------------------------------
@tool
async def execute_shell_command(
    command: str,
    timeout: int = 60,
    cwd: Optional[str] = None,
) -> str:
    """Execute a shell command and return stdout/stderr.

    Args:
        command: The shell command to execute.
        timeout: Maximum time in seconds (default 60).
        cwd: Working directory (default ~/.lightclaw).
    """
    from ...tools.shell import execute_shell_command as _impl

    cwd_path = Path(cwd) if cwd else None
    resp = await _impl(command=command, timeout=timeout, cwd=cwd_path)
    return resp.to_str()


# ---------------------------------------------------------------------------
# 2. read_file
# ---------------------------------------------------------------------------
@tool
async def read_file(
    file_path: str,
    start_line: Optional[int] = None,
    end_line: Optional[int] = None,
) -> str:
    """Read a file. Relative paths resolve from ~/.lightclaw.

    Use start_line/end_line (1-based) to read a specific range,
    or omit both to read the full file.

    Args:
        file_path: Path to the file.
        start_line: First line to read (1-based, inclusive).
        end_line: Last line to read (1-based, inclusive).
    """
    from ...tools.file_io import read_file as _impl

    resp = await _impl(file_path=file_path, start_line=start_line, end_line=end_line)
    return resp.to_str()


# ---------------------------------------------------------------------------
# 3. write_file
# ---------------------------------------------------------------------------
@tool
async def write_file(
    file_path: str,
    content: str,
) -> str:
    """Create or overwrite a file. Relative paths resolve from ~/.lightclaw.

    Args:
        file_path: Path to the file.
        content: Content to write.
    """
    from ...tools.file_io import write_file as _impl

    resp = await _impl(file_path=file_path, content=content)
    return resp.to_str()


# ---------------------------------------------------------------------------
# 4. edit_file
# ---------------------------------------------------------------------------
@tool
async def edit_file(
    file_path: str,
    old_text: str,
    new_text: str,
) -> str:
    """Find-and-replace text in a file. Relative paths resolve from ~/.lightclaw.

    Args:
        file_path: Path to the file.
        old_text: Exact text to find.
        new_text: Replacement text.
    """
    from ...tools.file_io import edit_file as _impl

    resp = await _impl(file_path=file_path, old_text=old_text, new_text=new_text)
    return resp.to_str()


# ---------------------------------------------------------------------------
# 5. browser_use
# ---------------------------------------------------------------------------
@tool
async def browser_use(
    action: str,
    url: str = "",
    page_id: str = "default",
    selector: str = "",
    text: str = "",
    code: str = "",
    path: str = "",
    wait: int = 0,
    full_page: bool = False,
    width: int = 0,
    height: int = 0,
    level: str = "info",
    filename: str = "",
    accept: bool = True,
    prompt_text: str = "",
    ref: str = "",
    element: str = "",
    paths_json: str = "",
    fields_json: str = "",
    key: str = "",
    submit: bool = False,
    slowly: bool = False,
    include_static: bool = False,
    screenshot_type: str = "png",
    snapshot_filename: str = "",
    double_click: bool = False,
    button: str = "left",
    modifiers_json: str = "",
    start_ref: str = "",
    end_ref: str = "",
    start_selector: str = "",
    end_selector: str = "",
    start_element: str = "",
    end_element: str = "",
    values_json: str = "",
    tab_action: str = "",
    index: int = -1,
    wait_time: float = 0,
    text_gone: str = "",
    frame_selector: str = "",
    headed: bool = False,
) -> str:
    """Control browser (Playwright). Default is headless. Use headed=True with action=start to open a visible browser window.

    Flow: start → open(url) → snapshot to get refs → click/type etc. with ref or selector. Use page_id for multiple tabs.

    Args:
        action: Required. Values: start, stop, open, navigate, navigate_back, snapshot, screenshot, click, type, eval, evaluate, resize, console_messages, network_requests, handle_dialog, file_upload, fill_form, install, press_key, run_code, drag, hover, select_option, tabs, wait_for, pdf, close.
        url: URL for open/navigate.
        page_id: Page/tab identifier (default "default").
        selector: CSS selector for element targeting.
        text: Text for type action.
        code: JavaScript for eval/evaluate/run_code.
        path: File path for screenshot/PDF.
        wait: Milliseconds to wait after click.
        full_page: Capture full page screenshot.
        width: Viewport width for resize.
        height: Viewport height for resize.
        level: Console log level filter.
        filename: Filename for file_upload.
        accept: Accept/dismiss dialog.
        prompt_text: Text for dialog prompt.
        ref: Element ref from snapshot.
        element: Element description for AI-based selection.
        paths_json: JSON array of file paths for file_upload.
        fields_json: JSON object for fill_form.
        key: Key for press_key.
        submit: Submit form after fill.
        slowly: Type slowly (one char at a time).
        include_static: Include static resources in network_requests.
        screenshot_type: Screenshot format (png/jpeg).
        snapshot_filename: Save snapshot to file.
        double_click: Double-click instead of single.
        button: Mouse button (left/right/middle).
        modifiers_json: JSON array of key modifiers.
        start_ref: Drag start ref.
        end_ref: Drag end ref.
        start_selector: Drag start CSS selector.
        end_selector: Drag end CSS selector.
        start_element: Drag start element description.
        end_element: Drag end element description.
        values_json: JSON array of values for select_option.
        tab_action: Tab action (list/switch/new/close).
        index: Tab index for switch.
        wait_time: Seconds to wait for wait_for action.
        text_gone: Text to wait to disappear.
        frame_selector: CSS selector for iframe.
        headed: Open visible browser window.
    """
    from ...tools.browser_control import browser_use as _impl

    resp = await _impl(
        action=action,
        url=url,
        page_id=page_id,
        selector=selector,
        text=text,
        code=code,
        path=path,
        wait=wait,
        full_page=full_page,
        width=width,
        height=height,
        level=level,
        filename=filename,
        accept=accept,
        prompt_text=prompt_text,
        ref=ref,
        element=element,
        paths_json=paths_json,
        fields_json=fields_json,
        key=key,
        submit=submit,
        slowly=slowly,
        include_static=include_static,
        screenshot_type=screenshot_type,
        snapshot_filename=snapshot_filename,
        double_click=double_click,
        button=button,
        modifiers_json=modifiers_json,
        start_ref=start_ref,
        end_ref=end_ref,
        start_selector=start_selector,
        end_selector=end_selector,
        start_element=start_element,
        end_element=end_element,
        values_json=values_json,
        tab_action=tab_action,
        index=index,
        wait_time=wait_time,
        text_gone=text_gone,
        frame_selector=frame_selector,
        headed=headed,
    )
    return resp.to_str()


# ---------------------------------------------------------------------------
# 6. desktop_screenshot
# ---------------------------------------------------------------------------
@tool
async def desktop_screenshot(
    path: str = "",
    capture_window: bool = False,
) -> str:
    """Capture a screenshot of the entire desktop or a single window.

    Args:
        path: Optional path to save the screenshot (default: temp file).
        capture_window: If True on macOS, click a window to capture it.
    """
    from ...tools.desktop_screenshot import desktop_screenshot as _impl

    resp = await _impl(path=path, capture_window=capture_window)
    return _serialize_tool_result(resp)


# ---------------------------------------------------------------------------
# 7. send_file_to_user
# ---------------------------------------------------------------------------
@tool
async def send_file_to_user(
    file_path: str,
) -> str:
    """Send a file to the user (image/audio/video/generic file).

    Args:
        file_path: Path to the file to send.
    """
    from ...tools.send_file import send_file_to_user as _impl

    resp = await _impl(file_path=file_path)
    return _serialize_tool_result(resp)


# ---------------------------------------------------------------------------
# 8. get_current_time
# ---------------------------------------------------------------------------
@tool
async def get_current_time() -> str:
    """Get the current system time with timezone info (e.g. '2026-02-13 19:30:45 CST (UTC+0800)')."""
    from ...tools.get_current_time import get_current_time as _impl

    resp = await _impl()
    return resp.to_str()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
def load_builtin_tools() -> list:
    """Return all 8 built-in tools as LangChain tool instances.

    These match the tools registered in ``LightClawAgent._create_toolkit()``.
    """
    return [
        execute_shell_command,
        read_file,
        write_file,
        edit_file,
        browser_use,
        desktop_screenshot,
        send_file_to_user,
        get_current_time,
    ]
