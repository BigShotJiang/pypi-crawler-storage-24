# -*- coding: utf-8 -*-
"""LangGraph-native command handler.

This replaces the PR4 fallback of delegating commands to AgentScope.
Commands operate directly on LangChain messages and the session store,
without requiring a ``LightClawAgent`` instance.

Supported commands:
    /compact       — Summarise old messages and discard originals
    /new           — Start fresh conversation (background summary)
    /clear         — Wipe all history
    /history       — Show conversation stats
    /compact_str   — Show current compressed summary
    /await_summary — Wait for background summary tasks
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from ...app.schemas.message_types import Message
from langchain_core.messages import BaseMessage, SystemMessage

from ..utils import safe_count_str_tokens
from .message_converter import langchain_to_msgs

if TYPE_CHECKING:
    from ..memory import MemoryManager
    from .middleware import LightClawMiddleware
    from .session_store import LangGraphSessionStore

logger = logging.getLogger(__name__)


# Re-export the command set for external use
SYSTEM_COMMANDS = frozenset(
    {"compact", "new", "clear", "history", "compact_str", "await_summary"},
)


def is_command(query: str | None) -> bool:
    """Check if query is a system command (static, no instance needed)."""
    if not isinstance(query, str):
        return False
    stripped = query.strip()
    if not stripped.startswith("/"):
        return False
    return stripped.lstrip("/") in SYSTEM_COMMANDS


class LangGraphCommandHandler:
    """Handle system commands for the LangGraph path.

    Unlike the AgentScope ``CommandHandler``, this operates on:
    * ``list[BaseMessage]`` (the LangGraph state) instead of agent.memory
    * ``LightClawMiddleware`` for compressed summary state
    * ``LangGraphSessionStore`` for persistence
    """

    def __init__(
        self,
        *,
        agent_name: str = "LightClaw",
        history_messages: list[BaseMessage],
        middleware: "LightClawMiddleware",
        session_store: "LangGraphSessionStore",
        session_id: str,
        user_id: str | None,
        channel: str = "",
        memory_manager: "MemoryManager | None" = None,
    ) -> None:
        self._agent_name = agent_name
        self._history = history_messages
        self._middleware = middleware
        self._session_store = session_store
        self._session_id = session_id
        self._user_id = user_id
        self._channel = channel
        self._memory_manager = memory_manager

    def _make_msg(self, text: str) -> Message:
        return Message(
            role="assistant",
            content=[{"type": "text", "text": text}],
        )

    @property
    def _non_system_messages(self) -> list[BaseMessage]:
        return [m for m in self._history if not isinstance(m, SystemMessage)]

    # ------------------------------------------------------------------
    # Command dispatch
    # ------------------------------------------------------------------

    async def handle(self, query: str) -> Message:
        """Dispatch a command string to its handler."""
        command = query.strip().lstrip("/")
        handler = getattr(self, f"_cmd_{command}", None)
        if handler is None:
            return self._make_msg(f"Unknown command: {query}")
        logger.info("LangGraph command handler: /%s", command)
        return await handler()

    # ------------------------------------------------------------------
    # Individual commands
    # ------------------------------------------------------------------

    async def _cmd_compact(self) -> Message:
        msgs = self._non_system_messages
        if not msgs:
            return self._make_msg(
                "**No messages to compact.**\n\n- Current memory is empty",
            )
        if self._memory_manager is None:
            return self._make_msg(
                "**Memory Manager Disabled**\n\n- Memory compaction is not available",
            )

        # Convert to internal Message for MemoryManager
        internal_msgs = langchain_to_msgs(msgs)
        self._memory_manager.add_async_summary_task(
            messages=internal_msgs,
            channel=self._channel,
            session_id=self._session_id,
        )

        compact_content = await self._memory_manager.compact_memory(
            messages_to_summarize=internal_msgs,
            previous_summary=self._middleware.compressed_summary,
        )
        self._middleware.compressed_summary = compact_content

        # Clear history (keep only system messages)
        sys_msgs = [m for m in self._history if isinstance(m, SystemMessage)]
        self._history.clear()
        self._history.extend(sys_msgs)

        # Persist
        await self._session_store.asave(
            self._session_id,
            self._user_id,
            self._history,
            compressed_summary=compact_content,
        )

        return self._make_msg(
            f"**Compact Complete!**\n\n"
            f"- Messages compacted: {len(msgs)}\n"
            f"**Compressed Summary:**\n{compact_content}\n"
            f"- Summary task started in background",
        )

    async def _cmd_new(self) -> Message:
        msgs = self._non_system_messages
        if not msgs:
            self._middleware.compressed_summary = ""
            return self._make_msg(
                "**No messages to summarize.**\n\n- Ready for new conversation",
            )
        if self._memory_manager is None:
            return self._make_msg(
                "**Memory Manager Disabled**\n\n"
                "- Cannot start new conversation with summary",
            )

        internal_msgs = langchain_to_msgs(msgs)
        self._memory_manager.add_async_summary_task(
            messages=internal_msgs,
            channel=self._channel,
            session_id=self._session_id,
        )
        self._middleware.compressed_summary = ""

        # Clear all non-system messages
        sys_msgs = [m for m in self._history if isinstance(m, SystemMessage)]
        self._history.clear()
        self._history.extend(sys_msgs)

        await self._session_store.asave(
            self._session_id,
            self._user_id,
            self._history,
            compressed_summary="",
        )

        return self._make_msg(
            "**New Conversation Started!**\n\n"
            "- Summary task started in background\n"
            "- Ready for new conversation",
        )

    async def _cmd_clear(self) -> Message:
        self._history.clear()
        self._middleware.compressed_summary = ""
        await self._session_store.aclear(self._session_id, self._user_id)
        return self._make_msg(
            "**History Cleared!**\n\n- Memory is now empty",
        )

    async def _cmd_history(self) -> Message:
        msgs = self._non_system_messages
        summary = self._middleware.compressed_summary or ""
        summary_tokens = safe_count_str_tokens(summary)

        # Estimate total tokens
        total_chars = sum(
            len(m.content) if isinstance(m.content, str) else len(str(m.content))
            for m in msgs
        )
        msg_tokens = total_chars // 4  # rough estimate
        estimated_tokens = msg_tokens + summary_tokens

        lines = []
        for i, m in enumerate(msgs, 1):
            role = type(m).__name__.replace("Message", "")
            content_preview = (
                m.content[:100] + "..."
                if isinstance(m.content, str) and len(m.content) > 100
                else str(m.content)[:100]
            )
            lines.append(f"[{i}] **{role}**: {content_preview}")

        return self._make_msg(
            f"**Conversation History**\n\n"
            f"- Total messages: {len(msgs)}\n"
            f"- Estimated tokens: ~{estimated_tokens}\n"
            f"- Compressed summary tokens: {summary_tokens}\n\n" + "\n\n".join(lines),
        )

    async def _cmd_compact_str(self) -> Message:
        summary = self._middleware.compressed_summary
        if not summary:
            return self._make_msg(
                "**No Compressed Summary**\n\n"
                "- Use /compact or wait for auto-compaction",
            )
        return self._make_msg(f"**Compressed Summary**\n\n{summary}")

    async def _cmd_await_summary(self) -> Message:
        if self._memory_manager is None:
            return self._make_msg(
                "**Memory Manager Disabled**\n\n- Cannot await summary tasks",
            )
        task_count = len(self._memory_manager.summary_tasks)
        if task_count == 0:
            return self._make_msg(
                "**No Summary Tasks**\n\n- No pending tasks to wait for",
            )
        result = await self._memory_manager.await_summary_tasks()
        return self._make_msg(
            f"**Summary Tasks Complete**\n\n"
            f"- Waited for {task_count} task(s)\n"
            f"- {result}\n"
            f"- All tasks finished",
        )
