# -*- coding: utf-8 -*-
"""Factory for creating LangChain-compatible chat models.

Bridges LightClaw's existing provider configuration (providers.json) to
LangChain's ``BaseChatModel`` hierarchy so the rest of the LangGraph
pipeline can stay provider-agnostic.

Supports multiple model providers (OpenAI, Anthropic, Google, Ollama,
Azure, and any OpenAI-compatible endpoint) via the ``chat_model`` field
in each provider definition.

Example:
    >>> from lightclaw.agent.langgraph.model_factory import create_chat_model
    >>> model = create_chat_model()          # uses active provider
    >>> model = create_chat_model(llm_cfg)   # explicit config
"""

from __future__ import annotations

import logging
import os
from typing import TYPE_CHECKING, Optional


if TYPE_CHECKING:
    from langchain_core.language_models import BaseChatModel

    from ...providers.models import ResolvedModelConfig

logger = logging.getLogger(__name__)


def _resolve_chat_model_name(provider_id: str) -> str:
    """Look up the ``chat_model`` class name for *provider_id*.

    Returns ``"ChatOpenAI"`` when the provider is unknown or has no
    explicit ``chat_model`` configured.
    """
    if not provider_id:
        return "ChatOpenAI"

    try:
        from ...providers.registry import get_provider_chat_model

        name = get_provider_chat_model(provider_id)
        # Map legacy AgentScope names to LangChain equivalents
        if name == "OpenAIChatModel":
            return "ChatOpenAI"
        return name
    except Exception:
        return "ChatOpenAI"


def create_chat_model(
    llm_cfg: Optional["ResolvedModelConfig"] = None,
) -> "BaseChatModel":
    """Create a LangChain ``BaseChatModel`` from LightClaw provider config.

    Resolution order:
    1. If *llm_cfg* is provided, use it directly.
    2. Otherwise call ``get_active_llm_config()`` to read providers.json.
    3. Fallback: ``DASHSCOPE_API_KEY`` env var + qwen3-max.

    The concrete ``BaseChatModel`` subclass (``ChatOpenAI``,
    ``ChatAnthropic``, ``ChatGoogleGenerativeAI``, etc.) is determined
    by the provider's ``chat_model`` field in providers.json.

    Args:
        llm_cfg: Resolved model configuration.  When ``None``, the
            active configuration is loaded automatically.

    Returns:
        A ready-to-use LangChain chat model.
    """
    if llm_cfg is None:
        from ...providers import get_active_llm_config

        llm_cfg = get_active_llm_config()

    return _create_remote_model(llm_cfg)


def _create_remote_model(
    llm_cfg: Optional["ResolvedModelConfig"],
) -> "BaseChatModel":
    """Create a remote chat model, routing to the correct LangChain class."""
    if llm_cfg and (llm_cfg.model or llm_cfg.base_url or llm_cfg.provider_id):
        model_name = llm_cfg.model or "qwen3-max"
        api_key = llm_cfg.api_key
        base_url = llm_cfg.base_url
        provider_id = llm_cfg.provider_id
    else:
        logger.warning(
            "No active LLM configured — falling back to DASHSCOPE_API_KEY env var",
        )
        model_name = "qwen3-max"
        api_key = os.getenv("DASHSCOPE_API_KEY", "")
        base_url = "https://dashscope.aliyuncs.com/compatible-mode/v1"
        provider_id = ""

    chat_model_name = _resolve_chat_model_name(provider_id)

    from ...providers.registry import get_langchain_model_class

    model_class = get_langchain_model_class(chat_model_name)

    return _instantiate_model(
        model_class=model_class,
        chat_model_name=chat_model_name,
        model_name=model_name,
        api_key=api_key,
        base_url=base_url,
    )


def _instantiate_model(
    *,
    model_class: type,
    chat_model_name: str,
    model_name: str,
    api_key: str,
    base_url: str,
) -> "BaseChatModel":
    """Instantiate a LangChain ChatModel with provider-specific parameters.

    Different providers have slightly different constructor signatures;
    this function handles the variance.
    """
    if chat_model_name == "ChatAnthropic":
        kwargs: dict = {
            "model": model_name,
            "api_key": api_key,
            "streaming": True,
            "stream_usage": True,
        }
        if base_url:
            kwargs["base_url"] = base_url
        return model_class(**kwargs)

    if chat_model_name == "ChatGoogleGenerativeAI":
        # Current langchain-google-genai does not accept `stream_usage`.
        return model_class(
            model=model_name,
            google_api_key=api_key,
            streaming=True,
        )

    if chat_model_name == "ChatOllama":
        kwargs: dict = {
            "model": model_name,
        }
        if base_url:
            kwargs["base_url"] = base_url
        return model_class(**kwargs)

    if chat_model_name == "AzureChatOpenAI":
        return model_class(
            model=model_name,
            api_key=api_key or "lightclaw-local",
            azure_endpoint=base_url,
            streaming=True,
            stream_usage=True,
        )

    # Default: ChatOpenAI and any OpenAI-compatible API
    return model_class(
        model=model_name,
        api_key=api_key or "lightclaw-local",
        base_url=base_url,
        streaming=True,
        stream_usage=True,
    )
