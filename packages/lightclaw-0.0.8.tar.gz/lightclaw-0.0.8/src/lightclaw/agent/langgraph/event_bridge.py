# -*- coding: utf-8 -*-
"""LangGraph EventBridge — streams LangGraph events as ``(Message, is_last)`` tuples.

This module is a **drop-in replacement** for the AgentScope-based
``EventBridge`` in ``app/runner/event_bridge.py``.  It consumes the
``astream_events`` (v2) stream from a compiled LangGraph graph and
yields ``(Message, is_last)`` tuples with exactly the same semantics the
Channel / Runner layers expect.

Event mapping (LangGraph v2 → Message):
    on_chat_model_stream   → Message(role="assistant", text chunk)   [is_last=False]
    on_tool_start          → (optionally logged, not yielded)
    on_tool_end            → Message(role="user", ToolResultBlock)   [is_last=False]
    on_chain_end(LangGraph)→ final Message from output messages      [is_last=True]

Usage:
    >>> bridge = LangGraphEventBridge()
    >>> async for msg, last in bridge.stream(graph, messages):
    ...     channel.send(msg, is_last=last)
"""

from __future__ import annotations

from copy import deepcopy
import logging
from numbers import Real
import warnings
from typing import TYPE_CHECKING, Any, AsyncIterator, Optional, Sequence

from langgraph.errors import GraphRecursionError

from ...app.schemas.message_types import Message

from .message_converter import langchain_to_msg

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


def _coerce_dict_like(value: Any) -> dict[str, Any] | None:
    """Convert pydantic-ish metadata objects to plain dicts when possible."""
    if value is None:
        return None
    if hasattr(value, "model_dump"):
        value = value.model_dump(exclude_none=True)
    elif hasattr(value, "dict"):
        value = value.dict(exclude_none=True)
    if isinstance(value, dict):
        return dict(value)
    return None


def _coerce_usage(value: Any) -> dict[str, Any] | None:
    """Return a normalized usage dict or ``None`` when unavailable."""
    usage = _coerce_dict_like(value)
    if usage:
        return usage
    return None


def _extract_usage_metadata(message: Any) -> dict[str, Any] | None:
    """Extract LangChain-standard usage metadata from a message-like object."""
    return _coerce_usage(getattr(message, "usage_metadata", None))


def _sum_usage(
    left: dict[str, Any] | None,
    right: dict[str, Any] | None,
) -> dict[str, Any] | None:
    """Recursively sum numeric usage fields while preserving nested structure."""
    if not right:
        return deepcopy(left) if left else None

    result = deepcopy(left) if left else {}
    for key, value in right.items():
        if isinstance(value, dict):
            merged = _sum_usage(
                result.get(key) if isinstance(result.get(key), dict) else None,
                _coerce_dict_like(value),
            )
            if merged:
                result[key] = merged
            continue

        if isinstance(value, Real) and not isinstance(value, bool):
            current = result.get(key, 0)
            if not isinstance(current, Real) or isinstance(current, bool):
                current = 0
            result[key] = current + value

    return result or None


class _UsageAggregator:
    """Aggregate per-chat-model usage without double counting stream fallbacks."""

    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        self._final_usage_by_run_id: dict[str, dict[str, Any]] = {}
        self._fallback_usage_by_run_id: dict[str, dict[str, Any]] = {}
        self._run_order: list[str] = []

    def record_stream_chunk(self, run_id: str, chunk: Any) -> None:
        usage = _extract_usage_metadata(chunk)
        if not usage or not run_id:
            return
        self._remember_run(run_id)
        self._fallback_usage_by_run_id[run_id] = usage

    def record_final_message(self, run_id: str, message: Any) -> None:
        usage = _extract_usage_metadata(message)
        if not usage or not run_id:
            return
        self._remember_run(run_id)
        self._final_usage_by_run_id[run_id] = usage

    @property
    def run_usage(self) -> dict[str, Any] | None:
        total: dict[str, Any] | None = None
        for run_id in self._run_order:
            usage = self._final_usage_by_run_id.get(run_id)
            if usage is None:
                usage = self._fallback_usage_by_run_id.get(run_id)
            total = _sum_usage(total, usage)
        return total

    @property
    def last_usage(self) -> dict[str, Any] | None:
        for run_id in reversed(self._run_order):
            usage = self._final_usage_by_run_id.get(run_id)
            if usage is None:
                usage = self._fallback_usage_by_run_id.get(run_id)
            if usage is not None:
                return deepcopy(usage)
        return None

    def _remember_run(self, run_id: str) -> None:
        if run_id not in self._run_order:
            self._run_order.append(run_id)


class LangGraphEventBridge:
    """Bridge LangGraph ``astream_events`` to ``(Message, is_last)`` tuples.

    This keeps the external contract identical to the original
    ``EventBridge.stream_agent_run`` so that Channels, RunController
    and session-saving logic need **zero** changes.
    """

    def __init__(
        self,
        *,
        emit_tool_events: bool = False,
        stream_version: str = "v2",
    ) -> None:
        """
        Args:
            emit_tool_events: If ``True``, tool start/end events are
                also yielded as Msg.  Defaults to ``False`` (only LLM
                stream tokens and the final message are emitted).
            stream_version: astream_events version. ``"v2"`` recommended.
        """
        self._emit_tool_events = emit_tool_events
        self._stream_version = stream_version
        # PR5: capture final output messages for session persistence
        self.final_output_messages: list = []
        self.final_output_usage: dict[str, Any] | None = None
        self.run_usage: dict[str, Any] | None = None
        # Track whether tool events have been streamed so we can avoid
        # duplicating them in the final ``on_chain_end`` message.
        self._streamed_tool_events: bool = False
        self._usage_aggregator = _UsageAggregator()

    async def stream(
        self,
        graph: Any,
        messages: Sequence[Any],
        config: Optional[dict] = None,
        max_iterations: Optional[int] = None,
    ) -> AsyncIterator[tuple[Message, bool]]:
        """Stream a LangGraph agent run, yielding ``(Message, is_last)`` tuples.

        This is the main entry point — analogous to the old
        ``EventBridge.stream_agent_run(agent=..., msgs=...)``.

        Args:
            graph: A compiled LangGraph graph (``CompiledStateGraph``).
            messages: The input messages — either LangChain ``BaseMessage``
                list or ``("role", "content")`` tuples.
            config: Optional ``RunnableConfig`` dict, e.g.
                ``{"configurable": {"thread_id": "..."}}``.
            max_iterations: Maximum ReAct loop iterations. Maps to
                ``recursion_limit`` in LangGraph (``max_iterations * 2 + 1``).
                If ``None``, LangGraph's default is used.

        Yields:
            ``(Message, is_last)`` — an internal ``Message`` and a bool indicating
            whether this is the final message of the run.
        """
        self.final_output_messages = []
        self.final_output_usage = None
        self.run_usage = None
        self._streamed_tool_events = False
        self._usage_aggregator.reset()

        final_result: dict | None = None
        text_buffer: list[str] = []

        # 将 max_iterations 换算为 LangGraph recursion_limit 并注入 config
        # 每次 ReAct 循环包含 agent 节点 + tools 节点 = 2 步，最后一次 agent 输出 +1
        run_config = dict(config or {})
        if max_iterations is not None:
            run_config["recursion_limit"] = max_iterations * 2 + 1
            logger.debug(
                "Setting recursion_limit=%d (max_iterations=%d)",
                run_config["recursion_limit"],
                max_iterations,
            )

        try:
            with warnings.catch_warnings():
                warnings.filterwarnings("ignore", category=DeprecationWarning)

                async for event in graph.astream_events(
                    {"messages": list(messages)},
                    config=run_config,
                    version=self._stream_version,
                ):
                    kind = event.get("event", "")

                    # ── LLM streaming token ──
                    if kind == "on_chat_model_stream":
                        chunk = event.get("data", {}).get("chunk")
                        if chunk is None:
                            continue
                        self._usage_aggregator.record_stream_chunk(
                            str(event.get("run_id", "") or ""),
                            chunk,
                        )

                        content = getattr(chunk, "content", None)
                        if content and isinstance(content, str):
                            text_buffer.append(content)
                            yield (
                                Message(
                                    role="assistant",
                                    content=[{"type": "text", "text": content}],
                                ),
                                False,
                            )

                        # Handle thinking blocks in streaming
                        thinking = (getattr(chunk, "additional_kwargs", {}) or {}).get(
                            "thinking"
                        )
                        if thinking:
                            yield (
                                Message(
                                    role="assistant",
                                    content=[
                                        {"type": "thinking", "thinking": thinking}
                                    ],
                                ),
                                False,
                            )

                    elif kind == "on_chat_model_end":
                        self._usage_aggregator.record_final_message(
                            str(event.get("run_id", "") or ""),
                            event.get("data", {}).get("output"),
                        )

                    # ── Tool execution events ──
                    elif kind == "on_tool_start" and self._emit_tool_events:
                        self._streamed_tool_events = True
                        tool_name = event.get("name", "unknown")
                        tool_input = event.get("data", {}).get("input", {})
                        yield (
                            Message(
                                role="assistant",
                                content=[
                                    {
                                        "type": "tool_use",
                                        "id": event.get("run_id", ""),
                                        "name": tool_name,
                                        "input": tool_input
                                        if isinstance(tool_input, dict)
                                        else {"input": str(tool_input)},
                                    }
                                ],
                            ),
                            False,
                        )

                    elif kind == "on_tool_end" and self._emit_tool_events:
                        tool_output = event.get("data", {}).get("output", "")
                        if hasattr(tool_output, "content"):
                            tool_output = tool_output.content
                        yield (
                            Message(
                                role="user",
                                content=[
                                    {
                                        "type": "tool_result",
                                        "id": event.get("run_id", ""),
                                        "name": event.get("name", ""),
                                        "output": str(tool_output),
                                    }
                                ],
                            ),
                            False,
                        )

                    # ── Graph execution complete ──
                    elif kind == "on_chain_end" and event.get("name") == "LangGraph":
                        output = event.get("data", {}).get("output", {})
                        final_messages = output.get("messages", [])
                        if final_messages:
                            final_result = final_messages[-1]
                            # PR5: capture all output messages for persistence
                            self.final_output_messages = list(final_messages)

        except GraphRecursionError:
            self.run_usage = self._usage_aggregator.run_usage
            self.final_output_usage = self._usage_aggregator.last_usage
            # 达到最大迭代次数，向用户返回友好引导消息
            logger.warning(
                "GraphRecursionError: reached recursion_limit (max_iterations=%s)",
                max_iterations,
            )
            yield (
                Message(
                    role="assistant",
                    content=[
                        {
                            "type": "text",
                            "text": (
                                "⚠️ 已达到最大迭代次数限制，任务未能在限定步骤内完成。\n\n"
                                "**建议：**\n"
                                "- 尝试将任务拆分为更小的子任务后重新提问\n"
                                "- 在「运行配置」中适当增大「最大迭代次数」\n"
                                "- 或者换一种更简洁的方式描述你的需求"
                            ),
                        }
                    ],
                ),
                True,
            )
            return

        self.run_usage = self._usage_aggregator.run_usage

        # ── Yield final message ──
        if final_result is not None:
            final_msg = langchain_to_msg(final_result)
            final_usage = _coerce_usage(getattr(final_msg, "usage", None))
            if final_usage is None and final_msg.role == "assistant":
                final_usage = self._usage_aggregator.last_usage
                if final_usage is not None:
                    final_msg = final_msg.model_copy(
                        update={"usage": deepcopy(final_usage)}
                    )
            self.final_output_usage = deepcopy(final_usage) if final_usage else None

            # Strip blocks that have already been streamed to avoid
            # duplicating content on the client side.
            if text_buffer or self._streamed_tool_events:
                filtered_blocks: list[dict] = []
                if isinstance(final_msg.content, list):
                    for block in final_msg.content:
                        if not isinstance(block, dict):
                            filtered_blocks.append(block)
                            continue
                        btype = block.get("type", "")
                        # Skip text blocks already streamed token-by-token
                        if btype == "text" and text_buffer:
                            continue
                        # Skip tool blocks already emitted via
                        # on_tool_start / on_tool_end events
                        if (
                            btype in ("tool_use", "tool_result")
                            and self._streamed_tool_events
                        ):
                            continue
                        filtered_blocks.append(block)

                if filtered_blocks:
                    # There are remaining blocks (e.g. thinking, image)
                    # that were NOT streamed — yield them.
                    yield (
                        final_msg.model_copy(update={"content": filtered_blocks}),
                        True,
                    )
                else:
                    # Everything was already streamed — yield an empty
                    # marker so downstream knows the run is complete.
                    yield (
                        Message(
                            role="assistant",
                            content=[{"type": "text", "text": ""}],
                            usage=self.final_output_usage,
                        ),
                        True,
                    )
            else:
                # Nothing was streamed (e.g. very short or non-streaming
                # response) — yield the full final message as-is.
                yield final_msg, True
        else:
            # Fallback: assemble from buffer
            full_text = "".join(text_buffer) if text_buffer else ""
            self.final_output_usage = self._usage_aggregator.last_usage
            yield (
                Message(
                    role="assistant",
                    content=[{"type": "text", "text": full_text}],
                    usage=self.final_output_usage,
                ),
                True,
            )

    async def stream_agent_run(
        self,
        *,
        graph: Any,
        messages: Sequence[Any],
        config: Optional[dict] = None,
        max_iterations: Optional[int] = None,
    ) -> AsyncIterator[tuple[Message, bool]]:
        """Alias matching the old ``EventBridge.stream_agent_run`` signature.

        This exists for compatibility so ``RunController`` can call the
        same method name whether using the old or new bridge.
        """
        async for msg, last in self.stream(
            graph, messages, config=config, max_iterations=max_iterations
        ):
            yield msg, last
