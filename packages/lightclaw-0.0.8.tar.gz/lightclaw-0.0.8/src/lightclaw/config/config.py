# -*- coding: utf-8 -*-
import os
from typing import Optional, Union, Dict, List, Literal
from pydantic import BaseModel, Field, ConfigDict, model_validator

from ..constant import (
    HEARTBEAT_DEFAULT_EVERY,
    HEARTBEAT_DEFAULT_TARGET,
)

# Import ProvidersData here to embed it in Config.
# Use a TYPE_CHECKING guard for the heavy provider registry to avoid
# circular imports at module load time.
from ..providers.models import ProvidersData


class BaseChannelConfig(BaseModel):
    """Base for channel config (read from lightclaw.json, no env)."""

    model_config = ConfigDict(populate_by_name=True)

    enabled: bool = False
    bot_prefix: str = Field(default="", alias="botPrefix")


class DiscordConfig(BaseChannelConfig):
    bot_token: str = Field(default="", alias="botToken")
    http_proxy: str = Field(default="", alias="httpProxy")
    http_proxy_auth: str = Field(default="", alias="httpProxyAuth")


class DingTalkConfig(BaseChannelConfig):
    """DingTalk: client_id, client_secret; media_dir for received media."""

    client_id: str = Field(default="", alias="clientId")
    client_secret: str = Field(default="", alias="clientSecret")
    media_dir: str = Field(default="~/.lightclaw/media", alias="mediaDir")


class FeishuConfig(BaseChannelConfig):
    """Feishu/Lark channel: app_id, app_secret; optional encrypt_key,
    verification_token for event handler. media_dir for received media.
    """

    app_id: str = Field(default="", alias="appId")
    app_secret: str = Field(default="", alias="appSecret")
    encrypt_key: str = Field(default="", alias="encryptKey")
    verification_token: str = Field(default="", alias="verificationToken")
    media_dir: str = Field(default="~/.lightclaw/media", alias="mediaDir")


class QQConfig(BaseChannelConfig):
    app_id: str = Field(default="", alias="appId")
    client_secret: str = Field(default="", alias="clientSecret")


class DashboardConfig(BaseChannelConfig):
    """Dashboard channel: prints agent responses to stdout."""

    enabled: bool = True


class ChannelConfig(BaseModel):
    """Built-in channel configs; extra keys allowed for plugin channels."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    discord: DiscordConfig = DiscordConfig()
    dingtalk: DingTalkConfig = DingTalkConfig()
    feishu: FeishuConfig = FeishuConfig()
    qqbot: QQConfig = Field(default_factory=QQConfig)
    dashboard: DashboardConfig = DashboardConfig()

    @model_validator(mode="before")
    @classmethod
    def _normalize_qq_key(cls, data):
        """Backward compat: map legacy 'qq' key to 'qqbot'."""
        if isinstance(data, dict) and "qq" in data and "qqbot" not in data:
            data = dict(data)
            data["qqbot"] = data.pop("qq")
        return data


class LastApiConfig(BaseModel):
    host: Optional[str] = None
    port: Optional[int] = None


class ActiveHoursConfig(BaseModel):
    """Optional active window for heartbeat (e.g. 08:00–22:00)."""

    start: str = "08:00"
    end: str = "22:00"


class HeartbeatConfig(BaseModel):
    """Heartbeat: run agent with HEARTBEAT.md as query at interval."""

    model_config = {"populate_by_name": True}

    every: str = Field(default=HEARTBEAT_DEFAULT_EVERY)
    target: str = Field(default=HEARTBEAT_DEFAULT_TARGET)
    active_hours: Optional[ActiveHoursConfig] = Field(
        default=None,
        alias="activeHours",
    )


class AgentsDefaultsConfig(BaseModel):
    heartbeat: Optional[HeartbeatConfig] = None


class AgentsRunningConfig(BaseModel):
    """Agent runtime behavior configuration."""

    model_config = ConfigDict(populate_by_name=True)

    max_iters: int = Field(
        default=50,
        ge=1,
        alias="maxIters",
        description=("Maximum number of reasoning-acting iterations for ReAct agent"),
    )
    max_input_length: int = Field(
        default=128 * 1024,  # 128K = 131072 tokens
        ge=1000,
        alias="maxInputLength",
        description=("Maximum input length (tokens) for the model context window"),
    )


class AgentsConfig(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    defaults: AgentsDefaultsConfig = Field(
        default_factory=AgentsDefaultsConfig,
    )
    running: AgentsRunningConfig = Field(
        default_factory=AgentsRunningConfig,
    )
    language: str = Field(
        default="zh",
        description="Language for agent MD files (en/zh)",
    )
    installed_md_files_language: Optional[str] = Field(
        default=None,
        alias="installedMdFilesLanguage",
        description="Language of currently installed md files",
    )


class LastDispatchConfig(BaseModel):
    """Last channel/user/session that received a user-originated reply."""

    model_config = ConfigDict(populate_by_name=True)

    channel: str = ""
    user_id: str = Field(default="", alias="userId")
    session_id: str = Field(default="", alias="sessionId")


class MCPClientConfig(BaseModel):
    """Configuration for a single MCP client.

    Supports three transport types:
    - ``stdio``: Launch a local process (requires ``command``).
    - ``streamable_http``: Connect to a remote HTTP MCP endpoint (requires ``url``).
    - ``sse``: Connect via Server-Sent Events (requires ``url``).
    """

    model_config = ConfigDict(populate_by_name=True)

    name: str
    description: str = ""
    enabled: bool = True
    transport: Literal["stdio", "streamable_http", "sse"] = "stdio"
    url: str = ""
    headers: Dict[str, str] = Field(default_factory=dict)
    command: str = ""
    args: List[str] = Field(default_factory=list)
    env: Dict[str, str] = Field(default_factory=dict)
    cwd: str = ""

    @model_validator(mode="before")
    @classmethod
    def _normalize_legacy_fields(cls, data):
        """Normalize common MCP field aliases from third-party examples."""
        if not isinstance(data, dict):
            return data

        payload = dict(data)

        # Alias: isActive -> enabled
        if "isActive" in payload and "enabled" not in payload:
            payload["enabled"] = payload["isActive"]

        # Alias: baseUrl -> url
        if "baseUrl" in payload and "url" not in payload:
            payload["url"] = payload["baseUrl"]

        # Alias: type -> transport
        if "type" in payload and "transport" not in payload:
            payload["transport"] = payload["type"]

        # Auto-detect: has url but no command → streamable_http
        if (
            "transport" not in payload
            and (payload.get("url") or payload.get("baseUrl"))
            and not payload.get("command")
        ):
            payload["transport"] = "streamable_http"

        # Normalize transport aliases (http → streamable_http, etc.)
        raw_transport = payload.get("transport")
        if isinstance(raw_transport, str):
            normalized = raw_transport.strip().lower()
            transport_alias_map = {
                "streamablehttp": "streamable_http",
                "streamable_http": "streamable_http",
                "http": "streamable_http",
                "stdio": "stdio",
                "sse": "sse",
            }
            payload["transport"] = transport_alias_map.get(
                normalized,
                normalized,
            )

        return payload

    @model_validator(mode="after")
    def _validate_transport_config(self):
        """Validate required fields for each MCP transport type."""
        if self.transport == "stdio":
            if not self.command.strip():
                raise ValueError("stdio MCP client requires non-empty command")
            return self

        if not self.url.strip():
            raise ValueError(
                f"{self.transport} MCP client requires non-empty url",
            )
        return self


class MCPConfig(BaseModel):
    """MCP clients configuration.

    Uses a dict to allow dynamic client definitions.
    Default tavily_search client is created and auto-enabled if API key exists.
    """

    clients: Dict[str, MCPClientConfig] = Field(
        default_factory=lambda: {
            "tavily_search": MCPClientConfig(
                name="tavily_mcp",
                # Auto-enable if TAVILY_API_KEY exists in environment
                enabled=bool(os.getenv("TAVILY_API_KEY")),
                command="npx",
                args=["-y", "tavily-mcp@latest"],
                env={"TAVILY_API_KEY": os.getenv("TAVILY_API_KEY", "")},
            ),
        },
    )


class OpenClawConfig(BaseModel):
    """Optional pointers to the OpenClaw installation.

    When either field is set it overrides the default discovery logic used by
    the ``sync_from_openclaw`` command / API.

    Defaults (when fields are *None*):
    - ``config_path``    → ``~/.openclaw/openclaw.json``
    - ``workspace_path`` → value of ``agents.defaults.workspace`` inside that
                           openclaw.json (usually ``~/.openclaw/workspace``)
    """

    model_config = ConfigDict(populate_by_name=True)

    config_path: Optional[str] = Field(
        default=None,
        alias="configPath",
        description="Override path to openclaw.json",
    )
    workspace_path: Optional[str] = Field(
        default=None,
        alias="workspacePath",
        description="Override path to openclaw workspace directory",
    )


class SkillEntryConfig(BaseModel):
    """Configuration for a single skill entry (enabled/disabled)."""

    model_config = ConfigDict(populate_by_name=True)

    enabled: bool = True


class SkillsConfig(BaseModel):
    """Skills configuration — mirrors openclaw's plugins.entries pattern.

    Example lightclaw.json:
        {
          "skills": {
            "entries": {
              "pdf":  { "enabled": true },
              "xlsx": { "enabled": false }
            }
          }
        }

    Skills whose name does not appear in ``entries`` are treated as disabled.
    """

    model_config = ConfigDict(populate_by_name=True)

    entries: Dict[str, SkillEntryConfig] = Field(default_factory=dict)


class Config(BaseModel):
    """Root config (lightclaw.json)."""

    model_config = ConfigDict(populate_by_name=True)

    channels: ChannelConfig = ChannelConfig()
    mcp: MCPConfig = MCPConfig()
    last_api: LastApiConfig = Field(default_factory=LastApiConfig, alias="lastApi")
    agents: AgentsConfig = Field(default_factory=AgentsConfig)
    last_dispatch: Optional[LastDispatchConfig] = Field(
        default=None, alias="lastDispatch"
    )
    # When False, hide tool call/result messages entirely.
    show_tool_details: bool = Field(default=True, alias="showToolDetails")
    # Provider/model config — merged into lightclaw.json (openclaw-compatible).
    models: ProvidersData = Field(default_factory=ProvidersData)
    # Skills enable/disable config — mirrors openclaw plugins.entries pattern.
    skills: SkillsConfig = Field(default_factory=SkillsConfig)
    # Optional openclaw integration paths.
    openclaw: OpenClawConfig = Field(default_factory=OpenClawConfig)


# Mapping from runtime channel registry key -> ChannelConfig attribute name.
# Used when the lightclaw.json key (openclaw-compatible) differs from the
# internal channel identifier.  e.g. QQ channel runs as "qq" internally but
# stores its config under "qqbot" in lightclaw.json.
CHANNEL_REGISTRY_KEY_TO_CONFIG_ATTR: Dict[str, str] = {
    "qq": "qqbot",
}


ChannelConfigUnion = Union[
    DiscordConfig,
    DingTalkConfig,
    FeishuConfig,
    QQConfig,
    DashboardConfig,
]
