# -*- coding: utf-8 -*-
"""lightclaw env — manage runtime environment variables."""

from __future__ import annotations

import click

from ..envs import load_envs, set_env_var, delete_env_var


@click.group("env")
def env_group() -> None:
    """Manage environment variables.

    \b
    Examples:
      lightclaw env list
      lightclaw env set OPENAI_API_KEY sk-...
      lightclaw env delete OPENAI_API_KEY
    """


@env_group.command("list")
def list_cmd() -> None:
    """List all configured environment variables."""
    envs = load_envs()
    if not envs:
        click.echo("No environment variables configured.")
        return
    click.echo(f"\n  {'Key':<30s}  Value")
    click.echo(f"  {'─' * 56}")
    for key in sorted(envs):
        click.echo(f"  {key:<30s}  {envs[key]}")
    click.echo()


@env_group.command("set")
@click.argument("key")
@click.argument("value")
def set_cmd(key: str, value: str) -> None:
    """Set an environment variable.

    \b
    Examples:
      lightclaw env set OPENAI_API_KEY sk-abc123
      lightclaw env set CUSTOM_BASE_URL https://api.example.com/v1
    """
    set_env_var(key, value)
    click.echo(f"✓ {key} = {value}")


@env_group.command("delete")
@click.argument("key")
def delete_cmd(key: str) -> None:
    """Delete an environment variable.

    \b
    Examples:
      lightclaw env delete OPENAI_API_KEY
    """
    envs = load_envs()
    if key not in envs:
        raise click.ClickException(f"env var '{key}' not found.")
    delete_env_var(key)
    click.echo(f"✓ Deleted: {key}")


def configure_env_interactive() -> None:
    """Interactively add/edit environment variables (used by lightclaw config)."""
    from .utils import prompt_confirm

    while True:
        key = click.prompt("  Variable name", default="", show_default=False).strip()
        if not key:
            break
        current = load_envs().get(key, "")
        value = click.prompt(
            f"  Value for {key}",
            default=current or "",
            show_default=bool(current),
        )
        set_env_var(key, value)
        click.echo(f"  ✓ {key} = {value}")
        if not prompt_confirm("Add another variable?", default=False):
            break
    click.echo("Environment variable configuration complete.")
