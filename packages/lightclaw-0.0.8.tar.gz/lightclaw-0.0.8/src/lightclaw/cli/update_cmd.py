# -*- coding: utf-8 -*-
"""lightclaw update — check for a newer release on PyPI and upgrade if needed."""

from __future__ import annotations

import subprocess
import sys
from typing import Optional

import click


_PACKAGE_NAME = "lightclaw"
_PYPI_URL = f"https://pypi.org/pypi/{_PACKAGE_NAME}/json"


def _get_local_version() -> str:
    """Return the currently installed package version."""
    from ..__version__ import __version__

    return __version__


def _get_pypi_version(timeout: int = 10) -> Optional[str]:
    """Fetch the latest version string from PyPI. Returns None on failure."""
    import json
    import urllib.error
    import urllib.request

    try:
        req = urllib.request.Request(
            _PYPI_URL,
            headers={"User-Agent": f"{_PACKAGE_NAME}-updater/1.0"},
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return data["info"]["version"]
    except urllib.error.URLError as exc:
        click.echo(
            click.style(f"Network error while checking PyPI: {exc}", fg="yellow"),
            err=True,
        )
    except Exception as exc:  # noqa: BLE001
        click.echo(
            click.style(f"Failed to fetch version from PyPI: {exc}", fg="yellow"),
            err=True,
        )
    return None


def _parse_version(v: str) -> tuple[int, ...]:
    """Parse a version string into a comparable tuple, ignoring non-numeric parts."""
    parts = []
    for segment in v.split("."):
        # Strip pre-release suffixes (a, b, rc, post, dev …)
        numeric = ""
        for ch in segment:
            if ch.isdigit():
                numeric += ch
            else:
                break
        try:
            parts.append(int(numeric))
        except ValueError:
            parts.append(0)
    return tuple(parts)


def _is_newer(remote: str, local: str) -> bool:
    """Return True if *remote* is strictly newer than *local*."""
    return _parse_version(remote) > _parse_version(local)


def _detect_installer() -> str:
    """Detect whether the package was installed via uv or pip."""
    # If uv is on PATH and manages the current environment, prefer it.
    import shutil

    if shutil.which("uv"):
        return "uv"
    return "pip"


def _run_upgrade(installer: str, verbose: bool) -> bool:
    """Run the upgrade command and return True on success."""
    if installer == "uv":
        cmd = [
            "uv",
            "pip",
            "install",
            "--system",
            "--break-system-packages",
            "--upgrade",
            _PACKAGE_NAME,
        ]
    else:
        cmd = [
            sys.executable,
            "-m",
            "pip",
            "install",
            "--upgrade",
            _PACKAGE_NAME,
        ]

    click.echo(f"Running: {' '.join(cmd)}")
    result = subprocess.run(
        cmd,
        check=False,
        capture_output=not verbose,
        text=True,
    )
    if result.returncode != 0:
        if not verbose and result.stderr:
            click.echo(result.stderr, err=True)
        return False
    if verbose and result.stdout:
        click.echo(result.stdout)
    return True


@click.command("update")
@click.option(
    "--check",
    "check_only",
    is_flag=True,
    default=False,
    help="Only check for a newer version; do not install.",
)
@click.option(
    "--yes",
    "-y",
    is_flag=True,
    default=False,
    help="Skip confirmation prompt and upgrade immediately.",
)
@click.option(
    "--verbose",
    "-v",
    is_flag=True,
    default=False,
    help="Show full installer output.",
)
def update_cmd(check_only: bool, yes: bool, verbose: bool) -> None:
    """Check PyPI for a newer version and upgrade if available.

    \b
    Examples:
      lightclaw update              # interactive upgrade
      lightclaw update --check      # print version info, no install
      lightclaw update --yes        # non-interactive upgrade
    """
    local_ver = _get_local_version()
    click.echo(f"Current version : {click.style(local_ver, bold=True)}")
    click.echo("Checking PyPI for latest version …")

    remote_ver = _get_pypi_version()
    if remote_ver is None:
        click.echo(click.style("Could not determine the latest version.", fg="red"))
        raise SystemExit(1)

    click.echo(f"Latest version  : {click.style(remote_ver, bold=True)}")

    if not _is_newer(remote_ver, local_ver):
        click.echo(
            click.style(
                f"\n{_PACKAGE_NAME} {local_ver} is already up to date.",
                fg="green",
            )
        )
        return

    click.echo(
        click.style(
            f"\nNew version available: {local_ver} → {remote_ver}",
            fg="cyan",
        )
    )

    if check_only:
        click.echo(
            "Run `lightclaw update` (without --check) to install the new version."
        )
        return

    if not yes:
        ok = click.confirm(
            f"Upgrade {_PACKAGE_NAME} to {remote_ver}?",
            default=True,
        )
        if not ok:
            click.echo("Upgrade cancelled.")
            return

    installer = _detect_installer()
    click.echo(f"Using installer  : {installer}")

    success = _run_upgrade(installer, verbose)
    if success:
        click.echo(
            click.style(
                f"\n{_PACKAGE_NAME} successfully upgraded to {remote_ver}.",
                fg="green",
            )
        )
        click.echo("Please restart lightclaw for the changes to take effect.")
    else:
        click.echo(
            click.style(
                "\nUpgrade failed. Check the output above for details.", fg="red"
            )
        )
        raise SystemExit(1)
