# -*- coding: utf-8 -*-
from __future__ import annotations

import asyncio
import json
import secrets
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import click

from ..app.crons.models import (
    CronJobRequest,
    CronJobSpec,
    DispatchSpec,
    DispatchTarget,
    JobRuntimeSpec,
    ScheduleSpec,
)
from ..app.crons.repo.json_repo import JsonJobRepository
from ..app.channels.schema import DEFAULT_CHANNEL
from ..config.utils import get_jobs_path


def _new_job_id() -> str:
    ts = int(datetime.now(timezone.utc).timestamp())
    return f"job-{ts}-{secrets.token_hex(2)}"


def _get_repo() -> JsonJobRepository:
    return JsonJobRepository(get_jobs_path())


def _run(coro):  # type: ignore[no-untyped-def]
    return asyncio.run(coro)


@click.group("cron")
def cron_group() -> None:
    """Manage scheduled cron jobs (reads/writes ~/.lightclaw/jobs.json directly).

    Use list/get to inspect jobs; create/delete to add or remove;
    pause/resume to toggle enabled state; run to trigger a one-off run via
    the running server.
    """


@cron_group.command("list")
def list_jobs() -> None:
    """List all cron jobs."""
    repo = _get_repo()
    jobs = _run(repo.list_jobs())
    click.echo(
        json.dumps(
            [j.model_dump(mode="json") for j in jobs], ensure_ascii=False, indent=2
        )
    )


@cron_group.command("get")
@click.argument("job_id", metavar="JOB_ID")
def get_job(job_id: str) -> None:
    """Fetch a cron job by ID."""
    repo = _get_repo()
    job = _run(repo.get_job(job_id))
    if job is None:
        raise click.ClickException("Job not found.")
    click.echo(json.dumps(job.model_dump(mode="json"), ensure_ascii=False, indent=2))


def _build_spec(
    task_type: str,
    name: str,
    cron: str,
    channel: str,
    target_user: str,
    target_session: str,
    text: Optional[str],
    timezone: str,
    enabled: bool,
    mode: str,
    job_id: Optional[str] = None,
) -> CronJobSpec:
    """Build a CronJobSpec from CLI args."""
    schedule = ScheduleSpec(cron=cron, timezone=timezone)
    dispatch = DispatchSpec(
        channel=channel,
        target=DispatchTarget(user_id=target_user, session_id=target_session),
        mode=mode,  # type: ignore[arg-type]
    )
    runtime = JobRuntimeSpec()

    if task_type == "text":
        if not (text and text.strip()):
            raise click.UsageError("--text is required when task type is 'text'")
        return CronJobSpec(
            id=job_id or _new_job_id(),
            name=name,
            enabled=enabled,
            schedule=schedule,
            task_type="text",
            text=text.strip(),
            dispatch=dispatch,
            runtime=runtime,
        )

    if task_type == "agent":
        if not (text and text.strip()):
            raise click.UsageError(
                "--text is required when task type is 'agent' "
                "(the question/prompt sent to the agent)"
            )
        return CronJobSpec(
            id=job_id or _new_job_id(),
            name=name,
            enabled=enabled,
            schedule=schedule,
            task_type="agent",
            request=CronJobRequest(
                input=[
                    {
                        "role": "user",
                        "type": "message",
                        "content": [{"type": "text", "text": text.strip()}],
                    }
                ],
                session_id=target_session,
                user_id=target_user,
            ),
            dispatch=dispatch,
            runtime=runtime,
        )

    raise click.UsageError(f"Unsupported task type: {task_type}")


@cron_group.command("create")
@click.option(
    "-f",
    "--file",
    "file_",
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
    default=None,
    help=(
        "Path to a JSON file containing the full cron job spec. "
        "Mutually exclusive with inline options (--type, --name, etc.)."
    ),
)
@click.option(
    "--type",
    "task_type",
    type=click.Choice(["text", "agent"], case_sensitive=False),
    default="agent",
    show_default=True,
    help=(
        "Task type: 'text' sends fixed content to the channel; "
        "'agent' sends a question to the agent and delivers the reply to the "
        "channel."
    ),
)
@click.option(
    "--name",
    default=None,
    help="Display name for the job. Required when not using -f/--file.",
)
@click.option(
    "--cron",
    default=None,
    help=(
        "Cron expression (5 fields: minute hour day month weekday). "
        "Example: '0 9 * * *' for daily at 09:00. Required without -f/--file."
    ),
)
@click.option(
    "--channel",
    default=None,
    help=(
        "Delivery channel: e.g. dingtalk, discord, qq, dashboard. "
        "Required when not using -f/--file."
    ),
)
@click.option(
    "--target-user",
    default="default",
    show_default=True,
    help="Target user_id for the channel (recipient identifier).",
)
@click.option(
    "--target-session",
    default="default",
    show_default=True,
    help="Target session_id for the channel.",
)
@click.option(
    "--text",
    default=None,
    help=(
        "Content: for 'text' tasks this is the message sent to the channel; "
        "for 'agent' tasks this is the prompt/question sent to the agent. "
        "Required for both task types."
    ),
)
@click.option(
    "--timezone",
    default="UTC",
    help="Timezone for the cron schedule (e.g. UTC, America/New_York).",
)
@click.option(
    "--enabled/--no-enabled",
    default=True,
    help="Create the job as enabled (--enabled) or disabled (--no-enabled).",
)
@click.option(
    "--mode",
    type=click.Choice(["stream", "final"], case_sensitive=False),
    default="final",
    help=(
        "Delivery mode: 'stream' sends incremental updates; "
        "'final' sends only the final result."
    ),
)
def create_job(
    file_: Optional[Path],
    task_type: Optional[str],
    name: Optional[str],
    cron: Optional[str],
    channel: Optional[str],
    target_user: str,
    target_session: str,
    text: Optional[str],
    timezone: str,
    enabled: bool,
    mode: str,
) -> None:
    """Create a cron job and write it to jobs.json.

    Either pass -f/--file with a JSON spec, or use --type, --name, --cron,
    --channel, and --text to define the job inline.
    """
    if file_ is not None:
        raw = json.loads(file_.read_text(encoding="utf-8"))
        # Assign a fresh id so CLI creates a new job even if spec has one
        raw["id"] = _new_job_id()
        try:
            spec = CronJobSpec.model_validate(raw)
        except Exception as exc:
            raise click.ClickException(f"Invalid spec file: {exc}") from exc
    else:
        for value, label in [
            (name, "--name"),
            (cron, "--cron"),
            (channel, "--channel"),
        ]:
            if not value or (isinstance(value, str) and not value.strip()):
                raise click.UsageError(
                    f"When creating without -f/--file, {label} is required"
                )
        spec = _build_spec(
            task_type=task_type or "agent",
            name=name or "",
            cron=cron or "",
            channel=channel or DEFAULT_CHANNEL,
            target_user=target_user,
            target_session=target_session,
            text=text,
            timezone=timezone,
            enabled=enabled,
            mode=mode,
        )

    repo = _get_repo()
    _run(repo.upsert_job(spec))
    click.echo(json.dumps(spec.model_dump(mode="json"), ensure_ascii=False, indent=2))


@cron_group.command("delete")
@click.argument("job_id", metavar="JOB_ID")
def delete_job(job_id: str) -> None:
    """Permanently delete a cron job from jobs.json."""
    repo = _get_repo()
    deleted = _run(repo.delete_job(job_id))
    if not deleted:
        raise click.ClickException("Job not found.")
    click.echo(json.dumps({"deleted": True}, ensure_ascii=False))


@cron_group.command("pause")
@click.argument("job_id", metavar="JOB_ID")
def pause_job(job_id: str) -> None:
    """Disable a cron job (sets enabled=false in jobs.json).

    Note: if the server is running, the change takes effect on next restart.
    To pause immediately without restarting, use the web dashboard.
    """
    repo = _get_repo()
    job = _run(repo.get_job(job_id))
    if job is None:
        raise click.ClickException("Job not found.")
    updated = job.model_copy(update={"enabled": False})
    _run(repo.upsert_job(updated))
    click.echo(json.dumps({"paused": True, "enabled": False}, ensure_ascii=False))


@cron_group.command("resume")
@click.argument("job_id", metavar="JOB_ID")
def resume_job(job_id: str) -> None:
    """Enable a cron job (sets enabled=true in jobs.json).

    Note: if the server is running, the change takes effect on next restart.
    To resume immediately without restarting, use the web dashboard.
    """
    repo = _get_repo()
    job = _run(repo.get_job(job_id))
    if job is None:
        raise click.ClickException("Job not found.")
    updated = job.model_copy(update={"enabled": True})
    _run(repo.upsert_job(updated))
    click.echo(json.dumps({"resumed": True, "enabled": True}, ensure_ascii=False))


@cron_group.command("run")
@click.argument("job_id", metavar="JOB_ID")
@click.option(
    "--base-url",
    default=None,
    help="Override the API base URL. Defaults to global --host/--port.",
)
@click.pass_context
def run_job(ctx: click.Context, job_id: str, base_url: Optional[str]) -> None:
    """Trigger a one-off run of a cron job immediately (requires running server).

    Unlike other sub-commands, 'run' must contact the running LightClaw server
    because executing a job requires the agent runner and channel manager that
    live inside the server process.
    """
    from .http import authed_client, print_json

    if base_url:
        url = base_url.rstrip("/")
    else:
        host = (ctx.obj or {}).get("host", "127.0.0.1")
        port = (ctx.obj or {}).get("port", 8088)
        url = f"http://{host}:{port}"

    with authed_client(url) as c:
        r = c.post(f"/cron/jobs/{job_id}/run")
        if r.status_code == 404:
            raise click.ClickException("Job not found.")
        r.raise_for_status()
        print_json(r.json())
