# -*- coding: utf-8 -*-
"""lightclaw init — non-interactive setup with sensible defaults."""

from __future__ import annotations

import click

from .providers_cmd import configure_providers_interactive
from ..config import get_config_path, get_heartbeat_query_path, load_config, save_config
from ..config.config import Config, HeartbeatConfig
from ..constant import HEARTBEAT_DEFAULT_EVERY
from ..providers import load_providers_json

_HEARTBEAT_MDS = {
    "zh": """\
# Heartbeat checklist
- 扫描收件箱紧急邮件
- 查看未来 2h 的日历
- 检查待办是否卡住
- 若安静超过 8h，轻量 check-in
""",
    "en": """\
# Heartbeat checklist
- Scan inbox for urgent email
- Check calendar for next 2h
- Check tasks for blockers
- Light check-in if quiet for 8h
""",
}


@click.command("init")
@click.option(
    "--force", is_flag=True, help="Overwrite existing lightclaw.json and HEARTBEAT.md."
)
def init_cmd(force: bool) -> None:
    """Initialize LightClaw with default configuration (non-interactive).

    \b
    Examples:
      lightclaw init            # first-time setup
      lightclaw init --force    # reset existing config to defaults
    """
    config_path = get_config_path()
    heartbeat_path = get_heartbeat_query_path()
    working_dir = config_path.parent

    click.echo(f"Working dir: {working_dir}")
    working_dir.mkdir(parents=True, exist_ok=True)

    if not config_path.is_file() or force:
        cfg = load_config(config_path) if config_path.is_file() else Config()
        cfg.agents.defaults.heartbeat = HeartbeatConfig(
            every=HEARTBEAT_DEFAULT_EVERY,
            target="main",
            active_hours=None,
        )
        cfg.show_tool_details = True
        save_config(cfg, config_path)
        click.echo(f"\n✓ Config saved to {config_path}")
    else:
        click.echo("Config already exists, skipping.")

    data = load_providers_json()
    llm_pid, llm_model = data.parse_active_llm()
    if llm_pid and llm_model:
        click.echo(f"\n✓ LLM: {llm_pid} / {llm_model}")
    else:
        click.echo("\n=== LLM Provider (required) ===")
        configure_providers_interactive(use_defaults=True)

    from ..agent.skills_manager import sync_skills_to_working_dir

    click.echo("\nEnabling all skills...")
    synced, skipped = sync_skills_to_working_dir(skill_names=None, force=False)
    click.echo(f"✓ Skills: {synced} enabled, {skipped} skipped (already present)")

    from ..agent.utils import copy_md_files

    cfg = load_config(config_path) if config_path.is_file() else Config()
    lang = cfg.agents.language
    click.echo(f"\nChecking MD files [{lang}]...")
    copied = copy_md_files(lang, skip_existing=True)
    if copied:
        cfg.agents.installed_md_files_language = lang
        save_config(cfg, config_path)
        click.echo(f"✓ Copied: {', '.join(copied)}")
    else:
        click.echo("✓ MD files already present.")

    if not heartbeat_path.is_file() or force:
        heartbeat_path.write_text(_HEARTBEAT_MDS[lang].strip(), encoding="utf-8")
        click.echo(f"✓ HEARTBEAT.md saved to {heartbeat_path}")
    else:
        click.echo("✓ HEARTBEAT.md already present.")

    click.echo("\n✓ Done! Run `lightclaw run` to start.")
