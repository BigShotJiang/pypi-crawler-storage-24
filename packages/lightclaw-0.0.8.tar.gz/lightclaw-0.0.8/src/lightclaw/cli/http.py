# -*- coding: utf-8 -*-
from __future__ import annotations

import json
from contextlib import contextmanager
from typing import Any, Iterator

import click
import httpx


DEFAULT_BASE_URL = "http://127.0.0.1:8088"


def client(base_url: str) -> httpx.Client:
    """Create HTTP client with /api prefix added to all requests."""
    base = base_url.rstrip("/")
    if not base.endswith("/api"):
        base = f"{base}/api"
    return httpx.Client(base_url=base, timeout=30.0)


@contextmanager
def authed_client(base_url: str) -> Iterator[httpx.Client]:
    """HTTP client that automatically handles password authentication.

    If the server has password protection disabled, behaves like a plain
    client.  Otherwise it mints a JWT token locally from auth.json (no
    password prompt needed), and attaches the token as ``Authorization: Bearer``
    on every request.
    """
    base = base_url.rstrip("/")
    api_base = f"{base}/api" if not base.endswith("/api") else base

    with httpx.Client(base_url=api_base, timeout=30.0) as c:
        # 1. Check whether auth is enabled on the server
        try:
            status_resp = c.get("/auth/status")
            status_resp.raise_for_status()
            auth_enabled = status_resp.json().get("enabled", False)
        except httpx.HTTPError:
            # Can't reach the server — let the actual request surface the error
            yield c
            return

        if not auth_enabled:
            yield c
            return

        # 2. Auth is enabled — mint a token locally from auth.json (no password needed)
        token = _local_token()
        if token is None:
            raise click.ClickException(
                "Failed to generate authentication token. "
                "Please ensure the server is running and ~/.lightclaw/auth.json is accessible."
            )
        c.headers["Authorization"] = f"Bearer {token}"
        yield c


def _local_token() -> str | None:
    """Mint a JWT token locally by reading the secret from auth.json.

    This works because the CLI runs on the same machine as the server and
    has direct access to ~/.lightclaw/auth.json.  No password is required.

    Fallback strategy:
    1. Try to read jwt_secret from ~/.lightclaw/auth.json
    2. If file missing, create it using default credentials (simulating first-run)

    Returns None if unable to create or read auth.json.
    """
    from ..app.auth import (
        AUTH_FILE,
        create_token,
        AuthData,
        _write_auth,
        _hash_password,
    )  # noqa: PLC0415
    import json as _json  # noqa: PLC0415
    import secrets  # noqa: PLC0415

    # Try to read existing auth.json
    if AUTH_FILE.is_file():
        try:
            data = _json.loads(AUTH_FILE.read_text(encoding="utf-8"))
        except Exception:
            return None
        secret = data.get("jwt_secret", "")
        if secret:
            return create_token(secret)

    # Fallback: Create auth.json with default credentials if it doesn't exist
    # This simulates the first-run behavior of the server
    try:
        default_password = "lightclaw"  # Match server's default
        auth_data = AuthData(
            enabled=True,
            password_hash=_hash_password(default_password),
            jwt_secret=secrets.token_hex(32),
        )
        _write_auth(auth_data)
        return create_token(auth_data.jwt_secret)
    except Exception:
        return None


def print_json(data: Any) -> None:
    click.echo(json.dumps(data, ensure_ascii=False, indent=2))
