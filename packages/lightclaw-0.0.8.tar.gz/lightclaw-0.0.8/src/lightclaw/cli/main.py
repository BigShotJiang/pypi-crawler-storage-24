# -*- coding: utf-8 -*-
from __future__ import annotations

import sys

import click

# Windows: force UTF-8 for stdout/stderr to handle non-ASCII output.
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except (AttributeError, OSError):
        pass

# ---------------------------------------------------------------------------
# Lazy command registry
# Each entry: command_name -> (module_path, attribute_name)
# The module is only imported when the command is actually invoked.
# ---------------------------------------------------------------------------
_COMMANDS: dict[str, tuple[str, str]] = {
    "run": (".run_cmd", "app_cmd"),
    "channels": (".channels_cmd", "channels_group"),
    "chats": (".chats_cmd", "chats_group"),
    "clean": (".clean_cmd", "clean_cmd"),
    "cron": (".cron_cmd", "cron_group"),
    "env": (".env_cmd", "env_group"),
    "config": (".config_cmd", "config_cmd"),
    "init": (".init_cmd", "init_cmd"),
    "models": (".providers_cmd", "models_group"),
    "passwd": (".passwd_cmd", "passwd_cmd"),
    "skills": (".skills_cmd", "skills_group"),
    "uninstall": (".uninstall_cmd", "uninstall_cmd"),
    "update": (".update_cmd", "update_cmd"),
    "start": (".service_cmd", "start_cmd"),
    "stop": (".service_cmd", "stop_cmd"),
    "restart": (".service_cmd", "restart_cmd"),
    "workspace": (".workspace_cmd", "workspace_group"),
}


class _LazyCLI(click.Group):
    """Click group that imports command modules only when invoked."""

    def list_commands(self, ctx: click.Context) -> list[str]:
        return sorted(_COMMANDS)

    def get_command(self, ctx: click.Context, name: str) -> click.BaseCommand | None:
        if name not in _COMMANDS:
            return None
        module_path, attr = _COMMANDS[name]
        import importlib

        mod = importlib.import_module(module_path, package=__package__)
        return getattr(mod, attr)


# Only this tiny import runs at startup — everything else is deferred.
from ..config.utils import read_last_api  # noqa: E402


def log_init_timings() -> None:
    """Re-emit per-module import timings at debug level (run_cmd triggers this)."""
    import logging

    logger = logging.getLogger(__name__)
    logger.debug("lazy imports: deferred until command invocation")


@click.group(cls=_LazyCLI, context_settings={"help_option_names": ["-h", "--help"]})
@click.option("--host", default=None, help="API host")
@click.option("--port", default=None, type=int, help="API port")
@click.pass_context
def cli(ctx: click.Context, host: str | None, port: int | None) -> None:
    """LightClaw CLI."""
    last = read_last_api()
    if last:
        host = host or last[0]
        port = port or last[1]
    host = host or "127.0.0.1"
    port = port or 8088
    ctx.ensure_object(dict)
    ctx.obj["host"] = host
    ctx.obj["port"] = port
