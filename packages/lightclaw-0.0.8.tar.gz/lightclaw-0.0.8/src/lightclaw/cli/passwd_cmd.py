# -*- coding: utf-8 -*-
"""lightclaw passwd — change the login password via the running API server."""

from __future__ import annotations

import click
import httpx

from .http import client


@click.command("passwd")
@click.option("--host", default=None, help="API host (overrides global --host)")
@click.option(
    "--port", default=None, type=int, help="API port (overrides global --port)"
)
@click.pass_context
def passwd_cmd(ctx: click.Context, host: str | None, port: int | None) -> None:
    """Change the LightClaw login password.

    Connects to the running LightClaw server and updates the login password.
    You will be prompted for the current password and the new password.

    The server must be running before you can use this command.
    Start it with: lightclaw run
    """
    obj = ctx.ensure_object(dict)
    host = host or obj.get("host") or "127.0.0.1"
    port = port or obj.get("port") or 8088
    base_url = f"http://{host}:{port}"

    # 1. Check auth status
    try:
        with client(base_url) as c:
            resp = c.get("/auth/status")
            resp.raise_for_status()
            status = resp.json()
    except httpx.ConnectError:
        raise click.ClickException(
            f"Cannot connect to LightClaw at {base_url}.\n"
            "Make sure the server is running: lightclaw run"
        )
    except httpx.HTTPStatusError as exc:
        raise click.ClickException(
            f"Server error: {exc.response.status_code} {exc.response.text}"
        )

    if not status.get("enabled"):
        raise click.ClickException(
            "Password protection is not enabled on this server.\n"
            "Enable it first via the web dashboard."
        )

    # 2. Prompt for passwords
    old_password = click.prompt("Current password", hide_input=True)
    new_password = click.prompt(
        "New password", hide_input=True, confirmation_prompt=True
    )

    if len(new_password) < 4:
        raise click.ClickException("New password must be at least 4 characters.")

    # 3. Call change-password endpoint
    # We need a token first — login with the old password
    try:
        with client(base_url) as c:
            login_resp = c.post("/auth/login", json={"password": old_password})
            if login_resp.status_code == 401:
                raise click.ClickException("Current password is incorrect.")
            login_resp.raise_for_status()
            token = login_resp.json().get("token", "")

            change_resp = c.post(
                "/auth/change-password",
                json={"old_password": old_password, "new_password": new_password},
                headers={"Authorization": f"Bearer {token}"},
            )
            if change_resp.status_code == 401:
                raise click.ClickException("Current password is incorrect.")
            change_resp.raise_for_status()

    except click.ClickException:
        raise
    except httpx.HTTPStatusError as exc:
        body = exc.response.text
        raise click.ClickException(
            f"Failed to change password: {exc.response.status_code} {body}"
        )

    click.echo("Password changed successfully.")
    click.echo(
        "All existing login sessions have been invalidated — please log in again."
    )
