# -*- coding: utf-8 -*-
"""lightclaw uninstall — remove the LightClaw environment and CLI wrapper."""

from __future__ import annotations

import shutil
import re
import subprocess
import sys
from pathlib import Path

import click

from ..constant import WORKING_DIR


# Directories created by the installer (relative to WORKING_DIR).
_INSTALLER_DIRS = ("venv", "bin")

# Shell profiles to clean up.
_SHELL_PROFILES = (
    Path.home() / ".zshrc",
    Path.home() / ".bashrc",
    Path.home() / ".bash_profile",
)


_PLATFORM = sys.platform


def _remove_service() -> bool:
    """Stop and remove the LightClaw system service. Returns True if anything was done."""
    if _PLATFORM == "linux":
        return _remove_systemd_service()
    elif _PLATFORM == "darwin":
        return _remove_launchd_service()
    return False


def _remove_systemd_service() -> bool:
    import os

    is_root = os.geteuid() == 0
    unit_dir = (
        Path("/etc/systemd/system")
        if is_root
        else Path.home() / ".config" / "systemd" / "user"
    )
    unit_file = unit_dir / "com.lightclaw.service"
    if not unit_file.exists():
        return False

    def _systemctl(*args: str) -> list[str]:
        return ["systemctl", *args] if is_root else ["systemctl", "--user", *args]

    subprocess.run(
        _systemctl("stop", "com.lightclaw"), check=False, capture_output=True
    )
    subprocess.run(
        _systemctl("disable", "com.lightclaw"), check=False, capture_output=True
    )
    unit_file.unlink()
    subprocess.run(_systemctl("daemon-reload"), check=False, capture_output=True)
    click.echo(f"  Removed systemd unit: {unit_file}")
    return True


def _remove_launchd_service() -> bool:
    plist = Path.home() / "Library" / "LaunchAgents" / "com.lightclaw.service.plist"
    if not plist.exists():
        return False

    subprocess.run(
        ["launchctl", "unload", str(plist)], check=False, capture_output=True
    )
    plist.unlink()
    click.echo(f"  Removed launchd plist: {plist}")
    return True


def _remove_path_entry(profile: Path) -> bool:
    """
    Remove LightClaw PATH lines from a shell profile. Returns True if changed.
    """
    if not profile.is_file():
        return False

    text = profile.read_text()
    # Remove the "# LightClaw" comment line and the export PATH line
    cleaned = re.sub(
        r"\n?# LightClaw\nexport PATH=\"\$HOME/\.lightclaw/bin:\$PATH\"\n?",
        "\n",
        text,
    )
    if cleaned == text:
        return False

    profile.write_text(cleaned)
    return True


@click.command("uninstall")
@click.option(
    "--purge",
    is_flag=True,
    help="Also remove all data (config, chats, models, etc.)",
)
@click.option("--yes", is_flag=True, help="Do not prompt for confirmation")
def uninstall_cmd(purge: bool, yes: bool) -> None:
    """Remove LightClaw environment, CLI wrapper, and shell PATH entries."""
    wd = WORKING_DIR

    if purge:
        click.echo(f"This will remove ALL LightClaw data in {wd}")
    else:
        click.echo(
            "This will remove the LightClaw Python environment and CLI wrapper.",
        )
        click.echo(f"Your configuration and data in {wd} will be preserved.")

    if not yes:
        ok = click.confirm("Continue?", default=False)
        if not ok:
            click.echo("Cancelled.")
            return

    # Stop and remove system service
    _remove_service()

    # Remove installer-managed directories
    for dirname in _INSTALLER_DIRS:
        d = wd / dirname
        if d.exists():
            shutil.rmtree(d)
            click.echo(f"  Removed {d}")

    # Purge everything if requested
    if purge and wd.exists():
        shutil.rmtree(wd)
        click.echo(f"  Removed {wd}")

    # Clean shell profiles
    for profile in _SHELL_PROFILES:
        if _remove_path_entry(profile):
            click.echo(f"  Cleaned {profile}")

    click.echo("")
    click.echo("LightClaw uninstalled. Please restart your terminal.")
