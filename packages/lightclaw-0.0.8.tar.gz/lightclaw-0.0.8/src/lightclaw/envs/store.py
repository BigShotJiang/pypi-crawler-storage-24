# -*- coding: utf-8 -*-
"""Reading and writing environment variables.

Persistence strategy (two layers):

1. **BASE_DIR/.env** – canonical store in dotenv format, survives process
   restarts.  Falls back to reading the legacy ``envs.json`` once and migrates
   the data automatically.
2. **os.environ** – injected into the current Python process so that
   ``os.getenv()`` and child subprocesses (``subprocess.run``, etc.)
   can read them immediately.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Optional


def _get_base_dir() -> Path:
    """Return BASE_DIR (lazy import to avoid circular dependencies)."""
    from ..constant import BASE_DIR  # noqa: PLC0415

    return BASE_DIR


def get_env_file_path() -> Path:
    """Return the path to the .env file inside BASE_DIR (not workspace)."""
    return _get_base_dir() / ".env"


# Legacy path – used only for one-time migration
def _get_legacy_envs_json_path() -> Path:
    return Path(__file__).resolve().parent / "envs.json"


# ------------------------------------------------------------------
# dotenv format helpers
# ------------------------------------------------------------------


def _parse_dotenv(text: str) -> dict[str, str]:
    """Parse a dotenv-formatted string into a dict.

    Supports:
    - ``KEY=value``
    - ``KEY="quoted value"`` / ``KEY='quoted value'``
    - Blank lines and ``# comments`` are ignored.
    - Multi-line values are **not** supported (not needed here).
    """
    result: dict[str, str] = {}
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        key, _, raw_value = line.partition("=")
        key = key.strip()
        if not key:
            continue
        value = raw_value.strip()
        # Strip surrounding quotes (single or double)
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
            value = value[1:-1]
        result[key] = value
    return result


def _serialize_dotenv(envs: dict[str, str]) -> str:
    """Serialise *envs* to dotenv format.

    Values that contain spaces, ``=``, ``#``, or newlines are
    double-quoted.  Single ``"`` inside values is escaped as ``\\"``.
    """
    lines: list[str] = []
    for key in sorted(envs):
        value = envs[key]
        needs_quotes = any(
            c in value for c in (" ", "\t", "=", "#", '"', "'", "\n", "\r")
        )
        if needs_quotes:
            escaped = value.replace("\\", "\\\\").replace('"', '\\"')
            lines.append(f'{key}="{escaped}"')
        else:
            lines.append(f"{key}={value}")
    return "\n".join(lines) + ("\n" if lines else "")


# ------------------------------------------------------------------
# os.environ helpers
# ------------------------------------------------------------------


def _apply_to_environ(envs: dict[str, str]) -> None:
    """Set every key/value into ``os.environ``."""
    for key, value in envs.items():
        os.environ[key] = value


def _remove_from_environ(key: str) -> None:
    """Remove *key* from ``os.environ`` if present."""
    os.environ.pop(key, None)


def _sync_environ(
    old: dict[str, str],
    new: dict[str, str],
) -> None:
    """Synchronise ``os.environ``: set *new*, remove stale *old*."""
    for key in old:
        if key not in new:
            _remove_from_environ(key)
    _apply_to_environ(new)


# ------------------------------------------------------------------
# Migration from legacy envs.json
# ------------------------------------------------------------------


def _migrate_from_legacy_json(dot_env_path: Path) -> dict[str, str]:
    """If the legacy envs.json exists and .env does not, migrate once.

    Returns the migrated dict (empty dict if no migration was needed).
    """
    legacy = _get_legacy_envs_json_path()
    if not legacy.is_file():
        return {}
    try:
        with open(legacy, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        if not isinstance(data, dict):
            return {}
        envs = {k: str(v) for k, v in data.items()}
    except (json.JSONDecodeError, ValueError, OSError):
        return {}

    # Write to new location
    dot_env_path.parent.mkdir(parents=True, exist_ok=True)
    dot_env_path.write_text(_serialize_dotenv(envs), encoding="utf-8")

    # Rename legacy file so migration only happens once
    legacy.rename(legacy.with_suffix(".json.bak"))

    return envs


# ------------------------------------------------------------------
# .env persistence
# ------------------------------------------------------------------


def load_envs(
    path: Optional[Path] = None,
) -> dict[str, str]:
    """Load env vars from BASE_DIR/.env (dotenv format)."""
    if path is None:
        path = get_env_file_path()
    if not path.is_file():
        # Try one-time migration from legacy envs.json
        return _migrate_from_legacy_json(path)
    try:
        text = path.read_text(encoding="utf-8")
        return _parse_dotenv(text)
    except OSError:
        return {}


def save_envs(
    envs: dict[str, str],
    path: Optional[Path] = None,
) -> None:
    """Write env vars to BASE_DIR/.env and sync to ``os.environ``."""
    old = load_envs(path)

    if path is None:
        path = get_env_file_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_serialize_dotenv(envs), encoding="utf-8")

    _sync_environ(old, envs)


def set_env_var(
    key: str,
    value: str,
) -> dict[str, str]:
    """Set a single env var. Returns updated dict."""
    envs = load_envs()
    envs[key] = value
    save_envs(envs)
    return envs


def delete_env_var(key: str) -> dict[str, str]:
    """Delete a single env var. Returns updated dict."""
    envs = load_envs()
    envs.pop(key, None)
    save_envs(envs)
    return envs


def load_envs_into_environ() -> dict[str, str]:
    """Load BASE_DIR/.env and apply all entries to ``os.environ``.

    Call this once at application startup so that environment
    variables persisted from a previous session are available
    immediately.
    """
    envs = load_envs()
    _apply_to_environ(envs)
    return envs
