# -*- coding: utf-8 -*-
"""Single-user password authentication with JWT tokens.

Password hash and settings are stored in ``auth.json`` in the LightClaw
working directory (``~/.lightclaw`` by default).
"""

from __future__ import annotations

import base64 as _b64
import hashlib
import hmac
import json
import secrets
import time
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel

from ..constant import BASE_DIR

# ---------------------------------------------------------------------------
# auth.json persistence
# ---------------------------------------------------------------------------

AUTH_FILE = BASE_DIR / "auth.json"

# JWT defaults
JWT_ALGORITHM = "HS256"
JWT_EXPIRE_SECONDS = 24 * 60 * 60  # 24 hours


class AuthData(BaseModel):
    """Schema for ``auth.json``."""

    enabled: bool = False
    password_hash: str = ""
    jwt_secret: str = ""
    setup_done: bool = False


# Default password for first-time setup
_DEFAULT_PASSWORD = "lightclaw"


def _read_auth() -> AuthData:
    if AUTH_FILE.is_file():
        with open(AUTH_FILE, "r", encoding="utf-8") as f:
            return AuthData.model_validate(json.load(f))
    # First run: create auth.json with password protection enabled
    data = AuthData(
        enabled=True,
        password_hash=_hash_password(_DEFAULT_PASSWORD),
        jwt_secret=secrets.token_hex(32),
    )
    _write_auth(data)
    return data


def _write_auth(data: AuthData) -> None:
    AUTH_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(AUTH_FILE, "w", encoding="utf-8") as f:
        json.dump(data.model_dump(), f, indent=2, ensure_ascii=False)


def _hash_password(password: str) -> str:
    """SHA-256 hash of password (simple & sufficient for single-user local)."""
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def _ensure_jwt_secret(auth: AuthData) -> str:
    """Return or generate a JWT secret."""
    if not auth.jwt_secret:
        auth.jwt_secret = secrets.token_hex(32)
        _write_auth(auth)
    return auth.jwt_secret


# ---------------------------------------------------------------------------
# Minimal JWT implementation (no external dependency)
# ---------------------------------------------------------------------------


def _b64url_encode(data: bytes) -> str:
    return _b64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64url_decode(s: str) -> bytes:
    s += "=" * (-len(s) % 4)
    return _b64.urlsafe_b64decode(s)


def _jwt_encode(payload: dict, secret: str) -> str:
    header = _b64url_encode(json.dumps({"alg": "HS256", "typ": "JWT"}).encode())
    body = _b64url_encode(json.dumps(payload).encode())
    msg = f"{header}.{body}"
    sig = hmac.new(secret.encode(), msg.encode(), hashlib.sha256).digest()
    return f"{msg}.{_b64url_encode(sig)}"


def _jwt_decode(token: str, secret: str) -> dict:
    parts = token.split(".")
    if len(parts) != 3:
        raise ValueError("Invalid token")
    msg = f"{parts[0]}.{parts[1]}"
    expected_sig = hmac.new(secret.encode(), msg.encode(), hashlib.sha256).digest()
    actual_sig = _b64url_decode(parts[2])
    if not hmac.compare_digest(expected_sig, actual_sig):
        raise ValueError("Invalid signature")
    payload = json.loads(_b64url_decode(parts[1]))
    if payload.get("exp", 0) < time.time():
        raise ValueError("Token expired")
    return payload


def create_token(secret: str) -> str:
    payload = {
        "sub": "admin",
        "iat": int(time.time()),
        "exp": int(time.time()) + JWT_EXPIRE_SECONDS,
    }
    return _jwt_encode(payload, secret)


# ---------------------------------------------------------------------------
# FastAPI dependency — auth guard
# ---------------------------------------------------------------------------

_bearer_scheme = HTTPBearer(auto_error=False)


async def require_auth(
    request: Request,
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(_bearer_scheme),
) -> None:
    """Dependency that enforces authentication when password protection is on.

    If password protection is **off** (``auth.enabled == False``), this is a
    no-op — every request passes through.
    """
    auth = _read_auth()
    if not auth.enabled:
        return  # password protection not enabled

    if credentials is None or not credentials.credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated",
            headers={"WWW-Authenticate": "Bearer"},
        )

    secret = _ensure_jwt_secret(auth)
    try:
        _jwt_decode(credentials.credentials, secret)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=str(exc),
            headers={"WWW-Authenticate": "Bearer"},
        ) from exc


# ---------------------------------------------------------------------------
# Auth API router
# ---------------------------------------------------------------------------

router = APIRouter(prefix="/auth", tags=["auth"])


class LoginRequest(BaseModel):
    password: str


class LoginResponse(BaseModel):
    token: str


class SetPasswordRequest(BaseModel):
    password: str


class ChangePasswordRequest(BaseModel):
    old_password: str
    new_password: str


class AuthStatusResponse(BaseModel):
    enabled: bool
    setup_done: bool


class SetupDoneRequest(BaseModel):
    done: bool = True


@router.get("/status", response_model=AuthStatusResponse)
async def auth_status():
    """Return whether password protection is enabled (public endpoint)."""
    auth = _read_auth()
    return AuthStatusResponse(enabled=auth.enabled, setup_done=auth.setup_done)


@router.post("/setup-done")
async def mark_setup_done(body: SetupDoneRequest):
    """Mark initial setup as completed (public endpoint — called from setup wizard)."""
    auth = _read_auth()
    auth.setup_done = body.done
    _write_auth(auth)
    return {"ok": True}


@router.post("/login", response_model=LoginResponse)
async def login(body: LoginRequest):
    """Verify password and return a JWT token."""
    auth = _read_auth()
    if not auth.enabled:
        raise HTTPException(
            status_code=400, detail="Password protection is not enabled"
        )
    if _hash_password(body.password) != auth.password_hash:
        raise HTTPException(status_code=401, detail="Wrong password")
    secret = _ensure_jwt_secret(auth)
    token = create_token(secret)
    return LoginResponse(token=token)


@router.post("/set-password")
async def set_password(
    body: SetPasswordRequest,
    _: None = Depends(require_auth),
):
    """Set password and enable password protection (first time setup)."""
    if not body.password or len(body.password) < 4:
        raise HTTPException(
            status_code=400, detail="Password must be at least 4 characters"
        )
    auth = _read_auth()
    auth.password_hash = _hash_password(body.password)
    auth.enabled = True
    auth.jwt_secret = secrets.token_hex(32)
    _write_auth(auth)
    token = create_token(auth.jwt_secret)
    return {"ok": True, "token": token}


@router.post("/change-password")
async def change_password(
    body: ChangePasswordRequest,
    _: None = Depends(require_auth),
):
    """Change password (requires old password verification)."""
    auth = _read_auth()
    if not auth.enabled:
        raise HTTPException(
            status_code=400, detail="Password protection is not enabled"
        )
    if _hash_password(body.old_password) != auth.password_hash:
        raise HTTPException(status_code=401, detail="Old password is wrong")
    if not body.new_password or len(body.new_password) < 4:
        raise HTTPException(
            status_code=400, detail="New password must be at least 4 characters"
        )
    auth.password_hash = _hash_password(body.new_password)
    # Rotate JWT secret so old tokens are invalidated
    auth.jwt_secret = secrets.token_hex(32)
    _write_auth(auth)
    token = create_token(auth.jwt_secret)
    return {"ok": True, "token": token}


@router.post("/disable")
async def disable_auth(
    body: LoginRequest,
    _: None = Depends(require_auth),
):
    """Disable password protection (requires password verification)."""
    auth = _read_auth()
    if not auth.enabled:
        raise HTTPException(
            status_code=400, detail="Password protection is not enabled"
        )
    if _hash_password(body.password) != auth.password_hash:
        raise HTTPException(status_code=401, detail="Wrong password")
    auth.enabled = False
    auth.password_hash = ""
    auth.jwt_secret = ""
    _write_auth(auth)
    return {"ok": True}
