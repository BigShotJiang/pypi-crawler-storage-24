# -*- coding: utf-8 -*-
"""Dashboard channel package."""

from .channel import DashboardChannel

__all__ = ["DashboardChannel"]
