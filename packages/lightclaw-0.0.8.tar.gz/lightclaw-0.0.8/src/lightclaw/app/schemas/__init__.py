# -*- coding: utf-8 -*-
"""LightClaw internal message/event schemas.

Pure data classes with no dependency on agentscope or langchain.
Provides drop-in replacements for agentscope_runtime.engine.schemas.agent_schemas
types used throughout the Channel and Runner layers.
"""

from .content_types import (
    ContentType,
    TextContent,
    ImageContent,
    VideoContent,
    AudioContent,
    FileContent,
    RefusalContent,
    DataContent,
    FunctionCall,
    FunctionCallOutput,
)
from .message_types import (
    MessageType,
    RunStatus,
    Role,
    Message,
    AgentRequest,
)
from .events import (
    ResponseEvent,
    ResponseEventMetadata,
    MessageEvent,
    MessageEventMetadata,
    ContentEvent,
    SequenceCounter,
)

__all__ = [
    # Content
    "ContentType",
    "TextContent",
    "ImageContent",
    "VideoContent",
    "AudioContent",
    "FileContent",
    "RefusalContent",
    "DataContent",
    "FunctionCall",
    "FunctionCallOutput",
    # Message
    "MessageType",
    "RunStatus",
    "Role",
    "Message",
    "AgentRequest",
    # Events (SSE)
    "ResponseEvent",
    "ResponseEventMetadata",
    "MessageEvent",
    "MessageEventMetadata",
    "ContentEvent",
    "SequenceCounter",
]
