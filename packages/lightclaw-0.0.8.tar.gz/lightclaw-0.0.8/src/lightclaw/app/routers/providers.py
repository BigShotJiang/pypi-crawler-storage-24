# -*- coding: utf-8 -*-
"""API routes for LLM providers and models."""

from __future__ import annotations

import logging
from typing import List, Optional

from fastapi import APIRouter, Body, HTTPException, Path
from pydantic import BaseModel, Field

from ...providers import (
    ActiveModelsInfo,
    ModelInfo,
    ModelSlotConfig,
    ProviderDefinition,
    ProviderEntry,
    ProviderInfo,
    ProvidersData,
    ResolvedModelPublic,
    add_model,
    create_custom_provider,
    delete_custom_provider,
    get_model_template,
    get_provider,
    list_providers,
    list_resolved_llm_configs,
    load_providers_json,
    mask_api_key,
    refresh_provider_models,
    remove_model,
    set_active_llm,
    toggle_model_enabled,
    update_provider_settings,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/models", tags=["models"])

# Read-only endpoints — no authentication required
public_router = APIRouter(prefix="/models", tags=["models"])


class ProviderConfigRequest(BaseModel):
    api_key: Optional[str] = Field(default=None)
    base_url: Optional[str] = Field(default=None)


class ModelSlotRequest(BaseModel):
    provider_id: str = Field(..., description="Provider to use")
    model: str = Field(..., description="Model identifier")


class CreateCustomProviderRequest(BaseModel):
    id: str = Field(...)
    name: str = Field(...)
    default_base_url: str = Field(default="")
    api_key_prefix: str = Field(default="")
    api_key: str = Field(default="")
    models: List[ModelInfo] = Field(default_factory=list)


class AddModelRequest(BaseModel):
    id: str = Field(...)
    name: str = Field(...)
    # Advanced / optional openclaw-compatible metadata
    context_window: Optional[int] = Field(default=None)
    max_tokens: Optional[int] = Field(default=None)
    reasoning: Optional[bool] = Field(default=None)
    input: Optional[List[str]] = Field(default=None)
    cost: Optional[dict] = Field(default=None)


class ToggleModelRequest(BaseModel):
    enabled: bool = Field(..., description="Whether the model should be enabled")


def _build_provider_info(
    provider: ProviderDefinition,
    data: ProvidersData,
) -> ProviderInfo:
    cur_base_url, cur_api_key = data.get_credentials(provider.id)
    configured = data.is_configured(provider)

    entry: Optional[ProviderEntry] = data.providers.get(provider.id)

    if provider.is_custom:
        # Custom providers: all models are in entry.models
        return ProviderInfo(
            id=provider.id,
            name=provider.name,
            api_key_prefix=provider.api_key_prefix,
            models=list(provider.models),
            extra_models=[],
            is_custom=provider.is_custom,
            has_api_key=configured,
            current_api_key=mask_api_key(cur_api_key),
            current_base_url=cur_base_url,
        )

    # Built-in providers: merge built-in models with extra_models overrides
    extra_list = list(entry.extra_models) if entry else []
    extra_by_id = {m.id: m for m in extra_list}

    # Apply enabled overrides from extra_models to built-in models
    merged_models: list[ModelInfo] = []
    for m in provider.models:
        override = extra_by_id.get(m.id)
        if override is not None:
            # Use the override (which may have enabled=False)
            merged_models.append(override)
        else:
            merged_models.append(m)

    # Truly user-added models (not overrides of built-in models)
    builtin_ids = {m.id for m in provider.models}
    user_added = [m for m in extra_list if m.id not in builtin_ids]
    merged_models.extend(user_added)

    return ProviderInfo(
        id=provider.id,
        name=provider.name,
        api_key_prefix=provider.api_key_prefix,
        models=merged_models,
        extra_models=user_added,
        is_custom=provider.is_custom,
        has_api_key=configured,
        current_api_key=mask_api_key(cur_api_key),
        current_base_url=cur_base_url,
    )


@public_router.get(
    "",
    response_model=List[ProviderInfo],
    summary="List all providers",
)
async def list_all_providers() -> List[ProviderInfo]:
    data = load_providers_json()
    return [_build_provider_info(p, data) for p in list_providers()]


@router.post(
    "/refresh",
    response_model=List[ProviderInfo],
    summary="Refresh local/Ollama model lists and return all providers",
)
async def refresh_all_providers() -> List[ProviderInfo]:
    """Explicitly sync local and Ollama model lists.

    Unlike ``GET /models`` which reads from cache, this endpoint performs
    a full refresh — scanning the local model manifest and querying the
    Ollama daemon.  The frontend should call this only when the user
    explicitly requests a refresh (e.g. clicks a "refresh" button).
    """
    data = refresh_provider_models()
    return [_build_provider_info(p, data) for p in list_providers()]


@public_router.get(
    "/{provider_id}/models/{model_id:path}/template",
    summary="Get bundled metadata template for a model",
)
async def get_model_template_endpoint(
    provider_id: str = Path(...),
    model_id: str = Path(...),
) -> dict:
    """Return the bundled metadata template for a known model, or 404 if not found.

    Useful for pre-filling the Advanced Options form when adding a model
    that matches a well-known built-in model.
    """
    tmpl = get_model_template(provider_id, model_id)
    if tmpl is None:
        raise HTTPException(
            status_code=404,
            detail=f"No template found for '{provider_id}/{model_id}'",
        )
    return tmpl


@router.put(
    "/{provider_id}/config",
    response_model=ProviderInfo,
    summary="Configure a provider",
)
async def configure_provider(
    provider_id: str = Path(...),
    body: ProviderConfigRequest = Body(...),
) -> ProviderInfo:
    provider = get_provider(provider_id)
    if provider is None:
        raise HTTPException(404, detail=f"Provider '{provider_id}' not found")

    base_url = body.base_url if provider.is_custom else None
    data = update_provider_settings(
        provider_id,
        api_key=body.api_key,
        base_url=base_url,
    )
    return _build_provider_info(provider, data)


@router.post(
    "/custom-providers",
    response_model=ProviderInfo,
    summary="Create a custom provider",
    status_code=201,
)
async def create_custom_provider_endpoint(
    body: CreateCustomProviderRequest = Body(...),
) -> ProviderInfo:
    try:
        data = create_custom_provider(
            provider_id=body.id,
            name=body.name,
            default_base_url=body.default_base_url,
            api_key_prefix=body.api_key_prefix,
            api_key=body.api_key,
            models=body.models,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    provider = get_provider(body.id)
    assert provider is not None
    return _build_provider_info(provider, data)


@router.delete(
    "/custom-providers/{provider_id}",
    response_model=List[ProviderInfo],
    summary="Delete a custom provider",
)
async def delete_custom_provider_endpoint(
    provider_id: str = Path(...),
) -> List[ProviderInfo]:
    try:
        data = delete_custom_provider(provider_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return [_build_provider_info(p, data) for p in list_providers()]


@router.post(
    "/{provider_id}/models",
    response_model=ProviderInfo,
    summary="Add a model to a provider",
    status_code=201,
)
async def add_model_endpoint(
    provider_id: str = Path(...),
    body: AddModelRequest = Body(...),
) -> ProviderInfo:
    from ...providers.models import ModelCost

    cost = None
    if body.cost:
        try:
            cost = ModelCost.model_validate(body.cost)
        except Exception:
            cost = None

    model = ModelInfo(
        id=body.id,
        name=body.name,
        context_window=body.context_window,
        max_tokens=body.max_tokens,
        reasoning=body.reasoning,
        input=body.input,
        cost=cost,
    )
    try:
        data = add_model(provider_id, model)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    provider = get_provider(provider_id)
    assert provider is not None
    return _build_provider_info(provider, data)


@router.delete(
    "/{provider_id}/models/{model_id:path}",
    response_model=ProviderInfo,
    summary="Remove a model from a provider",
)
async def remove_model_endpoint(
    provider_id: str = Path(...),
    model_id: str = Path(...),
) -> ProviderInfo:
    try:
        data = remove_model(provider_id, model_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    provider = get_provider(provider_id)
    assert provider is not None
    return _build_provider_info(provider, data)


@router.put(
    "/{provider_id}/models/{model_id:path}/enabled",
    response_model=ProviderInfo,
    summary="Toggle a model's enabled state",
)
async def toggle_model_enabled_endpoint(
    provider_id: str = Path(...),
    model_id: str = Path(...),
    body: ToggleModelRequest = Body(...),
) -> ProviderInfo:
    try:
        data = toggle_model_enabled(provider_id, model_id, body.enabled)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    provider = get_provider(provider_id)
    assert provider is not None
    return _build_provider_info(provider, data)


@public_router.get(
    "/resolved",
    response_model=List[ResolvedModelPublic],
    summary="List all resolved model candidates for auto-routing",
)
async def list_resolved_models() -> List[ResolvedModelPublic]:
    """Return every model that is available for automatic routing.

    This includes all models from configured (authorised) providers.
    Secrets (``api_key``, ``base_url``) are stripped from the response.
    """
    resolved = list_resolved_llm_configs()
    return [ResolvedModelPublic.from_resolved(r) for r in resolved]


@public_router.get(
    "/active",
    response_model=ActiveModelsInfo,
    summary="Get active LLM",
)
async def get_active_models() -> ActiveModelsInfo:
    data = load_providers_json()
    pid, model = data.parse_active_llm()
    return ActiveModelsInfo(active_llm=ModelSlotConfig(provider_id=pid, model=model))


@router.put(
    "/active",
    response_model=ActiveModelsInfo,
    summary="Set active LLM",
)
async def set_active_model(
    body: ModelSlotRequest = Body(...),
) -> ActiveModelsInfo:
    provider = get_provider(body.provider_id)
    if provider is None:
        raise HTTPException(
            404,
            detail=f"Provider '{body.provider_id}' not found",
        )

    data = load_providers_json()
    if not data.is_configured(provider):
        if provider.is_custom:
            msg = (
                f"Provider '{provider.name}' has no base_url configured. "
                "Please configure the base URL first."
            )
        else:
            msg = (
                f"Provider '{provider.name}' has no API key configured. "
                "Please configure the API key first."
            )
        raise HTTPException(status_code=400, detail=msg)

    if not body.model:
        raise HTTPException(status_code=400, detail="Model is required.")

    data = set_active_llm(body.provider_id, body.model)
    pid, model = data.parse_active_llm()
    return ActiveModelsInfo(active_llm=ModelSlotConfig(provider_id=pid, model=model))
