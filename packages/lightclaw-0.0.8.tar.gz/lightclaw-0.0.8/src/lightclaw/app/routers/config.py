# -*- coding: utf-8 -*-

import logging
from typing import List

from fastapi import APIRouter, Body, HTTPException, Path, Request
from ...config import (
    load_config,
    save_config,
    ChannelConfig,
    ChannelConfigUnion,
)
from ...config.config import CHANNEL_REGISTRY_KEY_TO_CONFIG_ATTR
from ...constant import get_available_channels

# Reverse map: config attr name -> registry key (e.g. "qqbot" -> "qq")
_CONFIG_ATTR_TO_REGISTRY_KEY = {
    v: k for k, v in CHANNEL_REGISTRY_KEY_TO_CONFIG_ATTR.items()
}

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/config", tags=["config"])


@router.get(
    "/channels",
    summary="List all channels",
    description="Retrieve configuration for all available channels",
)
async def list_channels() -> dict:
    """List all channel configs (filtered by available channels)."""
    config = load_config()
    available = get_available_channels()
    # model_dump() uses config attr names (e.g. "qqbot"); expose as registry
    # key (e.g. "qq") so the dashboard sees consistent channel identifiers.
    result = {}
    for attr_key, value in config.channels.model_dump().items():
        registry_key = _CONFIG_ATTR_TO_REGISTRY_KEY.get(attr_key, attr_key)
        if registry_key in available:
            result[registry_key] = value
    return result


@router.get(
    "/channels/types",
    summary="List channel types",
    description="Return all available channel type identifiers",
)
async def list_channel_types() -> List[str]:
    """Return available channel type identifiers (env-filtered).

    Excludes 'console' channel which is for internal use only.
    """
    available = get_available_channels()
    # Filter out 'console' channel from UI; it's for CLI/server use only
    return [ch for ch in available if ch != "console"]


@router.get(
    "/channels/status",
    summary="Get channel connection status",
    description="Retrieve connection status for all enabled channels",
)
async def get_channels_status(request: Request) -> dict:
    """获取所有频道的连接状态。"""
    channel_manager = getattr(request.app.state, "channel_manager", None)
    if channel_manager is None:
        raise HTTPException(
            status_code=503,
            detail="Channel manager not initialized",
        )
    return await channel_manager.get_all_status()


@router.put(
    "/channels",
    response_model=ChannelConfig,
    summary="Update all channels",
    description="Update configuration for all channels at once",
)
async def put_channels(
    channels_config: ChannelConfig = Body(
        ...,
        description="Complete channel configuration",
    ),
) -> ChannelConfig:
    """Update all channel configs."""
    config = load_config()
    config.channels = channels_config
    save_config(config)
    return channels_config


@router.get(
    "/channels/{channel_name}",
    response_model=ChannelConfigUnion,
    summary="Get channel config",
    description="Retrieve configuration for a specific channel by name",
)
async def get_channel(
    channel_name: str = Path(
        ...,
        description="Name of the channel to retrieve",
        min_length=1,
    ),
) -> ChannelConfigUnion:
    """Get a specific channel config by name."""
    available = get_available_channels()
    if channel_name not in available:
        raise HTTPException(
            status_code=404,
            detail=f"Channel '{channel_name}' not found",
        )
    config = load_config()
    config_attr = CHANNEL_REGISTRY_KEY_TO_CONFIG_ATTR.get(channel_name, channel_name)
    single_channel_config = getattr(config.channels, config_attr, None)
    if single_channel_config is None:
        extra = getattr(config.channels, "__pydantic_extra__", None) or {}
        single_channel_config = extra.get(channel_name)
    if single_channel_config is None:
        raise HTTPException(
            status_code=404,
            detail=f"Channel '{channel_name}' not found",
        )
    return single_channel_config


@router.put(
    "/channels/{channel_name}",
    response_model=ChannelConfigUnion,
    summary="Update channel config",
    description="Update configuration for a specific channel by name",
)
async def put_channel(
    channel_name: str = Path(
        ...,
        description="Name of the channel to update",
        min_length=1,
    ),
    single_channel_config: ChannelConfigUnion = Body(
        ...,
        description="Updated channel configuration",
    ),
) -> ChannelConfigUnion:
    """Update a specific channel config by name."""
    available = get_available_channels()
    if channel_name not in available:
        raise HTTPException(
            status_code=404,
            detail=f"Channel '{channel_name}' not found",
        )
    config = load_config()

    # Allow setting extra (plugin) channel config; map registry key to attr name
    config_attr = CHANNEL_REGISTRY_KEY_TO_CONFIG_ATTR.get(channel_name, channel_name)
    setattr(config.channels, config_attr, single_channel_config)
    save_config(config)
    return single_channel_config


@router.get(
    "/show_tool_details",
    summary="Get show_tool_details setting",
    description="Retrieve the current show_tool_details configuration value",
)
async def get_show_tool_details() -> dict:
    """Get the current show_tool_details setting."""
    config = load_config()
    return {"show_tool_details": config.show_tool_details}


@router.put(
    "/show_tool_details",
    summary="Update show_tool_details setting",
    description="Update the show_tool_details configuration value",
)
async def put_show_tool_details(
    body: dict = Body(
        ...,
        description="Body containing show_tool_details boolean value",
    ),
) -> dict:
    """Update the show_tool_details setting."""
    if "show_tool_details" not in body:
        raise HTTPException(
            status_code=400,
            detail="Missing 'show_tool_details' field in request body",
        )
    value = body["show_tool_details"]
    if not isinstance(value, bool):
        raise HTTPException(
            status_code=400,
            detail="'show_tool_details' must be a boolean value",
        )
    config = load_config()
    config.show_tool_details = value
    save_config(config)
    return {"show_tool_details": value}


@router.post(
    "/channels/{channel_name}/check",
    summary="Check channel credentials and connectivity",
    description="Verify channel credentials by calling the platform API. "
    "If credentials are provided in the request body, use those; "
    "otherwise use the running channel instance.",
)
async def check_channel(
    request: Request,
    channel_name: str = Path(
        ...,
        description="Name of the channel to check",
        min_length=1,
    ),
    credentials: dict = Body(
        default=None,
        description="Optional credentials to verify (e.g. app_id, client_secret). "
        "If provided, these values are used directly instead of the saved config.",
    ),
) -> dict:
    """校验频道凭据并检测连接联通性。

    当 credentials 传入时，使用传入的凭据直接调用平台 API 校验（不依赖已保存配置）。
    当 credentials 未传入时，使用已运行的频道实例进行校验。
    """
    available = get_available_channels()
    if channel_name not in available:
        raise HTTPException(
            status_code=404,
            detail=f"Channel '{channel_name}' not found",
        )

    # 如果传入了凭据，直接使用静态方法校验（不依赖频道实例是否运行）
    if credentials:
        try:
            from ..channels.registry import get_channel_registry

            registry = get_channel_registry()
            channel_cls = registry.get(channel_name)
            if channel_cls and hasattr(channel_cls, "verify_credentials_with_params"):
                result = await channel_cls.verify_credentials_with_params(credentials)
                return result
            else:
                return {
                    "valid": False,
                    "status": "disconnected",
                    "reason": "该频道不支持凭据校验",
                }
        except Exception as e:
            logger.exception(
                "Failed to check channel '%s' with credentials", channel_name
            )
            return {
                "valid": False,
                "status": "disconnected",
                "reason": f"检测异常: {str(e)}",
            }

    # 未传入凭据时，使用已运行的频道实例
    channel_manager = getattr(request.app.state, "channel_manager", None)
    if channel_manager is None:
        raise HTTPException(
            status_code=503,
            detail="Channel manager not initialized",
        )

    ch = await channel_manager.get_channel(channel_name)
    if ch is None:
        raise HTTPException(
            status_code=404,
            detail=f"Channel '{channel_name}' is not running",
        )

    try:
        result = await ch.verify_credentials()
        return result
    except Exception as e:
        logger.exception("Failed to check channel '%s'", channel_name)
        return {
            "valid": False,
            "status": "disconnected",
            "reason": f"检测异常: {str(e)}",
        }


@router.post(
    "/channels/{channel_name}/reconnect",
    summary="Reconnect a channel",
    description="Stop and restart a channel to re-establish connection",
)
async def reconnect_channel(
    request: Request,
    channel_name: str = Path(
        ...,
        description="Name of the channel to reconnect",
        min_length=1,
    ),
) -> dict:
    """重连指定频道：停止后基于当前配置重新创建并启动。"""
    available = get_available_channels()
    if channel_name not in available:
        raise HTTPException(
            status_code=404,
            detail=f"Channel '{channel_name}' not found",
        )

    channel_manager = getattr(request.app.state, "channel_manager", None)
    if channel_manager is None:
        raise HTTPException(
            status_code=503,
            detail="Channel manager not initialized",
        )

    ch = await channel_manager.get_channel(channel_name)
    if ch is None:
        raise HTTPException(
            status_code=404,
            detail=f"Channel '{channel_name}' is not running",
        )

    try:
        # 读取当前配置，获取对应频道的配置段
        config = load_config()
        config_attr = CHANNEL_REGISTRY_KEY_TO_CONFIG_ATTR.get(
            channel_name,
            channel_name,
        )
        ch_cfg = getattr(config.channels, config_attr, None)
        if ch_cfg is None:
            extra = getattr(config.channels, "__pydantic_extra__", None) or {}
            ch_cfg = extra.get(channel_name)
        if ch_cfg is None:
            raise HTTPException(
                status_code=404,
                detail=f"Channel '{channel_name}' config not found",
            )
        show_tool_details = bool(
            getattr(config, "show_tool_details", True),
        )
        new_ch = ch.clone(ch_cfg, show_tool_details=show_tool_details)
        await channel_manager.replace_channel(new_ch)
        logger.info("Channel '%s' reconnected successfully", channel_name)
        return {"status": "ok", "channel": channel_name}
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Failed to reconnect channel '%s'", channel_name)
        raise HTTPException(
            status_code=500,
            detail=f"Failed to reconnect: {str(e)}",
        ) from e
