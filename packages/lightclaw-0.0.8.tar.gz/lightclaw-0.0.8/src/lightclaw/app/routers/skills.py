# -*- coding: utf-8 -*-
import asyncio
import logging
import shutil
from typing import Any
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field
from ...agent.skills_manager import (
    SkillService,
    SkillInfo,
    ensure_skills_initialized,
    list_available_skills,
)
from ...agent.skills_hub import (
    search_hub_skills,
    install_skill_from_hub,
)
from ...constant import SKILLS_DIR

logger = logging.getLogger(__name__)


class SkillListItem(BaseModel):
    slug: str
    tool_name: str
    description: str = ""
    kind: str
    enabled: bool = False
    has_references: bool = False
    has_scripts: bool = False


class SkillDetail(BaseModel):
    slug: str
    tool_name: str
    description: str = ""
    kind: str
    content: str
    path: str
    references: dict[str, Any] = Field(default_factory=dict)
    scripts: dict[str, Any] = Field(default_factory=dict)
    has_references: bool = False
    has_scripts: bool = False
    enabled: bool = False


class CreateSkillRequest(BaseModel):
    name: str = Field(..., description="Skill name")
    content: str = Field(..., description="Skill content (SKILL.md)")
    references: dict[str, Any] | None = Field(
        None,
        description="Optional tree structure for references/. "
        "Can be flat {filename: content} or nested "
        "{dirname: {filename: content}}",
    )
    scripts: dict[str, Any] | None = Field(
        None,
        description="Optional tree structure for scripts/. "
        "Can be flat {filename: content} or nested "
        "{dirname: {filename: content}}",
    )


class HubSkillSpec(BaseModel):
    slug: str
    name: str
    description: str = ""
    version: str = ""
    source_url: str = ""


class HubInstallRequest(BaseModel):
    bundle_url: str = Field(..., description="Skill URL")
    version: str = Field(default="", description="Optional version tag")
    enable: bool = Field(default=True, description="Enable after import")
    overwrite: bool = Field(
        default=False,
        description="Overwrite existing customized skill",
    )


class SkillHubInstallRequest(BaseModel):
    skill_name: str = Field(..., description="SkillHub skill slug name")
    enable: bool = Field(default=True, description="Enable after install")


router = APIRouter(prefix="/skills", tags=["skills"])


def _to_skill_list_item(skill: SkillInfo, *, enabled: bool) -> SkillListItem:
    return SkillListItem(
        slug=skill.slug,
        tool_name=skill.tool_name,
        description=skill.description,
        kind=skill.kind,
        enabled=enabled,
        has_references=skill.has_references,
        has_scripts=skill.has_scripts,
    )


def _to_skill_detail(skill: SkillInfo, *, enabled: bool) -> SkillDetail:
    return SkillDetail(
        slug=skill.slug,
        tool_name=skill.tool_name,
        description=skill.description,
        kind=skill.kind,
        content=skill.content,
        path=skill.path,
        references=skill.references,
        scripts=skill.scripts,
        has_references=skill.has_references,
        has_scripts=skill.has_scripts,
        enabled=enabled,
    )


def _ensure_skills_initialized_for_request(request: Request) -> None:
    if getattr(request.app.state, "skills_initialized", False):
        return

    ensure_skills_initialized()
    request.app.state.skills_initialized = True


@router.get("")
async def list_skills(request: Request) -> list[SkillListItem]:
    _ensure_skills_initialized_for_request(request)
    all_skills = SkillService.list_all_skills()

    available_skills = set(list_available_skills())
    return [
        _to_skill_list_item(skill, enabled=skill.slug in available_skills)
        for skill in all_skills
    ]


@router.get("/available")
async def get_available_skills(request: Request) -> list[SkillListItem]:
    _ensure_skills_initialized_for_request(request)
    available_skills = SkillService.list_available_skills()
    return [_to_skill_list_item(skill, enabled=True) for skill in available_skills]


@router.get("/{skill_name}")
async def get_skill_detail(
    skill_name: str,
    request: Request,
) -> SkillDetail:
    _ensure_skills_initialized_for_request(request)
    skill = SkillService.get_skill(skill_name)
    if skill is None:
        raise HTTPException(status_code=404, detail="Skill not found")

    available_skills = set(list_available_skills())
    return _to_skill_detail(skill, enabled=skill.slug in available_skills)


@router.get("/hub/search")
async def search_hub(
    q: str = "",
    limit: int = 20,
) -> list[HubSkillSpec]:
    results = search_hub_skills(q, limit=limit)
    return [
        HubSkillSpec(
            slug=item.slug,
            name=item.name,
            description=item.description,
            version=item.version,
            source_url=item.source_url,
        )
        for item in results
    ]


@router.post("/hub/install")
async def install_from_hub(request: HubInstallRequest):
    try:
        result = install_skill_from_hub(
            bundle_url=request.bundle_url,
            version=request.version,
            enable=request.enable,
            overwrite=request.overwrite,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
    except RuntimeError as e:
        # Upstream hub is flaky/rate-limited sometimes; surface as bad gateway.
        raise HTTPException(status_code=502, detail=str(e)) from e
    except Exception as e:
        raise HTTPException(
            status_code=502,
            detail=f"Skill hub import failed: {e}",
        ) from e
    return {
        "installed": True,
        "name": result.name,
        "enabled": result.enabled,
        "source_url": result.source_url,
    }


@router.post("/batch-disable")
async def batch_disable_skills(skill_name: list[str]) -> None:
    for skill in skill_name:
        SkillService.disable_skill(skill)


@router.post("/batch-enable")
async def batch_enable_skills(skill_name: list[str]) -> None:
    for skill in skill_name:
        SkillService.enable_skill(skill)


@router.post("")
async def create_skill(request: CreateSkillRequest):
    result = SkillService.create_skill(
        name=request.name,
        content=request.content,
        references=request.references,
        scripts=request.scripts,
    )
    return {"created": result}


@router.post("/{skill_name}/disable")
async def disable_skill(skill_name: str):
    result = SkillService.disable_skill(skill_name)
    return {"disabled": result}


@router.post("/{skill_name}/enable")
async def enable_skill(skill_name: str):
    result = SkillService.enable_skill(skill_name)
    return {"enabled": result}


@router.delete("/{skill_name}")
async def delete_skill(skill_name: str):
    """Delete a skill from the unified workspace skills directory."""
    result = SkillService.delete_skill(skill_name)
    return {"deleted": result}


@router.get("/{skill_name}/files/{source}/{file_path:path}")
async def load_skill_file(
    skill_name: str,
    source: str,
    file_path: str,
):
    """Load a specific file from a skill's references or scripts directory.

    Args:
        skill_name: Name of the skill
        source: Source directory ("builtin" or "workspace").
            ``customized`` is accepted as a legacy alias for ``workspace``.
        file_path: Path relative to skill directory, must start with
                   "references/" or "scripts/"

    Returns:
        File content as string, or None if not found

    Example:
        GET /skills/my_skill/files/workspace/references/doc.md
        GET /skills/builtin_skill/files/builtin/scripts/utils/helper.py
    """
    content = SkillService.load_skill_file(
        skill_name=skill_name,
        file_path=file_path,
        source=source,
    )
    return {"content": content}


@router.post("/skillhub/install")
async def install_from_skillhub(request: SkillHubInstallRequest):
    """Install a skill from Tencent SkillHub using the skillhub CLI.

    The skillhub CLI is expected to be pre-installed. Skills are installed
    into the unified workspace skills directory.
    """
    skill_name = request.skill_name.strip()
    if not skill_name:
        raise HTTPException(status_code=400, detail="skill_name is required")

    # Check if skillhub CLI is available
    skillhub_bin = shutil.which("skillhub")
    if not skillhub_bin:
        raise HTTPException(
            status_code=400,
            detail=(
                "skillhub CLI not found. Please install it first:\n"
                "curl -fsSL https://skillhub-1251783334.cos.ap-guangzhou"
                ".myqcloud.com/install/install.sh | sh"
            ),
        )

    install_dir = str(SKILLS_DIR)
    cmd = [skillhub_bin, "--dir", install_dir, "install", skill_name]

    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await asyncio.wait_for(
            proc.communicate(),
            timeout=120,
        )
    except asyncio.TimeoutError:
        raise HTTPException(
            status_code=504,
            detail=f"skillhub install timed out for '{skill_name}'",
        )
    except Exception as e:
        raise HTTPException(
            status_code=502,
            detail=f"Failed to run skillhub CLI: {e}",
        )

    if proc.returncode != 0:
        err_msg = stderr.decode("utf-8", errors="replace").strip()
        logger.error(
            "skillhub install failed (rc=%d): %s",
            proc.returncode,
            err_msg,
        )
        raise HTTPException(
            status_code=502,
            detail=f"skillhub install failed: {err_msg or 'unknown error'}",
        )

    # Enable the skill if requested
    enabled = False
    if request.enable:
        try:
            enabled = SkillService.enable_skill(skill_name, force=True)
        except Exception:
            logger.warning(
                "Skill '%s' installed but enable failed",
                skill_name,
            )

    return {
        "installed": True,
        "name": skill_name,
        "enabled": enabled,
    }
