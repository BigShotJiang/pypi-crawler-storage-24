# -*- coding: utf-8 -*-
"""Image upload API — upload images and serve uploaded files."""

from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from ...constant import UPLOADS_DIR
from ..auth import require_auth

router = APIRouter(tags=["upload"])

# Maximum upload size: 10 MB
MAX_UPLOAD_SIZE = 10 * 1024 * 1024

# Allowed MIME types and their extensions
ALLOWED_MIME_TYPES: dict[str, str] = {
    "image/png": ".png",
    "image/jpeg": ".jpg",
    "image/gif": ".gif",
    "image/webp": ".webp",
}

# Magic byte signatures for image validation
MAGIC_BYTES: dict[str, list[bytes]] = {
    "image/png": [b"\x89PNG\r\n\x1a\n"],
    "image/jpeg": [b"\xff\xd8\xff"],
    "image/gif": [b"GIF87a", b"GIF89a"],
    "image/webp": [b"RIFF"],  # RIFF header; "WEBP" at offset 8
}


class UploadResponse(BaseModel):
    """Upload response."""

    url: str = Field(..., description="Accessible URL for the uploaded file")
    filename: str = Field(..., description="Original filename")
    media_type: str = Field(..., description="MIME type of the file")


def _validate_magic_bytes(data: bytes, mime_type: str) -> bool:
    """Validate file header bytes match the declared MIME type."""
    signatures = MAGIC_BYTES.get(mime_type, [])
    if not signatures:
        return False
    for sig in signatures:
        if data[: len(sig)] == sig:
            # Extra check for webp: bytes 8-12 must be "WEBP"
            if mime_type == "image/webp":
                return len(data) >= 12 and data[8:12] == b"WEBP"
            return True
    return False


@router.post(
    "/upload",
    dependencies=[Depends(require_auth)],
    response_model=UploadResponse,
    summary="Upload an image",
    description="Upload an image file (PNG, JPEG, GIF, WEBP). Max 10 MB.",
)
async def upload_image(
    file: UploadFile = File(..., description="Image file to upload"),
) -> UploadResponse:
    """Upload an image and return a URL to access it."""
    # --- MIME type check ---
    content_type = (file.content_type or "").lower()
    if content_type not in ALLOWED_MIME_TYPES:
        raise HTTPException(
            status_code=415,
            detail=(
                f"Unsupported file type: {content_type}. "
                f"Allowed: {', '.join(ALLOWED_MIME_TYPES.keys())}"
            ),
        )

    # --- Read file data (with size check) ---
    data = await file.read()
    if len(data) > MAX_UPLOAD_SIZE:
        raise HTTPException(
            status_code=413,
            detail=(
                f"File too large: {len(data)} bytes. "
                f"Maximum allowed: {MAX_UPLOAD_SIZE} bytes (10 MB)."
            ),
        )
    if len(data) == 0:
        raise HTTPException(status_code=400, detail="Empty file.")

    # --- Magic bytes validation ---
    if not _validate_magic_bytes(data, content_type):
        raise HTTPException(
            status_code=400,
            detail=(
                "File content does not match declared MIME type. "
                "The file may be corrupted or incorrectly named."
            ),
        )

    # --- Save file ---
    ext = ALLOWED_MIME_TYPES[content_type]
    unique_name = f"{uuid.uuid4().hex}{ext}"

    UPLOADS_DIR.mkdir(parents=True, exist_ok=True)
    dest = UPLOADS_DIR / unique_name
    dest.write_bytes(data)

    original_filename = file.filename or unique_name

    return UploadResponse(
        url=f"/api/files/{unique_name}",
        filename=original_filename,
        media_type=content_type,
    )


@router.get(
    "/files/{filename:path}",
    summary="Serve an uploaded file",
    description="Retrieve a previously uploaded file by its name.",
)
async def serve_file(filename: str) -> FileResponse:
    """Serve an uploaded file from the uploads directory."""
    # --- Path traversal protection ---
    # Reject any path component that attempts directory traversal
    if ".." in filename or filename.startswith("/"):
        raise HTTPException(status_code=400, detail="Invalid filename.")

    # Resolve and ensure it's within UPLOADS_DIR
    target = (UPLOADS_DIR / filename).resolve()
    if not str(target).startswith(str(UPLOADS_DIR.resolve())):
        raise HTTPException(status_code=400, detail="Invalid filename.")

    if not target.is_file():
        raise HTTPException(status_code=404, detail="File not found.")

    # Determine media type from extension
    suffix = target.suffix.lower()
    ext_to_mime = {v: k for k, v in ALLOWED_MIME_TYPES.items()}
    media_type = ext_to_mime.get(suffix, "application/octet-stream")

    return FileResponse(target, media_type=media_type)
