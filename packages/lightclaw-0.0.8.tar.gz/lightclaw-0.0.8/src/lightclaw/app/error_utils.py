# -*- coding: utf-8 -*-
"""Error classification and user-facing formatting helpers."""

from __future__ import annotations

from dataclasses import dataclass
import traceback
from typing import Any, Iterable

_RATE_LIMIT_KEYWORDS = (
    "too many requests",
    "rate limit",
    "rate-limited",
    "rate limited",
    "requests per min",
    "requests per minute",
    "tokens per min",
    "tokens per minute",
    "quota exceeded",
    "resource exhausted",
)

_MODEL_TRACE_HINTS = (
    "langchain_openai",
    "langchain_anthropic",
    "langchain_google",
    "langchain_google_genai",
    "langchain_community/chat_models",
    "langchain_core/language_models",
    "langchain_core/tracers/event_stream.py",
    "/openai/",
    "/anthropic/",
    "/google/",
    "/groq/",
)

_TOOL_TRACE_HINTS = (
    "/tools/",
    "/mcp/",
    "tool_registry.py",
    "skills_hub.py",
)


@dataclass(frozen=True)
class ErrorInfo:
    """Structured error information for logs, SSE, and user-facing prompts."""

    message: str
    code: str
    source: str
    status_code: int | None = None
    retryable: bool = False
    raw_message: str = ""

    def to_event_error(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "message": self.message,
            "code": self.code,
            "source": self.source,
            "retryable": self.retryable,
        }
        if self.status_code is not None:
            payload["status_code"] = self.status_code
        return payload


def _iter_exception_chain(exc: BaseException | None) -> Iterable[BaseException]:
    seen: set[int] = set()
    current = exc
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        yield current
        current = current.__cause__ or current.__context__


def _extract_status_code(exc: BaseException | None) -> int | None:
    for current in _iter_exception_chain(exc):
        for attr in ("status_code", "status", "code"):
            value = getattr(current, attr, None)
            if isinstance(value, int):
                return value
            if isinstance(value, str) and value.isdigit():
                return int(value)

        response = getattr(current, "response", None)
        if response is not None:
            for attr in ("status_code", "status"):
                value = getattr(response, attr, None)
                if isinstance(value, int):
                    return value
                if isinstance(value, str) and value.isdigit():
                    return int(value)

    return None


def _extract_raw_message(exc: BaseException | None) -> str:
    if exc is None:
        return ""

    for current in _iter_exception_chain(exc):
        text = str(current).strip()
        if text:
            return text

    return exc.__class__.__name__


def _traceback_filenames(exc: BaseException | None) -> list[str]:
    filenames: list[str] = []
    for current in _iter_exception_chain(exc):
        tb = current.__traceback__
        if tb is None:
            continue
        for frame in traceback.extract_tb(tb):
            filenames.append((frame.filename or "").lower())
    return filenames


def _looks_like_rate_limit(status_code: int | None, raw_message: str) -> bool:
    if status_code == 429:
        return True
    lowered = raw_message.lower()
    return any(keyword in lowered for keyword in _RATE_LIMIT_KEYWORDS)


def _infer_error_source(exc: BaseException | None, *, is_rate_limit: bool) -> str:
    filenames = _traceback_filenames(exc)
    if any(hint in filename for filename in filenames for hint in _TOOL_TRACE_HINTS):
        return "tool"
    if any(hint in filename for filename in filenames for hint in _MODEL_TRACE_HINTS):
        return "model_provider"
    if is_rate_limit:
        return "upstream_service"
    return "unknown"


def classify_exception(exc: BaseException | None) -> ErrorInfo:
    """Convert an exception into structured, user-facing error information."""
    raw_message = _extract_raw_message(exc)
    lowered = raw_message.lower()
    status_code = _extract_status_code(exc)

    if "does not support tools" in lowered:
        return ErrorInfo(
            message=(
                "当前选中的模型不支持工具调用（function calling）。"
                "请在「模型设置」中切换到支持工具的模型，或关闭工具功能后重试。"
            ),
            code="model_tool_support",
            source="model_provider",
            retryable=False,
            raw_message=raw_message,
        )

    is_rate_limit = _looks_like_rate_limit(status_code, raw_message)
    source = _infer_error_source(exc, is_rate_limit=is_rate_limit)

    if is_rate_limit:
        if source == "model_provider":
            message = (
                "模型服务当前触发 429 限频，请稍后重试。"
                "如果频繁出现，请降低并发、稍后再试，或切换到额度更高的模型或供应商。"
            )
        elif source == "tool":
            message = "外部工具或上游服务当前触发 429 限频，请稍后重试。"
        else:
            message = "上游服务当前触发 429 限频，请稍后重试。"

        return ErrorInfo(
            message=message,
            code="rate_limit",
            source=source,
            status_code=status_code or 429,
            retryable=True,
            raw_message=raw_message,
        )

    return ErrorInfo(
        message=raw_message or "处理请求时发生错误，请稍后重试。",
        code="runtime_error",
        source=source,
        status_code=status_code,
        retryable=False,
        raw_message=raw_message,
    )


def extract_event_error_message(error: Any) -> str:
    """Return a readable error message from a response/message error payload."""
    if error is None:
        return ""
    if isinstance(error, str):
        return error
    if isinstance(error, dict):
        message = error.get("message")
        if isinstance(message, str) and message.strip():
            return message.strip()
        return str(error)

    message = getattr(error, "message", None)
    if isinstance(message, str) and message.strip():
        return message.strip()

    return str(error)
