# -*- coding: utf-8 -*-
"""Process SSE protocol versioning helpers.

The runner emits a single internal event shape. This module controls how those
events are serialized on the ``/api/agent/process`` wire so legacy clients and
newer usage-aware clients can coexist.
"""

from __future__ import annotations

import json
from typing import Any, Mapping

from pydantic import BaseModel

PROCESS_PROTOCOL_V1 = "v1"
PROCESS_PROTOCOL_V2 = "v2"
# Default to v2 so that all channels (including console/other HTTP clients
# that don't explicitly set a protocol) receive per-message and per-run
# token usage metadata by default.
DEFAULT_PROCESS_PROTOCOL_VERSION = PROCESS_PROTOCOL_V2

_PROTOCOL_ALIASES = {
    "1": PROCESS_PROTOCOL_V1,
    "v1": PROCESS_PROTOCOL_V1,
    "legacy": PROCESS_PROTOCOL_V1,
    "2": PROCESS_PROTOCOL_V2,
    "v2": PROCESS_PROTOCOL_V2,
    "usage": PROCESS_PROTOCOL_V2,
}


def normalize_process_protocol_version(value: Any) -> str | None:
    """Normalize protocol aliases to ``v1`` / ``v2``."""
    if value is None:
        return None

    raw = str(value).strip().lower()
    if not raw:
        return None

    return _PROTOCOL_ALIASES.get(raw)


def resolve_process_protocol_version(
    *,
    body: Mapping[str, Any] | None = None,
    headers: Mapping[str, Any] | None = None,
    query_params: Mapping[str, Any] | None = None,
    default: str = DEFAULT_PROCESS_PROTOCOL_VERSION,
) -> str:
    """Resolve the effective process protocol version for one request."""
    candidates = [
        (body or {}).get("protocol_version"),
        (body or {}).get("process_protocol"),
        (headers or {}).get("x-process-protocol-version"),
        (headers or {}).get("x-process-protocol"),
        (query_params or {}).get("protocol_version"),
        (query_params or {}).get("process_protocol"),
    ]

    for candidate in candidates:
        normalized = normalize_process_protocol_version(candidate)
        if normalized is not None:
            return normalized

    return default


def _to_json_payload(event: BaseModel) -> dict[str, Any]:
    payload = event.model_dump(mode="json")
    if not isinstance(payload, dict):
        raise TypeError("Process event payload must serialize to a dict")
    return payload


def _downgrade_message_event_to_v1(payload: dict[str, Any]) -> dict[str, Any]:
    metadata = payload.get("metadata")
    if not isinstance(metadata, dict):
        return payload

    stripped = {k: v for k, v in metadata.items() if k != "usage"}
    payload["metadata"] = stripped or None
    return payload


def _downgrade_response_event_to_v1(payload: dict[str, Any]) -> dict[str, Any]:
    # Legacy response events had no metadata field at all.
    payload.pop("metadata", None)
    return payload


def process_event_to_payload(
    event: BaseModel,
    *,
    protocol_version: str = DEFAULT_PROCESS_PROTOCOL_VERSION,
) -> dict[str, Any]:
    """Convert one internal event to the requested wire payload."""
    version = (
        normalize_process_protocol_version(protocol_version)
        or DEFAULT_PROCESS_PROTOCOL_VERSION
    )
    payload = _to_json_payload(event)
    obj = payload.get("object")

    if version == PROCESS_PROTOCOL_V1:
        if obj == "message":
            return _downgrade_message_event_to_v1(payload)
        if obj == "response":
            return _downgrade_response_event_to_v1(payload)

    return payload


def serialize_process_event(
    event: BaseModel,
    *,
    protocol_version: str = DEFAULT_PROCESS_PROTOCOL_VERSION,
) -> str:
    """Serialize one process event according to the requested wire protocol."""
    payload = process_event_to_payload(event, protocol_version=protocol_version)
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
