# -*- coding: utf-8 -*-
"""Runner utility helpers.

build_env_context — constructs an environment context string for the system
prompt, containing session/user/channel info and usage hints.
"""

from typing import Optional


def build_env_context(
    session_id: Optional[str] = None,
    user_id: Optional[str] = None,
    channel: Optional[str] = None,
    working_dir: Optional[str] = None,
    add_hint: bool = True,
) -> str:
    """
    Build environment context with current request context prepended.

    Args:
        session_id: Current session ID
        user_id: Current user ID
        channel: Current channel name
        working_dir: Working directory path
        add_hint: Whether to add hint context
    Returns:
        Formatted environment context string
    """
    parts = []
    if session_id is not None:
        parts.append(f"- 当前的session_id: {session_id}")
    if user_id is not None:
        parts.append(f"- 当前的user_id: {user_id}")
    if channel is not None:
        parts.append(f"- 当前的channel: {channel}")

    if working_dir is not None:
        parts.append(f"- 工作目录: {working_dir}")

    if add_hint:
        parts.append(
            "- 重要提示:\n"
            "  1. 完成任务时，优先考虑使用 skills"
            "（例如定时任务，优先使用 cron skill）。"
            "对于不清楚的 skills，请先查阅相关对应文档。\n"
            "  2. 使用 write_file 写文件时，如果担心覆盖原有内容，"
            "可以先用 read_file 查看文件内容，"
            "再使用 edit_file 工具进行局部内容更新或追加内容。",
        )

    return "====================\n" + "\n".join(parts) + "\n===================="
