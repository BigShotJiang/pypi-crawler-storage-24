#! -*- coding: utf-8 -*-
"""Run controller for a single agent query.

This module owns the lifecycle of a single ``query_handler`` call:
* Logging and basic request metadata
* Wiring session / tools / events together
* Handling cancellation, errors and finalisation

Execution is handled exclusively via the LangGraph path, including:
* LangGraph-native command handling
* Session persistence (save/load history + compressed summary)
* Graceful cancellation via middleware
* Middleware integration (Bootstrap + MemoryCompaction)
"""

from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass
from typing import Any, AsyncIterator, Optional
from uuid import uuid4

from .event_bridge import EventBridge
from ..error_utils import classify_exception
from .query_error_dump import write_query_error_dump
from .session_factory import LangGraphSessionContext, SessionFactory
from .tool_registry import ToolRegistry
from ..channels.schema import DEFAULT_CHANNEL

logger = logging.getLogger(__name__)
_MEDIA_BLOCK_TYPES = frozenset({"file", "image", "audio", "video"})


def _message_has_file_or_media_blocks(message: Any) -> bool:
    """Return True when the message contains file/media blocks."""
    content = getattr(message, "content", None)
    if not isinstance(content, list):
        return False

    for block in content:
        if not isinstance(block, dict):
            if hasattr(block, "model_dump"):
                block = block.model_dump(exclude_none=True)
            elif hasattr(block, "dict"):
                block = block.dict(exclude_none=True)
            else:
                continue

        if block.get("type") in _MEDIA_BLOCK_TYPES:
            return True

    return False


@dataclass
class RunContext:
    """Lightweight context for a single run."""

    run_id: str
    session_id: Optional[str]
    user_id: Optional[str]
    channel: str


class RunController:
    """Control the lifecycle of a single agent run."""

    def __init__(
        self,
        *,
        session_factory: SessionFactory,
        tool_registry: ToolRegistry,
        event_bridge: EventBridge,
    ) -> None:
        self._session_factory = session_factory
        self._tool_registry = tool_registry
        self._event_bridge = event_bridge
        self.last_run_usage: dict[str, Any] | None = None
        self.last_final_output_usage: dict[str, Any] | None = None

    async def run(
        self,
        *,
        msgs,
        request: Any,
    ) -> AsyncIterator[tuple[Any, bool]]:
        """Execute a single agent run as an async generator.

        Always dispatches to the LangGraph execution path.
        """
        self.last_run_usage = None
        self.last_final_output_usage = None
        run_ctx = RunContext(
            run_id=str(uuid4()),
            session_id=request.session_id,
            user_id=request.user_id,
            channel=getattr(request, "channel", DEFAULT_CHANNEL),
        )

        logger.info(
            "Handle agent query (run_id=%s):\n%s",
            run_ctx.run_id,
            json.dumps(
                {
                    "session_id": run_ctx.session_id,
                    "user_id": run_ctx.user_id,
                    "channel": run_ctx.channel,
                    "msgs_len": len(msgs) if msgs else 0,
                    "msgs_str": str(msgs)[:300] + "...",
                },
                ensure_ascii=False,
                indent=2,
            ),
        )

        async for msg, last in self._run_langgraph(
            msgs=msgs, request=request, run_ctx=run_ctx
        ):
            yield msg, last

    # ------------------------------------------------------------------
    # LangGraph path
    # ------------------------------------------------------------------

    async def _run_langgraph(
        self,
        *,
        msgs,
        request: Any,
        run_ctx: RunContext,
    ) -> AsyncIterator[tuple[Any, bool]]:
        """New LangGraph agent execution path.

        Stage 1: Inspect the last user message and short-circuit pure commands
        Stage 2: For normal queries, preprocess files and build full context
        Stage 3: Execute ReAct agent via graph.astream_events

        PR5: Commands are now handled natively; session state is persisted.
        """
        from ...agent.langgraph.command_handler import (
            LangGraphCommandHandler,
            is_command,
        )
        from ...agent.langgraph.event_bridge import LangGraphEventBridge
        from ...agent.langgraph.message_converter import msgs_to_langchain
        from ...agent.utils import process_file_and_media_blocks_in_message

        chat = None
        lg_context: LangGraphSessionContext | None = None
        self.last_run_usage = None
        self.last_final_output_usage = None

        try:

            def _build_command_handler(context: LangGraphSessionContext):
                return LangGraphCommandHandler(
                    history_messages=context.history_messages,
                    middleware=context.middleware,
                    session_store=context.session_store,
                    session_id=context.session_id or run_ctx.run_id,
                    user_id=context.user_id,
                    channel=context.channel,
                    memory_manager=(self._session_factory._memory_manager),
                )

            # ── Stage 1: Command short-circuit ──
            last_msg = msgs[-1] if isinstance(msgs, list) else msgs
            query = (
                last_msg.get_text_content()
                if hasattr(last_msg, "get_text_content")
                else None
            )
            is_pure_command = bool(
                last_msg is not None
                and query
                and is_command(query)
                and not _message_has_file_or_media_blocks(last_msg)
            )

            if is_pure_command:
                logger.info(
                    "LangGraph path: short-circuiting pure command '%s'",
                    query.strip(),
                )
                lg_context = await self._session_factory.create_command_context(
                    msgs=msgs,
                    request=request,
                )
                chat = lg_context.chat
                result_msg = await _build_command_handler(lg_context).handle(query)
                yield result_msg, True
                return

            # ── Stage 2: Full context for normal queries ──
            if msgs is not None:
                await process_file_and_media_blocks_in_message(msgs)

            mcp_clients = await self._tool_registry.get_mcp_clients()
            lg_context = await self._session_factory.create_langgraph_context(
                msgs=msgs,
                request=request,
                mcp_clients=mcp_clients,
            )
            chat = lg_context.chat

            # ── Command interception after full init ──
            if query and is_command(query):
                logger.info(
                    "LangGraph path: handling command '%s' natively",
                    query,
                )
                result_msg = await _build_command_handler(lg_context).handle(query)
                yield result_msg, True
                return

            # ── Stage 3: Execute Agent ──
            # Convert incoming Msg objects to LangChain messages
            lc_messages = msgs_to_langchain(msgs if isinstance(msgs, list) else [msgs])
            # Prepend history (loaded from session store)
            all_messages = lg_context.history_messages + lc_messages

            bridge = LangGraphEventBridge(emit_tool_events=True)

            async for msg, last in bridge.stream(
                lg_context.graph,
                all_messages,
                config={
                    "configurable": {
                        "thread_id": lg_context.session_id or run_ctx.run_id,
                    },
                },
                max_iterations=lg_context.config.max_iterations,
            ):
                yield msg, last

            self.last_run_usage = bridge.run_usage
            self.last_final_output_usage = bridge.final_output_usage

            # After streaming completes, update history with the full
            # conversation (input + output) for session persistence.
            if bridge.final_output_messages:
                lg_context.history_messages = bridge.final_output_messages

        except asyncio.CancelledError:
            # PR5: graceful cancel via middleware
            if lg_context and lg_context.middleware:
                lg_context.middleware.cancel()
            raise
        except Exception as exc:  # pylint: disable=broad-except
            error_info = classify_exception(exc)
            debug_dump_path = write_query_error_dump(
                request=request,
                exc=exc,
                locals_=locals(),
            )
            path_hint = f"\n(Details:  {debug_dump_path})" if debug_dump_path else ""
            logger.exception(
                "Error in LangGraph query handler [%s/%s]: %s%s",
                error_info.code,
                error_info.source,
                error_info.raw_message or exc,
                path_hint,
            )
            setattr(exc, "lightclaw_error_info", error_info.to_event_error())
            if debug_dump_path:
                setattr(exc, "debug_dump_path", debug_dump_path)
                if hasattr(exc, "add_note"):
                    exc.add_note(f"(Details:  {debug_dump_path})")
                suffix = f"\n(Details:  {debug_dump_path})"
                exc.args = (
                    (f"{exc.args[0]}{suffix}" if exc.args else suffix.strip()),
                ) + exc.args[1:]
            raise
        finally:
            # PR5: Save LangGraph session state
            if lg_context is not None:
                try:
                    await self._session_factory.save_langgraph_session_state(
                        lg_context,
                    )
                except Exception:
                    logger.exception("Failed to save LangGraph session state")

            if chat is not None:
                await self._session_factory.update_chat(chat)
