# -*- coding: utf-8 -*-
# pylint: disable=unused-argument too-many-branches too-many-statements
"""AgentRunner — self-built runner, no agentscope_runtime dependency.

Replaces the old ``Runner`` base class from agentscope_runtime.  The key
method ``stream_query(request)`` directly consumes ``RunController.run()``
tokens and yields SSE events (ResponseEvent / MessageEvent / ContentEvent)
without passing through ``adapt_agentscope_message_stream``.
"""

import json
import logging
from pathlib import Path
from typing import Any, AsyncIterator

from dotenv import load_dotenv

from .session import SafeSession
from ..error_utils import classify_exception
from .run_controller import RunController
from .session_factory import SessionFactory
from .tool_registry import ToolRegistry
from .event_bridge import EventBridge
from ..channels.schema import DEFAULT_CHANNEL
from ...agent.memory import MemoryManager
from ...config import load_config
from ...constant import WORKING_DIR
from ..schemas import (
    AgentRequest,
    RunStatus,
    MessageType,
)
from ..schemas.events import (
    ResponseEvent,
    ResponseEventMetadata,
    MessageEvent,
    MessageEventMetadata,
    ContentEvent,
    SequenceCounter,
)
from ..schemas.content_types import (
    ContentType,
    FunctionCall,
    FunctionCallOutput,
)

logger = logging.getLogger(__name__)


class AgentRunner:
    """Self-built runner that directly produces SSE events.

    ``stream_query(request)`` is consumed by:
      - ``/api/agent/process`` SSE endpoint (via _app.py)
      - Channels via ``make_process_from_runner(runner)``
    """

    def __init__(self) -> None:
        self._chat_manager = None
        self._mcp_manager = None
        self.session: SafeSession | None = None
        self.memory_manager: MemoryManager | None = None

    # ----- external dependency injection -----

    def set_chat_manager(self, chat_manager):
        """Set chat manager for auto-registration."""
        self._chat_manager = chat_manager

    def set_mcp_manager(self, mcp_manager):
        """Set MCP client manager for hot-reload support."""
        self._mcp_manager = mcp_manager

    # ----- lifecycle -----

    async def start(self):
        """Initialise session, memory, etc. (replaces init_handler)."""
        env_path = Path(__file__).resolve().parents[4] / ".env"
        if env_path.exists():
            load_dotenv(env_path)
            logger.debug("Loaded environment variables from %s", env_path)
        else:
            logger.debug(
                ".env file not found at %s, using existing environment variables",
                env_path,
            )

        session_dir = str(WORKING_DIR / "sessions")
        self.session = SafeSession(save_dir=session_dir)

        try:
            if self.memory_manager is None:
                self.memory_manager = MemoryManager(
                    working_dir=str(WORKING_DIR),
                )
            await self.memory_manager.start()
        except Exception as e:
            logger.exception("MemoryManager start failed: %s", e)

    async def stop(self):
        """Shutdown handler."""
        try:
            if self.memory_manager:
                await self.memory_manager.close()
        except Exception as e:
            logger.warning("MemoryManager stop failed: %s", e)

    # ----- core: stream_query -----

    async def stream_query(
        self,
        request: Any,
    ) -> AsyncIterator[Any]:
        """Core SSE event generator.

        Directly consumes RunController.run() token stream and yields
        SSE events — no adapt_agentscope_message_stream, no aggregation.

        Yields:
            ResponseEvent / MessageEvent / ContentEvent instances with
            correct sequence_number, object, status fields.
        """
        seq = SequenceCounter()

        # Parse request if it's a raw dict
        if isinstance(request, dict):
            request = AgentRequest(**request)

        show_tool_details = True
        try:
            app_config = load_config()
            show_tool_details = bool(getattr(app_config, "show_tool_details", True))
        except Exception as e:
            logger.warning("Failed to load config.show_tool_details: %s", e)

        # 1. Response created → in_progress
        resp = ResponseEvent(
            status=RunStatus.Created,
            session_id=getattr(request, "session_id", ""),
        )
        yield seq.stamp(resp)

        resp_ip = resp.model_copy(update={"status": RunStatus.InProgress})
        yield seq.stamp(resp_ip)

        # 2. Consume RunController.run() token stream
        current_msg: MessageEvent | None = None
        message_buffers: dict[str, dict[str, Any]] = {}

        # Track tool_use / tool_result IDs already emitted so that
        # the final ``is_last=True`` message from the event bridge
        # does not re-send them.
        emitted_tool_use_ids: set[str] = set()
        emitted_tool_result_ids: set[str] = set()

        def _buffer_for(msg_id: str) -> dict[str, Any]:
            return message_buffers.setdefault(
                msg_id,
                {"text": "", "blocks": []},
            )

        def _append_text(msg_id: str, text: str) -> None:
            if not msg_id or not text:
                return
            buf = _buffer_for(msg_id)
            buf["text"] = (buf.get("text", "") or "") + text

        def _append_block(msg_id: str, block: dict[str, Any]) -> None:
            if not msg_id:
                return
            _buffer_for(msg_id)["blocks"].append(block)

        def _buffered_text(msg_id: str) -> str:
            if not msg_id:
                return ""
            return str((message_buffers.get(msg_id) or {}).get("text") or "")

        def _hydrate_message_content(
            msg: MessageEvent | None,
            *,
            force: bool = False,
        ) -> None:
            """Populate ``msg.content`` from the accumulated buffer.

            When *force* is ``False`` (the default for normal completed
            messages), we **skip** hydrating the full text/blocks into the
            ``MessageEvent`` because the frontend has already received all
            data incrementally via ``ContentEvent`` deltas.  This avoids
            re-serialising the entire content payload a second time,
            cutting SSE response size roughly in half.

            Set *force=True* for error paths where the frontend may not
            have received all content events.
            """
            if msg is None:
                return
            buf = message_buffers.pop(msg.id, None)
            if not buf:
                return
            if force:
                text = str(buf.get("text") or "")
                blocks = list(buf.get("blocks") or [])
                content: list[dict[str, Any]] = []
                if text:
                    content.append({"type": "text", "text": text})
                content.extend(blocks)
                msg.content = content

        def _coerce_dict_like(value: Any) -> dict[str, Any] | None:
            if value is None:
                return None
            if hasattr(value, "model_dump"):
                value = value.model_dump(exclude_none=True)
            elif hasattr(value, "dict"):
                value = value.dict(exclude_none=True)
            if isinstance(value, dict):
                return dict(value)
            return None

        def _attach_assistant_usage(
            msg_event: MessageEvent | None,
            *,
            source_msg: Any | None = None,
        ) -> None:
            if msg_event is None or source_msg is None:
                return
            if msg_event.type != MessageType.MESSAGE or msg_event.role != "assistant":
                return

            usage = _coerce_dict_like(getattr(source_msg, "usage", None))
            if not usage:
                return

            metadata = (
                msg_event.metadata.model_dump(exclude_none=True)
                if isinstance(msg_event.metadata, MessageEventMetadata)
                else _coerce_dict_like(msg_event.metadata) or {}
            )
            metadata["usage"] = usage
            msg_event.metadata = MessageEventMetadata(**metadata)

        try:
            if self.session is None:
                raise RuntimeError("Session is not initialised")

            request_channel = (
                getattr(request, "channel", DEFAULT_CHANNEL) or DEFAULT_CHANNEL
            )
            hydrate_completed_messages = request_channel != DEFAULT_CHANNEL

            session_factory = SessionFactory(
                session=self.session,
                memory_manager=self.memory_manager,
                chat_manager=self._chat_manager,
            )
            tool_registry = ToolRegistry(mcp_manager=self._mcp_manager)
            event_bridge = EventBridge()
            controller = RunController(
                session_factory=session_factory,
                tool_registry=tool_registry,
                event_bridge=event_bridge,
            )

            async for msg, is_last in controller.run(
                msgs=request.input,
                request=request,
            ):
                content = (
                    getattr(msg, "content", "") if hasattr(msg, "content") else str(msg)
                )
                current_id = current_msg.id if current_msg is not None else ""
                has_streamed_text = bool(_buffered_text(current_id))

                # --- text token (str content) ---
                if isinstance(content, str):
                    if current_msg is None:
                        current_msg = MessageEvent(
                            status=RunStatus.InProgress,
                            type=MessageType.MESSAGE,
                            role=getattr(msg, "role", "assistant"),
                        )
                        yield seq.stamp(current_msg.model_copy())
                    # LangGraph may emit final full text (is_last=True)
                    # after streaming chunks. Skip adding duplicated final
                    # full text when we already buffered streamed text.
                    if not (is_last and has_streamed_text):
                        _append_text(current_msg.id, content)
                        yield seq.stamp(
                            ContentEvent(
                                status=RunStatus.InProgress,
                                type=ContentType.TEXT,
                                delta=True,
                                text=content,
                                msg_id=current_msg.id,
                            )
                        )

                # --- structured content (list of blocks) ---
                elif isinstance(content, list):
                    for block in content:
                        if not isinstance(block, dict):
                            continue
                        btype = block.get("type", "text")

                        if btype == "text":
                            if current_msg is None:
                                current_msg = MessageEvent(
                                    status=RunStatus.InProgress,
                                    type=MessageType.MESSAGE,
                                    role=getattr(msg, "role", "assistant"),
                                )
                                yield seq.stamp(current_msg.model_copy())
                            if is_last and has_streamed_text:
                                continue
                            text_block = block.get("text", "")
                            _append_text(current_msg.id, text_block)
                            yield seq.stamp(
                                ContentEvent(
                                    status=RunStatus.InProgress,
                                    type=ContentType.TEXT,
                                    delta=True,
                                    text=text_block,
                                    msg_id=current_msg.id,
                                )
                            )

                        elif btype == "thinking":
                            # Close any open message
                            if current_msg is not None:
                                current_msg.status = RunStatus.Completed
                                _attach_assistant_usage(current_msg, source_msg=msg)
                                _hydrate_message_content(
                                    current_msg,
                                    force=hydrate_completed_messages,
                                )
                                yield seq.stamp(current_msg.model_copy())
                                current_msg = None

                            reasoning_msg = MessageEvent(
                                status=RunStatus.InProgress,
                                type=MessageType.REASONING,
                            )
                            yield seq.stamp(reasoning_msg.model_copy())
                            thinking_text = block.get("thinking", "")
                            _append_text(reasoning_msg.id, thinking_text)
                            yield seq.stamp(
                                ContentEvent(
                                    status=RunStatus.InProgress,
                                    type=ContentType.TEXT,
                                    delta=True,
                                    text=thinking_text,
                                    msg_id=reasoning_msg.id,
                                )
                            )
                            reasoning_msg.status = RunStatus.Completed
                            _hydrate_message_content(reasoning_msg, force=True)
                            yield seq.stamp(reasoning_msg.model_copy())

                        elif btype == "tool_use":
                            tool_use_id = block.get("id", "")
                            # Skip tool_use blocks already emitted via
                            # earlier streaming events.
                            if is_last and tool_use_id in emitted_tool_use_ids:
                                continue
                            emitted_tool_use_ids.add(tool_use_id)

                            # Close any open message
                            if current_msg is not None:
                                current_msg.status = RunStatus.Completed
                                _attach_assistant_usage(current_msg, source_msg=msg)
                                _hydrate_message_content(
                                    current_msg,
                                    force=hydrate_completed_messages,
                                )
                                yield seq.stamp(current_msg.model_copy())
                                current_msg = None

                            if not show_tool_details:
                                continue

                            plugin_msg = MessageEvent(
                                status=RunStatus.InProgress,
                                type=MessageType.PLUGIN_CALL,
                            )
                            yield seq.stamp(plugin_msg.model_copy())

                            arguments = block.get("input", {})
                            if isinstance(arguments, (dict, list)):
                                arguments = json.dumps(
                                    arguments,
                                    ensure_ascii=False,
                                )

                            call_data = FunctionCall(
                                call_id=block.get("id"),
                                name=block.get("name"),
                                arguments=arguments,
                            ).model_dump()
                            _append_block(
                                plugin_msg.id,
                                {
                                    "type": ContentType.DATA,
                                    "data": call_data,
                                },
                            )

                            yield seq.stamp(
                                ContentEvent(
                                    status=RunStatus.InProgress,
                                    type=ContentType.DATA,
                                    delta=False,
                                    data=call_data,
                                    msg_id=plugin_msg.id,
                                )
                            )
                            plugin_msg.status = RunStatus.Completed
                            _hydrate_message_content(plugin_msg, force=True)
                            yield seq.stamp(plugin_msg.model_copy())

                        elif btype == "tool_result":
                            tool_result_id = block.get("id", "")
                            # Skip tool_result blocks already emitted via
                            # earlier streaming events.
                            if is_last and tool_result_id in emitted_tool_result_ids:
                                continue
                            emitted_tool_result_ids.add(tool_result_id)

                            # Close any open message
                            if current_msg is not None:
                                current_msg.status = RunStatus.Completed
                                _attach_assistant_usage(current_msg, source_msg=msg)
                                _hydrate_message_content(
                                    current_msg,
                                    force=hydrate_completed_messages,
                                )
                                yield seq.stamp(current_msg.model_copy())
                                current_msg = None

                            if not show_tool_details:
                                continue

                            output_msg = MessageEvent(
                                status=RunStatus.InProgress,
                                type=MessageType.PLUGIN_CALL_OUTPUT,
                            )
                            yield seq.stamp(output_msg.model_copy())

                            output_val = block.get("output") or block.get("content", "")
                            if isinstance(output_val, (dict, list)):
                                output_val = json.dumps(
                                    output_val,
                                    ensure_ascii=False,
                                )

                            output_data = FunctionCallOutput(
                                call_id=block.get("id") or block.get("tool_use_id"),
                                name=block.get("name"),
                                output=output_val,
                            ).model_dump(exclude_none=True)
                            _append_block(
                                output_msg.id,
                                {
                                    "type": ContentType.DATA,
                                    "data": output_data,
                                },
                            )

                            yield seq.stamp(
                                ContentEvent(
                                    status=RunStatus.InProgress,
                                    type=ContentType.DATA,
                                    delta=False,
                                    data=output_data,
                                    msg_id=output_msg.id,
                                )
                            )
                            output_msg.status = RunStatus.Completed
                            _hydrate_message_content(output_msg, force=True)
                            yield seq.stamp(output_msg.model_copy())

                        elif btype == "image":
                            if current_msg is None:
                                current_msg = MessageEvent(
                                    status=RunStatus.InProgress,
                                    type=MessageType.MESSAGE,
                                    role=getattr(msg, "role", "assistant"),
                                )
                                yield seq.stamp(current_msg.model_copy())

                            source = block.get("source", {}) or {}
                            preview_url = str(block.get("preview_url") or "")
                            image_url = ""
                            if isinstance(source, dict):
                                if source.get("type") == "url":
                                    image_url = source.get("url", "")
                                elif source.get("type") == "base64":
                                    mt = source.get("media_type", "image/jpeg")
                                    b64 = source.get("data", "")
                                    image_url = f"data:{mt};base64,{b64}"
                            if image_url:
                                image_block: dict[str, Any] = {
                                    "type": ContentType.IMAGE,
                                    "source": source,
                                }
                                if preview_url:
                                    image_block["preview_url"] = preview_url
                                    image_block["image_url"] = preview_url
                                _append_block(
                                    current_msg.id,
                                    image_block,
                                )

                            yield seq.stamp(
                                ContentEvent(
                                    status=RunStatus.InProgress,
                                    type=ContentType.IMAGE,
                                    delta=False,
                                    image_url=preview_url or image_url,
                                    msg_id=current_msg.id,
                                )
                            )

                        elif btype == "file":
                            if current_msg is None:
                                current_msg = MessageEvent(
                                    status=RunStatus.InProgress,
                                    type=MessageType.MESSAGE,
                                    role=getattr(msg, "role", "assistant"),
                                )
                                yield seq.stamp(current_msg.model_copy())
                            source = block.get("source", {}) or {}
                            preview_url = str(block.get("preview_url") or "")
                            file_url = block.get("file_url") or block.get("url", "")
                            if isinstance(source, dict):
                                if source.get("type") == "url":
                                    file_url = file_url or source.get("url", "")
                                elif source.get("type") == "base64":
                                    mt = source.get(
                                        "media_type",
                                        "application/octet-stream",
                                    )
                                    b64 = source.get("data", "")
                                    if b64:
                                        file_url = f"data:{mt};base64,{b64}"
                            filename = (
                                block.get("filename")
                                or block.get("name", "")
                                or block.get("path", "")
                            )
                            file_block: dict[str, Any] = {
                                "type": ContentType.FILE,
                                "source": source,
                                "filename": filename,
                            }
                            if preview_url:
                                file_block["preview_url"] = preview_url
                            _append_block(current_msg.id, file_block)

                            yield seq.stamp(
                                ContentEvent(
                                    status=RunStatus.InProgress,
                                    type=ContentType.FILE,
                                    delta=False,
                                    file_url=preview_url or file_url,
                                    filename=filename,
                                    msg_id=current_msg.id,
                                )
                            )

                # is_last → close current message
                if is_last and current_msg is not None:
                    current_msg.status = RunStatus.Completed
                    _attach_assistant_usage(current_msg, source_msg=msg)
                    _hydrate_message_content(
                        current_msg,
                        force=hydrate_completed_messages,
                    )
                    yield seq.stamp(current_msg.model_copy())
                    current_msg = None

        except Exception as e:
            error_info = classify_exception(e)
            logger.exception(
                "stream_query error [%s/%s]: %s",
                error_info.code,
                error_info.source,
                error_info.raw_message or error_info.message,
            )
            # Close any open message as failed
            if current_msg is not None:
                current_msg.status = RunStatus.Failed
                current_msg.error = error_info.to_event_error()
                if not message_buffers.get(current_msg.id):
                    current_msg.content = [
                        {"type": ContentType.TEXT, "text": error_info.message}
                    ]
                _hydrate_message_content(current_msg, force=True)
                yield seq.stamp(current_msg.model_copy())
            # Response failed
            resp_fail = resp.model_copy(
                update={
                    "status": RunStatus.Failed,
                    "error": error_info.to_event_error(),
                },
            )
            yield seq.stamp(resp_fail)
            return

        # 3. Response completed
        run_usage = _coerce_dict_like(getattr(controller, "last_run_usage", None))
        resp_done = resp.model_copy(
            update={
                "status": RunStatus.Completed,
                "metadata": (
                    ResponseEventMetadata(run_usage=run_usage) if run_usage else None
                ),
            }
        )
        yield seq.stamp(resp_done)
