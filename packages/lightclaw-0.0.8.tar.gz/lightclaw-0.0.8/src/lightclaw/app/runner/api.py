# -*- coding: utf-8 -*-
"""Chat management API."""

from __future__ import annotations
import json
import logging
import os
from dataclasses import dataclass

from typing import Any, Optional
from uuid import uuid4
from fastapi import APIRouter, Depends, HTTPException, Query, Request

from ...agent.langgraph.message_converter import (
    langchain_to_msgs,
    msg_to_langchain,
)
from ...agent.langgraph.session_store import LangGraphSessionStore
from ...config import load_config
from ..schemas import Message
from .manager import ChatManager
from .models import (
    ChatSpec,
    ChatHistory,
)


logger = logging.getLogger(__name__)

router = APIRouter(prefix="/chats", tags=["chats"])


@dataclass
class _LegacyMessagePayload:
    role: str
    content: Any


def _extract_legacy_message(item: Any) -> _LegacyMessagePayload | None:
    raw: Any = None
    if isinstance(item, (list, tuple)) and len(item) == 2:
        raw = item[0]
    elif isinstance(item, dict):
        raw = item

    if not isinstance(raw, dict):
        return None

    return _LegacyMessagePayload(
        role=raw.get("role", "assistant"),
        content=raw.get("content", ""),
    )


def _legacy_state_to_messages(state: Any) -> list[Message]:
    if not isinstance(state, dict):
        return []

    memory_state = state.get("agent", {}).get("memory", {})
    if not isinstance(memory_state, dict):
        return []

    memory_content = memory_state.get("content", [])
    if not isinstance(memory_content, list):
        return []

    messages: list[Message] = []
    for item in memory_content:
        payload = _extract_legacy_message(item)
        if payload is None:
            continue

        try:
            converted = msg_to_langchain(payload)
        except Exception:  # pylint: disable=broad-except
            logger.exception("Failed to parse legacy message payload")
            continue

        if isinstance(converted, list):
            messages.extend(langchain_to_msgs(converted))
        else:
            messages.extend(langchain_to_msgs([converted]))
    return messages


def _show_tool_details_enabled() -> bool:
    try:
        config = load_config()
        return bool(getattr(config, "show_tool_details", True))
    except Exception:
        logger.exception("Failed to load config for tool visibility check")
        return True


def _filter_tool_blocks(content: Any) -> list[Any]:
    """Remove tool-related blocks while preserving all other message fields."""
    if not isinstance(content, list):
        return []

    kept_blocks: list[Any] = []
    for block in content:
        if not isinstance(block, dict):
            kept_blocks.append(block)
            continue

        btype = block.get("type")
        if btype in ("tool_use", "tool_result"):
            continue
        if btype == "data":
            data = block.get("data")
            if isinstance(data, dict) and ("arguments" in data or "output" in data):
                continue
        kept_blocks.append(block)

    return kept_blocks


def _filter_tool_messages(messages: list[Any]) -> list[Any]:
    """Hide all tool messages/blocks when show_tool_details is False."""
    if _show_tool_details_enabled():
        return messages

    filtered: list[Any] = []
    for msg in messages:
        if isinstance(msg, Message):
            if msg.role == "tool":
                continue

            kept_blocks = _filter_tool_blocks(msg.content)
            if not kept_blocks and isinstance(msg.content, list):
                continue

            filtered.append(
                msg.model_copy(update={"content": kept_blocks or msg.content})
            )
            continue

        if not isinstance(msg, dict):
            filtered.append(msg)
            continue

        role = msg.get("role")
        if role == "tool":
            continue

        content = msg.get("content")
        if not isinstance(content, list):
            filtered.append(msg)
            continue

        kept_blocks = _filter_tool_blocks(content)
        if not kept_blocks:
            continue

        new_msg = dict(msg)
        new_msg["content"] = kept_blocks
        filtered.append(new_msg)

    return filtered


def get_chat_manager(request: Request) -> ChatManager:
    """Get the chat manager from app state.

    Args:
        request: FastAPI request object

    Returns:
        ChatManager instance

    Raises:
        HTTPException: If manager is not initialized
    """
    mgr = getattr(request.app.state, "chat_manager", None)
    if mgr is None:
        raise HTTPException(
            status_code=503,
            detail="Chat manager not initialized",
        )
    return mgr


def get_session(request: Request) -> Any:
    """Get the session from app state.

    Args:
        request: FastAPI request object

    Returns:
        Session persistence instance

    Raises:
        HTTPException: If session is not initialized
    """
    runner = getattr(request.app.state, "runner", None)
    if runner is None:
        raise HTTPException(
            status_code=503,
            detail="Session not initialized",
        )
    return runner.session


@router.get("", response_model=list[ChatSpec])
async def list_chats(
    user_id: Optional[str] = Query(None, description="Filter by user ID"),
    channel: Optional[str] = Query(None, description="Filter by channel"),
    mgr: ChatManager = Depends(get_chat_manager),
):
    """List all chats with optional filters.

    Args:
        user_id: Optional user ID to filter chats
        channel: Optional channel name to filter chats
        mgr: Chat manager dependency
    """
    return await mgr.list_chats(user_id=user_id, channel=channel)


@router.post("", response_model=ChatSpec)
async def create_chat(
    request: ChatSpec,
    mgr: ChatManager = Depends(get_chat_manager),
):
    """Create a new chat.

    Server generates chat_id (UUID) automatically.

    Args:
        request: Chat creation request
        mgr: Chat manager dependency

    Returns:
        Created chat spec with UUID
    """
    chat_id = str(uuid4())
    spec = ChatSpec(
        id=chat_id,
        name=request.name,
        session_id=request.session_id,
        user_id=request.user_id,
        channel=request.channel,
        meta=request.meta,
    )
    return await mgr.create_chat(spec)


@router.post("/batch-delete", response_model=dict)
async def batch_delete_chats(
    chat_ids: list[str],
    mgr: ChatManager = Depends(get_chat_manager),
):
    """Delete chats by chat IDs.

    Args:
        chat_ids: List of chat IDs
        mgr: Chat manager dependency
    Returns:
        True if deleted, False if failed

    """
    deleted = await mgr.delete_chats(chat_ids=chat_ids)
    return {"deleted": deleted}


@router.get("/{chat_id}", response_model=ChatHistory)
async def get_chat(
    chat_id: str,
    mgr: ChatManager = Depends(get_chat_manager),
    session: Any = Depends(get_session),
):
    """Get detailed information about a specific chat by UUID.

    Tries LangGraph session format first (.langgraph.json), then falls
    back to legacy AgentScope format (.json).

    Args:
        chat_id: Chat UUID
        mgr: Chat manager dependency
        session: Session dependency

    Returns:
        ChatHistory with messages

    Raises:
        HTTPException: If chat not found (404)
    """
    chat_spec = await mgr.get_chat(chat_id)
    if not chat_spec:
        raise HTTPException(
            status_code=404,
            detail=f"Chat not found: {chat_id}",
        )

    # 1) Prefer LangGraph session files
    save_dir = getattr(session, "save_dir", None)
    if save_dir:
        store = LangGraphSessionStore(save_dir=save_dir)
        messages, _ = await store.aload(
            session_id=chat_spec.session_id,
            user_id=chat_spec.user_id,
        )
        if messages:
            return ChatHistory(
                messages=_filter_tool_messages(langchain_to_msgs(messages))
            )

        # New-format file exists but no valid content: stop at empty history.
        # pylint: disable=protected-access
        if store._get_path(chat_spec.session_id, chat_spec.user_id).exists():
            return ChatHistory(messages=[])

    # 2) Legacy fallback ({uid}_{sid}.json)
    # pylint: disable=protected-access
    session_path = session._get_save_path(
        chat_spec.session_id,
        chat_spec.user_id,
    )

    # Validate that session_path is within the allowed save directory
    # to prevent path traversal attacks
    real_path = os.path.realpath(session_path)
    real_save_dir = os.path.realpath(session.save_dir)
    if not real_path.startswith(real_save_dir + os.sep):
        raise HTTPException(
            status_code=400,
            detail="Invalid session path",
        )

    # --- Try LangGraph format first (.langgraph.json) ---
    langgraph_path = session_path.replace(".json", ".langgraph.json")
    if os.path.exists(langgraph_path):
        try:
            messages = _load_langgraph_history(langgraph_path)
            return ChatHistory(messages=_filter_tool_messages(messages))
        except Exception:
            pass  # fall through to legacy format

    # --- Fallback: legacy AgentScope format (.json) ---
    try:
        with open(session_path, "r", encoding="utf-8") as file:
            state = json.load(file)
    except Exception:  # pylint: disable=broad-except
        return ChatHistory(messages=[])
    return ChatHistory(messages=_filter_tool_messages(_legacy_state_to_messages(state)))


def _load_langgraph_history(path: str) -> list[Message]:
    """Load LangGraph session file and convert to internal Message format.

    Args:
        path: Path to the .langgraph.json file

    Returns:
        List of internal ``Message`` objects, preserving normalized usage and
        metadata from the original LangChain messages.
    """
    from langchain_core.messages import messages_from_dict

    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    raw_messages = data.get("messages", [])
    if not raw_messages:
        return []

    return langchain_to_msgs(messages_from_dict(raw_messages))


@router.put("/{chat_id}", response_model=ChatSpec)
async def update_chat(
    chat_id: str,
    spec: ChatSpec,
    mgr: ChatManager = Depends(get_chat_manager),
):
    """Update an existing chat.

    Args:
        chat_id: Chat UUID
        spec: Updated chat specification
        mgr: Chat manager dependency

    Returns:
        Updated chat spec

    Raises:
        HTTPException: If chat_id mismatch (400) or not found (404)
    """
    if spec.id != chat_id:
        raise HTTPException(
            status_code=400,
            detail="chat_id mismatch",
        )

    # Check if exists
    existing = await mgr.get_chat(chat_id)
    if not existing:
        raise HTTPException(
            status_code=404,
            detail=f"Chat not found: {chat_id}",
        )

    updated = await mgr.update_chat(spec)
    return updated


@router.delete("/{chat_id}", response_model=dict)
async def delete_chat(
    chat_id: str,
    mgr: ChatManager = Depends(get_chat_manager),
):
    """Delete a chat by UUID.

    Note: This only deletes the chat spec (UUID mapping).
    Session state file is NOT deleted.

    Args:
        chat_id: Chat UUID
        mgr: Chat manager dependency

    Returns:
        True if deleted, False if failed

    Raises:
        HTTPException: If chat not found (404)
    """
    deleted = await mgr.delete_chats(chat_ids=[chat_id])
    if not deleted:
        raise HTTPException(
            status_code=404,
            detail=f"Chat not found: {chat_id}",
        )
    return {"deleted": True}
