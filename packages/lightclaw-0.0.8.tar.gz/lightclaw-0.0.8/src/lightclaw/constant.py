# -*- coding: utf-8 -*-
import os
from pathlib import Path

# BASE_DIR: root lightclaw directory — holds config, database, auth, env vars.
# This is NOT the agent working area; use WORKING_DIR for md/skills files.
BASE_DIR = (
    Path(os.environ.get("LIGHTCLAW_BASE_DIR", "~/.lightclaw")).expanduser().resolve()
)

# WORKING_DIR: agent workspace — holds *.md files, skills/, memory/, etc.
# Sub-directory of BASE_DIR so that config files and workspace are separated.
WORKING_DIR = (
    Path(os.environ.get("LIGHTCLAW_WORKING_DIR", str(BASE_DIR / "workspace")))
    .expanduser()
    .resolve()
)

JOBS_FILE = os.environ.get("LIGHTCLAW_JOBS_FILE", "jobs.json")

CHATS_FILE = os.environ.get("LIGHTCLAW_CHATS_FILE", "chats.json")

CONFIG_FILE = os.environ.get("LIGHTCLAW_CONFIG_FILE", "lightclaw.json")

PROVIDERS_FILE = os.environ.get("LIGHTCLAW_PROVIDERS_FILE", "providers.json")

HEARTBEAT_FILE = os.environ.get("LIGHTCLAW_HEARTBEAT_FILE", "HEARTBEAT.md")
HEARTBEAT_DEFAULT_EVERY = "30m"
HEARTBEAT_DEFAULT_TARGET = "main"
HEARTBEAT_TARGET_LAST = "last"

# Env key for app log level (used by CLI and app load for reload child).
LOG_LEVEL_ENV = "LIGHTCLAW_LOG_LEVEL"

# When True, expose /docs, /redoc, /openapi.json
# (dev only; keep False in prod).
DOCS_ENABLED = os.environ.get("LIGHTCLAW_OPENAPI_DOCS", "false").lower() in (
    "true",
    "1",
    "yes",
)

# Skills directories
# Unified skills directory (all skills: builtin synced + user-created)
SKILLS_DIR = WORKING_DIR / "skills"
# Legacy directories (kept for backward-compat migration only)
ACTIVE_SKILLS_DIR = WORKING_DIR / "active_skills"
CUSTOMIZED_SKILLS_DIR = WORKING_DIR / "customized_skills"

# Logs directory (one file per day, e.g. ~/.lightclaw/logs/lightclaw.log.YYYY-MM-DD)
LOGS_DIR = BASE_DIR / "logs"

# Memory directory
MEMORY_DIR = WORKING_DIR / "memory"

# Custom channel modules (installed via `lightclaw channels install`); manager
# loads BaseChannel subclasses from here.
CUSTOM_CHANNELS_DIR = WORKING_DIR / "custom_channels"

# Uploads directory (user-uploaded images / files)
UPLOADS_DIR = WORKING_DIR / "uploads"

# Memory compaction configuration
MEMORY_COMPACT_KEEP_RECENT = int(
    os.environ.get("LIGHTCLAW_MEMORY_COMPACT_KEEP_RECENT", "3"),
)

MEMORY_COMPACT_RATIO = float(
    os.environ.get("LIGHTCLAW_MEMORY_COMPACT_RATIO", "0.7"),
)

DASHSCOPE_BASE_URL = os.environ.get(
    "DASHSCOPE_BASE_URL",
    "https://dashscope.aliyuncs.com/compatible-mode/v1",
)

# ---------------------------------------------------------------------------
# Channel availability — controlled by LIGHTCLAW_ENABLED_CHANNELS env var.
# When unset / empty, all registered channels (built-in + plugins) are
# available. Set to a comma-separated list to restrict, e.g.
#   LIGHTCLAW_ENABLED_CHANNELS=dingtalk,feishu,qq,console
# ---------------------------------------------------------------------------


def get_available_channels() -> tuple[str, ...]:
    """Return channel keys enabled for this run (built-in + entry point
    lightclaw.channels), filtered by LIGHTCLAW_ENABLED_CHANNELS when set.
    """
    from .app.channels.registry import get_channel_registry

    registry = get_channel_registry()
    all_keys = tuple(registry.keys())
    raw = os.environ.get("LIGHTCLAW_ENABLED_CHANNELS", "").strip()
    if not raw:
        return all_keys
    enabled = tuple(ch.strip() for ch in raw.split(",") if ch.strip())
    return tuple(k for k in all_keys if k in enabled) or all_keys


# ---------------------------------------------------------------------------
# One-time migration: BASE_DIR/*.md + BASE_DIR/skills/ -> WORKING_DIR/
# ---------------------------------------------------------------------------


def migrate_to_workspace() -> bool:
    """Migrate legacy md files and skills from BASE_DIR into WORKING_DIR.

    This is a one-time migration that runs when WORKING_DIR does not yet exist
    (i.e. first start after upgrading to workspace-subdirectory layout).

    Moves:
    - ``BASE_DIR/*.md``  →  ``WORKING_DIR/*.md``
    - ``BASE_DIR/skills/``  →  ``WORKING_DIR/skills/``
    - ``BASE_DIR/memory/``  →  ``WORKING_DIR/memory/``
    - ``BASE_DIR/custom_channels/``  →  ``WORKING_DIR/custom_channels/``
    - ``BASE_DIR/uploads/``  →  ``WORKING_DIR/uploads/``

    Returns True if any migration was performed.
    """
    import logging
    import shutil

    logger = logging.getLogger(__name__)

    # Only migrate if WORKING_DIR doesn't exist yet (fresh layout transition)
    if WORKING_DIR.exists():
        return False

    WORKING_DIR.mkdir(parents=True, exist_ok=True)
    migrated = False

    # Move *.md files from BASE_DIR root
    for md_file in BASE_DIR.glob("*.md"):
        target = WORKING_DIR / md_file.name
        try:
            shutil.move(str(md_file), str(target))
            logger.info("Migrated md file: %s -> %s", md_file, target)
            migrated = True
        except Exception as exc:
            logger.warning("Failed to migrate %s: %s", md_file, exc)

    # Move directories: skills, memory, custom_channels, uploads
    for dir_name in ("skills", "memory", "custom_channels", "uploads"):
        src = BASE_DIR / dir_name
        dst = WORKING_DIR / dir_name
        if src.is_dir() and not dst.exists():
            try:
                shutil.move(str(src), str(dst))
                logger.info("Migrated directory: %s -> %s", src, dst)
                migrated = True
            except Exception as exc:
                logger.warning("Failed to migrate directory %s: %s", src, exc)

    if migrated:
        logger.info(
            "Migration complete: agent workspace files moved to %s", WORKING_DIR
        )
    return migrated
