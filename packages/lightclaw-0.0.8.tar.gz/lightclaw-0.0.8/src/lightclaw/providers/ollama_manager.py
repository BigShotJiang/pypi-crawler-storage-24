# -*- coding: utf-8 -*-
"""Ollama model management using the Ollama Python SDK.

This module manages model lifecycle operations via the running Ollama daemon
instead of managing files or a manifest.json. Ollama remains the single
source of truth for its models.

Auto-bootstrapping
------------------
* If the ``ollama`` Python package is missing, ``_ensure_ollama_sdk()``
  will attempt to ``pip install ollama`` automatically.
* If the Ollama daemon is not reachable, ``_ensure_ollama_server()`` will
  attempt to start ``ollama serve`` in the background.
"""

from __future__ import annotations

import logging
import platform
import shutil
import subprocess
import time
from datetime import datetime
from typing import List, Optional, Union

from pydantic import BaseModel, Field, field_validator

logger = logging.getLogger(__name__)

_OLLAMA_SERVER_STARTED = False


class OllamaModelInfo(BaseModel):
    """Metadata for a single Ollama model returned by ``ollama.list()``."""

    name: str = Field(..., description="Model name, e.g. 'llama3:8b'")
    size: int = Field(0, description="Approximate size in bytes (if provided)")
    digest: Optional[str] = Field(default=None, description="Model digest/id")
    modified_at: Optional[str] = Field(
        default=None,
        description="Last modified time string (from Ollama, if present)",
    )

    @field_validator("modified_at", mode="before")
    @classmethod
    def convert_datetime_to_str(
        cls,
        v: Union[str, datetime, None],
    ) -> Optional[str]:
        """Convert datetime objects to ISO format strings."""
        if v is None:
            return None
        if isinstance(v, datetime):
            return v.isoformat()
        return str(v)


# ── SDK bootstrap ────────────────────────────────────────────────


def _ensure_ollama_sdk():
    """Import the ollama Python SDK, raising ``ImportError`` if missing.

    Unlike the previous implementation this function does **not** attempt
    to ``pip install ollama`` at runtime.  Auto-installing packages inside
    a running server process is fragile and can cause unexpected delays or
    permission errors.  If the package is missing the caller should either
    surface a user-friendly error or silently skip Ollama-related features.
    """
    try:
        import ollama  # type: ignore[import]
    except ImportError:
        raise ImportError(
            "The 'ollama' Python package is not installed. "
            "Please install it manually: pip install ollama"
        )
    return ollama


def is_ollama_sdk_available() -> bool:
    """Return ``True`` if the ollama SDK can be imported, without side-effects."""
    try:
        import ollama  # type: ignore[import]  # noqa: F401

        return True
    except ImportError:
        return False


# ── Server bootstrap ────────────────────────────────────────────


def _is_ollama_reachable() -> bool:
    """Quick connectivity check to the Ollama HTTP endpoint."""
    import urllib.request
    import urllib.error

    try:
        req = urllib.request.Request(
            "http://127.0.0.1:11434",
            method="GET",
        )
        with urllib.request.urlopen(req, timeout=3):
            return True
    except Exception:
        return False


def _start_ollama_server() -> None:
    """Try to start ``ollama serve`` in the background."""
    global _OLLAMA_SERVER_STARTED

    ollama_bin = shutil.which("ollama")
    if ollama_bin is None:
        # On macOS the CLI can live inside the .app bundle
        if platform.system() == "Darwin":
            candidates = [
                "/usr/local/bin/ollama",
                "/opt/homebrew/bin/ollama",
            ]
            for c in candidates:
                if shutil.which(c):
                    ollama_bin = c
                    break
    if ollama_bin is None:
        raise EnvironmentError(
            "Ollama binary not found on this system. "
            "Please install Ollama from https://ollama.com/download"
        )

    logger.info("Ollama daemon not reachable, starting ollama serve …")
    try:
        subprocess.Popen(
            [ollama_bin, "serve"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
    except Exception as exc:
        raise EnvironmentError(f"Failed to start ollama serve: {exc}") from exc

    # Wait for the server to become reachable
    for _ in range(10):
        time.sleep(1)
        if _is_ollama_reachable():
            logger.info("Ollama daemon is now running.")
            _OLLAMA_SERVER_STARTED = True
            return
    raise EnvironmentError(
        "Started ollama serve but it did not become reachable within 10 seconds."
    )


def _ensure_ollama_server() -> None:
    """Make sure the Ollama daemon is reachable, starting it if needed."""
    if _is_ollama_reachable():
        return
    _start_ollama_server()


# ── Combined bootstrap entry point ──────────────────────────────


def _ensure_ollama():
    """Bootstrap both the SDK and the server, then return the module."""
    sdk = _ensure_ollama_sdk()
    _ensure_ollama_server()
    return sdk


class OllamaModelManager:
    """High-level wrapper around the Ollama SDK for model lifecycle.

    All operations delegate to the Ollama daemon; this module does not manage
    files or persist a manifest. It is safe to call these methods from
    background tasks and CLIs.
    """

    @staticmethod
    def list_models() -> List[OllamaModelInfo]:
        """Return the current model list from ``ollama.list()``."""

        ollama = _ensure_ollama()
        raw = ollama.list()
        models: List[OllamaModelInfo] = []
        for m in raw.get("models", []):
            models.append(
                OllamaModelInfo(
                    name=m.get("model", ""),
                    size=m.get("size", 0) or 0,
                    digest=m.get("digest"),
                    modified_at=m.get("modified_at"),
                ),
            )
        return models

    @staticmethod
    def pull_model(name: str) -> OllamaModelInfo:
        """Pull/download a model via ``ollama.pull``.

        This call is blocking and intended to be run in a thread executor when
        used from async FastAPI endpoints.
        """

        ollama = _ensure_ollama()
        logger.info("Pulling Ollama model: %s", name)
        ollama.pull(name)
        logger.info("Pull completed: %s", name)

        for model in OllamaModelManager.list_models():
            if model.name == name:
                return model

        raise ValueError(f"Ollama model '{name}' not found after pull.")

    @staticmethod
    def delete_model(name: str) -> None:
        """Delete a model from the local Ollama instance."""

        ollama = _ensure_ollama()
        logger.info("Deleting Ollama model: %s", name)
        ollama.delete(name)
        logger.info("Ollama model deleted: %s", name)
