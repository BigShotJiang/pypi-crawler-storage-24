# -*- coding: utf-8 -*-
"""Built-in provider definitions and registry."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import TYPE_CHECKING, Dict, List, Optional

from .models import CustomProviderData, ModelInfo, ModelCost, ProviderDefinition

if TYPE_CHECKING:
    from .models import ProvidersData

_TEMPLATES_PATH = Path(__file__).resolve().parent / "model_templates.json"

# ---------------------------------------------------------------------------
# Load bundled model metadata templates (shipped as source)
# ---------------------------------------------------------------------------


def _load_model_templates() -> Dict[str, Dict[str, dict]]:
    """Load model_templates.json and return {provider_id: {model_id: metadata}}."""
    try:
        with open(_TEMPLATES_PATH, "r", encoding="utf-8") as fh:
            raw = json.load(fh)
        result: Dict[str, Dict[str, dict]] = {}
        for pid, pdata in raw.get("providers", {}).items():
            result[pid] = pdata.get("models", {})
        return result
    except Exception:
        return {}


_MODEL_TEMPLATES: Dict[str, Dict[str, dict]] = _load_model_templates()


def _apply_template(model: ModelInfo, provider_id: str) -> ModelInfo:
    """Merge bundled metadata into a ModelInfo if the user hasn't set it."""
    tmpl = _MODEL_TEMPLATES.get(provider_id, {}).get(model.id)
    if not tmpl:
        return model
    # Only fill in fields that are not already set on the model
    updates: dict = {}
    if model.context_window is None and "contextWindow" in tmpl:
        updates["context_window"] = tmpl["contextWindow"]
    if model.max_tokens is None and "maxTokens" in tmpl:
        updates["max_tokens"] = tmpl["maxTokens"]
    if model.reasoning is None and "reasoning" in tmpl:
        updates["reasoning"] = tmpl["reasoning"]
    if model.input is None and "input" in tmpl:
        updates["input"] = tmpl["input"]
    if model.cost is None and "cost" in tmpl:
        cost_raw = tmpl["cost"]
        updates["cost"] = ModelCost(
            input=cost_raw.get("input", 0.0),
            output=cost_raw.get("output", 0.0),
            cache_read=cost_raw.get("cacheRead", 0.0),
            cache_write=cost_raw.get("cacheWrite", 0.0),
        )
    if not updates:
        return model
    return model.model_copy(update=updates)


def get_model_template(provider_id: str, model_id: str) -> Optional[dict]:
    """Return the raw template dict for a specific provider/model, or None."""
    return _MODEL_TEMPLATES.get(provider_id, {}).get(model_id)


PROVIDER_OLLAMA = ProviderDefinition(
    id="ollama",
    name="Ollama",
    default_base_url="http://localhost:11434/v1",
    api_key_prefix="",
    models=[],
)

PROVIDER_OPENAI = ProviderDefinition(
    id="openai",
    name="OpenAI",
    default_base_url="https://api.openai.com/v1",
    api_key_prefix="sk-",
    models=[
        ModelInfo(id="gpt-4o", name="GPT-4o"),
        ModelInfo(id="gpt-4o-mini", name="GPT-4o Mini"),
        ModelInfo(id="gpt-4-turbo", name="GPT-4 Turbo"),
        ModelInfo(id="o3-mini", name="o3-mini"),
    ],
)

PROVIDER_ANTHROPIC = ProviderDefinition(
    id="anthropic",
    name="Anthropic",
    default_base_url="https://api.anthropic.com/v1",
    api_key_prefix="sk-ant-",
    models=[
        ModelInfo(id="claude-sonnet-4-20250514", name="Claude Sonnet 4"),
        ModelInfo(id="claude-3-5-sonnet-20241022", name="Claude 3.5 Sonnet"),
        ModelInfo(id="claude-3-5-haiku-20241022", name="Claude 3.5 Haiku"),
    ],
)

PROVIDER_GEMINI = ProviderDefinition(
    id="gemini",
    name="Google Gemini",
    default_base_url=("https://generativelanguage.googleapis.com/v1beta/openai"),
    api_key_prefix="",
    models=[
        ModelInfo(id="gemini-2.5-flash", name="Gemini 2.5 Flash"),
        ModelInfo(id="gemini-2.5-pro", name="Gemini 2.5 Pro"),
        ModelInfo(id="gemini-2.0-flash", name="Gemini 2.0 Flash"),
    ],
)

PROVIDER_DEEPSEEK = ProviderDefinition(
    id="deepseek",
    name="DeepSeek",
    default_base_url="https://api.deepseek.com/v1",
    api_key_prefix="sk-",
    models=[
        ModelInfo(id="deepseek-chat", name="DeepSeek Chat"),
        ModelInfo(id="deepseek-reasoner", name="DeepSeek Reasoner"),
    ],
)

PROVIDER_DASHSCOPE = ProviderDefinition(
    id="dashscope",
    name="Bailian (DashScope)",
    default_base_url=("https://dashscope.aliyuncs.com/compatible-mode/v1"),
    api_key_prefix="sk-",
    models=[
        ModelInfo(id="qwen-max", name="Qwen Max"),
        ModelInfo(id="qwen-plus", name="Qwen Plus"),
        ModelInfo(id="qwen-turbo", name="Qwen Turbo"),
    ],
)

PROVIDER_ZHIPU = ProviderDefinition(
    id="zhipu",
    name="Zhipu AI",
    default_base_url="https://open.bigmodel.cn/api/paas/v4",
    api_key_prefix="",
    models=[
        ModelInfo(id="glm-5", name="GLM-5"),
        ModelInfo(id="glm-4", name="GLM-4"),
        ModelInfo(id="glm-4-flash", name="GLM-4 Flash"),
        ModelInfo(id="glm-4-air", name="GLM-4 Air"),
    ],
)

PROVIDER_MOONSHOT = ProviderDefinition(
    id="moonshot",
    name="Moonshot AI",
    default_base_url="https://api.moonshot.cn/v1",
    api_key_prefix="sk-",
    models=[
        ModelInfo(id="moonshot-v1-auto", name="Moonshot v1 Auto"),
        ModelInfo(id="moonshot-v1-32k", name="Moonshot v1 32K"),
    ],
)

PROVIDER_SILICON = ProviderDefinition(
    id="silicon",
    name="SiliconFlow",
    default_base_url="https://api.siliconflow.cn/v1",
    api_key_prefix="sk-",
    models=[
        ModelInfo(
            id="deepseek-ai/DeepSeek-V3",
            name="DeepSeek V3",
        ),
        ModelInfo(
            id="Qwen/Qwen2.5-72B-Instruct",
            name="Qwen2.5 72B Instruct",
        ),
    ],
)

PROVIDER_GROQ = ProviderDefinition(
    id="groq",
    name="Groq",
    default_base_url="https://api.groq.com/openai/v1",
    api_key_prefix="gsk_",
    models=[
        ModelInfo(id="llama3-70b-8192", name="LLaMA3 70B"),
        ModelInfo(id="llama3-8b-8192", name="LLaMA3 8B"),
        ModelInfo(id="mixtral-8x7b-32768", name="Mixtral 8x7B"),
    ],
)

PROVIDER_MODELSCOPE = ProviderDefinition(
    id="modelscope",
    name="ModelScope",
    default_base_url="https://api-inference.modelscope.cn/v1",
    api_key_prefix="",
    models=[
        ModelInfo(
            id="Qwen/Qwen2.5-72B-Instruct",
            name="Qwen2.5 72B Instruct",
        ),
        ModelInfo(
            id="deepseek-ai/DeepSeek-R1",
            name="DeepSeek R1",
        ),
    ],
)

PROVIDER_TENCENT_CLOUD_TI = ProviderDefinition(
    id="tencent-cloud-ti",
    name="Tencent Cloud TI",
    default_base_url="https://api.lkeap.cloud.tencent.com/v1",
    api_key_prefix="",
    models=[
        ModelInfo(id="deepseek-r1", name="DeepSeek R1"),
        ModelInfo(id="deepseek-v3", name="DeepSeek V3"),
    ],
)

PROVIDER_OPENROUTER = ProviderDefinition(
    id="openrouter",
    name="OpenRouter",
    default_base_url="https://openrouter.ai/api/v1",
    api_key_prefix="sk-or-",
    models=[
        ModelInfo(
            id="google/gemini-2.5-flash-preview",
            name="Gemini 2.5 Flash Preview",
        ),
        ModelInfo(
            id="deepseek/deepseek-chat",
            name="DeepSeek V3",
        ),
        ModelInfo(
            id="mistralai/mistral-7b-instruct:free",
            name="Mistral 7B Instruct",
        ),
    ],
)

PROVIDER_MIMO = ProviderDefinition(
    id="mimo",
    name="Xiaomi MiMo",
    default_base_url="https://api.xiaomimimo.com/v1",
    api_key_prefix="",
    models=[
        ModelInfo(id="mimo-v2-flash", name="Mimo V2 Flash"),
    ],
)

PROVIDER_HUNYUAN = ProviderDefinition(
    id="hunyuan",
    name="Tencent Hunyuan",
    default_base_url="https://api.hunyuan.cloud.tencent.com/v1",
    api_key_prefix="",
    models=[
        ModelInfo(id="hunyuan-pro", name="Hunyuan Pro"),
        ModelInfo(id="hunyuan-turbo", name="Hunyuan Turbo"),
        ModelInfo(id="hunyuan-standard", name="Hunyuan Standard"),
        ModelInfo(id="hunyuan-lite", name="Hunyuan Lite"),
        ModelInfo(id="hunyuan-code", name="Hunyuan Code"),
        ModelInfo(id="hunyuan-vision", name="Hunyuan Vision"),
    ],
)

PROVIDER_MINIMAX = ProviderDefinition(
    id="minimax",
    name="MiniMax",
    default_base_url="https://api.minimaxi.com/v1",
    api_key_prefix="",
    models=[
        ModelInfo(id="MiniMax-M2", name="MiniMax M2"),
        ModelInfo(id="MiniMax-M2.5", name="MiniMax M2.5"),
        ModelInfo(
            id="MiniMax-M2.5-lightning",
            name="MiniMax M2.5 Lightning",
        ),
    ],
)

_BUILTIN_IDS: frozenset[str] = frozenset(
    [
        "ollama",
        "openai",
        "anthropic",
        "gemini",
        "deepseek",
        "dashscope",
        "zhipu",
        "moonshot",
        "silicon",
        "groq",
        "modelscope",
        "tencent-cloud-ti",
        "openrouter",
        "mimo",
        "hunyuan",
        "minimax",
    ],
)

PROVIDERS: dict[str, ProviderDefinition] = {
    PROVIDER_OPENAI.id: PROVIDER_OPENAI,
    PROVIDER_ANTHROPIC.id: PROVIDER_ANTHROPIC,
    PROVIDER_GEMINI.id: PROVIDER_GEMINI,
    PROVIDER_DEEPSEEK.id: PROVIDER_DEEPSEEK,
    PROVIDER_DASHSCOPE.id: PROVIDER_DASHSCOPE,
    PROVIDER_ZHIPU.id: PROVIDER_ZHIPU,
    PROVIDER_MOONSHOT.id: PROVIDER_MOONSHOT,
    PROVIDER_SILICON.id: PROVIDER_SILICON,
    PROVIDER_GROQ.id: PROVIDER_GROQ,
    PROVIDER_MODELSCOPE.id: PROVIDER_MODELSCOPE,
    PROVIDER_TENCENT_CLOUD_TI.id: PROVIDER_TENCENT_CLOUD_TI,
    PROVIDER_OPENROUTER.id: PROVIDER_OPENROUTER,
    PROVIDER_MIMO.id: PROVIDER_MIMO,
    PROVIDER_HUNYUAN.id: PROVIDER_HUNYUAN,
    PROVIDER_MINIMAX.id: PROVIDER_MINIMAX,
    PROVIDER_OLLAMA.id: PROVIDER_OLLAMA,
}

# Enrich built-in model lists with metadata from model_templates.json
for _pid, _defn in PROVIDERS.items():
    if not _defn.is_custom and _defn.models:
        _defn.models = [_apply_template(m, _pid) for m in _defn.models]

_VALID_ID_RE = re.compile(r"^[a-z][a-z0-9_-]{0,63}$")


def get_provider(provider_id: str) -> Optional[ProviderDefinition]:
    return PROVIDERS.get(provider_id)


def get_provider_chat_model(
    provider_id: str,
    providers_data: Optional[ProvidersData] = None,
) -> str:
    """Get chat model name for a provider, checking JSON settings first.

    Args:
        provider_id: Provider identifier.
        providers_data: Optional ProvidersData. If None, will load from JSON.

    Returns:
        Chat model class name, defaults to "OpenAIChatModel".
    """
    if providers_data is None:
        from .store import load_providers_json

        providers_data = load_providers_json()

    entry = providers_data.providers.get(provider_id)
    if entry and entry.chat_model:
        return entry.chat_model

    provider_def = get_provider(provider_id)
    if provider_def:
        return provider_def.chat_model

    return "OpenAIChatModel"


def list_providers() -> List[ProviderDefinition]:
    return list(PROVIDERS.values())


def is_builtin(provider_id: str) -> bool:
    return provider_id in _BUILTIN_IDS


def _custom_data_to_definition(cpd: CustomProviderData) -> ProviderDefinition:
    return ProviderDefinition(
        id=cpd.id,
        name=cpd.name,
        default_base_url=cpd.default_base_url,
        api_key_prefix=cpd.api_key_prefix,
        models=list(cpd.models),
        is_custom=True,
        chat_model=cpd.chat_model,
    )


def validate_custom_provider_id(provider_id: str) -> Optional[str]:
    """Return an error message if invalid, or None if valid."""
    if provider_id in _BUILTIN_IDS:
        return f"'{provider_id}' is a built-in provider id and cannot be used."
    if not _VALID_ID_RE.match(provider_id):
        return (
            f"Invalid provider id '{provider_id}'. "
            "Must start with a lowercase letter and contain only "
            "lowercase letters, digits, hyphens, and underscores "
            "(max 64 chars)."
        )
    return None


def register_custom_provider(cpd: CustomProviderData) -> ProviderDefinition:
    err = validate_custom_provider_id(cpd.id)
    if err:
        raise ValueError(err)
    defn = _custom_data_to_definition(cpd)
    PROVIDERS[cpd.id] = defn
    return defn


def unregister_custom_provider(provider_id: str) -> None:
    if provider_id in _BUILTIN_IDS:
        raise ValueError(f"Cannot remove built-in provider '{provider_id}'.")
    PROVIDERS.pop(provider_id, None)


def sync_custom_providers(
    custom_providers: dict[str, CustomProviderData],
) -> None:
    """Synchronise the in-memory registry with persisted custom providers."""
    stale = [
        pid
        for pid, defn in PROVIDERS.items()
        if defn.is_custom and pid not in custom_providers
    ]
    for pid in stale:
        del PROVIDERS[pid]
    for cpd in custom_providers.values():
        PROVIDERS[cpd.id] = _custom_data_to_definition(cpd)


def sync_ollama_models() -> None:
    """Refresh Ollama provider model list from the Ollama daemon.

    Models are derived from ``ollama.list()`` via :class:`OllamaModelManager`.
    If the SDK is not installed or the daemon is unavailable, the list is
    left unchanged.

    This function **never** triggers an automatic SDK installation.
    """
    try:
        from ..providers.ollama_manager import is_ollama_sdk_available

        if not is_ollama_sdk_available():
            # SDK not installed — leave model list as-is, no side-effects.
            return

        from ..providers.ollama_manager import OllamaModelManager

        models: list[ModelInfo] = []
        for model in OllamaModelManager.list_models():
            models.append(ModelInfo(id=model.name, name=model.name))
        PROVIDER_OLLAMA.models = models
    except ImportError:
        # Ollama SDK not installed; treat as having no models
        PROVIDER_OLLAMA.models = []
    except Exception:
        # Any other error (e.g. daemon not running) — keep previous list.
        pass


# ---------------------------------------------------------------------------
# LangChain model class mapping (used by the LangGraph model factory)
# ---------------------------------------------------------------------------

# Lazily populated on first call to avoid ImportError when optional
# LangChain provider packages are not installed.
_LANGCHAIN_MODEL_MAP: dict[str, type] | None = None


def _build_langchain_map() -> dict[str, type]:
    """Build the LangChain ChatModel class mapping (lazy, once)."""
    from langchain_openai import ChatOpenAI

    mapping: dict[str, type] = {
        # The default — covers OpenAI and any OpenAI-compatible API
        "OpenAIChatModel": ChatOpenAI,
        "ChatOpenAI": ChatOpenAI,
    }

    # Optional providers — only registered when their package is installed
    try:
        from langchain_anthropic import ChatAnthropic

        mapping["ChatAnthropic"] = ChatAnthropic
    except ImportError:
        pass

    try:
        from langchain_google_genai import ChatGoogleGenerativeAI

        mapping["ChatGoogleGenerativeAI"] = ChatGoogleGenerativeAI
    except ImportError:
        pass

    try:
        from langchain_ollama import ChatOllama

        mapping["ChatOllama"] = ChatOllama
    except ImportError:
        pass

    try:
        from langchain_openai import AzureChatOpenAI

        mapping["AzureChatOpenAI"] = AzureChatOpenAI
    except ImportError:
        pass

    return mapping


def get_langchain_model_class(chat_model_name: str) -> type:
    """Return the LangChain ``BaseChatModel`` subclass for *chat_model_name*.

    Falls back to ``ChatOpenAI`` when the name is unknown or the
    corresponding package is not installed.
    """
    global _LANGCHAIN_MODEL_MAP  # noqa: PLW0603
    if _LANGCHAIN_MODEL_MAP is None:
        _LANGCHAIN_MODEL_MAP = _build_langchain_map()

    from langchain_openai import ChatOpenAI

    return _LANGCHAIN_MODEL_MAP.get(chat_model_name, ChatOpenAI)
