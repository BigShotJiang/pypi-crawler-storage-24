# -*- coding: utf-8 -*-
"""Pydantic data models for providers and models."""

from __future__ import annotations

from typing import TYPE_CHECKING, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

if TYPE_CHECKING:
    pass


class ModelCost(BaseModel):
    """Cost metadata for a model (per 1M tokens)."""

    model_config = ConfigDict(populate_by_name=True)

    input: float = Field(default=0.0)
    output: float = Field(default=0.0)
    cache_read: float = Field(default=0.0, alias="cacheRead")
    cache_write: float = Field(default=0.0, alias="cacheWrite")


class ModelInfo(BaseModel):
    """Model identifier with optional openclaw-compatible metadata."""

    model_config = ConfigDict(populate_by_name=True)

    id: str = Field(..., description="Model identifier used in API calls")
    name: str = Field(..., description="Human-readable model name")
    enabled: bool = Field(
        default=True,
        description="Whether the model is enabled for use",
    )
    # Optional extended metadata (compatible with openclaw.json)
    context_window: Optional[int] = Field(
        default=None,
        alias="contextWindow",
        description="Maximum context window in tokens",
    )
    max_tokens: Optional[int] = Field(
        default=None,
        alias="maxTokens",
        description="Maximum output tokens",
    )
    reasoning: Optional[bool] = Field(
        default=None,
        description="Whether the model supports reasoning/thinking mode",
    )
    input: Optional[List[str]] = Field(
        default=None,
        description="Supported input modalities, e.g. ['text', 'image']",
    )
    cost: Optional[ModelCost] = Field(
        default=None,
        description="Cost per 1M tokens",
    )


class ProviderDefinition(BaseModel):
    """Static definition of a provider (built-in or custom)."""

    id: str = Field(..., description="Provider identifier")
    name: str = Field(..., description="Human-readable provider name")
    default_base_url: str = Field(
        default="",
        description="Default API base URL",
    )
    api_key_prefix: str = Field(
        default="",
        description="Expected prefix for the API key",
    )
    models: List[ModelInfo] = Field(
        default_factory=list,
        description="Built-in LLM model list",
    )
    is_custom: bool = Field(default=False)
    chat_model: str = Field(
        default="OpenAIChatModel",
        description="Chat model class name (e.g., 'OpenAIChatModel')",
    )


class ProviderEntry(BaseModel):
    """Unified storage for both built-in and custom providers in providers.json.

    Replaces the old split of ``ProviderSettings`` (built-in) +
    ``CustomProviderData`` (custom) with a single flat structure compatible
    with openclaw.json's ``models.providers`` format.
    """

    model_config = ConfigDict(populate_by_name=True)

    base_url: str = Field(default="", alias="baseUrl")
    api_key: str = Field(default="", alias="apiKey")
    # Built-in providers: user-added models beyond the built-in list
    extra_models: List[ModelInfo] = Field(default_factory=list, alias="extraModels")
    chat_model: str = Field(
        default="",
        alias="chatModel",
        description="Chat model class name override. Empty = use ProviderDefinition default.",
    )
    # Custom provider-only fields (None for built-in providers)
    name: Optional[str] = Field(default=None)
    default_base_url: Optional[str] = Field(default=None, alias="defaultBaseUrl")
    api_key_prefix: Optional[str] = Field(default=None, alias="apiKeyPrefix")
    is_custom: bool = Field(default=False, alias="isCustom")
    models: List[ModelInfo] = Field(
        default_factory=list,
        description="Full model list (custom providers only)",
    )
    # openclaw compatibility: API protocol type, e.g. "openai-completions"
    api: Optional[str] = Field(default=None)


# ---------------------------------------------------------------------------
# Legacy models kept for migration purposes only
# ---------------------------------------------------------------------------


class ProviderSettings(BaseModel):
    """Per-provider settings stored in providers.json (built-in only).

    DEPRECATED: Used only for reading legacy providers.json files.
    New code should use ``ProviderEntry``.
    """

    base_url: str = Field(default="")
    api_key: str = Field(default="")
    extra_models: List[ModelInfo] = Field(default_factory=list)
    chat_model: str = Field(
        default="",
        description="Chat model class name (e.g., 'OpenAIChatModel'). "
        "If empty, uses ProviderDefinition default.",
    )


class CustomProviderData(BaseModel):
    """Persisted definition + runtime config of a user-created custom provider.

    DEPRECATED: Used only for reading legacy providers.json files.
    New code should use ``ProviderEntry``.
    """

    id: str = Field(..., description="Provider identifier (unique)")
    name: str = Field(..., description="Human-readable provider name")
    default_base_url: str = Field(default="")
    api_key_prefix: str = Field(default="")
    models: List[ModelInfo] = Field(default_factory=list)
    base_url: str = Field(default="")
    api_key: str = Field(default="")
    chat_model: str = Field(
        default="OpenAIChatModel",
        description="Chat model class name (e.g., 'OpenAIChatModel')",
    )


class ModelSlotConfig(BaseModel):
    """Internal convenience model for (provider_id, model) pairs.

    Not stored in JSON directly; the JSON uses a ``"provider/model"`` string.
    """

    provider_id: str = Field(default="")
    model: str = Field(default="")


# ---------------------------------------------------------------------------
# Top-level providers.json structure
# ---------------------------------------------------------------------------


class ProvidersData(BaseModel):
    """Top-level structure of providers.json.

    Uses a flat ``providers`` dict compatible with openclaw.json's
    ``models.providers`` format. The active LLM is stored as a
    ``"provider-id/model-id"`` string (``activeLlm``).
    """

    model_config = ConfigDict(populate_by_name=True)

    providers: Dict[str, ProviderEntry] = Field(default_factory=dict)
    active_llm: str = Field(
        default="",
        alias="activeLlm",
        description="Active LLM as 'provider-id/model-id' string",
    )

    def parse_active_llm(self) -> tuple[str, str]:
        """Parse ``'provider/model'`` → ``(provider_id, model)``."""
        if not self.active_llm:
            return "", ""
        pid, _, model = self.active_llm.partition("/")
        return pid, model

    def format_active_llm(self, provider_id: str, model: str) -> str:
        """Format ``(provider_id, model)`` → ``'provider/model'`` string."""
        if provider_id and model:
            return f"{provider_id}/{model}"
        return ""

    def get_credentials(self, provider_id: str) -> tuple[str, str]:
        """Return ``(base_url, api_key)`` for *provider_id*."""
        entry = self.providers.get(provider_id)
        if entry is None:
            return "", ""
        base = entry.base_url or (entry.default_base_url or "")
        return base, entry.api_key

    def is_configured(self, defn: "ProviderDefinition") -> bool:
        """Return True if the provider has sufficient credentials configured.

        Custom providers need a base_url; built-in providers need an api_key.
        The special built-in provider ``ollama`` is always considered configured.
        """
        if defn.id == "ollama":
            return True
        entry = self.providers.get(defn.id)
        if entry is None:
            return False
        if entry.is_custom:
            return bool(entry.base_url or entry.default_base_url)
        return bool(entry.base_url) if defn.is_custom else bool(entry.api_key)


# ---------------------------------------------------------------------------
# API response models (unchanged — contract with dashboard)
# ---------------------------------------------------------------------------


class ProviderInfo(BaseModel):
    """Provider info returned by API."""

    id: str
    name: str
    api_key_prefix: str
    models: List[ModelInfo] = Field(default_factory=list)
    extra_models: List[ModelInfo] = Field(default_factory=list)
    is_custom: bool = Field(default=False)
    has_api_key: bool = Field(default=False)
    current_api_key: str = Field(default="")
    current_base_url: str = Field(default="")


class ActiveModelsInfo(BaseModel):
    active_llm: ModelSlotConfig


class ResolvedModelConfig(BaseModel):
    model: str = Field(default="")
    base_url: str = Field(default="")
    api_key: str = Field(default="")
    provider_id: str = Field(
        default="",
        description="Provider identifier, used to look up the chat_model class.",
    )


class ResolvedModelInfo(ResolvedModelConfig):
    """Resolved model configuration plus metadata used for auto-routing."""

    provider_name: str = Field(default="")
    name: str = Field(default="")
    context_window: Optional[int] = Field(
        default=None,
        alias="contextWindow",
    )
    max_tokens: Optional[int] = Field(
        default=None,
        alias="maxTokens",
    )
    reasoning: Optional[bool] = Field(default=None)
    input: Optional[List[str]] = Field(default=None)
    cost: Optional[ModelCost] = Field(default=None)


class ResolvedModelPublic(BaseModel):
    """Sanitised view of a resolved model for the dashboard (no secrets)."""

    model_config = ConfigDict(populate_by_name=True)

    provider_id: str = Field(default="")
    provider_name: str = Field(default="")
    model: str = Field(default="")
    name: str = Field(default="")
    context_window: Optional[int] = Field(default=None, alias="contextWindow")
    max_tokens: Optional[int] = Field(default=None, alias="maxTokens")
    reasoning: Optional[bool] = Field(default=None)
    input: Optional[List[str]] = Field(default=None)
    cost: Optional[ModelCost] = Field(default=None)

    @classmethod
    def from_resolved(cls, r: "ResolvedModelInfo") -> "ResolvedModelPublic":
        return cls(
            provider_id=r.provider_id,
            provider_name=r.provider_name,
            model=r.model,
            name=r.name,
            context_window=r.context_window,
            max_tokens=r.max_tokens,
            reasoning=r.reasoning,
            input=list(r.input) if r.input else None,
            cost=r.cost,
        )
