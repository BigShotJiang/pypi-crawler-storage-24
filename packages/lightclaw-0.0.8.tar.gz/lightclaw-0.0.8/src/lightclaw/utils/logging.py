# -*- coding: utf-8 -*-
import logging
import os
import platform
import sys
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path


_LEVEL_MAP = {
    "critical": logging.CRITICAL,
    "error": logging.ERROR,
    "warning": logging.WARNING,
    "info": logging.INFO,
    "debug": logging.DEBUG,
}

# Top-level name for this package; only loggers under this name are shown.
LOG_NAMESPACE = "lightclaw"


def _enable_windows_ansi() -> None:
    """Enable ANSI escape code support on Windows 10+."""
    if platform.system() != "Windows":
        return
    try:
        import ctypes

        kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
        # STD_OUTPUT_HANDLE = -11, ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004
        handle = kernel32.GetStdHandle(-11)
        mode = ctypes.c_ulong()
        kernel32.GetConsoleMode(handle, ctypes.byref(mode))
        kernel32.SetConsoleMode(handle, mode.value | 0x0004)
    except Exception:
        pass


# Call once at import time
_enable_windows_ansi()


class ColorFormatter(logging.Formatter):
    COLORS = {
        logging.DEBUG: "\033[34m",
        logging.INFO: "\033[32m",
        logging.WARNING: "\033[33m",
        logging.ERROR: "\033[31m",
        logging.CRITICAL: "\033[41m\033[97m",
    }
    RESET = "\033[0m"

    def format(self, record):
        # Disable colors if output is not a terminal (e.g. piped/redirected)
        use_color = hasattr(sys.stderr, "isatty") and sys.stderr.isatty()
        color = self.COLORS.get(record.levelno, "") if use_color else ""
        reset = self.RESET if use_color else ""
        level = f"{color}{record.levelname}{reset}"

        full_path = record.pathname
        cwd = os.getcwd()
        # Use os.path for cross-platform path prefix stripping
        try:
            if os.path.commonpath([full_path, cwd]) == cwd:
                full_path = os.path.relpath(full_path, cwd)
        except ValueError:
            # Different drives on Windows (e.g., C: vs D:) are not comparable.
            pass

        prefix = f"{level} {full_path}:{record.lineno}"
        original_msg = super().format(record)

        return f"{prefix} | {original_msg}"


class PlainFormatter(logging.Formatter):
    """Plain-text formatter without ANSI colour codes — used for file output."""

    def format(self, record):
        full_path = record.pathname
        cwd = os.getcwd()
        try:
            if os.path.commonpath([full_path, cwd]) == cwd:
                full_path = os.path.relpath(full_path, cwd)
        except ValueError:
            pass

        prefix = f"{record.levelname} {full_path}:{record.lineno}"
        original_msg = super().format(record)

        return f"{prefix} | {original_msg}"


class SuppressPathAccessLogFilter(logging.Filter):
    """
    Filter out uvicorn access log lines whose message contains any of the
    given path substrings. path_substrings: list of substrings; if any
    appears in the log message, the record is suppressed.
    Empty list = allow all.
    """

    def __init__(self, path_substrings: list[str]) -> None:
        super().__init__()
        self.path_substrings = path_substrings

    def filter(self, record: logging.LogRecord) -> bool:
        if not self.path_substrings:
            return True
        try:
            msg = record.getMessage()
            return not any(s in msg for s in self.path_substrings)
        except Exception:
            return True


def setup_logger(
    level: int | str = logging.INFO,
    log_dir: Path | None = None,
) -> logging.Logger:
    """Configure logging to only output from this package (lightclaw), not deps.

    Args:
        level: Log level (int or string such as "info", "debug").
        log_dir: Directory to write daily rotating log files into.  When
            *None* (default), the value of ``LOGS_DIR`` from
            ``lightclaw.constant`` is used so that logs always land under
            ``~/.lightclaw/logs/``.  Pass ``False``-y value only if you
            explicitly want to disable file logging.
    """
    log_format = "%(asctime)s | %(message)s"
    datefmt = "%Y-%m-%d %H:%M:%S"

    if isinstance(level, str):
        level = _LEVEL_MAP.get(level.lower(), logging.INFO)

    color_formatter = ColorFormatter(log_format, datefmt)

    # Suppress third-party: root has no handler and high level.
    root = logging.getLogger()
    root.setLevel(logging.WARNING)
    root.handlers.clear()

    # Only attach handler to our namespace so only lightclaw.* logs are printed.
    logger = logging.getLogger(LOG_NAMESPACE)
    logger.setLevel(level)
    logger.propagate = False

    # ---- console handler ------------------------------------------------
    # Guard: only add if no StreamHandler is present yet (idempotent re-call).
    has_stream = any(
        isinstance(h, logging.StreamHandler) and not isinstance(h, logging.FileHandler)
        for h in logger.handlers
    )
    if not has_stream:
        stream_handler = logging.StreamHandler()
        stream_handler.setFormatter(color_formatter)
        logger.addHandler(stream_handler)

    # ---- file handler ---------------------------------------------------
    # Resolve log_dir: fall back to LOGS_DIR from constants.
    if log_dir is None:
        try:
            from ..constant import LOGS_DIR  # relative import works at runtime

            log_dir = LOGS_DIR
        except ImportError:
            log_dir = Path("~/.lightclaw/logs").expanduser()

    if log_dir:
        log_dir = Path(log_dir)
        log_dir.mkdir(parents=True, exist_ok=True)

        log_file = log_dir / "lightclaw.log"

        # Guard: skip if a FileHandler pointing to the same file already exists.
        has_file = any(
            isinstance(h, logging.FileHandler)
            and Path(h.baseFilename).resolve() == log_file.resolve()
            for h in logger.handlers
            if hasattr(h, "baseFilename")
        )
        if not has_file:
            file_handler = TimedRotatingFileHandler(
                filename=log_file,
                when="midnight",
                interval=1,
                backupCount=7,  # keep 7 days of history
                encoding="utf-8",
                delay=True,  # create file only when the first record arrives
            )
            # Archive files: lightclaw.log.YYYY-MM-DD
            file_handler.suffix = "%Y-%m-%d"
            file_handler.setFormatter(PlainFormatter(log_format, datefmt))
            logger.addHandler(file_handler)

    return logger
