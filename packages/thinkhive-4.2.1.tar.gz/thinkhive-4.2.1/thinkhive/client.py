"""
ThinkHive Python SDK - HTTP Client
Centralized HTTP client with authentication and error handling
"""

import os
import time
import requests
from typing import Optional, Dict, Any, List, TypeVar, Generic
from dataclasses import dataclass

T = TypeVar('T')

SDK_VERSION = "4.2.0"

# Retry configuration
MAX_RETRIES = 3
INITIAL_BACKOFF = 0.5  # 500ms
MAX_BACKOFF = 8.0  # 8 seconds
RETRYABLE_STATUS_CODES = {408, 429, 500, 502, 503, 504}

# Global configuration
_config = {
    "api_key": None,
    "agent_id": None,
    "endpoint": "https://app.thinkhive.ai",
    "timeout": 30,
    "max_retries": MAX_RETRIES,
}


class ThinkHiveApiError(Exception):
    """API error with status code and optional error code"""

    def __init__(self, message: str, status_code: int, code: Optional[str] = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.code = code


class ThinkHiveValidationError(Exception):
    """Validation error with field information"""

    def __init__(self, message: str, field: Optional[str] = None):
        super().__init__(message)
        self.field = field


class PermissionDeniedError(ThinkHiveApiError):
    """Permission denied (403) with context about required permissions"""

    def __init__(self, message: str, required_permission: Optional[str] = None):
        super().__init__(message, status_code=403, code="PERMISSION_DENIED")
        self.required_permission = required_permission


class AgentScopeError(ThinkHiveApiError):
    """Agent access denied - API key doesn't have access to this agent"""

    def __init__(self, message: str, agent_id: Optional[str] = None, allowed_agents: Optional[List[str]] = None):
        super().__init__(message, status_code=403, code="AGENT_SCOPE_ERROR")
        self.agent_id = agent_id
        self.allowed_agents = allowed_agents or []


class RateLimitError(ThinkHiveApiError):
    """Rate limit exceeded (429) with retry-after information"""

    def __init__(self, message: str, retry_after_ms: Optional[int] = None):
        super().__init__(message, status_code=429, code="RATE_LIMIT_EXCEEDED")
        self.retry_after_ms = retry_after_ms
        self.retry_after = retry_after_ms  # Alias for cross-SDK parity


class IpWhitelistError(ThinkHiveApiError):
    """IP address not in API key's whitelist"""

    def __init__(self, message: str, ip_address: Optional[str] = None):
        super().__init__(message, status_code=403, code="IP_WHITELIST_ERROR")
        self.ip_address = ip_address


class NotFoundError(ThinkHiveApiError):
    """Resource not found (404)"""

    def __init__(self, message: str, resource_type: Optional[str] = None, resource_id: Optional[str] = None):
        super().__init__(message, status_code=404, code="NOT_FOUND")
        self.resource_type = resource_type
        self.resource_id = resource_id


def configure(
    api_key: Optional[str] = None,
    agent_id: Optional[str] = None,
    endpoint: Optional[str] = None,
    timeout: Optional[int] = None,
    max_retries: Optional[int] = None,
    service_name: Optional[str] = None,
) -> None:
    """
    Configure the HTTP client

    Args:
        api_key: ThinkHive API key
        agent_id: Agent ID for authentication
        endpoint: API endpoint URL
        timeout: Request timeout in seconds (default: 30)
        max_retries: Maximum number of retries for transient failures (default: 3)
        service_name: Service name for tracing (default: 'my-ai-agent')
    """
    global _config

    if api_key is not None:
        _config["api_key"] = api_key
    if agent_id is not None:
        _config["agent_id"] = agent_id
    if endpoint is not None:
        _config["endpoint"] = endpoint
    if timeout is not None:
        _config["timeout"] = timeout
    if max_retries is not None:
        _config["max_retries"] = max_retries
    if service_name is not None:
        _config["service_name"] = service_name

    # Try environment variables as fallback
    if not _config["api_key"]:
        _config["api_key"] = os.getenv("THINKHIVE_API_KEY")
    if not _config["agent_id"]:
        _config["agent_id"] = os.getenv("THINKHIVE_AGENT_ID")


def get_config() -> Dict[str, Any]:
    """Get current configuration"""
    return _config.copy()


def _get_headers() -> Dict[str, str]:
    """Get authentication headers"""
    headers = {
        "Content-Type": "application/json",
        "X-SDK-Version": SDK_VERSION,
        "X-SDK-Language": "python",
    }

    if _config["api_key"]:
        headers["Authorization"] = f"Bearer {_config['api_key']}"
    elif _config["agent_id"]:
        headers["X-Agent-ID"] = _config["agent_id"]

    return headers


def _calculate_backoff(attempt: int, retry_after: Optional[float] = None) -> float:
    """Calculate backoff time for retry attempt"""
    if retry_after is not None:
        return min(retry_after, MAX_BACKOFF)
    backoff = INITIAL_BACKOFF * (2 ** attempt)
    return min(backoff, MAX_BACKOFF)


def api_request(
    method: str,
    path: str,
    body: Optional[Dict[str, Any]] = None,
    params: Optional[Dict[str, Any]] = None,
    api_version: str = "v1",
    max_retries: Optional[int] = None,
    timeout: Optional[int] = None,
) -> Dict[str, Any]:
    """
    Make an authenticated API request with retry logic

    Args:
        method: HTTP method (GET, POST, PUT, DELETE)
        path: API path (e.g., '/human-review/queue')
        body: Request body for POST/PUT
        params: Query parameters
        api_version: API version (v1 or v3). Use empty string for unversioned
            endpoints (e.g., /api/agents).
        max_retries: Override max retries for this request
        timeout: Override timeout for this request (seconds)

    Returns:
        Response JSON

    Raises:
        ThinkHiveApiError: On API errors after all retries exhausted
    """
    if api_version:
        url = f"{_config['endpoint']}/api/{api_version}{path}"
    else:
        url = f"{_config['endpoint']}/api{path}"
    headers = _get_headers()

    retries = max_retries if max_retries is not None else _config.get("max_retries", MAX_RETRIES)
    request_timeout = timeout if timeout is not None else _config.get("timeout", 30)

    last_exception: Optional[Exception] = None

    for attempt in range(retries + 1):
        try:
            response = requests.request(
                method=method,
                url=url,
                headers=headers,
                json=body,
                params=params,
                timeout=request_timeout,
            )

            # Check if response is retryable
            if response.status_code in RETRYABLE_STATUS_CODES and attempt < retries:
                # Get Retry-After header if present (for 429 responses)
                retry_after = None
                if response.status_code == 429:
                    retry_after_header = response.headers.get("Retry-After")
                    if retry_after_header:
                        try:
                            retry_after = float(retry_after_header)
                        except ValueError:
                            pass

                backoff = _calculate_backoff(attempt, retry_after)
                time.sleep(backoff)
                continue

            if not response.ok:
                try:
                    error_data = response.json()
                    message = error_data.get("message") or error_data.get("error") or f"HTTP {response.status_code}"
                    code = error_data.get("code")
                except ValueError:
                    message = response.text or f"HTTP {response.status_code}"
                    code = None

                # Raise specific error subclasses based on status code and message
                message_lower = message.lower()
                if response.status_code == 403:
                    if "scope" in message_lower or "agent" in message_lower:
                        raise AgentScopeError(
                            message,
                            agent_id=error_data.get("agentId") if isinstance(error_data, dict) else None,
                            allowed_agents=error_data.get("allowedAgents") if isinstance(error_data, dict) else None,
                        )
                    elif "ip" in message_lower or "whitelist" in message_lower:
                        raise IpWhitelistError(
                            message,
                            ip_address=error_data.get("ipAddress") if isinstance(error_data, dict) else None,
                        )
                    else:
                        raise PermissionDeniedError(
                            message,
                            required_permission=error_data.get("requiredPermission") if isinstance(error_data, dict) else None,
                        )
                elif response.status_code == 404:
                    raise NotFoundError(
                        message,
                        resource_type=error_data.get("resourceType") if isinstance(error_data, dict) else None,
                        resource_id=error_data.get("resourceId") if isinstance(error_data, dict) else None,
                    )
                elif response.status_code == 429:
                    retry_after_ms = None
                    retry_after_header = response.headers.get("Retry-After")
                    if retry_after_header:
                        try:
                            retry_after_ms = int(float(retry_after_header) * 1000)
                        except ValueError:
                            pass
                    raise RateLimitError(message, retry_after_ms=retry_after_ms)

                raise ThinkHiveApiError(message, response.status_code, code)

            # Handle 204 No Content (e.g., successful DELETE)
            if response.status_code == 204:
                return {}

            return response.json()

        except requests.exceptions.Timeout as e:
            last_exception = e
            if attempt < retries:
                backoff = _calculate_backoff(attempt)
                time.sleep(backoff)
                continue
            raise ThinkHiveApiError(f"Request timed out after {request_timeout}s", 408)

        except requests.exceptions.ConnectionError as e:
            last_exception = e
            if attempt < retries:
                backoff = _calculate_backoff(attempt)
                time.sleep(backoff)
                continue
            raise ThinkHiveApiError(f"Connection failed: {str(e)}", 503)

    # Should not reach here, but just in case
    if last_exception:
        raise ThinkHiveApiError(f"Request failed after {retries} retries: {str(last_exception)}", 500)


def api_request_with_data(
    method: str,
    path: str,
    body: Optional[Dict[str, Any]] = None,
    params: Optional[Dict[str, Any]] = None,
    api_version: str = "v1",
) -> Any:
    """
    Make an API request and extract data from response wrapper

    Args:
        method: HTTP method
        path: API path
        body: Request body
        params: Query parameters
        api_version: API version

    Returns:
        Response data
    """
    response = api_request(method, path, body, params, api_version)

    if not response.get("success", True):
        error = response.get("error", {})
        raise ThinkHiveApiError(
            error.get("message", "Unknown error"),
            500,
            error.get("code"),
        )

    return response.get("data")


def get(path: str, params: Optional[Dict[str, Any]] = None, api_version: str = "v1") -> Any:
    """Convenience method for GET requests"""
    return api_request_with_data("GET", path, params=params, api_version=api_version)


def post(path: str, body: Optional[Dict[str, Any]] = None, api_version: str = "v1") -> Any:
    """Convenience method for POST requests"""
    return api_request_with_data("POST", path, body=body, api_version=api_version)


def put(path: str, body: Optional[Dict[str, Any]] = None, api_version: str = "v1") -> Any:
    """Convenience method for PUT requests"""
    return api_request_with_data("PUT", path, body=body, api_version=api_version)


def delete(path: str, api_version: str = "v1") -> Any:
    """Convenience method for DELETE requests"""
    return api_request_with_data("DELETE", path, api_version=api_version)


def patch(path: str, body: Optional[Dict[str, Any]] = None, api_version: str = "v1") -> Any:
    """Convenience method for PATCH requests"""
    return api_request_with_data("PATCH", path, body=body, api_version=api_version)


__all__ = [
    "ThinkHiveApiError",
    "ThinkHiveValidationError",
    "PermissionDeniedError",
    "AgentScopeError",
    "RateLimitError",
    "IpWhitelistError",
    "NotFoundError",
    "configure",
    "get_config",
    "api_request",
    "api_request_with_data",
    "get",
    "post",
    "put",
    "delete",
    "patch",
]
