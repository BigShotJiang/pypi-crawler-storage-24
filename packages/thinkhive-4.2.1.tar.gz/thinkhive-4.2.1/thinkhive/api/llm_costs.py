"""
ThinkHive Python SDK - LLM Costs API
LLM cost tracking and optimization insights
"""

from typing import Optional, Dict, Any
from dataclasses import dataclass
from ..client import get


@dataclass
class CostSummary:
    """LLM cost summary"""
    total_cost: float
    total_tokens: int
    period: str
    breakdown_by_model: Dict[str, Any]

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CostSummary":
        return cls(
            total_cost=data.get("totalCost", 0.0),
            total_tokens=data.get("totalTokens", 0),
            period=data.get("period", ""),
            breakdown_by_model=data.get("breakdownByModel", {}),
        )


@dataclass
class CostBreakdown:
    """LLM cost breakdown for an agent"""
    agent_id: str
    total_cost: float
    total_tokens: int
    period: str
    by_model: Dict[str, Any]

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CostBreakdown":
        return cls(
            agent_id=data.get("agentId", ""),
            total_cost=data.get("totalCost", 0.0),
            total_tokens=data.get("totalTokens", 0),
            period=data.get("period", ""),
            by_model=data.get("byModel", {}),
        )


def get_summary(*, period: str = "30d") -> CostSummary:
    """
    Get LLM cost summary.

    Args:
        period: Time period (e.g., '7d', '30d', '90d')

    Returns:
        CostSummary with total costs and breakdown
    """
    params: Dict[str, Any] = {"period": period}
    response = get("/llm-costs/summary", params=params, api_version="")
    return CostSummary.from_dict(response)


def get_breakdown(agent_id: str, *, period: str = "30d") -> CostBreakdown:
    """
    Get LLM cost breakdown for a specific agent.

    Args:
        agent_id: The agent ID
        period: Time period (e.g., '7d', '30d', '90d')

    Returns:
        CostBreakdown with agent-specific cost data
    """
    params: Dict[str, Any] = {"period": period}
    response = get(f"/llm-costs/breakdown/{agent_id}", params=params, api_version="")
    return CostBreakdown.from_dict(response)


def get_savings() -> Dict[str, Any]:
    """
    Get LLM cost savings data.

    Returns:
        Cost savings information
    """
    return get("/llm-costs/savings", api_version="")


def get_optimization_stats() -> Dict[str, Any]:
    """
    Get LLM cost optimization statistics.

    Returns:
        Optimization statistics and recommendations
    """
    return get("/llm-costs/optimization-stats", api_version="")


def format_cost(amount: float) -> str:
    """
    Format a cost amount as a currency string.

    Args:
        amount: Cost amount in dollars

    Returns:
        Formatted cost string (e.g., '$1.23')
    """
    return f"${amount:,.2f}"


# Convenience alias for cross-SDK parity
summary = get_summary

__all__ = [
    "CostSummary",
    "CostBreakdown",
    "get_summary",
    "get_breakdown",
    "get_savings",
    "get_optimization_stats",
    "format_cost",
    "summary",
]
