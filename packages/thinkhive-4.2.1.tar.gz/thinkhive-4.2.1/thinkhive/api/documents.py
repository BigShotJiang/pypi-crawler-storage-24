"""
ThinkHive Python SDK - Documents API
Agent document management for RAG (Retrieval-Augmented Generation)
"""

from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from ..client import post, get, delete


@dataclass
class Document:
    """An agent document"""
    id: str
    agent_id: str
    file_name: str
    file_type: str
    file_size: int
    status: str
    created_at: str

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Document":
        return cls(
            id=data.get("id", ""),
            agent_id=data.get("agentId", ""),
            file_name=data.get("fileName", ""),
            file_type=data.get("fileType", ""),
            file_size=data.get("fileSize", 0),
            status=data.get("status", ""),
            created_at=data.get("createdAt", ""),
        )


def list_documents(agent_id: str) -> List[Dict[str, Any]]:
    """
    List documents for an agent.

    Args:
        agent_id: The agent ID

    Returns:
        List of documents
    """
    return get(f"/agents/{agent_id}/documents", api_version="")


def upload(
    agent_id: str,
    *,
    file_name: str,
    file_type: str,
    file_size: int,
) -> Document:
    """
    Upload a document to an agent.

    Args:
        agent_id: The agent ID
        file_name: Name of the file
        file_type: MIME type of the file
        file_size: Size of the file in bytes

    Returns:
        Document with upload details
    """
    body: Dict[str, Any] = {
        "fileName": file_name,
        "fileType": file_type,
        "fileSize": file_size,
    }

    response = post(f"/agents/{agent_id}/documents", body, api_version="")
    return Document.from_dict(response)


def delete_document(agent_id: str, doc_id: str) -> None:
    """
    Delete a document from an agent.

    Args:
        agent_id: The agent ID
        doc_id: The document ID to delete
    """
    delete(f"/agents/{agent_id}/documents/{doc_id}", api_version="")


# Convenience aliases for cross-SDK parity
list = list_documents
delete = delete_document

__all__ = [
    "Document",
    "list_documents",
    "upload",
    "delete_document",
    "list",
    "delete",
]
