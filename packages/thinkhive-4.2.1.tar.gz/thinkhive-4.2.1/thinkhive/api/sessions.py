"""
ThinkHive Python SDK - Sessions API
Trace session grouping for managing conversation sessions
"""

from typing import Optional, Dict, Any, List
from ..client import get


def list_sessions(
    agent_id: str,
    *,
    limit: int = 50,
    offset: int = 0,
) -> Dict[str, Any]:
    """
    List trace sessions for an agent.

    Args:
        agent_id: The agent ID
        limit: Maximum number of sessions to return
        offset: Offset for pagination

    Returns:
        Paginated list of sessions
    """
    params: Dict[str, Any] = {
        "agentId": agent_id,
        "limit": limit,
        "offset": offset,
    }

    return get("/traces/sessions", params=params, api_version="")


def get_session_traces(session_id: str, agent_id: str) -> Dict[str, Any]:
    """
    Get traces for a specific session.

    Args:
        session_id: The session ID
        agent_id: The agent ID

    Returns:
        List of traces in the session
    """
    params: Dict[str, Any] = {
        "agentId": agent_id,
        "sessionId": session_id,
    }

    return get("/traces", params=params, api_version="")


# Convenience alias for cross-SDK parity
list = list_sessions

__all__ = [
    "list_sessions",
    "get_session_traces",
    "list",
]
