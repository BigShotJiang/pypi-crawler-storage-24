"""
ThinkHive Python SDK - Shadow Tests API
Shadow test execution for validating proposed fixes
"""

from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from ..client import post, get, patch


@dataclass
class ShadowTest:
    """A shadow test result"""
    id: str
    fix_id: str
    agent_id: str
    test_name: str
    status: str
    created_at: str

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ShadowTest":
        return cls(
            id=data.get("id", ""),
            fix_id=data.get("fixId", ""),
            agent_id=data.get("agentId", ""),
            test_name=data.get("testName", ""),
            status=data.get("status", ""),
            created_at=data.get("createdAt", ""),
        )


def list_tests(agent_id: str) -> List[Dict[str, Any]]:
    """
    List shadow tests for an agent.

    Args:
        agent_id: The agent ID

    Returns:
        List of shadow tests
    """
    params: Dict[str, Any] = {"agentId": agent_id}
    return get("/shadow-tests", params=params, api_version="")


def get_test(test_id: str) -> Dict[str, Any]:
    """
    Get a shadow test by ID.

    Args:
        test_id: The shadow test ID

    Returns:
        Shadow test data
    """
    return get(f"/shadow-tests/{test_id}", api_version="")


def get_by_fix(fix_id: str) -> List[Dict[str, Any]]:
    """
    Get shadow tests for a specific fix.

    Args:
        fix_id: The fix ID

    Returns:
        List of shadow tests for the fix
    """
    return get(f"/fixes/{fix_id}/shadow-tests", api_version="")


def create(
    *,
    fix_id: str,
    agent_id: str,
    test_name: str,
    input_data: Dict[str, Any],
    expected_output: Dict[str, Any],
) -> ShadowTest:
    """
    Create a new shadow test.

    Args:
        fix_id: The fix ID to test
        agent_id: The agent ID
        test_name: Name of the test
        input_data: Input data for the test
        expected_output: Expected output for validation

    Returns:
        ShadowTest with created test details
    """
    body: Dict[str, Any] = {
        "fixId": fix_id,
        "agentId": agent_id,
        "testName": test_name,
        "inputData": input_data,
        "expectedOutput": expected_output,
    }

    response = post("/shadow-tests", body, api_version="")
    return ShadowTest.from_dict(response)


def update(test_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Update a shadow test.

    Args:
        test_id: The shadow test ID to update
        data: Updated test data

    Returns:
        Updated shadow test data
    """
    return patch(f"/shadow-tests/{test_id}", data, api_version="")


# Convenience alias for cross-SDK parity
list = list_tests

__all__ = [
    "ShadowTest",
    "list_tests",
    "get_test",
    "get_by_fix",
    "create",
    "update",
    "list",
]
