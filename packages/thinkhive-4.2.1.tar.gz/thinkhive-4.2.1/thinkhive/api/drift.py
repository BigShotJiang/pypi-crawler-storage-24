"""
ThinkHive Python SDK - Drift API
Drift detection for monitoring agent behavior changes over time
"""

from typing import Optional, Dict, Any
from ..client import post, get


def detect(
    agent_id: str,
    *,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Detect drift for a specific agent.

    Args:
        agent_id: The agent ID
        start_date: Start date ISO timestamp
        end_date: End date ISO timestamp

    Returns:
        Drift detection report
    """
    params: Dict[str, Any] = {}

    if start_date is not None:
        params["startDate"] = start_date
    if end_date is not None:
        params["endDate"] = end_date

    return get(f"/drift/{agent_id}", params=params, api_version="")


def detect_all() -> Dict[str, Any]:
    """
    Run drift detection across all agents.

    Returns:
        Drift detection results for all agents
    """
    return post("/drift/detect-all", api_version="")


def has_drift(report: Dict[str, Any]) -> bool:
    """
    Check if a drift report indicates drift was detected.

    Args:
        report: Drift detection report from detect()

    Returns:
        True if drift was detected
    """
    return report.get("driftDetected", False)


def get_drift_severity(report: Dict[str, Any]) -> str:
    """
    Get the severity level of detected drift.

    Args:
        report: Drift detection report from detect()

    Returns:
        Severity level string (e.g., 'none', 'low', 'medium', 'high')
    """
    return report.get("severity", "none")


__all__ = [
    "detect",
    "detect_all",
    "has_drift",
    "get_drift_severity",
]
