"""
ThinkHive Python SDK - Quality Metrics API
RAG evaluation and hallucination detection for AI agent responses
"""

from typing import Optional, Dict, Any, List, Literal
from dataclasses import dataclass, field
from ..client import get, post


# --- Dataclasses ---


@dataclass
class RAGEvaluation:
    """RAG quality evaluation scores and assessment"""
    context_relevance: float
    context_precision: float
    context_recall: float
    groundedness: float
    faithfulness: float
    answer_relevance: float
    citation_accuracy: float
    citation_completeness: float
    overall_score: float
    grade: str
    issues: List[str]
    recommendations: List[str]

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RAGEvaluation":
        return cls(
            context_relevance=data.get("contextRelevance", 0.0),
            context_precision=data.get("contextPrecision", 0.0),
            context_recall=data.get("contextRecall", 0.0),
            groundedness=data.get("groundedness", 0.0),
            faithfulness=data.get("faithfulness", 0.0),
            answer_relevance=data.get("answerRelevance", 0.0),
            citation_accuracy=data.get("citationAccuracy", 0.0),
            citation_completeness=data.get("citationCompleteness", 0.0),
            overall_score=data.get("overallScore", 0.0),
            grade=data.get("grade", ""),
            issues=data.get("issues", []),
            recommendations=data.get("recommendations", []),
        )


@dataclass
class HallucinationInstance:
    """A single detected hallucination"""
    type: str
    severity: str
    text: str
    explanation: str
    confidence: float
    suggested_fix: str

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "HallucinationInstance":
        return cls(
            type=data.get("type", ""),
            severity=data.get("severity", ""),
            text=data.get("text", ""),
            explanation=data.get("explanation", ""),
            confidence=data.get("confidence", 0.0),
            suggested_fix=data.get("suggestedFix", ""),
        )


@dataclass
class HallucinationReport:
    """Hallucination detection report for a response"""
    has_hallucinations: bool
    hallucination_score: float
    risk_level: str
    factual_claims: int
    verified_claims: int
    unverified_claims: int
    summary: str
    recommendations: List[str]
    instances: List[HallucinationInstance]

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "HallucinationReport":
        return cls(
            has_hallucinations=data.get("hasHallucinations", False),
            hallucination_score=data.get("hallucinationScore", 0.0),
            risk_level=data.get("riskLevel", ""),
            factual_claims=data.get("factualClaims", 0),
            verified_claims=data.get("verifiedClaims", 0),
            unverified_claims=data.get("unverifiedClaims", 0),
            summary=data.get("summary", ""),
            recommendations=data.get("recommendations", []),
            instances=[
                HallucinationInstance.from_dict(i)
                for i in data.get("instances", [])
            ],
        )


@dataclass
class BatchEvaluationSummary:
    """Summary of batch RAG evaluation results"""
    total_traces: int
    successful_evaluations: int
    avg_rag_score: float
    hallucination_rate: float
    grade_distribution: Dict[str, int]

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "BatchEvaluationSummary":
        return cls(
            total_traces=data.get("totalTraces", 0),
            successful_evaluations=data.get("successfulEvaluations", 0),
            avg_rag_score=data.get("avgRagScore", 0.0),
            hallucination_rate=data.get("hallucinationRate", 0.0),
            grade_distribution=data.get("gradeDistribution", {}),
        )


# --- API Functions ---


def get_rag_scores(trace_id: str) -> RAGEvaluation:
    """
    Get RAG quality scores for a trace.

    Args:
        trace_id: The trace ID to retrieve scores for

    Returns:
        RAGEvaluation with quality scores and assessment

    Example:
        >>> from thinkhive.api import quality_metrics
        >>>
        >>> evaluation = quality_metrics.get_rag_scores("trace-123")
        >>> print(f"Overall: {evaluation.overall_score}, Grade: {evaluation.grade}")
    """
    response = get(f"/quality/rag-scores/{trace_id}", api_version="v1")
    return RAGEvaluation.from_dict(response)


def get_hallucination_report(trace_id: str) -> HallucinationReport:
    """
    Get hallucination detection report for a trace.

    Args:
        trace_id: The trace ID to retrieve the report for

    Returns:
        HallucinationReport with detection results and instances

    Example:
        >>> from thinkhive.api import quality_metrics
        >>>
        >>> report = quality_metrics.get_hallucination_report("trace-123")
        >>> if report.has_hallucinations:
        ...     print(f"Found {len(report.instances)} hallucinations")
    """
    response = get(f"/quality/hallucination-report/{trace_id}", api_version="v1")
    return HallucinationReport.from_dict(response)


def evaluate_rag(
    *,
    query: str,
    response: str,
    contexts: List[str],
    agent_id: str,
) -> RAGEvaluation:
    """
    Evaluate RAG quality for a query-response pair.

    Args:
        query: The user query
        response: The agent response to evaluate
        contexts: List of context strings used to generate the response
        agent_id: The agent ID

    Returns:
        RAGEvaluation with quality scores and assessment

    Example:
        >>> from thinkhive.api import quality_metrics
        >>>
        >>> evaluation = quality_metrics.evaluate_rag(
        ...     query="What is the refund policy?",
        ...     response="Our refund policy allows returns within 30 days.",
        ...     contexts=["Refund policy: 30-day return window for all items."],
        ...     agent_id="agent-123",
        ... )
        >>> print(f"Faithfulness: {evaluation.faithfulness}")
    """
    body: Dict[str, Any] = {
        "query": query,
        "response": response,
        "contexts": contexts,
        "agentId": agent_id,
    }
    resp = post("/quality/evaluate-rag", body, api_version="v1")
    return RAGEvaluation.from_dict(resp)


def detect_hallucinations(
    *,
    response: str,
    contexts: List[str],
    agent_id: str,
) -> HallucinationReport:
    """
    Detect hallucinations in an agent response.

    Args:
        response: The agent response to check
        contexts: List of context strings the response should be grounded in
        agent_id: The agent ID

    Returns:
        HallucinationReport with detection results

    Example:
        >>> from thinkhive.api import quality_metrics
        >>>
        >>> report = quality_metrics.detect_hallucinations(
        ...     response="The product costs $49.99 and ships in 2 days.",
        ...     contexts=["Product price: $49.99. Standard shipping: 5-7 days."],
        ...     agent_id="agent-123",
        ... )
        >>> if report.has_hallucinations:
        ...     for instance in report.instances:
        ...         print(f"[{instance.severity}] {instance.text}")
    """
    body: Dict[str, Any] = {
        "response": response,
        "contexts": contexts,
        "agentId": agent_id,
    }
    resp = post("/quality/detect-hallucinations", body, api_version="v1")
    return HallucinationReport.from_dict(resp)


def get_groundedness(trace_id: str) -> Dict[str, Any]:
    """
    Get groundedness analysis for a trace.

    Args:
        trace_id: The trace ID to retrieve groundedness for

    Returns:
        Groundedness analysis data

    Example:
        >>> from thinkhive.api import quality_metrics
        >>>
        >>> result = quality_metrics.get_groundedness("trace-123")
        >>> print(f"Groundedness score: {result['score']}")
    """
    return get(f"/quality/groundedness/{trace_id}", api_version="v1")


def evaluate_batch(
    *,
    trace_ids: List[str],
    agent_id: str,
    include_hallucination: bool = False,
) -> BatchEvaluationSummary:
    """
    Evaluate RAG quality for multiple traces in batch.

    Args:
        trace_ids: List of trace IDs to evaluate
        agent_id: The agent ID
        include_hallucination: Whether to include hallucination detection

    Returns:
        BatchEvaluationSummary with aggregated results

    Example:
        >>> from thinkhive.api import quality_metrics
        >>>
        >>> summary = quality_metrics.evaluate_batch(
        ...     trace_ids=["trace-1", "trace-2", "trace-3"],
        ...     agent_id="agent-123",
        ...     include_hallucination=True,
        ... )
        >>> print(f"Avg RAG score: {summary.avg_rag_score}")
        >>> print(f"Hallucination rate: {summary.hallucination_rate}")
    """
    body: Dict[str, Any] = {
        "traceIds": trace_ids,
        "agentId": agent_id,
        "includeHallucination": include_hallucination,
    }
    resp = post("/quality/evaluate-batch", body, api_version="v1")
    return BatchEvaluationSummary.from_dict(resp)


# --- Helper Functions ---


def is_high_quality(evaluation: RAGEvaluation, *, threshold: float = 0.8) -> bool:
    """
    Check if a RAG evaluation meets a quality threshold.

    Args:
        evaluation: The RAG evaluation to check
        threshold: Minimum overall score to consider high quality (default: 0.8)

    Returns:
        True if the overall score meets or exceeds the threshold
    """
    return evaluation.overall_score >= threshold


def has_critical_hallucinations(report: HallucinationReport) -> bool:
    """
    Check if a hallucination report contains any critical-severity hallucinations.

    Args:
        report: The hallucination report to check

    Returns:
        True if any hallucination instance has critical severity
    """
    return any(
        instance.severity == "critical" for instance in report.instances
    )


def get_grade_color(grade: str) -> str:
    """
    Return a display color for a quality grade.

    Args:
        grade: The quality grade (A, B, C, D, F)

    Returns:
        Color string for display (green, blue, yellow, orange, red)
    """
    colors: Dict[str, str] = {
        "A": "green",
        "B": "blue",
        "C": "yellow",
        "D": "orange",
        "F": "red",
    }
    return colors.get(grade.upper(), "gray")


def needs_improvement(evaluation: RAGEvaluation, *, threshold: float = 0.5) -> bool:
    """
    Check if any evaluation dimension is below the improvement threshold.

    Args:
        evaluation: The RAG evaluation to check
        threshold: Minimum score per dimension (default: 0.5)

    Returns:
        True if any individual dimension score is below the threshold
    """
    dimensions = [
        evaluation.context_relevance,
        evaluation.context_precision,
        evaluation.context_recall,
        evaluation.groundedness,
        evaluation.faithfulness,
        evaluation.answer_relevance,
        evaluation.citation_accuracy,
        evaluation.citation_completeness,
    ]
    return any(score < threshold for score in dimensions)


# Convenience alias for cross-SDK parity
evaluate = evaluate_rag

__all__ = [
    "RAGEvaluation",
    "HallucinationInstance",
    "HallucinationReport",
    "BatchEvaluationSummary",
    "get_rag_scores",
    "get_hallucination_report",
    "evaluate_rag",
    "detect_hallucinations",
    "get_groundedness",
    "evaluate_batch",
    "is_high_quality",
    "has_critical_hallucinations",
    "get_grade_color",
    "needs_improvement",
    "evaluate",
]
