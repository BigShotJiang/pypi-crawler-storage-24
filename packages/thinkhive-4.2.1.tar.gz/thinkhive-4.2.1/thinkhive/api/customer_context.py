"""
ThinkHive Python SDK - Customer Context API
Helpers for managing and querying customer context data attached to runs
"""

from typing import Optional, Dict, Any, List, Literal
from dataclasses import dataclass, field
from ..client import get, post

CustomerSegment = Literal[
    "enterprise",
    "mid-market",
    "smb",
    "startup",
    "free",
]

# Segment priority mapping (lower number = higher priority)
_SEGMENT_PRIORITIES: Dict[str, int] = {
    "enterprise": 1,
    "mid-market": 2,
    "smb": 3,
    "startup": 4,
    "free": 5,
}


@dataclass
class CustomerSnapshot:
    """Point-in-time snapshot of customer context"""
    customer_id: str
    arr: Optional[float]
    health_score: Optional[float]
    segment: Optional[str]
    captured_at: str
    custom_fields: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CustomerSnapshot":
        return cls(
            customer_id=data.get("customerId", ""),
            arr=data.get("arr"),
            health_score=data.get("healthScore"),
            segment=data.get("segment"),
            captured_at=data.get("capturedAt", ""),
            custom_fields=data.get("customFields", {}),
        )


@dataclass
class CustomerTimeSeries:
    """Time-series view of customer context across multiple snapshots"""
    customer_id: str
    snapshots: List[CustomerSnapshot]
    current_arr: Optional[float]
    arr_change: Optional[float]
    avg_health_score: Optional[float]

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CustomerTimeSeries":
        snapshots_data = data.get("snapshots", [])
        return cls(
            customer_id=data.get("customerId", ""),
            snapshots=[CustomerSnapshot.from_dict(s) for s in snapshots_data],
            current_arr=data.get("currentArr"),
            arr_change=data.get("arrChange"),
            avg_health_score=data.get("avgHealthScore"),
        )


# ---------------------------------------------------------------------------
# API functions
# ---------------------------------------------------------------------------

def create_snapshot(
    *,
    customer_id: str,
    arr: Optional[float] = None,
    health_score: Optional[float] = None,
    segment: Optional[CustomerSegment] = None,
    custom_fields: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Create a customer context snapshot dict for use in run creation.

    This is a local helper that builds the ``customer_context`` payload
    accepted by :func:`thinkhive.api.runs.create`.

    Args:
        customer_id: Unique customer / account identifier
        arr: Annual recurring revenue in dollars
        health_score: Customer health score (0-100)
        segment: Customer segment
        custom_fields: Arbitrary key-value pairs

    Returns:
        Dict suitable for passing as ``customer_context`` when creating a run

    Example:
        >>> from thinkhive.api import customer_context, runs
        >>>
        >>> ctx = customer_context.create_snapshot(
        ...     customer_id="cust-42",
        ...     arr=120_000,
        ...     health_score=85,
        ...     segment="enterprise",
        ... )
        >>> run = runs.create(
        ...     agent_id="agent-1",
        ...     conversation_messages=[{"role": "user", "content": "Hi"}],
        ...     customer_context=ctx,
        ... )
    """
    snapshot: Dict[str, Any] = {
        "customerId": customer_id,
    }

    if arr is not None:
        snapshot["arr"] = arr
    if health_score is not None:
        snapshot["healthScore"] = health_score
    if segment is not None:
        snapshot["segment"] = segment
    if custom_fields is not None:
        snapshot["customFields"] = custom_fields

    return snapshot


def get_customer_runs(
    customer_id: str,
    *,
    agent_id: Optional[str] = None,
    limit: int = 50,
    offset: int = 0,
) -> Dict[str, Any]:
    """
    Get runs associated with a customer.

    Args:
        customer_id: The customer / account ID
        agent_id: Optionally filter by agent ID
        limit: Maximum number of runs to return
        offset: Offset for pagination

    Returns:
        Paginated list of runs with items, limit, offset, hasMore
    """
    params: Dict[str, Any] = {
        "customerId": customer_id,
        "limit": limit,
        "offset": offset,
    }

    if agent_id is not None:
        params["agentId"] = agent_id

    return get("/customers/runs", params=params, api_version="v3")


def get_customer_impact(
    customer_id: str,
    *,
    agent_id: Optional[str] = None,
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Get impact analysis for a customer.

    Args:
        customer_id: The customer / account ID
        agent_id: Optionally filter by agent ID
        from_date: Start date ISO timestamp
        to_date: End date ISO timestamp

    Returns:
        Dict with impact analysis including failure rates, outcome breakdown,
        and financial impact metrics
    """
    params: Dict[str, Any] = {
        "customerId": customer_id,
    }

    if agent_id is not None:
        params["agentId"] = agent_id
    if from_date is not None:
        params["from"] = from_date
    if to_date is not None:
        params["to"] = to_date

    return get("/customers/impact", params=params, api_version="v3")


def calculate_arr_at_risk(
    customer_id: str,
    *,
    agent_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Calculate ARR at risk from failed runs for a customer.

    Args:
        customer_id: The customer / account ID
        agent_id: Optionally filter by agent ID

    Returns:
        Dict with arrAtRisk, failedRunCount, totalRunCount,
        failureRate, and riskFactors

    Example:
        >>> from thinkhive.api import customer_context
        >>>
        >>> risk = customer_context.calculate_arr_at_risk("cust-42")
        >>> print(f"ARR at risk: {customer_context.format_arr(risk['arrAtRisk'])}")
    """
    body: Dict[str, Any] = {
        "customerId": customer_id,
    }

    if agent_id is not None:
        body["agentId"] = agent_id

    return post("/customers/arr-at-risk", body, api_version="v3")


# ---------------------------------------------------------------------------
# Helper functions (pure / local — no API calls)
# ---------------------------------------------------------------------------

def is_high_value_customer(
    snapshot: CustomerSnapshot,
    *,
    arr_threshold: float = 100_000,
) -> bool:
    """
    Check if a customer is high value based on ARR.

    Args:
        snapshot: Customer context snapshot
        arr_threshold: ARR threshold in dollars (default $100,000)

    Returns:
        True if the customer's ARR meets or exceeds the threshold
    """
    if snapshot.arr is None:
        return False
    return snapshot.arr >= arr_threshold


def is_at_risk(
    snapshot: CustomerSnapshot,
    *,
    health_threshold: float = 50,
) -> bool:
    """
    Check if a customer is at risk based on health score.

    Args:
        snapshot: Customer context snapshot
        health_threshold: Health score threshold (default 50)

    Returns:
        True if the customer's health score is below the threshold
    """
    if snapshot.health_score is None:
        return False
    return snapshot.health_score < health_threshold


def get_segment_priority(segment: CustomerSegment) -> int:
    """
    Return a numeric priority for a customer segment.

    Lower numbers indicate higher priority:
        enterprise=1, mid-market=2, smb=3, startup=4, free=5

    Args:
        segment: Customer segment value

    Returns:
        Priority number (1-5). Returns 99 for unknown segments.
    """
    return _SEGMENT_PRIORITIES.get(segment, 99)


def format_arr(arr: float) -> str:
    """
    Format an ARR value as a US-dollar currency string.

    Args:
        arr: Annual recurring revenue in dollars

    Returns:
        Formatted string, e.g. ``"$50,000"``

    Example:
        >>> from thinkhive.api.customer_context import format_arr
        >>> format_arr(125000)
        '$125,000'
        >>> format_arr(1234567.89)
        '$1,234,568'
    """
    return f"${arr:,.0f}"


# Convenience alias for cross-SDK parity
capture = create_snapshot

__all__ = [
    # Types
    "CustomerSegment",
    # Dataclasses
    "CustomerSnapshot",
    "CustomerTimeSeries",
    # API functions
    "create_snapshot",
    "get_customer_runs",
    "get_customer_impact",
    "calculate_arr_at_risk",
    # Helpers
    "is_high_value_customer",
    "is_at_risk",
    "get_segment_priority",
    "format_arr",
    # Aliases
    "capture",
]
