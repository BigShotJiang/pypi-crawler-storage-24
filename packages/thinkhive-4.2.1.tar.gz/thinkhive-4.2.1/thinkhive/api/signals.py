"""
ThinkHive Python SDK - Signals API
Behavioral signal management for detecting patterns in agent interactions
"""

from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from ..client import post, get, put, delete


@dataclass
class Signal:
    """A behavioral signal definition"""
    id: str
    name: str
    group: str
    description: Optional[str]
    is_enabled: bool
    detection_config: Dict[str, Any]
    created_at: str

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Signal":
        return cls(
            id=data.get("id", ""),
            name=data.get("name", ""),
            group=data.get("group", ""),
            description=data.get("description"),
            is_enabled=data.get("isEnabled", True),
            detection_config=data.get("detectionConfig", {}),
            created_at=data.get("createdAt", ""),
        )


def list_signals(
    *,
    group: Optional[str] = None,
    source: Optional[str] = None,
    is_enabled: Optional[bool] = None,
) -> List[Dict[str, Any]]:
    """
    List behavioral signals.

    Args:
        group: Filter by signal group
        source: Filter by signal source
        is_enabled: Filter by enabled/disabled status

    Returns:
        List of signals
    """
    params: Dict[str, Any] = {}

    if group is not None:
        params["group"] = group
    if source is not None:
        params["source"] = source
    if is_enabled is not None:
        params["isEnabled"] = is_enabled

    return get("/signals/", params=params, api_version="v1")


def create(
    *,
    name: str,
    group: str,
    detection_config: Dict[str, Any],
    description: Optional[str] = None,
) -> Signal:
    """
    Create a new behavioral signal.

    Args:
        name: Signal name
        group: Signal group
        detection_config: Detection configuration
        description: Optional description

    Returns:
        Signal with the created signal details
    """
    body: Dict[str, Any] = {
        "name": name,
        "group": group,
        "detectionConfig": detection_config,
    }

    if description is not None:
        body["description"] = description

    response = post("/signals/", body, api_version="v1")
    return Signal.from_dict(response)


def update(
    signal_id: str,
    *,
    name: Optional[str] = None,
    description: Optional[str] = None,
    group: Optional[str] = None,
    is_enabled: Optional[bool] = None,
    detection_config: Optional[Dict[str, Any]] = None,
) -> Signal:
    """
    Update a behavioral signal.

    Args:
        signal_id: The signal ID to update
        name: New name
        description: New description
        group: New group
        is_enabled: Enable/disable the signal
        detection_config: New detection configuration

    Returns:
        Signal with updated details
    """
    body: Dict[str, Any] = {}

    if name is not None:
        body["name"] = name
    if description is not None:
        body["description"] = description
    if group is not None:
        body["group"] = group
    if is_enabled is not None:
        body["isEnabled"] = is_enabled
    if detection_config is not None:
        body["detectionConfig"] = detection_config

    response = put(f"/signals/{signal_id}", body, api_version="v1")
    return Signal.from_dict(response)


def delete_signal(signal_id: str) -> None:
    """
    Delete a behavioral signal.

    Args:
        signal_id: The signal ID to delete
    """
    delete(f"/signals/{signal_id}", api_version="v1")


def seed_defaults() -> Dict[str, Any]:
    """
    Seed default behavioral signals.

    Returns:
        Result of the seed operation
    """
    return post("/signals/seed", api_version="v1")


def get_stats(
    *,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    agent_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Get signal statistics.

    Args:
        start_date: Start date ISO timestamp
        end_date: End date ISO timestamp
        agent_id: Filter by agent ID

    Returns:
        Signal statistics
    """
    params: Dict[str, Any] = {}

    if start_date is not None:
        params["startDate"] = start_date
    if end_date is not None:
        params["endDate"] = end_date
    if agent_id is not None:
        params["agentId"] = agent_id

    return get("/signals/stats", params=params, api_version="v1")


def get_trends(
    *,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    agent_id: Optional[str] = None,
    granularity: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Get signal trends over time.

    Args:
        start_date: Start date ISO timestamp
        end_date: End date ISO timestamp
        agent_id: Filter by agent ID
        granularity: Time granularity (e.g., 'day', 'week', 'month')

    Returns:
        Signal trend data
    """
    params: Dict[str, Any] = {}

    if start_date is not None:
        params["startDate"] = start_date
    if end_date is not None:
        params["endDate"] = end_date
    if agent_id is not None:
        params["agentId"] = agent_id
    if granularity is not None:
        params["granularity"] = granularity

    return get("/signals/trends", params=params, api_version="v1")


def get_traces(
    signal_id: str,
    *,
    limit: int = 50,
    offset: int = 0,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    agent_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Get traces associated with a signal.

    Args:
        signal_id: The signal ID
        limit: Maximum number of traces to return
        offset: Offset for pagination
        start_date: Start date ISO timestamp
        end_date: End date ISO timestamp
        agent_id: Filter by agent ID

    Returns:
        Paginated list of traces for the signal
    """
    params: Dict[str, Any] = {"limit": limit, "offset": offset}

    if start_date is not None:
        params["startDate"] = start_date
    if end_date is not None:
        params["endDate"] = end_date
    if agent_id is not None:
        params["agentId"] = agent_id

    return get(f"/signals/{signal_id}/traces", params=params, api_version="v1")


def get_events(
    signal_id: str,
    *,
    limit: int = 50,
    offset: int = 0,
) -> Dict[str, Any]:
    """
    Get events for a signal.

    Args:
        signal_id: The signal ID
        limit: Maximum number of events to return
        offset: Offset for pagination

    Returns:
        Paginated list of signal events
    """
    params: Dict[str, Any] = {"limit": limit, "offset": offset}

    return get(f"/signals/{signal_id}/events", params=params, api_version="v1")


# Convenience aliases for cross-SDK parity
list = list_signals
delete = delete_signal

__all__ = [
    "Signal",
    "list_signals",
    "create",
    "update",
    "delete_signal",
    "seed_defaults",
    "get_stats",
    "get_trends",
    "get_traces",
    "get_events",
    "list",
    "delete",
]
