"""
ThinkHive Python SDK - Notifications API
Notification rules and alerts management

Usage:
    from thinkhive.api.notifications import notifications

    # List notification rules
    rules = notifications.list_rules(agent_id="agent-123")

    # Create a rule
    rule = notifications.create_rule({
        "agentId": "agent-123",
        "type": "threshold",
        "config": {"metric": "error_rate", "threshold": 0.1},
    })

    # List notifications
    notifs = notifications.list_notifications(agent_id="agent-123", unread_only=True)

    # Mark as read
    notifications.mark_as_read(notification_id="notif-456")
"""

from typing import Optional, Dict, Any, List
from ..client import get, post, patch, delete


class NotificationsClient:
    """
    Notifications API client for managing notification rules and alerts.
    """

    def list_rules(self, agent_id: str) -> List[Dict[str, Any]]:
        """
        List notification rules for an agent.

        Args:
            agent_id: The agent ID

        Returns:
            List of notification rules
        """
        params: Dict[str, Any] = {"agentId": agent_id}
        return get("/notification-rules", params=params, api_version="")

    def get_rule(
        self,
        rule_id: str,
        agent_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Get a notification rule by ID.

        Args:
            rule_id: The rule ID
            agent_id: Optional agent ID filter

        Returns:
            Notification rule data
        """
        params: Dict[str, Any] = {}
        if agent_id is not None:
            params["agentId"] = agent_id

        return get(f"/notification-rules/{rule_id}", params=params, api_version="")

    def create_rule(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create a notification rule.

        Args:
            data: Rule configuration data

        Returns:
            Created notification rule
        """
        return post("/notification-rules", data, api_version="")

    def update_rule(self, rule_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Update a notification rule.

        Args:
            rule_id: The rule ID to update
            data: Updated rule data

        Returns:
            Updated notification rule
        """
        return patch(f"/notification-rules/{rule_id}", data, api_version="")

    def delete_rule(self, rule_id: str) -> None:
        """
        Delete a notification rule.

        Args:
            rule_id: The rule ID to delete
        """
        delete(f"/notification-rules/{rule_id}", api_version="")

    def list_notifications(
        self,
        agent_id: str,
        unread_only: bool = False,
    ) -> List[Dict[str, Any]]:
        """
        List notifications for an agent.

        Args:
            agent_id: The agent ID
            unread_only: Only return unread notifications

        Returns:
            List of notifications
        """
        params: Dict[str, Any] = {"agentId": agent_id}

        if unread_only:
            params["unreadOnly"] = True

        return get("/notifications", params=params, api_version="")

    def mark_as_read(self, notification_id: str) -> Dict[str, Any]:
        """
        Mark a notification as read.

        Args:
            notification_id: The notification ID

        Returns:
            Updated notification
        """
        return patch(f"/notifications/{notification_id}/read", api_version="")

    # Convenience alias for cross-SDK parity
    list = list_notifications


# Singleton instance
notifications = NotificationsClient()

__all__ = [
    "NotificationsClient",
    "notifications",
]
