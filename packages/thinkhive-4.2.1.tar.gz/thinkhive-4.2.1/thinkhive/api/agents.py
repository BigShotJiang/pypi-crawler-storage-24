"""
Agents API Client
CRUD operations for managing AI agents

Usage:
    from thinkhive.api.agents import agents

    # List agents
    all_agents = agents.list()

    # Create agent
    agent = agents.create(
        name="Support Agent",
        description="Handles support",
        agent_type="customer_support",
    )

    # Update agent
    agents.update(agent["id"], name="Updated Agent")

    # Delete with dry-run preview
    impact = agents.delete(agent["id"], dry_run=True)
    print(f"Will delete {impact['cascadeImpact']['traces']} traces")

    # Actually delete
    agents.delete(agent["id"])
"""

from typing import Optional, List, Dict, Any, Union
from ..client import api_request, ThinkHiveValidationError

class _UnsetType:
    """Sentinel type to distinguish 'not provided' from 'explicitly None'."""
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __repr__(self):
        return '<UNSET>'

    def __bool__(self):
        return False

_UNSET = _UnsetType()


class AgentsClient:
    """
    Agents API client for managing AI agents.
    """

    def list(
        self,
        company_id: Optional[str] = None,
        department_id: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        List agents for the authenticated company.

        Args:
            company_id: Optional company ID filter
            department_id: Optional department ID filter

        Returns:
            List of agents
        """
        params = {}
        if company_id:
            params["companyId"] = company_id
        if department_id:
            params["departmentId"] = department_id

        response = api_request("GET", "/agents", params=params, api_version="")
        return response.get("data", response) if isinstance(response, dict) else response

    def get(self, agent_id: str) -> Dict[str, Any]:
        """
        Get a single agent by ID.

        Args:
            agent_id: The agent ID

        Returns:
            Agent details
        """
        if not agent_id:
            raise ThinkHiveValidationError("Agent ID is required", "agent_id")
        response = api_request("GET", f"/agents/{agent_id}", api_version="")
        return response.get("data", response) if isinstance(response, dict) else response

    def create(
        self,
        name: str,
        description: str = "",
        industry: Optional[str] = None,
        agent_type: Optional[str] = None,
        agent_owner: Optional[str] = None,
        built_in_house: Optional[bool] = None,
        department_id: Optional[str] = None,
        success_metrics: Optional[List[str]] = None,
        primary_success_metric: Optional[str] = None,
        secondary_metrics: Optional[List[str]] = None,
        connected_system: Optional[str] = None,
        auto_evaluate: Optional[bool] = None,
        evaluation_sample_rate: Optional[float] = None,
    ) -> Dict[str, Any]:
        """
        Create a new agent.

        Args:
            name: Agent name (required)
            description: Agent description
            industry: Industry category
            agent_type: Type of agent (customer_support, sales, etc.)
            agent_owner: Team/owner name
            built_in_house: Whether the agent was built in-house
            department_id: Department to assign to
            success_metrics: List of success metrics
            primary_success_metric: Primary metric to track
            secondary_metrics: Additional metrics
            connected_system: Connected CRM/platform
            auto_evaluate: Enable auto-evaluation
            evaluation_sample_rate: Percentage of traces to evaluate (0-1)

        Returns:
            Created agent
        """
        if not name:
            raise ThinkHiveValidationError("Agent name is required", "name")

        body: Dict[str, Any] = {
            "name": name,
            "description": description,
            "industry": industry or "other",
            "successMetrics": success_metrics if success_metrics is not None else [primary_success_metric or "Task Success Rate"],
        }

        if agent_type is not None:
            body["agentType"] = agent_type
        if agent_owner is not None:
            body["agentOwner"] = agent_owner
        if built_in_house is not None:
            body["builtInHouse"] = built_in_house
        if department_id is not None:
            body["departmentId"] = department_id
        if primary_success_metric is not None:
            body["primarySuccessMetric"] = primary_success_metric
        if secondary_metrics is not None:
            body["secondaryMetrics"] = secondary_metrics
        if connected_system is not None:
            body["connectedSystem"] = connected_system
        if auto_evaluate is not None:
            body["autoEvaluate"] = auto_evaluate
        if evaluation_sample_rate is not None:
            body["evaluationSampleRate"] = f"{evaluation_sample_rate:.4f}"

        response = api_request("POST", "/agents", body=body, api_version="")
        return response.get("data", response) if isinstance(response, dict) else response

    def update(
        self,
        agent_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        agent_type: Optional[str] = None,
        agent_owner: Optional[str] = None,
        built_in_house: Optional[bool] = None,
        department_id: Union[Optional[str], _UnsetType] = _UNSET,
        industry: Optional[str] = None,
        primary_success_metric: Optional[str] = None,
        secondary_metrics: Optional[List[str]] = None,
        connected_system: Optional[str] = None,
        auto_evaluate: Optional[bool] = None,
        evaluation_sample_rate: Optional[float] = None,
        is_active: Optional[bool] = None,
    ) -> Dict[str, Any]:
        """
        Update an existing agent.

        Args:
            agent_id: Agent ID to update
            name: New name
            description: New description
            agent_type: New agent type
            agent_owner: New owner
            built_in_house: Built in-house flag
            department_id: New department ID, or None to clear
            industry: New industry
            primary_success_metric: New primary metric
            secondary_metrics: New secondary metrics
            connected_system: New connected system
            auto_evaluate: Enable/disable auto-evaluation
            evaluation_sample_rate: New sample rate
            is_active: Active status

        Returns:
            Updated agent
        """
        if not agent_id:
            raise ThinkHiveValidationError("Agent ID is required", "agent_id")

        body: Dict[str, Any] = {}

        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        if agent_type is not None:
            body["agentType"] = agent_type
        if agent_owner is not None:
            body["agentOwner"] = agent_owner
        if built_in_house is not None:
            body["builtInHouse"] = built_in_house
        if department_id is not _UNSET:
            body["departmentId"] = department_id  # Can be None to clear
        if industry is not None:
            body["industry"] = industry
        if primary_success_metric is not None:
            body["primarySuccessMetric"] = primary_success_metric
        if secondary_metrics is not None:
            body["secondaryMetrics"] = secondary_metrics
        if connected_system is not None:
            body["connectedSystem"] = connected_system
        if auto_evaluate is not None:
            body["autoEvaluate"] = auto_evaluate
        if evaluation_sample_rate is not None:
            body["evaluationSampleRate"] = f"{evaluation_sample_rate:.4f}"
        if is_active is not None:
            body["isActive"] = is_active

        response = api_request("PATCH", f"/agents/{agent_id}", body=body, api_version="")
        return response.get("data", response) if isinstance(response, dict) else response

    def delete(
        self,
        agent_id: str,
        dry_run: bool = False,
    ) -> Optional[Dict[str, Any]]:
        """
        Delete an agent.

        Args:
            agent_id: Agent ID to delete
            dry_run: If True, returns cascade impact without deleting

        Returns:
            Cascade impact info if dry_run=True, None otherwise
        """
        if not agent_id:
            raise ThinkHiveValidationError("Agent ID is required", "agent_id")
        params = {"dryRun": "true"} if dry_run else None
        response = api_request("DELETE", f"/agents/{agent_id}", params=params, api_version="")

        if dry_run:
            return response.get("data", response) if isinstance(response, dict) else response
        return None

    def get_config(self, agent_id: str) -> Optional[Dict[str, Any]]:
        """
        Get agent configuration (baseline).

        Args:
            agent_id: Agent ID

        Returns:
            Agent configuration or None if not set
        """
        if not agent_id:
            raise ThinkHiveValidationError("Agent ID is required", "agent_id")
        response = api_request("GET", f"/agents/{agent_id}/config", api_version="")
        data = response.get("data") if isinstance(response, dict) else response
        return data

    def update_config(
        self,
        agent_id: str,
        name: Optional[str] = None,
        provider: Optional[str] = None,
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        system_prompt: Optional[str] = None,
        prompt_template: Optional[str] = None,
        rag_enabled: Optional[bool] = None,
        rag_config: Optional[Dict[str, Any]] = None,
        tools_enabled: Optional[bool] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """
        Create or update agent configuration.

        Args:
            agent_id: Agent ID
            name: Config name
            provider: LLM provider (openai, anthropic, etc.)
            model: Model name
            temperature: Temperature (0-2)
            max_tokens: Max tokens
            system_prompt: System prompt
            prompt_template: Prompt template with {{variables}}
            rag_enabled: Enable RAG
            rag_config: RAG configuration
            tools_enabled: Enable tools
            tools: Tool definitions

        Returns:
            Updated configuration
        """
        if not agent_id:
            raise ThinkHiveValidationError("Agent ID is required", "agent_id")

        body: Dict[str, Any] = {}

        if name is not None:
            body["name"] = name
        if provider is not None:
            body["provider"] = provider
        if model is not None:
            body["model"] = model
        if temperature is not None:
            body["temperature"] = temperature
        if max_tokens is not None:
            body["maxTokens"] = max_tokens
        if system_prompt is not None:
            body["systemPrompt"] = system_prompt
        if prompt_template is not None:
            body["promptTemplate"] = prompt_template
        if rag_enabled is not None:
            body["ragEnabled"] = rag_enabled
        if rag_config is not None:
            body["ragConfig"] = rag_config
        if tools_enabled is not None:
            body["toolsEnabled"] = tools_enabled
        if tools is not None:
            body["tools"] = tools

        response = api_request("PUT", f"/agents/{agent_id}/config", body=body, api_version="")
        return response.get("data", response) if isinstance(response, dict) else response


# Singleton instance
agents = AgentsClient()
