"""
ThinkHive Python SDK - Eval Runs API
Evaluation run management for grading agent traces
"""

from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from ..client import post, get, delete


@dataclass
class EvalRunResult:
    """Result from creating an eval run"""
    id: str
    agent_id: str
    status: str
    total_traces: int
    created_at: str

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EvalRunResult":
        return cls(
            id=data.get("id", ""),
            agent_id=data.get("agentId", ""),
            status=data.get("status", ""),
            total_traces=data.get("totalTraces", 0),
            created_at=data.get("createdAt", ""),
        )


@dataclass
class EvalRunDetail:
    """Detailed eval run information"""
    id: str
    agent_id: str
    status: str
    total_traces: int
    completed_traces: int
    passed: int
    failed: int
    created_at: str
    completed_at: Optional[str]

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EvalRunDetail":
        return cls(
            id=data.get("id", ""),
            agent_id=data.get("agentId", ""),
            status=data.get("status", ""),
            total_traces=data.get("totalTraces", 0),
            completed_traces=data.get("completedTraces", 0),
            passed=data.get("passed", 0),
            failed=data.get("failed", 0),
            created_at=data.get("createdAt", ""),
            completed_at=data.get("completedAt"),
        )


@dataclass
class CostEstimate:
    """Cost estimate for an eval run"""
    estimated_cost: float
    total_traces: int
    total_criteria: int

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CostEstimate":
        return cls(
            estimated_cost=data.get("estimatedCost", 0.0),
            total_traces=data.get("totalTraces", 0),
            total_criteria=data.get("totalCriteria", 0),
        )


def create(
    *,
    agent_id: str,
    trace_ids: Optional[List[str]] = None,
    criteria_ids: Optional[List[str]] = None,
    confidence_level: Optional[str] = None,
    use_llm: Optional[bool] = None,
) -> EvalRunResult:
    """
    Create a new evaluation run.

    Args:
        agent_id: The agent ID to evaluate
        trace_ids: Specific trace IDs to evaluate (optional)
        criteria_ids: Specific criteria IDs to use (optional)
        confidence_level: Confidence level for evaluation
        use_llm: Whether to use LLM-based grading

    Returns:
        EvalRunResult with run ID and details
    """
    body: Dict[str, Any] = {"agentId": agent_id}

    if trace_ids is not None:
        body["traceIds"] = trace_ids
    if criteria_ids is not None:
        body["criteriaIds"] = criteria_ids
    if confidence_level is not None:
        body["confidenceLevel"] = confidence_level
    if use_llm is not None:
        body["useLlm"] = use_llm

    response = post("/eval-runs", body, api_version="")
    return EvalRunResult.from_dict(response)


def get_run(run_id: str) -> EvalRunDetail:
    """
    Get an evaluation run by ID.

    Args:
        run_id: The eval run ID

    Returns:
        EvalRunDetail with full run information
    """
    response = get(f"/eval-runs/{run_id}", api_version="")
    return EvalRunDetail.from_dict(response)


def get_results(
    run_id: str,
    *,
    limit: int = 50,
    offset: int = 0,
    passed_only: bool = False,
    failed_only: bool = False,
) -> Dict[str, Any]:
    """
    Get results for an evaluation run.

    Args:
        run_id: The eval run ID
        limit: Maximum number of results to return
        offset: Offset for pagination
        passed_only: Only return passed results
        failed_only: Only return failed results

    Returns:
        Paginated list of eval results
    """
    params: Dict[str, Any] = {"limit": limit, "offset": offset}

    if passed_only:
        params["passedOnly"] = True
    if failed_only:
        params["failedOnly"] = True

    return get(f"/eval-runs/{run_id}/results", params=params, api_version="")


def list_runs(
    *,
    agent_id: Optional[str] = None,
    limit: int = 10,
) -> Dict[str, Any]:
    """
    List evaluation runs.

    Args:
        agent_id: Filter by agent ID
        limit: Maximum number of runs to return

    Returns:
        List of eval runs
    """
    params: Dict[str, Any] = {"limit": limit}

    if agent_id is not None:
        params["agentId"] = agent_id

    return get("/eval-runs", params=params, api_version="")


def estimate_cost(
    *,
    agent_id: str,
    trace_ids: Optional[List[str]] = None,
    criteria_ids: Optional[List[str]] = None,
    confidence_level: Optional[str] = None,
) -> CostEstimate:
    """
    Estimate cost for an evaluation run.

    Args:
        agent_id: The agent ID
        trace_ids: Specific trace IDs to evaluate
        criteria_ids: Specific criteria IDs to use
        confidence_level: Confidence level for evaluation

    Returns:
        CostEstimate with estimated cost and counts
    """
    body: Dict[str, Any] = {"agentId": agent_id}

    if trace_ids is not None:
        body["traceIds"] = trace_ids
    if criteria_ids is not None:
        body["criteriaIds"] = criteria_ids
    if confidence_level is not None:
        body["confidenceLevel"] = confidence_level

    response = post("/eval-runs/estimate-cost", body, api_version="")
    return CostEstimate.from_dict(response)


def get_trace_results(
    trace_id: str,
    *,
    latest: bool = True,
    include_criteria: bool = False,
) -> Dict[str, Any]:
    """
    Get evaluation results for a specific trace.

    Args:
        trace_id: The trace ID
        latest: Only return latest results
        include_criteria: Include criteria details

    Returns:
        Eval results for the trace
    """
    params: Dict[str, Any] = {}

    if latest:
        params["latest"] = True
    if include_criteria:
        params["includeCriteria"] = True

    return get(f"/eval-runs/trace/{trace_id}", params=params, api_version="")


def delete_run(run_id: str) -> None:
    """
    Delete an evaluation run.

    Args:
        run_id: The eval run ID to delete
    """
    delete(f"/eval-runs/{run_id}", api_version="")


__all__ = [
    "EvalRunResult",
    "EvalRunDetail",
    "CostEstimate",
    "create",
    "get_run",
    "get_results",
    "list_runs",
    "estimate_cost",
    "get_trace_results",
    "delete_run",
]
