"""
ThinkHive Python SDK - Ticket Linking API
Specialized helpers for linking runs to support tickets
"""

from typing import Optional, Dict, Any, List, Literal
from dataclasses import dataclass
from ..client import post, get, put

LinkMethod = Literal[
    "sdk_explicit",
    "zendesk_marker",
    "custom_field",
    "middleware_stamp",
    "session_match",
    "email_time_window",
    "manual",
]

# Confidence scores for each link method
_METHOD_CONFIDENCE: Dict[LinkMethod, float] = {
    "sdk_explicit": 1.0,
    "zendesk_marker": 1.0,
    "custom_field": 1.0,
    "middleware_stamp": 0.98,
    "session_match": 0.95,
    "email_time_window": 0.6,
    "manual": 1.0,
}

_SUPPORTED_PLATFORMS = [
    "zendesk",
    "intercom",
    "freshdesk",
    "salesforce",
    "hubspot",
    "jira",
    "servicenow",
]


@dataclass
class TicketLink:
    """Ticket linking information for a run"""
    method: LinkMethod
    ticket_id: str
    external_ticket_id: Optional[str]
    platform: Optional[str]
    confidence: float
    linked_at: str

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TicketLink":
        return cls(
            method=data.get("method", "sdk_explicit"),
            ticket_id=data.get("ticketId", ""),
            external_ticket_id=data.get("externalTicketId"),
            platform=data.get("platform"),
            confidence=data.get("confidence", 0.0),
            linked_at=data.get("linkedAt", ""),
        )


@dataclass
class LinkConfidence:
    """Maps a link method to its confidence score"""
    method: LinkMethod
    confidence: float

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "LinkConfidence":
        return cls(
            method=data.get("method", "sdk_explicit"),
            confidence=data.get("confidence", 0.0),
        )


# ============================================================================
# API FUNCTIONS
# ============================================================================


def link_run_to_ticket(
    run_id: str,
    *,
    ticket_id: str,
    method: LinkMethod = "sdk_explicit",
    platform: Optional[str] = None,
    external_ticket_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Link a run to a support ticket.

    Args:
        run_id: The run ID to link
        ticket_id: Internal ticket ID
        method: How the link was established
        platform: Ticket platform (zendesk, intercom, etc.)
        external_ticket_id: External ticket ID on the platform

    Returns:
        Updated run data with ticket linking information

    Example:
        >>> from thinkhive.api import linking
        >>>
        >>> result = linking.link_run_to_ticket(
        ...     "run-123",
        ...     ticket_id="ticket-456",
        ...     method="sdk_explicit",
        ...     platform="zendesk",
        ...     external_ticket_id="ZD-789",
        ... )
    """
    ticket_linking: Dict[str, Any] = {
        "ticketId": ticket_id,
        "method": method,
        "confidence": _METHOD_CONFIDENCE.get(method, 0.0),
    }

    if platform is not None:
        ticket_linking["platform"] = platform
    if external_ticket_id is not None:
        ticket_linking["externalTicketId"] = external_ticket_id

    return put(f"/runs/{run_id}", {"ticketLinking": ticket_linking}, api_version="v3")


def unlink_run(run_id: str) -> Dict[str, Any]:
    """
    Remove ticket link from a run.

    Args:
        run_id: The run ID to unlink

    Returns:
        Updated run data with ticket linking removed
    """
    return put(f"/runs/{run_id}", {"ticketLinking": None}, api_version="v3")


def get_linked_ticket(run_id: str) -> Optional[TicketLink]:
    """
    Get ticket linking information for a run.

    Args:
        run_id: The run ID

    Returns:
        TicketLink if the run is linked to a ticket, None otherwise
    """
    response = get(f"/runs/{run_id}", api_version="v3")
    ticket_linking = response.get("ticketLinking")

    if ticket_linking is None:
        return None

    return TicketLink.from_dict(ticket_linking)


def get_runs_for_ticket(
    ticket_id: str,
    *,
    agent_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Find all runs linked to a ticket.

    Args:
        ticket_id: The ticket ID to search for
        agent_id: Optionally filter by agent ID

    Returns:
        Paginated list of runs with items, limit, offset, hasMore

    Example:
        >>> from thinkhive.api import linking
        >>>
        >>> runs = linking.get_runs_for_ticket("ticket-456")
        >>> for run in runs.get("items", []):
        ...     print(run["id"])
    """
    params: Dict[str, Any] = {
        "ticketId": ticket_id,
    }

    if agent_id is not None:
        params["agentId"] = agent_id

    return get("/runs", params=params, api_version="v3")


def generate_zendesk_marker(run_id: str) -> str:
    """
    Generate a marker string for Zendesk integration.

    This marker can be added to Zendesk ticket fields or internal notes
    to enable automatic ticket linking via the zendesk_marker method.

    Args:
        run_id: The run ID to generate a marker for

    Returns:
        Marker string for Zendesk (e.g., 'thinkhive:run:run-123')

    Example:
        >>> from thinkhive.api import linking
        >>>
        >>> marker = linking.generate_zendesk_marker("run-123")
        >>> print(marker)
        'thinkhive:run:run-123'
    """
    return f"thinkhive:run:{run_id}"


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================


def get_method_confidence(method: LinkMethod) -> LinkConfidence:
    """
    Return the confidence score for a link method.

    Args:
        method: The link method

    Returns:
        LinkConfidence with method and confidence score
    """
    confidence = _METHOD_CONFIDENCE.get(method, 0.0)
    return LinkConfidence(method=method, confidence=confidence)


def is_high_confidence_link(link: TicketLink) -> bool:
    """
    Check if a ticket link has high confidence (>= 0.95).

    Args:
        link: The ticket link to check

    Returns:
        True if confidence >= 0.95
    """
    return link.confidence >= 0.95


def get_supported_platforms() -> List[str]:
    """
    Return list of supported ticket platforms.

    Returns:
        List of platform identifiers
    """
    return list(_SUPPORTED_PLATFORMS)


# Convenience aliases for cross-SDK parity
create = link_run_to_ticket
get_for_run = get_linked_ticket
delete = unlink_run


def stats() -> Dict[str, Any]:
    """
    Get supported platform stats.

    Returns:
        Dict with platform count and list of supported platforms
    """
    platforms = get_supported_platforms()
    return {"platform_count": len(platforms), "platforms": platforms}


def verify(
    run_id: str,
    *,
    verified: bool = True,
) -> Dict[str, Any]:
    """
    Update link verification status for a run.

    Args:
        run_id: The run ID whose link to verify
        verified: Whether the link is verified (default True)

    Returns:
        Updated run data
    """
    return put(f"/runs/{run_id}", {"ticketLinking": {"verified": verified}}, api_version="v3")


__all__ = [
    # Types
    "LinkMethod",
    # Dataclasses
    "TicketLink",
    "LinkConfidence",
    # API functions
    "link_run_to_ticket",
    "unlink_run",
    "get_linked_ticket",
    "get_runs_for_ticket",
    "generate_zendesk_marker",
    # Helper functions
    "get_method_confidence",
    "is_high_confidence_link",
    "get_supported_platforms",
    # Aliases
    "create",
    "get_for_run",
    "delete",
    "stats",
    "verify",
]
