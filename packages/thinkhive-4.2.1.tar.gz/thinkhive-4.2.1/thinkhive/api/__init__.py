"""
ThinkHive Python SDK - API Modules
"""

from .human_review import human_review
from .nondeterminism import nondeterminism
from .eval_health import eval_health
from .deterministic_graders import deterministic_graders
from .conversation_eval import conversation_eval
from .transcript_patterns import transcript_patterns
from .issues import issues
from .analyzer import analyzer
from . import traces
from . import runs
from . import claims
from . import calibration
from . import roi_analytics
from . import business_metrics
from .agents import agents
from .api_keys import api_keys
from . import quality_metrics
from . import linking
from . import customer_context
from . import eval_runs
from . import signals
from .notifications import notifications
from . import documents
from . import shadow_tests
from . import sessions
from . import drift
from . import llm_costs

# Deprecated aliases
cases = issues  # deprecated alias for issues
explainer = analyzer  # deprecated alias for analyzer

__all__ = [
    "human_review",
    "nondeterminism",
    "eval_health",
    "deterministic_graders",
    "conversation_eval",
    "transcript_patterns",
    "issues",
    "analyzer",
    "traces",
    # V3 APIs
    "runs",
    "claims",
    "calibration",
    "roi_analytics",
    "business_metrics",
    # Agents Management
    "agents",
    # API Key Management
    "api_keys",
    # Quality & Linking
    "quality_metrics",
    "linking",
    "customer_context",
    # Eval Runs
    "eval_runs",
    # Signals
    "signals",
    # Notifications
    "notifications",
    # Documents
    "documents",
    # Shadow Tests
    "shadow_tests",
    # Sessions
    "sessions",
    # Drift
    "drift",
    # LLM Costs
    "llm_costs",
    # Deprecated aliases
    "cases",
    "explainer",
]
