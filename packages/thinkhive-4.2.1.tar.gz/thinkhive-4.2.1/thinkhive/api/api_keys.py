"""
API Keys Client
Manage API keys for authentication and access control

Usage:
    from thinkhive.api.api_keys import api_keys

    # Create an API key
    key = api_keys.create(
        name="Production Key",
        scope_type="company",
        permissions=["traces:read", "agents:read"],
        environment="production",
    )

    # List all keys
    all_keys = api_keys.list_keys()

    # Test connection
    result = api_keys.test_connection()

    # Check permissions
    if has_permission(key, "traces:read"):
        print("Key can read traces")

    # Revoke a key
    api_keys.revoke(key["id"])
"""

from typing import Optional, List, Dict, Any, Literal
from datetime import datetime, timezone
from ..client import api_request, ThinkHiveValidationError

ScopeType = Literal["company", "agent", "readonly"]
Environment = Literal["production", "staging", "development"]


class ApiKeysClient:
    """
    API Keys client for managing API keys.
    """

    def create(
        self,
        *,
        name: str,
        scope_type: ScopeType = "company",
        permissions: Optional[List[str]] = None,
        environment: Environment = "production",
        allowed_agent_ids: Optional[List[str]] = None,
        allowed_ips: Optional[List[str]] = None,
        expires_at: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Create a new API key.

        Args:
            name: Display name for the key (required)
            scope_type: Access scope - 'company', 'agent', or 'readonly'
            permissions: List of permission strings (e.g., ['traces:read', 'agents:write'])
            environment: Target environment - 'production', 'staging', or 'development'
            allowed_agent_ids: List of agent IDs this key can access (for 'agent' scope)
            allowed_ips: List of allowed IP addresses for key usage
            expires_at: ISO 8601 expiration timestamp

        Returns:
            Created API key including the secret (only shown once)
        """
        if not name:
            raise ThinkHiveValidationError("API key name is required", "name")

        body: Dict[str, Any] = {
            "name": name,
            "scopeType": scope_type,
            "environment": environment,
        }

        if permissions is not None:
            body["permissions"] = permissions
        if allowed_agent_ids is not None:
            body["allowedAgentIds"] = allowed_agent_ids
        if allowed_ips is not None:
            body["allowedIps"] = allowed_ips
        if expires_at is not None:
            body["expiresAt"] = expires_at

        response = api_request("POST", "/api-keys", body=body, api_version="v2")
        return response.get("data", response) if isinstance(response, dict) else response

    def list_keys(self) -> List[Dict[str, Any]]:
        """
        List all API keys for the authenticated company.

        Returns:
            List of API keys (secrets are masked)
        """
        response = api_request("GET", "/api-keys", api_version="v2")
        return response.get("data", response) if isinstance(response, dict) else response

    def revoke(self, key_id: str) -> None:
        """
        Revoke (delete) an API key.

        Args:
            key_id: The API key ID to revoke
        """
        if not key_id:
            raise ThinkHiveValidationError("API key ID is required", "key_id")

        api_request("DELETE", f"/api-keys/{key_id}", api_version="v2")

    def test_connection(self) -> Dict[str, Any]:
        """
        Test the current API key connection.

        Returns:
            Connection test result with status and key metadata
        """
        response = api_request("POST", "/api-keys/test", api_version="v2")
        return response.get("data", response) if isinstance(response, dict) else response

    # Convenience alias for cross-SDK parity
    list = list_keys


def has_permission(key: Dict[str, Any], permission: str) -> bool:
    """
    Check if an API key has a specific permission.

    Args:
        key: API key dict (as returned by create or list_keys)
        permission: Permission string to check (e.g., 'traces:read')

    Returns:
        True if the key has the permission
    """
    permissions = key.get("permissions") or []
    return permission in permissions


def is_expired(key: Dict[str, Any]) -> bool:
    """
    Check if an API key is expired.

    Args:
        key: API key dict (as returned by create or list_keys)

    Returns:
        True if the key has an expiration date and it has passed
    """
    expires_at = key.get("expiresAt")
    if expires_at is None:
        return False

    if isinstance(expires_at, str):
        expiry = datetime.fromisoformat(expires_at.replace("Z", "+00:00"))
    else:
        expiry = expires_at

    return datetime.now(timezone.utc) > expiry


def can_access_agent(key: Dict[str, Any], agent_id: str) -> bool:
    """
    Check if an API key can access a specific agent.

    A key can access an agent if:
    - The key has 'company' scope (access to all agents)
    - The key has 'readonly' scope (read access to all agents)
    - The key has 'agent' scope and the agent_id is in allowedAgentIds

    Args:
        key: API key dict (as returned by create or list_keys)
        agent_id: Agent ID to check access for

    Returns:
        True if the key can access the agent
    """
    scope_type = key.get("scopeType")

    if scope_type in ("company", "readonly"):
        return True

    allowed_agent_ids = key.get("allowedAgentIds") or []
    return agent_id in allowed_agent_ids


# Singleton instance
api_keys = ApiKeysClient()

__all__ = [
    "ApiKeysClient",
    "api_keys",
    "has_permission",
    "is_expired",
    "can_access_agent",
    "ScopeType",
    "Environment",
]
