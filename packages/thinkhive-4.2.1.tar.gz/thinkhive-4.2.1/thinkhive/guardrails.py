"""
ThinkHive Guardrails SDK Module
Real-time content scanning using centralized SDK configuration
"""

import time
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field

import requests

from .client import _config, _get_headers, _calculate_backoff, ThinkHiveApiError


@dataclass
class Finding:
    type: str
    value: str
    start: int
    end: int
    confidence: float
    metadata: Optional[Dict[str, Any]] = None


@dataclass
class ScannerResult:
    scanner: str
    status: str  # 'completed' | 'timeout' | 'error'
    action: str  # 'pass' | 'block' | 'redact' | 'flag'
    findings: List[Finding] = field(default_factory=list)
    latency_ms: int = 0


@dataclass
class ScanMetadata:
    scan_id: str
    total_latency_ms: int
    scanners_executed: int
    scanners_blocked: int
    scanners_flagged: int
    scanners_timed_out: int
    cached: bool


@dataclass
class ScanResponse:
    action: str
    action_reason: Optional[str] = None
    redacted_input: Optional[str] = None
    redacted_output: Optional[str] = None
    results: Dict[str, ScannerResult] = field(default_factory=dict)
    metadata: Optional[ScanMetadata] = None


def _guardrails_request(method: str, path: str, body: Optional[Dict[str, Any]] = None) -> Any:
    """Make an authenticated request to guardrails routes (outside /api/ prefix)."""
    url = f"{_config['endpoint']}{path}"
    headers = _get_headers()
    # Also set X-API-Key for guardrails routes
    if _config.get("api_key"):
        headers["X-API-Key"] = _config["api_key"]

    max_retries = _config.get("max_retries", 3)
    request_timeout = _config.get("timeout", 30)

    for attempt in range(max_retries + 1):
        try:
            response = requests.request(
                method=method,
                url=url,
                headers=headers,
                json=body,
                timeout=request_timeout,
            )

            if response.status_code in {408, 429, 500, 502, 503, 504} and attempt < max_retries:
                retry_after = None
                if response.status_code == 429:
                    ra = response.headers.get("Retry-After")
                    if ra:
                        try:
                            retry_after = float(ra)
                        except ValueError:
                            pass
                backoff = _calculate_backoff(attempt, retry_after)
                time.sleep(backoff)
                continue

            if not response.ok:
                try:
                    error_data = response.json()
                    message = error_data.get("message", f"HTTP {response.status_code}")
                except ValueError:
                    message = response.text or f"HTTP {response.status_code}"
                raise ThinkHiveApiError(message, response.status_code)

            data = response.json()
            if not data.get("success", True):
                raise ThinkHiveApiError(data.get("message", "Request failed"), 500)
            return data.get("data")

        except requests.exceptions.Timeout:
            if attempt < max_retries:
                time.sleep(_calculate_backoff(attempt))
                continue
            raise ThinkHiveApiError(f"Request timed out after {request_timeout}s", 408)

        except requests.exceptions.ConnectionError as e:
            if attempt < max_retries:
                time.sleep(_calculate_backoff(attempt))
                continue
            raise ThinkHiveApiError(f"Connection failed: {str(e)}", 503)

    raise ThinkHiveApiError("Request failed after all retries", 500)


def _parse_scan_response(data: Dict[str, Any]) -> ScanResponse:
    """Parse raw API response into ScanResponse dataclass."""
    results = {}
    for name, r in data.get("results", {}).items():
        findings = [
            Finding(
                type=f["type"],
                value=f["value"],
                start=f["start"],
                end=f["end"],
                confidence=f["confidence"],
                metadata=f.get("metadata"),
            )
            for f in r.get("findings", [])
        ]
        results[name] = ScannerResult(
            scanner=r["scanner"],
            status=r["status"],
            action=r["action"],
            findings=findings,
            latency_ms=r.get("latencyMs", 0),
        )

    meta = data.get("metadata", {})
    metadata = ScanMetadata(
        scan_id=meta.get("scanId", ""),
        total_latency_ms=meta.get("totalLatencyMs", 0),
        scanners_executed=meta.get("scannersExecuted", 0),
        scanners_blocked=meta.get("scannersBlocked", 0),
        scanners_flagged=meta.get("scannersFlagged", 0),
        scanners_timed_out=meta.get("scannersTimedOut", 0),
        cached=meta.get("cached", False),
    )

    return ScanResponse(
        action=data["action"],
        action_reason=data.get("actionReason"),
        redacted_input=data.get("redactedInput"),
        redacted_output=data.get("redactedOutput"),
        results=results,
        metadata=metadata,
    )


def scan(
    scanners: Optional[List[str]] = None,
    input: Optional[str] = None,
    output: Optional[str] = None,
    tool_call: Optional[Dict[str, Any]] = None,
    policy_id: Optional[str] = None,
    config: Optional[Dict[str, Dict[str, Any]]] = None,
    options: Optional[Dict[str, Any]] = None,
) -> ScanResponse:
    """
    Scan content for policy violations.

    Args:
        scanners: List of scanner names to run (optional if policy_id provided)
        input: Input content to scan
        output: Output content to scan
        tool_call: Tool call to scan (dict with 'name' and 'arguments')
        policy_id: Policy ID to use for scanner configuration
        config: Per-scanner configuration overrides
        options: Execution options (timeout, failOpen, shortCircuit, returnRedacted)

    Returns:
        ScanResponse with action, findings, and metadata
    """
    payload: Dict[str, Any] = {}
    if scanners is not None:
        payload["scanners"] = scanners
    if input is not None:
        payload["input"] = input
    if output is not None:
        payload["output"] = output
    if tool_call is not None:
        payload["toolCall"] = tool_call
    if policy_id is not None:
        payload["policyId"] = policy_id
    if config is not None:
        payload["config"] = config
    if options is not None:
        payload["options"] = options

    data = _guardrails_request("POST", "/v1/guardrails/scan", payload)
    return _parse_scan_response(data)


def list_scanners() -> List[Dict[str, Any]]:
    """
    List available scanners.

    Returns:
        List of scanner info dicts with 'name' and 'description'
    """
    data = _guardrails_request("GET", "/v1/guardrails/scanners")
    return data.get("scanners", [])


# Convenience alias for cross-SDK parity
evaluate = scan
