"""Tests for ThinkHive Python SDK URL construction"""
import pytest
from unittest.mock import patch, MagicMock
from thinkhive.client import configure


@pytest.fixture(autouse=True)
def setup_client():
    """Configure client before each test"""
    configure(api_key="thk_test_key_123", endpoint="https://app.thinkhive.ai")


def mock_response(status_code=200, json_data=None):
    """Create a mock response"""
    mock = MagicMock()
    mock.ok = True
    mock.status_code = status_code
    mock.json.return_value = json_data or {"success": True, "data": {}}
    return mock


def _get_url(mock_request):
    """Extract the URL from a mock_request call"""
    return mock_request.call_args.kwargs.get("url") or mock_request.call_args[1].get("url")


class TestURLConstruction:
    """Verify every module constructs correct URLs from the route map"""

    # ── traces (unversioned) ──────────────────────────────────────────

    @patch("thinkhive.client.requests.request")
    def test_traces_create(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": {
                "id": "t1",
                "agentId": "a1",
                "companyId": "c1",
                "userMessage": "hi",
                "agentResponse": "hey",
                "createdAt": "2024-01-01",
            },
        })
        from thinkhive.api import traces
        traces.create(agent_id="a1", user_message="hi", agent_response="hey")
        url = _get_url(mock_request)
        assert url == "https://app.thinkhive.ai/api/traces"
        assert "/v1/" not in url  # Should be unversioned

    # ── runs (v3) ─────────────────────────────────────────────────────

    @patch("thinkhive.client.requests.request")
    def test_runs_create(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": {
                "id": "r1",
                "agentId": "a1",
                "companyId": "c1",
                "outcome": None,
                "startedAt": "2024-01-01",
                "endedAt": None,
                "createdAt": "2024-01-01",
            },
        })
        from thinkhive.api import runs
        runs.create(
            agent_id="a1",
            conversation_messages=[{"role": "user", "content": "hi"}],
        )
        url = _get_url(mock_request)
        assert url == "https://app.thinkhive.ai/api/v3/runs"

    # ── claims (v3) ───────────────────────────────────────────────────

    @patch("thinkhive.client.requests.request")
    def test_claims_create_analysis(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": {
                "id": "an1",
                "runId": "r1",
                "analysisVersion": "1",
                "outcomeVerdict": "failure",
                "outcomeConfidence": 0.9,
                "isCurrent": True,
                "analyzedAt": "2024-01-01",
                "claims": [],
            },
        })
        from thinkhive.api import claims
        claims.create_analysis(run_id="r1", outcome_verdict="failure")
        url = _get_url(mock_request)
        assert url == "https://app.thinkhive.ai/api/v3/analyses"

    # ── calibration (v3) ──────────────────────────────────────────────

    @patch("thinkhive.client.requests.request")
    def test_calibration_get_status(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": {
                "agentId": "agent1",
                "predictionType": "outcome",
                "brierScore": 0.05,
                "ece": 0.03,
                "mce": 0.08,
                "sampleCount": 100,
                "isCalibrated": True,
                "lastUpdated": "2024-01-01",
            },
        })
        from thinkhive.api import calibration
        calibration.get_status("agent1", "outcome")
        url = _get_url(mock_request)
        assert url == "https://app.thinkhive.ai/api/v3/calibration/agent1/status"

    @patch("thinkhive.client.requests.request")
    def test_calibration_get_metrics(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": [],
        })
        from thinkhive.api import calibration
        calibration.get_metrics("agent1")
        url = _get_url(mock_request)
        assert url == "https://app.thinkhive.ai/api/v3/calibration/agent1/metrics"

    @patch("thinkhive.client.requests.request")
    def test_calibration_retrain(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": {"retrainedTypes": [], "skippedTypes": []},
        })
        from thinkhive.api import calibration
        calibration.retrain("agent1")
        url = _get_url(mock_request)
        assert url == "https://app.thinkhive.ai/api/v3/calibration/agent1/retrain"

    # ── human_review (unversioned) ────────────────────────────────────

    @patch("thinkhive.client.requests.request")
    def test_human_review_get_queue(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": [],
        })
        from thinkhive.api import human_review
        human_review.get_queue()
        url = _get_url(mock_request)
        assert url == "https://app.thinkhive.ai/api/human-review/queue"
        assert "/v1/" not in url

    # ── eval_health (unversioned) ─────────────────────────────────────

    @patch("thinkhive.client.requests.request")
    def test_eval_health_get_report(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": {"status": "healthy"},
        })
        from thinkhive.api import eval_health
        eval_health.get_report("agent1")
        url = _get_url(mock_request)
        assert url == "https://app.thinkhive.ai/api/eval-health/report"
        assert "/v1/" not in url

    # ── nondeterminism (unversioned) ──────────────────────────────────

    @patch("thinkhive.client.requests.request")
    def test_nondeterminism_create_run(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": {"id": "nd1"},
        })
        from thinkhive.api import nondeterminism
        nondeterminism.create_run(
            agent_id="a1",
            k_value=3,
            trace_ids=["t1", "t2"],
        )
        url = _get_url(mock_request)
        assert url == "https://app.thinkhive.ai/api/nondeterminism/runs"
        assert "/v1/" not in url

    # ── deterministic_graders (unversioned) ───────────────────────────

    @patch("thinkhive.client.requests.request")
    def test_deterministic_graders_evaluate(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": {"passed": True, "score": 100},
        })
        from thinkhive.api import deterministic_graders
        deterministic_graders.evaluate(trace_id="t1", criterion_id="c1")
        url = _get_url(mock_request)
        assert url == "https://app.thinkhive.ai/api/deterministic-graders/evaluate"
        assert "/v1/" not in url

    # ── conversation_eval (unversioned) ───────────────────────────────

    @patch("thinkhive.client.requests.request")
    def test_conversation_eval_get_session_traces(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": [],
        })
        from thinkhive.api import conversation_eval
        conversation_eval.get_session_traces("s1")
        url = _get_url(mock_request)
        assert url == "https://app.thinkhive.ai/api/conversation-eval/traces"
        assert "/v1/" not in url

    # ── transcript_patterns (unversioned) ─────────────────────────────

    @patch("thinkhive.client.requests.request")
    def test_transcript_patterns_analyze(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": {"riskScore": 0, "matches": [], "insights": []},
        })
        from thinkhive.api import transcript_patterns
        transcript_patterns.analyze("t1")
        url = _get_url(mock_request)
        assert url == "https://app.thinkhive.ai/api/transcript-patterns/analyze"
        assert "/v1/" not in url

    # ── issues (v2) ──────────────────────────────────────────────────

    @patch("thinkhive.client.requests.request")
    def test_issues_list(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": [],
        })
        from thinkhive.api import issues
        issues.list("agent1")
        url = _get_url(mock_request)
        assert url == "https://app.thinkhive.ai/api/v2/issues"

    # ── agents (unversioned) ─────────────────────────────────────────

    @patch("thinkhive.client.requests.request")
    def test_agents_list(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": [],
        })
        from thinkhive.api import agents
        agents.list()
        url = _get_url(mock_request)
        assert url == "https://app.thinkhive.ai/api/agents"
        assert "/v1/" not in url

    # ── roi_analytics (v1) ───────────────────────────────────────────

    @patch("thinkhive.client.requests.request")
    def test_roi_analytics_get_summary(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": {
                "summary": {
                    "dateRange": {},
                    "traceCount": 0,
                    "successfulInteractions": 0,
                    "failedInteractions": 0,
                    "successRate": 0,
                    "roi": {},
                    "revenueProtected": 0.0,
                    "estimatedSavings": 0.0,
                },
            },
        })
        from thinkhive.api import roi_analytics
        roi_analytics.get_summary()
        url = _get_url(mock_request)
        assert url == "https://app.thinkhive.ai/api/v1/analytics/roi/summary"

    @patch("thinkhive.client.requests.request")
    def test_roi_analytics_get_correlations(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": {"analysis": {}},
        })
        from thinkhive.api import roi_analytics
        roi_analytics.get_correlations()
        url = _get_url(mock_request)
        assert url == "https://app.thinkhive.ai/api/v1/analytics/roi/correlations"

    # ── business_metrics (v3) ────────────────────────────────────────

    @patch("thinkhive.client.requests.request")
    def test_business_metrics_get_current(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": {
                "metricName": "m1",
                "metricType": "trace_calculated",
                "value": 42.0,
                "valueFormatted": "42%",
                "status": "ready",
            },
        })
        from thinkhive.api import business_metrics
        business_metrics.get_current("a1", metric_name="m1")
        url = _get_url(mock_request)
        assert url == "https://app.thinkhive.ai/api/v3/agents/a1/metrics/current"


class TestHTTPMethods:
    """Verify correct HTTP methods are used for each operation"""

    @patch("thinkhive.client.requests.request")
    def test_traces_create_uses_post(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": {
                "id": "t1", "agentId": "a1", "companyId": "c1",
                "userMessage": "hi", "agentResponse": "hey",
                "createdAt": "2024-01-01",
            },
        })
        from thinkhive.api import traces
        traces.create(agent_id="a1", user_message="hi", agent_response="hey")
        method = mock_request.call_args.kwargs.get("method")
        assert method == "POST"

    @patch("thinkhive.client.requests.request")
    def test_agents_list_uses_get(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True, "data": [],
        })
        from thinkhive.api import agents
        agents.list()
        method = mock_request.call_args.kwargs.get("method")
        assert method == "GET"

    @patch("thinkhive.client.requests.request")
    def test_issues_list_uses_get(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True, "data": [],
        })
        from thinkhive.api import issues
        issues.list("agent1")
        method = mock_request.call_args.kwargs.get("method")
        assert method == "GET"

    @patch("thinkhive.client.requests.request")
    def test_calibration_retrain_uses_post(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": {"retrainedTypes": [], "skippedTypes": []},
        })
        from thinkhive.api import calibration
        calibration.retrain("agent1")
        method = mock_request.call_args.kwargs.get("method")
        assert method == "POST"

    @patch("thinkhive.client.requests.request")
    def test_transcript_patterns_analyze_uses_post(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": {"riskScore": 0, "matches": [], "insights": []},
        })
        from thinkhive.api import transcript_patterns
        transcript_patterns.analyze("t1")
        method = mock_request.call_args.kwargs.get("method")
        assert method == "POST"


class TestRequestHeaders:
    """Verify correct headers are sent with requests"""

    @patch("thinkhive.client.requests.request")
    def test_authorization_header_set(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True, "data": [],
        })
        from thinkhive.api import agents
        agents.list()
        headers = mock_request.call_args.kwargs.get("headers", {})
        assert headers.get("Authorization") == "Bearer thk_test_key_123"

    @patch("thinkhive.client.requests.request")
    def test_sdk_version_header_set(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True, "data": [],
        })
        from thinkhive.api import agents
        agents.list()
        headers = mock_request.call_args.kwargs.get("headers", {})
        from thinkhive.client import SDK_VERSION
        assert headers.get("X-SDK-Version") == SDK_VERSION

    @patch("thinkhive.client.requests.request")
    def test_sdk_language_header_set(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True, "data": [],
        })
        from thinkhive.api import agents
        agents.list()
        headers = mock_request.call_args.kwargs.get("headers", {})
        assert headers.get("X-SDK-Language") == "python"

    @patch("thinkhive.client.requests.request")
    def test_content_type_header_set(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True, "data": [],
        })
        from thinkhive.api import agents
        agents.list()
        headers = mock_request.call_args.kwargs.get("headers", {})
        assert headers.get("Content-Type") == "application/json"


class TestRequestPayloads:
    """Verify request bodies and query parameters are correctly formatted"""

    @patch("thinkhive.client.requests.request")
    def test_traces_create_body_uses_camel_case(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": {
                "id": "t1", "agentId": "a1", "companyId": "c1",
                "userMessage": "hi", "agentResponse": "hey",
                "createdAt": "2024-01-01",
            },
        })
        from thinkhive.api import traces
        traces.create(
            agent_id="a1",
            user_message="hello",
            agent_response="world",
            session_id="sess-1",
        )
        body = mock_request.call_args.kwargs.get("json", {})
        assert body["agentId"] == "a1"
        assert body["userMessage"] == "hello"
        assert body["agentResponse"] == "world"
        assert body["sessionId"] == "sess-1"

    @patch("thinkhive.client.requests.request")
    def test_runs_create_body_includes_started_at(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": {
                "id": "r1", "agentId": "a1", "companyId": "c1",
                "startedAt": "2024-01-01", "createdAt": "2024-01-01",
            },
        })
        from thinkhive.api import runs
        runs.create(
            agent_id="a1",
            conversation_messages=[{"role": "user", "content": "hi"}],
        )
        body = mock_request.call_args.kwargs.get("json", {})
        assert body["agentId"] == "a1"
        assert body["conversationMessages"] == [{"role": "user", "content": "hi"}]
        # startedAt should be auto-populated
        assert "startedAt" in body

    @patch("thinkhive.client.requests.request")
    def test_calibration_get_status_sends_prediction_type_param(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": {
                "agentId": "agent1", "predictionType": "outcome",
                "brierScore": 0.05, "ece": 0.03, "mce": 0.08,
                "sampleCount": 100, "isCalibrated": True,
                "lastUpdated": "2024-01-01",
            },
        })
        from thinkhive.api import calibration
        calibration.get_status("agent1", "outcome")
        params = mock_request.call_args.kwargs.get("params", {})
        assert params["predictionType"] == "outcome"

    @patch("thinkhive.client.requests.request")
    def test_issues_list_sends_agent_id_param(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True, "data": [],
        })
        from thinkhive.api import issues
        issues.list("agent1")
        params = mock_request.call_args.kwargs.get("params", {})
        assert params["agentId"] == "agent1"

    @patch("thinkhive.client.requests.request")
    def test_eval_health_report_sends_agent_id_param(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True, "data": {},
        })
        from thinkhive.api import eval_health
        eval_health.get_report("agent1")
        params = mock_request.call_args.kwargs.get("params", {})
        assert params["agentId"] == "agent1"

    @patch("thinkhive.client.requests.request")
    def test_nondeterminism_create_run_body(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True, "data": {"id": "nd1"},
        })
        from thinkhive.api import nondeterminism
        nondeterminism.create_run(
            agent_id="a1",
            k_value=5,
            trace_ids=["t1", "t2", "t3"],
            run_type="pass_at_k",
        )
        body = mock_request.call_args.kwargs.get("json", {})
        assert body["agentId"] == "a1"
        assert body["kValue"] == 5
        assert body["traceIds"] == ["t1", "t2", "t3"]
        assert body["runType"] == "pass_at_k"

    @patch("thinkhive.client.requests.request")
    def test_deterministic_graders_evaluate_body(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True, "data": {"passed": True, "score": 100},
        })
        from thinkhive.api import deterministic_graders
        deterministic_graders.evaluate(trace_id="t1", criterion_id="c1")
        body = mock_request.call_args.kwargs.get("json", {})
        assert body["traceId"] == "t1"
        assert body["criterionId"] == "c1"

    @patch("thinkhive.client.requests.request")
    def test_transcript_patterns_analyze_body(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": {"riskScore": 0, "matches": [], "insights": []},
        })
        from thinkhive.api import transcript_patterns
        transcript_patterns.analyze("t1")
        body = mock_request.call_args.kwargs.get("json", {})
        assert body["traceId"] == "t1"

    @patch("thinkhive.client.requests.request")
    def test_business_metrics_get_current_sends_metric_name_param(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": {
                "metricName": "Deflection Rate",
                "metricType": "trace_calculated",
                "status": "ready",
                "valueFormatted": "42%",
            },
        })
        from thinkhive.api import business_metrics
        business_metrics.get_current("a1", metric_name="Deflection Rate")
        params = mock_request.call_args.kwargs.get("params", {})
        assert params["metricName"] == "Deflection Rate"


class TestResponseParsing:
    """Verify response data is correctly parsed into dataclasses"""

    @patch("thinkhive.client.requests.request")
    def test_traces_create_returns_trace_result(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": {
                "id": "trace-abc",
                "agentId": "a1",
                "companyId": "c1",
                "userMessage": "hello",
                "agentResponse": "world",
                "outcome": "success",
                "_evaluationQueued": True,
                "createdAt": "2024-01-01T00:00:00Z",
            },
        })
        from thinkhive.api import traces
        from thinkhive.api.traces import TraceResult
        result = traces.create(agent_id="a1", user_message="hello", agent_response="world")
        assert isinstance(result, TraceResult)
        assert result.id == "trace-abc"
        assert result.agent_id == "a1"
        assert result.evaluation_queued is True

    @patch("thinkhive.client.requests.request")
    def test_runs_create_returns_run_result(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": {
                "id": "run-abc",
                "agentId": "a1",
                "companyId": "c1",
                "outcome": "resolved",
                "startedAt": "2024-01-01",
                "endedAt": None,
                "createdAt": "2024-01-01",
            },
        })
        from thinkhive.api import runs
        from thinkhive.api.runs import RunResult
        result = runs.create(
            agent_id="a1",
            conversation_messages=[{"role": "user", "content": "hi"}],
        )
        assert isinstance(result, RunResult)
        assert result.id == "run-abc"
        assert result.outcome == "resolved"

    @patch("thinkhive.client.requests.request")
    def test_calibration_get_status_returns_dataclass(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": {
                "agentId": "a1",
                "predictionType": "outcome",
                "brierScore": 0.05,
                "ece": 0.03,
                "mce": 0.08,
                "sampleCount": 500,
                "isCalibrated": True,
                "lastUpdated": "2024-06-01",
            },
        })
        from thinkhive.api import calibration
        from thinkhive.api.calibration import CalibrationStatus
        result = calibration.get_status("a1", "outcome")
        assert isinstance(result, CalibrationStatus)
        assert result.brier_score == 0.05
        assert result.is_calibrated is True
        assert result.sample_count == 500

    @patch("thinkhive.client.requests.request")
    def test_roi_analytics_get_summary_returns_dataclass(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": {
                "summary": {
                    "dateRange": {"start": "2024-01-01", "end": "2024-01-31"},
                    "traceCount": 1000,
                    "successfulInteractions": 800,
                    "failedInteractions": 200,
                    "successRate": 80,
                    "roi": {"total": 50000},
                    "revenueProtected": 25000.0,
                    "estimatedSavings": 10000.0,
                },
            },
        })
        from thinkhive.api import roi_analytics
        from thinkhive.api.roi_analytics import ROISummary
        result = roi_analytics.get_summary()
        assert isinstance(result, ROISummary)
        assert result.trace_count == 1000
        assert result.revenue_protected == 25000.0

    @patch("thinkhive.client.requests.request")
    def test_business_metrics_get_current_returns_dataclass(self, mock_request):
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": {
                "metricName": "Deflection Rate",
                "metricType": "trace_calculated",
                "value": 0.75,
                "valueFormatted": "75%",
                "unit": "%",
                "status": "ready",
                "traceCount": 200,
                "minTraceThreshold": 50,
            },
        })
        from thinkhive.api import business_metrics
        from thinkhive.api.business_metrics import CurrentMetricResponse
        result = business_metrics.get_current("a1", metric_name="Deflection Rate")
        assert isinstance(result, CurrentMetricResponse)
        assert result.metric_name == "Deflection Rate"
        assert result.value == 0.75
        assert result.status == "ready"


class TestCustomEndpoint:
    """Verify URL construction works with non-default endpoints"""

    @patch("thinkhive.client.requests.request")
    def test_custom_endpoint_unversioned(self, mock_request):
        configure(api_key="thk_test", endpoint="https://staging.thinkhive.ai")
        mock_request.return_value = mock_response(json_data={
            "success": True, "data": [],
        })
        from thinkhive.api import agents
        agents.list()
        url = _get_url(mock_request)
        assert url == "https://staging.thinkhive.ai/api/agents"

    @patch("thinkhive.client.requests.request")
    def test_custom_endpoint_versioned(self, mock_request):
        configure(api_key="thk_test", endpoint="https://staging.thinkhive.ai")
        mock_request.return_value = mock_response(json_data={
            "success": True,
            "data": {
                "id": "r1", "agentId": "a1", "companyId": "c1",
                "startedAt": "2024-01-01", "createdAt": "2024-01-01",
            },
        })
        from thinkhive.api import runs
        runs.create(
            agent_id="a1",
            conversation_messages=[{"role": "user", "content": "hi"}],
        )
        url = _get_url(mock_request)
        assert url == "https://staging.thinkhive.ai/api/v3/runs"
