"""Tests for ThinkHive Python SDK initialization"""
import pytest
from unittest.mock import patch, MagicMock


class TestInit:
    """Test thinkhive.init() behavior"""

    def setup_method(self):
        """Reset SDK state before each test"""
        import thinkhive
        thinkhive._initialized = False
        thinkhive._tracer = None

    def test_version_is_4(self):
        import thinkhive
        assert thinkhive.__version__ == "4.0.1"

    def test_init_raises_without_credentials(self):
        import thinkhive
        with pytest.raises(ValueError, match="Either api_key or agent_id"):
            thinkhive.init()

    def test_init_raises_with_only_agent_id(self):
        """OTLP requires API key, agent_id alone should raise"""
        import thinkhive
        with pytest.raises(ValueError, match="OTLP tracing requires an API key"):
            thinkhive.init(agent_id="test-agent")

    @patch("thinkhive.OTLPSpanExporter")
    @patch("thinkhive.TracerProvider")
    @patch("thinkhive.trace")
    def test_init_configures_rest_client(self, mock_trace, mock_provider, mock_exporter):
        """init() should also call configure() so REST APIs work immediately"""
        import thinkhive
        from thinkhive.client import get_config

        mock_trace.get_tracer.return_value = MagicMock()

        thinkhive.init(api_key="thk_test123", agent_id="my-agent")

        config = get_config()
        assert config["api_key"] == "thk_test123"
        assert config["agent_id"] == "my-agent"
        assert config["endpoint"] == "https://app.thinkhive.ai"

    @patch("thinkhive.OTLPSpanExporter")
    @patch("thinkhive.TracerProvider")
    @patch("thinkhive.trace")
    def test_init_uses_production_endpoint_by_default(self, mock_trace, mock_provider, mock_exporter):
        import thinkhive
        mock_trace.get_tracer.return_value = MagicMock()
        thinkhive.init(api_key="thk_test123")
        # Check exporter was called with production endpoint (no /v1/traces suffix)
        mock_exporter.assert_called_once()
        call_kwargs = mock_exporter.call_args
        assert call_kwargs.kwargs["endpoint"] == "https://app.thinkhive.ai"

    @patch("thinkhive.OTLPSpanExporter")
    @patch("thinkhive.TracerProvider")
    @patch("thinkhive.trace")
    def test_init_custom_endpoint(self, mock_trace, mock_provider, mock_exporter):
        import thinkhive
        mock_trace.get_tracer.return_value = MagicMock()
        thinkhive.init(api_key="thk_test123", endpoint="https://custom.example.com")
        call_kwargs = mock_exporter.call_args
        assert call_kwargs.kwargs["endpoint"] == "https://custom.example.com"

    @patch("thinkhive.OTLPSpanExporter")
    @patch("thinkhive.TracerProvider")
    @patch("thinkhive.trace")
    def test_init_idempotent(self, mock_trace, mock_provider, mock_exporter):
        """Second init() call should be a no-op"""
        import thinkhive
        mock_trace.get_tracer.return_value = MagicMock()
        thinkhive.init(api_key="thk_test123")
        thinkhive.init(api_key="thk_different")  # Should not re-init
        assert mock_exporter.call_count == 1


class TestConfigure:
    """Test thinkhive.configure() behavior"""

    def test_default_endpoint_is_production(self):
        from thinkhive.client import _config
        assert _config["endpoint"] == "https://app.thinkhive.ai"

    def test_sdk_version_header(self):
        from thinkhive.client import SDK_VERSION
        assert SDK_VERSION == "4.0.1"
