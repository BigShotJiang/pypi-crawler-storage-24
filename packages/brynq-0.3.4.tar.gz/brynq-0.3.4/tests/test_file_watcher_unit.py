import pytest
from runtime.integrations.file_watcher import FileWatcher

def test_register_pattern():
    fw = FileWatcher("/tmp/dummy")
    fw.register_pattern("*.txt", "text_processor")
    assert len(fw._patterns) == 1
    assert fw._patterns[0]["pattern"] == "*.txt"
    assert fw._patterns[0]["chain_template"] == "text_processor"

def test_get_status_initial():
    fw = FileWatcher("/tmp/dummy")
    status = fw.get_status()
    assert status["watching"] is False
    assert status["directory"] == "/tmp/dummy"
    assert status["files_processed"] == 0
