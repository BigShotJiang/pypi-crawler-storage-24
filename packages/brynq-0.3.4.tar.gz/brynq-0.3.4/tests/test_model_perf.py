import pytest
from runtime.learning.usage_tracker import UsageTracker
from runtime.learning.model_perf import ModelPerformance

@pytest.fixture
def perf(tmp_path):
    tracker = UsageTracker(tmp_path)
    tracker.log("good_model", "single", 10, 10, 50, "success", "s1")
    tracker.log("bad_model", "single", 10, 10, 5000, "error", "s1")
    return ModelPerformance(tracker)

def test_score_model(perf):
    good = perf.score_model("good_model")
    assert good["score"] > 0.5
    
    bad = perf.score_model("bad_model")
    assert bad["score"] < 0.5

def test_rank_models(perf):
    ranked = perf.rank_models()
    assert len(ranked) == 2
    assert ranked[0]["model"] == "good_model"
    assert ranked[1]["model"] == "bad_model"
