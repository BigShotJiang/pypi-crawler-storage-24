import pytest
from runtime.mcp_adapter import match_tool, extract_arguments

def test_match_tool():
    tools = [
        {"name": "fetch_url", "description": "Fetches a URL"},
        {"name": "run_query", "description": "Runs a SQL query"}
    ]
    assert match_tool("I need to fetch_url", tools) == tools[0]
    assert match_tool("fetch", tools) == tools[0]
    assert match_tool("query", tools) == tools[1]
    assert match_tool("random_stuff", tools) is None

def test_extract_arguments():
    text = "Here is the request: url=https://example.com limit=10"
    schema = {"type": "object", "properties": {"url": {"type": "string"}, "limit": {"type": "integer"}}}
    args = extract_arguments(text, schema)    assert args.get("url") == "https://example.com"
    assert args.get("limit") == "10"
