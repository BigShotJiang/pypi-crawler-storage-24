import pytest
from runtime.learning.ab_testing import ABTest, ABTestManager

@pytest.fixture
def manager(tmp_path):
    return ABTestManager(tmp_path)

def test_create_and_assign(manager):
    test = manager.create_test("my_test", {"model": "claude"}, {"model": "gemini"})
    v = test.assign()
    assert v in ('A', 'B')

def test_results(manager, tmp_path):
    test = manager.create_test("my_test2", {"model": "a"}, {"model": "b"})
    for _ in range(5):
        test.record_outcome('A', 100, True, 50)
    for _ in range(3):
        test.record_outcome('B', 200, False, 60)
        
    res = test.results()
    assert res["variant_a"]["success_rate"] == 1.0
    assert res["variant_b"]["success_rate"] == 0.0
    assert res["winner"] == 'A'
