import pytest
from runtime.integrations.formatters import to_markdown, to_html, format_result

def test_to_markdown_headers():
    chain_result = {
        "steps": [
            {"model": "claude", "output": "Hello world", "latency_ms": 100}
        ]
    }
    out = to_markdown(chain_result)
    assert "# Chain Result" in out
    assert "## Step 1: claude" in out
    assert "Hello world" in out

def test_to_html_structure():
    chain_result = {
        "steps": [
            {"model": "gpt-4o", "output": "Hello HTML", "latency_ms": 150}
        ]
    }
    out = to_html(chain_result)
    assert "<html" in out.lower()
    assert "Hello HTML" in out
    assert "gpt-4o" in out

def test_format_result_unknown():
    with pytest.raises(ValueError, match="Unknown format: xml"):
        format_result({"steps": []}, "xml")
