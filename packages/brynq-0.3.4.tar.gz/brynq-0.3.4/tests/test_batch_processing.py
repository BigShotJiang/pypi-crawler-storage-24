import pytest
import os
from pathlib import Path
from runtime.integrations.batch import load_batch_file

def test_load_batch_txt(tmp_path):
    txt_path = tmp_path / "batch.txt"
    txt_path.write_text("prompt1\n\nprompt2\nprompt3\n")
    prompts = load_batch_file(str(txt_path))
    assert len(prompts) == 3
    assert prompts == ["prompt1", "prompt2", "prompt3"]

def test_load_batch_csv(tmp_path):
    csv_path = tmp_path / "batch.csv"
    csv_path.write_text("input\nprompt1\nprompt2\n\"prompt, with comma\"\n")
    prompts = load_batch_file(str(csv_path))
    assert len(prompts) == 3
    assert prompts[0] == "prompt1"
    assert prompts[1] == "prompt2"
    assert prompts[2] == "prompt, with comma"
