import pytest
from runtime.learning.cost_tracker import estimate_cost

def test_estimate_cost():
    # ollama should be free
    assert estimate_cost("ollama:llama3", 1000, 1000) == 0.0
    
    # claude-opus is expensive
    cost = estimate_cost("claude-opus-4-20250514", 1000, 1000)
    assert cost > 0.08
    assert abs(cost - 0.09) < 0.001
