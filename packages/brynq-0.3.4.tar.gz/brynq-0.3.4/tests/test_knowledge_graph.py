import pytest
import os
from brynq._shelved.knowledge_graph_sync import add_node, add_edge, get_graph, get_node_edges

def test_knowledge_graph():
    ns = "test_graph_namespace"
    
    # Add nodes
    assert add_node(ns, "agent_1", {"role": "developer"}) == True
    assert add_node(ns, "agent_2", {"role": "reviewer"}) == True
    
    # Add edge
    assert add_edge(ns, "agent_1", "agent_2", "collaborates_with") == True
    
    # Verify graph
    graph = get_graph(ns)
    assert "agent_1" in graph["nodes"]
    assert "agent_2" in graph["nodes"]
    assert len(graph["edges"]) == 1
    assert graph["edges"][0]["source"] == "agent_1"
    
    # Verify node edges
    edges = get_node_edges(ns, "agent_1")
    assert len(edges) == 1
    assert edges[0]["target"] == "agent_2"
