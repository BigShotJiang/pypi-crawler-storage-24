import pytest
import os
import json
from pathlib import Path
from cloud.marketplace.catalog import MarketplaceCatalog

def test_marketplace_catalog_basic(tmp_path):
    data_dir = tmp_path / "data"
    catalog_dir = data_dir / "marketplace"
    catalog_dir.mkdir(parents=True)
    catalog_file = catalog_dir / "catalog.json"
    
    initial_data = [
        {
            "id": "test-tool-1",
            "name": "Test Tool",
            "category": "code",
            "description": "A testing tool",
            "type": "mcp",
            "install_command": "npx test-tool"
        }
    ]    catalog_file.write_text(json.dumps(initial_data))
    
    cat = MarketplaceCatalog(data_dir)
    stats = cat.stats()
    assert stats["total_entries"] == 1
    assert stats["by_category"]["code"] == 1
    
    res = cat.search("test", limit=10)
    assert len(res) == 1
    assert res[0].id == "test-tool-1"
    
    res_cat = cat.search("", category="code")
    assert len(res_cat) == 1
    
    cat.add_entry({
        "id": "test-tool-2",
        "name": "Another Tool",
        "category": "data"
    })
    assert cat.stats()["total_entries"] == 2
    
    cat.remove_entry("test-tool-1")
    assert cat.stats()["total_entries"] == 1
