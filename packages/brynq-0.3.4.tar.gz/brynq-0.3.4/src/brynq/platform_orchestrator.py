"""
Phase 100: THE GRAND ORCHESTRATOR — Platform-wide coordination.

Ties every Brynq subsystem together. Storage: state/broker/platform/
"""

import json
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

from brynq.server import BROKER_DIR, _write_json_sync, _read_jsonl_sync, _append_jsonl_sync

# ── Paths ──────────────────────────────────────────────────────────────────

PLATFORM_DIR = BROKER_DIR / "platform"
BOOT_LOG_FILE = PLATFORM_DIR / "boot_log.jsonl"
STATUS_FILE = PLATFORM_DIR / "status.json"

PLATFORM_DIR.mkdir(parents=True, exist_ok=True)

# ── Constants ─────────────────────────────────────────────────────────────

PLATFORM_VERSION = "1.0.0"
PLATFORM_CODENAME = "Synapse"
_boot_time: Optional[float] = None


# ── Helpers ────────────────────────────────────────────────────────────────

def _count_lines(filepath: Path) -> int:
    """Count lines in a Python file."""
    try:
        return len(filepath.read_text("utf-8").splitlines())
    except OSError:
        return 0


def _discover_modules() -> List[dict]:
    """Discover all brynq modules under src/brynq/."""
    src_dir = Path(__file__).resolve().parent
    modules = []
    for f in sorted(src_dir.iterdir()):
        if f.suffix == ".py" and not f.name.startswith("_"):
            modules.append({
                "name": f.stem,
                "path": str(f),
                "lines": _count_lines(f),
            })
    return modules


def _discover_tests() -> List[dict]:
    """Discover all test files."""
    project_root = Path(__file__).resolve().parents[2]
    tests_dir = project_root / "tests"
    tests = []
    if tests_dir.exists():
        for f in sorted(tests_dir.iterdir()):
            if f.name.startswith("test_") and f.suffix == ".py":
                tests.append({
                    "name": f.stem,
                    "path": str(f),
                    "lines": _count_lines(f),
                })
    return tests


def _count_dir_entries(dirpath: Path, pattern: str = "*.json") -> int:
    """Count files matching pattern in a directory."""
    if not dirpath.exists():
        return 0
    return sum(1 for _ in dirpath.glob(pattern))


# ── Public API ─────────────────────────────────────────────────────────────

def boot() -> dict:
    """Initialize all platform subsystems. Returns boot report."""
    global _boot_time
    start = time.time()
    _boot_time = start
    now = datetime.now(timezone.utc).isoformat()

    core_dirs = ["channels", "sessions", "cursors", "tasks", "profiles",
                  "lifecycle", "costs", "incidents", "sla", "platform"]
    subsystems_checked = []
    for d in core_dirs:
        (BROKER_DIR / d).mkdir(parents=True, exist_ok=True)
        subsystems_checked.append({"subsystem": d, "status": "ready"})

    modules = _discover_modules()
    tests = _discover_tests()
    elapsed = round(time.time() - start, 4)

    report = {
        "boot_id": uuid.uuid4().hex[:12],
        "timestamp": now,
        "elapsed_seconds": elapsed,
        "subsystems": subsystems_checked,
        "modules_found": len(modules),
        "tests_found": len(tests),
        "status": "operational",
    }
    _append_jsonl_sync(BOOT_LOG_FILE, report)
    _write_json_sync(STATUS_FILE, {"status": "operational", "booted_at": now})
    return report


def get_platform_status() -> dict:
    """Comprehensive platform status snapshot."""
    now = datetime.now(timezone.utc).isoformat()
    modules = _discover_modules()
    tests = _discover_tests()
    total_lines = sum(m["lines"] for m in modules)

    active_agents = _count_dir_entries(BROKER_DIR / "lifecycle" / "agents")
    active_sessions = _count_dir_entries(BROKER_DIR / "sessions")
    kdir = BROKER_DIR / "knowledge"
    knowledge_entries = _count_dir_entries(kdir, "*.jsonl") if kdir.exists() else 0
    efile = BROKER_DIR / "events" / "event_log.jsonl"
    events_processed = len(_read_jsonl_sync(efile)) if efile.exists() else 0

    uptime = round(time.time() - _boot_time, 2) if _boot_time else 0

    # Health score: 100 base, deducted for issues
    health_score = 100
    open_incidents = _count_dir_entries(BROKER_DIR / "incidents")
    if open_incidents > 5:
        health_score -= 10
    if active_sessions == 0:
        health_score -= 5
    health_score = max(health_score, 0)

    return {
        "timestamp": now,
        "status": "operational",
        "health_score": health_score,
        "modules_loaded": len(modules),
        "total_module_lines": total_lines,
        "tests_count": len(tests),
        "active_agents": active_agents,
        "active_sessions": active_sessions,
        "knowledge_entries": knowledge_entries,
        "events_processed": events_processed,
        "uptime_seconds": uptime,
        "version": PLATFORM_VERSION,
        "codename": PLATFORM_CODENAME,
    }


def get_module_inventory() -> List[dict]:
    """List all brynq modules with line counts and test status."""
    modules = _discover_modules()
    tests = _discover_tests()
    test_names = {t["name"] for t in tests}
    for mod in modules:
        expected_test = f"test_{mod['name']}"
        mod["has_tests"] = expected_test in test_names
    return modules


def run_full_diagnostics() -> dict:
    """Health check + self-healing verification + SLA check."""
    now = datetime.now(timezone.utc).isoformat()
    checks: List[dict] = []

    # Check core directories
    for d in ("channels", "sessions", "tasks", "lifecycle", "costs",
              "incidents", "sla", "platform"):
        dp = BROKER_DIR / d
        checks.append({
            "check": f"directory_{d}",
            "ok": dp.exists(),
            "detail": "exists" if dp.exists() else "MISSING",
        })

    # Check boot log
    checks.append({
        "check": "boot_log",
        "ok": BOOT_LOG_FILE.exists(),
        "detail": "present" if BOOT_LOG_FILE.exists() else "no boot recorded",
    })

    # Check SLA compliance
    sla_ok = True
    try:
        from brynq.sla_engine import get_sla_report
        sla_ok = all(s.get("compliant", True) for s in get_sla_report())
    except Exception:
        pass
    detail = "all compliant" if sla_ok else "breaches detected"
    checks.append({"check": "sla_compliance", "ok": sla_ok, "detail": detail})

    all_ok = all(c["ok"] for c in checks)
    return {
        "timestamp": now,
        "overall": "healthy" if all_ok else "degraded",
        "checks": checks,
        "checks_passed": sum(1 for c in checks if c["ok"]),
        "checks_total": len(checks),
    }


def get_platform_summary() -> str:
    """One-paragraph human-readable summary of platform state."""
    s = get_platform_status()
    d = run_full_diagnostics()
    return (
        f"Brynq {PLATFORM_CODENAME} v{PLATFORM_VERSION} is {s['status']} "
        f"with a health score of {s['health_score']}/100. "
        f"{s['modules_loaded']} modules ({s['total_module_lines']} LOC), "
        f"{s['tests_count']} test files. "
        f"{s['active_agents']} agents, {s['active_sessions']} sessions, "
        f"{s['events_processed']} events. "
        f"Diagnostics: {d['checks_passed']}/{d['checks_total']} passed ({d['overall']}). "
        f"Uptime: {s['uptime_seconds']}s."
    )


def get_version() -> dict:
    """Return platform version info."""
    return {
        "version": PLATFORM_VERSION,
        "codename": PLATFORM_CODENAME,
        "python_module": "brynq",
        "phase": 100,
    }


def shutdown(reason: str = "") -> dict:
    """Graceful platform shutdown. Log event and mark status."""
    global _boot_time
    now = datetime.now(timezone.utc).isoformat()
    uptime = round(time.time() - _boot_time, 2) if _boot_time else 0
    event = {
        "event": "shutdown",
        "reason": reason or "graceful shutdown",
        "timestamp": now,
        "uptime_seconds": uptime,
    }
    _append_jsonl_sync(BOOT_LOG_FILE, event)
    _write_json_sync(STATUS_FILE, {"status": "shutdown", "shutdown_at": now, "reason": reason})
    _boot_time = None
    return event
