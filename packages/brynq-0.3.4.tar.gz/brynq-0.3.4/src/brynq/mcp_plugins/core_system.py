from mcp.types import TextContent, Tool

# Core system MCP tools for Brynq Swarm

TOOLS = [
    Tool(
        name="broker_core_ping",
        description="A simple ping to verify the core plugin is loaded.",
        inputSchema={
            "type": "object",
            "properties": {},
            "required": []
        }
    )
]

async def _handle_ping(args: dict) -> list[TextContent]:
    return [TextContent(type="text", text="Pong from core_system plugin!")]

HANDLERS = {
    "broker_core_ping": _handle_ping
}
