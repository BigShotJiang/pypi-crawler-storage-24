# Brynq MCP Plugin Modules
# Each module exposes TOOLS (list[Tool]) and HANDLERS (dict[str, Callable])
