"""Allow running as: python -m brynq"""
import sys

# If called with no args, inject "chat" so the runtime CLI launches chat directly
if len(sys.argv) <= 1:
    sys.argv = [sys.argv[0], "chat"]

from runtime.cli import main
main()
