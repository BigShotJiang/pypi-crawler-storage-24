"""
Phase 30: Production Hardening — Making Brynq Ready for Millions.

Security, reliability, and performance utilities that make the platform
production-grade. Input validation, rate limiting, circuit breakers,
health checks, and graceful degradation.

Features:
  - INPUT SANITIZATION: Validate and sanitize all user inputs
  - RATE LIMITER: Token bucket rate limiting per agent
  - CIRCUIT BREAKER: Fail-fast when downstream services are unhealthy
  - HEALTH CHECKS: Deep health check across all subsystems
  - GRACEFUL DEGRADATION: Disable non-critical features under load
  - REQUEST VALIDATION: Schema validation for API payloads
"""

import json
import re
import time
import html
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from brynq.server import (
    BROKER_DIR,
    CHANNELS_DIR,
    SESSIONS_DIR,
)


# ── Input Sanitization ────────────────────────────────────────────────────


# Patterns that should never appear in user-supplied text
_DANGEROUS_PATTERNS = [
    re.compile(r"<script", re.IGNORECASE),
    re.compile(r"javascript:", re.IGNORECASE),
    re.compile(r"on\w+=", re.IGNORECASE),    # onclick=, onerror=, etc.
    re.compile(r"data:text/html", re.IGNORECASE),
]

# Known credential patterns (from enforcer.py, centralized here)
CREDENTIAL_PATTERNS = [
    "sk-", "sk_live_", "sk_test_", "xoxb-", "xoxp-",
    "ghp_", "gho_", "github_pat_",
    "AKIA", "aws_secret",
    "hooks.slack.com", "discord.com/api/webhooks",
]


def sanitize_text(text: str, max_length: int = 5000) -> tuple[str, list[str]]:
    """Sanitize user-supplied text. Returns (clean_text, warnings).

    - HTML-escapes dangerous characters
    - Strips null bytes
    - Enforces max length
    - Detects credential leaks
    """
    warnings: list[str] = []

    if not isinstance(text, str):
        return str(text)[:max_length], ["Input was not a string"]

    # Strip null bytes
    text = text.replace("\x00", "")

    # Enforce length
    if len(text) > max_length:
        text = text[:max_length]
        warnings.append(f"Truncated to {max_length} chars")

    # Check for dangerous patterns
    for pattern in _DANGEROUS_PATTERNS:
        if pattern.search(text):
            warnings.append(f"Blocked pattern: {pattern.pattern}")
            text = pattern.sub("[BLOCKED]", text)

    # HTML-escape to prevent XSS
    text = html.escape(text)

    # Check for credentials
    text_lower = text.lower()
    for pat in CREDENTIAL_PATTERNS:
        if pat.lower() in text_lower:
            warnings.append(f"Potential credential detected: {pat}")

    return text, warnings


def validate_identifier(value: str, field_name: str = "id") -> tuple[bool, str]:
    """Validate an identifier (agent_id, task_id, etc.).

    Must be alphanumeric + hyphens/underscores, 1-64 chars.
    """
    if not value or not isinstance(value, str):
        return False, f"{field_name} is required"
    if len(value) > 64:
        return False, f"{field_name} too long (max 64 chars)"
    if not re.match(r"^[a-zA-Z0-9_\-]+$", value):
        return False, f"{field_name} contains invalid characters (use a-z, 0-9, -, _)"
    return True, "ok"


def validate_email(email: str) -> tuple[bool, str]:
    """Basic email validation."""
    if not email or not isinstance(email, str):
        return False, "Email is required"
    if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email):
        return False, "Invalid email format"
    if len(email) > 254:
        return False, "Email too long"
    return True, "ok"


def validate_url(url: str) -> tuple[bool, str]:
    """Basic URL validation."""
    if not url or not isinstance(url, str):
        return False, "URL is required"
    if not re.match(r"^https?://[^\s]+$", url):
        return False, "URL must start with http:// or https://"
    if len(url) > 2048:
        return False, "URL too long"
    return True, "ok"


# ── Rate Limiter (Token Bucket) ───────────────────────────────────────────


class RateLimiter:
    """Token bucket rate limiter.

    Each agent gets `max_tokens` tokens that refill at `refill_rate` per second.
    Each request costs 1 token. When tokens are exhausted, requests are rejected.
    """

    def __init__(self, max_tokens: int = 60, refill_rate: float = 1.0):
        self.max_tokens = max_tokens
        self.refill_rate = refill_rate  # tokens per second
        self._buckets: dict[str, dict] = {}

    def allow(self, agent_id: str) -> tuple[bool, dict]:
        """Check if an agent's request is allowed.

        Returns (allowed, info) where info includes remaining tokens.
        """
        now = time.monotonic()
        bucket = self._buckets.get(agent_id)

        if not bucket:
            bucket = {"tokens": self.max_tokens, "last_refill": now}
            self._buckets[agent_id] = bucket

        # Refill tokens
        elapsed = now - bucket["last_refill"]
        refill = elapsed * self.refill_rate
        bucket["tokens"] = min(self.max_tokens, bucket["tokens"] + refill)
        bucket["last_refill"] = now

        info = {
            "agent_id": agent_id,
            "remaining_tokens": round(bucket["tokens"], 1),
            "max_tokens": self.max_tokens,
            "refill_rate": self.refill_rate,
        }

        if bucket["tokens"] >= 1:
            bucket["tokens"] -= 1
            info["remaining_tokens"] = round(bucket["tokens"], 1)
            return True, info
        else:
            retry_after = (1 - bucket["tokens"]) / self.refill_rate if self.refill_rate > 0 else float("inf")
            info["retry_after_seconds"] = round(retry_after, 2)
            return False, info

    def reset(self, agent_id: str) -> None:
        """Reset an agent's rate limit bucket."""
        self._buckets.pop(agent_id, None)

    def get_status(self, agent_id: str) -> dict:
        """Get an agent's current rate limit status without consuming a token."""
        bucket = self._buckets.get(agent_id)
        if not bucket:
            return {"remaining_tokens": self.max_tokens, "max_tokens": self.max_tokens}

        now = time.monotonic()
        elapsed = now - bucket["last_refill"]
        refill = elapsed * self.refill_rate
        current = min(self.max_tokens, bucket["tokens"] + refill)
        return {"remaining_tokens": round(current, 1), "max_tokens": self.max_tokens}


# Default global rate limiter
_rate_limiter = RateLimiter(max_tokens=60, refill_rate=1.0)


def check_rate_limit(agent_id: str) -> tuple[bool, dict]:
    """Check rate limit using the global limiter."""
    return _rate_limiter.allow(agent_id)


# ── Circuit Breaker ───────────────────────────────────────────────────────


class CircuitBreaker:
    """Circuit breaker pattern for downstream service calls.

    States:
      CLOSED  — Normal operation, requests pass through
      OPEN    — Service is down, requests fail-fast immediately
      HALF    — Testing recovery, limited requests allowed

    Transitions:
      CLOSED -> OPEN: After `failure_threshold` consecutive failures
      OPEN -> HALF: After `recovery_timeout` seconds
      HALF -> CLOSED: After a successful request
      HALF -> OPEN: After another failure
    """

    def __init__(self, name: str, failure_threshold: int = 5, recovery_timeout: float = 30.0):
        self.name = name
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.state = "closed"
        self.failure_count = 0
        self.last_failure_time = 0.0
        self.success_count = 0

    def allow_request(self) -> bool:
        """Check if a request should be allowed through."""
        if self.state == "closed":
            return True
        elif self.state == "open":
            if time.monotonic() - self.last_failure_time >= self.recovery_timeout:
                self.state = "half"
                return True
            return False
        elif self.state == "half":
            return True
        return False

    def record_success(self) -> None:
        """Record a successful request."""
        self.failure_count = 0
        self.success_count += 1
        if self.state == "half":
            self.state = "closed"

    def record_failure(self) -> None:
        """Record a failed request."""
        self.failure_count += 1
        self.last_failure_time = time.monotonic()
        if self.failure_count >= self.failure_threshold:
            self.state = "open"

    def get_status(self) -> dict:
        return {
            "name": self.name,
            "state": self.state,
            "failure_count": self.failure_count,
            "success_count": self.success_count,
            "failure_threshold": self.failure_threshold,
        }


# ── Health Checks ──────────────────────────────────────────────────────────


def deep_health_check() -> dict:
    """Run a deep health check across all platform subsystems.

    Returns a structured report with status for each subsystem.
    """
    checks = {}
    overall = "healthy"

    # 1. Broker directory
    checks["broker_dir"] = _check_dir(BROKER_DIR, "Broker storage")

    # 2. Channels
    checks["channels"] = _check_dir(CHANNELS_DIR, "Channel storage")

    # 3. Sessions
    checks["sessions"] = _check_dir(SESSIONS_DIR, "Session storage")

    # 4. Tasks
    checks["tasks"] = _check_dir(BROKER_DIR / "tasks", "Task storage")

    # 5. Profiles
    checks["profiles"] = _check_dir(BROKER_DIR / "profiles", "Profile storage")

    # 6. Payments
    checks["payments"] = _check_dir(BROKER_DIR / "payments", "Payment storage")

    # 7. Federation
    checks["federation"] = _check_dir(BROKER_DIR / "federation", "Federation storage")

    # 8. Social
    checks["social"] = _check_dir(BROKER_DIR / "social", "Social storage")

    # 9. API Keys
    checks["api_keys"] = _check_dir(BROKER_DIR / "api_keys", "API key storage")

    # 10. Disk space
    checks["disk"] = _check_disk_space(BROKER_DIR)

    # Determine overall status
    statuses = [c.get("status") for c in checks.values()]
    if "critical" in statuses:
        overall = "critical"
    elif "degraded" in statuses:
        overall = "degraded"

    return {
        "status": overall,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "checks": checks,
        "subsystem_count": len(checks),
        "healthy_count": sum(1 for s in statuses if s == "healthy"),
    }


def _check_dir(path: Path, label: str) -> dict:
    """Check if a directory exists and is writable."""
    if not path.exists():
        return {"status": "degraded", "label": label, "detail": "Directory does not exist"}
    try:
        # Try writing a temp file
        test_file = path / ".health_check_tmp"
        test_file.write_text("ok")
        test_file.unlink()
        file_count = len(list(path.glob("*")))
        return {"status": "healthy", "label": label, "file_count": file_count}
    except OSError as e:
        return {"status": "critical", "label": label, "detail": str(e)}


def _check_disk_space(path: Path) -> dict:
    """Check available disk space."""
    try:
        import shutil
        usage = shutil.disk_usage(str(path))
        free_gb = round(usage.free / (1024 ** 3), 2)
        used_pct = round(usage.used / usage.total * 100, 1)
        status = "healthy" if free_gb > 1.0 else ("degraded" if free_gb > 0.1 else "critical")
        return {
            "status": status,
            "label": "Disk space",
            "free_gb": free_gb,
            "used_percent": used_pct,
        }
    except (OSError, ImportError):
        return {"status": "degraded", "label": "Disk space", "detail": "Could not check"}


# ── Request Schema Validation ─────────────────────────────────────────────


def validate_payload(payload: dict, schema: dict[str, dict]) -> tuple[bool, list[str]]:
    """Validate a request payload against a schema definition.

    Schema format:
        {
            "field_name": {
                "type": "str",           # str, int, float, bool, list, dict
                "required": True,
                "max_length": 100,       # for strings
                "min_value": 0,          # for numbers
                "max_value": 100,        # for numbers
                "choices": ["a", "b"],   # allowed values
            }
        }

    Returns (valid, errors).
    """
    errors = []

    for field, rules in schema.items():
        value = payload.get(field)
        required = rules.get("required", False)

        if value is None:
            if required:
                errors.append(f"Missing required field: {field}")
            continue

        expected_type = rules.get("type")
        type_map = {
            "str": str, "int": int, "float": (int, float),
            "bool": bool, "list": list, "dict": dict,
        }
        if expected_type and expected_type in type_map:
            if not isinstance(value, type_map[expected_type]):
                errors.append(f"{field}: expected {expected_type}, got {type(value).__name__}")
                continue

        if isinstance(value, str):
            max_len = rules.get("max_length")
            if max_len and len(value) > max_len:
                errors.append(f"{field}: exceeds max length {max_len}")

        if isinstance(value, (int, float)):
            min_val = rules.get("min_value")
            max_val = rules.get("max_value")
            if min_val is not None and value < min_val:
                errors.append(f"{field}: below minimum {min_val}")
            if max_val is not None and value > max_val:
                errors.append(f"{field}: above maximum {max_val}")

        choices = rules.get("choices")
        if choices and value not in choices:
            errors.append(f"{field}: must be one of {choices}")

    return len(errors) == 0, errors
