"""
Phase 66: Knowledge Federation — Share knowledge graphs between nodes.

Exports and imports knowledge bundles with trust-adjusted confidence.
Supports bidirectional sync and conflict resolution.

Storage:
  state/broker/knowledge_fed/
    bundles/{bundle_id}.json — exported/imported bundles
    sync_status.json         — last sync time per peer
    imported/{source}_{id}.json — imported entries
"""

import hashlib
import json
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from brynq.server import BROKER_DIR, _write_json_sync

# ── Paths ──────────────────────────────────────────────────────────────────

FED_DIR = BROKER_DIR / "knowledge_fed"
BUNDLES_DIR = FED_DIR / "bundles"
IMPORTED_DIR = FED_DIR / "imported"
SYNC_STATUS_PATH = FED_DIR / "sync_status.json"

for _d in (FED_DIR, BUNDLES_DIR, IMPORTED_DIR):
    _d.mkdir(parents=True, exist_ok=True)


# ── Helpers ────────────────────────────────────────────────────────────────

def _load_knowledge_entries(categories: Optional[List[str]] = None) -> List[dict]:
    """Load local knowledge entries, optionally filtered by category."""
    entries = []
    try:
        from brynq.knowledge_mcp import KNOWLEDGE_DIR
        for f in KNOWLEDGE_DIR.glob("*.json"):
            if f.name == "index.jsonl":
                continue
            try:
                entry = json.loads(f.read_text("utf-8"))
                if categories and entry.get("category") not in categories:
                    continue
                entries.append(entry)
            except (json.JSONDecodeError, OSError):
                continue
    except ImportError:
        pass
    return entries


def _load_sync_status() -> dict:
    if not SYNC_STATUS_PATH.exists():
        return {}
    try:
        return json.loads(SYNC_STATUS_PATH.read_text("utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def _save_sync_status(status: dict) -> None:
    _write_json_sync(SYNC_STATUS_PATH, status)


def _content_hash(entry: dict) -> str:
    """Deterministic hash of an entry's content for dedup."""
    text = json.dumps({"topic": entry.get("topic", ""),
                       "content": entry.get("content", "")}, sort_keys=True)
    return hashlib.sha256(text.encode()).hexdigest()[:16]


# ── Public API ─────────────────────────────────────────────────────────────

def export_knowledge_bundle(categories: Optional[List[str]] = None) -> dict:
    """Package local knowledge for sharing with peer nodes.

    Args:
        categories: Optional list of categories to include. None = all.

    Returns:
        Bundle dict with entries and metadata.
    """
    entries = _load_knowledge_entries(categories)
    bundle_id = uuid.uuid4().hex[:12]
    now = datetime.now(timezone.utc).isoformat()

    bundle = {
        "bundle_id": bundle_id,
        "created_at": now,
        "entry_count": len(entries),
        "categories": categories or "all",
        "entries": entries,
        "content_hashes": {e.get("knowledge_id", ""): _content_hash(e) for e in entries},
    }
    _write_json_sync(BUNDLES_DIR / f"{bundle_id}.json", bundle)
    return bundle


def import_knowledge_bundle(bundle: dict, source_node_id: str,
                            trust_level: float = 0.5) -> dict:
    """Import knowledge from a peer node with trust-adjusted confidence.

    Args:
        bundle: Bundle dict from export_knowledge_bundle.
        source_node_id: ID of the source peer.
        trust_level: 0.0-1.0 trust in the source (scales confidence).

    Returns:
        Import summary.
    """
    if not 0.0 <= trust_level <= 1.0:
        raise ValueError("trust_level must be between 0.0 and 1.0")
    if not source_node_id:
        raise ValueError("source_node_id is required")

    entries = bundle.get("entries", [])
    imported = 0
    skipped = 0
    conflicts = 0

    for entry in entries:
        kid = entry.get("knowledge_id", uuid.uuid4().hex[:12])
        adjusted_confidence = (entry.get("confidence", 1.0) * trust_level)

        import_entry = dict(entry)
        import_entry["confidence"] = round(adjusted_confidence, 4)
        import_entry["source_node"] = source_node_id
        import_entry["imported_at"] = datetime.now(timezone.utc).isoformat()
        import_entry["original_confidence"] = entry.get("confidence", 1.0)

        dest_path = IMPORTED_DIR / f"{source_node_id}_{kid}.json"
        if dest_path.exists():
            # Conflict — check if content differs
            try:
                existing = json.loads(dest_path.read_text("utf-8"))
                resolved = resolve_conflicts(existing, import_entry)
                _write_json_sync(dest_path, resolved)
                conflicts += 1
            except (json.JSONDecodeError, OSError):
                _write_json_sync(dest_path, import_entry)
                imported += 1
        else:
            _write_json_sync(dest_path, import_entry)
            imported += 1

    return {
        "source_node_id": source_node_id,
        "trust_level": trust_level,
        "total_entries": len(entries),
        "imported": imported,
        "skipped": skipped,
        "conflicts_resolved": conflicts,
    }


def broadcast_knowledge_to_peers(bundle: dict) -> dict:
    """
    Phase 102: The Cortex Sync
    Push a new knowledge bundle to all trusted peers in the federation network.
    """
    try:
        try:
            from brynq.federation import list_peers, get_instance
        except ImportError:
            from brynq._future.federation import list_peers, get_instance
            
        peers = list_peers()
        trusted_peers = [p for p in peers if p.get("trust_level") in ("trusted", "standard")]
        
        me = get_instance()
        my_id = me.get("instance_id", "unknown-node")
        
        results = {}
        for peer in trusted_peers:
            url = peer.get("public_url", "").rstrip("/")
            if not url:
                continue
                
            # In a real networked implementation, this would be an HTTP POST
            # to e.g. f"{url}/federation/knowledge/import"
            # For now, we simulate the transmission and log it
            results[peer["peer_id"]] = "transmitted"
            import logging
            logging.getLogger("brynq.cortex").info(
                f"Broadcasted knowledge bundle {bundle.get('bundle_id')} to peer {peer['peer_id']} at {url}"
            )
            
        return {"peers_reached": len(results), "details": results}
    except Exception as e:
        import logging
        logging.getLogger("brynq.cortex").error(f"Failed to broadcast knowledge: {e}")
        return {"error": str(e)}

    return {
        "source_node_id": source_node_id,
        "trust_level": trust_level,
        "total_entries": len(entries),
        "imported": imported,
        "skipped": skipped,
        "conflicts_resolved": conflicts,
    }


def sync_with_peer(peer_id: str, direction: str = "both") -> dict:
    """Bidirectional knowledge sync with a peer.

    In this local implementation, sync is tracked but actual transport
    is delegated to the caller (export + import).

    Args:
        peer_id: Peer node ID.
        direction: "export", "import", or "both".

    Returns:
        Sync result summary.
    """
    if direction not in ("export", "import", "both"):
        raise ValueError("direction must be 'export', 'import', or 'both'")

    now = datetime.now(timezone.utc).isoformat()
    status = _load_sync_status()

    result = {"peer_id": peer_id, "direction": direction, "synced_at": now}

    if direction in ("export", "both"):
        bundle = export_knowledge_bundle()
        result["exported_entries"] = bundle["entry_count"]
        result["export_bundle_id"] = bundle["bundle_id"]

    if direction in ("import", "both"):
        # Track that we intend to import — actual import requires a bundle
        result["import_ready"] = True

    peer_status = status.get(peer_id, {})
    peer_status["last_sync"] = now
    peer_status["direction"] = direction
    status[peer_id] = peer_status
    _save_sync_status(status)

    return result


def get_sync_status() -> dict:
    """Last sync times per peer."""
    return _load_sync_status()


def resolve_conflicts(local_entry: dict, remote_entry: dict) -> dict:
    """Merge conflicting knowledge entries. Higher confidence wins.

    If confidence is equal, the more recently updated entry wins.
    """
    local_conf = local_entry.get("confidence", 0)
    remote_conf = remote_entry.get("confidence", 0)

    if remote_conf > local_conf:
        winner = dict(remote_entry)
        winner["conflict_resolved"] = "remote_wins"
    elif local_conf > remote_conf:
        winner = dict(local_entry)
        winner["conflict_resolved"] = "local_wins"
    else:
        # Equal confidence — most recent wins
        local_time = local_entry.get("updated_at", local_entry.get("created_at", ""))
        remote_time = remote_entry.get("updated_at", remote_entry.get("created_at", ""))
        if remote_time > local_time:
            winner = dict(remote_entry)
            winner["conflict_resolved"] = "remote_wins_by_recency"
        else:
            winner = dict(local_entry)
            winner["conflict_resolved"] = "local_wins_by_recency"

    winner["conflict_resolved_at"] = datetime.now(timezone.utc).isoformat()
    return winner
