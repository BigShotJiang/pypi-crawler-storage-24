import json
from brynq import service_mesh

def mcp_broker_mesh_register(args: str) -> str:
    """Register a service. Args: JSON containing name, host, port, metadata."""
    try:
        data = json.loads(args)
        res = service_mesh.register_service(data.get('name'), data.get('host'), data.get('port'), data.get('metadata'))
        return json.dumps(res)
    except Exception as e:
        return json.dumps({"error": str(e)})

def mcp_broker_mesh_discover(args: str) -> str:
    """Discover a service. Args: service name."""
    try:
        res = service_mesh.discover_service(args.strip())
        return json.dumps(res)
    except Exception as e:
        return json.dumps({"error": str(e)})

TOOLS = [
    {
        "name": "broker_mesh_register",
        "description": "Register a service in the mesh. Args: JSON with name, host, port, metadata",
        "inputSchema": {"type": "object", "properties": {"args": {"type": "string"}}},
        "handler": mcp_broker_mesh_register
    },
    {
        "name": "broker_mesh_discover",
        "description": "Discover a service endpoint. Args: service name",
        "inputSchema": {"type": "object", "properties": {"args": {"type": "string"}}},
        "handler": mcp_broker_mesh_discover
    }
]
