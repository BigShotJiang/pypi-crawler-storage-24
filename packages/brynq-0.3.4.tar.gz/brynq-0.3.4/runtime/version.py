# Brynq v0.1.0
__version__ = '0.1.0'
BUILD_DATE = '2026-03-24'

def get_version():
    return __version__
