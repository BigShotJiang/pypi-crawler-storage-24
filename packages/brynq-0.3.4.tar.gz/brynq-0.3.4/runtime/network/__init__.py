"""
Brynq network layer — anonymous telemetry, community templates, model leaderboard, agent ratings, and discovery. All telemetry is opt-in.
"""