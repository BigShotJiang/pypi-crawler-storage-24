"""
Brynq learning subsystem — usage tracking, pattern detection, model performance, suggestions, and A/B testing.
All data stays local.
"""