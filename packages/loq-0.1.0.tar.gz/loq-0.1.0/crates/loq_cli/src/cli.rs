//! CLI argument definitions.

use std::path::PathBuf;

use clap::{Args, Parser, Subcommand, ValueEnum};

/// Parsed command-line arguments.
#[derive(Parser, Debug)]
#[command(name = "loq", version, about = "Enforce file size constraints")]
pub struct Cli {
    /// Subcommand to run.
    #[command(subcommand)]
    pub command: Option<Command>,

    /// Show extra information.
    #[arg(short = 'v', long = "verbose", global = true)]
    pub verbose: bool,
}

/// Available commands.
#[derive(Subcommand, Debug, Clone)]
pub enum Command {
    /// Check file line counts.
    Check(CheckArgs),
    /// Create a loq.toml config file.
    Init(InitArgs),
    /// Reset baseline limits to match current file sizes.
    Baseline(BaselineArgs),
    /// Tighten baseline limits without raising them.
    Tighten(TightenArgs),
    /// Allow violations by raising their limits.
    Relax(RelaxArgs),
}

/// Output format for check results.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, ValueEnum)]
pub enum OutputFormat {
    /// Human-readable colored output.
    #[default]
    Text,
    /// Machine-readable JSON output.
    Json,
}

/// Arguments for the check command.
#[derive(Args, Debug, Clone)]
pub struct CheckArgs {
    /// Paths to check (files or directories).
    #[arg(value_name = "PATH", conflicts_with_all = ["staged", "diff"])]
    pub paths: Vec<PathBuf>,

    /// Read additional paths from stdin (internal flag used for `loq check -`).
    #[arg(long = "stdin", hide = true, conflicts_with_all = ["staged", "diff"])]
    pub stdin: bool,

    /// Check only files currently staged in git.
    #[arg(long = "staged", conflicts_with = "diff")]
    pub staged: bool,

    /// Check files changed since a git reference.
    #[arg(long = "diff", value_name = "REF", conflicts_with = "staged")]
    pub diff: Option<String>,

    /// Disable file caching.
    #[arg(long = "no-cache")]
    pub no_cache: bool,

    /// Output format.
    #[arg(long = "output-format", value_enum, default_value_t = OutputFormat::Text)]
    pub output_format: OutputFormat,
}

/// Arguments for the init command.
#[derive(Args, Debug, Clone)]
pub struct InitArgs {}

/// Arguments for the baseline command.
#[derive(Args, Debug, Clone)]
pub struct BaselineArgs {
    /// Line threshold for baseline (defaults to `default_max_lines` from config).
    #[arg(long = "threshold")]
    pub threshold: Option<usize>,
}

/// Arguments for the tighten command.
#[derive(Args, Debug, Clone)]
pub struct TightenArgs {
    /// Line threshold for tightening (defaults to `default_max_lines` from config).
    #[arg(long = "threshold")]
    pub threshold: Option<usize>,
}

/// Arguments for the relax command.
#[derive(Args, Debug, Clone)]
pub struct RelaxArgs {
    /// Specific files to relax limits for.
    #[arg(value_name = "FILE")]
    pub files: Vec<PathBuf>,

    /// Extra lines to add above the current line count.
    #[arg(long = "extra", visible_alias = "buffer", default_value_t = 0)]
    pub extra: usize,
}
