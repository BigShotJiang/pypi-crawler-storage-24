fn main() {
    println!("short");
}
