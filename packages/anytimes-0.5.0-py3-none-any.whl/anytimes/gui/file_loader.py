"""Loading utilities for timeseries files and OrcaFlex data."""
from __future__ import annotations

import datetime
import gc
import os, re
from array import array
from collections.abc import Sequence
import numpy as np
import pandas as pd
from anyqats import TimeSeries, TsDB
from PySide6.QtCore import Qt
from PySide6.QtGui import QGuiApplication
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QDialog,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
    QFileDialog,
    QInputDialog
)

from .orcaflex_selector import OrcaflexVariableSelector
from .utils import (
    ORCAFLEX_VARIABLE_MAP,
    _matches_terms,
    _parse_search_terms,
)
from .layout_utils import apply_initial_size

try:  # Optional dependency used when working with OrcaFlex files
    import OrcFxAPI  # type: ignore
except ImportError:  # pragma: no cover - library is optional
    OrcFxAPI = None

class FileLoader:
    def __init__(self, orcaflex_varmap=None, parent_gui=None):
        self.orcaflex_varmap = orcaflex_varmap or {}
        self.parent_gui = parent_gui
        self.loaded_sim_models = {}
        self.orcaflex_sim_buffers = {}
        self.orcaflex_sim_sources = {}
        self.orcaflex_redundant_subs = []
        self.progress_callback = None  # called while pre-loading
        self._last_diffraction_dir = None
        self._diffraction_cache = {}
        self.cache_orcaflex_buffers = True
        self.orcaflex_time_windows = {}
        self.orcaflex_global_time_window = None

    def preload_sim_models(self, filepaths):
        if OrcFxAPI is None:
            print("OrcFxAPI not available. Cannot preload .sim files.")
            return
        total_files = len(filepaths)
        for idx, path in enumerate(filepaths):
            if path not in self.loaded_sim_models:
                try:
                    self._load_sim_model(path)
                except Exception as e:
                    print(f"❌ Failed to load OrcaFlex model {os.path.basename(path)}:\n{e}")

            if self.progress_callback:
                self.progress_callback(idx + 1, total_files)
            if self.parent_gui:
                QApplication.processEvents()

    def load_files(self, file_paths):
        tsdbs = []
        errors = []
        sim_files = [fp for fp in file_paths if fp.lower().endswith(".sim")]
        other_files = [fp for fp in file_paths if fp not in sim_files]

        tsdb_by_path = {}
        # --- OrcaFlex handling ---
        if sim_files:
            try:

                picked = self.open_orcaflex_picker(sim_files)
                tsdb_by_path.update(picked)

            except Exception as e:
                for fp in sim_files:
                    errors.append((fp, str(e)))
        # --- Other files ---
        for fp in other_files:
            try:
                tsdb_by_path[fp] = self._load_generic_file(fp)
            except Exception as e:
                errors.append((fp, str(e)))

        for fp in file_paths:
            if fp in tsdb_by_path:
                tsdbs.append(tsdb_by_path[fp])

        return tsdbs, errors

    def _load_orcaflex_file(self, filepath):
        # Preload model on first use (refresh from buffer if needed)
        model = self._load_sim_model(filepath)

        # Variable/object selection dialog
        selected, redundant, _ = OrcaflexVariableSelector.get_selection(
            model, self.orcaflex_varmap, self.parent_gui
        )
        if not selected:
            return None

        # Convert extras to OrcFxAPI objects
        specs = []
        for obj_name, var, extra_str in selected:
            obj = model[obj_name]
            for extra, label in self._parse_extras(obj, extra_str or ""):
                # Store only serializable pieces of the selection so it can be
                # safely reused for other models. Holding on to the OrcaFlex
                # object instances can lead to access violations once those
                # models are released (e.g., when loading multiple .sim files
                # in succession).
                specs.append((obj_name, var, extra, label))

        self.orcaflex_redundant_subs = redundant or []
        tsdb = self._load_orcaflex_data_from_specs(model, specs)
        return tsdb

    def open_orcaflex_picker(self, file_paths):
        """Qt version of the OrcaFlex variable picker."""
        self.orcaflex_time_windows = {}
        self.orcaflex_global_time_window = None
        errors = []
        for fp in file_paths:
            try:
                self._load_sim_model(fp)
            except Exception as exc:
                errors.append((fp, exc))
        if errors:
            details = "\n".join(
                f"{os.path.basename(path)}: {exc}" for path, exc in errors
            )
            raise RuntimeError(f"Models not preloaded.\n{details}")


        dialog = QDialog(self.parent_gui)
        dialog.setWindowTitle("Pick OrcaFlex Variables")
        dialog.setWindowFlags(dialog.windowFlags() | Qt.WindowMaximizeButtonHint)
        apply_initial_size(
            dialog,
            desired_width=1250,
            desired_height=860,
            min_width=880,
            min_height=640,
            width_ratio=0.92,
            height_ratio=0.92,
        )
        main_layout = QHBoxLayout(dialog)

        file_side = QVBoxLayout()
        right_side = QVBoxLayout()
        main_layout.addLayout(file_side)
        main_layout.addLayout(right_side)

        red_layout = QHBoxLayout()
        red_layout.addWidget(QLabel("Remove (comma-separated):"))
        redundant_entry = QLineEdit()
        red_layout.addWidget(redundant_entry)
        strip_cb = QCheckBox("Strip '_nodes_(x,y)' suffix")
        red_layout.addWidget(strip_cb)
        right_side.addLayout(red_layout)

        wc_layout = QHBoxLayout()
        wc_layout.addWidget(QLabel("Strip rule:"))
        wc_entry = QLineEdit()
        wc_layout.addWidget(wc_entry)
        regex_cb = QCheckBox("Use as REGEX")
        wc_layout.addWidget(regex_cb)
        right_side.addLayout(wc_layout)

        batch_has_frequency = any(
            self._is_frequency_domain_model(self.loaded_sim_models[fp])
            for fp in file_paths
        )
        default_start, default_stop = self._default_orcaflex_time_window(
            [self.loaded_sim_models[fp] for fp in file_paths],
            force_frequency_defaults=batch_has_frequency,
        )

        time_layout = QHBoxLayout()
        time_layout.addWidget(QLabel("Time from:"))
        time_from_entry = QLineEdit(f"{default_start:.3f}")
        time_from_entry.setFixedWidth(100)
        time_layout.addWidget(time_from_entry)
        time_layout.addWidget(QLabel("to:"))
        time_to_entry = QLineEdit(f"{default_stop:.3f}")
        time_to_entry.setFixedWidth(100)
        time_layout.addWidget(time_to_entry)
        time_layout.addStretch()
        right_side.addLayout(time_layout)

        # Default extras for each object type
        default_group = QGroupBox("Default Extra Input")
        def_layout = QGridLayout(default_group)
        default_inputs = {}
        types = ["Line", "Vessel", "Buoy", "Constraint", "Environment"]
        defaults = {
            "Line": "EndA, mid, EndB",
            "Vessel": "0,0,0",
            "Buoy": "0,0,0",
            "Constraint": "0,0,0",
            "Environment": "0,0,0",
        }
        for row, typ in enumerate(types):
            def_layout.addWidget(QLabel(f"{typ}:"), row, 0)
            e = QLineEdit(defaults[typ])
            default_inputs[typ] = e
            def_layout.addWidget(e, row, 1)

        applied_group = QGroupBox("Applied Selections")
        applied_layout = QVBoxLayout(applied_group)
        applied_summary = QPlainTextEdit()
        applied_summary.setReadOnly(True)
        applied_summary.setPlaceholderText("Selections applied with the button will appear here.")
        applied_layout.addWidget(applied_summary)

        default_summary_layout = QHBoxLayout()
        default_summary_layout.addWidget(default_group)
        default_summary_layout.addWidget(applied_group)
        right_side.addLayout(default_summary_layout)

        tabs = QTabWidget()
        right_side.addWidget(tabs)

        per_file_state = {}
        panel_pressure_by_file = {}
        for fp in file_paths:
            model = self.loaded_sim_models[fp]
            obj_map = {
                o.Name: o.typeName
                for o in model.objects
                if o.typeName in self.orcaflex_varmap
            }

            tab = QWidget()
            tabs.addTab(tab, os.path.basename(fp))
            tab_layout = QHBoxLayout(tab)
            left = QVBoxLayout()
            right = QVBoxLayout()
            tab_layout.addLayout(left)
            tab_layout.addLayout(right)

            left.addWidget(QLabel("Objects"))
            obj_filter = QLineEdit()

            obj_filter.setPlaceholderText("Filter objects")

            left.addWidget(obj_filter)
            obj_scroll = QScrollArea()
            obj_widget = QWidget()
            obj_vbox = QVBoxLayout(obj_widget)
            obj_scroll.setWidgetResizable(True)
            obj_scroll.setWidget(obj_widget)
            left.addWidget(obj_scroll)
            obj_vars = {}
            for name in sorted(obj_map):
                cb = QCheckBox(name)
                obj_vbox.addWidget(cb)
                obj_vars[name] = cb

            obj_btns = QHBoxLayout()
            btn_obj_all = QPushButton("Select All Objects")
            btn_obj_none = QPushButton("Unselect All Objects")
            obj_btns.addWidget(btn_obj_all)
            obj_btns.addWidget(btn_obj_none)
            left.addLayout(obj_btns)


            obj_show_cb = QCheckBox("Show only selected")
            left.addWidget(obj_show_cb)


            var_column = QVBoxLayout()
            var_column.addWidget(QLabel("Variables"))
            var_filter = QLineEdit()

            var_filter.setPlaceholderText("Filter variables")

            var_column.addWidget(var_filter)
            var_scroll = QScrollArea()
            var_widget = QWidget()
            var_vbox = QVBoxLayout(var_widget)
            var_scroll.setWidgetResizable(True)
            var_scroll.setWidget(var_widget)
            var_column.addWidget(var_scroll)
            var_vars = {}

            var_btns = QHBoxLayout()
            btn_var_all = QPushButton("Select All Variables")
            btn_var_none = QPushButton("Unselect All Variables")
            var_btns.addWidget(btn_var_all)
            var_btns.addWidget(btn_var_none)
            var_column.addLayout(var_btns)


            var_show_cb = QCheckBox("Show only selected")
            var_column.addWidget(var_show_cb)


            extra_group = QGroupBox("Position / Arc Length")
            extra_layout = QVBoxLayout(extra_group)
            extra_entry = QLineEdit()

            extra_entry.setPlaceholderText("Arc length / position")
            extra_layout.addWidget(extra_entry)
            extra_layout.addWidget(QLabel("Find Closest:"))
            coord_entry = QLineEdit()
            coord_entry.setPlaceholderText("x,y,z; x,y,z ...")

            extra_layout.addWidget(coord_entry)
            find_btn = QPushButton("Find Closest (Selected)")
            extra_layout.addWidget(find_btn)
            skip_entry = QLineEdit()
            skip_entry.setPlaceholderText("Skip names (comma-separated)")
            extra_layout.addWidget(skip_entry)
            find_all_btn = QPushButton("Find Closest (All)")
            extra_layout.addWidget(find_all_btn)
            pressure_btn = QPushButton("Extract Surface Pressures")
            extra_layout.addWidget(pressure_btn)
            result_table = QTableWidget()
            result_table.setColumnCount(4)
            result_table.setHorizontalHeaderLabels(
                ["Coordinate", "Object", "Node / Panel", "Distance"]
            )
            extra_layout.addWidget(result_table)
            copy_btn = QPushButton("Copy Table")

            def _copy_table(*_, table=result_table):

                lines = [
                    "\t".join(
                        table.horizontalHeaderItem(c).text()
                        for c in range(table.columnCount())
                    )
                ]
                for r in range(table.rowCount()):
                    vals = [
                        table.item(r, c).text() if table.item(r, c) else ""
                        for c in range(table.columnCount())
                    ]
                    lines.append("\t".join(vals))
                QGuiApplication.clipboard().setText("\n".join(lines))

            copy_btn.clicked.connect(_copy_table)
            extra_layout.addWidget(copy_btn)

            right_split = QHBoxLayout()
            right_split.addLayout(var_column)
            right_split.addWidget(extra_group)
            right.addLayout(right_split)


            def rebuild_lists(
                *_,

                obj_filter=obj_filter,
                obj_vars=obj_vars,
                var_filter=var_filter,
                var_vbox=var_vbox,
                var_vars=var_vars,
                obj_map=obj_map,
                extra_entry=extra_entry,
                default_inputs=default_inputs,

                obj_show_cb=obj_show_cb,
                var_show_cb=var_show_cb,

            ):

                def update_var_visibility(*_):
                    terms_var_vis = _parse_search_terms(var_filter.text())
                    for name, cb in var_vars.items():
                        visible = True

                        if terms_var_vis and not _matches_terms(name, terms_var_vis):
                            visible = False

                        if var_show_cb.isChecked() and not cb.isChecked():

                            visible = False
                        cb.setVisible(visible)

                terms_obj = _parse_search_terms(obj_filter.text())
                for name, cb in obj_vars.items():
                    visible = True
                    if terms_obj and not _matches_terms(name, terms_obj):
                        visible = False

                    if obj_show_cb.isChecked() and not cb.isChecked():

                        visible = False
                    cb.setVisible(visible)


                selected = [n for n, cb in obj_vars.items() if cb.isChecked()]
                prev_states = {name: cb.isChecked() for name, cb in var_vars.items()}
                for i in range(var_vbox.count() - 1, -1, -1):
                    w = var_vbox.itemAt(i).widget()
                    if w is not None:
                        w.deleteLater()
                var_vars.clear()

                extra_entry.clear()

                if selected:
                    first_type = obj_map[selected[0]]
                    same_type = all(
                        obj_map[n] == first_type for n in selected
                    )
                else:
                    same_type = False

                if selected and same_type:
                    otype = first_type
                    terms_var = _parse_search_terms(var_filter.text())
                    for vname in self.orcaflex_varmap.get(otype, []):

                        if not terms_var or _matches_terms(vname, terms_var):

                            cbv = QCheckBox(vname)
                            cbv.setChecked(prev_states.get(vname, False))
                            cbv.toggled.connect(update_var_visibility)
                            var_vbox.addWidget(cbv)
                            var_vars[vname] = cbv

                    if otype == "Line":
                        default_val = default_inputs.get("Line").text().strip()
                        extra_entry.setText(default_val or "EndA, mid, EndB")
                    elif otype in (
                        "Vessel",
                        "Buoy",
                        "Constraint",
                        "Environment",
                    ):
                        default_val = default_inputs.get(otype).text().strip()
                        extra_entry.setText(default_val or "0,0,0")
                else:
                    if not selected:
                        msg = "Select object(s) to see variables"
                    elif not same_type:
                        msg = "Selected objects are not the same type"
                    else:
                        msg = "Select object(s) to see variables"
                    var_vbox.addWidget(QLabel(msg))

                update_var_visibility()

            obj_filter.textChanged.connect(rebuild_lists)
            var_filter.textChanged.connect(rebuild_lists)
            for cb in obj_vars.values():
                cb.toggled.connect(rebuild_lists)
            rebuild_lists()


            def select_all_objects(*_, obj_vars=obj_vars):


                # Block signals while toggling to avoid repeated rebuilds

                for cb in obj_vars.values():
                    if cb.isVisible():
                        cb.blockSignals(True)
                        cb.setChecked(True)
                        cb.blockSignals(False)


                # Rebuild lists once after bulk toggle
                rebuild_lists()



            def unselect_all_objects(*_, obj_vars=obj_vars):

                for cb in obj_vars.values():
                    if cb.isVisible():
                        cb.blockSignals(True)
                        cb.setChecked(False)
                        cb.blockSignals(False)


                rebuild_lists()


            btn_obj_all.clicked.connect(select_all_objects)
            btn_obj_none.clicked.connect(unselect_all_objects)

            def select_all_vars(*_, var_vars=var_vars):

                for cb in var_vars.values():
                    if cb.isVisible():
                        cb.blockSignals(True)
                        cb.setChecked(True)
                        cb.blockSignals(False)


                rebuild_lists()



            def unselect_all_vars(*_, var_vars=var_vars):

                for cb in var_vars.values():
                    if cb.isVisible():
                        cb.blockSignals(True)
                        cb.setChecked(False)
                        cb.blockSignals(False)


                rebuild_lists()


            btn_var_all.clicked.connect(select_all_vars)
            btn_var_none.clicked.connect(unselect_all_vars)


            obj_show_cb.toggled.connect(rebuild_lists)
            var_show_cb.toggled.connect(rebuild_lists)


            def _update_table(coords, info, table=result_table):
                if table is None:
                    return
                table.setRowCount(len(coords))
                for row, (coord, (name, node, dist)) in enumerate(zip(coords, info)):
                    coord_str = f"{coord[0]:.2f}, {coord[1]:.2f}, {coord[2]:.2f}"
                    table.setItem(row, 0, QTableWidgetItem(coord_str))
                    table.setItem(row, 1, QTableWidgetItem(name or ""))
                    node_txt = "" if node is None else str(node)
                    table.setItem(row, 2, QTableWidgetItem(node_txt))
                    dist_txt = "" if dist is None else f"{dist:.3f}"
                    table.setItem(row, 3, QTableWidgetItem(dist_txt))
                table.resizeColumnsToContents()

            def find_closest(
                *_,
                obj_vars=obj_vars,
                obj_map=obj_map,
                model=model,
                coord_entry=coord_entry,
                update_table=_update_table,
            ):
                coords = self._parse_xyz_list(coord_entry.text())
                if not coords:
                    return
                selected = [
                    model[n] for n, cb in obj_vars.items() if cb.isChecked()
                ]
                if not selected:
                    return

                closest_info = self._get_closest_objects(coords, selected)
                chosen = {name for name, _, _ in closest_info}

                for name, cb in obj_vars.items():
                    cb.setChecked(name in chosen)
                rebuild_lists()
                update_table(coords, closest_info)

            find_btn.clicked.connect(find_closest)

            def find_closest_all(
                *_,
                obj_vars=obj_vars,
                obj_map=obj_map,
                model=model,
                coord_entry=coord_entry,
                skip_entry=skip_entry,
                update_table=_update_table,
            ):
                coords = self._parse_xyz_list(coord_entry.text())
                if not coords:
                    return
                skip_terms = [
                    s.strip().lower()
                    for s in skip_entry.text().split(',')
                    if s.strip()
                ]
                selected = [
                    model[name]
                    for name in obj_map
                    if not any(term in name.lower() for term in skip_terms)
                ]
                closest_info = self._get_closest_objects(coords, selected)
                chosen = {name for name, _, _ in closest_info}

                for name, cb in obj_vars.items():
                    cb.setChecked(name in chosen)
                rebuild_lists()
                update_table(coords, closest_info)

            find_all_btn.clicked.connect(find_closest_all)

            def extract_surface_pressures(
                *_,
                coord_entry=coord_entry,
                model=model,
                fp=fp,
                update_table=_update_table,
                table=result_table,
            ):
                coords = self._parse_xyz_list(coord_entry.text())
                if not coords:
                    QMessageBox.warning(
                        dialog,
                        "No Coordinates",
                        "Enter at least one coordinate in the form x,y,z.",
                    )
                    panel_pressure_by_file.pop(fp, None)
                    if table is not None:
                        table.setRowCount(0)
                    return
                coord_tuples = [tuple(float(v) for v in c) for c in coords]
                if not coord_tuples:
                    QMessageBox.warning(
                        dialog,
                        "No Coordinates",
                        "Could not interpret the provided coordinates.",
                    )
                    panel_pressure_by_file.pop(fp, None)
                    if table is not None:
                        table.setRowCount(0)
                    return

                start_dir = self._last_diffraction_dir or os.path.dirname(fp)
                if not start_dir or not os.path.isdir(start_dir):
                    start_dir = os.path.dirname(fp)
                file_path, _ = QFileDialog.getOpenFileName(
                    dialog,
                    "Select Diffraction Model (.owr)",
                    start_dir,
                    "Diffraction data (*.owr)",
                )
                if not file_path:
                    return

                directory = os.path.dirname(file_path)
                if directory:
                    self._last_diffraction_dir = directory

                try:
                    import OrcFxAPI
                except ImportError:
                    QMessageBox.critical(
                        dialog,
                        "OrcaFlex Not Available",
                        "OrcFxAPI is required to extract surface pressures.",
                    )
                    return

                diffraction_model = self._diffraction_cache.get(file_path)
                if diffraction_model is None:
                    try:
                        diffraction_model = OrcFxAPI.Diffraction(file_path)
                    except Exception as exc:
                        QMessageBox.critical(
                            dialog,
                            "Diffraction Load Error",
                            f"Failed to load diffraction model:\n{exc}",
                        )
                        return
                    self._diffraction_cache[file_path] = diffraction_model

                target_files = [target_fp for target_fp, cb in file_checks.items() if cb.isChecked()]
                if target_files:
                    if fp in target_files:
                        target_files = [fp] + [f for f in target_files if f != fp]
                    else:
                        target_files.insert(0, fp)
                else:
                    target_files = [fp]

                multi_target = len(target_files) > 1
                success_info = []
                no_data_files = []
                error_files = []

                for target_fp in target_files:
                    state = per_file_state.get(target_fp)
                    if state is None:
                        continue
                    target_model = state.get("model")
                    if target_model is None and target_fp == fp:
                        target_model = model
                    target_table = state.get("table")

                    try:
                        pressure_df, panel_info = self._get_panel_pressure(
                            model=target_model,
                            diffraction_model=diffraction_model,
                            panel_coords=tuple(coord_tuples),
                        )
                    except Exception as exc:
                        panel_pressure_by_file.pop(target_fp, None)
                        if target_table is not None:
                            target_table.setRowCount(0)
                        if multi_target:
                            error_files.append((target_fp, str(exc)))
                            continue
                        QMessageBox.critical(
                            dialog,
                            "Surface Pressure Error",
                            f"Failed to extract surface pressures:\n{exc}",
                        )
                        return

                    if (
                        pressure_df is None
                        or pressure_df.empty
                        or ("Time" in pressure_df.columns and pressure_df.shape[1] <= 1)
                        or ("Time" not in pressure_df.columns and pressure_df.shape[1] == 0)
                    ):
                        panel_pressure_by_file.pop(target_fp, None)
                        if target_table is not None:
                            target_table.setRowCount(0)
                        if multi_target:
                            no_data_files.append(target_fp)
                            continue
                        QMessageBox.warning(
                            dialog,
                            "No Surface Pressures",
                            "No surface pressure data was returned for the provided coordinates.",
                        )
                        return

                    if panel_info is None:
                        panel_info = pd.DataFrame()
                    else:
                        panel_info = panel_info.copy().reset_index(drop=True)

                    panel_pressure_by_file[target_fp] = [
                        {
                            "data": pressure_df.copy(),
                            "info": panel_info.copy(),
                            "diffraction_path": file_path,
                        }
                    ]

                    if not panel_info.empty:
                        surface_var_name = "Surface Pressures"
                        obj_vars_state = state.get("obj_vars", {})
                        obj_map_state = state.get("obj_map", {})
                        var_vars_state = state.get("var_vars", {})
                        rebuild_state = state.get("rebuild")

                        relevant_names = []
                        if "name" in panel_info.columns:
                            for raw_name in panel_info["name"].dropna().unique():
                                if not isinstance(raw_name, str):
                                    continue
                                if raw_name in obj_vars_state:
                                    relevant_names.append(raw_name)

                        selection_changed = False
                        if relevant_names:
                            target_types = {
                                obj_map_state[name]
                                for name in relevant_names
                                if name in obj_map_state
                            }
                            for name in relevant_names:
                                cb = obj_vars_state.get(name)
                                if cb is None or cb.isChecked():
                                    continue
                                cb.blockSignals(True)
                                cb.setChecked(True)
                                cb.blockSignals(False)
                                selection_changed = True
                            if target_types:
                                for name, cb in obj_vars_state.items():
                                    if cb is None or not cb.isChecked() or name in relevant_names:
                                        continue
                                    obj_type = obj_map_state.get(name)
                                    if obj_type not in target_types:
                                        cb.blockSignals(True)
                                        cb.setChecked(False)
                                        cb.blockSignals(False)
                                        selection_changed = True
                        if selection_changed and callable(rebuild_state):
                            rebuild_state()
                            var_vars_state = state.get("var_vars", var_vars_state)

                        surface_cb = var_vars_state.get(surface_var_name)
                        if surface_cb is not None and not surface_cb.isChecked():
                            surface_cb.setChecked(True)

                        coords_for_table = []
                        info_for_table = []
                        for _, row in panel_info.iterrows():
                            coord_val = row.get("input_coord")
                            if isinstance(coord_val, (tuple, list, np.ndarray)) and len(coord_val) == 3:
                                coords_for_table.append(np.array(coord_val, dtype=float))
                            else:
                                coords_for_table.append(
                                    np.array(
                                        [
                                            float(row.get("X", 0.0)),
                                            float(row.get("Y", 0.0)),
                                            float(row.get("Z", 0.0)),
                                        ],
                                        dtype=float,
                                    )
                                )
                            node_val = row.get("pidx")
                            node_disp = None if pd.isna(node_val) else int(node_val) + 1
                            dist_val = row.get("distance")
                            if pd.isna(dist_val):
                                dist_val = None
                            info_for_table.append((row.get("name"), node_disp, dist_val))
                        update_table(coords_for_table, info_for_table, table=target_table)
                    else:
                        if target_table is not None:
                            target_table.setRowCount(0)

                    time_col = "Time" if "Time" in pressure_df.columns else None
                    n_series = pressure_df.shape[1] - (1 if time_col else 0)
                    success_info.append((target_fp, n_series))

                if not success_info:
                    if multi_target:
                        if error_files:
                            message_lines = ["Failed to extract surface pressures for:"]
                            for path, err in error_files:
                                message_lines.append(f" - {os.path.basename(path)}: {err}")
                            QMessageBox.critical(
                                dialog,
                                "Surface Pressure Error",
                                "\n".join(message_lines),
                            )
                        elif no_data_files:
                            names = ", ".join(os.path.basename(path) for path in no_data_files)
                            QMessageBox.warning(
                                dialog,
                                "No Surface Pressures",
                                f"No surface pressure data was returned for: {names}.",
                            )
                    return

                if multi_target:
                    total_series = sum(count for _, count in success_info)
                    message_lines = [
                        f"Loaded {total_series} surface pressure series from {len(success_info)} file(s)."
                    ]
                    if no_data_files:
                        names = ", ".join(os.path.basename(path) for path in no_data_files)
                        message_lines.append(f"No surface pressure data was returned for: {names}.")
                    if error_files:
                        message_lines.append("Failed to extract surface pressures for:")
                        for path, err in error_files:
                            message_lines.append(f" - {os.path.basename(path)}: {err}")
                    QMessageBox.information(
                        dialog,
                        "Surface Pressures Extracted",
                        "\n".join(message_lines),
                    )
                else:
                    n_series = success_info[0][1]
                    QMessageBox.information(
                        dialog,
                        "Surface Pressures Extracted",
                        f"Loaded {n_series} surface pressure series.",
                    )

            pressure_btn.clicked.connect(extract_surface_pressures)

            per_file_state[fp] = {
                "obj_vars": obj_vars,
                "var_vars": var_vars,
                "extra_entry": extra_entry,
                "model": model,
                "obj_map": obj_map,
                "rebuild": rebuild_lists,
                "table": result_table,
            }

        apply_specs = {}

        def _format_applied_label(spec):
            obj_name, var_name, extra_val, label_val = spec
            base = f"{obj_name} : {var_name}"
            details = []
            if label_val and label_val != var_name:
                details.append(str(label_val))
            if extra_val not in (None, ""):
                details.append(str(extra_val))
            if details:
                base = f"{base} ({', '.join(details)})"
            return base

        def update_applied_summary():
            if not apply_specs:
                applied_summary.setPlainText("No selections applied yet.")
                return

            counts = []
            for specs in apply_specs.values():
                seen = []
                for spec in specs:
                    if any(self._specs_match(spec, other) for other in seen):
                        continue
                    for idx, (existing_spec, count) in enumerate(counts):
                        if self._specs_match(spec, existing_spec):
                            counts[idx] = (existing_spec, count + 1)
                            break
                    else:
                        counts.append((spec, 1))
                    seen.append(spec)

            def sort_key(item):
                spec, count = item
                obj_name, var_name, extra_val, label_val = spec
                return (
                    -count,
                    obj_name,
                    var_name,
                    "" if label_val is None else str(label_val),
                    "" if extra_val is None else str(extra_val),
                )

            lines = [
                f"{count} x sim files -> {_format_applied_label(spec)}"
                for spec, count in sorted(counts, key=sort_key)
            ]
            applied_summary.setPlainText("\n".join(lines))

        update_applied_summary()

        file_group = QGroupBox("Select Sims for this selection")
        file_layout = QVBoxLayout(file_group)
        file_checks = {}
        select_all_btn = QPushButton("Select All Sims")
        file_layout.addWidget(select_all_btn)
        status_label = QLabel()

        def select_all_sims():
            for cb in file_checks.values():
                cb.setChecked(True)

        select_all_btn.clicked.connect(select_all_sims)

        def check_files(*_):
            selected = [fp for fp, cb in file_checks.items() if cb.isChecked()]

            # Disable tabs not part of the selection
            if selected:
                for idx, fp in enumerate(file_paths):
                    tabs.setTabEnabled(idx, fp in selected)
            else:
                for idx in range(tabs.count()):
                    tabs.setTabEnabled(idx, True)

            if len(selected) < 2:
                status_label.setText("")
                apply_btn.setEnabled(bool(selected))
                return
            base = set(per_file_state[selected[0]]["obj_map"].keys())
            identical = all(
                set(per_file_state[f]["obj_map"].keys()) == base for f in selected[1:]
            )
            if identical:
                status_label.setText("")
                apply_btn.setEnabled(True)
            else:
                status_label.setText("objects not identical")
                apply_btn.setEnabled(False)

        for fp in file_paths:
            cb = QCheckBox(os.path.basename(fp))
            file_layout.addWidget(cb)
            file_checks[fp] = cb
            cb.toggled.connect(check_files)

        file_side.addWidget(file_group)
        file_side.addWidget(status_label)

        apply_btn = QPushButton("Apply Selection to Checked Sims")
        apply_btn.setEnabled(False)
        file_side.addWidget(apply_btn)

        def apply_selection():
            selected = [fp for fp, cb in file_checks.items() if cb.isChecked()]
            if not selected:
                return
            base_fp = file_paths[tabs.currentIndex()] if tabs.count() else selected[0]
            names_base = set(per_file_state[base_fp]["obj_map"].keys())
            if any(set(per_file_state[f]["obj_map"].keys()) != names_base for f in selected):
                status_label.setText("objects not identical")
                return
            st = per_file_state[base_fp]
            sel_objs = [n for n, cb in st["obj_vars"].items() if cb.isChecked()]
            if not sel_objs:
                QMessageBox.warning(dialog, "No Objects", "Select objects first")
                return
            sel_types = {st["obj_map"][n] for n in sel_objs}
            if len(sel_types) != 1:
                QMessageBox.warning(dialog, "Type mismatch", "Selected objects are not the same type")
                return
            sel_vars = [v for v, cb in st["var_vars"].items() if cb.isChecked()]
            if not sel_vars:
                QMessageBox.warning(dialog, "No Variables", "Select variables first")
                return
            specs = []
            for obj_name in sel_objs:
                obj = st["model"][obj_name]
                for var in sel_vars:
                    for ex, label in self._parse_extras(obj, st["extra_entry"].text()):
                        specs.append((obj_name, var, ex, label))

            for fp in selected:
                existing_specs = apply_specs.setdefault(fp, [])
                for spec in specs:
                    if not any(self._specs_match(spec, existing) for existing in existing_specs):
                        existing_specs.append(spec)

                st_target = per_file_state[fp]
                for name, cb in st_target["obj_vars"].items():
                    cb.setChecked(name in sel_objs)
                st_target["rebuild"]()
                for var, cb in st_target["var_vars"].items():
                    cb.setChecked(var in sel_vars)
                st_target["extra_entry"].setText(st["extra_entry"].text())

                file_checks[fp].setChecked(False)
            status_label.setText(f"Stored selection for {len(selected)} file(s)")
            apply_btn.setEnabled(False)
            update_applied_summary()

        apply_btn.clicked.connect(apply_selection)

        check_files()

        btn_layout = QHBoxLayout()
        load_btn = QPushButton("Load")
        cancel_btn = QPushButton("Cancel")
        btn_layout.addStretch()
        btn_layout.addWidget(load_btn)
        btn_layout.addWidget(cancel_btn)
        right_side.addLayout(btn_layout)

        out_specs = {}

        def on_load():
            self.orcaflex_redundant_subs = [
                s.strip() for s in redundant_entry.text().split(",") if s.strip()
            ]
            self._strip_coord_in_labels = strip_cb.isChecked()
            self._try_coord_wildcard = strip_cb.isChecked()
            rule_text = wc_entry.text().strip()
            if rule_text:
                if regex_cb.isChecked():
                    try:
                        pattern = re.compile(rule_text)
                        self._strip_rule = lambda n, p=pattern: p.sub("", n)
                    except re.error:
                        self._strip_rule = None
                else:
                    self._strip_rule = lambda n, t=rule_text: n.replace(t, "")
            else:
                self._strip_rule = None

            try:
                global_start = float(time_from_entry.text().strip())
                global_stop = float(time_to_entry.text().strip())
            except ValueError:
                QMessageBox.warning(
                    dialog,
                    "Invalid Time Range",
                    "Time from/to must be numeric values.",
                )
                return

            if global_stop <= global_start:
                QMessageBox.warning(
                    dialog,
                    "Invalid Time Range",
                    "Time 'to' must be greater than time 'from'.",
                )
                return

            self.orcaflex_global_time_window = (global_start, global_stop)

            for fp, specs in apply_specs.items():
                out_specs[fp] = list(specs)

            for fp, st in per_file_state.items():
                if fp in out_specs:
                    continue
                sel_objs = [n for n, cb in st["obj_vars"].items() if cb.isChecked()]
                if not sel_objs:
                    continue
                sel_types = {st["obj_map"][n] for n in sel_objs}
                if len(sel_types) != 1:
                    continue
                sel_vars = [v for v, cb in st["var_vars"].items() if cb.isChecked()]
                if not sel_vars:
                    continue
                specs = []
                for obj_name in sel_objs:
                    obj = st["model"][obj_name]
                    for var in sel_vars:
                        for ex, label in self._parse_extras(obj, st["extra_entry"].text()):
                            specs.append((obj_name, var, ex, label))
                out_specs[fp] = specs

            missing_files = [fp for fp in file_paths if fp not in out_specs]
            if missing_files:
                resp = QMessageBox.question(
                    dialog,
                    "No Selection",
                    f"{len(missing_files)} file(s) have no selection. Continue?",
                    QMessageBox.Yes | QMessageBox.No,
                    QMessageBox.No,
                )
                if resp != QMessageBox.Yes:
                    return

            dialog.accept()

        load_btn.clicked.connect(on_load)
        cancel_btn.clicked.connect(dialog.reject)

        if dialog.exec() != QDialog.Accepted:
            return {}

        result = {}
        for fp in file_paths:
            specs = out_specs.get(fp)
            tsdb = None
            if specs:
                tsdb = self._load_orcaflex_data_from_specs(
                    self.loaded_sim_models[fp], specs
                )
            if tsdb is None:
                tsdb = TsDB()

            entries = panel_pressure_by_file.get(fp, [])
            for entry in entries:
                tsdb = self._merge_panel_pressures(
                    tsdb, entry.get("data"), entry.get("info")
                )

            result[fp] = tsdb
        return result

    def _merge_panel_pressures(self, tsdb, pressures_df, panel_info):
        if tsdb is None:
            tsdb = TsDB()
        if pressures_df is None or pressures_df.empty:
            return tsdb
        if "Time" not in pressures_df.columns:
            return tsdb

        time = np.asarray(pressures_df["Time"].to_numpy())
        mapping = {}
        if panel_info is not None and hasattr(panel_info, "empty") and not panel_info.empty:
            for _, row in panel_info.iterrows():
                pidx = row.get("pidx")
                if pd.isna(pidx):
                    continue
                try:
                    key = str(int(pidx) + 1)
                except (TypeError, ValueError):
                    continue
                name = row.get("name")
                coord_val = row.get("input_coord")
                coord_txt = None
                if isinstance(coord_val, (tuple, list, np.ndarray)) and len(coord_val) == 3:
                    coord_txt = f"({coord_val[0]:.2f}, {coord_val[1]:.2f}, {coord_val[2]:.2f})"
                if name:
                    label = f"{name} Panel {int(pidx) + 1}"
                else:
                    label = f"Panel {int(pidx) + 1}"
                if coord_txt:
                    label = f"{label} Surface Pressure @ {coord_txt}"
                else:
                    label = f"{label} Surface Pressure"
                mapping[key] = label

        redundant = getattr(self, "orcaflex_redundant_subs", [])
        existing_names = {ts.name for ts in getattr(tsdb, "register", {}).values()}

        for col in pressures_df.columns:
            if col == "Time":
                continue
            data = pressures_df[col].to_numpy(dtype=float, copy=True)
            label = mapping.get(col, f"Panel {col} Surface Pressure")
            if redundant:
                label = self._strip_redundant(label, redundant)
            base_label = label
            suffix = 1
            while True:
                try:
                    tsdb.add(TimeSeries(label, time, data))
                    break
                except KeyError:
                    suffix += 1
                    label = f"{base_label} ({suffix})"
            existing_names.add(label)

        return tsdb


    def _strip_redundant(self, label, subs):
        for s in subs:
            label = label.replace(s, "")
        label = label.replace("__", "_").replace("::", ":").replace("  ", " ").strip("_:- ")
        return label

    def _resolve_orcaflex_line_end(self, end):
        try:
            import OrcFxAPI
        except ImportError:
            return None
        if end == "EndA":
            return OrcFxAPI.oeEndA
        elif end == "EndB":
            return OrcFxAPI.oeEndB
        elif isinstance(end, (float, int)):
            return OrcFxAPI.oeArcLength(end)
        else:
            return None

    def _parse_xyz_list(self, text: str):
        """Return list of xyz numpy arrays parsed from *text*."""
        import re
        coords = []
        pattern = re.compile(
            r"\(?\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*\)?"
        )
        for match in pattern.finditer(text):
            try:
                coords.append(
                    np.array(
                        [
                            float(match.group(1)),
                            float(match.group(2)),
                            float(match.group(3)),
                        ]
                    )
                )
            except ValueError:
                pass
        return coords

    def _get_closest_objects(self, coords, objects):
        """Return info on closest objects for each coordinate."""
        try:
            import OrcFxAPI
        except ImportError:
            return []

        import numpy as np

        if not coords or not objects:
            return []

        specs = []
        info = []
        for obj in objects:
            if obj.typeName == "Constraint":
                for v in ["In-frame X", "In-frame Y", "In-frame Z"]:
                    specs.append(OrcFxAPI.TimeHistorySpecification(obj, v, None))
                info.append((obj.Name, 1, "Constraint"))
            elif obj.typeName == "Line":
                n_nodes = len(obj.NodeArclengths)
                for n in range(n_nodes):
                    for v in ["X", "Y", "Z"]:
                        specs.append(
                            OrcFxAPI.TimeHistorySpecification(
                                obj, v, OrcFxAPI.oeNodeNum(n + 1)
                            )
                        )
                info.append((obj.Name, n_nodes, "Line"))

        if not specs:
            return []

        data = OrcFxAPI.GetMultipleTimeHistories(specs, OrcFxAPI.pnStaticState)[0]

        obj_data = {}
        idx = 0
        for name, count, typ in info:
            if typ == "Constraint":
                arr = np.array([data[idx : idx + 3]])
                idx += 3
            else:
                arr = np.array([
                    data[idx + i * 3 : idx + i * 3 + 3] for i in range(count)
                ])
                idx += 3 * count
            obj_data[name] = arr

        results = []
        for c in coords:
            best_name = None
            best_dist = None
            best_node = None
            for name, arr in obj_data.items():
                if arr.shape[0] == 1:
                    dist = np.linalg.norm(arr[0] - c)
                    node = None
                else:
                    dists = np.linalg.norm(arr - c, axis=1)
                    node_idx = int(np.argmin(dists))
                    dist = dists[node_idx]
                    node = node_idx + 1
                if best_dist is None or dist < best_dist:
                    best_dist = dist
                    best_name = name
                    best_node = node
                elif dist == best_dist:
                    if node is not None and best_node is not None:
                        if node < best_node:
                            best_name = name
                            best_node = node
            results.append((best_name, best_node, best_dist))

        return results

    def _get_panel_pressure(
        self,
        model,
        diffraction_model,
        time_window=None,
        kpa_to_pa=True,
        panel_coords=None,
        include_hydrostatic=True,
        simidx=0,
        work_folder=None,
        use_existing=True,
        ow_element_nth_resolution: int = 1,
    ):
        try:
            import OrcFxAPI
        except ImportError as exc:
            raise RuntimeError("OrcFxAPI not available") from exc

        if model is None:
            raise ValueError("model is required")
        if diffraction_model is None:
            raise ValueError("diffraction_model is required")

        if time_window is None:
            time_window = OrcFxAPI.SpecifiedPeriod(
                model.simulationStartTime, model.simulationStopTime
            )
        else:
            time_window = OrcFxAPI.SpecifiedPeriod(time_window[0], time_window[1])

        geometry = getattr(diffraction_model, "panelGeometry", None)
        if geometry is None:
            return pd.DataFrame(), pd.DataFrame()

        panel_geometry = [
            (res[0], res[1], res[3][0], res[3][1], res[3][2]) for res in geometry
        ]
        if not panel_geometry:
            return pd.DataFrame(), pd.DataFrame()

        pd_geo = pd.DataFrame(
            panel_geometry, columns=("idx_id", "name", "X", "Y", "Z")
        )
        pd_geo["pidx"] = pd_geo.index.values

        panel_array = pd.DataFrame()
        if panel_coords is None:
            panel_array = pd_geo.loc[pd_geo.idx_id != -1].copy()
            if panel_array.empty:
                time = model["General"].TimeHistory("Time", time_window)
                return pd.DataFrame({"Time": time}), panel_array
            panel_array["input_coord"] = list(
                zip(panel_array["X"], panel_array["Y"], panel_array["Z"])
            )
            panel_array["distance"] = np.nan
        else:
            coords_list = []
            for coord in panel_coords:
                if isinstance(coord, np.ndarray):
                    coord = coord.tolist()
                if coord is None:
                    continue
                try:
                    coords_list.append(tuple(float(v) for v in coord))
                except (TypeError, ValueError):
                    continue

            if not coords_list:
                time = model["General"].TimeHistory("Time", time_window)
                return pd.DataFrame({"Time": time}), pd.DataFrame()

            available = pd_geo.loc[pd_geo.idx_id != -1].copy()
            if available.empty:
                time = model["General"].TimeHistory("Time", time_window)
                return pd.DataFrame({"Time": time}), pd.DataFrame()

            rows = []
            for idx, pt in enumerate(coords_list):
                x, y, z = pt
                this_geo = available.copy()
                this_geo["distance"] = np.sqrt(
                    np.power(this_geo.X.values - x, 2)
                    + np.power(this_geo.Y.values - y, 2)
                    + np.power(this_geo.Z.values - z, 2)
                )
                best = this_geo.sort_values("distance").iloc[0]
                row_dict = best.to_dict()
                row_dict["distance"] = float(row_dict.get("distance", np.nan))
                row_dict["input_coord"] = tuple(pt)
                row_dict["input_index"] = idx
                rows.append(row_dict)

            if rows:
                panel_array = pd.DataFrame(rows)
                if ow_element_nth_resolution and ow_element_nth_resolution > 1:
                    panel_array = panel_array.iloc[::ow_element_nth_resolution]
                panel_array = panel_array.reset_index(drop=True)

        if panel_array is None or panel_array.empty:
            time = model["General"].TimeHistory("Time", time_window)
            return pd.DataFrame({"Time": time}), panel_array

        if "input_index" in panel_array.columns:
            panel_array = panel_array.sort_values("input_index").reset_index(drop=True)

        panel_array = panel_array.dropna(subset=["name"]).reset_index(drop=True)
        if panel_array.empty:
            time = model["General"].TimeHistory("Time", time_window)
            return pd.DataFrame({"Time": time}), panel_array

        if "pidx" in panel_array.columns:
            panel_array["pidx"] = panel_array["pidx"].astype(int)

        all_press = []
        unique_bodies = np.unique(panel_array["name"].values)

        for this_body in unique_bodies:
            press_df = None
            found_this_body_press = False
            if (
                use_existing
                and work_folder
                and isinstance(work_folder, str)
                and os.path.isdir(work_folder)
            ):
                for run_file in os.listdir(work_folder):
                    if (
                        f"of_pressures_sim_idx_{simidx}" in run_file
                        and this_body in run_file
                    ):
                        try:
                            press_df = pd.read_feather(
                                os.path.join(work_folder, run_file)
                            )
                            found_this_body_press = True
                            break
                        except Exception:
                            press_df = None
                            found_this_body_press = False
            if not found_this_body_press:
                panel_ids = panel_array.loc[panel_array.name == this_body, "pidx"].values
                if panel_ids.size == 0:
                    continue
                panel_press = model[this_body].PanelPressureTimeHistory(
                    diffraction=diffraction_model,
                    resultPanels=panel_ids,
                    period=time_window,
                    parameters=OrcFxAPI.PanelPressureParameters(
                        IncludeHydrostaticPressure=include_hydrostatic,
                        IncludeDiffractionPressure=True,
                        IncludeRadiationPressure=True,
                    ),
                )
                press_df = pd.DataFrame(
                    panel_press,
                    columns=np.int32(panel_ids + 1).astype(str),
                )
                if (
                    work_folder
                    and isinstance(work_folder, str)
                    and os.path.isdir(work_folder)
                ):
                    filename = (
                        f"of_pressures_sim_idx_{simidx}_body_{this_body}"
                        f"_resolution_{ow_element_nth_resolution}_"
                        f"{datetime.datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}.feather"
                    )
                    try:
                        press_df.to_feather(os.path.join(work_folder, filename))
                    except Exception:
                        pass
            if press_df is not None:
                all_press.append(press_df)

        time = model["General"].TimeHistory("Time", time_window)
        if not all_press:
            return pd.DataFrame({"Time": time}), panel_array

        all_press = pd.concat(all_press, axis=1)
        if kpa_to_pa:
            all_press = all_press * 1000
        all_press["Time"] = time
        return all_press, panel_array

    def _parse_extras(self, obj, entry_val: str):
        """Interpret extra strings for an OrcaFlex object."""
        import OrcFxAPI

        entry_val = entry_val.strip()

        if obj.typeName == "Line":
            if not entry_val:
                return [(None, None)]
            tokens = [t.strip() for t in entry_val.split(",") if t.strip()]
            total = obj.NodeArclengths[-1]
            extras = []
            for t in tokens:
                low = t.lower().strip()
                m_node = re.match(r"node\s*(\d+)", low)
                m_arc = re.match(r"arc\s*(\d+(?:\.\d+)?)", low)
                if low == "enda":
                    extras.append((OrcFxAPI.oeArcLength(obj.NodeArclengths[0]), "EndA"))
                elif low == "endb":
                    extras.append((OrcFxAPI.oeArcLength(total), "EndB"))
                elif low in ("mid", "middle"):
                    extras.append((OrcFxAPI.oeArcLength(total / 2), "mid"))
                elif m_node:
                    num = int(m_node.group(1))
                    extras.append((OrcFxAPI.oeNodeNum(num), f"Node {num}"))
                elif m_arc:
                    val = float(m_arc.group(1))
                    extras.append((OrcFxAPI.oeArcLength(val), f"Arc {val}"))
                else:
                    try:
                        val = float(t)
                    except ValueError:
                        continue
                    extras.append((OrcFxAPI.oeArcLength(val), f"Arc {val}"))
            return extras

        if obj.typeName in ("Vessel", "Buoy", "Constraint", "Environment"):
            groups = [g.strip() for g in entry_val.split(";") if g.strip()]
            if not groups:
                groups = ["0,0,0"]
            extras = []
            for grp in groups:
                txt = grp
                if txt.lower().startswith("pos"):
                    txt = txt[3:].strip()
                xyz = [s.strip() for s in txt.strip("() ").split(",") if s.strip()]
                if len(xyz) != 3:
                    continue
                try:
                    coords = [float(v) for v in xyz]
                except ValueError:
                    continue
                label = f"Pos ({coords[0]:.2f}, {coords[1]:.2f}, {coords[2]:.2f})"
                if obj.typeName == "Vessel":
                    extras.append((OrcFxAPI.oeVessel(coords), label))
                elif obj.typeName == "Buoy":
                    extras.append((OrcFxAPI.oeBuoy(coords), label))
                elif obj.typeName == "Constraint":
                    extras.append((OrcFxAPI.oeConstraint(coords), label))
                elif obj.typeName == "Environment":
                    extras.append((OrcFxAPI.oeEnvironment(coords), label))
            return extras if extras else [(None, None)]

        return [(None, None)]

    def _specs_match(self, spec_a, spec_b):
        """Check if two selection specs should be considered the same."""
        if len(spec_a) != len(spec_b):
            return False
        return all(
            self._spec_item_match(a, b) for a, b in zip(spec_a, spec_b)
        )

    def _spec_item_match(self, item_a, item_b):
        if item_a is item_b:
            return True
        if type(item_a) is not type(item_b):
            return False
        try:
            if item_a == item_b:
                return True
        except Exception:
            pass

        if OrcFxAPI and hasattr(OrcFxAPI, "ObjectExtra"):
            extra_type = OrcFxAPI.ObjectExtra
            if isinstance(item_a, extra_type) and isinstance(item_b, extra_type):
                comparable_attrs = (
                    "ArcLength",
                    "NodeNum",
                    "X",
                    "Y",
                    "Z",
                )
                compared = False
                for attr in comparable_attrs:
                    if hasattr(item_a, attr) or hasattr(item_b, attr):
                        compared = True
                        if getattr(item_a, attr, None) != getattr(item_b, attr, None):
                            return False
                if compared:
                    return True
                return repr(item_a) == repr(item_b)
        try:
            return repr(item_a) == repr(item_b)
        except Exception:
            return False

    def _load_orcaflex_data_from_specs(self, model, selection_specs):
        try:
            import OrcFxAPI
        except ImportError:
            print("OrcFxAPI not available. Cannot preload .sim files.")
            return
        tsdb = TsDB()
        time_spec = self._resolve_time_spec_for_model(model)
        time = self._extract_model_time(model, time_spec)
        object_var_map = {obj.Name: obj for obj in model.objects}
        def _match_obj(name):
            obj = object_var_map.get(name)
            if obj is None and getattr(self, "_strip_rule", None):
                stripped = self._strip_rule(name)
                for cand, o in object_var_map.items():
                    if self._strip_rule(cand) == stripped:
                        obj = o
                        break
            return obj
        resolved_specs = []
        fallback_specs = []
        names = []
        redundant_subs = getattr(self, "orcaflex_redundant_subs", [])
        for spec in selection_specs:
            try:
                label_override = None
                if len(spec) == 5:
                    obj, obj_name, var, end, label_override = spec
                elif len(spec) == 4:
                    if isinstance(spec[0], str):
                        obj_name, var, end, label_override = spec
                        obj = _match_obj(obj_name)
                    else:
                        obj, obj_name, var, end = spec
                elif len(spec) == 3:
                    obj_name, var, end = spec
                    obj = _match_obj(obj_name)
                else:
                    continue
                if isinstance(var, str) and var.strip().lower() == "surface pressures":
                    continue
                if obj is None:
                    continue
                short_obj = self._strip_redundant(obj_name, redundant_subs)
                short_var = self._strip_redundant(var, redundant_subs)
                if obj.typeName == "Line":
                    if end == "EndA" or (isinstance(end, str) and end.lower() == "enda"):
                        end_enum = self._resolve_orcaflex_line_end("EndA")
                        try:
                            spec_obj = OrcFxAPI.TimeHistorySpecification(model[obj_name], var, end_enum)
                            label = (
                                f"{short_obj}:{short_var} ({label_override})"
                                if label_override
                                else f"{short_obj}:{short_var} (EndA)"
                            )
                            resolved_specs.append(spec_obj)
                            fallback_specs.append((obj_name, var, end_enum))
                            names.append(label)
                        except Exception:
                            continue
                    elif end == "EndB" or (isinstance(end, str) and end.lower() == "endb"):
                        end_enum = self._resolve_orcaflex_line_end("EndB")
                        try:
                            spec_obj = OrcFxAPI.TimeHistorySpecification(model[obj_name], var, end_enum)
                            label = (
                                f"{short_obj}:{short_var} ({label_override})"
                                if label_override
                                else f"{short_obj}:{short_var} (EndB)"
                            )
                            resolved_specs.append(spec_obj)
                            fallback_specs.append((obj_name, var, end_enum))
                            names.append(label)
                        except Exception:
                            continue
                    elif hasattr(OrcFxAPI, "ObjectExtra") and isinstance(end, OrcFxAPI.ObjectExtra):
                        arc_val = getattr(end, 'ArcLength', None)
                        if label_override:
                            label = f"{short_obj}:{short_var} ({label_override})"
                        elif arc_val is not None:
                            label = f"{short_obj}:{short_var} (Arc {arc_val:.2f})"
                        else:
                            label = f"{short_obj}:{short_var} (extra {end})"
                        try:
                            spec_obj = OrcFxAPI.TimeHistorySpecification(model[obj_name], var, end)
                            resolved_specs.append(spec_obj)
                            fallback_specs.append((obj_name, var, end))
                            names.append(label)
                        except Exception:
                            continue
                    elif isinstance(end, (float, int)):
                        try:
                            extra = OrcFxAPI.oeArcLength(end)
                            label = (
                                f"{short_obj}:{short_var} ({label_override})"
                                if label_override
                                else f"{short_obj}:{short_var} (Arc {end:.2f})"
                            )
                            spec_obj = OrcFxAPI.TimeHistorySpecification(model[obj_name], var, extra)
                            resolved_specs.append(spec_obj)
                            fallback_specs.append((obj_name, var, extra))
                            names.append(label)
                        except Exception:
                            continue
                    elif isinstance(end, str):
                        try:
                            end_val = float(end)
                            extra = OrcFxAPI.oeArcLength(end_val)
                            label = (
                                f"{short_obj}:{short_var} ({label_override})"
                                if label_override
                                else f"{short_obj}:{short_var} (Arc {end_val:.2f})"
                            )
                            spec_obj = OrcFxAPI.TimeHistorySpecification(model[obj_name], var, extra)
                            resolved_specs.append(spec_obj)
                            fallback_specs.append((obj_name, var, extra))
                            names.append(label)
                        except Exception:
                            continue
                    else:
                        continue
                elif obj.typeName in ("Vessel", "Buoy", "Constraint", "Environment") and hasattr(OrcFxAPI, "ObjectExtra") and isinstance(end, OrcFxAPI.ObjectExtra):
                    try:
                        spec_obj = OrcFxAPI.TimeHistorySpecification(model[obj_name], var, end)
                        label = (
                            f"{short_obj}:{short_var} ({label_override})"
                            if label_override
                            else f"{short_obj}:{short_var} (pos {end})"
                        )
                        resolved_specs.append(spec_obj)
                        fallback_specs.append((obj_name, var, end))
                        names.append(label)
                    except Exception:
                        continue
                else:
                    try:
                        spec_obj = OrcFxAPI.TimeHistorySpecification(model[obj_name], var)
                        label = f"{short_obj}:{short_var}"
                        resolved_specs.append(spec_obj)
                        fallback_specs.append((obj_name, var, None))
                        names.append(label)
                    except Exception:
                        continue
            except Exception:
                continue
        if not resolved_specs:
            return tsdb
        spectral_lookup = {}
        if self._is_frequency_domain_model(model):
            for fallback_spec, label in zip(fallback_specs, names):
                try:
                    obj_name, var_name, object_extra = fallback_spec
                    obj_for_rao = model[obj_name]
                    kwargs = {}
                    if object_extra is not None:
                        kwargs["objectExtra"] = object_extra
                    rao = obj_for_rao.SpectralResponseRAO(var_name, **kwargs)
                    omega = np.asarray(rao.X, dtype=float)
                    rao_mag = np.asarray(rao.Y, dtype=float)
                    if omega.size and omega.size == rao_mag.size:
                        spectral_lookup[label] = {
                            "freq_hz": omega / (2.0 * np.pi),
                            "rao_amp": rao_mag,
                        }
                except Exception:
                    continue

        try:
            results = OrcFxAPI.GetMultipleTimeHistories(resolved_specs, time_spec)
            time, results = self._crop_orcaflex_series_to_window(model, time, results)
            for i, name in enumerate(names):
                metadata = spectral_lookup.get(name)
                self._add_unique_timeseries(tsdb, name, time, results[:, i], metadata=metadata)
            return tsdb
        except Exception as e:
            if self._is_frequency_domain_model(model):
                # OrcaFlex can reject bulk extraction for synthesised frequency-domain
                # histories, while per-variable extraction still works.
                fallback_error = self._load_orcaflex_time_histories_individually(
                    model,
                    tsdb,
                    fallback_specs,
                    names,
                    time_spec,
                    time,
                    spectral_lookup,
                )
                if fallback_error is None:
                    return tsdb
                e = fallback_error
            QMessageBox.critical(self.parent_gui, "OrcaFlex Read Error", f"Could not read variables:\n{e}")
            return None

    def _load_orcaflex_time_histories_individually(
        self,
        model,
        tsdb,
        fallback_specs,
        names,
        time_spec,
        time,
        spectral_lookup,
    ):
        """Read OrcaFlex time histories one-by-one for frequency-domain fallback.

        Returns ``None`` if at least one variable is read successfully, otherwise
        returns the latest exception instance.
        """

        last_error = None
        loaded_any = False
        for fallback_spec, name in zip(fallback_specs, names):
            try:
                obj_name, var_name, object_extra = fallback_spec
                obj = model[obj_name]
                if object_extra is None:
                    data = obj.TimeHistory(var_name, time_spec)
                else:
                    data = obj.TimeHistory(var_name, time_spec, object_extra)
                metadata = spectral_lookup.get(name)
                resolved_time = self._resolve_time_array(time, data)
                resolved_time, data = self._crop_orcaflex_series_to_window(model, resolved_time, data)
                self._add_unique_timeseries(tsdb, name, resolved_time, data, metadata=metadata)
                loaded_any = True
            except Exception as ex:
                last_error = ex

        if loaded_any:
            return None
        return last_error

    def _extract_model_time(self, model, time_spec):
        """Extract time values for OrcaFlex variables with frequency-domain fallback."""

        if self._is_frequency_domain_model(model):
            sample_times = getattr(model, "SampleTimes", None)
            if callable(sample_times):
                try:
                    return np.asarray(sample_times(time_spec), dtype=float)
                except UnicodeDecodeError:
                    # Certain frequency-domain .sim files can trigger locale
                    # decode errors inside OrcFxAPI while retrieving sample
                    # times. Fallback to General.TimeHistory in that case.
                    pass

        return model["General"].TimeHistory("Time", time_spec)

    def _resolve_time_array(self, time, data):
        """Return a 1D time array matching the data length."""

        data_arr = np.asarray(data, dtype=float)
        n_samples = data_arr.shape[0]
        if n_samples == 0:
            return np.asarray([], dtype=float)

        if time is not None:
            time_arr = np.asarray(time, dtype=float)
            if time_arr.ndim == 1 and time_arr.shape[0] == n_samples:
                return time_arr

        return np.arange(n_samples, dtype=float)

    def _crop_orcaflex_series_to_window(self, model, time, data):
        """Trim time-domain OrcaFlex results to the requested extraction window."""

        time_arr = np.asarray(time, dtype=float)
        data_arr = np.asarray(data)
        if time_arr.ndim != 1 or time_arr.size == 0:
            return time_arr, data_arr

        if self._is_frequency_domain_model(model):
            return time_arr, data_arr

        requested = self.orcaflex_time_windows.get(id(model))
        if requested is None:
            return time_arr, data_arr

        start, stop = requested
        tol = max(1e-9, np.finfo(float).eps * max(1.0, abs(start), abs(stop)) * 10.0)
        mask = (time_arr >= start - tol) & (time_arr <= stop + tol)
        if mask.all() or not mask.any():
            return time_arr, data_arr

        if data_arr.ndim == 1:
            return time_arr[mask], data_arr[mask]
        return time_arr[mask], data_arr[mask, ...]

    def _add_unique_timeseries(self, tsdb, base_label, time, data, metadata=None):
        """Add ``TimeSeries`` to *tsdb* ensuring its name is unique."""

        label = base_label
        suffix = 1
        while True:
            try:
                series = TimeSeries(label, time, data)
                if metadata:
                    for key, value in metadata.items():
                        setattr(series, key, value)
                tsdb.add(series)
                return label
            except KeyError:
                suffix += 1
                label = f"{base_label} ({suffix})"

    def _is_frequency_domain_model(self, model):
        """Detect frequency-domain OrcaFlex simulations from General settings."""

        try:
            general_obj = model["General"]
        except Exception:
            return False

        method = getattr(general_obj, "DynamicsSolutionMethod", None)
        if not isinstance(method, str):
            return False

        return method.strip().lower() == "frequency domain"

    def _resolve_time_spec_for_model(self, model):
        """Pick time window for OrcaFlex extraction using a shared batch range."""

        import OrcFxAPI

        model_id = id(model)
        if model_id in self.orcaflex_time_windows:
            start, stop = self.orcaflex_time_windows[model_id]
            return OrcFxAPI.SpecifiedPeriod(start, stop)

        model_start, model_stop = self._get_model_time_bounds(model)

        if self.orcaflex_global_time_window is not None:
            start, stop = self.orcaflex_global_time_window
            start = float(start)
            stop = float(stop)
            if not self._is_frequency_domain_model(model):
                start = max(start, model_start)
                stop = min(stop, model_stop)
                if stop <= start:
                    start, stop = model_start, model_stop
            self.orcaflex_time_windows[model_id] = (start, stop)
            return OrcFxAPI.SpecifiedPeriod(start, stop)

        if not self._is_frequency_domain_model(model):
            spec = OrcFxAPI.SpecifiedPeriod(model_start, model_stop)
            self.orcaflex_time_windows[model_id] = (model_start, model_stop)
            return spec

        self.orcaflex_time_windows[model_id] = (0.0, 10800.0)
        return OrcFxAPI.SpecifiedPeriod(0.0, 10800.0)

    def _get_model_time_bounds(self, model):
        start = float(getattr(model, "simulationStartTime", 0.0))
        stop = float(getattr(model, "simulationStopTime", start))
        if stop <= start:
            stop = float(getattr(model.simulationTimeStatus, "CurrentTime", start))
        if stop <= start:
            stop = start + 1.0
        return start, stop

    def _default_orcaflex_time_window(self, models, force_frequency_defaults=False):
        if force_frequency_defaults:
            return 0.0, 10800.0

        starts = []
        stops = []
        for model in models:
            start, stop = self._get_model_time_bounds(model)
            starts.append(start)
            stops.append(stop)

        if not starts:
            return 0.0, 1.0
        return min(starts), max(stops)

    def _get_orcaflex_buffer(self, filepath):
        if filepath in self.orcaflex_sim_buffers:
            return self.orcaflex_sim_buffers[filepath]
        with open(filepath, "rb") as handle:
            buffer = bytearray(handle.read())
        self.orcaflex_sim_buffers[filepath] = buffer
        return buffer

    def _load_sim_model(self, filepath):
        import OrcFxAPI

        if filepath in self.loaded_sim_models:
            if (
                self.cache_orcaflex_buffers
                and self.orcaflex_sim_sources.get(filepath) != "buffer"
            ):
                model = self.loaded_sim_models.pop(filepath)
                self._destroy_sim_model(model)
                self.orcaflex_sim_sources.pop(filepath, None)
            else:
                return self.loaded_sim_models[filepath]
        if self.cache_orcaflex_buffers:
            buffer = self._get_orcaflex_buffer(filepath)
            model = OrcFxAPI.Model()
            model.LoadSimulationMem(buffer)
            self.orcaflex_sim_sources[filepath] = "buffer"
        else:
            model = OrcFxAPI.Model(filepath)
            self.orcaflex_sim_sources[filepath] = "file"
        self.loaded_sim_models[filepath] = model
        print(f"✅ Loaded OrcaFlex model: {os.path.basename(filepath)}")
        return model

    def _destroy_sim_model(self, model):
        close = getattr(model, "Close", None)
        if callable(close):
            try:
                close()
            except Exception:
                pass
        destroy = getattr(model, "Destroy", None)
        if callable(destroy):
            try:
                destroy()
            except Exception:
                pass
        del model
        gc.collect()

    def _load_era5_netcdf(self, filepath):
        """Load ERA5-style NetCDF files into a :class:`TsDB` instance."""

        try:
            import xarray as xr
        except ImportError as exc:  # pragma: no cover - optional dependency
            raise ImportError(
                "Reading NetCDF files requires the optional dependency 'xarray'."
            ) from exc

        time_coder = xr.coders.CFDatetimeCoder(use_cftime=True)

        with xr.open_dataset(filepath, decode_times=time_coder) as opened:
            ds = opened.load()

        def _coord_used_as_dim(name: str) -> bool:
            return any(name in var.dims for var in ds.data_vars.values())

        def _coord_is_datetime(coord) -> bool:
            if np.issubdtype(coord.dtype, np.datetime64):
                return True
            if pd.api.types.is_object_dtype(coord.dtype):
                try:  # cftime datetimes present
                    import cftime  # type: ignore

                    sample = np.asarray(coord.values).ravel()
                    for val in sample:
                        if isinstance(val, cftime.datetime):
                            return True
                except Exception:
                    pass
            return False

        def _to_datetime_index(coord):
            try:
                index = coord.to_index()
            except Exception:
                index = pd.Index(np.asarray(coord.values))

            try:
                return pd.DatetimeIndex(index)
            except Exception:
                to_dtindex = getattr(index, "to_datetimeindex", None)
                if callable(to_dtindex):
                    try:
                        return pd.DatetimeIndex(to_dtindex())
                    except Exception:
                        pass

            converted = pd.to_datetime(np.asarray(coord.values), errors="coerce")
            if converted.isna().all():
                raise ValueError("Could not decode time coordinate to datetime values.")
            return pd.DatetimeIndex(converted)

        time_coord = None
        preferred_names = ("time", "valid_time")

        for candidate in preferred_names:
            if candidate in ds.coords and _coord_used_as_dim(candidate):
                time_coord = ds[candidate]
                break

        if time_coord is None:
            for name, coord in ds.coords.items():
                if name in preferred_names:
                    continue
                if ("time" in name.lower() or _coord_is_datetime(coord)) and _coord_used_as_dim(name):
                    time_coord = coord
                    break

        if time_coord is None:
            for var in ds.data_vars.values():
                for dim in var.dims:
                    coord = ds.coords.get(dim)
                    if coord is None:
                        continue
                    if _coord_is_datetime(coord) or "time" in dim.lower():
                        time_coord = coord
                        break
                if time_coord is not None:
                    break

        if time_coord is None:
            raise ValueError("Could not find a time coordinate in the NetCDF file.")

        time_values = _to_datetime_index(time_coord)
        tsdb = TsDB()
        skipped = set()

        for name, data_array in ds.data_vars.items():
            if time_coord.name not in data_array.dims:
                skipped.add(name)
                continue

            spatial_dims = [
                dim
                for dim in data_array.dims
                if dim != time_coord.name and data_array.sizes.get(dim, 0) > 1
            ]

            singleton_dims = [
                dim
                for dim in data_array.dims
                if dim != time_coord.name and data_array.sizes.get(dim, 0) == 1
            ]
            for dim in singleton_dims:
                data_array = data_array.isel({dim: 0})

            iter_indices = [()] if not spatial_dims else np.ndindex(*[data_array.sizes[d] for d in spatial_dims])

            added_any = False
            for idx_tuple in iter_indices:
                indexed = data_array
                suffix_parts = []
                for dim, idx in zip(spatial_dims, idx_tuple):
                    indexed = indexed.isel({dim: idx})
                    coord = ds.coords.get(dim)
                    if coord is not None and coord.ndim == 1 and coord.size > idx:
                        coord_value = np.asarray(coord.values[idx]).item()
                    else:
                        coord_value = idx
                    suffix_parts.append(f"{dim}={coord_value}")

                values = np.asarray(indexed.values)
                if values.ndim != 1 or values.shape[0] != time_values.size:
                    continue

                ts_name = str(name)
                if suffix_parts:
                    ts_name = f"{ts_name} [{', '.join(suffix_parts)}]"

                try:
                    tsdb.add(TimeSeries(ts_name, time_values, values.astype(float)))
                    added_any = True
                except Exception:
                    continue

            if not added_any:
                skipped.add(name)

        if len(tsdb.getm()) == 0:
            tsdb.add(
                TimeSeries(
                    "NO_DATA",
                    time_values,
                    np.full(time_values.shape, np.nan, dtype=float),
                )
            )

        if skipped:
            print(
                f"Skipped non-time variables in {os.path.basename(filepath)}: "
                f"{', '.join(sorted(skipped))}"
            )

        return tsdb

    def _load_generic_file(self, filepath):
        ext = os.path.splitext(filepath)[-1].lower().lstrip(".")
        if ext in ["csv", 'mat', 'dat', 'ts',  'h5', 'pickle', 'tda', 'asc', 'tdms', 'pkl', 'bin']:
            return TsDB.fromfile(filepath)
        elif ext in ["nc", "netcdf"]:
            return self._load_era5_netcdf(filepath)
        elif ext == "xlsx":
            df = pd.read_excel(filepath)
        elif ext == "json":
            df = pd.read_json(filepath)
        elif ext == "feather":
            df = pd.read_feather(filepath)
        elif ext == "parquet":
            df = pd.read_parquet(filepath)
        else:
            raise NotImplementedError(f"No loader for extension: {ext}")
        # Detect time column
        time_col = next((c for c in df.columns if c.lower() in ["time", "t"]), df.columns[0])
        time = df[time_col].values
        tsdb = TsDB()
        skipped = set()

        # Detect potential identifier columns with string values
        id_col = None

        string_cols = [
            c
            for c in df.columns
            if c != time_col
            and pd.api.types.is_string_dtype(df[c])
            and df[c].map(
                lambda x: isinstance(x, str)
                or (not hasattr(x, "__iter__") and pd.isna(x))
            ).all()
        ]

        for sc in string_cols:
            resp = QMessageBox.question(
                self.parent_gui,
                "Identifier Column?",
                f"Column '{sc}' contains strings. Use as identifier?",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )
            if resp == QMessageBox.Yes:
                id_col = sc
                break
            else:
                skipped.add(sc)


        if id_col:
            split_columns = {}
            for ident, subdf in df.groupby(id_col):
                time_vals = subdf[time_col].values
                for col in df.columns:

                    if col in (time_col, id_col):
                        continue
                    # ensure any pyarrow/extension values are converted to
                    # regular Python objects before further inspection
                    values = []

                    for v in subdf[col].tolist():
                        if hasattr(v, "to_pylist"):
                            v = v.to_pylist()
                        elif isinstance(v, array):
                            v = list(v)
                        elif isinstance(v, np.ndarray):
                            v = v.tolist()
                        values.append(v)

                    if col not in split_columns:
                        # consider only non-null entries when checking for list-like values
                        non_null = []
                        for v in values:
                            if isinstance(v, Sequence) and not isinstance(v, (str, bytes)):
                                non_null.append(v)
                            elif not pd.isna(v):
                                non_null.append(v)
                        if non_null and all(
                            isinstance(v, Sequence) and not isinstance(v, (str, bytes))
                            for v in non_null
                        ):
                            lengths = {len(v) for v in non_null}
                            if len(lengths) == 1:
                                n = lengths.pop()
                                resp = QMessageBox.question(
                                    self.parent_gui,
                                    "Split Column?",
                                    f"Column '{col}' contains list/tuple values of length {n}.\nSplit into {n} columns?",
                                    QMessageBox.Yes | QMessageBox.No,
                                    QMessageBox.Yes,
                                )
                                if resp == QMessageBox.Yes:
                                    name_str, ok = QInputDialog.getText(
                                        self.parent_gui,
                                        "Column Names",
                                        f"Enter {n} comma-separated names for '{col}':",
                                    )
                                    if ok:
                                        names = [s.strip() for s in name_str.split(",") if s.strip()]
                                    else:
                                        names = []
                                    if len(names) != n:
                                        names = [f"{col}_{i+1}" for i in range(n)]
                                    split_columns[col] = names
                                else:
                                    split_columns[col] = None
                            else:
                                split_columns[col] = None
                        else:
                            split_columns[col] = None
                    names = split_columns.get(col)
                    if names:
                        for i in range(len(names)):
                            row_vals = []
                            for row in values:
                                if isinstance(row, Sequence) and not isinstance(row, (str, bytes)):
                                    try:
                                        row_vals.append(row[i])
                                    except Exception:
                                        row_vals.append(np.nan)
                                else:
                                    row_vals.append(np.nan)
                            try:
                                data = np.array(row_vals, dtype=float)
                            except Exception:
                                skipped.add(f"{col}_{i}")
                                continue

                            tsdb.add(TimeSeries(f"{names[i]}_{ident}", time_vals, data))
                        continue
                    try:
                        numeric_values = np.array(values, dtype=float)
                        tsdb.add(TimeSeries(f"{col}_{ident}", time_vals, numeric_values))
                    except Exception:
                        skipped.add(col)

        else:
            for col in df.columns:
                if col == time_col:
                    continue
                # Convert potential extension array values to regular Python
                values = []
                for v in df[col].tolist():
                    if hasattr(v, "to_pylist"):
                        v = v.to_pylist()
                    elif isinstance(v, array):
                        v = list(v)
                    elif isinstance(v, np.ndarray):
                        v = v.tolist()
                    values.append(v)
                # Consider only non-null entries when checking for list-like values
                non_null = []
                for v in values:
                    if isinstance(v, Sequence) and not isinstance(v, (str, bytes)):
                        non_null.append(v)
                    elif not pd.isna(v):
                        non_null.append(v)
                if non_null and all(
                    isinstance(v, Sequence) and not isinstance(v, (str, bytes))
                    for v in non_null
                ):
                    lengths = {len(v) for v in non_null}
                    if len(lengths) == 1:
                        n = lengths.pop()
                        resp = QMessageBox.question(
                            self.parent_gui,
                            "Split Column?",
                            f"Column '{col}' contains list/tuple values of length {n}.\nSplit into {n} columns?",
                            QMessageBox.Yes | QMessageBox.No,
                            QMessageBox.Yes,
                        )
                        if resp == QMessageBox.Yes:
                            name_str, ok = QInputDialog.getText(
                                self.parent_gui,
                                "Column Names",
                                f"Enter {n} comma-separated names for '{col}':",
                            )
                            if ok:
                                names = [s.strip() for s in name_str.split(",") if s.strip()]
                            else:
                                names = []
                            if len(names) != n:
                                names = [f"{col}_{i+1}" for i in range(n)]
                            for i in range(n):
                                row_vals = []
                                for row in values:
                                    if isinstance(row, Sequence) and not isinstance(row, (str, bytes)):
                                        try:
                                            row_vals.append(row[i])
                                        except Exception:
                                            row_vals.append(np.nan)
                                    else:
                                        row_vals.append(np.nan)
                                try:
                                    data = np.array(row_vals, dtype=float)
                                except Exception:
                                    skipped.add(f"{col}_{i}")
                                    continue

                                tsdb.add(TimeSeries(names[i], time, data))
                            continue
                try:
                    numeric_values = np.array(values, dtype=float)
                    tsdb.add(TimeSeries(col, time, numeric_values))
                except Exception:
                    skipped.add(col)

        if len(tsdb.getm()) == 0:
            if 'time' in df.columns or 't' in df.columns:
                time_col = next((c for c in df.columns if c.lower() in ["time", "t"]), df.columns[0])
                time = df[time_col].values
            else:
                time = np.arange(len(df))
            tsdb.add(TimeSeries("NO_DATA", time, np.full_like(time, np.nan, dtype=float)))
        if skipped:
            print(
                f"Skipped non-numeric columns in {os.path.basename(filepath)}: {', '.join(sorted(skipped))}"
            )
        return tsdb

__all__ = ['FileLoader']
