import OrcFxAPI
import math


# ----------------------------
# Small vector utilities
# ----------------------------
def cross(a, b):
    return (
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    )


def dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def add(a, b):
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def mul(s, v):
    return (s * v[0], s * v[1], s * v[2])


def norm(v):
    return math.sqrt(max(0.0, dot(v, v)))


def as_float3(v):
    # Strips np.float64 etc to plain Python float for nice printing
    return (float(v[0]), float(v[1]), float(v[2]))


# ----------------------------
# Constraint external function
# ----------------------------
class ConstraintControl(object):
    """
    CONTROL POINT LOGIC (ABSOLUTE GEOMETRY, RELATIVE OUTPUT)

    Base point for control point: "ConstraintPull"
    p1 = "ConstraintBridgePull"
    p2 = "ConstraintPipeEndOffset"

    - Keep x_rel,y_rel fixed
    - Compute z such that C_abs lies on constructed perp_plane (or fallback)
    - Output C_rel = C_abs - base_abs
    - FLOOR: prevent control point from going below p1 (ConstraintBridgePull) in Z
    """

    def Initialise(self, info):
        self.model = info.Model
        self.c = info.ModelObject  # the constraint using this function (ConstraintPullOneWay)

        # Objects
        self.base_obj = self.model["ConstraintPull"]                 # base point for control point
        self.p1 = self.model["ConstraintBridgePull"]                 # p1 (floor reference)
        self.p2 = self.model["ConstraintPipeEndOffset"]              # p2

        # Instantaneous history request
        self.period_now = OrcFxAPI.Period(OrcFxAPI.pnInstantaneousValue)
        self.oe = OrcFxAPI.oeRigidBody(0.0, 0.0, 0.0)

        # The StructValue.Position here is RELATIVE to base point.
        self.x_rel0 = float(info.StructValue.Position[0])
        self.y_rel0 = float(info.StructValue.Position[1])

        # Keep orientation fixed
        self.initial_rot = info.StructValue.Orientation

        # State history for velocity (RELATIVE velocity)
        self.prev_pos_rel = tuple(map(float, info.StructValue.Position))
        self.prev_time = None
        self.last_velocity_rel = (0.0, 0.0, 0.0)

        info.UpdateDuringStatics = True

    def _fallback_bestfit_z_on_line_xy(self, p1_abs, p2_abs, x_abs, y_abs):
        """
        Best-fit point on the line segment p1->p2 based on XY projection.
        Returns (z_abs, s_clamped).
        """
        x1, y1, z1 = p1_abs
        x2, y2, z2 = p2_abs
        dx = x2 - x1
        dy = y2 - y1
        dz = z2 - z1

        denom = dx * dx + dy * dy
        if denom < 1e-12:
            s = 0.0
        else:
            s = ((x_abs - x1) * dx + (y_abs - y1) * dy) / denom
            s = max(0.0, min(1.0, s))

        return z1 + s * dz, s

    def Calculate(self, info):

        # ---------------------------------------------------------
        # 1) Fetch ABS positions
        # ---------------------------------------------------------
        base_abs = (
            self.base_obj.TimeHistory("In-frame X", self.period_now, self.oe)[0],
            self.base_obj.TimeHistory("In-frame Y", self.period_now, self.oe)[0],
            self.base_obj.TimeHistory("In-frame Z", self.period_now, self.oe)[0],
        )
        p1_abs = (
            self.p1.TimeHistory("In-frame X", self.period_now, self.oe)[0],
            self.p1.TimeHistory("In-frame Y", self.period_now, self.oe)[0],
            self.p1.TimeHistory("In-frame Z", self.period_now, self.oe)[0],
        )
        p2_abs = (
            self.p2.TimeHistory("In-frame X", self.period_now, self.oe)[0],
            self.p2.TimeHistory("In-frame Y", self.period_now, self.oe)[0],
            self.p2.TimeHistory("In-frame Z", self.period_now, self.oe)[0],
        )

        base_abs = as_float3(base_abs)
        p1_abs = as_float3(p1_abs)
        p2_abs = as_float3(p2_abs)

        xb, yb, zb = base_abs
        x1, y1, z1 = p1_abs
        x2, y2, z2 = p2_abs

        # Control point ABS x,y are fixed relative to base
        x_abs = xb + self.x_rel0
        y_abs = yb + self.y_rel0

        # ---------------------------------------------------------
        # 2) Plane construction
        # ---------------------------------------------------------
        n_main = cross(sub(p1_abs, base_abs), sub(p2_abs, base_abs))
        d = sub(p2_abs, p1_abs)

        # perp plane normal
        n_perp = cross(d, n_main)
        nx, ny, nz = n_perp

        eps = 1e-12
        method = ""
        plane_resid = 0.0

        # --- compute s_xy on the SEGMENT based on XY ---
        dx, dy = (x2 - x1), (y2 - y1)
        denom_xy = dx * dx + dy * dy
        if denom_xy < 1e-12:
            s_xy_unclamped = 0.0
        else:
            s_xy_unclamped = ((x_abs - x1) * dx + (y_abs - y1) * dy) / denom_xy

        s_xy = max(0.0, min(1.0, s_xy_unclamped))
        q_abs = add(p1_abs, mul(s_xy, d))

        # --- solve z_abs ---
        if norm(n_perp) < 1e-9 or abs(nz) < 1e-9:
            z_abs, _ = self._fallback_bestfit_z_on_line_xy(p1_abs, p2_abs, x_abs, y_abs)
            method = "fallback(z from segment, clamped s_xy)"
            plane_resid = 0.0
        else:
            if s_xy_unclamped < 0.0:
                z_abs = z1
                method = "clamp-to-p1 (s_xy<0)"
            elif s_xy_unclamped > 1.0:
                z_abs = z2
                method = "clamp-to-p2 (s_xy>1)"
            else:
                z_abs = z1 - (nx * (x_abs - x1) + ny * (y_abs - y1)) / nz
                method = "vertical->perp_plane (inside segment)"

                residue = nx * (x_abs - x1) + ny * (y_abs - y1) + nz * (z_abs - z1)
                plane_resid = abs(residue) / (norm(n_perp) + eps)

        # ---------------------------------------------------------
        # 3) FLOOR: do not go below ConstraintBridgePull (p1) in Z
        # ---------------------------------------------------------
        if z_abs < z1:
            z_abs = z1
            method += " + FLOOR(z>=p1.z)"

        # ---------------------------------------------------------
        # 4) Convert to REL + keep x/y fixed
        # ---------------------------------------------------------
        c_abs = (x_abs, y_abs, z_abs)
        c_rel = (c_abs[0] - xb, c_abs[1] - yb, c_abs[2] - zb)
        c_rel = (self.x_rel0, self.y_rel0, c_rel[2])

        # ---------------------------------------------------------
        # 5) Velocity (finite difference) in REL coordinates
        # ---------------------------------------------------------
        if info.NewTimeStep:
            if self.prev_time is None:
                self.prev_time = info.SimulationTime
                self.prev_pos_rel = c_rel
                self.last_velocity_rel = (0.0, 0.0, 0.0)
            else:
                dt = info.SimulationTime - self.prev_time
                if dt > 1e-9:
                    self.last_velocity_rel = (
                        (c_rel[0] - self.prev_pos_rel[0]) / dt,
                        (c_rel[1] - self.prev_pos_rel[1]) / dt,
                        (c_rel[2] - self.prev_pos_rel[2]) / dt,
                    )
                self.prev_pos_rel = c_rel
                self.prev_time = info.SimulationTime

            qx, qy, qz = as_float3(q_abs)
            print(
                f"t={info.SimulationTime:7.3f} | "
                f"base_abs=({xb: .6f}, {yb: .6f}, {zb: .6f}) | "
                f"p1_abs=({x1: .6f}, {y1: .6f}, {z1: .6f}) | "
                f"p2_abs=({x2: .6f}, {y2: .6f}, {z2: .6f}) | "
                f"q_abs=({qx: .3f}, {qy: .3f}, {qz: .3f}) s_xy={s_xy: .4f} (raw={s_xy_unclamped: .4f}) | "
                f"C_abs=({c_abs[0]: .6f}, {c_abs[1]: .6f}, {c_abs[2]: .6f}) | "
                f"C_rel=({c_rel[0]: .6f}, {c_rel[1]: .6f}, {c_rel[2]: .6f}) | "
                f"method={method} | resid~={plane_resid:.3e}"
            )

        # ---------------------------------------------------------
        # 6) Apply
        # ---------------------------------------------------------
        info.StructValue.Position = c_rel
        info.StructValue.Velocity = self.last_velocity_rel
        info.StructValue.Orientation = self.initial_rot
        info.StructValue.AngularVelocity = (0.0, 0.0, 0.0)
