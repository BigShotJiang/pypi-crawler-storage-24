# uzmorph-bigru: Uzbek Neural Morphological Analyzer (BiGRU Architecture)

**uzmorph-bigru** is a high-accuracy word-level morphological analyzer for the Uzbek language. It leverages the Bidirectional Gated Recurrent Unit (BiGRU) architecture to offer a lighter yet powerful alternative to standard LSTMs.

## Performance & Use Case
- **Architecture**: Bidirectional GRU (2 Layers, 128 hidden units).
- **Efficiency**: Approximately 20% faster inference and 15% smaller model size (~0.9MB) compared to BiLSTM.
- **Accuracy**: >96% on common word sets.
- **Ideal For**: Mobile applications or environments with limited memory where high throughput is required.

## Installation
```bash
pip install uzmorph-bigru
```

## Quick Start (Usage Examples)

### 1. Simple Analysis (String Output)
```python
from uzmorph_bigru.uzmorph_bigru import uzmorph_bigru

analyzer = uzmorph_bigru()
result = analyzer.analyze("kitobim")
print(result)

# Output:
# Result: 'kitobim' -> Stem: kitob | POS: NOUN | Tags: [possession=1, singular=1]
```

### 2. Structured Data (Dict/JSON)
```python
# To Dictionary
data = analyzer.analyze("maktabda").to_dict()
# { "word": "maktabda", "stem": "maktab", "pos": "NOUN", "cases": "Locative" }

# To JSON
json_string = analyzer.analyze("yozyapmiz").to_json()
```

## Supported Tags & Features

### Part of Speech (POS)
- `NOUN` (Ot), `VERB` (Fe'l), `ADJ` (Sifat), `ADV` (Ravish), `NUM` (Son), `PRN` (Olmosh).

### Grammatical Features
- **Cases**: `Nominative`, `Ablative`, `Accusative`, `Dative`, `Genitive`, `Locative`.
- **Possession**: `1` (Mening), `2` (Sening), `3` (Uning).
- **Number**: `singular=1`, `plural=1`.
- **Verb Specific**:
  - **Tense**: `Past` (O'tgan), `Present` (Hozirgi), `Future` (Kelasi).
  - **Voice**: `Causative`, `Passive`, `Reciprocal`, `Reflexive`.
  - **Mood/Impulsion**: `Imperative`, `Conditional`, `Proposal`.

## License
MIT
