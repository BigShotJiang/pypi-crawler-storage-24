"""Main entry point for context generation."""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from dfcontext.analyzers.base import ColumnSummary, classify_column
from dfcontext.analyzers.boolean import BooleanAnalyzer
from dfcontext.analyzers.categorical import CategoricalAnalyzer
from dfcontext.analyzers.datetime import DatetimeAnalyzer
from dfcontext.analyzers.numeric import NumericAnalyzer
from dfcontext.analyzers.text import TextAnalyzer
from dfcontext.budget import TokenBudgetAllocator
from dfcontext.config import ContextConfig
from dfcontext.formatters.markdown import MarkdownFormatter
from dfcontext.formatters.plain import PlainTextFormatter
from dfcontext.formatters.yaml_fmt import YAMLFormatter
from dfcontext.sampler import RepresentativeSampler
from dfcontext.tokenizer import TokenCounter

if TYPE_CHECKING:
    import pandas as pd

    from dfcontext.formatters.base import BaseFormatter

_ANALYZERS = {
    "numeric": NumericAnalyzer(),
    "categorical": CategoricalAnalyzer(),
    "text": TextAnalyzer(),
    "datetime": DatetimeAnalyzer(),
    "boolean": BooleanAnalyzer(),
}

_FORMATTERS: dict[str, BaseFormatter] = {
    "markdown": MarkdownFormatter(),
    "plain": PlainTextFormatter(),
    "yaml": YAMLFormatter(),
}


def to_context(
    df: pd.DataFrame,
    token_budget: int = 2000,
    format: Literal["markdown", "plain", "yaml"] = "markdown",  # noqa: A002
    hint: str | None = None,
    include_schema: bool = True,
    include_stats: bool = True,
    include_samples: bool = True,
    max_sample_rows: int = 5,
    columns: list[str] | None = None,
    tokenizer: str = "cl100k_base",
    config: ContextConfig | None = None,
) -> str:
    """Generate LLM context from a DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        The DataFrame to summarize.
    token_budget : int
        Maximum token count for the output.
    format : str
        Output format (``"markdown"``, ``"plain"``, ``"yaml"``).
    hint : str or None
        Query hint to prioritize relevant columns.
    include_schema : bool
        Include schema information.
    include_stats : bool
        Include column statistics.
    include_samples : bool
        Include sample rows.
    max_sample_rows : int
        Maximum sample rows to include.
    columns : list[str] or None
        Subset of columns to include. ``None`` means all.
    tokenizer : str
        tiktoken encoding name.
    config : ContextConfig or None
        Config object. If given, overrides individual keyword arguments.

    Returns
    -------
    str
        Context string for use with an LLM.
    """
    if config is not None:
        cfg = config
    else:
        cfg = ContextConfig(
            token_budget=token_budget,
            format=format,
            hint=hint,
            include_schema=include_schema,
            include_stats=include_stats,
            include_samples=include_samples,
            max_sample_rows=max_sample_rows,
            tokenizer=tokenizer,
        )

    if df.empty:
        return ""

    # Select columns
    if columns is not None:
        df = df[columns]

    tc = TokenCounter(cfg.tokenizer)
    formatter = _FORMATTERS[cfg.format]

    # Budget allocation
    allocator = TokenBudgetAllocator(cfg.budget_ratio)
    plan = allocator.allocate(
        df,
        cfg.token_budget,
        hint=cfg.hint,
        include_schema=cfg.include_schema,
        include_stats=cfg.include_stats,
        include_samples=cfg.include_samples,
    )

    parts: list[str] = []

    # Schema section
    if cfg.include_schema:
        schema_text = formatter.format_schema(df)
        if not tc.fits(schema_text, plan.schema_budget):
            schema_text = tc.truncate(
                schema_text, plan.schema_budget
            )
        parts.append(schema_text)

    # Stats section
    if cfg.include_stats:
        summaries = _analyze_all_columns(df, plan.column_budgets)
        stats_text = formatter.format_stats(summaries)
        if stats_text:
            parts.append(stats_text)

    # Samples section
    if cfg.include_samples and cfg.max_sample_rows > 0:
        sampler = RepresentativeSampler()
        sample_df = sampler.sample(df, cfg.max_sample_rows)
        samples_text = formatter.format_samples(
            sample_df, cfg.max_sample_rows
        )
        if samples_text:
            parts.append(samples_text)

    result = "\n\n".join(parts)

    # Final budget enforcement
    if not tc.fits(result, cfg.token_budget):
        result = tc.truncate(result, cfg.token_budget)

    return result


def analyze_columns(
    df: pd.DataFrame,
    columns: list[str] | None = None,
) -> dict[str, ColumnSummary]:
    """Analyze columns and return structured summaries.

    Parameters
    ----------
    df : pd.DataFrame
        The DataFrame to analyze.
    columns : list[str] or None
        Columns to analyze. ``None`` means all.

    Returns
    -------
    dict[str, ColumnSummary]
        Column name to summary mapping.
    """
    cols = columns or list(df.columns)
    result: dict[str, ColumnSummary] = {}
    for col in cols:
        col_type = classify_column(df[col])
        analyzer = _ANALYZERS.get(col_type, _ANALYZERS["text"])
        result[col] = analyzer.analyze(df[col], budget=200)
    return result


def count_tokens(
    text: str, tokenizer: str = "cl100k_base"
) -> int:
    """Count the number of tokens in text.

    Parameters
    ----------
    text : str
        The text to count tokens for.
    tokenizer : str
        tiktoken encoding name.

    Returns
    -------
    int
        Token count.
    """
    tc = TokenCounter(tokenizer)
    return tc.count(text)


def _analyze_all_columns(
    df: pd.DataFrame,
    column_budgets: dict[str, int],
) -> list[ColumnSummary]:
    """Analyze all columns with allocated budgets."""
    summaries: list[ColumnSummary] = []
    for col in df.columns:
        col_str = str(col)
        budget = column_budgets.get(col_str, 50)
        col_type = classify_column(df[col])
        analyzer = _ANALYZERS.get(col_type, _ANALYZERS["text"])
        summaries.append(analyzer.analyze(df[col], budget))
    return summaries
