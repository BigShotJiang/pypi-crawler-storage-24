# Chapter 8: Options Pricing and Volatility Strategies

This chapter is currently maintained in Chinese first.

- Chinese chapter: [第 8 章：期权定价与波动率策略](../../zh/textbook/08_options.md)
- Textbook home: [Chinese textbook index](../../zh/textbook/index.md)
- Practice links:
  - Primary example: [examples/textbook/ch08_options.py](https://github.com/akfamily/akquant/blob/main/examples/textbook/ch08_options.py)
  - Extended example: [examples/07_option_test.py](https://github.com/akfamily/akquant/blob/main/examples/07_option_test.py)
  - Guide: [Quant Basics Guide](../guide/quant_basics.md)
