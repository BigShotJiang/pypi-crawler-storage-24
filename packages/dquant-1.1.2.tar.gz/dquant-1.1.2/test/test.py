import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from src.dquant.models import VolClustGB, VolClustXGB, VolClustLightGBM
import MetaTrader5 as mt5
import datetime as dt
import numpy as np
from arch import arch_model
import pandas as pd



if __name__ == '__main__':
    # ===================== НАСТРОЙКИ =====================
    symbol = "EURUSD"          # какой символ смотреть
    timeframe = mt5.TIMEFRAME_H1   # M1, M5, M15, H1, D1 и т.д.
    days_back = 1000             # сколько дней истории загрузить
    # ====================================================

    # Подключаемся к MT5
    if not mt5.initialize():
        print("Не удалось подключиться к MetaTrader5")
        quit()

    # Проверяем, что символ доступен
    if not mt5.symbol_select(symbol, True):
        print(f"Символ {symbol} не найден или не включён")
        mt5.shutdown()
        quit()

    # Вычисляем даты
    #to_date = dt.datetime.fromisoformat('2026-03-24') + dt.timedelta(hours=3)
    to_date = dt.datetime.now() + dt.timedelta(hours=3)
    from_date = to_date - dt.timedelta(days=days_back)

    # Загружаем бары
    rates = mt5.copy_rates_range(symbol, timeframe, from_date, to_date)

    mt5.shutdown()  # больше не нужен терминал

    if rates is None or len(rates) == 0:
        print("Нет данных!")
        quit()

    # Превращаем в DataFrame
    df = pd.DataFrame(rates)
    df['time'] = pd.to_datetime(df['time'], unit='s')  # правильное время
    #df.set_index('time', inplace=True)


    df.rename(columns={
        'tick_volume': 'volume'
    }, inplace=True)



    #df = df.iloc[-20:]
    # Параметры для нижнего расположения
    #show_vol(df)

    print(f"Загружено {len(df)} баров с {df['time'].iloc[0]} по {df['time'].iloc[-1]}")

    """settings = {
        'loss': 'squared_error',
        'learning_rate': 0.1,
        'n_estimators': 1,
        'max_depth': 4,
        'min_samples_split': 5,
        'min_samples_leaf': 5,
        'subsample': 0.8,
        'random_state': 42,
        'warm_start': True
    }"""
    settings = {
        'objective': 'reg:squarederror',
        'learning_rate': 0.1,
        'n_estimators': 1,
        'max_depth': 3,
        'min_child_weight': 5,
        'subsample': 0.8,
        'random_state': 42
    }
    """settings = {
        'objective': 'regression',
        'learning_rate': 0.01,
        'n_estimators': 1,
        'max_depth': 3,
        'min_sum_hessian_in_leaf': 5,  # вместо min_child_weight
        'subsample': 0.8,  # или bagging_fraction
        'subsample_freq': 1,  # частота применения subsample
        'random_state': 42,
        'verbose': -1
    }"""
    params = {
        'objective': 'regression',
        'num_leaves': 7,  # небольшое количество листьев
        'min_data_in_leaf': 3,  # минимальное количество данных в листе
        'min_data_in_bin': 3,  # минимальное количество данных в бине
        'learning_rate': 0.1,  # маленький шаг обучения
        'verbosity': -1,  # отключаем вывод
        'seed': 42
    }
    model = VolClustXGB({}, early_stopping=True)


    while True:
        match input(">> "):
            case "clear":
                os.system('cls')
            case "train":
                lst = [
                    'TR',
                    'parkinson',
                    'garman_klass',
                    'rogers_satchell',
                    'returns',
                    'abs_returns',
                    'gap',
                    'body',
                    'shadow',
                    'close_position',
                    'roll_rsi_14',
                    'roll_atr_14',
                    'roll_bb_14',
                    'atr_14',
                    'rsi_14',
                    'bb_14',
                    'month',
                    'day_of_month',
                    'day_of_week',
                    'hour',
                    'roll_month',
                    'roll_day_of_month',
                    'roll_day_of_week',
                    'roll_hour',
                ]
                model.fit(df, lst, 100, 30, 2000, True)
            case "show":
                rez = model.forecast(df.iloc[-100:].copy(), show=True)
                print(rez)
            case "show train":
                model.show_train_results()
            case "save":
                model.save(str(input()))
            case "save_mql5":
                model.save(str(input()), 'mql5')
            case "load":
                model.load(str(input()))
            case "exit":
                break

    # Вывод результатов
    #print(np.array(df[-30:]))

    #model.forecast(df.iloc[-20:].copy())
