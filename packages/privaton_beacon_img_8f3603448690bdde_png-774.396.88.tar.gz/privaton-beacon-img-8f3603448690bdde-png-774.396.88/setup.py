from setuptools import setup
setup(name='privaton-beacon-img-8f3603448690bdde-png', version='774.396.88', py_modules=['data'])
