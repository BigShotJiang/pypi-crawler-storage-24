"""
Pytest configuration and fixtures for RComments tests.
"""

import os
import pytest
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_limiter import Limiter

# Set test environment before importing rcomments
os.environ["DATABASE_URL"] = "sqlite:///:memory:"
os.environ["SECRET_KEY"] = "test-secret-key"
os.environ["ALLOW_ANONYMOUS"] = "true"
os.environ["REQUIRE_EMAIL_ANONYMOUS"] = "false"

from rcomments import init_config, db as rcomments_db, Comment, init_routes
from rcomments.config import Config


@pytest.fixture(scope="session")
def app():
    """Create and configure a Flask app for testing."""
    app = Flask(__name__)
    app.config.from_object(Config)
    app.config["TESTING"] = True
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
    app.config["WTF_CSRF_ENABLED"] = False

    # Initialize config
    init_config()

    # Setup database
    rcomments_db.init_app(app)

    # Setup rate limiter
    limiter = Limiter(
        app=app,
        key_func=lambda: "test-client",
        default_limits=["1000 per hour"],
    )

    # Initialize routes
    init_routes(app, limiter)

    with app.app_context():
        rcomments_db.create_all()
        yield app
        rcomments_db.drop_all()


@pytest.fixture(scope="function")
def client(app):
    """A test client for the app."""
    return app.test_client()


@pytest.fixture(scope="function")
def db_session(app):
    """Provide a clean database session for each test."""
    with app.app_context():
        # Simply return the Flask-SQLAlchemy session
        # The session is automatically scoped to the app context
        yield rcomments_db.session

        # Rollback any uncommitted changes
        rcomments_db.session.rollback()


@pytest.fixture
def sample_comment(db_session):
    """Create a sample comment for testing."""
    comment = Comment(
        content="Test comment",
        author_name="Test User",
        author_email=None,
        is_anonymous=False,
        ip_hash="test-ip-hash",
        parent_id=None,
        status=Comment.Status.ACTIVE,
    )
    db_session.add(comment)
    db_session.commit()
    return comment


@pytest.fixture
def sample_thread(db_session):
    """Create a sample thread with replies for testing."""
    parent = Comment(
        content="Parent comment",
        author_name="Parent User",
        is_anonymous=False,
        ip_hash="hash1",
        status=Comment.Status.ACTIVE,
    )
    db_session.add(parent)
    db_session.flush()

    reply1 = Comment(
        content="First reply",
        author_name="Reply User 1",
        is_anonymous=False,
        ip_hash="hash2",
        parent_id=parent.id,
        status=Comment.Status.ACTIVE,
    )
    reply2 = Comment(
        content="Second reply",
        author_name="Reply User 2",
        is_anonymous=True,
        author_email="anon@example.com",
        ip_hash="hash3",
        parent_id=parent.id,
        status=Comment.Status.ACTIVE,
    )
    db_session.add_all([reply1, reply2])
    db_session.commit()

    return {"parent": parent, "replies": [reply1, reply2]}
