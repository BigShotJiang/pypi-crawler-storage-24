"""
Tests for Comment model.
"""

import pytest
from datetime import datetime, timezone
from rcomments.models import Comment, db


class TestCommentModel:
    """Tests for the Comment model."""

    def test_create_comment(self, db_session):
        """Test creating a basic comment."""
        comment = Comment(
            content="Hello World",
            author_name="Test User",
            is_anonymous=False,
            ip_hash="test-ip",
        )
        db_session.add(comment)
        db_session.commit()

        assert comment.id is not None
        assert comment.content == "Hello World"
        assert comment.author_name == "Test User"
        assert comment.is_anonymous is False
        assert comment.status == Comment.Status.ACTIVE
        assert comment.created_at is not None
        assert comment.parent_id is None

    def test_create_reply(self, db_session, sample_comment):
        """Test creating a reply to a comment."""
        reply = Comment(
            content="This is a reply",
            author_name="Reply User",
            parent_id=sample_comment.id,
            ip_hash="reply-ip",
        )
        db_session.add(reply)
        db_session.commit()

        assert reply.parent_id == sample_comment.id
        assert sample_comment.replies.count() == 1
        assert reply in sample_comment.replies

    def test_soft_delete(self, db_session, sample_comment):
        """Test soft deletion of a comment."""
        assert sample_comment.status == Comment.Status.ACTIVE
        assert sample_comment.content != "[Comment removed]"

        sample_comment.soft_delete()

        assert sample_comment.status == Comment.Status.DELETED
        assert sample_comment.content == "[Comment removed]"
        assert sample_comment.updated_at is not None

    def test_to_dict(self, db_session, sample_thread):
        """Test comment serialization to dictionary."""
        parent = sample_thread["parent"]
        data = parent.to_dict(include_replies=True)

        assert data["id"] == parent.id
        assert data["content"] == parent.content
        assert data["author_name"] == parent.author_name
        assert data["parent_id"] is None
        assert "replies" in data
        assert len(data["replies"]) == 2

        # Check that deleted comments show placeholder
        deleted_comment = parent.replies.first()
        deleted_comment.soft_delete()
        db_session.commit()

        data = parent.to_dict(include_replies=True)
        assert data["replies"][0]["content"] == "[Comment removed]"

    def test_get_threaded_comments(self, db_session, sample_thread):
        """Test fetching threaded comments."""
        comments = Comment.get_threaded_comments()

        assert len(comments) >= 1
        assert all(c.parent_id is None for c in comments)

    def test_anonymous_comment(self, db_session):
        """Test creating an anonymous comment."""
        comment = Comment(
            content="Anonymous post",
            author_name="Anonymous",
            is_anonymous=True,
            author_email="anon@example.com",
            ip_hash="anon-ip",
        )
        db_session.add(comment)
        db_session.commit()

        assert comment.is_anonymous is True
        assert comment.author_name == "Anonymous"
        assert comment.author_email == "anon@example.com"

    def test_email_validation_valid(self, db_session):
        """Test email validation with valid email."""
        comment = Comment(
            content="Test",
            author_name="Test",
            author_email="valid@example.com",
        )
        db_session.add(comment)
        db_session.commit()

        assert comment.author_email == "valid@example.com"

    def test_email_validation_invalid(self, db_session):
        """Test email validation with invalid email."""
        with pytest.raises(ValueError, match="Invalid email address"):
            comment = Comment(
                content="Test",
                author_name="Test",
                author_email="invalid-email",
            )
            db_session.add(comment)
            db_session.commit()

    def test_empty_content_validation(self, db_session):
        """Test that empty content is rejected."""
        with pytest.raises(ValueError, match="Comment content cannot be empty"):
            comment = Comment(
                content="   ",
                author_name="Test",
            )
            db_session.add(comment)
            db_session.commit()

    def test_timestamps(self, db_session):
        """Test automatic timestamp generation."""
        from datetime import datetime
        before = datetime.utcnow()
        comment = Comment(
            content="Test",
            author_name="Test",
            ip_hash="test",
        )
        db_session.add(comment)
        db_session.commit()
        after = datetime.utcnow()

        # Convert to naive for comparison if timezone-aware
        created_at = comment.created_at.replace(tzinfo=None) if comment.created_at.tzinfo else comment.created_at
        updated_at = comment.updated_at.replace(tzinfo=None) if comment.updated_at.tzinfo else comment.updated_at

        assert created_at >= before
        assert created_at <= after
        assert updated_at >= created_at

    def test_ordering(self, db_session):
        """Test that replies are ordered by created_at ascending."""
        parent = Comment(
            content="Parent",
            author_name="Parent",
            ip_hash="hash",
        )
        db_session.add(parent)
        db_session.flush()

        import time
        time.sleep(0.01)  # Small delay to ensure different timestamps

        reply1 = Comment(
            content="Reply 1",
            author_name="User 1",
            parent_id=parent.id,
            ip_hash="hash1",
        )
        time.sleep(0.01)
        reply2 = Comment(
            content="Reply 2",
            author_name="User 2",
            parent_id=parent.id,
            ip_hash="hash2",
        )
        db_session.add_all([reply1, reply2])
        db_session.commit()

        replies = parent.replies.order_by(None).all()  # Get all without ordering
        # The to_dict method orders by created_at.asc()
        data = parent.to_dict(include_replies=True)
        reply_ids = [r["id"] for r in data["replies"]]

        # Replies should be in ascending order by creation time
        assert reply_ids == sorted(reply_ids)
