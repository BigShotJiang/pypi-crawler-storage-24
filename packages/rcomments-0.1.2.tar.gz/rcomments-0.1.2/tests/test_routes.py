"""
Tests for comment routes and API endpoints.
"""

import pytest
from datetime import datetime, timezone, timedelta
from rcomments.models import Comment, db


class TestCommentRoutes:
    """Tests for the comment API routes."""

    def test_get_comments_empty(self, client):
        """Test fetching comments when database is empty."""
        response = client.get("/api/comments")
        assert response.status_code == 200
        data = response.get_json()
        assert data["success"] is True
        assert data["count"] == 0
        assert data["data"] == []

    def test_get_comments_with_data(self, client, sample_thread):
        """Test fetching comments with existing data."""
        response = client.get("/api/comments")
        assert response.status_code == 200
        data = response.get_json()
        assert data["success"] is True
        assert len(data["data"]) >= 1

        # Check structure of returned data
        comment = data["data"][0]
        assert "id" in comment
        assert "content" in comment
        assert "author_name" in comment
        assert "is_anonymous" in comment
        assert "status" in comment
        assert "created_at" in comment
        assert "replies" in comment

    def test_get_comments_sort_asc(self, client, sample_thread):
        """Test sorting comments ascending."""
        response = client.get("/api/comments?sort=asc")
        assert response.status_code == 200
        data = response.get_json()

        # Should have at least one top-level comment
        assert len(data["data"]) >= 1

    def test_get_comments_with_limit(self, client, sample_thread):
        """Test limiting number of comments."""
        response = client.get("/api/comments?limit=1")
        assert response.status_code == 200
        data = response.get_json()
        assert len(data["data"]) <= 1

    def test_create_comment(self, client):
        """Test creating a new comment."""
        payload = {
            "content": "This is a test comment",
            "author_name": "Test User",
            "is_anonymous": False,
        }
        response = client.post("/api/comments", json=payload)
        assert response.status_code == 201
        data = response.get_json()
        assert data["success"] is True
        assert data["data"]["content"] == "This is a test comment"
        assert data["data"]["author_name"] == "Test User"
        assert data["data"]["parent_id"] is None

    def test_create_comment_with_reply(self, client, sample_comment):
        """Test creating a reply to a comment."""
        payload = {
            "content": "This is a reply",
            "author_name": "Reply User",
            "parent_id": sample_comment.id,
            "is_anonymous": False,
        }
        response = client.post("/api/comments", json=payload)
        assert response.status_code == 201
        data = response.get_json()
        assert data["data"]["parent_id"] == sample_comment.id

    def test_create_comment_anonymous(self, client):
        """Test creating an anonymous comment."""
        payload = {
            "content": "Anonymous comment",
            "author_name": "Anonymous",
            "is_anonymous": True,
            "author_email": "anon@example.com",
        }
        response = client.post("/api/comments", json=payload)
        assert response.status_code == 201
        data = response.get_json()
        assert data["data"]["is_anonymous"] is True

    def test_create_comment_missing_content(self, client):
        """Test that missing content returns error."""
        payload = {
            "author_name": "Test User",
        }
        response = client.post("/api/comments", json=payload)
        assert response.status_code == 400
        data = response.get_json()
        assert data["success"] is False
        assert "content" in data["error"].lower()

    def test_create_comment_missing_author(self, client):
        """Test that missing author name returns error."""
        payload = {
            "content": "Test comment",
        }
        response = client.post("/api/comments", json=payload)
        assert response.status_code == 400
        data = response.get_json()
        assert data["success"] is False
        assert "author" in data["error"].lower()

    def test_create_comment_invalid_parent(self, client):
        """Test that non-existent parent returns error."""
        payload = {
            "content": "Reply to non-existent",
            "author_name": "Test User",
            "parent_id": 99999,
        }
        response = client.post("/api/comments", json=payload)
        assert response.status_code == 404

    def test_create_comment_empty_content(self, client):
        """Test that empty content is rejected."""
        payload = {
            "content": "   ",
            "author_name": "Test User",
        }
        response = client.post("/api/comments", json=payload)
        assert response.status_code == 400

    def test_get_comment(self, client, sample_comment):
        """Test fetching a single comment."""
        response = client.get(f"/api/comments/{sample_comment.id}")
        assert response.status_code == 200
        data = response.get_json()
        assert data["success"] is True
        assert data["data"]["id"] == sample_comment.id

    def test_get_comment_not_found(self, client):
        """Test fetching non-existent comment."""
        response = client.get("/api/comments/99999")
        assert response.status_code == 404

    def test_delete_comment(self, client, sample_comment):
        """Test soft deleting a comment."""
        response = client.delete(f"/api/comments/{sample_comment.id}")
        assert response.status_code == 200
        data = response.get_json()
        assert data["success"] is True

        # Verify comment is marked as deleted
        get_response = client.get(f"/api/comments/{sample_comment.id}")
        comment_data = get_response.get_json()["data"]
        assert comment_data["status"] == "DELETED"
        assert comment_data["content"] == "[Comment removed]"

    def test_delete_comment_already_deleted(self, client, sample_comment):
        """Test deleting an already deleted comment."""
        # First delete
        client.delete(f"/api/comments/{sample_comment.id}")

        # Second delete
        response = client.delete(f"/api/comments/{sample_comment.id}")
        assert response.status_code == 400

    def test_delete_comment_not_found(self, client):
        """Test deleting non-existent comment."""
        response = client.delete("/api/comments/99999")
        assert response.status_code == 404

    def test_get_replies(self, client, sample_thread):
        """Test fetching replies for a comment."""
        parent = sample_thread["parent"]
        response = client.get(f"/api/comments/{parent.id}/replies")
        assert response.status_code == 200
        data = response.get_json()
        assert data["success"] is True
        assert len(data["data"]) == 2

    def test_get_replies_not_found(self, client):
        """Test fetching replies for non-existent comment."""
        response = client.get("/api/comments/99999/replies")
        assert response.status_code == 404

    def test_get_stats(self, client, sample_thread):
        """Test fetching comment statistics."""
        response = client.get("/api/comments/stats")
        assert response.status_code == 200
        data = response.get_json()
        assert data["success"] is True
        assert "total" in data["data"]
        assert "active" in data["data"]
        assert "deleted" in data["data"]
        assert "top_level" in data["data"]
        assert "limits" in data["data"]
        assert "usage" in data["data"]

    def test_xss_protection(self, client):
        """Test that XSS payloads are sanitized."""
        xss_payload = {
            "content": "<script>alert('XSS')</script><b>Bold text</b>",
            "author_name": "Test User",
        }
        response = client.post("/api/comments", json=xss_payload)
        assert response.status_code == 201
        data = response.get_json()

        # Script tags should be removed, bold should remain
        assert "<script>" not in data["data"]["content"]
        assert "</script>" not in data["data"]["content"]
        # The text inside script may remain, but tags are stripped
        assert "<b>" in data["data"]["content"] or "Bold text" in data["data"]["content"]

    def test_hierarchical_threading(self, client, sample_thread):
        """Test that nested replies are properly structured."""
        parent = sample_thread["parent"]
        response = client.get(f"/api/comments/{parent.id}")
        assert response.status_code == 200
        data = response.get_json()

        assert len(data["data"]["replies"]) == 2
        for reply in data["data"]["replies"]:
            assert reply["parent_id"] == parent.id
            assert "replies" in reply  # Should have empty replies array

    def test_cleanup_endpoint(self, client, db_session, sample_thread):
        """Test the cleanup endpoint."""
        response = client.post("/api/comments/cleanup?dry_run=true")
        assert response.status_code == 200
        data = response.get_json()
        assert data["success"] is True
        assert "deleted_by_age" in data["data"]
        assert "deleted_by_count" in data["data"]
        assert "remaining" in data["data"]

    def test_rate_limiting(self, client):
        """Test rate limiting (basic check)."""
        # This is a basic test - actual rate limiting depends on configuration
        # In production, you'd test with more requests
        for i in range(5):
            payload = {
                "content": f"Comment {i}",
                "author_name": f"User {i}",
            }
            response = client.post("/api/comments", json=payload)
            # Should succeed for first few requests
            assert response.status_code in (201, 429)

    def test_ip_hashing(self, client, app):
        """Test that IP addresses are hashed."""
        with client as c:
            # Set a test IP
            c.environ_base["REMOTE_ADDR"] = "192.168.1.100"

            payload = {
                "content": "Test comment",
                "author_name": "Test User",
            }
            response = c.post("/api/comments", json=payload)
            assert response.status_code == 201

            # Get the created comment from database
            comment = Comment.query.order_by(Comment.id.desc()).first()
            assert comment is not None
            assert comment.ip_hash is not None
            assert comment.ip_hash != "192.168.1.100"
            assert len(comment.ip_hash) == 64  # SHA-256 produces 64 hex chars
