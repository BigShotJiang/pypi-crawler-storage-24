"""
Command-line interface for RComments management.
"""

import click
from flask import Flask
from flask_migrate import Migrate, upgrade, migrate, init, stamp
from .config import init_config
from .models import db
from .utils import cleanup_old_comments


@click.group()
def cli():
    """RComments command-line interface."""
    pass


@cli.command()
@click.option("--config", "-c", help="Path to .env file")
def init_db(config):
    """Initialize database and migrations."""
    if config:
        import os
        from dotenv import load_dotenv
        load_dotenv(config)

    init_config()

    app = Flask(__name__)
    app.config.from_object("rcomments.config")
    db.init_app(app)

    with app.app_context():
        # Initialize migrations
        try:
            init()
            click.echo("✓ Migration repository initialized")
        except Exception as e:
            click.echo(f"! Migration repository already exists: {e}")

        # Create initial migration
        migrate()
        click.echo("✓ Migration script created")

        # Apply migration
        upgrade()
        click.echo("✓ Database tables created")


@cli.command()
@click.option("--config", "-c", help="Path to .env file")
def migrate_db(config):
    """Create and apply database migrations."""
    if config:
        import os
        from dotenv import load_dotenv
        load_dotenv(config)

    init_config()

    app = Flask(__name__)
    app.config.from_object("rcomments.config")
    db.init_app(app)

    with app.app_context():
        migrate()
        click.echo("✓ Migration script created")
        upgrade()
        click.echo("✓ Migration applied")


@cli.command()
@click.option("--dry-run", is_flag=True, help="Show what would be deleted without deleting")
@click.option("--config", "-c", help="Path to .env file")
def cleanup(dry_run, config):
    """Clean up old comments based on limits."""
    if config:
        import os
        from dotenv import load_dotenv
        load_dotenv(config)

    init_config()

    app = Flask(__name__)
    app.config.from_object("rcomments.config")
    db.init_app(app)

    with app.app_context():
        stats = cleanup_old_comments(db.session, dry_run=dry_run)

        click.echo("\nCleanup Statistics:")
        click.echo(f"  Deleted by age: {stats['deleted_by_age']}")
        click.echo(f"  Deleted by count limit: {stats['deleted_by_count']}")
        click.echo(f"  Remaining active: {stats['remaining']}")


@cli.command()
@click.option("--config", "-c", help="Path to .env file")
def stats(config):
    """Show comment statistics."""
    if config:
        import os
        from dotenv import load_dotenv
        load_dotenv(config)

    init_config()

    from .models import Comment

    app = Flask(__name__)
    app.config.from_object("rcomments.config")
    db.init_app(app)

    with app.app_context():
        total = Comment.query.count()
        active = Comment.query.filter_by(status=Comment.Status.ACTIVE).count()
        deleted = Comment.query.filter_by(status=Comment.Status.DELETED).count()
        top_level = Comment.query.filter_by(parent_id=None, status=Comment.Status.ACTIVE).count()

        click.echo("\nComment Statistics:")
        click.echo(f"  Total comments: {total}")
        click.echo(f"  Active: {active}")
        click.echo(f"  Deleted: {deleted}")
        click.echo(f"  Top-level: {top_level}")


def main():
    """Entry point for the CLI."""
    cli()


if __name__ == "__main__":
    main()
