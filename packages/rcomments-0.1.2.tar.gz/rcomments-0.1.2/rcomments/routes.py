"""
Flask routes for RComments commenting system.
"""

from datetime import datetime, timezone
from flask import Blueprint, request, jsonify, current_app
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from sqlalchemy.exc import IntegrityError
from .models import db, Comment
from .config import get_config
from .utils import sanitize_html, hash_ip_address, get_client_ip, cleanup_old_comments

# Create blueprint
comments_bp = Blueprint("comments", __name__, url_prefix="/api/comments")


def init_routes(app, limiter=None):
    """
    Initialize comment routes with Flask app.

    Args:
        app: Flask application instance
        limiter: Optional Flask-Limiter instance
    """
    if limiter is None:
        # Create limiter if not provided
        limiter = Limiter(
            app=app,
            key_func=get_remote_address,
            default_limits=["200 per day", "50 per hour"],
        )

    # Store limiter in app for use in routes
    app.comments_limiter = limiter

    # Register blueprint
    app.register_blueprint(comments_bp)

    # Apply rate limit to create_comment endpoint after registration
    config = get_config()
    create_comment_view = app.view_functions["comments.create_comment"]
    limited = limiter.limit(config.RATE_LIMIT)(create_comment_view)
    app.view_functions["comments.create_comment"] = limited

    # Create tables if they don't exist
    with app.app_context():
        db.create_all()


def _apply_rate_limit():
    """Apply rate limit from config to the create_comment endpoint."""
    from flask import current_app
    config = get_config()
    if hasattr(current_app, 'comments_limiter'):
        return current_app.comments_limiter.limit(config.RATE_LIMIT)
    return None


@comments_bp.route("", methods=["GET"])
def get_comments():
    """
    Get all top-level comments with nested replies.

    Query params:
        sort: 'asc' or 'desc' (default: desc by created_at)
        limit: Maximum number of top-level comments

    Returns:
        JSON with list of threaded comments
    """
    try:
        sort = request.args.get("sort", "desc")
        limit = request.args.get("limit", type=int)

        query = Comment.query.filter_by(parent_id=None, status=Comment.Status.ACTIVE)

        if sort == "asc":
            query = query.order_by(Comment.created_at.asc())
        else:
            query = query.order_by(Comment.created_at.desc())

        if limit:
            query = query.limit(limit)

        comments = query.all()
        result = [comment.to_dict(include_replies=True) for comment in comments]

        return jsonify({
            "success": True,
            "data": result,
            "count": len(result),
        }), 200

    except Exception as e:
        current_app.logger.error(f"Error fetching comments: {e}")
        return jsonify({"success": False, "error": "Failed to fetch comments"}), 500


@comments_bp.route("", methods=["POST"])
def create_comment():
    """
    Create a new comment.

    Required JSON fields:
        content: Comment text (will be sanitized)
        author_name: Display name

    Optional fields:
        author_email: Email (required if anonymous and config requires it)
        parent_id: ID of parent comment for threading
        is_anonymous: Boolean (default: false)

    Returns:
        JSON with created comment data
    """
    try:
        data = request.get_json()

        if not data:
            return jsonify({"success": False, "error": "No data provided"}), 400

        # Validate required fields
        content = data.get("content", "").strip()
        author_name = data.get("author_name", "").strip()

        if not content:
            return jsonify({"success": False, "error": "Content is required"}), 400

        if not author_name:
            return jsonify({"success": False, "error": "Author name is required"}), 400

        # Sanitize content
        sanitized_content = sanitize_html(content)

        if not sanitized_content:
            return jsonify({"success": False, "error": "Content contains no valid text after sanitization"}), 400

        # Check if parent comment exists and is active
        parent_id = data.get("parent_id")
        if parent_id:
            parent = Comment.query.get(parent_id)
            if not parent:
                return jsonify({"success": False, "error": "Parent comment not found"}), 404
            if parent.status != Comment.Status.ACTIVE:
                return jsonify({"success": False, "error": "Cannot reply to a deleted comment"}), 400

        # Check if anonymous is allowed
        is_anonymous = data.get("is_anonymous", False)
        config = get_config()

        if is_anonymous and not config.ALLOW_ANONYMOUS:
            return jsonify({"success": False, "error": "Anonymous comments are not allowed"}), 403

        # Validate email if required
        author_email = data.get("author_email", "").strip() if data.get("author_email") else None

        if is_anonymous and config.REQUIRE_EMAIL_ANONYMOUS and not author_email:
            return jsonify({"success": False, "error": "Email is required for anonymous comments"}), 400

        # Hash IP address
        ip_address = get_client_ip()
        ip_hash = hash_ip_address(ip_address)

        # Create comment
        comment = Comment(
            content=sanitized_content,
            author_name=author_name,
            author_email=author_email,
            is_anonymous=is_anonymous,
            ip_hash=ip_hash,
            parent_id=parent_id,
            status=Comment.Status.ACTIVE,
        )

        db.session.add(comment)
        db.session.commit()

        return jsonify({
            "success": True,
            "data": comment.to_dict(include_replies=False),
            "message": "Comment created successfully"
        }), 201

    except IntegrityError:
        db.session.rollback()
        return jsonify({"success": False, "error": "Database integrity error"}), 400

    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error creating comment: {e}")
        return jsonify({"success": False, "error": "Failed to create comment"}), 500


@comments_bp.route("/<int:comment_id>", methods=["GET"])
def get_comment(comment_id):
    """
    Get a single comment by ID.

    Args:
        comment_id: Comment ID

    Returns:
        JSON with comment data
    """
    try:
        comment = Comment.query.get(comment_id)

        if not comment:
            return jsonify({"success": False, "error": "Comment not found"}), 404

        return jsonify({
            "success": True,
            "data": comment.to_dict(include_replies=True),
        }), 200

    except Exception as e:
        current_app.logger.error(f"Error fetching comment {comment_id}: {e}")
        return jsonify({"success": False, "error": "Failed to fetch comment"}), 500


@comments_bp.route("/<int:comment_id>", methods=["DELETE"])
def delete_comment(comment_id):
    """
    Soft delete a comment.

    Args:
        comment_id: Comment ID

    Returns:
        JSON success/error
    """
    try:
        comment = Comment.query.get(comment_id)

        if not comment:
            return jsonify({"success": False, "error": "Comment not found"}), 404

        if comment.status == Comment.Status.DELETED:
            return jsonify({"success": False, "error": "Comment already deleted"}), 400

        comment.soft_delete()
        db.session.commit()

        return jsonify({
            "success": True,
            "message": "Comment deleted successfully"
        }), 200

    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error deleting comment {comment_id}: {e}")
        return jsonify({"success": False, "error": "Failed to delete comment"}), 500


@comments_bp.route("/<int:comment_id>/replies", methods=["GET"])
def get_replies(comment_id):
    """
    Get direct replies for a comment.

    Args:
        comment_id: Parent comment ID

    Returns:
        JSON with list of replies
    """
    try:
        parent = Comment.query.get(comment_id)

        if not parent:
            return jsonify({"success": False, "error": "Comment not found"}), 404

        replies = (
            Comment.query.filter_by(
                parent_id=comment_id,
                status=Comment.Status.ACTIVE
            )
            .order_by(Comment.created_at.asc())
            .all()
        )

        return jsonify({
            "success": True,
            "data": [reply.to_dict(include_replies=False) for reply in replies],
            "count": len(replies),
        }), 200

    except Exception as e:
        current_app.logger.error(f"Error fetching replies for {comment_id}: {e}")
        return jsonify({"success": False, "error": "Failed to fetch replies"}), 500


@comments_bp.route("/cleanup", methods=["POST"])
def trigger_cleanup():
    """
    Trigger cleanup of old comments (admin endpoint).

    This endpoint should be secured in production (e.g., with API key or authentication).

    Query params:
        dry_run: If 'true', only report what would be deleted

    Returns:
        JSON with cleanup statistics
    """
    try:
        # WARNING: This endpoint should be secured in production!
        # Consider adding authentication/authorization here

        dry_run = request.args.get("dry_run", "false").lower() == "true"

        stats = cleanup_old_comments(db.session, dry_run=dry_run)

        return jsonify({
            "success": True,
            "data": stats,
            "message": "Cleanup completed" + (" (dry run)" if dry_run else "")
        }), 200

    except Exception as e:
        current_app.logger.error(f"Error during cleanup: {e}")
        return jsonify({"success": False, "error": "Cleanup failed"}), 500


@comments_bp.route("/stats", methods=["GET"])
def get_stats():
    """
    Get comment statistics.

    Returns:
        JSON with counts and limits
    """
    try:
        config = get_config()

        total_comments = Comment.query.count()
        active_comments = Comment.query.filter_by(status=Comment.Status.ACTIVE).count()
        deleted_comments = Comment.query.filter_by(status=Comment.Status.DELETED).count()
        top_level = Comment.query.filter_by(parent_id=None, status=Comment.Status.ACTIVE).count()

        return jsonify({
            "success": True,
            "data": {
                "total": total_comments,
                "active": active_comments,
                "deleted": deleted_comments,
                "top_level": top_level,
                "limits": {
                    "max_age_days": config.MAX_COMMENT_AGE_DAYS,
                    "max_total": config.MAX_TOTAL_COMMENTS,
                },
                "usage": {
                    "percent_of_limit": round((active_comments / config.MAX_TOTAL_COMMENTS) * 100, 2) if config.MAX_TOTAL_COMMENTS > 0 else 0,
                }
            }
        }), 200

    except Exception as e:
        current_app.logger.error(f"Error fetching stats: {e}")
        return jsonify({"success": False, "error": "Failed to fetch stats"}), 500
