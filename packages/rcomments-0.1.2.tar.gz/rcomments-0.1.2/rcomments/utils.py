"""
Utility functions for RComments.
"""

import hashlib
from typing import Optional
from flask import request
from bleach import clean
from .config import get_config


def sanitize_html(content: str) -> str:
    """
    Sanitize HTML content to prevent XSS attacks.

    Args:
        content: Raw comment text

    Returns:
        Sanitized HTML with allowed tags only
    """
    # Allow only basic formatting tags
    allowed_tags = ["b", "i", "u", "em", "strong", "br", "p"]
    allowed_attributes = {}

    return clean(
        content,
        tags=allowed_tags,
        attributes=allowed_attributes,
        strip=True,
    )


def hash_ip_address(ip_address: str) -> str:
    """
    Hash IP address for privacy while maintaining uniqueness for moderation.

    Args:
        ip_address: Raw IP address

    Returns:
        SHA-256 hash of IP address
    """
    return hashlib.sha256(ip_address.encode()).hexdigest()


def get_client_ip() -> str:
    """
    Get client IP address from request, handling proxies.

    Returns:
        IP address string
    """
    if request.headers.getlist("X-Forwarded-For"):
        # If behind proxy, use first IP in X-Forwarded-For
        ip = request.headers.getlist("X-Forwarded-For")[0].strip()
    else:
        ip = request.remote_addr or "0.0.0.0"
    return ip


def cleanup_old_comments(db_session, dry_run: bool = False) -> dict:
    """
    Clean up old comments based on age and total count limits.

    Args:
        db_session: SQLAlchemy database session
        dry_run: If True, only report what would be deleted

    Returns:
        Dictionary with deletion statistics
    """
    from .models import Comment, db

    config = get_config()
    stats = {
        "deleted_by_age": 0,
        "deleted_by_count": 0,
        "remaining": 0,
    }

    # Calculate cutoff date
    from datetime import datetime, timezone, timedelta
    cutoff_date = datetime.now(timezone.utc) - timedelta(days=config.MAX_COMMENT_AGE_DAYS)

    # Delete comments older than cutoff
    old_comments = (
        Comment.query.filter(
            Comment.created_at < cutoff_date,
            Comment.status == Comment.Status.ACTIVE,
        )
        .all()
    )

    if dry_run:
        stats["deleted_by_age"] = len(old_comments)
    else:
        for comment in old_comments:
            db.session.delete(comment)
        db.session.commit()
        stats["deleted_by_age"] = len(old_comments)

    # Check total comment count and delete oldest if over limit
    total_active = Comment.query.filter_by(status=Comment.Status.ACTIVE).count()

    if total_active > config.MAX_TOTAL_COMMENTS:
        excess = total_active - config.MAX_TOTAL_COMMENTS

        # Get oldest active comments (prioritize replies, then oldest)
        oldest = (
            Comment.query.filter_by(status=Comment.Status.ACTIVE)
            .order_by(Comment.created_at.asc(), Comment.parent_id.asc())
            .limit(excess)
            .all()
        )

        if dry_run:
            stats["deleted_by_count"] = len(oldest)
        else:
            for comment in oldest:
                db.session.delete(comment)
            db.session.commit()
            stats["deleted_by_count"] = len(oldest)

    # Count remaining
    if dry_run:
        stats["remaining"] = total_active - stats["deleted_by_age"] - stats["deleted_by_count"]
    else:
        stats["remaining"] = Comment.query.filter_by(status=Comment.Status.ACTIVE).count()

    return stats
