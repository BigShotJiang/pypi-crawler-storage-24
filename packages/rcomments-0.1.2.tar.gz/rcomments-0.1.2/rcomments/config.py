"""
Configuration management for RComments.
Loads settings from environment variables with .env support.
"""

import os
from dataclasses import dataclass
from typing import Optional
from dotenv import load_dotenv

load_dotenv()


@dataclass
class Config:
    """Configuration settings for RComments."""

    # Database
    DATABASE_URL: str = "postgresql://localhost/rcomments"

    # Rate limiting
    RATE_LIMIT: str = "10 per minute"  # Default: 10 comments per minute

    # Comment storage limits
    MAX_COMMENT_AGE_DAYS: int = os.getenv("MAX_COMMENT_AGE_DAYS")
    MAX_TOTAL_COMMENTS: int = os.getenv("MAX_TOTAL_COMMENTS")

    # Security
    ALLOW_ANONYMOUS: bool = True
    REQUIRE_EMAIL_ANONYMOUS: bool = False  # Require email even for anonymous

    # Flask
    SECRET_KEY: str = "dev-secret-key-change-in-production"

    @classmethod
    def from_env(cls) -> "Config":
        """Load configuration from environment variables."""
        config = cls()

        # Override with environment variables
        if db_url := os.getenv("DATABASE_URL"):
            config.DATABASE_URL = db_url

        if rate_limit := os.getenv("RATE_LIMIT"):
            config.RATE_LIMIT = rate_limit

        if max_age := os.getenv("MAX_COMMENT_AGE_DAYS"):
            config.MAX_COMMENT_AGE_DAYS = int(max_age)

        if max_comments := os.getenv("MAX_TOTAL_COMMENTS"):
            config.MAX_TOTAL_COMMENTS = int(max_comments)

        if secret_key := os.getenv("SECRET_KEY"):
            config.SECRET_KEY = secret_key

        if allow_anon := os.getenv("ALLOW_ANONYMOUS"):
            config.ALLOW_ANONYMOUS = allow_anon.lower() in ("true", "1", "yes")

        if require_email := os.getenv("REQUIRE_EMAIL_ANONYMOUS"):
            config.REQUIRE_EMAIL_ANONYMOUS = require_email.lower() in ("true", "1", "yes")

        return config


# Global config instance
_config: Optional[Config] = None


def init_config() -> Config:
    """Initialize and return the global configuration."""
    global _config
    _config = Config.from_env()
    return _config


def get_config() -> Config:
    """Get the global configuration instance."""
    if _config is None:
        init_config()
    return _config
