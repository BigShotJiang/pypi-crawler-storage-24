"""
Database models for RComments.
"""

from datetime import datetime, timezone
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import validates

db = SQLAlchemy()


class Comment(db.Model):
    """
    Comment model with hierarchical threading, soft deletion, and metadata tracking.

    Attributes:
        id: Primary key
        content: Sanitized comment text (HTML escaped)
        author_name: Display name (username or "Anonymous")
        author_email: Optional email for anonymous comments
        is_anonymous: Boolean flag for anonymous comments
        ip_address: IP address for moderation (stored as hashed)
        parent_id: Foreign key to parent comment for threading
        status: Comment status (ACTIVE, DELETED, PENDING)
        created_at: UTC timestamp
        updated_at: UTC timestamp
    """

    class Status:
        ACTIVE = "ACTIVE"
        DELETED = "DELETED"
        PENDING = "PENDING"

    __tablename__ = "comments"

    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text, nullable=False)
    author_name = db.Column(db.String(100), nullable=False)
    author_email = db.Column(db.String(255), nullable=True)
    is_anonymous = db.Column(db.Boolean, default=False, nullable=False)
    ip_hash = db.Column(db.String(64), nullable=True)  # SHA-256 hash of IP
    parent_id = db.Column(db.Integer, db.ForeignKey("comments.id"), nullable=True)
    status = db.Column(
        db.String(20), default=Status.ACTIVE, nullable=False
    )
    created_at = db.Column(
        db.DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        nullable=False,
    )
    updated_at = db.Column(
        db.DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )

    # Self-referential relationship for hierarchical threading
    replies = db.relationship(
        "Comment",
        backref=db.backref("parent", remote_side=[id]),
        lazy="dynamic",
        cascade="all, delete-orphan",
    )

    @validates("author_email")
    def validate_email(self, key, email):
        """Validate email format if provided."""
        if email:
            from email_validator import validate_email, EmailNotValidError
            try:
                # Validate email format only, skip DNS checks for deliverability
                valid = validate_email(email, check_deliverability=False)
                return valid.email
            except EmailNotValidError:
                raise ValueError(f"Invalid email address: {email}")
        return email

    @validates("content")
    def validate_content(self, key, content):
        """Ensure content is not empty after sanitization."""
        if not content or not content.strip():
            raise ValueError("Comment content cannot be empty")
        return content.strip()

    def soft_delete(self):
        """Soft delete this comment."""
        self.status = self.Status.DELETED
        self.content = "[Comment removed]"
        self.updated_at = datetime.now(timezone.utc)

    def to_dict(self, include_replies=True):
        """
        Convert comment to dictionary for JSON serialization.

        Args:
            include_replies: Whether to include nested replies

        Returns:
            Dictionary representation of comment
        """
        data = {
            "id": self.id,
            "content": self.content if self.status == self.Status.ACTIVE else "[Comment removed]",
            "author_name": self.author_name,
            "is_anonymous": self.is_anonymous,
            "status": self.status,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "parent_id": self.parent_id,
        }

        if include_replies:
            # Include all replies (including deleted ones) to maintain thread structure
            data["replies"] = [
                reply.to_dict(include_replies=True)
                for reply in self.replies.order_by(Comment.created_at.asc()).all()
            ]
        else:
            data["replies"] = []

        return data

    @classmethod
    def get_threaded_comments(cls):
        """
        Get all top-level comments with their nested replies.

        Returns:
            List of top-level comments with nested replies
        """
        return (
            cls.query.filter_by(parent_id=None, status=cls.Status.ACTIVE)
            .order_by(cls.created_at.desc())
            .all()
        )

    def __repr__(self):
        return f"<Comment {self.id} by {self.author_name}>"
