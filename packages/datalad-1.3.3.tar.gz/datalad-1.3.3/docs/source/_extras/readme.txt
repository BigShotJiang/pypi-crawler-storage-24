Directory used by sphinx
