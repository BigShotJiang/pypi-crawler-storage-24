"""Quizbase module."""
