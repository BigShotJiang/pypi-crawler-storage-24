from setuptools import setup, find_packages

setup(
    name="things-pytools-dasheer",
    version="0.3.1",
    packages=find_packages(),
)