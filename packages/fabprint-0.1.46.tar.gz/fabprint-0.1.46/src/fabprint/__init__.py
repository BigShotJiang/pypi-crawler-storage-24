"""fabprint — Immutable 3D print pipeline."""

__version__ = "0.1.46"


class FabprintError(Exception):
    """User-facing error — printed without a traceback."""
