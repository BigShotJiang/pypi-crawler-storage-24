pydantic-expost
===============

```python
from __future__ import annotations  # py 3.13-

from typing import Any, Self

from pydantic import validate_call, ConfigDict
from pydantic_expost import validate_call_expost


c = ConfigDict(arbitrary_types_allowed=True, validate_return=True)


try:
  @validate_call(config=c)
  def f(a: A, b: B) -> tuple[A, B]:
    return a, b
except:
  print('validate_call(f) --> raise')


@validate_call_expost(config=c)
def f(a: A, b: B) -> tuple[A, B]:
  return a, b
print('validate_call_expost(f) --> ok')


class A:

  try:
    @validate_call(config=c)
    def b(self: Any, b: B) -> Any:
      ...
  except:
    print('validate_call(A.b) --> raise')

  @validate_call_expost(config=c)
  def b(self: Any, b: B) -> Any:
    ...
  print('validate_call_expost(A.b) --> ok')

class B:
  ...


f(A(), B())
print('f(A(), B()) --> ok')

try:
  f(B(), A())    # raise
except:
  print('f(B(), A()) --> raise')

A().b(B())
print('A().b(B()) --> ok')

A.b('A', B())
print('A.b("A", B()) --> ok !')

try:
  A().b('B')
except:
  print('A().b("B") --> raise')
```
