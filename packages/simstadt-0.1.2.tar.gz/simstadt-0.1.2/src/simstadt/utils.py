import datetime
import logging
import os
import random
import re
import shutil
import string
from contextlib import contextmanager
from pathlib import Path

import numpy as np

WORKFLOW_FOLDER_PATTERN = re.compile(r"(20\d{6}_\d{4})_[a-z0-9]{4}")

log = logging.getLogger(__name__)


def set_random_seed(input_string: str) -> None:
    """Seed both random and numpy from a string so sampling is reproducible between runs."""
    random.seed(input_string)
    np.random.seed(random.randrange(1000))


def random_id(n: int = 4, time: bool = True) -> str:
    """Return a random string of n chars, optionally prefixed with YYYYMMDD_HHMM.
    Uses a fresh Random() instance to avoid being affected by set_random_seed()."""
    generator = random.Random()
    generator.seed()
    result = "".join(generator.choices(string.ascii_lowercase + string.digits, k=n))
    if time:
        result = datetime.datetime.now().strftime("%Y%m%d_%H%M_") + result
    return result


def remove_random_id(text: str) -> str:
    """Strip a leading random_id prefix from a filename."""
    return re.sub(r"^(20\d{6}_\d{4}_)?[a-z0-9]{4}_", "", text)


def clean_old_workflows(folder: Path, pattern: str = "20*.flow", hours: int = 1) -> None:
    """Remove timestamped workflow folders older than `hours` from `folder`.

    Only deletes paths whose names match the random_id timestamp pattern.
    """
    # TODO: Should it be called before simulation too?
    cutoff = (datetime.datetime.now() - datetime.timedelta(hours=hours)).strftime("%Y%m%d_%H%M_")
    for path in sorted(folder.glob(pattern)):
        if m := WORKFLOW_FOLDER_PATTERN.match(path.name):
            if m.group(1) < cutoff:
                log.info("Removing old workflow: %s", path.name)
                shutil.rmtree(path) if path.is_dir() else path.unlink()


@contextmanager
def chdir(path: Path):
    """Context manager that temporarily changes the working directory."""
    oldpwd = os.getcwd()
    os.chdir(path)
    try:
        yield
    finally:
        os.chdir(oldpwd)
