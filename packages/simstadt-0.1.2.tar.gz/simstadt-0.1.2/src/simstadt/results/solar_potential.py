from dataclasses import dataclass
from typing import ClassVar

import pandas as pd

from .base import SimStadtResults
from .kpi import KPI
from .providers import Providers


@dataclass(repr=False)
class SolarPotentialResults(SimStadtResults):
    """Results for SolarPotential workflows.

    The output is a .prn weather file with 8760 hourly rows and three columns:
    GHI (W/m²), DHI (W/m²), Ta (°C).
    """

    supported_providers: ClassVar[list[str]] = [Providers.SOLAR_POTENTIAL]
    csv_identifier = "_solar_potential"  # no CSV output; csv_path will raise if called

    def _parse_results(self) -> pd.DataFrame:
        prn_paths = self.get_all_by_extension(".prn")
        if len(prn_paths) != 1:
            raise ValueError(f"Expected exactly one .prn file, found {len(prn_paths)}")
        return pd.read_csv(
            prn_paths[0], sep=r"\s+", names=["GHI", "DHI", "Ta"], header=None
        )

    @property
    def kpis(self) -> list[KPI]:
        df = self.dataframe
        return [
            KPI("Annual GHI", df["GHI"].sum() / 1000, "kWh / m²", precision=1),
            KPI("Average GHI", df["GHI"].mean(), "W / m²", precision=1),
            KPI("Annual DHI", df["DHI"].sum() / 1000, "kWh / m²", precision=1),
            KPI("Average DHI", df["DHI"].mean(), "W / m²", precision=1),
            KPI("Average temperature", float(df["Ta"].mean()), "°C", precision=1),
        ]
