# mcpzoo-timestamp

> 时间戳转换 — Unix 时间戳与日期时间字符串互转

## Installation

```bash
uvx mcpzoo-timestamp
```

## uvx JSON

```json
{
  "mcpServers": {
    "timestamp": {
      "args": ["mcpzoo-timestamp"],
      "command": "uvx"
    }
  }
}
```
