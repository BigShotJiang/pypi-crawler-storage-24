import datetime
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("timestamp")


@mcp.tool()
def timestamp_to_datetime(timestamp: float) -> str:
    """Unix 时间戳（秒）转为本地日期时间。"""
    try:
        dt = datetime.datetime.fromtimestamp(timestamp)
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except Exception as e:
        return f"转换错误: {e}"

@mcp.tool()
def datetime_to_timestamp(date_str: str, fmt: str = "%Y-%m-%d %H:%M:%S") -> str:
    """日期时间字符串转为 Unix 时间戳（秒）。"""
    try:
        dt = datetime.datetime.strptime(date_str, fmt)
        return str(dt.timestamp())
    except Exception as e:
        return f"转换错误: {e}"


def main():
    mcp.run()


if __name__ == "__main__":
    main()
