"""Tests for skill definitions and registration."""
import pytest
from unittest.mock import patch

from pillar import Pillar, define_skill
from pillar._skill import SkillDefinition


class TestDefineSkill:
    def test_returns_skill_definition(self):
        skill = define_skill(
            name="setup-guide",
            description="How to set up billing",
            content="# Setup Guide",
        )
        assert isinstance(skill, SkillDefinition)
        assert skill.name == "setup-guide"
        assert skill.description == "How to set up billing"
        assert skill.content == "# Setup Guide"

    def test_rejects_empty_name(self):
        with pytest.raises(ValueError, match="name"):
            define_skill(name="", description="test", content="test")

    def test_rejects_empty_description(self):
        with pytest.raises(ValueError, match="description"):
            define_skill(name="test", description="", content="test")

    def test_rejects_empty_content(self):
        with pytest.raises(ValueError, match="content"):
            define_skill(name="test", description="test", content="")

    def test_frozen_dataclass(self):
        skill = define_skill(name="x", description="y", content="z")
        with pytest.raises(AttributeError):
            skill.name = "changed"


class TestPillarWithSkills:
    def test_accepts_skills_in_constructor(self):
        skill = define_skill(name="s", description="d", content="c")
        p = Pillar(secret="test", auto_register=False, skills=[skill])
        assert len(p._skills) == 1

    def test_skills_included_in_registration(self):
        skill = define_skill(name="my-skill", description="desc", content="content")
        p = Pillar(
            secret="test",
            endpoint_url="https://example.com/pillar",
            auto_register=False,
            skills=[skill],
        )

        with patch("pillar._client.register_tools") as mock_reg:
            mock_reg.return_value = {"registered": []}
            p.register()

            mock_reg.assert_called_once()
            call_kwargs = mock_reg.call_args[1]
            assert call_kwargs["skills"] is not None
            assert len(call_kwargs["skills"]) == 1
            assert call_kwargs["skills"][0].name == "my-skill"

    def test_no_skills_passes_none(self):
        p = Pillar(
            secret="test",
            endpoint_url="https://example.com/pillar",
            auto_register=False,
        )

        with patch("pillar._client.register_tools") as mock_reg:
            mock_reg.return_value = {"registered": []}
            p.register()

            call_kwargs = mock_reg.call_args[1]
            assert call_kwargs["skills"] is None
