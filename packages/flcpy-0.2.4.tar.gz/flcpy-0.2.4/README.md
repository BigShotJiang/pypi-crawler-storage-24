# Flare Python Controller (flcpy)

Python networking interface for Flare Live / Flare Real.

## Install & Upgrade

```
pip install --upgrade flcpy
```

## Use

```
import flcpy

c = flcpy.Controller()
obj = c.get_object(...)
...
```