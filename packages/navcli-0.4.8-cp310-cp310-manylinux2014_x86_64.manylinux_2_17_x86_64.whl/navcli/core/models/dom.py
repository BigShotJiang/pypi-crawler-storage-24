"""DOM Tree model for page DOM representation."""

from typing import Optional
from pydantic import BaseModel, Field

from .element import Element


class DOMChange(BaseModel):
    """Represents a SPA DOM change."""

    type: str              # 'added', 'removed', 'modified'
    selector: str          # CSS selector of changed element
    html: Optional[str] = None  # new HTML (for added/modified)
    text: Optional[str] = None  # new text (for modified)


class DOMTree(BaseModel):
    """Represents the page DOM tree.

    SPA Diff Strategy:
    - First load returns full DOM
    - Subsequent operations return incremental changes
    - Fallback to full DOM if changes > 50%
    """

    version: int = 0              # incremental version number
    full: bool = True              # is full DOM (vs incremental)
    html: str = ""                 # full or incremental HTML
    changes: list[DOMChange] = Field(default_factory=list)  # SPA changes
    elements: list[Element] = Field(default_factory=list)  # interactive elements
    async_loaded: bool = False     # contains async loaded content
    loading: bool = False          # currently loading
