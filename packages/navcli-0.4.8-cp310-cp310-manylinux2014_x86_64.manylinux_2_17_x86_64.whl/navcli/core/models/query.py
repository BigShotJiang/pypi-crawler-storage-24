"""Query result models - specialized results for query commands."""

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, computed_field


class QueryData(BaseModel):
    """Specialized result for query commands - no empty fields to avoid confusion."""

    text: Optional[str] = None
    html: Optional[str] = None
    elements: Optional[List[Dict[str, Any]]] = None
    paragraphs: Optional[List[Dict[str, Any]]] = None
    tables: Optional[List[Dict[str, Any]]] = None
    links: Optional[List[Dict[str, Any]]] = None
    forms: Optional[List[Dict[str, Any]]] = None
    screenshot: Optional[str] = None
    url: Optional[str] = None
    title: Optional[str] = None
    data: Optional[Any] = None
    error: Optional[str] = None
    detail: Optional[str] = None
    hints: Optional[List[str]] = None

    @computed_field
    @property
    def success(self) -> bool:
        """Returns True if query was successful (has data or no error)."""
        return self.error is None and any(
            [
                self.text,
                self.html,
                self.elements,
                self.paragraphs,
                self.tables,
                self.links,
                self.forms,
                self.screenshot,
                self.data,
                self.url,
                self.title,
            ]
        )
