"""Feedback and CommandResult models."""

from typing import Optional

from pydantic import BaseModel, Field

from .state import StateSnapshot


class Feedback(BaseModel):
    """Represents the result of a command execution."""

    action: str = ""  # action performed
    result: str = ""  # result description
    hints: list = Field(default_factory=list)  # next step hints


class CommandResult(BaseModel):
    """Standard result returned by all commands."""

    success: bool = False
    command: str = ""
    state: StateSnapshot = Field(default_factory=StateSnapshot)
    feedback: Feedback = Field(default_factory=Feedback)
    error: Optional[str] = None
    detail: Optional[dict] = None  # detailed data for commands
