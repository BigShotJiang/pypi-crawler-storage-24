"""Network request/response models."""

from typing import Optional

from pydantic import BaseModel


class NetworkRequest(BaseModel):
    """Captured network request."""

    id: str
    url: str
    method: str
    timestamp: float
    headers: Optional[dict] = None
    post_data: Optional[str] = None
    resource_type: Optional[str] = None


class NetworkResponse(BaseModel):
    """Captured network response."""

    status: int
    status_text: str
    headers: Optional[dict] = None
    body: Optional[str] = None
    timing: Optional[float] = None


class CapturedRequest(BaseModel):
    """Complete captured request/response pair."""

    id: str
    request: NetworkRequest
    response: Optional[NetworkResponse] = None
