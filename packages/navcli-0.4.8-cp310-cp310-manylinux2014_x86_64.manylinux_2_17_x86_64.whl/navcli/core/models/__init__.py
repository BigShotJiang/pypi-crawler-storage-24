"""Core models for NavCLI."""

from .dom import DOMChange, DOMTree
from .element import Element
from .feedback import CommandResult, Feedback
from .network import CapturedRequest, NetworkRequest, NetworkResponse
from .query import QueryData
from .state import Paragraph, StateSnapshot

__all__ = [
    "Element",
    "DOMTree",
    "DOMChange",
    "StateSnapshot",
    "Paragraph",
    "CommandResult",
    "Feedback",
    "QueryData",
    "NetworkRequest",
    "NetworkResponse",
    "CapturedRequest",
]
