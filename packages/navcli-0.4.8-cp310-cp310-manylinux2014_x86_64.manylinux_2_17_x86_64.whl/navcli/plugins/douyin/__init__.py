"""Douyin plugin for NavCLI.

Provides video URL extraction from Douyin (TikTok China).
"""

from navcli.plugins.base import NavPlugin
from navcli.plugins.douyin.routes import router


class DouyinPlugin(NavPlugin):
    """Douyin video extraction plugin."""

    name = "douyin"
    version = "1.0.0"
    description = "Extract video URLs from Douyin (TikTok China)"

    def get_router(self):
        """Return FastAPI router."""
        return router

    def get_commands(self):
        """Return CLI commands."""
        from navcli.cli.client import NavClient

        async def extract_handler(client: NavClient, args) -> dict:
            """Handle extract command."""
            url = str(args).strip()
            if not url:
                return {
                    "success": False,
                    "error": "URL required",
                }

            # Call the server API
            import aiohttp

            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{client.base_url}/plugins/douyin/extract",
                    params={"url": url},
                    timeout=aiohttp.ClientTimeout(total=60),
                ) as resp:
                    return await resp.json()

        async def download_handler(client: NavClient, args) -> dict:
            """Handle download command."""
            parts = str(args).strip().split()
            url = parts[0] if parts else ""
            output = parts[1] if len(parts) > 1 else None

            if not url:
                return {
                    "success": False,
                    "error": "URL required",
                }

            params = {"url": url}
            if output:
                params["output"] = output

            import aiohttp

            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{client.base_url}/plugins/douyin/download",
                    params=params,
                    timeout=aiohttp.ClientTimeout(total=120),
                ) as resp:
                    return await resp.json()

        return [
            {
                "name": "extract",
                "help": "Extract video URL from Douyin\n  Usage: plugins douyin extract <url>",
                "handler": extract_handler,
            },
            {
                "name": "download",
                "help": "Download video from Douyin\n  Usage: douyin download <url> [output.mp4]",
                "handler": download_handler,
            },
        ]


plugin = DouyinPlugin()
