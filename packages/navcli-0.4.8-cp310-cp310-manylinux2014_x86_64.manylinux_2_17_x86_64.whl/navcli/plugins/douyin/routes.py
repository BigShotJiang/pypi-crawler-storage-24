"""Douyin plugin routes for video extraction."""

import asyncio
import json
from typing import Optional
from urllib.parse import parse_qs, urlparse

import aiohttp
from fastapi import APIRouter, Query

from navcli.core.models import CommandResult, Feedback
from navcli.server import browser as browser_module
from navcli.server.utils import log_progress

router = APIRouter()


def extract_video_url_from_body(body: str) -> Optional[str]:
    """Extract video URL from Douyin API response body."""
    try:
        data = json.loads(body)
        aweme_detail = data.get("aweme_detail", {})
        if not aweme_detail:
            return None

        video = aweme_detail.get("video", {})
        play_addr = video.get("play_addr", {})
        url_list = play_addr.get("url_list", [])

        # Get watermark-free URL (without 'playwm')
        for url in url_list:
            if "playwm" not in url:
                return url

        return url_list[0] if url_list else None
    except Exception as e:
        log_progress(f"Error extracting video URL: {e}")
        return None


@router.post("/extract")
async def extract_video(
    url: str = Query(..., description="Douyin video URL or short URL"),
) -> CommandResult:
    """Extract video download URL from Douyin video page.

    Supports:
    - https://v.douyin.com/xxxxx (short URL)
    - https://www.douyin.com/video/xxxxx (full URL)

    IMPORTANT: Douyin blocks headless browsers. Start server with:
        nav-server --no-headless
    Then open http://127.0.0.1:8766 in a browser, login to Douyin via QR code.
    Subsequent calls will use the saved session.
    """
    try:
        await browser_module.start_browser()
        page = browser_module.get_page()

        # Set mobile user agent to bypass captcha
        await page.set_extra_http_headers(
            {
                "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1"
            }
        )

        video_url = None
        video_title = None

        async def handle_response(response):
            nonlocal video_url, video_title
            log_progress(f"Response: {response.url}")
            if "/aweme/v1/web/aweme/detail" in response.url:
                try:
                    body = await response.text()
                    video_url = extract_video_url_from_body(body)
                    if video_url:
                        # Try to get video title
                        try:
                            data = json.loads(body)
                            aweme = data.get("aweme_detail", {})
                            video_title = aweme.get("video", {}).get("title") or aweme.get(
                                "desc", ""
                            )
                        except Exception:
                            pass
                except Exception as e:
                    log_progress(f"Error in response handler: {e}")

        page.on("response", handle_response)

        # Navigate to the URL
        if not url.startswith(("http://", "https://")):
            url = "https://" + url

        log_progress(f"Navigating to: {url}")

        # First navigate to get the video ID from redirect
        try:
            response = await page.goto(url, timeout=60000, wait_until="domcontentloaded")
        except Exception as e:
            log_progress(f"Initial navigation failed: {e}")

        # Wait for video to load - Douyin loads video lazily
        log_progress("Waiting for video to load...")
        try:
            video_selector = "video"
            await page.wait_for_selector(video_selector, timeout=30000)
            log_progress("Video element found on page")

            # Extract video URL directly from video element src attribute
            video_url = await page.locator("video").first.get_attribute("src")
            if video_url:
                # Handle relative URL
                if not video_url.startswith("http"):
                    video_url = "https://m.douyin.com" + video_url
                log_progress(f"Got video URL from page: {video_url[:80]}...")
                # Try to get title from page
                try:
                    video_title = await page.locator("[class*='title']").first.text_content()
                except Exception:
                    video_title = None
        except Exception as e:
            log_progress(f"Video element not found yet: {e}")

        # Wait for redirect
        await asyncio.sleep(3)

        # Check current URL first
        log_progress(f"Current URL after navigation: {page.url}")

        # Detect and close login modal - try multiple selectors
        try:
            # Try the specific ID first
            login_modal = page.locator("#douyin-login-new-id")
            modal_count = await login_modal.count()
            log_progress(f"Login modal #douyin-login-new-id found: {modal_count}")

            if modal_count > 0:
                log_progress("Detected login modal, attempting to close")
                close_svg = login_modal.locator("svg").first
                if await close_svg.count() > 0:
                    await close_svg.click()
                    log_progress("Closed login modal via SVG")
                    await asyncio.sleep(2)
            else:
                # Try other common selectors
                other_selectors = [
                    ".login-modal svg",
                    '[class*="login"] svg',
                    ".pc-modal-close svg",
                ]
                for sel in other_selectors:
                    try:
                        el = page.locator(sel).first
                        if await el.count() > 0 and await el.is_visible():
                            log_progress(f"Found close button: {sel}")
                            await el.click()
                            await asyncio.sleep(2)
                            break
                    except Exception:
                        pass
        except Exception as e:
            log_progress(f"Login modal handling error: {e}")

        # Get current URL which should have the video ID
        current_url = page.url
        log_progress(f"Current URL after redirect: {current_url}")

        # Check if we're on the block page
        if "暂时无法展示" in (await page.content()) or "验证" in (await page.content()):
            return CommandResult(
                success=False,
                command="douyin/extract",
                error="Douyin is blocking the browser. Please start server with --no-headless and login via QR code once. Then try again.",
            )

        # Extract video ID from URL (either /video/xxx or from query params)
        video_id = None
        if "/video/" in current_url:
            video_id = current_url.split("/video/")[-1].split("?")[0]
        else:
            # Try to extract from query params
            parsed = urlparse(current_url)
            params = parse_qs(parsed.query)
            video_id = params.get("video_id", [None])[0] or params.get("id", [None])[0]

        log_progress(f"Extracted video ID: {video_id}")

        # If we have video ID but no video URL yet, try direct API call
        if video_id and not video_url:
            log_progress(f"Waiting for video API response (video_id: {video_id})...")
            # Wait longer for API to respond
            await asyncio.sleep(5)

            try:
                api_url = f"https://www.douyin.com/aweme/v1/web/aweme/detail/?aweme_id={video_id}&aid=6383&channel=channel_pc_web&version_code=170400&webid=7611121315726657034"
                async with aiohttp.ClientSession() as session:
                    async with session.get(
                        api_url, timeout=aiohttp.ClientTimeout(total=30)
                    ) as resp:
                        if resp.status == 200:
                            data = await resp.json()
                            video_url = extract_video_url_from_body(json.dumps(data))
                            if video_url:
                                aweme = data.get("aweme_detail", {})
                                video_title = aweme.get("video", {}).get("title") or aweme.get(
                                    "desc", ""
                                )
                                log_progress(f"Got video URL via API: {video_url[:50]}...")
            except Exception as e:
                log_progress(f"Direct API call failed: {e}")

        # Wait for potential captcha or redirect
        await asyncio.sleep(3)

        # Check for captcha/verification
        current_url = page.url
        log_progress(f"Current URL after navigation: {current_url}")

        # Take screenshot for debugging
        try:
            screenshot_bytes = await page.screenshot()
            log_progress(f"Page screenshot taken: {len(screenshot_bytes)} bytes")
        except Exception as e:
            log_progress(f"Failed to take screenshot: {e}")

        if video_url:
            return CommandResult(
                success=True,
                command="douyin/extract",
                feedback=Feedback(
                    action="extracted video URL",
                    result=f"title: {video_title[:50] if video_title else 'N/A'}",
                ),
                detail={
                    "video_url": video_url,
                    "title": video_title,
                },
            )
        else:
            return CommandResult(
                success=False,
                command="douyin/extract",
                error="Could not extract video URL. Douyin may be blocking the browser. Start server with --no-headless, open http://127.0.0.1:8766, login to Douyin via QR code, then try again.",
            )

    except Exception as e:
        log_progress(f"Error extracting video: {e}")
        return CommandResult(
            success=False,
            command="douyin/extract",
            error=str(e),
        )


@router.post("/download")
async def download_video(
    url: str = Query(..., description="Douyin video URL or short URL"),
    output: Optional[str] = Query(None, description="Output file path"),
) -> CommandResult:
    """Download video from Douyin to file."""
    try:
        # First extract the URL
        extract_result = await extract_video(url)

        if not extract_result.success:
            return extract_result

        video_url = extract_result.detail.get("video_url")
        if not video_url:
            return CommandResult(
                success=False,
                command="douyin/download",
                error="No video URL found",
            )

        # Get cookies for download
        page = browser_module.get_page()
        context = page.context
        cookies = await context.cookies()
        cookie_str = "; ".join([f"{c['name']}={c['value']}" for c in cookies])

        # Download with curl
        import subprocess

        output_path = output or "douyin_video.mp4"

        headers = [
            "-H",
            "User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15",
            "-H",
            "Referer: https://www.douyin.com/",
            "-H",
            f"Cookie: {cookie_str}",
        ]

        cmd = ["curl", "-L", "-o", output_path] + headers + [video_url]

        result = subprocess.run(cmd, capture_output=True)

        if result.returncode == 0:
            import os

            size = os.path.getsize(output_path)
            return CommandResult(
                success=True,
                command="douyin/download",
                feedback=Feedback(
                    action="downloaded video",
                    result=f"saved to {output_path} ({size} bytes)",
                ),
                detail={
                    "video_url": video_url,
                    "output_path": output_path,
                    "file_size": size,
                },
            )
        else:
            return CommandResult(
                success=False,
                command="douyin/download",
                error=f"Download failed: {result.stderr.decode()}",
            )

    except Exception as e:
        return CommandResult(
            success=False,
            command="douyin/download",
            error=str(e),
        )
