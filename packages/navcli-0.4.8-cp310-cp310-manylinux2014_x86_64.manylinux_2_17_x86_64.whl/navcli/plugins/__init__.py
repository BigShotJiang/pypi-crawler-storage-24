"""Plugin system for NavCLI.

Auto-discovers plugins from the plugins/ directory.
"""

import os
from importlib import import_module
from typing import TYPE_CHECKING, Optional

from navcli.plugins.base import NavPlugin

if TYPE_CHECKING:
    from fastapi import APIRouter

    from navcli.plugins.base import NavPlugin


def load_plugins() -> list["NavPlugin"]:
    """Auto-discover and load plugins from plugins/ directory.

    Plugins are Python packages in the plugins/ directory that:
    1. Have an __init__.py file
    2. Define a NavPlugin subclass named 'plugin'

    Returns:
        List of loaded plugin instances
    """
    plugins = []
    plugin_dir = os.path.dirname(__file__)

    for entry in os.listdir(plugin_dir):
        plugin_path = os.path.join(plugin_dir, entry)

        # Skip non-directories and private directories
        if not os.path.isdir(plugin_path) or entry.startswith("_"):
            continue

        # Check for __init__.py
        init_file = os.path.join(plugin_path, "__init__.py")
        if not os.path.exists(init_file):
            continue

        try:
            # Import the plugin module
            module_name = f"navcli.plugins.{entry}"
            module = import_module(module_name)

            # Look for 'plugin' attribute (NavPlugin instance or class)
            plugin_attr = getattr(module, "plugin", None)

            if plugin_attr is None:
                continue

            # Support both class and instance
            if isinstance(plugin_attr, type) and issubclass(plugin_attr, NavPlugin):
                plugin_instance = plugin_attr()
            elif isinstance(plugin_attr, NavPlugin):
                plugin_instance = plugin_attr
            else:
                continue

            # Call on_load hook
            plugin_instance.on_load()

            plugins.append(plugin_instance)

        except Exception as e:
            print(f"[PLUGIN] Failed to load {entry}: {e}")

    return plugins


def get_plugin_routers() -> list[tuple[str, "APIRouter"]]:
    """Get all plugin routers for server registration."""
    plugins = load_plugins()
    routers = []

    for plugin in plugins:
        router = plugin.get_router()
        if router:
            routers.append((plugin.name, router))

    return routers


def get_plugin_commands():
    """Get all plugin commands for CLI registration."""
    plugins = load_plugins()
    commands = []

    for plugin in plugins:
        commands.extend(plugin.get_commands())

    return commands
