"""Plugin base classes for NavCLI."""

from typing import TYPE_CHECKING, Optional

from fastapi import APIRouter

if TYPE_CHECKING:
    pass


class NavPlugin:
    """Base class for NavCLI plugins."""

    name: str = "base"
    version: str = "1.0.0"
    description: str = ""

    def get_router(self) -> Optional[APIRouter]:
        """Return FastAPI router for server endpoints.

        Routes will be mounted under /plugins/{plugin_name}/
        """
        return None

    def get_commands(self) -> list[dict]:
        """Return list of CLI command definitions.

        Each command is a dict with:
        - name: command name (e.g., 'extract')
        - help: help text
        - handler: async function(client, args) -> result
        """
        return []

    def on_load(self):
        """Called when plugin is loaded."""
        pass

    def on_unload(self):
        """Called when plugin is unloaded."""
        pass
