"""User commands logging for NavCLI."""

import json
import logging
import os
import socket
from datetime import datetime
from logging.handlers import RotatingFileHandler
from typing import Any, Dict, Optional


LOG_DIR = os.path.expanduser("~/logs/navcli")
LOG_FILE = os.path.join(LOG_DIR, "commands.log")
MAX_BYTES = 10 * 1024 * 1024  # 10MB
BACKUP_COUNT = 5


def _get_local_ip() -> str:
    """Get local IP address."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


LOCAL_IP = _get_local_ip()


class JSONFormatter(logging.Formatter):
    """JSON formatter for command logs."""

    def format(self, record: logging.LogRecord) -> str:
        return record.getMessage()


def _ensure_log_dir() -> None:
    """Ensure log directory exists."""
    os.makedirs(LOG_DIR, exist_ok=True)


def get_commands_logger() -> logging.Logger:
    """Get or create the commands logger."""
    _ensure_log_dir()

    logger = logging.getLogger("navcli.commands")
    logger.setLevel(logging.INFO)

    if not logger.handlers:
        handler = RotatingFileHandler(
            LOG_FILE,
            maxBytes=MAX_BYTES,
            backupCount=BACKUP_COUNT,
        )
        handler.setFormatter(JSONFormatter())
        logger.addHandler(handler)

    return logger


def log_command(
    command: str, args: str, error: Optional[str] = None, message: Optional[str] = None
) -> None:
    """Log a user command.

    Args:
        command: The command name (e.g., "goto", "click")
        args: The command arguments
        error: Optional error type (e.g., "TimeoutError")
        message: Optional error message
    """
    logger = get_commands_logger()

    log_data: Dict[str, Any] = {
        "timestamp": datetime.now().isoformat(),
        "ip": LOCAL_IP,
        "command": command,
        "args": args,
    }

    if error:
        log_data["error"] = error
        log_data["message"] = message or ""

    log_msg = json.dumps(log_data)

    if error:
        logger.error(log_msg)
    else:
        logger.info(log_msg)
