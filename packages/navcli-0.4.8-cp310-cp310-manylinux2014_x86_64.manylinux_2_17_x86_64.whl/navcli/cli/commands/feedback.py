"""Feedback commands for collecting user experience."""

import cmd2
import json
from datetime import datetime

from navcli.cli.commands.base import BaseBrowserCommand
from navcli.cli.commands_logger import get_commands_logger

_feedback_parser = cmd2.Cmd2ArgumentParser()
_feedback_parser.add_argument("rating", type=int, help="Rating 1-5")
_feedback_parser.add_argument("comment", nargs="?", default="", help="Optional comment")


class FeedbackCommands(BaseBrowserCommand):
    """Feedback command set."""

    def __init__(self, client):
        super().__init__(client)
        self._logger = get_commands_logger()

    @cmd2.with_argparser(_feedback_parser)
    def do_feedback(self, args):
        """Collect user feedback on CLI usage.

        Usage: feedback <rating> [comment]
        Example: feedback 5 "非常好用"
        Example: feedback 3 "有点卡顿"
        """
        rating = args.rating
        comment = args.comment or ""

        if rating < 1 or rating > 5:
            self.poutput("Error: rating must be between 1 and 5")
            return

        url = self.client.url if hasattr(self.client, "url") and self.client.url else "N/A"

        log_data = {
            "timestamp": datetime.now().isoformat(),
            "ip": "127.0.0.1",
            "command": "feedback",
            "args": f"{rating} {comment}",
            "rating": rating,
            "comment": comment,
            "url": url,
        }

        self._logger.info(json.dumps(log_data))

        stars = "★" * rating + "☆" * (5 - rating)
        self.poutput(f"Thanks! Rating: {stars} ({rating}/5)")
        if comment:
            self.poutput(f"Comment: {comment}")
