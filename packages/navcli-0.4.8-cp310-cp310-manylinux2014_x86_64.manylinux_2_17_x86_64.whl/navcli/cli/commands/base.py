"""Base command class for NavCLI commands."""

import cmd2

from navcli.cli.client import NavClient, ServerError
from navcli.cli.formatter import ResultFormatter


class BaseBrowserCommand(cmd2.Cmd):
    """Base class for browser commands with client connection."""

    def __init__(self, client: NavClient):
        super().__init__()
        self.client = client
        self.prompt = "(navcli) "
        self._show_suggestions = False
        self._suggestions_text = ""

    def _should_show_suggestions(self, result: dict) -> bool:
        """Check if result contains suggestions after navigation."""
        if not result or not result.get("success"):
            return False
        feedback = result.get("feedback", {})
        hints = feedback.get("hints", [])
        return len(hints) > 0

    def _get_suggestions_text(self, result: dict) -> str:
        """Get suggestions text from result."""
        feedback = result.get("feedback", {})
        hints = feedback.get("hints", [])
        if hints:
            return f"[Hint: {' | '.join(hints)}]"
        return ""

    @property
    def prompt(self):
        if self._show_suggestions:
            self._show_suggestions = False
            return f"(navcli) {self._suggestions_text} "
        return "(navcli) "

    @prompt.setter
    def prompt(self, value):
        self._prompt = value
        self._show_suggestions = False
        self._suggestions_text = ""

    def connect_client(self):
        """Ensure client is connected."""
        return self.client.connect()

    async def run_async_client(self, coro):
        """Run async client method."""
        await self.connect_client()
        try:
            return await coro
        except ServerError as e:
            self.perror(f"[FAIL] {e}")
            self.poutput("Please restart the server:")
            self.poutput("  pkill -f nav-server")
            self.poutput("  nav-server")
            return None
        finally:
            await self.client.close()

    def pretty_result(self, result: dict):
        """Output command result as JSON, filtering null values."""
        import json

        def filter_nulls(obj):
            if isinstance(obj, dict):
                return {k: filter_nulls(v) for k, v in obj.items() if v is not None}
            elif isinstance(obj, list):
                return [filter_nulls(item) for item in obj if item is not None]
            return obj

        filtered = filter_nulls(result)
        output = json.dumps(filtered, ensure_ascii=False, indent=2)
        self.poutput(output)

    def complete_url(self, text, line, begidx, endidx):
        """Complete URL with common prefixes."""
        urls = ["http://", "https://", "http://www.", "https://www."]
        return [u for u in urls if u.startswith(text)]
