"""Interaction commands: click, type, clear, upload."""

import cmd2

from navcli.cli.commands.base import BaseBrowserCommand

# Parsers for aliased commands
_click_parser = cmd2.Cmd2ArgumentParser()
_click_parser.add_argument("selector", help="CSS selector")
_click_parser.add_argument("--force", action="store_true", help="Force click without waiting")

_type_parser = cmd2.Cmd2ArgumentParser()
_type_parser.add_argument("selector", help="CSS selector")
_type_parser.add_argument("text", nargs="+", help="Text to type")


class InteractionCommands(BaseBrowserCommand):
    """Interaction command set."""

    def __init__(self, client):
        super().__init__(client)

    @cmd2.with_argparser(_click_parser)
    def do_click(self, args):
        """Click an element.

        Usage: click <selector> [--force]
        Example: click #submit-button
        Example: click .login-btn --force
        """
        import asyncio
        import re

        selector = args.selector
        url_pattern = re.compile(r"^https?://", re.IGNORECASE)
        if url_pattern.match(selector):
            self.perror("[FAIL] 'click' expects a CSS selector, not a URL")
            self.poutput("Hint: Use 'goto <url>' to navigate to a URL")
            self.poutput("Example: goto https://example.com")
            return

        async def _click():
            return await self.client.click(selector, force=args.force)

        result = asyncio.run(self.run_async_client(_click()))
        self.pretty_result(result)

    @cmd2.with_argparser(_type_parser)
    def do_type(self, args):
        """Type text into an input field.

        Usage: type <selector> <text>
        Example: type #search-input hello world
        """
        import asyncio
        import re

        selector = args.selector
        url_pattern = re.compile(r"^https?://", re.IGNORECASE)
        if url_pattern.match(selector):
            self.perror("[FAIL] 'type' expects a CSS selector, not a URL")
            self.poutput("Hint: Use 'goto <url>' to navigate to a URL")
            self.poutput("Example: type #search-input your text")
            return

        async def _type():
            return await self.client.type(selector, " ".join(args.text))

        result = asyncio.run(self.run_async_client(_type()))
        self.pretty_result(result)

    @cmd2.with_argparser(cmd2.Cmd2ArgumentParser())
    def do_dblclick(self, args):
        """Double-click an element.

        Usage: dblclick <selector>
        Example: dblclick #submit-button
        """
        import asyncio

        async def _dblclick():
            return await self.client.dblclick(args.selector)

        result = asyncio.run(self.run_async_client(_dblclick()))
        self.pretty_result(result)

    @cmd2.with_argparser(cmd2.Cmd2ArgumentParser())
    def do_rightclick(self, args):
        """Right-click an element.

        Usage: rightclick <selector>
        Example: rightclick .context-menu
        """
        import asyncio

        async def _rightclick():
            return await self.client.rightclick(args.selector)

        result = asyncio.run(self.run_async_client(_rightclick()))
        self.pretty_result(result)

    # Aliases
    @cmd2.with_argparser(_click_parser)
    def do_c(self, args):
        """Click an element (shortcut).

        Usage: c <selector> [--force]
        Example: c #nav_data
        Example: c .button-class --force
        """
        import asyncio
        import re

        selector = args.selector
        url_pattern = re.compile(r"^https?://", re.IGNORECASE)
        if url_pattern.match(selector):
            self.perror("[FAIL] 'c' expects a CSS selector, not a URL")
            self.poutput("Hint: Use 'goto <url>' to navigate to a URL")
            self.poutput("Example: goto https://example.com")
            return

        async def _click():
            return await self.client.click(selector, force=args.force)

        result = asyncio.run(self.run_async_client(_click()))
        self.pretty_result(result)

    @cmd2.with_argparser(_type_parser)
    def do_t(self, args):
        """Type text into an input (shortcut).

        Usage: t <selector> <text>
        """
        import asyncio

        async def _type():
            return await self.client.type(args.selector, " ".join(args.text))

        result = asyncio.run(self.run_async_client(_type()))
        self.pretty_result(result)

    @cmd2.with_argparser(cmd2.Cmd2ArgumentParser())
    def do_clear(self, args):
        """Clear an input field.

        Usage: clear <selector>
        Example: clear #search-input
        """
        import asyncio

        async def _clear():
            return await self.client.clear(args.selector)

        result = asyncio.run(self.run_async_client(_clear()))
        self.pretty_result(result)

    @cmd2.with_argparser(cmd2.Cmd2ArgumentParser())
    def do_upload(self, args):
        """Upload a file to an input.

        Usage: upload <selector> <file_path>
        Example: upload input[type=file] /path/to/file.txt
        """
        import asyncio

        async def _upload():
            return await self.client.upload(args.selector, args.file_path)

        result = asyncio.run(self.run_async_client(_upload()))
        self.pretty_result(result)
