"""NavCLI - Browser automation command line interface."""

import cmd2

from navcli.cli.client import NavClient
from navcli.cli.commands.control import ControlCommands
from navcli.cli.commands.explore import ExploreCommands
from navcli.cli.commands.feedback import FeedbackCommands
from navcli.cli.commands.interaction import InteractionCommands
from navcli.cli.commands.navigation import NavigationCommands
from navcli.cli.commands.query import QueryCommands
from navcli.cli.commands_logger import log_command
from navcli.cli.connection import DEFAULT_SERVER_URL, check_server_connection, get_server_error_msg
from navcli.plugins import load_plugins


def _print_server_status():
    """Print server connection status."""
    import sys

    if check_server_connection():
        print(f"[OK] Connected to NavCLI server at {DEFAULT_SERVER_URL}")
        return True
    else:
        print(get_server_error_msg(), file=sys.stderr)
        return False


class NavCLI(
    NavigationCommands,
    InteractionCommands,
    QueryCommands,
    ExploreCommands,
    ControlCommands,
    FeedbackCommands,
    cmd2.Cmd,
):
    """NavCLI main application class."""

    def __init__(self):
        super().__init__(client=NavClient())
        self.prompt = "(navcli) "
        self.doc_header = "Available commands"
        self._server_ok = _print_server_status()

        # Load plugin commands
        self._load_plugin_commands()

    def _load_plugin_commands(self):
        """Load commands from plugins."""
        plugins = load_plugins()

        for plugin in plugins:
            commands = plugin.get_commands()
            for cmd in commands:
                name = cmd.get("name")
                help_text = cmd.get("help", "")
                handler = cmd.get("handler")

                if name and handler:
                    # Create command method
                    def make_handler(h, pn):
                        def cmd_handler(self, args):
                            import asyncio

                            result = asyncio.run(h(self.client, args))
                            self.pretty_result(result)

                        cmd_handler.__doc__ = help_text
                        cmd_handler.__name__ = f"do_{pn}_{name}"
                        return cmd_handler

                    handler_fn = make_handler(handler, plugin.name)
                    setattr(NavCLI, f"do_{plugin.name}_{name}", handler_fn)

                    # Create completers if provided
                    completer = cmd.get("complete")
                    if completer:

                        def make_completer(c, pn, n):
                            def completer_fn(self, text, line, begidx, endidx):
                                return c(self, text, line, begidx, endidx)

                            completer_fn.__name__ = f"complete_{pn}_{n}"
                            return completer_fn

                        setattr(
                            NavCLI,
                            f"complete_{plugin.name}_{name}",
                            make_completer(completer, plugin.name, name),
                        )

    def onecmd(self, statement: str, add_to_history: bool = True) -> bool:
        """Intercept command to log it."""
        statement = statement.strip()
        if not statement:
            return super().onecmd(statement, add_to_history=add_to_history)

        parsed = self.statement_parser.parse(statement)
        command = parsed.command if parsed.command else ""
        args = parsed.args if parsed.args else ""

        if command:
            args_str = str(args) if args else ""
            try:
                result = super().onecmd(statement, add_to_history=add_to_history)
            except Exception as e:
                log_command(command, args_str, error=type(e).__name__, message=str(e))
                raise
            else:
                log_command(command, args_str)
                return result
        else:
            return super().onecmd(statement, add_to_history=add_to_history)


def main():
    """Entry point for navcli command."""
    import argparse

    epilog = """
Commands:
  Navigation:     goto <url>, back, forward, reload
  Interaction:   click <selector>, type <selector> <text>, clear <selector>, 
                 rightclick <selector>, dblclick <selector>, upload <selector> <file>
  Exploration:   findall <selector>, inspect <selector>, 
                 elements, links, forms, tables, paragraphs
  Query:         text <selector>, html <selector>, title, url, evaluate <js>, wait_idle
  Control:       screenshot [path], cookies [action], state, scroll <direction>,
                 wait <seconds>, clear_cookies, shutdown

Shortcuts:
  g=goto, b=back, f=forward, r=reload, c=clear, t=title

Examples:
  nav goto https://example.com
  nav click #submit-button
  nav type #search-input hello
  nav findall button.primary
  nav inspect #main-content
  nav screenshot
  nav cookies get
  nav state
  nav"""
    parser = argparse.ArgumentParser(
        prog="nav",
        description="NavCLI - Interactive browser automation CLI for AI Agents",
        epilog=epilog,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "-t",
        "--test",
        action="store_true",
        help="Test against transcript(s) in FILE (wildcards OK)",
    )
    parser.add_argument(
        "command", nargs="?", help="Command to execute (runs help if none provided)"
    )

    args, unknown = parser.parse_known_args()

    cli = NavCLI()
    if not cli._server_ok:
        import sys

        sys.exit(1)

    if args.command:
        full_cmd = args.command
        if unknown:
            full_cmd += " " + " ".join(unknown)
        cli.onecmd(full_cmd)
    else:
        cli.onecmd("help")


if __name__ == "__main__":
    main()
