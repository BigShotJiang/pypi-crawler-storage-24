"""HTTP client for NavCLI server communication."""

from typing import Any, Dict, Optional
from urllib.parse import urljoin

import aiohttp

DEFAULT_BASE_URL = "http://127.0.0.1:8765"


class ServerError(Exception):
    """Raised when server returns a 500 error."""

    pass


class NavClient:
    """Async HTTP client for NavCLI server."""

    def __init__(self, base_url: str = DEFAULT_BASE_URL):
        self.base_url = base_url.rstrip("/")
        self.session: Optional[aiohttp.ClientSession] = None

    async def connect(self):
        """Create aiohttp session."""
        if self.session is None:
            self.session = aiohttp.ClientSession()

    async def close(self):
        """Close aiohttp session."""
        if self.session:
            await self.session.close()
            self.session = None

    async def _request(self, method: str, path: str, **kwargs):
        """Make HTTP request to server."""
        if self.session is None:
            await self.connect()

        url = urljoin(self.base_url + "/", path.lstrip("/"))
        async with self.session.request(method, url, **kwargs) as response:
            if response.status == 500:
                raise ServerError(
                    "Server encountered an internal error (500). Please restart the server."
                )
            return await response.json()

    # Navigation commands
    async def goto(self, url: str, wait_until: str = "networkidle"):
        """Navigate to URL."""
        return await self._request("POST", "/cmd/goto", json={"url": url, "wait_until": wait_until})

    async def back(self):
        """Go back in history."""
        return await self._request("POST", "/cmd/back")

    async def forward(self):
        """Go forward in history."""
        return await self._request("POST", "/cmd/forward")

    async def reload(self):
        """Reload current page."""
        return await self._request("POST", "/cmd/reload")

    # Interaction commands
    async def click(self, selector: str, force: bool = False):
        """Click an element."""
        return await self._request(
            "POST", "/cmd/click", json={"selector": selector, "force": force}
        )

    async def type(self, selector: str, text: str):
        """Type text into input."""
        return await self._request("POST", "/cmd/type", json={"selector": selector, "text": text})

    async def clear(self, selector: str):
        """Clear input field."""
        return await self._request("POST", "/cmd/clear", json={"selector": selector})

    async def upload(self, selector: str, file_path: str):
        """Upload file to input."""
        return await self._request(
            "POST", "/cmd/upload", json={"selector": selector, "file_path": file_path}
        )

    async def dblclick(self, selector: str):
        """Double-click an element."""
        return await self._request("POST", "/cmd/dblclick", json={"selector": selector})

    async def rightclick(self, selector: str):
        """Right-click an element."""
        return await self._request("POST", "/cmd/rightclick", json={"selector": selector})

    # Query commands
    async def get_elements(self):
        """Get interactive elements."""
        return await self._request("GET", "/query/elements")

    async def get_text(self):
        """Get page text."""
        return await self._request("GET", "/query/text")

    async def get_html(self):
        """Get page HTML."""
        return await self._request("GET", "/query/html")

    async def get_screenshot(self, path: Optional[str] = None):
        """Get page screenshot and optionally save to file."""
        if path:
            result = await self._request("POST", "/query/screenshot", json={"path": path})
        else:
            result = await self._request("POST", "/query/screenshot")
        if result.get("screenshot_path"):
            return result
        if result.get("screenshot"):
            import base64
            import os
            import datetime

            if not path:
                timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                path = f"/tmp/screenshot_{timestamp}.png"
            screenshot_data = result["screenshot"]
            if "," in screenshot_data:
                screenshot_data = screenshot_data.split(",")[1]
            with open(path, "wb") as f:
                f.write(base64.b64decode(screenshot_data))
            result["screenshot_path"] = os.path.abspath(path)
        return result

    async def get_state(self):
        """Get page state."""
        return await self._request("GET", "/query/state")

    async def get_url(self):
        """Get current URL."""
        return await self._request("GET", "/query/url")

    async def get_title(self):
        """Get page title."""
        return await self._request("GET", "/query/title")

    async def evaluate(self, expr: str):
        """Evaluate JavaScript expression."""
        return await self._request("POST", "/query/evaluate", json={"expr": expr})

    async def get_links(self):
        """Get all links on the page."""
        return await self._request("GET", "/query/links")

    async def get_forms(self):
        """Get all forms on the page."""
        return await self._request("GET", "/query/forms")

    async def get_tables(self):
        """Get all tables on the page with their data."""
        return await self._request("GET", "/query/tables")

    async def get_paragraphs(self, min_length: int = 200):
        """Get large text paragraphs (200+ chars) from the page.

        Args:
            min_length: Minimum paragraph length (default: 200)
        """
        return await self._request("GET", "/query/paragraphs", json={"min_length": min_length})

    async def get_grids(self, min_repeat: int = 10):
        """Find grid patterns: divs with both <a> and <img> that repeat.

        Args:
            min_repeat: Minimum repetitions to qualify as a grid (default: 10)
        """
        return await self._request("POST", "/query/grids", json={"min_repeat": min_repeat})

    # Explore commands
    async def find(self, text: str):
        """Find element by text."""
        return await self._request("POST", "/explore/find", json={"text": text})

    async def findall(self, text: str):
        """Find all elements by text."""
        return await self._request("POST", "/explore/findall", json={"text": text})

    async def inspect(self, selector: str):
        """Inspect element details."""
        return await self._request("POST", "/explore/inspect", json={"selector": selector})

    async def wait(self, selector: str = None, seconds: float = None):
        """Wait for selector or timeout."""
        if selector:
            return await self._request("POST", "/explore/wait", json={"selector": selector})
        elif seconds is not None:
            return await self._request("POST", "/explore/wait", json={"seconds": seconds})
        else:
            return await self._request("POST", "/explore/wait")

    async def wait_idle(self, timeout: float = 3.0):
        """Wait for network idle."""
        return await self._request("POST", "/explore/wait/idle", json={"timeout": timeout})

    async def scroll(
        self, direction: str = None, x: int = None, y: int = None, selector: str = None
    ):
        """Scroll the page.

        Args:
            direction: top, bottom, up, down
            x, y: coordinates
            selector: element selector to scroll into view
        """
        payload = {}
        if direction:
            payload["direction"] = direction
        elif x is not None and y is not None:
            payload["x"] = x
            payload["y"] = y
        elif selector:
            payload["selector"] = selector
        else:
            payload["direction"] = "down"

        return await self._request("POST", "/explore/scroll", json=payload)

    # Control commands
    async def quit(self):
        """Quit browser."""
        return await self._request("POST", "/cmd/quit")

    async def shutdown(self):
        """Shutdown server."""
        return await self._request("POST", "/cmd/shutdown")

    # Session commands
    async def get_cookies(self):
        """Get all cookies."""
        return await self._request("GET", "/cmd/cookies")

    async def clear_cookies(self):
        """Clear all cookies."""
        return await self._request("DELETE", "/cmd/cookies/clear")

    async def set_cookie(
        self,
        name: str,
        value: str,
        domain: str,
        path: str = "/",
        expires: int = None,
        http_only: bool = False,
        secure: bool = False,
        same_site: str = None,
    ):
        """Set a cookie.

        Args:
            name: Cookie name
            value: Cookie value
            domain: Domain for cookie
            path: Cookie path (default: "/")
            expires: Expiration timestamp
            http_only: HttpOnly flag
            secure: Secure flag
            same_site: SameSite attribute
        """

        body = {
            "name": name,
            "value": value,
            "domain": domain,
            "path": path,
        }
        if expires is not None:
            body["expires"] = expires
        if http_only:
            body["httpOnly"] = http_only
        if secure:
            body["secure"] = secure
        if same_site:
            body["sameSite"] = same_site

        return await self._request("POST", "/cmd/cookies/set", json=body)

    async def save_session(self, name: str = None, path: str = None):
        """Save session to file.

        Args:
            name: Session name (saves to ~/.navcli/sessions/<name>.json)
            path: Full file path (alternative to name)
        """
        if name:
            return await self._request("POST", "/cmd/session/save", json={"name": name})
        elif path:
            return await self._request("POST", "/cmd/session/save", json={"path": path})
        else:
            return await self._request("POST", "/cmd/session/save")

    async def load_session(self, name: str = None, path: str = None):
        """Load session from file.

        Args:
            name: Session name (loads from ~/.navcli/sessions/<name>.json)
            path: Full file path (alternative to name)
        """
        if name:
            return await self._request("POST", "/cmd/session/load", json={"name": name})
        elif path:
            return await self._request("POST", "/cmd/session/load", json={"path": path})
        else:
            return await self._request("POST", "/cmd/session/load")


async def main():
    """Test client connection."""
    client = NavClient()
    try:
        await client.connect()
        result = await client.get_state()
        print(result)
    finally:
        await client.close()


if __name__ == "__main__":
    import asyncio

    asyncio.run(main())
