"""CLI result formatter - centralized output formatting."""

from typing import Optional


class ResultFormatter:
    """Centralized management of CLI result formatting."""

    @staticmethod
    def format_hints(hints: list) -> str:
        """Format hints for display."""
        if not hints:
            return ""
        return f" | {' | '.join(hints)}"

    @staticmethod
    def format_success(
        action: str,
        result: Optional[str] = None,
        hints: Optional[list] = None,
        state: Optional[dict] = None,
    ) -> list[str]:
        """Format success output, return list of lines."""
        lines = []

        hint_str = ResultFormatter.format_hints(hints) if hints else ""
        lines.append(f"[OK] {action}{hint_str}")

        if result:
            lines.append(f"  Result: {result}")

        if state:
            if state.get("url"):
                lines.append(f"  URL: {state.get('url')}")
            if state.get("title"):
                lines.append(f"  Title: {state.get('title')}")

        return lines

    @staticmethod
    def format_error(error: str) -> list[str]:
        """Format error output."""
        return [f"[FAIL] {error}"]

    @staticmethod
    def format_error_detail(error: str, detail: Optional[str] = None) -> list[str]:
        """Format error output with detail."""
        lines = [f"[FAIL] {error}"]
        if detail:
            lines.append(f"  Detail: {detail}")
        return lines

    @staticmethod
    def format_query(data: dict) -> list[str]:
        """Format QueryData response."""
        lines = []
        url = data.get("url", "")
        title = data.get("title", "")
        text = data.get("text", "")
        error = data.get("error")
        detail = data.get("detail")
        screenshot_path = data.get("screenshot_path")
        data_field = data.get("data")

        if data_field is not None:
            lines.append("[OK] Evaluated JavaScript")
            if url:
                lines.append(f"  URL: {url}")
            if title:
                lines.append(f"  Title: {title}")
            lines.append(f"  Result: {data_field}")
            return lines

        if error:
            if detail:
                return ResultFormatter.format_error_detail(error, detail)
            return ResultFormatter.format_error(error)

        if screenshot_path:
            lines.append(f"[OK] Screenshot saved to: {screenshot_path}")
            if url:
                lines.append(f"  URL: {url}")
            if title:
                lines.append(f"  Title: {title}")
            return lines

        if text:
            lines.append("[OK] Retrieved page text")
            if url:
                lines.append(f"  URL: {url}")
            if title:
                lines.append(f"  Title: {title}")
            text_preview = text[:500].replace("\n", " ").strip()
            lines.append(f"  Text: {text_preview}...")
        else:
            lines.append("[OK] Retrieved page info")
            if url:
                lines.append(f"  URL: {url}")
            if title:
                lines.append(f"  Title: {title}")

        hints = data.get("hints")
        if hints:
            for hint in hints:
                lines.append(f"  💡 {hint}")

        return lines

    @staticmethod
    def format_none_response() -> list[str]:
        """Format no response from server."""
        return ["[FAIL] No response from server"]
