try:
    from navcli.server.browser import *
except ImportError:
    pass
