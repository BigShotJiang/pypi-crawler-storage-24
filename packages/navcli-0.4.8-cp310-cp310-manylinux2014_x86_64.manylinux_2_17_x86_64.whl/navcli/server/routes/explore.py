"""Explore routes: find, findall, inspect, wait."""

from typing import Optional
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel
import asyncio

from navcli.core.models import CommandResult, Feedback, Element
from navcli.server.browser import get_page, get_current_state, start_browser, wait_for_network_idle
from navcli.server.utils import extract_interactive_elements_fast, get_explore_hints
from navcli.utils import wait_for_condition

router = APIRouter(prefix="/explore")


def log_progress(message: str):
    """Print progress message."""
    print(f"[PROGRESS] {message}")


class FindRequest(BaseModel):
    text: str


@router.post("/find")
async def find(request: Request) -> CommandResult:
    body = await request.json()
    text = body.get("text")
    """Find first element containing text."""
    try:
        if not text:
            raise HTTPException(status_code=400, detail="text is required")

        log_progress(f"Finding element with text: {text}")

        await start_browser()
        page = get_page()

        # Use page.get_by_text if available
        try:
            locator = page.get_by_text(text, exact=False).first
            count = await locator.count()
            if count > 0:
                # Get element info
                tag = await locator.evaluate_handle("el => el.tagName")
                element_text = await locator.inner_text()
                log_progress(f"Found: <{tag.lower()}> {element_text[:50]}...")

                element = Element(
                    selector=f"text={text}",
                    tag=tag.lower(),
                    text=element_text[:200],
                    clickable=True,
                    input=False,
                )

                state = await get_current_state()
                state.dom.elements = [element]

                hints = get_explore_hints("find")

                return CommandResult(
                    success=True,
                    command="find",
                    state=state,
                    feedback=Feedback(
                        action=f"found element with text: {text}",
                        result=f"tag: {tag}",
                        hints=hints,
                    ),
                )
            else:
                log_progress(f"No element found with text: {text}")
                return CommandResult(
                    success=False,
                    command="find",
                    error=f"no element found with text: {text}",
                )
        except Exception:
            # Fallback: fast element search without full DOM
            log_progress(f"Fallback: searching elements for text: {text}")
            elements, _ = await extract_interactive_elements_fast(
                page, max_elements=100, include_html=False
            )

            for elem in elements:
                if text.lower() in elem.text.lower():
                    log_progress(f"Found: {elem.selector}")
                    # Create lightweight state
                    from navcli.core.models import StateSnapshot, DOMTree

                    dom = DOMTree(version=1, full=False, html="", elements=[elem])
                    state = StateSnapshot(url=page.url, title=await page.title(), dom=dom)

                    return CommandResult(
                        success=True,
                        command="find",
                        state=state,
                        feedback=Feedback(
                            action=f"found element with text: {text}",
                            result=f"selector: {elem.selector}",
                        ),
                    )

            log_progress(f"No elements found with text: {text}")
            return CommandResult(
                success=False,
                command="find",
                error=f"no element found with text: {text}",
            )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="find",
            error=str(e),
        )


class FindAllRequest(BaseModel):
    text: str


@router.post("/findall")
async def findall(request: Request) -> CommandResult:
    body = await request.json()
    text = body.get("text")
    """Find all elements containing text."""
    try:
        if not text:
            raise HTTPException(status_code=400, detail="text is required")

        log_progress(f"Finding all elements with text: {text}")

        await start_browser()
        page = get_page()

        # Fast element extraction without full HTML
        elements, _ = await extract_interactive_elements_fast(
            page, max_elements=100, include_html=False
        )

        matching = [e for e in elements if text.lower() in e.text.lower()]

        if matching:
            log_progress(f"Found {len(matching)} elements")
            # Create lightweight state with just matching elements
            from navcli.core.models import StateSnapshot, DOMTree

            dom = DOMTree(version=1, full=False, html="", elements=matching)
            state = StateSnapshot(url=page.url, title=await page.title(), dom=dom)

            hints = get_explore_hints("findall")

            return CommandResult(
                success=True,
                command="findall",
                state=state,
                feedback=Feedback(
                    action=f"found {len(matching)} elements with text: {text}",
                    result=f"found {len(matching)} elements",
                    hints=hints,
                ),
            )
        else:
            log_progress(f"No elements found with text: {text}")
            return CommandResult(
                success=False,
                command="findall",
                error=f"no elements found with text: {text}",
            )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="findall",
            error=str(e),
        )


class InspectRequest(BaseModel):
    selector: str


@router.post("/inspect")
async def inspect(request: Request) -> CommandResult:
    body = await request.json()
    selector = body.get("selector")
    """Inspect element details."""
    try:
        if not selector:
            raise HTTPException(status_code=400, detail="selector is required")

        log_progress(f"Inspecting element: {selector}")

        await start_browser()
        page = get_page()

        locator = page.locator(selector)
        count = await locator.count()

        if count == 0:
            log_progress(f"Element not found: {selector}")
            return CommandResult(
                success=False,
                command="inspect",
                error=f"element not found: {selector}",
            )

        # Get element details
        first = locator.first
        tag = await first.evaluate_handle("el => el.tagName")
        text = await first.inner_text()
        html = await first.inner_html()

        # Get attributes
        attributes = {}
        try:
            all_attrs = await first.evaluate_handle("""
                el => {
                    const attrs = {};
                    for (const attr of el.attributes) {
                        attrs[attr.name] = attr.value;
                    }
                    return attrs;
                }
            """)
            attributes = dict(all_attrs)
        except Exception:
            pass

        element = Element(
            selector=selector,
            tag=tag.lower(),
            text=text[:500],
            clickable=await first.is_enabled() and await first.is_visible(),
            input=tag.lower() in ("input", "textarea"),
            type=attributes.get("type"),
            href=attributes.get("href"),
            alt=attributes.get("alt"),
        )

        state = await get_current_state()
        state.dom.elements = [element]
        log_progress(f"Inspected: <{tag.lower()}> {text[:30]}...")

        hints = get_explore_hints("inspect")

        return CommandResult(
            success=True,
            command="inspect",
            state=state,
            feedback=Feedback(
                action=f"inspected {selector}",
                result=f"tag: {tag}, visible: {await first.is_visible()}",
                hints=hints,
            ),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="inspect",
            error=str(e),
        )


class WaitRequest(BaseModel):
    selector: Optional[str] = None
    seconds: Optional[float] = None


@router.post("/wait")
async def wait(req: WaitRequest) -> CommandResult:
    """Wait for selector or timeout."""
    try:
        await start_browser()
        page = get_page()

        if req.selector:
            # Wait for selector
            log_progress(f"Waiting for selector: {req.selector}")
            hints = get_explore_hints("wait")
            try:
                await page.wait_for_selector(req.selector, timeout=10000)
                state = await get_current_state()
                log_progress(f"Selector appeared: {req.selector}")
                return CommandResult(
                    success=True,
                    command="wait",
                    state=state,
                    feedback=Feedback(
                        action=f"waited for {req.selector}",
                        result="element appeared",
                        hints=hints,
                    ),
                )
            except asyncio.TimeoutError:
                log_progress(f"Timeout waiting for: {req.selector}")
                return CommandResult(
                    success=False,
                    command="wait",
                    error=f"timeout waiting for {req.selector}",
                )
        elif req.seconds:
            # Wait for seconds
            hints = get_explore_hints("wait")
            log_progress(f"Waiting {req.seconds}s...")
            await asyncio.sleep(req.seconds)
            state = await get_current_state()
            return CommandResult(
                success=True,
                command="wait",
                state=state,
                feedback=Feedback(
                    action=f"waited {req.seconds}s",
                    result="waited",
                    hints=hints,
                ),
            )
        else:
            # Default: wait for network idle
            hints = get_explore_hints("wait")
            log_progress("Waiting for network idle...")
            await wait_for_network_idle(3.0)
            state = await get_current_state()
            log_progress("Network idle")
            return CommandResult(
                success=True,
                command="wait",
                state=state,
                feedback=Feedback(
                    action="waited for network idle",
                    result="ready",
                    hints=hints,
                ),
            )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="wait",
            error=str(e),
        )


@router.post("/wait/idle")
async def wait_idle(timeout: float = 3.0) -> CommandResult:
    """Wait for network idle."""
    try:
        hints = get_explore_hints("wait")
        log_progress(f"Waiting for network idle (timeout: {timeout}s)...")
        await start_browser()
        idle = await wait_for_network_idle(timeout)

        state = await get_current_state()
        log_progress(f"Network idle: {idle}")

        return CommandResult(
            success=True,
            command="wait_idle",
            state=state,
            feedback=Feedback(
                action="waited for network idle",
                result="idle" if idle else "timeout",
                hints=hints,
            ),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="wait_idle",
            error=str(e),
        )


class ScrollRequest(BaseModel):
    direction: Optional[str] = None  # top, bottom, up, down
    x: Optional[int] = None
    y: Optional[int] = None
    selector: Optional[str] = None


@router.post("/scroll")
async def scroll(req: ScrollRequest) -> CommandResult:
    """Scroll the page or element.

    Usage:
    - scroll?direction=top|bottom|up|down
    - scroll?x=<num>&y=<num>
    - scroll?selector=<sel>&into_view=true
    """
    try:
        await start_browser()
        page = get_page()

        if req.selector:
            # Scroll element into view
            log_progress(f"Scrolling to element: {req.selector}")
            locator = page.locator(req.selector)
            count = await locator.count()
            if count == 0:
                log_progress(f"Element not found: {req.selector}")
                return CommandResult(
                    success=False,
                    command="scroll",
                    error=f"element not found: {req.selector}",
                )
            await locator.first.scroll_into_view_if_needed()
            action = f"scrolled to {req.selector}"
        elif req.direction:
            # Directional scroll
            log_progress(f"Scrolling {req.direction}...")
            if req.direction == "top":
                await page.evaluate("window.scrollTo(0, 0)")
                action = "scrolled to top"
            elif req.direction == "bottom":
                await page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
                action = "scrolled to bottom"
            elif req.direction == "up":
                await page.evaluate("window.scrollBy(0, -window.innerHeight)")
                action = "scrolled up"
            elif req.direction == "down":
                await page.evaluate("window.scrollBy(0, window.innerHeight)")
                action = "scrolled down"
            else:
                return CommandResult(
                    success=False,
                    command="scroll",
                    error=f"invalid direction: {req.direction}. Use: top, bottom, up, down",
                )
        elif req.x is not None and req.y is not None:
            # Coordinate scroll
            log_progress(f"Scrolling to ({req.x}, {req.y})")
            await page.evaluate(f"window.scrollTo({req.x}, {req.y})")
            action = f"scrolled to ({req.x}, {req.y})"
        else:
            return CommandResult(
                success=False,
                command="scroll",
                error="provide direction, x/y coordinates, or selector",
            )

        await asyncio.sleep(0.3)  # Brief wait for scroll to complete
        state = await get_current_state()
        log_progress(action)

        hints = get_explore_hints("scroll")

        return CommandResult(
            success=True,
            command="scroll",
            state=state,
            feedback=Feedback(
                action=action,
                result="scrolled",
                hints=hints,
            ),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="scroll",
            error=str(e),
        )
