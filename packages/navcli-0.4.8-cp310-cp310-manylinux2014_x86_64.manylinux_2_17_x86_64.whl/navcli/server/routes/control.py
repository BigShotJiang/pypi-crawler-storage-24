"""Control routes: quit, shutdown."""

from fastapi import APIRouter

from navcli.core.models import CommandResult, Feedback, StateSnapshot
from navcli.server.browser import close_browser, get_current_state, start_browser
from navcli.server.utils import get_control_hints

router = APIRouter()


def log_progress(message: str):
    """Print progress message."""
    print(f"[PROGRESS] {message}")


@router.post("/quit")
async def quit() -> CommandResult:
    """Quit and close the browser server."""
    try:
        log_progress("Quitting browser...")
        # Get final state before closing
        try:
            state = await get_current_state()
        except Exception:
            state = StateSnapshot()

        # Close browser
        await close_browser()
        log_progress("Browser closed")

        hints = get_control_hints("quit")

        return CommandResult(
            success=True,
            command="quit",
            state=state,
            feedback=Feedback(
                action="quit",
                result="browser closed",
                hints=hints,
            ),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="quit",
            error=str(e),
        )


@router.post("/shutdown")
async def shutdown() -> CommandResult:
    """Shutdown the server (same as quit)."""
    log_progress("Shutting down server...")
    return await quit()
