"""Network interception routes: capture, watch, requests."""

import re
from typing import Optional

from fastapi import APIRouter, Query

from navcli.core.models import CommandResult, Feedback
from navcli.server.browser import (
    get_captured_requests,
    start_browser,
    start_network_capture,
    stop_network_capture,
    watch_url_pattern,
)
from navcli.server.utils import log_progress

router = APIRouter()


@router.post("/network/start_capture")
async def start_capture(
    url_pattern: Optional[str] = Query(None, description="Regex pattern to match URLs"),
    resource_types: Optional[str] = Query(
        None,
        description=(
            "Comma-separated resource types: xhr,fetch,document,script,stylesheet,image,media"
        ),
    ),
) -> CommandResult:
    """Start capturing network requests."""
    try:
        await start_browser()

        types_list = resource_types.split(",") if resource_types else None

        await start_network_capture(url_pattern=url_pattern, resource_types=types_list)

        log_progress(f"Network capture started (pattern: {url_pattern}, types: {resource_types})")

        return CommandResult(
            success=True,
            command="network/start_capture",
            feedback=Feedback(
                action="started network capture",
                result=f"monitoring {resource_types or 'all'} requests",
            ),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="network/start_capture",
            error=str(e),
        )


@router.post("/network/stop_capture")
async def stop_capture() -> CommandResult:
    """Stop capturing and return captured requests."""
    try:
        requests = await stop_network_capture()

        log_progress(f"Network capture stopped: {len(requests)} requests captured")

        return CommandResult(
            success=True,
            command="network/stop_capture",
            feedback=Feedback(
                action="stopped network capture", result=f"captured {len(requests)} requests"
            ),
            detail={"requests": requests},
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="network/stop_capture",
            error=str(e),
        )


@router.get("/network/requests")
async def get_requests(
    url_pattern: Optional[str] = Query(None, description="Filter by URL regex"),
    resource_type: Optional[str] = Query(None, description="Filter by resource type"),
    limit: int = Query(100, ge=1, le=1000, description="Max requests to return"),
) -> CommandResult:
    """Get captured network requests."""
    try:
        requests = get_captured_requests()

        requests = requests[-limit:]

        if url_pattern:
            requests = [r for r in requests if re.search(url_pattern, r.get("url", ""))]

        if resource_type:
            requests = [r for r in requests if r.get("resource_type") == resource_type]

        total = len(get_captured_requests())

        return CommandResult(
            success=True,
            command="network/requests",
            feedback=Feedback(
                action="retrieved network requests",
                result=f"showing {len(requests)} of {total} requests",
            ),
            detail={
                "request_count": len(requests),
                "total_captured": total,
                "requests": requests,
            },
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="network/requests",
            error=str(e),
        )


@router.post("/network/watch")
async def watch(
    url_pattern: str = Query(..., description="Regex pattern to watch for"),
    timeout: float = Query(30.0, ge=1, le=120, description="Max wait time in seconds"),
) -> CommandResult:
    """Watch for specific URL pattern and return immediately when matched."""
    try:
        await start_browser()

        log_progress(f"Watching for URL pattern: {url_pattern}")

        matched = await watch_url_pattern(url_pattern, timeout)

        if matched:
            return CommandResult(
                success=True,
                command="network/watch",
                feedback=Feedback(
                    action="watched for URL pattern",
                    result=f"matched: {matched.get('url', '')[:80]}...",
                ),
                detail={"matched_request": matched},
            )
        else:
            return CommandResult(
                success=False,
                command="network/watch",
                error=f"No request matching pattern '{url_pattern}' within {timeout}s",
            )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="network/watch",
            error=str(e),
        )
