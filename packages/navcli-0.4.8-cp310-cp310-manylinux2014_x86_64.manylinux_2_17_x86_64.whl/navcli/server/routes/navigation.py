"""Navigation routes: goto, back, forward, reload."""

import asyncio
from typing import Optional

from fastapi import APIRouter, HTTPException, Request

from navcli.core.models import CommandResult, Feedback
from navcli.server.browser import (
    auto_save_snapshot,
    get_current_state,
    get_page,
    start_browser,
    wait_for_network_idle,
)
from navcli.server.utils import get_navigation_hints, log_progress
from navcli.utils import normalize_url

router = APIRouter()


@router.post("/goto")
async def goto(request: Request) -> CommandResult:
    body = await request.json()
    url = body.get("url")
    wait_until = body.get("wait_until", "networkidle")
    """Navigate to a URL."""
    try:
        if not url:
            raise HTTPException(status_code=400, detail="url is required")

        normalized_url = normalize_url(url)
        log_progress(f"Navigating to {normalized_url}...")

        await start_browser()
        page = get_page()

        await page.goto(normalized_url, wait_until="commit", timeout=3000)
        await page.wait_for_selector("body", timeout=3000)

        from navcli.core.models import DOMTree, StateSnapshot

        try:
            title = await asyncio.wait_for(page.title(), timeout=3000)
        except Exception:
            title = ""
        state = StateSnapshot(
            url=normalized_url,
            title=title,
            dom=DOMTree(version=0, full=False, html="", elements=[]),
        )
        log_progress(f"Page title: {state.title}")

        await auto_save_snapshot()

        hints = get_navigation_hints("goto")

        return CommandResult(
            success=True,
            command="goto",
            state=state,
            feedback=Feedback(
                action=f"navigated to {normalized_url}",
                result=f"page loaded: {state.title}",
                hints=hints,
            ),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="goto",
            error=str(e),
        )


@router.post("/back")
async def back() -> CommandResult:
    """Go back in history."""
    try:
        log_progress("Going back...")
        page = get_page()
        await page.go_back()
        await wait_for_network_idle(3.0)

        state = await get_current_state()
        log_progress(f"Back to: {state.url}")

        await auto_save_snapshot()

        hints = get_navigation_hints("back")

        return CommandResult(
            success=True,
            command="back",
            state=state,
            feedback=Feedback(
                action="went back",
                result=f"navigated to {state.url}",
                hints=hints,
            ),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="back",
            error=str(e),
        )


@router.post("/forward")
async def forward() -> CommandResult:
    """Go forward in history."""
    try:
        log_progress("Going forward...")
        page = get_page()
        await page.go_forward()
        await wait_for_network_idle(3.0)

        state = await get_current_state()
        log_progress(f"Forward to: {state.url}")

        await auto_save_snapshot()

        hints = get_navigation_hints("forward")

        return CommandResult(
            success=True,
            command="forward",
            state=state,
            feedback=Feedback(
                action="went forward",
                result=f"navigated to {state.url}",
                hints=hints,
            ),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="forward",
            error=str(e),
        )


@router.post("/reload")
async def reload() -> CommandResult:
    """Reload the current page."""
    try:
        log_progress("Reloading page...")
        page = get_page()
        await page.reload()
        await wait_for_network_idle(3.0)

        state = await get_current_state()
        log_progress(f"Reloaded: {state.url}")

        await auto_save_snapshot()

        hints = get_navigation_hints("reload")

        return CommandResult(
            success=True,
            command="reload",
            state=state,
            feedback=Feedback(
                action="reloaded page",
                result=f"reloaded {state.url}",
                hints=hints,
            ),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="reload",
            error=str(e),
        )
