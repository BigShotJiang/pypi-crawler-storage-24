"""Interaction routes: click, type, clear, upload."""

import time
from typing import Optional
from fastapi import APIRouter, HTTPException, Request

from navcli.core.models import CommandResult, Feedback
from navcli.server.browser import get_page, get_current_state, start_browser, wait_for_network_idle
from navcli.server.utils import get_interaction_hints

router = APIRouter()


def log_progress(message: str):
    """Print progress message with timestamp."""
    print(f"[PROGRESS {time.strftime('%H:%M:%S')}] {message}")


@router.post("/click")
async def click(request: Request) -> CommandResult:
    body = await request.json()
    selector = body.get("selector")
    force = body.get("force", False)
    index = body.get("index", 0)
    """Click an element."""
    try:
        if not selector:
            raise HTTPException(status_code=400, detail="selector is required")

        log_progress(f"Clicking '{selector}'...")

        await start_browser()
        page = get_page()

        locator = page.locator(selector)

        # Check if element exists
        count = await locator.count()
        if count == 0:
            log_progress(f"Element not found: {selector}")
            return CommandResult(
                success=False,
                command="click",
                error=f"element not found: {selector}",
            )

        if index >= count:
            log_progress(f"Index {index} out of range for selector '{selector}' (found {count})")
            return CommandResult(
                success=False,
                command="click",
                error=f"index {index} out of range: found {count} elements",
            )

        # Click with timeout protection
        try:
            element = locator.nth(index)

            # Record pages before click to detect new tab
            context = page.context
            pages_before = len(context.pages)

            if force:
                await element.click(force=True, timeout=3000)
                log_progress(f"Force clicked '{selector}[{index}]'")
            else:
                await element.click(timeout=3000)
                log_progress(f"Clicked '{selector}[{index}]'")

            # Check if new tab opened
            pages_after = context.pages
            if len(pages_after) > pages_before:
                page = pages_after[-1]
                log_progress(f"New tab opened, switched to: {page.url}")
        except Exception as click_err:
            log_progress(f"Click failed: {click_err}")
            return CommandResult(
                success=False,
                command="click",
                error=f"click failed: {str(click_err)}",
            )

        # Return minimal state without expensive operations
        from navcli.core.models import StateSnapshot, DOMTree

        state = StateSnapshot(
            url=page.url,
            title="",
            dom=DOMTree(version=0, full=False, html="", elements=[]),
        )

        hints = get_interaction_hints("click")
        hints.insert(0, "页面可能已更新，建议使用 nav elements 刷新")

        return CommandResult(
            success=True,
            command="click",
            state=state,
            feedback=Feedback(
                action=f"clicked {selector}",
                result="clicked",
                hints=hints,
            ),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="click",
            error=str(e),
        )


@router.post("/type")
async def type_text(request: Request) -> CommandResult:
    body = await request.json()
    selector = body.get("selector")
    text = body.get("text")
    press = body.get("press")
    index = body.get("index", 0)
    """Type text into an input."""
    try:
        if not selector:
            raise HTTPException(status_code=400, detail="selector is required")
        if not text and not press:
            raise HTTPException(status_code=400, detail="text or press is required")

        log_progress(f"Typing into '{selector}': {text[:30] if text else ''}...")

        await start_browser()
        page = get_page()

        locator = page.locator(selector)

        count = await locator.count()
        if count == 0:
            log_progress(f"Element not found: {selector}")
            return CommandResult(
                success=False,
                command="type",
                error=f"element not found: {selector}",
            )

        if index >= count:
            return CommandResult(
                success=False,
                command="type",
                error=f"index {index} out of range: found {count} elements",
            )

        element = locator.nth(index)
        await element.focus()
        if text:
            await element.fill(text)
        if press:
            await element.press(press)

        # 验证输入是否成功
        input_verified = True
        if text:
            actual_value = await element.input_value()
            if actual_value != text:
                input_verified = False
                log_progress(f"Warning: expected '{text}', got '{actual_value}'")

        log_progress(f"Typed into '{selector}'")

        from navcli.core.models import StateSnapshot, DOMTree

        state = StateSnapshot(
            url=page.url,
            title="",
            dom=DOMTree(version=0, full=False, html="", elements=[]),
        )

        if input_verified:
            hints = get_interaction_hints("type")
            hints.insert(0, "✅ 输入完成，页面可能已更新，建议使用 nav elements 刷新")
        else:
            hints = [
                "⚠️ 输入内容与预期不符，元素可能已变化",
                "请使用 nav elements 重新获取元素列表后再尝试",
            ]

        return CommandResult(
            success=True,
            command="type",
            state=state,
            feedback=Feedback(
                action=f"typed into {selector}",
                result=f"typed: {text[:20] + '...' if text else 'pressed ' + press}",
                hints=hints,
            ),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="type",
            error=str(e),
        )


@router.post("/clear")
async def clear_input(request: Request) -> CommandResult:
    body = await request.json()
    selector = body.get("selector")
    """Clear an input field."""
    try:
        if not selector:
            raise HTTPException(status_code=400, detail="selector is required")

        log_progress(f"Clearing '{selector}'...")

        await start_browser()
        page = get_page()

        locator = page.locator(selector)

        # Check if element exists
        count = await locator.count()
        if count == 0:
            log_progress(f"Element not found: {selector}")
            return CommandResult(
                success=False,
                command="clear",
                error=f"element not found: {selector}",
            )

        # Clear
        await locator.clear()
        log_progress(f"Cleared '{selector}'")

        state = await get_current_state()

        hints = get_interaction_hints("clear")

        return CommandResult(
            success=True,
            command="clear",
            state=state,
            feedback=Feedback(
                action=f"cleared {selector}",
                result="cleared",
                hints=hints,
            ),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="clear",
            error=str(e),
        )


@router.post("/upload")
async def upload_file(request: Request) -> CommandResult:
    body = await request.json()
    selector = body.get("selector")
    file_path = body.get("file_path")
    """Upload a file to an input."""
    try:
        if not selector:
            raise HTTPException(status_code=400, detail="selector is required")
        if not file_path:
            raise HTTPException(status_code=400, detail="file_path is required")

        log_progress(f"Uploading '{file_path}' to '{selector}'...")

        # Check if file exists
        import os

        if not os.path.exists(file_path):
            log_progress(f"File not found: {file_path}")
            return CommandResult(
                success=False,
                command="upload",
                error=f"file not found: {file_path}",
            )

        await start_browser()
        page = get_page()

        locator = page.locator(selector)

        # Check if element exists
        count = await locator.count()
        if count == 0:
            log_progress(f"Element not found: {selector}")
            return CommandResult(
                success=False,
                command="upload",
                error=f"element not found: {selector}",
            )

        # Upload file
        await locator.set_input_files(file_path)
        log_progress(f"Uploaded '{file_path}'")

        state = await get_current_state()

        hints = get_interaction_hints("upload")

        return CommandResult(
            success=True,
            command="upload",
            state=state,
            feedback=Feedback(
                action=f"uploaded {file_path} to {selector}",
                result="uploaded",
                hints=hints,
            ),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="upload",
            error=str(e),
        )


@router.post("/dblclick")
async def dblclick(request: Request) -> CommandResult:
    body = await request.json()
    selector = body.get("selector")
    """Double-click an element."""
    try:
        if not selector:
            raise HTTPException(status_code=400, detail="selector is required")

        log_progress(f"Double-clicking '{selector}'...")

        await start_browser()
        page = get_page()

        locator = page.locator(selector)
        count = await locator.count()
        if count == 0:
            log_progress(f"Element not found: {selector}")
            return CommandResult(
                success=False,
                command="dblclick",
                error=f"element not found: {selector}",
            )
        if count > 1:
            log_progress(f"Multiple elements found: {selector}")
            return CommandResult(
                success=False,
                command="dblclick",
                error=f"multiple elements found: {selector}",
            )

        await locator.dblclick()
        log_progress(f"Double-clicked '{selector}'")

        # get_current_state() includes its own wait_for_load_state
        state = await get_current_state()

        hints = get_interaction_hints("dblclick")
        hints.insert(0, "页面可能已更新，建议使用 nav elements 刷新")

        return CommandResult(
            success=True,
            command="dblclick",
            state=state,
            feedback=Feedback(
                action=f"double-clicked {selector}",
                result="clicked",
                hints=hints,
            ),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="dblclick",
            error=str(e),
        )


@router.post("/rightclick")
async def rightclick(request: Request) -> CommandResult:
    body = await request.json()
    selector = body.get("selector")
    """Right-click an element."""
    try:
        if not selector:
            raise HTTPException(status_code=400, detail="selector is required")

        log_progress(f"Right-clicking '{selector}'...")

        await start_browser()
        page = get_page()

        locator = page.locator(selector)
        count = await locator.count()
        if count == 0:
            log_progress(f"Element not found: {selector}")
            return CommandResult(
                success=False,
                command="rightclick",
                error=f"element not found: {selector}",
            )
        if count > 1:
            log_progress(f"Multiple elements found: {selector}")
            return CommandResult(
                success=False,
                command="rightclick",
                error=f"multiple elements found: {selector}",
            )

        await locator.click(button="right")
        log_progress(f"Right-clicked '{selector}'")

        # get_current_state() includes its own wait_for_load_state
        state = await get_current_state()

        hints = get_interaction_hints("rightclick")
        hints.insert(0, "页面可能已更新，建议使用 nav elements 刷新")

        return CommandResult(
            success=True,
            command="rightclick",
            state=state,
            feedback=Feedback(
                action=f"right-clicked {selector}",
                result="clicked",
                hints=hints,
            ),
        )
    except Exception as e:
        log_progress(f"Error: {e}")
        return CommandResult(
            success=False,
            command="rightclick",
            error=str(e),
        )
