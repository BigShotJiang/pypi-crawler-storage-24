"""Server routes."""

from . import control, explore, interaction, navigation, network, query, session

__all__ = [
    "navigation",
    "interaction",
    "query",
    "explore",
    "control",
    "session",
    "network",
]
