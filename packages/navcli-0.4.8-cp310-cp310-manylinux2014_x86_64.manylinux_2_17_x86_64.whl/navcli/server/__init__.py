"""NavCLI Browser Server."""

import asyncio
import os
import signal
import socket
import sys
import time
from typing import Callable, Optional

import uvicorn
from uvicorn.config import Config

from navcli.server.app import create_app
from navcli.server.browser import _SNAPSHOT_PATH, close_browser, save_session, start_browser
from navcli.server.idle import (
    get_idle_check_interval,
    get_idle_time,
    get_idle_timeout,
    get_warning_time,
    update_activity,
)

__version__ = "0.1.0"

# Session directory
_NAVCLI_HOME = os.path.expanduser("~/.navcli")
_NAVCLI_SESSIONS_DIR = os.path.join(_NAVCLI_HOME, "sessions")

# Server instance
_server: Optional[uvicorn.Server] = None
_idle_check_task: Optional[asyncio.Task] = None


async def _check_idle():
    """Background task to check idle time and trigger shutdown."""
    global _idle_check_task

    while True:
        await asyncio.sleep(get_idle_check_interval())

        idle_time = get_idle_time()
        remaining = get_idle_timeout() - idle_time

        if idle_time >= get_idle_timeout():
            print(f"\n[IDLE] Timeout reached ({get_idle_timeout()}s), shutting down...")
            await _idle_shutdown()
            break
        elif (
            remaining <= get_warning_time()
            and remaining > get_warning_time() - get_idle_check_interval()
        ):
            minutes_left = int(remaining // 60)
            print(f"\n[IDLE] Will shut down in {minutes_left} minute(s) due to inactivity...")


async def _idle_shutdown():
    """Handle idle timeout shutdown."""
    global _server, _idle_check_task

    if _idle_check_task:
        _idle_check_task.cancel()
        _idle_check_task = None

    try:
        print("[IDLE] Saving session before shutdown...")
        await save_session(_SNAPSHOT_PATH)
        print(f"[IDLE] Session saved to {_SNAPSHOT_PATH}")
    except Exception as e:
        print(f"[IDLE] Failed to save session: {e}")

    if _server:
        _server.should_exit = True

    await close_browser()


async def start_server(
    host: str = "127.0.0.1",
    port: int = 8765,
    headless: bool = True,
    browser_args: Optional[list] = None,
    on_started: Optional[Callable] = None,
) -> uvicorn.Server:
    """Start the browser server.

    Args:
        host: Host to bind
        port: Port to listen
        headless: Run browser in headless mode (default: True)
        browser_args: Additional browser launch arguments

    Returns:
        Uvicorn server instance
    """
    global _server, _idle_check_task

    update_activity()

    # Start browser
    await start_browser(headless=headless, args=browser_args)

    # Create app
    app = create_app()

    # Configure uvicorn
    config = Config(app, host=host, port=port, log_level="info")
    _server = uvicorn.Server(config)

    # Register shutdown handlers
    def signal_handler(signum, frame):
        asyncio.create_task(shutdown())

    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)

    config.lifespan = "on"

    # Start idle check task
    _idle_check_task = asyncio.create_task(_check_idle())

    # Call on_started callback when server is ready
    if on_started:
        on_started()

    # Start server
    try:
        await _server.serve()
    except Exception as e:
        await close_browser()
        raise e

    return _server


async def shutdown():
    """Shutdown the server."""
    global _server

    if _server:
        _server.should_exit = True

    # Close browser
    await close_browser()


def main():
    """Main entry point for nav-server command."""
    import argparse
    import os

    parser = argparse.ArgumentParser(description="NavCLI Browser Server")
    parser.add_argument("--host", default="127.0.0.1", help="Host to bind")
    parser.add_argument("--port", type=int, default=8765, help="Port to listen")
    parser.add_argument(
        "--headless", action="store_true", default=True, help="Run in headless mode (default)"
    )
    parser.add_argument(
        "--no-headless", dest="headless", action="store_false", help="Run with GUI (non-headless)"
    )
    parser.add_argument(
        "--memory-limit",
        type=int,
        default=None,
        help="Browser memory limit in MB (e.g., --memory-limit 512)",
    )
    parser.add_argument(
        "--idle-timeout",
        type=int,
        default=15 * 60,
        help="Idle timeout in seconds (default: 900 = 15 minutes)",
    )

    args = parser.parse_args()

    # Set idle timeout
    from navcli.server.idle import set_idle_timeout

    set_idle_timeout(args.idle_timeout)
    print(f"[CONFIG] Idle timeout: {args.idle_timeout}s ({args.idle_timeout / 60:.0f} min)")

    # Build browser args for memory limit
    browser_args = None
    if args.memory_limit:
        browser_args = [
            f"--js-flags=--max-old-space-size={args.memory_limit}",
            "--disable-dev-shm-usage",
        ]
        print(f"Memory limit: {args.memory_limit}MB")

    print(f"Starting NavCLI Browser Server on {args.host}:{args.port}...")
    print("server is starting 预计 5 秒钟...")
    print("-" * 60)

    if is_port_in_use(args.port):
        print(f"[ERROR] Port {args.port} is already in use")
        print("        Is another nav-server running?")
        sys.exit(1)

    def on_started():
        print("server started ready for use")

    try:
        asyncio.run(
            start_server(
                args.host,
                args.port,
                headless=args.headless,
                browser_args=browser_args,
                on_started=on_started,
            )
        )
    except KeyboardInterrupt:
        print("\nShutting down...")
        sys.exit(0)
    except Exception as e:
        print(f"[FATAL] {e}")
        import traceback

        traceback.print_exc()
        sys.exit(1)


def is_port_in_use(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(("localhost", port)) == 0


if __name__ == "__main__":
    main()
