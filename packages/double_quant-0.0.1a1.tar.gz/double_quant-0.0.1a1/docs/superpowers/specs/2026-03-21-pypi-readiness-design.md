# PyPI Readiness Design

## Goal

Make the repository's public packaging story match a normal Python library so users can install released versions with `uv add double-quant` or `pip install double-quant`, while keeping source-based setup available for contributors.

## Scope

- Rewrite the README installation section from an end-user perspective.
- Remove obviously stale public API examples from the README and replace them with examples that match the live package exports.
- Make the README more PyPI-friendly by avoiding relative asset paths that break in package indexes.
- Add the missing `pyproject.toml` metadata needed for a cleaner PyPI project page.
- Correct runtime dependency declarations that would be inappropriate for published consumers.

## Non-Goals

- No CI release automation in this change.
- No versioning policy changes.
- No test-suite expansion for documentation or metadata edits.

## Approach

Use the smallest release-readiness change set:

1. Keep the package build backend and layout as-is because `uv build` already succeeds.
2. Update `README.md` so the first installation path is PyPI-based, then move clone-and-sync instructions into a development section.
3. Update `pyproject.toml` with author, license, classifiers, keywords, and repository URLs.
4. Replace `scipy-stubs[scipy]` with the real `scipy` runtime dependency; stub packages belong in development tooling, not end-user installs.
5. Verify by rebuilding distributions and inspecting generated metadata.
