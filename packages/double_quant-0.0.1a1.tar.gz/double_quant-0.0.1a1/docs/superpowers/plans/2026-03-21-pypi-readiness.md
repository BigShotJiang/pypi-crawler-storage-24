# PyPI Readiness Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make the library ready for user-facing PyPI installation messaging and cleaner package metadata.

**Architecture:** Keep the package layout and build backend unchanged. Limit the implementation to release-facing documentation and packaging metadata so the published artifact matches the current source tree and public imports.

**Tech Stack:** Python packaging (`pyproject.toml`, Hatchling, uv), Markdown documentation

---

### Task 1: Document the released installation path

**Files:**
- Modify: `README.md`

- [ ] **Step 1: Replace contributor-style installation instructions**

Rewrite the installation section so the primary commands are:

```bash
uv add double-quant
pip install double-quant
```

- [ ] **Step 2: Move source checkout into development setup**

Keep clone-based instructions under a development-oriented section using:

```bash
git clone https://github.com/11D-Beyonder/double-quant.git
cd double-quant
uv sync
```

- [ ] **Step 3: Replace stale API examples**

Use examples that match the live package surface, including `HHLSolver` and risk attribution classes.

### Task 2: Improve published package metadata

**Files:**
- Modify: `pyproject.toml`

- [ ] **Step 1: Add missing project metadata**

Add author, license, keywords, classifiers, and project URLs that point to the public GitHub repository.

- [ ] **Step 2: Fix runtime dependency declarations**

Replace the runtime stub package entry with the actual SciPy dependency.

### Task 3: Verify the built artifact

**Files:**
- Inspect: `dist/*`

- [ ] **Step 1: Rebuild distributions**

Run:

```bash
uv build --no-sources
```

Expected: wheel and source distribution are produced successfully.

- [ ] **Step 2: Inspect generated metadata**

Confirm the built wheel contains the updated metadata and README content.
