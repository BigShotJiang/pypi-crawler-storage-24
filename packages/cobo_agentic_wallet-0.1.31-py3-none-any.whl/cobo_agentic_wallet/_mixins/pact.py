"""Pact operations mixin (auto-generated).

DO NOT EDIT MANUALLY. Run scripts/generate_mixins.py to regenerate.
"""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

from cobo_agentic_wallet_api.models.pact_submit_request import PactSubmitRequest

if TYPE_CHECKING:
    from cobo_agentic_wallet._mixins.base import BaseClient


class PactMixin:
    """Pact operations mixin (auto-generated)."""

    _extract_result: Any
    _pacts_api: Any

    async def get_pact(self: "BaseClient", pact_id: str) -> Any:
        """Get pact detail"""
        response = await self._pacts_api.get_pact(pact_id)
        return self._extract_result(response)

    async def list_pact_events(
        self: "BaseClient", pact_id: str, offset: int | None = None, limit: int | None = None
    ) -> Any:
        """Get pact event history"""
        response = await self._pacts_api.list_pact_events(pact_id, offset, limit)
        return self._extract_result(response)

    async def list_pacts(
        self: "BaseClient",
        status: Any | None = None,
        wallet_id: str | None = None,
        offset: int | None = None,
        limit: int | None = None,
    ) -> Any:
        """List pacts"""
        response = await self._pacts_api.list_pacts(status, wallet_id, offset, limit)
        return self._extract_result(response)

    async def revoke_pact(self: "BaseClient", pact_id: str) -> Any:
        """Revoke an active pact"""
        response = await self._pacts_api.revoke_pact(pact_id)
        return self._extract_result(response)

    async def submit_pact(
        self: "BaseClient",
        wallet_id: str = None,
        intent: str = None,
        spec: Any = None,
        name: str | None = None,
    ) -> Any:
        """Submit pact for approval"""
        pact_submit_request = PactSubmitRequest(
            wallet_id=wallet_id, intent=intent, spec=spec, name=name
        )
        response = await self._pacts_api.submit_pact(pact_submit_request)
        return self._extract_result(response)
