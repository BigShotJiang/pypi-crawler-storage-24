"""Approval operations mixin (auto-generated).

DO NOT EDIT MANUALLY. Run scripts/generate_mixins.py to regenerate.
"""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

from cobo_agentic_wallet_api.models.create_approval_request import CreateApprovalRequest
from cobo_agentic_wallet_api.models.resolve_approval_request import ResolveApprovalRequest

if TYPE_CHECKING:
    from cobo_agentic_wallet._mixins.base import BaseClient


class ApprovalMixin:
    """Approval operations mixin (auto-generated)."""

    _extract_result: Any
    _approvals_api: Any

    async def create_approval(
        self: "BaseClient", wallet_id: str = None, approval_type: str = None, payload: str = None
    ) -> Any:
        """Create approval request"""
        create_approval_request = CreateApprovalRequest(
            wallet_id=wallet_id, approval_type=approval_type, payload=payload
        )
        response = await self._approvals_api.create_approval(create_approval_request)
        return self._extract_result(response)

    async def get_approval(self: "BaseClient", approval_id: str) -> Any:
        """Get approval details"""
        response = await self._approvals_api.get_approval(approval_id)
        return self._extract_result(response)

    async def list_approvals(
        self: "BaseClient",
        status: Any | None = None,
        offset: int | None = None,
        limit: int | None = None,
    ) -> Any:
        """List approvals"""
        response = await self._approvals_api.list_approvals(status, offset, limit)
        return self._extract_result(response)

    async def resolve_approval(
        self: "BaseClient",
        approval_id: str,
        *,
        action: str,
        approval_result: str | None = None,
        rejection_reason: str | None = None,
    ) -> Any:
        """Resolve approval request"""
        resolve_approval_request = ResolveApprovalRequest(
            action=action, approval_result=approval_result, rejection_reason=rejection_reason
        )
        response = await self._approvals_api.resolve_approval(approval_id, resolve_approval_request)
        return self._extract_result(response)
