# Contributing to dobbe

See the full [contributing guide](docs/contributing.md) for development setup, testing, and PR guidelines.

**Quick start:**
```bash
git clone https://github.com/nareshnavinash/dobbe.git
cd dobbe
pip install -e ".[dev]"
pytest
```

994 tests with 98%+ coverage.
