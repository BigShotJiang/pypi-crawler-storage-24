# CLI Reference

Complete reference for every dobbe command and option.

## Global Options

```
dobbe [OPTIONS] COMMAND
```

| Option | Type | Default | Description |
|---|---|---|---|
| `--version` / `-v` | `bool` | `False` | Show version and exit |
| `--no-color` | `bool` | `False` | Disable colored output (also respects `NO_COLOR` env var) |

---

## dobbe vuln scan

Scan repositories for Dependabot vulnerabilities and triage with AI.

```
dobbe vuln scan [OPTIONS]
```

| Option | Type | Default | Description |
|---|---|---|---|
| `--repo` / `-r` | `str` | - | Single repo to scan (`org/repo`) |
| `--org` / `-o` | `str` | - | Scan all repos in an organization |
| `--user` / `-u` | `str` | - | Scan all repos for a GitHub user |
| `--severity` / `-s` | `str` | `critical,high` | Comma-separated severity filter |
| `--format` / `-f` | `str` | `table` | Output format: `table`, `json`, `markdown` |
| `--verbose` / `-V` | `bool` | `False` | Show evidence, CVEs, and upgrade paths |
| `--quiet` / `-q` | `bool` | `False` | Suppress progress output |
| `--output` | `str` | - | Write output to file |
| `--notify` | `str` | - | Send report to platform (`slack`, `jira`) |
| `--channel` | `str` | - | Notification channel |

Mutually exclusive: `--repo`, `--org`, `--user` (at most one).

---

## dobbe vuln resolve

Scan, fix, and verify vulnerable dependencies with an agentic feedback loop.

```
dobbe vuln resolve [OPTIONS]
```

| Option | Type | Default | Description |
|---|---|---|---|
| `--repo` / `-r` | `str` | - | Repository to fix (`org/repo`) |
| `--org` / `-o` | `str` | - | Resolve all repos in an organization |
| `--user` / `-u` | `str` | - | Resolve all repos for a GitHub user |
| `--severity` / `-s` | `str` | `critical,high` | Comma-separated severity filter |
| `--max-iterations` | `int` | `3` | Max fix-verify iterations (1-10) |
| `--base` | `str` | `main` | Base branch |
| `--branch` | `str` | auto | Branch name for fixes |
| `--create-pr` / `--no-pr` | `bool` | `True` | Create PR on convergence |
| `--dry-run` | `bool` | `False` | Scan only, no edits |
| `--skip-verify` | `bool` | `False` | Skip verification step |
| `--format` / `-f` | `str` | `table` | Output format: `table`, `json`, `markdown` |
| `--from-scan` | `str` | - | Path to scan JSON from `dobbe vuln scan --format json`. Use `'-'` for stdin. |

Exactly one of `--repo`, `--org`, `--user` required.

---

## dobbe review digest

Fetch open PRs, analyze with AI, and output a prioritized review digest.

```
dobbe review digest [OPTIONS]
```

| Option | Type | Default | Description |
|---|---|---|---|
| `--repo` / `-r` | `str` | - | Single repo to review (`org/repo`) |
| `--org` / `-o` | `str` | - | Review all repos in an organization |
| `--reviewer` | `str` | `@me` | GitHub username to filter by |
| `--stale-days` | `int` | `7` | Days before flagging PR as stale |
| `--format` / `-f` | `str` | `table` | Output format: `table`, `json`, `markdown` |
| `--verbose` / `-V` | `bool` | `False` | Show diff stats, recommendations, concerns |
| `--output` | `str` | - | Write output to file |
| `--notify` | `str` | - | Send digest to platform (`slack`) |
| `--channel` | `str` | - | Notification channel |
| `--skip-label` | `str` | - | Skip PRs with these labels (comma-separated) |
| `--skip-author` | `str` | - | Skip PRs by these authors (comma-separated) |
| `--max-diff-lines` | `int` | `2000` | Max diff lines per PR |
| `--quiet` / `-q` | `bool` | `False` | Suppress progress output |

---

## dobbe review post

Analyze PRs with AI and post reviews to GitHub.

```
dobbe review post [OPTIONS]
```

| Option | Type | Default | Description |
|---|---|---|---|
| `--repo` / `-r` | `str` | - | Single repo (`org/repo`) |
| `--org` / `-o` | `str` | - | Review all repos in an organization |
| `--pr` | `int` | - | PR number to review (requires `--repo`) |
| `--all` | `bool` | `False` | Review all open PRs |
| `--reviewer` | `str` | - | GitHub username to filter by |
| `--dry-run` | `bool` | `False` | Preview without posting |
| `--format` / `-f` | `str` | `table` | Output format: `table`, `json`, `markdown` |
| `--verbose` / `-V` | `bool` | `False` | Show concern details |
| `--output` | `str` | - | Write output to file |
| `--skip-label` | `str` | - | Skip PRs with these labels (comma-separated) |
| `--skip-author` | `str` | - | Skip PRs by these authors (comma-separated) |
| `--max-diff-lines` | `int` | `2000` | Max diff lines per PR |
| `--quiet` / `-q` | `bool` | `False` | Suppress progress output |

Defaults to `--all` when neither `--pr` nor `--all` given. Cannot use `--pr` and `--all` together. `--pr` requires `--repo`.

---

## dobbe schedule add

Add a new scheduled task.

```
dobbe schedule add <name> --command <cmd> --every <interval> [--args <args>]
```

| Argument/Option | Type | Default | Description |
|---|---|---|---|
| `name` (arg) | `str` | *required* | Unique schedule name |
| `--command` / `-c` | `str` | *required* | dobbe command to schedule |
| `--args` / `-a` | `str` | `""` | Command arguments |
| `--every` / `-e` | `ScheduleInterval` | *required* | `hourly`, `every_4h`, `every_12h`, `daily`, `weekly` |

---

## dobbe schedule list

List all scheduled tasks.

```
dobbe schedule list
```

No options.

---

## dobbe schedule remove

Remove a scheduled task.

```
dobbe schedule remove <name> [--force]
```

| Argument/Option | Type | Default | Description |
|---|---|---|---|
| `name` (arg) | `str` | *required* | Schedule name |
| `--force` / `-f` | `bool` | `False` | Skip confirmation |

---

## dobbe schedule check

Check for overdue schedules and run them.

```
dobbe schedule check [--quiet] [--dry-run]
```

| Option | Type | Default | Description |
|---|---|---|---|
| `--quiet` / `-q` | `bool` | `False` | Minimal output |
| `--dry-run` | `bool` | `False` | Show what would run |

---

## dobbe schedule run

Run a schedule immediately.

```
dobbe schedule run <name>
```

| Argument | Type | Description |
|---|---|---|
| `name` | `str` | Schedule name |

---

## dobbe schedule logs

View recent run logs.

```
dobbe schedule logs [name] [--limit N]
```

| Argument/Option | Type | Default | Description |
|---|---|---|---|
| `name` (arg) | `str` | - | Schedule name (omit for all) |
| `--limit` / `-n` | `int` | `10` | Number of logs |

---

## dobbe schedule install

Install automatic schedule checking.

```
dobbe schedule install [--trigger <type>] [--shell <shell>] [--uninstall]
```

| Option | Type | Default | Description |
|---|---|---|---|
| `--trigger` | `str` | `shell` | `shell` or `login` |
| `--shell` | `str` | auto-detect | `bash`, `zsh`, `fish` |
| `--uninstall` | `bool` | `False` | Remove hook |

---

## dobbe setup

Interactive setup wizard.

```
dobbe setup
```

No options. Runs a 5-step interactive wizard.

---

## dobbe doctor

Check environment health.

```
dobbe doctor
```

No options. Runs 9 automatic health checks.

---

## dobbe config show

Display current configuration.

```
dobbe config show
```

No options.

---

## dobbe config check

Deprecated - redirects to `dobbe doctor`.

```
dobbe config check
```

No options.
