# Configuration Reference

dobbe stores all configuration and state in `~/.dobbe/`.

## File Locations

| Path | Purpose |
|---|---|
| `~/.dobbe/config.toml` | User configuration |
| `~/.dobbe/schedules.toml` | Scheduled task definitions |
| `~/.dobbe/state.toml` | Persistent state |
| `~/.dobbe/logs/schedules/{name}/` | Per-schedule JSON run logs |
| `~/.dobbe/locks/{name}.lock/` | Directory-based schedule locks |

## Full config.toml Reference

```toml
[general]
# Default GitHub organization (used when --org is not specified)
# Type: string
# Default: ""
default_org = "nareshnavinash"

# Default output format for all commands
# Type: string (one of: "table", "json", "markdown")
# Default: "table"
default_format = "table"

# Default severity filter for vulnerability commands
# Type: string (comma-separated: "critical", "high", "medium", "low")
# Default: "critical,high"
default_severity = "critical,high"

[notifications]
# Default Slack channel for --notify slack
# Type: string
# Default: ""
slack_channel = "#security-alerts"

[repos]
# Local repository paths for faster scanning (avoids cloning)
# Type: array of strings (absolute paths, ~ expansion supported)
# Default: []
local_paths = [
    "~/projects/api",
    "~/projects/web",
    "~/projects/mobile",
]

[review]
# Repositories to include in review commands when --org is not specified
# Type: array of strings (org/repo format)
# Default: []
watch_repos = [
    "nareshnavinash/api",
    "nareshnavinash/web",
]

# GitHub usernames to filter PRs by (default: current user)
# Type: array of strings
# Default: ["@me"]
reviewers = ["@me"]

# Days before a PR is flagged as stale
# Type: integer
# Default: 7
stale_days = 7

# Labels to skip when scanning PRs
# Type: array of strings
# Default: []
skip_labels = ["wip", "do-not-review"]

# Authors to skip when scanning PRs
# Type: array of strings
# Default: []
skip_authors = ["dependabot", "renovate"]

# Maximum diff lines to include in PR analysis
# Type: integer
# Default: 2000
max_diff_lines = 2000
```

## Environment Variables

| Variable | Effect |
|---|---|
| `NO_COLOR` | Disable colored output (any value) |
| `DOBBE_QUIET` | Set to `"1"` to suppress all progress output |
| `CI` | Detected for CI environment behavior |

## schedules.toml Format

Managed by `dobbe schedule` commands. Manual editing is supported but not recommended.

```toml
[daily-scan]
command = "vuln scan"
args = "--org nareshnavinash --notify slack --channel #security"
interval = "daily"
enabled = true
last_run = "2026-03-20T09:00:00"
created_at = "2026-03-01T10:30:00"

[weekly-review]
command = "review digest"
args = "--org nareshnavinash --format markdown --output ~/reports/review.md"
interval = "weekly"
enabled = true
last_run = "2026-03-17T08:00:00"
created_at = "2026-03-01T10:35:00"
```

### Schedule Fields

| Field | Type | Description |
|---|---|---|
| `command` | `str` | dobbe command (e.g., `"vuln scan"`, `"review digest"`) |
| `args` | `str` | Command arguments |
| `interval` | `str` | `hourly`, `every_4h`, `every_12h`, `daily`, `weekly` |
| `enabled` | `bool` | Whether the schedule is active |
| `last_run` | `str` | ISO 8601 datetime of last execution |
| `created_at` | `str` | ISO 8601 datetime of creation |

## Config Defaults Cascade

CLI options take precedence over config values:

```
CLI flag > config.toml value > built-in default
```

For example:

- `--format json` overrides `default_format = "table"` in config
- `--severity critical` overrides `default_severity = "critical,high"` in config
- If neither CLI flag nor config value is set, the built-in default applies

## See Also

- [Getting started](../getting-started.md) - setup wizard creates initial config
- [CLI reference](cli-reference.md) - all command options
- [Schedule command](../commands/schedule.md) - managing schedules
