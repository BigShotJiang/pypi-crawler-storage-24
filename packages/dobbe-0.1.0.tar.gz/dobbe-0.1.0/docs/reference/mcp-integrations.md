# MCP Integrations

dobbe auto-discovers MCP (Model Context Protocol) servers from your Claude Code configuration and uses them for enhanced capabilities.

## What Are MCPs?

MCP servers are plugins that extend Claude Code's capabilities by providing access to external APIs and services. When Claude Code is configured with MCP servers, dobbe detects them and includes the corresponding tools in agent prompts.

## How dobbe Discovers MCPs

dobbe reads MCP configuration from two locations:

1. **User-level**: `~/.claude/settings.json` → `mcpServers` section
2. **Project-level**: `.claude/settings.json` → `mcpServers` section

It also checks `enabledPlugins` in both files.

Each server name, command, and args are matched against known patterns to classify which service it provides. Results are cached for the session.

## Supported MCPs

### GitHub

**Detection patterns**: name/command/args containing "github"

**Tool prefix**: `mcp__github__*`

**What it enables**:
- Direct API access for fetching Dependabot alerts
- PR discovery and metadata retrieval
- Review posting
- Faster than `gh` CLI fallback

**Fallback behavior**: When the GitHub MCP is not available, dobbe instructs Claude to use `gh api` commands via the Bash tool. This is slower but functionally equivalent.

**Used by**: `vuln scan`, `vuln resolve`, `review digest`, `review post`

### Slack

**Detection patterns**: name/command/args containing "slack"

**Tool prefix**: `mcp__claude_ai_Slack__*`

**What it enables**:
- Post vulnerability scan reports to Slack channels
- Post review digests to Slack channels
- Rich message formatting

**Setup**: Configure the Slack MCP in Claude Code, then use `--notify slack --channel "#your-channel"` with scan or review commands.

**Used by**: `vuln scan` (with `--notify slack`), `review digest` (with `--notify slack`)

### Atlassian / Jira

**Detection patterns**: name/command/args containing "atlassian", "jira", or "confluence"

**Tool prefix**: `mcp__claude_ai_Atlassian__*`

**What it enables**:
- Create Jira tickets for critical/high-risk vulnerabilities
- Link tickets to specific Dependabot alerts

**Setup**: Configure the Atlassian MCP in Claude Code, then use `--notify jira` with scan commands.

**Used by**: `vuln scan` (with `--notify jira`)

### Sentry

**Detection patterns**: name/command/args containing "sentry"

**Tool prefix**: `mcp__claude_ai_Sentry__*`

**What it enables**:
- Correlate vulnerability alerts with runtime error data
- Enrich triage decisions with production impact information

**Used by**: Available to scan and fix agents when configured

### Figma

**Detection patterns**: name/command/args containing "figma"

**Tool prefix**: `mcp__claude_ai_Figma__*`

**What it enables**:
- Available for future design-related workflows

**Used by**: Currently discovered but not actively used by any command

## Tool Prefix Mapping

When an MCP is discovered, dobbe adds its tool prefix to the `--allowedTools` list for relevant agents:

```
github     -> mcp__github__*
slack      -> mcp__claude_ai_Slack__*
atlassian  -> mcp__claude_ai_Atlassian__*
sentry     -> mcp__claude_ai_Sentry__*
figma      -> mcp__claude_ai_Figma__*
unknown    -> mcp__{name}__*
```

## Checking MCP Availability

Run `dobbe doctor` to see which MCPs are detected:

```bash
dobbe doctor
```

The doctor output includes checks for:
- GitHub MCP availability
- Slack MCP availability

Or run `dobbe setup` which reports all discovered MCPs in Step 3.

## Setting Up MCPs

### GitHub MCP

Add to your Claude Code settings (`~/.claude/settings.json`):

```json
{
  "mcpServers": {
    "github": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"],
      "env": {
        "GITHUB_PERSONAL_ACCESS_TOKEN": "ghp_..."
      }
    }
  }
}
```

### Slack MCP

Use Claude Code's built-in Slack integration or add a custom MCP server. The built-in integration appears in `enabledPlugins` and is auto-detected.

### Atlassian MCP

Use Claude Code's built-in Atlassian integration or configure a custom MCP server. The built-in integration appears in `enabledPlugins`.

### Sentry MCP

Use Claude Code's built-in Sentry integration or configure a custom MCP server.

## See Also

- [Architecture overview](../architecture/overview.md) - MCP discovery internals
- [Getting started](../getting-started.md) - setup wizard MCP detection
- [doctor command](../commands/doctor.md) - MCP health checks
