# Review Pipeline Deep Dive

The review pipeline is a 5-phase async system that discovers, filters, analyzes, and prioritizes (or posts) PR reviews.

## Pipeline Flowchart

```
┌─────────────────────────────────────────────────────┐
│  run_review_digest(repos, reviewers, ...)            │
│  run_review_post(repos, reviewers, ...)              │
└──────────────────────────┬──────────────────────────┘
                           │
                           v
┌─────────────────────────────────────────────────────┐
│  PHASE 1: FETCH PRs                                  │
│                                                      │
│  For each repo (parallel, semaphore=5):              │
│  ┌─────────────────────────────────────────────┐     │
│  │  Option A: Single PR mode (--pr N)          │     │
│  │  _fetch_single_pr(repo, N)                  │     │
│  │  -> Direct gh API fetch                      │     │
│  ├─────────────────────────────────────────────┤     │
│  │  Option B: Discovery mode (--all / default)  │     │
│  │  _fetch_prs_for_repo(repo, reviewers, mcps) │     │
│  │  -> Claude prompt: PR_DISCOVERY_PROMPT       │     │
│  │  -> Parse JSON -> list[PRInfo]               │     │
│  └─────────────────────────────────────────────┘     │
│                                                      │
│  Collect all PRs + errors across repos               │
└──────────────────────────┬──────────────────────────┘
                           │
                           v
┌─────────────────────────────────────────────────────┐
│  PHASE 2: FILTER                                     │
│                                                      │
│  _filter_prs(prs, skip_labels, skip_authors,         │
│              skip_drafts=True)                        │
│                                                      │
│  Remove:                                             │
│  - Draft PRs                                         │
│  - PRs with labels matching --skip-label             │
│  - PRs from authors matching --skip-author           │
└──────────────────────────┬──────────────────────────┘
                           │
                           v
┌─────────────────────────────────────────────────────┐
│  PHASE 3: PRE-FETCH DIFFS                            │
│                                                      │
│  For each PR (parallel, semaphore=5):                │
│  _fetch_diff_for_pr(pr, max_diff_lines)              │
│                                                      │
│  - Fetch full diff via gh CLI                        │
│  - Truncate to max_diff_lines (default: 2000)        │
│  - Pass inline to analysis prompt for accuracy       │
└──────────────────────────┬──────────────────────────┘
                           │
                           v
┌─────────────────────────────────────────────────────┐
│  PHASE 4: ANALYZE                                    │
│                                                      │
│  For each PR (parallel, semaphore=5):                │
│  _analyze_pr(pr, mcps, diff_content)                 │
│                                                      │
│  Claude prompt: PR_REVIEW_PROMPT_TEMPLATE            │
│  - Analyze: security, test coverage, breaking        │
│    changes, code quality, complexity                 │
│  - Output: risk_level, summary, concerns[],          │
│    recommendations[], estimated_review_time,         │
│    approval_recommendation                           │
│  - Parse JSON -> PRReviewResult                      │
│  - On error: PRReviewResult with analysis_error      │
└──────────────────────────┬──────────────────────────┘
                           │
                           v
           ┌───────────────┴───────────────┐
           │                               │
     (digest path)                   (post path)
           │                               │
           v                               v
┌──────────────────────┐   ┌──────────────────────────┐
│ PHASE 5a: PRIORITIZE │   │ PHASE 5b: DEDUP + POST   │
│                      │   │                          │
│ _prioritize_results  │   │ For each result:         │
│ Sort by:             │   │ 1. Check existing review │
│ 1. Risk level        │   │    at current head SHA   │
│    (critical first)  │   │ 2. Skip if already       │
│ 2. Age (oldest first)│   │    reviewed              │
│                      │   │ 3. Build review payload: │
│ Flag stale PRs       │   │    - Body with summary   │
│ (> stale_days)       │   │    - Inline comments at  │
│                      │   │      file:line            │
│ Return ReviewDigest  │   │ 4. Post via gh CLI       │
│                      │   │    (unless --dry-run)    │
│                      │   │                          │
│                      │   │ Return ReviewPostReport  │
└──────────────────────┘   └──────────────────────────┘
```

## PR Discovery

Two modes for finding PRs:

### Claude-based discovery (default)

Uses `PR_DISCOVERY_PROMPT_TEMPLATE` - instructs Claude to find open PRs where the specified reviewers are requested. The prompt adapts based on GitHub MCP availability:

- **With MCP**: Uses `mcp__github__*` tools for direct API access
- **Without MCP**: Falls back to `gh pr list` via Bash

Returns structured JSON parsed into `PRInfo` objects with full metadata: additions, deletions, changed files, labels, draft status, description.

### Direct fetch (single PR)

`_fetch_single_pr()` fetches a specific PR by number using `gh api`, bypassing Claude entirely. Used when `--pr N` is specified.

## Diff Pre-fetching

Phase 3 fetches diffs in parallel before analysis. This is a performance optimization - embedding the diff directly in the analysis prompt gives Claude better context than asking it to fetch the diff itself.

- Diffs are truncated at `max_diff_lines` (default: 2000) to stay within prompt limits
- If fetching fails, the analysis still proceeds - Claude can fetch the diff itself via tools

## Analysis Model

The analysis prompt (`PR_REVIEW_PROMPT_TEMPLATE`) asks Claude to perform a senior engineer code review across 5 categories:

| Category | What It Checks |
|---|---|
| **Security** | Input validation, auth, injection, secrets exposure |
| **Test coverage** | New code has tests, edge cases covered |
| **Breaking changes** | API removals, type changes, behavioral shifts |
| **Code quality** | Naming, structure, duplication, error handling |
| **Complexity** | Cognitive load, nesting depth, function length |

Each concern includes:

- Category and severity
- Description of the issue
- File path and line number (for inline comments)
- Suggested fix

## Prioritization

The `_prioritize_results()` function sorts using a severity order:

```
CRITICAL (0) > HIGH (1) > MEDIUM (2) > LOW (3)
```

Within the same risk level, PRs are sorted by age (oldest first), ensuring long-waiting reviews surface to the top.

## Review Posting

For `review post`, Phase 5b handles deduplication and posting:

### Deduplication

Before posting, dobbe checks:

1. **Head SHA match** - has the PR been updated since the last review?
2. **Existing review** - does a dobbe-authored review already exist?

If both conditions indicate a prior review exists at the current SHA, the PR is skipped with the reason recorded in `PostResult.skipped_reason`.

### Payload Construction

The review payload posted to GitHub includes:

- **Body**: Overall summary with risk level, approval recommendation, and key concerns
- **Inline comments**: Each concern with a `file_path` and `line_number` becomes an inline review comment positioned at the exact code location

### Posting

Reviews are posted via `gh api` commands through the Bash tool. In `--dry-run` mode, the payload is logged but not posted.

## Concurrency Model

All phases use `asyncio` with semaphore-controlled concurrency:

- **Semaphore limit**: 5 concurrent operations (configurable via `max_concurrent`)
- **Phases 1, 3, 4**: Run in parallel across PRs/repos
- **Phase 5b (posting)**: Dedup checks run in parallel, posting runs sequentially to respect GitHub rate limits

## Error Handling

- **Per-repo errors** in Phase 1 are captured in the `errors` list without failing the entire pipeline
- **Per-PR analysis errors** in Phase 4 produce a `PRReviewResult` with `analysis_error` set instead of crashing
- **Posting errors** in Phase 5b are captured in `PostResult.error`

## See Also

- [review digest command reference](../commands/review-digest.md)
- [review post command reference](../commands/review-post.md)
- [Architecture overview](overview.md)
