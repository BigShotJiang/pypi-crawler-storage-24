# Architecture Overview

dobbe is a CLI tool that orchestrates Claude AI agents to automate vulnerability management and code review for GitHub repositories.

## Layer Architecture

```
┌─────────────────────────────────────────────────┐
│                 Terminal User                     │
└──────────────────────┬──────────────────────────┘
                       │
                       v
┌─────────────────────────────────────────────────┐
│              CLI Layer (cli.py / Typer)           │
│  Global options: --version, --no-color            │
└──────────────────────┬──────────────────────────┘
                       │
                       v
┌─────────────────────────────────────────────────┐
│             Command Layer                         │
│  vuln.py | review.py | schedule.py | setup.py    │
│  doctor.py | config.py                            │
└──────┬──────────┬──────────┬────────────────────┘
       │          │          │
       v          v          v
┌────────────┐ ┌──────────┐ ┌──────────────────┐
│ Core Layer │ │  Models  │ │  Output Layer    │
│ claude.py  │ │ alert.py │ │ table.py         │
│ pipeline.py│ │resolve.py│ │ json_out.py      │
│ prompts.py │ │review.py │ │ markdown.py      │
│ scheduler. │ │schedule. │ │ transcript.py    │
│   py       │ │  py      │ │ progress.py      │
└──────┬─────┘ └──────────┘ └──────────────────┘
       │
       v
┌─────────────────────────────────────────────────┐
│           External Tools (subprocess)             │
│  Claude Code CLI  |  gh CLI  |  MCP Servers       │
└─────────────────────────────────────────────────┘
```

## Layers

### CLI Layer (`cli.py`)

The entry point built with [Typer](https://typer.tiangolo.com/). Registers command groups (`vuln`, `review`, `schedule`, `setup`, `doctor`, `config`), handles global options (`--version`, `--no-color`), and respects `NO_COLOR` and `DOBBE_QUIET` environment variables.

### Command Layer (`commands/`)

Each module defines Typer subcommands with option parsing, validation, and orchestration:

| Module | Commands |
|---|---|
| `vuln.py` | `scan`, `resolve` |
| `review.py` | `digest`, `post` |
| `schedule.py` | `add`, `list`, `remove`, `check`, `run`, `logs`, `install` |
| `setup.py` | interactive wizard |
| `doctor.py` | health checks |
| `config.py` | `show`, `check` |

Commands validate inputs, merge CLI options with config defaults, and delegate to the core layer.

### Core Layer (`core/`)

Business logic that is command-agnostic:

| Module | Responsibility |
|---|---|
| `claude.py` | Claude subprocess invocation, tool allowlists, retry logic |
| `pipeline.py` | Vulnerability resolve pipeline orchestration |
| `review_pipeline.py` | Review digest/post async pipeline |
| `prompts.py` | All prompt templates and builders |
| `config_manager.py` | Config loading, saving, defaults |
| `scheduler.py` | Schedule persistence, locking, execution, hooks |
| `mcp_discovery.py` | MCP server discovery and classification |
| `repo_resolver.py` | Local/remote repository resolution |
| `response_parser.py` | Claude response JSON parsing |
| `notifier.py` | Slack/Jira notification dispatch |
| `batch_resolve.py` | Batch vulnerability resolution across repos |
| `github_review.py` | GitHub PR review posting logic |
| `org_repos.py` | Organization repository listing |
| `state_manager.py` | State persistence |
| `first_run.py` | First-run setup prompts |

### Models Layer (`models/`)

Pydantic v2 models for structured data:

| Module | Models |
|---|---|
| `shared.py` | Enums: `Severity`, `AccessMode`, `FixStatus`, `VerifyCategory`, `ReviewCategory` |
| `alert.py` | `Alert`, `TriageResult`, `AlertGroup`, `RepoResult`, `ScanReport` |
| `resolve.py` | `FixAction`, `SkippedFix`, `FixResult`, `VerifyResult`, `PipelineIteration`, `ResolveReport`, `BatchResolveReport` |
| `review.py` | `PRInfo`, `ReviewConcern`, `PRReviewResult`, `ReviewDigest`, `PostResult`, `ReviewPostReport` |
| `schedule.py` | `ScheduleInterval`, `Schedule`, `RunLog`, `CheckResult` |

### Output Layer (`output/`)

Renderers for different output formats:

| Module | Format |
|---|---|
| `table.py`, `review_table.py`, `review_post_table.py` | Rich table output |
| `json_out.py` | JSON serialization |
| `markdown.py`, `review_markdown.py`, `review_post_markdown.py` | Markdown report generation |
| `transcript.py` | Agent conversation transcript |
| `progress.py` | Rich progress bars and spinners |
| `status.py` | Status messages |
| `helpers.py` | Shared output utilities |

## Claude Integration Model

dobbe invokes Claude Code as a subprocess, not as an API:

```
claude -p "<prompt>" --allowedTools "Bash,Read,Grep,Glob" --output-format json
```

Key design choices:

- **Subprocess model** - uses `claude -p` (non-interactive prompt mode) with JSON output format
- **Tool allowlists** - each agent role gets scoped tool permissions via `--allowedTools`
- **Retry with backoff** - failed invocations retry up to 2 times with exponential backoff (2^attempt seconds)
- **Timeout enforcement** - default 300s per invocation, 600s for scans, 1800s for scheduled tasks
- **Async support** - `ask_claude_async()` uses `asyncio.create_subprocess_exec` for parallel execution

### Tool Sets by Role

```
Scan agent:    [Bash, Read, Grep, Glob] + MCP tools
Fix agent:     [Bash, Read, Grep, Glob, Edit, Write] + MCP tools
Verify agent:  [Bash, Read, Grep, Glob]
Report agent:  [Read]
Review agent:  [Bash, Read, Grep, Glob] + MCP tools
```

## MCP Discovery

dobbe auto-discovers MCP servers from Claude Code's settings:

1. Read `~/.claude/settings.json` (user-level)
2. Read `.claude/settings.json` (project-level)
3. Extract `mcpServers` and `enabledPlugins`
4. Classify each server against known patterns (GitHub, Slack, Atlassian, Sentry, Figma)
5. Cache results for the session

Tool prefix mapping for `--allowedTools`:

| MCP | Prefix Pattern |
|---|---|
| GitHub | `mcp__github__*` |
| Slack | `mcp__claude_ai_Slack__*` |
| Atlassian | `mcp__claude_ai_Atlassian__*` |
| Sentry | `mcp__claude_ai_Sentry__*` |
| Figma | `mcp__claude_ai_Figma__*` |

When the GitHub MCP is not available, dobbe falls back to using `gh` CLI commands via the Bash tool.

## Repository Resolution

dobbe resolves repository slugs (`org/repo`) to local paths for direct file access:

```
1. Check configured local_paths in ~/.dobbe/config.toml
2. Scan common project directories:
   ~/projects, ~/Projects, ~/Desktop/Projects,
   ~/code, ~/Code, ~/src, ~/repos, ~/dev,
   ~/workspace, ~/Developer
3. Check current working directory
4. Fall back to remote access (MCP or gh CLI)
```

Returns `AccessMode.LOCAL` with a path or `AccessMode.REMOTE` with `None`. Batch resolution pre-scans directories once for efficiency.

## Output Pipeline

All output follows the same flow:

```
Claude JSON response
       |
       v
Pydantic model parsing (with validation)
       |
       v
Format selection (--format flag or config default)
       |
       v
Renderer: Rich table / JSON / Markdown
       |
       v
Destination: stdout / --output file / --notify platform
```

## See Also

- [Resolve pipeline deep dive](resolve-pipeline.md)
- [Review pipeline deep dive](review-pipeline.md)
- [Configuration reference](../reference/configuration.md)
