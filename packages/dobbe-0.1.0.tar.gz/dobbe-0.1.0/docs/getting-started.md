# Getting Started

This guide walks you through installing dobbe, running the setup wizard, and executing your first scan and review.

## Prerequisites

Before installing dobbe, ensure you have:

- [ ] **Python 3.11+** - [download](https://www.python.org/downloads/)
- [ ] **Claude Code CLI** - installed and authenticated ([docs](https://docs.anthropic.com/en/docs/claude-code))
- [ ] **gh CLI** - for GitHub API access ([install](https://cli.github.com/))
- [ ] **GitHub access** - to the repositories you want to scan

Optional but recommended:

- [ ] **GitHub MCP server** - for direct API access (faster than `gh` CLI fallback)
- [ ] **Slack MCP server** - for posting reports to Slack channels

## Installation

### From PyPI

```bash
pip install dobbe
```

### With pipx (recommended for CLI tools)

```bash
pipx install dobbe
```

### Development install

```bash
git clone https://github.com/nareshnavinash/dobbe.git
cd dobbe
pip install -e ".[dev]"
```

## First-Time Setup

Run the interactive setup wizard:

```bash
dobbe setup
```

The wizard walks through 5 steps:

### Step 1: Claude Code CLI

Checks that the `claude` binary is installed and on your PATH. If not found, the wizard provides installation instructions.

### Step 2: Authentication

Verifies that Claude Code is authenticated by running a test prompt. If authentication fails, guides you through `claude auth`.

### Step 3: MCP Discovery

Scans your `~/.claude/settings.json` for configured MCP servers. Reports which integrations are available (GitHub, Slack, Atlassian, Sentry, Figma).

### Step 4: Default Organization

Prompts for your default GitHub organization. This is used as the fallback when `--org` is not specified.

### Step 5: Repository Scanning

Scans common project directories (`~/projects`, `~/code`, `~/src`, etc.) for local git repositories. Found repos are saved to config for faster local resolution.

After completing the steps, the wizard:

- Saves your configuration to `~/.dobbe/config.toml`
- Runs a smoke test to verify everything works
- Shows a post-setup menu with suggested next commands

## Your First Scan

Scan a single repository for vulnerabilities:

```bash
dobbe vuln scan --repo nareshnavinash/your-repo
```

This fetches Dependabot alerts, triages each one with AI (is the vulnerable code path actually used?), and outputs a prioritized report.

### Understanding the output

The scan report shows:

- **Package** - the vulnerable dependency
- **Severity** - the original CVE severity
- **Risk Level** - AI-adjusted severity based on code analysis
- **Affected** - whether the vulnerable code path is used in your codebase
- **Recommendation** - what to do about it

### Try verbose mode

Add `--verbose` to see evidence, CVE IDs, and upgrade paths:

```bash
dobbe vuln scan --repo nareshnavinash/your-repo --verbose
```

## Your First Review Digest

Get a prioritized digest of open PRs waiting for your review:

```bash
dobbe review digest --repo nareshnavinash/your-repo
```

The digest shows each PR ranked by risk level, with security concerns, test coverage gaps, and estimated review time.

## Next Steps

### Fix vulnerabilities automatically

```bash
dobbe vuln resolve --repo nareshnavinash/your-repo
```

This runs the full agentic fix-verify loop. See [vuln resolve](commands/vuln-resolve.md) for details.

### Scan first, fix later

Save scan results and resolve separately to avoid re-scanning:

```bash
dobbe vuln scan --repo nareshnavinash/your-repo --format json --output scan.json
dobbe vuln resolve --repo nareshnavinash/your-repo --from-scan scan.json
```

### Set up recurring scans

```bash
dobbe schedule add daily-scan \
  --command "vuln scan" \
  --args "--org nareshnavinash" \
  --every daily

dobbe schedule install --trigger shell
```

See [schedule](commands/schedule.md) for all scheduling options.

### Scan your entire organization

```bash
dobbe vuln scan --org nareshnavinash
dobbe review digest --org nareshnavinash
```

### Post AI reviews to GitHub

```bash
dobbe review post --repo nareshnavinash/your-repo --all
```

See [review post](commands/review-post.md) for deduplication and posting details.

### Tune your configuration

Edit `~/.dobbe/config.toml` to set defaults for severity filters, output format, Slack channels, and more. See the [configuration reference](reference/configuration.md).

### Check environment health

If something isn't working, run diagnostics:

```bash
dobbe doctor
```

See [doctor](commands/doctor.md) for details on the 9 health checks.
