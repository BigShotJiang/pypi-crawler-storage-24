# dobbe vuln scan

Scan repositories for Dependabot vulnerabilities and triage with AI.

## Synopsis

```
dobbe vuln scan [OPTIONS]
```

## Description

`vuln scan` fetches Dependabot vulnerability alerts from one or more GitHub repositories and uses Claude AI to triage each alert. The AI analyzes whether the vulnerable code path is actually used in your codebase, assigns adjusted risk levels, and provides evidence-backed recommendations.

## Flowchart

```
┌─────────────────────────────────────────────┐
│         dobbe vuln scan --repo org/repo      │
└──────────────────────┬──────────────────────┘
                       │
                       v
┌─────────────────────────────────────────────┐
│  Parse CLI args + merge config defaults      │
│  - severity from --severity or config        │
│  - format from --format or config            │
└──────────────────────┬──────────────────────┘
                       │
                       v
┌─────────────────────────────────────────────┐
│  Validate severity values                    │
│  (critical, high, medium, low only)          │
└──────────────────────┬──────────────────────┘
                       │
                       v
┌─────────────────────────────────────────────┐
│  Discover MCP servers                        │
│  (~/.claude/settings.json)                   │
└──────────────────────┬──────────────────────┘
                       │
                       v
┌─────────────────────────────────────────────┐
│  Resolve repo list                           │
│  --repo: single repo                         │
│  --org:  all repos in org                    │
│  --user: all repos for user                  │
└──────────────────────┬──────────────────────┘
                       │
                       v
┌─────────────────────────────────────────────┐
│  Resolve local paths (batch)                 │
│  configured paths -> common dirs -> remote   │
└──────────────────────┬──────────────────────┘
                       │
                       v
┌─────────────────────────────────────────────┐
│  Parallel scan (semaphore = 5)               │
│  For each repo:                              │
│    - Build scan prompt                       │
│    - Ask Claude async                        │
│    - Tools: [Bash, Read, Grep, Glob] + MCP   │
│    - Timeout: 600s per repo                  │
└──────────────────────┬──────────────────────┘
                       │
                       v
┌─────────────────────────────────────────────┐
│  Parse responses                             │
│  - Extract JSON from Claude output           │
│  - Build AlertGroup / TriageResult models    │
│  - Handle parse errors gracefully            │
└──────────────────────┬──────────────────────┘
                       │
                       v
┌─────────────────────────────────────────────┐
│  Build ScanReport                            │
│  - Aggregate stats by severity               │
│  - Count affected vs safe-to-ignore          │
└──────────────────────┬──────────────────────┘
                       │
                       v
┌─────────────────────────────────────────────┐
│  Render output                               │
│  --format table (default) / json / markdown  │
│  --output file (optional)                    │
└──────────────────────┬──────────────────────┘
                       │
                       v
┌─────────────────────────────────────────────┐
│  Optional: Notify                            │
│  --notify slack -> post to --channel         │
│  --notify jira  -> create tickets            │
└─────────────────────────────────────────────┘
```

## Options

| Option | Type | Default | Description |
|---|---|---|---|
| `--repo` / `-r` | `str` | - | Single repo to scan (`org/repo`) |
| `--org` / `-o` | `str` | - | Scan all repos in an organization |
| `--user` / `-u` | `str` | - | Scan all repos for a GitHub user |
| `--severity` / `-s` | `str` | `critical,high` | Comma-separated severity filter |
| `--format` / `-f` | `str` | `table` | Output format: `table`, `json`, `markdown` |
| `--verbose` / `-V` | `bool` | `False` | Show evidence, CVEs, and upgrade paths |
| `--quiet` / `-q` | `bool` | `False` | Suppress progress output, only show final result |
| `--output` | `str` | - | Write output to file instead of stdout |
| `--notify` | `str` | - | Send report to platform (`slack`, `jira`) |
| `--channel` | `str` | - | Notification channel (e.g., `#security-alerts`) |

At most one of `--repo`, `--org`, or `--user` may be specified. If none is given, the default organization from config is used.

## Examples

### Scan a single repository

```bash
dobbe vuln scan --repo nareshnavinash/api
```

### Scan all repos in an organization

```bash
dobbe vuln scan --org nareshnavinash
```

### Filter by severity and output verbose details

```bash
dobbe vuln scan --repo nareshnavinash/api --severity critical --verbose
```

### JSON output to file

```bash
dobbe vuln scan --org nareshnavinash --format json --output scan-report.json
```

### Send report to Slack

```bash
dobbe vuln scan --org nareshnavinash --notify slack --channel "#security-alerts"
```

## Saving Results for Later Use

Save scan results as JSON for use with [`dobbe vuln resolve --from-scan`](vuln-resolve.md#using-pre-computed-scan-results):

```bash
dobbe vuln scan --repo nareshnavinash/api --format json --output scan.json
dobbe vuln resolve --repo nareshnavinash/api --from-scan scan.json
```

Or pipe directly to avoid writing a file:

```bash
dobbe vuln scan --repo nareshnavinash/api --format json | dobbe vuln resolve --repo nareshnavinash/api --from-scan -
```

This avoids running the scan agent twice when scanning and resolving the same repository.

## Internal Architecture

### Prompt Construction

The scan prompt is built by `build_scan_prompt()` with:

- **Fetch instructions**: Uses GitHub MCP tools if available (`mcp__github__*`), otherwise instructs Claude to use `gh api` via Bash
- **Code instructions**: If the repo is resolved locally, instructs Claude to read source files directly. For remote repos, instructs analysis based on alert metadata only
- **Severity clause**: Filters alerts to the requested severity levels

### Async Scanning

Repos are scanned in parallel using `asyncio` with a semaphore limiting concurrency to 5 simultaneous scans. Each scan has a 600-second timeout. Errors for individual repos are captured in the `RepoResult.error` field without failing the entire batch.

### Response Parsing

Claude's JSON response is parsed into structured models:

- **AlertGroup**: Related alerts grouped by package (package name, current/target versions)
- **TriageResult**: Per-alert triage (severity, affected flag, evidence, risk level, recommendation)
- **RepoResult**: Per-repo aggregate (groups, total alerts, affected count)
- **ScanReport**: Cross-repo aggregate with severity statistics

### Output Models

The `ScanReport` provides computed properties:

- `total_alerts` - sum across all repos
- `total_affected` - alerts where the code path is actually used
- `total_safe_to_ignore` - alerts where the code path is not used
- `stats_by_severity` - breakdown by severity level

## See Also

- [vuln resolve](vuln-resolve.md) - scan and fix with the agentic loop
- [Configuration reference](../reference/configuration.md) - default severity and format settings
- [MCP integrations](../reference/mcp-integrations.md) - GitHub MCP for direct API access
