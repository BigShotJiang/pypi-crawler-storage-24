# dobbe setup

Interactive first-time setup wizard for dobbe.

## Synopsis

```
dobbe setup
```

No arguments or options. The wizard runs interactively.

## Description

`dobbe setup` walks you through configuring dobbe for first use. It checks prerequisites, discovers MCP servers, prompts for configuration values, runs a smoke test, and saves everything to `~/.dobbe/config.toml`.

## Wizard Flowchart

```
┌──────────────────────────────────────┐
│         dobbe setup                   │
└──────────────────┬───────────────────┘
                   │
                   v
┌──────────────────────────────────────┐
│  STEP 1: Claude Code CLI              │
│  - Check: is `claude` on PATH?        │
│  - Pass: show version                 │
│  - Fail: show install instructions    │
└──────────────────┬───────────────────┘
                   │
                   v
┌──────────────────────────────────────┐
│  STEP 2: Authentication               │
│  - Run test prompt with 30s timeout   │
│  - Pass: "authenticated"              │
│  - Fail: guide through `claude auth`  │
└──────────────────┬───────────────────┘
                   │
                   v
┌──────────────────────────────────────┐
│  STEP 3: MCP Discovery                │
│  - Read ~/.claude/settings.json       │
│  - Read .claude/settings.json         │
│  - Classify: GitHub, Slack,           │
│    Atlassian, Sentry, Figma           │
│  - Report available/missing           │
└──────────────────┬───────────────────┘
                   │
                   v
┌──────────────────────────────────────┐
│  STEP 4: Default Organization          │
│  - Prompt for GitHub org name          │
│  - Save to config.general.default_org  │
└──────────────────┬───────────────────┘
                   │
                   v
┌──────────────────────────────────────┐
│  STEP 5: Repository Scanning           │
│  - Scan common project directories:    │
│    ~/projects, ~/code, ~/src, etc.     │
│  - Find local git repositories         │
│  - Save to config.repos.local_paths    │
└──────────────────┬───────────────────┘
                   │
                   v
┌──────────────────────────────────────┐
│  SAVE CONFIG                           │
│  Write ~/.dobbe/config.toml            │
└──────────────────┬───────────────────┘
                   │
                   v
┌──────────────────────────────────────┐
│  SMOKE TEST                            │
│  Verify configuration works            │
└──────────────────┬───────────────────┘
                   │
                   v
┌──────────────────────────────────────┐
│  POST-SETUP MENU                       │
│  Suggest next commands:                │
│  - dobbe vuln scan --repo ...          │
│  - dobbe review digest --repo ...      │
│  - dobbe schedule add ...              │
│  - dobbe doctor                        │
└──────────────────────────────────────┘
```

## Re-running Setup

Running `dobbe setup` again is safe. It preserves existing notification settings and only updates values you change during the wizard.

## Sample Config Output

After setup, `~/.dobbe/config.toml` looks like:

```toml
[general]
default_org = "nareshnavinash"
default_format = "table"
default_severity = "critical,high"

[notifications]
slack_channel = ""

[repos]
local_paths = [
    "/Users/you/projects/api",
    "/Users/you/projects/web",
]
```

## See Also

- [Getting started](../getting-started.md) - full walkthrough
- [Configuration reference](../reference/configuration.md) - all config options
- [doctor](doctor.md) - verify environment health after setup
