# dobbe review post

Analyze PRs with AI and post reviews directly to GitHub.

## Synopsis

```
dobbe review post [OPTIONS]
```

## Description

`review post` extends the review pipeline by posting AI-generated reviews as GitHub PR reviews. It performs the same 5-phase analysis as `review digest`, then deduplicates against existing reviews and posts structured feedback with inline comments at specific file and line locations.

## Pipeline Flowchart

```
┌──────────────────────────────────────────┐
│   dobbe review post --repo org/repo       │
└─────────────────────┬────────────────────┘
                      │
                      v
┌──────────────────────────────────────────┐
│  PHASE 1: DISCOVER PRs                    │
│  --pr N: fetch single PR directly         │
│  --all:  discover all open PRs via Claude │
│  (default: --all if neither specified)    │
└─────────────────────┬────────────────────┘
                      │
                      v
┌──────────────────────────────────────────┐
│  PHASE 2: FILTER                          │
│  - Remove drafts                          │
│  - Apply --skip-label, --skip-author      │
└─────────────────────┬────────────────────┘
                      │
                      v
┌──────────────────────────────────────────┐
│  PHASE 3: PRE-FETCH DIFFS                 │
│  - Parallel diff fetching                 │
│  - Truncate at --max-diff-lines           │
└─────────────────────┬────────────────────┘
                      │
                      v
┌──────────────────────────────────────────┐
│  PHASE 4: ANALYZE                         │
│  - Full code review per PR                │
│  - Generate concerns with file:line refs  │
│  - Assign risk + recommendations          │
└─────────────────────┬────────────────────┘
                      │
                      v
┌──────────────────────────────────────────┐
│  PHASE 5: DEDUP + POST                    │
│                                           │
│  For each analyzed PR:                    │
│  ┌────────────────────────────────┐       │
│  │ Check existing reviews          │       │
│  │ - Compare head SHA              │       │
│  │ - Detect prior dobbe review     │       │
│  └─────────────┬──────────────────┘       │
│          ┌─────┴──────┐                   │
│          │ Already    │                   │
│          │ reviewed?  │                   │
│          └─────┬──────┘                   │
│        yes |       | no                   │
│            v       v                      │
│     ┌──────────┐ ┌─────────────────┐      │
│     │ Skip,    │ │ Build review    │      │
│     │ record   │ │ payload:        │      │
│     │ reason   │ │ - Body text     │      │
│     └──────────┘ │ - Inline        │      │
│                  │   comments at   │      │
│                  │   file:line     │      │
│                  └────────┬────────┘      │
│                           │               │
│                     ┌─────┴─────┐         │
│                     │ Dry run?  │         │
│                     └─────┬─────┘         │
│                   yes |       | no        │
│                       v       v           │
│                 ┌──────┐ ┌──────────┐     │
│                 │ Log  │ │ Post via │     │
│                 │ only │ │ gh CLI   │     │
│                 └──────┘ └──────────┘     │
└──────────────────────────────────────────┘
```

## Options

| Option | Type | Default | Description |
|---|---|---|---|
| `--repo` / `-r` | `str` | - | Single repo (`org/repo`) |
| `--org` / `-o` | `str` | - | Review all repos in an organization |
| `--pr` | `int` | - | PR number to review (requires `--repo`) |
| `--all` | `bool` | `False` | Review all open PRs |
| `--reviewer` | `str` | - | GitHub username to filter by |
| `--dry-run` | `bool` | `False` | Preview reviews without posting |
| `--format` / `-f` | `str` | `table` | Output format: `table`, `json`, `markdown` |
| `--verbose` / `-V` | `bool` | `False` | Show concern details with file:line and suggestions |
| `--output` | `str` | - | Write output to file instead of stdout |
| `--skip-label` | `str` | - | Skip PRs with these labels (comma-separated) |
| `--skip-author` | `str` | - | Skip PRs by these authors (comma-separated) |
| `--max-diff-lines` | `int` | `2000` | Max diff lines to include per PR |
| `--quiet` / `-q` | `bool` | `False` | Suppress progress output |

### Validation Rules

- If neither `--pr` nor `--all` is given, defaults to `--all`
- `--pr` and `--all` cannot be used together
- `--pr` requires `--repo`

## Deduplication

Before posting, dobbe checks whether it has already reviewed the PR at the current head SHA:

1. **Head SHA check** - if the PR has new commits since the last review, a new review is posted
2. **Existing review detection** - if a dobbe review already exists at the current SHA, the PR is skipped with the reason recorded in `PostResult.skipped_reason`

## Review Payload Structure

Each posted review contains:

- **Body** - overall summary with risk level, recommendations, and estimated review time
- **Inline comments** - attached to specific `file_path:line_number` locations from the concern list, each with a description and suggestion

## Output Models

### PostResult

Per-PR posting result:

- `posted` - whether the review was successfully posted
- `skipped_reason` - why the review was skipped (if applicable)
- `review_url` - URL of the posted review
- `error` - error message if posting failed

### ReviewPostReport

Aggregate report with computed properties:

- `total_posted` - reviews successfully posted
- `total_skipped` - reviews skipped (already reviewed)
- `total_failed` - reviews that failed to post
- `dry_run` - whether this was a dry run

## Examples

### Review a single PR

```bash
dobbe review post --repo nareshnavinash/api --pr 42
```

### Dry run all open PRs

```bash
dobbe review post --repo nareshnavinash/api --all --dry-run --verbose
```

### Post reviews for all repos in an org

```bash
dobbe review post --org nareshnavinash
```

## See Also

- [review digest](review-digest.md) - analyze without posting
- [Review pipeline architecture](../architecture/review-pipeline.md) - async pipeline internals
