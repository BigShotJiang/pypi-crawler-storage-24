# dobbe schedule

Manage scheduled tasks for automated dobbe command execution.

## Synopsis

```
dobbe schedule <subcommand> [OPTIONS]
```

## Subcommands

| Subcommand | Description |
|---|---|
| `add` | Add a new scheduled task |
| `list` | List all scheduled tasks |
| `remove` | Remove a scheduled task |
| `check` | Check for overdue schedules and run them |
| `run` | Run a schedule immediately |
| `logs` | View recent run logs |
| `install` | Install automatic schedule checking |

---

## schedule add

Add a new scheduled task.

```
dobbe schedule add <name> --command <cmd> --every <interval> [--args <args>]
```

### Arguments

| Argument | Type | Description |
|---|---|---|
| `name` | `str` | Unique name for this schedule |

### Options

| Option | Type | Default | Description |
|---|---|---|---|
| `--command` / `-c` | `str` | *required* | dobbe command to schedule |
| `--args` / `-a` | `str` | `""` | Arguments string |
| `--every` / `-e` | `ScheduleInterval` | *required* | Interval: `hourly`, `every_4h`, `every_12h`, `daily`, `weekly` |

### Known Commands

Only these commands can be scheduled:

- `vuln scan`
- `vuln resolve`
- `review digest`
- `review post`

### Interval Deltas

| Interval | Period |
|---|---|
| `hourly` | 1 hour |
| `every_4h` | 4 hours |
| `every_12h` | 12 hours |
| `daily` | 24 hours |
| `weekly` | 168 hours (7 days) |

---

## schedule list

List all scheduled tasks. Shows name, command, args, interval, enabled status, and last run time.

```
dobbe schedule list
```

No options.

---

## schedule remove

Remove a scheduled task.

```
dobbe schedule remove <name> [--force]
```

### Arguments

| Argument | Type | Description |
|---|---|---|
| `name` | `str` | Name of the schedule to remove |

### Options

| Option | Type | Default | Description |
|---|---|---|---|
| `--force` / `-f` | `bool` | `False` | Skip confirmation prompt |

---

## schedule check

Check for overdue schedules and run them. This is the command invoked by shell hooks and login triggers.

```
dobbe schedule check [--quiet] [--dry-run]
```

### Options

| Option | Type | Default | Description |
|---|---|---|---|
| `--quiet` / `-q` | `bool` | `False` | Minimal output (for shell hook) |
| `--dry-run` | `bool` | `False` | Show what would run without executing |

### Check Flowchart

```
┌──────────────────────────────────────┐
│    dobbe schedule check               │
└──────────────────┬───────────────────┘
                   │
                   v
┌──────────────────────────────────────┐
│  Acquire global lock                  │
│  "_schedule_check"                    │
│  (directory-based, PID tracking)      │
└──────────────────┬───────────────────┘
             ┌─────┴──────┐
             │ Lock held? │
             └─────┬──────┘
           no |        | yes
              v        v
              │   ┌──────────────┐
              │   │ Stale? (>2h  │
              │   │ or PID dead) │
              │   └──────┬───────┘
              │   yes |      | no
              │       v      v
              │   Break it   Exit
              │       │
              v       v
┌──────────────────────────────────────┐
│  Load schedules from TOML             │
│  Find overdue:                        │
│    now - last_run > interval + 5min   │
│  (first run: always overdue)          │
└──────────────────┬───────────────────┘
                   │
                   v
┌──────────────────────────────────────┐
│  For each overdue schedule:           │
│  1. Acquire per-schedule lock         │
│  2. Execute: python -m dobbe <cmd>    │
│     (timeout: 1800s)                  │
│  3. Capture exit code + output        │
│  4. Save RunLog as JSON               │
│  5. Release per-schedule lock         │
└──────────────────┬───────────────────┘
                   │
                   v
┌──────────────────────────────────────┐
│  Batch update last_run timestamps     │
│  Release global lock                  │
│  Return CheckResult                   │
└──────────────────────────────────────┘
```

---

## schedule run

Run a schedule immediately regardless of whether it's overdue.

```
dobbe schedule run <name>
```

### Arguments

| Argument | Type | Description |
|---|---|---|
| `name` | `str` | Name of the schedule to run |

---

## schedule logs

View recent run logs for schedules.

```
dobbe schedule logs [name] [--limit N]
```

### Arguments

| Argument | Type | Default | Description |
|---|---|---|---|
| `name` | `str` | - | Schedule name (omit for all schedules) |

### Options

| Option | Type | Default | Description |
|---|---|---|---|
| `--limit` / `-n` | `int` | `10` | Number of recent logs to show |

---

## schedule install

Install automatic schedule checking via shell hooks or OS login triggers.

```
dobbe schedule install [--trigger <type>] [--shell <shell>] [--uninstall]
```

### Options

| Option | Type | Default | Description |
|---|---|---|---|
| `--trigger` | `str` | `shell` | Trigger type: `shell` or `login` |
| `--shell` | `str` | auto-detect | Force shell type: `bash`, `zsh`, `fish` |
| `--uninstall` | `bool` | `False` | Remove the installed hook |

### Shell Hooks

When `--trigger shell`, dobbe appends a hook to your shell profile that runs `dobbe schedule check --quiet &` in the background when you open a new terminal:

| Shell | Profile File | Hook |
|---|---|---|
| zsh | `~/.zshrc` | `dobbe schedule check --quiet &` |
| bash | `~/.bashrc` | `dobbe schedule check --quiet &` |
| fish | `~/.config/fish/config.fish` | `dobbe schedule check --quiet &` |

### Login Hooks

When `--trigger login`, dobbe installs an OS-native service:

| OS | Mechanism | Interval |
|---|---|---|
| macOS | launchd plist in `~/Library/LaunchAgents/` | Every hour + on load |
| Linux | systemd user service + timer in `~/.config/systemd/user/` | Every hour, persistent |
| Windows | Scheduled task via `schtasks` | On logon |

---

## Scheduling Internals

### Persistence

Schedules are stored in `~/.dobbe/schedules.toml` with ISO datetime timestamps and interval enum values.

### Overdue Detection

A schedule is overdue when:

```
now - last_run > interval_delta + grace_period (5 minutes)
```

If `last_run` is `None` (never run), the schedule is immediately overdue. Binary detection ensures at most one catch-up run per schedule per check.

### Locking

Directory-based locking with PID tracking:

- Lock path: `~/.dobbe/locks/{name}.lock/`
- PID file written inside lock directory
- Stale detection: lock is stale if age > 2 hours OR the PID is no longer alive
- Stale locks are automatically broken

### Log Rotation

Run logs are stored as JSON files in `~/.dobbe/logs/schedules/{name}/`:

- Filename format: `{timestamp}.json`
- Maximum 50 logs per schedule (oldest pruned automatically)
- Each log records: status, exit code, duration, summary, error, command, args

---

## Examples

### Add a daily vulnerability scan

```bash
dobbe schedule add daily-scan \
  --command "vuln scan" \
  --args "--org nareshnavinash --notify slack --channel #security" \
  --every daily
```

### Install shell hook for automatic checking

```bash
dobbe schedule install --trigger shell
```

### View recent logs for a schedule

```bash
dobbe schedule logs daily-scan --limit 20
```

### Dry run to see what would execute

```bash
dobbe schedule check --dry-run
```

### Remove a schedule

```bash
dobbe schedule remove daily-scan --force
```

## See Also

- [Configuration reference](../reference/configuration.md) - schedule-related file locations
- [Getting started](../getting-started.md) - scheduling setup walkthrough
