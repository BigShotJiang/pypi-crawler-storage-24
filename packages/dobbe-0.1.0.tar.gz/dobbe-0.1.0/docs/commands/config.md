# dobbe config

View and manage configuration.

## Synopsis

```
dobbe config <subcommand>
```

## Subcommands

### config show

Display the current configuration.

```
dobbe config show
```

No options. Shows:

- **Config file path** - location of `config.toml`
- **Organization** - default org from config
- **Default format** - output format (table/json/markdown)
- **Default severity** - severity filter
- **Slack channel** - notification channel
- **Local repos count** - number of configured repo paths
- **Local repo paths** - list of paths (if configured)

### config check

**Deprecated** - use `dobbe doctor` instead.

```
dobbe config check
```

This command now redirects to `dobbe doctor` and will be removed in a future release.

## See Also

- [Configuration reference](../reference/configuration.md) - full TOML config reference
- [doctor](doctor.md) - environment health checks
- [setup](setup.md) - interactive configuration wizard
