# dobbe review digest

Fetch open PRs, analyze with AI, and output a prioritized review digest.

## Synopsis

```
dobbe review digest [OPTIONS]
```

## Description

`review digest` runs a 5-phase async pipeline that discovers open pull requests, pre-fetches diffs, analyzes each PR with Claude AI for security, quality, and complexity issues, and outputs a prioritized digest sorted by risk level and age.

## Pipeline Flowchart

```
┌──────────────────────────────────────────┐
│   dobbe review digest --repo org/repo     │
└─────────────────────┬────────────────────┘
                      │
                      v
┌──────────────────────────────────────────┐
│  PHASE 1: FETCH PRs                       │
│  - Discover open PRs via Claude prompt    │
│  - Filter by --reviewer (default: @me)    │
│  - Parallel across repos (semaphore = 5)  │
│  Tools: [Bash, Read, Grep, Glob] + MCP    │
└─────────────────────┬────────────────────┘
                      │
                      v
┌──────────────────────────────────────────┐
│  PHASE 2: FILTER                          │
│  - Remove drafts                          │
│  - Skip PRs with --skip-label labels      │
│  - Skip PRs from --skip-author authors    │
└─────────────────────┬────────────────────┘
                      │
                      v
┌──────────────────────────────────────────┐
│  PHASE 3: PRE-FETCH DIFFS                 │
│  - Parallel diff fetching                 │
│  - Truncate at --max-diff-lines (2000)    │
│  - Feed diffs inline to analysis prompt   │
└─────────────────────┬────────────────────┘
                      │
                      v
┌──────────────────────────────────────────┐
│  PHASE 4: ANALYZE                         │
│  - Senior engineer code review per PR     │
│  - Categories: Security, Test coverage,   │
│    Breaking changes, Code quality,        │
│    Complexity                             │
│  - Assign risk level + concerns           │
│  - Estimate review time                   │
│  - Recommend: approve / request_changes   │
│    / needs_discussion                     │
└─────────────────────┬────────────────────┘
                      │
                      v
┌──────────────────────────────────────────┐
│  PHASE 5: PRIORITIZE                      │
│  - Sort by risk: critical > high >        │
│    medium > low                           │
│  - Within same risk: oldest first         │
│  - Flag stale PRs (> --stale-days)        │
└─────────────────────┬────────────────────┘
                      │
                      v
┌──────────────────────────────────────────┐
│  OUTPUT                                   │
│  --format table / json / markdown         │
│  --output file (optional)                 │
│  --notify slack (optional)                │
└──────────────────────────────────────────┘
```

## Options

| Option | Type | Default | Description |
|---|---|---|---|
| `--repo` / `-r` | `str` | - | Single repo to review (`org/repo`) |
| `--org` / `-o` | `str` | - | Review all repos in an organization |
| `--reviewer` | `str` | `@me` | GitHub username to filter by |
| `--stale-days` | `int` | `7` | Days before flagging PR as stale |
| `--format` / `-f` | `str` | `table` | Output format: `table`, `json`, `markdown` |
| `--verbose` / `-V` | `bool` | `False` | Show diff stats, recommendations, concerns |
| `--output` | `str` | - | Write output to file instead of stdout |
| `--notify` | `str` | - | Send digest to platform (`slack`) |
| `--channel` | `str` | - | Notification channel (e.g., `#pr-reviews`) |
| `--skip-label` | `str` | - | Skip PRs with these labels (comma-separated) |
| `--skip-author` | `str` | - | Skip PRs by these authors (comma-separated) |
| `--max-diff-lines` | `int` | `2000` | Max diff lines to include per PR |
| `--quiet` / `-q` | `bool` | `False` | Suppress progress output |

## Output Models

The digest produces these structured models:

### ReviewDigest

Top-level report with computed properties:

- `total_prs` - number of PRs analyzed
- `critical_count` - PRs with critical risk
- `stale_prs` - PRs older than `stale_days`
- `stats_by_risk` - breakdown by risk level

### PRReviewResult

Per-PR analysis result:

- `risk_level` - `critical`, `high`, `medium`, `low`
- `summary` - AI-generated review summary
- `concerns` - list of specific issues found
- `recommendations` - suggested actions
- `estimated_review_time` - human review time estimate
- `approval_recommendation` - `approve`, `request_changes`, or `needs_discussion`

### ReviewConcern

Individual issue found during review:

- `category` - `security`, `test_coverage`, `breaking_change`, `code_quality`, `complexity`
- `severity` - `critical`, `high`, `medium`, `low`
- `description` - what the issue is
- `file_path` - affected file
- `line_number` - specific line (if applicable)
- `suggestion` - how to fix it

## Examples

### Digest for a single repository

```bash
dobbe review digest --repo nareshnavinash/api
```

### Org-wide digest with Slack notification

```bash
dobbe review digest --org nareshnavinash --notify slack --channel "#pr-reviews"
```

### Verbose digest skipping bot PRs

```bash
dobbe review digest --repo nareshnavinash/api --verbose --skip-author "dependabot,renovate"
```

## See Also

- [review post](review-post.md) - analyze and post reviews to GitHub
- [Review pipeline architecture](../architecture/review-pipeline.md) - async pipeline deep dive
- [Configuration reference](../reference/configuration.md) - review-related config options
