# dobbe doctor

Check environment health and diagnose issues.

## Synopsis

```
dobbe doctor
```

No arguments or options. Runs all health checks automatically.

## Description

`dobbe doctor` runs 9 diagnostic checks to verify that your environment is properly configured. Each check shows a pass/fail status with actionable fix hints on failure.

## Health Checks

| # | Check | Pass Criteria | Fix Hint |
|---|---|---|---|
| 1 | Claude Code CLI | `claude` binary found on PATH | Install Claude Code CLI |
| 2 | Authentication | Test prompt succeeds within 30s | Run `claude auth` |
| 3 | Config file | `~/.dobbe/config.toml` exists | Run `dobbe setup` |
| 4 | Default org | `general.default_org` is set | Run `dobbe setup` or edit config |
| 5 | Watch repos | `repos.local_paths` has entries | Run `dobbe setup` or edit config |
| 6 | GitHub MCP | GitHub MCP server discovered | Configure GitHub MCP in Claude Code |
| 7 | Slack MCP | Slack MCP server discovered | Configure Slack MCP (optional) |
| 8 | gh CLI | `gh` binary found on PATH | Install gh CLI |
| 9 | Shell completions | Completions installed for current shell | Run shell completion install |

## Example Output

### All checks pass

```
dobbe doctor

  1. Claude Code CLI .............. OK
  2. Authentication ............... OK
  3. Config file .................. OK
  4. Default organization ......... OK (nareshnavinash)
  5. Watch repositories ........... OK (3 repos)
  6. GitHub MCP ................... OK
  7. Slack MCP .................... OK
  8. gh CLI ....................... OK
  9. Shell completions ............ OK

All checks passed!
```

### Partial failure

```
dobbe doctor

  1. Claude Code CLI .............. OK
  2. Authentication ............... OK
  3. Config file .................. OK
  4. Default organization ......... OK (nareshnavinash)
  5. Watch repositories ........... WARN - no repos configured
     Hint: Run `dobbe setup` or add paths to config
  6. GitHub MCP ................... FAIL - not found
     Hint: Configure GitHub MCP in ~/.claude/settings.json
  7. Slack MCP .................... WARN - not found (optional)
  8. gh CLI ....................... OK
  9. Shell completions ............ WARN - not installed

6 passed, 3 warnings/failures
```

## See Also

- [setup](setup.md) - run the setup wizard to fix issues
- [Configuration reference](../reference/configuration.md) - config file format
- [MCP integrations](../reference/mcp-integrations.md) - MCP setup instructions
