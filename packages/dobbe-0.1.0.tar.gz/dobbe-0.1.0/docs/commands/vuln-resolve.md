# dobbe vuln resolve

Scan, fix, and verify vulnerable dependencies with an agentic feedback loop.

## Synopsis

```
dobbe vuln resolve [OPTIONS]
```

## Description

`vuln resolve` is dobbe's flagship command. It orchestrates multiple AI agents in an iterative loop to:

1. Scan for Dependabot vulnerability alerts
2. Apply dependency upgrades (patch/minor bumps only)
3. Run tests and verify no breaking changes
4. Revert and retry with error feedback if tests fail
5. Generate an executive summary and create a PR

The pipeline runs up to `--max-iterations` fix-verify cycles before reporting results.

## Pipeline Flowchart

```
┌─────────────────────────────────────────────────┐
│           dobbe vuln resolve --repo org/repo     │
└──────────────────────┬──────────────────────────┘
                       │
                       v
┌─────────────────────────────────────────────────┐
│  1. DISCOVER                                     │
│  - Discover available MCP servers                │
│  - Resolve repo: configured paths -> common      │
│    directories -> clone to tempdir               │
└──────────────────────┬──────────────────────────┘
                       │
                       v
┌─────────────────────────────────────────────────┐
│  2. BRANCH SETUP                                 │
│  - Create feature branch from --base             │
│  - Default branch name: dobbe/vuln-fix-YYYYMMDD  │
└──────────────────────┬──────────────────────────┘
                       │
                       v
┌─────────────────────────────────────────────────┐
│  3. SCAN AGENT                                   │
│  - Fetch Dependabot alerts via MCP or gh CLI     │
│  - Triage each alert: is code path affected?     │
│  - Group alerts by package                       │
│  - Build scan summary with risk levels           │
│  Tools: [Bash, Read, Grep, Glob] + MCP           │
└──────────────────────┬──────────────────────────┘
                       │
                 ┌─────┴──────┐
                 │  Dry run?  │
                 └─────┬──────┘
               yes |       | no
                   v       v
            ┌─────────┐  ┌────────────────────────┐
            │ Report  │  │  4. FIX AGENT           │<────────┐
            │ scan    │  │  - Read scan summary    │         │
            │ results │  │  - Apply PATCH/MINOR    │         │
            │ + exit  │  │    bumps only           │         │
            └─────────┘  │  - Update lockfiles     │         │
                         │  - Skip if no safe fix  │         │
                         │  Tools: [Bash, Read,    │         │
                         │   Grep, Glob, Edit,     │         │
                         │   Write] + MCP          │         │
                         └───────────┬─────────────┘         │
                                     │                       │
                                     v                       │
                         ┌───────────────────────┐           │
                         │  5. GIT COMMIT         │           │
                         │  - Stage all changes   │           │
                         │  - Commit with message │           │
                         └───────────┬────────────┘           │
                                     │                       │
                           ┌─────────┴──────────┐            │
                           │ Changes committed?  │            │
                           └─────────┬──────────┘            │
                         yes |             | no              │
                             v             v                 │
                  ┌────────────────┐  Mark converged,        │
                  │ --skip-verify? │  skip to report         │
                  └───────┬────────┘                         │
                yes |          | no                          │
                    v          v                             │
              Mark converged  ┌─────────────────────┐        │
              skip to report  │  6. VERIFY AGENT    │        │
                              │  - git diff review  │        │
                              │  - Check breaking   │        │
                              │    changes          │        │
                              │  - Run tests        │        │
                              │  - Verify lockfiles │        │
                              │  Tools: [Bash, Read,│        │
                              │   Grep, Glob]       │        │
                              └──────────┬──────────┘        │
                                         │                   │
                                   ┌─────┴─────┐            │
                                   │  Passed?  │            │
                                   └─────┬─────┘            │
                                 yes |       | no           │
                                     │       v              │
                                     │  ┌─────────────┐     │
                                     │  │ Iterations  │     │
                                     │  │ remaining?  │     │
                                     │  └──────┬──────┘     │
                                     │  yes |      | no    │
                                     │      v      │       │
                                     │  ┌────────┐ │       │
                                     │  │ REVERT │ │       │
                                     │  │ Reset  │ │       │
                                     │  │ branch │ │       │
                                     │  │ to base│ │       │
                                     │  │ Feed   │ │       │
                                     │  │ back   ├─┼───────┘
                                     │  │ errors │ │
                                     │  └────────┘ │
                                     │             │
                                     v             v
                         ┌─────────────────────────────┐
                         │  7. REPORT AGENT             │
                         │  - Summarize what was fixed  │
                         │  - What was skipped and why  │
                         │  - Verification results      │
                         │  - Risk assessment           │
                         │  - Next steps                │
                         │  Tools: [Read]               │
                         └──────────────┬───────────────┘
                                        │
                                        v
                         ┌─────────────────────────────┐
                         │  8. CREATE PR                │
                         │  - Push branch               │
                         │  - Create PR via gh CLI      │
                         │  - Include executive summary │
                         │  (skipped if --no-pr or      │
                         │   not converged)             │
                         └─────────────────────────────┘
```

## Options

| Option | Type | Default | Description |
|---|---|---|---|
| `--repo` / `-r` | `str` | - | Repository to fix (`org/repo`) |
| `--org` / `-o` | `str` | - | Resolve all repos in an organization |
| `--user` / `-u` | `str` | - | Resolve all repos for a GitHub user |
| `--severity` / `-s` | `str` | `critical,high` | Comma-separated severity filter |
| `--max-iterations` | `int` | `3` | Max fix-verify iterations (1-10) |
| `--base` | `str` | `main` | Base branch to branch from |
| `--branch` | `str` | auto | Branch name for fixes |
| `--create-pr` / `--no-pr` | `bool` | `True` | Create PR on convergence |
| `--dry-run` | `bool` | `False` | Scan only, no edits |
| `--skip-verify` | `bool` | `False` | Skip verification step |
| `--format` / `-f` | `str` | `table` | Output format: `table`, `json`, `markdown` |
| `--from-scan` | `str` | - | Path to scan JSON from `dobbe vuln scan --format json`. Use `'-'` for stdin. |

Exactly one of `--repo`, `--org`, or `--user` is required.

## Agent Tool Access

Each pipeline agent has scoped tool permissions:

| Agent | Tools | Why |
|---|---|---|
| **Scan** | `Bash`, `Read`, `Grep`, `Glob` + MCP | Read-only analysis of alerts and code |
| **Fix** | `Bash`, `Read`, `Grep`, `Glob`, `Edit`, `Write` + MCP | Needs to modify dependency files |
| **Verify** | `Bash`, `Read`, `Grep`, `Glob` | Read + run tests, no edits allowed |
| **Report** | `Read` | Read-only access to generate summary |

MCP tools (e.g., `mcp__github__*`) are added when available for the scan and fix agents.

## Pipeline Stages

### Stage 1: Discovery

Discovers available MCP servers from `~/.claude/settings.json` and resolves the repository location:

1. Check configured `local_paths` in `~/.dobbe/config.toml`
2. Scan common project directories (`~/projects`, `~/code`, `~/src`, etc.)
3. Fall back to shallow clone (`git clone --depth 1`) into a temp directory

### Stage 2: Branch Setup

Creates a feature branch from the base branch. Default branch name follows the pattern `dobbe/vuln-fix-YYYYMMDD`. Custom names can be set with `--branch`.

### Stage 3: Scan

The scan agent fetches Dependabot alerts and triages each one:

- Uses GitHub MCP if available, falls back to `gh` CLI
- Analyzes whether the vulnerable code path is actually used
- Assigns risk levels: `critical`, `high`, `medium`, `low`
- Groups related alerts by package for efficient fixing

### Stage 4: Fix

The fix agent reads the scan summary and applies upgrades:

- Only applies PATCH or MINOR version bumps
- Updates lockfiles after dependency changes
- Skips packages where no safe fix exists
- Does not modify application code

### Stage 5: Git Commit

Stages all changes and creates a commit. If no changes were made (e.g., all packages skipped), the pipeline marks convergence and moves to the report stage.

### Stage 6: Verify

The verify agent reviews the changes:

- Runs `git diff` against the base branch
- Checks for breaking changes (API removals, type changes)
- Runs the project's test suite
- Verifies lockfile consistency

If verification fails, the pipeline reverts the branch to the base, feeds the error details back to the fix agent, and starts the next iteration.

### Stage 7: Report

Generates a plain-text executive summary (under 500 words) covering:

- What was fixed and the versions changed
- What was skipped and why
- Verification results across iterations
- Risk assessment
- Recommended next steps

### Stage 8: Create PR

If the pipeline converged (tests pass) and `--create-pr` is enabled, pushes the branch and creates a PR via `gh pr create` with the executive summary as the body.

## Transcript Saving

Each pipeline run saves a full conversation log (all agent messages with timestamps) that can be reviewed for debugging or auditing. The conversation includes agent names, iteration numbers, and detailed summaries.

## Batch Mode

When using `--org` or `--user`, dobbe resolves all repositories for the owner and runs the pipeline sequentially for each repo. Results are aggregated into a `BatchResolveReport` with:

- Total repos processed
- Convergence count
- Total fixes applied
- All PR URLs created

Progress callbacks fire for each repo to keep you informed during long batch runs.

## Examples

### Fix a single repository

```bash
dobbe vuln resolve --repo nareshnavinash/api
```

### Fix all repos in an organization

```bash
dobbe vuln resolve --org nareshnavinash
```

### Dry run - scan and report without making changes

```bash
dobbe vuln resolve --repo nareshnavinash/api --dry-run
```

### Skip verification for fast iteration

```bash
dobbe vuln resolve --repo nareshnavinash/api --skip-verify --max-iterations 1
```

### Custom branch and base

```bash
dobbe vuln resolve --repo nareshnavinash/api --base develop --branch fix/security-march
```

### JSON output for CI integration

```bash
dobbe vuln resolve --repo nareshnavinash/api --format json
```

## Using Pre-computed Scan Results

When you run `dobbe vuln scan` followed by `dobbe vuln resolve` on the same repo, the scan agent runs twice - the same expensive Claude invocation analyzing the same alerts. The `--from-scan` option lets you pass pre-computed scan results to `resolve`, skipping the redundant scan agent entirely.

### How it works

```
┌──────────────────────────────────┐
│  Load scan JSON (file or stdin)  │
└──────────────────┬───────────────┘
                   │
                   v
┌──────────────────────────────────┐
│  Match repo -> build summary     │
└──────────────────┬───────────────┘
                   │
                   v
┌──────────────────────────────────┐
│  FIX AGENT (skip scan agent)     │
│  ... rest of pipeline unchanged  │
└──────────────────────────────────┘
```

### From a saved file

```bash
dobbe vuln scan --repo nareshnavinash/api --format json --output scan.json
dobbe vuln resolve --repo nareshnavinash/api --from-scan scan.json
```

### Piping directly

```bash
dobbe vuln scan --repo nareshnavinash/api --format json | dobbe vuln resolve --repo nareshnavinash/api --from-scan -
```

### Batch mode with --org

```bash
dobbe vuln scan --org nareshnavinash --format json --output scan.json
dobbe vuln resolve --org nareshnavinash --from-scan scan.json
```

In batch mode, repos are taken directly from the scan report (skipping `list_org_repos` / `list_user_repos` discovery). Repos with scan errors are excluded automatically.

### Notes

- `--from-scan` and `--dry-run` are mutually exclusive. `--dry-run` means "scan only" which contradicts "skip scan".
- `--severity` is ignored when `--from-scan` is set - filtering already happened during the original scan.

## Convergence Logic

The pipeline converges (succeeds) when any of these conditions are met:

1. **Verify passes** - all tests pass and no breaking changes detected
2. **No changes committed** - all packages skipped (no safe fix available)
3. **Skip verify** - `--skip-verify` flag bypasses verification

If the pipeline exhausts all iterations without converging, the report agent still generates a summary explaining what failed and why. No PR is created in this case.

## See Also

- [vuln scan](vuln-scan.md) - scan without fixing
- [Resolve pipeline architecture](../architecture/resolve-pipeline.md) - deep dive into agent orchestration
- [Configuration reference](../reference/configuration.md) - pipeline-related config options
