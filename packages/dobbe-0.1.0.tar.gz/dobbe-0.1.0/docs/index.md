# dobbe Documentation

AI-powered vulnerability scanner and code review automation for GitHub repositories.

## Start Here

New to dobbe? Begin with the **[Getting Started](getting-started.md)** guide - it walks you through installation, setup, and your first scan.

## Navigation

### Commands

| Document | Command | Description |
|---|---|---|
| [vuln-scan](commands/vuln-scan.md) | `dobbe vuln scan` | Scan repos for vulnerabilities, triage with AI |
| [vuln-resolve](commands/vuln-resolve.md) | `dobbe vuln resolve` | Agentic fix loop: scan, upgrade, test, iterate |
| [review-digest](commands/review-digest.md) | `dobbe review digest` | AI-powered PR review digest |
| [review-post](commands/review-post.md) | `dobbe review post` | Post AI reviews to GitHub |
| [schedule](commands/schedule.md) | `dobbe schedule` | Manage recurring scheduled tasks |
| [setup](commands/setup.md) | `dobbe setup` | Interactive first-time configuration |
| [doctor](commands/doctor.md) | `dobbe doctor` | Environment health diagnostics |
| [config](commands/config.md) | `dobbe config` | View and manage configuration |

### Architecture

| Document | Description |
|---|---|
| [Overview](architecture/overview.md) | System architecture, layer diagram, Claude integration model |
| [Resolve Pipeline](architecture/resolve-pipeline.md) | Deep dive: agentic fix-verify loop |
| [Review Pipeline](architecture/review-pipeline.md) | Deep dive: 5-phase async review pipeline |

### Reference

| Document | Description |
|---|---|
| [Configuration](reference/configuration.md) | Full `config.toml` reference with all keys and defaults |
| [CLI Reference](reference/cli-reference.md) | Complete CLI option reference for every command |
| [MCP Integrations](reference/mcp-integrations.md) | MCP setup, tool prefixes, fallback behavior |

### Contributing

| Document | Description |
|---|---|
| [Contributing](contributing.md) | Dev setup, testing, PR guidelines |
