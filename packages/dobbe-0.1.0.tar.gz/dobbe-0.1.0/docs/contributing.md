# Contributing

Guidelines for contributing to dobbe.

## Dev Setup

```bash
# Clone the repository
git clone https://github.com/nareshnavinash/dobbe.git
cd dobbe

# Create a virtual environment
python -m venv .venv
source .venv/bin/activate

# Install in development mode with dev dependencies
pip install -e ".[dev]"
```

## Running Tests

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=dobbe --cov-report=term-missing

# Run a specific test file
pytest tests/test_pipeline.py

# Run tests matching a pattern
pytest -k "test_scan"
```

### Coverage Target

Maintain **98%+ code coverage** on all changes. New code must include tests. PRs that drop coverage below the threshold will be flagged.

### Test Guidelines

- Tests should be fast - mock external calls (Claude subprocess, gh CLI)
- Use fixtures for shared setup
- Test both success and error paths
- Test edge cases: empty inputs, missing config, network failures

## Code Structure

```
src/dobbe/
├── cli.py              # CLI entry point (Typer app)
├── commands/           # Command implementations
│   ├── vuln.py         # vuln scan, vuln resolve
│   ├── review.py       # review digest, review post
│   ├── schedule.py     # schedule add/list/remove/check/run/logs/install
│   ├── setup.py        # Setup wizard
│   ├── doctor.py       # Health checks
│   └── config.py       # Config show/check
├── core/               # Business logic
│   ├── claude.py       # Claude subprocess invocation
│   ├── pipeline.py     # Resolve pipeline
│   ├── review_pipeline.py  # Review pipeline
│   ├── prompts.py      # Prompt templates
│   ├── config_manager.py   # Config management
│   ├── scheduler.py    # Scheduling engine
│   ├── mcp_discovery.py    # MCP discovery
│   └── repo_resolver.py    # Repo resolution
├── models/             # Pydantic models
│   ├── alert.py        # Vulnerability models
│   ├── resolve.py      # Pipeline models
│   ├── review.py       # Review models
│   ├── schedule.py     # Schedule models
│   └── shared.py       # Shared enums
└── output/             # Output formatters
    ├── table.py        # Rich table output
    ├── json_out.py     # JSON output
    └── markdown.py     # Markdown output
```

## PR Guidelines

1. **Branch from main** - create a feature branch with a descriptive name
2. **Keep PRs focused** - one feature or fix per PR
3. **Write tests** - all new code needs test coverage
4. **Update docs** - if you change CLI options or behavior, update the relevant docs in `docs/`
5. **Run the full test suite** before submitting: `pytest`
6. **Keep commits clean** - meaningful commit messages that explain the "why"

## Dependencies

Core dependencies (from `pyproject.toml`):

- `typer[all]>=0.9.0` - CLI framework
- `rich>=13.0.0` - Terminal output formatting
- `pydantic>=2.0.0` - Data validation and models
- `tomli>=2.0.0` - TOML parsing (Python <3.12)
- `tomli-w>=1.0.0` - TOML writing

## See Also

- [Architecture overview](architecture/overview.md) - understand the codebase structure
- [CLI reference](reference/cli-reference.md) - all commands and options
