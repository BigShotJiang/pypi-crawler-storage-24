"""Tests for repo resolver."""

from pathlib import Path
from unittest.mock import patch

from dobbe.core.repo_resolver import resolve_repo, _extract_repo_name
from dobbe.models.alert import AccessMode


def test_extract_repo_name():
    assert _extract_repo_name("my-org/my-repo") == "my-repo"
    assert _extract_repo_name("my-repo") == "my-repo"


def test_resolve_repo_remote_fallback():
    """When no local clone exists, should return REMOTE."""
    config = {"repos": {"local_paths": []}}
    with patch("dobbe.core.repo_resolver._scan_common_directories", return_value=None):
        mode, path = resolve_repo("org/nonexistent-repo", config)
    assert mode == AccessMode.REMOTE
    assert path is None


def test_resolve_repo_from_config(tmp_path):
    """When a repo exists in configured local_paths, should return LOCAL."""
    repo_dir = tmp_path / "my-repo"
    repo_dir.mkdir()
    (repo_dir / ".git").mkdir()

    config = {"repos": {"local_paths": [str(tmp_path)]}}
    with patch("dobbe.core.repo_resolver._scan_common_directories", return_value=None):
        mode, path = resolve_repo("org/my-repo", config)
    assert mode == AccessMode.LOCAL
    assert path == repo_dir


def test_resolve_repo_from_config_direct_path(tmp_path):
    """When the configured path IS the repo."""
    repo_dir = tmp_path / "my-repo"
    repo_dir.mkdir()
    (repo_dir / ".git").mkdir()

    config = {"repos": {"local_paths": [str(repo_dir)]}}
    with patch("dobbe.core.repo_resolver._scan_common_directories", return_value=None):
        mode, path = resolve_repo("org/my-repo", config)
    assert mode == AccessMode.LOCAL
    assert path == repo_dir


def test_resolve_repo_scan_common_dirs(tmp_path):
    """When the repo is found by scanning common directories."""
    config = {"repos": {"local_paths": []}}
    repo_dir = tmp_path / "my-repo"
    repo_dir.mkdir()
    (repo_dir / ".git").mkdir()

    with patch(
        "dobbe.core.repo_resolver._scan_common_directories",
        return_value=repo_dir,
    ):
        mode, path = resolve_repo("org/my-repo", config)
    assert mode == AccessMode.LOCAL
    assert path == repo_dir


# --- Additional tests ---

from dobbe.core.repo_resolver import resolve_repos, _find_in_configured_paths, _scan_common_directories


def test_extract_deeply_nested_slug():
    assert _extract_repo_name("a/b/c/d") == "d"


def test_find_in_configured_paths_no_git_dir(tmp_path):
    """Dir exists but has no .git → returns None."""
    repo_dir = tmp_path / "my-repo"
    repo_dir.mkdir()
    config = {"repos": {"local_paths": [str(tmp_path)]}}
    result = _find_in_configured_paths("org/my-repo", config)
    assert result is None


def test_scan_common_dirs_cwd_match(tmp_path, monkeypatch):
    """Path.cwd() name matches repo → returns cwd."""
    repo_dir = tmp_path / "my-repo"
    repo_dir.mkdir()
    (repo_dir / ".git").mkdir()
    monkeypatch.chdir(repo_dir)
    with patch("dobbe.core.repo_resolver.COMMON_PROJECT_DIRS", []):
        result = _scan_common_directories("org/my-repo")
    assert result == repo_dir


def test_resolve_repos_batch(tmp_path, monkeypatch):
    config = {"repos": {"local_paths": []}}
    monkeypatch.chdir(tmp_path)
    with patch("dobbe.core.repo_resolver.COMMON_PROJECT_DIRS", []):
        results = resolve_repos(["org/a", "org/b", "org/c"], config)
    assert len(results) == 3
    for slug in ["org/a", "org/b", "org/c"]:
        assert slug in results
        assert results[slug] == (AccessMode.REMOTE, None)


def test_resolve_repos_empty_list():
    results = resolve_repos([], {})
    assert results == {}


# --- cwd child directory (lines 67-71) ---


def test_scan_common_dirs_cwd_child(tmp_path, monkeypatch):
    """cwd/repo_name exists with .git → found."""
    repo_dir = tmp_path / "my-repo"
    repo_dir.mkdir()
    (repo_dir / ".git").mkdir()
    monkeypatch.chdir(tmp_path)
    with patch("dobbe.core.repo_resolver.COMMON_PROJECT_DIRS", []):
        result = _scan_common_directories("org/my-repo")
    assert result == repo_dir


# --- None config triggers load_config ---


def test_find_in_configured_paths_none_config(tmp_path, monkeypatch):
    """config=None triggers load_config."""
    monkeypatch.setattr(
        "dobbe.core.repo_resolver.load_config",
        lambda: {"repos": {"local_paths": []}},
    )
    result = _find_in_configured_paths("org/whatever")
    assert result is None


def test_resolve_repos_none_config(tmp_path, monkeypatch):
    """config=None triggers load_config inside resolve_repos."""
    monkeypatch.setattr(
        "dobbe.core.repo_resolver.load_config",
        lambda: {"repos": {"local_paths": []}},
    )
    monkeypatch.chdir(tmp_path)
    with patch("dobbe.core.repo_resolver.COMMON_PROJECT_DIRS", []):
        results = resolve_repos(["org/a"], config=None)
    assert results["org/a"] == (AccessMode.REMOTE, None)


# --- Pre-scan optimization ---


def test_resolve_repos_prescan_finds_in_common_dirs(tmp_path, monkeypatch):
    """Pre-scan finds repos in COMMON_PROJECT_DIRS without per-repo scanning."""
    projects_dir = tmp_path / "projects"
    projects_dir.mkdir()
    repo_a = projects_dir / "repo-a"
    repo_a.mkdir()
    (repo_a / ".git").mkdir()
    repo_b = projects_dir / "repo-b"
    repo_b.mkdir()
    (repo_b / ".git").mkdir()

    monkeypatch.chdir(tmp_path)
    config = {"repos": {"local_paths": []}}

    with patch("dobbe.core.repo_resolver.COMMON_PROJECT_DIRS", [projects_dir]):
        results = resolve_repos(["org/repo-a", "org/repo-b", "org/repo-c"], config)

    assert results["org/repo-a"] == (AccessMode.LOCAL, repo_a)
    assert results["org/repo-b"] == (AccessMode.LOCAL, repo_b)
    assert results["org/repo-c"] == (AccessMode.REMOTE, None)


def test_resolve_repos_prescan_cwd_child(tmp_path, monkeypatch):
    """Pre-scan finds repos that are children of cwd."""
    repo = tmp_path / "my-repo"
    repo.mkdir()
    (repo / ".git").mkdir()

    monkeypatch.chdir(tmp_path)
    config = {"repos": {"local_paths": []}}

    with patch("dobbe.core.repo_resolver.COMMON_PROJECT_DIRS", []):
        results = resolve_repos(["org/my-repo"], config)

    assert results["org/my-repo"] == (AccessMode.LOCAL, repo)


def test_resolve_repos_prescan_cwd_is_repo(tmp_path, monkeypatch):
    """Pre-scan finds cwd itself when it is a git repo."""
    (tmp_path / ".git").mkdir()
    monkeypatch.chdir(tmp_path)
    config = {"repos": {"local_paths": []}}

    with patch("dobbe.core.repo_resolver.COMMON_PROJECT_DIRS", []):
        results = resolve_repos([f"org/{tmp_path.name}"], config)

    assert results[f"org/{tmp_path.name}"] == (AccessMode.LOCAL, tmp_path)


def test_resolve_repos_configured_paths_take_precedence(tmp_path, monkeypatch):
    """Configured local_paths are checked before pre-scanned directories."""
    repo = tmp_path / "my-repo"
    repo.mkdir()
    (repo / ".git").mkdir()

    monkeypatch.chdir(tmp_path)
    config = {"repos": {"local_paths": [str(tmp_path)]}}

    with patch("dobbe.core.repo_resolver.COMMON_PROJECT_DIRS", []):
        results = resolve_repos(["org/my-repo"], config)

    assert results["org/my-repo"] == (AccessMode.LOCAL, repo)


def test_resolve_repos_prescan_skips_nonexistent_dirs(tmp_path, monkeypatch):
    """Pre-scan skips non-existent directories in COMMON_PROJECT_DIRS."""
    nonexistent = tmp_path / "does-not-exist"
    monkeypatch.chdir(tmp_path)
    config = {"repos": {"local_paths": []}}

    with patch("dobbe.core.repo_resolver.COMMON_PROJECT_DIRS", [nonexistent]):
        results = resolve_repos(["org/some-repo"], config)

    assert results["org/some-repo"] == (AccessMode.REMOTE, None)
