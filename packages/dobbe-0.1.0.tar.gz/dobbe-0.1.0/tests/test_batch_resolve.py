"""Tests for batch resolve orchestrator and BatchResolveReport model."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from dobbe.core.batch_resolve import BatchResolveConfig, run_batch_resolve
from dobbe.models.resolve import (
    BatchResolveReport,
    FixAction,
    FixResult,
    PipelineIteration,
    ResolveReport,
    VerifyResult,
)


# --- BatchResolveReport model ---


def test_batch_report_empty():
    br = BatchResolveReport()
    assert br.total_repos == 0
    assert br.converged_count == 0
    assert br.total_fixes == 0
    assert br.total_prs == 0
    assert br.pr_urls == []


def test_batch_report_properties():
    fix = FixAction(package_name="django", file_modified="req.txt", old_version="4.2.5", new_version="4.2.11")
    fr = FixResult(repo="org/repo1", branch="b", base_branch="main", fixes=[fix])
    pi = PipelineIteration(iteration=1, fix_result=fr, verify_result=VerifyResult(passed=True))

    report1 = ResolveReport(
        repo="org/repo1",
        iterations=[pi],
        converged=True,
        pr_url="https://github.com/org/repo1/pull/1",
    )
    report2 = ResolveReport(
        repo="org/repo2",
        iterations=[pi],
        converged=False,
    )

    br = BatchResolveReport.from_reports([report1, report2], owner="org")
    assert br.owner == "org"
    assert br.total_repos == 2
    assert br.converged_count == 1
    assert br.total_fixes == 2  # 1 fix per report, counted from last iteration
    assert br.total_prs == 1
    assert br.pr_urls == ["https://github.com/org/repo1/pull/1"]


def test_batch_report_from_reports_empty():
    br = BatchResolveReport.from_reports([], owner="nobody")
    assert br.total_repos == 0
    assert br.owner == "nobody"


def test_batch_report_serialization():
    report = ResolveReport(repo="org/repo1", converged=True, pr_url="https://example.com/pr/1")
    br = BatchResolveReport.from_reports([report], owner="org")
    json_str = br.model_dump_json()
    reconstructed = BatchResolveReport.model_validate_json(json_str)
    assert reconstructed.owner == "org"
    assert reconstructed.total_repos == 1


# --- run_batch_resolve ---


def _make_report(repo: str, converged: bool = True, pr_url: str = "") -> ResolveReport:
    return ResolveReport(repo=repo, converged=converged, pr_url=pr_url)


@patch("dobbe.core.batch_resolve.run_pipeline")
def test_batch_resolve_single_repo(mock_pipeline):
    mock_pipeline.return_value = _make_report("org/repo1")
    cfg = BatchResolveConfig(repos=["org/repo1"])
    reports = run_batch_resolve(cfg)
    assert len(reports) == 1
    mock_pipeline.assert_called_once()


@patch("dobbe.core.batch_resolve.run_pipeline")
def test_batch_resolve_multiple_repos(mock_pipeline):
    mock_pipeline.side_effect = [
        _make_report("org/r1"),
        _make_report("org/r2"),
        _make_report("org/r3"),
    ]
    cfg = BatchResolveConfig(repos=["org/r1", "org/r2", "org/r3"])
    reports = run_batch_resolve(cfg)
    assert len(reports) == 3
    assert mock_pipeline.call_count == 3


@patch("dobbe.core.batch_resolve.run_pipeline")
def test_batch_resolve_callbacks(mock_pipeline):
    mock_pipeline.return_value = _make_report("org/r1")
    on_start = MagicMock()
    on_done = MagicMock()
    cfg = BatchResolveConfig(repos=["org/r1"])
    run_batch_resolve(cfg, on_repo_start=on_start, on_repo_done=on_done)
    on_start.assert_called_once_with("org/r1", 1, 1)
    on_done.assert_called_once_with("org/r1", mock_pipeline.return_value)


@patch("dobbe.core.batch_resolve.run_pipeline")
def test_batch_resolve_partial_failure(mock_pipeline):
    mock_pipeline.side_effect = [
        _make_report("org/r1"),
        RuntimeError("clone failed"),
        _make_report("org/r3"),
    ]
    cfg = BatchResolveConfig(repos=["org/r1", "org/r2", "org/r3"])
    reports = run_batch_resolve(cfg)
    assert len(reports) == 3
    assert reports[0].converged is True
    assert reports[1].converged is False
    assert "Pipeline error" in reports[1].scan_summary
    assert reports[2].converged is True


@patch("dobbe.core.batch_resolve.run_pipeline")
def test_batch_resolve_dry_run(mock_pipeline):
    mock_pipeline.return_value = _make_report("org/r1", converged=False)
    cfg = BatchResolveConfig(repos=["org/r1"], dry_run=True)
    run_batch_resolve(cfg)
    pipeline_cfg = mock_pipeline.call_args[0][0]
    assert pipeline_cfg.dry_run is True


@patch("dobbe.core.batch_resolve.run_pipeline")
def test_batch_resolve_passes_config(mock_pipeline):
    mock_pipeline.return_value = _make_report("org/r1")
    cfg = BatchResolveConfig(
        repos=["org/r1"],
        severity_filter=["critical"],
        max_iterations=5,
        base_branch="develop",
        skip_verify=True,
        no_pr=True,
        timeout_per_step=300,
    )
    run_batch_resolve(cfg)
    pipeline_cfg = mock_pipeline.call_args[0][0]
    assert pipeline_cfg.severity_filter == ["critical"]
    assert pipeline_cfg.max_iterations == 5
    assert pipeline_cfg.base_branch == "develop"
    assert pipeline_cfg.skip_verify is True
    assert pipeline_cfg.no_pr is True
    assert pipeline_cfg.timeout_per_step == 300


@patch("dobbe.core.batch_resolve.run_pipeline")
def test_batch_resolve_forwards_callbacks(mock_pipeline):
    mock_pipeline.return_value = _make_report("org/r1")
    msg_callback = MagicMock()
    cfg = BatchResolveConfig(repos=["org/r1"])
    run_batch_resolve(cfg, callbacks=msg_callback)
    assert mock_pipeline.call_args[1]["callbacks"] is msg_callback


# --- scan_overrides ---


@patch("dobbe.core.batch_resolve.run_pipeline")
def test_batch_resolve_with_scan_overrides(mock_pipeline):
    mock_pipeline.side_effect = [_make_report("org/r1"), _make_report("org/r2")]
    cfg = BatchResolveConfig(
        repos=["org/r1", "org/r2"],
        scan_overrides={"org/r1": "summary1", "org/r2": "summary2"},
    )
    run_batch_resolve(cfg)
    assert mock_pipeline.call_count == 2
    cfg1 = mock_pipeline.call_args_list[0][0][0]
    cfg2 = mock_pipeline.call_args_list[1][0][0]
    assert cfg1.scan_summary_override == "summary1"
    assert cfg2.scan_summary_override == "summary2"


@patch("dobbe.core.batch_resolve.run_pipeline")
def test_batch_resolve_scan_overrides_partial(mock_pipeline):
    mock_pipeline.side_effect = [_make_report("org/r1"), _make_report("org/r2")]
    cfg = BatchResolveConfig(
        repos=["org/r1", "org/r2"],
        scan_overrides={"org/r1": "summary1"},  # r2 not in overrides
    )
    run_batch_resolve(cfg)
    cfg1 = mock_pipeline.call_args_list[0][0][0]
    cfg2 = mock_pipeline.call_args_list[1][0][0]
    assert cfg1.scan_summary_override == "summary1"
    assert cfg2.scan_summary_override is None


@patch("dobbe.core.batch_resolve.run_pipeline")
def test_batch_resolve_scan_overrides_empty(mock_pipeline):
    mock_pipeline.return_value = _make_report("org/r1")
    cfg = BatchResolveConfig(repos=["org/r1"], scan_overrides={})
    run_batch_resolve(cfg)
    pipeline_cfg = mock_pipeline.call_args[0][0]
    assert pipeline_cfg.scan_summary_override is None
