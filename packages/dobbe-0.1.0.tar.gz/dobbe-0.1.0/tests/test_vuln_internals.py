"""Tests for vuln.py internal functions - _parse_triage_response, _scan_repo_sync, _handle_notification, _load_scan_report."""

from __future__ import annotations

import asyncio
import json
from unittest.mock import patch, MagicMock, AsyncMock

import pytest
import typer

from dobbe.commands.vuln import (
    _load_scan_report,
    _scan_repo_sync,
    _scan_repo_async,
    _scan_repos_parallel,
    _handle_notification,
)
from dobbe.core.response_parser import parse_triage_response as _parse_triage_response
from dobbe.core.claude import ClaudeResult
from dobbe.models.alert import AccessMode, ScanReport


# --- _parse_triage_response ---


def test_parse_valid_json(valid_triage_json):
    result = _parse_triage_response(valid_triage_json, "org/repo")
    assert result.error is None
    assert len(result.groups) == 1
    assert result.groups[0].package_name == "django"
    assert result.groups[0].alerts[0].cve_id == "CVE-2024-0001"


def test_parse_json_in_markdown_fence(valid_triage_json_fenced):
    result = _parse_triage_response(valid_triage_json_fenced, "org/repo")
    assert result.error is None
    assert len(result.groups) == 1


def test_parse_json_in_plain_fence(valid_triage_json):
    text = f"```\n{valid_triage_json}\n```"
    result = _parse_triage_response(text, "org/repo")
    assert result.error is None
    assert len(result.groups) == 1


def test_parse_json_with_preamble_text(valid_triage_json):
    text = f"Here is the result: {valid_triage_json}"
    result = _parse_triage_response(text, "org/repo")
    assert result.error is None
    assert len(result.groups) == 1


def test_parse_no_json_at_all():
    result = _parse_triage_response("I couldn't find any alerts", "org/repo")
    assert result.error is not None
    assert "No JSON found" in result.error


def test_parse_malformed_json():
    result = _parse_triage_response('{"groups": [', "org/repo")
    assert result.error is not None
    assert "JSON" in result.error


def test_parse_empty_groups():
    text = json.dumps({"groups": []})
    result = _parse_triage_response(text, "org/repo")
    assert result.error is None
    assert result.groups == []


def test_parse_malformed_alert_skipped():
    """One valid alert + one missing required fields → only valid kept."""
    text = json.dumps({
        "groups": [
            {
                "package_name": "django",
                "alerts": [
                    {
                        "alert_number": 1,
                        "package_name": "django",
                        "severity": "critical",
                        "summary": "SQL injection",
                        "affected": True,
                        "risk_level": "critical",
                        "recommended_action": "Upgrade",
                    },
                    {
                        "alert_number": 2,
                        # missing package_name, severity, etc.
                    },
                ],
            }
        ]
    })
    result = _parse_triage_response(text, "org/repo")
    assert result.error is None
    assert len(result.groups) == 1
    assert len(result.groups[0].alerts) == 1
    assert result.groups[0].alerts[0].alert_number == 1


def test_parse_empty_string():
    result = _parse_triage_response("", "org/repo")
    assert result.error is not None


def test_parse_nested_braces_in_values():
    text = json.dumps({
        "groups": [
            {
                "package_name": "pkg",
                "alerts": [
                    {
                        "alert_number": 1,
                        "package_name": "pkg",
                        "severity": "low",
                        "summary": "Uses pattern {foo} internally",
                        "affected": False,
                        "risk_level": "low",
                        "recommended_action": "No action needed",
                    }
                ],
            }
        ]
    })
    result = _parse_triage_response(text, "org/repo")
    assert result.error is None
    assert result.groups[0].alerts[0].summary == "Uses pattern {foo} internally"


# --- _scan_repo_sync ---


@patch("dobbe.commands.vuln.ask_claude")
@patch("dobbe.commands.vuln.resolve_repo")
def test_scan_repo_sync_claude_failure(mock_resolve, mock_claude):
    mock_resolve.return_value = (AccessMode.REMOTE, None)
    mock_claude.return_value = ClaudeResult(success=False, error="Claude timed out")
    result = _scan_repo_sync("org/repo", ["critical"], {}, {})
    assert result.error == "Claude timed out"
    assert result.repo == "org/repo"


@patch("dobbe.commands.vuln.ask_claude")
@patch("dobbe.commands.vuln.resolve_repo")
def test_scan_repo_sync_success(mock_resolve, mock_claude, valid_triage_json):
    mock_resolve.return_value = (AccessMode.LOCAL, "/tmp/repo")
    mock_claude.return_value = ClaudeResult(success=True, text=valid_triage_json)
    result = _scan_repo_sync("org/repo", ["critical"], {}, {})
    assert result.error is None
    assert len(result.groups) == 1
    assert result.access_mode == AccessMode.LOCAL


# --- _handle_notification ---


@patch("dobbe.core.notifier.ask_claude")
def test_handle_notification_slack_no_mcp(mock_claude, sample_scan_report, capsys):
    _handle_notification(
        sample_scan_report, "slack", "#test", {"slack": False}, {}
    )
    mock_claude.assert_not_called()


# --- _parse_triage_response edge cases ---


def test_parse_braces_but_invalid_inner_json():
    """Text has { and } but inner substring is not valid JSON."""
    text = "result: {not valid json} end"
    result = _parse_triage_response(text, "org/repo")
    assert result.error is not None
    assert "Failed to parse" in result.error


# --- _scan_repo_async ---


@patch("dobbe.commands.vuln.ask_claude_async")
@patch("dobbe.commands.vuln.resolve_repo")
def test_scan_repo_async_success(mock_resolve, mock_claude_async, valid_triage_json):
    mock_resolve.return_value = (AccessMode.LOCAL, "/tmp/repo")
    mock_claude_async.return_value = ClaudeResult(success=True, text=valid_triage_json)
    result = asyncio.run(_scan_repo_async("org/repo", ["critical"], {}, {}))
    assert result.error is None
    assert len(result.groups) == 1
    assert result.access_mode == AccessMode.LOCAL


@patch("dobbe.commands.vuln.ask_claude_async")
@patch("dobbe.commands.vuln.resolve_repo")
def test_scan_repo_async_failure(mock_resolve, mock_claude_async):
    mock_resolve.return_value = (AccessMode.REMOTE, None)
    mock_claude_async.return_value = ClaudeResult(success=False, error="Timeout")
    result = asyncio.run(_scan_repo_async("org/repo", ["critical"], {}, {}))
    assert result.error == "Timeout"
    assert result.repo == "org/repo"


# --- _scan_repos_parallel ---


@patch("dobbe.commands.vuln._scan_repo_async")
def test_scan_repos_parallel(mock_scan_async):
    from dobbe.models.alert import RepoResult

    r1 = RepoResult(repo="org/r1", access_mode=AccessMode.REMOTE, groups=[])
    r2 = RepoResult(repo="org/r2", access_mode=AccessMode.REMOTE, groups=[])

    async def side_effect(repo, sev, mcps, cfg):
        return r1 if repo == "org/r1" else r2

    mock_scan_async.side_effect = side_effect
    results = asyncio.run(_scan_repos_parallel(["org/r1", "org/r2"], ["critical"], {}, {}))
    assert len(results) == 2
    assert results[0].repo == "org/r1"
    assert results[1].repo == "org/r2"


# --- _handle_notification full coverage ---


@patch("dobbe.core.notifier.ask_claude")
def test_handle_notification_slack_success(mock_claude, sample_scan_report, capsys):
    mock_claude.return_value = ClaudeResult(success=True, text="Posted")
    _handle_notification(
        sample_scan_report, "slack", "#alerts", {"slack": True}, {}
    )
    mock_claude.assert_called_once()
    captured = capsys.readouterr()
    assert "posted" in captured.out.lower() or "✓" in captured.out


@patch("dobbe.core.notifier.ask_claude")
def test_handle_notification_slack_no_channel(mock_claude, sample_scan_report, capsys):
    _handle_notification(
        sample_scan_report, "slack", None, {"slack": True}, {}
    )
    mock_claude.assert_not_called()
    captured = capsys.readouterr()
    assert "No Slack channel" in captured.out


@patch("dobbe.core.notifier.ask_claude")
def test_handle_notification_slack_failure(mock_claude, sample_scan_report, capsys):
    mock_claude.return_value = ClaudeResult(success=False, error="API error")
    _handle_notification(
        sample_scan_report, "slack", "#alerts", {"slack": True}, {}
    )
    captured = capsys.readouterr()
    assert "Failed" in captured.out or "✗" in captured.out


@patch("dobbe.core.notifier.ask_claude")
def test_handle_notification_jira_success(mock_claude, sample_scan_report, capsys):
    mock_claude.return_value = ClaudeResult(success=True, text="Created")
    _handle_notification(
        sample_scan_report, "jira", None, {"atlassian": True}, {}
    )
    mock_claude.assert_called_once()
    captured = capsys.readouterr()
    assert "Jira" in captured.out


@patch("dobbe.core.notifier.ask_claude")
def test_handle_notification_jira_no_mcp(mock_claude, sample_scan_report, capsys):
    _handle_notification(
        sample_scan_report, "jira", None, {"atlassian": False}, {}
    )
    mock_claude.assert_not_called()
    captured = capsys.readouterr()
    assert "Atlassian MCP not available" in captured.out


@patch("dobbe.core.notifier.ask_claude")
def test_handle_notification_jira_failure(mock_claude, sample_scan_report, capsys):
    mock_claude.return_value = ClaudeResult(success=False, error="Jira down")
    _handle_notification(
        sample_scan_report, "jira", None, {"atlassian": True}, {}
    )
    captured = capsys.readouterr()
    assert "Failed" in captured.out or "✗" in captured.out


def test_handle_notification_unknown_platform(sample_scan_report, capsys):
    _handle_notification(
        sample_scan_report, "teams", None, {}, {}
    )
    captured = capsys.readouterr()
    assert "Unknown" in captured.out


# --- _load_scan_report ---


def _make_scan_report_json(repos=None):
    """Build a minimal valid ScanReport JSON string."""
    report = ScanReport(repos=repos or [])
    return report.model_dump_json()


def test_load_scan_report_valid_file(tmp_path):
    path = tmp_path / "scan.json"
    path.write_text(_make_scan_report_json())
    result = _load_scan_report(str(path))
    assert isinstance(result, ScanReport)


def test_load_scan_report_stdin():
    json_str = _make_scan_report_json()
    with patch("dobbe.commands.vuln.sys") as mock_sys:
        mock_sys.stdin.read.return_value = json_str
        result = _load_scan_report("-")
    assert isinstance(result, ScanReport)


def test_load_scan_report_invalid_json(tmp_path):
    path = tmp_path / "bad.json"
    path.write_text("{bad json")
    with pytest.raises(typer.Exit):
        _load_scan_report(str(path))


def test_load_scan_report_empty_file(tmp_path):
    path = tmp_path / "empty.json"
    path.write_text("")
    with pytest.raises(typer.Exit):
        _load_scan_report(str(path))


def test_load_scan_report_missing_file():
    with pytest.raises(typer.Exit):
        _load_scan_report("/nonexistent/scan.json")


def test_load_scan_report_valid_but_wrong_schema(tmp_path):
    path = tmp_path / "wrong.json"
    path.write_text('{"foo": 1}')
    # Pydantic may accept unknown fields gracefully; test the behavior
    # ScanReport has optional fields with defaults, so {"foo": 1} might parse
    # as an empty report. The key is it doesn't crash.
    result = _load_scan_report(str(path))
    assert isinstance(result, ScanReport)
    assert len(result.repos) == 0
