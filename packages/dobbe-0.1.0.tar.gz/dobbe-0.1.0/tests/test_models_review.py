"""Tests for PR review models and computed properties."""

from __future__ import annotations

from datetime import datetime, timedelta

import pytest
from pydantic import ValidationError

from dobbe.models.review import (
    PRInfo,
    PRReviewResult,
    PostResult,
    ReviewConcern,
    ReviewDigest,
    ReviewPostReport,
)
from dobbe.models.shared import ReviewCategory, Severity


# --- ReviewCategory enum ---


def test_review_category_values():
    assert ReviewCategory("security") == ReviewCategory.SECURITY
    assert ReviewCategory("test_coverage") == ReviewCategory.TEST_COVERAGE
    assert ReviewCategory("breaking_change") == ReviewCategory.BREAKING_CHANGE
    assert ReviewCategory("code_quality") == ReviewCategory.CODE_QUALITY
    assert ReviewCategory("complexity") == ReviewCategory.COMPLEXITY


def test_review_category_invalid_raises():
    with pytest.raises(ValueError):
        ReviewCategory("bogus")


# --- PRInfo ---


def test_pr_info_minimal():
    pr = PRInfo(
        repo="org/repo",
        pr_number=42,
        title="Fix bug",
        author="alice",
        url="https://github.com/org/repo/pull/42",
        created_at=datetime.now(),
        updated_at=datetime.now(),
    )
    assert pr.pr_number == 42
    assert pr.additions == 0
    assert pr.deletions == 0
    assert pr.changed_files == 0
    assert pr.draft is False
    assert pr.description == ""


def test_pr_info_full():
    pr = PRInfo(
        repo="org/repo",
        pr_number=99,
        title="Add feature",
        author="bob",
        url="https://github.com/org/repo/pull/99",
        created_at=datetime(2024, 1, 1),
        updated_at=datetime(2024, 1, 10),
        additions=100,
        deletions=20,
        changed_files=5,
        draft=True,
        description="This is a feature PR",
    )
    assert pr.draft is True
    assert pr.additions == 100
    assert pr.description == "This is a feature PR"


def test_pr_info_age_days():
    created = datetime.now() - timedelta(days=10)
    pr = PRInfo(
        repo="org/repo",
        pr_number=1,
        title="Old PR",
        author="alice",
        url="https://github.com/org/repo/pull/1",
        created_at=created,
        updated_at=created,
    )
    assert pr.age_days == 10


def test_pr_info_age_days_fresh():
    pr = PRInfo(
        repo="org/repo",
        pr_number=1,
        title="Fresh PR",
        author="alice",
        url="https://github.com/org/repo/pull/1",
        created_at=datetime.now(),
        updated_at=datetime.now(),
    )
    assert pr.age_days == 0


def test_pr_info_missing_required_raises():
    with pytest.raises(ValidationError):
        PRInfo(
            repo="org/repo",
            pr_number=1,
            # missing title, author, url, created_at, updated_at
        )


def test_pr_info_labels_default():
    pr = _make_pr()
    assert pr.labels == []


def test_pr_info_labels_with_values():
    pr = PRInfo(
        repo="org/repo",
        pr_number=42,
        title="Fix bug",
        author="alice",
        url="https://github.com/org/repo/pull/42",
        created_at=datetime.now(),
        updated_at=datetime.now(),
        labels=["bug", "urgent"],
    )
    assert pr.labels == ["bug", "urgent"]


def test_pr_info_labels_empty_list():
    pr = PRInfo(
        repo="org/repo",
        pr_number=42,
        title="Fix bug",
        author="alice",
        url="https://github.com/org/repo/pull/42",
        created_at=datetime.now(),
        updated_at=datetime.now(),
        labels=[],
    )
    assert pr.labels == []


# --- ReviewConcern ---


def test_review_concern_construction():
    concern = ReviewConcern(
        category=ReviewCategory.SECURITY,
        severity=Severity.CRITICAL,
        description="SQL injection risk",
        file_path="src/db.py",
        suggestion="Use parameterized queries",
    )
    assert concern.category == ReviewCategory.SECURITY
    assert concern.severity == Severity.CRITICAL
    assert concern.file_path == "src/db.py"


def test_review_concern_defaults():
    concern = ReviewConcern(
        category=ReviewCategory.CODE_QUALITY,
        severity=Severity.LOW,
        description="Minor naming issue",
    )
    assert concern.file_path == ""
    assert concern.suggestion == ""


# --- PRReviewResult ---


def _make_pr() -> PRInfo:
    return PRInfo(
        repo="org/repo",
        pr_number=42,
        title="Fix bug",
        author="alice",
        url="https://github.com/org/repo/pull/42",
        created_at=datetime.now() - timedelta(days=3),
        updated_at=datetime.now(),
    )


def test_pr_review_result_basic():
    result = PRReviewResult(
        pr=_make_pr(),
        risk_level=Severity.HIGH,
        summary="This PR has security concerns",
    )
    assert result.risk_level == Severity.HIGH
    assert result.concerns == []
    assert result.recommendations == []
    assert result.analysis_error is None


def test_pr_review_result_with_concerns():
    concern = ReviewConcern(
        category=ReviewCategory.SECURITY,
        severity=Severity.HIGH,
        description="Unvalidated input",
    )
    result = PRReviewResult(
        pr=_make_pr(),
        risk_level=Severity.HIGH,
        summary="Security review needed",
        concerns=[concern],
        recommendations=["Add input validation"],
        estimated_review_time="30 min",
        approval_recommendation="request_changes",
    )
    assert len(result.concerns) == 1
    assert result.estimated_review_time == "30 min"
    assert result.approval_recommendation == "request_changes"


def test_pr_review_result_with_error():
    result = PRReviewResult(
        pr=_make_pr(),
        risk_level=Severity.MEDIUM,
        summary="",
        analysis_error="Claude timed out",
    )
    assert result.analysis_error == "Claude timed out"


# --- ReviewDigest ---


def _make_result(risk: Severity, age_days: int = 3) -> PRReviewResult:
    pr = PRInfo(
        repo="org/repo",
        pr_number=1,
        title="PR",
        author="alice",
        url="https://github.com/org/repo/pull/1",
        created_at=datetime.now() - timedelta(days=age_days),
        updated_at=datetime.now(),
    )
    return PRReviewResult(pr=pr, risk_level=risk, summary="Test")


def test_review_digest_total_prs():
    digest = ReviewDigest(
        results=[_make_result(Severity.HIGH), _make_result(Severity.LOW)],
    )
    assert digest.total_prs == 2


def test_review_digest_critical_count():
    digest = ReviewDigest(
        results=[
            _make_result(Severity.CRITICAL),
            _make_result(Severity.CRITICAL),
            _make_result(Severity.HIGH),
        ],
    )
    assert digest.critical_count == 2


def test_review_digest_stale_prs():
    digest = ReviewDigest(
        results=[
            _make_result(Severity.LOW, age_days=10),
            _make_result(Severity.LOW, age_days=3),
        ],
        stale_days=7,
    )
    assert len(digest.stale_prs) == 1
    assert digest.stale_prs[0].pr.age_days == 10


def test_review_digest_stale_prs_none():
    digest = ReviewDigest(
        results=[_make_result(Severity.LOW, age_days=3)],
        stale_days=7,
    )
    assert len(digest.stale_prs) == 0


def test_review_digest_stats_by_risk():
    digest = ReviewDigest(
        results=[
            _make_result(Severity.CRITICAL),
            _make_result(Severity.HIGH),
            _make_result(Severity.HIGH),
            _make_result(Severity.LOW),
        ],
    )
    stats = digest.stats_by_risk
    assert stats[Severity.CRITICAL] == 1
    assert stats[Severity.HIGH] == 2
    assert stats[Severity.LOW] == 1
    assert stats.get(Severity.MEDIUM) is None


def test_review_digest_empty():
    digest = ReviewDigest()
    assert digest.total_prs == 0
    assert digest.critical_count == 0
    assert digest.stale_prs == []
    assert digest.stats_by_risk == {}
    assert digest.reviewers == []
    assert digest.repos_scanned == []
    assert digest.errors == []


def test_review_digest_defaults():
    digest = ReviewDigest()
    assert digest.stale_days == 7
    assert isinstance(digest.timestamp, datetime)


# --- ReviewConcern line_number ---


def test_review_concern_with_line_number():
    concern = ReviewConcern(
        category=ReviewCategory.SECURITY,
        severity=Severity.HIGH,
        description="Issue",
        file_path="src/main.py",
        line_number=42,
    )
    assert concern.line_number == 42


def test_review_concern_line_number_default():
    concern = ReviewConcern(
        category=ReviewCategory.CODE_QUALITY,
        severity=Severity.LOW,
        description="Minor",
    )
    assert concern.line_number is None


# --- PostResult ---


def test_post_result_posted():
    pr = _make_pr()
    review = PRReviewResult(pr=pr, risk_level=Severity.HIGH, summary="Test")
    result = PostResult(
        pr=pr,
        review=review,
        posted=True,
        review_url="https://github.com/org/repo/pull/42#review",
    )
    assert result.posted is True
    assert result.skipped_reason == ""
    assert result.error == ""


def test_post_result_skipped():
    pr = _make_pr()
    review = PRReviewResult(pr=pr, risk_level=Severity.LOW, summary="Test")
    result = PostResult(
        pr=pr,
        review=review,
        skipped_reason="already reviewed at commit abc123",
    )
    assert result.posted is False
    assert "already reviewed" in result.skipped_reason


def test_post_result_error():
    pr = _make_pr()
    review = PRReviewResult(pr=pr, risk_level=Severity.MEDIUM, summary="Test")
    result = PostResult(
        pr=pr,
        review=review,
        error="403 Forbidden",
    )
    assert result.posted is False
    assert result.error == "403 Forbidden"


# --- ReviewPostReport ---


def test_post_report_empty():
    report = ReviewPostReport()
    assert report.total_posted == 0
    assert report.total_skipped == 0
    assert report.total_failed == 0
    assert report.dry_run is False
    assert isinstance(report.timestamp, datetime)


def test_post_report_counts():
    pr = _make_pr()
    review = PRReviewResult(pr=pr, risk_level=Severity.LOW, summary="Test")
    report = ReviewPostReport(
        results=[
            PostResult(pr=pr, review=review, posted=True),
            PostResult(pr=pr, review=review, skipped_reason="already reviewed"),
            PostResult(pr=pr, review=review, error="failed"),
        ],
    )
    assert report.total_posted == 1
    assert report.total_skipped == 1
    assert report.total_failed == 1


def test_post_report_dry_run():
    report = ReviewPostReport(dry_run=True)
    assert report.dry_run is True
