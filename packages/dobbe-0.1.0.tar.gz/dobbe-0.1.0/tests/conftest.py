"""Shared fixtures for dobbe test suite."""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

import pytest
import tomli_w


@pytest.fixture(autouse=True)
def _invalidate_caches(monkeypatch):
    """Clear config, MCP discovery, and first-run caches between tests.

    Also suppress first-run detection by default so CLI tests don't trigger
    the interactive setup prompt unexpectedly.
    """
    from unittest.mock import MagicMock
    from dobbe.core.config_manager import invalidate_config_cache
    from dobbe.core.mcp_discovery import invalidate_mcp_cache
    from dobbe.core.first_run import invalidate_first_run_flag
    invalidate_config_cache()
    invalidate_mcp_cache()
    invalidate_first_run_flag()
    # Suppress first-run prompt by pretending config exists
    mock_cf = MagicMock()
    mock_cf.exists.return_value = True
    monkeypatch.setattr("dobbe.core.first_run.CONFIG_FILE", mock_cf)
    # Suppress tips by default
    import os
    monkeypatch.setattr("dobbe.core.state_manager.STATE_FILE", Path(f"/tmp/dobbe-test-{os.getpid()}-state.toml"))
    yield
    invalidate_config_cache()
    invalidate_mcp_cache()
    invalidate_first_run_flag()


@pytest.fixture
def sched_dir(tmp_path, monkeypatch):
    """Patch all scheduler paths to use tmp_path."""
    schedules_file = tmp_path / "schedules.toml"
    logs_dir = tmp_path / "logs" / "schedules"
    locks_dir = tmp_path / "locks"
    monkeypatch.setattr("dobbe.core.scheduler.SCHEDULES_FILE", schedules_file)
    monkeypatch.setattr("dobbe.core.scheduler.LOGS_DIR", logs_dir)
    monkeypatch.setattr("dobbe.core.scheduler.LOCKS_DIR", locks_dir)
    return tmp_path

from dobbe.models.alert import (
    AccessMode,
    AlertGroup,
    RepoResult,
    ScanReport,
    Severity,
    TriageResult,
)


@pytest.fixture
def sample_triage_result():
    return TriageResult(
        alert_number=1,
        cve_id="CVE-2024-0001",
        package_name="django",
        severity=Severity.CRITICAL,
        summary="SQL injection in Django ORM",
        affected=True,
        evidence="Found usage in models.py:42",
        risk_level=Severity.CRITICAL,
        recommended_action="Upgrade to Django 4.2.8",
    )


@pytest.fixture
def sample_triage_result_safe():
    return TriageResult(
        alert_number=2,
        cve_id="CVE-2024-0002",
        package_name="requests",
        severity=Severity.HIGH,
        summary="SSRF vulnerability in requests library",
        affected=False,
        evidence="Package is only used in test suite",
        risk_level=Severity.LOW,
        recommended_action="Upgrade when convenient",
    )


@pytest.fixture
def sample_alert_group(sample_triage_result, sample_triage_result_safe):
    return AlertGroup(
        package_name="django",
        package_ecosystem="pip",
        current_version="4.2.5",
        target_version="4.2.8",
        alerts=[sample_triage_result, sample_triage_result_safe],
    )


@pytest.fixture
def sample_repo_result(sample_triage_result, sample_triage_result_safe):
    group1 = AlertGroup(
        package_name="django",
        package_ecosystem="pip",
        current_version="4.2.5",
        target_version="4.2.8",
        alerts=[sample_triage_result],
    )
    group2 = AlertGroup(
        package_name="requests",
        package_ecosystem="pip",
        current_version="2.28.0",
        target_version="2.31.0",
        alerts=[sample_triage_result_safe],
    )
    return RepoResult(
        repo="my-org/django-app",
        access_mode=AccessMode.LOCAL,
        groups=[group1, group2],
    )


@pytest.fixture
def sample_repo_result_error():
    return RepoResult(
        repo="my-org/broken-repo",
        access_mode=AccessMode.REMOTE,
        error="Failed to scan: Claude timed out",
        groups=[],
    )


@pytest.fixture
def sample_scan_report(sample_repo_result, sample_repo_result_error):
    return ScanReport(
        timestamp=datetime(2024, 1, 15, 10, 30),
        org="my-org",
        severity_filter=[Severity.CRITICAL, Severity.HIGH],
        available_mcps={"github": True, "slack": True},
        repos=[sample_repo_result, sample_repo_result_error],
    )


@pytest.fixture
def empty_scan_report():
    return ScanReport(
        timestamp=datetime(2024, 1, 15, 10, 30),
        org="empty-org",
        repos=[],
    )


@pytest.fixture
def sample_config():
    return {
        "general": {
            "default_org": "my-org",
            "default_format": "table",
            "default_severity": "critical,high",
        },
        "notifications": {
            "slack_channel": "#security-alerts",
        },
        "repos": {
            "local_paths": ["/home/user/projects/repo1", "/home/user/projects/repo2"],
        },
    }


@pytest.fixture
def config_dir(tmp_path, sample_config, monkeypatch):
    """Creates temp dir with valid config.toml, patches CONFIG_DIR and CONFIG_FILE."""
    config_file = tmp_path / "config.toml"
    config_file.write_bytes(tomli_w.dumps(sample_config).encode())
    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_DIR", tmp_path)
    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_FILE", config_file)
    return tmp_path


@pytest.fixture
def valid_triage_json():
    return json.dumps({
        "groups": [
            {
                "package_name": "django",
                "package_ecosystem": "pip",
                "current_version": "4.2.5",
                "target_version": "4.2.8",
                "alerts": [
                    {
                        "alert_number": 1,
                        "cve_id": "CVE-2024-0001",
                        "package_name": "django",
                        "severity": "critical",
                        "summary": "SQL injection in Django ORM",
                        "affected": True,
                        "evidence": "Found usage in models.py:42",
                        "risk_level": "critical",
                        "recommended_action": "Upgrade to Django 4.2.8",
                    }
                ],
            }
        ]
    })


@pytest.fixture
def valid_triage_json_fenced(valid_triage_json):
    return f"```json\n{valid_triage_json}\n```"
