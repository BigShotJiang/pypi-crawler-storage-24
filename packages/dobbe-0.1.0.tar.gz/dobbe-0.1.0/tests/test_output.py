"""Tests for output formatters."""

import json
from datetime import datetime

from rich.console import Console

from dobbe.models.alert import (
    AccessMode,
    AlertGroup,
    RepoResult,
    ScanReport,
    Severity,
    TriageResult,
)
from dobbe.output import json_out, markdown
from dobbe.output import table as table_out


def _make_sample_report() -> ScanReport:
    """Create a sample report for testing."""
    alert1 = TriageResult(
        alert_number=1,
        cve_id="CVE-2024-0001",
        package_name="django",
        severity=Severity.CRITICAL,
        summary="SQL injection in Django ORM",
        affected=True,
        evidence="Found usage in models.py:42",
        risk_level=Severity.CRITICAL,
        recommended_action="Upgrade to Django 4.2.8",
    )
    alert2 = TriageResult(
        alert_number=2,
        cve_id="CVE-2024-0002",
        package_name="requests",
        severity=Severity.HIGH,
        summary="SSRF vulnerability in requests library",
        affected=False,
        evidence="Package is only used in test suite",
        risk_level=Severity.LOW,
        recommended_action="Upgrade when convenient",
    )
    group1 = AlertGroup(
        package_name="django",
        package_ecosystem="pip",
        current_version="4.2.5",
        target_version="4.2.8",
        alerts=[alert1],
    )
    group2 = AlertGroup(
        package_name="requests",
        package_ecosystem="pip",
        current_version="2.28.0",
        target_version="2.31.0",
        alerts=[alert2],
    )
    repo_result = RepoResult(
        repo="my-org/django-app",
        access_mode=AccessMode.LOCAL,
        groups=[group1, group2],
    )
    return ScanReport(
        timestamp=datetime(2024, 1, 15, 10, 30),
        org="my-org",
        severity_filter=[Severity.CRITICAL, Severity.HIGH],
        available_mcps={"github": True, "slack": True},
        repos=[repo_result],
    )


def test_json_output():
    report = _make_sample_report()
    output = json_out.render_report(report)
    parsed = json.loads(output)
    assert parsed["org"] == "my-org"
    assert len(parsed["repos"]) == 1
    assert len(parsed["repos"][0]["groups"]) == 2


def test_markdown_output():
    report = _make_sample_report()
    output = markdown.render_report(report)
    assert "# Vulnerability Scan Report" in output
    assert "my-org/django-app" in output
    assert "CVE-2024-0001" in output
    assert "django" in output
    assert "Critical" in output


def test_markdown_empty_report():
    report = ScanReport(org="empty-org", repos=[])
    output = markdown.render_report(report)
    assert "empty-org" in output
    assert "Total alerts:** 0" in output


def test_table_output():
    """Test that table output renders key content."""
    report = _make_sample_report()
    import io
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=True, width=120)
    table_out.render_report(report, console=console)
    output = buf.getvalue()
    assert "django" in output
    assert "my-org/django-app" in output


def test_report_stats():
    report = _make_sample_report()
    assert report.total_alerts == 2
    assert report.total_affected == 1
    assert report.total_safe_to_ignore == 1
    stats = report.stats_by_severity
    assert stats[Severity.CRITICAL] == 1
    assert stats[Severity.LOW] == 1


# --- Additional output tests ---


def test_json_render_to_file(tmp_path):
    report = _make_sample_report()
    out_path = tmp_path / "out.json"
    json_out.render_report_to_file(report, str(out_path))
    assert out_path.exists()
    parsed = json.loads(out_path.read_text())
    assert parsed["org"] == "my-org"


def test_json_roundtrip():
    report = _make_sample_report()
    json_str = json_out.render_report(report)
    reconstructed = ScanReport.model_validate_json(json_str)
    assert reconstructed.org == report.org
    assert len(reconstructed.repos) == len(report.repos)
    assert reconstructed.repos[0].groups[0].package_name == "django"


def test_markdown_error_repo():
    error_repo = RepoResult(
        repo="org/broken",
        access_mode=AccessMode.REMOTE,
        error="Failed to scan",
    )
    report = ScanReport(repos=[error_repo])
    output = markdown.render_report(report)
    assert "Error" in output
    assert "Failed to scan" in output


def test_markdown_no_groups():
    empty_repo = RepoResult(
        repo="org/clean",
        access_mode=AccessMode.LOCAL,
        groups=[],
    )
    report = ScanReport(repos=[empty_repo])
    output = markdown.render_report(report)
    assert "No alerts found" in output


def test_markdown_severity_filter_shown():
    report = ScanReport(
        severity_filter=[Severity.CRITICAL, Severity.HIGH],
        repos=[],
    )
    output = markdown.render_report(report)
    assert "Severity filter" in output


def test_table_error_repo():
    error_repo = RepoResult(
        repo="org/broken",
        access_mode=AccessMode.REMOTE,
        error="Timed out",
    )
    report = ScanReport(repos=[error_repo])
    console = Console(file=None, force_terminal=True, width=120)
    table_out.render_report(report, console=console)  # no exception


def test_table_empty_report():
    report = ScanReport(repos=[])
    import io
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=True, width=120)
    table_out.render_report(report, console=console)
    output = buf.getvalue()
    assert "No repositories scanned" in output


def test_table_long_summary_truncated():
    long_summary = "A" * 100
    alert = TriageResult(
        alert_number=1,
        package_name="pkg",
        severity=Severity.LOW,
        summary=long_summary,
        affected=False,
        risk_level=Severity.LOW,
        recommended_action="Do nothing",
    )
    group = AlertGroup(package_name="pkg", alerts=[alert])
    repo = RepoResult(repo="org/repo", access_mode=AccessMode.LOCAL, groups=[group])
    report = ScanReport(repos=[repo])
    import io
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=True, width=120)
    table_out.render_report(report, console=console)
    output = buf.getvalue()
    # Rich uses Unicode ellipsis (…) for truncation
    assert "…" in output or "..." in output


# --- Default console creation (line 28) ---


def test_table_default_console():
    """render_report with no console arg creates its own Console."""
    report = _make_sample_report()
    # Should not raise
    table_out.render_report(report)


# --- No groups message (lines 57-58) ---


def test_markdown_pipe_in_summary():
    """Pipe characters in alert fields are escaped in markdown tables."""
    alert = TriageResult(
        alert_number=1,
        package_name="pkg|name",
        severity=Severity.CRITICAL,
        summary="A | B vulnerability",
        affected=True,
        risk_level=Severity.CRITICAL,
        recommended_action="Upgrade to v2 | see docs",
    )
    group = AlertGroup(package_name="pkg|name", alerts=[alert])
    repo = RepoResult(repo="org/repo", access_mode=AccessMode.LOCAL, groups=[group])
    report = ScanReport(repos=[repo])
    output = markdown.render_report(report)
    assert "pkg\\|name" in output
    assert "A \\| B vulnerability" in output
    assert "Upgrade to v2 \\| see docs" in output


def test_markdown_newline_in_summary():
    """Newline characters in alert fields are replaced with spaces."""
    alert = TriageResult(
        alert_number=1,
        package_name="pkg",
        severity=Severity.HIGH,
        summary="Line1\nLine2",
        affected=False,
        risk_level=Severity.HIGH,
        recommended_action="Fix\nit",
    )
    group = AlertGroup(package_name="pkg", alerts=[alert])
    repo = RepoResult(repo="org/repo", access_mode=AccessMode.LOCAL, groups=[group])
    report = ScanReport(repos=[repo])
    output = markdown.render_report(report)
    assert "Line1 Line2" in output
    assert "Fix it" in output


def test_table_truncation_boundary():
    """Test strings at exactly the truncation boundary (60 for summary, 40 for action)."""
    import io

    for length in [59, 60, 61]:
        summary = "S" * length
        action = "A" * min(length, 41)  # action limit is 40
        alert = TriageResult(
            alert_number=1,
            package_name="pkg",
            severity=Severity.LOW,
            summary=summary,
            affected=False,
            risk_level=Severity.LOW,
            recommended_action=action,
        )
        group = AlertGroup(package_name="pkg", alerts=[alert])
        repo = RepoResult(repo="org/repo", access_mode=AccessMode.LOCAL, groups=[group])
        report = ScanReport(repos=[repo])
        buf = io.StringIO()
        console = Console(file=buf, force_terminal=True, width=200)
        table_out.render_report(report, console=console)
        output = buf.getvalue()
        if length > 60:
            assert "..." in output or "\u2026" in output


def test_table_repo_no_groups():
    """Repo with groups=[] shows 'No alerts' message."""
    empty_repo = RepoResult(
        repo="org/clean",
        access_mode=AccessMode.LOCAL,
        groups=[],
    )
    report = ScanReport(repos=[empty_repo])
    import io
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=True, width=120)
    table_out.render_report(report, console=console)
    output = buf.getvalue()
    assert "No alerts" in output


def test_markdown_special_chars_escaped():
    """Markdown formatting chars in fields are escaped in table cells."""
    alert = TriageResult(
        alert_number=1,
        package_name="@scope/pkg_name",
        severity=Severity.CRITICAL,
        summary="*bold* and `code` issue",
        affected=True,
        risk_level=Severity.CRITICAL,
        recommended_action="See [docs](url) for _details_",
    )
    group = AlertGroup(package_name="@scope/pkg_name", alerts=[alert])
    repo = RepoResult(repo="org/repo", access_mode=AccessMode.LOCAL, groups=[group])
    report = ScanReport(repos=[repo])
    output = markdown.render_report(report)
    assert "\\*bold\\*" in output
    assert "\\`code\\`" in output
    assert "\\[docs\\]" in output
    assert "\\_details\\_" in output
