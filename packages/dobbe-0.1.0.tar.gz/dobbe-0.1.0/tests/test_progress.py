"""Tests for the multi-phase progress display and pipeline callbacks."""

from __future__ import annotations

import io

from rich.console import Console

from dobbe.output.progress import LiveProgress


# --- LiveProgress unit tests ---


def test_live_progress_context_manager():
    """LiveProgress can be used as a context manager without error."""
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=True, width=80)
    with LiveProgress(console=console, title="test") as lp:
        lp.update(phase="Phase 1")
    # No exception means success


def test_live_progress_update_phase():
    """Update sets the current phase."""
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=True, width=80)
    with LiveProgress(console=console, title="test") as lp:
        lp.update(phase="Fetching")
        assert lp._phase == "Fetching"


def test_live_progress_update_counts():
    """Update sets completed and total."""
    lp = LiveProgress(title="test")
    lp.update(phase="Analyzing", completed=3, total=10)
    assert lp._completed == 3
    assert lp._total == 10


def test_live_progress_repo_statuses():
    """Repos can be tracked individually."""
    lp = LiveProgress(title="test")
    lp.update(repo="org/api", repo_status="waiting")
    lp.update(repo="org/web", repo_status="analyzing PR #42")
    lp.update(repo="org/api", repo_status="done (2 PRs)")
    assert lp._repo_statuses["org/api"] == "done (2 PRs)"
    assert lp._repo_statuses["org/web"] == "analyzing PR #42"


def test_live_progress_phase_number():
    """Phase numbers are tracked."""
    lp = LiveProgress(title="test")
    lp.update(phase="Fetch", phase_number=1, total_phases=5)
    assert lp._phase_number == 1
    assert lp._total_phases == 5


def test_live_progress_callback_method():
    """The callback method matches ProgressCallback protocol."""
    lp = LiveProgress(title="test")
    lp.callback(phase="Analyzing", detail="PR #42", completed=1, total=5)
    assert lp._phase == "Analyzing"
    assert lp._completed == 1


def test_live_progress_build_table():
    """The internal table builder produces valid output."""
    lp = LiveProgress(title="test pipeline")
    lp.update(phase="Analyzing", phase_number=2, total_phases=5, total=4, completed=2)
    lp.update(repo="org/api", repo_status="done (1 PR)")
    lp.update(repo="org/web", repo_status="analyzing PR #42")
    table = lp._build_table()
    assert table is not None


def test_live_progress_build_table_with_waiting():
    """Waiting repos get the dot icon."""
    lp = LiveProgress(title="test")
    lp.update(phase="Fetch", repo="org/repo", repo_status="waiting")
    table = lp._build_table()
    assert table is not None


def test_live_progress_no_title():
    """Works without a title."""
    lp = LiveProgress()
    lp.update(phase="Scanning")
    table = lp._build_table()
    assert table is not None


def test_live_progress_no_total():
    """Works with no total count (no progress bar line)."""
    lp = LiveProgress(title="test")
    lp.update(phase="Loading")
    table = lp._build_table()
    assert table is not None


def test_live_progress_renders_in_context():
    """Full render cycle in a context manager."""
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=True, width=100)
    with LiveProgress(console=console, title="dobbe review digest") as lp:
        lp.update(phase="Fetching PRs", phase_number=1, total_phases=5, total=3)
        lp.update(repo="org/api", repo_status="waiting")
        lp.update(repo="org/web", repo_status="waiting")
        lp.update(repo="org/api", repo_status="done (2 PRs)", completed=1)
        lp.update(phase="Analyzing PRs", phase_number=4, total=2, completed=0)
        lp.update(repo="org/api", repo_status="analyzing PR #42", completed=1)
        lp.update(completed=2)
    # Transient mode clears output, so just verify no errors


def test_live_progress_default_console():
    """LiveProgress with no console arg uses a default."""
    lp = LiveProgress(title="test")
    assert lp._console is not None


def test_progress_update_reset_to_zero():
    """Passing completed=0 or total=0 actually resets the value (Bug D)."""
    lp = LiveProgress(title="test")
    lp.update(phase="Working", completed=5, total=10, phase_number=3, total_phases=5)
    assert lp._completed == 5
    assert lp._total == 10
    assert lp._phase_number == 3
    assert lp._total_phases == 5

    # Reset all to zero - previously silently ignored due to truthiness check
    lp.update(phase="Reset", completed=0, total=0, phase_number=0, total_phases=0)
    assert lp._completed == 0
    assert lp._total == 0
    assert lp._phase_number == 0
    assert lp._total_phases == 0


def test_live_progress_multiple_updates():
    """Rapid updates don't cause issues."""
    lp = LiveProgress(title="test")
    for i in range(20):
        lp.update(phase=f"Phase {i}", completed=i, total=20)
    assert lp._completed == 19
    assert lp._phase == "Phase 19"
