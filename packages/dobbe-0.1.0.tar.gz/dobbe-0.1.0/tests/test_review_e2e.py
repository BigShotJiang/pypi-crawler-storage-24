"""End-to-end CLI tests for `dobbe review` commands."""

from __future__ import annotations

import json
from datetime import datetime, timedelta
from unittest.mock import patch, MagicMock, AsyncMock

from typer.testing import CliRunner

from dobbe.cli import app
from dobbe.core.claude import ClaudeResult
from dobbe.models.review import PRInfo, PRReviewResult, ReviewDigest
from dobbe.models.shared import Severity

runner = CliRunner()


def _make_discovery_json():
    created = (datetime.now() - timedelta(days=3)).isoformat()
    return json.dumps({
        "prs": [{
            "pr_number": 42,
            "title": "Fix login bug",
            "author": "alice",
            "url": "https://github.com/org/repo/pull/42",
            "created_at": created,
            "updated_at": datetime.now().isoformat(),
            "additions": 50,
            "deletions": 10,
            "changed_files": 3,
        }]
    })


def _make_review_json():
    return json.dumps({
        "risk_level": "high",
        "summary": "Needs security review",
        "concerns": [{
            "category": "security",
            "severity": "high",
            "description": "Unvalidated input",
            "file_path": "src/auth.py",
            "suggestion": "Add validation",
        }],
        "recommendations": ["Add input validation"],
        "estimated_review_time": "30 min",
        "approval_recommendation": "request_changes",
    })


# --- Basic CLI ---


def test_cli_help_shows_review():
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "review" in result.output


def test_cli_review_help():
    result = runner.invoke(app, ["review", "--help"])
    assert result.exit_code == 0
    assert "digest" in result.output


# --- Review digest command ---


@patch("dobbe.commands.review.load_config")
def test_review_digest_no_repos(mock_load):
    mock_load.return_value = {
        "general": {"default_format": "table"},
        "review": {"watch_repos": []},
    }
    with patch("dobbe.commands.review.discover_mcps", return_value={}):
        result = runner.invoke(app, ["review", "digest"])
    assert result.exit_code == 1
    assert "No repos" in result.output or "repo" in result.output.lower()


@patch("dobbe.commands.review.run_review_digest")
@patch("dobbe.commands.review.discover_mcps")
@patch("dobbe.commands.review.load_config")
def test_review_digest_single_repo_table(mock_load, mock_discover, mock_run):
    mock_load.return_value = {
        "general": {"default_format": "table"},
        "review": {"reviewers": ["@me"], "stale_days": 7},
    }
    mock_discover.return_value = {"github": False, "slack": False}

    pr = PRInfo(
        repo="org/repo",
        pr_number=42,
        title="Fix bug",
        author="alice",
        url="https://github.com/org/repo/pull/42",
        created_at=datetime.now() - timedelta(days=3),
        updated_at=datetime.now(),
    )
    mock_run.return_value = ReviewDigest(
        reviewers=["@me"],
        repos_scanned=["org/repo"],
        results=[PRReviewResult(pr=pr, risk_level=Severity.HIGH, summary="Needs review")],
    )

    result = runner.invoke(app, ["review", "digest", "--repo", "org/repo"])
    assert result.exit_code == 0


@patch("dobbe.commands.review.run_review_digest")
@patch("dobbe.commands.review.discover_mcps")
@patch("dobbe.commands.review.load_config")
def test_review_digest_json_format(mock_load, mock_discover, mock_run):
    mock_load.return_value = {
        "general": {"default_format": "table"},
        "review": {"reviewers": ["@me"], "stale_days": 7},
    }
    mock_discover.return_value = {}
    mock_run.return_value = ReviewDigest(
        repos_scanned=["org/repo"],
        results=[],
    )

    result = runner.invoke(app, ["review", "digest", "--repo", "org/repo", "--format", "json"])
    assert result.exit_code == 0
    assert '"repos_scanned"' in result.output


@patch("dobbe.commands.review.run_review_digest")
@patch("dobbe.commands.review.discover_mcps")
@patch("dobbe.commands.review.load_config")
def test_review_digest_markdown_format(mock_load, mock_discover, mock_run):
    mock_load.return_value = {
        "general": {"default_format": "table"},
        "review": {"reviewers": ["@me"], "stale_days": 7},
    }
    mock_discover.return_value = {}
    mock_run.return_value = ReviewDigest(
        repos_scanned=["org/repo"],
        results=[],
    )

    result = runner.invoke(app, ["review", "digest", "--repo", "org/repo", "--format", "markdown"])
    assert result.exit_code == 0
    assert "PR Review Digest" in result.output


@patch("dobbe.commands.review.run_review_digest")
@patch("dobbe.commands.review.discover_mcps")
@patch("dobbe.commands.review.load_config")
def test_review_digest_custom_reviewer(mock_load, mock_discover, mock_run):
    mock_load.return_value = {
        "general": {"default_format": "table"},
        "review": {"reviewers": ["@me"], "stale_days": 7},
    }
    mock_discover.return_value = {}
    mock_run.return_value = ReviewDigest(repos_scanned=["org/repo"], results=[])

    result = runner.invoke(app, ["review", "digest", "--repo", "org/repo", "--reviewer", "bob"])
    assert result.exit_code == 0
    # Verify reviewer was passed
    call_kwargs = mock_run.call_args.kwargs
    assert call_kwargs["reviewers"] == ["bob"]


@patch("dobbe.commands.review.run_review_digest")
@patch("dobbe.commands.review.discover_mcps")
@patch("dobbe.commands.review.load_config")
def test_review_digest_custom_stale_days(mock_load, mock_discover, mock_run):
    mock_load.return_value = {
        "general": {"default_format": "table"},
        "review": {"reviewers": ["@me"], "stale_days": 7},
    }
    mock_discover.return_value = {}
    mock_run.return_value = ReviewDigest(repos_scanned=["org/repo"], results=[])

    result = runner.invoke(app, ["review", "digest", "--repo", "org/repo", "--stale-days", "14"])
    assert result.exit_code == 0
    call_kwargs = mock_run.call_args.kwargs
    assert call_kwargs["stale_days"] == 14


@patch("dobbe.commands.review.run_review_digest")
@patch("dobbe.commands.review.list_org_repos")
@patch("dobbe.commands.review.discover_mcps")
@patch("dobbe.commands.review.load_config")
def test_review_digest_org(mock_load, mock_discover, mock_list_repos, mock_run):
    mock_load.return_value = {
        "general": {"default_format": "table"},
        "review": {"reviewers": ["@me"], "stale_days": 7},
    }
    mock_discover.return_value = {"github": True}
    mock_list_repos.return_value = ["org/repo1", "org/repo2"]
    mock_run.return_value = ReviewDigest(repos_scanned=["org/repo1", "org/repo2"], results=[])

    result = runner.invoke(app, ["review", "digest", "--org", "org"])
    assert result.exit_code == 0
    call_kwargs = mock_run.call_args.kwargs
    assert call_kwargs["repos"] == ["org/repo1", "org/repo2"]


@patch("dobbe.commands.review.list_org_repos")
@patch("dobbe.commands.review.discover_mcps")
@patch("dobbe.commands.review.load_config")
def test_review_digest_org_list_failure(mock_load, mock_discover, mock_list_repos):
    from dobbe.core.org_repos import OrgListError

    mock_load.return_value = {
        "general": {"default_format": "table"},
        "review": {"reviewers": ["@me"], "stale_days": 7},
    }
    mock_discover.return_value = {"github": True}
    mock_list_repos.side_effect = OrgListError("Could not list repos")

    result = runner.invoke(app, ["review", "digest", "--org", "org"])
    assert result.exit_code == 1


@patch("dobbe.commands.review.run_review_digest")
@patch("dobbe.commands.review.discover_mcps")
@patch("dobbe.commands.review.load_config")
def test_review_digest_from_config(mock_load, mock_discover, mock_run):
    mock_load.return_value = {
        "general": {"default_format": "table"},
        "review": {
            "watch_repos": ["org/configured-repo"],
            "reviewers": ["bob"],
            "stale_days": 14,
        },
    }
    mock_discover.return_value = {}
    mock_run.return_value = ReviewDigest(repos_scanned=["org/configured-repo"], results=[])

    result = runner.invoke(app, ["review", "digest"])
    assert result.exit_code == 0
    call_kwargs = mock_run.call_args.kwargs
    assert call_kwargs["repos"] == ["org/configured-repo"]
    assert call_kwargs["reviewers"] == ["bob"]
    assert call_kwargs["stale_days"] == 14


@patch("dobbe.commands.review._handle_review_notification")
@patch("dobbe.commands.review.run_review_digest")
@patch("dobbe.commands.review.discover_mcps")
@patch("dobbe.commands.review.load_config")
def test_review_digest_notify_slack(mock_load, mock_discover, mock_run, mock_notify):
    mock_load.return_value = {
        "general": {"default_format": "table"},
        "review": {"reviewers": ["@me"], "stale_days": 7},
    }
    mock_discover.return_value = {"github": False, "slack": True}
    mock_run.return_value = ReviewDigest(repos_scanned=["org/repo"], results=[])

    result = runner.invoke(app, ["review", "digest", "--repo", "org/repo", "--notify", "slack", "--channel", "#reviews"])
    assert result.exit_code == 0
    mock_notify.assert_called_once()


# --- _handle_review_notification tests ---


@patch("dobbe.core.claude.ask_claude")
def test_handle_notification_slack_no_mcp(mock_claude):
    from dobbe.commands.review import _handle_review_notification

    digest = ReviewDigest(repos_scanned=["org/repo"], results=[])
    _handle_review_notification(digest, "#ch", {"slack": False}, {})
    mock_claude.assert_not_called()


@patch("dobbe.core.claude.ask_claude")
def test_handle_notification_slack_no_channel(mock_claude):
    from dobbe.commands.review import _handle_review_notification

    _handle_review_notification(
        ReviewDigest(),
        None,
        {"slack": True},
        {},  # no slack_channel in config
    )
    mock_claude.assert_not_called()


@patch("dobbe.core.claude.ask_claude")
def test_handle_notification_slack_success(mock_claude):
    from dobbe.commands.review import _handle_review_notification

    mock_claude.return_value = ClaudeResult(success=True, text="Posted")
    _handle_review_notification(
        ReviewDigest(),
        "#reviews",
        {"slack": True},
        {},
    )
    mock_claude.assert_called_once()


@patch("dobbe.core.claude.ask_claude")
def test_handle_notification_slack_failure(mock_claude):
    from dobbe.commands.review import _handle_review_notification

    mock_claude.return_value = ClaudeResult(success=False, error="API error")
    _handle_review_notification(
        ReviewDigest(),
        "#reviews",
        {"slack": True},
        {},
    )
    mock_claude.assert_called_once()


@patch("dobbe.core.claude.ask_claude")
def test_handle_notification_slack_from_config(mock_claude):
    from dobbe.commands.review import _handle_review_notification

    mock_claude.return_value = ClaudeResult(success=True, text="OK")
    _handle_review_notification(
        ReviewDigest(),
        None,  # no explicit channel
        {"slack": True},
        {"notifications": {"slack_channel": "#configured"}},
    )
    mock_claude.assert_called_once()


# --- Filter options ---


@patch("dobbe.commands.review.run_review_digest")
@patch("dobbe.commands.review.discover_mcps")
@patch("dobbe.commands.review.load_config")
def test_review_digest_skip_label(mock_load, mock_discover, mock_run):
    mock_load.return_value = {
        "general": {"default_format": "table"},
        "review": {"reviewers": ["@me"], "stale_days": 7},
    }
    mock_discover.return_value = {}
    mock_run.return_value = ReviewDigest(repos_scanned=["org/repo"], results=[])

    result = runner.invoke(app, ["review", "digest", "--repo", "org/repo", "--skip-label", "wip,draft"])
    assert result.exit_code == 0
    call_kwargs = mock_run.call_args.kwargs
    assert call_kwargs["skip_labels"] == ["wip", "draft"]


@patch("dobbe.commands.review.run_review_digest")
@patch("dobbe.commands.review.discover_mcps")
@patch("dobbe.commands.review.load_config")
def test_review_digest_skip_author(mock_load, mock_discover, mock_run):
    mock_load.return_value = {
        "general": {"default_format": "table"},
        "review": {"reviewers": ["@me"], "stale_days": 7},
    }
    mock_discover.return_value = {}
    mock_run.return_value = ReviewDigest(repos_scanned=["org/repo"], results=[])

    result = runner.invoke(app, ["review", "digest", "--repo", "org/repo", "--skip-author", "dependabot[bot]"])
    assert result.exit_code == 0
    call_kwargs = mock_run.call_args.kwargs
    assert call_kwargs["skip_authors"] == ["dependabot[bot]"]


@patch("dobbe.commands.review.run_review_digest")
@patch("dobbe.commands.review.discover_mcps")
@patch("dobbe.commands.review.load_config")
def test_review_digest_max_diff_lines(mock_load, mock_discover, mock_run):
    mock_load.return_value = {
        "general": {"default_format": "table"},
        "review": {"reviewers": ["@me"], "stale_days": 7},
    }
    mock_discover.return_value = {}
    mock_run.return_value = ReviewDigest(repos_scanned=["org/repo"], results=[])

    result = runner.invoke(app, ["review", "digest", "--repo", "org/repo", "--max-diff-lines", "500"])
    assert result.exit_code == 0
    call_kwargs = mock_run.call_args.kwargs
    assert call_kwargs["max_diff_lines"] == 500


@patch("dobbe.commands.review.run_review_digest")
@patch("dobbe.commands.review.discover_mcps")
@patch("dobbe.commands.review.load_config")
def test_review_digest_filters_from_config(mock_load, mock_discover, mock_run):
    mock_load.return_value = {
        "general": {"default_format": "table"},
        "review": {
            "watch_repos": ["org/configured-repo"],
            "reviewers": ["@me"],
            "stale_days": 7,
            "skip_labels": ["wip"],
            "skip_authors": ["bot"],
            "max_diff_lines": 1000,
        },
    }
    mock_discover.return_value = {}
    mock_run.return_value = ReviewDigest(repos_scanned=["org/configured-repo"], results=[])

    result = runner.invoke(app, ["review", "digest"])
    assert result.exit_code == 0
    call_kwargs = mock_run.call_args.kwargs
    assert call_kwargs["skip_labels"] == ["wip"]
    assert call_kwargs["skip_authors"] == ["bot"]
    assert call_kwargs["max_diff_lines"] == 1000
