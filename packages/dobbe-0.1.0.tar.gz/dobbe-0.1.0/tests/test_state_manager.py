"""Tests for dobbe.core.state_manager."""

from __future__ import annotations

from dobbe.core.state_manager import (
    get_run_count,
    increment_run_count,
    load_state,
    mark_setup_complete,
    save_state,
)


def test_load_state_missing_file(tmp_path, monkeypatch):
    monkeypatch.setattr("dobbe.core.state_manager.STATE_FILE", tmp_path / "nope.toml")
    assert load_state() == {}


def test_roundtrip(tmp_path, monkeypatch):
    state_file = tmp_path / "state.toml"
    monkeypatch.setattr("dobbe.core.state_manager.STATE_FILE", state_file)
    monkeypatch.setattr("dobbe.core.state_manager.CONFIG_DIR", tmp_path)
    save_state({"runs_since_setup": 5})
    loaded = load_state()
    assert loaded["runs_since_setup"] == 5


def test_increment_run_count(tmp_path, monkeypatch):
    state_file = tmp_path / "state.toml"
    monkeypatch.setattr("dobbe.core.state_manager.STATE_FILE", state_file)
    monkeypatch.setattr("dobbe.core.state_manager.CONFIG_DIR", tmp_path)
    assert increment_run_count() == 1
    assert increment_run_count() == 2
    assert increment_run_count() == 3


def test_mark_setup_complete_resets_count(tmp_path, monkeypatch):
    state_file = tmp_path / "state.toml"
    monkeypatch.setattr("dobbe.core.state_manager.STATE_FILE", state_file)
    monkeypatch.setattr("dobbe.core.state_manager.CONFIG_DIR", tmp_path)
    increment_run_count()
    increment_run_count()
    mark_setup_complete()
    assert get_run_count() == 0
    state = load_state()
    assert "setup_completed_at" in state


def test_get_run_count_default(tmp_path, monkeypatch):
    monkeypatch.setattr("dobbe.core.state_manager.STATE_FILE", tmp_path / "nope.toml")
    assert get_run_count() == 0


def test_load_state_corrupt_file(tmp_path, monkeypatch):
    state_file = tmp_path / "state.toml"
    state_file.write_text("not valid toml [[[[")
    monkeypatch.setattr("dobbe.core.state_manager.STATE_FILE", state_file)
    assert load_state() == {}


def test_increment_from_fresh(tmp_path, monkeypatch):
    state_file = tmp_path / "state.toml"
    monkeypatch.setattr("dobbe.core.state_manager.STATE_FILE", state_file)
    monkeypatch.setattr("dobbe.core.state_manager.CONFIG_DIR", tmp_path)
    # No state file exists yet
    count = increment_run_count()
    assert count == 1
    assert state_file.exists()


def test_load_state_corrupted_binary(tmp_path, monkeypatch):
    """Binary garbage triggers UnicodeDecodeError, returns empty dict (Bug H)."""
    state_file = tmp_path / "state.toml"
    state_file.write_bytes(b"\x80\x81\xff\xfe\x00\x01")
    monkeypatch.setattr("dobbe.core.state_manager.STATE_FILE", state_file)
    assert load_state() == {}


# --- Bug 8-9: PermissionError + symlink handling ---


def test_load_state_permission_denied(tmp_path, monkeypatch):
    state_file = tmp_path / "state.toml"
    state_file.write_bytes(b"key = 'value'")
    state_file.chmod(0o000)
    monkeypatch.setattr("dobbe.core.state_manager.STATE_FILE", state_file)
    try:
        assert load_state() == {}
    finally:
        state_file.chmod(0o644)


def test_save_state_permission_error_silent(tmp_path, monkeypatch):
    """save_state silently ignores PermissionError."""
    # Point STATE_FILE to a read-only directory
    readonly_dir = tmp_path / "readonly"
    readonly_dir.mkdir()
    state_file = readonly_dir / "state.toml"
    monkeypatch.setattr("dobbe.core.state_manager.STATE_FILE", state_file)
    monkeypatch.setattr("dobbe.core.state_manager.CONFIG_DIR", readonly_dir)
    readonly_dir.chmod(0o444)
    try:
        # Should not raise
        save_state({"key": "value"})
    finally:
        readonly_dir.chmod(0o755)


def test_save_state_removes_symlink(tmp_path, monkeypatch):
    """save_state removes symlink before writing to prevent following it."""
    state_file = tmp_path / "state.toml"
    target = tmp_path / "somewhere_else.toml"
    target.write_text("old data")
    state_file.symlink_to(target)
    monkeypatch.setattr("dobbe.core.state_manager.STATE_FILE", state_file)
    monkeypatch.setattr("dobbe.core.state_manager.CONFIG_DIR", tmp_path)
    save_state({"runs_since_setup": 1})
    # Should no longer be a symlink
    assert not state_file.is_symlink()
    assert state_file.exists()
    loaded = load_state()
    assert loaded.get("runs_since_setup") == 1


def test_save_state_creates_config_dir(tmp_path, monkeypatch):
    nested = tmp_path / "deep" / "dir"
    state_file = nested / "state.toml"
    monkeypatch.setattr("dobbe.core.state_manager.STATE_FILE", state_file)
    monkeypatch.setattr("dobbe.core.state_manager.CONFIG_DIR", nested)
    save_state({"key": "value"})
    assert state_file.exists()
