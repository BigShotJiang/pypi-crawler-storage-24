"""Tests for PR review response parsers - parse_pr_list_response, parse_review_response."""

from __future__ import annotations

import json
from datetime import datetime, timedelta

from dobbe.core.response_parser import parse_pr_list_response, parse_review_response
from dobbe.models.review import PRInfo
from dobbe.models.shared import ReviewCategory, Severity


def _make_pr_info() -> PRInfo:
    return PRInfo(
        repo="org/repo",
        pr_number=42,
        title="Fix bug",
        author="alice",
        url="https://github.com/org/repo/pull/42",
        created_at=datetime.now() - timedelta(days=3),
        updated_at=datetime.now(),
    )


# --- parse_pr_list_response ---


def test_parse_pr_list_valid():
    text = json.dumps({
        "prs": [{
            "repo": "org/repo",
            "pr_number": 42,
            "title": "Fix bug",
            "author": "alice",
            "url": "https://github.com/org/repo/pull/42",
            "created_at": "2024-01-15T10:30:00Z",
            "updated_at": "2024-01-16T12:00:00Z",
            "additions": 50,
            "deletions": 10,
            "changed_files": 3,
            "draft": False,
            "description": "Fixes a critical bug",
        }]
    })
    result = parse_pr_list_response(text, "org/repo")
    assert len(result) == 1
    assert result[0].pr_number == 42
    assert result[0].title == "Fix bug"
    assert result[0].author == "alice"
    assert result[0].additions == 50


def test_parse_pr_list_empty():
    text = json.dumps({"prs": []})
    result = parse_pr_list_response(text, "org/repo")
    assert result == []


def test_parse_pr_list_no_json():
    result = parse_pr_list_response("No JSON here", "org/repo")
    assert result == []


def test_parse_pr_list_fenced():
    inner = json.dumps({
        "prs": [{
            "repo": "org/repo",
            "pr_number": 1,
            "title": "PR",
            "author": "bob",
            "url": "https://github.com/org/repo/pull/1",
            "created_at": "2024-01-15T10:30:00Z",
            "updated_at": "2024-01-16T12:00:00Z",
        }]
    })
    text = f"```json\n{inner}\n```"
    result = parse_pr_list_response(text, "org/repo")
    assert len(result) == 1


def test_parse_pr_list_with_preamble():
    inner = json.dumps({
        "prs": [{
            "pr_number": 5,
            "title": "Add test",
            "author": "carol",
            "url": "https://github.com/org/repo/pull/5",
            "created_at": "2024-01-15T10:30:00Z",
            "updated_at": "2024-01-16T12:00:00Z",
        }]
    })
    text = f"Here are the results: {inner}"
    result = parse_pr_list_response(text, "org/repo")
    assert len(result) == 1
    assert result[0].repo == "org/repo"  # falls back to param


def test_parse_pr_list_malformed_entry_skipped():
    text = json.dumps({
        "prs": [
            {
                "pr_number": 1,
                "title": "Good",
                "author": "a",
                "url": "u",
                "created_at": "2024-01-15T10:30:00Z",
                "updated_at": "2024-01-16T12:00:00Z",
            },
            "not a dict",
        ]
    })
    result = parse_pr_list_response(text, "org/repo")
    assert len(result) == 1


def test_parse_pr_list_gh_cli_format():
    """Handle gh CLI field naming (camelCase)."""
    text = json.dumps({
        "prs": [{
            "number": 7,
            "title": "PR from gh",
            "author": "dev",
            "url": "https://github.com/org/repo/pull/7",
            "createdAt": "2024-01-15T10:30:00Z",
            "updatedAt": "2024-01-16T12:00:00Z",
            "changedFiles": 2,
            "isDraft": True,
            "body": "PR body text",
        }]
    })
    result = parse_pr_list_response(text, "org/repo")
    assert len(result) == 1
    assert result[0].pr_number == 7
    assert result[0].changed_files == 2
    assert result[0].draft is True
    assert result[0].description == "PR body text"


def test_parse_pr_list_missing_optional_fields():
    text = json.dumps({
        "prs": [{
            "pr_number": 1,
            "title": "Minimal",
            "author": "a",
            "url": "u",
            "created_at": "2024-01-15T10:30:00Z",
            "updated_at": "2024-01-16T12:00:00Z",
        }]
    })
    result = parse_pr_list_response(text, "org/repo")
    assert len(result) == 1
    assert result[0].additions == 0
    assert result[0].deletions == 0
    assert result[0].draft is False


def test_parse_pr_list_as_plain_array():
    """Handle response as plain JSON array without wrapper object."""
    text = json.dumps([{
        "pr_number": 1,
        "title": "PR",
        "author": "a",
        "url": "u",
        "created_at": "2024-01-15T10:30:00Z",
        "updated_at": "2024-01-16T12:00:00Z",
    }])
    result = parse_pr_list_response(text, "org/repo")
    assert len(result) == 1


def test_parse_pr_list_bad_datetime():
    text = json.dumps({
        "prs": [{
            "pr_number": 1,
            "title": "Bad date",
            "author": "a",
            "url": "u",
            "created_at": "not-a-date",
            "updated_at": "also-bad",
        }]
    })
    result = parse_pr_list_response(text, "org/repo")
    assert len(result) == 1
    # Should get None on parse failure
    assert result[0].created_at is None


# --- parse_review_response ---


def test_parse_review_valid():
    text = json.dumps({
        "risk_level": "high",
        "summary": "This PR has security concerns",
        "concerns": [{
            "category": "security",
            "severity": "high",
            "description": "SQL injection risk",
            "file_path": "src/db.py",
            "suggestion": "Use parameterized queries",
        }],
        "recommendations": ["Add input validation", "Add tests"],
        "estimated_review_time": "30 min",
        "approval_recommendation": "request_changes",
    })
    result = parse_review_response(text, _make_pr_info())
    assert result.risk_level == Severity.HIGH
    assert result.summary == "This PR has security concerns"
    assert len(result.concerns) == 1
    assert result.concerns[0].category == ReviewCategory.SECURITY
    assert result.concerns[0].file_path == "src/db.py"
    assert len(result.recommendations) == 2
    assert result.estimated_review_time == "30 min"
    assert result.approval_recommendation == "request_changes"
    assert result.analysis_error is None


def test_parse_review_no_json():
    result = parse_review_response("No JSON here", _make_pr_info())
    assert result.analysis_error is not None
    assert "Failed to parse" in result.analysis_error


def test_parse_review_empty():
    result = parse_review_response("", _make_pr_info())
    assert result.analysis_error is not None


def test_parse_review_fenced():
    inner = json.dumps({
        "risk_level": "low",
        "summary": "Clean PR",
        "concerns": [],
        "recommendations": [],
        "estimated_review_time": "10 min",
        "approval_recommendation": "approve",
    })
    text = f"```json\n{inner}\n```"
    result = parse_review_response(text, _make_pr_info())
    assert result.risk_level == Severity.LOW
    assert result.approval_recommendation == "approve"


def test_parse_review_unknown_risk_level():
    text = json.dumps({
        "risk_level": "unknown_level",
        "summary": "Test",
    })
    result = parse_review_response(text, _make_pr_info())
    assert result.risk_level == Severity.MEDIUM  # fallback


def test_parse_review_unknown_category():
    text = json.dumps({
        "risk_level": "low",
        "summary": "Test",
        "concerns": [{
            "category": "unknown_cat",
            "severity": "low",
            "description": "Test concern",
        }],
    })
    result = parse_review_response(text, _make_pr_info())
    assert len(result.concerns) == 1
    assert result.concerns[0].category == ReviewCategory.CODE_QUALITY  # fallback


def test_parse_review_unknown_severity():
    text = json.dumps({
        "risk_level": "low",
        "summary": "Test",
        "concerns": [{
            "category": "security",
            "severity": "unknown_sev",
            "description": "Test",
        }],
    })
    result = parse_review_response(text, _make_pr_info())
    assert result.concerns[0].severity == Severity.MEDIUM  # fallback


def test_parse_review_malformed_concern_skipped():
    text = json.dumps({
        "risk_level": "low",
        "summary": "Test",
        "concerns": [
            {
                "category": "security",
                "severity": "high",
                "description": "Valid",
            },
            "not a dict",
        ],
    })
    result = parse_review_response(text, _make_pr_info())
    assert len(result.concerns) == 1
    assert result.concerns[0].description == "Valid"


def test_parse_review_missing_optional_fields():
    text = json.dumps({
        "risk_level": "medium",
        "summary": "Decent PR",
    })
    result = parse_review_response(text, _make_pr_info())
    assert result.concerns == []
    assert result.recommendations == []
    assert result.estimated_review_time == ""
    assert result.approval_recommendation == ""


def test_parse_review_all_categories():
    for cat in ["security", "test_coverage", "breaking_change", "code_quality", "complexity"]:
        text = json.dumps({
            "risk_level": "low",
            "summary": "Test",
            "concerns": [{"category": cat, "severity": "low", "description": f"test {cat}"}],
        })
        result = parse_review_response(text, _make_pr_info())
        assert result.concerns[0].category == ReviewCategory(cat)


def test_parse_review_with_preamble():
    inner = json.dumps({
        "risk_level": "high",
        "summary": "Needs work",
        "concerns": [],
    })
    text = f"Here is my analysis:\n{inner}"
    result = parse_review_response(text, _make_pr_info())
    assert result.risk_level == Severity.HIGH


def test_parse_pr_list_fenced_array():
    """Array inside markdown fence."""
    inner = json.dumps([{
        "pr_number": 1,
        "title": "PR",
        "author": "a",
        "url": "u",
        "created_at": "2024-01-15T10:30:00Z",
        "updated_at": "2024-01-16T12:00:00Z",
    }])
    text = f"```json\n{inner}\n```"
    result = parse_pr_list_response(text, "org/repo")
    assert len(result) == 1


def test_parse_pr_list_array_with_preamble():
    """Array with preamble text - exercises fallback [bracket search."""
    inner = json.dumps([{
        "pr_number": 3,
        "title": "PR3",
        "author": "c",
        "url": "u",
        "created_at": "2024-01-15T10:30:00Z",
        "updated_at": "2024-01-16T12:00:00Z",
    }])
    text = f"Here are the PRs: {inner}"
    result = parse_pr_list_response(text, "org/repo")
    assert len(result) == 1
    assert result[0].pr_number == 3


def test_parse_pr_list_missing_datetime():
    """PR with no datetime fields - exercises _parse_datetime empty path."""
    text = json.dumps({
        "prs": [{
            "pr_number": 1,
            "title": "No dates",
            "author": "a",
            "url": "u",
        }]
    })
    result = parse_pr_list_response(text, "org/repo")
    assert len(result) == 1
    assert result[0].created_at is None


# --- line_number parsing ---


def test_parse_review_with_line_number():
    text = json.dumps({
        "risk_level": "high",
        "summary": "Issues found",
        "concerns": [{
            "category": "security",
            "severity": "high",
            "description": "SQL injection",
            "file_path": "src/db.py",
            "line_number": 42,
            "suggestion": "Use parameterized queries",
        }],
    })
    result = parse_review_response(text, _make_pr_info())
    assert result.concerns[0].line_number == 42


def test_parse_review_line_number_null():
    text = json.dumps({
        "risk_level": "low",
        "summary": "OK",
        "concerns": [{
            "category": "code_quality",
            "severity": "low",
            "description": "Minor",
            "line_number": None,
        }],
    })
    result = parse_review_response(text, _make_pr_info())
    assert result.concerns[0].line_number is None


def test_parse_review_line_number_invalid():
    text = json.dumps({
        "risk_level": "low",
        "summary": "OK",
        "concerns": [{
            "category": "code_quality",
            "severity": "low",
            "description": "Test",
            "line_number": "not_a_number",
        }],
    })
    result = parse_review_response(text, _make_pr_info())
    assert result.concerns[0].line_number is None


# --- labels parsing ---


def test_parse_pr_list_with_string_labels():
    text = json.dumps({
        "prs": [{
            "pr_number": 10,
            "title": "Label test",
            "author": "dev",
            "url": "https://github.com/org/repo/pull/10",
            "created_at": "2024-01-15T10:30:00Z",
            "updated_at": "2024-01-16T12:00:00Z",
            "labels": ["bug", "feature"],
        }]
    })
    result = parse_pr_list_response(text, "org/repo")
    assert len(result) == 1
    assert result[0].labels == ["bug", "feature"]


def test_parse_pr_list_with_dict_labels():
    text = json.dumps({
        "prs": [{
            "pr_number": 11,
            "title": "Dict label test",
            "author": "dev",
            "url": "https://github.com/org/repo/pull/11",
            "created_at": "2024-01-15T10:30:00Z",
            "updated_at": "2024-01-16T12:00:00Z",
            "labels": [{"name": "bug"}, {"name": "urgent"}],
        }]
    })
    result = parse_pr_list_response(text, "org/repo")
    assert len(result) == 1
    assert result[0].labels == ["bug", "urgent"]


def test_parse_datetime_strips_timezone():
    """parse_datetime returns naive datetime even for tz-aware input."""
    from dobbe.core.response_parser import parse_datetime

    result = parse_datetime("2024-01-15T10:30:00Z")
    assert result is not None
    assert result.tzinfo is None
    assert result.year == 2024
    assert result.month == 1
    assert result.hour == 10

    result2 = parse_datetime("2024-01-15T10:30:00+05:30")
    assert result2 is not None
    assert result2.tzinfo is None


def test_parse_pr_list_no_labels():
    text = json.dumps({
        "prs": [{
            "pr_number": 12,
            "title": "No labels",
            "author": "dev",
            "url": "https://github.com/org/repo/pull/12",
            "created_at": "2024-01-15T10:30:00Z",
            "updated_at": "2024-01-16T12:00:00Z",
        }]
    })
    result = parse_pr_list_response(text, "org/repo")
    assert len(result) == 1
    assert result[0].labels == []
