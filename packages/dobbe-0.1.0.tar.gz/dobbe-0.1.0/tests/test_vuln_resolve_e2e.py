"""End-to-end CLI tests for `dobbe vuln resolve`."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch, MagicMock

from typer.testing import CliRunner

from dobbe.cli import app
from dobbe.models.alert import (
    AccessMode,
    AlertGroup,
    RepoResult,
    ScanReport,
    Severity,
    TriageResult,
)
from dobbe.models.resolve import (
    ConversationLog,
    FixAction,
    FixResult,
    PipelineIteration,
    ResolveReport,
    VerifyResult,
)

runner = CliRunner()


def _make_resolve_report(converged: bool = True, pr_url: str = "") -> ResolveReport:
    fix = FixAction(
        package_name="django",
        file_modified="requirements.txt",
        old_version="4.2.5",
        new_version="4.2.11",
        alerts_addressed=[1],
    )
    fr = FixResult(repo="org/repo", branch="dobbe/fix", base_branch="main", fixes=[fix])
    vr = VerifyResult(passed=converged)
    pi = PipelineIteration(iteration=1, fix_result=fr, verify_result=vr)
    log = ConversationLog()
    log.add(agent="orchestrator", icon="\u2699\ufe0f", summary="Ready")
    return ResolveReport(
        repo="org/repo",
        scan_summary="1 alert",
        iterations=[pi],
        converged=converged,
        max_iterations=3,
        final_branch="dobbe/fix",
        pr_url=pr_url,
        summary="Fixed 1 package",
        conversation=log,
    )


# --- Missing --repo ---


@patch("dobbe.commands.vuln.load_config")
def test_resolve_no_repo(mock_load):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    result = runner.invoke(app, ["vuln", "resolve"])
    assert result.exit_code == 1
    assert "repo" in result.output.lower()


# --- Table output (default) ---


@patch("dobbe.commands.vuln.run_pipeline")
@patch("dobbe.commands.vuln.resolve_repo")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_resolve_table_output(mock_load, mock_discover, mock_resolve, mock_pipeline):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": False, "slack": False}
    mock_resolve.return_value = (AccessMode.REMOTE, None)
    mock_pipeline.return_value = _make_resolve_report()

    result = runner.invoke(app, ["vuln", "resolve", "--repo", "org/repo", "--no-pr"])
    assert result.exit_code == 0
    assert "django" in result.output


# --- JSON output ---


@patch("dobbe.commands.vuln.run_pipeline")
@patch("dobbe.commands.vuln.resolve_repo")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_resolve_json_output(mock_load, mock_discover, mock_resolve, mock_pipeline):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": False, "slack": False}
    mock_resolve.return_value = (AccessMode.REMOTE, None)
    mock_pipeline.return_value = _make_resolve_report()

    result = runner.invoke(app, ["vuln", "resolve", "--repo", "org/repo", "--format", "json", "--no-pr"])
    assert result.exit_code == 0
    assert '"repo"' in result.output


# --- Markdown output ---


@patch("dobbe.commands.vuln.run_pipeline")
@patch("dobbe.commands.vuln.resolve_repo")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_resolve_markdown_output(mock_load, mock_discover, mock_resolve, mock_pipeline):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": False, "slack": False}
    mock_resolve.return_value = (AccessMode.REMOTE, None)
    mock_pipeline.return_value = _make_resolve_report()

    result = runner.invoke(app, ["vuln", "resolve", "--repo", "org/repo", "--format", "markdown", "--no-pr"])
    assert result.exit_code == 0
    assert "Transcript" in result.output


# --- Dry run ---


@patch("dobbe.commands.vuln.run_pipeline")
@patch("dobbe.commands.vuln.resolve_repo")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_resolve_dry_run(mock_load, mock_discover, mock_resolve, mock_pipeline):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": False, "slack": False}
    mock_resolve.return_value = (AccessMode.REMOTE, None)
    mock_pipeline.return_value = ResolveReport(repo="org/repo", scan_summary="5 alerts")

    result = runner.invoke(app, ["vuln", "resolve", "--repo", "org/repo", "--dry-run"])
    assert result.exit_code == 0
    # Pipeline should have been called with dry_run=True
    call_args = mock_pipeline.call_args
    cfg = call_args[0][0]
    assert cfg.dry_run is True


# --- Skip verify ---


@patch("dobbe.commands.vuln.run_pipeline")
@patch("dobbe.commands.vuln.resolve_repo")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_resolve_skip_verify(mock_load, mock_discover, mock_resolve, mock_pipeline):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": False, "slack": False}
    mock_resolve.return_value = (AccessMode.REMOTE, None)
    mock_pipeline.return_value = _make_resolve_report()

    result = runner.invoke(app, ["vuln", "resolve", "--repo", "org/repo", "--skip-verify", "--no-pr"])
    assert result.exit_code == 0
    cfg = mock_pipeline.call_args[0][0]
    assert cfg.skip_verify is True


# --- Custom options ---


@patch("dobbe.commands.vuln.run_pipeline")
@patch("dobbe.commands.vuln.resolve_repo")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_resolve_custom_options(mock_load, mock_discover, mock_resolve, mock_pipeline):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": False, "slack": False}
    mock_resolve.return_value = (AccessMode.LOCAL, "/tmp/repo")
    mock_pipeline.return_value = _make_resolve_report()

    result = runner.invoke(app, [
        "vuln", "resolve",
        "--repo", "org/repo",
        "--severity", "critical",
        "--max-iterations", "5",
        "--base", "develop",
        "--branch", "my-fix-branch",
        "--no-pr",
    ])
    assert result.exit_code == 0
    cfg = mock_pipeline.call_args[0][0]
    assert cfg.severity_filter == ["critical"]
    assert cfg.max_iterations == 5
    assert cfg.base_branch == "develop"
    assert cfg.branch_name == "my-fix-branch"
    assert cfg.local_path == "/tmp/repo"
    assert cfg.no_pr is True


# --- PR URL shown ---


@patch("dobbe.commands.vuln.run_pipeline")
@patch("dobbe.commands.vuln.resolve_repo")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_resolve_shows_pr_url(mock_load, mock_discover, mock_resolve, mock_pipeline):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": False, "slack": False}
    mock_resolve.return_value = (AccessMode.REMOTE, None)
    mock_pipeline.return_value = _make_resolve_report(pr_url="https://github.com/org/repo/pull/42")

    result = runner.invoke(app, ["vuln", "resolve", "--repo", "org/repo"])
    assert result.exit_code == 0
    assert "pull/42" in result.output


# --- Not converged report ---


@patch("dobbe.commands.vuln.run_pipeline")
@patch("dobbe.commands.vuln.resolve_repo")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_resolve_not_converged(mock_load, mock_discover, mock_resolve, mock_pipeline):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": False, "slack": False}
    mock_resolve.return_value = (AccessMode.REMOTE, None)
    mock_pipeline.return_value = _make_resolve_report(converged=False)

    result = runner.invoke(app, ["vuln", "resolve", "--repo", "org/repo", "--no-pr"])
    assert result.exit_code == 0


# --- Severity default from config ---


@patch("dobbe.commands.vuln.run_pipeline")
@patch("dobbe.commands.vuln.resolve_repo")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_resolve_uses_config_severity(mock_load, mock_discover, mock_resolve, mock_pipeline):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical"}}
    mock_discover.return_value = {"github": False}
    mock_resolve.return_value = (AccessMode.REMOTE, None)
    mock_pipeline.return_value = _make_resolve_report()

    result = runner.invoke(app, ["vuln", "resolve", "--repo", "org/repo", "--no-pr"])
    assert result.exit_code == 0
    cfg = mock_pipeline.call_args[0][0]
    assert cfg.severity_filter == ["critical"]


# --- Empty report ---


@patch("dobbe.commands.vuln.run_pipeline")
@patch("dobbe.commands.vuln.resolve_repo")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_resolve_empty_report(mock_load, mock_discover, mock_resolve, mock_pipeline):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": False}
    mock_resolve.return_value = (AccessMode.REMOTE, None)
    mock_pipeline.return_value = ResolveReport(repo="org/repo")

    result = runner.invoke(app, ["vuln", "resolve", "--repo", "org/repo", "--no-pr"])
    assert result.exit_code == 0


# --- --from-scan tests ---


def _make_scan_report(repos_data=None):
    """Build a ScanReport with optional repo data."""
    repos = []
    for repo_name, has_alerts in (repos_data or [("org/repo", True)]):
        if has_alerts:
            alert = TriageResult(
                alert_number=1,
                package_name="django",
                severity=Severity.CRITICAL,
                summary="SQL injection",
                affected=True,
                risk_level=Severity.CRITICAL,
                recommended_action="Upgrade",
            )
            group = AlertGroup(
                package_name="django",
                package_ecosystem="pip",
                current_version="4.2.5",
                target_version="4.2.11",
                alerts=[alert],
            )
            repos.append(RepoResult(repo=repo_name, access_mode=AccessMode.REMOTE, groups=[group]))
        else:
            repos.append(RepoResult(repo=repo_name, access_mode=AccessMode.REMOTE, error="Scan failed"))
    return ScanReport(repos=repos)


def _write_scan_json(tmp_path: Path, report: ScanReport) -> str:
    path = tmp_path / "scan.json"
    path.write_text(report.model_dump_json())
    return str(path)


@patch("dobbe.commands.vuln.run_pipeline")
@patch("dobbe.commands.vuln.resolve_repo")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_resolve_from_scan_single_repo(mock_load, mock_discover, mock_resolve, mock_pipeline, tmp_path):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": False}
    mock_resolve.return_value = (AccessMode.REMOTE, None)
    mock_pipeline.return_value = _make_resolve_report()

    scan_path = _write_scan_json(tmp_path, _make_scan_report())
    result = runner.invoke(app, ["vuln", "resolve", "--repo", "org/repo", "--from-scan", scan_path, "--no-pr"])
    assert result.exit_code == 0
    cfg = mock_pipeline.call_args[0][0]
    assert cfg.scan_summary_override is not None
    assert "django" in cfg.scan_summary_override


@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_resolve_from_scan_repo_not_in_report(mock_load, mock_discover, tmp_path):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": False}

    scan_path = _write_scan_json(tmp_path, _make_scan_report([("org/other", True)]))
    result = runner.invoke(app, ["vuln", "resolve", "--repo", "org/repo", "--from-scan", scan_path, "--no-pr"])
    assert result.exit_code == 1
    assert "not found in scan report" in result.output


@patch("dobbe.commands.vuln.run_pipeline")
@patch("dobbe.commands.vuln.resolve_repo")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_resolve_from_scan_stdin(mock_load, mock_discover, mock_resolve, mock_pipeline):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": False}
    mock_resolve.return_value = (AccessMode.REMOTE, None)
    mock_pipeline.return_value = _make_resolve_report()

    report = _make_scan_report()
    with patch("dobbe.commands.vuln.sys") as mock_sys:
        mock_sys.stdin.read.return_value = report.model_dump_json()
        result = runner.invoke(app, ["vuln", "resolve", "--repo", "org/repo", "--from-scan", "-", "--no-pr"])

    assert result.exit_code == 0
    cfg = mock_pipeline.call_args[0][0]
    assert cfg.scan_summary_override is not None


@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_resolve_from_scan_dry_run_conflict(mock_load, mock_discover, tmp_path):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": False}

    scan_path = _write_scan_json(tmp_path, _make_scan_report())
    result = runner.invoke(app, ["vuln", "resolve", "--repo", "org/repo", "--from-scan", scan_path, "--dry-run"])
    assert result.exit_code == 1
    assert "mutually exclusive" in result.output


@patch("dobbe.commands.vuln.run_pipeline")
@patch("dobbe.commands.vuln.resolve_repo")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_resolve_from_scan_preserves_other_options(mock_load, mock_discover, mock_resolve, mock_pipeline, tmp_path):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": False}
    mock_resolve.return_value = (AccessMode.REMOTE, None)
    mock_pipeline.return_value = _make_resolve_report()

    scan_path = _write_scan_json(tmp_path, _make_scan_report())
    result = runner.invoke(app, [
        "vuln", "resolve",
        "--repo", "org/repo",
        "--from-scan", scan_path,
        "--max-iterations", "5",
        "--base", "develop",
        "--no-pr",
    ])
    assert result.exit_code == 0
    cfg = mock_pipeline.call_args[0][0]
    assert cfg.max_iterations == 5
    assert cfg.base_branch == "develop"
    assert cfg.no_pr is True
    assert cfg.scan_summary_override is not None


# --- --from-scan batch mode ---


@patch("dobbe.commands.vuln.run_batch_resolve")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_resolve_from_scan_batch_org(mock_load, mock_discover, mock_batch, tmp_path):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": False}

    from dobbe.models.resolve import BatchResolveReport
    mock_batch.return_value = [
        ResolveReport(repo="org/r1", converged=True),
        ResolveReport(repo="org/r2", converged=True),
    ]

    report = _make_scan_report([("org/r1", True), ("org/r2", True)])
    scan_path = _write_scan_json(tmp_path, report)

    result = runner.invoke(app, ["vuln", "resolve", "--org", "myorg", "--from-scan", scan_path, "--no-pr"])
    assert result.exit_code == 0
    batch_cfg = mock_batch.call_args[0][0]
    assert set(batch_cfg.repos) == {"org/r1", "org/r2"}
    assert "org/r1" in batch_cfg.scan_overrides
    assert "org/r2" in batch_cfg.scan_overrides


@patch("dobbe.commands.vuln.run_batch_resolve")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_resolve_from_scan_batch_user(mock_load, mock_discover, mock_batch, tmp_path):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": False}

    mock_batch.return_value = [ResolveReport(repo="user/r1", converged=True)]

    report = _make_scan_report([("user/r1", True)])
    scan_path = _write_scan_json(tmp_path, report)

    result = runner.invoke(app, ["vuln", "resolve", "--user", "myuser", "--from-scan", scan_path, "--no-pr"])
    assert result.exit_code == 0
    batch_cfg = mock_batch.call_args[0][0]
    assert batch_cfg.repos == ["user/r1"]
    assert "user/r1" in batch_cfg.scan_overrides


@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_resolve_from_scan_batch_empty_report(mock_load, mock_discover, tmp_path):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": False}

    # All repos have errors → no valid repos
    report = _make_scan_report([("org/r1", False), ("org/r2", False)])
    scan_path = _write_scan_json(tmp_path, report)

    result = runner.invoke(app, ["vuln", "resolve", "--org", "myorg", "--from-scan", scan_path, "--no-pr"])
    assert result.exit_code == 0
    assert "No repos" in result.output


@patch("dobbe.commands.vuln.run_batch_resolve")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_resolve_from_scan_batch_mixed_errors(mock_load, mock_discover, mock_batch, tmp_path):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": False}

    mock_batch.return_value = [
        ResolveReport(repo="org/r1", converged=True),
        ResolveReport(repo="org/r3", converged=True),
    ]

    # r2 has error, should be excluded
    report = _make_scan_report([("org/r1", True), ("org/r2", False), ("org/r3", True)])
    scan_path = _write_scan_json(tmp_path, report)

    result = runner.invoke(app, ["vuln", "resolve", "--org", "myorg", "--from-scan", scan_path, "--no-pr"])
    assert result.exit_code == 0
    batch_cfg = mock_batch.call_args[0][0]
    assert set(batch_cfg.repos) == {"org/r1", "org/r3"}
    assert "org/r2" not in batch_cfg.scan_overrides
