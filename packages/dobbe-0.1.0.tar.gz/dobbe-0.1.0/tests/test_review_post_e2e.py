"""End-to-end CLI tests for `dobbe review post` command."""

from __future__ import annotations

import json
from datetime import datetime, timedelta
from unittest.mock import patch

from typer.testing import CliRunner

from dobbe.cli import app
from dobbe.models.review import (
    PRInfo,
    PRReviewResult,
    PostResult,
    ReviewPostReport,
)
from dobbe.models.shared import Severity

runner = CliRunner()


def _make_report(posted=0, skipped=0, failed=0, dry_run=False):
    results = []
    pr_num = 1
    for _ in range(posted):
        pr = PRInfo(
            repo="org/repo", pr_number=pr_num, title=f"PR #{pr_num}",
            author="alice", url=f"https://github.com/org/repo/pull/{pr_num}",
            created_at=datetime.now() - timedelta(days=3), updated_at=datetime.now(),
        )
        review = PRReviewResult(pr=pr, risk_level=Severity.HIGH, summary="Needs work")
        results.append(PostResult(
            pr=pr, review=review, posted=True,
            review_url=f"https://github.com/org/repo/pull/{pr_num}#review",
        ))
        pr_num += 1
    for _ in range(skipped):
        pr = PRInfo(
            repo="org/repo", pr_number=pr_num, title=f"PR #{pr_num}",
            author="bob", url=f"https://github.com/org/repo/pull/{pr_num}",
            created_at=datetime.now() - timedelta(days=1), updated_at=datetime.now(),
        )
        review = PRReviewResult(pr=pr, risk_level=Severity.LOW, summary="OK")
        results.append(PostResult(
            pr=pr, review=review, skipped_reason="already reviewed",
        ))
        pr_num += 1
    for _ in range(failed):
        pr = PRInfo(
            repo="org/repo", pr_number=pr_num, title=f"PR #{pr_num}",
            author="carol", url=f"https://github.com/org/repo/pull/{pr_num}",
            created_at=datetime.now(), updated_at=datetime.now(),
        )
        review = PRReviewResult(pr=pr, risk_level=Severity.MEDIUM, summary="Review")
        results.append(PostResult(
            pr=pr, review=review, error="403 Forbidden",
        ))
        pr_num += 1
    return ReviewPostReport(
        repos_scanned=["org/repo"],
        results=results,
        dry_run=dry_run,
    )


# --- CLI help ---


def test_cli_review_help_shows_post():
    result = runner.invoke(app, ["review", "--help"])
    assert result.exit_code == 0
    assert "post" in result.output


def test_cli_post_help():
    result = runner.invoke(app, ["review", "post", "--help"])
    assert result.exit_code == 0
    assert "--pr" in result.output
    assert "--all" in result.output
    assert "--dry-run" in result.output


# --- Validation ---


@patch("dobbe.commands.review.discover_mcps")
@patch("dobbe.commands.review.run_review_post")
@patch("dobbe.commands.review.load_config")
def test_post_no_pr_no_all_defaults_to_all(mock_load, mock_post, mock_mcps):
    """When neither --pr nor --all is given, default to --all behavior."""
    from dobbe.models.review import ReviewPostReport

    mock_load.return_value = {"general": {"default_format": "table"}}
    mock_mcps.return_value = {}
    mock_post.return_value = ReviewPostReport(
        repos_scanned=["org/repo"], results=[], errors=[], dry_run=False,
    )
    result = runner.invoke(app, ["review", "post", "--repo", "org/repo"])
    assert result.exit_code == 0
    # Verify run_review_post was called with pr_number=None (all PRs mode)
    mock_post.assert_called_once()
    assert mock_post.call_args[1].get("pr_number") is None or mock_post.call_args.kwargs.get("pr_number") is None


@patch("dobbe.commands.review.load_config")
def test_post_both_pr_and_all(mock_load):
    mock_load.return_value = {"general": {"default_format": "table"}}
    result = runner.invoke(app, ["review", "post", "--repo", "org/repo", "--pr", "42", "--all"])
    assert result.exit_code == 1


@patch("dobbe.commands.review.load_config")
def test_post_pr_without_repo(mock_load):
    mock_load.return_value = {"general": {"default_format": "table"}}
    result = runner.invoke(app, ["review", "post", "--pr", "42"])
    assert result.exit_code == 1
    assert "--repo" in result.output


# --- Single PR ---


@patch("dobbe.commands.review.run_review_post")
@patch("dobbe.commands.review.discover_mcps")
@patch("dobbe.commands.review.load_config")
def test_post_single_pr_table(mock_load, mock_discover, mock_run):
    mock_load.return_value = {
        "general": {"default_format": "table"},
        "review": {"reviewers": ["@me"]},
    }
    mock_discover.return_value = {}
    mock_run.return_value = _make_report(posted=1)

    result = runner.invoke(app, ["review", "post", "--repo", "org/repo", "--pr", "42"])
    assert result.exit_code == 0


@patch("dobbe.commands.review.run_review_post")
@patch("dobbe.commands.review.discover_mcps")
@patch("dobbe.commands.review.load_config")
def test_post_single_pr_json(mock_load, mock_discover, mock_run):
    mock_load.return_value = {
        "general": {"default_format": "table"},
        "review": {"reviewers": ["@me"]},
    }
    mock_discover.return_value = {}
    mock_run.return_value = _make_report(posted=1)

    result = runner.invoke(app, ["review", "post", "--repo", "org/repo", "--pr", "42", "--format", "json"])
    assert result.exit_code == 0
    assert '"repos_scanned"' in result.output


@patch("dobbe.commands.review.run_review_post")
@patch("dobbe.commands.review.discover_mcps")
@patch("dobbe.commands.review.load_config")
def test_post_single_pr_markdown(mock_load, mock_discover, mock_run):
    mock_load.return_value = {
        "general": {"default_format": "table"},
        "review": {"reviewers": ["@me"]},
    }
    mock_discover.return_value = {}
    mock_run.return_value = _make_report(posted=1)

    result = runner.invoke(app, ["review", "post", "--repo", "org/repo", "--pr", "42", "--format", "markdown"])
    assert result.exit_code == 0
    assert "dobbe review post" in result.output


# --- Dry run ---


@patch("dobbe.commands.review.run_review_post")
@patch("dobbe.commands.review.discover_mcps")
@patch("dobbe.commands.review.load_config")
def test_post_dry_run(mock_load, mock_discover, mock_run):
    mock_load.return_value = {
        "general": {"default_format": "table"},
        "review": {"reviewers": ["@me"]},
    }
    mock_discover.return_value = {}
    mock_run.return_value = _make_report(skipped=1, dry_run=True)

    result = runner.invoke(app, ["review", "post", "--repo", "org/repo", "--pr", "42", "--dry-run"])
    assert result.exit_code == 0
    call_kwargs = mock_run.call_args.kwargs
    assert call_kwargs["dry_run"] is True


# --- All PRs ---


@patch("dobbe.commands.review.run_review_post")
@patch("dobbe.commands.review.discover_mcps")
@patch("dobbe.commands.review.load_config")
def test_post_all_prs(mock_load, mock_discover, mock_run):
    mock_load.return_value = {
        "general": {"default_format": "table"},
        "review": {"reviewers": ["@me"]},
    }
    mock_discover.return_value = {}
    mock_run.return_value = _make_report(posted=2)

    result = runner.invoke(app, ["review", "post", "--repo", "org/repo", "--all"])
    assert result.exit_code == 0
    call_kwargs = mock_run.call_args.kwargs
    assert call_kwargs["pr_number"] is None


# --- Org ---


@patch("dobbe.commands.review.run_review_post")
@patch("dobbe.commands.review.list_org_repos")
@patch("dobbe.commands.review.discover_mcps")
@patch("dobbe.commands.review.load_config")
def test_post_org(mock_load, mock_discover, mock_list, mock_run):
    mock_load.return_value = {
        "general": {"default_format": "table"},
        "review": {"reviewers": ["@me"]},
    }
    mock_discover.return_value = {"github": True}
    mock_list.return_value = ["org/repo1", "org/repo2"]
    mock_run.return_value = _make_report(posted=2)

    result = runner.invoke(app, ["review", "post", "--org", "org", "--all"])
    assert result.exit_code == 0
    call_kwargs = mock_run.call_args.kwargs
    assert call_kwargs["repos"] == ["org/repo1", "org/repo2"]


# --- No repos ---


@patch("dobbe.commands.review.discover_mcps")
@patch("dobbe.commands.review.load_config")
def test_post_no_repos(mock_load, mock_discover):
    mock_load.return_value = {
        "general": {"default_format": "table"},
        "review": {"watch_repos": []},
    }
    mock_discover.return_value = {}
    result = runner.invoke(app, ["review", "post", "--all"])
    assert result.exit_code == 1
    assert "No repos" in result.output


# --- Org error ---


@patch("dobbe.commands.review.list_org_repos")
@patch("dobbe.commands.review.discover_mcps")
@patch("dobbe.commands.review.load_config")
def test_post_org_list_failure(mock_load, mock_discover, mock_list):
    from dobbe.core.org_repos import OrgListError

    mock_load.return_value = {
        "general": {"default_format": "table"},
        "review": {"reviewers": ["@me"]},
    }
    mock_discover.return_value = {"github": True}
    mock_list.side_effect = OrgListError("Could not list repos")

    result = runner.invoke(app, ["review", "post", "--org", "org", "--all"])
    assert result.exit_code == 1


# --- Custom reviewer ---


@patch("dobbe.commands.review.run_review_post")
@patch("dobbe.commands.review.discover_mcps")
@patch("dobbe.commands.review.load_config")
def test_post_custom_reviewer(mock_load, mock_discover, mock_run):
    mock_load.return_value = {
        "general": {"default_format": "table"},
        "review": {"reviewers": ["@me"]},
    }
    mock_discover.return_value = {}
    mock_run.return_value = _make_report()

    result = runner.invoke(app, [
        "review", "post", "--repo", "org/repo", "--all", "--reviewer", "bob",
    ])
    assert result.exit_code == 0
    call_kwargs = mock_run.call_args.kwargs
    assert call_kwargs["reviewers"] == ["bob"]


# --- Filter options ---


@patch("dobbe.commands.review.run_review_post")
@patch("dobbe.commands.review.discover_mcps")
@patch("dobbe.commands.review.load_config")
def test_post_skip_label(mock_load, mock_discover, mock_run):
    mock_load.return_value = {
        "general": {"default_format": "table"},
        "review": {"reviewers": ["@me"]},
    }
    mock_discover.return_value = {}
    mock_run.return_value = _make_report()

    result = runner.invoke(app, [
        "review", "post", "--repo", "org/repo", "--all", "--skip-label", "wip",
    ])
    assert result.exit_code == 0
    call_kwargs = mock_run.call_args.kwargs
    assert call_kwargs["skip_labels"] == ["wip"]


@patch("dobbe.commands.review.run_review_post")
@patch("dobbe.commands.review.discover_mcps")
@patch("dobbe.commands.review.load_config")
def test_post_max_diff_lines(mock_load, mock_discover, mock_run):
    mock_load.return_value = {
        "general": {"default_format": "table"},
        "review": {"reviewers": ["@me"]},
    }
    mock_discover.return_value = {}
    mock_run.return_value = _make_report()

    result = runner.invoke(app, [
        "review", "post", "--repo", "org/repo", "--all", "--max-diff-lines", "300",
    ])
    assert result.exit_code == 0
    call_kwargs = mock_run.call_args.kwargs
    assert call_kwargs["max_diff_lines"] == 300
