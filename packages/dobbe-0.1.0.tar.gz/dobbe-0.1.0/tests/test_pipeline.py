"""Tests for pipeline orchestrator - mocked Claude calls, no real subprocess."""

from __future__ import annotations

import json
import subprocess
from unittest.mock import MagicMock, patch, call

import pytest

from dobbe.core.claude import ClaudeResult
from dobbe.core.pipeline import (
    GitError,
    PipelineConfig,
    _build_iteration_details,
    _build_scan_summary,
    _commit_fixes,
    _create_pr,
    _ensure_local_clone,
    _revert_to_base,
    _run_git,
    _run_git_checked,
    _setup_branch,
    run_pipeline,
    scan_summary_from_repo_result,
)
from dobbe.models.alert import (
    AccessMode,
    AlertGroup,
    RepoResult,
    TriageResult,
)
from dobbe.models.resolve import (
    FixAction,
    FixResult,
    PipelineIteration,
    VerifyIssue,
    VerifyResult,
)
from dobbe.models.shared import Severity, VerifyCategory


# --- Helper data ---


def _make_scan_json():
    return json.dumps({
        "groups": [{
            "package_name": "django",
            "package_ecosystem": "pip",
            "current_version": "4.2.5",
            "target_version": "4.2.11",
            "alerts": [{
                "alert_number": 1,
                "cve_id": "CVE-2024-0001",
                "package_name": "django",
                "severity": "critical",
                "summary": "SQL injection",
                "affected": True,
                "risk_level": "critical",
                "recommended_action": "Upgrade to 4.2.11",
            }],
        }]
    })


def _make_fix_json():
    return json.dumps({
        "fixes": [{
            "package_name": "django",
            "file_modified": "requirements.txt",
            "old_version": "4.2.5",
            "new_version": "4.2.11",
            "alerts_addressed": [1],
            "status": "applied",
        }],
        "skipped": [],
        "diff_summary": "Updated django in requirements.txt",
    })


def _make_verify_pass_json():
    return json.dumps({
        "passed": True,
        "issues": [],
        "test_output": "All tests pass",
        "feedback": "",
    })


def _make_verify_fail_json():
    return json.dumps({
        "passed": False,
        "issues": [{
            "category": "test_failure",
            "severity": "high",
            "description": "test_api.py fails",
            "suggestion": "Pin requests to 2.30.x",
        }],
        "test_output": "FAILED 1 test",
        "feedback": "Pin requests to 2.30.x or update timeout usage",
    })


def _make_report_text():
    return "Fixed 1 vulnerable package (django). All tests pass. Low risk."


# --- _run_git ---


@patch("dobbe.core.pipeline.subprocess.run")
def test_run_git(mock_run):
    mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
    result = _run_git(["status"], "/tmp/repo")
    mock_run.assert_called_once()
    assert result.returncode == 0


# --- _ensure_local_clone ---


def test_ensure_local_clone_existing(tmp_path):
    (tmp_path / ".git").mkdir()
    cfg = PipelineConfig(repo="org/repo", local_path=str(tmp_path))
    path, is_tempdir = _ensure_local_clone(cfg)
    assert path == str(tmp_path)
    assert is_tempdir is False


@patch("dobbe.core.pipeline.subprocess.run")
def test_ensure_local_clone_auto_clone(mock_run):
    mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
    cfg = PipelineConfig(repo="org/repo", local_path=None)
    path, is_tempdir = _ensure_local_clone(cfg)
    assert "dobbe-" in path or "/tmp" in path or "/var" in path
    assert is_tempdir is True
    mock_run.assert_called_once()
    # Check git clone was called with the right URL
    cmd = mock_run.call_args[0][0]
    assert "git" in cmd[0]
    assert "clone" in cmd


@patch("dobbe.core.pipeline.subprocess.run")
def test_ensure_local_clone_failure(mock_run):
    mock_run.return_value = MagicMock(returncode=1, stdout="", stderr="not found")
    cfg = PipelineConfig(repo="org/repo", local_path=None)
    with pytest.raises(RuntimeError, match="Failed to clone"):
        _ensure_local_clone(cfg)


def test_ensure_local_clone_path_no_git(tmp_path):
    """local_path exists but has no .git dir → triggers clone."""
    cfg = PipelineConfig(repo="org/repo", local_path=str(tmp_path))
    with patch("dobbe.core.pipeline.subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
        result = _ensure_local_clone(cfg)
        mock_run.assert_called_once()


# --- _setup_branch ---


@patch("dobbe.core.pipeline._run_git")
def test_setup_branch(mock_git):
    mock_git.return_value = MagicMock(returncode=0, stderr="")
    _setup_branch("/tmp/repo", "fix-branch", "main")
    assert mock_git.call_count == 2
    mock_git.assert_any_call(["checkout", "main"], "/tmp/repo")
    mock_git.assert_any_call(["checkout", "-b", "fix-branch"], "/tmp/repo")


# --- _commit_fixes ---


@patch("dobbe.core.pipeline._run_git")
def test_commit_fixes_with_changes(mock_git):
    # git add returns OK, git diff --cached --quiet returns non-zero (= changes staged),
    # commit returns OK (via _run_git_checked which calls _run_git)
    def side_effect(args, cwd):
        if args[0] == "diff":
            return MagicMock(returncode=1, stderr="")  # changes exist
        return MagicMock(returncode=0, stderr="")

    mock_git.side_effect = side_effect
    result = _commit_fixes("/tmp/repo", "fix vulns")
    assert result is True
    assert mock_git.call_count == 3  # add, diff --cached, commit


@patch("dobbe.core.pipeline._run_git")
def test_commit_fixes_no_changes(mock_git):
    mock_git.return_value = MagicMock(returncode=0)  # diff --cached returns 0 = clean
    result = _commit_fixes("/tmp/repo", "fix vulns")
    assert result is False


# --- _revert_to_base ---


@patch("dobbe.core.pipeline._run_git")
def test_revert_to_base(mock_git):
    mock_git.return_value = MagicMock(returncode=0, stderr="")
    _revert_to_base("/tmp/repo", "main", "fix-branch")
    mock_git.assert_called_once_with(["reset", "--hard", "main"], "/tmp/repo")


# --- _create_pr ---


@patch("dobbe.core.pipeline.subprocess.run")
@patch("dobbe.core.pipeline._run_git")
def test_create_pr_success(mock_git, mock_run):
    mock_git.return_value = MagicMock(returncode=0)
    mock_run.return_value = MagicMock(returncode=0, stdout="https://github.com/org/repo/pull/42\n")
    url = _create_pr("/tmp/repo", "fix-branch", "Fix vulns", "PR body")
    assert url == "https://github.com/org/repo/pull/42"


@patch("dobbe.core.pipeline.subprocess.run")
@patch("dobbe.core.pipeline._run_git")
def test_create_pr_failure(mock_git, mock_run):
    mock_git.return_value = MagicMock(returncode=0)
    mock_run.return_value = MagicMock(returncode=1, stdout="", stderr="error")
    url = _create_pr("/tmp/repo", "fix-branch", "Fix vulns", "PR body")
    assert url == ""


# --- _build_scan_summary ---


def test_build_scan_summary():
    scan_text = _make_scan_json()
    summary = _build_scan_summary(scan_text, "org/repo")
    assert "django" in summary
    assert "1 alert" in summary


def test_build_scan_summary_error():
    summary = _build_scan_summary("not json", "org/repo")
    assert "Scan error" in summary


# --- _build_iteration_details ---


def test_build_iteration_details():
    fix = FixAction(package_name="django", file_modified="req.txt", old_version="4.2.5", new_version="4.2.11")
    fr = FixResult(repo="org/repo", branch="b", base_branch="main", fixes=[fix], diff_summary="Updated django")
    vr = VerifyResult(passed=True, test_output="OK")
    iterations = [PipelineIteration(iteration=1, fix_result=fr, verify_result=vr)]
    details = _build_iteration_details(iterations)
    assert "Iteration 1" in details
    assert "PASSED" in details
    assert "Updated django" in details


def test_build_iteration_details_with_failure():
    fr = FixResult(repo="org/repo", branch="b", base_branch="main")
    issue = VerifyIssue(
        category=VerifyCategory.TEST_FAILURE,
        severity=Severity.HIGH,
        description="Tests fail",
    )
    vr = VerifyResult(passed=False, issues=[issue], feedback="Fix tests")
    iterations = [PipelineIteration(iteration=1, fix_result=fr, verify_result=vr)]
    details = _build_iteration_details(iterations)
    assert "FAILED" in details
    assert "Tests fail" in details
    assert "Fix tests" in details


def test_build_iteration_details_no_verify():
    fr = FixResult(repo="org/repo", branch="b", base_branch="main")
    iterations = [PipelineIteration(iteration=1, fix_result=fr)]
    details = _build_iteration_details(iterations)
    assert "Iteration 1" in details


# --- run_pipeline (full orchestration) ---


@patch("dobbe.core.pipeline._create_pr")
@patch("dobbe.core.pipeline._commit_fixes")
@patch("dobbe.core.pipeline._setup_branch")
@patch("dobbe.core.pipeline._ensure_local_clone")
@patch("dobbe.core.pipeline.ask_claude")
def test_run_pipeline_converges_first_try(mock_claude, mock_clone, mock_branch, mock_commit, mock_pr):
    mock_clone.return_value = ("/tmp/repo", False)
    mock_branch.return_value = None
    mock_commit.return_value = True
    mock_pr.return_value = "https://github.com/org/repo/pull/1"

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=_make_scan_json()),     # scan
        ClaudeResult(success=True, text=_make_fix_json()),      # fix
        ClaudeResult(success=True, text=_make_verify_pass_json()),  # verify
        ClaudeResult(success=True, text=_make_report_text()),   # report
    ]

    cfg = PipelineConfig(repo="org/repo", local_path="/tmp/repo")
    report = run_pipeline(cfg)

    assert report.converged is True
    assert report.iteration_count == 1
    assert report.total_fixes == 1
    assert report.pr_url == "https://github.com/org/repo/pull/1"
    assert len(report.conversation.messages) > 0


@patch("dobbe.core.pipeline._create_pr")
@patch("dobbe.core.pipeline._revert_to_base")
@patch("dobbe.core.pipeline._commit_fixes")
@patch("dobbe.core.pipeline._setup_branch")
@patch("dobbe.core.pipeline._ensure_local_clone")
@patch("dobbe.core.pipeline.ask_claude")
def test_run_pipeline_converges_second_try(mock_claude, mock_clone, mock_branch, mock_commit, mock_revert, mock_pr):
    mock_clone.return_value = ("/tmp/repo", False)
    mock_branch.return_value = None
    mock_commit.return_value = True
    mock_revert.return_value = None
    mock_pr.return_value = "https://github.com/org/repo/pull/2"

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=_make_scan_json()),          # scan
        ClaudeResult(success=True, text=_make_fix_json()),           # fix iter 1
        ClaudeResult(success=True, text=_make_verify_fail_json()),   # verify iter 1 - FAIL
        ClaudeResult(success=True, text=_make_fix_json()),           # fix iter 2
        ClaudeResult(success=True, text=_make_verify_pass_json()),   # verify iter 2 - PASS
        ClaudeResult(success=True, text=_make_report_text()),        # report
    ]

    cfg = PipelineConfig(repo="org/repo", local_path="/tmp/repo")
    report = run_pipeline(cfg)

    assert report.converged is True
    assert report.iteration_count == 2
    mock_revert.assert_called_once()


@patch("dobbe.core.pipeline._commit_fixes")
@patch("dobbe.core.pipeline._revert_to_base")
@patch("dobbe.core.pipeline._setup_branch")
@patch("dobbe.core.pipeline._ensure_local_clone")
@patch("dobbe.core.pipeline.ask_claude")
def test_run_pipeline_exhausts_iterations(mock_claude, mock_clone, mock_branch, mock_revert, mock_commit):
    mock_clone.return_value = ("/tmp/repo", False)
    mock_branch.return_value = None
    mock_commit.return_value = True
    mock_revert.return_value = None

    # All verifications fail, max_iterations=2
    mock_claude.side_effect = [
        ClaudeResult(success=True, text=_make_scan_json()),
        ClaudeResult(success=True, text=_make_fix_json()),
        ClaudeResult(success=True, text=_make_verify_fail_json()),
        ClaudeResult(success=True, text=_make_fix_json()),
        ClaudeResult(success=True, text=_make_verify_fail_json()),
        ClaudeResult(success=True, text=_make_report_text()),
    ]

    cfg = PipelineConfig(repo="org/repo", local_path="/tmp/repo", max_iterations=2, no_pr=True)
    report = run_pipeline(cfg)

    assert report.converged is False
    assert report.iteration_count == 2


@patch("dobbe.core.pipeline._commit_fixes")
@patch("dobbe.core.pipeline._setup_branch")
@patch("dobbe.core.pipeline._ensure_local_clone")
@patch("dobbe.core.pipeline.ask_claude")
def test_run_pipeline_dry_run(mock_claude, mock_clone, mock_branch, mock_commit):
    mock_clone.return_value = ("/tmp/repo", False)
    mock_branch.return_value = None

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=_make_scan_json()),
    ]

    cfg = PipelineConfig(repo="org/repo", local_path="/tmp/repo", dry_run=True)
    report = run_pipeline(cfg)

    assert report.converged is False
    assert report.iteration_count == 0
    # Fix agent should NOT have been called
    assert mock_claude.call_count == 1  # only scan
    mock_commit.assert_not_called()


@patch("dobbe.core.pipeline._commit_fixes")
@patch("dobbe.core.pipeline._setup_branch")
@patch("dobbe.core.pipeline._ensure_local_clone")
@patch("dobbe.core.pipeline.ask_claude")
def test_run_pipeline_skip_verify(mock_claude, mock_clone, mock_branch, mock_commit):
    mock_clone.return_value = ("/tmp/repo", False)
    mock_branch.return_value = None
    mock_commit.return_value = True

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=_make_scan_json()),
        ClaudeResult(success=True, text=_make_fix_json()),
        ClaudeResult(success=True, text=_make_report_text()),
    ]

    cfg = PipelineConfig(repo="org/repo", local_path="/tmp/repo", skip_verify=True, no_pr=True)
    report = run_pipeline(cfg)

    assert report.converged is True
    assert report.iteration_count == 1
    # No verify call made
    assert mock_claude.call_count == 3  # scan + fix + report


@patch("dobbe.core.pipeline._setup_branch")
@patch("dobbe.core.pipeline._ensure_local_clone")
@patch("dobbe.core.pipeline.ask_claude")
def test_run_pipeline_scan_failure(mock_claude, mock_clone, mock_branch):
    mock_clone.return_value = ("/tmp/repo", False)
    mock_branch.return_value = None

    mock_claude.return_value = ClaudeResult(success=False, error="Claude timed out")

    cfg = PipelineConfig(repo="org/repo", local_path="/tmp/repo")
    report = run_pipeline(cfg)

    assert report.converged is False
    assert "timed out" in report.scan_summary


@patch("dobbe.core.pipeline._commit_fixes")
@patch("dobbe.core.pipeline._setup_branch")
@patch("dobbe.core.pipeline._ensure_local_clone")
@patch("dobbe.core.pipeline.ask_claude")
def test_run_pipeline_fix_failure(mock_claude, mock_clone, mock_branch, mock_commit):
    mock_clone.return_value = ("/tmp/repo", False)
    mock_branch.return_value = None
    mock_commit.return_value = False  # no changes → converges

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=_make_scan_json()),
        ClaudeResult(success=False, error="Fix agent crashed"),
        ClaudeResult(success=True, text=_make_report_text()),
    ]

    cfg = PipelineConfig(repo="org/repo", local_path="/tmp/repo", no_pr=True)
    report = run_pipeline(cfg)

    assert report.iteration_count == 1


@patch("dobbe.core.pipeline._create_pr")
@patch("dobbe.core.pipeline._commit_fixes")
@patch("dobbe.core.pipeline._setup_branch")
@patch("dobbe.core.pipeline._ensure_local_clone")
@patch("dobbe.core.pipeline.ask_claude")
def test_run_pipeline_no_pr_flag(mock_claude, mock_clone, mock_branch, mock_commit, mock_pr):
    mock_clone.return_value = ("/tmp/repo", False)
    mock_branch.return_value = None
    mock_commit.return_value = True

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=_make_scan_json()),
        ClaudeResult(success=True, text=_make_fix_json()),
        ClaudeResult(success=True, text=_make_verify_pass_json()),
        ClaudeResult(success=True, text=_make_report_text()),
    ]

    cfg = PipelineConfig(repo="org/repo", local_path="/tmp/repo", no_pr=True)
    report = run_pipeline(cfg)

    assert report.converged is True
    mock_pr.assert_not_called()
    assert report.pr_url == ""


@patch("dobbe.core.pipeline._create_pr")
@patch("dobbe.core.pipeline._commit_fixes")
@patch("dobbe.core.pipeline._setup_branch")
@patch("dobbe.core.pipeline._ensure_local_clone")
@patch("dobbe.core.pipeline.ask_claude")
def test_run_pipeline_callbacks(mock_claude, mock_clone, mock_branch, mock_commit, mock_pr):
    mock_clone.return_value = ("/tmp/repo", False)
    mock_branch.return_value = None
    mock_commit.return_value = True
    mock_pr.return_value = ""

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=_make_scan_json()),
        ClaudeResult(success=True, text=_make_fix_json()),
        ClaudeResult(success=True, text=_make_verify_pass_json()),
        ClaudeResult(success=True, text=_make_report_text()),
    ]

    messages = []
    cfg = PipelineConfig(repo="org/repo", local_path="/tmp/repo", no_pr=True)
    report = run_pipeline(cfg, callbacks=lambda msg: messages.append(msg))

    assert len(messages) > 0
    agents_seen = {m.agent for m in messages}
    assert "orchestrator" in agents_seen
    assert "scan" in agents_seen
    assert "fix" in agents_seen


@patch("dobbe.core.pipeline._commit_fixes")
@patch("dobbe.core.pipeline._setup_branch")
@patch("dobbe.core.pipeline._ensure_local_clone")
@patch("dobbe.core.pipeline.ask_claude")
def test_run_pipeline_no_changes_committed(mock_claude, mock_clone, mock_branch, mock_commit):
    """When fix agent makes no changes, pipeline converges without verify."""
    mock_clone.return_value = ("/tmp/repo", False)
    mock_branch.return_value = None
    mock_commit.return_value = False  # no changes

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=_make_scan_json()),
        ClaudeResult(success=True, text=_make_fix_json()),
        ClaudeResult(success=True, text=_make_report_text()),
    ]

    cfg = PipelineConfig(repo="org/repo", local_path="/tmp/repo", no_pr=True)
    report = run_pipeline(cfg)

    assert report.converged is True
    assert report.iteration_count == 1


@patch("dobbe.core.pipeline._revert_to_base")
@patch("dobbe.core.pipeline._commit_fixes")
@patch("dobbe.core.pipeline._setup_branch")
@patch("dobbe.core.pipeline._ensure_local_clone")
@patch("dobbe.core.pipeline.ask_claude")
def test_run_pipeline_verify_error(mock_claude, mock_clone, mock_branch, mock_commit, mock_revert):
    """When verify agent returns error, feedback is captured."""
    mock_clone.return_value = ("/tmp/repo", False)
    mock_branch.return_value = None
    mock_commit.return_value = True
    mock_revert.return_value = None

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=_make_scan_json()),
        ClaudeResult(success=True, text=_make_fix_json()),
        ClaudeResult(success=False, error="Verify crashed"),  # verify fails
        ClaudeResult(success=True, text=_make_report_text()),
    ]

    cfg = PipelineConfig(repo="org/repo", local_path="/tmp/repo", max_iterations=1, no_pr=True)
    report = run_pipeline(cfg)

    assert report.converged is False
    assert report.iteration_count == 1


@patch("dobbe.core.pipeline._commit_fixes")
@patch("dobbe.core.pipeline._setup_branch")
@patch("dobbe.core.pipeline._ensure_local_clone")
@patch("dobbe.core.pipeline.ask_claude")
def test_run_pipeline_custom_branch_name(mock_claude, mock_clone, mock_branch, mock_commit):
    mock_clone.return_value = ("/tmp/repo", False)
    mock_branch.return_value = None
    mock_commit.return_value = True

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=_make_scan_json()),
        ClaudeResult(success=True, text=_make_fix_json()),
        ClaudeResult(success=True, text=_make_verify_pass_json()),
        ClaudeResult(success=True, text=_make_report_text()),
    ]

    cfg = PipelineConfig(repo="org/repo", local_path="/tmp/repo", branch_name="my-custom-branch", no_pr=True)
    report = run_pipeline(cfg)

    assert report.final_branch == "my-custom-branch"
    mock_branch.assert_called_once_with("/tmp/repo", "my-custom-branch", "main")


@patch("dobbe.core.pipeline._commit_fixes")
@patch("dobbe.core.pipeline._setup_branch")
@patch("dobbe.core.pipeline._ensure_local_clone")
@patch("dobbe.core.pipeline.ask_claude")
def test_run_pipeline_report_failure(mock_claude, mock_clone, mock_branch, mock_commit):
    """Report agent failure doesn't crash the pipeline."""
    mock_clone.return_value = ("/tmp/repo", False)
    mock_branch.return_value = None
    mock_commit.return_value = True

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=_make_scan_json()),
        ClaudeResult(success=True, text=_make_fix_json()),
        ClaudeResult(success=True, text=_make_verify_pass_json()),
        ClaudeResult(success=False, error="Report failed"),
    ]

    cfg = PipelineConfig(repo="org/repo", local_path="/tmp/repo", no_pr=True)
    report = run_pipeline(cfg)

    assert report.converged is True
    assert report.summary == ""


# --- PipelineConfig defaults ---


def test_pipeline_config_defaults():
    cfg = PipelineConfig(repo="org/repo")
    assert cfg.max_iterations == 3
    assert cfg.base_branch == "main"
    assert cfg.dry_run is False
    assert cfg.skip_verify is False
    assert cfg.no_pr is False
    assert cfg.timeout_per_step == 600
    assert cfg.branch_name is None
    assert cfg.local_path is None


# --- _run_git_checked ---


@patch("dobbe.core.pipeline._run_git")
def test_run_git_checked_success(mock_git):
    mock_git.return_value = MagicMock(returncode=0, stderr="")
    result = _run_git_checked(["status"], "/tmp/repo")
    assert result.returncode == 0


@patch("dobbe.core.pipeline._run_git")
def test_run_git_checked_raises(mock_git):
    mock_git.return_value = MagicMock(returncode=128, stderr="fatal: not a git repository")
    with pytest.raises(GitError, match="failed.*rc=128"):
        _run_git_checked(["status"], "/tmp/repo")


# --- Git error checking ---


@patch("dobbe.core.pipeline._run_git")
def test_setup_branch_raises_on_checkout_failure(mock_git):
    mock_git.return_value = MagicMock(returncode=1, stderr="error: pathspec 'main' did not match")
    with pytest.raises(GitError, match="checkout main"):
        _setup_branch("/tmp/repo", "fix-branch", "main")


@patch("dobbe.core.pipeline._run_git")
def test_setup_branch_raises_on_branch_create_failure(mock_git):
    def side_effect(args, cwd):
        if args == ["checkout", "main"]:
            return MagicMock(returncode=0, stderr="")
        return MagicMock(returncode=128, stderr="fatal: branch already exists")

    mock_git.side_effect = side_effect
    with pytest.raises(GitError, match="checkout -b"):
        _setup_branch("/tmp/repo", "fix-branch", "main")


@patch("dobbe.core.pipeline._run_git")
def test_revert_to_base_raises_on_failure(mock_git):
    mock_git.return_value = MagicMock(returncode=1, stderr="error: reset failed")
    with pytest.raises(GitError, match="reset --hard"):
        _revert_to_base("/tmp/repo", "main", "fix-branch")


@patch("dobbe.core.pipeline._run_git")
def test_commit_fixes_raises_on_commit_failure(mock_git):
    def side_effect(args, cwd):
        if args[0] == "diff":
            return MagicMock(returncode=1, stderr="")  # changes exist
        if args[0] == "commit":
            return MagicMock(returncode=1, stderr="error: commit failed")
        return MagicMock(returncode=0, stderr="")

    mock_git.side_effect = side_effect
    with pytest.raises(GitError, match="commit"):
        _commit_fixes("/tmp/repo", "fix vulns")


@patch("dobbe.core.pipeline._setup_branch")
@patch("dobbe.core.pipeline._ensure_local_clone")
def test_run_pipeline_handles_branch_setup_failure(mock_clone, mock_branch):
    mock_clone.return_value = ("/tmp/repo", False)
    mock_branch.side_effect = GitError("`git checkout main` failed (rc=1): error")

    cfg = PipelineConfig(repo="org/repo", local_path="/tmp/repo")
    report = run_pipeline(cfg)

    assert report.converged is False
    assert "Branch setup failed" in report.scan_summary


@patch("dobbe.core.pipeline._revert_to_base")
@patch("dobbe.core.pipeline._commit_fixes")
@patch("dobbe.core.pipeline._setup_branch")
@patch("dobbe.core.pipeline._ensure_local_clone")
@patch("dobbe.core.pipeline.ask_claude")
def test_run_pipeline_handles_revert_failure(mock_claude, mock_clone, mock_branch, mock_commit, mock_revert):
    mock_clone.return_value = ("/tmp/repo", False)
    mock_branch.return_value = None
    mock_commit.return_value = True
    mock_revert.side_effect = GitError("reset failed")

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=_make_scan_json()),
        ClaudeResult(success=True, text=_make_fix_json()),
        ClaudeResult(success=True, text=_make_verify_fail_json()),
        ClaudeResult(success=True, text=_make_report_text()),
    ]

    cfg = PipelineConfig(repo="org/repo", local_path="/tmp/repo", max_iterations=3, no_pr=True)
    report = run_pipeline(cfg)

    # Should break out of the loop after revert failure
    assert report.iteration_count == 1


# --- gh pre-flight ---


@patch("dobbe.core.pipeline.shutil.which")
@patch("dobbe.core.pipeline._run_git")
def test_create_pr_gh_not_installed(mock_git, mock_which):
    mock_which.return_value = None
    url = _create_pr("/tmp/repo", "fix-branch", "Fix vulns", "PR body")
    assert url == ""
    mock_git.assert_not_called()  # should not even attempt push


@patch("dobbe.core.pipeline.subprocess.run")
@patch("dobbe.core.pipeline.shutil.which")
@patch("dobbe.core.pipeline._run_git")
def test_create_pr_gh_os_error(mock_git, mock_which, mock_run):
    mock_which.return_value = "/usr/local/bin/gh"
    mock_git.return_value = MagicMock(returncode=0)
    mock_run.side_effect = OSError("Permission denied")
    url = _create_pr("/tmp/repo", "fix-branch", "Fix vulns", "PR body")
    assert url == ""


@patch("dobbe.core.pipeline.shutil.which")
@patch("dobbe.core.pipeline._commit_fixes")
@patch("dobbe.core.pipeline._setup_branch")
@patch("dobbe.core.pipeline._ensure_local_clone")
@patch("dobbe.core.pipeline.ask_claude")
def test_run_pipeline_warns_gh_missing(mock_claude, mock_clone, mock_branch, mock_commit, mock_which):
    mock_which.return_value = None
    mock_clone.return_value = ("/tmp/repo", False)
    mock_branch.return_value = None
    mock_commit.return_value = True

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=_make_scan_json()),
        ClaudeResult(success=True, text=_make_fix_json()),
        ClaudeResult(success=True, text=_make_verify_pass_json()),
        ClaudeResult(success=True, text=_make_report_text()),
    ]

    messages = []
    cfg = PipelineConfig(repo="org/repo", local_path="/tmp/repo")
    run_pipeline(cfg, callbacks=lambda msg: messages.append(msg))

    gh_warnings = [m for m in messages if "gh CLI not found" in m.summary]
    assert len(gh_warnings) == 1


# --- Tempdir cleanup ---


def test_ensure_local_clone_returns_tuple(tmp_path):
    """Verify (path, False) for existing local path."""
    (tmp_path / ".git").mkdir()
    cfg = PipelineConfig(repo="org/repo", local_path=str(tmp_path))
    path, is_tempdir = _ensure_local_clone(cfg)
    assert path == str(tmp_path)
    assert is_tempdir is False


@patch("dobbe.core.pipeline.subprocess.run")
def test_ensure_local_clone_returns_tempdir_flag(mock_run):
    """Verify (path, True) for auto-clone."""
    mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
    cfg = PipelineConfig(repo="org/repo", local_path=None)
    path, is_tempdir = _ensure_local_clone(cfg)
    assert is_tempdir is True


@patch("dobbe.core.pipeline.shutil.rmtree")
@patch("dobbe.core.pipeline.subprocess.run")
def test_ensure_local_clone_cleans_up_on_clone_failure(mock_run, mock_rmtree):
    """Tempdir is cleaned up when clone fails."""
    mock_run.return_value = MagicMock(returncode=1, stdout="", stderr="not found")
    cfg = PipelineConfig(repo="org/repo", local_path=None)
    with pytest.raises(RuntimeError, match="Failed to clone"):
        _ensure_local_clone(cfg)
    mock_rmtree.assert_called_once()


@patch("dobbe.core.pipeline.shutil.rmtree")
@patch("dobbe.core.pipeline._create_pr")
@patch("dobbe.core.pipeline._commit_fixes")
@patch("dobbe.core.pipeline._setup_branch")
@patch("dobbe.core.pipeline._ensure_local_clone")
@patch("dobbe.core.pipeline.ask_claude")
def test_run_pipeline_cleans_up_tempdir(mock_claude, mock_clone, mock_branch, mock_commit, mock_pr, mock_rmtree):
    mock_clone.return_value = ("/tmp/dobbe-abc123", True)
    mock_branch.return_value = None
    mock_commit.return_value = True
    mock_pr.return_value = ""

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=_make_scan_json()),
        ClaudeResult(success=True, text=_make_fix_json()),
        ClaudeResult(success=True, text=_make_verify_pass_json()),
        ClaudeResult(success=True, text=_make_report_text()),
    ]

    cfg = PipelineConfig(repo="org/repo", no_pr=True)
    run_pipeline(cfg)

    mock_rmtree.assert_called_once_with("/tmp/dobbe-abc123", ignore_errors=True)


@patch("dobbe.core.pipeline.shutil.rmtree")
@patch("dobbe.core.pipeline._setup_branch")
@patch("dobbe.core.pipeline._ensure_local_clone")
def test_run_pipeline_cleans_up_on_error(mock_clone, mock_branch, mock_rmtree):
    """Tempdir cleaned up even when pipeline fails mid-run."""
    mock_clone.return_value = ("/tmp/dobbe-abc123", True)
    mock_branch.side_effect = GitError("branch fail")

    cfg = PipelineConfig(repo="org/repo")
    run_pipeline(cfg)

    mock_rmtree.assert_called_once_with("/tmp/dobbe-abc123", ignore_errors=True)


# --- Bug 15: clone timeout cleans tmpdir ---


@patch("dobbe.core.pipeline.subprocess.run")
def test_ensure_local_clone_timeout_cleans_tmpdir(mock_run):
    """TimeoutExpired during clone cleans up tmpdir and raises RuntimeError."""
    mock_run.side_effect = subprocess.TimeoutExpired(cmd="git clone", timeout=120)
    cfg = PipelineConfig(repo="org/repo", local_path=None)
    with pytest.raises(RuntimeError, match="timed out"):
        _ensure_local_clone(cfg)


# --- Bug 16: _run_git timeout ---


@patch("dobbe.core.pipeline.subprocess.run")
def test_run_git_timeout_returns_failure(mock_run):
    """TimeoutExpired in _run_git returns CompletedProcess with rc=-1."""
    mock_run.side_effect = subprocess.TimeoutExpired(cmd="git status", timeout=60)
    result = _run_git(["status"], "/tmp/repo")
    assert result.returncode == -1
    assert "timed out" in result.stderr


@patch("dobbe.core.pipeline.subprocess.run")
def test_run_git_checked_timeout_raises_git_error(mock_run):
    """TimeoutExpired in _run_git propagates as GitError via _run_git_checked."""
    mock_run.side_effect = subprocess.TimeoutExpired(cmd="git push", timeout=60)
    with pytest.raises(GitError, match="timed out"):
        _run_git_checked(["push"], "/tmp/repo")


@patch("dobbe.core.pipeline.shutil.rmtree")
@patch("dobbe.core.pipeline._commit_fixes")
@patch("dobbe.core.pipeline._setup_branch")
@patch("dobbe.core.pipeline._ensure_local_clone")
@patch("dobbe.core.pipeline.ask_claude")
def test_run_pipeline_no_cleanup_for_local_path(mock_claude, mock_clone, mock_branch, mock_commit, mock_rmtree):
    """No rmtree call when using an existing local path (not a tempdir)."""
    mock_clone.return_value = ("/tmp/repo", False)
    mock_branch.return_value = None
    mock_commit.return_value = True

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=_make_scan_json()),
        ClaudeResult(success=True, text=_make_fix_json()),
        ClaudeResult(success=True, text=_make_verify_pass_json()),
        ClaudeResult(success=True, text=_make_report_text()),
    ]

    cfg = PipelineConfig(repo="org/repo", local_path="/tmp/repo", no_pr=True)
    run_pipeline(cfg)

    mock_rmtree.assert_not_called()


# --- scan_summary_from_repo_result ---


def _make_repo_result(groups=None, error=None):
    """Build a RepoResult for testing."""
    return RepoResult(
        repo="org/repo",
        access_mode=AccessMode.REMOTE,
        groups=groups or [],
        error=error,
    )


def _make_alert_group(package_name, alert_numbers, current="1.0.0", target="1.1.0"):
    alerts = [
        TriageResult(
            alert_number=n,
            package_name=package_name,
            severity=Severity.CRITICAL,
            summary=f"Alert {n}",
            affected=True,
            risk_level=Severity.CRITICAL,
            recommended_action="Upgrade",
        )
        for n in alert_numbers
    ]
    return AlertGroup(
        package_name=package_name,
        package_ecosystem="pip",
        current_version=current,
        target_version=target,
        alerts=alerts,
    )


def test_scan_summary_from_repo_result_basic():
    group = _make_alert_group("django", [1, 2])
    rr = _make_repo_result(groups=[group])
    summary = scan_summary_from_repo_result(rr)
    assert "Found 2 alerts across 1 package groups." in summary
    assert "django" in summary
    assert "#1" in summary
    assert "#2" in summary
    assert "upgrade 1.0.0 → 1.1.0" in summary


def test_scan_summary_from_repo_result_with_error():
    rr = _make_repo_result(error="Claude timed out")
    summary = scan_summary_from_repo_result(rr)
    assert summary == "Scan error: Claude timed out"


def test_scan_summary_from_repo_result_no_target():
    group = _make_alert_group("requests", [5], target=None)
    rr = _make_repo_result(groups=[group])
    summary = scan_summary_from_repo_result(rr)
    assert "requests" in summary
    assert "upgrade" not in summary


def test_scan_summary_from_repo_result_empty():
    rr = _make_repo_result(groups=[])
    summary = scan_summary_from_repo_result(rr)
    assert "Found 0 alerts across 0 package groups." in summary


def test_scan_summary_from_repo_result_multiple_groups():
    g1 = _make_alert_group("django", [1, 2])
    g2 = _make_alert_group("requests", [3])
    g3 = _make_alert_group("flask", [4, 5, 6])
    rr = _make_repo_result(groups=[g1, g2, g3])
    summary = scan_summary_from_repo_result(rr)
    assert "Found 6 alerts across 3 package groups." in summary
    assert "django" in summary
    assert "requests" in summary
    assert "flask" in summary


def test_scan_summary_roundtrip_consistency():
    """Build RepoResult, check scan_summary_from_repo_result matches _build_scan_summary."""
    scan_json = _make_scan_json()
    # _build_scan_summary goes: raw text -> parse_triage_response -> format
    summary_from_raw = _build_scan_summary(scan_json, "org/repo")

    # scan_summary_from_repo_result goes: RepoResult -> format
    from dobbe.core.response_parser import parse_triage_response
    repo_result = parse_triage_response(scan_json, "org/repo")
    summary_from_model = scan_summary_from_repo_result(repo_result)

    assert summary_from_raw == summary_from_model


# --- run_pipeline with scan_summary_override ---


@patch("dobbe.core.pipeline._create_pr")
@patch("dobbe.core.pipeline._commit_fixes")
@patch("dobbe.core.pipeline._setup_branch")
@patch("dobbe.core.pipeline._ensure_local_clone")
@patch("dobbe.core.pipeline.ask_claude")
def test_pipeline_with_scan_override_skips_scan_agent(mock_claude, mock_clone, mock_branch, mock_commit, mock_pr):
    mock_clone.return_value = ("/tmp/repo", False)
    mock_branch.return_value = None
    mock_commit.return_value = True
    mock_pr.return_value = ""

    # Only 3 Claude calls: fix, verify, report (NO scan)
    mock_claude.side_effect = [
        ClaudeResult(success=True, text=_make_fix_json()),
        ClaudeResult(success=True, text=_make_verify_pass_json()),
        ClaudeResult(success=True, text=_make_report_text()),
    ]

    cfg = PipelineConfig(
        repo="org/repo",
        local_path="/tmp/repo",
        no_pr=True,
        scan_summary_override="Found 1 alerts across 1 package groups.\n- django: 1 alert(s) [#1] (upgrade 4.2.5 → 4.2.11)",
    )
    report = run_pipeline(cfg)

    assert report.converged is True
    assert mock_claude.call_count == 3  # fix + verify + report, NOT 4


@patch("dobbe.core.pipeline._create_pr")
@patch("dobbe.core.pipeline._commit_fixes")
@patch("dobbe.core.pipeline._setup_branch")
@patch("dobbe.core.pipeline._ensure_local_clone")
@patch("dobbe.core.pipeline.ask_claude")
def test_pipeline_with_scan_override_uses_override_text(mock_claude, mock_clone, mock_branch, mock_commit, mock_pr):
    mock_clone.return_value = ("/tmp/repo", False)
    mock_branch.return_value = None
    mock_commit.return_value = True
    mock_pr.return_value = ""

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=_make_fix_json()),
        ClaudeResult(success=True, text=_make_verify_pass_json()),
        ClaudeResult(success=True, text=_make_report_text()),
    ]

    override = "Found 1 alerts across 1 package groups.\n- django: 1 alert(s) [#1]"
    cfg = PipelineConfig(repo="org/repo", local_path="/tmp/repo", no_pr=True, scan_summary_override=override)
    report = run_pipeline(cfg)

    assert report.scan_summary == override


@patch("dobbe.core.pipeline._create_pr")
@patch("dobbe.core.pipeline._commit_fixes")
@patch("dobbe.core.pipeline._setup_branch")
@patch("dobbe.core.pipeline._ensure_local_clone")
@patch("dobbe.core.pipeline.ask_claude")
def test_pipeline_with_scan_override_emits_message(mock_claude, mock_clone, mock_branch, mock_commit, mock_pr):
    mock_clone.return_value = ("/tmp/repo", False)
    mock_branch.return_value = None
    mock_commit.return_value = True
    mock_pr.return_value = ""

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=_make_fix_json()),
        ClaudeResult(success=True, text=_make_verify_pass_json()),
        ClaudeResult(success=True, text=_make_report_text()),
    ]

    messages = []
    override = "Pre-computed summary"
    cfg = PipelineConfig(repo="org/repo", local_path="/tmp/repo", no_pr=True, scan_summary_override=override)
    run_pipeline(cfg, callbacks=lambda msg: messages.append(msg))

    scan_msgs = [m for m in messages if m.agent == "scan"]
    assert any("Using pre-computed scan" in m.summary for m in scan_msgs)


@patch("dobbe.core.pipeline._setup_branch")
@patch("dobbe.core.pipeline._ensure_local_clone")
@patch("dobbe.core.pipeline.ask_claude")
def test_pipeline_with_scan_override_and_dry_run(mock_claude, mock_clone, mock_branch):
    """Override + dry_run → returns immediately after using override, ask_claude not called."""
    mock_clone.return_value = ("/tmp/repo", False)
    mock_branch.return_value = None

    override = "Pre-computed summary"
    cfg = PipelineConfig(repo="org/repo", local_path="/tmp/repo", dry_run=True, scan_summary_override=override)
    report = run_pipeline(cfg)

    assert report.scan_summary == override
    mock_claude.assert_not_called()


@patch("dobbe.core.pipeline._create_pr")
@patch("dobbe.core.pipeline._commit_fixes")
@patch("dobbe.core.pipeline._setup_branch")
@patch("dobbe.core.pipeline._ensure_local_clone")
@patch("dobbe.core.pipeline.ask_claude")
def test_pipeline_without_override_calls_scan_agent(mock_claude, mock_clone, mock_branch, mock_commit, mock_pr):
    """No override (None) → existing behavior, scan agent called."""
    mock_clone.return_value = ("/tmp/repo", False)
    mock_branch.return_value = None
    mock_commit.return_value = True
    mock_pr.return_value = ""

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=_make_scan_json()),     # scan
        ClaudeResult(success=True, text=_make_fix_json()),      # fix
        ClaudeResult(success=True, text=_make_verify_pass_json()),  # verify
        ClaudeResult(success=True, text=_make_report_text()),   # report
    ]

    cfg = PipelineConfig(repo="org/repo", local_path="/tmp/repo", no_pr=True, scan_summary_override=None)
    report = run_pipeline(cfg)

    assert mock_claude.call_count == 4  # scan + fix + verify + report


# --- PipelineConfig scan_summary_override default ---


def test_pipeline_config_scan_summary_override_default():
    cfg = PipelineConfig(repo="org/repo")
    assert cfg.scan_summary_override is None


# --- scan_report_json_roundtrip integration ---


def test_scan_report_json_roundtrip():
    """Build ScanReport → JSON → parse back → scan_summary_from_repo_result → valid."""
    from dobbe.models.alert import ScanReport

    group = _make_alert_group("django", [1, 2])
    rr = _make_repo_result(groups=[group])
    report = ScanReport(repos=[rr])

    json_str = report.model_dump_json()
    parsed = ScanReport.model_validate_json(json_str)

    summary = scan_summary_from_repo_result(parsed.repos[0])
    assert "django" in summary
    assert "Found 2 alerts" in summary
