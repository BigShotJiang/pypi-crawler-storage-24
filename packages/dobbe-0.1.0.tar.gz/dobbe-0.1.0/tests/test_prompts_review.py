"""Tests for PR review prompt builders."""

from dobbe.core.prompts import (
    build_pr_discovery_prompt,
    build_pr_review_prompt,
    build_review_notify_prompt,
)


# --- build_pr_discovery_prompt ---


def test_discovery_prompt_basic():
    prompt = build_pr_discovery_prompt(repo="org/repo", reviewers=["@me"])
    assert "org/repo" in prompt
    assert "@me" in prompt
    assert "prs" in prompt  # JSON schema reference


def test_discovery_prompt_with_github_mcp():
    prompt = build_pr_discovery_prompt(
        repo="org/repo",
        reviewers=["@me"],
        available_mcps={"github": True},
    )
    assert "GitHub MCP" in prompt
    assert "gh pr list" not in prompt


def test_discovery_prompt_without_github_mcp():
    prompt = build_pr_discovery_prompt(
        repo="org/repo",
        reviewers=["@me"],
        available_mcps={"github": False},
    )
    assert "gh pr list" in prompt
    assert "--reviewer @me" in prompt


def test_discovery_prompt_no_mcps():
    prompt = build_pr_discovery_prompt(
        repo="org/repo",
        reviewers=["alice"],
        available_mcps={},
    )
    assert "gh pr list" in prompt
    assert "--reviewer alice" in prompt


def test_discovery_prompt_multiple_reviewers():
    prompt = build_pr_discovery_prompt(
        repo="org/repo",
        reviewers=["@me", "alice", "bob"],
        available_mcps={"github": False},
    )
    assert "@me" in prompt
    assert "alice" in prompt
    assert "bob" in prompt


def test_discovery_prompt_json_schema():
    prompt = build_pr_discovery_prompt(repo="org/repo", reviewers=["@me"])
    assert '"pr_number"' in prompt
    assert '"title"' in prompt
    assert '"author"' in prompt


# --- build_pr_review_prompt ---


def test_review_prompt_basic():
    prompt = build_pr_review_prompt(
        repo="org/repo",
        pr_number=42,
        title="Fix bug",
        author="alice",
    )
    assert "org/repo" in prompt
    assert "#42" in prompt or "42" in prompt
    assert "Fix bug" in prompt
    assert "alice" in prompt


def test_review_prompt_with_github_mcp():
    prompt = build_pr_review_prompt(
        repo="org/repo",
        pr_number=42,
        title="Fix bug",
        author="alice",
        available_mcps={"github": True},
    )
    assert "GitHub MCP" in prompt
    assert "gh pr diff" not in prompt


def test_review_prompt_without_github_mcp():
    prompt = build_pr_review_prompt(
        repo="org/repo",
        pr_number=42,
        title="Fix bug",
        author="alice",
        available_mcps={"github": False},
    )
    assert "gh pr diff" in prompt


def test_review_prompt_includes_categories():
    prompt = build_pr_review_prompt(
        repo="org/repo",
        pr_number=1,
        title="t",
        author="a",
    )
    assert "security" in prompt.lower()
    assert "test" in prompt.lower()
    assert "breaking" in prompt.lower()
    assert "quality" in prompt.lower()
    assert "complexity" in prompt.lower()


def test_review_prompt_json_schema():
    prompt = build_pr_review_prompt(
        repo="org/repo",
        pr_number=1,
        title="t",
        author="a",
    )
    assert '"risk_level"' in prompt
    assert '"concerns"' in prompt
    assert '"approval_recommendation"' in prompt


def test_review_prompt_with_description():
    prompt = build_pr_review_prompt(
        repo="org/repo",
        pr_number=1,
        title="t",
        author="a",
        description="This PR fixes the login bug",
    )
    assert "This PR fixes the login bug" in prompt


def test_review_prompt_empty_description():
    prompt = build_pr_review_prompt(
        repo="org/repo",
        pr_number=1,
        title="t",
        author="a",
        description="",
    )
    assert "(no description)" in prompt


# --- build_review_notify_prompt ---


def test_review_notify_prompt():
    prompt = build_review_notify_prompt(
        digest_json='{"total_prs": 5}',
        channel="#pr-reviews",
    )
    assert "#pr-reviews" in prompt
    assert "Slack" in prompt
    assert '{"total_prs": 5}' in prompt


# --- line_number in review prompt ---


def test_review_prompt_includes_line_number():
    prompt = build_pr_review_prompt(
        repo="org/repo",
        pr_number=1,
        title="t",
        author="a",
    )
    assert '"line_number"' in prompt


def test_review_prompt_line_number_note():
    prompt = build_pr_review_prompt(
        repo="org/repo",
        pr_number=1,
        title="t",
        author="a",
    )
    assert "line_number should be the line" in prompt


# --- diff_content support ---


def test_review_prompt_with_diff_content():
    diff = "--- a/file.py\n+++ b/file.py\n+new line"
    prompt = build_pr_review_prompt(
        repo="org/repo",
        pr_number=10,
        title="Add feature",
        author="alice",
        diff_content=diff,
    )
    assert diff in prompt
    assert "Review the PR diff provided below" in prompt
    assert "<diff>" in prompt


def test_review_prompt_diff_content_overrides_mcp():
    prompt = build_pr_review_prompt(
        repo="org/repo",
        pr_number=10,
        title="Add feature",
        author="alice",
        diff_content="some diff",
        available_mcps={"github": True},
    )
    assert "GitHub MCP" not in prompt


def test_review_prompt_none_diff_content_uses_mcp():
    prompt = build_pr_review_prompt(
        repo="org/repo",
        pr_number=10,
        title="Add feature",
        author="alice",
        diff_content=None,
        available_mcps={"github": True},
    )
    assert "GitHub MCP" in prompt


def test_review_prompt_empty_diff_content_uses_fallback():
    prompt = build_pr_review_prompt(
        repo="org/repo",
        pr_number=10,
        title="Add feature",
        author="alice",
        diff_content="",
        available_mcps={"github": False},
    )
    assert "gh pr diff" in prompt


# --- discovery prompt label coverage ---


def test_discovery_prompt_includes_labels():
    prompt = build_pr_discovery_prompt(repo="org/repo", reviewers=["@me"])
    assert "labels" in prompt
