"""Tests for review pipeline - fetch, analyze, prioritize."""

from __future__ import annotations

import asyncio
import json
import threading
from datetime import datetime, timedelta
from unittest.mock import AsyncMock, patch

import pytest

from dobbe.core.claude import ClaudeResult
from dobbe.core.review_pipeline import (
    _filter_prs,
    _prioritize_results,
    run_review_digest,
    run_review_post,
)
from dobbe.models.review import PRInfo, PRReviewResult, ReviewDigest
from dobbe.models.shared import Severity


def _make_discovery_json(*prs):
    """Build a discovery response JSON with given PR dicts."""
    return json.dumps({"prs": list(prs)})


def _make_pr_dict(number=1, title="PR", author="alice", age_days=3):
    created = (datetime.now() - timedelta(days=age_days)).isoformat()
    return {
        "pr_number": number,
        "title": title,
        "author": author,
        "url": f"https://github.com/org/repo/pull/{number}",
        "created_at": created,
        "updated_at": datetime.now().isoformat(),
    }


def _make_review_json(risk_level="medium", summary="OK", recommendation="approve"):
    return json.dumps({
        "risk_level": risk_level,
        "summary": summary,
        "concerns": [],
        "recommendations": [],
        "estimated_review_time": "10 min",
        "approval_recommendation": recommendation,
    })


# --- _prioritize_results ---


def _make_result(risk: Severity, age_days: int = 3) -> PRReviewResult:
    pr = PRInfo(
        repo="org/repo",
        pr_number=1,
        title="PR",
        author="a",
        url="u",
        created_at=datetime.now() - timedelta(days=age_days),
        updated_at=datetime.now(),
    )
    return PRReviewResult(pr=pr, risk_level=risk, summary="Test")


def test_prioritize_by_risk():
    results = [
        _make_result(Severity.LOW),
        _make_result(Severity.CRITICAL),
        _make_result(Severity.HIGH),
    ]
    sorted_results = _prioritize_results(results)
    assert sorted_results[0].risk_level == Severity.CRITICAL
    assert sorted_results[1].risk_level == Severity.HIGH
    assert sorted_results[2].risk_level == Severity.LOW


def test_prioritize_by_age_within_risk():
    results = [
        _make_result(Severity.HIGH, age_days=1),
        _make_result(Severity.HIGH, age_days=10),
        _make_result(Severity.HIGH, age_days=5),
    ]
    sorted_results = _prioritize_results(results)
    # Oldest first within same risk
    assert sorted_results[0].pr.age_days == 10
    assert sorted_results[1].pr.age_days == 5
    assert sorted_results[2].pr.age_days == 1


def test_prioritize_empty():
    assert _prioritize_results([]) == []


def test_prioritize_single():
    r = _make_result(Severity.MEDIUM)
    assert _prioritize_results([r]) == [r]


# --- run_review_digest ---


@patch("dobbe.core.review_pipeline.ask_claude_async")
def test_run_digest_single_repo(mock_claude):
    discovery_json = _make_discovery_json(_make_pr_dict())
    review_json = _make_review_json(risk_level="high", summary="Needs review")

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=discovery_json),
        ClaudeResult(success=True, text=review_json),
    ]

    digest = asyncio.run(run_review_digest(
        repos=["org/repo"],
        reviewers=["@me"],
        available_mcps={"github": False},
    ))

    assert isinstance(digest, ReviewDigest)
    assert digest.total_prs == 1
    assert digest.results[0].risk_level == Severity.HIGH
    assert digest.repos_scanned == ["org/repo"]
    assert digest.reviewers == ["@me"]
    assert digest.errors == []


@patch("dobbe.core.review_pipeline.ask_claude_async")
def test_run_digest_multiple_repos(mock_claude):
    discovery1 = _make_discovery_json(_make_pr_dict(number=1))
    discovery2 = _make_discovery_json(_make_pr_dict(number=2))
    review1 = _make_review_json(risk_level="critical")
    review2 = _make_review_json(risk_level="low")

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=discovery1),
        ClaudeResult(success=True, text=discovery2),
        ClaudeResult(success=True, text=review1),
        ClaudeResult(success=True, text=review2),
    ]

    digest = asyncio.run(run_review_digest(
        repos=["org/repo1", "org/repo2"],
        reviewers=["@me"],
        available_mcps={},
    ))

    assert digest.total_prs == 2
    # Critical should be first after prioritization
    assert digest.results[0].risk_level == Severity.CRITICAL


@patch("dobbe.core.review_pipeline.ask_claude_async")
def test_run_digest_no_prs(mock_claude):
    mock_claude.return_value = ClaudeResult(success=True, text='{"prs": []}')

    digest = asyncio.run(run_review_digest(
        repos=["org/repo"],
        reviewers=["@me"],
        available_mcps={},
    ))

    assert digest.total_prs == 0
    assert digest.results == []
    assert digest.errors == []


@patch("dobbe.core.review_pipeline.ask_claude_async")
def test_run_digest_fetch_failure(mock_claude):
    mock_claude.return_value = ClaudeResult(success=False, error="Claude down")

    digest = asyncio.run(run_review_digest(
        repos=["org/repo"],
        reviewers=["@me"],
        available_mcps={},
    ))

    assert digest.total_prs == 0
    assert len(digest.errors) == 1
    assert "Failed to fetch PRs" in digest.errors[0]


@patch("dobbe.core.review_pipeline.ask_claude_async")
def test_run_digest_analysis_failure(mock_claude):
    discovery = _make_discovery_json(_make_pr_dict())

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=discovery),
        ClaudeResult(success=False, error="Analysis timed out"),
    ]

    digest = asyncio.run(run_review_digest(
        repos=["org/repo"],
        reviewers=["@me"],
        available_mcps={},
    ))

    assert digest.total_prs == 1
    assert digest.results[0].analysis_error is not None
    assert "Analysis timed out" in digest.results[0].analysis_error


@patch("dobbe.core.review_pipeline.ask_claude_async")
def test_run_digest_partial_failure(mock_claude):
    """One repo succeeds, one fails - digest includes both."""
    discovery1 = _make_discovery_json(_make_pr_dict(number=1))

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=discovery1),
        ClaudeResult(success=False, error="Repo2 failed"),
        ClaudeResult(success=True, text=_make_review_json()),
    ]

    digest = asyncio.run(run_review_digest(
        repos=["org/repo1", "org/repo2"],
        reviewers=["@me"],
        available_mcps={},
    ))

    assert digest.total_prs == 1
    assert len(digest.errors) == 1


@patch("dobbe.core.review_pipeline.ask_claude_async")
def test_run_digest_stale_days(mock_claude):
    old_pr = _make_pr_dict(number=1, age_days=15)
    fresh_pr = _make_pr_dict(number=2, age_days=2)
    discovery = _make_discovery_json(old_pr, fresh_pr)

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=discovery),
        ClaudeResult(success=True, text=_make_review_json()),
        ClaudeResult(success=True, text=_make_review_json()),
    ]

    digest = asyncio.run(run_review_digest(
        repos=["org/repo"],
        reviewers=["@me"],
        available_mcps={},
        stale_days=7,
    ))

    assert digest.stale_days == 7
    assert digest.total_prs == 2
    assert len(digest.stale_prs) == 1


@patch("dobbe.core.review_pipeline.ask_claude_async")
def test_run_digest_malformed_review_response(mock_claude):
    discovery = _make_discovery_json(_make_pr_dict())

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=discovery),
        ClaudeResult(success=True, text="Not valid JSON at all"),
    ]

    digest = asyncio.run(run_review_digest(
        repos=["org/repo"],
        reviewers=["@me"],
        available_mcps={},
    ))

    assert digest.total_prs == 1
    assert digest.results[0].analysis_error is not None


@patch("dobbe.core.review_pipeline.ask_claude_async")
def test_run_digest_respects_max_concurrent(mock_claude):
    """Ensure semaphore is used (no crash with many repos)."""
    discovery = _make_discovery_json(_make_pr_dict())
    review = _make_review_json()

    mock_claude.return_value = ClaudeResult(success=True, text=discovery)
    # After discovery, each PR triggers a review call
    call_count = 0

    async def _mock_call(*args, **kwargs):
        nonlocal call_count
        call_count += 1
        if call_count <= 3:
            return ClaudeResult(success=True, text=discovery)
        return ClaudeResult(success=True, text=review)

    mock_claude.side_effect = _mock_call

    digest = asyncio.run(run_review_digest(
        repos=["org/r1", "org/r2", "org/r3"],
        reviewers=["@me"],
        available_mcps={},
        max_concurrent=2,
    ))

    assert isinstance(digest, ReviewDigest)


# --- _filter_prs ---


def _make_pr_info(
    pr_number=1, title="PR", author="alice", labels=None, draft=False,
):
    """Build a PRInfo for filter tests."""
    return PRInfo(
        repo="org/repo",
        pr_number=pr_number,
        title=title,
        author=author,
        url=f"https://github.com/org/repo/pull/{pr_number}",
        created_at=datetime.now(),
        updated_at=datetime.now(),
        labels=labels or [],
        draft=draft,
    )


def test_filter_prs_skip_labels():
    prs = [
        _make_pr_info(pr_number=1, labels=["wip"]),
        _make_pr_info(pr_number=2, labels=["ready"]),
    ]
    filtered = _filter_prs(prs, skip_labels=["wip"], skip_drafts=False)
    assert len(filtered) == 1
    assert filtered[0].pr_number == 2


def test_filter_prs_skip_authors():
    prs = [
        _make_pr_info(pr_number=1, author="dependabot[bot]"),
        _make_pr_info(pr_number=2, author="alice"),
    ]
    filtered = _filter_prs(prs, skip_authors=["dependabot[bot]"], skip_drafts=False)
    assert len(filtered) == 1
    assert filtered[0].author == "alice"


def test_filter_prs_skip_drafts():
    prs = [
        _make_pr_info(pr_number=1, draft=True),
        _make_pr_info(pr_number=2, draft=False),
    ]
    filtered = _filter_prs(prs, skip_drafts=True)
    assert len(filtered) == 1
    assert filtered[0].pr_number == 2


def test_filter_prs_no_filters():
    prs = [
        _make_pr_info(pr_number=1),
        _make_pr_info(pr_number=2),
    ]
    filtered = _filter_prs(prs, skip_drafts=False)
    assert len(filtered) == 2


def test_filter_prs_case_insensitive_labels():
    prs = [_make_pr_info(pr_number=1, labels=["WIP"])]
    filtered = _filter_prs(prs, skip_labels=["wip"], skip_drafts=False)
    assert len(filtered) == 0


# --- Digest diff pre-fetch ---


def _make_pr_dict_with_labels(number=1, title="PR", author="alice", age_days=3, labels=None):
    """Build a discovery PR dict that includes labels."""
    created = (datetime.now() - timedelta(days=age_days)).isoformat()
    return {
        "pr_number": number,
        "title": title,
        "author": author,
        "url": f"https://github.com/org/repo/pull/{number}",
        "created_at": created,
        "updated_at": datetime.now().isoformat(),
        "labels": labels or [],
    }


@patch("dobbe.core.review_pipeline.fetch_pr_diff")
@patch("dobbe.core.review_pipeline.ask_claude_async")
def test_run_digest_with_skip_labels(mock_claude, mock_diff):
    discovery = _make_discovery_json(
        _make_pr_dict_with_labels(number=1, labels=["wip"]),
        _make_pr_dict_with_labels(number=2, labels=["ready"]),
    )
    review = _make_review_json()

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=discovery),
        ClaudeResult(success=True, text=review),
    ]
    mock_diff.return_value = ("diff content", None)

    digest = asyncio.run(run_review_digest(
        repos=["org/repo"],
        reviewers=["@me"],
        available_mcps={},
        skip_labels=["wip"],
    ))

    assert digest.total_prs == 1
    assert digest.results[0].pr.pr_number == 2


@patch("dobbe.core.review_pipeline.fetch_pr_diff")
@patch("dobbe.core.review_pipeline.ask_claude_async")
def test_run_digest_with_skip_authors(mock_claude, mock_diff):
    discovery = _make_discovery_json(
        _make_pr_dict_with_labels(number=1, author="bot"),
        _make_pr_dict_with_labels(number=2, author="alice"),
    )
    review = _make_review_json()

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=discovery),
        ClaudeResult(success=True, text=review),
    ]
    mock_diff.return_value = ("diff content", None)

    digest = asyncio.run(run_review_digest(
        repos=["org/repo"],
        reviewers=["@me"],
        available_mcps={},
        skip_authors=["bot"],
    ))

    assert digest.total_prs == 1
    assert digest.results[0].pr.author == "alice"


@patch("dobbe.core.review_pipeline.fetch_pr_diff")
@patch("dobbe.core.review_pipeline.ask_claude_async")
def test_run_digest_diff_passed_to_analysis(mock_claude, mock_diff):
    discovery = _make_discovery_json(_make_pr_dict(number=1))
    review = _make_review_json()

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=discovery),
        ClaudeResult(success=True, text=review),
    ]
    mock_diff.return_value = ("diff --git a/file.py b/file.py\n+new line", None)

    asyncio.run(run_review_digest(
        repos=["org/repo"],
        reviewers=["@me"],
        available_mcps={},
    ))

    # The second call to ask_claude_async is the analysis call
    assert mock_claude.call_count == 2
    analysis_call_prompt = mock_claude.call_args_list[1][1].get(
        "prompt", mock_claude.call_args_list[1][0][0] if mock_claude.call_args_list[1][0] else ""
    )
    assert "<diff>" in analysis_call_prompt


@patch("dobbe.core.review_pipeline.fetch_pr_diff")
@patch("dobbe.core.review_pipeline.ask_claude_async")
def test_run_digest_gather_exception_resilience(mock_claude, mock_diff):
    """If a coroutine in gather raises, pipeline degrades gracefully."""
    discovery = _make_discovery_json(_make_pr_dict(number=1))

    call_count = 0

    async def _mock_claude(*args, **kwargs):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return ClaudeResult(success=True, text=discovery)
        raise OSError("Subprocess exploded")

    mock_claude.side_effect = _mock_claude
    mock_diff.return_value = ("diff content", None)

    digest = asyncio.run(run_review_digest(
        repos=["org/repo"],
        reviewers=["@me"],
        available_mcps={},
    ))

    assert digest.total_prs == 1
    assert digest.results[0].analysis_error is not None
    assert "Analysis failed" in digest.results[0].analysis_error


@patch("dobbe.core.review_pipeline.fetch_pr_diff")
@patch("dobbe.core.review_pipeline.ask_claude_async")
def test_run_digest_diff_failure_graceful(mock_claude, mock_diff):
    discovery = _make_discovery_json(_make_pr_dict(number=1))
    review = _make_review_json()

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=discovery),
        ClaudeResult(success=True, text=review),
    ]
    mock_diff.return_value = ("", "Failed to fetch diff")

    digest = asyncio.run(run_review_digest(
        repos=["org/repo"],
        reviewers=["@me"],
        available_mcps={},
    ))

    assert digest.total_prs == 1
    assert digest.results[0].pr.pr_number == 1
    assert digest.errors == []


# --- asyncio.to_thread wrapping ---


@patch("dobbe.core.review_pipeline.fetch_pr_diff")
@patch("dobbe.core.review_pipeline.ask_claude_async")
def test_run_digest_diff_fetch_runs_in_thread(mock_claude, mock_diff):
    """Diff fetches run in a thread pool via asyncio.to_thread, not blocking the event loop."""
    discovery = _make_discovery_json(_make_pr_dict(number=1))
    review = _make_review_json()

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=discovery),
        ClaudeResult(success=True, text=review),
    ]

    call_threads: list[str] = []

    def track_thread(*args, **kwargs):
        call_threads.append(threading.current_thread().name)
        return ("diff content", None)

    mock_diff.side_effect = track_thread

    asyncio.run(run_review_digest(
        repos=["org/repo"],
        reviewers=["@me"],
        available_mcps={},
    ))

    assert len(call_threads) == 1
    assert call_threads[0] != threading.main_thread().name


# --- on_progress callback tests ---


@patch("dobbe.core.review_pipeline.fetch_pr_diff")
@patch("dobbe.core.review_pipeline.ask_claude_async")
def test_run_digest_emits_progress_callbacks(mock_claude, mock_diff):
    """on_progress callback is called at each pipeline phase."""
    discovery = _make_discovery_json(_make_pr_dict(number=1))
    review = _make_review_json()

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=discovery),
        ClaudeResult(success=True, text=review),
    ]
    mock_diff.return_value = ("diff content", None)

    calls: list[dict] = []

    def _track(**kwargs):
        calls.append(kwargs)

    asyncio.run(run_review_digest(
        repos=["org/repo"],
        reviewers=["@me"],
        available_mcps={},
        on_progress=_track,
    ))

    # Should have callbacks for all 5 phases
    phases = [c["phase"] for c in calls]
    assert "Fetching PRs" in phases
    assert "Filtering PRs" in phases
    assert "Pre-fetching diffs" in phases
    assert "Analyzing PRs" in phases
    assert "Prioritizing results" in phases


@patch("dobbe.core.review_pipeline.fetch_pr_diff")
@patch("dobbe.core.review_pipeline.ask_claude_async")
def test_run_digest_progress_includes_phase_numbers(mock_claude, mock_diff):
    """Callbacks include phase numbers."""
    discovery = _make_discovery_json(_make_pr_dict(number=1))
    review = _make_review_json()

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=discovery),
        ClaudeResult(success=True, text=review),
    ]
    mock_diff.return_value = ("diff content", None)

    calls: list[dict] = []

    def _track(**kwargs):
        calls.append(kwargs)

    asyncio.run(run_review_digest(
        repos=["org/repo"],
        reviewers=["@me"],
        available_mcps={},
        on_progress=_track,
    ))

    phase_numbers = [c.get("phase_number") for c in calls if c.get("phase_number")]
    assert 1 in phase_numbers
    assert 5 in phase_numbers


@patch("dobbe.core.review_pipeline.fetch_pr_diff")
@patch("dobbe.core.review_pipeline.ask_claude_async")
def test_run_digest_progress_tracks_repos(mock_claude, mock_diff):
    """Callbacks include per-repo status updates."""
    discovery = _make_discovery_json(_make_pr_dict(number=1))
    review = _make_review_json()

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=discovery),
        ClaudeResult(success=True, text=review),
    ]
    mock_diff.return_value = ("diff content", None)

    calls: list[dict] = []

    def _track(**kwargs):
        calls.append(kwargs)

    asyncio.run(run_review_digest(
        repos=["org/repo"],
        reviewers=["@me"],
        available_mcps={},
        on_progress=_track,
    ))

    repo_calls = [c for c in calls if c.get("repo") == "org/repo"]
    assert len(repo_calls) >= 1


# --- Bug 17b: on_progress exception doesn't crash pipeline ---


@patch("dobbe.core.review_pipeline.fetch_pr_diff")
@patch("dobbe.core.review_pipeline.ask_claude_async")
def test_review_digest_callback_exception_ignored(mock_claude, mock_diff):
    """An exception in on_progress callback doesn't crash the pipeline."""
    discovery = _make_discovery_json(_make_pr_dict(number=1))
    review = _make_review_json()

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=discovery),
        ClaudeResult(success=True, text=review),
    ]
    mock_diff.return_value = ("diff content", None)

    def _exploding_callback(**kwargs):
        raise RuntimeError("Callback exploded!")

    digest = asyncio.run(run_review_digest(
        repos=["org/repo"],
        reviewers=["@me"],
        available_mcps={},
        on_progress=_exploding_callback,
    ))

    assert isinstance(digest, ReviewDigest)
    assert digest.total_prs == 1


@patch("dobbe.core.review_pipeline.ask_claude_async")
def test_run_digest_no_progress_callback(mock_claude):
    """Pipeline works fine with no on_progress callback."""
    mock_claude.return_value = ClaudeResult(success=True, text='{"prs": []}')

    digest = asyncio.run(run_review_digest(
        repos=["org/repo"],
        reviewers=["@me"],
        available_mcps={},
        on_progress=None,
    ))

    assert digest.total_prs == 0


@patch("dobbe.core.review_pipeline.fetch_pr_metadata")
@patch("dobbe.core.review_pipeline.ask_claude_async")
def test_review_post_callback_exception_ignored(mock_claude, mock_meta):
    """An exception in on_progress callback doesn't crash run_review_post."""
    from dobbe.models.review import ReviewPostReport

    mock_claude.return_value = ClaudeResult(success=True, text='{"prs": []}')

    def _exploding_callback(**kwargs):
        raise RuntimeError("Callback exploded!")

    report = asyncio.run(run_review_post(
        repos=["org/repo"],
        pr_number=None,
        reviewers=["@me"],
        available_mcps={},
        dry_run=True,
        on_progress=_exploding_callback,
    ))

    assert isinstance(report, ReviewPostReport)
