"""Edge-case tests for response_parser - None inputs, null JSON fields, string booleans."""

from __future__ import annotations

import json

from dobbe.core.response_parser import (
    extract_json_from_response,
    parse_fix_response,
    parse_pr_list_response,
    parse_review_response,
    parse_triage_response,
    parse_verify_response,
)
from dobbe.models.review import PRInfo
from dobbe.models.shared import Severity

from datetime import datetime, timedelta


def _make_pr_info() -> PRInfo:
    return PRInfo(
        repo="org/repo",
        pr_number=42,
        title="Fix bug",
        author="alice",
        url="https://github.com/org/repo/pull/42",
        created_at=datetime.now() - timedelta(days=3),
        updated_at=datetime.now(),
    )


# --- Bug 1: extract_json_from_response(None) ---


def test_extract_json_none_input():
    assert extract_json_from_response(None) is None


def test_extract_json_empty_string():
    assert extract_json_from_response("") is None


# --- Bug 2: JSON null for list fields ---


def test_parse_triage_null_groups():
    text = json.dumps({"groups": None})
    result = parse_triage_response(text, "org/repo")
    assert result.groups == []


def test_parse_triage_none_input():
    result = parse_triage_response("", "org/repo")
    assert result.error is not None


def test_parse_fix_null_fixes():
    text = json.dumps({"fixes": None, "skipped": None, "diff_summary": ""})
    result = parse_fix_response(text, "org/repo", "b", "main")
    assert result.fixes == []
    assert result.skipped == []


def test_parse_fix_null_skipped():
    text = json.dumps({"fixes": [], "skipped": None})
    result = parse_fix_response(text, "org/repo", "b", "main")
    assert result.skipped == []


def test_parse_fix_null_alerts_addressed():
    text = json.dumps({
        "fixes": [{
            "package_name": "pkg",
            "file_modified": "f",
            "old_version": "1",
            "new_version": "2",
            "alerts_addressed": None,
            "status": "applied",
        }],
        "skipped": [],
    })
    result = parse_fix_response(text, "org/repo", "b", "main")
    assert result.fixes[0].alerts_addressed == []


def test_parse_verify_null_issues():
    text = json.dumps({"passed": True, "issues": None})
    result = parse_verify_response(text, "org/repo")
    assert result.passed is True
    assert result.issues == []


def test_parse_review_null_concerns():
    text = json.dumps({"risk_level": "low", "summary": "OK", "concerns": None, "recommendations": None})
    result = parse_review_response(text, _make_pr_info())
    assert result.concerns == []
    assert result.recommendations == []


def test_parse_pr_list_null_prs():
    text = json.dumps({"prs": None})
    result = parse_pr_list_response(text, "org/repo")
    assert result == []


def test_parse_pr_list_null_labels():
    text = json.dumps({
        "prs": [{
            "pr_number": 1,
            "title": "PR",
            "author": "a",
            "url": "u",
            "created_at": "2024-01-15T10:30:00Z",
            "updated_at": "2024-01-16T12:00:00Z",
            "labels": None,
        }]
    })
    result = parse_pr_list_response(text, "org/repo")
    assert len(result) == 1
    assert result[0].labels == []


# --- Bug 3: string "false" for passed ---


def test_parse_verify_string_false():
    text = json.dumps({"passed": "false", "issues": []})
    result = parse_verify_response(text, "org/repo")
    assert result.passed is False


def test_parse_verify_string_true():
    text = json.dumps({"passed": "true", "issues": []})
    result = parse_verify_response(text, "org/repo")
    assert result.passed is True


def test_parse_verify_string_no():
    text = json.dumps({"passed": "no", "issues": []})
    result = parse_verify_response(text, "org/repo")
    assert result.passed is False


def test_parse_verify_string_zero():
    text = json.dumps({"passed": "0", "issues": []})
    result = parse_verify_response(text, "org/repo")
    assert result.passed is False


def test_parse_verify_string_yes():
    text = json.dumps({"passed": "yes", "issues": []})
    result = parse_verify_response(text, "org/repo")
    assert result.passed is True


# --- Bug 4: non-dict entries in groups array ---


def test_parse_triage_non_dict_groups():
    text = json.dumps({
        "groups": [
            "not a dict",
            42,
            {
                "package_name": "django",
                "alerts": [{
                    "alert_number": 1,
                    "package_name": "django",
                    "severity": "high",
                    "summary": "Vuln",
                    "affected": True,
                    "risk_level": "high",
                    "recommended_action": "Upgrade",
                }],
            },
        ]
    })
    result = parse_triage_response(text, "org/repo")
    assert len(result.groups) == 1
    assert result.groups[0].package_name == "django"
