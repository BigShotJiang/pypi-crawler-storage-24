"""Tests for Pydantic models and computed properties."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from dobbe.models.alert import (
    AccessMode,
    Alert,
    AlertGroup,
    RepoResult,
    ScanReport,
    Severity,
    TriageResult,
)


# --- Enums ---


def test_severity_values():
    assert Severity("critical") == Severity.CRITICAL
    assert Severity("high") == Severity.HIGH
    assert Severity("medium") == Severity.MEDIUM
    assert Severity("low") == Severity.LOW


def test_severity_invalid_raises():
    with pytest.raises(ValueError):
        Severity("bogus")


def test_access_mode_values():
    assert AccessMode("local") == AccessMode.LOCAL
    assert AccessMode("remote") == AccessMode.REMOTE


# --- Alert ---


def test_alert_minimal_construction():
    a = Alert(number=1, package_name="django", severity=Severity.CRITICAL)
    assert a.number == 1
    assert a.state == "open"
    assert a.cve_id is None
    assert a.package_ecosystem == ""


def test_alert_full_construction():
    a = Alert(
        number=42,
        state="dismissed",
        cve_id="CVE-2024-0001",
        ghsa_id="GHSA-xxxx",
        package_name="django",
        package_ecosystem="pip",
        vulnerable_version_range="<4.2.8",
        patched_version="4.2.8",
        severity=Severity.HIGH,
        summary="XSS bug",
        description="Full description",
        url="https://github.com/advisories/GHSA-xxxx",
    )
    assert a.state == "dismissed"
    assert a.ghsa_id == "GHSA-xxxx"


# --- TriageResult ---


def test_triage_result_required_fields_only():
    t = TriageResult(
        alert_number=1,
        package_name="django",
        severity=Severity.CRITICAL,
        summary="SQL injection",
        affected=True,
        risk_level=Severity.CRITICAL,
        recommended_action="Upgrade",
    )
    assert t.cve_id is None
    assert t.evidence == ""


def test_triage_result_missing_required_raises():
    with pytest.raises(ValidationError):
        TriageResult(
            alert_number=1,
            severity=Severity.CRITICAL,
            summary="SQL injection",
            affected=True,
            risk_level=Severity.CRITICAL,
            recommended_action="Upgrade",
            # missing package_name
        )


def test_triage_result_from_dict():
    data = {
        "alert_number": 1,
        "cve_id": "CVE-2024-0001",
        "package_name": "django",
        "severity": "critical",
        "summary": "SQL injection",
        "affected": True,
        "risk_level": "critical",
        "recommended_action": "Upgrade",
    }
    t = TriageResult(**data)
    assert t.severity == Severity.CRITICAL
    assert t.package_name == "django"


# --- AlertGroup properties ---


def test_alert_group_max_risk_critical(sample_triage_result, sample_triage_result_safe):
    group = AlertGroup(
        package_name="django",
        alerts=[sample_triage_result, sample_triage_result_safe],
    )
    assert group.max_risk == Severity.CRITICAL


def test_alert_group_max_risk_empty():
    group = AlertGroup(package_name="empty")
    assert group.max_risk == Severity.LOW


def test_alert_group_all_safe_to_ignore_true(sample_triage_result_safe):
    group = AlertGroup(package_name="safe", alerts=[sample_triage_result_safe])
    assert group.all_safe_to_ignore is True


def test_alert_group_all_safe_to_ignore_mixed(sample_triage_result, sample_triage_result_safe):
    group = AlertGroup(
        package_name="mixed",
        alerts=[sample_triage_result, sample_triage_result_safe],
    )
    assert group.all_safe_to_ignore is False


def test_alert_group_all_safe_to_ignore_empty():
    group = AlertGroup(package_name="empty")
    assert group.all_safe_to_ignore is True


# --- RepoResult + ScanReport properties ---


def test_repo_result_counts(sample_repo_result):
    assert sample_repo_result.total_alerts == 2
    assert sample_repo_result.affected_count == 1
    assert sample_repo_result.safe_to_ignore_count == 1


def test_scan_report_stats_by_severity(sample_scan_report):
    stats = sample_scan_report.stats_by_severity
    assert stats.get(Severity.CRITICAL) == 1
    assert stats.get(Severity.LOW) == 1


def test_scan_report_empty(empty_scan_report):
    assert empty_scan_report.total_alerts == 0
    assert empty_scan_report.total_affected == 0
    assert empty_scan_report.total_safe_to_ignore == 0
    assert empty_scan_report.stats_by_severity == {}
