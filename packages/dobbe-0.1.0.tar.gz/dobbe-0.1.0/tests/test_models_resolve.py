"""Tests for resolve pipeline models - construction, validation, properties."""

from __future__ import annotations

from datetime import datetime

import pytest
from pydantic import ValidationError

from dobbe.models.resolve import (
    AgentMessage,
    ConversationLog,
    FixAction,
    FixResult,
    PipelineIteration,
    ResolveReport,
    SkippedFix,
    VerifyIssue,
    VerifyResult,
)
from dobbe.models.shared import FixStatus, Severity, VerifyCategory


# --- Enums ---


def test_fix_status_values():
    assert FixStatus("applied") == FixStatus.APPLIED
    assert FixStatus("skipped") == FixStatus.SKIPPED
    assert FixStatus("failed") == FixStatus.FAILED


def test_fix_status_invalid_raises():
    with pytest.raises(ValueError):
        FixStatus("bogus")


def test_verify_category_values():
    assert VerifyCategory("test_failure") == VerifyCategory.TEST_FAILURE
    assert VerifyCategory("breaking_change") == VerifyCategory.BREAKING_CHANGE
    assert VerifyCategory("lockfile_inconsistency") == VerifyCategory.LOCKFILE_INCONSISTENCY
    assert VerifyCategory("dependency_conflict") == VerifyCategory.DEPENDENCY_CONFLICT
    assert VerifyCategory("other") == VerifyCategory.OTHER


def test_verify_category_invalid_raises():
    with pytest.raises(ValueError):
        VerifyCategory("bogus")


# --- FixAction ---


def test_fix_action_minimal():
    fa = FixAction(
        package_name="django",
        file_modified="requirements.txt",
        old_version="4.2.5",
        new_version="4.2.11",
    )
    assert fa.package_name == "django"
    assert fa.alerts_addressed == []
    assert fa.status == FixStatus.APPLIED


def test_fix_action_full():
    fa = FixAction(
        package_name="requests",
        file_modified="requirements.txt",
        old_version="2.28.0",
        new_version="2.31.0",
        alerts_addressed=[1, 2, 3],
        status=FixStatus.APPLIED,
    )
    assert fa.alerts_addressed == [1, 2, 3]
    assert fa.status == FixStatus.APPLIED


def test_fix_action_missing_required_raises():
    with pytest.raises(ValidationError):
        FixAction(file_modified="x", old_version="1", new_version="2")


# --- SkippedFix ---


def test_skipped_fix_construction():
    sf = SkippedFix(
        package_name="numpy",
        reason="Major version bump required",
        alerts_skipped=[4, 5],
    )
    assert sf.package_name == "numpy"
    assert sf.reason == "Major version bump required"
    assert sf.alerts_skipped == [4, 5]


def test_skipped_fix_defaults():
    sf = SkippedFix(package_name="pkg", reason="no fix")
    assert sf.alerts_skipped == []


# --- FixResult ---


def test_fix_result_minimal():
    fr = FixResult(repo="org/repo", branch="fix-branch", base_branch="main")
    assert fr.fixes == []
    assert fr.skipped == []
    assert fr.diff_summary == ""


def test_fix_result_with_fixes():
    fix = FixAction(package_name="django", file_modified="req.txt", old_version="4.2.5", new_version="4.2.11")
    skip = SkippedFix(package_name="numpy", reason="major bump")
    fr = FixResult(
        repo="org/repo",
        branch="fix-branch",
        base_branch="main",
        fixes=[fix],
        skipped=[skip],
        diff_summary="Updated django",
    )
    assert len(fr.fixes) == 1
    assert len(fr.skipped) == 1
    assert fr.diff_summary == "Updated django"


# --- VerifyIssue ---


def test_verify_issue_construction():
    vi = VerifyIssue(
        category=VerifyCategory.TEST_FAILURE,
        severity=Severity.HIGH,
        description="test_api.py::test_timeout fails",
        suggestion="Pin requests to 2.30.x",
    )
    assert vi.category == VerifyCategory.TEST_FAILURE
    assert vi.severity == Severity.HIGH
    assert vi.suggestion == "Pin requests to 2.30.x"


def test_verify_issue_defaults():
    vi = VerifyIssue(
        category=VerifyCategory.OTHER,
        severity=Severity.LOW,
        description="Minor warning",
    )
    assert vi.suggestion == ""


# --- VerifyResult ---


def test_verify_result_passed():
    vr = VerifyResult(passed=True)
    assert vr.passed is True
    assert vr.issues == []
    assert vr.feedback == ""


def test_verify_result_failed():
    issue = VerifyIssue(
        category=VerifyCategory.TEST_FAILURE,
        severity=Severity.HIGH,
        description="Tests failed",
    )
    vr = VerifyResult(
        passed=False,
        issues=[issue],
        test_output="FAILED 1 test",
        feedback="Fix the timeout test",
    )
    assert vr.passed is False
    assert len(vr.issues) == 1
    assert vr.feedback == "Fix the timeout test"


# --- PipelineIteration ---


def test_pipeline_iteration_construction():
    fr = FixResult(repo="org/repo", branch="b", base_branch="main")
    vr = VerifyResult(passed=True)
    pi = PipelineIteration(iteration=1, fix_result=fr, verify_result=vr)
    assert pi.iteration == 1
    assert pi.verify_result is not None
    assert pi.verify_result.passed is True


def test_pipeline_iteration_no_verify():
    fr = FixResult(repo="org/repo", branch="b", base_branch="main")
    pi = PipelineIteration(iteration=1, fix_result=fr)
    assert pi.verify_result is None


# --- AgentMessage ---


def test_agent_message_construction():
    msg = AgentMessage(
        agent="scan",
        icon="\U0001f50d",
        summary="Found 5 alerts",
    )
    assert msg.agent == "scan"
    assert msg.iteration is None
    assert isinstance(msg.timestamp, datetime)


def test_agent_message_with_iteration():
    msg = AgentMessage(
        agent="fix",
        icon="\U0001f527",
        iteration=2,
        summary="Applied 3 fixes",
        details="Full response text",
    )
    assert msg.iteration == 2
    assert msg.details == "Full response text"


# --- ConversationLog ---


def test_conversation_log_add():
    log = ConversationLog()
    msg = log.add(agent="scan", icon="\U0001f50d", summary="Found alerts")
    assert len(log.messages) == 1
    assert msg.agent == "scan"
    assert msg.summary == "Found alerts"


def test_conversation_log_add_multiple():
    log = ConversationLog()
    log.add(agent="scan", icon="\U0001f50d", summary="Scan done")
    log.add(agent="fix", icon="\U0001f527", summary="Fix done", iteration=1)
    log.add(agent="verify", icon="\u2705", summary="Verify passed", iteration=1)
    assert len(log.messages) == 3
    assert log.messages[1].iteration == 1


def test_conversation_log_empty():
    log = ConversationLog()
    assert log.messages == []


def test_conversation_log_add_with_details():
    log = ConversationLog()
    msg = log.add(agent="fix", icon="\U0001f527", summary="Summary", details="Details here")
    assert msg.details == "Details here"


# --- ResolveReport ---


def test_resolve_report_empty():
    rr = ResolveReport(repo="org/repo")
    assert rr.total_fixes == 0
    assert rr.total_skipped == 0
    assert rr.iteration_count == 0
    assert rr.converged is False


def test_resolve_report_with_iterations():
    fix = FixAction(package_name="django", file_modified="req.txt", old_version="4.2.5", new_version="4.2.11")
    skip = SkippedFix(package_name="numpy", reason="major")
    fr = FixResult(repo="org/repo", branch="b", base_branch="main", fixes=[fix], skipped=[skip])
    vr = VerifyResult(passed=True)
    pi = PipelineIteration(iteration=1, fix_result=fr, verify_result=vr)

    rr = ResolveReport(
        repo="org/repo",
        iterations=[pi],
        converged=True,
        final_branch="dobbe/fix-vulns",
        pr_url="https://github.com/org/repo/pull/1",
        summary="Fixed 1 package",
    )
    assert rr.total_fixes == 1
    assert rr.total_skipped == 1
    assert rr.iteration_count == 1
    assert rr.converged is True
    assert rr.pr_url == "https://github.com/org/repo/pull/1"


def test_resolve_report_multiple_iterations():
    fr1 = FixResult(
        repo="org/repo", branch="b", base_branch="main",
        fixes=[FixAction(package_name="a", file_modified="f", old_version="1", new_version="2")],
    )
    fr2 = FixResult(
        repo="org/repo", branch="b", base_branch="main",
        fixes=[
            FixAction(package_name="a", file_modified="f", old_version="1", new_version="2"),
            FixAction(package_name="b", file_modified="f", old_version="1", new_version="2"),
        ],
    )
    rr = ResolveReport(
        repo="org/repo",
        iterations=[
            PipelineIteration(iteration=1, fix_result=fr1, verify_result=VerifyResult(passed=False, feedback="fix b")),
            PipelineIteration(iteration=2, fix_result=fr2, verify_result=VerifyResult(passed=True)),
        ],
        converged=True,
    )
    # total_fixes/total_skipped come from last iteration
    assert rr.total_fixes == 2
    assert rr.total_skipped == 0
    assert rr.iteration_count == 2


def test_resolve_report_serialization():
    """ResolveReport can be serialized to JSON and back."""
    fix = FixAction(package_name="django", file_modified="req.txt", old_version="4.2.5", new_version="4.2.11")
    fr = FixResult(repo="org/repo", branch="b", base_branch="main", fixes=[fix])
    pi = PipelineIteration(iteration=1, fix_result=fr)
    rr = ResolveReport(repo="org/repo", iterations=[pi], converged=True)

    json_str = rr.model_dump_json()
    reconstructed = ResolveReport.model_validate_json(json_str)
    assert reconstructed.repo == "org/repo"
    assert reconstructed.converged is True
    assert len(reconstructed.iterations) == 1
    assert reconstructed.iterations[0].fix_result.fixes[0].package_name == "django"
