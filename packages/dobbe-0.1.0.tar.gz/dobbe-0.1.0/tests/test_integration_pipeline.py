"""Integration tests - cross-module flows with minimal mocking."""

from __future__ import annotations

import json
from unittest.mock import patch

import tomli_w

from dobbe.core.config_manager import (
    get_default_severity,
    load_config,
    save_config,
)
from dobbe.core.claude import build_allowed_tools
from dobbe.core.mcp_discovery import discover_mcps
from dobbe.core.prompts import build_scan_prompt
from dobbe.core.repo_resolver import resolve_repo
from dobbe.core.response_parser import parse_triage_response as _parse_triage_response
from dobbe.models.alert import AccessMode, RepoResult, ScanReport, Severity
from dobbe.output import json_out, markdown
from dobbe.output import table as table_out
from rich.console import Console


# --- Config + Repo Resolution ---


def test_save_load_config_then_resolve_repo(tmp_path, monkeypatch):
    """Save config with local_paths, then resolve_repo finds the repo locally."""
    repo_dir = tmp_path / "my-repo"
    repo_dir.mkdir()
    (repo_dir / ".git").mkdir()

    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_DIR", tmp_path)
    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_FILE", tmp_path / "config.toml")

    config = {"repos": {"local_paths": [str(tmp_path)]}, "general": {"default_org": ""}}
    save_config(config)
    loaded = load_config()

    with patch("dobbe.core.repo_resolver._scan_common_directories", return_value=None):
        mode, path = resolve_repo("org/my-repo", loaded)
    assert mode == AccessMode.LOCAL
    assert path == repo_dir


def test_empty_config_paths_falls_to_common_dirs(tmp_path, monkeypatch):
    """Config has empty local_paths → repo found via common dir scan."""
    repo_dir = tmp_path / "my-repo"
    repo_dir.mkdir()
    (repo_dir / ".git").mkdir()

    config = {"repos": {"local_paths": []}}
    with patch(
        "dobbe.core.repo_resolver.COMMON_PROJECT_DIRS", [tmp_path]
    ):
        mode, path = resolve_repo("org/my-repo", config)
    assert mode == AccessMode.LOCAL
    assert path == repo_dir


def test_config_severity_flows_to_prompt(tmp_path, monkeypatch):
    """Load config severity → get_default_severity → build_scan_prompt → severity in prompt."""
    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_DIR", tmp_path)
    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_FILE", tmp_path / "config.toml")
    save_config({"general": {"default_severity": "critical,high", "default_org": ""}})

    config = load_config()
    severity = get_default_severity(config)
    prompt = build_scan_prompt(repo="org/repo", severity_filter=severity)
    assert "critical" in prompt
    assert "high" in prompt


# --- MCP + Tools + Prompts ---


@patch("dobbe.core.mcp_discovery._read_claude_settings")
@patch("dobbe.core.mcp_discovery._read_project_settings")
def test_discovered_mcps_to_tools_to_prompt(mock_project, mock_user):
    """discover_mcps → build_allowed_tools → build_scan_prompt → consistent references."""
    mock_user.return_value = {
        "mcpServers": {"github": {"command": "npx", "args": ["@github/mcp-server"]}}
    }
    mock_project.return_value = {}

    mcps = discover_mcps()
    assert mcps["github"] is True

    tools = build_allowed_tools(available_mcps=mcps)
    assert "mcp__github__*" in tools

    prompt = build_scan_prompt(repo="org/repo", available_mcps=mcps)
    assert "GitHub MCP" in prompt


@patch("dobbe.core.mcp_discovery._read_claude_settings")
@patch("dobbe.core.mcp_discovery._read_project_settings")
def test_no_mcps_produces_gh_fallback(mock_project, mock_user):
    mock_user.return_value = {}
    mock_project.return_value = {}

    mcps = discover_mcps()
    tools = build_allowed_tools(available_mcps=mcps)
    # No MCP tool prefixes
    assert not any("mcp__" in t for t in tools)

    prompt = build_scan_prompt(repo="org/repo", available_mcps=mcps)
    assert "gh api" in prompt


@patch("dobbe.core.mcp_discovery._read_claude_settings")
@patch("dobbe.core.mcp_discovery._read_project_settings")
def test_mcp_plus_local_access(mock_project, mock_user):
    mock_user.return_value = {
        "mcpServers": {"github": {"command": "npx", "args": ["@github/mcp-server"]}}
    }
    mock_project.return_value = {}

    mcps = discover_mcps()
    prompt = build_scan_prompt(
        repo="org/repo",
        available_mcps=mcps,
        access_mode="local",
        local_path="/home/user/projects/repo",
    )
    # Local path mentioned for code inspection
    assert "/home/user/projects/repo" in prompt
    assert "Grep" in prompt
    # GitHub MCP used for fetching alerts
    assert "GitHub MCP" in prompt


# --- Parse + Output Pipeline ---


def test_parse_then_json_output(valid_triage_json):
    repo_result = _parse_triage_response(valid_triage_json, "org/repo")
    report = ScanReport(repos=[repo_result])
    output = json_out.render_report(report)
    parsed = json.loads(output)
    assert len(parsed["repos"]) == 1
    assert parsed["repos"][0]["groups"][0]["package_name"] == "django"


def test_parse_then_markdown_output(valid_triage_json):
    repo_result = _parse_triage_response(valid_triage_json, "org/repo")
    report = ScanReport(repos=[repo_result])
    output = markdown.render_report(report)
    assert "CVE-2024-0001" in output
    assert "django" in output


def test_parse_then_table_output(valid_triage_json):
    repo_result = _parse_triage_response(valid_triage_json, "org/repo")
    report = ScanReport(repos=[repo_result])
    console = Console(file=None, force_terminal=True, width=120)
    table_out.render_report(report, console=console)  # no exception


def test_parse_error_shown_in_all_formats():
    repo_result = _parse_triage_response("no json here", "org/repo")
    report = ScanReport(repos=[repo_result])

    # JSON
    json_output = json_out.render_report(report)
    parsed = json.loads(json_output)
    assert parsed["repos"][0]["error"] is not None

    # Markdown
    md_output = markdown.render_report(report)
    assert "Error" in md_output

    # Table (no crash)
    console = Console(file=None, force_terminal=True, width=120)
    table_out.render_report(report, console=console)


def test_mixed_repos_in_report(valid_triage_json):
    good_repo = _parse_triage_response(valid_triage_json, "org/good-repo")
    bad_repo = _parse_triage_response("not json", "org/bad-repo")
    report = ScanReport(repos=[good_repo, bad_repo])

    # JSON output has both
    json_output = json_out.render_report(report)
    parsed = json.loads(json_output)
    assert len(parsed["repos"]) == 2
    assert parsed["repos"][0]["error"] is None
    assert parsed["repos"][1]["error"] is not None

    # Markdown output has both
    md_output = markdown.render_report(report)
    assert "org/good-repo" in md_output
    assert "org/bad-repo" in md_output


def test_full_pipeline_config_to_output(tmp_path, monkeypatch, valid_triage_json):
    """Full chain: config → MCP discovery → repo resolution → prompt → mock Claude → parse → format."""
    # Setup config
    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_DIR", tmp_path)
    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_FILE", tmp_path / "config.toml")
    save_config({
        "general": {"default_org": "test-org", "default_severity": "critical"},
        "repos": {"local_paths": []},
    })
    config = load_config()
    severity = get_default_severity(config)

    # Mock MCP discovery
    with patch("dobbe.core.mcp_discovery._read_claude_settings", return_value={}), \
         patch("dobbe.core.mcp_discovery._read_project_settings", return_value={}):
        mcps = discover_mcps()

    # Build prompt
    prompt = build_scan_prompt(repo="test-org/app", severity_filter=severity, available_mcps=mcps)
    assert "test-org/app" in prompt
    assert "critical" in prompt

    # "Claude" returns valid JSON
    repo_result = _parse_triage_response(valid_triage_json, "test-org/app")
    report = ScanReport(org="test-org", repos=[repo_result], available_mcps=mcps)

    # All output formats work
    assert "django" in json_out.render_report(report)
    assert "django" in markdown.render_report(report)
    console = Console(file=None, force_terminal=True, width=120)
    table_out.render_report(report, console=console)
