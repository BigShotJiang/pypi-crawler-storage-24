"""Tests for resolve-specific prompt templates and builders."""

from __future__ import annotations

from dobbe.core.prompts import (
    FIX_PROMPT_TEMPLATE,
    REPORT_PROMPT_TEMPLATE,
    VERIFY_PROMPT_TEMPLATE,
    build_fix_prompt,
    build_report_prompt,
    build_verify_prompt,
)


# --- build_fix_prompt ---


def test_build_fix_prompt_basic():
    prompt = build_fix_prompt(local_path="/tmp/repo", scan_summary="3 alerts to fix")
    assert "/tmp/repo" in prompt
    assert "3 alerts to fix" in prompt
    assert "Previous Attempt Feedback" not in prompt
    assert '"fixes"' in prompt
    assert '"skipped"' in prompt


def test_build_fix_prompt_with_feedback():
    prompt = build_fix_prompt(
        local_path="/tmp/repo",
        scan_summary="Fix these",
        feedback="Pin requests to 2.30.x",
    )
    assert "Previous Attempt Feedback" in prompt
    assert "Pin requests to 2.30.x" in prompt


def test_build_fix_prompt_empty_feedback():
    prompt = build_fix_prompt(local_path="/tmp/repo", scan_summary="Fix", feedback="")
    assert "Previous Attempt Feedback" not in prompt


def test_build_fix_prompt_contains_rules():
    prompt = build_fix_prompt(local_path="/tmp/repo", scan_summary="Fix")
    assert "PATCH or MINOR" in prompt
    assert "major version" in prompt.lower()
    assert "lockfile" in prompt.lower()


# --- build_verify_prompt ---


def test_build_verify_prompt_basic():
    prompt = build_verify_prompt(
        local_path="/tmp/repo",
        branch="fix-branch",
        base_branch="main",
    )
    assert "/tmp/repo" in prompt
    assert "fix-branch" in prompt
    assert "main" in prompt
    assert '"passed"' in prompt
    assert '"issues"' in prompt


def test_build_verify_prompt_instructions():
    prompt = build_verify_prompt(
        local_path="/tmp/repo",
        branch="b",
        base_branch="main",
    )
    assert "git diff" in prompt
    assert "test suite" in prompt
    assert "breaking change" in prompt.lower()
    assert "lockfile" in prompt.lower()


# --- build_report_prompt ---


def test_build_report_prompt_basic():
    prompt = build_report_prompt(
        repo="org/repo",
        scan_summary="5 alerts found",
        iteration_count=2,
        converged=True,
        iteration_details="Iteration 1: passed",
    )
    assert "org/repo" in prompt
    assert "5 alerts found" in prompt
    assert "2" in prompt
    assert "True" in prompt
    assert "Iteration 1: passed" in prompt


def test_build_report_prompt_not_converged():
    prompt = build_report_prompt(
        repo="org/repo",
        scan_summary="alerts",
        iteration_count=3,
        converged=False,
        iteration_details="all failed",
    )
    assert "False" in prompt
    assert "all failed" in prompt


def test_build_report_prompt_contains_instructions():
    prompt = build_report_prompt(
        repo="org/repo",
        scan_summary="",
        iteration_count=1,
        converged=True,
        iteration_details="",
    )
    assert "executive summary" in prompt.lower()
    assert "risk assessment" in prompt.lower()
    assert "500 words" in prompt


# --- Templates have correct placeholders ---


def test_fix_template_has_placeholders():
    assert "{local_path}" in FIX_PROMPT_TEMPLATE
    assert "{scan_summary}" in FIX_PROMPT_TEMPLATE
    assert "{feedback_section}" in FIX_PROMPT_TEMPLATE


def test_verify_template_has_placeholders():
    assert "{local_path}" in VERIFY_PROMPT_TEMPLATE
    assert "{branch}" in VERIFY_PROMPT_TEMPLATE
    assert "{base_branch}" in VERIFY_PROMPT_TEMPLATE


def test_report_template_has_placeholders():
    assert "{repo}" in REPORT_PROMPT_TEMPLATE
    assert "{scan_summary}" in REPORT_PROMPT_TEMPLATE
    assert "{iteration_count}" in REPORT_PROMPT_TEMPLATE
    assert "{converged}" in REPORT_PROMPT_TEMPLATE
    assert "{iteration_details}" in REPORT_PROMPT_TEMPLATE
