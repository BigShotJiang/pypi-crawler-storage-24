"""Tests for verbose vs default rendering across all output modules."""

from __future__ import annotations

import io
from datetime import datetime, timedelta

from rich.console import Console

from dobbe.models.alert import (
    AccessMode,
    AlertGroup,
    RepoResult,
    ScanReport,
    Severity,
    TriageResult,
)
from dobbe.models.review import (
    PRInfo,
    PRReviewResult,
    PostResult,
    ReviewConcern,
    ReviewDigest,
    ReviewPostReport,
)
from dobbe.models.shared import ReviewCategory
from dobbe.output import markdown, review_markdown, review_post_markdown, review_post_table, review_table
from dobbe.output import table as table_out


# --- Fixtures ---


def _make_alert(evidence="Found usage in models.py:42"):
    return TriageResult(
        alert_number=1,
        cve_id="CVE-2024-0001",
        package_name="django",
        severity=Severity.CRITICAL,
        summary="SQL injection in ORM",
        affected=True,
        evidence=evidence,
        risk_level=Severity.CRITICAL,
        recommended_action="Upgrade to 4.2.8",
    )


def _make_vuln_report(alert=None, verbose_group=True):
    alert = alert or _make_alert()
    group = AlertGroup(
        package_name="django",
        package_ecosystem="pip",
        current_version="4.2.5",
        target_version="4.2.8" if verbose_group else None,
        alerts=[alert],
    )
    repo = RepoResult(repo="org/app", access_mode=AccessMode.LOCAL, groups=[group])
    return ScanReport(org="org", repos=[repo])


def _make_pr(number=42, age_days=3, repo="org/repo"):
    return PRInfo(
        repo=repo,
        pr_number=number,
        title=f"Fix auth flow in PR #{number}",
        author="alice",
        url=f"https://github.com/{repo}/pull/{number}",
        created_at=datetime.now() - timedelta(days=age_days),
        updated_at=datetime.now(),
        additions=50,
        deletions=10,
        changed_files=3,
        labels=["security"],
        draft=False,
    )


def _make_concern():
    return ReviewConcern(
        category=ReviewCategory.SECURITY,
        severity=Severity.CRITICAL,
        description="Token stored in plaintext",
        file_path="src/auth.py",
        line_number=42,
        suggestion="Use encrypted storage",
    )


def _make_review_result(risk=Severity.HIGH, concerns=None, recommendations=None):
    return PRReviewResult(
        pr=_make_pr(),
        risk_level=risk,
        summary="Security concerns found",
        concerns=concerns or [_make_concern()],
        recommendations=recommendations or ["Add integration test", "Update API docs"],
        estimated_review_time="15 min",
        approval_recommendation="request_changes",
    )


def _make_digest(results=None):
    return ReviewDigest(
        timestamp=datetime(2024, 1, 15, 10, 30),
        reviewers=["@me"],
        repos_scanned=["org/repo"],
        results=results or [_make_review_result()],
        stale_days=7,
    )


def _make_post_report(results=None, dry_run=False):
    pr = _make_pr()
    review = _make_review_result()
    post = PostResult(pr=pr, review=review, posted=True, review_url="https://github.com/org/repo/pull/42#review")
    return ReviewPostReport(
        repos_scanned=["org/repo"],
        results=results or [post],
        dry_run=dry_run,
    )


# --- Vuln table: default vs verbose ---


def test_vuln_table_default_no_cve_column():
    """Default mode does not show CVE column."""
    report = _make_vuln_report()
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=False, no_color=True, width=160)
    table_out.render_report(report, console=console, verbose=False)
    output = buf.getvalue()
    assert "CVE-2024-0001" not in output


def test_vuln_table_verbose_shows_cve():
    """Verbose mode shows CVE column."""
    report = _make_vuln_report()
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=False, no_color=True, width=200)
    table_out.render_report(report, console=console, verbose=True)
    output = buf.getvalue()
    assert "CVE-2024-0001" in output


def test_vuln_table_verbose_shows_upgrade_path():
    """Verbose mode shows upgrade path."""
    report = _make_vuln_report()
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=False, no_color=True, width=200)
    table_out.render_report(report, console=console, verbose=True)
    output = buf.getvalue()
    assert "4.2.5" in output
    assert "4.2.8" in output


def test_vuln_table_verbose_shows_evidence():
    """Verbose mode shows evidence detail rows."""
    report = _make_vuln_report()
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=False, no_color=True, width=200)
    table_out.render_report(report, console=console, verbose=True)
    output = buf.getvalue()
    assert "Evidence" in output
    assert "models.py:42" in output


def test_vuln_table_verbose_no_truncation():
    """Verbose mode does not truncate summary."""
    long_summary = "A" * 100
    alert = _make_alert()
    alert.summary = long_summary
    report = _make_vuln_report(alert=alert)
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=False, no_color=True, width=300)
    table_out.render_report(report, console=console, verbose=True)
    output = buf.getvalue()
    assert "..." not in output


def test_vuln_table_default_truncates():
    """Default mode truncates long summary."""
    long_summary = "A" * 100
    alert = _make_alert()
    alert.summary = long_summary
    report = _make_vuln_report(alert=alert)
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=False, no_color=True, width=200)
    table_out.render_report(report, console=console, verbose=False)
    output = buf.getvalue()
    assert "..." in output


# --- Vuln markdown: verbose ---


def test_vuln_markdown_verbose_shows_evidence():
    report = _make_vuln_report()
    output = markdown.render_report(report, verbose=True)
    assert "Evidence" in output
    assert "models.py:42" in output


def test_vuln_markdown_verbose_shows_upgrade():
    report = _make_vuln_report()
    output = markdown.render_report(report, verbose=True)
    assert "4.2.5" in output
    assert "4.2.8" in output


def test_vuln_markdown_default_no_evidence():
    report = _make_vuln_report()
    output = markdown.render_report(report, verbose=False)
    assert "Evidence" not in output


# --- Review digest table: verbose ---


def test_review_table_verbose_shows_diff_stats():
    """Verbose mode shows +/- and Files columns."""
    digest = _make_digest()
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=False, no_color=True, width=200)
    review_table.render_digest(digest, console=console, verbose=True)
    output = buf.getvalue()
    assert "+50/-10" in output
    assert "3" in output  # changed_files


def test_review_table_verbose_shows_recommendations():
    digest = _make_digest()
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=False, no_color=True, width=200)
    review_table.render_digest(digest, console=console, verbose=True)
    output = buf.getvalue()
    assert "Recommendations" in output
    assert "integration test" in output.lower()


def test_review_table_verbose_shows_all_concerns():
    digest = _make_digest()
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=False, no_color=True, width=200)
    review_table.render_digest(digest, console=console, verbose=True)
    output = buf.getvalue()
    assert "src/auth.py:42" in output
    assert "encrypted storage" in output.lower()


def test_review_table_default_no_diff_stats():
    digest = _make_digest()
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=False, no_color=True, width=200)
    review_table.render_digest(digest, console=console, verbose=False)
    output = buf.getvalue()
    assert "+50/-10" not in output


# --- Review digest markdown: verbose ---


def test_review_markdown_verbose_shows_diff_stats():
    digest = _make_digest()
    output = review_markdown.render_digest(digest, verbose=True)
    assert "+50/-10" in output


def test_review_markdown_verbose_shows_recommendations():
    digest = _make_digest()
    output = review_markdown.render_digest(digest, verbose=True)
    assert "Recommendations" in output
    assert "integration test" in output.lower()


def test_review_markdown_default_no_diff_column():
    digest = _make_digest()
    output = review_markdown.render_digest(digest, verbose=False)
    assert "+/-" not in output


# --- Review post table: verbose ---


def test_post_table_verbose_shows_concerns():
    concern = _make_concern()
    review = _make_review_result(concerns=[concern])
    post = PostResult(pr=_make_pr(), review=review, posted=True)
    report = _make_post_report(results=[post])
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=False, no_color=True, width=200)
    review_post_table.render_post_report(report, console=console, verbose=True)
    output = buf.getvalue()
    assert "src/auth.py:42" in output
    assert "plaintext" in output.lower()


def test_post_table_default_no_concerns():
    report = _make_post_report()
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=False, no_color=True, width=200)
    review_post_table.render_post_report(report, console=console, verbose=False)
    output = buf.getvalue()
    assert "src/auth.py:42" not in output


# --- Repo grouping tests (U5) ---


def test_review_table_multi_repo_grouping():
    """Multiple repos get Rule separators."""
    results = [
        _make_review_result(risk=Severity.CRITICAL),
    ]
    # Create a second result with a different repo
    pr2 = _make_pr(number=99, repo="org/other-repo")
    result2 = PRReviewResult(
        pr=pr2,
        risk_level=Severity.LOW,
        summary="Low risk",
        concerns=[],
        recommendations=[],
        estimated_review_time="5 min",
        approval_recommendation="approve",
    )
    results.append(result2)
    digest = ReviewDigest(
        timestamp=datetime(2024, 1, 15, 10, 30),
        reviewers=["@me"],
        repos_scanned=["org/repo", "org/other-repo"],
        results=results,
        stale_days=7,
    )
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=False, no_color=True, width=200)
    review_table.render_digest(digest, console=console)
    output = buf.getvalue()
    # Rule separators show repo names
    assert "org/repo" in output
    assert "org/other-repo" in output
    assert "critical" in output.lower()


def test_review_table_single_repo_no_rule():
    """Single repo doesn't get a Rule separator."""
    digest = _make_digest()
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=False, no_color=True, width=200)
    review_table.render_digest(digest, console=console)
    output = buf.getvalue()
    # No horizontal rule for single repo
    assert "─" not in output or "PRs" not in output.split("─")[0] if "─" in output else True


def test_post_table_multi_repo_grouping():
    """Multiple repos in post report get Rule separators."""
    pr1 = _make_pr(number=1, repo="org/repo1")
    pr2 = _make_pr(number=2, repo="org/repo2")
    review1 = PRReviewResult(
        pr=pr1, risk_level=Severity.HIGH, summary="Review", concerns=[], recommendations=[], approval_recommendation="approve",
    )
    review2 = PRReviewResult(
        pr=pr2, risk_level=Severity.LOW, summary="OK", concerns=[], recommendations=[], approval_recommendation="approve",
    )
    post1 = PostResult(pr=pr1, review=review1, posted=True, review_url="url1")
    post2 = PostResult(pr=pr2, review=review2, posted=True, review_url="url2")
    report = ReviewPostReport(repos_scanned=["org/repo1", "org/repo2"], results=[post1, post2], dry_run=False)
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=False, no_color=True, width=200)
    review_post_table.render_post_report(report, console=console)
    output = buf.getvalue()
    assert "org/repo1" in output
    assert "org/repo2" in output


# --- Status helpers tests (U6) ---


def test_status_helpers():
    """Status helpers render without error."""
    from dobbe.output import status
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=False, no_color=True, width=80)
    status.error("Something failed", console=console)
    status.warning("Watch out", console=console)
    status.success("All good", console=console)
    status.info("FYI", console=console)
    output = buf.getvalue()
    assert "Error:" in output
    assert "Warning:" in output
    assert "All good" in output
    assert "FYI" in output


def test_status_helpers_default_console():
    """Status helpers work with no console arg."""
    from dobbe.output import status
    status.error("test")
    status.warning("test")
    status.success("test")
    status.info("test")


# --- Code highlighting (U11) ---


def test_highlight_code_refs():
    """Code references get highlighted."""
    from dobbe.output.table import _highlight_code_refs
    result = _highlight_code_refs("Found in models.py:42 and views.py:10")
    assert "models.py:42" in result
    assert "bold cyan" in result


def test_highlight_no_refs():
    """Text without code refs is unchanged."""
    from dobbe.output.table import _highlight_code_refs
    assert _highlight_code_refs("No code here") == "No code here"


# --- Shared helpers (U10) ---


def test_shared_helpers():
    """Shared severity_badge and sanitize_md_cell work correctly."""
    from dobbe.output.helpers import sanitize_md_cell, severity_badge
    badge = severity_badge(Severity.CRITICAL)
    assert badge.plain == "CRITICAL"
    assert sanitize_md_cell("a | b") == "a \\| b"
    assert sanitize_md_cell("*bold*") == "\\*bold\\*"


# --- Bug 18: Rich markup escaping ---


def test_render_report_markup_in_error_no_crash():
    """Rich markup characters in error strings don't crash the table renderer."""
    report = ScanReport(repos=[
        RepoResult(
            repo="org/repo",
            access_mode=AccessMode.REMOTE,
            error="[bold red]malicious[/bold red] <script>alert(1)</script>",
        )
    ])
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=False, no_color=True, width=200)
    # Should not raise MarkupError
    table_out.render_report(report, console=console)
    output = buf.getvalue()
    assert "malicious" in output


def test_status_markup_in_message_no_crash():
    """Rich markup characters in status messages don't crash."""
    from dobbe.output import status
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=False, no_color=True, width=200)
    # These should not raise MarkupError
    status.error("[bold]not really bold[/bold]", console=console)
    status.warning("[red]not red[/red]", console=console)
    status.success("[link=http://evil]click[/link]", console=console)
    status.info("[dim]not dim[/dim]", console=console)
    output = buf.getvalue()
    assert "[bold]not really bold[/bold]" in output


def test_render_digest_markup_in_error_no_crash():
    """Rich markup characters in digest errors don't crash."""
    digest = ReviewDigest(
        timestamp=datetime(2024, 1, 15, 10, 30),
        reviewers=["@me"],
        repos_scanned=["org/repo"],
        results=[],
        stale_days=7,
        errors=["[red]bad markup[/red] <script>"],
    )
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=False, no_color=True, width=200)
    review_table.render_digest(digest, console=console)
    output = buf.getvalue()
    assert "bad markup" in output


def test_progress_markup_in_repo_no_crash():
    """Rich markup in repo names doesn't crash progress display."""
    from dobbe.output.progress import LiveProgress
    lp = LiveProgress(title="test")
    lp.update(repo="[bold]evil/repo[/bold]", repo_status="done (1 PR)")
    # Should not raise
    table = lp._build_table()
    assert table is not None
