"""Tests for org/user repo listing via Claude."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from dobbe.core.claude import ClaudeResult
from dobbe.core.org_repos import (
    OrgListError,
    list_org_repos,
    list_repos,
    list_user_repos,
)


# --- list_user_repos ---


@patch("dobbe.core.org_repos.ask_claude")
def test_list_user_repos_success(mock_claude):
    mock_claude.return_value = ClaudeResult(success=True, text='["user/repo1", "user/repo2"]')
    repos = list_user_repos("user", {"github": True})
    assert repos == ["user/repo1", "user/repo2"]


@patch("dobbe.core.org_repos.ask_claude")
def test_list_user_repos_claude_failure(mock_claude):
    mock_claude.return_value = ClaudeResult(success=False, error="Claude down")
    with pytest.raises(OrgListError, match="Claude down"):
        list_user_repos("user", {"github": True})


@patch("dobbe.core.org_repos.ask_claude")
def test_list_user_repos_bad_json(mock_claude):
    mock_claude.return_value = ClaudeResult(success=True, text="No repos found.")
    with pytest.raises(OrgListError, match="Could not parse"):
        list_user_repos("user", {"github": True})


@patch("dobbe.core.org_repos.ask_claude")
def test_list_user_repos_skip_forks_in_prompt(mock_claude):
    mock_claude.return_value = ClaudeResult(success=True, text='["u/r1"]')
    list_user_repos("user", {"github": True}, skip_forks=True)
    prompt = mock_claude.call_args.kwargs["prompt"]
    assert "Exclude forked repositories" in prompt


@patch("dobbe.core.org_repos.ask_claude")
def test_list_user_repos_include_forks(mock_claude):
    mock_claude.return_value = ClaudeResult(success=True, text='["u/r1"]')
    list_user_repos("user", {"github": True}, skip_forks=False)
    prompt = mock_claude.call_args.kwargs["prompt"]
    assert "Exclude forked" not in prompt


@patch("dobbe.core.org_repos.ask_claude")
def test_list_user_repos_skip_archived_in_prompt(mock_claude):
    mock_claude.return_value = ClaudeResult(success=True, text='["u/r1"]')
    list_user_repos("user", {"github": True}, skip_archived=True)
    prompt = mock_claude.call_args.kwargs["prompt"]
    assert "Exclude archived repositories" in prompt


@patch("dobbe.core.org_repos.ask_claude")
def test_list_user_repos_include_archived(mock_claude):
    mock_claude.return_value = ClaudeResult(success=True, text='["u/r1"]')
    list_user_repos("user", {"github": True}, skip_archived=False)
    prompt = mock_claude.call_args.kwargs["prompt"]
    assert "Exclude archived" not in prompt


@patch("dobbe.core.org_repos.ask_claude")
def test_list_user_repos_prompt_uses_gh_api(mock_claude):
    mock_claude.return_value = ClaudeResult(success=True, text='["u/r1"]')
    list_user_repos("testuser", {"github": True})
    prompt = mock_claude.call_args.kwargs["prompt"]
    assert "/users/testuser/repos" in prompt
    assert "GitHub user" in prompt


# --- list_org_repos filter params ---


@patch("dobbe.core.org_repos.ask_claude")
def test_list_org_repos_skip_forks_in_prompt(mock_claude):
    mock_claude.return_value = ClaudeResult(success=True, text='["org/r1"]')
    list_org_repos("myorg", {"github": True}, skip_forks=True)
    prompt = mock_claude.call_args.kwargs["prompt"]
    assert "Exclude forked repositories" in prompt


@patch("dobbe.core.org_repos.ask_claude")
def test_list_org_repos_include_forks(mock_claude):
    mock_claude.return_value = ClaudeResult(success=True, text='["org/r1"]')
    list_org_repos("myorg", {"github": True}, skip_forks=False)
    prompt = mock_claude.call_args.kwargs["prompt"]
    assert "Exclude forked" not in prompt


# --- list_repos dispatcher ---


@patch("dobbe.core.org_repos.list_user_repos")
def test_list_repos_dispatches_to_user(mock_user):
    mock_user.return_value = ["user/repo1"]
    result = list_repos("user", {"github": True}, is_user=True)
    assert result == ["user/repo1"]
    mock_user.assert_called_once_with("user", {"github": True})


@patch("dobbe.core.org_repos.list_org_repos")
def test_list_repos_dispatches_to_org(mock_org):
    mock_org.return_value = ["org/repo1"]
    result = list_repos("org", {"github": True}, is_user=False)
    assert result == ["org/repo1"]
    mock_org.assert_called_once_with("org", {"github": True})


@patch("dobbe.core.org_repos.list_user_repos")
def test_list_repos_passes_kwargs(mock_user):
    mock_user.return_value = []
    list_repos("user", {"github": True}, is_user=True, timeout=30, skip_forks=False)
    mock_user.assert_called_once_with("user", {"github": True}, timeout=30, skip_forks=False)


# --- list_user_repos invalid JSON ---


@patch("dobbe.core.org_repos.ask_claude")
def test_list_user_repos_invalid_json_array(mock_claude):
    mock_claude.return_value = ClaudeResult(success=True, text="[not valid json}")
    with pytest.raises(OrgListError, match="Could not parse"):
        list_user_repos("user", {"github": True})
