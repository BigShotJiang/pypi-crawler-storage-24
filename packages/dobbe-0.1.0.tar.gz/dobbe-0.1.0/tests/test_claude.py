"""Tests for Claude Code subprocess wrapper."""

import subprocess
from unittest.mock import patch, MagicMock, call
import json

from dobbe.core.claude import (
    ClaudeResult,
    RETRY_BACKOFF_BASE,
    _extract_text_from_parsed,
    build_allowed_tools,
    is_claude_installed,
    ask_claude,
    BASE_TOOLS,
)


def test_build_allowed_tools_base():
    tools = build_allowed_tools()
    assert tools == BASE_TOOLS


def test_build_allowed_tools_with_mcps():
    mcps = {"github": True, "slack": True, "atlassian": False}
    tools = build_allowed_tools(available_mcps=mcps)
    assert "mcp__github__*" in tools
    assert "mcp__claude_ai_Slack__*" in tools
    assert "mcp__claude_ai_Atlassian__*" not in tools


def test_build_allowed_tools_with_extras():
    tools = build_allowed_tools(extra_tools=["Edit", "Write"])
    assert "Edit" in tools
    assert "Write" in tools
    for t in BASE_TOOLS:
        assert t in tools


@patch("dobbe.core.claude._find_claude_binary")
def test_is_claude_installed_true(mock_find):
    mock_find.return_value = "/usr/local/bin/claude"
    assert is_claude_installed() is True


@patch("dobbe.core.claude._find_claude_binary")
def test_is_claude_installed_false(mock_find):
    mock_find.return_value = None
    assert is_claude_installed() is False


@patch("dobbe.core.claude._find_claude_binary")
def test_ask_claude_not_installed(mock_find):
    mock_find.return_value = None
    result = ask_claude("hello")
    assert result.success is False
    assert "not installed" in result.error


@patch("dobbe.core.claude.subprocess.run")
@patch("dobbe.core.claude._find_claude_binary")
def test_ask_claude_success(mock_find, mock_run):
    mock_find.return_value = "/usr/local/bin/claude"
    mock_run.return_value = MagicMock(
        returncode=0,
        stdout=json.dumps({"result": "Hello! How can I help?"}),
        stderr="",
    )
    result = ask_claude("hello")
    assert result.success is True
    assert "Hello" in result.text


@patch("dobbe.core.claude.subprocess.run")
@patch("dobbe.core.claude._find_claude_binary")
def test_ask_claude_error(mock_find, mock_run):
    mock_find.return_value = "/usr/local/bin/claude"
    mock_run.return_value = MagicMock(
        returncode=1,
        stdout="",
        stderr="Something went wrong",
    )
    result = ask_claude("hello", max_retries=0)
    assert result.success is False
    assert "Something went wrong" in result.error


@patch("dobbe.core.claude.subprocess.run")
@patch("dobbe.core.claude._find_claude_binary")
def test_ask_claude_timeout(mock_find, mock_run):
    mock_find.return_value = "/usr/local/bin/claude"
    mock_run.side_effect = subprocess.TimeoutExpired(cmd="claude", timeout=30)
    result = ask_claude("hello", timeout=30, max_retries=0)
    assert result.success is False
    assert "timed out" in result.error


@patch("dobbe.core.claude.subprocess.run")
@patch("dobbe.core.claude._find_claude_binary")
def test_ask_claude_non_json_response(mock_find, mock_run):
    mock_find.return_value = "/usr/local/bin/claude"
    mock_run.return_value = MagicMock(
        returncode=0,
        stdout="Just plain text response",
        stderr="",
    )
    result = ask_claude("hello")
    assert result.success is True
    assert result.text == "Just plain text response"


# --- check_claude_auth ---

from dobbe.core.claude import check_claude_auth


@patch("dobbe.core.claude.subprocess.run")
@patch("dobbe.core.claude._find_claude_binary")
def test_check_claude_auth_success(mock_find, mock_run):
    mock_find.return_value = "/usr/local/bin/claude"
    mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
    ok, msg = check_claude_auth()
    assert ok is True
    assert "authenticated" in msg.lower()


@patch("dobbe.core.claude._find_claude_binary")
def test_check_claude_auth_not_installed(mock_find):
    mock_find.return_value = None
    ok, msg = check_claude_auth()
    assert ok is False
    assert "not installed" in msg.lower() or "Install" in msg


@patch("dobbe.core.claude.subprocess.run")
@patch("dobbe.core.claude._find_claude_binary")
def test_check_claude_auth_error_rc(mock_find, mock_run):
    mock_find.return_value = "/usr/local/bin/claude"
    mock_run.return_value = MagicMock(returncode=1, stdout="", stderr="auth failed")
    ok, msg = check_claude_auth()
    assert ok is False
    assert "auth failed" in msg


@patch("dobbe.core.claude.subprocess.run")
@patch("dobbe.core.claude._find_claude_binary")
def test_check_claude_auth_timeout(mock_find, mock_run):
    mock_find.return_value = "/usr/local/bin/claude"
    import subprocess
    mock_run.side_effect = subprocess.TimeoutExpired(cmd="claude", timeout=30)
    ok, msg = check_claude_auth()
    assert ok is False
    assert "timed out" in msg.lower()


@patch("dobbe.core.claude.subprocess.run")
@patch("dobbe.core.claude._find_claude_binary")
def test_check_claude_auth_os_error(mock_find, mock_run):
    mock_find.return_value = "/usr/local/bin/claude"
    mock_run.side_effect = OSError("Permission denied")
    ok, msg = check_claude_auth()
    assert ok is False
    assert "Failed" in msg


# --- ask_claude content-blocks format ---


@patch("dobbe.core.claude.subprocess.run")
@patch("dobbe.core.claude._find_claude_binary")
def test_ask_claude_content_blocks_list(mock_find, mock_run):
    mock_find.return_value = "/usr/local/bin/claude"
    mock_run.return_value = MagicMock(
        returncode=0,
        stdout=json.dumps({"content": [{"type": "text", "text": "hi"}, {"type": "tool_use", "name": "x"}]}),
        stderr="",
    )
    result = ask_claude("hello")
    assert result.success is True
    assert result.text == "hi"


@patch("dobbe.core.claude.subprocess.run")
@patch("dobbe.core.claude._find_claude_binary")
def test_ask_claude_content_string(mock_find, mock_run):
    mock_find.return_value = "/usr/local/bin/claude"
    mock_run.return_value = MagicMock(
        returncode=0,
        stdout=json.dumps({"content": "hello direct"}),
        stderr="",
    )
    result = ask_claude("hello")
    assert result.success is True
    assert result.text == "hello direct"


@patch("dobbe.core.claude.subprocess.run")
@patch("dobbe.core.claude._find_claude_binary")
def test_ask_claude_os_error(mock_find, mock_run):
    mock_find.return_value = "/usr/local/bin/claude"
    mock_run.side_effect = OSError("No such file")
    result = ask_claude("hello")
    assert result.success is False
    assert "No such file" in result.error


# --- Parsed string branch (lines 163-164) ---


@patch("dobbe.core.claude.subprocess.run")
@patch("dobbe.core.claude._find_claude_binary")
def test_ask_claude_parsed_string_json(mock_find, mock_run):
    """When stdout is a JSON string (not object), text should be that string."""
    mock_find.return_value = "/usr/local/bin/claude"
    mock_run.return_value = MagicMock(
        returncode=0,
        stdout=json.dumps("just a string"),
        stderr="",
    )
    result = ask_claude("hello")
    assert result.success is True
    assert result.text == "just a string"


# --- Retry logic ---


@patch("dobbe.core.claude.time.sleep")
@patch("dobbe.core.claude.subprocess.run")
@patch("dobbe.core.claude._find_claude_binary")
def test_ask_claude_retries_on_timeout(mock_find, mock_run, mock_sleep):
    """Timeout twice, succeed on third attempt."""
    mock_find.return_value = "/usr/local/bin/claude"
    mock_run.side_effect = [
        subprocess.TimeoutExpired(cmd="claude", timeout=30),
        subprocess.TimeoutExpired(cmd="claude", timeout=30),
        MagicMock(returncode=0, stdout=json.dumps({"result": "OK"}), stderr=""),
    ]
    result = ask_claude("hello", timeout=30, max_retries=2)
    assert result.success is True
    assert result.text == "OK"
    assert mock_sleep.call_count == 2


@patch("dobbe.core.claude.time.sleep")
@patch("dobbe.core.claude.subprocess.run")
@patch("dobbe.core.claude._find_claude_binary")
def test_ask_claude_retries_on_error_code(mock_find, mock_run, mock_sleep):
    """Non-zero return code twice, succeed on third attempt."""
    mock_find.return_value = "/usr/local/bin/claude"
    mock_run.side_effect = [
        MagicMock(returncode=1, stdout="", stderr="error 1"),
        MagicMock(returncode=1, stdout="", stderr="error 2"),
        MagicMock(returncode=0, stdout=json.dumps({"result": "OK"}), stderr=""),
    ]
    result = ask_claude("hello", max_retries=2)
    assert result.success is True
    assert mock_sleep.call_count == 2


@patch("dobbe.core.claude.subprocess.run")
@patch("dobbe.core.claude._find_claude_binary")
def test_ask_claude_no_retry_on_not_installed(mock_find, mock_run):
    """Not-installed is immediate, no retry."""
    mock_find.return_value = None
    result = ask_claude("hello", max_retries=2)
    assert result.success is False
    assert "not installed" in result.error
    mock_run.assert_not_called()


@patch("dobbe.core.claude.time.sleep")
@patch("dobbe.core.claude.subprocess.run")
@patch("dobbe.core.claude._find_claude_binary")
def test_ask_claude_no_retry_on_os_error(mock_find, mock_run, mock_sleep):
    """OSError is permanent - no retry."""
    mock_find.return_value = "/usr/local/bin/claude"
    mock_run.side_effect = OSError("Permission denied")
    result = ask_claude("hello", max_retries=2)
    assert result.success is False
    assert "Permission denied" in result.error
    mock_sleep.assert_not_called()


@patch("dobbe.core.claude.time.sleep")
@patch("dobbe.core.claude.subprocess.run")
@patch("dobbe.core.claude._find_claude_binary")
def test_ask_claude_exhausts_retries(mock_find, mock_run, mock_sleep):
    """Always times out - returns failure after max retries."""
    mock_find.return_value = "/usr/local/bin/claude"
    mock_run.side_effect = subprocess.TimeoutExpired(cmd="claude", timeout=30)
    result = ask_claude("hello", timeout=30, max_retries=2)
    assert result.success is False
    assert "timed out" in result.error
    assert mock_run.call_count == 3  # initial + 2 retries


@patch("dobbe.core.claude.time.sleep")
@patch("dobbe.core.claude.subprocess.run")
@patch("dobbe.core.claude._find_claude_binary")
def test_ask_claude_max_retries_zero(mock_find, mock_run, mock_sleep):
    """With max_retries=0, no retries happen."""
    mock_find.return_value = "/usr/local/bin/claude"
    mock_run.side_effect = subprocess.TimeoutExpired(cmd="claude", timeout=30)
    result = ask_claude("hello", timeout=30, max_retries=0)
    assert result.success is False
    assert mock_run.call_count == 1
    mock_sleep.assert_not_called()


@patch("dobbe.core.claude.time.sleep")
@patch("dobbe.core.claude.subprocess.run")
@patch("dobbe.core.claude._find_claude_binary")
def test_ask_claude_backoff_called(mock_find, mock_run, mock_sleep):
    """Verify time.sleep called with correct exponential backoff intervals."""
    mock_find.return_value = "/usr/local/bin/claude"
    mock_run.side_effect = subprocess.TimeoutExpired(cmd="claude", timeout=30)
    ask_claude("hello", timeout=30, max_retries=2)
    assert mock_sleep.call_args_list == [
        call(RETRY_BACKOFF_BASE ** 0),  # 2^0 = 1
        call(RETRY_BACKOFF_BASE ** 1),  # 2^1 = 2
    ]


# --- _extract_text_from_parsed ---


def test_extract_text_from_result_field():
    assert _extract_text_from_parsed({"result": "hello"}) == "hello"


def test_extract_text_from_text_field():
    assert _extract_text_from_parsed({"text": "hello"}) == "hello"


def test_extract_text_from_content_blocks():
    parsed = {"content": [{"type": "text", "text": "a"}, {"type": "tool_use", "name": "x"}, {"type": "text", "text": "b"}]}
    assert _extract_text_from_parsed(parsed) == "a\nb"


def test_extract_text_from_content_string():
    assert _extract_text_from_parsed({"content": "direct"}) == "direct"


def test_extract_text_from_string():
    assert _extract_text_from_parsed("plain string") == "plain string"


def test_extract_text_from_empty_dict():
    assert _extract_text_from_parsed({}) == ""
