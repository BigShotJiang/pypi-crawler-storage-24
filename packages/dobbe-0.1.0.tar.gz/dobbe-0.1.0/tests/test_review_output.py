"""Tests for review output formatters - table and markdown."""

from __future__ import annotations

import io
from datetime import datetime, timedelta

from rich.console import Console

from dobbe.models.review import (
    PRInfo,
    PRReviewResult,
    ReviewConcern,
    ReviewDigest,
)
from dobbe.models.shared import ReviewCategory, Severity
from dobbe.output import review_markdown, review_table


def _make_pr(number=42, age_days=3, repo="org/repo") -> PRInfo:
    return PRInfo(
        repo=repo,
        pr_number=number,
        title=f"PR #{number}",
        author="alice",
        url=f"https://github.com/{repo}/pull/{number}",
        created_at=datetime.now() - timedelta(days=age_days),
        updated_at=datetime.now(),
        additions=50,
        deletions=10,
        changed_files=3,
    )


def _make_result(
    risk=Severity.MEDIUM,
    number=42,
    age_days=3,
    concerns=None,
    recommendation="approve",
) -> PRReviewResult:
    return PRReviewResult(
        pr=_make_pr(number=number, age_days=age_days),
        risk_level=risk,
        summary=f"Risk: {risk.value}",
        concerns=concerns or [],
        recommendations=["Review carefully"],
        estimated_review_time="15 min",
        approval_recommendation=recommendation,
    )


def _make_digest(results=None, errors=None, stale_days=7) -> ReviewDigest:
    return ReviewDigest(
        timestamp=datetime(2024, 1, 15, 10, 30),
        reviewers=["@me"],
        repos_scanned=["org/repo"],
        results=results or [],
        stale_days=stale_days,
        errors=errors or [],
    )


# --- Table output ---


def test_table_render_basic():
    digest = _make_digest(results=[_make_result()])
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=True, width=120)
    review_table.render_digest(digest, console=console)
    output = buf.getvalue()
    assert "alice" in output
    assert "org/repo" in output


def test_table_render_empty():
    digest = _make_digest()
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=True, width=120)
    review_table.render_digest(digest, console=console)
    output = buf.getvalue()
    assert "No open PRs" in output


def test_table_render_default_console():
    digest = _make_digest(results=[_make_result()])
    review_table.render_digest(digest)


def test_table_render_critical_shows_concern():
    concern = ReviewConcern(
        category=ReviewCategory.SECURITY,
        severity=Severity.CRITICAL,
        description="SQL injection risk in user input handler",
    )
    result = _make_result(risk=Severity.CRITICAL, concerns=[concern])
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=True, width=120)
    review_table.render_digest(_make_digest(results=[result]), console=console)
    output = buf.getvalue()
    assert "security" in output.lower()


def test_table_render_stale_pr():
    result = _make_result(age_days=14)
    digest = _make_digest(results=[result], stale_days=7)
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=True, width=120)
    review_table.render_digest(digest, console=console)
    output = buf.getvalue()
    assert "14d" in output


def test_table_render_with_errors():
    digest = _make_digest(errors=["Failed to fetch org/broken"])
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=True, width=120)
    review_table.render_digest(digest, console=console)
    output = buf.getvalue()
    assert "Error" in output


def test_table_render_summary_panel():
    digest = _make_digest(results=[
        _make_result(risk=Severity.CRITICAL, number=1),
        _make_result(risk=Severity.HIGH, number=2),
        _make_result(risk=Severity.LOW, number=3),
    ])
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=True, width=120)
    review_table.render_digest(digest, console=console)
    output = buf.getvalue()
    assert "3 PRs" in output


def test_table_recommendation_styles():
    results = [
        _make_result(risk=Severity.LOW, number=1, recommendation="approve"),
        _make_result(risk=Severity.HIGH, number=2, recommendation="request_changes"),
        _make_result(risk=Severity.MEDIUM, number=3, recommendation="needs_discussion"),
    ]
    digest = _make_digest(results=results)
    console = Console(file=None, force_terminal=True, width=120)
    review_table.render_digest(digest, console=console)


# --- Markdown output ---


def test_markdown_render_basic():
    digest = _make_digest(results=[_make_result()])
    output = review_markdown.render_digest(digest)
    assert "# PR Review Digest" in output
    assert "org/repo" in output
    assert "@me" in output


def test_markdown_render_empty():
    digest = _make_digest()
    output = review_markdown.render_digest(digest)
    assert "No open PRs" in output
    assert "Total PRs:** 0" in output


def test_markdown_render_grouped_by_risk():
    digest = _make_digest(results=[
        _make_result(risk=Severity.CRITICAL, number=1),
        _make_result(risk=Severity.HIGH, number=2),
        _make_result(risk=Severity.LOW, number=3),
    ])
    output = review_markdown.render_digest(digest)
    assert "Critical Risk" in output
    assert "High Risk" in output
    assert "Low Risk" in output


def test_markdown_render_concerns_for_critical():
    concern = ReviewConcern(
        category=ReviewCategory.SECURITY,
        severity=Severity.CRITICAL,
        description="XSS vulnerability",
        file_path="src/views.py",
        suggestion="Sanitize output",
    )
    result = _make_result(risk=Severity.CRITICAL, concerns=[concern])
    digest = _make_digest(results=[result])
    output = review_markdown.render_digest(digest)
    assert "XSS vulnerability" in output
    assert "src/views.py" in output
    assert "Sanitize output" in output


def test_markdown_render_no_concerns_for_low():
    concern = ReviewConcern(
        category=ReviewCategory.CODE_QUALITY,
        severity=Severity.LOW,
        description="Minor issue",
    )
    result = _make_result(risk=Severity.LOW, concerns=[concern])
    digest = _make_digest(results=[result])
    output = review_markdown.render_digest(digest)
    # Low risk concerns should not have their own section
    assert "Minor issue" not in output


def test_markdown_render_with_errors():
    digest = _make_digest(errors=["Repo fetch failed"])
    output = review_markdown.render_digest(digest)
    assert "Errors" in output
    assert "Repo fetch failed" in output


def test_markdown_render_summary():
    digest = _make_digest(results=[
        _make_result(risk=Severity.CRITICAL, number=1),
        _make_result(risk=Severity.LOW, number=2),
    ])
    output = review_markdown.render_digest(digest)
    assert "Summary" in output
    assert "Critical" in output


def test_markdown_render_stale_count():
    digest = _make_digest(
        results=[_make_result(age_days=14, number=1)],
        stale_days=7,
    )
    output = review_markdown.render_digest(digest)
    assert "Stale:** 1" in output


def test_markdown_render_date():
    digest = _make_digest()
    output = review_markdown.render_digest(digest)
    assert "2024-01-15" in output


def test_table_title_truncation_boundary():
    """Test PR title at exactly the 35-char truncation boundary."""
    for length in [34, 35, 36]:
        pr = _make_pr()
        pr.title = "T" * length
        result = _make_result()
        result.pr = pr
        digest = _make_digest(results=[result])
        buf = io.StringIO()
        console = Console(file=buf, force_terminal=True, width=200)
        review_table.render_digest(digest, console=console)
        output = buf.getvalue()
        if length > 35:
            assert "..." in output


def test_markdown_pipe_in_pr_title():
    """Pipe characters in PR title are escaped in markdown tables."""
    pr = _make_pr()
    pr.title = "Fix | operator handling"
    result = PRReviewResult(
        pr=pr,
        risk_level=Severity.MEDIUM,
        summary="Risk: medium",
        approval_recommendation="approve",
        estimated_review_time="5 min",
    )
    digest = _make_digest(results=[result])
    output = review_markdown.render_digest(digest)
    assert "Fix \\| operator handling" in output


def test_markdown_special_chars_escaped():
    """Markdown formatting chars in PR title are escaped in table cells."""
    pr = _make_pr()
    pr.title = "*bold* `code` [link](url) _italic_"
    result = PRReviewResult(
        pr=pr,
        risk_level=Severity.MEDIUM,
        summary="Risk: medium",
        approval_recommendation="approve",
        estimated_review_time="5 min",
    )
    digest = _make_digest(results=[result])
    output = review_markdown.render_digest(digest)
    assert "\\*bold\\*" in output
    assert "\\`code\\`" in output
    assert "\\[link\\]" in output
    assert "\\_italic\\_" in output
