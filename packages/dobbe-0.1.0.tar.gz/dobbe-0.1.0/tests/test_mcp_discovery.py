"""Tests for MCP discovery."""

from unittest.mock import patch
import json

from dobbe.core.mcp_discovery import (
    discover_mcps,
    get_mcp_tool_prefix,
    _classify_mcp,
    KNOWN_MCPS,
)


def test_classify_mcp_github():
    assert _classify_mcp("github", {}) == "github"
    assert _classify_mcp("my-github-server", {}) == "github"
    assert _classify_mcp("github", {"command": "something"}) == "github"
    assert _classify_mcp("unrelated", {}) is None


def test_classify_mcp_slack():
    assert _classify_mcp("slack", {}) == "slack"
    assert _classify_mcp("my-slack-bot", {}) == "slack"


def test_classify_mcp_from_command():
    config = {"command": "npx", "args": ["@github/mcp-server"]}
    assert _classify_mcp("my-server", config) == "github"


def test_get_mcp_tool_prefix():
    assert get_mcp_tool_prefix("github") == "mcp__github__*"
    assert get_mcp_tool_prefix("slack") == "mcp__claude_ai_Slack__*"
    assert get_mcp_tool_prefix("unknown") == "mcp__unknown__*"


@patch("dobbe.core.mcp_discovery._read_claude_settings")
@patch("dobbe.core.mcp_discovery._read_project_settings")
def test_discover_mcps_empty(mock_project, mock_user):
    mock_user.return_value = {}
    mock_project.return_value = {}
    result = discover_mcps()
    assert all(v is False for v in result.values())
    for name in KNOWN_MCPS:
        assert name in result


@patch("dobbe.core.mcp_discovery._read_claude_settings")
@patch("dobbe.core.mcp_discovery._read_project_settings")
def test_discover_mcps_with_github(mock_project, mock_user):
    mock_user.return_value = {
        "mcpServers": {
            "github": {"command": "npx", "args": ["@github/mcp-server"]},
        }
    }
    mock_project.return_value = {}
    result = discover_mcps()
    assert result["github"] is True
    assert result["slack"] is False


@patch("dobbe.core.mcp_discovery._read_claude_settings")
@patch("dobbe.core.mcp_discovery._read_project_settings")
def test_discover_mcps_with_plugins(mock_project, mock_user):
    mock_user.return_value = {
        "enabledPlugins": ["claude_ai_Slack", "claude_ai_Atlassian"]
    }
    mock_project.return_value = {}
    result = discover_mcps()
    assert result["slack"] is True
    assert result["atlassian"] is True
    assert result["github"] is False


# --- Additional classification tests ---

from dobbe.core.mcp_discovery import _find_mcp_servers_in_settings


def test_classify_mcp_atlassian():
    assert _classify_mcp("atlassian", {}) == "atlassian"


def test_classify_mcp_jira_maps_to_atlassian():
    assert _classify_mcp("jira-server", {}) == "atlassian"


def test_classify_mcp_sentry_from_args():
    config = {"command": "npx", "args": ["@sentry/mcp"]}
    assert _classify_mcp("my-error-tracker", config) == "sentry"


def test_find_mcp_servers_lowercases_names():
    settings = {"mcpServers": {"GitHub": {"command": "npx"}}}
    servers = _find_mcp_servers_in_settings(settings)
    assert "github" in servers
    assert "GitHub" not in servers


@patch("dobbe.core.mcp_discovery._read_claude_settings")
@patch("dobbe.core.mcp_discovery._read_project_settings")
def test_discover_mcps_project_and_user_merge(mock_project, mock_user):
    mock_user.return_value = {
        "mcpServers": {"github": {"command": "npx", "args": ["@github/mcp-server"]}}
    }
    mock_project.return_value = {
        "mcpServers": {"my-slack-bot": {"command": "node", "args": ["slack-server"]}}
    }
    result = discover_mcps()
    assert result["github"] is True
    assert result["slack"] is True


# --- Real file reads ---

from dobbe.core.mcp_discovery import _read_claude_settings, _read_project_settings


def test_read_claude_settings_valid_file(tmp_path, monkeypatch):
    settings_dir = tmp_path / ".claude"
    settings_dir.mkdir()
    settings_file = settings_dir / "settings.json"
    settings_file.write_text(json.dumps({"mcpServers": {"github": {}}}))
    monkeypatch.setattr("dobbe.core.mcp_discovery.Path.home", lambda: tmp_path)
    result = _read_claude_settings()
    assert "mcpServers" in result
    assert "github" in result["mcpServers"]


def test_read_claude_settings_missing_file(tmp_path, monkeypatch):
    monkeypatch.setattr("dobbe.core.mcp_discovery.Path.home", lambda: tmp_path)
    result = _read_claude_settings()
    assert result == {}


def test_read_claude_settings_invalid_json(tmp_path, monkeypatch):
    settings_dir = tmp_path / ".claude"
    settings_dir.mkdir()
    settings_file = settings_dir / "settings.json"
    settings_file.write_text("not valid json {{{")
    monkeypatch.setattr("dobbe.core.mcp_discovery.Path.home", lambda: tmp_path)
    result = _read_claude_settings()
    assert result == {}


def test_read_project_settings_valid(tmp_path, monkeypatch):
    settings_dir = tmp_path / ".claude"
    settings_dir.mkdir()
    settings_file = settings_dir / "settings.json"
    settings_file.write_text(json.dumps({"mcpServers": {"slack-bot": {}}}))
    monkeypatch.chdir(tmp_path)
    result = _read_project_settings()
    assert "mcpServers" in result


# --- Classify branches from args ---


def test_classify_mcp_figma_from_args():
    config = {"command": "npx", "args": ["figma-mcp"]}
    assert _classify_mcp("my-design-tool", config) == "figma"


def test_classify_mcp_jira_from_args():
    config = {"command": "npx", "args": ["jira-tool"]}
    assert _classify_mcp("my-ticketing", config) == "atlassian"


def test_classify_mcp_slack_from_args():
    config = {"command": "node", "args": ["slack-server"]}
    assert _classify_mcp("my-chat", config) == "slack"


# --- Plugin classification for sentry and figma ---


@patch("dobbe.core.mcp_discovery._read_claude_settings")
@patch("dobbe.core.mcp_discovery._read_project_settings")
def test_discover_mcps_plugin_sentry_figma(mock_project, mock_user):
    mock_user.return_value = {
        "enabledPlugins": ["claude_ai_Sentry", "claude_ai_Figma"]
    }
    mock_project.return_value = {}
    result = discover_mcps()
    assert result["sentry"] is True
    assert result["figma"] is True
    assert result["github"] is False


@patch("dobbe.core.mcp_discovery._read_claude_settings")
@patch("dobbe.core.mcp_discovery._read_project_settings")
def test_discover_mcps_corrupt_data_graceful_fallback(mock_project, mock_user):
    """If settings contain unexpected types, discover_mcps returns all-False instead of crashing."""
    mock_user.return_value = {"mcpServers": "not-a-dict"}
    mock_project.return_value = {}
    result = discover_mcps()
    assert all(v is False for v in result.values())
    for name in KNOWN_MCPS:
        assert name in result


# --- MCP discovery cache ---


@patch("dobbe.core.mcp_discovery._read_claude_settings")
@patch("dobbe.core.mcp_discovery._read_project_settings")
def test_discover_mcps_cache_hit(mock_project, mock_user):
    """Second call returns cached result without re-reading settings files."""
    mock_user.return_value = {
        "mcpServers": {"github": {"command": "npx", "args": ["@github/mcp-server"]}}
    }
    mock_project.return_value = {}

    result1 = discover_mcps()
    assert result1["github"] is True

    # Clear mocks - second call should use cache
    mock_user.reset_mock()
    mock_project.reset_mock()

    result2 = discover_mcps()
    assert result2["github"] is True
    mock_user.assert_not_called()
    mock_project.assert_not_called()


@patch("dobbe.core.mcp_discovery._read_claude_settings")
@patch("dobbe.core.mcp_discovery._read_project_settings")
def test_discover_mcps_cache_returns_copy(mock_project, mock_user):
    """Cached result is a copy - mutations don't affect the cache."""
    mock_user.return_value = {
        "mcpServers": {"github": {"command": "npx", "args": ["@github/mcp-server"]}}
    }
    mock_project.return_value = {}

    result1 = discover_mcps()
    result1["github"] = False  # mutate

    result2 = discover_mcps()
    assert result2["github"] is True  # cache unaffected
