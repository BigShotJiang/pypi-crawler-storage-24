"""End-to-end CLI tests using typer.testing.CliRunner."""

from __future__ import annotations

import json
from unittest.mock import patch, MagicMock

from typer.testing import CliRunner

from dobbe.cli import app
from dobbe.core.claude import ClaudeResult
from dobbe.models.alert import AccessMode

runner = CliRunner()


# --- Basic CLI ---


def test_cli_version():
    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert "dobbe 0.1.0" in result.output


def test_cli_no_args_shows_help():
    result = runner.invoke(app, [])
    # Typer with no_args_is_help may use exit code 0 or 2
    assert result.exit_code in (0, 2)
    assert "Usage" in result.output or "usage" in result.output.lower()


def test_cli_help():
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "vuln" in result.output
    assert "config" in result.output
    assert "setup" in result.output


# --- Config Commands ---


@patch("dobbe.commands.doctor.run_doctor")
def test_cli_config_check(mock_doctor):
    """config check now shows deprecation warning and delegates to doctor."""
    mock_doctor.return_value = []
    result = runner.invoke(app, ["config", "check"])
    assert result.exit_code == 0
    assert "deprecated" in result.output.lower()
    mock_doctor.assert_called_once()


@patch("dobbe.commands.doctor.run_doctor")
def test_cli_config_check_no_config(mock_doctor):
    """config check shows deprecation warning even without config."""
    mock_doctor.return_value = []
    result = runner.invoke(app, ["config", "check"])
    assert result.exit_code == 0
    assert "deprecated" in result.output.lower() or "dobbe doctor" in result.output


@patch("dobbe.commands.config.CONFIG_FILE")
@patch("dobbe.commands.config.load_config")
def test_cli_config_show(mock_load, mock_config_file):
    mock_config_file.exists.return_value = True
    mock_load.return_value = {
        "general": {"default_org": "my-org", "default_format": "table", "default_severity": "critical,high"},
        "notifications": {"slack_channel": "#alerts"},
        "repos": {"local_paths": ["/a", "/b"]},
    }
    result = runner.invoke(app, ["config", "show"])
    assert result.exit_code == 0


@patch("dobbe.commands.config.CONFIG_FILE")
def test_cli_config_show_no_config(mock_config_file):
    mock_config_file.exists.return_value = False
    result = runner.invoke(app, ["config", "show"])
    assert result.exit_code == 1


# --- Setup Command ---


@patch("dobbe.commands.setup.is_claude_installed")
def test_cli_setup_claude_not_installed(mock_installed):
    mock_installed.return_value = False
    result = runner.invoke(app, ["setup"])
    assert result.exit_code == 1
    assert "not found" in result.output.lower() or "not installed" in result.output.lower() or "Install" in result.output


@patch("dobbe.commands.setup.check_claude_auth")
@patch("dobbe.commands.setup.is_claude_installed")
def test_cli_setup_auth_failure(mock_installed, mock_auth):
    mock_installed.return_value = True
    mock_auth.return_value = (False, "Not authenticated")
    result = runner.invoke(app, ["setup"])
    assert result.exit_code == 1


@patch("dobbe.core.state_manager.mark_setup_complete")
@patch("dobbe.commands.setup.subprocess")
@patch("dobbe.commands.setup.shutil")
@patch("dobbe.commands.setup.save_config")
@patch("dobbe.commands.setup._scan_for_repos")
@patch("dobbe.commands.setup.load_config")
@patch("dobbe.commands.setup.discover_mcps")
@patch("dobbe.commands.setup.check_claude_auth")
@patch("dobbe.commands.setup.is_claude_installed")
def test_cli_setup_full_success(mock_installed, mock_auth, mock_discover, mock_load, mock_scan, mock_save, mock_shutil, mock_sub, mock_mark):
    mock_installed.return_value = True
    mock_auth.return_value = (True, "Authenticated")
    mock_discover.return_value = {"github": True, "slack": False, "atlassian": False, "sentry": False, "figma": False}
    mock_load.return_value = {"general": {"default_org": ""}}
    mock_scan.return_value = ["/home/user/projects/repo1"]
    mock_save.return_value = MagicMock()
    mock_shutil.which.return_value = "/usr/local/bin/gh"
    mock_sub.run.return_value = MagicMock(returncode=0, stdout="42")
    result = runner.invoke(app, ["setup"], input="my-org\nall\n3\n")
    assert result.exit_code == 0
    assert "Setup complete" in result.output or "complete" in result.output.lower()


# --- Vuln Scan Command ---


@patch("dobbe.commands.vuln.load_config")
def test_cli_vuln_scan_no_repo_no_org(mock_load):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    result = runner.invoke(app, ["vuln", "scan"])
    assert result.exit_code == 1
    assert "Specify" in result.output or "repo" in result.output.lower()


def _make_valid_triage_json():
    return json.dumps({
        "groups": [{
            "package_name": "django",
            "package_ecosystem": "pip",
            "current_version": "4.2.5",
            "target_version": "4.2.8",
            "alerts": [{
                "alert_number": 1,
                "cve_id": "CVE-2024-0001",
                "package_name": "django",
                "severity": "critical",
                "summary": "SQL injection",
                "affected": True,
                "risk_level": "critical",
                "recommended_action": "Upgrade to 4.2.8",
            }],
        }]
    })


@patch("dobbe.commands.vuln.ask_claude")
@patch("dobbe.commands.vuln.resolve_repo")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_cli_vuln_scan_single_repo_table(mock_load, mock_discover, mock_resolve, mock_claude):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": False, "slack": False}
    mock_resolve.return_value = (AccessMode.REMOTE, None)
    mock_claude.return_value = ClaudeResult(success=True, text=_make_valid_triage_json())
    result = runner.invoke(app, ["vuln", "scan", "--repo", "org/repo"])
    assert result.exit_code == 0


@patch("dobbe.commands.vuln.ask_claude")
@patch("dobbe.commands.vuln.resolve_repo")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_cli_vuln_scan_json_format(mock_load, mock_discover, mock_resolve, mock_claude):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": False, "slack": False}
    mock_resolve.return_value = (AccessMode.REMOTE, None)
    mock_claude.return_value = ClaudeResult(success=True, text=_make_valid_triage_json())
    result = runner.invoke(app, ["vuln", "scan", "--repo", "org/repo", "--format", "json"])
    assert result.exit_code == 0
    # Output should contain JSON
    assert '"groups"' in result.output or '"repos"' in result.output


@patch("dobbe.commands.vuln.ask_claude")
@patch("dobbe.commands.vuln.resolve_repo")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_cli_vuln_scan_markdown_format(mock_load, mock_discover, mock_resolve, mock_claude):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": False, "slack": False}
    mock_resolve.return_value = (AccessMode.REMOTE, None)
    mock_claude.return_value = ClaudeResult(success=True, text=_make_valid_triage_json())
    result = runner.invoke(app, ["vuln", "scan", "--repo", "org/repo", "--format", "markdown"])
    assert result.exit_code == 0
    assert "Vulnerability Scan Report" in result.output


@patch("dobbe.commands.vuln.ask_claude")
@patch("dobbe.commands.vuln.resolve_repo")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_cli_vuln_scan_severity_filter(mock_load, mock_discover, mock_resolve, mock_claude):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": False, "slack": False}
    mock_resolve.return_value = (AccessMode.REMOTE, None)
    mock_claude.return_value = ClaudeResult(success=True, text=_make_valid_triage_json())
    result = runner.invoke(app, ["vuln", "scan", "--repo", "org/repo", "--severity", "critical"])
    assert result.exit_code == 0
    # Verify severity was passed to Claude
    call_args = mock_claude.call_args
    prompt_arg = call_args.kwargs.get("prompt", call_args.args[0] if call_args.args else "")
    assert "critical" in prompt_arg


@patch("dobbe.commands.vuln._handle_notification")
@patch("dobbe.commands.vuln.ask_claude")
@patch("dobbe.commands.vuln.resolve_repo")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_cli_vuln_scan_notify_slack(mock_load, mock_discover, mock_resolve, mock_claude, mock_notify):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": False, "slack": True}
    mock_resolve.return_value = (AccessMode.REMOTE, None)
    mock_claude.return_value = ClaudeResult(success=True, text=_make_valid_triage_json())
    result = runner.invoke(app, ["vuln", "scan", "--repo", "org/repo", "--notify", "slack", "--channel", "#sec"])
    assert result.exit_code == 0
    mock_notify.assert_called_once()
    call_args = mock_notify.call_args
    assert call_args[0][1] == "slack"  # platform arg
    assert call_args[0][2] == "#sec"   # channel arg


@patch("dobbe.commands.vuln._handle_notification")
@patch("dobbe.commands.vuln.ask_claude")
@patch("dobbe.commands.vuln.resolve_repo")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_cli_vuln_scan_notify_unknown_platform(mock_load, mock_discover, mock_resolve, mock_claude, mock_notify):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": False, "slack": False}
    mock_resolve.return_value = (AccessMode.REMOTE, None)
    mock_claude.return_value = ClaudeResult(success=True, text=_make_valid_triage_json())
    result = runner.invoke(app, ["vuln", "scan", "--repo", "org/repo", "--notify", "teams"])
    assert result.exit_code == 0
    mock_notify.assert_called_once()


# --- File write error handling (Bug C) ---


@patch("dobbe.commands.vuln.ask_claude")
@patch("dobbe.commands.vuln.resolve_repo")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_vuln_scan_output_write_error(mock_load, mock_discover, mock_resolve, mock_claude, tmp_path):
    """--output to unwritable path shows error instead of traceback (Bug C)."""
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": False, "slack": False}
    mock_resolve.return_value = (AccessMode.REMOTE, None)
    mock_claude.return_value = ClaudeResult(success=True, text=_make_valid_triage_json())
    bad_path = str(tmp_path / "nonexistent_dir" / "output.json")
    result = runner.invoke(app, ["vuln", "scan", "--repo", "org/repo", "--format", "json", "--output", bad_path])
    assert result.exit_code == 1
    assert "Failed to write" in result.output


@patch("dobbe.commands.review.run_review_digest")
@patch("dobbe.commands.review.discover_mcps")
@patch("dobbe.commands.review.load_config")
def test_review_digest_output_write_error(mock_load, mock_discover, mock_digest, tmp_path):
    """--output to unwritable path shows error instead of traceback (Bug C)."""
    from dobbe.models.review import ReviewDigest
    mock_load.return_value = {"general": {"default_org": "", "default_format": "json"}}
    mock_discover.return_value = {"github": False, "slack": False}
    mock_digest.return_value = ReviewDigest(reviewers=["@me"], repos_scanned=["org/repo"], results=[])
    bad_path = str(tmp_path / "nonexistent_dir" / "output.json")
    result = runner.invoke(app, ["review", "digest", "--repo", "org/repo", "--format", "json", "--output", bad_path, "--quiet"])
    assert result.exit_code == 1
    assert "Failed to write" in result.output


# --- Org listing path ---


@patch("dobbe.commands.vuln.ask_claude")
@patch("dobbe.core.org_repos.ask_claude")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_cli_vuln_scan_org_success(mock_load, mock_discover, mock_list_claude, mock_scan_claude):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": True, "slack": False}

    mock_list_claude.return_value = ClaudeResult(success=True, text='["my-org/repo1"]')
    mock_scan_claude.return_value = ClaudeResult(success=True, text=_make_valid_triage_json())

    with patch("dobbe.commands.vuln.resolve_repo", return_value=(AccessMode.REMOTE, None)):
        result = runner.invoke(app, ["vuln", "scan", "--org", "my-org"])
    assert result.exit_code == 0


@patch("dobbe.core.org_repos.ask_claude")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_cli_vuln_scan_org_list_failure(mock_load, mock_discover, mock_claude):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": True, "slack": False}
    mock_claude.return_value = ClaudeResult(success=False, error="Claude down")
    result = runner.invoke(app, ["vuln", "scan", "--org", "my-org"])
    assert result.exit_code == 1


@patch("dobbe.core.org_repos.ask_claude")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_cli_vuln_scan_org_bad_json(mock_load, mock_discover, mock_claude):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": True, "slack": False}
    mock_claude.return_value = ClaudeResult(success=True, text="No repos found in this org.")
    result = runner.invoke(app, ["vuln", "scan", "--org", "my-org"])
    assert result.exit_code == 1


@patch("dobbe.core.org_repos.ask_claude")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_cli_vuln_scan_org_empty_list(mock_load, mock_discover, mock_claude):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": True, "slack": False}
    mock_claude.return_value = ClaudeResult(success=True, text="[]")
    result = runner.invoke(app, ["vuln", "scan", "--org", "my-org"])
    assert result.exit_code == 0
    assert "No repos" in result.output


@patch("dobbe.commands.vuln._scan_repos_parallel")
@patch("dobbe.core.org_repos.ask_claude")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_cli_vuln_scan_org_multi_repo(mock_load, mock_discover, mock_claude, mock_parallel):
    from dobbe.models.alert import RepoResult

    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": True, "slack": False}
    mock_claude.return_value = ClaudeResult(success=True, text='["org/r1", "org/r2"]')
    mock_parallel.return_value = [
        RepoResult(repo="org/r1", access_mode=AccessMode.REMOTE, groups=[]),
        RepoResult(repo="org/r2", access_mode=AccessMode.REMOTE, groups=[]),
    ]
    result = runner.invoke(app, ["vuln", "scan", "--org", "org"])
    assert result.exit_code == 0


@patch("dobbe.commands.vuln.ask_claude")
@patch("dobbe.commands.vuln.resolve_repo")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_cli_vuln_scan_invalid_severity(mock_load, mock_discover, mock_resolve, mock_claude):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": False, "slack": False}
    mock_resolve.return_value = (AccessMode.REMOTE, None)
    mock_claude.return_value = ClaudeResult(success=True, text=_make_valid_triage_json())
    result = runner.invoke(app, ["vuln", "scan", "--repo", "org/repo", "--severity", "critical,bogus"])
    assert result.exit_code == 0


# --- Setup command coverage ---


def test_scan_for_repos_finds_git_dirs(tmp_path, monkeypatch):
    from dobbe.commands.setup import _scan_for_repos

    repo1 = tmp_path / "repo1"
    repo1.mkdir()
    (repo1 / ".git").mkdir()
    repo2 = tmp_path / "repo2"
    repo2.mkdir()
    (repo2 / ".git").mkdir()

    monkeypatch.setattr("dobbe.commands.setup.COMMON_PROJECT_DIRS", [tmp_path])
    found = _scan_for_repos()
    assert len(found) == 2
    assert str(repo1) in found
    assert str(repo2) in found


def test_scan_for_repos_skips_non_git(tmp_path, monkeypatch):
    from dobbe.commands.setup import _scan_for_repos

    nongit = tmp_path / "nongit"
    nongit.mkdir()
    # No .git dir

    monkeypatch.setattr("dobbe.commands.setup.COMMON_PROJECT_DIRS", [tmp_path])
    found = _scan_for_repos()
    assert len(found) == 0


def test_scan_for_repos_empty(tmp_path, monkeypatch):
    from dobbe.commands.setup import _scan_for_repos

    monkeypatch.setattr("dobbe.commands.setup.COMMON_PROJECT_DIRS", [tmp_path / "nonexistent"])
    found = _scan_for_repos()
    assert found == []


@patch("dobbe.core.state_manager.mark_setup_complete")
@patch("dobbe.commands.setup.subprocess")
@patch("dobbe.commands.setup.shutil")
@patch("dobbe.commands.setup.save_config")
@patch("dobbe.commands.setup._scan_for_repos")
@patch("dobbe.commands.setup.load_config")
@patch("dobbe.commands.setup.discover_mcps")
@patch("dobbe.commands.setup.check_claude_auth")
@patch("dobbe.commands.setup.is_claude_installed")
def test_cli_setup_no_github_mcp_warning(mock_installed, mock_auth, mock_discover, mock_load, mock_scan, mock_save, mock_shutil, mock_sub, mock_mark):
    mock_installed.return_value = True
    mock_auth.return_value = (True, "Authenticated")
    mock_discover.return_value = {"github": False, "slack": False, "atlassian": False, "sentry": False, "figma": False}
    mock_load.return_value = {"general": {"default_org": ""}}
    mock_scan.return_value = []
    mock_save.return_value = MagicMock()
    mock_shutil.which.return_value = None
    mock_sub.run.return_value = MagicMock(returncode=1, stdout="")
    result = runner.invoke(app, ["setup"], input="my-org\n3\n")
    assert result.exit_code == 0
    assert "Warning" in result.output


@patch("dobbe.core.state_manager.mark_setup_complete")
@patch("dobbe.commands.setup.subprocess")
@patch("dobbe.commands.setup.shutil")
@patch("dobbe.commands.setup.save_config")
@patch("dobbe.commands.setup._scan_for_repos")
@patch("dobbe.commands.setup.load_config")
@patch("dobbe.commands.setup.discover_mcps")
@patch("dobbe.commands.setup.check_claude_auth")
@patch("dobbe.commands.setup.is_claude_installed")
def test_cli_setup_many_repos(mock_installed, mock_auth, mock_discover, mock_load, mock_scan, mock_save, mock_shutil, mock_sub, mock_mark):
    mock_installed.return_value = True
    mock_auth.return_value = (True, "Authenticated")
    mock_discover.return_value = {"github": True, "slack": False, "atlassian": False, "sentry": False, "figma": False}
    mock_load.return_value = {"general": {"default_org": ""}}
    mock_scan.return_value = [f"/home/user/projects/repo{i}" for i in range(15)]
    mock_save.return_value = MagicMock()
    mock_shutil.which.return_value = "/usr/local/bin/gh"
    mock_sub.run.return_value = MagicMock(returncode=0, stdout="42")
    result = runner.invoke(app, ["setup"], input="my-org\nall\n3\n")
    assert result.exit_code == 0
    # All 15 repos shown in numbered list
    assert "[15]" in result.output


def test_cli_broken_command_shows_unavailable():
    """A broken command module should show [UNAVAILABLE] instead of crashing the CLI."""
    import importlib
    from unittest.mock import patch as _patch

    # Temporarily make vuln import fail
    real_import = importlib.import_module

    def _failing_import(name, *args, **kwargs):
        if name == "dobbe.commands.vuln":
            raise ImportError("simulated broken import")
        return real_import(name, *args, **kwargs)

    with _patch("importlib.import_module", side_effect=_failing_import):
        # Re-create the app with the broken import
        import typer
        from dobbe import __version__

        test_app = typer.Typer(name="dobbe", help="Test app", no_args_is_help=True)

        from dobbe.cli import _register_command as _reg

        # Monkey-patch target app temporarily
        original_app = None
        import dobbe.cli as cli_mod
        original_app = cli_mod.app
        cli_mod.app = test_app

        try:
            _reg("dobbe.commands.vuln", "vuln_app", "vuln", "Vulnerability scanning and triage.")
            _reg("dobbe.commands.config", "config_app", "config", "View and manage configuration.")
        finally:
            cli_mod.app = original_app

    # The test_app should have vuln as [UNAVAILABLE] and config working
    test_runner = CliRunner()
    result = test_runner.invoke(test_app, ["--help"])
    assert "UNAVAILABLE" in result.output
    assert "config" in result.output


@patch("dobbe.core.state_manager.mark_setup_complete")
@patch("dobbe.commands.setup.subprocess")
@patch("dobbe.commands.setup.shutil")
@patch("dobbe.commands.setup.save_config")
@patch("dobbe.commands.setup._scan_for_repos")
@patch("dobbe.commands.setup.load_config")
@patch("dobbe.commands.setup.discover_mcps")
@patch("dobbe.commands.setup.check_claude_auth")
@patch("dobbe.commands.setup.is_claude_installed")
def test_cli_setup_preserves_notifications(mock_installed, mock_auth, mock_discover, mock_load, mock_scan, mock_save, mock_shutil, mock_sub, mock_mark):
    mock_installed.return_value = True
    mock_auth.return_value = (True, "Authenticated")
    mock_discover.return_value = {"github": True, "slack": False, "atlassian": False, "sentry": False, "figma": False}
    mock_load.return_value = {
        "general": {"default_org": "old-org"},
        "notifications": {"slack_channel": "#existing"},
    }
    mock_scan.return_value = []
    mock_save.return_value = MagicMock()
    mock_shutil.which.return_value = "/usr/local/bin/gh"
    mock_sub.run.return_value = MagicMock(returncode=0, stdout="42")
    result = runner.invoke(app, ["setup"], input="new-org\n3\n")
    assert result.exit_code == 0
    saved_config = mock_save.call_args[0][0]
    assert saved_config["notifications"]["slack_channel"] == "#existing"


# --- Setup B1: Org verification ---


@patch("dobbe.core.state_manager.mark_setup_complete")
@patch("dobbe.commands.setup.subprocess")
@patch("dobbe.commands.setup.shutil")
@patch("dobbe.commands.setup.save_config")
@patch("dobbe.commands.setup._scan_for_repos")
@patch("dobbe.commands.setup.load_config")
@patch("dobbe.commands.setup.discover_mcps")
@patch("dobbe.commands.setup.check_claude_auth")
@patch("dobbe.commands.setup.is_claude_installed")
def test_cli_setup_org_verified(mock_installed, mock_auth, mock_discover, mock_load, mock_scan, mock_save, mock_shutil, mock_sub, mock_mark):
    mock_installed.return_value = True
    mock_auth.return_value = (True, "Authenticated")
    mock_discover.return_value = {"github": True, "slack": False, "atlassian": False, "sentry": False, "figma": False}
    mock_load.return_value = {"general": {"default_org": ""}}
    mock_scan.return_value = []
    mock_save.return_value = MagicMock()
    mock_shutil.which.return_value = "/usr/local/bin/gh"
    mock_sub.run.return_value = MagicMock(returncode=0, stdout="42")
    result = runner.invoke(app, ["setup"], input="my-org\n3\n")
    assert result.exit_code == 0
    assert "Organization verified" in result.output


# --- Setup B2: Interactive repo selection ---


@patch("dobbe.core.state_manager.mark_setup_complete")
@patch("dobbe.commands.setup.subprocess")
@patch("dobbe.commands.setup.shutil")
@patch("dobbe.commands.setup.save_config")
@patch("dobbe.commands.setup._scan_for_repos")
@patch("dobbe.commands.setup.load_config")
@patch("dobbe.commands.setup.discover_mcps")
@patch("dobbe.commands.setup.check_claude_auth")
@patch("dobbe.commands.setup.is_claude_installed")
def test_cli_setup_repo_selection_specific(mock_installed, mock_auth, mock_discover, mock_load, mock_scan, mock_save, mock_shutil, mock_sub, mock_mark):
    mock_installed.return_value = True
    mock_auth.return_value = (True, "Authenticated")
    mock_discover.return_value = {"github": True, "slack": False, "atlassian": False, "sentry": False, "figma": False}
    mock_load.return_value = {"general": {"default_org": ""}}
    mock_scan.return_value = ["/a/repo1", "/a/repo2", "/a/repo3"]
    mock_save.return_value = MagicMock()
    mock_shutil.which.return_value = "/usr/local/bin/gh"
    mock_sub.run.return_value = MagicMock(returncode=0, stdout="10")
    # Select only repos 1 and 3
    result = runner.invoke(app, ["setup"], input="my-org\n1,3\n3\n")
    assert result.exit_code == 0
    saved = mock_save.call_args[0][0]
    assert saved["repos"]["local_paths"] == ["/a/repo1", "/a/repo3"]


@patch("dobbe.core.state_manager.mark_setup_complete")
@patch("dobbe.commands.setup.subprocess")
@patch("dobbe.commands.setup.shutil")
@patch("dobbe.commands.setup.save_config")
@patch("dobbe.commands.setup._scan_for_repos")
@patch("dobbe.commands.setup.load_config")
@patch("dobbe.commands.setup.discover_mcps")
@patch("dobbe.commands.setup.check_claude_auth")
@patch("dobbe.commands.setup.is_claude_installed")
def test_cli_setup_repo_selection_none(mock_installed, mock_auth, mock_discover, mock_load, mock_scan, mock_save, mock_shutil, mock_sub, mock_mark):
    mock_installed.return_value = True
    mock_auth.return_value = (True, "Authenticated")
    mock_discover.return_value = {"github": True, "slack": False, "atlassian": False, "sentry": False, "figma": False}
    mock_load.return_value = {"general": {"default_org": ""}}
    mock_scan.return_value = ["/a/repo1", "/a/repo2"]
    mock_save.return_value = MagicMock()
    mock_shutil.which.return_value = "/usr/local/bin/gh"
    mock_sub.run.return_value = MagicMock(returncode=0, stdout="10")
    result = runner.invoke(app, ["setup"], input="my-org\nnone\n3\n")
    assert result.exit_code == 0
    saved = mock_save.call_args[0][0]
    assert saved["repos"]["local_paths"] == []


# --- Setup B3: gh CLI check ---


@patch("dobbe.core.state_manager.mark_setup_complete")
@patch("dobbe.commands.setup.subprocess")
@patch("dobbe.commands.setup.shutil")
@patch("dobbe.commands.setup.save_config")
@patch("dobbe.commands.setup._scan_for_repos")
@patch("dobbe.commands.setup.load_config")
@patch("dobbe.commands.setup.discover_mcps")
@patch("dobbe.commands.setup.check_claude_auth")
@patch("dobbe.commands.setup.is_claude_installed")
def test_cli_setup_no_gh_cli_warning(mock_installed, mock_auth, mock_discover, mock_load, mock_scan, mock_save, mock_shutil, mock_sub, mock_mark):
    mock_installed.return_value = True
    mock_auth.return_value = (True, "Authenticated")
    mock_discover.return_value = {"github": False, "slack": False, "atlassian": False, "sentry": False, "figma": False}
    mock_load.return_value = {"general": {"default_org": ""}}
    mock_scan.return_value = []
    mock_save.return_value = MagicMock()
    mock_shutil.which.return_value = None  # gh not available
    mock_sub.run.return_value = MagicMock(returncode=1, stdout="")
    result = runner.invoke(app, ["setup"], input="my-org\n3\n")
    assert result.exit_code == 0
    assert "gh CLI not found" in result.output
    assert "cli.github.com" in result.output


# --- Setup B4: Smoke test ---


@patch("dobbe.core.state_manager.mark_setup_complete")
@patch("dobbe.commands.setup.subprocess")
@patch("dobbe.commands.setup.shutil")
@patch("dobbe.commands.setup.save_config")
@patch("dobbe.commands.setup._scan_for_repos")
@patch("dobbe.commands.setup.load_config")
@patch("dobbe.commands.setup.discover_mcps")
@patch("dobbe.commands.setup.check_claude_auth")
@patch("dobbe.commands.setup.is_claude_installed")
def test_cli_setup_smoke_test_output(mock_installed, mock_auth, mock_discover, mock_load, mock_scan, mock_save, mock_shutil, mock_sub, mock_mark):
    mock_installed.return_value = True
    mock_auth.return_value = (True, "Authenticated")
    mock_discover.return_value = {"github": True, "slack": True, "atlassian": False, "sentry": False, "figma": False}
    mock_load.return_value = {"general": {"default_org": ""}}
    mock_scan.return_value = []
    mock_save.return_value = MagicMock()
    mock_shutil.which.return_value = "/usr/local/bin/gh"
    mock_sub.run.return_value = MagicMock(returncode=0, stdout="15")
    result = runner.invoke(app, ["setup"], input="acme\n3\n")
    assert result.exit_code == 0
    assert "Verifying setup" in result.output
    assert "Config saved" in result.output
    assert "GitHub access works" in result.output


# --- Setup E1: Post-setup menu ---


@patch("dobbe.core.state_manager.mark_setup_complete")
@patch("dobbe.commands.setup.subprocess")
@patch("dobbe.commands.setup.shutil")
@patch("dobbe.commands.setup.save_config")
@patch("dobbe.commands.setup._scan_for_repos")
@patch("dobbe.commands.setup.load_config")
@patch("dobbe.commands.setup.discover_mcps")
@patch("dobbe.commands.setup.check_claude_auth")
@patch("dobbe.commands.setup.is_claude_installed")
def test_cli_setup_post_menu_scan(mock_installed, mock_auth, mock_discover, mock_load, mock_scan, mock_save, mock_shutil, mock_sub, mock_mark):
    mock_installed.return_value = True
    mock_auth.return_value = (True, "Authenticated")
    mock_discover.return_value = {"github": True, "slack": False, "atlassian": False, "sentry": False, "figma": False}
    mock_load.return_value = {"general": {"default_org": ""}}
    mock_scan.return_value = []
    mock_save.return_value = MagicMock()
    mock_shutil.which.return_value = "/usr/local/bin/gh"
    mock_sub.run.return_value = MagicMock(returncode=0, stdout="10")
    # Choose option 1 (scan) in post-setup menu
    result = runner.invoke(app, ["setup"], input="my-org\n1\n")
    assert result.exit_code == 0
    assert "dobbe vuln scan" in result.output


# --- Doctor command ---


@patch("dobbe.commands.doctor.run_doctor")
def test_cli_doctor_via_config_check(mock_doctor):
    """config check delegates to doctor with deprecation warning."""
    mock_doctor.return_value = []
    result = runner.invoke(app, ["config", "check"])
    assert result.exit_code == 0
    assert "deprecated" in result.output.lower()
    mock_doctor.assert_called_once()


# --- First-run E2E ---


def test_cli_first_run_prompt_shown(monkeypatch):
    """First run triggers setup prompt when config is missing."""
    from dobbe.core.first_run import invalidate_first_run_flag
    invalidate_first_run_flag()
    mock_cf = MagicMock()
    mock_cf.exists.return_value = False
    monkeypatch.setattr("dobbe.core.first_run.CONFIG_FILE", mock_cf)
    monkeypatch.delenv("CI", raising=False)
    # Answer 'n' to the setup prompt, then the command fails as expected
    result = runner.invoke(app, ["vuln", "scan"], input="n\n")
    assert "Welcome to dobbe" in result.output
    assert "first run" in result.output.lower()


# --- Unit tests for setup helper functions ---


def test_verify_org_success():
    from dobbe.commands.setup import _verify_org
    with patch("dobbe.commands.setup.shutil") as mock_shutil, \
         patch("dobbe.commands.setup.subprocess") as mock_sub, \
         patch("dobbe.commands.setup.console"):
        mock_shutil.which.return_value = "/usr/local/bin/gh"
        mock_sub.run.return_value = MagicMock(returncode=0, stdout="42")
        assert _verify_org("my-org") is True


def test_verify_org_not_found():
    from dobbe.commands.setup import _verify_org
    with patch("dobbe.commands.setup.shutil") as mock_shutil, \
         patch("dobbe.commands.setup.subprocess") as mock_sub, \
         patch("dobbe.commands.setup.console"):
        mock_shutil.which.return_value = "/usr/local/bin/gh"
        mock_sub.run.return_value = MagicMock(returncode=1, stdout="")
        assert _verify_org("bad-org") is False


def test_verify_org_no_gh():
    from dobbe.commands.setup import _verify_org
    with patch("dobbe.commands.setup.shutil") as mock_shutil:
        mock_shutil.which.return_value = None
        assert _verify_org("my-org") is False


def test_verify_org_empty():
    from dobbe.commands.setup import _verify_org
    assert _verify_org("") is False


def test_verify_org_timeout():
    import subprocess as real_subprocess
    from dobbe.commands.setup import _verify_org
    with patch("dobbe.commands.setup.shutil") as mock_shutil, \
         patch("dobbe.commands.setup.subprocess") as mock_sub, \
         patch("dobbe.commands.setup.console"):
        mock_shutil.which.return_value = "/usr/local/bin/gh"
        mock_sub.run.side_effect = real_subprocess.TimeoutExpired("gh", 15)
        mock_sub.TimeoutExpired = real_subprocess.TimeoutExpired
        assert _verify_org("my-org") is False


def test_select_repos_all():
    from dobbe.commands.setup import _select_repos
    with patch("dobbe.commands.setup.typer") as mock_typer, \
         patch("dobbe.commands.setup.console"):
        mock_typer.prompt.return_value = "all"
        result = _select_repos(["/a", "/b", "/c"])
    assert result == ["/a", "/b", "/c"]


def test_select_repos_none():
    from dobbe.commands.setup import _select_repos
    with patch("dobbe.commands.setup.typer") as mock_typer, \
         patch("dobbe.commands.setup.console"):
        mock_typer.prompt.return_value = "none"
        result = _select_repos(["/a", "/b"])
    assert result == []


def test_select_repos_specific():
    from dobbe.commands.setup import _select_repos
    with patch("dobbe.commands.setup.typer") as mock_typer, \
         patch("dobbe.commands.setup.console"):
        mock_typer.prompt.return_value = "1,3"
        result = _select_repos(["/a", "/b", "/c"])
    assert result == ["/a", "/c"]


def test_select_repos_empty_found():
    from dobbe.commands.setup import _select_repos
    with patch("dobbe.commands.setup.console"):
        result = _select_repos([])
    assert result == []


def test_check_gh_cli_with_github_mcp():
    from dobbe.commands.setup import _check_gh_cli
    with patch("dobbe.commands.setup.console") as mock_console:
        _check_gh_cli(True)
    mock_console.print.assert_not_called()


def test_check_gh_cli_found():
    from dobbe.commands.setup import _check_gh_cli
    with patch("dobbe.commands.setup.shutil") as mock_shutil, \
         patch("dobbe.commands.setup.console") as mock_console:
        mock_shutil.which.return_value = "/usr/local/bin/gh"
        _check_gh_cli(False)
    assert any("gh CLI found" in str(c) for c in mock_console.print.call_args_list)


def test_post_setup_menu_review():
    from dobbe.commands.setup import _post_setup_menu
    with patch("dobbe.commands.setup.typer") as mock_typer, \
         patch("dobbe.commands.setup.subprocess") as mock_sub, \
         patch("dobbe.commands.setup.console"):
        mock_typer.prompt.return_value = "2"
        _post_setup_menu("my-org")
    mock_sub.run.assert_called_once()
    assert "review" in str(mock_sub.run.call_args)


def test_post_setup_menu_no_org():
    from dobbe.commands.setup import _post_setup_menu
    with patch("dobbe.commands.setup.typer") as mock_typer, \
         patch("dobbe.commands.setup.subprocess") as mock_sub, \
         patch("dobbe.commands.setup.console") as mock_console:
        mock_typer.prompt.return_value = "1"
        _post_setup_menu("")
    mock_sub.run.assert_not_called()
    assert any("No org" in str(c) for c in mock_console.print.call_args_list)


def test_smoke_test_no_gh_or_org():
    from dobbe.commands.setup import _run_smoke_test
    with patch("dobbe.commands.setup.shutil") as mock_shutil, \
         patch("dobbe.commands.setup.console"):
        mock_shutil.which.return_value = None
        _run_smoke_test("", {"github": False, "slack": False})


def test_smoke_test_gh_fails():
    from dobbe.commands.setup import _run_smoke_test
    with patch("dobbe.commands.setup.shutil") as mock_shutil, \
         patch("dobbe.commands.setup.subprocess") as mock_sub, \
         patch("dobbe.commands.setup.console"):
        mock_shutil.which.return_value = "/usr/local/bin/gh"
        mock_sub.run.return_value = MagicMock(returncode=1, stdout="")
        _run_smoke_test("my-org", {"github": False, "slack": False})


def test_smoke_test_gh_timeout():
    import subprocess as real_subprocess
    from dobbe.commands.setup import _run_smoke_test
    with patch("dobbe.commands.setup.shutil") as mock_shutil, \
         patch("dobbe.commands.setup.subprocess") as mock_sub, \
         patch("dobbe.commands.setup.console"):
        mock_shutil.which.return_value = "/usr/local/bin/gh"
        mock_sub.run.side_effect = real_subprocess.TimeoutExpired("gh", 15)
        mock_sub.TimeoutExpired = real_subprocess.TimeoutExpired
        _run_smoke_test("my-org", {"github": False, "slack": False})


def test_cli_first_run_suppressed_in_quiet(monkeypatch):
    """First-run prompt suppressed when DOBBE_QUIET=1."""
    from dobbe.core.first_run import invalidate_first_run_flag
    invalidate_first_run_flag()
    mock_cf = MagicMock()
    mock_cf.exists.return_value = False
    monkeypatch.setattr("dobbe.core.first_run.CONFIG_FILE", mock_cf)
    monkeypatch.setenv("DOBBE_QUIET", "1")
    result = runner.invoke(app, ["vuln", "scan"])
    assert "Welcome to dobbe" not in result.output


# =================================================================
# Gap 1: First-run accepted → setup → original command continues
# =================================================================


@patch("dobbe.commands.vuln.load_config")
@patch("dobbe.commands.setup.is_claude_installed")
def test_first_run_accepted_setup_then_command(mock_installed, mock_load, monkeypatch):
    """First-run → accept → setup fails (no claude) → original command still runs."""
    from dobbe.core.first_run import invalidate_first_run_flag
    invalidate_first_run_flag()
    mock_cf = MagicMock()
    mock_cf.exists.return_value = False
    monkeypatch.setattr("dobbe.core.first_run.CONFIG_FILE", mock_cf)
    monkeypatch.delenv("CI", raising=False)
    # Setup will fail because Claude not installed (BUG 1 fix catches typer.Exit)
    mock_installed.return_value = False
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    result = runner.invoke(app, ["vuln", "scan"], input="y\n")
    # BUG 1 fix: setup failure is caught, CLI continues
    assert "Setup did not complete" in result.output
    # Original command still attempts to run (will fail for other reasons, but NOT crash)
    assert result.exit_code in (0, 1)


# =================================================================
# Gap 2: First-run suppressed in CI at CLI level
# =================================================================


def test_cli_first_run_suppressed_in_ci(monkeypatch):
    """First-run prompt suppressed when CI=true at CLI invocation level."""
    from dobbe.core.first_run import invalidate_first_run_flag
    invalidate_first_run_flag()
    mock_cf = MagicMock()
    mock_cf.exists.return_value = False
    monkeypatch.setattr("dobbe.core.first_run.CONFIG_FILE", mock_cf)
    monkeypatch.setenv("CI", "true")
    result = runner.invoke(app, ["vuln", "scan"])
    assert "Welcome to dobbe" not in result.output


# =================================================================
# Gap 3: First-run triggers for non-vuln commands
# =================================================================


def test_cli_first_run_triggers_for_config_show(monkeypatch):
    """First-run prompt fires for config show, not just vuln scan."""
    from dobbe.core.first_run import invalidate_first_run_flag
    invalidate_first_run_flag()
    mock_cf = MagicMock()
    mock_cf.exists.return_value = False
    monkeypatch.setattr("dobbe.core.first_run.CONFIG_FILE", mock_cf)
    monkeypatch.delenv("CI", raising=False)
    result = runner.invoke(app, ["config", "show"], input="n\n")
    assert "Welcome to dobbe" in result.output


# =================================================================
# Gap 4: Org verification failure in full setup E2E
# =================================================================


@patch("dobbe.core.state_manager.mark_setup_complete")
@patch("dobbe.commands.setup.subprocess")
@patch("dobbe.commands.setup.shutil")
@patch("dobbe.commands.setup.save_config")
@patch("dobbe.commands.setup._scan_for_repos")
@patch("dobbe.commands.setup.load_config")
@patch("dobbe.commands.setup.discover_mcps")
@patch("dobbe.commands.setup.check_claude_auth")
@patch("dobbe.commands.setup.is_claude_installed")
def test_cli_setup_org_verification_fails(mock_installed, mock_auth, mock_discover, mock_load, mock_scan, mock_save, mock_shutil, mock_sub, mock_mark):
    mock_installed.return_value = True
    mock_auth.return_value = (True, "Authenticated")
    mock_discover.return_value = {"github": True, "slack": False, "atlassian": False, "sentry": False, "figma": False}
    mock_load.return_value = {"general": {"default_org": ""}}
    mock_scan.return_value = []
    mock_save.return_value = MagicMock()
    mock_shutil.which.return_value = "/usr/local/bin/gh"
    # gh api returns error for org verification
    mock_sub.run.return_value = MagicMock(returncode=1, stdout="")
    result = runner.invoke(app, ["setup"], input="bad-org\n3\n")
    assert result.exit_code == 0
    assert "Could not verify" in result.output


# =================================================================
# Gap 5: Repo selection edge cases in full setup E2E
# =================================================================


@patch("dobbe.core.state_manager.mark_setup_complete")
@patch("dobbe.commands.setup.subprocess")
@patch("dobbe.commands.setup.shutil")
@patch("dobbe.commands.setup.save_config")
@patch("dobbe.commands.setup._scan_for_repos")
@patch("dobbe.commands.setup.load_config")
@patch("dobbe.commands.setup.discover_mcps")
@patch("dobbe.commands.setup.check_claude_auth")
@patch("dobbe.commands.setup.is_claude_installed")
def test_cli_setup_repo_selection_invalid_input(mock_installed, mock_auth, mock_discover, mock_load, mock_scan, mock_save, mock_shutil, mock_sub, mock_mark):
    """Garbage repo selection input shows warning and falls back to all repos."""
    mock_installed.return_value = True
    mock_auth.return_value = (True, "Authenticated")
    mock_discover.return_value = {"github": True, "slack": False, "atlassian": False, "sentry": False, "figma": False}
    mock_load.return_value = {"general": {"default_org": ""}}
    mock_scan.return_value = ["/a/repo1", "/a/repo2"]
    mock_save.return_value = MagicMock()
    mock_shutil.which.return_value = "/usr/local/bin/gh"
    mock_sub.run.return_value = MagicMock(returncode=0, stdout="10")
    # Type "abc" for repo selection → garbage → fallback with warning (BUG 3 fix)
    result = runner.invoke(app, ["setup"], input="my-org\nabc\n3\n")
    assert result.exit_code == 0
    assert "No valid selection" in result.output
    saved = mock_save.call_args[0][0]
    assert saved["repos"]["local_paths"] == ["/a/repo1", "/a/repo2"]


@patch("dobbe.core.state_manager.mark_setup_complete")
@patch("dobbe.commands.setup.subprocess")
@patch("dobbe.commands.setup.shutil")
@patch("dobbe.commands.setup.save_config")
@patch("dobbe.commands.setup._scan_for_repos")
@patch("dobbe.commands.setup.load_config")
@patch("dobbe.commands.setup.discover_mcps")
@patch("dobbe.commands.setup.check_claude_auth")
@patch("dobbe.commands.setup.is_claude_installed")
def test_cli_setup_repo_selection_duplicates(mock_installed, mock_auth, mock_discover, mock_load, mock_scan, mock_save, mock_shutil, mock_sub, mock_mark):
    """Duplicate repo indices (BUG 2) are deduplicated."""
    mock_installed.return_value = True
    mock_auth.return_value = (True, "Authenticated")
    mock_discover.return_value = {"github": True, "slack": False, "atlassian": False, "sentry": False, "figma": False}
    mock_load.return_value = {"general": {"default_org": ""}}
    mock_scan.return_value = ["/a", "/b", "/c"]
    mock_save.return_value = MagicMock()
    mock_shutil.which.return_value = "/usr/local/bin/gh"
    mock_sub.run.return_value = MagicMock(returncode=0, stdout="10")
    # Input 1,1,1 → should deduplicate to just ["/a"]
    result = runner.invoke(app, ["setup"], input="my-org\n1,1,1\n3\n")
    assert result.exit_code == 0
    saved = mock_save.call_args[0][0]
    assert saved["repos"]["local_paths"] == ["/a"]


# =================================================================
# Gap 6: gh CLI found (positive) in full setup E2E
# =================================================================


@patch("dobbe.core.state_manager.mark_setup_complete")
@patch("dobbe.commands.setup.subprocess")
@patch("dobbe.commands.setup.shutil")
@patch("dobbe.commands.setup.save_config")
@patch("dobbe.commands.setup._scan_for_repos")
@patch("dobbe.commands.setup.load_config")
@patch("dobbe.commands.setup.discover_mcps")
@patch("dobbe.commands.setup.check_claude_auth")
@patch("dobbe.commands.setup.is_claude_installed")
def test_cli_setup_gh_cli_found_no_github_mcp(mock_installed, mock_auth, mock_discover, mock_load, mock_scan, mock_save, mock_shutil, mock_sub, mock_mark):
    """When GitHub MCP is missing but gh CLI exists, show 'gh CLI found'."""
    mock_installed.return_value = True
    mock_auth.return_value = (True, "Authenticated")
    mock_discover.return_value = {"github": False, "slack": False, "atlassian": False, "sentry": False, "figma": False}
    mock_load.return_value = {"general": {"default_org": ""}}
    mock_scan.return_value = []
    mock_save.return_value = MagicMock()
    mock_shutil.which.return_value = "/usr/local/bin/gh"
    mock_sub.run.return_value = MagicMock(returncode=1, stdout="")
    result = runner.invoke(app, ["setup"], input="my-org\n3\n")
    assert result.exit_code == 0
    assert "gh CLI found" in result.output


# =================================================================
# Gap 7: Smoke test failure paths in full setup E2E
# =================================================================


@patch("dobbe.core.state_manager.mark_setup_complete")
@patch("dobbe.commands.setup.subprocess")
@patch("dobbe.commands.setup.shutil")
@patch("dobbe.commands.setup.save_config")
@patch("dobbe.commands.setup._scan_for_repos")
@patch("dobbe.commands.setup.load_config")
@patch("dobbe.commands.setup.discover_mcps")
@patch("dobbe.commands.setup.check_claude_auth")
@patch("dobbe.commands.setup.is_claude_installed")
def test_cli_setup_smoke_test_warnings(mock_installed, mock_auth, mock_discover, mock_load, mock_scan, mock_save, mock_shutil, mock_sub, mock_mark):
    """Smoke test shows warnings for unreachable org and no MCPs."""
    mock_installed.return_value = True
    mock_auth.return_value = (True, "Authenticated")
    mock_discover.return_value = {"github": False, "slack": False, "atlassian": False, "sentry": False, "figma": False}
    mock_load.return_value = {"general": {"default_org": ""}}
    mock_scan.return_value = []
    mock_save.return_value = MagicMock()
    mock_shutil.which.return_value = None  # no gh CLI
    mock_sub.run.return_value = MagicMock(returncode=1, stdout="")
    result = runner.invoke(app, ["setup"], input="my-org\n3\n")
    assert result.exit_code == 0
    assert "No MCPs detected" in result.output
    assert "GitHub access check skipped" in result.output


# =================================================================
# Gap 8: Post-setup menu option 2 (review) in E2E
# =================================================================


@patch("dobbe.core.state_manager.mark_setup_complete")
@patch("dobbe.commands.setup.subprocess")
@patch("dobbe.commands.setup.shutil")
@patch("dobbe.commands.setup.save_config")
@patch("dobbe.commands.setup._scan_for_repos")
@patch("dobbe.commands.setup.load_config")
@patch("dobbe.commands.setup.discover_mcps")
@patch("dobbe.commands.setup.check_claude_auth")
@patch("dobbe.commands.setup.is_claude_installed")
def test_cli_setup_post_menu_review(mock_installed, mock_auth, mock_discover, mock_load, mock_scan, mock_save, mock_shutil, mock_sub, mock_mark):
    """Post-setup menu option 2 triggers review digest."""
    mock_installed.return_value = True
    mock_auth.return_value = (True, "Authenticated")
    mock_discover.return_value = {"github": True, "slack": False, "atlassian": False, "sentry": False, "figma": False}
    mock_load.return_value = {"general": {"default_org": ""}}
    mock_scan.return_value = []
    mock_save.return_value = MagicMock()
    mock_shutil.which.return_value = "/usr/local/bin/gh"
    mock_sub.run.return_value = MagicMock(returncode=0, stdout="10")
    # Choose option 2 (review) in post-setup menu
    result = runner.invoke(app, ["setup"], input="my-org\n2\n")
    assert result.exit_code == 0
    assert "dobbe review digest" in result.output


# =================================================================
# Gap 9: Tips shown after real CLI command via ctx.call_on_close
# =================================================================


@patch("dobbe.commands.vuln.load_config")
def test_cli_tip_shown_after_command(mock_load, monkeypatch, tmp_path):
    """Tip text appears in CLI output after a command (via call_on_close)."""
    from dobbe.core.first_run import TIPS

    # Set up state file with runs_since_setup=1
    import tomli_w
    state_file = tmp_path / "state.toml"
    state_file.write_bytes(tomli_w.dumps({"runs_since_setup": 0}).encode())
    monkeypatch.setattr("dobbe.core.state_manager.STATE_FILE", state_file)
    monkeypatch.setattr("dobbe.core.state_manager.CONFIG_DIR", tmp_path)
    monkeypatch.delenv("CI", raising=False)
    monkeypatch.delenv("DOBBE_QUIET", raising=False)

    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    result = runner.invoke(app, ["vuln", "scan"])
    # After increment, run_count = 1, so tip 1 should appear
    assert "dobbe doctor" in result.output or "Tip" in result.output


# =================================================================
# Gap 11: First-run → setup fails → graceful recovery (BUG 1 fix test)
# =================================================================


@patch("dobbe.commands.setup.is_claude_installed")
def test_first_run_setup_fails_gracefully(mock_installed, monkeypatch):
    """First-run → accept → setup raises typer.Exit → caught → CLI continues."""
    from dobbe.core.first_run import invalidate_first_run_flag
    invalidate_first_run_flag()
    mock_cf = MagicMock()
    mock_cf.exists.return_value = False
    monkeypatch.setattr("dobbe.core.first_run.CONFIG_FILE", mock_cf)
    monkeypatch.delenv("CI", raising=False)
    mock_installed.return_value = False  # causes typer.Exit(1) in setup
    result = runner.invoke(app, ["vuln", "scan"], input="y\n")
    # BUG 1 fix: typer.Exit is caught
    assert "Setup did not complete" in result.output
    # CLI did NOT crash - it continued past setup
    assert result.exit_code in (0, 1)


# =================================================================
# Gap 12: mark_setup_complete integration
# =================================================================


@patch("dobbe.commands.setup.subprocess")
@patch("dobbe.commands.setup.shutil")
@patch("dobbe.commands.setup.save_config")
@patch("dobbe.commands.setup._scan_for_repos")
@patch("dobbe.commands.setup.load_config")
@patch("dobbe.commands.setup.discover_mcps")
@patch("dobbe.commands.setup.check_claude_auth")
@patch("dobbe.commands.setup.is_claude_installed")
def test_setup_marks_state_complete(mock_installed, mock_auth, mock_discover, mock_load, mock_scan, mock_save, mock_shutil, mock_sub, monkeypatch, tmp_path):
    """After successful setup, mark_setup_complete is called and run_count resets."""
    import tomli_w
    state_file = tmp_path / "state.toml"
    state_file.write_bytes(tomli_w.dumps({"runs_since_setup": 5}).encode())
    monkeypatch.setattr("dobbe.core.state_manager.STATE_FILE", state_file)
    monkeypatch.setattr("dobbe.core.state_manager.CONFIG_DIR", tmp_path)

    mock_installed.return_value = True
    mock_auth.return_value = (True, "Authenticated")
    mock_discover.return_value = {"github": True, "slack": False, "atlassian": False, "sentry": False, "figma": False}
    mock_load.return_value = {"general": {"default_org": ""}}
    mock_scan.return_value = []
    mock_save.return_value = MagicMock()
    mock_shutil.which.return_value = "/usr/local/bin/gh"
    mock_sub.run.return_value = MagicMock(returncode=0, stdout="10")
    result = runner.invoke(app, ["setup"], input="my-org\n3\n")
    assert result.exit_code == 0
    # Verify state file was updated
    from dobbe.core.state_manager import load_state
    state = load_state()
    assert state["runs_since_setup"] == 0
    assert "setup_completed_at" in state


# =================================================================
# Bug 5 regression: setup/doctor don't burn tips
# =================================================================


@patch("dobbe.commands.doctor.run_doctor")
def test_cli_doctor_does_not_increment_run_count(mock_doctor, monkeypatch, tmp_path):
    """Running doctor should not increment run_count (BUG 5 fix)."""
    import tomli_w
    state_file = tmp_path / "state.toml"
    state_file.write_bytes(tomli_w.dumps({"runs_since_setup": 0}).encode())
    monkeypatch.setattr("dobbe.core.state_manager.STATE_FILE", state_file)
    monkeypatch.setattr("dobbe.core.state_manager.CONFIG_DIR", tmp_path)
    mock_doctor.return_value = []

    runner.invoke(app, ["doctor"])
    runner.invoke(app, ["doctor"])
    runner.invoke(app, ["doctor"])

    from dobbe.core.state_manager import load_state
    state = load_state()
    assert state.get("runs_since_setup", 0) == 0


# =================================================================
# User repo discovery + batch resolve
# =================================================================


@patch("dobbe.commands.vuln.ask_claude")
@patch("dobbe.core.org_repos.ask_claude")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_cli_vuln_scan_user_success(mock_load, mock_discover, mock_list_claude, mock_scan_claude):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": True, "slack": False}
    mock_list_claude.return_value = ClaudeResult(success=True, text='["testuser/repo1"]')
    mock_scan_claude.return_value = ClaudeResult(success=True, text=_make_valid_triage_json())

    with patch("dobbe.commands.vuln.resolve_repo", return_value=(AccessMode.REMOTE, None)):
        result = runner.invoke(app, ["vuln", "scan", "--user", "testuser"])
    assert result.exit_code == 0


@patch("dobbe.commands.vuln.load_config")
def test_cli_vuln_scan_user_and_org_conflict(mock_load):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    result = runner.invoke(app, ["vuln", "scan", "--user", "testuser", "--org", "myorg"])
    assert result.exit_code == 1
    assert "only one" in result.output.lower() or "Specify only one" in result.output


@patch("dobbe.commands.vuln.load_config")
def test_cli_vuln_scan_user_and_repo_conflict(mock_load):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    result = runner.invoke(app, ["vuln", "scan", "--user", "testuser", "--repo", "org/repo"])
    assert result.exit_code == 1
    assert "only one" in result.output.lower() or "Specify only one" in result.output


@patch("dobbe.commands.vuln.run_batch_resolve")
@patch("dobbe.core.org_repos.ask_claude")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_cli_vuln_resolve_user_success(mock_load, mock_discover, mock_list_claude, mock_batch):
    from dobbe.models.resolve import ResolveReport
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": True, "slack": False}
    mock_list_claude.return_value = ClaudeResult(success=True, text='["testuser/repo1"]')
    mock_batch.return_value = [ResolveReport(repo="testuser/repo1", converged=True)]
    result = runner.invoke(app, ["vuln", "resolve", "--user", "testuser"])
    assert result.exit_code == 0
    mock_batch.assert_called_once()


@patch("dobbe.commands.vuln.run_batch_resolve")
@patch("dobbe.core.org_repos.ask_claude")
@patch("dobbe.commands.vuln.discover_mcps")
@patch("dobbe.commands.vuln.load_config")
def test_cli_vuln_resolve_org_success(mock_load, mock_discover, mock_list_claude, mock_batch):
    from dobbe.models.resolve import ResolveReport
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    mock_discover.return_value = {"github": True, "slack": False}
    mock_list_claude.return_value = ClaudeResult(success=True, text='["myorg/repo1"]')
    mock_batch.return_value = [ResolveReport(repo="myorg/repo1", converged=True)]
    result = runner.invoke(app, ["vuln", "resolve", "--org", "myorg"])
    assert result.exit_code == 0
    mock_batch.assert_called_once()


def test_cli_vuln_resolve_no_target():
    result = runner.invoke(app, ["vuln", "resolve"])
    assert result.exit_code == 1
    assert "Specify one" in result.output or "--repo" in result.output


def test_cli_vuln_resolve_conflicting_flags():
    result = runner.invoke(app, ["vuln", "resolve", "--repo", "org/repo", "--org", "myorg"])
    assert result.exit_code == 1
    assert "Conflicting" in result.output or "only one" in result.output.lower()


@patch("dobbe.commands.vuln.load_config")
def test_cli_vuln_resolve_user_org_conflict(mock_load):
    mock_load.return_value = {"general": {"default_org": "", "default_format": "table", "default_severity": "critical,high"}}
    result = runner.invoke(app, ["vuln", "resolve", "--user", "testuser", "--org", "myorg"])
    assert result.exit_code == 1
    assert "Conflicting" in result.output
