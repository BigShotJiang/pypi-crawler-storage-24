"""Tests for resolve-specific response parsers - parse_fix_response, parse_verify_response."""

from __future__ import annotations

import json

from dobbe.core.response_parser import parse_fix_response, parse_verify_response
from dobbe.models.shared import FixStatus, Severity, VerifyCategory


# --- parse_fix_response ---


def test_parse_fix_valid():
    text = json.dumps({
        "fixes": [{
            "package_name": "django",
            "file_modified": "requirements.txt",
            "old_version": "4.2.5",
            "new_version": "4.2.11",
            "alerts_addressed": [1, 2],
            "status": "applied",
        }],
        "skipped": [{
            "package_name": "numpy",
            "reason": "Major version bump",
            "alerts_skipped": [3],
        }],
        "diff_summary": "Updated django",
    })
    result = parse_fix_response(text, "org/repo", "fix-branch", "main")
    assert len(result.fixes) == 1
    assert result.fixes[0].package_name == "django"
    assert result.fixes[0].status == FixStatus.APPLIED
    assert result.fixes[0].alerts_addressed == [1, 2]
    assert len(result.skipped) == 1
    assert result.skipped[0].package_name == "numpy"
    assert result.diff_summary == "Updated django"
    assert result.repo == "org/repo"
    assert result.branch == "fix-branch"


def test_parse_fix_no_json():
    result = parse_fix_response("No valid JSON here", "org/repo", "b", "main")
    assert result.fixes == []
    assert result.skipped == []
    assert "No valid JSON" in result.raw_response


def test_parse_fix_empty_fixes():
    text = json.dumps({"fixes": [], "skipped": [], "diff_summary": ""})
    result = parse_fix_response(text, "org/repo", "b", "main")
    assert result.fixes == []
    assert result.skipped == []


def test_parse_fix_in_markdown_fence():
    inner = json.dumps({
        "fixes": [{
            "package_name": "requests",
            "file_modified": "req.txt",
            "old_version": "2.28",
            "new_version": "2.31",
            "alerts_addressed": [],
            "status": "applied",
        }],
        "skipped": [],
        "diff_summary": "bump requests",
    })
    text = f"```json\n{inner}\n```"
    result = parse_fix_response(text, "org/repo", "b", "main")
    assert len(result.fixes) == 1
    assert result.fixes[0].package_name == "requests"


def test_parse_fix_invalid_status():
    text = json.dumps({
        "fixes": [{
            "package_name": "pkg",
            "file_modified": "f",
            "old_version": "1",
            "new_version": "2",
            "alerts_addressed": [],
            "status": "unknown_status",
        }],
        "skipped": [],
        "diff_summary": "",
    })
    result = parse_fix_response(text, "org/repo", "b", "main")
    assert len(result.fixes) == 1
    assert result.fixes[0].status == FixStatus.APPLIED  # fallback


def test_parse_fix_malformed_entry_skipped():
    text = json.dumps({
        "fixes": [
            {
                "package_name": "good",
                "file_modified": "f",
                "old_version": "1",
                "new_version": "2",
            },
            "not a dict",  # malformed
        ],
        "skipped": [
            {"package_name": "ok", "reason": "no fix"},
            42,  # malformed
        ],
        "diff_summary": "",
    })
    result = parse_fix_response(text, "org/repo", "b", "main")
    assert len(result.fixes) == 1
    assert result.fixes[0].package_name == "good"
    assert len(result.skipped) == 1
    assert result.skipped[0].package_name == "ok"


def test_parse_fix_missing_optional_fields():
    text = json.dumps({
        "fixes": [{
            "package_name": "pkg",
            "file_modified": "f.txt",
            "old_version": "1.0",
            "new_version": "1.1",
        }],
        "skipped": [],
    })
    result = parse_fix_response(text, "org/repo", "b", "main")
    assert len(result.fixes) == 1
    assert result.fixes[0].alerts_addressed == []
    assert result.diff_summary == ""


def test_parse_fix_with_preamble():
    inner = json.dumps({
        "fixes": [{
            "package_name": "p",
            "file_modified": "f",
            "old_version": "1",
            "new_version": "2",
        }],
        "skipped": [],
        "diff_summary": "done",
    })
    text = f"Here are the results: {inner}"
    result = parse_fix_response(text, "org/repo", "b", "main")
    assert len(result.fixes) == 1


# --- parse_verify_response ---


def test_parse_verify_passed():
    text = json.dumps({
        "passed": True,
        "issues": [],
        "test_output": "All 42 tests passed",
        "feedback": "",
    })
    result = parse_verify_response(text, "org/repo")
    assert result.passed is True
    assert result.issues == []
    assert result.test_output == "All 42 tests passed"
    assert result.feedback == ""


def test_parse_verify_failed():
    text = json.dumps({
        "passed": False,
        "issues": [{
            "category": "test_failure",
            "severity": "high",
            "description": "test_api.py::test_timeout fails",
            "suggestion": "Pin requests to 2.30.x",
        }],
        "test_output": "FAILED 1 test",
        "feedback": "Pin requests to 2.30.x",
    })
    result = parse_verify_response(text, "org/repo")
    assert result.passed is False
    assert len(result.issues) == 1
    assert result.issues[0].category == VerifyCategory.TEST_FAILURE
    assert result.issues[0].severity == Severity.HIGH
    assert result.feedback == "Pin requests to 2.30.x"


def test_parse_verify_no_json():
    result = parse_verify_response("No JSON here", "org/repo")
    assert result.passed is False
    assert "Failed to parse" in result.feedback


def test_parse_verify_empty_response():
    result = parse_verify_response("", "org/repo")
    assert result.passed is False


def test_parse_verify_unknown_category():
    text = json.dumps({
        "passed": False,
        "issues": [{
            "category": "unknown_cat",
            "severity": "medium",
            "description": "Something happened",
        }],
        "test_output": "",
        "feedback": "Investigate",
    })
    result = parse_verify_response(text, "org/repo")
    assert result.issues[0].category == VerifyCategory.OTHER


def test_parse_verify_unknown_severity():
    text = json.dumps({
        "passed": False,
        "issues": [{
            "category": "other",
            "severity": "unknown_sev",
            "description": "Something",
        }],
        "test_output": "",
        "feedback": "",
    })
    result = parse_verify_response(text, "org/repo")
    assert result.issues[0].severity == Severity.MEDIUM  # fallback


def test_parse_verify_malformed_issue_skipped():
    text = json.dumps({
        "passed": False,
        "issues": [
            {
                "category": "test_failure",
                "severity": "high",
                "description": "Valid issue",
            },
            "not a dict",
        ],
        "test_output": "",
        "feedback": "",
    })
    result = parse_verify_response(text, "org/repo")
    assert len(result.issues) == 1
    assert result.issues[0].description == "Valid issue"


def test_parse_verify_multiple_issues():
    text = json.dumps({
        "passed": False,
        "issues": [
            {
                "category": "test_failure",
                "severity": "high",
                "description": "Tests fail",
                "suggestion": "Fix tests",
            },
            {
                "category": "breaking_change",
                "severity": "critical",
                "description": "API changed",
                "suggestion": "Pin version",
            },
        ],
        "test_output": "2 failures",
        "feedback": "Fix both issues",
    })
    result = parse_verify_response(text, "org/repo")
    assert len(result.issues) == 2
    assert result.issues[0].category == VerifyCategory.TEST_FAILURE
    assert result.issues[1].category == VerifyCategory.BREAKING_CHANGE


def test_parse_verify_in_fence():
    inner = json.dumps({
        "passed": True,
        "issues": [],
        "test_output": "OK",
        "feedback": "",
    })
    text = f"```json\n{inner}\n```"
    result = parse_verify_response(text, "org/repo")
    assert result.passed is True


def test_parse_verify_all_categories():
    """Verify all VerifyCategory values are handled."""
    for cat in ["test_failure", "breaking_change", "lockfile_inconsistency", "dependency_conflict", "other"]:
        text = json.dumps({
            "passed": False,
            "issues": [{"category": cat, "severity": "low", "description": f"test {cat}"}],
            "test_output": "",
            "feedback": "",
        })
        result = parse_verify_response(text, "org/repo")
        assert result.issues[0].category == VerifyCategory(cat)


def test_parse_verify_missing_optional_fields():
    text = json.dumps({
        "passed": True,
        "issues": [{
            "category": "other",
            "severity": "low",
            "description": "Minor",
        }],
    })
    result = parse_verify_response(text, "org/repo")
    assert result.passed is True
    assert result.issues[0].suggestion == ""
    assert result.test_output == ""
    assert result.feedback == ""
