"""Tests for schedule models."""

from __future__ import annotations

from datetime import datetime, timedelta

from dobbe.models.schedule import (
    INTERVAL_DELTAS,
    CheckResult,
    RunLog,
    RunStatus,
    Schedule,
    ScheduleInterval,
)


# --- ScheduleInterval enum ---


def test_schedule_interval_values():
    assert ScheduleInterval.HOURLY == "hourly"
    assert ScheduleInterval.EVERY_4H == "every_4h"
    assert ScheduleInterval.EVERY_12H == "every_12h"
    assert ScheduleInterval.DAILY == "daily"
    assert ScheduleInterval.WEEKLY == "weekly"


def test_interval_deltas_all_present():
    for member in ScheduleInterval:
        assert member in INTERVAL_DELTAS
        assert isinstance(INTERVAL_DELTAS[member], timedelta)


def test_interval_deltas_values():
    assert INTERVAL_DELTAS[ScheduleInterval.HOURLY] == timedelta(hours=1)
    assert INTERVAL_DELTAS[ScheduleInterval.EVERY_4H] == timedelta(hours=4)
    assert INTERVAL_DELTAS[ScheduleInterval.EVERY_12H] == timedelta(hours=12)
    assert INTERVAL_DELTAS[ScheduleInterval.DAILY] == timedelta(hours=24)
    assert INTERVAL_DELTAS[ScheduleInterval.WEEKLY] == timedelta(hours=168)


# --- Schedule model ---


def test_schedule_minimal():
    s = Schedule(name="test", command="vuln scan", interval=ScheduleInterval.DAILY)
    assert s.name == "test"
    assert s.command == "vuln scan"
    assert s.args == ""
    assert s.interval == ScheduleInterval.DAILY
    assert s.enabled is True
    assert s.last_run is None
    assert isinstance(s.created_at, datetime)


def test_schedule_full():
    now = datetime(2026, 3, 15, 10, 0)
    s = Schedule(
        name="vuln-daily",
        command="vuln scan",
        args="--org acme --severity critical,high",
        interval=ScheduleInterval.DAILY,
        enabled=False,
        last_run=now,
        created_at=now,
    )
    assert s.name == "vuln-daily"
    assert s.args == "--org acme --severity critical,high"
    assert s.enabled is False
    assert s.last_run == now


def test_schedule_serialization_roundtrip():
    s = Schedule(
        name="test",
        command="review digest",
        interval=ScheduleInterval.WEEKLY,
        last_run=datetime(2026, 3, 19, 8, 30),
    )
    data = s.model_dump()
    s2 = Schedule(**data)
    assert s2.name == s.name
    assert s2.command == s.command
    assert s2.interval == s.interval
    assert s2.last_run == s.last_run


# --- RunStatus enum ---


def test_run_status_values():
    assert RunStatus.SUCCESS == "success"
    assert RunStatus.FAILED == "failed"
    assert RunStatus.TIMEOUT == "timeout"


# --- RunLog model ---


def test_run_log_construction():
    started = datetime(2026, 3, 19, 8, 30)
    finished = datetime(2026, 3, 19, 8, 31)
    log = RunLog(
        schedule_name="vuln-daily",
        started_at=started,
        finished_at=finished,
        status=RunStatus.SUCCESS,
        duration_seconds=60.5,
        exit_code=0,
        summary="Completed",
        command="vuln scan",
        args="--org acme",
    )
    assert log.schedule_name == "vuln-daily"
    assert log.duration_seconds == 60.5
    assert log.exit_code == 0
    assert log.error == ""


def test_run_log_failure():
    started = datetime(2026, 3, 19, 8, 30)
    finished = datetime(2026, 3, 19, 8, 31)
    log = RunLog(
        schedule_name="vuln-daily",
        started_at=started,
        finished_at=finished,
        status=RunStatus.FAILED,
        duration_seconds=45.0,
        exit_code=1,
        error="Permission denied",
        command="vuln scan",
        args="",
    )
    assert log.status == RunStatus.FAILED
    assert log.exit_code == 1
    assert log.error == "Permission denied"


def test_run_log_serialization():
    log = RunLog(
        schedule_name="test",
        started_at=datetime(2026, 3, 19, 8, 30),
        finished_at=datetime(2026, 3, 19, 8, 31),
        status=RunStatus.SUCCESS,
        duration_seconds=60.0,
        command="review digest",
        args="",
    )
    json_str = log.model_dump_json()
    assert "test" in json_str
    assert "success" in json_str
    # Roundtrip
    log2 = RunLog.model_validate_json(json_str)
    assert log2.schedule_name == "test"
    assert log2.status == RunStatus.SUCCESS


# --- CheckResult model ---


def test_check_result_defaults():
    cr = CheckResult()
    assert isinstance(cr.checked_at, datetime)
    assert cr.schedules_checked == 0
    assert cr.schedules_run == 0
    assert cr.results == []


def test_check_result_with_results():
    log = RunLog(
        schedule_name="test",
        started_at=datetime(2026, 3, 19, 8, 30),
        finished_at=datetime(2026, 3, 19, 8, 31),
        status=RunStatus.SUCCESS,
        duration_seconds=60.0,
        command="vuln scan",
        args="",
    )
    cr = CheckResult(schedules_checked=3, schedules_run=1, results=[log])
    assert cr.schedules_checked == 3
    assert cr.schedules_run == 1
    assert len(cr.results) == 1
