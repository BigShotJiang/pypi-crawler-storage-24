"""Tests for prompt builder."""

from dobbe.core.prompts import build_scan_prompt, build_notify_prompt


def test_build_scan_prompt_basic():
    prompt = build_scan_prompt(repo="org/repo")
    assert "org/repo" in prompt
    assert "Dependabot" in prompt


def test_build_scan_prompt_with_github_mcp():
    prompt = build_scan_prompt(
        repo="org/repo",
        available_mcps={"github": True},
    )
    assert "GitHub MCP" in prompt
    assert "gh api" not in prompt


def test_build_scan_prompt_without_github_mcp():
    prompt = build_scan_prompt(
        repo="org/repo",
        available_mcps={"github": False},
    )
    assert "gh api" in prompt


def test_build_scan_prompt_local_access():
    prompt = build_scan_prompt(
        repo="org/repo",
        access_mode="local",
        local_path="/home/user/projects/repo",
    )
    assert "/home/user/projects/repo" in prompt
    assert "Grep" in prompt


def test_build_scan_prompt_remote_access():
    prompt = build_scan_prompt(
        repo="org/repo",
        available_mcps={"github": True},
        access_mode="remote",
    )
    assert "not cloned locally" in prompt


def test_build_scan_prompt_severity_filter():
    prompt = build_scan_prompt(
        repo="org/repo",
        severity_filter=["critical", "high"],
    )
    assert "critical" in prompt
    assert "high" in prompt


def test_build_scan_prompt_json_output_instructions():
    prompt = build_scan_prompt(repo="org/repo")
    assert '"groups"' in prompt
    assert '"alerts"' in prompt
    assert "JSON" in prompt


def test_build_notify_prompt_slack():
    prompt = build_notify_prompt(
        report_json='{"test": true}',
        channel="#security",
        platform="slack",
    )
    assert "#security" in prompt
    assert "Slack" in prompt


def test_build_notify_prompt_jira():
    prompt = build_notify_prompt(
        report_json='{"test": true}',
        platform="jira",
    )
    assert "Jira" in prompt
    assert "ticket" in prompt.lower()


# --- Additional tests ---

import pytest


def test_build_notify_prompt_unknown_platform_raises():
    with pytest.raises(ValueError, match="Unknown notification platform"):
        build_notify_prompt(report_json='{}', platform="teams")


def test_build_scan_prompt_remote_no_github_mcp():
    prompt = build_scan_prompt(
        repo="org/repo",
        available_mcps={"github": False},
        access_mode="remote",
    )
    assert "gh api" in prompt
    assert "base64" in prompt


def test_build_scan_prompt_no_severity_filter_none():
    prompt = build_scan_prompt(repo="org/repo", severity_filter=None)
    # No severity filter clause added
    assert "Filter to only" not in prompt
