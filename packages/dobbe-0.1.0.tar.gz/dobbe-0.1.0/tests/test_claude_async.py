"""Tests for ask_claude_async."""

from __future__ import annotations

import asyncio
import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from dobbe.core.claude import ask_claude_async


@pytest.mark.asyncio
@patch("dobbe.core.claude._find_claude_binary")
async def test_async_not_installed(mock_find):
    mock_find.return_value = None
    result = await ask_claude_async("hello")
    assert result.success is False
    assert "not installed" in result.error


@pytest.mark.asyncio
@patch("dobbe.core.claude.asyncio.wait_for")
@patch("dobbe.core.claude.asyncio.create_subprocess_exec")
@patch("dobbe.core.claude._find_claude_binary")
async def test_async_success(mock_find, mock_create, mock_wait_for):
    mock_find.return_value = "/usr/local/bin/claude"
    mock_proc = MagicMock()
    mock_proc.returncode = 0
    mock_create.return_value = mock_proc
    stdout_data = json.dumps({"result": "Hello!"}).encode()
    mock_wait_for.return_value = (stdout_data, b"")
    result = await ask_claude_async("hello")
    assert result.success is True
    assert "Hello!" in result.text


@pytest.mark.asyncio
@patch("dobbe.core.claude.asyncio.wait_for")
@patch("dobbe.core.claude.asyncio.create_subprocess_exec")
@patch("dobbe.core.claude._find_claude_binary")
async def test_async_error_returncode(mock_find, mock_create, mock_wait_for):
    mock_find.return_value = "/usr/local/bin/claude"
    mock_proc = MagicMock()
    mock_proc.returncode = 1
    mock_create.return_value = mock_proc
    mock_wait_for.return_value = (b"", b"Something went wrong")
    result = await ask_claude_async("hello")
    assert result.success is False
    assert "Something went wrong" in result.error


@pytest.mark.asyncio
@patch("dobbe.core.claude.asyncio.wait_for")
@patch("dobbe.core.claude.asyncio.create_subprocess_exec")
@patch("dobbe.core.claude._find_claude_binary")
async def test_async_timeout(mock_find, mock_create, mock_wait_for):
    mock_find.return_value = "/usr/local/bin/claude"
    mock_proc = MagicMock()
    mock_proc.kill = MagicMock()
    mock_proc.wait = AsyncMock()
    mock_create.return_value = mock_proc
    mock_wait_for.side_effect = asyncio.TimeoutError()
    result = await ask_claude_async("hello", timeout=5, max_retries=0)
    assert result.success is False
    assert "timed out" in result.error
    mock_proc.kill.assert_called_once()
    mock_proc.wait.assert_awaited_once()


@pytest.mark.asyncio
@patch("dobbe.core.claude.asyncio.create_subprocess_exec")
@patch("dobbe.core.claude._find_claude_binary")
async def test_async_os_error(mock_find, mock_create):
    mock_find.return_value = "/usr/local/bin/claude"
    mock_create.side_effect = OSError("Permission denied")
    result = await ask_claude_async("hello")
    assert result.success is False
    assert "Permission denied" in result.error


@pytest.mark.asyncio
@patch("dobbe.core.claude.asyncio.wait_for")
@patch("dobbe.core.claude.asyncio.create_subprocess_exec")
@patch("dobbe.core.claude._find_claude_binary")
async def test_async_non_json_stdout(mock_find, mock_create, mock_wait_for):
    mock_find.return_value = "/usr/local/bin/claude"
    mock_proc = MagicMock()
    mock_proc.returncode = 0
    mock_create.return_value = mock_proc
    mock_wait_for.return_value = (b"Just plain text", b"")
    result = await ask_claude_async("hello")
    assert result.success is True
    assert result.text == "Just plain text"


# --- Async retry logic ---


@pytest.mark.asyncio
@patch("dobbe.core.claude.asyncio.sleep", new_callable=AsyncMock)
@patch("dobbe.core.claude.asyncio.wait_for")
@patch("dobbe.core.claude.asyncio.create_subprocess_exec")
@patch("dobbe.core.claude._find_claude_binary")
async def test_async_retries_on_timeout(mock_find, mock_create, mock_wait_for, mock_sleep):
    """Timeout twice, succeed on third attempt."""
    mock_find.return_value = "/usr/local/bin/claude"

    mock_proc_ok = MagicMock()
    mock_proc_ok.returncode = 0

    mock_proc_timeout = MagicMock()
    mock_proc_timeout.kill = MagicMock()
    mock_proc_timeout.wait = AsyncMock()

    mock_create.side_effect = [mock_proc_timeout, mock_proc_timeout, mock_proc_ok]

    stdout_data = json.dumps({"result": "OK"}).encode()
    mock_wait_for.side_effect = [
        asyncio.TimeoutError(),
        asyncio.TimeoutError(),
        (stdout_data, b""),
    ]

    result = await ask_claude_async("hello", timeout=5, max_retries=2)
    assert result.success is True
    assert result.text == "OK"
    assert mock_sleep.call_count == 2


@pytest.mark.asyncio
@patch("dobbe.core.claude.asyncio.sleep", new_callable=AsyncMock)
@patch("dobbe.core.claude.asyncio.wait_for")
@patch("dobbe.core.claude.asyncio.create_subprocess_exec")
@patch("dobbe.core.claude._find_claude_binary")
async def test_async_retries_on_error_code(mock_find, mock_create, mock_wait_for, mock_sleep):
    """Non-zero return code twice, succeed on third."""
    mock_find.return_value = "/usr/local/bin/claude"

    mock_proc_fail = MagicMock()
    mock_proc_fail.returncode = 1
    mock_proc_ok = MagicMock()
    mock_proc_ok.returncode = 0

    mock_create.side_effect = [mock_proc_fail, mock_proc_fail, mock_proc_ok]
    stdout_data = json.dumps({"result": "OK"}).encode()
    mock_wait_for.side_effect = [
        (b"", b"error 1"),
        (b"", b"error 2"),
        (stdout_data, b""),
    ]

    result = await ask_claude_async("hello", max_retries=2)
    assert result.success is True
    assert mock_sleep.call_count == 2


@pytest.mark.asyncio
@patch("dobbe.core.claude.asyncio.sleep", new_callable=AsyncMock)
@patch("dobbe.core.claude.asyncio.wait_for")
@patch("dobbe.core.claude.asyncio.create_subprocess_exec")
@patch("dobbe.core.claude._find_claude_binary")
async def test_async_exhausts_retries(mock_find, mock_create, mock_wait_for, mock_sleep):
    """Always times out - returns failure after max retries."""
    mock_find.return_value = "/usr/local/bin/claude"

    mock_proc = MagicMock()
    mock_proc.kill = MagicMock()
    mock_proc.wait = AsyncMock()
    mock_create.return_value = mock_proc

    mock_wait_for.side_effect = asyncio.TimeoutError()

    result = await ask_claude_async("hello", timeout=5, max_retries=2)
    assert result.success is False
    assert "timed out" in result.error
    assert mock_create.call_count == 3
