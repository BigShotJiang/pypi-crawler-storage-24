"""Tests for GitHub review posting - payload building, dedup, posting."""

from __future__ import annotations

import json
import subprocess
from datetime import datetime, timedelta
from unittest.mock import patch

from dobbe.core.github_review import (
    DOBBE_REVIEW_MARKER,
    _run_gh,
    build_inline_comment,
    build_review_body,
    build_review_payload,
    check_existing_review,
    fetch_pr_diff,
    fetch_pr_metadata,
    get_pr_head_sha,
    post_review,
)
from dobbe.models.review import PRInfo, PRReviewResult, ReviewConcern
from dobbe.models.shared import ReviewCategory, Severity


def _make_pr() -> PRInfo:
    return PRInfo(
        repo="org/repo",
        pr_number=42,
        title="Fix bug",
        author="alice",
        url="https://github.com/org/repo/pull/42",
        created_at=datetime.now() - timedelta(days=3),
        updated_at=datetime.now(),
    )


def _make_concern(
    file_path="src/main.py",
    line_number=10,
    category=ReviewCategory.SECURITY,
    severity=Severity.HIGH,
    description="SQL injection risk",
    suggestion="Use parameterized queries",
) -> ReviewConcern:
    return ReviewConcern(
        category=category,
        severity=severity,
        description=description,
        file_path=file_path,
        line_number=line_number,
        suggestion=suggestion,
    )


def _make_review(concerns=None, risk=Severity.HIGH) -> PRReviewResult:
    return PRReviewResult(
        pr=_make_pr(),
        risk_level=risk,
        summary="This PR has security concerns",
        concerns=concerns or [],
        recommendations=["Add input validation", "Add tests"],
        approval_recommendation="request_changes",
    )


# --- build_review_body ---


def test_build_review_body_basic():
    review = _make_review()
    body = build_review_body(review)
    assert DOBBE_REVIEW_MARKER in body
    assert "HIGH" in body
    assert "This PR has security concerns" in body
    assert "Request Changes" in body


def test_build_review_body_with_concerns():
    concern = _make_concern()
    review = _make_review(concerns=[concern])
    body = build_review_body(review)
    assert "Concerns" in body
    assert "SQL injection risk" in body
    assert "src/main.py" in body
    assert "Use parameterized queries" in body


def test_build_review_body_only_high_concerns():
    high = _make_concern(severity=Severity.HIGH)
    low = _make_concern(severity=Severity.LOW, description="Minor style issue")
    review = _make_review(concerns=[high, low])
    body = build_review_body(review)
    assert "SQL injection risk" in body
    # Low severity concern should not be in the Concerns section
    assert "Minor style issue" not in body


def test_build_review_body_with_recommendations():
    review = _make_review()
    body = build_review_body(review)
    assert "Recommendations" in body
    assert "Add input validation" in body
    assert "Add tests" in body


def test_build_review_body_no_recommendations():
    review = PRReviewResult(
        pr=_make_pr(),
        risk_level=Severity.LOW,
        summary="Clean PR",
        recommendations=[],
        approval_recommendation="approve",
    )
    body = build_review_body(review)
    assert "Recommendations" not in body


def test_build_review_body_severity_emoji():
    for sev in [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW]:
        review = _make_review(risk=sev)
        body = build_review_body(review)
        assert sev.value.upper() in body


# --- build_inline_comment ---


def test_build_inline_comment_basic():
    concern = _make_concern()
    comment = build_inline_comment(concern)
    assert comment is not None
    assert comment["path"] == "src/main.py"
    assert comment["line"] == 10
    assert comment["side"] == "RIGHT"
    assert "SQL injection risk" in comment["body"]
    assert "Use parameterized queries" in comment["body"]


def test_build_inline_comment_no_file_path():
    concern = _make_concern(file_path="")
    assert build_inline_comment(concern) is None


def test_build_inline_comment_no_line_number():
    concern = _make_concern(line_number=None)
    assert build_inline_comment(concern) is None


def test_build_inline_comment_no_suggestion():
    concern = _make_concern(suggestion="")
    comment = build_inline_comment(concern)
    assert comment is not None
    assert "Suggestion" not in comment["body"]


def test_build_inline_comment_path_override():
    concern = _make_concern(file_path="original.py")
    comment = build_inline_comment(concern, path_override="override.py")
    assert comment["path"] == "override.py"


# --- build_review_payload ---


def test_build_review_payload_basic():
    review = _make_review()
    payload = build_review_payload(review)
    assert payload["event"] == "COMMENT"
    assert DOBBE_REVIEW_MARKER in payload["body"]
    assert isinstance(payload["comments"], list)


def test_build_review_payload_with_inline_comments():
    concern = _make_concern()
    review = _make_review(concerns=[concern])
    payload = build_review_payload(review)
    assert len(payload["comments"]) == 1
    assert payload["comments"][0]["path"] == "src/main.py"


def test_build_review_payload_skips_concerns_without_line():
    c1 = _make_concern(line_number=10)
    c2 = _make_concern(line_number=None)
    c3 = _make_concern(file_path="")
    review = _make_review(concerns=[c1, c2, c3])
    payload = build_review_payload(review)
    assert len(payload["comments"]) == 1


# --- get_pr_head_sha ---


@patch("dobbe.core.github_review._run_gh")
def test_get_pr_head_sha_success(mock_gh):
    mock_gh.return_value = (True, "abc123def456")
    sha = get_pr_head_sha("org/repo", 42)
    assert sha == "abc123def456"
    mock_gh.assert_called_once()


@patch("dobbe.core.github_review._run_gh")
def test_get_pr_head_sha_failure(mock_gh):
    mock_gh.return_value = (False, "not found")
    sha = get_pr_head_sha("org/repo", 42)
    assert sha is None


@patch("dobbe.core.github_review._run_gh")
def test_get_pr_head_sha_empty(mock_gh):
    mock_gh.return_value = (True, "")
    sha = get_pr_head_sha("org/repo", 42)
    assert sha is None


# --- check_existing_review ---


@patch("dobbe.core.github_review._run_gh")
def test_check_existing_review_found(mock_gh):
    reviews = [
        {"body": f"{DOBBE_REVIEW_MARKER}\nSome review", "commit_id": "abc123"},
    ]
    mock_gh.return_value = (True, json.dumps(reviews))
    assert check_existing_review("org/repo", 42, "abc123") is True


@patch("dobbe.core.github_review._run_gh")
def test_check_existing_review_different_sha(mock_gh):
    reviews = [
        {"body": f"{DOBBE_REVIEW_MARKER}\nSome review", "commit_id": "abc123"},
    ]
    mock_gh.return_value = (True, json.dumps(reviews))
    assert check_existing_review("org/repo", 42, "def456") is False


@patch("dobbe.core.github_review._run_gh")
def test_check_existing_review_no_marker(mock_gh):
    reviews = [
        {"body": "Regular review", "commit_id": "abc123"},
    ]
    mock_gh.return_value = (True, json.dumps(reviews))
    assert check_existing_review("org/repo", 42, "abc123") is False


@patch("dobbe.core.github_review._run_gh")
def test_check_existing_review_no_reviews(mock_gh):
    mock_gh.return_value = (True, "[]")
    assert check_existing_review("org/repo", 42, "abc123") is False


@patch("dobbe.core.github_review._run_gh")
def test_check_existing_review_api_failure(mock_gh):
    mock_gh.return_value = (False, "API error")
    assert check_existing_review("org/repo", 42, "abc123") is False


@patch("dobbe.core.github_review._run_gh")
def test_check_existing_review_bad_json(mock_gh):
    mock_gh.return_value = (True, "not json")
    assert check_existing_review("org/repo", 42, "abc123") is False


@patch("dobbe.core.github_review._run_gh")
def test_check_existing_review_non_list(mock_gh):
    mock_gh.return_value = (True, '{"error": "not found"}')
    assert check_existing_review("org/repo", 42, "abc123") is False


# --- post_review ---


@patch("dobbe.core.github_review._run_gh")
def test_post_review_success_with_url(mock_gh):
    response = {"id": 12345, "html_url": "https://github.com/org/repo/pull/42#pullrequestreview-12345"}
    mock_gh.return_value = (True, json.dumps(response))
    success, url = post_review("org/repo", 42, {"body": "test", "event": "COMMENT", "comments": []})
    assert success is True
    assert "pullrequestreview" in url


@patch("dobbe.core.github_review._run_gh")
def test_post_review_success_id_fallback(mock_gh):
    response = {"id": 12345}
    mock_gh.return_value = (True, json.dumps(response))
    success, url = post_review("org/repo", 42, {"body": "test", "event": "COMMENT", "comments": []})
    assert success is True
    assert "12345" in url


@patch("dobbe.core.github_review._run_gh")
def test_post_review_success_no_id(mock_gh):
    mock_gh.return_value = (True, "{}")
    success, url = post_review("org/repo", 42, {"body": "test", "event": "COMMENT", "comments": []})
    assert success is True
    assert "org/repo" in url


@patch("dobbe.core.github_review._run_gh")
def test_post_review_failure(mock_gh):
    mock_gh.return_value = (False, "403 Forbidden")
    success, error = post_review("org/repo", 42, {"body": "test", "event": "COMMENT", "comments": []})
    assert success is False
    assert "403" in error


@patch("dobbe.core.github_review._run_gh")
def test_post_review_bad_response_json(mock_gh):
    mock_gh.return_value = (True, "not json")
    success, url = post_review("org/repo", 42, {"body": "test", "event": "COMMENT", "comments": []})
    assert success is True
    assert "org/repo" in url


# --- _run_gh edge cases ---


@patch("dobbe.core.github_review.subprocess.run")
def test_run_gh_success(mock_run):
    mock_run.return_value = subprocess.CompletedProcess(
        args=["gh", "api", "test"], returncode=0, stdout="output", stderr=""
    )
    success, output = _run_gh(["api", "test"])
    assert success is True
    assert output == "output"


@patch("dobbe.core.github_review.subprocess.run")
def test_run_gh_nonzero_exit(mock_run):
    mock_run.return_value = subprocess.CompletedProcess(
        args=["gh"], returncode=1, stdout="", stderr="error msg"
    )
    success, output = _run_gh(["api", "test"])
    assert success is False
    assert "error msg" in output


@patch("dobbe.core.github_review.subprocess.run")
def test_run_gh_nonzero_exit_no_stderr(mock_run):
    mock_run.return_value = subprocess.CompletedProcess(
        args=["gh"], returncode=1, stdout="", stderr=""
    )
    success, output = _run_gh(["api", "test"])
    assert success is False
    assert "exited with code" in output


@patch("dobbe.core.github_review.subprocess.run", side_effect=FileNotFoundError)
def test_run_gh_not_installed(mock_run):
    success, output = _run_gh(["api", "test"])
    assert success is False
    assert "not installed" in output


@patch("dobbe.core.github_review.subprocess.run", side_effect=subprocess.TimeoutExpired("gh", 30))
def test_run_gh_timeout(mock_run):
    success, output = _run_gh(["api", "test"])
    assert success is False
    assert "timed out" in output


@patch("dobbe.core.github_review.subprocess.run")
def test_run_gh_with_input_data(mock_run):
    mock_run.return_value = subprocess.CompletedProcess(
        args=["gh"], returncode=0, stdout='{"id": 1}', stderr=""
    )
    success, output = _run_gh(["api", "test", "--input", "-"], input_data='{"body": "hi"}')
    assert success is True
    mock_run.assert_called_once()
    assert mock_run.call_args.kwargs.get("input") == '{"body": "hi"}'


# --- check_existing_review non-dict entry ---


@patch("dobbe.core.github_review._run_gh")
def test_check_existing_review_non_dict_entry(mock_gh):
    reviews = ["not a dict", {"body": f"{DOBBE_REVIEW_MARKER}", "commit_id": "abc123"}]
    mock_gh.return_value = (True, json.dumps(reviews))
    assert check_existing_review("org/repo", 42, "abc123") is True


# --- fetch_pr_metadata ---


@patch("dobbe.core.github_review._run_gh")
def test_fetch_pr_metadata_success(mock_gh):
    payload = {
        "number": 42,
        "title": "Fix bug",
        "user": {"login": "alice"},
        "html_url": "https://github.com/org/repo/pull/42",
        "created_at": "2024-01-15T10:30:00Z",
        "updated_at": "2024-01-16T12:00:00Z",
        "additions": 50,
        "deletions": 10,
        "changed_files": 3,
        "draft": False,
        "body": "PR description",
        "labels": [{"name": "bug"}, {"name": "urgent"}],
    }
    mock_gh.return_value = (True, json.dumps(payload))
    pr_info, error = fetch_pr_metadata("org/repo", 42)
    assert pr_info is not None
    assert error is None
    assert pr_info.pr_number == 42
    assert pr_info.labels == ["bug", "urgent"]
    assert pr_info.author == "alice"


@patch("dobbe.core.github_review._run_gh")
def test_fetch_pr_metadata_failure(mock_gh):
    mock_gh.return_value = (False, "not found")
    pr_info, error = fetch_pr_metadata("org/repo", 42)
    assert pr_info is None
    assert "Failed to fetch" in error


@patch("dobbe.core.github_review._run_gh")
def test_fetch_pr_metadata_invalid_json(mock_gh):
    mock_gh.return_value = (True, "not json")
    pr_info, error = fetch_pr_metadata("org/repo", 42)
    assert pr_info is None
    assert "Invalid JSON" in error


@patch("dobbe.core.github_review._run_gh")
def test_fetch_pr_metadata_string_labels(mock_gh):
    payload = {
        "number": 42,
        "title": "Fix bug",
        "user": {"login": "alice"},
        "html_url": "https://github.com/org/repo/pull/42",
        "created_at": "2024-01-15T10:30:00Z",
        "updated_at": "2024-01-16T12:00:00Z",
        "labels": ["bug", "feature"],
    }
    mock_gh.return_value = (True, json.dumps(payload))
    pr_info, error = fetch_pr_metadata("org/repo", 42)
    assert pr_info is not None
    assert pr_info.labels == ["bug", "feature"]


@patch("dobbe.core.github_review._run_gh")
def test_fetch_pr_metadata_no_labels(mock_gh):
    payload = {
        "number": 42,
        "title": "Fix bug",
        "user": {"login": "alice"},
        "html_url": "https://github.com/org/repo/pull/42",
        "created_at": "2024-01-15T10:30:00Z",
        "updated_at": "2024-01-16T12:00:00Z",
    }
    mock_gh.return_value = (True, json.dumps(payload))
    pr_info, error = fetch_pr_metadata("org/repo", 42)
    assert pr_info is not None
    assert pr_info.labels == []


@patch("dobbe.core.github_review._run_gh")
def test_fetch_pr_metadata_null_body(mock_gh):
    payload = {
        "number": 42,
        "title": "Fix bug",
        "user": {"login": "alice"},
        "html_url": "https://github.com/org/repo/pull/42",
        "created_at": "2024-01-15T10:30:00Z",
        "updated_at": "2024-01-16T12:00:00Z",
        "body": None,
    }
    mock_gh.return_value = (True, json.dumps(payload))
    pr_info, error = fetch_pr_metadata("org/repo", 42)
    assert pr_info is not None
    assert pr_info.description == ""


# --- fetch_pr_diff ---


@patch("dobbe.core.github_review._run_gh")
def test_fetch_pr_diff_success(mock_gh):
    mock_gh.return_value = (True, "diff line 1\ndiff line 2")
    diff, error = fetch_pr_diff("org/repo", 42)
    assert diff == "diff line 1\ndiff line 2"
    assert error is None


@patch("dobbe.core.github_review._run_gh")
def test_fetch_pr_diff_failure(mock_gh):
    mock_gh.return_value = (False, "error msg")
    diff, error = fetch_pr_diff("org/repo", 42)
    assert diff == ""
    assert "Failed to fetch diff" in error


@patch("dobbe.core.github_review._run_gh")
def test_fetch_pr_diff_truncation(mock_gh):
    long_diff = "\n".join(f"line {i}" for i in range(20))
    mock_gh.return_value = (True, long_diff)
    diff, error = fetch_pr_diff("org/repo", 42, max_lines=5)
    assert error is None
    lines = diff.split("\n")
    assert lines[0] == "line 0"
    assert lines[4] == "line 4"
    assert "truncated" in diff


@patch("dobbe.core.github_review._run_gh")
def test_fetch_pr_diff_empty(mock_gh):
    mock_gh.return_value = (True, "")
    diff, error = fetch_pr_diff("org/repo", 42)
    assert diff == ""
    assert error is None
