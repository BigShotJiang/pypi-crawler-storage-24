"""CLI e2e tests for schedule commands."""

from __future__ import annotations

from datetime import datetime, timedelta
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from dobbe.cli import app
from dobbe.models.schedule import RunLog, RunStatus, Schedule, ScheduleInterval

runner = CliRunner()


# ---------------------------------------------------------------------------
# schedule --help
# ---------------------------------------------------------------------------


def test_schedule_help():
    result = runner.invoke(app, ["schedule", "--help"])
    assert result.exit_code == 0
    assert "add" in result.output
    assert "list" in result.output
    assert "remove" in result.output
    assert "check" in result.output


# ---------------------------------------------------------------------------
# schedule add
# ---------------------------------------------------------------------------


def test_schedule_add(sched_dir):
    result = runner.invoke(app, [
        "schedule", "add", "test-vuln",
        "--command", "vuln scan",
        "--args", "--org acme",
        "--every", "daily",
    ])
    assert result.exit_code == 0
    assert "added" in result.output


def test_schedule_add_unknown_command_warns(sched_dir):
    result = runner.invoke(app, [
        "schedule", "add", "test-unknown",
        "--command", "bogus command",
        "--every", "hourly",
    ])
    assert result.exit_code == 0
    assert "Warning" in result.output
    assert "not a known" in result.output


def test_schedule_add_duplicate_fails(sched_dir):
    runner.invoke(app, [
        "schedule", "add", "dupe",
        "--command", "vuln scan",
        "--every", "daily",
    ])
    result = runner.invoke(app, [
        "schedule", "add", "dupe",
        "--command", "vuln scan",
        "--every", "daily",
    ])
    assert result.exit_code == 1
    assert "already exists" in result.output


# ---------------------------------------------------------------------------
# schedule list
# ---------------------------------------------------------------------------


def test_schedule_list_empty(sched_dir):
    result = runner.invoke(app, ["schedule", "list"])
    assert result.exit_code == 0
    assert "No schedules" in result.output


def test_schedule_list_with_entries(sched_dir):
    runner.invoke(app, [
        "schedule", "add", "vuln-daily",
        "--command", "vuln scan",
        "--every", "daily",
    ])
    result = runner.invoke(app, ["schedule", "list"])
    assert result.exit_code == 0
    assert "vuln-daily" in result.output
    assert "daily" in result.output


# ---------------------------------------------------------------------------
# schedule remove
# ---------------------------------------------------------------------------


def test_schedule_remove_with_force(sched_dir):
    runner.invoke(app, [
        "schedule", "add", "to-remove",
        "--command", "vuln scan",
        "--every", "daily",
    ])
    result = runner.invoke(app, ["schedule", "remove", "to-remove", "--force"])
    assert result.exit_code == 0
    assert "removed" in result.output


def test_schedule_remove_missing(sched_dir):
    result = runner.invoke(app, ["schedule", "remove", "nonexistent", "--force"])
    assert result.exit_code == 1
    assert "not found" in result.output


# ---------------------------------------------------------------------------
# schedule check
# ---------------------------------------------------------------------------


def test_schedule_check_no_overdue(sched_dir):
    result = runner.invoke(app, ["schedule", "check"])
    assert result.exit_code == 0
    assert "No overdue" in result.output


def test_schedule_check_dry_run(sched_dir):
    runner.invoke(app, [
        "schedule", "add", "test-check",
        "--command", "vuln scan",
        "--every", "daily",
    ])
    result = runner.invoke(app, ["schedule", "check", "--dry-run"])
    assert result.exit_code == 0
    assert "would run" in result.output
    assert "test-check" in result.output


def test_schedule_check_executes(sched_dir):
    runner.invoke(app, [
        "schedule", "add", "test-exec",
        "--command", "vuln scan",
        "--every", "daily",
    ])
    with patch("dobbe.core.scheduler.subprocess.run") as mock_run:
        mock_run.return_value.returncode = 0
        mock_run.return_value.stdout = "done\n"
        mock_run.return_value.stderr = ""
        result = runner.invoke(app, ["schedule", "check"])
    assert result.exit_code == 0
    assert "executed" in result.output or "schedule(s)" in result.output


def test_schedule_check_quiet(sched_dir):
    result = runner.invoke(app, ["schedule", "check", "--quiet"])
    assert result.exit_code == 0


# ---------------------------------------------------------------------------
# schedule run
# ---------------------------------------------------------------------------


def test_schedule_run_missing(sched_dir):
    result = runner.invoke(app, ["schedule", "run", "nonexistent"])
    assert result.exit_code == 1
    assert "not found" in result.output


def test_schedule_run_success(sched_dir):
    runner.invoke(app, [
        "schedule", "add", "manual-run",
        "--command", "vuln scan",
        "--every", "daily",
    ])
    with patch("dobbe.core.scheduler.subprocess.run") as mock_run:
        mock_run.return_value.returncode = 0
        mock_run.return_value.stdout = "Scan complete\n"
        mock_run.return_value.stderr = ""
        result = runner.invoke(app, ["schedule", "run", "manual-run"])
    assert result.exit_code == 0
    assert "Completed" in result.output


def test_schedule_run_failure(sched_dir):
    runner.invoke(app, [
        "schedule", "add", "fail-run",
        "--command", "vuln scan",
        "--every", "daily",
    ])
    with patch("dobbe.core.scheduler.subprocess.run") as mock_run:
        mock_run.return_value.returncode = 1
        mock_run.return_value.stdout = ""
        mock_run.return_value.stderr = "Error: auth failed"
        result = runner.invoke(app, ["schedule", "run", "fail-run"])
    assert result.exit_code == 1


# ---------------------------------------------------------------------------
# schedule logs
# ---------------------------------------------------------------------------


def test_schedule_logs_empty(sched_dir):
    result = runner.invoke(app, ["schedule", "logs", "nonexistent"])
    assert result.exit_code == 0
    assert "No logs" in result.output


def test_schedule_logs_with_entries(sched_dir):
    from dobbe.core.scheduler import save_run_log

    log = RunLog(
        schedule_name="test-log",
        started_at=datetime(2026, 3, 19, 8, 30),
        finished_at=datetime(2026, 3, 19, 8, 31),
        status=RunStatus.SUCCESS,
        duration_seconds=60.0,
        command="vuln scan",
        args="",
        summary="Completed scan",
    )
    save_run_log(log)

    result = runner.invoke(app, ["schedule", "logs", "test-log"])
    assert result.exit_code == 0
    assert "test-log" in result.output


def test_schedule_logs_all(sched_dir):
    from dobbe.core.scheduler import save_run_log, save_schedules

    sched = Schedule(
        name="sched-a",
        command="vuln scan",
        interval=ScheduleInterval.DAILY,
        created_at=datetime(2026, 3, 15),
    )
    save_schedules({sched.name: sched})

    log = RunLog(
        schedule_name="sched-a",
        started_at=datetime(2026, 3, 19, 8, 30),
        finished_at=datetime(2026, 3, 19, 8, 31),
        status=RunStatus.SUCCESS,
        duration_seconds=60.0,
        command="vuln scan",
        args="",
    )
    save_run_log(log)

    result = runner.invoke(app, ["schedule", "logs"])
    assert result.exit_code == 0
    assert "sched-a" in result.output


# ---------------------------------------------------------------------------
# schedule install
# ---------------------------------------------------------------------------


def test_schedule_install_shell_already_installed(sched_dir, tmp_path):
    profile = tmp_path / ".zshrc"
    profile.write_text("# dobbe scheduler hook\ncommand -v dobbe >/dev/null 2>&1 && dobbe schedule check --quiet &\n")

    with patch("dobbe.core.scheduler.get_shell_hook_info", return_value=("hook text\n", profile)):
        with patch("dobbe.core.scheduler.install_shell_hook", return_value=(False, f"Hook already installed in {profile}")):
            result = runner.invoke(app, ["schedule", "install", "--trigger", "shell"], input="y\n")
    assert result.exit_code == 0
    assert "already installed" in result.output


def test_schedule_install_shell_success(sched_dir, tmp_path):
    profile = tmp_path / ".zshrc"

    with patch("dobbe.core.scheduler.get_shell_hook_info", return_value=("hook text\n", profile)):
        with patch("dobbe.core.scheduler.install_shell_hook", return_value=(True, f"Hook installed in {profile}")):
            result = runner.invoke(app, ["schedule", "install", "--trigger", "shell"], input="y\n")
    assert result.exit_code == 0
    assert "installed" in result.output.lower()


def test_schedule_install_uninstall_shell(sched_dir, tmp_path):
    with patch("dobbe.commands.schedule.uninstall_shell_hook", return_value=(True, "Hook removed")):
        result = runner.invoke(app, ["schedule", "install", "--trigger", "shell", "--uninstall"])
    assert result.exit_code == 0
    assert "removed" in result.output.lower()


def test_schedule_install_login(sched_dir):
    with patch("dobbe.core.scheduler.install_login_hook", return_value=(True, "LaunchAgent installed")):
        result = runner.invoke(app, ["schedule", "install", "--trigger", "login"])
    assert result.exit_code == 0
    assert "installed" in result.output.lower()


def test_schedule_install_login_uninstall(sched_dir):
    with patch("dobbe.core.scheduler.uninstall_login_hook", return_value=(True, "LaunchAgent removed")):
        result = runner.invoke(app, ["schedule", "install", "--trigger", "login", "--uninstall"])
    assert result.exit_code == 0
    assert "removed" in result.output.lower()


def test_schedule_install_unknown_trigger(sched_dir):
    result = runner.invoke(app, ["schedule", "install", "--trigger", "cron"])
    assert result.exit_code == 1
    assert "Unknown trigger" in result.output


# ---------------------------------------------------------------------------
# schedule list - display variants
# ---------------------------------------------------------------------------


def test_schedule_list_with_last_run(sched_dir):
    """List shows last_run and next_due when schedule has run before."""
    from dobbe.core.scheduler import save_schedules

    sched = Schedule(
        name="ran-before",
        command="vuln scan",
        args="--org acme",
        interval=ScheduleInterval.DAILY,
        last_run=datetime(2026, 3, 19, 8, 30),
        created_at=datetime(2026, 3, 15),
    )
    save_schedules({sched.name: sched})
    result = runner.invoke(app, ["schedule", "list"])
    assert result.exit_code == 0
    assert "ran-before" in result.output
    assert "2026-03-19" in result.output


def test_schedule_list_disabled(sched_dir):
    """Disabled schedules show 'disabled' status."""
    from dobbe.core.scheduler import save_schedules

    sched = Schedule(
        name="disabled-sched",
        command="vuln scan",
        interval=ScheduleInterval.DAILY,
        enabled=False,
        created_at=datetime(2026, 3, 15),
    )
    save_schedules({sched.name: sched})
    result = runner.invoke(app, ["schedule", "list"])
    assert result.exit_code == 0
    assert "disabled" in result.output


def test_schedule_list_on_schedule(sched_dir):
    """A recently-run schedule shows 'on schedule'."""
    from dobbe.core.scheduler import save_schedules

    sched = Schedule(
        name="on-time",
        command="vuln scan",
        interval=ScheduleInterval.DAILY,
        last_run=datetime.now(),
        created_at=datetime(2026, 3, 15),
    )
    save_schedules({sched.name: sched})
    result = runner.invoke(app, ["schedule", "list"])
    assert result.exit_code == 0
    assert "on schedule" in result.output


# ---------------------------------------------------------------------------
# schedule check - quiet mode with failures
# ---------------------------------------------------------------------------


def test_schedule_check_quiet_with_failures(sched_dir):
    """Quiet check shows error summary on failure."""
    runner.invoke(app, [
        "schedule", "add", "fail-check",
        "--command", "vuln scan",
        "--every", "daily",
    ])
    with patch("dobbe.core.scheduler.subprocess.run") as mock_run:
        mock_run.return_value.returncode = 1
        mock_run.return_value.stdout = ""
        mock_run.return_value.stderr = "Auth error"
        result = runner.invoke(app, ["schedule", "check", "--quiet"])
    assert result.exit_code == 0
    # CliRunner captures both stdout and stderr in result.output
    # Use AND (not OR) to assert both the failure detail and summary are present
    assert "schedule(s) run" in result.output
    assert "fail-check" in result.output


def test_schedule_check_dry_run_quiet_no_overdue(sched_dir):
    """Dry-run + quiet with no overdue schedules: silent."""
    from dobbe.core.scheduler import save_schedules

    sched = Schedule(
        name="recent",
        command="vuln scan",
        interval=ScheduleInterval.DAILY,
        last_run=datetime.now(),
        created_at=datetime(2026, 3, 15),
    )
    save_schedules({sched.name: sched})
    result = runner.invoke(app, ["schedule", "check", "--dry-run", "--quiet"])
    assert result.exit_code == 0


def test_schedule_check_dry_run_with_args(sched_dir):
    """Dry-run shows command with args."""
    runner.invoke(app, [
        "schedule", "add", "args-check",
        "--command", "vuln scan",
        "--args", "--org acme",
        "--every", "daily",
    ])
    result = runner.invoke(app, ["schedule", "check", "--dry-run"])
    assert result.exit_code == 0
    assert "--org acme" in result.output


# ---------------------------------------------------------------------------
# schedule check - verbose output variants
# ---------------------------------------------------------------------------


def test_schedule_check_verbose_success(sched_dir):
    """Verbose check shows success output with duration."""
    runner.invoke(app, [
        "schedule", "add", "verbose-ok",
        "--command", "vuln scan",
        "--every", "daily",
    ])
    with patch("dobbe.core.scheduler.subprocess.run") as mock_run:
        mock_run.return_value.returncode = 0
        mock_run.return_value.stdout = "All clear\n"
        mock_run.return_value.stderr = ""
        result = runner.invoke(app, ["schedule", "check"])
    assert result.exit_code == 0
    assert "verbose-ok" in result.output


def test_schedule_check_verbose_failure(sched_dir):
    """Verbose check shows failure output."""
    runner.invoke(app, [
        "schedule", "add", "verbose-fail",
        "--command", "vuln scan",
        "--every", "daily",
    ])
    with patch("dobbe.core.scheduler.subprocess.run") as mock_run:
        mock_run.return_value.returncode = 1
        mock_run.return_value.stdout = ""
        mock_run.return_value.stderr = "Connection refused"
        result = runner.invoke(app, ["schedule", "check"])
    assert result.exit_code == 0
    assert "verbose-fail" in result.output


# ---------------------------------------------------------------------------
# schedule run - output detail
# ---------------------------------------------------------------------------


def test_schedule_run_shows_summary(sched_dir):
    """Run command shows summary on success."""
    runner.invoke(app, [
        "schedule", "add", "summary-run",
        "--command", "vuln scan",
        "--args", "--org test",
        "--every", "daily",
    ])
    with patch("dobbe.core.scheduler.subprocess.run") as mock_run:
        mock_run.return_value.returncode = 0
        mock_run.return_value.stdout = "3 vulnerabilities found\n"
        mock_run.return_value.stderr = ""
        result = runner.invoke(app, ["schedule", "run", "summary-run"])
    assert result.exit_code == 0
    assert "Completed" in result.output


# ---------------------------------------------------------------------------
# schedule remove - confirmation prompt
# ---------------------------------------------------------------------------


def test_schedule_remove_with_confirmation(sched_dir):
    """Remove without --force asks for confirmation."""
    runner.invoke(app, [
        "schedule", "add", "confirm-rm",
        "--command", "vuln scan",
        "--every", "daily",
    ])
    result = runner.invoke(app, ["schedule", "remove", "confirm-rm"], input="y\n")
    assert result.exit_code == 0
    assert "removed" in result.output


def test_schedule_remove_declined(sched_dir):
    """Remove declined by user doesn't remove schedule."""
    runner.invoke(app, [
        "schedule", "add", "keep-me",
        "--command", "vuln scan",
        "--every", "daily",
    ])
    result = runner.invoke(app, ["schedule", "remove", "keep-me"], input="n\n")
    assert result.exit_code != 0 or "Aborted" in result.output


# ---------------------------------------------------------------------------
# Lifecycle integration test
# ---------------------------------------------------------------------------


def test_schedule_lifecycle_add_check_logs(sched_dir):
    """Full lifecycle: add → check (overdue) → logs shows the run."""
    # 1. Add a schedule
    result = runner.invoke(app, [
        "schedule", "add", "lifecycle-test",
        "--command", "vuln scan",
        "--every", "daily",
    ])
    assert result.exit_code == 0
    assert "added" in result.output

    # 2. Check - should be overdue (never run) and execute
    with patch("dobbe.core.scheduler.subprocess.run") as mock_run:
        mock_run.return_value.returncode = 0
        mock_run.return_value.stdout = "Scan complete\n"
        mock_run.return_value.stderr = ""
        result = runner.invoke(app, ["schedule", "check"])
    assert result.exit_code == 0
    assert "lifecycle-test" in result.output

    # 3. Verify logs show the run
    result = runner.invoke(app, ["schedule", "logs", "lifecycle-test"])
    assert result.exit_code == 0
    assert "lifecycle-test" in result.output
    assert "success" in result.output

    # 4. Verify the schedule TOML is still readable (last_run was updated)
    from dobbe.core.scheduler import load_schedules
    schedules = load_schedules()
    assert "lifecycle-test" in schedules
    assert schedules["lifecycle-test"].last_run is not None


# ---------------------------------------------------------------------------
# schedule run - lock prevents concurrent execution
# ---------------------------------------------------------------------------


def test_schedule_run_locked(sched_dir):
    """Run command fails when schedule is already locked."""
    from dobbe.core.scheduler import acquire_lock, release_lock

    runner.invoke(app, [
        "schedule", "add", "locked-run",
        "--command", "vuln scan",
        "--every", "daily",
    ])
    lock = acquire_lock("locked-run")
    assert lock is not None

    result = runner.invoke(app, ["schedule", "run", "locked-run"])
    assert result.exit_code == 1
    assert "currently running" in result.output

    release_lock("locked-run")
