"""Tests for core scheduler logic."""

from __future__ import annotations

import json
import os
import subprocess
from datetime import datetime, timedelta
from unittest.mock import patch

import pytest
import tomli_w

from dobbe.core.scheduler import (
    GRACE_PERIOD,
    MAX_LOGS_PER_SCHEDULE,
    _is_stale_lock,
    _prune_logs,
    _update_last_run,
    acquire_lock,
    add_schedule,
    execute_schedule,
    find_overdue,
    load_run_logs,
    load_schedules,
    release_lock,
    remove_schedule,
    run_check,
    save_run_log,
    save_schedules,
)
from dobbe.models.schedule import (
    INTERVAL_DELTAS,
    RunLog,
    RunStatus,
    Schedule,
    ScheduleInterval,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _make_schedule(
    name: str = "test-sched",
    command: str = "vuln scan",
    args: str = "",
    interval: ScheduleInterval = ScheduleInterval.DAILY,
    enabled: bool = True,
    last_run: datetime | None = None,
) -> Schedule:
    return Schedule(
        name=name,
        command=command,
        args=args,
        interval=interval,
        enabled=enabled,
        last_run=last_run,
        created_at=datetime(2026, 3, 15, 10, 0),
    )


# ---------------------------------------------------------------------------
# TOML round-trip
# ---------------------------------------------------------------------------


def test_load_schedules_empty(sched_dir):
    result = load_schedules()
    assert result == {}


def test_save_and_load_roundtrip(sched_dir):
    now = datetime(2026, 3, 19, 8, 30)
    sched = _make_schedule(last_run=now)
    save_schedules({sched.name: sched})

    loaded = load_schedules()
    assert sched.name in loaded
    s = loaded[sched.name]
    assert s.command == "vuln scan"
    assert s.interval == ScheduleInterval.DAILY
    assert s.last_run == now
    assert s.enabled is True


def test_save_multiple_schedules(sched_dir):
    s1 = _make_schedule(name="daily-vuln", command="vuln scan", interval=ScheduleInterval.DAILY)
    s2 = _make_schedule(name="weekly-review", command="review digest", interval=ScheduleInterval.WEEKLY)
    save_schedules({s1.name: s1, s2.name: s2})

    loaded = load_schedules()
    assert len(loaded) == 2
    assert "daily-vuln" in loaded
    assert "weekly-review" in loaded


def test_save_schedule_without_last_run(sched_dir):
    sched = _make_schedule(last_run=None)
    save_schedules({sched.name: sched})
    loaded = load_schedules()
    assert loaded[sched.name].last_run is None


# ---------------------------------------------------------------------------
# add / remove
# ---------------------------------------------------------------------------


def test_add_schedule(sched_dir):
    sched = _make_schedule()
    add_schedule(sched)
    loaded = load_schedules()
    assert sched.name in loaded


def test_add_schedule_duplicate_raises(sched_dir):
    sched = _make_schedule()
    add_schedule(sched)
    with pytest.raises(ValueError, match="already exists"):
        add_schedule(sched)


def test_remove_schedule(sched_dir):
    sched = _make_schedule()
    add_schedule(sched)
    remove_schedule(sched.name)
    loaded = load_schedules()
    assert sched.name not in loaded


def test_remove_schedule_missing_raises(sched_dir):
    with pytest.raises(KeyError, match="not found"):
        remove_schedule("nonexistent")


# ---------------------------------------------------------------------------
# Overdue detection
# ---------------------------------------------------------------------------


def test_overdue_never_run():
    sched = _make_schedule(last_run=None)
    overdue = find_overdue({sched.name: sched})
    assert len(overdue) == 1
    assert overdue[0].name == sched.name


def test_overdue_just_ran():
    now = datetime(2026, 3, 19, 10, 0)
    sched = _make_schedule(last_run=now - timedelta(minutes=1))
    overdue = find_overdue({sched.name: sched}, now=now)
    assert len(overdue) == 0


def test_overdue_past_interval():
    now = datetime(2026, 3, 19, 10, 0)
    sched = _make_schedule(
        interval=ScheduleInterval.DAILY,
        last_run=now - timedelta(hours=25),
    )
    overdue = find_overdue({sched.name: sched}, now=now)
    assert len(overdue) == 1


def test_overdue_within_grace_period():
    now = datetime(2026, 3, 19, 10, 0)
    # Ran exactly 24h + 3min ago - within the 5min grace window
    sched = _make_schedule(
        interval=ScheduleInterval.DAILY,
        last_run=now - timedelta(hours=24, minutes=3),
    )
    overdue = find_overdue({sched.name: sched}, now=now)
    assert len(overdue) == 0


def test_overdue_past_grace_period():
    now = datetime(2026, 3, 19, 10, 0)
    # Ran exactly 24h + 6min ago - past the 5min grace
    sched = _make_schedule(
        interval=ScheduleInterval.DAILY,
        last_run=now - timedelta(hours=24, minutes=6),
    )
    overdue = find_overdue({sched.name: sched}, now=now)
    assert len(overdue) == 1


def test_overdue_disabled_schedule():
    sched = _make_schedule(enabled=False, last_run=None)
    overdue = find_overdue({sched.name: sched})
    assert len(overdue) == 0


def test_overdue_multiple_schedules():
    now = datetime(2026, 3, 19, 10, 0)
    s1 = _make_schedule(name="a", last_run=None)  # overdue
    s2 = _make_schedule(name="b", last_run=now - timedelta(minutes=1))  # not overdue
    s3 = _make_schedule(name="c", last_run=now - timedelta(hours=25))  # overdue
    schedules = {s.name: s for s in [s1, s2, s3]}
    overdue = find_overdue(schedules, now=now)
    names = {s.name for s in overdue}
    assert names == {"a", "c"}


# ---------------------------------------------------------------------------
# Execution
# ---------------------------------------------------------------------------


def test_execute_schedule_success(sched_dir):
    sched = _make_schedule(command="--version")
    with patch("dobbe.core.scheduler.subprocess.run") as mock_run:
        mock_run.return_value.returncode = 0
        mock_run.return_value.stdout = "dobbe 0.1.0\n"
        mock_run.return_value.stderr = ""
        log = execute_schedule(sched)
    assert log.status == RunStatus.SUCCESS
    assert log.exit_code == 0
    assert "0.1.0" in log.summary


def test_execute_schedule_failure(sched_dir):
    sched = _make_schedule()
    with patch("dobbe.core.scheduler.subprocess.run") as mock_run:
        mock_run.return_value.returncode = 1
        mock_run.return_value.stdout = ""
        mock_run.return_value.stderr = "Error: something broke"
        log = execute_schedule(sched)
    assert log.status == RunStatus.FAILED
    assert log.exit_code == 1
    assert "something broke" in log.error


def test_execute_schedule_timeout(sched_dir):
    import subprocess as sp

    sched = _make_schedule()
    with patch("dobbe.core.scheduler.subprocess.run", side_effect=sp.TimeoutExpired(cmd="test", timeout=10)):
        log = execute_schedule(sched, timeout=10)
    assert log.status == RunStatus.TIMEOUT
    assert log.exit_code == -1


def test_execute_schedule_missing_executable(sched_dir):
    """Missing executable raises OSError, caught and returns FAILED (Bug B)."""
    sched = _make_schedule()
    with patch("dobbe.core.scheduler.subprocess.run", side_effect=FileNotFoundError("No such file")):
        log = execute_schedule(sched)
    assert log.status == RunStatus.FAILED
    assert log.exit_code == -1
    assert "Failed to execute" in log.error


def test_execute_schedule_updates_last_run(sched_dir):
    sched = _make_schedule()
    add_schedule(sched)
    with patch("dobbe.core.scheduler.subprocess.run") as mock_run:
        mock_run.return_value.returncode = 0
        mock_run.return_value.stdout = "done\n"
        mock_run.return_value.stderr = ""
        execute_schedule(sched)
    loaded = load_schedules()
    assert loaded[sched.name].last_run is not None


# ---------------------------------------------------------------------------
# Locking
# ---------------------------------------------------------------------------


def test_acquire_and_release_lock(sched_dir):
    lock = acquire_lock("test")
    assert lock is not None
    assert lock.exists()
    release_lock("test")
    assert not lock.exists()


def test_acquire_lock_held(sched_dir):
    lock1 = acquire_lock("test")
    assert lock1 is not None
    lock2 = acquire_lock("test")
    assert lock2 is None
    release_lock("test")


def test_stale_lock_dead_process(sched_dir):
    lock = acquire_lock("test")
    assert lock is not None
    # Write a PID that doesn't exist
    pid_file = lock / "pid"
    pid_file.write_text("999999999")
    assert _is_stale_lock(lock) is True
    # Should be reclaimable
    release_lock("test")
    lock2 = acquire_lock("test")
    assert lock2 is not None
    release_lock("test")


def test_stale_lock_no_pid_file(sched_dir):
    lock_dir = sched_dir / "locks" / "test.lock"
    lock_dir.mkdir(parents=True)
    assert _is_stale_lock(lock_dir) is True


def test_lock_reclaimed_on_stale(sched_dir):
    # Create a lock with a dead PID
    lock_dir = sched_dir / "locks" / "reclaim.lock"
    lock_dir.mkdir(parents=True)
    pid_file = lock_dir / "pid"
    pid_file.write_text("999999999")

    lock = acquire_lock("reclaim")
    assert lock is not None
    release_lock("reclaim")


# ---------------------------------------------------------------------------
# Run logging
# ---------------------------------------------------------------------------


def _make_run_log(name: str = "test", status: RunStatus = RunStatus.SUCCESS, minutes_ago: int = 0) -> RunLog:
    started = datetime(2026, 3, 19, 8, 30) - timedelta(minutes=minutes_ago)
    return RunLog(
        schedule_name=name,
        started_at=started,
        finished_at=started + timedelta(seconds=60),
        status=status,
        duration_seconds=60.0,
        command="vuln scan",
        args="",
    )


def test_save_and_load_run_log(sched_dir):
    log = _make_run_log()
    path = save_run_log(log)
    assert path.exists()

    logs = load_run_logs("test")
    assert len(logs) == 1
    assert logs[0].schedule_name == "test"
    assert logs[0].status == RunStatus.SUCCESS


def test_load_run_logs_limit(sched_dir):
    for i in range(5):
        save_run_log(_make_run_log(minutes_ago=i * 10))
    logs = load_run_logs("test", limit=3)
    assert len(logs) == 3


def test_load_run_logs_empty(sched_dir):
    logs = load_run_logs("nonexistent")
    assert logs == []


def test_prune_logs(sched_dir):
    log_dir = sched_dir / "logs" / "schedules" / "test"
    log_dir.mkdir(parents=True)
    # Create more than MAX_LOGS_PER_SCHEDULE files
    for i in range(MAX_LOGS_PER_SCHEDULE + 10):
        ts = f"20260319T{i:06d}"
        (log_dir / f"{ts}.json").write_text("{}")
    _prune_logs(log_dir)
    remaining = list(log_dir.glob("*.json"))
    assert len(remaining) == MAX_LOGS_PER_SCHEDULE


# ---------------------------------------------------------------------------
# run_check orchestration
# ---------------------------------------------------------------------------


def test_run_check_no_overdue(sched_dir):
    now = datetime.now()
    sched = _make_schedule(last_run=now - timedelta(minutes=1))
    save_schedules({sched.name: sched})

    result = run_check()
    assert result.schedules_checked == 1
    assert result.schedules_run == 0


def test_run_check_dry_run(sched_dir):
    sched = _make_schedule(last_run=None)
    save_schedules({sched.name: sched})

    result = run_check(dry_run=True)
    assert result.schedules_checked == 1
    assert result.schedules_run == 1
    assert len(result.results) == 0  # dry-run doesn't execute


def test_run_check_executes_overdue(sched_dir):
    sched = _make_schedule(last_run=None)
    save_schedules({sched.name: sched})

    with patch("dobbe.core.scheduler.subprocess.run") as mock_run:
        mock_run.return_value.returncode = 0
        mock_run.return_value.stdout = "done\n"
        mock_run.return_value.stderr = ""
        result = run_check()

    assert result.schedules_run == 1
    assert len(result.results) == 1
    assert result.results[0].status == RunStatus.SUCCESS


def test_run_check_global_lock_prevents_concurrent(sched_dir):
    # Acquire the global lock
    lock = acquire_lock("_schedule_check")
    assert lock is not None

    # Run check should bail out immediately
    result = run_check()
    assert result.schedules_checked == 0
    assert result.schedules_run == 0

    release_lock("_schedule_check")


# ---------------------------------------------------------------------------
# _update_last_run
# ---------------------------------------------------------------------------


def test_update_last_run(sched_dir):
    sched = _make_schedule(last_run=None)
    save_schedules({sched.name: sched})
    now = datetime(2026, 3, 19, 10, 0)
    _update_last_run(sched.name, now)
    loaded = load_schedules()
    assert loaded[sched.name].last_run == now


def test_update_last_run_nonexistent(sched_dir):
    """Updating last_run for a nonexistent schedule should be a no-op."""
    _update_last_run("nonexistent", datetime.now())
    assert load_schedules() == {}


# ---------------------------------------------------------------------------
# Shell hook functions
# ---------------------------------------------------------------------------


def test_detect_shell_zsh(monkeypatch):
    from dobbe.core.scheduler import detect_shell
    monkeypatch.setenv("SHELL", "/bin/zsh")
    assert detect_shell() == "zsh"


def test_detect_shell_bash(monkeypatch):
    from dobbe.core.scheduler import detect_shell
    monkeypatch.setenv("SHELL", "/bin/bash")
    assert detect_shell() == "bash"


def test_detect_shell_fish(monkeypatch):
    from dobbe.core.scheduler import detect_shell
    monkeypatch.setenv("SHELL", "/usr/bin/fish")
    assert detect_shell() == "fish"


def test_detect_shell_unknown_defaults_zsh(monkeypatch):
    from dobbe.core.scheduler import detect_shell
    monkeypatch.setenv("SHELL", "/usr/bin/csh")
    assert detect_shell() == "zsh"


def test_detect_shell_no_false_positive(monkeypatch):
    """Substring matches like 'crawfish' should not match 'fish'."""
    from dobbe.core.scheduler import detect_shell
    monkeypatch.setenv("SHELL", "/usr/bin/crawfish")
    assert detect_shell() == "zsh"  # fallback, not "fish"


def test_get_shell_hook_info_zsh():
    from dobbe.core.scheduler import get_shell_hook_info
    hook_text, profile = get_shell_hook_info("zsh")
    assert "dobbe scheduler hook" in hook_text
    assert profile.name == ".zshrc"


def test_get_shell_hook_info_fish():
    from dobbe.core.scheduler import get_shell_hook_info
    hook_text, profile = get_shell_hook_info("fish")
    assert "command -q dobbe" in hook_text
    assert profile.name == "config.fish"


def test_install_shell_hook_new_profile(tmp_path, monkeypatch):
    from dobbe.core.scheduler import install_shell_hook, DOBBE_HOOK_START, DOBBE_HOOK_END
    # Point to a non-existent profile
    profile = tmp_path / ".zshrc"
    hook_text = f"{DOBBE_HOOK_START}\nhook line\n{DOBBE_HOOK_END}\n"
    monkeypatch.setattr("dobbe.core.scheduler.get_shell_hook_info", lambda s=None: (hook_text, profile))
    success, msg = install_shell_hook()
    assert success is True
    assert profile.exists()
    assert DOBBE_HOOK_START in profile.read_text()


def test_install_shell_hook_already_installed(tmp_path, monkeypatch):
    from dobbe.core.scheduler import install_shell_hook, DOBBE_HOOK_START, DOBBE_HOOK_END
    profile = tmp_path / ".zshrc"
    profile.write_text(f"existing content\n{DOBBE_HOOK_START}\nhook line\n{DOBBE_HOOK_END}\n")
    monkeypatch.setattr("dobbe.core.scheduler.get_shell_hook_info", lambda s=None: ("hook\n", profile))
    success, msg = install_shell_hook()
    assert success is False
    assert "already installed" in msg


def test_uninstall_shell_hook_success(tmp_path, monkeypatch):
    from dobbe.core.scheduler import uninstall_shell_hook, DOBBE_HOOK_START, DOBBE_HOOK_END
    profile = tmp_path / ".zshrc"
    profile.write_text(f"before\n{DOBBE_HOOK_START}\nhook line\n{DOBBE_HOOK_END}\nafter\n")
    monkeypatch.setattr("dobbe.core.scheduler.get_shell_hook_info", lambda s=None: ("hook\n", profile))
    success, msg = uninstall_shell_hook()
    assert success is True
    content = profile.read_text()
    assert DOBBE_HOOK_START not in content
    assert "before" in content
    assert "after" in content


def test_uninstall_shell_hook_legacy_format(tmp_path, monkeypatch):
    """Uninstall handles the old single-marker format."""
    from dobbe.core.scheduler import uninstall_shell_hook
    profile = tmp_path / ".zshrc"
    profile.write_text("before\n# dobbe scheduler hook\ncommand -v dobbe >/dev/null 2>&1 && dobbe schedule check --quiet &\nafter\n")
    monkeypatch.setattr("dobbe.core.scheduler.get_shell_hook_info", lambda s=None: ("hook\n", profile))
    success, msg = uninstall_shell_hook()
    assert success is True
    content = profile.read_text()
    assert "# dobbe scheduler hook" not in content
    assert "before" in content
    assert "after" in content


def test_uninstall_shell_hook_no_profile(tmp_path, monkeypatch):
    from dobbe.core.scheduler import uninstall_shell_hook
    profile = tmp_path / ".zshrc"  # doesn't exist
    monkeypatch.setattr("dobbe.core.scheduler.get_shell_hook_info", lambda s=None: ("hook\n", profile))
    success, msg = uninstall_shell_hook()
    assert success is False
    assert "not found" in msg.lower()


def test_uninstall_shell_hook_no_marker(tmp_path, monkeypatch):
    from dobbe.core.scheduler import uninstall_shell_hook
    profile = tmp_path / ".zshrc"
    profile.write_text("some content\n")
    monkeypatch.setattr("dobbe.core.scheduler.get_shell_hook_info", lambda s=None: ("hook\n", profile))
    success, msg = uninstall_shell_hook()
    assert success is False
    assert "No dobbe hook" in msg


# ---------------------------------------------------------------------------
# Login hook dispatch
# ---------------------------------------------------------------------------


def test_install_login_hook_darwin(monkeypatch):
    from dobbe.core.scheduler import install_login_hook
    monkeypatch.setattr("dobbe.core.scheduler.sys.platform", "darwin")
    monkeypatch.setattr("dobbe.core.scheduler._install_launchd", lambda: (True, "installed"))
    success, msg = install_login_hook()
    assert success is True


def test_install_login_hook_linux(monkeypatch):
    from dobbe.core.scheduler import install_login_hook
    monkeypatch.setattr("dobbe.core.scheduler.sys.platform", "linux")
    monkeypatch.setattr("dobbe.core.scheduler._install_systemd", lambda: (True, "installed"))
    success, msg = install_login_hook()
    assert success is True


def test_install_login_hook_win32(monkeypatch):
    from dobbe.core.scheduler import install_login_hook
    monkeypatch.setattr("dobbe.core.scheduler.sys.platform", "win32")
    monkeypatch.setattr("dobbe.core.scheduler._install_schtasks", lambda: (True, "installed"))
    success, msg = install_login_hook()
    assert success is True


def test_install_login_hook_unsupported(monkeypatch):
    from dobbe.core.scheduler import install_login_hook
    monkeypatch.setattr("dobbe.core.scheduler.sys.platform", "freebsd")
    success, msg = install_login_hook()
    assert success is False
    assert "Unsupported" in msg


def test_uninstall_login_hook_darwin(monkeypatch):
    from dobbe.core.scheduler import uninstall_login_hook
    monkeypatch.setattr("dobbe.core.scheduler.sys.platform", "darwin")
    monkeypatch.setattr("dobbe.core.scheduler._uninstall_launchd", lambda: (True, "removed"))
    success, msg = uninstall_login_hook()
    assert success is True


def test_uninstall_login_hook_linux(monkeypatch):
    from dobbe.core.scheduler import uninstall_login_hook
    monkeypatch.setattr("dobbe.core.scheduler.sys.platform", "linux")
    monkeypatch.setattr("dobbe.core.scheduler._uninstall_systemd", lambda: (True, "removed"))
    success, msg = uninstall_login_hook()
    assert success is True


def test_uninstall_login_hook_win32(monkeypatch):
    from dobbe.core.scheduler import uninstall_login_hook
    monkeypatch.setattr("dobbe.core.scheduler.sys.platform", "win32")
    monkeypatch.setattr("dobbe.core.scheduler._uninstall_schtasks", lambda: (True, "removed"))
    success, msg = uninstall_login_hook()
    assert success is True


def test_uninstall_login_hook_unsupported(monkeypatch):
    from dobbe.core.scheduler import uninstall_login_hook
    monkeypatch.setattr("dobbe.core.scheduler.sys.platform", "freebsd")
    success, msg = uninstall_login_hook()
    assert success is False
    assert "Unsupported" in msg


# ---------------------------------------------------------------------------
# Launchd helpers (macOS)
# ---------------------------------------------------------------------------


def test_install_launchd(tmp_path, monkeypatch):
    from dobbe.core.scheduler import _install_launchd
    plist = tmp_path / "com.dobbe.schedule.plist"
    monkeypatch.setattr("dobbe.core.scheduler._launchd_plist_path", lambda: plist)
    monkeypatch.setattr("dobbe.core.scheduler._find_dobbe_executable", lambda: ["/usr/local/bin/dobbe"])
    with patch("dobbe.core.scheduler.subprocess.run") as mock_run:
        success, msg = _install_launchd()
    assert success is True
    assert plist.exists()
    content = plist.read_text()
    assert "<string>/usr/local/bin/dobbe</string>" in content
    assert "<string>schedule</string>" in content
    assert "LaunchAgent installed" in msg
    mock_run.assert_called_once()


def test_install_launchd_fallback_splits_args(tmp_path, monkeypatch):
    """When dobbe is not in PATH, launchd plist splits python -m dobbe into separate elements."""
    import sys
    from dobbe.core.scheduler import _install_launchd
    plist = tmp_path / "com.dobbe.schedule.plist"
    monkeypatch.setattr("dobbe.core.scheduler._launchd_plist_path", lambda: plist)
    monkeypatch.setattr("dobbe.core.scheduler._find_dobbe_executable", lambda: [sys.executable, "-m", "dobbe"])
    with patch("dobbe.core.scheduler.subprocess.run"):
        success, msg = _install_launchd()
    assert success is True
    content = plist.read_text()
    assert f"<string>{sys.executable}</string>" in content
    assert "<string>-m</string>" in content
    assert "<string>dobbe</string>" in content
    assert "<string>schedule</string>" in content


def test_install_launchd_subprocess_failure(tmp_path, monkeypatch):
    """launchctl load failure returns (False, error) instead of crashing."""
    from dobbe.core.scheduler import _install_launchd
    plist = tmp_path / "com.dobbe.schedule.plist"
    monkeypatch.setattr("dobbe.core.scheduler._launchd_plist_path", lambda: plist)
    monkeypatch.setattr("dobbe.core.scheduler._find_dobbe_executable", lambda: ["/usr/local/bin/dobbe"])
    with patch("dobbe.core.scheduler.subprocess.run", side_effect=subprocess.CalledProcessError(1, "launchctl")):
        success, msg = _install_launchd()
    assert success is False
    assert "Failed to load" in msg


def test_install_launchd_already_exists(tmp_path, monkeypatch):
    from dobbe.core.scheduler import _install_launchd
    plist = tmp_path / "com.dobbe.schedule.plist"
    plist.write_text("existing")
    monkeypatch.setattr("dobbe.core.scheduler._launchd_plist_path", lambda: plist)
    success, msg = _install_launchd()
    assert success is False
    assert "already exists" in msg


def test_uninstall_launchd(tmp_path, monkeypatch):
    from dobbe.core.scheduler import _uninstall_launchd
    plist = tmp_path / "com.dobbe.schedule.plist"
    plist.write_text("content")
    monkeypatch.setattr("dobbe.core.scheduler._launchd_plist_path", lambda: plist)
    with patch("dobbe.core.scheduler.subprocess.run"):
        success, msg = _uninstall_launchd()
    assert success is True
    assert not plist.exists()


def test_install_launchd_xml_escaping(tmp_path, monkeypatch):
    """Plist XML-escapes special characters in executable path (Bug E)."""
    from dobbe.core.scheduler import _install_launchd
    plist = tmp_path / "com.dobbe.schedule.plist"
    monkeypatch.setattr("dobbe.core.scheduler._launchd_plist_path", lambda: plist)
    # Simulate a path with XML-special characters
    monkeypatch.setattr("dobbe.core.scheduler._find_dobbe_executable", lambda: ["/path/<with>&special"])
    with patch("dobbe.core.scheduler.subprocess.run"):
        success, msg = _install_launchd()
    assert success is True
    content = plist.read_text()
    assert "&lt;with&gt;&amp;special" in content
    assert "<with>" not in content  # raw chars must be escaped


def test_install_launchd_uses_config_dir_for_logs(tmp_path, monkeypatch):
    """Plist uses CONFIG_DIR/logs instead of /tmp (Bug F)."""
    from dobbe.core.scheduler import _install_launchd
    plist = tmp_path / "com.dobbe.schedule.plist"
    monkeypatch.setattr("dobbe.core.scheduler._launchd_plist_path", lambda: plist)
    monkeypatch.setattr("dobbe.core.scheduler._find_dobbe_executable", lambda: ["/usr/local/bin/dobbe"])
    monkeypatch.setattr("dobbe.core.scheduler.CONFIG_DIR", tmp_path / ".dobbe")
    with patch("dobbe.core.scheduler.subprocess.run"):
        success, msg = _install_launchd()
    assert success is True
    content = plist.read_text()
    assert "/tmp/dobbe-schedule" not in content
    assert "schedule.log" in content
    assert "schedule.err" in content


def test_install_launchd_oserror(tmp_path, monkeypatch):
    """launchctl not on PATH raises FileNotFoundError, caught (Bug G)."""
    from dobbe.core.scheduler import _install_launchd
    plist = tmp_path / "com.dobbe.schedule.plist"
    monkeypatch.setattr("dobbe.core.scheduler._launchd_plist_path", lambda: plist)
    monkeypatch.setattr("dobbe.core.scheduler._find_dobbe_executable", lambda: ["/usr/local/bin/dobbe"])
    with patch("dobbe.core.scheduler.subprocess.run", side_effect=FileNotFoundError("launchctl not found")):
        success, msg = _install_launchd()
    assert success is False
    assert "Failed to load" in msg


def test_uninstall_launchd_not_found(tmp_path, monkeypatch):
    from dobbe.core.scheduler import _uninstall_launchd
    plist = tmp_path / "com.dobbe.schedule.plist"
    monkeypatch.setattr("dobbe.core.scheduler._launchd_plist_path", lambda: plist)
    success, msg = _uninstall_launchd()
    assert success is False
    assert "not found" in msg.lower()


# ---------------------------------------------------------------------------
# Systemd helpers (Linux)
# ---------------------------------------------------------------------------


def test_install_systemd(tmp_path, monkeypatch):
    from dobbe.core.scheduler import _install_systemd
    sd_dir = tmp_path / "systemd" / "user"
    monkeypatch.setattr("dobbe.core.scheduler._systemd_dir", lambda: sd_dir)
    monkeypatch.setattr("dobbe.core.scheduler._find_dobbe_executable", lambda: ["/usr/local/bin/dobbe"])
    with patch("dobbe.core.scheduler.subprocess.run"):
        success, msg = _install_systemd()
    assert success is True
    service_path = sd_dir / "dobbe-schedule.service"
    assert service_path.exists()
    assert "/usr/local/bin/dobbe schedule check --quiet" in service_path.read_text()
    assert (sd_dir / "dobbe-schedule.timer").exists()


def test_install_systemd_subprocess_failure(tmp_path, monkeypatch):
    """systemctl enable failure returns (False, error) instead of crashing."""
    from dobbe.core.scheduler import _install_systemd
    sd_dir = tmp_path / "systemd" / "user"
    monkeypatch.setattr("dobbe.core.scheduler._systemd_dir", lambda: sd_dir)
    monkeypatch.setattr("dobbe.core.scheduler._find_dobbe_executable", lambda: ["/usr/local/bin/dobbe"])
    with patch("dobbe.core.scheduler.subprocess.run", side_effect=subprocess.CalledProcessError(1, "systemctl")):
        success, msg = _install_systemd()
    assert success is False
    assert "Failed to enable" in msg


def test_install_systemd_already_exists(tmp_path, monkeypatch):
    from dobbe.core.scheduler import _install_systemd
    sd_dir = tmp_path / "systemd" / "user"
    sd_dir.mkdir(parents=True)
    (sd_dir / "dobbe-schedule.service").write_text("existing")
    monkeypatch.setattr("dobbe.core.scheduler._systemd_dir", lambda: sd_dir)
    success, msg = _install_systemd()
    assert success is False
    assert "already exists" in msg


def test_uninstall_systemd(tmp_path, monkeypatch):
    from dobbe.core.scheduler import _uninstall_systemd
    sd_dir = tmp_path / "systemd" / "user"
    sd_dir.mkdir(parents=True)
    (sd_dir / "dobbe-schedule.service").write_text("svc")
    (sd_dir / "dobbe-schedule.timer").write_text("timer")
    monkeypatch.setattr("dobbe.core.scheduler._systemd_dir", lambda: sd_dir)
    with patch("dobbe.core.scheduler.subprocess.run"):
        success, msg = _uninstall_systemd()
    assert success is True
    assert not (sd_dir / "dobbe-schedule.service").exists()
    assert not (sd_dir / "dobbe-schedule.timer").exists()


def test_uninstall_systemd_not_found(tmp_path, monkeypatch):
    from dobbe.core.scheduler import _uninstall_systemd
    sd_dir = tmp_path / "systemd" / "user"
    sd_dir.mkdir(parents=True)
    monkeypatch.setattr("dobbe.core.scheduler._systemd_dir", lambda: sd_dir)
    success, msg = _uninstall_systemd()
    assert success is False
    assert "not found" in msg.lower()


# ---------------------------------------------------------------------------
# Windows schtasks helpers
# ---------------------------------------------------------------------------


def test_install_schtasks(monkeypatch):
    from dobbe.core.scheduler import _install_schtasks
    monkeypatch.setattr("dobbe.core.scheduler._find_dobbe_executable", lambda: ["dobbe"])
    with patch("dobbe.core.scheduler.subprocess.run"):
        success, msg = _install_schtasks()
    assert success is True
    assert "dobbe-schedule" in msg


def test_uninstall_schtasks():
    from dobbe.core.scheduler import _uninstall_schtasks
    with patch("dobbe.core.scheduler.subprocess.run"):
        success, msg = _uninstall_schtasks()
    assert success is True


def test_install_schtasks_subprocess_failure(monkeypatch):
    """schtasks /create failure returns (False, error) instead of crashing."""
    from dobbe.core.scheduler import _install_schtasks
    monkeypatch.setattr("dobbe.core.scheduler._find_dobbe_executable", lambda: ["dobbe"])
    with patch("dobbe.core.scheduler.subprocess.run", side_effect=subprocess.CalledProcessError(1, "schtasks")):
        success, msg = _install_schtasks()
    assert success is False
    assert "Failed to create" in msg


def test_uninstall_schtasks_subprocess_failure():
    """schtasks /delete failure returns (False, error) instead of crashing."""
    from dobbe.core.scheduler import _uninstall_schtasks
    with patch("dobbe.core.scheduler.subprocess.run", side_effect=subprocess.CalledProcessError(1, "schtasks")):
        success, msg = _uninstall_schtasks()
    assert success is False
    assert "Failed to delete" in msg


# ---------------------------------------------------------------------------
# _find_dobbe_executable
# ---------------------------------------------------------------------------


def test_find_dobbe_executable_found(monkeypatch):
    from dobbe.core.scheduler import _find_dobbe_executable
    monkeypatch.setattr("shutil.which", lambda x: "/usr/local/bin/dobbe" if x == "dobbe" else None)
    assert _find_dobbe_executable() == ["/usr/local/bin/dobbe"]


def test_find_dobbe_executable_fallback(monkeypatch):
    import sys
    from dobbe.core.scheduler import _find_dobbe_executable
    monkeypatch.setattr("shutil.which", lambda x: None)
    result = _find_dobbe_executable()
    assert isinstance(result, list)
    assert result[0] == sys.executable
    assert result[1:] == ["-m", "dobbe"]


# ---------------------------------------------------------------------------
# Corrupt log file handling
# ---------------------------------------------------------------------------


def test_load_run_logs_skips_corrupt(sched_dir):
    log_dir = sched_dir / "logs" / "schedules" / "corrupt-test"
    log_dir.mkdir(parents=True)
    (log_dir / "20260319T083000.json").write_text("not valid json {{{")
    logs = load_run_logs("corrupt-test")
    assert logs == []


# ---------------------------------------------------------------------------
# Per-schedule lock in run_check
# ---------------------------------------------------------------------------


# --- Bug 10: corrupt TOML ---


def test_load_schedules_corrupt_toml(sched_dir, monkeypatch):
    """Corrupt schedules TOML returns empty dict instead of crashing."""
    import dobbe.core.scheduler as sched_mod
    sched_file = sched_mod.SCHEDULES_FILE
    sched_file.parent.mkdir(parents=True, exist_ok=True)
    sched_file.write_bytes(b"[[[invalid toml")
    result = load_schedules()
    assert result == {}


def test_load_schedules_invalid_interval(sched_dir, monkeypatch):
    """Invalid interval value returns empty dict."""
    import dobbe.core.scheduler as sched_mod
    sched_file = sched_mod.SCHEDULES_FILE
    sched_file.parent.mkdir(parents=True, exist_ok=True)
    sched_file.write_text('[test]\ncommand = "vuln scan"\ninterval = "every_second"\nenabled = true\n')
    result = load_schedules()
    assert result == {}


def test_load_schedules_non_dict_entry(sched_dir, monkeypatch):
    """Non-dict schedule entry is skipped."""
    import dobbe.core.scheduler as sched_mod
    import tomli_w
    sched_file = sched_mod.SCHEDULES_FILE
    sched_file.parent.mkdir(parents=True, exist_ok=True)
    # TOML won't naturally produce non-dict top-level, but let's test edge case
    # Write valid TOML with a proper schedule
    data = {
        "good-sched": {
            "command": "vuln scan",
            "args": "",
            "interval": "daily",
            "enabled": True,
        }
    }
    sched_file.write_bytes(tomli_w.dumps(data).encode())
    result = load_schedules()
    assert "good-sched" in result


# --- Bug 11: shlex unmatched quotes ---


def test_execute_schedule_unmatched_quote(sched_dir):
    """Unmatched quote in command doesn't crash - falls back to str.split."""
    sched = _make_schedule(command="vuln scan --filter 'unmatched")
    with patch("dobbe.core.scheduler.subprocess.run") as mock_run:
        mock_run.return_value.returncode = 0
        mock_run.return_value.stdout = "done\n"
        mock_run.return_value.stderr = ""
        log = execute_schedule(sched)
    assert log.status == RunStatus.SUCCESS


# --- Bug 12: path traversal ---


def test_schedule_name_path_traversal_rejected(sched_dir):
    """Schedule names with path traversal characters are rejected."""
    from dobbe.core.scheduler import _sanitize_schedule_name
    for bad_name in ["../etc/passwd", "foo/bar", "foo\\bar", "foo\x00bar"]:
        with pytest.raises(ValueError, match="Invalid schedule name"):
            _sanitize_schedule_name(bad_name)


def test_add_schedule_path_traversal_rejected(sched_dir):
    """add_schedule rejects path traversal names."""
    sched = _make_schedule(name="../etc/passwd")
    with pytest.raises(ValueError, match="Invalid schedule name"):
        add_schedule(sched)


# --- Bug 13: prune_logs missing_ok ---


def test_prune_logs_missing_file_no_crash(sched_dir):
    """_prune_logs doesn't crash if file is deleted concurrently."""
    log_dir = sched_dir / "logs" / "schedules" / "test"
    log_dir.mkdir(parents=True)
    for i in range(MAX_LOGS_PER_SCHEDULE + 5):
        ts = f"20260319T{i:06d}"
        (log_dir / f"{ts}.json").write_text("{}")
    # Delete some files to simulate concurrent deletion
    files = sorted(log_dir.glob("*.json"))
    files[0].unlink()
    files[1].unlink()
    # Should not raise
    _prune_logs(log_dir)


# --- Bug 14: run_check isolates failures ---


def test_run_check_isolates_schedule_failures(sched_dir):
    """One schedule failing doesn't prevent others from running."""
    s1 = _make_schedule(name="failing", last_run=None)
    s2 = _make_schedule(name="passing", command="--version", last_run=None)
    save_schedules({s1.name: s1, s2.name: s2})

    call_count = 0

    def _mock_run(*args, **kwargs):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            raise RuntimeError("Simulated internal error")
        mock_result = subprocess.CompletedProcess(args=[], returncode=0, stdout="ok\n", stderr="")
        return mock_result

    with patch("dobbe.core.scheduler.subprocess.run", side_effect=_mock_run):
        result = run_check()

    # At least one should have run/attempted
    assert result.schedules_run >= 0
    assert len(result.results) >= 1


def test_run_check_skips_locked_schedule(sched_dir):
    sched = _make_schedule(last_run=None)
    save_schedules({sched.name: sched})
    # Pre-acquire the per-schedule lock
    per_lock = acquire_lock(sched.name)
    assert per_lock is not None

    result = run_check()
    assert result.schedules_run == 0

    release_lock(sched.name)
