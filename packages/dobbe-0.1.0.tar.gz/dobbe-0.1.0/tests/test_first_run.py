"""Tests for dobbe.core.first_run."""

from __future__ import annotations

import os
from unittest.mock import patch, MagicMock

import pytest

from dobbe.core.first_run import (
    TIPS,
    invalidate_first_run_flag,
    maybe_show_tip,
    prompt_and_run_setup,
    should_prompt_setup,
)


@pytest.fixture(autouse=True)
def _reset_flag():
    invalidate_first_run_flag()
    yield
    invalidate_first_run_flag()


# --- should_prompt_setup ---


def test_prompt_when_no_config(monkeypatch):
    mock_file = MagicMock()
    mock_file.exists.return_value = False
    monkeypatch.setattr("dobbe.core.first_run.CONFIG_FILE", mock_file)
    monkeypatch.delenv("CI", raising=False)
    assert should_prompt_setup("vuln", quiet=False) is True


def test_no_prompt_when_config_exists(monkeypatch):
    mock_file = MagicMock()
    mock_file.exists.return_value = True
    monkeypatch.setattr("dobbe.core.first_run.CONFIG_FILE", mock_file)
    assert should_prompt_setup("vuln", quiet=False) is False


def test_no_prompt_when_quiet(monkeypatch):
    mock_file = MagicMock()
    mock_file.exists.return_value = False
    monkeypatch.setattr("dobbe.core.first_run.CONFIG_FILE", mock_file)
    assert should_prompt_setup("vuln", quiet=True) is False


def test_no_prompt_for_setup_command(monkeypatch):
    mock_file = MagicMock()
    mock_file.exists.return_value = False
    monkeypatch.setattr("dobbe.core.first_run.CONFIG_FILE", mock_file)
    monkeypatch.delenv("CI", raising=False)
    assert should_prompt_setup("setup", quiet=False) is False


def test_no_prompt_for_doctor_command(monkeypatch):
    mock_file = MagicMock()
    mock_file.exists.return_value = False
    monkeypatch.setattr("dobbe.core.first_run.CONFIG_FILE", mock_file)
    monkeypatch.delenv("CI", raising=False)
    assert should_prompt_setup("doctor", quiet=False) is False


def test_no_prompt_in_ci(monkeypatch):
    mock_file = MagicMock()
    mock_file.exists.return_value = False
    monkeypatch.setattr("dobbe.core.first_run.CONFIG_FILE", mock_file)
    monkeypatch.setenv("CI", "true")
    assert should_prompt_setup("vuln", quiet=False) is False


def test_session_guard_prevents_double_prompt(monkeypatch):
    mock_file = MagicMock()
    mock_file.exists.return_value = False
    monkeypatch.setattr("dobbe.core.first_run.CONFIG_FILE", mock_file)
    monkeypatch.delenv("CI", raising=False)

    # First call: should prompt
    assert should_prompt_setup("vuln", quiet=False) is True

    # Simulate that prompt_and_run_setup was called (sets _prompted_this_session)
    with patch("dobbe.core.first_run.typer") as mock_typer, \
         patch("dobbe.core.first_run.console"):
        mock_typer.confirm.return_value = False
        prompt_and_run_setup()

    # Second call: session guard prevents
    assert should_prompt_setup("vuln", quiet=False) is False


# --- prompt_and_run_setup ---


def test_prompt_declined(monkeypatch):
    monkeypatch.delenv("CI", raising=False)
    with patch("dobbe.core.first_run.typer") as mock_typer, \
         patch("dobbe.core.first_run.console"):
        mock_typer.confirm.return_value = False
        result = prompt_and_run_setup()
    assert result is False


def test_prompt_accepted(monkeypatch):
    monkeypatch.delenv("CI", raising=False)
    with patch("dobbe.core.first_run.typer") as mock_typer, \
         patch("dobbe.core.first_run.console"), \
         patch("dobbe.commands.setup.run_setup_wizard") as mock_wizard:
        mock_typer.confirm.return_value = True
        result = prompt_and_run_setup()
    assert result is True
    mock_wizard.assert_called_once()


# --- maybe_show_tip ---


def test_tip_shown_run_1(monkeypatch, capsys):
    monkeypatch.delenv("CI", raising=False)
    with patch("dobbe.core.first_run.get_run_count", return_value=1):
        maybe_show_tip(quiet=False)
    # Tip is printed via Rich console; we check it was called
    # (Rich uses stderr or stdout depending on Console config)


def test_tip_not_shown_when_quiet():
    with patch("dobbe.core.first_run.get_run_count", return_value=1), \
         patch("dobbe.core.first_run.console") as mock_console:
        maybe_show_tip(quiet=True)
    mock_console.print.assert_not_called()


def test_tip_not_shown_after_3_runs():
    with patch("dobbe.core.first_run.get_run_count", return_value=4), \
         patch("dobbe.core.first_run.console") as mock_console:
        maybe_show_tip(quiet=False)
    mock_console.print.assert_not_called()


def test_tip_not_shown_in_ci(monkeypatch):
    monkeypatch.setenv("CI", "true")
    with patch("dobbe.core.first_run.get_run_count", return_value=1), \
         patch("dobbe.core.first_run.console") as mock_console:
        maybe_show_tip(quiet=False)
    mock_console.print.assert_not_called()


def test_tip_rotation():
    for i in range(1, len(TIPS) + 1):
        with patch("dobbe.core.first_run.get_run_count", return_value=i), \
             patch("dobbe.core.first_run.console") as mock_console, \
             patch.dict(os.environ, {}, clear=True):
            maybe_show_tip(quiet=False)
            call_args = mock_console.print.call_args[0][0]
            assert TIPS[i - 1] in call_args


# --- BUG 1 fix: setup failure caught gracefully ---


def test_prompt_accepted_setup_fails_typer_exit(monkeypatch):
    """When setup raises typer.Exit, prompt_and_run_setup catches it and returns False."""
    import typer as _typer
    monkeypatch.delenv("CI", raising=False)
    with patch("dobbe.core.first_run.typer") as mock_typer, \
         patch("dobbe.core.first_run.console") as mock_console, \
         patch("dobbe.commands.setup.run_setup_wizard", side_effect=_typer.Exit(1)):
        mock_typer.confirm.return_value = True
        mock_typer.Exit = _typer.Exit
        result = prompt_and_run_setup()
    assert result is False
    assert any("Setup did not complete" in str(c) for c in mock_console.print.call_args_list)


def test_prompt_accepted_setup_fails_system_exit(monkeypatch):
    """When setup raises SystemExit, prompt_and_run_setup catches it and returns False."""
    import typer as _typer
    monkeypatch.delenv("CI", raising=False)
    with patch("dobbe.core.first_run.typer") as mock_typer, \
         patch("dobbe.core.first_run.console") as mock_console, \
         patch("dobbe.commands.setup.run_setup_wizard", side_effect=SystemExit(1)):
        mock_typer.confirm.return_value = True
        mock_typer.Exit = _typer.Exit
        result = prompt_and_run_setup()
    assert result is False
