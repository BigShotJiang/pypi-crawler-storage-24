"""Tests for agent-specific tool sets in claude.py."""

from __future__ import annotations

from unittest.mock import patch

from dobbe.core.claude import (
    BASE_TOOLS,
    FIX_TOOLS,
    REPORT_TOOLS,
    VERIFY_TOOLS,
    build_agent_tools,
)


# --- Tool constants ---


def test_fix_tools_includes_edit_write():
    assert "Edit" in FIX_TOOLS
    assert "Write" in FIX_TOOLS
    for t in BASE_TOOLS:
        assert t in FIX_TOOLS


def test_verify_tools_matches_base():
    assert set(VERIFY_TOOLS) == set(BASE_TOOLS)


def test_report_tools_minimal():
    assert REPORT_TOOLS == ["Read"]


# --- build_agent_tools ---


def test_build_agent_tools_scan():
    tools = build_agent_tools("scan")
    assert set(tools) == set(BASE_TOOLS)


def test_build_agent_tools_fix():
    tools = build_agent_tools("fix")
    assert "Edit" in tools
    assert "Write" in tools
    assert "Bash" in tools


def test_build_agent_tools_verify():
    tools = build_agent_tools("verify")
    assert "Bash" in tools
    assert "Read" in tools
    assert "Edit" not in tools


def test_build_agent_tools_report():
    tools = build_agent_tools("report")
    assert tools == ["Read"]


def test_build_agent_tools_unknown_role():
    tools = build_agent_tools("unknown")
    assert set(tools) == set(BASE_TOOLS)


def test_build_agent_tools_scan_with_github_mcp():
    tools = build_agent_tools("scan", available_mcps={"github": True})
    assert "mcp__github__*" in tools


def test_build_agent_tools_fix_with_github_mcp():
    tools = build_agent_tools("fix", available_mcps={"github": True})
    assert "mcp__github__*" in tools
    assert "Edit" in tools


def test_build_agent_tools_verify_with_github_mcp():
    tools = build_agent_tools("verify", available_mcps={"github": True})
    assert "mcp__github__*" in tools


def test_build_agent_tools_report_no_mcps():
    tools = build_agent_tools("report", available_mcps={"github": True})
    assert "mcp__github__*" not in tools


def test_build_agent_tools_verify_no_slack_mcp():
    tools = build_agent_tools("verify", available_mcps={"slack": True})
    # Verify only gets github MCP, not slack
    assert not any("slack" in t for t in tools)


def test_build_agent_tools_no_mcps():
    tools = build_agent_tools("scan", available_mcps={})
    assert not any("mcp__" in t for t in tools)


def test_build_agent_tools_none_mcps():
    tools = build_agent_tools("scan", available_mcps=None)
    assert not any("mcp__" in t for t in tools)


def test_build_agent_tools_unavailable_mcp():
    tools = build_agent_tools("scan", available_mcps={"github": False})
    assert not any("mcp__" in t for t in tools)
