"""Tests for dobbe.commands.doctor."""

from __future__ import annotations

from unittest.mock import patch, MagicMock

from typer.testing import CliRunner

from dobbe.cli import app
from dobbe.commands.doctor import (
    CheckResult,
    _check_claude_auth,
    _check_claude_installed,
    _check_config_exists,
    _check_default_org,
    _check_gh_cli,
    _check_github_mcp,
    _check_shell_completions,
    _check_slack_mcp,
    _check_watch_repos,
    run_doctor,
)

runner = CliRunner()


# --- Unit tests for individual checks ---


def test_check_claude_installed_pass():
    with patch("dobbe.commands.doctor.is_claude_installed", return_value=True):
        result = _check_claude_installed()
    assert result.passed is True
    assert "installed" in result.message


def test_check_claude_installed_fail():
    with patch("dobbe.commands.doctor.is_claude_installed", return_value=False):
        result = _check_claude_installed()
    assert result.passed is False
    assert "not found" in result.message


def test_check_claude_auth_pass():
    with patch("dobbe.commands.doctor.check_claude_auth", return_value=(True, "logged in")):
        result = _check_claude_auth()
    assert result.passed is True


def test_check_claude_auth_fail():
    with patch("dobbe.commands.doctor.check_claude_auth", return_value=(False, "not authenticated")):
        result = _check_claude_auth()
    assert result.passed is False


def test_check_config_exists_pass(monkeypatch):
    mock_file = MagicMock()
    mock_file.exists.return_value = True
    mock_file.__str__ = lambda self: "/home/.dobbe/config.toml"
    monkeypatch.setattr("dobbe.commands.doctor.CONFIG_FILE", mock_file)
    result = _check_config_exists()
    assert result.passed is True


def test_check_config_exists_fail(monkeypatch):
    mock_file = MagicMock()
    mock_file.exists.return_value = False
    monkeypatch.setattr("dobbe.commands.doctor.CONFIG_FILE", mock_file)
    result = _check_config_exists()
    assert result.passed is False


def test_check_default_org_pass():
    with patch("dobbe.commands.doctor.get_default_org", return_value="my-org"):
        result = _check_default_org()
    assert result.passed is True
    assert "my-org" in result.message


def test_check_default_org_fail():
    with patch("dobbe.commands.doctor.get_default_org", return_value=""):
        result = _check_default_org()
    assert result.passed is False


def test_check_watch_repos_pass():
    with patch("dobbe.commands.doctor.get_local_paths", return_value=["/a", "/b"]):
        result = _check_watch_repos()
    assert result.passed is True
    assert "2 configured" in result.message


def test_check_watch_repos_fail():
    with patch("dobbe.commands.doctor.get_local_paths", return_value=[]):
        result = _check_watch_repos()
    assert result.passed is False


def test_check_github_mcp_pass():
    result = _check_github_mcp({"github": True, "slack": False})
    assert result.passed is True


def test_check_github_mcp_fail():
    result = _check_github_mcp({"github": False, "slack": False})
    assert result.passed is False


def test_check_slack_mcp_pass():
    result = _check_slack_mcp({"github": False, "slack": True})
    assert result.passed is True


def test_check_slack_mcp_fail():
    result = _check_slack_mcp({"github": False, "slack": False})
    assert result.passed is False


def test_check_gh_cli_pass():
    with patch("dobbe.commands.doctor.shutil") as mock_shutil:
        mock_shutil.which.return_value = "/usr/local/bin/gh"
        result = _check_gh_cli()
    assert result.passed is True
    assert "/usr/local/bin/gh" in result.message


def test_check_gh_cli_fail():
    with patch("dobbe.commands.doctor.shutil") as mock_shutil:
        mock_shutil.which.return_value = None
        result = _check_gh_cli()
    assert result.passed is False


def test_check_shell_completions_not_installed(tmp_path, monkeypatch):
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
    result = _check_shell_completions()
    assert result.passed is False


def test_check_shell_completions_installed(tmp_path, monkeypatch):
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
    zfunc = tmp_path / ".zfunc"
    zfunc.mkdir()
    (zfunc / "_dobbe").write_text("# completions")
    result = _check_shell_completions()
    assert result.passed is True


# --- Integration: run_doctor ---


@patch("dobbe.commands.doctor.is_claude_installed", return_value=True)
@patch("dobbe.commands.doctor.check_claude_auth", return_value=(True, "ok"))
@patch("dobbe.commands.doctor.CONFIG_FILE")
@patch("dobbe.commands.doctor.get_default_org", return_value="my-org")
@patch("dobbe.commands.doctor.get_local_paths", return_value=["/a"])
@patch("dobbe.commands.doctor.discover_mcps", return_value={"github": True, "slack": True, "atlassian": False, "sentry": False, "figma": False})
@patch("dobbe.commands.doctor.shutil")
def test_run_doctor_all_pass(mock_shutil, mock_discover, mock_paths, mock_org, mock_cf, mock_auth, mock_installed, tmp_path, monkeypatch):
    mock_cf.exists.return_value = True
    mock_cf.__str__ = lambda self: "/home/.dobbe/config.toml"
    mock_shutil.which.return_value = "/usr/local/bin/gh"
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
    zfunc = tmp_path / ".zfunc"
    zfunc.mkdir()
    (zfunc / "_dobbe").write_text("# completions")

    results = run_doctor()
    assert all(r.passed for r in results)
    assert len(results) == 9


@patch("dobbe.commands.doctor.is_claude_installed", return_value=False)
@patch("dobbe.commands.doctor.check_claude_auth", return_value=(False, "nope"))
@patch("dobbe.commands.doctor.CONFIG_FILE")
@patch("dobbe.commands.doctor.get_default_org", return_value="")
@patch("dobbe.commands.doctor.get_local_paths", return_value=[])
@patch("dobbe.commands.doctor.discover_mcps", return_value={"github": False, "slack": False, "atlassian": False, "sentry": False, "figma": False})
@patch("dobbe.commands.doctor.shutil")
def test_run_doctor_mixed(mock_shutil, mock_discover, mock_paths, mock_org, mock_cf, mock_auth, mock_installed, tmp_path, monkeypatch):
    mock_cf.exists.return_value = False
    mock_shutil.which.return_value = None
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

    results = run_doctor()
    passed = sum(1 for r in results if r.passed)
    assert passed == 0


# --- E2E: dobbe doctor command ---


@patch("dobbe.commands.doctor.is_claude_installed", return_value=True)
@patch("dobbe.commands.doctor.check_claude_auth", return_value=(True, "ok"))
@patch("dobbe.commands.doctor.CONFIG_FILE")
@patch("dobbe.commands.doctor.get_default_org", return_value="my-org")
@patch("dobbe.commands.doctor.get_local_paths", return_value=["/a"])
@patch("dobbe.commands.doctor.discover_mcps", return_value={"github": True, "slack": False, "atlassian": False, "sentry": False, "figma": False})
@patch("dobbe.commands.doctor.shutil")
def test_cli_doctor_e2e(mock_shutil, mock_discover, mock_paths, mock_org, mock_cf, mock_auth, mock_installed, tmp_path, monkeypatch):
    mock_cf.exists.return_value = True
    mock_cf.__str__ = lambda self: "/home/.dobbe/config.toml"
    mock_shutil.which.return_value = "/usr/local/bin/gh"
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

    result = runner.invoke(app, ["doctor"])
    assert result.exit_code == 0
    assert "checks passed" in result.output


# --- E2E: dobbe doctor with mixed pass/fail (Gap 10) ---


@patch("dobbe.commands.doctor.is_claude_installed", return_value=True)
@patch("dobbe.commands.doctor.check_claude_auth", return_value=(False, "not authenticated"))
@patch("dobbe.commands.doctor.CONFIG_FILE")
@patch("dobbe.commands.doctor.get_default_org", return_value="")
@patch("dobbe.commands.doctor.get_local_paths", return_value=[])
@patch("dobbe.commands.doctor.discover_mcps", return_value={"github": False, "slack": False, "atlassian": False, "sentry": False, "figma": False})
@patch("dobbe.commands.doctor.shutil")
def test_cli_doctor_e2e_with_failures(mock_shutil, mock_discover, mock_paths, mock_org, mock_cf, mock_auth, mock_installed, tmp_path, monkeypatch):
    """Doctor E2E with mixed pass/fail checks shows both statuses."""
    mock_cf.exists.return_value = False
    mock_shutil.which.return_value = None
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

    result = runner.invoke(app, ["doctor"])
    assert result.exit_code == 0
    assert "checks passed" in result.output
    # Only Claude CLI installed passes → 1/9
    assert "1/9" in result.output
