"""Tests for conversation transcript renderer."""

from __future__ import annotations

from datetime import datetime

from rich.console import Console

from dobbe.models.resolve import (
    AgentMessage,
    ConversationLog,
    FixAction,
    FixResult,
    PipelineIteration,
    ResolveReport,
    SkippedFix,
    VerifyResult,
)
from dobbe.output.transcript import (
    render_live_message,
    render_pr_body,
    render_transcript,
)


# --- Helpers ---


def _make_report(converged: bool = True, with_pr: bool = True) -> ResolveReport:
    fix = FixAction(
        package_name="django",
        file_modified="requirements.txt",
        old_version="4.2.5",
        new_version="4.2.11",
        alerts_addressed=[1, 2],
    )
    skip = SkippedFix(package_name="numpy", reason="Major version bump", alerts_skipped=[3])
    fr = FixResult(
        repo="org/repo",
        branch="dobbe/fix-vulns",
        base_branch="main",
        fixes=[fix],
        skipped=[skip],
    )
    vr = VerifyResult(passed=converged)
    pi = PipelineIteration(iteration=1, fix_result=fr, verify_result=vr)

    log = ConversationLog()
    log.add(agent="orchestrator", icon="\u2699\ufe0f", summary="Cloned repo")
    log.add(agent="scan", icon="\U0001f50d", summary="Found 3 alerts")
    log.add(agent="fix", icon="\U0001f527", summary="Applied 1 fix", iteration=1)
    log.add(agent="verify", icon="\u2705", summary="All clear", iteration=1)
    log.add(agent="report", icon="\U0001f4dd", summary="Summary here")

    return ResolveReport(
        repo="org/repo",
        scan_summary="3 alerts across 2 packages",
        iterations=[pi],
        converged=converged,
        max_iterations=3,
        final_branch="dobbe/fix-vulns",
        pr_url="https://github.com/org/repo/pull/1" if with_pr else "",
        summary="Fixed 1 package, deferred 1",
        conversation=log,
    )


# --- render_live_message ---


def test_render_live_message_basic():
    msg = AgentMessage(
        agent="scan",
        icon="\U0001f50d",
        summary="Found 5 alerts",
        timestamp=datetime(2024, 1, 15, 10, 30),
    )
    console = Console(file=None, force_terminal=True, width=80)
    render_live_message(msg, console=console)  # should not raise


def test_render_live_message_with_iteration():
    msg = AgentMessage(
        agent="fix",
        icon="\U0001f527",
        iteration=2,
        summary="Applied fixes",
        timestamp=datetime(2024, 1, 15, 10, 31),
    )
    console = Console(file=None, force_terminal=True, width=80)
    render_live_message(msg, console=console)  # should not raise


def test_render_live_message_default_console():
    msg = AgentMessage(
        agent="report",
        icon="\U0001f4dd",
        summary="Done",
        timestamp=datetime(2024, 1, 15, 10, 32),
    )
    render_live_message(msg)  # creates its own console


# --- render_pr_body ---


def test_render_pr_body_converged():
    report = _make_report(converged=True)
    body = render_pr_body(report)
    assert "## Summary" in body
    assert "## Agent Resolution Process" in body
    assert "## Changes" in body
    assert "django" in body
    assert "4.2.5" in body
    assert "4.2.11" in body
    assert "## Deferred" in body
    assert "numpy" in body


def test_render_pr_body_not_converged():
    report = _make_report(converged=False)
    report.summary = ""
    body = render_pr_body(report)
    assert "did not converge" in body


def test_render_pr_body_no_summary():
    report = _make_report()
    report.summary = ""
    body = render_pr_body(report)
    assert "converged" in body


def test_render_pr_body_empty_iterations():
    report = ResolveReport(repo="org/repo")
    body = render_pr_body(report)
    assert "## Summary" in body
    assert "## Changes" not in body


def test_render_pr_body_message_with_details():
    log = ConversationLog()
    log.add(agent="verify", icon="\u2705", summary="Issues found", details="Full details here")
    report = ResolveReport(repo="org/repo", conversation=log)
    body = render_pr_body(report)
    assert "Full details here" in body


def test_render_pr_body_message_with_iteration_tag():
    log = ConversationLog()
    log.add(agent="fix", icon="\U0001f527", summary="Applied fix", iteration=2)
    report = ResolveReport(repo="org/repo", conversation=log)
    body = render_pr_body(report)
    assert "attempt 2" in body


# --- render_transcript ---


def test_render_transcript_full():
    report = _make_report(converged=True, with_pr=True)
    transcript = render_transcript(report)
    assert "# Vulnerability Resolution Transcript" in transcript
    assert "org/repo" in transcript
    assert "**Converged:** True" in transcript
    assert "**Branch:** dobbe/fix-vulns" in transcript
    assert "**PR:**" in transcript
    assert "## Conversation Thread" in transcript
    assert "ORCHESTRATOR" in transcript
    assert "SCAN" in transcript
    assert "FIX" in transcript
    assert "VERIFY" in transcript
    assert "REPORT" in transcript
    assert "## Final Summary" in transcript


def test_render_transcript_no_pr():
    report = _make_report(converged=True, with_pr=False)
    transcript = render_transcript(report)
    assert "**PR:**" not in transcript


def test_render_transcript_not_converged():
    report = _make_report(converged=False, with_pr=False)
    transcript = render_transcript(report)
    assert "**Converged:** False" in transcript


def test_render_transcript_with_details():
    log = ConversationLog()
    log.add(agent="fix", icon="\U0001f527", summary="Applied fix", details="Full JSON response")
    report = ResolveReport(repo="org/repo", conversation=log)
    transcript = render_transcript(report)
    assert "<details>" in transcript
    assert "Full JSON response" in transcript


def test_render_transcript_empty_report():
    report = ResolveReport(repo="org/repo")
    transcript = render_transcript(report)
    assert "org/repo" in transcript
    assert "## Conversation Thread" in transcript


def test_render_transcript_no_summary():
    report = ResolveReport(repo="org/repo", summary="")
    transcript = render_transcript(report)
    assert "## Final Summary" not in transcript
