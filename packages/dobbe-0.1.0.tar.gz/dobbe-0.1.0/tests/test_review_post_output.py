"""Tests for review post output formatters - table and markdown."""

from __future__ import annotations

import io
from datetime import datetime, timedelta

from rich.console import Console

from dobbe.models.review import (
    PRInfo,
    PRReviewResult,
    PostResult,
    ReviewConcern,
    ReviewPostReport,
)
from dobbe.models.shared import ReviewCategory, Severity
from dobbe.output import review_post_markdown, review_post_table


def _make_pr(number=42, repo="org/repo") -> PRInfo:
    return PRInfo(
        repo=repo,
        pr_number=number,
        title=f"PR #{number}",
        author="alice",
        url=f"https://github.com/{repo}/pull/{number}",
        created_at=datetime.now() - timedelta(days=3),
        updated_at=datetime.now(),
    )


def _make_review(risk=Severity.MEDIUM, concerns=None) -> PRReviewResult:
    return PRReviewResult(
        pr=_make_pr(),
        risk_level=risk,
        summary=f"Risk: {risk.value}",
        concerns=concerns or [],
        recommendations=["Review carefully"],
        approval_recommendation="approve",
    )


def _make_post_result(
    posted=False,
    error="",
    skipped_reason="",
    review_url="",
    risk=Severity.MEDIUM,
    number=42,
    concerns=None,
) -> PostResult:
    pr = _make_pr(number=number)
    review = PRReviewResult(
        pr=pr,
        risk_level=risk,
        summary=f"Risk: {risk.value}",
        concerns=concerns or [],
        recommendations=[],
        approval_recommendation="approve",
    )
    return PostResult(
        pr=pr,
        review=review,
        posted=posted,
        error=error,
        skipped_reason=skipped_reason,
        review_url=review_url,
    )


def _make_report(results=None, errors=None, dry_run=False) -> ReviewPostReport:
    return ReviewPostReport(
        timestamp=datetime(2024, 1, 15, 10, 30),
        repos_scanned=["org/repo"],
        results=results or [],
        errors=errors or [],
        dry_run=dry_run,
    )


# --- Table output ---


def test_table_render_posted():
    result = _make_post_result(posted=True, review_url="https://github.com/org/repo/pull/42#review")
    report = _make_report(results=[result])
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=True, width=120)
    review_post_table.render_post_report(report, console=console)
    output = buf.getvalue()
    assert "Posted" in output


def test_table_render_skipped():
    result = _make_post_result(skipped_reason="already reviewed at commit abc123")
    report = _make_report(results=[result])
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=True, width=120)
    review_post_table.render_post_report(report, console=console)
    output = buf.getvalue()
    assert "Skipped" in output


def test_table_render_failed():
    result = _make_post_result(error="403 Forbidden")
    report = _make_report(results=[result])
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=True, width=120)
    review_post_table.render_post_report(report, console=console)
    output = buf.getvalue()
    assert "Failed" in output


def test_table_render_dry_run():
    concern = ReviewConcern(
        category=ReviewCategory.SECURITY,
        severity=Severity.HIGH,
        description="XSS",
        file_path="src/views.py",
        line_number=10,
    )
    result = _make_post_result(skipped_reason="dry run", concerns=[concern])
    report = _make_report(results=[result], dry_run=True)
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=True, width=120)
    review_post_table.render_post_report(report, console=console)
    output = buf.getvalue()
    assert "DRY RUN" in output
    assert "inline comment" in output.lower()
    assert "dry run" in output.lower()


def test_table_render_empty():
    report = _make_report()
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=True, width=120)
    review_post_table.render_post_report(report, console=console)
    output = buf.getvalue()
    assert "No PRs" in output


def test_table_render_with_errors():
    report = _make_report(errors=["Failed to fetch org/broken"])
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=True, width=120)
    review_post_table.render_post_report(report, console=console)
    output = buf.getvalue()
    assert "Error" in output


def test_table_render_default_console():
    result = _make_post_result(posted=True)
    report = _make_report(results=[result])
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=True, width=120)
    review_post_table.render_post_report(report, console=console)
    output = buf.getvalue()
    assert "org/repo" in output


# --- Markdown output ---


def test_markdown_render_posted():
    result = _make_post_result(posted=True, review_url="https://github.com/org/repo/pull/42#review")
    report = _make_report(results=[result])
    output = review_post_markdown.render_post_report(report)
    assert "dobbe review post" in output
    assert "Posted" in output
    assert "Review" in output


def test_markdown_render_empty():
    report = _make_report()
    output = review_post_markdown.render_post_report(report)
    assert "No PRs" in output


def test_markdown_render_with_errors():
    report = _make_report(errors=["Fetch failed"])
    output = review_post_markdown.render_post_report(report)
    assert "Errors" in output
    assert "Fetch failed" in output


def test_markdown_render_dry_run_preview():
    concern = ReviewConcern(
        category=ReviewCategory.SECURITY,
        severity=Severity.HIGH,
        description="SQL injection",
        file_path="src/db.py",
        line_number=42,
    )
    review = PRReviewResult(
        pr=_make_pr(),
        risk_level=Severity.HIGH,
        summary="Security concerns found",
        concerns=[concern],
        recommendations=["Fix SQL injection"],
        approval_recommendation="request_changes",
    )
    result = PostResult(
        pr=_make_pr(),
        review=review,
        skipped_reason="dry run",
    )
    report = _make_report(results=[result], dry_run=True)
    output = review_post_markdown.render_post_report(report)
    assert "DRY RUN" in output
    assert "Review body preview" in output
    assert "Inline comments" in output
    assert "src/db.py:42" in output


def test_markdown_render_stats():
    results = [
        _make_post_result(posted=True, number=1),
        _make_post_result(skipped_reason="already reviewed", number=2),
        _make_post_result(error="failed", number=3),
    ]
    report = _make_report(results=results)
    output = review_post_markdown.render_post_report(report)
    assert "Posted:** 1" in output
    assert "Skipped:** 1" in output
    assert "Failed:** 1" in output


def test_markdown_render_date():
    report = _make_report()
    output = review_post_markdown.render_post_report(report)
    assert "2024-01-15" in output


def test_markdown_render_no_status():
    """PostResult with no posted, no error, no skipped - exercises else branch."""
    pr = _make_pr()
    review = _make_review()
    result = PostResult(pr=pr, review=review)
    report = _make_report(results=[result])
    output = review_post_markdown.render_post_report(report)
    # Should still render the table row
    assert "org/repo" in output


def test_markdown_pipe_in_title_and_details():
    """Pipe characters in PR title and error details are escaped."""
    result = _make_post_result(error="403 | Forbidden", number=99)
    result.pr.title = "Fix | operator"
    report = _make_report(results=[result])
    output = review_post_markdown.render_post_report(report)
    assert "Fix \\| operator" in output
    assert "403 \\| Forbidden" in output


def test_table_render_no_status():
    """PostResult with no posted, no error, no skipped - exercises else branch."""
    pr = _make_pr()
    review = _make_review()
    result = PostResult(pr=pr, review=review)
    report = _make_report(results=[result])
    buf = io.StringIO()
    console = Console(file=buf, force_terminal=True, width=120)
    review_post_table.render_post_report(report, console=console)
    output = buf.getvalue()
    assert "org/repo" in output


def test_markdown_special_chars_escaped():
    """Markdown formatting chars in PR title and details are escaped."""
    result = _make_post_result(error="*bold* `code` [link](url)", number=99)
    result.pr.title = "Fix _italic_ handling"
    report = _make_report(results=[result])
    output = review_post_markdown.render_post_report(report)
    assert "\\*bold\\*" in output
    assert "\\`code\\`" in output
    assert "\\[link\\]" in output
    assert "\\_italic\\_" in output
