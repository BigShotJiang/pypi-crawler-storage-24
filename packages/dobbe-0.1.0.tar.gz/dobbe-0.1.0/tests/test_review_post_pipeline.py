"""Tests for review post pipeline - orchestration, dedup, error paths."""

from __future__ import annotations

import asyncio
import json
import threading
from datetime import datetime, timedelta
from unittest.mock import patch

from dobbe.core.claude import ClaudeResult
from dobbe.core.review_pipeline import _fetch_single_pr, run_review_post
from dobbe.models.review import PRInfo, ReviewPostReport
from dobbe.models.shared import Severity


def _make_pr_dict(number=1, title="PR", author="alice", age_days=3):
    created = (datetime.now() - timedelta(days=age_days)).isoformat()
    return {
        "pr_number": number,
        "title": title,
        "author": author,
        "url": f"https://github.com/org/repo/pull/{number}",
        "created_at": created,
        "updated_at": datetime.now().isoformat(),
    }


def _make_discovery_json(*prs):
    return json.dumps({"prs": list(prs)})


def _make_review_json(risk_level="medium", summary="OK"):
    return json.dumps({
        "risk_level": risk_level,
        "summary": summary,
        "concerns": [],
        "recommendations": [],
        "estimated_review_time": "10 min",
        "approval_recommendation": "approve",
    })


def _make_pr_info(number=1, title="PR", author="alice", age_days=3, labels=None, draft=False, repo="org/repo"):
    """Helper to construct a PRInfo directly."""
    created = datetime.now() - timedelta(days=age_days)
    return PRInfo(
        repo=repo,
        pr_number=number,
        title=title,
        author=author,
        url=f"https://github.com/{repo}/pull/{number}",
        created_at=created,
        updated_at=datetime.now(),
        labels=labels or [],
        draft=draft,
    )


# --- _fetch_single_pr ---


@patch("dobbe.core.review_pipeline.fetch_pr_metadata")
def test_fetch_single_pr_found(mock_metadata):
    pr_info = _make_pr_info(number=42)
    mock_metadata.return_value = (pr_info, None)

    pr, error = asyncio.run(
        _fetch_single_pr("org/repo", 42, asyncio.Semaphore(5))
    )
    assert pr is not None
    assert pr.pr_number == 42
    assert error is None


@patch("dobbe.core.review_pipeline.fetch_pr_metadata")
def test_fetch_single_pr_not_found(mock_metadata):
    mock_metadata.return_value = (None, "PR #42 not found in org/repo")

    pr, error = asyncio.run(
        _fetch_single_pr("org/repo", 42, asyncio.Semaphore(5))
    )
    assert pr is None
    assert error is not None
    assert "not found" in error


@patch("dobbe.core.review_pipeline.fetch_pr_metadata")
def test_fetch_single_pr_api_failure(mock_metadata):
    mock_metadata.return_value = (None, "API error")

    pr, error = asyncio.run(
        _fetch_single_pr("org/repo", 42, asyncio.Semaphore(5))
    )
    assert pr is None
    assert error is not None
    assert "API error" in error


# --- run_review_post ---


@patch("dobbe.core.review_pipeline.post_review")
@patch("dobbe.core.review_pipeline.check_existing_review")
@patch("dobbe.core.review_pipeline.get_pr_head_sha")
@patch("dobbe.core.review_pipeline.fetch_pr_diff")
@patch("dobbe.core.review_pipeline.ask_claude_async")
@patch("dobbe.core.review_pipeline.fetch_pr_metadata")
def test_run_post_single_pr(mock_metadata, mock_claude, mock_diff, mock_sha, mock_check, mock_post):
    pr_info = _make_pr_info(number=42)
    mock_metadata.return_value = (pr_info, None)
    review = _make_review_json(risk_level="high")
    mock_claude.return_value = ClaudeResult(success=True, text=review)
    mock_diff.return_value = ("some diff content", None)
    mock_sha.return_value = "abc123"
    mock_check.return_value = False
    mock_post.return_value = (True, "https://github.com/org/repo/pull/42#review")

    report = asyncio.run(run_review_post(
        repos=["org/repo"],
        pr_number=42,
        reviewers=["@me"],
        available_mcps={},
    ))

    assert isinstance(report, ReviewPostReport)
    assert len(report.results) == 1
    assert report.results[0].posted is True
    assert report.total_posted == 1
    assert report.dry_run is False


@patch("dobbe.core.review_pipeline.fetch_pr_diff")
@patch("dobbe.core.review_pipeline.ask_claude_async")
@patch("dobbe.core.review_pipeline.fetch_pr_metadata")
def test_run_post_dry_run(mock_metadata, mock_claude, mock_diff):
    pr_info = _make_pr_info(number=42)
    mock_metadata.return_value = (pr_info, None)
    review = _make_review_json()
    mock_claude.return_value = ClaudeResult(success=True, text=review)
    mock_diff.return_value = ("some diff content", None)

    with patch("dobbe.core.review_pipeline.get_pr_head_sha", return_value="abc123"), \
         patch("dobbe.core.review_pipeline.check_existing_review", return_value=False):
        report = asyncio.run(run_review_post(
            repos=["org/repo"],
            pr_number=42,
            reviewers=["@me"],
            available_mcps={},
            dry_run=True,
        ))

    assert report.dry_run is True
    assert report.total_posted == 0
    assert report.results[0].skipped_reason == "dry run"


@patch("dobbe.core.review_pipeline.fetch_pr_diff")
@patch("dobbe.core.review_pipeline.check_existing_review")
@patch("dobbe.core.review_pipeline.get_pr_head_sha")
@patch("dobbe.core.review_pipeline.ask_claude_async")
@patch("dobbe.core.review_pipeline.fetch_pr_metadata")
def test_run_post_skips_already_reviewed(mock_metadata, mock_claude, mock_sha, mock_check, mock_diff):
    pr_info = _make_pr_info(number=42)
    mock_metadata.return_value = (pr_info, None)
    review = _make_review_json()
    mock_claude.return_value = ClaudeResult(success=True, text=review)
    mock_diff.return_value = ("some diff content", None)
    mock_sha.return_value = "abc123"
    mock_check.return_value = True  # Already reviewed

    report = asyncio.run(run_review_post(
        repos=["org/repo"],
        pr_number=42,
        reviewers=["@me"],
        available_mcps={},
    ))

    assert report.total_skipped == 1
    assert "already reviewed" in report.results[0].skipped_reason


@patch("dobbe.core.review_pipeline.fetch_pr_diff")
@patch("dobbe.core.review_pipeline.post_review")
@patch("dobbe.core.review_pipeline.check_existing_review")
@patch("dobbe.core.review_pipeline.get_pr_head_sha")
@patch("dobbe.core.review_pipeline.ask_claude_async")
def test_run_post_all_prs(mock_claude, mock_sha, mock_check, mock_post, mock_diff):
    discovery = _make_discovery_json(
        _make_pr_dict(number=1),
        _make_pr_dict(number=2),
    )
    review = _make_review_json()

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=discovery),
        ClaudeResult(success=True, text=review),
        ClaudeResult(success=True, text=review),
    ]
    mock_sha.return_value = "abc123"
    mock_check.return_value = False
    mock_post.return_value = (True, "https://github.com/org/repo/pull/1#review")
    mock_diff.return_value = ("some diff content", None)

    report = asyncio.run(run_review_post(
        repos=["org/repo"],
        pr_number=None,
        reviewers=["@me"],
        available_mcps={},
    ))

    assert len(report.results) == 2
    assert report.total_posted == 2


@patch("dobbe.core.review_pipeline.fetch_pr_diff")
@patch("dobbe.core.review_pipeline.post_review")
@patch("dobbe.core.review_pipeline.check_existing_review")
@patch("dobbe.core.review_pipeline.get_pr_head_sha")
@patch("dobbe.core.review_pipeline.ask_claude_async")
def test_run_post_skips_drafts(mock_claude, mock_sha, mock_check, mock_post, mock_diff):
    draft_pr = _make_pr_dict(number=1)
    draft_pr["draft"] = True
    normal_pr = _make_pr_dict(number=2)
    discovery = _make_discovery_json(draft_pr, normal_pr)
    review = _make_review_json()

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=discovery),
        ClaudeResult(success=True, text=review),
    ]
    mock_sha.return_value = "abc123"
    mock_check.return_value = False
    mock_post.return_value = (True, "url")
    mock_diff.return_value = ("some diff content", None)

    report = asyncio.run(run_review_post(
        repos=["org/repo"],
        pr_number=None,
        reviewers=["@me"],
        available_mcps={},
    ))

    # Only non-draft PR should be included
    assert len(report.results) == 1


@patch("dobbe.core.review_pipeline.fetch_pr_diff")
@patch("dobbe.core.review_pipeline.post_review")
@patch("dobbe.core.review_pipeline.check_existing_review")
@patch("dobbe.core.review_pipeline.get_pr_head_sha")
@patch("dobbe.core.review_pipeline.ask_claude_async")
@patch("dobbe.core.review_pipeline.fetch_pr_metadata")
def test_run_post_analysis_error(mock_metadata, mock_claude, mock_sha, mock_check, mock_post, mock_diff):
    pr_info = _make_pr_info(number=42)
    mock_metadata.return_value = (pr_info, None)
    mock_claude.return_value = ClaudeResult(success=False, error="Analysis timed out")
    mock_diff.return_value = ("some diff content", None)

    report = asyncio.run(run_review_post(
        repos=["org/repo"],
        pr_number=42,
        reviewers=["@me"],
        available_mcps={},
    ))

    assert report.total_failed == 1
    assert "Analysis failed" in report.results[0].error
    mock_post.assert_not_called()


@patch("dobbe.core.review_pipeline.fetch_pr_diff")
@patch("dobbe.core.review_pipeline.post_review")
@patch("dobbe.core.review_pipeline.check_existing_review")
@patch("dobbe.core.review_pipeline.get_pr_head_sha")
@patch("dobbe.core.review_pipeline.ask_claude_async")
@patch("dobbe.core.review_pipeline.fetch_pr_metadata")
def test_run_post_post_failure(mock_metadata, mock_claude, mock_sha, mock_check, mock_post, mock_diff):
    pr_info = _make_pr_info(number=42)
    mock_metadata.return_value = (pr_info, None)
    review = _make_review_json()
    mock_claude.return_value = ClaudeResult(success=True, text=review)
    mock_diff.return_value = ("some diff content", None)
    mock_sha.return_value = "abc123"
    mock_check.return_value = False
    mock_post.return_value = (False, "403 Forbidden")

    report = asyncio.run(run_review_post(
        repos=["org/repo"],
        pr_number=42,
        reviewers=["@me"],
        available_mcps={},
    ))

    assert report.total_failed == 1
    assert "403" in report.results[0].error


@patch("dobbe.core.review_pipeline.fetch_pr_diff")
@patch("dobbe.core.review_pipeline.fetch_pr_metadata")
def test_run_post_fetch_failure(mock_metadata, mock_diff):
    mock_metadata.return_value = (None, "network error")
    mock_diff.return_value = ("", None)

    report = asyncio.run(run_review_post(
        repos=["org/repo"],
        pr_number=42,
        reviewers=["@me"],
        available_mcps={},
    ))

    assert len(report.errors) == 1
    assert len(report.results) == 0


@patch("dobbe.core.review_pipeline.fetch_pr_diff")
@patch("dobbe.core.review_pipeline.post_review")
@patch("dobbe.core.review_pipeline.check_existing_review")
@patch("dobbe.core.review_pipeline.get_pr_head_sha")
@patch("dobbe.core.review_pipeline.ask_claude_async")
def test_run_post_multiple_repos(mock_claude, mock_sha, mock_check, mock_post, mock_diff):
    discovery1 = _make_discovery_json(_make_pr_dict(number=1))
    discovery2 = _make_discovery_json(_make_pr_dict(number=2))
    review = _make_review_json()

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=discovery1),
        ClaudeResult(success=True, text=discovery2),
        ClaudeResult(success=True, text=review),
        ClaudeResult(success=True, text=review),
    ]
    mock_sha.return_value = "abc123"
    mock_check.return_value = False
    mock_post.return_value = (True, "url")
    mock_diff.return_value = ("some diff content", None)

    report = asyncio.run(run_review_post(
        repos=["org/repo1", "org/repo2"],
        pr_number=None,
        reviewers=["@me"],
        available_mcps={},
    ))

    assert len(report.results) == 2
    assert report.repos_scanned == ["org/repo1", "org/repo2"]


@patch("dobbe.core.review_pipeline.fetch_pr_diff")
@patch("dobbe.core.review_pipeline.ask_claude_async")
def test_run_post_no_prs_found(mock_claude, mock_diff):
    mock_claude.return_value = ClaudeResult(success=True, text='{"prs": []}')
    mock_diff.return_value = ("", None)

    report = asyncio.run(run_review_post(
        repos=["org/repo"],
        pr_number=None,
        reviewers=["@me"],
        available_mcps={},
    ))

    assert len(report.results) == 0
    assert report.total_posted == 0


# --- New tests ---


@patch("dobbe.core.review_pipeline.fetch_pr_diff")
@patch("dobbe.core.review_pipeline.post_review")
@patch("dobbe.core.review_pipeline.check_existing_review")
@patch("dobbe.core.review_pipeline.get_pr_head_sha")
@patch("dobbe.core.review_pipeline.ask_claude_async")
@patch("dobbe.core.review_pipeline.fetch_pr_metadata")
def test_run_post_direct_fetch_no_claude_for_discovery(
    mock_metadata, mock_claude, mock_sha, mock_check, mock_post, mock_diff,
):
    """Single PR mode: verify ask_claude_async is NOT called for discovery (only for analysis)."""
    pr_info = _make_pr_info(number=42)
    mock_metadata.return_value = (pr_info, None)
    review = _make_review_json()
    mock_claude.return_value = ClaudeResult(success=True, text=review)
    mock_diff.return_value = ("some diff content", None)
    mock_sha.return_value = "abc123"
    mock_check.return_value = False
    mock_post.return_value = (True, "url")

    report = asyncio.run(run_review_post(
        repos=["org/repo"],
        pr_number=42,
        reviewers=["@me"],
        available_mcps={},
    ))

    # fetch_pr_metadata should be called for discovery (not Claude)
    mock_metadata.assert_called_once()
    # ask_claude_async should only be called once - for analysis, not discovery
    assert mock_claude.call_count == 1
    assert report.total_posted == 1


@patch("dobbe.core.review_pipeline.fetch_pr_diff")
@patch("dobbe.core.review_pipeline.post_review")
@patch("dobbe.core.review_pipeline.check_existing_review")
@patch("dobbe.core.review_pipeline.get_pr_head_sha")
@patch("dobbe.core.review_pipeline.ask_claude_async")
def test_run_post_filter_skips_label(mock_claude, mock_sha, mock_check, mock_post, mock_diff):
    """All PRs mode: 2 PRs discovered, one has label 'wip', pass skip_labels=['wip'], verify only 1 posted."""
    pr1 = _make_pr_dict(number=1)
    pr1["labels"] = ["wip"]
    pr2 = _make_pr_dict(number=2)
    discovery = _make_discovery_json(pr1, pr2)
    review = _make_review_json()

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=discovery),
        ClaudeResult(success=True, text=review),
    ]
    mock_sha.return_value = "abc123"
    mock_check.return_value = False
    mock_post.return_value = (True, "url")
    mock_diff.return_value = ("some diff content", None)

    report = asyncio.run(run_review_post(
        repos=["org/repo"],
        pr_number=None,
        reviewers=["@me"],
        available_mcps={},
        skip_labels=["wip"],
    ))

    assert len(report.results) == 1
    assert report.total_posted == 1


@patch("dobbe.core.review_pipeline.fetch_pr_diff")
@patch("dobbe.core.review_pipeline.post_review")
@patch("dobbe.core.review_pipeline.check_existing_review")
@patch("dobbe.core.review_pipeline.get_pr_head_sha")
@patch("dobbe.core.review_pipeline.ask_claude_async")
def test_run_post_filter_skips_author(mock_claude, mock_sha, mock_check, mock_post, mock_diff):
    """All PRs mode: 2 PRs, one by 'dependabot[bot]', pass skip_authors, verify only 1 posted."""
    pr1 = _make_pr_dict(number=1, author="dependabot[bot]")
    pr2 = _make_pr_dict(number=2, author="alice")
    discovery = _make_discovery_json(pr1, pr2)
    review = _make_review_json()

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=discovery),
        ClaudeResult(success=True, text=review),
    ]
    mock_sha.return_value = "abc123"
    mock_check.return_value = False
    mock_post.return_value = (True, "url")
    mock_diff.return_value = ("some diff content", None)

    report = asyncio.run(run_review_post(
        repos=["org/repo"],
        pr_number=None,
        reviewers=["@me"],
        available_mcps={},
        skip_authors=["dependabot[bot]"],
    ))

    assert len(report.results) == 1
    assert report.total_posted == 1


@patch("dobbe.core.review_pipeline.fetch_pr_diff")
@patch("dobbe.core.review_pipeline.post_review")
@patch("dobbe.core.review_pipeline.check_existing_review")
@patch("dobbe.core.review_pipeline.get_pr_head_sha")
@patch("dobbe.core.review_pipeline.ask_claude_async")
@patch("dobbe.core.review_pipeline.fetch_pr_metadata")
def test_run_post_diff_passed_to_analysis(
    mock_metadata, mock_claude, mock_sha, mock_check, mock_post, mock_diff,
):
    """Single PR: mock fetch_pr_diff to return diff text, verify ask_claude_async prompt contains diff."""
    pr_info = _make_pr_info(number=42)
    mock_metadata.return_value = (pr_info, None)
    review = _make_review_json()
    mock_claude.return_value = ClaudeResult(success=True, text=review)
    mock_diff.return_value = ("+ added line\n- removed line", None)
    mock_sha.return_value = "abc123"
    mock_check.return_value = False
    mock_post.return_value = (True, "url")

    asyncio.run(run_review_post(
        repos=["org/repo"],
        pr_number=42,
        reviewers=["@me"],
        available_mcps={},
    ))

    # The analysis call should contain the diff in its prompt
    assert mock_claude.call_count == 1
    analysis_call = mock_claude.call_args
    prompt_text = analysis_call.kwargs.get("prompt", "") or analysis_call[1].get("prompt", "")
    if not prompt_text:
        # Try positional
        prompt_text = analysis_call[0][0] if analysis_call[0] else ""
    assert "<diff>" in prompt_text


@patch("dobbe.core.review_pipeline.fetch_pr_diff")
@patch("dobbe.core.review_pipeline.post_review")
@patch("dobbe.core.review_pipeline.check_existing_review")
@patch("dobbe.core.review_pipeline.get_pr_head_sha")
@patch("dobbe.core.review_pipeline.ask_claude_async")
@patch("dobbe.core.review_pipeline.fetch_pr_metadata")
def test_run_post_diff_failure_falls_back(
    mock_metadata, mock_claude, mock_sha, mock_check, mock_post, mock_diff,
):
    """Mock fetch_pr_diff to return error, verify analysis still proceeds (Claude fetches diff itself)."""
    pr_info = _make_pr_info(number=42)
    mock_metadata.return_value = (pr_info, None)
    review = _make_review_json()
    mock_claude.return_value = ClaudeResult(success=True, text=review)
    mock_diff.return_value = ("", "diff fetch error")
    mock_sha.return_value = "abc123"
    mock_check.return_value = False
    mock_post.return_value = (True, "url")

    report = asyncio.run(run_review_post(
        repos=["org/repo"],
        pr_number=42,
        reviewers=["@me"],
        available_mcps={},
    ))

    # Analysis should still proceed and post successfully
    assert mock_claude.call_count == 1
    assert report.total_posted == 1


@patch("dobbe.core.review_pipeline.fetch_pr_diff")
@patch("dobbe.core.review_pipeline.post_review")
@patch("dobbe.core.review_pipeline.check_existing_review")
@patch("dobbe.core.review_pipeline.get_pr_head_sha")
@patch("dobbe.core.review_pipeline.ask_claude_async")
def test_run_post_filter_skips_drafts_in_all_mode(mock_claude, mock_sha, mock_check, mock_post, mock_diff):
    """Explicitly pass skip_labels=[] to verify drafts are still filtered in all-PRs mode."""
    draft_pr = _make_pr_dict(number=1)
    draft_pr["draft"] = True
    normal_pr = _make_pr_dict(number=2)
    discovery = _make_discovery_json(draft_pr, normal_pr)
    review = _make_review_json()

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=discovery),
        ClaudeResult(success=True, text=review),
    ]
    mock_sha.return_value = "abc123"
    mock_check.return_value = False
    mock_post.return_value = (True, "url")
    mock_diff.return_value = ("some diff content", None)

    report = asyncio.run(run_review_post(
        repos=["org/repo"],
        pr_number=None,
        reviewers=["@me"],
        available_mcps={},
        skip_labels=[],
    ))

    # Only non-draft PR should be included - drafts filtered regardless of skip_labels
    assert len(report.results) == 1
    assert report.total_posted == 1


# --- asyncio.to_thread wrapping ---


@patch("dobbe.core.review_pipeline.fetch_pr_diff")
@patch("dobbe.core.review_pipeline.fetch_pr_metadata")
def test_fetch_single_pr_runs_in_thread(mock_metadata, mock_diff):
    """_fetch_single_pr uses asyncio.to_thread to avoid blocking the event loop."""
    pr_info = _make_pr_info(number=42)
    call_threads: list[str] = []

    def track_thread(*args, **kwargs):
        call_threads.append(threading.current_thread().name)
        return (pr_info, None)

    mock_metadata.side_effect = track_thread

    pr, error = asyncio.run(
        _fetch_single_pr("org/repo", 42, asyncio.Semaphore(5))
    )

    assert pr is not None
    assert len(call_threads) == 1
    assert call_threads[0] != threading.main_thread().name


@patch("dobbe.core.review_pipeline.fetch_pr_diff")
@patch("dobbe.core.review_pipeline.post_review")
@patch("dobbe.core.review_pipeline.check_existing_review")
@patch("dobbe.core.review_pipeline.get_pr_head_sha")
@patch("dobbe.core.review_pipeline.ask_claude_async")
def test_run_post_dedup_checks_run_in_thread(mock_claude, mock_sha, mock_check, mock_post, mock_diff):
    """Dedup checks (get_pr_head_sha) run in thread pool, not blocking the event loop."""
    discovery = _make_discovery_json(
        _make_pr_dict(number=1),
        _make_pr_dict(number=2),
    )
    review = _make_review_json()

    mock_claude.side_effect = [
        ClaudeResult(success=True, text=discovery),
        ClaudeResult(success=True, text=review),
        ClaudeResult(success=True, text=review),
    ]
    mock_diff.return_value = ("some diff", None)

    sha_call_threads: list[str] = []

    def track_sha(*args, **kwargs):
        sha_call_threads.append(threading.current_thread().name)
        return "abc123"

    mock_sha.side_effect = track_sha
    mock_check.return_value = False
    mock_post.return_value = (True, "url")

    report = asyncio.run(run_review_post(
        repos=["org/repo"],
        pr_number=None,
        reviewers=["@me"],
        available_mcps={},
    ))

    assert len(sha_call_threads) == 2
    main_thread = threading.main_thread().name
    assert all(t != main_thread for t in sha_call_threads)
    assert report.total_posted == 2


@patch("dobbe.core.review_pipeline.fetch_pr_diff")
@patch("dobbe.core.review_pipeline.post_review")
@patch("dobbe.core.review_pipeline.check_existing_review")
@patch("dobbe.core.review_pipeline.get_pr_head_sha")
@patch("dobbe.core.review_pipeline.ask_claude_async")
@patch("dobbe.core.review_pipeline.fetch_pr_metadata")
def test_run_post_dedup_exception_still_posts(mock_metadata, mock_claude, mock_sha, mock_check, mock_post, mock_diff):
    """If dedup check raises an exception, the review is still posted."""
    pr_info = _make_pr_info(number=42)
    mock_metadata.return_value = (pr_info, None)
    review = _make_review_json()
    mock_claude.return_value = ClaudeResult(success=True, text=review)
    mock_diff.return_value = ("diff", None)
    mock_sha.side_effect = OSError("network error")
    mock_post.return_value = (True, "url")

    report = asyncio.run(run_review_post(
        repos=["org/repo"],
        pr_number=42,
        reviewers=["@me"],
        available_mcps={},
    ))

    assert report.total_posted == 1
