"""Tests for config_manager.py - load, save, getters."""

from __future__ import annotations

import tomli_w

from dobbe.core.config_manager import (
    DEFAULT_CONFIG,
    ensure_config_dir,
    get_default_format,
    get_default_org,
    get_default_severity,
    get_local_paths,
    get_review_max_diff_lines,
    get_review_reviewers,
    get_review_skip_authors,
    get_review_skip_labels,
    get_review_stale_days,
    get_review_watch_repos,
    get_slack_channel,
    invalidate_config_cache,
    load_config,
    save_config,
)


# --- load_config ---


def test_load_config_file_not_exists(tmp_path, monkeypatch):
    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_FILE", tmp_path / "missing.toml")
    result = load_config()
    assert result == DEFAULT_CONFIG


def test_load_config_valid_toml(tmp_path, monkeypatch):
    data = {"general": {"default_org": "test-org"}}
    cfg = tmp_path / "config.toml"
    cfg.write_bytes(tomli_w.dumps(data).encode())
    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_FILE", cfg)
    result = load_config()
    assert result["general"]["default_org"] == "test-org"


def test_load_config_empty_file(tmp_path, monkeypatch):
    cfg = tmp_path / "config.toml"
    cfg.write_bytes(b"")
    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_FILE", cfg)
    result = load_config()
    assert result == {}


def test_load_config_returns_independent_copy(tmp_path, monkeypatch):
    """Verify deep copy: mutating returned config must NOT leak into DEFAULT_CONFIG."""
    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_FILE", tmp_path / "missing.toml")
    result = load_config()
    result["general"]["default_org"] = "mutated"
    assert DEFAULT_CONFIG["general"]["default_org"] == ""


# --- save_config ---


def test_save_config_creates_dir_and_file(tmp_path, monkeypatch):
    new_dir = tmp_path / "newdir"
    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_DIR", new_dir)
    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_FILE", new_dir / "config.toml")
    path = save_config({"general": {"default_org": "org1"}})
    assert path.exists()
    assert new_dir.exists()


def test_save_config_roundtrip(tmp_path, monkeypatch):
    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_DIR", tmp_path)
    cfg_file = tmp_path / "config.toml"
    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_FILE", cfg_file)
    data = {"general": {"default_org": "my-org", "default_format": "json"}}
    save_config(data)
    loaded = load_config()
    assert loaded == data


def test_save_config_overwrites_existing(tmp_path, monkeypatch):
    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_DIR", tmp_path)
    cfg_file = tmp_path / "config.toml"
    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_FILE", cfg_file)
    save_config({"general": {"default_org": "first"}})
    save_config({"general": {"default_org": "second"}})
    loaded = load_config()
    assert loaded["general"]["default_org"] == "second"


# --- ensure_config_dir ---


def test_ensure_config_dir_creates_new(tmp_path, monkeypatch):
    new_dir = tmp_path / "new_dobbe"
    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_DIR", new_dir)
    result = ensure_config_dir()
    assert result == new_dir
    assert new_dir.is_dir()


def test_ensure_config_dir_idempotent(tmp_path, monkeypatch):
    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_DIR", tmp_path)
    ensure_config_dir()
    ensure_config_dir()  # no error on second call
    assert tmp_path.is_dir()


# --- Getters ---


def test_get_default_org_with_value():
    config = {"general": {"default_org": "my-org"}}
    assert get_default_org(config) == "my-org"


def test_get_default_org_missing_key():
    assert get_default_org({}) == ""


def test_get_default_format():
    assert get_default_format({}) == "table"
    config = {"general": {"default_format": "json"}}
    assert get_default_format(config) == "json"


def test_get_default_severity_splits_correctly():
    config = {"general": {"default_severity": "critical,high"}}
    assert get_default_severity(config) == ["critical", "high"]


def test_get_default_severity_strips_whitespace():
    config = {"general": {"default_severity": " critical , high "}}
    assert get_default_severity(config) == ["critical", "high"]


def test_get_local_paths():
    config = {"repos": {"local_paths": ["/a", "/b"]}}
    assert get_local_paths(config) == ["/a", "/b"]


def test_get_slack_channel():
    assert get_slack_channel({}) == ""
    config = {"notifications": {"slack_channel": "#alerts"}}
    assert get_slack_channel(config) == "#alerts"


# --- Getters with config=None (trigger load_config path) ---


def test_get_default_org_none_config_loads(config_dir):
    result = get_default_org(config=None)
    assert result == "my-org"


def test_get_default_format_none_config_loads(config_dir):
    result = get_default_format(config=None)
    assert result == "table"


def test_get_default_severity_none_config_loads(config_dir):
    result = get_default_severity(config=None)
    assert result == ["critical", "high"]


def test_get_local_paths_none_config_loads(config_dir):
    result = get_local_paths(config=None)
    assert "/home/user/projects/repo1" in result


def test_get_slack_channel_none_config_loads(config_dir):
    result = get_slack_channel(config=None)
    assert result == "#security-alerts"


# --- Review config getters ---


def test_get_review_watch_repos_with_value():
    config = {"review": {"watch_repos": ["org/repo1", "org/repo2"]}}
    assert get_review_watch_repos(config) == ["org/repo1", "org/repo2"]


def test_get_review_watch_repos_missing():
    assert get_review_watch_repos({}) == []


def test_get_review_reviewers_with_value():
    config = {"review": {"reviewers": ["alice", "bob"]}}
    assert get_review_reviewers(config) == ["alice", "bob"]


def test_get_review_reviewers_default():
    assert get_review_reviewers({}) == ["@me"]


def test_get_review_stale_days_with_value():
    config = {"review": {"stale_days": 14}}
    assert get_review_stale_days(config) == 14


def test_get_review_stale_days_default():
    assert get_review_stale_days({}) == 7


def test_get_review_skip_labels_with_value():
    config = {"review": {"skip_labels": ["wip", "draft"]}}
    assert get_review_skip_labels(config) == ["wip", "draft"]


def test_get_review_skip_labels_missing():
    assert get_review_skip_labels({}) == []


def test_get_review_skip_authors_with_value():
    config = {"review": {"skip_authors": ["dependabot[bot]"]}}
    assert get_review_skip_authors(config) == ["dependabot[bot]"]


def test_get_review_skip_authors_missing():
    assert get_review_skip_authors({}) == []


def test_get_review_max_diff_lines_with_value():
    config = {"review": {"max_diff_lines": 500}}
    assert get_review_max_diff_lines(config) == 500


def test_get_review_max_diff_lines_default():
    assert get_review_max_diff_lines({}) == 2000


# --- Config cache ---


def test_load_config_cache_hit(tmp_path, monkeypatch):
    """Second call returns cached result without re-reading file."""
    data = {"general": {"default_org": "cached-org"}}
    cfg = tmp_path / "config.toml"
    cfg.write_bytes(tomli_w.dumps(data).encode())
    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_FILE", cfg)

    result1 = load_config()
    # Overwrite the file - cache should still return old value
    cfg.write_bytes(tomli_w.dumps({"general": {"default_org": "new-org"}}).encode())
    result2 = load_config()

    assert result1["general"]["default_org"] == "cached-org"
    assert result2["general"]["default_org"] == "cached-org"


def test_save_config_invalidates_cache(tmp_path, monkeypatch):
    """save_config invalidates the cache so next load_config reads from disk."""
    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_DIR", tmp_path)
    cfg_file = tmp_path / "config.toml"
    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_FILE", cfg_file)

    save_config({"general": {"default_org": "first"}})
    result1 = load_config()
    assert result1["general"]["default_org"] == "first"

    save_config({"general": {"default_org": "second"}})
    result2 = load_config()
    assert result2["general"]["default_org"] == "second"


def test_invalidate_config_cache_explicit(tmp_path, monkeypatch):
    """invalidate_config_cache forces next load_config to re-read."""
    data = {"general": {"default_org": "original"}}
    cfg = tmp_path / "config.toml"
    cfg.write_bytes(tomli_w.dumps(data).encode())
    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_FILE", cfg)

    load_config()  # Populate cache
    cfg.write_bytes(tomli_w.dumps({"general": {"default_org": "updated"}}).encode())
    invalidate_config_cache()
    result = load_config()
    assert result["general"]["default_org"] == "updated"


def test_load_config_cache_returns_independent_copies(tmp_path, monkeypatch):
    """Cached load_config returns deep copies - mutations don't affect the cache."""
    data = {"general": {"default_org": "immutable"}}
    cfg = tmp_path / "config.toml"
    cfg.write_bytes(tomli_w.dumps(data).encode())
    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_FILE", cfg)

    result1 = load_config()
    result1["general"]["default_org"] = "mutated"
    result2 = load_config()
    assert result2["general"]["default_org"] == "immutable"


# --- Bug documentation ---


def test_load_config_malformed_toml_falls_back_to_defaults(tmp_path, monkeypatch):
    """Malformed TOML falls back to defaults instead of crashing (Bug A fix)."""
    cfg = tmp_path / "config.toml"
    cfg.write_bytes(b"[invalid toml content = = =")
    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_FILE", cfg)
    result = load_config()
    assert result == DEFAULT_CONFIG


def test_load_config_corrupted_toml(tmp_path, monkeypatch):
    """Corrupted TOML syntax falls back to defaults (Bug A)."""
    cfg = tmp_path / "config.toml"
    cfg.write_bytes(b"key = [[[invalid")
    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_FILE", cfg)
    result = load_config()
    assert result == DEFAULT_CONFIG


def test_load_config_binary_garbage(tmp_path, monkeypatch):
    """Binary garbage triggers UnicodeDecodeError, falls back to defaults (Bug A)."""
    cfg = tmp_path / "config.toml"
    cfg.write_bytes(b"\x80\x81\x82\xff\xfe\xfd\x00\x01")
    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_FILE", cfg)
    result = load_config()
    assert result == DEFAULT_CONFIG


# --- Bug 5: get_default_severity with non-string values ---


def test_get_default_severity_integer_value():
    config = {"general": {"default_severity": 42}}
    result = get_default_severity(config)
    assert result == ["critical", "high"]


def test_get_default_severity_boolean_value():
    config = {"general": {"default_severity": True}}
    result = get_default_severity(config)
    assert result == ["critical", "high"]


# --- Bug 6-7: load_config with IsADirectoryError / PermissionError ---


def test_load_config_path_is_directory(tmp_path, monkeypatch):
    """If CONFIG_FILE is a directory, load_config falls back to defaults."""
    cfg_dir = tmp_path / "config.toml"
    cfg_dir.mkdir()
    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_FILE", cfg_dir)
    result = load_config()
    assert result == DEFAULT_CONFIG


def test_load_config_permission_error(tmp_path, monkeypatch):
    """If CONFIG_FILE is unreadable, load_config falls back to defaults."""
    cfg = tmp_path / "config.toml"
    cfg.write_bytes(b"[general]")
    cfg.chmod(0o000)
    monkeypatch.setattr("dobbe.core.config_manager.CONFIG_FILE", cfg)
    try:
        result = load_config()
        assert result == DEFAULT_CONFIG
    finally:
        cfg.chmod(0o644)


def test_markdown_pipe_breaks_table():
    """Documents that summary containing | breaks markdown table."""
    from dobbe.models.alert import (
        AccessMode,
        AlertGroup,
        RepoResult,
        ScanReport,
        Severity,
        TriageResult,
    )
    from dobbe.output import markdown

    alert = TriageResult(
        alert_number=1,
        package_name="pkg",
        severity=Severity.LOW,
        summary="Uses pattern | pipe | in text",
        affected=False,
        risk_level=Severity.LOW,
        recommended_action="None",
    )
    group = AlertGroup(package_name="pkg", alerts=[alert])
    repo = RepoResult(repo="org/repo", access_mode=AccessMode.LOCAL, groups=[group])
    report = ScanReport(repos=[repo])
    output = markdown.render_report(report)
    # The pipe in summary breaks the table - count columns in the alert row
    table_lines = [line for line in output.split("\n") if line.startswith("| 1")]
    assert len(table_lines) == 1
    # The unescaped pipes create extra columns (more than 7 |'s in the row)
    assert table_lines[0].count("|") > 8
