[![CI](https://github.com/nareshnavinash/dobbe/actions/workflows/ci.yml/badge.svg)](https://github.com/nareshnavinash/dobbe/actions/workflows/ci.yml)
[![PyPI version](https://img.shields.io/pypi/v/dobbe)](https://pypi.org/project/dobbe/)
[![Python 3.11+](https://img.shields.io/badge/python-3.11%2B-blue)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/license-MIT-green)](LICENSE)
[![Tests](https://img.shields.io/badge/tests-994_passed-brightgreen)]()

---

# dobbe

**Your AI security engineer. Not just another version bumper.**

dobbe runs Claude Code agents to autonomously scan, fix, and verify vulnerable
dependencies across your GitHub repos - then opens a PR with passing tests.

---

## Demo

```
$ dobbe vuln resolve --repo nareshnavinash/api

  dobbe v0.1.0 - AI Security Engineer

  ● Discovering MCP servers... GitHub ✓  Slack ✓
  ● Resolving repository... nareshnavinash/api (main)
  ● Creating fix branch... fix/dobbe-security-2026-03-21

  ┌─────────────────────────────────────────────────────┐
  │  SCAN - Fetching Dependabot alerts                  │
  └─────────────────────────────────────────────────────┘
  Found 12 alerts. Triaging with AI...

  ┌──────┬──────────────────┬──────────┬────────────────┐
  │  #   │ Package          │ Severity │ AI Triage      │
  ├──────┼──────────────────┼──────────┼────────────────┤
  │  1   │ lodash 4.17.20   │ Critical │ Fix - in path  │
  │  2   │ express 4.17.1   │ High     │ Fix - in path  │
  │  3   │ semver 7.3.5     │ Medium   │ Skip - unused  │
  └──────┴──────────────────┴──────────┴────────────────┘

  ┌─────────────────────────────────────────────────────┐
  │  FIX - Upgrading 2 dependencies                     │
  └─────────────────────────────────────────────────────┘
  ✓ lodash 4.17.20 → 4.17.21
  ✓ express 4.17.1 → 4.21.0

  ┌─────────────────────────────────────────────────────┐
  │  VERIFY - Running tests (attempt 1/3)               │
  └─────────────────────────────────────────────────────┘
  ✓ 847 tests passed

  ┌─────────────────────────────────────────────────────┐
  │  REPORT - Creating pull request                     │
  └─────────────────────────────────────────────────────┘
  ✓ PR #142 opened: fix/dobbe-security-2026-03-21
    https://github.com/nareshnavinash/api/pull/142
```

## Why dobbe?

**Dependabot alerts pile up.** Your team has hundreds of open alerts. dobbe scans them with AI, determines which ones actually affect your code paths, and tells you what to fix first.

**PR reviews bottleneck your team.** dobbe analyzes open pull requests, flags security issues, and posts inline review comments - so human reviewers can focus on architecture and design.

**Security upgrades break things.** dobbe doesn't just bump versions. It runs an agentic fix-verify loop: upgrade, run tests, read errors, revert, try again - until tests pass or it reports what's blocking convergence.

## Features

| Command | Description |
|---|---|
| `dobbe vuln scan` | Scan repos for Dependabot alerts, triage with AI risk analysis |
| `dobbe vuln resolve` | Agentic fix loop: scan, upgrade, test, iterate until tests pass |
| `dobbe review digest` | Fetch open PRs, analyze with AI, output prioritized review digest |
| `dobbe review post` | Analyze PRs and post inline review comments to GitHub |
| `dobbe schedule` | Automate any command on a recurring schedule |
| `dobbe setup` | Interactive first-time configuration wizard |
| `dobbe doctor` | Check environment health and diagnose issues |
| `dobbe config` | View and manage configuration |

## Quick Start

```bash
pip install dobbe
dobbe setup
dobbe vuln scan --repo nareshnavinash/your-repo
dobbe vuln resolve --repo nareshnavinash/your-repo
```

## dobbe vs. the Alternatives

|                          | dobbe | Dependabot | Renovate | Snyk  |
|--------------------------|-------|------------|----------|-------|
| Auto-bump versions       |  Yes  |    Yes     |   Yes    |  Yes  |
| AI code path analysis    |  Yes  |     -      |    -     |   -   |
| Run tests before PR      |  Yes  |     -      |    -     |   -   |
| Retry on test failure    |  Yes  |     -      |    -     |   -   |
| AI PR code reviews       |  Yes  |     -      |    -     |   -   |
| Org-wide batch scanning  |  Yes  |     -      |   Yes    |  Yes  |
| Terminal-native CLI      |  Yes  |     -      |    -     |  Yes  |
| Open source              |  Yes  |    Yes*    |   Yes    |   -   |
| No SaaS required         |  Yes  |     -      |  Self-host|  -   |

_*Dependabot is open source but tightly coupled to GitHub's hosted infrastructure._

## How It Works

The `dobbe vuln resolve` pipeline orchestrates multiple AI agents in a feedback loop:

```
┌─────────────────────────────────────┐
│     dobbe vuln resolve --repo       │
└──────────────┬──────────────────────┘
               │
               v
┌─────────────────────────────────────┐
│  MCP Discovery + Repo Resolution    │
└──────────────┬──────────────────────┘
               │
               v
┌─────────────────────────────────────┐
│  Create fix branch from base        │
└──────────────┬──────────────────────┘
               │
               v
┌─────────────────────────────────────┐
│  SCAN AGENT                         │
│  Fetch Dependabot alerts,           │
│  triage risk with code analysis     │
└──────────────┬──────────────────────┘
               │
         ┌─────┴─────┐
         │ Dry run?  │
         └─────┬─────┘
       yes |       | no
           v       v
     ┌────────┐  ┌─────────────────────┐
     │ Report │  │  FIX AGENT          │<───┐
     │  and   │  │  Upgrade deps,      │    │
     │  exit  │  │  update lockfiles   │    │
     └────────┘  └──────────┬──────────┘    │
                            │               │
                            v               │
                 ┌──────────────────┐       │
                 │  Git commit      │       │
                 └────────┬─────────┘       │
                          │                 │
                          v                 │
                 ┌──────────────────┐       │
                 │  VERIFY AGENT    │       │
                 │  Run tests,      │       │
                 │  check breaking  │       │
                 │  changes         │       │
                 └────────┬─────────┘       │
                          │                 │
                    ┌─────┴─────┐           │
                    │  Pass?    │           │
                    └─────┬─────┘           │
                  yes |       | no          │
                      │       v             │
                      │  ┌────────────┐     │
                      │  │ Iterations │     │
                      │  │ left?      │     │
                      │  └─────┬──────┘     │
                      │  yes |    | no      │
                      │      │    │         │
                      │      v    │         │
                      │  Revert,  │         │
                      │  feed back├─────────┘
                      │  errors   │
                      │           │
                      v           v
                 ┌──────────────────┐
                 │  REPORT AGENT    │
                 │  Executive       │
                 │  summary         │
                 └────────┬─────────┘
                          │
                          v
                 ┌──────────────────┐
                 │  Create PR       │
                 │  (if converged)  │
                 └──────────────────┘
```

Each agent has scoped tool access - the fix agent can edit files, the verify agent can only read and run tests, and the report agent can only read. See the [resolve pipeline deep dive](docs/architecture/resolve-pipeline.md) for full details.

## Prerequisites

- **Python 3.11+**
- **[Claude Code CLI](https://docs.anthropic.com/en/docs/claude-code)** - installed and authenticated
- **[gh CLI](https://cli.github.com/)** - for GitHub API access
- **MCP servers** (optional) - GitHub, Slack, Atlassian, Sentry for enhanced capabilities

## Installation

```bash
# Install from PyPI
pip install dobbe

# Or with pipx for isolated install
pipx install dobbe

# Development install
git clone https://github.com/nareshnavinash/dobbe.git
cd dobbe
pip install -e ".[dev]"
```

## Configuration

dobbe stores configuration in `~/.dobbe/config.toml`. Run `dobbe setup` to generate it interactively, or edit it directly:

```toml
[general]
default_org = "nareshnavinash"
default_format = "table"          # table, json, markdown
default_severity = "critical,high"

[notifications]
slack_channel = "#security-alerts"
```

See the [full configuration reference](docs/reference/configuration.md) for all options.

## Documentation

- [Getting Started](docs/getting-started.md) - install, setup, first scan
- [Command Reference](docs/commands/) - per-command docs with flowcharts and examples
- [Architecture](docs/architecture/) - system design, pipeline deep dives
- [Configuration Reference](docs/reference/configuration.md) - full TOML reference
- [CLI Reference](docs/reference/cli-reference.md) - every command and option
- [MCP Integrations](docs/reference/mcp-integrations.md) - GitHub, Slack, Jira, Sentry setup
- [Contributing](docs/contributing.md) - dev setup and PR guidelines

## Contributing

```bash
git clone https://github.com/nareshnavinash/dobbe.git
cd dobbe
pip install -e ".[dev]"
pytest
```

994 tests with 98%+ coverage. See the [contributing guide](docs/contributing.md) for full details.

## License

MIT
