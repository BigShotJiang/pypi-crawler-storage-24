# Changelog

## 0.1.0 (2026-03-21)

Initial release. Features:
- `vuln scan` - AI-powered vulnerability triage with code path analysis
- `vuln resolve` - Agentic fix-verify loop with automatic retry
- `review digest` - Prioritized PR review digest
- `review post` - Post AI reviews as inline GitHub comments
- `schedule` - Recurring task automation
- MCP integration auto-discovery (GitHub, Slack, Jira, Sentry)
