# Code of Conduct

## Our Pledge

We as members, contributors, and leaders pledge to make participation in our
community a welcoming experience for everyone.

## Standard

This project follows the [Contributor Covenant v2.1](https://www.contributor-covenant.org/version/2/1/code_of_conduct/).

Please read the full text at the link above. All participants in the dobbe
project are expected to uphold these standards.

## Enforcement

Instances of unacceptable behavior may be reported to the project maintainer
at **nareshnavinash@gmail.com**. All reports will be reviewed promptly and
fairly.

## Attribution

This Code of Conduct is adapted from the
[Contributor Covenant](https://www.contributor-covenant.org), version 2.1.
