"""Centralized status display helpers for consistent CLI output."""

from __future__ import annotations

import os

from rich.console import Console
from rich.markup import escape


def _get_console(console: Console | None = None) -> Console:
    """Return provided console or a default one respecting NO_COLOR."""
    if console:
        return console
    no_color = os.environ.get("NO_COLOR") is not None
    return Console(no_color=no_color)


def error(message: str, console: Console | None = None) -> None:
    """Print an error message with consistent formatting."""
    c = _get_console(console)
    c.print(f"[bold red]Error:[/bold red] {escape(message)}")


def warning(message: str, console: Console | None = None) -> None:
    """Print a warning message with consistent formatting."""
    c = _get_console(console)
    c.print(f"[bold yellow]Warning:[/bold yellow] {escape(message)}")


def success(message: str, console: Console | None = None) -> None:
    """Print a success message with consistent formatting."""
    c = _get_console(console)
    c.print(f"[bold green]\u2713[/bold green] {escape(message)}")


def info(message: str, console: Console | None = None) -> None:
    """Print an info message with consistent formatting."""
    c = _get_console(console)
    c.print(f"[bold]\u2139[/bold] {escape(message)}")
