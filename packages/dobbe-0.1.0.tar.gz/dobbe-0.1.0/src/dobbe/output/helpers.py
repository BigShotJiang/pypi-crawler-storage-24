"""Shared output helpers - severity badges, markdown sanitization."""

from __future__ import annotations

from rich.text import Text

from dobbe.models.shared import Severity

SEVERITY_COLORS: dict[Severity, str] = {
    Severity.CRITICAL: "bold red",
    Severity.HIGH: "bold yellow",
    Severity.MEDIUM: "yellow",
    Severity.LOW: "dim",
}


def severity_badge(severity: Severity) -> Text:
    """Return a styled Rich Text badge for a severity level."""
    style = SEVERITY_COLORS.get(severity, "")
    return Text(severity.value.upper(), style=style)


def sanitize_md_cell(text: str) -> str:
    """Escape characters that break markdown table cells."""
    return (
        text.replace("|", "\\|")
        .replace("\n", " ")
        .replace("*", "\\*")
        .replace("_", "\\_")
        .replace("`", "\\`")
        .replace("[", "\\[")
        .replace("]", "\\]")
    )
